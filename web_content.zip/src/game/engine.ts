import * as THREE from 'three'
import type { Skin } from './skins'
import { sfx } from './audio'

/* ============================== Types ============================== */

export type GameEvent =
  | { type: 'hud'; hp: number; web: number; score: number; combo: number; wave: number; left: number }
  | { type: 'banner'; title: string; sub?: string }
  | { type: 'hit'; pts: number; combo: number; kill: boolean }
  | { type: 'hurt' }
  | { type: 'gameover'; score: number; wave: number }

export type Mode = 'attract' | 'play' | 'over'

/* ============================== World consts ============================== */

const BLOCK = 64
const STREET = 18
const N = 6
const TILE = BLOCK + STREET          // 82
const SPAN = N * TILE + STREET       // 510
const HALF = SPAN / 2                // 255
const STREET_C: number[] = []
for (let k = 0; k <= N; k++) STREET_C.push(-HALF + STREET / 2 + k * TILE) // -246 .. 246

interface Collider { x1: number; x2: number; z1: number; z2: number }

interface Enemy {
  g: THREE.Group
  bodyMat: THREE.MeshLambertMaterial
  eyeMat: THREE.MeshBasicMaterial
  hp: number
  state: 'spawn' | 'chase' | 'windup' | 'recover' | 'stun' | 'dead'
  stateT: number
  speed: number
  kb: THREE.Vector3
  flash: number
  phase: number
  deadT: number
}

interface Particle {
  p: THREE.Vector3
  v: THREE.Vector3
  life: number
  max: number
  color: THREE.Color
  active: boolean
}

/* ============================== Texture helpers ============================== */

function canvasTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void): THREE.CanvasTexture {
  const cv = document.createElement('canvas')
  cv.width = w
  cv.height = h
  const c = cv.getContext('2d')!
  draw(c)
  const t = new THREE.CanvasTexture(cv)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

const FACADES = ['#4a3b6b', '#5c3a52', '#3b4a6b', '#6b4a3b', '#415c52']
const LITS = ['#ffd27a', '#ffe9b8', '#9fd7ff', '#ff9f6e']

function windowTex(variant: number, rows: number): THREE.CanvasTexture {
  const c = canvasTex(128, 64 * rows, (ctx) => {
    ctx.fillStyle = FACADES[variant % FACADES.length]
    ctx.fillRect(0, 0, 128, 64 * rows)
    const cols = 4
    for (let r = 0; r < rows; r++) {
      for (let col = 0; col < cols; col++) {
        const x = 8 + col * 30
        const y = 8 + r * 64
        const rnd = Math.random()
        ctx.fillStyle = rnd < 0.42 ? LITS[(Math.random() * LITS.length) | 0] : '#141126'
        ctx.fillRect(x, y, 20, 40)
        ctx.fillStyle = 'rgba(0,0,0,0.35)'
        ctx.fillRect(x + 9, y, 2, 40)
      }
    }
  })
  return c
}

function groundTex(): THREE.CanvasTexture {
  const S = 512
  const u = S / TILE
  const roadW = STREET * u // 112
  const t = canvasTex(S, S, (ctx) => {
    // block base
    ctx.fillStyle = '#22253a'
    ctx.fillRect(0, 0, S, S)
    ctx.strokeStyle = 'rgba(255,255,255,0.045)'
    ctx.lineWidth = 1
    for (let i = 0; i < S; i += 41) {
      ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, S); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(S, i); ctx.stroke()
    }
    // sidewalks (40px strips around the center cross)
    ctx.fillStyle = '#33374e'
    ctx.fillRect(S / 2 - roadW / 2 - 26, 0, 26, S)
    ctx.fillRect(S / 2 + roadW / 2, 0, 26, S)
    ctx.fillRect(0, S / 2 - roadW / 2 - 26, S, 26)
    ctx.fillRect(0, S / 2 + roadW / 2, S, 26)
    // roads (centered cross, wraps at edges)
    ctx.fillStyle = '#14161f'
    ctx.fillRect(S / 2 - roadW / 2, 0, roadW, S)
    ctx.fillRect(0, S / 2 - roadW / 2, S, roadW)
    // edge glow line at road border
    ctx.fillStyle = 'rgba(255,90,140,0.16)'
    ctx.fillRect(S / 2 - roadW / 2 - 2, 0, 2, S)
    ctx.fillRect(S / 2 + roadW / 2, 0, 2, S)
    ctx.fillRect(0, S / 2 - roadW / 2 - 2, S, 2)
    ctx.fillRect(0, S / 2 + roadW / 2, S, 2)
    // center dashes
    ctx.fillStyle = 'rgba(230,235,255,0.75)'
    for (let i = 0; i < S; i += 52) {
      ctx.fillRect(S / 2 - 2, i, 4, 26)
      ctx.fillRect(i, S / 2 - 2, 26, 4)
    }
    // crosswalks
    ctx.fillStyle = 'rgba(230,235,255,0.55)'
    const cw = 10
    for (let i = 0; i < 7; i++) {
      const o = i * (cw + 8)
      ctx.fillRect(S / 2 + roadW / 2 + 28 + o * 0, 0, 0, 0)
      // top crossing (horizontal stripes across vertical road)
      ctx.fillRect(S / 2 - roadW / 2 + o, S / 2 + roadW / 2 + 30, cw, 22)
      ctx.fillRect(S / 2 - roadW / 2 + o, S / 2 - roadW / 2 - 52, cw, 22)
      ctx.fillRect(S / 2 - roadW / 2 - 52, S / 2 - roadW / 2 + o, 22, cw)
      ctx.fillRect(S / 2 + roadW / 2 + 30, S / 2 - roadW / 2 + o, 22, cw)
    }
  })
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  return t
}

function webDotTex(): THREE.CanvasTexture {
  return canvasTex(64, 64, (ctx) => {
    ctx.strokeStyle = 'rgba(255,255,255,0.95)'
    ctx.lineWidth = 2.5
    ctx.beginPath(); ctx.arc(32, 32, 26, 0, Math.PI * 2); ctx.stroke()
    ctx.beginPath(); ctx.arc(32, 32, 13, 0, Math.PI * 2); ctx.stroke()
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2
      ctx.beginPath()
      ctx.moveTo(32 + Math.cos(a) * 6, 32 + Math.sin(a) * 6)
      ctx.lineTo(32 + Math.cos(a) * 27, 32 + Math.sin(a) * 27)
      ctx.stroke()
    }
  })
}

/* ============================== The Game ============================== */

const NEON = ['#ff2fd6', '#29e6ff', '#ffd21f', '#7cff4f', '#ff5c39']
const CAR_COLORS = ['#ff2a4d', '#ffd21f', '#29e6ff', '#7cff4f', '#ff8c1a', '#c8cff0', '#2b46d8', '#ff5cf0']
const NPC_COLORS = ['#8a4f6d', '#3e6e8e', '#6d8e3e', '#8e6d3e', '#5e3e8e', '#3e8e7d']
const THUG_COLORS = ['#232838', '#2a2030', '#1f2c2a', '#33232b']

export class Game {
  mode: Mode = 'attract'
  paused = false

  private renderer: THREE.WebGLRenderer
  private scene = new THREE.Scene()
  private camera: THREE.PerspectiveCamera
  private onEvent: (e: GameEvent) => void

  /* player */
  private pos = new THREE.Vector3(0, 0, 0)
  private vel = new THREE.Vector3()
  private yaw = 0
  private pitch = 0
  private hp = 100
  private webFluid = 100
  private score = 0
  private combo = 0
  private comboT = 0
  private invuln = 0

  /* input (set by React) */
  joy = { x: 0, y: 0 }
  keys = { x: 0, y: 0 }

  /* swing / web */
  private swinging = false
  private webHeld = false
  private webPressT = 0
  private engaged = false
  private anchor = new THREE.Vector3()
  private ropeLen = 30
  private webCd = 0
  private webDelayT = 0

  /* punch */
  private punchT = 0
  private punchCd = 0
  private hitDone = false

  /* fx */
  private t = 0
  private shakeT = 0
  private hitstopT = 0
  private bobT = 0
  private hudT = 0

  /* waves */
  private wave = 0
  private toSpawn = 0
  private spawnT = 0
  private phase: 'pre' | 'fight' | 'clear' = 'pre'
  private phaseT = 0

  /* world */
  private colliders: Collider[] = []
  private cars: { g: THREE.Group; axis: 0 | 1; dir: 1 | -1; speed: number; lane: number; t: number }[] = []
  private npcs: { g: THREE.Group; axis: 0 | 1; dir: 1 | -1; speed: number; lane: number; t: number; phase: number }[] = []
  private enemies: Enemy[] = []
  private particles: Particle[] = []
  private pMesh: THREE.InstancedMesh
  private rope: THREE.Line
  private ropeGeo: THREE.BufferGeometry
  private webDot: THREE.Sprite
  private projectiles: { mesh: THREE.Mesh; vel: THREE.Vector3; life: number; active: boolean }[] = []

  /* hands */
  private handR!: THREE.Group
  private handL!: THREE.Group
  private gloveMat!: THREE.MeshLambertMaterial
  private glove2Mat!: THREE.MeshLambertMaterial
  private emblemMat!: THREE.MeshLambertMaterial
  private ropeMat!: THREE.LineBasicMaterial
  private projMat!: THREE.MeshBasicMaterial
  private webDotMat!: THREE.SpriteMaterial
  private shadow: THREE.Mesh
  private handShotT = 0

  private raf = 0
  private last = performance.now() / 1000
  private disposed = false
  private onResize = () => {
    const w = window.innerWidth
    const h = window.innerHeight
    this.camera.aspect = w / h
    this.camera.updateProjectionMatrix()
    this.renderer.setSize(w, h, false)
  }

  constructor(canvas: HTMLCanvasElement, skin: Skin, onEvent: (e: GameEvent) => void) {
    this.onEvent = onEvent
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.8))
    this.renderer.setSize(window.innerWidth, window.innerHeight, false)

    this.camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 1600)
    this.camera.rotation.order = 'YXZ'
    this.scene.add(this.camera)

    this.scene.fog = new THREE.Fog(0x5a2464, 70, 460)

    this.buildSky()
    this.buildLights()
    this.buildGround()
    this.buildCity()
    this.buildCars()
    this.buildNpcs()
    this.buildHands(skin)

    // particles
    const pGeo = new THREE.BoxGeometry(0.16, 0.16, 0.16)
    const pMat = new THREE.MeshBasicMaterial()
    this.pMesh = new THREE.InstancedMesh(pGeo, pMat, 90)
    this.pMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage)
    const m = new THREE.Matrix4()
    for (let i = 0; i < 90; i++) {
      this.particles.push({ p: new THREE.Vector3(), v: new THREE.Vector3(), life: 0, max: 1, color: new THREE.Color(), active: false })
      m.makeScale(0, 0, 0)
      this.pMesh.setMatrixAt(i, m)
      this.pMesh.setColorAt(i, new THREE.Color(0xffffff))
    }
    this.scene.add(this.pMesh)

    // rope
    this.ropeGeo = new THREE.BufferGeometry()
    this.ropeGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3))
    this.ropeMat = new THREE.LineBasicMaterial({ color: skin.web, transparent: true, opacity: 0.9 })
    this.rope = new THREE.Line(this.ropeGeo, this.ropeMat)
    this.rope.visible = false
    this.rope.frustumCulled = false
    this.scene.add(this.rope)

    // web dot
    this.webDotMat = new THREE.SpriteMaterial({ map: webDotTex(), color: skin.web, transparent: true, opacity: 0.95, depthWrite: false })
    this.webDot = new THREE.Sprite(this.webDotMat)
    this.webDot.scale.set(1.6, 1.6, 1)
    this.webDot.visible = false
    this.scene.add(this.webDot)

    // projectiles
    this.projMat = new THREE.MeshBasicMaterial({ color: skin.web })
    for (let i = 0; i < 3; i++) {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 8), this.projMat)
      mesh.visible = false
      this.scene.add(mesh)
      this.projectiles.push({ mesh, vel: new THREE.Vector3(), life: 0, active: false })
    }

    // player ground shadow
    this.shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.55, 16),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.32, depthWrite: false })
    )
    this.shadow.rotation.x = -Math.PI / 2
    this.shadow.position.y = 0.03
    this.scene.add(this.shadow)

    window.addEventListener('resize', this.onResize)
    this.raf = requestAnimationFrame(this.tick)
  }

  /* ---------------------------- world building ---------------------------- */

  private buildSky() {
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(1000, 24, 16),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        vertexShader: `varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `
          varying vec3 vP;
          void main(){
            float h = normalize(vP).y;
            vec3 low = vec3(1.0, 0.44, 0.22);
            vec3 mid = vec3(0.42, 0.15, 0.46);
            vec3 top = vec3(0.07, 0.04, 0.17);
            vec3 c = mix(low, mid, smoothstep(-0.02, 0.16, h));
            c = mix(c, top, smoothstep(0.14, 0.55, h));
            gl_FragColor = vec4(c, 1.0);
          }`,
      })
    )
    this.scene.add(sky)

    // moon
    const moon = new THREE.Mesh(
      new THREE.CircleGeometry(28, 24),
      new THREE.MeshBasicMaterial({ color: 0xffe9c4, fog: false })
    )
    moon.position.set(420, 330, -540)
    moon.lookAt(0, 0, 0)
    this.scene.add(moon)

    // stars
    const n = 220
    const arr = new Float32Array(n * 3)
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      const e = 0.15 + Math.random() * 1.2
      const r = 900
      arr[i * 3] = Math.cos(a) * Math.cos(e) * r
      arr[i * 3 + 1] = Math.sin(e) * r
      arr[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(arr, 3))
    const stars = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xcfd6ff, size: 2.2, sizeAttenuation: false, fog: false, transparent: true, opacity: 0.85 }))
    this.scene.add(stars)
  }

  private buildLights() {
    this.scene.add(new THREE.HemisphereLight(0x8a5fd8, 0x241038, 1.15))
    const dir = new THREE.DirectionalLight(0xffa05c, 1.5)
    dir.position.set(140, 70, -120)
    this.scene.add(dir)
  }

  private buildGround() {
    const tex = groundTex()
    const size = 1500
    tex.repeat.set(size / TILE, size / TILE)
    // align the road strip (drawn at tile center) with streets at world coords ≡ 0 mod 82
    const off = 0.5 - ((size / 2) / TILE) % 1
    tex.offset.set(off, off)
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(size, size),
      new THREE.MeshLambertMaterial({ map: tex, color: 0xffffff })
    )
    ground.rotation.x = -Math.PI / 2
    this.scene.add(ground)
  }

  private buildCity() {
    const winMats: THREE.MeshLambertMaterial[] = []
    for (let v = 0; v < FACADES.length; v++) {
      for (let rows = 3; rows <= 7; rows++) {
        const t = windowTex(v, rows)
        const mat = new THREE.MeshLambertMaterial({ map: t })
        winMats.push(mat)
      }
    }
    const matAt = (v: number, h: number) => {
      const rows = h < 26 ? 3 : h < 40 ? 4 : h < 54 ? 5 : h < 68 ? 6 : 7
      return winMats[v * 5 + (rows - 3)]
    }

    const neonMats = NEON.map((c) => new THREE.MeshBasicMaterial({ color: c }))

    for (let b = 0; b < N; b++) {
      const bx = -HALF + STREET + b * TILE
      const bz = HALF - STREET - b * TILE // blocks run in -z direction to match streets at z ≡ 0 mod 82
      for (let lx = 0; lx < 2; lx++) {
        for (let lz = 0; lz < 2; lz++) {
          if (Math.random() < 0.35) continue
          const lot = 32
          const inset = 3 + Math.random() * 4
          const w = lot - inset * 2
          const d = lot - inset * 2
          const cx = bx + lx * lot + lot / 2
          const cz = bz + lz * lot + lot / 2
          const distC = Math.hypot(cx, cz) / HALF
          const h = 16 + Math.random() * (72 - distC * 26)
          const v = (Math.random() * FACADES.length) | 0
          const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), matAt(v, h))
          mesh.position.set(cx, h / 2, cz)
          this.scene.add(mesh)
          this.colliders.push({ x1: cx - w / 2, x2: cx + w / 2, z1: cz - d / 2, z2: cz + d / 2 })

          // roof box
          if (Math.random() < 0.5) {
            const rb = new THREE.Mesh(new THREE.BoxGeometry(w * 0.4, 3, d * 0.4), winMats[(v + 2) * 5 + 1])
            rb.position.set(cx + (Math.random() - 0.5) * 6, h + 1.5, cz + (Math.random() - 0.5) * 6)
            this.scene.add(rb)
          }
          // neon strip
          if (Math.random() < 0.4) {
            const nm = neonMats[(Math.random() * neonMats.length) | 0]
            const strip = new THREE.Mesh(new THREE.BoxGeometry(w * 0.72, 0.7, 0.5), nm)
            strip.position.set(cx, h - 2.5, cz + d / 2 + 0.1)
            if (Math.random() < 0.5) { strip.rotation.y = Math.PI / 2; strip.scale.x = 1 }
            this.scene.add(strip)
          }
        }
      }
    }
  }

  private buildCars() {
    const bodyGeo = new THREE.BoxGeometry(2.2, 1.0, 4.6)
    const cabGeo = new THREE.BoxGeometry(1.9, 0.75, 2.4)
    const headGeo = new THREE.BoxGeometry(1.9, 0.18, 0.1)
    const bodyMats = CAR_COLORS.map((c) => new THREE.MeshLambertMaterial({ color: c }))
    const cabMat = new THREE.MeshLambertMaterial({ color: 0x141a2c })
    const headMat = new THREE.MeshBasicMaterial({ color: 0xfff2b0 })
    const tailMat = new THREE.MeshBasicMaterial({ color: 0xff3b30 })

    for (let i = 0; i < 16; i++) {
      const g = new THREE.Group()
      const body = new THREE.Mesh(bodyGeo, bodyMats[i % bodyMats.length])
      body.position.y = 0.65
      const cab = new THREE.Mesh(cabGeo, cabMat)
      cab.position.set(0, 1.4, 0.2)
      const head = new THREE.Mesh(headGeo, headMat)
      head.position.set(0, 0.6, -2.32)
      const tail = new THREE.Mesh(headGeo, tailMat)
      tail.position.set(0, 0.6, 2.32)
      g.add(body, cab, head, tail)
      this.scene.add(g)
      const axis: 0 | 1 = i % 2 === 0 ? 0 : 1
      const dir: 1 | -1 = Math.random() < 0.5 ? 1 : -1
      const lane = STREET_C[(Math.random() * STREET_C.length) | 0]
      this.cars.push({ g, axis, dir, speed: 8 + Math.random() * 7, lane, t: Math.random() * SPAN - HALF })
    }
  }

  private buildNpcs() {
    const bodyGeo = new THREE.CapsuleGeometry(0.26, 0.7, 3, 7)
    const headGeo = new THREE.SphereGeometry(0.19, 8, 8)
    const bodyMats = NPC_COLORS.map((c) => new THREE.MeshLambertMaterial({ color: c }))
    const headMats = ['#d9a06b', '#8a5a3b', '#f0c8a0', '#5c3a26'].map((c) => new THREE.MeshLambertMaterial({ color: c }))
    for (let i = 0; i < 20; i++) {
      const g = new THREE.Group()
      const body = new THREE.Mesh(bodyGeo, bodyMats[i % bodyMats.length])
      body.position.y = 0.72
      const head = new THREE.Mesh(headGeo, headMats[i % headMats.length])
      head.position.y = 1.52
      g.add(body, head)
      this.scene.add(g)
      const axis: 0 | 1 = i % 2 === 0 ? 0 : 1
      const dir: 1 | -1 = Math.random() < 0.5 ? 1 : -1
      const side = Math.random() < 0.5 ? 1 : -1
      const lane = STREET_C[(Math.random() * STREET_C.length) | 0] + 10.5 * side
      this.npcs.push({ g, axis, dir, speed: 1.1 + Math.random() * 1.4, lane, t: Math.random() * SPAN - HALF, phase: Math.random() * 10 })
    }
  }

  private buildHands(skin: Skin) {
    this.gloveMat = new THREE.MeshLambertMaterial({ color: skin.glove })
    this.glove2Mat = new THREE.MeshLambertMaterial({ color: skin.glove2 })
    this.emblemMat = new THREE.MeshLambertMaterial({ color: skin.emblem })

    const build = (mirror: 1 | -1) => {
      const g = new THREE.Group()
      const palm = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.055, 0.22), this.gloveMat)
      const fingers = new THREE.Mesh(new THREE.BoxGeometry(0.155, 0.05, 0.15), this.gloveMat)
      fingers.position.set(0, 0.004, -0.175)
      const thumb = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.12), this.gloveMat)
      thumb.position.set(mirror * 0.105, -0.005, -0.04)
      thumb.rotation.y = mirror * -0.5
      const cuff = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.1, 0.13), this.glove2Mat)
      cuff.position.set(0, -0.02, 0.16)
      const emblem = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.012, 0.05), this.emblemMat)
      emblem.position.set(0, 0.034, 0.0)
      emblem.rotation.y = Math.PI / 4
      g.add(palm, fingers, thumb, cuff, emblem)
      g.visible = false
      this.camera.add(g)
      return g
    }
    this.handR = build(1)
    this.handL = build(-1)
    this.handR.position.set(0.34, -0.36, -0.55)
    this.handL.position.set(-0.34, -0.36, -0.55)
  }

  /* ---------------------------- public API ---------------------------- */

  setSkin(skin: Skin) {
    this.gloveMat.color.set(skin.glove)
    this.glove2Mat.color.set(skin.glove2)
    this.emblemMat.color.set(skin.emblem)
    this.ropeMat.color.set(skin.web)
    this.projMat.color.set(skin.web)
    this.webDotMat.color.set(skin.web)
  }

  setPaused(p: boolean) { this.paused = p }

  addLook(dx: number, dy: number) {
    if (this.mode !== 'play' || this.paused) return
    this.yaw -= dx * 0.0034
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * 0.003, -1.25, 1.35)
  }

  startRun() {
    for (const e of this.enemies) { this.scene.remove(e.g); e.bodyMat.dispose(); e.eyeMat.dispose() }
    this.enemies = []
    this.pos.set(0, 0, 0)
    this.vel.set(0, 0, 0)
    this.yaw = 0
    this.pitch = 0
    this.hp = 100
    this.webFluid = 100
    this.score = 0
    this.combo = 0
    this.comboT = 0
    this.invuln = 0
    this.swinging = false
    this.webHeld = false
    this.punchT = 0
    this.wave = 0
    this.toSpawn = 0
    this.phase = 'pre'
    this.phaseT = 0.8
    this.handR.visible = true
    this.handL.visible = true
    this.mode = 'play'
    this.emitHud()
  }

  toAttract() {
    this.mode = 'attract'
    this.handR.visible = false
    this.handL.visible = false
    this.swinging = false
    this.webHeld = false
    this.rope.visible = false
    this.webDot.visible = false
    for (const e of this.enemies) { this.scene.remove(e.g); e.bodyMat.dispose(); e.eyeMat.dispose() }
    this.enemies = []
    for (const p of this.projectiles) { p.active = false; p.mesh.visible = false }
  }

  punch() {
    if (this.mode !== 'play' || this.paused) return
    if (this.punchT > 0 || this.punchCd > 0) return
    this.punchT = 0.0001
    this.hitDone = false
    sfx.punchMiss()
  }

  webDown() {
    if (this.mode !== 'play' || this.paused) return
    if (this.webHeld) return
    this.webHeld = true
    this.webPressT = this.t
    this.engaged = false
  }

  webUp() {
    if (!this.webHeld) return
    this.webHeld = false
    const held = this.t - this.webPressT
    if (!this.engaged && held < 0.28 && this.mode === 'play' && !this.paused) this.fireWebShot()
  }

  dispose() {
    this.disposed = true
    cancelAnimationFrame(this.raf)
    window.removeEventListener('resize', this.onResize)
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh
      if (mesh.geometry) mesh.geometry.dispose()
      const mat = (mesh as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined
      if (Array.isArray(mat)) mat.forEach((mm) => mm.dispose())
      else if (mat) mat.dispose()
    })
    this.renderer.dispose()
  }

  /* ---------------------------- helpers ---------------------------- */

  private emitHud() {
    this.onEvent({
      type: 'hud',
      hp: Math.max(0, Math.round(this.hp)),
      web: Math.round(this.webFluid),
      score: this.score,
      combo: this.combo,
      wave: this.wave,
      left: this.toSpawn + this.enemies.filter((e) => e.state !== 'dead').length,
    })
  }

  private cameraForward(out: THREE.Vector3): THREE.Vector3 {
    return out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw))
  }

  private resolveCollide(p: THREE.Vector3, r: number) {
    p.x = THREE.MathUtils.clamp(p.x, -HALF + 3, HALF - 3)
    p.z = THREE.MathUtils.clamp(p.z, -HALF + 3, HALF - 3)
    for (const c of this.colliders) {
      if (p.x > c.x1 - r && p.x < c.x2 + r && p.z > c.z1 - r && p.z < c.z2 + r) {
        const dxl = p.x - (c.x1 - r)
        const dxr = c.x2 + r - p.x
        const dzl = p.z - (c.z1 - r)
        const dzr = c.z2 + r - p.z
        const m = Math.min(dxl, dxr, dzl, dzr)
        if (m === dxl) p.x = c.x1 - r
        else if (m === dxr) p.x = c.x2 + r
        else if (m === dzl) p.z = c.z1 - r
        else p.z = c.z2 + r
      }
    }
  }

  private spawnBurst(p: THREE.Vector3, color: string | number, n: number, up = 0) {
    let spawned = 0
    for (let i = 0; i < this.particles.length && spawned < n; i++) {
      const pt = this.particles[i]
      if (pt.active) continue
      pt.active = true
      pt.p.copy(p)
      pt.p.x += (Math.random() - 0.5) * 0.4
      pt.p.y += (Math.random() - 0.5) * 0.4 + up
      pt.p.z += (Math.random() - 0.5) * 0.4
      pt.v.set((Math.random() - 0.5) * 8, Math.random() * 7 + 2, (Math.random() - 0.5) * 8)
      pt.max = pt.life = 0.5 + Math.random() * 0.3
      pt.color.set(color as THREE.ColorRepresentation)
      this.pMesh.setColorAt(i, pt.color)
      spawned++
    }
    if (this.pMesh.instanceColor) this.pMesh.instanceColor.needsUpdate = true
  }

  /* ---------------------------- enemies ---------------------------- */

  private spawnEnemy() {
    const g = new THREE.Group()
    const color = THUG_COLORS[(Math.random() * THUG_COLORS.length) | 0]
    const bodyMat = new THREE.MeshLambertMaterial({ color })
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.32, 0.85, 3, 8), bodyMat)
    body.position.y = 0.85
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.21, 8, 8), bodyMat)
    head.position.y = 1.7
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff2233 })
    const eyes = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.07, 0.06), eyeMat)
    eyes.position.set(0, 1.72, -0.17)
    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.42, 12),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3, depthWrite: false })
    )
    shadow.rotation.x = -Math.PI / 2
    shadow.position.y = 0.02
    g.add(body, head, eyes, shadow)
    g.scale.setScalar(0.01)
    g.visible = false

    // find a street point near the player
    let px = 0, pz = 0
    for (let tries = 0; tries < 14; tries++) {
      const axis = Math.random() < 0.5
      const c = STREET_C[(Math.random() * STREET_C.length) | 0]
      const off = 10.5 * (Math.random() < 0.5 ? 1 : -1)
      const along = (Math.random() * 2 - 1) * (HALF - 30)
      if (axis) { px = c + off; pz = along } else { px = along; pz = c + off }
      const d = Math.hypot(px - this.pos.x, pz - this.pos.z)
      if (d > 26 && d < 62) break
    }
    g.position.set(px, 0, pz)
    this.scene.add(g)
    this.enemies.push({
      g, bodyMat, eyeMat,
      hp: 3, state: 'spawn', stateT: 0,
      speed: 3.0 + Math.random() * 1.2 + this.wave * 0.15,
      kb: new THREE.Vector3(), flash: 0, phase: Math.random() * 10, deadT: 0,
    })
  }

  private tmpV = new THREE.Vector3()
  private damageEnemy(e: Enemy, dmg: number, from: THREE.Vector3, stun: boolean) {
    if (e.state === 'dead') return
    e.hp -= dmg
    e.flash = 0.12
    const dir = this.tmpV.copy(e.g.position).sub(from).setY(0).normalize()
    e.kb.addScaledVector(dir, 7)
    this.combo++
    this.comboT = 2.5
    const pts = 10 * this.combo
    this.score += pts
    sfx.combo(this.combo)

    let kill = false
    if (e.hp <= 0) {
      kill = true
      e.state = 'dead'
      e.stateT = 0
      const bonus = 100 + this.wave * 15
      this.score += bonus
      sfx.enemyDie()
      this.spawnBurst(new THREE.Vector3(e.g.position.x, 1.2, e.g.position.z), 0xff2fd6, 12)
      this.spawnBurst(new THREE.Vector3(e.g.position.x, 1.2, e.g.position.z), '#ffffff', 6)
    } else {
      this.spawnBurst(new THREE.Vector3(e.g.position.x, 1.2, e.g.position.z), '#ffffff', 6)
      if (stun) { e.state = 'stun'; e.stateT = 0 }
      sfx.webHit()
    }
    this.hitstopT = Math.max(this.hitstopT, kill ? 0.09 : 0.05)
    this.onEvent({ type: 'hit', pts: kill ? pts + 100 + this.wave * 15 : pts, combo: this.combo, kill })
  }

  private playerHurt(dmg: number, from: THREE.Vector3) {
    if (this.invuln > 0 || this.mode !== 'play') return
    this.hp -= dmg
    this.invuln = 0.6
    this.shakeT = 0.35
    this.hitstopT = Math.max(this.hitstopT, 0.07)
    const dir = this.tmpV.copy(this.pos).sub(from).setY(0).normalize()
    this.vel.addScaledVector(dir, 5)
    sfx.hurt()
    this.onEvent({ type: 'hurt' })
    if (this.hp <= 0) {
      this.hp = 0
      this.mode = 'over'
      this.swinging = false
      this.webHeld = false
      sfx.over()
      this.emitHud()
      this.onEvent({ type: 'gameover', score: this.score, wave: this.wave })
    }
  }

  /* ---------------------------- web ---------------------------- */

  private fireWebShot() {
    if (this.webFluid < 12 || this.webCd > 0) return
    this.webFluid -= 12
    this.webCd = 0.35
    this.handShotT = 0.001
    const proj = this.projectiles.find((p) => !p.active)
    if (!proj) return
    proj.active = true
    proj.life = 0.62
    proj.mesh.visible = true
    const handP = new THREE.Vector3()
    this.handR.getWorldPosition(handP)
    proj.mesh.position.copy(handP)
    const fwd = new THREE.Vector3(-Math.sin(this.yaw), Math.sin(this.pitch), -Math.cos(this.yaw))
    proj.vel.copy(fwd).multiplyScalar(70)
    sfx.webShot()
  }

  private endSwing() {
    if (!this.swinging) return
    this.swinging = false
    this.rope.visible = false
    this.webDot.visible = false
    this.webDelayT = 0.6
  }

  /* ---------------------------- main loop ---------------------------- */

  private tick = (nowMs: number) => {
    if (this.disposed) return
    this.raf = requestAnimationFrame(this.tick)
    const now = nowMs / 1000
    const dt = Math.min(0.05, Math.max(0.001, now - this.last))
    this.last = now
    if (this.paused) return

    let gdt = dt
    if (this.hitstopT > 0) { this.hitstopT -= dt; gdt = dt * 0.12 }
    this.t += gdt

    if (this.mode === 'attract') this.updateAttract()
    else if (this.mode === 'play') this.updatePlay(gdt)
    else this.updateOver(gdt)

    this.updateCars(gdt)
    this.updateNpcs(gdt)
    this.updateParticles(gdt)
    this.renderer.render(this.scene, this.camera)
  }

  private updateAttract() {
    const a = this.t * 0.07
    this.camera.position.set(Math.sin(a) * 150, 112 + Math.sin(this.t * 0.2) * 8, Math.cos(a) * 150)
    this.camera.lookAt(0, 16, 0)
  }

  private updateOver(dt: number) {
    this.yaw += dt * 0.08
    this.camera.position.set(this.pos.x, Math.max(1.7, this.pos.y + 1.7), this.pos.z)
    this.camera.rotation.set(-0.15, this.yaw, 0)
    this.updateEnemies(dt)
    this.updateHands(0)
  }

  private updatePlay(dt: number) {
    /* ---- movement input ---- */
    const jx = this.joy.x, jy = this.joy.y
    let ix = 0, iy = 0
    if (Math.abs(this.keys.x) > 0.01 || Math.abs(this.keys.y) > 0.01) { ix = this.keys.x; iy = this.keys.y }
    else if (Math.abs(jx) > 0.08 || Math.abs(jy) > 0.08) { ix = jx; iy = jy }
    const mlen = Math.hypot(ix, iy)
    if (mlen > 1) { ix /= mlen; iy /= mlen }

    const fwd = this.cameraForward(new THREE.Vector3())
    const right = new THREE.Vector3(fwd.z * -1, 0, fwd.x)
    const wish = new THREE.Vector3().addScaledVector(fwd, iy).addScaledVector(right, ix)

    /* ---- web / swing ---- */
    if (this.webHeld && !this.swinging && this.webFluid > 4) {
      const look = new THREE.Vector3(-Math.sin(this.yaw), Math.sin(this.pitch), -Math.cos(this.yaw))
      this.anchor.copy(this.pos).addScaledVector(look, 32)
      this.anchor.y = Math.max(this.anchor.y, this.pos.y + 17)
      this.ropeLen = this.anchor.distanceTo(this.pos)
      this.swinging = true
      this.engaged = true
      this.rope.visible = true
      this.webDot.visible = true
      this.vel.y += 3.5
      sfx.punchMiss()
    }
    if (!this.webHeld || this.webFluid <= 0) this.endSwing()

    if (this.swinging) {
      this.webFluid = Math.max(0, this.webFluid - 26 * dt)
      const toA = this.tmpV.copy(this.anchor).sub(this.pos)
      const dir = toA.normalize()
      this.vel.y -= 15 * dt
      this.vel.addScaledVector(dir, 24 * dt)
      this.vel.addScaledVector(new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)), 5 * dt)
      this.vel.multiplyScalar(1 - 0.18 * dt)
      if (this.vel.lengthSq() > 44 * 44) this.vel.setLength(44)
      this.pos.addScaledVector(this.vel, dt)
      if (this.pos.y < 0.25) { this.pos.y = 0.25; if (this.vel.y < -4) this.vel.y = -4 }
      if (this.pos.distanceTo(this.anchor) > this.ropeLen) {
        this.pos.copy(this.anchor).addScaledVector(dir, -this.ropeLen)
        const vr = this.vel.dot(dir)
        if (vr > 0) this.vel.addScaledVector(dir, -vr)
      }
    } else {
      this.webDelayT -= dt
      if (this.webDelayT <= 0) this.webFluid = Math.min(100, this.webFluid + 15 * dt)
    }
    this.webCd -= dt

    /* ---- normal physics ---- */
    if (!this.swinging) {
      this.vel.y -= 30 * dt
      const accel = 8
      this.vel.x += (wish.x * 9.5 - this.vel.x) * Math.min(1, accel * dt)
      this.vel.z += (wish.z * 9.5 - this.vel.z) * Math.min(1, accel * dt)
    }
    this.pos.addScaledVector(this.vel, dt)
    this.pos.y = Math.max(0, this.pos.y)
    if (this.pos.y === 0 && this.vel.y < 0) this.vel.y = 0
    this.resolveCollide(this.pos, 0.55)

    /* car bumps */
    for (const c of this.cars) {
      const cp = c.g.position
      if (Math.abs(cp.x - this.pos.x) > 6 || Math.abs(cp.z - this.pos.z) > 6) continue
      const dx = this.pos.x - cp.x
      const dz = this.pos.z - cp.z
      if (c.axis === 0) {
        if (Math.abs(dx) < 1.6 && Math.abs(dz) < 2.6 && this.pos.y < 1.6) this.pos.x = cp.x + Math.sign(dx || 1) * 1.6
      } else {
        if (Math.abs(dz) < 1.6 && Math.abs(dx) < 2.6 && this.pos.y < 1.6) this.pos.z = cp.z + Math.sign(dz || 1) * 1.6
      }
    }

    /* ---- punch ---- */
    this.punchCd -= dt
    if (this.punchT > 0) {
      this.punchT += dt / 0.28
      if (!this.hitDone && this.punchT >= 0.3 && this.punchT < 0.9) {
        this.hitDone = true
        const fwdP = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw))
        let best: Enemy | null = null
        let bestD = 2.8
        for (const e of this.enemies) {
          if (e.state === 'dead') continue
          const toE = new THREE.Vector3(e.g.position.x - this.pos.x, 0, e.g.position.z - this.pos.z)
          const dist = toE.length()
          if (dist < bestD && toE.normalize().dot(fwdP) > 0.3) { best = e; bestD = dist }
        }
        if (best) {
          this.damageEnemy(best, 1, this.pos, false)
          sfx.punchHit()
          this.shakeT = Math.max(this.shakeT, 0.12)
        }
      }
      if (this.punchT >= 1) this.punchT = 0
    }
    if (this.handShotT > 0) {
      this.handShotT += dt / 0.2
      if (this.handShotT >= 1) this.handShotT = 0
    }

    /* ---- projectiles ---- */
    for (const p of this.projectiles) {
      if (!p.active) continue
      p.life -= dt
      p.mesh.position.addScaledVector(p.vel, dt)
      let hit = false
      for (const e of this.enemies) {
        if (e.state === 'dead') continue
        const cp = new THREE.Vector3(e.g.position.x, 1.0, e.g.position.z)
        if (p.mesh.position.distanceToSquared(cp) < 1.3) {
          this.damageEnemy(e, 2, p.mesh.position, true)
          hit = true
          break
        }
      }
      if (hit || p.life <= 0 || p.mesh.position.y < 0) {
        if (p.life <= 0 || p.mesh.position.y < 0) this.spawnBurst(p.mesh.position, this.skinWebColor(), 4)
        p.active = false
        p.mesh.visible = false
      }
    }

    /* ---- enemies & waves ---- */
    this.updateEnemies(dt)
    this.updateWaves(dt)

    /* ---- combo ---- */
    this.comboT -= dt
    if (this.comboT <= 0 && this.combo > 0) this.combo = 0
    this.invuln -= dt
    this.shakeT = Math.max(0, this.shakeT - dt)

    /* ---- camera ---- */
    const speed = this.vel.length()
    const grounded = this.pos.y <= 0.02 && !this.swinging
    if (grounded && speed > 1) this.bobT += speed * dt
    const bob = grounded ? Math.sin(this.bobT * 2.6) * 0.05 * Math.min(1, speed / 9) : 0
    let shx = 0, shy = 0, shp = 0
    if (this.shakeT > 0) {
      const s = this.shakeT * 0.5
      shx = (Math.random() - 0.5) * s
      shy = (Math.random() - 0.5) * s
      shp = (Math.random() - 0.5) * s * 0.6
    }
    this.camera.position.set(this.pos.x + shx, this.pos.y + 1.7 + bob + shy, this.pos.z + shx * 0.5)
    const rightV = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw))
    const lateral = this.vel.dot(rightV)
    const targetRoll = this.swinging ? THREE.MathUtils.clamp(-lateral * 0.014, -0.16, 0.16) : 0
    this.camera.rotation.set(this.pitch + shp, this.yaw, targetRoll)
    const targetFov = 70 + (this.swinging ? Math.min(24, speed * 0.5) : Math.min(9, speed * 0.6))
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, 6 * dt)
      this.camera.updateProjectionMatrix()
    }

    this.shadow.position.set(this.pos.x, 0.03, this.pos.z)
    this.shadow.visible = this.pos.y < 12

    /* ---- hands & rope ---- */
    this.updateHands(1)
    if (this.swinging) {
      const handP = new THREE.Vector3()
      this.handR.getWorldPosition(handP)
      const attr = this.ropeGeo.getAttribute('position') as THREE.BufferAttribute
      attr.setXYZ(0, handP.x, handP.y, handP.z)
      attr.setXYZ(1, this.anchor.x, this.anchor.y, this.anchor.z)
      attr.needsUpdate = true
      this.rope.visible = true
      this.webDot.position.copy(this.anchor)
      this.webDot.visible = true
    } else {
      this.rope.visible = false
      this.webDot.visible = false
    }

    /* ---- HUD ---- */
    this.hudT += dt
    if (this.hudT > 0.12) { this.hudT = 0; this.emitHud() }
  }

  private skinWebColor() { return this.ropeMat.color.getHex() }

  private updateWaves(dt: number) {
    this.phaseT -= dt
    if (this.phase === 'pre') {
      if (this.phaseT <= 0) {
        this.wave++
        this.toSpawn = Math.min(12, 2 + this.wave * 2)
        this.phase = 'fight'
        this.spawnT = 0
        sfx.wave()
        this.onEvent({ type: 'banner', title: `WAVE ${this.wave}`, sub: `${this.toSpawn} THUGS INBOUND` })
      }
      return
    }
    if (this.phase === 'fight') {
      if (this.toSpawn > 0) {
        this.spawnT -= dt
        if (this.spawnT <= 0) { this.spawnT = 0.55; this.toSpawn--; this.spawnEnemy() }
      } else if (this.enemies.length === 0) {
        const bonus = 75 * this.wave
        this.score += bonus
        this.phase = 'clear'
        this.phaseT = 2.2
        sfx.clear()
        this.onEvent({ type: 'banner', title: 'WAVE CLEARED', sub: `+${bonus} BONUS` })
      }
      return
    }
    // clear
    if (this.phaseT <= 0) { this.phase = 'pre'; this.phaseT = 0.8 }
  }

  private updateEnemies(dt: number) {
    const toRemove: Enemy[] = []
    for (const e of this.enemies) {
      e.stateT += dt
      e.flash = Math.max(0, e.flash - dt)
      e.bodyMat.emissive.setHex(e.flash > 0 ? 0x999999 : 0x000000)
      e.kb.multiplyScalar(Math.max(0, 1 - 4 * dt))
      e.g.position.addScaledVector(e.kb, dt)

      const toP = new THREE.Vector3(this.pos.x - e.g.position.x, 0, this.pos.z - e.g.position.z)
      const dist = toP.length()

      switch (e.state) {
        case 'spawn': {
          const s = Math.min(1, e.stateT / 0.35)
          e.g.scale.setScalar(0.01 + s * s)
          if (s >= 1) { e.state = 'chase'; e.stateT = 0; e.g.visible = true }
          break
        }
        case 'chase': {
          e.g.visible = true
          if (dist > 1.5) {
            const sp = e.speed * (this.mode === 'play' ? 1 : 0.25)
            e.g.position.addScaledVector(toP.normalize(), sp * dt)
            const targetRot = Math.atan2(-toP.x, -toP.z)
            e.g.rotation.y += (targetRot - e.g.rotation.y) * Math.min(1, 8 * dt)
            e.g.position.y = Math.abs(Math.sin(this.t * 7 + e.phase)) * 0.07
          } else {
            e.g.position.y = 0
            e.g.rotation.y += (Math.atan2(-toP.x, -toP.z) - e.g.rotation.y) * Math.min(1, 6 * dt)
          }
          if (this.mode === 'play' && dist < 2.4 && e.stateT > 0.4) { e.state = 'windup'; e.stateT = 0 }
          break
        }
        case 'windup': {
          e.g.visible = true
          e.g.position.x += (Math.random() - 0.5) * 0.02
          e.eyeMat.color.setHex(0xff8899)
          if (e.stateT >= 0.38) {
            e.eyeMat.color.setHex(0xff2233)
            if (this.mode === 'play' && dist < 3.0) this.playerHurt(8 + this.wave, e.g.position)
            e.state = 'recover'; e.stateT = 0
          }
          break
        }
        case 'recover': {
          if (e.stateT >= 0.55) { e.state = 'chase'; e.stateT = 0 }
          break
        }
        case 'stun': {
          e.g.rotation.z = Math.sin(e.stateT * 20) * 0.08
          if (e.stateT >= 1.1) { e.state = 'chase'; e.stateT = 0; e.g.rotation.z = 0 }
          break
        }
        case 'dead': {
          e.deadT += dt
          e.g.rotation.x -= 6.5 * dt
          if (e.deadT > 0.8) e.g.position.y -= 2.5 * dt
          if (e.deadT > 1.9) toRemove.push(e)
          break
        }
      }

      // separation
      if (e.state !== 'dead') {
        for (const o of this.enemies) {
          if (o === e || o.state === 'dead') continue
          const dx = e.g.position.x - o.g.position.x
          const dz = e.g.position.z - o.g.position.z
          const d2 = dx * dx + dz * dz
          if (d2 < 1.4 && d2 > 0.0001) {
            const d = Math.sqrt(d2)
            e.g.position.x += (dx / d) * 1.4 * dt
            e.g.position.z += (dz / d) * 1.4 * dt
          }
        }
        this.resolveCollide(e.g.position, 0.45)
        e.g.position.y = Math.max(0, e.g.position.y)
      }
    }
    for (const e of toRemove) {
      this.scene.remove(e.g)
      e.bodyMat.dispose()
      e.eyeMat.dispose()
      this.enemies.splice(this.enemies.indexOf(e), 1)
    }
  }

  private updateHands(dt: number) {
    const idle = this.t
    const bobR = Math.sin(idle * 2.3 + 1) * 0.012
    const bobL = Math.sin(idle * 2.1) * 0.012

    // right hand target
    let rx = 0.34, ry = -0.36 + bobR, rz = -0.55
    let rrx = 0.15, rry = -0.12
    if (this.swinging) { rx = 0.27; ry = -0.12 + bobR; rz = -1.02; rrx = -0.45; rry = -0.05 }
    else if (this.punchT > 0) {
      const ext = Math.sin(Math.min(1, this.punchT) * Math.PI)
      rz = -0.55 - ext * 0.55
      ry = -0.36 + ext * 0.12
      rrx = 0.05
    } else if (this.handShotT > 0) {
      const ext = Math.sin(Math.min(1, this.handShotT) * Math.PI)
      rz = -0.55 - ext * 0.4
      rrx = -0.15
    }
    const k = 1 - Math.exp(-16 * dt)
    this.handR.position.x += (rx - this.handR.position.x) * k
    this.handR.position.y += (ry - this.handR.position.y) * k
    this.handR.position.z += (rz - this.handR.position.z) * k
    this.handR.rotation.x += (rrx - this.handR.rotation.x) * k
    this.handR.rotation.y += (rry - this.handR.rotation.y) * k

    // left hand
    let lx = -0.34, ly = -0.38 + bobL, lz = -0.5
    let lrx = 0.2, lry = 0.12
    if (this.swinging) { lx = -0.4; ly = -0.42; lz = -0.42; lrx = 0.3 }
    this.handL.position.x += (lx - this.handL.position.x) * k
    this.handL.position.y += (ly - this.handL.position.y) * k
    this.handL.position.z += (lz - this.handL.position.z) * k
    this.handL.rotation.x += (lrx - this.handL.rotation.x) * k
    this.handL.rotation.y += (lry - this.handL.rotation.y) * k
  }

  private updateCars(dt: number) {
    for (const c of this.cars) {
      c.t += c.dir * c.speed * dt
      if (c.t > HALF + 40) c.t = -HALF - 40
      if (c.t < -HALF - 40) c.t = HALF + 40
      if (c.axis === 0) {
        c.g.position.set(c.lane + (c.dir === 1 ? 3.5 : -3.5), 0, c.t)
        c.g.rotation.y = c.dir === 1 ? Math.PI : 0
      } else {
        c.g.position.set(c.t, 0, c.lane + (c.dir === 1 ? 3.5 : -3.5))
        c.g.rotation.y = c.dir === 1 ? -Math.PI / 2 : Math.PI / 2
      }
    }
  }

  private updateNpcs(dt: number) {
    for (const n of this.npcs) {
      n.t += n.dir * n.speed * dt
      if (n.t > HALF - 15) n.t = -HALF + 15
      if (n.t < -HALF + 15) n.t = HALF - 15
      n.g.position.y = Math.abs(Math.sin(this.t * 6 + n.phase)) * 0.06
      if (n.axis === 0) { n.g.position.set(n.lane, 0, n.t); n.g.rotation.y = n.dir === 1 ? 0 : Math.PI }
      else { n.g.position.set(n.t, 0, n.lane); n.g.rotation.y = n.dir === 1 ? Math.PI / 2 : -Math.PI / 2 }
    }
  }

  private tmpM = new THREE.Matrix4()
  private updateParticles(dt: number) {
    const q = new THREE.Quaternion()
    const s = new THREE.Vector3()
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i]
      if (p.active) {
        p.life -= dt
        if (p.life <= 0) p.active = false
        else {
          p.v.y -= 22 * dt
          p.p.addScaledVector(p.v, dt)
          if (p.p.y < 0.08) { p.p.y = 0.08; p.v.y *= -0.35; p.v.x *= 0.7; p.v.z *= 0.7 }
          const sc = 0.25 + 0.75 * (p.life / p.max)
          s.setScalar(sc)
          this.tmpM.compose(p.p, q, s)
          this.pMesh.setMatrixAt(i, this.tmpM)
          continue
        }
      }
      s.setScalar(0)
      this.tmpM.makeScale(0, 0, 0)
      this.pMesh.setMatrixAt(i, this.tmpM)
    }
    this.pMesh.instanceMatrix.needsUpdate = true
  }
}
