import * as THREE from 'three';
import { buildWorld, WORLD, type Quality, type Surface, type WorldBuild } from './world';
import { buildRallyCar, buildTrafficCar, type CarBuild } from './vehicles';
import type { InputManager } from './input';

export interface HudData {
  speedKmh: number;
  region: string;
  surface: Surface;
  drifting: boolean;
  wrongWay?: boolean;
}

export interface EngineOptions {
  quality: Quality;
  carColor: string;
  input: InputManager;
  onHUD?: (h: HudData) => void;
  onProgress?: (p: number, label: string) => void;
}

interface TrafficCar {
  build: CarBuild;
  pathIndex: number;
  segT: number; // progress along current segment
  segIdx: number;
  dir: 1 | -1;
  speed: number;
  pos: THREE.Vector3;
  heading: number;
  stopTimer: number;
}

const SURFACE_PARAMS: Record<Surface, { grip: number; accel: number; max: number; drag: number }> = {
  asphalt: { grip: 8.5, accel: 1.0, max: 1.0, drag: 1.0 },
  sidewalk: { grip: 7.0, accel: 0.95, max: 0.9, drag: 1.05 },
  dirt: { grip: 4.6, accel: 0.8, max: 0.72, drag: 1.5 },
  grass: { grip: 3.1, accel: 0.6, max: 0.5, drag: 2.2 },
  sand: { grip: 2.7, accel: 0.55, max: 0.44, drag: 2.6 },
  water: { grip: 1.0, accel: 0.2, max: 0.1, drag: 5.0 },
};

export class RallyEngine {
  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private world: WorldBuild | null = null;
  private player: CarBuild | null = null;
  private traffic: TrafficCar[] = [];
  private clock = new THREE.Clock();
  private raf = 0;
  private running = false;
  private paused = false;
  private disposed = false;

  // car state
  pos = new THREE.Vector3(0, 0, -300);
  vel = new THREE.Vector3();
  heading = 0;
  steer = 0;
  speedFwd = 0;
  cameraShake = 0;
  cameraMode: 0 | 1 | 2 = 0; // 0 chase, 1 far, 2 hood
  drifting = false;
  surface: Surface = 'asphalt';
  region = 'شهر';

  private camPos = new THREE.Vector3(0, 5, -290);
  private hudTimer = 0;
  private elapsed = 0;
  private crashCooldown = 0;

  // audio
  private audioCtx: AudioContext | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  muted = false;

  constructor(private opts: EngineOptions) {
    this.camera = new THREE.PerspectiveCamera(68, 1, 0.3, 5000);
  }

  async init(container: HTMLElement): Promise<void> {
    const { quality } = this.opts;
    const antialias = quality !== 'low';
    this.renderer = new THREE.WebGLRenderer({ antialias, powerPreference: 'high-performance' });
    const dpr = Math.min(window.devicePixelRatio || 1, quality === 'low' ? 1.25 : quality === 'medium' ? 1.75 : 2);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    container.appendChild(this.renderer.domElement);

    this.world = await buildWorld(this.scene, quality, this.opts.onProgress);

    // player car
    this.player = buildRallyCar(this.opts.carColor, { detail: quality === 'low' ? 'low' : 'high' });
    this.scene.add(this.player.group);
    this.resetCar();

    // traffic
    this.spawnTraffic();

    // resize
    window.addEventListener('resize', this.handleResize);
    this.handleResize();

    // fog + background match
    this.scene.background = new THREE.Color(0x9ec3e6);
  }

  private handleResize = () => {
    if (!this.renderer) return;
    const el = this.renderer.domElement.parentElement;
    if (!el) return;
    const w = el.clientWidth;
    const h = el.clientHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  private spawnTraffic() {
    if (!this.world) return;
    const count = this.opts.quality === 'low' ? 7 : this.opts.quality === 'medium' ? 11 : 14;
    const colors = ['#e8e8ec', '#1c1f26', '#2a5fd2', '#c8a020', '#7a1fd2', '#0f9a6c', '#d2551f', '#8a93a3'];
    let ci = 0;
    for (let i = 0; i < count; i++) {
      const pathIndex = i % this.world.trafficPaths.length;
      const path = this.world.trafficPaths[pathIndex];
      // spread along path
      const segIdx = Math.floor((i / this.world.trafficPaths.length) * path.points.length) % Math.max(1, path.points.length - (path.loop ? 0 : 1));
      const kind = i % 4 === 3 ? 3 : i % 3;
      const color = kind === 3 ? '#f5c518' : colors[ci++ % colors.length];
      const build = buildTrafficCar(color, kind);
      this.scene.add(build.group);
      const a = path.points[segIdx % path.points.length];
      const b = path.points[(segIdx + 1) % path.points.length];
      const t = (i * 0.37) % 1;
      const pos = new THREE.Vector3().lerpVectors(a, b, t);
      pos.y = (path.elevated ? this.world.getGroundHeightAt(pos.x, pos.z) : 0) + 0.1;
      const heading = Math.atan2(-(b.x - a.x), -(b.z - a.z));
      build.group.position.copy(pos);
      build.group.rotation.y = heading;
      this.traffic.push({
        build,
        pathIndex,
        segIdx,
        segT: t,
        dir: 1,
        speed: path.speed * (0.85 + Math.random() * 0.3),
        pos: pos.clone(),
        heading,
        stopTimer: 0,
      });
    }
  }

  start() {
    if (this.running || this.disposed) return;
    this.running = true;
    this.paused = false;
    this.clock.start();
    this.initAudio();
    this.loop();
  }

  pause() {
    this.paused = true;
  }
  resume() {
    if (!this.running) return;
    this.paused = false;
    this.clock.getDelta();
  }

  resetCar() {
    this.pos.set(0, 0, -300);
    this.vel.set(0, 0, 0);
    this.heading = 0;
    this.steer = 0;
    this.speedFwd = 0;
    if (this.world) this.pos.y = this.world.getGroundHeightAt(this.pos.x, this.pos.z);
    if (this.player) {
      this.player.group.position.copy(this.pos);
      this.player.group.rotation.set(0, this.heading, 0);
    }
    this.camPos.set(this.pos.x, this.pos.y + 4, this.pos.z + 10);
  }

  /** Flip car back if stuck / return to road */
  recover() {
    // find nearest asphalt: sample spiral
    if (!this.world) return;
    for (let r = 0; r < 120; r += 6) {
      for (let a = 0; a < 12; a++) {
        const x = this.pos.x + Math.cos((a / 12) * Math.PI * 2) * r;
        const z = this.pos.z + Math.sin((a / 12) * Math.PI * 2) * r;
        if (this.world.getSurfaceAt(x, z) === 'asphalt') {
          this.pos.set(x, this.world.getGroundHeightAt(x, z), z);
          this.vel.set(0, 0, 0);
          this.speedFwd = 0;
          return;
        }
      }
    }
    this.resetCar();
  }

  setCarColor(c: string) {
    this.opts.carColor = c;
    this.player?.bodyMat.color.set(c);
  }

  toggleCamera() {
    this.cameraMode = ((this.cameraMode + 1) % 3) as 0 | 1 | 2;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.engineGain && this.audioCtx) {
      this.engineGain.gain.setTargetAtTime(m ? 0 : 0.06, this.audioCtx.currentTime, 0.1);
    }
  }

  private initAudio() {
    try {
      if (this.audioCtx) {
        if (this.audioCtx.state === 'suspended') void this.audioCtx.resume();
        return;
      }
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.audioCtx = new AC();
      this.engineGain = this.audioCtx.createGain();
      this.engineGain.gain.value = this.muted ? 0 : 0.05;
      this.engineFilter = this.audioCtx.createBiquadFilter();
      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.value = 900;
      this.engineOsc = this.audioCtx.createOscillator();
      this.engineOsc.type = 'sawtooth';
      this.engineOsc.frequency.value = 55;
      this.engineOsc2 = this.audioCtx.createOscillator();
      this.engineOsc2.type = 'square';
      this.engineOsc2.frequency.value = 28;
      const g2 = this.audioCtx.createGain();
      g2.gain.value = 0.4;
      this.engineOsc.connect(this.engineFilter);
      this.engineOsc2.connect(g2);
      g2.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.audioCtx.destination);
      this.engineOsc.start();
      this.engineOsc2.start();
    } catch {
      this.audioCtx = null;
    }
  }

  private updateAudio() {
    if (!this.audioCtx || !this.engineOsc || !this.engineOsc2 || !this.engineFilter || !this.engineGain) return;
    try {
      const spd = Math.abs(this.speedFwd);
      const input = this.opts.input.getState();
      const load = input.throttle;
      const rpm = 50 + spd * 5.5 + load * 30;
      const t = this.audioCtx.currentTime;
      this.engineOsc.frequency.setTargetAtTime(rpm, t, 0.08);
      this.engineOsc2.frequency.setTargetAtTime(rpm * 0.5 + 3, t, 0.08);
      this.engineFilter.frequency.setTargetAtTime(600 + spd * 40 + load * 900, t, 0.1);
      if (!this.muted) this.engineGain.gain.setTargetAtTime(0.035 + load * 0.05 + Math.min(0.03, spd * 0.0008), t, 0.1);
    } catch {
      /* ignore */
    }
  }

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const rawDt = Math.min(this.clock.getDelta(), 0.05);
    if (!this.paused) {
      this.elapsed += rawDt;
      this.update(rawDt);
    }
    if (this.renderer && this.world) {
      this.world.update(rawDt, this.elapsed, this.pos);
      this.renderer.render(this.scene, this.camera);
    }
  };

  private update(dt: number) {
    if (!this.world || !this.player) return;
    const input = this.opts.input.getState();
    this.surface = this.world.getSurfaceAt(this.pos.x, this.pos.z);
    this.region = this.world.getRegionAt(this.pos.x, this.pos.z);
    const P = SURFACE_PARAMS[this.surface];

    // --- steering smoothing ---
    const steerSpeed = input.steer === 0 ? 7 : 5;
    this.steer += (input.steer - this.steer) * Math.min(1, steerSpeed * dt);

    // --- speed integration ---
    const maxSpeed = 62 * P.max;
    const maxReverse = -13;
    const curSpeed = this.speedFwd;
    let accel = 0;
    if (input.throttle > 0) {
      const eff = Math.max(0, 1 - Math.max(0, curSpeed) / maxSpeed);
      accel += (26 * P.accel * (0.35 + 0.65 * eff) + 4) * input.throttle;
    }
    if (input.brake > 0) {
      if (curSpeed > 1.5) accel -= 44 * input.brake;
      else accel -= 14 * input.brake; // reverse
    }
    if (input.handbrake) {
      accel -= Math.sign(curSpeed) * 22;
    }
    // drag
    const drag = (0.28 * P.drag * Math.abs(curSpeed) + 0.012 * curSpeed * Math.abs(curSpeed)) * Math.sign(curSpeed);
    accel -= drag;
    // rolling stop
    if (input.throttle === 0 && input.brake === 0 && Math.abs(curSpeed) < 0.6) accel = -curSpeed / Math.max(dt, 0.001) * 0.9;

    this.speedFwd += accel * dt;
    this.speedFwd = Math.max(maxReverse, Math.min(maxSpeed * 1.15, this.speedFwd));

    // --- heading / yaw ---
    // Note: forward vector is (-sin(heading), -cos(heading)), so +heading turns LEFT (-X) and -heading turns RIGHT (+X).
    // Since input.steer is -1 for Left and +1 for Right, yawRate uses -this.steer so Left turns Left and Right turns Right.
    const spdAbs = Math.abs(this.speedFwd);
    const gripNow = input.handbrake ? P.grip * 0.28 : P.grip;
    const maxSteer = 0.62 - Math.min(1, spdAbs / 62) * 0.44;
    const yawRate = -this.steer * maxSteer * 2.4 * Math.min(1, spdAbs / 5) * (this.speedFwd >= 0 ? 1 : -1);
    this.heading += yawRate * dt;

    // --- velocity with lateral slide ---
    const fx = -Math.sin(this.heading);
    const fz = -Math.cos(this.heading);
    const fSpeed = this.vel.x * fx + this.vel.z * fz;
    let latX = this.vel.x - fx * fSpeed;
    let latZ = this.vel.z - fz * fSpeed;
    const latDecay = Math.exp(-gripNow * dt);
    latX *= latDecay;
    latZ *= latDecay;
    // blend forward speed toward target (tire slip)
    const newFSpeed = fSpeed + (this.speedFwd - fSpeed) * Math.min(1, (input.handbrake ? 3 : 8) * dt);
    this.vel.x = fx * newFSpeed + latX;
    this.vel.z = fz * newFSpeed + latZ;

    const latSpeed = Math.hypot(latX, latZ);
    this.drifting = latSpeed > 4.5 && spdAbs > 12;

    // --- integrate position ---
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;

    // --- collisions ---
    this.crashCooldown = Math.max(0, this.crashCooldown - dt);
    this.collide(dt);

    // --- ground height (hysteresis so ground roads pass UNDER the bridge deck) ---
    const rawH = this.world.getGroundHeightAt(this.pos.x, this.pos.z);
    let targetY = rawH;
    if (Math.abs(rawH - this.pos.y) > 2.5) {
      targetY = this.pos.y > 4 ? rawH : 0;
    }
    this.pos.y += (targetY - this.pos.y) * Math.min(1, 10 * dt);

    // --- apply to mesh ---
    const g = this.player.group;
    g.position.copy(this.pos);
    const roll = this.steer * Math.min(1, spdAbs / 40) * 0.09;
    const pitch = THREE.MathUtils.clamp(-accel * 0.0012, -0.05, 0.06);
    g.rotation.set(pitch, this.heading, roll, 'YXZ');

    // wheels (order 'YXZ' so rotation.y steers cleanly and rotation.x spins around axle)
    const spin = (newFSpeed / 0.42) * dt;
    this.player.wheels.forEach((w, i) => {
      if (i < 2) w.rotation.y = -this.steer * maxSteer;
      w.rotation.x -= spin;
    });
    // brake lights
    const braking = input.brake > 0 || input.handbrake;
    this.player.brakeLights.emissiveIntensity = braking ? 2.4 : 0.6;

    // --- traffic ---
    this.updateTraffic(dt);

    // --- camera ---
    this.updateCamera(dt);

    // --- audio ---
    this.updateAudio();

    // --- HUD ---
    this.hudTimer += dt;
    if (this.hudTimer > 0.12) {
      this.hudTimer = 0;
      this.opts.onHUD?.({
        speedKmh: Math.round(Math.abs(newFSpeed) * 3.6),
        region: this.region,
        surface: this.surface,
        drifting: this.drifting,
      });
    }
  }

  private collide(_dt: number) {
    if (!this.world) return;
    const R = 1.7;
    // bounds
    let hit = false;
    if (this.pos.x < WORLD.MIN_X + R) { this.pos.x = WORLD.MIN_X + R; this.vel.x = Math.abs(this.vel.x) * 0.3; hit = true; }
    if (this.pos.x > WORLD.MAX_X - R) { this.pos.x = WORLD.MAX_X - R; this.vel.x = -Math.abs(this.vel.x) * 0.3; hit = true; }
    if (this.pos.z < WORLD.MIN_Z + R) { this.pos.z = WORLD.MIN_Z + R; this.vel.z = Math.abs(this.vel.z) * 0.3; hit = true; }
    if (this.pos.z > WORLD.MAX_Z - R) { this.pos.z = WORLD.MAX_Z - R; this.vel.z = -Math.abs(this.vel.z) * 0.3; hit = true; }
    // bridge guard rails (only when actually driving on the deck)
    if (this.pos.y > 3.5 && Math.abs(this.pos.x) < 330 && Math.abs(this.pos.z + 150) < 12) {
      const edge = 8.2;
      const dz = this.pos.z + 150;
      if (dz > edge) {
        this.pos.z = -150 + edge;
        if (this.vel.z > 0) this.vel.z = -this.vel.z * 0.35;
        this.speedFwd *= 0.92;
        hit = true;
      } else if (dz < -edge) {
        this.pos.z = -150 - edge;
        if (this.vel.z < 0) this.vel.z = -this.vel.z * 0.35;
        this.speedFwd *= 0.92;
        hit = true;
      }
    }

    // building colliders (only near ones — linear scan is fine: ~250 boxes)
    for (const c of this.world.colliders) {
      // skip bridge pillar colliders when player is ON bridge (high)
      const onBridge = this.pos.y > 3;
      if (onBridge && c.maxX - c.minX < 5 && c.maxZ - c.minZ < 5) continue;
      const nx = Math.max(c.minX, Math.min(this.pos.x, c.maxX));
      const nz = Math.max(c.minZ, Math.min(this.pos.z, c.maxZ));
      const dx = this.pos.x - nx;
      const dz = this.pos.z - nz;
      const d2 = dx * dx + dz * dz;
      if (d2 < R * R) {
        if (d2 > 0.0001) {
          const d = Math.sqrt(d2);
          const push = R - d;
          this.pos.x += (dx / d) * push;
          this.pos.z += (dz / d) * push;
          // kill velocity into wall
          const vn = this.vel.x * (dx / d) + this.vel.z * (dz / d);
          if (vn < 0) {
            this.vel.x -= (dx / d) * vn * 1.4;
            this.vel.z -= (dz / d) * vn * 1.4;
            this.speedFwd *= 0.35;
            hit = true;
          }
        } else {
          // inside box: push along min axis
          const pl = this.pos.x - c.minX;
          const pr = c.maxX - this.pos.x;
          const pt = this.pos.z - c.minZ;
          const pb = c.maxZ - this.pos.z;
          const m = Math.min(pl, pr, pt, pb);
          if (m === pl) this.pos.x = c.minX - R;
          else if (m === pr) this.pos.x = c.maxX + R;
          else if (m === pt) this.pos.z = c.minZ - R;
          else this.pos.z = c.maxZ + R;
          this.vel.multiplyScalar(0.3);
          this.speedFwd *= 0.3;
          hit = true;
        }
      }
    }

    // tree colliders via grid
    const cx = Math.floor(this.pos.x / 40);
    const cz = Math.floor(this.pos.z / 40);
    for (let gx = cx - 1; gx <= cx + 1; gx++) {
      for (let gz = cz - 1; gz <= cz + 1; gz++) {
        const arr = this.world.treeGrid.get(`${gx},${gz}`);
        if (!arr) continue;
        for (const t of arr) {
          const dx = this.pos.x - t.x;
          const dz = this.pos.z - t.z;
          const rr = R * 0.8 + t.r;
          const d2 = dx * dx + dz * dz;
          if (d2 < rr * rr && d2 > 0.0001) {
            const d = Math.sqrt(d2);
            this.pos.x += (dx / d) * (rr - d);
            this.pos.z += (dz / d) * (rr - d);
            const vn = this.vel.x * (dx / d) + this.vel.z * (dz / d);
            if (vn < 0) {
              this.vel.x -= (dx / d) * vn * 1.5;
              this.vel.z -= (dz / d) * vn * 1.5;
              this.speedFwd *= 0.3;
              hit = true;
            }
          }
        }
      }
    }

    // traffic collision (circle)
    for (const t of this.traffic) {
      const dx = this.pos.x - t.pos.x;
      const dz = this.pos.z - t.pos.z;
      const dy = Math.abs(this.pos.y - t.pos.y);
      if (dy > 4) continue; // different level (bridge)
      const d2 = dx * dx + dz * dz;
      const rr = 3.4;
      if (d2 < rr * rr && d2 > 0.001) {
        const d = Math.sqrt(d2);
        const push = (rr - d) / 2;
        this.pos.x += (dx / d) * push;
        this.pos.z += (dz / d) * push;
        t.pos.x -= (dx / d) * push;
        t.pos.z -= (dz / d) * push;
        // exchange some velocity
        const relVx = this.vel.x;
        const relVz = this.vel.z;
        this.vel.x = relVx * 0.4;
        this.vel.z = relVz * 0.4;
        this.speedFwd *= 0.5;
        hit = true;
      }
    }

    if (hit && this.crashCooldown <= 0) {
      const impact = Math.hypot(this.vel.x, this.vel.z);
      this.cameraShake = Math.min(1.2, 0.25 + impact * 0.03);
      this.crashCooldown = 0.25;
    }
  }

  private updateTraffic(dt: number) {
    if (!this.world) return;
    for (const t of this.traffic) {
      const path = this.world.trafficPaths[t.pathIndex];
      const pts = path.points;
      const n = pts.length;
      const nextIdx = t.dir === 1 ? (t.segIdx + 1) % n : (t.segIdx - 1 + n) % n;
      // for non-loop ping-pong
      let a = pts[t.segIdx % n];
      let b = pts[nextIdx % n];
      if (!path.loop) {
        if (t.dir === 1 && t.segIdx >= n - 1) {
          t.dir = -1;
          t.segIdx = n - 1;
          a = pts[n - 1];
          b = pts[n - 2];
        } else if (t.dir === -1 && t.segIdx <= 0) {
          t.dir = 1;
          t.segIdx = 0;
          a = pts[0];
          b = pts[1];
        } else {
          a = pts[t.segIdx];
          b = pts[t.dir === 1 ? t.segIdx + 1 : t.segIdx - 1];
        }
      }
      const segLen = Math.max(1, Math.hypot(b.x - a.x, b.z - a.z));

      // slow if player ahead
      const toPlayerX = this.pos.x - t.pos.x;
      const toPlayerZ = this.pos.z - t.pos.z;
      const distP = Math.hypot(toPlayerX, toPlayerZ);
      const fx = -Math.sin(t.heading);
      const fz = -Math.cos(t.heading);
      const ahead = toPlayerX * fx + toPlayerZ * fz;
      let targetSpeed = t.speed;
      if (distP < 16 && ahead > 0 && Math.abs(this.pos.y - t.pos.y) < 4) {
        targetSpeed = distP < 8 ? 0 : t.speed * (distP - 8) / 8;
      }
      t.stopTimer += ((targetSpeed > 0.5 ? 0 : 1) - t.stopTimer) * Math.min(1, 4 * dt);
      const spd = targetSpeed;

      t.segT += (spd * dt) / segLen;
      if (t.segT >= 1) {
        t.segT = 0;
        if (path.loop) {
          t.segIdx = nextIdx;
        } else {
          t.segIdx = t.dir === 1 ? t.segIdx + 1 : t.segIdx - 1;
          if (t.segIdx >= n - 1) { t.segIdx = n - 1; t.dir = -1; }
          if (t.segIdx <= 0) { t.segIdx = 0; t.dir = 1; }
        }
      }
      // recompute a,b after possible advance
      if (path.loop) {
        a = pts[t.segIdx % n];
        b = pts[(t.segIdx + 1) % n];
      } else {
        const ni = t.dir === 1 ? Math.min(n - 1, t.segIdx + 1) : Math.max(0, t.segIdx - 1);
        a = pts[t.segIdx];
        b = pts[ni];
      }
      t.pos.lerpVectors(a, b, t.segT);
      const gh = this.world.getGroundHeightAt(t.pos.x, t.pos.z) + 0.1;
      if (Math.abs(gh - t.pos.y) < 2.5) {
        t.pos.y += (gh - t.pos.y) * Math.min(1, 8 * dt);
      }
      // heading smoothing
      const want = Math.atan2(-(b.x - a.x), -(b.z - a.z));
      let diff = want - t.heading;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      t.heading += diff * Math.min(1, 3.5 * dt);
      t.build.group.position.copy(t.pos);
      t.build.group.rotation.y = t.heading;
      // wheels spin
      const spin = (spd / 0.38) * dt;
      for (const w of t.build.wheels) w.rotateX(spin);
      t.build.brakeLights.emissiveIntensity = targetSpeed < 1 ? 2.2 : 0.4;
    }
  }

  private updateCamera(dt: number) {
    const spd = Math.hypot(this.vel.x, this.vel.z);
    const fx = -Math.sin(this.heading);
    const fz = -Math.cos(this.heading);

    this.cameraShake = Math.max(0, this.cameraShake - dt * 2.2);
    const shakeX = (Math.random() - 0.5) * this.cameraShake * 0.5;
    const shakeY = (Math.random() - 0.5) * this.cameraShake * 0.4;

    if (this.cameraMode === 2) {
      // hood cam
      const hx = this.pos.x + fx * 0.6;
      const hz = this.pos.z + fz * 0.6;
      this.camera.position.set(hx + shakeX * 0.3, this.pos.y + 1.55, hz);
      this.camera.lookAt(this.pos.x + fx * 30, this.pos.y + 1.0, this.pos.z + fz * 30);
      this.camera.fov += ((70 + spd * 0.25) - this.camera.fov) * Math.min(1, 5 * dt);
      this.camera.updateProjectionMatrix();
      return;
    }

    const dist = this.cameraMode === 1 ? 12.5 + spd * 0.05 : 8.2 + spd * 0.045;
    const height = this.cameraMode === 1 ? 5.2 + spd * 0.012 : 3.3 + spd * 0.014;
    // slight lateral offset with steering for feel
    const sideX = -fz;
    const sideZ = fx;
    const desired = new THREE.Vector3(
      this.pos.x - fx * dist + sideX * this.steer * 0.8,
      this.pos.y + height,
      this.pos.z - fz * dist + sideZ * this.steer * 0.8
    );
    // keep camera above ground/bridge
    if (this.world) {
      const gy = this.world.getGroundHeightAt(desired.x, desired.z) + 1.2;
      if (desired.y < gy) desired.y = gy;
    }
    const k = 1 - Math.exp(-6 * dt);
    this.camPos.lerp(desired, k);
    this.camera.position.set(this.camPos.x + shakeX, this.camPos.y + shakeY, this.camPos.z);
    const look = new THREE.Vector3(this.pos.x + fx * 5, this.pos.y + 1.3, this.pos.z + fz * 5);
    this.camera.lookAt(look);
    const targetFov = 66 + Math.min(22, spd * 0.42) + (this.drifting ? 4 : 0);
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, 4 * dt);
    this.camera.updateProjectionMatrix();
  }

  getTrafficPositions(): { x: number; z: number }[] {
    return this.traffic.map((t) => ({ x: t.pos.x, z: t.pos.z }));
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.handleResize);
    try {
      this.engineOsc?.stop();
      this.engineOsc2?.stop();
      void this.audioCtx?.close();
    } catch {
      /* ignore */
    }
    this.traffic.forEach((t) => this.scene.remove(t.build.group));
    if (this.player) this.scene.remove(this.player.group);
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
  }
}
