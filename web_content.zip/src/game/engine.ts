import * as THREE from "three";
import { CATALOG } from "./catalog";
import { Input } from "./input";
import {
  disposeObject,
  makeBlackHole,
  makeCoreSprite,
  makeGalaxyGeometry,
  makeDustGeometry,
  makeHIIField,
  makeDimensionField,
  makeGlowTexture,
  makeShip,
  makeStarfield,
  POINT_MAT_PARAMS,
} from "./visuals";
import { isDiscovered, useGameStore } from "./store";
import { sfxScan, sfxWarp, sfxWarn, pulseDrone } from "./audio";
import type { Celestial, Marker, TouchState } from "./types";

const WORLD = 760;
const CRUISE = 34;
const BOOST_SPD = 82;
const TURN = 2.15;
const PITCH_RATE = 1.55;
const SCAN_RANGE = 16;
const DIVE_RANGE = 8;
const SAMPLE_RANGE = 1.35;
const TRAIL_N = 40;
const QUALITY = [
  { bg: 7000, field: 10500, dust: 2400, hii: 700, dpr: 1.18 },
  { bg: 4400, field: 6800, dust: 1500, hii: 460, dpr: 1.02 },
  { bg: 2400, field: 3600, dust: 800, hii: 240, dpr: 0.86 },
];

function damp(a: number, b: number, k: number, dt: number) {
  return a + (b - a) * (1 - Math.exp(-k * dt));
}

export class AtlasEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(62, 1, 0.25, 1400);
  private input = new Input();
  private ship = makeShip();
  private pos = new THREE.Vector3();
  private vel = new THREE.Vector3();
  private yaw = 0;
  private pitch = 0.12;
  private speed = 0;
  private hull = 1;
  private boost = 1;
  private elapsed = 0;
  private last = 0;
  private acc = 0;
  private hudAcc = 0;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private fps = 60;
  private quality = 0;
  private slow = 0;
  private fast = 0;
  private cool = 3;
  private phase: "attract" | "play" | "pause" | "complete" = "attract";
  private targetId: number | null = 0;
  private nearest = 0;
  private warpT = 0;
  private warpFrom = new THREE.Vector3();
  private warpDest = new THREE.Vector3();
  private warpActive = false;
  private scanHold = 0;
  private lastWarn = 0;
  private shake = 0;
  private reduced = false;
  private glowTex: THREE.Texture;
  private starfield: THREE.Points;
  private cores: THREE.Group;
  private field: THREE.Group | null = null;
  private fieldId = -1;
  private blackHoles: { id: number; group: THREE.Group }[] = [];
  private samples: { pos: THREE.Vector3; taken: boolean; home: number; phase: number }[] = [];
  private sampleMesh: THREE.InstancedMesh;
  private trail: THREE.InstancedMesh;
  private trailBuf: THREE.Vector3[] = [];
  private tmp = new THREE.Vector3();
  private tmp2 = new THREE.Vector3();
  private tmp3 = new THREE.Vector3();
  private fwd = new THREE.Vector3();
  private dummy = new THREE.Object3D();
  private sampleColor = new THREE.Color(0xb8dcff);
  private pointMat: THREE.PointsMaterial;
  private dustMat: THREE.PointsMaterial;
  private hiiMat: THREE.PointsMaterial;
  private running = false;
  private canvas: HTMLCanvasElement;
  private ro: ResizeObserver | null = null;
  private starMat: THREE.PointsMaterial;
  private dimensionField: THREE.Points;
  private dimensionMat: THREE.ShaderMaterial;
  private dimension = 0;
  private wSlice = 0;
  private vPhase = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setClearColor(0x05070c, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setPixelRatio(this.dpr());
    this.scene.fog = new THREE.FogExp2(0x05070c, 0.00155);
    this.glowTex = makeGlowTexture(64);
    this.pointMat = new THREE.PointsMaterial({
      ...POINT_MAT_PARAMS,
      map: this.glowTex,
      size: 0.10,
    });
    this.dustMat = new THREE.PointsMaterial({
      size: 0.13,
      vertexColors: true,
      transparent: true,
      opacity: 0.66,
      depthWrite: false,
      blending: THREE.NormalBlending,
      sizeAttenuation: true,
    });
    this.hiiMat = new THREE.PointsMaterial({
      size: 0.14,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      map: this.glowTex,
      sizeAttenuation: true,
    });

    const q = QUALITY[this.quality];
    this.starMat = new THREE.PointsMaterial({
      size: 2.4,
      vertexColors: true,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: 0.9,
      sizeAttenuation: false,
      map: this.glowTex,
    });
    this.starfield = new THREE.Points(makeStarfield(q.bg, 900), this.starMat);
    this.starfield.frustumCulled = false;
    this.scene.add(this.starfield);

    const dimensionGeo = makeDimensionField(1800);
    this.dimensionMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uMode: { value: 0 }, uW: { value: 0 }, uV: { value: 0 } },
      vertexShader: `attribute vec4 aBase; uniform float uTime; uniform float uMode; uniform float uW; uniform float uV; varying float vGlow; void main(){ vec3 p=aBase.xyz; float extra=aBase.w; float t=uTime*.32+extra*6.28318; float mode=uMode; if(mode>0.5){ float w=sin(extra+uW*3.14+t); p*=1.0+0.18*w; p.y += 7.0*w; } if(mode>1.5){ float q=cos(extra*2.0+t+uW*4.0); p.xz*=1.0+0.22*q; p.y+=sin(t*1.7+uV*4.0)*5.0*q; } if(mode>2.5){ float ph=sin(t*2.0+uV*6.0); p.z += ph*12.0*(0.2+abs(aBase.y)); } if(mode>3.5){ vec3 cube=step(0.0, sin(vec3(extra*6.0+t,extra*7.0+t*1.3,extra*5.0-t)))-0.5; p = mix(p*0.55, cube*48.0, 0.62); } if(mode>4.5){ float q=sin(extra*8.0+t+uW*6.0); p += vec3(q*cos(t), sin(t*1.3+extra*5.0), q*sin(t))*10.0; p*=1.0+0.25*sin(t*2.0+uV*5.0); } vGlow=.5+.5*sin(t*1.7); vec4 mv=modelViewMatrix*vec4(p,1.0); gl_Position=projectionMatrix*mv; gl_PointSize=(2.0+2.0*vGlow)/max(1.0,-mv.z*.035); }`,
      fragmentShader: `varying float vGlow; void main(){ vec2 q=gl_PointCoord-.5; float r=dot(q,q); if(r>.25) discard; float a=smoothstep(.25,0.0,r)*(0.22+vGlow*.35); gl_FragColor=vec4(0.44,0.72,1.0,a); }`,
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false,
    });
    this.dimensionField = new THREE.Points(dimensionGeo, this.dimensionMat);
    this.dimensionField.frustumCulled = false;
    this.dimensionField.visible = false;
    this.scene.add(this.dimensionField);

    this.cores = new THREE.Group();
    this.scene.add(this.cores);
    for (const body of CATALOG) {
      const node = new THREE.Group();
      node.position.set(body.pos[0], body.pos[1], body.pos[2]);
      node.userData.id = body.id;
      if (body.kind === "blackhole") {
        const bh = makeBlackHole(body);
        node.add(bh);
        this.blackHoles.push({ id: body.id, group: bh });
      } else {
        const sprite = makeCoreSprite(body.colorA, this.glowTex);
        sprite.scale.setScalar(5.5 + body.radius * 1.3);
        node.add(sprite);
        const inner = makeCoreSprite(body.colorB, this.glowTex);
        inner.scale.setScalar(3.5 + body.radius * 0.55);
        node.add(inner);
      }
      this.cores.add(node);
    }

    const sGeo = new THREE.SphereGeometry(0.22, 8, 6);
    const sMat = new THREE.MeshBasicMaterial({ color: 0xcfe8ff, transparent: true, opacity: 0.9 });
    this.sampleMesh = new THREE.InstancedMesh(sGeo, sMat, 64);
    this.sampleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.sampleMesh.frustumCulled = false;
    this.scene.add(this.sampleMesh);
    this.seedSamples();

    const tGeo = new THREE.SphereGeometry(0.06, 6, 4);
    const tMat = new THREE.MeshBasicMaterial({
      color: 0x9ec4e8,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.trail = new THREE.InstancedMesh(tGeo, tMat, TRAIL_N);
    this.trail.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.trail.frustumCulled = false;
    this.scene.add(this.trail);
    for (let i = 0; i < TRAIL_N; i++) this.trailBuf.push(new THREE.Vector3());

    this.sampleMesh.count = 0;
    this.trail.count = 0;
    this.ship.visible = false;
    this.scene.add(this.ship);

    const mw = CATALOG[0];
    this.pos.set(mw.pos[0], mw.pos[1] + 4, mw.pos[2] + 22);
    this.camera.position.set(0, 36, 160);
    this.camera.lookAt(0, 0, 0);

    this.input.attach();
    this.resize();
    this.bindProbe();
    addEventListener("resize", this.onResize);
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this.canvas);
    this.last = performance.now();
    this.running = true;
    this.renderer.setAnimationLoop(this.tick);
  }

  private dpr() {
    const cap = QUALITY[this.quality].dpr;
    const raw = typeof devicePixelRatio === "number" ? devicePixelRatio : 1;
    return Math.min(raw, cap);
  }

  private onResize = () => this.resize();

  resize() {
    const w = this.canvas.clientWidth || innerWidth;
    const h = this.canvas.clientHeight || innerHeight;
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(this.dpr());
    this.renderer.setSize(w, h, false);
  }

  startExpedition() {
    this.phase = "play";
    this.ship.visible = true;
    this.hull = 1;
    this.boost = 1;
    const mw = CATALOG[0];
    this.pos.set(mw.pos[0], mw.pos[1] + 3.5, mw.pos[2] + 18);
    this.vel.set(0, 0, 0);
    this.yaw = 0;
    this.pitch = 0.08;
    this.speed = 0;
    this.targetId = 0;
    const f = this.forward();
    this.camera.position.copy(this.pos).addScaledVector(f, -11.5);
    this.camera.position.y += 3.4;
    this.camera.lookAt(this.pos);
    this.trail.count = TRAIL_N;
    useGameStore.getState().setPhase("play");
  }

  setPaused(paused: boolean) {
    if (this.phase === "attract") return;
    this.phase = paused ? "pause" : "play";
    useGameStore.getState().setPhase(this.phase);
  }

  togglePause() {
    if (this.phase === "play") this.setPaused(true);
    else if (this.phase === "pause") this.setPaused(false);
  }

  setTouch(next: Partial<TouchState>) {
    this.input.setTouch(next);
  }

  warpTo(id: number) {
    if ((this.phase !== "play" && this.phase !== "complete") || this.warpActive) return;
    const body = CATALOG[id];
    if (!body) return;
    this.targetId = id;
    this.warpFrom.copy(this.pos);
    const [x, y, z] = body.pos;
    this.tmp.set(x, y, z);
    this.tmp2.copy(this.pos).sub(this.tmp);
    if (this.tmp2.lengthSq() < 1) this.tmp2.set(0, 0, 1);
    this.tmp2.normalize().multiplyScalar(body.kind === "blackhole" ? 18 : 14);
    this.warpDest.copy(this.tmp).add(this.tmp2);
    this.warpActive = true;
    this.warpT = 0;
    sfxWarp();
    useGameStore.getState().recordWarp();
  }

  setTarget(id: number | null) {
    this.targetId = id;
  }

  setDimension(mode: number) {
    this.dimension = Math.max(0, Math.min(5, Math.round(mode)));
    this.dimensionField.visible = this.dimension > 0;
    this.dimensionMat.uniforms.uMode.value = this.dimension;
    useGameStore.getState().patchHud({ dimension: this.dimension });
  }

  setDimensionSlice(w: number, v: number) {
    this.wSlice = Math.max(-1, Math.min(1, w));
    this.vPhase = Math.max(-1, Math.min(1, v));
    this.dimensionMat.uniforms.uW.value = this.wSlice;
    this.dimensionMat.uniforms.uV.value = this.vPhase;
    useGameStore.getState().patchHud({ wSlice: this.wSlice, vPhase: this.vPhase });
  }

  private bindProbe() {
    window.__controlsTest = {
      getYaw: () => this.yaw,
      getSpeed: () => this.speed,
      setSteer: (v) => this.input.setSteer(v),
      setKeys: (codes) => this.input.setKeys(codes),
    };
  }

  private seedSamples() {
    this.samples = [];
    for (const body of CATALOG) {
      if (body.kind === "blackhole") continue;
      const n = 2;
      for (let k = 0; k < n; k++) {
        this.samples.push({
          pos: new THREE.Vector3(),
          taken: false,
          home: body.id,
          phase: Math.random() * Math.PI * 2,
        });
      }
    }
  }

  private forward() {
    const cp = Math.cos(this.pitch);
    this.fwd.set(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp);
    return this.fwd;
  }

  private nearestBody() {
    let best = 0;
    let bestD = Infinity;
    for (const b of CATALOG) {
      const d = this.tmp.set(b.pos[0], b.pos[1], b.pos[2]).sub(this.pos).length();
      if (d < bestD) {
        bestD = d;
        best = b.id;
      }
    }
    return { id: best, dist: bestD, body: CATALOG[best] };
  }

  private localScale(body: Celestial) {
    return 1.15 + body.radius * 0.42;
  }

  private ensureField(id: number) {
    if (this.fieldId === id) return;
    if (this.field) {
      this.scene.remove(this.field);
      this.field.traverse((o) => {
        const p = o as THREE.Points;
        if (p.geometry) p.geometry.dispose();
      });
      this.field = null;
    }
    this.fieldId = id;
    const body = CATALOG[id];
    if (!body || body.kind === "blackhole") return;

    const group = new THREE.Group();
    group.position.set(body.pos[0], body.pos[1], body.pos[2]);
    const stars = new THREE.Points(makeGalaxyGeometry(body, QUALITY[this.quality].field), this.pointMat);
    stars.renderOrder = 1;
    stars.frustumCulled = false;

    const dust = new THREE.Points(makeDustGeometry(body, Math.round(QUALITY[this.quality].dust * Math.max(0.25, body.morphology.dust))), this.dustMat);
    dust.renderOrder = 3;
    dust.frustumCulled = false;

    const hii = new THREE.Points(makeHIIField(body, Math.max(40, Math.round(QUALITY[this.quality].hii * Math.max(0.2, body.morphology.starburst)))), this.hiiMat);
    hii.renderOrder = 4;
    hii.frustumCulled = false;

    const s = this.localScale(body);
    group.scale.setScalar(s);
    group.add(stars, dust, hii);
    group.userData.bodyId = id;
    if (/edgeOn/.test(body.kind) || body.morphology.edgeOn) group.rotation.x = 1.15;
    if (body.recipeId != null) group.rotation.z += (body.recipeId % 7 - 3) * 0.045;
    this.scene.add(group);
    this.field = group;
  }

  private dropField() {
    if (!this.field) return;
    this.scene.remove(this.field);
    this.field.traverse((o) => {
      const p = o as THREE.Points;
      if (p.geometry) p.geometry.dispose();
    });
    this.field = null;
    this.fieldId = -1;
  }

  private tick = (now: number) => {
    if (!this.running) return;
    const raw = Math.max(0, (now - this.last) / 1000);
    this.last = now;
    const dt = Math.min(raw, 0.1);
    this.elapsed += dt;

    if (this.phase === "pause") {
      this.renderer.render(this.scene, this.camera);
      this.pushHud(dt);
      return;
    }

    if (this.phase === "attract") {
      this.updateAttract(dt);
    } else {
      this.acc += dt;
      const step = 1 / 60;
      let guard = 0;
      while (this.acc >= step && guard++ < 6) {
        this.fixed(step);
        this.acc -= step;
      }
      this.updateVisuals(dt);
    }

    if (raw < 0.5) {
      this.fpsFrames++;
      this.fpsAcc += raw;
    }
    if (this.fpsAcc > 1) {
      this.fps = this.fpsFrames / this.fpsAcc;
      this.fpsFrames = 0;
      this.fpsAcc = 0;
      this.adapt();
    }

    this.renderer.render(this.scene, this.camera);
    this.pushHud(dt);
  };

  private adapt() {
    if (this.elapsed < this.cool) {
      this.slow = 0;
      this.fast = 0;
      return;
    }
    if (this.fps < 38) {
      this.fast = 0;
      if (++this.slow >= 2 && this.quality < 2) {
        this.quality++;
        this.slow = 0;
        this.cool = this.elapsed + 4;
        this.applyQuality();
      }
    } else if (this.fps > 56 && this.quality > 0) {
      this.slow = 0;
      if (++this.fast >= 8) {
        this.quality--;
        this.fast = 0;
        this.cool = this.elapsed + 8;
        this.applyQuality();
      }
    } else {
      this.slow = 0;
      this.fast = 0;
    }
  }

  private applyQuality() {
    this.starfield.geometry.dispose();
    this.starfield.geometry = makeStarfield(QUALITY[this.quality].bg, 900);
    if (this.fieldId >= 0) {
      const keep = this.fieldId;
      this.dropField();
      this.ensureField(keep);
    }
    this.resize();
  }

  private updateAttract(dt: number) {
    const t = this.elapsed;
    this.camera.position.set(Math.sin(t * 0.11) * 170, 42 + Math.sin(t * 0.07) * 18, Math.cos(t * 0.11) * 170);
    this.camera.lookAt(0, 0, 0);
    this.starfield.rotation.y += dt * 0.012;
    this.spinDisks();
  }

  private spinDisks() {
    for (const bh of this.blackHoles) {
      const disk = bh.group.getObjectByName("disk") as THREE.Mesh | undefined;
      const mat = disk?.material as THREE.ShaderMaterial | undefined;
      if (mat?.uniforms?.uTime) mat.uniforms.uTime.value = this.elapsed;
      bh.group.rotation.y = this.elapsed * 0.08;
    }
    if (this.field) { this.field.rotation.y += 0.006; }
  }

  private fixed(dt: number) {
    const act = this.input.sample();
    if (this.input.pauseEdge) this.togglePause();
    if (this.input.catalogEdge) {
      useGameStore.getState().setCatalogOpen(!useGameStore.getState().catalogOpen);
    }
    if (this.input.muteEdge) useGameStore.getState().toggleMute();
    if (this.input.dimensionEdge) this.setDimension(this.dimension >= 5 ? 0 : this.dimension + 1);
    if (this.phase !== "play" && this.phase !== "complete") return;
    if (this.input.warpEdge) {
      const dest = this.targetId ?? this.nearest;
      this.warpTo(dest);
    }

    if (this.warpActive) {
      this.warpT += dt / 1.35;
      const t = Math.min(1, this.warpT);
      const k = t * t * (3 - 2 * t);
      this.pos.lerpVectors(this.warpFrom, this.warpDest, k);
      this.vel.set(0, 0, 0);
      this.speed = 0;
      if (t >= 1) this.warpActive = false;
    } else {
      this.yaw += act.steer * TURN * dt;
      this.pitch += act.pitch * PITCH_RATE * dt;
      this.pitch = Math.max(-1.15, Math.min(1.15, this.pitch));

      const boosting = act.boost && this.boost > 0.05 && act.throttle > 0;
      if (boosting) this.boost = Math.max(0, this.boost - dt * 0.28);
      else this.boost = Math.min(1, this.boost + dt * 0.16);

      const cap = boosting ? BOOST_SPD : CRUISE;
      const thrust = act.throttle * cap * 1.8;
      const f = this.forward();
      this.vel.addScaledVector(f, thrust * dt);
      this.vel.multiplyScalar(Math.exp(-2.4 * dt));

      this.applyGravity(dt);

      this.pos.addScaledVector(this.vel, dt);
      this.speed = this.vel.length();

      const r = this.pos.length();
      if (r > WORLD) {
        this.pos.multiplyScalar(WORLD / r);
        this.vel.multiplyScalar(0.4);
      }
    }

    this.handleScan(act.scan, dt);
    this.collectSamples();
    this.updateFieldLod();
    this.spinDisks();
  }

  private applyGravity(dt: number) {
    let danger = 0;
    for (const body of CATALOG) {
      if (body.kind !== "blackhole") continue;
      this.tmp.set(body.pos[0], body.pos[1], body.pos[2]);
      this.tmp2.copy(this.tmp).sub(this.pos);
      const d = this.tmp2.length();
      const rs = 2.2 + body.radius * 0.55;
      if (d < 55) {
        const pull = (38 * body.radius) / Math.max(4, d * d);
        this.vel.addScaledVector(this.tmp2.normalize(), pull * dt);
        danger = Math.max(danger, 1 - d / 55);
        if (d < rs) {
          this.hull = Math.max(0, this.hull - dt * 0.85);
          this.shake = Math.min(1, this.shake + dt * 2.4);
          if (this.elapsed - this.lastWarn > 0.7) {
            sfxWarn();
            this.lastWarn = this.elapsed;
          }
          if (this.hull <= 0) this.emergencyExtract(body);
        } else if (d < rs * 2.4) {
          this.hull = Math.max(0.12, this.hull - dt * 0.08);
          this.shake = Math.min(1, this.shake + dt * 0.9);
        }
      }
    }
    if (danger < 0.05) this.hull = Math.min(1, this.hull + dt * 0.04);
    pulseDrone(danger);
  }

  private emergencyExtract(body: Celestial) {
    this.tmp.set(body.pos[0], body.pos[1], body.pos[2]);
    this.tmp2.copy(this.pos).sub(this.tmp).normalize().multiplyScalar(28);
    this.pos.copy(this.tmp).add(this.tmp2);
    this.vel.set(0, 0, 0);
    this.hull = 0.45;
    this.shake = 0.8;
    useGameStore.getState().toast("EMERGENCY EXTRACT", "Pulled clear of the event horizon");
  }

  private handleScan(holding: boolean, dt: number) {
    const n = this.nearestBody();
    this.nearest = n.id;
    const inRange = n.dist < SCAN_RANGE + n.body.radius;
    if (holding && inRange) this.scanHold += dt;
    else this.scanHold = Math.max(0, this.scanHold - dt * 2);
    if (this.scanHold > 0.55 && inRange) {
      this.scanHold = 0;
      const dive = n.body.kind !== "blackhole" && n.dist < DIVE_RANGE + n.body.radius * 0.25;
      sfxScan();
      useGameStore.getState().recordScan(n.id, dive, n.body.kind === "blackhole");
      this.shake = Math.min(1, this.shake + 0.18);
    }
  }

  private collectSamples() {
    for (const s of this.samples) {
      if (s.taken) continue;
      if (!isDiscovered(s.home)) continue;
      if (s.pos.distanceTo(this.pos) < SAMPLE_RANGE) {
        s.taken = true;
        useGameStore.getState().collectSample();
      }
    }
  }

  private updateFieldLod() {
    const n = this.nearestBody();
    if (n.dist < 70 && n.body.kind !== "blackhole") this.ensureField(n.id);
    else if (n.dist > 90) this.dropField();
  }

  private updateVisuals(dt: number) {
    const f = this.forward();
    for (const bh of this.blackHoles) {
      const disk = bh.group.getObjectByName("disk") as THREE.Mesh | undefined;
      const jet = bh.group.getObjectByName("jet") as THREE.Mesh | undefined;
      if (disk) disk.lookAt(this.camera.position);
      if (jet) jet.lookAt(this.camera.position);
    }
    this.ship.position.copy(this.pos);
    this.tmp.copy(this.pos).add(f);
    this.ship.lookAt(this.tmp);
    const engine = this.ship.getObjectByName("engine") as THREE.Mesh | undefined;
    if (engine) {
      const mat = engine.material as THREE.MeshBasicMaterial;
      const glow = 0.45 + Math.min(1, this.speed / BOOST_SPD) * 0.55;
      mat.color.setRGB(0.55 * glow, 0.78 * glow, 1);
      engine.scale.setScalar(0.8 + glow * 0.7);
    }

    const follow = this.reduced ? 14 : 10;
    this.tmp.copy(this.pos).addScaledVector(f, -11.5);
    this.tmp.y += 3.4;
    this.camera.position.x = damp(this.camera.position.x, this.tmp.x, follow, dt);
    this.camera.position.y = damp(this.camera.position.y, this.tmp.y, follow, dt);
    this.camera.position.z = damp(this.camera.position.z, this.tmp.z, follow, dt);
    this.tmp2.copy(this.pos).addScaledVector(f, 6);
    if (this.shake > 0 && !this.reduced) {
      const mag = this.shake * this.shake * 0.45;
      this.camera.position.x += (Math.random() - 0.5) * mag;
      this.camera.position.y += (Math.random() - 0.5) * mag;
      this.shake = Math.max(0, this.shake - dt * 1.8);
    }
    this.camera.lookAt(this.tmp2);
    this.camera.fov = damp(this.camera.fov, this.warpActive ? 78 : 62 + Math.min(8, this.speed * 0.08), 6, dt);
    this.camera.updateProjectionMatrix();

    this.trailBuf[Math.floor(this.elapsed * 48) % TRAIL_N]?.copy(this.pos);
    if (Math.floor(this.elapsed * 48) !== Math.floor((this.elapsed - dt) * 48)) {
      this.trailBuf[Math.floor(this.elapsed * 48) % TRAIL_N].copy(this.pos);
    }
    for (let i = 0; i < TRAIL_N; i++) {
      const p = this.trailBuf[i];
      this.dummy.position.copy(p);
      const s = 0.4 + ((i % 7) * 0.08);
      this.dummy.scale.setScalar(s);
      this.dummy.updateMatrix();
      this.trail.setMatrixAt(i, this.dummy.matrix);
    }
    this.trail.instanceMatrix.needsUpdate = true;

    let si = 0;
    for (const s of this.samples) {
      const home = CATALOG[s.home];
      const orbit = 7 + (s.home % 5) * 0.45;
      const a = this.elapsed * 0.55 + s.phase;
      s.pos.set(
        home.pos[0] + Math.cos(a) * orbit,
        home.pos[1] + Math.sin(a * 1.4) * 1.6,
        home.pos[2] + Math.sin(a) * orbit,
      );
      this.dummy.position.copy(s.pos);
      this.dummy.scale.setScalar(s.taken || !isDiscovered(s.home) ? 0.0001 : 1);
      this.dummy.updateMatrix();
      this.sampleMesh.setMatrixAt(si, this.dummy.matrix);
      this.sampleMesh.setColorAt?.(si, this.sampleColor);
      si++;
    }
    this.sampleMesh.count = si;
    this.sampleMesh.instanceMatrix.needsUpdate = true;
    if (this.sampleMesh.instanceColor) this.sampleMesh.instanceColor.needsUpdate = true;

    this.starfield.rotation.y += dt * 0.004;
    if (this.dimensionField.visible) {
      const nearest = this.nearestBody();
      this.dimensionField.position.set(nearest.body.pos[0], nearest.body.pos[1], nearest.body.pos[2]);
      this.dimensionField.rotation.y += dt * (0.025 + this.dimension * 0.012);
      this.dimensionField.rotation.x = Math.sin(this.elapsed * 0.11) * 0.12;
      this.dimensionMat.uniforms.uTime.value = this.elapsed;
      this.dimensionMat.uniforms.uMode.value = this.dimension;
      this.dimensionMat.uniforms.uW.value = this.wSlice;
      this.dimensionMat.uniforms.uV.value = this.vPhase;
    }
  }

  private pushHud(dt: number) {
    this.hudAcc += dt;
    if (this.hudAcc < 0.08) return;
    this.hudAcc = 0;
    const n = this.nearestBody();
    const w = this.canvas.clientWidth || innerWidth;
    const h = this.canvas.clientHeight || innerHeight;
    const markers: Marker[] = [];
    for (const b of CATALOG) {
      this.tmp.set(b.pos[0], b.pos[1], b.pos[2]);
      const dist = this.tmp.distanceTo(this.pos);
      if (dist > 160 && b.id !== this.targetId) continue;
      this.tmp.project(this.camera);
      const off = this.tmp.z > 1 || this.tmp.x < -1.15 || this.tmp.x > 1.15 || this.tmp.y < -1.15 || this.tmp.y > 1.15;
      markers.push({
        id: b.id,
        name: b.name,
        kind: b.kind,
        x: (this.tmp.x * 0.5 + 0.5) * w,
        y: (-this.tmp.y * 0.5 + 0.5) * h,
        discovered: isDiscovered(b.id),
        dist,
        offscreen: off,
      });
    }
    markers.sort((a, b) => a.dist - b.dist);
    const target = this.targetId != null ? CATALOG[this.targetId] : null;
    useGameStore.getState().patchHud({
      fps: this.fps,
      speed: this.speed,
      hull: this.hull,
      boost: this.boost,
      nearestName: n.body.name,
      nearestDist: n.dist,
      nearestKind: n.body.kind,
      canScan: n.dist < SCAN_RANGE + n.body.radius,
      scanning: this.scanHold > 0,
      targetId: this.targetId,
      targetName: target?.name ?? "None",
      warping: this.warpActive,
      markers: markers.slice(0, 10),
      phase: this.phase,
    });
  }

  dispose() {
    this.running = false;
    this.renderer.setAnimationLoop(null);
    this.input.detach();
    removeEventListener("resize", this.onResize);
    this.ro?.disconnect();
    if (window.__controlsTest) delete window.__controlsTest;
    this.dropField();
    disposeObject(this.scene);
    this.glowTex.dispose();
    this.pointMat.dispose();
    this.starMat.dispose();
    this.dustMat.dispose();
    this.hiiMat.dispose();
    this.dimensionField.geometry.dispose();
    this.dimensionMat.dispose();
    this.renderer.dispose();
  }
}
