import { ASSETS, DIFFICULTY_FACTORS, INITIAL_FRIENDS, SCHOOL_STAGES } from './constants';
import { AVAILABLE_COURSES } from './courses';
import { CAREER_POSITIONS, CAREER_TRACKS_INFO } from './careers';
import {
  CareerPosition,
  CareerTier,
  CareerTrack,
  Child,
  DifficultyMode,
  Friend,
  GameState,
  Gender,
  PlayerCourse,
  SchoolStage
} from './types';

export const BASE_MAX_ENERGY = 100;
export const ENERGY_PER_FITNESS_LEVEL = 10;
export const MAX_FITNESS_LEVEL = 20;
export const PREGNANCY_TOTAL_DAYS = 10;

export function calculateMaxEnergy(fitnessLevel: number): number {
  const lvl = Math.max(0, Math.min(MAX_FITNESS_LEVEL, fitnessLevel || 0));
  return BASE_MAX_ENERGY + lvl * ENERGY_PER_FITNESS_LEVEL;
}

export function getXpRequiredForNextLevel(currentLevel: number): number {
  return 100 + Math.min(MAX_FITNESS_LEVEL, currentLevel) * 20;
}

export function getMoodProductivityMultiplier(mood: number): {
  multiplier: number;
  label: string;
  tone: 'positive' | 'neutral' | 'negative';
} {
  if (mood >= 75) {
    return { multiplier: 1.20, label: 'نشاط وحماس عالٍ (+20% إنتاجية)', tone: 'positive' };
  } else if (mood >= 50) {
    return { multiplier: 1.00, label: 'مزاج مستقر وطبيعي', tone: 'neutral' };
  } else if (mood >= 35) {
    return { multiplier: 0.85, label: 'إجهاد وتشتت ذهني (-15% إنتاجية)', tone: 'negative' };
  } else {
    return { multiplier: 0.65, label: 'إحباط واكتئاب حاد (-35% إنتاجية)', tone: 'negative' };
  }
}

export function createInitialState(
  customName = 'محمد',
  customPartner = 'أروى',
  difficulty: DifficultyMode = 'realistic',
  timeSpeed: 'slow' | 'normal' = 'slow'
): GameState {
  const initialTrack: CareerTrack = 'commerce';
  const initialTier: CareerTier = 1;
  const initialPos = CAREER_POSITIONS[initialTrack][initialTier];

  return {
    playerName: customName.trim() || 'محمد',
    partnerName: customPartner.trim() || 'أروى',
    difficulty,
    money: 350,
    health: 95,
    hunger: 75,
    energy: BASE_MAX_ENERGY,
    fitnessXP: 0,
    fitnessLevel: 0,
    mood: 80,
    rep: 0,
    skill: 0,
    day: 1,
    hour: 8.0,
    timeSpeed,

    love: 20,
    trust: 25,
    lastLoveDay: 1,
    engaged: false,
    married: false,
    romanticSurprisesDone: 0,

    pregnancyDaysRemaining: 0,
    pregnancyCheckupsDone: 0,
    children: [],
    familyMood: 70,

    activeCourses: [],
    completedCourseIds: [],
    friends: INITIAL_FRIENDS.map(f => ({ ...f })),

    // Career Path State
    currentCareerTrack: initialTrack,
    currentCareerTier: initialTier,
    careerDaysWorked: {
      commerce: 0,
      corporate: 0,
      tech: 0,
      logistics: 0,
      freelance: 0
    },
    promotionsCount: 0,

    assets: [],
    job: initialPos.title,
    daysWorked: 0,

    path: 'clean',
    heat: 0,
    gang: 0,
    loyalty: 50,
    suspicion: 0,
    jail: 0,
    crimesCount: 0,
    cleanDays: 0,
    partnerKnowsDark: false,
    partnerLeft: false,

    dreams: [],
    achievements: [],
    log: [
      {
        id: 'start',
        day: 1,
        time: '08:00 ص',
        text: `بدأت رحلتك في القاهرة يا ${customName.trim() || 'محمد'}، التحدي بدأ ومعك 350 ج.م.`,
        icon: '🌅'
      }
    ],
    notifications: [],
    dead: false,
    tutorialCompleted: false
  };
}

export function formatGameTime(hour: number): { timeStr: string; period: string } {
  const h = Math.floor(hour) % 24;
  const m = Math.floor((hour - Math.floor(hour)) * 60);
  const displayH = h % 12 === 0 ? 12 : h % 12;
  const period = h < 12 ? 'صباحاً' : h < 17 ? 'ظهراً' : 'مساءً';
  const timeStr = `${String(displayH).padStart(2, '0')}:${String(m).padStart(2, '0')} ${period}`;
  return { timeStr, period };
}

export function advanceTime(state: GameState, hoursToAdd: number): { state: GameState; dayPassed: boolean } {
  const speedFactor = state.timeSpeed === 'slow' ? 0.5 : 1.0;
  const effectiveHours = hoursToAdd * speedFactor;

  let newHour = state.hour + effectiveHours;
  let dayPassed = false;
  let s = { ...state };

  const diff = DIFFICULTY_FACTORS[state.difficulty] || DIFFICULTY_FACTORS.realistic;
  const energyLoss = effectiveHours * 1.5 * diff.energyDrainMultiplier;
  const hungerLoss = effectiveHours * 1.8 * diff.costMultiplier;

  s.energy = Math.max(0, s.energy - energyLoss);
  s.hunger = Math.max(0, s.hunger - hungerLoss);

  while (newHour >= 24) {
    newHour -= 24;
    dayPassed = true;
    s = executeDailyTick(s);
  }

  s.hour = newHour;
  return { state: s, dayPassed };
}

export function executeDailyTick(state: GameState): GameState {
  const s: GameState = {
    ...state,
    children: state.children.map(c => ({ ...c })),
    activeCourses: state.activeCourses.map(c => ({ ...c })),
    careerDaysWorked: { ...state.careerDaysWorked }
  };

  const diff = DIFFICULTY_FACTORS[s.difficulty];

  // 1. Rent and Upkeep
  const hasVilla = s.assets.includes('villa');
  const hasHome = s.assets.includes('home');
  const hasFlat = s.assets.includes('flat');

  let housingCost = 0;
  if (!hasHome && !hasVilla) {
    housingCost = hasFlat ? 95 : 75;
  } else if (hasVilla) {
    housingCost = 150;
  }
  housingCost = Math.round(housingCost * diff.costMultiplier);

  if (s.money >= housingCost) {
    s.money -= housingCost;
  } else {
    s.money = Math.max(0, s.money - housingCost);
    s.mood = Math.max(0, s.mood - 12);
    s.rep = Math.max(0, s.rep - 2);
    s.log.unshift({
      id: `rent_fail_${s.day}`,
      day: s.day,
      time: '08:00 ص',
      text: 'تعثرت في سداد إيجار/صيانة السكن اليوم وأثار ذلك غضب صاحب العقار!',
      icon: '⚠️'
    });
  }

  // 2. Business and Workshop Revenue
  if (s.assets.includes('business')) {
    const biz = ASSETS.business;
    const net = Math.round(((biz.dailyRevenue || 280) - (biz.dailyUpkeep || 90)) * diff.payMultiplier);
    s.money += net;
    s.log.unshift({
      id: `biz_${s.day}`,
      day: s.day,
      time: '09:00 ص',
      text: `حقق محلك التجاري صافي أرباح يومية قدرها ${net} ج.م.`,
      icon: '🏪'
    });
  }

  if (s.assets.includes('workshop')) {
    const ws = ASSETS.workshop;
    const net = Math.round(((ws.dailyRevenue || 680) - (ws.dailyUpkeep || 220)) * diff.payMultiplier);
    s.money += net;
    s.log.unshift({
      id: `ws_${s.day}`,
      day: s.day,
      time: '09:00 ص',
      text: `حققت ورشتك الصناعية أرباحاً صافية قدرها ${net} ج.م.`,
      icon: '⚙️'
    });
  }

  // 3. Children Expenses & Age Progression
  if (s.children.length > 0) {
    const totalChildExpense = s.children.reduce((acc, child) => {
      const stageInfo = SCHOOL_STAGES[child.stage] || SCHOOL_STAGES.primary;
      const schoolMultiplier = child.schoolType === 'private' ? 2.2 : child.schoolType === 'experimental' ? 1.5 : 1.0;
      return acc + Math.round((stageInfo.baseCost * schoolMultiplier + 30) * diff.costMultiplier);
    }, 0);

    if (s.money >= totalChildExpense) {
      s.money -= totalChildExpense;
    } else {
      s.money = 0;
      s.familyMood = Math.max(0, s.familyMood - 15);
      s.log.unshift({
        id: `child_debt_${s.day}`,
        day: s.day,
        time: '10:00 ص',
        text: 'عجزت الميزانية عن تغطية كافة مصاريف الأولاد المدرسية والمعيشية!',
        icon: '⚠️'
      });
    }

    s.children = s.children.map(child => {
      const ageDays = child.ageDays + 1;
      let stage = child.stage;

      if (ageDays >= 30) stage = 'graduated';
      else if (ageDays >= 22) stage = 'university';
      else if (ageDays >= 15) stage = 'secondary';
      else if (ageDays >= 10) stage = 'preparatory';
      else if (ageDays >= 5) stage = 'primary';
      else stage = 'nursery';

      const groundedDays = child.groundedDays && child.groundedDays > 0 ? child.groundedDays - 1 : 0;

      return {
        ...child,
        ageDays,
        stage,
        groundedDays,
        education: Math.min(100, child.education + (child.schoolType === 'private' ? 1.5 : 0.8))
      };
    });
  }

  // 4. Pregnancy Countdown
  if (s.pregnancyDaysRemaining > 0) {
    s.pregnancyDaysRemaining -= 1;
    if (s.pregnancyDaysRemaining > 0) {
      s.log.unshift({
        id: `preg_${s.day}`,
        day: s.day,
        time: '08:00 ص',
        text: `الحمل يتقدم بثبات: متبقي ${s.pregnancyDaysRemaining} أيام على موعد الولادة بإذن الله.`,
        icon: '🤰'
      });
    }
  }

  // 5. Health degradation if hungry or exhausted
  if (s.hunger < 20) s.health = Math.max(0, s.health - 10);
  if (s.energy < 10) s.health = Math.max(0, s.health - 6);

  // 6. Crime Heat & Suspicion
  if (s.path === 'dark') {
    if (s.heat > 0) {
      s.suspicion = Math.min(100, s.suspicion + s.heat * 0.12);
      s.heat = Math.max(0, s.heat - 2);
    }
    s.cleanDays = 0;
  } else {
    s.cleanDays += 1;
    s.heat = Math.max(0, s.heat - 5);
    s.suspicion = Math.max(0, s.suspicion - 4);
  }

  s.log = s.log.slice(0, 45);
  return s;
}

export function trainGym(state: GameState): { state: GameState; leveledUp: boolean; message: string } {
  const maxE = calculateMaxEnergy(state.fitnessLevel);
  if (state.energy < 22) {
    return {
      state,
      leveledUp: false,
      message: 'طاقتك منخفضة جداً! ارتاح أو تناول وجبة قبل التوجه للجيم.'
    };
  }

  const s = { ...state };
  s.energy = Math.max(0, s.energy - 22);
  s.hunger = Math.max(0, s.hunger - 10);
  s.health = Math.min(100, s.health + 6);
  s.mood = Math.min(100, s.mood + 7);

  const tarek = s.friends.find(f => f.id === 'captain_tarek');
  const xpBoost = tarek && tarek.closeness >= 50 ? 55 : 35;
  const reqXP = getXpRequiredForNextLevel(s.fitnessLevel);
  const currentXP = s.fitnessXP + xpBoost;
  let leveledUp = false;
  let msg = `أنهيت تمريناً بدنياً مكثفاً (+${xpBoost} خبرة لياقة).`;

  if (currentXP >= reqXP && s.fitnessLevel < MAX_FITNESS_LEVEL) {
    s.fitnessLevel += 1;
    s.fitnessXP = currentXP - reqXP;
    leveledUp = true;
    const newMax = calculateMaxEnergy(s.fitnessLevel);
    msg = `🎉 ارتقيت لمستوى لياقة جديد [مستوى ${s.fitnessLevel}]! ارتفع الحد الأقصى لطاقتك إلى ${newMax}⚡!`;
    s.log.unshift({
      id: `gym_lvl_${s.day}_${Date.now()}`,
      day: s.day,
      time: 'الجيم',
      text: msg,
      icon: '🏋️'
    });
  } else {
    s.fitnessXP = Math.min(reqXP, currentXP);
  }

  const advanced = advanceTime(s, 0.75);
  return {
    state: advanced.state,
    leveledUp,
    message: msg
  };
}

export function startPregnancy(state: GameState): { state: GameState; success: boolean; message: string } {
  if (!state.married) {
    return { state, success: false, message: 'يجب أن تكون متزوجاً أولاً لتكوين أسرة وإنجاب أطفال.' };
  }
  if (state.pregnancyDaysRemaining > 0) {
    return { state, success: false, message: `زوجتك حامل بالفعل! متبقي ${state.pregnancyDaysRemaining} أيام على الولادة.` };
  }

  const s = { ...state };
  s.pregnancyDaysRemaining = PREGNANCY_TOTAL_DAYS;
  s.pregnancyCheckupsDone = 0;
  s.familyMood = Math.min(100, s.familyMood + 15);
  s.love = Math.min(100, s.love + 10);
  const msg = `🤰 بشارة خير وسعادة غامرة! تم تأكيد خبر حمل ${s.partnerName}. ستبدأ مرحلة العناية والترقب (متبقي ${PREGNANCY_TOTAL_DAYS} أيام على الولادة)!`;

  s.log.unshift({
    id: `start_preg_${s.day}_${Date.now()}`,
    day: s.day,
    time: 'المنزل',
    text: msg,
    icon: '🍼'
  });

  return { state: s, success: true, message: msg };
}

export function performPregnancyCheckup(state: GameState): { state: GameState; message: string; revealedGender: Gender } {
  if (state.pregnancyDaysRemaining <= 0) {
    return {
      state,
      message: 'لا يوجد حمل حالياً.',
      revealedGender: 'boy'
    };
  }

  const dr = state.friends.find(f => f.id === 'dr_mahmoud');
  const cost = dr && dr.closeness >= 40 ? 90 : 150;

  if (state.money < cost) {
    return {
      state,
      message: `تحتاج إلى ${cost} ج.م لكشف السونار ومتابعة الطبيب.`,
      revealedGender: state.pregnancyGender || 'boy'
    };
  }

  const s = { ...state };
  s.money -= cost;
  s.love = Math.min(100, s.love + 8);
  s.trust = Math.min(100, s.trust + 8);
  s.familyMood = Math.min(100, s.familyMood + 12);
  s.pregnancyCheckupsDone += 1;

  const gender: Gender = s.pregnancyGender || (Math.random() > 0.5 ? 'boy' : 'girl');
  s.pregnancyGender = gender;

  const genderStr = gender === 'boy' ? 'ولد 👦' : 'بنت 👧';
  const msg = `أجرى الطبيب فحص السونار وأكد استقرار صحة ${s.partnerName} والجنين! وأظهر الفحص بوضوح أن المولود القادم: ${genderStr}!`;

  s.log.unshift({
    id: `checkup_${s.day}_${Date.now()}`,
    day: s.day,
    time: 'العيادة',
    text: msg,
    icon: '🩺'
  });

  const advanced = advanceTime(s, 1.0);
  return {
    state: advanced.state,
    message: msg,
    revealedGender: gender
  };
}

export function deliverBaby(
  state: GameState,
  babyName: string,
  chosenGender?: Gender
): { state: GameState; child: Child; message: string } {
  const gender = chosenGender || state.pregnancyGender || (Math.random() > 0.5 ? 'boy' : 'girl');
  const name = babyName.trim() || (gender === 'boy' ? 'كريم' : 'مريم');

  const newChild: Child = {
    id: `child_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name,
    gender,
    ageDays: 0,
    education: 15,
    happiness: 90,
    discipline: 70,
    stage: 'nursery',
    schoolType: 'public',
    lastGrade: 'ممتاز (A)'
  };

  const s = {
    ...state,
    pregnancyDaysRemaining: 0,
    pregnancyGender: undefined,
    pregnancyCheckupsDone: 0,
    children: [...state.children, newChild],
    familyMood: Math.min(100, state.familyMood + 25),
    love: Math.min(100, state.love + 15),
    trust: Math.min(100, state.trust + 10)
  };

  const genderText = gender === 'boy' ? 'ولد' : 'بنت';
  const msg = `🎉 ألف مبروك! رُزقتم بمولود جديد (${genderText}) وسميتوه: ${name}. عمّت الفرحة والبهجة بيتكم!`;

  s.log.unshift({
    id: `birth_${s.day}_${Date.now()}`,
    day: s.day,
    time: 'المستشفى',
    text: msg,
    icon: '🍼'
  });

  return { state: s, child: newChild, message: msg };
}

export function updatePersonName(
  state: GameState,
  target: 'player' | 'partner' | string,
  newName: string
): GameState {
  const clean = newName.trim();
  if (!clean) return state;

  const s = { ...state };
  if (target === 'player') {
    s.playerName = clean;
    s.log.unshift({
      id: `rename_player_${Date.now()}`,
      day: s.day,
      time: 'إعدادات',
      text: `تم تغيير اسم اللاعب إلى: ${clean}`,
      icon: '✏️'
    });
  } else if (target === 'partner') {
    s.partnerName = clean;
    s.log.unshift({
      id: `rename_partner_${Date.now()}`,
      day: s.day,
      time: 'إعدادات',
      text: `تم تغيير اسم شريكة الحياة إلى: ${clean}`,
      icon: '✏️'
    });
  } else {
    s.children = s.children.map(c => c.id === target ? { ...c, name: clean } : c);
    s.log.unshift({
      id: `rename_child_${Date.now()}`,
      day: s.day,
      time: 'إعدادات',
      text: `تم تعديل اسم الطفل إلى: ${clean}`,
      icon: '👶'
    });
  }

  return s;
}

export function enrollCourse(state: GameState, courseId: string): { state: GameState; success: boolean; message: string } {
  const courseDef = AVAILABLE_COURSES.find(c => c.id === courseId);
  if (!courseDef) return { state, success: false, message: 'الكورس غير موجود.' };

  if (state.completedCourseIds.includes(courseId)) {
    return { state, success: false, message: 'لقد أتممت هذا الكورس وحصلت على شهادته بالفعل!' };
  }
  if (state.activeCourses.some(c => c.id === courseId)) {
    return { state, success: false, message: 'أنت مسجل في هذا الكورس حالياً بالفعل وتدرسه!' };
  }
  if (state.money < courseDef.cost) {
    return { state, success: false, message: `تكلفة التسجيل ${courseDef.cost} ج.م. رصيدك لا يكفي.` };
  }

  const s = { ...state };
  s.money -= courseDef.cost;
  const newCourse: PlayerCourse = {
    ...courseDef,
    daysEnrolled: 0,
    completed: false
  };
  s.activeCourses = [...s.activeCourses, newCourse];

  const msg = `تم التسجيل بنجاح في ${courseDef.name}! يتطلب منك دراسة يومية لمدة ${courseDef.durationDays} أيام للتخرج والحصول على المزايا.`;
  s.log.unshift({
    id: `enroll_${courseId}_${Date.now()}`,
    day: s.day,
    time: 'التعليم',
    text: msg,
    icon: '📚'
  });

  return { state: s, success: true, message: msg };
}

export function attendCourseDaily(state: GameState, courseId: string): { state: GameState; success: boolean; message: string } {
  const course = state.activeCourses.find(c => c.id === courseId);
  if (!course) return { state, success: false, message: 'لست مسجلاً في هذا الكورس.' };

  if (state.energy < 20) {
    return { state, success: false, message: 'طاقتك لا تكفي لحضور المحاضرة والاستيعاب. ارتاح أولاً.' };
  }

  const s = {
    ...state,
    activeCourses: state.activeCourses.map(c => ({ ...c }))
  };
  const target = s.activeCourses.find(c => c.id === courseId)!;

  const moodInfo = getMoodProductivityMultiplier(s.mood);
  s.energy = Math.max(0, s.energy - 20);
  target.daysEnrolled += 1;

  let msg = '';
  if (target.daysEnrolled >= target.durationDays) {
    target.completed = true;
    s.completedCourseIds = [...s.completedCourseIds, target.id];
    s.activeCourses = s.activeCourses.filter(c => c.id !== target.id);
    s.skill = Math.min(100, s.skill + target.skillBonus);
    s.rep = Math.min(100, s.rep + target.repBonus);
    s.mood = Math.min(100, s.mood + 15);
    msg = `🎓 ألف مبروك التخرج! أتممت ${target.name} بنجاح وحصلت على الشهادة الرسمية (+${target.skillBonus} مهارة، +${target.repBonus} سمعة)! ${target.unlockedCareerPerk ? `[ميزة: ${target.unlockedCareerPerk}]` : ''}`;
  } else {
    s.skill = Math.min(100, s.skill + Math.round(2 * moodInfo.multiplier));
    msg = `حضرت محاضرة اليوم في ${target.name} بنجاح (${target.daysEnrolled} من ${target.durationDays} أيام). ${moodInfo.label}.`;
  }

  s.log.unshift({
    id: `study_course_${Date.now()}`,
    day: s.day,
    time: 'محاضرة',
    text: msg,
    icon: '🎓'
  });

  const advanced = advanceTime(s, target.dailyHours);
  return { state: advanced.state, success: true, message: msg };
}

// ----------------- CAREER PATH & PROMOTIONS SYSTEM -----------------

export function getCurrentCareerPosition(state: GameState): CareerPosition {
  const track = state.currentCareerTrack || 'commerce';
  const tier = (state.currentCareerTier || 1) as CareerTier;
  return CAREER_POSITIONS[track][tier];
}

export function getNextCareerPosition(state: GameState): CareerPosition | null {
  const track = state.currentCareerTrack || 'commerce';
  const tier = state.currentCareerTier || 1;
  if (tier >= 5) return null;
  const nextTier = (tier + 1) as CareerTier;
  return CAREER_POSITIONS[track][nextTier];
}

export function checkPromotionEligibility(state: GameState): {
  eligible: boolean;
  nextPos: CareerPosition | null;
  reasonsMissing: string[];
} {
  const nextPos = getNextCareerPosition(state);
  if (!nextPos) {
    return { eligible: false, nextPos: null, reasonsMissing: ['وصلت بالفعل إلى أعلى رتبة قيادية في هذا المسار المهني!'] };
  }

  const track = state.currentCareerTrack;
  const daysWorkedInTrack = state.careerDaysWorked?.[track] || 0;
  const reasonsMissing: string[] = [];

  // Check days worked
  if (daysWorkedInTrack < nextPos.minDaysWorked) {
    reasonsMissing.push(`أيام العمل الفعلية: متبقي ${nextPos.minDaysWorked - daysWorkedInTrack} يوم عمل (لديك ${daysWorkedInTrack}/${nextPos.minDaysWorked})`);
  }

  // Check skill
  if (state.skill < nextPos.minSkill) {
    reasonsMissing.push(`المهارة المطلوبة: متبقي ${nextPos.minSkill - state.skill} نقطة مهارة (لديك ${Math.round(state.skill)}/${nextPos.minSkill})`);
  }

  // Check required assets
  if (nextPos.requiredAssets && nextPos.requiredAssets.length > 0) {
    for (const assetId of nextPos.requiredAssets) {
      if (!state.assets.includes(assetId)) {
        const assetName = ASSETS[assetId]?.name || assetId;
        reasonsMissing.push(`امتلاك أصل مطلوب: ${assetName}`);
      }
    }
  }

  // Check required course
  if (nextPos.requiredCourseId) {
    if (!state.completedCourseIds.includes(nextPos.requiredCourseId)) {
      const courseName = AVAILABLE_COURSES.find(c => c.id === nextPos.requiredCourseId)?.name || 'دورة تدريبية متخصصة';
      reasonsMissing.push(`شهادة معتمدة مطلوبة: إتمام ${courseName}`);
    }
  }

  return {
    eligible: reasonsMissing.length === 0,
    nextPos,
    reasonsMissing
  };
}

export function requestPromotion(state: GameState): {
  state: GameState;
  success: boolean;
  message: string;
} {
  const { eligible, nextPos, reasonsMissing } = checkPromotionEligibility(state);
  if (!eligible || !nextPos) {
    return {
      state,
      success: false,
      message: `لم تستوفِ شروط الترقية بعد:\n• ` + reasonsMissing.join('\n• ')
    };
  }

  const s: GameState = {
    ...state,
    currentCareerTier: nextPos.tier,
    job: nextPos.title,
    rep: Math.min(100, state.rep + 8),
    mood: Math.min(100, state.mood + 20),
    familyMood: Math.min(100, state.familyMood + 15),
    promotionsCount: (state.promotionsCount || 0) + 1
  };

  const msg = `🎉 مبروك الترقية الكبرى! تمت ترقيتك رسمياً إلى: ${nextPos.title} [رتبة ${nextPos.tier} - ${nextPos.department}]! ارتفع راتبك الأساسي إلى ${nextPos.basePay} ج.م، وتوسعت صلاحياتك ومسؤولياتك.`;

  s.log.unshift({
    id: `promo_${Date.now()}`,
    day: s.day,
    time: 'ترقية وظيفية',
    text: msg,
    icon: '🎖️'
  });

  return { state: s, success: true, message: msg };
}

export function switchCareerTrack(
  state: GameState,
  newTrack: CareerTrack
): { state: GameState; success: boolean; message: string } {
  if (state.currentCareerTrack === newTrack) {
    return { state, success: false, message: 'أنت في هذا المسار المهني حالياً بالفعل.' };
  }

  const trackInfo = CAREER_TRACKS_INFO[newTrack];
  const initialPos = CAREER_POSITIONS[newTrack][1];

  // Check entry requirements for tier 1 of new track
  if (initialPos.minSkill > state.skill) {
    return {
      state,
      success: false,
      message: `بدء هذا المسار يتطلب مهارة ${initialPos.minSkill} على الأقل (لديك ${Math.round(state.skill)}).`
    };
  }

  if (initialPos.requiredAssets && initialPos.requiredAssets.length > 0) {
    for (const aId of initialPos.requiredAssets) {
      if (!state.assets.includes(aId)) {
        return {
          state,
          success: false,
          message: `بدء مسار ${trackInfo.name} يتطلب امتلاك: ${ASSETS[aId]?.name || aId}.`
        };
      }
    }
  }

  const s: GameState = {
    ...state,
    currentCareerTrack: newTrack,
    currentCareerTier: 1,
    job: initialPos.title
  };

  const msg = `تم تغيير مسارك المهني بنجاح إلى: ${trackInfo.name}! وظيفتك الحالية: ${initialPos.title}.`;
  s.log.unshift({
    id: `switch_track_${Date.now()}`,
    day: s.day,
    time: 'تغيير مسار',
    text: msg,
    icon: '🔄'
  });

  return { state: s, success: true, message: msg };
}

export function executeCareerShift(state: GameState): {
  state: GameState;
  success: boolean;
  message: string;
} {
  const currentPos = getCurrentCareerPosition(state);
  const diff = DIFFICULTY_FACTORS[state.difficulty] || DIFFICULTY_FACTORS.realistic;
  const moodInfo = getMoodProductivityMultiplier(state.mood);

  if (state.energy < currentPos.energyCost || state.hunger < 15) {
    return {
      state,
      success: false,
      message: `طاقتك أو شبعك منخفض! تتطلب وردية [${currentPos.title}] طاقة ${currentPos.energyCost} على الأقل. تناول طعاماً أو ارتح أولاً.`
    };
  }

  const s = {
    ...state,
    careerDaysWorked: { ...state.careerDaysWorked }
  };

  const carBonus = s.assets.includes('car') || s.assets.includes('luxcar') ? 0.15 : 0;
  const bikeBonus = currentPos.track === 'logistics' && s.assets.includes('bike') ? 0.25 : 0;
  const phoneBonus = currentPos.track === 'freelance' && s.assets.includes('phone') ? 0.20 : 0;

  const totalMultiplier = (1 + carBonus + bikeBonus + phoneBonus) * diff.payMultiplier * moodInfo.multiplier;
  const payEarned = Math.round(currentPos.basePay * totalMultiplier);

  s.money += payEarned;
  s.energy = Math.max(0, s.energy - currentPos.energyCost);
  s.daysWorked += 1;
  s.careerDaysWorked[currentPos.track] = (s.careerDaysWorked[currentPos.track] || 0) + 1;
  s.skill = Math.min(100, s.skill + 0.5);
  s.rep = Math.min(100, s.rep + 1);

  const daysWorkedInTrack = s.careerDaysWorked[currentPos.track];
  const nextPos = getNextCareerPosition(s);
  const promoReady = nextPos && daysWorkedInTrack >= nextPos.minDaysWorked && s.skill >= nextPos.minSkill;

  let msg = `أنهيت وردية العمل في وظيفة [${currentPos.title} - رتبة ${currentPos.tier}] وحصلت على ${payEarned} ج.م! (${moodInfo.label}).`;
  if (promoReady) {
    msg += ` ⭐ إشعار: لقد استوفيت شروط الترقية للرتبة التالية! توجه لسلم المسار المهني لطلب الترقية.`;
  }

  s.log.unshift({
    id: `career_shift_${Date.now()}`,
    day: s.day,
    time: 'العمل',
    text: msg,
    icon: '💼'
  });

  const advanced = advanceTime(s, currentPos.hoursRequired);
  return { state: advanced.state, success: true, message: msg };
}

export function executeWork(state: GameState, jobType: 'delivery' | 'shop' | 'office' | 'freelance' | 'trade' | 'tech'): { state: GameState; success: boolean; message: string } {
  return executeCareerShift(state);
}

export function educateChild(
  state: GameState,
  childId: string,
  action: 'study' | 'tutor' | 'books' | 'schoolUpgrade',
  schoolType?: 'public' | 'experimental' | 'private'
): { state: GameState; success: boolean; message: string } {
  const child = state.children.find(c => c.id === childId);
  if (!child) return { state, success: false, message: 'الطفل غير موجود.' };

  const s = {
    ...state,
    children: state.children.map(c => ({ ...c }))
  };
  const target = s.children.find(c => c.id === childId)!;

  if (action === 'study') {
    if (s.energy < 15) {
      return { state, success: false, message: 'طاقتك لا تكفي للتركيز والمذاكرة مع طفلك. ارتاح أولاً.' };
    }
    s.energy = Math.max(0, s.energy - 15);
    target.education = Math.min(100, target.education + 8);
    target.happiness = Math.min(100, target.happiness + 6);
    s.familyMood = Math.min(100, s.familyMood + 6);
    s.log.unshift({
      id: `study_${Date.now()}`,
      day: s.day,
      time: 'المنزل',
      text: `جلست وذاكرت مع ${target.name} وساعدته في دروسه وواجباته.`,
      icon: '📖'
    });
    const advanced = advanceTime(s, 0.75);
    return {
      state: advanced.state,
      success: true,
      message: `قضيت وقتاً مفيداً مع ${target.name}، وارتفع تحصيله الدراسي بنسبة +8%.`
    };
  }

  if (action === 'tutor') {
    const cost = 120;
    if (s.money < cost) {
      return { state, success: false, message: `تكلفة حصة الدرس الخصوصي ${cost} ج.م. رصيدك لا يكفي.` };
    }
    s.money -= cost;
    target.education = Math.min(100, target.education + 16);
    s.log.unshift({
      id: `tutor_${Date.now()}`,
      day: s.day,
      time: 'تعليم',
      text: `حجزت درس تقوية خاص لـ ${target.name} لتطوير مستواه.`,
      icon: '🎓'
    });
    return {
      state: s,
      success: true,
      message: `أنهى ${target.name} الحصة التعليمية وحقق قفزة ممتازة في المادة (+16% تعليم).`
    };
  }

  if (action === 'books') {
    const cost = 70;
    if (s.money < cost) {
      return { state, success: false, message: `تكلفة الكتب والأدوات المدرسية ${cost} ج.م.` };
    }
    s.money -= cost;
    target.education = Math.min(100, target.education + 7);
    target.happiness = Math.min(100, target.happiness + 8);
    return {
      state: s,
      success: true,
      message: `اشتريت كتباً وقصصاً مفيدة وحقيبة لـ ${target.name}، مما حفزه على القراءة.`
    };
  }

  if (action === 'schoolUpgrade' && schoolType) {
    target.schoolType = schoolType;
    const typeNames = { public: 'حكومية', experimental: 'تجريبية متميزة', private: 'لغات ودولية' };
    return {
      state: s,
      success: true,
      message: `تم تحويل ${target.name} إلى مدرسة ${typeNames[schoolType]}.`
    };
  }

  return { state, success: false, message: 'إجراء غير معروف.' };
}

export function checkChildGrades(state: GameState, childId: string): { state: GameState; grade: string; message: string } {
  const child = state.children.find(c => c.id === childId);
  if (!child) return { state, grade: '', message: 'الطفل غير موجود.' };

  const s = {
    ...state,
    children: state.children.map(c => ({ ...c }))
  };
  const target = s.children.find(c => c.id === childId)!;

  let grade: Child['lastGrade'] = 'مقبول (D)';
  if (target.education >= 85) grade = 'ممتاز (A)';
  else if (target.education >= 70) grade = 'جيد جداً (B)';
  else if (target.education >= 50) grade = 'جيد (C)';
  else if (target.education >= 30) grade = 'مقبول (D)';
  else grade = 'راسب (F)';

  target.lastGrade = grade;
  const msg = `تم فحص شهادة درجات ${target.name}: تقديره الحالي هو ${grade}. التحصيل العلمي: ${Math.round(target.education)}%، الانضباط: ${Math.round(target.discipline || 70)}%.`;

  s.log.unshift({
    id: `report_${Date.now()}`,
    day: s.day,
    time: 'المدرسة',
    text: msg,
    icon: '📊'
  });

  return { state: s, grade: grade || 'مقبول (D)', message: msg };
}

export function disciplineChild(
  state: GameState,
  childId: string,
  action: 'advice' | 'ground' | 'reward' | 'extra_study'
): { state: GameState; message: string } {
  const child = state.children.find(c => c.id === childId);
  if (!child) return { state, message: 'الطفل غير موجود.' };

  const s = {
    ...state,
    children: state.children.map(c => ({ ...c }))
  };
  const target = s.children.find(c => c.id === childId)!;

  if (action === 'advice') {
    target.discipline = Math.min(100, (target.discipline || 70) + 10);
    s.love = Math.min(100, s.love + 2);
    return {
      state: s,
      message: `جلست مع ${target.name} وتحدثت معه بلطف وهدوء حول أهمية الاجتهاد والأخلاق. استمع لك ووعد بالتحسن (+10 انضباط).`
    };
  }

  if (action === 'ground') {
    target.discipline = Math.min(100, (target.discipline || 70) + 18);
    target.happiness = Math.max(0, target.happiness - 12);
    target.groundedDays = 3;
    return {
      state: s,
      message: `عاقبت ${target.name} بسحب الموبايل والألعاب لمدة 3 أيام لعدم تكرار الإهمال (+18 انضباط، -12 سعادة).`
    };
  }

  if (action === 'reward') {
    if (s.money < 80) return { state, message: 'تحتاج 80 ج.م لشراء هدية ومكافأة تشجيعية.' };
    s.money -= 80;
    target.happiness = Math.min(100, target.happiness + 20);
    target.education = Math.min(100, target.education + 5);
    s.familyMood = Math.min(100, s.familyMood + 10);
    return {
      state: s,
      message: `كافأت ${target.name} بهدية جميلة ومصروف تشجيعي (+20 سعادة، +5 رغبة في التفوق)!`
    };
  }

  if (action === 'extra_study') {
    if (s.energy < 15) return { state, message: 'طاقتك لا تكفي للمتابعة.' };
    s.energy -= 15;
    target.education = Math.min(100, target.education + 10);
    target.discipline = Math.min(100, (target.discipline || 70) + 6);
    return {
      state: s,
      message: `ألزمت ${target.name} بجدول استذكار صارم لتعويض الدرجات والتقصير (+10 تحصيل، +6 انضباط).`
    };
  }

  return { state, message: 'إجراء غير معروف.' };
}

export function performRomanticAction(
  state: GameState,
  action: 'poetry' | 'nile_dinner' | 'sunset_drive' | 'surprise_gift' | 'deep_talk' | 'reconcile'
): { state: GameState; message: string; success: boolean } {
  const s = { ...state };
  s.lastLoveDay = s.day;

  if (action === 'poetry') {
    s.love = Math.min(100, s.love + 7);
    s.trust = Math.min(100, s.trust + 4);
    s.mood = Math.min(100, s.mood + 6);
    const msg = `كتبت لـ ${s.partnerName} رسالة حب وتقدير صادقة من قلبك. احمرت وجنتاها وابتسمت بسعادة بالغة!`;
    s.log.unshift({ id: `love_msg_${Date.now()}`, day: s.day, time: 'رومانسية', text: msg, icon: '💌' });
    const advanced = advanceTime(s, 0.4);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'nile_dinner') {
    const cost = 320;
    if (s.money < cost) return { state, message: `تكلفة العشاء على النيل ${cost} ج.م. رصيدك لا يكفي.`, success: false };
    s.money -= cost;
    s.love = Math.min(100, s.love + 15);
    s.trust = Math.min(100, s.trust + 8);
    s.mood = Math.min(100, s.mood + 14);
    s.romanticSurprisesDone += 1;
    const msg = `عشاء رومانسي ساحر على ضفاف النيل مع أنغام هادئة وأضواء المدينة. شعرت ${s.partnerName} أنها أميرة زمانها!`;
    s.log.unshift({ id: `dinner_${Date.now()}`, day: s.day, time: 'النيل', text: msg, icon: '🍷' });
    const advanced = advanceTime(s, 1.5);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'sunset_drive') {
    if (!s.assets.includes('car') && !s.assets.includes('luxcar') && !s.assets.includes('bike')) {
      return { state, message: 'تحتاج سيارة أو موتوسيكل للقيام بنزهة الغروب الرومانسية.', success: false };
    }
    s.love = Math.min(100, s.love + 10);
    s.mood = Math.min(100, s.mood + 12);
    const msg = `نزهة رائعة وقت الغروب على كورنيش النيل وتبادلتم الضحكات والذكريات الجميلة سوياً.`;
    s.log.unshift({ id: `drive_${Date.now()}`, day: s.day, time: 'الغروب', text: msg, icon: '🌇' });
    const advanced = advanceTime(s, 0.8);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'surprise_gift') {
    const cost = 220;
    if (s.money < cost) return { state, message: `تحتاج ${cost} ج.م لشراء هدية مفاجئة راقية.`, success: false };
    s.money -= cost;
    s.love = Math.min(100, s.love + 12);
    s.trust = Math.min(100, s.trust + 6);
    s.romanticSurprisesDone += 1;
    const msg = `فاجأت ${s.partnerName} بعطر مميز وباقة ورد رقيقة. طارت من الفرحة وعانقتك بامتنان!`;
    s.log.unshift({ id: `gift_${Date.now()}`, day: s.day, time: 'مفاجأة', text: msg, icon: '🎁' });
    const advanced = advanceTime(s, 0.5);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'deep_talk') {
    s.trust = Math.min(100, s.trust + 8);
    s.love = Math.min(100, s.love + 6);
    const msg = `قعدتم سوياً وتحدثتم عن طموحاتكم ومخاوفكم وخططكم للمستقبل. زاد الترابط والانسجام الروحي بينكم.`;
    s.log.unshift({ id: `talk_${Date.now()}`, day: s.day, time: 'حديث القلب', text: msg, icon: '☕' });
    const advanced = advanceTime(s, 0.7);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'reconcile') {
    s.trust = Math.min(100, s.trust + 10);
    s.love = Math.min(100, s.love + 8);
    s.mood = Math.min(100, s.mood + 8);
    const msg = `احتويت الخلاف واعتذرت برقي وحكمة، وزال أي عتاب وسوء تفاهم بينكم.`;
    s.log.unshift({ id: `reconcile_${Date.now()}`, day: s.day, time: 'مصالحة', text: msg, icon: '🕊️' });
    const advanced = advanceTime(s, 0.5);
    return { state: advanced.state, message: msg, success: true };
  }

  return { state, message: 'إجراء غير معروف.', success: false };
}

export function interactWithFriend(
  state: GameState,
  friendId: string,
  action: 'hangout' | 'borrow' | 'biz_advice' | 'workout'
): { state: GameState; message: string; success: boolean } {
  const friend = state.friends.find(f => f.id === friendId);
  if (!friend) return { state, message: 'الصديق غير موجود.', success: false };

  const s = {
    ...state,
    friends: state.friends.map(f => ({ ...f }))
  };
  const target = s.friends.find(f => f.id === friendId)!;

  if (action === 'hangout') {
    if (s.money < 60) return { state, message: 'تحتاج 60 ج.م لقعدة كافيه مع صديقك.', success: false };
    s.money -= 60;
    target.closeness = Math.min(100, target.closeness + 10);
    s.mood = Math.min(100, s.mood + 12);
    const msg = `تقابلت مع ${target.name} على القهوة وضحكتم واسترجعتم ذكريات جميلة (+10 صداقة).`;
    s.log.unshift({ id: `hang_${Date.now()}`, day: s.day, time: 'أصدقاء', text: msg, icon: '☕' });
    const advanced = advanceTime(s, 0.75);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'borrow') {
    if (target.closeness < 45) {
      return { state, message: `علاقتك بـ ${target.name} ليست قوية بما يكفي للاقتراض. اقضِ وقتاً معه أولاً.`, success: false };
    }
    const loanAmount = target.id === 'ramy' ? 600 : 400;
    s.money += loanAmount;
    target.closeness = Math.max(0, target.closeness - 15);
    const msg = `أقرضك ${target.name} مبلغ ${loanAmount} ج.م لمساندتك في أزمتك المالية. احرص على ردها عندما يتيسر حالك!`;
    s.log.unshift({ id: `loan_${Date.now()}`, day: s.day, time: 'سلفة', text: msg, icon: '🤝' });
    return { state: s, message: msg, success: true };
  }

  if (action === 'biz_advice') {
    if (target.id !== 'hossam') {
      return { state, message: 'حسام البدري هو المتخصص في استشارات البيزنس والاستثمار.', success: false };
    }
    s.skill = Math.min(100, s.skill + 4);
    s.rep = Math.min(100, s.rep + 3);
    target.closeness = Math.min(100, target.closeness + 6);
    const msg = `جلس معك حسام وشرح لك أسرار إدارة المشاريع وكيف تحافظ على أرباحك وتتوسع بذكاء (+4 مهارة).`;
    s.log.unshift({ id: `biz_adv_${Date.now()}`, day: s.day, time: 'استشارة', text: msg, icon: '💡' });
    const advanced = advanceTime(s, 0.6);
    return { state: advanced.state, message: msg, success: true };
  }

  if (action === 'workout') {
    if (target.id !== 'captain_tarek') {
      return { state, message: 'كابتن طارق هو مدرب اللياقة.', success: false };
    }
    const gymRes = trainGym(s);
    if (!gymRes.leveledUp && gymRes.message.includes('منخفضة')) {
      return { state, message: gymRes.message, success: false };
    }
    target.closeness = Math.min(100, target.closeness + 8);
    const msg = `تمرنت تحت إشراف وتوجيه كابتن طارق وضغط على عضلاتك بشكل احترافي! ${gymRes.message}`;
    return { state: gymRes.state, message: msg, success: true };
  }

  return { state, message: 'إجراء غير معروف.', success: false };
}
