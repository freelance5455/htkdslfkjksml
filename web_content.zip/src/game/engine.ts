import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { createSfx } from "@/game/audio";
import {
  attachBeams,
  createCar,
  createCharacter,
  createHeli,
  limbsOf,
  PRESETS,
  type CarKind,
  type CarRig,
} from "@/game/actors";
import { blocked, buildCity, collide, GRID, gridPos, type Shop } from "@/game/world";

export type LibertyHandle = {
  dispose: () => void;
  begin: () => void;
  togglePause: () => void;
  resume: () => void;
  weapon: (index: number) => void;
  interact: () => void;
  setHold: (key: "fire" | "sprint" | "brake", value: boolean) => void;
};

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}

type Gun = {
  name: string;
  kind: string;
  dmg: number;
  spread: number;
  cd: number;
  pellets: number;
  speed: number;
  range: number;
  magSize: number;
  mag: number;
  res: number;
  reload: number;
};

type Car = {
  rig: CarRig;
  x: number;
  z: number;
  yaw: number;
  speed: number;
  kind: CarKind;
  role: "parked" | "traffic" | "police";
  hp: number;
  dead: boolean;
  deadT: number;
  ci: number;
  cj: number;
  dir: number;
  ti: number;
  tj: number;
  tx: number;
  tz: number;
  airT: number;
  airDur: number;
  airLock: number;
};

type Ped = {
  mesh: THREE.Group;
  x: number;
  z: number;
  tx: number;
  tz: number;
  yaw: number;
  speed: number;
  hp: number;
  dead: boolean;
  deadT: number;
  phase: number;
  state: "wander" | "flee";
  fleeT: number;
  crew: boolean;
};

type Foot = {
  mesh: THREE.Group;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  dead: boolean;
  deadT: number;
  cd: number;
  phase: number;
};

type Bullet = { mesh: THREE.Mesh; vel: THREE.Vector3; life: number; dmg: number; exp: boolean };
type Puff = {
  sprite: THREE.Sprite;
  mat: THREE.SpriteMaterial;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  grav: number;
};
type Drop = { mesh: THREE.Mesh; x: number; z: number; value: number; life: number };
type Bounty = { ped: Ped; value: number };

const DIRS = [
  { yaw: 0, ix: 0, iz: -1, lx: 3.5, lz: 0 },
  { yaw: Math.PI / 2, ix: -1, iz: 0, lx: 0, lz: -3.5 },
  { yaw: Math.PI, ix: 0, iz: 1, lx: -3.5, lz: 0 },
  { yaw: -Math.PI / 2, ix: 1, iz: 0, lx: 0, lz: 3.5 },
];

const PAINTS = [0xb4232e, 0x1d4e89, 0xc6a15a, 0x1f6a45, 0x4c2f78, 0xd8d4cc, 0x15171c, 0xb85a28, 0x0e6e78, 0x7a1e3a];
const KINDS: CarKind[] = ["sedan", "sports", "suv", "van"];
const SAVE_KEY = "liberty-drive-v1";

function lerpAngle(a: number, b: number, t: number) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * Math.min(1, t);
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function mountLiberty(canvas: HTMLCanvasElement, root: HTMLElement): LibertyHandle {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xb7c4d4, 90, 420);
  const camera = new THREE.PerspectiveCamera(68, window.innerWidth / window.innerHeight, 0.12, 800);

  try {
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = 0.78;
    pmrem.dispose();
  } catch {
    /* reflections are optional */
  }

  const skyMat = new THREE.ShaderMaterial({
    uniforms: {
      uTop: { value: new THREE.Color("#4d74ad") },
      uMid: { value: new THREE.Color("#d7b08a") },
      uBot: { value: new THREE.Color("#f0c39a") },
      uSun: { value: new THREE.Vector3(0, 0.2, -1) },
      uNight: { value: 0 },
      uFlash: { value: 0 },
    },
    vertexShader: "varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }",
    fragmentShader: `
      uniform vec3 uTop, uMid, uBot, uSun;
      uniform float uNight, uFlash;
      varying vec3 vP;
      void main() {
        vec3 d = normalize(vP);
        float h = d.y;
        vec3 col = mix(uBot, uMid, smoothstep(-0.2, 0.15, h));
        col = mix(col, uTop, smoothstep(0.05, 0.8, h));
        float sun = pow(max(dot(d, normalize(uSun)), 0.0), 96.0);
        col += vec3(1.0, 0.82, 0.55) * sun * (1.0 - uNight);
        float stars = step(0.998, fract(sin(dot(floor(d * 90.0), vec2(12.9, 78.2))) * 43758.5));
        col += stars * uNight * smoothstep(0.05, 0.35, h);
        col += vec3(0.75, 0.85, 1.0) * uFlash;
        gl_FragColor = vec4(col, 1.0);
      }
    `,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
  });
  scene.add(new THREE.Mesh(new THREE.SphereGeometry(520, 28, 16), skyMat));

  const sun = new THREE.DirectionalLight(0xfff0d2, 3.6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 8;
  sun.shadow.camera.far = 240;
  sun.shadow.camera.left = -70;
  sun.shadow.camera.right = 70;
  sun.shadow.camera.top = 70;
  sun.shadow.camera.bottom = -70;
  sun.shadow.bias = -0.00035;
  scene.add(sun, sun.target);
  const hemi = new THREE.HemisphereLight(0xc5d7ee, 0x2a241c, 0.62);
  const amb = new THREE.AmbientLight(0xffffff, 0.22);
  const fill = new THREE.DirectionalLight(0x8eb4d4, 0.35);
  fill.position.set(-40, 30, 20);
  scene.add(hemi, amb, fill);

  const city = buildCity(scene);
  const sfx = createSfx();

  const soft = (() => {
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const g = c.getContext("2d")!;
    const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    grd.addColorStop(0, "rgba(255,255,255,1)");
    grd.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grd;
    g.fillRect(0, 0, 64, 64);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  })();

  let saved: { money?: number; preset?: number; guns?: { mag: number; res: number }[]; best?: number } = {};
  try {
    saved = JSON.parse(localStorage.getItem(SAVE_KEY) || "{}") as typeof saved;
  } catch {
    saved = {};
  }

  let money = saved.money ?? 250;
  let best = saved.best ?? money;
  let presetIdx = saved.preset ?? 0;
  let wanted = 0;
  let wantedT = 0;
  let tod = 18.35;
  let weather: "clear" | "rain" = "clear";
  let cine = false;
  let lampMode: 0 | 1 | 2 = 0;
  let radio = 0;
  let radioAcc = 0;
  let radioStep = 0;
  let started = false;
  let paused = false;
  let titleAng = 0.4;
  let nightF = 0;
  let duskF = 0;
  let flash = 0;
  let shake = 0;
  let pain = 0;
  let combo = 0;
  let comboT = 0;
  let drift = 0;
  let braking = false;
  let steerNow = 0;
  let stunts = 0;
  let toastT = 0;
  let copTimer = 2;
  let bountyT = 12;
  let missionIdx = 0;
  let missionDelay = 0;
  let gameTime = 0;
  let saveT = 2;
  let qaSteer: number | null = null;
  const held = new Set<string>();
  const qa = new Set<string>();
  const touch = { x: 0, y: 0 };
  const look = { x: 0, y: 0 };
  let holdFire = false;
  let holdSprint = false;
  let holdBrake = false;
  let mouseFire = false;
  let padFire = false;
  let padSprint = false;
  let padBrake = false;
  let prevPadUse = false;

  const guns: Gun[] = [
    { name: "Pistol", kind: "pistol", dmg: 28, spread: 0.012, cd: 0.28, pellets: 1, speed: 120, range: 90, magSize: 12, mag: 12, res: 96, reload: 1.1 },
    { name: "SMG", kind: "smg", dmg: 14, spread: 0.04, cd: 0.08, pellets: 1, speed: 130, range: 70, magSize: 30, mag: 30, res: 180, reload: 1.5 },
    { name: "Shotgun", kind: "shotgun", dmg: 12, spread: 0.09, cd: 0.78, pellets: 8, speed: 100, range: 36, magSize: 6, mag: 6, res: 36, reload: 1.8 },
    { name: "Rocket", kind: "rpg", dmg: 90, spread: 0.02, cd: 1.25, pellets: 1, speed: 62, range: 90, magSize: 1, mag: 1, res: 6, reload: 2 },
  ];
  if (saved.guns) {
    saved.guns.forEach((g, i) => {
      const gun = guns[i];
      if (!gun || !g) return;
      gun.mag = g.mag;
      gun.res = g.res;
    });
  }
  let gunIdx = 0;
  let reloading = false;
  let reloadT = 0;

  const player = {
    x: 0,
    z: 18,
    vx: 0,
    vz: 0,
    yaw: 0,
    camYaw: 0,
    pitch: 0.42,
    hp: 100,
    car: null as Car | null,
    dead: false,
    deadT: 0,
    mesh: createCharacter(PRESETS[presetIdx] ?? PRESETS[0]!),
    cd: 0,
    phase: 0,
    nitro: 100,
  };
  player.mesh.position.set(player.x, 0, player.z);
  scene.add(player.mesh);

  const cars: Car[] = [];
  const peds: Ped[] = [];
  const feet: Foot[] = [];
  const bullets: Bullet[] = [];
  const puffs: Puff[] = [];
  const drops: Drop[] = [];
  const bounties: Bounty[] = [];
  const markers: THREE.Object3D[] = [];
  let heli: {
    rig: ReturnType<typeof createHeli>;
    angle: number;
    hp: number;
    dead: boolean;
    leaving: number;
    cd: number;
    x: number;
    y: number;
    z: number;
  } | null = null;

  const bulletGeo = new THREE.SphereGeometry(0.08, 6, 6);
  const bulletMat = new THREE.MeshBasicMaterial({ color: 0xffe08a });
  const rocketMat = new THREE.MeshBasicMaterial({ color: 0xff5a1f });
  const dropGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.12, 10);
  const skidGeo = new THREE.PlaneGeometry(0.45, 1.1);
  const skids: { mesh: THREE.Mesh; life: number }[] = [];
  const tracerGeo = new THREE.CylinderGeometry(0.03, 0.03, 1, 5);
  const tracers: { mesh: THREE.Mesh; life: number }[] = [];
  const up = new THREE.Vector3(0, 1, 0);
  const dirV = new THREE.Vector3();
  const camDesired = new THREE.Vector3();
  const lookAt = new THREE.Vector3();
  const heliLight = new THREE.SpotLight(0xd6e6ff, 0, 80, 0.42, 0.5, 1);
  scene.add(heliLight, heliLight.target);

  const rainGeo = new THREE.BufferGeometry();
  const rainPos = new Float32Array(1600 * 3);
  for (let i = 0; i < 1600; i++) {
    rainPos[i * 3] = (Math.random() - 0.5) * 70;
    rainPos[i * 3 + 1] = Math.random() * 40;
    rainPos[i * 3 + 2] = (Math.random() - 0.5) * 70;
  }
  rainGeo.setAttribute("position", new THREE.BufferAttribute(rainPos, 3));
  const rain = new THREE.Points(rainGeo, new THREE.PointsMaterial({ color: 0xb7d4ee, size: 0.12, transparent: true, opacity: 0.65 }));
  rain.visible = false;
  scene.add(rain);

  function spawnCar(x: number, z: number, yaw: number, color: number, kind: CarKind, role: Car["role"], police = false): Car {
    const rig = createCar(color, police ? "sedan" : kind, police);
    rig.group.position.set(x, 0, z);
    rig.group.rotation.y = yaw + Math.PI;
    scene.add(rig.group);
    const car: Car = {
      rig, x, z, yaw, speed: 0, kind: police ? "sedan" : kind, role, hp: police ? 160 : 100,
      dead: false, deadT: 0, ci: 0, cj: 0, dir: 0, ti: 0, tj: 0, tx: x, tz: z, airT: 0, airDur: 0, airLock: 0,
    };
    cars.push(car);
    return car;
  }

  spawnCar(5.1, 24, 0, 0xb4232e, "sports", "parked");
  spawnCar(-5.2, 34, Math.PI, 0x1d4e89, "sedan", "parked");
  spawnCar(4.4, 10, 0, 0x15171c, "moto", "parked");
  spawnCar(-4.6, -20, Math.PI, 0xc6a15a, "suv", "parked");
  for (let n = 0; n < 14; n++) {
    const ci = 1 + Math.floor(Math.random() * (GRID - 1));
    const cj = 1 + Math.floor(Math.random() * (GRID - 1));
    const dir = Math.floor(Math.random() * 4);
    const d = DIRS[dir]!;
    const x = gridPos(ci) + d.lx;
    const z = gridPos(cj) + d.lz;
    if (Math.hypot(x, z - 18) < 16) continue;
    const car = spawnCar(x, z, d.yaw, PAINTS[n % PAINTS.length]!, KINDS[n % KINDS.length]!, "traffic");
    car.ci = ci;
    car.cj = cj;
    car.dir = dir;
    car.speed = 8 + Math.random() * 4;
    retarget(car);
  }

  function sidewalk() {
    const b = city.blocks[Math.floor(Math.random() * city.blocks.length)]!;
    const side = Math.floor(Math.random() * 4);
    const u = Math.random();
    if (side === 0) return { x: b.x + u * b.w, z: b.z + 1.6 };
    if (side === 1) return { x: b.x + b.w - 1.6, z: b.z + u * b.d };
    if (side === 2) return { x: b.x + u * b.w, z: b.z + b.d - 1.6 };
    return { x: b.x + 1.6, z: b.z + u * b.d };
  }

  function spawnPed(x: number, z: number, crew = false, preset = 0) {
    const mesh = crew
      ? createCharacter(PRESETS[preset] ?? PRESETS[1]!)
      : createCharacter({
          name: "LOCAL",
          skin: [0xe8c0a0, 0xc48a62, 0x8a5638, 0xf0d2b4, 0x6b4226][Math.floor(Math.random() * 5)]!,
          hair: [0x1a1410, 0x3a2510, 0x111111, 0x8a7050][Math.floor(Math.random() * 4)]!,
          shirt: [0xb04a3a, 0x3a70b0, 0xc0b040, 0x4a9a60, 0x6a7a8a, 0xd8d8d8][Math.floor(Math.random() * 6)]!,
          pants: [0x1b1f28, 0x2a2620, 0x243044][Math.floor(Math.random() * 3)]!,
          shoes: 0x1a1c22,
          hairStyle: (["buzz", "recede", "bald"] as const)[Math.floor(Math.random() * 3)]!,
        });
    mesh.position.set(x, 0, z);
    scene.add(mesh);
    const tgt = sidewalk();
    peds.push({
      mesh, x, z, tx: tgt.x, tz: tgt.z, yaw: Math.random() * 6, speed: crew ? 1.7 : 1.5 + Math.random(),
      hp: crew ? 80 : 30, dead: false, deadT: 0, phase: Math.random() * 6, state: "wander", fleeT: 0, crew,
    });
  }
  for (let i = 0; i < 24; i++) {
    const p = sidewalk();
    spawnPed(p.x, p.z);
  }
  for (let i = 1; i < PRESETS.length; i++) {
    const ang = (i / PRESETS.length) * Math.PI * 2;
    spawnPed(Math.cos(ang) * 14, 18 + Math.sin(ang) * 14, true, i);
  }

  function q<T extends Element>(sel: string) {
    const n = root.querySelector(sel);
    if (!n) throw new Error(sel);
    return n as T;
  }
  const els = {
    money: q<HTMLElement>("#ld-money"),
    clock: q<HTMLElement>("#ld-clock"),
    title: q<HTMLElement>("#ld-mission-title"),
    desc: q<HTMLElement>("#ld-mission-desc"),
    status: q<HTMLElement>("#ld-mission-status"),
    kicker: q<HTMLElement>("#ld-mission-kicker"),
    weapon: q<HTMLElement>("#ld-weapon"),
    ammo: q<HTMLElement>("#ld-ammo"),
    speed: q<HTMLElement>("#ld-speed"),
    radio: q<HTMLElement>("#ld-radio"),
    hint: q<HTMLElement>("#ld-hint"),
    toast: q<HTMLElement>("#ld-toast"),
    combo: q<HTMLElement>("#ld-combo"),
    wasted: q<HTMLElement>("#ld-wasted"),
    pause: q<HTMLElement>("#ld-pause"),
    best: q<HTMLElement>("#ld-best"),
    stars: [...root.querySelectorAll("#ld-stars i")],
    slots: [...root.querySelectorAll(".ld-slots button")],
    pain: q<HTMLElement>(".ld-pain"),
  };
  const mapCanvas = q<HTMLCanvasElement>("#ld-map");
  const mapCtx = mapCanvas.getContext("2d")!;

  function toast(text: string) {
    toastT = 2.1;
    els.toast.textContent = text;
    els.toast.classList.add("on");
  }
  function hint(text: string) {
    els.hint.textContent = text;
    els.hint.classList.toggle("on", text.length > 0);
  }
  function persist() {
    best = Math.max(best, money);
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        v: 1, money, preset: presetIdx, best,
        guns: guns.map((g) => ({ mag: g.mag, res: g.res })),
      }));
    } catch {
      /* private mode */
    }
  }
  function addWanted(n: number) {
    wanted = Math.min(5, wanted + n);
    wantedT = 0;
  }
  function down(code: string) {
    return held.has(code) || qa.has(code);
  }

  function retarget(c: Car) {
    const d = DIRS[c.dir]!;
    const ni = c.ci + d.ix;
    const nj = c.cj + d.iz;
    if (ni < 0 || nj < 0 || ni > GRID || nj > GRID) {
      c.dir = (c.dir + 2) % 4;
      retarget(c);
      return;
    }
    c.ti = ni;
    c.tj = nj;
    c.tx = gridPos(ni) + d.lx;
    c.tz = gridPos(nj) + d.lz;
  }
  function chooseDir(c: Car) {
    const opts: number[] = [];
    for (let d = 0; d < 4; d++) {
      if (d === (c.dir + 2) % 4) continue;
      const dir = DIRS[d]!;
      const ni = c.ti + dir.ix;
      const nj = c.tj + dir.iz;
      if (ni < 0 || nj < 0 || ni > GRID || nj > GRID) continue;
      opts.push(d);
    }
    if (!opts.length) return (c.dir + 2) % 4;
    if (opts.includes(c.dir) && Math.random() < 0.62) return c.dir;
    return opts[Math.floor(Math.random() * opts.length)]!;
  }

  function syncCar(c: Car, dt: number, visualSteer: number) {
    let y = 0;
    if (c.airDur > 0) {
      const u = Math.min(1, c.airT / c.airDur);
      y = Math.sin(u * Math.PI) * (1.6 + Math.abs(c.speed) * 0.04);
      c.rig.group.rotation.x = -0.2 * Math.sin(u * Math.PI);
    } else c.rig.group.rotation.x = 0;
    c.rig.group.position.set(c.x, y, c.z);
    c.rig.group.rotation.y = c.yaw + Math.PI;
    c.rig.spin -= (c.speed * dt) / 0.36;
    for (const w of c.rig.wheels) {
      w.spin.rotation.x = c.rig.spin;
      w.steer.rotation.y = w.front ? visualSteer : 0;
    }
    const brakeGlow = c === player.car && braking;
    for (const t of c.rig.tails) t.emissiveIntensity = brakeGlow ? 4.5 : 0.7;
    const lights = lampMode === 1 || (lampMode === 0 && (nightF > 0.35 || duskF > 0.55));
    for (const h of c.rig.heads) h.emissiveIntensity = c === player.car ? (lights ? 3.2 : 0.45) : nightF > 0.4 ? 1.6 : 0.3;
    if (c.role === "police") {
      const blink = Math.sin(performance.now() / (90 + wanted * 8)) > 0;
      c.rig.siren.forEach((m, i) => {
        m.emissiveIntensity = blink === (i % 2 === 0) ? 6 : 0.15;
      });
    }
  }

  function puff(x: number, y: number, z: number, color: number, life: number, size: number, vx: number, vy: number, vz: number) {
    let p = puffs.find((item) => item.life <= 0);
    if (!p && puffs.length < 80) {
      const mat = new THREE.SpriteMaterial({ map: soft, color, transparent: true, depthWrite: false });
      const sprite = new THREE.Sprite(mat);
      scene.add(sprite);
      p = { sprite, mat, vx: 0, vy: 0, vz: 0, life: 0, max: 1, grav: 0 };
      puffs.push(p);
    }
    if (!p) return;
    p.mat.color.setHex(color);
    p.mat.opacity = 0.9;
    p.sprite.position.set(x, y, z);
    p.sprite.scale.setScalar(size);
    p.sprite.visible = true;
    p.life = p.max = life;
    p.vx = vx;
    p.vy = vy;
    p.vz = vz;
    p.grav = 0.4;
  }

  function skid(x: number, z: number, yaw: number) {
    if (skids.length > 220) {
      const old = skids.shift();
      if (old) {
        scene.remove(old.mesh);
        (old.mesh.material as THREE.Material).dispose();
      }
    }
    const mat = new THREE.MeshBasicMaterial({ color: 0x0a0a0c, transparent: true, opacity: 0.55, depthWrite: false });
    const mesh = new THREE.Mesh(skidGeo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.rotation.z = -yaw;
    mesh.position.set(x, 0.04, z);
    scene.add(mesh);
    skids.push({ mesh, life: 12 });
    sfx.skid();
  }

  function tracer(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, color: number) {
    let t = tracers.find((item) => item.life <= 0);
    if (!t && tracers.length < 16) {
      const mesh = new THREE.Mesh(tracerGeo, new THREE.MeshBasicMaterial({ color }));
      scene.add(mesh);
      t = { mesh, life: 0 };
      tracers.push(t);
    }
    if (!t) return;
    (t.mesh.material as THREE.MeshBasicMaterial).color.setHex(color);
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    const len = Math.hypot(dx, dy, dz) || 0.001;
    t.mesh.position.set((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2);
    t.mesh.scale.set(1, len, 1);
    t.mesh.quaternion.setFromUnitVectors(up, dirV.set(dx / len, dy / len, dz / len));
    t.mesh.visible = true;
    t.life = 0.07;
  }

  function explode(x: number, y: number, z: number) {
    sfx.explode();
    shake = Math.max(shake, 0.9);
    flash = Math.max(flash, 0.35);
    for (let i = 0; i < 14; i++) {
      const a = Math.random() * Math.PI * 2;
      puff(x, y + 0.6, z, i % 2 ? 0xfff1c2 : 0xff6a1a, 0.45 + Math.random() * 0.3, 0.8 + Math.random(), Math.cos(a) * 4, 2 + Math.random() * 3, Math.sin(a) * 4);
    }
    const R = 7.5;
    for (const p of peds) {
      if (!p.dead && Math.hypot(p.x - x, p.z - z) < R) killPed(p, true);
    }
    for (const c of cars) {
      if (!c.dead && c !== player.car && Math.hypot(c.x - x, c.z - z) < R + 1.5) damageCar(c, 140);
    }
    for (const f of feet) {
      if (!f.dead && Math.hypot(f.x - x, f.z - z) < R) f.hp = 0;
    }
    if (heli && !heli.dead && Math.hypot(heli.x - x, heli.z - z) < R + 4 && Math.abs(heli.y - y) < 10) damageHeli(120);
    const pd = Math.hypot(player.x - x, player.z - z);
    if (pd < R) hurt(Math.round(28 * (1 - pd / R)));
  }

  function damageCar(c: Car, dmg: number, boom = true) {
    if (c.dead) return;
    c.hp -= dmg;
    if (c.hp <= 0) {
      c.dead = true;
      c.deadT = 0;
      c.speed = 0;
      if (player.car === c) {
        player.car = null;
        player.mesh.visible = true;
        player.x = c.x;
        player.z = c.z;
      }
      if (boom) explode(c.x, 0.8, c.z);
      addWanted(1);
      money += 40;
    }
  }

  function damageHeli(dmg: number) {
    if (!heli || heli.dead) return;
    heli.hp -= dmg;
    if (heli.hp <= 0) {
      heli.dead = true;
      explode(heli.x, heli.y, heli.z);
      money += 900;
      toast("HELI DOWN +$900");
      sfx.chime();
      wanted = Math.max(0, wanted - 1);
    }
  }

  function killPed(p: Ped, byPlayer: boolean) {
    if (p.dead) return;
    p.dead = true;
    p.deadT = 0;
    const mat = new THREE.MeshBasicMaterial({ color: 0x6b1218, transparent: true, opacity: 0.8, depthWrite: false });
    const blot = new THREE.Mesh(new THREE.CircleGeometry(0.7, 8), mat);
    blot.rotation.x = -Math.PI / 2;
    blot.position.set(p.x, 0.045, p.z);
    scene.add(blot);
    if (byPlayer) {
      addWanted(1);
      sfx.scream();
      combo += 1;
      comboT = 3;
      const gain = 20 * combo;
      money += gain;
      dropCash(p.x, p.z, 12 + combo * 4);
      if (combo > 1) toast(`X${combo}  +$${gain}`);
      const bi = bounties.findIndex((b) => b.ped === p);
      if (bi >= 0) {
        const pay = bounties[bi]!.value;
        money += pay;
        toast(`BOUNTY +$${pay}`);
        sfx.chime();
        bounties.splice(bi, 1);
      }
    }
    for (const o of peds) {
      if (!o.dead && (o.x - p.x) ** 2 + (o.z - p.z) ** 2 < 320) {
        o.state = "flee";
        o.fleeT = 3.5;
      }
    }
  }

  function dropCash(x: number, z: number, value: number) {
    const mat = new THREE.MeshStandardMaterial({ color: 0xe4b15a, emissive: 0xc48a2a, emissiveIntensity: 0.4, metalness: 0.6, roughness: 0.35 });
    const mesh = new THREE.Mesh(dropGeo, mat);
    mesh.position.set(x, 0.4, z);
    scene.add(mesh);
    drops.push({ mesh, x, z, value, life: 18 });
  }

  function hurt(amount: number) {
    if (player.dead || !started || amount <= 0) return;
    player.hp = Math.max(0, player.hp - amount);
    pain = Math.min(0.7, pain + amount / 50);
    shake = Math.max(shake, 0.35);
    sfx.hurt();
    if (player.hp <= 0) {
      player.dead = true;
      player.deadT = 0;
      player.hp = 0;
      if (player.car) {
        player.car.speed = 0;
        player.car = null;
      }
      player.mesh.visible = true;
      player.mesh.position.set(player.x, 0, player.z);
      els.wasted.classList.add("on");
      root.classList.add("is-dead");
      sfx.engine(0, 0, false);
    }
  }

  function respawn() {
    player.dead = false;
    player.hp = 100;
    player.deadT = 0;
    player.x = 0;
    player.z = 18;
    player.vx = 0;
    player.vz = 0;
    player.yaw = 0;
    player.camYaw = 0;
    player.mesh.position.set(player.x, 0, player.z);
    player.mesh.rotation.set(0, Math.PI, 0);
    player.mesh.visible = true;
    els.wasted.classList.remove("on");
    root.classList.remove("is-dead");
    wanted = 0;
    for (const c of cars) if (c.role === "police") c.dead = true;
    for (const f of feet) {
      scene.remove(f.mesh);
    }
    feet.length = 0;
    if (heli) {
      scene.remove(heli.rig.group);
      heli = null;
      heliLight.intensity = 0;
    }
    startMission(missionIdx);
  }

  function fire() {
    const gun = guns[gunIdx]!;
    if (reloading || gun.mag <= 0) {
      tryReload();
      return;
    }
    const yaw = player.car ? player.car.yaw : player.camYaw;
    const ox = player.x + -Math.sin(yaw) * (player.car ? 2.3 : 0.4);
    const oz = player.z + -Math.cos(yaw) * (player.car ? 2.3 : 0.4);
    const oy = 1.35;
    for (let i = 0; i < gun.pellets; i++) {
      const ang = yaw + (Math.random() - 0.5) * gun.spread * 2;
      const vx = -Math.sin(ang) * gun.speed;
      const vz = -Math.cos(ang) * gun.speed;
      const mesh = new THREE.Mesh(bulletGeo, gun.kind === "rpg" ? rocketMat : bulletMat);
      if (gun.kind === "rpg") mesh.scale.setScalar(2.4);
      mesh.position.set(ox, oy, oz);
      scene.add(mesh);
      bullets.push({ mesh, vel: new THREE.Vector3(vx, 0, vz), life: gun.range / gun.speed, dmg: gun.dmg, exp: gun.kind === "rpg" });
    }
    while (bullets.length > 48) {
      const b = bullets.shift();
      if (b) scene.remove(b.mesh);
    }
    gun.mag -= 1;
    puff(ox, oy, oz, 0xffe7a8, 0.06, 0.45, 0, 0, 0);
    shake = Math.max(shake, gun.kind === "rpg" ? 0.7 : gun.kind === "shotgun" ? 0.4 : 0.16);
    sfx.gun(gun.kind);
    for (const p of peds) {
      if (!p.dead && (p.x - player.x) ** 2 + (p.z - player.z) ** 2 < 400) {
        p.state = "flee";
        p.fleeT = 2.5;
      }
    }
  }

  function tryReload() {
    const gun = guns[gunIdx]!;
    if (reloading || gun.mag >= gun.magSize || gun.res <= 0) return;
    reloading = true;
    reloadT = gun.reload;
    sfx.reload();
  }

  function nearestShop(): Shop | null {
    let best: Shop | null = null;
    let bd = 16;
    for (const s of city.shops) {
      if (s.cd > 0) continue;
      const d = (s.x - player.x) ** 2 + (s.z - player.z) ** 2;
      if (d < bd) {
        bd = d;
        best = s;
      }
    }
    return best;
  }
  function nearestCar() {
    let best: Car | null = null;
    let bd = 22;
    for (const c of cars) {
      if (c.dead || c === player.car) continue;
      const d = (c.x - player.x) ** 2 + (c.z - player.z) ** 2;
      if (d < bd) {
        bd = d;
        best = c;
      }
    }
    return best;
  }

  function interact() {
    if (!started || paused || player.dead) return;
    const shop = nearestShop();
    if (shop) {
      useShop(shop);
      return;
    }
    if (player.car) {
      const c = player.car;
      const rx = Math.cos(c.yaw);
      const rz = -Math.sin(c.yaw);
      player.car = null;
      player.mesh.visible = true;
      player.x = c.x + rx * 2.4;
      player.z = c.z + rz * 2.4;
      const hit = collide(player.x, player.z, 0.5, city.colliders);
      player.x = hit.x;
      player.z = hit.z;
      c.speed *= 0.12;
      sfx.door();
      sfx.engine(0, 0, false);
      return;
    }
    const car = nearestCar();
    if (!car) return;
    player.car = car;
    player.camYaw = car.yaw;
    player.mesh.visible = false;
    attachBeams(car.rig);
    if (car.role === "traffic") car.role = "parked";
    sfx.door();
  }

  function useShop(shop: Shop) {
    if (shop.type === "garage" && player.car) {
      if (money < 80) {
        toast("NEED $80");
        return;
      }
      money -= 80;
      const next = PAINTS[Math.floor(Math.random() * PAINTS.length)]!;
      player.car.rig.paint.color.setHex(next);
      toast("RESPRAY");
      sfx.chime();
      shop.cd = 1.2;
      return;
    }
    const price = shop.type === "health" ? 40 : shop.type === "ammo" ? 60 : 400;
    if (money < price) {
      toast(`NEED $${price}`);
      return;
    }
    money -= price;
    if (shop.type === "health") {
      player.hp = 100;
      toast("PATCHED UP");
    } else if (shop.type === "ammo") {
      for (const g of guns) g.res = Math.min(240, g.res + g.magSize * 3);
      toast("AMMO UP");
    } else {
      const yaw = player.camYaw;
      spawnCar(player.x - Math.sin(yaw) * 6, player.z - Math.cos(yaw) * 6, yaw, 0x1d4e89, "sports", "parked");
      toast("SPORTS DELIVERED");
    }
    sfx.chime();
    shop.cd = 1.4;
  }

  function swapCrew() {
    presetIdx = (presetIdx + 1) % PRESETS.length;
    scene.remove(player.mesh);
    player.mesh = createCharacter(PRESETS[presetIdx]!);
    player.mesh.visible = !player.car;
    player.mesh.position.set(player.x, 0, player.z);
    scene.add(player.mesh);
    toast(PRESETS[presetIdx]!.name);
    persist();
  }

  function clearMarkers() {
    for (const m of markers) scene.remove(m);
    markers.length = 0;
  }
  function pillar(x: number, z: number, color: number) {
    const group = new THREE.Group();
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.35, 0.08, 6, 22), mat);
    ring.rotation.x = Math.PI / 2;
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.24, 8, 6), mat);
    beam.position.y = 4;
    group.add(ring, beam);
    group.position.set(x, 0.05, z);
    scene.add(group);
    markers.push(group);
    return group;
  }

  type Mission = {
    title: string;
    desc: string;
    reward: number;
    setup: () => void;
    tick: (dt: number) => void;
    status: () => string;
    done: () => boolean;
    failed?: () => boolean;
  };
  let active: Mission | null = null;

  function makeMissions(): Mission[] {
    return [
      {
        title: "First Delivery",
        desc: "Drive the yellow marker. Stay in the car.",
        reward: 500,
        target: { x: 0, z: 0 },
        mark: null as THREE.Object3D | null,
        setup() {
          const b = city.blocks[Math.floor(Math.random() * city.blocks.length)]!;
          this.target = { x: b.x + 4, z: b.z + 4 };
          this.mark = pillar(this.target.x, this.target.z, 0xffd15c);
        },
        tick() {
          this.mark?.rotateY(0.02);
        },
        status() {
          return `${Math.round(Math.hypot(player.x - this.target.x, player.z - this.target.z))} m`;
        },
        done() {
          return !!player.car && Math.hypot(player.x - this.target.x, player.z - this.target.z) < 5;
        },
      },
      {
        title: "Eliminate",
        desc: "Drop the marked walker.",
        reward: 900,
        target: null as Ped | null,
        mark: null as THREE.Object3D | null,
        setup() {
          const pool = peds.filter((p) => !p.dead && !p.crew && Math.hypot(p.x - player.x, p.z - player.z) > 20);
          this.target = pool[Math.floor(Math.random() * pool.length)] ?? null;
          if (this.target) this.mark = pillar(this.target.x, this.target.z, 0xff4458);
        },
        tick() {
          if (this.target && this.mark) this.mark.position.set(this.target.x, 0.05, this.target.z);
        },
        status() {
          if (!this.target || this.target.dead) return "Down";
          return `${Math.round(Math.hypot(this.target.x - player.x, this.target.z - player.z))} m`;
        },
        done() {
          return !!this.target && this.target.dead;
        },
      },
      {
        title: "Heat Wave",
        desc: "Reach 3 stars and survive 20 seconds.",
        reward: 1800,
        start: null as number | null,
        setup() {
          this.start = null;
        },
        tick() {
          if (wanted >= 3 && this.start === null) this.start = gameTime;
          if (wanted < 3) this.start = null;
        },
        status() {
          if (this.start === null) return "Raise the heat";
          return `${Math.max(0, Math.ceil(20 - (gameTime - this.start)))} s`;
        },
        done() {
          return this.start !== null && gameTime - this.start >= 20;
        },
      },
      {
        title: "Collector",
        desc: "Pick up three cash drops.",
        reward: 1200,
        left: 3,
        setup() {
          this.left = 3;
          clearMarkers();
          for (let i = 0; i < 3; i++) {
            const b = city.blocks[Math.floor(Math.random() * city.blocks.length)]!;
            const x = b.x + b.w * 0.5;
            const z = b.z + 3;
            const mark = pillar(x, z, 0x3dce7a);
            mark.userData.drop = { x, z, taken: false };
          }
        },
        tick() {
          let left = 0;
          for (const m of markers) {
            const d = m.userData.drop as { x: number; z: number; taken: boolean } | undefined;
            if (!d || d.taken) continue;
            m.rotateY(0.03);
            if (Math.hypot(player.x - d.x, player.z - d.z) < 3) {
              d.taken = true;
              m.visible = false;
              sfx.chime();
            } else left += 1;
          }
          this.left = left;
        },
        status() {
          return `${3 - this.left} / 3`;
        },
        done() {
          return this.left <= 0 && markers.length > 0;
        },
      },
      {
        title: "The Heist",
        desc: "Stand in the blue zone, then lose the cops.",
        reward: 3000,
        phase: "rob" as "rob" | "run",
        prog: 0,
        target: { x: 0, z: 0 },
        setup() {
          const b = city.blocks[8] ?? city.blocks[0]!;
          this.target = { x: b.x + b.w / 2, z: b.z + 4 };
          this.phase = "rob";
          this.prog = 0;
          pillar(this.target.x, this.target.z, 0x44aaff);
        },
        tick(dt) {
          if (this.phase !== "rob") return;
          const near = Math.hypot(player.x - this.target.x, player.z - this.target.z) < 4.5 && !player.car;
          this.prog = near ? this.prog + dt : Math.max(0, this.prog - dt * 0.5);
          if (this.prog >= 6) {
            this.phase = "run";
            addWanted(4);
            clearMarkers();
            toast("ESCAPE");
          }
        },
        status() {
          if (this.phase === "rob") return `Hold ${Math.min(6, this.prog).toFixed(1)} / 6s`;
          return wanted === 0 ? "Clear" : "Lose the stars";
        },
        done() {
          return this.phase === "run" && wanted === 0;
        },
      },
      {
        title: "Night Race",
        desc: "Hit four gates before the clock dies.",
        reward: 1600,
        time: 70,
        hit: 0,
        setup() {
          this.time = 70;
          this.hit = 0;
          clearMarkers();
          for (let i = 0; i < 4; i++) {
            const b = city.blocks[Math.floor(Math.random() * city.blocks.length)]!;
            const mark = pillar(b.x + b.w / 2, b.z + b.d / 2, 0xff4d9a);
            mark.userData.gate = false;
          }
        },
        tick(dt) {
          this.time -= dt;
          let hit = 0;
          for (const m of markers) {
            if (m.userData.gate) {
              hit += 1;
              continue;
            }
            m.rotateY(0.04);
            if (Math.hypot(player.x - m.position.x, player.z - m.position.z) < 5) {
              m.userData.gate = true;
              m.visible = false;
              sfx.chime();
            }
          }
          this.hit = hit;
        },
        status() {
          return `${this.hit} / 4 · ${Math.max(0, Math.ceil(this.time))}s`;
        },
        done() {
          return this.hit >= 4;
        },
        failed() {
          return this.time <= 0 && this.hit < 4;
        },
      },
      {
        title: "Stunt School",
        desc: "Catch air off three ramps.",
        reward: 1400,
        base: 0,
        setup() {
          this.base = stunts;
          clearMarkers();
          for (const r of city.ramps) pillar(r.x, r.z, 0xff9a1f);
        },
        tick() {
          for (const m of markers) m.rotateY(0.02);
        },
        status() {
          return `${Math.min(3, stunts - this.base)} / 3 jumps`;
        },
        done() {
          return stunts - this.base >= 3;
        },
      },
    ];
  }
  const missions = makeMissions();

  function startMission(index: number) {
    clearMarkers();
    if (index >= missions.length) {
      active = null;
      els.kicker.textContent = "Free roam";
      els.title.textContent = "City's open";
      els.desc.textContent = "Bounties, shops, and empty lanes.";
      els.status.textContent = "";
      return;
    }
    missionIdx = index;
    const m = missions[index]!;
    active = m;
    m.setup();
    els.kicker.textContent = `Contract ${index + 1}`;
    els.title.textContent = m.title;
    els.desc.textContent = m.desc;
    els.status.textContent = "";
    toast(m.title.toUpperCase());
    sfx.chime();
  }

  function completeMission() {
    if (!active) return;
    const reward = active.reward;
    money += reward;
    toast(`PAID +$${reward}`);
    sfx.chime();
    clearMarkers();
    active = null;
    missionIdx += 1;
    missionDelay = 2.3;
    els.title.textContent = "Contract paid";
    els.desc.textContent = `+$${reward}`;
    els.status.textContent = "";
    persist();
  }

  function axes() {
    let throttle = 0;
    let strafe = 0;
    let steer = 0;
    if (down("KeyW") || down("ArrowUp")) throttle += 1;
    if (down("KeyS") || down("ArrowDown")) throttle -= 1;
    if (down("KeyA") || down("ArrowLeft")) {
      strafe -= 1;
      steer += 1;
    }
    if (down("KeyD") || down("ArrowRight")) {
      strafe += 1;
      steer -= 1;
    }
    if (touch.y < -0.22) throttle = Math.max(throttle, Math.min(1, -touch.y));
    if (touch.y > 0.22) throttle = Math.min(throttle, Math.max(-1, -touch.y));
    if (touch.x < -0.22) {
      steer = Math.max(steer, Math.min(1, -touch.x));
      strafe = Math.min(strafe, touch.x);
    }
    if (touch.x > 0.22) {
      steer = Math.min(steer, Math.max(-1, -touch.x));
      strafe = Math.max(strafe, Math.min(1, touch.x));
    }
    const pads = navigator.getGamepads?.() ?? [];
    const pad = pads[0];
    if (pad) {
      const ax = pad.axes[0] ?? 0;
      const ay = pad.axes[1] ?? 0;
      if (ay < -0.22) throttle = Math.max(throttle, Math.min(1, -ay));
      if (ay > 0.22) throttle = Math.min(throttle, Math.max(-1, -ay));
      if (ax < -0.22) {
        steer = Math.max(steer, Math.min(1, -ax));
        strafe = Math.min(strafe, ax);
      }
      if (ax > 0.22) {
        steer = Math.min(steer, Math.max(-1, -ax));
        strafe = Math.max(strafe, Math.min(1, ax));
      }
      const pressed = (i: number) => !!pad.buttons[i]?.pressed;
      padFire = pressed(7) || pressed(5);
      padSprint = pressed(1);
      padBrake = pressed(6);
      const use = pressed(0);
      if (use && !prevPadUse) interact();
      prevPadUse = use;
    } else {
      padFire = false;
      padSprint = false;
      padBrake = false;
    }
    if (qaSteer !== null) steer = qaSteer;
    const sprint = holdSprint || padSprint || down("ShiftLeft") || down("ShiftRight");
    const brake = holdBrake || padBrake || down("Space");
    return { throttle, strafe, steer, sprint, brake };
  }

  function updatePlayer(dt: number) {
    const input = axes();
    steerNow = input.steer;
    braking = input.brake;
    player.camYaw -= look.x * 2.5 * dt;
    player.pitch = clamp(player.pitch + look.y * 1.6 * dt, -0.2, 1.05);
    const pads = navigator.getGamepads?.() ?? [];
    const pad = pads[0];
    if (pad) {
      const rx = pad.axes[2] ?? 0;
      const ry = pad.axes[3] ?? 0;
      if (Math.abs(rx) > 0.18) player.camYaw -= rx * 1.8 * dt;
      if (Math.abs(ry) > 0.18) player.pitch = clamp(player.pitch + ry * 1.2 * dt, -0.2, 1.05);
    }
    if (reloading) {
      reloadT -= dt;
      if (reloadT <= 0) {
        const gun = guns[gunIdx]!;
        const take = Math.min(gun.magSize - gun.mag, gun.res);
        gun.mag += take;
        gun.res -= take;
        reloading = false;
      }
    }
    const firing = mouseFire || holdFire || padFire;
    if (player.car) {
      const c = player.car;
      const boost = input.sprint && player.nitro > 1 && input.throttle > 0;
      if (boost) player.nitro = Math.max(0, player.nitro - 36 * dt);
      else player.nitro = Math.min(100, player.nitro + 14 * dt);
      const moto = c.kind === "moto";
      const accel = (moto ? 78 : 50) * (boost ? 1.8 : 1);
      const max = (moto ? 76 : 54) * (boost ? 1.5 : 1);
      if (input.throttle > 0) c.speed += accel * dt * input.throttle;
      else if (input.throttle < 0) c.speed -= (accel + 16) * dt;
      else c.speed *= Math.pow(0.18, dt);
      if (input.brake) c.speed *= Math.pow(0.1, dt);
      c.speed = clamp(c.speed, -16, max);
      const grip = Math.min(1, Math.abs(c.speed) / 11);
      const reverse = c.speed >= 0 ? 1 : -1;
      // Skill basis: +yaw is left on a chase cam. A adds steer.
      c.yaw += input.steer * 2.25 * grip * (input.brake ? 1.4 : 1) * reverse * dt;
      const fx = -Math.sin(c.yaw);
      const fz = -Math.cos(c.yaw);
      c.x += fx * c.speed * dt;
      c.z += fz * c.speed * dt;
      const before = collide(c.x, c.z, 1.55, city.colliders);
      if (before.push > 0.05 && Math.abs(c.speed) > 5) {
        c.speed *= 0.62;
        shake = Math.max(shake, 0.3);
        sfx.crash(Math.min(1, Math.abs(c.speed) / 40));
      }
      c.x = before.x;
      c.z = before.z;
      c.airLock = Math.max(0, c.airLock - dt);
      if (c.airDur > 0) {
        c.airT += dt;
        if (c.airT >= c.airDur) {
          const pay = Math.round(18 + c.airDur * Math.abs(c.speed) * 0.4);
          money += pay;
          stunts += 1;
          toast(`AIR +$${pay}`);
          sfx.crash(0.25);
          shake = Math.max(shake, 0.4);
          c.airDur = 0;
          c.airLock = 0.8;
        }
      } else if (c.airLock <= 0 && Math.abs(c.speed) > 13) {
        for (const r of city.ramps) {
          if (Math.hypot(c.x - r.x, c.z - r.z) < 3.3) {
            c.airDur = 0.78 + Math.min(0.45, Math.abs(c.speed) * 0.01);
            c.airT = 0;
            break;
          }
        }
      }
      if (input.brake && Math.abs(input.steer) > 0.45 && Math.abs(c.speed) > 14 && c.airDur === 0) {
        drift += dt * Math.abs(c.speed) * 0.35;
        if (Math.random() < 0.4) skid(c.x, c.z, c.yaw);
        puff(c.x, 0.3, c.z, 0x9aa0aa, 0.4, 0.7, 0, 0.4, 0);
      } else if (drift > 12) {
        const pay = Math.round(drift);
        money += pay;
        toast(`DRIFT +$${pay}`);
        drift = 0;
      } else drift = Math.max(0, drift - dt * 8);
      if (boost && Math.random() < 0.8) {
        puff(c.x + Math.sin(c.yaw) * 2, 0.4, c.z + Math.cos(c.yaw) * 2, 0x7eb6ff, 0.18, 0.45, 0, 0.2, 0);
      }
      if (Math.abs(c.speed) > 2 && Math.random() < dt * 8) {
        puff(c.x + Math.sin(c.yaw) * 1.8, 0.35, c.z + Math.cos(c.yaw) * 1.8, 0x66707c, 0.35, 0.35, 0, 0.5, 0);
      }
      if (Math.abs(c.speed) > 8) {
        for (const ped of peds) {
          if (!ped.dead && (ped.x - c.x) ** 2 + (ped.z - c.z) ** 2 < 5) killPed(ped, true);
        }
      }
      player.x = c.x;
      player.z = c.z;
      if (Math.abs(c.speed) > 2) player.camYaw = lerpAngle(player.camYaw, c.yaw, 1 - Math.exp(-3.4 * dt));
      syncCar(c, dt, input.steer * 0.42);
      sfx.engine(c.speed * (boost ? 1.3 : 1), input.throttle, true);
      const want = boost ? 78 : cine ? 58 : 68;
      if (Math.abs(camera.fov - want) > 0.35) {
        camera.fov += (want - camera.fov) * Math.min(1, 5 * dt);
        camera.updateProjectionMatrix();
      }
    } else {
      player.nitro = Math.min(100, player.nitro + 10 * dt);
      const cy = player.camYaw;
      const fx = -Math.sin(cy);
      const fz = -Math.cos(cy);
      const rx = Math.cos(cy);
      const rz = -Math.sin(cy);
      let ix = fx * input.throttle + rx * input.strafe;
      let iz = fz * input.throttle + rz * input.strafe;
      const len = Math.hypot(ix, iz);
      const spd = input.sprint ? 10 : 6.4;
      if (len > 0.05) {
        ix /= len;
        iz /= len;
        player.vx += (ix * spd - player.vx) * Math.min(1, 12 * dt);
        player.vz += (iz * spd - player.vz) * Math.min(1, 12 * dt);
        player.yaw = Math.atan2(-ix, -iz);
      } else {
        player.vx *= Math.pow(0.001, dt);
        player.vz *= Math.pow(0.001, dt);
      }
      player.x += player.vx * dt;
      player.z += player.vz * dt;
      const hit = collide(player.x, player.z, 0.5, city.colliders);
      player.x = hit.x;
      player.z = hit.z;
      const moving = Math.hypot(player.vx, player.vz);
      player.phase += moving * dt * 3.2;
      const face = firing || moving < 0.4 ? player.camYaw : player.yaw;
      player.mesh.rotation.y = lerpAngle(player.mesh.rotation.y, face + Math.PI, 1 - Math.exp(-12 * dt));
      player.mesh.position.set(player.x, 0, player.z);
      const limbs = limbsOf(player.mesh);
      const sw = Math.sin(player.phase) * Math.min(0.75, moving * 0.12);
      limbs.legs[0]!.rotation.x = sw;
      limbs.legs[1]!.rotation.x = -sw;
      limbs.arms[0]!.rotation.x = -sw * 0.7;
      limbs.arms[1]!.rotation.x = sw * 0.7;
      if (moving > 1.4 && Math.random() < dt * 3) sfx.step();
      sfx.engine(0, 0, false);
      if (Math.abs(camera.fov - (cine ? 58 : 68)) > 0.4) {
        camera.fov += ((cine ? 58 : 68) - camera.fov) * Math.min(1, 4 * dt);
        camera.updateProjectionMatrix();
      }
    }
    player.cd -= dt;
    if (firing && player.cd <= 0 && !reloading) {
      player.cd = guns[gunIdx]!.cd;
      fire();
    }
    const shop = nearestShop();
    const car = !player.car ? nearestCar() : null;
    if (shop) {
      const label = shop.type === "health" ? "Use — heal $40" : shop.type === "ammo" ? "Use — ammo $60" : player.car ? "Use — respray $80" : "Use — sports $400";
      hint(label);
    } else if (car || player.car) hint(player.car ? "Use — exit" : "Use — enter");
    else hint("");
  }

  function updatePeds(dt: number) {
    for (let i = peds.length - 1; i >= 0; i--) {
      const p = peds[i]!;
      if (p.dead) {
        p.deadT += dt;
        p.mesh.rotation.x = Math.min(1.25, p.deadT * 2.2);
        p.mesh.position.y = -Math.min(0.45, p.deadT * 0.25);
        if (p.deadT > 12) {
          scene.remove(p.mesh);
          peds.splice(i, 1);
        }
        continue;
      }
      p.fleeT = Math.max(0, p.fleeT - dt);
      if (p.state === "flee" && p.fleeT <= 0) p.state = "wander";
      let tx = p.tx;
      let tz = p.tz;
      let spd = p.speed;
      if (p.state === "flee") {
        const dx = p.x - player.x;
        const dz = p.z - player.z;
        const d = Math.hypot(dx, dz) || 1;
        tx = p.x + (dx / d) * 12;
        tz = p.z + (dz / d) * 12;
        spd *= 2.6;
      } else if ((p.tx - p.x) ** 2 + (p.tz - p.z) ** 2 < 3) {
        const n = sidewalk();
        p.tx = n.x;
        p.tz = n.z;
      }
      const dx = tx - p.x;
      const dz = tz - p.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.2) {
        p.x += (dx / d) * spd * dt;
        p.z += (dz / d) * spd * dt;
        const hit = collide(p.x, p.z, 0.45, city.colliders);
        p.x = hit.x;
        p.z = hit.z;
        p.yaw = Math.atan2(dx, dz);
      }
      p.mesh.position.set(p.x, 0, p.z);
      p.mesh.rotation.y = p.yaw;
      p.phase += spd * dt * 3;
      const limbs = limbsOf(p.mesh);
      const sw = Math.sin(p.phase) * (p.state === "flee" ? 0.85 : 0.55);
      limbs.legs[0]!.rotation.x = sw;
      limbs.legs[1]!.rotation.x = -sw;
      limbs.arms[0]!.rotation.x = -sw * 0.6;
      limbs.arms[1]!.rotation.x = sw * 0.6;
      if (Math.hypot(p.x - player.x, p.z - player.z) > 130) p.mesh.visible = false;
      else p.mesh.visible = true;
    }
    if (peds.length < 20 && Math.random() < dt * 0.4) {
      const s = sidewalk();
      if (Math.hypot(s.x - player.x, s.z - player.z) > 25) spawnPed(s.x, s.z);
    }
  }

  function updateCars(dt: number) {
    for (const c of cars) {
      if (c === player.car) continue;
      if (c.dead) {
        c.deadT += dt;
        c.rig.group.rotation.z = Math.min(0.4, c.deadT);
        if (c.deadT > 8) c.rig.group.visible = false;
        continue;
      }
      if (c.role === "traffic" || c.role === "police") {
        const dx = (c.role === "police" ? player.x : c.tx) - c.x;
        const dz = (c.role === "police" ? player.z : c.tz) - c.z;
        const dist = Math.hypot(dx, dz);
        if (c.role === "traffic" && dist < 3.2) {
          c.ci = c.ti;
          c.cj = c.tj;
          c.dir = chooseDir(c);
          retarget(c);
        }
        const desired = Math.atan2(-dx, -dz);
        c.yaw = lerpAngle(c.yaw, desired, 1 - Math.exp(-(c.role === "police" ? 3.4 : 2.6) * dt));
        const cap = c.role === "police" ? (player.dead ? 0 : dist > 16 ? 18 + wanted * 2 : 7) : 13;
        c.speed += (cap - c.speed) * Math.min(1, 1.6 * dt);
        c.x += -Math.sin(c.yaw) * c.speed * dt;
        c.z += -Math.cos(c.yaw) * c.speed * dt;
        const hit = collide(c.x, c.z, 1.5, city.colliders);
        if (hit.push > 0.08) c.speed *= 0.7;
        c.x = hit.x;
        c.z = hit.z;
        if (c.role === "police") {
          c.rig.group.position.set(c.x, 0, c.z);
          const dd = Math.hypot(player.x - c.x, player.z - c.z);
          if (!player.dead && dd < 46 && Math.random() < dt * (0.45 + wanted * 0.08)) {
            hurt(wanted >= 4 ? 8 : 5);
            sfx.gun("pistol");
            tracer(c.x, 1.2, c.z, player.x, 1.2, player.z, 0xffd0a0);
          }
          if (!player.car && dd < 14 && Math.abs(c.speed) < 10 && feet.length < 4 && Math.random() < dt * 0.35) {
            const mesh = createCharacter(PRESETS[4]!);
            mesh.position.set(c.x + 1.5, 0, c.z);
            scene.add(mesh);
            feet.push({ mesh, x: c.x + 1.5, z: c.z, yaw: 0, hp: 50, dead: false, deadT: 0, cd: 0.6, phase: 0 });
            sfx.door();
          }
          if (dd > 220) c.dead = true;
        }
      } else {
        c.speed *= Math.pow(0.25, dt);
      }
      syncCar(c, dt, 0);
      if (Math.abs(c.speed) > 7) {
        for (const p of peds) {
          if (p.dead) continue;
          if ((p.x - c.x) ** 2 + (p.z - c.z) ** 2 < 4.6) {
            killPed(p, c === player.car);
            c.speed *= 0.9;
            break;
          }
        }
      }
    }
    for (let i = 0; i < cars.length; i++) {
      for (let j = i + 1; j < cars.length; j++) {
        const a = cars[i]!;
        const b = cars[j]!;
        if (a.dead || b.dead) continue;
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const d = Math.hypot(dx, dz) || 0.001;
        if (d < 2.8) {
          const k = ((2.8 - d) / 2) / d;
          a.x -= dx * k;
          a.z -= dz * k;
          b.x += dx * k;
          b.z += dz * k;
          if (Math.abs(a.speed) + Math.abs(b.speed) > 10) {
            a.speed *= 0.86;
            b.speed *= 0.86;
          }
        }
      }
    }
  }

  function updateFeet(dt: number) {
    for (let i = feet.length - 1; i >= 0; i--) {
      const f = feet[i]!;
      if (f.hp <= 0 && !f.dead) {
        f.dead = true;
        addWanted(1);
        money += 60;
      }
      if (f.dead) {
        f.deadT += dt;
        f.mesh.rotation.x = Math.min(1.2, f.deadT * 2);
        if (f.deadT > 6) {
          scene.remove(f.mesh);
          feet.splice(i, 1);
        }
        continue;
      }
      const dx = player.x - f.x;
      const dz = player.z - f.z;
      const dist = Math.hypot(dx, dz) || 1;
      if (dist > 4) {
        f.x += (dx / dist) * 5.2 * dt;
        f.z += (dz / dist) * 5.2 * dt;
        const hit = collide(f.x, f.z, 0.45, city.colliders);
        f.x = hit.x;
        f.z = hit.z;
      }
      f.yaw = Math.atan2(dx, dz);
      f.mesh.position.set(f.x, 0, f.z);
      f.mesh.rotation.y = f.yaw;
      f.phase += dt * 8;
      const limbs = limbsOf(f.mesh);
      const sw = Math.sin(f.phase) * 0.7;
      limbs.legs[0]!.rotation.x = sw;
      limbs.legs[1]!.rotation.x = -sw;
      f.cd -= dt;
      if (!player.dead && dist < 28 && f.cd <= 0) {
        f.cd = 0.85 + Math.random() * 0.4;
        hurt(6);
        sfx.gun("pistol");
        tracer(f.x, 1.3, f.z, player.x, 1.2, player.z, 0xffe0b0);
      }
    }
  }

  function spawnCop() {
    const yaw = player.camYaw + Math.PI + (Math.random() - 0.5);
    const dist = 70 + Math.random() * 20;
    const x = player.x - Math.sin(player.camYaw) * dist;
    const z = player.z - Math.cos(player.camYaw) * dist;
    const c = spawnCar(x, z, yaw, 0x101828, "sedan", "police", true);
    c.speed = 16;
    sfx.siren();
  }

  function updateHeli(dt: number) {
    if (wanted >= 4 && !heli) {
      const rig = createHeli();
      scene.add(rig.group);
      heli = { rig, angle: 0, hp: 140, dead: false, leaving: 0, cd: 1, x: player.x, y: 18, z: player.z };
    }
    if (!heli) {
      heliLight.intensity = 0;
      return;
    }
    if (wanted < 4 && !heli.dead) heli.leaving += dt;
    heli.angle += dt * 0.45;
    const rad = 24;
    heli.x = player.x + Math.cos(heli.angle) * rad;
    heli.z = player.z + Math.sin(heli.angle) * rad;
    const goalY = heli.dead || heli.leaving > 0 ? 48 : 16;
    heli.y += (goalY - heli.y) * Math.min(1, dt);
    heli.rig.group.position.set(heli.x, heli.y, heli.z);
    heli.rig.group.rotation.y = -heli.angle;
    heli.rig.mainRotor.rotation.y += dt * 22;
    heli.rig.tailRotor.rotation.x += dt * 28;
    heliLight.position.set(heli.x, heli.y - 0.5, heli.z);
    heliLight.target.position.set(player.x, 0, player.z);
    heliLight.intensity = heli.dead || heli.leaving > 0 ? 0 : 30;
    if (!heli.dead && heli.leaving === 0 && wanted >= 5) {
      heli.cd -= dt;
      if (heli.cd <= 0 && !player.dead) {
        heli.cd = 1.3;
        hurt(7);
        tracer(heli.x, heli.y, heli.z, player.x, 1, player.z, 0xff5530);
        sfx.gun("smg");
      }
    }
    if (heli.y > 44 && (heli.dead || heli.leaving > 0.5)) {
      scene.remove(heli.rig.group);
      heli = null;
    }
  }

  function updateBullets(dt: number) {
    for (let i = bullets.length - 1; i >= 0; i--) {
      const b = bullets[i]!;
      b.life -= dt;
      b.mesh.position.addScaledVector(b.vel, dt);
      const p = b.mesh.position;
      let hit = blocked(p.x, p.z, city.colliders) && p.y < 40;
      if (!hit) {
        for (const ped of peds) {
          if (ped.dead) continue;
          if ((ped.x - p.x) ** 2 + (ped.z - p.z) ** 2 < 0.8 && Math.abs(1.2 - p.y) < 1.3) {
            const head = Math.abs(p.y - 1.7) < 0.28;
            ped.hp -= b.dmg * (head ? 2.2 : 1);
            if (ped.hp <= 0) {
              killPed(ped, true);
              if (head) toast("HEADSHOT");
            } else {
              ped.state = "flee";
              ped.fleeT = 3;
            }
            hit = true;
            break;
          }
        }
      }
      if (!hit) {
        for (const f of feet) {
          if (f.dead) continue;
          if ((f.x - p.x) ** 2 + (f.z - p.z) ** 2 < 0.8 && Math.abs(1.2 - p.y) < 1.3) {
            f.hp -= b.dmg;
            hit = true;
            break;
          }
        }
      }
      if (!hit) {
        for (const c of cars) {
          if (c.dead || c === player.car) continue;
          if ((c.x - p.x) ** 2 + (c.z - p.z) ** 2 < 3.2 && p.y < 2.2) {
            damageCar(c, b.dmg, !b.exp);
            hit = true;
            break;
          }
        }
      }
      if (!hit && heli && !heli.dead) {
        if ((heli.x - p.x) ** 2 + (heli.z - p.z) ** 2 + (heli.y - p.y) ** 2 < 42) {
          damageHeli(b.dmg);
          hit = true;
        }
      }
      if (hit || b.life <= 0) {
        if (b.exp) explode(p.x, p.y, p.z);
        scene.remove(b.mesh);
        bullets.splice(i, 1);
      }
    }
  }

  function updateFx(dt: number) {
    for (const p of puffs) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.sprite.position.x += p.vx * dt;
      p.sprite.position.y += p.vy * dt;
      p.sprite.position.z += p.vz * dt;
      p.vy -= p.grav * dt;
      const u = Math.max(0, p.life / p.max);
      p.mat.opacity = u;
      p.sprite.scale.multiplyScalar(1 + dt * 1.4);
      if (p.life <= 0) p.sprite.visible = false;
    }
    for (let i = skids.length - 1; i >= 0; i--) {
      const s = skids[i]!;
      s.life -= dt;
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, s.life / 12) * 0.55;
      if (s.life <= 0) {
        scene.remove(s.mesh);
        skids.splice(i, 1);
      }
    }
    for (const t of tracers) {
      if (t.life <= 0) continue;
      t.life -= dt;
      if (t.life <= 0) t.mesh.visible = false;
    }
    for (let i = drops.length - 1; i >= 0; i--) {
      const d = drops[i]!;
      d.life -= dt;
      d.mesh.rotation.y += dt * 2;
      d.mesh.position.y = 0.35 + Math.sin(performance.now() / 200 + i) * 0.08;
      if ((d.x - player.x) ** 2 + (d.z - player.z) ** 2 < 2.2) {
        money += d.value;
        scene.remove(d.mesh);
        drops.splice(i, 1);
        sfx.chime();
        continue;
      }
      if (d.life <= 0) {
        scene.remove(d.mesh);
        drops.splice(i, 1);
      }
    }
  }

  function updateBounties(dt: number) {
    bountyT -= dt;
    if (bountyT <= 0) {
      bountyT = 26 + Math.random() * 12;
      const pool = peds.filter((p) => !p.dead && !p.crew && !bounties.some((b) => b.ped === p));
      const ped = pool[Math.floor(Math.random() * pool.length)];
      if (ped) {
        const value = 220 + Math.floor(Math.random() * 380);
        bounties.push({ ped, value });
        toast(`BOUNTY $${value}`);
      }
    }
    for (let i = bounties.length - 1; i >= 0; i--) if (bounties[i]!.ped.dead) bounties.splice(i, 1);
  }

  function updateSky(dt: number) {
    tod = (tod + (dt * 24) / 260) % 24;
    const ang = ((tod - 6) / 24) * Math.PI * 2;
    const sy = Math.sin(ang);
    const sx = Math.cos(ang);
    const day = Math.max(0, sy);
    nightF = Math.max(0, -sy);
    duskF = Math.max(0, 1 - Math.abs(sy) * 2.6);
    sun.position.set(player.x + sx * 150, Math.max(8, sy * 130 + 10), player.z + 30);
    sun.target.position.set(player.x, 0, player.z);
    sun.target.updateMatrixWorld();
    const expo = cine ? 0.86 : 1.08;
    renderer.toneMappingExposure = expo;
    sun.intensity = (day * 3.5 + duskF * 1.15 + nightF * 0.15) * (cine ? 0.75 : 1);
    sun.color.set("#fff0d0").lerp(new THREE.Color("#ff7a3c"), duskF).lerp(new THREE.Color("#223055"), nightF);
    hemi.intensity = 0.18 + day * 0.5;
    amb.intensity = 0.12 + day * 0.18 + nightF * 0.05;
    (skyMat.uniforms.uTop.value as THREE.Color).set("#07101f").lerp(new THREE.Color("#4d74ad"), day).lerp(new THREE.Color("#3a1d42"), duskF);
    (skyMat.uniforms.uMid.value as THREE.Color).set("#10192c").lerp(new THREE.Color("#d7c2a4"), Math.max(day, duskF));
    (skyMat.uniforms.uBot.value as THREE.Color).set("#1a140e").lerp(new THREE.Color("#f2c39a"), duskF).lerp(new THREE.Color("#9eb6d4"), day);
    (skyMat.uniforms.uSun.value as THREE.Vector3).set(sx, sy, 0.2).normalize();
    skyMat.uniforms.uNight.value = nightF;
    skyMat.uniforms.uFlash.value = flash;
    scene.fog?.color.copy(skyMat.uniforms.uMid.value as THREE.Color);
    for (const m of city.nightMats) m.emissiveIntensity = 0.08 + nightF * 1.25 + duskF * 0.35;
    city.bulbMat.emissiveIntensity = 0.2 + nightF * 2.4 + duskF * 0.7;
    city.beaconMat.emissiveIntensity = 1.2 + Math.sin(performance.now() / 160) * 1.4;
    city.beaconLight.intensity = (nightF > 0.25 ? 12 : 2) + Math.sin(performance.now() / 160) * 6;
    const wet = weather === "rain";
    for (const m of city.roadMats) {
      m.roughness = wet ? 0.38 : 0.92;
      m.metalness = wet ? 0.25 : 0.04;
    }
    if (wet && Math.random() < dt * 0.15) {
      flash = 1;
      sfx.thunder();
    }
    flash = Math.max(0, flash - dt * 2.5);
  }

  function updateRain(dt: number) {
    rain.visible = weather === "rain";
    if (weather !== "rain") return;
    rain.position.set(player.x, 0, player.z);
    const arr = rainGeo.attributes.position as THREE.BufferAttribute;
    const a = arr.array as Float32Array;
    for (let i = 0; i < 1600; i++) {
      a[i * 3 + 1] -= 42 * dt;
      if (a[i * 3 + 1] < 0) {
        a[i * 3 + 1] = 40;
        a[i * 3] = (Math.random() - 0.5) * 70;
        a[i * 3 + 2] = (Math.random() - 0.5) * 70;
      }
    }
    arr.needsUpdate = true;
  }

  function updateWanted(dt: number) {
    if (wanted <= 0) return;
    const heatNear = cars.some((c) => c.role === "police" && !c.dead && Math.hypot(c.x - player.x, c.z - player.z) < 26);
    if (!heatNear) wantedT += dt;
    if (wantedT > 9) {
      wantedT = 0;
      wanted = Math.max(0, wanted - 1);
    }
    copTimer -= dt;
    const cap = wanted * 2;
    const cops = cars.filter((c) => c.role === "police" && !c.dead).length;
    if (wanted > 0 && cops < cap && copTimer <= 0 && !player.dead) {
      copTimer = Math.max(0.9, 3.1 - wanted * 0.35);
      spawnCop();
    }
  }

  function updateCamera(dt: number) {
    const yaw = player.camYaw;
    let dist = player.car ? 8.4 + Math.min(5, Math.abs(player.car.speed) * 0.07) : 6.2;
    const py = player.car ? player.car.rig.group.position.y : 0;
    let hor = Math.cos(player.pitch) * dist;
    for (let n = 0; n < 5; n++) {
      if (!blocked(player.x + Math.sin(yaw) * hor, player.z + Math.cos(yaw) * hor, city.colliders)) break;
      hor *= 0.72;
    }
    const lift = Math.sin(player.pitch) * dist + (player.car ? 2.55 : 2.15);
    camDesired.set(player.x + Math.sin(yaw) * hor, py + lift, player.z + Math.cos(yaw) * hor);
    lookAt.set(player.x - Math.sin(yaw) * 6.5, py + 1.35, player.z - Math.cos(yaw) * 6.5);
    camera.position.lerp(camDesired, 1 - Math.exp(-10 * dt));
    if (camera.position.y < 0.7) camera.position.y = 0.7;
    shake *= Math.pow(0.05, dt);
    if (shake > 0.02) {
      camera.position.x += (Math.random() - 0.5) * shake;
      camera.position.y += (Math.random() - 0.5) * shake * 0.5;
    }
    camera.lookAt(lookAt);
  }

  function drawMap() {
    const s = mapCanvas.width;
    const ctx = mapCtx;
    ctx.clearRect(0, 0, s, s);
    ctx.fillStyle = "rgba(8,10,16,0.92)";
    ctx.fillRect(0, 0, s, s);
    const scale = s / 170;
    const to = (x: number, z: number) => [s / 2 + (x - player.x) * scale, s / 2 + (z - player.z) * scale] as const;
    ctx.fillStyle = "rgba(90,98,112,0.55)";
    for (const b of city.blocks) {
      const [x, y] = to(b.x, b.z);
      ctx.fillRect(x, y, b.w * scale, b.d * scale);
    }
    for (const shop of city.shops) {
      const [x, y] = to(shop.x, shop.z);
      ctx.fillStyle = shop.type === "health" ? "#3dce7a" : shop.type === "ammo" ? "#e4b15a" : "#7eb0d4";
      ctx.fillRect(x - 2, y - 2, 5, 5);
    }
    for (const r of city.ramps) {
      const [x, y] = to(r.x, r.z);
      ctx.fillStyle = "#ff9a1f";
      ctx.fillRect(x - 2, y - 2, 4, 4);
    }
    ctx.fillStyle = "#ff5a68";
    for (const c of cars) if (c.role === "police" && !c.dead) {
      const [x, y] = to(c.x, c.z);
      ctx.fillRect(x - 2, y - 2, 4, 4);
    }
    if (heli && !heli.dead) {
      const [x, y] = to(heli.x, heli.z);
      ctx.fillStyle = "#ff3355";
      ctx.fillRect(x - 3, y - 3, 6, 6);
    }
    for (const m of markers) {
      if (!m.visible) continue;
      const [x, y] = to(m.position.x, m.position.z);
      ctx.fillStyle = "#ffe08a";
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
    const facing = player.car ? player.car.yaw : player.camYaw;
    ctx.save();
    ctx.translate(s / 2, s / 2);
    ctx.rotate(-facing);
    ctx.fillStyle = "#8ecbff";
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4, 5);
    ctx.lineTo(-4, 5);
    ctx.fill();
    ctx.restore();
    const hh = Math.floor(tod) % 24;
    const mm = Math.floor((tod % 1) * 60);
    els.clock.textContent = `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
  }

  function updateHud() {
    root.style.setProperty("--hp", String(player.hp));
    root.style.setProperty("--nitro", String(player.nitro));
    els.money.textContent = `$${Math.floor(money)}`;
    els.stars.forEach((el, i) => el.classList.toggle("on", i < wanted));
    const gun = guns[gunIdx]!;
    els.weapon.textContent = reloading ? `${gun.name} …` : gun.name;
    els.ammo.textContent = `${gun.mag} / ${gun.res}`;
    els.slots.forEach((el, i) => el.classList.toggle("on", i === gunIdx));
    const stations = ["Radio off", "Pulse FM", "Nightwire", "Low End"];
    els.radio.textContent = stations[radio] ?? "Radio off";
    if (player.car) {
      const mph = Math.round(Math.abs(player.car.speed) * 2.15);
      els.speed.textContent = player.car.airDur > 0 ? `${mph} mph · air` : `${mph} mph`;
    } else els.speed.textContent = "On foot";
    els.combo.textContent = combo > 1 ? `X${combo}` : "";
    els.combo.classList.toggle("on", combo > 1 && comboT > 0);
    els.toast.classList.toggle("on", toastT > 0);
    els.pain.style.opacity = String(pain);
    els.best.textContent = `Best haul $${Math.floor(best)}`;
    drawMap();
  }

  function updateAmbient(dt: number) {
    gameTime += dt;
    comboT = Math.max(0, comboT - dt);
    if (comboT <= 0) combo = 0;
    toastT = Math.max(0, toastT - dt);
    pain = Math.max(0, pain - dt * 0.8);
    saveT -= dt;
    if (saveT <= 0) {
      saveT = 4;
      persist();
    }
    for (const s of city.shops) {
      if (s.cd > 0) s.cd -= dt;
      s.ring.rotation.z += dt;
    }
    updatePeds(dt);
    updateCars(dt);
    updateFeet(dt);
    updateBullets(dt);
    updateFx(dt);
    updateBounties(dt);
    updateSky(dt);
    updateRain(dt);
    if (started && !paused) {
      updateHeli(dt);
      updateWanted(dt);
      if (active && !player.dead) {
        active.tick(dt);
        els.status.textContent = active.status();
        if (active.failed?.()) {
          toast("FAILED");
          clearMarkers();
          active = null;
          missionDelay = 1.6;
        } else if (active.done()) completeMission();
      } else if (missionDelay > 0) {
        missionDelay -= dt;
        if (missionDelay <= 0) startMission(missionIdx);
      }
      if (radio > 0) {
        radioAcc += dt;
        if (radioAcc > 0.32) {
          radioAcc = 0;
          sfx.radio(radio, radioStep++);
        }
      }
    }
  }

  let raf = 0;
  let last = performance.now();
  function frame(now: number) {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (!started) {
      titleAng += dt * 0.15;
      updateAmbient(dt);
      camera.position.set(Math.sin(titleAng) * 28 + 2, 7.4, Math.cos(titleAng) * 26 + 6);
      camera.lookAt(4, 1.2, 16);
      renderer.render(scene, camera);
      return;
    }
    if (!paused) {
      if (player.dead) {
        player.deadT += dt;
        if (player.deadT > 2.6) respawn();
      } else updatePlayer(dt);
      updateAmbient(dt);
      updateCamera(dt);
    }
    updateHud();
    renderer.render(scene, camera);
  }
  raf = requestAnimationFrame(frame);
  startMission(0);

  const ac = new AbortController();
  const opt = { signal: ac.signal };
  window.addEventListener("keydown", (e) => {
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    held.add(e.code);
    if (e.repeat || !started) return;
    if (e.code === "Escape") {
      togglePause();
      return;
    }
    if (paused || player.dead) return;
    if (e.code === "KeyE" || e.code === "KeyF") interact();
    if (e.code === "Digit1") weapon(0);
    if (e.code === "Digit2") weapon(1);
    if (e.code === "Digit3") weapon(2);
    if (e.code === "Digit4") weapon(3);
    if (e.code === "KeyR") tryReload();
    if (e.code === "KeyH" && player.car) sfx.horn();
    if (e.code === "KeyT") {
      weather = weather === "rain" ? "clear" : "rain";
      toast(weather === "rain" ? "RAIN" : "CLEAR");
    }
    if (e.code === "KeyP") {
      cine = !cine;
      toast(cine ? "CINEMATIC" : "NORMAL");
    }
    if (e.code === "KeyC") swapCrew();
    if (e.code === "KeyM") {
      radio = (radio + 1) % 4;
      toast(["RADIO OFF", "PULSE FM", "NIGHTWIRE", "LOW END"][radio] ?? "");
    }
    if (e.code === "KeyL") {
      lampMode = ((lampMode + 1) % 3) as 0 | 1 | 2;
      toast(["LIGHTS AUTO", "LIGHTS ON", "LIGHTS OFF"][lampMode] ?? "");
    }
  }, opt);
  window.addEventListener("keyup", (e) => held.delete(e.code), opt);
  window.addEventListener("blur", () => held.clear(), opt);
  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }, opt);
  canvas.addEventListener("mousemove", (e) => {
    if (document.pointerLockElement !== canvas || paused) return;
    player.camYaw -= e.movementX * 0.0022;
    player.pitch = clamp(player.pitch + e.movementY * 0.002, -0.2, 1.05);
  }, opt);
  canvas.addEventListener("mousedown", (e) => {
    if (e.button === 0 && started && !paused) {
      mouseFire = true;
      sfx.unlock();
    }
  }, opt);
  window.addEventListener("mouseup", (e) => {
    if (e.button === 0) mouseFire = false;
  }, opt);
  canvas.addEventListener("contextmenu", (e) => e.preventDefault(), opt);
  canvas.addEventListener("click", () => {
    if (!started || paused || window.matchMedia("(pointer: coarse)").matches) return;
    canvas.requestPointerLock();
  }, opt);

  const stickL = root.querySelector("#ld-stick-l");
  const knobL = root.querySelector("#ld-knob-l");
  const stickR = root.querySelector("#ld-stick-r");
  const knobR = root.querySelector("#ld-knob-r");
  const bindStick = (el: Element | null, knob: Element | null, set: (x: number, y: number) => void) => {
    if (!(el instanceof HTMLElement) || !(knob instanceof HTMLElement)) return;
    let id: number | null = null;
    const end = () => {
      id = null;
      knob.style.transform = "";
      set(0, 0);
    };
    el.addEventListener("pointerdown", (e) => {
      id = e.pointerId;
      el.setPointerCapture(e.pointerId);
      move(e);
      sfx.unlock();
    }, opt);
    el.addEventListener("pointermove", (e) => {
      if (e.pointerId === id) move(e);
    }, opt);
    el.addEventListener("pointerup", end, opt);
    el.addEventListener("pointercancel", end, opt);
    function move(e: PointerEvent) {
      const r = el.getBoundingClientRect();
      let dx = e.clientX - (r.left + r.width / 2);
      let dy = e.clientY - (r.top + r.height / 2);
      const max = r.width / 2 - 16;
      const d = Math.hypot(dx, dy) || 1;
      if (d > max) {
        dx = (dx / d) * max;
        dy = (dy / d) * max;
      }
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      set(dx / max, dy / max);
    }
  };
  bindStick(stickL, knobL, (x, y) => {
    touch.x = x;
    touch.y = y;
  });
  bindStick(stickR, knobR, (x, y) => {
    look.x = x;
    look.y = y;
  });

  function begin() {
    if (started) return;
    started = true;
    root.classList.add("is-live");
    sfx.unlock();
    if (!window.matchMedia("(pointer: coarse)").matches) canvas.requestPointerLock();
  }
  function togglePause() {
    if (!started || player.dead) return;
    paused = !paused;
    els.pause.classList.toggle("open", paused);
    root.classList.toggle("is-paused", paused);
    if (paused && document.pointerLockElement === canvas) document.exitPointerLock();
  }
  function resume() {
    paused = false;
    els.pause.classList.remove("open");
    root.classList.remove("is-paused");
  }
  function weapon(index: number) {
    if (index < 0 || index >= guns.length || paused) return;
    gunIdx = index;
    reloading = false;
    sfx.unlock();
  }

  window.__controlsTest = {
    getYaw: () => (player.car ? player.car.yaw : player.yaw),
    getSpeed: () => (player.car ? player.car.speed : Math.hypot(player.vx, player.vz)),
    setKeys: (codes) => {
      qa.clear();
      for (const code of codes) qa.add(code);
    },
    setSteer: (v) => {
      qaSteer = v;
    },
  };

  return {
    dispose() {
      cancelAnimationFrame(raf);
      ac.abort();
      delete window.__controlsTest;
      renderer.dispose();
    },
    begin,
    togglePause,
    resume,
    weapon,
    interact,
    setHold(key, value) {
      if (key === "fire") holdFire = value;
      if (key === "sprint") holdSprint = value;
      if (key === "brake") holdBrake = value;
      if (value) sfx.unlock();
    },
  };
}
