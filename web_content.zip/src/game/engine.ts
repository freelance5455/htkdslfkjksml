import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import confetti from 'canvas-confetti';
import {
  WeaponType,
  LootType,
  LootItem,
  GlooWallInstance,
  BotEntity,
  SafeZone,
  KillFeedEntry,
  GameStats,
} from './types';
import { WEAPON_REGISTRY } from './weapons';
import { sounds } from './audio';
import {
  createCharacterModel,
  createWeaponModel,
  createGlooWallMesh,
  createPalmTree,
  createPineTree,
  createContainer,
  createHouse,
  createWatchtower,
  createRock,
  createAirdropCrate,
  createLootMesh,
} from './models';
import { InputManager } from './input';

// Pre-allocated math objects to avoid garbage collection inside render loop
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _camPos = new THREE.Vector3();
const _targetPos = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();
const _rayDir = new THREE.Vector3();
const _raycaster = new THREE.Raycaster();

export interface EngineCallbacks {
  onStatsUpdate: (stats: {
    hp: number;
    maxHp: number;
    ep: number;
    maxEp: number;
    vest: number;
    aliveCount: number;
    kills: number;
    activeWeapon: WeaponType;
    currentAmmo: number;
    reserveAmmo: number;
    glooWalls: number;
    medkits: number;
    isOutsideZone: boolean;
    zoneCountdown: number;
    zonePhase: number;
    isHealing: boolean;
  }) => void;
  onKillFeed: (entry: KillFeedEntry) => void;
  onHitMarker: (isHeadshot: boolean) => void;
  onDamageNumber: (dmg: number, isHeadshot: boolean, screenX: number, screenY: number) => void;
  onGameOver: (stats: GameStats) => void;
  onRadarUpdate: (data: {
    playerX: number;
    playerZ: number;
    playerRot: number;
    zoneX: number;
    zoneZ: number;
    zoneRadius: number;
    targetZoneX: number;
    targetZoneZ: number;
    targetZoneRadius: number;
    gunshots: { x: number; z: number; time: number }[];
  }) => void;
}

export class BattleRoyaleEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  public input: InputManager;

  // Three.js Core
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private clock!: THREE.Clock;
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private frameId: number = 0;
  private isSoftwareGl: boolean = false;

  // Environment & Lights
  private sunLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private safeZoneMesh!: THREE.Mesh;
  private nextZoneMesh!: THREE.LineSegments;

  // Player State
  public player = {
    x: 0,
    y: 0,
    z: 0,
    rotationY: 0,
    cameraPitch: 0.15,
    cameraYaw: 0,
    velocityY: 0,
    isGrounded: true,
    hp: 200,
    maxHp: 200,
    ep: 150,
    maxEp: 200,
    vest: 100, // 50% damage reduction
    glooWalls: 3,
    medkits: 3,
    kills: 0,
    damageDealt: 0,
    shotsFired: 0,
    shotsHit: 0,
    headshots: 0,
    gloowallsPlaced: 0,
    startTime: 0,
    isDead: false,
    isParachuting: true,
    parachuteHeight: 45,
    speed: 9.5,
    activeSlot: 0 as 0 | 1 | 2,
    inventory: [
      { id: 'ar' as WeaponType, currentAmmo: 30, reserveAmmo: 90 },
      { id: 'shotgun' as WeaponType, currentAmmo: 2, reserveAmmo: 24 },
      { id: 'sniper' as WeaponType, currentAmmo: 5, reserveAmmo: 15 },
    ],
    lastShotTime: 0,
    isReloading: false,
    reloadTimer: 0,
    isHealing: false,
    healingTimer: 0,
    recoilPitch: 0,
    model: null as any,
    currentWeaponMesh: null as THREE.Group | null,
    parachuteMesh: null as THREE.Group | null,
  };

  // World State
  private bots: BotEntity[] = [];
  private lootItems: LootItem[] = [];
  private glooWalls: GlooWallInstance[] = [];
  private obstacles: { box: THREE.Box3; mesh: THREE.Object3D }[] = [];
  private gunshots: { x: number; z: number; time: number }[] = [];

  // Safe Zone
  private zone: SafeZone = {
    currentCenterX: 0,
    currentCenterZ: 0,
    currentRadius: 160,
    targetCenterX: 10,
    targetCenterZ: 10,
    targetRadius: 90,
    shrinkTimer: 45, // 45s countdown
    shrinkDuration: 30,
    isShrinking: false,
    phase: 1,
    totalPhases: 4,
    damagePerSec: 8,
  };

  // Particles & Tracers
  private tracers: { line: THREE.Line; age: number; maxAge: number }[] = [];
  private airdrop: { mesh: THREE.Group; x: number; z: number; y: number; isFalling: boolean } | null = null;

  constructor(container: HTMLElement, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.input = new InputManager();
  }

  public init() {
    this.input.init(this.container);

    // 1. Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Setup Three.js Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    // 3. Scene, Camera, Clock
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x7dd3fc); // Bermuda sky blue
    this.scene.fog = new THREE.FogExp2(0x7dd3fc, 0.007);

    this.camera = new THREE.PerspectiveCamera(
      70,
      this.container.clientWidth / this.container.clientHeight,
      0.1,
      600
    );
    this.clock = new THREE.Clock();

    // 4. Studio Environment & Lighting
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Key Sun Light (Warm tropical sunlight)
    this.sunLight = new THREE.DirectionalLight(0xfffbeb, 1.8);
    this.sunLight.position.set(60, 90, 40);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.width = 1024;
    this.sunLight.shadow.mapSize.height = 1024;
    this.sunLight.shadow.camera.near = 10;
    this.sunLight.shadow.camera.far = 250;
    const d = 80;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.scene.add(this.sunLight);

    // Cool Hemisphere fill light
    this.hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x166534, 0.85);
    this.scene.add(this.hemiLight);

    // 5. Build Island World
    this.buildMap();

    // 6. Spawn Safe Zone Forcefield
    this.buildSafeZone();

    // 7. Spawn Player
    this.spawnPlayer();

    // 8. Spawn Bots & Loot
    this.spawnBots(15);
    this.spawnInitialLoot();

    // 9. Window Resize
    window.addEventListener('resize', this.handleResize);

    // Start Clock & Loop
    this.player.startTime = Date.now();
    this.isRunning = true;
    this.clock.start();
    this.tick();
  }

  private buildMap() {
    // 1. Island Terrain Mesh
    const terrainGeo = new THREE.PlaneGeometry(320, 320, 40, 40);
    terrainGeo.rotateX(-Math.PI / 2);

    // Subtle gentle rolling hills
    const pos = terrainGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i);
      const vz = pos.getZ(i);
      const distFromCenter = Math.hypot(vx, vz);

      // Island drop off to ocean near edges
      let h = Math.sin(vx * 0.04) * Math.cos(vz * 0.04) * 2.2;
      if (distFromCenter > 130) {
        h -= (distFromCenter - 130) * 0.25;
      }
      pos.setY(i, h);
    }
    terrainGeo.computeVertexNormals();

    // Grass & Sand material
    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0x4ade80, // Lush tropical grass
      roughness: 0.85,
      metalness: 0.05,
    });
    const terrain = new THREE.Mesh(terrainGeo, terrainMat);
    terrain.receiveShadow = true;
    this.scene.add(terrain);

    // Ocean plane extending to horizon
    const oceanGeo = new THREE.PlaneGeometry(800, 800);
    oceanGeo.rotateX(-Math.PI / 2);
    const oceanMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Tropical ocean
      roughness: 0.1,
      metalness: 0.4,
      transparent: true,
      opacity: 0.85,
    });
    const ocean = new THREE.Mesh(oceanGeo, oceanMat);
    ocean.position.y = -2.5;
    this.scene.add(ocean);

    // 2. Add Tactical Compound & Buildings (Factory / Village)
    // Central Military Warehouse
    const house1 = createHouse();
    house1.position.set(0, 0, 0);
    this.scene.add(house1);
    this.obstacles.push({ box: new THREE.Box3().setFromObject(house1), mesh: house1 });

    const house2 = createHouse();
    house2.position.set(-45, 0, 30);
    house2.rotation.y = Math.PI / 3;
    this.scene.add(house2);
    this.obstacles.push({ box: new THREE.Box3().setFromObject(house2), mesh: house2 });

    const house3 = createHouse();
    house3.position.set(50, 0, -35);
    house3.rotation.y = -Math.PI / 4;
    this.scene.add(house3);
    this.obstacles.push({ box: new THREE.Box3().setFromObject(house3), mesh: house3 });

    // Watchtowers
    const watchtowerCoords = [
      [-30, -30],
      [40, 40],
      [-50, -45],
      [55, 30],
    ];
    watchtowerCoords.forEach(([tx, tz]) => {
      const tower = createWatchtower();
      tower.position.set(tx, 0, tz);
      this.scene.add(tower);
      this.obstacles.push({ box: new THREE.Box3().setFromObject(tower), mesh: tower });
    });

    // Shipping Containers in Yards
    const containerLocations = [
      { x: 18, z: -12, rot: 0, col: 0xb91c1c },
      { x: 22, z: -12, rot: 0, col: 0x1d4ed8 },
      { x: 20, z: -18, rot: 0.4, col: 0x047857 },
      { x: -22, z: 15, rot: 1.2, col: 0xb91c1c },
      { x: -28, z: 18, rot: 1.2, col: 0xd97706 },
      { x: -15, z: -35, rot: 0.8, col: 0x4338ca },
      { x: 35, z: -20, rot: -0.5, col: 0x0f172a },
    ];
    containerLocations.forEach((c) => {
      const cont = createContainer(c.col);
      cont.position.set(c.x, 0, c.z);
      cont.rotation.y = c.rot;
      this.scene.add(cont);
      this.obstacles.push({ box: new THREE.Box3().setFromObject(cont), mesh: cont });
    });

    // Palm & Pine Trees scattered across island
    for (let i = 0; i < 48; i++) {
      const angle = (i / 48) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
      const radius = 25 + Math.random() * 85;
      const tx = Math.cos(angle) * radius;
      const tz = Math.sin(angle) * radius;

      // Don't spawn on top of central warehouse
      if (Math.hypot(tx, tz) > 12) {
        const tree = i % 2 === 0 ? createPalmTree() : createPineTree();
        tree.position.set(tx, 0, tz);
        const s = 0.85 + Math.random() * 0.35;
        tree.scale.set(s, s, s);
        tree.rotation.y = Math.random() * Math.PI * 2;
        this.scene.add(tree);
        // Add simple obstacle cylinder box
        this.obstacles.push({
          box: new THREE.Box3(
            new THREE.Vector3(tx - 0.6, 0, tz - 0.6),
            new THREE.Vector3(tx + 0.6, 6, tz + 0.6)
          ),
          mesh: tree,
        });
      }
    }

    // Rocks / Boulders
    for (let i = 0; i < 22; i++) {
      const rx = (Math.random() - 0.5) * 190;
      const rz = (Math.random() - 0.5) * 190;
      if (Math.hypot(rx, rz) > 15) {
        const rock = createRock();
        rock.position.set(rx, 0, rz);
        rock.rotation.y = Math.random() * Math.PI * 2;
        this.scene.add(rock);
        this.obstacles.push({ box: new THREE.Box3().setFromObject(rock), mesh: rock });
      }
    }
  }

  private buildSafeZone() {
    // Electric blue shrinking cylinder forcefield
    const geo = new THREE.CylinderGeometry(this.zone.currentRadius, this.zone.currentRadius, 80, 48, 1, true);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x00d2ff, // Free Fire classic electric blue zone
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.safeZoneMesh = new THREE.Mesh(geo, mat);
    this.safeZoneMesh.position.set(this.zone.currentCenterX, 40, this.zone.currentCenterZ);
    this.scene.add(this.safeZoneMesh);

    // Target zone indicator outline on ground
    const circlePts: THREE.Vector3[] = [];
    const segments = 48;
    for (let i = 0; i <= segments; i++) {
      const theta = (i / segments) * Math.PI * 2;
      circlePts.push(
        new THREE.Vector3(
          Math.cos(theta) * this.zone.targetRadius,
          0.3,
          Math.sin(theta) * this.zone.targetRadius
        )
      );
    }
    const lineGeo = new THREE.BufferGeometry().setFromPoints(circlePts);
    const lineMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.65 });
    this.nextZoneMesh = new THREE.LineSegments(lineGeo, lineMat);
    this.nextZoneMesh.position.set(this.zone.targetCenterX, 0, this.zone.targetCenterZ);
    this.scene.add(this.nextZoneMesh);
  }

  private spawnPlayer() {
    this.player.model = createCharacterModel(true);
    this.player.x = (Math.random() - 0.5) * 40;
    this.player.z = (Math.random() - 0.5) * 40;
    this.player.y = this.player.parachuteHeight;
    this.player.model.root.position.set(this.player.x, this.player.y, this.player.z);
    this.scene.add(this.player.model.root);

    // Parachute canopy
    const paraGroup = new THREE.Group();
    const canopyGeo = new THREE.SphereGeometry(3.5, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.45);
    const canopyMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b, // Yellow Free Fire parachute
      side: THREE.DoubleSide,
      roughness: 0.6,
    });
    const canopy = new THREE.Mesh(canopyGeo, canopyMat);
    canopy.position.y = 4.2;
    paraGroup.add(canopy);

    // Cords
    const cordMat = new THREE.LineBasicMaterial({ color: 0x1f2937 });
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      const pts = [
        new THREE.Vector3(0, 1.8, 0),
        new THREE.Vector3(Math.cos(a) * 3.2, 4.0, Math.sin(a) * 3.2),
      ];
      const cord = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), cordMat);
      paraGroup.add(cord);
    }
    this.player.parachuteMesh = paraGroup;
    this.player.model.root.add(paraGroup);

    // Equip default weapon
    this.updateEquippedWeapon();
  }

  private updateEquippedWeapon() {
    if (this.player.currentWeaponMesh) {
      this.player.model.weaponHolder.remove(this.player.currentWeaponMesh);
    }
    const currentWep = this.player.inventory[this.player.activeSlot];
    const wepModel = createWeaponModel(currentWep.id);
    this.player.currentWeaponMesh = wepModel;
    this.player.model.weaponHolder.add(wepModel);
  }

  private spawnBots(count: number) {
    const botNames = [
      'Ajjubhai_Pro',
      'TotalGaming',
      'Raistar_OP',
      'DesiGamers',
      'GyanSujan',
      'Badge99',
      'LokeshGamer',
      'AS_Gaming',
      'SniperKing99',
      'Headshot_God',
      'Killer_X',
      'Bermuda_Hero',
      'NoobSlayer',
      'ShadowNinja',
      'FreeFire_King',
    ];

    const weaponChoices: WeaponType[] = ['ar', 'shotgun', 'sniper', 'ar', 'pistol'];

    for (let i = 0; i < count; i++) {
      const botModel = createCharacterModel(false, i);
      const angle = (i / count) * Math.PI * 2 + Math.random() * 0.4;
      const dist = 35 + Math.random() * 85;
      const bx = Math.cos(angle) * dist;
      const bz = Math.sin(angle) * dist;

      const wep = weaponChoices[i % weaponChoices.length];
      const wepMesh = createWeaponModel(wep);
      botModel.weaponHolder.add(wepMesh);

      botModel.root.position.set(bx, 0, bz);
      this.scene.add(botModel.root);

      this.bots.push({
        id: `bot-${i}`,
        name: botNames[i % botNames.length],
        x: bx,
        y: 0,
        z: bz,
        rotationY: Math.random() * Math.PI * 2,
        health: 150,
        maxHealth: 150,
        weapon: wep,
        isDead: false,
        targetX: bx + (Math.random() - 0.5) * 30,
        targetZ: bz + (Math.random() - 0.5) * 30,
        state: 'roam',
        attackCooldown: 1.0 + Math.random() * 1.5,
        reactionTimer: 0,
        mesh: botModel,
        animTime: Math.random() * 10,
        isMoving: true,
        velocity: { x: 0, y: 0, z: 0 },
      });
    }
  }

  private spawnInitialLoot() {
    const lootList: { type: LootType; name: string; amount: number }[] = [
      { type: 'weapon_ar', name: 'AK-47', amount: 30 },
      { type: 'weapon_shotgun', name: 'M1887', amount: 8 },
      { type: 'weapon_sniper', name: 'AWM', amount: 10 },
      { type: 'medkit', name: 'Medkit', amount: 1 },
      { type: 'gloowall', name: 'Gloo Wall', amount: 1 },
      { type: 'vest', name: 'Level 2 Vest', amount: 50 },
      { type: 'mushroom', name: 'Mushroom', amount: 50 },
      { type: 'ammo_ar', name: 'AR Ammo', amount: 60 },
      { type: 'ammo_sg', name: 'SG Ammo', amount: 12 },
    ];

    for (let i = 0; i < 36; i++) {
      const template = lootList[i % lootList.length];
      const lx = (Math.random() - 0.5) * 180;
      const lz = (Math.random() - 0.5) * 180;
      const mesh = createLootMesh(template.type);
      mesh.position.set(lx, 0, lz);
      this.scene.add(mesh);

      this.lootItems.push({
        id: `loot-${i}`,
        type: template.type,
        name: template.name,
        amount: template.amount,
        x: lx,
        y: 0,
        z: lz,
        mesh,
      });
    }
  }

  public deployGlooWall() {
    if (this.player.glooWalls <= 0 || this.player.isDead) return;

    this.player.glooWalls--;
    this.player.gloowallsPlaced++;
    sounds.playGlooWall();

    // Spawn 2.6m in front of player
    const spawnDist = 2.6;
    const forwardX = -Math.sin(this.player.rotationY) * spawnDist;
    const forwardZ = -Math.cos(this.player.rotationY) * spawnDist;

    const gx = this.player.x + forwardX;
    const gz = this.player.z + forwardZ;

    const wallMesh = createGlooWallMesh();
    wallMesh.position.set(gx, 0, gz);
    wallMesh.rotation.y = this.player.rotationY;
    this.scene.add(wallMesh);

    const instance: GlooWallInstance = {
      id: `gloo-${Date.now()}`,
      x: gx,
      y: 0,
      z: gz,
      rotationY: this.player.rotationY,
      health: 450,
      maxHealth: 450,
      mesh: wallMesh,
      createdAt: Date.now(),
    };
    this.glooWalls.push(instance);
    this.obstacles.push({
      box: new THREE.Box3(
        new THREE.Vector3(gx - 1.8, 0, gz - 1.8),
        new THREE.Vector3(gx + 1.8, 2.8, gz + 1.8)
      ),
      mesh: wallMesh,
    });
  }

  public useMedkit() {
    if (this.player.medkits <= 0 || this.player.hp >= this.player.maxHp || this.player.isHealing) {
      return;
    }
    this.player.isHealing = true;
    this.player.healingTimer = 2.5; // 2.5s use time
    sounds.playMedkit();
  }

  public switchWeapon(slotIndex: 0 | 1 | 2) {
    if (this.player.activeSlot === slotIndex) return;
    this.player.activeSlot = slotIndex;
    this.player.isReloading = false;
    this.updateEquippedWeapon();
  }

  public reloadWeapon() {
    const wep = this.player.inventory[this.player.activeSlot];
    const def = WEAPON_REGISTRY[wep.id];
    if (wep.currentAmmo >= def.magazineSize || wep.reserveAmmo <= 0 || this.player.isReloading) {
      return;
    }
    this.player.isReloading = true;
    this.player.reloadTimer = def.reloadTime;
    sounds.playReload();
  }

  private handlePlayerShooting(now: number) {
    if (this.player.isDead || this.player.isParachuting || this.player.isReloading) return;

    const wep = this.player.inventory[this.player.activeSlot];
    const def = WEAPON_REGISTRY[wep.id];

    // Check fire rate
    if (now - this.player.lastShotTime < 1 / def.fireRate) return;

    // Check ammo
    if (wep.currentAmmo <= 0) {
      this.reloadWeapon();
      return;
    }

    wep.currentAmmo--;
    this.player.lastShotTime = now;
    this.player.shotsFired++;
    sounds.playShoot(wep.id);

    // Gunshot radar ping
    this.gunshots.push({ x: this.player.x, z: this.player.z, time: now });

    // Recoil kick
    this.player.recoilPitch = Math.min(this.player.recoilPitch + def.recoil, 0.2);

    // Camera origin & Raycast aim
    _rayOrigin.copy(this.camera.position);
    this.camera.getWorldDirection(_rayDir);

    // Weapon Spread
    if (!this.input.state.aimDownSights) {
      _rayDir.x += (Math.random() - 0.5) * def.spread;
      _rayDir.y += (Math.random() - 0.5) * def.spread;
      _rayDir.z += (Math.random() - 0.5) * def.spread;
      _rayDir.normalize();
    }

    // Shotgun fires 5 pellets
    const pelletCount = wep.id === 'shotgun' ? 5 : 1;

    for (let p = 0; p < pelletCount; p++) {
      const pelletDir = _rayDir.clone();
      if (wep.id === 'shotgun') {
        pelletDir.x += (Math.random() - 0.5) * def.spread;
        pelletDir.y += (Math.random() - 0.5) * def.spread;
        pelletDir.z += (Math.random() - 0.5) * def.spread;
        pelletDir.normalize();
      }

      _raycaster.set(_rayOrigin, pelletDir);
      _raycaster.far = def.range;

      // Check hit against bots
      let closestHitDist = def.range;
      let hitTarget: { bot?: BotEntity; gloo?: GlooWallInstance; point: THREE.Vector3; isHeadshot: boolean } | null = null;

      // 1. Check Gloo Walls
      for (const gw of this.glooWalls) {
        const d = Math.hypot(gw.x - this.player.x, gw.z - this.player.z);
        if (d < closestHitDist) {
          const intersects = _raycaster.intersectObject(gw.mesh, true);
          if (intersects.length > 0 && intersects[0].distance < closestHitDist) {
            closestHitDist = intersects[0].distance;
            hitTarget = { gloo: gw, point: intersects[0].point, isHeadshot: false };
          }
        }
      }

      // 2. Check Bots
      for (const bot of this.bots) {
        if (bot.isDead) continue;
        const dist = Math.hypot(bot.x - this.player.x, bot.z - this.player.z);
        if (dist < closestHitDist) {
          const intersects = _raycaster.intersectObject(bot.mesh.root, true);
          if (intersects.length > 0 && intersects[0].distance < closestHitDist) {
            closestHitDist = intersects[0].distance;
            // Check if head hit (y > 1.4)
            const isHead = intersects[0].point.y > 1.45;
            hitTarget = { bot, point: intersects[0].point, isHeadshot: isHead };
          }
        }
      }

      const targetPoint = hitTarget
        ? hitTarget.point
        : _rayOrigin.clone().add(pelletDir.clone().multiplyScalar(def.range));

      // Draw Bullet Tracer line
      this.createTracer(
        this.player.model.root.position.clone().add(new THREE.Vector3(0, 1.2, 0)),
        targetPoint,
        def.color
      );

      // Process Damage if hit
      if (hitTarget?.bot) {
        const bot = hitTarget.bot;
        const headMultiplier = hitTarget.isHeadshot ? 2.2 : 1.0;
        const finalDmg = Math.round(def.damage * headMultiplier);

        bot.health -= finalDmg;
        this.player.shotsHit++;
        this.player.damageDealt += finalDmg;
        if (hitTarget.isHeadshot) this.player.headshots++;

        sounds.playHit(hitTarget.isHeadshot);
        this.callbacks.onHitMarker(hitTarget.isHeadshot);

        // Project 3D point to 2D screen coordinates for floating damage number
        _v1.copy(hitTarget.point).project(this.camera);
        const sx = ((_v1.x + 1) * this.container.clientWidth) / 2;
        const sy = ((-_v1.y + 1) * this.container.clientHeight) / 2;
        this.callbacks.onDamageNumber(finalDmg, hitTarget.isHeadshot, sx, sy);

        // Alert bot to hunt player!
        bot.state = 'attack';
        bot.targetX = this.player.x;
        bot.targetZ = this.player.z;

        if (bot.health <= 0) {
          this.eliminateBot(bot, 'Player', hitTarget.isHeadshot);
        }
      } else if (hitTarget?.gloo) {
        hitTarget.gloo.health -= def.damage;
        if (hitTarget.gloo.health <= 0) {
          this.destroyGlooWall(hitTarget.gloo);
        }
      }
    }
  }

  private eliminateBot(bot: BotEntity, killerName: string, isHeadshot: boolean) {
    if (bot.isDead) return;
    bot.isDead = true;
    this.scene.remove(bot.mesh.root);

    // Drop loot crate
    const lootMesh = createLootMesh('medkit');
    lootMesh.position.set(bot.x, 0, bot.z);
    this.scene.add(lootMesh);
    this.lootItems.push({
      id: `loot-drop-${Date.now()}-${Math.random()}`,
      type: 'medkit',
      name: 'Medkit',
      amount: 1,
      x: bot.x,
      y: 0,
      z: bot.z,
      mesh: lootMesh,
    });

    const isPlayerKiller = killerName === 'Player';
    if (isPlayerKiller) {
      this.player.kills++;
    }

    const entry: KillFeedEntry = {
      id: `kill-${Date.now()}-${Math.random()}`,
      killer: killerName,
      victim: bot.name,
      weapon: WEAPON_REGISTRY[this.player.inventory[this.player.activeSlot].id].name,
      isHeadshot,
      isPlayerKiller,
      isPlayerVictim: false,
      timestamp: Date.now(),
    };
    this.callbacks.onKillFeed(entry);

    // Check Victory (BOOYAH!)
    const aliveBots = this.bots.filter((b) => !b.isDead).length;
    if (aliveBots === 0 && !this.player.isDead) {
      this.triggerBooyah();
    }
  }

  private triggerBooyah() {
    sounds.playBooyah();
    try {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }

    const stats: GameStats = {
      kills: this.player.kills,
      damageDealt: this.player.damageDealt,
      survivalTime: Math.round((Date.now() - this.player.startTime) / 1000),
      headshots: this.player.headshots,
      shotsFired: this.player.shotsFired,
      shotsHit: this.player.shotsHit,
      gloowallsPlaced: this.player.gloowallsPlaced,
      rank: 1,
      totalPlayers: 16,
      isVictory: true,
    };
    this.callbacks.onGameOver(stats);
  }

  private triggerDefeat() {
    this.player.isDead = true;
    sounds.playDefeat();
    const aliveBots = this.bots.filter((b) => !b.isDead).length;
    const rank = aliveBots + 1;

    const stats: GameStats = {
      kills: this.player.kills,
      damageDealt: this.player.damageDealt,
      survivalTime: Math.round((Date.now() - this.player.startTime) / 1000),
      headshots: this.player.headshots,
      shotsFired: this.player.shotsFired,
      shotsHit: this.player.shotsHit,
      gloowallsPlaced: this.player.gloowallsPlaced,
      rank,
      totalPlayers: 16,
      isVictory: false,
    };
    this.callbacks.onGameOver(stats);
  }

  private destroyGlooWall(gloo: GlooWallInstance) {
    this.scene.remove(gloo.mesh);
    this.glooWalls = this.glooWalls.filter((g) => g.id !== gloo.id);
    this.obstacles = this.obstacles.filter((o) => o.mesh !== gloo.mesh);
  }

  private createTracer(start: THREE.Vector3, end: THREE.Vector3, color: string) {
    const geo = new THREE.BufferGeometry().setFromPoints([start, end]);
    const mat = new THREE.LineBasicMaterial({
      color: new THREE.Color(color),
      transparent: true,
      opacity: 0.9,
    });
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);
    this.tracers.push({ line, age: 0, maxAge: 0.08 });
  }

  private updateSafeZone(dt: number) {
    if (this.zone.isShrinking) {
      // Interpolate radius and center towards target
      const shrinkSpeed = (dt / this.zone.shrinkDuration) * (this.zone.currentRadius - this.zone.targetRadius);
      this.zone.currentRadius = Math.max(this.zone.currentRadius - shrinkSpeed, this.zone.targetRadius);

      this.zone.currentCenterX += (this.zone.targetCenterX - this.zone.currentCenterX) * (dt / this.zone.shrinkDuration);
      this.zone.currentCenterZ += (this.zone.targetCenterZ - this.zone.currentCenterZ) * (dt / this.zone.shrinkDuration);

      if (this.zone.currentRadius <= this.zone.targetRadius + 0.5) {
        // Phase finished, set up next phase
        this.zone.isShrinking = false;
        this.zone.phase++;
        this.zone.shrinkTimer = 35; // wait 35s before next shrink
        this.zone.targetRadius = Math.max(this.zone.currentRadius * 0.5, 15);
        this.zone.targetCenterX = this.zone.currentCenterX + (Math.random() - 0.5) * 20;
        this.zone.targetCenterZ = this.zone.currentCenterZ + (Math.random() - 0.5) * 20;
        this.zone.damagePerSec += 4;
      }
    } else {
      this.zone.shrinkTimer -= dt;
      if (this.zone.shrinkTimer <= 0) {
        this.zone.isShrinking = true;
        sounds.playZoneWarning();
      }
    }

    // Update 3D safe zone cylinder scale & position
    this.safeZoneMesh.scale.set(this.zone.currentRadius / 160, 1, this.zone.currentRadius / 160);
    this.safeZoneMesh.position.set(this.zone.currentCenterX, 40, this.zone.currentCenterZ);

    // Update target zone circle on ground
    this.nextZoneMesh.scale.set(this.zone.targetRadius / 90, 1, this.zone.targetRadius / 90);
    this.nextZoneMesh.position.set(this.zone.targetCenterX, 0.2, this.zone.targetCenterZ);

    // Check if player is outside safe zone
    const distToZoneCenter = Math.hypot(
      this.player.x - this.zone.currentCenterX,
      this.player.z - this.zone.currentCenterZ
    );
    const isOutside = distToZoneCenter > this.zone.currentRadius;

    if (isOutside && !this.player.isDead && !this.player.isParachuting) {
      this.player.hp -= this.zone.damagePerSec * dt;
      if (Math.random() < 0.15) sounds.playHurt();
      if (this.player.hp <= 0) {
        this.player.hp = 0;
        this.triggerDefeat();
      }
    }

    // Check bots outside zone
    for (const bot of this.bots) {
      if (bot.isDead) continue;
      const bDist = Math.hypot(bot.x - this.zone.currentCenterX, bot.z - this.zone.currentCenterZ);
      if (bDist > this.zone.currentRadius) {
        bot.health -= this.zone.damagePerSec * dt;
        // Make bot prioritize running to zone
        bot.state = 'flee_zone';
        bot.targetX = this.zone.currentCenterX + (Math.random() - 0.5) * 15;
        bot.targetZ = this.zone.currentCenterZ + (Math.random() - 0.5) * 15;
        if (bot.health <= 0) {
          this.eliminateBot(bot, 'SafeZone', false);
        }
      }
    }
  }

  private updateBots(dt: number, now: number) {
    for (const bot of this.bots) {
      if (bot.isDead) continue;

      bot.animTime += dt * 8;

      // Distance to player
      const distToPlayer = Math.hypot(bot.x - this.player.x, bot.z - this.player.z);

      // Simple AI state machine
      if (bot.state !== 'flee_zone') {
        if (distToPlayer < 45 && !this.player.isDead && !this.player.isParachuting) {
          bot.state = 'attack';
          bot.targetX = this.player.x;
          bot.targetZ = this.player.z;
        } else if (Math.hypot(bot.x - bot.targetX, bot.z - bot.targetZ) < 3) {
          // Reached roam destination, pick new one
          bot.state = 'roam';
          bot.targetX = bot.x + (Math.random() - 0.5) * 40;
          bot.targetZ = bot.z + (Math.random() - 0.5) * 40;
        }
      }

      // Move toward target
      const dx = bot.targetX - bot.x;
      const dz = bot.targetZ - bot.z;
      const dist = Math.hypot(dx, dz);

      if (dist > 0.5) {
        const moveSpeed = bot.state === 'attack' ? 4.5 : 3.2;
        const nx = dx / dist;
        const nz = dz / dist;

        const nextX = bot.x + nx * moveSpeed * dt;
        const nextZ = bot.z + nz * moveSpeed * dt;

        // Check obstacle collision
        if (!this.checkObstacleCollision(nextX, nextZ, 0.6)) {
          bot.x = nextX;
          bot.z = nextZ;
        } else {
          // Pick new direction if blocked
          bot.targetX = bot.x + (Math.random() - 0.5) * 20;
          bot.targetZ = bot.z + (Math.random() - 0.5) * 20;
        }

        bot.rotationY = Math.atan2(nx, nz);
        bot.mesh.root.rotation.y = bot.rotationY;

        // Run animation
        const swing = Math.sin(bot.animTime);
        bot.mesh.leftLegGroup.rotation.x = swing * 0.6;
        bot.mesh.rightLegGroup.rotation.x = -swing * 0.6;
        bot.mesh.leftArmGroup.rotation.x = -swing * 0.5;
      }

      bot.mesh.root.position.set(bot.x, bot.y, bot.z);

      // Bot Attacks
      if (bot.state === 'attack' && distToPlayer < 40 && !this.player.isDead) {
        bot.attackCooldown -= dt;
        if (bot.attackCooldown <= 0) {
          bot.attackCooldown = 0.9 + Math.random() * 1.2;
          this.botShootPlayer(bot, now);
        }
      }
    }
  }

  private botShootPlayer(bot: BotEntity, now: number) {
    sounds.playShoot(bot.weapon);
    this.gunshots.push({ x: bot.x, z: bot.z, time: now });

    // Tracer from bot to player
    const botHand = bot.mesh.root.position.clone().add(new THREE.Vector3(0, 1.2, 0));
    const playerChest = this.player.model.root.position.clone().add(new THREE.Vector3(0, 1.2, 0));

    // Bot accuracy check
    const isHit = Math.random() < 0.45; // 45% accuracy
    const tracerEnd = isHit
      ? playerChest
      : playerChest.clone().add(new THREE.Vector3((Math.random() - 0.5) * 3, 0, (Math.random() - 0.5) * 3));

    this.createTracer(botHand, tracerEnd, '#ef4444');

    if (isHit) {
      let dmg = 18;
      // Vest reduction
      if (this.player.vest > 0) {
        this.player.vest = Math.max(0, this.player.vest - 10);
        dmg *= 0.6; // 40% reduction
      }
      this.player.hp -= Math.round(dmg);
      sounds.playHurt();

      if (this.player.hp <= 0) {
        this.player.hp = 0;
        this.triggerDefeat();
      }
    }
  }

  private checkObstacleCollision(x: number, z: number, radius: number): boolean {
    const testBox = new THREE.Box3(
      new THREE.Vector3(x - radius, 0, z - radius),
      new THREE.Vector3(x + radius, 2.5, z + radius)
    );
    for (const obs of this.obstacles) {
      if (obs.box.intersectsBox(testBox)) {
        return true;
      }
    }
    return false;
  }

  private updateLoot(dt: number) {
    // Rotate floating loot meshes
    for (const item of this.lootItems) {
      if (item.mesh) {
        item.mesh.rotation.y += dt * 1.5;

        // Pickup check
        const dist = Math.hypot(item.x - this.player.x, item.z - this.player.z);
        if (dist < 1.8 && !this.player.isDead && !this.player.isParachuting) {
          this.pickupLoot(item);
        }
      }
    }
  }

  private pickupLoot(item: LootItem) {
    sounds.playPickup();
    this.scene.remove(item.mesh);
    this.lootItems = this.lootItems.filter((i) => i.id !== item.id);

    if (item.type === 'medkit') {
      this.player.medkits = Math.min(this.player.medkits + 1, 8);
    } else if (item.type === 'gloowall') {
      this.player.glooWalls = Math.min(this.player.glooWalls + 1, 6);
    } else if (item.type === 'vest') {
      this.player.vest = 100;
    } else if (item.type === 'mushroom') {
      this.player.ep = Math.min(this.player.ep + item.amount, this.player.maxEp);
    } else if (item.type === 'ammo_ar') {
      this.player.inventory[0].reserveAmmo += item.amount;
    } else if (item.type === 'ammo_sg') {
      this.player.inventory[1].reserveAmmo += item.amount;
    } else if (item.type.startsWith('weapon')) {
      // Picked up weapon, top up reserve ammo
      this.player.inventory[0].reserveAmmo += 30;
      this.player.inventory[1].reserveAmmo += 8;
      this.player.inventory[2].reserveAmmo += 5;
    }
  }

  private updatePlayer(dt: number, now: number) {
    if (this.player.isDead) return;

    // Handle Parachute deployment
    if (this.player.isParachuting) {
      this.player.parachuteHeight -= dt * 14;
      this.player.y = this.player.parachuteHeight;
      this.player.model.root.position.y = this.player.y;

      if (this.player.parachuteHeight <= 0) {
        this.player.isParachuting = false;
        this.player.y = 0;
        this.player.model.root.position.y = 0;
        if (this.player.parachuteMesh) {
          this.player.model.root.remove(this.player.parachuteMesh);
        }
      }
      return;
    }

    // EP to HP passive healing (Free Fire classic mushroom mechanic!)
    if (this.player.ep > 0 && this.player.hp < this.player.maxHp) {
      this.player.ep -= dt * 3;
      this.player.hp = Math.min(this.player.hp + dt * 2, this.player.maxHp);
    }

    // Medkit usage progress
    if (this.player.isHealing) {
      this.player.healingTimer -= dt;
      if (this.player.healingTimer <= 0) {
        this.player.isHealing = false;
        this.player.hp = Math.min(this.player.hp + 75, this.player.maxHp);
        this.player.medkits--;
      }
    }

    // Reload timer
    if (this.player.isReloading) {
      this.player.reloadTimer -= dt;
      if (this.player.reloadTimer <= 0) {
        this.player.isReloading = false;
        const wep = this.player.inventory[this.player.activeSlot];
        const def = WEAPON_REGISTRY[wep.id];
        const needed = def.magazineSize - wep.currentAmmo;
        const take = Math.min(needed, wep.reserveAmmo);
        wep.currentAmmo += take;
        wep.reserveAmmo -= take;
      }
    }

    // Mouse Look / Pointer Lock rotation
    if (this.input.state.lookDeltaX !== 0 || this.input.state.lookDeltaY !== 0) {
      this.player.cameraYaw -= this.input.state.lookDeltaX;
      this.player.cameraPitch -= this.input.state.lookDeltaY;
      // Clamp pitch
      this.player.cameraPitch = Math.max(-0.6, Math.min(0.8, this.player.cameraPitch));
      this.player.rotationY = this.player.cameraYaw;
    }

    // Damp recoil
    if (this.player.recoilPitch > 0) {
      this.player.recoilPitch = Math.max(0, this.player.recoilPitch - dt * 0.15);
    }

    // Movement WASD
    let moveX = 0;
    let moveZ = 0;
    if (this.input.state.forward) moveZ -= 1;
    if (this.input.state.backward) moveZ += 1;
    if (this.input.state.left) moveX -= 1;
    if (this.input.state.right) moveX += 1;

    const isMoving = moveX !== 0 || moveZ !== 0;

    if (isMoving) {
      const len = Math.hypot(moveX, moveZ);
      moveX /= len;
      moveZ /= len;

      const currentSpeed = this.input.state.sprint ? this.player.speed * 1.4 : this.player.speed;

      // Transform by camera yaw
      const cos = Math.cos(this.player.cameraYaw);
      const sin = Math.sin(this.player.cameraYaw);

      const worldMoveX = (moveX * cos + moveZ * sin) * currentSpeed * dt;
      const worldMoveZ = (-moveX * sin + moveZ * cos) * currentSpeed * dt;

      const nextX = this.player.x + worldMoveX;
      const nextZ = this.player.z + worldMoveZ;

      // Collision with obstacles
      if (!this.checkObstacleCollision(nextX, this.player.z, 0.5)) {
        this.player.x = nextX;
      }
      if (!this.checkObstacleCollision(this.player.x, nextZ, 0.5)) {
        this.player.z = nextZ;
      }

      // Run animation
      const walkTime = now * 12;
      this.player.model.leftLegGroup.rotation.x = Math.sin(walkTime) * 0.6;
      this.player.model.rightLegGroup.rotation.x = -Math.sin(walkTime) * 0.6;
      this.player.model.leftArmGroup.rotation.x = -Math.sin(walkTime) * 0.5;
    } else {
      // Idle pose
      this.player.model.leftLegGroup.rotation.x = 0;
      this.player.model.rightLegGroup.rotation.x = 0;
      this.player.model.leftArmGroup.rotation.x = 0;
    }

    // Jump
    if (this.input.state.justJumped && this.player.isGrounded) {
      this.player.velocityY = 8.5;
      this.player.isGrounded = false;
      sounds.playJump();
    }

    // Gravity
    if (!this.player.isGrounded) {
      this.player.velocityY -= 22 * dt;
      this.player.y += this.player.velocityY * dt;
      if (this.player.y <= 0) {
        this.player.y = 0;
        this.player.velocityY = 0;
        this.player.isGrounded = true;
      }
    }

    // Update Model Position & Rotation
    this.player.model.root.position.set(this.player.x, this.player.y, this.player.z);
    this.player.model.root.rotation.y = this.player.rotationY;

    // Third-person camera positioning
    const isADS = this.input.state.aimDownSights;
    const targetFov = isADS
      ? WEAPON_REGISTRY[this.player.inventory[this.player.activeSlot].id].zoomFov
      : 70;
    this.camera.fov += (targetFov - this.camera.fov) * (dt * 12);
    this.camera.updateProjectionMatrix();

    // Camera offset (Free Fire over-the-shoulder view)
    const camDist = isADS ? 1.6 : 3.8;
    const camHeight = isADS ? 1.6 : 2.0;
    const shoulderOffset = isADS ? 0.45 : 0.6;

    const pitch = this.player.cameraPitch + this.player.recoilPitch;
    const yaw = this.player.cameraYaw;

    _camPos.set(
      this.player.x + Math.sin(yaw) * camDist + Math.cos(yaw) * shoulderOffset,
      this.player.y + camHeight + Math.sin(pitch) * camDist,
      this.player.z + Math.cos(yaw) * camDist - Math.sin(yaw) * shoulderOffset
    );

    _targetPos.set(
      this.player.x - Math.sin(yaw) * 15,
      this.player.y + 1.4 - Math.sin(pitch) * 15,
      this.player.z - Math.cos(yaw) * 15
    );

    this.camera.position.copy(_camPos);
    this.camera.lookAt(_targetPos);

    // Aim spine / weapon toward crosshair
    this.player.model.torsoGroup.rotation.x = -pitch * 0.7;

    // Handle Input Actions
    if (this.input.state.switchSlot1) this.switchWeapon(0);
    if (this.input.state.switchSlot2) this.switchWeapon(1);
    if (this.input.state.switchSlot3) this.switchWeapon(2);
    if (this.input.state.deployGlooWall) this.deployGlooWall();
    if (this.input.state.useMedkit) this.useMedkit();
    if (this.input.state.reload) this.reloadWeapon();

    // Shooting
    if (this.input.state.shoot) {
      this.handlePlayerShooting(now);
    }
  }

  private updateTracers(dt: number) {
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.age += dt;
      if (t.age >= t.maxAge) {
        this.scene.remove(t.line);
        this.tracers.splice(i, 1);
      }
    }
  }

  private spawnAirdrop() {
    if (this.airdrop) return;
    const ax = this.zone.currentCenterX + (Math.random() - 0.5) * 40;
    const az = this.zone.currentCenterZ + (Math.random() - 0.5) * 40;
    const mesh = createAirdropCrate();
    mesh.position.set(ax, 60, az);
    this.scene.add(mesh);

    this.airdrop = { mesh, x: ax, z: az, y: 60, isFalling: true };
  }

  private updateAirdrop(dt: number) {
    if (!this.airdrop) return;
    if (this.airdrop.isFalling) {
      this.airdrop.y -= dt * 6;
      this.airdrop.mesh.position.y = this.airdrop.y;
      if (this.airdrop.y <= 0) {
        this.airdrop.y = 0;
        this.airdrop.mesh.position.y = 0;
        this.airdrop.isFalling = false;
        // Add supply crate to obstacles & drop legendary loot
        this.obstacles.push({ box: new THREE.Box3().setFromObject(this.airdrop.mesh), mesh: this.airdrop.mesh });
      }
    }
  }

  private tick = () => {
    if (!this.isRunning) return;

    const rawDt = this.clock.getDelta();
    const dt = Math.min(rawDt, 0.05); // Frame delta clamp
    const now = this.clock.getElapsedTime();

    if (!this.isPaused) {
      this.updatePlayer(dt, now);
      this.updateBots(dt, now);
      this.updateSafeZone(dt);
      this.updateLoot(dt);
      this.updateTracers(dt);
      this.updateAirdrop(dt);

      // Periodically spawn airdrop in Phase 2
      if (this.zone.phase === 2 && !this.airdrop && Math.random() < 0.005) {
        this.spawnAirdrop();
      }

      // Dispatch UI Stats Callbacks
      const aliveBots = this.bots.filter((b) => !b.isDead).length;
      const aliveCount = (this.player.isDead ? 0 : 1) + aliveBots;
      const wep = this.player.inventory[this.player.activeSlot];

      this.callbacks.onStatsUpdate({
        hp: Math.round(this.player.hp),
        maxHp: this.player.maxHp,
        ep: Math.round(this.player.ep),
        maxEp: this.player.maxEp,
        vest: Math.round(this.player.vest),
        aliveCount,
        kills: this.player.kills,
        activeWeapon: wep.id,
        currentAmmo: wep.currentAmmo,
        reserveAmmo: wep.reserveAmmo,
        glooWalls: this.player.glooWalls,
        medkits: this.player.medkits,
        isOutsideZone: Math.hypot(this.player.x - this.zone.currentCenterX, this.player.z - this.zone.currentCenterZ) > this.zone.currentRadius,
        zoneCountdown: Math.max(0, Math.round(this.zone.shrinkTimer)),
        zonePhase: this.zone.phase,
        isHealing: this.player.isHealing,
      });

      // Radar update
      this.callbacks.onRadarUpdate({
        playerX: this.player.x,
        playerZ: this.player.z,
        playerRot: this.player.rotationY,
        zoneX: this.zone.currentCenterX,
        zoneZ: this.zone.currentCenterZ,
        zoneRadius: this.zone.currentRadius,
        targetZoneX: this.zone.targetCenterX,
        targetZoneZ: this.zone.targetCenterZ,
        targetZoneRadius: this.zone.targetRadius,
        gunshots: this.gunshots.filter((g) => now - g.time < 3.0),
      });

      this.input.endFrame();
    }

    this.renderer.render(this.scene, this.camera);
    this.frameId = requestAnimationFrame(this.tick);
  };

  private handleResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public pause() {
    this.isPaused = true;
  }

  public resume() {
    this.isPaused = false;
  }

  public destroy() {
    this.isRunning = false;
    cancelAnimationFrame(this.frameId);
    window.removeEventListener('resize', this.handleResize);
    this.input.destroy();
    this.renderer.dispose();
    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
