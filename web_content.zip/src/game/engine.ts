import {
  WeaponConfig,
  Zombie,
  ZombieType,
  Bullet,
  AcidSpit,
  HazardZone,
  ResourceDrop,
  Turret,
  WallSegment,
  Particle,
  BloodDecal,
  FloatingText,
  BaseState,
  PlayerState,
  GameResources,
  GraphicsSettings,
  WeaponType,
} from '../types';
import { soundEngine } from '../audio/soundEngine';
import { MAP_WIDTH, MAP_HEIGHT, BASE_RADIUS } from './constants';

export interface GameCallbacks {
  onGameOver: (stats: { wave: number; kills: number; score: number }) => void;
  onWaveComplete: (wave: number) => void;
  onResourcesChange: (resources: GameResources) => void;
  onPlayerHpChange: (hp: number, maxHp: number) => void;
  onBaseHpChange: (hp: number, maxHp: number) => void;
  onWeaponChange: (weapon: WeaponConfig, ammo: number, maxAmmo: number, isReloading: boolean) => void;
}

export class ZombieGameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private callbacks: GameCallbacks;

  // Game Loop
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private lastTime: number = 0;
  private animationFrameId: number | null = null;

  // Settings
  private graphics: GraphicsSettings;

  // Game State
  public wave: number = 1;
  public kills: number = 0;
  public score: number = 0;
  public waveZombiesRemaining: number = 0;
  public waveZombiesTotal: number = 0;
  public waveSpawnTimer: number = 0;
  public waveInProgress: boolean = false;
  private isWaveCleared: boolean = false;

  // Entities
  public player: PlayerState;
  public base: BaseState;
  public walls: WallSegment[] = [];
  public weapons: Record<string, WeaponConfig>;
  public zombies: Zombie[] = [];
  public bullets: Bullet[] = [];
  public acidSpits: AcidSpit[] = [];
  public hazardZones: HazardZone[] = [];
  public drops: ResourceDrop[] = [];
  public turrets: Turret[] = [];
  public particles: Particle[] = [];
  public bloodDecals: BloodDecal[] = [];
  public floatingTexts: FloatingText[] = [];

  // Resources
  public resources: GameResources = {
    wood: 60,
    metal: 30,
    coins: 150,
    ammo: 120,
  };

  // Inputs
  public moveDir = { x: 0, y: 0 };
  public aimAngle: number = 0;
  public isFiring: boolean = false;
  private lastFireTime: number = 0;
  public mousePos = { x: 0, y: 0 };

  // Screen shake
  private screenShakeTime: number = 0;
  private screenShakeIntensity: number = 0;

  // Viewport camera
  public camera = { x: 0, y: 0 };

  constructor(
    canvas: HTMLCanvasElement,
    initialWeapons: Record<string, WeaponConfig>,
    graphics: GraphicsSettings,
    callbacks: GameCallbacks
  ) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error('Could not get 2d context');
    this.ctx = context;
    this.weapons = JSON.parse(JSON.stringify(initialWeapons));
    this.graphics = graphics;
    this.callbacks = callbacks;

    // Initialize Base at map center
    this.base = {
      x: MAP_WIDTH / 2,
      y: MAP_HEIGHT / 2,
      radius: BASE_RADIUS,
      health: 800,
      maxHealth: 800,
      defenseLevel: 1,
      repairEfficiencyLevel: 1,
    };

    // Initialize Player inside base
    this.player = {
      x: MAP_WIDTH / 2,
      y: MAP_HEIGHT / 2 + 30,
      vx: 0,
      vy: 0,
      angle: -Math.PI / 2,
      health: 120,
      maxHealth: 120,
      speed: 210,
      speedLevel: 1,
      currentWeapon: 'pistol',
      currentAmmo: 12,
      isReloading: false,
      reloadProgress: 0,
      grenades: 2,
      dashCooldown: 0,
      lastDashTime: 0,
    };

    this.initWalls();
    this.initDefaultTurrets();
  }

  public updateGraphicsSettings(settings: GraphicsSettings) {
    this.graphics = settings;
  }

  public initWalls() {
    this.walls = [];
    const cx = MAP_WIDTH / 2;
    const cy = MAP_HEIGHT / 2;
    const dist = 180;
    const wallThick = 24;
    const wallLen = 140;

    // 4 Wall sections protecting the base with corner gaps
    // Top-left
    this.walls.push({ id: 1, x: cx - dist, y: cy - dist, width: wallLen, height: wallThick, orientation: 'horizontal', health: 400, maxHealth: 400 });
    // Top-right
    this.walls.push({ id: 2, x: cx + dist - wallLen, y: cy - dist, width: wallLen, height: wallThick, orientation: 'horizontal', health: 400, maxHealth: 400 });
    // Bottom-left
    this.walls.push({ id: 3, x: cx - dist, y: cy + dist, width: wallLen, height: wallThick, orientation: 'horizontal', health: 400, maxHealth: 400 });
    // Bottom-right
    this.walls.push({ id: 4, x: cx + dist - wallLen, y: cy + dist, width: wallLen, height: wallThick, orientation: 'horizontal', health: 400, maxHealth: 400 });

    // Left-top
    this.walls.push({ id: 5, x: cx - dist, y: cy - dist, width: wallThick, height: wallLen, orientation: 'vertical', health: 400, maxHealth: 400 });
    // Left-bottom
    this.walls.push({ id: 6, x: cx - dist, y: cy + dist - wallLen, width: wallThick, height: wallLen, orientation: 'vertical', health: 400, maxHealth: 400 });
    // Right-top
    this.walls.push({ id: 7, x: cx + dist, y: cy - dist, width: wallThick, height: wallLen, orientation: 'vertical', health: 400, maxHealth: 400 });
    // Right-bottom
    this.walls.push({ id: 8, x: cx + dist, y: cy + dist - wallLen, width: wallThick, height: wallLen, orientation: 'vertical', health: 400, maxHealth: 400 });
  }

  public initDefaultTurrets() {
    this.turrets = [
      {
        id: 'turret-1',
        x: MAP_WIDTH / 2 - 90,
        y: MAP_HEIGHT / 2 - 90,
        range: 300,
        damage: 18,
        fireRate: 2.2,
        lastFireTime: 0,
        targetId: null,
        angle: -Math.PI / 4,
        level: 1,
      },
    ];
  }

  public startWave(waveNumber: number) {
    this.wave = waveNumber;
    this.waveZombiesTotal = 12 + waveNumber * 8;
    this.waveZombiesRemaining = this.waveZombiesTotal;
    this.waveSpawnTimer = 0;
    this.waveInProgress = true;
    this.isWaveCleared = false;
    soundEngine.playWaveStart();

    this.addFloatingText(this.player.x, this.player.y - 50, `${waveNumber}-TOʻLQIN BOSHLANDI!`, '#ef4444', 2.0);
  }

  public start() {
    this.isRunning = true;
    this.isPaused = false;
    this.lastTime = performance.now();
    this.loop();
  }

  public pause() {
    this.isPaused = true;
  }

  public resume() {
    this.isPaused = false;
    this.lastTime = performance.now();
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  private loop = () => {
    if (!this.isRunning) return;

    const now = performance.now();
    let dt = (now - this.lastTime) / 1000;
    this.lastTime = now;

    // Cap dt to prevent tunneling on frame drops
    if (dt > 0.1) dt = 0.1;

    if (!this.isPaused) {
      this.update(dt);
    }
    this.render();

    this.animationFrameId = requestAnimationFrame(this.loop);
  };

  public update(dt: number) {
    // Screen shake
    if (this.screenShakeTime > 0) {
      this.screenShakeTime -= dt;
    }

    // 1. Player movement & Dash
    if (this.player.dashCooldown > 0) {
      this.player.dashCooldown -= dt;
    }

    let moveSpeed = this.player.speed;
    for (const hz of this.hazardZones) {
      if (Math.hypot(this.player.x - hz.x, this.player.y - hz.y) <= hz.radius + 15) {
        moveSpeed *= hz.slowFactor;
        break;
      }
    }
    const moveLen = Math.hypot(this.moveDir.x, this.moveDir.y);
    if (moveLen > 0.05) {
      const nx = this.moveDir.x / moveLen;
      const ny = this.moveDir.y / moveLen;
      this.player.x += nx * moveSpeed * dt;
      this.player.y += ny * moveSpeed * dt;
    }

    // Map bounds clamping
    this.player.x = Math.max(30, Math.min(MAP_WIDTH - 30, this.player.x));
    this.player.y = Math.max(30, Math.min(MAP_HEIGHT - 30, this.player.y));

    // 2. Auto-Aim assist / Target direction
    if (this.graphics.autoAim && this.zombies.length > 0) {
      let nearestDist = 450;
      let targetZombie: Zombie | null = null;
      for (const z of this.zombies) {
        const d = Math.hypot(z.x - this.player.x, z.y - this.player.y);
        if (d < nearestDist) {
          nearestDist = d;
          targetZombie = z;
        }
      }
      if (targetZombie) {
        const desiredAngle = Math.atan2(targetZombie.y - this.player.y, targetZombie.x - this.player.x);
        this.player.angle = desiredAngle;
      } else if (moveLen > 0.05) {
        this.player.angle = Math.atan2(this.moveDir.y, this.moveDir.x);
      }
    } else if (this.aimAngle !== undefined) {
      this.player.angle = this.aimAngle;
    }

    // 3. Reload logic
    const currentWeapon = this.weapons[this.player.currentWeapon];
    if (this.player.isReloading) {
      this.player.reloadProgress += dt / currentWeapon.reloadTime;
      if (this.player.reloadProgress >= 1) {
        this.player.isReloading = false;
        this.player.reloadProgress = 0;

        if (this.player.currentWeapon === 'pistol') {
          this.player.currentAmmo = currentWeapon.magazineSize;
        } else {
          const needed = currentWeapon.magazineSize - this.player.currentAmmo;
          const available = Math.min(needed, this.resources.ammo);
          this.player.currentAmmo += available;
          this.resources.ammo -= available;
          this.callbacks.onResourcesChange({ ...this.resources });
        }

        this.callbacks.onWeaponChange(
          currentWeapon,
          this.player.currentAmmo,
          currentWeapon.magazineSize,
          false
        );
      }
    }

    // 4. Player Firing
    if (this.isFiring && !this.player.isReloading) {
      const now = performance.now() / 1000;
      const interval = 1 / currentWeapon.fireRate;
      if (now - this.lastFireTime >= interval) {
        if (this.player.currentAmmo > 0) {
          this.fireWeapon(currentWeapon);
          this.lastFireTime = now;
        } else {
          this.reload();
        }
      }
    }

    // 5. Update Bullets
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      const travel = Math.hypot(b.vx * dt, b.vy * dt);
      b.rangeRemaining -= travel;

      // Check collision with zombies
      let bulletHit = false;
      for (let j = this.zombies.length - 1; j >= 0; j--) {
        const z = this.zombies[j];
        const dist = Math.hypot(b.x - z.x, b.y - z.y);
        if (dist <= z.radius + b.radius) {
          this.damageZombie(z, b.damage, b.x, b.y, b.isRpg);
          b.pierceCount--;

          if (b.isRpg) {
            this.triggerExplosion(b.x, b.y, 140, b.damage);
            bulletHit = true;
            break;
          }

          if (b.pierceCount <= 0) {
            bulletHit = true;
            break;
          }
        }
      }

      if (
        bulletHit ||
        b.rangeRemaining <= 0 ||
        b.x < 0 ||
        b.x > MAP_WIDTH ||
        b.y < 0 ||
        b.y > MAP_HEIGHT
      ) {
        this.bullets.splice(i, 1);
      }
    }

    // 6. Update Turrets
    this.updateTurrets(dt);

    // 7. Update Acid Spits
    for (let i = this.acidSpits.length - 1; i >= 0; i--) {
      const spit = this.acidSpits[i];
      spit.x += spit.vx * dt;
      spit.y += spit.vy * dt;

      // Hit player?
      const pDist = Math.hypot(spit.x - this.player.x, spit.y - this.player.y);
      if (pDist < 20 + spit.radius) {
        this.damagePlayer(spit.damage);
        this.acidSpits.splice(i, 1);
        continue;
      }

      // Hit Base?
      const bDist = Math.hypot(spit.x - this.base.x, spit.y - this.base.y);
      if (bDist < this.base.radius) {
        this.damageBase(spit.damage);
        this.acidSpits.splice(i, 1);
        continue;
      }

      // Hit walls?
      let hitWall = false;
      for (const w of this.walls) {
        if (w.health > 0 && this.checkPointInRect(spit.x, spit.y, w.x, w.y, w.width, w.height)) {
          w.health = Math.max(0, w.health - spit.damage);
          this.createSparks(spit.x, spit.y, '#84cc16', 5);
          hitWall = true;
          break;
        }
      }

      if (hitWall || spit.x < 0 || spit.x > MAP_WIDTH || spit.y < 0 || spit.y > MAP_HEIGHT) {
        this.acidSpits.splice(i, 1);
      }
    }

    // 8. Wave Spawner
    this.updateWaveSpawner(dt);

    // 9. Update Zombies
    this.updateZombies(dt);

    // 9.5 Update Hazard Zones (toxic radiation from kamikaze exploders)
    this.updateHazardZones(dt);

    // 10. Update Resource Drops & magnet
    this.updateDrops(dt);

    // 11. Update Particles & Floating Text
    this.updateEffects(dt);

    // 12. Camera Follow Player
    this.updateCamera();

    // Check Victory of current wave
    if (this.waveInProgress && this.waveZombiesRemaining === 0 && this.zombies.length === 0 && !this.isWaveCleared) {
      this.isWaveCleared = true;
      this.waveInProgress = false;
      soundEngine.playWaveVictory();

      // Bonus rewards for wave completion
      const bonusCoins = 50 + this.wave * 35;
      const bonusWood = 20 + this.wave * 10;
      const bonusMetal = 10 + this.wave * 8;
      this.resources.coins += bonusCoins;
      this.resources.wood += bonusWood;
      this.resources.metal += bonusMetal;
      this.callbacks.onResourcesChange({ ...this.resources });

      this.addFloatingText(this.player.x, this.player.y - 60, `${this.wave}-TOʻLQIN YENGILDI!`, '#22c55e', 2.5);
      this.callbacks.onWaveComplete(this.wave);
    }
  }

  private updateCamera() {
    const viewW = this.canvas.width;
    const viewH = this.canvas.height;
    // Keep player in center of screen
    this.camera.x = this.player.x - viewW / 2;
    this.camera.y = this.player.y - viewH / 2;

    // Clamp camera to map bounds
    this.camera.x = Math.max(0, Math.min(MAP_WIDTH - viewW, this.camera.x));
    this.camera.y = Math.max(0, Math.min(MAP_HEIGHT - viewH, this.camera.y));
  }

  private fireWeapon(weapon: WeaponConfig) {
    const angle = this.player.angle;
    this.player.currentAmmo--;

    // Recoil / Muzzle Flash
    const muzzleX = this.player.x + Math.cos(angle) * 28;
    const muzzleY = this.player.y + Math.sin(angle) * 28;
    this.createMuzzleFlash(muzzleX, muzzleY, angle);

    // Sound
    if (weapon.id === 'pistol') soundEngine.playPistol();
    else if (weapon.id === 'shotgun') soundEngine.playShotgun();
    else if (weapon.id === 'rifle') soundEngine.playRifle();
    else if (weapon.id === 'sniper') soundEngine.playSniper();
    else if (weapon.id === 'rpg') soundEngine.playExplosion();
    else soundEngine.playPistol();

    // Spawn bullets (shotguns have multiple pellets)
    for (let p = 0; p < weapon.pellets; p++) {
      const spreadAngle = angle + (Math.random() - 0.5) * weapon.spread;
      const speed = weapon.bulletSpeed * (0.95 + Math.random() * 0.1);
      const isRpg = weapon.id === 'rpg';
      const isPlasma = weapon.id === 'plasma';
      const pierce = weapon.id === 'sniper' ? 4 : isPlasma ? 2 : 1;

      this.bullets.push({
        id: Math.random().toString(),
        x: muzzleX,
        y: muzzleY,
        vx: Math.cos(spreadAngle) * speed,
        vy: Math.sin(spreadAngle) * speed,
        damage: weapon.damage,
        radius: isRpg ? 7 : isPlasma ? 8 : 4,
        rangeRemaining: isRpg ? 700 : weapon.id === 'shotgun' ? 380 : 900,
        isRpg,
        isPlasma,
        pierceCount: pierce,
        color: isPlasma ? '#06b6d4' : isRpg ? '#f97316' : '#fde047',
      });
    }

    this.callbacks.onWeaponChange(
      weapon,
      this.player.currentAmmo,
      weapon.magazineSize,
      false
    );
  }

  public reload() {
    const currentWeapon = this.weapons[this.player.currentWeapon];
    if (this.player.isReloading) return;
    if (this.player.currentAmmo >= currentWeapon.magazineSize) return;
    if (this.player.currentWeapon !== 'pistol' && this.resources.ammo <= 0) {
      this.addFloatingText(this.player.x, this.player.y - 30, "O'Q TUGADI!", '#ef4444', 1.0);
      return;
    }

    this.player.isReloading = true;
    this.player.reloadProgress = 0;
    soundEngine.playReload();
    this.callbacks.onWeaponChange(
      currentWeapon,
      this.player.currentAmmo,
      currentWeapon.magazineSize,
      true
    );
  }

  public switchWeapon(type?: WeaponType) {
    const weaponKeys = Object.keys(this.weapons) as WeaponType[];
    const unlocked = weaponKeys.filter((k) => this.weapons[k].unlocked);

    let nextType: WeaponType;
    if (type && this.weapons[type]?.unlocked) {
      nextType = type;
    } else {
      const curIdx = unlocked.indexOf(this.player.currentWeapon);
      nextType = unlocked[(curIdx + 1) % unlocked.length];
    }

    this.player.currentWeapon = nextType;
    this.player.isReloading = false;
    this.player.reloadProgress = 0;
    const w = this.weapons[nextType];
    this.player.currentAmmo = Math.min(w.magazineSize, this.player.currentAmmo > 0 ? this.player.currentAmmo : w.magazineSize);

    soundEngine.playReload();
    this.callbacks.onWeaponChange(w, this.player.currentAmmo, w.magazineSize, false);
    this.addFloatingText(this.player.x, this.player.y - 40, w.name, '#38bdf8', 1.2);
  }

  public dash() {
    const now = performance.now() / 1000;
    if (this.player.dashCooldown > 0) return;

    this.player.dashCooldown = 2.5;
    this.player.lastDashTime = now;

    const angle = this.player.angle;
    const dashDist = 140;
    const targetX = this.player.x + Math.cos(angle) * dashDist;
    const targetY = this.player.y + Math.sin(angle) * dashDist;

    // Create ghost trail particles
    for (let i = 0; i < 8; i++) {
      const t = i / 8;
      this.particles.push({
        x: this.player.x + (targetX - this.player.x) * t,
        y: this.player.y + (targetY - this.player.y) * t,
        vx: (Math.random() - 0.5) * 40,
        vy: (Math.random() - 0.5) * 40,
        radius: 12,
        color: '#38bdf8',
        alpha: 0.6,
        decay: 2.0,
      });
    }

    this.player.x = Math.max(30, Math.min(MAP_WIDTH - 30, targetX));
    this.player.y = Math.max(30, Math.min(MAP_HEIGHT - 30, targetY));
    soundEngine.playPickup();
  }

  public throwGrenade() {
    if (this.player.grenades <= 0) {
      this.addFloatingText(this.player.x, this.player.y - 30, "GRANATA YO'Q!", '#ef4444', 1.0);
      return;
    }

    this.player.grenades--;
    const angle = this.player.angle;
    const gx = this.player.x + Math.cos(angle) * 160;
    const gy = this.player.y + Math.sin(angle) * 160;

    // Delay explosion 0.7s
    setTimeout(() => {
      this.triggerExplosion(gx, gy, 200, 320);
    }, 700);

    // Throwing trail
    for (let i = 0; i < 10; i++) {
      this.particles.push({
        x: this.player.x + (gx - this.player.x) * (i / 10),
        y: this.player.y + (gy - this.player.y) * (i / 10),
        vx: 0,
        vy: 0,
        radius: 3,
        color: '#4ade80',
        alpha: 0.8,
        decay: 1.5,
      });
    }
  }

  public repairBaseOrWall() {
    // Check if near base core
    const distToBase = Math.hypot(this.player.x - this.base.x, this.player.y - this.base.y);
    let repairedSomething = false;

    if (distToBase < this.base.radius + 60 && this.base.health < this.base.maxHealth) {
      const woodCost = 15;
      const metalCost = 8;
      if (this.resources.wood >= woodCost && this.resources.metal >= metalCost) {
        this.resources.wood -= woodCost;
        this.resources.metal -= metalCost;
        const healAmount = 150 * this.base.repairEfficiencyLevel;
        this.base.health = Math.min(this.base.maxHealth, this.base.health + healAmount);
        this.callbacks.onBaseHpChange(this.base.health, this.base.maxHealth);
        this.callbacks.onResourcesChange({ ...this.resources });
        this.createSparks(this.base.x, this.base.y, '#3b82f6', 15);
        soundEngine.playRepair();
        this.addFloatingText(this.base.x, this.base.y - 40, `BAZA +${healAmount} HP`, '#38bdf8', 1.5);
        repairedSomething = true;
      } else {
        this.addFloatingText(this.player.x, this.player.y - 30, 'RESURS YETARLI EMAS (15 Yogʻoch, 8 Metall)', '#ef4444', 1.2);
        return;
      }
    }

    // Check near walls
    for (const w of this.walls) {
      const wxCenter = w.x + w.width / 2;
      const wyCenter = w.y + w.height / 2;
      const dist = Math.hypot(this.player.x - wxCenter, this.player.y - wyCenter);
      if (dist < 80 && w.health < w.maxHealth) {
        const woodCost = 10;
        if (this.resources.wood >= woodCost) {
          this.resources.wood -= woodCost;
          const heal = 120;
          w.health = Math.min(w.maxHealth, w.health + heal);
          this.callbacks.onResourcesChange({ ...this.resources });
          this.createSparks(wxCenter, wyCenter, '#fbbf24', 12);
          soundEngine.playRepair();
          this.addFloatingText(wxCenter, wyCenter - 20, `DEVOR +${heal} HP`, '#22c55e', 1.2);
          repairedSomething = true;
          break;
        } else {
          this.addFloatingText(this.player.x, this.player.y - 30, 'YOGʻOCH YETARLI EMAS (10 dona)', '#ef4444', 1.2);
          return;
        }
      }
    }

    if (!repairedSomething) {
      this.addFloatingText(this.player.x, this.player.y - 30, 'TAʼMIRLASH UCHUN BAZA YOKI DEVORGA YAQINLASHING!', '#f59e0b', 1.3);
    }
  }

  public placeTurret() {
    const costMetal = 40;
    const costWood = 25;

    if (this.resources.metal < costMetal || this.resources.wood < costWood) {
      this.addFloatingText(this.player.x, this.player.y - 30, 'MINORA UCHUN 40 METALL VA 25 YOGʻOCH KERAK!', '#ef4444', 1.2);
      return;
    }

    if (this.turrets.length >= 6) {
      this.addFloatingText(this.player.x, this.player.y - 30, 'MAKSIMAL 6 TA MINORA MUMKIN!', '#f59e0b', 1.2);
      return;
    }

    this.resources.metal -= costMetal;
    this.resources.wood -= costWood;
    this.callbacks.onResourcesChange({ ...this.resources });

    this.turrets.push({
      id: 'turret-' + Date.now(),
      x: this.player.x,
      y: this.player.y,
      range: 320,
      damage: 22,
      fireRate: 2.5,
      lastFireTime: 0,
      targetId: null,
      angle: this.player.angle,
      level: 1,
    });

    this.createSparks(this.player.x, this.player.y, '#3b82f6', 20);
    soundEngine.playRepair();
    this.addFloatingText(this.player.x, this.player.y - 40, 'YANGI MINORA OʻRNATILDI!', '#38bdf8', 1.5);
  }

  private triggerExplosion(x: number, y: number, radius: number, damage: number) {
    soundEngine.playExplosion();
    this.triggerScreenShake(0.3, 14);

    // Particle flash and blast rings
    for (let i = 0; i < 35; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 60 + Math.random() * 280;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: 4 + Math.random() * 8,
        color: Math.random() > 0.4 ? '#f97316' : '#facc15',
        alpha: 1,
        decay: 1.2 + Math.random(),
      });
    }

    // Damage all zombies in radius
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      const dist = Math.hypot(z.x - x, z.y - y);
      if (dist <= radius) {
        const falloff = 1 - dist / radius;
        const dealt = Math.round(damage * (0.4 + falloff * 0.6));
        this.damageZombie(z, dealt, z.x, z.y, true);
      }
    }
  }

  // 3. Portlovchi Zombi (Kamikaze) Maxsus Toksik Portlash Qobiliyati
  public triggerToxicDetonation(x: number, y: number, radius: number, damage: number) {
    soundEngine.playExplosion();
    soundEngine.playToxicHiss();
    this.triggerScreenShake(0.35, 16);

    // Blast particles: Fire + toxic neon green shockwave
    for (let i = 0; i < 40; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 60 + Math.random() * 260;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: 4 + Math.random() * 8,
        color: i % 2 === 0 ? '#84cc16' : i % 3 === 0 ? '#22c55e' : '#ea580c',
        alpha: 1,
        decay: 1.0 + Math.random() * 0.8,
      });
    }

    // Damage all zombies in blast radius (chain reactions!)
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      const dist = Math.hypot(z.x - x, z.y - y);
      if (dist <= radius) {
        const falloff = 1 - dist / radius;
        const dealt = Math.round(damage * (0.5 + falloff * 0.5));
        this.damageZombie(z, dealt, z.x, z.y, true);
      }
    }

    // Damage Player if in blast
    const pDist = Math.hypot(this.player.x - x, this.player.y - y);
    if (pDist <= radius) {
      const falloff = 1 - pDist / radius;
      this.damagePlayer(Math.round(damage * 0.7 * falloff));
      this.addFloatingText(this.player.x, this.player.y - 40, 'TOKSIK ZARBA!', '#ef4444', 1.3);
    }

    // Damage Base Core if in blast
    const bDist = Math.hypot(this.base.x - x, this.base.y - y);
    if (bDist <= radius + this.base.radius) {
      this.damageBase(Math.round(damage * 0.6));
    }

    // Damage Walls in blast
    for (const w of this.walls) {
      if (w.health > 0) {
        const wx = w.x + w.width / 2;
        const wy = w.y + w.height / 2;
        if (Math.hypot(wx - x, wy - y) <= radius + 30) {
          w.health = Math.max(0, w.health - damage);
          this.createSparks(wx, wy, '#84cc16', 10);
        }
      }
    }

    // Spawn lingering Toxic Chemical Hazard Zone (lasts 5.0 seconds)
    this.hazardZones.push({
      id: Math.random().toString(),
      x,
      y,
      radius: 95,
      life: 5.0,
      maxLife: 5.0,
      damagePerSec: 14,
      slowFactor: 0.65,
      color: '#22c55e',
    });
  }

  private updateHazardZones(dt: number) {
    for (let i = this.hazardZones.length - 1; i >= 0; i--) {
      const hz = this.hazardZones[i];
      hz.life -= dt;

      // Spawn ambient toxic bubbling vapor particles
      if (Math.random() < 0.35) {
        const angle = Math.random() * Math.PI * 2;
        const r = Math.random() * hz.radius * 0.85;
        this.particles.push({
          x: hz.x + Math.cos(angle) * r,
          y: hz.y + Math.sin(angle) * r,
          vx: (Math.random() - 0.5) * 15,
          vy: -20 - Math.random() * 25,
          radius: 2 + Math.random() * 3,
          color: Math.random() > 0.4 ? '#84cc16' : '#22c55e',
          alpha: 0.6,
          decay: 1.8,
        });
      }

      // Check Player in toxic puddle
      const pDist = Math.hypot(this.player.x - hz.x, this.player.y - hz.y);
      if (pDist < hz.radius + 14) {
        // Slow player down
        this.player.x -= this.player.vx * dt * (1 - hz.slowFactor);
        this.player.y -= this.player.vy * dt * (1 - hz.slowFactor);
        // Damage over time (ticks approx every 0.45s)
        if (Math.random() < dt * 2.2) {
          this.damagePlayer(Math.round(hz.damagePerSec * 0.45));
          soundEngine.playToxicHiss();
          this.addFloatingText(this.player.x + (Math.random() - 0.5) * 20, this.player.y - 25, '☣ ZAHARLANISH!', '#84cc16', 0.95);
        }
      }

      if (hz.life <= 0) {
        this.hazardZones.splice(i, 1);
      }
    }
  }

  private updateTurrets(dt: number) {
    const now = performance.now() / 1000;
    for (const t of this.turrets) {
      // Find nearest zombie in range
      let nearest: Zombie | null = null;
      let minDist = t.range;
      for (const z of this.zombies) {
        const d = Math.hypot(z.x - t.x, z.y - t.y);
        if (d < minDist) {
          minDist = d;
          nearest = z;
        }
      }

      if (nearest) {
        t.angle = Math.atan2(nearest.y - t.y, nearest.x - t.x);
        if (now - t.lastFireTime >= 1 / t.fireRate) {
          t.lastFireTime = now;
          soundEngine.playPistol();

          this.bullets.push({
            id: Math.random().toString(),
            x: t.x + Math.cos(t.angle) * 18,
            y: t.y + Math.sin(t.angle) * 18,
            vx: Math.cos(t.angle) * 800,
            vy: Math.sin(t.angle) * 800,
            damage: t.damage,
            radius: 4,
            rangeRemaining: t.range,
            isTurret: true,
            pierceCount: 1,
            color: '#38bdf8',
          });
        }
      }
    }
  }

  private updateWaveSpawner(dt: number) {
    if (!this.waveInProgress || this.waveZombiesRemaining <= 0) return;

    this.waveSpawnTimer += dt;
    const spawnInterval = Math.max(0.4, 2.2 - this.wave * 0.12);

    if (this.waveSpawnTimer >= spawnInterval) {
      this.waveSpawnTimer = 0;
      this.spawnZombie();
      this.waveZombiesRemaining--;
    }
  }

  private spawnZombie() {
    // Pick random edge of map
    let x = 0;
    let y = 0;
    const side = Math.floor(Math.random() * 4);
    const margin = 20;

    if (side === 0) {
      // Top
      x = Math.random() * MAP_WIDTH;
      y = margin;
    } else if (side === 1) {
      // Bottom
      x = Math.random() * MAP_WIDTH;
      y = MAP_HEIGHT - margin;
    } else if (side === 2) {
      // Left
      x = margin;
      y = Math.random() * MAP_HEIGHT;
    } else {
      // Right
      x = MAP_WIDTH - margin;
      y = Math.random() * MAP_HEIGHT;
    }

    // Determine zombie type based on wave
    let type: ZombieType = 'walker';
    const rand = Math.random();

    if (this.wave >= 6 && this.waveZombiesRemaining === 1 && !this.zombies.some((z) => z.isBoss)) {
      type = 'boss';
    } else if (this.wave >= 4 && rand < 0.22) {
      type = 'kamikaze'; // 3. Portlovchi Zombi (Kamikaze toxic bomber)
    } else if (this.wave >= 3 && rand < 0.44) {
      type = 'armored'; // 2. Zirhli Zombi (Iron armored juggernaut)
    } else if (this.wave >= 2 && rand < 0.65) {
      type = 'sprinter'; // 1. Tezkor Zombi (Fast sprinter with lightning dash)
    } else if (this.wave === 1 && rand < 0.25) {
      type = 'sprinter'; // 1. Tezkor Zombi right from Wave 1!
    } else if (this.wave >= 4 && rand < 0.76) {
      type = 'spitter';
    } else if (this.wave >= 3 && rand < 0.86) {
      type = 'tank';
    } else if (this.wave >= 2 && rand < 0.93) {
      type = 'runner';
    } else {
      type = 'walker';
    }

    const hpMultiplier = 1 + (this.wave - 1) * 0.15;
    let baseHp = 60;
    let speed = 90;
    let radius = 16;
    let damage = 10;
    let color = '#22c55e';
    let isBoss = false;
    let isArmored = false;
    let scoreVal = 10;
    let woodDrop = 2;
    let metalDrop = 1;
    let coinDrop = 5;
    let attackCooldown = 1.0;

    switch (type) {
      case 'sprinter':
        // 1. Tezkor Zombi: Yuqori tezlik va chaqmoq dash
        baseHp = 52;
        speed = 215;
        radius = 15;
        damage = 12;
        color = '#f59e0b';
        scoreVal = 22;
        coinDrop = 12;
        attackCooldown = 0.65;
        break;
      case 'armored':
        // 2. Zirhli Zombi: Ogʻir poʻlat zirh, 50% zararni qaytarish, devorlarni maydalash
        baseHp = 340;
        speed = 62;
        radius = 25;
        damage = 28;
        color = '#64748b';
        isArmored = true;
        scoreVal = 50;
        woodDrop = 4;
        metalDrop = 9; // Koʻp metall qoldiradi
        coinDrop = 25;
        attackCooldown = 1.2;
        break;
      case 'kamikaze':
        // 3. Portlovchi Zombi: Yaqinlashganda portlaydi va zaharli maydon qoldiradi
        baseHp = 70;
        speed = 135;
        radius = 19;
        damage = 35;
        color = '#ea580c';
        scoreVal = 32;
        coinDrop = 16;
        attackCooldown = 0.8;
        break;
      case 'runner':
        baseHp = 45;
        speed = 160;
        radius = 14;
        damage = 8;
        color = '#eab308';
        scoreVal = 15;
        coinDrop = 8;
        break;
      case 'tank':
        baseHp = 260;
        speed = 55;
        radius = 26;
        damage = 25;
        color = '#7c2d12';
        scoreVal = 40;
        woodDrop = 4;
        metalDrop = 4;
        coinDrop = 25;
        break;
      case 'spitter':
        baseHp = 70;
        speed = 80;
        radius = 16;
        damage = 14;
        color = '#84cc16';
        scoreVal = 25;
        coinDrop = 15;
        break;
      case 'boss':
        baseHp = 800;
        speed = 70;
        radius = 36;
        damage = 45;
        color = '#991b1b';
        isBoss = true;
        scoreVal = 150;
        woodDrop = 20;
        metalDrop = 15;
        coinDrop = 100;
        break;
    }

    const targetType: 'base' | 'player' = Math.random() > 0.4 ? 'base' : 'player';

    this.zombies.push({
      id: Math.random().toString(),
      type,
      x,
      y,
      vx: 0,
      vy: 0,
      radius,
      health: Math.round(baseHp * hpMultiplier),
      maxHealth: Math.round(baseHp * hpMultiplier),
      speed: speed * (0.9 + Math.random() * 0.2),
      damage,
      attackCooldown,
      lastAttackTime: 0,
      color,
      targetType,
      isBoss,
      isArmored,
      dashCooldown: type === 'sprinter' ? 1.5 + Math.random() * 2 : undefined,
      isDashing: false,
      dashTimer: 0,
      detonating: false,
      detonationTimer: 0.55,
      scoreValue: scoreVal,
      woodDrop,
      metalDrop,
      coinDrop,
      ammoDropChance: 0.35,
    });
  }

  private updateZombies(dt: number) {
    const now = performance.now() / 1000;

    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];

      // Target selection: Player or Base Core
      let targetX = this.base.x;
      let targetY = this.base.y;

      const distToPlayer = Math.hypot(this.player.x - z.x, this.player.y - z.y);
      const distToBase = Math.hypot(this.base.x - z.x, this.base.y - z.y);

      if (z.targetType === 'player' || distToPlayer < 240) {
        targetX = this.player.x;
        targetY = this.player.y;
      }

      // 3. Portlovchi Zombi (Kamikaze): Yaqin kelganda taymer boshlanadi va portlaydi
      if (z.type === 'kamikaze') {
        const nearTarget = distToPlayer < 65 || distToBase < z.radius + this.base.radius + 15;
        if (nearTarget && !z.detonating) {
          z.detonating = true;
          z.detonationTimer = 0.55;
          soundEngine.playFuseBeep();
          this.addFloatingText(z.x, z.y - 25, '⚠️ PORTLASH!', '#ef4444', 1.25);
        }

        if (z.detonating) {
          z.vx = 0;
          z.vy = 0;
          z.detonationTimer = (z.detonationTimer ?? 0.55) - dt;

          // Detonation sparks and toxic fumes
          if (Math.random() < 0.8) {
            this.particles.push({
              x: z.x + (Math.random() - 0.5) * 14,
              y: z.y + (Math.random() - 0.5) * 14,
              vx: (Math.random() - 0.5) * 35,
              vy: -20 - Math.random() * 30,
              radius: 3,
              color: Math.random() > 0.4 ? '#ef4444' : '#84cc16',
              alpha: 0.9,
              decay: 2.2,
            });
          }

          if (z.detonationTimer <= 0) {
            this.triggerToxicDetonation(z.x, z.y, 160, 85);
            this.kills++;
            this.score += z.scoreValue;
            this.spawnDrops(z);
            this.zombies.splice(i, 1);
            continue;
          }
          // Don't do standard movement or attack while ticking down
          continue;
        }
      }

      // Spitter ranged attack
      if (z.type === 'spitter') {
        if (!z.spitCooldown) z.spitCooldown = 0;
        z.spitCooldown -= dt;
        if (z.spitCooldown <= 0 && distToPlayer < 350) {
          z.spitCooldown = 2.5;
          const sAngle = Math.atan2(this.player.y - z.y, this.player.x - z.x);
          this.acidSpits.push({
            id: Math.random().toString(),
            x: z.x,
            y: z.y,
            vx: Math.cos(sAngle) * 320,
            vy: Math.sin(sAngle) * 320,
            damage: z.damage,
            radius: 8,
          });
        }
      }

      // 1. Tezkor Zombi (Sprinter): Chaqmoqdek tezlik va qisqa masofaga dash
      let effectiveSpeed = z.speed;
      if (z.type === 'sprinter') {
        if (z.isDashing) {
          effectiveSpeed = z.speed * 2.0;
          z.dashTimer = (z.dashTimer ?? 0.45) - dt;
          if (z.dashTimer <= 0) {
            z.isDashing = false;
          }
          // Motion trail ghost particles
          if (Math.random() < 0.5) {
            this.particles.push({
              x: z.x,
              y: z.y,
              vx: (Math.random() - 0.5) * 20,
              vy: (Math.random() - 0.5) * 20,
              radius: z.radius * 0.75,
              color: '#f59e0b',
              alpha: 0.5,
              decay: 3.5,
            });
          }
        } else {
          z.dashCooldown = (z.dashCooldown ?? 2.5) - dt;
          if (z.dashCooldown <= 0 && (distToPlayer < 280 || distToBase < 240)) {
            z.isDashing = true;
            z.dashTimer = 0.45;
            z.dashCooldown = 3.2;
            soundEngine.playDashSwoosh();
            this.addFloatingText(z.x, z.y - 20, '⚡ DASH!', '#facc15', 1.1);
          }
        }
      }

      // Movement towards target
      const angle = Math.atan2(targetY - z.y, targetX - z.x);
      z.vx = Math.cos(angle) * effectiveSpeed;
      z.vy = Math.sin(angle) * effectiveSpeed;

      // Check wall collisions (zombies get blocked and attack walls)
      let hitWall: WallSegment | null = null;
      for (const w of this.walls) {
        if (w.health > 0) {
          const nextX = z.x + z.vx * dt;
          const nextY = z.y + z.vy * dt;
          if (this.checkCircleRect(nextX, nextY, z.radius, w.x, w.y, w.width, w.height)) {
            hitWall = w;
            break;
          }
        }
      }

      if (hitWall) {
        // Attack the wall!
        if (now - z.lastAttackTime >= z.attackCooldown) {
          z.lastAttackTime = now;
          // 2. Zirhli Zombi devorlarga 2 baravar koʻp zarar yetkazadi
          const wallDmg = z.type === 'armored' ? z.damage * 2 : z.damage;
          hitWall.health = Math.max(0, hitWall.health - wallDmg);
          soundEngine.playBaseHit();

          if (z.type === 'armored') {
            soundEngine.playMetalClang();
            this.createSparks(z.x, z.y, '#94a3b8', 8);
            this.addFloatingText(hitWall.x + hitWall.width / 2, hitWall.y - 15, `DEVORGA -${wallDmg}!`, '#f87171', 1.1);
          } else {
            this.createSparks(z.x, z.y, '#e5e7eb', 4);
          }

          if (z.type === 'boomer') {
            this.triggerExplosion(z.x, z.y, 110, z.damage * 2);
            this.zombies.splice(i, 1);
            continue;
          }

          if (z.type === 'kamikaze') {
            this.triggerToxicDetonation(z.x, z.y, 160, 85);
            this.zombies.splice(i, 1);
            continue;
          }
        }
      } else {
        // Move freely
        z.x += z.vx * dt;
        z.y += z.vy * dt;
      }

      // Check attack on Player
      if (distToPlayer <= z.radius + 18) {
        if (now - z.lastAttackTime >= z.attackCooldown) {
          z.lastAttackTime = now;
          this.damagePlayer(z.damage);
          if (z.type === 'boomer') {
            this.triggerExplosion(z.x, z.y, 120, z.damage * 2);
            this.zombies.splice(i, 1);
            continue;
          }
          if (z.type === 'kamikaze') {
            this.triggerToxicDetonation(z.x, z.y, 160, 85);
            this.zombies.splice(i, 1);
            continue;
          }
        }
      }

      // Check attack on Base Core
      if (distToBase <= z.radius + this.base.radius) {
        if (now - z.lastAttackTime >= z.attackCooldown) {
          z.lastAttackTime = now;
          this.damageBase(z.damage);
          if (z.type === 'boomer') {
            this.triggerExplosion(z.x, z.y, 130, z.damage * 2);
            this.zombies.splice(i, 1);
            continue;
          }
          if (z.type === 'kamikaze') {
            this.triggerToxicDetonation(z.x, z.y, 160, 85);
            this.zombies.splice(i, 1);
            continue;
          }
        }
      }
    }
  }

  private damageZombie(z: Zombie, damage: number, hitX: number, hitY: number, isExplosion = false) {
    // 2. Zirhli Zombi: Oʻqlardan 50% himoya (portlashlar toʻliq ta'sir qiladi)
    let actualDamage = damage;
    if (z.type === 'armored' && !isExplosion) {
      actualDamage = Math.max(1, Math.round(damage * 0.5));
      soundEngine.playMetalClang();
      this.createSparks(hitX, hitY, '#94a3b8', 6);
      this.createSparks(hitX, hitY, '#38bdf8', 4);
    } else {
      soundEngine.playZombieHit();
    }

    z.health -= actualDamage;

    // Floating damage text
    if (this.graphics.damageNumbers) {
      const isCrit = Math.random() > 0.75;
      this.addFloatingText(
        hitX + (Math.random() - 0.5) * 20,
        hitY - 15,
        z.type === 'armored' && !isExplosion ? `🛡️ -${actualDamage}` : `-${actualDamage}`,
        z.type === 'armored' && !isExplosion ? '#94a3b8' : isCrit ? '#fbbf24' : '#ffffff',
        isCrit ? 1.4 : 1.0
      );
    }

    // Blood splatters and particles
    if (this.graphics.particleQuality !== 'low') {
      const pCount = this.graphics.particleQuality === 'high' ? 8 : 4;
      for (let i = 0; i < pCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 40 + Math.random() * 120;
        this.particles.push({
          x: hitX,
          y: hitY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          radius: 2 + Math.random() * 3,
          color: z.type === 'armored' ? '#64748b' : z.color,
          alpha: 0.9,
          decay: 2.0,
        });
      }
    }

    // Zombie died
    if (z.health <= 0) {
      this.kills++;
      this.score += z.scoreValue;
      soundEngine.playZombieGroan();

      // 3. Portlovchi Zombi o'lganda ham zaharli portlash hosil qiladi
      if (z.type === 'kamikaze') {
        this.triggerToxicDetonation(z.x, z.y, 150, 75);
      }

      // Blood Decal on ground
      if (this.graphics.bloodDecals) {
        this.bloodDecals.push({
          x: z.x,
          y: z.y,
          radius: z.radius * (1.2 + Math.random() * 0.5),
          color: z.type === 'spitter' || z.type === 'kamikaze' ? 'rgba(132, 204, 22, 0.45)' : 'rgba(153, 27, 27, 0.5)',
          alpha: 0.85,
        });
        if (this.bloodDecals.length > 50) this.bloodDecals.shift();
      }

      // Drop resources
      this.spawnDrops(z);

      // Remove zombie
      const idx = this.zombies.indexOf(z);
      if (idx !== -1) {
        this.zombies.splice(idx, 1);
      }
    }
  }

  private spawnDrops(z: Zombie) {
    // Wood
    if (z.woodDrop > 0 && Math.random() > 0.3) {
      this.drops.push({
        id: Math.random().toString(),
        x: z.x + (Math.random() - 0.5) * 20,
        y: z.y + (Math.random() - 0.5) * 20,
        type: 'wood',
        amount: z.woodDrop,
        life: 25,
      });
    }
    // Metal
    if (z.metalDrop > 0 && Math.random() > 0.4) {
      this.drops.push({
        id: Math.random().toString(),
        x: z.x + (Math.random() - 0.5) * 20,
        y: z.y + (Math.random() - 0.5) * 20,
        type: 'metal',
        amount: z.metalDrop,
        life: 25,
      });
    }
    // Coins
    if (z.coinDrop > 0) {
      this.drops.push({
        id: Math.random().toString(),
        x: z.x + (Math.random() - 0.5) * 20,
        y: z.y + (Math.random() - 0.5) * 20,
        type: 'coin',
        amount: z.coinDrop,
        life: 25,
      });
    }
    // Ammo or Medkit chance
    if (Math.random() < z.ammoDropChance) {
      const isMedkit = Math.random() < 0.25;
      this.drops.push({
        id: Math.random().toString(),
        x: z.x + (Math.random() - 0.5) * 20,
        y: z.y + (Math.random() - 0.5) * 20,
        type: isMedkit ? 'medkit' : 'ammo',
        amount: isMedkit ? 30 : 25,
        life: 30,
      });
    }
  }

  private updateDrops(dt: number) {
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.life -= dt;

      // Magnetic attraction to player
      const dist = Math.hypot(this.player.x - d.x, this.player.y - d.y);
      if (dist < 110) {
        const pull = 280 * dt;
        const angle = Math.atan2(this.player.y - d.y, this.player.x - d.x);
        d.x += Math.cos(angle) * pull;
        d.y += Math.sin(angle) * pull;
      }

      // Collect drop
      if (dist < 28) {
        soundEngine.playPickup();
        if (d.type === 'wood') {
          this.resources.wood += d.amount;
          this.addFloatingText(d.x, d.y - 15, `+${d.amount} Yogʻoch`, '#a16207', 1.0);
        } else if (d.type === 'metal') {
          this.resources.metal += d.amount;
          this.addFloatingText(d.x, d.y - 15, `+${d.amount} Metall`, '#94a3b8', 1.0);
        } else if (d.type === 'coin') {
          this.resources.coins += d.amount;
          this.addFloatingText(d.x, d.y - 15, `+${d.amount} Tanga`, '#facc15', 1.0);
        } else if (d.type === 'ammo') {
          this.resources.ammo += d.amount;
          this.addFloatingText(d.x, d.y - 15, `+${d.amount} Oʻq`, '#fb923c', 1.0);
        } else if (d.type === 'medkit') {
          this.player.health = Math.min(this.player.maxHealth, this.player.health + d.amount);
          this.callbacks.onPlayerHpChange(this.player.health, this.player.maxHealth);
          this.addFloatingText(d.x, d.y - 15, `+${d.amount} HP`, '#22c55e', 1.2);
        }

        this.callbacks.onResourcesChange({ ...this.resources });
        this.drops.splice(i, 1);
        continue;
      }

      if (d.life <= 0) {
        this.drops.splice(i, 1);
      }
    }
  }

  private damagePlayer(amount: number) {
    this.player.health = Math.max(0, this.player.health - amount);
    this.callbacks.onPlayerHpChange(this.player.health, this.player.maxHealth);
    soundEngine.playZombieHit();
    this.triggerScreenShake(0.2, 8);

    if (this.player.health <= 0) {
      this.callbacks.onGameOver({ wave: this.wave, kills: this.kills, score: this.score });
      this.stop();
    }
  }

  private damageBase(amount: number) {
    const defenseReduction = Math.max(0.6, 1 - (this.base.defenseLevel - 1) * 0.1);
    const dealt = Math.round(amount * defenseReduction);
    this.base.health = Math.max(0, this.base.health - dealt);
    this.callbacks.onBaseHpChange(this.base.health, this.base.maxHealth);
    soundEngine.playBaseHit();
    this.triggerScreenShake(0.25, 10);

    if (this.base.health <= 0) {
      this.callbacks.onGameOver({ wave: this.wave, kills: this.kills, score: this.score });
      this.stop();
    }
  }

  private triggerScreenShake(time: number, intensity: number) {
    if (this.graphics.screenShake > 0) {
      this.screenShakeTime = time;
      this.screenShakeIntensity = intensity * this.graphics.screenShake;
    }
  }

  private createMuzzleFlash(x: number, y: number, angle: number) {
    if (this.graphics.particleQuality === 'low') return;
    for (let i = 0; i < 4; i++) {
      const spread = angle + (Math.random() - 0.5) * 0.5;
      const speed = 80 + Math.random() * 120;
      this.particles.push({
        x,
        y,
        vx: Math.cos(spread) * speed,
        vy: Math.sin(spread) * speed,
        radius: 2 + Math.random() * 3,
        color: '#fef08a',
        alpha: 0.9,
        decay: 3.5,
      });
    }
  }

  private createSparks(x: number, y: number, color: string, count: number) {
    if (this.graphics.particleQuality === 'low') count = Math.ceil(count / 2);
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 40 + Math.random() * 140;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: 2 + Math.random() * 2,
        color,
        alpha: 1,
        decay: 2.5,
      });
    }
  }

  public addFloatingText(x: number, y: number, text: string, color: string, scale: number = 1) {
    this.floatingTexts.push({
      id: Math.random().toString(),
      x,
      y,
      text,
      color,
      alpha: 1,
      scale,
      vy: -35,
    });
  }

  private updateEffects(dt: number) {
    // Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha -= p.decay * dt;
      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // Floating text
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.y += ft.vy * dt;
      ft.alpha -= 0.85 * dt;
      if (ft.alpha <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }
  }

  // Geometry helpers
  private checkCircleRect(cx: number, cy: number, r: number, rx: number, ry: number, rw: number, rh: number) {
    const testX = Math.max(rx, Math.min(cx, rx + rw));
    const testY = Math.max(ry, Math.min(cy, ry + rh));
    const distX = cx - testX;
    const distY = cy - testY;
    return distX * distX + distY * distY <= r * r;
  }

  private checkPointInRect(px: number, py: number, rx: number, ry: number, rw: number, rh: number) {
    return px >= rx && px <= rx + rw && py >= ry && py <= ry + rh;
  }

  // RENDER METHOD
  public render() {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    ctx.save();

    // Clear background
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, w, h);

    // Screen Shake transform
    let shakeX = 0;
    let shakeY = 0;
    if (this.screenShakeTime > 0) {
      shakeX = (Math.random() - 0.5) * this.screenShakeIntensity;
      shakeY = (Math.random() - 0.5) * this.screenShakeIntensity;
    }

    // Apply Camera
    ctx.translate(-this.camera.x + shakeX, -this.camera.y + shakeY);

    // 1. Draw Map Grid & Wasteland Floor
    this.renderMapFloor(ctx);

    // 2. Draw Blood Decals
    this.renderBloodDecals(ctx);

    // 2.5 Draw Toxic Hazard Zones (from Kamikaze explosions)
    this.renderHazardZones(ctx);

    // 3. Draw Fortification Walls
    this.renderWalls(ctx);

    // 4. Draw Base Core
    this.renderBase(ctx);

    // 5. Draw Turrets
    this.renderTurrets(ctx);

    // 6. Draw Resource Drops
    this.renderDrops(ctx);

    // 7. Draw Zombies
    this.renderZombies(ctx);

    // 8. Draw Player
    this.renderPlayer(ctx);

    // 9. Draw Bullets & Spits
    this.renderProjectiles(ctx);

    // 10. Draw Particles
    this.renderParticles(ctx);

    // 11. Draw Lighting & Darkness Vignette if enabled
    if (this.graphics.lightingEffects) {
      this.renderLightingOverlay(ctx);
    }

    // 12. Draw Floating Numbers
    this.renderFloatingTexts(ctx);

    ctx.restore();
  }

  private renderMapFloor(ctx: CanvasRenderingContext2D) {
    // Dark apocalyptic soil & grid tiles
    ctx.fillStyle = '#121316';
    ctx.fillRect(0, 0, MAP_WIDTH, MAP_HEIGHT);

    // Subtle grid
    ctx.strokeStyle = '#1e2025';
    ctx.lineWidth = 1;
    const gridSize = 120;
    for (let x = 0; x <= MAP_WIDTH; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, MAP_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y <= MAP_HEIGHT; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(MAP_WIDTH, y);
      ctx.stroke();
    }

    // Outer boundary warning line
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
    ctx.lineWidth = 6;
    ctx.strokeRect(6, 6, MAP_WIDTH - 12, MAP_HEIGHT - 12);
  }

  private renderBloodDecals(ctx: CanvasRenderingContext2D) {
    for (const d of this.bloodDecals) {
      ctx.save();
      ctx.fillStyle = d.color;
      ctx.beginPath();
      ctx.arc(d.x, d.y, d.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderWalls(ctx: CanvasRenderingContext2D) {
    for (const w of this.walls) {
      if (w.health <= 0) {
        // Destroyed wall ruins
        ctx.fillStyle = '#27272a';
        ctx.fillRect(w.x, w.y, w.width, w.height);
        ctx.strokeStyle = '#52525b';
        ctx.lineWidth = 1;
        ctx.strokeRect(w.x, w.y, w.width, w.height);
        continue;
      }

      // Healthy wall: Steel & concrete barricade
      const hpPct = w.health / w.maxHealth;
      ctx.fillStyle = hpPct > 0.5 ? '#3f3f46' : '#713f12';
      ctx.fillRect(w.x, w.y, w.width, w.height);

      // Warning stripes
      ctx.strokeStyle = hpPct > 0.3 ? '#f59e0b' : '#ef4444';
      ctx.lineWidth = 2;
      ctx.strokeRect(w.x, w.y, w.width, w.height);

      // Mini Health bar above wall
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(w.x, w.y - 8, w.width, 4);
      ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : hpPct > 0.25 ? '#eab308' : '#ef4444';
      ctx.fillRect(w.x, w.y - 8, w.width * hpPct, 4);
    }
  }

  private renderBase(ctx: CanvasRenderingContext2D) {
    const b = this.base;
    ctx.save();

    // Defense field ring
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.radius + 15, 0, Math.PI * 2);
    ctx.stroke();

    // Outer metal silo
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 4;
    ctx.stroke();

    // Inner generator core with pulse
    const pulse = Math.sin(performance.now() / 250) * 4;
    ctx.fillStyle = b.health < b.maxHealth * 0.3 ? '#ef4444' : '#0284c7';
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.radius * 0.45 + pulse, 0, Math.PI * 2);
    ctx.fill();

    // Base Title label
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 13px Chakra Petch, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('BAZA MARKAZI', b.x, b.y - 12);

    // Base Health bar on core
    const hpPct = b.health / b.maxHealth;
    const barW = 80;
    const barH = 7;
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(b.x - barW / 2, b.y + 6, barW, barH);
    ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : hpPct > 0.25 ? '#eab308' : '#ef4444';
    ctx.fillRect(b.x - barW / 2, b.y + 6, barW * hpPct, barH);

    ctx.restore();
  }

  private renderTurrets(ctx: CanvasRenderingContext2D) {
    for (const t of this.turrets) {
      ctx.save();
      // Turret base
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.arc(t.x, t.y, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Rotating barrel
      ctx.translate(t.x, t.y);
      ctx.rotate(t.angle);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(0, -4, 22, 8);
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(16, -3, 6, 6);

      ctx.restore();
    }
  }

  private renderDrops(ctx: CanvasRenderingContext2D) {
    for (const d of this.drops) {
      ctx.save();
      ctx.translate(d.x, d.y);

      if (d.type === 'wood') {
        // Wood log / scrap box
        ctx.fillStyle = '#92400e';
        ctx.fillRect(-8, -6, 16, 12);
        ctx.strokeStyle = '#d97706';
        ctx.strokeRect(-8, -6, 16, 12);
      } else if (d.type === 'metal') {
        // Metal ingot
        ctx.fillStyle = '#64748b';
        ctx.fillRect(-7, -7, 14, 14);
        ctx.strokeStyle = '#94a3b8';
        ctx.strokeRect(-7, -7, 14, 14);
      } else if (d.type === 'coin') {
        // Gold coin
        ctx.fillStyle = '#eab308';
        ctx.beginPath();
        ctx.arc(0, 0, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#fef08a';
        ctx.stroke();
      } else if (d.type === 'ammo') {
        // Ammo box
        ctx.fillStyle = '#c2410c';
        ctx.fillRect(-8, -5, 16, 10);
        ctx.fillStyle = '#fef08a';
        ctx.fillRect(-4, -2, 8, 4);
      } else if (d.type === 'medkit') {
        // Medkit cross
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-8, -8, 16, 16);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(-2, -6, 4, 12);
        ctx.fillRect(-6, -2, 12, 4);
      }

      ctx.restore();
    }
  }

  private renderHazardZones(ctx: CanvasRenderingContext2D) {
    const time = performance.now() / 1000;
    for (const hz of this.hazardZones) {
      ctx.save();
      const alpha = Math.min(0.4, (hz.life / hz.maxLife) * 0.4);
      const pulse = Math.sin(time * 4) * 3;

      // Acid puddle radial gradient
      const grad = ctx.createRadialGradient(hz.x, hz.y, 8, hz.x, hz.y, hz.radius + pulse);
      grad.addColorStop(0, `rgba(132, 204, 22, ${alpha * 1.6})`);
      grad.addColorStop(0.65, `rgba(34, 197, 94, ${alpha})`);
      grad.addColorStop(1, 'rgba(34, 197, 94, 0)');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(hz.x, hz.y, hz.radius + pulse, 0, Math.PI * 2);
      ctx.fill();

      // Outer hazardous boundary ring
      ctx.strokeStyle = `rgba(132, 204, 22, ${alpha * 1.4})`;
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.arc(hz.x, hz.y, hz.radius, 0, Math.PI * 2);
      ctx.stroke();

      // Biohazard label
      ctx.fillStyle = `rgba(250, 204, 21, ${alpha * 2.2})`;
      ctx.font = 'bold 11px Chakra Petch';
      ctx.textAlign = 'center';
      ctx.fillText('☣ ZAHARLI MAYDON', hz.x, hz.y + 4);

      ctx.restore();
    }
  }

  private renderZombies(ctx: CanvasRenderingContext2D) {
    const time = performance.now() / 1000;

    for (const z of this.zombies) {
      ctx.save();
      ctx.translate(z.x, z.y);

      // Warning circle if Kamikaze is detonating
      if (z.type === 'kamikaze' && z.detonating) {
        ctx.save();
        const flashAlpha = 0.3 + Math.abs(Math.sin(time * 16)) * 0.4;
        ctx.strokeStyle = `rgba(239, 68, 68, ${flashAlpha})`;
        ctx.lineWidth = 2.5;
        ctx.setLineDash([8, 8]);
        ctx.beginPath();
        ctx.arc(0, 0, 160, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = `rgba(239, 68, 68, 0.08)`;
        ctx.beginPath();
        ctx.arc(0, 0, 160, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      const angle = Math.atan2(z.vy, z.vx);
      ctx.rotate(angle);

      // 1. TEZKOR ZOMBI (Sprinter) - Dash ghost trail
      if (z.type === 'sprinter' && z.isDashing) {
        ctx.save();
        ctx.fillStyle = 'rgba(245, 158, 11, 0.25)';
        ctx.beginPath();
        ctx.arc(-14, 0, z.radius * 0.85, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(245, 158, 11, 0.12)';
        ctx.beginPath();
        ctx.arc(-26, 0, z.radius * 0.7, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Zombie Body Rendering based on type
      if (z.type === 'armored') {
        // 2. ZIRHLI ZOMBI: Ogʻir poʻlat zirh, plitalar va yelka himoyasi
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.arc(0, 0, z.radius, 0, Math.PI * 2);
        ctx.fill();

        // Steel armor plates
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(0, 0, z.radius * 0.85, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Heavy shoulder pauldrons
        ctx.fillStyle = '#64748b';
        ctx.fillRect(z.radius * 0.2, -z.radius * 0.95, z.radius * 0.7, z.radius * 0.45);
        ctx.fillRect(z.radius * 0.2, z.radius * 0.5, z.radius * 0.7, z.radius * 0.45);
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(z.radius * 0.2, -z.radius * 0.95, z.radius * 0.7, z.radius * 0.45);
        ctx.strokeRect(z.radius * 0.2, z.radius * 0.5, z.radius * 0.7, z.radius * 0.45);

        // Heavy steel helmet with visor slit
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(z.radius * 0.4, -z.radius * 0.4, z.radius * 0.5, z.radius * 0.8);
        ctx.fillStyle = '#ef4444'; // Glowing red tactical visor slit
        ctx.fillRect(z.radius * 0.7, -4, 4, 8);
      } else if (z.type === 'kamikaze') {
        // 3. PORTLOVCHI ZOMBI: Shishgan, qorinida radioaktiv modda va ogohlantirish chiroqlari
        const pulse = z.detonating ? Math.sin(time * 20) * 3 : Math.sin(time * 6) * 1.5;
        const currentR = z.radius + pulse;

        // Swollen radioactive body
        ctx.fillStyle = z.detonating ? '#b91c1c' : '#c2410c';
        ctx.beginPath();
        ctx.arc(0, 0, currentR, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = z.detonating ? '#f87171' : '#f97316';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Glowing hazardous core
        ctx.fillStyle = z.detonating ? '#facc15' : '#84cc16';
        ctx.beginPath();
        ctx.arc(0, 0, currentR * 0.5, 0, Math.PI * 2);
        ctx.fill();

        // Arms reaching forward
        ctx.fillStyle = '#9a3412';
        ctx.fillRect(currentR * 0.4, -currentR * 0.55, currentR * 0.7, currentR * 0.3);
        ctx.fillRect(currentR * 0.4, currentR * 0.25, currentR * 0.7, currentR * 0.3);

        // Blinking red bomb eyes
        ctx.fillStyle = z.detonating && Math.floor(time * 12) % 2 === 0 ? '#fef08a' : '#ef4444';
        ctx.beginPath();
        ctx.arc(currentR * 0.5, -4, 2.5, 0, Math.PI * 2);
        ctx.arc(currentR * 0.5, 4, 2.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (z.type === 'sprinter') {
        // 1. TEZKOR ZOMBI: Yengil, sariq-olovrang, oʻtkir changallar va chaqnoq koʻzlar
        ctx.fillStyle = z.color;
        ctx.beginPath();
        ctx.arc(0, 0, z.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Sharp claw arms forward
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(z.radius * 0.4, -z.radius * 0.6, z.radius * 0.9, z.radius * 0.3);
        ctx.fillRect(z.radius * 0.4, z.radius * 0.3, z.radius * 0.9, z.radius * 0.3);
        // Razor claws
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.moveTo(z.radius * 1.3, -z.radius * 0.5);
        ctx.lineTo(z.radius * 1.6, -z.radius * 0.45);
        ctx.lineTo(z.radius * 1.3, -z.radius * 0.35);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(z.radius * 1.3, z.radius * 0.35);
        ctx.lineTo(z.radius * 1.6, z.radius * 0.45);
        ctx.lineTo(z.radius * 1.3, z.radius * 0.55);
        ctx.fill();

        // Glowing electric cyan eyes
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(z.radius * 0.5, -3, 2.5, 0, Math.PI * 2);
        ctx.arc(z.radius * 0.5, 3, 2.5, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Standard Zombie Body (Walker, Runner, Tank, Spitter, Boss)
        ctx.fillStyle = z.color;
        ctx.beginPath();
        ctx.arc(0, 0, z.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#14532d';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Zombie Arms reaching out
        ctx.fillStyle = z.color;
        ctx.fillRect(z.radius * 0.4, -z.radius * 0.6, z.radius * 0.8, z.radius * 0.35);
        ctx.fillRect(z.radius * 0.4, z.radius * 0.25, z.radius * 0.8, z.radius * 0.35);

        // Red glowing eyes
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(z.radius * 0.5, -4, 2, 0, Math.PI * 2);
        ctx.arc(z.radius * 0.5, 4, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      // Rotate back to draw labels and health bars upright
      ctx.rotate(-angle);
      const hpPct = z.health / z.maxHealth;
      const barW = z.radius * 2.2;
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(-barW / 2, -z.radius - 10, barW, 4);
      ctx.fillStyle = hpPct > 0.5 ? '#22c55e' : hpPct > 0.25 ? '#eab308' : '#ef4444';
      ctx.fillRect(-barW / 2, -z.radius - 10, barW * hpPct, 4);

      // Custom Badges & Titles
      ctx.textAlign = 'center';
      if (z.isBoss) {
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 11px Chakra Petch';
        ctx.fillText('BOSS', 0, -z.radius - 14);
      } else if (z.type === 'sprinter') {
        ctx.fillStyle = '#facc15';
        ctx.font = 'bold 9px Chakra Petch';
        ctx.fillText(z.isDashing ? '⚡ DASH!' : '⚡ TEZKOR', 0, -z.radius - 14);
      } else if (z.type === 'armored') {
        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 9px Chakra Petch';
        ctx.fillText('🛡️ ZIRHLI', 0, -z.radius - 14);
      } else if (z.type === 'kamikaze') {
        if (z.detonating) {
          ctx.fillStyle = Math.floor(time * 10) % 2 === 0 ? '#ef4444' : '#facc15';
          ctx.font = 'bold 11px Chakra Petch';
          ctx.fillText(`⚠️ ${(Math.max(0, z.detonationTimer ?? 0)).toFixed(1)}s`, 0, -z.radius - 15);
        } else {
          ctx.fillStyle = '#fb923c';
          ctx.font = 'bold 9px Chakra Petch';
          ctx.fillText('☢️ PORTLOVCHI', 0, -z.radius - 14);
        }
      }

      ctx.restore();
    }
  }

  private renderPlayer(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.angle);

    // Player Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(0, 4, 18, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    // Player Hands holding gun
    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(10, 4, 12, 6);
    ctx.fillRect(10, -10, 12, 6);

    // Player Weapon barrel
    const weapon = this.weapons[p.currentWeapon];
    ctx.fillStyle = '#1e293b';
    const gunLen = weapon.id === 'sniper' ? 34 : weapon.id === 'shotgun' ? 24 : 18;
    ctx.fillRect(8, -3, gunLen, 6);

    // Player Torso & Helmet
    ctx.fillStyle = '#0284c7';
    ctx.beginPath();
    ctx.arc(0, 0, 15, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Helmet Visor
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.arc(6, 0, 5, -Math.PI / 2, Math.PI / 2);
    ctx.fill();

    // Reloading ring / indicator
    if (p.isReloading) {
      ctx.rotate(-p.angle);
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, 26, 0, Math.PI * 2 * p.reloadProgress);
      ctx.stroke();
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 11px Chakra Petch';
      ctx.textAlign = 'center';
      ctx.fillText('Qayta oʻqlash...', 0, -32);
    }

    ctx.restore();
  }

  private renderProjectiles(ctx: CanvasRenderingContext2D) {
    // Bullets
    for (const b of this.bullets) {
      ctx.save();
      ctx.fillStyle = b.color;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Acid Spits
    for (const s of this.acidSpits) {
      ctx.save();
      ctx.fillStyle = '#84cc16';
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderParticles(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderLightingOverlay(ctx: CanvasRenderingContext2D) {
    // Flashlight cone & base ambient light in the dark
    const p = this.player;
    const b = this.base;

    // We can draw a subtle dark vignette with cutout circles for base and player flashlight
    ctx.save();
    const grad = ctx.createRadialGradient(p.x, p.y, 40, p.x, p.y, 480);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0.45)');

    ctx.fillStyle = grad;
    ctx.fillRect(this.camera.x, this.camera.y, this.canvas.width, this.canvas.height);

    // Base spotlight glow
    const baseGrad = ctx.createRadialGradient(b.x, b.y, 20, b.x, b.y, b.radius + 90);
    baseGrad.addColorStop(0, 'rgba(56, 189, 248, 0.15)');
    baseGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = baseGrad;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.radius + 90, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private renderFloatingTexts(ctx: CanvasRenderingContext2D) {
    for (const ft of this.floatingTexts) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, ft.alpha);
      ctx.fillStyle = ft.color;
      ctx.font = `bold ${Math.round(14 * ft.scale)}px Chakra Petch, sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    }
  }
}
