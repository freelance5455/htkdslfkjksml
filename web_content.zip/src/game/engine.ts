import * as THREE from "three";
import { Sfx } from "@/game/audio";
import {
  CELL,
  EYE,
  PLAYER_RADIUS,
  SPRINT_SPEED,
  WALK_SPEED,
  cellCenter,
  gateRotY,
  generateMaze,
  mapCellVisible,
  moveCircle,
  preferredYaw,
  revealAround,
  wishVelocity,
  type MazeData,
} from "@/game/sim";

export type Phase = "menu" | "play" | "paused" | "won";

export type BestRun = { ms: number; gems: number; total: number };

export type HudSnapshot = {
  phase: Phase;
  time: number;
  collected: number;
  total: number;
  best: BestRun | null;
  seed: number;
  muted: boolean;
  newBest: boolean;
  perfect: boolean;
};

const SAVE_KEY = "sunbloom-v1";
const HEDGE = ["#215c38", "#2a7344", "#327e4c", "#1b5132", "#3b8b56"];
const CAPS = ["#8ed07a", "#a6db90", "#7bc46e", "#b7e4a4"];
const PARTICLE_MAX = 80;

type SaveFile = { v: 1; best: BestRun | null; muted: boolean };

type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  r: number;
  g: number;
  b: number;
};

function loadSave(): SaveFile {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { v: 1, best: null, muted: false };
    const parsed = JSON.parse(raw) as SaveFile;
    if (!parsed || parsed.v !== 1) return { v: 1, best: null, muted: false };
    return {
      v: 1,
      best: parsed.best && typeof parsed.best.ms === "number" ? parsed.best : null,
      muted: Boolean(parsed.muted),
    };
  } catch {
    return { v: 1, best: null, muted: false };
  }
}

function glowTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 64;
  canvas.height = 64;
  const g = canvas.getContext("2d");
  if (!g) return new THREE.CanvasTexture(canvas);
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(0.35, "rgba(255,244,210,0.85)");
  grd.addColorStop(1, "rgba(255,244,210,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class MazeEngine {
  readonly canvas: HTMLCanvasElement;
  private readonly map: HTMLCanvasElement;
  private readonly onHud: (s: HudSnapshot) => void;
  private readonly sfx = new Sfx();
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly camera: THREE.PerspectiveCamera;
  private readonly clockT = { now: 0 };
  private readonly keys = new Set<string>();
  private readonly reduceMotion: boolean;
  private readonly detach: Array<() => void> = [];
  private readonly dummy = new THREE.Object3D();
  private readonly color = new THREE.Color();
  private readonly particles: Particle[] = [];
  private readonly particlePos: Float32Array;
  private readonly particleCol: Float32Array;
  private readonly points: THREE.Points;

  px = 0;
  pz = 0;
  yaw = 0;
  pitch = -0.08;

  private maze: MazeData;
  private visited: Uint8Array;
  private alive: boolean[] = [];
  private world: THREE.Group | null = null;
  private gemMesh: THREE.InstancedMesh | null = null;
  private haloMesh: THREE.InstancedMesh | null = null;
  private ringA: THREE.Mesh | null = null;
  private ringB: THREE.Mesh | null = null;
  private disc: THREE.Mesh | null = null;
  private phase: Phase = "menu";
  private timeMs = 0;
  private collected = 0;
  private velX = 0;
  private velZ = 0;
  private axisX = 0;
  private axisY = 0;
  private lastInputR = 0;
  private sprinting = false;
  private bob = 0;
  private trauma = 0;
  private stepAcc = 0;
  private nearAcc = 0;
  private hudAcc = 0;
  private hudDirty = true;
  private baseYaw = 0;
  private worldT = 0;
  private lastBump = -10;
  private qaOverride: Set<string> | null = null;
  private wasLocked = false;
  private touchLayout = false;
  private best: BestRun | null;
  private newBest = false;
  private perfect = false;
  private disposed = false;
  private raf = 0;
  private lastFrame = 0;
  private resizeObs: ResizeObserver | null = null;

  constructor(canvas: HTMLCanvasElement, map: HTMLCanvasElement, onHud: (s: HudSnapshot) => void) {
    this.canvas = canvas;
    this.map = map;
    this.onHud = onHud;
    const save = loadSave();
    this.best = save.best;
    this.sfx.muted = save.muted;
    this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor(0xc5e9fb, 1);

    this.scene.background = new THREE.Color(0xc5e9fb);
    this.scene.fog = new THREE.Fog(0xd4f1fd, 12, 34);

    this.camera = new THREE.PerspectiveCamera(75, 1, 0.08, 80);

    const hemi = new THREE.HemisphereLight(0xfff6df, 0x8fbf78, 1.15);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xfffaf0, 2.35);
    sun.position.set(16, 28, 10);
    sun.castShadow = true;
    const shadowCam = sun.shadow.camera as THREE.OrthographicCamera;
    sun.shadow.mapSize.set(1024, 1024);
    shadowCam.near = 2;
    shadowCam.far = 70;
    shadowCam.left = -28;
    shadowCam.right = 28;
    shadowCam.top = 28;
    shadowCam.bottom = -28;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.035;
    this.scene.add(sun);
    this.scene.add(sun.target);
    sun.target.position.set(18, 0, 18);

    const sunBall = new THREE.Mesh(
      new THREE.SphereGeometry(2.4, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xffe29a }),
    );
    sunBall.position.set(-8, 18, -10);
    this.scene.add(sunBall);

    this.addClouds();

    this.particlePos = new Float32Array(PARTICLE_MAX * 3);
    this.particleCol = new Float32Array(PARTICLE_MAX * 3);
    for (let i = 0; i < PARTICLE_MAX; i++) {
      this.particles.push({
        x: 0, y: -40, z: 0, vx: 0, vy: 0, vz: 0, life: 0, max: 1, r: 1, g: 1, b: 1,
      });
      this.particlePos[i * 3 + 1] = -40;
    }
    const pgeo = new THREE.BufferGeometry();
    pgeo.setAttribute("position", new THREE.BufferAttribute(this.particlePos, 3));
    pgeo.setAttribute("color", new THREE.BufferAttribute(this.particleCol, 3));
    const tex = glowTexture();
    this.points = new THREE.Points(
      pgeo,
      new THREE.PointsMaterial({
        size: 0.22,
        map: tex,
        transparent: true,
        depthWrite: false,
        vertexColors: true,
        sizeAttenuation: true,
      }),
    );
    this.scene.add(this.points);

    const seed = (Math.random() * 0x7fffffff) | 0;
    this.maze = generateMaze(seed);
    this.visited = new Uint8Array(this.maze.w * this.maze.h);
    this.buildWorld(this.maze);
    this.resetRun();

    this.bind(window, "keydown", this.onKeyDown);
    this.bind(window, "keyup", this.onKeyUp);
    this.bind(window, "blur", () => this.keys.clear());
    this.bind(document, "visibilitychange", () => {
      if (document.hidden) this.keys.clear();
    });
    this.bind(document, "mousemove", this.onMouseMove);
    this.bind(document, "pointerlockchange", this.onLockChange);
    this.bind(canvas, "contextmenu", (e) => e.preventDefault());

    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(canvas);
    this.resize();
    this.lastFrame = performance.now();
    this.raf = requestAnimationFrame(this.frame);
    this.emit();
  }

  get speed() {
    return Math.hypot(this.velX, this.velZ);
  }

  setTouchLayout(on: boolean) {
    this.touchLayout = on;
  }

  setMoveAxis(x: number, y: number) {
    this.axisX = Math.max(-1, Math.min(1, x));
    this.axisY = Math.max(-1, Math.min(1, y));
  }

  lookBy(dx: number, dy: number, sens = 0.0042) {
    if (this.phase !== "play") return;
    this.yaw -= dx * sens;
    this.pitch -= dy * sens;
    this.pitch = Math.max(-1.3, Math.min(1.3, this.pitch));
  }

  setKeys(codes: string[]) {
    this.qaOverride = new Set(codes);
    if (this.phase === "menu" || this.phase === "paused") {
      this.phase = "play";
      this.hudDirty = true;
    }
  }

  beginFromMenu() {
    this.sfx.unlock();
    this.sfx.click();
    if (this.phase === "won" || this.phase === "menu") this.resetRun();
    this.phase = "play";
    this.hudDirty = true;
    this.emit();
    this.lockPointer();
  }

  resume() {
    if (this.phase !== "paused") return;
    this.sfx.unlock();
    this.sfx.click();
    this.phase = "play";
    this.hudDirty = true;
    this.emit();
    this.lockPointer();
  }

  pause() {
    if (this.phase !== "play") return;
    this.phase = "paused";
    this.hudDirty = true;
    this.wasLocked = false;
    if (document.pointerLockElement) document.exitPointerLock();
    this.emit();
  }

  toMenu() {
    this.sfx.click();
    this.resetRun();
    this.phase = "menu";
    this.wasLocked = false;
    if (document.pointerLockElement) document.exitPointerLock();
    this.hudDirty = true;
    this.emit();
  }

  retry(newSeed: boolean) {
    this.sfx.unlock();
    this.sfx.click();
    const seed = newSeed ? ((Math.random() * 0x7fffffff) | 0) : this.maze.seed;
    if (newSeed || this.phase === "won") {
      this.maze = generateMaze(seed);
      this.visited = new Uint8Array(this.maze.w * this.maze.h);
      this.buildWorld(this.maze);
    }
    this.resetRun();
    this.phase = "play";
    this.hudDirty = true;
    this.emit();
    this.lockPointer();
  }

  toggleMute() {
    this.sfx.muted = !this.sfx.muted;
    if (!this.sfx.muted) {
      this.sfx.unlock();
      this.sfx.click();
    }
    this.persist();
    this.hudDirty = true;
    this.emit();
  }

  lockPointer() {
    if (this.touchLayout || this.qaOverride) return;
    const node = this.canvas as HTMLCanvasElement & {
      requestPointerLock?: (opts?: { unadjustedMovement?: boolean }) => Promise<void> | void;
    };
    try {
      const pending = node.requestPointerLock?.({ unadjustedMovement: true });
      void Promise.resolve(pending).catch(() => {
        try {
          node.requestPointerLock?.();
        } catch {
          /* pointer lock is optional */
        }
      });
    } catch {
      try {
        node.requestPointerLock?.();
      } catch {
        /* ignore */
      }
    }
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.resizeObs?.disconnect();
    for (const off of this.detach) off();
    this.detach.length = 0;
    this.clearWorld();
    this.points.geometry.dispose();
    (this.points.material as THREE.Material).dispose();
    this.renderer.dispose();
  }

  private bind(target: EventTarget, type: string, fn: EventListener) {
    target.addEventListener(type, fn);
    this.detach.push(() => target.removeEventListener(type, fn));
  }

  private onKeyDown = (event: Event) => {
    const e = event as KeyboardEvent;
    if (!this.qaOverride) this.keys.add(e.code);
    if (e.code === "Escape" && this.phase === "play") this.pause();
    if (e.code.startsWith("Arrow") || e.code === "Space") e.preventDefault();
  };

  private onKeyUp = (event: Event) => {
    const e = event as KeyboardEvent;
    this.keys.delete(e.code);
  };

  private onMouseMove = (event: Event) => {
    const e = event as MouseEvent;
    if (this.phase !== "play") return;
    if (document.pointerLockElement !== this.canvas) return;
    this.lookBy(e.movementX, e.movementY, 0.00215);
  };

  private onLockChange = () => {
    const locked = document.pointerLockElement === this.canvas;
    if (locked) {
      this.wasLocked = true;
      return;
    }
    if (this.wasLocked && this.phase === "play" && !this.qaOverride) {
      this.wasLocked = false;
      this.phase = "paused";
      this.hudDirty = true;
    }
  };

  private held(code: string) {
    if (this.qaOverride) return this.qaOverride.has(code);
    return this.keys.has(code);
  }

  private readInput() {
    let f = 0;
    let r = 0;
    if (this.held("KeyW") || this.held("ArrowUp")) f += 1;
    if (this.held("KeyS") || this.held("ArrowDown")) f -= 1;
    if (this.held("KeyD") || this.held("ArrowRight")) r += 1;
    if (this.held("KeyA") || this.held("ArrowLeft")) r -= 1;
    r += this.axisX;
    f += this.axisY;
    const mag = Math.hypot(f, r);
    if (mag > 1) {
      f /= mag;
      r /= mag;
    }
    const sprint = this.held("ShiftLeft") || this.held("ShiftRight");
    return { f, r, sprint, pushing: mag > 0.08 };
  }

  private resetRun() {
    const spawn = cellCenter(this.maze.start);
    this.px = spawn.x;
    this.pz = spawn.z;
    this.baseYaw = preferredYaw(this.maze, this.maze.start);
    this.yaw = this.baseYaw;
    this.pitch = -0.08;
    this.velX = 0;
    this.velZ = 0;
    this.timeMs = 0;
    this.collected = 0;
    this.alive = this.maze.pickups.map(() => true);
    this.visited.fill(0);
    this.newBest = false;
    this.perfect = false;
    this.trauma = 0;
    this.stepAcc = 0;
    this.nearAcc = 0;
    revealAround(this.maze, this.px, this.pz, this.visited);
  }

  private persist() {
    const data: SaveFile = { v: 1, best: this.best, muted: this.sfx.muted };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch {
      /* private mode */
    }
  }

  private snapshot(): HudSnapshot {
    return {
      phase: this.phase,
      time: this.timeMs,
      collected: this.collected,
      total: this.maze.pickups.length,
      best: this.best,
      seed: this.maze.seed,
      muted: this.sfx.muted,
      newBest: this.newBest,
      perfect: this.perfect,
    };
  }

  private emit() {
    if (this.disposed) return;
    this.onHud(this.snapshot());
  }

  private resize() {
    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  private frame = (now: number) => {
    if (this.disposed) return;
    const dt = Math.min(0.05, (now - this.lastFrame) / 1000);
    this.lastFrame = now;
    this.worldT += dt;
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
    this.raf = requestAnimationFrame(this.frame);
  };

  private update(dt: number) {
    if (this.phase === "play") {
      const input = this.readInput();
      this.lastInputR = input.r;
      this.sprinting = input.sprint && input.pushing;
      const max = this.sprinting ? SPRINT_SPEED : WALK_SPEED;
      const wish = wishVelocity(this.yaw, input.f, input.r);
      const rate = input.pushing ? 16 : 12;
      const k = 1 - Math.exp(-rate * dt);
      this.velX += (wish.x * max - this.velX) * k;
      this.velZ += (wish.z * max - this.velZ) * k;
      const speedBefore = Math.hypot(this.velX, this.velZ);
      const step = moveCircle(this.maze, this.px, this.pz, this.velX * dt, this.velZ * dt, PLAYER_RADIUS);
      if (step.blockedX) this.velX = 0;
      if (step.blockedZ) this.velZ = 0;
      const bumped = (step.blockedX || step.blockedZ) && input.pushing && speedBefore > 1.15;
      if (bumped && this.worldT - this.lastBump > 0.24) {
        this.lastBump = this.worldT;
        this.trauma = Math.min(1, this.trauma + 0.32);
        this.sfx.bump();
        this.burst(this.px, 0.35, this.pz, "#f0b429", 5);
      }
      this.px = step.x;
      this.pz = step.z;

      const horiz = Math.hypot(this.velX, this.velZ);
      if (horiz > 1.3) {
        this.stepAcc += dt;
        const interval = this.sprinting ? 0.32 : 0.46;
        if (this.stepAcc >= interval) {
          this.stepAcc = 0;
          this.sfx.step();
        }
      } else {
        this.stepAcc = 0;
      }

      this.collect();
      this.checkExit(dt);
      revealAround(this.maze, this.px, this.pz, this.visited);
      this.timeMs += dt * 1000;
    }

    this.animateProps();
    this.stepParticles(dt);
    this.applyCamera(dt);
    if (this.phase === "play" || this.phase === "paused") this.drawMap();

    this.hudAcc += dt;
    if (this.hudDirty || (this.phase === "play" && this.hudAcc > 0.1)) {
      this.hudAcc = 0;
      this.hudDirty = false;
      this.emit();
    }
  }

  private collect() {
    const r2 = 0.72 * 0.72;
    for (let i = 0; i < this.maze.pickups.length; i++) {
      if (!this.alive[i]) continue;
      const c = cellCenter(this.maze.pickups[i]!);
      const dx = this.px - c.x;
      const dz = this.pz - c.z;
      if (dx * dx + dz * dz > r2) continue;
      this.alive[i] = false;
      this.collected += 1;
      this.hudDirty = true;
      this.sfx.pickup();
      this.burst(c.x, 0.8, c.z, "#f0b429", 14);
    }
  }

  private checkExit(dt: number) {
    if (this.phase !== "play") return;
    const c = cellCenter(this.maze.exit);
    const dx = this.px - c.x;
    const dz = this.pz - c.z;
    const dist = Math.hypot(dx, dz);
    if (dist < 5.5) {
      this.nearAcc += dt;
      if (this.nearAcc > 1.35) {
        this.nearAcc = 0;
        this.sfx.near();
      }
    }
    if (dist > 0.78) return;
    this.phase = "won";
    this.velX = 0;
    this.velZ = 0;
    this.perfect = this.collected === this.maze.pickups.length;
    this.newBest = !this.best || this.timeMs < this.best.ms;
    if (this.newBest) {
      this.best = {
        ms: this.timeMs,
        gems: this.collected,
        total: this.maze.pickups.length,
      };
      this.persist();
    }
    this.sfx.win();
    this.burst(c.x, 1.3, c.z, "#ff6b4a", 28);
    this.burst(c.x, 1.1, c.z, "#f0b429", 20);
    this.wasLocked = false;
    if (document.pointerLockElement) document.exitPointerLock();
    this.hudDirty = true;
  }

  private animateProps() {
    const t = this.worldT;
    if (this.gemMesh && this.haloMesh) {
      for (let i = 0; i < this.maze.pickups.length; i++) {
        const c = cellCenter(this.maze.pickups[i]!);
        const bob = 0.78 + Math.sin(t * 2.1 + i) * 0.12;
        const s = this.alive[i] ? 1 : 0.0001;
        this.dummy.position.set(c.x, bob, c.z);
        this.dummy.rotation.set(t * 0.7, t * 1.4 + i, 0);
        this.dummy.scale.setScalar(s);
        this.dummy.updateMatrix();
        this.gemMesh.setMatrixAt(i, this.dummy.matrix);
        const halo = 1 + Math.sin(t * 3 + i) * 0.08;
        this.dummy.scale.setScalar(this.alive[i] ? halo : 0.0001);
        this.dummy.rotation.set(0, 0, 0);
        this.dummy.updateMatrix();
        this.haloMesh.setMatrixAt(i, this.dummy.matrix);
      }
      this.gemMesh.instanceMatrix.needsUpdate = true;
      this.haloMesh.instanceMatrix.needsUpdate = true;
    }
    if (this.ringA) this.ringA.rotation.z = t * 0.7;
    if (this.ringB) this.ringB.rotation.z = -t * 1.15;
    if (this.disc) {
      const mat = this.disc.material as THREE.MeshBasicMaterial;
      mat.opacity = 0.28 + Math.sin(t * 2.4) * 0.08;
    }
  }

  private applyCamera(dt: number) {
    const reduce = this.reduceMotion;
    const speed = Math.hypot(this.velX, this.velZ);
    const moving = speed > 0.4 && this.phase === "play";
    if (moving && !reduce) this.bob += dt * (this.sprinting ? 11.5 : 9.2);
    const mag = !reduce && moving ? Math.min(1, speed / WALK_SPEED) : 0;
    const bobY = Math.sin(this.bob) * 0.045 * mag;
    const bobX = Math.cos(this.bob * 0.5) * 0.018 * mag;
    this.trauma = Math.max(0, this.trauma - dt * 2.5);
    const sh = reduce ? 0 : this.trauma * this.trauma;
    const shakeX = Math.sin(this.worldT * 41) * sh * 0.05;
    const shakeY = Math.cos(this.worldT * 33) * sh * 0.032;
    let yaw = this.yaw;
    let pitch = this.pitch;
    if (this.phase === "menu" && !reduce) {
      yaw = this.baseYaw + Math.sin(this.worldT * 0.42) * 0.45;
      pitch = -0.12 + Math.sin(this.worldT * 0.31) * 0.04;
    }
    const b = wishVelocity(yaw, 0, 1);
    const lean = reduce ? 0 : -this.lastInputR * 0.028 * (moving ? 1 : 0);
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y = yaw;
    this.camera.rotation.x = pitch;
    this.camera.rotation.z = lean;
    this.camera.position.set(
      this.px + b.x * bobX + shakeX,
      EYE + bobY + shakeY,
      this.pz + b.z * bobX,
    );
    const targetFov = this.sprinting && moving && !reduce ? 84 : 75;
    if (Math.abs(this.camera.fov - targetFov) > 0.04) {
      this.camera.fov += (targetFov - this.camera.fov) * (1 - Math.exp(-6 * dt));
      this.camera.updateProjectionMatrix();
    }
  }

  private burst(x: number, y: number, z: number, hex: string, count: number) {
    this.color.set(hex);
    for (let n = 0; n < count; n++) {
      let slot = this.particles.findIndex((p) => p.life <= 0);
      if (slot < 0) slot = n % PARTICLE_MAX;
      const p = this.particles[slot]!;
      const ang = Math.random() * Math.PI * 2;
      const up = 1.2 + Math.random() * 2.4;
      const spd = 0.8 + Math.random() * 2.2;
      p.x = x;
      p.y = y;
      p.z = z;
      p.vx = Math.cos(ang) * spd;
      p.vz = Math.sin(ang) * spd;
      p.vy = up;
      p.life = 0.45 + Math.random() * 0.35;
      p.max = p.life;
      p.r = this.color.r;
      p.g = this.color.g;
      p.b = this.color.b;
    }
  }

  private stepParticles(dt: number) {
    const pos = this.particlePos;
    const col = this.particleCol;
    for (let i = 0; i < PARTICLE_MAX; i++) {
      const p = this.particles[i]!;
      if (p.life > 0) {
        p.life -= dt;
        p.vy -= 4.5 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.z += p.vz * dt;
        if (p.y < 0.08) {
          p.y = 0.08;
          p.vy *= -0.35;
          p.vx *= 0.7;
          p.vz *= 0.7;
        }
      }
      const k = p.life > 0 ? p.life / p.max : 0;
      pos[i * 3] = p.life > 0 ? p.x : 0;
      pos[i * 3 + 1] = p.life > 0 ? p.y : -40;
      pos[i * 3 + 2] = p.life > 0 ? p.z : 0;
      col[i * 3] = p.r * k;
      col[i * 3 + 1] = p.g * k;
      col[i * 3 + 2] = p.b * k;
    }
    const geo = this.points.geometry;
    (geo.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
    (geo.getAttribute("color") as THREE.BufferAttribute).needsUpdate = true;
  }

  private drawMap() {
    const ctx = this.map.getContext("2d");
    if (!ctx) return;
    const S = this.map.width || 384;
    if (this.map.height !== S) this.map.height = S;
    const maze = this.maze;
    const pad = 16;
    const inner = S - pad * 2;
    const cw = inner / maze.w;
    const ch = inner / maze.h;
    ctx.clearRect(0, 0, S, S);
    ctx.fillStyle = "#163026";
    ctx.fillRect(0, 0, S, S);
    for (let z = 0; z < maze.h; z++) {
      for (let x = 0; x < maze.w; x++) {
        if (!mapCellVisible(maze, x, z, this.visited)) continue;
        const wall = maze.walls[z * maze.w + x] === 1;
        ctx.fillStyle = wall ? "#2f7d4a" : "#f4ead4";
        ctx.fillRect(pad + x * cw, pad + z * ch, cw + 0.6, ch + 0.6);
      }
    }
    for (let i = 0; i < maze.pickups.length; i++) {
      if (!this.alive[i]) continue;
      const p = maze.pickups[i]!;
      if (!this.visited[p.z * maze.w + p.x]) continue;
      ctx.fillStyle = "#e6a817";
      ctx.beginPath();
      ctx.arc(pad + (p.x + 0.5) * cw, pad + (p.z + 0.5) * ch, Math.max(2.5, cw * 0.16), 0, Math.PI * 2);
      ctx.fill();
    }
    const exitSeen = this.visited[maze.exit.z * maze.w + maze.exit.x] === 1;
    if (exitSeen) {
      ctx.strokeStyle = "#ff6b4a";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(
        pad + (maze.exit.x + 0.5) * cw,
        pad + (maze.exit.z + 0.5) * ch,
        cw * 0.28,
        0,
        Math.PI * 2,
      );
      ctx.stroke();
    }
    const px = pad + (this.px / CELL) * cw;
    const py = pad + (this.pz / CELL) * ch;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-this.yaw);
    ctx.fillStyle = "#1a2e24";
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(6.5, 7);
    ctx.lineTo(-6.5, 7);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#f0b429";
    ctx.beginPath();
    ctx.moveTo(0, -6.5);
    ctx.lineTo(4.2, 5);
    ctx.lineTo(-4.2, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  private addClouds() {
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const spots = [
      [-6, 14, -6, 7.5],
      [22, 15, 4, 6],
      [8, 16, 26, 8],
      [30, 14.5, 22, 5.5],
      [-2, 15.5, 24, 6.5],
    ];
    for (const [x, y, z, s] of spots) {
      const g = new THREE.Group();
      const puff = [
        [0, 0, 0, 1, 0.55, 0.8],
        [0.7, 0.1, 0.1, 0.7, 0.42, 0.6],
        [-0.65, 0.05, 0.05, 0.62, 0.4, 0.55],
      ];
      for (const [px, py, pz, sx, sy, sz] of puff) {
        const m = new THREE.Mesh(geo, mat);
        m.position.set(px!, py!, pz!);
        m.scale.set(sx!, sy!, sz!);
        g.add(m);
      }
      g.position.set(x!, y!, z!);
      g.scale.setScalar(s!);
      this.scene.add(g);
    }
  }

  private clearWorld() {
    if (!this.world) return;
    this.scene.remove(this.world);
    const mats = new Set<THREE.Material>();
    this.world.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const material = mesh.material;
      if (!material) return;
      const list = Array.isArray(material) ? material : [material];
      for (const m of list) mats.add(m);
    });
    for (const m of mats) m.dispose();
    this.world = null;
    this.gemMesh = null;
    this.haloMesh = null;
    this.ringA = null;
    this.ringB = null;
    this.disc = null;
  }

  private buildWorld(maze: MazeData) {
    this.clearWorld();
    const group = new THREE.Group();
    this.world = group;
    const width = maze.w * CELL;
    const depth = maze.h * CELL;

    const floorGeo = new THREE.PlaneGeometry(width, depth, maze.w, maze.h);
    floorGeo.rotateX(-Math.PI / 2);
    const colors: number[] = [];
    const pos = floorGeo.attributes.position!;
    for (let i = 0; i < pos.count; i++) {
      const wx = pos.getX(i) + width / 2;
      const wz = pos.getZ(i) + depth / 2;
      let cx = Math.floor(wx / CELL);
      let cz = Math.floor(wz / CELL);
      cx = Math.max(0, Math.min(maze.w - 1, cx));
      cz = Math.max(0, Math.min(maze.h - 1, cz));
      const wall = maze.walls[cz * maze.w + cx] === 1;
      const exit = cx === maze.exit.x && cz === maze.exit.z;
      const start = cx === maze.start.x && cz === maze.start.z;
      if (exit) this.color.set("#f7d9a8");
      else if (start) this.color.set("#f4e7c4");
      else if (wall) this.color.set("#b7d7a2");
      else this.color.set(i % 3 === 0 ? "#e5f6cf" : "#d4eebc");
      colors.push(this.color.r, this.color.g, this.color.b);
    }
    floorGeo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    const floor = new THREE.Mesh(
      floorGeo,
      new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 }),
    );
    floor.position.set(width / 2, -0.02, depth / 2);
    floor.receiveShadow = true;
    group.add(floor);

    let wallCount = 0;
    for (let i = 0; i < maze.walls.length; i++) if (maze.walls[i]) wallCount++;
    const box = new THREE.BoxGeometry(1, 1, 1);
    const hedgeMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.92, metalness: 0 });
    const capMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0 });
    const hedges = new THREE.InstancedMesh(box, hedgeMat, wallCount);
    const caps = new THREE.InstancedMesh(box, capMat, wallCount);
    hedges.castShadow = true;
    hedges.receiveShadow = true;
    caps.castShadow = true;
    let n = 0;
    for (let z = 0; z < maze.h; z++) {
      for (let x = 0; x < maze.w; x++) {
        if (!maze.walls[z * maze.w + x]) continue;
        const hgt = 2.25 + ((x * 13 + z * 7 + maze.seed) % 5) * 0.14;
        this.dummy.position.set((x + 0.5) * CELL, hgt / 2, (z + 0.5) * CELL);
        this.dummy.rotation.set(0, 0, 0);
        this.dummy.scale.set(1.02, hgt, 1.02);
        this.dummy.updateMatrix();
        hedges.setMatrixAt(n, this.dummy.matrix);
        this.color.set(HEDGE[(x + z * 3) % HEDGE.length]!);
        hedges.setColorAt(n, this.color);
        this.dummy.position.set((x + 0.5) * CELL, hgt - 0.02, (z + 0.5) * CELL);
        this.dummy.scale.set(0.78, 0.36, 0.78);
        this.dummy.updateMatrix();
        caps.setMatrixAt(n, this.dummy.matrix);
        this.color.set(CAPS[(x * 2 + z) % CAPS.length]!);
        caps.setColorAt(n, this.color);
        n++;
      }
    }
    hedges.instanceMatrix.needsUpdate = true;
    caps.instanceMatrix.needsUpdate = true;
    if (hedges.instanceColor) hedges.instanceColor.needsUpdate = true;
    if (caps.instanceColor) caps.instanceColor.needsUpdate = true;
    hedges.computeBoundingSphere();
    caps.computeBoundingSphere();
    group.add(hedges);
    group.add(caps);

    const gemGeo = new THREE.OctahedronGeometry(0.24, 0);
    const gemMat = new THREE.MeshStandardMaterial({
      color: 0xf0b429,
      emissive: 0xc48a12,
      emissiveIntensity: 0.55,
      roughness: 0.32,
      metalness: 0.05,
    });
    const gems = new THREE.InstancedMesh(gemGeo, gemMat, Math.max(1, maze.pickups.length));
    gems.count = maze.pickups.length;
    const haloGeo = new THREE.SphereGeometry(0.42, 8, 6);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0xffe7a8,
      transparent: true,
      opacity: 0.38,
      depthWrite: false,
    });
    const halos = new THREE.InstancedMesh(haloGeo, haloMat, Math.max(1, maze.pickups.length));
    halos.count = maze.pickups.length;
    this.gemMesh = gems;
    this.haloMesh = halos;
    group.add(gems);
    group.add(halos);

    const exit = cellCenter(maze.exit);
    const rot = gateRotY(maze);
    const gate = new THREE.Group();
    gate.position.set(exit.x, 0, exit.z);
    gate.rotation.y = rot;
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0xffe29a,
      emissive: 0xf0b429,
      emissiveIntensity: 0.85,
      roughness: 0.35,
    });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.86, 0.075, 5, 14), ringMat);
    ring.position.y = 1.15;
    ring.castShadow = true;
    const innerMat = new THREE.MeshStandardMaterial({
      color: 0xffc1b0,
      emissive: 0xff6b4a,
      emissiveIntensity: 0.7,
      roughness: 0.4,
    });
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.045, 5, 12), innerMat);
    ring2.position.y = 1.15;
    const discMat = new THREE.MeshBasicMaterial({
      color: 0xfff1c9,
      transparent: true,
      opacity: 0.34,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const disc = new THREE.Mesh(new THREE.CircleGeometry(0.5, 14), discMat);
    disc.position.y = 1.15;
    const pad = new THREE.Mesh(
      new THREE.CircleGeometry(0.7, 14),
      new THREE.MeshStandardMaterial({ color: 0xf7d9a8, roughness: 1 }),
    );
    pad.rotation.x = -Math.PI / 2;
    pad.position.y = 0.025;
    const light = new THREE.PointLight(0xffc14d, 6, 7, 2);
    light.position.y = 1.3;
    gate.add(ring, ring2, disc, pad, light);
    group.add(gate);
    this.ringA = ring;
    this.ringB = ring2;
    this.disc = disc;

    this.scene.add(group);
    this.animateProps();
  }
}
