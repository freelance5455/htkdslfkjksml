import { soundEngine } from './audio';
import {
  AbilityId,
  Afterimage,
  Enemy,
  FloatingCallout,
  GameScreenState,
  GrappleNode,
  HitSlashEffect,
  HudSnapshot,
  Particle,
  Platform,
  Projectile,
  Rect,
  SectorId,
  SlashArc,
  SpeedRail,
} from './types';
import { createWorldBlueprint, detectSector, SECTORS, WorldBlueprint } from './world';

const GRAVITY = 1650;
const MAX_FALL = 790;
const RUN_SPEED = 350;
const GROUND_ACCEL = 3200;
const AIR_ACCEL = 2100;
const JUMP_VEL = -615;
const DOUBLE_JUMP_VEL = -580;
const WALL_SLIDE_MAX = 140;
const WALL_JUMP_VX = 375;
const WALL_JUMP_VY = -590;
const SLIDE_SPEED = 515;
const SLIDE_DURATION = 0.34;
const DASH_SPEED = 790;
const DASH_DURATION = 0.15;
const GRAPPLE_RANGE = 340;
const GRAPPLE_SPEED = 860;
const POGO_VEL = -565;

interface RainDrop {
  x: number;
  y: number;
  len: number;
  speed: number;
  alpha: number;
}

interface SkylineBuilding {
  x: number;
  w: number;
  h: number;
  layer: 0 | 1;
  accent: string;
  windows: boolean[];
}

export class HollowwireEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private rafId: number | null = null;
  private lastTime = 0;

  private world: WorldBlueprint;
  private screenState: GameScreenState = 'TITLE_MENU';

  // Input state
  private held = new Set<string>();
  private virtualHeld = new Set<string>();
  private justPressed = new Set<string>();
  private mouseLeftJustPressed = false;
  private mouseRightJustPressed = false;
  private forceDownSlash = false;

  // Player state
  private px = 210;
  private py = 1560;
  private pw = 24;
  private ph = 40;
  private vx = 0;
  private vy = 0;
  private facing: 1 | -1 = 1;
  private onGround = false;
  private onWall: -1 | 0 | 1 = 0;
  private coyoteTimer = 0;
  private jumpBufferTimer = 0;
  private wallJumpLockTimer = 0;

  // Parkour state
  private abilities = new Set<AbilityId>();
  private canDash = true;
  private dashTimer = 0;
  private dashCooldown = 0;
  private dashDir: 1 | -1 = 1;
  private hasDoubleJump = true;
  private slideTimer = 0;
  private onRail: SpeedRail | null = null;
  private grappleTarget: GrappleNode | null = null;
  private isGrappling = false;
  private grappleTimer = 0;

  // Visual squash & scarf Verlet trail
  private scaleX = 1;
  private scaleY = 1;
  private scarfNodes: Array<{ x: number; y: number; oldX: number; oldY: number }> = [];

  // Combat & Health
  private hp = 5;
  private maxHp = 5;
  private flux = 35;
  private shards = 0;
  private totalShards = 18;
  private invulnTimer = 0;
  private slashCooldown = 0;
  private activeSlashTimer = 0;
  private readonly activeSlashDuration = 0.16;
  private activeSlashDir: 'left' | 'right' | 'up' | 'down' = 'right';
  private slashSwingFlip = false;
  private comboCount = 0;
  private comboTimer = 0;
  private healChannel = 0;

  // Respawn & Progression
  private respawnX = 210;
  private respawnY = 1560;
  private currentSector: SectorId = 'sunken_conduit';
  private discoveredSectors = new Set<SectorId>(['sunken_conduit']);
  private activatedTerminals = new Set<string>(['uplink_conduit']);
  private activeBossId: string | null = null;
  private defeatedBosses = new Set<string>();
  private bossAttackCount = 0;
  private elapsedSeconds = 0;

  // FX & Juice
  private hitstopTimer = 0;
  private shakeIntensity = 0;
  private camX = 0;
  private camY = 1350;
  private particles: Particle[] = [];
  private afterimages: Afterimage[] = [];
  private slashArcs: SlashArc[] = [];
  private hitEffects: HitSlashEffect[] = [];
  private projectiles: Projectile[] = [];
  private callouts: FloatingCallout[] = [];
  private bannerTitle: string | null = null;
  private bannerSubtitle: string | null = null;
  private bannerTimer = 0;
  private activePrompt: string | null = null;

  // Backdrop ambience & cached CanvasPattern textures
  private rain: RainDrop[] = [];
  private buildings: SkylineBuilding[] = [];
  private solidPattern: CanvasPattern | null = null;
  private foundryPattern: CanvasPattern | null = null;
  private spirePattern: CanvasPattern | null = null;
  private neonWallPattern: CanvasPattern | null = null;
  private catwalkPattern: CanvasPattern | null = null;
  private hazardStripePattern: CanvasPattern | null = null;

  // Callbacks to React shell
  private onHudUpdate: (hud: HudSnapshot) => void;
  private onScreenChange: (next: GameScreenState) => void;
  private hudEmitTimer = 0;

  constructor(
    canvas: HTMLCanvasElement,
    onHudUpdate: (hud: HudSnapshot) => void,
    onScreenChange: (next: GameScreenState) => void
  ) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Could not initialize 2D canvas context');
    }
    this.ctx = context;
    this.onHudUpdate = onHudUpdate;
    this.onScreenChange = onScreenChange;
    this.world = createWorldBlueprint();

    this.initTextures();
    this.initBackdrop();
    this.resetScarf();
    this.bindEvents();
  }

  private createTileCanvas(
    w: number,
    h: number,
    drawFn: (tctx: CanvasRenderingContext2D) => void
  ): CanvasPattern | null {
    const off = document.createElement('canvas');
    off.width = w;
    off.height = h;
    const tctx = off.getContext('2d');
    if (!tctx) return null;
    drawFn(tctx);
    return this.ctx.createPattern(off, 'repeat');
  }

  private initTextures(): void {
    // 1. Brushed Steel Metro Plating
    this.solidPattern = this.createTileCanvas(48, 48, (t) => {
      t.fillStyle = '#0b1222';
      t.fillRect(0, 0, 48, 48);
      // Subtle metal grain streaks
      t.fillStyle = 'rgba(148, 163, 184, 0.04)';
      for (let y = 2; y < 48; y += 6) {
        t.fillRect(0, y, 48, 1);
      }
      // Recessed panel seam
      t.strokeStyle = 'rgba(2, 6, 23, 0.75)';
      t.lineWidth = 1.5;
      t.strokeRect(0.75, 0.75, 46.5, 46.5);
      // Inner bevel highlight
      t.strokeStyle = 'rgba(56, 189, 248, 0.08)';
      t.lineWidth = 1;
      t.strokeRect(2.5, 2.5, 43, 43);
      // Corner rivets
      t.fillStyle = 'rgba(148, 163, 184, 0.22)';
      t.fillRect(5, 5, 2, 2);
      t.fillRect(41, 5, 2, 2);
      t.fillRect(5, 41, 2, 2);
      t.fillRect(41, 41, 2, 2);
    });

    // 2. Cryo-Foundry Industrial Plate
    this.foundryPattern = this.createTileCanvas(48, 48, (t) => {
      t.fillStyle = '#0a161b';
      t.fillRect(0, 0, 48, 48);
      t.fillStyle = 'rgba(16, 185, 129, 0.05)';
      t.fillRect(0, 22, 48, 4);
      t.strokeStyle = 'rgba(2, 6, 23, 0.8)';
      t.strokeRect(0.5, 0.5, 47, 47);
      t.fillStyle = 'rgba(52, 211, 153, 0.16)';
      t.fillRect(6, 6, 3, 3);
      t.fillRect(39, 39, 3, 3);
    });

    // 3. Black Spire & Data Vault Carbon Monolith
    this.spirePattern = this.createTileCanvas(48, 48, (t) => {
      t.fillStyle = '#110d20';
      t.fillRect(0, 0, 48, 48);
      t.strokeStyle = 'rgba(232, 121, 249, 0.09)';
      t.beginPath();
      t.moveTo(0, 24);
      t.lineTo(16, 24);
      t.lineTo(24, 16);
      t.lineTo(48, 16);
      t.stroke();
      t.strokeStyle = 'rgba(0, 0, 0, 0.65)';
      t.strokeRect(0.5, 0.5, 47, 47);
    });

    // 4. Tactile Wall-Jump Chevron Grip Surface
    this.neonWallPattern = this.createTileCanvas(28, 28, (t) => {
      t.fillStyle = '#12182f';
      t.fillRect(0, 0, 28, 28);
      t.strokeStyle = 'rgba(34, 211, 238, 0.22)';
      t.lineWidth = 2;
      t.beginPath();
      t.moveTo(4, 18);
      t.lineTo(14, 8);
      t.lineTo(24, 18);
      t.stroke();
      t.fillStyle = 'rgba(255, 255, 255, 0.06)';
      t.fillRect(0, 26, 28, 2);
    });

    // 5. Diamond-Plate One-Way Catwalk Mesh
    this.catwalkPattern = this.createTileCanvas(16, 16, (t) => {
      t.fillStyle = '#10192d';
      t.fillRect(0, 0, 16, 16);
      t.strokeStyle = 'rgba(148, 163, 184, 0.2)';
      t.lineWidth = 1.2;
      t.beginPath();
      t.moveTo(0, 0);
      t.lineTo(16, 16);
      t.moveTo(16, 0);
      t.lineTo(0, 16);
      t.stroke();
    });

    // 6. Caution Hazard Striping
    this.hazardStripePattern = this.createTileCanvas(20, 20, (t) => {
      t.fillStyle = '#18181b';
      t.fillRect(0, 0, 20, 20);
      t.fillStyle = 'rgba(245, 158, 11, 0.5)';
      t.beginPath();
      t.moveTo(0, 20);
      t.lineTo(10, 0);
      t.lineTo(18, 0);
      t.lineTo(8, 20);
      t.closePath();
      t.fill();
    });
  }

  private initBackdrop(): void {
    this.rain = Array.from({ length: 85 }, () => ({
      x: Math.random() * 1600,
      y: Math.random() * 960,
      len: 12 + Math.random() * 18,
      speed: 520 + Math.random() * 340,
      alpha: 0.08 + Math.random() * 0.16,
    }));

    const accents = ['#22d3ee', '#e879f9', '#38bdf8', '#f59e0b'];
    this.buildings = Array.from({ length: 46 }, (_, i) => ({
      x: i * 110 - 200,
      w: 64 + ((i * 37) % 70),
      h: 180 + ((i * 97) % 340),
      layer: (i % 2) as 0 | 1,
      accent: accents[i % accents.length],
      windows: Array.from({ length: 12 }, (__, wIdx) => ((i + wIdx * 3) % 5) === 0),
    }));
  }

  private resetScarf(): void {
    const startX = this.px + this.pw / 2 - this.facing * 3;
    const startY = this.py + 13;
    this.scarfNodes = Array.from({ length: 9 }, (_, i) => {
      const nx = startX - i * 3.4 * this.facing;
      const ny = Math.min(this.py + this.ph - 5, startY + i * 2.1);
      return { x: nx, y: ny, oldX: nx, oldY: ny };
    });
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    const code = e.code;
    if (
      code === 'Space' ||
      code === 'ArrowUp' ||
      code === 'ArrowDown' ||
      code === 'ArrowLeft' ||
      code === 'ArrowRight'
    ) {
      e.preventDefault();
    }
    if (!this.held.has(code)) {
      this.justPressed.add(code);
    }
    this.held.add(code);
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.held.delete(e.code);
  };

  private handleBlur = () => {
    this.held.clear();
    this.virtualHeld.clear();
    this.justPressed.clear();
  };

  public setVirtualHeld(code: string, active: boolean): void {
    if (active) {
      if (!this.virtualHeld.has(code)) {
        this.justPressed.add(code);
      }
      this.virtualHeld.add(code);
    } else {
      this.virtualHeld.delete(code);
    }
  }

  public triggerVirtualPogo(): void {
    this.forceDownSlash = true;
    this.justPressed.add('KeyJ');
  }

  public clearVirtualInputs(): void {
    this.virtualHeld.clear();
  }

  private handleMouseDown = (e: MouseEvent) => {
    if (this.screenState !== 'PLAYING') return;
    if (e.button === 0) this.mouseLeftJustPressed = true;
    if (e.button === 2) this.mouseRightJustPressed = true;
  };

  private handleContextMenu = (e: MouseEvent) => {
    if (this.screenState === 'PLAYING') {
      e.preventDefault();
    }
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('blur', this.handleBlur);
    this.canvas.addEventListener('mousedown', this.handleMouseDown);
    this.canvas.addEventListener('contextmenu', this.handleContextMenu);
  }

  public destroy(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
    }
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('blur', this.handleBlur);
    this.canvas.removeEventListener('mousedown', this.handleMouseDown);
    this.canvas.removeEventListener('contextmenu', this.handleContextMenu);
  }

  public startLoop(): void {
    this.lastTime = performance.now();
    const tick = (now: number) => {
      const rawDt = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const dt = Math.min(Math.max(rawDt, 0), 0.05);

      this.resizeCanvasIfNeeded();
      if (this.screenState === 'PLAYING') {
        this.update(dt);
      } else {
        this.updateAmbient(dt);
      }
      this.render();

      this.justPressed.clear();
      this.mouseLeftJustPressed = false;
      this.mouseRightJustPressed = false;
      this.forceDownSlash = false;
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  private resizeCanvasIfNeeded(): void {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.floor(this.canvas.clientWidth * dpr);
    const height = Math.floor(this.canvas.clientHeight * dpr);
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = Math.max(1, width);
      this.canvas.height = Math.max(1, height);
    }
  }

  public setScreenState(next: GameScreenState): void {
    this.screenState = next;
    this.held.clear();
    this.virtualHeld.clear();
    this.justPressed.clear();
    this.emitHudNow();
  }

  public startNewRun(): void {
    this.world = createWorldBlueprint();
    this.px = 210;
    this.py = 1560;
    this.vx = 0;
    this.vy = 0;
    this.facing = 1;
    this.hp = 5;
    this.maxHp = 5;
    this.flux = 35;
    this.shards = 0;
    this.abilities.clear();
    this.respawnX = 210;
    this.respawnY = 1560;
    this.currentSector = 'sunken_conduit';
    this.discoveredSectors = new Set<SectorId>(['sunken_conduit']);
    this.activatedTerminals = new Set<string>(['uplink_conduit']);
    this.activeBossId = null;
    this.defeatedBosses.clear();
    this.bossAttackCount = 0;
    this.elapsedSeconds = 0;
    this.comboCount = 0;
    this.comboTimer = 0;
    this.activeSlashTimer = 0;
    this.particles = [];
    this.afterimages = [];
    this.slashArcs = [];
    this.hitEffects = [];
    this.projectiles = [];
    this.callouts = [];
    this.onRail = null;
    this.isGrappling = false;
    this.grappleTarget = null;
    this.invulnTimer = 0.6;
    this.camX = this.px;
    this.camY = this.py - 80;
    this.resetScarf();
    this.showBanner('SECTOR 01 · SUNKEN CONDUIT', 'Ascend Maglev Spire or descend to Cryo-Foundry');
    this.screenState = 'PLAYING';
    this.onScreenChange('PLAYING');
    this.emitHudNow();
  }

  public respawnAtLastUplink(): void {
    this.px = this.respawnX;
    this.py = this.respawnY - 4;
    this.vx = 0;
    this.vy = 0;
    this.hp = this.maxHp;
    this.flux = Math.max(this.flux, 35);
    this.invulnTimer = 1.0;
    this.onRail = null;
    this.isGrappling = false;
    this.dashTimer = 0;
    this.slideTimer = 0;
    this.activeSlashTimer = 0;
    this.activeBossId = null;
    this.bossAttackCount = 0;

    // Reset in-arena repair relays for bosses not yet defeated
    const relayBossMap: Record<string, string> = {
      relay_boss_west: 'boss_archon',
      relay_boss_east: 'boss_archon',
      relay_vortex_west: 'boss_vortex',
      relay_vortex_east: 'boss_vortex',
      relay_glacier_west: 'boss_glacier',
      relay_glacier_east: 'boss_glacier',
      relay_nexus_west: 'boss_nexus',
      relay_nexus_east: 'boss_nexus',
    };
    for (const item of this.world.pickups) {
      if (item.kind === 'repair_relay') {
        const bossId = relayBossMap[item.id];
        if (!bossId || !this.defeatedBosses.has(bossId)) {
          item.collected = false;
        }
      }
    }

    for (const enemy of this.world.enemies) {
      if (this.isBossEnemy(enemy) && this.defeatedBosses.has(enemy.id)) continue;
      enemy.x = enemy.spawnX;
      enemy.y = enemy.spawnY;
      enemy.vx =
        enemy.kind === 'patrol_bot' ||
        enemy.kind === 'hover_sentinel' ||
        enemy.kind === 'dash_stalker' ||
        enemy.kind === 'plasma_orbiter' ||
        enemy.kind === 'shield_warden'
          ? 75
          : 0;
      enemy.vy = 0;
      enemy.hp = enemy.maxHp;
      enemy.alive = true;
      enemy.phase2 = false;
      enemy.aiPhase = this.isBossEnemy(enemy)
        ? 'idle'
        : enemy.kind === 'patrol_bot' || enemy.kind === 'dash_stalker' || enemy.kind === 'shield_warden'
        ? 'patrol'
        : enemy.aiPhase;
      enemy.stateTimer = 1.2;
      enemy.telegraphTimer = 0;
    }
    this.projectiles = [];
    this.hitEffects = [];
    this.resetScarf();
    this.screenState = 'PLAYING';
    this.onScreenChange('PLAYING');
    this.emitHudNow();
  }

  private isBossEnemy(e: Enemy): boolean {
    return (
      e.kind === 'boss_archon' ||
      e.kind === 'boss_vortex' ||
      e.kind === 'boss_glacier' ||
      e.kind === 'boss_nexus'
    );
  }

  private getBossConfig(kind: Enemy['kind']): {
    name: string;
    subtitle: string;
    arenaMinX: number;
    arenaMaxX: number;
    topY: number;
    floorY: number;
    hoverY: number;
    groundY: number;
    color: string;
    dashSpeed: number;
    barrageCount: number;
    slamSpeed: number;
  } {
    switch (kind) {
      case 'boss_vortex':
        return {
          name: 'VORTEX-VII',
          subtitle: 'Void Foundry Phantom Stalker',
          arenaMinX: 4540,
          arenaMaxX: 5440,
          topY: 940,
          floorY: 1580,
          hoverY: 1240,
          groundY: 1484,
          color: '#e879f9',
          dashSpeed: 760,
          barrageCount: 5,
          slamSpeed: 1180,
        };
      case 'boss_glacier':
        return {
          name: 'GLACIER-OMEGA',
          subtitle: 'Cryo-Abyss Armored Titan',
          arenaMinX: 1160,
          arenaMaxX: 2340,
          topY: 2440,
          floorY: 3020,
          hoverY: 2680,
          groundY: 2918,
          color: '#34d399',
          dashSpeed: 640,
          barrageCount: 6,
          slamSpeed: 1260,
        };
      case 'boss_nexus':
        return {
          name: 'NEXUS-PRIME',
          subtitle: 'Zenith Apex Sovereign Overlord',
          arenaMinX: 3120,
          arenaMaxX: 4340,
          topY: -510,
          floorY: 80,
          hoverY: -260,
          groundY: -20,
          color: '#fbbf24',
          dashSpeed: 810,
          barrageCount: 7,
          slamSpeed: 1300,
        };
      case 'boss_archon':
      default:
        return {
          name: 'ARCHON-IX',
          subtitle: 'Black Spire Containment Engaged',
          arenaMinX: 980,
          arenaMaxX: 2350,
          topY: 190,
          floorY: 780,
          hoverY: 450,
          groundY: 684,
          color: '#f43f5e',
          dashSpeed: 680,
          barrageCount: 4,
          slamSpeed: 1120,
        };
    }
  }

  public captureSnapshotDataUrl(): string {
    return this.canvas.toDataURL('image/jpeg', 0.82);
  }

  public getHudSnapshot(): HudSnapshot {
    const activeBoss = this.activeBossId
      ? this.world.enemies.find((e) => e.id === this.activeBossId)
      : null;
    const bossCfg = activeBoss ? this.getBossConfig(activeBoss.kind) : null;
    return {
      hp: this.hp,
      maxHp: this.maxHp,
      flux: this.flux,
      shards: this.shards,
      totalShards: this.totalShards,
      abilities: Array.from(this.abilities),
      currentSector: this.currentSector,
      currentSectorName: SECTORS[this.currentSector].name,
      discoveredSectors: Array.from(this.discoveredSectors),
      speed: Math.round(Math.hypot(this.vx, this.vy)),
      comboCount: this.comboCount,
      healProgress: this.healChannel / 0.5,
      activePrompt: this.activePrompt,
      bossActive: Boolean(activeBoss && activeBoss.alive),
      activeBossName: bossCfg ? bossCfg.name : 'ARCHON-IX',
      bossHp: activeBoss ? Math.max(0, activeBoss.hp) : 0,
      bossMaxHp: activeBoss ? activeBoss.maxHp : 34,
      bossPhase2: Boolean(activeBoss?.phase2),
      bossDefeated: this.defeatedBosses.has('boss_archon'),
      defeatedBosses: Array.from(this.defeatedBosses),
      playerX: this.px,
      playerY: this.py,
      elapsedSeconds: this.elapsedSeconds,
      bannerTitle: this.bannerTimer > 0 ? this.bannerTitle : null,
      bannerSubtitle: this.bannerTimer > 0 ? this.bannerSubtitle : null,
      muted: soundEngine.isMuted(),
    };
  }

  private emitHudNow(): void {
    this.onHudUpdate(this.getHudSnapshot());
  }

  private showBanner(title: string, subtitle: string, duration = 3.2): void {
    this.bannerTitle = title;
    this.bannerSubtitle = subtitle;
    this.bannerTimer = duration;
  }

  private isDown(codes: string[]): boolean {
    return codes.some((c) => this.held.has(c) || this.virtualHeld.has(c));
  }

  private wasPressed(codes: string[]): boolean {
    return codes.some((c) => this.justPressed.has(c));
  }

  private updateAmbient(dt: number): void {
    for (const drop of this.rain) {
      drop.y += drop.speed * dt;
      drop.x -= drop.speed * 0.16 * dt;
      if (drop.y > 960) {
        drop.y = -20;
        drop.x = Math.random() * 1700;
      }
    }
  }

  private update(dt: number): void {
    this.updateAmbient(dt);
    this.elapsedSeconds += dt;

    if (this.bannerTimer > 0) this.bannerTimer -= dt;
    if (this.invulnTimer > 0) this.invulnTimer -= dt;
    if (this.slashCooldown > 0) this.slashCooldown -= dt;
    if (this.activeSlashTimer > 0) this.activeSlashTimer = Math.max(0, this.activeSlashTimer - dt);
    if (this.dashCooldown > 0) this.dashCooldown -= dt;
    if (this.wallJumpLockTimer > 0) this.wallJumpLockTimer -= dt;
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.comboCount = 0;
    }

    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      this.shakeIntensity = Math.max(0, this.shakeIntensity - 28 * dt);
      return;
    }

    this.shakeIntensity = Math.max(0, this.shakeIntensity - 26 * dt);
    this.scaleX += (1 - this.scaleX) * Math.min(1, dt * 15);
    this.scaleY += (1 - this.scaleY) * Math.min(1, dt * 15);

    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateProjectiles(dt);
    this.updatePickupsAndTerminals(dt);
    this.updateEffects(dt);
    this.updateCamera(dt);

    // Sector detection
    const detected = detectSector(this.px + this.pw / 2, this.py + this.ph / 2);
    if (detected !== this.currentSector) {
      this.currentSector = detected;
      const isNew = !this.discoveredSectors.has(detected);
      this.discoveredSectors.add(detected);
      if (isNew) {
        this.showBanner(SECTORS[detected].name.toUpperCase(), SECTORS[detected].subtitle, 2.8);
      }
    }

    // Trigger Bosses when entering each Sanctum Arena
    if (!this.activeBossId) {
      let triggeredId: string | null = null;
      if (
        !this.defeatedBosses.has('boss_archon') &&
        this.currentSector === 'black_spire' &&
        this.px > 1060 &&
        this.py > 380
      ) {
        triggeredId = 'boss_archon';
      } else if (
        !this.defeatedBosses.has('boss_vortex') &&
        this.currentSector === 'void_foundry' &&
        this.px > 4560 &&
        this.py > 1200
      ) {
        triggeredId = 'boss_vortex';
      } else if (
        !this.defeatedBosses.has('boss_glacier') &&
        this.currentSector === 'cryo_abyss' &&
        this.px > 1190 &&
        this.py > 2740
      ) {
        triggeredId = 'boss_glacier';
      } else if (
        !this.defeatedBosses.has('boss_nexus') &&
        this.currentSector === 'zenith_apex' &&
        this.px > 3160 &&
        this.py > -260
      ) {
        triggeredId = 'boss_nexus';
      }

      if (triggeredId) {
        const boss = this.world.enemies.find((e) => e.id === triggeredId && e.alive);
        if (boss) {
          this.activeBossId = triggeredId;
          this.bossAttackCount = 0;
          const cfg = this.getBossConfig(boss.kind);
          soundEngine.playBossWarning();
          this.shakeIntensity = 9;
          this.showBanner(`${cfg.name} // ENGAGED`, cfg.subtitle, 3.4);
        }
      }
    }

    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.08) {
      this.hudEmitTimer = 0;
      this.emitHudNow();
    }
  }

  private updatePlayer(dt: number): void {
    const moveLeft = this.isDown(['KeyA', 'ArrowLeft']);
    const moveRight = this.isDown(['KeyD', 'ArrowRight']);
    const holdUp = this.isDown(['KeyW', 'ArrowUp']);
    const holdDown = this.isDown(['KeyS', 'ArrowDown']);
    const moveDir = (moveRight ? 1 : 0) - (moveLeft ? 1 : 0);

    const jumpPressed = this.wasPressed(['Space']);
    const jumpHeld = this.isDown(['Space']);
    const dashPressed = this.wasPressed(['ShiftLeft', 'ShiftRight', 'KeyK', 'KeyX']);
    const slashPressed = this.wasPressed(['KeyJ', 'KeyZ']) || this.mouseLeftJustPressed;
    const grapplePressed = this.wasPressed(['KeyC', 'KeyL']) || this.mouseRightJustPressed;
    const healHeld = this.isDown(['KeyE', 'KeyH']);

    if (jumpPressed) {
      this.jumpBufferTimer = 0.12;
    } else if (this.jumpBufferTimer > 0) {
      this.jumpBufferTimer -= dt;
    }

    // Update facing
    if (moveDir !== 0 && this.wallJumpLockTimer <= 0 && this.dashTimer <= 0) {
      this.facing = moveDir > 0 ? 1 : -1;
    }

    // Focus Heal (Hollow Knight Soul style!)
    if (
      healHeld &&
      this.onGround &&
      Math.abs(this.vx) < 40 &&
      this.flux >= 33 &&
      this.hp < this.maxHp &&
      !this.activePrompt
    ) {
      this.healChannel += dt;
      if (Math.random() < 0.45) {
        this.spawnParticle(
          this.px + this.pw / 2 + (Math.random() - 0.5) * 38,
          this.py + this.ph - 4,
          0,
          -65 - Math.random() * 55,
          '#22d3ee',
          3,
          0.4,
          0
        );
      }
      if (this.healChannel >= 0.5) {
        this.healChannel = 0;
        this.flux -= 33;
        this.hp = Math.min(this.maxHp, this.hp + 1);
        soundEngine.playHeal();
        this.spawnBurst(this.px + this.pw / 2, this.py + this.ph / 2, '#22d3ee', 18, 220);
        this.callouts.push({
          x: this.px + this.pw / 2,
          y: this.py - 10,
          vy: -45,
          text: '+1 INTEGRITY',
          color: '#22d3ee',
          life: 0.9,
          maxLife: 0.9,
        });
      }
    } else {
      this.healChannel = 0;
    }

    // Locate best Grapple Node
    this.grappleTarget = null;
    if (this.abilities.has('grapple_tether')) {
      let bestScore = Infinity;
      const cx = this.px + this.pw / 2;
      const cy = this.py + this.ph / 2;
      for (const node of this.world.grappleNodes) {
        const dx = node.x - cx;
        const dy = node.y - cy;
        const dist = Math.hypot(dx, dy);
        if (dist <= GRAPPLE_RANGE && dist > 45) {
          const dirBias = dx * this.facing > -40 ? 0.78 : 1.25;
          const score = dist * dirBias;
          if (score < bestScore) {
            bestScore = score;
            this.grappleTarget = node;
          }
        }
      }
    }

    // Start Grapple Tether
    if (grapplePressed && this.grappleTarget && !this.isGrappling) {
      this.isGrappling = true;
      this.grappleTimer = 0.42;
      this.onRail = null;
      this.dashTimer = 0;
      this.slideTimer = 0;
      this.canDash = true;
      this.hasDoubleJump = true;
      soundEngine.playGrapple();
      this.spawnBurst(this.grappleTarget.x, this.grappleTarget.y, '#38bdf8', 10, 160);
    }

    // Phase Dash Trigger
    if (
      dashPressed &&
      this.abilities.has('phase_dash') &&
      this.canDash &&
      this.dashCooldown <= 0 &&
      this.dashTimer <= 0
    ) {
      this.dashTimer = DASH_DURATION;
      this.dashCooldown = 0.22;
      this.canDash = false;
      this.isGrappling = false;
      this.onRail = null;
      this.slideTimer = 0;
      this.dashDir = moveDir !== 0 ? (moveDir > 0 ? 1 : -1) : this.facing;
      this.facing = this.dashDir;
      this.vx = this.dashDir * DASH_SPEED;
      this.vy = 0;
      this.scaleX = 1.32;
      this.scaleY = 0.72;
      soundEngine.playDash();
      this.spawnBurst(this.px + this.pw / 2, this.py + this.ph / 2, '#00d4ff', 16, 220);
    }

    // Active Grapple Motion
    if (this.isGrappling && this.grappleTarget) {
      this.grappleTimer -= dt;
      const cx = this.px + this.pw / 2;
      const cy = this.py + this.ph / 2;
      const dx = this.grappleTarget.x - cx;
      const dy = this.grappleTarget.y - cy;
      const dist = Math.hypot(dx, dy);

      if (dist < 44 || this.grappleTimer <= 0 || this.jumpBufferTimer > 0) {
        this.isGrappling = false;
        this.vy = Math.min(this.vy, -430);
        if (this.jumpBufferTimer > 0) {
          this.jumpBufferTimer = 0;
          this.vy = -560;
          soundEngine.playJump();
        }
      } else {
        this.vx = (dx / dist) * GRAPPLE_SPEED;
        this.vy = (dy / dist) * GRAPPLE_SPEED;
      }
    } else if (this.dashTimer > 0) {
      // Active Phase Dash with neon-blue particle trail
      this.dashTimer -= dt;
      this.vx = this.dashDir * DASH_SPEED;
      this.vy = 0;
      this.afterimages.push({
        x: this.px,
        y: this.py,
        w: this.pw,
        h: this.ph,
        facing: this.facing,
        alpha: 0.72,
        color: '#00d4ff',
      });
      for (let i = 0; i < 3; i++) {
        this.spawnParticle(
          this.px + Math.random() * this.pw,
          this.py + 4 + Math.random() * (this.ph - 8),
          -this.dashDir * (90 + Math.random() * 170),
          (Math.random() - 0.5) * 70,
          i === 0 ? '#00e5ff' : i === 1 ? '#38bdf8' : '#0284c7',
          2.5 + Math.random() * 3,
          0.24 + Math.random() * 0.18,
          0
        );
      }
      if (this.dashTimer <= 0) {
        this.vx = this.dashDir * 420;
      }
    } else if (this.onRail) {
      // Active Speed Rail Grinding
      const r = this.onRail;
      const rdx = r.x2 - r.x1;
      const rdy = r.y2 - r.y1;
      const rLen = Math.hypot(rdx, rdy);
      const dirSign = this.vx >= 0 ? 1 : -1;
      const railSpeed = 680;
      this.vx = (rdx / rLen) * railSpeed * dirSign;
      this.vy = (rdy / rLen) * railSpeed * dirSign;
      this.canDash = true;
      this.hasDoubleJump = true;

      if (Math.random() < 0.7) {
        this.spawnParticle(
          this.px + this.pw / 2,
          this.py + this.ph,
          -this.vx * 0.25 + (Math.random() - 0.5) * 80,
          -60 - Math.random() * 80,
          r.color === 'amber' ? '#f59e0b' : '#22d3ee',
          3,
          0.25,
          450
        );
      }

      if (this.jumpBufferTimer > 0) {
        this.jumpBufferTimer = 0;
        this.onRail = null;
        this.vy = JUMP_VEL * 1.04;
        this.vx = Math.max(Math.abs(this.vx), 460) * dirSign;
        soundEngine.playJump();
        this.scaleX = 0.78;
        this.scaleY = 1.25;
      } else {
        // Check if still within rail span
        const cx = this.px + this.pw / 2;
        const minX = Math.min(r.x1, r.x2) - 10;
        const maxX = Math.max(r.x1, r.x2) + 10;
        if (cx < minX || cx > maxX) {
          this.onRail = null;
          this.vy = Math.min(this.vy, -210);
        }
      }
    } else {
      // Standard Run / Slide / Jump / Wall-Slide
      // Trigger Slide
      if (
        this.onGround &&
        holdDown &&
        this.slideTimer <= 0 &&
        (Math.abs(this.vx) > 120 || moveDir !== 0)
      ) {
        const sDir = moveDir !== 0 ? (moveDir > 0 ? 1 : -1) : this.facing;
        this.facing = sDir;
        this.vx = sDir * SLIDE_SPEED;
        this.slideTimer = SLIDE_DURATION;
        this.setHitboxHeight(22);
        soundEngine.playSlide();
      }

      if (this.slideTimer > 0) {
        this.slideTimer -= dt;
        if (Math.random() < 0.6) {
          this.spawnParticle(
            this.px + this.pw / 2,
            this.py + this.ph,
            -this.vx * 0.2,
            -40 - Math.random() * 50,
            '#38bdf8',
            2.5,
            0.22,
            300
          );
        }
        if (this.slideTimer <= 0 || !this.onGround) {
          this.tryStandUp();
        }
      } else {
        this.tryStandUp();
      }

      // Horizontal acceleration
      if (this.wallJumpLockTimer <= 0 && this.slideTimer <= 0) {
        const targetVx = moveDir * RUN_SPEED;
        const accel = this.onGround ? GROUND_ACCEL : AIR_ACCEL;
        if (this.vx < targetVx) {
          this.vx = Math.min(targetVx, this.vx + accel * dt);
        } else if (this.vx > targetVx) {
          this.vx = Math.max(targetVx, this.vx - accel * dt);
        }
      } else if (this.slideTimer > 0) {
        this.vx *= 1 - 0.8 * dt;
      }

      // Coyote time
      if (this.onGround) {
        this.coyoteTimer = 0.1;
        this.canDash = true;
        this.hasDoubleJump = true;
      } else if (this.coyoteTimer > 0) {
        this.coyoteTimer -= dt;
      }

      // Jump / Wall-Jump / Double-Jump / Slide-Vault (all emit neon-blue particles matching dash!)
      if (this.jumpBufferTimer > 0) {
        if (this.coyoteTimer > 0) {
          const wasSliding = this.slideTimer > 0;
          this.slideTimer = 0;
          this.tryStandUp();
          this.jumpBufferTimer = 0;
          this.coyoteTimer = 0;
          this.onGround = false;
          this.vy = JUMP_VEL;
          if (wasSliding) {
            this.vx = this.facing * 510;
            this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, '#00d4ff', 14, 190);
          } else {
            this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, '#00d4ff', 9, 150);
          }
          this.scaleX = 0.76;
          this.scaleY = 1.26;
          soundEngine.playJump();
        } else if (this.onWall !== 0) {
          this.jumpBufferTimer = 0;
          this.vy = WALL_JUMP_VY;
          this.vx = -this.onWall * WALL_JUMP_VX;
          this.facing = (-this.onWall) as 1 | -1;
          this.wallJumpLockTimer = 0.14;
          this.canDash = true;
          this.scaleX = 0.78;
          this.scaleY = 1.22;
          soundEngine.playWallJump();
          this.spawnBurst(
            this.onWall === 1 ? this.px + this.pw : this.px,
            this.py + this.ph / 2,
            '#00d4ff',
            11,
            165
          );
        } else if (this.abilities.has('aero_thruster') && this.hasDoubleJump) {
          this.jumpBufferTimer = 0;
          this.hasDoubleJump = false;
          this.vy = DOUBLE_JUMP_VEL;
          this.scaleX = 0.76;
          this.scaleY = 1.24;
          soundEngine.playDoubleJump();
          this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, '#00d4ff', 14, 195);
          for (let i = 0; i < 6; i++) {
            this.spawnParticle(
              this.px + 4 + Math.random() * (this.pw - 8),
              this.py + this.ph - 2,
              (Math.random() - 0.5) * 90,
              90 + Math.random() * 140,
              i % 2 === 0 ? '#00e5ff' : '#38bdf8',
              3,
              0.28,
              120
            );
          }
        }
      }

      // Variable jump cut
      if (!jumpHeld && this.vy < -180 && this.wallJumpLockTimer <= 0) {
        this.vy += GRAVITY * 1.45 * dt;
      }

      // Gravity & Wall-slide clamp
      this.vy = Math.min(MAX_FALL, this.vy + GRAVITY * dt);
      if (!this.onGround && this.onWall !== 0 && this.vy > WALL_SLIDE_MAX && moveDir === this.onWall) {
        this.vy = WALL_SLIDE_MAX;
        this.canDash = true;
        if (Math.random() < 0.35) {
          this.spawnParticle(
            this.onWall === 1 ? this.px + this.pw : this.px,
            this.py + 16,
            -this.onWall * 30,
            -40,
            '#e879f9',
            2.2,
            0.22,
            120
          );
        }
      }
    }

    // Move & Collide
    const prevOnGround = this.onGround;
    this.moveAndCollide(dt);
    if (!prevOnGround && this.onGround) {
      this.scaleX = 1.24;
      this.scaleY = 0.78;
      this.spawnBurst(this.px + this.pw / 2, this.py + this.ph, '#94a3b8', 5, 90);
    }

    // Snap onto Speed-Rails when airborne & falling onto rail
    if (!this.onRail && !this.isGrappling && this.dashTimer <= 0 && this.vy >= -40) {
      const cx = this.px + this.pw / 2;
      const feetY = this.py + this.ph;
      for (const rail of this.world.rails) {
        const minX = Math.min(rail.x1, rail.x2);
        const maxX = Math.max(rail.x1, rail.x2);
        if (cx >= minX && cx <= maxX) {
          const t = (cx - rail.x1) / (rail.x2 - rail.x1);
          const railY = rail.y1 + (rail.y2 - rail.y1) * t;
          if (Math.abs(feetY - railY) <= 14) {
            this.onRail = rail;
            this.py = railY - this.ph;
            if (Math.abs(this.vx) < 200) {
              this.vx = this.facing * 520;
            }
            soundEngine.playSlide();
            break;
          }
        }
      }
    }

    // Katana Slash (4-directional + Pogo!)
    if (slashPressed && this.slashCooldown <= 0) {
      this.slashCooldown = 0.24;
      let dir: 'left' | 'right' | 'up' | 'down' = this.facing === 1 ? 'right' : 'left';
      if (this.forceDownSlash) {
        dir = 'down';
      } else if (holdUp) {
        dir = 'up';
      } else if (holdDown && !this.onGround) {
        dir = 'down';
      }

      this.performSlash(dir);
    }

    // Hazard checks
    this.checkHazards();

    // Update tall red scarf with true Verlet cloth physics
    const anchorX = this.px + this.pw / 2 - this.facing * 4;
    const anchorY = this.py + 13;
    this.scarfNodes[0].x = anchorX;
    this.scarfNodes[0].y = anchorY;
    this.scarfNodes[0].oldX = anchorX;
    this.scarfNodes[0].oldY = anchorY;

    const timeNow = performance.now() * 0.005;
    const floorClearanceY = this.py + this.ph - 5;

    for (let i = 1; i < this.scarfNodes.length; i++) {
      const cur = this.scarfNodes[i];
      const velX = (cur.x - cur.oldX) * 0.88;
      const velY = (cur.y - cur.oldY) * 0.88;
      cur.oldX = cur.x;
      cur.oldY = cur.y;

      // Subtle breeze & downward drape + inertia when jumping/falling
      const breezeX = -this.facing * (35 + Math.sin(timeNow + i * 0.6) * 22);
      const waveY = Math.cos(timeNow * 1.3 + i * 0.7) * 14;
      cur.x += velX + breezeX * dt;
      cur.y += velY + (220 + waveY) * dt;
    }

    // Distance constraints keep scarf tall & cohesive without touching ground when grounded
    const segLen = 3.6;
    for (let iter = 0; iter < 4; iter++) {
      for (let i = 1; i < this.scarfNodes.length; i++) {
        const prev = this.scarfNodes[i - 1];
        const cur = this.scarfNodes[i];
        const dx = cur.x - prev.x;
        const dy = cur.y - prev.y;
        const dist = Math.hypot(dx, dy) || 0.001;
        const diff = (dist - segLen) / dist;
        if (i === 1) {
          cur.x -= dx * diff;
          cur.y -= dy * diff;
        } else {
          prev.x += dx * diff * 0.35;
          prev.y += dy * diff * 0.35;
          cur.x -= dx * diff * 0.65;
          cur.y -= dy * diff * 0.65;
        }
        if (this.onGround && cur.y > floorClearanceY) {
          cur.y = floorClearanceY;
        }
      }
      this.scarfNodes[0].x = anchorX;
      this.scarfNodes[0].y = anchorY;
    }
  }

  private setHitboxHeight(newH: number): void {
    if (this.ph === newH) return;
    this.py += this.ph - newH;
    this.ph = newH;
  }

  private tryStandUp(): void {
    if (this.ph === 40) return;
    const testRect: Rect = { x: this.px, y: this.py - (40 - this.ph), w: this.pw, h: 40 };
    for (const plat of this.getActivePlatforms()) {
      if (plat.kind !== 'oneway' && this.rectsOverlap(testRect, plat)) {
        return; // Keep crouching under low ceiling
      }
    }
    this.setHitboxHeight(40);
  }

  private getActivePlatforms(): Platform[] {
    return this.world.platforms.filter((p) => {
      if (p.kind === 'gate' && this.defeatedBosses.has('boss_archon')) return false;
      return true;
    });
  }

  private moveAndCollide(dt: number): void {
    const platforms = this.getActivePlatforms();

    // X Axis
    this.px += this.vx * dt;
    this.onWall = 0;
    const pRectX: Rect = { x: this.px, y: this.py, w: this.pw, h: this.ph };
    for (const plat of platforms) {
      if (plat.kind === 'oneway') continue;
      if (this.rectsOverlap(pRectX, plat)) {
        if (this.vx > 0) {
          this.px = plat.x - this.pw;
          this.onWall = 1;
        } else if (this.vx < 0) {
          this.px = plat.x + plat.w;
          this.onWall = -1;
        }
        this.vx = 0;
        pRectX.x = this.px;
      }
    }

    // Boss arena temporary containment walls
    if (this.activeBossId) {
      const activeBoss = this.world.enemies.find((e) => e.id === this.activeBossId && e.alive);
      if (activeBoss) {
        const cfg = this.getBossConfig(activeBoss.kind);
        if (this.px < cfg.arenaMinX) {
          this.px = cfg.arenaMinX;
          this.vx = 0;
        }
        if (this.px + this.pw > cfg.arenaMaxX) {
          this.px = cfg.arenaMaxX - this.pw;
          this.vx = 0;
        }
      }
    }

    // Y Axis
    const prevBottom = this.py + this.ph;
    this.py += this.vy * dt;
    this.onGround = false;
    const pRectY: Rect = { x: this.px, y: this.py, w: this.pw, h: this.ph };
    for (const plat of platforms) {
      if (plat.kind === 'oneway') {
        if (
          this.vy >= 0 &&
          prevBottom <= plat.y + 8 &&
          this.rectsOverlap(pRectY, plat)
        ) {
          this.py = plat.y - this.ph;
          this.vy = 0;
          this.onGround = true;
          pRectY.y = this.py;
        }
        continue;
      }
      if (this.rectsOverlap(pRectY, plat)) {
        if (this.vy > 0) {
          this.py = plat.y - this.ph;
          this.vy = 0;
          this.onGround = true;
        } else if (this.vy < 0) {
          this.py = plat.y + plat.h;
          this.vy = 0;
        }
        pRectY.y = this.py;
      }
    }

    // Check adjacent wall grip even when vx was stopped
    if (!this.onGround && this.onWall === 0) {
      const probeRight: Rect = { x: this.px + this.pw, y: this.py + 6, w: 3, h: this.ph - 12 };
      const probeLeft: Rect = { x: this.px - 3, y: this.py + 6, w: 3, h: this.ph - 12 };
      for (const plat of platforms) {
        if (plat.kind === 'oneway') continue;
        if (this.rectsOverlap(probeRight, plat)) {
          this.onWall = 1;
          break;
        }
        if (this.rectsOverlap(probeLeft, plat)) {
          this.onWall = -1;
          break;
        }
      }
    }
  }

  private performSlash(dir: 'left' | 'right' | 'up' | 'down'): void {
    const overdrive = this.abilities.has('overdrive_arc');
    soundEngine.playSlash(overdrive);

    this.activeSlashTimer = this.activeSlashDuration;
    this.activeSlashDir = dir;
    this.slashSwingFlip = !this.slashSwingFlip;

    const cx = this.px + this.pw / 2;
    const cy = this.py + this.ph / 2;
    let hitbox: Rect;
    if (dir === 'right') hitbox = { x: cx, y: cy - 30, w: 72, h: 60 };
    else if (dir === 'left') hitbox = { x: cx - 72, y: cy - 30, w: 72, h: 60 };
    else if (dir === 'up') hitbox = { x: cx - 32, y: cy - 74, w: 64, h: 70 };
    else hitbox = { x: cx - 34, y: cy + 6, w: 68, h: 70 };

    this.slashArcs.push({
      x: cx,
      y: cy,
      dir,
      life: 0.16,
      maxLife: 0.16,
      overdrive,
      flip: this.slashSwingFlip,
    });

    if (overdrive) {
      const speed = 720;
      const vx = dir === 'right' ? speed : dir === 'left' ? -speed : 0;
      const vy = dir === 'down' ? speed : dir === 'up' ? -speed : 0;
      this.projectiles.push({
        x: cx,
        y: cy,
        vx,
        vy,
        radius: 12,
        fromPlayer: true,
        damage: 1,
        life: 0.45,
        color: '#22d3ee',
        piercing: true,
      });
    }

    const damage = overdrive ? 2 : 1;
    let pogoTriggered = false;

    for (const enemy of this.world.enemies) {
      if (!enemy.alive) continue;
      if (this.rectsOverlap(hitbox, enemy)) {
        this.damageEnemy(enemy, damage, dir);
        if (dir === 'down') {
          pogoTriggered = true;
        }
      }
    }

    // Hollow Knight Spike-Pogo mechanic!
    if (dir === 'down' && !pogoTriggered) {
      for (const hazard of this.world.hazards) {
        if (hazard.pogoable && this.rectsOverlap(hitbox, hazard)) {
          pogoTriggered = true;
          this.spawnBurst(cx, hazard.y, '#f59e0b', 10, 170);
          break;
        }
      }
    }

    if (pogoTriggered) {
      this.vy = POGO_VEL;
      this.canDash = true;
      this.hasDoubleJump = true;
      this.comboCount += 1;
      this.comboTimer = 2.6;
      soundEngine.playPogo();
      this.scaleX = 0.78;
      this.scaleY = 1.24;
    }
  }

  private damageEnemy(enemy: Enemy, damage: number, slashDir: 'left' | 'right' | 'up' | 'down'): void {
    if (enemy.invulnTimer > 0) return;

    const ex = enemy.x + enemy.w / 2;
    const ey = enemy.y + enemy.h / 2;

    if (enemy.kind === 'pogo_mine') {
      enemy.hitFlashTimer = 0.12;
      this.hitstopTimer = 0.035;
      this.shakeIntensity = Math.max(this.shakeIntensity, 4);
      this.flux = Math.min(100, this.flux + 10);
      this.hitEffects.push({
        x: ex,
        y: ey,
        angle: Math.random() * Math.PI,
        life: 0.16,
        maxLife: 0.16,
        color: '#fbbf24',
      });
      this.spawnBurst(ex, ey, '#f59e0b', 12, 190);
      return;
    }

    // Shield Warden blocks frontal horizontal hits unless flanked, pogoed, or overdrive pierced!
    const overdrive = this.abilities.has('overdrive_arc');
    if (enemy.kind === 'shield_warden' && !overdrive && slashDir !== 'down' && slashDir !== 'up') {
      const hitFromFront =
        (enemy.facing === 1 && slashDir === 'left') || (enemy.facing === -1 && slashDir === 'right');
      if (hitFromFront && enemy.aiPhase !== 'recover') {
        enemy.invulnTimer = 0.14;
        if (slashDir === 'right') this.vx = -220;
        if (slashDir === 'left') this.vx = 220;
        soundEngine.playPogo();
        this.spawnBurst(ex + enemy.facing * 14, ey, '#38bdf8', 12, 210);
        this.callouts.push({
          x: ex,
          y: enemy.y - 12,
          vy: -36,
          text: 'BLOCKED · POGO OR FLANK',
          color: '#38bdf8',
          life: 0.75,
          maxLife: 0.75,
        });
        return;
      }
    }

    enemy.hp -= damage;
    enemy.hitFlashTimer = 0.12;
    enemy.invulnTimer = 0.14;
    this.hitstopTimer = 0.045;
    this.shakeIntensity = Math.max(this.shakeIntensity, 6);
    this.flux = Math.min(100, this.flux + 14);
    this.comboCount += 1;
    this.comboTimer = 2.6;

    // Recoil on player when hitting horizontally
    if (slashDir === 'right') this.vx = Math.min(this.vx, -160);
    if (slashDir === 'left') this.vx = Math.max(this.vx, 160);

    // Crisp katana X-slash impact & directional spark spray
    const baseAngle =
      slashDir === 'right' ? 0.38 : slashDir === 'left' ? -0.38 : slashDir === 'down' ? Math.PI * 0.25 : -Math.PI * 0.25;
    const hitCol = overdrive ? '#fbbf24' : '#38bdf8';
    this.hitEffects.push({
      x: ex,
      y: ey,
      angle: baseAngle + (Math.random() - 0.5) * 0.22,
      life: 0.18,
      maxLife: 0.18,
      color: hitCol,
    });
    for (let i = 0; i < 8; i++) {
      const dirSign = slashDir === 'right' ? 1 : slashDir === 'left' ? -1 : (Math.random() - 0.5) * 2;
      this.spawnParticle(
        ex,
        ey,
        dirSign * (140 + Math.random() * 210),
        (Math.random() - 0.5) * 220,
        i % 2 === 0 ? '#ffffff' : hitCol,
        2.5 + Math.random() * 2.5,
        0.22 + Math.random() * 0.14,
        180
      );
    }

    soundEngine.playHit(enemy.hp <= 0);

    if (enemy.hp <= 0) {
      enemy.alive = false;
      const isBoss = this.isBossEnemy(enemy);
      this.shards += isBoss ? 150 : 12;
      this.spawnBurst(ex, ey, isBoss ? '#38bdf8' : '#e879f9', isBoss ? 36 : 22, 290);

      if (isBoss) {
        const cfg = this.getBossConfig(enemy.kind);
        this.defeatedBosses.add(enemy.id);
        this.activeBossId = null;
        this.shakeIntensity = 14;
        soundEngine.playVictory();
        this.callouts.push({
          x: ex,
          y: ey - 18,
          vy: -45,
          text: `${cfg.name} SEVERED`,
          color: '#fbbf24',
          life: 1.4,
          maxLife: 1.4,
        });

        // Grant +1 Max Integrity reward for clearing new sector bosses
        if (enemy.kind !== 'boss_archon') {
          this.maxHp += 1;
          this.hp = this.maxHp;
          this.showBanner(
            `${cfg.name} DEFEATED`,
            '+150 Shards & +1 Max Armor Integrity Granted!',
            3.6
          );
        }

        this.emitHudNow();
        if (enemy.kind === 'boss_archon' || enemy.kind === 'boss_nexus') {
          setTimeout(() => {
            this.screenState = 'VICTORY';
            this.onScreenChange('VICTORY');
          }, 1200);
        }
      } else {
        this.callouts.push({
          x: ex,
          y: ey - 14,
          vy: -50,
          text: '+12 SHARDS',
          color: '#f59e0b',
          life: 0.9,
          maxLife: 0.9,
        });
      }
    }
  }

  private checkHazards(): void {
    const pRect: Rect = { x: this.px + 3, y: this.py + 3, w: this.pw - 6, h: this.ph - 4 };
    for (const h of this.world.hazards) {
      if (h.phaseable && this.dashTimer > 0) continue; // Phase Dash ignores lasers!
      if (this.rectsOverlap(pRect, h)) {
        if (h.kind === 'acid') {
          this.takeDamage(1, 0, -440);
        } else {
          const knockDir = this.px + this.pw / 2 < h.x + h.w / 2 ? -1 : 1;
          this.takeDamage(1, knockDir * 280, -340);
        }
        break;
      }
    }
  }

  private takeDamage(amount: number, knockVx: number, knockVy: number): void {
    if (this.invulnTimer > 0 || this.dashTimer > 0) return;

    this.hp = Math.max(0, this.hp - amount);
    this.invulnTimer = 1.05;
    this.hitstopTimer = 0.06;
    this.shakeIntensity = 11;
    this.vx = knockVx;
    this.vy = knockVy;
    this.isGrappling = false;
    this.onRail = null;
    this.healChannel = 0;

    soundEngine.playDamage();
    this.spawnBurst(this.px + this.pw / 2, this.py + this.ph / 2, '#f43f5e', 22, 260);
    this.emitHudNow();

    if (this.hp <= 0) {
      this.screenState = 'GAME_OVER';
      this.onScreenChange('GAME_OVER');
    }
  }

  private updateEnemies(dt: number): void {
    const pRect: Rect = { x: this.px, y: this.py, w: this.pw, h: this.ph };
    const pcx = this.px + this.pw / 2;
    const pcy = this.py + this.ph / 2;

    for (const e of this.world.enemies) {
      if (!e.alive) continue;
      if (e.hitFlashTimer > 0) e.hitFlashTimer -= dt;
      if (e.invulnTimer > 0) e.invulnTimer -= dt;

      if (e.kind === 'patrol_bot') {
        e.x += e.vx * dt;
        if (e.x <= e.patrolMinX) {
          e.x = e.patrolMinX;
          e.vx = Math.abs(e.vx);
          e.facing = 1;
        } else if (e.x + e.w >= e.patrolMaxX) {
          e.x = e.patrolMaxX - e.w;
          e.vx = -Math.abs(e.vx);
          e.facing = -1;
        }
      } else if (e.kind === 'hover_sentinel') {
        e.stateTimer += dt * 3;
        e.x += e.vx * dt;
        e.y = e.spawnY + Math.sin(e.stateTimer) * 14;
        if (e.x <= e.patrolMinX) {
          e.vx = Math.abs(e.vx);
          e.facing = 1;
        } else if (e.x + e.w >= e.patrolMaxX) {
          e.vx = -Math.abs(e.vx);
          e.facing = -1;
        }
      } else if (e.kind === 'pogo_mine') {
        e.stateTimer += dt * 2.5;
        e.y = e.spawnY + Math.sin(e.stateTimer) * 6;
      } else if (e.kind === 'sniper_turret') {
        const dist = Math.hypot(pcx - (e.x + e.w / 2), pcy - (e.y + e.h / 2));
        e.facing = pcx < e.x ? -1 : 1;
        if (dist < 620) {
          e.stateTimer -= dt;
          if (e.stateTimer <= 0.45 && e.stateTimer > 0) {
            e.telegraphTimer = e.stateTimer;
          }
          if (e.stateTimer <= 0) {
            e.stateTimer = 2.3;
            e.telegraphTimer = 0;
            const ex = e.x + e.w / 2;
            const ey = e.y + 12;
            const dx = pcx - ex;
            const dy = pcy - ey;
            const d = Math.hypot(dx, dy) || 1;
            this.projectiles.push({
              x: ex,
              y: ey,
              vx: (dx / d) * 430,
              vy: (dy / d) * 430,
              radius: 6,
              fromPlayer: false,
              damage: 1,
              life: 2.2,
              color: '#f43f5e',
            });
          }
        }
      } else if (e.kind === 'dash_stalker') {
        const dx = pcx - (e.x + e.w / 2);
        const dy = Math.abs(pcy - (e.y + e.h / 2));
        if (e.aiPhase === 'patrol') {
          e.x += e.vx * dt;
          if (e.x <= e.patrolMinX) {
            e.x = e.patrolMinX;
            e.vx = Math.abs(e.vx);
            e.facing = 1;
          } else if (e.x + e.w >= e.patrolMaxX) {
            e.x = e.patrolMaxX - e.w;
            e.vx = -Math.abs(e.vx);
            e.facing = -1;
          }
          e.stateTimer -= dt;
          if (Math.abs(dx) < 340 && dy < 75 && e.stateTimer <= 0) {
            e.aiPhase = 'telegraph';
            e.facing = dx >= 0 ? 1 : -1;
            e.telegraphTimer = 0.42;
            e.stateTimer = 0.42;
          }
        } else if (e.aiPhase === 'telegraph') {
          e.stateTimer -= dt;
          e.telegraphTimer = Math.max(0, e.stateTimer);
          if (e.stateTimer <= 0) {
            e.aiPhase = 'lunge';
            e.stateTimer = 0.34;
            e.vx = e.facing * 470;
          }
        } else if (e.aiPhase === 'lunge') {
          e.stateTimer -= dt;
          e.x += e.vx * dt;
          e.x = Math.max(e.patrolMinX, Math.min(e.patrolMaxX - e.w, e.x));
          if (Math.random() < 0.5) {
            this.afterimages.push({
              x: e.x,
              y: e.y,
              w: e.w,
              h: e.h,
              facing: e.facing,
              alpha: 0.45,
              color: '#e879f9',
            });
          }
          if (e.stateTimer <= 0) {
            e.aiPhase = 'patrol';
            e.stateTimer = 1.25;
            e.vx = e.facing * 115;
          }
        }
      } else if (e.kind === 'plasma_orbiter') {
        e.x += e.vx * dt;
        e.y = e.spawnY + Math.sin(performance.now() * 0.004 + e.spawnX) * 18;
        if (e.x <= e.patrolMinX) {
          e.vx = Math.abs(e.vx);
        } else if (e.x + e.w >= e.patrolMaxX) {
          e.vx = -Math.abs(e.vx);
        }
        e.facing = pcx < e.x + e.w / 2 ? -1 : 1;
        const dist = Math.hypot(pcx - (e.x + e.w / 2), pcy - (e.y + e.h / 2));
        if (dist < 560) {
          e.stateTimer -= dt;
          if (e.stateTimer <= 0.45 && e.stateTimer > 0) {
            e.telegraphTimer = e.stateTimer;
          }
          if (e.stateTimer <= 0) {
            e.stateTimer = 2.0;
            e.telegraphTimer = 0;
            const ex = e.x + e.w / 2;
            const ey = e.y + e.h / 2;
            const base = Math.atan2(pcy - ey, pcx - ex);
            for (const spread of [-0.14, 0.14]) {
              const ang = base + spread;
              this.projectiles.push({
                x: ex,
                y: ey,
                vx: Math.cos(ang) * 380,
                vy: Math.sin(ang) * 380,
                radius: 6,
                fromPlayer: false,
                damage: 1,
                life: 2.4,
                color: '#38bdf8',
              });
            }
          }
        }
      } else if (e.kind === 'shield_warden') {
        const dx = pcx - (e.x + e.w / 2);
        const dy = Math.abs(pcy - (e.y + e.h / 2));
        if (e.aiPhase === 'patrol') {
          e.x += e.vx * dt;
          if (e.x <= e.patrolMinX) {
            e.x = e.patrolMinX;
            e.vx = Math.abs(e.vx);
            e.facing = 1;
          } else if (e.x + e.w >= e.patrolMaxX) {
            e.x = e.patrolMaxX - e.w;
            e.vx = -Math.abs(e.vx);
            e.facing = -1;
          }
          e.stateTimer -= dt;
          if (Math.abs(dx) < 280 && dy < 70 && e.stateTimer <= 0) {
            e.aiPhase = 'telegraph';
            e.facing = dx >= 0 ? 1 : -1;
            e.telegraphTimer = 0.55;
            e.stateTimer = 0.55;
          }
        } else if (e.aiPhase === 'telegraph') {
          e.stateTimer -= dt;
          e.telegraphTimer = Math.max(0, e.stateTimer);
          if (e.stateTimer <= 0) {
            e.aiPhase = 'charge';
            e.stateTimer = 0.55;
            e.vx = e.facing * 320;
          }
        } else if (e.aiPhase === 'charge') {
          e.stateTimer -= dt;
          e.x += e.vx * dt;
          e.x = Math.max(e.patrolMinX, Math.min(e.patrolMaxX - e.w, e.x));
          if (e.stateTimer <= 0) {
            e.aiPhase = 'recover';
            e.stateTimer = 0.9;
            e.vx = 0;
          }
        } else if (e.aiPhase === 'recover') {
          e.stateTimer -= dt;
          if (e.stateTimer <= 0) {
            e.aiPhase = 'patrol';
            e.stateTimer = 1.2;
            e.vx = e.facing * 68;
          }
        }
      } else if (this.isBossEnemy(e) && this.activeBossId === e.id) {
        this.updateBossUnified(e, dt, pcx, pcy);
      }

      // Contact damage (pogo_mine safe to bounce on)
      if (e.kind !== 'pogo_mine' && this.rectsOverlap(pRect, e)) {
        const kDir = pcx < e.x + e.w / 2 ? -1 : 1;
        this.takeDamage(1, kDir * 310, -300);
      }
    }
  }

  private updateBossUnified(b: Enemy, dt: number, pcx: number, pcy: number): void {
    const cfg = this.getBossConfig(b.kind);

    if (!b.phase2 && b.hp <= b.maxHp * 0.5) {
      b.phase2 = true;
      b.vx = 0;
      b.vy = 0;
      b.aiPhase = 'rest_vent';
      b.stateTimer = 2.4;
      b.telegraphTimer = 0;
      this.shakeIntensity = 12;
      this.spawnBurst(b.x + b.w / 2, b.y + b.h / 2, cfg.color, 30, 320);
      this.showBanner(`${cfg.name} // THERMAL STAGGER`, 'Core Overheating — Heal or Strike!', 2.6);
      this.callouts.push({
        x: b.x + b.w / 2,
        y: b.y - 18,
        vy: -24,
        text: 'SYSTEM VENTING · REST WINDOW',
        color: '#22d3ee',
        life: 1.8,
        maxLife: 1.8,
      });
      return;
    }

    const speedMul = b.phase2 ? 1.24 : 1;
    b.stateTimer -= dt;

    if (b.aiPhase === 'rest_vent') {
      b.y += (cfg.groundY - b.y) * Math.min(1, dt * 6);
      b.vx = 0;
      if (Math.random() < 0.45) {
        this.spawnParticle(
          b.x + b.w / 2 + (Math.random() - 0.5) * 34,
          b.y + 14,
          (Math.random() - 0.5) * 36,
          -75 - Math.random() * 55,
          '#67e8f9',
          3.2,
          0.48,
          -40
        );
      }
      if (b.stateTimer <= 0) {
        b.aiPhase = 'idle';
        b.stateTimer = 0.65;
      }
      return;
    }

    const finishBossAttack = (normalCooldown: number) => {
      this.bossAttackCount += 1;
      const restEvery = b.kind === 'boss_nexus' ? 3 : 2;
      if (this.bossAttackCount % restEvery === 0) {
        b.aiPhase = 'rest_vent';
        b.stateTimer = 2.2;
        this.callouts.push({
          x: b.x + b.w / 2,
          y: b.y - 18,
          vy: -22,
          text: 'VENTING · REST WINDOW',
          color: '#22d3ee',
          life: 1.6,
          maxLife: 1.6,
        });
      } else {
        b.aiPhase = 'idle';
        b.stateTimer = normalCooldown;
      }
    };

    if (b.aiPhase === 'idle') {
      b.facing = pcx < b.x + b.w / 2 ? -1 : 1;
      b.y += (cfg.groundY - b.y) * Math.min(1, dt * 6);
      if (b.stateTimer <= 0) {
        const roll = Math.random();
        if (roll < 0.42) {
          b.aiPhase = 'telegraph_dash';
          b.telegraphTimer = 0.58 / speedMul;
          b.stateTimer = b.telegraphTimer;
          b.facing = pcx < b.x + b.w / 2 ? -1 : 1;
        } else if (roll < 0.74) {
          b.aiPhase = 'telegraph_barrage';
          b.telegraphTimer = 0.56 / speedMul;
          b.stateTimer = b.telegraphTimer;
        } else {
          b.aiPhase = 'telegraph_slam';
          b.telegraphTimer = 0.6 / speedMul;
          b.stateTimer = b.telegraphTimer;
          b.targetX = Math.max(cfg.arenaMinX + 60, Math.min(cfg.arenaMaxX - b.w - 60, pcx - b.w / 2));
        }
      }
    } else if (b.aiPhase === 'telegraph_dash') {
      b.telegraphTimer = Math.max(0, b.stateTimer);
      if (b.stateTimer <= 0) {
        b.aiPhase = 'dash';
        b.stateTimer = b.kind === 'boss_vortex' ? 0.58 : 0.5;
        b.vx = b.facing * cfg.dashSpeed * speedMul;
        soundEngine.playDash();
      }
    } else if (b.aiPhase === 'dash') {
      b.x += b.vx * dt;
      this.afterimages.push({
        x: b.x,
        y: b.y,
        w: b.w,
        h: b.h,
        facing: b.facing,
        alpha: 0.55,
        color: cfg.color,
      });
      if (b.x <= b.patrolMinX) {
        b.x = b.patrolMinX;
        b.stateTimer = 0;
      } else if (b.x + b.w >= b.patrolMaxX) {
        b.x = b.patrolMaxX - b.w;
        b.stateTimer = 0;
      }
      if (b.stateTimer <= 0) {
        b.vx = 0;
        // Vortex & Nexus chain a quick second blink-slash dash in Phase 2!
        if ((b.kind === 'boss_vortex' || b.kind === 'boss_nexus') && b.phase2 && !b.targetY) {
          b.targetY = 1;
          b.facing = pcx < b.x + b.w / 2 ? -1 : 1;
          b.aiPhase = 'telegraph_dash';
          b.telegraphTimer = 0.32;
          b.stateTimer = 0.32;
        } else {
          b.targetY = 0;
          finishBossAttack(0.95 / speedMul);
        }
      }
    } else if (b.aiPhase === 'telegraph_barrage') {
      b.y += (cfg.hoverY - b.y) * Math.min(1, dt * 6);
      b.telegraphTimer = Math.max(0, b.stateTimer);
      if (b.stateTimer <= 0) {
        const count = cfg.barrageCount + (b.phase2 ? 2 : 0);
        const bx = b.x + b.w / 2;
        const by = b.y + 32;
        const baseAngle = Math.atan2(pcy - by, pcx - bx);
        for (let i = 0; i < count; i++) {
          const offset = (i - (count - 1) / 2) * 0.24;
          const ang = baseAngle + offset;
          this.projectiles.push({
            x: bx,
            y: by,
            vx: Math.cos(ang) * 430 * speedMul,
            vy: Math.sin(ang) * 430 * speedMul,
            radius: 8,
            fromPlayer: false,
            damage: 1,
            life: 2.6,
            color: cfg.color,
          });
        }
        soundEngine.playBossWarning();
        finishBossAttack(1.05 / speedMul);
      }
    } else if (b.aiPhase === 'telegraph_slam') {
      b.x += ((b.targetX ?? b.x) - b.x) * Math.min(1, dt * 8);
      b.y += (cfg.hoverY - 50 - b.y) * Math.min(1, dt * 8);
      b.telegraphTimer = Math.max(0, b.stateTimer);
      if (b.stateTimer <= 0) {
        b.aiPhase = 'slam_drop';
        b.vy = cfg.slamSpeed;
      }
    } else if (b.aiPhase === 'slam_drop') {
      b.y += b.vy * dt;
      if (b.y >= cfg.groundY) {
        b.y = cfg.groundY;
        b.vy = 0;
        this.shakeIntensity = 12;
        soundEngine.playHit(true);
        const cx = b.x + b.w / 2;
        const waveY = cfg.floorY - 20;
        this.spawnBurst(cx, cfg.floorY, cfg.color, 26, 290);
        this.projectiles.push(
          {
            x: cx - 20,
            y: waveY,
            vx: -460 * speedMul,
            vy: 0,
            radius: 13,
            fromPlayer: false,
            damage: 1,
            life: 2.1,
            color: cfg.color,
          },
          {
            x: cx + 20,
            y: waveY,
            vx: 460 * speedMul,
            vy: 0,
            radius: 13,
            fromPlayer: false,
            damage: 1,
            life: 2.1,
            color: cfg.color,
          }
        );
        // Glacier-Omega & Nexus-Prime also launch an angled frost/plasma arc on slam!
        if (b.kind === 'boss_glacier' || b.kind === 'boss_nexus') {
          this.projectiles.push(
            {
              x: cx,
              y: waveY - 12,
              vx: -260 * speedMul,
              vy: -310,
              radius: 9,
              fromPlayer: false,
              damage: 1,
              life: 1.9,
              color: '#38bdf8',
            },
            {
              x: cx,
              y: waveY - 12,
              vx: 260 * speedMul,
              vy: -310,
              radius: 9,
              fromPlayer: false,
              damage: 1,
              life: 1.9,
              color: '#38bdf8',
            }
          );
        }
        finishBossAttack(1.0 / speedMul);
      }
    }
  }

  private updateProjectiles(dt: number): void {
    const pRect: Rect = { x: this.px + 2, y: this.py + 2, w: this.pw - 4, h: this.ph - 4 };

    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;
      pr.life -= dt;

      if (pr.life <= 0) {
        this.projectiles.splice(i, 1);
        continue;
      }

      const prRect: Rect = {
        x: pr.x - pr.radius,
        y: pr.y - pr.radius,
        w: pr.radius * 2,
        h: pr.radius * 2,
      };

      if (pr.fromPlayer) {
        for (const e of this.world.enemies) {
          if (!e.alive || e.kind === 'pogo_mine') continue;
          if (this.rectsOverlap(prRect, e)) {
            this.damageEnemy(e, pr.damage, pr.vx >= 0 ? 'right' : 'left');
            if (!pr.piercing) {
              pr.life = 0;
              break;
            }
          }
        }
      } else {
        if (this.dashTimer <= 0 && this.rectsOverlap(prRect, pRect)) {
          const kDir = pr.vx >= 0 ? 1 : -1;
          this.takeDamage(pr.damage, kDir * 260, -240);
          this.projectiles.splice(i, 1);
          continue;
        }
      }

      // Hit solid walls
      if (!pr.piercing) {
        for (const plat of this.world.platforms) {
          if (plat.kind !== 'oneway' && this.rectsOverlap(prRect, plat)) {
            this.spawnBurst(pr.x, pr.y, pr.color, 5, 110);
            this.projectiles.splice(i, 1);
            break;
          }
        }
      }
    }
  }

  private updatePickupsAndTerminals(dt: number): void {
    const pRect: Rect = { x: this.px, y: this.py, w: this.pw, h: this.ph };

    for (const item of this.world.pickups) {
      if (item.collected) continue;
      const itemRect: Rect = { x: item.x - 18, y: item.y - 18, w: 36, h: 36 };
      if (this.rectsOverlap(pRect, itemRect)) {
        item.collected = true;
        if (item.kind === 'ability' && item.abilityId) {
          this.abilities.add(item.abilityId);
          soundEngine.playAbilityUnlock();
          this.showBanner(`MODULE ACQUIRED · ${item.label}`, item.description, 4.5);
          this.spawnBurst(item.x, item.y, '#22d3ee', 28, 280);
        } else if (item.kind === 'integrity_cell') {
          this.maxHp += 1;
          this.hp = this.maxHp;
          soundEngine.playAbilityUnlock();
          this.showBanner('INTEGRITY CELL INTEGRATED', item.description, 3.4);
          this.spawnBurst(item.x, item.y, '#10b981', 22, 240);
        } else if (item.kind === 'repair_relay') {
          this.hp = Math.min(this.maxHp, this.hp + 2);
          this.flux = Math.min(100, this.flux + 33);
          soundEngine.playHeal();
          this.spawnBurst(item.x, item.y, '#10b981', 24, 240);
          this.callouts.push({
            x: item.x,
            y: item.y - 16,
            vy: -42,
            text: '+2 INTEGRITY · +33 FLUX',
            color: '#6ee7b7',
            life: 1.1,
            maxLife: 1.1,
          });
        } else {
          this.shards += 25;
          this.flux = Math.min(100, this.flux + 20);
          soundEngine.playPickup();
          this.spawnBurst(item.x, item.y, '#f59e0b', 16, 200);
          this.callouts.push({
            x: item.x,
            y: item.y - 12,
            vy: -45,
            text: '+25 DATA SHARD',
            color: '#f59e0b',
            life: 0.9,
            maxLife: 0.9,
          });
        }
        this.emitHudNow();
      }
    }

    // Uplink Terminals
    this.activePrompt = null;
    for (const term of this.world.terminals) {
      const dist = Math.hypot(this.px + this.pw / 2 - term.x, this.py + this.ph - term.y);
      if (dist < 64) {
        if (!this.activatedTerminals.has(term.id)) {
          this.activatedTerminals.add(term.id);
          this.respawnX = term.x - 12;
          this.respawnY = term.y - 44;
          soundEngine.playTerminal();
          this.callouts.push({
            x: term.x,
            y: term.y - 52,
            vy: -30,
            text: 'UPLINK SYNCED',
            color: '#22d3ee',
            life: 1.1,
            maxLife: 1.1,
          });
        }
        this.activePrompt = `[E] Rest & Restore at ${term.name}`;
        if (this.wasPressed(['KeyE'])) {
          this.respawnX = term.x - 12;
          this.respawnY = term.y - 44;
          this.hp = this.maxHp;
          this.flux = Math.max(this.flux, 50);
          soundEngine.playHeal();
          this.spawnBurst(term.x, term.y - 26, '#22d3ee', 20, 210);
          this.callouts.push({
            x: term.x,
            y: term.y - 54,
            vy: -35,
            text: 'INTEGRITY RESTORED',
            color: '#10b981',
            life: 1.0,
            maxLife: 1.0,
          });
          this.emitHudNow();
        }
        break;
      }
    }
    void dt;
  }

  private updateEffects(dt: number): void {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }

    for (let i = this.afterimages.length - 1; i >= 0; i--) {
      this.afterimages[i].alpha -= dt * 3.8;
      if (this.afterimages[i].alpha <= 0) this.afterimages.splice(i, 1);
    }

    for (let i = this.slashArcs.length - 1; i >= 0; i--) {
      this.slashArcs[i].life -= dt;
      if (this.slashArcs[i].life <= 0) this.slashArcs.splice(i, 1);
    }

    for (let i = this.hitEffects.length - 1; i >= 0; i--) {
      this.hitEffects[i].life -= dt;
      if (this.hitEffects[i].life <= 0) this.hitEffects.splice(i, 1);
    }

    for (let i = this.callouts.length - 1; i >= 0; i--) {
      const c = this.callouts[i];
      c.y += c.vy * dt;
      c.life -= dt;
      if (c.life <= 0) this.callouts.splice(i, 1);
    }
  }

  private updateCamera(dt: number): void {
    const targetX = this.px + this.pw / 2 + this.facing * 75 + this.vx * 0.14;
    const targetY = this.py + this.ph / 2 - 35 + this.vy * 0.06;
    const smooth = 1 - Math.exp(-8.5 * dt);
    this.camX += (targetX - this.camX) * smooth;
    this.camY += (targetY - this.camY) * smooth;
  }

  private spawnParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    color: string,
    size: number,
    life: number,
    gravity: number
  ): void {
    if (this.particles.length > 260) return;
    this.particles.push({ x, y, vx, vy, size, life, maxLife: life, color, gravity });
  }

  private spawnBurst(x: number, y: number, color: string, count: number, speed: number): void {
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = (0.3 + Math.random() * 0.7) * speed;
      this.spawnParticle(
        x,
        y,
        Math.cos(ang) * spd,
        Math.sin(ang) * spd,
        color,
        2 + Math.random() * 3,
        0.24 + Math.random() * 0.28,
        240
      );
    }
  }

  private rectsOverlap(a: Rect, b: Rect): boolean {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  // ===========================================================================
  // RENDERER
  // ===========================================================================
  private render(): void {
    const ctx = this.ctx;
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const vw = cw / dpr;
    const vh = ch / dpr;

    ctx.save();
    ctx.scale(dpr, dpr);

    // Deep obsidian cyber sky gradient
    const sky = ctx.createLinearGradient(0, 0, 0, vh);
    sky.addColorStop(0, '#04060d');
    sky.addColorStop(0.55, '#090e1c');
    sky.addColorStop(1, '#0d1528');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, vw, vh);

    // Parallax Cyberpunk Skyline
    this.renderParallaxSkyline(ctx, vw, vh);

    // Responsive zoom on short horizontal mobile screens so vertical shafts & boss arena stay readable
    const worldScale = Math.max(0.56, Math.min(1, vh / 640));

    // Camera Transform with decaying screen shake
    const sx = (Math.random() - 0.5) * this.shakeIntensity * 2;
    const sy = (Math.random() - 0.5) * this.shakeIntensity * 2;
    ctx.save();
    ctx.translate(vw / 2, vh / 2);
    ctx.scale(worldScale, worldScale);
    ctx.translate(-this.camX + sx, -this.camY + sy);

    this.renderPlatforms(ctx);
    this.renderSpeedRails(ctx);
    this.renderGrappleNodes(ctx);
    this.renderTerminals(ctx);
    this.renderHazards(ctx);
    this.renderPickups(ctx);
    this.renderBossContainment(ctx);
    this.renderEnemies(ctx);
    this.renderAfterimages(ctx);
    this.renderPlayer(ctx);
    this.renderSlashArcs(ctx);
    this.renderHitEffects(ctx);
    this.renderProjectiles(ctx);
    this.renderParticles(ctx);
    this.renderCallouts(ctx);

    ctx.restore();

    // Screen-space atmospheric rain
    this.renderRain(ctx, vw, vh);
    ctx.restore();
  }

  private renderParallaxSkyline(ctx: CanvasRenderingContext2D, vw: number, vh: number): void {
    const time = performance.now() * 0.001;
    for (const layer of [0, 1] as const) {
      const parallax = layer === 0 ? 0.12 : 0.24;
      const offset = -((this.camX * parallax) % 2400);
      for (const b of this.buildings) {
        if (b.layer !== layer) continue;
        const bx = ((b.x + offset + 3600) % 2600) - 300;
        if (bx > vw + 150 || bx + b.w < -150) continue;
        const by = vh - b.h * (layer === 0 ? 0.92 : 0.72);
        ctx.fillStyle = layer === 0 ? '#070b16' : '#0a1020';
        ctx.fillRect(bx, by, b.w, vh - by);

        // Subtle vertical neon edge strip
        ctx.fillStyle = b.accent;
        ctx.globalAlpha = layer === 0 ? 0.12 : 0.2;
        ctx.fillRect(bx, by, 2, Math.min(120, b.h * 0.45));
        ctx.globalAlpha = 1;

        // Occasional glowing window dots
        if (layer === 1) {
          ctx.fillStyle = b.accent;
          ctx.globalAlpha = 0.2 + Math.sin(time * 2 + b.x) * 0.06;
          for (let wi = 0; wi < 6; wi++) {
            if (b.windows[wi]) {
              ctx.fillRect(bx + 12 + (wi % 2) * 22, by + 24 + wi * 28, 8, 4);
            }
          }
          ctx.globalAlpha = 1;
        }
      }
    }
  }

  private renderPlatforms(ctx: CanvasRenderingContext2D): void {
    const accentColors: Record<string, string> = {
      cyan: '#22d3ee',
      magenta: '#e879f9',
      amber: '#f59e0b',
      emerald: '#10b981',
    };

    for (const p of this.getActivePlatforms()) {
      const col = accentColors[p.accent || 'cyan'];

      if (p.kind === 'oneway') {
        ctx.fillStyle = this.catwalkPattern || '#11192e';
        ctx.fillRect(p.x, p.y, p.w, p.h);

        // Industrial truss underside & rivets
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.lineWidth = 2;
        ctx.strokeRect(p.x + 1, p.y + 1, p.w - 2, p.h - 2);

        ctx.fillStyle = col;
        ctx.fillRect(p.x, p.y, p.w, 3);
        ctx.fillStyle = 'rgba(255,255,255,0.16)';
        for (let gx = p.x + 14; gx < p.x + p.w - 14; gx += 32) {
          ctx.fillRect(gx, p.y + 7, 10, 3);
        }
        continue;
      }

      // Sector-textured Solid or Neon Wall (preserving exact cached CanvasPatterns across all 9 sectors)
      if (p.kind === 'neon_wall') {
        ctx.fillStyle = this.neonWallPattern || '#131830';
      } else if (p.sector === 'cryo_foundry' || p.sector === 'cryo_abyss') {
        ctx.fillStyle = this.foundryPattern || '#0a161b';
      } else if (
        p.sector === 'black_spire' ||
        p.sector === 'data_vault' ||
        p.sector === 'void_foundry' ||
        p.sector === 'zenith_apex'
      ) {
        ctx.fillStyle = this.spirePattern || '#110d20';
      } else {
        ctx.fillStyle = this.solidPattern || '#0c1222';
      }
      ctx.fillRect(p.x, p.y, p.w, p.h);

      // Subtle architectural bevel & shadow
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.14)';
      ctx.lineWidth = 1;
      ctx.strokeRect(p.x + 0.5, p.y + 0.5, p.w - 1, p.h - 1);

      // Top / edge neon trim & subtle caution stripe on thick ledges
      ctx.fillStyle = col;
      ctx.globalAlpha = p.kind === 'neon_wall' ? 0.9 : 0.65;
      if (p.kind === 'neon_wall') {
        ctx.fillRect(p.x, p.y, 3, p.h);
        ctx.fillRect(p.x + p.w - 3, p.y, 3, p.h);
      } else {
        ctx.fillRect(p.x, p.y, p.w, 3);
        if (p.h >= 30) {
          ctx.globalAlpha = 0.25;
          ctx.fillStyle = '#020617';
          ctx.fillRect(p.x, p.y + p.h - 6, p.w, 6);
        }
      }
      ctx.globalAlpha = 1;
    }
  }

  private renderSpeedRails(ctx: CanvasRenderingContext2D): void {
    const t = performance.now() * 0.008;
    for (const r of this.world.rails) {
      const col = r.color === 'amber' ? '#f59e0b' : '#22d3ee';
      ctx.save();
      // Support stanchions under rail endpoints
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(r.x1 - 3, r.y1, 6, 18);
      ctx.fillRect(r.x2 - 3, r.y2, 6, 18);

      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 9;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(r.x1, r.y1);
      ctx.lineTo(r.x2, r.y2);
      ctx.stroke();

      ctx.strokeStyle = col;
      ctx.lineWidth = 4.5;
      ctx.shadowColor = col;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.moveTo(r.x1, r.y1);
      ctx.lineTo(r.x2, r.y2);
      ctx.stroke();

      // Moving energy chevron pulse
      const pulse = t % 1;
      const px = r.x1 + (r.x2 - r.x1) * pulse;
      const py = r.y1 + (r.y2 - r.y1) * pulse;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderGrappleNodes(ctx: CanvasRenderingContext2D): void {
    const time = performance.now() * 0.004;
    for (const n of this.world.grappleNodes) {
      const isLocked = this.grappleTarget?.id === n.id;
      ctx.save();
      ctx.translate(n.x, n.y);

      // Anchor mount plate
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, n.radius + 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Outer pulse ring
      ctx.strokeStyle = isLocked ? '#22d3ee' : 'rgba(56, 189, 248, 0.5)';
      ctx.lineWidth = isLocked ? 2.5 : 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, n.radius + (isLocked ? 6 + Math.sin(time * 2) * 2 : 2), 0, Math.PI * 2);
      ctx.stroke();

      // Rotating diamond core
      ctx.rotate(time * (isLocked ? 1.8 : 0.6));
      ctx.fillStyle = isLocked ? '#ffffff' : '#38bdf8';
      ctx.fillRect(-5, -5, 10, 10);

      if (isLocked) {
        ctx.rotate(Math.PI / 4);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2;
        ctx.strokeRect(-14, -14, 28, 28);
      }
      ctx.restore();
    }

    // Active Tether Cable
    if (this.isGrappling && this.grappleTarget) {
      ctx.save();
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#22d3ee';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(this.px + this.pw / 2, this.py + 14);
      ctx.lineTo(this.grappleTarget.x, this.grappleTarget.y);
      ctx.stroke();
      ctx.restore();
    }
  }

  private renderTerminals(ctx: CanvasRenderingContext2D): void {
    const pulse = 0.7 + Math.sin(performance.now() * 0.005) * 0.3;
    for (const term of this.world.terminals) {
      const active = this.activatedTerminals.has(term.id);
      ctx.save();
      // Textured base pedestal
      ctx.fillStyle = this.hazardStripePattern || '#1e293b';
      ctx.fillRect(term.x - 22, term.y - 10, 44, 10);
      ctx.strokeStyle = active ? '#22d3ee' : '#475569';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(term.x - 22, term.y - 10, 44, 10);

      // Hologram pylon & side ribs
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(term.x - 6, term.y - 54, 12, 44);
      ctx.fillStyle = active ? '#22d3ee' : '#64748b';
      ctx.fillRect(term.x - 2, term.y - 52, 4, 42);

      // Glowing diamond beacon
      ctx.globalAlpha = pulse;
      ctx.fillStyle = active ? '#22d3ee' : '#94a3b8';
      ctx.beginPath();
      ctx.moveTo(term.x, term.y - 74);
      ctx.lineTo(term.x + 12, term.y - 58);
      ctx.lineTo(term.x, term.y - 42);
      ctx.lineTo(term.x - 12, term.y - 58);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  private renderHazards(ctx: CanvasRenderingContext2D): void {
    const time = performance.now() * 0.004;
    const flicker = 0.75 + Math.sin(time * 5) * 0.25;
    for (const h of this.world.hazards) {
      if (h.kind === 'laser') {
        ctx.save();
        // Emitter bracket caps
        ctx.fillStyle = this.hazardStripePattern || '#334155';
        ctx.fillRect(h.x - 2, h.y - 4, h.w + 4, 6);
        ctx.fillRect(h.x - 2, h.y + h.h - 2, h.w + 4, 6);

        ctx.globalAlpha = flicker;
        ctx.fillStyle = '#f43f5e';
        ctx.shadowColor = '#f43f5e';
        ctx.shadowBlur = 14;
        ctx.fillRect(h.x, h.y, h.w, h.h);
        ctx.fillStyle = '#ffe4e6';
        ctx.fillRect(h.x + h.w * 0.3, h.y, h.w * 0.4, h.h);
        ctx.restore();
      } else if (h.kind === 'spikes') {
        ctx.save();
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(h.x, h.y + h.h - 4, h.w, 4);
        const toothW = 14;
        for (let sx = h.x; sx < h.x + h.w - 4; sx += toothW) {
          ctx.fillStyle = '#b45309';
          ctx.beginPath();
          ctx.moveTo(sx, h.y + h.h);
          ctx.lineTo(sx + toothW / 2, h.y);
          ctx.lineTo(sx + toothW, h.y + h.h);
          ctx.closePath();
          ctx.fill();

          ctx.fillStyle = '#fbbf24';
          ctx.beginPath();
          ctx.moveTo(sx + 2, h.y + h.h);
          ctx.lineTo(sx + toothW / 2, h.y + 2);
          ctx.lineTo(sx + toothW / 2 + 2, h.y + h.h);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      } else if (h.kind === 'acid') {
        ctx.save();
        const grad = ctx.createLinearGradient(0, h.y, 0, h.y + h.h);
        grad.addColorStop(0, 'rgba(16, 185, 129, 0.85)');
        grad.addColorStop(1, 'rgba(6, 78, 59, 0.95)');
        ctx.fillStyle = grad;
        ctx.fillRect(h.x, h.y, h.w, h.h);
        ctx.fillStyle = '#6ee7b7';
        ctx.fillRect(h.x, h.y, h.w, 3);
        // Animated coolant bubbles
        ctx.fillStyle = 'rgba(167, 243, 208, 0.45)';
        for (let bx = h.x + 28; bx < h.x + h.w - 20; bx += 68) {
          const offset = ((time * 24 + bx) % 18);
          ctx.beginPath();
          ctx.arc(bx, h.y + h.h - 4 - offset, 3, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }
    }
  }

  private renderPickups(ctx: CanvasRenderingContext2D): void {
    const t = performance.now() * 0.004;
    for (const item of this.world.pickups) {
      if (item.collected) continue;
      const bob = Math.sin(t + item.x * 0.01) * 5;
      const color =
        item.kind === 'ability'
          ? '#22d3ee'
          : item.kind === 'integrity_cell' || item.kind === 'repair_relay'
          ? '#10b981'
          : '#f59e0b';

      ctx.save();
      ctx.translate(item.x, item.y + bob);
      ctx.shadowColor = color;
      ctx.shadowBlur = item.kind === 'ability' || item.kind === 'repair_relay' ? 18 : 10;

      if (item.kind === 'ability') {
        ctx.rotate(t * 0.5);
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        ctx.strokeRect(-14, -14, 28, 28);
        ctx.rotate(Math.PI / 4);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-7, -7, 14, 14);
      } else if (item.kind === 'integrity_cell' || item.kind === 'repair_relay') {
        // Hexagonal or circular Repair / Integrity capsule
        ctx.strokeStyle = '#6ee7b7';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, item.kind === 'repair_relay' ? 14 : 11, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(6, 78, 59, 0.85)';
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#34d399';
        ctx.fillRect(-2.5, -7, 5, 14);
        ctx.fillRect(-7, -2.5, 14, 5);
      } else {
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(0, -10);
        ctx.lineTo(8, 0);
        ctx.lineTo(0, 10);
        ctx.lineTo(-8, 0);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }
  }

  private renderBossContainment(ctx: CanvasRenderingContext2D): void {
    if (!this.activeBossId) return;
    const boss = this.world.enemies.find((e) => e.id === this.activeBossId && e.alive);
    if (!boss) return;
    const cfg = this.getBossConfig(boss.kind);
    ctx.save();
    ctx.fillStyle = cfg.color;
    ctx.globalAlpha = 0.35;
    ctx.fillRect(cfg.arenaMinX - 8, cfg.topY, 8, cfg.floorY - cfg.topY);
    ctx.fillRect(cfg.arenaMaxX, cfg.topY, 8, cfg.floorY - cfg.topY);
    ctx.restore();
  }

  private renderEnemies(ctx: CanvasRenderingContext2D): void {
    const t = performance.now() * 0.005;
    for (const e of this.world.enemies) {
      if (!e.alive) continue;
      const flash = e.hitFlashTimer > 0;
      ctx.save();

      if (e.kind === 'pogo_mine') {
        const cx = e.x + e.w / 2;
        const cy = e.y + e.h / 2;
        ctx.translate(cx, cy);
        ctx.rotate(t * 0.6);
        ctx.fillStyle = flash ? '#ffffff' : '#1e293b';
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        // Bumper prongs
        ctx.fillStyle = '#f59e0b';
        for (let k = 0; k < 4; k++) {
          ctx.rotate(Math.PI / 2);
          ctx.fillRect(-2, -17, 4, 5);
        }
        ctx.fillStyle = flash ? '#ffffff' : '#fbbf24';
        ctx.fillRect(-5, -5, 10, 10);
        ctx.restore();
        continue;
      }

      if (this.isBossEnemy(e)) {
        const cfg = this.getBossConfig(e.kind);
        const isVenting = e.aiPhase === 'rest_vent';
        if (e.telegraphTimer > 0) {
          ctx.strokeStyle = cfg.color;
          ctx.lineWidth = 3;
          ctx.strokeRect(e.x - 6, e.y - 6, e.w + 12, e.h + 12);
          if (e.aiPhase === 'telegraph_dash') {
            ctx.fillStyle = cfg.color;
            ctx.globalAlpha = 0.22;
            const lineX = e.facing === 1 ? e.x + e.w : e.x - 420;
            ctx.fillRect(lineX, e.y + e.h * 0.35, 420, 20);
            ctx.globalAlpha = 1;
          }
        }

        // Phase 2 overdrive wing fins / shoulder horns
        if (e.phase2) {
          ctx.fillStyle = isVenting ? 'rgba(34, 211, 238, 0.35)' : cfg.color;
          ctx.globalAlpha = isVenting ? 1 : 0.4;
          ctx.beginPath();
          ctx.moveTo(e.x + e.w / 2, e.y + 30);
          ctx.lineTo(e.x - 32, e.y + 4);
          ctx.lineTo(e.x - 16, e.y + 54);
          ctx.closePath();
          ctx.fill();
          ctx.beginPath();
          ctx.moveTo(e.x + e.w / 2, e.y + 30);
          ctx.lineTo(e.x + e.w + 32, e.y + 4);
          ctx.lineTo(e.x + e.w + 16, e.y + 54);
          ctx.closePath();
          ctx.fill();
          ctx.globalAlpha = 1;
        }

        // Layered Mech Chassis & Shoulder Pauldrons
        const crouchOffset = isVenting ? 10 : 0;
        const bodyColor =
          e.kind === 'boss_glacier'
            ? '#082f49'
            : e.kind === 'boss_vortex'
            ? '#2e1065'
            : e.kind === 'boss_nexus'
            ? '#2a1805'
            : '#16133a';
        ctx.fillStyle = flash ? '#ffffff' : e.phase2 ? '#3b0718' : bodyColor;
        ctx.fillRect(e.x, e.y + crouchOffset, e.w, e.h - crouchOffset);
        ctx.strokeStyle = isVenting ? '#22d3ee' : cfg.color;
        ctx.lineWidth = 2.8;
        ctx.strokeRect(e.x, e.y + crouchOffset, e.w, e.h - crouchOffset);

        // Armor plating seams & heavy pauldrons
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(e.x - 7, e.y + 12 + crouchOffset, 11, 28);
        ctx.fillRect(e.x + e.w - 4, e.y + 12 + crouchOffset, 11, 28);
        ctx.fillStyle = isVenting ? '#22d3ee' : cfg.color;
        ctx.fillRect(e.x + e.w / 2 - 8, e.y + 42 + crouchOffset, 16, 16);

        // Glowing Boss Visor
        ctx.fillStyle = isVenting ? '#67e8f9' : '#ffffff';
        const visorX = e.facing === 1 ? e.x + e.w - 26 : e.x + 6;
        ctx.fillRect(visorX, e.y + 18 + crouchOffset, 20, 7);

        if (isVenting) {
          ctx.font = '700 10px "Chakra Petch", sans-serif';
          ctx.textAlign = 'center';
          ctx.fillStyle = '#67e8f9';
          ctx.fillText('VENTING · REST', e.x + e.w / 2, e.y - 10);
        }
        ctx.restore();
        continue;
      }

      // Standard & New Enemies (patrol_bot, hover_sentinel, sniper_turret, dash_stalker, plasma_orbiter, shield_warden)
      const bgMap: Record<string, string> = {
        hover_sentinel: '#2e1065',
        sniper_turret: '#3f1d2b',
        dash_stalker: '#1f0b2e',
        plasma_orbiter: '#0b2545',
        shield_warden: '#0f2922',
        patrol_bot: '#1e293b',
      };
      const strokeMap: Record<string, string> = {
        hover_sentinel: '#e879f9',
        sniper_turret: '#f43f5e',
        dash_stalker: '#c084fc',
        plasma_orbiter: '#38bdf8',
        shield_warden: '#34d399',
        patrol_bot: '#e879f9',
      };

      ctx.fillStyle = flash ? '#ffffff' : bgMap[e.kind] || '#1e293b';
      ctx.fillRect(e.x, e.y, e.w, e.h);
      ctx.strokeStyle = strokeMap[e.kind] || '#e879f9';
      ctx.lineWidth = 2;
      ctx.strokeRect(e.x, e.y, e.w, e.h);

      // Mechanical panel seam & unit-specific silhouette hardware
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.fillRect(e.x + 3, e.y + e.h * 0.55, e.w - 6, 3);
      if (e.kind === 'hover_sentinel' || e.kind === 'plasma_orbiter') {
        ctx.fillStyle = e.kind === 'plasma_orbiter' ? '#38bdf8' : '#22d3ee';
        ctx.fillRect(e.x - 5, e.y + 4, 5, 10);
        ctx.fillRect(e.x + e.w, e.y + 4, 5, 10);
      } else if (e.kind === 'sniper_turret') {
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(e.facing === 1 ? e.x + e.w : e.x - 12, e.y + 10, 12, 5);
      } else if (e.kind === 'dash_stalker') {
        // Dual cyber-fangs / lunge blade
        ctx.fillStyle = '#e879f9';
        const bx = e.facing === 1 ? e.x + e.w : e.x - 10;
        ctx.fillRect(bx, e.y + 18, 10, 4);
      } else if (e.kind === 'shield_warden') {
        // Front Energy Riot Shield (blocks frontal slashes unless flanked or pogoed)
        ctx.fillStyle = e.aiPhase === 'recover' ? 'rgba(52, 211, 153, 0.25)' : '#38bdf8';
        const sx = e.facing === 1 ? e.x + e.w + 2 : e.x - 7;
        ctx.fillRect(sx, e.y + 2, 5, e.h - 4);
      }

      // Eye visor
      ctx.fillStyle = e.telegraphTimer > 0 ? '#ffffff' : '#f43f5e';
      const eyeX = e.facing === 1 ? e.x + e.w - 11 : e.x + 3;
      ctx.fillRect(eyeX, e.y + 8, 8, 5);

      // Small enemy HP pips
      if (e.hp < e.maxHp) {
        const bw = e.w;
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(e.x, e.y - 8, bw, 4);
        ctx.fillStyle = '#f43f5e';
        ctx.fillRect(e.x, e.y - 8, bw * (e.hp / e.maxHp), 4);
      }

      ctx.restore();
    }
  }

  private renderAfterimages(ctx: CanvasRenderingContext2D): void {
    for (const a of this.afterimages) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, a.alpha * 0.65);
      ctx.fillStyle = a.color;
      ctx.fillRect(a.x, a.y, a.w, a.h);
      ctx.restore();
    }
  }

  private renderPlayer(ctx: CanvasRenderingContext2D): void {
    // Flicker during invulnerability
    if (this.invulnTimer > 0 && Math.floor(this.invulnTimer * 18) % 2 === 0) {
      return;
    }

    // Tall Crimson-Red Scarf Tail (behind character, Verlet physics)
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (let i = 0; i < this.scarfNodes.length - 1; i++) {
      const a = this.scarfNodes[i];
      const b = this.scarfNodes[i + 1];
      const t = i / (this.scarfNodes.length - 1);
      ctx.strokeStyle = i % 2 === 0 ? '#dc2626' : '#b91c1c';
      ctx.lineWidth = 7.5 - t * 4.2;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    // Subtle top highlight thread along scarf
    ctx.strokeStyle = 'rgba(248, 113, 113, 0.45)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    this.scarfNodes.forEach((n, idx) => {
      if (idx === 0) ctx.moveTo(n.x, n.y - 1.5);
      else ctx.lineTo(n.x, n.y - 1.5);
    });
    ctx.stroke();
    ctx.restore();

    // All-Black Cyber-Shinobi Chassis with Squash & Stretch
    ctx.save();
    const cx = this.px + this.pw / 2;
    const by = this.py + this.ph;
    ctx.translate(cx, by);
    ctx.scale(this.scaleX, this.scaleY);

    // Pure black suit & dark hood silhouette
    ctx.fillStyle = this.dashTimer > 0 ? '#082f49' : '#050508';
    ctx.strokeStyle = this.dashTimer > 0 ? '#00d4ff' : '#27272a';
    ctx.lineWidth = 1.6;
    ctx.fillRect(-this.pw / 2, -this.ph, this.pw, this.ph);
    ctx.strokeRect(-this.pw / 2, -this.ph, this.pw, this.ph);

    // Subtle matte charcoal chest & belt seams (all-black palette)
    ctx.fillStyle = '#0c0c10';
    ctx.fillRect(-this.pw / 2 + 3, -this.ph + 16, this.pw - 6, 11);
    ctx.fillStyle = '#18181b';
    ctx.fillRect(-this.pw / 2 + 2, -13, this.pw - 4, 2);

    // Animated all-black leg stride when running
    const stride =
      this.onGround && Math.abs(this.vx) > 40 ? Math.sin(performance.now() * 0.02) * 3 : 0;
    ctx.fillStyle = '#030305';
    ctx.fillRect(-8 + stride, -9, 6, 9);
    ctx.fillRect(2 - stride, -9, 6, 9);

    // Subtle dark-hood visor slit
    ctx.fillStyle = this.dashTimer > 0 ? '#00e5ff' : '#52525b';
    const vx = this.facing === 1 ? 2 : -10;
    ctx.fillRect(vx, -this.ph + 7, 8, 3);

    // Tall Red Scarf Collar wrapped snugly around neck
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(-this.pw / 2 - 1, -this.ph + 11, this.pw + 2, 6);
    ctx.fillStyle = '#991b1b';
    ctx.fillRect(-this.pw / 2, -this.ph + 15, this.pw, 2.5);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(-this.pw / 2 + 2, -this.ph + 11.5, this.pw - 4, 1.5);

    // Cyber-Katana: either sheathed on back or actively swinging in hand!
    if (this.activeSlashTimer > 0) {
      const progress = 1 - this.activeSlashTimer / this.activeSlashDuration;
      const baseDirAngle: Record<SlashArc['dir'], number> = {
        right: 0,
        down: Math.PI / 2,
        left: Math.PI,
        up: -Math.PI / 2,
      };
      const swingSpan = 2.15;
      const startOff = this.slashSwingFlip ? -swingSpan / 2 : swingSpan / 2;
      const endOff = this.slashSwingFlip ? swingSpan / 2 : -swingSpan / 2;
      const swordAngle = baseDirAngle[this.activeSlashDir] + startOff + (endOff - startOff) * progress;
      const bladeColor = this.abilities.has('overdrive_arc') ? '#f59e0b' : '#22d3ee';

      ctx.save();
      ctx.translate(this.facing * 4, -this.ph * 0.52);
      ctx.rotate(swordAngle);
      // Grip & Tsuba guard
      ctx.fillStyle = '#18181b';
      ctx.fillRect(-6, -2, 10, 4);
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(4, -5, 3, 10);
      // Glowing tapered katana blade
      ctx.shadowColor = bladeColor;
      ctx.shadowBlur = 12;
      ctx.fillStyle = bladeColor;
      ctx.beginPath();
      ctx.moveTo(7, -2.5);
      ctx.lineTo(44, -1);
      ctx.lineTo(48, 0);
      ctx.lineTo(44, 2);
      ctx.lineTo(7, 2.5);
      ctx.closePath();
      ctx.fill();
      // Razor white edge highlight
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(8, -1.2, 37, 1.4);
      ctx.restore();
    } else {
      ctx.strokeStyle = this.abilities.has('overdrive_arc') ? '#f59e0b' : '#52525b';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(-this.facing * 8, -this.ph + 15);
      ctx.lineTo(-this.facing * 16, -this.ph + 4);
      ctx.stroke();
    }

    ctx.restore();
  }

  private renderSlashArcs(ctx: CanvasRenderingContext2D): void {
    for (const s of this.slashArcs) {
      const ratio = s.life / s.maxLife;
      const progress = 1 - ratio;
      ctx.save();
      ctx.translate(s.x, s.y);
      const angleMap: Record<SlashArc['dir'], number> = {
        right: 0,
        down: Math.PI / 2,
        left: Math.PI,
        up: -Math.PI / 2,
      };
      ctx.rotate(angleMap[s.dir]);
      if (s.flip) ctx.scale(1, -1);

      const primary = s.overdrive ? '#f59e0b' : '#00e5ff';
      const outerR = 54 + progress * 6;
      const innerR = 36 + progress * 10;
      const aStart = -1.15;
      const aEnd = 1.15;

      // Tapered crescent blade slash polygon
      ctx.globalAlpha = Math.min(1, ratio * 1.15);
      ctx.shadowColor = primary;
      ctx.shadowBlur = 18;
      ctx.fillStyle = primary;
      ctx.beginPath();
      ctx.arc(8, 0, outerR, aStart, aEnd, false);
      ctx.arc(2, 0, innerR, aEnd, aStart, true);
      ctx.closePath();
      ctx.fill();

      // Razor-sharp white inner blade edge crescent
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(10, 0, outerR - 1, -0.95, 0.95, false);
      ctx.arc(6, 0, outerR - 7 * ratio - 2, 0.95, -0.95, true);
      ctx.closePath();
      ctx.fill();

      // Secondary trailing speed streak
      ctx.strokeStyle = primary;
      ctx.globalAlpha = ratio * 0.55;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(4, 0, outerR + 7, -0.75, 0.75);
      ctx.stroke();

      ctx.restore();
    }
  }

  private renderHitEffects(ctx: CanvasRenderingContext2D): void {
    for (const h of this.hitEffects) {
      const ratio = Math.max(0, h.life / h.maxLife);
      const spread = 1 + (1 - ratio) * 0.45;
      ctx.save();
      ctx.translate(h.x, h.y);
      ctx.rotate(h.angle);
      ctx.globalAlpha = ratio;
      ctx.shadowColor = h.color;
      ctx.shadowBlur = 16;

      // Two crisp crossed diamond katana cut beams
      for (const rot of [0, Math.PI / 2.2]) {
        ctx.save();
        ctx.rotate(rot);
        const len = 34 * spread;
        const thick = 4.2 * ratio;
        ctx.fillStyle = h.color;
        ctx.beginPath();
        ctx.moveTo(-len, 0);
        ctx.lineTo(0, -thick);
        ctx.lineTo(len, 0);
        ctx.lineTo(0, thick);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(-len * 0.72, 0);
        ctx.lineTo(0, -thick * 0.45);
        ctx.lineTo(len * 0.72, 0);
        ctx.lineTo(0, thick * 0.45);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      ctx.restore();
    }
  }

  private renderProjectiles(ctx: CanvasRenderingContext2D): void {
    for (const pr of this.projectiles) {
      ctx.save();
      ctx.fillStyle = pr.color;
      ctx.shadowColor = pr.color;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, pr.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(pr.x, pr.y, pr.radius * 0.45, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  private renderParticles(ctx: CanvasRenderingContext2D): void {
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
      ctx.restore();
    }
  }

  private renderCallouts(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    ctx.font = '700 12px "Chakra Petch", sans-serif';
    ctx.textAlign = 'center';
    for (const c of this.callouts) {
      ctx.globalAlpha = Math.min(1, c.life / c.maxLife);
      ctx.fillStyle = c.color;
      ctx.fillText(c.text, c.x, c.y);
    }
    ctx.restore();
  }

  private renderRain(ctx: CanvasRenderingContext2D, vw: number, vh: number): void {
    ctx.save();
    ctx.strokeStyle = '#7dd3fc';
    ctx.lineWidth = 1;
    for (const r of this.rain) {
      const rx = (r.x / 1600) * vw;
      const ry = (r.y / 960) * vh;
      ctx.globalAlpha = r.alpha;
      ctx.beginPath();
      ctx.moveTo(rx, ry);
      ctx.lineTo(rx - r.len * 0.18, ry + r.len);
      ctx.stroke();
    }
    ctx.restore();
  }
}
