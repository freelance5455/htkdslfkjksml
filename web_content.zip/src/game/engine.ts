/* ============================================================
   MEME SURVIVORS — game engine
   Fixed-timestep canvas platformer-survival roguelite.
   ============================================================ */
import { sprite, spriteDims, renderLevelBG, platformSprite } from './pixel';
import { AudioEngine } from './audio';
import { WEAPONS, ENEMIES, BOSSES, LEVELS, rollUpgrades, rollWeaponChoices, saveHigh } from './data';
import type { UpgradeDef, ChoiceDef, EnemyDef, BossDef } from './data';

export const W = 960, H = 540, GROUND = 492;
const GRAV = 1850;
const PLATS = [
  { x: 104, y: 388, w: 170 }, { x: 392, y: 312, w: 180 },
  { x: 664, y: 388, w: 170 }, { x: 496, y: 222, w: 150 },
];

export interface Hud {
  hp: number; maxHp: number; shield: number; shieldMax: number;
  xp: number; xpNeed: number; level: number;
  wave: number; stage: number; stageName: string; kills: number;
  weaponId: string; weaponLv: number; score: number; time: number;
  boss: { name: string; hp: number; max: number } | null;
  dashReady: boolean; muted: boolean;
}
export interface EndStats { stage: number; wave: number; kills: number; level: number; time: number; score: number; }
export interface GameHooks {
  hud: (h: Hud) => void;
  levelUp: (opts: UpgradeDef[]) => void;
  weaponChoice: (opts: ChoiceDef[]) => void;
  pause: (paused: boolean) => void;
  gameOver: (s: EndStats) => void;
  win: (s: EndStats) => void;
}

interface Stats {
  dmg: number; rof: number; pspeed: number; shots: number;
  critC: number; critD: number; pierce: number; expl: boolean;
  chain: boolean; ricochet: number; move: number; defT: number;
  regen: number; magnet: number; freeze: number; shieldMax: number;
}
interface PlayerT {
  x: number; y: number; vx: number; vy: number; face: 1 | -1;
  w: number; h: number;
  onGround: boolean; coyote: number; jumpBuf: number; jumpCut: boolean;
  hp: number; maxHp: number; shield: number; shieldT: number; iframes: number;
  level: number; xp: number; xpNeed: number;
  weaponId: string; weaponLv: number; fireCd: number; muzzle: number;
  dashCd: number; dashT: number;
  stats: Stats; taken: Record<string, number>;
  hurtT: number; runT: number; aimX: number; aimY: number;
  trail: { x: number; y: number; t: number }[];
}
interface Ent {
  id: number; def: EnemyDef; x: number; y: number; vx: number; vy: number;
  dir: 1 | -1; hp: number; maxHp: number; touchCd: number; flash: number;
  frozen: number; t: number; baseY: number; shotCd: number; hopT: number;
  shardCd: number; miniboss: boolean; ringT: number; scaleS: number;
}
type BossState = 'enter' | 'move' | 'tele' | 'attack' | 'stun';
interface BossT {
  def: BossDef; x: number; y: number; vx: number; vy: number;
  dir: 1 | -1; hp: number; maxHp: number; touchCd: number; flash: number;
  state: BossState; t: number; atkIdx: number; targetX: number;
  burstN: number; burstT: number; chargeDir: 1 | -1; landing: boolean;
}
interface Bullet {
  x: number; y: number; vx: number; vy: number; dmg: number; r: number;
  life: number; kind: 'p' | 'e'; color: string; pierce: number; bounce: number;
  explR: number; chain: number; homing: boolean; size: number;
  hit: Set<number>; trail: { x: number; y: number }[];
}
interface Orb { x: number; y: number; vx: number; vy: number; val: number; age: number; tier: number; }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; col: string; grav: number; }
interface DmgT { x: number; y: number; val: string; life: number; crit: boolean; }
interface Mine { x: number; y: number; arm: number; lv: number; }
interface TurretT { x: number; y: number; life: number; cd: number; }
interface Ring { x: number; y: number; r: number; life: number; max: number; col: string; }

const uid = (() => { let i = 1; return () => i++; })();

export class Game {
  audio = new AudioEngine();
  private cv: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private hooks: GameHooks;
  private raf = 0; private last = 0; private acc = 0;
  private running = false;
  modal: 'none' | 'pause' | 'levelup' | 'choice' | 'over' | 'win' = 'none';

  /* input */
  private keys = new Set<string>();
  private pointer = { x: W / 2, y: H / 2, down: false };
  private touchIn = { left: false, right: false, jump: false, fire: false, dash: false };
  private jumpHeld = false;

  /* entities */
  p!: PlayerT;
  private enemies: Ent[] = [];
  private boss: BossT | null = null;
  private bullets: Bullet[] = [];
  private orbs: Orb[] = [];
  private parts: Particle[] = [];
  private dmgs: DmgT[] = [];
  private mines: Mine[] = [];
  private turrets: TurretT[] = [];
  private rings: Ring[] = [];
  private drones: { a: number; cd: number }[] = [];
  private orbitA = 0;

  /* run state */
  private stage = 1; private wave = 1;
  private phase: 'banner' | 'spawn' | 'fight' | 'rest' | 'done' = 'banner';
  private phaseT = 0; private queue: string[] = []; private spawnT = 0;
  private kills = 0; private score = 0; private time = 0;
  private trickleT = 0; private pendingLv = 0;
  private bannerTitle = ''; private bannerSub = ''; private bannerT = 0; private bannerDur = 0; private bannerCol = '#ffd23f';
  private shakeT = 0; private hitstop = 0;
  private doneTimer = 0; private dieTimer = 0;
  private lastChoices: ChoiceDef[] = [];
  private hudT = 0;
  private specialT = { mine: 4, turret: 11 };
  private dashPrev = false;
  private flip = false;

  constructor(canvas: HTMLCanvasElement, hooks: GameHooks, vol: { music: number; sfx: number; muted: boolean }) {
    this.cv = canvas; this.hooks = hooks;
    this.ctx = canvas.getContext('2d')!;
    this.audio.musicVol = vol.music; this.audio.sfxVol = vol.sfx; this.audio.muted = vol.muted;
    this.bind();
  }

  /* ================= lifecycle ================= */
  start() {
    this.audio.init();
    this.resetRun();
    this.running = true;
    this.last = performance.now();
    const loop = (t: number) => {
      if (!this.running) return;
      let dt = (t - this.last) / 1000; this.last = t;
      if (dt > 0.25) dt = 0.25;
      if (this.hitstop > 0) { this.hitstop -= dt; this.render(); this.raf = requestAnimationFrame(loop); return; }
      this.acc += dt;
      const step = 1 / 60;
      let n = 0;
      while (this.acc >= step && n < 4) { this.update(step); this.acc -= step; n++; }
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }
  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.unbind();
    this.audio.destroy();
  }
  private resetRun() {
    this.p = {
      x: W * 0.78, y: GROUND, vx: 0, vy: 0, face: -1, onGround: true,
      w: 34, h: 58,
      coyote: 0, jumpBuf: 0, jumpCut: false,
      hp: 100, maxHp: 100, shield: 0, shieldT: 0, iframes: 0,
      level: 1, xp: 0, xpNeed: this.xpNeed(1),
      weaponId: 'blaster', weaponLv: 1, fireCd: 0, muzzle: 0,
      dashCd: 0, dashT: 0,
      stats: { dmg: 1, rof: 1, pspeed: 1, shots: 0, critC: 0.05, critD: 1.6, pierce: 0, expl: false, chain: false, ricochet: 0, move: 1, defT: 1, regen: 0, magnet: 1, freeze: 0, shieldMax: 0 },
      taken: {}, hurtT: 0, runT: 0, aimX: W * 0.5, aimY: GROUND - 40, trail: [],
    };
    this.enemies = []; this.boss = null; this.bullets = []; this.orbs = [];
    this.parts = []; this.dmgs = []; this.mines = []; this.turrets = []; this.rings = []; this.drones = [];
    this.stage = 1; this.wave = 1; this.kills = 0; this.score = 0; this.time = 0;
    this.pendingLv = 0; this.phase = 'banner'; this.phaseT = 2.4;
    this.buildQueue();
    this.banner(`STAGE 1`, LEVELS[0].name, 2.4, '#7ddf64');
    this.audio.setMode('normal');
    this.pushHud(true);
  }

  /* ================= input ================= */
  private onKey = (e: KeyboardEvent) => {
    if (e.repeat) { if (e.code === 'Escape') return; }
    if (['Space', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault();
    if (e.type === 'keydown') {
      this.keys.add(e.code);
      if (e.code === 'Escape') this.togglePause();
    } else this.keys.delete(e.code);
  };
  private onMove = (e: PointerEvent) => {
    const r = this.cv.getBoundingClientRect();
    this.pointer.x = (e.clientX - r.left) / r.width * W;
    this.pointer.y = (e.clientY - r.top) / r.height * H;
  };
  private onDown = (e: PointerEvent) => { this.onMove(e); this.pointer.down = true; this.audio.init(); };
  private onUp = () => { this.pointer.down = false; };
  private onVis = () => { if (document.hidden && this.modal === 'none' && this.running) this.togglePause(); };
  private bind() {
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKey);
    this.cv.addEventListener('pointermove', this.onMove);
    this.cv.addEventListener('pointerdown', this.onDown);
    window.addEventListener('pointerup', this.onUp);
    document.addEventListener('visibilitychange', this.onVis);
  }
  private unbind() {
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKey);
    this.cv.removeEventListener('pointermove', this.onMove);
    this.cv.removeEventListener('pointerdown', this.onDown);
    window.removeEventListener('pointerup', this.onUp);
    document.removeEventListener('visibilitychange', this.onVis);
  }
  setTouch(k: keyof typeof this.touchIn, v: boolean) { this.touchIn[k] = v; if (v) this.audio.init(); }
  togglePause() {
    if (this.modal === 'none') { this.modal = 'pause'; this.hooks.pause(true); this.audio.sfx('click'); }
    else if (this.modal === 'pause') { this.modal = 'none'; this.hooks.pause(false); this.audio.sfx('click'); }
  }
  resume() { if (this.modal === 'pause') { this.modal = 'none'; this.hooks.pause(false); } }

  /* ================= helpers ================= */
  private xpNeed(l: number) { return Math.round(7 + l * 3 + Math.pow(l, 1.55) * 2.1); }
  private lv() { return LEVELS[this.stage - 1]; }
  private banner(t: string, sub: string, dur: number, col = '#ffd23f') {
    this.bannerTitle = t; this.bannerSub = sub; this.bannerT = dur; this.bannerDur = dur; this.bannerCol = col;
  }
  private shake(m: number) { this.shakeT = Math.max(this.shakeT, m); }
  private burst(x: number, y: number, col: string, n: number, spd = 160, grav = 300) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = spd * (0.35 + Math.random() * 0.9);
      this.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 60, life: 0, max: 0.4 + Math.random() * 0.4, size: 2 + Math.random() * 3, col, grav });
    }
  }
  private addDmg(x: number, y: number, val: number, crit: boolean) {
    if (this.dmgs.length > 60) this.dmgs.shift();
    this.dmgs.push({ x: x + (Math.random() - 0.5) * 14, y, val: String(Math.max(1, Math.round(val))), life: 0.8, crit });
  }
  private nearestFoe(x: number, y: number, maxR: number, exclude?: Set<number>): Ent | BossT | null {
    let best: Ent | BossT | null = null, bd = maxR * maxR;
    const consider = (e: Ent | BossT, id: number) => {
      if (exclude && exclude.has(id)) return;
      const h = id === 9999 ? spriteDims((e as BossT).def.sprite).h : this.entH(e as Ent);
      const dx = e.x - x, dy = (e.y - h / 2) - y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = e; }
    };
    for (const e of this.enemies) consider(e, e.id);
    if (this.boss) consider(this.boss, 9999);
    return best;
  }
  private get paused() { return this.modal !== 'none'; }

  /* ================= combat ================= */
  private fire() {
    const p = this.p, w = WEAPONS[p.weaponId], s = p.stats;
    const gx = p.x + p.face * 16, gy = p.y - p.h * 0.62;
    const ang = Math.atan2(p.aimY - gy, p.aimX - gx);
    p.face = Math.cos(ang) >= 0 ? 1 : -1;
    const spd = w.pspeed * s.pspeed;
    const mk = (a: number, dmg: number, opts: Partial<Bullet> = {}) => {
      this.bullets.push({
        x: gx + Math.cos(a) * 10, y: gy + Math.sin(a) * 10,
        vx: Math.cos(a) * spd, vy: Math.sin(a) * spd,
        dmg: dmg * s.dmg * (1 + (p.weaponLv - 1) * 0.18), r: 4, life: 1.4, kind: 'p',
        color: w.color, pierce: s.pierce, bounce: s.ricochet,
        explR: s.expl ? 55 : 0, chain: s.chain ? 1 : 0, homing: false,
        size: 3, hit: new Set(), trail: [], ...opts,
      });
    };
    const multi = s.shots;
    switch (p.weaponId) {
      case 'blaster':
        for (let i = 0; i <= multi; i++) mk(ang + (i - multi / 2) * 0.09, w.dmg, { size: 3.4 });
        break;
      case 'shotgun':
        for (let i = 0; i < 5 + multi; i++) mk(ang + (Math.random() - 0.5) * 0.42, w.dmg, { life: 0.34, size: 2.6, r: 3 });
        break;
      case 'laser':
        for (let i = 0; i <= multi; i++) mk(ang + (i - multi / 2) * 0.05, w.dmg, { pierce: 3 + s.pierce, size: 2.4, life: 0.9 });
        break;
      case 'plasma':
        for (let i = 0; i <= multi; i++) mk(ang + (i - multi / 2) * 0.1, w.dmg, { explR: (s.expl ? 85 : 70), size: 6, r: 7, life: 1.8 });
        break;
      case 'rocket':
        for (let i = 0; i <= multi; i++) mk(ang + (i - multi / 2) * 0.07, w.dmg, { explR: (s.expl ? 105 : 90), size: 5, r: 6, life: 2 });
        break;
      case 'dual': {
        this.flip = !this.flip;
        const off = this.flip ? 4 : -4;
        for (let i = 0; i <= multi; i++) {
          const a = ang + (Math.random() - 0.5) * 0.06 + (i - multi / 2) * 0.08;
          this.bullets.push({
            x: gx + Math.cos(a + Math.PI / 2) * off, y: gy + Math.sin(a + Math.PI / 2) * off,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, dmg: w.dmg * s.dmg, r: 3.4, life: 1.1,
            kind: 'p', color: w.color, pierce: s.pierce, bounce: s.ricochet, explR: s.expl ? 55 : 0,
            chain: s.chain ? 1 : 0, homing: false, size: 2.6, hit: new Set(), trail: [],
          });
        }
        break;
      }
      case 'tesla':
        for (let i = 0; i <= multi; i++) mk(ang + (i - multi / 2) * 0.07, w.dmg, { chain: 2 + (s.chain ? 1 : 0), size: 3, life: 1 });
        break;
      case 'homing':
        for (let i = 0; i <= multi; i++) mk(ang + (i - multi / 2) * 0.3, w.dmg, { homing: true, size: 4, r: 5, life: 2.6 });
        break;
    }
    p.muzzle = 0.06;
    this.audio.sfx(('shoot_' + p.weaponId) as 'shoot_blaster');
    p.fireCd = 1 / (w.rof * s.rof);
  }

  private explode(x: number, y: number, r: number, dmg: number) {
    this.rings.push({ x, y, r: 6, life: 0.32, max: r, col: '#ffd23f' });
    this.burst(x, y, '#ff8a47', 14, 240);
    this.burst(x, y, '#ffd23f', 10, 180);
    this.burst(x, y, '#5a5666', 8, 120);
    this.shake(0.09); this.audio.sfx('explode');
    const hitAoe = (e: Ent | BossT, id: number, h: number) => {
      const dx = e.x - x, dy = (e.y - h / 2) - y;
      if (dx * dx + dy * dy < r * r) this.damageFoe(e, id, dmg, false);
    };
    for (const e of [...this.enemies]) hitAoe(e, e.id, this.entH(e));
    if (this.boss) hitAoe(this.boss, 9999, spriteDims(this.boss.def.sprite).h);
  }

  private damageFoe(t: Ent | BossT, id: number, dmg: number, crit: boolean) {
    const isBoss = id === 9999;
    t.hp -= dmg;
    t.flash = 0.14;
    this.addDmg(t.x, t.y - (isBoss ? spriteDims((t as BossT).def.sprite).h : this.entH(t as Ent)) - 6, dmg, crit);
    if (t.hp <= 0) { isBoss ? this.killBoss() : this.killEnemy(t as Ent); }
    else this.audio.sfx('hit');
  }

  private killEnemy(e: Ent) {
    const i = this.enemies.indexOf(e);
    if (i < 0) return;
    this.enemies.splice(i, 1);
    this.kills++; this.score += e.miniboss ? 250 : 10;
    this.hitstop = Math.max(this.hitstop, e.miniboss ? 0.09 : 0.02);
    this.audio.sfx('kill');
    this.burst(e.x, e.y - this.entH(e) / 2, '#ffffff', 6, 150);
    this.burst(e.x, e.y - this.entH(e) / 2, e.miniboss ? '#ffd23f' : '#7ddf64', 10, 190);
    const v = e.miniboss ? 30 : e.def.xp;
    this.dropOrbs(e.x, e.y - 10, v);
    if (e.miniboss) {
      this.p.hp = Math.min(this.p.maxHp, this.p.hp + this.p.maxHp * 0.3);
      this.audio.sfx('heal'); this.audio.sfx('victory');
      this.banner('MINI-BOSS DOWN!', '+30% HP restored', 1.6, '#4dd0e1');
      this.shake(0.2); this.audio.setMode('normal');
      this.rings.push({ x: e.x, y: e.y - 20, r: 10, life: 0.5, max: 130, col: '#4dd0e1' });
    }
    this.pushHud(true);
  }

  private dropOrbs(x: number, y: number, val: number) {
    const n = Math.min(4, 1 + Math.floor(val / 4));
    for (let i = 0; i < n; i++) {
      const v = Math.ceil(val / n);
      this.orbs.push({
        x: x + (Math.random() - 0.5) * 24, y: y + (Math.random() - 0.5) * 18,
        vx: (Math.random() - 0.5) * 120, vy: -60 - Math.random() * 100,
        val: v, age: 0, tier: v < 3 ? 0 : v < 8 ? 1 : 2,
      });
    }
  }

  private damagePlayer(dmg: number, kx: number) {
    const p = this.p;
    if (p.iframes > 0 || p.dashT > 0) return;
    let d = dmg * p.stats.defT;
    if (p.shield > 0) {
      const absorbed = Math.min(p.shield, d);
      p.shield -= absorbed; d -= absorbed;
      p.shieldT = 11;
      this.burst(p.x, p.y - p.h / 2, '#4dd0e1', 8, 140);
    }
    if (d <= 0.5) { p.iframes = 0.5; return; }
    p.hp -= d; p.hurtT = 0.25; p.iframes = 0.75;
    p.vx += kx * 220; p.vy = Math.min(p.vy, -160);
    this.addDmg(p.x, p.y - p.h - 8, d, false);
    this.burst(p.x, p.y - p.h / 2, '#ff5d8f', 10, 160);
    this.shake(0.12); this.audio.sfx('hurt');
    if (p.hp <= 0) { p.hp = 0; this.dieTimer = 1.6; this.audio.sfx('gameover'); this.audio.setMode('off'); this.burst(p.x, p.y - p.h / 2, '#ff5d8f', 26, 260); }
    this.pushHud(true);
  }

  /* ================= upgrades / choices ================= */
  chooseUpgrade(id: string) {
    const p = this.p;
    p.taken[id] = (p.taken[id] || 0) + 1;
    const s = p.stats;
    switch (id) {
      case 'dmg': s.dmg *= 1.2; break;
      case 'rof': s.rof *= 1.15; break;
      case 'pspeed': s.pspeed *= 1.2; break;
      case 'shots': s.shots += 1; break;
      case 'crit': s.critC = Math.min(0.8, s.critC + 0.12); break;
      case 'critd': s.critD += 0.3; break;
      case 'pierce': s.pierce += 1; break;
      case 'expl': s.expl = true; break;
      case 'chain': s.chain = true; break;
      case 'ricochet': s.ricochet += 1; break;
      case 'maxhp': { const add = p.maxHp * 0.2; p.maxHp += add; p.hp = Math.min(p.maxHp, p.hp + add); break; }
      case 'heal': p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.3); break;
      case 'speed': s.move *= 1.12; break;
      case 'def': s.defT = Math.max(0.5, s.defT * 0.88); break;
      case 'shield': s.shieldMax += 30; p.shield = s.shieldMax; break;
      case 'regen': s.regen += 1.2; break;
      case 'magnet': s.magnet *= 1.6; break;
      case 'freeze': s.freeze = Math.min(0.45, s.freeze + 0.12); break;
      case 'mines': break;
      case 'orbit': break;
      case 'turret': break;
      case 'drone': if (this.drones.length < 2) this.drones.push({ a: Math.random() * 6.28, cd: 0.5 }); break;
    }
    this.audio.sfx('pick');
    this.pendingLv--;
    if (this.pendingLv > 0) {
      this.hooks.levelUp(rollUpgrades(p.taken, 2));
    } else {
      this.modal = 'none';
      this.pushHud(true);
    }
  }
  private buildChoices() {
    this.lastChoices = rollWeaponChoices(this.p.weaponId, [this.p.weaponId]);
    this.hooks.weaponChoice(this.lastChoices);
  }
  chooseWeapon(id: string) {
    const c = this.lastChoices.find(x => x.id === id);
    if (!c) { this.modal = 'none'; return; }
    if (c.kind === 'weapon' && c.weaponId) {
      this.p.weaponId = c.weaponId; this.p.weaponLv = 1;
      this.audio.sfx('levelup');
    } else if (c.kind === 'mastery') {
      this.p.weaponLv += 1; this.audio.sfx('levelup');
    } else {
      this.p.maxHp += 15; this.p.hp = this.p.maxHp; this.audio.sfx('heal');
    }
    this.modal = 'none';
    this.nextStage();
  }
  private nextStage() {
    this.stage++;
    if (this.stage > LEVELS.length) {
      this.modal = 'win';
      saveHigh({ stage: 5, wave: 10, kills: this.kills });
      this.hooks.win(this.endStats());
      return;
    }
    this.wave = 1; this.phase = 'banner'; this.phaseT = 2.4;
    this.enemies = []; this.bullets = this.bullets.filter(b => b.kind === 'p');
    this.buildQueue();
    const lv = this.lv();
    this.banner(`STAGE ${this.stage}`, lv.name, 2.6, '#4dd0e1');
    this.audio.setMode('normal');
    this.p.hp = Math.min(this.p.maxHp, this.p.hp + this.p.maxHp * 0.25);
    this.pushHud(true);
  }
  private endStats(): EndStats {
    return { stage: this.stage, wave: this.wave, kills: this.kills, level: this.p.level, time: this.time, score: this.score };
  }

  /* ================= waves ================= */
  private buildQueue() {
    const lv = this.lv();
    const q: string[] = [];
    if (this.wave === 5 || this.wave === 10) { this.queue = q; return; }
    const slots = Math.min(lv.roster.length, 1 + Math.ceil(this.wave / 2));
    const types = lv.roster.slice(0, slots);
    const total = Math.min(26, 4 + this.wave * 2 + (this.stage - 1) * 2);
    for (let i = 0; i < total; i++) {
      const wsum = types.reduce((a, _, j) => a + (types.length - j), 0);
      let r = Math.random() * wsum;
      for (let j = 0; j < types.length; j++) { r -= (types.length - j); if (r <= 0) { q.push(types[j]); break; } }
    }
    this.queue = q;
  }
  private waveLogic(dt: number) {
    if (this.phase === 'banner') {
      this.phaseT -= dt;
      if (this.phaseT <= 0) this.startWave();
    } else if (this.phase === 'spawn') {
      this.spawnT -= dt;
      const interval = Math.max(0.32, 1.3 - this.wave * 0.09 - (this.stage - 1) * 0.05);
      if (this.spawnT <= 0 && this.queue.length > 0) {
        this.spawnT = interval;
        this.spawnEnemy(this.queue.shift()!);
      }
      if (this.queue.length === 0) this.phase = 'fight';
    } else if (this.phase === 'fight') {
      if (this.enemies.length === 0 && !this.boss) {
        this.phase = 'rest'; this.phaseT = 1.7;
        this.score += 150;
        if (this.wave < 10) { this.audio.sfx('wave'); this.banner(`WAVE ${this.wave} CLEAR`, '', 1.2, '#7ddf64'); }
      }
    } else if (this.phase === 'rest') {
      this.phaseT -= dt;
      if (this.phaseT <= 0) { this.wave++; this.startWave(); }
    } else if (this.phase === 'done') {
      this.doneTimer -= dt;
      if (this.doneTimer <= 0 && this.modal === 'none') { this.modal = 'choice'; this.buildChoices(); }
    }
    // boss wave trickle
    if (this.wave === 10 && this.boss && this.boss.state !== 'enter' && this.enemies.length < 3) {
      this.trickleT -= dt;
      if (this.trickleT <= 0) { this.trickleT = 4.6; this.spawnEnemy(this.lv().roster[Math.floor(Math.random() * this.lv().roster.length)]); }
    }
  }
  private startWave() {
    this.buildQueue();
    if (this.wave === 5) {
      this.phase = 'fight';
      this.spawnMiniboss();
    } else if (this.wave === 10) {
      this.phase = 'fight';
      this.spawnBoss();
    } else {
      this.phase = 'spawn'; this.spawnT = 0.4;
      if (this.wave > 1) { this.banner(`WAVE ${this.wave}`, '', 1.1, '#ffffff'); this.audio.sfx('wave'); }
    }
    this.pushHud(true);
  }
  private entHpMul() { return 1 + 0.11 * (this.wave - 1) + 0.38 * (this.stage - 1); }
  private entDmgMul() { return 1 + 0.07 * (this.wave - 1) + 0.18 * (this.stage - 1); }
  private spawnEnemy(type: string) {
    const def = ENEMIES[type];
    const fly = def.kind === 'fly';
    const e: Ent = {
      id: uid(), def, x: -46, y: fly ? 130 + Math.random() * 150 : GROUND,
      vx: 0, vy: 0, dir: 1,
      hp: def.hp * this.entHpMul(), maxHp: def.hp * this.entHpMul(),
      touchCd: 0, flash: 0, frozen: 0, t: Math.random() * 10, baseY: fly ? 130 + Math.random() * 140 : GROUND,
      shotCd: 1 + Math.random(), hopT: 0.4 + Math.random() * 0.7, shardCd: 0,
      miniboss: false, ringT: 3, scaleS: 1,
    };
    this.enemies.push(e);
  }
  private spawnMiniboss() {
    const def = ENEMIES[this.lv().miniboss];
    const mul = 7 + this.stage * 1.2;
    const e: Ent = {
      id: uid(), def, x: -70, y: def.kind === 'fly' ? 200 : GROUND,
      vx: 0, vy: 0, dir: 1, hp: def.hp * mul, maxHp: def.hp * mul,
      touchCd: 0, flash: 0, frozen: 0, t: 0, baseY: def.kind === 'fly' ? 200 : GROUND,
      shotCd: 2, hopT: 0.5, shardCd: 0, miniboss: true, ringT: 2.6, scaleS: 1.65,
    };
    this.enemies.push(e);
    this.banner('MINI-BOSS', 'MEGA ' + def.name.toUpperCase(), 2, '#ff5d8f');
    this.audio.sfx('boss_roar'); this.audio.setMode('boss');
    this.shake(0.16);
    for (let i = 0; i < 3; i++) this.spawnEnemy(this.lv().roster[i % this.lv().roster.length]);
  }
  private spawnBoss() {
    const def = BOSSES[this.lv().boss];
    const b: BossT = {
      def, x: -150, y: def.flyer ? 170 : GROUND, vx: 0, vy: 0, dir: 1,
      hp: def.hp, maxHp: def.hp, touchCd: 0, flash: 0,
      state: 'enter', t: 0, atkIdx: 0, targetX: 0, burstN: 0, burstT: 0, chargeDir: 1, landing: false,
    };
    this.boss = b;
    this.banner('!! BOSS !!', def.name, 2.6, '#ff5d5d');
    this.audio.sfx('boss_roar'); this.audio.setMode('boss');
    this.shake(0.3); this.trickleT = 5;
    this.pushHud(true);
  }
  private killBoss() {
    const b = this.boss!;
    this.boss = null;
    this.kills++; this.score += 1500;
    this.hitstop = 0.35; this.shake(0.5);
    this.audio.sfx('explode'); this.audio.sfx('victory');
    for (let i = 0; i < 5; i++)
      setTimeout(() => { if (this.running) { this.burst(b.x + (Math.random() - 0.5) * 90, b.y - Math.random() * 90, ['#ffd23f', '#ff8a47', '#ffffff'][i % 3], 16, 260); this.shake(0.12); } }, i * 140);
    this.rings.push({ x: b.x, y: b.y - 40, r: 12, life: 0.7, max: 240, col: '#ffd23f' });
    this.dropOrbs(b.x, b.y - 20, b.def.xp);
    // clear remaining adds with fireworks
    for (const e of [...this.enemies]) { this.burst(e.x, e.y - 16, '#ff8a47', 8, 200); this.dropOrbs(e.x, e.y - 10, e.def.xp); this.enemies.splice(this.enemies.indexOf(e), 1); }
    this.banner('BOSS DEFEATED!', b.def.name, 2.2, '#ffd23f');
    this.audio.setMode('off');
    this.phase = 'done'; this.doneTimer = 2.0;
    saveHigh({ stage: this.stage, wave: this.wave, kills: this.kills });
  }

  /* ================= update ================= */
  private update(dt: number) {
    if (this.paused) return;
    this.time += dt;
    if (this.bannerT > 0) this.bannerT -= dt;
    if (this.dieTimer > 0) {
      this.dieTimer -= dt;
      if (this.dieTimer <= 0 && this.modal === 'none') {
        this.modal = 'over';
        saveHigh({ stage: this.stage, wave: this.wave, kills: this.kills });
        this.hooks.gameOver(this.endStats());
      }
    }
    this.waveLogic(dt);
    if (this.p.hp > 0) this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateBoss(dt);
    this.updateBullets(dt);
    this.updateOrbs(dt);
    this.updateFx(dt);
    this.updateSpecials(dt);
    this.hudT -= dt;
    if (this.hudT <= 0) { this.hudT = 0.12; this.pushHud(); }
  }

  private updatePlayer(dt: number) {
    const p = this.p, s = p.stats;
    const left = this.keys.has('KeyA') || this.keys.has('ArrowLeft') || this.touchIn.left;
    const right = this.keys.has('KeyD') || this.keys.has('ArrowRight') || this.touchIn.right;
    const jumpKey = this.keys.has('Space') || this.keys.has('KeyW') || this.keys.has('ArrowUp') || this.touchIn.jump;
    const fireKey = this.keys.has('KeyJ') || this.pointer.down || this.touchIn.fire;
    const dashKey = this.keys.has('KeyE') || this.touchIn.dash;

    const spd = 235 * s.move;
    const dir = (right ? 1 : 0) - (left ? 1 : 0);

    if (p.dashT > 0) {
      p.dashT -= dt; p.vy = 0;
      p.trail.push({ x: p.x, y: p.y, t: 0.3 });
    } else {
      const target = dir * spd;
      p.vx += (target - p.vx) * Math.min(1, 18 * dt);
      p.vy += GRAV * dt;
    }
    if (dir !== 0) { p.face = dir as 1 | -1; p.runT += dt; } else p.runT = 0;

    // dash (edge triggered)
    p.dashCd -= dt;
    if (dashKey && !this.dashPrev && p.dashCd <= 0 && p.dashT <= 0) {
      p.dashT = 0.16; p.dashCd = 1.5; p.iframes = Math.max(p.iframes, 0.3);
      p.vx = p.face * 720;
      this.audio.sfx('dash');
      this.burst(p.x - p.face * 12, p.y - 20, '#9df2ff', 6, 120, 0);
    }
    this.dashPrev = !!dashKey;

    // jump buffering + coyote
    p.coyote = p.onGround ? 0.11 : Math.max(0, p.coyote - dt);
    if (jumpKey && !this.jumpHeld) p.jumpBuf = 0.12;
    else p.jumpBuf = Math.max(0, p.jumpBuf - dt);
    if (p.jumpBuf > 0 && p.coyote > 0) {
      p.vy = -680; p.onGround = false; p.coyote = 0; p.jumpBuf = 0; p.jumpCut = false;
      this.audio.sfx('jump');
      this.burst(p.x, p.y, '#ffffff', 5, 90, 200);
    }
    if (!jumpKey && !p.jumpCut && p.vy < -160) { p.vy *= 0.55; p.jumpCut = true; }
    this.jumpHeld = !!jumpKey;

    // integrate
    const prevY = p.y;
    p.x += p.vx * dt; p.y += p.vy * dt;
    p.x = Math.max(22, Math.min(W - 22, p.x));
    p.onGround = false;
    if (p.y >= GROUND) { p.y = GROUND; p.vy = 0; p.onGround = true; }
    else if (p.vy >= 0) {
      for (const pl of PLATS) {
        if (prevY <= pl.y + 2 && p.y >= pl.y && p.x > pl.x - 8 && p.x < pl.x + pl.w + 8) {
          p.y = pl.y; p.vy = 0; p.onGround = true; break;
        }
      }
    }

    // aim
    const nearest = this.nearestFoe(p.x, p.y - 30, 900);
    const aimWithPointer = this.pointer.down;
    if (aimWithPointer) { p.aimX = this.pointer.x; p.aimY = this.pointer.y; }
    else if (nearest) { p.aimX = nearest.x; p.aimY = nearest.y - (nearest === this.boss ? 40 : 20); }
    else { p.aimX = p.x + p.face * 100; p.aimY = p.y - 30; }
    if (fireKey && !aimWithPointer && this.touchIn.fire && nearest) { p.aimX = nearest.x; p.aimY = nearest.y - 24; }

    // fire
    p.fireCd -= dt;
    if (fireKey && p.fireCd <= 0) this.fire();
    p.muzzle -= dt;

    // regen / shield / iframes
    if (s.regen > 0) p.hp = Math.min(p.maxHp, p.hp + s.regen * dt);
    if (p.shield < s.shieldMax) { p.shieldT -= dt; if (p.shieldT <= 0) { p.shield = s.shieldMax; this.burst(p.x, p.y - 24, '#4dd0e1', 6, 90, 0); } }
    p.iframes = Math.max(0, p.iframes - dt);
    p.hurtT = Math.max(0, p.hurtT - dt);
    for (const t of p.trail) t.t -= dt;
    p.trail = p.trail.filter(t => t.t > 0);
  }

  private updateEnemies(dt: number) {
    const p = this.p;
    for (const e of [...this.enemies]) {
      e.t += dt;
      e.flash = Math.max(0, e.flash - dt);
      e.touchCd = Math.max(0, e.touchCd - dt);
      e.shardCd = Math.max(0, e.shardCd - dt);
      const frozen = e.frozen > 0;
      if (frozen) e.frozen -= dt;
      const spdMul = (frozen ? 0 : 1) * (e.miniboss ? 0.85 : 1) * Math.min(1.28, 1 + 0.02 * (this.wave - 1));
      const dxp = p.x - e.x;
      e.dir = dxp >= 0 ? 1 : -1;
      const spd = e.def.spd * spdMul * (e.miniboss ? 0.9 : 1);

      if (!frozen) switch (e.def.kind) {
        case 'ground': case 'fast': case 'tank': {
          e.vx += (e.dir * spd - e.vx) * Math.min(1, 8 * dt);
          e.vy += GRAV * dt;
          e.y += e.vy * dt;
          if (e.y >= GROUND) { e.y = GROUND; e.vy = 0; }
          e.x += e.vx * dt;
          break;
        }
        case 'hop': {
          if (e.y >= GROUND - 1) {
            e.hopT -= dt;
            if (e.hopT <= 0) { e.hopT = 1.15 + Math.random() * 0.5; e.vy = -540; e.vx = e.dir * spd * 3.1; }
            else e.vx *= 0.9;
          }
          e.vy += GRAV * dt;
          e.x += e.vx * dt; e.y += e.vy * dt;
          if (e.y >= GROUND) { e.y = GROUND; e.vy = 0; }
          break;
        }
        case 'fly': {
          const ty = Math.max(70, Math.min(GROUND - 40, (p.y - 70) + Math.sin(e.t * 2.1) * 42));
          e.y += (ty - e.y) * Math.min(1, 2.2 * dt);
          e.vx += (e.dir * spd - e.vx) * Math.min(1, 4 * dt);
          e.x += e.vx * dt;
          break;
        }
        case 'ranged': {
          if (Math.abs(dxp) > 260) e.vx += (e.dir * spd - e.vx) * Math.min(1, 8 * dt);
          else e.vx *= 0.8;
          e.vy += GRAV * dt;
          e.x += e.vx * dt; e.y += e.vy * dt;
          if (e.y >= GROUND) { e.y = GROUND; e.vy = 0; }
          e.shotCd -= dt;
          if (e.shotCd <= 0 && Math.abs(dxp) < 560 && p.hp > 0) {
            e.shotCd = e.miniboss ? 1.5 : 2.1;
            const gy = e.y - this.entH(e) * 0.6;
            const a = Math.atan2(p.y - 26 - gy, p.x - e.x);
            const n = e.miniboss ? 3 : 1;
            for (let i = 0; i < n; i++) {
              const aa = a + (i - (n - 1) / 2) * 0.22;
              this.bullets.push({ x: e.x, y: gy, vx: Math.cos(aa) * 235, vy: Math.sin(aa) * 235, dmg: e.def.dmg * this.entDmgMul(), r: 5, life: 3.4, kind: 'e', color: '#ff5d8f', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 4, hit: new Set(), trail: [] });
            }
            this.audio.sfx('shoot_blaster');
          }
          break;
        }
      }
      if (e.x < -140) e.x = -140;

      // miniboss periodic ring
      if (e.miniboss) {
        e.ringT -= dt;
        if (e.ringT <= 0 && p.hp > 0) {
          e.ringT = 3.4;
          const n = 6 + this.stage;
          for (let i = 0; i < n; i++) {
            const a = (i / n) * Math.PI * 2;
            this.bullets.push({ x: e.x, y: e.y - this.entH(e) / 2, vx: Math.cos(a) * 185, vy: Math.sin(a) * 185, dmg: e.def.dmg * this.entDmgMul(), r: 5, life: 3.6, kind: 'e', color: '#c25eff', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 4, hit: new Set(), trail: [] });
          }
          this.audio.sfx('warn');
        }
      }

      // touch damage
      const er = this.entW(e) * 0.42;
      const dxc = e.x - p.x, dyc = (e.y - this.entH(e) / 2) - (p.y - p.h / 2);
      if (e.touchCd <= 0 && dxc * dxc + dyc * dyc < Math.pow(er + 16, 2)) {
        e.touchCd = 0.85;
        this.damagePlayer(e.def.dmg * this.entDmgMul() * (e.miniboss ? 1.35 : 1), e.dir);
        e.vx = -e.dir * 120;
      }
    }
  }
  private entW(e: Ent) { return spriteDims(e.def.sprite).w * e.scaleS; }
  private entH(e: Ent) { return spriteDims(e.def.sprite).h * e.scaleS; }

  private updateBoss(dt: number) {
    const b = this.boss;
    if (!b) return;
    const p = this.p;
    b.flash = Math.max(0, b.flash - dt);
    b.touchCd = Math.max(0, b.touchCd - dt);
    const dims = spriteDims(b.def.sprite);
    b.dir = p.x >= b.x ? 1 : -1;

    if (b.state === 'enter') {
      b.x += 130 * dt;
      if (b.x > 190) { b.state = 'move'; b.t = 1.4; }
    } else if (b.state === 'move') {
      b.t -= dt;
      const want = b.def.flyer ? 240 : 150;
      const dx = p.x - b.x;
      if (Math.abs(dx) > want) b.x += b.dir * b.def.spd * dt;
      else b.x += Math.sin(this.time * 1.7) * 18 * dt;
      if (b.def.flyer) b.y += (Math.max(120, p.y - 190) - b.y) * dt * 2;
      if (b.t <= 0) {
        b.atkIdx = (b.atkIdx + 1) % b.def.attacks.length;
        b.state = 'tele'; b.t = 0.7;
        this.audio.sfx('warn');
        if (b.def.attacks[b.atkIdx] === 'slam') b.targetX = p.x;
        if (b.def.attacks[b.atkIdx] === 'charge') b.chargeDir = b.dir;
      }
    } else if (b.state === 'tele') {
      b.t -= dt;
      if (b.def.attacks[b.atkIdx] === 'slam') b.targetX += (p.x - b.targetX) * 4 * dt;
      if (b.t <= 0) {
        const atk = b.def.attacks[b.atkIdx];
        b.state = 'attack'; b.t = 0;
        if (atk === 'slam') { b.vy = -720; b.vx = (b.targetX - b.x) * 1.35; b.landing = false; }
        else if (atk === 'charge') { b.t = 0.5; }
        else if (atk === 'spread') {
          const n = 5 + this.stage;
          const gy = b.y - dims.h * 0.55;
          const base = Math.atan2(p.y - 24 - gy, p.x - b.x);
          for (let i = 0; i < n; i++) {
            const a = base + (i - (n - 1) / 2) * 0.16;
            this.bullets.push({ x: b.x, y: gy, vx: Math.cos(a) * 245, vy: Math.sin(a) * 245, dmg: b.def.dmg * 0.55, r: 5.5, life: 3.6, kind: 'e', color: '#ff9d5d', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 4.4, hit: new Set(), trail: [] });
          }
          this.audio.sfx('shoot_shotgun');
          b.state = 'stun'; b.t = 0.8;
        } else if (atk === 'ring') {
          const n = 10 + this.stage * 2;
          for (let i = 0; i < n; i++) {
            const a = (i / n) * Math.PI * 2 + this.time;
            this.bullets.push({ x: b.x, y: b.y - dims.h * 0.5, vx: Math.cos(a) * 175, vy: Math.sin(a) * 175, dmg: b.def.dmg * 0.5, r: 5.5, life: 4.2, kind: 'e', color: '#c25eff', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 4.4, hit: new Set(), trail: [] });
          }
          this.audio.sfx('shoot_plasma');
          b.state = 'stun'; b.t = 0.9;
        } else if (atk === 'barrage') { b.burstN = 3 + Math.min(2, this.stage); b.burstT = 0; }
        else if (atk === 'summon') {
          const n = Math.min(3, 2 + Math.floor(this.stage / 2));
          for (let i = 0; i < n; i++) {
            const type = this.lv().roster[Math.floor(Math.random() * this.lv().roster.length)];
            const e = ENEMIES[type];
            this.enemies.push({
              id: uid(), def: e, x: b.x + (Math.random() - 0.5) * 120, y: e.kind === 'fly' ? b.y : GROUND,
              vx: 0, vy: 0, dir: 1, hp: e.hp * this.entHpMul() * 0.7, maxHp: e.hp * this.entHpMul() * 0.7,
              touchCd: 0, flash: 0, frozen: 0, t: 0, baseY: GROUND, shotCd: 1.5, hopT: 0.5, shardCd: 0, miniboss: false, ringT: 3, scaleS: 1,
            });
            this.burst(b.x, b.y - 30, '#c25eff', 8, 160);
          }
          this.audio.sfx('boss_roar');
          b.state = 'stun'; b.t = 0.7;
        }
      }
    } else if (b.state === 'attack') {
      const atk = b.def.attacks[b.atkIdx];
      if (atk === 'slam') {
        b.vy += GRAV * 1.15 * dt;
        b.x += b.vx * dt; b.y += b.vy * dt;
        if (b.y >= GROUND) {
          b.y = GROUND; b.vy = 0;
          this.shake(0.3); this.audio.sfx('explode');
          this.rings.push({ x: b.x, y: GROUND, r: 10, life: 0.45, max: 150, col: '#ff8a47' });
          this.burst(b.x, GROUND, '#c9a27a', 16, 260);
          if (p.onGround && Math.abs(p.x - b.x) < 150) this.damagePlayer(b.def.dmg, p.x > b.x ? 1 : -1);
          b.state = 'stun'; b.t = 0.7;
        }
      } else if (atk === 'charge') {
        b.t -= dt;
        b.x += b.chargeDir * 540 * dt;
        if (b.x < 30) { b.x = 30; b.t = 0; }
        if (b.x > W - 30) { b.x = W - 30; b.t = 0; }
        // charge trail hit
        const dx = p.x - b.x, dy = (p.y - p.h / 2) - (b.y - dims.h / 2);
        if (b.touchCd <= 0 && dx * dx + dy * dy < Math.pow(dims.w * 0.42 + 16, 2)) {
          b.touchCd = 0.9;
          this.damagePlayer(b.def.dmg * 0.9, b.chargeDir);
        }
        if (b.t <= 0) { b.state = 'stun'; b.t = 0.6; this.shake(0.1); }
      } else if (atk === 'barrage') {
        b.burstT -= dt;
        if (b.burstT <= 0 && b.burstN > 0) {
          b.burstT = 0.22; b.burstN--;
          const gy = b.y - dims.h * 0.55;
          const a = Math.atan2(p.y - 26 - gy, p.x - b.x) + (Math.random() - 0.5) * 0.14;
          this.bullets.push({ x: b.x, y: gy, vx: Math.cos(a) * 300, vy: Math.sin(a) * 300, dmg: b.def.dmg * 0.55, r: 5, life: 3.4, kind: 'e', color: '#ff5d8f', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 4, hit: new Set(), trail: [] });
          this.audio.sfx('shoot_blaster');
        }
        if (b.burstN <= 0) { b.state = 'stun'; b.t = 0.8; }
      }
    } else if (b.state === 'stun') {
      b.t -= dt;
      if (b.t <= 0) { b.state = 'move'; b.t = Math.max(0.9, 1.9 - this.stage * 0.12); }
    }

    // boss contact damage
    const dx = p.x - b.x, dy = (p.y - p.h / 2) - (b.y - dims.h / 2);
    if (b.touchCd <= 0 && b.state !== 'attack' && dx * dx + dy * dy < Math.pow(dims.w * 0.4 + 15, 2)) {
      b.touchCd = 0.85;
      this.damagePlayer(b.def.dmg * 0.8, dx > 0 ? 1 : -1);
    }
  }

  private updateBullets(dt: number) {
    const p = this.p;
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.life -= dt;
      if (b.homing && b.kind === 'p') {
        const t = this.nearestFoe(b.x, b.y, 460, b.hit);
        if (t) {
          const cur = Math.atan2(b.vy, b.vx);
          const want = Math.atan2((t.y - 24) - b.y, t.x - b.x);
          let d = want - cur;
          while (d > Math.PI) d -= Math.PI * 2;
          while (d < -Math.PI) d += Math.PI * 2;
          const turn = Math.max(-4.6 * dt, Math.min(4.6 * dt, d));
          const spd = Math.hypot(b.vx, b.vy);
          const na = cur + turn;
          b.vx = Math.cos(na) * spd; b.vy = Math.sin(na) * spd;
        }
      }
      b.x += b.vx * dt; b.y += b.vy * dt;
      b.trail.push({ x: b.x, y: b.y });
      if (b.trail.length > 5) b.trail.shift();

      let dead = false;
      if (b.life <= 0 || b.x < -60 || b.x > W + 60 || b.y < -60 || b.y > H + 60) {
        if (b.kind === 'p' && b.explR > 0 && b.life <= 0) this.explode(b.x, b.y, b.explR, b.dmg * 0.8);
        dead = true;
      } else if (b.kind === 'p') {
        // vs enemies
        for (const e of [...this.enemies]) {
          if (b.hit.has(e.id)) continue;
          const er = this.entW(e) * 0.42 + b.r;
          const dx = e.x - b.x, dy = (e.y - this.entH(e) / 2) - b.y;
          if (dx * dx + dy * dy < er * er) { this.hitFoeBullet(b, e, e.id); if (b.life <= -99) break; if (b.hit.has(e.id) && b.pierce < 0 && b.bounce < 0) { dead = true; break; } }
        }
        // vs boss
        if (!dead && this.boss && !b.hit.has(9999)) {
          const bo = this.boss, dims = spriteDims(bo.def.sprite);
          const er = dims.w * 0.42 + b.r;
          const dx = bo.x - b.x, dy = (bo.y - dims.h / 2) - b.y;
          if (dx * dx + dy * dy < er * er) this.hitFoeBullet(b, bo, 9999);
        }
        if (b.life <= -99) dead = true;
      } else {
        // enemy bullet vs player
        const dx = p.x - b.x, dy = (p.y - p.h / 2) - b.y;
        if (p.hp > 0 && dx * dx + dy * dy < Math.pow(b.r + 13, 2)) {
          this.damagePlayer(b.dmg, b.vx > 0 ? 1 : -1);
          dead = true;
        }
      }
      if (dead) this.bullets.splice(i, 1);
    }
  }
  private hitFoeBullet(b: Bullet, fo: Ent | BossT, id: number) {
    b.hit.add(id);
    const crit = Math.random() < this.p.stats.critC;
    this.damageFoe(fo, id, b.dmg * (crit ? this.p.stats.critD : 1), crit);
    this.burst(b.x, b.y, b.color, 5, 130, 200);
    // freeze
    if (this.p.stats.freeze > 0 && Math.random() < this.p.stats.freeze && id !== 9999) {
      (fo as Ent).frozen = 1.4;
    }
    // chain lightning
    let chains = b.chain;
    if (chains > 0) {
      let from = fo; let fromId = id; const seen = new Set(b.hit);
      while (chains > 0) {
        const nxt = this.nearestFoe(from.x, from.y - 20, 170, seen);
        if (!nxt) break;
        const nid = nxt === this.boss ? 9999 : (nxt as Ent).id;
        seen.add(nid); b.hit.add(nid);
        this.lightning(from.x, from.y - 24, nxt.x, nxt.y - 24);
        this.damageFoe(nxt, nid, b.dmg * 0.6, false);
        from = nxt; fromId = nid; chains--;
      }
      void fromId;
      this.audio.sfx('shoot_tesla');
    }
    // explosion
    if (b.explR > 0) this.explode(b.x, b.y, b.explR, b.dmg * 0.85);
    // pierce / bounce / die
    if (b.bounce > 0) {
      const nxt = this.nearestFoe(b.x, b.y, 300, b.hit);
      if (nxt) {
        b.bounce--;
        const a = Math.atan2((nxt.y - 24) - b.y, nxt.x - b.x);
        const spd = Math.hypot(b.vx, b.vy) * 0.92;
        b.vx = Math.cos(a) * spd; b.vy = Math.sin(a) * spd;
        b.dmg *= 0.82;
        return;
      }
    }
    if (b.pierce > 0) { b.pierce--; b.dmg *= 0.9; return; }
    b.life = -100; // mark dead
  }
  private lightning(x1: number, y1: number, x2: number, y2: number) {
    const steps = 6;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      this.parts.push({
        x: x1 + (x2 - x1) * t + (Math.random() - 0.5) * 12,
        y: y1 + (y2 - y1) * t + (Math.random() - 0.5) * 12,
        vx: 0, vy: 0, life: 0, max: 0.16, size: 3, col: '#9df2ff', grav: 0,
      });
    }
  }

  private updateOrbs(dt: number) {
    const p = this.p;
    const range = 115 * p.stats.magnet;
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const o = this.orbs[i];
      o.age += dt;
      const dx = p.x - o.x, dy = (p.y - 24) - o.y;
      const d2 = dx * dx + dy * dy;
      const magnet = d2 < range * range || o.age > 2.1;
      if (magnet) {
        const d = Math.sqrt(d2) || 1;
        const acc = 2600;
        o.vx += (dx / d) * acc * dt; o.vy += (dy / d) * acc * dt;
        const sp = Math.hypot(o.vx, o.vy), max = 640;
        if (sp > max) { o.vx = o.vx / sp * max; o.vy = o.vy / sp * max; }
        if (Math.random() < 0.3) this.parts.push({ x: o.x, y: o.y, vx: -o.vx * 0.1, vy: -o.vy * 0.1, life: 0, max: 0.22, size: 2, col: ['#7dff6a', '#4aa8ff', '#c25eff'][o.tier], grav: 0 });
      } else {
        o.vy += 500 * dt;
        o.vx *= 0.96;
      }
      o.x += o.vx * dt; o.y += o.vy * dt;
      if (o.y > GROUND + 8) { o.y = GROUND + 8; o.vy *= -0.4; }
      if (d2 < 22 * 22) {
        this.orbs.splice(i, 1);
        this.gainXp(o.val);
        this.parts.push({ x: p.x, y: p.y - 30, vx: 0, vy: -40, life: 0, max: 0.3, size: 4, col: ['#7dff6a', '#4aa8ff', '#c25eff'][o.tier], grav: 0 });
        this.audio.sfx('xp');
      }
    }
  }
  private gainXp(v: number) {
    const p = this.p;
    p.xp += v; this.score += v * 2;
    while (p.xp >= p.xpNeed) {
      p.xp -= p.xpNeed; p.level++; p.xpNeed = this.xpNeed(p.level);
      this.pendingLv++;
    }
    if (this.pendingLv > 0 && this.modal === 'none' && this.p.hp > 0) {
      this.modal = 'levelup';
      this.audio.sfx('levelup');
      this.rings.push({ x: p.x, y: p.y - 24, r: 8, life: 0.5, max: 100, col: '#ffd23f' });
      this.burst(p.x, p.y - 24, '#ffd23f', 14, 200, 0);
      this.hooks.levelUp(rollUpgrades(p.taken, 2));
    }
    this.pushHud(true);
  }

  private updateFx(dt: number) {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const q = this.parts[i];
      q.life += dt;
      q.vy += q.grav * dt;
      q.x += q.vx * dt; q.y += q.vy * dt;
      if (q.life >= q.max) this.parts.splice(i, 1);
    }
    if (this.parts.length > 420) this.parts.splice(0, this.parts.length - 420);
    for (let i = this.dmgs.length - 1; i >= 0; i--) {
      const d = this.dmgs[i];
      d.life -= dt; d.y -= 44 * dt;
      if (d.life <= 0) this.dmgs.splice(i, 1);
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.life -= dt; r.r += (r.max - r.r) * 9 * dt;
      if (r.life <= 0) this.rings.splice(i, 1);
    }
    this.shakeT = Math.max(0, this.shakeT - dt * 1.4);
  }

  private updateSpecials(dt: number) {
    const p = this.p, tk = p.taken;
    // orbit shards
    const orbitLv = tk['orbit'] || 0;
    if (orbitLv > 0) {
      this.orbitA += 2.7 * dt;
      const n = orbitLv + 1;
      for (let i = 0; i < n; i++) {
        const a = this.orbitA + (i / n) * Math.PI * 2;
        const ox = p.x + Math.cos(a) * 52, oy = p.y - 26 + Math.sin(a) * 40;
        for (const e of [...this.enemies]) {
          if (e.shardCd > 0) continue;
          const dx = e.x - ox, dy = (e.y - this.entH(e) / 2) - oy;
          if (dx * dx + dy * dy < Math.pow(this.entW(e) * 0.4 + 9, 2)) {
            e.shardCd = 0.5;
            this.damageFoe(e, e.id, 10 * p.stats.dmg, false);
            this.burst(ox, oy, '#9df2ff', 4, 110, 0);
          }
        }
        if (this.boss) {
          const bo = this.boss, dims = spriteDims(bo.def.sprite);
          const dx = bo.x - ox, dy = (bo.y - dims.h / 2) - oy;
          if (bo.touchCd <= 0.01 && dx * dx + dy * dy < Math.pow(dims.w * 0.42 + 9, 2)) {
            this.damageFoe(bo, 9999, 10 * p.stats.dmg, false);
            this.burst(ox, oy, '#9df2ff', 4, 110, 0);
          }
        }
      }
    }
    // mines
    const mineLv = tk['mines'] || 0;
    if (mineLv > 0) {
      this.specialT.mine -= dt;
      if (this.specialT.mine <= 0) {
        this.specialT.mine = Math.max(2.6, 4.2 - mineLv * 0.5);
        this.mines.push({ x: p.x - p.face * 20, y: GROUND, arm: 0.5, lv: mineLv });
      }
    }
    for (let i = this.mines.length - 1; i >= 0; i--) {
      const m = this.mines[i];
      m.arm -= dt;
      if (m.arm <= 0) {
        const foe = this.nearestFoe(m.x, m.y - 6, 46);
        if (foe) {
          this.mines.splice(i, 1);
          this.explode(m.x, m.y - 6, 72 + m.lv * 10, (24 + m.lv * 6) * p.stats.dmg);
        }
      }
    }
    // turret
    const turretLv = tk['turret'] || 0;
    if (turretLv > 0) {
      this.specialT.turret -= dt;
      if (this.specialT.turret <= 0) {
        this.specialT.turret = 11;
        this.turrets.push({ x: p.x, y: p.y, life: 10, cd: 0.3 });
        this.audio.sfx('pick');
      }
    }
    for (let i = this.turrets.length - 1; i >= 0; i--) {
      const t = this.turrets[i];
      t.life -= dt; t.cd -= dt;
      if (t.cd <= 0) {
        const foe = this.nearestFoe(t.x, t.y - 20, 420);
        if (foe) {
          t.cd = Math.max(0.4, 0.85 - turretLv * 0.12);
          const a = Math.atan2((foe.y - 24) - (t.y - 20), foe.x - t.x);
          this.bullets.push({ x: t.x, y: t.y - 20, vx: Math.cos(a) * 540, vy: Math.sin(a) * 540, dmg: (7 + turretLv * 2) * p.stats.dmg, r: 3.4, life: 1, kind: 'p', color: '#59d9ff', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 2.6, hit: new Set(), trail: [] });
          this.audio.sfx('shoot_dual');
        }
      }
      if (t.life <= 0) { this.burst(t.x, t.y - 12, '#8b93a8', 8, 130); this.turrets.splice(i, 1); }
    }
    // drones
    for (const d of this.drones) {
      d.a += 2.1 * dt; d.cd -= dt;
      if (d.cd <= 0) {
        const dx = p.x + Math.cos(d.a) * 34, dy = p.y - 34 + Math.sin(d.a) * 26;
        const foe = this.nearestFoe(dx, dy, 520);
        if (foe) {
          d.cd = 1.0;
          const a = Math.atan2((foe.y - 24) - dy, foe.x - dx);
          this.bullets.push({ x: dx, y: dy, vx: Math.cos(a) * 620, vy: Math.sin(a) * 620, dmg: 8 * p.stats.dmg, r: 3, life: 1, kind: 'p', color: '#9df2ff', pierce: 0, bounce: 0, explR: 0, chain: 0, homing: false, size: 2.4, hit: new Set(), trail: [] });
        }
      }
    }
  }

  /* ================= HUD ================= */
  private pushHud(_force = false) {
    const lv = this.lv();
    this.hooks.hud({
      hp: Math.ceil(this.p.hp), maxHp: Math.round(this.p.maxHp),
      shield: Math.ceil(this.p.shield), shieldMax: this.p.stats.shieldMax,
      xp: Math.round(this.p.xp), xpNeed: this.p.xpNeed, level: this.p.level,
      wave: this.wave, stage: this.stage, stageName: lv.name, kills: this.kills,
      weaponId: this.p.weaponId, weaponLv: this.p.weaponLv,
      score: this.score, time: this.time,
      boss: this.boss ? { name: this.boss.def.name, hp: this.boss.hp, max: this.boss.maxHp } : null,
      dashReady: this.p.dashCd <= 0, muted: this.audio.muted,
    });
  }

  /* ================= render ================= */
  private render() {
    const c = this.ctx;
    const lv = this.lv();
    const bg = renderLevelBG(lv, W, H, GROUND);
    c.imageSmoothingEnabled = false;
    c.save();
    if (this.shakeT > 0) {
      const m = this.shakeT * 14;
      c.translate((Math.random() - 0.5) * m, (Math.random() - 0.5) * m);
    }
    // parallax bg (overscan so edges never peek)
    const px = (this.p.x - W / 2) / (W / 2);
    c.drawImage(bg.sky, 0, 0);
    c.drawImage(bg.far, -40 - px * 12, 0, W + 80, H);
    c.drawImage(bg.mid, -60 - px * 24, 0, W + 120, H);
    c.drawImage(bg.ground, 0, 0);
    // platforms
    for (const pl of PLATS) c.drawImage(platformSprite(lv, pl.w), pl.x, pl.y, pl.w, 26);
    // slam target marker
    if (this.boss && (this.boss.state === 'tele' || this.boss.state === 'attack') && this.boss.def.attacks[this.boss.atkIdx] === 'slam') {
      c.fillStyle = '#ff3b3b';
      c.globalAlpha = 0.35 + Math.sin(this.time * 18) * 0.15;
      c.beginPath(); c.ellipse(this.boss.targetX, GROUND + 8, 110, 12, 0, 0, Math.PI * 2); c.fill();
      c.globalAlpha = 1;
    }
    // mines / turrets
    for (const m of this.mines) this.drawSprite('mine', 0, m.x, m.y + 4, 1, 1, m.arm > 0 ? 0.6 : 1);
    for (const t of this.turrets) this.drawSprite('turret', 0, t.x, t.y, 1, t.life < 2 ? (Math.sin(this.time * 20) > 0 ? 0.5 : 1) : 1);
    // xp orbs
    for (const o of this.orbs) {
      const fr = Math.floor((this.time * 6 + o.x) % 2);
      const spr = sprite(['xp1', 'xp2', 'xp3'][o.tier], fr);
      const puls = 1 + Math.sin(this.time * 6 + o.x) * 0.12;
      c.globalAlpha = 0.35;
      c.fillStyle = ['#7dff6a', '#4aa8ff', '#c25eff'][o.tier];
      c.beginPath(); c.arc(o.x, o.y - 6, 11 * puls, 0, Math.PI * 2); c.fill();
      c.globalAlpha = 1;
      c.drawImage(spr, o.x - spr.width / 2 * puls, o.y - 6 - spr.height / 2 * puls, spr.width * puls, spr.height * puls);
    }
    // enemies
    for (const e of this.enemies) this.drawEnt(e);
    // boss
    if (this.boss) this.drawBoss(this.boss);
    // player trail + player
    for (const t of this.p.trail) {
      c.globalAlpha = t.t * 2;
      const spr = sprite('hero', 0);
      this.drawImg(spr, t.x, t.y, 1);
    }
    c.globalAlpha = 1;
    if (this.p.hp > 0) this.drawPlayer();
    // drones
    for (const d of this.drones) {
      const dx = this.p.x + Math.cos(d.a) * 34, dy = this.p.y - 34 + Math.sin(d.a) * 26;
      this.drawSprite('drone', Math.floor(this.time * 8) % 2, dx, dy + spriteDims('drone').h / 2, 1, 1);
    }
    // orbit shards
    const orbitLv = this.p.taken['orbit'] || 0;
    if (orbitLv > 0) {
      const n = orbitLv + 1;
      for (let i = 0; i < n; i++) {
        const a = this.orbitA + (i / n) * Math.PI * 2;
        const ox = this.p.x + Math.cos(a) * 52, oy = this.p.y - 26 + Math.sin(a) * 40;
        const spr = sprite('orb_shard', Math.floor(this.time * 10) % 2);
        c.drawImage(spr, ox - spr.width / 2, oy - spr.height / 2);
      }
    }
    // bullets
    for (const b of this.bullets) {
      // trail
      if (b.trail.length > 1) {
        c.strokeStyle = b.color; c.globalAlpha = 0.4; c.lineWidth = b.size;
        c.beginPath(); c.moveTo(b.trail[0].x, b.trail[0].y);
        for (const t of b.trail) c.lineTo(t.x, t.y);
        c.stroke(); c.globalAlpha = 1;
      }
      c.fillStyle = b.color;
      c.beginPath(); c.arc(b.x, b.y, b.size + 1.5, 0, Math.PI * 2); c.globalAlpha = 0.45; c.fill(); c.globalAlpha = 1;
      c.fillStyle = '#ffffff';
      c.beginPath(); c.arc(b.x, b.y, b.size * 0.55, 0, Math.PI * 2); c.fill();
      c.fillStyle = b.color;
      c.fillRect(b.x - b.size / 2, b.y - b.size / 2, b.size, b.size);
    }
    // particles
    for (const q of this.parts) {
      c.globalAlpha = 1 - q.life / q.max;
      c.fillStyle = q.col;
      c.fillRect(q.x - q.size / 2, q.y - q.size / 2, q.size, q.size);
    }
    c.globalAlpha = 1;
    // rings
    for (const r of this.rings) {
      c.globalAlpha = Math.max(0, r.life / 0.4);
      c.strokeStyle = r.col; c.lineWidth = 4;
      c.beginPath(); c.arc(r.x, r.y, r.r, 0, Math.PI * 2); c.stroke();
    }
    c.globalAlpha = 1;
    // damage numbers
    c.textAlign = 'center';
    for (const d of this.dmgs) {
      c.globalAlpha = Math.min(1, d.life * 2.4);
      c.font = d.crit ? '13px "Press Start 2P", monospace' : '9px "Press Start 2P", monospace';
      c.fillStyle = '#10131f';
      c.fillText(d.val, d.x + 1, d.y + 1);
      c.fillStyle = d.crit ? '#ffd23f' : '#ffffff';
      c.fillText(d.val, d.x, d.y);
    }
    c.globalAlpha = 1;
    c.restore();

    // banner
    if (this.bannerT > 0) this.drawBanner(c);
    // low hp vignette
    if (this.p.hp > 0 && this.p.hp < this.p.maxHp * 0.3) {
      c.globalAlpha = 0.16 + Math.sin(this.time * 5) * 0.08;
      c.fillStyle = '#ff2a3a';
      c.fillRect(0, 0, W, 10); c.fillRect(0, H - 10, W, 10);
      c.fillRect(0, 0, 10, H); c.fillRect(W - 10, 0, 10, H);
      c.globalAlpha = 1;
    }
  }

  private drawImg(img: HTMLCanvasElement, cx: number, bottomY: number, dir: 1 | -1, alpha = 1, scale = 1) {
    const c = this.ctx;
    c.save();
    c.globalAlpha *= alpha;
    c.translate(Math.round(cx), Math.round(bottomY));
    if (dir < 0) c.scale(-1, 1);
    c.drawImage(img, -img.width / 2 * scale, -img.height * scale, img.width * scale, img.height * scale);
    c.restore();
  }
  private drawSprite(name: string, frame: number, cx: number, bottomY: number, dir: 1 | -1, alpha = 1, scale = 1) {
    this.drawImg(sprite(name, frame), cx, bottomY, dir, alpha, scale);
  }
  private shadow(cx: number, y: number, w: number, alpha = 0.3) {
    const c = this.ctx;
    c.globalAlpha = alpha;
    c.fillStyle = '#0a0d1f';
    c.beginPath(); c.ellipse(cx, y + 5, w * 0.5, 5 + w * 0.02, 0, 0, Math.PI * 2); c.fill();
    c.globalAlpha = 1;
  }
  private drawEnt(e: Ent) {
    const dims = spriteDims(e.def.sprite);
    const flyShadow = e.def.kind === 'fly';
    this.shadow(e.x, flyShadow ? GROUND : e.y, dims.w * e.scaleS * 0.62, flyShadow ? 0.16 : 0.28);
    const fr = Math.floor(e.t * (e.def.kind === 'fast' ? 12 : 6)) % dims.frames;
    const alpha = e.def.id === 'ghost' ? 0.78 + Math.sin(e.t * 3) * 0.12 : 1;
    this.drawSprite(e.def.sprite, fr, e.x, e.y, e.dir, alpha, e.scaleS);
    if (e.frozen > 0) this.drawImg(sprite(e.def.sprite, fr, 'ice'), e.x, e.y, e.dir, 0.75, e.scaleS);
    else if (e.flash > 0) this.drawImg(sprite(e.def.sprite, fr, 'white'), e.x, e.y, e.dir, Math.min(1, e.flash * 9), e.scaleS);
    // hp bar
    if (e.hp < e.maxHp) {
      const w = Math.min(44, dims.w * 0.7 * e.scaleS);
      const x = e.x - w / 2, y = e.y - dims.h * e.scaleS - 8;
      this.ctx.fillStyle = '#10131f'; this.ctx.fillRect(x - 1, y - 1, w + 2, 5);
      this.ctx.fillStyle = '#ff3b4d'; this.ctx.fillRect(x, y, w, 3);
      this.ctx.fillStyle = '#7ddf64'; this.ctx.fillRect(x, y, w * Math.max(0, e.hp / e.maxHp), 3);
    }
  }
  private drawBoss(b: BossT) {
    const dims = spriteDims(b.def.sprite);
    this.shadow(b.x, GROUND, dims.w * 0.7, 0.34);
    const fr = Math.floor(this.time * 5) % dims.frames;
    this.drawSprite(b.def.sprite, fr, b.x, b.y, b.dir, 1, 1);
    if (b.state === 'tele') {
      if (Math.floor(this.time * 12) % 2 === 0) this.drawImg(sprite(b.def.sprite, fr, 'white'), b.x, b.y, b.dir, 0.8);
      // warning icon
      this.ctx.font = '16px "Press Start 2P", monospace';
      this.ctx.textAlign = 'center';
      this.ctx.fillStyle = '#10131f'; this.ctx.fillText('!', b.x + 2, b.y - dims.h - 14 + 2);
      this.ctx.fillStyle = '#ff3b3b'; this.ctx.fillText('!', b.x, b.y - dims.h - 14);
    } else if (b.flash > 0) {
      this.drawImg(sprite(b.def.sprite, fr, 'white'), b.x, b.y, b.dir, Math.min(1, b.flash * 9));
    }
  }
  private drawPlayer() {
    const p = this.p;
    this.shadow(p.x, p.onGround ? p.y : GROUND, 40, 0.3);
    let frame = 0;
    if (!p.onGround) frame = 6;
    else if (Math.abs(p.vx) > 30) frame = [2, 3, 4, 5][Math.floor(p.runT * 10) % 4];
    else frame = Math.floor(this.time * 2.2) % 2;
    if (p.muzzle > 0) frame = 7;
    const blink = p.iframes > 0 && Math.floor(this.time * 16) % 2 === 0;
    const face: 1 | -1 = p.aimX >= p.x ? 1 : -1;
    if (!blink) this.drawSprite('hero', frame, p.x, p.y, face);
    // gun rotated toward aim
    const c = this.ctx;
    const dims = spriteDims('gun_' + p.weaponId);
    const gspr = sprite('gun_' + p.weaponId, 0);
    const gx = p.x + face * 8, gy = p.y - p.h * 0.62;
    const ang = Math.atan2(p.aimY - gy, p.aimX - gx);
    c.save();
    c.translate(gx, gy);
    c.rotate(ang);
    if (Math.cos(ang) < 0) c.scale(1, -1);
    c.drawImage(gspr, -4, -dims.h / 2);
    if (p.muzzle > 0) {
      c.fillStyle = WEAPONS[p.weaponId].color;
      c.fillRect(dims.w - 6, -3, 8, 6);
      c.fillStyle = '#ffffff';
      c.fillRect(dims.w - 4, -1.5, 5, 3);
    }
    c.restore();
    // shield ring
    if (p.shield > 0) {
      c.globalAlpha = 0.5 + Math.sin(this.time * 6) * 0.15;
      c.strokeStyle = '#4dd0e1'; c.lineWidth = 2;
      c.beginPath(); c.arc(p.x, p.y - p.h / 2, 26, 0, Math.PI * 2); c.stroke();
      c.globalAlpha = 1;
    }
    void face;
  }
  private drawBanner(c: CanvasRenderingContext2D) {
    const a = Math.min(1, this.bannerT / (this.bannerDur * 0.3), (this.bannerDur - this.bannerT) * 6);
    const scale = 1 + Math.max(0, this.bannerT - this.bannerDur + 0.18) * 2;
    c.save();
    c.globalAlpha = Math.max(0, Math.min(1, a));
    c.translate(W / 2, 170);
    c.scale(scale, scale);
    c.textAlign = 'center';
    c.font = '26px "Press Start 2P", monospace';
    c.fillStyle = '#10131f';
    c.fillText(this.bannerTitle, 3, 3);
    c.fillStyle = this.bannerCol;
    c.fillText(this.bannerTitle, 0, 0);
    if (this.bannerSub) {
      c.font = '11px "Press Start 2P", monospace';
      c.fillStyle = '#10131f'; c.fillText(this.bannerSub, 2, 26 + 2);
      c.fillStyle = '#ffffff'; c.fillText(this.bannerSub, 0, 26);
    }
    c.restore();
  }
}
