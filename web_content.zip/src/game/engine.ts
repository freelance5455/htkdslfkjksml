import {
  ANSWER_VALUE, ATTRACT_SPEED, BASE_SPEED, BOOST_AMOUNT, BOOST_TIME, COIN_VALUE, FAST_FALL_G, GRAVITY, HIT_Z,
  HURDLE_HEIGHT, INVULN_TIME, JUMP_V, MAX_COMBO, MAX_LIVES, MAX_SPEED, SPEED_PER_LEVEL, PALETTE as C, FONT_DISPLAY,
  CAM,
} from './constants';
import type {
  Entity, EngineEvent, EnginePhase, GameStats, ObstacleEnt, PlayerState, QuestionGroup, SceneryEnt, SceneryVariant, View,
} from './types';
import { QuestionDeck } from './questions';
import { ParticleSystem, FloatingTexts } from './particles';
import { audio } from './audio';
import { getBestScore } from './storage';
import {
  buildSkyCache, drawBanner, drawEntity, drawGo, drawHUD, drawPlayer, drawRoad, drawScenery, drawSigns, drawSky,
  drawSpeedLines, makeView, project, Z_FAR, clamp01, lerp, type Scene, type SkyCache,
} from './render';

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

const SCENERY_VARIANTS: SceneryVariant[] = ['palm', 'palm', 'palm', 'pillar', 'pillar', 'rock', 'rock', 'bush', 'bush', 'torch', 'obelisk'];

function makePlayer(): PlayerState {
  return {
    targetLane: 1, x: 1, y: 0, vy: 0, grounded: true, fastFall: false, runPhase: 0, lean: 0, squash: 1,
    stumbleT: 0, invulnT: 0, fallT: 0, blinkT: 0,
  };
}

function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = (Math.random() * (i + 1)) | 0;
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export class Engine implements Scene {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  view: View;
  sky: SkyCache;
  phase: EnginePhase = 'attract';
  onEvent: (e: EngineEvent) => void = () => {};

  // world
  time = 0;
  distance = 0;
  prevDistance = 0;
  speed = 0;
  boostT = 0;
  camX = 0;
  player: PlayerState = makePlayer();
  ents: Entity[] = [];
  scenery: SceneryEnt[] = [];
  groups: QuestionGroup[] = [];
  activeGroup: QuestionGroup | null = null;
  private cursorZ = 0;
  private sceneryCursor = 0;
  private chunkIndex = 0;
  private groupId = 0;
  private deadCount = 0;

  // scoring
  score = 0;
  private scoreAcc = 0;
  scoreDisplay = 0;
  best = 0;
  combo = 1;
  lives = MAX_LIVES;
  coins = 0;
  correct = 0;
  answered = 0;
  maxCombo = 1;
  level = 0;
  private coinStreak = 0;
  private coinStreakT = 0;

  // fx
  particles = new ParticleSystem();
  floats = new FloatingTexts();
  private shake = 0;
  private shakeX = 0;
  private shakeY = 0;
  private flashA = 0;
  private flashColor = '#fff';
  private slowmoT = 0;
  private hitstopT = 0;
  scoreBump = 0;
  coinBump = 0;
  comboBump = 0;
  heartBump = 0;
  goT = 0;
  private dyingT = 0;
  showHud = false;
  private deck = new QuestionDeck();

  // loop
  private raf = 0;
  private lastT = 0;
  private pausedFrameDrawn = false;
  private destroyed = false;

  // input
  private ptrId = -1;
  private ptrStartX = 0;
  private ptrStartY = 0;
  private ptrStartT = 0;
  private ptrSwiped = false;
  private ptrLastDir = '';
  private ptrLastSwipeT = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas 2D not supported');
    this.ctx = ctx;
    this.view = makeView(1, 1);
    this.sky = buildSkyCache(ctx, this.view);
    this.resize();
    this.toAttract();
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('resize', this.resize);
    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointermove', this.onPointerMove);
    canvas.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('pointercancel', this.onPointerUp);
    canvas.addEventListener('touchstart', this.preventTouch, { passive: false });
    canvas.addEventListener('touchmove', this.preventTouch, { passive: false });
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.frame);
    // Re-measure cached text once the web fonts arrive.
    if (typeof document !== 'undefined' && document.fonts && document.fonts.ready) {
      document.fonts.ready.then(() => this.invalidateTextCaches()).catch(() => undefined);
    }
  }

  private invalidateTextCaches() {
    for (const g of this.groups) {
      g.lines = undefined;
      g.fits = undefined;
    }
    if (this.activeGroup) {
      this.activeGroup.lines = undefined;
      this.activeGroup.fits = undefined;
    }
    this.pausedFrameDrawn = false;
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('resize', this.resize);
    this.canvas.removeEventListener('pointerdown', this.onPointerDown);
    this.canvas.removeEventListener('pointermove', this.onPointerMove);
    this.canvas.removeEventListener('pointerup', this.onPointerUp);
    this.canvas.removeEventListener('pointercancel', this.onPointerUp);
    this.canvas.removeEventListener('touchstart', this.preventTouch);
    this.canvas.removeEventListener('touchmove', this.preventTouch);
  }

  private preventTouch = (e: TouchEvent) => {
    if (e.cancelable) e.preventDefault();
  };

  // ---------- lifecycle ----------
  resize = () => {
    const W = Math.max(1, this.canvas.clientWidth);
    const H = Math.max(1, this.canvas.clientHeight);
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.round(W * dpr);
    this.canvas.height = Math.round(H * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.view = makeView(W, H);
    this.sky = buildSkyCache(this.ctx, this.view);
    this.invalidateTextCaches();
  };

  private resetWorld() {
    this.time = 0;
    this.distance = 0;
    this.prevDistance = 0;
    this.boostT = 0;
    this.camX = 0;
    this.player = makePlayer();
    this.ents = [];
    this.scenery = [];
    this.groups = [];
    this.activeGroup = null;
    this.cursorZ = 0;
    this.chunkIndex = 0;
    this.groupId = 0;
    this.deadCount = 0;
    this.score = 0;
    this.scoreAcc = 0;
    this.scoreDisplay = 0;
    this.combo = 1;
    this.lives = MAX_LIVES;
    this.coins = 0;
    this.correct = 0;
    this.answered = 0;
    this.maxCombo = 1;
    this.level = 0;
    this.coinStreak = 0;
    this.coinStreakT = 0;
    this.particles.clear();
    this.floats.clear();
    this.shake = 0;
    this.flashA = 0;
    this.slowmoT = 0;
    this.hitstopT = 0;
    this.scoreBump = this.coinBump = this.comboBump = this.heartBump = 0;
    this.goT = 0;
    this.dyingT = 0;
    this.sceneryCursor = 2;
    this.spawnScenery();
  }

  toAttract() {
    this.resetWorld();
    this.phase = 'attract';
    this.speed = ATTRACT_SPEED;
    this.showHud = false;
  }

  start() {
    this.resetWorld();
    this.deck.reset();
    this.phase = 'running';
    this.speed = 5;
    this.goT = 1.4;
    this.showHud = true;
    this.best = getBestScore();
    this.generateChunk();
    audio.start();
  }

  pause() {
    if (this.phase !== 'running') return;
    this.phase = 'paused';
    this.pausedFrameDrawn = false;
  }

  resume() {
    if (this.phase !== 'paused') return;
    this.phase = 'running';
    this.lastT = performance.now();
  }

  getStats(): GameStats {
    return {
      score: this.score, distance: Math.floor(this.distance), correct: this.correct, answered: this.answered,
      coins: this.coins, maxCombo: this.maxCombo, time: this.time, level: this.level,
    };
  }

  // ---------- loop ----------
  private frame = (t: number) => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = clamp((t - this.lastT) / 1000, 0, 0.05);
    this.lastT = t;
    if (this.canvas.clientWidth !== this.view.W || this.canvas.clientHeight !== this.view.H) this.resize();
    if (this.phase === 'paused') {
      if (!this.pausedFrameDrawn) {
        this.render();
        this.pausedFrameDrawn = true;
      }
      return;
    }
    this.update(dt);
    this.render();
  };

  private decayFx(dt: number) {
    if (this.shake > 0) {
      this.shake *= Math.pow(0.0005, dt);
      if (this.shake < 0.25) this.shake = 0;
      this.shakeX = (Math.random() - 0.5) * 2 * this.shake;
      this.shakeY = (Math.random() - 0.5) * 2 * this.shake;
    }
    this.flashA *= Math.pow(0.01, dt);
    this.scoreBump = Math.max(0, this.scoreBump - dt * 3);
    this.coinBump = Math.max(0, this.coinBump - dt * 4);
    this.comboBump = Math.max(0, this.comboBump - dt * 2.5);
    this.heartBump = Math.max(0, this.heartBump - dt * 2.5);
    if (this.goT > 0) this.goT -= dt;
  }

  private update(rawDt: number) {
    const ph = this.phase;
    this.decayFx(rawDt);
    this.particles.update(rawDt);
    this.floats.update(rawDt);
    this.scoreDisplay += (this.score - this.scoreDisplay) * Math.min(1, rawDt * 12);
    if (Math.abs(this.score - this.scoreDisplay) < 1) this.scoreDisplay = this.score;
    if (ph === 'over') return;

    let dt = rawDt;
    if (this.hitstopT > 0) {
      this.hitstopT -= rawDt;
      return;
    }
    if (this.slowmoT > 0) {
      this.slowmoT -= rawDt;
      dt = rawDt * 0.4;
    }
    this.time += dt;
    const p = this.player;

    // speed
    if (ph === 'running') {
      const base = Math.min(MAX_SPEED, BASE_SPEED + this.level * SPEED_PER_LEVEL);
      const target = base + (this.boostT > 0 ? BOOST_AMOUNT * (this.boostT / BOOST_TIME) : 0);
      this.speed += (target - this.speed) * Math.min(1, dt * 3);
      if (this.boostT > 0) this.boostT -= dt;
    } else if (ph === 'attract') {
      this.speed += (ATTRACT_SPEED - this.speed) * Math.min(1, dt * 2);
    } else if (ph === 'dying') {
      this.speed *= Math.pow(0.03, dt);
      this.dyingT += dt;
      p.fallT += dt;
      if (this.dyingT > 1.5) {
        this.phase = 'over';
        this.onEvent({ type: 'gameover', stats: this.getStats() });
        return;
      }
    }

    this.prevDistance = this.distance;
    this.distance += this.speed * dt;
    if (ph === 'running') {
      this.scoreAcc += this.speed * dt * 0.6;
      if (this.scoreAcc >= 1) {
        const n = Math.floor(this.scoreAcc);
        this.scoreAcc -= n;
        this.score += n;
      }
    }

    // lateral movement
    const targetX = ph === 'attract' ? 1 : p.targetLane;
    p.x += (targetX - p.x) * Math.min(1, dt * 14);
    if (Math.abs(targetX - p.x) < 0.002) p.x = targetX;
    p.lean += ((targetX - p.x) * 1.2 - p.lean) * Math.min(1, dt * 12);

    // jump physics
    if (!p.grounded) {
      p.vy -= (p.fastFall ? FAST_FALL_G : GRAVITY) * dt;
      p.y += p.vy * dt;
      if (p.y <= 0) {
        p.y = 0;
        p.vy = 0;
        p.grounded = true;
        p.fastFall = false;
        p.squash = 0.8;
        audio.land();
        this.dust(6, 70);
      }
    }
    p.squash += (1 - p.squash) * Math.min(1, dt * 10);

    // run cycle
    const prevPhase = p.runPhase;
    p.runPhase += this.speed * dt * 0.95;
    if (p.grounded && ph !== 'dying' && Math.floor(prevPhase / Math.PI) !== Math.floor(p.runPhase / Math.PI)) this.dust(2, 35);
    if (p.stumbleT > 0) p.stumbleT -= dt;
    if (p.invulnT > 0) p.invulnT -= dt;

    this.camX += ((p.x - 1) * 0.35 - this.camX) * Math.min(1, dt * 8);

    // spawning
    this.spawnScenery();
    if (ph === 'running') {
      const ahead = Math.max(90, this.speed * 7.5);
      while (this.cursorZ < this.distance + ahead) this.generateChunk();
      this.activateQuestion();
    }

    this.updateEntities();

    if (this.coinStreakT > 0) {
      this.coinStreakT -= dt;
      if (this.coinStreakT <= 0) this.coinStreak = 0;
    }
    if (this.activeGroup && this.activeGroup.resolved) {
      this.activeGroup.resultT += dt;
      if (this.activeGroup.resultT > 1.6) this.activeGroup = null;
    }
  }

  // ---------- spawning ----------
  private spawnScenery() {
    const ahead = this.distance + Z_FAR + 6;
    while (this.sceneryCursor < ahead) {
      for (let side = -1; side <= 1; side += 2) {
        if (Math.random() < 0.78) {
          this.scenery.push({
            z: this.sceneryCursor + Math.random() * 1.5,
            x: side * (2.35 + Math.random() * 1.7),
            variant: SCENERY_VARIANTS[(Math.random() * SCENERY_VARIANTS.length) | 0],
            seed: Math.random(),
          });
        }
      }
      this.sceneryCursor += 3.4;
    }
    while (this.scenery.length && this.scenery[0].z < this.distance - CAM) this.scenery.shift();
  }

  private generateChunk() {
    const planSpeed = Math.min(MAX_SPEED, BASE_SPEED + this.level * SPEED_PER_LEVEL) + 2;
    const first = this.chunkIndex === 0;
    const len = first ? Math.max(44, planSpeed * 4) : planSpeed * (7 + Math.random() * 1.5);
    const start = this.cursorZ;
    const gateZ = start + len;
    let z = start + (first ? 7 : 9);
    const end = gateZ - 14;
    const lvl = this.level;
    const obstacleChance = lvl < 1 ? 0 : lvl < 3 ? 0.3 : lvl < 6 ? 0.42 : 0.52;
    while (z < end - 5) {
      if (!first && Math.random() < obstacleChance) z = this.placeObstacles(z, lvl);
      else z = this.placeCoins(z, end);
      z += 2 + Math.random() * 3;
    }
    this.placeGates(gateZ);
    this.cursorZ = gateZ + 5;
    this.chunkIndex++;
    this.ents.sort((a, b) => a.z - b.z);
  }

  private placeCoins(z: number, end: number): number {
    let lane = (Math.random() * 3) | 0;
    const count = 4 + ((Math.random() * 4) | 0);
    const spacing = 1.7;
    const zig = this.level >= 2 && Math.random() < 0.45;
    let placed = 0;
    for (let i = 0; i < count; i++) {
      const cz = z + i * spacing;
      if (cz > end) break;
      if (zig && i === Math.floor(count / 2)) lane = clamp(lane + (Math.random() < 0.5 ? -1 : 1), 0, 2);
      this.ents.push({ kind: 'coin', z: cz, lane, y: 0, phase: Math.random() * 6.28, dead: false });
      placed++;
    }
    return z + placed * spacing;
  }

  private placeObstacles(z: number, lvl: number): number {
    const lanes = shuffle([0, 1, 2]);
    const pick = (): ObstacleEnt['variant'] => (Math.random() < 0.5 ? 'rock' : 'hurdle');
    const v0 = pick();
    this.ents.push({ kind: 'obstacle', z, lane: lanes[0], variant: v0, dead: false, hit: false });
    if (v0 === 'hurdle') {
      for (const [dz, y] of [[-1.1, 0.55], [0, 1.0], [1.1, 0.55]] as const) {
        this.ents.push({ kind: 'coin', z: z + dz, lane: lanes[0], y, phase: Math.random() * 6.28, dead: false });
      }
    }
    if (lvl >= 4 && Math.random() < 0.45) {
      this.ents.push({ kind: 'obstacle', z, lane: lanes[1], variant: pick(), dead: false, hit: false });
    }
    return z + 3;
  }

  private placeGates(z: number) {
    const q = this.deck.draw(this.level);
    const order = shuffle([0, 1, 2]);
    const answers = order.map((i) => q.a[i]);
    const correctLane = order.indexOf(q.c);
    const group: QuestionGroup = {
      id: ++this.groupId, question: q, answers, correctLane, z, active: false, activatedAt: 0, activationDist: 1,
      resolved: false, chosenLane: -1, wasCorrect: false, resultT: 0,
    };
    this.groups.push(group);
    for (let lane = 0; lane < 3; lane++) this.ents.push({ kind: 'gate', z, lane, group, dead: false });
  }

  private activateQuestion() {
    if (this.activeGroup) return;
    const g = this.groups[0];
    if (!g) return;
    const tta = lerp(6.2, 3.4, clamp01(this.level / 14));
    const rel = g.z - this.distance;
    if (rel <= this.speed * tta + 1) {
      g.active = true;
      g.activatedAt = this.time;
      g.activationDist = Math.max(1, rel);
      this.activeGroup = g;
      audio.swipe();
    }
  }

  // ---------- entities & collisions ----------
  private updateEntities() {
    const p = this.player;
    const d = this.distance;
    const pd = this.prevDistance;
    const running = this.phase === 'running';
    for (const e of this.ents) {
      if (e.dead) continue;
      const rel = e.z - d;
      if (rel < -CAM) {
        e.dead = true;
        this.deadCount++;
        if (e.kind === 'gate' && !e.group.resolved) {
          // safety: silently retire a group that was never resolved (e.g. died mid-approach)
          e.group.resolved = true;
          const gi = this.groups.indexOf(e.group);
          if (gi >= 0) this.groups.splice(gi, 1);
          if (this.activeGroup === e.group) this.activeGroup = null;
        }
        continue;
      }
      if (!running) continue;
      const crossed = e.z > pd + HIT_Z && e.z <= d + HIT_Z;
      if (e.kind === 'coin') {
        if (Math.abs(rel - HIT_Z) < 0.9 && Math.abs(p.x - e.lane) < 0.5 && Math.abs(p.y - e.y) < 0.75) {
          e.dead = true;
          this.deadCount++;
          this.collectCoin(e.lane, e.y, e.z);
        }
      } else if (e.kind === 'obstacle') {
        if (crossed && !e.hit && Math.abs(p.x - e.lane) < 0.55) {
          const clears = e.variant === 'hurdle' && p.y > HURDLE_HEIGHT - 0.12;
          if (!clears && p.invulnT <= 0) {
            e.hit = true;
            this.hitObstacle(e);
          }
        }
      } else if (crossed && !e.group.resolved && e.lane === 0) {
        this.resolveGroup(e.group);
      }
    }
    if (this.deadCount > 24) {
      this.ents = this.ents.filter((e) => !e.dead);
      this.deadCount = 0;
    }
  }

  private collectCoin(lane: number, y: number, z: number) {
    this.coins++;
    this.coinStreak++;
    this.coinStreakT = 1.2;
    const val = COIN_VALUE * this.combo;
    this.score += val;
    this.coinBump = 1;
    audio.coin(this.coinStreak);
    const pr = project(this.view, lane - 1, y + 0.36, z - this.distance, this.camX);
    this.particles.emit({
      x: pr.x, y: pr.y, count: 9, speed: 170, colors: [C.gold, C.goldLight, '#ffffff'], life: 0.5, size: 2.5, sizeVar: 2,
      gravity: 220, drag: 0.96,
    });
    this.floats.add(`+${val}`, pr.x, pr.y - 22, { color: C.goldLight, size: 15, life: 0.55, vy: -80 });
  }

  private hitObstacle(e: ObstacleEnt) {
    const p = this.player;
    audio.hit();
    this.shake = 14;
    this.flash(C.wrong, 0.4);
    this.hitstopT = 0.06;
    this.slowmoT = 0.28;
    this.combo = 1;
    this.coinStreak = 0;
    p.stumbleT = 0.6;
    p.invulnT = INVULN_TIME;
    const pr = project(this.view, e.lane - 1, 0.4, e.z - this.distance, this.camX);
    this.particles.emit({
      x: pr.x, y: pr.y, count: 18, speed: 300, colors: e.variant === 'rock' ? ['#8d8274', '#6a6052', '#c9bfae'] : [C.wood, C.woodDark, '#d9a066'],
      life: 0.8, size: 4, sizeVar: 4, gravity: 600, shape: 1, angle: -Math.PI / 2, spread: Math.PI * 1.2,
    });
    this.floats.add('OUCH!', pr.x, pr.y - 50, { color: C.wrong, size: 28, font: FONT_DISPLAY, life: 1 });
    this.loseLife();
  }

  private resolveGroup(g: QuestionGroup) {
    if (g.resolved) return;
    g.resolved = true;
    g.resultT = 0;
    g.chosenLane = this.player.targetLane;
    g.wasCorrect = g.chosenLane === g.correctLane;
    const idx = this.groups.indexOf(g);
    if (idx >= 0) this.groups.splice(idx, 1);
    if (!g.active) {
      g.active = true;
      g.activatedAt = this.time - 1;
    }
    this.activeGroup = g;
    this.answered++;
    this.level++;
    const v = this.view;
    const pr = project(v, g.chosenLane - 1, 1.1, HIT_Z, this.camX);
    const px = pr.x;
    const py = pr.y;

    if (g.wasCorrect) {
      this.correct++;
      const val = ANSWER_VALUE * this.combo;
      this.score += val;
      this.scoreBump = 1;
      this.combo = Math.min(MAX_COMBO, this.combo + 1);
      this.maxCombo = Math.max(this.maxCombo, this.combo);
      this.comboBump = 1;
      this.boostT = BOOST_TIME;
      audio.correct();
      audio.boost();
      this.shake = 5;
      this.flash(C.correct, 0.22);
      this.particles.emit({ x: px, y: py, count: 36, speed: 420, colors: [C.gold, C.goldLight, '#fff'], life: 1, size: 4, sizeVar: 4, gravity: 380, shape: 2, drag: 0.97 });
      this.particles.emit({ x: px, y: py, count: 34, speed: 380, colors: [C.correct, C.gold, '#fff', '#7dd3fc'], life: 1.2, size: 4, sizeVar: 3, gravity: 500, shape: 1, drag: 0.98 });
      this.particles.emit({ x: px, y: py, count: 14, speed: 120, colors: ['rgba(255,240,180,0.9)'], life: 0.6, size: 6, sizeVar: 6, gravity: -40, glow: true });
      this.floats.add(`+${val}`, px, py - 30, { color: C.goldLight, size: 36, font: FONT_DISPLAY, life: 1.3, vy: -70 });
      if (this.combo >= 3) {
        this.floats.add(`COMBO ×${this.combo}`, v.W / 2, v.H * 0.52, { color: C.gold, size: 30, life: 1.1, vy: -40 });
        audio.combo(this.combo);
      }
      if ((this.combo === 5 || this.combo === 8) && this.lives < MAX_LIVES) {
        this.lives++;
        this.heartBump = 1;
        audio.life();
        this.floats.add('+1 LIFE', v.W / 2, v.H * 0.6, { color: C.wrong, size: 28, life: 1.3, vy: -40 });
      }
      if (this.level % 5 === 0) {
        this.floats.add(`CHAPTER ${this.level / 5 + 1}`, v.W / 2, v.H * 0.44, { color: '#fff', size: 26, font: FONT_DISPLAY, life: 1.6, vy: -25 });
      }
    } else {
      audio.wrong();
      this.shake = 16;
      this.flash(C.wrong, 0.5);
      this.hitstopT = 0.08;
      this.slowmoT = 0.45;
      this.combo = 1;
      this.coinStreak = 0;
      this.player.stumbleT = 0.7;
      this.player.invulnT = Math.max(this.player.invulnT, 0.9); // no double punishment right after a miss
      this.particles.emit({ x: px, y: py, count: 26, speed: 340, colors: [C.wrong, C.wrongDark, '#fff'], life: 0.9, size: 4, sizeVar: 4, gravity: 600, shape: 1 });
      this.floats.add('WRONG!', px, py - 34, { color: C.wrong, size: 32, font: FONT_DISPLAY, life: 1.2, vy: -60 });
      this.loseLife();
    }
  }

  private loseLife() {
    this.lives--;
    this.heartBump = 1;
    if (this.lives <= 0) {
      this.lives = 0;
      this.phase = 'dying';
      this.dyingT = 0;
      this.player.fallT = 0.0001;
      this.player.invulnT = 0;
      audio.gameover();
    }
  }

  private flash(color: string, a: number) {
    this.flashColor = color;
    this.flashA = a;
  }

  private dust(n: number, speed: number) {
    const p = this.player;
    const pr = project(this.view, p.x - 1, 0, 0, this.camX);
    this.particles.emit({
      x: pr.x, y: pr.y, count: n, speed, colors: ['rgba(230,200,150,0.7)', 'rgba(200,170,120,0.6)'], life: 0.45,
      size: 3, sizeVar: 3, gravity: -30, drag: 0.94, angle: Math.PI / 2, spread: Math.PI,
    });
  }

  // ---------- controls ----------
  moveLane(dir: number) {
    if (this.phase !== 'running') return;
    const p = this.player;
    const nl = clamp(p.targetLane + dir, 0, 2);
    if (nl !== p.targetLane) {
      p.targetLane = nl;
      audio.swipe();
    } else {
      p.lean += dir * 0.5;
    }
  }

  setLane(lane: number) {
    if (this.phase !== 'running') return;
    const p = this.player;
    const nl = clamp(Math.round(lane), 0, 2);
    if (nl !== p.targetLane) {
      p.targetLane = nl;
      audio.swipe();
    }
  }

  jump() {
    if (this.phase !== 'running') return;
    const p = this.player;
    if (!p.grounded) return;
    p.grounded = false;
    p.vy = JUMP_V;
    p.squash = 1.2;
    audio.jump();
    this.dust(5, 60);
  }

  fastFall() {
    if (this.phase !== 'running') return;
    const p = this.player;
    if (!p.grounded) p.fastFall = true;
  }

  private onKey = (e: KeyboardEvent) => {
    const k = e.key;
    const code = e.code;
    const target = e.target as HTMLElement | null;
    const typing = !!target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA');
    if (code === 'Escape' || ((k === 'p' || k === 'P') && !typing)) {
      e.preventDefault();
      if (!e.repeat) this.onEvent({ type: 'togglePause' });
      return;
    }
    if (typing) return;
    if (this.phase === 'running') {
      if (k === 'ArrowLeft' || k === 'a' || k === 'A') {
        e.preventDefault();
        if (!e.repeat) this.moveLane(-1);
      } else if (k === 'ArrowRight' || k === 'd' || k === 'D') {
        e.preventDefault();
        if (!e.repeat) this.moveLane(1);
      } else if (k === 'ArrowUp' || k === 'w' || k === 'W' || code === 'Space') {
        e.preventDefault();
        if (!e.repeat) this.jump();
      } else if (k === 'ArrowDown' || k === 's' || k === 'S') {
        e.preventDefault();
        this.fastFall();
      } else if (k === '1' || k === '2' || k === '3') {
        e.preventDefault();
        if (!e.repeat) this.setLane(Number(k) - 1);
      }
    } else if (code === 'Space' || code === 'Enter') {
      if (target && target.tagName === 'BUTTON') return; // let the focused button handle it
      e.preventDefault();
      if (!e.repeat) this.onEvent({ type: 'primary' });
    }
  };

  private onPointerDown = (e: PointerEvent) => {
    if (this.phase !== 'running' || this.ptrId !== -1) return;
    this.ptrId = e.pointerId;
    this.ptrStartX = e.clientX;
    this.ptrStartY = e.clientY;
    this.ptrStartT = performance.now();
    this.ptrSwiped = false;
    this.ptrLastDir = '';
    try {
      this.canvas.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (e.pointerId !== this.ptrId || this.phase !== 'running') return;
    const dx = e.clientX - this.ptrStartX;
    const dy = e.clientY - this.ptrStartY;
    const TH = 22;
    if (Math.abs(dx) < TH && Math.abs(dy) < TH) return;
    const horizontal = Math.abs(dx) > Math.abs(dy);
    const dir = horizontal ? (dx > 0 ? 'R' : 'L') : dy < 0 ? 'U' : 'D';
    const now = performance.now();
    this.ptrStartX = e.clientX;
    this.ptrStartY = e.clientY;
    if (this.ptrSwiped && dir === this.ptrLastDir && now - this.ptrLastSwipeT < 220) return;
    if (dir === 'L') this.moveLane(-1);
    else if (dir === 'R') this.moveLane(1);
    else if (dir === 'U') this.jump();
    else this.fastFall();
    this.ptrSwiped = true;
    this.ptrLastDir = dir;
    this.ptrLastSwipeT = now;
  };

  private onPointerUp = (e: PointerEvent) => {
    if (e.pointerId !== this.ptrId) return;
    this.ptrId = -1;
    if (this.phase !== 'running') return;
    if (!this.ptrSwiped && performance.now() - this.ptrStartT < 320) {
      const rect = this.canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const W = this.view.W;
      const zone = x < W * 0.34 ? 0 : x > W * 0.66 ? 2 : 1;
      if (y < this.view.H * 0.5) {
        // Tapping the upper half (where the answer signs live) picks that lane directly.
        this.setLane(zone);
      } else if (zone === 0) this.moveLane(-1);
      else if (zone === 2) this.moveLane(1);
      else this.jump();
    }
  };

  // ---------- render ----------
  private render() {
    const ctx = this.ctx;
    const v = this.view;
    ctx.save();
    if (this.shake > 0) ctx.translate(this.shakeX, this.shakeY);
    drawSky(ctx, v, this.sky, this.time, this.camX);
    drawRoad(ctx, v, this.sky, this.distance, this.camX);
    this.drawWorld();
    this.particles.draw(ctx);
    if (this.boostT > 0) drawSpeedLines(ctx, v, this.boostT / BOOST_TIME, this.time);
    if (this.activeGroup && this.phase !== 'attract') {
      const g = this.activeGroup;
      const rel = g.z - this.distance;
      drawSigns(ctx, v, g, rel, this.camX, this.time);
      const remaining = g.resolved ? 0 : clamp01(rel / g.activationDist);
      drawBanner(ctx, v, g, this.time, remaining);
    }
    this.floats.draw(ctx);
    ctx.restore();
    if (this.flashA > 0.01) {
      ctx.globalAlpha = this.flashA;
      ctx.fillStyle = this.flashColor;
      ctx.fillRect(0, 0, v.W, v.H);
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = this.sky.vignette;
    ctx.fillRect(0, 0, v.W, v.H);
    if (this.showHud) drawHUD(ctx, v, this);
    if (this.goT > 0) drawGo(ctx, v, this.goT);
  }

  private drawWorld() {
    const ctx = this.ctx;
    const v = this.view;
    const d = this.distance;
    let i = this.scenery.length - 1;
    let j = this.ents.length - 1;
    let playerDrawn = false;
    const minRel = -CAM + 0.3;
    while (i >= 0 || j >= 0) {
      const zs = i >= 0 ? this.scenery[i].z : -Infinity;
      const ze = j >= 0 ? this.ents[j].z : -Infinity;
      const z = Math.max(zs, ze);
      const rel = z - d;
      if (!playerDrawn && rel < 0) {
        drawPlayer(ctx, v, this.player, this.player.x - 1, this.camX, this.time);
        playerDrawn = true;
      }
      if (zs >= ze) {
        const e = this.scenery[i--];
        if (rel <= Z_FAR && rel > minRel) drawScenery(ctx, v, e, rel, this.camX, this.time);
      } else {
        const e = this.ents[j--];
        if (!e.dead && rel <= Z_FAR && rel > minRel) drawEntity(ctx, v, e, rel, this.camX, this.time);
      }
    }
    if (!playerDrawn) drawPlayer(ctx, v, this.player, this.player.x - 1, this.camX, this.time);
  }
}
