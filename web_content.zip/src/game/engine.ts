// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — المحرك: حلقة اللعبة، الكاميرا، الإدخال، الربط
// ═══════════════════════════════════════════════════════════════
import * as THREE from "three";
import { CHARACTERS, CharacterDef, Line, SaveData } from "./data";
import { AudioEngine, clamp, damp, defaultSave, loadSave, mulberry32, storeSave } from "./systems";
import { buildWorld, WorldHandles } from "./world";
import {
  Ally, Ctx, Enemy, InputFrame, MissionManager, Npc, ParticleSystem, Pickup,
  Player, Projectile, insideBuilding, spawnNpc, updateNpc, makeBeacon,
} from "./entities";

export interface HudState {
  hp: number; hpMax: number; rc: number; rcMax: number; stam: number;
  level: number; xp: number; xpNext: number; cells: number;
  combo: number; comboT: number;
  boss: { name: string; frac: number } | null;
  locked: boolean; kagune: boolean; transforming: boolean;
  interact: string | null; skillCd: number;
  mission: { title: string; desc: string; kind: string } | null;
  sideMission: { title: string; desc: string } | null;
  dead: boolean; timeLabel: string; fps: number;
}
export interface EngineEvents {
  onHud(h: HudState): void;
  onToast(msg: string, kind: string): void;
  onDialogue(lines: Line[] | null): void;
  onEnding(id: string): void;
  onDeath(): void;
  onHurt(): void;
  onMissionChanged(): void;
}

export class GameEngine {
  canvas: HTMLCanvasElement;
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  world: WorldHandles;
  audio = new AudioEngine();
  particles: ParticleSystem;
  player: Player;
  ctx: Ctx;
  missions: MissionManager;
  allies: Ally[] = [];
  npcs: Npc[] = [];
  enemies: Enemy[] = [];
  projectiles: Projectile[] = [];
  pickups: Pickup[] = [];
  events: EngineEvents;
  save: SaveData;
  def: CharacterDef;
  paused = false;
  dlgAfter: ((c?: string) => void) | null = null;
  inDialogue = false;
  raf = 0;
  last = 0;
  timeScale = 1;
  shake = 0;
  dayT = 0.74;
  weatherT = 40;
  fps = 60; fpsAcc = 0; fpsN = 0;
  hudT = 0;
  beaconT = 0;
  beacons: THREE.Object3D[] = [];
  minimap: HTMLCanvasElement | null = null;
  keys: Record<string, boolean> = {};
  vAxis = { x: 0, y: 0 };
  edge: Record<string, boolean> = {};
  touchSprint = false;
  lampLights: THREE.PointLight[] = [];
  disposed = false;
  hitFlashT = 0;
  private listeners: [any, string, any][] = [];

  constructor(canvas: HTMLCanvasElement, save: SaveData | null, events: EngineEvents) {
    this.canvas = canvas;
    this.events = events;
    const loaded = save || loadSave();
    this.save = loaded ? { ...loaded, settings: { ...loaded.settings } } : defaultSave();
    this.def = CHARACTERS.find((c) => c.id === this.save.charId) || CHARACTERS[0];
    const q = this.save.settings.quality;

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: q > 0, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(q === 0 ? 0.72 : q === 1 ? Math.min(window.devicePixelRatio, 1.5) : Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = q === 2;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 700);

    const rng = mulberry32(20260214);
    this.world = buildWorld(this.scene, q, rng);
    this.particles = new ParticleSystem(this.scene);

    const start = this.save.pos
      ? new THREE.Vector3(this.save.pos[0], this.save.pos[1], this.save.pos[2])
      : new THREE.Vector3(this.world.anchors["cafe"][0].x, 0, this.world.anchors["cafe"][0].z - 6);
    const hpMax = 100 + (this.save.level - 1) * 8;
    this.player = new Player(this.def, this.scene, start, hpMax);

    this.ctx = {
      scene: this.scene, camera: this.camera, world: this.world, audio: this.audio,
      particles: this.particles, stats: this.computeStats(), flags: new Set(this.save.flags),
      addShake: (m) => { if (this.save.settings.shake) this.shake = Math.min(1.4, this.shake + m); },
      notify: (msg, kind = "info") => events.onToast(msg, kind),
      dialogue: (lines, after) => this.beginDialogue(lines, after),
      onKill: (tag) => this.onKill(tag),
      onCollect: (kind) => this.onCollect(kind),
      onPlayerHit: () => { this.hitFlashT = 0.5; events.onHurt(); },
      onDeath: () => events.onDeath(),
      player: this.player, enemies: this.enemies, projectiles: this.projectiles, pickups: this.pickups,
      time: 0,
    };
    (this.ctx as any).reward = (xp: number, cells: number, unlock?: string) => {
      this.addXp(xp);
      this.save.cells += cells;
      if (unlock && !this.save.unlocked.includes(unlock)) this.save.unlocked.push(unlock);
      this.persist();
    };
    (this.ctx as any).onEnding = (id: string) => {
      this.persist();
      setTimeout(() => events.onEnding(id), 900);
    };

    this.missions = new MissionManager(this.ctx, this.save.missionIdx, this.save.done);
    this.missions.saveHook = () => this.persist();

    // المدنيون
    const npcCount = [6, 12, 18][q];
    for (let i = 0; i < npcCount; i++) this.npcs.push(spawnNpc(this.ctx));

    // أضواء مصابيح قريبة
    if (q > 0) {
      for (let i = 0; i < 2; i++) {
        const pl = new THREE.PointLight(0xffd9a0, 0.9, 20, 1.8);
        this.scene.add(pl);
        this.lampLights.push(pl);
      }
    }

    this.bindInput();
    this.audio.ensure();
    this.audio.setVolumes(this.save.settings.music, this.save.settings.sfx);
    this.audio.startMusic();

    // ابدأ المهمة الحالية
    setTimeout(() => this.missions.startCurrent(), 800);
    events.onMissionChanged();

    this.last = performance.now();
    const loop = (t: number) => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(loop);
      this.tick(t);
    };
    this.raf = requestAnimationFrame(loop);
  }

  // ── إحصاءات من الشجرة ──
  computeStats() {
    const p = this.def.id === "daisuke" ? "dai" : this.def.id === "hollow" ? "hol" : this.def.id;
    const has = (e: string) => this.save.skills.includes(`${p}_${e}`);
    const d = this.def;
    return {
      power: (1 + (d.stats.power - 5) * 0.055) * (has("pow") ? 1.2 : 1),
      range: 1 + (has("rng") ? 0.25 : 0),
      dodgeIF: has("dod") ? 0.55 : 0.3,
      leech: has("lee") ? 0.08 : 0,
      rcMax: 100 + (d.stats.rc - 5) * 8 + (has("rc") ? 50 : 0),
      ult: has("ult"),
      speedMul: 1 + (d.stats.speed - 5) * 0.045,
      defMul: d.stats.defense + (this.save.level - 1) * 0.5,
    };
  }
  refreshStats() { this.ctx.stats = this.computeStats(); }

  addXp(xp: number) {
    this.save.xp += xp;
    let next = Math.floor(40 * Math.pow(this.save.level, 1.4));
    while (this.save.xp >= next) {
      this.save.xp -= next;
      this.save.level++;
      this.save.cells++;
      this.player.hpMax += 8;
      this.player.hp = Math.min(this.player.hpMax, this.player.hp + this.player.hpMax * 0.4);
      this.events.onToast(`ارتقيت إلى المستوى ${this.save.level}! +خلية RC`, "good");
      this.audio.pickup();
      next = Math.floor(40 * Math.pow(this.save.level, 1.4));
    }
  }

  persist() {
    this.save.pos = [this.player.pos.x, this.player.pos.y, this.player.pos.z];
    this.save.flags = Array.from(this.ctx.flags);
    this.save.missionIdx = this.missions.storyIdx;
    this.save.done = Array.from(this.missions.done);
    storeSave(this.save);
  }

  onKill(tag: string) {
    this.missions.onKill(tag);
    const e = this.enemies.find((x) => x.tag === tag && x.dead);
    if (e) this.addXp(e.spec.xp);
    this.events.onMissionChanged();
  }
  onCollect(kind: string) {
    this.missions.onCollect(kind);
    this.events.onMissionChanged();
  }

  // ── الحوار ──
  beginDialogue(lines: Line[], after?: (c?: string) => void) {
    this.inDialogue = true;
    this.dlgAfter = after || null;
    this.events.onDialogue(lines);
  }
  endDialogue(choice?: string) {
    this.inDialogue = false;
    this.events.onDialogue(null);
    const after = this.dlgAfter;
    this.dlgAfter = null;
    if (after) after(choice);
  }

  // ── الإدخال ──
  setAxis(x: number, y: number) { this.vAxis.x = x; this.vAxis.y = y; }
  press(name: string) { this.edge[name] = true; }
  hold(name: string, v: boolean) {
    if (name === "block") this.player.blockHold = v;
    if (name === "sprint") this.touchSprint = v;
  }
  cameraDrag(dx: number, dy: number) {
    const s = this.save.settings.sens;
    this.player.camYaw -= dx * 0.0052 * s;
    this.player.camPitch = clamp(this.player.camPitch + dy * 0.0042 * s, 0.04, 1.15);
  }
  cameraZoom(d: number) { this.player.camDist = clamp(this.player.camDist + d, 3.2, 13); }

  private on(el: any, ev: string, fn: (e: any) => void) {
    el.addEventListener(ev, fn, { passive: false });
    this.listeners.push([el, ev, fn]);
  }
  bindInput() {
    // استئناف الصوت عند أول تلمس/ضغطة (سياسة المتصفحات)
    const wake = () => this.audio.ensure();
    this.on(window, "pointerdown", wake);
    this.on(window, "touchstart", wake);
    const kd = (e: KeyboardEvent) => {
      this.keys[e.code] = true;
      if (e.code === "Space") { this.edge.jump = true; e.preventDefault(); }
      if (e.code === "KeyJ") this.edge.attack = true;
      if (e.code === "KeyK") this.edge.heavy = true;
      if (e.code === "KeyL") this.edge.dodge = true;
      if (e.code === "KeyQ") this.edge.skill = true;
      if (e.code === "KeyT") this.edge.transform = true;
      if (e.code === "KeyF") this.edge.lock = true;
      if (e.code === "KeyE") this.edge.interact = true;
    };
    const ku = (e: KeyboardEvent) => { this.keys[e.code] = false; };
    this.on(window, "keydown", kd);
    this.on(window, "keyup", ku);
    // ماوس
    let drag = false, lx = 0, ly = 0;
    this.on(this.canvas, "mousedown", (e: MouseEvent) => { drag = true; lx = e.clientX; ly = e.clientY; });
    this.on(window, "mouseup", () => { drag = false; });
    this.on(window, "mousemove", (e: MouseEvent) => {
      if (!drag) return;
      this.cameraDrag(e.clientX - lx, e.clientY - ly);
      lx = e.clientX; ly = e.clientY;
    });
    this.on(this.canvas, "wheel", (e: WheelEvent) => { e.preventDefault(); this.cameraZoom(e.deltaY * 0.004); });
    this.on(this.canvas, "contextmenu", (e: Event) => e.preventDefault());
    this.on(window, "resize", () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }

  collectInput(): InputFrame {
    const k = this.keys;
    let mx = this.vAxis.x + ((k["KeyD"] || k["ArrowRight"] ? 1 : 0) - (k["KeyA"] || k["ArrowLeft"] ? 1 : 0));
    let mz = this.vAxis.y + ((k["KeyW"] || k["ArrowUp"] ? 1 : 0) - (k["KeyS"] || k["ArrowDown"] ? 1 : 0));
    const len = Math.hypot(mx, mz);
    if (len > 1) { mx /= len; mz /= len; }
    const f: InputFrame = {
      mx, mz,
      sprint: !!(k["ShiftLeft"] || k["ShiftRight"] || this.touchSprint),
      jump: !!this.edge.jump, attack: !!this.edge.attack, heavy: !!this.edge.heavy,
      dodge: !!this.edge.dodge, skill: !!this.edge.skill, transform: !!this.edge.transform,
      block: !!(k["KeyC"] || this.player.blockHold), interact: !!this.edge.interact, lock: !!this.edge.lock,
    };
    this.edge = {};
    return f;
  }

  attachMinimap(c: HTMLCanvasElement | null) { this.minimap = c; }

  respawn() {
    this.player.respawn(this.ctx);
    this.events.onToast("عدت إلى اللوتس الأسود… المدينة لا تنام", "info");
  }

  startSide(id: string) { this.missions.startSide(id); }

  // ── الحلقة الرئيسية ──
  tick(now: number) {
    let dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    // إحصاء FPS
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 0.5) { this.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }

    const cinematic = this.player.transforming;
    this.timeScale = damp(this.timeScale, cinematic ? 0.4 : 1, 6, dt);
    const sdt = this.paused || this.inDialogue ? 0 : dt * this.timeScale;
    this.ctx.time += sdt;
    this.player.blockHold = this.player.blockHold; // حالة مستمرة

    if (sdt > 0) {
      this.updateWorld(sdt);
      this.updateEntities(sdt);
    }
    // الكاميرا تعمل دائماً (سينمائية)
    this.updateCamera(dt, cinematic);
    this.particles.update(Math.max(sdt, dt * 0.25));

    // وميض الإصابة
    this.hitFlashT = Math.max(0, this.hitFlashT - dt * 1.8);

    // HUD
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.1;
      this.emitHud();
    }
    this.renderer.render(this.scene, this.camera);
  }

  updateWorld(dt: number) {
    this.dayT = (this.dayT + dt / 340) % 1;
    const p = this.player.pos;
    const nightF = this.world.update(dt, this.dayT, p.x, p.z);
    // الطقس
    this.weatherT -= dt;
    if (this.weatherT <= 0) {
      this.weatherT = 60 + Math.random() * 90;
      const on = Math.random() < 0.55;
      this.world.setRain(on);
      if (on) { this.audio.rainStart(1); this.events.onToast("بدأ المطر يهطل على المدينة…", "info"); }
      else this.audio.rainStop();
    }
    // أضواء المصابيح تتبع اللاعب
    if (this.lampLights.length) {
      const pts = this.world.lampPts;
      const near = pts
        .map((lp) => ({ lp, d: (lp.x - p.x) ** 2 + (lp.z - p.z) ** 2 }))
        .sort((a, b) => a.d - b.d);
      this.lampLights.forEach((l, i) => {
        if (near[i]) { l.position.copy(near[i].lp); l.intensity = nightF * 1.1; }
      });
    }
    // جمرات محيطية
    if (Math.random() < dt * 1.6) {
      const off = new THREE.Vector3((Math.random() - 0.5) * 16, Math.random() * 5, (Math.random() - 0.5) * 16);
      this.particles.burst(p.clone().add(off), 0x8e2236, 2, 0.5, 3.2, 0.14, 0.55);
    }
  }

  updateEntities(dt: number) {
    const inp = this.collectInput();
    const ctx = this.ctx;

    // تفاعل
    this.updateInteract(inp);

    this.player.update(dt, inp, ctx);

    // الأعداء
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      const gone = e.update(dt, ctx);
      if (gone) {
        ctx.scene.remove(e.rig.root);
        this.enemies.splice(i, 1);
        if (this.player.lockTarget === e) this.player.lockTarget = null;
      }
    }
    // الحلفاء
    for (const a of this.allies) a.update(dt, ctx);
    // المدنيون
    for (const n of this.npcs) updateNpc(n, dt, ctx);
    // مهمات m4: استحداث الحليف
    if (this.missions.cur?.id === "m4" && this.missions.phase === "active" && this.allies.length === 0) {
      this.allies.push(new Ally(ctx.scene, this.player.pos.x + 2, this.player.pos.z + 2));
      this.events.onToast("رين ويوكي يقاتلان إلى جانبك!", "good");
    }
    if (this.missions.cur?.id !== "m4" && this.allies.length) {
      for (const a of this.allies) ctx.scene.remove(a.rig.root);
      this.allies = [];
    }

    // المقذوفات
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.life -= dt;
      pr.mesh.position.addScaledVector(pr.vel, dt);
      const pp = pr.mesh.position;
      let kill = pr.life <= 0;
      if (!kill && insideBuilding(pp.x, pp.y, pp.z, ctx.world.colliders)) {
        ctx.particles.burst(pp.clone(), pr.friendly ? 0xff2038 : 0x5f8fd9, 6, 3, 0.3, 0.18);
        kill = true;
      }
      if (!kill) {
        if (pr.friendly) {
          for (const e of this.enemies) {
            if (e.dead) continue;
            if (Math.abs(e.pos.y + 1.2 - pp.y) < 1.6 && Math.hypot(e.pos.x - pp.x, e.pos.z - pp.z) < 0.95 * e.spec.scale + 0.4) {
              e.takeHit(ctx, pr.dmg, pr.vel.clone().setY(0).normalize(), 3);
              ctx.audio.hit(0.8);
              this.player.rc = Math.min(ctx.stats.rcMax, this.player.rc + 2);
              kill = true;
              break;
            }
          }
        } else if (!this.player.dead) {
          const pl = this.player.pos;
          if (Math.abs(pl.y + 1.1 - pp.y) < 1.5 && Math.hypot(pl.x - pp.x, pl.z - pp.z) < 0.85) {
            this.player.takeDamage(ctx, pr.dmg, pp);
            kill = true;
          }
        }
      }
      if (kill) {
        ctx.scene.remove(pr.mesh);
        pr.mesh.geometry.dispose();
        (pr.mesh.material as THREE.Material).dispose();
        this.projectiles.splice(i, 1);
      }
    }

    // الملتقطات
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const pk = this.pickups[i];
      pk.t += dt;
      pk.mesh.position.y = pk.baseY + Math.sin(pk.t * 2.2) * 0.18;
      pk.mesh.rotation.y += dt * 1.8;
      const d = pk.mesh.position.distanceTo(this.player.pos.clone().add(new THREE.Vector3(0, 1, 0)));
      if (d < 7) {
        const dir = this.player.pos.clone().add(new THREE.Vector3(0, 1, 0)).sub(pk.mesh.position).normalize();
        pk.mesh.position.addScaledVector(dir, dt * (10 - d) * 2.4);
      }
      if (d < 1.5) {
        this.audio.pickup();
        if (pk.kind === "cell") {
          this.save.cells += 1;
          this.player.hp = Math.min(this.player.hpMax, this.player.hp + 6);
          this.player.rc = Math.min(ctx.stats.rcMax, this.player.rc + 12);
          this.events.onToast("+1 خلية RC", "good");
        } else {
          this.events.onToast("بلورة RC — تُحتسب للمهمة الجانبية", "good");
        }
        this.onCollect(pk.kind);
        ctx.particles.burst(pk.mesh.position.clone(), pk.kind === "crystal" ? 0xff2d55 : 0xff8844, 10, 4, 0.4, 0.2, 2);
        ctx.scene.remove(pk.mesh);
        this.pickups.splice(i, 1);
      }
    }

    this.missions.update(dt);

    // منارات
    this.beaconT -= dt;
    if (this.beaconT <= 0) {
      this.beaconT = 0.8;
      this.rebuildBeacons();
    }
    for (const b of this.beacons) {
      b.rotation.y += dt * 0.8;
      const gem = b.children[2];
      if (gem) gem.position.y = 2.2 + Math.sin(this.ctx.time * 2.4) * 0.3;
    }
  }

  rebuildBeacons() {
    for (const b of this.beacons) this.scene.remove(b);
    this.beacons = [];
    const add = (pts: { x: number; z: number; h: number }[], color: number) => {
      for (const pt of pts.slice(0, 4)) {
        const b = makeBeacon(color);
        b.position.set(pt.x, pt.h, pt.z);
        this.scene.add(b);
        this.beacons.push(b);
      }
    };
    const m = this.missions;
    if (m.phase === "active" && m.cur?.objective.kind === "reach") {
      add(m.objectivePoints(m.cur, "active", m.visitedRoofs), 0xe0455e);
    }
    if (m.sidePhase === "active" && m.side?.objective.kind === "reach") {
      add(m.objectivePoints(m.side, "active", null), 0xffb02e);
    }
  }

  updateInteract(inp: InputFrame) {
    const p = this.player;
    p.interactPrompt = null;
    p.interactAction = null;
    const A = this.world.anchors;
    const near = (key: string, r: number) => {
      const a = A[key]?.[0];
      if (!a) return false;
      return Math.hypot(a.x - p.pos.x, a.z - p.pos.z) < r && Math.abs(p.pos.y - a.h) < 3;
    };
    if (near("cafe", 4)) {
      p.interactPrompt = "اللوتس الأسود — استرح واستعد صحتك (حفظ)";
      p.interactAction = () => {
        p.hp = p.hpMax;
        p.rc = this.ctx.stats.rcMax;
        this.persist();
        this.events.onToast("قهوة سوداء، دفء نادر… تم الحفظ واستعادة الصحة", "good");
        this.audio.pickup();
      };
    } else if (near("apartment", 3.5)) {
      p.interactPrompt = "شقتك القديمة — تفقّد والحفظ";
      p.interactAction = () => {
        this.persist();
        this.events.onToast("كل شيء كما تركته… تقريباً. تم الحفظ.", "info");
      };
    } else if (near("hospital", 6)) {
      p.interactPrompt = "المستشفى — ضمّد جراحك";
      p.interactAction = () => {
        p.hp = p.hpMax;
        this.events.onToast("استعدت صحتك بالكامل", "good");
        this.audio.pickup();
      };
    } else if (near("shrine", 5)) {
      p.interactPrompt = "الضريح القديم — تأمّل";
      p.interactAction = () => {
        p.rc = this.ctx.stats.rcMax;
        this.events.onToast("سكينة غامرة… امتلأ مقياس RC", "good");
        this.audio.pickup();
      };
    }
    if (inp.interact && p.interactAction) p.interactAction();
  }

  updateCamera(dt: number, cinematic: boolean) {
    const p = this.player;
    if (cinematic) {
      p.camYaw += dt * 1.15;
      p.camPitch = damp(p.camPitch, 0.24, 2, dt);
      p.camDist = damp(p.camDist, 4.6, 2, dt);
    }
    const cp = Math.cos(p.camPitch), sp = Math.sin(p.camPitch);
    const off = new THREE.Vector3(Math.sin(p.camYaw) * cp, sp, Math.cos(p.camYaw) * cp).multiplyScalar(p.camDist);
    const head = p.pos.clone().add(new THREE.Vector3(0, 1.62 * p.rig.scale, 0));
    let desired = head.clone().add(off);
    // منع اختراق الكاميرا للجدران
    let safe = 1;
    for (let i = 1; i <= 6; i++) {
      const t = i / 6;
      const pt = head.clone().lerp(desired, t);
      if (insideBuilding(pt.x, pt.y - 0.15, pt.z, this.world.colliders)) { safe = (i - 1) / 6; break; }
    }
    desired = head.clone().lerp(desired, Math.max(0.12, safe));
    if (desired.y < 0.5) desired.y = 0.5;
    const pos = this.camera.position;
    pos.x = damp(pos.x, desired.x, 9, dt);
    pos.y = damp(pos.y, Math.max(0.45, desired.y), 9, dt);
    pos.z = damp(pos.z, desired.z, 9, dt);
    // اهتزاز
    this.shake = Math.max(0, this.shake - dt * 2.2);
    if (this.shake > 0.002) {
      pos.x += (Math.random() - 0.5) * this.shake * 0.25;
      pos.y += (Math.random() - 0.5) * this.shake * 0.2;
      pos.z += (Math.random() - 0.5) * this.shake * 0.25;
    }
    this.camera.lookAt(head.x, head.y + 0.12, head.z);
  }

  emitHud() {
    const p = this.player;
    const st = this.ctx.stats;
    let boss: { name: string; frac: number } | null = null;
    for (const e of this.enemies) {
      if (e.spec.boss && !e.dead) {
        boss = {
          name: e.spec.type === "boss_genji" ? `القائد جينجي — المرحلة ${e.phase}` : `موراساكي — المرحلة ${e.phase}`,
          frac: clamp(e.hp / e.maxHp, 0, 1),
        };
      }
    }
    const hours = Math.floor(this.dayT * 24), mins = Math.floor((this.dayT * 24 - hours) * 60);
    const h: HudState = {
      hp: Math.max(0, Math.round(p.hp)), hpMax: p.hpMax,
      rc: Math.max(0, Math.round(p.rc)), rcMax: st.rcMax,
      stam: Math.round(p.stamina),
      level: this.save.level, xp: this.save.xp, xpNext: Math.floor(40 * Math.pow(this.save.level, 1.4)),
      cells: this.save.cells,
      combo: p.comboCount, comboT: clamp(p.comboShowT / 2.2, 0, 1),
      boss, locked: !!p.lockTarget, kagune: p.kaguneOn, transforming: p.transforming,
      interact: p.interactPrompt,
      skillCd: clamp(p.skillCd / 6, 0, 1),
      mission: this.missions.cur && this.missions.phase !== "over"
        ? { title: this.missions.cur.title, desc: this.missions.cur.desc, kind: this.missions.cur.kind } : null,
      sideMission: this.missions.side && this.missions.sidePhase === "active"
        ? { title: this.missions.side.title, desc: this.missions.side.desc } : null,
      dead: p.dead,
      timeLabel: `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`,
      fps: this.fps,
    };
    this.events.onHud(h);
    // الخريطة المصغرة
    if (this.minimap) {
      const g = this.minimap.getContext("2d");
      if (g) {
        this.world.drawMinimap(
          g, this.minimap.width, p.pos.x, p.pos.z, -p.camYaw,
          this.missions.markers(),
          this.enemies.filter((e) => !e.dead).map((e) => ({ x: e.pos.x, z: e.pos.z, boss: e.spec.boss }))
        );
      }
    }
  }

  setPaused(v: boolean) { this.paused = v; }
  setVolumes() { this.audio.setVolumes(this.save.settings.music, this.save.settings.sfx); }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    for (const [el, ev, fn] of this.listeners) el.removeEventListener(ev, fn);
    this.audio.close();
    this.renderer.dispose();
  }
}
