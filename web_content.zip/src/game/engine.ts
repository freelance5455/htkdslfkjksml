import { drawSkinPattern, SKINS, SKIN_MAP } from './skins';
import { soundFX } from './sound';
import {
  ArenaTheme,
  Cell,
  EjectedMass,
  FoodPellet,
  GameConfig,
  GameMode,
  HudSnapshot,
  LeaderboardEntry,
  MinimapDot,
  NetStatePayload,
  Particle,
  Ripple,
  SkinId,
  Virus,
} from './types';

export const WORLD_SIZE = 4200;
const MAX_CELLS_PER_OWNER = 16;
const TARGET_FOOD_COUNT = 780;
const TARGET_BOT_COUNT = 23;
const TARGET_VIRUS_COUNT = 22;
const MAX_VIRUS_COUNT = 32;

const PELLET_COLORS = [
  '#F43F5E',
  '#F59E0B',
  '#10B981',
  '#0EA5E9',
  '#8B5CF6',
  '#EC4899',
  '#14B8A6',
  '#F97316',
];

const BOT_NAMES = [
  'شێرە',
  'ئەستێرە',
  'کوردۆ',
  'ڕەشەبا',
  'پڵنگ',
  'زانا',
  'خێرا',
  'نێچیر',
  'ئاسۆ',
  'باوەڕ',
  'هەڵۆ',
  'بروسکە',
  'چیا',
  'دەریا',
  'کانی',
  'ڕێباز',
  'سۆران',
  'ئاگر',
  'تیشک',
  'بەفرین',
  'هێمن',
  'لاوین',
  'دیلان',
  'ئارام',
  'شنە',
  'بەهێز',
  'ڕووناک',
  'ژیار',
];

let uidCounter = 1;
function nextId(prefix: string): string {
  uidCounter += 1;
  return `${prefix}_${uidCounter}`;
}

export function massToRadius(mass: number): number {
  return 5.4 * Math.sqrt(Math.max(mass, 1)) + 4;
}

export class AgarEngine {
  public cells: Cell[] = [];
  public foods: FoodPellet[] = [];
  public ejected: EjectedMass[] = [];
  public viruses: Virus[] = [];
  public particles: Particle[] = [];
  public ripples: Ripple[] = [];

  public cameraX = WORLD_SIZE / 2;
  public cameraY = WORLD_SIZE / 2;
  public cameraZoom = 1;
  public userZoomMultiplier = 1;

  public pointerScreenX = 0;
  public pointerScreenY = 0;
  public viewportWidth = 1280;
  public viewportHeight = 720;

  public playerAlive = false;
  public peakMass = 0;
  public cellsEaten = 0;
  public foodsEaten = 0;
  public splitsUsed = 0;
  public elapsedSeconds = 0;
  public killerName: string | null = null;

  private time = 0;
  private mode: GameMode = 'classic';
  private theme: ArenaTheme = 'light';
  private showMassOnCells = true;
  private botCounter = 0;
  private botBrains = new Map<string, { targetX: number; targetY: number; cooldown: number }>();
  private onPlayerDeath?: (snapshot: HudSnapshot) => void;

  public isNetworkMode = false;
  private netCellTargets = new Map<string, { x: number; y: number; radius: number; mass: number }>();
  private netHudSnapshot: HudSnapshot | null = null;
  private lastNetMass = 0;
  private lastNetCellCount = 0;

  constructor(onPlayerDeath?: (snapshot: HudSnapshot) => void) {
    this.onPlayerDeath = onPlayerDeath;
    this.initArena();
  }

  public setUserZoom(multiplier: number) {
    this.userZoomMultiplier = clamp(multiplier, 0.55, 1.65);
  }

  public setNetworkMode(enabled: boolean) {
    this.isNetworkMode = enabled;
    this.netCellTargets.clear();
    this.netHudSnapshot = null;
    this.lastNetMass = 0;
    this.lastNetCellCount = 0;
    if (enabled) {
      this.cells = [];
      this.foods = [];
      this.ejected = [];
      this.viruses = [];
      this.particles = [];
      this.ripples = [];
      this.playerAlive = true;
    } else {
      this.initArena();
    }
  }

  public applyNetworkState(payload: NetStatePayload): HudSnapshot {
    const existingById = new Map(this.cells.map((c) => [c.id, c]));
    const nextCells: Cell[] = [];
    const nextTargets = new Map<string, { x: number; y: number; radius: number; mass: number }>();

    for (const nc of payload.cells) {
      const prev = existingById.get(nc.id);
      const isMe = nc.ownerId === payload.playerId;
      nextTargets.set(nc.id, { x: nc.x, y: nc.y, radius: nc.radius, mass: nc.mass });

      if (prev) {
        if (isMe && nc.mass > prev.mass + 2) {
          prev.eatPulse = 0.35;
        }
        prev.name = nc.name;
        prev.skinId = nc.skinId;
        prev.isPlayer = isMe;
        prev.isHuman = nc.isHuman;
        prev.mass = nc.mass;
        nextCells.push(prev);
      } else {
        nextCells.push({
          id: nc.id,
          ownerId: nc.ownerId,
          name: nc.name,
          isPlayer: isMe,
          isHuman: nc.isHuman,
          skinId: nc.skinId,
          x: nc.x,
          y: nc.y,
          vx: 0,
          vy: 0,
          boostVx: 0,
          boostVy: 0,
          mass: nc.mass,
          radius: nc.radius,
          mergeTimer: 0,
          wobblePhase: Math.random() * Math.PI * 2,
          eatPulse: 0.25,
        });
      }
    }

    const myCells = nextCells.filter((c) => c.isPlayer);
    if (this.lastNetMass > 0 && payload.mass > this.lastNetMass) {
      if (payload.mass - this.lastNetMass > 14) {
        soundFX.playEatCell();
      } else {
        soundFX.playEatPellet(payload.mass - this.lastNetMass >= 4.5);
      }
    }
    if (this.lastNetCellCount > 0 && myCells.length > this.lastNetCellCount) {
      soundFX.playSplit();
    }
    this.lastNetMass = payload.mass;
    this.lastNetCellCount = myCells.length;

    this.cells = nextCells;
    this.netCellTargets = nextTargets;
    this.playerAlive = myCells.length > 0;

    this.foods = payload.foods.map((f) => ({
      id: f.id,
      x: f.x,
      y: f.y,
      mass: f.g ? 5 : 1.4,
      radius: f.r,
      color: f.c,
      isGolden: f.g,
      pulseOffset: (f.x + f.y) * 0.01,
    }));

    this.ejected = payload.ejected.map((e) => ({
      id: e.id,
      ownerId: '',
      x: e.x,
      y: e.y,
      vx: 0,
      vy: 0,
      mass: 14,
      radius: e.r,
      color: e.c,
      stroke: e.s,
      age: 0,
    }));

    this.viruses = payload.viruses.map((v) => ({
      id: v.id,
      x: v.x,
      y: v.y,
      vx: 0,
      vy: 0,
      mass: 100,
      radius: v.r,
      feedCount: 0,
      lastFeedAngle: 0,
      pulsePhase: (v.x + v.y) * 0.01,
    }));

    const liveScore = Math.round(
      payload.peakMass * 2 + payload.cellsEaten * 85 + payload.elapsedSeconds * 1.5
    );
    const snapshot: HudSnapshot = {
      mass: payload.mass,
      peakMass: payload.peakMass,
      score: liveScore,
      rank: payload.rank,
      totalPlayers: payload.totalPlayers,
      cellsEaten: payload.cellsEaten,
      cellCount: myCells.length,
      elapsedSeconds: payload.elapsedSeconds,
      leaderboard: payload.leaderboard.slice(0, 5),
      minimapDots: payload.minimapDots,
      worldSize: WORLD_SIZE,
      canSplit: payload.canSplit,
      canEject: payload.canEject,
      killerName: null,
      onlinePlayers: payload.onlinePlayers,
      roomId: payload.roomId,
    };
    this.netHudSnapshot = snapshot;
    return snapshot;
  }

  public setConfig(config: Pick<GameConfig, 'mode' | 'theme' | 'showMassOnCells'>) {
    this.mode = config.mode;
    this.theme = config.theme;
    this.showMassOnCells = config.showMassOnCells;
  }

  public setViewport(width: number, height: number) {
    this.viewportWidth = Math.max(width, 1);
    this.viewportHeight = Math.max(height, 1);
  }

  public setPointerScreen(x: number, y: number) {
    this.pointerScreenX = x;
    this.pointerScreenY = y;
  }

  public initArena() {
    this.cells = [];
    this.foods = [];
    this.ejected = [];
    this.viruses = [];
    this.particles = [];
    this.ripples = [];
    this.botBrains.clear();
    this.playerAlive = false;
    this.peakMass = 0;
    this.cellsEaten = 0;
    this.foodsEaten = 0;
    this.splitsUsed = 0;
    this.elapsedSeconds = 0;
    this.killerName = null;

    for (let i = 0; i < TARGET_FOOD_COUNT; i++) {
      this.spawnFood();
    }
    for (let i = 0; i < TARGET_VIRUS_COUNT; i++) {
      this.spawnVirus();
    }
    for (let i = 0; i < TARGET_BOT_COUNT; i++) {
      this.spawnBot(true);
    }

    this.cameraX = WORLD_SIZE / 2;
    this.cameraY = WORLD_SIZE / 2;
    this.cameraZoom = 0.72;
  }

  public spawnPlayer(config: GameConfig, startMassBonus = 0) {
    this.setConfig(config);
    // Remove any leftover player cells
    this.cells = this.cells.filter((c) => !c.isPlayer);

    const safePos = this.findSafeSpawn(180);
    const startMass = (this.mode === 'blitz' ? 42 : 24) + Math.max(0, startMassBonus);
    const playerCell: Cell = {
      id: nextId('p'),
      ownerId: 'player',
      name: config.nickname.trim() || 'یاریزان',
      isPlayer: true,
      skinId: config.skinId,
      x: safePos.x,
      y: safePos.y,
      vx: 0,
      vy: 0,
      boostVx: 0,
      boostVy: 0,
      mass: startMass,
      radius: massToRadius(startMass),
      mergeTimer: 0,
      wobblePhase: Math.random() * Math.PI * 2,
      eatPulse: 0,
    };

    this.cells.push(playerCell);
    this.playerAlive = true;
    this.peakMass = startMass;
    this.cellsEaten = 0;
    this.foodsEaten = 0;
    this.splitsUsed = 0;
    this.elapsedSeconds = 0;
    this.killerName = null;
    this.cameraX = safePos.x;
    this.cameraY = safePos.y;
    this.cameraZoom = 1.05;
  }

  private findSafeSpawn(padding: number): { x: number; y: number } {
    let best = {
      x: padding + Math.random() * (WORLD_SIZE - padding * 2),
      y: padding + Math.random() * (WORLD_SIZE - padding * 2),
    };
    let bestMinDist = -1;

    for (let attempt = 0; attempt < 16; attempt++) {
      const x = padding + Math.random() * (WORLD_SIZE - padding * 2);
      const y = padding + Math.random() * (WORLD_SIZE - padding * 2);
      let minDist = Infinity;

      for (const c of this.cells) {
        if (c.mass < 35) continue;
        const d = Math.hypot(c.x - x, c.y - y) - c.radius;
        if (d < minDist) minDist = d;
      }
      for (const v of this.viruses) {
        const d = Math.hypot(v.x - x, v.y - y) - v.radius;
        if (d < minDist) minDist = d;
      }

      if (minDist > bestMinDist) {
        bestMinDist = minDist;
        best = { x, y };
      }
      if (minDist > 360) break;
    }

    return best;
  }

  private spawnFood() {
    const isGolden = Math.random() < 0.045;
    const mass = isGolden
      ? this.mode === 'blitz'
        ? 8
        : 5
      : this.mode === 'blitz'
      ? 2.2
      : 1.4;
    const color = isGolden
      ? '#FACC15'
      : PELLET_COLORS[Math.floor(Math.random() * PELLET_COLORS.length)];

    this.foods.push({
      id: nextId('f'),
      x: 40 + Math.random() * (WORLD_SIZE - 80),
      y: 40 + Math.random() * (WORLD_SIZE - 80),
      mass,
      radius: isGolden ? 10.5 : 6.2 + Math.random() * 1.6,
      color,
      isGolden,
      pulseOffset: Math.random() * Math.PI * 2,
    });
  }

  private spawnVirus(x?: number, y?: number, vx = 0, vy = 0) {
    const pos = x !== undefined && y !== undefined ? { x, y } : this.findSafeSpawn(180);
    const mass = 100;
    this.viruses.push({
      id: nextId('v'),
      x: pos.x,
      y: pos.y,
      vx,
      vy,
      mass,
      radius: massToRadius(mass),
      feedCount: 0,
      lastFeedAngle: 0,
      pulsePhase: Math.random() * Math.PI * 2,
    });
  }

  private spawnBot(initial = false) {
    this.botCounter += 1;
    const ownerId = `bot_${this.botCounter}`;
    const name = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)];
    const botSkinPool = SKINS.filter((s) => !s.seasonExclusive);
    const skin = botSkinPool[Math.floor(Math.random() * botSkinPool.length)] || SKINS[0];
    const pos = this.findSafeSpawn(160);

    let mass = 22 + Math.random() * 26;
    if (initial) {
      const roll = Math.random();
      if (roll > 0.85) mass = 160 + Math.random() * 200;
      else if (roll > 0.55) mass = 65 + Math.random() * 90;
    }

    this.cells.push({
      id: nextId('b'),
      ownerId,
      name,
      isPlayer: false,
      skinId: skin.id,
      x: pos.x,
      y: pos.y,
      vx: 0,
      vy: 0,
      boostVx: 0,
      boostVy: 0,
      mass,
      radius: massToRadius(mass),
      mergeTimer: 0,
      wobblePhase: Math.random() * Math.PI * 2,
      eatPulse: 0,
      aiTargetX: Math.random() * WORLD_SIZE,
      aiTargetY: Math.random() * WORLD_SIZE,
      aiCooldown: 0,
    });
  }

  public getPointerWorld(): { x: number; y: number } {
    const dx = (this.pointerScreenX - this.viewportWidth / 2) / this.cameraZoom;
    const dy = (this.pointerScreenY - this.viewportHeight / 2) / this.cameraZoom;
    return {
      x: this.cameraX + dx,
      y: this.cameraY + dy,
    };
  }

  public splitPlayer() {
    if (!this.playerAlive) return;
    const pointer = this.getPointerWorld();
    const didSplit = this.splitOwner('player', pointer.x, pointer.y);
    if (didSplit) {
      this.splitsUsed += 1;
      soundFX.playSplit();
    }
  }

  private splitOwner(ownerId: string, targetX: number, targetY: number): boolean {
    const owned = this.cells.filter((c) => c.ownerId === ownerId);
    if (owned.length >= MAX_CELLS_PER_OWNER) return false;

    const newCells: Cell[] = [];
    let availableSlots = MAX_CELLS_PER_OWNER - owned.length;

    // Sort larger first so biggest cells split first
    const sorted = [...owned].sort((a, b) => b.mass - a.mass);

    for (const cell of sorted) {
      if (availableSlots <= 0) break;
      if (cell.mass < 36) continue;

      const halfMass = cell.mass / 2;
      cell.mass = halfMass;
      cell.radius = massToRadius(halfMass);
      const mergeDelay = Math.max(8.5, 6.5 + halfMass * 0.04);
      cell.mergeTimer = mergeDelay;

      let angle = Math.atan2(targetY - cell.y, targetX - cell.x);
      if (Number.isNaN(angle)) angle = 0;

      const launchSpeed = Math.min(820, 560 + cell.radius * 3.2);
      const childRadius = massToRadius(halfMass);

      const child: Cell = {
        id: nextId(cell.isPlayer ? 'p' : 'b'),
        ownerId: cell.ownerId,
        name: cell.name,
        isPlayer: cell.isPlayer,
        skinId: cell.skinId,
        x: clamp(cell.x + Math.cos(angle) * childRadius * 0.9, childRadius, WORLD_SIZE - childRadius),
        y: clamp(cell.y + Math.sin(angle) * childRadius * 0.9, childRadius, WORLD_SIZE - childRadius),
        vx: cell.vx,
        vy: cell.vy,
        boostVx: Math.cos(angle) * launchSpeed,
        boostVy: Math.sin(angle) * launchSpeed,
        mass: halfMass,
        radius: childRadius,
        mergeTimer: mergeDelay,
        wobblePhase: Math.random() * Math.PI * 2,
        eatPulse: 0.4,
      };

      newCells.push(child);
      availableSlots -= 1;
    }

    if (newCells.length > 0) {
      this.cells.push(...newCells);
      return true;
    }
    return false;
  }

  public ejectPlayerMass(burstCount = 1, playSound = true) {
    if (!this.playerAlive) return;
    const pointer = this.getPointerWorld();
    const owned = this.cells.filter((c) => c.ownerId === 'player');
    const safeBurst = Math.max(1, Math.min(3, Math.round(burstCount)));
    let ejectedAny = false;

    for (let b = 0; b < safeBurst; b++) {
      for (const cell of owned) {
        if (cell.mass < 34) continue;
        cell.mass -= 14;
        cell.radius = massToRadius(cell.mass);
        const baseAngle = Math.atan2(pointer.y - cell.y, pointer.x - cell.x);
        const jitter = safeBurst > 1 ? (Math.random() - 0.5) * 0.14 : 0;
        const angle = baseAngle + jitter;
        const skin = SKIN_MAP[cell.skinId] || SKIN_MAP.ocean;
        const speed = safeBurst > 1 ? 820 : 690;

        this.ejected.push({
          id: nextId('e'),
          ownerId: cell.ownerId,
          x: cell.x + Math.cos(angle) * (cell.radius + 10),
          y: cell.y + Math.sin(angle) * (cell.radius + 10),
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          mass: 14,
          radius: massToRadius(14),
          color: skin.secondary,
          stroke: skin.stroke,
          age: 0,
        });
        ejectedAny = true;
      }
    }

    if (ejectedAny && playSound) {
      soundFX.playEject();
    }
  }

  public addPlayerMass(amount: number): number {
    if (!this.playerAlive || this.isNetworkMode || amount <= 0) return 0;
    const owned = this.cells.filter((c) => c.ownerId === 'player');
    if (owned.length === 0) return 0;
    const perCell = amount / owned.length;
    let total = 0;
    for (const cell of owned) {
      cell.mass = Math.min(250000, cell.mass + perCell);
      cell.radius = massToRadius(cell.mass);
      cell.eatPulse = 0.85;
      total += cell.mass;
    }
    const rounded = Math.round(total);
    if (rounded > this.peakMass) {
      this.peakMass = rounded;
    }
    soundFX.playEatCell();
    return rounded;
  }

  public update(dtRaw: number) {
    const dt = Math.min(dtRaw, 0.05);
    this.time += dt;

    if (this.isNetworkMode) {
      const lerpFactor = Math.min(1, dt * 16);
      for (const cell of this.cells) {
        const target = this.netCellTargets.get(cell.id);
        if (target) {
          cell.x += (target.x - cell.x) * lerpFactor;
          cell.y += (target.y - cell.y) * lerpFactor;
          cell.radius += (target.radius - cell.radius) * lerpFactor;
          cell.mass = target.mass;
        }
        if (cell.eatPulse > 0) {
          cell.eatPulse = Math.max(0, cell.eatPulse - dt * 2.5);
        }
      }
      for (const v of this.viruses) {
        v.pulsePhase += dt * 2.2;
      }
      this.updateEffects(dt);
      this.updatePlayerStatsAndCamera(dt);
      return;
    }

    if (this.playerAlive) {
      this.elapsedSeconds += dt;
    }

    // 1. Compute one unified decision per bot ownerId, then update cell movement
    this.updateUnifiedBotBrains(dt);

    const pointer = this.getPointerWorld();
    const speedMult = this.mode === 'blitz' ? 1.28 : this.mode === 'relaxed' ? 0.96 : 1.0;

    for (const cell of this.cells) {
      if (cell.mergeTimer > 0) {
        cell.mergeTimer = Math.max(0, cell.mergeTimer - dt);
      }
      if (cell.eatPulse > 0) {
        cell.eatPulse = Math.max(0, cell.eatPulse - dt * 2.5);
      }

      // Gentle mass decay for big cells
      if (cell.mass > 140) {
        const decayRate = this.mode === 'blitz' ? 0.0022 : 0.0014;
        cell.mass -= cell.mass * decayRate * dt;
        cell.radius = massToRadius(cell.mass);
      }

      let targetX = cell.x;
      let targetY = cell.y;

      if (cell.isPlayer) {
        targetX = pointer.x;
        targetY = pointer.y;
      } else {
        const brain = this.botBrains.get(cell.ownerId);
        targetX = brain ? brain.targetX : (cell.aiTargetX ?? cell.x);
        targetY = brain ? brain.targetY : (cell.aiTargetY ?? cell.y);
      }

      const dx = targetX - cell.x;
      const dy = targetY - cell.y;
      const dist = Math.hypot(dx, dy);

      const baseSpeed = (340 / Math.pow(cell.mass, 0.34)) * speedMult;
      const throttle = dist < 12 ? dist / 12 : 1;

      if (dist > 0.5) {
        const desiredVx = (dx / dist) * baseSpeed * throttle;
        const desiredVy = (dy / dist) * baseSpeed * throttle;
        const accel = 9.5 * dt;
        cell.vx += (desiredVx - cell.vx) * Math.min(1, accel);
        cell.vy += (desiredVy - cell.vy) * Math.min(1, accel);
      } else {
        cell.vx *= 0.85;
        cell.vy *= 0.85;
      }

      // Decay boost velocity
      cell.boostVx *= Math.pow(0.03, dt);
      cell.boostVy *= Math.pow(0.03, dt);

      cell.x += (cell.vx + cell.boostVx) * dt;
      cell.y += (cell.vy + cell.boostVy) * dt;

      // Arena bounds clamping
      if (cell.x < cell.radius) {
        cell.x = cell.radius;
        cell.boostVx = Math.abs(cell.boostVx) * 0.4;
      } else if (cell.x > WORLD_SIZE - cell.radius) {
        cell.x = WORLD_SIZE - cell.radius;
        cell.boostVx = -Math.abs(cell.boostVx) * 0.4;
      }
      if (cell.y < cell.radius) {
        cell.y = cell.radius;
        cell.boostVy = Math.abs(cell.boostVy) * 0.4;
      } else if (cell.y > WORLD_SIZE - cell.radius) {
        cell.y = WORLD_SIZE - cell.radius;
        cell.boostVy = -Math.abs(cell.boostVy) * 0.4;
      }
    }

    // 2. Same-owner repulsion / merging
    this.resolveSameOwnerInteractions(dt);

    // 3. Ejected mass physics & virus feeding
    this.updateEjectedMass(dt);

    // 4. Virus physics & cell collisions
    this.updateViruses(dt);

    // 5. Food eating
    this.resolveFoodEating();

    // 6. Cell vs Cell eating
    this.resolveCellEating();

    // 7. Particles & ripples
    this.updateEffects(dt);

    // 8. Replenish food, viruses, and bots
    while (this.foods.length < TARGET_FOOD_COUNT) {
      this.spawnFood();
    }
    while (this.viruses.length < TARGET_VIRUS_COUNT) {
      this.spawnVirus();
    }
    const activeBotOwners = new Set(this.cells.filter((c) => !c.isPlayer).map((c) => c.ownerId));
    while (activeBotOwners.size < TARGET_BOT_COUNT) {
      this.spawnBot(false);
      const latest = this.cells[this.cells.length - 1];
      if (latest) activeBotOwners.add(latest.ownerId);
    }

    // 9. Update player stats & camera
    this.updatePlayerStatsAndCamera(dt);
  }

  private updateUnifiedBotBrains(dt: number) {
    const groups = new Map<string, Cell[]>();
    for (const c of this.cells) {
      if (c.isPlayer) continue;
      let list = groups.get(c.ownerId);
      if (!list) {
        list = [];
        groups.set(c.ownerId, list);
      }
      list.push(c);
    }

    // Remove dead bot brains
    for (const ownerId of this.botBrains.keys()) {
      if (!groups.has(ownerId)) {
        this.botBrains.delete(ownerId);
      }
    }

    const aggression = this.mode === 'relaxed' ? 0.55 : this.mode === 'blitz' ? 1.15 : 0.9;

    for (const [ownerId, owned] of groups) {
      let brain = this.botBrains.get(ownerId);
      if (!brain) {
        brain = {
          targetX: owned[0].aiTargetX ?? Math.random() * WORLD_SIZE,
          targetY: owned[0].aiTargetY ?? Math.random() * WORLD_SIZE,
          cooldown: 0,
        };
        this.botBrains.set(ownerId, brain);
      }
      brain.cooldown = Math.max(0, brain.cooldown - dt);

      // Compute center of mass and largest/smallest cell for this single unified bot
      let totalMass = 0;
      let sumX = 0;
      let sumY = 0;
      let largest = owned[0];
      let smallest = owned[0];
      for (const c of owned) {
        totalMass += c.mass;
        sumX += c.x * c.mass;
        sumY += c.y * c.mass;
        if (c.mass > largest.mass) largest = c;
        if (c.mass < smallest.mass) smallest = c;
      }
      const cx = sumX / totalMass;
      const cy = sumY / totalMass;

      let fleeX = 0;
      let fleeY = 0;
      let fleeing = false;
      let bestPrey: Cell | null = null;
      let bestPreyScore = -Infinity;

      for (const other of this.cells) {
        if (other.ownerId === ownerId) continue;
        const dx = other.x - cx;
        const dy = other.y - cy;
        const dist = Math.hypot(dx, dy);
        if (dist > 680) continue;

        if (other.mass > smallest.mass * 1.2) {
          const threatWeight = (680 - dist) / 680;
          fleeX -= (dx / (dist || 1)) * threatWeight * 2.3;
          fleeY -= (dy / (dist || 1)) * threatWeight * 2.3;
          fleeing = true;
        } else if (largest.mass > other.mass * 1.28 * (1 / aggression) && owned.length <= 4) {
          const score = other.mass * 3 - dist * 0.45;
          if (score > bestPreyScore) {
            bestPreyScore = score;
            bestPrey = other;
          }
        }
      }

      if (largest.mass >= 115) {
        for (const v of this.viruses) {
          const dx = v.x - largest.x;
          const dy = v.y - largest.y;
          const dist = Math.hypot(dx, dy);
          if (dist < largest.radius + v.radius + 95) {
            fleeX -= (dx / (dist || 1)) * 1.6;
            fleeY -= (dy / (dist || 1)) * 1.6;
            fleeing = true;
          }
        }
      }

      if (fleeing && (Math.abs(fleeX) > 0.05 || Math.abs(fleeY) > 0.05)) {
        brain.targetX = clamp(cx + fleeX * 320, 120, WORLD_SIZE - 120);
        brain.targetY = clamp(cy + fleeY * 320, 120, WORLD_SIZE - 120);
        continue;
      }

      if (bestPrey) {
        brain.targetX = bestPrey.x;
        brain.targetY = bestPrey.y;

        const distToPrey = Math.hypot(bestPrey.x - largest.x, bestPrey.y - largest.y);
        if (
          brain.cooldown <= 0 &&
          owned.length < 4 &&
          largest.mass >= 75 &&
          largest.mass > bestPrey.mass * 2.7 &&
          distToPrey > largest.radius * 1.3 &&
          distToPrey < 320 &&
          Math.random() < 0.08 * aggression
        ) {
          brain.cooldown = 6.5;
          this.splitOwner(ownerId, bestPrey.x, bestPrey.y);
        }
        continue;
      }

      // When split into multiple pieces, steer smoothly from center of mass toward nearby food so pieces regroup & merge together
      if (
        Math.hypot(brain.targetX - cx, brain.targetY - cy) < largest.radius + 35
      ) {
        let bestFood: FoodPellet | null = null;
        let bestFoodScore = -Infinity;

        for (let i = 0; i < Math.min(this.foods.length, 85); i++) {
          const f = this.foods[Math.floor(Math.random() * this.foods.length)];
          const d = Math.hypot(f.x - cx, f.y - cy);
          const val = (f.isGolden ? 180 : 30) - d * 0.22;
          if (val > bestFoodScore) {
            bestFoodScore = val;
            bestFood = f;
          }
        }

        if (bestFood) {
          brain.targetX = bestFood.x;
          brain.targetY = bestFood.y;
        } else {
          brain.targetX = 200 + Math.random() * (WORLD_SIZE - 400);
          brain.targetY = 200 + Math.random() * (WORLD_SIZE - 400);
        }
      }
    }
  }

  private resolveSameOwnerInteractions(dt: number) {
    const removedIds = new Set<string>();

    for (let i = 0; i < this.cells.length; i++) {
      const a = this.cells[i];
      if (removedIds.has(a.id)) continue;

      for (let j = i + 1; j < this.cells.length; j++) {
        const b = this.cells[j];
        if (removedIds.has(b.id)) continue;
        if (a.ownerId !== b.ownerId) continue;

        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy);
        const minDist = a.radius + b.radius;

        const canMerge = a.mergeTimer <= 0 && b.mergeTimer <= 0;

        if (canMerge) {
          if (dist < minDist * 0.65) {
            const eater = a.mass >= b.mass ? a : b;
            const prey = a.mass >= b.mass ? b : a;
            eater.mass += prey.mass;
            eater.radius = massToRadius(eater.mass);
            eater.eatPulse = 0.5;
            removedIds.add(prey.id);
          } else if (dist < minDist * 2.2 && dist > 1) {
            // Gentle attraction so ready cells merge cleanly
            const pull = 55 * dt;
            a.x += (dx / dist) * pull;
            a.y += (dy / dist) * pull;
            b.x -= (dx / dist) * pull;
            b.y -= (dy / dist) * pull;
          }
        } else if (dist < minDist && dist > 0.001) {
          // Elastic separation while on merge cooldown
          const overlap = minDist - dist;
          const nx = dx / dist;
          const ny = dy / dist;
          const totalMass = a.mass + b.mass;
          const ratioA = b.mass / totalMass;
          const ratioB = a.mass / totalMass;

          a.x -= nx * overlap * ratioA * 0.65;
          a.y -= ny * overlap * ratioA * 0.65;
          b.x += nx * overlap * ratioB * 0.65;
          b.y += ny * overlap * ratioB * 0.65;
        }
      }
    }

    if (removedIds.size > 0) {
      this.cells = this.cells.filter((c) => !removedIds.has(c.id));
    }
  }

  private updateEjectedMass(dt: number) {
    const remaining: EjectedMass[] = [];

    for (const e of this.ejected) {
      e.age += dt;
      e.vx *= Math.pow(0.04, dt);
      e.vy *= Math.pow(0.04, dt);
      e.x = clamp(e.x + e.vx * dt, e.radius, WORLD_SIZE - e.radius);
      e.y = clamp(e.y + e.vy * dt, e.radius, WORLD_SIZE - e.radius);

      let consumed = false;

      // Check virus feeding
      for (const v of this.viruses) {
        if (Math.hypot(e.x - v.x, e.y - v.y) < v.radius + e.radius * 0.5) {
          v.feedCount += 1;
          v.lastFeedAngle = Math.atan2(e.vy, e.vx);
          v.mass += 6;
          v.radius = massToRadius(v.mass);
          consumed = true;

          if (v.feedCount >= 7 && this.viruses.length < MAX_VIRUS_COUNT) {
            v.feedCount = 0;
            v.mass = 100;
            v.radius = massToRadius(100);
            const angle = v.lastFeedAngle;
            this.spawnVirus(
              clamp(v.x + Math.cos(angle) * (v.radius * 2 + 12), 100, WORLD_SIZE - 100),
              clamp(v.y + Math.sin(angle) * (v.radius * 2 + 12), 100, WORLD_SIZE - 100),
              Math.cos(angle) * 580,
              Math.sin(angle) * 580
            );
          }
          break;
        }
      }

      if (consumed) continue;

      // Check cell eating ejected mass
      for (const c of this.cells) {
        if (c.ownerId === e.ownerId && e.age < 0.28) continue;
        if (Math.hypot(e.x - c.x, e.y - c.y) < c.radius) {
          c.mass += e.mass;
          c.radius = massToRadius(c.mass);
          c.eatPulse = 0.25;
          if (c.isPlayer) soundFX.playEatPellet(false);
          consumed = true;
          break;
        }
      }

      if (!consumed && e.age < 45) {
        remaining.push(e);
      }
    }

    this.ejected = remaining;
  }

  private updateViruses(dt: number) {
    const newFragments: Cell[] = [];
    const poppedViruses = new Set<string>();

    for (const v of this.viruses) {
      v.pulsePhase += dt * 2.2;
      v.vx *= Math.pow(0.06, dt);
      v.vy *= Math.pow(0.06, dt);
      v.x = clamp(v.x + v.vx * dt, v.radius + 20, WORLD_SIZE - v.radius - 20);
      v.y = clamp(v.y + v.vy * dt, v.radius + 20, WORLD_SIZE - v.radius - 20);

      for (const cell of this.cells) {
        if (cell.mass < 122) continue;
        const dist = Math.hypot(cell.x - v.x, cell.y - v.y);
        if (dist < cell.radius - v.radius * 0.2) {
          poppedViruses.add(v.id);
          const ownerCount = this.cells.filter((c) => c.ownerId === cell.ownerId).length + newFragments.filter((c) => c.ownerId === cell.ownerId).length;
          const maxSplits = Math.min(8, MAX_CELLS_PER_OWNER - ownerCount);

          cell.mass += 24;
          if (maxSplits > 0) {
            const totalPieces = maxSplits + 1;
            const pieceMass = Math.max(16, cell.mass / totalPieces);
            cell.mass = pieceMass;
            cell.radius = massToRadius(pieceMass);
            cell.mergeTimer = 14;

            for (let k = 0; k < maxSplits; k++) {
              const angle = (k * Math.PI * 2) / maxSplits + (Math.random() - 0.5) * 0.3;
              const speed = 420 + Math.random() * 240;
              const r = massToRadius(pieceMass);
              newFragments.push({
                id: nextId(cell.isPlayer ? 'p' : 'b'),
                ownerId: cell.ownerId,
                name: cell.name,
                isPlayer: cell.isPlayer,
                skinId: cell.skinId,
                x: clamp(cell.x + Math.cos(angle) * (r * 0.9), r, WORLD_SIZE - r),
                y: clamp(cell.y + Math.sin(angle) * (r * 0.9), r, WORLD_SIZE - r),
                vx: cell.vx,
                vy: cell.vy,
                boostVx: Math.cos(angle) * speed,
                boostVy: Math.sin(angle) * speed,
                mass: pieceMass,
                radius: r,
                mergeTimer: 14,
                wobblePhase: Math.random() * Math.PI * 2,
                eatPulse: 0.6,
              });
            }
          } else {
            cell.radius = massToRadius(cell.mass);
          }

          this.spawnExplosion(v.x, v.y, '#22C55E', 18);
          this.ripples.push({
            x: v.x,
            y: v.y,
            radius: v.radius,
            maxRadius: v.radius * 2.8,
            color: '#22C55E',
            alpha: 0.65,
          });
          if (cell.isPlayer) {
            soundFX.playVirusPop();
          }
          break;
        }
      }
    }

    if (poppedViruses.size > 0) {
      this.viruses = this.viruses.filter((v) => !poppedViruses.has(v.id));
    }
    if (newFragments.length > 0) {
      this.cells.push(...newFragments);
    }
  }

  private resolveFoodEating() {
    const remainingFoods: FoodPellet[] = [];

    for (const f of this.foods) {
      let eaten = false;
      for (const c of this.cells) {
        const dx = f.x - c.x;
        const dy = f.y - c.y;
        if (Math.abs(dx) > c.radius || Math.abs(dy) > c.radius) continue;
        if (dx * dx + dy * dy < c.radius * c.radius) {
          c.mass += f.mass;
          c.radius = massToRadius(c.mass);
          c.eatPulse = Math.min(0.45, c.eatPulse + 0.14);
          if (c.isPlayer) {
            this.foodsEaten += 1;
            soundFX.playEatPellet(f.isGolden);
          }
          if (f.isGolden) {
            this.spawnExplosion(f.x, f.y, '#FACC15', 8);
          }
          eaten = true;
          break;
        }
      }
      if (!eaten) {
        remainingFoods.push(f);
      }
    }

    this.foods = remainingFoods;
  }

  private resolveCellEating() {
    const deadIds = new Set<string>();
    const sorted = [...this.cells].sort((a, b) => b.mass - a.mass);

    for (let i = 0; i < sorted.length; i++) {
      const eater = sorted[i];
      if (deadIds.has(eater.id)) continue;

      for (let j = i + 1; j < sorted.length; j++) {
        const prey = sorted[j];
        if (deadIds.has(prey.id)) continue;
        if (eater.ownerId === prey.ownerId) continue;
        if (eater.mass <= prey.mass * 1.22) continue;

        const dist = Math.hypot(eater.x - prey.x, eater.y - prey.y);
        if (dist < eater.radius - prey.radius * 0.32) {
          eater.mass += prey.mass;
          eater.radius = massToRadius(eater.mass);
          eater.eatPulse = 0.7;
          deadIds.add(prey.id);

          const skin = SKIN_MAP[prey.skinId] || SKIN_MAP.ocean;
          this.spawnExplosion(prey.x, prey.y, skin.secondary, 12);
          this.ripples.push({
            x: eater.x,
            y: eater.y,
            radius: eater.radius * 0.85,
            maxRadius: eater.radius * 1.45,
            color: SKIN_MAP[eater.skinId]?.secondary || '#38BDF8',
            alpha: 0.45,
          });

          if (eater.isPlayer) {
            this.cellsEaten += 1;
            soundFX.playEatCell();
          }

          if (prey.isPlayer) {
            const remainingPlayerCells = this.cells.filter(
              (c) => c.isPlayer && !deadIds.has(c.id)
            );
            if (remainingPlayerCells.length === 0) {
              this.killerName = eater.name;
            }
          }
        }
      }
    }

    if (deadIds.size > 0) {
      this.cells = this.cells.filter((c) => !deadIds.has(c.id));
    }
  }

  private spawnExplosion(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 70 + Math.random() * 220;
      const maxLife = 0.35 + Math.random() * 0.3;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: 3 + Math.random() * 4.5,
        color,
        alpha: 1,
        life: 0,
        maxLife,
      });
    }
  }

  private updateEffects(dt: number) {
    const nextParticles: Particle[] = [];
    for (const p of this.particles) {
      p.life += dt;
      if (p.life >= p.maxLife) continue;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= Math.pow(0.15, dt);
      p.vy *= Math.pow(0.15, dt);
      p.alpha = 1 - p.life / p.maxLife;
      nextParticles.push(p);
    }
    this.particles = nextParticles;

    const nextRipples: Ripple[] = [];
    for (const r of this.ripples) {
      r.radius += (r.maxRadius - r.radius) * Math.min(1, dt * 8);
      r.alpha -= dt * 1.4;
      if (r.alpha > 0.02) nextRipples.push(r);
    }
    this.ripples = nextRipples;
  }

  private updatePlayerStatsAndCamera(dt: number) {
    const playerCells = this.cells.filter((c) => c.isPlayer);

    if (!this.isNetworkMode && this.playerAlive && playerCells.length === 0) {
      this.playerAlive = false;
      soundFX.playGameOver();
      if (this.onPlayerDeath) {
        this.onPlayerDeath(this.getHudSnapshot());
      }
      return;
    }

    if (playerCells.length > 0) {
      let totalMass = 0;
      let sumX = 0;
      let sumY = 0;
      let minX = Infinity;
      let maxX = -Infinity;
      let minY = Infinity;
      let maxY = -Infinity;

      for (const c of playerCells) {
        totalMass += c.mass;
        sumX += c.x * c.mass;
        sumY += c.y * c.mass;
        if (c.x - c.radius < minX) minX = c.x - c.radius;
        if (c.x + c.radius > maxX) maxX = c.x + c.radius;
        if (c.y - c.radius < minY) minY = c.y - c.radius;
        if (c.y + c.radius > maxY) maxY = c.y + c.radius;
      }

      if (totalMass > this.peakMass) {
        this.peakMass = totalMass;
      }

      const cx = sumX / totalMass;
      const cy = sumY / totalMass;

      const spread = Math.max(maxX - minX, maxY - minY);
      const effectiveRadius = Math.max(massToRadius(totalMass), spread * 0.52);
      const viewportScale = this.viewportWidth < 640 ? 0.78 : 1.0;
      const targetZoom = clamp(
        Math.pow(62 / effectiveRadius, 0.42) * viewportScale * this.userZoomMultiplier,
        0.22,
        1.85
      );

      const camSmooth = Math.min(1, dt * 7.5);
      this.cameraX += (cx - this.cameraX) * camSmooth;
      this.cameraY += (cy - this.cameraY) * camSmooth;
      this.cameraZoom += (targetZoom - this.cameraZoom) * Math.min(1, dt * 5);
    } else {
      // Spectate the top cell gently in background
      const leader = this.cells.reduce<Cell | null>(
        (best, c) => (!best || c.mass > best.mass ? c : best),
        null
      );
      if (leader) {
        const camSmooth = Math.min(1, dt * 1.8);
        this.cameraX += (leader.x - this.cameraX) * camSmooth;
        this.cameraY += (leader.y - this.cameraY) * camSmooth;
        this.cameraZoom += (0.65 - this.cameraZoom) * Math.min(1, dt * 1.5);
      }
    }
  }

  public getHudSnapshot(): HudSnapshot {
    const ownerTotals = new Map<
      string,
      { ownerId: string; name: string; mass: number; isPlayer: boolean; skinId: SkinId; x: number; y: number }
    >();

    for (const c of this.cells) {
      const existing = ownerTotals.get(c.ownerId);
      if (existing) {
        existing.x = (existing.x * existing.mass + c.x * c.mass) / (existing.mass + c.mass);
        existing.y = (existing.y * existing.mass + c.y * c.mass) / (existing.mass + c.mass);
        existing.mass += c.mass;
      } else {
        ownerTotals.set(c.ownerId, {
          ownerId: c.ownerId,
          name: c.name,
          mass: c.mass,
          isPlayer: c.isPlayer,
          skinId: c.skinId,
          x: c.x,
          y: c.y,
        });
      }
    }

    if (this.isNetworkMode && this.netHudSnapshot) {
      return this.netHudSnapshot;
    }

    const sorted = Array.from(ownerTotals.values()).sort((a, b) => b.mass - a.mass);
    const leaderboard: LeaderboardEntry[] = sorted.slice(0, 5).map((entry, idx) => ({
      ownerId: entry.ownerId,
      name: entry.name,
      mass: Math.round(entry.mass),
      isPlayer: entry.isPlayer,
      skinId: entry.skinId,
      rank: idx + 1,
    }));

    const playerIndex = sorted.findIndex((e) => e.isPlayer);
    const playerEntry = playerIndex >= 0 ? sorted[playerIndex] : null;
    const playerCells = this.cells.filter((c) => c.isPlayer);

    const leaderId = sorted[0]?.ownerId;
    const minimapDots: MinimapDot[] = [];

    for (const c of this.cells) {
      if (c.isPlayer || c.ownerId === leaderId) {
        minimapDots.push({
          x: c.x,
          y: c.y,
          radius: c.radius,
          isPlayer: c.isPlayer,
          isLeader: c.ownerId === leaderId,
        });
      }
    }

    return {
      mass: playerEntry ? Math.round(playerEntry.mass) : 0,
      peakMass: Math.round(this.peakMass),
      score: Math.round(this.peakMass * 2 + this.cellsEaten * 85 + this.elapsedSeconds * 1.5),
      rank: playerIndex >= 0 ? playerIndex + 1 : 0,
      totalPlayers: sorted.length,
      cellsEaten: this.cellsEaten,
      cellCount: playerCells.length,
      elapsedSeconds: Math.floor(this.elapsedSeconds),
      leaderboard,
      minimapDots,
      worldSize: WORLD_SIZE,
      canSplit:
        playerCells.length < MAX_CELLS_PER_OWNER && playerCells.some((c) => c.mass >= 36),
      canEject: playerCells.some((c) => c.mass >= 34),
      killerName: this.killerName,
      foodsEaten: this.foodsEaten,
      splitsUsed: this.splitsUsed,
    };
  }

  public render(ctx: CanvasRenderingContext2D) {
    const w = this.viewportWidth;
    const h = this.viewportHeight;
    const isDark = this.theme === 'dark';

    // Background fill
    ctx.fillStyle = isDark ? '#0B1120' : '#F8FAFC';
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.scale(this.cameraZoom, this.cameraZoom);
    ctx.translate(-this.cameraX, -this.cameraY);

    const halfW = w / (2 * this.cameraZoom) + 160;
    const halfH = h / (2 * this.cameraZoom) + 160;
    const viewMinX = this.cameraX - halfW;
    const viewMaxX = this.cameraX + halfW;
    const viewMinY = this.cameraY - halfH;
    const viewMaxY = this.cameraY + halfH;

    // 1. Arena Grid
    this.renderGrid(ctx, viewMinX, viewMaxX, viewMinY, viewMaxY, isDark);

    // 2. Arena Boundary
    ctx.strokeStyle = isDark ? '#334155' : '#CBD5E1';
    ctx.lineWidth = 8;
    ctx.strokeRect(0, 0, WORLD_SIZE, WORLD_SIZE);

    // Subtle outer void tint outside arena bounds
    ctx.fillStyle = isDark ? 'rgba(2, 6, 23, 0.55)' : 'rgba(226, 232, 240, 0.55)';
    if (viewMinX < 0) ctx.fillRect(viewMinX, viewMinY, -viewMinX, viewMaxY - viewMinY);
    if (viewMaxX > WORLD_SIZE)
      ctx.fillRect(WORLD_SIZE, viewMinY, viewMaxX - WORLD_SIZE, viewMaxY - viewMinY);
    if (viewMinY < 0) ctx.fillRect(Math.max(0, viewMinX), viewMinY, Math.min(WORLD_SIZE, viewMaxX) - Math.max(0, viewMinX), -viewMinY);
    if (viewMaxY > WORLD_SIZE)
      ctx.fillRect(Math.max(0, viewMinX), WORLD_SIZE, Math.min(WORLD_SIZE, viewMaxX) - Math.max(0, viewMinX), viewMaxY - WORLD_SIZE);

    // 3. Ripples
    for (const r of this.ripples) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, r.alpha);
      ctx.strokeStyle = r.color;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 4. Food pellets
    for (const f of this.foods) {
      if (f.x < viewMinX || f.x > viewMaxX || f.y < viewMinY || f.y > viewMaxY) continue;
      if (f.isGolden) {
        const pulse = 1 + Math.sin(this.time * 4 + f.pulseOffset) * 0.14;
        ctx.save();
        ctx.fillStyle = 'rgba(250, 204, 21, 0.25)';
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.radius * 1.55 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = f.color;
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.radius * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else {
        ctx.fillStyle = f.color;
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.radius, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 5. Ejected mass
    for (const e of this.ejected) {
      if (e.x < viewMinX || e.x > viewMaxX || e.y < viewMinY || e.y > viewMaxY) continue;
      ctx.fillStyle = e.color;
      ctx.strokeStyle = e.stroke;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    // 6. Particles
    for (const p of this.particles) {
      if (p.x < viewMinX || p.x > viewMaxX || p.y < viewMinY || p.y > viewMaxY) continue;
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 7. Sort cells ascending by mass; interleave viruses at mass 115 so small cells hide under viruses!
    const sortedCells = [...this.cells].sort((a, b) => a.mass - b.mass);
    let virusDrawn = false;

    for (const cell of sortedCells) {
      if (!virusDrawn && cell.mass >= 115) {
        this.renderViruses(ctx, viewMinX, viewMaxX, viewMinY, viewMaxY);
        virusDrawn = true;
      }
      if (
        cell.x + cell.radius < viewMinX ||
        cell.x - cell.radius > viewMaxX ||
        cell.y + cell.radius < viewMinY ||
        cell.y - cell.radius > viewMaxY
      ) {
        continue;
      }
      this.renderCell(ctx, cell);
    }

    if (!virusDrawn) {
      this.renderViruses(ctx, viewMinX, viewMaxX, viewMinY, viewMaxY);
    }

    ctx.restore();
  }

  private renderGrid(
    ctx: CanvasRenderingContext2D,
    minX: number,
    maxX: number,
    minY: number,
    maxY: number,
    isDark: boolean
  ) {
    const step = 64;
    const startX = Math.max(0, Math.floor(minX / step) * step);
    const endX = Math.min(WORLD_SIZE, Math.ceil(maxX / step) * step);
    const startY = Math.max(0, Math.floor(minY / step) * step);
    const endY = Math.min(WORLD_SIZE, Math.ceil(maxY / step) * step);

    ctx.strokeStyle = isDark ? 'rgba(51, 65, 85, 0.32)' : 'rgba(203, 213, 225, 0.52)';
    ctx.lineWidth = 1;
    ctx.beginPath();

    for (let x = startX; x <= endX; x += step) {
      ctx.moveTo(x, startY);
      ctx.lineTo(x, endY);
    }
    for (let y = startY; y <= endY; y += step) {
      ctx.moveTo(startX, y);
      ctx.lineTo(endX, y);
    }
    ctx.stroke();
  }

  private renderViruses(
    ctx: CanvasRenderingContext2D,
    minX: number,
    maxX: number,
    minY: number,
    maxY: number
  ) {
    for (const v of this.viruses) {
      if (
        v.x + v.radius < minX ||
        v.x - v.radius > maxX ||
        v.y + v.radius < minY ||
        v.y - v.radius > maxY
      ) {
        continue;
      }

      const spikes = 22;
      const outerR = v.radius * (1.06 + Math.sin(v.pulsePhase) * 0.02);
      const innerR = v.radius * 0.9;

      ctx.save();
      ctx.beginPath();
      for (let i = 0; i < spikes * 2; i++) {
        const angle = (i * Math.PI) / spikes + v.pulsePhase * 0.08;
        const r = i % 2 === 0 ? outerR : innerR;
        const px = v.x + Math.cos(angle) * r;
        const py = v.y + Math.sin(angle) * r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();

      ctx.fillStyle = 'rgba(34, 197, 94, 0.88)';
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#15803D';
      ctx.stroke();

      // Inner translucent nucleus ring
      ctx.beginPath();
      ctx.arc(v.x, v.y, v.radius * 0.56, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(134, 239, 172, 0.25)';
      ctx.fill();
      ctx.restore();
    }
  }

  private renderCell(ctx: CanvasRenderingContext2D, cell: Cell) {
    const skin = SKIN_MAP[cell.skinId] || SKIN_MAP.ocean;
    const points = cell.radius > 70 ? 48 : cell.radius > 35 ? 36 : 24;
    const pulseScale = 1 + cell.eatPulse * 0.08;

    ctx.save();
    ctx.beginPath();

    for (let i = 0; i < points; i++) {
      const angle = (i * Math.PI * 2) / points;
      const wobbleAmp = Math.min(2.6, cell.radius * 0.025) * (1 + cell.eatPulse * 1.4);
      const wobble =
        Math.sin(angle * 4 + this.time * 4.2 + cell.wobblePhase) * wobbleAmp +
        Math.cos(angle * 3 - this.time * 2.8 + cell.wobblePhase) * (wobbleAmp * 0.5);
      const r = cell.radius * pulseScale + wobble;
      const px = cell.x + Math.cos(angle) * r;
      const py = cell.y + Math.sin(angle) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();

    drawSkinPattern(ctx, cell.skinId, cell.x, cell.y, cell.radius * pulseScale, this.time);

    ctx.lineWidth = Math.max(3, Math.min(8, cell.radius * 0.08));
    ctx.strokeStyle = skin.stroke;
    ctx.stroke();

    // Name & Mass text
    if (cell.radius * this.cameraZoom > 15) {
      const fontSize = Math.max(12, Math.min(44, cell.radius * 0.36));
      ctx.font = `700 ${Math.round(fontSize)}px 'Noto Sans Arabic', 'Outfit', sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.lineJoin = 'round';
      ctx.lineWidth = Math.max(2.5, fontSize * 0.16);
      ctx.strokeStyle = 'rgba(15, 23, 42, 0.72)';
      ctx.fillStyle = '#FFFFFF';

      const yOffset = this.showMassOnCells && cell.radius * this.cameraZoom > 26 ? -fontSize * 0.3 : 0;
      ctx.strokeText(cell.name, cell.x, cell.y + yOffset);
      ctx.fillText(cell.name, cell.x, cell.y + yOffset);

      if (this.showMassOnCells && cell.radius * this.cameraZoom > 26) {
        const massFont = Math.max(10, Math.round(fontSize * 0.58));
        ctx.font = `700 ${massFont}px 'JetBrains Mono', monospace`;
        ctx.lineWidth = Math.max(2, massFont * 0.18);
        const massLabel = String(Math.round(cell.mass));
        ctx.strokeText(massLabel, cell.x, cell.y + fontSize * 0.48);
        ctx.fillText(massLabel, cell.x, cell.y + fontSize * 0.48);
      }
    }

    ctx.restore();
  }
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}
