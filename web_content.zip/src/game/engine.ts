/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowConfig, ArrowEntity, Direction, LevelData, Point } from './types';
import { canArrowEscape, DIR_DELTA, getArrowCells } from './solver';
import { sound } from './audio';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
  rotation: number;
  rotSpeed: number;
  life: number;
  maxLife: number;
}

function distToSegment(
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number
): number {
  const vx = bx - ax;
  const vy = by - ay;
  const wx = px - ax;
  const wy = py - ay;
  const lenSq = vx * vx + vy * vy;
  if (lenSq < 1e-6) return Math.hypot(px - ax, py - ay);
  const t = Math.max(0, Math.min(1, (wx * vx + wy * vy) / lenSq));
  const projX = ax + t * vx;
  const projY = ay + t * vy;
  return Math.hypot(px - projX, py - projY);
}

function slicePolyline(pts: Point[], startDist: number, sliceLen: number): Point[] {
  if (pts.length < 2) return pts;

  const endDist = startDist + sliceLen;
  const result: Point[] = [];
  let accum = 0;

  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    const segLen = Math.hypot(b.x - a.x, b.y - a.y);
    if (segLen < 1e-6) continue;

    const segStart = accum;
    const segEnd = accum + segLen;

    if (segEnd >= startDist && segStart <= endDist) {
      const t0 = Math.max(0, (startDist - segStart) / segLen);
      const t1 = Math.min(1, (endDist - segStart) / segLen);

      const pStart = {
        x: a.x + (b.x - a.x) * t0,
        y: a.y + (b.y - a.y) * t0,
      };
      const pEnd = {
        x: a.x + (b.x - a.x) * t1,
        y: a.y + (b.y - a.y) * t1,
      };

      if (result.length === 0) {
        result.push(pStart);
      } else {
        const last = result[result.length - 1];
        if (Math.hypot(last.x - pStart.x, last.y - pStart.y) > 1e-4) {
          result.push(pStart);
        }
      }
      result.push(pEnd);
    }

    accum = segEnd;
    if (accum >= endDist) break;
  }

  return result;
}

export const MIN_ZOOM = 0.6;
export const MAX_ZOOM = 3.6;

export class ArrowGameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private level: LevelData | null = null;
  private arrows: ArrowEntity[] = [];
  private particles: Particle[] = [];
  private animFrameId: number | null = null;
  private lastTime: number = 0;
  private dpr: number = 1;

  // Base layout metrics
  private boardCenterX: number = 0;
  private boardCenterY: number = 0;
  private cellSize: number = 36;
  private gridMinX: number = 0;
  private gridMaxX: number = 0;
  private gridMinY: number = 0;
  private gridMaxY: number = 0;

  // Camera Zoom & Pan state
  private zoom: number = 1;
  private targetZoom: number = 1;
  private panX: number = 0;
  private targetPanX: number = 0;
  private panY: number = 0;
  private targetPanY: number = 0;

  // Multi-touch & pointer gesture state
  private activePointers: Map<number, Point> = new Map();
  private downPos: Point | null = null;
  private lastSinglePos: Point | null = null;
  private isPanning: boolean = false;
  private isPinching: boolean = false;
  private lastPinchDist: number = 0;
  private lastPinchMid: Point | null = null;
  private pinchCooldownUntil: number = 0;

  // Callbacks
  public onMistake?: () => void;
  public onArrowEscaped?: (remainingCount: number) => void;
  public onLevelCompleted?: () => void;
  public onCombo?: (combo: number) => void;
  public onZoomChange?: (zoom: number) => void;

  private comboCount: number = 0;
  private comboTimer: number = 0;
  private isInteractive: boolean = true;
  private showGrid: boolean = false;
  private hintTime: number = 0;

  private onResizeBound = () => this.handleResize();

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Could not get 2D context');
    this.ctx = ctx;

    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.bindEvents();
    this.handleResize();
    this.startLoop();
  }

  public setInteractive(val: boolean) {
    this.isInteractive = val;
  }

  public setShowGrid(val: boolean) {
    this.showGrid = val;
  }

  public getShowGrid(): boolean {
    return this.showGrid;
  }

  public getZoom(): number {
    return this.zoom;
  }

  public zoomIn() {
    this.setTargetZoomAround(this.targetZoom * 1.28, this.boardCenterX, this.boardCenterY);
  }

  public zoomOut() {
    this.setTargetZoomAround(this.targetZoom / 1.28, this.boardCenterX, this.boardCenterY);
  }

  public resetZoom() {
    this.targetZoom = 1;
    this.targetPanX = 0;
    this.targetPanY = 0;
    this.notifyZoomChange();
  }

  private notifyZoomChange() {
    if (this.onZoomChange) {
      this.onZoomChange(this.targetZoom);
    }
  }

  private clampPan(px: number, py: number, z: number): Point {
    const spanX = Math.max(2, this.gridMaxX - this.gridMinX + 1) * this.cellSize * z;
    const spanY = Math.max(2, this.gridMaxY - this.gridMinY + 1) * this.cellSize * z;
    const w = this.canvas.width / this.dpr;
    const h = this.canvas.height / this.dpr;

    const maxPanX = Math.max(w * 0.4, spanX * 0.55);
    const maxPanY = Math.max(h * 0.4, spanY * 0.55);

    return {
      x: Math.max(-maxPanX, Math.min(maxPanX, px)),
      y: Math.max(-maxPanY, Math.min(maxPanY, py)),
    };
  }

  private setTargetZoomAround(newZoomRaw: number, focalX: number, focalY: number, immediate: boolean = false) {
    const clampedZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, newZoomRaw));
    const oldZoom = immediate ? this.zoom : this.targetZoom;
    const oldPanX = immediate ? this.panX : this.targetPanX;
    const oldPanY = immediate ? this.panY : this.targetPanY;

    // World point relative to boardCenter under focal screen point
    const wx = (focalX - this.boardCenterX - oldPanX) / oldZoom;
    const wy = (focalY - this.boardCenterY - oldPanY) / oldZoom;

    const rawPanX = focalX - this.boardCenterX - wx * clampedZoom;
    const rawPanY = focalY - this.boardCenterY - wy * clampedZoom;
    const clamped = this.clampPan(rawPanX, rawPanY, clampedZoom);

    this.targetZoom = clampedZoom;
    this.targetPanX = clamped.x;
    this.targetPanY = clamped.y;

    if (immediate) {
      this.zoom = clampedZoom;
      this.panX = clamped.x;
      this.panY = clamped.y;
    }

    this.notifyZoomChange();
  }

  public getActiveArrows(): ArrowConfig[] {
    return this.arrows
      .filter((a) => a.state === 'idle' || a.state === 'blocked')
      .map((a) => ({
        id: a.id,
        x: a.x,
        y: a.y,
        dir: a.dir,
        path: a.path,
      }));
  }

  public loadLevel(level: LevelData) {
    this.level = level;
    this.particles = [];
    this.comboCount = 0;
    this.isInteractive = true;

    // Reset camera cleanly for each level
    this.zoom = 1;
    this.targetZoom = 1;
    this.panX = 0;
    this.targetPanX = 0;
    this.panY = 0;
    this.targetPanY = 0;
    this.activePointers.clear();
    this.isPanning = false;
    this.isPinching = false;
    this.notifyZoomChange();

    let minX = Infinity,
      maxX = -Infinity,
      minY = Infinity,
      maxY = -Infinity;

    level.arrows.forEach((a) => {
      const cells = getArrowCells(a);
      for (const c of cells) {
        if (c.x < minX) minX = c.x;
        if (c.x > maxX) maxX = c.x;
        if (c.y < minY) minY = c.y;
        if (c.y > maxY) maxY = c.y;
      }
    });

    // Also include boundaryPath in bounds if present so drawn outline frames cleanly
    if (level.boundaryPath && level.boundaryPath.length > 2) {
      for (const bp of level.boundaryPath) {
        if (bp.x < minX) minX = bp.x;
        if (bp.x > maxX) maxX = bp.x;
        if (bp.y < minY) minY = bp.y;
        if (bp.y > maxY) maxY = bp.y;
      }
    }

    this.gridMinX = minX === Infinity ? 0 : minX;
    this.gridMaxX = maxX === -Infinity ? level.gridWidth - 1 : maxX;
    this.gridMinY = minY === Infinity ? 0 : minY;
    this.gridMaxY = maxY === -Infinity ? level.gridHeight - 1 : maxY;

    this.arrows = level.arrows.map((a) => {
      const normalizedPath =
        a.path && a.path.length > 0 ? a.path.map((p) => ({ x: p.x, y: p.y })) : [{ x: a.x, y: a.y }];
      const head = normalizedPath[normalizedPath.length - 1];
      return {
        id: a.id,
        x: head.x,
        y: head.y,
        dir: a.dir,
        path: normalizedPath,
        length: normalizedPath.length,
        state: 'idle',
        slideDistance: 0,
        slideSpeed: 0,
        shakeTime: 0,
        isHinted: false,
        alpha: 1,
      };
    });

    this.updateLayout();
  }

  public setHint(arrowId: string | null) {
    this.hintTime = 0;
    this.arrows.forEach((a) => {
      a.isHinted = a.id === arrowId;
    });
  }

  public handleResize() {
    const rect = this.canvas.getBoundingClientRect();
    const width = Math.floor(rect.width);
    const height = Math.floor(rect.height);

    if (width === 0 || height === 0) return;

    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = width * this.dpr;
    this.canvas.height = height * this.dpr;

    this.updateLayout();
  }

  private updateLayout() {
    const w = this.canvas.width / this.dpr;
    const h = this.canvas.height / this.dpr;

    this.boardCenterX = w / 2;
    this.boardCenterY = h / 2;

    const spanX = Math.max(2, this.gridMaxX - this.gridMinX + 1);
    const spanY = Math.max(2, this.gridMaxY - this.gridMinY + 1);

    const availableW = w * 0.86;
    const availableH = h * 0.82;

    const cellFromW = availableW / (spanX + 0.8);
    const cellFromH = availableH / (spanY + 0.8);

    this.cellSize = Math.max(11, Math.min(56, Math.min(cellFromW, cellFromH)));
  }

  private gridToScreen(gx: number, gy: number): Point {
    const midX = (this.gridMinX + this.gridMaxX) / 2;
    const midY = (this.gridMinY + this.gridMaxY) / 2;
    const baseX = this.boardCenterX + (gx - midX) * this.cellSize;
    const baseY = this.boardCenterY + (gy - midY) * this.cellSize;

    return {
      x: this.boardCenterX + (baseX - this.boardCenterX) * this.zoom + this.panX,
      y: this.boardCenterY + (baseY - this.boardCenterY) * this.zoom + this.panY,
    };
  }

  private screenToGrid(sx: number, sy: number): Point {
    const midX = (this.gridMinX + this.gridMaxX) / 2;
    const midY = (this.gridMinY + this.gridMaxY) / 2;
    const baseX = this.boardCenterX + (sx - this.boardCenterX - this.panX) / this.zoom;
    const baseY = this.boardCenterY + (sy - this.boardCenterY - this.panY) / this.zoom;

    return {
      x: midX + (baseX - this.boardCenterX) / this.cellSize,
      y: midY + (baseY - this.boardCenterY) / this.cellSize,
    };
  }

  private bindEvents() {
    window.addEventListener('resize', this.onResizeBound);

    const getLocalPos = (clientX: number, clientY: number): Point => {
      const rect = this.canvas.getBoundingClientRect();
      return {
        x: clientX - rect.left,
        y: clientY - rect.top,
      };
    };

    this.canvas.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (this.canvas.setPointerCapture) {
        try {
          this.canvas.setPointerCapture(e.pointerId);
        } catch {
          // ignore
        }
      }

      const pos = getLocalPos(e.clientX, e.clientY);
      this.activePointers.set(e.pointerId, pos);

      if (this.activePointers.size === 1) {
        this.downPos = pos;
        this.lastSinglePos = pos;
        this.isPanning = false;
        this.isPinching = false;
      } else if (this.activePointers.size === 2) {
        // Transition cleanly to two-finger pinch zoom
        this.isPinching = true;
        this.isPanning = false;
        this.downPos = null;
        const pts = Array.from(this.activePointers.values());
        this.lastPinchDist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
        this.lastPinchMid = {
          x: (pts[0].x + pts[1].x) / 2,
          y: (pts[0].y + pts[1].y) / 2,
        };
      }
    });

    this.canvas.addEventListener('pointermove', (e) => {
      if (!this.activePointers.has(e.pointerId)) return;
      e.preventDefault();

      const pos = getLocalPos(e.clientX, e.clientY);
      this.activePointers.set(e.pointerId, pos);

      if (this.activePointers.size >= 2) {
        this.isPinching = true;
        const pts = Array.from(this.activePointers.values());
        const dist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
        const mid = {
          x: (pts[0].x + pts[1].x) / 2,
          y: (pts[0].y + pts[1].y) / 2,
        };

        if (this.lastPinchDist > 5 && this.lastPinchMid) {
          // Pan by midpoint delta
          const dxMid = mid.x - this.lastPinchMid.x;
          const dyMid = mid.y - this.lastPinchMid.y;
          const panned = this.clampPan(this.panX + dxMid, this.panY + dyMid, this.zoom);
          this.panX = panned.x;
          this.panY = panned.y;
          this.targetPanX = panned.x;
          this.targetPanY = panned.y;

          // Scale around pinch midpoint
          const scaleFactor = dist / this.lastPinchDist;
          this.setTargetZoomAround(this.zoom * scaleFactor, mid.x, mid.y, true);
        }

        this.lastPinchDist = dist;
        this.lastPinchMid = mid;
      } else if (this.activePointers.size === 1 && !this.isPinching && this.lastSinglePos) {
        const dx = pos.x - this.lastSinglePos.x;
        const dy = pos.y - this.lastSinglePos.y;

        if (!this.isPanning && this.downPos) {
          const totalDist = Math.hypot(pos.x - this.downPos.x, pos.y - this.downPos.y);
          if (totalDist > 8) {
            this.isPanning = true;
          }
        }

        if (this.isPanning) {
          const clamped = this.clampPan(this.panX + dx, this.panY + dy, this.zoom);
          this.panX = clamped.x;
          this.panY = clamped.y;
          this.targetPanX = clamped.x;
          this.targetPanY = clamped.y;
        }

        this.lastSinglePos = pos;
      }
    });

    const handlePointerUp = (e: PointerEvent) => {
      if (!this.activePointers.has(e.pointerId)) return;
      const pos = getLocalPos(e.clientX, e.clientY);
      this.activePointers.delete(e.pointerId);

      if (this.activePointers.size === 1) {
        // One finger left after pinch -> prevent accidental tap
        if (this.isPinching) {
          this.pinchCooldownUntil = performance.now() + 220;
          const remainingPt = Array.from(this.activePointers.values())[0];
          this.lastSinglePos = remainingPt;
          this.downPos = null;
        }
        this.lastPinchDist = 0;
        this.lastPinchMid = null;
        return;
      }

      if (this.activePointers.size === 0) {
        const now = performance.now();
        const wasGesture = this.isPanning || this.isPinching || now < this.pinchCooldownUntil;

        if (!wasGesture && this.downPos && this.isInteractive) {
          const dist = Math.hypot(pos.x - this.downPos.x, pos.y - this.downPos.y);
          if (dist <= 9) {
            this.processTap(pos.x, pos.y);
          }
        }

        if (this.isPinching) {
          this.pinchCooldownUntil = now + 180;
        }
        this.isPanning = false;
        this.isPinching = false;
        this.downPos = null;
        this.lastSinglePos = null;
        this.lastPinchDist = 0;
        this.lastPinchMid = null;
      }
    };

    this.canvas.addEventListener('pointerup', handlePointerUp);
    this.canvas.addEventListener('pointercancel', handlePointerUp);

    // Desktop Mouse Wheel Zoom centered at cursor
    this.canvas.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        const pos = getLocalPos(e.clientX, e.clientY);
        const factor = Math.exp(-e.deltaY * 0.0016);
        this.setTargetZoomAround(this.targetZoom * factor, pos.x, pos.y, false);
      },
      { passive: false }
    );
  }

  private processTap(touchX: number, touchY: number) {
    let closestArrow: ArrowEntity | null = null;
    let minDistance = Math.max(18, this.cellSize * this.zoom * 0.65);
    const touchGrid = this.screenToGrid(touchX, touchY);
    const gridMargin = minDistance / Math.max(6, this.cellSize * this.zoom) + 0.6;

    for (const a of this.arrows) {
      if (a.state !== 'idle') continue;

      // Fast grid bounding-box pre-check to avoid screen projection on distant arrows
      let bMinX = Infinity;
      let bMaxX = -Infinity;
      let bMinY = Infinity;
      let bMaxY = -Infinity;
      for (const p of a.path) {
        if (p.x < bMinX) bMinX = p.x;
        if (p.x > bMaxX) bMaxX = p.x;
        if (p.y < bMinY) bMinY = p.y;
        if (p.y > bMaxY) bMaxY = p.y;
      }
      if (
        touchGrid.x < bMinX - gridMargin ||
        touchGrid.x > bMaxX + gridMargin ||
        touchGrid.y < bMinY - gridMargin ||
        touchGrid.y > bMaxY + gridMargin
      ) {
        continue;
      }

      let arrowDist = Infinity;
      if (a.path.length === 1) {
        const sp = this.gridToScreen(a.path[0].x, a.path[0].y);
        arrowDist = Math.hypot(sp.x - touchX, sp.y - touchY);
      } else {
        let prevSp = this.gridToScreen(a.path[0].x, a.path[0].y);
        for (let i = 0; i < a.path.length - 1; i++) {
          const nextSp = this.gridToScreen(a.path[i + 1].x, a.path[i + 1].y);
          const d = distToSegment(touchX, touchY, prevSp.x, prevSp.y, nextSp.x, nextSp.y);
          if (d < arrowDist) arrowDist = d;
          prevSp = nextSp;
        }
      }

      if (arrowDist < minDistance) {
        minDistance = arrowDist;
        closestArrow = a;
      }
    }

    if (!closestArrow) return;

    const activeConfigs: ArrowConfig[] = this.getActiveArrows();
    const { canEscape, blockerCell } = canArrowEscape(
      {
        id: closestArrow.id,
        x: closestArrow.x,
        y: closestArrow.y,
        dir: closestArrow.dir,
        path: closestArrow.path,
      },
      activeConfigs
    );

    if (canEscape) {
      sound.playTap();
      this.comboCount++;
      this.comboTimer = 2.0;
      sound.playEscape(this.comboCount);

      if (this.onCombo && this.comboCount > 1) {
        this.onCombo(this.comboCount);
      }

      closestArrow.state = 'flying';
      closestArrow.isHinted = false;
      closestArrow.slideDistance = 0;
      closestArrow.slideSpeed = 14;

      const headScreen = this.gridToScreen(closestArrow.x, closestArrow.y);
      this.spawnTrailParticles(headScreen.x, headScreen.y, closestArrow.dir);

      const remaining = this.arrows.filter(
        (a) => a.state === 'idle' || a.state === 'blocked'
      ).length;

      if (this.onArrowEscaped) {
        this.onArrowEscaped(remaining);
      }

      if (remaining === 0) {
        this.isInteractive = false;
        setTimeout(() => {
          this.triggerVictoryCelebration();
          if (this.onLevelCompleted) {
            this.onLevelCompleted();
          }
        }, 380);
      }
    } else {
      sound.playBlocked();
      closestArrow.state = 'blocked';
      closestArrow.shakeTime = 320;

      if (blockerCell) {
        const blockScreen = this.gridToScreen(blockerCell.x, blockerCell.y);
        this.spawnSparks(blockScreen.x, blockScreen.y);
      } else {
        const headScreen = this.gridToScreen(closestArrow.x, closestArrow.y);
        this.spawnSparks(headScreen.x, headScreen.y);
      }

      this.comboCount = 0;
      if (this.onMistake) {
        this.onMistake();
      }
    }
  }

  private spawnTrailParticles(x: number, y: number, dir: Direction) {
    const { dx, dy } = DIR_DELTA[dir];
    for (let i = 0; i < 6; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * 10,
        y: y + (Math.random() - 0.5) * 10,
        vx: -dx * (Math.random() * 3 + 1.5) + (Math.random() - 0.5) * 1.5,
        vy: -dy * (Math.random() * 3 + 1.5) + (Math.random() - 0.5) * 1.5,
        size: Math.random() * 3.5 + 2,
        alpha: 0.75,
        color: '#2563EB',
        rotation: 0,
        rotSpeed: 0,
        life: 0,
        maxLife: 18 + Math.random() * 12,
      });
    }
  }

  private spawnSparks(x: number, y: number) {
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 3.5 + 1.2;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: Math.random() * 3 + 1.5,
        alpha: 0.9,
        color: '#EF4444',
        rotation: 0,
        rotSpeed: 0,
        life: 0,
        maxLife: 16 + Math.random() * 10,
      });
    }
  }

  public triggerVictoryCelebration() {
    sound.playVictory();
    const colors = ['#2563EB', '#38BDF8', '#10B981', '#F59E0B', '#EC4899', '#8B5CF6'];

    for (let i = 0; i < 55; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 8 + 3.5;
      this.particles.push({
        x: this.boardCenterX,
        y: this.boardCenterY - 20,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2.5,
        size: Math.random() * 7 + 4,
        alpha: 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * Math.PI,
        rotSpeed: (Math.random() - 0.5) * 0.2,
        life: 0,
        maxLife: 75 + Math.random() * 35,
      });
    }
  }

  private startLoop() {
    const loop = (timestamp: number) => {
      if (!this.lastTime) this.lastTime = timestamp;
      const dt = Math.min((timestamp - this.lastTime) / 1000, 0.05);
      this.lastTime = timestamp;

      this.update(dt);
      this.render();

      this.animFrameId = requestAnimationFrame(loop);
    };

    this.animFrameId = requestAnimationFrame(loop);
  }

  public destroy() {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    window.removeEventListener('resize', this.onResizeBound);
  }

  private update(dt: number) {
    this.hintTime += dt;

    // Smooth camera interpolation for buttons, wheel, and reset zoom
    const lerp = 1 - Math.exp(-16 * dt);
    if (Math.abs(this.targetZoom - this.zoom) > 0.0005) {
      this.zoom += (this.targetZoom - this.zoom) * lerp;
    } else {
      this.zoom = this.targetZoom;
    }
    if (Math.abs(this.targetPanX - this.panX) > 0.1) {
      this.panX += (this.targetPanX - this.panX) * lerp;
    } else {
      this.panX = this.targetPanX;
    }
    if (Math.abs(this.targetPanY - this.panY) > 0.1) {
      this.panY += (this.targetPanY - this.panY) * lerp;
    } else {
      this.panY = this.targetPanY;
    }

    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) {
        this.comboCount = 0;
      }
    }

    const w = this.canvas.width / this.dpr;
    const h = this.canvas.height / this.dpr;
    const maxCellsOffscreen =
      Math.max(w, h) / Math.max(8, this.cellSize * this.zoom) + 8;

    for (const a of this.arrows) {
      if (a.state === 'flying') {
        a.slideSpeed += 38 * dt;
        a.slideDistance += a.slideSpeed * dt;

        const pathLen = Math.max(0.5, a.path.length - 1);
        if (a.slideDistance > pathLen + maxCellsOffscreen) {
          a.state = 'escaped';
        }
      } else if (a.state === 'blocked') {
        a.shakeTime -= dt * 1000;
        if (a.shakeTime <= 0) {
          a.shakeTime = 0;
          a.state = 'idle';
        }
      }
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life++;
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.14;
      p.rotation += p.rotSpeed;
      p.alpha = 1 - p.life / p.maxLife;

      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
      }
    }
  }

  private render() {
    const ctx = this.ctx;
    const w = this.canvas.width / this.dpr;
    const h = this.canvas.height / this.dpr;

    ctx.save();
    ctx.scale(this.dpr, this.dpr);

    // 1. Crisp pure white background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    // 2. Subtle Dotted Grid Background (scales & moves with zoom/pan behind arrows)
    this.renderDottedGrid(ctx, w, h);

    // 3. Optional crisp Grid Lines overlay when # Grid Toggle is ON
    if (this.showGrid && this.level) {
      this.renderGridOverlay(ctx);
    }

    // 4. Preserved Drawn Shape Outline (rendered only for user-drawn custom levels)
    if (
      this.level &&
      this.level.boundaryPath &&
      this.level.boundaryPath.length > 2 &&
      (this.level.isCustomDrawn || String(this.level.id).startsWith('custom_'))
    ) {
      this.renderShapeBoundary(ctx, this.level.boundaryPath);
    }

    // 5. Render idle navy-blue arrows in two batched draw calls (shafts + heads) for 60fps on 100+ arrow mazes
    this.renderIdleArrowsBatched(ctx);

    // Render active/animated arrows (blocked, flying, hinted) individually on top
    for (const arrow of this.arrows) {
      if (arrow.state === 'escaped' || (arrow.state === 'idle' && !arrow.isHinted)) continue;
      if (!arrow.isHinted) {
        this.renderPolylineArrow(ctx, arrow);
      }
    }
    for (const arrow of this.arrows) {
      if (arrow.state === 'escaped' || !arrow.isHinted) continue;
      this.renderPolylineArrow(ctx, arrow);
    }

    // 6. Render particles
    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      ctx.restore();
    }

    ctx.restore();
  }

  /**
   * Renders evenly spaced light-grey dots across the entire viewport in grid coordinates
   * so they scale and pan seamlessly behind the puzzle arrows.
   */
  private renderDottedGrid(ctx: CanvasRenderingContext2D, w: number, h: number) {
    const topLeftGrid = this.screenToGrid(0, 0);
    const botRightGrid = this.screenToGrid(w, h);

    const startX = Math.floor(topLeftGrid.x) - 1;
    const endX = Math.ceil(botRightGrid.x) + 1;
    const startY = Math.floor(topLeftGrid.y) - 1;
    const endY = Math.ceil(botRightGrid.y) + 1;

    // Prevent excessive draw calls if zoomed way out
    if ((endX - startX) * (endY - startY) > 3500) return;

    const dotRadius = Math.max(0.9, Math.min(2.2, 1.35 * this.zoom));
    ctx.fillStyle = 'rgba(148, 163, 184, 0.44)';

    ctx.beginPath();
    for (let gx = startX; gx <= endX; gx++) {
      for (let gy = startY; gy <= endY; gy++) {
        // Place dots at half-cell corners (gx + 0.5, gy + 0.5) so they sit cleanly around arrow paths
        const sp = this.gridToScreen(gx + 0.5, gy + 0.5);
        ctx.moveTo(sp.x + dotRadius, sp.y);
        ctx.arc(sp.x, sp.y, dotRadius, 0, Math.PI * 2);
      }
    }
    ctx.fill();
  }

  private renderGridOverlay(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.strokeStyle = 'rgba(203, 213, 225, 0.65)';
    ctx.lineWidth = 1;

    const startX = Math.floor(this.gridMinX) - 0.5;
    const endX = Math.ceil(this.gridMaxX) + 0.5;
    const startY = Math.floor(this.gridMinY) - 0.5;
    const endY = Math.ceil(this.gridMaxY) + 0.5;

    const topLeft = this.gridToScreen(startX, startY);
    const botRight = this.gridToScreen(endX, endY);

    ctx.beginPath();
    for (let gx = startX; gx <= endX + 0.01; gx += 1) {
      const p = this.gridToScreen(gx, startY);
      ctx.moveTo(p.x, topLeft.y);
      ctx.lineTo(p.x, botRight.y);
    }

    for (let gy = startY; gy <= endY + 0.01; gy += 1) {
      const p = this.gridToScreen(startX, gy);
      ctx.moveTo(topLeft.x, p.y);
      ctx.lineTo(botRight.x, p.y);
    }
    ctx.stroke();

    ctx.restore();
  }

  /**
   * Renders the preserved shape boundary outline directly in grid space so it stays
   * perfectly aligned with the arrows during zoom and pan.
   */
  private renderShapeBoundary(ctx: CanvasRenderingContext2D, boundaryPath: Point[]) {
    ctx.save();
    ctx.beginPath();
    boundaryPath.forEach((pt, idx) => {
      const sp = this.gridToScreen(pt.x, pt.y);
      if (idx === 0) ctx.moveTo(sp.x, sp.y);
      else ctx.lineTo(sp.x, sp.y);
    });
    ctx.closePath();

    ctx.fillStyle = 'rgba(239, 246, 255, 0.42)';
    ctx.fill();

    ctx.strokeStyle = 'rgba(37, 99, 235, 0.28)';
    ctx.lineWidth = Math.max(1.5, 2.0 * Math.min(this.zoom, 1.5));
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Batches all idle non-hinted navy-blue arrows into one stroke call + one fill call
   * so dense 100+ arrow mazes stay razor-sharp at 60fps on mobile Android WebView.
   */
  private renderIdleArrowsBatched(ctx: CanvasRenderingContext2D) {
    const scaledCell = this.cellSize * this.zoom;
    const lineW = Math.max(1.8, scaledCell * 0.165);
    const headLen = Math.max(5.5, lineW * 2.4);
    const headHalfW = Math.max(4, lineW * 1.65);

    const midX = (this.gridMinX + this.gridMaxX) / 2;
    const midY = (this.gridMinY + this.gridMaxY) / 2;
    const scale = this.cellSize * this.zoom;
    const offsetX = this.boardCenterX - midX * scale + this.panX;
    const offsetY = this.boardCenterY - midY * scale + this.panY;

    const headTips: { x: number; y: number; cos: number; sin: number }[] = [];

    ctx.save();
    ctx.strokeStyle = '#0F1E3D';
    ctx.lineWidth = lineW;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();

    for (const arrow of this.arrows) {
      if (arrow.state !== 'idle' || arrow.isHinted) continue;

      const { dx, dy, angle } = DIR_DELTA[arrow.dir];
      const len = arrow.path.length;

      if (len === 1) {
        const p = arrow.path[0];
        const sx0 = (p.x - dx * 0.28) * scale + offsetX;
        const sy0 = (p.y - dy * 0.28) * scale + offsetY;
        const sx1 = (p.x + dx * 0.14) * scale + offsetX;
        const sy1 = (p.y + dy * 0.14) * scale + offsetY;

        ctx.moveTo(sx0, sy0);
        ctx.lineTo(sx1, sy1);
        headTips.push({ x: sx1, y: sy1, cos: Math.cos(angle), sin: Math.sin(angle) });
      } else {
        const first = arrow.path[0];
        ctx.moveTo(first.x * scale + offsetX, first.y * scale + offsetY);

        for (let i = 1; i < len - 1; i++) {
          const pt = arrow.path[i];
          ctx.lineTo(pt.x * scale + offsetX, pt.y * scale + offsetY);
        }

        const head = arrow.path[len - 1];
        const tipX = (head.x - dx * 0.06) * scale + offsetX;
        const tipY = (head.y - dy * 0.06) * scale + offsetY;
        ctx.lineTo(tipX, tipY);

        headTips.push({ x: tipX, y: tipY, cos: Math.cos(angle), sin: Math.sin(angle) });
      }
    }

    ctx.stroke();

    if (headTips.length > 0) {
      ctx.fillStyle = '#0F1E3D';
      ctx.beginPath();
      const front = headLen * 0.75;
      const back = -headLen * 0.45;
      const notch = -headLen * 0.25;

      for (const h of headTips) {
        ctx.moveTo(h.x + front * h.cos, h.y + front * h.sin);
        ctx.lineTo(h.x + back * h.cos + headHalfW * h.sin, h.y + back * h.sin - headHalfW * h.cos);
        ctx.lineTo(h.x + notch * h.cos, h.y + notch * h.sin);
        ctx.lineTo(h.x + back * h.cos - headHalfW * h.sin, h.y + back * h.sin + headHalfW * h.cos);
        ctx.closePath();
      }
      ctx.fill();
    }

    ctx.restore();
  }

  private renderPolylineArrow(ctx: CanvasRenderingContext2D, arrow: ArrowEntity) {
    const { dx, dy, angle } = DIR_DELTA[arrow.dir];
    const scaledCell = this.cellSize * this.zoom;
    const lineW = Math.max(1.8, scaledCell * 0.165);

    let gridPts: Point[];

    if (arrow.path.length === 1) {
      const p = arrow.path[0];
      const stem = [
        { x: p.x - dx * 0.28, y: p.y - dy * 0.28 },
        { x: p.x + dx * 0.14, y: p.y + dy * 0.14 },
      ];
      if (arrow.state === 'flying') {
        const ext = [stem[0], stem[1], { x: p.x + dx * 55, y: p.y + dy * 55 }];
        gridPts = slicePolyline(ext, arrow.slideDistance, 0.42);
      } else {
        gridPts = stem;
      }
    } else {
      const head = arrow.path[arrow.path.length - 1];
      const trimmedEnd = {
        x: head.x - dx * 0.06,
        y: head.y - dy * 0.06,
      };
      const basePath = [...arrow.path.slice(0, -1), trimmedEnd];

      if (arrow.state === 'flying') {
        let totalLen = 0;
        for (let i = 0; i < basePath.length - 1; i++) {
          totalLen += Math.hypot(
            basePath[i + 1].x - basePath[i].x,
            basePath[i + 1].y - basePath[i].y
          );
        }
        const extended = [...basePath, { x: head.x + dx * 60, y: head.y + dy * 60 }];
        gridPts = slicePolyline(extended, arrow.slideDistance, totalLen);
      } else {
        gridPts = basePath;
      }
    }

    if (gridPts.length < 2) return;

    let shakeOffsetX = 0;
    let shakeOffsetY = 0;
    if (arrow.state === 'blocked' && arrow.shakeTime > 0) {
      const progress = arrow.shakeTime / 320;
      const bounce = Math.sin(progress * Math.PI * 5) * 4.5 * progress;
      shakeOffsetX = dx * bounce;
      shakeOffsetY = dy * bounce;
    }

    const screenPts = gridPts.map((gp) => {
      const sp = this.gridToScreen(gp.x, gp.y);
      return {
        x: sp.x + shakeOffsetX,
        y: sp.y + shakeOffsetY,
      };
    });

    let strokeColor = '#0F1E3D';
    if (arrow.state === 'blocked') {
      strokeColor = '#DC2626';
    } else if (arrow.isHinted) {
      strokeColor = '#2563EB';
    }

    ctx.save();

    if (arrow.isHinted) {
      const pulse = (Math.sin(this.hintTime * 7) + 1) * 0.5;
      const tip = screenPts[screenPts.length - 1];

      ctx.save();
      ctx.strokeStyle = `rgba(37, 99, 235, ${0.35 + pulse * 0.35})`;
      ctx.lineWidth = Math.max(1.5, 2 * Math.min(this.zoom, 1.5));
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(tip.x, tip.y);
      ctx.lineTo(tip.x + dx * scaledCell * 4, tip.y + dy * scaledCell * 4);
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.strokeStyle = `rgba(59, 130, 246, ${0.22 + pulse * 0.18})`;
      ctx.lineWidth = lineW * 2.5;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      screenPts.forEach((pt, idx) => {
        if (idx === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
      });
      ctx.stroke();
      ctx.restore();
    }

    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = lineW;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.beginPath();
    screenPts.forEach((pt, idx) => {
      if (idx === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();

    const tipBase = screenPts[screenPts.length - 1];
    const prevPt = screenPts[screenPts.length - 2];

    let headAngle = angle;
    const segDx = tipBase.x - prevPt.x;
    const segDy = tipBase.y - prevPt.y;
    if (Math.hypot(segDx, segDy) > 0.5) {
      headAngle = Math.atan2(segDy, segDx);
    }

    const headLen = Math.max(5.5, lineW * 2.4);
    const headHalfW = Math.max(4, lineW * 1.65);

    ctx.save();
    ctx.translate(tipBase.x, tipBase.y);
    ctx.rotate(headAngle);

    ctx.beginPath();
    ctx.moveTo(headLen * 0.75, 0);
    ctx.lineTo(-headLen * 0.45, -headHalfW);
    ctx.lineTo(-headLen * 0.25, 0);
    ctx.lineTo(-headLen * 0.45, headHalfW);
    ctx.closePath();

    ctx.fillStyle = strokeColor;
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }
}
