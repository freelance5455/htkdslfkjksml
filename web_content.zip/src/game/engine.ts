import type { ChirpAudio } from "./audio";
import { sampleTheme, type Theme } from "./theme";

export type Phase = "menu" | "ready" | "play" | "pause" | "dying" | "over";

export type UiSnapshot = {
  phase: Phase;
  score: number;
  best: number;
  newRecord: boolean;
  pop: number;
};

type Pipe = { id: number; x: number; gapY: number; gap: number; scored: boolean };
type Feather = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  rot: number;
  spin: number;
  size: number;
  cream: boolean;
};
type Cloud = { x: number; y: number; s: number; v: number; a: number; layer: number };
type Floater = { x: number; y: number; life: number; text: string; gold: boolean };

export type GameHooks = {
  onUi: (ui: UiSnapshot) => void;
};

const STEP = 1 / 60;

function circleRect(cx: number, cy: number, r: number, x: number, y: number, w: number, h: number) {
  if (w <= 0 || h <= 0) return false;
  const nx = Math.max(x, Math.min(cx, x + w));
  const ny = Math.max(y, Math.min(cy, y + h));
  const dx = cx - nx;
  const dy = cy - ny;
  return dx * dx + dy * dy < r * r;
}

function hash(n: number) {
  const x = Math.sin(n * 127.1) * 43758.5453;
  return x - Math.floor(x);
}

export class SkyGame {
  phase: Phase = "menu";
  score = 0;
  best: number;
  private newRecord = false;
  private announced = false;
  private baselineBest: number;
  private pop = 0;
  private sig = "";

  private cssW = 0;
  private cssH = 0;
  private dpr = 1;
  private stageW = 360;
  private stageH = 640;
  private offsetX = 0;
  private unit = 1;
  private groundY = 560;

  private birdX = 120;
  private birdY = 280;
  private vy = 0;
  private rot = 0;
  private flapAge = 10;
  private flapBuffer = 0;
  private cooldown = 0;
  private autoFlap = false;
  private hitStop = 0;
  private deathT = 0;
  private scroll = 0;
  private time = 0;
  private theme = 0;
  private shake = 0;
  private flash = 0;
  private pipeSerial = 1;
  private pipes: Pipe[] = [];
  private feathers: Feather[] = [];
  private floaters: Floater[] = [];
  private clouds: Cloud[] = [];
  private prevPad = false;
  private reduceMotion = false;

  private raf = 0;
  private last = 0;
  private acc = 0;
  private ctx2d: CanvasRenderingContext2D | null = null;

  constructor(
    private canvas: HTMLCanvasElement,
    private audio: ChirpAudio,
    private hooks: GameHooks,
    best: number,
  ) {
    this.best = best;
    this.baselineBest = best;
    this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  start() {
    this.ctx2d = this.canvas.getContext("2d");
    this.resize();
    this.emit();
    window.addEventListener("keydown", this.onKey);
    window.addEventListener("pointerdown", this.onPointer);
    window.addEventListener("resize", this.resize);
    document.addEventListener("visibilitychange", this.onVis);
    this.raf = requestAnimationFrame(this.loop);
    window.__skyChirp = {
      flap: () => this.requestFlap(),
      pause: () => this.pause(),
      resume: () => this.resume(),
      state: () => ({
        phase: this.phase,
        score: this.score,
        best: this.best,
        birdY: this.birdY,
        vy: this.vy,
        pipes: this.pipes.length,
        gapY: this.pipes[0]?.gapY ?? null,
        pipeX: this.pipes[0]?.x ?? null,
      }),
    };
  }

  stop() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKey);
    window.removeEventListener("pointerdown", this.onPointer);
    window.removeEventListener("resize", this.resize);
    document.removeEventListener("visibilitychange", this.onVis);
    this.audio.dispose();
    if (window.__skyChirp) delete window.__skyChirp;
  }

  beginReady() {
    this.clearRun();
    this.phase = "ready";
    this.birdY = this.stageH * 0.36;
    this.baselineBest = this.best;
    this.syncAudio();
    this.emit();
  }

  pause() {
    if (this.phase !== "play") return;
    this.phase = "pause";
    this.flapBuffer = 0;
    this.audio.setWind(false);
    this.emit();
  }

  resume() {
    if (this.phase !== "pause") return;
    this.phase = "play";
    this.audio.setWind(true);
    this.emit();
  }

  restart() {
    this.beginReady();
  }

  home() {
    this.clearRun();
    this.phase = "menu";
    this.birdY = this.stageH * 0.32;
    this.syncAudio();
    this.emit();
  }

  requestFlap() {
    if (this.phase !== "ready" && this.phase !== "play") return;
    this.flapBuffer = 0.12;
  }

  private clearRun() {
    this.score = 0;
    this.pop = 0;
    this.newRecord = false;
    this.announced = false;
    this.pipes = [];
    this.feathers = [];
    this.floaters = [];
    this.vy = 0;
    this.rot = 0;
    this.flapAge = 10;
    this.cooldown = 0;
    this.flapBuffer = 0;
    this.deathT = 0;
    this.hitStop = 0;
    this.shake = 0;
    this.flash = 0;
  }

  private resize = () => {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const cssW = parent.clientWidth;
    const cssH = parent.clientHeight;
    if (cssW < 2 || cssH < 2) return;
    const prevW = this.stageW;
    const prevH = this.stageH;
    this.cssW = cssW;
    this.cssH = cssH;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(cssW * this.dpr);
    this.canvas.height = Math.floor(cssH * this.dpr);
    this.stageW = Math.max(280, Math.min(cssW, 560));
    this.stageH = cssH;
    this.offsetX = (cssW - this.stageW) / 2;
    this.unit = this.stageH / 780;
    this.groundY = this.stageH * 0.86;
    this.birdX = this.stageW * 0.32;
    if (prevH > 40 && (this.phase === "play" || this.phase === "pause" || this.phase === "dying")) {
      const sy = this.stageH / prevH;
      const sx = this.stageW / prevW;
      this.birdY *= sy;
      this.vy *= sy;
      for (const p of this.pipes) {
        p.x *= sx;
        p.gapY *= sy;
        p.gap *= sy;
      }
    } else if (this.phase === "menu" || this.phase === "ready" || prevH < 40) {
      this.birdY = this.stageH * (this.phase === "menu" ? 0.32 : 0.36);
    }
    if (this.clouds.length === 0) this.seedClouds();
  };

  private seedClouds() {
    this.clouds = [];
    for (let i = 0; i < 9; i++) {
      this.clouds.push({
        x: Math.random() * this.cssW,
        y: this.cssH * (0.06 + (i % 5) * 0.07),
        s: 0.7 + (i % 4) * 0.28,
        v: 6 + (i % 3) * 7,
        a: 0.42 + (i % 3) * 0.12,
        layer: i % 3,
      });
    }
  }

  private loop = (now: number) => {
    const dt = this.last ? Math.min(0.05, (now - this.last) / 1000) : 0;
    this.last = now;
    this.acc += dt;
    let steps = 0;
    while (this.acc >= STEP && steps < 5) {
      this.update(STEP);
      this.acc -= STEP;
      steps++;
    }
    if (steps === 5) this.acc = 0;
    this.draw();
    this.raf = requestAnimationFrame(this.loop);
  };

  private update(dt: number) {
    if (this.stageH < 20) return;
    if (this.pollPad()) {
      if (this.phase === "menu") this.beginReady();
      else if (this.phase === "pause") this.resume();
      else this.requestFlap();
    }

    if (this.phase === "pause") return;

    this.time += dt;
    this.flapAge += dt;
    this.updateTheme(dt);
    this.updateFx(dt);

    const bobbing = this.phase === "menu" || this.phase === "ready";
    if (bobbing) {
      const base = this.stageH * (this.phase === "menu" ? 0.32 : 0.36);
      this.birdY = base + Math.sin(this.time * 2.3) * 12 * this.unit;
      this.rot = Math.sin(this.time * 2.3) * 0.1;
      const pulse = Math.sin(this.time * 1.35) > 0.93;
      if (pulse && !this.autoFlap) this.flapAge = 0;
      this.autoFlap = pulse;
    }

    this.cooldown = Math.max(0, this.cooldown - dt);
    if (this.flapBuffer > 0) {
      this.flapBuffer -= dt;
      if (this.cooldown <= 0 && (this.phase === "ready" || this.phase === "play")) this.doFlap();
    }

    const scrolling = this.phase === "play" || this.phase === "menu" || this.phase === "ready";
    const speed = this.phase === "play" ? this.difficulty().speed : scrolling ? 34 * this.unit : 0;
    if (speed > 0) {
      this.scroll += speed * dt;
      this.driftClouds(speed, dt);
    }

    if (this.phase === "play") {
      this.maybeSpawn();
      for (const p of this.pipes) p.x -= speed * dt;
      if (this.pipes[0] && this.pipes[0].x < -160 * this.unit) this.pipes.shift();
      const g = 2800 * this.unit;
      this.vy = Math.min(760 * this.unit, this.vy + g * dt);
      this.birdY += this.vy * dt;
      const r = 15 * this.unit;
      if (this.birdY < r + 6) {
        this.birdY = r + 6;
        if (this.vy < 0) this.vy = 0;
      }
      const target = Math.max(-0.7, Math.min(1.2, this.vy / (640 * this.unit)));
      this.rot += (target - this.rot) * (1 - Math.exp(-10 * dt));
      this.passPipes();
      const hit = this.hitTest();
      if (hit) this.kill(hit);
    } else if (this.phase === "dying") {
      this.deathT += dt;
      if (this.hitStop > 0) {
        this.hitStop -= dt;
      } else {
        const g = 2800 * this.unit;
        this.vy = Math.min(780 * this.unit, this.vy + g * dt);
        this.birdY += this.vy * dt;
        const r = 16 * this.unit;
        if (this.birdY > this.groundY - r) {
          this.birdY = this.groundY - r;
          if (Math.abs(this.vy) > 40 * this.unit) this.vy *= -0.28;
          else this.vy = 0;
        }
        const target = 1.15;
        this.rot += (target - this.rot) * (1 - Math.exp(-4 * dt));
      }
      if (this.deathT > 0.92) {
        this.phase = "over";
        this.audio.over();
        this.syncAudio();
        this.emit();
      }
    }
  }

  private doFlap() {
    if (this.phase === "ready") {
      this.phase = "play";
      this.syncAudio();
      this.maybeSpawn();
    }
    if (this.phase !== "play") return;
    this.vy = -620 * this.unit;
    this.flapAge = 0;
    this.cooldown = 0.09;
    this.flapBuffer = 0;
    this.audio.flap();
    this.burst(this.birdX - 18 * this.unit, this.birdY, 3, 0.7);
    this.emit();
  }

  private difficulty() {
    const t = Math.min(this.score, 24) / 24;
    const wide = Math.max(1, this.stageW / 420);
    return {
      speed: (142 + t * 108) * this.unit * wide,
      gap: (206 - t * 42) * this.unit,
      spacing: (268 - t * 40) * this.unit,
    };
  }

  private pipeW() {
    return 64 * this.unit;
  }

  private maybeSpawn() {
    const { spacing } = this.difficulty();
    let guard = 0;
    while (guard++ < 3) {
      const last = this.pipes[this.pipes.length - 1];
      if (last && last.x >= this.stageW - spacing) break;
      const x = last ? last.x + spacing : this.stageW + 48 * this.unit;
      this.spawn(x, !last && this.score === 0);
    }
  }

  private spawn(x: number, easy: boolean) {
    const lip = 26 * this.unit;
    const margin = 28 * this.unit;
    let gap = this.difficulty().gap;
    if (easy) gap = Math.max(gap, 236 * this.unit);
    const minCenter = margin + gap / 2 + lip;
    const maxCenter = this.groundY - margin - gap / 2 - lip;
    const gapY = easy
      ? this.stageH * 0.42
      : minCenter + Math.random() * Math.max(0, maxCenter - minCenter);
    this.pipes.push({ id: this.pipeSerial++, x, gapY, gap, scored: false });
  }

  private passPipes() {
    const w = this.pipeW();
    for (const p of this.pipes) {
      if (p.scored || p.x + w * 0.5 >= this.birdX) continue;
      p.scored = true;
      this.score += 1;
      this.pop += 1;
      this.audio.score();
      this.floaters.push({
        x: this.birdX,
        y: this.birdY - 40 * this.unit,
        life: 0.7,
        text: "+1",
        gold: false,
      });
      if (this.score > this.best) {
        this.best = this.score;
        this.newRecord = this.score > this.baselineBest;
        if (!this.announced && this.baselineBest > 0 && this.newRecord) {
          this.announced = true;
          this.floaters.push({
            x: this.birdX,
            y: this.birdY - 68 * this.unit,
            life: 0.95,
            text: "Best!",
            gold: true,
          });
        } else if (!this.announced) {
          this.announced = this.newRecord;
        }
      }
      this.emit();
    }
  }

  private hitTest(): "pipe" | "ground" | null {
    const r = 14.5 * this.unit;
    if (this.birdY + r >= this.groundY) return "ground";
    const w = this.pipeW();
    const lipOver = 8 * this.unit;
    const lipH = 26 * this.unit;
    for (const p of this.pipes) {
      if (p.x > this.birdX + r + lipOver || p.x + w + lipOver < this.birdX - r) continue;
      const gapTop = p.gapY - p.gap / 2;
      const gapBot = p.gapY + p.gap / 2;
      const bodyX = p.x;
      if (circleRect(this.birdX, this.birdY, r, bodyX, 0, w, gapTop - lipH)) return "pipe";
      if (circleRect(this.birdX, this.birdY, r, bodyX - lipOver, gapTop - lipH, w + lipOver * 2, lipH))
        return "pipe";
      if (circleRect(this.birdX, this.birdY, r, bodyX - lipOver, gapBot, w + lipOver * 2, lipH))
        return "pipe";
      if (circleRect(this.birdX, this.birdY, r, bodyX, gapBot + lipH, w, this.groundY - (gapBot + lipH)))
        return "pipe";
    }
    return null;
  }

  private kill(kind: "pipe" | "ground") {
    if (this.phase !== "play") return;
    this.phase = "dying";
    this.deathT = 0;
    this.hitStop = this.reduceMotion ? 0 : 0.045;
    this.vy = (kind === "ground" ? -280 : -200) * this.unit;
    this.shake = 1;
    this.flash = 0.85;
    this.flapBuffer = 0;
    this.burst(this.birdX, this.birdY, 14, 1);
    this.audio.hit(kind);
    this.audio.setWind(false);
    this.syncAudio();
    this.emit();
  }

  private burst(x: number, y: number, n: number, power: number) {
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2;
      const sp = (40 + Math.random() * 160) * this.unit * power;
      this.feathers.push({
        x,
        y,
        vx: Math.cos(ang) * sp - 30 * this.unit,
        vy: Math.sin(ang) * sp - 40 * this.unit,
        life: 0.45 + Math.random() * 0.45,
        max: 0.9,
        rot: Math.random() * 6,
        spin: (Math.random() - 0.5) * 8,
        size: (4 + Math.random() * 5) * this.unit,
        cream: Math.random() > 0.45,
      });
    }
    if (this.feathers.length > 48) this.feathers.splice(0, this.feathers.length - 48);
  }

  private updateFx(dt: number) {
    this.flash = Math.max(0, this.flash - dt * 2.4);
    this.shake = Math.max(0, this.shake - dt * 2.1);
    for (const f of this.feathers) {
      f.life -= dt;
      f.vy += 420 * this.unit * dt;
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      f.rot += f.spin * dt;
    }
    if (this.feathers.some((f) => f.life <= 0)) this.feathers = this.feathers.filter((f) => f.life > 0);
    for (const floater of this.floaters) {
      floater.life -= dt;
      floater.y -= 36 * this.unit * dt;
    }
    if (this.floaters.some((f) => f.life <= 0)) this.floaters = this.floaters.filter((f) => f.life > 0);
  }

  private updateTheme(dt: number) {
    if (this.phase === "menu") {
      this.theme = (this.time * 0.035) % 3;
      return;
    }
    const target = (this.score / 7) % 3;
    const max = 3;
    const delta = ((target - this.theme) % max + max) % max;
    this.theme = (this.theme + Math.min(delta, dt * 0.55)) % max;
  }

  private driftClouds(speed: number, dt: number) {
    for (const c of this.clouds) {
      c.x -= (c.v + speed * (0.12 + c.layer * 0.1)) * dt;
      if (c.x < -180) c.x = this.cssW + 60 + Math.random() * 80;
    }
  }

  private syncAudio() {
    const scene =
      this.phase === "play" || this.phase === "pause"
        ? "play"
        : this.phase === "menu" || this.phase === "ready"
          ? "menu"
          : "quiet";
    this.audio.syncScene(scene);
    this.audio.setWind(this.phase === "play");
  }

  private pollPad() {
    const pads = navigator.getGamepads?.();
    if (!pads) return false;
    let down = false;
    for (const pad of pads) {
      if (!pad) continue;
      if (pad.buttons[0]?.pressed) down = true;
    }
    const just = down && !this.prevPad;
    this.prevPad = down;
    return just;
  }

  private emit() {
    const sig = `${this.phase}|${this.score}|${this.best}|${this.newRecord ? 1 : 0}|${this.pop}`;
    if (sig === this.sig) return;
    this.sig = sig;
    this.hooks.onUi({
      phase: this.phase,
      score: this.score,
      best: this.best,
      newRecord: this.newRecord,
      pop: this.pop,
    });
  }

  private onKey = (e: KeyboardEvent) => {
    if (e.repeat) return;
    this.audio.unlock();
    if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
      e.preventDefault();
      if (this.phase === "menu") this.beginReady();
      else this.requestFlap();
    } else if (e.code === "Escape" || e.code === "KeyP") {
      if (this.phase === "play") this.pause();
      else if (this.phase === "pause") this.resume();
    }
  };

  private onPointer = (e: PointerEvent) => {
    this.audio.unlock();
    const el = e.target as HTMLElement | null;
    if (el?.closest("button, input, label, a, [data-no-flap]")) return;
    if (this.phase === "menu") return;
    e.preventDefault();
    this.requestFlap();
  };

  private onVis = () => {
    if (document.hidden) {
      if (this.phase === "play") this.pause();
    } else {
      this.audio.onVisible();
    }
  };

  private wingAngle() {
    if (this.flapAge < 0.2) {
      const t = this.flapAge / 0.2;
      return -0.95 + Math.sin(t * Math.PI) * 1.65;
    }
    if (this.phase === "play" && this.vy > 280 * this.unit) return -1.05;
    return -0.4 + Math.sin(this.time * 6.2) * 0.18;
  }

  private draw() {
    const ctx = this.ctx2d;
    if (!ctx || this.cssW < 2) return;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const theme = sampleTheme(this.theme);
    const mag = this.reduceMotion ? 0 : this.shake * 8 * this.unit;
    const sx = (Math.random() - 0.5) * 2 * mag;
    const sy = (Math.random() - 0.5) * 2 * mag;
    ctx.clearRect(0, 0, this.cssW, this.cssH);
    ctx.save();
    ctx.translate(sx, sy);
    this.drawSky(ctx, theme);
    this.drawClouds(ctx, theme, 0);
    this.drawHills(ctx, theme, true);
    this.drawHills(ctx, theme, false);
    this.drawClouds(ctx, theme, 2);
    this.drawPipes(ctx, theme);
    this.drawGround(ctx, theme);
    this.drawFeathers(ctx);
    this.drawBird(ctx);
    this.drawFloaters(ctx);
    ctx.restore();
    this.drawVignette(ctx, theme);
    if (this.flash > 0) {
      ctx.fillStyle = `rgba(255, 236, 214, ${this.flash * 0.45})`;
      ctx.fillRect(0, 0, this.cssW, this.cssH);
    }
  }

  private drawSky(ctx: CanvasRenderingContext2D, theme: Theme) {
    const g = ctx.createLinearGradient(0, 0, 0, this.cssH);
    g.addColorStop(0, theme.sky0);
    g.addColorStop(0.55, theme.sky1);
    g.addColorStop(1, theme.sky2);
    ctx.fillStyle = g;
    ctx.fillRect(-20, -20, this.cssW + 40, this.cssH + 40);

    if (theme.star > 0.05) {
      for (let i = 0; i < 36; i++) {
        const x = hash(i * 3.1) * this.cssW;
        const y = hash(i * 8.7) * this.cssH * 0.55;
        const tw = 0.45 + 0.55 * Math.sin(this.time * 2 + i);
        ctx.globalAlpha = theme.star * tw * 0.85;
        ctx.fillStyle = "#fff8e8";
        ctx.beginPath();
        ctx.arc(x, y, (hash(i) > 0.8 ? 1.8 : 1.1) * this.unit, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    const sx = this.cssW * theme.sunX;
    const sy = this.cssH * theme.sunY;
    const glow = ctx.createRadialGradient(sx, sy, 8, sx, sy, this.cssH * 0.48);
    glow.addColorStop(0, theme.sunCore);
    glow.addColorStop(0.12, theme.sun);
    glow.addColorStop(1, "rgba(255,255,255,0)");
    ctx.globalAlpha = 0.9 - theme.night * 0.35;
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, this.cssW, this.cssH);
    ctx.globalAlpha = 1;

    ctx.save();
    ctx.translate(sx, sy);
    if (theme.night < 0.65) {
      ctx.rotate(this.time * 0.04);
      ctx.globalAlpha = (0.14 - theme.night * 0.12) * (this.reduceMotion ? 0.4 : 1);
      ctx.fillStyle = theme.sun;
      for (let i = 0; i < 8; i++) {
        ctx.rotate(Math.PI / 8);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(this.cssH * 0.7, 16);
        ctx.lineTo(this.cssH * 0.7, -16);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      const sunR = 36 + (1 - theme.night) * 10;
      const sun = ctx.createRadialGradient(-8, -8, 4, 0, 0, sunR);
      sun.addColorStop(0, "#fffef8");
      sun.addColorStop(0.6, theme.sun);
      sun.addColorStop(1, theme.sun);
      ctx.fillStyle = sun;
      ctx.beginPath();
      ctx.arc(0, 0, sunR, 0, Math.PI * 2);
      ctx.fill();
    }
    if (theme.night > 0.35) {
      ctx.globalAlpha = Math.min(1, (theme.night - 0.35) / 0.5);
      ctx.fillStyle = theme.sunCore;
      ctx.beginPath();
      ctx.arc(0, 0, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha *= 0.95;
      ctx.fillStyle = theme.sky0;
      ctx.beginPath();
      ctx.arc(12, -6, 22, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }

  private drawClouds(ctx: CanvasRenderingContext2D, theme: Theme, layer: number) {
    for (const c of this.clouds) {
      if (layer === 0 && c.layer === 2) continue;
      if (layer === 2 && c.layer !== 2) continue;
      if (layer === 0 && c.layer === 2) continue;
      ctx.save();
      ctx.translate(c.x, c.y);
      ctx.scale(c.s * this.unit * 1.35, c.s * this.unit * 1.35);
      ctx.globalAlpha = c.a * (1 - theme.night * 0.45);
      const puffs: [number, number, number][] = [
        [0, 0, 28],
        [26, -8, 22],
        [-24, -4, 18],
        [12, 8, 16],
      ];
      for (const [px, py, pr] of puffs) {
        const grd = ctx.createRadialGradient(px - 6, py - 8, 2, px, py, pr);
        grd.addColorStop(0, "#ffffff");
        grd.addColorStop(1, theme.cloud);
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(px, py, pr, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawHills(ctx: CanvasRenderingContext2D, theme: Theme, far: boolean) {
    const amp = (far ? 28 : 18) * this.unit;
    const base = this.groundY - (far ? 70 : 28) * this.unit;
    const freq = far ? 0.008 : 0.014;
    const parallax = far ? 0.15 : 0.32;
    ctx.fillStyle = far ? theme.hillFar : theme.hillNear;
    ctx.beginPath();
    ctx.moveTo(0, this.cssH);
    for (let x = 0; x <= this.cssW; x += 10) {
      const y =
        base -
        Math.sin((x + this.scroll * parallax) * freq) * amp -
        Math.sin((x + this.scroll * parallax) * freq * 0.37 + 1.2) * amp * 0.45;
      if (x === 0) ctx.lineTo(0, y);
      else ctx.lineTo(x, y);
    }
    ctx.lineTo(this.cssW, this.cssH);
    ctx.closePath();
    ctx.fill();
  }

  private drawPipes(ctx: CanvasRenderingContext2D, theme: Theme) {
    const w = this.pipeW();
    const lipOver = 8 * this.unit;
    const lipH = 26 * this.unit;
    for (const p of this.pipes) {
      const x = this.offsetX + p.x;
      const gapTop = p.gapY - p.gap / 2;
      const gapBot = p.gapY + p.gap / 2;
      this.drawPipeColumn(ctx, theme, x, 0, w, Math.max(0, gapTop - lipH), p.id);
      this.drawLip(ctx, theme, x - lipOver, gapTop - lipH, w + lipOver * 2, lipH);
      this.drawLip(ctx, theme, x - lipOver, gapBot, w + lipOver * 2, lipH);
      this.drawPipeColumn(ctx, theme, x, gapBot + lipH, w, Math.max(0, this.groundY - (gapBot + lipH)), p.id + 3);
      ctx.fillStyle = "rgba(6, 28, 24, 0.55)";
      ctx.beginPath();
      ctx.ellipse(x + w / 2, gapTop - 2 * this.unit, w * 0.26, 7 * this.unit, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(x + w / 2, gapBot + lipH * 0.15, w * 0.26, 7 * this.unit, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawPipeColumn(
    ctx: CanvasRenderingContext2D,
    theme: Theme,
    x: number,
    y: number,
    w: number,
    h: number,
    id: number,
  ) {
    if (h < 1) return;
    const g = ctx.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, theme.pipeDark);
    g.addColorStop(0.22, theme.pipeLite);
    g.addColorStop(0.48, theme.pipe);
    g.addColorStop(1, theme.pipeDark);
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = "rgba(255,255,255,0.22)";
    ctx.fillRect(x + w * 0.18, y, Math.max(3, w * 0.08), h);
    ctx.fillStyle = "rgba(0,0,0,0.16)";
    ctx.fillRect(x + w * 0.82, y, w * 0.18, h);
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    for (let i = 0; i < 4; i++) {
      const px = x + 8 * this.unit + hash(id * 5 + i) * (w - 16 * this.unit);
      const py = y + hash(id * 9 + i) * h;
      ctx.fillStyle = "rgba(12, 60, 40, 0.28)";
      ctx.beginPath();
      ctx.ellipse(px, py, 3.2 * this.unit, 2.1 * this.unit, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawLip(ctx: CanvasRenderingContext2D, theme: Theme, x: number, y: number, w: number, h: number) {
    if (h < 1 || y > this.groundY) return;
    const g = ctx.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, theme.pipeDark);
    g.addColorStop(0.25, theme.pipeLite);
    g.addColorStop(0.7, theme.lip);
    g.addColorStop(1, theme.pipeDark);
    ctx.fillStyle = g;
    roundRect(ctx, x, y, w, h, 8 * this.unit);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.28)";
    ctx.fillRect(x + 8 * this.unit, y + 4 * this.unit, w * 0.18, Math.max(2, h - 8 * this.unit));
    ctx.strokeStyle = "rgba(255, 236, 190, 0.35)";
    ctx.lineWidth = 2;
    roundRect(ctx, x + 1, y + 1, w - 2, h - 2, 7 * this.unit);
    ctx.stroke();
  }

  private drawGround(ctx: CanvasRenderingContext2D, theme: Theme) {
    const y = this.groundY;
    const g = ctx.createLinearGradient(0, y, 0, this.cssH);
    g.addColorStop(0, theme.grass);
    g.addColorStop(0.16, theme.dirt);
    g.addColorStop(1, theme.dirtDark);
    ctx.fillStyle = g;
    ctx.fillRect(0, y, this.cssW, this.cssH - y);
    ctx.fillStyle = theme.grassDark;
    ctx.fillRect(0, y, this.cssW, 8 * this.unit);
    ctx.fillStyle = theme.grass;
    const blade = 16 * this.unit;
    const offset = this.scroll % blade;
    ctx.beginPath();
    for (let x = -blade; x < this.cssW + blade; x += blade) {
      const bx = x - offset;
      ctx.moveTo(bx, y);
      ctx.lineTo(bx + 5 * this.unit, y - 12 * this.unit);
      ctx.lineTo(bx + 10 * this.unit, y);
    }
    ctx.fill();
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = theme.dirtDark;
    for (let i = 0; i < 18; i++) {
      const px = ((i * 97 - this.scroll * 0.85) % (this.cssW + 30) + 30) % (this.cssW + 30);
      const py = y + 22 * this.unit + (i % 5) * 8 * this.unit;
      ctx.beginPath();
      ctx.ellipse(px, py, 4 * this.unit, 2.4 * this.unit, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  private drawFeathers(ctx: CanvasRenderingContext2D) {
    for (const f of this.feathers) {
      ctx.save();
      ctx.translate(this.offsetX + f.x, f.y);
      ctx.rotate(f.rot);
      ctx.globalAlpha = Math.max(0, f.life / f.max);
      ctx.fillStyle = f.cream ? "#fff1dc" : "#ef7a45";
      ctx.beginPath();
      ctx.ellipse(0, 0, f.size * 1.6, f.size * 0.55, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawBird(ctx: CanvasRenderingContext2D) {
    const s = 1.22 * this.unit;
    const wing = this.wingAngle();
    const blink = this.time % 3.8 > 3.62;
    ctx.save();
    ctx.translate(this.offsetX + this.birdX, this.birdY);
    ctx.rotate(this.rot);

    drawWing(ctx, s, wing, true);

    ctx.fillStyle = "#9a3412";
    ctx.beginPath();
    ctx.ellipse(0, 2 * s, 17 * s, 14.2 * s, -0.2, 0, Math.PI * 2);
    ctx.fill();
    const body = ctx.createRadialGradient(-6 * s, -4 * s, 2 * s, 0, 2 * s, 18 * s);
    body.addColorStop(0, "#ffd0a6");
    body.addColorStop(0.45, "#f4894e");
    body.addColorStop(1, "#e15a32");
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.ellipse(0, 2 * s, 15.4 * s, 12.6 * s, -0.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#fff3e0";
    ctx.beginPath();
    ctx.ellipse(2 * s, 6 * s, 8.5 * s, 6.4 * s, 0.15, 0, Math.PI * 2);
    ctx.fill();

    ctx.save();
    ctx.rotate(0.35 + wing * 0.05);
    ctx.fillStyle = "#c2410c";
    ctx.beginPath();
    ctx.ellipse(-14 * s, 3 * s, 7 * s, 3.4 * s, 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#fff1dc";
    ctx.beginPath();
    ctx.ellipse(-19 * s, 4 * s, 2.4 * s, 1.5 * s, 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    const head = ctx.createRadialGradient(4 * s, -12 * s, 1 * s, 6 * s, -8 * s, 12 * s);
    head.addColorStop(0, "#ffe0c2");
    head.addColorStop(1, "#ef7444");
    ctx.fillStyle = "#9a3412";
    ctx.beginPath();
    ctx.arc(6 * s, -8 * s, 10.4 * s, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = head;
    ctx.beginPath();
    ctx.arc(6 * s, -8 * s, 9.2 * s, 0, Math.PI * 2);
    ctx.fill();

    const crestLift = Math.sin(this.time * 8) * 0.8 * s;
    ctx.fillStyle = "#ff8fab";
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.ellipse(
        1 * s + i * 3.1 * s,
        -16.5 * s - i * 0.6 * s + crestLift,
        2 * s,
        5 * s,
        -0.7 + i * 0.38,
        0,
        Math.PI * 2,
      );
      ctx.fill();
    }

    ctx.fillStyle = "#f0b429";
    ctx.beginPath();
    ctx.moveTo(13 * s, -10 * s);
    ctx.lineTo(24 * s, -7.2 * s);
    ctx.lineTo(13.5 * s, -5.4 * s);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#d4922a";
    ctx.beginPath();
    ctx.moveTo(13.2 * s, -7.2 * s);
    ctx.quadraticCurveTo(20 * s, -6.2 * s, 13.2 * s, -4.6 * s);
    ctx.fill();

    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.ellipse(10 * s, -9.5 * s, 4.3 * s, blink ? 0.7 * s : 4.6 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    if (!blink) {
      ctx.fillStyle = "#3a2418";
      ctx.beginPath();
      ctx.arc(11.2 * s, -9.4 * s, 2.2 * s, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(10.4 * s, -10.3 * s, 0.9 * s, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "rgba(239, 106, 69, 0.4)";
    ctx.beginPath();
    ctx.ellipse(7.5 * s, -4.5 * s, 2.5 * s, 1.5 * s, 0, 0, Math.PI * 2);
    ctx.fill();

    drawWing(ctx, s, wing, false);

    ctx.strokeStyle = "#e8a317";
    ctx.lineWidth = 1.7 * s;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-1 * s, 12 * s);
    ctx.lineTo(-3 * s, 16 * s);
    ctx.moveTo(5 * s, 12.5 * s);
    ctx.lineTo(7 * s, 16.5 * s);
    ctx.stroke();

    ctx.restore();
  }

  private drawFloaters(ctx: CanvasRenderingContext2D) {
    ctx.textAlign = "center";
    ctx.lineJoin = "round";
    for (const f of this.floaters) {
      ctx.globalAlpha = Math.max(0, Math.min(1, f.life * 1.6));
      ctx.font = `700 ${Math.round(26 * this.unit)}px Fredoka, Trebuchet MS, sans-serif`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(27, 36, 48, 0.45)";
      ctx.strokeText(f.text, this.offsetX + f.x, f.y);
      ctx.fillStyle = f.gold ? "#f0b429" : "#fff7ec";
      ctx.fillText(f.text, this.offsetX + f.x, f.y);
    }
    ctx.globalAlpha = 1;
  }

  private drawVignette(ctx: CanvasRenderingContext2D, theme: Theme) {
    const v = ctx.createRadialGradient(
      this.cssW / 2,
      this.cssH * 0.45,
      this.cssH * 0.25,
      this.cssW / 2,
      this.cssH * 0.5,
      this.cssH * 0.78,
    );
    v.addColorStop(0, "rgba(0,0,0,0)");
    v.addColorStop(1, `rgba(12, 18, 32, ${0.16 + theme.night * 0.32})`);
    ctx.fillStyle = v;
    ctx.fillRect(0, 0, this.cssW, this.cssH);
  }
}

function drawWing(ctx: CanvasRenderingContext2D, s: number, wing: number, back: boolean) {
  ctx.save();
  ctx.translate(-2 * s, 2 * s);
  ctx.rotate(wing * 0.9);
  ctx.globalAlpha = back ? 0.75 : 1;
  const feathers = back
    ? [
        { rot: -0.55, len: 13, wid: 4.2 },
        { rot: -0.2, len: 16, wid: 4.6 },
        { rot: 0.18, len: 14, wid: 4 },
      ]
    : [
        { rot: -0.7, len: 15, wid: 4.4 },
        { rot: -0.28, len: 19, wid: 5 },
        { rot: 0.12, len: 16, wid: 4.4 },
        { rot: 0.48, len: 12, wid: 3.6 },
      ];
  for (const f of feathers) {
    ctx.save();
    ctx.rotate(f.rot);
    ctx.fillStyle = back ? "#9a3412" : "#c2410c";
    ctx.beginPath();
    ctx.ellipse(-f.len * 0.42 * s, 0, f.len * 0.5 * s, f.wid * 0.42 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffe7c4";
    ctx.beginPath();
    ctx.ellipse(-f.len * 0.78 * s, 0, f.wid * 0.32 * s, f.wid * 0.2 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, Math.max(0, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

declare global {
  interface Window {
    __skyChirp?: {
      flap: () => void;
      pause: () => void;
      resume: () => void;
      state: () => {
        phase: string;
        score: number;
        best: number;
        birdY: number;
        vy: number;
        pipes: number;
        gapY: number | null;
        pipeX: number | null;
      };
    };
  }
}
