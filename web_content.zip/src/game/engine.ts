import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';

import { BodycamSettings, GameHudState } from './types';
import { ProceduralTextureLibrary } from './textures';
import { TacticalWeaponRig } from './weapon';
import { buildCompoundWorld, CompoundWorld } from './world';
import { updateHostiles } from './enemies';
import { BodycamOpticalShader } from './bodycamShader';
import { TacticalAudio } from './audio';

interface ActiveTracer {
  line: THREE.Line;
  life: number;
}

interface ActiveSpark {
  points: THREE.Points;
  velocities: Float32Array;
  life: number;
}

// Pre-allocated math helpers (zero GC inside tick loop)
const _forward = new THREE.Vector3();
const _right = new THREE.Vector3();
const _move = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();
const _rayDir = new THREE.Vector3();
const _muzzleWorld = new THREE.Vector3();

function detectSoftwareGl(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class BodycamGameEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private bodycamPass: ShaderPass | null = null;
  private isSoftwareGl: boolean;

  private texLib: ProceduralTextureLibrary;
  private world: CompoundWorld;
  private weapon: TacticalWeaponRig;
  private audio = new TacticalAudio();

  private clock = new THREE.Clock();
  private raycaster = new THREE.Raycaster();
  private frameId = 0;
  private disposed = false;

  // Player kinematic state
  private playerPos = new THREE.Vector3(0, 1.48, 22.8);
  private yaw = 0; // Facing -Z (North)
  private pitch = 0;
  private currentRoll = 0;
  private currentFov = 90;
  private walkPhase = 0;
  private stepDistAccum = 0;

  // Input state
  private keys: Record<string, boolean> = {};
  private isMouseDown = false;
  private isAiming = false;
  private isDraggingLook = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // Mobile touch input state
  private touchMoveX = 0;
  private touchMoveY = 0;
  private touchSprint = false;
  private touchCrouch = false;

  // Combat & Mission state
  private phase: GameHudState['phase'] = 'briefing';
  private health = 100;
  private maxHealth = 100;
  private ammo = 15;
  private magSize = 15;
  private reserveAmmo = 75;
  private isReloading = false;
  private reloadTimer = 0;
  private fireCooldown = 0;
  private flashlightBattery = 100;
  private elapsedSeconds = 0;
  private hitMarkerTimer = 0;
  private damageFlashTimer = 0;
  private impactShock = 0;
  private statusBanner: string | null = null;
  private statusBannerTimer = 0;

  private tracers: ActiveTracer[] = [];
  private sparks: ActiveSpark[] = [];

  private settings: BodycamSettings;
  private onHudUpdate: (state: GameHudState) => void;
  private onContextLostCallback?: () => void;
  private hudSyncTimer = 0;

  // Bound event listeners
  private handleResizeBound: () => void;
  private handleKeyDownBound: (e: KeyboardEvent) => void;
  private handleKeyUpBound: (e: KeyboardEvent) => void;
  private handleMouseMoveBound: (e: MouseEvent) => void;
  private handleMouseDownBound: (e: MouseEvent) => void;
  private handleMouseUpBound: (e: MouseEvent) => void;
  private handleContextMenuBound: (e: MouseEvent) => void;
  private handlePointerLockChangeBound: () => void;
  private handleWebglLostBound: (e: Event) => void;

  constructor(
    container: HTMLElement,
    initialSettings: BodycamSettings,
    onHudUpdate: (state: GameHudState) => void,
    onContextLost?: () => void,
  ) {
    this.container = container;
    this.settings = { ...initialSettings };
    this.onHudUpdate = onHudUpdate;
    this.onContextLostCallback = onContextLost;
    this.isSoftwareGl = detectSoftwareGl();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = this.settings.exposure;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();

    // Mandatory studio environment reflection map (on every device)
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // Bodycam wide-angle perspective camera (chest mount ~90 deg FOV)
    this.camera = new THREE.PerspectiveCamera(90, width / height, 0.08, 120);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    // Build textures, world & weapon rig
    this.texLib = new ProceduralTextureLibrary(this.renderer);
    this.world = buildCompoundWorld(this.scene, this.texLib, this.isSoftwareGl);
    this.world.applyLightingMood(this.settings.lightingMood, this.scene);

    const gunmetalTex = this.texLib.createBrushedGunmetal();
    this.weapon = new TacticalWeaponRig(gunmetalTex, this.isSoftwareGl);
    this.camera.add(this.weapon.root);
    this.weapon.setFlashlight(this.settings.flashlightOn);

    // Post-processing pipeline (bypassed cleanly on software WebGL)
    if (!this.isSoftwareGl) {
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));

      this.bloomPass = new UnrealBloomPass(
        new THREE.Vector2(width, height),
        0.42,
        0.55,
        0.82,
      );
      this.composer.addPass(this.bloomPass);

      this.bodycamPass = new ShaderPass(BodycamOpticalShader);
      this.bodycamPass.uniforms.uAspect.value = width / height;
      this.composer.addPass(this.bodycamPass);
      this.syncShaderUniforms();

      this.renderer.compile(this.scene, this.camera);
    }

    // Bind events
    this.handleResizeBound = this.onResize.bind(this);
    this.handleKeyDownBound = this.onKeyDown.bind(this);
    this.handleKeyUpBound = this.onKeyUp.bind(this);
    this.handleMouseMoveBound = this.onMouseMove.bind(this);
    this.handleMouseDownBound = this.onMouseDown.bind(this);
    this.handleMouseUpBound = this.onMouseUp.bind(this);
    this.handleContextMenuBound = (e: MouseEvent) => e.preventDefault();
    this.handlePointerLockChangeBound = this.onPointerLockChange.bind(this);
    this.handleWebglLostBound = (e: Event) => {
      e.preventDefault();
      this.onContextLostCallback?.();
    };

    window.addEventListener('resize', this.handleResizeBound);
    window.addEventListener('keydown', this.handleKeyDownBound);
    window.addEventListener('keyup', this.handleKeyUpBound);
    window.addEventListener('mousemove', this.handleMouseMoveBound);
    this.renderer.domElement.addEventListener('mousedown', this.handleMouseDownBound);
    window.addEventListener('mouseup', this.handleMouseUpBound);
    this.renderer.domElement.addEventListener('contextmenu', this.handleContextMenuBound);
    document.addEventListener('pointerlockchange', this.handlePointerLockChangeBound);
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleWebglLostBound);

    this.pushHudState();
    this.startLoop();
  }

  private syncShaderUniforms(): void {
    if (!this.bodycamPass) return;
    const u = this.bodycamPass.uniforms;
    u.uDistortion.value = this.settings.distortion;
    u.uAberration.value = this.settings.aberration * 0.01;
    u.uGrain.value = this.settings.grain * 0.11;
    u.uOpticalMode.value =
      this.settings.opticalMode === 'standard'
        ? 0
        : this.settings.opticalMode === 'lowlight'
          ? 1
          : 2;
  }

  public updateSettings(next: Partial<BodycamSettings>): void {
    const prevMood = this.settings.lightingMood;
    this.settings = { ...this.settings, ...next };
    this.renderer.toneMappingExposure = this.settings.exposure;
    this.audio.setEnabled(this.settings.audioEnabled);
    this.weapon.setFlashlight(this.settings.flashlightOn && this.flashlightBattery > 0.5);

    if (next.lightingMood && next.lightingMood !== prevMood) {
      this.world.applyLightingMood(next.lightingMood, this.scene);
    }
    this.syncShaderUniforms();
    this.pushHudState();
  }

  public startMission(): void {
    this.audio.init();
    this.phase = 'playing';
    this.requestLock();
    this.showStatusBanner('AXON-TAC // TRENCH ASSAULT ACTIVE', 3.2);
    this.pushHudState();
  }

  public resumeMission(): void {
    this.audio.init();
    this.phase = 'playing';
    this.requestLock();
    this.pushHudState();
  }

  public pauseMission(): void {
    this.phase = 'paused';
    if (document.pointerLockElement) document.exitPointerLock?.();
    this.pushHudState();
  }

  public setTouchMove(x: number, y: number, sprint: boolean): void {
    this.touchMoveX = THREE.MathUtils.clamp(x, -1, 1);
    this.touchMoveY = THREE.MathUtils.clamp(y, -1, 1);
    this.touchSprint = sprint;
  }

  public addTouchLook(dx: number, dy: number): void {
    if (this.phase !== 'playing') return;
    const sens = 0.0036 * this.settings.mouseSensitivity;
    this.yaw -= dx * sens;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * sens, -1.32, 1.32);
    this.weapon.addLookImpulse(dx * sens, dy * sens);
  }

  public triggerTouchFire(): void {
    if (this.phase !== 'playing') return;
    this.audio.init();
    this.tryFire();
  }

  public toggleTouchAim(): void {
    if (this.phase !== 'playing') return;
    this.isAiming = !this.isAiming;
    this.pushHudState();
  }

  public triggerTouchReload(): void {
    if (this.phase !== 'playing') return;
    this.audio.init();
    this.tryReload();
  }

  public triggerTouchInteract(): void {
    if (this.phase !== 'playing') return;
    this.audio.init();
    this.tryInteract();
  }

  public toggleFlashlight(): void {
    this.settings.flashlightOn = !this.settings.flashlightOn;
    this.audio.init();
    this.audio.playFlashlightClick();
    this.weapon.setFlashlight(this.settings.flashlightOn && this.flashlightBattery > 0.5);
    this.pushHudState();
  }

  public toggleCrouch(): void {
    this.touchCrouch = !this.touchCrouch;
    this.pushHudState();
  }

  public restartMission(): void {
    this.audio.init();
    this.playerPos.set(0, 1.48, 22.8);
    this.yaw = 0;
    this.pitch = 0;
    this.health = 100;
    this.ammo = this.magSize;
    this.reserveAmmo = 75;
    this.isReloading = false;
    this.touchCrouch = false;
    this.touchMoveX = 0;
    this.touchMoveY = 0;
    this.touchSprint = false;
    this.flashlightBattery = 100;
    this.elapsedSeconds = 0;

    // Reset objectives & hostiles
    for (const d of this.world.drives) {
      d.collected = false;
      const mesh = this.world.driveMeshes.get(d.id);
      if (mesh) mesh.visible = true;
    }
    for (const h of this.world.hostiles) {
      h.alive = true;
      h.hp = h.maxHp;
      h.alerted = false;
      h.group.visible = true;
      h.group.position.copy(h.waypoints[0]);
      h.currentWaypoint = 1 % h.waypoints.length;
    }

    this.phase = 'playing';
    this.requestLock();
    this.showStatusBanner('TRENCH DEPLOYMENT RESET // SECURE 3 FIELD RADIOS', 3.5);
    this.pushHudState();
  }

  public requestLock(): void {
    try {
      const el = this.renderer.domElement;
      if (document.pointerLockElement !== el && el.requestPointerLock) {
        const res = el.requestPointerLock() as unknown as Promise<void> | undefined;
        if (res && typeof res.catch === 'function') {
          res.catch(() => {
            // PointerLock blocked in sandboxed iframe; drag-look fallback works seamlessly
          });
        }
      }
    } catch {
      // Fallback drag look remains available
    }
  }

  private showStatusBanner(msg: string, duration = 2.6): void {
    this.statusBanner = msg;
    this.statusBannerTimer = duration;
  }

  private onPointerLockChange(): void {
    this.pushHudState();
  }

  private onKeyDown(e: KeyboardEvent): void {
    this.keys[e.code] = true;
    if (this.phase !== 'playing') return;

    if (e.code === 'KeyF') {
      this.settings.flashlightOn = !this.settings.flashlightOn;
      this.audio.playFlashlightClick();
      this.weapon.setFlashlight(this.settings.flashlightOn && this.flashlightBattery > 0.5);
      this.pushHudState();
    } else if (e.code === 'KeyR') {
      this.tryReload();
    } else if (e.code === 'KeyE') {
      this.tryInteract();
    } else if (e.code === 'KeyN') {
      const order: BodycamSettings['opticalMode'][] = ['standard', 'lowlight', 'ir_night'];
      const next = order[(order.indexOf(this.settings.opticalMode) + 1) % order.length];
      this.updateSettings({ opticalMode: next });
    } else if (e.code === 'KeyP') {
      this.phase = 'paused';
      if (document.pointerLockElement) document.exitPointerLock?.();
      this.pushHudState();
    }
  }

  private onKeyUp(e: KeyboardEvent): void {
    this.keys[e.code] = false;
  }

  private onMouseDown(e: MouseEvent): void {
    if (this.phase !== 'playing') return;
    this.audio.init();

    if (e.button === 0) {
      this.isMouseDown = true;
      this.isDraggingLook = true;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
      this.tryFire();
      if (document.pointerLockElement !== this.renderer.domElement) {
        this.requestLock();
      }
    } else if (e.button === 2) {
      this.isAiming = true;
      this.pushHudState();
    }
  }

  private onMouseUp(e: MouseEvent): void {
    if (e.button === 0) {
      this.isMouseDown = false;
      this.isDraggingLook = false;
    } else if (e.button === 2) {
      this.isAiming = false;
      this.pushHudState();
    }
  }

  private onMouseMove(e: MouseEvent): void {
    if (this.phase !== 'playing') return;

    const sens = 0.0021 * this.settings.mouseSensitivity;
    let dx = 0;
    let dy = 0;

    if (document.pointerLockElement === this.renderer.domElement) {
      dx = e.movementX;
      dy = e.movementY;
    } else if (this.isDraggingLook) {
      dx = e.clientX - this.lastPointerX;
      dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
    } else {
      return;
    }

    this.yaw -= dx * sens;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * sens, -1.32, 1.32);
    this.weapon.addLookImpulse(dx * sens, dy * sens);
  }

  private tryReload(): void {
    if (this.isReloading || this.ammo >= this.magSize || this.reserveAmmo <= 0) return;
    this.isReloading = true;
    this.reloadTimer = 1.15;
    this.weapon.triggerReload();
    this.audio.playReload();
    this.pushHudState();
  }

  private tryInteract(): void {
    // Check nearby encrypted evidence drives
    for (const drive of this.world.drives) {
      if (drive.collected) continue;
      if (this.playerPos.distanceTo(drive.position) < 2.6) {
        drive.collected = true;
        const mesh = this.world.driveMeshes.get(drive.id);
        if (mesh) mesh.visible = false;
        this.audio.playObjectivePickup();
        const collectedCount = this.world.drives.filter((d) => d.collected).length;
        if (collectedCount >= this.world.drives.length) {
          this.showStatusBanner('ALL DRIVES SECURED // PROCEED TO NORTH EXTRACTION GATE', 4.0);
        } else {
          this.showStatusBanner(
            `EVIDENCE RECOVERED: ${drive.label.toUpperCase()} (${collectedCount}/${this.world.drives.length})`,
            3.0,
          );
        }
        this.pushHudState();
        return;
      }
    }

    // Check extraction zone
    const allCollected = this.world.drives.every((d) => d.collected);
    if (allCollected && this.playerPos.distanceTo(this.world.extractionZone) < 3.5) {
      this.phase = 'extracted';
      this.audio.playObjectivePickup();
      if (document.pointerLockElement) document.exitPointerLock?.();
      this.pushHudState();
    }
  }

  private tryFire(): void {
    if (this.phase !== 'playing' || this.isReloading || this.fireCooldown > 0) return;

    if (this.ammo <= 0) {
      this.fireCooldown = 0.22;
      this.audio.playEmptyClick();
      this.tryReload();
      return;
    }

    this.ammo -= 1;
    this.fireCooldown = 0.16;
    this.impactShock = 1.0;

    // Subtle bodycam upward recoil kick
    this.pitch = THREE.MathUtils.clamp(this.pitch + 0.016, -1.32, 1.32);
    this.yaw += (Math.random() - 0.5) * 0.007;

    this.weapon.triggerFire();
    this.audio.playGunshot();

    // Hitscan from camera center
    _rayOrigin.copy(this.camera.position);
    this.camera.getWorldDirection(_rayDir);

    // Slight hipfire spread when not ADS
    if (!this.isAiming) {
      _rayDir.x += (Math.random() - 0.5) * 0.018;
      _rayDir.y += (Math.random() - 0.5) * 0.018;
      _rayDir.normalize();
    }

    this.raycaster.set(_rayOrigin, _rayDir);
    this.raycaster.far = 75;

    // Collect hostile hit meshes + solid world walls
    const targets: THREE.Object3D[] = [...this.world.raycastSolids];
    for (const h of this.world.hostiles) {
      if (h.alive) targets.push(...h.hitMeshes);
    }

    this.raycaster.layers.enableAll();
    const hits = this.raycaster.intersectObjects(targets, false);

    // Tracer origin from weapon muzzle
    this.weapon.muzzleFlashGroup.getWorldPosition(_muzzleWorld);
    const endPoint =
      hits.length > 0
        ? hits[0].point.clone()
        : _rayOrigin.clone().add(_rayDir.clone().multiplyScalar(45));

    this.spawnTracer(_muzzleWorld.clone(), endPoint, 0xffd580);

    if (hits.length > 0) {
      const hit = hits[0];
      const hostileId = hit.object.userData.hostileId as string | undefined;

      if (hostileId) {
        const unit = this.world.hostiles.find((u) => u.id === hostileId);
        if (unit && unit.alive) {
          unit.hp -= 38;
          unit.alerted = true;
          unit.hitFlashTimer = 0.08;
          this.hitMarkerTimer = 0.16;
          this.audio.playImpactSpark(true);
          this.spawnSparks(hit.point, 0xff7b29, 14);

          if (unit.hp <= 0) {
            unit.alive = false;
            unit.group.visible = false;
            this.spawnSparks(hit.point, 0xffaa33, 34);
            this.showStatusBanner('HOSTILE UNIT NEUTRALIZED', 2.0);
          }
        }
      } else {
        this.audio.playImpactSpark(false);
        this.spawnSparks(hit.point, 0xffcf77, 10);
      }
    }

    this.pushHudState();
  }

  private spawnTracer(start: THREE.Vector3, end: THREE.Vector3, colorHex: number): void {
    const geo = new THREE.BufferGeometry().setFromPoints([start, end]);
    const mat = new THREE.LineBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity: 0.85,
    });
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);
    this.tracers.push({ line, life: 0.055 });
  }

  private spawnSparks(origin: THREE.Vector3, colorHex: number, count: number): void {
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = origin.x;
      positions[i * 3 + 1] = origin.y;
      positions[i * 3 + 2] = origin.z;
      velocities[i * 3] = (Math.random() - 0.5) * 5.2;
      velocities[i * 3 + 1] = Math.random() * 4.2;
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 5.2;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: colorHex,
      size: 0.08,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const points = new THREE.Points(geo, mat);
    this.scene.add(points);
    this.sparks.push({ points, velocities, life: 0.35 });
  }

  private resolvePlayerMovement(dt: number): { isMoving: boolean; isSprinting: boolean; isCrouching: boolean } {
    const keyFwd = (this.keys['KeyW'] ? 1 : 0) - (this.keys['KeyS'] ? 1 : 0);
    const keyStrafe = (this.keys['KeyD'] ? 1 : 0) - (this.keys['KeyA'] ? 1 : 0);
    const forwardInput = THREE.MathUtils.clamp(keyFwd + this.touchMoveY, -1, 1);
    const strafeInput = THREE.MathUtils.clamp(keyStrafe + this.touchMoveX, -1, 1);
    const isCrouching = Boolean(this.keys['KeyC'] || this.keys['ControlLeft'] || this.touchCrouch);
    const isSprinting =
      (Boolean(this.keys['ShiftLeft'] || this.keys['ShiftRight']) || this.touchSprint) &&
      forwardInput > 0.2 &&
      !isCrouching &&
      !this.isAiming;

    const speed = isCrouching ? 2.4 : isSprinting ? 5.6 : this.isAiming ? 2.8 : 3.9;

    _forward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    _right.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    _move.set(0, 0, 0);
    _move.addScaledVector(_forward, forwardInput);
    _move.addScaledVector(_right, strafeInput);

    const isMoving = _move.lengthSq() > 0.002;
    if (isMoving) {
      const mag = Math.min(1, _move.length());
      _move.normalize().multiplyScalar(speed * mag * dt);
      this.moveWithSlidingCollision(_move.x, _move.z);

      const stepLen = _move.length();
      this.stepDistAccum += stepLen;
      const stepStride = isSprinting ? 1.55 : 1.15;
      if (this.stepDistAccum >= stepStride) {
        this.stepDistAccum = 0;
        this.audio.playFootstep(isSprinting);
      }
    }

    // Tactical lean Q / Z
    const leanTilt = (this.keys['KeyQ'] ? 1 : 0) - (this.keys['KeyZ'] ? 1 : 0);
    const targetRoll = leanTilt * 0.14 + strafeInput * -0.025;
    this.currentRoll = THREE.MathUtils.damp(this.currentRoll, targetRoll, 10, dt);

    // Chest-mounted camera bob & height damping
    const baseHeight = isCrouching ? 0.98 : 1.48;
    const bobRate = isSprinting ? 11.5 : isMoving ? 7.5 : 1.6;
    this.walkPhase += dt * bobRate;
    const bobY = isMoving ? Math.sin(this.walkPhase) * (isSprinting ? 0.045 : 0.024) : Math.sin(this.walkPhase) * 0.004;
    const bobRoll = isMoving ? Math.cos(this.walkPhase * 0.5) * (isSprinting ? 0.016 : 0.007) : 0;

    this.playerPos.y = THREE.MathUtils.damp(this.playerPos.y, baseHeight, 12, dt);

    // Smooth FOV zoom on ADS / Sprint
    const targetFov = this.isAiming ? 68 : isSprinting ? 96 : 90;
    this.currentFov = THREE.MathUtils.damp(this.currentFov, targetFov, 12, dt);
    if (Math.abs(this.camera.fov - this.currentFov) > 0.05) {
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    // Apply lean lateral offset
    const leanOffsetX = Math.cos(this.yaw) * (-leanTilt * 0.22);
    const leanOffsetZ = -Math.sin(this.yaw) * (-leanTilt * 0.22);

    this.camera.position.set(
      this.playerPos.x + leanOffsetX,
      this.playerPos.y + bobY,
      this.playerPos.z + leanOffsetZ,
    );
    this.camera.rotation.set(this.pitch, this.yaw, this.currentRoll + bobRoll, 'YXZ');

    return { isMoving, isSprinting, isCrouching };
  }

  private moveWithSlidingCollision(dx: number, dz: number): void {
    const r = 0.42;

    // Try X axis
    const nextX = this.playerPos.x + dx;
    if (!this.collidesAt(nextX, this.playerPos.z, r)) {
      this.playerPos.x = nextX;
    }

    // Try Z axis
    const nextZ = this.playerPos.z + dz;
    if (!this.collidesAt(this.playerPos.x, nextZ, r)) {
      this.playerPos.z = nextZ;
    }
  }

  private collidesAt(x: number, z: number, r: number): boolean {
    for (const b of this.world.colliders) {
      if (b.maxY < 0.3) continue;
      if (
        x + r > b.minX &&
        x - r < b.maxX &&
        z + r > b.minZ &&
        z - r < b.maxZ
      ) {
        return true;
      }
    }
    return false;
  }

  private updateEffects(dt: number): void {
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const tr = this.tracers[i];
      tr.life -= dt;
      if (tr.life <= 0) {
        this.scene.remove(tr.line);
        tr.line.geometry.dispose();
        (tr.line.material as THREE.Material).dispose();
        this.tracers.splice(i, 1);
      } else {
        (tr.line.material as THREE.LineBasicMaterial).opacity = tr.life / 0.055;
      }
    }

    for (let i = this.sparks.length - 1; i >= 0; i--) {
      const sp = this.sparks[i];
      sp.life -= dt;
      if (sp.life <= 0) {
        this.scene.remove(sp.points);
        sp.points.geometry.dispose();
        (sp.points.material as THREE.Material).dispose();
        this.sparks.splice(i, 1);
      } else {
        const pos = sp.points.geometry.attributes.position as THREE.BufferAttribute;
        const arr = pos.array as Float32Array;
        for (let j = 0; j < arr.length; j += 3) {
          sp.velocities[j + 1] -= 9.8 * dt;
          arr[j] += sp.velocities[j] * dt;
          arr[j + 1] += sp.velocities[j + 1] * dt;
          arr[j + 2] += sp.velocities[j + 2] * dt;
        }
        pos.needsUpdate = true;
        (sp.points.material as THREE.PointsMaterial).opacity = sp.life / 0.35;
      }
    }
  }

  private computeNearbyPrompt(): string | null {
    for (const d of this.world.drives) {
      if (!d.collected && this.playerPos.distanceTo(d.position) < 2.6) {
        return `[E] Recover ${d.label}`;
      }
    }
    const allCollected = this.world.drives.every((d) => d.collected);
    if (allCollected && this.playerPos.distanceTo(this.world.extractionZone) < 3.5) {
      return '[E] Confirm Extraction & Upload Bodycam Feed';
    }
    return null;
  }

  private pushHudState(): void {
    const drivesCollected = this.world.drives.filter((d) => d.collected).length;
    const hostilesNeutralized = this.world.hostiles.filter((h) => !h.alive).length;
    const extractionReady = drivesCollected >= this.world.drives.length;

    this.onHudUpdate({
      phase: this.phase,
      health: Math.max(0, Math.round(this.health)),
      maxHealth: this.maxHealth,
      ammo: this.ammo,
      magSize: this.magSize,
      reserveAmmo: this.reserveAmmo,
      isReloading: this.isReloading,
      isAiming: this.isAiming,
      isSprinting: Boolean(this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchSprint),
      isCrouching: Boolean(this.keys['KeyC'] || this.keys['ControlLeft'] || this.touchCrouch),
      flashlightOn: this.settings.flashlightOn && this.flashlightBattery > 0.5,
      flashlightBattery: Math.round(this.flashlightBattery),
      drivesCollected,
      totalDrives: this.world.drives.length,
      hostilesNeutralized,
      totalHostiles: this.world.hostiles.length,
      extractionReady,
      nearbyPrompt: this.phase === 'playing' ? this.computeNearbyPrompt() : null,
      currentZone: this.world.getZoneName(this.playerPos),
      hitMarkerTimer: this.hitMarkerTimer,
      damageFlashTimer: this.damageFlashTimer,
      elapsedSeconds: this.elapsedSeconds,
      pointerLocked: document.pointerLockElement === this.renderer.domElement,
      statusBanner: this.statusBanner,
    });
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private startLoop(): void {
    const tick = () => {
      if (this.disposed) return;
      const dt = Math.min(this.clock.getDelta(), 0.05);
      const elapsed = this.clock.elapsedTime;

      const extractionReady = this.world.drives.every((d) => d.collected);
      this.world.update(dt, elapsed, extractionReady);

      if (this.phase === 'playing') {
        this.elapsedSeconds += dt;
        const { isMoving, isSprinting, isCrouching } = this.resolvePlayerMovement(dt);

        // Reload timer
        if (this.isReloading) {
          this.reloadTimer -= dt;
          if (this.reloadTimer <= 0) {
            const needed = this.magSize - this.ammo;
            const take = Math.min(needed, this.reserveAmmo);
            this.ammo += take;
            this.reserveAmmo -= take;
            this.isReloading = false;
          }
        }

        if (this.fireCooldown > 0) this.fireCooldown -= dt;
        if (this.hitMarkerTimer > 0) this.hitMarkerTimer = Math.max(0, this.hitMarkerTimer - dt);
        if (this.damageFlashTimer > 0) this.damageFlashTimer = Math.max(0, this.damageFlashTimer - dt);
        if (this.statusBannerTimer > 0) {
          this.statusBannerTimer -= dt;
          if (this.statusBannerTimer <= 0) this.statusBanner = null;
        }
        this.impactShock = THREE.MathUtils.damp(this.impactShock, 0, 14, dt);

        // Subtle tactical flashlight battery drain + flicker when low
        if (this.settings.flashlightOn && this.flashlightBattery > 0) {
          this.flashlightBattery = Math.max(0, this.flashlightBattery - dt * 0.35);
          const flicker =
            this.flashlightBattery < 12
              ? Math.sin(elapsed * 45) > 0.3
                ? 1.0
                : 0.2
              : 1.0;
          this.weapon.setFlashlight(this.flashlightBattery > 0.5, flicker);
        }

        this.weapon.update(dt, isMoving, isSprinting, this.isAiming, isCrouching);

        // Update hostiles AI
        updateHostiles(
          this.world.hostiles,
          this.playerPos,
          this.world.raycastSolids,
          this.raycaster,
          dt,
          (origin, target, hitPlayer) => {
            this.spawnTracer(origin, target, 0xff4040);
            if (hitPlayer && this.phase === 'playing') {
              this.health = Math.max(0, this.health - 12);
              this.damageFlashTimer = 0.42;
              this.impactShock = 1.0;
              this.audio.playDamageHit();
              if (this.health <= 0) {
                this.phase = 'down';
                if (document.pointerLockElement) document.exitPointerLock?.();
              }
              this.pushHudState();
            }
          },
        );
      } else {
        // Gentle idle camera drift on briefing/menu screen overlooking the compound
        const previewAngle = Math.sin(elapsed * 0.16) * 0.18;
        this.camera.position.set(0, 1.56, 20.5);
        this.camera.rotation.set(-0.04, previewAngle, 0, 'YXZ');
        this.weapon.update(dt, false, false, false, false);
      }

      this.updateEffects(dt);

      // Update bodycam optical shader uniforms
      if (this.bodycamPass) {
        this.bodycamPass.uniforms.uTime.value = elapsed;
        this.bodycamPass.uniforms.uImpactShock.value = this.impactShock;
        this.bodycamPass.uniforms.uDamagePulse.value = this.damageFlashTimer / 0.42;
      }

      // Render via composer on GPU, or direct renderer on software WebGL
      if (this.isSoftwareGl || !this.composer) {
        this.renderer.render(this.scene, this.camera);
      } else {
        this.composer.render();
      }

      // Throttle HUD updates to ~15 Hz for crisp UI without React churn
      this.hudSyncTimer += dt;
      if (this.hudSyncTimer >= 0.065) {
        this.hudSyncTimer = 0;
        this.pushHudState();
      }

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.frameId = window.setTimeout(tick, 16);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  private onResize(): void {
    if (this.disposed) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    if (this.composer) {
      this.composer.setSize(width, height);
    }
    if (this.bloomPass) {
      this.bloomPass.resolution.set(width, height);
    }
    if (this.bodycamPass) {
      this.bodycamPass.uniforms.uAspect.value = width / height;
    }
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResizeBound);
    window.removeEventListener('keydown', this.handleKeyDownBound);
    window.removeEventListener('keyup', this.handleKeyUpBound);
    window.removeEventListener('mousemove', this.handleMouseMoveBound);
    this.renderer.domElement.removeEventListener('mousedown', this.handleMouseDownBound);
    window.removeEventListener('mouseup', this.handleMouseUpBound);
    this.renderer.domElement.removeEventListener('contextmenu', this.handleContextMenuBound);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChangeBound);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleWebglLostBound);

    this.weapon.dispose();
    this.world.dispose();
    this.texLib.disposeAll();
    this.audio.dispose();
    if (this.composer) this.composer.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
