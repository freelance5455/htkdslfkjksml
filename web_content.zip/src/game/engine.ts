import type { RapierRigidBody } from '@react-three/rapier';
import {FORMATIONS, PLAYERS, PLAYERS_BY_ID, effectivePlayer, type Player, type Position} from '../data/players';
import type {MatchRecord,Settings} from '../store';
export type Side=0|1;
export type Phase='kickoff'|'playing'|'goal'|'half'|'full'|'paused'|'restart';
export type Footballer={id:number;card:Player;side:Side;slot:number;x:number;z:number;vx:number;vz:number;face:number;stamina:number;skillUntil:number;cooldown:number;aiTimer:number;anim:number;};
export type MatchStats=MatchRecord['stats'];
export type MatchView={phase:Phase;clock:number;half:number;score:[number,number];homePossession:number;stats:MatchStats;notice:string;noticeUntil:number;charge:number;selected:number;holding:Side|null;setPiece:string;goalScorers:string[];replay:boolean;playerRatings:{name:string;rating:number;goals:number;shots:number;passes:number;tackles:number}[];};
type Frame={ball:[number,number,number];people:[number,number][];};
const FIELD_X=52.5,FIELD_Z=34,GOAL_Z=3.66;
const bounds=(v:number,a:number,b:number)=>Math.max(a,Math.min(b,v));
const len=(x:number,z:number)=>Math.hypot(x,z)||1;
const distance=(a:{x:number;z:number},b:{x:number;z:number})=>Math.hypot(a.x-b.x,a.z-b.z);
export const BASE_FORMATION:Record<Position,[number,number]>={GK:[-48,0],LB:[-33,-25],CB:[-37,-10],RB:[-33,25],CDM:[-19,0],CM:[-16,12],CAM:[-9,0],LM:[-15,-28],RM:[-15,28],LW:[-7,-26],RW:[-7,26],ST:[-6,0]};
function formationCoords(roles:Position[]){const count:Record<string,number>={};return roles.map((role,i):[number,number]=>{count[role]=(count[role]||0)+1;
 if(role==='CB')return[-38,count[role]===1?-11:count[role]===2?11:0];
 if(role==='CM')return[-18,count[role]===1?-15:count[role]===2?15:0];
 if(role==='CDM')return[-23,count[role]===1?-9:9];
 if(role==='CAM')return[-9,count[role]===1?0:count[role]===2?-12:12];
 if(role==='ST')return[-7,count[role]===1?-7:7];
 if(role==='LM')return[-15,-26];if(role==='RM')return[-15,26];
 return BASE_FORMATION[role]||[-16,(i-5)*5];});}
function makeTeam(ids:number[],side:Side,formation:string,training:Record<number,number>):Footballer[]{const coords=formationCoords(FORMATIONS[formation]||FORMATIONS['4-3-3']);return ids.map((id,i)=>{const c=coords[i],card=side===0?effectivePlayer(PLAYERS_BY_ID.get(id)!,training[id]||0):PLAYERS_BY_ID.get(id)!;return{id,card,side,slot:i,x:c[0]*(side===0?1:-1),z:c[1]*(side===0?1:-1),vx:0,vz:0,face:side===0?0:Math.PI,stamina:100,skillUntil:0,cooldown:0,aiTimer:0.6+i*.14,anim:0};});}
export class MatchEngine {
 people:Footballer[];ball:RapierRigidBody|null=null; ballPos:[number,number,number]=[0,.23,0];ballVelocity:[number,number,number]=[0,0,0];phase:Phase='kickoff';pausedFrom:Phase='playing';half=1;clock=0;score:[number,number]=[0,0];
 selected=9; joystick={x:0,z:0}; keeperHold=0; holder:number|null=9; lastTouch:Side=0;lastTouchSlot=9; charge=0; aiming={x:52,z:0}; held=new Set<string>();manualShot=false;
 notice='KICKOFF';noticeUntil=1.5;goalTimer=0;restartTimer=0;restartName='';restartSide:Side=0;restartX=0;restartZ=0;lastScorer='';goalScorers:string[]=[];playerActions:{goals:number;shots:number;passes:number;tackles:number}[]=Array.from({length:22},()=>({goals:0,shots:0,passes:0,tackles:0}));
 statShots:[number,number]=[0,0];statPasses:[number,number]=[0,0];statSaves:[number,number]=[0,0];statTackles:[number,number]=[0,0];possessions:[number,number]=[1,1];
 frames:Frame[]=[];frameClock=0;replayFrames:Frame[]=[];replayProgress=0;elapsed=0;aiLevel=0;settings:Settings;tactic:'Balanced'|'Attacking'|'Defensive';
 formation:string;onView:((view:MatchView)=>void)|null=null;onWhistle:((sound:'kick'|'whistle'|'goal')=>void)|null=null;uiClock=0;
 constructor(squad:number[],training:Record<number,number>,formation:string,rank:number,settings:Settings,tactic:'Balanced'|'Attacking'|'Defensive',chemistry=72,captain=-1){
  this.aiLevel=Math.min(18,rank);this.settings=settings;this.tactic=tactic;this.formation=formation;
  const wanted=bounds(Math.round(58+rank*1.2),58,84);const roles=FORMATIONS[formation]||FORMATIONS['4-3-3'];const opponent=roles.map((role,index)=>{
    const options=PLAYERS.filter(p=>p.position===role && !squad.includes(p.id)).sort((a,b)=>Math.abs(a.overall-(wanted+(index%3-1)*4))-Math.abs(b.overall-(wanted+(index%3-1)*4)));
    return options[0].id;
  });
  // A local unique-id list avoids duplicate opponents.
  const seen=new Set<number>();opponent.forEach((id,i)=>{if(seen.has(id)){const alt=PLAYERS.filter(p=>p.position===roles[i]&&!seen.has(p.id)).sort((a,b)=>Math.abs(a.overall-wanted)-Math.abs(b.overall-wanted))[0];opponent[i]=alt.id;}seen.add(opponent[i]);});
  const home=makeTeam(squad,0,formation,training);const boost=Math.round((chemistry-65)/13);home.forEach((p,i)=>{const rightRole=roles[i]===p.card.position;const fit=rightRole?0:-4;const captainBonus=p.id===captain?2:0;const bump=(n:number)=>bounds(n+boost+fit+captainBonus,25,99);p.card={...p.card,passing:bump(p.card.passing),dribbling:bump(p.card.dribbling),defending:bump(p.card.defending),physical:bump(p.card.physical),stamina:bump(p.card.stamina)};});this.people=[...home,...makeTeam(opponent,1,formation,{})];this.selected=9;this.resetKickoff(0);
 }
 get stats():MatchStats {const total=this.possessions[0]+this.possessions[1];return{shots:this.statShots[0],shotsAgainst:this.statShots[1],passes:this.statPasses[0],passesAgainst:this.statPasses[1],possession:Math.round(this.possessions[0]/total*100),tackles:this.statTackles[0],saves:this.statSaves[0]};}
 view():MatchView{return{phase:this.phase,clock:this.clock,half:this.half,score:[...this.score] as [number,number],homePossession:this.stats.possession,stats:this.stats,notice:this.notice,noticeUntil:this.noticeUntil,charge:this.charge,selected:this.selected,holding:this.holder===null?null:this.people[this.holder].side,setPiece:this.restartName,goalScorers:[...this.goalScorers],playerRatings:this.people.slice(0,11).map((p,i)=>{const a=this.playerActions[i];return{name:p.card.name,goals:a.goals,shots:a.shots,passes:a.passes,tackles:a.tackles,rating:Math.min(10,Math.round((6+a.goals*1.6+a.shots*.35+a.passes*.07+a.tackles*.4)*10)/10)};}).sort((a,b)=>b.rating-a.rating),replay:this.phase==='goal'};}
 announce(message:string,duration=2.2){this.notice=message;this.noticeUntil=duration;}
 attachBall(ball:RapierRigidBody){this.ball=ball;this.ball.setTranslation({x:0,y:.23,z:0},true);this.ball.setLinvel({x:0,y:0,z:0},true);}
 placeBall(x:number,y:number,z:number){this.ballPos=[x,y,z];if(this.ball){this.ball.setTranslation({x,y,z},true);this.ball.setLinvel({x:0,y:0,z:0},true);this.ball.setAngvel({x:0,y:0,z:0},true);}}
 setAim(x:number,z:number){this.aiming.x=bounds(x,-FIELD_X-3,FIELD_X+3);this.aiming.z=bounds(z,-FIELD_Z-3,FIELD_Z+3);}
 keyDown(code:string){this.held.add(code);if(code==='Escape'){this.togglePause();return;}if(this.phase!=='playing')return;
 if(code==='Space'){if(this.holder!==null&&this.people[this.holder].side===0&&this.holder===this.selected)this.doSkill();else this.selectDefender();}
 if(code==='KeyE'||(code==='ShiftLeft'&&!this.isAttacking()))this.tackle();}
 keyUp(code:string){this.held.delete(code);}
 isAttacking(){return this.holder!==null&&this.people[this.holder].side===0;}
 setJoystick(x:number,z:number){this.joystick={x:bounds(x,-1,1),z:bounds(z,-1,1)};}
 actionSkill(){if(this.phase!=='playing')return;if(this.isAttacking()&&this.holder===this.selected)this.doSkill();else this.selectDefender();}
 actionSprint(){if(this.phase==='playing'&&!this.isAttacking())this.tackle();}
 togglePause(){if(this.phase==='paused'){this.phase=this.pausedFrom;}else if(['playing','restart','kickoff'].includes(this.phase)){this.pausedFrom=this.phase;this.phase='paused';}}
 start(){this.phase='playing';this.announce('KICKOFF',1.8);}
 secondHalf(){this.half=2;this.clock=45*60;this.resetKickoff(1);this.phase='playing';this.announce('SECOND HALF',2);}
 resetKickoff(side:Side){const coords=formationCoords(FORMATIONS[this.formation]);this.people.forEach((p)=>{const c=coords[p.slot];p.x=c[0]*(p.side===0?1:-1);p.z=c[1]*(p.side===0?1:-1);p.vx=0;p.vz=0;p.stamina=Math.min(100,p.stamina+12);p.aiTimer=.5;});
 this.holder=side===0?9:20;this.selected=9;this.keeperHold=0;this.placeBall(0,.23,0);this.people[this.holder].x=side===0?-1:1;this.people[this.holder].z=0;this.lastTouch=side;}
 selectDefender(){const choices=this.people.slice(0,11).filter(p=>p.slot!==0).sort((a,b)=>distance(a,{x:this.ballPos[0],z:this.ballPos[2]})-distance(b,{x:this.ballPos[0],z:this.ballPos[2]}));this.selected=choices[0].slot;}
 doSkill(){const p=this.people[this.selected];if(p.cooldown>0||p.stamina<12)return;p.skillUntil=.55;p.cooldown=2;p.stamina-=9;this.announce('SKILL MOVE',.5);}
 tackle(){if(this.phase!=='playing')return;const p=this.people[this.selected];if(p.cooldown>0||p.stamina<8)return;p.cooldown=.85;p.stamina-=6;
 const carrier=this.holder===null?null:this.people[this.holder];if(carrier?.side===1&&distance(p,carrier)<3.35){this.statTackles[0]++;this.playerActions[this.selected].tackles++;const advantage=(p.card.defending+(.5+p.stamina/200)*p.card.physical)/2;
 const beaten=(carrier.card.dribbling+carrier.card.physical)/2;const roll=Math.random()*35-12;
 if(advantage+roll>beaten){this.holder=this.selected;this.lastTouch=0;this.lastTouchSlot=p.slot;this.announce('BALL WON',1);this.onWhistle?.('kick');}
 else if(Math.random()<.22){this.foul(0,carrier.x,carrier.z);}else this.announce('TACKLE MISSED',1);
 }else if(this.holder===null&&distance(p,{x:this.ballPos[0],z:this.ballPos[2]})<2.8){this.holder=this.selected;this.lastTouch=0;}}
 touchShotDown(){if(this.phase==='playing'&&this.isAttacking()&&this.holder===this.selected)this.charge=.001;}
 touchShotUp(){if(this.phase!=='playing'||this.charge===0)return;const duration=this.charge;this.charge=0;const p=this.people[this.selected];if(this.holder!==this.selected||p.side!==0)return;const face={x:Math.cos(p.face),z:Math.sin(p.face)};if(duration<.23){const mates=this.people.slice(0,11).filter(t=>t.slot!==p.slot&&t.slot!==0).map(t=>({p:t,forward:(t.x-p.x)*face.x+(t.z-p.z)*face.z,side:Math.abs((t.x-p.x)*face.z-(t.z-p.z)*face.x)})).filter(t=>t.forward>1).sort((a,b)=>a.side-b.side);const t=mates[0]?.p;this.kick(p,t?{x:t.x+t.vx*.2,z:t.z+t.vz*.2}:{x:p.x+face.x*17,z:p.z+face.z*17},'pass',.7);}else{this.kick(p,{x:p.x+face.x*45,z:p.z+face.z*45},'shot',bounds((duration-.16)/1.6,.16,1));}}
 cancelShot(){this.charge=0;}
 mouseDown(){if(this.phase==='playing'&&this.isAttacking()&&this.holder===this.selected)this.charge=.001;}
 mouseUp(){if(this.phase!=='playing'||this.charge===0)return;const duration=this.charge;this.charge=0;const holder=this.holder!==null?this.people[this.holder]:null;
 if(!holder||holder.side!==0||holder.slot!==this.selected)return;
 if(duration<.23)this.playerPass();else this.playerShot(duration);}
 playerPass(){const p=this.people[this.selected],dirX=this.aiming.x-p.x,dirZ=this.aiming.z-p.z,angle=Math.atan2(dirZ,dirX);
 const mates=this.people.slice(0,11).filter(t=>t.slot!==p.slot&&t.slot!==0);
 const candidates=mates.map(t=>{const d=distance(p,t),da=Math.abs(Math.atan2(Math.sin(Math.atan2(t.z-p.z,t.x-p.x)-angle),Math.cos(Math.atan2(t.z-p.z,t.x-p.x)-angle)));
 const openness=Math.min(...this.people.slice(11).map(o=>distance(o,t)));return {p:t,score:da*18+Math.abs(d-18)*.23-Math.min(4,openness)*.7};}).sort((a,b)=>a.score-b.score);
 const mate=candidates[0]?.p;const target=mate&&candidates[0].score<22?{x:mate.x+mate.vx*.25,z:mate.z+mate.vz*.25}:this.aiming;
 this.kick(p,target,'pass',.7);}
 playerShot(duration:number){const p=this.people[this.selected];const power=bounds((duration-.16)/1.6,.16,1);
 let x=this.aiming.x,z=this.aiming.z;if(Math.hypot(x-p.x,z-p.z)<7||x<p.x+5){x=55;z=bounds(this.aiming.z,-9,9);}this.kick(p,{x,z},'shot',power);}
 kick(p:Footballer,target:{x:number;z:number},type:'pass'|'shot'|'cross',power:number){if(this.phase!=='playing')return;
 const dx=target.x-p.x,dz=target.z-p.z,d=Math.max(.001,len(dx,dz));const accuracy=(type==='shot'?p.card.shooting:p.card.passing)/100;
 const dispersion=(1-accuracy)*(.7+Math.random()*.9)*(type==='shot'?2.7:1.6);
 const drift=(Math.random()-.5)*dispersion;const tx=dx/d*Math.cos(drift)-dz/d*Math.sin(drift),tz=dx/d*Math.sin(drift)+dz/d*Math.cos(drift);
 const speed=type==='shot'?26+power*27+(p.card.shooting-60)*.12:type==='cross'?24:29+p.card.passing*.085;
 const lift=type==='shot'?4.0+power*7.0:type==='cross'?5.8:.12;
 const offside=type==='pass'&&this.isOffside(p,target);
 this.holder=null;this.lastTouch=p.side;this.lastTouchSlot=p.slot;
 this.placeBall(p.x+tx*1.15,.4,p.z+tz*1.15);this.ballVelocity=[tx*speed,lift,tz*speed];this.ball?.setLinvel({x:tx*speed,y:lift,z:tz*speed},true);
 this.ball?.setAngvel({x:tz*6,y:3*(Math.random()-.5),z:-tx*6},true);
 if(type==='shot'){this.statShots[p.side]++;this.playerActions[p.side*11+p.slot].shots++;this.announce(p.side===0?'SHOT!':'OPPOSITION SHOT',1.2);}
 else {this.statPasses[p.side]++;this.playerActions[p.side*11+p.slot].passes++;}
 this.onWhistle?.('kick');if(offside){this.restart('OFFSIDE',(1-p.side) as Side,p.x,p.z);}
 }
 isOffside(p:Footballer,target:{x:number;z:number}){const dir=p.side===0?1:-1;const defenders=this.people.filter(a=>a.side!==p.side).map(a=>a.x*dir).sort((a,b)=>b-a);const line=defenders[1]||0;
 const receiver=this.people.filter(a=>a.side===p.side&&a.slot!==p.slot).sort((a,b)=>Math.hypot(a.x-target.x,a.z-target.z)-Math.hypot(b.x-target.x,b.z-target.z))[0];
 return !!receiver&&receiver.x*dir>Math.max(0,p.x*dir,line)+1.5&&Math.hypot(receiver.x-target.x,receiver.z-target.z)<10;}
 foul(aggressor:Side,x:number,z:number){const other=(1-aggressor) as Side;const inBox=(other===0?x>36:x<-36)&&Math.abs(z)<20.2;
 this.restart(inBox?'PENALTY':'FREE KICK',other,inBox?(other===0?41.5:-41.5):x,z);this.onWhistle?.('whistle');}
 restart(name:string,side:Side,x:number,z:number){this.phase='restart';this.restartName=name;this.restartSide=side;this.restartX=bounds(x,-50,50);this.restartZ=bounds(z,-32,32);this.restartTimer=1.75;this.holder=null;this.placeBall(this.restartX,.23,this.restartZ);this.announce(name,2.3);this.onWhistle?.('whistle');}
 takeRestart(){const side=this.restartSide;const choices=this.people.filter(p=>p.side===side);const taker=[...choices].sort((a,b)=>distance(a,{x:this.restartX,z:this.restartZ})-distance(b,{x:this.restartX,z:this.restartZ}))[0];taker.x=this.restartX+(side===0?-1:1)*.7;taker.z=this.restartZ;
 this.holder=taker.side*11+taker.slot;this.lastTouch=side;this.lastTouchSlot=taker.slot;this.phase='playing';
 if(side===0&&taker.slot!==0)this.selected=taker.slot;
 if(this.restartName==='PENALTY'){const goalX=side===0?54:-54;this.kick(taker,{x:goalX,z:(Math.random()-.5)*4.2},'shot',.86);}
 else if(side===1){const target=this.choosePass(taker);if(target)this.kick(taker,target,'pass',.45);}
 else this.announce('PLAY RESUMED',.8);
 this.restartName='';}
 choosePass(p:Footballer){const mates=this.people.filter(a=>a.side===p.side&&a.slot!==p.slot&&a.slot!==0);const opponents=this.people.filter(a=>a.side!==p.side);
 const scored=mates.map(t=>{const d=distance(p,t),progress=(t.x-p.x)*(p.side===0?1:-1),space=Math.min(...opponents.map(o=>distance(o,t)));const lane=opponents.some(o=>{
 const vx=t.x-p.x,vz=t.z-p.z,L=vx*vx+vz*vz;const k=bounds(((o.x-p.x)*vx+(o.z-p.z)*vz)/Math.max(L,1),0,1);return k>.1&&k<.9&&Math.hypot(o.x-(p.x+vx*k),o.z-(p.z+vz*k))<2.8;});
 return{t,score:progress*.85+Math.min(space,10)*1.6-Math.abs(d-16)*.65-(lane?18:0)-(t.x*(p.side===0?1:-1)>48?12:0)};}).sort((a,b)=>b.score-a.score);
 return scored[0]?.t;}
 aiDecision(p:Footballer){if(this.holder!==p.side*11+p.slot)return;
 const dir=p.side===0?1:-1,goalX=dir*52.5,dGoal=Math.abs(p.x-goalX),dZ=Math.abs(p.z);
 const pressure=Math.min(...this.people.filter(o=>o.side!==p.side).map(o=>distance(o,p)));
 const level=p.side===1?this.aiLevel/18:.6;
 const shouldShoot=dGoal<26 && dZ<23 && (dGoal<13||Math.random()<.3+level*.3);
 if(shouldShoot){this.kick(p,{x:goalX+dir*2,z:(Math.random()-.5)*(7-level*3)},'shot',bounds(.5+level*.37,.3,.94));return;}
 const receiver=this.choosePass(p);
 if(receiver && (pressure<9||Math.random()<.66+level*.13) && receiver.x*dir>p.x*dir-13){this.kick(p,{x:receiver.x+receiver.vx*.2,z:receiver.z+receiver.vz*.2},'pass',.45);return;}
 p.aiTimer=.35+(1-level)*.6+Math.random()*.6;
 }
 adjustBall(){if(this.ball){const a=this.ball.translation(),v=this.ball.linvel();this.ballPos=[a.x,a.y,a.z];this.ballVelocity=[v.x,v.y,v.z];}}
 simulate(dt:number){if(this.phase==='paused'||this.phase==='half'||this.phase==='full')return;
 this.elapsed+=dt;this.noticeUntil=Math.max(0,this.noticeUntil-dt);
 if(this.phase==='goal'){this.goalTimer-=dt;this.replayProgress+=dt;if(this.replayFrames.length){const idx=Math.min(this.replayFrames.length-1,Math.floor((this.replayProgress/3.1)*this.replayFrames.length));const f=this.replayFrames[idx];if(f){f.people.forEach(([x,z],i)=>{this.people[i].x=x;this.people[i].z=z;});this.placeBall(...f.ball);}}if(this.goalTimer<=0){this.resetKickoff(this.lastTouch===0?1:0);this.phase='playing';this.frames=[];this.announce('KICKOFF',1);}return;}
 if(this.phase==='kickoff')return;
 if(this.phase==='restart'){this.restartTimer-=dt;if(this.restartTimer<=0)this.takeRestart();return;}
 const gameRate=30;this.clock+=dt*gameRate;
 if(this.clock>=(this.half===1?2700:5400)){this.clock=this.half===1?2700:5400;this.phase=this.half===1?'half':'full';this.charge=0;this.onWhistle?.('whistle');return;}
 if(this.charge>0)this.charge=Math.min(2.3,this.charge+dt);
 this.adjustBall();
 if(this.holder===null){for(const g of [this.people[0],this.people[11]]){const goalX=g.side===0?-52.5:52.5;const dx=this.ballPos[0]-g.x,dz=this.ballPos[2]-g.z;const incoming=this.ballVelocity[0]*(g.side===0?-1:1)>2;const nearBox=Math.abs(this.ballPos[0]-goalX)<18;const reach=1.5+g.card.keeper/47; if(nearBox&&incoming&&Math.hypot(dx,dz)<reach&&this.ballPos[1]<2.5){const shotSpeed=Math.hypot(this.ballVelocity[0],this.ballVelocity[2]);const catchChance=bounds((g.card.keeper-28)/85+(shotSpeed<26?.35:0),.15,.92);this.lastTouch=g.side;this.lastTouchSlot=0;if(Math.random()<catchChance){this.holder=g.side*11;this.keeperHold=1.2+Math.random()*1.1;this.statSaves[g.side]++;this.announce('GOALKEEPER CATCH',1.25);this.placeBall(g.x,.8,g.z);}else{const sign=g.side===0?1:-1;this.ball?.setLinvel({x:sign*9,y:3+Math.random()*3,z:(dz>=0?1:-1)*(12+Math.random()*7)},true);this.ballVelocity=[sign*9,4,(dz>=0?1:-1)*14];this.statSaves[g.side]++;this.announce('SAVE AND PARRY',1.2);}break;}}}
 if(this.holder!==null){const h=this.people[this.holder];this.possessions[h.side]+=dt;
 if(h.slot===0){this.keeperHold-=dt;if(this.keeperHold<=0){const receiver=this.choosePass(h);if(receiver)this.kick(h,{x:receiver.x+receiver.vx*.35,z:receiver.z+receiver.vz*.35},'pass',.6);else this.kick(h,{x:h.side===0?0:-0,z:0},'pass',.55);}}}
 else if(this.ballPos[1]<2.8&&Math.abs(this.ballPos[0])<=54&&Math.abs(this.ballPos[2])<=35)this.findLooseBall();
 this.movePlayers(dt);
 if(this.holder!==null){const p=this.people[this.holder];const lead=Math.min(1.3,1+.05*Math.hypot(p.vx,p.vz));this.placeBall(p.x+Math.cos(p.face)*lead,.25,p.z+Math.sin(p.face)*lead);this.ballVelocity=[p.vx,0,p.vz];}
 else{this.adjustBall();this.checkBoundary();}
 this.frameClock+=dt;if(this.frameClock>.13){this.frameClock=0;this.frames.push({ball:[...this.ballPos],people:this.people.map(p=>[p.x,p.z])});if(this.frames.length>35)this.frames.shift();}
 this.uiClock+=dt;if(this.uiClock>.12){this.uiClock=0;this.onView?.(this.view());}
 }
 findLooseBall(){const candidates=this.people.filter(p=>Math.hypot(p.x-this.ballPos[0],p.z-this.ballPos[2])<2.02).sort((a,b)=>distance(a,{x:this.ballPos[0],z:this.ballPos[2]})-distance(b,{x:this.ballPos[0],z:this.ballPos[2]}));
 const winner=candidates[0];if(!winner)return;
 const speed=Math.hypot(this.ballVelocity[0],this.ballVelocity[2]);if(speed>25&&Math.random()<(winner.slot===0?1-bounds((winner.card.keeper-25)/85,.25,.82):.6))return;
 // Keep goalkeepers from collecting outside their penalty box.
 if(winner.slot===0&&Math.abs(winner.x)<34)return;
 const guarding=candidates.find(p=>p.side!==winner.side);if(guarding&&guarding!==winner){const w=winner.card.dribbling+winner.card.physical*.4,g=guarding.card.defending+guarding.card.physical*.4;if(g>w+9&&Math.random()<.45)return;}
 this.holder=winner.side*11+winner.slot;this.lastTouch=winner.side;this.lastTouchSlot=winner.slot;
 if(winner.slot===0){this.keeperHold=1.1+Math.random()*.8;this.statSaves[winner.side]++;this.announce(winner.side===0?'GREAT SAVE':'OPPOSITION SAVE',1.3);}if(winner.side===0&&winner.slot!==0&&this.settings.autoSwitch)this.selected=winner.slot;}
 checkBoundary(){const [x,y,z]=this.ballPos;if(Math.abs(x)>FIELD_X+.6){if(Math.abs(z)<GOAL_Z&&y<2.65){this.goal(x>0?0:1);return;}
 const defending:Side=x>0?1:0;const attacking:Side=(1-defending) as Side;
 if(this.lastTouch===defending)this.restart('CORNER',attacking,x>0?50:-50,z<0?-32:32);else this.restart('GOAL KICK',defending,x>0?46:-46,z<0?-7:7);return;}
 if(Math.abs(z)>FIELD_Z+.6)this.restart('THROW-IN',(1-this.lastTouch) as Side,x,z>0?33:-33);
 }
 goal(side:Side){this.score[side]++;this.lastTouch=side;const scorer=this.people[this.lastTouchSlot+side*11];this.lastScorer=scorer?.card.name||'Own goal';if(scorer&&scorer.side===side)this.playerActions[side*11+scorer.slot].goals++;if(side===0)this.goalScorers.push(`${Math.floor(this.clock/60)}' ${this.lastScorer}`);
 this.replayFrames=this.frames.slice();this.replayProgress=0;this.goalTimer=4;this.phase='goal';this.charge=0;this.announce(`GOAL! ${this.score[0]} - ${this.score[1]}`,4);
 this.onWhistle?.('goal');this.ball?.setLinvel({x:0,y:0,z:0},true);}
 movePlayers(dt:number){const holder=this.holder!==null?this.people[this.holder]:null;const bx=holder?.x??this.ballPos[0],bz=holder?.z??this.ballPos[2];
 for(const p of this.people){p.cooldown=Math.max(0,p.cooldown-dt);p.skillUntil=Math.max(0,p.skillUntil-dt);p.aiTimer-=dt;
 let tx=p.x,tz=p.z;const hasBall=this.holder===p.side*11+p.slot;const isHuman=p.side===0&&p.slot===this.selected&&p.slot!==0;
 if(isHuman){const forward=bounds((this.held.has('KeyD')?1:0)-(this.held.has('KeyA')?1:0)+this.joystick.x,-1,1),vertical=bounds((this.held.has('KeyS')?1:0)-(this.held.has('KeyW')?1:0)+this.joystick.z,-1,1),mag=Math.max(1,Math.hypot(forward,vertical));
 tx=p.x+(forward/mag)*8;tz=p.z+(vertical/mag)*8;}
 else if(hasBall&&p.slot===0){tx=p.side===0?-47:47;tz=bounds(p.z,-4,4);}
 else if(hasBall){const dir=p.side===0?1:-1;const pressure=Math.min(...this.people.filter(o=>o.side!==p.side).map(o=>distance(o,p)));
 tx=bounds(p.x+dir*12,-49,49);tz=p.z+((bz>21?-1:bz<-21?1:0)*5);if(pressure<3)tz=p.z+(Math.sin(this.elapsed*2.4+p.slot)*8);
 if(p.aiTimer<=0){this.aiDecision(p);p.aiTimer=0.7+Math.random()*.6;}}
 else if(p.slot===0){const goal=p.side===0?-1:1;tx=goal*46+(bx-goal*46)*.08;tz=bounds(bz*.68,-6.1,6.1);if(Math.abs(bx-goal*46)>32){tx=goal*46;tz=0;}}
 else {
 const formation=formationCoords(FORMATIONS[this.formation]);const base=formation[p.slot];const dir=p.side===0?1:-1;
 const isAttacking=holder?.side===p.side;
 const shiftX=bounds(bx*.38,-15,15)+(isAttacking?dir*5:-dir*2)+(p.side===0?(this.tactic==='Attacking'?6:this.tactic==='Defensive'?-5:0):0);
 tx=bounds(base[0]*dir+shiftX,-49,49);
 tz=bounds(base[1]*dir+bz*.19,-30,30);
 if(holder?.side!==p.side){const d=Math.hypot(p.x-bx,p.z-bz),pursuers=this.people.filter(a=>a.side===p.side&&a.slot!==0).sort((a,b)=>distance(a,{x:bx,z:bz})-distance(b,{x:bx,z:bz}));
 if(pursuers.slice(0,2).includes(p)&&d<25){tx=bx+(p.side===0?-1:1)*.4;tz=bz;}
 }else if(isAttacking&&p.slot>=5&&p.slot!==holder?.slot){const spaceX=(p.x-bx)*dir;if(spaceX<12)tx+=dir*(3+(p.slot%3));}
 if(!holder&&Math.hypot(p.x-bx,p.z-bz)<18){tx=bx;tz=bz;}
 }
 const dx=tx-p.x,dz=tz-p.z,L=len(dx,dz);const sprint=isHuman&&(this.held.has('ShiftLeft')||this.held.has('TouchSprint'))&&p.stamina>4;
 const speed=(3.6+p.card.pace*.052)*(sprint?1.43:1)*(hasBall?.89:1)*(p.skillUntil>0?1.45:1)*(p.stamina<22?.76:1);
 const targetVX=L>.5?dx/L*speed:0,targetVZ=L>.5?dz/L*speed:0;const acceleration=(hasBall?12:15)*dt;
 p.vx+=(targetVX-p.vx)*Math.min(1,acceleration);p.vz+=(targetVZ-p.vz)*Math.min(1,acceleration);
 const nextX=bounds(p.x+p.vx*dt,-51.2,51.2),nextZ=bounds(p.z+p.vz*dt,-32.4,32.4);
 const realSpeed=Math.hypot(p.vx,p.vz);if(realSpeed>.15)p.face=Math.atan2(p.vz,p.vx);
 if(sprint){p.stamina=Math.max(0,p.stamina-(16-p.card.stamina*.045)*dt);}else p.stamina=Math.min(100,p.stamina+(realSpeed>4?.25:realSpeed>1?1.1:4)*dt);
 p.x=nextX;p.z=nextZ;p.anim+=realSpeed*dt*.92;
 if(!hasBall&&holder&&this.holder!==null&&this.people[this.holder].side!==p.side&&distance(p,holder)<2.12&&p.cooldown<=0){const quality=(p.card.defending*.65+p.card.physical*.35)-(holder!.card.dribbling*.7+holder!.card.physical*.3);const opportunity=Math.max(.015,(quality+35)/420)*dt*6*(p.side===1?1+this.aiLevel*.022:1);
 if(Math.random()<opportunity){if(Math.random()<.08&&p.side===1){this.foul(1,holder!.x,holder!.z);return;}this.holder=p.side*11+p.slot;this.lastTouch=p.side;this.lastTouchSlot=p.slot;this.playerActions[p.side*11+p.slot].tackles++;p.cooldown=1;}}
 }
 if(this.holder===null&&this.settings.autoSwitch){const closest=this.people.slice(0,11).filter(p=>p.slot!==0).sort((a,b)=>distance(a,{x:bx,z:bz})-distance(b,{x:bx,z:bz}))[0];if(closest&&distance(closest,{x:bx,z:bz})<7&&distance(this.people[this.selected],{x:bx,z:bz})>13)this.selected=closest.slot;}
 }
}
