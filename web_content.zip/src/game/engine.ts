import { GameAudio } from "./audio";
import { Input, type Actions } from "./input";
import { STEP } from "./math";
import { createCam, drawWorld, updateCam, type Cam } from "./render";
import { createMatch, stepMatch, type Match } from "./sim";
import type { Difficulty } from "./save";
import type { TeamDef } from "./teams";

export type EngineMode = "demo" | "live";

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  setKeys?: (codes: string[]) => void;
  getPos?: () => { x: number; y: number };
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
  }
}

export class GameEngine {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  input = new Input();
  audio = new GameAudio();
  match: Match;
  cam: Cam = createCam();
  mode: EngineMode = "demo";
  running = false;
  private raf = 0;
  private acc = 0;
  private last = 0;
  private dpr = 1;
  onHud: ((m: Match) => void) | null = null;
  onEnded: ((m: Match) => void) | null = null;
  onGoal: (() => void) | null = null;
  onPauseChange: ((paused: boolean) => void) | null = null;
  private lastScore: [number, number] = [0, 0];
  paused = false;
  shakeOn = true;

  constructor(canvas: HTMLCanvasElement, home: TeamDef, away: TeamDef) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unsupported");
    this.ctx = ctx;
    this.match = createMatch(home, away, { userTeam: -1, difficulty: "pro" });
  }

  startDemo(home: TeamDef, away: TeamDef) {
    this.mode = "demo";
    this.match = createMatch(home, away, { userTeam: -1, difficulty: "pro" });
    this.lastScore = [0, 0];
    this.paused = false;
  }

  startLive(
    home: TeamDef,
    away: TeamDef,
    opts: { userTeam: 0 | 1; difficulty: Difficulty; practice?: boolean; autoSwitch?: boolean },
  ) {
    this.mode = "live";
    this.match = createMatch(home, away, {
      userTeam: opts.userTeam,
      difficulty: opts.difficulty,
      practice: opts.practice,
      autoSwitch: opts.autoSwitch,
    });
    this.lastScore = [0, 0];
    this.paused = false;
    this.audio.whistle();
  }

  attach() {
    this.input.attach();
    this.resize();
    window.addEventListener("resize", this.resize);
    document.addEventListener("visibilitychange", this.onVis);
    this.running = true;
    this.last = performance.now();
    this.acc = 0;
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
    this.installProbe();
  }

  detach() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.input.detach();
    window.removeEventListener("resize", this.resize);
    document.removeEventListener("visibilitychange", this.onVis);
    if (window.__controlsTest) delete window.__controlsTest;
  }

  private resize = () => {
    const parent = this.canvas.parentElement ?? document.body;
    const w = parent.clientWidth || window.innerWidth;
    const h = parent.clientHeight || window.innerHeight;
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.max(1, Math.floor(w * this.dpr));
    this.canvas.height = Math.max(1, Math.floor(h * this.dpr));
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
  };

  private onVis = () => {
    if (document.visibilityState === "visible") this.audio.resume();
    else this.input.keys.clear();
  };

  private installProbe() {
    window.__controlsTest = {
      getYaw: () => {
        const p = this.match.players[this.match.controlled];
        return p?.facing ?? 0;
      },
      getSpeed: () => {
        const p = this.match.players[this.match.controlled];
        if (!p) return 0;
        return Math.hypot(p.vx, p.vy);
      },
      setKeys: (codes: string[]) => this.input.setKeys(codes),
      getPos: () => {
        const p = this.match.players[this.match.controlled];
        return { x: p?.x ?? 0, y: p?.y ?? 0 };
      },
    };
  }

  private loop = (now: number) => {
    if (!this.running) return;
    const raw = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    if (!this.paused) {
      this.acc += raw;
      const idle: Actions = {
        moveX: 0,
        moveY: 0,
        sprint: false,
        pass: false,
        through: false,
        shoot: false,
        shootHeld: false,
        tackle: false,
        switchP: false,
        pause: false,
      };
      while (this.acc >= STEP) {
        const actions = this.mode === "live" ? this.input.sample() : idle;
        if (actions.pause && this.mode === "live") {
          this.paused = true;
          this.onPauseChange?.(true);
          break;
        }
        const prevPhase = this.match.phase;
        stepMatch(this.match, actions, STEP);
        this.acc -= STEP;
        if (this.match.score[0] !== this.lastScore[0] || this.match.score[1] !== this.lastScore[1]) {
          this.lastScore = [this.match.score[0], this.match.score[1]];
          this.audio.goal();
          this.onGoal?.();
        }
        if (prevPhase !== "fulltime" && this.match.phase === "fulltime") {
          this.audio.longWhistle();
          this.onEnded?.(this.match);
        }
        if (this.match.phase === "halftime" && prevPhase !== "halftime") this.audio.whistle();
      }
    } else {
      this.acc = 0;
      const actions = this.input.sample();
      if (actions.pause) {
        this.paused = false;
        this.onPauseChange?.(false);
      }
    }

    const alpha = this.paused ? 1 : this.acc / STEP;
    const cssW = this.canvas.width / this.dpr;
    const cssH = this.canvas.height / this.dpr;
    updateCam(this.cam, this.match, raw, cssW, cssH, this.mode === "demo");
    if (!this.shakeOn) {
      this.cam.shakeX = 0;
      this.cam.shakeY = 0;
    }
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    drawWorld(this.ctx, this.match, this.cam, alpha, this.mode === "demo");
    this.audio.setExcitement(this.match.excitement);
    this.raf = requestAnimationFrame(this.loop);
  };
}
