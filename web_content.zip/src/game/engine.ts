import { soundEngine } from './sound';
import {
  drawCityTileBackground,
  drawClover,
  drawMapTransitionOverlay,
  drawPlayer,
  drawRainbowNpc,
  drawTileBackground,
  drawTrackWarningOverlay,
  drawTrain,
} from './sprites';
import {
  CLOVER_HOLD_SECONDS,
  Clover,
  DeathReason,
  Direction,
  FloatingText,
  GameStatus,
  HudSnapshot,
  MAP_SWITCH_INTERVAL,
  MapTheme,
  Particle,
  PlayerState,
  RainbowNpc,
  SAFE_COLS,
  TILE_PX,
  TOTAL_COLS,
  TRACK_COLS,
  Train,
  TrainStyle,
} from './types';

const HIGH_SCORE_KEY = 'bentonamu_highscore';
const MAX_PARTICLES = 120;

export class RailwayGameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private onHudChange: (snapshot: HudSnapshot) => void;

  private rafId: number | null = null;
  private lastTimestamp = 0;
  private totalTime = 0;

  // Logical pixel viewport
  private pxScale = 3;
  private viewW = 320;
  private viewH = 240;

  // Game state
  private status: GameStatus = 'TITLE';
  private score = 0;
  private survivalScoreCarry = 0;
  private bestScore = 0;
  private isNewRecord = false;
  private cloversCollected = 0;
  private streak = 0;
  private timeSinceLastClover = 0;
  private elapsedSeconds = 0;
  private deathReason: DeathReason = null;

  // Map transformation state (switches every 15 seconds)
  private mapTheme: MapTheme = 'RAILWAY';
  private mapSwitchTimer = 0;
  private mapTransitionActive = false;
  private mapTransitionTimer = 0;
  private mapTransitionDuration = 0.65;
  private mapTransitionTarget: MapTheme = 'TWELVE_CITY';
  private mapSwappedMidTransition = false;

  // Camera (world row centered around player)
  private cameraRow = 1.2;

  // Entities
  private player: PlayerState;
  private bufferedDir: Direction | null = null;
  private clovers: Clover[] = [];
  private trains: Train[] = [];
  private npcs: RainbowNpc[] = [];
  private particles: Particle[] = [];
  private floatingTexts: FloatingText[] = [];

  private nextId = 1;
  private trainSpawnCooldown = 1.2;
  private hitstopTimer = 0;
  private shakeTimer = 0;
  private shakeMagnitude = 0;

  private lastTrackLeft: { col: number; row: number; at: number } | null = null;
  private lastHudEmit = 0;

  constructor(canvas: HTMLCanvasElement, onHudChange: (snapshot: HudSnapshot) => void) {
    this.canvas = canvas;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) {
      throw new Error('Could not initialize 2D canvas context');
    }
    this.ctx = context;
    this.onHudChange = onHudChange;

    this.bestScore = this.loadHighScore();
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        life: 0,
        maxLife: 1,
        size: 2,
        color: '#ffffff',
        gravity: 0,
      });
    }

    this.player = this.createInitialPlayer();
    this.seedTitleWorld();
    this.resize();
    this.emitHud(true);
  }

  private loadHighScore(): number {
    try {
      const raw = localStorage.getItem(HIGH_SCORE_KEY);
      const parsed = raw ? parseInt(raw, 10) : 0;
      return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
    } catch {
      return 0;
    }
  }

  private saveHighScore(val: number): void {
    try {
      localStorage.setItem(HIGH_SCORE_KEY, String(val));
    } catch {
      // ignore storage errors
    }
  }

  private createInitialPlayer(): PlayerState {
    return {
      col: 3,
      row: 0,
      fromCol: 3,
      fromRow: 0,
      visualCol: 3,
      visualRow: 0,
      isMoving: false,
      moveTimer: 0,
      moveDuration: 0.105,
      facing: 'UP',
      squashX: 1,
      squashY: 1,
      hopZ: 0,
      collectPose: false,
      knockedOut: false,
      knockoutTimer: 0,
      knockoutVx: 0,
      knockoutVy: 0,
      hatOffsetY: 0,
    };
  }

  private seedTitleWorld(): void {
    this.clovers = [];
    this.trains = [];
    this.npcs = [];
    this.floatingTexts = [];
    this.mapTheme = 'RAILWAY';
    this.mapSwitchTimer = 0;
    this.mapTransitionActive = false;
    this.deathReason = null;
    this.cameraRow = 1.4;
    this.player = this.createInitialPlayer();
    // Place decorative MARAU items along the grass lanes for the live title backdrop
    this.clovers.push(
      this.makeClover(0, 2, 'normal'),
      this.makeClover(3, 3, 'golden'),
      this.makeClover(6, 1, 'normal'),
      this.makeClover(3, 0, 'normal')
    );
    this.npcs.push(
      this.makeRainbowNpc(0, 3.5, -1, 2.2, 0),
      this.makeRainbowNpc(6, -0.5, 1, 2.4, 0)
    );
  }

  public startLoop(): void {
    if (this.rafId !== null) return;
    this.lastTimestamp = performance.now();
    const tick = (now: number) => {
      const rawDt = (now - this.lastTimestamp) / 1000;
      this.lastTimestamp = now;
      const dt = Math.min(Math.max(rawDt, 0), 0.05);

      this.update(dt);
      this.render();

      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  public destroy(): void {
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public resize(): void {
    const rect = this.canvas.parentElement?.getBoundingClientRect();
    const w = Math.max(320, Math.floor(rect?.width ?? window.innerWidth));
    const h = Math.max(320, Math.floor(rect?.height ?? window.innerHeight));

    // Pick crisp integer pixel scale so 7 columns (168px) always fit with room to spare
    let scale = 3;
    if (w < 540 || h < 540) {
      scale = 2;
    } else if (w >= 1600 && h >= 1000) {
      scale = 4;
    }
    this.pxScale = scale;
    this.viewW = Math.ceil(w / scale);
    this.viewH = Math.ceil(h / scale);

    this.canvas.width = this.viewW;
    this.canvas.height = this.viewH;
    this.ctx.imageSmoothingEnabled = false;
  }

  public startGame(): void {
    soundEngine.playStart();
    this.status = 'PLAYING';
    this.score = 0;
    this.survivalScoreCarry = 0;
    this.isNewRecord = false;
    this.cloversCollected = 0;
    this.streak = 0;
    this.timeSinceLastClover = 0;
    this.elapsedSeconds = 0;
    this.deathReason = null;
    this.mapTheme = 'RAILWAY';
    this.mapSwitchTimer = 0;
    this.mapTransitionActive = false;
    this.mapTransitionTimer = 0;
    this.mapSwappedMidTransition = false;

    this.player = this.createInitialPlayer();
    this.bufferedDir = null;
    this.cameraRow = 1.4;
    this.clovers = [];
    this.trains = [];
    this.npcs = [];
    this.floatingTexts = [];
    this.lastTrackLeft = null;
    this.hitstopTimer = 0;
    this.shakeTimer = 0;
    this.trainSpawnCooldown = 1.0;

    for (const p of this.particles) p.active = false;

    this.ensureClovers();
    this.seedInitialNpcs();
    this.emitHud(true);
  }

  public togglePause(): void {
    if (this.status === 'PLAYING') {
      this.status = 'PAUSED';
      this.emitHud(true);
    } else if (this.status === 'PAUSED') {
      this.status = 'PLAYING';
      this.lastTimestamp = performance.now();
      this.emitHud(true);
    }
  }

  public returnToTitle(): void {
    this.status = 'TITLE';
    this.seedTitleWorld();
    this.emitHud(true);
  }

  public getStatus(): GameStatus {
    return this.status;
  }

  public move(dir: Direction): void {
    if (this.status !== 'PLAYING' || this.player.knockedOut) return;
    soundEngine.unlock();

    if (this.player.isMoving) {
      // Buffer next hop if past 35% of current hop
      if (this.player.moveTimer / this.player.moveDuration >= 0.35) {
        this.bufferedDir = dir;
      }
      return;
    }

    this.executeMove(dir);
  }

  public handleTapAtClientPos(clientX: number, clientY: number): void {
    if (this.status !== 'PLAYING' || this.player.knockedOut) return;
    const rect = this.canvas.getBoundingClientRect();
    const lx = ((clientX - rect.left) / rect.width) * this.viewW;
    const ly = ((clientY - rect.top) / rect.height) * this.viewH;

    const { x: px, y: py } = this.worldToScreen(this.player.visualCol, this.player.visualRow);
    const centerX = px + TILE_PX / 2;
    const centerY = py + TILE_PX / 2;
    const dx = lx - centerX;
    const dy = ly - centerY;

    if (Math.hypot(dx, dy) < 8) return;
    if (Math.abs(dx) > Math.abs(dy)) {
      this.move(dx < 0 ? 'LEFT' : 'RIGHT');
    } else {
      this.move(dy < 0 ? 'UP' : 'DOWN');
    }
  }

  private executeMove(dir: Direction): void {
    let targetCol = this.player.col;
    let targetRow = this.player.row;

    if (dir === 'LEFT') targetCol -= 1;
    if (dir === 'RIGHT') targetCol += 1;
    if (dir === 'UP') targetRow += 1;
    if (dir === 'DOWN') targetRow -= 1;

    this.player.facing = dir;

    if (targetCol < 0 || targetCol >= TOTAL_COLS) {
      // Subtle bump squash at corridor boundary
      this.player.squashX = 0.85;
      this.player.squashY = 1.15;
      return;
    }

    // Check if leaving a track tile for Close Call detection
    const wasTrack = (TRACK_COLS as readonly number[]).includes(this.player.col);
    if (wasTrack) {
      this.lastTrackLeft = {
        col: this.player.col,
        row: this.player.row,
        at: this.totalTime,
      };
    }

    // Reset clover progress if moving off a partially collected clover
    for (const clover of this.clovers) {
      if (clover.col === this.player.col && clover.row === this.player.row && clover.collectProgress > 0) {
        clover.collectProgress = 0;
        clover.lastTickStep = 0;
      }
    }

    this.player.fromCol = this.player.col;
    this.player.fromRow = this.player.row;
    this.player.col = targetCol;
    this.player.row = targetRow;
    this.player.isMoving = true;
    this.player.moveTimer = 0;
    this.player.collectPose = false;
    this.player.squashX = 0.84;
    this.player.squashY = 1.18;

    soundEngine.playHop();
    this.spawnDustBurst(this.player.fromCol, this.player.fromRow, '#a3c992', 4);
  }

  private update(dt: number): void {
    if (this.status === 'PAUSED') return;

    this.totalTime += dt;

    if (this.shakeTimer > 0) {
      this.shakeTimer = Math.max(0, this.shakeTimer - dt);
    }

    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    if (this.status === 'TITLE') {
      this.updateTitleAmbient(dt);
      return;
    }

    // Handle post-crash dramatic delay before showing Game Over modal
    if (this.player.knockedOut) {
      this.player.knockoutTimer += dt;
      this.player.visualCol += this.player.knockoutVx * dt;
      this.player.visualRow += this.player.knockoutVy * dt;
      this.player.hatOffsetY = -Math.sin(Math.min(1, this.player.knockoutTimer * 2.5) * Math.PI) * 7;

      this.updateTrains(dt, false);
      this.updateParticles(dt);
      this.updateFloatingTexts(dt);

      if (this.status === 'PLAYING' && this.player.knockoutTimer >= 0.62) {
        this.status = 'GAME_OVER';
        this.emitHud(true);
      }
      return;
    }

    if (this.status !== 'PLAYING') return;

    // Survival progression
    this.elapsedSeconds += dt;
    this.timeSinceLastClover += dt;
    if (this.streak > 0 && this.timeSinceLastClover > 12) {
      this.streak = 0;
    }

    // Automatic 15-second map switching (Map 1 Railway <-> Map 2 Twelve City)
    this.mapSwitchTimer += dt;
    if (this.mapSwitchTimer >= MAP_SWITCH_INTERVAL && !this.mapTransitionActive) {
      this.mapSwitchTimer -= MAP_SWITCH_INTERVAL;
      this.startMapTransition(this.mapTheme === 'RAILWAY' ? 'TWELVE_CITY' : 'RAILWAY');
    }
    this.updateMapTransition(dt);

    this.survivalScoreCarry += dt * 10;
    if (this.survivalScoreCarry >= 1) {
      const gained = Math.floor(this.survivalScoreCarry);
      this.survivalScoreCarry -= gained;
      this.addScore(gained);
    }

    // Player hop movement
    this.updatePlayerMovement(dt);

    // Smoothly track camera to keep player centered comfortably above the bottom D-pad
    const targetCamRow = this.player.visualRow + 0.9;
    this.cameraRow += (targetCamRow - this.cameraRow) * Math.min(1, dt * 8.5);

    // Clovers update & 3-second collection check
    this.updateClovers(dt);
    this.ensureClovers();

    // Trains spawn & movement
    this.updateTrainSpawner(dt);
    this.updateTrains(dt, true);

    // Rainbow Hair NPCs running up & down non-track lanes
    this.updateRainbowNpcs(dt, true);

    // Particles & floating texts
    this.updateParticles(dt);
    this.updateFloatingTexts(dt);

    // Periodic HUD sync (every 100ms or on score/clover events)
    if (this.totalTime - this.lastHudEmit >= 0.1) {
      this.emitHud(false);
    }
  }

  private updateTitleAmbient(dt: number): void {
    // Ambient background trains on title screen
    this.trainSpawnCooldown -= dt;
    if (this.trainSpawnCooldown <= 0) {
      this.trainSpawnCooldown = 1.5 + Math.random() * 1.4;
      const freeCols = TRACK_COLS.filter(
        (c) => !this.trains.some((t) => t.col === c)
      );
      if (freeCols.length > 0) {
        const col = freeCols[Math.floor(Math.random() * freeCols.length)];
        const styles: TrainStyle[] = ['yamanote', 'chuo', 'shinkansen'];
        const style = styles[Math.floor(Math.random() * styles.length)];
        const dir: 1 | -1 = col >= 4 ? 1 : -1;
        this.trains.push(this.createTrain(col, dir, style, 1.4, 8.5));
      }
    }

    for (const c of this.clovers) {
      c.age += dt;
    }
    this.updateTrains(dt, false);
    this.updateRainbowNpcs(dt, false);
    this.updateParticles(dt);
  }

  private updatePlayerMovement(dt: number): void {
    // Recover squash & stretch smoothly
    this.player.squashX += (1 - this.player.squashX) * Math.min(1, dt * 18);
    this.player.squashY += (1 - this.player.squashY) * Math.min(1, dt * 18);

    if (!this.player.isMoving) {
      this.player.visualCol = this.player.col;
      this.player.visualRow = this.player.row;
      this.player.hopZ = 0;
      this.player.hatOffsetY = 0;
      return;
    }

    this.player.moveTimer += dt;
    const t = Math.min(1, this.player.moveTimer / this.player.moveDuration);
    const eased = 1 - Math.pow(1 - t, 2);

    this.player.visualCol = this.player.fromCol + (this.player.col - this.player.fromCol) * eased;
    this.player.visualRow = this.player.fromRow + (this.player.row - this.player.fromRow) * eased;
    this.player.hopZ = Math.sin(t * Math.PI) * 5.5;
    this.player.hatOffsetY = -Math.sin(t * Math.PI) * 1.5;

    if (t >= 1) {
      this.player.isMoving = false;
      this.player.visualCol = this.player.col;
      this.player.visualRow = this.player.row;
      this.player.hopZ = 0;
      this.player.hatOffsetY = 0;
      this.player.squashX = 1.18;
      this.player.squashY = 0.84;

      if (this.bufferedDir) {
        const next = this.bufferedDir;
        this.bufferedDir = null;
        this.executeMove(next);
      }
    }
  }

  private makeClover(col: number, row: number, kind: 'normal' | 'golden'): Clover {
    return {
      id: this.nextId++,
      col,
      row,
      kind,
      age: 0,
      maxAge: 16 + Math.random() * 4,
      collectProgress: 0,
      lastTickStep: 0,
      swayOffset: Math.random() * Math.PI * 2,
    };
  }

  private ensureClovers(): void {
    const minRow = Math.round(this.cameraRow) - 3;
    const maxRow = Math.round(this.cameraRow) + 5;

    // Remove clovers too far behind/ahead camera
    this.clovers = this.clovers.filter(
      (c) => c.row >= minRow - 2 && c.row <= maxRow + 3
    );

    const targetCount = 4;
    let attempts = 0;
    while (this.clovers.length < targetCount && attempts < 24) {
      attempts++;
      const col = SAFE_COLS[Math.floor(Math.random() * SAFE_COLS.length)];
      const row = Math.round(this.player.row) + Math.floor(Math.random() * 7) - 2;
      const occupied =
        this.clovers.some((c) => c.col === col && c.row === row) ||
        (col === this.player.col && row === this.player.row);
      if (!occupied) {
        const isGolden = col === 3 && Math.random() < 0.25;
        this.clovers.push(this.makeClover(col, row, isGolden ? 'golden' : 'normal'));
      }
    }
  }

  private updateClovers(dt: number): void {
    let standingOnAny = false;
    const remaining: Clover[] = [];

    for (const clover of this.clovers) {
      const isStanding =
        !this.player.isMoving &&
        this.player.col === clover.col &&
        this.player.row === clover.row;

      if (isStanding) {
        standingOnAny = true;
        clover.collectProgress += dt;

        // Tick audio + sparkle every 0.5 seconds
        const step = Math.floor(clover.collectProgress / 0.5);
        if (step > clover.lastTickStep && step <= 5) {
          clover.lastTickStep = step;
          soundEngine.playCloverTick(step);
          this.spawnDustBurst(
            clover.col,
            clover.row,
            clover.kind === 'golden' ? '#fde047' : '#86efac',
            5
          );
        }

        if (clover.collectProgress >= CLOVER_HOLD_SECONDS) {
          // Collected!
          this.onCloverCollected(clover);
          continue; // remove collected clover
        }
      } else {
        clover.age += dt;
        if (clover.age >= clover.maxAge) {
          // Wilt away
          this.spawnDustBurst(clover.col, clover.row, '#65a30d', 4);
          continue;
        }
      }

      remaining.push(clover);
    }

    this.clovers = remaining;
    this.player.collectPose = standingOnAny;
  }

  private onCloverCollected(clover: Clover): void {
    const isGolden = clover.kind === 'golden';
    this.cloversCollected += 1;
    this.streak += 1;
    this.timeSinceLastClover = 0;

    const base = isGolden ? 250 : 100;
    const streakBonus = (this.streak - 1) * 25;
    const total = base + streakBonus;

    this.addScore(total);
    soundEngine.playCloverCollected(isGolden);

    const burstColor = isGolden ? '#facc15' : '#4ade80';
    this.spawnCelebrationBurst(clover.col, clover.row, burstColor);
    const label = streakBonus > 0 ? `+${total} x${this.streak}` : `+${total}`;
    this.addFloatingText(clover.col, clover.row + 0.35, label, isGolden ? '#fef08a' : '#86efac');

    this.player.squashX = 1.24;
    this.player.squashY = 0.78;
    this.emitHud(true);
  }

  private getDifficultyFactor(): number {
    // 0.0 at start -> 1.0 around 90s, continues scaling gently beyond
    const timeFactor = this.elapsedSeconds / 85;
    const cloverFactor = this.cloversCollected / 28;
    return Math.min(1.6, timeFactor * 0.75 + cloverFactor * 0.25);
  }

  private updateTrainSpawner(dt: number): void {
    this.trainSpawnCooldown -= dt;
    if (this.trainSpawnCooldown > 0) return;

    const diff = this.getDifficultyFactor();
    const maxConcurrent = diff < 0.2 ? 2 : diff < 0.65 ? 3 : 4;

    if (this.trains.length >= maxConcurrent) {
      this.trainSpawnCooldown = 0.3;
      return;
    }

    // Pick a free track column
    const freeCols = TRACK_COLS.filter(
      (c) => !this.trains.some((t) => t.col === c)
    );

    if (freeCols.length === 0) {
      this.trainSpawnCooldown = 0.35;
      return;
    }

    // Slight preference to occasionally target the track the player is standing on if they linger, keeping tension lively!
    let chosenCol = freeCols[Math.floor(Math.random() * freeCols.length)];
    if (
      (TRACK_COLS as readonly number[]).includes(this.player.col) &&
      freeCols.includes(this.player.col as 1 | 2 | 4 | 5) &&
      Math.random() < 0.35
    ) {
      chosenCol = this.player.col as 1 | 2 | 4 | 5;
    }

    // Choose vehicle style & speed scaled by difficulty and current map theme
    const roll = Math.random();
    let style: TrainStyle = this.mapTheme === 'TWELVE_CITY' ? 'city_tram' : 'yamanote';
    let baseSpeed = 7.2 + diff * 5.2;
    let lengthRows = 5 + Math.floor(Math.random() * 3);

    if (diff > 0.25 && roll > 0.52) {
      style = this.mapTheme === 'TWELVE_CITY' ? 'twelve_bus' : 'chuo';
      baseSpeed = 9.0 + diff * 6.0;
      lengthRows = 6 + Math.floor(Math.random() * 2);
    }
    if (diff > 0.5 && roll > 0.78) {
      style = this.mapTheme === 'TWELVE_CITY' ? 'metro_12' : 'shinkansen';
      baseSpeed = 12.0 + diff * 7.2;
      lengthRows = 7 + Math.floor(Math.random() * 3);
    }
    if (diff > 0.85 && roll > 0.92) {
      style = this.mapTheme === 'TWELVE_CITY' ? 'twelve_bus' : 'dryellow';
      baseSpeed = 14.0 + diff * 7.5;
      lengthRows = 7;
    }

    // Direction: early game trains mostly come from ahead (-1), later tracks 4 & 5 also bring northbound (+1) trains
    let direction: 1 | -1 = -1;
    if (diff > 0.28 && (chosenCol === 4 || chosenCol === 5)) {
      direction = Math.random() < 0.65 ? 1 : -1;
    } else if (diff > 0.7) {
      direction = Math.random() < 0.35 ? 1 : -1;
    }

    const warningDuration = Math.max(1.05, 1.85 - diff * 0.55);
    this.trains.push(this.createTrain(chosenCol, direction, style, warningDuration, baseSpeed, lengthRows));

    if (this.status === 'PLAYING') {
      soundEngine.playCrossingWarning();
    }

    const baseInterval = Math.max(0.42, 1.45 - diff * 0.72);
    this.trainSpawnCooldown = baseInterval * (0.75 + Math.random() * 0.5);
  }

  private createTrain(
    col: number,
    direction: 1 | -1,
    style: TrainStyle,
    warningDuration: number,
    speedRowsPerSec: number,
    lengthRows = 6
  ): Train {
    const visibleHalfRows = this.viewH / TILE_PX / 2 + 1.5;
    // Start just outside top or bottom of camera viewport
    const startRow =
      direction === -1
        ? this.cameraRow + visibleHalfRows + 0.5
        : this.cameraRow - visibleHalfRows - 0.5;

    return {
      id: this.nextId++,
      col,
      direction,
      rowPos: startRow,
      lengthRows,
      speedRowsPerSec,
      style,
      phase: 'WARNING',
      warningTimer: warningDuration,
      warningDuration,
      passedPlayerRow: false,
      whooshed: false,
    };
  }

  private updateTrains(dt: number, checkCollision: boolean): void {
    const visibleHalfRows = this.viewH / TILE_PX / 2 + 2;
    const activeTrains: Train[] = [];

    for (const train of this.trains) {
      if (train.phase === 'WARNING') {
        train.warningTimer -= dt;
        // Anchor entry just off-screen relative to current camera so moving forward/backward doesn't pop train early
        train.rowPos =
          train.direction === -1
            ? this.cameraRow + visibleHalfRows - 0.5
            : this.cameraRow - visibleHalfRows + 0.5;

        if (train.warningTimer <= 0) {
          train.phase = 'ACTIVE';
        }
        activeTrains.push(train);
        continue;
      }

      // Move active train
      train.rowPos += train.direction * train.speedRowsPerSec * dt;

      const tailRow = train.rowPos - train.direction * train.lengthRows;
      const minRow = Math.min(train.rowPos, tailRow);
      const maxRow = Math.max(train.rowPos, tailRow);

      // Whoosh sound when passing near player row
      if (!train.whooshed && checkCollision) {
        const distToPlayerRow = Math.abs(train.rowPos - this.player.visualRow);
        if (distToPlayerRow < 2.2) {
          train.whooshed = true;
          if (Math.abs(train.col - this.player.col) <= 2) {
            soundEngine.playTrainWhoosh();
          }
        }
      }

      // Close-call detection
      if (
        checkCollision &&
        !train.passedPlayerRow &&
        this.lastTrackLeft &&
        this.lastTrackLeft.col === train.col &&
        this.totalTime - this.lastTrackLeft.at <= 0.42 &&
        this.lastTrackLeft.row >= minRow - 0.3 &&
        this.lastTrackLeft.row <= maxRow + 0.3
      ) {
        train.passedPlayerRow = true;
        this.addScore(25);
        soundEngine.playCloseCall();
        this.addFloatingText(this.player.col, this.player.row + 0.4, 'CLOSE! +25', '#fde047');
        this.lastTrackLeft = null;
      }

      // Collision check with forgiving inner bounds
      if (checkCollision && !this.player.knockedOut) {
        const sameCol = Math.abs(this.player.visualCol - train.col) < 0.42;
        const inRowSpan =
          this.player.visualRow >= minRow - 0.32 &&
          this.player.visualRow <= maxRow + 0.32;

        if (sameCol && inRowSpan) {
          this.triggerCrash(train);
        }
      }

      // Keep train until tail clears viewport
      const keep =
        train.direction === -1
          ? maxRow >= this.cameraRow - visibleHalfRows - 2
          : minRow <= this.cameraRow + visibleHalfRows + 2;

      if (keep) {
        activeTrains.push(train);
      }
    }

    this.trains = activeTrains;
  }

  private triggerCrash(train: Train): void {
    this.deathReason = 'TRAIN';
    this.player.knockedOut = true;
    this.player.knockoutTimer = 0;
    this.player.collectPose = false;
    this.player.knockoutVx = (this.player.col <= 3 ? -1 : 1) * 1.4;
    this.player.knockoutVy = train.direction * 2.2;

    this.hitstopTimer = 0.065;
    this.shakeTimer = 0.4;
    this.shakeMagnitude = 5;

    soundEngine.playCrash();
    this.spawnCelebrationBurst(this.player.visualCol, this.player.visualRow, '#ef4444');
    this.spawnCelebrationBurst(this.player.visualCol, this.player.visualRow, '#facc15');
    this.emitHud(true);
  }

  private triggerLehauGameOver(npc: RainbowNpc): void {
    this.deathReason = 'LEHAU';
    this.status = 'GAME_OVER';
    this.shakeTimer = 0.35;
    this.shakeMagnitude = 4;

    soundEngine.playLehauCatch();
    const rainbow = ['#ef4444', '#f97316', '#facc15', '#22c55e', '#06b6d4', '#3b82f6', '#a855f7'];
    for (const c of rainbow) {
      this.spawnDustBurst(npc.col, npc.rowPos, c, 3);
    }
    this.emitHud(true);
  }

  private startMapTransition(target: MapTheme): void {
    this.mapTransitionActive = true;
    this.mapTransitionTimer = 0;
    this.mapTransitionTarget = target;
    this.mapSwappedMidTransition = false;
    soundEngine.playMapTransform();
  }

  private updateMapTransition(dt: number): void {
    if (!this.mapTransitionActive) return;
    this.mapTransitionTimer += dt;
    const progress = this.mapTransitionTimer / this.mapTransitionDuration;

    if (progress >= 0.5 && !this.mapSwappedMidTransition) {
      this.mapSwappedMidTransition = true;
      this.mapTheme = this.mapTransitionTarget;
      // Restyle active vehicles cleanly to match new map environment
      for (const train of this.trains) {
        if (this.mapTheme === 'TWELVE_CITY') {
          if (train.style === 'yamanote') train.style = 'city_tram';
          else if (train.style === 'chuo') train.style = 'twelve_bus';
          else train.style = 'metro_12';
        } else {
          if (train.style === 'city_tram') train.style = 'yamanote';
          else if (train.style === 'twelve_bus') train.style = 'chuo';
          else train.style = 'shinkansen';
        }
      }
      this.emitHud(true);
    }

    if (progress >= 1) {
      this.mapTransitionActive = false;
      this.mapTransitionTimer = 0;
    }
  }

  private makeRainbowNpc(
    col: 0 | 3 | 6,
    rowPos: number,
    direction: 1 | -1,
    speedRowsPerSec: number,
    anchorRow: number
  ): RainbowNpc {
    return {
      id: this.nextId++,
      col,
      rowPos,
      direction,
      speedRowsPerSec,
      minRowOffset: -4.5,
      maxRowOffset: 5.5,
      anchorRow,
      animPhase: Math.random() * 10,
      turnPauseTimer: 0,
    };
  }

  private seedInitialNpcs(): void {
    // One rainbow-haired NPC patrolling each non-track lane (cols 0, 3, 6), spawned safely away from (3, 0)
    this.npcs = [
      this.makeRainbowNpc(0, 4.5, -1, 2.3, 0),
      this.makeRainbowNpc(3, 5.2, -1, 2.1, 0),
      this.makeRainbowNpc(6, -3.5, 1, 2.5, 0),
    ];
  }

  private updateRainbowNpcs(dt: number, checkCollision: boolean): void {
    const diff = this.getDifficultyFactor();
    const visibleHalfRows = this.viewH / TILE_PX / 2 + 1.5;

    for (const npc of this.npcs) {
      npc.animPhase += dt * (npc.speedRowsPerSec * 0.45);

      if (npc.turnPauseTimer > 0) {
        npc.turnPauseTimer -= dt;
        continue;
      }

      const speedBoost = checkCollision ? 1 + diff * 0.35 : 1;
      npc.rowPos += npc.direction * npc.speedRowsPerSec * speedBoost * dt;

      const minRow = npc.anchorRow + npc.minRowOffset;
      const maxRow = npc.anchorRow + npc.maxRowOffset;

      if (npc.direction === 1 && npc.rowPos >= maxRow) {
        npc.rowPos = maxRow;
        npc.direction = -1;
        npc.turnPauseTimer = 0.18;
      } else if (npc.direction === -1 && npc.rowPos <= minRow) {
        npc.rowPos = minRow;
        npc.direction = 1;
        npc.turnPauseTimer = 0.18;
      }

      // Re-anchor patrolling zone smoothly when player travels far forward or backward
      if (checkCollision && Math.abs(this.player.row - npc.anchorRow) > 7.5) {
        const spawnTop = this.player.row > npc.anchorRow;
        npc.anchorRow = Math.round(this.player.row);
        npc.rowPos = spawnTop
          ? this.cameraRow + visibleHalfRows + 1.2
          : this.cameraRow - visibleHalfRows - 1.2;
        npc.direction = spawnTop ? -1 : 1;
      }

      // Immediate Game Over if colliding with a Rainbow Hair NPC
      if (checkCollision && !this.player.knockedOut && this.status === 'PLAYING') {
        const sameCol = Math.abs(this.player.visualCol - npc.col) < 0.42;
        const sameRow = Math.abs(this.player.visualRow - npc.rowPos) < 0.44;
        if (sameCol && sameRow) {
          this.triggerLehauGameOver(npc);
          return;
        }
      }
    }

    // Keep unused SAFE_COLS import referenced cleanly
    void SAFE_COLS;
  }

  private addScore(points: number): void {
    this.score += points;
    if (this.score > this.bestScore) {
      this.bestScore = this.score;
      this.isNewRecord = true;
      this.saveHighScore(this.bestScore);
    }
  }

  private spawnDustBurst(col: number, row: number, color: string, count: number): void {
    const { x, y } = this.worldToScreen(col, row);
    const cx = x + TILE_PX / 2;
    const cy = y + TILE_PX / 2 + 4;
    for (let i = 0; i < count; i++) {
      this.spawnParticle(
        cx + (Math.random() - 0.5) * 8,
        cy + (Math.random() - 0.5) * 4,
        (Math.random() - 0.5) * 26,
        -10 - Math.random() * 20,
        0.25 + Math.random() * 0.2,
        1 + Math.floor(Math.random() * 2),
        color,
        55
      );
    }
  }

  private spawnCelebrationBurst(col: number, row: number, primaryColor: string): void {
    const { x, y } = this.worldToScreen(col, row);
    const cx = x + TILE_PX / 2;
    const cy = y + TILE_PX / 2;
    const palette = [primaryColor, '#fef08a', '#ffffff', '#22c55e'];
    for (let i = 0; i < 18; i++) {
      const angle = (Math.PI * 2 * i) / 18 + Math.random() * 0.25;
      const speed = 24 + Math.random() * 44;
      this.spawnParticle(
        cx,
        cy,
        Math.cos(angle) * speed,
        Math.sin(angle) * speed - 12,
        0.4 + Math.random() * 0.3,
        Math.random() > 0.5 ? 2 : 3,
        palette[i % palette.length],
        70
      );
    }
  }

  private spawnParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    maxLife: number,
    size: number,
    color: string,
    gravity: number
  ): void {
    for (const p of this.particles) {
      if (!p.active) {
        p.active = true;
        p.x = x;
        p.y = y;
        p.vx = vx;
        p.vy = vy;
        p.life = 0;
        p.maxLife = maxLife;
        p.size = size;
        p.color = color;
        p.gravity = gravity;
        return;
      }
    }
  }

  private updateParticles(dt: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        continue;
      }
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  private addFloatingText(col: number, row: number, text: string, color: string): void {
    this.floatingTexts.push({
      id: this.nextId++,
      worldCol: col,
      worldRow: row,
      text,
      color,
      life: 0,
      maxLife: 0.95,
    });
  }

  private updateFloatingTexts(dt: number): void {
    this.floatingTexts = this.floatingTexts.filter((ft) => {
      ft.life += dt;
      ft.worldRow += dt * 0.85;
      return ft.life < ft.maxLife;
    });
  }

  private worldToScreen(col: number, row: number): { x: number; y: number } {
    const corridorWidth = TOTAL_COLS * TILE_PX;
    const originX = Math.floor((this.viewW - corridorWidth) / 2);
    const originY = Math.floor(this.viewH * 0.48);

    const x = originX + col * TILE_PX;
    // Higher row = higher up on screen (-Y)
    const y = originY - (row - this.cameraRow) * TILE_PX - TILE_PX / 2;
    return { x, y };
  }

  private render(): void {
    const ctx = this.ctx;
    ctx.save();

    // Camera shake on impact
    if (this.shakeTimer > 0) {
      const decay = this.shakeTimer / 0.4;
      const sx = Math.round((Math.random() - 0.5) * 2 * this.shakeMagnitude * decay);
      const sy = Math.round((Math.random() - 0.5) * 2 * this.shakeMagnitude * decay);
      ctx.translate(sx, sy);
    }

    const corridorWidth = TOTAL_COLS * TILE_PX;
    const originX = Math.floor((this.viewW - corridorWidth) / 2);

    const minCol = Math.floor(-originX / TILE_PX) - 1;
    const maxCol = Math.ceil((this.viewW - originX) / TILE_PX) + 1;

    const halfRows = Math.ceil(this.viewH / TILE_PX / 2) + 2;
    const minRow = Math.floor(this.cameraRow) - halfRows;
    const maxRow = Math.ceil(this.cameraRow) + halfRows;

    // 1. Render endless tiles (Map 1 Japanese Railway vs Map 2 Twelve City)
    for (let r = minRow; r <= maxRow; r++) {
      for (let c = minCol; c <= maxCol; c++) {
        const { x, y } = this.worldToScreen(c, r);
        if (this.mapTheme === 'TWELVE_CITY') {
          drawCityTileBackground(ctx, c, r, Math.round(x), Math.round(y), this.totalTime);
        } else {
          drawTileBackground(ctx, c, r, Math.round(x), Math.round(y));
        }
      }
    }

    // 2. Render track warning telegraphs
    for (const train of this.trains) {
      if (train.phase === 'WARNING') {
        const { x } = this.worldToScreen(train.col, 0);
        drawTrackWarningOverlay(ctx, train.col, Math.round(x), this.viewH, train, this.totalTime);
      }
    }

    // 3. Render three-leaf clovers
    for (const clover of this.clovers) {
      const { x, y } = this.worldToScreen(clover.col, clover.row);
      const standing =
        this.status === 'PLAYING' &&
        !this.player.isMoving &&
        this.player.col === clover.col &&
        this.player.row === clover.row;
      drawClover(ctx, clover, Math.round(x), Math.round(y), this.totalTime, standing);
    }

    // 4. Render Rainbow Hair NPCs & Player sorted top-to-bottom for clean depth overlap
    type ActorDraw = { row: number; draw: () => void };
    const actors: ActorDraw[] = [];
    for (const npc of this.npcs) {
      actors.push({
        row: npc.rowPos,
        draw: () => {
          const { x, y } = this.worldToScreen(npc.col, npc.rowPos);
          drawRainbowNpc(ctx, npc, x, y, this.totalTime);
        },
      });
    }
    actors.push({
      row: this.player.visualRow,
      draw: () => {
        const { x, y } = this.worldToScreen(this.player.visualCol, this.player.visualRow);
        drawPlayer(ctx, this.player, x, y, this.totalTime);
      },
    });
    actors.sort((a, b) => b.row - a.row);
    for (const actor of actors) {
      actor.draw();
    }

    // 5. Render active trains / Twelve City vehicles
    for (const train of this.trains) {
      if (train.phase !== 'ACTIVE') continue;
      const tailRow = train.rowPos - train.direction * train.lengthRows;
      const nosePos = this.worldToScreen(train.col, train.rowPos);
      const tailPos = this.worldToScreen(train.col, tailRow);
      drawTrain(ctx, train, Math.round(nosePos.x), nosePos.y + TILE_PX / 2, tailPos.y + TILE_PX / 2);
    }

    // 6. Render pooled particles
    for (const p of this.particles) {
      if (!p.active) continue;
      ctx.globalAlpha = Math.max(0, 1 - p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.fillRect(Math.round(p.x), Math.round(p.y), p.size, p.size);
    }
    ctx.globalAlpha = 1;

    // 7. Render crisp countdown badge when actively collecting a clover
    if (this.status === 'PLAYING' && this.player.collectPose) {
      const activeClover = this.clovers.find(
        (c) => c.col === this.player.col && c.row === this.player.row
      );
      if (activeClover) {
        const { x, y } = this.worldToScreen(this.player.visualCol, this.player.visualRow);
        const secsLeft = Math.max(0, CLOVER_HOLD_SECONDS - activeClover.collectProgress).toFixed(1);
        ctx.font = 'bold 7px monospace';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#09130c';
        ctx.fillText(`${secsLeft}s`, Math.round(x + TILE_PX / 2) + 1, Math.round(y) - 8);
        ctx.fillStyle = '#fef08a';
        ctx.fillText(`${secsLeft}s`, Math.round(x + TILE_PX / 2), Math.round(y) - 9);
      }
    }

    // 8. Render floating score texts
    for (const ft of this.floatingTexts) {
      const { x, y } = this.worldToScreen(ft.worldCol, ft.worldRow);
      ctx.globalAlpha = Math.max(0, 1 - ft.life / ft.maxLife);
      ctx.font = 'bold 8px monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#09130c';
      ctx.fillText(ft.text, Math.round(x + TILE_PX / 2) + 1, Math.round(y) + 1);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, Math.round(x + TILE_PX / 2), Math.round(y));
    }
    ctx.globalAlpha = 1;

    // 9. Pixel-art map transformation wipe overlay
    if (this.mapTransitionActive) {
      const progress = Math.min(1, this.mapTransitionTimer / this.mapTransitionDuration);
      drawMapTransitionOverlay(ctx, this.viewW, this.viewH, progress, this.mapTransitionTarget);
    }

    ctx.restore();
  }

  private emitHud(force: boolean): void {
    this.lastHudEmit = this.totalTime;
    void force;
    const difficultyLevel = 1 + Math.floor(this.elapsedSeconds / 20);
    const mapTimeRemaining = Math.max(0, Math.ceil(MAP_SWITCH_INTERVAL - this.mapSwitchTimer));
    this.onHudChange({
      status: this.status,
      score: this.score,
      bestScore: this.bestScore,
      clovers: this.cloversCollected,
      streak: this.streak,
      elapsedSeconds: Math.floor(this.elapsedSeconds),
      isNewRecord: this.isNewRecord,
      difficultyLevel,
      mapTheme: this.mapTheme,
      mapTimeRemaining,
      deathReason: this.deathReason,
    });
  }
}
