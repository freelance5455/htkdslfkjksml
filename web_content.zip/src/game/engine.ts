import { sound } from './audio';
import { CombatSystem } from './combat';
import { ARMORS, ITEMS, MONSTERS, QUESTS, REGIONS, WEAPONS } from './constants';
import { InputManager } from './input';
import { MonsterAIManager } from './monsterAI';
import { ParticlePool } from './particleSystem';
import { SaveSystem } from './saveSystem';
import { SpriteRenderer } from './spriteRenderer';
import {
  ActiveMonsterState,
  FloatingNumber,
  GameSaveData,
  MonsterAttackDef,
  MonsterPart,
  PlayerStats,
  Projectile,
  QuestDef,
  RegionId,
  WeaponClass,
} from './types';
import { WorldManager } from './world';

export interface GameEngineEvents {
  onStateUpdate: (stats: PlayerStats, activeMonster: ActiveMonsterState | null) => void;
  onHuntComplete: (quest: QuestDef, monsterId: string, timeSec: number, carves: string[]) => void;
  onHuntFailed: (reason: string) => void;
  onPartBrokenBanner: (monsterName: string, partName: string) => void;
  onNotification: (msg: string) => void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private running: boolean = false;
  private animFrameId: number = 0;
  private lastTime: number = 0;

  // Systems
  public input: InputManager;
  public world: WorldManager;
  public particles: ParticlePool;
  public saveData: GameSaveData;
  public events: GameEngineEvents;

  // Player state
  public playerX: number = 600;
  public playerY: number = 600;
  public playerAngle: number = 0;
  public playerStats: PlayerStats;
  public walkDistance: number = 0;
  public isMoving: boolean = false;
  public isSprinting: boolean = false;
  public isRolling: boolean = false;
  public rollTimer: number = 0;
  public rollDuration: number = 0.42;
  public invulnerableTimer: number = 0;
  public rollDx: number = 0;
  public rollDy: number = 0;

  // Combat state
  public isAttacking: boolean = false;
  public attackTimer: number = 0;
  public attackDuration: number = 0.35;
  public attackType: string = 'standard';
  public attackComboIndex: number = 0;
  public isGuarding: boolean = false;
  public potionDrinkTimer: number = 0;

  // Camera & Screen Shake
  public cameraX: number = 0;
  public cameraY: number = 0;
  public cameraShake: number = 0;
  public hitstopTimer: number = 0;

  // Active entities
  public monsters: ActiveMonsterState[] = [];
  public lockedMonsterIndex: number | null = null;
  public projectiles: Projectile[] = [];
  public floatingNumbers: FloatingNumber[] = [];

  // Hunt session timer
  public huntTimer: number = 0;
  public activeQuest: QuestDef | null = null;
  public collectedCarves: string[] = [];
  public questFinished: boolean = false;

  constructor(
    canvas: HTMLCanvasElement,
    events: GameEngineEvents,
    saveData?: GameSaveData
  ) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.events = events;
    this.saveData = saveData || SaveSystem.load();

    this.input = new InputManager();
    this.world = new WorldManager();
    this.particles = new ParticlePool(600);

    // Initial player stats from save data
    this.playerStats = {
      level: 1,
      hunterRank: this.saveData.hunterRank,
      hunterXp: this.saveData.hunterXp,
      nextRankXp: this.saveData.hunterRank * 300,
      zenny: this.saveData.zenny,
      hp: 120,
      maxHp: 120,
      stamina: 100,
      maxStamina: 100,
      equippedWeaponId: this.saveData.equippedWeaponId || 'iron_greatsword',
      equippedArmor: this.saveData.equippedArmor,
      pouch: [...this.saveData.inventory],
      selectedPouchIndex: 0,
      spiritGauge: 0,
      spiritLevel: 0,
      spiritDuration: 0,
      demonMode: false,
      demonGauge: 0,
      chargeLevel: 0,
      chargeTimer: 0,
      bowCoating: 'none',
    };

    // Calculate max health bonus from armor
    this.recalculateArmorStats();

    // Spawn player at Camp
    this.loadRegion(this.saveData.unlockedRegions[0] || 'settlement');
  }

  public recalculateArmorStats() {
    let hpBonus = 0;
    Object.values(this.playerStats.equippedArmor).forEach((armorId) => {
      const armor = ARMORS[armorId];
      if (armor?.skillName.includes('Health Boost II')) hpBonus += 35;
      else if (armor?.skillName.includes('Health Boost')) hpBonus += 20;
    });
    this.playerStats.maxHp = 100 + hpBonus;
    this.playerStats.hp = Math.min(this.playerStats.hp, this.playerStats.maxHp);
  }

  public start() {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public stop() {
    this.running = false;
    cancelAnimationFrame(this.animFrameId);
  }

  public loadRegion(regionId: RegionId) {
    this.world.loadRegion(regionId);
    this.monsters = [];
    this.projectiles = [];
    this.floatingNumbers = [];
    this.lockedMonsterIndex = null;
    this.questFinished = false;
    this.huntTimer = 0;
    this.collectedCarves = [];

    // Set player position to region camp
    const regCfg = this.world.getRegionConfig();
    this.playerX = regCfg.campX;
    this.playerY = regCfg.campY;
    this.cameraX = this.playerX - this.canvas.width / 2;
    this.cameraY = this.playerY - this.canvas.height / 2;

    // Spawn monsters for this region
    this.spawnMonstersForRegion(regionId);

    // Set active quest if matches region
    if (this.saveData.activeQuestId) {
      const q = QUESTS.find((quest) => quest.id === this.saveData.activeQuestId);
      if (q && q.region === regionId) {
        this.activeQuest = q;
      }
    }

    this.events.onNotification(`Entered ${regCfg.name}`);
  }

  private spawnMonstersForRegion(region: RegionId) {
    if (region === 'settlement') {
      // Training Dummy / Bulwark to test combos
      this.spawnMonster('mossback', 850, 650);
      return;
    }

    if (region === 'verdant') {
      this.spawnMonster('mossback', 950, 800);
      this.spawnMonster('thornweaver', 1500, 1400);
    } else if (region === 'ember') {
      this.spawnMonster('ashfang', 1100, 1100);
      this.spawnMonster('basaltor', 1650, 1600);
    } else if (region === 'frostveil') {
      this.spawnMonster('frostmaw', 1050, 1150);
      this.spawnMonster('glaciershell', 1700, 1500);
    } else if (region === 'marsh') {
      this.spawnMonster('mireclaw', 1200, 1000);
      this.spawnMonster('nightstalker', 1600, 1650);
    } else if (region === 'crater') {
      this.spawnMonster('dreadhorn', 900, 900);
      this.spawnMonster('thunderjaw', 1450, 1100);
      this.spawnMonster('crystalhide', 1700, 1550);
      this.spawnMonster('voidcrown', 1200, 1800);
    }
  }

  private spawnMonster(defId: string, x: number, y: number) {
    const def = MONSTERS[defId];
    if (!def) return;

    this.monsters.push({
      defId,
      x,
      y,
      vx: 0,
      vy: 0,
      angle: Math.random() * Math.PI * 2,
      hp: def.baseHp,
      maxHp: def.baseHp,
      stamina: 100,
      state: 'idle',
      stateTimer: 2.0,
      enraged: false,
      enrageTimer: 0,
      parts: def.parts.map((p) => ({ ...p })),
      currentAttack: null,
      attackTargetX: 0,
      attackTargetY: 0,
      staggerBuildup: 0,
      stunBuildup: 0,
      poisonBuildup: 0,
      isPoisoned: false,
      poisonTimer: 0,
      isCarved: false,
      targetHunter: false,
      variantPhase: 1,
    });
  }

  private loop = (currentTime: number) => {
    if (!this.running) return;

    const rawDt = (currentTime - this.lastTime) / 1000;
    this.lastTime = currentTime;

    // Clamped frame delta time
    const dt = Math.min(rawDt, 0.05);

    // Update screen shake & hitstop
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      // During hitstop, simulation physics pause but particles and camera shake continue
    } else {
      this.updateSimulation(dt);
    }

    this.updateVisualEffects(dt);
    this.render();

    this.animFrameId = requestAnimationFrame(this.loop);
  };

  private updateSimulation(dt: number) {
    this.huntTimer += dt;
    this.world.update(dt);
    this.input.update(dt);

    // Update Player
    this.updatePlayer(dt);

    // Update Monsters
    for (let i = 0; i < this.monsters.length; i++) {
      const monster = this.monsters[i];
      MonsterAIManager.updateMonster(
        monster,
        this.playerX,
        this.playerY,
        dt,
        this.world,
        (m, att) => this.onMonsterTriggerAttack(m, att),
        (m) => sound.play('monster_roar')
      );
    }

    // Update Projectiles
    this.updateProjectiles(dt);

    // Longsword Spirit Gauge Decay
    if (this.playerStats.spiritLevel > 0) {
      this.playerStats.spiritDuration -= dt;
      if (this.playerStats.spiritDuration <= 0) {
        this.playerStats.spiritLevel--;
        this.playerStats.spiritDuration = this.playerStats.spiritLevel > 0 ? 30 : 0;
      }
    }

    // Dual Blades Demon Mode Stamina Drain
    if (this.playerStats.demonMode) {
      this.playerStats.stamina = Math.max(0, this.playerStats.stamina - 18 * dt);
      if (this.playerStats.stamina <= 0) {
        this.playerStats.demonMode = false;
      }
    }

    // Check Quest Completion
    this.checkQuestProgress();

    // Notify UI (throttled to discrete frames)
    const lockedMonster =
      this.lockedMonsterIndex !== null ? this.monsters[this.lockedMonsterIndex] : null;
    this.events.onStateUpdate(this.playerStats, lockedMonster || this.monsters[0] || null);

    // Conclude input frame
    this.input.endFrame();
  }

  private updatePlayer(dt: number) {
    const weapon = WEAPONS[this.playerStats.equippedWeaponId] || WEAPONS['iron_greatsword'];

    // 1. Invulnerability Timer
    if (this.invulnerableTimer > 0) {
      this.invulnerableTimer = Math.max(0, this.invulnerableTimer - dt);
    }

    // 2. Dodge Roll
    if (this.isRolling) {
      this.rollTimer += dt;
      const progress = this.rollTimer / this.rollDuration;

      // Move during roll
      const rollSpeed = 340 * (1 - progress * 0.4);
      this.playerX += this.rollDx * rollSpeed * dt;
      this.playerY += this.rollDy * rollSpeed * dt;

      // Obstacle collision
      const col = this.world.resolveCollision(this.playerX, this.playerY, 14);
      this.playerX = col.x;
      this.playerY = col.y;

      if (this.rollTimer >= this.rollDuration) {
        this.isRolling = false;
        this.rollTimer = 0;
      }
      return;
    }

    // 3. Attack Execution & Combo Animation
    if (this.isAttacking) {
      this.attackTimer += dt;

      // Weapon Charging (Greatsword & Bow hold)
      if (this.attackType === 'charge') {
        if (this.input.isHeld('attack')) {
          this.playerStats.chargeTimer += dt;
          if (this.playerStats.chargeTimer >= 1.4) this.playerStats.chargeLevel = 3;
          else if (this.playerStats.chargeTimer >= 0.7) this.playerStats.chargeLevel = 2;
          else this.playerStats.chargeLevel = 1;
        } else {
          // Release Charged Attack!
          this.releaseChargedAttack(weapon.weaponClass);
          this.isAttacking = false;
          this.attackTimer = 0;
          this.playerStats.chargeTimer = 0;
        }
        return;
      }

      if (this.attackTimer >= this.attackDuration) {
        this.isAttacking = false;
        this.attackTimer = 0;
      }
      return;
    }

    // 4. Movement Input
    const { dx, dy } = this.input.getMovementVector();
    this.isMoving = dx !== 0 || dy !== 0;

    // Guard Check (Lance or Greatsword)
    this.isGuarding = this.input.isHeld('guard') && (weapon.weaponClass === 'lance' || weapon.weaponClass === 'greatsword');

    // Sprinting (costs stamina)
    this.isSprinting =
      this.isMoving &&
      this.input.isHeld('sprint') &&
      this.playerStats.stamina > 10 &&
      !this.isGuarding;

    if (this.isSprinting) {
      this.playerStats.stamina = Math.max(0, this.playerStats.stamina - 15 * dt);
    } else if (!this.playerStats.demonMode) {
      // Regenerate stamina
      this.playerStats.stamina = Math.min(
        this.playerStats.maxStamina,
        this.playerStats.stamina + 28 * dt
      );
    }

    // Move player
    if (this.isMoving && !this.isGuarding) {
      const speed = this.isSprinting
        ? 240
        : weapon.weaponClass === 'dualblades' && this.playerStats.demonMode
        ? 210
        : 160;
      this.playerX += dx * speed * dt;
      this.playerY += dy * speed * dt;
      this.playerAngle = Math.atan2(dy, dx);
      this.walkDistance += speed * dt;

      // Pushout from solid walls/trees
      const res = this.world.resolveCollision(this.playerX, this.playerY, 15);
      this.playerX = res.x;
      this.playerY = res.y;
    }

    // 5. Actions: Roll Dodge (Space or Roll Button)
    if (this.input.isJustPressed('roll') && this.playerStats.stamina >= 20 && !this.isRolling) {
      this.isRolling = true;
      this.rollTimer = 0;
      this.invulnerableTimer = 0.28; // i-frames!
      this.playerStats.stamina -= 20;

      // Roll direction follows input or facing angle
      if (this.isMoving) {
        this.rollDx = dx;
        this.rollDy = dy;
      } else {
        this.rollDx = Math.cos(this.playerAngle);
        this.rollDy = Math.sin(this.playerAngle);
      }
      sound.play('dodge_roll');
      this.particles.burst(this.playerX, this.playerY, 6, '#cbd5e1', 70, 2.5, 0.25);
      return;
    }

    // 6. Actions: Primary Attack (J / Left Click / Touch Button)
    const attackPressed = this.input.isJustPressed('attack');
    const attackHeld = this.input.isHeld('attack');

    if ((attackPressed || (!this.isAttacking && attackHeld)) && !this.isGuarding && !this.isRolling) {
      // Auto-aim towards cursor or locked monster
      if (this.input.mousePos.x > 0 || this.input.mousePos.y > 0) {
        const worldMx = this.cameraX + this.input.mousePos.x;
        const worldMy = this.cameraY + this.input.mousePos.y;
        const distToMouse = Math.hypot(worldMx - this.playerX, worldMy - this.playerY);
        if (distToMouse > 30) {
          this.playerAngle = Math.atan2(worldMy - this.playerY, worldMx - this.playerX);
        }
      }
      if (this.lockedMonsterIndex !== null && this.monsters[this.lockedMonsterIndex]) {
        const lm = this.monsters[this.lockedMonsterIndex];
        if (lm.state !== 'dead') {
          this.playerAngle = Math.atan2(lm.y - this.playerY, lm.x - this.playerX);
        }
      }
      this.triggerPlayerAttack(weapon.weaponClass, false);
      return;
    }

    // 7. Actions: Weapon Special / Heavy (K / Right Click)
    if (this.input.isJustPressed('special') && !this.isRolling) {
      if (this.lockedMonsterIndex !== null && this.monsters[this.lockedMonsterIndex]) {
        const lm = this.monsters[this.lockedMonsterIndex];
        if (lm.state !== 'dead') {
          this.playerAngle = Math.atan2(lm.y - this.playerY, lm.x - this.playerX);
        }
      }
      this.triggerPlayerAttack(weapon.weaponClass, true);
      return;
    }

    // 8. Actions: Quick Heal / Use Item (H / Quick Heal)
    if (this.input.isJustPressed('heal')) {
      this.useCurrentPouchItem();
      return;
    }

    // 9. Actions: Interact (Gather / Carve / Camp)
    if (this.input.isJustPressed('interact')) {
      this.interactNearby();
      return;
    }

    // 10. Actions: Lock-on Toggle (Tab / Q)
    if (this.input.isJustPressed('lockon')) {
      this.toggleLockOn();
      return;
    }

    // 11. Cycle Item Pouch
    if (this.input.isJustPressed('nextItem')) {
      this.playerStats.selectedPouchIndex =
        (this.playerStats.selectedPouchIndex + 1) % this.playerStats.pouch.length;
    } else if (this.input.isJustPressed('prevItem')) {
      this.playerStats.selectedPouchIndex =
        (this.playerStats.selectedPouchIndex - 1 + this.playerStats.pouch.length) %
        this.playerStats.pouch.length;
    }

    // Camera follow with smooth damping
    const targetCamX = this.playerX - this.canvas.width / 2;
    const targetCamY = this.playerY - this.canvas.height / 2;
    this.cameraX += (targetCamX - this.cameraX) * 0.12;
    this.cameraY += (targetCamY - this.cameraY) * 0.12;
  }

  // Trigger attacks tailored to the 6 weapon classes
  private triggerPlayerAttack(weaponClass: WeaponClass, isSpecial: boolean) {
    if (weaponClass === 'greatsword') {
      if (isSpecial) {
        // Greatsword Charge Overhead Slash
        this.isAttacking = true;
        this.attackType = 'charge';
        this.attackTimer = 0;
        this.playerStats.chargeLevel = 1;
        this.playerStats.chargeTimer = 0;
        sound.play('ui_click');
      } else {
        // Quick cleave
        this.isAttacking = true;
        this.attackType = 'slash';
        this.attackDuration = 0.4;
        sound.play('slash');
        this.executeWeaponHitbox(1.2, 95, 1.4);
      }
    } else if (weaponClass === 'dualblades') {
      if (isSpecial) {
        // Toggle Demon Mode
        this.playerStats.demonMode = !this.playerStats.demonMode;
        sound.play('demon_mode');
        this.particles.burst(this.playerX, this.playerY, 14, '#ef4444', 120, 3, 0.4);
        this.events.onNotification(
          this.playerStats.demonMode ? 'Demon Mode Activated!' : 'Demon Mode Ended'
        );
      } else {
        // Rapid Flurry
        this.isAttacking = true;
        this.attackType = 'dual_flurry';
        this.attackDuration = 0.22;
        sound.play('slash');
        const mult = this.playerStats.demonMode ? 0.9 : 0.65;
        this.executeWeaponHitbox(mult, 70, 2.2);
      }
    } else if (weaponClass === 'hammer') {
      if (isSpecial) {
        // Hammer Super Pound
        this.isAttacking = true;
        this.attackType = 'pound';
        this.attackDuration = 0.55;
        sound.play('blunt_hit');
        this.executeWeaponHitbox(1.8, 85, 1.2);
        this.cameraShake = 8;
      } else {
        // Blunt swing
        this.isAttacking = true;
        this.attackType = 'swing';
        this.attackDuration = 0.35;
        sound.play('blunt_hit');
        this.executeWeaponHitbox(1.0, 75, 1.6);
      }
    } else if (weaponClass === 'longsword') {
      if (isSpecial) {
        // Spirit Helm Breaker Leap
        if (this.playerStats.spiritLevel > 0 || this.playerStats.spiritGauge >= 80) {
          this.isAttacking = true;
          this.attackType = 'helm_breaker';
          this.attackDuration = 0.45;
          sound.play('heavy_slash');
          this.executeWeaponHitbox(2.2, 110, 1.6);
          this.playerStats.spiritGauge = 0;
          if (this.playerStats.spiritLevel < 3) {
            this.playerStats.spiritLevel++;
            this.playerStats.spiritDuration = 35;
            this.events.onNotification(
              `Spirit Gauge Lv.${this.playerStats.spiritLevel} Reached!`
            );
          }
          this.cameraShake = 7;
        } else {
          this.events.onNotification('Insufficient Spirit Gauge!');
        }
      } else {
        // Spirit Sweep combo
        this.isAttacking = true;
        this.attackType = 'slash';
        this.attackDuration = 0.3;
        sound.play('slash');
        this.executeWeaponHitbox(0.9, 90, 2.0);
      }
    } else if (weaponClass === 'bow') {
      if (isSpecial) {
        // Switch Arrow Coating
        this.playerStats.bowCoating =
          this.playerStats.bowCoating === 'none'
            ? 'power'
            : this.playerStats.bowCoating === 'power'
            ? 'poison'
            : 'none';
        sound.play('ui_click');
        this.events.onNotification(`Bow Coating: ${this.playerStats.bowCoating.toUpperCase()}`);
      } else {
        // Fire Piercing Arrow Projectile
        this.isAttacking = true;
        this.attackType = 'shoot';
        this.attackDuration = 0.3;
        sound.play('bow_fire');
        this.fireArrowProjectile();
      }
    } else if (weaponClass === 'lance') {
      if (isSpecial) {
        // Guard Counter Thrust
        this.isAttacking = true;
        this.attackType = 'counter';
        this.attackDuration = 0.4;
        sound.play('guard_block');
        this.executeWeaponHitbox(1.6, 95, 0.9);
      } else {
        // Precise thrust
        this.isAttacking = true;
        this.attackType = 'thrust';
        this.attackDuration = 0.28;
        sound.play('lance_poke');
        this.executeWeaponHitbox(0.95, 90, 0.8);
      }
    }
  }

  // Release charged greatsword cleave
  private releaseChargedAttack(weaponClass: WeaponClass) {
    sound.play('heavy_slash');
    const chargeMult = this.playerStats.chargeLevel === 3 ? 3.0 : 1.8;
    this.executeWeaponHitbox(chargeMult, 110, 1.8, 'charge');
    this.cameraShake = 12;
    this.hitstopTimer = 0.06;
    this.particles.slashArc(
      this.playerX,
      this.playerY,
      this.playerAngle,
      110,
      this.playerStats.chargeLevel === 3 ? '#ef4444' : '#f59e0b'
    );
  }

  // Fire bow projectile
  private fireArrowProjectile() {
    const spd = 480;
    const color =
      this.playerStats.bowCoating === 'poison'
        ? '#84cc16'
        : this.playerStats.bowCoating === 'power'
        ? '#f59e0b'
        : '#e2e8f0';

    this.projectiles.push({
      id: `proj_${Date.now()}_${Math.random()}`,
      x: this.playerX + Math.cos(this.playerAngle) * 20,
      y: this.playerY + Math.sin(this.playerAngle) * 20,
      vx: Math.cos(this.playerAngle) * spd,
      vy: Math.sin(this.playerAngle) * spd,
      radius: 6,
      damage: CombatSystem.calculatePlayerAttack(this.playerStats),
      element: this.playerStats.bowCoating === 'poison' ? 'poison' : 'none',
      fromPlayer: true,
      life: 0.8,
      maxLife: 0.8,
      color,
    });
  }

  // Execute melee weapon hitbox against nearby monsters
  private executeWeaponHitbox(
    multiplier: number,
    range: number,
    arcAngle: number,
    attackType: string = 'standard'
  ) {
    this.particles.slashArc(this.playerX, this.playerY, this.playerAngle, range);

    for (const monster of this.monsters) {
      if (monster.state === 'dead') continue;

      const dx = monster.x - this.playerX;
      const dy = monster.y - this.playerY;
      const dist = Math.hypot(dx, dy);

      if (dist <= range + 30) {
        // Angle check
        const hitAngle = Math.atan2(dy, dx);
        let angleDiff = Math.abs(hitAngle - this.playerAngle);
        if (angleDiff > Math.PI) angleDiff = Math.PI * 2 - angleDiff;

        if (angleDiff <= arcAngle / 2) {
          // HIT CONNECTED!
          const angleRelativeToMonster = Math.atan2(this.playerY - monster.y, this.playerX - monster.x);
          const result = CombatSystem.executeAttackOnMonster(
            this.playerStats,
            monster,
            multiplier,
            attackType,
            angleRelativeToMonster
          );

          // Hitstop feedback
          this.hitstopTimer = result.isCrit ? 0.06 : 0.03;
          this.cameraShake = result.isCrit ? 7 : 4;

          // Damage Number
          this.floatingNumbers.push({
            x: monster.x + (Math.random() - 0.5) * 30,
            y: monster.y - 20,
            value: result.damage,
            text: result.isCrit ? `${result.damage}!` : `${result.damage}`,
            color: result.isCrit ? '#f97316' : '#f8fafc',
            isCrit: result.isCrit,
            life: 0.8,
            maxLife: 0.8,
          });

          // Blood / Sparks particle burst
          this.particles.burst(monster.x, monster.y, result.isCrit ? 16 : 8, '#ef4444', 110, 3, 0.35);

          // Part broken event
          if (result.partBroken) {
            sound.play('part_break');
            const def = MONSTERS[monster.defId];
            this.events.onPartBrokenBanner(def.name, result.partBroken.name);
            this.events.onNotification(`BROKEN: ${def.name}'s ${result.partBroken.name}!`);

            // If tail severed, spawn tail drop on ground
            if (result.tailSevered) {
              this.world.severedTails.push({
                x: monster.x,
                y: monster.y,
                monsterId: monster.defId,
                carved: false,
                dropItemId: result.partBroken.breakBonusDrop,
              });
              this.events.onNotification(`SEVERED: ${def.name}'s Tail dropped to the ground!`);
            }
          }

          // Defeat event
          if (result.monsterDefeated) {
            sound.play('victory');
            this.onMonsterDefeated(monster);
          }
        }
      }
    }
  }

  // Monster triggers attack against player
  private onMonsterTriggerAttack(monster: ActiveMonsterState, attack: MonsterAttackDef) {
    const def = MONSTERS[monster.defId];
    if (!def) return;

    // If attack is a projectile (e.g. Quill spray or fire breath fireball)
    if (attack.projectile) {
      const spd = 320;
      this.projectiles.push({
        id: `m_proj_${Date.now()}`,
        x: monster.x + Math.cos(monster.angle) * 30,
        y: monster.y + Math.sin(monster.angle) * 30,
        vx: Math.cos(monster.angle) * spd,
        vy: Math.sin(monster.angle) * spd,
        radius: 10,
        damage: def.baseAttack * attack.damageMultiplier,
        element: attack.element,
        fromPlayer: false,
        life: 1.2,
        maxLife: 1.2,
        color: attack.element === 'fire' ? '#ea580c' : '#84cc16',
      });
      return;
    }

    // Direct melee / charge damage check against player
    const dx = this.playerX - monster.x;
    const dy = this.playerY - monster.y;
    const dist = Math.hypot(dx, dy);

    if (dist <= attack.range + 20) {
      // Check dodge roll i-frames!
      if (this.invulnerableTimer > 0) {
        // Evaded safely!
        this.floatingNumbers.push({
          x: this.playerX,
          y: this.playerY - 24,
          value: 0,
          text: 'EVADED!',
          color: '#38bdf8',
          life: 0.6,
          maxLife: 0.6,
        });
        return;
      }

      // Calculate damage factoring guard
      const { finalDamage, blocked } = CombatSystem.calculateMonsterDamageToPlayer(
        attack.damageMultiplier,
        def.baseAttack,
        attack.element,
        this.playerStats,
        this.isGuarding
      );

      if (blocked) {
        sound.play('guard_block');
        this.playerStats.stamina = Math.max(0, this.playerStats.stamina - 25);
        this.floatingNumbers.push({
          x: this.playerX,
          y: this.playerY - 24,
          value: finalDamage,
          text: `BLOCKED -${finalDamage}`,
          color: '#38bdf8',
          life: 0.7,
          maxLife: 0.7,
        });
      } else {
        sound.play('player_hurt');
        this.playerStats.hp = Math.max(0, this.playerStats.hp - finalDamage);
        this.cameraShake = 10;
        this.particles.burst(this.playerX, this.playerY, 12, '#ef4444', 90, 3, 0.4);

        // Knockback
        this.playerX += Math.cos(monster.angle) * attack.knockback * 0.4;
        this.playerY += Math.sin(monster.angle) * attack.knockback * 0.4;

        this.floatingNumbers.push({
          x: this.playerX,
          y: this.playerY - 24,
          value: finalDamage,
          text: `-${finalDamage}`,
          color: '#ef4444',
          life: 0.8,
          maxLife: 0.8,
        });

        // Player faints
        if (this.playerStats.hp <= 0) {
          sound.play('defeat');
          this.events.onHuntFailed('Hunter fainted during combat!');
          this.respawnAtCamp();
        }
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;

      if (p.life <= 0) {
        this.projectiles.splice(i, 1);
        continue;
      }

      if (p.fromPlayer) {
        // Hit monster
        for (const monster of this.monsters) {
          if (monster.state === 'dead') continue;
          if (Math.hypot(monster.x - p.x, monster.y - p.y) < 35) {
            const result = CombatSystem.executeAttackOnMonster(
              this.playerStats,
              monster,
              1.0,
              'bow'
            );
            this.floatingNumbers.push({
              x: p.x,
              y: p.y - 15,
              value: result.damage,
              text: `${result.damage}`,
              color: '#facc15',
              life: 0.7,
              maxLife: 0.7,
            });
            this.particles.burst(p.x, p.y, 6, p.color, 80, 2.5, 0.3);
            this.projectiles.splice(i, 1);
            break;
          }
        }
      } else {
        // Hit player
        if (Math.hypot(this.playerX - p.x, this.playerY - p.y) < 22) {
          if (this.invulnerableTimer <= 0) {
            sound.play('player_hurt');
            const dmg = Math.round(p.damage * 0.8);
            this.playerStats.hp = Math.max(0, this.playerStats.hp - dmg);
            this.particles.burst(p.x, p.y, 8, '#ef4444', 80, 3, 0.3);
          }
          this.projectiles.splice(i, 1);
        }
      }
    }
  }

  private onMonsterDefeated(monster: ActiveMonsterState) {
    const def = MONSTERS[monster.defId];
    this.events.onNotification(`TARGET DEFEATED: ${def.name}!`);

    // Increment Bestiary records
    this.saveData.bestiaryKills[monster.defId] =
      (this.saveData.bestiaryKills[monster.defId] || 0) + 1;

    // Check quest completion condition
    if (this.activeQuest && this.activeQuest.targetMonsterId === monster.defId) {
      this.questFinished = true;
      this.grantQuestRewards(this.activeQuest, monster.defId);
    }
  }

  private grantQuestRewards(quest: QuestDef, monsterId: string) {
    this.playerStats.zenny += quest.rewardZenny;
    this.playerStats.hunterXp += quest.rewardHunterXp;

    // Hunter rank up check
    while (this.playerStats.hunterXp >= this.playerStats.nextRankXp) {
      this.playerStats.hunterRank++;
      this.playerStats.hunterXp -= this.playerStats.nextRankXp;
      this.playerStats.nextRankXp = this.playerStats.hunterRank * 350;
      this.events.onNotification(`★ HUNTER RANK UP! Now HR ${this.playerStats.hunterRank}!`);
    }

    // Unlocks region if story quest
    if (quest.unlocksRegion && !this.saveData.unlockedRegions.includes(quest.unlocksRegion)) {
      this.saveData.unlockedRegions.push(quest.unlocksRegion);
      this.events.onNotification(`New Region Unlocked: ${REGIONS[quest.unlocksRegion].name}!`);
    }

    // Add quest to completed
    if (!this.saveData.completedQuestIds.includes(quest.id)) {
      this.saveData.completedQuestIds.push(quest.id);
    }

    // Auto save
    this.saveData.hunterRank = this.playerStats.hunterRank;
    this.saveData.hunterXp = this.playerStats.hunterXp;
    this.saveData.zenny = this.playerStats.zenny;
    SaveSystem.save(this.saveData);

    this.events.onHuntComplete(quest, monsterId, Math.round(this.huntTimer), this.collectedCarves);
  }

  private checkQuestProgress() {
    if (!this.activeQuest || this.questFinished) return;

    // Gather quest target check
    if (this.activeQuest.gatherItemId && this.activeQuest.gatherCount) {
      const itemInPouch = this.playerStats.pouch.find(
        (i) => i.itemId === this.activeQuest!.gatherItemId
      );
      if (itemInPouch && itemInPouch.count >= this.activeQuest.gatherCount) {
        this.questFinished = true;
        sound.play('victory');
        this.grantQuestRewards(this.activeQuest, 'gather');
      }
    }
  }

  // Interact with gather nodes, monster carcass carves, or camps
  public interactNearby() {
    // 1. Check Monster Carcass Carve
    for (const monster of this.monsters) {
      if (monster.state === 'dead' && !monster.isCarved) {
        if (Math.hypot(monster.x - this.playerX, monster.y - this.playerY) < 70) {
          monster.isCarved = true;
          sound.play('gather');

          const def = MONSTERS[monster.defId];
          const drops = def.drops;
          const chosen = drops[Math.floor(Math.random() * drops.length)];

          this.addItemToPouch(chosen.itemId, chosen.count);
          this.collectedCarves.push(chosen.itemId);
          this.events.onNotification(
            `Carved ${ITEMS[chosen.itemId]?.name || chosen.itemId} x${chosen.count} from ${def.name}!`
          );
          return;
        }
      }
    }

    // 2. Check Severed Tail Carve
    for (const tail of this.world.severedTails) {
      if (!tail.carved && Math.hypot(tail.x - this.playerX, tail.y - this.playerY) < 45) {
        tail.carved = true;
        sound.play('gather');
        this.addItemToPouch(tail.dropItemId, 1);
        this.collectedCarves.push(tail.dropItemId);
        this.events.onNotification(
          `Carved ${ITEMS[tail.dropItemId]?.name || 'Tail'} from Severed Tail!`
        );
        return;
      }
    }

    // 3. Check Gather Nodes
    for (const node of this.world.gatherNodes) {
      if (!node.isGathered && Math.hypot(node.x - this.playerX, node.y - this.playerY) < 45) {
        node.isGathered = true;
        node.respawnTimer = 45; // Respawns in 45s
        sound.play('gather');

        const reward = node.items[Math.floor(Math.random() * node.items.length)];
        this.addItemToPouch(reward.itemId, reward.count);
        this.events.onNotification(
          `Gathered ${ITEMS[reward.itemId]?.name || reward.itemId} x${reward.count}!`
        );
        return;
      }
    }
  }

  // Add items cleanly to stackable pouch
  public addItemToPouch(itemId: string, count: number) {
    const existing = this.playerStats.pouch.find((slot) => slot.itemId === itemId);
    if (existing) {
      existing.count += count;
    } else {
      this.playerStats.pouch.push({ itemId, count });
    }
  }

  // Use current selected pouch item
  public useCurrentPouchItem() {
    const slot = this.playerStats.pouch[this.playerStats.selectedPouchIndex];
    if (!slot || slot.count <= 0) {
      this.events.onNotification('No item in selected pouch slot!');
      return;
    }

    const item = ITEMS[slot.itemId];
    if (!item) return;

    if (item.healAmount) {
      this.playerStats.hp = Math.min(this.playerStats.maxHp, this.playerStats.hp + item.healAmount);
      sound.play('potion');
      this.events.onNotification(`Used ${item.name} (+${item.healAmount} HP)`);
      slot.count--;
    } else if (item.staminaAmount) {
      this.playerStats.maxStamina = Math.min(150, this.playerStats.maxStamina + 25);
      this.playerStats.stamina = this.playerStats.maxStamina;
      sound.play('potion');
      this.events.onNotification(`Ate ${item.name}! Max Stamina increased!`);
      slot.count--;
    } else if (item.curesPoison) {
      sound.play('potion');
      this.events.onNotification(`Used ${item.name}! Poison cured.`);
      slot.count--;
    }

    if (slot.count <= 0) {
      this.playerStats.pouch.splice(this.playerStats.selectedPouchIndex, 1);
      this.playerStats.selectedPouchIndex = Math.max(
        0,
        this.playerStats.selectedPouchIndex - 1
      );
    }
  }

  public toggleLockOn() {
    if (this.monsters.length === 0) return;

    if (this.lockedMonsterIndex === null) {
      this.lockedMonsterIndex = 0;
    } else {
      const next = this.lockedMonsterIndex + 1;
      this.lockedMonsterIndex = next >= this.monsters.length ? null : next;
    }
    sound.play('ui_click');
  }

  private respawnAtCamp() {
    const cfg = this.world.getRegionConfig();
    this.playerX = cfg.campX;
    this.playerY = cfg.campY;
    this.playerStats.hp = this.playerStats.maxHp;
    this.playerStats.stamina = this.playerStats.maxStamina;
  }

  private updateVisualEffects(dt: number) {
    this.particles.update(dt);

    // Floating damage numbers decay
    for (let i = this.floatingNumbers.length - 1; i >= 0; i--) {
      const fn = this.floatingNumbers[i];
      fn.life -= dt;
      fn.y -= 30 * dt;
      if (fn.life <= 0) {
        this.floatingNumbers.splice(i, 1);
      }
    }

    // Camera shake decay
    if (this.cameraShake > 0) {
      this.cameraShake = Math.max(0, this.cameraShake - 20 * dt);
    }
  }

  private render() {
    const w = this.canvas.width;
    const h = this.canvas.height;

    // Apply Camera Shake
    let camX = this.cameraX;
    let camY = this.cameraY;
    if (this.cameraShake > 0) {
      camX += (Math.random() - 0.5) * this.cameraShake * 2;
      camY += (Math.random() - 0.5) * this.cameraShake * 2;
    }

    // 1. World Ground and Terrain Grid
    this.world.render(this.ctx, camX, camY, w, h);

    // 2. Monsters
    const animTime = performance.now() / 1000;
    for (const monster of this.monsters) {
      const def = MONSTERS[monster.defId];
      if (def) {
        SpriteRenderer.drawMonster(
          this.ctx,
          { ...monster, x: monster.x - camX, y: monster.y - camY },
          def,
          animTime
        );
      }
    }

    // 3. Player Hunter
    const weapon = WEAPONS[this.playerStats.equippedWeaponId] || WEAPONS['iron_greatsword'];
    SpriteRenderer.drawHunter(
      this.ctx,
      this.playerX - camX,
      this.playerY - camY,
      this.playerAngle,
      this.playerStats,
      weapon.weaponClass,
      this.isMoving,
      this.isSprinting,
      this.isRolling,
      this.rollTimer / this.rollDuration,
      this.isAttacking,
      this.attackTimer / this.attackDuration,
      this.attackType,
      this.isGuarding,
      this.walkDistance,
      this.invulnerableTimer
    );

    // 4. Obstacles (sorted for isometric depth)
    const cfg = this.world.getRegionConfig();
    this.world.renderObstacles(this.ctx, camX, camY, w, h, cfg.themeColor);

    // 5. Projectiles
    for (const p of this.projectiles) {
      this.ctx.fillStyle = p.color;
      this.ctx.beginPath();
      this.ctx.arc(p.x - camX, p.y - camY, p.radius, 0, Math.PI * 2);
      this.ctx.fill();
    }

    // 6. Particles
    this.particles.render(this.ctx, camX, camY);

    // 7. Day / Night Lighting & Torch Glow
    this.world.renderLighting(this.ctx, this.playerX, this.playerY, camX, camY, w, h);

    // 8. Floating Damage Numbers
    for (const fn of this.floatingNumbers) {
      const sx = fn.x - camX;
      const sy = fn.y - camY;
      this.ctx.save();
      this.ctx.globalAlpha = Math.max(0, fn.life / fn.maxLife);
      this.ctx.fillStyle = fn.color;
      this.ctx.font = fn.isCrit ? 'bold 18px monospace' : 'bold 14px monospace';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(fn.text || `${fn.value}`, sx, sy);
      this.ctx.restore();
    }

    // 9. Lock-On Target Reticle
    if (this.lockedMonsterIndex !== null && this.monsters[this.lockedMonsterIndex]) {
      const m = this.monsters[this.lockedMonsterIndex];
      const sx = m.x - camX;
      const sy = m.y - camY;
      this.ctx.strokeStyle = '#ef4444';
      this.ctx.lineWidth = 2;
      this.ctx.beginPath();
      this.ctx.arc(sx, sy, 45, 0, Math.PI * 2);
      this.ctx.stroke();

      // Crosshairs
      this.ctx.beginPath();
      this.ctx.moveTo(sx - 52, sy);
      this.ctx.lineTo(sx - 38, sy);
      this.ctx.moveTo(sx + 38, sy);
      this.ctx.lineTo(sx + 52, sy);
      this.ctx.moveTo(sx, sy - 52);
      this.ctx.lineTo(sx, sy - 38);
      this.ctx.moveTo(sx, sy + 38);
      this.ctx.lineTo(sx, sy + 52);
      this.ctx.stroke();
    }
  }
}
