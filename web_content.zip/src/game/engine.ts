// ============================================================
// DEEP DIG — main engine (gameplay engineer + performance engineer)
// ============================================================
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import {
  LAYERS, LAYER_ENDS, MAX_DEPTH, TREASURES, TREASURE_MAP, RARITY_INFO, layerStart, locById, layerAtDepth,
  type LocationDef, type Rarity, type TDef,
} from "./data";
import {
  S, ui, hud, bus, emit, derived, addItem, recordDig, pushDiscovery, markDirty, setScreen, toast, bagCount,
} from "./store";
import { audio } from "./audio";
import { Terrain, makeSandTexture, mulberry32, clamp, lerp } from "./terrain";
import { Particles } from "./particles";
import { buildTreasure, setEnv, type TreasureModel } from "./treasureModels";
import { Rig, buildShovel, buildDetector, DIG_IMPACT, DIG_TOSS, SHOVEL_LEN } from "./tools";
import { buildScenery, buildEnv, type Scenery, type Env } from "./scenery";

const REACH = 1.2;
const TREASURE_COUNT = 110;
const RAR_DEPTH: Record<Rarity, [number, number]> = {
  common: [0.12, 2.4], uncommon: [0.5, 3.6], rare: [1.6, 5.0], legendary: [3.0, 5.6],
};
const lin2s = (c: number) => Math.pow(clamp(c, 0, 1), 1 / 2.2);
const hex2s = (hex: number): [number, number, number] => [((hex >> 16) & 255) / 255, ((hex >> 8) & 255) / 255, (hex & 255) / 255];

interface Tr {
  idx: number;
  def: TDef;
  x: number; z: number; y: number;
  depth: number;
  state: 0 | 1 | 2;
  model: TreasureModel | null;
  halfH: number;
  rad: number;
  beam: THREE.Mesh | null;
  fly: { t: number; from: THREE.Vector3 } | null;
  fall: { vy: number; vx: number; vz: number } | null;
  glintT: number;
  yaw: number;
}

function pickWeighted<T>(items: T[], w: (t: T) => number, r: number): T {
  let tot = 0;
  for (const i of items) tot += w(i);
  let x = r * tot;
  for (const i of items) {
    x -= w(i);
    if (x <= 0) return i;
  }
  return items[items.length - 1];
}
function pickRarity(w: number[], r: number): Rarity {
  const tot = w[0] + w[1] + w[2] + w[3];
  let x = r * tot;
  const rs: Rarity[] = ["common", "uncommon", "rare", "legendary"];
  for (let i = 0; i < 4; i++) {
    x -= w[i];
    if (x <= 0) return rs[i];
  }
  return "common";
}

export class Engine {
  canvas!: HTMLCanvasElement;
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(60, 1, 0.1, 600);
  sun!: THREE.DirectionalLight;
  hemi!: THREE.HemisphereLight;
  sandTex!: THREE.Texture;
  terrainMat!: THREE.MeshStandardMaterial;
  terrain: Terrain | null = null;
  scenery: Scenery | null = null;
  envObj: Env | null = null;
  loc!: LocationDef;
  particles = new Particles();
  rig = new Rig();
  treasures: Tr[] = [];
  started = false;
  running = false;

  // input
  input = { mx: 0, mz: 0, dig: false, jump: false, interact: false };
  keys = new Set<string>();
  look = new Map<number, { x: number; y: number }>();

  // player
  pos = new THREE.Vector3();
  vy = 0;
  grounded = true;
  faceYaw = 0;
  speed = 0;
  running_ = false;
  camYaw = 0.6;
  camPitch = 0.38;
  camDist = 5.6;
  camTarget = new THREE.Vector3();
  shake = 0;
  fovKick = 0;
  digT = -1;
  impactDone = false;
  tossDone = false;
  swingDone = false;
  scoopLayer = 0;
  scoopVol = 0;
  pickupT = -1;
  toolPop = 1;
  detectorModel: THREE.Group | null = null;
  tgt = new THREE.Vector3();
  tgtOk = true;
  tgtMsg = "";
  marker!: THREE.Mesh;
  markerGeo!: THREE.BufferGeometry;
  stepIdx = 0;
  time = 0;
  hudT = 0;
  beepT = 0;
  scanT = 0;
  hintT = 0;
  nearList: Tr[] = [];
  nearT = 0;
  orbit = 0;
  lastScreen = "menu";

  // perf
  pr = 1;
  prCap = 1;
  frames = 0;
  frameAcc = 0;
  last = 0;

  // icons
  iconRT!: THREE.WebGLRenderTarget;
  iconScene = new THREE.Scene();
  iconCam = new THREE.PerspectiveCamera(30, 1, 0.1, 20);
  iconModels = new Map<string, TreasureModel>();
  iconCache = new Map<string, string>();
  pix = new Uint8Array(4);

  start(canvas: HTMLCanvasElement) {
    if (this.started) return;
    this.started = true;
    this.canvas = canvas;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer = renderer;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const pm = new THREE.PMREMGenerator(renderer);
    const env = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    setEnv(env);
    pm.dispose();

    this.sandTex = makeSandTexture();
    this.terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true, map: this.sandTex, roughness: 1, metalness: 0, bumpMap: this.sandTex, bumpScale: 1.2,
    });

    this.hemi = new THREE.HemisphereLight(0xffffff, 0xaa9977, 0.9);
    this.sun = new THREE.DirectionalLight(0xffffff, 2.5);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -15; sc.right = 15; sc.top = 15; sc.bottom = -15; sc.near = 1; sc.far = 90;
    sc.updateProjectionMatrix();
    this.sun.shadow.bias = -0.0005;
    this.sun.shadow.normalBias = 0.05;
    this.scene.add(this.hemi, this.sun, this.sun.target);
    this.scene.add(this.rig.root);
    this.scene.add(this.particles.group);

    // dig target marker (terrain-following ring)
    const SEG = 56;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array((SEG + 1) * 2 * 3), 3));
    const idx: number[] = [];
    for (let i = 0; i < SEG; i++) {
      const a = i * 2;
      idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
    geo.setIndex(idx);
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    this.markerGeo = geo;
    this.marker = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8, depthWrite: false, fog: false }));
    this.marker.frustumCulled = false;
    this.marker.renderOrder = 4;
    this.scene.add(this.marker);

    // icon rendering
    this.iconRT = new THREE.WebGLRenderTarget(128, 128, { samples: 4, colorSpace: THREE.SRGBColorSpace });
    const il = new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.3);
    const id = new THREE.DirectionalLight(0xffffff, 2.6);
    id.position.set(2, 3, 2.5);
    const id2 = new THREE.DirectionalLight(0xaaccff, 1.0);
    id2.position.set(-3, 1, -2);
    this.iconScene.add(il, id, id2);

    this.applyQuality();
    this.resize();
    window.addEventListener("resize", () => this.resize());
    window.addEventListener("orientationchange", () => setTimeout(() => this.resize(), 200));
    this.bindInput();
    bus.on("equip", () => this.rebuildTool(true));
    bus.on("beforeSave", () => this.snapshot());
    bus.on("sold", (total: number) => this.sellFx(total));

    this.loadLocation(S.location, true);
    this.running = true;
    this.last = performance.now();
    renderer.setAnimationLoop(() => this.frame());
    setTimeout(() => this.pregenIcons(), 800);
  }

  // ---------------- setup helpers ----------------
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setPixelRatio(this.pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.camDist = w / h < 0.9 ? 7.0 : 5.6;
    this.particles.setScale((h * this.pr) / (2 * Math.tan((this.camera.fov * Math.PI) / 360)));
  }
  applyQuality() {
    const q = S.settings.quality;
    const dpr = window.devicePixelRatio || 1;
    const cap = q === "low" ? Math.min(dpr, 0.8) : q === "med" ? Math.min(dpr, 1.25) : q === "high" ? Math.min(dpr, 2) : Math.min(dpr, 1.5);
    this.prCap = cap;
    if (!this.pr || this.pr > cap || q !== "auto") this.pr = cap;
    const sh = S.settings.shadows && q !== "low";
    this.renderer.shadowMap.enabled = sh;
    this.sun.castShadow = sh;
    const size = q === "high" ? 2048 : 1024;
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size);
      this.sun.shadow.map?.dispose();
      this.sun.shadow.map = null;
    }
    this.scene.traverse((o) => {
      const m = (o as THREE.Mesh).material as THREE.Material | undefined;
      if (m) m.needsUpdate = true;
    });
    audio.setVolumes({ master: S.settings.master, sfx: S.settings.sfx, ambient: S.settings.ambient });
    if (this.renderer) this.resize();
  }

  snapshot() {
    if (!this.terrain) return;
    const w = (S.worlds[this.loc.id] ||= { seed: 1, collected: [], terrain: [] });
    w.terrain = this.terrain.serialize();
  }

  loadLocation(id: string, first = false) {
    if (this.terrain) {
      this.snapshot();
    }
    const loc = locById(id);
    this.loc = loc;
    S.location = loc.id;
    // dispose previous
    this.terrain?.dispose();
    this.scenery?.dispose();
    this.envObj?.dispose();
    for (const t of this.treasures) this.disposeTr(t);
    this.treasures = [];
    this.nearList = [];

    let world = S.worlds[loc.id];
    if (!world) {
      world = S.worlds[loc.id] = { seed: 1 + Math.floor(Math.random() * 1e9), collected: [], terrain: [] };
    }
    this.terrain = new Terrain(loc, world.seed, this.terrainMat);
    this.terrain.load(world.terrain);
    this.scene.add(this.terrain.group);
    this.scenery = buildScenery(loc, this.terrain, world.seed);
    this.scene.add(this.scenery.group);
    this.envObj = buildEnv(loc, this.sandTex, this.terrain);
    this.scene.add(this.envObj.group);
    this.particles.setGround((x, z) => this.terrain!.heightAt(x, z));

    this.scene.fog = new THREE.Fog(loc.sky.fog, loc.sky.fogNear, loc.sky.fogFar);
    this.hemi.color.set(loc.sun.hemiSky);
    this.hemi.groundColor.set(loc.sun.hemiGround);
    this.hemi.intensity = loc.sun.hemiI;
    this.sun.color.set(loc.sun.color);
    this.sun.intensity = loc.sun.intensity * 1.3;
    this.hemi.intensity = loc.sun.hemiI * 1.2;
    this.generateTreasures(world);
    this.terrain.flush();
    this.treasureCheck(0, 0, true, 100);

    // place player
    this.pos.set(loc.spawn.x, 0, loc.spawn.z);
    this.pos.y = this.terrain.heightAt(loc.spawn.x, loc.spawn.z);
    this.vy = 0;
    this.grounded = true;
    this.faceYaw = Math.atan2(-loc.spawn.x, -loc.spawn.z);
    this.camYaw = this.faceYaw + Math.PI;
    this.digT = -1;
    this.pickupT = -1;
    this.rebuildTool(false);
    audio.startAmbient(loc.ambient);
    if (!first) markDirty();
    this.updateInteract();
    emit();
  }

  travel(id: string) {
    if (!S.unlocked.includes(id as any)) return;
    ui.loading = true;
    emit();
    setTimeout(() => {
      this.loadLocation(id);
      ui.loading = false;
      ui.screen = "none";
      toast(`Welcome to ${this.loc.name}`, this.loc.tagline, this.loc.accent);
      emit();
    }, 120);
  }

  generateTreasures(world: { seed: number; collected: number[] }) {
    const loc = this.loc, terrain = this.terrain!;
    const rnd = mulberry32(world.seed ^ 0x9e3779b9);
    const pool = TREASURES.filter((t) => t.locs.includes("all") || t.locs.includes(loc.id));
    const placed: { x: number; z: number }[] = [];
    const wl = loc.water ? loc.water.level : -99;
    for (let idx = 0; idx < TREASURE_COUNT; idx++) {
      const rarity = pickRarity(loc.rarityW, rnd());
      const cands = pool.filter((p) => p.rarity === rarity);
      const def = pickWeighted(cands.length ? cands : pool, (t) => (t.locs.includes(loc.id) ? 3 : 1), rnd());
      let x = 0, z = 0;
      for (let tries = 0; tries < 40; tries++) {
        x = (rnd() * 2 - 1) * 27;
        z = (rnd() * 2 - 1) * 27;
        if (this.protectedAt(x, z, 0.3)) continue;
        if (terrain.origAt(x, z) < wl + 0.5) continue;
        if (placed.some((p) => Math.hypot(p.x - x, p.z - z) < 1.1)) continue;
        break;
      }
      placed.push({ x, z });
      const rd = RAR_DEPTH[def.rarity];
      let lo = Math.max(rd[0], layerStart(def.layers[0]) + 0.05);
      let hi = Math.min(rd[1], LAYER_ENDS[def.layers[1]] - 0.05);
      if (lo >= hi) { lo = rd[0]; hi = rd[1]; }
      const depth = Math.min(lo + (hi - lo) * Math.pow(rnd(), 1.3), MAX_DEPTH - 0.3);
      const tr: Tr = {
        idx, def, x, z, depth, y: terrain.origAt(x, z) - depth, state: world.collected.includes(idx) ? 2 : 0,
        model: null, halfH: 0.05, rad: 0.1, beam: null, fly: null, fall: null, glintT: 0, yaw: rnd() * 6.28,
      };
      this.treasures.push(tr);
    }
  }

  protectedAt(x: number, z: number, pad = 0.6): boolean {
    const sc = this.scenery;
    if (!sc) return false;
    if (Math.hypot(x - sc.stationPos.x, z - sc.stationPos.z) < 4.6) return true;
    for (const c of sc.colliders) if (Math.hypot(c.x - x, c.z - z) < c.r + pad) return true;
    return false;
  }

  ensureModel(t: Tr) {
    if (t.model) return;
    t.model = buildTreasure(t.def);
    t.halfH = t.model.halfH;
    t.rad = t.model.rad;
    const o = t.model.obj;
    o.position.set(t.x, t.y, t.z);
    o.rotation.y = t.yaw;
    if (!t.def.flat) o.rotation.z = ((t.idx * 7919) % 100) / 100 * 0.5 - 0.25;
    o.visible = false;
    this.scene.add(o);
  }
  disposeTr(t: Tr) {
    if (t.model) {
      t.model.obj.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) m.geometry.dispose();
      });
      t.model.obj.removeFromParent();
      t.model = null;
    }
    if (t.beam) {
      t.beam.geometry.dispose();
      (t.beam.material as THREE.Material).dispose();
      t.beam.removeFromParent();
      t.beam = null;
    }
  }

  rebuildTool(pop: boolean) {
    if (ui.detector) {
      if (!this.detectorModel) this.detectorModel = buildDetector();
      this.rig.setTool(this.detectorModel);
    } else this.rig.setTool(buildShovel(S.shovel));
    if (pop) this.toolPop = 0.2;
  }
  toggleDetector() {
    if (this.digT >= 0 || ui.screen !== "none") return;
    ui.detector = !ui.detector;
    audio.detectorToggle(ui.detector);
    this.rebuildTool(true);
    hud.signal = 0;
    emit();
  }

  // ---------------- input ----------------
  bindInput() {
    const c = this.canvas;
    c.style.touchAction = "none";
    c.addEventListener("pointerdown", (e) => {
      if (ui.screen !== "none") return;
      c.setPointerCapture(e.pointerId);
      this.look.set(e.pointerId, { x: e.clientX, y: e.clientY });
    });
    c.addEventListener("pointermove", (e) => {
      const l = this.look.get(e.pointerId);
      if (!l) return;
      const dx = e.clientX - l.x, dy = e.clientY - l.y;
      l.x = e.clientX;
      l.y = e.clientY;
      const k = 0.0052 * S.settings.sens * (e.pointerType === "mouse" ? 0.8 : 1);
      this.camYaw -= dx * k;
      this.camPitch = clamp(this.camPitch + dy * k * (S.settings.invertY ? -1 : 1), -0.12, 1.25);
    });
    const up = (e: PointerEvent) => this.look.delete(e.pointerId);
    c.addEventListener("pointerup", up);
    c.addEventListener("pointercancel", up);
    c.addEventListener("wheel", (e) => {
      this.camDist = clamp(this.camDist + e.deltaY * 0.004, 3, 9);
    }, { passive: true });
    window.addEventListener("keydown", (e) => {
      if (e.repeat) return;
      const k = e.key.toLowerCase();
      this.keys.add(k);
      if (ui.screen === "none") {
        if (k === " ") this.input.jump = true;
        if (k === "e") this.input.interact = true;
        if (k === "r") this.toggleDetector();
        if (k === "i") setScreen("inventory");
        if (k === "b") { ui.shopTab = "shovels"; setScreen("shop"); }
        if (k === "escape") setScreen("pause");
      } else if (k === "escape" && ui.screen !== "menu") setScreen("none");
    });
    window.addEventListener("keyup", (e) => this.keys.delete(e.key.toLowerCase()));
    window.addEventListener("blur", () => this.keys.clear());
  }

  // ---------------- gameplay ----------------
  get frozen() {
    return ui.screen !== "none";
  }

  height(x: number, z: number) {
    return this.terrain!.heightAt(x, z);
  }

  private moveTo(nx: number, nz: number) {
    const t = this.terrain!;
    const lim = 28.6;
    nx = clamp(nx, -lim, lim);
    nz = clamp(nz, -lim, lim);
    for (const c of this.scenery!.colliders) {
      const dx = nx - c.x, dz = nz - c.z;
      const d = Math.hypot(dx, dz), m = c.r + 0.38;
      if (d < m) {
        const k = d < 1e-4 ? 0 : m / d;
        nx = c.x + dx * k;
        nz = c.z + dz * k;
      }
    }
    const wl = this.loc.water ? this.loc.water.level - 0.12 : -99;
    if (t.origAt(nx, nz) < wl) return false;
    const dist = Math.hypot(nx - this.pos.x, nz - this.pos.z);
    if (dist > 1e-5 && this.grounded) {
      const slope = (t.heightAt(nx, nz) - t.heightAt(this.pos.x, this.pos.z)) / dist;
      if (slope > 2.0) return false;
    }
    this.pos.x = nx;
    this.pos.z = nz;
    return true;
  }

  private targetPoint() {
    const x = this.pos.x + Math.sin(this.faceYaw) * REACH;
    const z = this.pos.z + Math.cos(this.faceYaw) * REACH;
    this.tgt.set(x, this.terrain!.heightAt(x, z), z);
    let ok = true, msg = "";
    const wl = this.loc.water ? this.loc.water.level - 0.1 : -99;
    if (this.terrain!.origAt(x, z) < wl) { ok = false; msg = "Can't dig in water"; }
    else if (this.protectedAt(x, z, 0.5)) { ok = false; msg = "Can't dig here"; }
    else if (Math.abs(x) > 28.2 || Math.abs(z) > 28.2) { ok = false; msg = "Edge of the dig zone"; }
    else if (this.terrain!.depthAt(x, z) > MAX_DEPTH - 0.05) { ok = false; msg = "Bedrock reached!"; }
    this.tgtOk = ok;
    this.tgtMsg = msg;
  }

  private fx = { r: 0, g: 0, b: 0 };
  private layerCol(layer: number, shade = 1) {
    const c = this.terrain!.layerRGB[layer];
    this.fx.r = lin2s(c[0]) * shade;
    this.fx.g = lin2s(c[1]) * shade;
    this.fx.b = lin2s(c[2]) * shade;
    return this.fx;
  }
  sandBurst(x: number, y: number, z: number, layer: number, n: number, up: number, dx = 0, dz = 0) {
    const L = LAYERS[layer];
    const dust = this.particles.dust;
    for (let i = 0; i < n; i++) {
      const c = this.layerCol(layer, 0.8 + Math.random() * 0.4);
      dust.emit({
        x: x + (Math.random() - 0.5) * 0.5, y, z: z + (Math.random() - 0.5) * 0.5,
        vx: dx * (0.6 + Math.random()) + (Math.random() - 0.5) * 2.4, vy: up * (0.5 + Math.random() * 0.9),
        vz: dz * (0.6 + Math.random()) + (Math.random() - 0.5) * 2.4,
        life: 0.7 + Math.random() * 0.6, size: 0.04 * L.chunk * (0.6 + Math.random() * 0.8), r: c.r, g: c.g, b: c.b,
        gravity: 9, drag: 0.4, hard: true, ground: true,
      });
    }
    const dn = Math.round(3 + 7 * L.dust);
    for (let i = 0; i < dn; i++) {
      const c = this.layerCol(layer, 1.12);
      dust.emit({
        x: x + (Math.random() - 0.5) * 0.7, y: y + 0.05, z: z + (Math.random() - 0.5) * 0.7,
        vx: dx * 0.3 + (Math.random() - 0.5) * 1.2, vy: 0.5 + Math.random() * 1.2, vz: dz * 0.3 + (Math.random() - 0.5) * 1.2,
        life: 0.9 + Math.random() * 0.9, size: 0.3, size1: 0.9 + Math.random() * 0.5, r: c.r, g: c.g, b: c.b, a: 0.28 * (0.4 + L.dust),
        gravity: -0.15, drag: 1.6,
      });
    }
    if (layer === 5 || layer === 4) {
      for (let i = 0; i < 4; i++)
        dust.emit({ x, y: y + 0.1, z, vx: (Math.random() - 0.5) * 4, vy: 2.5 + Math.random() * 2, vz: (Math.random() - 0.5) * 4, life: 0.8, size: 0.06, r: 0.5, g: 0.48, b: 0.46, gravity: 10, hard: true, ground: true });
    }
    if (layer === 6) this.glints(x, y + 0.1, z, 0xbfa8ff, 5, 1.2);
  }
  glints(x: number, y: number, z: number, hex: number, n: number, spread = 0.5, up = 1) {
    const [r, g, b] = hex2s(hex);
    for (let i = 0; i < n; i++)
      this.particles.glow.emit({
        x: x + (Math.random() - 0.5) * spread, y: y + Math.random() * 0.1, z: z + (Math.random() - 0.5) * spread,
        vx: (Math.random() - 0.5) * 0.5, vy: 0.3 + Math.random() * up, vz: (Math.random() - 0.5) * 0.5,
        life: 0.7 + Math.random() * 0.7, size: 0.1 + Math.random() * 0.12, size1: 0.02, r, g, b, a: 1, gravity: -0.2, drag: 0.8,
      });
  }
  revealFx(t: Tr) {
    const col = RARITY_INFO[t.def.rarity].hex;
    const n = { common: 10, uncommon: 18, rare: 36, legendary: 70 }[t.def.rarity];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const sp = 1 + Math.random() * 1.8;
      const [r, g, b] = hex2s(col);
      this.particles.glow.emit({
        x: t.x, y: t.y + t.halfH + 0.05, z: t.z, vx: Math.cos(a) * sp, vy: 0.8 + Math.random() * 2, vz: Math.sin(a) * sp,
        life: 0.9 + Math.random() * 0.6, size: 0.14 + Math.random() * 0.1, size1: 0.02, r, g, b, a: 1, gravity: 2.5, drag: 1,
      });
    }
    this.makeBeam(t);
    this.shake = Math.max(this.shake, t.def.rarity === "legendary" ? 0.12 : t.def.rarity === "rare" ? 0.06 : 0);
    this.fovKick = t.def.rarity === "legendary" ? 14 : t.def.rarity === "rare" ? 7 : 0;
    ui.flash = Date.now();
    ui.flashColor = RARITY_INFO[t.def.rarity].color;
    this.haptic(t.def.rarity === "legendary" ? [40, 40, 80] : t.def.rarity === "rare" ? 40 : 15);
  }
  makeBeam(t: Tr) {
    if (t.beam || (t.def.rarity !== "rare" && t.def.rarity !== "legendary")) return;
    const col = RARITY_INFO[t.def.rarity].hex;
    const m = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, t.def.rarity === "legendary" ? 0.35 : 0.22, 4.5, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false })
    );
    m.position.set(t.x, t.y + 2.2, t.z);
    m.renderOrder = 3;
    this.scene.add(m);
    t.beam = m;
  }
  haptic(p: number | number[]) {
    if (S.settings.haptics && navigator.vibrate) {
      try { navigator.vibrate(p); } catch { /* ignore */ }
    }
  }

  private doImpact() {
    const t = this.terrain!;
    const d = derived();
    this.targetPoint();
    const x = this.tgt.x, z = this.tgt.z;
    if (!this.tgtOk) {
      audio.error();
      return;
    }
    const res = t.dig(x, z, d.radius, 0.28, d.power);
    this.scoopLayer = res.layer;
    this.scoopVol = res.volume;
    const gy = t.heightAt(x, z);
    const L = LAYERS[res.layer];
    audio.dig(L.sound);
    this.sandBurst(x, gy + 0.05, z, res.layer, Math.round(14 * d.radius), 3.2, Math.sin(this.faceYaw) * 0.3, Math.cos(this.faceYaw) * 0.3);
    this.shake = Math.max(this.shake, 0.03 + res.layer * 0.006);
    this.haptic(8);
    recordDig(res.volume, res.depth);
    this.treasureCheck(x, z);
    // lucky scoop-find
    const luck = d.luck;
    if (res.volume > 0.02 && Math.random() < 0.045 * luck) this.scoopFind(res.layer, luck);
    markDirty();
  }

  private bladeTip(out: THREE.Vector3) {
    this.rig.root.updateMatrixWorld(true);
    out.set(0, -SHOVEL_LEN * 0.8, 0.0);
    this.rig.toolHolder.localToWorld(out);
    return out;
  }
  private doToss() {
    const tip = this.bladeTip(new THREE.Vector3());
    const side = new THREE.Vector3(Math.cos(this.faceYaw), 0, -Math.sin(this.faceYaw));
    const n = Math.round(clamp(this.scoopVol * 55, 5, 26));
    for (let i = 0; i < n; i++) {
      const c = this.layerCol(this.scoopLayer, 0.85 + Math.random() * 0.3);
      this.particles.dust.emit({
        x: tip.x, y: tip.y, z: tip.z,
        vx: side.x * (1.5 + Math.random() * 2.2) + (Math.random() - 0.5), vy: 1.2 + Math.random() * 2, vz: side.z * (1.5 + Math.random() * 2.2) + (Math.random() - 0.5),
        life: 0.9, size: 0.035 + Math.random() * 0.03, r: c.r, g: c.g, b: c.b, gravity: 9.5, drag: 0.2, hard: true, ground: true,
      });
    }
    const c = this.layerCol(this.scoopLayer, 1.1);
    for (let i = 0; i < 4; i++)
      this.particles.dust.emit({ x: tip.x + side.x * 0.8, y: tip.y - 0.4, z: tip.z + side.z * 0.8, vx: side.x, vy: 0.4, vz: side.z, life: 1.2, size: 0.25, size1: 0.8, r: c.r, g: c.g, b: c.b, a: 0.2, drag: 1.5 });
    audio.sandFall();
  }

  private scoopFind(layer: number, luck: number) {
    const loc = this.loc;
    const L = layer;
    const w = [loc.rarityW[0], loc.rarityW[1] * (1 + 0.25 * L), loc.rarityW[2] * (1 + 0.5 * L) * luck, loc.rarityW[3] * (1 + 0.8 * L) * luck];
    const rarity = pickRarity(w, Math.random());
    let pool = TREASURES.filter((p) => p.rarity === rarity && (p.locs.includes("all") || p.locs.includes(loc.id)) && L >= p.layers[0] - 1 && L <= p.layers[1]);
    if (!pool.length) pool = TREASURES.filter((p) => p.rarity === "common" && (p.locs.includes("all") || p.locs.includes(loc.id)));
    const def = pickWeighted(pool, (p) => (p.locs.includes(loc.id) ? 3 : 1), Math.random());
    const tip = this.bladeTip(new THREE.Vector3());
    const side = new THREE.Vector3(Math.cos(this.faceYaw), 0, -Math.sin(this.faceYaw));
    const tr: Tr = {
      idx: -1 - this.treasures.length, def, x: tip.x, z: tip.z, y: tip.y, depth: 0, state: 1, model: null, halfH: 0.05, rad: 0.1,
      beam: null, fly: null, fall: { vy: 3.5, vx: side.x * 1.6, vz: side.z * 1.6 }, glintT: 0, yaw: Math.random() * 6,
    };
    this.treasures.push(tr);
    this.ensureModel(tr);
    tr.model!.obj.visible = true;
    this.announce(tr);
  }

  private announce(t: Tr) {
    pushDiscovery(t.def.id);
    audio.discover(t.def.rarity);
    this.revealFx(t);
  }

  private treasureCheck(cx: number, cz: number, silent = false, range = 11) {
    const terrain = this.terrain!;
    for (const t of this.treasures) {
      if (t.state !== 0 || t.idx < 0) continue;
      if (Math.hypot(t.x - cx, t.z - cz) > range) continue;
      this.ensureModel(t);
      const r = Math.max(t.rad * 0.7, 0.05);
      const hm = Math.min(
        terrain.heightAt(t.x, t.z), terrain.heightAt(t.x + r, t.z), terrain.heightAt(t.x - r, t.z),
        terrain.heightAt(t.x, t.z + r), terrain.heightAt(t.x, t.z - r)
      );
      const top = t.y + t.halfH;
      const ex = clamp((top - hm) / (2 * t.halfH + 0.02), 0, 1);
      t.model!.obj.visible = ex > 0;
      if (ex >= 0.3) {
        t.state = 1;
        if (silent) this.makeBeam(t);
        else {
          this.announce(t);
          markDirty();
        }
      }
    }
  }

  collect(t: Tr) {
    if (t.state !== 1 || t.fly) return false;
    if (!addItem(t.def.id)) return false;
    t.state = 2;
    const w = S.worlds[this.loc.id];
    if (w && t.idx >= 0) w.collected.push(t.idx);
    const o = t.model!.obj;
    t.fly = { t: 0, from: o.position.clone() };
    this.pickupT = 0;
    const k = t.def.kind;
    audio.pickup(["coin", "button", "nugget", "hoard"].includes(k) ? "coin" : ["gem", "diamond", "crystal", "pearl", "heart", "amber"].includes(k) ? "gem" : "other");
    this.glints(t.x, t.y + 0.1, t.z, RARITY_INFO[t.def.rarity].hex, 8, 0.4);
    if (t.beam) {
      t.beam.geometry.dispose();
      (t.beam.material as THREE.Material).dispose();
      t.beam.removeFromParent();
      t.beam = null;
    }
    this.haptic(12);
    markDirty();
    return true;
  }

  pressInteract() {
    if (this.frozen) return;
    const t = this.nearestRevealed();
    if (t) {
      this.collect(t);
      return;
    }
    if (ui.nearMerchant) {
      ui.shopTab = "sell";
      audio.open();
      setScreen("shop");
    }
  }

  private nearestRevealed(): Tr | null {
    let best: Tr | null = null, bd = 2.6;
    for (const t of this.treasures) {
      if (t.state !== 1 || t.fly) continue;
      const d = Math.hypot(t.x - this.pos.x, t.z - this.pos.z);
      if (d < bd) { bd = d; best = t; }
    }
    return best;
  }
  private updateInteract() {
    const near = this.nearestRevealed();
    const sc = this.scenery!;
    const nm = Math.hypot(this.pos.x - sc.stationPos.x, this.pos.z - sc.stationPos.z) < 5.2;
    const mode: "" | "collect" | "sell" = near ? "collect" : nm ? "sell" : "";
    if (mode !== ui.interact || nm !== ui.nearMerchant || (near && near.def.name !== ui.interactName)) {
      ui.interact = mode;
      ui.nearMerchant = nm;
      ui.interactName = near ? near.def.name : "";
      emit();
    }
  }

  private sellFx(total: number) {
    const sc = this.scenery;
    if (!sc) return;
    const p = sc.stationPos;
    const n = clamp(Math.round(Math.log10(total + 10) * 8), 8, 40);
    for (let i = 0; i < n; i++)
      this.particles.glow.emit({
        x: p.x + sc.front.x * 1.2, y: p.y + 1.4, z: p.z + sc.front.z * 1.2,
        vx: (Math.random() - 0.5) * 2.5 + sc.front.x, vy: 2 + Math.random() * 3, vz: (Math.random() - 0.5) * 2.5 + sc.front.z,
        life: 1.2, size: 0.16, size1: 0.1, r: 1, g: 0.8 + Math.random() * 0.15, b: 0.2, a: 1, gravity: 6, drag: 0.3,
      });
    sc.merchant.scale.setScalar(1.12);
  }

  // ---------------- detector ----------------
  private detectorUpdate(dt: number) {
    const range = derived().detect;
    let best = 0, tier = 0;
    for (const t of this.treasures) {
      if (t.state !== 0 || t.def.metal === 0 || t.idx < 0) continue;
      const dx = t.x - this.pos.x, dz = t.z - this.pos.z;
      if (Math.abs(dx) > range || Math.abs(dz) > range) continue;
      const d = Math.hypot(dx, dz, t.depth * 0.3);
      if (d >= range) continue;
      const s = Math.pow(1 - d / range, 1.4);
      if (s > best) { best = s; tier = t.def.metal; }
    }
    hud.signal = lerp(hud.signal, best, Math.min(1, dt * 10));
    hud.signalTier = best > 0.02 ? tier : 0;
    this.beepT -= dt;
    this.scanT -= dt;
    if (best > 0.03) {
      if (this.beepT <= 0) {
        const base = tier === 3 ? 700 : tier === 2 ? 480 : 300;
        audio.detector(base * (1 + best * 0.9), tier);
        this.beepT = lerp(1.0, 0.1, Math.pow(best, 0.7));
        this.haptic(5);
      }
    } else if (this.scanT <= 0) {
      audio.scanTick();
      this.scanT = 1.4;
    }
    const led = this.detectorModel?.userData.led as THREE.MeshStandardMaterial | undefined;
    if (led) led.emissiveIntensity = 0.2 + hud.signal * 3 * (0.6 + 0.4 * Math.sin(this.time * 20));
  }

  // ---------------- main frame ----------------
  frame() {
    const now = performance.now();
    let dt = (now - this.last) / 1000;
    this.last = now;
    dt = Math.min(dt, 0.05);
    this.time += dt;
    this.perf(dt);
    if (!this.terrain || !this.scenery || !this.envObj) return;
    const frozen = this.frozen;
    const terrain = this.terrain;
    if (this.lastScreen === "menu" && ui.screen !== "menu") {
      this.camYaw = this.faceYaw + Math.PI;
      this.camPitch = 0.38;
      this.camTarget.set(this.pos.x, this.pos.y + 1.45, this.pos.z);
    }
    this.lastScreen = ui.screen;

    // ---- input ----
    let mx = this.input.mx, mz = this.input.mz;
    const k = this.keys;
    if (k.has("w") || k.has("arrowup")) mz += 1;
    if (k.has("s") || k.has("arrowdown")) mz -= 1;
    if (k.has("d") || k.has("arrowright")) mx += 1;
    if (k.has("a") || k.has("arrowleft")) mx -= 1;
    const wantDig = this.input.dig || k.has("f") || k.has("x");
    let mag = Math.hypot(mx, mz);
    if (mag > 1) { mx /= mag; mz /= mag; mag = 1; }
    if (frozen) { mx = 0; mz = 0; mag = 0; }
    const sprint = k.has("shift") || mag > 0.82;

    // ---- player ----
    const digging = this.digT >= 0;
    const d = derived();
    if (!frozen) {
      if (this.input.jump && this.grounded && !digging) {
        this.vy = 6.4;
        this.grounded = false;
        audio.jump();
      }
      this.input.jump = false;
      if (this.input.interact) { this.pressInteract(); this.input.interact = false; }
    } else {
      this.input.jump = false;
      this.input.interact = false;
    }
    const cf = new THREE.Vector3(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw));
    const cr = new THREE.Vector3(Math.cos(this.camYaw), 0, -Math.sin(this.camYaw));
    const dir = new THREE.Vector3().addScaledVector(cf, mz).addScaledVector(cr, mx);
    let spd = 0;
    if (mag > 0.08 && !digging && this.pickupT < 0) {
      const base = sprint ? 6.0 : 3.4;
      spd = base * Math.min(1, mag > 0.82 ? 1 : mag * 1.15);
      const ndx = dir.x / (Math.hypot(dir.x, dir.z) || 1), ndz = dir.z / (Math.hypot(dir.x, dir.z) || 1);
      const slope = (terrain.heightAt(this.pos.x + ndx * 0.4, this.pos.z + ndz * 0.4) - this.pos.y) / 0.4;
      spd *= clamp(1 - Math.max(0, slope) * 0.3, 0.5, 1);
      const nx = this.pos.x + ndx * spd * dt, nz = this.pos.z + ndz * spd * dt;
      if (!this.moveTo(nx, nz)) {
        // slide along axes
        if (!this.moveTo(nx, this.pos.z)) this.moveTo(this.pos.x, nz);
      }
      const target = Math.atan2(ndx, ndz);
      let df = target - this.faceYaw;
      df = Math.atan2(Math.sin(df), Math.cos(df));
      this.faceYaw += df * Math.min(1, dt * 12);
    } else if (!frozen && (digging || (wantDig && !ui.detector))) {
      const target = Math.atan2(cf.x, cf.z);
      let df = target - this.faceYaw;
      df = Math.atan2(Math.sin(df), Math.cos(df));
      this.faceYaw += df * Math.min(1, dt * 14);
    } else if (!frozen && this.look.size > 0 || (!frozen && ui.screen === "none")) {
      const target = Math.atan2(cf.x, cf.z);
      let df = target - this.faceYaw;
      df = Math.atan2(Math.sin(df), Math.cos(df));
      if (this.look.size > 0 || Math.abs(df) > 0.01) this.faceYaw += df * Math.min(1, dt * 3.2);
    }
    this.speed = lerp(this.speed, spd, Math.min(1, dt * 12));
    this.running_ = sprint && spd > 0;
    // vertical
    const ground = terrain.heightAt(this.pos.x, this.pos.z);
    if (this.vy > 0 || this.pos.y > ground + 0.05) {
      this.vy -= 19 * dt;
      this.pos.y += this.vy * dt;
      this.grounded = false;
      if (this.pos.y <= ground) {
        if (this.vy < -4) { audio.land(); this.sandBurst(this.pos.x, ground, this.pos.z, 0, 4, 1.2); }
        this.pos.y = ground;
        this.vy = 0;
        this.grounded = true;
      }
    } else {
      this.pos.y = ground;
      this.vy = 0;
      this.grounded = true;
    }
    // footsteps
    if (this.grounded && this.speed > 0.8) {
      const si = Math.floor(this.rig.phase / Math.PI);
      if (si !== this.stepIdx) {
        this.stepIdx = si;
        const layer = layerAtDepth(terrain.depthAt(this.pos.x, this.pos.z));
        audio.step(this.running_, LAYERS[layer].sound);
        if (this.running_) this.sandBurst(this.pos.x, this.pos.y, this.pos.z, layer, 0, 0.5);
      }
    }

    // ---- digging ----
    this.targetPoint();
    const shovelOn = !ui.detector;
    if (!frozen && shovelOn && this.digT < 0 && wantDig && this.pickupT < 0 && this.grounded) {
      if (this.tgtOk) {
        this.digT = 0;
        this.impactDone = this.tossDone = this.swingDone = false;
      } else if (this.tgtMsg && Math.floor(this.time * 2) !== Math.floor((this.time - dt) * 2)) {
        audio.error();
      }
    }
    if (this.digT >= 0) {
      this.digT += (dt * d.speed) / 0.95;
      if (!this.swingDone && this.digT > 0.18) { this.swingDone = true; audio.swing(); }
      if (!this.impactDone && this.digT >= DIG_IMPACT) { this.impactDone = true; this.doImpact(); }
      if (!this.tossDone && this.digT >= DIG_TOSS) { this.tossDone = true; this.doToss(); }
      if (this.digT >= 1) this.digT = -1;
    }
    if (this.pickupT >= 0) {
      this.pickupT += dt / 0.6;
      if (this.pickupT >= 1) this.pickupT = -1;
    }
    if (ui.detector && !frozen) this.detectorUpdate(dt);
    else hud.signal = lerp(hud.signal, 0, Math.min(1, dt * 8));

    // ---- rig ----
    this.toolPop = Math.min(1, this.toolPop + dt * 3.2);
    const hold = this.toolPop < 1 ? 0.4 + 0.6 * this.toolPop + Math.sin(this.toolPop * Math.PI) * 0.15 : 1;    this.rig.root.position.copy(this.pos);
    this.rig.root.rotation.y = this.faceYaw;
    this.rig.update(dt, {
      speed: this.speed, run: this.running_, grounded: this.grounded, vy: this.vy,
      dig: this.digT, pickup: this.pickupT, scanning: ui.detector && !frozen, dy: this.tgt.y - this.pos.y, reach: REACH,
      tool: ui.detector ? "detector" : "shovel",
    }, hold);

    // ---- treasures ----
    this.updateTreasures(dt);
    this.updateMarker(dt, frozen);

    // ---- camera ----
    this.updateCamera(dt, frozen);

    // ---- world ----
    this.particles.update(dt);
    terrain.flush();
    this.scenery.update(dt, this.time);
    if (this.scenery.merchant.scale.x > 1.001) this.scenery.merchant.scale.setScalar(lerp(this.scenery.merchant.scale.x, 1, Math.min(1, dt * 6)));
    this.envObj.update(dt, this.time, this.camera.position);
    // sun follows player (texel snapped)
    const sd = new THREE.Vector3(...this.loc.sun.dir).normalize();
    const sx = Math.round(this.pos.x / 0.5) * 0.5, sz = Math.round(this.pos.z / 0.5) * 0.5;
    this.sun.target.position.set(sx, this.pos.y, sz);
    this.sun.position.set(sx + sd.x * 45, this.pos.y + sd.y * 45, sz + sd.z * 45);
    this.sun.target.updateMatrixWorld();

    // ---- hud ----
    this.hudT += dt;
    if (this.hudT > 0.1) {
      this.hudT = 0;
      this.syncHud();
    }
    this.renderer.render(this.scene, this.camera);
  }

  private updateTreasures(dt: number) {
    this.nearT -= dt;
    if (this.nearT <= 0) {
      this.nearT = 0.3;
      this.nearList = this.treasures.filter((t) => t.state !== 2 && Math.hypot(t.x - this.pos.x, t.z - this.pos.z) < 10);
      this.updateInteract();
    }
    const terrain = this.terrain!;
    for (const t of this.nearList) {
      if (t.state === 0) {
        // hint sparkles when only a thin layer of sand covers a find
        const hm = terrain.heightAt(t.x, t.z);
        const cover = hm - (t.y + t.halfH);
        const rar = t.def.rarity;
        const maxC = rar === "legendary" ? 0.75 : rar === "rare" ? 0.55 : rar === "uncommon" ? 0.38 : 0.25;
        if (cover > 0 && cover < maxC) {
          t.glintT -= dt;
          if (t.glintT <= 0) {
            t.glintT = (0.5 + (cover / maxC) * 1.2) * (rar === "common" ? 1.6 : 1);
            this.glints(t.x, hm + 0.03, t.z, RARITY_INFO[rar].hex, rar === "legendary" ? 3 : 1, 0.25, 0.7);
          }
        }
      } else if (t.state === 1 && t.model) {
        t.glintT -= dt;
        if (t.glintT <= 0 && t.def.rarity !== "common") {
          t.glintT = 0.35 + Math.random() * 0.5;
          this.glints(t.x + (Math.random() - 0.5) * 0.3, t.y + t.halfH + 0.05, t.z + (Math.random() - 0.5) * 0.3, RARITY_INFO[t.def.rarity].hex, 1, 0.1, 0.6);
        }
      }
    }
    for (const t of this.treasures) {
      if (!t.model) continue;
      const o = t.model.obj;
      if (t.fall) {
        const f = t.fall;
        f.vy -= 14 * dt;
        t.x += f.vx * dt; t.z += f.vz * dt; t.y += f.vy * dt;
        f.vx *= 0.99; f.vz *= 0.99;
        const g = terrain.heightAt(t.x, t.z) + t.halfH * 0.6;
        if (t.y <= g) { t.y = g; t.fall = null; this.sandBurst(t.x, g, t.z, 0, 3, 1); }
        o.position.set(t.x, t.y, t.z);
        o.rotation.y += dt * 6;
      }
      if (t.fly) {
        t.fly.t += dt / 0.45;
        const u = clamp(t.fly.t, 0, 1);
        const e = u * u * (3 - 2 * u);
        const to = new THREE.Vector3(this.pos.x, this.pos.y + 1.3, this.pos.z);
        o.position.lerpVectors(t.fly.from, to, e);
        o.position.y += Math.sin(u * Math.PI) * 0.7;
        o.scale.setScalar(1 - e * 0.85);
        o.rotation.y += dt * 12;
        if (u >= 1) {
          this.disposeTr(t);
          t.fly = null;
        }
      }
      if (t.state === 1 && t.model) {
        const gl = t.model.glow;
        if (gl) gl.emissiveIntensity = 0.7 + Math.sin(this.time * 3 + t.idx) * 0.35;
      }
      if (t.beam) (t.beam.material as THREE.MeshBasicMaterial).opacity = 0.2 + Math.sin(this.time * 3) * 0.08;
    }
  }

  private updateMarker(dt: number, frozen: boolean) {
    void dt;
    const show = !frozen && !ui.detector && this.pickupT < 0;
    this.marker.visible = show;
    if (!show) return;
    const r = derived().radius;
    const pos = this.markerGeo.attributes.position as THREE.BufferAttribute;
    const SEG = 56;
    const t = this.terrain!;
    const pulse = 1 + Math.sin(this.time * 4) * 0.02;
    for (let i = 0; i <= SEG; i++) {
      const a = (i / SEG) * Math.PI * 2;
      const c = Math.cos(a), s = Math.sin(a);
      for (let j = 0; j < 2; j++) {
        const rr = (r + (j ? 0.035 : -0.035)) * pulse;
        const x = this.tgt.x + c * rr, z = this.tgt.z + s * rr;
        pos.setXYZ(i * 2 + j, x, t.heightAt(x, z) + 0.05, z);
      }
    }
    pos.needsUpdate = true;
    const mat = this.marker.material as THREE.MeshBasicMaterial;
    mat.color.set(this.tgtOk ? 0xfff2b0 : 0xff6a5a);
    mat.opacity = this.digT >= 0 ? 0.9 : 0.5 + Math.sin(this.time * 4) * 0.12;
  }

  private updateCamera(dt: number, frozen: boolean) {
    const cam = this.camera;
    if (ui.screen === "menu") {
      this.orbit += dt * 0.12;
      this.camYaw = this.faceYaw + Math.PI * 0.75 + this.orbit;
      this.camPitch = 0.34;
    }
    const hy = this.pos.y + 1.45;
    const off = new THREE.Vector3(Math.cos(this.camYaw), 0, -Math.sin(this.camYaw)).multiplyScalar(ui.screen === "menu" ? 0 : 0.8);
    if (ui.screen !== "menu") off.addScaledVector(new THREE.Vector3(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw)), 1.1);
    const tx = this.pos.x + off.x, ty = hy, tz = this.pos.z + off.z;
    this.camTarget.x = lerp(this.camTarget.x, tx, Math.min(1, dt * 16));
    this.camTarget.y = lerp(this.camTarget.y, ty, Math.min(1, dt * 10));
    this.camTarget.z = lerp(this.camTarget.z, tz, Math.min(1, dt * 16));
    if (this.camTarget.distanceTo(new THREE.Vector3(tx, ty, tz)) > 4) this.camTarget.set(tx, ty, tz);
    const dist = this.camDist * (ui.screen === "menu" ? 1.5 : 1) * (this.digT >= 0 ? 0.94 : 1);
    const cp = Math.cos(this.camPitch), sp = Math.sin(this.camPitch);
    let cx = this.camTarget.x + Math.sin(this.camYaw) * cp * dist;
    let cy = this.camTarget.y + sp * dist;
    let cz = this.camTarget.z + Math.cos(this.camYaw) * cp * dist;
    const g = this.terrain!.heightAt(cx, cz) + 0.55;
    if (cy < g) cy = g;
    if (this.loc.water) cy = Math.max(cy, this.loc.water.level + 0.4);
    this.shake = Math.max(0, this.shake - dt * 0.5);
    if (this.shake > 0 && !frozen) {
      cx += (Math.random() - 0.5) * this.shake;
      cy += (Math.random() - 0.5) * this.shake;
      cz += (Math.random() - 0.5) * this.shake;
    }
    cam.position.set(cx, cy, cz);
    cam.lookAt(this.camTarget);
    this.fovKick = lerp(this.fovKick, 0, Math.min(1, dt * 3));
    const fov = 60 + this.fovKick + (this.running_ ? 4 : 0);
    if (Math.abs(cam.fov - fov) > 0.05) {
      cam.fov = lerp(cam.fov, fov, Math.min(1, dt * 6));
      cam.updateProjectionMatrix();
    }
  }

  private syncHud() {
    const t = this.terrain!;
    const depth = Math.round(t.depthAt(this.tgt.x, this.tgt.z) * 10) / 10;
    const layer = layerAtDepth(depth);
    let changed = false;
    if (hud.depth !== depth || hud.layer !== layer) { hud.depth = depth; hud.layer = layer; changed = true; }
    const msg = this.tgtOk ? "" : this.tgtMsg;
    if (hud.digMsg !== msg) { hud.digMsg = msg; hud.canDig = this.tgtOk; changed = true; }
    const dg = this.digT >= 0;
    if (hud.digging !== dg) { hud.digging = dg; changed = true; }
    if (ui.detector) changed = true;
    if (S.settings.showFps) changed = true;
    if (changed) emit();
  }

  private perf(dt: number) {
    this.frames++;
    this.frameAcc += dt;
    if (this.frameAcc >= 1.5) {
      const fps = this.frames / this.frameAcc;
      hud.fps = Math.round(fps);
      this.frames = 0;
      this.frameAcc = 0;
      if (S.settings.quality === "auto") {
        if (fps < 27 && this.pr > 0.6) {
          this.pr = Math.max(0.6, this.pr * 0.85);
          this.resize();
        } else if (fps > 57 && this.pr < this.prCap) {
          this.pr = Math.min(this.prCap, this.pr * 1.1);
          this.resize();
        }
      }
    }
  }

  // ---------------- icons / inspection ----------------
  private iconModel(id: string): TreasureModel {
    let m = this.iconModels.get(id);
    if (!m) {
      m = buildTreasure(TREASURE_MAP[id]);
      m.obj.scale.setScalar(1 / TREASURE_MAP[id].size);
      this.iconModels.set(id, m);
    }
    return m;
  }
  renderTo(canvas: HTMLCanvasElement, id: string, yaw: number, pitch = 0.55) {
    if (!this.renderer) return;
    const m = this.iconModel(id);
    const def = TREASURE_MAP[id];
    m.obj.rotation.set(0, yaw, 0);
    const dist = def.kind === "chest" || def.kind === "scepter" || def.kind === "relics" ? 2.5 : 2.2;
    this.renderObj(canvas, m.obj, dist, pitch);
  }
  renderObj(canvas: HTMLCanvasElement, obj: THREE.Object3D, dist: number, pitch: number) {
    const size = canvas.width;
    if (this.iconRT.width !== size) this.iconRT.setSize(size, size);
    obj.visible = true;
    this.iconScene.add(obj);
    this.iconCam.position.set(0, Math.sin(pitch) * dist, Math.cos(pitch) * dist);
    this.iconCam.lookAt(0, 0, 0);
    const r = this.renderer;
    const prevTM = r.toneMapping;
    const prevRT = r.getRenderTarget();
    const prevShadow = r.shadowMap.enabled;
    r.shadowMap.enabled = false;
    r.toneMapping = THREE.NoToneMapping;
    r.setRenderTarget(this.iconRT);
    r.setClearColor(0x000000, 0);
    r.clear();
    r.render(this.iconScene, this.iconCam);
    const buf = new Uint8Array(size * size * 4);
    r.readRenderTargetPixels(this.iconRT, 0, 0, size, size, buf);
    r.setRenderTarget(prevRT);
    r.toneMapping = prevTM;
    r.shadowMap.enabled = prevShadow;
    this.iconScene.remove(obj);
    const ctx = canvas.getContext("2d")!;
    const img = ctx.createImageData(size, size);
    for (let y = 0; y < size; y++) img.data.set(buf.subarray((size - 1 - y) * size * 4, (size - y) * size * 4), y * size * 4);
    ctx.putImageData(img, 0, 0);
  }
  shovelIcons = new Map<string, string>();
  getShovelIcon(id: string): string {
    const c = this.shovelIcons.get(id);
    if (c) return c;
    if (!this.started || !this.renderer) return "";
    const wrap = new THREE.Group();
    const g = buildShovel(id);
    g.position.y = 0.5;
    wrap.add(g);
    wrap.rotation.set(0, 0.5, 0.62);
    const cv = document.createElement("canvas");
    cv.width = cv.height = 192;
    this.renderObj(cv, wrap, 2.7, 0.15);
    const url = cv.toDataURL("image/png");
    this.shovelIcons.set(id, url);
    return url;
  }
  getIcon(id: string): string {
    const c = this.iconCache.get(id);
    if (c) return c;
    if (!this.started || !this.renderer) return "";
    const cv = document.createElement("canvas");
    cv.width = cv.height = 128;
    if (this.iconRT.width !== 128) this.iconRT.setSize(128, 128);
    this.renderTo(cv, id, 0.6, 0.6);
    const url = cv.toDataURL("image/png");
    this.iconCache.set(id, url);
    return url;
  }
  private pregenIcons() {
    const ids = TREASURES.map((t) => t.id).filter((id) => !this.iconCache.has(id));
    let i = 0;
    const step = () => {
      if (!this.running) return;
      for (let k = 0; k < 3 && i < ids.length; k++, i++) this.getIcon(ids[i]);
      if (i < ids.length) setTimeout(step, 30);
      else emit();
    };
    step();
  }
  bagFull() {
    return bagCount() >= derived().bag;
  }
}

export const engine = new Engine();

if (typeof window !== "undefined") (window as any).__deepdig = { engine, S, ui, hud };
