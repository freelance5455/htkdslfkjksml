import * as THREE from "three";
import { GameAudio } from "./audio";
import { Input, type Actions } from "./input";
import { loadSave, writeSave } from "./save";
import { Sim } from "./sim";
import { buildWorld, makeCharacter, syncShelfVisual, type WorldLayout } from "./world";
import type { DayReport, HudSnap } from "./types";

export type EngineHooks = {
  onHud: (h: HudSnap) => void;
  onToast: (text: string) => void;
  onDayEnd: (r: DayReport) => void;
  onRebuild?: () => void;
};

export type GameHandle = {
  sim: Sim;
  input: Input;
  audio: GameAudio;
  start: () => void;
  stop: () => void;
  dispose: () => void;
  setQuality: (q: "low" | "med" | "high") => void;
  rebuild: () => void;
};

const _f = new THREE.Vector3();
const _cam = new THREE.Vector3();
const _look = new THREE.Vector3();

export function createGame(canvas: HTMLCanvasElement, hooks: EngineHooks): GameHandle {
  const sim = new Sim(loadSave());
  const input = new Input();
  const audio = new GameAudio();
  audio.sfxVol = sim.s.settings.sfx;
  audio.musicVol = sim.s.settings.music;
  audio.applyVol();

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: sim.s.settings.quality !== "low",
    powerPreference: "high-performance",
    alpha: false,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, sim.s.settings.quality === "high" ? 2 : 1.5));
  renderer.setSize(canvas.clientWidth || 800, canvas.clientHeight || 450, false);
  renderer.shadowMap.enabled = sim.s.settings.quality !== "low";
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87a0b4);
  scene.fog = new THREE.Fog(0x87a0b4, 28, 72);

  const camera = new THREE.PerspectiveCamera(58, 16 / 9, 0.08, 120);
  camera.position.set(0, 4, 12);

  let world: WorldLayout = buildWorld(sim.s.storeLevel, sim.s.checkouts, sim.s.shelves);
  scene.add(world.group);
  sim.bindLayout({
    colliders: world.colliders,
    checkouts: world.checkouts,
    pallets: world.pallets,
    shelves: world.shelves,
    grid: world.grid,
    entrance: world.entrance,
    warehouseZone: world.warehouseZone,
    spawn: world.spawn,
    w: world.w,
    d: world.d,
  });

  const playerMesh = makeCharacter(0x2a3a42, 1, true);
  scene.add(playerMesh);

  const customerMeshes = new Map<number, THREE.Group>();
  const staffMeshes = new Map<number, THREE.Group>();

  const detachInput = input.attach(canvas);

  let running = false;
  let last = 0;
  let acc = 0;
  const FIXED = 1 / 60;
  let hudT = 0;
  let saveT = 0;
  let toastSeen = "";
  let lastReportDay = 0;
  let lastFoot = 0;

  const setQuality = (q: "low" | "med" | "high") => {
    sim.s.settings.quality = q;
    renderer.shadowMap.enabled = q !== "low";
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q === "high" ? 2 : q === "med" ? 1.5 : 1));
    const sun = world.lights.find((l) => l instanceof THREE.DirectionalLight) as THREE.DirectionalLight | undefined;
    if (sun?.shadow) sun.shadow.mapSize.set(q === "high" ? 1024 : 512, q === "high" ? 1024 : 512);
  };

  const rebuild = () => {
    scene.remove(world.group);
    world.dispose();
    world = buildWorld(sim.s.storeLevel, sim.s.checkouts, sim.s.shelves);
    scene.add(world.group);
    sim.bindLayout({
      colliders: world.colliders,
      checkouts: world.checkouts,
      pallets: world.pallets,
      shelves: world.shelves,
      grid: world.grid,
      entrance: world.entrance,
      warehouseZone: world.warehouseZone,
      spawn: world.spawn,
      w: world.w,
      d: world.d,
    });
    setQuality(sim.s.settings.quality);
  };

  const resize = () => {
    const w = canvas.clientWidth || 800;
    const h = canvas.clientHeight || 450;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(canvas);

  const syncActors = () => {
    const seenC = new Set<number>();
    for (const c of sim.customers) {
      seenC.add(c.id);
      let m = customerMeshes.get(c.id);
      if (!m) {
        m = makeCharacter(c.color, c.scale);
        customerMeshes.set(c.id, m);
        scene.add(m);
      }
      m.position.set(c.x, 0, c.z);
      m.rotation.y = c.yaw;
      bob(m, c.anim, c.state === "queue" || c.state === "take" ? 0 : 1);
      const hold = m.getObjectByName("hold");
      if (hold) hold.visible = c.cart.length > 0;
    }
    for (const [id, m] of customerMeshes) {
      if (!seenC.has(id)) {
        scene.remove(m);
        customerMeshes.delete(id);
      }
    }
    const seenS = new Set<number>();
    for (const e of sim.s.staff) {
      seenS.add(e.id);
      let m = staffMeshes.get(e.id);
      if (!m) {
        m = makeCharacter(roleColor(e.role), 1, e.role === "cashier");
        staffMeshes.set(e.id, m);
        scene.add(m);
      }
      m.position.set(e.x, 0, e.z);
      m.rotation.y = e.yaw;
      bob(m, e.anim, e.path.length ? 1 : 0);
      const hold = m.getObjectByName("hold");
      if (hold) hold.visible = !!e.holding;
    }
    for (const [id, m] of staffMeshes) {
      if (!seenS.has(id)) {
        scene.remove(m);
        staffMeshes.delete(id);
      }
    }
    for (const sh of sim.s.shelves) syncShelfVisual(sh, world.productBoxes.get(sh.id));
  };

  const updateCamera = (dt: number, actions: Actions) => {
    const look = input.consumeLook();
    sim.camYaw -= look.x * 0.0024;
    sim.camPitch -= look.y * 0.0022;
    sim.camPitch = Math.max(-1.05, Math.min(-0.08, sim.camPitch));
    void actions;

    const p = sim.s.player;
    playerMesh.position.set(p.x, 0, p.z);
    playerMesh.rotation.y = p.yaw;
    bob(playerMesh, sim.footT, sim.speed > 0.2 ? 1 : 0);
    const hold = playerMesh.getObjectByName("hold");
    if (hold) hold.visible = !!p.holding;

    const fy = -Math.sin(sim.camYaw);
    const fz = -Math.cos(sim.camYaw);
    _f.set(fy, 0, fz);
    const dist = 6.4;
    const height = 3.15;
    _cam.set(p.x - _f.x * dist, height, p.z - _f.z * dist);
    _cam.y += Math.sin(sim.camPitch + 0.4) * 0.2;
    const k = 1 - Math.exp(-8 * dt);
    camera.position.lerp(_cam, k);
    _look.set(p.x, 1.35, p.z);
    camera.lookAt(_look);

    if (sim.s.settings.shake && sim.trauma > 0.02) {
      const s = sim.trauma * sim.trauma;
      camera.position.x += (Math.random() - 0.5) * s * 0.18;
      camera.position.y += (Math.random() - 0.5) * s * 0.12;
    }
  };

  const lighting = () => {
    const h = sim.s.timeOfDay;
    const day = h > 6 && h < 20;
    const dusk = h > 17 && h < 19.5 ? (h - 17) / 2.5 : h >= 19.5 ? 1 : 0;
    const sky = day ? new THREE.Color().lerpColors(new THREE.Color(0x87a0b4), new THREE.Color(0x1a2230), dusk) : new THREE.Color(0x0d1218);
    scene.background = sky;
    if (scene.fog) scene.fog.color.copy(sky);
    const sun = world.lights.find((l) => l instanceof THREE.DirectionalLight) as THREE.DirectionalLight | undefined;
    if (sun) sun.intensity = day ? 1.15 * (1 - dusk * 0.75) : 0.08;
    const outage = sim.s.event?.kind === "outage" || sim.s.event?.kind === "fire";
    for (const l of world.lights) {
      if (l instanceof THREE.PointLight) l.intensity = outage ? 0.15 : 2.2 + sim.s.lights * 0.4;
    }
    renderer.toneMappingExposure = outage ? 0.45 : sim.s.event?.kind === "festival" ? 1.15 : 1.05;
  };

  const loop = (now: number) => {
    if (!running) return;
    if (!last) last = now;
    let dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    acc += dt;
    const actions = input.sample();
    let steps = 0;
    while (acc >= FIXED && steps < 5) {
      sim.step(FIXED, actions);
      acc -= FIXED;
      steps++;
    }
    updateCamera(dt, actions);
    syncActors();
    lighting();
    audio.tickMusic(dt);

    if (sim.speed > 0.4 && sim.footT - lastFoot > 0.42) {
      lastFoot = sim.footT;
      audio.step();
    }
    if (sim.toast && sim.toast.text !== toastSeen) {
      toastSeen = sim.toast.text;
      hooks.onToast(sim.toast.text);
      if (/Receipt|Scanned|Delivery/.test(sim.toast.text)) audio.register();
      else if (/Hired|Unlocked|Mission|Stocked/.test(sim.toast.text)) audio.coin();
      else if (/Fire|outage|thief|broke|left the queue/.test(sim.toast.text)) audio.error();
      else audio.chime();
    }
    if (sim.report && sim.report.day !== lastReportDay) {
      lastReportDay = sim.report.day;
      hooks.onDayEnd(sim.report);
    }

    hudT += dt;
    if (hudT > 0.08) {
      hudT = 0;
      hooks.onHud(sim.hud());
    }
    saveT += dt;
    if (saveT > 8) {
      saveT = 0;
      writeSave(sim.s);
    }
    renderer.render(scene, camera);
  };

  const onHide = () => {
    if (document.hidden) writeSave(sim.s);
    else if (audio.ctx?.state === "suspended") void audio.ctx.resume();
  };
  document.addEventListener("visibilitychange", onHide);

  const start = () => {
    if (running) return;
    running = true;
    last = 0;
    audio.unlock();
    renderer.setAnimationLoop(loop);
  };
  const stop = () => {
    running = false;
    renderer.setAnimationLoop(null);
  };

  const qa = new URLSearchParams(window.location.search).has("qa") || import.meta.env.DEV;
  if (qa) {
    (window as unknown as { __controlsTest: unknown }).__controlsTest = {
      getYaw: () => sim.s.player.yaw,
      getSpeed: () => sim.speed,
      getPos: () => ({ x: sim.s.player.x, z: sim.s.player.z }),
      setKeys: (codes: string[]) => input.setKeys(codes),
      setSteer: (v: number) => {
        if (v > 0.2) input.setKeys(["KeyW", "KeyA"]);
        else if (v < -0.2) input.setKeys(["KeyW", "KeyD"]);
        else input.setKeys(["KeyW"]);
      },
    };
  }

  renderer.render(scene, camera);

  return {
    sim,
    input,
    audio,
    start,
    stop,
    setQuality,
    rebuild,
    dispose: () => {
      stop();
      writeSave(sim.s);
      detachInput();
      ro.disconnect();
      document.removeEventListener("visibilitychange", onHide);
      world.dispose();
      renderer.dispose();
      audio.dispose();
      delete (window as unknown as { __controlsTest?: unknown }).__controlsTest;
    },
  };
}

function bob(g: THREE.Group, t: number, amp: number): void {
  const l = g.getObjectByName("legL");
  const r = g.getObjectByName("legR");
  if (l) l.rotation.x = Math.sin(t * 6) * 0.55 * amp;
  if (r) r.rotation.x = Math.sin(t * 6 + Math.PI) * 0.55 * amp;
  g.position.y = Math.abs(Math.sin(t * 6)) * 0.03 * amp;
}

function roleColor(role: string): number {
  switch (role) {
    case "cashier":
      return 0x3d6d6a;
    case "stocker":
      return 0x6a5a3a;
    case "cleaner":
      return 0x5a7a8a;
    case "security":
      return 0x2a3344;
    case "delivery":
      return 0x5a6a3a;
    default:
      return 0x4a3a5a;
  }
}
