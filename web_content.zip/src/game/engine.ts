import * as THREE from "three";
import {
  BLOCKS,
  CHUNK,
  WORLD_HEIGHT,
  WORLD_SIZE,
  World,
  buildChunkGeometry,
  createAtlasTexture,
  generateWorld,
  isSolid,
} from "./world";
import { buildStructure } from "./builds";
import type { BuildKind } from "./builds";

/* ------------------------------------------------------------------ */
/*  Controls                                                           */
/* ------------------------------------------------------------------ */
export type Action =
  | "forward"
  | "backward"
  | "left"
  | "right"
  | "jump"
  | "sneak"
  | "sprint"
  | "fly"
  | "attack"
  | "use"
  | "interact"
  | "store"
  | "settings"
  | "debug"
  | "hotbar1"
  | "hotbar2"
  | "hotbar3"
  | "hotbar4"
  | "hotbar5"
  | "hotbar6"
  | "hotbar7"
  | "hotbar8"
  | "hotbar9";

export const ACTION_LIST: { id: Action; label: string; group: string }[] = [
  { id: "forward", label: "Move Forward", group: "Movement" },
  { id: "backward", label: "Move Backward", group: "Movement" },
  { id: "left", label: "Strafe Left", group: "Movement" },
  { id: "right", label: "Strafe Right", group: "Movement" },
  { id: "jump", label: "Jump / Swim Up", group: "Movement" },
  { id: "sneak", label: "Sneak / Descend", group: "Movement" },
  { id: "sprint", label: "Sprint", group: "Movement" },
  { id: "fly", label: "Toggle Fly", group: "Movement" },
  { id: "attack", label: "Attack / Break / Fire", group: "Combat" },
  { id: "use", label: "Place Block / Use", group: "Combat" },
  { id: "interact", label: "Enter / Exit Vehicle", group: "Combat" },
  { id: "store", label: "Open Store", group: "Interface" },
  { id: "settings", label: "Open Settings", group: "Interface" },
  { id: "debug", label: "Debug Overlay", group: "Interface" },
  { id: "hotbar1", label: "Hotbar Slot 1", group: "Hotbar" },
  { id: "hotbar2", label: "Hotbar Slot 2", group: "Hotbar" },
  { id: "hotbar3", label: "Hotbar Slot 3", group: "Hotbar" },
  { id: "hotbar4", label: "Hotbar Slot 4", group: "Hotbar" },
  { id: "hotbar5", label: "Hotbar Slot 5", group: "Hotbar" },
  { id: "hotbar6", label: "Hotbar Slot 6", group: "Hotbar" },
  { id: "hotbar7", label: "Hotbar Slot 7", group: "Hotbar" },
  { id: "hotbar8", label: "Hotbar Slot 8", group: "Hotbar" },
  { id: "hotbar9", label: "Hotbar Slot 9", group: "Hotbar" },
];

export const DEFAULT_KEYMAP: Record<Action, string> = {
  forward: "KeyW",
  backward: "KeyS",
  left: "KeyA",
  right: "KeyD",
  jump: "Space",
  sneak: "ShiftLeft",
  sprint: "ControlLeft",
  fly: "KeyF",
  attack: "Mouse0",
  use: "Mouse2",
  interact: "KeyE",
  store: "KeyB",
  settings: "KeyO",
  debug: "F3",
  hotbar1: "Digit1",
  hotbar2: "Digit2",
  hotbar3: "Digit3",
  hotbar4: "Digit4",
  hotbar5: "Digit5",
  hotbar6: "Digit6",
  hotbar7: "Digit7",
  hotbar8: "Digit8",
  hotbar9: "Digit9",
};

export function prettyKey(code: string): string {
  if (code.startsWith("Mouse")) return `MOUSE ${code.slice(5)}`;
  if (code.startsWith("Key")) return code.slice(3);
  if (code.startsWith("Digit")) return code.slice(5);
  if (code.startsWith("Arrow")) return code.slice(5).toUpperCase();
  if (code === "Space") return "SPACE";
  if (code === "ShiftLeft") return "L-SHIFT";
  if (code === "ShiftRight") return "R-SHIFT";
  if (code === "ControlLeft") return "L-CTRL";
  if (code === "ControlRight") return "R-CTRL";
  return code.toUpperCase();
}

export interface GameSettings {
  sensitivity: number;
  fov: number;
  renderScale: number;
  hudScale: number;
  invertY: boolean;
  showDebug: boolean;
}

export const DEFAULT_SETTINGS: GameSettings = {
  sensitivity: 1,
  fov: 72,
  renderScale: 1,
  hudScale: 1,
  invertY: false,
  showDebug: true,
};

export interface GameState {
  health: number;
  armour: number;
  coins: number;
  ammo: number;
  rockets: number;
  slot: number;
  hotbar: string[];
  vehicle: string | null;
  speed: number;
  altitude: number;
  flying: boolean;
  fps: number;
  x: number;
  y: number;
  z: number;
  dead: boolean;
  messages: { id: number; text: string }[];
}

type VehicleType = "car" | "bus" | "truck" | "plane";

interface Vehicle {
  type: VehicleType;
  group: THREE.Group;
  pos: THREE.Vector3;
  yaw: number;
  speed: number;
  vspeed: number;
  wheels: THREE.Object3D[];
  prop?: THREE.Object3D;
}

interface Rocket {
  mesh: THREE.Object3D;
  vel: THREE.Vector3;
  life: number;
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

/* ------------------------------------------------------------------ */

export class Game {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private world: World;
  private chunkMeshes = new Map<string, THREE.Mesh>();
  private terrainMaterial: THREE.MeshLambertMaterial;

  private keymap: Record<Action, string>;
  private settings: GameSettings;
  private onState: (s: GameState) => void;
  private onPause: (reason: "pause" | "store" | "settings") => void;

  private keys = new Set<string>();
  private actionState = new Set<Action>();
  private paused = false;
  private raf = 0;
  private last = performance.now();
  private fpsAcc = 0;
  private fpsCount = 0;
  private fps = 60;
  private stateTimer = 0;
  private clockTime = 0;

  private pos = new THREE.Vector3(WORLD_SIZE / 2, 40, WORLD_SIZE / 2);
  private vel = new THREE.Vector3();
  private yaw = 0;
  private pitch = 0;
  private onGround = false;
  private flying = false;
  private health = 100;
  private armour = 0;
  private coins = 12000;
  private ammo = 240;
  private rockets = 12;
  private dead = false;
  private fallStart = 0;
  private bob = 0;

  private hotbar: string[] = [
    "block:3",
    "block:8",
    "block:9",
    "sword",
    "rifle",
    "bazooka",
    "armour",
    "",
    "",
  ];
  private slot = 3;

  private vehicles: Vehicle[] = [];
  private driving: Vehicle | null = null;
  private orbitYaw = 0;

  private viewModel = new THREE.Group();
  private vmSwing = 0;
  private vmRecoil = 0;
  private muzzle: THREE.PointLight;
  private muzzleTimer = 0;

  private rocketsFlying: Rocket[] = [];
  private flashes: { mesh: THREE.Mesh; life: number }[] = [];
  private tracers: { mesh: THREE.Mesh; life: number }[] = [];
  private shake = 0;
  private gunCooldown = 0;

  private particles: THREE.Points;
  private pPos: Float32Array;
  private pVel: Float32Array;
  private pLife: Float32Array;
  private pColor: Float32Array;
  private pCursor = 0;
  private static readonly P_MAX = 1200;

  private clouds = new THREE.Group();
  private msgId = 1;
  private messages: { id: number; text: string }[] = [];

  constructor(
    container: HTMLElement,
    opts: {
      onState: (s: GameState) => void;
      onPause: (reason: "pause" | "store" | "settings") => void;
      keymap: Record<Action, string>;
      settings: GameSettings;
    },
  ) {
    this.container = container;
    this.onState = opts.onState;
    this.onPause = opts.onPause;
    this.keymap = { ...opts.keymap };
    this.settings = { ...opts.settings };

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(
      Math.min(window.devicePixelRatio || 1, 2) * this.settings.renderScale,
    );
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    container.appendChild(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(
      this.settings.fov,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.08,
      420,
    );
    this.camera.rotation.order = "YXZ";

    this.scene.background = new THREE.Color(0x8ab8ff);
    this.scene.fog = new THREE.Fog(0x8ab8ff, 72, 240);

    const hemi = new THREE.HemisphereLight(0xa8cdff, 0x4c5f3c, 0.62);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xfff0cf, 0.88);
    sun.position.set(60, 110, 40);
    this.scene.add(sun);

    this.world = generateWorld();

    const atlas = createAtlasTexture();
    this.terrainMaterial = new THREE.MeshLambertMaterial({
      map: atlas,
      vertexColors: true,
    });

    const chunksPerSide = Math.ceil(WORLD_SIZE / CHUNK);
    for (let cx = 0; cx < chunksPerSide; cx++) {
      for (let cz = 0; cz < chunksPerSide; cz++) {
        this.rebuildChunk(cx, cz);
      }
    }

    // clouds
    const cloudMat = new THREE.MeshLambertMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.92,
    });
    const cloudGeo = new THREE.BoxGeometry(14, 3, 9);
    for (let i = 0; i < 46; i++) {
      const m = new THREE.Mesh(cloudGeo, cloudMat);
      m.position.set(
        Math.random() * 260 - 130,
        52 + Math.random() * 10,
        Math.random() * 260 - 130,
      );
      m.scale.set(0.7 + Math.random(), 1, 0.7 + Math.random() * 1.4);
      this.clouds.add(m);
    }
    this.scene.add(this.clouds);

    // particles
    const N = Game.P_MAX;
    this.pPos = new Float32Array(N * 3);
    this.pVel = new Float32Array(N * 3);
    this.pLife = new Float32Array(N);
    this.pColor = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) this.pPos[i * 3 + 1] = -1000;
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute("position", new THREE.BufferAttribute(this.pPos, 3));
    pGeo.setAttribute("color", new THREE.BufferAttribute(this.pColor, 3));
    this.particles = new THREE.Points(
      pGeo,
      new THREE.PointsMaterial({
        size: 0.24,
        vertexColors: true,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
      }),
    );
    this.scene.add(this.particles);

    // viewmodel
    this.camera.add(this.viewModel);
    this.scene.add(this.camera);
    this.muzzle = new THREE.PointLight(0xffcc77, 0, 14);
    this.camera.add(this.muzzle);
    this.muzzle.position.set(0.35, -0.2, -1.1);

    const spawnY = this.world.heightAt(WORLD_SIZE / 2, WORLD_SIZE / 2);
    this.pos.set(WORLD_SIZE / 2 + 0.5, spawnY + 0.2, WORLD_SIZE / 2 + 0.5);

    this.buildViewModel();
    this.bindEvents();
    this.message("World loaded — press B for the Store, O for Settings.");
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.tick);
    this.emit();
  }

  /* ---------------- chunk meshing ---------------- */
  private rebuildChunk(cx: number, cz: number) {
    const key = `${cx},${cz}`;
    const existing = this.chunkMeshes.get(key);
    if (existing) {
      this.scene.remove(existing);
      existing.geometry.dispose();
      this.chunkMeshes.delete(key);
    }
    if (cx < 0 || cz < 0 || cx >= WORLD_SIZE / CHUNK || cz >= WORLD_SIZE / CHUNK) return;
    const geo = buildChunkGeometry(this.world, cx, cz);
    const mesh = new THREE.Mesh(geo, this.terrainMaterial);
    mesh.frustumCulled = true;
    this.chunkMeshes.set(key, mesh);
    this.scene.add(mesh);
  }

  private flushDirty() {
    if (this.world.dirty.size === 0) return;
    const keys = Array.from(this.world.dirty);
    this.world.dirty.clear();
    for (const key of keys) {
      const [cx, cz] = key.split(",").map(Number);
      this.rebuildChunk(cx, cz);
    }
  }

  /* ---------------- events ---------------- */
  private onKeyDown = (e: KeyboardEvent) => {
    if (e.code === "F3" || e.code.startsWith("Digit") || e.code === "Space") e.preventDefault();
    if (this.paused) return;
    this.keys.add(e.code);
    const action = this.actionForCode(e.code);
    if (action) this.handleAction(action, true);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
    const action = this.actionForCode(e.code);
    if (action) this.handleAction(action, false);
  };
  private onMouseMove = (e: MouseEvent) => {
    if (this.paused) return;
    if (document.pointerLockElement !== this.container) return;
    const s = this.settings.sensitivity * 0.0022;
    if (this.driving) {
      this.orbitYaw = clamp(this.orbitYaw - e.movementX * s, -1.15, 1.15);
      return;
    }
    this.yaw -= e.movementX * s;
    this.pitch -= e.movementY * s * (this.settings.invertY ? -1 : 1);
    this.pitch = clamp(this.pitch, -1.53, 1.53);
  };
  private onMouseDown = (e: MouseEvent) => {
    if (this.paused) return;
    if (document.pointerLockElement !== this.container) {
      this.requestLock();
      return;
    }
    e.preventDefault();
    const action: Action = e.button === 2 ? "use" : "attack";
    this.handleAction(action, true);
  };
  private onMouseUp = (e: MouseEvent) => {
    const action: Action = e.button === 2 ? "use" : "attack";
    this.handleAction(action, false);
  };
  private onWheel = (e: WheelEvent) => {
    if (this.paused) return;
    this.setSlot((this.slot + (e.deltaY > 0 ? 1 : -1) + 9) % 9);
  };
  private onContext = (e: Event) => e.preventDefault();
  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };
  private onLockChange = () => {
    if (document.pointerLockElement !== this.container && !this.paused) {
      this.paused = true;
      this.keys.clear();
      this.actionState.clear();
      this.onPause("pause");
    }
  };

  private bindEvents() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("mousemove", this.onMouseMove);
    window.addEventListener("mouseup", this.onMouseUp);
    window.addEventListener("resize", this.onResize);
    document.addEventListener("pointerlockchange", this.onLockChange);
    this.container.addEventListener("mousedown", this.onMouseDown);
    this.container.addEventListener("contextmenu", this.onContext);
    this.container.addEventListener("wheel", this.onWheel, { passive: true });
  }

  private actionForCode(code: string): Action | null {
    for (const a of ACTION_LIST) {
      if (this.keymap[a.id] === code) return a.id;
    }
    return null;
  }

  /* ---------------- public API ---------------- */
  setPaused(v: boolean) {
    this.paused = v;
    this.keys.clear();
    this.actionState.clear();
    if (!v) this.last = performance.now();
  }
  requestLock() {
    setTimeout(() => {
      try {
        this.container.requestPointerLock();
      } catch {
        /* ignore */
      }
    }, 130);
  }
  setKeymap(km: Record<Action, string>) {
    this.keymap = { ...km };
  }
  setSettings(s: GameSettings) {
    this.settings = { ...s };
    this.camera.fov = s.fov;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2) * s.renderScale);
    this.onResize();
  }
  setSlot(i: number) {
    this.slot = clamp(i, 0, 8);
    this.buildViewModel();
    this.emit();
  }
  give(itemId: string): boolean {
    if (itemId === "ammo") {
      this.ammo += 120;
      this.message("+120 rifle rounds");
      this.emit();
      return true;
    }
    if (itemId === "rockets") {
      this.rockets += 8;
      this.message("+8 bazooka rockets");
      this.emit();
      return true;
    }
    const idx = this.hotbar.indexOf(itemId);
    if (idx >= 0) {
      this.setSlot(idx);
      return true;
    }
    const free = this.hotbar.indexOf("");
    if (free < 0) {
      this.message("Hotbar full — select a slot to replace first.");
      return false;
    }
    this.hotbar[free] = itemId;
    this.setSlot(free);
    return true;
  }
  setSlotItem(itemId: string) {
    this.hotbar[this.slot] = itemId;
    this.buildViewModel();
    this.emit();
  }
  heal() {
    this.health = 100;
    this.dead = false;
    this.emit();
  }
  setCoins(v: number) {
    this.coins = v;
    this.emit();
  }
  spend(n: number): boolean {
    if (this.coins < n) return false;
    this.coins -= n;
    this.emit();
    return true;
  }
  spawnVehicle(type: VehicleType) {
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const p = this.pos.clone().add(forward.multiplyScalar(9));
    const x = clamp(p.x, 8, WORLD_SIZE - 8);
    const z = clamp(p.z, 8, WORLD_SIZE - 8);
    const y = this.world.heightAt(x, z);
    const v = this.createVehicle(type);
    v.pos.set(x, y + 0.1, z);
    v.yaw = this.yaw + Math.PI;
    v.group.position.copy(v.pos);
    v.group.rotation.y = v.yaw;
    this.scene.add(v.group);
    this.vehicles.push(v);
    this.message(`${type.toUpperCase()} spawned — press ${prettyKey(this.keymap.interact)} to drive`);
    this.emit();
    return v;
  }
  buildAt(kind: BuildKind) {
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const target = this.pos.clone().add(forward.multiplyScalar(kind === "highway" ? 6 : 24));
    const done = buildStructure(this.world, kind, target.x, target.z);
    this.flushDirty();
    this.spawnParticles(done.x, done.y + 2, done.z, "#e8c24a", 220, 14, 6);
    this.shake = 0.6;
    this.message(
      kind === "highway"
        ? "Highway built — 105 blocks of four-lane road."
        : `${kind === "mansion" ? "Mansion" : "Bungalow"} built ahead of you.`,
    );
    this.emit();
    return done;
  }
  setVirtualKey(action: Action, down: boolean) {
    this.handleAction(action, down);
  }
  lookDelta(dx: number, dy: number) {
    const s = this.settings.sensitivity * 0.0045;
    if (this.driving) {
      this.orbitYaw = clamp(this.orbitYaw - dx * s, -1.15, 1.15);
      return;
    }
    this.yaw -= dx * s;
    this.pitch = clamp(this.pitch - dy * s, -1.53, 1.53);
  }

  private message(text: string) {
    this.messages = [...this.messages, { id: this.msgId++, text }].slice(-5);
  }

  /* ---------------- actions ---------------- */
  private handleAction(action: Action, down: boolean) {
    if (down) this.actionState.add(action);
    else this.actionState.delete(action);

    if (!down) {
      if (action === "attack") this.attacking = false;
      return;
    }
    switch (action) {
      case "fly":
        this.flying = !this.flying;
        this.vel.y = 0;
        this.message(this.flying ? "Fly mode ON" : "Fly mode OFF");
        break;
      case "interact":
        this.toggleVehicle();
        break;
      case "attack":
        this.attacking = true;
        this.primary();
        break;
      case "use":
        this.secondary();
        break;
      case "store":
        this.onPause("store");
        break;
      case "settings":
        this.onPause("settings");
        break;
      case "debug":
        this.settings.showDebug = !this.settings.showDebug;
        break;
      default:
        if (action.startsWith("hotbar")) {
          this.setSlot(Number(action.slice(6)) - 1);
        }
        break;
    }
  }

  private attacking = false;

  /* ---------------- vehicles ---------------- */
  private createVehicle(type: VehicleType): Vehicle {
    const group = new THREE.Group();
    const wheels: THREE.Object3D[] = [];
    const mat = (color: number, extra: THREE.MeshLambertMaterialParameters = {}) =>
      new THREE.MeshLambertMaterial({ color, ...extra });
    const add = (
      w: number,
      h: number,
      d: number,
      m: THREE.Material,
      x: number,
      y: number,
      z: number,
    ) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
      mesh.position.set(x, y, z);
      group.add(mesh);
      return mesh;
    };
    const wheel = (x: number, y: number, z: number, r = 0.46, w = 0.36) => {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 14), mat(0x1b1b1b));
      m.rotation.z = Math.PI / 2;
      m.position.set(x, y, z);
      group.add(m);
      wheels.push(m);
      return m;
    };
    const glass = mat(0x9fd8ff, { transparent: true, opacity: 0.75 });

    if (type === "car") {
      const body = mat(0xc0392b);
      add(2.0, 0.8, 4.4, body, 0, 0.9, 0);
      add(1.86, 0.8, 2.1, body, 0, 1.62, -0.2);
      add(1.72, 0.62, 0.12, glass, 0, 1.68, -1.26);
      add(1.72, 0.62, 0.12, glass, 0, 1.68, 0.86);
      add(1.9, 0.14, 4.2, mat(0x8e2b20), 0, 1.34, 0);
      add(0.42, 0.22, 0.16, mat(0xfff2c0), -0.68, 1.02, -2.2);
      add(0.42, 0.22, 0.16, mat(0xfff2c0), 0.68, 1.02, -2.2);
      wheel(-1.04, 0.5, -1.45);
      wheel(1.04, 0.5, -1.45);
      wheel(-1.04, 0.5, 1.45);
      wheel(1.04, 0.5, 1.45);
    } else if (type === "bus") {
      const body = mat(0xf2b21e);
      add(2.5, 2.6, 9.2, body, 0, 1.75, 0);
      add(2.56, 1.0, 7.4, glass, 0, 2.35, -0.3);
      add(2.56, 1.0, 0.12, glass, 0, 2.35, -4.62);
      add(2.42, 0.26, 8.8, mat(0xd99b12), 0, 3.15, 0);
      add(2.6, 0.5, 9.2, mat(0x2b2b2b), 0, 0.62, 0);
      add(0.3, 0.3, 0.16, mat(0xfff2c0), -0.95, 1.15, -4.62);
      add(0.3, 0.3, 0.16, mat(0xfff2c0), 0.95, 1.15, -4.62);
      wheel(-1.28, 0.52, -3.3);
      wheel(1.28, 0.52, -3.3);
      wheel(-1.28, 0.52, 2.7);
      wheel(1.28, 0.52, 2.7);
      wheel(-1.28, 0.52, 3.9);
      wheel(1.28, 0.52, 3.9);
    } else if (type === "truck") {
      add(2.6, 0.36, 9.6, mat(0x2b2b2b), 0, 0.78, 0);
      add(2.5, 2.3, 2.9, mat(0x2f5aa8), 0, 1.95, -3.3);
      add(2.3, 0.9, 0.12, glass, 0, 2.55, -4.78);
      add(2.7, 3.0, 6.4, mat(0xb9bcc2), 0, 2.3, 1.4);
      add(2.72, 0.2, 6.42, mat(0x8b8e94), 0, 3.85, 1.4);
      add(0.36, 0.3, 0.16, mat(0xfff2c0), -0.95, 1.35, -4.78);
      add(0.36, 0.3, 0.16, mat(0xfff2c0), 0.95, 1.35, -4.78);
      wheel(-1.32, 0.56, -3.4);
      wheel(1.32, 0.56, -3.4);
      wheel(-1.32, 0.56, 1.1);
      wheel(1.32, 0.56, 1.1);
      wheel(-1.32, 0.56, 2.5);
      wheel(1.32, 0.56, 2.5);
    } else {
      const white = mat(0xe9edf2);
      add(1.7, 1.7, 8.4, white, 0, 1.7, 0);
      add(1.2, 1.2, 1.5, mat(0xd43a2a), 0, 1.7, -4.7);
      add(13, 0.28, 2.5, white, 0, 1.78, -0.2);
      add(5, 0.24, 1.5, white, 0, 2.1, 3.8);
      add(0.28, 1.9, 1.6, mat(0xd43a2a), 0, 2.95, 3.9);
      add(1.35, 0.62, 1.7, glass, 0, 2.5, -1.7);
      add(0.2, 3.0, 0.3, mat(0x2b2b2b), 0, 1.7, -5.5);
      wheel(-0.95, 0.5, -1.3, 0.42, 0.3);
      wheel(0.95, 0.5, -1.3, 0.42, 0.3);
      wheel(0, 0.5, 3.5, 0.42, 0.3);
      const prop = new THREE.Group();
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.22, 3.1, 0.16), mat(0x3a3a3a));
      const blade2 = new THREE.Mesh(new THREE.BoxGeometry(3.1, 0.22, 0.16), mat(0x3a3a3a));
      prop.add(blade, blade2);
      prop.position.set(0, 1.7, -5.75);
      group.add(prop);
      return { type, group, pos: new THREE.Vector3(), yaw: 0, speed: 0, vspeed: 0, wheels, prop };
    }
    return { type, group, pos: new THREE.Vector3(), yaw: 0, speed: 0, vspeed: 0, wheels };
  }

  private toggleVehicle() {
    if (this.driving) {
      const v = this.driving;
      const side = new THREE.Vector3(Math.cos(v.yaw), 0, -Math.sin(v.yaw));
      this.pos.copy(v.pos).add(side.multiplyScalar(3.2));
      this.pos.y = Math.max(this.pos.y, this.world.heightAt(this.pos.x, this.pos.z));
      this.vel.set(0, 0, 0);
      this.driving = null;
      this.message("Exited vehicle");
      this.emit();
      return;
    }
    let best: Vehicle | null = null;
    let bestDist = 8;
    for (const v of this.vehicles) {
      const d = v.pos.distanceTo(this.pos);
      if (d < bestDist) {
        bestDist = d;
        best = v;
      }
    }
    if (!best) {
      this.message("No vehicle nearby — buy one in the Store (B).");
      return;
    }
    this.driving = best;
    this.message(`Driving ${best.type.toUpperCase()}`);
    this.emit();
  }

  /* ---------------- combat ---------------- */
  private currentItem(): string {
    return this.hotbar[this.slot] ?? "";
  }

  private primary() {
    const item = this.currentItem();
    if (item === "rifle") {
      this.fireGun();
      return;
    }
    if (item === "bazooka") {
      this.fireRocket();
      return;
    }
    this.vmSwing = 1;
    const reach = item === "sword" ? 4.6 : 5;
    const hit = this.raycastBlocks(reach);
    if (hit) this.breakBlock(hit.x, hit.y, hit.z);
  }

  private secondary() {
    const item = this.currentItem();
    if (!item.startsWith("block:")) {
      this.vmSwing = 1;
      return;
    }
    const id = Number(item.split(":")[1]);
    const hit = this.raycastBlocks(6);
    if (!hit) return;
    const x = hit.x + hit.nx;
    const y = hit.y + hit.ny;
    const z = hit.z + hit.nz;
    // never place inside the player
    const px = this.pos.x;
    const py = this.pos.y;
    const pz = this.pos.z;
    const overlaps =
      x + 1 > px - 0.35 && x < px + 0.35 && y + 1 > py && y < py + 1.8 && z + 1 > pz - 0.35 && z < pz + 0.35;
    if (overlaps) return;
    if (this.world.get(x, y, z) !== 0) return;
    this.world.set(x, y, z, id);
    this.flushDirty();
    this.vmSwing = 1;
  }

  private fireGun() {
    if (this.gunCooldown > 0) return;
    if (this.ammo <= 0) {
      this.message("Out of ammo — buy Rifle Ammo in the Store.");
      return;
    }
    this.gunCooldown = 0.095;
    this.ammo--;
    this.vmRecoil = 1;
    this.muzzleTimer = 0.07;
    this.muzzle.intensity = 6;
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    dir.x += (Math.random() - 0.5) * 0.012;
    dir.y += (Math.random() - 0.5) * 0.012;
    dir.normalize();
    const hit = this.raycastBlocks(90, dir);
    const end = hit
      ? new THREE.Vector3(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5)
      : this.camera.position.clone().add(dir.clone().multiplyScalar(90));
    this.spawnTracer(end);
    if (hit) this.spawnParticles(end.x, end.y, end.z, "#ffd88a", 8, 5, 0.5);
    this.pitch += 0.0075;
  }

  private fireRocket() {
    if (this.rockets <= 0) {
      this.message("No rockets — buy Rockets in the Store.");
      return;
    }
    this.rockets--;
    this.vmRecoil = 1.6;
    this.shake = 0.35;
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    const g = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.17, 0.17, 1.1, 10),
      new THREE.MeshLambertMaterial({ color: 0x9aa2ad }),
    );
    body.rotation.x = Math.PI / 2;
    const tip = new THREE.Mesh(
      new THREE.ConeGeometry(0.2, 0.5, 10),
      new THREE.MeshLambertMaterial({ color: 0xd43a2a, emissive: 0x521006 }),
    );
    tip.rotation.x = -Math.PI / 2;
    tip.position.z = -0.75;
    g.add(body, tip);
    g.position.copy(this.camera.position).add(dir.clone().multiplyScalar(1.4));
    g.lookAt(g.position.clone().add(dir));
    this.scene.add(g);
    this.rocketsFlying.push({
      mesh: g,
      vel: dir.clone().multiplyScalar(52),
      life: 6,
    });
    this.emit();
  }

  private explode(p: THREE.Vector3, radius = 4.4) {
    const r = Math.ceil(radius);
    for (let dx = -r; dx <= r; dx++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dz = -r; dz <= r; dz++) {
          const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (d > radius) continue;
          const x = Math.floor(p.x) + dx;
          const y = Math.floor(p.y) + dy;
          const z = Math.floor(p.z) + dz;
          if (y < 1) continue;
          if (this.world.get(x, y, z) !== 0) this.world.set(x, y, z, 0);
        }
      }
    }
    this.flushDirty();
    this.spawnParticles(p.x, p.y, p.z, "#ffb347", 90, 17, 2.4);
    this.spawnParticles(p.x, p.y, p.z, "#6b6b6b", 60, 11, 2.2);
    this.spawnParticles(p.x, p.y, p.z, "#2b2b2b", 40, 8, 3);
    this.shake = 1.5;

    const flash = new THREE.Mesh(
      new THREE.SphereGeometry(1, 14, 10),
      new THREE.MeshBasicMaterial({
        color: 0xffb040,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    flash.position.copy(p);
    this.scene.add(flash);
    this.flashes.push({ mesh: flash, life: 0.32 });

    const dist = this.pos.distanceTo(p);
    if (dist < radius + 4) {
      this.damage(Math.max(0, 1 - dist / (radius + 4)) * 34);
    }
  }

  private damage(amount: number) {
    if (amount <= 0 || this.dead) return;
    const absorbed = this.armour > 0 ? amount * 0.6 : 0;
    this.armour = Math.max(0, this.armour - absorbed * 0.9);
    this.health -= amount - absorbed;
    if (this.health <= 0) {
      this.health = 0;
      this.dead = true;
      this.message("You died — respawning…");
      window.setTimeout(() => this.respawn(), 900);
    }
    this.emit();
  }

  private respawn() {
    const y = this.world.heightAt(WORLD_SIZE / 2, WORLD_SIZE / 2);
    this.pos.set(WORLD_SIZE / 2 + 0.5, y + 0.3, WORLD_SIZE / 2 + 0.5);
    this.vel.set(0, 0, 0);
    this.health = 100;
    this.dead = false;
    this.driving = null;
    this.flying = false;
    this.message("Respawned at world spawn.");
    this.emit();
  }

  private breakBlock(x: number, y: number, z: number) {
    const id = this.world.get(x, y, z);
    if (id === 0) return;
    const def = BLOCKS[id];
    this.world.set(x, y, z, 0);
    this.flushDirty();
    this.spawnParticles(x + 0.5, y + 0.5, z + 0.5, def.particle, 14, 4.2, 0.7);
    this.coins += 2;
    this.emit();
  }

  /* ---------------- rays & particles ---------------- */
  private raycastBlocks(
    maxDist: number,
    dirOverride?: THREE.Vector3,
  ): { x: number; y: number; z: number; nx: number; ny: number; nz: number } | null {
    const origin = this.camera.position;
    const dir = dirOverride ?? this.camera.getWorldDirection(new THREE.Vector3());
    let x = Math.floor(origin.x);
    let y = Math.floor(origin.y);
    let z = Math.floor(origin.z);
    const stepX = dir.x > 0 ? 1 : -1;
    const stepY = dir.y > 0 ? 1 : -1;
    const stepZ = dir.z > 0 ? 1 : -1;
    const tDeltaX = dir.x === 0 ? Infinity : Math.abs(1 / dir.x);
    const tDeltaY = dir.y === 0 ? Infinity : Math.abs(1 / dir.y);
    const tDeltaZ = dir.z === 0 ? Infinity : Math.abs(1 / dir.z);
    let tMaxX = dir.x === 0 ? Infinity : ((stepX > 0 ? x + 1 : x) - origin.x) / dir.x;
    let tMaxY = dir.y === 0 ? Infinity : ((stepY > 0 ? y + 1 : y) - origin.y) / dir.y;
    let tMaxZ = dir.z === 0 ? Infinity : ((stepZ > 0 ? z + 1 : z) - origin.z) / dir.z;
    let nx = 0;
    let ny = 0;
    let nz = 0;
    let t = 0;
    while (t <= maxDist) {
      if (isSolid(this.world.get(x, y, z))) {
        return { x, y, z, nx, ny, nz };
      }
      if (tMaxX < tMaxY && tMaxX < tMaxZ) {
        x += stepX;
        t = tMaxX;
        tMaxX += tDeltaX;
        nx = -stepX;
        ny = 0;
        nz = 0;
      } else if (tMaxY < tMaxZ) {
        y += stepY;
        t = tMaxY;
        tMaxY += tDeltaY;
        nx = 0;
        ny = -stepY;
        nz = 0;
      } else {
        z += stepZ;
        t = tMaxZ;
        tMaxZ += tDeltaZ;
        nx = 0;
        ny = 0;
        nz = -stepZ;
      }
      if (y < -1 || y > WORLD_HEIGHT + 2) return null;
    }
    return null;
  }

  private spawnTracer(end: THREE.Vector3) {
    const start = this.camera.position.clone();
    const dir = end.clone().sub(start);
    const len = dir.length();
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.07, 0.07, len),
      new THREE.MeshBasicMaterial({
        color: 0xffe9a8,
        transparent: true,
        opacity: 0.85,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    mesh.position.copy(start).add(end).multiplyScalar(0.5);
    mesh.lookAt(end);
    this.scene.add(mesh);
    this.tracers.push({ mesh, life: 0.09 });
  }

  private spawnParticles(
    x: number,
    y: number,
    z: number,
    color: string,
    count: number,
    speed: number,
    spread: number,
  ) {
    const c = new THREE.Color(color);
    for (let n = 0; n < count; n++) {
      const i = this.pCursor;
      this.pCursor = (this.pCursor + 1) % Game.P_MAX;
      this.pPos[i * 3] = x + (Math.random() - 0.5) * spread;
      this.pPos[i * 3 + 1] = y + (Math.random() - 0.5) * spread;
      this.pPos[i * 3 + 2] = z + (Math.random() - 0.5) * spread;
      const s = speed * (0.35 + Math.random() * 0.9);
      this.pVel[i * 3] = (Math.random() - 0.5) * s;
      this.pVel[i * 3 + 1] = Math.random() * s * 0.9 + 1.2;
      this.pVel[i * 3 + 2] = (Math.random() - 0.5) * s;
      this.pLife[i] = 0.7 + Math.random() * 1.1;
      this.pColor[i * 3] = c.r;
      this.pColor[i * 3 + 1] = c.g;
      this.pColor[i * 3 + 2] = c.b;
    }
  }

  /* ---------------- view model ---------------- */
  private buildViewModel() {
    while (this.viewModel.children.length) {
      const c = this.viewModel.children[0];
      this.viewModel.remove(c);
      if (c instanceof THREE.Mesh) {
        c.geometry.dispose();
        const m = c.material as THREE.MeshLambertMaterial;
        m.map?.dispose();
        m.dispose();
      }
    }
    const item = this.currentItem();
    const mat = (color: number, extra: THREE.MeshLambertMaterialParameters = {}) =>
      new THREE.MeshLambertMaterial({ color, ...extra });
    const add = (
      w: number,
      h: number,
      d: number,
      m: THREE.Material,
      x: number,
      y: number,
      z: number,
      rx = 0,
      ry = 0,
      rz = 0,
    ) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
      mesh.position.set(x, y, z);
      mesh.rotation.set(rx, ry, rz);
      this.viewModel.add(mesh);
      return mesh;
    };

    if (item === "sword") {
      add(0.07, 0.95, 0.16, mat(0xc8ccd8), 0, 0, 0, 0, 0, -0.42);
      add(0.1, 0.28, 0.34, mat(0x8b5a2b), -0.2, -0.48, 0, 0, 0, -0.42);
      add(0.12, 0.12, 0.4, mat(0xe8c24a), -0.28, -0.6, 0, 0, 0, -0.42);
    } else if (item === "rifle") {
      add(0.14, 0.16, 1.15, mat(0x31363f), 0, 0, -0.2);
      add(0.1, 0.1, 0.85, mat(0x22262d), 0, 0.01, -1.15);
      add(0.16, 0.34, 0.16, mat(0x31363f), 0, -0.22, -0.22);
      add(0.13, 0.3, 0.42, mat(0x4a3524), 0, -0.05, 0.62);
      add(0.12, 0.1, 0.2, mat(0x22262d), 0, 0.13, -0.5);
    } else if (item === "bazooka") {
      add(0.34, 0.34, 1.9, mat(0x3f5a3a), 0, 0, -0.35);
      add(0.42, 0.42, 0.22, mat(0x2b3a28), 0, 0, -1.32);
      add(0.2, 0.36, 0.2, mat(0x2b3a28), 0, -0.3, -0.1);
      add(0.12, 0.1, 0.3, mat(0xd43a2a), 0.02, 0.22, -0.72);
    } else if (item.startsWith("block:")) {
      const id = Number(item.split(":")[1]);
      const def = BLOCKS[id] ?? BLOCKS[3];
      const tileIndex = def.side;
      const tex = createAtlasTexture();
      const uvScale = new THREE.Vector2(1 / 4, 1 / 4);
      const col = tileIndex % 4;
      const row = Math.floor(tileIndex / 4);
      const m = new THREE.MeshLambertMaterial({ map: tex.clone() });
      const map = m.map!;
      map.repeat.copy(uvScale);
      map.offset.set(col / 4, 1 - (row + 1) / 4);
      map.needsUpdate = true;
      add(0.42, 0.42, 0.42, m, 0.02, -0.02, -0.55, 0.2, 0.7, 0.1);
    } else if (item === "armour") {
      add(0.42, 0.5, 0.22, mat(0x9aa7b8), 0, -0.04, -0.5, 0, 0.4, 0);
    }
    this.viewModel.position.set(0.34, -0.3, -0.42);
    this.viewModel.rotation.set(0, 0, 0);
    this.viewModel.scale.setScalar(1);
    if (item === "rifle") this.viewModel.position.set(0.3, -0.28, -0.5);
    if (item === "bazooka") this.viewModel.position.set(0.3, -0.26, -0.55);
    if (item === "sword") this.viewModel.position.set(0.42, -0.36, -0.6);
    if (item.startsWith("block:")) this.viewModel.position.set(0.5, -0.44, -0.62);
    if (item === "") this.viewModel.visible = false;
    else this.viewModel.visible = true;
  }

  /* ---------------- loop ---------------- */
  private tick = () => {
    this.raf = requestAnimationFrame(this.tick);
    const now = performance.now();
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.06) dt = 0.06;
    this.clockTime += dt;

    this.fpsAcc += dt;
    this.fpsCount++;
    if (this.fpsAcc > 0.5) {
      this.fps = Math.round(this.fpsCount / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsCount = 0;
    }

    if (!this.paused) {
      if (this.driving) this.updateVehicle(dt);
      else this.updatePlayer(dt);
      if (this.attacking && this.currentItem() === "rifle") this.fireGun();
    }
    this.updateWorldObjects(dt);
    this.updateCamera(dt);

    this.stateTimer += dt;
    if (this.stateTimer > 0.15) {
      this.stateTimer = 0;
      this.emit();
    }
    this.renderer.render(this.scene, this.camera);
  };

  private updatePlayer(dt: number) {
    const k = this.actionState;
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const wish = new THREE.Vector3();
    if (k.has("forward")) wish.add(forward);
    if (k.has("backward")) wish.sub(forward);
    if (k.has("right")) wish.add(right);
    if (k.has("left")) wish.sub(right);
    const moving = wish.lengthSq() > 0;
    if (moving) wish.normalize();

    const sprinting = k.has("sprint");
    const speed = (sprinting ? 8.2 : 4.7) * (this.flying ? 2.4 : 1);

    const head = Math.floor(this.pos.y + 1.2);
    const inWater =
      this.world.get(Math.floor(this.pos.x), head, Math.floor(this.pos.z)) === 5;

    if (this.flying) {
      this.vel.x = wish.x * speed;
      this.vel.z = wish.z * speed;
      this.vel.y = 0;
      if (k.has("jump")) this.vel.y = speed * 0.85;
      if (k.has("sneak")) this.vel.y = -speed * 0.85;
      this.pos.addScaledVector(this.vel, dt);
      this.pos.y = clamp(this.pos.y, 1, WORLD_HEIGHT + 26);
      this.onGround = false;
    } else {
      const accel = this.onGround ? 14 : 5.2;
      this.vel.x += (wish.x * speed - this.vel.x) * Math.min(1, accel * dt);
      this.vel.z += (wish.z * speed - this.vel.z) * Math.min(1, accel * dt);
      if (inWater) {
        const targetY = k.has("jump") ? 4.2 : -2.4;
        this.vel.y += (targetY - this.vel.y) * Math.min(1, 4 * dt);
        this.vel.y = clamp(this.vel.y, -3, 4.4);
      } else {
        this.vel.y -= 26 * dt;
        if (this.vel.y < -46) this.vel.y = -46;
        if (k.has("jump") && this.onGround) {
          this.vel.y = 8.6;
          this.onGround = false;
        }
      }
      const wasGround = this.onGround;
      this.onGround = false;
      this.moveWithCollision(dt);
      if (!wasGround && this.onGround) {
        const fall = this.fallStart - this.pos.y;
        if (fall > 4.2) this.damage((fall - 4.2) * 6.5);
        this.fallStart = this.pos.y;
      }
      if (this.onGround || inWater) this.fallStart = this.pos.y;
      else if (this.pos.y > this.fallStart) this.fallStart = this.pos.y;
    }

    if (this.pos.y < -6) {
      this.damage(100);
    }

    if (moving && this.onGround) this.bob += dt * (sprinting ? 13 : 9);
  }

  private moveWithCollision(dt: number) {
    const hw = 0.32;
    const height = 1.8;
    const move = this.vel.clone().multiplyScalar(dt);
    const collides = (p: THREE.Vector3) => {
      const x0 = Math.floor(p.x - hw);
      const x1 = Math.floor(p.x + hw);
      const y0 = Math.floor(p.y + 0.02);
      const y1 = Math.floor(p.y + height);
      const z0 = Math.floor(p.z - hw);
      const z1 = Math.floor(p.z + hw);
      for (let x = x0; x <= x1; x++) {
        for (let y = y0; y <= y1; y++) {
          for (let z = z0; z <= z1; z++) {
            if (isSolid(this.world.get(x, y, z))) return true;
          }
        }
      }
      return false;
    };
    const axes: Array<"x" | "y" | "z"> = ["y", "x", "z"];
    for (const axis of axes) {
      const before = this.pos[axis];
      this.pos[axis] += move[axis];
      if (collides(this.pos)) {
        this.pos[axis] = before;
        if (axis === "y") {
          if (move.y < 0) this.onGround = true;
          this.vel.y = 0;
        }
      }
    }
  }

  private updateVehicle(dt: number) {
    const v = this.driving;
    if (!v) return;
    const k = this.actionState;
    const maxSpeed =
      v.type === "plane" ? 64 : v.type === "car" ? 33 : v.type === "bus" ? 23 : 21;
    const accel = v.type === "plane" ? 16 : v.type === "car" ? 12 : 8;

    if (k.has("forward")) v.speed += accel * dt;
    else if (k.has("backward")) v.speed -= accel * dt;
    else v.speed *= 1 - Math.min(1, 1.1 * dt);
    v.speed = clamp(v.speed, -maxSpeed * 0.35, maxSpeed);

    const steer = (k.has("left") ? 1 : 0) - (k.has("right") ? 1 : 0);
    const steerPower = (1.25 - Math.min(Math.abs(v.speed) / 90, 0.55)) * Math.sign(v.speed || 1);
    v.yaw += steer * steerPower * dt * 1.15;

    const forward = new THREE.Vector3(-Math.sin(v.yaw), 0, -Math.cos(v.yaw));
    v.pos.addScaledVector(forward, v.speed * dt);

    const groundY = this.world.heightAt(v.pos.x, v.pos.z);
    if (v.type === "plane") {
      if (k.has("jump")) v.vspeed += 26 * dt;
      if (k.has("sneak")) v.vspeed -= 26 * dt;
      v.vspeed -= 7.5 * dt;
      v.vspeed *= 1 - Math.min(1, 0.7 * dt);
      v.pos.y += v.vspeed * dt;
      const floor = groundY + 1.2;
      if (v.pos.y < floor) {
        v.pos.y = floor;
        v.vspeed = Math.max(0, v.vspeed);
      }
      if (v.pos.y > WORLD_HEIGHT + 22) {
        v.pos.y = WORLD_HEIGHT + 22;
        v.vspeed = Math.min(0, v.vspeed);
      }
    } else {
      const target = groundY + 0.12;
      v.pos.y += (target - v.pos.y) * Math.min(1, dt * 9);
    }

    v.pos.x = clamp(v.pos.x, 2, WORLD_SIZE - 2);
    v.pos.z = clamp(v.pos.z, 2, WORLD_SIZE - 2);
    v.group.position.copy(v.pos);
    v.group.rotation.y = v.yaw;

    if (v.type === "plane") {
      v.group.rotation.x = clamp(-v.vspeed * 0.012, -0.45, 0.45);
      if (v.prop) v.prop.rotation.z += (6 + Math.abs(v.speed) * 0.6) * dt * 3;
      v.group.rotation.z += (steer * 0.22 - v.group.rotation.z) * Math.min(1, dt * 3);
    } else {
      for (const w of v.wheels) w.rotation.x += v.speed * dt * 1.7;
    }
    this.pos.copy(v.pos);
  }

  private updateWorldObjects(dt: number) {
    // particles
    const N = Game.P_MAX;
    for (let i = 0; i < N; i++) {
      if (this.pLife[i] <= 0) continue;
      this.pLife[i] -= dt;
      if (this.pLife[i] <= 0) {
        this.pPos[i * 3 + 1] = -1000;
        continue;
      }
      this.pVel[i * 3 + 1] -= 19 * dt;
      this.pPos[i * 3] += this.pVel[i * 3] * dt;
      this.pPos[i * 3 + 1] += this.pVel[i * 3 + 1] * dt;
      this.pPos[i * 3 + 2] += this.pVel[i * 3 + 2] * dt;
    }
    const posAttr = this.particles.geometry.getAttribute("position") as THREE.BufferAttribute;
    const colAttr = this.particles.geometry.getAttribute("color") as THREE.BufferAttribute;
    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;

    // rockets
    for (let i = this.rocketsFlying.length - 1; i >= 0; i--) {
      const r = this.rocketsFlying[i];
      r.life -= dt;
      r.mesh.position.addScaledVector(r.vel, dt);
      r.vel.y -= 3.2 * dt;
      const p = r.mesh.position;
      const hitBlock = isSolid(
        this.world.get(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)),
      );
      let hitVehicle = false;
      for (const v of this.vehicles) {
        if (v.pos.distanceTo(p) < 3.4) hitVehicle = true;
      }
      if (r.life <= 0 || hitBlock || hitVehicle || p.y < 0.4) {
        this.explode(p.clone());
        this.scene.remove(r.mesh);
        this.rocketsFlying.splice(i, 1);
      } else if (Math.random() < 0.75) {
        this.spawnParticles(p.x, p.y, p.z, "#c9c9c9", 2, 1.6, 0.2);
      }
    }

    // explosion flashes
    for (let i = this.flashes.length - 1; i >= 0; i--) {
      const f = this.flashes[i];
      f.life -= dt;
      const t = Math.max(0, f.life / 0.32);
      f.mesh.scale.setScalar(1 + (1 - t) * 6.5);
      (f.mesh.material as THREE.MeshBasicMaterial).opacity = t * 0.9;
      if (f.life <= 0) {
        this.scene.remove(f.mesh);
        f.mesh.geometry.dispose();
        this.flashes.splice(i, 1);
      }
    }

    // tracers
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const tr = this.tracers[i];
      tr.life -= dt;
      (tr.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, tr.life / 0.09) * 0.85;
      if (tr.life <= 0) {
        this.scene.remove(tr.mesh);
        tr.mesh.geometry.dispose();
        this.tracers.splice(i, 1);
      }
    }

    // cooldowns / timers
    if (this.gunCooldown > 0) this.gunCooldown -= dt;
    if (this.muzzleTimer > 0) {
      this.muzzleTimer -= dt;
      this.muzzle.intensity = Math.max(0, this.muzzleTimer / 0.07) * 6;
    } else {
      this.muzzle.intensity = 0;
    }
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 1.9);
    if (this.vmSwing > 0) this.vmSwing = Math.max(0, this.vmSwing - dt * 3.4);
    if (this.vmRecoil > 0) this.vmRecoil = Math.max(0, this.vmRecoil - dt * 5.5);

    // clouds drift
    this.clouds.position.x += dt * 1.15;
    if (this.clouds.position.x > 140) this.clouds.position.x = -140;

    // idle regen
    if (!this.dead && this.health < 100) this.health = Math.min(100, this.health + dt * 1.1);
  }

  private updateCamera(dt: number) {
    const vm = this.viewModel;
    const swing = this.vmSwing;
    const bobAmount = this.driving ? 0 : Math.min(1, this.bob) * 0.012;
    vm.position.y +=
      (Math.sin(this.bob * 2) * bobAmount - (vm.position.y - this.vmBaseY())) * Math.min(1, dt * 12);
    vm.rotation.x = -swing * 1.15 - this.vmRecoil * 0.16;
    vm.rotation.z = -swing * 0.65;
    vm.position.z = this.vmBaseZ() + this.vmRecoil * 0.16 + swing * 0.12;

    if (this.driving) {
      const v = this.driving;
      const back = new THREE.Vector3(-Math.sin(v.yaw), 0, -Math.cos(v.yaw)).multiplyScalar(-1);
      const dist = v.type === "plane" ? 17 : v.type === "bus" ? 15 : 11;
      const height = v.type === "plane" ? 6.5 : 5.2;
      const target = v.pos
        .clone()
        .add(back.multiplyScalar(dist))
        .add(new THREE.Vector3(0, height, 0));
      this.camera.position.lerp(target, 1 - Math.pow(0.0015, dt));
      const lookYaw = v.yaw + this.orbitYaw;
      const look = v.pos
        .clone()
        .add(new THREE.Vector3(-Math.sin(lookYaw), 0, -Math.cos(lookYaw)).multiplyScalar(6))
        .add(new THREE.Vector3(0, 2.2, 0));
      this.camera.lookAt(look);
      this.viewModel.visible = false;
    } else {
      this.viewModel.visible = this.currentItem() !== "";
      this.camera.position.set(this.pos.x, this.pos.y + 1.62, this.pos.z);
      this.camera.rotation.set(this.pitch, this.yaw, 0);
    }

    if (this.shake > 0) {
      const s = this.shake * 0.045;
      this.camera.rotation.x += (Math.random() - 0.5) * s;
      this.camera.rotation.y += (Math.random() - 0.5) * s;
      this.camera.rotation.z += (Math.random() - 0.5) * s * 0.6;
    }
  }

  private vmBaseY() {
    const item = this.currentItem();
    if (item === "sword") return -0.36;
    if (item === "rifle") return -0.28;
    if (item === "bazooka") return -0.26;
    if (item.startsWith("block:")) return -0.44;
    return -0.3;
  }
  private vmBaseZ() {
    const item = this.currentItem();
    if (item === "sword") return -0.6;
    if (item === "rifle") return -0.5;
    if (item === "bazooka") return -0.55;
    if (item.startsWith("block:")) return -0.62;
    return -0.42;
  }

  /* ---------------- state out ---------------- */
  private emit() {
    const v = this.driving;
    this.onState({
      health: Math.round(this.health),
      armour: Math.round(this.armour),
      coins: Math.round(this.coins),
      ammo: this.ammo,
      rockets: this.rockets,
      slot: this.slot,
      hotbar: [...this.hotbar],
      vehicle: v ? v.type : null,
      speed: v ? Math.abs(v.speed) * 3.6 : 0,
      altitude: v ? Math.round(v.pos.y) : Math.round(this.pos.y),
      flying: this.flying,
      fps: this.fps,
      x: Math.round(this.pos.x),
      y: Math.round(this.pos.y),
      z: Math.round(this.pos.z),
      dead: this.dead,
      messages: [...this.messages],
    });
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    window.removeEventListener("mouseup", this.onMouseUp);
    window.removeEventListener("resize", this.onResize);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    this.container.removeEventListener("mousedown", this.onMouseDown);
    this.container.removeEventListener("contextmenu", this.onContext);
    this.container.removeEventListener("wheel", this.onWheel);
    for (const mesh of this.chunkMeshes.values()) mesh.geometry.dispose();
    this.chunkMeshes.clear();
    this.terrainMaterial.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
