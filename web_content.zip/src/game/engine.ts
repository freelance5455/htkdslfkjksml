import * as THREE from 'three';
import {
  ADS_SPEED_MUL,
  BOT_COUNT,
  DROP_TIME,
  GRAVITY,
  JUMP_V,
  MAX_MEDS,
  MED_HEAL,
  MOUSE_SENS,
  PLAYER_MAX_HP,
  PLAYER_RADIUS,
  SPRINT_SPEED,
  WALK_SPEED,
} from './constants';
import { Sfx } from './audio';
import { Input, type InputFrame } from './input';
import { Fx } from './fx';
import { World } from './world';
import { Zone } from './zone';
import { Fighter } from './fighter';
import { Bot, type BotEnv } from './bot';
import { RESERVE_CAP, WEAPONS, type AmmoType, type WeaponDef, type WeaponId } from './weapons';
import { buildLootMesh, lootName, randomLootKind, type LootItem, type LootKind } from './loot';
import { recordMatch } from './storage';
import type { Outfit } from './humanoid';
import type { FeedItem, HudState, MatchResult, Phase } from './types';

const BOT_NAMES = ['Viper', 'Nova', 'Blaze', 'Shadow', 'Rex', 'Ghost', 'Titan', 'Frost', 'Kairo', 'Raven', 'Jett', 'Orion', 'Mako', 'Sable', 'Drift'];
const BOT_OUTFITS: Outfit[] = [
  { shirt: 0x2f5d3a, pants: 0x3b3228, skin: 0xd9a77e, helmet: 0x4a5a2a, vest: 0x222622 },
  { shirt: 0x8c2f2f, pants: 0x1f2a3a, skin: 0xc68e62, helmet: 0x1d1d1d, vest: 0x2a2a2a },
  { shirt: 0x3b4c6b, pants: 0x2a2f36, skin: 0x8d5a3b, helmet: 0x6b5b3a, vest: 0x1c1f24 },
  { shirt: 0x6d6a4f, pants: 0x3a3a2e, skin: 0xe8b98f, helmet: 0x3d4a2a, vest: 0x2b2e26 },
  { shirt: 0x4a2c5e, pants: 0x191b20, skin: 0xa86f4f, helmet: 0x2a0e3a, vest: 0x262626 },
  { shirt: 0x1f4f4a, pants: 0x3a2f24, skin: 0xf0c9a6, helmet: 0x9a8a5b, vest: 0x1f2a2a },
];
const PLAYER_OUTFIT: Outfit = { shirt: 0xf97316, pants: 0x1f2937, skin: 0xe0b08a, helmet: 0xfbbf24, vest: 0x1e293b };
const DROP_HEIGHT = 120;
const LOOT_CAP = 160;
const AMMO_TYPES: AmmoType[] = ['light', 'heavy', 'shell'];

/** Slightly randomised direction inside a cone of half-angle `s` (radians, approximate). */
function perturb(dir: THREE.Vector3, s: number): THREE.Vector3 {
  const up = Math.abs(dir.y) > 0.95 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
  const r = new THREE.Vector3().crossVectors(dir, up).normalize();
  const u = new THREE.Vector3().crossVectors(r, dir).normalize();
  const a = (Math.random() + Math.random() - 1) * s;
  const b = (Math.random() + Math.random() - 1) * s;
  return dir.clone().addScaledVector(r, a).addScaledVector(u, b).normalize();
}

/** Ray vs sphere; returns the nearest positive hit distance or null. `d` must be normalized. */
function raySphere(o: THREE.Vector3, d: THREE.Vector3, cx: number, cy: number, cz: number, r: number): number | null {
  const ox = o.x - cx;
  const oy = o.y - cy;
  const oz = o.z - cz;
  const b = ox * d.x + oy * d.y + oz * d.z;
  const c = ox * ox + oy * oy + oz * oz - r * r;
  const disc = b * b - c;
  if (disc < 0) return null;
  const s = Math.sqrt(disc);
  let t = -b - s;
  if (t < 0) t = -b + s;
  return t < 0 ? null : t;
}

/**
 * The whole match: world, fighters, loot, zone, shooting, damage, camera and HUD snapshots.
 * React only receives throttled HUD state and phase changes.
 */
export class Game {
  phase: Phase = 'menu';
  onHud: ((h: HudState) => void) | null = null;
  onPhase: ((p: Phase) => void) | null = null;
  onEnd: ((r: MatchResult) => void) | null = null;

  readonly input = new Input();
  readonly sfx = new Sfx();

  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(64, 1, 0.1, 1500);
  private sun = new THREE.DirectionalLight(0xfff0d2, 2.7);
  private hemi = new THREE.HemisphereLight(0xcfe6ff, 0x3d4b2a, 1.1);
  private container: HTMLElement | null = null;
  private world: World | null = null;
  private zone: Zone | null = null;
  private fx: Fx | null = null;
  private player!: Fighter;
  private fighters: Fighter[] = [];
  private bots: Bot[] = [];
  private loot: LootItem[] = [];
  private lootId = 0;
  private feed: FeedItem[] = [];
  private feedId = 0;
  private botEnv: BotEnv | null = null;
  private playerName = 'Survivor';
  private yaw = 0;
  private pitch = -0.06;
  private adsT = 0;
  private wantAds = false;
  private shake = 0;
  private vy = 0;
  private onGround = true;
  private prevFire = false;
  private time = 0;
  private dropT = 0;
  private dropFrom = { x: 0, z: 0 };
  private dropTo = { x: 0, z: 0 };
  private endT = 0;
  private endResult: MatchResult | null = null;
  private winFlag = false;
  private alive = 0;
  private hitTick = 0;
  private hitHead = false;
  private dmgTick = 0;
  private emitAcc = 0;
  private forceEmit = false;
  private zoneWarnT = 0;
  private resizeHandler = () => this.resize();

  constructor() {
    this.scene.fog = new THREE.FogExp2(0xb9d3e0, 0.0065);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -55;
    sc.right = 55;
    sc.top = 55;
    sc.bottom = -55;
    sc.near = 1;
    sc.far = 300;
    this.sun.shadow.bias = -0.0008;
    this.sun.shadow.normalBias = 0.04;
    this.scene.add(this.sun, this.sun.target, this.hemi);

    // Gradient sky dome with a soft sun glow. Fog colour matches the horizon.
    const skyMat = new THREE.ShaderMaterial({
      uniforms: {
        top: { value: new THREE.Color(0x2c6cb5) },
        horizon: { value: new THREE.Color(0xbcd7e6) },
        sunDir: { value: new THREE.Vector3(0.55, 0.45, 0.3).normalize() },
      },
      vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader:
        'uniform vec3 top; uniform vec3 horizon; uniform vec3 sunDir; varying vec3 vDir;' +
        'void main(){ float h = clamp(vDir.y, 0.0, 1.0); vec3 col = mix(horizon, top, pow(h, 0.5));' +
        'float s = max(dot(normalize(vDir), normalize(sunDir)), 0.0);' +
        'col += vec3(1.0,0.86,0.6) * (pow(s, 500.0) * 2.0 + pow(s, 10.0) * 0.18); gl_FragColor = vec4(col, 1.0); }',
      side: THREE.BackSide,
      depthWrite: false,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 32, 16), skyMat);
    sky.frustumCulled = false;
    this.scene.add(sky);
  }

  // ---- lifecycle -------------------------------------------------------

  attach(el: HTMLElement) {
    this.container = el;
    if (!this.renderer) {
      const r = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
      r.shadowMap.enabled = true;
      r.shadowMap.type = THREE.PCFSoftShadowMap;
      r.toneMapping = THREE.ACESFilmicToneMapping;
      r.toneMappingExposure = 1.0;
      this.renderer = r;
    }
    const canvas = this.renderer.domElement;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    el.appendChild(canvas);
    this.resize();
    window.addEventListener('resize', this.resizeHandler);
    this.input.attach(canvas);
  }

  detach() {
    window.removeEventListener('resize', this.resizeHandler);
    this.input.detach();
    this.renderer?.domElement.remove();
    this.container = null;
  }

  resize() {
    if (!this.renderer || !this.container) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    const coarse = typeof window !== 'undefined' && !!window.matchMedia?.('(pointer: coarse)').matches;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, coarse ? 1.5 : 2));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  start(name: string) {
    if (!this.renderer) return;
    this.sfx.unlock();
    this.sfx.start();
    this.clearMatch();
    this.input.reset();
    this.playerName = name.trim() || 'Survivor';

    const world = new World();
    this.world = world;
    this.scene.add(world.group);
    const zone = new Zone();
    this.zone = zone;
    this.scene.add(zone.group);
    this.fx = new Fx(this.scene);

    // Player: starts in the sky under a parachute, with a pistol already equipped.
    const pl = new Fighter(0, this.playerName, PLAYER_OUTFIT);
    this.player = pl;
    const landing = world.randomLand();
    const ang = Math.random() * Math.PI * 2;
    this.dropFrom = { x: landing.x + Math.cos(ang) * 40, z: landing.z + Math.sin(ang) * 40 };
    this.dropTo = { x: landing.x, z: landing.z };
    pl.x = this.dropFrom.x;
    pl.y = DROP_HEIGHT;
    pl.z = this.dropFrom.z;
    pl.slots[0] = { id: 'pistol', mag: WEAPONS.pistol.mag };
    pl.reserve.light = 24;
    pl.refreshBody();
    pl.body.setChute(true);

    this.fighters = [pl];
    this.bots = [];
    for (let i = 0; i < BOT_COUNT; i++) {
      const sp = world.randomLand();
      const name = BOT_NAMES[i % BOT_NAMES.length] + (i >= BOT_NAMES.length ? `${i}` : '');
      const b = new Bot(i + 1, name, BOT_OUTFITS[i % BOT_OUTFITS.length]);
      b.x = sp.x;
      b.y = sp.y;
      b.z = sp.z;
      b.yaw = Math.random() * Math.PI * 2;
      if (Math.random() < 0.3) {
        b.slots[0] = { id: 'pistol', mag: WEAPONS.pistol.mag };
        b.reserve.light = 12;
        b.refreshBody();
      }
      this.bots.push(b);
      this.fighters.push(b);
    }
    for (const f of this.fighters) this.scene.add(f.body.root);

    this.loot = [];
    this.lootId = 0;
    for (const s of world.lootSpots) this.spawnLoot(s.x, s.y, s.z, randomLootKind());
    for (let i = 0; i < 80; i++) {
      const s = world.randomLand();
      this.spawnLoot(s.x, s.y, s.z, randomLootKind());
    }

    this.botEnv = {
      world,
      zone,
      fighters: this.fighters,
      hasLOS: (ax, ay, az, bx, by, bz) => this.hasLOS(ax, ay, az, bx, by, bz),
      fire: (s, tx, ty, tz, acc) => this.fireBot(s, tx, ty, tz, acc),
      nearestLoot: (b, maxD) => this.nearestLootFor(b, maxD),
    };

    this.alive = this.fighters.length;
    this.yaw = Math.random() * Math.PI * 2;
    this.pitch = -0.06;
    this.adsT = 0;
    this.wantAds = false;
    this.shake = 0;
    this.vy = 0;
    this.onGround = false;
    this.prevFire = false;
    this.time = 0;
    this.dropT = 0;
    this.endT = 0;
    this.endResult = null;
    this.winFlag = false;
    this.feed = [];
    this.hitTick = 0;
    this.dmgTick = 0;
    this.hitHead = false;
    this.zoneWarnT = 0;
    this.pushFeed(`${this.playerName} is dropping in`, 'neutral', false);
    this.forceEmit = true;
    this.setPhase('drop');
  }

  pause() {
    if (this.phase !== 'playing') return;
    this.input.reset();
    this.input.releaseLock();
    this.setPhase('paused');
  }

  resume() {
    if (this.phase !== 'paused') return;
    this.input.reset();
    this.setPhase('playing');
  }

  toMenu() {
    this.input.releaseLock();
    this.clearMatch();
    this.input.reset();
    this.setPhase('menu');
  }

  private setPhase(p: Phase) {
    this.phase = p;
    this.onPhase?.(p);
    this.emit();
  }

  private clearMatch() {
    if (this.world) {
      this.scene.remove(this.world.group);
      this.world.dispose();
      this.world = null;
    }
    if (this.zone) {
      this.scene.remove(this.zone.group);
      this.zone = null;
    }
    if (this.fx) {
      this.fx.dispose();
      this.fx = null;
    }
    for (const l of this.loot) this.scene.remove(l.mesh);
    for (const f of this.fighters) this.scene.remove(f.body.root);
    this.loot = [];
    this.fighters = [];
    this.bots = [];
    this.botEnv = null;
  }

  // ---- main loop -------------------------------------------------------

  /** Called every animation frame with real elapsed seconds. */
  frame(dt: number) {
    if (!this.renderer || !this.world) return;
    const d = Math.min(dt, 0.05);
    if (this.phase === 'drop') this.updateDrop(d);
    else if (this.phase === 'playing' || this.phase === 'dying') this.update(d);
    else if (this.phase === 'over') this.fx?.update(d);
    this.renderer.render(this.scene, this.camera);
  }

  private update(dt: number) {
    const inp = this.input.consume();
    const pl = this.player;
    const zone = this.zone!;

    if (this.phase === 'playing') {
      this.time += dt;
      this.updatePlayer(dt, inp);
    } else if (pl.alive) {
      pl.body.update(dt, 0, false, 0);
    }

    for (const f of this.fighters) f.tick(dt);
    for (const b of this.bots) {
      if (!b.alive) continue;
      if (this.phase === 'playing' || this.phase === 'dying') b.update(dt, this.botEnv!);
      this.autoPickup(b, 1.3, true);
      if (b.hp < 55 && b.meds > 0) {
        b.meds--;
        b.hp = Math.min(PLAYER_MAX_HP, b.hp + MED_HEAL);
      }
    }
    for (const f of this.fighters) if (!f.alive) f.body.update(dt, 0, false, 0);

    zone.update(dt);
    const dps = zone.dps;
    if (dps > 0) {
      for (const f of this.fighters) {
        if (f.alive && !zone.contains(f.x, f.z, 0)) this.applyDamage(f, dps * dt, null, false, null);
      }
    }
    if (pl.alive && !zone.contains(pl.x, pl.z, 0)) {
      this.zoneWarnT -= dt;
      if (this.zoneWarnT <= 0) {
        this.zoneWarnT = 2;
        this.sfx.zoneWarn();
      }
    }

    for (const f of this.fighters) f.sync();
    this.fx?.update(dt);
    this.updateCamera(dt, pl);

    if (this.phase === 'dying') {
      this.endT -= dt;
      if (this.endT <= 0) this.finishMatch();
    }

    this.emitAcc += dt;
    if (this.forceEmit || this.emitAcc >= 0.1) this.emit();
  }

  private updateDrop(dt: number) {
    const inp = this.input.consume();
    const pl = this.player;
    const world = this.world!;
    this.yaw -= inp.look.x * MOUSE_SENS;
    this.pitch = Math.max(-0.9, Math.min(0.95, this.pitch - inp.look.y * MOUSE_SENS));

    this.dropT += dt;
    const k = Math.min(1, this.dropT / DROP_TIME);
    pl.x = this.dropFrom.x + (this.dropTo.x - this.dropFrom.x) * k;
    pl.z = this.dropFrom.z + (this.dropTo.z - this.dropFrom.z) * k;
    const ground = world.groundAt(pl.x, pl.z);
    pl.y = ground + (DROP_HEIGHT - ground) * Math.pow(1 - k, 1.6);
    pl.yaw = this.yaw;
    pl.pitch = this.pitch;
    pl.body.setChute(k < 0.92);
    pl.body.update(dt, 0.1, false, 0);

    if (k >= 1) {
      pl.body.setChute(false);
      pl.y = ground;
      this.onGround = true;
      this.vy = 0;
      this.pushFeed('You landed. Good luck', 'neutral', false);
      this.setPhase('playing');
    }

    for (const b of this.bots) b.sync();
    pl.sync();
    this.fx?.update(dt);
    this.updateCamera(dt, pl);
    this.emitAcc += dt;
    if (this.forceEmit || this.emitAcc >= 0.1) this.emit();
  }

  private updatePlayer(dt: number, inp: InputFrame) {
    const pl = this.player;
    const world = this.world!;
    const lookScale = this.adsT > 0.5 ? 0.6 : 1;
    this.yaw -= inp.look.x * MOUSE_SENS * lookScale;
    this.pitch = Math.max(-0.9, Math.min(0.95, this.pitch - inp.look.y * MOUSE_SENS * lookScale));

    const w = pl.weapon;
    const ads = inp.ads && w !== null;
    this.wantAds = ads;
    const sprint = inp.sprint && inp.move.y > 0.2 && !ads;
    let speed = sprint ? SPRINT_SPEED : WALK_SPEED;
    if (ads) speed *= ADS_SPEED_MUL;

    const sy = Math.sin(this.yaw);
    const cy = Math.cos(this.yaw);
    const wx = (-sy * inp.move.y + cy * inp.move.x) * speed;
    const wz = (-cy * inp.move.y - sy * inp.move.x) * speed;
    const moving = Math.hypot(wx, wz) > 0.05;
    const [nx, nz] = world.resolve(pl.x + wx * dt, pl.z + wz * dt, PLAYER_RADIUS, pl.y);
    pl.x = nx;
    pl.z = nz;

    // Jump and gravity
    if (inp.actions.includes('jump') && this.onGround) {
      this.vy = JUMP_V;
      this.onGround = false;
    }
    this.vy -= GRAVITY * dt;
    pl.y += this.vy * dt;
    const ground = world.groundAt(pl.x, pl.z);
    if (pl.y <= ground) {
      pl.y = ground;
      this.vy = 0;
      this.onGround = true;
    }

    for (const a of inp.actions) this.handleAction(a);
    this.autoPickup(pl, 1.4, false);

    if (w) {
      const def = WEAPONS[w];
      const trigger = def.auto ? inp.fire : inp.fire && !this.prevFire;
      if (trigger && !pl.reloading) {
        if (pl.slot.mag > 0 && pl.fireCd <= 0) this.playerShoot(def);
        else if (pl.slot.mag === 0 && pl.startReload()) this.sfx.reload();
      }
    }
    this.prevFire = inp.fire;

    pl.yaw = this.yaw;
    pl.pitch = this.pitch;
    pl.body.update(dt, moving ? (sprint ? 1 : 0.55) : 0, ads, this.pitch);
  }

  private handleAction(a: string) {
    const pl = this.player;
    switch (a) {
      case 'reload':
        if (pl.startReload()) this.sfx.reload();
        break;
      case 'pick':
        this.pickNearest(pl);
        break;
      case 'heal':
        if (pl.meds > 0 && pl.hp < PLAYER_MAX_HP) {
          pl.meds--;
          pl.hp = Math.min(PLAYER_MAX_HP, pl.hp + MED_HEAL);
          this.sfx.heal();
          this.forceEmit = true;
        }
        break;
      case 'slot0':
        this.switchSlot(0);
        break;
      case 'slot1':
        this.switchSlot(1);
        break;
      case 'swap':
        this.switchSlot(1 - pl.active);
        break;
    }
  }

  private switchSlot(i: number) {
    if (this.player.active === i) return;
    this.player.setActive(i);
    this.forceEmit = true;
  }

  private aimDir(): THREE.Vector3 {
    const cp = Math.cos(this.pitch);
    return new THREE.Vector3(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp);
  }

  private playerShoot(def: WeaponDef) {
    const pl = this.player;
    pl.slot.mag -= 1;
    pl.fireCd = def.rate;
    pl.body.kick(def.recoil);
    const dir = this.aimDir();
    const origin = this.camera.position.clone();
    const muzzle = pl.body.muzzleWorld(new THREE.Vector3());
    this.fx?.muzzle(muzzle);
    this.resolveShot(pl, origin, dir, def, muzzle, 0);
    this.shake = Math.min(1, this.shake + def.recoil * 0.06);
    this.sfx.shot(def.id, 1);
    if (pl.slot.mag === 0) pl.startReload();
  }

  private fireBot(shooter: Bot, tx: number, ty: number, tz: number, acc: number) {
    const w = shooter.weapon;
    if (!w || shooter.slot.mag <= 0) return;
    const def = WEAPONS[w];
    shooter.slot.mag -= 1;
    shooter.fireCd = def.rate * (1 + Math.random() * 0.3);
    shooter.body.kick(def.recoil * 0.5);
    const origin = new THREE.Vector3(shooter.x, shooter.y + 1.55, shooter.z);
    const target = new THREE.Vector3(tx, ty, tz);
    const dist = origin.distanceTo(target);
    const dir = target.clone().sub(origin).normalize();
    const muzzle = origin.clone().addScaledVector(dir, 0.8);
    this.resolveShot(shooter, origin, dir, def, muzzle, (1 - acc) * 0.1);
    this.fx?.muzzle(muzzle);
    this.sfx.shot(w, Math.max(0.05, Math.min(0.45, 1 - dist / 110)));
  }

  /** Resolves every pellet of a shot: world obstacles first, then the nearest fighter hitbox. */
  private resolveShot(shooter: Fighter, origin: THREE.Vector3, dir: THREE.Vector3, def: WeaponDef, muzzle: THREE.Vector3, extraSpread: number) {
    const world = this.world!;
    const spread = def.spread + extraSpread;
    let traced = false;
    for (let p = 0; p < def.pellets; p++) {
      const d = spread > 0 ? perturb(dir, spread) : dir.clone();
      const obs = world.rayHit(origin.x, origin.y, origin.z, d.x, d.y, d.z, def.range);
      let bestT = Math.min(obs, def.range);
      let victim: Fighter | null = null;
      let head = false;
      for (const f of this.fighters) {
        if (f === shooter || !f.alive) continue;
        const th = raySphere(origin, d, f.x, f.y + 1.68, f.z, 0.2);
        if (th !== null && th < bestT) {
          bestT = th;
          victim = f;
          head = true;
        }
        const tb = raySphere(origin, d, f.x, f.y + 1.12, f.z, 0.42);
        if (tb !== null && tb < bestT) {
          bestT = tb;
          victim = f;
          head = false;
        }
      }
      const end = origin.clone().addScaledVector(d, bestT);
      if (victim) {
        this.applyDamage(victim, def.dmg * (head ? 2.3 : 1), shooter, head, def.id);
        this.fx?.blood(end);
      } else if (obs < def.range) {
        this.fx?.dust(end);
      }
      if (!traced) {
        this.fx?.tracer(muzzle, end);
        traced = true;
      }
    }
  }

  private applyDamage(target: Fighter, amount: number, source: Fighter | null, head: boolean, weapon: WeaponId | null) {
    if (!target.alive || amount <= 0) return;
    let dmg = amount;
    if (target.armor > 0) {
      const absorb = Math.min(target.armor, dmg * 0.5);
      target.armor -= absorb;
      dmg -= absorb;
      if (target.armor <= 0) {
        target.armor = 0;
        target.armorLv = 0;
        target.body.setArmor(false);
      }
    }
    target.hp -= dmg;
    target.hurtT = 0.12;

    if (target === this.player) {
      this.dmgTick++;
      this.shake = Math.min(1, this.shake + 0.4);
      if (source) this.sfx.hurt();
      this.forceEmit = true;
    } else if (target instanceof Bot && source) {
      target.aggro = source;
    }
    if (source === this.player) {
      this.hitTick++;
      this.hitHead = head;
      this.sfx.hitConfirm(head);
      this.forceEmit = true;
    }
    if (source) this.fx?.blood(new THREE.Vector3(target.x, target.y + 1.2, target.z));

    if (target.hp <= 0) {
      target.hp = 0;
      this.killFighter(target, source, head, weapon);
    }
  }

  private killFighter(victim: Fighter, killer: Fighter | null, head: boolean, weapon: WeaponId | null) {
    victim.alive = false;
    victim.hp = 0;
    victim.body.die();
    this.dropLootFor(victim);
    if (killer && killer !== victim) killer.kills++;

    const killerName = killer ? killer.name : 'ZONE';
    const tone: FeedItem['tone'] = killer === this.player ? 'kill' : victim === this.player ? 'death' : killer ? 'neutral' : 'zone';
    this.pushFeed(`${killerName} → ${victim.name}`, tone, head, weapon ? WEAPONS[weapon].name : 'Zone');
    this.alive = this.fighters.filter((f) => f.alive).length;
    this.forceEmit = true;

    if (victim === this.player) this.endMatch(false);
    else if (this.player.alive && this.alive === 1) this.endMatch(true);
  }

  private dropLootFor(f: Fighter) {
    for (const s of f.slots) if (s.id) this.spawnLoot(f.x, f.y, f.z, { t: 'weapon', id: s.id });
    for (const t of AMMO_TYPES) {
      if (f.reserve[t] > 0) this.spawnLoot(f.x, f.y, f.z, { t: 'ammo', ammo: t, n: f.reserve[t] });
    }
    if (f.meds > 0) this.spawnLoot(f.x, f.y, f.z, { t: 'med' });
    if (f.armorLv > 0) this.spawnLoot(f.x, f.y, f.z, { t: 'armor', level: f.armorLv === 2 ? 2 : 1 });
    f.reserve = { light: 0, heavy: 0, shell: 0 };
    f.meds = 0;
  }

  private endMatch(win: boolean) {
    if (this.phase === 'dying' || this.phase === 'over') return;
    this.winFlag = win;
    const placement = win ? 1 : this.alive + 1;
    this.endResult = { win, placement, kills: this.player.kills, time: this.time, name: this.playerName };
    this.endT = win ? 3 : 2.6;
    if (win) this.sfx.win();
    else this.sfx.lose();
    this.setPhase('dying');
  }

  private finishMatch() {
    const r = this.endResult;
    if (!r) return;
    recordMatch(r.kills, r.win);
    this.onEnd?.(r);
    this.setPhase('over');
  }

  // ---- loot ------------------------------------------------------------

  private spawnLoot(x: number, y: number, z: number, kind: LootKind) {
    if (this.loot.length >= LOOT_CAP) {
      const old = this.loot.shift();
      if (old) this.scene.remove(old.mesh);
    }
    const mesh = buildLootMesh(kind);
    const jx = x + (Math.random() - 0.5) * 1.2;
    const jz = z + (Math.random() - 0.5) * 1.2;
    mesh.position.set(jx, y, jz);
    this.scene.add(mesh);
    this.loot.push({ id: ++this.lootId, kind, x: jx, y, z: jz, mesh });
  }

  private removeLoot(item: LootItem) {
    this.scene.remove(item.mesh);
    this.loot = this.loot.filter((l) => l !== item);
  }

  private wantsItem(f: Fighter, kind: LootKind): boolean {
    switch (kind.t) {
      case 'weapon':
        return f.slots.some((s) => s.id === null);
      case 'ammo':
        return f.reserve[kind.ammo] < RESERVE_CAP[kind.ammo] - 10;
      case 'med':
        return f.meds < MAX_MEDS;
      case 'armor':
        return (kind.level === 2 ? 100 : 50) > f.armor;
    }
  }

  private pickupItem(f: Fighter, item: LootItem): boolean {
    const k = item.kind;
    switch (k.t) {
      case 'weapon': {
        const empty = f.slots.findIndex((s) => s.id === null);
        if (empty >= 0) {
          f.slots[empty] = { id: k.id, mag: WEAPONS[k.id].mag };
        } else {
          // Swap with the active weapon and leave the old one on the ground.
          const old = f.slot.id;
          if (old) this.spawnLoot(f.x, f.y, f.z, { t: 'weapon', id: old });
          f.slots[f.active] = { id: k.id, mag: WEAPONS[k.id].mag };
          f.reloadT = 0;
        }
        f.refreshBody();
        break;
      }
      case 'ammo':
        f.addAmmo(k.ammo, k.n);
        break;
      case 'med':
        if (f.meds >= MAX_MEDS) return false;
        f.meds++;
        break;
      case 'armor': {
        const v = k.level === 2 ? 100 : 50;
        if (v <= f.armor) return false;
        f.armor = v;
        f.armorLv = k.level;
        f.body.setArmor(true);
        break;
      }
    }
    this.removeLoot(item);
    if (f === this.player) {
      this.sfx.pickup();
      this.forceEmit = true;
    }
    return true;
  }

  private pickNearest(f: Fighter) {
    let best: LootItem | null = null;
    let bd = 2.4;
    for (const l of this.loot) {
      const d = Math.hypot(l.x - f.x, l.z - f.z);
      if (d < bd) {
        bd = d;
        best = l;
      }
    }
    if (best) this.pickupItem(f, best);
  }

  private autoPickup(f: Fighter, radius: number, onlyUseful: boolean) {
    for (const l of [...this.loot]) {
      if (Math.hypot(l.x - f.x, l.z - f.z) > radius) continue;
      const take = l.kind.t === 'ammo' ? f === this.player || this.wantsItem(f, l.kind) : onlyUseful && this.wantsItem(f, l.kind);
      if (take) this.pickupItem(f, l);
    }
  }

  private nearestLootFor(b: Bot, maxD: number): { x: number; z: number } | null {
    let best: LootItem | null = null;
    let bd = maxD;
    for (const l of this.loot) {
      if (!this.wantsItem(b, l.kind)) continue;
      const d = Math.hypot(l.x - b.x, l.z - b.z);
      if (d < bd) {
        bd = d;
        best = l;
      }
    }
    return best ? { x: best.x, z: best.z } : null;
  }

  private findPrompt(): string | null {
    let best: LootItem | null = null;
    let bd = 2.4;
    for (const l of this.loot) {
      if (l.kind.t === 'ammo') continue;
      const d = Math.hypot(l.x - this.player.x, l.z - this.player.z);
      if (d < bd) {
        bd = d;
        best = l;
      }
    }
    return best ? lootName(best.kind) : null;
  }

  // ---- queries & camera ------------------------------------------------

  private hasLOS(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
    const dx = bx - ax;
    const dy = by - ay;
    const dz = bz - az;
    const d = Math.hypot(dx, dy, dz);
    if (d < 0.01 || !this.world) return true;
    const t = this.world.rayHit(ax, ay, az, dx / d, dy / d, dz / d, d);
    return t >= d - 0.6;
  }

  private updateCamera(dt: number, pl: Fighter) {
    const world = this.world!;
    this.adsT += ((this.wantAds ? 1 : 0) - this.adsT) * Math.min(1, dt * 10);
    const a = this.adsT;
    const cp = Math.cos(this.pitch);
    const sp = Math.sin(this.pitch);
    const fwdX = -Math.sin(this.yaw) * cp;
    const fwdY = sp;
    const fwdZ = -Math.cos(this.yaw) * cp;
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);
    const px = pl.x;
    const py = pl.y + 1.55;
    const pz = pl.z;
    const side = 0.75 + (0.42 - 0.75) * a;
    let dist = 3.6 + (2.3 - 3.6) * a;
    let cx = 0;
    let cy = 0;
    let cz = 0;
    for (let i = 0; i < 10; i++) {
      cx = px - fwdX * dist + rightX * side;
      cy = py - fwdY * dist;
      cz = pz - fwdZ * dist + rightZ * side;
      if (cy > world.groundAt(cx, cz) + 0.5) break;
      dist -= 0.35;
    }
    const sh = this.shake * this.shake * 0.4;
    cx += (Math.random() * 2 - 1) * sh;
    cy += (Math.random() * 2 - 1) * sh;
    cz += (Math.random() * 2 - 1) * sh;
    this.camera.position.set(cx, cy, cz);
    this.camera.lookAt(px + fwdX * 70, py + fwdY * 70, pz + fwdZ * 70);
    const fov = 64 + (46 - 64) * a;
    if (Math.abs(this.camera.fov - fov) > 0.01) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
    this.shake = Math.max(0, this.shake - dt * 1.8);

    this.sun.position.set(pl.x + 45, pl.y + 80, pl.z + 30);
    this.sun.target.position.set(pl.x, pl.y, pl.z);
    this.sun.target.updateMatrixWorld();
  }

  // ---- HUD snapshot ----------------------------------------------------

  private pushFeed(text: string, tone: FeedItem['tone'], head: boolean, weapon = '') {
    this.feed.push({ id: ++this.feedId, text, tone, head, weapon });
    if (this.feed.length > 6) this.feed.shift();
  }

  private emit() {
    this.emitAcc = 0;
    this.forceEmit = false;
    if (!this.world || !this.zone || !this.player) return;
    const pl = this.player;
    const zone = this.zone;
    const def = pl.weapon ? WEAPONS[pl.weapon] : null;
    const hud: HudState = {
      phase: this.phase,
      hp: Math.max(0, Math.round(pl.hp)),
      armor: Math.round(pl.armor),
      meds: pl.meds,
      alive: this.alive,
      kills: pl.kills,
      time: this.time,
      weapon: def
        ? {
            name: def.name,
            mag: pl.slot.mag,
            reserve: pl.reserve[def.ammo],
            reloading: pl.reloading,
            reloadFrac: pl.reloading ? 1 - pl.reloadT / def.reload : 0,
            slots: pl.slots.map((s) => (s.id ? { name: WEAPONS[s.id].name, mag: s.mag } : null)),
            active: pl.active,
            auto: def.auto,
          }
        : null,
      zone: {
        inside: zone.contains(pl.x, pl.z, 0),
        timeLeft: zone.timeLeft,
        shrinking: zone.shrinking,
        radius: zone.r,
        dps: zone.dps,
        stage: zone.stage,
      },
      minimap: { px: pl.x, pz: pl.z, yaw: this.yaw, zx: zone.cx, zz: zone.cz, zr: zone.r, mapR: 110 },
      prompt: this.findPrompt(),
      hitTick: this.hitTick,
      hitHead: this.hitHead,
      dmgTick: this.dmgTick,
      feed: this.feed.slice(-4),
      ads: this.wantAds,
      win: this.winFlag,
      dropT: this.dropT,
      dropTotal: DROP_TIME,
    };
    this.onHud?.(hud);
  }
}
