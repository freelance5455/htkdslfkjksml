import { STAGES, StageDef, faNum } from "./data";
import { sfx } from "./audio";

/* ============================== types ============================== */

export interface Snapshot {
  hp: number;
  maxHp: number;
  kills: number;
  needed: number;
  score: number;
  combo: number;
  stage: number;
  sneak: boolean;
  hidden: boolean;
  danger: boolean;
}

export type GameEvent =
  | { type: "evolve"; stage: number }
  | { type: "gameover"; score: number; stage: number; kills: number }
  | { type: "victory"; score: number; stage: number; kills: number }
  | { type: "pauseRequest" };

interface Callbacks {
  onSnapshot: (s: Snapshot) => void;
  onEvent: (e: GameEvent) => void;
}

interface Critter {
  x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number;
  emoji: string; size: number; speed: number;
  face: number; bob: number;
  wanderT: number; wanderA: number;
  alert: number; chasing: boolean;
  hitFlash: number; touchCd: number;
  erratic: boolean; dead: boolean;
}

interface Patch { x: number; y: number; r: number; v: number; }
interface Pond { x: number; y: number; rx: number; ry: number; }
interface Decor { x: number; y: number; emoji: string; size: number; }
interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; max: number; size: number; color: string; grav: number; kind: number;
}
interface FloatText {
  x: number; y: number; text: string; color: string; life: number; max: number; big: boolean;
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const dist2 = (ax: number, ay: number, bx: number, by: number) => {
  const dx = ax - bx, dy = ay - by;
  return dx * dx + dy * dy;
};

/* ============================== engine ============================== */

export class Engine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: Callbacks;
  private raf = 0;
  private lastT = 0;
  private w = 0; private h = 0; private scale = 1;

  mode: "demo" | "play" = "demo";
  paused = false;

  private stageIdx = 0;
  private stage: StageDef = STAGES[0];
  private world = 2000;

  private player = {
    x: 0, y: 0, vx: 0, vy: 0, hp: 100, face: 1, bob: 0,
    lungeT: 0, lungeCd: 0, lungeDx: 1, lungeDy: 0, invuln: 0,
    lastHurt: 99, dead: false, deadT: 0,
  };
  private hitThisLunge = new Set<Critter>();

  private preys: Critter[] = [];
  private preds: Critter[] = [];
  private patches: Patch[] = [];
  private ponds: Pond[] = [];
  private decors: Decor[] = [];
  private particles: Particle[] = [];
  private texts: FloatText[] = [];

  private cam = { x: 0, y: 0 };
  private shake = 0;
  private hurtFlash = 0;
  private evolveFlash = 0;
  private slowmo = 0;
  private hitstop = 0;
  private time = 0;
  private demoT = 0;

  score = 0;
  private kills = 0;
  private totalKills = 0;
  private combo = 0;
  private comboT = 0;

  /* input */
  private keys = new Set<string>();
  private joy = { x: 0, y: 0 };
  private touchSneak = false;
  private attackQueued = false;
  private snapT = 0;

  private spriteCache = new Map<string, HTMLCanvasElement>();
  private grassSprites: HTMLCanvasElement[] = [];
  private groundPattern: CanvasPattern | null = null;
  private vignette: CanvasGradient | null = null;

  constructor(canvas: HTMLCanvasElement, cb: Callbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.cb = cb;
    this.resize();
    window.addEventListener("resize", this.resize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    canvas.addEventListener("pointerdown", this.onPointer);
    this.buildWorld(6, true);
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.resize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.canvas.removeEventListener("pointerdown", this.onPointer);
  }

  /* ---------------- public controls ---------------- */

  startGame() {
    this.mode = "play";
    this.paused = false;
    this.score = 0;
    this.totalKills = 0;
    this.combo = 0;
    this.buildWorld(0, false);
  }

  setPaused(p: boolean) { this.paused = p; }
  setJoystick(x: number, y: number) { this.joy.x = x; this.joy.y = y; }
  setTouchSneak(s: boolean) { this.touchSneak = s; }
  queueAttack() { this.attackQueued = true; }
  goDemo() {
    this.mode = "demo";
    this.paused = false;
    this.buildWorld(6, true);
  }

  /* ---------------- input handlers ---------------- */

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
    if (k === "p" || k === "escape") { this.cb.onEvent({ type: "pauseRequest" }); return; }
    if (k === " ") { this.attackQueued = true; return; }
    this.keys.add(k);
  };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.key.toLowerCase()); };
  private onPointer = (e: PointerEvent) => {
    if (e.pointerType === "mouse" && this.mode === "play" && !this.paused) this.attackQueued = true;
  };

  private resize = () => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(2_600_000 / (w * h)));
    this.scale = Math.max(0.75, dpr);
    this.canvas.width = Math.round(w * this.scale);
    this.canvas.height = Math.round(h * this.scale);
    this.w = w; this.h = h;
    this.vignette = null;
  };

  /* ---------------- world generation ---------------- */

  private buildWorld(stageIdx: number, demo: boolean) {
    this.stageIdx = stageIdx;
    this.stage = STAGES[stageIdx];
    this.world = this.stage.world;
    this.kills = 0;
    this.preys = [];
    this.preds = [];
    this.particles = [];
    this.texts = [];
    this.patches = [];
    this.ponds = [];
    this.decors = [];

    const W = this.world;
    const nPatch = Math.round(W / 26);
    for (let i = 0; i < nPatch; i++) {
      this.patches.push({ x: rand(80, W - 80), y: rand(80, W - 80), r: rand(55, 115), v: Math.floor(rand(0, 3)) });
    }
    const nPond = 3 + Math.floor(stageIdx / 2);
    for (let i = 0; i < nPond; i++) {
      this.ponds.push({ x: rand(300, W - 300), y: rand(300, W - 300), rx: rand(110, 220), ry: rand(70, 140) });
    }
    const decorSets = [
      ["🍄", "🪨", "🌱"], ["🍄", "", "🪨"], ["🌿", "🪷", ""], ["🌵", "🪨", "🌾"],
      ["🌳", "", "🪨"], ["🌲", "🌲", ""], ["🌴", "🌳", "🪨"], ["", "🌿", "🪨"], ["", "", "🌾"],
    ][stageIdx];
    const nDecor = Math.round(W / 55);
    for (let i = 0; i < nDecor; i++) {
      this.decors.push({
        x: rand(60, W - 60), y: rand(60, W - 60),
        emoji: decorSets[Math.floor(rand(0, decorSets.length))],
        size: rand(26, 54) + stageIdx * 2,
      });
    }

    const px = W / 2, py = W / 2;
    Object.assign(this.player, {
      x: px, y: py, vx: 0, vy: 0, hp: this.stage.maxHp, face: 1,
      lungeT: 0, lungeCd: 0, invuln: 0, lastHurt: 99, dead: false, deadT: 0,
    });
    // safe start: clear predators near spawn
    for (let i = 0; i < this.preyTarget(); i++) this.spawnPrey(px, py, demo ? 0 : 420);
    for (let i = 0; i < this.predTarget(); i++) this.spawnPred(px, py, demo ? 0 : 700);

    // starter prey right next to player for instant action
    if (!demo) {
      for (let i = 0; i < 3; i++) {
        const c = this.makePrey();
        const a = rand(0, Math.PI * 2);
        c.x = px + Math.cos(a) * rand(120, 220);
        c.y = py + Math.sin(a) * rand(120, 220);
        this.preys.push(c);
      }
    }

    this.cam.x = px; this.cam.y = py;
    this.makeGround();
    this.makeGrassSprites();
  }

  private preyTarget(): number {
    return clamp(Math.round((this.world * this.world) / 280000), 14, 60);
  }

  private predTarget(): number {
    return this.stage.predator.count + Math.floor((this.world - 2000) / 800);
  }

  private makePrey(): Critter {
    const p = this.stage.prey;
    return {
      x: 0, y: 0, vx: 0, vy: 0, hp: p.hp, maxHp: p.hp,
      emoji: p.emoji, size: p.size, speed: this.stage.speed * 0.92,
      face: 1, bob: rand(0, 9), wanderT: 0, wanderA: rand(0, 7),
      alert: 0, chasing: false, hitFlash: 0, touchCd: 0,
      erratic: !!p.erratic, dead: false,
    };
  }

  private spawnPrey(avoidX: number, avoidY: number, minDist: number) {
    const c = this.makePrey();
    for (let t = 0; t < 12; t++) {
      c.x = rand(60, this.world - 60);
      c.y = rand(60, this.world - 60);
      if (dist2(c.x, c.y, avoidX, avoidY) > minDist * minDist) break;
    }
    this.preys.push(c);
  }

  private spawnPred(avoidX: number, avoidY: number, minDist: number) {
    const p = this.stage.predator;
    const c: Critter = {
      x: 0, y: 0, vx: 0, vy: 0, hp: p.hp, maxHp: p.hp,
      emoji: p.emoji, size: p.size, speed: this.stage.speed * 0.88,
      face: 1, bob: rand(0, 9), wanderT: 0, wanderA: rand(0, 7),
      alert: 0, chasing: false, hitFlash: 0, touchCd: 0,
      erratic: false, dead: false,
    };
    for (let t = 0; t < 12; t++) {
      c.x = rand(80, this.world - 80);
      c.y = rand(80, this.world - 80);
      if (dist2(c.x, c.y, avoidX, avoidY) > minDist * minDist) break;
    }
    this.preds.push(c);
  }

  /* ---------------- prerendered art ---------------- */

  private sprite(emoji: string): HTMLCanvasElement {
    let s = this.spriteCache.get(emoji);
    if (s) return s;
    s = document.createElement("canvas");
    s.width = 128; s.height = 128;
    const c = s.getContext("2d")!;
    c.font = '104px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
    c.textAlign = "center";
    c.textBaseline = "middle";
    c.fillText(emoji, 64, 70);
    this.spriteCache.set(emoji, s);
    return s;
  }

  private makeGround() {
    const pal = this.stage.palette;
    const t = document.createElement("canvas");
    t.width = 256; t.height = 256;
    const c = t.getContext("2d")!;
    c.fillStyle = pal.base;
    c.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 26; i++) {
      c.fillStyle = pal.blotch;
      c.globalAlpha = rand(0.3, 0.7);
      c.beginPath();
      c.ellipse(rand(0, 256), rand(0, 256), rand(12, 42), rand(8, 26), rand(0, 3), 0, 7);
      c.fill();
    }
    c.globalAlpha = 0.8;
    for (let i = 0; i < 90; i++) {
      c.fillStyle = Math.random() < 0.5 ? pal.speck : pal.blotch;
      c.fillRect(rand(0, 256), rand(0, 256), rand(1.5, 3.5), rand(1.5, 3.5));
    }
    c.globalAlpha = 1;
    this.groundPattern = this.ctx.createPattern(t, "repeat");
  }

  private makeGrassSprites() {
    const pal = this.stage.palette;
    this.grassSprites = [];
    for (let v = 0; v < 3; v++) {
      const s = document.createElement("canvas");
      s.width = 220; s.height = 180;
      const c = s.getContext("2d")!;
      const blades = 46 + v * 8;
      for (let i = 0; i < blades; i++) {
        const bx = rand(15, 205), by = rand(60, 172);
        const hgt = rand(26, 62);
        const lean = rand(-16, 16);
        c.strokeStyle = Math.random() < 0.5 ? pal.grass1 : pal.grass2;
        c.lineWidth = rand(2.4, 4.4);
        c.lineCap = "round";
        c.beginPath();
        c.moveTo(bx, by);
        c.quadraticCurveTo(bx + lean * 0.4, by - hgt * 0.6, bx + lean, by - hgt);
        c.stroke();
      }
      this.grassSprites.push(s);
    }
  }

  /* ---------------- helpers ---------------- */

  private inGrass(x: number, y: number): Patch | null {
    for (const p of this.patches) {
      if (dist2(x, y, p.x, p.y) < p.r * p.r * 0.6) return p;
    }
    return null;
  }

  private inPond(x: number, y: number): boolean {
    for (const p of this.ponds) {
      const dx = (x - p.x) / p.rx, dy = (y - p.y) / p.ry;
      if (dx * dx + dy * dy < 1) return true;
    }
    return false;
  }

  private burst(x: number, y: number, color: string, n: number, spd = 220, kind = 0) {
    for (let i = 0; i < n; i++) {
      if (this.particles.length > 320) this.particles.shift();
      const a = rand(0, Math.PI * 2), v = rand(spd * 0.3, spd);
      this.particles.push({
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40,
        life: rand(0.35, 0.8), max: 0.8, size: rand(2.5, 6.5), color, grav: kind === 1 ? 60 : 300, kind,
      });
    }
  }

  private addText(x: number, y: number, text: string, color: string, big = false) {
    this.texts.push({ x, y, text, color, life: 1.1, max: 1.1, big });
    if (this.texts.length > 24) this.texts.shift();
  }

  private playerDamage(): number {
    return this.stageIdx >= 6 ? 3 : this.stageIdx >= 4 ? 2 : 1;
  }

  /* ---------------- combat ---------------- */

  private tryAttack() {
    const P = this.player;
    if (P.lungeCd > 0 || P.dead) return;
    // aim assist: snap toward nearest target in a forward cone
    let dx = P.vx, dy = P.vy;
    if (Math.abs(dx) + Math.abs(dy) < 10) { dx = P.face; dy = 0; }
    const fl = Math.hypot(dx, dy) || 1;
    dx /= fl; dy /= fl;
    let best: Critter | null = null, bestD = 190 * 190;
    for (const list of [this.preys, this.preds]) {
      for (const c of list) {
        if (c.dead) continue;
        const d = dist2(P.x, P.y, c.x, c.y);
        if (d < bestD) {
          const tx = (c.x - P.x), ty = (c.y - P.y);
          const tl = Math.hypot(tx, ty) || 1;
          if ((tx / tl) * dx + (ty / tl) * dy > 0.1) { best = c; bestD = d; }
        }
      }
    }
    if (best) {
      const tl = Math.hypot(best.x - P.x, best.y - P.y) || 1;
      dx = (best.x - P.x) / tl; dy = (best.y - P.y) / tl;
    }
    P.lungeDx = dx; P.lungeDy = dy;
    P.lungeT = 0.22; P.lungeCd = 0.55;
    if (Math.abs(dx) > 0.1) P.face = dx > 0 ? 1 : -1;
    this.hitThisLunge.clear();
    sfx.lunge();
    this.burst(P.x, P.y, "rgba(255,255,255,0.6)", 5, 120, 1);
  }

  private hitCritter(c: Critter, isPred: boolean) {
    const P = this.player;
    const hidden = this.touchSneak || this.keys.has("shift") || !!this.inGrass(P.x, P.y);
    const ambush = !isPred && c.alert < 0.4 && hidden;
    c.hp -= this.playerDamage();
    c.hitFlash = 0.15;
    c.alert = 1;
    const kb = 260;
    const d = Math.hypot(c.x - P.x, c.y - P.y) || 1;
    c.vx += ((c.x - P.x) / d) * kb;
    c.vy += ((c.y - P.y) / d) * kb;
    this.hitstop = 0.045;
    this.shake = Math.max(this.shake, 5);
    this.burst(c.x, c.y, "#ffd76a", 8, 200);
    sfx.hit();

    if (c.hp <= 0) {
      c.dead = true;
      this.totalKills++;
      this.comboT = 4;
      this.combo = Math.min(this.combo + 1, 9);
      const mult = Math.min(this.combo, 5);
      let pts: number;
      if (isPred) {
        pts = this.stage.predator.pts * mult;
        this.addText(c.x, c.y - 30, "شکارچی شکار شد!", "#ff8d5c", true);
      } else {
        pts = this.stage.prey.pts * mult * (ambush ? 2 : 1);
        this.kills++;
      }
      this.score += pts;
      this.addText(c.x, c.y - 8, "+" + faNum(pts), ambush ? "#f5b83d" : "#d9f7a8", ambush);
      if (ambush) {
        this.addText(c.x, c.y - 52, "کمین کامل! ×۲", "#f5b83d", true);
        sfx.ambush();
      } else {
        sfx.kill(this.combo);
      }
      if (this.combo >= 2) this.addText(P.x, P.y - 46, "زنجیره ×" + faNum(Math.min(this.combo, 5)), "#8fe3ff", false);
      this.burst(c.x, c.y, "#e8613c", 16, 300);
      this.burst(c.x, c.y, "#fff3c4", 10, 180, 1);
      this.shake = Math.max(this.shake, ambush ? 11 : 8);
      this.player.hp = Math.min(this.stage.maxHp, this.player.hp + 6);

      if (!isPred && this.kills >= this.stage.kills) this.evolveOrWin();
    }
  }

  private evolveOrWin() {
    if (this.stageIdx >= STAGES.length - 1) {
      this.slowmo = 1.2;
      this.evolveFlash = 1;
      sfx.victory();
      this.cb.onEvent({ type: "victory", score: this.score, stage: this.stageIdx, kills: this.totalKills });
      this.mode = "demo";
      return;
    }
    const next = this.stageIdx + 1;
    this.score += 150 * next;
    sfx.evolve();
    this.slowmo = 1.3;
    this.evolveFlash = 1;
    this.shake = 14;
    this.burst(this.player.x, this.player.y, "#f5b83d", 40, 380, 1);
    this.burst(this.player.x, this.player.y, "#b6ff7a", 30, 300, 1);
    this.buildWorld(next, false);
    this.cb.onEvent({ type: "evolve", stage: next });
  }

  private hurtPlayer(dmg: number, fromX: number, fromY: number) {
    const P = this.player;
    if (P.invuln > 0 || P.dead) return;
    P.hp -= dmg;
    P.invuln = 1;
    P.lastHurt = 0;
    this.combo = 0;
    this.hurtFlash = 0.6;
    this.shake = Math.max(this.shake, 15);
    const d = Math.hypot(P.x - fromX, P.y - fromY) || 1;
    P.vx += ((P.x - fromX) / d) * 420;
    P.vy += ((P.y - fromY) / d) * 420;
    this.burst(P.x, P.y, "#ff5c5c", 14, 280);
    sfx.hurt();
    if (P.hp <= 0) {
      P.hp = 0;
      P.dead = true;
      P.deadT = 0;
      this.slowmo = 1.4;
      sfx.gameOver();
      this.burst(P.x, P.y, "#ff5c5c", 30, 360);
    }
  }

  /* ---------------- main loop ---------------- */

  private loop = (t: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let dt = Math.min((t - this.lastT) / 1000, 0.05);
    this.lastT = t;
    if (this.paused) { this.render(); return; }

    if (this.hitstop > 0) { this.hitstop -= dt; this.render(); return; }
    let ts = 1;
    if (this.slowmo > 0) { this.slowmo -= dt; ts = 0.3; }
    dt *= ts;
    this.time += dt;

    if (this.mode === "play") this.updatePlay(dt);
    else this.updateDemo(dt);

    this.updateFx(dt);
    this.render();

    this.snapT -= dt;
    if (this.snapT <= 0 && this.mode === "play") {
      this.snapT = 0.1;
      this.pushSnapshot();
    }
  };

  private pushSnapshot() {
    const P = this.player;
    let danger = false;
    for (const c of this.preds) if (c.chasing && !c.dead) { danger = true; break; }
    this.cb.onSnapshot({
      hp: Math.ceil(P.hp), maxHp: this.stage.maxHp,
      kills: this.kills, needed: this.stage.kills,
      score: this.score, combo: Math.min(this.combo, 5),
      stage: this.stageIdx,
      sneak: this.touchSneak || this.keys.has("shift"),
      hidden: !!this.inGrass(P.x, P.y),
      danger,
    });
  }

  private updateDemo(dt: number) {
    this.demoT += dt;
    const W = this.world;
    const cx = W / 2 + Math.cos(this.demoT * 0.07) * W * 0.28;
    const cy = W / 2 + Math.sin(this.demoT * 0.05) * W * 0.28;
    this.cam.x += (cx - this.cam.x) * dt * 0.5;
    this.cam.y += (cy - this.cam.y) * dt * 0.5;
    for (const c of [...this.preys, ...this.preds]) this.wanderCritter(c, dt, false);
  }

  private wanderCritter(c: Critter, dt: number, canFlee: boolean) {
    c.wanderT -= dt;
    if (c.wanderT <= 0) {
      c.wanderT = c.erratic ? rand(0.2, 0.6) : rand(1, 2.6);
      c.wanderA = rand(0, Math.PI * 2);
    }
    const sp = c.speed * (c.erratic ? 0.55 : 0.3);
    c.vx += (Math.cos(c.wanderA) * sp - c.vx) * dt * 3;
    c.vy += (Math.sin(c.wanderA) * sp - c.vy) * dt * 3;
    c.x = clamp(c.x + c.vx * dt, 30, this.world - 30);
    c.y = clamp(c.y + c.vy * dt, 30, this.world - 30);
    if (Math.abs(c.vx) > 8) c.face = c.vx > 0 ? 1 : -1;
    c.bob += dt * (4 + Math.hypot(c.vx, c.vy) * 0.03);
    c.hitFlash = Math.max(0, c.hitFlash - dt);
    c.alert = Math.max(0, c.alert - dt * (canFlee ? 0.5 : 1));
    c.touchCd = Math.max(0, c.touchCd - dt);
  }

  private updatePlay(dt: number) {
    const P = this.player;
    const st = this.stage;

    /* ----- player ----- */
    let ix = this.joy.x, iy = this.joy.y;
    if (this.keys.has("w") || this.keys.has("arrowup")) iy -= 1;
    if (this.keys.has("s") || this.keys.has("arrowdown")) iy += 1;
    if (this.keys.has("a") || this.keys.has("arrowleft")) ix -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) ix += 1;
    const il = Math.hypot(ix, iy);
    if (il > 1) { ix /= il; iy /= il; }

    const sneak = this.touchSneak || this.keys.has("shift");
    const grass = this.inGrass(P.x, P.y);
    const pond = this.inPond(P.x, P.y);
    const spd = st.speed * (sneak ? 0.45 : 1) * (pond ? 0.6 : 1);

    if (this.attackQueued) { this.attackQueued = false; if (!P.dead) this.tryAttack(); }

    if (P.dead) {
      P.deadT += dt;
      P.vx *= 1 - dt * 4; P.vy *= 1 - dt * 4;
      P.x += P.vx * dt; P.y += P.vy * dt;
      if (P.deadT > 1.1) {
        this.mode = "demo";
        this.cb.onEvent({ type: "gameover", score: this.score, stage: this.stageIdx, kills: this.totalKills });
      }
    } else if (P.lungeT > 0) {
      P.lungeT -= dt;
      P.vx = P.lungeDx * st.speed * 3.1;
      P.vy = P.lungeDy * st.speed * 3.1;
      P.x = clamp(P.x + P.vx * dt, 24, this.world - 24);
      P.y = clamp(P.y + P.vy * dt, 24, this.world - 24);
      // trail
      if (Math.random() < 0.7) this.burst(P.x, P.y, "rgba(255,255,255,0.35)", 1, 40, 1);
      // hits
      const reach = st.size + 16;
      for (const c of this.preys) {
        if (!c.dead && !this.hitThisLunge.has(c) &&
          dist2(P.x, P.y, c.x, c.y) < (reach + c.size) * (reach + c.size)) {
          this.hitThisLunge.add(c);
          this.hitCritter(c, false);
        }
      }
      for (const c of this.preds) {
        if (!c.dead && !this.hitThisLunge.has(c) &&
          dist2(P.x, P.y, c.x, c.y) < (reach + c.size) * (reach + c.size)) {
          this.hitThisLunge.add(c);
          this.hitCritter(c, true);
        }
      }
    } else {
      P.vx += (ix * spd - P.vx) * Math.min(1, dt * 9);
      P.vy += (iy * spd - P.vy) * Math.min(1, dt * 9);
      P.x = clamp(P.x + P.vx * dt, 24, this.world - 24);
      P.y = clamp(P.y + P.vy * dt, 24, this.world - 24);
      if (Math.abs(P.vx) > 12) P.face = P.vx > 0 ? 1 : -1;
    }
    P.bob += dt * (4 + Math.hypot(P.vx, P.vy) * 0.035);
    P.lungeCd = Math.max(0, P.lungeCd - dt);
    P.invuln = Math.max(0, P.invuln - dt);
    P.lastHurt += dt;
    if (P.lastHurt > 5 && !P.dead) P.hp = Math.min(st.maxHp, P.hp + dt * 3);
    if (pond && Math.hypot(P.vx, P.vy) > 60 && Math.random() < dt * 8) {
      this.burst(P.x, P.y + st.size * 0.5, "#9fd9e8", 3, 90);
    }

    this.comboT -= dt;
    if (this.comboT <= 0) this.combo = 0;

    const detectMult = (sneak ? 0.42 : 1) * (grass ? 0.35 : 1) * (P.lungeT > 0 ? 1.5 : 1);

    /* ----- prey ----- */
    for (const c of this.preys) {
      if (c.dead) continue;
      const d2p = dist2(c.x, c.y, P.x, P.y);
      const detectR = (150 + st.size * 2) * detectMult;
      if (!P.dead && d2p < detectR * detectR && c.alert < 0.5) {
        c.alert = 1;
        sfx.alert();
      }
      if (c.alert > 0.4 && !P.dead) {
        const d = Math.sqrt(d2p) || 1;
        let fx = (c.x - P.x) / d, fy = (c.y - P.y) / d;
        // steer away from walls
        if (c.x < 120) fx += 0.8; if (c.x > this.world - 120) fx -= 0.8;
        if (c.y < 120) fy += 0.8; if (c.y > this.world - 120) fy -= 0.8;
        const fl = Math.hypot(fx, fy) || 1;
        const fs = c.speed * (this.inPond(c.x, c.y) ? 0.6 : 1);
        c.vx += ((fx / fl) * fs - c.vx) * Math.min(1, dt * 6);
        c.vy += ((fy / fl) * fs - c.vy) * Math.min(1, dt * 6);
        c.x = clamp(c.x + c.vx * dt, 30, this.world - 30);
        c.y = clamp(c.y + c.vy * dt, 30, this.world - 30);
        if (Math.abs(c.vx) > 8) c.face = c.vx > 0 ? 1 : -1;
        c.bob += dt * 14;
        c.hitFlash = Math.max(0, c.hitFlash - dt);
        c.alert -= dt * 0.35;
      } else {
        this.wanderCritter(c, dt, true);
      }
    }

    /* ----- predators ----- */
    for (const c of this.preds) {
      if (c.dead) continue;
      const d2p = dist2(c.x, c.y, P.x, P.y);
      const detectR = 300 * (grass && sneak ? 0.3 : grass ? 0.55 : 1);
      if (!P.dead && d2p < detectR * detectR) {
        if (!c.chasing) sfx.alert();
        c.chasing = true;
        c.alert = 1;
      }
      if (c.chasing && (P.dead || d2p > 620 * 620 || (grass && sneak && d2p > 130 * 130))) {
        c.chasing = false;
      }
      if (c.chasing) {
        const d = Math.sqrt(d2p) || 1;
        const cs = c.speed * (this.inPond(c.x, c.y) ? 0.65 : 1);
        c.vx += (((P.x - c.x) / d) * cs - c.vx) * Math.min(1, dt * 4);
        c.vy += (((P.y - c.y) / d) * cs - c.vy) * Math.min(1, dt * 4);
        c.x = clamp(c.x + c.vx * dt, 30, this.world - 30);
        c.y = clamp(c.y + c.vy * dt, 30, this.world - 30);
        if (Math.abs(c.vx) > 8) c.face = c.vx > 0 ? 1 : -1;
        c.bob += dt * 13;
        c.hitFlash = Math.max(0, c.hitFlash - dt);
        c.touchCd = Math.max(0, c.touchCd - dt);
        const rr = c.size + st.size;
        if (d2p < rr * rr && c.touchCd <= 0) {
          c.touchCd = 0.9;
          this.hurtPlayer(this.stage.predator.dmg, c.x, c.y);
        }
      } else {
        this.wanderCritter(c, dt, true);
      }
    }

    /* ----- repopulate ----- */
    this.preys = this.preys.filter((c) => !c.dead);
    this.preds = this.preds.filter((c) => !c.dead);
    while (this.preys.length < this.preyTarget()) this.spawnPrey(P.x, P.y, 520);
    while (this.preds.length < this.predTarget()) this.spawnPred(P.x, P.y, 800);

    /* ----- camera ----- */
    const tx = P.x + P.vx * 0.22, ty = P.y + P.vy * 0.22;
    this.cam.x += (tx - this.cam.x) * Math.min(1, dt * 5);
    this.cam.y += (ty - this.cam.y) * Math.min(1, dt * 5);
  }

  private updateFx(dt: number) {
    this.shake = Math.max(0, this.shake - dt * 34);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 1.4);
    this.evolveFlash = Math.max(0, this.evolveFlash - dt * 0.8);
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) { this.particles.splice(i, 1); continue; }
      p.vy += p.grav * dt;
      p.vx *= 1 - dt * 2;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= dt * 46;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
  }

  /* ---------------- render ---------------- */

  private render() {
    const ctx = this.ctx;
    const { w, h, scale } = this;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);

    const shx = this.shake > 0.2 ? rand(-this.shake, this.shake) : 0;
    const shy = this.shake > 0.2 ? rand(-this.shake, this.shake) : 0;
    const camX = this.cam.x - w / 2 + shx;
    const camY = this.cam.y - h / 2 + shy;

    /* ground */
    ctx.save();
    ctx.translate(-camX, -camY);
    if (this.groundPattern) {
      ctx.fillStyle = this.groundPattern;
      ctx.fillRect(camX - 4, camY - 4, w + 8, h + 8);
    }
    // world edge darkening
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    if (camX < 0) ctx.fillRect(camX - 4, camY - 4, -camX + 4, h + 8);
    if (camY < 0) ctx.fillRect(camX - 4, camY - 4, w + 8, -camY + 4);
    if (camX + w > this.world) ctx.fillRect(this.world, camY - 4, camX + w - this.world + 4, h + 8);
    if (camY + h > this.world) ctx.fillRect(camX - 4, this.world, w + 8, camY + h - this.world + 4);

    const vis = (x: number, y: number, r: number) =>
      x + r > camX && x - r < camX + w && y + r > camY && y - r < camY + h;

    /* ponds */
    for (const p of this.ponds) {
      if (!vis(p.x, p.y, p.rx + 20)) continue;
      const g = ctx.createRadialGradient(p.x, p.y, 8, p.x, p.y, p.rx);
      g.addColorStop(0, this.stage.palette.pondDeep);
      g.addColorStop(1, this.stage.palette.pond);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, p.rx, p.ry, 0, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.18)";
      ctx.lineWidth = 2.5;
      ctx.stroke();
      // shimmer
      ctx.strokeStyle = "rgba(255,255,255,0.14)";
      ctx.lineWidth = 1.6;
      const ph = this.time * 1.4;
      for (let i = 0; i < 3; i++) {
        const yy = p.y + Math.sin(ph + i * 2.1) * p.ry * 0.4;
        ctx.beginPath();
        ctx.moveTo(p.x - p.rx * 0.5 + i * 18, yy);
        ctx.quadraticCurveTo(p.x + i * 10, yy - 5, p.x + p.rx * 0.4 - i * 14, yy);
        ctx.stroke();
      }
    }

    /* grass bases */
    for (const p of this.patches) {
      if (!vis(p.x, p.y, p.r * 1.4)) continue;
      const spr = this.grassSprites[p.v];
      if (!spr) continue;
      const sway = Math.sin(this.time * 1.6 + p.x * 0.01) * 3;
      ctx.drawImage(spr, p.x - p.r * 1.2 + sway, p.y - p.r, p.r * 2.4, p.r * 2);
    }

    /* drawables sorted by y for depth */
    type D = { y: number; f: () => void };
    const draws: D[] = [];

    for (const d of this.decors) {
      if (!vis(d.x, d.y, d.size)) continue;
      draws.push({
        y: d.y,
        f: () => {
          ctx.globalAlpha = 0.25;
          ctx.fillStyle = "#000";
          ctx.beginPath();
          ctx.ellipse(d.x, d.y + d.size * 0.32, d.size * 0.4, d.size * 0.14, 0, 0, 7);
          ctx.fill();
          ctx.globalAlpha = 1;
          ctx.drawImage(this.sprite(d.emoji), d.x - d.size / 2, d.y - d.size / 2, d.size, d.size);
        },
      });
    }

    const drawCritter = (c: Critter, isPlayer: boolean) => {
      const s = isPlayer ? this.stage.size * 2.6 : c.size * 2.6;
      const bobS = 1 + Math.sin(c.bob * 2) * 0.06;
      const lunge = isPlayer && this.player.lungeT > 0;
      ctx.save();
      ctx.translate(c.x, c.y);
      // shadow
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.ellipse(0, s * 0.34, s * 0.34, s * 0.12, 0, 0, 7);
      ctx.fill();
      ctx.globalAlpha = 1;
      if (isPlayer) {
        const P = this.player;
        if (P.invuln > 0 && Math.floor(this.time * 14) % 2 === 0) ctx.globalAlpha = 0.45;
        if (P.dead) { ctx.globalAlpha = 0.7; ctx.rotate(Math.PI / 2); }
        // player ring
        ctx.strokeStyle = this.touchSneak || this.keys.has("shift") ? "rgba(140,220,255,0.55)" : "rgba(245,184,61,0.5)";
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 6]);
        ctx.beginPath();
        ctx.ellipse(0, s * 0.3, s * 0.5, s * 0.2, 0, 0, 7);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      ctx.scale(c.face * (lunge ? 1.25 : 1), bobS * (lunge ? 0.82 : 1));
      const spr = this.sprite(c.emoji);
      ctx.drawImage(spr, -s / 2, -s / 2 - s * 0.08, s, s);
      if (c.hitFlash > 0) {
        ctx.globalCompositeOperation = "source-atop";
        ctx.globalAlpha = c.hitFlash * 5;
        ctx.fillStyle = "#fff";
        ctx.fillRect(-s / 2, -s / 2, s, s);
        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = 1;
      }
      ctx.restore();
      // alert / chase indicator
      if (!isPlayer && (c.alert > 0.5 || c.chasing)) {
        ctx.font = `900 ${c.chasing ? 20 : 15}px Vazirmatn, sans-serif`;
        ctx.textAlign = "center";
        ctx.fillStyle = c.chasing ? "#ff5c5c" : "#ffd76a";
        const bounce = Math.sin(this.time * 10) * 3;
        ctx.fillText("!", c.x, c.y - s * 0.62 + bounce);
      }
      // predator hp bar when damaged
      if (!isPlayer && c.hp < c.maxHp && c.maxHp > 2) {
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        ctx.fillRect(c.x - 18, c.y - s * 0.58, 36, 4);
        ctx.fillStyle = "#ff7a5c";
        ctx.fillRect(c.x - 18, c.y - s * 0.58, 36 * (c.hp / c.maxHp), 4);
      }
    };

    for (const c of this.preys) if (vis(c.x, c.y, 80)) draws.push({ y: c.y, f: () => drawCritter(c, false) });
    for (const c of this.preds) if (vis(c.x, c.y, 120)) draws.push({ y: c.y, f: () => drawCritter(c, false) });
    if (this.mode === "play") {
      const P = this.player;
      const pc: Critter = {
        x: P.x, y: P.y, vx: P.vx, vy: P.vy, hp: P.hp, maxHp: this.stage.maxHp,
        emoji: this.stage.emoji, size: this.stage.size, speed: 0, face: P.face, bob: P.bob,
        wanderT: 0, wanderA: 0, alert: 0, chasing: false, hitFlash: this.hurtFlash > 0.45 ? 0.12 : 0,
        touchCd: 0, erratic: false, dead: false,
      };
      draws.push({ y: P.y, f: () => drawCritter(pc, true) });
    }
    draws.sort((a, b) => a.y - b.y);
    for (const d of draws) d.f();

    /* grass overlay — hides critters standing inside */
    const overlay = (px: number, py: number) => {
      const g = this.inGrass(px, py);
      if (!g) return null;
      return g;
    };
    const overPatches = new Set<Patch>();
    if (this.mode === "play") {
      const g = overlay(this.player.x, this.player.y);
      if (g) overPatches.add(g);
    }
    for (const c of this.preys) { const g = overlay(c.x, c.y); if (g) overPatches.add(g); }
    for (const g of overPatches) {
      if (!vis(g.x, g.y, g.r * 1.4)) continue;
      const spr = this.grassSprites[g.v];
      ctx.globalAlpha = 0.85;
      const sway = Math.sin(this.time * 1.6 + g.x * 0.01) * 3;
      ctx.drawImage(spr, g.x - g.r * 1.2 + sway, g.y - g.r, g.r * 2.4, g.r * 2);
      ctx.globalAlpha = 1;
    }

    /* particles */
    for (const p of this.particles) {
      const a = p.life / p.max;
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      if (p.kind === 1) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.life * 6);
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        ctx.restore();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * a, 0, 7);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;

    /* floating texts */
    for (const t of this.texts) {
      const a = clamp(t.life / t.max, 0, 1);
      ctx.globalAlpha = a;
      ctx.font = `${t.big ? "900 22px" : "700 16px"} Vazirmatn, sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(0,0,0,0.55)";
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    /* ambient tint */
    ctx.fillStyle = this.stage.palette.ambient;
    ctx.fillRect(0, 0, w, h);

    /* vignette */
    if (!this.vignette) {
      this.vignette = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.38, w / 2, h / 2, Math.max(w, h) * 0.72);
      this.vignette.addColorStop(0, "rgba(0,0,0,0)");
      this.vignette.addColorStop(1, "rgba(0,0,0,0.42)");
    }
    ctx.fillStyle = this.vignette;
    ctx.fillRect(0, 0, w, h);

    /* hurt / evolve flashes */
    if (this.hurtFlash > 0) {
      ctx.fillStyle = `rgba(200,30,30,${this.hurtFlash * 0.3})`;
      ctx.fillRect(0, 0, w, h);
    }
    if (this.evolveFlash > 0) {
      ctx.fillStyle = `rgba(255,240,190,${this.evolveFlash * 0.55})`;
      ctx.fillRect(0, 0, w, h);
    }

    /* minimap */
    if (this.mode === "play") this.renderMinimap(ctx);
  }

  private renderMinimap(ctx: CanvasRenderingContext2D) {
    const r = Math.min(46, this.w * 0.06);
    const cx = this.w / 2, cy = r + 14;
    ctx.save();
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = "rgba(8,14,8,0.72)";
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "rgba(143,191,77,0.5)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, r - 2, 0, 7);
    ctx.clip();
    const sc = (r * 2) / this.world;
    const ox = cx - (this.world / 2) * sc, oy = cy - (this.world / 2) * sc;
    for (const c of this.preys) {
      ctx.fillStyle = "#8fbf4d";
      ctx.fillRect(ox + c.x * sc - 1.2, oy + c.y * sc - 1.2, 2.4, 2.4);
    }
    for (const c of this.preds) {
      ctx.fillStyle = c.chasing ? "#ff5c5c" : "#c96a4a";
      ctx.fillRect(ox + c.x * sc - 1.8, oy + c.y * sc - 1.8, 3.6, 3.6);
    }
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(ox + this.player.x * sc, oy + this.player.y * sc, 2.6, 0, 7);
    ctx.fill();
    ctx.restore();
  }
}