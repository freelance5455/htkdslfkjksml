import * as THREE from "three";
import { buildCrop, disposeObject, makeBike, makeFarmer, makeLabel, poseFarmer, type Limbs } from "@/game/actors";
import {
  APPLE_COST,
  FORAGE_LOOT,
  HOTBAR,
  PLANT_BY_ID,
  PLANTS,
  SAVE_KEY,
  WORLD,
  cleanName,
} from "@/game/plants";
import { valleyStore } from "@/game/store";
import { animateWorld, buildWorld, type Collider } from "@/game/world";

type Plot = {
  id: number;
  x: number;
  z: number;
  plantId: string | null;
  growth: number;
  watered: boolean;
  stage: number;
  bed: THREE.Group;
  soilMat: THREE.MeshStandardMaterial;
  crop: THREE.Group | null;
};

type Forage = { x: number; z: number; mesh: THREE.Object3D; hiddenUntil: number };

type Remote = {
  id: string;
  name: string;
  root: THREE.Group;
  farmerY: THREE.Group;
  bike: THREE.Group;
  limbs: Limbs;
  x: number;
  z: number;
  yaw: number;
  tx: number;
  tz: number;
  tyaw: number;
  ride: boolean;
  seen: number;
};

type SaveV1 = {
  v: 1;
  name: string;
  coins: number;
  health: number;
  stamina: number;
  hunger: number;
  apples: number;
  seeds: Record<string, number>;
  crops: Record<string, number>;
  plots: { plantId: string | null; growth: number; watered: boolean }[];
  x: number;
  z: number;
  yaw: number;
  minutes: number;
  flags: { planted: boolean; watered: boolean; harvested: boolean; sold: boolean; city: boolean };
};

type Spark = { x: number; y: number; z: number; vx: number; vy: number; vz: number; life: number };

const WALK = 7.4;
const BIKE = 16.5;
const PITCH_MIN = 0.05;
const PITCH_MAX = 0.34;

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function dampAngle(current: number, target: number, dt: number, lambda = 12) {
  const d = Math.atan2(Math.sin(target - current), Math.cos(target - current));
  return current + d * (1 - Math.exp(-lambda * dt));
}

function clockLabel(minutes: number) {
  const m = ((Math.floor(minutes) % 1440) + 1440) % 1440;
  const h = Math.floor(m / 60);
  const min = m % 60;
  const am = h < 12;
  const hr = h % 12 === 0 ? 12 : h % 12;
  return `${hr}:${min.toString().padStart(2, "0")} ${am ? "AM" : "PM"}`;
}

function periodLabel(hour: number) {
  if (hour < 5) return "Madrugada";
  if (hour < 12) return "Manhã";
  if (hour < 17) return "Tarde";
  if (hour < 19.5) return "Entardecer";
  return "Noite";
}

class Sfx {
  private ctx: AudioContext | null = null;
  on = true;
  unlock() {
    const AC = window.AudioContext;
    if (!AC) return;
    if (!this.ctx) this.ctx = new AC();
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }
  private tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0) {
    if (!this.on || !this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const amp = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    amp.gain.setValueAtTime(gain, t);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(amp);
    amp.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }
  plant() {
    this.tone(523, 0.09, "triangle", 0.04);
    this.tone(784, 0.12, "sine", 0.03, 0.06);
  }
  water() {
    this.tone(330, 0.1, "sine", 0.035);
    this.tone(420, 0.12, "sine", 0.025, 0.05);
  }
  harvest() {
    this.tone(392, 0.1, "triangle", 0.05);
    this.tone(523, 0.14, "triangle", 0.04, 0.08);
    this.tone(659, 0.18, "sine", 0.03, 0.14);
  }
  coin() {
    this.tone(880, 0.08, "triangle", 0.04);
    this.tone(1174, 0.14, "sine", 0.03, 0.07);
  }
  eat() {
    this.tone(280, 0.1, "sine", 0.04);
  }
  deny() {
    this.tone(160, 0.12, "triangle", 0.03);
  }
}

export class ValleyEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private timer = new THREE.Timer();
  private world: ReturnType<typeof buildWorld>;
  private player: THREE.Group;
  private limbs: Limbs;
  private bike: THREE.Group;
  private wheels: THREE.Group[];
  private plots: Plot[] = [];
  private forage: Forage[] = [];
  private colliders: Collider[] = [];
  private remotes = new Map<string, Remote>();

  private keys = new Set<string>();
  private injected: Set<string> | null = null;
  private stickX = 0;
  private stickY = 0;
  private sprintHeld = false;

  playing = false;
  private modal: null | "shop" | "sell" | "bag" = null;
  private name = "Oliver";
  private px: number;
  private pz: number;
  private speed = 0;
  private vel = 0;
  private riding = false;
  private gait = 0;
  private camYaw = 0;
  private camPitch = 0.16;
  private camDist = 7.6;
  private snap = true;
  private time = 0;
  private minutes = 9 * 60;
  private raining = false;
  private weatherT = 80;
  private hudT = 0;
  private saveT = 0;
  private dirty = false;
  private shake = 0;
  private toastT = 0;
  private slot = 1;
  private seedId = "wheat";
  private coins = 80;
  private health = 100;
  private stamina = 100;
  private hunger = 100;
  private apples = 4;
  private seeds: Record<string, number> = { wheat: 8, carrot: 4, tomato: 2 };
  private crops: Record<string, number> = {};
  private flags = { planted: false, watered: false, harvested: false, sold: false, city: false };
  private parkX = -8;
  private parkZ = 54;
  private parkYaw = Math.PI;
  private sfx = new Sfx();
  private sparks: Spark[] = [];
  private sparkPos = new Float32Array(64 * 3);
  private sparksMesh: THREE.Points;

  private readonly desired = new THREE.Vector3();
  private readonly look = new THREE.Vector3();
  private readonly camPos = new THREE.Vector3(8, 5.4, 68);
  private readonly lookPos = new THREE.Vector3(-16, 1.3, 30);

  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onBlur: () => void;
  private onResize: () => void;
  private onWheel: (e: WheelEvent) => void;
  private onHide: () => void;

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, window.matchMedia("(pointer: coarse)").matches ? 1.35 : 1.7));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.camera = new THREE.PerspectiveCamera(56, window.innerWidth / Math.max(1, window.innerHeight), 0.1, 650);
    this.camera.position.copy(this.camPos);

    this.world = buildWorld(this.scene);
    this.colliders = this.world.colliders;
    this.forage = this.world.forage.map((f) => ({ x: f.x, z: f.z, mesh: f.mesh, hiddenUntil: 0 }));

    this.makePlots();
    const rig = makeFarmer(0x2c6e9b);
    this.player = rig.group;
    this.limbs = rig.limbs;
    this.px = WORLD.spawn.x;
    this.pz = WORLD.spawn.z;
    this.player.position.set(this.px, 0, this.pz);
    this.player.rotation.y = Math.PI;
    this.scene.add(this.player);

    const bike = makeBike();
    this.bike = bike.group;
    this.wheels = bike.wheels;
    this.bike.position.set(this.parkX, 0, this.parkZ);
    this.bike.rotation.y = this.parkYaw;
    this.scene.add(this.bike);

    const blob = new THREE.Mesh(
      new THREE.CircleGeometry(0.55, 14),
      new THREE.MeshBasicMaterial({ color: 0x142016, transparent: true, opacity: 0.28, depthWrite: false }),
    );
    blob.rotation.x = -Math.PI / 2;
    blob.position.y = 0.03;
    this.player.add(blob);

    const sparkGeo = new THREE.BufferGeometry();
    sparkGeo.setAttribute("position", new THREE.BufferAttribute(this.sparkPos, 3));
    this.sparksMesh = new THREE.Points(
      sparkGeo,
      new THREE.PointsMaterial({ color: 0xe2a23a, size: 0.16, transparent: true, opacity: 0.9 }),
    );
    this.scene.add(this.sparksMesh);

    this.load();
    this.timer.connect(document);

    this.onKeyDown = (e) => this.keyDown(e);
    this.onKeyUp = (e) => this.keyUp(e);
    this.onBlur = () => {
      this.keys.clear();
      this.stickX = 0;
      this.stickY = 0;
      this.sprintHeld = false;
    };
    this.onResize = () => {
      const w = window.innerWidth;
      const h = Math.max(1, window.innerHeight);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h, false);
    };
    this.onWheel = (e) => {
      if (!this.playing || this.modal) return;
      this.camDist = clamp(this.camDist + e.deltaY * 0.004, 5.4, 12.5);
      e.preventDefault();
    };
    this.onHide = () => this.save();

    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("resize", this.onResize);
    window.addEventListener("pagehide", this.onHide);
    window.addEventListener("wheel", this.onWheel, { passive: false });
    canvas.addEventListener("contextmenu", (e) => e.preventDefault());

    const qa =
      import.meta.env.DEV ||
      (typeof location !== "undefined" && new URLSearchParams(location.search).has("qa"));
    if (qa) {
      window.__controlsTest = {
        getYaw: () => this.player.rotation.y,
        getSpeed: () => this.speed,
        setKeys: (codes: string[]) => {
          this.injected = new Set(codes);
        },
        interact: () => this.interact(),
      };
    }

    this.renderer.setAnimationLoop((t) => this.frame(t));
    this.pushHud();
    valleyStore.setState({ ready: true });
  }

  dispose() {
    this.renderer.setAnimationLoop(null);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("pagehide", this.onHide);
    window.removeEventListener("wheel", this.onWheel);
    this.timer.dispose();
    this.renderer.dispose();
    if (window.__controlsTest?.getYaw() !== undefined) {
      /* leave probe; a fresh engine replaces it */
    }
  }

  start(name: string) {
    this.name = cleanName(name);
    this.playing = true;
    this.snap = true;
    this.camYaw = 0;
    this.camPitch = 0.16;
    this.sfx.unlock();
    this.toast("A estrada segue até a cidade. Plante, colha e venda.");
    this.dirty = true;
    this.pushHud();
  }

  setStick(x: number, y: number) {
    this.stickX = x;
    this.stickY = y;
  }

  setSprint(on: boolean) {
    this.sprintHeld = on;
  }

  addLook(dx: number, dy: number) {
    if (!this.playing || this.modal) return;
    this.camYaw -= dx * 0.0045;
    this.camPitch = clamp(this.camPitch + dy * 0.003, PITCH_MIN, PITCH_MAX);
  }

  selectSlot(n: number) {
    const item = HOTBAR[n - 1];
    if (!item || !this.playing) return;
    if (item.type === "food") {
      this.eat();
      return;
    }
    this.slot = n;
    if (item.type === "seed") this.seedId = item.itemId;
    this.pushHud();
  }

  toggleBike() {
    if (!this.playing || this.modal) return;
    this.riding = !this.riding;
    if (this.riding) this.toast("Bicicleta pronta. A cidade fica no fim da estrada.");
    else {
      this.parkX = this.px;
      this.parkZ = this.pz;
      this.parkYaw = this.player.rotation.y;
      this.toast("Você desmontou.");
    }
    this.pushHud();
  }

  eat() {
    if (!this.playing) return;
    if (this.apples <= 0) {
      this.toast("Sem maçãs. O mercado da cidade vende.");
      this.sfx.deny();
      return;
    }
    this.apples -= 1;
    this.hunger = Math.min(100, this.hunger + 36);
    this.health = Math.min(100, this.health + 8);
    this.sfx.eat();
    this.toast("Você comeu uma maçã.");
    this.dirty = true;
    this.pushHud();
  }

  closeModal() {
    this.modal = null;
    this.pushHud();
  }

  toggleBag() {
    if (!this.playing) return;
    this.modal = this.modal === "bag" ? null : "bag";
    this.pushHud();
  }

  setSound(on: boolean) {
    this.sfx.on = on;
    if (on) this.sfx.unlock();
    valleyStore.setState({ sound: on });
  }

  buy(id: string) {
    const plant = PLANT_BY_ID[id];
    if (!plant) return;
    if (this.coins < plant.seedCost) {
      this.toast("Sem moedas. Venda a colheita no atacado.");
      this.sfx.deny();
      return;
    }
    this.coins -= plant.seedCost;
    this.seeds[id] = (this.seeds[id] ?? 0) + 1;
    this.sfx.coin();
    this.toast(`Semente de ${plant.name} na mochila.`);
    this.dirty = true;
    this.pushHud();
  }

  buyApple() {
    if (this.coins < APPLE_COST) {
      this.toast("Sem moedas para a maçã.");
      this.sfx.deny();
      return;
    }
    this.coins -= APPLE_COST;
    this.apples += 1;
    this.sfx.coin();
    this.toast("Maçã guardada.");
    this.dirty = true;
    this.pushHud();
  }

  sell(id: string) {
    const plant = PLANT_BY_ID[id];
    const n = this.crops[id] ?? 0;
    if (!plant || n <= 0) return;
    const gain = n * plant.sellValue;
    this.coins += gain;
    delete this.crops[id];
    this.flags.sold = true;
    this.sfx.coin();
    this.burst(this.px, this.pz);
    this.toast(`+${gain} moedas · ${plant.name}`);
    this.dirty = true;
    this.pushHud();
  }

  sellAll() {
    let gain = 0;
    for (const plant of PLANTS) {
      const n = this.crops[plant.id] ?? 0;
      if (n <= 0) continue;
      gain += n * plant.sellValue;
      delete this.crops[plant.id];
    }
    if (gain <= 0) {
      this.toast("Nada para vender. Colha na fazenda.");
      this.sfx.deny();
      return;
    }
    this.coins += gain;
    this.flags.sold = true;
    this.sfx.coin();
    this.burst(this.px, this.pz);
    this.toast(`Atacado pagou ${gain} moedas.`);
    this.dirty = true;
    this.pushHud();
  }

  interact() {
    if (!this.playing || this.modal) return;
    this.sfx.unlock();
    const target = this.nearest();
    if (!target) return;
    if (target.kind === "shop") {
      this.modal = "shop";
      this.pushHud();
      return;
    }
    if (target.kind === "market") {
      this.modal = "sell";
      this.pushHud();
      return;
    }
    if (target.kind === "forage") {
      const loot = FORAGE_LOOT[Math.floor(Math.random() * FORAGE_LOOT.length)] ?? "wheat";
      const plant = PLANT_BY_ID[loot];
      this.seeds[loot] = (this.seeds[loot] ?? 0) + 1;
      target.node.hiddenUntil = this.time + 45;
      target.node.mesh.visible = false;
      this.toast(plant ? `A mata deu semente de ${plant.name}.` : "Semente encontrada.");
      this.sfx.plant();
      this.dirty = true;
      this.pushHud();
      return;
    }
    const plot = target.plot;
    if (plot.plantId) {
      const plant = PLANT_BY_ID[plot.plantId];
      if (!plant) return;
      if (plot.growth >= plant.growTime) {
        this.crops[plant.id] = (this.crops[plant.id] ?? 0) + 1;
        plot.plantId = null;
        plot.growth = 0;
        plot.watered = false;
        plot.stage = 0;
        this.syncCrop(plot);
        this.flags.harvested = true;
        this.burst(plot.x, plot.z);
        this.shake = 0.12;
        this.sfx.harvest();
        this.toast(`${plant.name} colhido. Venda na cidade.`);
        this.dirty = true;
      } else if (!plot.watered) {
        if (this.stamina < 6) {
          this.toast("Sem energia para regar.");
          this.sfx.deny();
          return;
        }
        this.stamina -= 6;
        plot.watered = true;
        this.flags.watered = true;
        this.sfx.water();
        this.toast(`${plant.name} regado.`);
        this.dirty = true;
      } else {
        const pct = Math.min(99, Math.floor((plot.growth / plant.growTime) * 100));
        this.toast(`${plant.name} crescendo · ${pct}%`);
      }
    } else {
      const plant = PLANT_BY_ID[this.seedId];
      const have = this.seeds[this.seedId] ?? 0;
      if (!plant || have <= 0) {
        this.toast("Sem essa semente. Compre na loja da cidade.");
        this.sfx.deny();
        return;
      }
      this.seeds[this.seedId] = have - 1;
      plot.plantId = this.seedId;
      plot.growth = 0;
      plot.watered = false;
      plot.stage = 1;
      this.syncCrop(plot);
      this.flags.planted = true;
      this.sfx.plant();
      this.toast(`${plant.name} plantado. Agora regue.`);
      this.dirty = true;
    }
    this.tintAll();
    this.pushHud();
  }

  getNetSnapshot() {
    return {
      x: this.px,
      z: this.pz,
      yaw: this.player.rotation.y,
      ride: this.riding,
      name: this.name,
    };
  }

  applyRemote(id: string, data: unknown) {
    if (!data || typeof data !== "object") return;
    const d = data as Record<string, unknown>;
    if (typeof d.x !== "number" || typeof d.z !== "number" || !Number.isFinite(d.x) || !Number.isFinite(d.z)) return;
    const x = clamp(d.x, -120, 120);
    const z = clamp(d.z, -160, 90);
    const yaw = typeof d.yaw === "number" ? d.yaw : 0;
    const ride = Boolean(d.ride);
    const name = cleanName(typeof d.name === "string" ? d.name : "Fazendeiro");
    let remote = this.remotes.get(id);
    if (!remote) {
      if (this.remotes.size >= 8) return;
      const rig = makeFarmer(shirtOf(id));
      const bike = makeBike().group;
      bike.visible = false;
      const root = new THREE.Group();
      root.add(rig.group, bike);
      root.add(makeLabel(name));
      this.scene.add(root);
      remote = {
        id,
        name,
        root,
        farmerY: rig.group,
        bike,
        limbs: rig.limbs,
        x,
        z,
        yaw,
        tx: x,
        tz: z,
        tyaw: yaw,
        ride,
        seen: this.time,
      };
      this.remotes.set(id, remote);
    }
    remote.tx = x;
    remote.tz = z;
    remote.tyaw = yaw;
    remote.ride = ride;
    remote.seen = this.time;
    remote.root.visible = true;
  }

  setRemoteIds(ids: string[]) {
    const keep = new Set(ids);
    for (const [id, remote] of this.remotes) {
      if (!keep.has(id)) {
        this.scene.remove(remote.root);
        this.remotes.delete(id);
      }
    }
  }

  private frame(stamp: number) {
    this.timer.update(stamp);
    const dt = Math.min(this.timer.getDelta(), 0.05);
    this.time += dt;
    const sim = this.playing && !this.modal;

    this.move(dt, sim);
    if (sim) {
      this.minutes += dt * 2;
      if (this.minutes >= 1440) this.minutes -= 1440;
      this.stepNeeds(dt);
      this.stepWeather(dt);
      this.stepCrops(dt);
      this.stepForage();
    }
    this.pose(dt);
    this.updateRemotes(dt);
    this.updateSparks(dt);
    this.cameraWork(dt);
    const hour = (this.minutes / 60) % 24;
    animateWorld(this.world, dt, this.time, this.px, this.pz, hour, this.raining, this.camera.position.x, this.camera.position.z);

    if (this.toastT > 0) {
      this.toastT -= dt;
      if (this.toastT <= 0) valleyStore.setState({ toast: null });
    }

    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.12;
      this.pushHud();
    }
    this.saveT -= dt;
    if (this.dirty && this.saveT <= 0) {
      this.saveT = 6;
      this.save();
    }
    this.renderer.render(this.scene, this.camera);
  }

  private move(dt: number, sim: boolean) {
    let ix = this.stickX;
    let iz = this.stickY;
    if (this.down("KeyW") || this.down("ArrowUp")) iz += 1;
    if (this.down("KeyS") || this.down("ArrowDown")) iz -= 1;
    if (this.down("KeyD") || this.down("ArrowRight")) ix += 1;
    if (this.down("KeyA") || this.down("ArrowLeft")) ix -= 1;
    ix = clamp(ix, -1, 1);
    iz = clamp(iz, -1, 1);
    const mag = Math.min(1, Math.hypot(ix, iz));
    const sprint = !this.riding && (this.sprintHeld || this.down("ShiftLeft") || this.down("ShiftRight")) && this.stamina > 8;
    const hungerMul = this.hunger <= 0 ? 0.62 : 1;
    const target = sim && mag > 0.12 ? (this.riding ? BIKE : sprint ? WALK * 1.55 : WALK) * mag * hungerMul : 0;
    this.vel += (target - this.vel) * (1 - Math.exp(-8 * dt));
    if (this.vel < 0.05) this.vel = 0;
    this.speed = this.vel;

    if (this.vel > 0 && mag > 0.12) {
      const inv = 1 / Math.hypot(ix, iz);
      const dirX = ix * inv;
      const dirZ = iz * inv;
      const fx = -Math.sin(this.camYaw);
      const fz = -Math.cos(this.camYaw);
      const rx = Math.cos(this.camYaw);
      const rz = -Math.sin(this.camYaw);
      const wx = fx * dirZ + rx * dirX;
      const wz = fz * dirZ + rz * dirX;
      this.px += wx * this.vel * dt;
      this.pz += wz * this.vel * dt;
      const face = Math.atan2(wx, wz);
      this.player.rotation.y = dampAngle(this.player.rotation.y, face, dt, 14);
      this.gait += dt * this.vel * 1.5;
    }

    for (const c of this.colliders) {
      const dx = this.px - c.x;
      const dz = this.pz - c.z;
      const dist = Math.hypot(dx, dz);
      const min = c.r + 0.55;
      if (dist < min) {
        if (dist < 0.0001) this.px += min;
        else {
          const push = (min - dist) / dist;
          this.px += dx * push;
          this.pz += dz * push;
        }
      }
    }
    this.px = clamp(this.px, -105, 105);
    this.pz = clamp(this.pz, -140, 78);
    this.player.position.x = this.px;
    this.player.position.z = this.pz;
    this.player.position.y = this.riding ? 0.5 : 0;

    if (this.riding) {
      this.bike.position.set(this.px, 0, this.pz);
      this.bike.rotation.y = this.player.rotation.y;
      const spin = this.vel * dt * 3.2;
      for (const w of this.wheels) w.rotation.x += spin;
    } else {
      this.bike.position.set(this.parkX, 0, this.parkZ);
      this.bike.rotation.y = this.parkYaw;
    }

    if (sim && sprint && this.vel > 0.5) this.stamina = Math.max(0, this.stamina - 20 * dt);
    else this.stamina = Math.min(100, this.stamina + 14 * dt);

    if (sim && !this.flags.city && this.locationName() === "Cidade") {
      this.flags.city = true;
      this.toast("Cidade à vista. Loja à esquerda, atacado à direita.");
      this.dirty = true;
    }
  }

  private stepNeeds(dt: number) {
    const moving = this.vel > 0.4;
    this.hunger = Math.max(0, this.hunger - dt * (moving ? 0.42 : 0.16));
    if (this.hunger <= 0) this.health = Math.max(0, this.health - dt * 3);
    else if (this.hunger > 60 && this.health < 100) this.health = Math.min(100, this.health + dt * 1.4);
    if (this.health <= 0) {
      this.health = 46;
      this.hunger = 38;
      this.stamina = 40;
      this.riding = false;
      this.px = WORLD.cottage.x;
      this.pz = WORLD.cottage.z - 10;
      this.snap = true;
      this.toast("Você desmaiou e acordou na fazenda.");
      this.dirty = true;
    }
  }

  private stepWeather(dt: number) {
    this.weatherT -= dt;
    if (this.weatherT > 0) return;
    this.raining = !this.raining;
    if (this.raining) {
      this.weatherT = 22;
      let n = 0;
      for (const plot of this.plots) {
        if (plot.plantId && !plot.watered) {
          plot.watered = true;
          n++;
        }
      }
      if (n > 0) {
        this.flags.watered = true;
        this.toast("A chuva regou os canteiros.");
        this.dirty = true;
      }
    } else this.weatherT = 70 + Math.random() * 30;
  }

  private stepCrops(dt: number) {
    for (const plot of this.plots) {
      if (!plot.plantId || !plot.watered) continue;
      const plant = PLANT_BY_ID[plot.plantId];
      if (!plant) continue;
      if (plot.growth < plant.growTime) plot.growth += dt * (this.raining ? 1.3 : 1);
      const stage = plot.growth >= plant.growTime ? 3 : plot.growth >= plant.growTime * 0.45 ? 2 : 1;
      if (stage !== plot.stage) {
        plot.stage = stage;
        this.syncCrop(plot);
        if (stage === 3) this.dirty = true;
      } else if (stage === 3 && plot.crop) {
        const s = 1 + Math.sin(this.time * 3 + plot.id) * 0.045;
        plot.crop.scale.setScalar(s);
      }
    }
  }

  private stepForage() {
    for (const node of this.forage) {
      if (node.hiddenUntil > 0 && this.time >= node.hiddenUntil) {
        node.hiddenUntil = 0;
        node.mesh.visible = true;
      }
    }
  }

  private pose(dt: number) {
    poseFarmer(this.limbs, this.gait, this.vel > 0.4, this.riding);
    void dt;
  }

  private updateRemotes(dt: number) {
    for (const remote of this.remotes.values()) {
      if (this.time - remote.seen > 3.5) {
        remote.root.visible = false;
        continue;
      }
      const ox = remote.x;
      const oz = remote.z;
      remote.x += (remote.tx - remote.x) * (1 - Math.exp(-8 * dt));
      remote.z += (remote.tz - remote.z) * (1 - Math.exp(-8 * dt));
      remote.yaw = dampAngle(remote.yaw, remote.tyaw, dt, 10);
      remote.root.position.set(remote.x, 0, remote.z);
      remote.root.rotation.y = remote.yaw;
      remote.farmerY.position.y = remote.ride ? 0.5 : 0;
      remote.bike.visible = remote.ride;
      const moving = Math.hypot(remote.x - ox, remote.z - oz) > 0.002;
      if (moving) remote.root.userData.gait = (remote.root.userData.gait as number | undefined ?? 0) + dt * 8;
      poseFarmer(remote.limbs, (remote.root.userData.gait as number) || 0, moving, remote.ride);
    }
  }

  private updateSparks(dt: number) {
    const attr = this.sparksMesh.geometry.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < 64; i++) {
      const s = this.sparks[i];
      if (!s || s.life <= 0) {
        this.sparkPos[i * 3 + 1] = -20;
        continue;
      }
      s.life -= dt;
      s.vy -= 8 * dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.z += s.vz * dt;
      this.sparkPos[i * 3] = s.x;
      this.sparkPos[i * 3 + 1] = s.y;
      this.sparkPos[i * 3 + 2] = s.z;
    }
    attr.needsUpdate = true;
  }

  private cameraWork(dt: number) {
    if (!this.playing) {
      const t = this.time;
      this.camera.position.set(8 + Math.sin(t * 0.12) * 1.4, 5.2, 69);
      this.camera.lookAt(-16, 1.2, 30);
      this.camPos.copy(this.camera.position);
      this.lookPos.set(-16, 1.2, 30);
      return;
    }
    const yaw = this.camYaw;
    const pitch = this.camPitch;
    const dist = this.camDist + (this.riding ? 1.7 : 0);
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    const horiz = dist * Math.cos(pitch);
    const bob = Math.sin(this.gait * 2) * (this.vel > 0.4 ? 0.045 : 0);
    this.desired.set(this.px - fx * horiz, 1.4 + dist * Math.sin(pitch) + bob, this.pz - fz * horiz);
    this.look.set(this.px + fx * 1.7, 1.15, this.pz + fz * 1.7);
    const k = this.snap ? 1 : 1 - Math.exp(-6.5 * dt);
    this.camPos.lerp(this.desired, k);
    this.lookPos.lerp(this.look, k);
    this.camera.position.copy(this.camPos);
    if (this.shake > 0) {
      this.camera.position.x += Math.sin(this.time * 40) * this.shake;
      this.camera.position.y += Math.cos(this.time * 34) * this.shake * 0.5;
      this.shake = Math.max(0, this.shake - dt * 0.7);
    }
    this.camera.lookAt(this.lookPos);
    this.snap = false;
  }

  private nearest():
    | { kind: "plot"; plot: Plot; d: number }
    | { kind: "shop"; d: number }
    | { kind: "market"; d: number }
    | { kind: "forage"; node: Forage; d: number }
    | null {
    let best:
      | { kind: "plot"; plot: Plot; d: number }
      | { kind: "shop"; d: number }
      | { kind: "market"; d: number }
      | { kind: "forage"; node: Forage; d: number }
      | null = null;
    const take = (next: NonNullable<typeof best>) => {
      if (!best || next.d < best.d) best = next;
    };
    for (const plot of this.plots) {
      const d = Math.hypot(this.px - plot.x, this.pz - plot.z);
      if (d < 3.05) take({ kind: "plot", plot, d });
    }
    const ds = Math.hypot(this.px - WORLD.shop.x, this.pz - WORLD.shop.z);
    if (ds < 3.1) take({ kind: "shop", d: ds });
    const dm = Math.hypot(this.px - WORLD.market.x, this.pz - WORLD.market.z);
    if (dm < 3.1) take({ kind: "market", d: dm });
    for (const node of this.forage) {
      if (node.hiddenUntil > 0) continue;
      const d = Math.hypot(this.px - node.x, this.pz - node.z);
      if (d < 2.3) take({ kind: "forage", node, d });
    }
    return best;
  }

  private promptFor() {
    const target = this.playing && !this.modal ? this.nearest() : null;
    if (!target) return { prompt: null as string | null, live: false };
    if (target.kind === "shop") return { prompt: "Loja de sementes", live: true };
    if (target.kind === "market") return { prompt: "Vender colheita", live: true };
    if (target.kind === "forage") return { prompt: "Coletar semente", live: true };
    const plot = target.plot;
    if (!plot.plantId) {
      const plant = PLANT_BY_ID[this.seedId];
      const n = this.seeds[this.seedId] ?? 0;
      return { prompt: plant ? `Plantar ${plant.name} (${n})` : "Plantar", live: n > 0 };
    }
    const plant = PLANT_BY_ID[plot.plantId];
    if (!plant) return { prompt: null, live: false };
    if (plot.growth >= plant.growTime) return { prompt: `Colher ${plant.name}`, live: true };
    if (!plot.watered) return { prompt: `Regar ${plant.name}`, live: true };
    const pct = Math.min(99, Math.floor((plot.growth / plant.growTime) * 100));
    return { prompt: `${plant.name} · ${pct}%`, live: false };
  }

  private locationName() {
    const { px: x, pz: z } = this;
    if (z < -70 && Math.abs(x) < 55) return "Cidade";
    if (x < -46) return "Mata";
    if (Math.hypot(x - 54, z + 6) < 22) return "Lago";
    if (x < 2 && z > 10 && z < 70) return "Minha Fazenda";
    return "Estrada do Vale";
  }

  private goal() {
    const crops = Object.values(this.crops).reduce((a, b) => a + b, 0);
    const seeds = Object.values(this.seeds).reduce((a, b) => a + b, 0);
    if (crops > 0) return { ...WORLD.market, label: "Atacado" };
    if (seeds <= 0) return { ...WORLD.shop, label: "Loja" };
    return { ...WORLD.farm, label: "Canteiros" };
  }

  private tip() {
    if (!this.flags.planted) return "Escolha uma semente e plante no canteiro (E).";
    if (!this.flags.watered) return "Regue com E. Sem água a planta não cresce.";
    if (!this.flags.harvested) return "Quando a planta brilhar, colha e leve à cidade.";
    if (!this.flags.sold) return "Siga a estrada ao norte e venda no atacado.";
    return "Reinvista na loja do Barnaby e plante outra vez.";
  }

  private pushHud() {
    const prompt = this.promptFor();
    const goal = this.goal();
    const dx = goal.x - this.px;
    const dz = goal.z - this.pz;
    const len = Math.hypot(dx, dz) || 1;
    const fx = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    const rx = Math.cos(this.camYaw);
    const rz = -Math.sin(this.camYaw);
    const dotF = (dx / len) * fx + (dz / len) * fz;
    const dotR = (dx / len) * rx + (dz / len) * rz;
    const hour = (this.minutes / 60) % 24;
    this.tintAll();
    valleyStore.setState({
      playing: this.playing,
      name: this.name,
      coins: this.coins,
      health: this.health,
      stamina: this.stamina,
      hunger: this.hunger,
      weather: this.raining ? "rain" : "sun",
      clock: clockLabel(this.minutes),
      period: periodLabel(hour),
      location: this.locationName(),
      riding: this.riding,
      slot: this.slot,
      seedId: this.seedId,
      seeds: { ...this.seeds },
      crops: { ...this.crops },
      apples: this.apples,
      prompt: prompt.prompt,
      promptLive: prompt.live,
      modal: this.modal,
      tip: this.tip(),
      goalLabel: goal.label,
      goalAngle: Math.atan2(dotR, dotF),
      goalMeters: Math.round(len),
    });
  }

  private toast(text: string) {
    this.toastT = 3.2;
    valleyStore.setState({ toast: text });
  }

  private burst(x: number, z: number) {
    for (let i = 0; i < 10; i++) {
      const slot = this.sparks.find((s) => s.life <= 0);
      const spark = slot ?? { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0 };
      spark.x = x;
      spark.y = 0.7;
      spark.z = z;
      spark.vx = (Math.random() - 0.5) * 3.2;
      spark.vy = 2.2 + Math.random() * 2.4;
      spark.vz = (Math.random() - 0.5) * 3.2;
      spark.life = 0.7;
      if (!slot) {
        if (this.sparks.length < 64) this.sparks.push(spark);
      }
    }
  }

  private makePlots() {
    const x0 = -31;
    const z0 = 18;
    const gap = 6.7;
    const plank = new THREE.MeshStandardMaterial({ color: 0x8a5a32, roughness: 0.82 });
    let id = 0;
    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 4; col++) {
        const x = x0 + col * gap;
        const z = z0 + row * gap;
        const bed = new THREE.Group();
        const soilMat = new THREE.MeshStandardMaterial({ color: 0x8a5a34, roughness: 1 });
        const soil = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.28, 4.5), soilMat);
        soil.receiveShadow = true;
        bed.add(soil);
        const edge = (sx: number, sz: number, px: number, pz: number) => {
          const m = new THREE.Mesh(new THREE.BoxGeometry(sx, 0.34, sz), plank);
          m.position.set(px, 0.06, pz);
          m.castShadow = true;
          bed.add(m);
        };
        edge(4.8, 0.16, 0, 2.3);
        edge(4.8, 0.16, 0, -2.3);
        edge(0.16, 4.5, 2.3, 0);
        edge(0.16, 4.5, -2.3, 0);
        bed.position.set(x, 0.16, z);
        this.scene.add(bed);
        this.plots.push({
          id: id++,
          x,
          z,
          plantId: null,
          growth: 0,
          watered: false,
          stage: 0,
          bed,
          soilMat,
          crop: null,
        });
      }
    }
  }

  private syncCrop(plot: Plot) {
    if (plot.crop) {
      plot.bed.remove(plot.crop);
      disposeObject(plot.crop);
      plot.crop = null;
    }
    if (!plot.plantId || plot.stage <= 0) return;
    const plant = PLANT_BY_ID[plot.plantId];
    if (!plant) return;
    plot.crop = buildCrop(plant, plot.stage);
    plot.bed.add(plot.crop);
  }

  private tintAll() {
    const active = this.playing ? this.nearest() : null;
    const activeId = active && active.kind === "plot" ? active.plot.id : -1;
    for (const plot of this.plots) {
      if (plot.id === activeId) plot.soilMat.color.set(0xd8a15a);
      else if (plot.watered && plot.plantId) plot.soilMat.color.set(0x4e321c);
      else plot.soilMat.color.set(0x8a5a34);
    }
  }

  private down(code: string) {
    if (this.injected) return this.injected.has(code);
    return this.keys.has(code);
  }

  private keyDown(e: KeyboardEvent) {
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    this.keys.add(e.code);
    if (e.repeat || !this.playing) return;
    if (e.code === "KeyE" || e.code === "Space") this.interact();
    if (e.code === "KeyF") this.toggleBike();
    if (e.code === "Escape") this.closeModal();
    if (e.code === "KeyB" || e.code === "KeyI") {
      this.modal = this.modal === "bag" ? null : "bag";
      this.pushHud();
    }
    if (e.code.startsWith("Digit")) {
      const n = Number(e.code.slice(5));
      if (n >= 1 && n <= 6) this.selectSlot(n);
    }
  }

  private keyUp(e: KeyboardEvent) {
    this.keys.delete(e.code);
  }

  private load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw) as SaveV1;
      if (data.v !== 1) return;
      this.name = cleanName(data.name || "Oliver");
      this.coins = data.coins ?? this.coins;
      this.health = data.health ?? 100;
      this.stamina = data.stamina ?? 100;
      this.hunger = data.hunger ?? 100;
      this.apples = data.apples ?? this.apples;
      this.seeds = { ...data.seeds };
      this.crops = { ...data.crops };
      this.minutes = data.minutes ?? this.minutes;
      if (data.flags) this.flags = { ...this.flags, ...data.flags };
      if (typeof data.x === "number" && typeof data.z === "number") {
        this.px = data.x;
        this.pz = data.z;
        this.player.position.set(this.px, 0, this.pz);
      }
      if (typeof data.yaw === "number") this.player.rotation.y = data.yaw;
      if (data.plots?.length === this.plots.length) {
        data.plots.forEach((saved, i) => {
          const plot = this.plots[i];
          if (!plot) return;
          plot.plantId = saved.plantId;
          plot.growth = saved.growth;
          plot.watered = saved.watered;
          const plant = plot.plantId ? PLANT_BY_ID[plot.plantId] : null;
          plot.stage = !plant ? 0 : plot.growth >= plant.growTime ? 3 : plot.growth > 0 || plot.watered || plot.plantId ? (plot.growth >= plant.growTime * 0.45 ? 2 : 1) : 0;
          if (plot.plantId && plot.stage === 0) plot.stage = 1;
          this.syncCrop(plot);
        });
      }
    } catch {
      /* fresh valley */
    }
  }

  private save() {
    const data: SaveV1 = {
      v: 1,
      name: this.name,
      coins: this.coins,
      health: this.health,
      stamina: this.stamina,
      hunger: this.hunger,
      apples: this.apples,
      seeds: this.seeds,
      crops: this.crops,
      plots: this.plots.map((p) => ({ plantId: p.plantId, growth: p.growth, watered: p.watered })),
      x: this.px,
      z: this.pz,
      yaw: this.player.rotation.y,
      minutes: this.minutes,
      flags: this.flags,
    };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      this.dirty = false;
    } catch {
      /* ignore quota */
    }
  }
}

function shirtOf(id: string) {
  const palette = [0x2a6fdb, 0xc4523a, 0x7a4a9a, 0xd8a04a, 0x1f7a45, 0x0e7490];
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return palette[h % palette.length] ?? 0x2a6fdb;
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      interact: () => void;
    };
  }
}
