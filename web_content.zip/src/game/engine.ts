import {
  PlayerState,
  Direction,
  ItemId,
  InventorySlot,
  Building,
  BuildingType,
  ResourceNode,
  DroppedItem,
  Enemy,
  Milestone,
  GameStats,
  SaveGameData,
} from '../types/game';
import { generateWorld, GeneratedWorld, TILE_SIZE, WORLD_WIDTH, WORLD_HEIGHT } from './procedural';
import { ITEMS, CRAFTING_RECIPES } from './items';
import { sounds } from './audio';
import { particles } from './particles';
import { createEnemy, updateEnemyAI } from './enemies';
import { INITIAL_MILESTONES } from './milestones';
import { saveGameToStorage, loadGameFromStorage } from './save';
import { weather } from './weather';
import { getSkillEffect, unlockSkill, canUnlockSkill, SkillId } from './skills';

export class GameEngine {
  public world: GeneratedWorld;
  public player: PlayerState;
  public weather = weather;
  public inventory: (InventorySlot | null)[] = []; // 20 slots (5x4)
  public buildings: Building[] = [];
  public droppedItems: DroppedItem[] = [];
  public enemies: Enemy[] = [];
  public milestones: Milestone[] = [];
  public stats: GameStats = {
    daysSurvived: 1,
    resourcesCollected: 0,
    enemiesDefeated: 0,
    itemsCrafted: 0,
    structuresBuilt: 0,
  };

  public timeOfDay: number = 390; // 06:30 AM (minutes)
  public dayCount: number = 1;
  public cameraX: number = 0;
  public cameraY: number = 0;
  public screenShake: number = 0;

  public activeBuildingGhost: BuildingType | null = null;
  public activeOpenChest: Building | null = null;
  public activeNotification: { title: string; desc: string; icon: string; timer: number } | null = null;

  // Listeners for UI state synchronisation
  public onStateChange: (() => void) | null = null;
  public onGameOver: (() => void) | null = null;

  constructor(customSeed?: number) {
    const seed = customSeed ?? Math.floor(Math.random() * 999999);
    this.world = generateWorld(seed);

    // Initial player state
    this.player = {
      x: this.world.spawnX,
      y: this.world.spawnY,
      vx: 0,
      vy: 0,
      direction: 'down',
      action: 'idle',
      actionTimer: 0,
      animFrame: 0,
      animTimer: 0,
      health: 100,
      maxHealth: 100,
      hunger: 90,
      maxHunger: 100,
      energy: 100,
      maxEnergy: 100,
      speed: 2.2,
      isDead: false,
      isRunning: false,
      isSwimming: false,
      selectedHotbarIndex: 0,
      activeTool: null,
      attackCooldown: 0,
      hurtFlashTimer: 0,
      isDodging: false,
      dodgeTimer: 0,
      dodgeCooldown: 0,
      isInvulnerable: false,
      xp: 0,
      level: 1,
      skillPoints: 1,
      skills: {},
    };

    // 20 inventory slots (5 columns x 4 rows)
    this.inventory = new Array(20).fill(null);
    // Starter items in hotbar
    this.inventory[0] = { item: 'wooden_axe', count: 1, durability: 35 };
    this.inventory[1] = { item: 'apple', count: 3 };
    this.inventory[2] = { item: 'torch', count: 2, durability: 100 };

    this.player.activeTool = 'wooden_axe';

    this.milestones = JSON.parse(JSON.stringify(INITIAL_MILESTONES));

    // Spawn initial enemies
    this.spawnInitialEnemies();

    this.updateActiveTool();
  }

  private spawnInitialEnemies() {
    this.enemies = [];
    const spawnOnLand = (type: any, count: number, minDistance = 150) => {
      let attempts = 0;
      let spawned = 0;
      while (spawned < count && attempts < count * 25) {
        attempts++;
        const tx = Math.floor(Math.random() * (WORLD_WIDTH - 24) + 12);
        const ty = Math.floor(Math.random() * (WORLD_HEIGHT - 24) + 12);
        const tile = this.world.tiles[ty]?.[tx];
        const isWater = tile && (tile.type === 'water' || tile.type === 'deep_water');
        const isAquatic = type === 'fish' || type === 'duck';

        if (isAquatic ? isWater : (tile && tile.walkable)) {
          const px = tx * TILE_SIZE + 16;
          const py = ty * TILE_SIZE + 16;
          if (Math.hypot(px - this.player.x, py - this.player.y) >= minDistance) {
            this.enemies.push(createEnemy(`${type}_${spawned}_${Date.now()}`, type, px, py));
            spawned++;
          }
        }
      }
    };

    // Passive & wild animals
    spawnOnLand('deer', 5, 220);
    spawnOnLand('rabbit', 8, 120);
    spawnOnLand('chicken', 5, 140);
    spawnOnLand('duck', 4, 180);
    spawnOnLand('fish', 6, 160);
    spawnOnLand('goat', 4, 260);
    spawnOnLand('frog', 4, 180);
    spawnOnLand('bird', 4, 150);

    // Neutral & Territorial
    spawnOnLand('boar', 4, 250);
    spawnOnLand('wild_boar', 2, 350);

    // Predators & Monsters
    spawnOnLand('slime', 6, 200);
    spawnOnLand('wolf', 4, 300);
    spawnOnLand('bear', 2, 450);
    spawnOnLand('croc', 2, 380);

    // Mythic Golden Deer (Rare Island Wonder!)
    spawnOnLand('golden_deer', 1, 400);
  }

  // Dodge Roll Mechanic
  public dodge() {
    if (this.player.isDead || this.player.isDodging || this.player.dodgeCooldown > 0) return;

    // Energy cost calculation with skill reduction
    const energyReduction = getSkillEffect(this.player, 'dodgeEfficiency');
    const energyCost = Math.round(20 * (1 - energyReduction));
    if (this.player.energy < energyCost) {
      particles.addDamageNumber('لا توجد طاقة كافية!', this.player.x, this.player.y - 20, '#ef4444');
      return;
    }

    this.player.energy = Math.max(0, this.player.energy - energyCost);
    this.player.isDodging = true;
    this.player.dodgeTimer = 14;
    this.player.dodgeCooldown = 26;
    this.player.isInvulnerable = true;
    this.player.action = 'dodge';

    sounds.playDodge();
    particles.emitSprintDust(this.player.x, this.player.y + 10, this.player.vx, this.player.vy);

    // Determine roll direction
    let dirX = 0;
    let dirY = 0;
    if (this.player.vx !== 0 || this.player.vy !== 0) {
      const len = Math.hypot(this.player.vx, this.player.vy);
      dirX = this.player.vx / len;
      dirY = this.player.vy / len;
    } else {
      if (this.player.direction === 'down') dirY = 1;
      else if (this.player.direction === 'up') dirY = -1;
      else if (this.player.direction === 'left') dirX = -1;
      else if (this.player.direction === 'right') dirX = 1;
    }

    const dodgeSpeed = (this.player.speed + 3.2) * (1 + energyReduction * 0.25);
    this.player.vx = dirX * dodgeSpeed;
    this.player.vy = dirY * dodgeSpeed;
  }

  // XP & Leveling progression
  public addXP(amount: number) {
    if (this.player.isDead) return;
    this.player.xp += amount;
    particles.addDamageNumber(`+${amount} XP`, this.player.x + 12, this.player.y - 18, '#a855f7');

    const xpForLevel = (lvl: number) => Math.floor(75 * Math.pow(1.3, lvl - 1));
    let needed = xpForLevel(this.player.level);

    while (this.player.xp >= needed) {
      this.player.xp -= needed;
      this.player.level++;
      this.player.skillPoints += 1;

      // Level up fanfare!
      sounds.playCraft();
      this.screenShake = 5;
      particles.emitSparkles(this.player.x, this.player.y, 24);
      particles.addDamageNumber(`مستوى جديد: ${this.player.level}!`, this.player.x, this.player.y - 28, '#f59e0b');

      this.activeNotification = {
        title: 'ارتقاء في المستوى!',
        desc: `وصلت للمستوى ${this.player.level}! حصلت على نقطة مهارة جديدة.`,
        icon: 'level',
        timer: 200,
      };

      // Fully replenish energy & boost stats
      this.player.energy = this.player.maxEnergy;
      this.applySkillPassives();
      needed = xpForLevel(this.player.level);
    }
  }

  // Unlock skill
  public unlockPlayerSkill(skillId: SkillId): boolean {
    if (this.player.skillPoints <= 0) return false;
    if (!canUnlockSkill(this.player, skillId)) return false;

    if (unlockSkill(this.player, skillId)) {
      this.player.skillPoints--;
      sounds.playCraft();
      particles.emitSparkles(this.player.x, this.player.y, 20);
      this.applySkillPassives();
      this.activeNotification = {
        title: 'مهارة مكتسبة!',
        desc: `تم تفعيل المهارة بنجاح.`,
        icon: 'skill',
        timer: 160,
      };
      return true;
    }
    return false;
  }

  // Recalculate passive stats from unlocked skills
  public applySkillPassives() {
    // Vitality: +25 Max Health per tier
    const extraHealth = getSkillEffect(this.player, 'maxHealth');
    this.player.maxHealth = 100 + extraHealth;

    // Endurance: +25 Max Energy per tier
    const extraEnergy = getSkillEffect(this.player, 'maxEnergy');
    this.player.maxEnergy = 100 + extraEnergy;

    // Pathfinder: +15% Move Speed
    const extraSpeed = getSkillEffect(this.player, 'moveSpeed');
    this.player.speed = 2.2 * (1 + extraSpeed);
  }

  // Load from local storage
  public loadSavedGame(): boolean {
    const data = loadGameFromStorage();
    if (!data) return false;

    this.world = generateWorld(data.seed);
    // Restore resources health/harvested
    if (data.resources && data.resources.length > 0) {
      const map = new Map(data.resources.map((r) => [r.id, r]));
      this.world.resources.forEach((r) => {
        const saved = map.get(r.id);
        if (saved) {
          r.health = saved.health;
          r.harvested = saved.harvested;
        }
      });
    }

    this.player = {
      ...this.player,
      ...data.player,
      isRunning: false,
      isSwimming: false,
    };
    this.inventory = data.inventory;
    this.buildings = data.buildings || [];
    this.timeOfDay = data.timeOfDay;
    this.dayCount = data.dayCount;
    this.stats = data.stats;
    if (data.milestones) {
      this.milestones = data.milestones;
    }

    this.updateActiveTool();
    this.spawnInitialEnemies();
    return true;
  }

  public saveCurrentGame(): boolean {
    const data: SaveGameData = {
      version: 1,
      seed: this.world.seed,
      timeOfDay: this.timeOfDay,
      dayCount: this.dayCount,
      player: this.player,
      inventory: this.inventory,
      buildings: this.buildings,
      resources: this.world.resources,
      stats: this.stats,
      milestones: this.milestones,
    };
    return saveGameToStorage(data);
  }

  // Hotbar item sync
  public updateActiveTool() {
    const activeSlot = this.inventory[this.player.selectedHotbarIndex];
    this.player.activeTool = activeSlot ? activeSlot.item : null;
  }

  public selectHotbarSlot(index: number) {
    if (index < 0 || index > 4) return;
    this.player.selectedHotbarIndex = index;
    this.updateActiveTool();
    sounds.playClick();
  }

  // Survival stat ticks
  private tickSurvival() {
    if (this.player.isDead) return;

    // Time cycle: 1 real second = ~10 in-game minutes
    this.timeOfDay += 0.16; // ~10 in-game minutes per second at 60fps
    if (this.timeOfDay >= 1440) {
      this.timeOfDay = 0;
      this.dayCount++;
      this.stats.daysSurvived = this.dayCount;

      // Check night milestones
      if (this.dayCount >= 2) this.unlockMilestone('first_night');
      if (this.dayCount >= 3) this.unlockMilestone('survive_3_days');
      if (this.dayCount >= 7) this.unlockMilestone('survive_7_days');
    }

    // Hunger depletion: decreases slowly (reduced by Iron Stomach skill)
    const hungerDrainMod = 1 - getSkillEffect(this.player, 'hungerRate');
    this.player.hunger = Math.max(0, this.player.hunger - 0.008 * Math.max(0.2, hungerDrainMod));

    // Base speed from pathfinder skill
    const baseSpeed = 2.2 * (1 + getSkillEffect(this.player, 'moveSpeed'));

    // Energy management
    if (this.player.isSwimming) {
      // Swimming expends energy continuously (reduced by Swimmer Lungs skill)
      const swimEfficiency = 1 - getSkillEffect(this.player, 'swimEfficiency');
      const swimDrain = (this.player.isRunning ? 0.08 : 0.035) * Math.max(0.3, swimEfficiency);
      this.player.energy = Math.max(0, this.player.energy - swimDrain);
      if (this.player.energy <= 0) {
        // Drowning damage when exhausted in water!
        this.player.health = Math.max(0, this.player.health - 0.05);
        if (Math.random() < 0.05) {
          particles.addDamageNumber('غرق!', this.player.x, this.player.y - 18, '#38bdf8');
        }
        if (this.player.health <= 0) {
          this.killPlayer();
        }
      }
    } else if (this.player.hunger < 25) {
      // Energy decays when hungry
      this.player.energy = Math.max(0, this.player.energy - 0.015);
      this.player.speed = baseSpeed * 0.65; // sluggish
    } else if (this.player.energy < this.player.maxEnergy) {
      // Near campfire bonus
      const nearCampfire = this.isNearCampfire(this.player.x, this.player.y, 80);
      this.player.energy = Math.min(this.player.maxEnergy, this.player.energy + (nearCampfire ? 0.07 : 0.025));
      this.player.speed = baseSpeed;
    } else {
      this.player.speed = baseSpeed;
    }

    // Auto cancel sprint if out of energy
    if (this.player.isRunning && this.player.energy <= 2) {
      this.player.isRunning = false;
    }

    // Starvation damage
    if (this.player.hunger <= 0) {
      this.player.health = Math.max(0, this.player.health - 0.03);
      if (this.player.health <= 0) {
        this.killPlayer();
      }
    } else if (this.player.health < this.player.maxHealth && this.player.hunger > 70 && this.player.energy > 50) {
      // Health natural regeneration when well-fed
      this.player.health = Math.min(this.player.maxHealth, this.player.health + 0.018);
    }
  }

  public isNearCampfire(x: number, y: number, radius: number = 70): boolean {
    return this.buildings.some(
      (b) => b.type === 'campfire' && Math.hypot(b.tileX * 32 + 16 - x, b.tileY * 32 + 16 - y) <= radius
    );
  }

  // Check if position is on water (and not bridged by a wooden floor)
  public isWaterAt(x: number, y: number): boolean {
    const tileX = Math.floor(x / TILE_SIZE);
    const tileY = Math.floor(y / TILE_SIZE);
    if (tileX < 0 || tileY < 0 || tileX >= WORLD_WIDTH || tileY >= WORLD_HEIGHT) return false;

    // A wooden floor acting as a bridge over water
    const floor = this.buildings.find((b) => b.tileX === tileX && b.tileY === tileY && b.type === 'wood_floor');
    if (floor) return false;

    const tile = this.world.tiles[tileY]?.[tileX];
    return tile ? tile.type === 'water' || tile.type === 'deep_water' : false;
  }

  // Toggle sprint / run
  public setSprinting(sprinting: boolean) {
    if (this.player.isDead) return;
    if (sprinting && this.player.energy > 5) {
      this.player.isRunning = true;
    } else {
      this.player.isRunning = false;
    }
  }

  // Player movement and collision
  public setPlayerVelocity(vx: number, vy: number) {
    if (this.player.isDead) return;

    // Check if player is entering or exiting water
    const inWater = this.isWaterAt(this.player.x, this.player.y);
    if (inWater && !this.player.isSwimming) {
      // Transition WALKING -> SWIMMING
      this.player.isSwimming = true;
      particles.emitWaterSplash(this.player.x, this.player.y + 8, 10);
      particles.emitWaterRipple(this.player.x, this.player.y + 12);
      sounds.playCollect();
    } else if (!inWater && this.player.isSwimming) {
      // Transition SWIMMING -> WALKING
      this.player.isSwimming = false;
      particles.emitWaterSplash(this.player.x, this.player.y + 8, 8);
      sounds.playClick();
    }

    // Dynamic speed based on swim / run / walk
    let currentSpeed = 2.2;
    if (this.player.isSwimming) {
      currentSpeed = this.player.isRunning && this.player.energy > 5 ? 2.0 : 1.35;
    } else if (this.player.isRunning && this.player.energy > 5) {
      currentSpeed = 3.6;
    } else if (this.player.hunger < 25) {
      currentSpeed = 1.4;
    }

    this.player.speed = currentSpeed;
    this.player.vx = vx * currentSpeed;
    this.player.vy = vy * currentSpeed;

    const isMoving = Math.abs(vx) > 0.05 || Math.abs(vy) > 0.05;

    if (isMoving) {
      if (Math.abs(vx) > Math.abs(vy)) {
        this.player.direction = vx > 0 ? 'right' : 'left';
      } else {
        this.player.direction = vy > 0 ? 'down' : 'up';
      }

      // Update action state
      if (this.player.action !== 'attack' && this.player.action !== 'hurt') {
        if (this.player.isSwimming) {
          this.player.action = 'swim';
        } else if (this.player.isRunning) {
          this.player.action = 'run';
        } else {
          this.player.action = 'walk';
        }
      }

      // Dynamic animation interval: running is faster
      const animInterval = this.player.isRunning ? 8 : this.player.isSwimming ? 16 : 14;
      this.player.animTimer++;
      if (this.player.animTimer >= animInterval) {
        this.player.animTimer = 0;
        this.player.animFrame = this.player.animFrame === 0 ? 1 : 0;

        if (this.player.isSwimming) {
          particles.emitWaterRipple(this.player.x, this.player.y + 10);
          if (Math.random() < 0.4) {
            particles.emitWaterSplash(this.player.x, this.player.y + 8, 3);
          }
        } else if (this.player.isRunning) {
          sounds.playFootstep();
          particles.emitSprintDust(this.player.x, this.player.y + 12, vx, vy);
          // Running consumes energy while moving
          this.player.energy = Math.max(0, this.player.energy - 0.05);
        } else {
          sounds.playFootstep();
          particles.emitFootstep(this.player.x, this.player.y + 12);
        }
      }
    } else {
      if (this.player.action !== 'attack' && this.player.action !== 'hurt') {
        this.player.action = 'idle';
      }
      if (this.player.isSwimming && Math.random() < 0.04) {
        particles.emitWaterRipple(this.player.x, this.player.y + 10);
      }
    }
  }

  // Attack Action
  public attack() {
    if (this.player.isDead || this.player.attackCooldown > 0) return;

    this.player.attackCooldown = 20; // frames
    this.player.action = 'attack';
    this.player.actionTimer = 14;
    sounds.playAttack();

    // Determine attack hitbox center
    let hx = this.player.x;
    let hy = this.player.y;
    const reach = 26;
    if (this.player.direction === 'down') hy += reach;
    else if (this.player.direction === 'up') hy -= reach;
    else if (this.player.direction === 'left') hx -= reach;
    else if (this.player.direction === 'right') hx += reach;

    // Calculate attack damage based on tool and skills
    let baseDamage = 6;
    let woodPower = 8;
    let stonePower = 4;
    const activeToolDef = this.player.activeTool ? ITEMS[this.player.activeTool] : null;
    if (activeToolDef) {
      if (activeToolDef.damage) baseDamage = activeToolDef.damage;
      if (activeToolDef.gatherPowerWood) woodPower = activeToolDef.gatherPowerWood;
      if (activeToolDef.gatherPowerStone) stonePower = activeToolDef.gatherPowerStone;
    }

    // Apply skill boosts
    const weaponBonus = getSkillEffect(this.player, 'weaponDamage');
    const critChance = getSkillEffect(this.player, 'critChance');
    const isCrit = Math.random() < critChance;
    let finalDmg = Math.round(baseDamage * (1 + weaponBonus));
    if (isCrit) finalDmg = Math.round(finalDmg * 1.8);

    woodPower = Math.round(woodPower * (1 + getSkillEffect(this.player, 'chopPower')));
    stonePower = Math.round(stonePower * (1 + getSkillEffect(this.player, 'minePower')));

    // 1. Check hitting Enemies
    let hitEnemy = false;
    for (const enemy of this.enemies) {
      if (enemy.health <= 0) continue;
      const d = Math.hypot(enemy.x - hx, enemy.y - hy);
      if (d < 34) {
        hitEnemy = true;
        enemy.health -= finalDmg;
        enemy.hurtTimer = 16;
        enemy.state = 'hurt';

        // Impact screen shake & hit sparks
        this.screenShake = isCrit ? 10 : 6;
        particles.emitHitImpact(enemy.x, enemy.y);

        // Knockback
        const angle = Math.atan2(enemy.y - this.player.y, enemy.x - this.player.x);
        enemy.vx = Math.cos(angle) * (isCrit ? 6.5 : 4.5);
        enemy.vy = Math.sin(angle) * (isCrit ? 6.5 : 4.5);
        sounds.playHurt();

        const hitColor = isCrit ? '#f59e0b' : '#ef4444';
        const hitText = isCrit ? `حرجة! -${finalDmg}` : `-${finalDmg}`;
        particles.addDamageNumber(hitText, enemy.x, enemy.y - 12, hitColor);

        if (enemy.health <= 0) {
          this.stats.enemiesDefeated++;
          this.unlockMilestone('first_enemy');
          // Award XP based on enemy danger
          const xpGain = enemy.isRare ? 60 : enemy.damage >= 15 ? 35 : 15;
          this.addXP(xpGain);
          // Enemy loot drops
          this.dropEnemyLoot(enemy);
        }
      }
    }

    // 2. Check hitting Resource Nodes if no enemy hit
    if (!hitEnemy) {
      for (const res of this.world.resources) {
        if (res.harvested) continue;
        const d = Math.hypot(res.x - hx, res.y - hy);
        if (d < 34) {
          const isTree = res.type.startsWith('tree');
          const isRock = res.type.startsWith('rock');
          const isBush = res.type === 'bush_berry';

          let power = 10;
          if (isTree) {
            power = woodPower;
            sounds.playChop();
            particles.emitWoodChips(res.x, res.y);
            particles.emitLeaves(res.x, res.y - 20);
          } else if (isRock) {
            power = stonePower;
            sounds.playPickaxe();
            particles.emitStoneChips(res.x, res.y);
          } else if (isBush) {
            power = 30;
            sounds.playChop();
            particles.emitLeaves(res.x, res.y);
          }

          res.health -= power;
          res.shakeTimer = 8;
          particles.addDamageNumber(`-${power}`, res.x, res.y - 10, '#fde047');

          // Durability wear on tool
          this.wearActiveTool(1);

          if (res.health <= 0) {
            res.harvested = true;
            this.harvestResource(res);
          }
          break;
        }
      }
    }
  }

  // Wear down durability of currently active tool
  private wearActiveTool(amount: number) {
    const slot = this.inventory[this.player.selectedHotbarIndex];
    if (slot && slot.durability !== undefined) {
      slot.durability -= amount;
      if (slot.durability <= 0) {
        // Break tool
        this.inventory[this.player.selectedHotbarIndex] = null;
        this.updateActiveTool();
        sounds.playChop();
        particles.addDamageNumber('انكسرت الأداة!', this.player.x, this.player.y - 20, '#ef4444');
      }
    }
  }

  // Harvest resource and drop items
  private harvestResource(res: ResourceNode) {
    const extra = Math.random() < getSkillEffect(this.player, 'extraLootChance') ? 1 : 0;
    this.addXP(6);

    if (res.type.startsWith('tree')) {
      this.stats.resourcesCollected += 4 + extra;
      this.unlockMilestone('first_tree');
      // Drop wood logs
      this.spawnDroppedItem('wood', 3 + extra, res.x - 10, res.y);
      this.spawnDroppedItem('wood', 2, res.x + 10, res.y);
      // Chance of apple or fiber
      if (Math.random() < 0.5) {
        this.spawnDroppedItem('apple', 1, res.x, res.y - 12);
      }
      this.spawnDroppedItem('fiber', 2, res.x, res.y + 10);
    } else if (res.type === 'rock') {
      this.stats.resourcesCollected += 3 + extra;
      this.spawnDroppedItem('stone', 3 + extra, res.x - 8, res.y);
      this.spawnDroppedItem('stone', 2, res.x + 8, res.y);
    } else if (res.type === 'rock_coal') {
      this.stats.resourcesCollected += 4 + extra;
      this.spawnDroppedItem('coal', 3 + extra, res.x - 8, res.y);
      this.spawnDroppedItem('stone', 2, res.x + 8, res.y);
    } else if (res.type === 'rock_iron') {
      this.stats.resourcesCollected += 4 + extra;
      this.spawnDroppedItem('iron', 2 + extra, res.x - 8, res.y);
      this.spawnDroppedItem('stone', 2, res.x + 8, res.y);
    } else if (res.type === 'bush_berry') {
      this.stats.resourcesCollected += 3 + extra;
      this.spawnDroppedItem('berry', 3 + extra, res.x, res.y);
      this.spawnDroppedItem('fiber', 2, res.x - 6, res.y + 6);
    } else if (res.type === 'flower') {
      this.spawnDroppedItem('fiber', 1 + extra, res.x, res.y);
    }
  }

  private dropEnemyLoot(enemy: Enemy) {
    if (enemy.type === 'slime') {
      this.spawnDroppedItem('fiber', 3, enemy.x, enemy.y);
      this.spawnDroppedItem('berry', 1, enemy.x + 6, enemy.y);
    } else if (enemy.type === 'wolf') {
      this.spawnDroppedItem('fiber', 4, enemy.x, enemy.y);
      this.spawnDroppedItem('apple', 2, enemy.x - 6, enemy.y);
      this.spawnDroppedItem('wood', 2, enemy.x + 6, enemy.y);
    } else if (enemy.type === 'night_creature') {
      this.spawnDroppedItem('coal', 4, enemy.x, enemy.y);
      this.spawnDroppedItem('iron', 3, enemy.x + 8, enemy.y);
    } else if (enemy.type === 'deer') {
      this.spawnDroppedItem('apple', 2, enemy.x, enemy.y);
      this.spawnDroppedItem('fiber', 3, enemy.x + 6, enemy.y);
    } else if (enemy.type === 'golden_deer') {
      this.spawnDroppedItem('iron', 5, enemy.x, enemy.y);
      this.spawnDroppedItem('coal', 4, enemy.x - 8, enemy.y);
      this.spawnDroppedItem('apple', 4, enemy.x + 8, enemy.y);
      particles.emitSparkles(enemy.x, enemy.y, 30);
    } else if (enemy.type === 'rabbit') {
      this.spawnDroppedItem('berry', 2, enemy.x, enemy.y);
      this.spawnDroppedItem('fiber', 2, enemy.x + 4, enemy.y);
    } else if (enemy.type === 'boar' || enemy.type === 'wild_boar') {
      this.spawnDroppedItem('wood', 3, enemy.x, enemy.y);
      this.spawnDroppedItem('fiber', 3, enemy.x - 6, enemy.y);
      this.spawnDroppedItem('apple', 1, enemy.x + 6, enemy.y);
    } else if (enemy.type === 'goat') {
      this.spawnDroppedItem('fiber', 4, enemy.x, enemy.y);
      this.spawnDroppedItem('stone', 2, enemy.x + 6, enemy.y);
    } else if (enemy.type === 'chicken' || enemy.type === 'duck' || enemy.type === 'bird') {
      this.spawnDroppedItem('fiber', 2, enemy.x, enemy.y);
      this.spawnDroppedItem('berry', 1, enemy.x + 4, enemy.y);
    } else if (enemy.type === 'fish') {
      this.spawnDroppedItem('berry', 1, enemy.x, enemy.y);
    } else if (enemy.type === 'frog') {
      this.spawnDroppedItem('fiber', 2, enemy.x, enemy.y);
    } else if (enemy.type === 'bear') {
      this.spawnDroppedItem('wood', 5, enemy.x, enemy.y);
      this.spawnDroppedItem('fiber', 6, enemy.x - 8, enemy.y);
      this.spawnDroppedItem('apple', 3, enemy.x + 8, enemy.y);
    } else if (enemy.type === 'croc') {
      this.spawnDroppedItem('stone', 4, enemy.x, enemy.y);
      this.spawnDroppedItem('fiber', 5, enemy.x + 8, enemy.y);
    }
  }

  public spawnDroppedItem(item: ItemId, count: number, x: number, y: number) {
    this.droppedItems.push({
      id: Math.random().toString(),
      item,
      count,
      x,
      y,
      spawnTime: Date.now(),
      pickupDelay: 15,
    });
  }

  // Interact Action (E key or Mobile button)
  public interact() {
    if (this.player.isDead) return;

    // 1. Check interactive buildings near player
    for (const b of this.buildings) {
      const bx = b.tileX * 32 + 16;
      const by = b.tileY * 32 + 16;
      const d = Math.hypot(bx - this.player.x, by - this.player.y);
      if (d < 50) {
        if (b.type === 'wood_door') {
          b.isOpen = !b.isOpen;
          sounds.playBuild();
          particles.addDamageNumber(b.isOpen ? 'الباب مفتوح' : 'الباب مغلق', bx, by - 14, '#fde047');
          return;
        } else if (b.type === 'chest') {
          this.activeOpenChest = b;
          sounds.playClick();
          return;
        }
      }
    }

    // 2. Pick up nearest items manually if not already magnetized
    for (let i = this.droppedItems.length - 1; i >= 0; i--) {
      const di = this.droppedItems[i];
      const d = Math.hypot(di.x - this.player.x, di.y - this.player.y);
      if (d < 50) {
        const added = this.addToInventory(di.item, di.count);
        if (added) {
          sounds.playCollect();
          particles.emitSparkles(di.x, di.y);
          this.droppedItems.splice(i, 1);
          return;
        }
      }
    }
  }

  // Use / Eat Food Action
  public useCurrentItem() {
    if (this.player.isDead) return;

    const activeSlot = this.inventory[this.player.selectedHotbarIndex];
    if (!activeSlot || !activeSlot.item) return;

    const itemDef = ITEMS[activeSlot.item];
    if (itemDef.category === 'food') {
      sounds.playEat();
      this.player.hunger = Math.min(this.player.maxHunger, this.player.hunger + (itemDef.hungerRestore || 0));
      this.player.energy = Math.min(this.player.maxEnergy, this.player.energy + (itemDef.energyRestore || 0));
      this.player.health = Math.min(this.player.maxHealth, this.player.health + (itemDef.healthRestore || 0));

      particles.addDamageNumber(`+${itemDef.hungerRestore} طعام`, this.player.x, this.player.y - 16, '#22c55e');

      activeSlot.count--;
      if (activeSlot.count <= 0) {
        this.inventory[this.player.selectedHotbarIndex] = null;
      }
      this.updateActiveTool();
    }
  }

  // Inventory item management
  public addToInventory(item: ItemId, count: number): boolean {
    const def = ITEMS[item];
    // 1. Try stacking
    if (def.stackable) {
      for (const slot of this.inventory) {
        if (slot && slot.item === item && slot.count < def.maxStack) {
          const space = def.maxStack - slot.count;
          const add = Math.min(space, count);
          slot.count += add;
          count -= add;
          if (count <= 0) {
            this.updateActiveTool();
            return true;
          }
        }
      }
    }

    // 2. Find empty slot
    while (count > 0) {
      const emptyIdx = this.inventory.findIndex((s) => s === null);
      if (emptyIdx === -1) {
        // Inventory full!
        particles.addDamageNumber('الحقيبة ممتلئة!', this.player.x, this.player.y - 20, '#ef4444');
        return false;
      }
      const add = Math.min(def.maxStack, count);
      this.inventory[emptyIdx] = {
        item,
        count: add,
        durability: def.maxDurability,
      };
      count -= add;
    }

    this.updateActiveTool();
    return true;
  }

  public dropItemFromInventory(slotIndex: number) {
    const slot = this.inventory[slotIndex];
    if (!slot || !slot.item) return;

    this.spawnDroppedItem(slot.item, slot.count, this.player.x + 16, this.player.y);
    this.inventory[slotIndex] = null;
    this.updateActiveTool();
    sounds.playClick();
  }

  public swapInventorySlots(fromIndex: number, toIndex: number) {
    if (fromIndex === toIndex) return;
    const temp = this.inventory[fromIndex];
    this.inventory[fromIndex] = this.inventory[toIndex];
    this.inventory[toIndex] = temp;
    this.updateActiveTool();
    sounds.playClick();
  }

  // Crafting System
  public canCraft(recipeId: string): boolean {
    const recipe = CRAFTING_RECIPES.find((r) => r.id === recipeId);
    if (!recipe) return false;

    if (recipe.requiresCampfire && !this.isNearCampfire(this.player.x, this.player.y, 70)) {
      return false;
    }

    for (const req of recipe.requirements) {
      let countInInv = 0;
      for (const slot of this.inventory) {
        if (slot && slot.item === req.item) {
          countInInv += slot.count;
        }
      }
      if (countInInv < req.count) return false;
    }
    return true;
  }

  public craftItem(recipeId: string): boolean {
    const recipe = CRAFTING_RECIPES.find((r) => r.id === recipeId);
    if (!recipe || !this.canCraft(recipeId)) return false;

    // Deduct requirements
    for (const req of recipe.requirements) {
      let needed = req.count;
      for (const slot of this.inventory) {
        if (slot && slot.item === req.item) {
          const deduct = Math.min(needed, slot.count);
          slot.count -= deduct;
          needed -= deduct;
          if (slot.count <= 0) {
            const idx = this.inventory.indexOf(slot);
            this.inventory[idx] = null;
          }
          if (needed <= 0) break;
        }
      }
    }

    // Add crafted item
    this.addToInventory(recipe.output, recipe.outputCount);
    this.stats.itemsCrafted++;
    sounds.playCraft();
    particles.emitSparkles(this.player.x, this.player.y, 12);
    particles.addDamageNumber(`تم صنع: ${recipe.nameAr}`, this.player.x, this.player.y - 20, '#38bdf8');

    // Milestones check
    if (recipe.output === 'wooden_axe' || recipe.output === 'stone_axe' || recipe.output === 'stone_pickaxe') {
      this.unlockMilestone('first_tool');
    } else if (recipe.output === 'campfire') {
      this.unlockMilestone('first_campfire');
    } else if (recipe.output === 'chest') {
      this.unlockMilestone('first_chest');
    }

    return true;
  }

  // Building System
  public placeBuilding(type: BuildingType, tileX: number, tileY: number): boolean {
    if (!this.isValidBuildingLocation(type, tileX, tileY)) return false;

    // Find and consume 1 of building item from inventory
    let found = false;
    for (let i = 0; i < this.inventory.length; i++) {
      const slot = this.inventory[i];
      if (slot && slot.item === type) {
        slot.count--;
        if (slot.count <= 0) {
          this.inventory[i] = null;
        }
        found = true;
        break;
      }
    }
    if (!found) return false;

    this.buildings.push({
      id: `b_${tileX}_${tileY}_${Date.now()}`,
      type,
      tileX,
      tileY,
      health: 100,
      maxHealth: 100,
      isOpen: false,
      storage: type === 'chest' ? new Array(8).fill(null) : undefined,
    });

    this.stats.structuresBuilt++;
    sounds.playBuild();
    particles.emitWoodChips(tileX * 32 + 16, tileY * 32 + 16);
    this.updateActiveTool();
    return true;
  }

  public isValidBuildingLocation(type: BuildingType, tileX: number, tileY: number): boolean {
    if (tileX < 0 || tileY < 0 || tileX >= WORLD_WIDTH || tileY >= WORLD_HEIGHT) return false;

    const tile = this.world.tiles[tileY]?.[tileX];
    if (!tile) return false;

    // Floors can be placed over water (bridges) or land; walls/structures only on walkable ground or floors
    if (type !== 'wood_floor' && !tile.walkable) {
      // Check if floor exists underneath
      const hasFloor = this.buildings.some((b) => b.tileX === tileX && b.tileY === tileY && b.type === 'wood_floor');
      if (!hasFloor) return false;
    }

    // Check existing building collision
    const existing = this.buildings.find((b) => b.tileX === tileX && b.tileY === tileY);
    if (existing) {
      // Allow building wall/door on top of floor
      if (existing.type === 'wood_floor' && type !== 'wood_floor') {
        // Ok to build wall on floor
      } else {
        return false;
      }
    }

    // Check resource node overlap
    const bx = tileX * 32 + 16;
    const by = tileY * 32 + 16;
    for (const res of this.world.resources) {
      if (!res.harvested && Math.hypot(res.x - bx, res.y - by) < 22) {
        return false;
      }
    }

    // Distance from player (can't build too far away)
    if (Math.hypot(this.player.x - bx, this.player.y - by) > 130) {
      return false;
    }

    return true;
  }

  // Unlock Milestone notification
  public unlockMilestone(id: string) {
    const m = this.milestones.find((item) => item.id === id);
    if (m && !m.completed) {
      m.completed = true;
      m.completedAt = Date.now();
      sounds.playMilestone();
      this.activeNotification = {
        title: m.titleAr,
        desc: m.descriptionAr,
        icon: m.icon,
        timer: 180, // 3 seconds at 60fps
      };
    }
  }

  private killPlayer() {
    if (this.player.isDead) return;
    this.player.isDead = true;
    this.player.action = 'death';
    sounds.playDeath();
    if (this.onGameOver) {
      this.onGameOver();
    }
  }

  // Core Game Loop Tick
  public update() {
    this.tickSurvival();

    // Player action timer & cooldowns
    if (this.player.attackCooldown > 0) this.player.attackCooldown--;
    if (this.player.hurtFlashTimer > 0) this.player.hurtFlashTimer--;
    if (this.player.dodgeCooldown > 0) this.player.dodgeCooldown--;

    if (this.player.dodgeTimer > 0) {
      this.player.dodgeTimer--;
      this.player.action = 'dodge';
      if (this.player.dodgeTimer <= 0) {
        this.player.isDodging = false;
        this.player.isInvulnerable = false;
        this.player.action = 'idle';
        this.player.vx = 0;
        this.player.vy = 0;
      }
    } else if (this.player.actionTimer > 0) {
      this.player.actionTimer--;
      if (this.player.actionTimer <= 0 && !this.player.isDead) {
        this.player.action = 'idle';
      }
    }

    // Active notification timer
    if (this.activeNotification) {
      this.activeNotification.timer--;
      if (this.activeNotification.timer <= 0) {
        this.activeNotification = null;
      }
    }

    // Check POI Proximity & Discovery
    if (this.world.pois) {
      for (const poi of this.world.pois) {
        if (!poi.discovered) {
          const distToPoi = Math.hypot(this.player.x - poi.x, this.player.y - poi.y);
          if (distToPoi < 70) {
            poi.discovered = true;
            this.addXP(45);
            sounds.playCollect();
            particles.emitSparkles(this.player.x, this.player.y, 25);
            particles.addDamageNumber(`اكتشفت: ${poi.nameAr}!`, this.player.x, this.player.y - 24, '#38bdf8');
            this.activeNotification = {
              title: 'موقع استكشافي مكتشف!',
              desc: poi.descAr,
              icon: 'poi',
              timer: 240,
            };
          }
        }
      }
    }

    // Update Weather System
    this.weather.update(this.timeOfDay, particles.particles, this.cameraX, this.cameraY, 800, 600);

    // Update player position with collision
    if (!this.player.isDead && (this.player.vx !== 0 || this.player.vy !== 0)) {
      const nextX = this.player.x + this.player.vx;
      const nextY = this.player.y + this.player.vy;

      if (this.isWalkablePosition(nextX, this.player.y)) {
        this.player.x = nextX;
      }
      if (this.isWalkablePosition(this.player.x, nextY)) {
        this.player.y = nextY;
      }
    }

    // Campfire particle emitters
    this.buildings.forEach((b) => {
      if (b.type === 'campfire') {
        particles.emitCampfire(b.tileX * 32 + 16, b.tileY * 32 + 16);
      }
    });

    // Update dropped items & magnetic pickup
    for (let i = this.droppedItems.length - 1; i >= 0; i--) {
      const di = this.droppedItems[i];
      if (di.pickupDelay > 0) {
        di.pickupDelay--;
        continue;
      }

      const dist = Math.hypot(this.player.x - di.x, this.player.y - di.y);
      // Magnetic suction
      if (dist < 55 && !this.player.isDead) {
        const angle = Math.atan2(this.player.y - di.y, this.player.x - di.x);
        di.x += Math.cos(angle) * 3.5;
        di.y += Math.sin(angle) * 3.5;

        if (dist < 16) {
          const added = this.addToInventory(di.item, di.count);
          if (added) {
            sounds.playCollect();
            particles.emitSparkles(di.x, di.y);
            this.stats.resourcesCollected += di.count;
            this.droppedItems.splice(i, 1);
          }
        }
      }
    }

    // Update Enemies AI
    const isNight = this.timeOfDay < 300 || this.timeOfDay > 1200;

    // Spawn night creatures during night if count is low
    if (isNight && this.enemies.filter((e) => e.type === 'night_creature' && e.health > 0).length < 3) {
      if (Math.random() < 0.01) {
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * 200 + 200;
        this.enemies.push(
          createEnemy(
            `night_${Date.now()}`,
            'night_creature',
            this.player.x + Math.cos(angle) * dist,
            this.player.y + Math.sin(angle) * dist
          )
        );
      }
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      if (enemy.health <= 0) {
        this.enemies.splice(i, 1);
        continue;
      }

      updateEnemyAI(
        enemy,
        this.player.x,
        this.player.y,
        isNight,
        this.buildings,
        (dmg) => {
          // Player hit by enemy
          if (this.player.isInvulnerable || this.player.isDodging) {
            particles.addDamageNumber('تفادي!', this.player.x, this.player.y - 18, '#38bdf8');
            return;
          }
          const dmgReduction = getSkillEffect(this.player, 'damageReduction');
          const finalDamage = Math.max(1, Math.round(dmg * (1 - dmgReduction)));

          this.player.health = Math.max(0, this.player.health - finalDamage);
          this.player.hurtFlashTimer = 18;
          this.screenShake = 10;
          sounds.playHurt();
          particles.addDamageNumber(`-${finalDamage}`, this.player.x, this.player.y - 16, '#dc2626');
          if (this.player.health <= 0) {
            this.killPlayer();
          }
        }
      );
    }

    // Update particles
    particles.update();

    // Camera lerp towards player
    if (this.screenShake > 0) this.screenShake *= 0.88;
  }

  private isWalkablePosition(x: number, y: number): boolean {
    const tileX = Math.floor(x / TILE_SIZE);
    const tileY = Math.floor(y / TILE_SIZE);

    if (tileX < 0 || tileY < 0 || tileX >= WORLD_WIDTH || tileY >= WORLD_HEIGHT) return false;

    // Check building solid collisions (wood walls and closed doors)
    const building = this.buildings.find((b) => b.tileX === tileX && b.tileY === tileY);
    if (building) {
      if (building.type === 'wood_wall') return false;
      if (building.type === 'wood_door' && !building.isOpen) return false;
    }

    // Check floor over water
    const floor = this.buildings.find((b) => b.tileX === tileX && b.tileY === tileY && b.type === 'wood_floor');
    if (floor) return true;

    const tile = this.world.tiles[tileY]?.[tileX];
    if (!tile) return false;
    // Allow swimming in water and deep water tiles
    if (!tile.walkable && tile.type !== 'water' && tile.type !== 'deep_water') return false;

    // Check resource nodes collisions
    for (const res of this.world.resources) {
      if (!res.harvested) {
        if (Math.hypot(res.x - x, res.y - y) < 18) {
          return false;
        }
      }
    }

    return true;
  }
}
