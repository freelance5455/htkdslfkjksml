// Core game engine: rendering, player, vehicles, combat, weather, missions, UI state.
import * as THREE from 'three';
import { World, WORLD_SIZE, BLOCK, ROAD_W } from './world';
import { Human, Dog } from './character';
import { Vehicle } from './vehicles';
import { PedManager, TrafficManager } from './npc';
import { buildLuxuryHouse, buildShopInterior, Interior } from './interiors';
import { WEAPONS, WEAPON_ORDER, ITEMS, MISSIONS, ItemCategory, LANDMARKS } from './items';
import { audio } from './audio';
import { clamp, damp, lerp, angleLerp, formatClock, makeRng, rand } from './util';
import { glowTexture } from './textures';

export interface InventoryEntry {
  id: string;
  name: string;
  category: ItemCategory;
  icon: string;
  qty: number;
  desc: string;
}

export interface Notification {
  id: number;
  text: string;
  kind: 'info' | 'good' | 'bad';
}

export interface HudState {
  hp: number;
  maxHp: number;
  money: number;
  wanted: number;
  weather: string;
  temp: number;
  clock: number;
  location: string;
  speed: number;
  inVehicle: boolean;
  vehicleName: string;
  weapon: string;
  weaponName: string;
  weaponIcon: string;
  ammo: number;
  reserve: number;
  inventory: InventoryEntry[];
  objective: string;
  objectiveSub: string;
  jailed: boolean;
  jailRemaining: number;
  jailTotal: number;
  notifications: Notification[];
  fps: number;
  prompt: string | null;
  phoneOpen: boolean;
  phoneApp: string | null;
  mapOpen: boolean;
  inventoryOpen: boolean;
  wheelOpen: boolean;
  settingsOpen: boolean;
  paused: boolean;
  interior: string | null;
  missionTitle: string;
  missionStage: string;
  missions: { id: string; title: string; brief: string; reward: number; state: string }[];
  phoneBalance: number;
  damageFlash: number;
  showHints: boolean;
  shopOpen: boolean;
}

const SAVE_KEY = 'solstice_openworld_save_v1';
const JAIL_MS = 3 * 60 * 60 * 1000; // 3 real-world hours

type Quality = 'low' | 'medium' | 'high';

export class GameEngine {
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  private lastTime = 0;
  world!: World;
  peds!: PedManager;
  traffic!: TrafficManager;
  playerHuman!: Human;
  dog!: Dog;
  playerGroup = new THREE.Group();
  dogGroup = new THREE.Group();
  sun = new THREE.DirectionalLight(0xfff4e0, 2.2);
  hemi = new THREE.HemisphereLight(0xbcd7ff, 0x556044, 0.75);
  ambient = new THREE.AmbientLight(0xffffff, 0.25);
  fog = new THREE.Fog(0x9fb6cf, 120, 620);

  // player state
  playerPos = new THREE.Vector3(-450, 0.15, -447);
  playerVel = new THREE.Vector3();
  grounded = true;
  vy = 0;
  health = 100;
  maxHealth = 100;
  money = 1500;
  wanted = 0;
  wantedHeat = 0;
  inVehicle: Vehicle | null = null;
  sitting = false;
  punchTimer = 0;
  fireTimer = 0;
  dead = false;
  respawnTimer = 0;
  damageFlash = 0;

  // camera
  camYaw = Math.PI;
  camPitch = 0.18;
  camDist = 4.2;
  camTargetDist = 4.2;
  aimMode = false;

  // weapons / inventory
  weapon = 'fists';
  ammo: Record<string, number> = {};
  reserve: Record<string, number> = {};
  inventory: InventoryEntry[] = [];
  phoneBalance = 250;

  // world state
  timeOfDay = 9.5;
  daySpeed = 0.5; // game hours per real second (1 game hour = 2 real minutes)
  weather = 'Clear';
  weatherTimer = 180;
  rainIntensity = 0;
  wetness = 0;
  lightning = 0;

  // missions
  missionIndex = -1;
  missionStage = 0;
  missionCollected = 0;
  missions: { id: string; state: 'locked' | 'active' | 'done' }[] = MISSIONS.map((m) => ({
    id: m.id,
    state: 'locked',
  }));
  escapeTimer = 0;

  // jail
  jailEnd = 0;
  jailed = false;

  // UI state
  phoneOpen = false;
  phoneApp: string | null = null;
  mapOpen = false;
  inventoryOpen = false;
  wheelOpen = false;
  settingsOpen = false;
  paused = false;
  shopOpen = false;
  notifications: Notification[] = [];
  private notifId = 1;
  prompt: string | null = null;
  fps = 60;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private hudTimer = 0;

  // input
  keys = new Set<string>();
  mouseDown = false;
  rightDown = false;
  pointerLocked = false;
  touch = { mx: 0, my: 0, ldx: 0, ldy: 0 };
  buttons: Record<string, boolean> = {};
  sensitivity = 0.0026;
  invertY = false;
  masterVolume = 0.7;
  quality: Quality = 'high';
  isMobile = false;

  // scene objects
  vehicles: Vehicle[] = [];
  policeCars: Vehicle[] = [];
  interiors = new Map<string, Interior>();
  private projectiles: {
    mesh: THREE.Object3D;
    vel: THREE.Vector3;
    life: number;
    kind: string;
    fuse: number;
    dmg: number;
  }[] = [];
  private effects: { obj: THREE.Object3D; life: number; max: number; kind: string }[] = [];
  private rainPoints: THREE.Points | null = null;
  private marker!: THREE.Mesh;
  private markerArrow!: THREE.Mesh;
  private packages: { mesh: THREE.Mesh; x: number; z: number; taken: boolean }[] = [];
  private policeSpawnTimer = 0;
  private listeners = new Set<(s: HudState) => void>();
  private hud!: HudState;
  private minimapCanvas: HTMLCanvasElement | null = null;
  private mapCanvas: HTMLCanvasElement | null = null;
  private envMap: THREE.Texture | null = null;
  private envRT: THREE.WebGLRenderTarget | null = null;
  private pmrem: THREE.PMREMGenerator | null = null;
  private envTimer = 0;
  private lastFootstep = 0;
  private damageDirs: { angle: number; life: number }[] = [];
  private lastSave = 0;
  private mapFrame = 0;
  private skidTimer = 0;
  showHints = true;

  constructor() {
    this.camera = new THREE.PerspectiveCamera(62, 1, 0.15, 1400);
    this.isMobile =
      typeof window !== 'undefined' &&
      (('ontouchstart' in window && navigator.maxTouchPoints > 0) ||
        /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent));
    this.hud = this.buildHud();
  }

  // ------------------------------------------------------------------ setup
  init(canvas: HTMLCanvasElement, quality: Quality) {
    this.initRenderer(canvas, quality);
    this.initScene(quality);
    this.bindInput(canvas);
    this.resize();
    window.addEventListener('resize', () => this.resize());
    this.loop();
  }

  private initRenderer(canvas: HTMLCanvasElement, quality: Quality) {
    this.quality = quality;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: quality !== 'low',
      powerPreference: 'high-performance',
      alpha: false,
      stencil: false,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, quality === 'high' ? 2 : 1.35));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = quality === 'low' ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
  }

  private initScene(quality: Quality) {
    this.scene.fog = this.fog;
    this.scene.add(this.hemi, this.ambient, this.sun);
    this.sun.castShadow = true;
    const shadowSize = quality === 'high' ? 2048 : quality === 'medium' ? 1536 : 1024;
    this.sun.shadow.mapSize.set(shadowSize, shadowSize);
    const cam = this.sun.shadow.camera as THREE.OrthographicCamera;
    cam.left = -95;
    cam.right = 95;
    cam.top = 95;
    cam.bottom = -95;
    cam.near = 1;
    cam.far = 420;
    this.sun.shadow.bias = -0.0009;
    this.sun.shadow.normalBias = 0.035;

    this.world = new World(quality);
    this.world.build();
    this.scene.add(this.world.group);

    this.peds = new PedManager(this.world);
    this.peds.setDensity(quality);
    this.traffic = new TrafficManager(this.world);
    this.traffic.setDensity(quality);
    this.scene.add(this.peds.group, this.traffic.group);

    // player
    this.playerHuman = new Human({
      shirt: 0x1f2b3d,
      pants: 0x22252b,
      hair: 0x241a12,
      height: 1.83,
      bulk: 1.02,
    });
    this.playerGroup.add(this.playerHuman.group);
    this.scene.add(this.playerGroup);

    // CHOP
    this.dog = new Dog();
    this.dogGroup.add(this.dog.group);
    this.scene.add(this.dogGroup);

    // interiors
    const villa = buildLuxuryHouse();
    villa.group.position.set(0, 0, 0);
    this.interiors.set('villa', villa);
    this.scene.add(villa.group);
    villa.group.visible = false;

    const phone = buildShopInterior('phone', 'phone', 'CITY PHONE', 0x2f9d5b);
    phone.group.position.set(0, 0, 0);
    this.interiors.set('phone', phone);
    this.scene.add(phone.group);
    phone.group.visible = false;

    const mod = buildShopInterior('mod', 'mod', 'TORQUE GARAGE', 0xd4622a);
    mod.group.position.set(0, 0, 0);
    this.interiors.set('mod', mod);
    this.scene.add(mod.group);
    mod.group.visible = false;

    const police = buildShopInterior('police', 'police', 'SOLSTICE POLICE HQ', 0x2b4a8c);
    police.group.position.set(0, 0, 0);
    this.interiors.set('police', police);
    this.scene.add(police.group);
    police.group.visible = false;

    const mall = buildShopInterior('mall', 'mall', 'SOLSTICE GRAND MALL', 0x9a5fc4);
    mall.group.position.set(0, 0, 0);
    this.interiors.set('mall', mall);
    this.scene.add(mall.group);
    mall.group.visible = false;

    // vehicles
    this.spawnStartingVehicles();

    // mission marker
    const markerMat = new THREE.MeshBasicMaterial({
      color: 0xffc53d,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    });
    this.marker = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 6, 20, 1, true), markerMat);
    this.marker.visible = false;
    this.scene.add(this.marker);
    const arrowMat = new THREE.MeshBasicMaterial({ color: 0xffd979, transparent: true, opacity: 0.95 });
    this.markerArrow = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.4, 4), arrowMat);
    this.markerArrow.rotation.x = Math.PI;
    this.marker.visible = false;
    this.scene.add(this.markerArrow);

    // collectible packages for mission 3
    const pkgMat = new THREE.MeshStandardMaterial({
      color: 0xd9a441,
      emissive: 0x604010,
      emissiveIntensity: 0.5,
      roughness: 0.6,
    });
    const pkgGeo = new THREE.BoxGeometry(0.7, 0.5, 0.5);
    [
      [120, -40],
      [-80, 90],
      [40, 330],
    ].forEach(([px, pz]) => {
      const m = new THREE.Mesh(pkgGeo, pkgMat);
      m.position.set(px, 0.8, pz);
      m.castShadow = true;
      this.scene.add(m);
      this.packages.push({ mesh: m, x: px, z: pz, taken: false });
    });

    // collectible pickups scattered across the city
    this.spawnPickups();

    // job board marker in front of the villa
    const jobMarker = new THREE.Mesh(
      new THREE.CylinderGeometry(1.8, 1.8, 5, 18, 1, true),
      new THREE.MeshBasicMaterial({
        color: 0xffc53d,
        transparent: true,
        opacity: 0.35,
        depthWrite: false,
      })
    );
    jobMarker.position.set(-450, 2.5, -428);
    this.scene.add(jobMarker);
    this.jobMarker = jobMarker;
    const jobSign = new THREE.Mesh(
      new THREE.PlaneGeometry(2.6, 0.8),
      new THREE.MeshStandardMaterial({
        color: 0x1a1408,
        emissive: 0xffc53d,
        emissiveIntensity: 1.4,
        side: THREE.DoubleSide,
      })
    );
    jobSign.position.set(-450, 4.2, -428);
    this.scene.add(jobSign);

    // rain
    this.setupRain(quality);

    // environment reflections
    try {
      this.pmrem = new THREE.PMREMGenerator(this.renderer);
      this.updateEnvironment(true);
    } catch (e) {
      console.warn('environment reflections unavailable', e);
    }

    // Spawn the player inside the luxury villa
    villa.returnTo.set(-450, 0, -436);
    this.enterInterior('villa');
    window.addEventListener('resize', () => this.resize());
    this.loop();
  }

  private pickups: {
    mesh: THREE.Mesh;
    kind: string;
    x: number;
    z: number;
    taken: boolean;
    timer: number;
  }[] = [];
  jobMarker!: THREE.Mesh;

  private spawnPickups() {
    const kinds = [
      { k: 'cash', color: 0x4ad07a, amount: 60 },
      { k: 'cash', color: 0x4ad07a, amount: 120 },
      { k: 'medkit', color: 0xe05555, amount: 1 },
      { k: 'ammo', color: 0xd9a441, amount: 1 },
    ];
    const rng = makeRng(5150);
    const geo = new THREE.OctahedronGeometry(0.34, 0);
    for (let i = 0; i < 46; i++) {
      const x = rand(rng, -700, 700);
      const z = rand(rng, -700, 700);
      const kind = kinds[Math.floor(rng() * kinds.length)];
      const mat = new THREE.MeshStandardMaterial({
        color: kind.color,
        emissive: kind.color,
        emissiveIntensity: 0.8,
        roughness: 0.35,
        metalness: 0.3,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, 1.1, z);
      mesh.castShadow = true;
      this.scene.add(mesh);
      this.pickups.push({ mesh, kind: kind.k, x, z, taken: false, timer: 0 });
    }
  }

  private updatePickups(dt: number) {
    for (const p of this.pickups) {
      if (p.taken) {
        p.timer -= dt;
        if (p.timer <= 0) {
          p.taken = false;
          p.mesh.visible = true;
        }
        continue;
      }
      p.mesh.rotation.y += dt * 1.6;
      p.mesh.position.y = 1.1 + Math.sin(performance.now() / 600 + p.x) * 0.12;
      if (
        !this.currentInterior &&
        Math.hypot(p.x - this.playerPos.x, p.z - this.playerPos.z) < 1.8
      ) {
        p.taken = true;
        p.timer = 45;
        p.mesh.visible = false;
        if (p.kind === 'cash') {
          this.money += 60 + Math.random() * 90;
          this.notify('+$' + Math.floor(this.money).toLocaleString(), 'good');
        } else if (p.kind === 'medkit') {
          this.giveItem('medkit', 1, true);
          this.notify('Found a Field Medkit', 'good');
        } else {
          this.giveItem('pistolammo', 1, true);
          this.notify('Found pistol rounds', 'good');
        }
        audio.pickup();
      }
    }
  }

  private setupRain(quality: Quality) {
    const count = quality === 'high' ? 9000 : quality === 'medium' ? 5000 : 2600;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 90;
      pos[i * 3 + 1] = Math.random() * 45;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xaaccee,
      size: 0.11,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    this.rainPoints = new THREE.Points(geo, mat);
    this.rainPoints.frustumCulled = false;
    this.rainPoints.visible = false;
    this.scene.add(this.rainPoints);
  }

  private spawnStartingVehicles() {
    const spawn = (type: string, x: number, z: number, heading: number, color: number, plate: string) => {
      const v = new Vehicle(type, color, plate);
      v.pos.set(x, 0, z);
      v.heading = heading;
      v.group.position.copy(v.pos);
      v.group.rotation.y = heading;
      this.vehicles.push(v);
      this.scene.add(v.group);
      return v;
    };
    // the player's M8 on the driveway, nose pointing at the street
    this.playerCar = spawn('m8', -442, -430, 0, 0x101216, 'SOL-8001');
    this.playerCar.addHeadlightSpot();
    spawn('sedan', -461, -434, Math.PI, 0xe8e9ec, 'SOL-4417');
    spawn('suv', -437, -425, Math.PI * 0.5, 0x2a3f6b, 'SOL-2093');
    spawn('ev', -458, -418, -Math.PI * 0.5, 0xd7d9de, 'SOL-7742');
    spawn('taxi', -300, 150, 0, 0xf2c114, 'TAXI-042');
    spawn('vip', 150, 50, Math.PI, 0x0a0b0d, 'VIP-0001');
    spawn('bus', -150, -300, Math.PI / 2, 0x2f6f7d, 'BUS-0088');
    spawn('van', 250, 300, 0, 0xf4f5f7, 'SOL-3120');
    spawn('super', 250, -150, Math.PI * 0.5, 0xd8d9dd, 'VIP-0888');
    for (let i = 0; i < 4; i++) {
      const pv = spawn('police', 12 + i * 9, 268 + (i % 2) * 7, Math.PI, 0x1b1e24, 'POL-' + (100 + i));
      pv.isPolice = true;
      pv.sirenOn = true;
    }
  }

  playerCar!: Vehicle;

  // ------------------------------------------------------------------ input
  private bindInput(canvas: HTMLCanvasElement) {
    const kd = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      this.onKeyDown(e);
      if (
        ['Space', 'Tab', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(
          e.code
        )
      )
        e.preventDefault();
    };
    const ku = (e: KeyboardEvent) => this.keys.delete(e.code);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    window.addEventListener('blur', () => this.keys.clear());

    canvas.addEventListener('mousedown', (e) => {
      if (!this.pointerLocked && !this.isMobile) {
        canvas.requestPointerLock?.();
        return;
      }
      if (e.button === 0) this.mouseDown = true;
      if (e.button === 2) this.rightDown = true;
      audio.resume();
    });
    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.mouseDown = false;
      if (e.button === 2) this.rightDown = false;
    });
    window.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('mousemove', (e) => {
      if (!this.pointerLocked) return;
      this.camYaw -= e.movementX * this.sensitivity;
      this.camPitch += (this.invertY ? -1 : 1) * e.movementY * this.sensitivity;
      this.camPitch = clamp(this.camPitch, -0.9, 1.25);
    });
    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement === canvas;
      if (!this.pointerLocked && !this.phoneOpen && !this.mapOpen && !this.inventoryOpen && !this.isMobile) {
        this.paused = true;
        this.publishHud(true);
      }
    });
    canvas.addEventListener(
      'touchstart',
      (e) => {
        audio.resume();
        const t = e.touches[0];
        if (t) {
          this.touch.ldx += t.clientX - (this.touch as any).lx || 0;
          (this.touch as any).lx = t.clientX;
        }
      },
      { passive: true }
    );
  }

  private onKeyDown(e: KeyboardEvent) {
    if (e.repeat) return;
    const c = e.code;
    if (this.jailed) {
      if (c === 'Escape') this.paused = !this.paused;
      return;
    }
    switch (c) {
      case 'Escape':
        if (this.phoneOpen) this.closePhone();
        else if (this.mapOpen) this.mapOpen = false;
        else if (this.inventoryOpen) this.inventoryOpen = false;
        else if (this.wheelOpen) this.wheelOpen = false;
        else if (this.settingsOpen) this.settingsOpen = false;
        else {
          this.paused = !this.paused;
          if (this.paused && this.pointerLocked) document.exitPointerLock();
        }
        this.publishHud(true);
        break;
      case 'KeyP':
        this.togglePhone();
        break;
      case 'Tab':
      case 'KeyI':
        this.inventoryOpen = !this.inventoryOpen;
        this.publishHud(true);
        break;
      case 'KeyM':
        this.mapOpen = !this.mapOpen;
        this.publishHud(true);
        break;
      case 'KeyQ':
        this.wheelOpen = !this.wheelOpen;
        this.publishHud(true);
        break;
      case 'KeyE':
        this.interact();
        break;
      case 'KeyF':
        this.tryPunch();
        break;
      case 'KeyC':
        this.toggleSit();
        break;
      case 'KeyR':
        this.reload();
        break;
      case 'KeyH':
        audio.horn(this.inVehicle ? 'car' : 'car');
        break;
      case 'Digit1':
      case 'Digit2':
      case 'Digit3':
      case 'Digit4':
      case 'Digit5':
      case 'Digit6': {
        const idx = parseInt(e.code.slice(5), 10) - 1;
        const wid = WEAPON_ORDER[idx];
        if (wid) this.selectWeapon(wid);
        break;
      }
      case 'Space':
        if (this.inVehicle) this.inVehicle.brake = 1;
        break;
    }
  }

  // ------------------------------------------------------------------ helpers
  notify(text: string, kind: Notification['kind'] = 'info') {
    this.notifications.unshift({ id: this.notifId++, text, kind });
    if (this.notifications.length > 5) this.notifications.pop();
    this.publishHud(true);
  }

  private key(code: string) {
    return this.keys.has(code);
  }

  private get moveVec() {
    let x = 0;
    let y = 0;
    if (this.key('KeyW') || this.key('ArrowUp')) y += 1;
    if (this.key('KeyS') || this.key('ArrowDown')) y -= 1;
    if (this.key('KeyD') || this.key('ArrowRight')) x += 1;
    if (this.key('KeyA') || this.key('ArrowLeft')) x -= 1;
    x += this.touch.mx;
    y += this.touch.my;
    const len = Math.hypot(x, y);
    if (len > 1) {
      x /= len;
      y /= len;
    }
    return { x, y };
  }

  private get sprintHeld() {
    return this.key('ShiftLeft') || this.key('ShiftRight') || !!this.buttons.run;
  }

  setButton(name: string, pressed: boolean) {
    this.buttons[name] = pressed;
    if (pressed) {
      audio.resume();
      switch (name) {
        case 'jump':
          if (this.inVehicle) this.inVehicle.brake = 1;
          else this.jump();
          break;
        case 'punch':
          this.tryPunch();
          break;
        case 'sit':
          this.toggleSit();
          break;
        case 'enter':
          this.interact();
          break;
        case 'fire':
          this.fireHeld = true;
          break;
        case 'weapon':
          this.wheelOpen = !this.wheelOpen;
          this.publishHud(true);
          break;
        case 'phone':
          this.togglePhone();
          break;
        case 'inventory':
          this.inventoryOpen = !this.inventoryOpen;
          this.publishHud(true);
          break;
        case 'map':
          this.mapOpen = !this.mapOpen;
          this.publishHud(true);
          break;
        case 'aim':
          this.aimMode = !this.aimMode;
          break;
        case 'horn':
          audio.horn('car');
          break;
      }
    } else if (name === 'fire') {
      this.fireHeld = false;
    }
  }

  fireHeld = false;

  look(dx: number, dy: number) {
    this.camYaw -= dx * this.sensitivity * 1.35;
    this.camPitch += (this.invertY ? -1 : 1) * dy * this.sensitivity * 1.35;
    this.camPitch = clamp(this.camPitch, -0.9, 1.25);
  }

  // ------------------------------------------------------------------ actions
  private jump() {
    if (this.grounded && !this.sitting && !this.inVehicle) {
      this.vy = 7.1;
      this.grounded = false;
    }
  }

  private toggleSit() {
    if (this.inVehicle) return;
    this.sitting = !this.sitting;
    this.notify(this.sitting ? 'Sat down' : 'Stood up');
  }

  private tryPunch() {
    if (this.inVehicle || this.sitting) return;
    this.punchTimer = 0.45;
    this.playerHuman.triggerPunch();
    // melee hit detection in front of player
    const fwd = new THREE.Vector3(Math.sin(this.playerHuman.group.rotation.y), 0, Math.cos(this.playerHuman.group.rotation.y));
    const origin = this.playerPos.clone().add(new THREE.Vector3(0, 1.2, 0));
    for (const p of this.peds.peds) {
      if (p.dead) continue;
      const to = p.pos.clone().sub(origin);
      const dist = to.length();
      if (dist < 2.3 && to.normalize().dot(fwd) > 0.35) {
        this.damagePed(p, 16, false);
        audio.hit();
        this.peds.panic(p.pos, 18);
        break;
      }
    }
  }

  private reload() {
    const w = WEAPONS[this.weapon];
    if (!w || w.ammo === 0) return;
    if (this.reserve[this.weapon] > 0) {
      this.ammo[this.weapon] = w.ammo * 10;
      this.notify(`Reloaded ${w.short}`);
      audio.beep(320, 0.08, 'square', 0.1);
    } else {
      this.notify('No ammo left', 'bad');
      audio.error();
    }
  }

  selectWeapon(id: string) {
    if (!WEAPONS[id]) return;
    if (id !== 'fists' && !this.ownsWeapon(id)) {
      this.notify(`You don't own the ${WEAPONS[id].short}`, 'bad');
      audio.error();
      return;
    }
    this.weapon = id;
    this.wheelOpen = false;
    this.refreshWeaponModel();
    this.publishHud(true);
  }

  ownsWeapon(id: string) {
    return this.inventory.some((i) => i.id === id && i.category === 'weapon');
  }

  useItem(id: string) {
    const entry = this.inventory.find((i) => i.id === id);
    if (!entry || entry.qty <= 0) return;
    const def = ITEMS[id];
    if (!def) return;
    if (def.heal) {
      if (this.health >= this.maxHealth) {
        this.notify('Already at full health', 'bad');
        return;
      }
      this.health = Math.min(this.maxHealth, this.health + def.heal);
      this.notify(`Used ${def.name} (+${def.heal} HP)`, 'good');
      audio.pickup();
    } else if (def.ammoFor) {
      this.reserve[def.ammoFor] = (this.reserve[def.ammoFor] || 0) + (def.amount || 0);
      this.notify(`+${def.amount} rounds for ${WEAPONS[def.ammoFor].short}`, 'good');
      audio.pickup();
    } else {
      this.notify(`${def.name} used`, 'good');
      audio.beep(520, 0.1, 'triangle', 0.12);
    }
    entry.qty -= 1;
    if (entry.qty <= 0) this.inventory = this.inventory.filter((i) => i.id !== id);
    this.publishHud(true);
  }

  giveItem(id: string, qty = 1, silent = false) {
    const def = ITEMS[id];
    if (!def) return;
    const found = this.inventory.find((i) => i.id === id);
    if (found) found.qty += qty;
    else
      this.inventory.push({
        id: def.id,
        name: def.name,
        category: def.category,
        icon: def.icon,
        qty,
        desc: def.desc,
      });
    if (!silent) {
      this.notify(`Picked up ${def.name}`, 'good');
      audio.pickup();
    }
    this.publishHud(true);
  }

  giveWeapon(id: string) {
    const w = WEAPONS[id];
    if (!w || id === 'fists') return;
    if (!this.ownsWeapon(id)) {
      this.inventory.push({
        id,
        name: w.name,
        category: 'weapon',
        icon: w.icon,
        qty: 1,
        desc: w.desc,
      });
      this.ammo[id] = w.ammo * 10;
      this.reserve[id] = w.ammo * 10;
    }
    this.publishHud(true);
  }

  // ------------------------------------------------------------------ weapon models
  private weaponMesh: THREE.Group | null = null;
  private muzzleLight: THREE.PointLight | null = null;
  private muzzleTimer = 0;

  private buildWeaponModel(id: string) {
    const g = new THREE.Group();
    const metal = new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.35, metalness: 0.85 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x14161a, roughness: 0.7 });
    const wood = new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.6 });
    const brass = new THREE.MeshStandardMaterial({ color: 0xb08d3c, roughness: 0.35, metalness: 0.9 });
    const add = (
      geo: THREE.BufferGeometry,
      mat: THREE.Material,
      x: number,
      y: number,
      z: number,
      rx = 0
    ) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z);
      m.rotation.x = rx;
      m.castShadow = true;
      g.add(m);
      return m;
    };
    if (id === 'eagle') {
      add(new THREE.BoxGeometry(0.05, 0.1, 0.26), metal, 0, -0.05, -0.1);
      add(new THREE.BoxGeometry(0.045, 0.14, 0.07), dark, 0, -0.13, 0.02, 0.28);
      add(new THREE.CylinderGeometry(0.017, 0.017, 0.13, 8), metal, 0, -0.05, -0.24, Math.PI / 2);
      add(new THREE.BoxGeometry(0.04, 0.05, 0.05), brass, 0, 0.02, -0.02);
      add(new THREE.BoxGeometry(0.012, 0.05, 0.012), metal, 0, 0.04, -0.16);
    } else if (id === 'sniper') {
      add(new THREE.BoxGeometry(0.05, 0.08, 0.9), dark, 0, -0.05, -0.35);
      add(new THREE.CylinderGeometry(0.014, 0.016, 0.6, 8), metal, 0, -0.05, -0.85, Math.PI / 2);
      add(new THREE.CylinderGeometry(0.03, 0.03, 0.26, 10), metal, 0, 0.04, -0.18, Math.PI / 2);
      add(new THREE.BoxGeometry(0.05, 0.12, 0.26), wood, 0, -0.14, 0.05, 0.25);
      add(new THREE.BoxGeometry(0.04, 0.06, 0.16), metal, 0, -0.02, 0.22);
    } else if (id === 'rpg') {
      add(new THREE.CylinderGeometry(0.05, 0.05, 1.25, 12), metal, 0, -0.06, -0.4, Math.PI / 2);
      add(new THREE.ConeGeometry(0.06, 0.18, 10), dark, 0, -0.06, -1.05, -Math.PI / 2);
      add(new THREE.BoxGeometry(0.04, 0.09, 0.2), dark, 0, -0.12, 0.06, 0.2);
      add(new THREE.BoxGeometry(0.05, 0.1, 0.1), wood, 0, -0.06, 0.3);
    } else if (id === 'grenade' || id === 'smoke') {
      add(
        new THREE.SphereGeometry(0.055, 10, 8),
        id === 'smoke'
          ? new THREE.MeshStandardMaterial({ color: 0x3d4a3a, roughness: 0.8 })
          : new THREE.MeshStandardMaterial({ color: 0x3a4a32, roughness: 0.75 }),
        0,
        -0.09,
        0
      );
      add(new THREE.CylinderGeometry(0.018, 0.018, 0.03, 8), metal, 0, -0.03, 0);
    }
    return g;
  }

  private refreshWeaponModel() {
    if (!this.playerHuman?.joints?.handR) return;
    if (this.weaponMesh) {
      this.playerHuman.joints.handR.remove(this.weaponMesh);
      this.weaponMesh = null;
    }
    if (this.weapon === 'fists') return;
    const m = this.buildWeaponModel(this.weapon);
    m.position.set(0, -0.07, 0.03);
    m.rotation.set(-0.25, 0, 0);
    this.playerHuman.joints.handR.add(m);
    this.weaponMesh = m;
  }

  // ------------------------------------------------------------------ combat
  private fire() {
    const w = WEAPONS[this.weapon];
    if (!w) return;
    if (this.fireTimer > 0) return;
    if (this.weapon === 'fists') {
      this.fireTimer = w.fireRate;
      this.tryPunch();
      return;
    }
    if (w.ammo > 0 && (this.ammo[this.weapon] || 0) <= 0) {
      this.notify('Out of ammo — press R to reload', 'bad');
      this.fireTimer = 0.35;
      audio.error();
      return;
    }
    this.fireTimer = w.fireRate;
    if (w.ammo > 0) this.ammo[this.weapon] = (this.ammo[this.weapon] || 0) - 1;
    this.playerHuman.triggerShoot();

    if (w.projectile) {
      this.spawnProjectile(w);
      this.flashMuzzle();
      audio.shot(w.sound);
      return;
    }

    // hitscan
    const origin = this.camera.getWorldPosition(new THREE.Vector3());
    const dir = this.camera.getWorldDirection(new THREE.Vector3());
    dir.x += (Math.random() - 0.5) * w.spread * 3;
    dir.y += (Math.random() - 0.5) * w.spread * 3;
    dir.normalize();
    const end = origin.clone().addScaledVector(dir, w.range);

    // peds
    let hitSomething = false;
    for (const p of this.peds.peds) {
      if (p.dead) continue;
      const to = p.pos.clone().setY(1.0).sub(origin);
      const proj = to.dot(dir);
      if (proj < 0 || proj > w.range) continue;
      const closest = origin.clone().addScaledVector(dir, proj);
      const d = closest.distanceTo(p.pos.clone().setY(1.0));
      if (d < 0.85) {
        this.damagePed(p, w.damage, true);
        hitSomething = true;
        this.spawnImpact(closest, 0xff6a4a);
        break;
      }
    }
    if (!hitSomething) {
      // world hit
      const wall = this.rayWorld(origin, dir, w.range);
      if (wall) this.spawnImpact(wall, 0xdddddd);
    }
    this.spawnTracer(origin, end);
    this.flashMuzzle();
    audio.shot(w.sound);
    if (this.nearbyPeds(18).length > 0) this.peds.panic(this.playerPos, 26);
  }

  private flashMuzzle() {
    if (!this.muzzleLight) {
      this.muzzleLight = new THREE.PointLight(0xffcf7a, 0, 9, 2);
      this.scene.add(this.muzzleLight);
    }
    const hand = this.playerHuman.joints.handR;
    const p = new THREE.Vector3(0, -0.2, -0.1);
    hand.localToWorld(p);
    this.muzzleLight.position.copy(p);
    this.muzzleLight.intensity = 14;
    this.muzzleTimer = 0.06;
  }

  private nearbyPeds(r: number) {
    return this.peds.peds.filter((p) => !p.dead && p.pos.distanceTo(this.playerPos) < r);
  }

  private damagePed(p: any, dmg: number, byWeapon: boolean) {
    p.hp -= dmg;
    p.hitFlash = 1;
    if (p.hp <= 0) {
      p.setDead();
      this.addWanted(byWeapon ? 2 : 1);
      this.notify(p.isCop ? 'Officer down' : 'Civilian down', 'bad');
    } else if (p.isCop) {
      this.addWanted(1);
    }
  }

  private rayWorld(origin: THREE.Vector3, dir: THREE.Vector3, maxDist: number) {
    const boxes = this.world.collidersNear(
      origin.x + dir.x * maxDist * 0.5,
      origin.z + dir.z * maxDist * 0.5
    );
    let best: THREE.Vector3 | null = null;
    let bestT = maxDist;
    for (const b of boxes) {
      const t = this.rayBox(origin, dir, b.minX, b.maxX, b.minZ, b.maxZ, b.top);
      if (t !== null && t < bestT) {
        bestT = t;
        best = origin.clone().addScaledVector(dir, t);
      }
    }
    return best;
  }

  private rayBox(
    o: THREE.Vector3,
    d: THREE.Vector3,
    minX: number,
    maxX: number,
    minZ: number,
    maxZ: number,
    top: number
  ) {
    let tmin = 0;
    let tmax = Infinity;
    const axes: [number, number, number, number][] = [
      [o.x, d.x, minX, maxX],
      [o.z, d.z, minZ, maxZ],
      [o.y, d.y, 0, top],
    ];
    for (const [ov, dv, mn, mx] of axes) {
      if (Math.abs(dv) < 1e-6) {
        if (ov < mn || ov > mx) return null;
      } else {
        let t1 = (mn - ov) / dv;
        let t2 = (mx - ov) / dv;
        if (t1 > t2) [t1, t2] = [t2, t1];
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) return null;
      }
    }
    return tmin;
  }

  private spawnProjectile(w: typeof WEAPONS[string]) {
    const origin = this.camera.getWorldPosition(new THREE.Vector3());
    const dir = this.camera.getWorldDirection(new THREE.Vector3());
    const kind = w.projectile!;
    let geo: THREE.BufferGeometry;
    let mat: THREE.Material;
    if (kind === 'rpg') {
      geo = new THREE.CylinderGeometry(0.12, 0.14, 0.9, 10);
      mat = new THREE.MeshStandardMaterial({ color: 0x6b6f57, roughness: 0.6 });
      geo.rotateX(Math.PI / 2);
    } else if (kind === 'smoke') {
      geo = new THREE.CylinderGeometry(0.11, 0.11, 0.24, 8);
      mat = new THREE.MeshStandardMaterial({ color: 0x3d4a3a, roughness: 0.8 });
    } else {
      geo = new THREE.SphereGeometry(0.13, 8, 6);
      mat = new THREE.MeshStandardMaterial({ color: 0x3a4a32, roughness: 0.75 });
    }
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(origin).addScaledVector(dir, 0.8);
    mesh.castShadow = true;
    this.scene.add(mesh);
    const speed = kind === 'rpg' ? 58 : 24;
    const vel = dir.clone().multiplyScalar(speed);
    this.projectiles.push({
      mesh,
      vel,
      life: kind === 'rpg' ? 6 : 3.2,
      kind,
      fuse: kind === 'grenade' ? 2.4 : 0,
      dmg: w.damage,
    });
  }

  private spawnTracer(from: THREE.Vector3, to: THREE.Vector3) {
    const geo = new THREE.BufferGeometry().setFromPoints([from, to]);
    const mat = new THREE.LineBasicMaterial({ color: 0xfff0b0, transparent: true, opacity: 0.85 });
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);
    this.effects.push({ obj: line, life: 0.08, max: 0.08, kind: 'tracer' });
  }

  private spawnImpact(pos: THREE.Vector3, color: number) {
    const mat = new THREE.SpriteMaterial({
      map: glowTexture(),
      color,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const s = new THREE.Sprite(mat);
    s.position.copy(pos);
    s.scale.setScalar(0.8);
    this.scene.add(s);
    this.effects.push({ obj: s, life: 0.22, max: 0.22, kind: 'spark' });
  }

  private spawnExplosion(pos: THREE.Vector3, radius: number, smoke: boolean) {
    if (smoke) {
      const count = 14;
      for (let i = 0; i < count; i++) {
        const mat = new THREE.SpriteMaterial({
          map: glowTexture(),
          color: 0x9aa5a8,
          transparent: true,
          opacity: 0.75,
          depthWrite: false,
        });
        const s = new THREE.Sprite(mat);
        s.position.copy(pos);
        s.scale.setScalar(2 + Math.random() * 3);
        this.scene.add(s);
        this.effects.push({ obj: s, life: 6 + Math.random() * 3, max: 9, kind: 'smoke' });
      }
      return;
    }
    const mat = new THREE.SpriteMaterial({
      map: glowTexture(),
      color: 0xffa33c,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const s = new THREE.Sprite(mat);
    s.position.copy(pos);
    s.scale.setScalar(radius * 0.7);
    this.scene.add(s);
    this.effects.push({ obj: s, life: 0.5, max: 0.5, kind: 'fire' });
    const light = new THREE.PointLight(0xff8833, 20, radius * 6, 2);
    light.position.copy(pos);
    this.scene.add(light);
    this.effects.push({ obj: light, life: 0.35, max: 0.35, kind: 'light' });
    audio.explosion();
    // damage
    for (const p of this.peds.peds) {
      if (p.dead) continue;
      const d = p.pos.distanceTo(pos);
      if (d < radius) this.damagePed(p, 120, true);
    }
  }

  private addWanted(amount: number) {
    const before = this.wanted;
    this.wanted = clamp(this.wanted + amount, 0, 5);
    this.wantedHeat = 40;
    if (this.wanted > before) {
      this.notify(`WANTED ${'★'.repeat(this.wanted)}`, 'bad');
      audio.beep(220, 0.2, 'sawtooth', 0.12);
    }
  }

  clearWanted() {
    if (this.wanted > 0) this.notify('You lost the police', 'good');
    this.wanted = 0;
    this.wantedHeat = 0;
  }

  // ------------------------------------------------------------------ wanted / police
  private updatePolice(dt: number) {
    if (this.wanted <= 0) {
      // remove police cars
      for (let i = this.policeCars.length - 1; i >= 0; i--) {
        const c = this.policeCars[i];
        this.scene.remove(c.group);
        this.policeCars.splice(i, 1);
      }
      audio.setSiren(false);
      return;
    }
    this.wantedHeat -= dt;
    this.policeSpawnTimer -= dt;
    if (this.policeSpawnTimer <= 0 && this.policeCars.length < Math.min(4, this.wanted)) {
      this.policeSpawnTimer = 2.4;
      const ang = Math.random() * Math.PI * 2;
      const r = 70 + Math.random() * 40;
      const car = new Vehicle(
        'police',
        0x1b1e24,
        'POL-' + Math.floor(1000 + Math.random() * 8999),
        true
      );
      car.sirenOn = true;
      car.pos.set(this.playerPos.x + Math.cos(ang) * r, 0, this.playerPos.z + Math.sin(ang) * r);
      car.heading = Math.atan2(this.playerPos.x - car.pos.x, this.playerPos.z - car.pos.z);
      car.group.position.copy(car.pos);
      this.scene.add(car.group);
      this.policeCars.push(car);
    }
    // chase
    for (const car of this.policeCars) {
      const to = this.playerPos.clone().sub(car.pos).setY(0);
      const dist = to.length();
      const desired = Math.atan2(to.x, to.z);
      car.heading = angleLerp(car.heading, desired, 1 - Math.exp(-2.6 * dt));
      const targetSpeed = dist > 12 ? 34 : 16;
      car.speed = damp(car.speed, targetSpeed, 2.5, dt);
      car.pos.addScaledVector(new THREE.Vector3(Math.sin(car.heading), 0, Math.cos(car.heading)), car.speed * dt);
      car.updateVisual(dt, performance.now() / 1000);
      car.setLightsOn(true);
      car.group.position.copy(car.pos);
      car.group.rotation.y = car.heading;
      // ram damage
      if (dist < 3.4 && car.speed > 12) {
        this.damagePlayer(car.speed * 0.35, 'police');
        car.speed *= 0.5;
      }
    }
    audio.setSiren(true);
    // cops on foot
    if (this.wanted >= 2 && Math.random() < dt * 0.22) {
      const ang = Math.random() * Math.PI * 2;
      const r = 22 + Math.random() * 14;
      const cop = this.peds.spawnCop(this.playerPos.x + Math.cos(ang) * r, this.playerPos.z + Math.sin(ang) * r);
      cop.state = 'chase';
    }
    const cop = this.peds.nearestCop(this.playerPos, 2.6);
    if (cop) this.busted();
  }

  private busted() {
    if (this.jailed) return;
    this.jailed = true;
    this.jailEnd = Date.now() + JAIL_MS;
    this.health = Math.max(this.health, 55);
    this.wanted = 0;
    this.money = Math.max(0, this.money - 500);
    this.enterInterior('police');
    this.playerPos.set(4.4, 0.05, 4.6);
    this.notify('Busted! 3 hour sentence', 'bad');
    audio.error();
    this.save();
    this.publishHud(true);
  }

  private damagePlayer(amount: number, source: string) {
    if (this.dead) return;
    this.health -= amount;
    this.damageFlash = Math.min(1, this.damageFlash + amount / 40);
    this.damageDirs.push({ angle: Math.random() * 6.28, life: 1.6 });
    if (amount > 6) audio.hit();
    if (this.health <= 0) {
      this.health = 0;
      this.dead = true;
      this.respawnTimer = 3.2;
      this.playerHuman.setPose('dead');
      this.notify('You died — respawning at the hospital', 'bad');
    }
    void source;
  }

  // ------------------------------------------------------------------ interiors
  currentInterior: Interior | null = null;

  private enterInterior(id: string) {
    const it = this.interiors.get(id);
    if (!it) return;
    this.currentInterior = it;
    this.world.group.visible = false;
    this.peds.group.visible = false;
    this.traffic.group.visible = false;
    for (const v of this.vehicles) v.group.visible = false;
    for (const v of this.policeCars) v.group.visible = false;
    it.group.visible = true;
    this.playerPos.copy(it.spawn);
    this.playerVel.set(0, 0, 0);
    this.vy = 0;
    this.grounded = true;
    this.publishHud(true);
  }

  private exitInterior() {
    const it = this.currentInterior;
    if (!it) return;
    it.group.visible = false;
    this.currentInterior = null;
    this.world.group.visible = true;
    this.peds.group.visible = true;
    this.traffic.group.visible = true;
    for (const v of this.vehicles) v.group.visible = true;
    for (const v of this.policeCars) v.group.visible = true;
    this.playerPos.copy(it.returnTo);
    this.playerVel.set(0, 0, 0);
    this.vy = 0;
    this.publishHud(true);
  }

  // ------------------------------------------------------------------ interaction
  private interact() {
    if (this.inVehicle) {
      this.exitVehicle();
      return;
    }
    // shop counter
    const it = this.currentInterior;
    if (it && it.shopItems && it.shopItems.length) {
      this.shopTarget = it;
      this.shopOpen = !this.shopOpen;
      this.publishHud(true);
      if (this.shopOpen) this.notify('Store counter opened', 'good');
      return;
    }
    // exit door
    if (it && this.playerPos.distanceTo(it.exit) < 2.4) {
      this.exitInterior();
      this.notify('Back outside');
      return;
    }
    // vehicles
    const v = this.nearestVehicle(3.4);
    if (v) {
      this.enterVehicle(v);
      return;
    }
    // job board
    if (!this.inVehicle && Math.hypot(this.playerPos.x + 450, this.playerPos.z + 428) < 3.2) {
      this.startNextMission();
      return;
    }
    // landmarks
    const lm = this.nearestLandmarkDoor(4.5);
    if (lm && lm.interior) {
      const target = this.interiors.get(lm.interior);
      if (target) {
        target.returnTo.copy(this.playerPos);
        this.enterInterior(lm.interior);
        this.notify(`Entered ${lm.name}`);
      }
    }
  }

  shopTarget: Interior | null = null;

  private nearestVehicle(maxDist: number) {
    let best: Vehicle | null = null;
    let bd = maxDist;
    for (const v of this.vehicles) {
      const d = v.pos.distanceTo(this.playerPos);
      if (d < bd) {
        bd = d;
        best = v;
      }
    }
    return best;
  }

  private nearestLandmarkDoor(maxDist: number) {
    let best: any = null;
    let bd = maxDist;
    for (const l of LANDMARKS) {
      if (!l.interior) continue;
      const d = Math.hypot(l.doorX - this.playerPos.x, l.doorZ - this.playerPos.z);
      if (d < bd) {
        bd = d;
        best = l;
      }
    }
    return best;
  }

  private enterVehicle(v: Vehicle) {
    this.inVehicle = v;
    this.sitting = false;
    // put the camera directly behind the car
    this.camYaw = v.heading + Math.PI;
    this.camPitch = 0.14;
    this.playerGroup.visible = false;
    this.dogGroup.visible = false;
    audio.beep(300, 0.08, 'square', 0.1);
    this.notify(`Entered ${v.spec.displayName}`);
    if (v.spec.type === 'm8' || v.spec.type === 'super') this.notify('Engine: V8 twin-turbo', 'info');
  }

  private exitVehicle() {
    const v = this.inVehicle;
    if (!v) return;
    const side = new THREE.Vector3(Math.cos(v.heading), 0, -Math.sin(v.heading));
    this.playerPos.copy(v.pos).addScaledVector(side, 1.9);
    this.playerPos.y = 0;
    this.inVehicle = null;
    this.playerGroup.visible = true;
    this.dogGroup.visible = true;
    audio.beep(240, 0.08, 'square', 0.08);
  }

  // ------------------------------------------------------------------ missions
  startMission(id: string) {
    const idx = MISSIONS.findIndex((m) => m.id === id);
    if (idx < 0) return;
    const st = this.missions[idx];
    if (st.state === 'done') {
      this.notify('Mission already completed');
      return;
    }
    this.missionIndex = idx;
    this.missionStage = 0;
    this.missionCollected = 0;
    this.escapeTimer = 0;
    for (let i = 0; i < this.missions.length; i++) {
      if (this.missions[i].state === 'locked') this.missions[i].state = 'active';
    }
    this.missions[idx].state = 'active';
    this.notify(`Mission started: ${MISSIONS[idx].title}`, 'good');
    audio.notify();
    this.publishHud(true);
  }

  startNextMission() {
    const idx = this.missions.findIndex((m) => m.state !== 'done');
    if (idx < 0) {
      this.notify('All jobs completed — free roam!', 'good');
      return;
    }
    this.startMission(MISSIONS[idx].id);
  }

  private updateMissions(dt: number) {
    if (this.missionIndex < 0) return;
    const m = MISSIONS[this.missionIndex];
    const target = new THREE.Vector3(m.target[0], 0, m.target[1]);
    let done = false;
    void this.packages;
    if (m.type === 'goto') {
      if (this.playerPos.distanceTo(target) < 9) done = true;
    } else if (m.type === 'vehicle') {
      if (m.vehicleType && (!this.inVehicle || this.inVehicle.spec.type !== m.vehicleType)) {
        const has = this.vehicles.some((v) => v.spec.type === m.vehicleType);
        if (!has) {
          this.notify('Find the vehicle first', 'bad');
        }
      } else if (this.playerPos.distanceTo(target) < 12) {
        done = true;
      }
    } else if (m.type === 'collect') {
      for (const p of this.packages) {
        if (!p.taken && Math.hypot(p.x - this.playerPos.x, p.z - this.playerPos.z) < 2.2) {
          p.taken = true;
          p.mesh.visible = false;
          this.missionCollected++;
          this.notify(`Package ${this.missionCollected}/${m.collectCount}`, 'good');
          audio.pickup();
        }
      }
      if (this.missionCollected >= (m.collectCount || 3) && this.playerPos.distanceTo(target) < 12) done = true;
    } else if (m.type === 'escape') {
      if (!this.inVehicle) {
        if (this.missionStage === 0) {
          this.notify('Get into any vehicle to start the escape', 'bad');
        }
      } else {
        if (this.missionStage === 0) {
          this.missionStage = 1;
          this.addWanted(2);
          this.escapeTimer = 45;
          this.notify('Lose the police!', 'bad');
        }
        this.escapeTimer -= dt;
        if (this.wanted === 0) this.escapeTimer -= dt * 2;
        if (this.escapeTimer <= 0) done = true;
      }
    }
    if (done) {
      this.money += m.reward;
      this.missions[this.missionIndex].state = 'done';
      this.notify(`Mission complete! +$${m.reward}`, 'good');
      audio.notify();
      this.missionIndex = -1;
      if (this.marker) this.marker.visible = false;
      this.publishHud(true);
    }
  }

  private updateMarker() {
    if (this.missionIndex < 0) {
      this.marker.visible = false;
      this.markerArrow.visible = false;
      return;
    }
    const m = MISSIONS[this.missionIndex];
    const t = new THREE.Vector3(m.target[0], 0, m.target[1]);
    this.marker.visible = true;
    this.marker.position.set(t.x, 3, t.z);
    this.markerArrow.visible = true;
    this.markerArrow.position.set(t.x, 7 + Math.sin(performance.now() / 300) * 0.4, t.z);
  }

  // ------------------------------------------------------------------ phone
  togglePhone() {
    this.phoneOpen = !this.phoneOpen;
    if (this.phoneOpen) {
      this.phoneApp = 'home';
      this.mapOpen = false;
      this.inventoryOpen = false;
      if (this.pointerLocked) document.exitPointerLock();
    }
    this.publishHud(true);
  }
  closePhone() {
    this.phoneOpen = false;
    this.phoneApp = null;
    this.publishHud(true);
    setTimeout(() => this.requestLock(), 60);
  }
  openPhoneApp(app: string) {
    this.phoneApp = app;
    audio.click();
    this.publishHud(true);
  }
  buyItem(id: string, price: number) {
    if (this.money < price) {
      this.notify('Not enough money', 'bad');
      audio.error();
      return false;
    }
    this.money -= price;
    if (id === 'ammo') {
      this.reserve.eagle = (this.reserve.eagle || 0) + 40;
      this.ammo.eagle = (this.ammo.eagle || 0) + 40;
      this.notify('Bought Pistol Rounds x40', 'good');
    } else if (id === 'grenade' || id === 'smoke') {
      this.giveWeapon(id);
      this.notify(`Bought ${WEAPONS[id].name}`, 'good');
    } else if (id === 'sniper' || id === 'rpg') {
      this.giveWeapon(id);
      this.notify(`Bought ${WEAPONS[id].name}`, 'good');
    } else {
      this.giveItem(id);
    }
    audio.pickup();
    this.publishHud(true);
    return true;
  }

  /** Pay for an early release from custody. */
  buyEarlyRelease() {
    const fee = 25000;
    if (this.money < fee) {
      this.notify(`Early release costs $${fee.toLocaleString()}`, 'bad');
      audio.error();
      return;
    }
    this.money -= fee;
    this.jailEnd = Date.now();
    this.jailed = false;
    this.exitInterior();
    this.playerPos.set(10, 0, 272);
    this.notify('Bailed out. Stay out of trouble.', 'good');
    this.save();
    this.publishHud(true);
  }

  setVolume(v: number) {
    this.masterVolume = clamp(v, 0, 1);
    audio.setVolume(this.masterVolume);
  }

  /** Garage customisation for the vehicle the player is sitting in. */
  applyMod(kind: string) {
    const prices: Record<string, number> = { paint: 400, engine: 1200, tires: 600, plate: 250 };
    const price = prices[kind] ?? 0;
    if (this.money < price) {
      this.notify('Not enough money', 'bad');
      audio.error();
      return;
    }
    const v = this.inVehicle ?? this.nearestVehicle(16);
    if (!v) {
      this.notify('Bring your car to the garage first', 'bad');
      audio.error();
      return;
    }
    this.money -= price;
    if (kind === 'paint') {
      const colors = [0x101216, 0xe9ebee, 0x1b3f8f, 0x7a1f22, 0x14523a, 0xd08a1e, 0x5a2f8f];
      const c = colors[Math.floor(Math.random() * colors.length)];
      v.group.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh && (m.material as THREE.MeshStandardMaterial)?.metalness === 0.62) {
          (m.material as THREE.MeshStandardMaterial).color.setHex(c);
        }
      });
      this.notify('Custom paint applied', 'good');
    } else if (kind === 'engine') {
      v.spec.accel *= 1.25;
      v.spec.maxSpeed *= 1.12;
      this.notify('Engine tuned (+25% power)', 'good');
    } else if (kind === 'tires') {
      v.spec.grip *= 1.25;
      this.notify('Sport tyres fitted', 'good');
    } else if (kind === 'plate') {
      this.notify('Custom plate fitted', 'good');
    }
    audio.pickup();
    this.publishHud(true);
  }

  /** Runs one simulation step (exposed for tests). */
  step(dt: number) {
    this.update(dt);
  }

  // ------------------------------------------------------------------ main loop
  private loop = () => {
    requestAnimationFrame(this.loop);
    const now = performance.now() / 1000;
    const raw = this.lastTime ? now - this.lastTime : 0.016;
    this.lastTime = now;
    const dt = Math.min(raw, 0.05);
    this.fpsAcc += raw;
    this.fpsFrames++;
    if (this.fpsAcc > 0.5) {
      this.fps = Math.round(this.fpsFrames / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsFrames = 0;
    }
    try {
      this.update(dt);
      this.renderer.render(this.scene, this.camera);
    } catch (e) {
      console.error('frame error', e);
    }
  };

  private update(dt: number) {
    const paused = this.paused || this.phoneOpen || this.mapOpen || this.inventoryOpen;
    this.timeOfDay = (this.timeOfDay + dt * this.daySpeed) % 24;

    this.updateEnvironment(false);
    this.updateWeather(dt);

    if (!paused && !this.jailed) {
      this.fireTimer = Math.max(0, this.fireTimer - dt);
      this.punchTimer = Math.max(0, this.punchTimer - dt);
      this.damageFlash = Math.max(0, this.damageFlash - dt * 1.6);
      this.damageDirs.forEach((d) => (d.life -= dt));
      this.damageDirs = this.damageDirs.filter((d) => d.life > 0);

      if (this.inVehicle) this.updateVehicle(dt);
      else this.updatePlayer(dt);

      this.updateCombat(dt);
      this.updatePolice(dt);
      this.updateMissions(dt);
      if (!this.currentInterior) {
        this.peds.update(dt, this.playerPos, this.timeOfDay);
        this.traffic.update(dt, this.playerPos, this.nightFactor() > 0.4);
      }
      this.updateDog(dt);
      this.updatePickups(dt);
      this.updateEffects(dt);
      if (this.muzzleTimer > 0) {
        this.muzzleTimer -= dt;
        if (this.muzzleLight) this.muzzleLight.intensity = Math.max(0, this.muzzleTimer * 220);
      }
      this.updateInteractPrompt();
      if (this.wanted > 0 && this.wantedHeat <= 0) this.clearWanted();
    } else {
      this.updateEffects(dt * 0.4);
    }

    if (this.dead) {
      this.respawnTimer -= dt;
      if (this.respawnTimer <= 0) this.respawn();
    }
    if (this.jailed) {
      const remain = this.jailEnd - Date.now();
      if (remain <= 0) {
        this.jailed = false;
        this.exitInterior();
        this.playerPos.set(10, 0, 260);
        this.notify('Released. behave yourself.', 'good');
        this.save();
      }
    }

    this.updateMarker();
    if (this.jobMarker) {
      this.jobMarker.rotation.y += dt * 0.6;
      (this.jobMarker.material as THREE.MeshBasicMaterial).opacity =
        0.22 + Math.sin(performance.now() / 500) * 0.12;
    }
    this.world.update(dt, this.timeOfDay);
    this.world.setNight(this.nightFactor());
    this.updateCamera(dt);
    this.updateSun();
    this.updateAudioState();
    this.mapFrame = (this.mapFrame + 1) % 2;
    if (this.mapFrame === 0) this.drawMinimap();

    this.hudTimer += dt;
    if (this.hudTimer > 0.12) {
      this.hudTimer = 0;
      this.publishHud();
    }
    if (Date.now() - this.lastSave > 20000) {
      this.lastSave = Date.now();
      this.save(true);
    }
  }

  private updatePlayer(dt: number) {
    const mv = this.moveVec;
    const sprint = this.sprintHeld;
    const moving = Math.hypot(mv.x, mv.y) > 0.05 && !this.sitting;

    let speed = this.sitting ? 0 : sprint ? 6.3 : 2.35;
    if (this.sitting) speed = 0;

    // forward = direction the camera is looking (horizontally)
    const fwd = new THREE.Vector3(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw));
    const right = new THREE.Vector3(-fwd.z, 0, fwd.x);
    const desired = new THREE.Vector3()
      .addScaledVector(fwd, mv.y)
      .addScaledVector(right, mv.x)
      .multiplyScalar(speed);

    const accel = this.grounded ? 16 : 5;
    this.playerVel.x = damp(this.playerVel.x, desired.x, accel, dt);
    this.playerVel.z = damp(this.playerVel.z, desired.z, accel, dt);

    if (!this.grounded) this.vy -= 22 * dt;
    else if (this.vy < 0) this.vy = 0;

    const prevY = this.playerPos.y;
    this.playerPos.x += this.playerVel.x * dt;
    this.playerPos.z += this.playerVel.z * dt;
    this.playerPos.y += this.vy * dt;

    const groundY = this.currentInterior ? this.currentInterior.kind === 'villa' ? 0.15 : 0.05 : 0;
    if (this.playerPos.y <= groundY) {
      if (!this.grounded && this.vy < -9.5) {
        const dmg = (-this.vy - 9.5) * 7;
        this.damagePlayer(dmg, 'fall');
        this.notify('Hard landing!', 'bad');
      }
      this.playerPos.y = groundY;
      this.vy = 0;
      this.grounded = true;
    } else {
      this.grounded = false;
    }
    void prevY;

    // collision with world boxes
    this.resolveCollisions();

    // facing
    if (moving) {
      const target = Math.atan2(this.playerVel.x, this.playerVel.z);
      this.playerHuman.group.rotation.y = angleLerp(this.playerHuman.group.rotation.y, target, 1 - Math.exp(-14 * dt));
    }
    this.playerGroup.position.copy(this.playerPos);
    this.playerGroup.position.y = this.playerPos.y;

    // animation state
    let pose: any = 'idle';
    const sp = Math.hypot(this.playerVel.x, this.playerVel.z);
    if (this.dead) pose = 'dead';
    else if (this.sitting) pose = 'sit';
    else if (this.punchTimer > 0) pose = 'punch';
    else if (this.fireTimer > WEAPONS[this.weapon].fireRate * 0.55) pose = 'shoot';
    else if (!this.grounded) pose = 'jump';
    else if (sp > 0.35) pose = sprint ? 'run' : 'walk';
    this.playerHuman.setPose(pose);
    this.playerHuman.update(dt, sp, this.grounded, { aim: this.aimMode ? 1 : 0 });

    // footsteps
    if (this.grounded && sp > 0.4) {
      this.lastFootstep += dt * (sprint ? 2.1 : 1.35);
      if (this.lastFootstep > 1) {
        this.lastFootstep = 0;
        audio.footstep(sprint);
      }
    }
  }

  private resolveCollisions() {
    const r = 0.42;
    const boxes = this.currentInterior
      ? this.currentInterior.colliders
      : this.world.collidersNear(this.playerPos.x, this.playerPos.z);
    for (const b of boxes) {
      const cx = clamp(this.playerPos.x, b.minX, b.maxX);
      const cz = clamp(this.playerPos.z, b.minZ, b.maxZ);
      const dx = this.playerPos.x - cx;
      const dz = this.playerPos.z - cz;
      const dist2 = dx * dx + dz * dz;
      if (dist2 < r * r) {
        const dist = Math.sqrt(dist2) || 0.0001;
        const push = (r - dist) / dist;
        this.playerPos.x += dx * push;
        this.playerPos.z += dz * push;
        if (dist < 0.0001) {
          // centre inside box: push out along smallest axis
          const ox = Math.min(this.playerPos.x - b.minX, b.maxX - this.playerPos.x);
          const oz = Math.min(this.playerPos.z - b.minZ, b.maxZ - this.playerPos.z);
          if (ox < oz) this.playerPos.x += this.playerPos.x - (b.minX + b.maxX) / 2 > 0 ? ox : -ox;
          else this.playerPos.z += this.playerPos.z - (b.minZ + b.maxZ) / 2 > 0 ? oz : -oz;
        }
      }
    }
  }

  private updateVehicle(dt: number) {
    const v = this.inVehicle!;
    const fwdInput = this.moveVec.y;
    const steerInput = this.moveVec.x;
    const brakeHeld = this.key('Space') || !!this.buttons.handbrake;

    const throttle = fwdInput > 0 ? fwdInput : fwdInput < 0 ? 0 : 0;
    const reverse = fwdInput < 0 ? -fwdInput : 0;
    v.throttle = throttle;
    v.brake = brakeHeld ? 1 : 0;

    const spec = v.spec;
    const speedFactor = 1 - clamp(Math.abs(v.speed) / spec.maxSpeed, 0, 0.92);
    let acc = 0;
    if (throttle > 0) acc = spec.accel * throttle * speedFactor;
    if (reverse > 0) {
      if (v.speed > 0.5) acc = -spec.accel * 1.6 * reverse;
      else acc = -spec.accel * 0.45 * reverse;
    }
    if (brakeHeld) {
      v.speed *= Math.pow(0.02, dt);
      acc = 0;
    }
    v.speed += acc * dt;
    v.speed *= 1 - 0.5 * dt;
    v.speed = clamp(v.speed, -spec.maxSpeed * 0.35, spec.maxSpeed);

    // steering
    v.steer = damp(v.steer, steerInput, 9, dt);
    const steerAuthority = clamp(Math.abs(v.speed) / 6, 0, 1);
    const dir = v.speed >= 0 ? 1 : -1;
    v.heading += v.steer * steerAuthority * dir * 1.55 * dt * clamp(Math.abs(v.speed) / 14, 0.25, 1);

    const fwd = new THREE.Vector3(Math.sin(v.heading), 0, Math.cos(v.heading));
    v.pos.addScaledVector(fwd, v.speed * dt);
    v.pos.y = 0;

    // collide with world
    const boxes = this.world.collidersNear(v.pos.x, v.pos.z);
    const rad = spec.length * 0.45;
    for (const b of boxes) {
      const bw = b.maxX - b.minX;
      const bd = b.maxZ - b.minZ;
      if (bw < 1.6 && bd < 1.6) continue; // thin props: trees, poles
      const cx = clamp(v.pos.x, b.minX, b.maxX);
      const cz = clamp(v.pos.z, b.minZ, b.maxZ);
      const dx = v.pos.x - cx;
      const dz = v.pos.z - cz;
      const d = Math.hypot(dx, dz);
      if (d < rad) {
        const push = (rad - d) / (d || 0.001);
        v.pos.x += dx * push;
        v.pos.z += dz * push;
        if (Math.abs(v.speed) > 6) {
          const impact = Math.abs(v.speed) * 0.9;
          v.health -= impact;
          this.damagePlayer(impact * 0.25, 'crash');
          v.speed *= -0.25;
          this.notify('Crash!', 'bad');
          audio.explosion();
        } else {
          v.speed *= 0.4;
        }
      }
    }

    v.group.position.copy(v.pos);
    v.group.rotation.y = v.heading;
    v.updateVisual(dt, performance.now() / 1000);
    v.setBrake(brakeHeld);
    v.setLightsOn(this.nightFactor() > 0.35);
    if (v.headlightSpot) v.headlightSpot.intensity = this.nightFactor() > 0.3 ? 9 : 0;

    v.rpm = clamp(Math.abs(v.speed) / spec.maxSpeed, 0.1, 1) * 0.8 + (throttle > 0 ? 0.2 : 0);
    // tyre screech when cornering hard
    const slip = Math.abs(v.steer) * clamp(Math.abs(v.speed) / 26, 0, 1);
    if (slip > 0.55) {
      this.skidTimer -= dt;
      if (this.skidTimer <= 0) {
        this.skidTimer = 0.16;
        audio.footstep(true);
      }
    }
    this.playerPos.copy(v.pos);
    this.playerPos.y = 0;
  }

  private updateCombat(dt: number) {
    const w = WEAPONS[this.weapon];
    const wantFire = (this.mouseDown && !this.aimMode) || this.fireHeld || (this.aimMode && this.rightDown);
    if (wantFire && !this.inVehicle) {
      if (w.auto || this.fireTimer <= 0) this.fire();
    }
    // projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      p.vel.y -= (p.kind === 'rpg' ? 5.5 : 14) * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (p.kind === 'rpg') {
        p.mesh.lookAt(p.mesh.position.clone().add(p.vel));
        if (Math.random() < 0.5) this.spawnImpact(p.mesh.position.clone(), 0xffa040);
      }
      const gy = this.currentInterior ? 0.1 : 0;
      let boom = false;
      if (p.mesh.position.y <= gy + 0.15) {
        p.mesh.position.y = gy + 0.15;
        boom = true;
      }
      if (p.kind === 'grenade') {
        p.fuse -= dt;
        if (p.fuse <= 0) boom = true;
      }
      // hit peds
      for (const ped of this.peds.peds) {
        if (ped.dead) continue;
        if (p.mesh.position.distanceTo(ped.pos.clone().setY(1)) < 1.1) {
          this.damagePed(ped, p.dmg, true);
          boom = true;
          break;
        }
      }
      if (boom || p.life <= 0) {
        if (p.kind === 'smoke') this.spawnExplosion(p.mesh.position.clone(), 4, true);
        else if (p.kind === 'grenade' || p.kind === 'rpg') {
          this.spawnExplosion(p.mesh.position.clone(), p.kind === 'rpg' ? 9 : 7, false);
          this.addWanted(2);
          this.peds.panic(p.mesh.position, 30);
        }
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  private updateEffects(dt: number) {
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const e = this.effects[i];
      e.life -= dt;
      const t = Math.max(0, e.life / e.max);
      if (e.kind === 'spark') (e.obj as THREE.Sprite).scale.setScalar(0.8 * t + 0.1);
      else if (e.kind === 'fire') (e.obj as THREE.Sprite).scale.setScalar(e.max * 3.2 * (1 - t) + 0.4);
      else if (e.kind === 'smoke') {
        const s = e.obj as THREE.Sprite;
        s.scale.multiplyScalar(1 + dt * 0.45);
        (s.material as THREE.SpriteMaterial).opacity = 0.6 * t;
        s.position.y += dt * 0.5;
      } else if (e.kind === 'tracer') {
        ((e.obj as THREE.Line).material as THREE.LineBasicMaterial).opacity = t;
      } else if (e.kind === 'light') {
        (e.obj as THREE.PointLight).intensity = 20 * t;
      }
      if (e.life <= 0) {
        this.scene.remove(e.obj);
        (e.obj as any).material?.dispose?.();
        this.effects.splice(i, 1);
      }
    }
    // rain particles follow the player
    if (this.rainPoints && this.rainIntensity > 0) {
      const pos = this.rainPoints.geometry.attributes.position as THREE.BufferAttribute;
      const arr = pos.array as Float32Array;
      const cam = this.camera.position;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] -= 34 * dt;
        if (arr[i + 1] < -6) {
          arr[i] = (Math.random() - 0.5) * 90 + cam.x;
          arr[i + 1] = 42;
          arr[i + 2] = (Math.random() - 0.5) * 90 + cam.z;
        }
      }
      pos.needsUpdate = true;
      this.rainPoints.position.set(cam.x, 0, cam.z);
    }
  }

  private updateDog(dt: number) {
    const target = this.playerPos.clone();
    const dist = this.dogGroup.position.distanceTo(target);
    const dogSpeed = clamp((dist - 2.2) * 1.5, 0, 6.5);
    const dir = target.clone().sub(this.dogGroup.position).setY(0);
    if (dir.lengthSq() > 0.01) dir.normalize();
    this.dogGroup.position.addScaledVector(dir, dogSpeed * dt);
    this.dogGroup.position.y = this.currentInterior ? 0.15 : 0;
    const heading = Math.atan2(dir.x, dir.z);
    this.dogGroup.rotation.y = angleLerp(this.dogGroup.rotation.y, heading, 1 - Math.exp(-8 * dt));
    this.dog.update(dt, dogSpeed, dist < 1.4);
  }

  private updateCamera(dt: number) {
    const target = new THREE.Vector3();
    if (this.inVehicle) {
      const v = this.inVehicle;
      target.copy(v.pos);
      target.y += 1.15;
      this.camTargetDist = this.aimMode ? 4.2 : 7.4;
    } else {
      target.copy(this.playerPos);
      target.y += 1.5;
      this.camTargetDist = this.aimMode ? 1.9 : this.sitting ? 3.2 : 4.4;
    }
    this.camDist = damp(this.camDist, this.camTargetDist, 8, dt);

    const dir = new THREE.Vector3(
      Math.sin(this.camYaw) * Math.cos(this.camPitch),
      Math.sin(this.camPitch),
      Math.cos(this.camYaw) * Math.cos(this.camPitch)
    );
    let desired = target.clone().addScaledVector(dir, this.camDist);
    // keep the camera above the ground
    desired.y = Math.max(desired.y, (this.currentInterior ? 0.2 : 0) + 0.45);

    // camera collision: sample the ray
    const steps = 8;
    for (let i = steps; i >= 1; i--) {
      const t = i / steps;
      const p = target.clone().lerp(desired, t);
      if (this.pointBlocked(p)) {
        desired = target.clone().lerp(desired, Math.max(0.12, (i - 1) / steps));
        break;
      }
    }
    this.camera.position.lerp(desired, 1 - Math.exp(-16 * dt));
    this.camera.lookAt(target);
  }

  private pointBlocked(p: THREE.Vector3) {
    if (this.currentInterior) {
      return this.currentInterior.colliders.some(
        (b) => p.x > b.minX - 0.25 && p.x < b.maxX + 0.25 && p.z > b.minZ - 0.25 && p.z < b.maxZ + 0.25
      );
    }
    const boxes = this.world.collidersNear(p.x, p.z);
    return boxes.some(
      (b) =>
        p.x > b.minX - 0.3 &&
        p.x < b.maxX + 0.3 &&
        p.z > b.minZ - 0.3 &&
        p.z < b.maxZ + 0.3 &&
        p.y < b.top + 0.3
    );
  }

  private updateSun() {
    const ang = ((this.timeOfDay - 6) / 24) * Math.PI * 2;
    const dir = new THREE.Vector3(Math.sin(ang) * 0.7, Math.max(-0.4, Math.sin(ang + Math.PI / 2) * 0.9 + 0.35), Math.cos(ang) * 0.4);
    if (dir.y < 0.06) dir.y = 0.06;
    dir.normalize();
    const focus = this.camera.position;
    this.sun.position.copy(focus).addScaledVector(dir, 140);
    this.sun.target.position.copy(focus);
    this.sun.target.updateMatrixWorld();
    const night = this.nightFactor();
    this.sun.intensity = lerp(2.4, 0.05, night);
    this.sun.color.setHSL(lerp(0.1, 0.6, night), lerp(0.25, 0.55, night), lerp(0.62, 0.55, night));
    this.hemi.intensity = lerp(0.85, 0.18, night);
    this.ambient.intensity = lerp(0.22, 0.08, night);
    this.renderer.toneMappingExposure = lerp(1.05, 0.82, night);
    // sky + fog
    const sky = new THREE.Color().setHSL(lerp(0.58, 0.66, night), lerp(0.55, 0.5, night), lerp(0.62, 0.1, night));
    this.fog.color.copy(sky);
    const overcast = this.weather === 'Overcast' || this.weather === 'Rain' || this.weather === 'Storm';
    if (overcast) this.fog.color.lerp(new THREE.Color(0x8c96a1), 0.55);
    if (this.weather === 'Fog') this.fog.color.lerp(new THREE.Color(0xa8b0b6), 0.7);
    this.fog.near = 60;
    this.fog.far = this.weather === 'Fog' ? 220 : this.weather === 'Storm' ? 420 : 640;
    if (this.scene.background instanceof THREE.Color) this.scene.background.copy(sky);
    else this.scene.background = sky;
  }

  nightFactor() {
    const h = this.timeOfDay;
    if (h < 5 || h > 21) return 1;
    if (h < 7) return 1 - (h - 5) / 2;
    if (h > 19) return (h - 19) / 2;
    return 0;
  }

  private updateWeather(dt: number) {
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0) {
      this.weatherTimer = 150 + Math.random() * 260;
      const options = ['Clear', 'Clear', 'Cloudy', 'Overcast', 'Rain', 'Rain', 'Storm', 'Fog'];
      const next = options[Math.floor(Math.random() * options.length)];
      if (next !== this.weather) {
        this.weather = next;
        this.notify(`Weather: ${next}`, 'info');
      }
    }
    const targetRain =
      this.weather === 'Rain' ? 0.7 : this.weather === 'Storm' ? 1 : 0;
    this.rainIntensity = damp(this.rainIntensity, targetRain, 0.6, dt);
    this.wetness = damp(this.wetness, this.rainIntensity > 0.05 ? 1 : 0, this.rainIntensity > 0.05 ? 0.35 : 0.12, dt);
    this.world.updateWetness(this.wetness);
    if (this.rainPoints) {
      this.rainPoints.visible = this.rainIntensity > 0.02;
      (this.rainPoints.material as THREE.PointsMaterial).opacity = 0.2 + this.rainIntensity * 0.45;
    }
    if (this.weather === 'Storm' && Math.random() < dt * 0.12) {
      this.lightning = 1;
      setTimeout(() => (this.lightning = 0), 120);
      audio.beep(60, 0.5, 'sawtooth', 0.12);
    }
    if (this.lightning > 0) {
      this.ambient.intensity += this.lightning * 2;
    }
  }

  private updateEnvironment(force: boolean) {
    this.envTimer -= 1;
    if (!force && this.envTimer > 0) return;
    this.envTimer = 900; // ~15 seconds between reflection refreshes
    // build a simple gradient environment for reflections
    const skyScene = new THREE.Scene();
    const geo = new THREE.SphereGeometry(10, 16, 12);
    const mat = new THREE.MeshBasicMaterial({
      side: THREE.BackSide,
      color: new THREE.Color().setHSL(0.58, 0.5, lerp(0.6, 0.12, this.nightFactor())),
    });
    skyScene.add(new THREE.Mesh(geo, mat));
    const sun = new THREE.Mesh(
      new THREE.SphereGeometry(1.6, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xfff0d0 })
    );
    sun.position.set(4, 6, 3);
    skyScene.add(sun);
    const rt = this.pmrem!.fromScene(skyScene, 0.04);
    if (this.envRT) this.envRT.dispose();
    this.envRT = rt;
    this.envMap = rt.texture;
    this.scene.environment = this.envMap;
    geo.dispose();
    mat.dispose();
  }

  private updateAudioState() {
    if (this.inVehicle) {
      const v = this.inVehicle;
      audio.setEngine(true, v.rpm, Math.abs(v.throttle));
    } else {
      audio.setEngine(false, 0, 0);
    }
    audio.setRain(this.rainIntensity);
    audio.setWind(0.2 + this.rainIntensity * 0.6);
  }

  private updateInteractPrompt() {
    let prompt: string | null = null;
    if (this.inVehicle) prompt = 'Exit vehicle (E)';
    else {
      const it = this.currentInterior;
      if (it && it.shopItems?.length) prompt = 'Open store (E)';
      else if (it && this.playerPos.distanceTo(it.exit) < 2.4) prompt = 'Exit building (E)';
      else {
        const v = this.nearestVehicle(3.2);
        if (v) prompt = `Enter ${v.spec.displayName} (E)`;
        else if (Math.hypot(this.playerPos.x + 450, this.playerPos.z + 428) < 3.2)
          prompt = 'Start next job (E)';
        else {
          const lm = this.nearestLandmarkDoor(6);
          if (lm && lm.interior) prompt = `Enter ${lm.name} (E)`;
        }
      }
    }
    this.prompt = prompt;
  }

  private respawn() {
    this.dead = false;
    this.health = this.maxHealth;
    this.playerHuman.setPose('idle');
    this.inVehicle = null;
    this.playerGroup.visible = true;
    this.dogGroup.visible = true;
    this.playerPos.set(250, 0, 312);
    this.playerVel.set(0, 0, 0);
    this.vy = 0;
    this.wanted = 0;
    this.money = Math.max(0, this.money - 250);
    this.notify('Respawned at St. Verity Hospital', 'bad');
    this.publishHud(true);
  }

  // ------------------------------------------------------------------ minimap
  attachCanvases(minimap: HTMLCanvasElement | null, map: HTMLCanvasElement | null) {
    this.minimapCanvas = minimap;
    this.mapCanvas = map;
  }

  private drawMinimap() {
    const c = this.minimapCanvas;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const w = c.width;
    const h = c.height;
    const cx = w / 2;
    const cy = h / 2;
    const scale = 0.62;
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(cx, cy) - 1, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = '#20262c';
    ctx.fillRect(0, 0, w, h);
    const focus = this.currentInterior ? this.currentInterior.returnTo : this.playerPos;
    const px = focus.x;
    const pz = focus.z;

    // roads
    ctx.strokeStyle = '#4a5560';
    ctx.lineWidth = Math.max(2, ROAD_W * scale * 0.8);
    ctx.beginPath();
    for (let i = -8; i <= 8; i++) {
      const x = cx + (i * BLOCK - px) * scale;
      const y = cy + (i * BLOCK - pz) * scale;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();
    // buildings
    ctx.fillStyle = '#39424c';
    for (const b of this.world.buildingRects) {
      const x = cx + (b.x - b.w / 2 - px) * scale;
      const y = cy + (b.z - b.d / 2 - pz) * scale;
      const bw = b.w * scale;
      const bh = b.d * scale;
      if (x + bw < -10 || x > w + 10 || y + bh < -10 || y > h + 10) continue;
      ctx.fillRect(x, y, bw, bh);
    }
    // landmarks
    for (const l of LANDMARKS) {
      const x = cx + (l.x - px) * scale;
      const y = cy + (l.z - pz) * scale;
      if (x < -20 || x > w + 20 || y < -20 || y > h + 20) continue;
      ctx.fillStyle = '#' + new THREE.Color(l.color).getHexString();
      ctx.fillRect(x - 4, y - 4, 8, 8);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.font = '9px Arial';
      ctx.fillText(l.name, x + 7, y + 3);
    }
    // mission marker
    if (this.missionIndex >= 0) {
      const m = MISSIONS[this.missionIndex];
      const x = cx + (m.target[0] - px) * scale;
      const y = cy + (m.target[1] - pz) * scale;
      ctx.fillStyle = '#ffc53d';
      ctx.beginPath();
      ctx.arc(x, y, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // border + player triangle
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(cx, cy) - 1, 0, Math.PI * 2);
    ctx.stroke();

    const heading = this.inVehicle ? this.inVehicle.heading : this.playerHuman.group.rotation.y;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-heading + Math.PI);
    ctx.fillStyle = '#ffd979';
    ctx.strokeStyle = '#20180a';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, -8);
    ctx.lineTo(6, 7);
    ctx.lineTo(0, 4);
    ctx.lineTo(-6, 7);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  drawBigMap() {
    const c = this.mapCanvas;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const w = c.width;
    const h = c.height;
    const scale = Math.min(w, h) / (WORLD_SIZE * 1.05);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#171b20';
    ctx.fillRect(0, 0, w, h);
    const ox = w / 2;
    const oy = h / 2;
    const tx = (x: number) => ox + x * scale;
    const tz = (z: number) => oy + z * scale;

    ctx.strokeStyle = '#3d4650';
    ctx.lineWidth = Math.max(2, ROAD_W * scale);
    ctx.beginPath();
    for (let i = -8; i <= 8; i++) {
      ctx.moveTo(tx(i * BLOCK), 0);
      ctx.lineTo(tx(i * BLOCK), h);
      ctx.moveTo(0, tz(i * BLOCK));
      ctx.lineTo(w, tz(i * BLOCK));
    }
    ctx.stroke();
    ctx.fillStyle = '#2f3841';
    for (const b of this.world.buildingRects) {
      ctx.fillRect(tx(b.x - b.w / 2), tz(b.z - b.d / 2), b.w * scale, b.d * scale);
    }
    for (const l of LANDMARKS) {
      ctx.fillStyle = '#' + new THREE.Color(l.color).getHexString();
      ctx.fillRect(tx(l.x) - 5, tz(l.z) - 5, 10, 10);
      ctx.fillStyle = '#e8eef5';
      ctx.font = '11px Arial';
      ctx.fillText(l.name, tx(l.x) + 9, tz(l.z) + 4);
    }
    if (this.missionIndex >= 0) {
      const m = MISSIONS[this.missionIndex];
      ctx.fillStyle = '#ffc53d';
      ctx.beginPath();
      ctx.arc(tx(m.target[0]), tz(m.target[1]), 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffd979';
      ctx.font = 'bold 11px Arial';
      ctx.fillText('OBJECTIVE', tx(m.target[0]) + 9, tz(m.target[1]) - 6);
    }
    // player
    const heading = this.inVehicle ? this.inVehicle.heading : this.playerHuman.group.rotation.y;
    const pmap = this.currentInterior ? this.currentInterior.returnTo : this.playerPos;
    ctx.save();
    ctx.translate(tx(pmap.x), tz(pmap.z));
    ctx.rotate(-heading + Math.PI);
    ctx.fillStyle = '#ffd979';
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(6.5, 8);
    ctx.lineTo(0, 4.5);
    ctx.lineTo(-6.5, 8);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    // compass
    ctx.fillStyle = 'rgba(255,255,255,0.65)';
    ctx.font = 'bold 13px Arial';
    ctx.fillText('N', w / 2 - 4, 22);
    ctx.fillText('S', w / 2 - 4, h - 12);
    ctx.fillText('W', 12, h / 2 + 4);
    ctx.fillText('E', w - 22, h / 2 + 4);
  }

  // ------------------------------------------------------------------ HUD
  private buildHud(): HudState {
    return {
      hp: 100,
      maxHp: 100,
      money: 0,
      wanted: 0,
      weather: 'Clear',
      temp: 21,
      clock: 12,
      location: '',
      speed: 0,
      inVehicle: false,
      vehicleName: '',
      weapon: 'fists',
      weaponName: 'Bare Knuckles',
      weaponIcon: '✊',
      ammo: 0,
      reserve: 0,
      inventory: [],
      objective: '',
      objectiveSub: '',
      jailed: false,
      jailRemaining: 0,
      jailTotal: JAIL_MS,
      notifications: [],
      fps: 60,
      prompt: null,
      phoneOpen: false,
      phoneApp: null,
      mapOpen: false,
      inventoryOpen: false,
      wheelOpen: false,
      settingsOpen: false,
      paused: false,
      interior: null,
      missionTitle: '',
      missionStage: '',
      missions: [],
      phoneBalance: 0,
      damageFlash: 0,
      showHints: true,
      shopOpen: false,
    };
  }

  private publishHud(force = false) {
    const w = WEAPONS[this.weapon];
    const mission = this.missionIndex >= 0 ? MISSIONS[this.missionIndex] : null;
    const next: HudState = {
      hp: Math.round(this.health),
      maxHp: this.maxHealth,
      money: Math.round(this.money),
      wanted: this.wanted,
      weather: this.weather,
      temp: Math.round(18 + Math.sin(((this.timeOfDay - 8) / 24) * Math.PI * 2) * 7),
      clock: this.timeOfDay,
      location: this.currentInterior
        ? 'Interior'
        : this.world
        ? this.world.district(this.playerPos.x, this.playerPos.z)
        : 'Solstice',
      speed: this.inVehicle ? this.inVehicle.kmh : Math.hypot(this.playerVel.x, this.playerVel.z) * 3.6,
      inVehicle: !!this.inVehicle,
      vehicleName: this.inVehicle ? this.inVehicle.spec.displayName : '',
      weapon: this.weapon,
      weaponName: w.name,
      weaponIcon: w.icon,
      ammo: this.ammo[this.weapon] || 0,
      reserve: this.reserve[this.weapon] || 0,
      inventory: this.inventory.map((i) => ({ ...i })),
      objective: mission ? mission.title : this.jailed ? 'Serve your sentence' : 'Free roam',
      objectiveSub: mission ? mission.brief : this.jailed ? 'Wait for the timer to reach zero' : 'Explore the city of Solstice',
      jailed: this.jailed,
      jailRemaining: Math.max(0, this.jailEnd - Date.now()),
      jailTotal: JAIL_MS,
      notifications: this.notifications.slice(0, 4),
      fps: this.fps,
      prompt: this.prompt,
      phoneOpen: this.phoneOpen,
      phoneApp: this.phoneApp,
      mapOpen: this.mapOpen,
      inventoryOpen: this.inventoryOpen,
      wheelOpen: this.wheelOpen,
      settingsOpen: this.settingsOpen,
      paused: this.paused,
      interior: this.currentInterior?.id ?? null,
      missionTitle: mission?.title ?? '',
      missionStage: mission ? `Stage ${this.missionStage + 1}` : '',
      missions: MISSIONS.map((m, i) => ({
        id: m.id,
        title: m.title,
        brief: m.brief,
        reward: m.reward,
        state: this.missions[i].state,
      })),
      phoneBalance: this.phoneBalance,
      damageFlash: this.damageFlash,
      showHints: !this.isMobile || this.showHints,
      shopOpen: this.shopOpen,
    };
    this.hud = next;
    this.listeners.forEach((l) => l(next));
    void force;
  }

  subscribe(l: (s: HudState) => void) {
    this.listeners.add(l);
    l(this.hud);
    return () => {
      this.listeners.delete(l);
    };
  }

  getHud() {
    return this.hud;
  }

  // ------------------------------------------------------------------ save/load
  save(silent = false) {
    try {
      const data = {
        v: 1,
        pos: [this.playerPos.x, this.playerPos.y, this.playerPos.z],
        hp: this.health,
        money: this.money,
        time: this.timeOfDay,
        weather: this.weather,
        weapon: this.weapon,
        ammo: this.ammo,
        reserve: this.reserve,
        inventory: this.inventory,
        missions: this.missions,
        jailEnd: this.jailEnd,
        jailed: this.jailed,
        vehicles: this.vehicles.map((v) => ({
          type: v.spec.type,
          x: v.pos.x,
          z: v.pos.z,
          h: v.heading,
        })),
        vehiclePos: this.vehicles.map((v) => ({ x: v.pos.x, z: v.pos.z, h: v.heading })),
        playerVehicle: this.inVehicle ? this.vehicles.indexOf(this.inVehicle) : -1,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      if (!silent) this.notify('Game saved', 'good');
    } catch (e) {
      console.warn('save failed', e);
    }
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) {
        this.notify('No saved game found', 'bad');
        return false;
      }
      const d = JSON.parse(raw);
      if (d.pos) this.playerPos.set(d.pos[0], d.pos[1], d.pos[2]);
      this.health = d.hp ?? 100;
      this.money = d.money ?? 1500;
      this.timeOfDay = d.time ?? 9.5;
      if (d.weather) this.weather = d.weather;
      if (d.weapon && WEAPONS[d.weapon]) {
        this.weapon = d.weapon;
        this.refreshWeaponModel();
      }
      this.ammo = d.ammo ?? {};
      this.reserve = d.reserve ?? {};
      this.inventory = d.inventory ?? [];
      if (d.missions) this.missions = d.missions;
      if (d.vehiclePos) {
        d.vehiclePos.forEach((p: any, i: number) => {
          const v = this.vehicles[i];
          if (v) {
            v.pos.set(p.x, 0, p.z);
            v.heading = p.h;
            v.group.position.copy(v.pos);
            v.group.rotation.y = p.h;
          }
        });
      }
      if (d.jailed && d.jailEnd > Date.now()) {
        this.jailed = true;
        this.jailEnd = d.jailEnd;
        this.enterInterior('police');
      } else if (d.jailed) {
        this.jailed = false;
      }
      this.notify('Game loaded', 'good');
      this.publishHud(true);
      return true;
    } catch (e) {
      console.warn('load failed', e);
      return false;
    }
  }

  resetGame() {
    localStorage.removeItem(SAVE_KEY);
    this.playerPos.set(-450, 0.15, -447);
    this.health = 100;
    this.money = 1500;
    this.wanted = 0;
    this.inventory = [];
    this.weapon = 'fists';
    this.timeOfDay = 9.5;
    this.missions = MISSIONS.map((m) => ({ id: m.id, state: 'locked' }));
    this.missionIndex = -1;
    this.jailed = false;
    this.notify('New game started', 'good');
    this.publishHud(true);
  }

  // ------------------------------------------------------------------ quality
  setQuality(q: Quality) {
    this.quality = q;
    this.peds?.setDensity(q);
    this.traffic?.setDensity(q);
    if (!this.renderer) return;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q === 'high' ? 2 : q === 'medium' ? 1.5 : 1));
    this.renderer.shadowMap.enabled = q !== 'low';
    this.sun.castShadow = q !== 'low';
    this.sun.shadow.mapSize.set(q === 'high' ? 2048 : q === 'medium' ? 1536 : 1024, q === 'high' ? 2048 : q === 'medium' ? 1536 : 1024);
    if (q === 'low') {
      (this.scene.fog as THREE.Fog).far = 380;
    }
    this.publishHud(true);
  }

  requestLock() {
    if (this.isMobile) return;
    const el = this.renderer?.domElement;
    if (el && document.pointerLockElement !== el) el.requestPointerLock?.();
  }

  resize() {
    const canvas = this.renderer?.domElement;
    if (!canvas) return;
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
}

export const engine = new GameEngine();
export { MISSIONS, WEAPONS, WEAPON_ORDER, ITEMS, LANDMARKS };
export { formatClock };
