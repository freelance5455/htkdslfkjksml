import * as THREE from "three";
import { buildArena, type Arena } from "./arena";
import { createWarrior, type Warrior } from "./warrior";
import { Vfx } from "./vfx";
import { AudioManager } from "./audio";
import { environmentTexture } from "./textures";
import {
  AETHER,
  ARENAS,
  INFERNO,
  createInputs,
  type ArenaId,
  type EngineOptions,
  type HudState,
  type Inputs,
  type PadInput,
  type Phase,
  type Quality,
  type WarriorConfig,
} from "./types";

type FighterState = "idle" | "attack" | "dodge" | "hit" | "block" | "ko" | "victory";

interface AttackSpec {
  kind: "light" | "heavy" | "special";
  duration: number;
  activeStart: number;
  activeEnd: number;
  damage: number;
  range: number;
  arc: number;
  knockback: number;
  hitstun: number;
  cooldown: number;
  shake: number;
  energyGain: number;
  lunge: number;
}

const ATTACKS: Record<"light" | "heavy" | "special", AttackSpec> = {
  light: {
    kind: "light",
    duration: 0.46,
    activeStart: 0.15,
    activeEnd: 0.27,
    damage: 7,
    range: 2.35,
    arc: 0.34,
    knockback: 2.4,
    hitstun: 0.24,
    cooldown: 0.16,
    shake: 0.1,
    energyGain: 11,
    lunge: 1.6,
  },
  heavy: {
    kind: "heavy",
    duration: 0.98,
    activeStart: 0.42,
    activeEnd: 0.58,
    damage: 17,
    range: 2.75,
    arc: 0.18,
    knockback: 6.2,
    hitstun: 0.5,
    cooldown: 0.55,
    shake: 0.42,
    energyGain: 19,
    lunge: 2.4,
  },
  special: {
    kind: "special",
    duration: 1.3,
    activeStart: 0.56,
    activeEnd: 0.78,
    damage: 27,
    range: 3.5,
    arc: -0.15,
    knockback: 9,
    hitstun: 0.8,
    cooldown: 1.1,
    shake: 0.8,
    energyGain: 0,
    lunge: 3.2,
  },
};

const MAX_HEALTH = 100;
const MAX_ENERGY = 100;
const ROUND_TIME = 60;
const ARENA_LIMIT = 6.8;
const BODY_RADIUS = 0.46;
const FIGHTER_SEPARATION = 1.02;
const WALK_SPEED = 3.0;
const RUN_SPEED = 4.7;
const BLOCK_SPEED = 1.35;

interface Fighter {
  index: 0 | 1;
  cfg: WarriorConfig;
  warrior: Warrior;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  facing: number;
  health: number;
  energy: number;
  rounds: number;
  state: FighterState;
  stateTime: number;
  attack: { spec: AttackSpec; time: number; hasHit: boolean } | null;
  cooldowns: { light: number; heavy: number; dodge: number; special: number };
  invuln: number;
  stun: number;
  blocking: boolean;
  hitFlash: number;
  walkPhase: number;
  prev: PadInput;
  trailTimer: number;
}

const clamp = THREE.MathUtils.clamp;
const damp = (current: number, target: number, lambda: number, dt: number) =>
  THREE.MathUtils.damp(current, target, lambda, dt);

function angleLerp(a: number, b: number, t: number) {
  let d = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function pickAnimation(state: FighterState, blocking: boolean, speed: number, attackKind?: string) {
  if (state === "attack" && attackKind) return attackKind;
  if (state === "dodge") return "dodge";
  if (state === "hit") return "hit";
  if (state === "ko") return "ko";
  if (state === "victory") return "victory";
  if (blocking) return "block";
  if (speed > 3.6) return "run";
  if (speed > 0.3) return "walk";
  return "idle";
}

export class GameEngine {
  private opts: EngineOptions;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private arena: Arena;
  private vfx: Vfx;
  private audio = new AudioManager();
  private fighters: [Fighter, Fighter];
  private inputs: Inputs = createInputs();
  private keys = new Set<string>();
  private keyMove: [THREE.Vector2, THREE.Vector2] = [new THREE.Vector2(), new THREE.Vector2()];

  private phase: Phase = "menu";
  private round = 1;
  private timer = ROUND_TIME;
  private scores: [number, number] = [0, 0];
  private message = "";
  private sub = "";
  private messageKey = 0;
  private winner: 0 | 1 | null = null;
  private roundEndTimer = 0;
  private countdown = 0;
  private bannerTimer = 0;
  private hitStop = 0;
  private shake = 0;
  private elapsed = 0;
  private paused = false;
  private disposed = false;
  private raf = 0;
  private hudTimer = 0;
  private fps = 60;
  private quality: Quality;
  private arenaId: ArenaId;
  private lookTarget = new THREE.Vector3(0, 1.1, 0);
  private tmpA = new THREE.Vector3();
  private tmpB = new THREE.Vector3();
  private tmpC = new THREE.Vector3();
  private tmpD = new THREE.Vector3();
  private tmpE = new THREE.Vector3();
  private up = new THREE.Vector3(0, 1, 0);
  private resizeObserver: ResizeObserver | null = null;
  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onBlur: () => void;
  private onVisibility: () => void;
  private onResize: () => void;

  constructor(opts: EngineOptions) {
    this.opts = opts;
    this.quality = opts.quality;
    this.arenaId = opts.arena;

    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas: opts.canvas,
        antialias: opts.quality !== "low",
        powerPreference: "high-performance",
        alpha: false,
        stencil: false,
      });
    } catch {
      throw new Error("WebGL could not be initialised on this device.");
    }
    this.renderer.setPixelRatio(this.pixelRatio());
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.shadowMap.enabled = opts.quality !== "low";
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene.background = new THREE.Color(ARENAS[opts.arena].sky);
    this.scene.fog = new THREE.Fog(ARENAS[opts.arena].fog, ARENAS[opts.arena].fogNear, ARENAS[opts.arena].fogFar);
    this.scene.environment = environmentTexture(opts.arena);
    this.scene.environmentIntensity = 0.55;

    this.camera = new THREE.PerspectiveCamera(46, 1, 0.1, 220);
    this.camera.position.set(0, 4.2, 10.5);
    this.camera.lookAt(this.lookTarget);

    this.arena = buildArena(this.scene, opts.arena, opts.quality);
    this.vfx = new Vfx(this.scene, opts.quality);

    const make = (cfg: WarriorConfig, index: 0 | 1): Fighter => {
      const warrior = createWarrior(cfg);
      this.scene.add(warrior.root);
      return {
        index,
        cfg,
        warrior,
        pos: new THREE.Vector3(index === 0 ? -2.9 : 2.9, 0, index === 0 ? 0.5 : -0.5),
        vel: new THREE.Vector3(),
        facing: index === 0 ? Math.PI / 2 : -Math.PI / 2,
        health: MAX_HEALTH,
        energy: 0,
        rounds: 0,
        state: "idle",
        stateTime: 0,
        attack: null,
        cooldowns: { light: 0, heavy: 0, dodge: 0, special: 0 },
        invuln: 0,
        stun: 0,
        blocking: false,
        hitFlash: 0,
        walkPhase: 0,
        prev: { x: 0, y: 0, light: 0, heavy: 0, dodge: 0, special: 0, block: false },
        trailTimer: 0,
      };
    };
    this.fighters = [make(AETHER, 0), make(INFERNO, 1)];

    this.audio.setMuted(opts.muted);
    this.audio.setVolume(opts.volume);

    this.onKeyDown = (e) => this.handleKey(e, true);
    this.onKeyUp = (e) => this.handleKey(e, false);
    this.onBlur = () => {
      this.keys.clear();
      this.keyMove[0].set(0, 0);
      this.keyMove[1].set(0, 0);
      this.inputs.p1.block = false;
      this.inputs.p2.block = false;
    };
    this.onVisibility = () => {
      if (document.hidden && (this.phase === "fight" || this.phase === "countdown") && !this.paused) {
        this.paused = true;
        this.opts.onAutoPause?.();
      }
    };
    this.onResize = () => this.resize();
    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("resize", this.onResize);
    window.addEventListener("orientationchange", this.onResize);
    document.addEventListener("visibilitychange", this.onVisibility);
    if (typeof ResizeObserver !== "undefined") {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(opts.canvas.parentElement ?? opts.canvas);
    }
    this.resize();
    this.toMenu();
    this.loop();

    // read-only diagnostics hook (used by automated smoke tests / debugging)
    (window as unknown as { __TITAN__?: unknown }).__TITAN__ = {
      snapshot: () => ({
        phase: this.phase,
        round: this.round,
        timer: this.timer,
        scores: [...this.scores],
        message: this.message,
        fighters: this.fighters.map((f) => ({
          name: f.cfg.name,
          health: f.health,
          energy: f.energy,
          state: f.state,
          rounds: f.rounds,
          x: Number(f.pos.x.toFixed(2)),
          z: Number(f.pos.z.toFixed(2)),
          cooldowns: { ...f.cooldowns },
        })),
        fps: Math.round(this.fps),
      }),
      capture: () => {
        this.renderer.render(this.scene, this.camera);
        return this.opts.canvas.toDataURL("image/png");
      },
      move: (p: 0 | 1, x: number, y: number) => this.setMove(p, x, y),
      press: (p: 0 | 1, a: "light" | "heavy" | "dodge" | "special") => this.press(p, a),
      block: (p: 0 | 1, b: boolean) => this.setBlock(p, b),
    };
  }

  private pixelRatio() {
    const dpr = window.devicePixelRatio || 1;
    if (this.quality === "low") return Math.min(dpr, 1);
    if (this.quality === "medium") return Math.min(dpr, 1.5);
    return Math.min(dpr, 2);
  }

  private resize() {
    if (this.disposed) return;
    const canvas = this.opts.canvas;
    const parent = canvas.parentElement;
    const w = Math.max(1, parent?.clientWidth ?? window.innerWidth);
    const h = Math.max(1, parent?.clientHeight ?? window.innerHeight);
    this.renderer.setPixelRatio(this.pixelRatio());
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    // widen the FOV on portrait screens so both fighters stay framed
    this.camera.fov = w / h < 0.85 ? 58 : 46;
    this.camera.updateProjectionMatrix();
  }

  private handleKey(e: KeyboardEvent, down: boolean) {
    const target = e.target as HTMLElement | null;
    if (target && ["INPUT", "TEXTAREA", "BUTTON", "SELECT"].includes(target.tagName)) return;
    const code = e.code;
    const tracked = [
      "KeyW", "KeyA", "KeyS", "KeyD",
      "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight",
      "KeyJ", "KeyK", "KeyL", "KeyU", "Space",
      "Numpad0", "Numpad1", "Numpad2", "Numpad3", "Numpad5",
      "Comma", "Period", "Slash", "ShiftRight", "ControlRight",
    ];
    if (!tracked.includes(code)) return;
    if (down) e.preventDefault();
    if (down) this.keys.add(code);
    else this.keys.delete(code);

    const p1 = this.inputs.p1;
    const p2 = this.inputs.p2;
    if (down && !e.repeat) {
      if (code === "KeyJ") p1.light++;
      if (code === "KeyK") p1.heavy++;
      if (code === "KeyL") p1.dodge++;
      if (code === "KeyU") p1.special++;
      if (code === "Numpad1" || code === "Comma") p2.light++;
      if (code === "Numpad2" || code === "Period") p2.heavy++;
      if (code === "Numpad3" || code === "Slash") p2.dodge++;
      if (code === "Numpad0" || code === "ShiftRight") p2.special++;
    }
    if (code === "Space") p1.block = down;
    if (code === "Numpad5" || code === "ControlRight") p2.block = down;

    const kx = (down && this.keys.has("KeyD") ? 1 : 0) - (down && this.keys.has("KeyA") ? 1 : 0);
    const ky = (down && this.keys.has("KeyW") ? 1 : 0) - (down && this.keys.has("KeyS") ? 1 : 0);
    this.keyMove[0].set(kx, ky);
    const kx2 = (down && this.keys.has("ArrowRight") ? 1 : 0) - (down && this.keys.has("ArrowLeft") ? 1 : 0);
    const ky2 = (down && this.keys.has("ArrowUp") ? 1 : 0) - (down && this.keys.has("ArrowDown") ? 1 : 0);
    this.keyMove[1].set(kx2, ky2);
  }

  private setMessage(message: string, sub = "") {
    this.message = message;
    this.sub = sub;
    this.messageKey++;
  }

  toMenu() {
    this.phase = "menu";
    this.paused = false;
    this.winner = null;
    this.round = 1;
    this.scores = [0, 0];
    this.timer = ROUND_TIME;
    this.message = "";
    this.sub = "";
    this.resetFighters();
    this.fighters[0].pos.set(0.3, 0, 0.5);
    this.fighters[1].pos.set(3.6, 0, -0.3);
    this.fighters[0].facing = Math.atan2(3.3, -0.8);
    this.fighters[1].facing = Math.atan2(-3.3, 0.8);
    this.fighters.forEach((f) => {
      f.warrior.play("idle", 0.2);
      f.warrior.root.position.set(f.pos.x, 0, f.pos.z);
      f.warrior.root.rotation.y = f.facing;
    });
    this.audio.stopMusic();
    this.emitHud();
  }

  startMatch() {
    this.audio.init();
    this.audio.startMusic(this.arenaId);
    this.scores = [0, 0];
    this.round = 1;
    this.fighters[0].rounds = 0;
    this.fighters[1].rounds = 0;
    this.winner = null;
    this.resetFighters();
    this.beginCountdown();
    this.emitHud();
  }

  rematch() {
    this.startMatch();
  }

  private beginCountdown() {
    this.phase = "countdown";
    this.countdown = 4.0;
    this.timer = ROUND_TIME;
    this.paused = false;
    this.hitStop = 0;
    this.shake = 0;
    this.resetFighters();
    this.setMessage(`ROUND ${this.round}`, this.round === 1 ? "First to two rounds claims the arena" : "The gods demand more");
    this.audio.play("round");
    this.emitHud();
  }

  private resetFighters() {
    const [a, b] = this.fighters;
    a.pos.set(-2.9, 0, 0.5);
    b.pos.set(2.9, 0, -0.5);
    a.vel.set(0, 0, 0);
    b.vel.set(0, 0, 0);
    a.health = MAX_HEALTH;
    b.health = MAX_HEALTH;
    a.energy = 0;
    b.energy = 0;
    a.state = "idle";
    b.state = "idle";
    a.attack = null;
    b.attack = null;
    a.stun = 0;
    b.stun = 0;
    a.invuln = 0;
    b.invuln = 0;
    a.blocking = false;
    b.blocking = false;
    a.cooldowns = { light: 0, heavy: 0, dodge: 0, special: 0 };
    b.cooldowns = { light: 0, heavy: 0, dodge: 0, special: 0 };
    a.facing = Math.atan2(b.pos.x - a.pos.x, b.pos.z - a.pos.z);
    b.facing = Math.atan2(a.pos.x - b.pos.x, a.pos.z - b.pos.z);
    for (const f of this.fighters) {
      f.warrior.root.position.set(f.pos.x, 0, f.pos.z);
      f.warrior.root.rotation.y = f.facing;
      f.warrior.play("idle", 0.12);
      f.warrior.setGlow(0);
    }
    this.inputs.p1.light = this.inputs.p1.heavy = this.inputs.p1.dodge = this.inputs.p1.special = 0;
    this.inputs.p2.light = this.inputs.p2.heavy = this.inputs.p2.dodge = this.inputs.p2.special = 0;
    this.inputs.p1.block = false;
    this.inputs.p2.block = false;
    this.timer = ROUND_TIME;
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (p) {
      this.keys.clear();
      this.keyMove[0].set(0, 0);
      this.keyMove[1].set(0, 0);
      this.inputs.p1.block = false;
      this.inputs.p2.block = false;
      this.inputs.p1.x = this.inputs.p1.y = 0;
      this.inputs.p2.x = this.inputs.p2.y = 0;
    } else {
      this.clock.getDelta();
    }
    this.emitHud();
  }

  setQuality(q: Quality) {
    if (q === this.quality) return;
    this.quality = q;
    this.renderer.setPixelRatio(this.pixelRatio());
    this.renderer.shadowMap.enabled = q !== "low";
    this.arena.sun.castShadow = q !== "low";
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.material) {
        const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        list.forEach((m) => (m.needsUpdate = true));
      }
    });
    this.resize();
  }

  setArena(id: ArenaId) {
    if (id === this.arenaId) return;
    this.arenaId = id;
    this.arena.dispose();
    this.arena = buildArena(this.scene, id, this.quality);
    const pal = ARENAS[id];
    this.scene.background = new THREE.Color(pal.sky);
    this.scene.fog = new THREE.Fog(pal.fog, pal.fogNear, pal.fogFar);
    this.scene.environment = environmentTexture(id);
    if (this.phase === "menu") this.toMenu();
  }

  setMove(player: 0 | 1, x: number, y: number) {
    const pad = player === 0 ? this.inputs.p1 : this.inputs.p2;
    pad.x = clamp(x, -1, 1);
    pad.y = clamp(y, -1, 1);
  }

  press(player: 0 | 1, action: "light" | "heavy" | "dodge" | "special") {
    const pad = player === 0 ? this.inputs.p1 : this.inputs.p2;
    pad[action] += 1;
  }

  setBlock(player: 0 | 1, block: boolean) {
    const pad = player === 0 ? this.inputs.p1 : this.inputs.p2;
    pad.block = block;
  }

  setMuted(m: boolean) {
    this.audio.setMuted(m);
  }

  setVolume(v: number) {
    this.audio.setVolume(v);
  }

  getPhase() {
    return this.phase;
  }

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const raw = this.clock.getDelta();
    const dt = Math.min(raw, 0.05);
    this.fps = this.fps * 0.92 + (1 / Math.max(raw, 0.0001)) * 0.08;
    if (!this.paused) {
      this.elapsed += dt;
      this.update(dt);
    }
    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number) {
    this.arena.update(dt, this.elapsed);
    this.vfx.update(dt);
    const animDt = this.hitStop > 0 ? dt * 0.12 : dt;

    if (this.phase === "menu" || this.phase === "matchOver") {
      if (this.phase === "menu") this.updateMenuCamera(dt);
      else this.updateCamera(dt);
      for (const f of this.fighters) {
        f.warrior.update(animDt, this.elapsed);
        f.warrior.setMotion(0);
      }
      this.emitHudThrottled(dt);
      return;
    }

    if (this.phase === "countdown") {
      this.countdown -= dt;
      const n = Math.ceil(this.countdown);
      if (this.countdown <= 0.4) {
        if (this.message !== "FIGHT!") this.setMessage("FIGHT!", "Strike true, champions");
        this.phase = "fight";
        this.bannerTimer = 0.9;
        this.audio.play("charge");
      } else if (n !== Math.ceil(this.countdown + dt) && n <= 3 && n >= 1) {
        this.setMessage(String(n), "");
        this.audio.play("ui");
      }
      for (const f of this.fighters) {
        f.warrior.update(animDt, this.elapsed);
        f.warrior.setMotion(0);
      }
      this.updateCamera(dt);
      this.emitHudThrottled(dt);
      return;
    }

    if (this.phase === "fight") {
      if (this.bannerTimer > 0) {
        this.bannerTimer -= dt;
        if (this.bannerTimer <= 0 && this.message === "FIGHT!") {
          this.message = "";
          this.sub = "";
          this.messageKey++;
        }
      }
      // impact freeze: pause fighters for a few frames so hits feel heavy
      if (this.hitStop > 0) {
        this.hitStop -= dt;
        this.updateCamera(dt);
        this.emitHudThrottled(dt);
        return;
      }
      this.timer = Math.max(0, this.timer - dt);
      this.updateFighter(this.fighters[0], this.fighters[1], dt);
      this.updateFighter(this.fighters[1], this.fighters[0], dt);
      this.resolveOverlap();
      this.updateCamera(dt);
      if (this.timer <= 0) {
        const [a, b] = this.fighters;
        if (a.health === b.health) this.endRound(null, "TIME");
        else this.endRound(a.health > b.health ? 0 : 1, "TIME");
      }
      this.emitHudThrottled(dt);
      return;
    }

    if (this.phase === "roundOver") {
      this.roundEndTimer -= dt;
      for (const f of this.fighters) {
        f.warrior.update(animDt, this.elapsed);
        f.warrior.setMotion(0);
        f.vel.multiplyScalar(Math.max(0, 1 - dt * 4));
        f.pos.addScaledVector(f.vel, dt);
        f.warrior.root.position.set(f.pos.x, 0, f.pos.z);
      }
      this.updateCamera(dt);
      if (this.roundEndTimer <= 0) {
        if (this.scores[0] >= 2 || this.scores[1] >= 2) {
          this.phase = "matchOver";
          this.winner = this.scores[0] >= 2 ? 0 : 1;
          const w = this.fighters[this.winner];
          this.setMessage(`${w.cfg.name} WINS`, "The arena remembers its champion");
          this.audio.play("victory");
          w.warrior.play("victory", 0.25);
          this.emitHud();
        } else {
          this.round++;
          this.beginCountdown();
        }
      }
      this.emitHudThrottled(dt);
    }
  }

  private updateFighter(f: Fighter, opp: Fighter, dt: number) {
    f.cooldowns.light = Math.max(0, f.cooldowns.light - dt);
    f.cooldowns.heavy = Math.max(0, f.cooldowns.heavy - dt);
    f.cooldowns.dodge = Math.max(0, f.cooldowns.dodge - dt);
    f.cooldowns.special = Math.max(0, f.cooldowns.special - dt);
    f.invuln = Math.max(0, f.invuln - dt);
    f.stun = Math.max(0, f.stun - dt);
    f.hitFlash = Math.max(0, f.hitFlash - dt);
    f.stateTime += dt;
    f.trailTimer -= dt;

    // KO / victory are terminal for the round: only slide and settle.
    if (f.state === "ko" || f.state === "victory") {
      f.pos.addScaledVector(f.vel, dt);
      f.vel.multiplyScalar(Math.max(0, 1 - dt * 4));
      const r = Math.hypot(f.pos.x, f.pos.z);
      if (r > ARENA_LIMIT) {
        f.pos.x = (f.pos.x / r) * ARENA_LIMIT;
        f.pos.z = (f.pos.z / r) * ARENA_LIMIT;
      }
      f.warrior.root.position.set(f.pos.x, 0, f.pos.z);
      f.warrior.update(dt, this.elapsed);
      return;
    }

    const pad = f.index === 0 ? this.inputs.p1 : this.inputs.p2;
    const keyVec = this.keyMove[f.index];
    let mx = pad.x;
    let my = pad.y;
    if (keyVec.lengthSq() > 0.01) {
      mx = keyVec.x;
      my = keyVec.y;
    }
    const pressed = {
      light: pad.light > 0,
      heavy: pad.heavy > 0,
      dodge: pad.dodge > 0,
      special: pad.special > 0,
    };
    pad.light = Math.max(0, pad.light - 1);
    pad.heavy = Math.max(0, pad.heavy - 1);
    pad.dodge = Math.max(0, pad.dodge - 1);
    pad.special = Math.max(0, pad.special - 1);

    const mag = Math.min(1, Math.hypot(mx, my));
    const moveDir = this.tmpA.set(0, 0, 0);
    if (mag > 0.08) {
      const forward = this.tmpB;
      this.camera.getWorldDirection(forward);
      forward.y = 0;
      if (forward.lengthSq() < 0.001) forward.set(0, 0, -1);
      forward.normalize();
      const right = this.tmpC.crossVectors(forward, this.up).normalize();
      moveDir.addScaledVector(forward, my).addScaledVector(right, mx).normalize();
    }

    const canStart = f.state === "idle" || f.state === "block";
    if (canStart && f.stun <= 0) {
      if (pressed.special && f.energy >= MAX_ENERGY && f.cooldowns.special <= 0) {
        this.startAttack(f, "special");
      } else if (pressed.heavy && f.cooldowns.heavy <= 0) {
        this.startAttack(f, "heavy");
      } else if (pressed.light && f.cooldowns.light <= 0) {
        this.startAttack(f, "light");
      } else if (pressed.dodge && f.cooldowns.dodge <= 0) {
        this.startDodge(f, moveDir, mag);
      }
    }

    if (f.state === "attack" && f.attack) {
      const spec = f.attack.spec;
      f.attack.time += dt;
      const t = f.attack.time;
      // forward lunge during the wind-up
      if (t < spec.activeStart) {
        const lungeSpeed = spec.lunge * (1 - t / spec.activeStart);
        f.pos.x += Math.sin(f.facing) * lungeSpeed * dt;
        f.pos.z += Math.cos(f.facing) * lungeSpeed * dt;
      }
      if (!f.attack.hasHit && t >= spec.activeStart && t <= spec.activeEnd) {
        this.tryHit(f, opp, spec);
        if (spec.kind !== "light" && f.trailTimer <= 0) {
          f.trailTimer = 0.016;
          const tip = new THREE.Vector3();
          f.warrior.weaponTip.getWorldPosition(tip);
          this.vfx.trail(tip, f.cfg.palette.glow);
        }
      }
      if (t >= spec.duration) {
        f.state = "idle";
        f.stateTime = 0;
        f.attack = null;
        f.cooldowns[spec.kind] = spec.cooldown;
      }
    } else if (f.state === "dodge") {
      f.pos.addScaledVector(f.vel, dt);
      f.vel.multiplyScalar(Math.max(0, 1 - dt * 5.5));
      if (f.stateTime >= 0.44) {
        f.state = "idle";
        f.stateTime = 0;
      }
    } else if (f.state === "hit") {
      f.pos.addScaledVector(f.vel, dt);
      f.vel.multiplyScalar(Math.max(0, 1 - dt * 6));
      if (f.stun <= 0) {
        f.state = "idle";
        f.stateTime = 0;
      }
    } else {
      // free movement
      f.blocking = pad.block && f.stun <= 0;
      const speed = f.blocking ? BLOCK_SPEED : mag > 0.82 ? RUN_SPEED : WALK_SPEED;
      const targetVx = moveDir.x * speed * mag;
      const targetVz = moveDir.z * speed * mag;
      f.vel.x = damp(f.vel.x, targetVx, 12, dt);
      f.vel.z = damp(f.vel.z, targetVz, 12, dt);
      f.pos.addScaledVector(f.vel, dt);
      if (f.blocking) {
        f.state = "block";
      } else if (f.state === "block") {
        f.state = "idle";
        f.stateTime = 0;
      }
    }

    // keep inside the arena
    const r = Math.hypot(f.pos.x, f.pos.z);
    if (r > ARENA_LIMIT) {
      f.pos.x = (f.pos.x / r) * ARENA_LIMIT;
      f.pos.z = (f.pos.z / r) * ARENA_LIMIT;
      f.vel.multiplyScalar(0.4);
    }

    // face the opponent (locked while attacking / dodging / staggered)
    if (f.state !== "attack" && f.state !== "dodge" && f.state !== "hit") {
      const target = Math.atan2(opp.pos.x - f.pos.x, opp.pos.z - f.pos.z);
      f.facing = angleLerp(f.facing, target, 1 - Math.exp(-12 * dt));
    }

    f.warrior.root.position.set(f.pos.x, 0, f.pos.z);
    f.warrior.root.rotation.y = f.facing;
    f.warrior.setMotion(Math.hypot(f.vel.x, f.vel.z));
    f.warrior.setGlow(f.energy / MAX_ENERGY);
    f.warrior.update(dt, this.elapsed);

    // choose animation state
    const speed = Math.hypot(f.vel.x, f.vel.z);
    const anim = pickAnimation(f.state, f.blocking, speed, f.attack?.spec.kind);
    f.warrior.play(anim, anim === "light" || anim === "heavy" || anim === "special" ? 0.05 : 0.13);
  }

  private startAttack(f: Fighter, kind: "light" | "heavy" | "special") {
    const spec = ATTACKS[kind];
    if (kind === "special") f.energy = 0;
    f.state = "attack";
    f.stateTime = 0;
    f.attack = { spec, time: 0, hasHit: false };
    f.blocking = false;
    f.vel.multiplyScalar(0.2);
    // snap facing to the opponent at the start of the swing
    const opp = this.fighters[f.index === 0 ? 1 : 0];
    f.facing = Math.atan2(opp.pos.x - f.pos.x, opp.pos.z - f.pos.z);
    f.warrior.play(kind, 0.05);
    this.audio.play(kind === "light" ? "swing_light" : "swing_heavy");
    if (kind === "special") {
      this.audio.play("charge");
      this.vfx.ring(f.pos, f.cfg.palette.glow, 3.4, 0.6);
      this.vfx.flash(new THREE.Vector3(f.pos.x, 1.2, f.pos.z), f.cfg.palette.glow, 2.4, 0.35);
    }
  }

  private startDodge(f: Fighter, moveDir: THREE.Vector3, mag: number) {
    f.state = "dodge";
    f.stateTime = 0;
    f.invuln = 0.3;
    f.cooldowns.dodge = 0.85;
    f.blocking = false;
    const dir = mag > 0.1 ? moveDir.clone() : new THREE.Vector3(-Math.sin(f.facing), 0, -Math.cos(f.facing));
    f.vel.copy(dir).multiplyScalar(10.5);
    f.warrior.play("dodge", 0.05);
    this.audio.play("dodge");
    this.vfx.ring(f.pos, f.cfg.palette.glow, 1.8, 0.35, 0.08);
  }

  private tryHit(attacker: Fighter, defender: Fighter, spec: AttackSpec) {
    if (defender.invuln > 0 || defender.state === "ko") return;
    const dx = defender.pos.x - attacker.pos.x;
    const dz = defender.pos.z - attacker.pos.z;
    const dist = Math.hypot(dx, dz);
    if (dist > spec.range + BODY_RADIUS) return;
    const nx = dx / Math.max(dist, 0.0001);
    const nz = dz / Math.max(dist, 0.0001);
    const fx = Math.sin(attacker.facing);
    const fz = Math.cos(attacker.facing);
    const dot = fx * nx + fz * nz;
    if (dot < spec.arc) return;

    attacker.attack!.hasHit = true;
    const hitPoint = new THREE.Vector3(
      attacker.pos.x + nx * Math.min(dist * 0.6, 1.2),
      1.05 + Math.random() * 0.25,
      attacker.pos.z + nz * Math.min(dist * 0.6, 1.2)
    );
    const facingDot = Math.sin(defender.facing) * -nx + Math.cos(defender.facing) * -nz;
    const blocked = defender.blocking && facingDot > 0.15 && defender.state === "block";
    const heavy = spec.kind !== "light";

    if (blocked) {
      const dmg = spec.damage * 0.22;
      defender.health = Math.max(0, defender.health - dmg);
      defender.energy = Math.min(MAX_ENERGY, defender.energy + 7);
      defender.vel.set(nx * spec.knockback * 0.35, 0, nz * spec.knockback * 0.35);
      attacker.energy = Math.min(MAX_ENERGY, attacker.energy + spec.energyGain * 0.4);
      this.audio.play("block");
      this.vfx.sparksBurst(hitPoint, 0xffe6a8, 12, 0.9);
      this.vfx.flash(hitPoint, 0xffd27a, 1.1, 0.16);
      this.shake = Math.max(this.shake, spec.shake * 0.4);
      this.hitStop = 0.03;
    } else {
      defender.health = Math.max(0, defender.health - spec.damage);
      defender.energy = Math.min(MAX_ENERGY, defender.energy + 8);
      defender.state = "hit";
      defender.stateTime = 0;
      defender.stun = spec.hitstun;
      defender.attack = null;
      defender.blocking = false;
      defender.vel.set(nx * spec.knockback, 0, nz * spec.knockback);
      defender.hitFlash = 0.25;
      attacker.energy = Math.min(MAX_ENERGY, attacker.energy + spec.energyGain);
      this.audio.play(heavy ? "hit_heavy" : "hit_light");
      this.vfx.sparksBurst(hitPoint, attacker.cfg.palette.glow, heavy ? 30 : 15, heavy ? 1.5 : 1);
      this.vfx.flash(hitPoint, attacker.cfg.palette.glow, heavy ? 2.4 : 1.5, heavy ? 0.26 : 0.18);
      this.vfx.slash(hitPoint, attacker.cfg.palette.glow, heavy, this.camera);
      this.vfx.ring(defender.pos, attacker.cfg.palette.glow, heavy ? 3.6 : 2.2, 0.5);
      this.shake = Math.max(this.shake, spec.shake);
      this.hitStop = heavy ? 0.085 : 0.045;
      if (defender.health <= 0) {
        defender.state = "ko";
        defender.stateTime = 0;
        defender.vel.set(nx * 3, 0, nz * 3);
        defender.warrior.play("ko", 0.08);
        this.audio.play("ko");
        this.endRound(attacker.index, "K.O.");
      }
    }
    this.emitHud();
  }

  private resolveOverlap() {
    const [a, b] = this.fighters;
    const dx = b.pos.x - a.pos.x;
    const dz = b.pos.z - a.pos.z;
    const dist = Math.hypot(dx, dz);
    if (dist < FIGHTER_SEPARATION && dist > 0.0001) {
      const push = (FIGHTER_SEPARATION - dist) / 2;
      const nx = dx / dist;
      const nz = dz / dist;
      a.pos.x -= nx * push;
      a.pos.z -= nz * push;
      b.pos.x += nx * push;
      b.pos.z += nz * push;
    }
  }

  private endRound(winner: 0 | 1 | null, reason: "K.O." | "TIME") {
    if (this.phase !== "fight") return;
    this.phase = "roundOver";
    this.roundEndTimer = 3.4;
    this.hitStop = 0;
    if (winner !== null) {
      this.scores[winner]++;
      this.fighters[winner].rounds++;
      const loser = this.fighters[winner === 0 ? 1 : 0];
      loser.state = reason === "K.O." ? "ko" : "idle";
      loser.warrior.play(reason === "K.O." ? "ko" : "idle", 0.1);
      this.fighters[winner].state = "victory";
      this.fighters[winner].warrior.play("victory", 0.2);
      this.setMessage(reason === "K.O." ? "K.O." : "TIME", `${this.fighters[winner].cfg.name} takes round ${this.round}`);
      this.audio.play("victory");
      this.vfx.ring(loser.pos, this.fighters[winner].cfg.palette.glow, 4.5, 0.9);
    } else {
      this.setMessage("DRAW", "No champion this round");
      this.fighters.forEach((f) => {
        f.state = "idle";
        f.warrior.play("idle", 0.2);
      });
      this.audio.play("defeat");
    }
    this.emitHud();
  }

  private updateCamera(dt: number) {
    const [a, b] = this.fighters;
    if (this.phase === "menu") {
      this.updateMenuCamera(dt);
      return;
    }
    if (this.phase === "matchOver" && this.winner !== null) {
      const w = this.fighters[this.winner];
      const t = this.elapsed * 0.35;
      const desired = this.tmpE.set(
        w.pos.x + Math.sin(t) * 5.2,
        2.4 + Math.sin(t * 0.7) * 0.4,
        w.pos.z + Math.cos(t) * 5.2
      );
      this.camera.position.lerp(desired, 1 - Math.exp(-2.2 * dt));
      this.lookTarget.lerp(this.tmpD.set(w.pos.x, 1.2, w.pos.z), 1 - Math.exp(-4 * dt));
      this.camera.lookAt(this.lookTarget);
      return;
    }
    const mid = this.tmpD.addVectors(a.pos, b.pos).multiplyScalar(0.5);
    const sep = a.pos.distanceTo(b.pos);
    // fit both fighters horizontally for the current aspect ratio, then add headroom
    const frameWidth = 7.4 + sep * 0.6;
    const vFov = THREE.MathUtils.degToRad(this.camera.fov);
    const hFov = 2 * Math.atan(Math.tan(vFov / 2) * this.camera.aspect);
    const dist = clamp(frameWidth / 2 / Math.tan(hFov / 2), 5.2, 26);
    const height = 2.7 + frameWidth * 0.14;
    const desired = this.tmpE.set(mid.x * 0.8, height, mid.z * 0.5 + dist);
    this.camera.position.lerp(desired, 1 - Math.exp(-3.4 * dt));
    this.lookTarget.lerp(this.tmpC.set(mid.x * 0.9, 1.15, mid.z * 0.7), 1 - Math.exp(-5 * dt));
    if (this.shake > 0.001) {
      const s = this.shake;
      this.camera.position.x += (Math.random() - 0.5) * s * 0.55;
      this.camera.position.y += (Math.random() - 0.5) * s * 0.4;
      this.camera.position.z += (Math.random() - 0.5) * s * 0.3;
      this.shake = Math.max(0, this.shake - dt * 2.6);
    }
    this.camera.lookAt(this.lookTarget);
  }

  private updateMenuCamera(dt: number) {
    const t = this.elapsed * 0.16;
    const desired = this.tmpE.set(Math.sin(t) * 1.6 - 0.6, 3.0 + Math.sin(t * 0.8) * 0.22, 9.2);
    this.camera.position.lerp(desired, 1 - Math.exp(-2 * dt));
    this.lookTarget.lerp(this.tmpD.set(-2.0, 1.25, 0), 1 - Math.exp(-3 * dt));
    this.camera.lookAt(this.lookTarget);
  }

  private emitHudThrottled(dt: number) {
    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.07;
      this.emitHud();
    }
  }

  private emitHud() {
    if (this.disposed) return;
    const mk = (f: Fighter) => ({
      name: f.cfg.name,
      epithet: f.cfg.epithet,
      health: Math.round(f.health * 10) / 10,
      maxHealth: MAX_HEALTH,
      energy: Math.round(f.energy),
      rounds: f.rounds,
      accent: f.cfg.palette.glowCss,
      blocking: f.blocking,
      state: f.state,
      cooldowns: {
        light: f.cooldowns.light / ATTACKS.light.cooldown,
        heavy: f.cooldowns.heavy / ATTACKS.heavy.cooldown,
        dodge: f.cooldowns.dodge / 0.85,
        special: f.cooldowns.special / ATTACKS.special.cooldown,
      },
    });
    const hud: HudState = {
      phase: this.phase,
      round: this.round,
      timer: Math.ceil(this.timer),
      message: this.message,
      sub: this.sub,
      messageKey: this.messageKey,
      winner: this.winner,
      fighters: [mk(this.fighters[0]), mk(this.fighters[1])],
      score: [this.scores[0], this.scores[1]],
      fps: Math.round(this.fps),
    };
    this.opts.onHud(hud);
  }

  dispose() {
    this.disposed = true;
    delete (window as unknown as { __TITAN__?: unknown }).__TITAN__;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("orientationchange", this.onResize);
    document.removeEventListener("visibilitychange", this.onVisibility);
    this.resizeObserver?.disconnect();
    this.audio.dispose();
    this.vfx.dispose();
    this.arena.dispose();
    this.fighters.forEach((f) => {
      this.scene.remove(f.warrior.root);
      f.warrior.dispose();
    });
    this.scene.environment = null;
    this.renderer.dispose();
    this.renderer.forceContextLoss();
  }
}
