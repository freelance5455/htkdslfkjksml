import { ITEMS } from "./data/items";
import { MISSIONS, missionById } from "./data/missions";
import { NPCS } from "./data/npcs";
import { AREA_DEFS } from "./data/areas";
import type {
  Choice,
  EffectMap,
  Ending,
  GameState,
  Mission,
  NpcState,
  NpcStats,
  StatKey,
} from "./types";

export const SAVE_KEY = "caminho_do_poder_save_v1";
export const HS_KEY = "caminho_do_poder_highscores_v1";
export const NAME_KEY = "caminho_do_poder_name_v1";

export const AREA_NAME: Record<string, string> = Object.fromEntries(
  AREA_DEFS.map((a) => [a.id, a.name])
);

export function createInitialState(playerName: string): GameState {
  const npcs: Record<string, NpcState> = {};
  NPCS.forEach((n) => {
    npcs[n.id] = {
      id: n.id,
      trust: n.initial.trust,
      respect: n.initial.respect,
      fear: n.initial.fear,
      loyalty: n.initial.loyalty,
      ambition: n.initial.ambition,
      areaId: n.areaId,
      x: n.x,
      y: n.y,
      alive: true,
      memories: [],
    };
  });
  return {
    version: 1,
    started: true,
    player: { x: 19, y: 16, areaId: "vila", facing: "down", anim: 0, moving: false },
    stats: { influence: 5, reputation: 10, intelligence: 8, wealth: 60, power: 2 },
    score: 0,
    inventory: [],
    npcs,
    flags: [],
    memoriesByLaw: {},
    currentMission: 1,
    missionStep: 0,
    completedMissions: [],
    unlockedAreas: ["vila"],
    discoveredAreas: ["vila"],
    knownLaws: [],
    worldItems: [],
    log: [],
    toasts: [],
    floaters: [],
    particles: [],
    gameOver: null,
    ending: null,
    playerName,
    turnCount: 0,
    time: 0,
  };
}

export const nextMission = (state: GameState): Mission | null => {
  const done = new Set(state.completedMissions);
  for (const m of MISSIONS) {
    if (!done.has(m.id)) return m;
  }
  return null;
};

export const missionForNpc = (state: GameState, npcId: string): Mission | null => {
  const m = nextMission(state);
  if (!m) return null;
  return m.giverNpc === npcId ? m : null;
};

export function addItem(state: GameState, id: string, count = 1) {
  const found = state.inventory.find((i) => i.id === id);
  if (found) found.count += count;
  else state.inventory.push({ id, count });
}

export function removeItem(state: GameState, id: string, count = 1) {
  const found = state.inventory.find((i) => i.id === id);
  if (!found) return false;
  found.count -= count;
  if (found.count <= 0) state.inventory = state.inventory.filter((i) => i.id !== id);
  return true;
}

export const hasItem = (state: GameState, id: string) =>
  state.inventory.some((i) => i.id === id && i.count > 0);

export const hasFlag = (state: GameState, f: string) => state.flags.includes(f);

export function applyEffects(state: GameState, eff?: EffectMap) {
  if (!eff) return;
  (Object.keys(eff) as StatKey[]).forEach((k) => {
    state.stats[k] = Math.max(0, Math.round(state.stats[k] + (eff[k] ?? 0)));
  });
}

export function adjustNpc(state: GameState, id: string, deltas: Partial<NpcStats>) {
  const n = state.npcs[id];
  if (!n) return;
  (Object.keys(deltas) as (keyof NpcStats)[]).forEach((k) => {
    n[k] = Math.max(0, Math.min(100, n[k] + (deltas[k] ?? 0)));
  });
}

export function addMemory(state: GameState, npcId: string, text: string, kind: "good" | "bad" | "info", mission: number) {
  const n = state.npcs[npcId];
  if (!n) return;
  n.memories.unshift({ id: `${mission}-${n.memories.length}-${text.length}`, text, kind, mission });
  if (n.memories.length > 12) n.memories.pop();
}

export function addLog(state: GameState, text: string, tone: "good" | "bad" | "info" | "gold", mission?: number) {
  state.log.unshift({ id: state.log.length + Date.now() + Math.random(), text, tone, mission });
  if (state.log.length > 60) state.log.pop();
}

export function addToast(state: GameState, text: string, tone: "good" | "bad" | "info" | "gold") {
  state.toasts.push({ id: Date.now() + Math.random(), text, tone, at: Date.now() });
  if (state.toasts.length > 4) state.toasts.shift();
}

export function checkRequirement(state: GameState, choice: Choice): boolean {
  const req = choice.req;
  if (!req) return true;
  if (req.stat) {
    for (const k of Object.keys(req.stat) as StatKey[]) {
      if (state.stats[k] < (req.stat[k] ?? 0)) return false;
    }
  }
  if (req.item && !hasItem(state, req.item)) return false;
  if (req.flag && !hasFlag(state, req.flag)) return false;
  if (req.npcTrust) {
    const n = state.npcs[req.npcTrust.id];
    if (!n || n.trust < req.npcTrust.min) return false;
  }
  return true;
}

export interface ChoiceResult {
  outcome: string;
  completed: boolean;
  failed: boolean;
  scoreGained: number;
  statDeltas: EffectMap;
}

/** Applies a chosen dialogue choice to the world. */
export function applyChoice(state: GameState, mission: Mission, choice: Choice): ChoiceResult {
  applyEffects(state, choice.effects);
  choice.npc?.forEach((n) => adjustNpc(state, n.id, n.deltas));
  choice.give?.forEach((g) => addItem(state, g.item, g.count));
  choice.take?.forEach((t) => removeItem(state, t.item, t.count));
  choice.flags?.forEach((f) => {
    if (!state.flags.includes(f)) state.flags.push(f);
  });

  const scoreGained = choice.score ?? 0;
  state.score += scoreGained;

  if (choice.npc?.length) {
    const main = choice.npc[0];
    const good = (main.deltas.trust ?? 0) + (main.deltas.respect ?? 0) - (main.deltas.fear ?? 0) > 0;
    const bad = (main.deltas.trust ?? 0) + (main.deltas.respect ?? 0) - (main.deltas.fear ?? 0) < 0;
    addMemory(
      state,
      main.id,
      choice.text,
      bad ? "bad" : good ? "good" : "info",
      mission.id
    );
  }

  const failed = choice.end === "fail";
  const completed = choice.end === "mission" || failed;

  if (choice.effects) {
    const parts: string[] = [];
    (Object.keys(choice.effects) as StatKey[]).forEach((k) => {
      const v = choice.effects![k]!;
      if (v !== 0) parts.push(`${v > 0 ? "+" : ""}${v} ${k === "wealth" ? "ouro" : k}`);
    });
    if (parts.length) addToast(state, parts.join("  "), "good");
  }
  if (scoreGained) addToast(state, `+${scoreGained} pontos de poder`, "gold");

  return { outcome: choice.outcome, completed, failed, scoreGained, statDeltas: choice.effects ?? {} };
}

export function completeMission(state: GameState, mission: Mission, failed = false) {
  if (!state.completedMissions.includes(mission.id)) state.completedMissions.push(mission.id);
  if (!failed) {
    applyEffects(state, mission.reward.effects);
    state.score += mission.reward.score;
    if (mission.reward.item) addItem(state, mission.reward.item, 1);
    if (!state.knownLaws.includes(mission.id)) state.knownLaws.push(mission.id);
    mission.unlockAreas?.forEach((a) => {
      if (!state.unlockedAreas.includes(a)) {
        state.unlockedAreas.push(a);
        addToast(state, `Nova região liberada: ${AREA_NAME[a] ?? a}`, "gold");
      }
    });
    addLog(state, `Lei ${mission.id} dominada: ${mission.lawTitle}`, "gold", mission.id);
  } else {
    addLog(state, `Lei ${mission.id}: fracasso. A corte vai lembrar.`, "bad", mission.id);
    state.stats.reputation = Math.max(0, state.stats.reputation - 3);
  }
  const m = nextMission(state);
  state.currentMission = m ? m.id : null;
  state.missionStep = 0;
  if (!m) {
    state.ending = computeEnding(state);
  }
}

export function currentStep(state: GameState): Mission["steps"][number] | null {
  const m = state.currentMission !== null ? missionById(state.currentMission) : null;
  if (!m) return null;
  return m.steps[state.missionStep] ?? null;
}

export interface EndingInfo {
  id: Ending;
  title: string;
  text: string;
  tone: "gold" | "bad" | "info";
}

export function computeEnding(state: GameState): Ending {
  const f = state.flags;
  const { influence, reputation, wealth, power } = state.stats;
  if (reputation <= 0 && power <= 10) return "ruin";
  if (f.includes("coroado") && power >= 40) return "king";
  if (power >= 42 && influence >= 38) return "advisor";
  if (power >= 30) return "shadow";
  if (
    reputation >= 25 &&
    (f.includes("padrinho_da_igreja") || f.includes("herdeiro_no_olhar") || f.includes("promessa_de_pao"))
  )
    return "dynasty";
  if (wealth >= 700) return "noble";
  if (power >= 18) return "shadow";
  return "ruin";
}

export const ENDINGS: Record<Ending, EndingInfo> = {
  king: {
    id: "king",
    title: "A COROA É SUA",
    text: "Você tomou a coroa de um rei moribundo. O reino se curva, o povo hesita, e a história vai perguntar se você foi um rei ou apenas um homem muito esperto numa hora de transição.",
    tone: "gold",
  },
  advisor: {
    id: "advisor",
    title: "O CONSELHEIRO QUE COMANDA",
    text: "Você não sentou no trono: sentou ao lado dele, e de lá governou melhor do que qualquer rei. Quando o rei morre, o trono fica vago — e o advice continua.",
    tone: "gold",
  },
  shadow: {
    id: "shadow",
    title: "O PODER SEM TRONO",
    text: "Ninguém sabe que você decide. A corte obedece a um rei fraco, o povo obedece a um título vazio, e ambos obedecem a você. O poder perfeito é o poder que ninguém aponta.",
    tone: "info",
  },
  noble: {
    id: "noble",
    title: "O GRANDE NOBRE",
    text: "Você não quis o trono: quis uma casa forte, com terras, gente e ouro. O reino continua igual, mas tem um novo senhor — e ele se lembra de quem o fez subir.",
    tone: "info",
  },
  dynasty: {
    id: "dynasty",
    title: "A DINASTIA",
    text: "Você não precisou da coroa: precisou de gente, de fé e de filhos. Em dez anos o reino vai falar do seu nome como se sempre o tivesse dito.",
    tone: "gold",
  },
  ruin: {
    id: "ruin",
    title: "A RUÍNA",
    text: "Você subiu alto demais, rápido demais, e sem gente o bastante para segurar o que subiu. Falam do seu nome na praça, mas nunca em tom de respeito. A corte não odeia: só apaga.",
    tone: "bad",
  },
};

export function npcMood(n: NpcState): { label: string; color: string } {
  const v = n.trust + n.respect + n.loyalty - n.fear;
  if (n.fear >= 45 && n.trust < 20) return { label: "Aterrorizado", color: "#b0556a" };
  if (v >= 90) return { label: "Aliado leal", color: "#7ed08a" };
  if (v >= 50) return { label: "Favorável", color: "#9fd06a" };
  if (v >= 15) return { label: "Neutro", color: "#c8c08a" };
  if (v >= -15) return { label: "Desconfiado", color: "#d09a5a" };
  if (v >= -45) return { label: "Hostil", color: "#d0705a" };
  return { label: "Inimigo", color: "#c0404a" };
}

export function itemDef(id: string) {
  return ITEMS[id];
}

/* ------------------------------ persistence ----------------------------- */

/* Storage that survives file:// origins (Android WebView) and private mode. */
const memStore = new Map<string, string>();

export const storage = {
  get(key: string): string | null {
    try {
      const v = window.localStorage.getItem(key);
      if (v !== null) return v;
    } catch {
      /* fall through to memory */
    }
    return memStore.has(key) ? memStore.get(key)! : null;
  },
  set(key: string, value: string): boolean {
    memStore.set(key, value);
    try {
      window.localStorage.setItem(key, value);
      return true;
    } catch {
      return false;
    }
  },
  remove(key: string) {
    memStore.delete(key);
    try {
      window.localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
  },
};

export function saveGame(state: GameState) {
  try {
    return storage.set(SAVE_KEY, JSON.stringify(state));
  } catch {
    return false;
  }
}

export function loadGame(): GameState | null {
  try {
    const raw = storage.get(SAVE_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as GameState;
    if (!s || s.version !== 1) return null;
    return s;
  } catch {
    return null;
  }
}

export function clearSave() {
  storage.remove(SAVE_KEY);
}

export interface HighScore {
  name: string;
  score: number;
  ending: string;
  laws: number;
  date: number;
}

export function loadScores(): HighScore[] {
  try {
    const raw = storage.get(HS_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as HighScore[];
    return Array.isArray(arr) ? arr.sort((a, b) => b.score - a.score).slice(0, 8) : [];
  } catch {
    return [];
  }
}

export function saveScore(entry: HighScore) {
  const arr = loadScores();
  arr.push(entry);
  arr.sort((a, b) => b.score - a.score);
  storage.set(HS_KEY, JSON.stringify(arr.slice(0, 8)));
}

export function loadPlayerName(): string {
  try {
    return storage.get(NAME_KEY) || "";
  } catch {
    return "";
  }
}

export function savePlayerName(name: string) {
  storage.set(NAME_KEY, name);
}
