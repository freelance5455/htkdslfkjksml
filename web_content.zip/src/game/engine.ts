import type { Word } from "./words";

export type Mode = "tap" | "type" | "meaning";
export type Difficulty = "easy" | "normal" | "hard";

export interface EngineConfig {
  mode: Mode;
  difficulty: Difficulty;
  words: Word[];
  lessonId: string;
  lessonTitle: string;
}

export interface HudState {
  score: number;
  combo: number;
  maxCombo: number;
  multiplier: number;
  hearts: number;
  maxHearts: number;
  level: number;
  prompt: string;
  promptIsEnglish: boolean;
  answer: string;
  buffer: string;
  hintPattern: string;
  mastered: number;
  total: number;
  round: number;
  correctCount: number;
  wrongCount: number;
  missedCount: number;
}

export interface GameResult {
  score: number;
  correct: number;
  wrong: number;
  missed: number;
  maxCombo: number;
  mastered: number;
  total: number;
  win: boolean;
  seconds: number;
  lessonId: string;
  lessonTitle: string;
  mode: Mode;
  difficulty: Difficulty;
  answered: { word: Word; ok: boolean }[];
}

export type EngineEvent =
  | { type: "correct"; word: Word; points: number; combo: number }
  | { type: "life" }
  | { type: "wrong" }
  | { type: "miss"; word: Word }
  | { type: "levelup"; level: number }
  | { type: "round"; word: Word }
  | { type: "countdown"; n: number }
  | { type: "hint" }
  | { type: "gameover"; result: GameResult };

interface Tile {
  id: number;
  text: string;
  isTarget: boolean;
  x: number;
  y: number;
  w: number;
  h: number;
  fs: number;
  vy: number;
  born: number;
  dying: number;
  hint: number;
  color: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  rot: number;
  spin: number;
  square: boolean;
}

interface Ring {
  x: number;
  y: number;
  r: number;
  maxR: number;
  life: number;
  maxLife: number;
  color: string;
}

interface Popup {
  x: number;
  y: number;
  text: string;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

interface Star {
  x: number;
  y: number;
  r: number;
  v: number;
  a: number;
}

const DIFFICULTY: Record<
  Difficulty,
  { tiles: number; time: number; hearts: number }
> = {
  easy: { tiles: 3, time: 14, hearts: 4 },
  normal: { tiles: 4, time: 10.5, hearts: 3 },
  hard: { tiles: 5, time: 8.5, hearts: 3 },
};

const PALETTE = [
  "#22d3ee",
  "#a78bfa",
  "#f472b6",
  "#facc15",
  "#34d399",
  "#fb923c",
  "#60a5fa",
];

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const rand = (a: number, b: number) => a + Math.random() * (b - a);

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function easeOutBack(t: number) {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private config: EngineConfig;
  private hooks: {
    onState: (s: HudState) => void;
    onTick: (remaining: number, max: number) => void;
    onEvent: (e: EngineEvent) => void;
  };

  private W = 0;
  private H = 0;
  private dpr = 1;
  private raf = 0;
  private bgCanvas: HTMLCanvasElement | null = null;
  private bgGradient: CanvasGradient | null = null;
  private lastTime = 0;
  private phase: "idle" | "countdown" | "playing" | "paused" | "over" = "idle";
  private resizeObs: ResizeObserver | null = null;

  private tiles: Tile[] = [];
  private particles: Particle[] = [];
  private rings: Ring[] = [];
  private popups: Popup[] = [];
  private stars: Star[] = [];
  private nextId = 1;

  private target: Word | null = null;
  private buffer = "";
  private hintRevealed = 0;
  private hintUsedThisRound = false;
  private timeLeft = 0;
  private timeMax = 1;
  private roundDelay = 0;
  private roundNo = 0;
  private countdown = 3;
  private lastCountdown = 0;

  private score = 0;
  private combo = 0;
  private maxCombo = 0;
  private hearts = 3;
  private maxHearts = 3;
  private level = 1;
  private timeMul = 1;
  private correctCount = 0;
  private wrongCount = 0;
  private missedCount = 0;
  private mastered = new Set<string>();
  private answeredLog: { word: Word; ok: boolean }[] = [];
  private startedAt = 0;

  private shake = 0;
  private flash: { color: string; amount: number } | null = null;
  private tickAcc = 0;

  constructor(
    canvas: HTMLCanvasElement,
    config: EngineConfig,
    hooks: {
      onState: (s: HudState) => void;
      onTick: (remaining: number, max: number) => void;
      onEvent: (e: EngineEvent) => void;
    },
  ) {
    this.canvas = canvas;
    this.config = config;
    this.hooks = hooks;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) throw new Error("2D canvas context unavailable");
    this.ctx = ctx;

    this.hearts = DIFFICULTY[config.difficulty].hearts;
    this.maxHearts = this.hearts;

    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(canvas);
    this.resize();

    for (let i = 0; i < 46; i++) {
      this.stars.push({
        x: rand(0, 100),
        y: rand(0, 100),
        r: rand(0.6, 2.1),
        v: rand(3, 16),
        a: rand(0.15, 0.7),
      });
    }

    this.emitState();
  }

  /* ------------------------------------------------------------------ */
  /* lifecycle                                                            */
  /* ------------------------------------------------------------------ */

  private resize() {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(1, Math.round(rect.width));
    const h = Math.max(1, Math.round(rect.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (this.W === w && this.H === h && this.dpr === dpr) return;
    this.W = w;
    this.H = h;
    this.dpr = dpr;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.buildBackground();
  }

  /** Pre-renders the aurora backdrop once per resize (keeps the frame loop cheap). */
  private buildBackground() {
    const W = this.W;
    const H = this.H;
    if (W < 2 || H < 2) return;

    const g = this.ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#0d1330");
    g.addColorStop(0.55, "#0a0e20");
    g.addColorStop(1, "#05060f");
    this.bgGradient = g;

    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(W / 2));
    c.height = Math.max(1, Math.round(H / 2));
    const bctx = c.getContext("2d");
    if (!bctx) return;
    const bw = c.width;
    const bh = c.height;
    const blob = (x: number, y: number, r: number, color: string) => {
      const rg = bctx.createRadialGradient(x, y, 0, x, y, r);
      rg.addColorStop(0, color);
      rg.addColorStop(1, "rgba(0,0,0,0)");
      bctx.fillStyle = rg;
      bctx.fillRect(0, 0, bw, bh);
    };
    blob(bw * 0.22, bh * 0.22, Math.max(bw, bh) * 0.55, "rgba(34,211,238,0.16)");
    blob(bw * 0.85, bh * 0.62, Math.max(bw, bh) * 0.5, "rgba(167,139,250,0.18)");
    this.bgCanvas = c;
  }

  start() {
    this.score = 0;
    this.combo = 0;
    this.maxCombo = 0;
    this.level = 1;
    this.timeMul = 1;
    this.correctCount = 0;
    this.wrongCount = 0;
    this.missedCount = 0;
    this.mastered.clear();
    this.answeredLog = [];
    this.tiles = [];
    this.particles = [];
    this.rings = [];
    this.popups = [];
    this.hearts = DIFFICULTY[this.config.difficulty].hearts;
    this.maxHearts = this.hearts;
    this.countdown = 3;
    this.phase = "countdown";
    this.startedAt = performance.now();
    this.lastTime = performance.now() / 1000;
    if (!this.raf) this.raf = requestAnimationFrame(this.loop);
    this.emitState();
  }

  pause() {
    if (this.phase !== "playing" && this.phase !== "countdown") return;
    this.phase = "paused";
  }

  resume() {
    if (this.phase !== "paused") return;
    this.phase = "playing";
    this.lastTime = performance.now() / 1000;
  }

  destroy() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.resizeObs?.disconnect();
    this.resizeObs = null;
  }

  /* ------------------------------------------------------------------ */
  /* input                                                                */
  /* ------------------------------------------------------------------ */

  tap(x: number, y: number) {
    if (this.phase !== "playing") return;
    for (let i = this.tiles.length - 1; i >= 0; i--) {
      const t = this.tiles[i];
      if (t.dying > 0) continue;
      if (
        x >= t.x &&
        x <= t.x + t.w &&
        y >= t.y &&
        y <= t.y + t.h
      ) {
        if (t.isTarget) this.resolveCorrect(t);
        else this.resolveWrong(t);
        return;
      }
    }
    this.splash(x, y, "rgba(148,163,184,0.9)", 6);
  }

  pressChar(raw: string) {
    if (this.phase !== "playing" || this.config.mode !== "type") return;
    const ch = raw.toLowerCase();
    if (!/^[a-z]$/.test(ch)) return;
    const target = this.target;
    if (!target) return;
    const answer = target.en.toLowerCase().replace(/[^a-z]/g, "");
    const expected = answer[this.buffer.length];
    if (!expected) return;
    if (ch !== expected) {
      this.buffer = "";
      this.combo = 0;
      this.score = Math.max(0, this.score - 3);
      this.shake = Math.max(this.shake, 7);
      this.flash = { color: "rgba(248,113,113,0.55)", amount: 0.45 };
      this.hooks.onEvent({ type: "wrong" });
      this.emitState();
      return;
    }
    this.buffer += ch;
    if (this.buffer === answer) {
      this.resolveCorrect(null);
    } else {
      this.emitState();
    }
  }

  backspace() {
    if (this.phase !== "playing") return;
    this.buffer = this.buffer.slice(0, -1);
    this.emitState();
  }

  requestHint(): boolean {
    if (this.phase !== "playing") return false;
    if (this.hintUsedThisRound) return false;
    // the hint is always available; it costs up to 20 points
    this.score = Math.max(0, this.score - 20);
    this.hintUsedThisRound = true;
    this.hintRevealed = Math.min(this.hintRevealed + 1, 2);
    if (this.config.mode === "type") {
      this.hintRevealed = Math.min(this.hintRevealed, 2);
    } else if (this.target) {
      const t = this.tiles.find((x) => x.isTarget);
      if (t) t.hint = 1;
    }
    this.hooks.onEvent({ type: "hint" });
    this.emitState();
    return true;
  }

  /* ------------------------------------------------------------------ */
  /* round flow                                                           */
  /* ------------------------------------------------------------------ */

  private pick<T>(arr: T[], exclude?: T): T {
    const pool = exclude !== undefined ? arr.filter((x) => x !== exclude) : arr;
    if (!pool.length) return arr[0];
    return pool[Math.floor(Math.random() * pool.length)];
  }

  private newRound() {
    const words = this.config.words;
    if (!words.length) return;
    const remaining = words.filter((x) => !this.mastered.has(x.id));
    if (!remaining.length) {
      this.finish(true);
      return;
    }
    const target = this.pick(remaining);
    this.target = target;
    this.buffer = "";
    this.hintRevealed = 0;
    this.hintUsedThisRound = false;
    this.roundNo++;

    const d = DIFFICULTY[this.config.difficulty];
    const count = Math.min(d.tiles, Math.max(2, words.length));
    const distractors: Word[] = [];
    const used = new Set<string>([target.id]);
    while (distractors.length < count - 1) {
      const cand = this.pick(words);
      if (used.has(cand.id)) {
        if (distractors.length >= words.length - 1) break;
        continue;
      }
      used.add(cand.id);
      distractors.push(cand);
    }
    const tiles = [target, ...distractors].sort(() => Math.random() - 0.5);

    const cfg = DIFFICULTY[this.config.difficulty];
    this.timeMax = cfg.time * this.timeMul;
    this.timeLeft = this.timeMax;

    this.tiles = [];
    for (const wd of tiles) {
      this.tiles.push(this.makeTile(wd, wd.id === target.id));
    }

    this.hooks.onEvent({ type: "round", word: target });
    this.emitState();
  }

  private makeTile(word: Word, isTarget: boolean): Tile {
    const h = clamp(this.H * 0.085, 40, 58);
    const maxW = this.W * 0.88;
    let label = word.en;
    if (this.config.mode === "meaning") label = word.fa;
    if (this.config.mode === "type") {
      label = isTarget
        ? this.maskWord(word.en)
        : word.en.replace(/(?!^)([a-zA-Z])/g, "•");
    }
    const isFa = /[\u0600-\u06FF]/.test(label);
    let fontSize = clamp(h * 0.42, 14, 27);
    let textW = this.measure(label, fontSize, isFa);
    while (textW > maxW && fontSize > 10) {
      fontSize -= 1;
      textW = this.measure(label, fontSize, isFa);
    }
    const w = Math.min(maxW, textW + 32);

    let x = rand(6, Math.max(7, this.W - w - 6));
    let y = -h - rand(0, 120);
    // avoid spawning on top of another tile
    for (let attempt = 0; attempt < 14; attempt++) {
      const overlap = this.tiles.some(
        (t) =>
          x < t.x + t.w + 10 &&
          x + w + 10 > t.x &&
          y < t.y + t.h + 14 &&
          y + h + 14 > t.y,
      );
      if (!overlap) break;
      x = rand(6, Math.max(7, this.W - w - 6));
      y = -h - rand(60, 260);
    }

    // the target reaches the bottom exactly when the round timer ends
    const travel = this.H - y;
    const fallTime = this.timeMax * (isTarget ? 1 : rand(0.78, 1.04));
    return {
      id: this.nextId++,
      text: label,
      isTarget,
      x,
      y,
      w,
      h,
      fs: fontSize,
      vy: travel / Math.max(1, fallTime),
      born: 0,
      dying: 0,
      hint: 0,
      color: this.pick(PALETTE),
    };
  }

  private maskWord(en: string) {
    const clean = en.replace(/[^a-zA-Z]/g, "");
    return clean.charAt(0) + "•".repeat(Math.max(0, clean.length - 1));
  }

  private measure(text: string, size: number, fa = false) {
    const ctx = this.ctx;
    ctx.font = `700 ${size}px ${this.fontFamily(fa)}`;
    return ctx.measureText(text).width;
  }

  private fontFamily(fa: boolean) {
    return fa
      ? '"Vazirmatn", system-ui, sans-serif'
      : '"Outfit", "Vazirmatn", system-ui, sans-serif';
  }

  private resolveCorrect(tile: Tile | null) {
    const target = this.target;
    if (!target || this.roundDelay > 0) return;
    this.correctCount++;
    this.combo++;
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    const mult = Math.min(5, 1 + Math.floor(this.combo / 3));
    const timeBonus = Math.round(this.timeLeft * 2);
    const perfect = this.timeLeft > this.timeMax * 0.55 ? 5 : 0;
    const points = (10 + timeBonus + perfect) * mult;
    this.score += points;
    this.mastered.add(target.id);
    this.answeredLog.push({ word: target, ok: true });

    const tx = tile ? tile.x + tile.w / 2 : this.W / 2;
    const ty = tile ? tile.y + tile.h / 2 : this.H * 0.4;
    this.burst(tx, ty);
    this.rings.push({
      x: tx,
      y: ty,
      r: 8,
      maxR: Math.max(90, this.W * 0.32),
      life: 0.5,
      maxLife: 0.5,
      color: "#a3e635",
    });
    this.popups.push({
      x: tx,
      y: ty - 10,
      text: `+${points}`,
      life: 0.9,
      maxLife: 0.9,
      color: mult > 1 ? "#facc15" : "#a3e635",
      size: 20 + mult * 2,
    });
    if (mult > 1) {
      this.popups.push({
        x: tx,
        y: ty - 40,
        text: `×${mult}`,
        life: 1.1,
        maxLife: 1.1,
        color: "#22d3ee",
        size: 16 + mult,
      });
    }

    const targetTile = tile ?? this.tiles.find((x) => x.isTarget);
    if (targetTile) {
      if (this.config.mode === "type") targetTile.text = target.en;
      targetTile.dying = 0.001;
    }
    this.shake = Math.max(this.shake, 3.5);
    this.flash = { color: "rgba(163,230,53,0.18)", amount: 0.25 };
    this.roundDelay = 0.62;
    this.buffer = "";

    this.hooks.onEvent({
      type: "correct",
      word: target,
      points,
      combo: this.combo,
    });

    if (this.correctCount % 4 === 0) {
      this.level++;
      this.timeMul = Math.max(0.5, this.timeMul * 0.93);
      this.hooks.onEvent({ type: "levelup", level: this.level });
    }

    // every 8 correct answers in a row restores a heart
    if (this.correctCount % 8 === 0 && this.hearts < this.maxHearts) {
      this.hearts++;
      this.hooks.onEvent({ type: "life" });
    }

    if (this.mastered.size >= this.config.words.length) {
      this.finish(true);
      return;
    }
    this.emitState();
  }

  private resolveWrong(tile: Tile) {
    this.wrongCount++;
    this.combo = 0;
    this.score = Math.max(0, this.score - 5);
    this.shake = Math.max(this.shake, 9);
    this.flash = { color: "rgba(248,113,113,0.4)", amount: 0.4 };
    tile.hint = 0;
    this.hooks.onEvent({ type: "wrong" });
    this.emitState();
  }

  private missTarget() {
    const target = this.target;
    if (!target) return;
    this.missedCount++;
    this.combo = 0;
    this.hearts = Math.max(0, this.hearts - 1);
    this.shake = Math.max(this.shake, 16);
    this.flash = { color: "rgba(248,113,113,0.6)", amount: 0.6 };
    this.answeredLog.push({ word: target, ok: false });
    const t = this.tiles.find((x) => x.isTarget);
    if (t) {
      this.splash(t.x + t.w / 2, this.H - 10, "rgba(248,113,113,0.95)", 18);
      t.dying = 0.001;
    }
    this.hooks.onEvent({ type: "miss", word: target });
    this.roundDelay = 0.75;
    if (this.hearts <= 0) {
      this.finish(false);
      return;
    }
    this.emitState();
  }

  private finish(win: boolean) {
    this.phase = "over";
    const result: GameResult = {
      score: this.score,
      correct: this.correctCount,
      wrong: this.wrongCount,
      missed: this.missedCount,
      maxCombo: this.maxCombo,
      mastered: this.mastered.size,
      total: this.config.words.length,
      win,
      seconds: Math.round((performance.now() - this.startedAt) / 1000),
      lessonId: this.config.lessonId,
      lessonTitle: this.config.lessonTitle,
      mode: this.config.mode,
      difficulty: this.config.difficulty,
      answered: this.answeredLog,
    };
    this.hooks.onEvent({ type: "gameover", result });
    this.emitState();
  }

  /* ------------------------------------------------------------------ */
  /* effects                                                              */
  /* ------------------------------------------------------------------ */

  private burst(x: number, y: number) {
    const count = 34;
    for (let i = 0; i < count; i++) {
      const a = rand(0, Math.PI * 2);
      const sp = rand(90, 420);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - rand(40, 220),
        life: rand(0.45, 0.95),
        maxLife: 0.95,
        size: rand(2.5, 7),
        color: PALETTE[Math.floor(Math.random() * PALETTE.length)],
        rot: rand(0, Math.PI),
        spin: rand(-9, 9),
        square: Math.random() > 0.45,
      });
    }
    if (this.particles.length > 420) this.particles.splice(0, this.particles.length - 420);
  }

  private splash(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const sp = rand(40, 220);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(0.2, 0.5),
        maxLife: 0.5,
        size: rand(2, 5),
        color,
        rot: 0,
        spin: 0,
        square: false,
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /* update                                                               */
  /* ------------------------------------------------------------------ */

  private loop = (t: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const now = t / 1000;
    let dt = now - this.lastTime;
    this.lastTime = now;
    if (dt < 0) dt = 0;
    dt = Math.min(dt, 0.05);

    if (this.phase === "countdown") {
      this.countdown -= dt;
      const n = Math.max(1, Math.ceil(this.countdown));
      if (n !== this.lastCountdown) {
        this.lastCountdown = n;
        this.hooks.onEvent({ type: "countdown", n });
      }
      if (this.countdown <= 0) {
        this.phase = "playing";
        this.newRound();
      }
    } else if (this.phase === "playing") {
      this.update(dt);
    }

    this.draw(dt);
  };

  private update(dt: number) {
    // countdown of the round
    if (this.roundDelay > 0) {
      this.roundDelay -= dt;
      if (this.roundDelay <= 0) {
        this.roundDelay = 0;
        this.newRound();
      }
    } else {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.missTarget();
      }
    }

    this.tickAcc += dt;
    if (this.tickAcc >= 0.1) {
      this.tickAcc = 0;
      this.hooks.onTick(this.timeLeft, this.timeMax);
    }

    for (const t of this.tiles) {
      t.born += dt;
      if (t.hint > 0) t.hint = Math.max(0, t.hint - dt * 0.5);
      if (t.dying > 0) {
        t.dying += dt;
        t.y += t.vy * dt * 0.4;
        continue;
      }
      t.y += t.vy * dt;
      if (t.isTarget && t.y > this.H + 20) {
        t.dying = 0.001;
        this.missTarget();
      }
    }
    this.tiles = this.tiles.filter((t) => t.dying <= 0 || t.dying < 0.45);

    // particles
    for (const p of this.particles) {
      p.life -= dt;
      p.vy += 1500 * dt;
      p.vx *= 0.985;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.spin * dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);

    for (const r of this.rings) {
      r.life -= dt;
      const p = 1 - r.life / r.maxLife;
      r.r = 8 + (r.maxR - 8) * (1 - Math.pow(1 - p, 3));
    }
    this.rings = this.rings.filter((r) => r.life > 0);

    for (const p of this.popups) {
      p.life -= dt;
      p.y -= 42 * dt;
    }
    this.popups = this.popups.filter((p) => p.life > 0);

    this.shake *= Math.pow(0.0016, dt);
    if (this.shake < 0.2) this.shake = 0;
    if (this.flash) {
      this.flash.amount -= dt * 2.2;
      if (this.flash.amount <= 0) this.flash = null;
    }
  }

  /* ------------------------------------------------------------------ */
  /* draw                                                                 */
  /* ------------------------------------------------------------------ */

  private draw(dt: number) {
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;

    ctx.save();
    if (this.shake > 0) {
      ctx.translate(rand(-this.shake, this.shake), rand(-this.shake, this.shake));
    }

    this.drawBackground(dt);

    // danger line
    const dangerY = H - 6;
    const grad = ctx.createLinearGradient(0, dangerY - 26, 0, dangerY);
    grad.addColorStop(0, "rgba(248,113,113,0)");
    grad.addColorStop(1, "rgba(248,113,113,0.35)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, dangerY - 26, W, 26);
    ctx.strokeStyle = "rgba(248,113,113,0.55)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, dangerY);
    ctx.lineTo(W, dangerY);
    ctx.stroke();

    for (const t of this.tiles) this.drawTile(t);

    for (const r of this.rings) {
      const a = Math.max(0, r.life / r.maxLife);
      ctx.strokeStyle = r.color;
      ctx.globalAlpha = a * 0.85;
      ctx.lineWidth = 3 + a * 5;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    for (const p of this.particles) {
      const a = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      if (p.square) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * a, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;

    for (const p of this.popups) {
      const a = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      ctx.font = `800 ${p.size}px "Outfit", system-ui, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.direction = "ltr";
      ctx.shadowColor = "rgba(0,0,0,0.6)";
      ctx.shadowBlur = 6;
      ctx.fillText(p.text, p.x, p.y);
      ctx.shadowBlur = 0;
    }
    ctx.globalAlpha = 1;

    if (this.flash) {
      ctx.fillStyle = this.flash.color;
      ctx.globalAlpha = Math.max(0, this.flash.amount);
      ctx.fillRect(-40, -40, W + 80, H + 80);
      ctx.globalAlpha = 1;
    }

    if (this.phase === "countdown") {
      this.drawCountdown();
    }

    ctx.restore();
  }

  private drawBackground(dt: number) {
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;

    ctx.fillStyle = this.bgGradient ?? "#0a0e20";
    ctx.fillRect(0, 0, W, H);

    // pre-rendered aurora, gently drifting
    if (this.bgCanvas) {
      const t = performance.now() / 1000;
      const ox = Math.cos(t * 0.25) * W * 0.035;
      const oy = Math.sin(t * 0.2) * H * 0.03;
      ctx.drawImage(this.bgCanvas, ox, oy, W, H);
    }

    // stars
    for (const s of this.stars) {
      s.y += (s.v * dt) / Math.max(1, H / 100);
      if (s.y > 102) {
        s.y = -2;
        s.x = Math.random() * 100;
      }
      ctx.globalAlpha = s.a;
      ctx.fillStyle = "#cfe3ff";
      ctx.beginPath();
      ctx.arc((s.x / 100) * W, (s.y / 100) * H, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // moving grid lines
    ctx.strokeStyle = "rgba(148,163,184,0.07)";
    ctx.lineWidth = 1;
    const spacing = 64;
    const off = (performance.now() / 26) % spacing;
    ctx.beginPath();
    for (let y = off - spacing; y < H + spacing; y += spacing) {
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
    }
    ctx.stroke();
  }

  private drawTile(t: Tile) {
    const ctx = this.ctx;
    const spawn = clamp(t.born / 0.26, 0, 1);
    const scale = easeOutBack(spawn);
    let alpha = 1;
    if (t.dying > 0) {
      const p = clamp(t.dying / 0.42, 0, 1);
      alpha = 1 - p;
    }
    if (alpha <= 0) return;

    const cx = t.x + t.w / 2;
    const cy = t.y + t.h / 2;

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.translate(-cx, -cy);

    const isFa = /[\u0600-\u06FF]/.test(t.text);
    const fontSize = t.fs;

    const glow = t.hint > 0 ? 0.55 + 0.45 * Math.sin(performance.now() / 90) : 0;
    const color = t.hint > 0 ? "#facc15" : t.color;

    ctx.shadowColor = color;
    ctx.shadowBlur = 14 + glow * 26;
    roundRect(ctx, t.x, t.y, t.w, t.h, 14);
    const grad = ctx.createLinearGradient(t.x, t.y, t.x, t.y + t.h);
    grad.addColorStop(0, "rgba(255,255,255,0.14)");
    grad.addColorStop(1, "rgba(255,255,255,0.04)");
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.lineWidth = t.hint > 0 ? 3 : 2;
    ctx.strokeStyle = color;
    ctx.globalAlpha = alpha * (0.75 + glow * 0.25);
    ctx.stroke();
    ctx.globalAlpha = alpha;
    ctx.shadowBlur = 0;

    ctx.fillStyle = "#f8fbff";
    ctx.font = `700 ${fontSize}px ${this.fontFamily(isFa)}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.direction = isFa ? "rtl" : "ltr";
    ctx.fillText(t.text, cx, cy + 1);

    ctx.restore();
  }

  private drawCountdown() {
    const ctx = this.ctx;
    const n = Math.ceil(this.countdown);
    if (n <= 0) return;
    const frac = 1 - (this.countdown - Math.floor(this.countdown));
    const scale = 1 + (1 - frac) * 0.5;
    ctx.save();
    ctx.translate(this.W / 2, this.H / 2);
    ctx.scale(scale, scale);
    ctx.globalAlpha = Math.max(0, Math.min(1, frac * 2.2));
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.direction = "ltr";
    ctx.font = `900 ${Math.min(this.W, this.H) * 0.3}px "Outfit", system-ui, sans-serif`;
    ctx.shadowColor = "rgba(34,211,238,0.8)";
    ctx.shadowBlur = 40;
    ctx.fillStyle = "#ffffff";
    ctx.fillText(String(n), 0, 0);
    ctx.restore();
  }

  /* ------------------------------------------------------------------ */
  /* state                                                                */
  /* ------------------------------------------------------------------ */

  private buildHud(): HudState {
    const target = this.target;
    let hintPattern = "";
    if (target && this.config.mode === "type") {
      const answer = target.en.replace(/[^a-zA-Z]/g, "");
      hintPattern = answer
        .split("")
        .map((ch, i) => (i < this.hintRevealed ? ch : "•"))
        .join("");
    }
    return {
      score: this.score,
      combo: this.combo,
      maxCombo: this.maxCombo,
      multiplier: Math.min(5, 1 + Math.floor(this.combo / 3)),
      hearts: this.hearts,
      maxHearts: DIFFICULTY[this.config.difficulty].hearts,
      level: this.level,
      prompt: target
        ? this.config.mode === "meaning"
          ? target.en
          : target.fa
        : "",
      promptIsEnglish: this.config.mode === "meaning",
      answer: target?.en ?? "",
      buffer: this.buffer,
      hintPattern,
      mastered: this.mastered.size,
      total: this.config.words.length,
      round: this.roundNo,
      correctCount: this.correctCount,
      wrongCount: this.wrongCount,
      missedCount: this.missedCount,
    };
  }

  private emitState() {
    this.hooks.onState(this.buildHud());
  }

  getState(): HudState {
    return this.buildHud();
  }
}
