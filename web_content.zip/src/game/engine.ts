import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { applyOutfit, disposeTree, makeCar, makeLampGeo, makeRig, makeTreeGeo, toonGradient } from "@/game/actors";
import { buildCity, districtAt, WORLD, type Bld, type City } from "@/game/city";
import {
  CAR_SPEC,
  CARS,
  DISPATCH,
  MISSIONS,
  OUTFITS,
  PASS,
  PROPS,
  RADIO,
  TIPS,
  WEAPONS,
} from "@/game/content";
import { createAudio, type AudioBus } from "@/game/audio";
import type { CarKind, HudState, ModeId, Note, Step, WeaponId } from "@/game/types";

const SAVE_KEY = "darkfire-save-v1";
const BEATS = [
  [220, 277, 330, 220, 370, 330, 277, 247],
  [98, 98, 123, 98, 82, 98, 110, 82],
  [196, 247, 196, 294, 247, 220, 196, 185],
  [262, 330, 392, 330, 294, 330, 349, 294],
  [140, 180, 140, 120, 160, 140, 100, 140],
];

type VehRole = "traffic" | "parked" | "player" | "cop" | "off";
type Veh = {
  alive: boolean;
  x: number;
  z: number;
  yaw: number;
  speed: number;
  kind: CarKind;
  role: VehRole;
  hp: number;
  color: string;
  na: number;
  nb: number;
  t: number;
  shoot: number;
  spin: number;
};
type Ped = {
  alive: boolean;
  x: number;
  z: number;
  yaw: number;
  kind: "civ" | "gang";
  state: "walk" | "flee" | "attack" | "dead";
  hp: number;
  speed: number;
  walk: number;
  shoot: number;
  dead: number;
};
type Run = {
  id: string;
  name: string;
  reward: number;
  xp: number;
  weapon?: WeaponId;
  steps: Step[];
  step: number;
  hold: number;
  time: number;
  cp: number;
  lap: number;
  kills: number;
  raceT: number;
};
type Save = {
  version: 1;
  name: string;
  money: number;
  gems: number;
  outfit: string;
  ownedWeapons: WeaponId[];
  ownedCars: string[];
  ownedProps: string[];
  mags: Partial<Record<WeaponId, number>>;
  reserve: Partial<Record<WeaponId, number>>;
  grenades: number;
  missionsDone: string[];
  xp: number;
  passClaimed: number;
  volume: number;
  muted: boolean;
  carColor: string;
  bestRace: number | null;
  vaultAt: number;
  armor: number;
  ownedFits: string[];
};

export type GameAPI = {
  destroy: () => void;
  skipLoad: () => void;
  startMode: (mode: ModeId) => void;
  startMission: (id: string) => void;
  setOutfit: (id: string) => void;
  buyWeapon: (id: WeaponId) => void;
  equipWeapon: (id: WeaponId) => void;
  buyCar: (id: string) => void;
  deliverCar: (id: string) => void;
  paintCar: (color: string) => void;
  buyProperty: (id: string) => void;
  buyKit: (kind: "armor" | "health") => void;
  buyGrenades: () => void;
  claimVault: () => void;
  claimPass: () => void;
  openCrate: () => void;
  setName: (name: string) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  setPaused: (v: boolean) => void;
  setPhone: (v: boolean) => void;
  goLobby: () => void;
  respawn: () => void;
  setAnalog: (x: number, y: number) => void;
  setHeld: (btn: "shoot" | "brake", down: boolean) => void;
  tap: (btn: "action" | "weapon" | "grenade" | "crouch" | "radio") => void;
  blip: () => void;
};

const VEH = 12;
const CIV = 16;
const GANG = 6;
const WATCH = ["Escape", "KeyP", "KeyM", "KeyF", "KeyE", "KeyR", "KeyZ", "KeyC", "KeyG", "KeyN", "Digit1", "Digit2", "Digit3", "Digit4", "Digit5"];

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}
function wrap(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}
function paintGeo(geo: THREE.BufferGeometry, color: THREE.Color) {
  const n = geo.getAttribute("position").count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = color.r;
    arr[i * 3 + 1] = color.g;
    arr[i * 3 + 2] = color.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
  return geo;
}
function clockString(min: number) {
  const m = ((Math.floor(min) % 1440) + 1440) % 1440;
  let h = Math.floor(m / 60);
  const mm = m % 60;
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${mm.toString().padStart(2, "0")} ${ap}`;
}

export function mountGame(opts: {
  canvas: HTMLCanvasElement;
  mini: HTMLCanvasElement;
  poster: HTMLCanvasElement;
  phoneMap: HTMLCanvasElement;
  onHud: (h: HudState) => void;
}): GameAPI {
  const game = new CityGame(opts);
  return game.api();
}

class CityGame {
  private opts: {
    canvas: HTMLCanvasElement;
    mini: HTMLCanvasElement;
    poster: HTMLCanvasElement;
    phoneMap: HTMLCanvasElement;
    onHud: (h: HudState) => void;
  };
  private city: City;
  private audio: AudioBus;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private cam = new THREE.PerspectiveCamera(58, 1, 0.15, 900);
  private hemi: THREE.HemisphereLight;
  private sun: THREE.DirectionalLight;
  private spotA: THREE.SpotLight;
  private spotB: THREE.SpotLight;
  private windows: THREE.InstancedMesh;
  private bulbs: THREE.InstancedMesh;
  private clouds: THREE.InstancedMesh;
  private rig: ReturnType<typeof makeRig>;
  private shadow: THREE.Mesh;
  private cars: THREE.Group[] = [];
  private vehicles: Veh[] = [];
  private civs: Ped[] = [];
  private gangs: Ped[] = [];
  private pedBody: THREE.InstancedMesh;
  private pedHead: THREE.InstancedMesh;
  private marker: THREE.Mesh;
  private heli: THREE.Group;
  private rotor: THREE.Object3D;
  private blast: THREE.Mesh;
  private flash: THREE.PointLight;
  private dummy = new THREE.Object3D();
  private desired = new THREE.Vector3();
  private lookV = new THREE.Vector3();
  private buckets = new Map<string, Bld[]>();
  private keys = new Set<string>();
  private injected = new Set<string>();
  private prev = new Set<string>();
  private edge = new Set<string>();
  private reduce: boolean;
  private raf = 0;
  private last = 0;
  private acc = 0;
  private bootAt = 0;
  private minLoad = 3200;
  private phase: "load" | "lobby" | "play" = "load";
  private load = 0.04;
  private tip = TIPS[0]!;
  private snap = true;
  private night = true;
  private minutes = 21 * 60;
  private name = "DARKFIRE";
  private money = 23820;
  private gems = 86;
  private outfit = "darkfire";
  private ownedWeapons: WeaponId[] = ["fists", "pistol", "jade"];
  private ownedCars = ["veto", "issi"];
  private ownedProps: string[] = [];
  private mags: Partial<Record<WeaponId, number>> = { pistol: 12, jade: 30 };
  private reserve: Partial<Record<WeaponId, number>> = { pistol: 48, jade: 90 };
  private grenades = 2;
  private weapon: WeaponId = "jade";
  private cool = 0;
  private trigger = false;
  private missionsDone: string[] = [];
  private xp = 0;
  private passClaimed = 0;
  private carColor = "#161616";
  private bestRace: number | null = null;
  private vaultAt = 0;
  private driveIndex: number | null = null;
  private player = { x: 0, z: 276, yaw: 0, speed: 0, health: 100, armor: 25 };
  private camYaw = 0;
  private look = 0;
  private lobbyYaw = 0.45;
  private stars = 0;
  private hidden = 0;
  private shake = 0;
  private pain = 0;
  private paused = false;
  private phone = false;
  private down: "" | "wasted" | "busted" = "";
  private downT = 0;
  private bustT = 0;
  private crouch = false;
  private aggro = false;
  private hear = 0;
  private mode: ModeId = "freeroam";
  private run: Run | null = null;
  private station = 0;
  private radioOn = true;
  private radioT = 0;
  private radioStep = 0;
  private eventT = 8;
  private gangCool = 12;
  private heliOn = false;
  private heliHp = 80;
  private heliX = 40;
  private heliZ = -40;
  private heliYaw = 0;
  private heliCool = 0;
  private heliShot = 0;
  private fx = 0;
  private fz = 90;
  private fyaw = 0;
  private fspeed = 0;
  private analogX = 0;
  private analogY = 0;
  private touchShoot = false;
  private touchBrake = false;
  private pointerDown = false;
  private drag = 0;
  private steerOverride: number | null = null;
  private feed: { id: number; text: string; until: number }[] = [];
  private nid = 1;
  private lastEmit = 0;
  private interact = "";
  private hint = "WASD drive  ·  A turns left  ·  F exits  ·  click shoots";
  private hintT = 9;
  private nades: { x: number; y: number; z: number; vx: number; vy: number; vz: number; t: number; alive: boolean }[] = [];
  private picks: { x: number; z: number; kind: "cash" | "armor" | "health"; wait: number; mesh: THREE.Mesh }[] = [];
  private ro: ResizeObserver;
  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onBlur: () => void;
  private onPointerDown: (e: PointerEvent) => void;
  private onPointerMove: (e: PointerEvent) => void;
  private onPointerUp: () => void;
  private onWheel: (e: WheelEvent) => void;

  constructor(opts: CityGame["opts"]) {
    this.opts = opts;
    this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.city = buildCity();
    this.audio = createAudio();
    this.loadSave();
    this.renderer = new THREE.WebGLRenderer({ canvas: opts.canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.setClearColor(0x070b18);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.scene.fog = new THREE.Fog(0x070b18, 80, 420);
    this.hemi = new THREE.HemisphereLight(0x223055, 0x1a120c, 0.85);
    this.sun = new THREE.DirectionalLight(0x8aa4ff, 0.65);
    this.sun.position.set(-40, 80, 20);
    this.scene.add(this.hemi, this.sun);
    const grad = toonGradient();
    this.buildStatic(grad);
    this.rig = makeRig();
    applyOutfit(this.rig, OUTFITS.find((o) => o.id === this.outfit) ?? OUTFITS[0]!);
    this.rig.root.position.set(0, 0, 276);
    this.scene.add(this.rig.root);
    this.shadow = new THREE.Mesh(new THREE.CircleGeometry(0.7, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28 }));
    this.shadow.rotation.x = -Math.PI / 2;
    this.shadow.position.y = 0.06;
    this.scene.add(this.shadow);
    this.spotA = new THREE.SpotLight(0x6a7bff, 900, 48, 0.55, 0.45, 1);
    this.spotB = new THREE.SpotLight(0xc084fc, 700, 42, 0.6, 0.5, 1);
    this.spotA.position.set(-8, 16, 292);
    this.spotB.position.set(10, 13, 268);
    this.spotA.target = this.rig.root;
    this.spotB.target = this.rig.root;
    this.scene.add(this.spotA, this.spotB);
    this.windows = this.buildWindows();
    this.bulbs = this.buildBulbs();
    this.clouds = this.buildClouds();
    this.scene.add(this.windows, this.bulbs, this.clouds);
    this.spawnActors();
    const bodyGeo = new THREE.BoxGeometry(0.46, 0.72, 0.26);
    const headGeo = new THREE.SphereGeometry(0.16, 8, 6);
    this.pedBody = new THREE.InstancedMesh(bodyGeo, new THREE.MeshStandardMaterial({ roughness: 0.7, metalness: 0.05, vertexColors: false }), CIV + GANG);
    this.pedHead = new THREE.InstancedMesh(headGeo, new THREE.MeshStandardMaterial({ color: "#c48a62", roughness: 0.7 }), CIV + GANG);
    this.scene.add(this.pedBody, this.pedHead);
    this.marker = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.55, 16, 8, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xf5b301, transparent: true, opacity: 0.38, side: THREE.DoubleSide }),
    );
    this.scene.add(this.marker);
    this.heli = new THREE.Group();
    const hmat = new THREE.MeshStandardMaterial({ color: "#2c3340", metalness: 0.45, roughness: 0.4 });
    const hbody = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.05, 5.4), hmat);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.32, 2.8), hmat);
    tail.position.z = -3.6;
    this.rotor = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.08, 0.26), new THREE.MeshStandardMaterial({ color: "#111" }));
    this.rotor.position.y = 0.7;
    this.heli.add(hbody, tail, this.rotor);
    this.heli.visible = false;
    this.scene.add(this.heli);
    this.blast = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffb15a, transparent: true, opacity: 0.8 }));
    this.blast.visible = false;
    this.scene.add(this.blast);
    this.flash = new THREE.PointLight(0xffe1a8, 0, 10, 2);
    this.scene.add(this.flash);
    this.spawnPickups();
    this.indexBuildings();
    this.drawPoster();
    this.bootAt = performance.now();
    this.last = this.bootAt;
    this.applyLook();
    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(opts.canvas);
    this.onKeyDown = (e) => {
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
    };
    this.onKeyUp = (e) => this.keys.delete(e.code);
    this.onBlur = () => {
      this.keys.clear();
      this.pointerDown = false;
      this.touchShoot = false;
      this.touchBrake = false;
      this.analogX = 0;
      this.analogY = 0;
    };
    this.onPointerDown = (e) => {
      if (this.phase !== "play") {
        if (this.phase === "lobby") {
          this.pointerDown = true;
          this.drag = 0;
          this.lastPx = e.clientX;
        }
        return;
      }
      this.pointerDown = true;
      this.drag = 0;
      this.lastPx = e.clientX;
    };
    this.onPointerMove = (e) => {
      if (!this.pointerDown) return;
      const dx = e.clientX - this.lastPx;
      this.lastPx = e.clientX;
      this.drag += Math.abs(dx);
      if (this.phase === "lobby") this.lobbyYaw -= dx * 0.01;
      else if (this.phase === "play" && !this.paused && !this.phone) {
        if (this.driveIndex !== null) this.look -= dx * 0.004;
        else this.camYaw -= dx * 0.005;
      }
    };
    this.onPointerUp = () => {
      this.pointerDown = false;
    };
    this.onWheel = (e) => {
      if (this.phase !== "play" || this.paused || this.phone) return;
      this.cycleWeapon(e.deltaY > 0 ? 1 : -1);
    };
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
    opts.canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("wheel", this.onWheel, { passive: true });
    opts.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    window.__controlsTest = {
      getYaw: () => this.fyaw,
      getSpeed: () => (this.phase === "play" && this.driveIndex !== null ? this.vehicles[this.driveIndex]!.speed : 0),
      setKeys: (codes) => {
        this.injected = new Set(codes);
      },
      setSteer: (v) => {
        this.steerOverride = v;
      },
    };
    this.raf = requestAnimationFrame(this.frame);
    this.emit(true);
  }

  private lastPx = 0;

  private api(): GameAPI {
    return {
      destroy: () => this.destroy(),
      skipLoad: () => this.enterLobby(),
      startMode: (mode) => this.startMode(mode),
      startMission: (id) => this.startMission(id),
      setOutfit: (id) => this.setOutfit(id),
      buyWeapon: (id) => this.buyWeapon(id),
      equipWeapon: (id) => this.equipWeapon(id),
      buyCar: (id) => this.buyCar(id),
      deliverCar: (id) => this.deliverCar(id),
      paintCar: (color) => this.paintCar(color),
      buyProperty: (id) => this.buyProperty(id),
      buyKit: (kind) => this.buyKit(kind),
      buyGrenades: () => this.buyGrenades(),
      claimVault: () => this.claimVault(),
      claimPass: () => this.claimPass(),
      openCrate: () => this.openCrate(),
      setName: (name) => this.setName(name),
      setVolume: (v) => {
        this.audio.setVolume(v);
        this.save();
        this.emit(true);
      },
      toggleMute: () => {
        this.audio.setMuted(!this.audio.muted);
        this.save();
        this.emit(true);
      },
      setPaused: (v) => {
        this.paused = v;
        this.emit(true);
      },
      setPhone: (v) => {
        this.phone = v;
        this.emit(true);
      },
      goLobby: () => this.goLobby(),
      respawn: () => this.respawn(),
      setAnalog: (x, y) => {
        this.analogX = x;
        this.analogY = y;
      },
      setHeld: (btn, down) => {
        if (btn === "shoot") this.touchShoot = down;
        else this.touchBrake = down;
      },
      tap: (btn) => this.tap(btn),
      blip: () => this.audio.blip(),
    };
  }

  private loadSave() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const s = JSON.parse(raw) as Save;
      if (s.version !== 1) return;
      this.name = s.name?.slice(0, 12) || this.name;
      this.money = s.money ?? this.money;
      this.gems = s.gems ?? this.gems;
      this.outfit = s.outfit || this.outfit;
      this.ownedWeapons = s.ownedWeapons?.length ? s.ownedWeapons : this.ownedWeapons;
      this.ownedCars = s.ownedCars?.length ? s.ownedCars : this.ownedCars;
      this.ownedProps = s.ownedProps ?? [];
      this.mags = s.mags ?? this.mags;
      this.reserve = s.reserve ?? this.reserve;
      this.grenades = s.grenades ?? this.grenades;
      this.missionsDone = s.missionsDone ?? [];
      this.xp = s.xp ?? 0;
      this.passClaimed = s.passClaimed ?? 0;
      this.carColor = s.carColor || this.carColor;
      this.bestRace = s.bestRace ?? null;
      this.vaultAt = s.vaultAt ?? 0;
      this.player.armor = s.armor ?? 25;
      for (const id of s.ownedFits ?? []) this.ownedFits.add(id);
      this.audio.setVolume(s.volume ?? 0.45);
      this.audio.setMuted(!!s.muted);
    } catch {
      /* fresh */
    }
  }

  private save() {
    const data: Save = {
      version: 1,
      name: this.name,
      money: Math.floor(this.money),
      gems: Math.floor(this.gems),
      outfit: this.outfit,
      ownedWeapons: this.ownedWeapons,
      ownedCars: this.ownedCars,
      ownedProps: this.ownedProps,
      mags: this.mags,
      reserve: this.reserve,
      grenades: this.grenades,
      missionsDone: this.missionsDone,
      xp: this.xp,
      passClaimed: this.passClaimed,
      volume: this.audio.volume,
      muted: this.audio.muted,
      carColor: this.carColor,
      bestRace: this.bestRace,
      vaultAt: this.vaultAt,
      armor: Math.floor(this.player.armor),
      ownedFits: [...this.ownedFits],
    };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch {
      /* ignore */
    }
  }

  private buildStatic(grad: THREE.Texture) {
    const tex = new THREE.CanvasTexture(this.city.map);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(WORLD * 2, WORLD * 2), new THREE.MeshBasicMaterial({ map: tex }));
    ground.rotation.x = -Math.PI / 2;
    this.scene.add(ground);
    const geos: THREE.BufferGeometry[] = [];
    for (const b of this.city.buildings) {
      const box = new THREE.BoxGeometry(b.w, b.h, b.d);
      box.translate(b.x, b.h / 2, b.z);
      paintGeo(box, new THREE.Color(b.wall));
      const rh = Math.min(5.5, Math.max(2.2, b.h * 0.38));
      const roof = new THREE.ConeGeometry(Math.max(b.w, b.d) * 0.62, rh, 4);
      roof.rotateY(Math.PI / 4);
      roof.translate(b.x, b.h + rh / 2, b.z);
      paintGeo(roof, new THREE.Color(b.roof));
      geos.push(box, roof);
      if (b.name) {
        const sprite = makeLabel(b.name);
        sprite.position.set(b.x, b.h + rh + 1.6, b.z);
        this.scene.add(sprite);
      }
    }
    const merged = geos.length ? mergeGeometries(geos, false) : null;
    geos.forEach((g) => g.dispose());
    if (merged) {
      this.scene.add(new THREE.Mesh(merged, new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: grad })));
    }
    if (this.city.trees.length) {
      const parts = makeTreeGeo();
      const tree = mergeGeometries(parts, false);
      parts.forEach((g) => g.dispose());
      if (tree) {
        const mesh = new THREE.InstancedMesh(tree, new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: grad }), this.city.trees.length);
        this.city.trees.forEach((t, i) => {
          this.dummy.position.set(t.x, 0, t.z);
          this.dummy.rotation.set(0, t.shade * 6, 0);
          this.dummy.scale.setScalar(0.75 + t.s);
          this.dummy.updateMatrix();
          mesh.setMatrixAt(i, this.dummy.matrix);
        });
        this.scene.add(mesh);
      }
    }
    if (this.city.lamps.length) {
      const parts = makeLampGeo();
      const lamp = mergeGeometries(parts, false);
      parts.forEach((g) => g.dispose());
      if (lamp) {
        paintGeo(lamp, new THREE.Color("#2c3038"));
        const mesh = new THREE.InstancedMesh(lamp, new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: grad }), this.city.lamps.length);
        this.city.lamps.forEach((p, i) => {
          this.dummy.position.set(p.x, 0, p.z);
          this.dummy.rotation.set(0, 0, 0);
          this.dummy.scale.set(1, 1, 1);
          this.dummy.updateMatrix();
          mesh.setMatrixAt(i, this.dummy.matrix);
        });
        this.scene.add(mesh);
      }
    }
    const pier = new THREE.Mesh(new THREE.BoxGeometry(8, 0.4, 92), new THREE.MeshStandardMaterial({ color: "#a97850", roughness: 0.86 }));
    pier.position.set(0, 0.16, 286);
    this.scene.add(pier);
    const disc = new THREE.Mesh(
      new THREE.CylinderGeometry(7.2, 7.6, 0.2, 28),
      new THREE.MeshStandardMaterial({ color: "#141824", metalness: 0.35, roughness: 0.5, emissive: "#2a1048", emissiveIntensity: 0.55 }),
    );
    disc.position.set(0, 0.1, 276);
    this.scene.add(disc);
    const umb = new THREE.InstancedMesh(new THREE.ConeGeometry(1.3, 0.55, 6), new THREE.MeshToonMaterial({ color: "#ff5d73", gradientMap: grad }), 8);
    for (let i = 0; i < 8; i++) {
      this.dummy.position.set(-46 + i * 14, 1.6, 252);
      this.dummy.rotation.set(0, i, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      umb.setMatrixAt(i, this.dummy.matrix);
    }
    this.scene.add(umb);
  }

  private buildWindows() {
    const count = Math.min(120, this.city.buildings.length);
    const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.7, 0.85, 0.12), new THREE.MeshBasicMaterial({ color: "#ffd27a" }), count);
    for (let i = 0; i < count; i++) {
      const b = this.city.buildings[i % this.city.buildings.length]!;
      const face = i % 2 === 0 ? 1 : -1;
      this.dummy.position.set(b.x + face * (b.w / 2 + 0.05), b.h * 0.55, b.z + ((i % 5) - 2) * 0.4);
      this.dummy.rotation.set(0, face > 0 ? Math.PI / 2 : -Math.PI / 2, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      mesh.setMatrixAt(i, this.dummy.matrix);
    }
    return mesh;
  }

  private buildBulbs() {
    const n = this.city.lamps.length || 1;
    const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.45, 0.12, 0.22), new THREE.MeshBasicMaterial({ color: "#ffe1a8" }), n);
    this.city.lamps.forEach((p, i) => {
      this.dummy.position.set(p.x, 3.25, p.z);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      mesh.setMatrixAt(i, this.dummy.matrix);
    });
    return mesh;
  }

  private buildClouds() {
    const mesh = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 1 }), 18);
    for (let i = 0; i < 18; i++) {
      const cluster = Math.floor(i / 3);
      this.dummy.position.set(-220 + cluster * 70 + (i % 3) * 8, 70 + (i % 3) * 3, -180 + (cluster % 3) * 90);
      this.dummy.scale.set(7 + (i % 3) * 3, 3.2, 5);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.updateMatrix();
      mesh.setMatrixAt(i, this.dummy.matrix);
    }
    mesh.visible = false;
    return mesh;
  }

  private spawnActors() {
    const palette = ["#f4f4f4", "#de3c45", "#355070", "#f5c400", "#2a9d8f", "#ffb703", "#6d597a", "#d9d3c7"];
    const kinds: CarKind[] = ["sedan", "taxi", "suv", "van", "sport", "sedan"];
    for (let i = 0; i < VEH; i++) {
      let kind: CarKind = "sedan";
      let role: VehRole = "traffic";
      let color = palette[i % palette.length]!;
      if (i === 0) {
        kind = "sport";
        role = "parked";
        color = this.carColor;
      } else if (i >= 9) {
        kind = "cop";
        role = "cop";
        color = "#e9eef5";
      } else if (i >= 7) role = "parked";
      else kind = kinds[i % kinds.length]!;
      const v: Veh = { alive: i < 9, x: 0, z: 90, yaw: 0, speed: 0, kind, role, hp: 140, color, na: 0, nb: 0, t: 0, shoot: 1, spin: 0 };
      if (i === 0) {
        v.x = 0;
        v.z = 90;
        v.yaw = 0;
      } else if (i < 9) this.scatterVehicle(v, i >= 7);
      else v.alive = false;
      this.vehicles.push(v);
      const mesh = makeCar(kind, color);
      mesh.visible = v.alive;
      this.scene.add(mesh);
      this.cars.push(mesh);
    }
    for (let i = 0; i < CIV; i++) {
      const p = this.makePed("civ");
      this.placePed(p, i);
      this.civs.push(p);
    }
    for (let i = 0; i < GANG; i++) {
      const p = this.makePed("gang");
      const pin = this.city.pins.foundry!;
      p.x = pin.x + (i - 2.5) * 3.2;
      p.z = pin.z + (i % 2 === 0 ? 3 : -3);
      p.state = "walk";
      this.gangs.push(p);
    }
  }

  private makePed(kind: Ped["kind"]): Ped {
    return { alive: true, x: 0, z: 0, yaw: 0, kind, state: "walk", hp: kind === "gang" ? 70 : 40, speed: 1.4, walk: Math.random() * 10, shoot: 1, dead: 0 };
  }

  private placePed(p: Ped, salt: number) {
    const nodes = this.city.nodes;
    for (let k = 0; k < 20; k++) {
      const i = (salt * 7 + k * 5) % nodes.length;
      const n = nodes[i];
      const nxt = this.city.adj[i]?.[0];
      if (!n || nxt === undefined) continue;
      const m = nodes[nxt]!;
      const dx = m.x - n.x;
      const dz = m.z - n.z;
      const len = Math.hypot(dx, dz) || 1;
      const side = salt % 2 === 0 ? 1 : -1;
      p.x = n.x + (-dz / len) * 8 * side;
      p.z = n.z + (dx / len) * 8 * side;
      p.yaw = Math.atan2(-dx, -dz);
      if (!this.blocked(p.x, p.z, 0.4)) return;
    }
    p.x = 20 + salt;
    p.z = 20;
  }

  private scatterVehicle(v: Veh, parked: boolean) {
    const nodes = this.city.nodes;
    for (let k = 0; k < 24; k++) {
      const i = Math.floor(Math.random() * nodes.length);
      const nxts = this.city.adj[i];
      if (!nxts?.length) continue;
      const j = nxts[Math.floor(Math.random() * nxts.length)]!;
      const a = nodes[i]!;
      const b = nodes[j]!;
      if (Math.abs(a.x) < 14 && a.z > 50 && a.z < 140) continue;
      v.na = i;
      v.nb = j;
      v.t = Math.random();
      v.x = a.x + (b.x - a.x) * v.t;
      v.z = a.z + (b.z - a.z) * v.t;
      v.yaw = Math.atan2(-(b.x - a.x), -(b.z - a.z));
      v.speed = parked ? 0 : 8 + Math.random() * 6;
      if (parked) {
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const len = Math.hypot(dx, dz) || 1;
        v.x += (-dz / len) * 7;
        v.z += (dx / len) * 7;
        v.speed = 0;
        const c = this.collide(v.x, v.z, 1.4);
        v.x = c.x;
        v.z = c.z;
      }
      v.alive = true;
      return;
    }
  }

  private spawnPickups() {
    const spots = [
      [40, 40, "cash"],
      [-40, -20, "armor"],
      [20, -80, "health"],
      [160, 20, "cash"],
      [-180, 40, "armor"],
      [0, 200, "health"],
      [80, -160, "cash"],
      [-80, 150, "cash"],
    ] as const;
    const mats = {
      cash: new THREE.MeshStandardMaterial({ color: "#f5b301", emissive: "#a87400", emissiveIntensity: 0.4, metalness: 0.6, roughness: 0.3 }),
      armor: new THREE.MeshStandardMaterial({ color: "#7eb6ff", emissive: "#1d4e89", emissiveIntensity: 0.35, metalness: 0.4, roughness: 0.35 }),
      health: new THREE.MeshStandardMaterial({ color: "#ff5d73", emissive: "#8f1d2c", emissiveIntensity: 0.3, roughness: 0.4 }),
    };
    for (const [x, z, kind] of spots) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.7), mats[kind]);
      mesh.position.set(x, 0.6, z);
      this.scene.add(mesh);
      this.picks.push({ x, z, kind, wait: 0, mesh });
    }
  }

  private indexBuildings() {
    for (const b of this.city.buildings) {
      const x0 = Math.floor((b.x - b.w / 2) / 48);
      const x1 = Math.floor((b.x + b.w / 2) / 48);
      const z0 = Math.floor((b.z - b.d / 2) / 48);
      const z1 = Math.floor((b.z + b.d / 2) / 48);
      for (let ix = x0; ix <= x1; ix++) {
        for (let iz = z0; iz <= z1; iz++) {
          const k = `${ix}:${iz}`;
          const arr = this.buckets.get(k);
          if (arr) arr.push(b);
          else this.buckets.set(k, [b]);
        }
      }
    }
  }

  private nearBuildings(x: number, z: number, rad: number) {
    const a = Math.floor((x - rad) / 48);
    const b = Math.floor((z - rad) / 48);
    const c = Math.floor((x + rad) / 48);
    const d = Math.floor((z + rad) / 48);
    const out: Bld[] = [];
    for (let ix = a; ix <= c; ix++) {
      for (let iz = b; iz <= d; iz++) {
        const arr = this.buckets.get(`${ix}:${iz}`);
        if (arr) out.push(...arr);
      }
    }
    return out;
  }

  private blocked(x: number, z: number, rad: number) {
    for (const b of this.nearBuildings(x, z, rad)) {
      if (Math.abs(x - b.x) < b.w / 2 + rad && Math.abs(z - b.z) < b.d / 2 + rad) return true;
    }
    return false;
  }

  private collide(x: number, z: number, rad: number) {
    let hit = false;
    for (let pass = 0; pass < 2; pass++) {
      for (const b of this.nearBuildings(x, z, rad)) {
        const minX = b.x - b.w / 2 - rad;
        const maxX = b.x + b.w / 2 + rad;
        const minZ = b.z - b.d / 2 - rad;
        const maxZ = b.z + b.d / 2 + rad;
        if (x <= minX || x >= maxX || z <= minZ || z >= maxZ) continue;
        const dl = x - minX;
        const dr = maxX - x;
        const dn = z - minZ;
        const df = maxZ - z;
        const m = Math.min(dl, dr, dn, df);
        if (m === dl) x = minX;
        else if (m === dr) x = maxX;
        else if (m === dn) z = minZ;
        else z = maxZ;
        hit = true;
      }
    }
    if (x < -348 || x > 348 || z < -348 || z > 348) {
      x = clamp(x, -348, 348);
      z = clamp(z, -348, 348);
      hit = true;
    }
    return { x, z, hit };
  }

  private los(x1: number, z1: number, x2: number, z2: number) {
    const dx = x2 - x1;
    const dz = z2 - z1;
    const dist = Math.hypot(dx, dz);
    const steps = Math.max(1, Math.ceil(dist / 6));
    for (let i = 1; i < steps; i++) {
      if (this.blocked(x1 + (dx * i) / steps, z1 + (dz * i) / steps, 0.25)) return false;
    }
    return true;
  }

  private frame = (now: number) => {
    const raw = Math.min(0.05, (now - this.last) / 1000 || 0);
    this.last = now;
    if (this.phase === "load") {
      const u = (now - this.bootAt) / this.minLoad;
      this.load = clamp(u, 0, 1);
      this.tip = TIPS[Math.floor(now / 2400) % TIPS.length]!;
      if (u >= 1) this.enterLobby();
    }
    this.acc += raw;
    let n = 0;
    while (this.acc >= 1 / 60 && n < 5) {
      this.tick(1 / 60);
      this.acc -= 1 / 60;
      n++;
    }
    this.animate(raw, now);
    this.renderer.render(this.scene, this.cam);
    this.emit(false);
    this.raf = requestAnimationFrame(this.frame);
  };

  private tick(dt: number) {
    this.captureEdges();
    if (this.phase !== "play") {
      this.ambient(dt);
      return;
    }
    if (this.pressed("Escape")) {
      if (this.phone) this.phone = false;
      else this.paused = !this.paused;
      this.emit(true);
    }
    if (this.down) {
      this.downT += dt;
      if (this.downT > 3.5) this.respawn();
      this.syncFocus();
      return;
    }
    if (this.paused || this.phone) {
      this.syncFocus();
      return;
    }
    if (this.pressed("KeyP") || this.pressed("KeyM")) {
      this.phone = true;
      this.emit(true);
      return;
    }
    this.sim(dt);
  }

  private captureEdges() {
    this.edge.clear();
    for (const c of WATCH) {
      const now = this.downCode(c);
      if (now && !this.prev.has(c)) this.edge.add(c);
      if (now) this.prev.add(c);
      else this.prev.delete(c);
    }
  }

  private pressed(code: string) {
    return this.edge.has(code);
  }

  private downCode(code: string) {
    if (this.injected.has(code)) return true;
    const el = document.activeElement;
    if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) return false;
    return this.keys.has(code);
  }

  private enterLobby() {
    if (this.phase !== "load") return;
    this.phase = "lobby";
    this.snap = true;
    this.minutes = 21 * 60;
    this.applyLook();
    this.emit(true);
  }

  private ambient(dt: number) {
    for (const v of this.vehicles) {
      if (!v.alive || v.role !== "traffic") continue;
      this.driveAlong(v, dt, v.speed || 12);
    }
    for (const p of this.civs) this.wander(p, dt, false);
  }

  private sim(dt: number) {
    this.minutes += dt * 0.55;
    const night = this.minutes % 1440 >= 20 * 60 || this.minutes % 1440 < 6 * 60;
    if (night !== this.night) this.applyLook();
    if (this.pressed("KeyN")) {
      this.minutes += 8 * 60;
      this.applyLook();
      this.note(this.night ? "Night falls on Bahia Bay." : "Morning hits the bay.");
    }
    if (this.pressed("KeyF")) this.toggleCar();
    if (this.pressed("KeyE")) this.useWorld();
    if (this.pressed("KeyR")) this.reload();
    if (this.pressed("KeyZ")) this.cycleRadio();
    if (this.pressed("KeyC")) this.crouch = !this.crouch;
    if (this.pressed("KeyG")) this.throwNade();
    if (this.pressed("Digit1")) this.equipWeapon("fists");
    if (this.pressed("Digit2")) this.equipWeapon("pistol");
    if (this.pressed("Digit3")) this.equipWeapon("jade");
    if (this.pressed("Digit4")) this.equipWeapon("shotgun");
    if (this.pressed("Digit5")) this.equipWeapon("rifle");
    this.syncFocus();
    if (this.driveIndex !== null) this.drivePlayer(dt);
    else this.walkPlayer(dt);
    this.syncFocus();
    for (const v of this.vehicles) {
      if (!v.alive || v.role === "player" || v.role === "off") continue;
      if (v.role === "traffic" || v.role === "parked") {
        if (v.role === "traffic") this.driveAlong(v, dt, 13);
      } else if (v.role === "cop") this.updateCop(v, dt);
    }
    for (const p of this.civs) this.wander(p, dt, true);
    this.updateGangs(dt);
    this.updateHeli(dt);
    this.updateWanted(dt);
    this.updateCombat(dt);
    this.updateNades(dt);
    this.updatePicks(dt);
    this.updateMission(dt);
    this.maybeEvent(dt);
    this.carBump();
    if (this.hear > 0) this.hear -= dt;
    if (this.hintT > 0) this.hintT -= dt;
    this.interact = this.interactLabel();
    this.feed = this.feed.filter((n) => n.until > performance.now());
  }

  private syncFocus() {
    if (this.driveIndex !== null) {
      const v = this.vehicles[this.driveIndex]!;
      this.fx = v.x;
      this.fz = v.z;
      this.fyaw = v.yaw;
      this.fspeed = v.speed;
    } else {
      this.fx = this.player.x;
      this.fz = this.player.z;
      this.fyaw = this.player.yaw;
      this.fspeed = this.player.speed;
    }
  }

  private walkPlayer(dt: number) {
    let ix = 0;
    let iz = 0;
    if (this.downCode("KeyD") || this.downCode("ArrowRight")) ix += 1;
    if (this.downCode("KeyA") || this.downCode("ArrowLeft")) ix -= 1;
    if (this.downCode("KeyW") || this.downCode("ArrowUp")) iz += 1;
    if (this.downCode("KeyS") || this.downCode("ArrowDown")) iz -= 1;
    ix += this.analogX;
    iz += this.analogY;
    const len = Math.hypot(ix, iz) || 1;
    if (len > 1) {
      ix /= len;
      iz /= len;
    }
    const moving = Math.hypot(ix, iz) > 0.12;
    const sprint = this.downCode("ShiftLeft") || this.downCode("ShiftRight") || Math.hypot(this.analogX, this.analogY) > 0.85;
    const sp = (sprint ? 8.5 : 5.3) * (this.crouch ? 0.55 : 1);
    const fx = -Math.sin(this.camYaw);
    const fz = -Math.cos(this.camYaw);
    const rx = Math.cos(this.camYaw);
    const rz = -Math.sin(this.camYaw);
    const mx = moving ? fx * iz + rx * ix : 0;
    const mz = moving ? fz * iz + rz * ix : 0;
    this.player.x += mx * sp * dt;
    this.player.z += mz * sp * dt;
    const c = this.collide(this.player.x, this.player.z, 0.55);
    this.player.x = c.x;
    this.player.z = c.z;
    this.water(this.player, 0.55, false);
    if (this.shootHeld()) this.player.yaw = this.camYaw;
    else if (moving) this.player.yaw = Math.atan2(-mx, -mz);
    this.player.speed = moving ? sp : 0;
  }

  private drivePlayer(dt: number) {
    const v = this.vehicles[this.driveIndex!]!;
    const spec = CAR_SPEC[v.kind];
    let steer = 0;
    if (this.downCode("KeyA") || this.downCode("ArrowLeft")) steer += 1;
    if (this.downCode("KeyD") || this.downCode("ArrowRight")) steer -= 1;
    steer += -this.analogX;
    steer = clamp(steer, -1, 1);
    if (this.steerOverride !== null) steer = this.steerOverride;
    let throttle = 0;
    if (this.downCode("KeyW") || this.downCode("ArrowUp")) throttle += 1;
    if (this.downCode("KeyS") || this.downCode("ArrowDown")) throttle -= 1;
    throttle += this.analogY;
    throttle = clamp(throttle, -1, 1);
    const hand = this.downCode("Space") || this.touchBrake;
    if (throttle > 0.05) v.speed += spec.accel * throttle * dt * (v.hp < 40 ? 0.55 : 1);
    else if (throttle < -0.05) v.speed -= spec.accel * 0.75 * dt;
    else v.speed *= Math.exp(-0.55 * dt);
    if (hand) v.speed *= Math.exp(-2.6 * dt);
    v.speed = clamp(v.speed, -10, spec.max * (v.hp < 40 ? 0.45 : 1));
    const reverse = v.speed >= 0 ? 1 : -1;
    const sf = Math.min(1, Math.abs(v.speed) / 7);
    const factor = Math.abs(v.speed) > 0.8 ? Math.max(0.42, sf) : sf;
    v.yaw += steer * spec.turn * factor * (hand ? 1.35 : 1) * reverse * dt;
    const ox = v.x;
    const oz = v.z;
    v.x += -Math.sin(v.yaw) * v.speed * dt;
    v.z += -Math.cos(v.yaw) * v.speed * dt;
    const rad = Math.max(1.15, spec.wid * 0.48);
    const c = this.collide(v.x, v.z, rad);
    if (c.hit && Math.abs(v.speed) > 12) {
      this.hurt(Math.min(18, Math.abs(v.speed) * 0.35));
      v.speed *= 0.42;
      v.hp -= 8;
      this.shake = Math.min(1, this.shake + 0.45);
    }
    v.x = c.x;
    v.z = c.z;
    this.water(v, rad, true);
    v.spin += v.speed * dt * 1.4;
    const diff = wrap(v.yaw - this.camYaw);
    this.camYaw += diff * (1 - Math.exp(-4 * dt));
    this.look *= Math.exp(-1.6 * dt);
    void ox;
    void oz;
  }

  private water(ent: { x: number; z: number; speed?: number }, rad: number, car: boolean) {
    if (ent.z > 320 && Math.abs(ent.x) > 14) {
      if (ent.speed !== undefined) ent.speed *= 0.9;
      if (car && ent.speed !== undefined && Math.abs(ent.speed) < 4 && ent.z > 330) {
        this.hurt(8);
        ent.z = 300;
        ent.speed = 0;
        this.note("The bay keeps the car. You, barely.");
        if (this.driveIndex !== null) this.toggleCar();
      }
    }
    void rad;
  }

  private driveAlong(v: Veh, dt: number, speed: number) {
    const a = this.city.nodes[v.na];
    const b = this.city.nodes[v.nb];
    if (!a || !b) return;
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    let slow = speed;
    for (const o of this.vehicles) {
      if (o === v || !o.alive) continue;
      const fx = -Math.sin(v.yaw);
      const fz = -Math.cos(v.yaw);
      const rx = o.x - v.x;
      const rz = o.z - v.z;
      const along = rx * fx + rz * fz;
      if (along > 0 && along < 7 && rx * rx + rz * rz < 30) slow = Math.min(slow, 2);
    }
    v.t += (slow * dt) / len;
    v.speed = slow;
    if (v.t >= 1) {
      v.t = 0;
      const outs = (this.city.adj[v.nb] ?? []).filter((n) => n !== v.na);
      const pool = outs.length ? outs : (this.city.adj[v.nb] ?? [v.na]);
      const nxt = pool[Math.floor(Math.random() * pool.length)] ?? v.na;
      v.na = v.nb;
      v.nb = nxt;
    }
    const p = this.city.nodes[v.na]!;
    const q = this.city.nodes[v.nb] ?? p;
    v.x = p.x + (q.x - p.x) * v.t;
    v.z = p.z + (q.z - p.z) * v.t;
    const mx = q.x - p.x;
    const mz = q.z - p.z;
    if (mx * mx + mz * mz > 0.01) v.yaw = Math.atan2(-mx, -mz);
    v.spin += slow * dt;
  }

  private updateCop(v: Veh, dt: number) {
    if (this.stars <= 0) {
      this.driveAlong(v, dt, 16);
      return;
    }
    const dx = this.fx - v.x;
    const dz = this.fz - v.z;
    const dist = Math.hypot(dx, dz);
    const target = Math.atan2(-dx, -dz);
    v.yaw += clamp(wrap(target - v.yaw), -2.4 * dt, 2.4 * dt);
    const want = dist < 7 ? 0 : dist < 14 ? 8 : 32;
    v.speed += clamp(want - v.speed, -24 * dt, 20 * dt);
    v.x += -Math.sin(v.yaw) * v.speed * dt;
    v.z += -Math.cos(v.yaw) * v.speed * dt;
    const c = this.collide(v.x, v.z, 1.45);
    v.x = c.x;
    v.z = c.z;
    v.spin += v.speed * dt;
    if (dist < 30 && this.stars >= 2 && this.los(v.x, v.z, this.fx, this.fz)) {
      v.shoot -= dt;
      if (v.shoot <= 0) {
        v.shoot = 0.85;
        if (Math.random() < 0.35 + this.stars * 0.08) this.hurt(5 + this.stars * 1.4);
      }
    }
    if (dist < 3.4 && Math.abs(this.fspeed) < 6) this.bustT += dt;
  }

  private wander(p: Ped, dt: number, smart: boolean) {
    if (!p.alive) return;
    if (p.state === "dead") {
      p.dead += dt;
      if (p.dead > 8) p.alive = false;
      return;
    }
    const dx = p.x - this.fx;
    const dz = p.z - this.fz;
    const dist = Math.hypot(dx, dz);
    if (smart && (this.hear > 0 && dist < 26)) p.state = "flee";
    if (p.state === "flee") {
      p.yaw = Math.atan2(-dx, -dz);
      p.speed = 4.6;
    } else {
      p.speed = 1.35;
      p.walk += dt;
      if (Math.random() < dt * 0.4) p.yaw += (Math.random() - 0.5) * 1.6;
    }
    p.x += -Math.sin(p.yaw) * p.speed * dt;
    p.z += -Math.cos(p.yaw) * p.speed * dt;
    if (this.blocked(p.x, p.z, 0.4) || p.z > 330 || Math.abs(p.x) > 340) p.yaw += 2.2;
    const c = this.collide(p.x, p.z, 0.4);
    p.x = c.x;
    p.z = c.z;
  }

  private updateGangs(dt: number) {
    const pin = this.city.pins.foundry!;
    let living = 0;
    for (const g of this.gangs) {
      if (!g.alive) continue;
      if (g.state === "dead") {
        g.dead += dt;
        if (g.dead > 6) g.alive = false;
        continue;
      }
      living++;
      const dx = this.fx - g.x;
      const dz = this.fz - g.z;
      const dist = Math.hypot(dx, dz);
      const home = Math.hypot(g.x - pin.x, g.z - pin.z);
      const angry = this.aggro || dist < 20 || (this.stepKind() === "eliminate" && home < 40);
      if (angry) {
        g.state = "attack";
        g.yaw = Math.atan2(-dx, -dz);
        if (dist > 9) {
          g.x += -Math.sin(g.yaw) * 3.4 * dt;
          g.z += -Math.cos(g.yaw) * 3.4 * dt;
        }
        g.shoot -= dt;
        if (dist < 32 && g.shoot <= 0 && this.los(g.x, g.z, this.fx, this.fz)) {
          g.shoot = 0.9;
          if (Math.random() < 0.42) this.hurt(7);
        }
      } else {
        g.state = "walk";
        this.wander(g, dt, false);
      }
      const c = this.collide(g.x, g.z, 0.45);
      g.x = c.x;
      g.z = c.z;
    }
    const elim = this.stepKind() === "eliminate";
    if (!elim && living === 0) {
      this.gangCool -= dt;
      if (this.gangCool <= 0) {
        this.gangCool = 25;
        this.spawnGang(5);
        this.aggro = false;
      }
    }
  }

  private spawnGang(n: number) {
    const pin = this.city.pins.foundry!;
    this.gangs.forEach((g, i) => {
      g.alive = i < n;
      g.state = "walk";
      g.hp = 70;
      g.dead = 0;
      g.x = pin.x + (i - n / 2) * 3;
      g.z = pin.z + (i % 2 === 0 ? 4 : -4);
    });
  }

  private updateHeli(dt: number) {
    if (this.stars >= 4 && !this.heliOn && this.heliCool <= 0) {
      this.heliOn = true;
      this.heliHp = 90;
      this.heliX = this.fx + 30;
      this.heliZ = this.fz + 30;
      this.note("Air unit is overhead.");
    }
    if (this.heliCool > 0) this.heliCool -= dt;
    if (!this.heliOn) return;
    const ang = performance.now() * 0.00035;
    const tx = this.fx + Math.cos(ang) * 22;
    const tz = this.fz + Math.sin(ang) * 22;
    const dx = tx - this.heliX;
    const dz = tz - this.heliZ;
    this.heliYaw = Math.atan2(-dx, -dz);
    this.heliX += clamp(dx, -30 * dt, 30 * dt);
    this.heliZ += clamp(dz, -30 * dt, 30 * dt);
    this.heliShot -= dt;
    if (this.heliShot <= 0 && this.stars >= 4) {
      this.heliShot = 1.3;
      if (Math.random() < 0.5) this.hurt(8);
    }
  }

  private updateWanted(dt: number) {
    const need = [0, 1, 2, 3, 3, 3][this.stars] ?? 0;
    let have = 0;
    for (const v of this.vehicles) if (v.role === "cop" && v.alive) have++;
    if (have < need) {
      const slot = this.vehicles.find((v) => v.role === "cop" && !v.alive);
      if (slot) this.placeCop(slot);
    }
    if (this.stars === 0) {
      for (const v of this.vehicles) {
        if (v.role === "cop" && v.alive && Math.hypot(v.x - this.fx, v.z - this.fz) > 70) v.alive = false;
      }
    }
    if (this.stars <= 0) {
      this.bustT = 0;
      return;
    }
    let seen = false;
    for (const v of this.vehicles) {
      if (v.role !== "cop" || !v.alive) continue;
      const d = Math.hypot(v.x - this.fx, v.z - this.fz);
      if (d < 48 + this.stars * 8 && this.los(v.x, v.z, this.fx, this.fz)) seen = true;
    }
    if (this.heliOn && this.stars >= 4 && Math.hypot(this.heliX - this.fx, this.heliZ - this.fz) < 80) seen = true;
    if (seen) this.hidden = 0;
    else {
      this.hidden += dt;
      if (this.hidden > 7 + this.stars * 1.6) {
        this.stars -= 1;
        this.hidden = 0;
        if (this.stars <= 0) {
          this.heliOn = false;
          this.note("You slipped them.");
        }
      }
    }
    if (this.bustT > 1.65) this.knock("busted");
    else if (!seen) this.bustT = Math.max(0, this.bustT - dt);
  }

  private placeCop(v: Veh) {
    for (let k = 0; k < 30; k++) {
      const i = Math.floor(Math.random() * this.city.nodes.length);
      const n = this.city.nodes[i];
      const next = this.city.adj[i]?.[0];
      if (!n || next === undefined) continue;
      const d = Math.hypot(n.x - this.fx, n.z - this.fz);
      if (d < 50 || d > 110) continue;
      v.alive = true;
      v.hp = 130;
      v.na = i;
      v.nb = next;
      v.t = 0;
      v.x = n.x;
      v.z = n.z;
      v.speed = 16;
      v.yaw = Math.atan2(-(this.fx - n.x), -(this.fz - n.z));
      return;
    }
  }

  private shootHeld() {
    return this.touchShoot || this.downCode("ControlLeft") || this.downCode("ControlRight") || (this.pointerDown && this.drag < 14);
  }

  private updateCombat(dt: number) {
    const spec = WEAPONS.find((w) => w.id === this.weapon)!;
    this.cool -= dt;
    const held = this.shootHeld();
    if (this.driveIndex === null && held) this.player.yaw = this.camYaw;
    if (!spec.auto) {
      if (held && !this.trigger && this.cool <= 0) this.fire(spec);
      this.trigger = held;
    } else if (held && this.cool <= 0) this.fire(spec);
    if (this.flash.intensity > 0) this.flash.intensity = Math.max(0, this.flash.intensity - dt * 80);
  }

  private aimYaw() {
    return this.driveIndex !== null ? this.vehicles[this.driveIndex]!.yaw : this.player.yaw;
  }

  private fire(spec: (typeof WEAPONS)[number]) {
    if (spec.mag > 0) {
      const mag = this.mags[spec.id] ?? 0;
      if (mag <= 0) {
        this.reload();
        return;
      }
      this.mags[spec.id] = mag - 1;
    }
    this.cool = spec.rate;
    this.audio.gun(spec.id);
    this.hear = 1.2;
    this.shake = Math.min(1, this.shake + (spec.id === "shotgun" ? 0.45 : 0.18));
    const yaw = this.aimYaw();
    this.flash.position.set(this.fx - Math.sin(yaw) * 1.2, 1.4, this.fz - Math.cos(yaw) * 1.2);
    this.flash.intensity = 18;
    const pellets = spec.pellets ?? 1;
    for (let i = 0; i < pellets; i++) {
      const spread = (Math.random() - 0.5) * spec.spread * 2;
      this.hitscan(yaw + spread, spec.dmg, spec.range);
    }
    let copNear = false;
    for (const v of this.vehicles) {
      if (v.role === "cop" && v.alive && Math.hypot(v.x - this.fx, v.z - this.fz) < 42) copNear = true;
    }
    if (copNear && this.stars < 1) this.addStars(1);
  }

  private hitscan(yaw: number, dmg: number, range: number) {
    const dx = -Math.sin(yaw);
    const dz = -Math.cos(yaw);
    let best = range;
    let hit: { kind: "ped" | "car" | "heli"; ped?: Ped; car?: Veh } | null = null;
    const considerPed = (p: Ped) => {
      if (!p.alive || p.state === "dead") return;
      const px = p.x - this.fx;
      const pz = p.z - this.fz;
      const t = px * dx + pz * dz;
      if (t < 1 || t > best) return;
      const cx = this.fx + dx * t;
      const cz = this.fz + dz * t;
      if (Math.hypot(p.x - cx, p.z - cz) < 0.7) {
        best = t;
        hit = { kind: "ped", ped: p };
      }
    };
    for (const p of this.civs) considerPed(p);
    for (const p of this.gangs) considerPed(p);
    for (const v of this.vehicles) {
      if (!v.alive || (this.driveIndex !== null && v === this.vehicles[this.driveIndex])) continue;
      const px = v.x - this.fx;
      const pz = v.z - this.fz;
      const t = px * dx + pz * dz;
      if (t < 1 || t > best) continue;
      const cx = this.fx + dx * t;
      const cz = this.fz + dz * t;
      if (Math.hypot(v.x - cx, v.z - cz) < 1.5) {
        best = t;
        hit = { kind: "car", car: v };
      }
    }
    if (this.heliOn) {
      const px = this.heliX - this.fx;
      const pz = this.heliZ - this.fz;
      const t = px * dx + pz * dz;
      if (t > 0 && t < best && Math.hypot(this.heliX - (this.fx + dx * t), this.heliZ - (this.fz + dz * t)) < 8) {
        hit = { kind: "heli" };
        best = t;
      }
    }
    if (!hit) return;
    this.audio.hit();
    if (hit.kind === "heli") {
      this.heliHp -= dmg;
      if (this.heliHp <= 0) {
        this.heliOn = false;
        this.heliCool = 35;
        this.note("Air unit down.");
        this.money += 400;
      }
      return;
    }
    if (hit.kind === "ped" && hit.ped) {
      hit.ped.hp -= dmg;
      if (hit.ped.kind === "civ") hit.ped.state = "flee";
      if (hit.ped.hp <= 0) {
        hit.ped.state = "dead";
        hit.ped.dead = 0;
        if (hit.ped.kind === "civ") this.addStars(1);
        else {
          this.aggro = true;
          if (this.run) this.run.kills += 1;
          this.money += 50;
        }
      }
      return;
    }
    if (hit.car) {
      hit.car.hp -= dmg * 0.7;
      if (hit.car.role === "cop") this.aggro = true;
      if (hit.car.hp <= 0) {
        hit.car.alive = false;
        hit.car.speed = 0;
        this.boom(hit.car.x, hit.car.z);
        if (hit.car.role === "cop") this.addStars(1);
      }
    }
  }

  private reload() {
    const spec = WEAPONS.find((w) => w.id === this.weapon);
    if (!spec || spec.mag <= 0) return;
    const have = this.mags[spec.id] ?? 0;
    const pool = this.reserve[spec.id] ?? 0;
    if (pool <= 0 || have >= spec.mag) return;
    const take = Math.min(spec.mag - have, pool);
    this.mags[spec.id] = have + take;
    this.reserve[spec.id] = pool - take;
    this.cool = Math.max(this.cool, 0.7);
  }

  private throwNade() {
    if (this.grenades <= 0 || this.down) return;
    this.grenades -= 1;
    const yaw = this.aimYaw();
    this.nades.push({
      x: this.fx,
      y: 1.5,
      z: this.fz,
      vx: -Math.sin(yaw) * 14,
      vy: 8,
      vz: -Math.cos(yaw) * 14,
      t: 0,
      alive: true,
    });
  }

  private updateNades(dt: number) {
    for (const n of this.nades) {
      if (!n.alive) continue;
      n.vy -= 14 * dt;
      n.x += n.vx * dt;
      n.y += n.vy * dt;
      n.z += n.vz * dt;
      n.t += dt;
      if ((n.y <= 0.4 && n.t > 0.25) || n.t > 2.1) {
        n.alive = false;
        this.explode(n.x, n.z);
      }
    }
    this.nades = this.nades.filter((n) => n.alive);
  }

  private explode(x: number, z: number) {
    this.audio.boom();
    this.boom(x, z);
    this.shake = 1;
    this.addStars(1);
    const hitR = (px: number, pz: number, rad: number, dmg: number, apply: () => void) => {
      const d = Math.hypot(px - x, pz - z);
      if (d < rad) apply();
      void dmg;
    };
    if (Math.hypot(this.fx - x, this.fz - z) < 6) this.hurt(22);
    for (const p of [...this.civs, ...this.gangs]) {
      hitR(p.x, p.z, 8, 50, () => {
        if (!p.alive || p.state === "dead") return;
        p.hp -= 55;
        if (p.hp <= 0) {
          p.state = "dead";
          if (p.kind === "gang" && this.run) this.run.kills += 1;
          if (p.kind === "civ") this.addStars(1);
        }
      });
    }
    for (const v of this.vehicles) {
      if (!v.alive) continue;
      if (Math.hypot(v.x - x, v.z - z) < 7) {
        v.hp -= 60;
        if (v.hp <= 0 && v.role !== "player") v.alive = false;
      }
    }
  }

  private boom(x: number, z: number) {
    this.blast.visible = true;
    this.blast.position.set(x, 1.2, z);
    this.blast.scale.setScalar(0.4);
    const mat = this.blast.material as THREE.MeshBasicMaterial;
    mat.opacity = 0.85;
  }

  private hurt(amount: number) {
    if (this.down) return;
    if (this.crouch) amount *= 0.7;
    let left = amount;
    if (this.player.armor > 0) {
      const use = Math.min(this.player.armor, left);
      this.player.armor -= use;
      left -= use;
    }
    this.player.health -= left;
    this.pain = 1;
    this.shake = Math.min(1, this.shake + 0.3);
    if (this.player.health <= 0) this.knock("wasted");
  }

  private knock(kind: "wasted" | "busted") {
    if (this.down) return;
    this.down = kind;
    this.downT = 0;
    this.player.health = 0;
    if (this.driveIndex !== null) this.vehicles[this.driveIndex]!.speed = 0;
    this.note(kind === "wasted" ? "Wasted." : "Busted.");
    this.emit(true);
  }

  private addStars(n: number) {
    const before = this.stars;
    this.stars = clamp(this.stars + n, 0, 5);
    this.hidden = 0;
    if (this.stars > before) this.note(DISPATCH[Math.min(DISPATCH.length - 1, this.stars - 1)] ?? "Heat rising.");
  }

  private updatePicks(dt: number) {
    for (const p of this.picks) {
      if (p.wait > 0) {
        p.wait -= dt;
        p.mesh.visible = false;
        continue;
      }
      p.mesh.visible = true;
      p.mesh.rotation.y += dt * 1.6;
      p.mesh.position.y = 0.65 + Math.sin(performance.now() * 0.004 + p.x) * 0.12;
      if (Math.hypot(p.x - this.fx, p.z - this.fz) < 1.7) {
        if (p.kind === "cash") {
          this.money += 250;
          this.note("+$250");
          this.audio.cash();
        } else if (p.kind === "armor") {
          this.player.armor = Math.min(100, this.player.armor + 40);
          this.note("Armor up.");
        } else {
          this.player.health = Math.min(100, this.player.health + 35);
          this.note("Patched up.");
        }
        p.wait = 28;
      }
    }
  }

  private carBump() {
    if (this.driveIndex === null) return;
    const v = this.vehicles[this.driveIndex]!;
    for (const o of this.vehicles) {
      if (o === v || !o.alive) continue;
      const d = Math.hypot(v.x - o.x, v.z - o.z);
      const min = 2.5;
      if (d < min && d > 0.001) {
        const nx = (v.x - o.x) / d;
        const nz = (v.z - o.z) / d;
        const push = (min - d) * 0.6;
        v.x += nx * push;
        v.z += nz * push;
        o.x -= nx * push * 0.4;
        o.z -= nz * push * 0.4;
        if (Math.abs(v.speed) > 14) {
          this.hurt(4);
          v.speed *= 0.55;
          o.hp -= 10;
          this.shake = Math.min(1, this.shake + 0.25);
        }
      }
    }
  }

  private stepKind() {
    return this.run?.steps[this.run.step]?.kind ?? "";
  }

  private updateMission(dt: number) {
    const run = this.run;
    if (!run) return;
    const step = run.steps[run.step];
    if (!step) return;
    if (step.kind === "goto" || step.kind === "hold") {
      const pin = this.city.pins[step.at];
      if (!pin) return;
      const d = Math.hypot(pin.x - this.fx, pin.z - this.fz);
      if (step.kind === "goto" && d <= step.r) this.advance();
      if (step.kind === "hold") {
        if (d <= step.r) run.hold += dt;
        else run.hold = Math.max(0, run.hold - dt * 0.35);
        if (run.hold >= step.time) this.advance();
      }
    } else if (step.kind === "survive") {
      run.time += dt;
      if (this.stars <= 0 || run.time >= step.time) this.advance();
    } else if (step.kind === "eliminate") {
      if (run.kills >= step.count) this.advance();
    } else if (step.kind === "race") {
      run.raceT += dt;
      const target = step.points[run.cp];
      if (target && Math.hypot(target.x - this.fx, target.z - this.fz) < 14) {
        run.cp += 1;
        if (run.cp >= step.points.length) {
          run.cp = 0;
          run.lap += 1;
          if (run.lap >= step.laps) this.advance();
        }
      }
    }
  }

  private advance() {
    const run = this.run;
    if (!run) return;
    run.step += 1;
    run.hold = 0;
    run.time = 0;
    if (run.step >= run.steps.length) this.finishMission();
    else {
      this.onStep(false);
      this.note(run.steps[run.step]?.text ?? "Next.");
    }
  }

  private onStep(start: boolean) {
    const run = this.run;
    if (!run) return;
    const step = run.steps[run.step];
    if (!step) return;
    if (step.kind === "survive") this.stars = Math.max(this.stars, step.stars);
    if (step.kind === "eliminate") {
      this.spawnGang(step.count);
      this.aggro = true;
      run.kills = 0;
    }
    if (step.kind === "race" && start) this.beginRace(step.points);
    if (step.kind === "race" && !start) {
      /* continue */
    }
  }

  private beginRace(points: { x: number; z: number }[]) {
    const a = points[0];
    const b = points[1] ?? points[0];
    if (!a || !b) return;
    const yaw = Math.atan2(-(b.x - a.x), -(b.z - a.z));
    if (this.vehicles[0]!.kind !== "sport") this.rebuild(0, "sport", this.carColor);
    this.prepareDrive(0, a.x, a.z, yaw);
    this.vehicles[0]!.speed = 10;
    if (this.run) {
      this.run.cp = 1 % points.length;
      this.run.lap = 0;
      this.run.raceT = 0;
    }
  }

  private finishMission() {
    const run = this.run;
    if (!run) return;
    this.money += run.reward;
    this.xp += run.xp;
    if (run.weapon && !this.ownedWeapons.includes(run.weapon)) {
      this.ownedWeapons.push(run.weapon);
      const spec = WEAPONS.find((w) => w.id === run.weapon);
      if (spec && spec.mag) {
        this.mags[run.weapon] = spec.mag;
        this.reserve[run.weapon] = spec.mag * 2;
      }
    }
    if (run.id !== "event" && !this.missionsDone.includes(run.id)) this.missionsDone.push(run.id);
    if ((run.id === "m9" || run.id === "m10" || run.id === "m30") && run.raceT > 0) {
      if (this.bestRace === null || run.raceT < this.bestRace) this.bestRace = run.raceT;
    }
    this.note(`${run.name} clear  +$${run.reward.toLocaleString("en-US")}`);
    this.audio.cash();
    this.run = null;
    this.aggro = false;
    this.save();
    this.emit(true);
  }

  private maybeEvent(dt: number) {
    if (this.run || this.mode !== "freeroam" || this.stars > 0) return;
    this.eventT += dt;
    if (this.eventT < 48) return;
    this.eventT = 0;
    if (Math.random() > 0.6) return;
    const pinKeys = ["pizza", "beach", "mall", "gas", "park"];
    const dest = pinKeys[Math.floor(Math.random() * pinKeys.length)]!;
    let nx = this.fx + 30;
    let nz = this.fz;
    for (let k = 0; k < 12; k++) {
      const i = Math.floor(Math.random() * this.city.nodes.length);
      const n = this.city.nodes[i];
      if (!n) continue;
      const d = Math.hypot(n.x - this.fx, n.z - this.fz);
      if (d > 25 && d < 70) {
        nx = n.x;
        nz = n.z;
        break;
      }
    }
    this.city.pins.event = { x: nx, z: nz, name: "Caller" };
    this.run = {
      id: "event",
      name: "Street call",
      reward: 900,
      xp: 25,
      steps: [
        { kind: "goto", at: "event", r: 10, text: "Someone's waving you down." },
        { kind: "goto", at: dest, r: 12, text: "Get them where they paid to go." },
      ],
      step: 0,
      hold: 0,
      time: 0,
      cp: 0,
      lap: 0,
      kills: 0,
      raceT: 0,
    };
    this.note("Street call — check the gold beam.");
  }

  private markerPos(): { x: number; z: number } | null {
    const run = this.run;
    if (!run) return null;
    const step = run.steps[run.step];
    if (!step) return null;
    if (step.kind === "goto" || step.kind === "hold") {
      const p = this.city.pins[step.at];
      return p ? { x: p.x, z: p.z } : null;
    }
    if (step.kind === "race") return step.points[run.cp] ?? null;
    if (step.kind === "eliminate") {
      const g = this.gangs.find((p) => p.alive && p.state !== "dead");
      return g ? { x: g.x, z: g.z } : this.city.pins.foundry ?? null;
    }
    return null;
  }

  private hold01() {
    const step = this.run?.steps[this.run.step];
    if (!step || step.kind !== "hold") return 0;
    return clamp((this.run?.hold ?? 0) / step.time, 0, 1);
  }

  private interactLabel() {
    if (this.driveIndex !== null) return "F  Exit vehicle";
    if (this.nearestCar(3.4) >= 0) return "F  Enter vehicle";
    for (const prop of PROPS) {
      const pin = this.city.pins[prop.at];
      if (!pin || Math.hypot(pin.x - this.fx, pin.z - this.fz) > 12) continue;
      if (this.ownedProps.includes(prop.id)) return `E  ${prop.name} — save & heal`;
      return `E  Buy ${prop.name} $${prop.price.toLocaleString("en-US")}`;
    }
    const pizza = this.city.pins.pizza;
    if (pizza && Math.hypot(pizza.x - this.fx, pizza.z - this.fz) < 12) return "E  Slice $100";
    return "";
  }

  private nearestCar(max: number) {
    let best = -1;
    let bd = max;
    this.vehicles.forEach((v, i) => {
      if (!v.alive || i === this.driveIndex) return;
      const d = Math.hypot(v.x - this.player.x, v.z - this.player.z);
      if (d < bd) {
        bd = d;
        best = i;
      }
    });
    return best;
  }

  private toggleCar() {
    if (this.driveIndex !== null) {
      const v = this.vehicles[this.driveIndex]!;
      const rx = Math.cos(v.yaw);
      const rz = -Math.sin(v.yaw);
      this.player.x = v.x + rx * 2.3;
      this.player.z = v.z + rz * 2.3;
      const c = this.collide(this.player.x, this.player.z, 0.5);
      this.player.x = c.x;
      this.player.z = c.z;
      this.player.yaw = v.yaw;
      v.role = "parked";
      v.speed = 0;
      this.driveIndex = null;
      this.camYaw = v.yaw;
      return;
    }
    const i = this.nearestCar(3.4);
    if (i < 0) return;
    const v = this.vehicles[i]!;
    if (v.role === "traffic") this.addStars(1);
    if (v.role === "cop") this.addStars(2);
    v.role = "player";
    this.driveIndex = i;
    this.camYaw = v.yaw;
    this.player.speed = 0;
  }

  private useWorld() {
    for (const prop of PROPS) {
      const pin = this.city.pins[prop.at];
      if (!pin || Math.hypot(pin.x - this.fx, pin.z - this.fz) > 12) continue;
      if (!this.ownedProps.includes(prop.id)) {
        this.buyProperty(prop.id);
        return;
      }
      this.player.health = 100;
      this.player.armor = 100;
      if (this.driveIndex !== null) this.vehicles[this.driveIndex]!.hp = 140;
      this.note(`${prop.name} — saved, healed, patched.`);
      this.save();
      this.emit(true);
      return;
    }
    const pizza = this.city.pins.pizza;
    if (pizza && Math.hypot(pizza.x - this.fx, pizza.z - this.fz) < 12) {
      if (this.money < 100) {
        this.note("Slice costs $100.");
        return;
      }
      this.money -= 100;
      this.player.health = Math.min(100, this.player.health + 40);
      this.note("Hot slice. Health up.");
      this.save();
    }
  }

  private prepareDrive(index: number, x: number, z: number, yaw: number) {
    if (this.driveIndex !== null && this.driveIndex !== index) {
      const prev = this.vehicles[this.driveIndex]!;
      prev.role = "parked";
      prev.speed = 0;
    }
    const v = this.vehicles[index]!;
    v.alive = true;
    v.role = "player";
    v.x = x;
    v.z = z;
    v.yaw = yaw;
    v.speed = 0;
    v.hp = Math.max(40, v.hp);
    this.driveIndex = index;
    this.camYaw = yaw;
    this.look = 0;
    this.player.x = x;
    this.player.z = z;
    for (const o of this.vehicles) {
      if (o === v) continue;
      if (Math.hypot(o.x - x, o.z - z) < 9) o.x += 18;
    }
  }

  private startMode(mode: ModeId) {
    this.audio.unlock();
    this.audio.ensureEngine();
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    this.phase = "play";
    this.paused = false;
    this.phone = false;
    this.down = "";
    this.mode = mode;
    this.minutes = 10 * 60;
    this.snap = true;
    this.hintT = 8;
    this.applyLook();
    const launch = (id: string) => {
      const m = MISSIONS.find((x) => x.id === id);
      if (m && (!m.unlockAfter || this.missionsDone.includes(m.unlockAfter))) this.startMission(id);
      else {
        this.note("That job is still locked. Streets are open.");
        this.run = null;
        this.prepareDrive(0, 0, 90, 0);
      }
    };
    if (mode === "freeroam") {
      this.run = null;
      this.prepareDrive(0, 0, 90, 0);
    } else if (mode === "story") {
      const next = MISSIONS.find((m) => m.chapter === "Story" && !this.missionsDone.includes(m.id) && (!m.unlockAfter || this.missionsDone.includes(m.unlockAfter)));
      if (next) this.startMission(next.id);
      else {
        this.note("Story's quiet. The city isn't.");
        this.prepareDrive(0, 0, 90, 0);
      }
    } else if (mode === "heist") {
      const id =
        ["m13", "m14", "m24"].find((x) => {
          const m = MISSIONS.find((mm) => mm.id === x);
          return !!m && !this.missionsDone.includes(x) && (!m.unlockAfter || this.missionsDone.includes(m.unlockAfter));
        }) ?? "m13";
      launch(id);
    } else if (mode === "race") launch("m10");
    else if (mode === "heat") launch("m20");
    else if (mode === "turf") launch("m11");
    this.emit(true);
  }

  private startMission(id: string) {
    const m = MISSIONS.find((x) => x.id === id);
    if (!m) return;
    this.audio.unlock();
    this.phase = "play";
    this.paused = false;
    this.phone = false;
    this.down = "";
    this.snap = true;
    this.minutes = 10 * 60;
    this.applyLook();
    if (m.unlockAfter && !this.missionsDone.includes(m.unlockAfter)) {
      this.note("Finish the job before that one.");
      this.prepareDrive(0, 0, 90, 0);
      this.emit(true);
      return;
    }
    this.run = {
      id: m.id,
      name: m.name,
      reward: m.reward,
      xp: m.xp,
      weapon: m.rewardWeapon,
      steps: m.steps,
      step: 0,
      hold: 0,
      time: 0,
      cp: 0,
      lap: 0,
      kills: 0,
      raceT: 0,
    };
    this.mode = m.chapter === "Heist" ? "heist" : m.chapter === "Race" ? "race" : m.chapter === "Heat" ? "heat" : m.chapter === "Turf" ? "turf" : m.chapter === "Story" ? "story" : "freeroam";
    if (m.steps[0]?.kind !== "race") this.prepareDrive(0, 0, 90, 0);
    this.onStep(true);
    this.note(m.steps[0]?.text ?? m.name);
    this.emit(true);
  }

  private goLobby() {
    this.phase = "lobby";
    this.paused = false;
    this.phone = false;
    this.snap = true;
    this.minutes = 21 * 60;
    this.applyLook();
    this.emit(true);
  }

  private respawn() {
    const spot = this.ownedProps.includes("garage")
      ? this.city.pins.garage!
      : this.ownedProps.includes("condo")
        ? this.city.pins.condo!
        : this.city.pins.hospital!;
    const lost = this.down === "busted" ? 0.1 : 0.05;
    this.money = Math.max(0, Math.floor(this.money * (1 - lost)));
    this.player.health = 100;
    this.player.armor = 0;
    this.stars = 0;
    this.heliOn = false;
    this.down = "";
    this.bustT = 0;
    this.player.x = spot.x;
    this.player.z = spot.z;
    if (this.driveIndex !== null) {
      const v = this.vehicles[this.driveIndex]!;
      v.x = spot.x;
      v.z = spot.z;
      v.speed = 0;
      v.hp = 100;
      v.yaw = 0;
    }
    if (this.run) {
      this.note("Mission failed.");
      this.run = null;
    }
    this.camYaw = 0;
    this.save();
    this.emit(true);
  }

  private ownedFits = new Set<string>(["darkfire"]);

  private setOutfit(id: string) {
    const o = OUTFITS.find((x) => x.id === id);
    if (!o) return;
    if (!this.ownedFits.has(id)) {
      if (this.money < o.price) {
        this.note("Not enough cash for that fit.");
        return;
      }
      this.money -= o.price;
      this.ownedFits.add(id);
      if (o.price > 0) this.note(`${o.name} — closet's yours.`);
    }
    this.outfit = id;
    applyOutfit(this.rig, o);
    this.audio.blip();
    this.save();
    this.emit(true);
  }

  private buyWeapon(id: WeaponId) {
    if (this.ownedWeapons.includes(id)) {
      this.equipWeapon(id);
      return;
    }
    const spec = WEAPONS.find((w) => w.id === id);
    if (!spec) return;
    if (this.money < spec.price) {
      this.note("Too light for that iron.");
      return;
    }
    this.money -= spec.price;
    this.ownedWeapons.push(id);
    if (spec.mag) {
      this.mags[id] = spec.mag;
      this.reserve[id] = spec.mag * 2;
    }
    this.weapon = id;
    this.note(`${spec.name} unlocked.`);
    this.audio.cash();
    this.save();
    this.emit(true);
  }

  private equipWeapon(id: WeaponId) {
    if (!this.ownedWeapons.includes(id)) {
      this.note("You don't own that.");
      return;
    }
    this.weapon = id;
    this.audio.blip();
    this.emit(true);
  }

  private cycleWeapon(dir: number) {
    const list = this.ownedWeapons;
    const i = list.indexOf(this.weapon);
    const n = list[(i + dir + list.length) % list.length];
    if (n) this.weapon = n;
  }

  private buyCar(id: string) {
    const def = CARS.find((c) => c.id === id);
    if (!def) return;
    if (!this.ownedCars.includes(id)) {
      if (this.money < def.price) {
        this.note("That car costs more than you hold.");
        return;
      }
      this.money -= def.price;
      this.ownedCars.push(id);
      this.note(`${def.name} is in the garage.`);
      this.audio.cash();
    }
    this.deliverCar(id);
    this.save();
  }

  private deliverCar(id: string) {
    const def = CARS.find((c) => c.id === id);
    if (!def || !this.ownedCars.includes(id)) return;
    const color = id === "veto" ? this.carColor : def.color;
    this.rebuild(0, def.kind, id === "veto" || id === "sultan" ? color : def.color);
    if (this.phase === "play") {
      this.prepareDrive(0, this.fx + 4, this.fz + 4, this.fyaw);
      this.note(`${def.name} delivered.`);
    }
    this.save();
    this.emit(true);
  }

  private paintCar(color: string) {
    const near = this.phase !== "play" || Math.hypot((this.city.pins.garage?.x ?? 0) - this.fx, (this.city.pins.garage?.z ?? 0) - this.fz) < 16 || this.ownedProps.includes("garage");
    if (this.phase === "play" && !near) {
      this.note("Respray at Hill Garage.");
      return;
    }
    this.carColor = color;
    if (this.vehicles[0]) this.rebuild(0, this.vehicles[0].kind, color);
    this.note("New paint.");
    this.save();
    this.emit(true);
  }

  private rebuild(i: number, kind: CarKind, color: string) {
    const old = this.cars[i];
    if (old) {
      this.scene.remove(old);
      disposeTree(old);
    }
    const mesh = makeCar(kind, color);
    this.scene.add(mesh);
    this.cars[i] = mesh;
    const v = this.vehicles[i];
    if (v) {
      v.kind = kind;
      v.color = color;
    }
  }

  private buyProperty(id: string) {
    const prop = PROPS.find((p) => p.id === id);
    if (!prop) return;
    if (this.ownedProps.includes(id)) {
      this.note("Already yours.");
      return;
    }
    if (this.money < prop.price) {
      this.note("The seller laughs. Come back richer.");
      return;
    }
    this.money -= prop.price;
    this.ownedProps.push(id);
    this.note(`${prop.name} is yours.`);
    this.audio.cash();
    this.save();
    this.emit(true);
  }

  private buyKit(kind: "armor" | "health") {
    const cost = kind === "armor" ? 500 : 200;
    if (this.money < cost) {
      this.note("Not enough cash.");
      return;
    }
    this.money -= cost;
    if (kind === "armor") this.player.armor = 100;
    else this.player.health = 100;
    this.note(kind === "armor" ? "Armor plated." : "Patched.");
    this.save();
    this.emit(true);
  }

  private buyGrenades() {
    if (this.money < 600) {
      this.note("Grenades are $600 a brick.");
      return;
    }
    this.money -= 600;
    this.grenades += 3;
    this.note("+3 grenades.");
    this.save();
    this.emit(true);
  }

  private claimVault() {
    if (Date.now() - this.vaultAt < 20 * 60 * 60 * 1000) {
      this.note("Vault already paid today.");
      return;
    }
    this.vaultAt = Date.now();
    this.money += 1500;
    this.gems += 15;
    this.note("Street cut: $1,500 and 15 gems.");
    this.audio.cash();
    this.save();
    this.emit(true);
  }

  private claimPass() {
    const row = PASS[this.passClaimed];
    if (!row) {
      this.note("Pass is maxed.");
      return;
    }
    if (this.xp < row.xp) {
      this.note("More heat, more pass.");
      return;
    }
    this.money += row.cash;
    this.gems += row.gems;
    this.passClaimed += 1;
    this.note(`Pass: ${row.label}.`);
    this.audio.cash();
    this.save();
    this.emit(true);
  }

  private openCrate() {
    if (this.gems < 40) {
      this.note("Crates take 40 gems.");
      return;
    }
    this.gems -= 40;
    const roll = Math.random();
    if (roll < 0.55) {
      const cash = 800 + Math.floor(Math.random() * 4200);
      this.money += cash;
      this.note(`Crate: $${cash.toLocaleString("en-US")}.`);
    } else if (roll < 0.85) {
      this.grenades += 2;
      this.note("Crate: two grenades.");
    } else {
      this.gems += 70;
      this.note("Crate jackpot: 70 gems.");
    }
    this.audio.cash();
    this.save();
    this.emit(true);
  }

  private setName(name: string) {
    const clean = name.replace(/[^\w \-]/g, "").trim().slice(0, 12);
    if (clean.length < 2) return;
    this.name = clean;
    this.save();
    this.emit(true);
  }

  private cycleRadio() {
    this.station = (this.station + 1) % RADIO.length;
    this.radioOn = true;
    this.note(RADIO[this.station]?.name ?? "Radio");
  }

  private tap(btn: "action" | "weapon" | "grenade" | "crouch" | "radio") {
    if (this.phase !== "play" || this.down || this.paused || this.phone) return;
    if (btn === "action") {
      if (this.driveIndex !== null || this.nearestCar(3.4) >= 0) this.toggleCar();
      else this.useWorld();
    }
    if (btn === "weapon") this.cycleWeapon(1);
    if (btn === "grenade") this.throwNade();
    if (btn === "crouch") this.crouch = !this.crouch;
    if (btn === "radio") this.cycleRadio();
  }

  private note(text: string) {
    this.feed.unshift({ id: this.nid++, text, until: performance.now() + 3400 });
    this.feed = this.feed.slice(0, 4);
    this.emit(true);
  }

  private applyLook() {
    const clock = ((this.minutes % 1440) + 1440) % 1440;
    this.night = this.phase !== "play" || clock >= 20 * 60 || clock < 6 * 60;
    if (this.night) {
      this.renderer.setClearColor(0x070b18);
      this.scene.fog = new THREE.Fog(0x0b1024, 70, 430);
      this.hemi.color.set(0x31456e);
      this.hemi.groundColor.set(0x20150f);
      this.hemi.intensity = 0.9;
      this.sun.color.set(0x9eb6ff);
      this.sun.intensity = 0.55;
      this.windows.visible = true;
      this.bulbs.visible = true;
      this.clouds.visible = false;
    } else {
      this.renderer.setClearColor(0x8fd0ff);
      this.scene.fog = new THREE.Fog(0xc7e8ff, 170, 620);
      this.hemi.color.set(0xd7ecff);
      this.hemi.groundColor.set(0x86c56a);
      this.hemi.intensity = 1.35;
      this.sun.color.set(0xfff3d2);
      this.sun.intensity = 2.4;
      this.windows.visible = false;
      this.bulbs.visible = false;
      this.clouds.visible = true;
    }
    const show = this.phase !== "play";
    this.spotA.intensity = show ? 1100 : 0;
    this.spotB.intensity = show ? 800 : 0;
  }

  private animate(dt: number, now: number) {
    const t = now * 0.001;
    const showRig = this.phase !== "play" || this.driveIndex === null;
    this.rig.root.visible = showRig;
    if (this.phase !== "play") {
      this.rig.root.position.set(0, 0.02, 276);
      this.rig.root.rotation.y = this.lobbyYaw;
      this.poseRig(t, false, false);
      this.shadow.position.set(0, 0.07, 276);
      const bob = this.phase === "load" ? Math.sin(t * 0.35) * 1.4 : 0;
      if (this.phase === "load") this.desired.set(16 + bob, 4.1, 298);
      else this.desired.set(7.2, 2.65, 293.5);
      this.lookV.set(this.phase === "load" ? -1.5 : 0, 1.45, 276);
    } else {
      this.syncFocus();
      const view = this.camYaw + (this.driveIndex !== null ? this.look : 0);
      const dist = this.driveIndex !== null ? 8.4 : this.crouch ? 5.6 : 6.8;
      const height = this.driveIndex !== null ? 3.15 : this.crouch ? 1.35 : 2.25;
      let cx = this.fx + Math.sin(view) * dist;
      let cz = this.fz + Math.cos(view) * dist;
      const clip = this.camClip(this.fx, this.fz, cx, cz);
      cx = clip.x;
      cz = clip.z;
      this.desired.set(cx, height + 0.2, cz);
      this.lookV.set(this.fx, this.driveIndex !== null ? 1.1 : 1.35, this.fz);
      if (showRig) {
        this.rig.root.position.set(this.player.x, 0, this.player.z);
        this.rig.root.rotation.y = this.player.yaw + Math.PI;
        this.poseRig(t, this.player.speed > 0.4, this.crouch);
        this.shadow.position.set(this.player.x, 0.06, this.player.z);
      } else if (this.driveIndex !== null) {
        const v = this.vehicles[this.driveIndex]!;
        this.shadow.position.set(v.x, 0.06, v.z);
      }
    }
    const k = this.snap ? 1 : 1 - Math.exp(-5 * dt);
    this.cam.position.lerp(this.desired, k);
    if (!this.reduce && this.shake > 0.02) {
      this.cam.position.x += (Math.random() - 0.5) * this.shake * 0.35;
      this.cam.position.y += (Math.random() - 0.5) * this.shake * 0.25;
    }
    this.shake *= Math.exp(-2.8 * dt);
    this.pain = Math.max(0, this.pain - dt * 0.85);
    this.cam.lookAt(this.lookV);
    this.snap = false;
    this.rotor.rotation.y += dt * 18;
    this.heli.visible = this.heliOn && this.phase === "play";
    this.heli.position.set(this.heliX, 26, this.heliZ);
    this.heli.rotation.y = this.heliYaw + Math.PI;
    if (this.blast.visible) {
      const s = this.blast.scale.x + dt * 8;
      this.blast.scale.setScalar(s);
      const mat = this.blast.material as THREE.MeshBasicMaterial;
      mat.opacity -= dt * 1.4;
      if (mat.opacity <= 0) this.blast.visible = false;
    }
    this.vehicles.forEach((v, i) => {
      const mesh = this.cars[i];
      if (!mesh) return;
      mesh.visible = v.alive;
      mesh.position.set(v.x, 0, v.z);
      mesh.rotation.y = v.yaw + Math.PI;
      const night = this.night;
      mesh.traverse((obj) => {
        if (obj.name === "wheel") obj.rotation.x = v.spin;
        if (obj.name === "head") {
          const mat = (obj as THREE.Mesh).material as THREE.MeshStandardMaterial;
          mat.emissiveIntensity = night && v.alive ? 1.5 : 0.2;
        }
        if (obj.name === "sirenR" || obj.name === "sirenB") {
          const on = v.role === "cop" && this.stars > 0 && v.alive;
          const mat = (obj as THREE.Mesh).material as THREE.MeshStandardMaterial;
          const blink = Math.sin(t * 18) > 0;
          const mine = obj.name === "sirenR" ? blink : !blink;
          mat.emissiveIntensity = on && mine ? 2.2 : 0.05;
        }
      });
    });
    this.syncPeds();
    const mark = this.phase === "play" ? this.markerPos() : null;
    this.marker.visible = !!mark;
    if (mark) {
      this.marker.position.set(mark.x, 8, mark.z);
      this.marker.rotation.y += dt;
    }
    if (this.phase === "play") {
      this.drawMini();
      if (this.phone) this.drawPhone();
    }
    const inCar = this.phase === "play" && this.driveIndex !== null && !this.paused && !this.phone;
    this.audio.engine(Math.abs(this.fspeed), inCar);
    this.audio.siren(this.phase === "play" && this.stars > 0 && !this.paused);
    if (inCar && this.radioOn) {
      this.radioT += dt;
      if (this.radioT > 0.23) {
        this.radioT = 0;
        const beat = BEATS[this.station] ?? BEATS[0]!;
        const f = beat[this.radioStep % beat.length] ?? 220;
        this.audio.radioNote(f, this.radioStep % 4 === 0);
        this.radioStep++;
      }
    }
  }

  private poseRig(t: number, moving: boolean, crouch: boolean) {
    const swing = moving ? Math.sin(t * 9) : 0;
    this.rig.legL.rotation.x = swing * 0.7;
    this.rig.legR.rotation.x = -swing * 0.7;
    this.rig.armL.rotation.x = moving ? -swing * 0.55 : 0.2;
    this.rig.armR.rotation.x = moving ? 0.35 + swing * 0.25 : 0.55;
    this.rig.bob.position.y = (moving ? Math.abs(Math.sin(t * 9)) * 0.05 : Math.sin(t * 2) * 0.02) + (crouch ? -0.28 : 0);
  }

  private camClip(x1: number, z1: number, x2: number, z2: number) {
    const dx = x2 - x1;
    const dz = z2 - z1;
    const dist = Math.hypot(dx, dz);
    const steps = Math.max(1, Math.ceil(dist / 1.5));
    for (let i = 1; i <= steps; i++) {
      const x = x1 + (dx * i) / steps;
      const z = z1 + (dz * i) / steps;
      if (this.blocked(x, z, 0.35)) {
        const k = Math.max(0, (i - 1) / steps);
        return { x: x1 + dx * k, z: z1 + dz * k };
      }
    }
    return { x: x2, z: z2 };
  }

  private syncPeds() {
    const all = [...this.civs, ...this.gangs];
    const shirts = ["#ff6b6b", "#ffd166", "#7bdff2", "#f7aef8", "#b8f2a2", "#ffe8a3", "#90e0ef", "#cdb4db"];
    for (let i = 0; i < CIV + GANG; i++) {
      const p = all[i];
      if (!p || !p.alive) {
        this.dummy.position.set(0, -20, 0);
        this.dummy.scale.set(0, 0, 0);
        this.dummy.rotation.set(0, 0, 0);
        this.dummy.updateMatrix();
        this.pedBody.setMatrixAt(i, this.dummy.matrix);
        this.pedHead.setMatrixAt(i, this.dummy.matrix);
        continue;
      }
      const dead = p.state === "dead";
      const bob = dead ? 0 : Math.abs(Math.sin(p.walk * 8)) * 0.04;
      this.dummy.position.set(p.x, (dead ? 0.35 : 0.95) + bob, p.z);
      this.dummy.rotation.set(dead ? 1.1 : 0, p.yaw + Math.PI, 0);
      this.dummy.scale.set(1, dead ? 0.45 : 1, 1);
      this.dummy.updateMatrix();
      this.pedBody.setMatrixAt(i, this.dummy.matrix);
      const shirt = p.kind === "gang" ? new THREE.Color("#8f1d2c") : new THREE.Color(shirts[i % shirts.length]!);
      this.pedBody.setColorAt(i, shirt);
      this.dummy.position.y += dead ? 0.2 : 0.55;
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      this.pedHead.setMatrixAt(i, this.dummy.matrix);
    }
    this.pedBody.instanceMatrix.needsUpdate = true;
    this.pedHead.instanceMatrix.needsUpdate = true;
    if (this.pedBody.instanceColor) this.pedBody.instanceColor.needsUpdate = true;
  }

  private drawPoster() {
    const ctx = this.opts.poster.getContext("2d");
    if (!ctx) return;
    const w = this.opts.poster.width;
    const h = this.opts.poster.height;
    ctx.drawImage(this.city.map, 0, 0, w, h);
  }

  private drawMini() {
    const ctx = this.opts.mini.getContext("2d");
    if (!ctx) return;
    const w = this.opts.mini.width;
    const h = this.opts.mini.height;
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = "#163024";
    ctx.fillRect(0, 0, w, h);
    ctx.translate(w / 2, h / 2);
    const scale = 1.25;
    const s = Math.sin(this.camYaw);
    const c = Math.cos(this.camYaw);
    const proj = (x: number, z: number) => {
      const dx = x - this.fx;
      const dz = z - this.fz;
      return [(dx * c - dz * s) * scale, (dx * s + dz * c) * scale];
    };
    ctx.lineWidth = 5;
    ctx.strokeStyle = "#3c4454";
    ctx.beginPath();
    for (const r of this.city.vRoads) {
      const [x1, y1] = proj(r.x, r.z1);
      const [x2, y2] = proj(r.x, r.z2);
      ctx.moveTo(x1!, y1!);
      ctx.lineTo(x2!, y2!);
    }
    for (const r of this.city.hRoads) {
      const [x1, y1] = proj(r.x1, r.z);
      const [x2, y2] = proj(r.x2, r.z);
      ctx.moveTo(x1!, y1!);
      ctx.lineTo(x2!, y2!);
    }
    ctx.stroke();
    ctx.fillStyle = "#ffb15a";
    for (const b of this.city.buildings) {
      if (Math.hypot(b.x - this.fx, b.z - this.fz) > 130) continue;
      const [x, y] = proj(b.x, b.z);
      ctx.fillRect(x! - 2.5, y! - 2.5, 5, 5);
    }
    for (const v of this.vehicles) {
      if (!v.alive) continue;
      const [x, y] = proj(v.x, v.z);
      ctx.fillStyle = v.role === "cop" ? "#ff4d4d" : "#f4f4f4";
      ctx.fillRect(x! - 2, y! - 2, 4, 4);
    }
    const mark = this.markerPos();
    if (mark) {
      const [x, y] = proj(mark.x, mark.z);
      ctx.fillStyle = "#f5b301";
      ctx.beginPath();
      ctx.arc(x!, y!, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "#f5b301";
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(6, 7);
    ctx.lineTo(-6, 7);
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = "rgba(243,239,230,0.7)";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 3, 0, Math.PI * 2);
    ctx.stroke();
  }

  private drawPhone() {
    const ctx = this.opts.phoneMap.getContext("2d");
    if (!ctx) return;
    const w = this.opts.phoneMap.width;
    const h = this.opts.phoneMap.height;
    ctx.drawImage(this.city.map, 0, 0, w, h);
    const tx = (x: number) => ((x + WORLD) / (WORLD * 2)) * w;
    const ty = (z: number) => ((WORLD - z) / (WORLD * 2)) * h;
    const mark = this.markerPos();
    if (mark) {
      ctx.fillStyle = "#f5b301";
      ctx.beginPath();
      ctx.arc(tx(mark.x), ty(mark.z), 6, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "#ff4d2e";
    ctx.beginPath();
    ctx.moveTo(tx(this.fx), ty(this.fz) - 7);
    ctx.lineTo(tx(this.fx) + 5, ty(this.fz) + 6);
    ctx.lineTo(tx(this.fx) - 5, ty(this.fz) + 6);
    ctx.fill();
  }

  private resize() {
    const w = this.opts.canvas.clientWidth || window.innerWidth;
    const h = this.opts.canvas.clientHeight || window.innerHeight;
    if (w < 2 || h < 2) return;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, w < 740 ? 1.25 : 1.6));
    this.renderer.setSize(w, h, false);
    this.cam.aspect = w / h;
    this.cam.updateProjectionMatrix();
  }

  private weaponName() {
    return WEAPONS.find((w) => w.id === this.weapon)?.name ?? "Fists";
  }

  private snapshot(): HudState {
    const spec = WEAPONS.find((w) => w.id === this.weapon);
    const step = this.run?.steps[this.run.step];
    const notes: Note[] = this.feed.map((n) => ({ id: n.id, text: n.text }));
    const car = this.driveIndex !== null ? this.vehicles[this.driveIndex] : undefined;
    return {
      phase: this.phase,
      load: this.load,
      tip: this.tip,
      name: this.name,
      rank: 34,
      money: Math.floor(this.money),
      gems: Math.floor(this.gems),
      health: clamp(this.player.health, 0, 100),
      armor: clamp(this.player.armor, 0, 100),
      stars: this.stars,
      weapon: this.weapon,
      weaponName: this.weaponName(),
      mag: spec && spec.mag > 0 ? (this.mags[this.weapon] ?? 0) : 0,
      reserve: spec && spec.mag > 0 ? (this.reserve[this.weapon] ?? 0) : 0,
      grenades: this.grenades,
      inCar: this.driveIndex !== null,
      carName: car ? (CARS.find((c) => c.kind === car.kind)?.name ?? car.kind) : "On foot",
      speed: Math.abs(this.fspeed),
      district: districtAt(this.fx, this.fz),
      clock: clockString(this.phase === "play" ? this.minutes : 21 * 60),
      radio: RADIO[this.station]?.name ?? "NEON FM",
      radioOn: this.radioOn,
      outfit: this.outfit,
      ownedWeapons: [...this.ownedWeapons],
      ownedCars: [...this.ownedCars],
      ownedProps: [...this.ownedProps],
      carColor: this.carColor,
      missionsDone: [...this.missionsDone],
      xp: this.xp,
      passClaimed: this.passClaimed,
      missionName: this.run?.name ?? "",
      objective: step?.text ?? "",
      hold: this.hold01(),
      notes,
      hint: this.hintT > 0 ? this.hint : "",
      interact: this.phase === "play" && !this.paused && !this.phone ? this.interact : "",
      paused: this.paused,
      phone: this.phone,
      down: this.down,
      pain: this.pain,
      mode: this.mode,
      volume: this.audio.volume,
      muted: this.audio.muted,
      crouch: this.crouch,
      raceLap: step?.kind === "race" && this.run ? `Lap ${Math.min(step.laps, this.run.lap + 1)}/${step.laps}` : "",
      bestRace: this.bestRace,
      vaultReady: Date.now() - this.vaultAt > 20 * 60 * 60 * 1000,
      ownedOutfits: [...this.ownedFits],
    };
  }

  private emit(force: boolean) {
    const now = performance.now();
    if (!force && now - this.lastEmit < 140) return;
    this.lastEmit = now;
    this.opts.onHud(this.snapshot());
  }

  private destroy() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.opts.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("wheel", this.onWheel);
    this.audio.close();
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
    });
    this.renderer.dispose();
    if (window.__controlsTest) delete window.__controlsTest;
  }
}

function makeLabel(text: string) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 64;
  const g = c.getContext("2d");
  if (!g) return new THREE.Sprite();
  g.fillStyle = "#12141c";
  g.fillRect(0, 0, 256, 64);
  g.strokeStyle = "#f5b301";
  g.lineWidth = 4;
  g.strokeRect(3, 3, 250, 58);
  g.fillStyle = "#f3efe6";
  g.font = "700 26px sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text, 128, 34);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  s.scale.set(10, 2.5, 1);
  return s;
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}
