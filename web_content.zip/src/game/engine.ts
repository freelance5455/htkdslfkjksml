import type { BufferGeometry, Material, Mesh, MeshBasicMaterial, MeshStandardMaterial, Object3D } from "three";
import { COOK, CUSTOMERS, ING_HEX, ING_LABEL, dayGoal, daySeconds, patienceSeconds, recipesForDay } from "./content";
import { getHud, setHud } from "./hud";
import { bindApi, input, radialDeadzone } from "./input";
import type { CookChip, CookId, HudSnap, Ing, Phase, StationId, ToastTone } from "./types";

type Probe = {
  getYaw: () => number;
  getPitch: () => number;
  getSpeed: () => number;
  getPos: () => { x: number; z: number };
  getPlate: () => Ing[];
  setKeys: (codes: string[]) => void;
  setYaw: (yaw: number) => void;
  setPos: (x: number, z: number) => void;
  addLook: (dx: number, dy: number) => void;
  use: () => void;
};

declare global {
  interface Window {
    __controlsTest?: Probe;
    __shawarmaReady?: boolean;
  }
}

const EYE = 1.58;
const WALK = 3.35;
const RADIUS = 0.28;
const PITCH_LIMIT = Math.PI / 2 - 0.08;
const COOK_IDS: CookId[] = ["grill", "chop", "oven"];
const SAVE_KEY = "shawarma-legend-v1";

type Save = { version: 1; bestDay: number; bestMoney: number; muted: boolean };
type AABB = { minX: number; maxX: number; minZ: number; maxZ: number };
type Job = { t: number; dur: number; ready: boolean; dinged: boolean };
type Stand = { id: StationId; x: number; z: number; reach: number };

const STANDS: Stand[] = [
  { id: "bread", x: 0, z: -2.95, reach: 1.35 },
  { id: "grill", x: -3.45, z: -1.05, reach: 1.4 },
  { id: "oven", x: 3.45, z: -1.05, reach: 1.4 },
  { id: "chop", x: -3.45, z: 1.7, reach: 1.4 },
  { id: "sauce", x: 3.45, z: 1.7, reach: 1.4 },
  { id: "trash", x: -4.05, z: 3.2, reach: 1.35 },
];

const GAME_KEYS = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Space",
  "KeyE",
  "Escape",
]);

function loadSave(): Save {
  const blank: Save = { version: 1, bestDay: 0, bestMoney: 0, muted: false };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return blank;
    const parsed = JSON.parse(raw) as Partial<Save>;
    if (parsed.version !== 1) return blank;
    return {
      version: 1,
      bestDay: Number(parsed.bestDay) || 0,
      bestMoney: Number(parsed.bestMoney) || 0,
      muted: Boolean(parsed.muted),
    };
  } catch {
    return blank;
  }
}

function approach(cur: number, target: number, maxDelta: number): number {
  const d = target - cur;
  if (Math.abs(d) <= maxDelta) return target;
  return cur + Math.sign(d) * maxDelta;
}

export function mountGame(canvas: HTMLCanvasElement): () => void {
  let disposed = false;
  let stop = () => {};
  void import("three")
    .then((mod) => {
      if (!disposed) start(mod);
    })
    .catch(() => {
      const hud = getHud();
      setHud({ ...hud, booted: true, detail: "This device couldn't start the 3D shop." });
    });

  function start(THREE: typeof import("three")): void {
    if (disposed) return;

    const save = loadSave();
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setClearColor(0xf2c9a0, 1);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xf2c9a0, 14, 26);
    const camera = new THREE.PerspectiveCamera(72, 1, 0.08, 40);
    const rig = new THREE.Group();
    rig.add(camera);
    scene.add(rig);

    const geos: BufferGeometry[] = [];
    const materials: Material[] = [];
    const matCache = new Map<string, MeshStandardMaterial>();
    const solids: AABB[] = [];

    const trackGeo = <T extends BufferGeometry>(g: T): T => {
      geos.push(g);
      return g;
    };
    const std = (color: number, roughness = 0.76, metalness = 0.04) => {
      const key = `${color}|${roughness}|${metalness}`;
      const hit = matCache.get(key);
      if (hit) return hit;
      const material = new THREE.MeshStandardMaterial({ color, roughness, metalness });
      matCache.set(key, material);
      materials.push(material);
      return material;
    };
    const own = <T extends Material>(material: T): T => {
      materials.push(material);
      return material;
    };

    const box = trackGeo(new THREE.BoxGeometry(1, 1, 1));
    const cyl = trackGeo(new THREE.CylinderGeometry(1, 1, 1, 18));
    const sph = trackGeo(new THREE.SphereGeometry(1, 18, 14));
    const cone = trackGeo(new THREE.ConeGeometry(1, 1, 14));

    function addBox(
      w: number,
      h: number,
      d: number,
      color: number,
      x: number,
      y: number,
      z: number,
      opts?: { solid?: boolean; rough?: number; metal?: number; cast?: boolean; receive?: boolean },
    ) {
      const mesh = new THREE.Mesh(box, std(color, opts?.rough, opts?.metal));
      mesh.scale.set(w, h, d);
      mesh.position.set(x, y, z);
      mesh.castShadow = Boolean(opts?.cast);
      mesh.receiveShadow = opts?.receive !== false;
      scene.add(mesh);
      if (opts?.solid) {
        solids.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
      }
      return mesh;
    }

    function makeSign(text: string) {
      const c = document.createElement("canvas");
      c.width = 256;
      c.height = 128;
      const g = c.getContext("2d");
      if (!g) return new THREE.Sprite(own(new THREE.SpriteMaterial({ color: 0xffffff })));
      g.fillStyle = "rgba(42, 22, 12, 0.92)";
      g.beginPath();
      g.roundRect(12, 18, 232, 92, 28);
      g.fill();
      g.fillStyle = "#f6ead7";
      g.font = "700 46px sans-serif";
      g.textAlign = "center";
      g.textBaseline = "middle";
      g.fillText(text, 128, 64);
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      const mat = own(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
      const sprite = new THREE.Sprite(mat);
      sprite.scale.set(1.05, 0.52, 1);
      return sprite;
    }

    const floorCanvas = document.createElement("canvas");
    floorCanvas.width = 128;
    floorCanvas.height = 128;
    const floorCtx = floorCanvas.getContext("2d");
    if (floorCtx) {
      for (let y = 0; y < 4; y++) {
        for (let x = 0; x < 4; x++) {
          floorCtx.fillStyle = (x + y) % 2 === 0 ? "#c9a36d" : "#b48958";
          floorCtx.fillRect(x * 32, y * 32, 32, 32);
        }
      }
    }
    const floorTex = new THREE.CanvasTexture(floorCanvas);
    floorTex.colorSpace = THREE.SRGBColorSpace;
    floorTex.wrapS = THREE.RepeatWrapping;
    floorTex.wrapT = THREE.RepeatWrapping;
    floorTex.repeat.set(6, 5);
    const floorMat = own(new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.92 }));
    const floor = new THREE.Mesh(box, floorMat);
    floor.scale.set(12.8, 0.12, 10.2);
    floor.position.set(0, -0.06, 0.15);
    floor.receiveShadow = true;
    scene.add(floor);

    addBox(14, 0.1, 5, 0xe4cfae, 0, -0.04, 7.6, { receive: true, rough: 0.95 });
    addBox(12.9, 3.2, 0.36, 0xf3e6d2, 0, 1.6, -4.85, { solid: true, cast: true });
    addBox(0.36, 3.2, 10.4, 0xf3e6d2, -6.45, 1.6, 0.25, { solid: true, cast: true });
    addBox(0.36, 3.2, 10.4, 0xf3e6d2, 6.45, 1.6, 0.25, { solid: true, cast: true });
    addBox(5.05, 3.2, 0.32, 0xf3e6d2, -3.85, 1.6, 5.38, { solid: true, cast: true });
    addBox(5.05, 3.2, 0.32, 0xf3e6d2, 3.85, 1.6, 5.38, { solid: true, cast: true });
    addBox(2.55, 1.05, 0.32, 0xf3e6d2, 0, 2.68, 5.38, { solid: true });
    addBox(2.55, 0.95, 0.32, 0x6b3e2a, 0, 0.48, 5.38, { solid: true });

    const glassMat = own(
      new THREE.MeshStandardMaterial({
        color: 0xcfe8f2,
        transparent: true,
        opacity: 0.18,
        roughness: 0.05,
        metalness: 0.1,
        depthWrite: false,
      }),
    );
    const glass = new THREE.Mesh(box, glassMat);
    glass.scale.set(2.4, 1.2, 0.04);
    glass.position.set(0, 1.55, 5.22);
    scene.add(glass);

    for (let i = 0; i < 6; i++) {
      addBox(0.42, 0.08, 0.7, i % 2 === 0 ? 0xe15a3a : 0xf6ead7, -1.25 + i * 0.42, 2.42, 5.85, { cast: true, receive: false });
    }

    const ceiling = addBox(12.8, 0.12, 10.2, 0xe7d5c0, 0, 3.2, 0.15, { receive: false });
    ceiling.castShadow = false;

    addBox(7.2, 0.96, 0.95, 0x8a5a32, 0, 0.48, -4.08, { solid: true, cast: true, rough: 0.72 });
    addBox(7.2, 0.08, 1.02, 0xc48955, 0, 1.0, -4.08, { cast: true, rough: 0.6 });
    addBox(12.4, 0.96, 0.95, 0x8a5a32, 0, 0.48, 4.62, { solid: true, cast: true, rough: 0.72 });
    addBox(12.4, 0.08, 1.02, 0xc48955, 0, 1.0, 4.62, { cast: true, rough: 0.6 });
    addBox(1.15, 0.9, 1.3, 0x3e444c, -4.7, 0.45, -1.05, { solid: true, cast: true, metal: 0.45, rough: 0.4 });
    addBox(1.2, 1.15, 1.25, 0x4a403c, 4.7, 0.58, -1.05, { solid: true, cast: true, rough: 0.7 });
    addBox(1.35, 0.86, 1.05, 0xa56b3c, -4.75, 0.43, 1.7, { solid: true, cast: true });
    addBox(1.35, 0.86, 1.05, 0xa56b3c, 4.75, 0.43, 1.7, { solid: true, cast: true });

    const trashCan = new THREE.Mesh(cyl, std(0x3a4148, 0.45, 0.35));
    trashCan.scale.set(0.28, 0.62, 0.28);
    trashCan.position.set(-4.85, 0.31, 3.2);
    trashCan.castShadow = true;
    scene.add(trashCan);
    solids.push({ minX: -5.2, maxX: -4.5, minZ: 2.88, maxZ: 3.52 });

    const spit = new THREE.Group();
    spit.position.set(-4.7, 0, -1.05);
    scene.add(spit);
    const pole = new THREE.Mesh(cyl, std(0x2c3136, 0.35, 0.7));
    pole.scale.set(0.06, 1.7, 0.06);
    pole.position.y = 1.15;
    spit.add(pole);
    const meatMat = own(new THREE.MeshStandardMaterial({ color: 0x7a3b28, roughness: 0.62 }));
    for (let i = 0; i < 5; i++) {
      const layer = new THREE.Mesh(cyl, meatMat);
      const r = 0.3 - i * 0.025;
      layer.scale.set(r, 0.14, r);
      layer.position.y = 0.72 + i * 0.15;
      layer.castShadow = true;
      spit.add(layer);
    }
    const flameMat = own(new THREE.MeshBasicMaterial({ color: 0xff7a2a }));
    const flame = new THREE.Mesh(cone, flameMat);
    flame.scale.set(0.16, 0.28, 0.16);
    flame.position.y = 0.2;
    spit.add(flame);

    const ovenGlowMat = own(new THREE.MeshBasicMaterial({ color: 0x2a120c }));
    const ovenGlow = new THREE.Mesh(box, ovenGlowMat);
    ovenGlow.scale.set(0.7, 0.55, 0.06);
    ovenGlow.position.set(4.7, 0.72, -0.42);
    scene.add(ovenGlow);

    const leafMat = own(new THREE.MeshStandardMaterial({ color: 0x3f8f5a, roughness: 0.55 }));
    const chopLeaf = new THREE.Mesh(sph, leafMat);
    chopLeaf.scale.set(0.22, 0.08, 0.16);
    chopLeaf.position.set(-4.75, 0.92, 1.7);
    scene.add(chopLeaf);
    const knife = addBox(0.06, 0.04, 0.42, 0xd5d8dc, -4.45, 0.9, 1.55, { cast: true, metal: 0.6, rough: 0.25, receive: false });

    const bottle = new THREE.Mesh(cyl, std(0xf6ead7, 0.35, 0.05));
    bottle.scale.set(0.1, 0.38, 0.1);
    bottle.position.set(4.75, 1.05, 1.7);
    bottle.castShadow = true;
    scene.add(bottle);
    const sauceTop = new THREE.Mesh(sph, std(0xd64545, 0.4, 0.05));
    sauceTop.scale.set(0.1, 0.1, 0.1);
    sauceTop.position.set(4.75, 1.28, 1.7);
    scene.add(sauceTop);

    const breadMat = std(0xe6c48a, 0.7, 0.02);
    for (let i = 0; i < 4; i++) {
      const loaf = new THREE.Mesh(cyl, breadMat);
      loaf.scale.set(0.2, 0.045, 0.2);
      loaf.position.set(-0.15 + (i % 2) * 0.28, 1.08 + Math.floor(i / 2) * 0.05, -4.05);
      loaf.castShadow = true;
      scene.add(loaf);
    }
    for (let i = 0; i < 3; i++) {
      const jar = new THREE.Mesh(cyl, std(i === 1 ? 0xc46b4a : 0xf0c14a, 0.4, 0.08));
      jar.scale.set(0.1, 0.24, 0.1);
      jar.position.set(1.3 + i * 0.32, 1.16, -4.08);
      jar.castShadow = true;
      scene.add(jar);
    }

    const signs: Array<[string, number, number, number]> = [
      ["BREAD", 0, 1.85, -3.55],
      ["GRILL", -4.7, 2.15, -1.05],
      ["OVEN", 4.7, 2.15, -1.05],
      ["CHOP", -4.75, 1.75, 1.7],
      ["SAUCE", 4.75, 1.75, 1.7],
      ["TRASH", -4.85, 1.35, 3.2],
      ["SERVE", 0, 1.45, 4.05],
    ];
    for (const [label, x, y, z] of signs) {
      const sprite = makeSign(label);
      sprite.position.set(x, y, z);
      scene.add(sprite);
    }

    addBox(0.9, 0.025, 0.55, 0xe6c48a, 0, 0.02, -2.85, { receive: true });
    addBox(0.7, 0.025, 0.7, 0x8a4030, -3.45, 0.02, -1.05, { receive: true });
    addBox(0.7, 0.025, 0.7, 0xf0c14a, 3.45, 0.02, -1.05, { receive: true });
    addBox(0.7, 0.025, 0.7, 0x3f8f5a, -3.45, 0.02, 1.7, { receive: true });
    addBox(0.7, 0.025, 0.7, 0xd64545, 3.45, 0.02, 1.7, { receive: true });
    addBox(1.5, 0.025, 0.55, 0xe15a3a, 0, 0.02, 3.45, { receive: true });

    const plateGroup = new THREE.Group();
    plateGroup.position.set(0, 1.045, 4.28);
    scene.add(plateGroup);
    const plateBase = new THREE.Mesh(cyl, std(0xf7f3ec, 0.42, 0.05));
    plateBase.scale.set(0.28, 0.04, 0.28);
    plateBase.position.y = 0.02;
    plateBase.castShadow = true;
    plateGroup.add(plateBase);
    const stack = new THREE.Group();
    plateGroup.add(stack);
    const ingMaterials: Record<Ing, MeshStandardMaterial> = {
      bread: std(ING_HEX.bread, 0.7, 0.02),
      meat: std(ING_HEX.meat, 0.55, 0.04),
      veg: std(ING_HEX.veg, 0.55, 0.02),
      cheese: std(ING_HEX.cheese, 0.48, 0.05),
      sauce: std(ING_HEX.sauce, 0.35, 0.08),
    };

    const boardCanvas = document.createElement("canvas");
    boardCanvas.width = 960;
    boardCanvas.height = 240;
    const boardTex = new THREE.CanvasTexture(boardCanvas);
    boardTex.colorSpace = THREE.SRGBColorSpace;
    const board = new THREE.Mesh(
      trackGeo(new THREE.PlaneGeometry(1, 1)),
      own(new THREE.MeshBasicMaterial({ map: boardTex })),
    );
    board.scale.set(2.4, 0.6, 1);
    board.position.set(0, 2.32, 5.16);
    board.rotation.y = Math.PI;
    scene.add(board);

    const customer = new THREE.Group();
    customer.position.set(0, 0, 6.15);
    customer.rotation.y = Math.PI;
    scene.add(customer);
    const skin = std(0xf0c7a4, 0.7, 0.02);
    const shirtMat = own(new THREE.MeshStandardMaterial({ color: 0x3d7ea6, roughness: 0.62 }));
    const hairMat = own(new THREE.MeshStandardMaterial({ color: 0x2a2118, roughness: 0.75 }));
    const pants = std(0x2c3338, 0.8, 0.02);
    const body = new THREE.Mesh(box, shirtMat);
    body.scale.set(0.46, 0.5, 0.28);
    body.position.y = 0.95;
    body.castShadow = true;
    customer.add(body);
    const head = new THREE.Mesh(sph, skin);
    head.scale.set(0.2, 0.22, 0.2);
    head.position.y = 1.38;
    head.castShadow = true;
    customer.add(head);
    const hair = new THREE.Mesh(sph, hairMat);
    hair.scale.set(0.21, 0.14, 0.21);
    hair.position.y = 1.5;
    customer.add(hair);
    const eyeMat = own(new THREE.MeshBasicMaterial({ color: 0x1c1a17 }));
    for (const ex of [-0.07, 0.07]) {
      const eye = new THREE.Mesh(sph, eyeMat);
      eye.scale.set(0.028, 0.032, 0.028);
      eye.position.set(ex, 1.4, 0.16);
      customer.add(eye);
    }
    const smile = new THREE.Mesh(box, eyeMat);
    smile.scale.set(0.09, 0.02, 0.02);
    smile.position.set(0, 1.3, 0.17);
    customer.add(smile);
    for (const lx of [-0.12, 0.12]) {
      const leg = new THREE.Mesh(box, pants);
      leg.scale.set(0.12, 0.42, 0.14);
      leg.position.set(lx, 0.42, 0);
      leg.castShadow = true;
      customer.add(leg);
    }
    const barBg = new THREE.Mesh(box, own(new THREE.MeshBasicMaterial({ color: 0x2a2118 })));
    barBg.scale.set(0.62, 0.07, 0.02);
    barBg.position.set(0, 1.78, 0);
    customer.add(barBg);
    const barFill = new THREE.Mesh(box, own(new THREE.MeshBasicMaterial({ color: 0x3cba7a })));
    barFill.scale.set(0.58, 0.045, 0.03);
    barFill.position.set(0, 1.78, 0.01);
    customer.add(barFill);

    const ring = new THREE.Mesh(
      trackGeo(new THREE.RingGeometry(0.34, 0.42, 28)),
      own(new THREE.MeshBasicMaterial({ color: 0xf0a04b, side: THREE.DoubleSide, transparent: true, opacity: 0.95 })),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.035;
    ring.visible = false;
    scene.add(ring);

    const hemi = new THREE.HemisphereLight(0xffe6cc, 0x8a6244, 0.72);
    scene.add(hemi);
    scene.add(new THREE.AmbientLight(0xfff3e4, 0.28));
    const dir = new THREE.DirectionalLight(0xfff1dd, 1.2);
    dir.position.set(-3.5, 8.5, 6.5);
    dir.castShadow = true;
    dir.shadow.mapSize.set(1024, 1024);
    dir.shadow.camera.left = -12;
    dir.shadow.camera.right = 12;
    dir.shadow.camera.top = 12;
    dir.shadow.camera.bottom = -12;
    dir.shadow.camera.near = 0.5;
    dir.shadow.camera.far = 28;
    dir.shadow.bias = -0.0006;
    dir.shadow.normalBias = 0.04;
    scene.add(dir);
    scene.add(dir.target);
    dir.target.position.set(0, 0.8, 1);
    const pendant = (x: number, z: number) => {
      const cord = new THREE.Mesh(cyl, std(0x2a2118, 0.6, 0.1));
      cord.scale.set(0.02, 0.45, 0.02);
      cord.position.set(x, 2.95, z);
      scene.add(cord);
      const bulbMat = own(new THREE.MeshBasicMaterial({ color: 0xffe1b0 }));
      const bulb = new THREE.Mesh(sph, bulbMat);
      bulb.scale.set(0.1, 0.1, 0.1);
      bulb.position.set(x, 2.68, z);
      scene.add(bulb);
      const light = new THREE.PointLight(0xffc98a, 0.55, 6.5, 2);
      light.position.set(x, 2.6, z);
      scene.add(light);
    };
    pendant(-1.4, 0.2);
    pendant(1.5, 2.4);
    const grillLight = new THREE.PointLight(0xff7a2a, 0.15, 4.5, 2);
    grillLight.position.set(-4.7, 0.6, -0.7);
    scene.add(grillLight);
    const windowLight = new THREE.PointLight(0xffe2c4, 0.85, 9, 2);
    windowLight.position.set(0, 2.15, 3.6);
    scene.add(windowLight);

    const keys = new Set<string>();
    let forced: Set<string> | null = null;
    let prevUse = false;
    let prevEsc = false;
    let padA = false;

    let phase: Phase = "menu";
    let day = 1;
    let money = 0;
    let goal = dayGoal(1);
    let timeLeft = daySeconds(1);
    let bestDay = save.bestDay;
    let bestMoney = save.bestMoney;
    let muted = save.muted;
    let plate: Ing[] = [];
    let plateSig = "";
    let order: Ing[] = [];
    let recipeName = "";
    let price = 0;
    let customerName = "";
    let customerHere = false;
    let patience = 1;
    let patienceDur = patienceSeconds(1);
    let lastRecipe = "";
    let firstOrder = true;
    let gap = 0;
    let mood: "idle" | "happy" | "mad" = "idle";
    let moodT = 0;
    let popT = 1;
    let cooldown = 0;
    let toast = "";
    let toastTone: ToastTone = "info";
    let toastT = 0;
    let hints = false;
    let hintT = 0;
    let shake = 0;
    let bob = 0;
    let animT = 0;
    let menuT = 0;
    let currentTarget: StationId | null = null;
    let dirty = true;
    let hudAcc = 0;
    const jobs: Record<CookId, Job | null> = { grill: null, chop: null, oven: null };

    const pos = { x: 0, z: 1.5 };
    let yaw = Math.PI;
    let pitch = -0.2;
    let velX = 0;
    let velZ = 0;

    let actx: AudioContext | null = null;
    function unlockAudio() {
      if (muted) return;
      if (!actx) actx = new AudioContext();
      if (actx.state === "suspended") void actx.resume();
    }
    function tone(freq: number, dur: number, when: number, gain: number) {
      if (!actx || muted) return;
      const osc = actx.createOscillator();
      const amp = actx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      amp.gain.setValueAtTime(gain, when);
      amp.gain.exponentialRampToValueAtTime(0.0001, when + dur);
      osc.connect(amp);
      amp.connect(actx.destination);
      osc.start(when);
      osc.stop(when + dur + 0.02);
    }
    function chime(kind: "pop" | "ready" | "serve" | "bad" | "leave") {
      unlockAudio();
      if (!actx || muted) return;
      const t = actx.currentTime;
      if (kind === "pop") tone(540, 0.07, t, 0.045);
      if (kind === "ready") {
        tone(660, 0.09, t, 0.05);
        tone(880, 0.12, t + 0.08, 0.045);
      }
      if (kind === "serve") {
        tone(523, 0.11, t, 0.05);
        tone(659, 0.11, t + 0.09, 0.05);
        tone(784, 0.16, t + 0.18, 0.05);
      }
      if (kind === "bad") tone(196, 0.18, t, 0.04);
      if (kind === "leave") {
        tone(392, 0.1, t, 0.04);
        tone(262, 0.16, t + 0.09, 0.04);
      }
    }

    function persist() {
      const next: Save = { version: 1, bestDay, bestMoney, muted };
      try {
        localStorage.setItem(SAVE_KEY, JSON.stringify(next));
      } catch {
        /* ignore full or blocked storage */
      }
    }

    function say(text: string, tone: ToastTone) {
      toast = text;
      toastTone = tone;
      toastT = 1.7;
      dirty = true;
    }

    function sameBag(a: Ing[], b: Ing[]) {
      if (a.length !== b.length) return false;
      const counts = new Map<string, number>();
      for (const item of a) counts.set(item, (counts.get(item) ?? 0) + 1);
      for (const item of b) {
        const left = counts.get(item) ?? 0;
        if (left <= 0) return false;
        counts.set(item, left - 1);
      }
      return true;
    }

    function redrawBoard() {
      const g = boardCanvas.getContext("2d");
      if (!g) return;
      g.clearRect(0, 0, boardCanvas.width, boardCanvas.height);
      g.fillStyle = "#2c2118";
      g.beginPath();
      g.roundRect(8, 8, boardCanvas.width - 16, boardCanvas.height - 16, 28);
      g.fill();
      g.textAlign = "left";
      g.textBaseline = "middle";
      g.fillStyle = "#f6ead7";
      g.font = "700 40px sans-serif";
      g.fillText(customerHere ? customerName : "Window", 36, 58);
      g.fillStyle = "#f0a04b";
      g.font = "600 30px sans-serif";
      g.fillText(customerHere ? `${recipeName}  ·  ${price}` : "Next guest soon", 36, 104);
      if (customerHere) {
        const chip: Record<Ing, string> = {
          bread: "#e6c48a",
          meat: "#8a4030",
          veg: "#3f8f5a",
          cheese: "#f0c14a",
          sauce: "#d64545",
        };
        let x = 32;
        for (const ing of order) {
          g.fillStyle = chip[ing];
          g.beginPath();
          g.roundRect(x, 142, 140, 52, 26);
          g.fill();
          g.fillStyle = ing === "meat" || ing === "sauce" || ing === "veg" ? "#f6ead7" : "#2a1608";
          g.font = "700 24px sans-serif";
          g.textAlign = "center";
          g.fillText(ING_LABEL[ing], x + 70, 168);
          g.textAlign = "left";
          x += 150;
        }
      }
      boardTex.needsUpdate = true;
    }

    function syncPlate() {
      const sig = plate.join(",");
      if (sig === plateSig) return;
      plateSig = sig;
      while (stack.children.length) stack.remove(stack.children[0] as Object3D);
      let y = 0.04;
      for (const ing of plate) {
        const wide = ing === "bread" ? 0.2 : ing === "sauce" ? 0.11 : 0.16;
        const h = ing === "sauce" ? 0.03 : 0.05;
        const mesh = new THREE.Mesh(cyl, ingMaterials[ing]);
        mesh.userData.age = 0;
        mesh.userData.wide = wide;
        mesh.userData.h = h;
        mesh.scale.set(wide, h, wide);
        mesh.position.y = y + h / 2;
        mesh.castShadow = true;
        stack.add(mesh);
        y += h;
      }
    }

    function forward() {
      return { x: -Math.sin(yaw), z: -Math.cos(yaw) };
    }

    function findTarget(): StationId | null {
      const f = forward();
      let best: StationId | null = null;
      let bestScore = 0.55;
      for (const stand of STANDS) {
        const dx = stand.x - pos.x;
        const dz = stand.z - pos.z;
        const dist = Math.hypot(dx, dz);
        if (dist > stand.reach) continue;
        if (dist < 0.04) {
          best = stand.id;
          bestScore = 2;
          continue;
        }
        const dot = (dx / dist) * f.x + (dz / dist) * f.z;
        if (dot < 0.42) continue;
        const score = dot + (1 - dist / stand.reach) * 0.3;
        if (score > bestScore) {
          bestScore = score;
          best = stand.id;
        }
      }
      if (pos.z > 2.7 && pos.z < 4.02 && Math.abs(pos.x) < 3.7 && f.z > 0.28) {
        const score = 0.68 + f.z * 0.28;
        if (score > bestScore) best = "serve";
      }
      return best;
    }

    function addIng(ing: Ing): boolean {
      if (plate.length >= 8) {
        say("Plate is full", "bad");
        chime("bad");
        return false;
      }
      plate = [...plate, ing];
      say(`Added ${ING_LABEL[ing]}`, "info");
      chime("pop");
      dirty = true;
      return true;
    }

    function tryInteract() {
      if (phase !== "playing" || cooldown > 0) return;
      const target = findTarget();
      currentTarget = target;
      if (!target) {
        say("Face a station", "info");
        return;
      }
      cooldown = 0.24;
      if (target === "bread") {
        addIng("bread");
        return;
      }
      if (target === "sauce") {
        addIng("sauce");
        return;
      }
      if (target === "trash") {
        if (plate.length === 0) {
          say("Plate is already empty", "info");
          return;
        }
        plate = [];
        say("Plate cleared", "info");
        chime("pop");
        dirty = true;
        return;
      }
      if (target === "serve") {
        if (!customerHere) {
          say("Wait for the next customer", "info");
          return;
        }
        if (plate.length === 0) {
          say("Plate is empty", "info");
          return;
        }
        if (!sameBag(plate, order)) {
          say("That's not the order", "bad");
          chime("bad");
          shake = Math.max(shake, 0.14);
          return;
        }
        money += price;
        if (money > bestMoney) {
          bestMoney = money;
          persist();
        }
        say(`Served +${price}`, "good");
        chime("serve");
        shake = Math.max(shake, 0.2);
        plate = [];
        customerHere = false;
        mood = "happy";
        moodT = 0.7;
        dirty = true;
        return;
      }
      const spec = COOK[target];
      const job = jobs[target];
      if (job?.ready) {
        if (addIng(spec.ing)) jobs[target] = null;
        return;
      }
      if (job) {
        say("Still cooking", "info");
        return;
      }
      jobs[target] = { t: 0, dur: spec.dur, ready: false, dinged: false };
      say(spec.start, "info");
      chime("pop");
      dirty = true;
    }

    function spawnCustomer() {
      const pool = recipesForDay(day);
      let recipe = pool[Math.floor(Math.random() * pool.length)] ?? pool[0];
      if (!recipe) return;
      if (firstOrder) {
        recipe = pool[0] ?? recipe;
        firstOrder = false;
      } else if (pool.length > 1 && recipe.id === lastRecipe) {
        const idx = pool.findIndex((item) => item.id === recipe?.id);
        recipe = pool[(idx + 1) % pool.length] ?? recipe;
      }
      lastRecipe = recipe.id;
      order = [...recipe.ings];
      recipeName = recipe.name;
      price = recipe.price;
      const person = CUSTOMERS[Math.floor(Math.random() * CUSTOMERS.length)] ?? CUSTOMERS[0];
      if (!person) return;
      customerName = person.name;
      (shirtMat as MeshStandardMaterial).color.setHex(person.shirt);
      (hairMat as MeshStandardMaterial).color.setHex(person.hair);
      patience = 1;
      patienceDur = patienceSeconds(day);
      customerHere = true;
      mood = "idle";
      popT = 0;
      customer.position.x = 0;
      customer.visible = true;
      redrawBoard();
      dirty = true;
    }

    function showPreviewGuest() {
      const recipe = recipesForDay(1)[0];
      const person = CUSTOMERS[0];
      if (!recipe || !person) return;
      order = [...recipe.ings];
      recipeName = recipe.name;
      price = recipe.price;
      customerName = person.name;
      (shirtMat as MeshStandardMaterial).color.setHex(person.shirt);
      (hairMat as MeshStandardMaterial).color.setHex(person.hair);
      customerHere = true;
      customer.visible = true;
      patience = 0.82;
      redrawBoard();
      customerHere = false;
      order = [];
    }

    function finishDay() {
      phase = money >= goal ? "win" : "lose";
      if (phase === "win" && day > bestDay) bestDay = day;
      if (money > bestMoney) bestMoney = money;
      persist();
      input.joyX = 0;
      input.joyY = 0;
      velX = 0;
      velZ = 0;
      dirty = true;
    }

    function begin(nextDay: number) {
      day = nextDay;
      money = 0;
      goal = dayGoal(day);
      timeLeft = daySeconds(day);
      plate = [];
      jobs.grill = null;
      jobs.chop = null;
      jobs.oven = null;
      firstOrder = true;
      lastRecipe = "";
      order = [];
      recipeName = "";
      price = 0;
      customerName = "";
      customerHere = false;
      patience = 1;
      mood = "idle";
      moodT = 0;
      gap = 0.25;
      cooldown = 0;
      toast = "";
      toastT = 0;
      hints = true;
      hintT = 9;
      shake = 0;
      pos.x = 0;
      pos.z = 1.5;
      velX = 0;
      velZ = 0;
      yaw = Math.PI;
      pitch = -0.2;
      phase = "playing";
      customer.visible = false;
      redrawBoard();
      dirty = true;
      unlockAudio();
      chime("ready");
    }

    function blocked(x: number, z: number) {
      if (x < -6.05 || x > 6.05 || z < -4.4 || z > 4.02) return true;
      const r2 = RADIUS * RADIUS;
      for (const box of solids) {
        const cx = Math.max(box.minX, Math.min(x, box.maxX));
        const cz = Math.max(box.minZ, Math.min(z, box.maxZ));
        const dx = x - cx;
        const dz = z - cz;
        if (dx * dx + dz * dz < r2) return true;
      }
      return false;
    }

    function publish() {
      const cook: CookChip[] = [];
      for (const id of COOK_IDS) {
        const job = jobs[id];
        if (!job) continue;
        cook.push({
          id,
          label: COOK[id].label,
          p: job.ready ? 1 : Math.min(1, job.t / job.dur),
          ready: job.ready,
        });
      }
      let verb = "Use";
      let detail = "";
      let canAct = false;
      if (phase === "playing") {
        if (!currentTarget) detail = "Look at a station";
        else if (currentTarget === "bread") {
          verb = "Add bread";
          detail = "Flatbread shelf";
          canAct = plate.length < 8;
        } else if (currentTarget === "sauce") {
          verb = "Add sauce";
          detail = "Sauce pump";
          canAct = plate.length < 8;
        } else if (currentTarget === "trash") {
          verb = "Trash plate";
          detail = plate.length ? "Clears the plate" : "Plate is empty";
          canAct = plate.length > 0;
        } else if (currentTarget === "serve") {
          verb = "Serve";
          detail = customerHere ? `${customerName} · ${recipeName}` : "No customer yet";
          canAct = customerHere && plate.length > 0;
        } else {
          const spec = COOK[currentTarget];
          const job = jobs[currentTarget];
          if (job?.ready) {
            verb = spec.take;
            detail = "Ready to plate";
            canAct = plate.length < 8;
          } else if (job) {
            verb = "Cooking";
            detail = `${spec.label} · ${Math.max(1, Math.ceil(spec.dur - job.t))}s`;
          } else {
            verb = spec.start;
            detail = spec.label;
            canAct = true;
          }
        }
      }
      const snap: HudSnap = {
        phase,
        day,
        money,
        goal,
        timeLeft,
        customerName: customerHere ? customerName : "",
        recipeName: customerHere ? recipeName : "",
        price: customerHere ? price : 0,
        order: customerHere ? order : [],
        patience: customerHere ? patience : 0,
        plate: [...plate],
        verb,
        detail,
        toast,
        toastTone,
        cook,
        bestDay,
        bestMoney,
        muted,
        customerHere,
        hints: phase === "playing" && hints,
        booted: true,
        canAct,
      };
      setHud(snap);
    }

    function held() {
      return forced ?? keys;
    }

    function applyLook(dx: number, dy: number) {
      yaw -= dx * 0.0033;
      pitch -= dy * 0.0033;
      if (pitch < -PITCH_LIMIT) pitch = -PITCH_LIMIT;
      if (pitch > PITCH_LIMIT) pitch = PITCH_LIMIT;
    }

    function onKeyDown(event: KeyboardEvent) {
      if ((phase === "playing" || phase === "paused") && GAME_KEYS.has(event.code)) event.preventDefault();
      keys.add(event.code);
    }
    function onKeyUp(event: KeyboardEvent) {
      keys.delete(event.code);
    }
    function clearKeys() {
      keys.clear();
    }
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", clearKeys);
    document.addEventListener("visibilitychange", clearKeys);

    const timer = new THREE.Timer();
    timer.connect(document);

    function resize() {
      const w = canvas.clientWidth || 1;
      const h = canvas.clientHeight || 1;
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
      renderer.setSize(w, h, false);
    }
    const parent = canvas.parentElement ?? canvas;
    const observer = new ResizeObserver(() => resize());
    observer.observe(parent);
    resize();

    showPreviewGuest();
    publish();

    function update(dt: number) {
      const padIds = navigator.getGamepads?.() ?? [];
      let padMoveX = 0;
      let padMoveY = 0;
      let padLookX = 0;
      let padLookY = 0;
      let padEdge = false;
      let sawPad = false;
      for (const pad of padIds) {
        if (!pad) continue;
        sawPad = true;
        const move = radialDeadzone(pad.axes[0] ?? 0, -(pad.axes[1] ?? 0));
        padMoveX += move.x;
        padMoveY += move.y;
        const look = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0, 0.2);
        padLookX += look.x;
        padLookY += look.y;
        const pressed = Boolean(pad.buttons[0]?.pressed);
        if (pressed && !padA) padEdge = true;
        padA = pressed;
        break;
      }
      if (!sawPad) padA = false;

      if (phase === "playing") {
        applyLook(input.lookDx, input.lookDy);
        yaw -= padLookX * 1.9 * dt;
        pitch -= padLookY * 1.35 * dt;
        if (pitch < -PITCH_LIMIT) pitch = -PITCH_LIMIT;
        if (pitch > PITCH_LIMIT) pitch = PITCH_LIMIT;

        const down = held();
        const esc = down.has("Escape");
        if (esc && !prevEsc) {
          phase = "paused";
          velX = 0;
          velZ = 0;
          dirty = true;
        }
        prevEsc = esc;

        if (phase === "playing") {
          const use = down.has("KeyE") || down.has("Space");
          if ((use && !prevUse) || input.interact || padEdge) tryInteract();
          prevUse = use;

          let mx = 0;
          let my = 0;
          if (down.has("KeyW") || down.has("ArrowUp")) my += 1;
          if (down.has("KeyS") || down.has("ArrowDown")) my -= 1;
          if (down.has("KeyD") || down.has("ArrowRight")) mx += 1;
          if (down.has("KeyA") || down.has("ArrowLeft")) mx -= 1;
          mx += input.joyX + padMoveX;
          my += input.joyY + padMoveY;
          const mag = Math.hypot(mx, my);
          if (mag > 1) {
            mx /= mag;
            my /= mag;
          }
          const f = forward();
          const rx = Math.cos(yaw);
          const rz = -Math.sin(yaw);
          const wishX = (f.x * my + rx * mx) * WALK;
          const wishZ = (f.z * my + rz * mx) * WALK;
          velX = approach(velX, wishX, 22 * dt);
          velZ = approach(velZ, wishZ, 22 * dt);
          const stepX = velX * dt;
          const stepZ = velZ * dt;
          if (stepX !== 0) {
            if (!blocked(pos.x + stepX, pos.z)) pos.x += stepX;
            else velX = 0;
          }
          if (stepZ !== 0) {
            if (!blocked(pos.x, pos.z + stepZ)) pos.z += stepZ;
            else velZ = 0;
          }

          for (const id of COOK_IDS) {
            const job = jobs[id];
            if (!job || job.ready) continue;
            job.t += dt;
            if (job.t >= job.dur) {
              job.t = job.dur;
              job.ready = true;
              if (!job.dinged) {
                job.dinged = true;
                say(`${COOK[id].label} is ready`, "good");
                chime("ready");
              }
            }
          }

          if (customerHere) {
            patience = Math.max(0, patience - dt / patienceDur);
            if (patience <= 0) {
              customerHere = false;
              plate = [];
              mood = "mad";
              moodT = 0.55;
              say(`${customerName} left hungry`, "bad");
              chime("leave");
              redrawBoard();
            }
          } else if (mood !== "idle") {
            moodT -= dt;
            if (moodT <= 0) {
              mood = "idle";
              gap = 0.35;
              customer.visible = false;
            }
          } else {
            gap -= dt;
            if (gap <= 0) spawnCustomer();
          }

          if (hintT > 0) {
            hintT -= dt;
            if (hintT <= 0) {
              hints = false;
              dirty = true;
            }
          }

          timeLeft -= dt;
          if (timeLeft <= 0) {
            timeLeft = 0;
            finishDay();
          }
          cooldown = Math.max(0, cooldown - dt);
          currentTarget = phase === "playing" ? findTarget() : null;
        }
      } else if (phase === "paused") {
        const esc = held().has("Escape");
        if (esc && !prevEsc) {
          phase = "playing";
          dirty = true;
        }
        prevEsc = esc;
        prevUse = held().has("KeyE") || held().has("Space");
      } else if (phase === "menu") {
        menuT += dt;
        pos.x = 0;
        pos.z = 1.5;
        if (!reduce) {
          yaw = Math.PI + Math.sin(menuT * 0.33) * 0.48;
          pitch = -0.18 + Math.sin(menuT * 0.27) * 0.05;
        }
        customer.visible = true;
        customer.position.y = Math.sin(menuT * 1.4) * 0.02;
      }

      input.lookDx = 0;
      input.lookDy = 0;
      input.interact = false;
      animT += dt;

      if (toastT > 0) {
        toastT -= dt;
        if (toastT <= 0) {
          toast = "";
          dirty = true;
        }
      }

      const moving = phase === "playing" && Math.hypot(velX, velZ) > 0.25;
      if (moving && !reduce) bob += dt * 9;
      shake = Math.max(0, shake - dt * 1.5);
      const sx = shake > 0 && !reduce ? (Math.random() - 0.5) * shake : 0;
      const sy = shake > 0 && !reduce ? (Math.random() - 0.5) * shake : 0;
      const bobY = moving && !reduce ? Math.sin(bob) * 0.03 : 0;
      const bobX = moving && !reduce ? Math.cos(bob * 0.5) * 0.018 : 0;
      rig.position.set(pos.x, EYE, pos.z);
      rig.rotation.y = yaw;
      camera.rotation.x = pitch;
      camera.position.set(bobX + sx, bobY + sy, 0);

      const grilling = Boolean(jobs.grill && !jobs.grill.ready);
      spit.rotation.y += dt * (grilling ? 2.6 : 0.35);
      const flick = 0.85 + Math.sin(animT * 18) * 0.15;
      flame.scale.set(grilling ? 0.22 * flick : 0.1, grilling ? 0.4 * flick : 0.16, grilling ? 0.22 : 0.1);
      grillLight.intensity = grilling ? 1.6 : jobs.grill?.ready ? 0.45 : 0.08;
      const baking = Boolean(jobs.oven && !jobs.oven.ready);
      ovenGlowMat.color.setHex(jobs.oven?.ready ? 0xf0c14a : baking ? 0xff7a2a : 0x2a120c);
      if (jobs.chop && !jobs.chop.ready) {
        chopLeaf.rotation.y += dt * 8;
        knife.rotation.z = Math.sin(animT * 16) * 0.4;
      }

      if (phase === "playing") {
        if (mood === "happy") customer.position.y = Math.abs(Math.sin((0.7 - moodT) * 14)) * 0.16;
        else if (mood === "mad") {
          customer.position.x = Math.sin(moodT * 40) * 0.06;
          customer.position.y = 0;
        } else {
          customer.position.y = customerHere ? Math.sin(performance.now() / 420) * 0.015 : 0;
          customer.position.x = 0;
        }
        popT = Math.min(1, popT + dt * 3.2);
        customer.scale.setScalar(customerHere ? 0.86 + popT * 0.14 : 1);
        customer.visible = customerHere || mood !== "idle";
        const p = customerHere ? patience : 0;
        barFill.scale.x = Math.max(0.02, 0.58 * p);
        barFill.position.x = ((p - 1) * 0.58) / 2;
        const barMat = barFill.material as MeshBasicMaterial;
        barMat.color.setHex(p > 0.5 ? 0x3cba7a : p > 0.25 ? 0xf0a04b : 0xe15a3a);
        barBg.visible = customerHere;
        barFill.visible = customerHere;
      }

      if (currentTarget && phase === "playing") {
        const stand = STANDS.find((item) => item.id === currentTarget);
        ring.visible = Boolean(stand);
        if (stand) ring.position.set(stand.x, 0.04, stand.z);
        else if (currentTarget === "serve") ring.position.set(Math.max(-1.2, Math.min(1.2, pos.x)), 0.04, 3.5);
        ring.rotation.z += dt;
      } else if (phase !== "menu") {
        ring.visible = false;
      }

      syncPlate();
      for (const child of stack.children) {
        const mesh = child as Mesh;
        const age = (mesh.userData.age as number) + dt;
        mesh.userData.age = age;
        const wide = mesh.userData.wide as number;
        const h = mesh.userData.h as number;
        const pop = age < 0.22 ? 1 + Math.sin((age / 0.22) * Math.PI) * 0.2 : 1;
        mesh.scale.set(wide * pop, h, wide * pop);
      }

      hudAcc += dt;
      if (dirty || hudAcc > 0.12) {
        hudAcc = 0;
        dirty = false;
        publish();
      }
    }

    renderer.setAnimationLoop((now) => {
      if (disposed) return;
      timer.update(now);
      const dt = Math.min(timer.getDelta(), 0.05);
      if (!window.__shawarmaReady) window.__shawarmaReady = true;
      update(dt);
      renderer.render(scene, camera);
    });

    bindApi({
      start: () => {
        if (phase === "menu" || phase === "win" || phase === "lose") begin(phase === "win" ? day + 1 : phase === "lose" ? day : 1);
      },
      nextDay: () => begin(day + 1),
      retry: () => begin(day),
      pause: () => {
        if (phase !== "playing") return;
        phase = "paused";
        velX = 0;
        velZ = 0;
        input.joyX = 0;
        input.joyY = 0;
        dirty = true;
        publish();
      },
      resume: () => {
        if (phase !== "paused") return;
        phase = "playing";
        dirty = true;
        publish();
      },
      quit: () => {
        phase = "menu";
        menuT = 0;
        velX = 0;
        velZ = 0;
        input.joyX = 0;
        input.joyY = 0;
        customerHere = false;
        showPreviewGuest();
        dirty = true;
        publish();
      },
      toggleMute: () => {
        muted = !muted;
        persist();
        dirty = true;
        publish();
      },
    });

    if (import.meta.env.DEV) {
      window.__controlsTest = {
        getYaw: () => yaw,
        getPitch: () => pitch,
        getSpeed: () => Math.hypot(velX, velZ),
        getPos: () => ({ x: pos.x, z: pos.z }),
        getPlate: () => plate.slice(),
        setKeys: (codes: string[]) => {
          forced = new Set(codes);
        },
        setYaw: (next: number) => {
          yaw = next;
        },
        setPos: (x: number, z: number) => {
          pos.x = x;
          pos.z = z;
          velX = 0;
          velZ = 0;
        },
        addLook: (dx: number, dy: number) => applyLook(dx, dy),
        use: () => tryInteract(),
      };
    }

    stop = () => {
      renderer.setAnimationLoop(null);
      timer.dispose();
      observer.disconnect();
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", clearKeys);
      document.removeEventListener("visibilitychange", clearKeys);
      bindApi(null);
      if (window.__controlsTest) delete window.__controlsTest;
      for (const g of geos) g.dispose();
      for (const m of materials) m.dispose();
      floorTex.dispose();
      boardTex.dispose();
      renderer.dispose();
    };
  }

  return () => {
    disposed = true;
    stop();
  };
}
