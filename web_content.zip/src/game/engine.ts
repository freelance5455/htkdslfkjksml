import { audio } from './audio';

// ---------- Types ----------
export type ZombieType = 'walker' | 'runner' | 'brute';

interface Zombie {
  id: number;
  type: ZombieType;
  x: number; // lateral world position
  targetX: number;
  d: number; // depth / distance; spawns far, attacks when near
  speed: number;
  hp: number;
  maxHp: number;
  phase: number;
  state: 'walk' | 'die' | 'attack';
  t: number; // state timer
  dieKind: 'head' | 'body';
  dieDir: number;
  flash: number;
  size: number;
  moaned: boolean;
  // screen-space cache (computed every frame)
  sx: number;
  sy: number;
  hpx: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  grav: number;
  drag: number;
  kind: 0 | 1 | 2 | 3; // 0 blood square, 1 smoke circle, 2 spark, 3 shell casing
  rot: number;
  vr: number;
}

interface FloatText {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
  size: number;
}

interface Decal {
  wx: number; // world lateral
  wd: number; // world depth
  size: number; // world size multiplier
  life: number;
  seed: number;
}

interface Claw {
  x: number;
  y: number;
  angle: number;
  life: number;
  len: number;
}

export interface GameStats {
  score: number;
  kills: number;
  headshots: number;
  time: number;
  maxCombo: number;
  accuracy: number;
}

export interface EngineCallbacks {
  onGameOver: (stats: GameStats) => void;
  onPauseChange: (paused: boolean) => void;
}

// ---------- Constants ----------
const MAG = 5;
const RELOAD_TIME = 1.45;
const BOLT_TIME = 0.5;
const CAM_H = 2.2;
const SPAWN_D = 10;
const ATTACK_D = 1.15;
export const MAX_HEALTH = 5;
const MAX_PARTICLES = 360;

const TYPES: Record<
  ZombieType,
  { hp: number; speed: number; score: number; size: number; skin: string; cloth: string; eye: string; wobble: number }
> = {
  walker: { hp: 1, speed: 0.78, score: 100, size: 1, skin: '#6e8a58', cloth: '#3a3f4b', eye: '#ffd54a', wobble: 1 },
  runner: { hp: 1, speed: 1.65, score: 150, size: 0.92, skin: '#98a86f', cloth: '#5b3535', eye: '#ff7a3a', wobble: 1.9 },
  brute: { hp: 4, speed: 0.55, score: 300, size: 1.38, skin: '#55644a', cloth: '#262a30', eye: '#ff2a2a', wobble: 0.7 },
};

const GREEN = '#9dff7a';
const AMBER = '#ffb648';
const CYAN = '#7ae7ff';
const HEAD_FONT = '"Black Ops One", Impact, "Arial Black", sans-serif';
const MONO_FONT = 'ui-monospace, "SF Mono", Menlo, Consolas, monospace';

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const easeOut = (t: number) => 1 - (1 - t) * (1 - t);

// ---------- Engine ----------
export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: EngineCallbacks;
  W = 1;
  H = 1;
  private dpr = 1;
  private horizonY = 0;

  private rafId = 0;
  private lastTs = 0;
  running = false;
  paused = false;
  over = false;
  private attractMode = false;

  // time & difficulty
  time = 0;
  private spawnTimer = 0;
  private hitstop = 0;

  // aim
  aimX = 0;
  aimY = 0;
  private aimVX = 0;
  private aimVY = 0;
  private recoilX = 0;
  private recoilY = 0;
  private keys = new Set<string>();

  // feedback
  private trauma = 0;
  private shakeX = 0;
  private shakeY = 0;
  private shakeRot = 0;
  private whiteFlash = 0;
  private redFlash = 0;
  private muzzle = 0;
  private tracer: { x: number; y: number; life: number } | null = null;
  private boltT = 0;
  private reloading = false;
  private reloadT = 0;
  private announce: { text: string; life: number; max: number; color: string } | null = null;
  private comboPulse = 0;
  private damagePulse = 0;
  private lowHealthT = 0;

  // entities
  private zombies: Zombie[] = [];
  private particles: Particle[] = [];
  private texts: FloatText[] = [];
  private decals: Decal[] = [];
  private claws: Claw[] = [];
  private idc = 0;

  // stats
  score = 0;
  kills = 0;
  headshots = 0;
  shots = 0;
  hits = 0;
  combo = 0;
  maxCombo = 0;
  health = MAX_HEALTH;
  ammo = MAG;
  private killWindow: number[] = [];

  // scenery (precomputed)
  private stars: { x: number; y: number; r: number; tw: number }[] = [];
  private hills: { pts: number[]; color: string }[] = [];
  private trees: { x: number; d: number; h: number; seed: number }[] = [];

  // touch state
  private touchId: number | null = null;
  private touchStart = { x: 0, y: 0, t: 0, moved: 0 };
  private touchLast = { x: 0, y: 0 };

  constructor(canvas: HTMLCanvasElement, cb: EngineCallbacks) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('no 2d context');
    this.ctx = ctx;
    this.cb = cb;
    this.resize();
    this.bind();
    this.buildScenery();
    this.aimX = this.W / 2;
    this.aimY = this.H * 0.55;
    this.attract();
  }

  // ---------- Setup ----------
  resize = () => {
    const rect = this.canvas.getBoundingClientRect();
    const W = Math.max(1, Math.round(rect.width));
    const H = Math.max(1, Math.round(rect.height));
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = W;
    this.H = H;
    this.canvas.width = Math.round(W * this.dpr);
    this.canvas.height = Math.round(H * this.dpr);
    this.horizonY = H * 0.4;
    this.buildScenery();
    this.aimX = clamp(this.aimX, 0, W);
    this.aimY = clamp(this.aimY, 0, H);
    for (const z of this.zombies) this.projectZombie(z);
    if (!this.running || this.paused) this.renderFrame();
  };

  private buildScenery() {
    const { W, H } = this;
    this.stars = [];
    const n = Math.floor((W * this.horizonY) / 9000);
    for (let i = 0; i < n; i++) {
      this.stars.push({ x: Math.random() * W, y: Math.random() * this.horizonY * 0.9, r: rand(0.4, 1.4), tw: Math.random() * 6 });
    }
    this.hills = [];
    const layers = [
      { amp: H * 0.06, base: this.horizonY - H * 0.015, color: '#0b120d', freq: 0.004 },
      { amp: H * 0.035, base: this.horizonY + 2, color: '#111a13', freq: 0.007 },
    ];
    layers.forEach((l, li) => {
      const pts: number[] = [];
      for (let x = -10; x <= W + 10; x += 14) {
        const y = l.base - Math.abs(Math.sin(x * l.freq + li * 2.1) * l.amp + Math.sin(x * l.freq * 3.1 + li) * l.amp * 0.3);
        pts.push(x, y);
      }
      this.hills.push({ pts, color: l.color });
    });
    this.trees = [];
    const seeds = [
      [-1.9, 3.2],
      [1.7, 4.1],
      [-1.2, 6.5],
      [2.3, 2.6],
      [0.9, 8.2],
      [-2.6, 2.1],
      [-0.5, 9.1],
      [1.3, 6.9],
    ];
    seeds.forEach(([x, d], i) => this.trees.push({ x, d, h: rand(2.4, 3.6), seed: i * 1.37 }));
  }

  private bind() {
    const c = this.canvas;
    c.addEventListener('pointerdown', this.onPointerDown);
    c.addEventListener('pointermove', this.onPointerMove);
    c.addEventListener('pointerup', this.onPointerUp);
    c.addEventListener('pointercancel', this.onPointerUp);
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.resize);
    document.addEventListener('visibilitychange', this.onVisibility);
  }

  destroy() {
    cancelAnimationFrame(this.rafId);
    const c = this.canvas;
    c.removeEventListener('pointerdown', this.onPointerDown);
    c.removeEventListener('pointermove', this.onPointerMove);
    c.removeEventListener('pointerup', this.onPointerUp);
    c.removeEventListener('pointercancel', this.onPointerUp);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.resize);
    document.removeEventListener('visibilitychange', this.onVisibility);
  }

  // ---------- Input ----------
  private onVisibility = () => {
    if (document.hidden && this.running && !this.paused && !this.over) this.setPaused(true);
  };

  private onPointerDown = (e: PointerEvent) => {
    if (!this.running || this.paused || this.over) return;
    audio.unlock();
    if (e.pointerType === 'mouse') {
      this.setAim(e.clientX, e.clientY);
      if (e.button === 0) this.fire();
      else if (e.button === 2) this.reload();
      return;
    }
    // touch / pen: drag-to-aim, tap-to-fire
    if (this.touchId !== null) return;
    this.touchId = e.pointerId;
    this.canvas.setPointerCapture(e.pointerId);
    this.touchStart = { x: e.clientX, y: e.clientY, t: performance.now(), moved: 0 };
    this.touchLast = { x: e.clientX, y: e.clientY };
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.running || this.paused || this.over) return;
    if (e.pointerType === 'mouse') {
      this.setAim(e.clientX, e.clientY);
      return;
    }
    if (e.pointerId !== this.touchId) return;
    const dx = e.clientX - this.touchLast.x;
    const dy = e.clientY - this.touchLast.y;
    this.touchLast = { x: e.clientX, y: e.clientY };
    this.touchStart.moved += Math.abs(dx) + Math.abs(dy);
    const sens = 1.35;
    this.aimX = clamp(this.aimX + dx * sens, 0, this.W);
    this.aimY = clamp(this.aimY + dy * sens, 0, this.H);
  };

  private onPointerUp = (e: PointerEvent) => {
    if (e.pointerId !== this.touchId) return;
    this.touchId = null;
    const dt = performance.now() - this.touchStart.t;
    if (dt < 220 && this.touchStart.moved < 14 && this.running && !this.paused && !this.over) {
      this.fire();
    }
  };

  private setAim(cx: number, cy: number) {
    const r = this.canvas.getBoundingClientRect();
    this.aimX = clamp(cx - r.left, 0, this.W);
    this.aimY = clamp(cy - r.top, 0, this.H);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    if (e.repeat) return;
    this.keys.add(k);
    if (!this.running || this.over) return;
    if (k === 'escape' || k === 'p') {
      this.setPaused(!this.paused);
      return;
    }
    if (this.paused) return;
    if (k === ' ' || k === 'enter' || k === 'f' || k === 'control' || k === 'j') {
      audio.unlock();
      this.fire();
    } else if (k === 'r') {
      this.reload();
    } else if (k === 'm') {
      audio.setMuted(!audio.muted);
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  // ---------- Game control ----------
  start() {
    this.zombies = [];
    this.particles = [];
    this.texts = [];
    this.decals = [];
    this.claws = [];
    this.score = 0;
    this.kills = 0;
    this.headshots = 0;
    this.shots = 0;
    this.hits = 0;
    this.combo = 0;
    this.maxCombo = 0;
    this.health = MAX_HEALTH;
    this.ammo = MAG;
    this.time = 0;
    this.spawnTimer = 1.2;
    this.hitstop = 0;
    this.trauma = 0;
    this.whiteFlash = 0;
    this.redFlash = 0;
    this.boltT = 0;
    this.reloading = false;
    this.reloadT = 0;
    this.announce = null;
    this.killWindow = [];
    this.recoilX = 0;
    this.recoilY = 0;
    this.aimX = this.W / 2;
    this.aimY = this.H * 0.58;
    this.over = false;
    this.paused = false;
    this.attractMode = false;
    this.running = true;
    // Instant action: a couple of targets already in range.
    this.spawn('walker', 5.4, -0.35);
    this.spawn('walker', 7.4, 0.55);
    this.setAnnounce('CLEAR THE ZONE', 1.6, GREEN);
    this.lastTs = performance.now();
    cancelAnimationFrame(this.rafId);
    this.rafId = requestAnimationFrame(this.loop);
  }

  stop() {
    this.running = false;
    this.over = false;
    this.attract();
  }

  /** Idle background loop for menus: zombies shamble, scope sweeps, no damage. */
  attract() {
    this.attractMode = true;
    this.running = false;
    this.over = false;
    this.paused = false;
    this.zombies = [];
    this.particles = [];
    this.texts = [];
    this.decals = [];
    this.claws = [];
    this.announce = null;
    this.tracer = null;
    this.trauma = 0;
    this.redFlash = 0;
    this.whiteFlash = 0;
    this.reloading = false;
    this.boltT = 0;
    this.health = MAX_HEALTH;
    this.spawnTimer = 0;
    this.spawn('walker', 7, -0.6);
    this.spawn('walker', 5, 0.8);
    this.lastTs = performance.now();
    cancelAnimationFrame(this.rafId);
    this.rafId = requestAnimationFrame(this.loop);
  }

  private updateAttract(dt: number) {
    const { W, H } = this;
    this.time += dt;
    this.aimX = W / 2 + Math.sin(this.time * 0.35) * W * 0.18;
    this.aimY = H * 0.56 + Math.cos(this.time * 0.22) * H * 0.05;
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0 && this.zombies.length < 6) {
      this.spawn(Math.random() < 0.2 ? 'brute' : 'walker');
      this.spawnTimer = rand(1.5, 3);
    }
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      z.d -= z.speed * dt * 0.8;
      z.x += (z.targetX - z.x) * dt * 0.18;
      z.phase += dt * (z.type === 'brute' ? 4.5 : 6.5);
      if (z.d <= 1.4) {
        this.zombies.splice(i, 1);
        continue;
      }
      this.projectZombie(z);
    }
    this.zombies.sort((a, b) => b.d - a.d);
  }

  setPaused(p: boolean) {
    if (!this.running || this.over) return;
    if (this.paused === p) return;
    this.paused = p;
    if (p) {
      cancelAnimationFrame(this.rafId);
      this.renderFrame();
    } else {
      this.lastTs = performance.now();
      this.rafId = requestAnimationFrame(this.loop);
    }
    this.cb.onPauseChange(p);
  }

  togglePause() {
    this.setPaused(!this.paused);
  }

  private endGame() {
    this.over = true;
    this.running = false;
    audio.gameOver();
    const stats: GameStats = {
      score: this.score,
      kills: this.kills,
      headshots: this.headshots,
      time: this.time,
      maxCombo: this.maxCombo,
      accuracy: this.shots > 0 ? Math.round((this.hits / this.shots) * 100) : 0,
    };
    // Let the death flash play out briefly, then hand over.
    setTimeout(() => {
      cancelAnimationFrame(this.rafId);
      this.cb.onGameOver(stats);
    }, 900);
  }

  // ---------- Actions ----------
  fire() {
    if (!this.running || this.paused || this.over) return;
    if (this.reloading || this.boltT > 0) return;
    if (this.ammo <= 0) {
      audio.empty();
      this.reload();
      return;
    }
    this.ammo--;
    this.shots++;
    this.boltT = BOLT_TIME;
    const cx = this.crossX();
    const cy = this.crossY();
    // juice
    this.trauma = Math.min(1, this.trauma + 0.45);
    this.recoilY -= 26;
    this.recoilX += rand(-6, 6);
    this.whiteFlash = 0.22;
    this.muzzle = 1;
    this.tracer = { x: cx, y: cy, life: 1 };
    audio.shot();
    setTimeout(() => audio.bolt(), 180);
    this.spawnShell();

    // hit test: nearest zombies first (they're drawn in front)
    for (const z of this.zombies) this.projectZombie(z);
    const sorted = this.zombies.filter((z) => z.state !== 'die' && z.hp > 0).sort((a, b) => a.d - b.d);
    let hitZ: Zombie | null = null;
    let head = false;
    for (const z of sorted) {
      const headR = Math.max(8, z.hpx * 0.12 * 1.3);
      const hx = z.sx;
      const hy = z.sy - z.hpx * 0.88;
      if ((cx - hx) ** 2 + (cy - hy) ** 2 <= headR * headR) {
        hitZ = z;
        head = true;
        break;
      }
      const hw = Math.max(7, z.hpx * 0.17);
      if (cx >= z.sx - hw && cx <= z.sx + hw && cy >= z.sy - z.hpx * 0.8 && cy <= z.sy) {
        hitZ = z;
        head = false;
        break;
      }
    }
    if (hitZ) {
      this.hits++;
      this.damageZombie(hitZ, head, cx, cy);
    } else {
      this.miss(cx, cy);
    }
  }

  reload() {
    if (!this.running || this.paused || this.over) return;
    if (this.reloading || this.ammo >= MAG) return;
    this.reloading = true;
    this.reloadT = RELOAD_TIME;
    audio.reloadStart();
  }

  private miss(x: number, y: number) {
    if (this.combo >= 3) this.setAnnounce('COMBO LOST', 0.8, '#ff6b6b');
    this.combo = 0;
    audio.miss();
    if (y > this.horizonY) {
      // dirt kick
      this.puff(x, y, 10, '#6b5a43', 1.2);
      for (let i = 0; i < 6; i++) this.addParticle(x, y, rand(-120, 120), rand(-260, -60), rand(0.3, 0.6), rand(1.5, 3), '#8a7658', 900, 0.98, 0);
    } else {
      this.addText(x, y - 10, 'MISS', '#8c8c8c', 14);
      for (let i = 0; i < 4; i++) this.addParticle(x, y, rand(-80, 80), rand(-80, 80), 0.25, 1.5, '#cfd6cc', 0, 0.9, 2);
    }
  }

  private damageZombie(z: Zombie, head: boolean, x: number, y: number) {
    const cfg = TYPES[z.type];
    const dmg = head ? 3 : 1;
    z.hp -= dmg;
    z.flash = 1;
    const bloodN = head ? 26 : 14;
    this.blood(x, y, bloodN, head ? 1.4 : 1);
    if (z.hp <= 0) {
      this.killZombie(z, head);
    } else {
      // brute soak
      z.d += 0.12; // staggers back
      this.combo++;
      audio.hit();
      this.addText(x, y - 20, head ? 'CRITICAL' : 'HIT', '#ffd9d9', 15);
      this.trauma = Math.min(1, this.trauma + 0.1);
    }
    void cfg;
  }

  private killZombie(z: Zombie, head: boolean) {
    const cfg = TYPES[z.type];
    z.state = 'die';
    z.t = 0;
    z.dieKind = head ? 'head' : 'body';
    z.dieDir = Math.random() < 0.5 ? -1 : 1;
    this.kills++;
    this.combo++;
    if (this.combo > this.maxCombo) this.maxCombo = this.combo;
    const mult = this.multiplier();
    let pts = cfg.score;
    const parts: string[] = [];
    if (head) {
      this.headshots++;
      pts *= 2;
      parts.push('HEADSHOT');
    }
    const longShot = z.d > 6.5;
    if (longShot) {
      pts += Math.round(z.d * 15);
      parts.push('LONG SHOT');
    }
    pts *= mult;
    this.score += pts;

    // multi-kill tracking
    const now = this.time;
    this.killWindow = this.killWindow.filter((t) => now - t < 1.4);
    this.killWindow.push(now);
    const mk = this.killWindow.length;

    const color = head ? AMBER : longShot ? CYAN : GREEN;
    this.addText(z.sx, z.sy - z.hpx - 6, `+${pts}`, color, head ? 24 : 19);
    if (mk >= 3) this.setAnnounce(mk >= 4 ? 'MASSACRE!' : 'TRIPLE KILL', 1.1, '#ff4d6d');
    else if (mk === 2) this.setAnnounce('DOUBLE KILL', 1.0, AMBER);
    else if (parts.length) this.setAnnounce(parts.join(' • '), 0.9, color);

    if (this.combo > 0 && this.combo % 3 === 0) {
      this.comboPulse = 1;
      audio.combo(Math.min(5, this.combo / 3));
    }
    if (head) {
      audio.headshot();
      this.hitstop = 0.07;
      this.trauma = Math.min(1, this.trauma + 0.25);
    } else {
      audio.hit();
      this.trauma = Math.min(1, this.trauma + 0.1);
    }
    if (z.type === 'brute') {
      this.hitstop = Math.max(this.hitstop, 0.06);
      this.trauma = Math.min(1, this.trauma + 0.3);
    }
    // ground decal
    this.decals.push({ wx: z.x, wd: z.d, size: z.size, life: 1, seed: Math.random() * 10 });
    if (this.decals.length > 28) this.decals.shift();
  }

  multiplier() {
    return Math.min(5, 1 + Math.floor(this.combo / 3));
  }

  private takeDamage(z: Zombie) {
    this.health--;
    this.combo = 0;
    this.redFlash = 1;
    this.damagePulse = 1;
    this.trauma = 1;
    audio.damage();
    const ang = rand(-0.9, -0.4) * (Math.random() < 0.5 ? 1 : -1);
    this.claws.push({ x: clamp(z.sx, this.W * 0.2, this.W * 0.8), y: this.H * rand(0.35, 0.55), angle: ang, life: 1, len: Math.min(this.W, this.H) * 0.7 });
    this.setAnnounce(this.health > 0 ? 'BREACHED!' : 'OVERRUN', 1.2, '#ff3b3b');
    if (this.health <= 0) this.endGame();
  }

  // ---------- Spawning ----------
  private spawn(type: ZombieType, d = SPAWN_D, x?: number) {
    const cfg = TYPES[type];
    const sp = 1 + this.time * 0.004;
    const xx = x ?? rand(-1.3, 1.3);
    const z: Zombie = {
      id: this.idc++,
      type,
      x: xx,
      targetX: xx * rand(0.3, 0.6),
      d,
      speed: cfg.speed * sp * rand(0.9, 1.1),
      hp: cfg.hp,
      maxHp: cfg.hp,
      phase: Math.random() * Math.PI * 2,
      state: 'walk',
      t: 0,
      dieKind: 'body',
      dieDir: 1,
      flash: 0,
      size: cfg.size * rand(0.94, 1.06),
      moaned: false,
      sx: 0,
      sy: 0,
      hpx: 0,
    };
    this.zombies.push(z);
    this.projectZombie(z);
  }

  private pickType(): ZombieType {
    const t = this.time;
    const runner = clamp((t - 8) / 90, 0, 0.4);
    const brute = clamp((t - 25) / 120, 0, 0.25);
    const r = Math.random();
    if (r < brute) return 'brute';
    if (r < brute + runner) return 'runner';
    return 'walker';
  }

  // ---------- Particles / FX ----------
  private addParticle(
    x: number,
    y: number,
    vx: number,
    vy: number,
    life: number,
    size: number,
    color: string,
    grav: number,
    drag: number,
    kind: 0 | 1 | 2 | 3,
  ) {
    if (this.particles.length >= MAX_PARTICLES) this.particles.shift();
    this.particles.push({ x, y, vx, vy, life, max: life, size, color, grav, drag, kind, rot: Math.random() * 6.3, vr: rand(-10, 10) });
  }

  private blood(x: number, y: number, n: number, power: number) {
    const colors = ['#b3121f', '#8e0f1a', '#d4202f', '#5e0a12'];
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const sp = rand(60, 320) * power;
      this.addParticle(x, y, Math.cos(a) * sp, Math.sin(a) * sp - 120 * power, rand(0.35, 0.8), rand(1.5, 4.5) * power, colors[(Math.random() * colors.length) | 0], 1100, 0.985, 0);
    }
    // mist
    for (let i = 0; i < 3; i++) this.addParticle(x, y, rand(-30, 30), rand(-40, 10), rand(0.4, 0.7), rand(8, 16) * power, 'rgba(120,10,20,0.35)', 60, 0.95, 1);
  }

  private puff(x: number, y: number, n: number, color: string, power: number) {
    for (let i = 0; i < n; i++) {
      this.addParticle(x, y, rand(-70, 70) * power, rand(-90, -10) * power, rand(0.4, 0.9), rand(5, 12) * power, color, -40, 0.94, 1);
    }
  }

  private spawnShell() {
    const x = this.crossX() + 40;
    const y = this.crossY() + 20;
    this.addParticle(x, y, rand(180, 320), rand(-260, -140), 0.9, 3, '#d8a94a', 1300, 0.995, 3);
  }

  private addText(x: number, y: number, text: string, color: string, size: number) {
    this.texts.push({ x, y, text, life: 1, max: 1, color, size });
    if (this.texts.length > 20) this.texts.shift();
  }

  private setAnnounce(text: string, dur: number, color: string) {
    this.announce = { text, life: dur, max: dur, color };
  }

  // ---------- Projection ----------
  private parallaxX() {
    return -(this.aimX - this.W / 2) * 0.06;
  }
  private parallaxY() {
    return -(this.aimY - this.H / 2) * 0.03;
  }

  private F() {
    return (this.H - this.horizonY) / CAM_H;
  }

  private projectZombie(z: Zombie) {
    const F = this.F();
    z.sx = this.W / 2 + this.parallaxX() + (z.x * this.W * 0.45) / z.d;
    z.sy = this.horizonY + this.parallaxY() + (F * CAM_H) / z.d;
    z.hpx = (1.7 * F * z.size) / z.d;
  }

  private crossX() {
    return this.aimX + this.recoilX + Math.sin(this.time * 1.3) * 2.5;
  }
  private crossY() {
    return this.aimY + this.recoilY + Math.cos(this.time * 0.9) * 2;
  }

  // ---------- Update ----------
  private loop = (ts: number) => {
    if (!this.running && !this.over && !this.attractMode) return;
    const raw = Math.min(0.05, (ts - this.lastTs) / 1000);
    this.lastTs = ts;
    if (this.attractMode) this.updateAttract(raw);
    else if (!this.paused) this.update(raw);
    this.renderFrame();
    this.rafId = requestAnimationFrame(this.loop);
  };

  private update(raw: number) {
    // hitstop slows the world but not UI feel
    let scale = 1;
    if (this.hitstop > 0) {
      this.hitstop -= raw;
      scale = 0.12;
    }
    const dt = raw * scale;
    if (!this.over) this.time += dt;

    // keyboard aim
    const k = this.keys;
    let ix = 0;
    let iy = 0;
    if (k.has('arrowleft') || k.has('a')) ix -= 1;
    if (k.has('arrowright') || k.has('d')) ix += 1;
    if (k.has('arrowup') || k.has('w')) iy -= 1;
    if (k.has('arrowdown') || k.has('s')) iy += 1;
    const slow = k.has('shift');
    const sp = Math.min(this.W, this.H) * (slow ? 0.45 : 1.25);
    const tvx = ix * sp;
    const tvy = iy * sp;
    const sm = 1 - Math.exp(-raw * 18);
    this.aimVX = lerp(this.aimVX, tvx, sm);
    this.aimVY = lerp(this.aimVY, tvy, sm);
    this.aimX = clamp(this.aimX + this.aimVX * raw, 0, this.W);
    this.aimY = clamp(this.aimY + this.aimVY * raw, 0, this.H);

    // recoil recovery
    const rr = Math.exp(-raw * 9);
    this.recoilX *= rr;
    this.recoilY *= rr;

    // shake
    this.trauma = Math.max(0, this.trauma - raw * 1.8);
    const sh = this.trauma * this.trauma;
    const mag = Math.min(this.W, this.H) * 0.03;
    this.shakeX = sh * mag * rand(-1, 1);
    this.shakeY = sh * mag * rand(-1, 1);
    this.shakeRot = sh * 0.025 * rand(-1, 1);

    this.whiteFlash = Math.max(0, this.whiteFlash - raw * 4);
    this.redFlash = Math.max(0, this.redFlash - raw * 1.6);
    this.muzzle = Math.max(0, this.muzzle - raw * 12);
    this.comboPulse = Math.max(0, this.comboPulse - raw * 3);
    this.damagePulse = Math.max(0, this.damagePulse - raw * 2);
    this.lowHealthT += raw;
    if (this.tracer) {
      this.tracer.life -= raw * 10;
      if (this.tracer.life <= 0) this.tracer = null;
    }
    if (this.announce) {
      this.announce.life -= raw;
      if (this.announce.life <= 0) this.announce = null;
    }

    // weapon timers
    if (this.boltT > 0) {
      this.boltT -= raw;
      if (this.boltT <= 0 && this.ammo <= 0 && !this.over) this.reload();
    }
    if (this.reloading) {
      this.reloadT -= raw;
      if (this.reloadT <= 0) {
        this.reloading = false;
        this.ammo = MAG;
        audio.reloadEnd();
      }
    }

    if (this.over) {
      this.updateParticles(dt);
      return;
    }

    // spawning
    this.spawnTimer -= dt;
    const alive = this.zombies.filter((z) => z.state !== 'die').length;
    const maxAlive = Math.min(13, 3 + Math.floor(this.time / 14));
    if (this.spawnTimer <= 0 && alive < maxAlive) {
      this.spawn(this.pickType());
      const interval = Math.max(0.55, 2.3 - this.time * 0.014);
      this.spawnTimer = interval * rand(0.7, 1.3);
      if (Math.random() < 0.5) audio.moan();
    }

    // zombies
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      z.flash = Math.max(0, z.flash - raw * 8);
      if (z.state === 'walk') {
        z.d -= z.speed * dt;
        z.x += (z.targetX - z.x) * dt * 0.18;
        z.phase += dt * (z.type === 'runner' ? 11 : z.type === 'brute' ? 4.5 : 6.5);
        if (z.d < 2.6 && !z.moaned) {
          z.moaned = true;
          audio.moan();
        }
        if (z.d <= ATTACK_D) {
          z.state = 'attack';
          z.t = 0;
          z.d = ATTACK_D;
        }
      } else if (z.state === 'attack') {
        z.t += dt;
        if (z.t >= 0.18 && z.hp > 0) {
          z.hp = 0; // mark as spent
          this.takeDamage(z);
        }
        if (z.t >= 0.45) {
          this.zombies.splice(i, 1);
          continue;
        }
      } else {
        z.t += dt;
        if (z.dieKind === 'head' && z.t < 0.25) {
          const nx = z.sx;
          const ny = z.sy - z.hpx * 0.78;
          this.addParticle(nx, ny, rand(-60, 60), rand(-340, -180) * (z.hpx / 120 + 0.5), rand(0.4, 0.7), rand(2, 4), '#b3121f', 1100, 0.985, 0);
        }
        if (z.t >= 0.75) {
          this.zombies.splice(i, 1);
          continue;
        }
      }
      this.projectZombie(z);
    }
    // sort far -> near for drawing
    this.zombies.sort((a, b) => b.d - a.d);

    this.updateParticles(dt);

    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt * 1.1;
      t.y -= dt * 40;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
    for (let i = this.decals.length - 1; i >= 0; i--) {
      this.decals[i].life -= dt * 0.045;
      if (this.decals[i].life <= 0) this.decals.splice(i, 1);
    }
    for (let i = this.claws.length - 1; i >= 0; i--) {
      this.claws[i].life -= raw * 0.7;
      if (this.claws[i].life <= 0) this.claws.splice(i, 1);
    }
  }

  private updateParticles(dt: number) {
    const ground = this.H + 20;
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0 || p.y > ground) {
        this.particles[i] = this.particles[this.particles.length - 1];
        this.particles.pop();
        continue;
      }
      p.vy += p.grav * dt;
      p.vx *= p.drag;
      p.vy *= p.drag;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      if (p.kind === 1) p.size += dt * 18;
    }
  }

  // ---------- Render ----------
  renderFrame() {
    const { ctx, W, H } = this;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);

    // world + scope shake together
    ctx.save();
    const boltDip = this.boltT > 0 ? Math.sin((1 - this.boltT / BOLT_TIME) * Math.PI) * 12 : 0;
    const reloadDip = this.reloading ? Math.sin((1 - this.reloadT / RELOAD_TIME) * Math.PI) * 44 : 0;
    ctx.translate(W / 2 + this.shakeX, H / 2 + this.shakeY + boltDip + reloadDip);
    ctx.rotate(this.shakeRot + (this.reloading ? Math.sin((1 - this.reloadT / RELOAD_TIME) * Math.PI) * 0.02 : 0));
    ctx.translate(-W / 2, -H / 2);

    this.drawSky();
    this.drawGround();
    this.drawDecals();
    this.drawScenery();
    for (const z of this.zombies) this.drawZombie(z);
    this.drawParticles();
    this.drawTracer();
    this.drawTexts();
    this.drawScope();
    ctx.restore();

    this.drawFlashes();
    this.drawHUD();
  }

  private drawSky() {
    const { ctx, W, H, horizonY } = this;
    const g = ctx.createLinearGradient(0, 0, 0, horizonY);
    g.addColorStop(0, '#04070a');
    g.addColorStop(0.6, '#0e1a18');
    g.addColorStop(1, '#3a2a20');
    ctx.fillStyle = g;
    ctx.fillRect(-60, -60, W + 120, horizonY + 60);
    // stars
    ctx.fillStyle = '#cfe8d8';
    for (const s of this.stars) {
      const a = 0.35 + 0.5 * Math.abs(Math.sin(this.time * 0.8 + s.tw));
      ctx.globalAlpha = a;
      ctx.fillRect(s.x, s.y, s.r, s.r);
    }
    ctx.globalAlpha = 1;
    // blood moon
    const mx = W * 0.72;
    const my = horizonY * 0.38;
    const mr = Math.min(W, H) * 0.075;
    const glow = ctx.createRadialGradient(mx, my, mr * 0.6, mx, my, mr * 3.2);
    glow.addColorStop(0, 'rgba(255,110,60,0.35)');
    glow.addColorStop(1, 'rgba(255,110,60,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(mx - mr * 3.2, my - mr * 3.2, mr * 6.4, mr * 6.4);
    const mg = ctx.createRadialGradient(mx - mr * 0.3, my - mr * 0.3, mr * 0.1, mx, my, mr);
    mg.addColorStop(0, '#ffd2a8');
    mg.addColorStop(1, '#c8623a');
    ctx.fillStyle = mg;
    ctx.beginPath();
    ctx.arc(mx, my, mr, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(120,50,30,0.35)';
    ctx.beginPath();
    ctx.arc(mx + mr * 0.3, my + mr * 0.2, mr * 0.22, 0, Math.PI * 2);
    ctx.arc(mx - mr * 0.35, my + mr * 0.4, mr * 0.14, 0, Math.PI * 2);
    ctx.arc(mx - mr * 0.1, my - mr * 0.45, mr * 0.1, 0, Math.PI * 2);
    ctx.fill();
    // hills
    for (const h of this.hills) {
      ctx.fillStyle = h.color;
      ctx.beginPath();
      ctx.moveTo(-60, horizonY + 10);
      for (let i = 0; i < h.pts.length; i += 2) ctx.lineTo(h.pts[i], h.pts[i + 1]);
      ctx.lineTo(W + 60, horizonY + 10);
      ctx.closePath();
      ctx.fill();
    }
  }

  private drawGround() {
    const { ctx, W, H, horizonY } = this;
    const g = ctx.createLinearGradient(0, horizonY, 0, H);
    g.addColorStop(0, '#2a3326');
    g.addColorStop(0.25, '#1c251a');
    g.addColorStop(1, '#0d120c');
    ctx.fillStyle = g;
    ctx.fillRect(-60, horizonY, W + 120, H - horizonY + 60);
    // fog band
    const fg = ctx.createLinearGradient(0, horizonY - 14, 0, horizonY + H * 0.12);
    fg.addColorStop(0, 'rgba(150,170,140,0.22)');
    fg.addColorStop(1, 'rgba(150,170,140,0)');
    ctx.fillStyle = fg;
    ctx.fillRect(-60, horizonY - 14, W + 120, H * 0.12 + 14);
    // faint distance lines
    ctx.strokeStyle = 'rgba(90,110,80,0.12)';
    ctx.lineWidth = 1;
    const F = this.F();
    for (let d = 1.4; d < 9; d *= 1.35) {
      const y = horizonY + this.parallaxY() + (F * CAM_H) / d;
      ctx.beginPath();
      ctx.moveTo(-60, y);
      ctx.lineTo(W + 60, y);
      ctx.stroke();
    }
  }

  private drawScenery() {
    const { ctx, W, horizonY } = this;
    const F = this.F();
    const px = this.parallaxX();
    const py = this.parallaxY();
    // dead trees
    for (const t of this.trees) {
      const sx = W / 2 + px + (t.x * W * 0.45) / t.d;
      const sy = horizonY + py + (F * CAM_H) / t.d;
      const h = (t.h * F) / t.d;
      const w = Math.max(2, h * 0.06);
      ctx.strokeStyle = '#070a07';
      ctx.lineCap = 'round';
      ctx.lineWidth = w;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + Math.sin(t.seed) * h * 0.1, sy - h);
      ctx.stroke();
      ctx.lineWidth = w * 0.5;
      for (let b = 0; b < 3; b++) {
        const by = sy - h * (0.45 + b * 0.18);
        const dir = b % 2 === 0 ? 1 : -1;
        ctx.beginPath();
        ctx.moveTo(sx, by);
        ctx.lineTo(sx + dir * h * 0.28, by - h * 0.22);
        ctx.stroke();
      }
    }
    // fence line
    const fd = 3.3;
    const fy = horizonY + py + (F * CAM_H) / fd;
    const fh = (1.1 * F) / fd;
    ctx.strokeStyle = '#0a0d09';
    ctx.lineWidth = Math.max(1.5, fh * 0.08);
    for (let x = -3; x <= 3; x += 0.45) {
      const sx = W / 2 + px + (x * W * 0.45) / fd;
      ctx.beginPath();
      ctx.moveTo(sx, fy);
      ctx.lineTo(sx, fy - fh);
      ctx.stroke();
    }
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(10,13,9,0.8)';
    for (let r = 0.35; r <= 0.95; r += 0.3) {
      ctx.beginPath();
      ctx.moveTo(W / 2 + px + (-3 * W * 0.45) / fd, fy - fh * r);
      ctx.lineTo(W / 2 + px + (3 * W * 0.45) / fd, fy - fh * r + 2);
      ctx.stroke();
    }
  }

  private drawDecals() {
    const { ctx, W, horizonY } = this;
    const F = this.F();
    const px = this.parallaxX();
    const py = this.parallaxY();
    for (const d of this.decals) {
      const x = W / 2 + px + (d.wx * W * 0.45) / d.wd;
      const y = horizonY + py + (F * CAM_H) / d.wd;
      const hpx = (1.7 * F * d.size) / d.wd;
      const rx = hpx * 0.4;
      const ry = hpx * 0.1;
      ctx.globalAlpha = Math.min(0.7, d.life);
      ctx.fillStyle = '#4a0810';
      ctx.beginPath();
      ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
      ctx.ellipse(x + rx * 0.5 * Math.sin(d.seed), y + ry * 0.6, rx * 0.5, ry * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  private drawZombie(z: Zombie) {
    const { ctx } = this;
    const cfg = TYPES[z.type];
    const h = z.hpx;
    if (h < 2) return;
    ctx.save();
    ctx.translate(z.sx, z.sy);

    // ground shadow
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(0, 0, h * 0.22, h * 0.05, 0, 0, Math.PI * 2);
    ctx.fill();

    let alpha = 1;
    if (z.state === 'die') {
      const t = z.t / 0.75;
      const fall = easeOut(Math.min(1, t * 1.5));
      ctx.rotate(fall * 1.5 * z.dieDir);
      alpha = t > 0.6 ? 1 - (t - 0.6) / 0.4 : 1;
    } else if (z.state === 'attack') {
      const t = z.t / 0.45;
      const s = 1 + t * 1.6;
      ctx.scale(s, s);
      alpha = 1 - t * t;
    }
    ctx.globalAlpha = alpha;

    const w = cfg.wobble;
    const sway = Math.sin(z.phase) * 0.07 * w;
    const bob = Math.abs(Math.sin(z.phase)) * h * 0.025;
    ctx.rotate(sway * 0.6);
    ctx.translate(0, -bob);

    const fl = z.flash;
    const skin = fl > 0 ? mix(cfg.skin, '#ffffff', fl) : cfg.skin;
    const cloth = fl > 0 ? mix(cfg.cloth, '#ffffff', fl) : cfg.cloth;
    const torsoW = h * 0.3 * (z.type === 'brute' ? 1.25 : 1);

    // legs
    ctx.fillStyle = mix(cloth, '#000000', 0.25);
    const legSwing = Math.sin(z.phase) * h * 0.08 * w;
    roundRect(ctx, -torsoW * 0.42 + legSwing * 0.5, -h * 0.45, torsoW * 0.36, h * 0.46, h * 0.03);
    roundRect(ctx, torsoW * 0.06 - legSwing * 0.5, -h * 0.45, torsoW * 0.36, h * 0.46, h * 0.03);

    // torso
    ctx.fillStyle = cloth;
    roundRect(ctx, -torsoW / 2, -h * 0.8, torsoW, h * 0.4, h * 0.04);
    // tattered shirt highlight
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    ctx.fillRect(-torsoW / 2, -h * 0.8, torsoW * 0.35, h * 0.4);

    // arms (reaching forward -> appear angled outward/down)
    ctx.strokeStyle = skin;
    ctx.lineCap = 'round';
    ctx.lineWidth = Math.max(1.5, h * 0.06);
    const armSwing = Math.sin(z.phase * 2) * h * 0.05 * w;
    ctx.beginPath();
    ctx.moveTo(-torsoW / 2, -h * 0.74);
    ctx.lineTo(-torsoW * 0.95, -h * 0.55 + armSwing);
    ctx.moveTo(torsoW / 2, -h * 0.74);
    ctx.lineTo(torsoW * 0.95, -h * 0.55 - armSwing);
    ctx.stroke();
    // hands
    ctx.fillStyle = skin;
    ctx.beginPath();
    ctx.arc(-torsoW * 0.95, -h * 0.55 + armSwing, h * 0.035, 0, Math.PI * 2);
    ctx.arc(torsoW * 0.95, -h * 0.55 - armSwing, h * 0.035, 0, Math.PI * 2);
    ctx.fill();

    // head
    const headR = h * 0.12;
    const headY = -h * 0.88;
    if (!(z.state === 'die' && z.dieKind === 'head')) {
      ctx.fillStyle = skin;
      ctx.beginPath();
      ctx.arc(0, headY, headR, 0, Math.PI * 2);
      ctx.fill();
      // jaw shade
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.beginPath();
      ctx.arc(0, headY + headR * 0.45, headR * 0.75, 0, Math.PI);
      ctx.fill();
      // eyes
      if (h > 14) {
        ctx.fillStyle = cfg.eye;
        ctx.shadowColor = cfg.eye;
        ctx.shadowBlur = h > 60 ? 6 : 0;
        const ex = headR * 0.4;
        const ey = headY - headR * 0.1;
        const er = Math.max(1, headR * 0.17);
        ctx.fillRect(-ex - er, ey - er, er * 2, er * 2);
        ctx.fillRect(ex - er, ey - er, er * 2, er * 2);
        ctx.shadowBlur = 0;
      }
    } else {
      // neck stump
      ctx.fillStyle = '#7a0d16';
      ctx.beginPath();
      ctx.arc(0, -h * 0.79, headR * 0.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // brute HP bar
    if (z.type === 'brute' && z.hp < z.maxHp && z.state === 'walk') {
      const bw = h * 0.5;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(-bw / 2, headY - headR - h * 0.08, bw, h * 0.03);
      ctx.fillStyle = '#ff3b3b';
      ctx.fillRect(-bw / 2, headY - headR - h * 0.08, (bw * z.hp) / z.maxHp, h * 0.03);
    }

    ctx.restore();
  }

  private drawParticles() {
    const { ctx } = this;
    for (const p of this.particles) {
      const a = clamp(p.life / p.max, 0, 1);
      if (p.kind === 1) {
        ctx.globalAlpha = a * 0.5;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === 3) {
        ctx.globalAlpha = 1;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.fillRect(-4, -1.5, 8, 3);
        ctx.fillStyle = '#8a6a2a';
        ctx.fillRect(2, -1.5, 2, 3);
        ctx.restore();
      } else {
        ctx.globalAlpha = p.kind === 2 ? a : Math.min(1, a * 1.5);
        ctx.fillStyle = p.color;
        const s = p.size;
        ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawTracer() {
    const { ctx, W, H } = this;
    if (this.tracer) {
      const t = this.tracer;
      const a = clamp(t.life, 0, 1);
      ctx.globalAlpha = a * 0.6;
      ctx.strokeStyle = '#fff4c2';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(W * 0.78, H + 30);
      ctx.lineTo(t.x, t.y);
      ctx.stroke();
      ctx.globalAlpha = a;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(t.x, t.y, 3 + (1 - a) * 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    if (this.muzzle > 0) {
      const g = ctx.createRadialGradient(W * 0.78, H + 20, 0, W * 0.78, H + 20, Math.min(W, H) * 0.5);
      g.addColorStop(0, `rgba(255,220,140,${0.55 * this.muzzle})`);
      g.addColorStop(1, 'rgba(255,180,80,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
  }

  private drawTexts() {
    const { ctx } = this;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const t of this.texts) {
      const a = clamp(t.life / t.max, 0, 1);
      const pop = 1 + (1 - Math.min(1, (1 - a) * 6)) * 0.6;
      ctx.globalAlpha = a;
      ctx.font = `${Math.round(t.size * pop)}px ${HEAD_FONT}`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(0,0,0,0.8)';
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;
  }

  private drawScope() {
    const { ctx, W, H } = this;
    const cx = this.crossX();
    const cy = this.crossY();
    const R = clamp(Math.min(W, H) * 0.31, 110, 330);

    // outside dim
    ctx.fillStyle = 'rgba(2,6,4,0.72)';
    ctx.beginPath();
    ctx.rect(-200, -200, W + 400, H + 400);
    ctx.arc(cx, cy, R, 0, Math.PI * 2, true);
    ctx.fill();

    // glass vignette + tint
    const g = ctx.createRadialGradient(cx, cy, R * 0.55, cx, cy, R);
    g.addColorStop(0, 'rgba(140,255,160,0.04)');
    g.addColorStop(1, 'rgba(0,10,5,0.5)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fill();
    // glass glint
    ctx.strokeStyle = 'rgba(180,255,200,0.12)';
    ctx.lineWidth = R * 0.05;
    ctx.beginPath();
    ctx.arc(cx, cy, R * 0.88, Math.PI * 1.1, Math.PI * 1.45);
    ctx.stroke();

    // ring
    ctx.strokeStyle = '#05080a';
    ctx.lineWidth = R * 0.09;
    ctx.beginPath();
    ctx.arc(cx, cy, R + R * 0.04, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(157,255,122,0.35)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, R + R * 0.085, 0, Math.PI * 2);
    ctx.stroke();

    // reticle
    const gap = R * 0.09;
    ctx.strokeStyle = 'rgba(0,0,0,0.9)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(cx - R, cy);
    ctx.lineTo(cx - gap, cy);
    ctx.moveTo(cx + gap, cy);
    ctx.lineTo(cx + R, cy);
    ctx.moveTo(cx, cy - R);
    ctx.lineTo(cx, cy - gap);
    ctx.moveTo(cx, cy + gap);
    ctx.lineTo(cx, cy + R);
    ctx.stroke();
    // thick posts
    ctx.lineWidth = R * 0.05;
    ctx.beginPath();
    ctx.moveTo(cx - R, cy);
    ctx.lineTo(cx - R * 0.5, cy);
    ctx.moveTo(cx + R, cy);
    ctx.lineTo(cx + R * 0.5, cy);
    ctx.moveTo(cx, cy + R);
    ctx.lineTo(cx, cy + R * 0.5);
    ctx.stroke();
    // mil dots
    ctx.fillStyle = 'rgba(0,0,0,0.9)';
    for (let i = 1; i <= 3; i++) {
      const o = gap + i * R * 0.13;
      ctx.fillRect(cx - o - 1.5, cy - 4, 3, 8);
      ctx.fillRect(cx + o - 1.5, cy - 4, 3, 8);
      ctx.fillRect(cx - 4, cy - o - 1.5, 8, 3);
      ctx.fillRect(cx - 4, cy + o - 1.5, 8, 3);
    }
    // center dot
    ctx.fillStyle = '#ff2e2e';
    ctx.shadowColor = '#ff2e2e';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(cx, cy, 2.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // range readout: nearest zombie under reticle
    let target: Zombie | null = null;
    for (const z of this.zombies) {
      if (z.state !== 'walk') continue;
      const hw = Math.max(10, z.hpx * 0.25);
      if (Math.abs(cx - z.sx) < hw && cy > z.sy - z.hpx * 1.05 && cy < z.sy + 4) target = z;
    }
    ctx.font = `${Math.max(10, R * 0.075)}px ${MONO_FONT}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = target ? '#ff6b6b' : 'rgba(157,255,122,0.8)';
    const label = target ? `TGT ${Math.round(target.d * 12)}m` : `RNG ---`;
    ctx.fillText(label, cx, cy + R * 0.3);
    if (target) {
      // target bracket
      ctx.strokeStyle = 'rgba(255,90,90,0.9)';
      ctx.lineWidth = 1.5;
      const bw = Math.max(14, target.hpx * 0.35);
      const top = target.sy - target.hpx * 1.02;
      const bot = target.sy + 2;
      const l = target.sx - bw;
      const r = target.sx + bw;
      const c = Math.min(8, bw * 0.4);
      ctx.beginPath();
      ctx.moveTo(l, top + c);
      ctx.lineTo(l, top);
      ctx.lineTo(l + c, top);
      ctx.moveTo(r - c, top);
      ctx.lineTo(r, top);
      ctx.lineTo(r, top + c);
      ctx.moveTo(l, bot - c);
      ctx.lineTo(l, bot);
      ctx.lineTo(l + c, bot);
      ctx.moveTo(r - c, bot);
      ctx.lineTo(r, bot);
      ctx.lineTo(r, bot - c);
      ctx.stroke();
    }
  }

  private drawFlashes() {
    const { ctx, W, H } = this;
    if (this.whiteFlash > 0) {
      ctx.fillStyle = `rgba(255,245,220,${this.whiteFlash * 0.5})`;
      ctx.fillRect(0, 0, W, H);
    }
    // claw marks
    for (const c of this.claws) {
      ctx.save();
      ctx.translate(c.x, c.y);
      ctx.rotate(c.angle);
      ctx.globalAlpha = Math.min(1, c.life * 1.5);
      ctx.strokeStyle = '#c8101c';
      ctx.lineCap = 'round';
      for (let i = -1; i <= 1; i++) {
        ctx.lineWidth = 6 + (1 - c.life) * 4;
        ctx.beginPath();
        ctx.moveTo(-c.len / 2, i * 26);
        ctx.quadraticCurveTo(0, i * 26 - 10, c.len / 2, i * 26);
        ctx.stroke();
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    if (this.redFlash > 0) {
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.2, W / 2, H / 2, Math.max(W, H) * 0.7);
      g.addColorStop(0, `rgba(180,0,10,${this.redFlash * 0.25})`);
      g.addColorStop(1, `rgba(180,0,10,${this.redFlash * 0.85})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    // low health pulse
    if (this.health <= 2 && this.health > 0 && this.running) {
      const p = 0.25 + 0.2 * Math.sin(this.lowHealthT * 5);
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
      g.addColorStop(0, 'rgba(140,0,10,0)');
      g.addColorStop(1, `rgba(140,0,10,${p})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    if (this.over) {
      ctx.fillStyle = 'rgba(40,0,0,0.5)';
      ctx.fillRect(0, 0, W, H);
    }
  }

  private drawHUD() {
    const { ctx, W, H } = this;
    if (!this.running && !this.over) return;
    const small = W < 520;
    const pad = small ? 12 : 22;
    ctx.textBaseline = 'top';

    // Score
    ctx.textAlign = 'left';
    ctx.font = `${small ? 10 : 12}px ${MONO_FONT}`;
    ctx.fillStyle = 'rgba(157,255,122,0.7)';
    ctx.fillText('SCORE', pad, pad);
    ctx.font = `${small ? 26 : 36}px ${HEAD_FONT}`;
    ctx.fillStyle = GREEN;
    ctx.shadowColor = 'rgba(157,255,122,0.5)';
    ctx.shadowBlur = 10;
    ctx.fillText(this.score.toLocaleString(), pad, pad + (small ? 12 : 14));
    ctx.shadowBlur = 0;
    // combo
    if (this.combo >= 2) {
      const mult = this.multiplier();
      const pulse = 1 + this.comboPulse * 0.35;
      ctx.save();
      ctx.translate(pad, pad + (small ? 44 : 58));
      ctx.scale(pulse, pulse);
      ctx.font = `${small ? 14 : 18}px ${HEAD_FONT}`;
      ctx.fillStyle = mult > 1 ? AMBER : '#dfe8d8';
      ctx.fillText(`x${mult}  ${this.combo} COMBO`, 0, 0);
      ctx.restore();
      // bar to next multiplier
      const prog = (this.combo % 3) / 3;
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(pad, pad + (small ? 64 : 84), small ? 90 : 120, 4);
      ctx.fillStyle = AMBER;
      ctx.fillRect(pad, pad + (small ? 64 : 84), (small ? 90 : 120) * (mult >= 5 ? 1 : prog), 4);
    }

    // Health (right top)
    const hs = small ? 18 : 24;
    for (let i = 0; i < MAX_HEALTH; i++) {
      const x = W - pad - hs - i * (hs + 6);
      const y = pad + 2;
      const alive = i < this.health;
      const wob = alive && this.damagePulse > 0 ? Math.sin(this.lowHealthT * 40) * this.damagePulse * 3 : 0;
      drawHeart(ctx, x + hs / 2 + wob, y + hs / 2, hs, alive ? '#ff3b4a' : 'rgba(255,255,255,0.12)', alive);
    }

    // Ammo (bottom-left)
    const by = H - pad - (small ? 22 : 28);
    const bw = small ? 9 : 12;
    const bh = small ? 22 : 28;
    for (let i = 0; i < MAG; i++) {
      const x = pad + i * (bw + 6);
      const loaded = i < this.ammo;
      ctx.globalAlpha = loaded ? 1 : 0.18;
      ctx.fillStyle = '#d8a94a';
      roundRect(ctx, x, by + bh * 0.3, bw, bh * 0.7, 2);
      ctx.fillStyle = '#c86f3a';
      ctx.beginPath();
      ctx.moveTo(x, by + bh * 0.32);
      ctx.quadraticCurveTo(x + bw / 2, by - bh * 0.1, x + bw, by + bh * 0.32);
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.font = `${small ? 10 : 12}px ${MONO_FONT}`;
    ctx.textAlign = 'left';
    if (this.reloading) {
      const p = 1 - this.reloadT / RELOAD_TIME;
      ctx.fillStyle = AMBER;
      ctx.fillText('RELOADING', pad, by - 18);
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(pad, by - 6, 100, 3);
      ctx.fillStyle = AMBER;
      ctx.fillRect(pad, by - 6, 100 * p, 3);
    } else if (this.ammo === 0) {
      ctx.fillStyle = '#ff6b6b';
      ctx.fillText('EMPTY — R TO RELOAD', pad, by - 18);
    } else {
      ctx.fillStyle = 'rgba(157,255,122,0.6)';
      ctx.fillText(`${this.ammo}/${MAG}  .338`, pad, by - 18);
    }

    // Time + kills (bottom-center, clear of touch buttons)
    ctx.textAlign = 'center';
    ctx.font = `${small ? 16 : 20}px ${MONO_FONT}`;
    ctx.fillStyle = 'rgba(223,232,216,0.9)';
    const m = Math.floor(this.time / 60);
    const s = Math.floor(this.time % 60);
    ctx.fillText(`${m}:${s.toString().padStart(2, '0')}`, W / 2, H - pad - (small ? 30 : 36));
    ctx.font = `${small ? 10 : 12}px ${MONO_FONT}`;
    ctx.fillStyle = 'rgba(157,255,122,0.7)';
    ctx.fillText(`KILLS ${this.kills}   HS ${this.headshots}`, W / 2, H - pad - (small ? 10 : 12));

    // Announcement (top center)
    if (this.announce) {
      const a = this.announce;
      const t = 1 - a.life / a.max;
      const alpha = t < 0.1 ? t / 0.1 : t > 0.75 ? 1 - (t - 0.75) / 0.25 : 1;
      const scale = 1 + (1 - Math.min(1, t * 5)) * 0.5;
      ctx.save();
      ctx.translate(W / 2, H * 0.17);
      ctx.scale(scale, scale);
      ctx.globalAlpha = clamp(alpha, 0, 1);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = `${small ? 24 : 38}px ${HEAD_FONT}`;
      ctx.lineWidth = 6;
      ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      ctx.strokeText(a.text, 0, 0);
      ctx.fillStyle = a.color;
      ctx.shadowColor = a.color;
      ctx.shadowBlur = 16;
      ctx.fillText(a.text, 0, 0);
      ctx.restore();
    }
  }
}

// ---------- helpers ----------
function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
  ctx.fill();
}

function drawHeart(ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number, color: string, glow: boolean) {
  const s = size / 2;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.fillStyle = color;
  if (glow) {
    ctx.shadowColor = color;
    ctx.shadowBlur = 8;
  }
  ctx.beginPath();
  ctx.moveTo(0, s * 0.9);
  ctx.bezierCurveTo(-s * 1.1, s * 0.1, -s * 0.9, -s * 0.9, 0, -s * 0.35);
  ctx.bezierCurveTo(s * 0.9, -s * 0.9, s * 1.1, s * 0.1, 0, s * 0.9);
  ctx.fill();
  ctx.restore();
}

const colorCache = new Map<string, string>();
function mix(a: string, b: string, t: number): string {
  const key = `${a}|${b}|${(t * 20) | 0}`;
  const c = colorCache.get(key);
  if (c) return c;
  const pa = hex(a);
  const pb = hex(b);
  const r = Math.round(lerp(pa[0], pb[0], t));
  const g = Math.round(lerp(pa[1], pb[1], t));
  const bl = Math.round(lerp(pa[2], pb[2], t));
  const out = `rgb(${r},${g},${bl})`;
  colorCache.set(key, out);
  return out;
}
function hex(h: string): [number, number, number] {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
