import { COMBINATIONS, FRAGMENTS, getItemDef } from "@/data/fragments";
import { getLocation } from "@/data/locations";
import { JOURNAL } from "@/data/journal";
import { getPuzzle } from "@/data/puzzles";
import { STARS } from "@/data/constellation";
import type { HotspotDef, SaveState, TimeLayer } from "./types";

export function fillNames(text: string, names: SaveState["names"]): string {
  return text.split("Lohen").join(names.player).split("Esteban").join(names.searched);
}

export function isNight(internalFall: boolean): boolean {
  if (internalFall) return true;
  if (typeof Date === "undefined") return false;
  const h = new Date().getHours();
  return h >= 21 || h < 5;
}

export function hotspotVisible(
  hs: HotspotDef,
  state: SaveState,
  layer: TimeLayer,
  night: boolean,
): boolean {
  if (hs.layer && hs.layer !== layer) return false;
  if (hs.hideFlag && state.flags[hs.hideFlag]) return false;
  if (hs.requireFlag && !state.flags[hs.requireFlag]) return false;
  if (hs.requireItem && !state.inventory.includes(hs.requireItem)) return false;
  if (hs.nightOnly && !night) return false;
  return true;
}

export function deriveFlags(state: SaveState): Record<string, boolean> {
  const f = { ...state.flags };
  const has = (id: string) => state.inventory.includes(id) || Boolean(f[id]);

  if (f.solved_seuil) f.act2_unlocked = true;
  if (f.got_lune && f.solved_puits && f.solved_foret) f.traces_found = true;
  if (f.solved_camp) f.got_souvenir_flag = true;
  if (f.solved_rebuild) f.act3_mid = true;
  if (f.solved_anneaux) f.act4_unlocked = true;
  if (f.solved_miroir && f.solved_tour) f.act5_unlocked = true;
  if (f.act5_door) f.act6_unlocked = true;
  if (f.door_lien) f.act7_unlocked = true;
  if (f.false_reveal_done) f.act8_unlocked = true;
  if (has("cle_seuil")) {
    f.has_cle_seuil = true;
    f.act8_understood = true;
    f.act9_unlocked = true;
  }
  if (f.solved_final) f.act10_unlocked = true;
  if (has("lentille_passe")) f.has_lentille_passe = true;
  if (has("fragment_nuit")) f.has_fragment_nuit = true;
  if (has("lentille_naissante")) f.has_lentille_naissante = true;
  if (Object.keys(state.resonances).length > 0) f.resonance_any = true;
  if (f.got_nuit) f.has_fragment_nuit = true;
  if (f.chose_camp || f.chose_well) f.chose_act2 = true;
  if (f.got_compass && f.accepted_boussole) {
    /* ready to turn in */
  }
  return f;
}

export function deriveAct(flags: Record<string, boolean>): number {
  if (flags.act10_unlocked || flags.ending_started) return 10;
  if (flags.act9_unlocked) return 9;
  if (flags.act8_unlocked) return 8;
  if (flags.act7_unlocked) return 7;
  if (flags.act6_unlocked) return 6;
  if (flags.act5_unlocked) return 5;
  if (flags.act4_unlocked) return 4;
  if (flags.solved_rebuild || flags.obs_open) return 3;
  if (flags.act2_unlocked) return 2;
  return 1;
}

export function locationUnlocked(id: string, state: SaveState): boolean {
  const loc = getLocation(id);
  if (!loc) return false;
  if (state.discovered.includes(id) || state.locationId === id) return true;
  if (loc.act === 1) return true;
  const f = state.flags;
  if (loc.act === 2) return Boolean(f.act2_unlocked);
  if (["observatory"].includes(id)) return Boolean(f.solved_foret);
  if (["city_gate", "library", "market", "tower", "garden", "ruins"].includes(id))
    return Boolean(f.act4_unlocked);
  if (id === "sanctuary") return Boolean(f.solved_tour);
  if (id === "gates") return Boolean(f.act5_door);
  if (id === "fall_path") return Boolean(f.door_lien);
  if (id === "false_place") return Boolean(f.false_reveal_done);
  if (id === "last_sky") return Boolean(f.act9_unlocked);
  if (id === "last_room") return Boolean(f.solved_final);
  return Boolean(state.visits[id]);
}

export function matchCombination(ids: string[]): (typeof COMBINATIONS)[number] | undefined {
  const set = new Set(ids);
  return COMBINATIONS.find((c) => c.inputs.length === set.size && c.inputs.every((i) => set.has(i)));
}

export function relevantItems(locationId: string, inventory: string[]): string[] {
  const loc = getLocation(locationId);
  if (!loc) return [];
  const needed = new Set<string>();
  for (const hs of loc.hotspots) {
    if (hs.requireItem) needed.add(hs.requireItem);
    if (hs.action.type === "use") needed.add(hs.action.itemId);
    if (hs.action.type === "puzzle") {
      const p = getPuzzle(hs.action.puzzleId);
      p?.requiredFragments?.forEach((i) => needed.add(i));
      p?.requiredItems?.forEach((i) => needed.add(i));
    }
  }
  return inventory.filter((id) => needed.has(id));
}

export function nextHint(puzzleId: string, used: number): { text: string; level: number } | null {
  const p = getPuzzle(puzzleId);
  if (!p) return null;
  const level = Math.min(2, used);
  return { text: p.hints[level]!, level };
}

export function journalVisible(state: SaveState) {
  return JOURNAL.filter((e) => state.flags[e.requireFlag] || e.requireFlag === "game_started").map((e) => {
    const stage = Math.min(state.journalStage[e.id] ?? 0, e.stages.length - 1);
    const lockedArchive = e.id === "j_archive_locked" && !state.flags.ending_started;
    return {
      ...e,
      text: lockedArchive ? "Archive verrouillée." : e.stages[stage] ?? e.stages[0]!,
      locked: lockedArchive,
    };
  });
}

export function bumpJournal(state: SaveState, id: string): Record<string, number> {
  const def = JOURNAL.find((j) => j.id === id);
  if (!def) return state.journalStage;
  const cur = state.journalStage[id] ?? 0;
  const next = Math.min(def.stages.length - 1, cur + 1);
  return { ...state.journalStage, [id]: next };
}

export function setJournalMin(state: SaveState, id: string, min: number): Record<string, number> {
  const def = JOURNAL.find((j) => j.id === id);
  if (!def) return state.journalStage;
  const cur = state.journalStage[id] ?? 0;
  return { ...state.journalStage, [id]: Math.min(def.stages.length - 1, Math.max(cur, min)) };
}

export function itemLabel(id: string): string {
  return getItemDef(id)?.name ?? id;
}

export function starsUnlocked(flags: Record<string, boolean>): string[] {
  return STARS.filter((s) => flags[s.unlockFlag]).map((s) => s.id);
}

export function weatherFor(locationId: string, act: number): "clear" | "fog" | "wind" | "overcast" | "starfall" {
  const loc = getLocation(locationId);
  if (act >= 7 && act < 8) return "starfall";
  if (act >= 10) return "clear";
  return loc?.weather ?? "clear";
}

export function lohenLine(flag: string, act: number): string | null {
  if (flag === "solved_seuil") {
    return act < 8
      ? "Une première lumière. Ce n'est pas lui. C'est une direction."
      : "La première étoile était déjà un adieu.";
  }
  if (flag === "false_reveal_done") return "Trop tard. Encore.";
  if (flag === "solved_final") return "Tout ce que j'ai ramassé… c'était pour ouvrir ça.";
  return null;
}

export { FRAGMENTS };
