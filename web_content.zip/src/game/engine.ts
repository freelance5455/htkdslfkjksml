export const R = 18;
export const COLS_EVEN = 11;
export const ROW_H = Math.sqrt(3) * R;
export const BOARD_W = COLS_EVEN * 2 * R;
export const BOARD_H = 680;
export const SHOOTER_X = BOARD_W / 2;
export const SHOOTER_Y = BOARD_H - 46;
export const DEATH_Y = BOARD_H - 128;
export const BUBBLE_SPEED = 940;

export const PALETTE = [
  { core: "#ff4b6a", light: "#ffd5de", dark: "#c81e45" },
  { core: "#ff9f1c", light: "#ffe3b8", dark: "#e06a00" },
  { core: "#ffe14a", light: "#fff6c2", dark: "#e0b400" },
  { core: "#2ec27e", light: "#c9f6e0", dark: "#128a52" },
  { core: "#4c8dff", light: "#d6e6ff", dark: "#1d4ed8" },
  { core: "#b06bff", light: "#ead9ff", dark: "#7c3aed" },
] as const;

const SAVE_KEY = "bubble-pop-v1";

export type Phase = "menu" | "playing" | "paused" | "cleared" | "over";

export type Bubble = { row: number; col: number; color: number };

export type Flying = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: number;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  r: number;
};

export type Falling = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: number;
  life: number;
};

export type Popping = {
  x: number;
  y: number;
  color: number;
  life: number;
  max: number;
};

export type Floater = {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
};

export type GameState = {
  phase: Phase;
  bubbles: Bubble[];
  minRow: number;
  current: number;
  next: number;
  angle: number;
  flying: Flying | null;
  particles: Particle[];
  falling: Falling[];
  popping: Popping[];
  texts: Floater[];
  score: number;
  best: number;
  level: number;
  shotsLeft: number;
  shotsMax: number;
  lock: number;
  hitstop: number;
  shake: number;
  dropSlide: number;
  hint: boolean;
  rev: number;
  events: string[];
  time: number;
  reduced: boolean;
};

export type SaveData = { best: number; mute: boolean };

const EVEN_NB: ReadonlyArray<readonly [number, number]> = [
  [0, -1],
  [0, 1],
  [-1, -1],
  [-1, 0],
  [1, -1],
  [1, 0],
];

const ODD_NB: ReadonlyArray<readonly [number, number]> = [
  [0, -1],
  [0, 1],
  [-1, 0],
  [-1, 1],
  [1, 0],
  [1, 1],
];

export function parity(row: number): number {
  return ((row % 2) + 2) % 2;
}

export function colsFor(row: number): number {
  return parity(row) === 0 ? COLS_EVEN : COLS_EVEN - 1;
}

export function key(row: number, col: number): string {
  return row + "," + col;
}

export function cellPos(
  row: number,
  col: number,
  minRow: number,
): { x: number; y: number } {
  const vis = row - minRow;
  const odd = parity(row) === 1;
  const x = (odd ? 2 * R : R) + col * 2 * R;
  const y = R + vis * ROW_H;
  return { x, y };
}

export function neighborCells(
  row: number,
  col: number,
): { row: number; col: number }[] {
  const deltas = parity(row) === 1 ? ODD_NB : EVEN_NB;
  const out: { row: number; col: number }[] = [];
  for (const [dr, dc] of deltas) out.push({ row: row + dr, col: col + dc });
  return out;
}

export function clampAngle(angle: number): number {
  const min = -Math.PI + 0.16;
  const max = -0.16;
  if (angle < min) return min;
  if (angle > max) return max;
  return angle;
}

export function levelPlan(level: number): {
  colors: number;
  rows: number;
  shots: number;
} {
  const colors = Math.min(6, 4 + Math.floor((level - 1) / 3));
  const rows = Math.min(12, 8 + Math.floor((level - 1) / 2));
  const shots = Math.max(5, 8 - Math.floor((level - 1) / 3));
  return { colors, rows, shots };
}

export function freshState(): GameState {
  return {
    phase: "menu",
    bubbles: [],
    minRow: 0,
    current: 0,
    next: 1,
    angle: -Math.PI / 2,
    flying: null,
    particles: [],
    falling: [],
    popping: [],
    texts: [],
    score: 0,
    best: 0,
    level: 1,
    shotsLeft: 8,
    shotsMax: 8,
    lock: 0,
    hitstop: 0,
    shake: 0,
    dropSlide: 0,
    hint: true,
    rev: 0,
    events: [],
    time: 0,
    reduced: false,
  };
}

export function loadSave(): SaveData {
  if (typeof localStorage === "undefined") return { best: 0, mute: false };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { best: 0, mute: false };
    const parsed = JSON.parse(raw) as { best?: unknown; mute?: unknown };
    return {
      best: typeof parsed.best === "number" && parsed.best > 0 ? parsed.best : 0,
      mute: parsed.mute === true,
    };
  } catch {
    return { best: 0, mute: false };
  }
}

export function persist(best: number, mute: boolean) {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(
      SAVE_KEY,
      JSON.stringify({ version: 1, best, mute }),
    );
  } catch {
    /* ignore quota */
  }
}

function persistBest(best: number) {
  persist(best, loadSave().mute);
}

function pushEvent(state: GameState, name: string) {
  state.events.push(name);
  if (state.events.length > 24) state.events.shift();
}

export function drainEvents(state: GameState): string[] {
  const ev = state.events;
  state.events = [];
  return ev;
}

function pick(colors: number[]): number {
  return colors[Math.floor(Math.random() * colors.length)] ?? 0;
}

export function colorsOnBoard(state: GameState): number[] {
  const set = new Set<number>();
  for (const b of state.bubbles) set.add(b.color);
  return [...set].sort((a, b) => a - b);
}

function ensureColors(state: GameState) {
  const colors = colorsOnBoard(state);
  if (!colors.length) return;
  if (!colors.includes(state.current)) state.current = pick(colors);
  if (!colors.includes(state.next)) state.next = pick(colors);
}

function anchoredSet(state: GameState): Set<string> {
  const present = new Set(state.bubbles.map((b) => key(b.row, b.col)));
  const seen = new Set<string>();
  const queue: string[] = [];
  for (const b of state.bubbles) {
    if (b.row !== state.minRow) continue;
    const k = key(b.row, b.col);
    if (seen.has(k)) continue;
    seen.add(k);
    queue.push(k);
  }
  while (queue.length) {
    const cur = queue.pop() as string;
    const comma = cur.indexOf(",");
    const row = Number(cur.slice(0, comma));
    const col = Number(cur.slice(comma + 1));
    for (const nb of neighborCells(row, col)) {
      if (nb.col < 0 || nb.col >= colsFor(nb.row)) continue;
      const k = key(nb.row, nb.col);
      if (seen.has(k) || !present.has(k)) continue;
      seen.add(k);
      queue.push(k);
    }
  }
  return seen;
}

export function makeBoard(level: number): Bubble[] {
  const { colors, rows } = levelPlan(level);
  for (let attempt = 0; attempt < 8; attempt++) {
    const map = new Map<string, number>();
    for (let row = 0; row < rows; row++) {
      const n = colsFor(row);
      for (let col = 0; col < n; col++) {
        if (row === rows - 1 && col % 4 === 3) continue;
        let color = row === 0 ? col % colors : Math.floor(Math.random() * colors);
        if (row !== 0) {
          const friends: number[] = [];
          for (const nb of neighborCells(row, col)) {
            const v = map.get(key(nb.row, nb.col));
            if (v !== undefined) friends.push(v);
          }
          if (friends.length && Math.random() < 0.48) {
            color = friends[Math.floor(Math.random() * friends.length)] as number;
          }
          let guard = 0;
          while (guard < 6 && horizontalRun(map, row, col, color) >= 5) {
            color = (color + 1 + Math.floor(Math.random() * (colors - 1))) % colors;
            guard++;
          }
        }
        map.set(key(row, col), color);
      }
    }
    let bubbles: Bubble[] = [];
    for (const [k, color] of map) {
      const comma = k.indexOf(",");
      bubbles.push({
        row: Number(k.slice(0, comma)),
        col: Number(k.slice(comma + 1)),
        color,
      });
    }
    const probe = freshState();
    probe.bubbles = bubbles;
    probe.minRow = 0;
    const keep = anchoredSet(probe);
    bubbles = bubbles.filter((b) => keep.has(key(b.row, b.col)));
    if (bubbles.length >= rows * 7) return bubbles;
  }
  const fallback: Bubble[] = [];
  const plan = levelPlan(level);
  for (let row = 0; row < plan.rows; row++) {
    const n = colsFor(row);
    for (let col = 0; col < n; col++) {
      fallback.push({ row, col, color: (row + col) % plan.colors });
    }
  }
  return fallback;
}

function horizontalRun(
  map: Map<string, number>,
  row: number,
  col: number,
  color: number,
): number {
  let run = 1;
  for (let c = col - 1; c >= 0; c--) {
    if (map.get(key(row, c)) !== color) break;
    run++;
  }
  return run;
}

function bump(state: GameState) {
  state.rev++;
}

export function createMatch(): GameState {
  const saved = loadSave();
  const state = freshState();
  state.best = saved.best;
  state.bubbles = makeBoard(1);
  const colors = colorsOnBoard(state);
  state.current = pick(colors);
  state.next = pick(colors);
  const plan = levelPlan(1);
  state.shotsLeft = plan.shots;
  state.shotsMax = plan.shots;
  return state;
}

export function startLevel(state: GameState, mode: "new" | "next") {
  if (mode === "new") {
    state.score = 0;
    state.level = 1;
  } else {
    state.level += 1;
  }
  const plan = levelPlan(state.level);
  state.minRow = 0;
  state.bubbles = makeBoard(state.level);
  state.shotsLeft = plan.shots;
  state.shotsMax = plan.shots;
  state.flying = null;
  state.particles = [];
  state.falling = [];
  state.popping = [];
  state.texts = [];
  state.lock = 0;
  state.hitstop = 0;
  state.shake = 0;
  state.dropSlide = 0;
  state.angle = -Math.PI / 2;
  state.hint = mode === "new";
  const colors = colorsOnBoard(state);
  state.current = pick(colors);
  state.next = pick(colors);
  state.phase = "playing";
  bump(state);
}

export function togglePause(state: GameState) {
  if (state.phase === "playing") state.phase = "paused";
  else if (state.phase === "paused") state.phase = "playing";
  bump(state);
}

export function canShoot(state: GameState): boolean {
  return state.phase === "playing" && !state.flying && state.lock <= 0;
}

export function shoot(state: GameState): boolean {
  if (!canShoot(state)) return false;
  const ang = state.angle;
  state.flying = {
    x: SHOOTER_X,
    y: SHOOTER_Y,
    vx: Math.cos(ang) * BUBBLE_SPEED,
    vy: Math.sin(ang) * BUBBLE_SPEED,
    color: state.current,
  };
  const colors = colorsOnBoard(state);
  state.current = state.next;
  state.next = colors.length ? pick(colors) : state.next;
  state.hint = false;
  pushEvent(state, "shoot");
  bump(state);
  return true;
}

export function swapBalls(state: GameState) {
  if (!canShoot(state)) return;
  const tmp = state.current;
  state.current = state.next;
  state.next = tmp;
  pushEvent(state, "swap");
  bump(state);
}

export function aimAt(state: GameState, x: number, y: number) {
  if (state.phase !== "playing" && state.phase !== "paused") return;
  const dx = x - SHOOTER_X;
  const dy = y - SHOOTER_Y;
  if (dx * dx + dy * dy < R * R) return;
  state.angle = clampAngle(Math.atan2(dy, dx));
}

function colliding(
  bubbles: Bubble[],
  minRow: number,
  x: number,
  y: number,
): boolean {
  const limit = (2 * R - 1.25) * (2 * R - 1.25);
  for (const b of bubbles) {
    const p = cellPos(b.row, b.col, minRow);
    if (Math.abs(p.y - y) > 2 * R) continue;
    const dx = p.x - x;
    const dy = p.y - y;
    if (dx * dx + dy * dy <= limit) return true;
  }
  return false;
}

export function snapCell(
  bubbles: Bubble[],
  minRow: number,
  impactX: number,
  impactY: number,
  fromX: number,
  fromY: number,
): { row: number; col: number } | null {
  const occupied = new Set(bubbles.map((b) => key(b.row, b.col)));
  let hitRow = 0;
  let hitCol = 0;
  let hitD = Infinity;
  for (const b of bubbles) {
    const p = cellPos(b.row, b.col, minRow);
    const d = (p.x - impactX) ** 2 + (p.y - impactY) ** 2;
    if (d < hitD) {
      hitD = d;
      hitRow = b.row;
      hitCol = b.col;
    }
  }
  const hitBubble = bubbles.length > 0 && hitD <= (2 * R) ** 2;
  if (!hitBubble) {
    let best: { row: number; col: number } | null = null;
    let bestD = Infinity;
    const n = colsFor(minRow);
    for (let col = 0; col < n; col++) {
      if (occupied.has(key(minRow, col))) continue;
      const p = cellPos(minRow, col, minRow);
      const d = (p.x - fromX) ** 2 + (p.y - fromY) ** 2;
      if (d < bestD) {
        bestD = d;
        best = { row: minRow, col };
      }
    }
    return best;
  }
  let best: { row: number; col: number } | null = null;
  let bestD = Infinity;
  for (const nb of neighborCells(hitRow, hitCol)) {
    if (nb.row < minRow) continue;
    if (nb.col < 0 || nb.col >= colsFor(nb.row)) continue;
    if (occupied.has(key(nb.row, nb.col))) continue;
    const p = cellPos(nb.row, nb.col, minRow);
    const d = (p.x - fromX) ** 2 + (p.y - fromY) ** 2;
    if (d < bestD) {
      bestD = d;
      best = nb;
    }
  }
  return best;
}

export function aimPath(state: GameState): {
  points: { x: number; y: number }[];
  ghost: { row: number; col: number } | null;
} {
  const points: { x: number; y: number }[] = [];
  let x = SHOOTER_X;
  let y = SHOOTER_Y;
  let vx = Math.cos(state.angle);
  let vy = Math.sin(state.angle);
  const step = 9;
  let bounced = 0;
  let since = 0;
  for (let i = 0; i < 460; i++) {
    x += vx * step;
    y += vy * step;
    since += step;
    if (x < R) {
      x = R;
      vx = Math.abs(vx);
      bounced++;
    } else if (x > BOARD_W - R) {
      x = BOARD_W - R;
      vx = -Math.abs(vx);
      bounced++;
    }
    if (since >= 20) {
      points.push({ x, y });
      since = 0;
    }
    if (bounced > 5) break;
    if (y <= R || colliding(state.bubbles, state.minRow, x, y)) {
      const spd = Math.hypot(vx, vy) || 1;
      const ghost = snapCell(
        state.bubbles,
        state.minRow,
        x,
        y,
        x - (vx / spd) * R,
        y - (vy / spd) * R,
      );
      return { points, ghost };
    }
    if (y > BOARD_H) break;
  }
  return { points, ghost: null };
}

function burst(
  state: GameState,
  x: number,
  y: number,
  color: number,
  count: number,
) {
  const swatch = PALETTE[color] ?? PALETTE[0];
  for (let i = 0; i < count; i++) {
    const ang = Math.random() * Math.PI * 2;
    const spd = 70 + Math.random() * 220;
    state.particles.push({
      x,
      y,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd - 40,
      life: 0.35 + Math.random() * 0.35,
      max: 0.7,
      color: Math.random() < 0.35 ? swatch.light : swatch.core,
      r: 2 + Math.random() * 3.2,
    });
  }
  if (state.particles.length > 240) {
    state.particles.splice(0, state.particles.length - 240);
  }
}

function spawnPop(state: GameState, bubble: Bubble) {
  const p = cellPos(bubble.row, bubble.col, state.minRow);
  state.popping.push({
    x: p.x,
    y: p.y - state.dropSlide,
    color: bubble.color,
    life: 0.2,
    max: 0.2,
  });
  burst(state, p.x, p.y - state.dropSlide, bubble.color, 8);
}

function spawnFall(state: GameState, bubble: Bubble) {
  const p = cellPos(bubble.row, bubble.col, state.minRow);
  state.falling.push({
    x: p.x,
    y: p.y - state.dropSlide,
    vx: (Math.random() - 0.5) * 80,
    vy: 30 + Math.random() * 40,
    color: bubble.color,
    life: 1.4,
  });
}

function floatText(state: GameState, x: number, y: number, text: string) {
  state.texts.push({ x, y, text, life: 0.9, max: 0.9 });
}

function lowestY(state: GameState): number {
  let max = 0;
  for (const b of state.bubbles) {
    const y = cellPos(b.row, b.col, state.minRow).y;
    if (y > max) max = y;
  }
  return max;
}

function flood(
  state: GameState,
  row: number,
  col: number,
  color: number,
): string[] {
  const map = new Map<string, number>();
  for (const b of state.bubbles) map.set(key(b.row, b.col), b.color);
  const start = key(row, col);
  if (map.get(start) !== color) return [];
  const seen = new Set<string>([start]);
  const queue = [start];
  const out = [start];
  while (queue.length) {
    const cur = queue.pop() as string;
    const comma = cur.indexOf(",");
    const r = Number(cur.slice(0, comma));
    const c = Number(cur.slice(comma + 1));
    for (const nb of neighborCells(r, c)) {
      if (nb.col < 0 || nb.col >= colsFor(nb.row)) continue;
      const k = key(nb.row, nb.col);
      if (seen.has(k) || map.get(k) !== color) continue;
      seen.add(k);
      queue.push(k);
      out.push(k);
    }
  }
  return out;
}

function dropCeiling(state: GameState) {
  const row = state.minRow - 1;
  const colors = colorsOnBoard(state);
  const palette = colors.length ? colors : [0, 1, 2, 3];
  const n = colsFor(row);
  for (let col = 0; col < n; col++) {
    let color = pick(palette);
    for (const nb of neighborCells(row, col)) {
      const found = state.bubbles.find((b) => b.row === nb.row && b.col === nb.col);
      if (found && Math.random() < 0.45) {
        color = found.color;
        break;
      }
    }
    state.bubbles.push({ row, col, color });
  }
  state.minRow = row;
  state.dropSlide = ROW_H;
  state.lock = Math.max(state.lock, 0.26);
  pushEvent(state, "drop");
}

function missShot(state: GameState) {
  state.shotsLeft -= 1;
  if (state.shotsLeft <= 0) {
    dropCeiling(state);
    const plan = levelPlan(state.level);
    state.shotsLeft = plan.shots;
    state.shotsMax = plan.shots;
    ensureColors(state);
  }
  if (lowestY(state) > DEATH_Y) {
    state.phase = "over";
    pushEvent(state, "lose");
    if (state.score > state.best) state.best = state.score;
    persistBest(state.best);
  }
  bump(state);
}

export function settle(
  state: GameState,
  row: number,
  col: number,
  color: number,
) {
  state.bubbles.push({ row, col, color });
  const group = flood(state, row, col, color);
  let popped = 0;
  if (group.length >= 3) {
    const doomed = new Set(group);
    const stay: Bubble[] = [];
    for (const b of state.bubbles) {
      if (doomed.has(key(b.row, b.col))) {
        spawnPop(state, b);
        popped++;
      } else stay.push(b);
    }
    state.bubbles = stay;
  }

  const keep = anchoredSet(state);
  const stay: Bubble[] = [];
  const fallers: Bubble[] = [];
  for (const b of state.bubbles) {
    if (keep.has(key(b.row, b.col))) stay.push(b);
    else fallers.push(b);
  }
  state.bubbles = stay;
  for (const b of fallers) spawnFall(state, b);

  let gained = 0;
  if (popped >= 3) gained += popped * 10;
  gained += fallers.length * 25;
  if (popped >= 6) gained += 60;
  if (popped + fallers.length >= 10) gained += 120;
  state.score += gained;
  if (gained > 0) {
    const spot = cellPos(row, col, state.minRow);
    floatText(state, spot.x, spot.y - state.dropSlide, "+" + gained);
    const word =
      popped + fallers.length >= 10
        ? "Amazing!"
        : popped >= 6 || fallers.length >= 4
          ? "Super!"
          : popped >= 3
            ? "Pop!"
            : "";
    if (word) floatText(state, spot.x, spot.y - state.dropSlide - 26, word);
  }

  if (popped >= 3) {
    state.shake = state.reduced ? 0 : Math.min(1, 0.28 + popped * 0.05);
    state.hitstop = state.reduced ? 0 : Math.min(0.07, 0.02 + popped * 0.006);
    state.lock = Math.max(state.lock, 0.16);
    pushEvent(state, popped >= 6 ? "pop-big" : "pop");
  } else if (fallers.length) {
    state.shake = state.reduced ? 0 : 0.22;
    state.lock = Math.max(state.lock, 0.12);
    pushEvent(state, "fall");
  } else {
    state.lock = Math.max(state.lock, 0.05);
    pushEvent(state, "stick");
  }

  if (state.score > state.best) {
    state.best = state.score;
    persistBest(state.best);
  }
  ensureColors(state);

  if (state.bubbles.length === 0) {
    const bonus = 400 * state.level;
    state.score += bonus;
    if (state.score > state.best) state.best = state.score;
    persistBest(state.best);
    floatText(state, SHOOTER_X, BOARD_H * 0.42, "+" + bonus);
    burst(state, SHOOTER_X, BOARD_H * 0.35, color, 36);
    state.phase = "cleared";
    pushEvent(state, "win");
    bump(state);
    return;
  }

  state.shotsLeft -= 1;
  if (state.shotsLeft <= 0) {
    dropCeiling(state);
    const plan = levelPlan(state.level);
    state.shotsLeft = plan.shots;
    state.shotsMax = plan.shots;
    ensureColors(state);
  }
  if (lowestY(state) > DEATH_Y) {
    state.phase = "over";
    pushEvent(state, "lose");
    persistBest(state.best);
  }
  bump(state);
}

function advanceFlying(state: GameState, dt: number) {
  const flyer = state.flying;
  if (!flyer) return;
  let left = dt;
  const maxStep = 6 / BUBBLE_SPEED;
  while (left > 0 && state.flying) {
    const h = Math.min(left, maxStep);
    left -= h;
    flyer.x += flyer.vx * h;
    flyer.y += flyer.vy * h;
    if (flyer.x < R) {
      flyer.x = R;
      flyer.vx = Math.abs(flyer.vx);
    } else if (flyer.x > BOARD_W - R) {
      flyer.x = BOARD_W - R;
      flyer.vx = -Math.abs(flyer.vx);
    }
    const hit =
      flyer.y <= R || colliding(state.bubbles, state.minRow, flyer.x, flyer.y);
    if (hit) {
      const spd = Math.hypot(flyer.vx, flyer.vy) || 1;
      const cell = snapCell(
        state.bubbles,
        state.minRow,
        flyer.x,
        flyer.y,
        flyer.x - (flyer.vx / spd) * R,
        flyer.y - (flyer.vy / spd) * R,
      );
      const color = flyer.color;
      state.flying = null;
      if (cell) settle(state, cell.row, cell.col, color);
      else missShot(state);
      return;
    }
    if (flyer.y > BOARD_H + 30) {
      state.flying = null;
      missShot(state);
      return;
    }
  }
}

export function tick(state: GameState, dt: number) {
  const step = Math.min(dt, 0.05);
  state.time += step;
  if (state.phase === "paused" || state.phase === "menu") return;

  for (const p of state.particles) {
    p.life -= step;
    p.vy += 420 * step;
    p.x += p.vx * step;
    p.y += p.vy * step;
  }
  state.particles = state.particles.filter((p) => p.life > 0);

  for (const f of state.falling) {
    f.life -= step;
    f.vy += 1300 * step;
    f.x += f.vx * step;
    f.y += f.vy * step;
  }
  state.falling = state.falling.filter((f) => f.life > 0 && f.y < BOARD_H + 40);

  for (const p of state.popping) p.life -= step;
  state.popping = state.popping.filter((p) => p.life > 0);

  for (const t of state.texts) {
    t.life -= step;
    t.y -= 36 * step;
  }
  state.texts = state.texts.filter((t) => t.life > 0);

  if (state.dropSlide > 0) {
    state.dropSlide = Math.max(0, state.dropSlide - step * ROW_H * 5);
  }

  if (state.hitstop > 0) {
    state.hitstop -= step;
    return;
  }
  if (state.lock > 0) state.lock = Math.max(0, state.lock - step);
  if (state.shake > 0) state.shake = Math.max(0, state.shake - step * 1.7);
  if (state.phase === "playing") advanceFlying(state, step);
}

export function lowestBubbleY(state: GameState): number {
  return lowestY(state);
}

export function selfTest() {
  const a = cellPos(0, 1, 0);
  const b = cellPos(1, 0, 0);
  const c = cellPos(1, 1, 0);
  const dist = (p: { x: number; y: number }, q: { x: number; y: number }) =>
    Math.hypot(p.x - q.x, p.y - q.y);
  if (Math.abs(dist(a, b) - 2 * R) > 0.02) throw new Error("neighbor distance b");
  if (Math.abs(dist(a, c) - 2 * R) > 0.02) throw new Error("neighbor distance c");

  const pop = freshState();
  pop.phase = "playing";
  pop.level = 1;
  pop.shotsLeft = 5;
  pop.bubbles = [
    { row: 0, col: 0, color: 0 },
    { row: 0, col: 1, color: 0 },
  ];
  settle(pop, 0, 2, 0);
  if (pop.bubbles.length !== 0) throw new Error("expected clear, left " + pop.bubbles.length);
  if ((pop.phase as string) !== "cleared") throw new Error("expected cleared");
  if (pop.score !== 30 + 400) throw new Error("score " + pop.score);

  const orphan = freshState();
  orphan.phase = "playing";
  orphan.shotsLeft = 5;
  orphan.bubbles = [
    { row: 0, col: 0, color: 0 },
    { row: 0, col: 1, color: 0 },
    { row: 0, col: 3, color: 1 },
    { row: 1, col: 0, color: 2 },
  ];
  settle(orphan, 0, 2, 0);
  if (orphan.bubbles.length !== 1) {
    throw new Error("orphan board " + orphan.bubbles.length);
  }
  if (orphan.bubbles[0]?.color !== 1) throw new Error("anchor color");
  if (orphan.phase !== "playing") throw new Error("orphan phase");
  if (orphan.score !== 30 + 25) throw new Error("orphan score " + orphan.score);

  const stay = freshState();
  stay.phase = "playing";
  stay.shotsLeft = 4;
  stay.bubbles = [{ row: 0, col: 5, color: 1 }];
  settle(stay, 0, 6, 0);
  if (stay.bubbles.length !== 2) throw new Error("no-pop count");
  if (stay.shotsLeft !== 3) throw new Error("shots " + stay.shotsLeft);

  const snap = snapCell([], 0, SHOOTER_X, R, SHOOTER_X, R + 30);
  if (!snap || snap.row !== 0) throw new Error("ceiling snap");

  const flight = freshState();
  flight.phase = "playing";
  flight.bubbles = [];
  flight.angle = -Math.PI / 2;
  flight.shotsLeft = 4;
  if (!shoot(flight)) throw new Error("shoot failed");
  for (let i = 0; i < 180; i++) tick(flight, 1 / 60);
  if (flight.flying) throw new Error("still flying");
  if (flight.bubbles.length !== 1) throw new Error("flight place " + flight.bubbles.length);
  if (flight.bubbles[0]?.row !== 0) throw new Error("flight row " + flight.bubbles[0]?.row);

  const board = makeBoard(1);
  if (board.length < 40) throw new Error("board small " + board.length);
  const probe = freshState();
  probe.bubbles = board;
  const keep = anchoredSet(probe);
  if (keep.size !== board.length) throw new Error("loose bubbles");

  const low = freshState();
  low.phase = "playing";
  low.minRow = 0;
  low.shotsLeft = 3;
  low.bubbles = [{ row: 0, col: 5, color: 3 }];
  const from = cellPos(0, 5, 0);
  const snapped = snapCell(
    low.bubbles,
    0,
    from.x,
    from.y + R,
    from.x - 8,
    from.y + ROW_H,
  );
  if (!snapped || snapped.row !== 1) throw new Error("side snap " + JSON.stringify(snapped));
}
