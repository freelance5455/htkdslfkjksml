import * as THREE from "three";
import { GameAudio } from "@/game/audio";
import { Input } from "@/game/input";
import { Player } from "@/game/player";
import { Weapon } from "@/game/weapon";
import { buildWorld, type World } from "@/game/world";
import { ZombieHorde } from "@/game/zombies";
import { loadSave, recordRun } from "@/game/save";
import { useGameStore } from "@/game/store";
import { disposeTextures } from "@/game/textures";
import type { ControlsProbe } from "@/game/types";

export class GameEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private overlay = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private overlayCam: THREE.PerspectiveCamera;
  private player = new Player();
  private input = new Input();
  private audio = new GameAudio();
  private weapon: Weapon;
  private world: World;
  private horde: ZombieHorde;
  private raycaster = new THREE.Raycaster();
  private ndc = new THREE.Vector2(0, 0);
  private shake = new THREE.Vector3();
  private trauma = 0;
  private hitstop = 0;
  private time = 0;
  private last = 0;
  private disposed = false;
  private hadPointerLock = false;
  private wave = 1;
  private toSpawn = 0;
  private spawnCd = 0;
  private wavePause = 0;
  private score = 0;
  private kills = 0;
  private bannerT = 0;
  private reduceMotion = false;
  private impacts: THREE.Mesh[] = [];
  private impactGeo: THREE.SphereGeometry;
  private onPointerMove: (e: MouseEvent) => void;
  private onMouseDown: (e: MouseEvent) => void;
  private onMouseUp: (e: MouseEvent) => void;
  private onPointerLock: () => void;
  private onVisibility: () => void;
  private onResize: () => void;

  constructor(private canvas: HTMLCanvasElement) {
    const mobile = window.matchMedia("(pointer: coarse)").matches;
    this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: !mobile,
      powerPreference: "high-performance",
      alpha: false,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.25 : 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.autoClear = false;

    this.camera = new THREE.PerspectiveCamera(78, 1, 0.08, 120);
    this.overlayCam = new THREE.PerspectiveCamera(70, 1, 0.05, 10);
    this.overlay.add(this.overlayCam);
    const gunLight = new THREE.HemisphereLight(0xfff4e4, 0x3a2a18, 1.6);
    this.overlay.add(gunLight);
    const gunDir = new THREE.DirectionalLight(0xffe2b0, 1.15);
    gunDir.position.set(0.4, 0.8, 1);
    this.overlay.add(gunDir);

    this.weapon = new Weapon();
    this.overlayCam.add(this.weapon.group);
    this.world = buildWorld(this.scene);
    this.horde = new ZombieHorde(this.scene);

    this.impactGeo = new THREE.SphereGeometry(0.06, 6, 6);
    const impactMat = new THREE.MeshBasicMaterial({
      color: 0x1a120c,
      transparent: true,
      opacity: 0.8,
    });
    for (let i = 0; i < 18; i++) {
      const m = new THREE.Mesh(this.impactGeo, impactMat.clone());
      m.visible = false;
      this.scene.add(m);
      this.impacts.push(m);
    }
    impactMat.dispose();

    this.input.attach();
    this.onResize = () => this.resize();
    this.onPointerMove = (e: MouseEvent) => {
      if (document.pointerLockElement === this.canvas) {
        this.input.addLook(e.movementX, e.movementY);
      }
    };
    this.onMouseDown = (e: MouseEvent) => {
      if (e.button === 0 && document.pointerLockElement === this.canvas) {
        this.input.fireHeld = true;
      }
    };
    this.onMouseUp = (e: MouseEvent) => {
      if (e.button === 0 && document.pointerLockElement === this.canvas) {
        this.input.fireHeld = false;
      }
    };
    this.onPointerLock = () => {
      const locked = document.pointerLockElement === this.canvas;
      if (!locked && this.hadPointerLock && useGameStore.getState().phase === "playing") {
        this.pause();
      }
      this.hadPointerLock = locked;
    };
    this.onVisibility = () => {
      if (document.visibilityState === "visible") this.audio.resume();
      if (document.visibilityState === "hidden" && useGameStore.getState().phase === "playing") {
        this.pause();
      }
    };
    window.addEventListener("resize", this.onResize);
    document.addEventListener("mousemove", this.onPointerMove);
    document.addEventListener("mousedown", this.onMouseDown);
    document.addEventListener("mouseup", this.onMouseUp);
    document.addEventListener("pointerlockchange", this.onPointerLock);
    document.addEventListener("visibilitychange", this.onVisibility);

    this.resize();
    this.placeTitleZombies();
    const save = loadSave();
    useGameStore.setState({
      ready: true,
      phase: "title",
      highScore: save.highScore,
      bestWave: save.bestWave,
    });

    window.__controlsTest = this.probe();
    window.__startGame = () => this.start();

    this.last = performance.now();
    this.renderer.setAnimationLoop(this.loop);
  }

  private probe(): ControlsProbe {
    return {
      getYaw: () => this.player.yaw,
      getSpeed: () => this.player.speed,
      getX: () => this.player.x,
      getZ: () => this.player.z,
      getAmmo: () => this.weapon.ammo,
      setKeys: (codes) => this.input.setInjected(codes),
    };
  }

  private resize() {
    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.overlayCam.aspect = w / h;
    this.overlayCam.updateProjectionMatrix();
  }

  tryPointerLock() {
    const fn = this.canvas.requestPointerLock as (
      opts?: { unadjustedMovement?: boolean },
    ) => Promise<void> | void;
    try {
      const res = fn.call(this.canvas, { unadjustedMovement: true });
      if (res && typeof (res as Promise<void>).catch === "function") {
        (res as Promise<void>).catch(() => {
          try {
            this.canvas.requestPointerLock();
          } catch {
            /* iframe may block */
          }
        });
      }
    } catch {
      try {
        this.canvas.requestPointerLock();
      } catch {
        /* ignore */
      }
    }
  }

  start() {
    this.audio.unlock();
    this.player.reset();
    this.weapon.reset();
    this.horde.reset();
    this.wave = 1;
    this.score = 0;
    this.kills = 0;
    this.trauma = 0;
    this.wavePause = 0.4;
    this.toSpawn = 0;
    this.spawnCd = 0;
    this.banner("Wave 1");
    this.audio.wave();
    useGameStore.setState({
      phase: "playing",
      newRecord: false,
      health: 100,
      ammo: 6,
      reserve: 24,
      score: 0,
      wave: 1,
      kills: 0,
      banner: "Wave 1",
    });
    this.tryPointerLock();
    this.pushHud();
  }

  pause() {
    if (useGameStore.getState().phase !== "playing") return;
    useGameStore.setState({ phase: "paused" });
    if (document.pointerLockElement) document.exitPointerLock();
  }

  resume() {
    if (useGameStore.getState().phase !== "paused") return;
    useGameStore.setState({ phase: "playing" });
    this.tryPointerLock();
    this.last = performance.now();
  }

  quitToTitle() {
    if (document.pointerLockElement) document.exitPointerLock();
    this.horde.reset();
    this.placeTitleZombies();
    this.player.reset();
    useGameStore.setState({ phase: "title", banner: "" });
  }

  setTouchMove(x: number, y: number) {
    this.input.touchMoveX = x;
    this.input.touchMoveY = y;
  }

  addLook(dx: number, dy: number) {
    this.input.addLook(dx, dy);
  }

  setFireHeld(held: boolean) {
    this.input.fireHeld = held;
  }

  queueReload() {
    this.input.queueReload();
  }

  queuePause() {
    this.input.queuePause();
  }

  setMuted(muted: boolean) {
    this.audio.setMuted(muted);
  }

  private banner(text: string) {
    this.bannerT = 2.4;
    useGameStore.setState({ banner: text });
  }

  private placeTitleZombies() {
    this.horde.reset();
    const spots = this.world.spawnPoints;
    for (let i = 0; i < 5; i++) {
      const s = spots[i % spots.length];
      this.horde.spawn(s.x, s.z, 80, 0.55);
    }
  }

  private beginWave() {
    this.toSpawn = 4 + this.wave * 2;
    this.spawnCd = 0.15;
    this.banner(`Wave ${this.wave}`);
    this.audio.wave();
  }

  private spawnOne() {
    const spots = this.world.spawnPoints;
    const s = spots[(Math.random() * spots.length) | 0];
    const jitter = 1.4;
    const hp = 70 + this.wave * 12;
    const speed = 1.15 + this.wave * 0.1;
    if (
      this.horde.spawn(
        s.x + (Math.random() - 0.5) * jitter,
        s.z + (Math.random() - 0.5) * jitter,
        hp,
        speed,
      )
    ) {
      this.toSpawn -= 1;
      if (Math.random() < 0.35) this.audio.groan();
    }
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    const raw = Math.min((now - this.last) / 1000, 0.1);
    this.last = now;
    const phase = useGameStore.getState().phase;

    if (phase === "title") {
      this.time += raw;
      const t = this.time * 0.12;
      this.camera.position.set(Math.sin(t) * 16, 7.2, Math.cos(t) * 16);
      this.camera.lookAt(0, 1.4, 0);
      this.horde.update(raw, Math.sin(t) * 3, Math.cos(t) * 3, this.world.colliders, () => undefined);
      this.render();
      return;
    }

    if (phase === "paused" || phase === "dead") {
      this.render();
      return;
    }

    const actions = this.input.sample();
    if (actions.pause) {
      this.pause();
      return;
    }

    const sens = useGameStore.getState().sensitivity;
    actions.lookDx *= sens;
    actions.lookDy *= sens;

    let dt = raw;
    if (this.hitstop > 0) {
      this.hitstop -= raw;
      dt = raw * 0.15;
    }
    this.time += dt;

    this.player.update(dt, actions, this.world.colliders);
    const bobAmt = this.player.speed > 0.4 ? 0.028 : 0;
    if (this.player.speed > 1.4) this.audio.footstep(this.time);

    if (actions.reload) {
      if (this.weapon.beginReload()) this.audio.reload();
    }
    if (actions.fire) this.tryShoot();

    this.weapon.update(dt, this.player.dist, actions.lookDx, actions.lookDy);

    this.horde.update(dt, this.player.x, this.player.z, this.world.colliders, (dmg) => {
      this.hurt(dmg);
    });

    if (this.wavePause > 0) {
      this.wavePause -= dt;
      if (this.wavePause <= 0) this.beginWave();
    } else if (this.toSpawn > 0) {
      this.spawnCd -= dt;
      if (this.spawnCd <= 0 && this.horde.aliveCount < 14) {
        this.spawnOne();
        this.spawnCd = Math.max(0.35, 1.1 - this.wave * 0.06);
      }
    } else if (this.horde.aliveCount === 0 && useGameStore.getState().phase === "playing") {
      this.wave += 1;
      this.weapon.addReserve(10);
      this.player.health = Math.min(100, this.player.health + 18);
      this.wavePause = 2.2;
      this.banner("The square holds");
    }

    this.trauma = Math.max(0, this.trauma - dt * 1.7);
    const shakeAmt = this.reduceMotion ? 0 : this.trauma * this.trauma;
    this.shake.set(
      shakeAmt * 0.11 * Math.sin(this.time * 47.2),
      shakeAmt * 0.09 * Math.sin(this.time * 53.1 + 1.1),
      shakeAmt * 0.04 * Math.sin(this.time * 39.4),
    );
    this.player.applyToCamera(this.camera, bobAmt, this.shake, this.weapon.recoil);

    for (const m of this.impacts) {
      if (!m.visible) continue;
      const mat = m.material as THREE.MeshBasicMaterial;
      mat.opacity -= dt * 1.4;
      m.scale.multiplyScalar(1 + dt * 1.2);
      if (mat.opacity <= 0) m.visible = false;
    }

    if (this.bannerT > 0) {
      this.bannerT -= dt;
      if (this.bannerT <= 0) useGameStore.setState({ banner: "" });
    }

    this.pushHud();
    this.render();
  };

  private tryShoot() {
    const result = this.weapon.tryFire();
    if (result === "empty") {
      this.audio.empty();
      return;
    }
    if (result !== "shot") return;

    this.audio.gunshot();
    this.trauma = Math.min(1, this.trauma + 0.22);
    if (navigator.vibrate) navigator.vibrate(16);

    this.raycaster.setFromCamera(this.ndc, this.camera);
    if (useGameStore.getState().aimAssist) this.applyAimAssist();

    const zombieHits = this.raycaster.intersectObjects(this.horde.targets, true);
    const worldHits = this.raycaster.intersectObjects(this.world.hitMeshes, true);
    const zHit = zombieHits[0];
    const wHit = worldHits[0];

    const zombieFirst = zHit && (!wHit || zHit.distance < wHit.distance - 0.05) ? zHit : null;

    if (zombieFirst) {
      const info = this.horde.hitFromRay(zombieFirst, 38, 100);
      if (info) {
        this.audio.hit();
        useGameStore.setState({ hitmarkerAt: performance.now() });
        const dir = this.raycaster.ray.direction;
        this.horde.knockback(info.index, dir.x, dir.z, 0.55);
        this.spawnImpact(info.point, true);
        const pts = info.head ? 150 : 80;
        this.score += pts;
        if (!info.zombie.alive) {
          this.kills += 1;
          this.score += 40;
          this.audio.kill();
          this.hitstop = 0.05;
          this.trauma = Math.min(1, this.trauma + 0.28);
          if (navigator.vibrate) navigator.vibrate(28);
        }
      }
    } else if (wHit) {
      this.spawnImpact(wHit.point, false);
    }
  }

  private applyAimAssist() {
    const dir = this.raycaster.ray.direction;
    const origin = this.raycaster.ray.origin;
    let bestDot = 0.96;
    let best: THREE.Vector3 | null = null;
    const to = new THREE.Vector3();
    for (const obj of this.horde.targets) {
      if (!obj.visible) continue;
      obj.getWorldPosition(to);
      to.y += 1.45;
      to.sub(origin);
      const dist = to.length();
      if (dist < 0.4 || dist > 22) continue;
      to.multiplyScalar(1 / dist);
      const dot = to.dot(dir);
      if (dot > bestDot) {
        bestDot = dot;
        best = to.clone();
      }
    }
    if (best) {
      dir.lerp(best, 0.45).normalize();
    }
  }

  private spawnImpact(point: THREE.Vector3, flesh: boolean) {
    const m = this.impacts.find((p) => !p.visible);
    if (!m) return;
    m.visible = true;
    m.position.copy(point);
    m.scale.setScalar(flesh ? 0.7 : 1);
    const mat = m.material as THREE.MeshBasicMaterial;
    mat.color.setHex(flesh ? 0x5a1810 : 0x2a241c);
    mat.opacity = 0.9;
  }

  private hurt(dmg: number) {
    if (this.player.invuln > 0) return;
    this.player.health -= dmg;
    this.player.invuln = 0.55;
    this.trauma = Math.min(1, this.trauma + 0.45);
    this.audio.hurt();
    useGameStore.setState({ hurtAt: performance.now(), health: Math.max(0, this.player.health) });
    if (navigator.vibrate) navigator.vibrate([20, 30, 40]);
    if (this.player.health <= 0) this.die();
  }

  private die() {
    this.player.health = 0;
    if (document.pointerLockElement) document.exitPointerLock();
    const save = recordRun(this.score, this.wave);
    useGameStore.setState({
      phase: "dead",
      health: 0,
      score: this.score,
      wave: this.wave,
      highScore: save.highScore,
      bestWave: save.bestWave,
      newRecord: this.score > 0 && this.score >= save.highScore,
      banner: "",
    });
  }

  private pushHud() {
    const s = useGameStore.getState();
    if (
      s.health === this.player.health &&
      s.ammo === this.weapon.ammo &&
      s.reserve === this.weapon.reserve &&
      s.reloading === this.weapon.reloading &&
      s.score === this.score &&
      s.wave === this.wave &&
      s.kills === this.kills
    ) {
      return;
    }
    useGameStore.setState({
      health: this.player.health,
      ammo: this.weapon.ammo,
      reserve: this.weapon.reserve,
      reloading: this.weapon.reloading,
      score: this.score,
      wave: this.wave,
      kills: this.kills,
    });
  }

  private render() {
    this.renderer.clear();
    this.renderer.render(this.scene, this.camera);
    const phase = useGameStore.getState().phase;
    if (phase === "playing" || phase === "paused") {
      this.renderer.clearDepth();
      this.renderer.render(this.overlay, this.overlayCam);
    }
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.input.detach();
    window.removeEventListener("resize", this.onResize);
    document.removeEventListener("mousemove", this.onPointerMove);
    document.removeEventListener("mousedown", this.onMouseDown);
    document.removeEventListener("mouseup", this.onMouseUp);
    document.removeEventListener("pointerlockchange", this.onPointerLock);
    document.removeEventListener("visibilitychange", this.onVisibility);
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    this.world.dispose();
    this.horde.dispose();
    this.weapon.dispose();
    this.impactGeo.dispose();
    for (const m of this.impacts) {
      (m.material as THREE.Material).dispose();
    }
    disposeTextures();
    this.renderer.dispose();
    delete window.__controlsTest;
    delete window.__startGame;
  }
}
