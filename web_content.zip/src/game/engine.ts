import { sfx } from "./audio";
import { Particles } from "./particles";
import {
  CUSTOMER_TYPES,
  DISHES,
  ING_MAP,
  INGREDIENTS,
  LOCATIONS,
  UPGRADES,
  bn,
  DAY_LENGTH,
  DAY_TARGET,
  festForDay,
  locForDay,
  taka,
  type CustType,
  type Dish,
  type Festival,
  type IngId,
  type Location,
} from "./data";

export type Phase = "menu" | "ready" | "playing" | "paused" | "shop" | "gameover";

export interface Customer {
  key: string;
  uid: number;
  type: CustType;
  slot: number;
  order: Dish;
  patience: number;
  maxPatience: number;
  state: "enter" | "wait" | "happy" | "angry";
  t: number;
  paid: number;
  perfect: boolean;
  nudge: number;
}

export interface Plate {
  key: string;
  uid: number;
  dish: Dish;
  t: number;
}

export interface Toast {
  key: string;
  bn: string;
  kind: "good" | "bad" | "info" | "epic";
  t: number;
  max: number;
}

export interface DayStats {
  served: number;
  perfect: number;
  missed: number;
  wrong: number;
  tips: number;
}

export interface ScoreRow {
  name: string;
  score: number;
  day: number;
  loc: string;
  served: number;
}

export interface GameState {
  phase: Phase;
  readyT: number;
  day: number;
  loc: Location;
  fest: Festival | undefined;
  wallet: number;
  dayEarned: number;
  totalEarned: number;
  totalTips: number;
  score: number;
  combo: number;
  bestCombo: number;
  rep: number;
  popularity: number;
  clock: number;
  dayLen: number;
  target: number;
  current: IngId[];
  plates: Plate[];
  customers: Customer[];
  upgrades: Record<string, number>;
  toasts: Toast[];
  stats: DayStats;
  runServed: number;
  runPerfect: number;
  runMissed: number;
  overReason: "target" | "rep" | "";
  lastGain: { amount: number; key: string } | null;
  /* derived */
  unlocked: IngId[];
  menu: Dish[];
  maxPlates: number;
  maxSlots: number;
  priceMul: number;
  patienceMul: number;
  tipMul: number;
  autoEvery: number;
  selected: number;
  hintStage: number;
  shakeBadge: number;
}

const HS_KEY = "sft_scores_v2";

export function loadScores(): ScoreRow[] {
  try {
    const raw = localStorage.getItem(HS_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as ScoreRow[];
    return Array.isArray(arr) ? arr.slice(0, 8) : [];
  } catch {
    return [];
  }
}

function saveScores(rows: ScoreRow[]) {
  try {
    localStorage.setItem(HS_KEY, JSON.stringify(rows.slice(0, 8)));
  } catch {
    /* ignore */
  }
}

function freshState(): GameState {
  const s: GameState = {
    phase: "menu",
    readyT: 0,
    day: 1,
    loc: LOCATIONS[0],
    fest: undefined,
    wallet: 0,
    dayEarned: 0,
    totalEarned: 0,
    totalTips: 0,
    score: 0,
    combo: 0,
    bestCombo: 0,
    rep: 62,
    popularity: 0,
    clock: DAY_LENGTH(1),
    dayLen: DAY_LENGTH(1),
    target: DAY_TARGET(1),
    current: [],
    plates: [],
    customers: [],
    upgrades: {},
    toasts: [],
    stats: { served: 0, perfect: 0, missed: 0, wrong: 0, tips: 0 },
    runServed: 0,
    runPerfect: 0,
    runMissed: 0,
    overReason: "",
    lastGain: null,
    unlocked: [],
    menu: [],
    maxPlates: 1,
    maxSlots: 3,
    priceMul: 1,
    patienceMul: 1,
    tipMul: 1,
    autoEvery: 0,
    selected: -1,
    hintStage: 0,
    shakeBadge: 0,
  };
  return s;
}

export class Game {
  s: GameState = freshState();
  parts = new Particles();
  private els = new Map<string, HTMLElement>();
  private listeners = new Set<() => void>();
  private raf = 0;
  private last = 0;
  private lastEmit = 0;
  private dirty = true;
  private shake = 0;
  private flash = 0;
  private flashColor = "#ffb627";
  private shakeRoot: HTMLElement | null = null;
  private flashEl: HTMLElement | null = null;
  private uid = 1;
  private spawnTimer = 1;
  private autoTimer = 0;
  private ambTimer = 0;
  private running = false;
  private festConfetti = 0;

  constructor() {
    this.derive();
  }

  /* ---------------- plumbing ---------------- */

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  version = 0;

  private emit() {
    this.version++;
    this.listeners.forEach((l) => l());
  }

  /** ingredient ids that legally extend the current build — used to glow the right buttons */
  validNext(): IngId[] {
    const cands = this.candidates(this.s.current);
    const set = new Set<IngId>();
    cands.forEach((d) => {
      const nxt = d.recipe[this.s.current.length];
      if (nxt) set.add(nxt);
    });
    if (this.s.current.length === 0) {
      this.s.menu.forEach((d) => set.add(d.recipe[0]));
    }
    return [...set];
  }

  /** recipes the player could still be building toward */
  buildingTowards(): Dish[] {
    return this.candidates(this.s.current).filter((d) => d.recipe.length > this.s.current.length);
  }

  mark() {
    this.dirty = true;
  }

  register(key: string, el: HTMLElement | null) {
    if (el) this.els.set(key, el);
    else this.els.delete(key);
  }

  at(key: string) {
    return this.parts.center(this.els.get(key) ?? null);
  }

  attachShake(el: HTMLElement | null) {
    this.shakeRoot = el;
  }
  attachFlash(el: HTMLElement | null) {
    this.flashEl = el;
  }
  attachCanvas(el: HTMLCanvasElement | null) {
    if (el) {
      this.parts.attach(el);
      if (!this.running) this.start();
    }
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      this.frame(dt, now);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.running = false;
    this.listeners.clear();
    sfx.ambient(false);
  }

  private frame(dt: number, now: number) {
    if (this.s.phase === "playing") {
      this.tick(dt);
    } else if (this.s.phase === "ready") {
      this.s.readyT -= dt;
      if (this.s.readyT <= 0) this.beginPlay();
      this.mark();
    }

    // toasts
    if (this.s.toasts.length) {
      let changed = false;
      this.s.toasts = this.s.toasts.filter((t) => {
        t.t += dt;
        if (t.t >= t.max) {
          changed = true;
          return false;
        }
        return true;
      });
      if (changed) this.mark();
    }

    // ambience particles
    this.ambTimer -= dt;
    if (this.ambTimer <= 0 && (this.s.phase === "playing" || this.s.phase === "menu")) {
      this.ambTimer = 0.55 + Math.random() * 0.8;
      const cart = this.els.get("cart");
      if (cart) {
        const p = this.parts.center(cart);
        this.parts.steam(p.x + (Math.random() - 0.5) * 60, p.y - 20, 1 + ((Math.random() * 2) | 0));
      }
    }
    if (this.s.fest && this.s.phase === "playing") {
      this.festConfetti -= dt;
      if (this.festConfetti <= 0) {
        this.festConfetti = 1.6;
        this.parts.confetti(6);
      }
    }

    this.parts.update(dt);
    this.parts.draw();

    // shake + flash (imperative, no react churn)
    if (this.shake > 0.05) {
      this.shake *= Math.pow(0.0016, dt);
      const m = this.shake;
      if (this.shakeRoot) {
        this.shakeRoot.style.transform = `translate3d(${(Math.random() - 0.5) * m}px,${
          (Math.random() - 0.5) * m
        }px,0) rotate(${(Math.random() - 0.5) * m * 0.09}deg)`;
      }
    } else if (this.shake !== 0) {
      this.shake = 0;
      if (this.shakeRoot) this.shakeRoot.style.transform = "translate3d(0,0,0)";
    }
    if (this.flash > 0.001) {
      this.flash *= Math.pow(0.0009, dt);
      if (this.flashEl) {
        this.flashEl.style.opacity = String(Math.min(0.55, this.flash));
        this.flashEl.style.background = this.flashColor;
      }
    } else if (this.flash !== 0) {
      this.flash = 0;
      if (this.flashEl) this.flashEl.style.opacity = "0";
    }

    const live = this.s.phase === "playing" || this.s.phase === "ready";
    if (this.dirty || (live && now - this.lastEmit > 100)) {
      this.dirty = false;
      this.lastEmit = now;
      this.emit();
    }
  }

  kick(mag: number, color = "#ffb627", flash = 0.5) {
    this.shake = Math.max(this.shake, mag);
    if (flash > 0) {
      this.flash = Math.max(this.flash, flash);
      this.flashColor = color;
    }
  }

  toast(bnText: string, kind: Toast["kind"] = "info", max = 1.5) {
    this.s.toasts = [...this.s.toasts.slice(-2), { key: "t" + this.uid++, bn: bnText, kind, t: 0, max }];
    this.mark();
  }

  /* ---------------- derived ---------------- */

  private ulvl(id: string) {
    return this.s.upgrades[id] ?? 0;
  }

  derive() {
    const s = this.s;
    const unlocked = new Set<IngId>(INGREDIENTS.filter((i) => i.start).map((i) => i.id));
    UPGRADES.forEach((u) => {
      if (u.cat === "ing" && this.ulvl(u.id) > 0 && u.ing) unlocked.add(u.ing);
    });
    s.unlocked = [...unlocked];
    s.menu = DISHES.filter((d) => d.needs.every((n) => unlocked.has(n)));
    s.maxPlates = 1 + this.ulvl("pot");
    const narrow = typeof window !== "undefined" && window.innerWidth < 460;
    s.maxSlots = Math.min(5, (s.day >= 4 ? 4 : 3) + this.ulvl("stool") - (narrow ? 1 : 0));
    s.maxSlots = Math.max(2, s.maxSlots);
    s.priceMul =
      s.loc.priceMul * (s.fest?.priceMul ?? 1) * (1 + 0.08 * this.ulvl("stove")) * (unlocked.has("spice") ? 1.1 : 1);
    s.patienceMul = s.loc.patienceMul * (s.fest?.patienceMul ?? 1) * (1 + 0.12 * this.ulvl("light"));
    s.tipMul = 1 + 0.12 * this.ulvl("banner");
    s.autoEvery = this.ulvl("auto") === 2 ? 1.25 : this.ulvl("auto") === 1 ? 2.0 : 0;
    s.dayLen = DAY_LENGTH(s.day);
    s.target = DAY_TARGET(s.day);
  }

  private candidates(seq: IngId[]): Dish[] {
    return this.s.menu.filter((d) => {
      if (d.recipe.length < seq.length) return false;
      for (let i = 0; i < seq.length; i++) if (d.recipe[i] !== seq[i]) return false;
      return true;
    });
  }

  private pickDish(type: CustType): Dish {
    const menu = this.s.menu;
    const fest = this.s.fest;
    const weights = menu.map((d) => {
      let w = type.rich ? d.price / 12 : d.price <= 24 ? 3.2 : d.price <= 42 ? 2 : 0.9;
      if (fest && fest.dishes.includes(d.id)) w *= 2.4;
      if (type.id === "student" && d.recipe.length > 5) w *= 0.5;
      return w;
    });
    const total = weights.reduce((a, b) => a + b, 0);
    let r = Math.random() * total;
    for (let i = 0; i < menu.length; i++) {
      r -= weights[i];
      if (r <= 0) return menu[i];
    }
    return menu[0];
  }

  private pickType(): CustType {
    const pool = CUSTOMER_TYPES.filter((c) => c.minDay <= this.s.day);
    let soundBonus = this.ulvl("sound");
    const weights = pool.map((c) => {
      let w = c.weight;
      if (c.rich) w += soundBonus * 5;
      if (this.s.fest) w *= c.id === "student" || c.id === "rickshaw" ? 1.4 : 1;
      return w;
    });
    const total = weights.reduce((a, b) => a + b, 0);
    let r = Math.random() * total;
    for (let i = 0; i < pool.length; i++) {
      r -= weights[i];
      if (r <= 0) return pool[i];
    }
    return pool[0];
  }

  /* ---------------- flow ---------------- */

  /** set by the game-over screen so keyboard restarts still bank the high score */
  pendingSave: (() => void) | null = null;

  private flushSave() {
    if (this.s.phase === "gameover" && this.pendingSave) {
      this.pendingSave();
      this.pendingSave = null;
    }
  }

  startRun() {
    sfx.init();
    this.flushSave();
    this.s = freshState();
    this.uid = 1;
    this.parts.clear();
    this.derive();
    this.startDay(1);
    sfx.ambient(true);
  }

  startDay(day: number) {
    const s = this.s;
    s.day = day;
    s.loc = locForDay(day);
    s.fest = festForDay(day);
    s.dayEarned = 0;
    s.clock = DAY_LENGTH(day);
    s.dayLen = s.clock;
    s.customers = [];
    s.plates = [];
    s.current = [];
    s.combo = 0;
    s.selected = -1;
    s.stats = { served: 0, perfect: 0, missed: 0, wrong: 0, tips: 0 };
    s.overReason = "";
    s.toasts = [];
    s.hintStage = day === 1 ? 1 : 0;
    this.derive();
    s.target = DAY_TARGET(day);
    this.spawnTimer = 0.5;
    this.autoTimer = 0;
    s.phase = "ready";
    s.readyT = 2.6;
    this.parts.clear();
    this.mark();
  }

  skipReady() {
    if (this.s.phase === "ready") {
      this.s.readyT = 0;
      this.beginPlay();
    }
  }

  private beginPlay() {
    this.s.phase = "playing";
    this.s.readyT = 0;
    sfx.bell();
    if (this.s.fest) {
      sfx.dhol();
      this.parts.confetti(50);
      this.toast(`${this.s.fest.icon} ${this.s.fest.bn} — ${this.s.fest.note}`, "epic", 3.2);
    } else {
      this.toast(`${this.s.loc.icon} ${this.s.loc.bn} — ${this.s.loc.tagline}`, "info", 2.2);
    }
    this.kick(6, "#ffb627", 0.35);
    this.mark();
  }

  togglePause(force?: boolean) {
    const s = this.s;
    if (force !== undefined && ((force && s.phase !== "playing") || (!force && s.phase !== "paused"))) return;
    if (s.phase === "playing") {
      s.phase = "paused";
      sfx.pauseAmbient(true);
      sfx.click();
    } else if (s.phase === "paused") {
      s.phase = "playing";
      this.last = performance.now();
      sfx.pauseAmbient(false);
      sfx.click();
    }
    this.mark();
  }

  private endDay() {
    const s = this.s;
    s.clock = 0;
    if (s.dayEarned >= s.target) {
      const bonus = Math.round(s.rep * 8 + s.stats.perfect * 25 + s.bestCombo * 15 + s.stats.tips * 0.5);
      s.score += bonus;
      s.wallet += bonus;
      s.totalEarned += bonus;
      s.phase = "shop";
      sfx.ambient(false);
      sfx.fanfare();
      this.parts.confetti(90);
      this.kick(10, "#17b8a6", 0.5);
    } else {
      this.gameOver("target");
    }
    this.mark();
  }

  nextDay() {
    sfx.click();
    sfx.ambient(true);
    this.startDay(this.s.day + 1);
  }

  gameOver(reason: "target" | "rep") {
    const s = this.s;
    if (s.phase === "gameover") return;
    s.overReason = reason;
    s.phase = "gameover";
    s.score += Math.round(s.totalEarned + s.rep * 10 + s.day * 150 + s.bestCombo * 20);
    sfx.ambient(false);
    sfx.fail();
    this.kick(16, "#e8384f", 0.7);
    this.mark();
  }

  submitScore(name: string): ScoreRow[] {
    const rows = loadScores();
    rows.push({
      name: name.trim().slice(0, 14) || "নামহীন",
      score: Math.round(this.s.score),
      day: this.s.day,
      loc: this.s.loc.bn,
      served: this.s.runServed,
    });
    rows.sort((a, b) => b.score - a.score);
    const top = rows.slice(0, 8);
    saveScores(top);
    return top;
  }

  toMenu() {
    this.flushSave();
    this.s = freshState();
    this.derive();
    this.parts.clear();
    sfx.ambient(false);
    sfx.click();
    this.mark();
  }

  /* ---------------- input ---------------- */

  tapIng(id: IngId, viaAuto = false) {
    const s = this.s;
    if (s.phase !== "playing") return;
    if (!s.unlocked.includes(id)) {
      const el = this.els.get("st_" + id);
      if (el) el.animate(
        [{ transform: "translateX(0)" }, { transform: "translateX(-5px)" }, { transform: "translateX(5px)" }, { transform: "translateX(0)" }],
        { duration: 240 },
      );
      sfx.error();
      this.toast("এই উপাদানটা এখনও কেনা হয়নি!", "bad", 1.2);
      return;
    }

    const seq = [...s.current, id];
    const cands = this.candidates(seq);
    const el = this.els.get("st_" + id);
    const p = el ? this.parts.center(el) : { x: this.parts.w / 2, y: this.parts.h / 2 };

    if (cands.length === 0) {
      s.stats.wrong++;
      sfx.error();
      this.kick(9, "#e8384f", 0.3);
      this.parts.sparks(p.x, p.y, "#e8384f", 14, 210);
      this.parts.text(p.x, p.y - 26, "ভুল!", "#ff8fa3", 20);
      s.rep = Math.max(0, s.rep - 0.6);
      if (el) {
        el.animate(
          [
            { transform: "translateX(0) rotate(0)" },
            { transform: "translateX(-7px) rotate(-4deg)" },
            { transform: "translateX(7px) rotate(4deg)" },
            { transform: "translateX(0) rotate(0)" },
          ],
          { duration: 300 },
        );
      }
      if (s.rep <= 0) this.gameOver("rep");
      this.mark();
      return;
    }

    const done = cands.find((d) => d.recipe.length === seq.length);
    if (done && s.plates.length >= s.maxPlates) {
      sfx.error();
      this.kick(7, "#ff4d8d", 0.25);
      this.toast(`প্লেট শেষ! আগে ${bn(s.maxPlates)} টা পরিবেশন করুন`, "bad", 1.3);
      this.mark();
      return;
    }

    s.current = seq;
    const ing = ING_MAP[id];
    this.parts.sparks(p.x, p.y, ing.color, viaAuto ? 6 : 10, viaAuto ? 120 : 170);
    this.parts.ring(p.x, p.y, viaAuto ? "#17b8a6" : ing.color, 10, 0.36);
    sfx.tap(seq.length - 1);
    if (el) {
      el.animate(
        [
          { transform: "scale(1)" },
          { transform: "scale(0.86)" },
          { transform: "scale(1.12)" },
          { transform: "scale(1)" },
        ],
        { duration: 240, easing: "ease-out" },
      );
    }

    if (done) {
      s.current = [];
      const plate: Plate = { key: "p" + this.uid++, uid: this.uid, dish: done, t: 0 };
      s.plates = [...s.plates, plate];
      const cp = this.els.get("tray") ? this.parts.center(this.els.get("tray") ?? null) : p;
      this.parts.stars(cp.x, cp.y, done.color, 9);
      this.parts.ring(cp.x, cp.y, "#fff3dc", 12, 0.5);
      this.parts.emoji(cp.x, cp.y - 10, done.icon, 3);
      sfx.complete();
      this.kick(5, done.color, 0.28);
      if (s.hintStage === 1) s.hintStage = 2;
    }
    this.mark();
  }

  trash() {
    const s = this.s;
    if (s.phase !== "playing") return;
    if (s.current.length) {
      const cp = this.els.get("tray") ? this.parts.center(this.els.get("tray") ?? null) : { x: 0, y: 0 };
      this.parts.sparks(cp.x, cp.y, "#8a4b12", 10, 130);
      s.current = [];
      sfx.whoosh();
      this.toast("আধা বানানো খাবার ফেলে দিলেন", "bad", 1);
    } else if (s.plates.length) {
      const p = s.plates[s.plates.length - 1];
      s.plates = s.plates.slice(0, -1);
      sfx.whoosh();
      this.toast(`${p.dish.icon} ${p.dish.bn} নষ্ট হলো`, "bad", 1);
    }
    s.selected = -1;
    this.mark();
  }

  selectPlate(i: number) {
    const s = this.s;
    if (s.phase !== "playing") return;
    s.selected = s.selected === i ? -1 : i;
    sfx.click();
    const el = this.els.get("pl_" + i);
    if (el) {
      const p = this.parts.center(el);
      this.parts.ring(p.x, p.y, "#ffb627", 8, 0.3);
    }
    this.mark();
  }

  serve(custKey: string) {
    const s = this.s;
    if (s.phase !== "playing") return;
    const c = s.customers.find((x) => x.key === custKey);
    if (!c || c.state !== "wait") return;
    const cp = this.els.get("c_" + c.key) ? this.parts.center(this.els.get("c_" + c.key)!) : { x: 0, y: 0 };

    let idx = -1;
    if (s.selected >= 0 && s.plates[s.selected]) idx = s.selected;
    else idx = s.plates.findIndex((p) => p.dish.id === c.order.id);

    if (idx === -1) {
      if (s.plates.length === 0) {
        sfx.error();
        this.kick(4, "#e8384f", 0.15);
        this.parts.text(cp.x, cp.y - 46, "আগে বানান!", "#ffd0d8", 18);
        if (s.hintStage === 0 || s.hintStage === 1) s.hintStage = 1;
      } else {
        // deliberate wrong serve (a plate was hand-picked)
        if (s.selected >= 0) {
          const bad = s.plates[s.selected];
          s.plates = s.plates.filter((_, i) => i !== s.selected);
          s.selected = -1;
          s.stats.wrong++;
          s.combo = 0;
          s.rep = Math.max(0, s.rep - 4);
          c.patience = Math.max(0.4, c.patience - 2);
          c.nudge = 1;
          sfx.angry();
          this.kick(14, "#e8384f", 0.55);
          this.parts.sparks(cp.x, cp.y - 40, "#e8384f", 20, 240);
          this.parts.emoji(cp.x, cp.y - 60, "💢", 2);
          this.parts.text(cp.x, cp.y - 74, "ভুল খাবার!", "#ff6b81", 22);
          this.toast(`${bad.dish.bn} ওনার অর্ডার ছিল না! রেটিং কমল`, "bad", 1.8);
          if (s.rep <= 0) this.gameOver("rep");
        } else {
          sfx.error();
          this.kick(5, "#ffb627", 0.15);
          this.parts.text(cp.x, cp.y - 52, `${c.order.icon} রেডি নেই`, "#ffe9c2", 18);
          if (s.hintStage === 0) s.hintStage = 1;
        }
      }
      this.mark();
      return;
    }

    const plate = s.plates[idx];
    s.plates = s.plates.filter((_, i) => i !== idx);
    s.selected = -1;

    const ratio = Math.max(0, c.patience / c.maxPatience);
    const perfect = ratio > 0.55;
    const comboMul = 1 + Math.min(12, s.combo) * 0.05;
    const popMul = s.popularity > 0 ? 2 : 1;
    const base = plate.dish.price * s.priceMul * comboMul;
    const tipRate = perfect ? 0.6 : ratio > 0.3 ? 0.26 : 0.08;
    const tip = base * tipRate * c.type.tipMul * s.tipMul;
    const total = Math.round((base + tip) * popMul);

    s.wallet += total;
    s.dayEarned += total;
    s.totalEarned += total;
    s.totalTips += Math.round(tip * popMul);
    s.stats.tips += Math.round(tip * popMul);
    s.score += total;
    s.combo += 1;
    s.bestCombo = Math.max(s.bestCombo, s.combo);
    s.stats.served++;
    s.runServed++;
    if (perfect) {
      s.stats.perfect++;
      s.runPerfect++;
    }
    const repGain = (perfect ? 2.6 : 0.9) * (1 + 0.3 * this.ulvl("sound")) * (c.type.id === "dadi" ? 1.6 : 1);
    s.rep = Math.min(100, s.rep + repGain);
    s.lastGain = { amount: total, key: "g" + this.uid++ };
    if (s.popularity > 0) s.popularity--;

    c.state = "happy";
    c.t = 0;
    c.paid = total;
    c.perfect = perfect;

    // juice
    this.parts.coins(cp.x, cp.y - 34, perfect ? 18 : 11);
    this.parts.stars(cp.x, cp.y - 50, perfect ? "#ffb627" : "#fff3dc", perfect ? 12 : 6);
    this.parts.ring(cp.x, cp.y - 30, perfect ? "#ffb627" : "#17b8a6", 14, 0.55);
    this.parts.text(
      cp.x,
      cp.y - 82,
      `${taka(total)}${popMul > 1 ? " ×২" : ""}`,
      perfect ? "#ffd75e" : "#fff3dc",
      perfect ? 30 : 24,
    );
    if (perfect) {
      this.parts.emoji(cp.x, cp.y - 64, "😍", 2);
      this.parts.text(cp.x + 46, cp.y - 44, "পারফেক্ট!", "#ff4d8d", 20);
    }
    if (s.combo > 0 && s.combo % 3 === 0) {
      this.parts.text(cp.x - 40, cp.y - 104, `কম্বো ×${bn(s.combo)}`, "#17b8a6", 22);
    }
    sfx.coin(perfect || total > 120);
    this.kick(perfect ? 9 : 5, perfect ? "#ffb627" : "#17b8a6", perfect ? 0.42 : 0.2);

    // influencer boost
    if (c.type.id === "blogger" && perfect) {
      s.popularity = 10;
      sfx.fanfare();
      this.kick(14, "#ff4d8d", 0.6);
      this.parts.confetti(70);
      this.toast("📸 ভাইরাল! পরের ১০ জন কাস্টমার দ্বিগুণ টাকা দেবে!", "epic", 3);
    } else if (c.type.id === "blogger") {
      this.toast("📸 ব্লগার খুশি নন… রেটিং একটু কমল", "bad", 1.6);
      s.rep = Math.max(0, s.rep - 2);
    }
    if (s.hintStage === 2) s.hintStage = 3;
    this.mark();
  }

  serveBySlot(slot: number) {
    const c = this.s.customers.find((x) => x.slot === slot && x.state === "wait");
    if (c) this.serve(c.key);
    else this.toast("ওই স্লটে কেউ নেই", "bad", 0.8);
  }

  serveBest() {
    const s = this.s;
    if (s.phase !== "playing") return;
    if (s.selected >= 0 && s.plates[s.selected]) {
      // hand-picked plate -> only serve someone who actually wants it
      const dish = s.plates[s.selected].dish;
      const match = s.customers
        .filter((c) => c.state === "wait" && c.order.id === dish.id)
        .sort((a, b) => a.patience - b.patience)[0];
      if (match) return this.serve(match.key);
      sfx.error();
      this.toast(`${dish.icon} ${dish.bn} এখন কেউ চায় না`, "bad", 1.1);
      s.selected = -1;
      this.mark();
      return;
    }
    const ready = new Set(s.plates.map((p) => p.dish.id));
    const match = s.customers
      .filter((c) => c.state === "wait" && ready.has(c.order.id))
      .sort((a, b) => a.patience - b.patience)[0];
    if (match) return this.serve(match.key);
    if (s.plates.length) this.toast("কারো অর্ডারই রেডি নেই!", "bad", 1);
    else if (s.customers.length) {
      this.toast("আগে খাবার বানান — নিচের স্টেশনে ট্যাপ!", "info", 1.4);
      if (s.hintStage === 0) s.hintStage = 1;
    }
    sfx.error();
  }

  buyUpgrade(id: string) {
    const s = this.s;
    if (s.phase !== "shop") return;
    const u = UPGRADES.find((x) => x.id === id);
    if (!u) return;
    const lvl = this.ulvl(id);
    if (lvl >= u.costs.length) return;
    const cost = u.costs[lvl];
    if (s.wallet < cost) {
      sfx.error();
      this.toast("টাকা যথেষ্ট নয়!", "bad", 1.2);
      return;
    }
    s.wallet -= cost;
    s.upgrades = { ...s.upgrades, [id]: lvl + 1 };
    this.derive();
    sfx.levelUp();
    const el = this.els.get("up_" + id);
    if (el) {
      const p = this.parts.center(el);
      this.parts.stars(p.x, p.y, "#ffb627", 14);
      this.parts.ring(p.x, p.y, "#17b8a6", 12, 0.6);
      this.parts.emoji(p.x, p.y - 20, u.icon, 2);
    }
    this.kick(6, "#17b8a6", 0.3);
    if (u.unlocks) {
      const d = DISHES.find((x) => x.id === u.unlocks);
      if (d) this.toast(`নতুন মেনু: ${d.icon} ${d.bn} — ${taka(d.price * s.priceMul)}`, "epic", 2.4);
    }
    this.mark();
  }

  /* ---------------- simulation ---------------- */

  private spawn() {
    const s = this.s;
    const used = new Set(s.customers.filter((c) => c.state === "enter" || c.state === "wait").map((c) => c.slot));
    let slot = -1;
    for (let i = 0; i < s.maxSlots; i++)
      if (!used.has(i)) {
        slot = i;
        break;
      }
    if (slot === -1) return;
    const type = this.pickType();
    const patience = Math.max(4, type.patience * s.patienceMul * (0.9 + s.rep / 320));
    const c: Customer = {
      key: "c" + this.uid++,
      uid: this.uid,
      type,
      slot,
      order: this.pickDish(type),
      patience,
      maxPatience: patience,
      state: "enter",
      t: 0,
      paid: 0,
      perfect: false,
      nudge: 0,
    };
    s.customers = [...s.customers, c];
    if (type.id === "blogger") {
      sfx.bell();
      this.toast("📸 ফুড ব্লগার এসে গেছে! পারফেক্ট বানাও!", "epic", 2);
      this.parts.confetti(18, ["#ff4d8d", "#ffb627", "#fff3dc"]);
    } else if (type.rich) {
      sfx.bell();
    }
    if (s.hintStage === 0 && s.day === 1) s.hintStage = 1;
    this.mark();
  }

  private tick(dt: number) {
    const s = this.s;
    s.clock -= dt;
    if (s.clock <= 0) {
      this.endDay();
      return;
    }

    // spawn
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      const repF = 0.72 + (s.rep / 100) * 0.55;
      const base = Math.max(1.4, 3.2 - s.day * 0.15);
      // opening rush: the first dozen seconds of a day should feel busy
      const rush = s.dayLen - s.clock < 12 ? 0.72 : 1;
      const gap = (base * rush) / (s.loc.spawnMul * (s.fest?.spawnMul ?? 1) * repF);
      this.spawnTimer = gap * (0.72 + Math.random() * 0.5);
      const waiting = s.customers.filter((c) => c.state === "wait" || c.state === "enter").length;
      if (waiting < s.maxSlots) this.spawn();
    }

    // customers
    let changed = false;
    const next: Customer[] = [];
    for (const c of s.customers) {
      c.t += dt;
      if (c.nudge > 0) c.nudge = Math.max(0, c.nudge - dt * 2);
      if (c.state === "enter") {
        if (c.t > 0.62) {
          c.state = "wait";
          c.t = 0;
          changed = true;
        }
        next.push(c);
      } else if (c.state === "wait") {
        c.patience -= dt;
        if (c.patience <= 0) {
          c.state = "angry";
          c.t = 0;
          c.patience = 0;
          s.combo = 0;
          s.stats.missed++;
          s.runMissed++;
          const hit = c.type.rich ? 9 : 7;
          s.rep = Math.max(0, s.rep - hit);
          const p = this.els.get("c_" + c.key) ? this.parts.center(this.els.get("c_" + c.key)!) : null;
          if (p) {
            this.parts.emoji(p.x, p.y - 60, "😡", 2);
            this.parts.sparks(p.x, p.y - 30, "#e8384f", 12, 150);
            this.parts.text(p.x, p.y - 84, "রেটিং −" + bn(hit), "#ff8fa3", 20);
          }
          sfx.angry();
          this.kick(11, "#e8384f", 0.4);
          this.toast(`${c.type.bn} রেগে চলে গেল! (${c.order.bn} রেডি ছিল না)`, "bad", 1.8);
          changed = true;
          if (s.rep <= 0) {
            this.gameOver("rep");
            return;
          }
        }
        next.push(c);
      } else {
        if (c.t > (c.state === "happy" ? 0.78 : 0.9)) changed = true;
        else next.push(c);
      }
    }
    if (next.length !== s.customers.length) {
      s.customers = next;
      changed = true;
    }
    // keep slots compact
    const waiting = s.customers.filter((c) => c.state === "enter" || c.state === "wait");
    waiting.forEach((c, i) => {
      if (c.slot !== i) {
        c.slot = i;
        changed = true;
      }
    });

    // plates / build timers
    for (const p of s.plates) p.t += dt;

    // auto maker
    if (s.autoEvery > 0 && s.current.length > 0) {
      this.autoTimer += dt;
      if (this.autoTimer >= s.autoEvery) {
        this.autoTimer = 0;
        const cands = this.candidates(s.current);
        if (cands.length) {
          const nextIng = cands[0].recipe[s.current.length];
          this.tapIng(nextIng, true);
        }
      }
    }

    if (changed) this.mark();
  }
}

export const game = new Game();
