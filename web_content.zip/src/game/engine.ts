import { AudioKit } from "./audio";
import {
  ARCH,
  CAMP,
  OASIS,
  RIVER,
  RUINS,
  SHRINES,
  WORLD,
  createProps,
  createWorldCanvas,
  drawCampfire,
  drawProp,
  drawShrine,
  drawWaterRipples,
  type Prop,
} from "./world";
import type { BannerEvent, HudSnapshot, RunResult } from "./types";

type Mode = "attract" | "playing" | "paused" | "dying" | "over";

interface Vec {
  x: number;
  y: number;
}

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  water: number;
  maxWater: number;
  attackCd: number;
  attackT: number;
  dashCd: number;
  dashT: number;
  invT: number;
  hurtT: number;
  walkT: number;
  facing: number;
  aim: number;
  moving: boolean;
}

interface Enemy {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  r: number;
  kind: "shade" | "wraith" | "elite";
  speed: number;
  score: number;
  phase: number;
  spawnT: number;
  flash: number;
  dead: boolean;
}

interface Shard {
  x: number;
  y: number;
  phase: number;
  alive: boolean;
  respawn: number;
  pulled: number;
}

interface Flask {
  x: number;
  y: number;
  phase: number;
  alive: boolean;
  respawn: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind: "dot" | "spark" | "ring" | "smoke" | "leaf";
  gravity: number;
  drag: number;
  rot: number;
  vr: number;
}

interface FloatText {
  x: number;
  y: number;
  life: number;
  max: number;
  text: string;
  color: string;
  size: number;
}

interface Slash {
  angle: number;
  t: number;
  life: number;
}

interface EngineOptions {
  onHud: (hud: HudSnapshot) => void;
  onGameOver: (result: RunResult) => void;
  muted: boolean;
}

const SPEED = 212;
const ATTACK_CD = 0.32;
const ATTACK_RANGE = 86;
const DASH_CD = 1.2;
const DASH_TIME = 0.18;
const COMBO_WINDOW = 5.2;
const MAX_PARTICLES = 330;
const EDGE = 62;
const DUSK_AT = 34;

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const dist = (ax: number, ay: number, bx: number, by: number) => Math.hypot(ax - bx, ay - by);
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);

const SHARD_START: Array<[number, number]> = [
  [64, -8],
  [128, -74],
  [-84, -108],
  [186, 52],
  [-168, 66],
  [246, -142],
  [-212, -194],
  [314, 108],
  [-36, 186],
  [402, -40],
  [-334, 96],
];

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private lightCanvas: HTMLCanvasElement;
  private lightCtx: CanvasRenderingContext2D;
  private terrain: HTMLCanvasElement;
  private props: Prop[];
  private options: EngineOptions;
  audio = new AudioKit();

  mode: Mode = "attract";
  private raf = 0;
  private last = 0;
  private time = 0;
  private runTime = 0;
  private hudTimer = 0;
  private view = { w: 800, h: 560 };
  private dpr = 1;
  private zoom = 1.05;
  private cam = { x: CAMP.x, y: CAMP.y };
  private shake = 0;
  private shakeX = 0;
  private shakeY = 0;
  private ro: ResizeObserver | null = null;

  private player: Player = this.freshPlayer();
  private enemies: Enemy[] = [];
  private shards: Shard[] = [];
  private flasks: Flask[] = [];
  private particles: Particle[] = [];
  private texts: FloatText[] = [];
  private slash: Slash | null = null;

  private keys = new Set<string>();
  private joy: Vec = { x: 0, y: 0 };

  private score = 0;
  private kills = 0;
  private shardsTaken = 0;
  private combo = 1;
  private comboT = 0;
  private cycles = 1;
  private cycleT = 0;
  private night = 0;
  private shrines: [boolean, boolean, boolean] = [false, false, false];
  private shrinesLitTotal = 0;
  private spawnTimer = 2.3;
  private enemySeq = 1;
  private duskAnnounced = false;
  private nextBannerId = 1;
  private banner: BannerEvent | null = null;
  private prompt: "shrine" | "heal" | null = null;
  private promptLabel = "";
  private promptShrine = -1;
  private deathTimer = 0;
  private overSent = false;
  private emberTimer = 0;
  private discovered = new Set<string>();
  private attractT = 0;
  private waterFlash = 0;
  private taughtCombat = false;

  private motes: Array<{ x: number; y: number; p: number; r: number }> = [];

  constructor(canvas: HTMLCanvasElement, options: EngineOptions) {
    this.canvas = canvas;
    this.options = options;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.lightCanvas = document.createElement("canvas");
    this.lightCtx = this.lightCanvas.getContext("2d")!;
    this.terrain = createWorldCanvas();
    this.props = createProps();

    const seed = (n: number) => {
      let a = n;
      return () => {
        a = (a * 16807) % 2147483647;
        return (a - 1) / 2147483646;
      };
    };
    const r = seed(9137);
    for (let i = 0; i < 72; i++) {
      this.motes.push({
        x: 80 + r() * (WORLD.w - 160),
        y: 80 + r() * (WORLD.h - 160),
        p: r() * Math.PI * 2,
        r: 0.7 + r() * 1.5,
      });
    }

    this.audio.setMuted(options.muted);
    this.attach();
    this.resize();
    this.seedAttract();
    this.last = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
  }

  private freshPlayer(): Player {
    return {
      x: CAMP.x,
      y: CAMP.y + 112,
      vx: 0,
      vy: 0,
      hp: 5,
      maxHp: 5,
      water: 100,
      maxWater: 100,
      attackCd: 0,
      attackT: 0,
      dashCd: 0,
      dashT: 0,
      invT: 0,
      hurtT: 0,
      walkT: 0,
      facing: 1,
      aim: -Math.PI / 2,
      moving: false,
    };
  }

  private rand(min: number, max: number) {
    return min + Math.random() * (max - min);
  }

  private clampWorld(v: number, axis: "x" | "y") {
    const max = axis === "x" ? WORLD.w - EDGE : WORLD.h - EDGE;
    return clamp(v, EDGE, max);
  }

  private attach() {
    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this.canvas);
  }

  private detach() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    this.ro?.disconnect();
    this.ro = null;
    cancelAnimationFrame(this.raf);
  }

  private onBlur = () => {
    this.keys.clear();
    this.joy = { x: 0, y: 0 };
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
    const gameKeys = ["Space", "ShiftLeft", "ShiftRight", "KeyE", "KeyJ", "KeyK", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"];
    if (gameKeys.includes(e.code) && this.mode === "playing") e.preventDefault();
    this.keys.add(e.code);
    if (this.mode !== "playing") return;
    if (!e.repeat) {
      if (e.code === "Space" || e.code === "KeyJ") this.tryAttack();
      if (e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyK") this.tryDash();
      if (e.code === "KeyE") this.interact();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private isDown(...codes: string[]) {
    return codes.some((c) => this.keys.has(c));
  }

  private resize() {
    const w = this.canvas.clientWidth || 800;
    const h = this.canvas.clientHeight || 560;
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    this.dpr = Math.min(window.devicePixelRatio || 1, coarse ? 1.6 : 2);
    this.view = { w, h };
    this.canvas.width = Math.max(1, Math.round(w * this.dpr));
    this.canvas.height = Math.max(1, Math.round(h * this.dpr));
    this.zoom = clamp(Math.min(w / 850, h / 560), 0.84, 1.24);
    const lw = Math.max(2, Math.round(w / 2));
    const lh = Math.max(2, Math.round(h / 2));
    if (this.lightCanvas.width !== lw || this.lightCanvas.height !== lh) {
      this.lightCanvas.width = lw;
      this.lightCanvas.height = lh;
    }
    this.cam = { ...this.cam };
  }

  setMuted(muted: boolean) {
    this.audio.setMuted(muted);
    this.options.muted = muted;
  }

  setTouchVector(x: number, y: number) {
    const len = Math.hypot(x, y);
    if (len > 1) {
      x /= len;
      y /= len;
    }
    this.joy = { x, y };
  }

  private seedAttract() {
    this.shards = SHARD_START.slice(0, 8).map(([dx, dy], i) => ({
      x: clamp(CAMP.x + dx * 0.85, EDGE, WORLD.w - EDGE),
      y: clamp(CAMP.y + dy * 0.85, EDGE, WORLD.h - EDGE),
      phase: i,
      alive: true,
      respawn: 0,
      pulled: 0,
    }));
    this.flasks = [];
    this.player = this.freshPlayer();
    this.cam = { x: CAMP.x + 20, y: CAMP.y - 30 };
  }

  start() {
    this.audio.init();
    this.mode = "playing";
    this.player = this.freshPlayer();
    this.enemies = [];
    this.particles = [];
    this.texts = [];
    this.flasks = [];
    this.slash = null;
    this.score = 0;
    this.kills = 0;
    this.shardsTaken = 0;
    this.combo = 1;
    this.comboT = 0;
    this.cycles = 1;
    this.cycleT = 0;
    this.night = 0;
    this.runTime = 0;
    this.shrines = [false, false, false];
    this.shrinesLitTotal = 0;
    this.spawnTimer = 1.4;
    this.enemySeq = 1;
    this.duskAnnounced = false;
    this.deathTimer = 0;
    this.overSent = false;
    this.discovered = new Set();
    this.waterFlash = 0;
    this.taughtCombat = false;
    this.prompt = null;
    this.promptShrine = -1;
    this.keys.clear();
    this.joy = { x: 0, y: 0 };

    const built: Shard[] = [];
    SHARD_START.forEach(([dx, dy], i) => {
      built.push({
        x: this.clampWorld(this.player.x + dx, "x"),
        y: this.clampWorld(this.player.y + dy, "y"),
        phase: i * 0.9,
        alive: true,
        respawn: 0,
        pulled: 0,
      });
    });
    for (let i = built.length; i < 30; i++) {
      const a = Math.random() * Math.PI * 2;
      const d = this.rand(220, 880);
      built.push({
        x: this.clampWorld(this.player.x + Math.cos(a) * d, "x"),
        y: this.clampWorld(this.player.y + Math.sin(a) * d, "y"),
        phase: i * 0.8,
        alive: true,
        respawn: 0,
        pulled: 0,
      });
    }
    this.shards = built;
    this.spawnFlask(this.player.x - 150, this.player.y + 190);
    this.spawnFlask(CAMP.x + 260, CAMP.y - 180);
    this.spawnFlask(920, 760);

    this.cam = { x: this.player.x, y: this.player.y - 40 };
    this.showBanner("الواحة تناديك", "اجمع النور، أيقظ الأضرحة الثلاثة، وابقَ حيًّا حتى الفجر", "gold");
    this.emitHud(true);
  }

  pause() {
    if (this.mode === "playing") {
      this.mode = "paused";
      this.keys.clear();
      this.joy = { x: 0, y: 0 };
    }
  }

  resume() {
    if (this.mode === "paused") {
      this.mode = "playing";
      this.audio.init();
      this.last = performance.now();
    }
  }

  backToAttract() {
    this.mode = "attract";
    this.attractT = 0;
    this.enemies = [];
    this.slash = null;
    this.particles = [];
    this.texts = [];
    this.shake = 0;
    this.shakeX = 0;
    this.shakeY = 0;
    this.seedAttract();
    this.showBanner("سِراب", "واحة تتنفّس تحت الرمال", "gold");
  }

  destroy() {
    this.detach();
    this.audio.dispose();
  }

  tryAttack() {
    if (this.mode !== "playing") return;
    const p = this.player;
    if (p.attackCd > 0) return;
    p.attackCd = ATTACK_CD;
    p.attackT = 0.26;

    let aim = p.aim;
    let nearest: Enemy | null = null;
    let nd = 128;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p.x, p.y, e.x, e.y);
      if (d < nd) {
        nd = d;
        nearest = e;
      }
    }
    if (nearest) aim = Math.atan2(nearest.y - p.y, nearest.x - p.x);
    p.aim = aim;
    p.facing = Math.cos(aim) >= 0 ? 1 : -1;
    this.slash = { angle: aim, t: 0, life: 0.26 };
    this.audio.slash();

    let hitAny = false;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p.x, p.y, e.x, e.y);
      const ang = Math.atan2(e.y - p.y, e.x - p.x);
      const diff = Math.abs(Math.atan2(Math.sin(ang - aim), Math.cos(ang - aim)));
      if (d < ATTACK_RANGE + e.r && (diff < 1.25 || d < 52)) {
        hitAny = true;
        this.hitEnemy(e, Math.cos(aim) * 30, Math.sin(aim) * 30);
      }
    }
    if (hitAny) {
      this.shake = Math.max(this.shake, 5.5);
      this.audio.hit();
    }
    for (let i = 0; i < 7; i++) {
      const a = aim + this.rand(-1.1, 1.1);
      this.addParticle({
        x: p.x + Math.cos(aim) * this.rand(22, 66),
        y: p.y - 18 + Math.sin(aim) * this.rand(14, 44),
        vx: Math.cos(a) * this.rand(40, 160),
        vy: Math.sin(a) * this.rand(25, 100) - 30,
        life: this.rand(0.18, 0.42),
        size: this.rand(1.4, 3.2),
        color: "#ffe2a5",
        kind: "spark",
        gravity: 160,
        drag: 0.9,
      });
    }
  }

  tryDash() {
    if (this.mode !== "playing") return;
    const p = this.player;
    if (p.dashCd > 0 || p.dashT > 0) return;
    let dx = this.joy.x + (this.isDown("KeyD", "ArrowRight") ? 1 : 0) - (this.isDown("KeyA", "ArrowLeft") ? 1 : 0);
    let dy = this.joy.y + (this.isDown("KeyS", "ArrowDown") ? 1 : 0) - (this.isDown("KeyW", "ArrowUp") ? 1 : 0);
    const len = Math.hypot(dx, dy);
    if (len < 0.15) {
      dx = Math.cos(p.aim);
      dy = Math.sin(p.aim);
    } else {
      dx /= len;
      dy /= len;
    }
    p.dashT = DASH_TIME;
    p.dashCd = DASH_CD;
    p.invT = Math.max(p.invT, DASH_TIME + 0.1);
    p.vx = dx * 660;
    p.vy = dy * 660;
    p.aim = Math.atan2(dy, dx);
    p.facing = dx >= 0 ? 1 : -1;
    this.audio.dash();
    this.shake = Math.max(this.shake, 3.5);
    for (let i = 0; i < 12; i++) {
      this.addParticle({
        x: p.x + this.rand(-10, 10),
        y: p.y - this.rand(4, 26),
        vx: -dx * this.rand(20, 90) + this.rand(-30, 30),
        vy: -dy * this.rand(20, 90) + this.rand(-30, 20),
        life: this.rand(0.24, 0.5),
        size: this.rand(2, 5),
        color: i % 2 ? "rgba(204,239,222,0.85)" : "rgba(246,217,159,0.9)",
        kind: "smoke",
        gravity: -20,
        drag: 0.9,
      });
    }
  }

  interact() {
    if (this.mode !== "playing") return;
    const near = this.nearestShrine();
    if (near >= 0 && near < 95) {
      this.lightShrine(near);
      return;
    }
    const p = this.player;
    if (this.nearWater(p.x, p.y) && (p.water < 96 || p.hp < p.maxHp)) {
      p.water = Math.min(p.maxWater, p.water + 46);
      p.hp = Math.min(p.maxHp, p.hp + (p.hp < p.maxHp ? 1 : 0));
      this.waterFlash = 1;
      this.score += 10;
      this.audio.heal();
      this.floatText(p.x, p.y - 54, "ماء عذب +٤٦", "#9fe3d4", 14);
      for (let i = 0; i < 14; i++) {
        this.addParticle({
          x: p.x + this.rand(-18, 18),
          y: p.y - this.rand(0, 22),
          vx: this.rand(-40, 40),
          vy: this.rand(-130, -30),
          life: this.rand(0.3, 0.7),
          size: this.rand(1.4, 3.4),
          color: "#bdeee0",
          kind: "dot",
          gravity: 120,
          drag: 0.93,
        });
      }
      this.emitHud(true);
    } else {
      this.audio.deny();
    }
  }

  private hitEnemy(e: Enemy, kx: number, ky: number) {
    e.hp -= 1;
    e.flash = 0.14;
    e.vx += kx;
    e.vy += ky;
    if (e.hp > 0) return;
    e.dead = true;
    this.kills++;
    this.combo = Math.min(6, this.combo + 1);
    this.comboT = COMBO_WINDOW;
    const gain = Math.round(e.score * Math.min(this.combo, 6) * (0.65 + this.night * 0.7));
    this.score += gain;
    this.floatText(e.x, e.y - 30, `+${gain}`, "#f7dda6", 16);
    this.shake = Math.max(this.shake, e.kind === "elite" ? 12 : 7);
    const colors =
      e.kind === "elite"
        ? ["#f0c07a", "#b66c48", "#3d2b4a", "#f8e5b4"]
        : ["#544572", "#8c76ad", "#cbb59b", "#e3b974"];
    for (let i = 0; i < (e.kind === "elite" ? 30 : 17); i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = this.rand(30, e.kind === "elite" ? 260 : 170);
      this.addParticle({
        x: e.x + this.rand(-10, 10),
        y: e.y - 18 + this.rand(-16, 16),
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 40,
        life: this.rand(0.3, 0.8),
        size: this.rand(1.5, 4.4),
        color: colors[Math.floor(Math.random() * colors.length)],
        kind: i % 3 === 0 ? "smoke" : "spark",
        gravity: 80,
        drag: 0.93,
      });
    }
    this.addParticle({
      x: e.x,
      y: e.y - 12,
      vx: 0,
      vy: 0,
      life: 0.5,
      size: e.r,
      color: e.kind === "elite" ? "rgba(240,192,122,0.55)" : "rgba(196,168,233,0.45)",
      kind: "ring",
      gravity: 0,
      drag: 1,
    });
    if (Math.random() < (e.kind === "elite" ? 0.9 : 0.24)) {
      this.spawnFlask(e.x, e.y + 8);
    }
    this.emitHud(true);
  }

  private nearestShrine(): number {
    let best = -1;
    let bd = 130;
    SHRINES.forEach((s, i) => {
      if (this.shrines[i]) return;
      const d = dist(this.player.x, this.player.y, s.x, s.y);
      if (d < bd) {
        bd = d;
        best = i;
      }
    });
    return best;
  }

  private nearWater(x: number, y: number) {
    const a = ((x - OASIS.x) / (OASIS.rx + 34)) ** 2 + ((y - OASIS.y) / (OASIS.ry + 30)) ** 2;
    const b = ((x - RIVER.x) / (RIVER.rx + 34)) ** 2 + ((y - RIVER.y) / (RIVER.ry + 30)) ** 2;
    return a < 1 || b < 1;
  }

  private lightShrine(index: number) {
    if (this.shrines[index]) return;
    this.shrines[index] = true;
    this.shrinesLitTotal++;
    const s = SHRINES[index];
    const p = this.player;
    p.hp = Math.min(p.maxHp, p.hp + 1);
    const shrineGain = 250 * Math.min(this.combo, 5);
    this.score += shrineGain;
    this.combo = Math.min(6, this.combo + 1);
    this.comboT = COMBO_WINDOW;
    this.shake = Math.max(this.shake, 9);
    this.audio.shrine();
    this.floatText(s.x, s.y - 120, `+${shrineGain}`, "#ffe2a5", 19);
    this.floatText(p.x, p.y - 58, "+قلب", "#f59d84", 14);
    this.addParticle({
      x: s.x,
      y: s.y - 40,
      vx: 0,
      vy: 0,
      life: 0.9,
      size: 46,
      color: "rgba(247,219,157,0.65)",
      kind: "ring",
      gravity: 0,
      drag: 1,
    });
    for (let i = 0; i < 38; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = this.rand(25, 170);
      this.addParticle({
        x: s.x + this.rand(-20, 20),
        y: s.y - this.rand(10, 100),
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 70,
        life: this.rand(0.5, 1.3),
        size: this.rand(1.5, 4),
        color: i % 3 ? "#f6dda9" : "#a9e3cd",
        kind: "spark",
        gravity: -10,
        drag: 0.95,
      });
    }
    const litCount = this.shrines.filter(Boolean).length;
    if (litCount === 3) {
      this.completeCycle();
    } else {
      this.showBanner(`أُضيء ${s.name}`, `${litCount} من ٣ — النور يعود ببطء إلى الواحة`, "gold");
    }
    this.emitHud(true);
  }

  private completeCycle() {
    this.cycles++;
    this.score += 1000;
    this.combo = Math.min(6, this.combo + 1);
    this.comboT = COMBO_WINDOW;
    this.player.hp = this.player.maxHp;
    this.player.water = Math.min(this.player.maxWater, this.player.water + 40);
    this.cycleT = 0;
    this.night = 0;
    this.duskAnnounced = false;
    this.shrines = [false, false, false];
    this.audio.cycle();
    this.shake = 17;
    this.floatText(this.player.x, this.player.y - 70, "+١٠٠٠", "#ffe8b4", 23);

    for (const e of this.enemies) {
      if (e.dead) continue;
      e.dead = true;
      this.kills++;
      for (let i = 0; i < 10; i++) {
        this.addParticle({
          x: e.x,
          y: e.y - 20,
          vx: this.rand(-160, 160),
          vy: this.rand(-200, 60),
          life: this.rand(0.5, 1),
          size: this.rand(1.5, 4),
          color: i % 2 ? "#f3d49a" : "#b9e4d5",
          kind: "spark",
          gravity: 120,
          drag: 0.94,
        });
      }
    }
    this.enemies = [];
    this.spawnTimer = 2.4;
    this.addParticle({
      x: this.player.x,
      y: this.player.y - 20,
      vx: 0,
      vy: 0,
      life: 1,
      size: 70,
      color: "rgba(247,219,157,0.55)",
      kind: "ring",
      gravity: 0,
      drag: 1,
    });
    for (let i = 0; i < 3; i++) {
      this.spawnFlask(this.player.x + this.rand(-140, 140), this.player.y + this.rand(-120, 120));
    }
    const e = this.player;
    for (let i = 0; i < 36; i++) {
      this.addParticle({
        x: e.x,
        y: e.y - 18,
        vx: this.rand(-240, 240),
        vy: this.rand(-250, 80),
        life: this.rand(0.5, 1.4),
        size: this.rand(1.6, 4.6),
        color: i % 3 === 0 ? "#a9e3cd" : "#f7dda6",
        kind: "spark",
        gravity: 60,
        drag: 0.95,
      });
    }
    this.showBanner(
      "أشرقت الواحة من جديد",
      `الدورة ${this.cycles} بدأت — الظلال ستأتي أقوى. +١٠٠٠ نقطة`,
      "teal",
    );
    this.emitHud(true);
  }

  private spawnFlask(x: number, y: number) {
    if (this.flasks.length > 8) return;
    this.flasks.push({
      x: this.clampWorld(x, "x"),
      y: this.clampWorld(y, "y"),
      phase: Math.random() * 6,
      alive: true,
      respawn: 0,
    });
  }

  private spawnEnemy() {
    const max = Math.min(13, 5 + this.cycles + Math.floor(this.night * 3));
    if (this.enemies.length >= max) return;
    let x = 0;
    let y = 0;
    let tries = 0;
    do {
      const a = Math.random() * Math.PI * 2;
      const d = this.rand(300, 580);
      x = this.clampWorld(this.player.x + Math.cos(a) * d, "x");
      y = this.clampWorld(this.player.y + Math.sin(a) * d, "y");
      tries++;
    } while (dist(x, y, this.player.x, this.player.y) < 280 && tries < 12);

    const roll = Math.random();
    let kind: Enemy["kind"] = "shade";
    if (this.cycles >= 2 && roll < 0.16) kind = "elite";
    else if (this.cycles >= 1 && roll < 0.46) kind = "wraith";
    const stats =
      kind === "elite"
        ? { hp: 4, r: 26, speed: 52, score: 190 }
        : kind === "wraith"
          ? { hp: 2, r: 19, speed: 86, score: 95 }
          : { hp: 1, r: 16, speed: 66, score: 55 };
    this.enemies.push({
      id: this.enemySeq++,
      x,
      y,
      vx: 0,
      vy: 0,
      hp: stats.hp + (this.cycles > 3 ? 1 : 0),
      maxHp: stats.hp + (this.cycles > 3 ? 1 : 0),
      r: stats.r,
      kind,
      speed: stats.speed + this.cycles * 3 + this.night * 14,
      score: stats.score,
      phase: Math.random() * 8,
      spawnT: 0.6,
      flash: 0,
      dead: false,
    });
    this.addParticle({
      x,
      y: y - 12,
      vx: 0,
      vy: 0,
      life: 0.6,
      size: stats.r,
      color: "rgba(87,68,110,0.5)",
      kind: "ring",
      gravity: 0,
      drag: 1,
    });
    this.audio.spawn();
  }

  private damagePlayer() {
    const p = this.player;
    if (p.invT > 0 || p.dashT > 0) return;
    p.hp -= 1;
    p.invT = 1.15;
    p.hurtT = 0.42;
    this.shake = Math.max(this.shake, 13);
    this.combo = 1;
    this.comboT = 0;
    this.audio.hurt();
    for (let i = 0; i < 18; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = this.rand(40, 190);
      this.addParticle({
        x: p.x + this.rand(-8, 8),
        y: p.y - 18,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 40,
        life: this.rand(0.3, 0.7),
        size: this.rand(1.5, 4),
        color: i % 3 ? "#d97a55" : "#f4d3a0",
        kind: "spark",
        gravity: 140,
        drag: 0.92,
      });
    }
    const ang = Math.atan2(p.y - this.cam.y, p.x - this.cam.x);
    p.vx += Math.cos(ang) * 160;
    p.vy += Math.sin(ang) * 160;
    if (p.hp <= 0) {
      p.hp = 0;
      this.die();
    }
    this.emitHud(true);
  }

  private die() {
    this.mode = "dying";
    this.deathTimer = 1.35;
    this.player.hurtT = 1;
    this.shake = 17;
    this.audio.death();
    for (let i = 0; i < 34; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = this.rand(30, 210);
      this.addParticle({
        x: this.player.x,
        y: this.player.y - 20,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 60,
        life: this.rand(0.6, 1.5),
        size: this.rand(1.6, 5),
        color: i % 4 === 0 ? "#f4d9a4" : i % 3 === 0 ? "#c97c5c" : "#5b4a6e",
        kind: i % 4 === 0 ? "spark" : "smoke",
        gravity: -40,
        drag: 0.95,
      });
    }
    this.emitHud(true);
  }

  private update(dt: number) {
    this.time += dt;
    this.ambient(dt);
    if (this.mode === "attract") {
      this.attractT += dt;
      const tx = CAMP.x + Math.cos(this.attractT * 0.11) * 120;
      const ty = CAMP.y + Math.sin(this.attractT * 0.11) * 80 - 20;
      this.cam.x += (tx - this.cam.x) * Math.min(1, dt * 1.2);
      this.cam.y += (ty - this.cam.y) * Math.min(1, dt * 1.2);
      this.updateParticles(dt);
      return;
    }
    if (this.mode === "dying") {
      this.deathTimer -= dt;
      this.updateParticles(dt);
      this.updateCamera(dt);
      if (this.deathTimer <= 0 && !this.overSent) {
        this.overSent = true;
        this.mode = "over";
        this.shake = 0;
        this.shakeX = 0;
        this.shakeY = 0;
        this.options.onGameOver({
          score: Math.round(this.score),
          kills: this.kills,
          shards: this.shardsTaken,
          shrines: this.shrinesLitTotal,
          cycles: this.cycles,
          time: Math.round(this.runTime),
        });
        this.emitHud(true);
      }
      return;
    }
    if (this.mode !== "playing") return;

    this.runTime += dt;
    this.updateParticles(dt);
    this.updateDusk(dt);
    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateShards(dt);
    this.updateFlasks(dt);
    this.updatePrompts();
    this.updateDiscoveries();
    this.updateCamera(dt);

    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnEnemy();
      const base = Math.max(1.5, 4.5 - this.cycles * 0.35 - this.night * 1.4 - this.runTime * 0.004);
      this.spawnTimer = base * this.rand(0.8, 1.25);
    }

    this.shake *= Math.exp(-dt * 7.5);
    if (this.shake < 0.12) this.shake = 0;
    const ang = Math.random() * Math.PI * 2;
    this.shakeX = Math.cos(ang) * this.shake;
    this.shakeY = Math.sin(ang) * this.shake;

    this.hudTimer += dt;
    if (this.hudTimer >= 0.085) {
      this.hudTimer = 0;
      this.emitHud();
    }
  }

  private ambient(dt: number) {
    this.emberTimer -= dt;
    if (this.emberTimer <= 0) {
      this.emberTimer = 0.12;
      this.addParticle({
        x: CAMP.x + this.rand(-13, 13),
        y: CAMP.y - this.rand(4, 24),
        vx: this.rand(-12, 12),
        vy: this.rand(-75, -38),
        life: this.rand(0.7, 1.6),
        size: this.rand(1, 2.6),
        color: Math.random() > 0.4 ? "rgba(255,196,112,0.9)" : "rgba(255,227,160,0.8)",
        kind: "dot",
        gravity: -9,
        drag: 0.99,
      });
    }
    this.waterFlash = Math.max(0, this.waterFlash - dt * 1.6);
    this.player.walkT += dt;
  }

  private updateDusk(dt: number) {
    this.cycleT += dt;
    const target = clamp((this.cycleT - DUSK_AT) / 26, 0, 1);
    this.night += (target - this.night) * Math.min(1, dt * 0.9);
    if (this.cycleT >= DUSK_AT && !this.duskAnnounced) {
      this.duskAnnounced = true;
      this.showBanner("حلّ الغسق", "الظلال تتحرك… النقاط تتضاعف، والحذر واجب", "clay");
      this.shake = Math.max(this.shake, 5);
      this.emitHud(true);
    }
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    p.attackCd = Math.max(0, p.attackCd - dt);
    p.attackT = Math.max(0, p.attackT - dt);
    p.dashCd = Math.max(0, p.dashCd - dt);
    p.dashT = Math.max(0, p.dashT - dt);
    p.invT = Math.max(0, p.invT - dt);
    p.hurtT = Math.max(0, p.hurtT - dt);
    if (this.slash) {
      this.slash.t += dt;
      if (this.slash.t > this.slash.life) this.slash = null;
    }
    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) {
        this.comboT = 0;
        this.combo = 1;
      }
    }

    if (this.isDown("Space", "KeyJ")) this.tryAttack();

    let dx = this.joy.x + (this.isDown("KeyD", "ArrowRight") ? 1 : 0) - (this.isDown("KeyA", "ArrowLeft") ? 1 : 0);
    let dy = this.joy.y + (this.isDown("KeyS", "ArrowDown") ? 1 : 0) - (this.isDown("KeyW", "ArrowUp") ? 1 : 0);
    const mag = Math.hypot(dx, dy);
    if (mag > 1) {
      dx /= mag;
      dy /= mag;
    }
    p.moving = Math.hypot(dx, dy) > 0.08;
    if (p.dashT <= 0) {
      const targetVX = dx * SPEED * (p.attackT > 0 ? 0.62 : 1);
      const targetVY = dy * SPEED * (p.attackT > 0 ? 0.62 : 1);
      const ease = Math.min(1, dt * (p.moving ? 15 : 20));
      p.vx += (targetVX - p.vx) * ease;
      p.vy += (targetVY - p.vy) * ease;
    } else {
      p.vx *= Math.exp(-dt * 2.4);
      p.vy *= Math.exp(-dt * 2.4);
      this.addParticle({
        x: p.x + this.rand(-7, 7),
        y: p.y - this.rand(2, 22),
        vx: this.rand(-20, 20),
        vy: this.rand(-20, 20),
        life: 0.28,
        size: this.rand(2, 4.5),
        color: "rgba(214,240,224,0.55)",
        kind: "smoke",
        gravity: 0,
        drag: 0.9,
      });
    }
    p.x = this.clampWorld(p.x + p.vx * dt, "x");
    p.y = this.clampWorld(p.y + p.vy * dt, "y");
    if (p.moving) {
      if (Math.abs(dx) > 0.15) p.facing = dx > 0 ? 1 : -1;
      if (p.attackT <= 0) p.aim = Math.atan2(dy, dx);
      if (Math.random() < dt * 14) {
        this.addParticle({
          x: p.x + this.rand(-6, 6),
          y: p.y + this.rand(-2, 3),
          vx: this.rand(-12, 12),
          vy: this.rand(-18, -4),
          life: this.rand(0.3, 0.65),
          size: this.rand(2, 4.4),
          color: "rgba(231,215,182,0.7)",
          kind: "smoke",
          gravity: -6,
          drag: 0.94,
        });
      }
    }

    p.water = Math.max(0, p.water - dt * 0.56);
    if (p.water <= 0) {
      p.hp = Math.max(0, p.hp - dt * 0.85);
      if (p.hp <= 0) {
        this.die();
        return;
      }
    }

    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      if (dist(p.x, p.y, e.x, e.y) < e.r + 15) this.damagePlayer();
    }
  }

  private updateEnemies(dt: number) {
    const p = this.player;
    for (const e of this.enemies) {
      if (e.dead) continue;
      e.spawnT = Math.max(0, e.spawnT - dt);
      e.flash = Math.max(0, e.flash - dt);
      if (e.spawnT > 0) continue;
      const d = dist(e.x, e.y, p.x, p.y);
      if (!this.taughtCombat && d < 235 && this.runTime > 5) {
        this.taughtCombat = true;
        this.showBanner("ظل يقترب منك", "مسافة للهجوم · Shift للاندفاع — أو استخدم أزرار اللمس", "clay");
        this.emitHud(true);
      }
      if (d > 1) {
        const nx = (p.x - e.x) / d;
        const ny = (p.y - e.y) / d;
        const wobble = Math.sin(this.time * 2.4 + e.phase) * 0.35;
        const tx = nx - ny * wobble;
        const ty = ny + nx * wobble;
        e.vx += (tx * e.speed - e.vx) * Math.min(1, dt * 2.4);
        e.vy += (ty * e.speed - e.vy) * Math.min(1, dt * 2.4);
      }
      for (const o of this.enemies) {
        if (o === e || o.dead) continue;
        const dd = dist(e.x, e.y, o.x, o.y);
        const min = e.r + o.r + 4;
        if (dd > 0.5 && dd < min) {
          e.vx += ((e.x - o.x) / dd) * 24;
          e.vy += ((e.y - o.y) / dd) * 24;
        }
      }
      e.x = this.clampWorld(e.x + e.vx * dt, "x");
      e.y = this.clampWorld(e.y + e.vy * dt, "y");
      e.vx *= Math.exp(-dt * 0.8);
      e.vy *= Math.exp(-dt * 0.8);
      if (Math.random() < dt * 5) {
        this.addParticle({
          x: e.x + this.rand(-8, 8),
          y: e.y - this.rand(2, 26),
          vx: this.rand(-12, 12),
          vy: this.rand(-24, -4),
          life: this.rand(0.4, 0.9),
          size: this.rand(2, 5),
          color: e.kind === "elite" ? "rgba(200,124,88,0.4)" : "rgba(107,88,136,0.42)",
          kind: "smoke",
          gravity: -18,
          drag: 0.96,
        });
      }
    }
    this.enemies = this.enemies.filter((e) => !e.dead);
  }

  private updateShards(dt: number) {
    const p = this.player;
    for (const s of this.shards) {
      if (!s.alive) {
        s.respawn -= dt;
        if (s.respawn <= 0) {
          const a = Math.random() * Math.PI * 2;
          const d = this.rand(260, 720);
          s.x = this.clampWorld(p.x + Math.cos(a) * d, "x");
          s.y = this.clampWorld(p.y + Math.sin(a) * d, "y");
          s.alive = true;
          s.pulled = 0;
        }
        continue;
      }
      const d = dist(p.x, p.y, s.x, s.y);
      if (d < 118 && d > 8) {
        const pull = (1 - d / 118) * 4.6 + 1.6;
        s.x += ((p.x - s.x) / d) * pull * 90 * dt;
        s.y += ((p.y - s.y) / d) * pull * 90 * dt;
        s.pulled = 1;
      }
      if (d < 28) {
        s.alive = false;
        s.respawn = this.rand(4.5, 8.5);
        this.shardsTaken++;
        this.combo = Math.min(6, this.combo + 1);
        this.comboT = COMBO_WINDOW;
        const gain = 25 * Math.min(this.combo, 6);
        this.score += gain;
        this.audio.pickup(this.combo);
        this.floatText(s.x, s.y - 18, `+${gain}`, "#ffe3a6", 14);
        this.addParticle({
          x: s.x,
          y: s.y,
          vx: 0,
          vy: 0,
          life: 0.4,
          size: 10,
          color: "rgba(255,224,158,0.7)",
          kind: "ring",
          gravity: 0,
          drag: 1,
        });
        for (let i = 0; i < 10; i++) {
          const a = Math.random() * Math.PI * 2;
          this.addParticle({
            x: s.x,
            y: s.y,
            vx: Math.cos(a) * this.rand(20, 110),
            vy: Math.sin(a) * this.rand(20, 110) - 30,
            life: this.rand(0.25, 0.6),
            size: this.rand(1.2, 3),
            color: i % 3 === 0 ? "#fff2cd" : "#e8be78",
            kind: "spark",
            gravity: 70,
            drag: 0.92,
          });
        }
      }
    }
  }

  private updateFlasks(dt: number) {
    const p = this.player;
    for (const f of this.flasks) {
      if (!f.alive) {
        f.respawn -= dt;
        if (f.respawn <= 0) {
          const a = Math.random() * Math.PI * 2;
          const d = this.rand(250, 760);
          f.x = this.clampWorld(p.x + Math.cos(a) * d, "x");
          f.y = this.clampWorld(p.y + Math.sin(a) * d, "y");
          f.alive = true;
        }
        continue;
      }
      if (dist(p.x, p.y, f.x, f.y) < 32) {
        f.alive = false;
        f.respawn = this.rand(16, 26);
        p.water = Math.min(p.maxWater, p.water + 38);
        p.hp = Math.min(p.maxHp, p.hp + 1);
        this.score += 20;
        this.waterFlash = 1;
        this.audio.heal();
        this.floatText(f.x, f.y - 24, "+٣٨ ماء · +قلب", "#a9e7d5", 14);
        for (let i = 0; i < 12; i++) {
          this.addParticle({
            x: f.x,
            y: f.y - 8,
            vx: this.rand(-55, 55),
            vy: this.rand(-130, -30),
            life: this.rand(0.3, 0.7),
            size: this.rand(1.5, 3.4),
            color: i % 2 ? "#a9e7d5" : "#e6f5e8",
            kind: "dot",
            gravity: 90,
            drag: 0.92,
          });
        }
      }
    }
    if (this.flasks.length < 3) {
      this.spawnFlask(this.player.x + this.rand(-450, 450), this.player.y + this.rand(-380, 380));
    }
  }

  private updatePrompts() {
    const near = this.nearestShrine();
    if (near >= 0 && dist(this.player.x, this.player.y, SHRINES[near].x, SHRINES[near].y) < 92) {
      this.prompt = "shrine";
      this.promptShrine = near;
      this.promptLabel = `أيقظ ${SHRINES[near].name}`;
      return;
    }
    this.promptShrine = -1;
    if (this.nearWater(this.player.x, this.player.y) && (this.player.water < 96 || this.player.hp < this.player.maxHp)) {
      this.prompt = "heal";
      this.promptLabel = "اشرب من ماء الواحة";
      return;
    }
    this.prompt = null;
    this.promptLabel = "";
  }

  private updateDiscoveries() {
    const places: Array<[string, string, number, number, number]> = [
      ["oasis", "واحة القمر", OASIS.x, OASIS.y, 330],
      ["ruins", "أطلال الغروب", RUINS.x, RUINS.y, 310],
      ["arch", "قوس الرياح", ARCH.x, ARCH.y, 260],
      ["river", "نهر الرمل", RIVER.x, RIVER.y, 220],
    ];
    for (const [key, name, x, y, r] of places) {
      if (this.discovered.has(key)) continue;
      if (dist(this.player.x, this.player.y, x, y) < r) {
        this.discovered.add(key);
        this.score += 80;
        this.audio.shrine();
        this.floatText(this.player.x, this.player.y - 66, "+٨٠ استكشاف", "#ffe3a6", 15);
        this.showBanner(`استكشفت ${name}`, "مناطق جديدة تفتح أسرار الواحة", "teal");
        this.emitHud(true);
      }
    }
  }

  private updateCamera(dt: number) {
    const p = this.player;
    const halfW = this.view.w / (2 * this.zoom);
    const halfH = this.view.h / (2 * this.zoom);
    let tx = p.x + p.vx * 0.09;
    let ty = p.y - 18 + p.vy * 0.09;
    if (halfW * 2 >= WORLD.w) tx = WORLD.w / 2;
    else tx = clamp(tx, halfW + 10, WORLD.w - halfW - 10);
    if (halfH * 2 >= WORLD.h) ty = WORLD.h / 2;
    else ty = clamp(ty, halfH + 10, WORLD.h - halfH - 10);
    const ease = Math.min(1, dt * 6.2);
    this.cam.x += (tx - this.cam.x) * ease;
    this.cam.y += (ty - this.cam.y) * ease;
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      p.vx *= Math.pow(p.drag, dt * 60);
      p.vy *= Math.pow(p.drag, dt * 60);
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= 28 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
  }

  private addParticle(p: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    life: number;
    size: number;
    color: string;
    kind: Particle["kind"];
    gravity: number;
    drag: number;
  }) {
    if (this.particles.length >= MAX_PARTICLES) this.particles.shift();
    this.particles.push({
      ...p,
      max: p.life,
      rot: Math.random() * Math.PI * 2,
      vr: this.rand(-3, 3),
    });
  }

  private floatText(x: number, y: number, text: string, color: string, size: number) {
    if (this.texts.length > 16) this.texts.shift();
    this.texts.push({ x, y, life: 1.05, max: 1.05, text, color, size });
  }

  private showBanner(title: string, sub: string, tone: "gold" | "teal" | "clay") {
    this.banner = { id: this.nextBannerId++, title, sub, tone };
  }

  private emitHud(force = false) {
    if (!force && this.mode !== "playing" && this.mode !== "dying") return;
    this.options.onHud({
      hp: Math.ceil(this.player.hp),
      maxHp: this.player.maxHp,
      water: clamp(this.player.water, 0, this.player.maxWater),
      maxWater: this.player.maxWater,
      score: Math.round(this.score),
      combo: this.combo,
      comboProgress: this.combo > 1 ? clamp(this.comboT / COMBO_WINDOW, 0, 1) : 0,
      shrines: [...this.shrines] as [boolean, boolean, boolean],
      cycles: this.cycles,
      night: this.night,
      time: this.runTime,
      kills: this.kills,
      shards: this.shardsTaken,
      dashReady: this.player.dashCd <= 0,
      dashProgress: 1 - clamp(this.player.dashCd / DASH_CD, 0, 1),
      prompt: this.prompt,
      promptLabel: this.promptLabel,
      banner: this.banner,
    });
  }

  private loop(now: number) {
    const raw = (now - this.last) / 1000;
    this.last = now;
    const dt = Math.min(0.045, Math.max(0, raw));
    this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    const p = this.player;
    const speed = Math.hypot(p.vx, p.vy);
    const step = Math.sin(this.time * 13) * Math.min(1, speed / 170);
    ctx.save();
    ctx.translate(p.x, p.y);
    if (this.combo >= 3 && this.mode === "playing") {
      const aura = ctx.createRadialGradient(0, -16, 4, 0, -16, 40);
      aura.addColorStop(0, `rgba(247, 216, 154, ${0.06 + (this.combo - 3) * 0.05})`);
      aura.addColorStop(0.62, `rgba(227, 185, 116, ${0.05 + (this.combo - 3) * 0.025})`);
      aura.addColorStop(1, "rgba(227, 185, 116, 0)");
      ctx.fillStyle = aura;
      ctx.fillRect(-42, -58, 84, 84);
      ctx.strokeStyle = `rgba(245, 219, 164, ${0.14 + (this.combo - 3) * 0.05})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(0, 0, 25 + (this.combo - 3) * 2, 10 + (this.combo - 3) * 0.8, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(50, 38, 25, 0.26)";
    ctx.beginPath();
    ctx.ellipse(2, 2, 17, 6.5, 0, 0, Math.PI * 2);
    ctx.fill();

    if (p.invT > 0 && p.dashT <= 0) {
      ctx.globalAlpha = 0.6 + Math.sin(this.time * 34) * 0.3;
    }

    ctx.save();
    ctx.scale(p.facing, 1);
    const bob = (p.moving ? Math.abs(Math.sin(this.time * 11)) * 1.9 : Math.sin(this.time * 2.2) * 0.7) - 1;
    ctx.translate(0, bob);

    // legs
    ctx.strokeStyle = "#3d3129";
    ctx.lineWidth = 4.2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-4.5, -12);
    ctx.lineTo(-5 + step * 3.4, -2);
    ctx.moveTo(4.5, -12);
    ctx.lineTo(5 - step * 3.4, -2);
    ctx.stroke();
    ctx.fillStyle = "#624735";
    ctx.beginPath();
    ctx.ellipse(-5 + step * 3.4, -1.5, 3.6, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(5 - step * 3.4, -1.5, 3.6, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();

    // flowing scarf
    const flap = Math.sin(this.time * 6 + speed * 0.02) * 5;
    ctx.fillStyle = "#2f7a71";
    ctx.beginPath();
    ctx.moveTo(-8, -36);
    ctx.quadraticCurveTo(-25, -29 + flap, -29 - speed * 0.02, -20 + flap);
    ctx.quadraticCurveTo(-20, -24, -8, -27);
    ctx.closePath();
    ctx.fill();

    // cloak
    const cloak = ctx.createLinearGradient(-13, -42, 14, 0);
    cloak.addColorStop(0, "#d38a5b");
    cloak.addColorStop(0.5, "#b96b45");
    cloak.addColorStop(1, "#8e4f36");
    ctx.fillStyle = cloak;
    ctx.beginPath();
    ctx.moveTo(-11, -38);
    ctx.quadraticCurveTo(-16, -24, -13, -8);
    ctx.quadraticCurveTo(0, -3, 13, -8);
    ctx.quadraticCurveTo(16, -24, 11, -38);
    ctx.quadraticCurveTo(0, -44, -11, -38);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(247, 216, 164, 0.65)";
    ctx.beginPath();
    ctx.moveTo(-11, -9);
    ctx.quadraticCurveTo(0, -4, 12, -9);
    ctx.lineTo(11, -5);
    ctx.quadraticCurveTo(0, 0, -10, -5);
    ctx.closePath();
    ctx.fill();

    // belt
    ctx.fillStyle = "#3c7c72";
    ctx.beginPath();
    ctx.roundRect(-12, -24, 24, 4.5, 2);
    ctx.fill();
    ctx.fillStyle = "#e6c383";
    ctx.beginPath();
    ctx.arc(1, -22, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // arm + scimitar
    ctx.strokeStyle = "#c9805a";
    ctx.lineWidth = 3.6;
    ctx.beginPath();
    ctx.moveTo(9, -33);
    ctx.lineTo(15, -22 + (p.attackT > 0 ? -4 : 0));
    ctx.stroke();
    ctx.save();
    ctx.translate(15, -20);
    ctx.rotate(p.attackT > 0 ? -0.9 : 0.5);
    ctx.strokeStyle = "#e8dcc0";
    ctx.lineWidth = 2.6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(0, 2);
    ctx.quadraticCurveTo(3, -9, 0, -18);
    ctx.stroke();
    ctx.strokeStyle = "#7b5f3b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-0.5, 2);
    ctx.lineTo(0.5, 7);
    ctx.stroke();
    ctx.fillStyle = "#e3b974";
    ctx.beginPath();
    ctx.ellipse(0, 2, 4, 1.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // head
    ctx.fillStyle = "#d6a077";
    ctx.beginPath();
    ctx.arc(0, -46, 8.2, 0, Math.PI * 2);
    ctx.fill();
    // keffiyeh
    const cloth = ctx.createLinearGradient(-9, -56, 9, -38);
    cloth.addColorStop(0, "#f2e6cc");
    cloth.addColorStop(1, "#d8c6a4");
    ctx.fillStyle = cloth;
    ctx.beginPath();
    ctx.arc(0, -47, 9.3, Math.PI * 0.95, Math.PI * 2.1);
    ctx.lineTo(8, -42);
    ctx.quadraticCurveTo(12, -36, 9, -32);
    ctx.lineTo(2, -38);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(140, 111, 70, 0.35)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-8, -49);
    ctx.quadraticCurveTo(0, -53, 8, -48);
    ctx.stroke();
    // gold band
    ctx.strokeStyle = "#c09a5d";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(0, -47, 8.6, Math.PI * 1.03, Math.PI * 1.97);
    ctx.stroke();
    // eyes
    ctx.fillStyle = "#3c2a21";
    ctx.beginPath();
    ctx.arc(3.6, -46, 1.05, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-1.4, -46.4, 0.9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.restore();

    if (p.invT > 0 && this.mode === "playing") {
      ctx.save();
      ctx.strokeStyle = "rgba(247, 221, 166, 0.5)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.ellipse(p.x, p.y - 2, 22, 9, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy) {
    const bob = Math.sin(this.time * 2.8 + e.phase) * 4;
    const scale = e.spawnT > 0 ? 1 - e.spawnT / 0.6 : 1;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    ctx.globalAlpha = e.spawnT > 0 ? 0.35 + scale * 0.65 : 1;
    ctx.fillStyle = "rgba(46, 32, 48, 0.28)";
    ctx.beginPath();
    ctx.ellipse(2, 4 - bob, e.r * 0.9, e.r * 0.32, 0, 0, Math.PI * 2);
    ctx.fill();

    const aura = ctx.createRadialGradient(0, -e.r, 2, 0, -e.r, e.r * 2.4);
    aura.addColorStop(0, e.kind === "elite" ? "rgba(198, 113, 78, 0.34)" : "rgba(103, 81, 132, 0.3)");
    aura.addColorStop(1, "rgba(70, 50, 88, 0)");
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(0, -e.r, e.r * 2.4, 0, Math.PI * 2);
    ctx.fill();

    // wispy tail
    ctx.fillStyle = e.kind === "elite" ? "rgba(68, 42, 57, 0.84)" : "rgba(43, 35, 58, 0.82)";
    ctx.beginPath();
    ctx.moveTo(-e.r * 0.8, -e.r * 1.05);
    ctx.quadraticCurveTo(-e.r * 1.5, -e.r * 0.2, -e.r * 0.3, e.r * 0.1);
    ctx.quadraticCurveTo(0, -e.r * 0.2, e.r * 0.3, e.r * 0.1);
    ctx.quadraticCurveTo(e.r * 1.5, -e.r * 0.2, e.r * 0.8, -e.r * 1.05);
    ctx.closePath();
    ctx.fill();

    // body silhouette
    const g = ctx.createLinearGradient(-e.r, -e.r * 2.4, e.r, 0);
    g.addColorStop(0, e.kind === "elite" ? "#4d3040" : "#342b47");
    g.addColorStop(0.6, "#231c31");
    g.addColorStop(1, "#171320");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, -e.r * 1.05, e.r * 0.92, e.r * 1.13, Math.sin(this.time + e.phase) * 0.07, 0, Math.PI * 2);
    ctx.fill();

    if (e.kind === "elite") {
      ctx.strokeStyle = "rgba(216,158,110,0.8)";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(-e.r * 0.6, -e.r * 1.9);
      ctx.quadraticCurveTo(-e.r * 1.1, -e.r * 2.7, -e.r * 0.4, -e.r * 2.5);
      ctx.moveTo(e.r * 0.6, -e.r * 1.9);
      ctx.quadraticCurveTo(e.r * 1.1, -e.r * 2.7, e.r * 0.4, -e.r * 2.5);
      ctx.stroke();
    }

    // eyes
    const eyeGlow = 0.8 + Math.sin(this.time * 4 + e.phase) * 0.2;
    ctx.fillStyle = e.kind === "elite" ? `rgba(255, 182, 116, ${eyeGlow})` : `rgba(242, 214, 146, ${eyeGlow})`;
    ctx.shadowColor = e.kind === "elite" ? "#f0a366" : "#f0d394";
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.ellipse(-e.r * 0.3, -e.r * 1.18, e.r * 0.17, e.r * 0.12, -0.25, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(e.r * 0.3, -e.r * 1.18, e.r * 0.17, e.r * 0.12, 0.25, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    if (e.flash > 0) {
      ctx.globalAlpha = e.flash / 0.14;
      ctx.fillStyle = "#fff1cf";
      ctx.beginPath();
      ctx.ellipse(0, -e.r * 1.05, e.r * 0.92, e.r * 1.13, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    if (e.hp < e.maxHp) {
      const w = e.r * 1.8;
      ctx.fillStyle = "rgba(12, 20, 20, 0.5)";
      ctx.beginPath();
      ctx.roundRect(-w / 2, -e.r * 2.7, w, 3.4, 2);
      ctx.fill();
      ctx.fillStyle = e.kind === "elite" ? "#e6a470" : "#e6cf9b";
      ctx.beginPath();
      ctx.roundRect(-w / 2, -e.r * 2.7, w * (e.hp / e.maxHp), 3.4, 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private render() {
    const { ctx } = this;
    const { w, h } = this.view;
    if (!w || !h) return;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = "#c6ab80";
    ctx.fillRect(0, 0, w, h);

    const zoom = this.zoom;
    const halfW = w / (2 * zoom);
    const halfH = h / (2 * zoom);
    const camX = this.cam.x + this.shakeX / zoom;
    const camY = this.cam.y + this.shakeY / zoom;
    const left = camX - halfW;
    const top = camY - halfH;

    ctx.save();
    ctx.translate(w / 2 + this.shakeX, h / 2 + this.shakeY);
    ctx.scale(zoom, zoom);
    ctx.translate(-camX, -camY);

    const sx = Math.max(0, Math.floor(left - 90));
    const sy = Math.max(0, Math.floor(top - 90));
    const sw = Math.min(WORLD.w - sx, Math.ceil(halfW * 2 + 180));
    const sh = Math.min(WORLD.h - sy, Math.ceil(halfH * 2 + 180));
    if (sw > 0 && sh > 0) ctx.drawImage(this.terrain, sx, sy, sw, sh, sx, sy, sw, sh);

    drawWaterRipples(ctx, this.time);

    const pad = 120;
    const inView = (x: number, y: number) => x > left - pad && x < left + halfW * 2 + pad && y > top - pad && y < top + halfH * 2 + pad;

    // moody contact shadows under landmarks
    for (let i = 0; i < SHRINES.length; i++) {
      if (inView(SHRINES[i].x, SHRINES[i].y)) {
        drawShrine(ctx, SHRINES[i], this.shrines[i], this.time, this.promptShrine === i);
      }
    }
    if (inView(CAMP.x, CAMP.y)) drawCampfire(ctx, this.time);

    const drawables: Array<{ y: number; draw: () => void }> = [];
    for (const prop of this.props) {
      if (!inView(prop.x, prop.y)) continue;
      drawables.push({ y: prop.y, draw: () => drawProp(ctx, prop, this.time) });
    }

    for (const s of this.shards) {
      if (!s.alive || !inView(s.x, s.y)) continue;
      drawables.push({
        y: s.y,
        draw: () => {
          const pulse = Math.sin(this.time * 3 + s.phase) * 0.5 + 0.5;
          const bob = Math.sin(this.time * 2.3 + s.phase) * 4;
          ctx.save();
          ctx.translate(s.x, s.y + bob);
          const glow = ctx.createRadialGradient(0, -10, 1, 0, -10, 30 + pulse * 8);
          glow.addColorStop(0, "rgba(255, 228, 164, 0.5)");
          glow.addColorStop(1, "rgba(255, 228, 164, 0)");
          ctx.fillStyle = glow;
          ctx.beginPath();
          ctx.arc(0, -10, 38, 0, Math.PI * 2);
          ctx.fill();
          ctx.rotate(Math.sin(this.time * 1.3 + s.phase) * 0.24);
          ctx.fillStyle = "#f7dfa8";
          ctx.strokeStyle = "#b58948";
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(0, -23);
          ctx.lineTo(8, -10);
          ctx.lineTo(0, 2);
          ctx.lineTo(-8, -10);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = "rgba(255,255,242,0.92)";
          ctx.beginPath();
          ctx.moveTo(0, -18);
          ctx.lineTo(4, -10);
          ctx.lineTo(0, -4);
          ctx.lineTo(-4, -10);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = "rgba(240, 210, 148, 0.9)";
          ctx.beginPath();
          ctx.arc(-13, -18 - pulse * 4, 1.4, 0, Math.PI * 2);
          ctx.arc(12, -4 + pulse * 3, 1, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        },
      });
    }

    for (const f of this.flasks) {
      if (!f.alive || !inView(f.x, f.y)) continue;
      drawables.push({
        y: f.y,
        draw: () => {
          const bob = Math.sin(this.time * 2 + f.phase) * 2.5;
          ctx.save();
          ctx.translate(f.x, f.y + bob);
          ctx.fillStyle = "rgba(47, 39, 27, 0.22)";
          ctx.beginPath();
          ctx.ellipse(0, 2, 12, 4, 0, 0, Math.PI * 2);
          ctx.fill();
          const glow = ctx.createRadialGradient(0, -12, 2, 0, -12, 24);
          glow.addColorStop(0, "rgba(142, 226, 207, 0.32)");
          glow.addColorStop(1, "rgba(142, 226, 207, 0)");
          ctx.fillStyle = glow;
          ctx.fillRect(-28, -40, 56, 56);
          ctx.fillStyle = "#4c9d92";
          ctx.beginPath();
          ctx.ellipse(0, -11, 8.5, 11, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#78bfb2";
          ctx.beginPath();
          ctx.ellipse(-2.5, -13, 4.5, 6.5, -0.2, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#d8c29a";
          ctx.beginPath();
          ctx.roundRect(-3.4, -25, 6.8, 7, 2);
          ctx.fill();
          ctx.strokeStyle = "rgba(244, 235, 208, 0.65)";
          ctx.lineWidth = 1.3;
          ctx.beginPath();
          ctx.arc(0, -11, 7, -1.2, 0.4);
          ctx.stroke();
          ctx.restore();
        },
      });
    }

    for (const e of this.enemies) {
      if (!inView(e.x, e.y)) continue;
      drawables.push({ y: e.y, draw: () => this.drawEnemy(ctx, e) });
    }
    drawables.push({ y: this.player.y, draw: () => this.drawPlayer(ctx) });
    drawables.sort((a, b) => a.y - b.y);
    for (const d of drawables) d.draw();

    if (this.slash) {
      const t = clamp(this.slash.t / this.slash.life, 0, 1);
      const p = this.player;
      ctx.save();
      ctx.translate(p.x, p.y - 20);
      ctx.rotate(this.slash.angle);
      ctx.globalAlpha = 0.85 * (1 - t);
      const spread = -1.15 + easeOut(t) * 2.3;
      const grad = ctx.createLinearGradient(18, 0, 88, 0);
      grad.addColorStop(0, "rgba(255, 238, 192, 0.05)");
      grad.addColorStop(0.6, "rgba(255, 223, 154, 0.5)");
      grad.addColorStop(1, "rgba(255, 250, 226, 0.92)");
      ctx.strokeStyle = grad;
      ctx.lineWidth = 5 - t * 2;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.arc(0, 0, 72, spread - 1.25, spread + 0.15);
      ctx.stroke();
      ctx.strokeStyle = "rgba(255, 247, 218, 0.6)";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(0, 0, 58, spread - 1.25, spread + 0.25);
      ctx.stroke();
      ctx.restore();
    }

    // Particles
    for (const p of this.particles) {
      if (!inView(p.x, p.y)) continue;
      const a = clamp(p.life / p.max, 0, 1);
      if (p.kind === "ring") {
        ctx.globalAlpha = a * 0.8;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1 + (1 - a) * 2.6), 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.kind === "spark") {
        ctx.globalAlpha = a;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = Math.max(0.8, p.size * 0.5);
        ctx.beginPath();
        ctx.moveTo(p.x - p.size, p.y);
        ctx.lineTo(p.x + p.size, p.y);
        ctx.moveTo(p.x, p.y - p.size);
        ctx.lineTo(p.x, p.y + p.size);
        ctx.stroke();
      } else if (p.kind === "smoke") {
        ctx.globalAlpha = a * 0.5;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1.6 - a * 0.6), 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (0.5 + a * 0.5), 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;

    for (const t of this.texts) {
      const a = clamp(t.life / t.max, 0, 1);
      ctx.globalAlpha = Math.min(1, a * 1.8);
      ctx.font = `600 ${t.size}px "IBM Plex Sans Arabic", sans-serif`;
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(20, 36, 30, 0.4)";
      ctx.fillText(t.text, t.x + 1.5, t.y + 1.5);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;

    // Ambient motes
    for (const m of this.motes) {
      if (!inView(m.x, m.y)) continue;
      const x = m.x + Math.sin(this.time * 0.35 + m.p) * 18;
      const y = m.y + Math.cos(this.time * 0.28 + m.p * 1.4) * 14;
      const a = 0.2 + 0.35 * (0.5 + Math.sin(this.time * 1.2 + m.p) * 0.5);
      ctx.fillStyle = `rgba(255, 236, 188, ${a})`;
      ctx.beginPath();
      ctx.arc(x, y, m.r, 0, Math.PI * 2);
      ctx.fill();
    }

    if (this.mode === "dying") {
      ctx.fillStyle = `rgba(24, 12, 12, ${clamp((1.35 - this.deathTimer) / 1.35, 0, 0.55)})`;
      ctx.fillRect(left - 30, top - 30, halfW * 2 + 60, halfH * 2 + 60);
    }
    ctx.restore();

    this.renderLighting(camX, camY, left, top);

    this.renderIndicators();

    // full-screen feedback
    if (this.player.hurtT > 0) {
      const a = (this.player.hurtT / 0.42) * 0.24;
      ctx.fillStyle = `rgba(178, 54, 41, ${a})`;
      ctx.fillRect(0, 0, w, h);
    }
    const p = this.player;
    if (p.hp <= 1 && this.mode === "playing" && p.hp > 0) {
      const pulse = 0.5 + Math.sin(this.time * 4.4) * 0.5;
      const low = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.68);
      low.addColorStop(0, "rgba(110, 20, 16, 0)");
      low.addColorStop(1, `rgba(110, 20, 16, ${0.26 + pulse * 0.2})`);
      ctx.fillStyle = low;
      ctx.fillRect(0, 0, w, h);
    }
  }

  private renderLighting(camX: number, camY: number, left: number, top: number) {
    const alpha = clamp(this.night * 0.58 + (this.mode === "attract" ? 0.12 : 0), 0, 0.66);
    if (alpha <= 0.015) return;
    const ctx = this.ctx;
    const { w, h } = this.view;
    const lw = this.lightCanvas.width;
    const lh = this.lightCanvas.height;
    const scale = lw / w;
    const l = this.lightCtx;
    l.setTransform(1, 0, 0, 1, 0, 0);
    l.globalCompositeOperation = "source-over";
    l.clearRect(0, 0, lw, lh);
    l.fillStyle = `rgba(10, 24, 38, ${alpha})`;
    l.fillRect(0, 0, lw, lh);
    l.globalCompositeOperation = "destination-out";

    const hole = (wx: number, wy: number, radius: number, strength: number) => {
      const x = (wx - camX) * this.zoom * scale + lw / 2;
      const y = (wy - camY) * this.zoom * scale + lh / 2;
      const r = radius * this.zoom * scale;
      const g = l.createRadialGradient(x, y, r * 0.12, x, y, r);
      g.addColorStop(0, `rgba(0,0,0,${strength})`);
      g.addColorStop(0.55, `rgba(0,0,0,${strength * 0.6})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      l.fillStyle = g;
      l.fillRect(x - r, y - r, r * 2, r * 2);
    };
    hole(CAMP.x, CAMP.y - 10, 210, 0.95);
    SHRINES.forEach((s, i) => {
      if (this.shrines[i]) hole(s.x, s.y - 50, 170, 0.9);
    });
    hole(this.player.x, this.player.y - 26, 132, 0.72);
    for (const f of this.flasks) if (f.alive) hole(f.x, f.y, 40, 0.3);
    l.globalCompositeOperation = "source-over";

    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.drawImage(this.lightCanvas, 0, 0, w, h);

    // Warm color blooms
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const glow = (wx: number, wy: number, r: number, color: string) => {
      const x = (wx - camX) * this.zoom + w / 2;
      const y = (wy - camY) * this.zoom + h / 2;
      if (x < -r || y < -r || x > w + r || y > h + r) return;
      const g = ctx.createRadialGradient(x, y, 1, x, y, r);
      g.addColorStop(0, color);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(x - r, y - r, r * 2, r * 2);
    };
    const warm = alpha * 0.5;
    glow(CAMP.x, CAMP.y - 8, 200 * this.zoom, `rgba(255, 178, 84, ${warm})`);
    SHRINES.forEach((s, i) => {
      if (this.shrines[i]) glow(s.x, s.y - 50, 150 * this.zoom, `rgba(246, 207, 130, ${warm * 0.7})`);
    });
    glow(this.player.x, this.player.y - 24, 100 * this.zoom, `rgba(255, 206, 128, ${warm * 0.3})`);
    ctx.restore();
    void left;
    void top;
  }

  private renderIndicators() {
    if (this.mode === "attract") return;
    const ctx = this.ctx;
    const { w, h } = this.view;
    const toScreen = (x: number, y: number) => {
      const sx = (x - this.cam.x) * this.zoom + w / 2;
      const sy = (y - this.cam.y) * this.zoom + h / 2;
      return { sx, sy };
    };
    const marks: Array<{ x: number; y: number; color: string; label: string }> = [];
    SHRINES.forEach((s, i) => {
      if (!this.shrines[i]) marks.push({ x: s.x, y: s.y, color: "#f2d197", label: `${i + 1}` });
    });
    marks.push({ x: CAMP.x, y: CAMP.y, color: "#e79a6c", label: "" });

    for (const m of marks) {
      const { sx, sy } = toScreen(m.x, m.y);
      const margin = 34;
      if (sx > margin && sx < w - margin && sy > margin && sy < h - margin) continue;
      const cx = w / 2;
      const cy = h / 2;
      const ang = Math.atan2(sy - cy, sx - cx);
      const rx = w / 2 - margin;
      const ry = h / 2 - margin;
      const t = Math.min(Math.abs(rx / Math.cos(ang)), Math.abs(ry / Math.sin(ang)));
      const px = clamp(cx + Math.cos(ang) * t, margin, w - margin);
      const py = clamp(cy + Math.sin(ang) * t, margin, h - margin);
      const d = dist(this.player.x, this.player.y, m.x, m.y);
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(ang + Math.PI / 2);
      ctx.fillStyle = m.color;
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.moveTo(0, -9);
      ctx.lineTo(6.5, 2);
      ctx.lineTo(0, -1);
      ctx.lineTo(-6.5, 2);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      if (m.label) {
        ctx.fillStyle = "rgba(250, 243, 226, 0.88)";
        ctx.font = '600 10px "IBM Plex Sans Arabic", sans-serif';
        ctx.textAlign = "center";
        ctx.fillText(m.label, px, py + 17);
      } else {
        ctx.fillStyle = "rgba(250, 243, 226, 0.55)";
        ctx.font = '500 9px "IBM Plex Sans Arabic", sans-serif';
        ctx.textAlign = "center";
        ctx.fillText(`${Math.round(d)}م`, px, py + 17);
      }
    }
  }
}
