import * as THREE from 'three';
import { B, DEFS, HOTBAR, createAtlasCanvas } from './blocks';
import { World, W, D, H } from './world';

const SAVE_KEY = 'minicraft-save-v1';
const DAY_LENGTH = 360;

interface SaveData {
  seed: number;
  edits: [number, number][];
  pos: [number, number, number];
  yaw: number;
  pitch: number;
  slot: number;
}

export function clearSave() {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch {
    /* ignore */
  }
}

function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? (JSON.parse(raw) as SaveData) : null;
  } catch {
    return null;
  }
}

export interface EngineCallbacks {
  onSlot: (slot: number) => void;
  onFly: (flying: boolean) => void;
}

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
}

const HW = 0.3; // half width
const PH = 1.8; // player height
const EYE = 1.62;
const REACH = 6;

export class Engine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  world!: World;
  container: HTMLElement;
  cb: EngineCallbacks;

  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  input = { x: 0, y: 0, jump: false, down: false };
  keys = { f: false, b: false, l: false, r: false };
  flying = false;
  onGround = false;
  inWater = false;
  underwater = false;
  running = false;
  slot = 0;

  private breaking = false;
  private breakTimer = 0;
  private raf = 0;
  private last = 0;
  private disposed = false;
  private ready = false;
  private seed: number;
  private saved: SaveData | null;
  private time = 0.2;
  private lastJumpPress = 0;
  private saveTimer = 0;
  private dirty = false;
  private fpsAcc = 0;
  private fpsCount = 0;
  fps = 0;

  private highlight: THREE.LineSegments;
  private hitInfo: { x: number; y: number; z: number; nx: number; ny: number; nz: number } | null = null;
  private particles: Particle[] = [];
  private partGeo = new THREE.BoxGeometry(0.14, 0.14, 0.14);
  private partMats = new Map<number, THREE.MeshBasicMaterial>();

  private sky = new THREE.Color();
  private sun: THREE.Mesh;
  private moon: THREE.Mesh;
  private stars: THREE.Points;
  private tmpV = new THREE.Vector3();
  private resizeObs: ResizeObserver;
  private atlasTex: THREE.CanvasTexture;
  atlasCanvas: HTMLCanvasElement;

  constructor(container: HTMLElement, cb: EngineCallbacks) {
    this.container = container;
    this.cb = cb;
    this.saved = loadSave();
    this.seed = this.saved?.seed ?? Math.floor(Math.random() * 1_000_000);

    this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.style.display = 'block';
    container.appendChild(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.05, 700);
    this.camera.rotation.order = 'YXZ';

    this.scene.background = this.sky;
    this.scene.fog = new THREE.Fog(0x87ceeb, 30, 80);

    this.atlasCanvas = createAtlasCanvas();
    this.atlasTex = new THREE.CanvasTexture(this.atlasCanvas);
    this.atlasTex.magFilter = THREE.NearestFilter;
    this.atlasTex.minFilter = THREE.NearestFilter;
    this.atlasTex.generateMipmaps = false;
    this.atlasTex.colorSpace = THREE.SRGBColorSpace;

    // block highlight
    const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004));
    this.highlight = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x000000 }));
    this.highlight.visible = false;
    this.scene.add(this.highlight);

    // sun / moon
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xfff1a8, fog: false, depthWrite: false });
    this.sun = new THREE.Mesh(new THREE.PlaneGeometry(50, 50), sunMat);
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xdfe6f5, fog: false, depthWrite: false });
    this.moon = new THREE.Mesh(new THREE.PlaneGeometry(36, 36), moonMat);
    this.scene.add(this.sun, this.moon);

    // stars
    const sp = new Float32Array(300 * 3);
    for (let i = 0; i < 300; i++) {
      const u = Math.random() * 2 - 1;
      const t = Math.random() * Math.PI * 2;
      const r = Math.sqrt(1 - u * u);
      sp[i * 3] = r * Math.cos(t) * 450;
      sp[i * 3 + 1] = u * 450;
      sp[i * 3 + 2] = r * Math.sin(t) * 450;
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
    this.stars = new THREE.Points(
      sg,
      new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, fog: false, depthWrite: false }),
    );
    this.stars.frustumCulled = false;
    this.scene.add(this.stars);

    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(container);
    this.resize();

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('pagehide', this.save);
    this.renderer.domElement.addEventListener('wheel', this.onWheel, { passive: true });
  }

  async init(onProgress: (p: number) => void) {
    this.world = new World(this.seed, this.atlasTex);
    this.world.generate();
    if (this.saved?.edits) this.world.applyEdits(this.saved.edits);
    this.scene.add(this.world.group);
    await this.world.buildAll(onProgress, () => this.disposed);
    if (this.disposed) return;

    if (this.saved?.pos) {
      this.pos.set(...this.saved.pos);
      this.yaw = this.saved.yaw ?? 0;
      this.pitch = this.saved.pitch ?? 0;
      this.slot = Math.max(0, Math.min(HOTBAR.length - 1, this.saved.slot ?? 0));
      if (this.collidesAt(this.pos.x, this.pos.y, this.pos.z)) {
        const s = this.world.findSpawn();
        this.pos.set(...s);
      }
    } else {
      const s = this.world.findSpawn();
      this.pos.set(...s);
      this.yaw = Math.PI * 0.25;
    }
    this.ready = true;
    this.cb.onSlot(this.slot);
    this.syncCamera();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  // ---------- input ----------
  look(dx: number, dy: number) {
    this.yaw -= dx * 0.0048;
    this.pitch -= dy * 0.0048;
    this.pitch = Math.max(-1.55, Math.min(1.55, this.pitch));
  }

  setSlot(i: number) {
    const n = HOTBAR.length;
    this.slot = ((i % n) + n) % n;
    this.cb.onSlot(this.slot);
  }

  pressJump() {
    const now = performance.now();
    if (now - this.lastJumpPress < 300) this.toggleFly();
    this.lastJumpPress = now;
  }

  toggleFly() {
    this.flying = !this.flying;
    if (this.flying) this.vel.y = 0;
    this.cb.onFly(this.flying);
  }

  setBreaking(v: boolean) {
    this.breaking = v;
    if (v) this.breakTimer = 0;
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (!this.running) return;
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.keys.f = true;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.keys.b = true;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.keys.l = true;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.keys.r = true;
        break;
      case 'Space':
        if (!e.repeat) this.pressJump();
        this.input.jump = true;
        e.preventDefault();
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.input.down = true;
        break;
      case 'KeyF':
        this.toggleFly();
        break;
      default:
        if (/^Digit[0-9]$/.test(e.code)) {
          const n = Number(e.code.slice(5));
          this.setSlot(n === 0 ? 9 : n - 1);
        }
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.keys.f = false;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.keys.b = false;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.keys.l = false;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.keys.r = false;
        break;
      case 'Space':
        this.input.jump = false;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.input.down = false;
        break;
    }
  };

  private onWheel = (e: WheelEvent) => {
    if (!this.running) return;
    this.setSlot(this.slot + (e.deltaY > 0 ? 1 : -1));
  };

  // ---------- world interaction ----------
  private raycast() {
    const o = this.camera.position;
    const d = this.camera.getWorldDirection(this.tmpV);
    let x = Math.floor(o.x);
    let y = Math.floor(o.y);
    let z = Math.floor(o.z);
    const sx = d.x > 0 ? 1 : -1;
    const sy = d.y > 0 ? 1 : -1;
    const sz = d.z > 0 ? 1 : -1;
    const tdx = d.x === 0 ? Infinity : Math.abs(1 / d.x);
    const tdy = d.y === 0 ? Infinity : Math.abs(1 / d.y);
    const tdz = d.z === 0 ? Infinity : Math.abs(1 / d.z);
    let tx = d.x === 0 ? Infinity : (d.x > 0 ? x + 1 - o.x : o.x - x) * tdx;
    let ty = d.y === 0 ? Infinity : (d.y > 0 ? y + 1 - o.y : o.y - y) * tdy;
    let tz = d.z === 0 ? Infinity : (d.z > 0 ? z + 1 - o.z : o.z - z) * tdz;
    let nx = 0;
    let ny = 0;
    let nz = 0;
    let t = 0;
    for (let i = 0; i < 40; i++) {
      const id = this.world.peek(x, y, z);
      if (id !== B.AIR && id !== B.WATER) return { x, y, z, nx, ny, nz };
      if (tx < ty && tx < tz) {
        t = tx;
        x += sx;
        tx += tdx;
        nx = -sx;
        ny = 0;
        nz = 0;
      } else if (ty < tz) {
        t = ty;
        y += sy;
        ty += tdy;
        nx = 0;
        ny = -sy;
        nz = 0;
      } else {
        t = tz;
        z += sz;
        tz += tdz;
        nx = 0;
        ny = 0;
        nz = -sz;
      }
      if (t > REACH) break;
    }
    return null;
  }

  breakBlock() {
    const h = this.hitInfo;
    if (!h) return;
    if (h.y === 0) return; // bedrock layer
    const id = this.world.peek(h.x, h.y, h.z);
    if (id === B.AIR) return;
    this.world.setBlock(h.x, h.y, h.z, B.AIR);
    this.spawnParticles(h.x, h.y, h.z, id);
    this.markDirty();
    if (navigator.vibrate) navigator.vibrate(8);
  }

  placeBlock() {
    const h = this.hitInfo;
    if (!h) return;
    const x = h.x + h.nx;
    const y = h.y + h.ny;
    const z = h.z + h.nz;
    if (!this.world.inBounds(x, y, z)) return;
    const cur = this.world.peek(x, y, z);
    if (cur !== B.AIR && cur !== B.WATER) return;
    const id = HOTBAR[this.slot];
    if (DEFS[id].solid) {
      const p = this.pos;
      if (
        x + 1 > p.x - HW &&
        x < p.x + HW &&
        y + 1 > p.y &&
        y < p.y + PH &&
        z + 1 > p.z - HW &&
        z < p.z + HW
      )
        return;
    }
    this.world.setBlock(x, y, z, id);
    this.markDirty();
    if (navigator.vibrate) navigator.vibrate(5);
  }

  private spawnParticles(x: number, y: number, z: number, id: number) {
    let mat = this.partMats.get(id);
    if (!mat) {
      mat = new THREE.MeshBasicMaterial({ color: DEFS[id].color });
      this.partMats.set(id, mat);
    }
    for (let i = 0; i < 10; i++) {
      const m = new THREE.Mesh(this.partGeo, mat);
      m.position.set(x + Math.random(), y + Math.random(), z + Math.random());
      this.scene.add(m);
      this.particles.push({
        mesh: m,
        vel: new THREE.Vector3((Math.random() - 0.5) * 4, Math.random() * 4 + 1, (Math.random() - 0.5) * 4),
        life: 0.6 + Math.random() * 0.3,
      });
    }
  }

  private markDirty() {
    this.dirty = true;
    this.saveTimer = 1.5;
  }

  // ---------- physics ----------
  private collidesAt(x: number, y: number, z: number) {
    const x0 = Math.floor(x - HW);
    const x1 = Math.floor(x + HW);
    const y0 = Math.floor(y);
    const y1 = Math.floor(y + PH - 0.001);
    const z0 = Math.floor(z - HW);
    const z1 = Math.floor(z + HW);
    for (let yy = y0; yy <= y1; yy++)
      for (let zz = z0; zz <= z1; zz++)
        for (let xx = x0; xx <= x1; xx++) if (this.world.solid(xx, yy, zz)) return true;
    return false;
  }

  private stepAxis(axis: 0 | 1 | 2, d: number): boolean {
    if (d === 0) return false;
    const n = Math.ceil(Math.abs(d) / 0.05);
    const s = d / n;
    for (let i = 0; i < n; i++) {
      const old = this.pos.getComponent(axis);
      this.pos.setComponent(axis, old + s);
      if (this.collidesAt(this.pos.x, this.pos.y, this.pos.z)) {
        this.pos.setComponent(axis, old);
        this.vel.setComponent(axis, 0);
        return true;
      }
    }
    return false;
  }

  private physics(dt: number) {
    const inp = this.input;
    let ix = inp.x + (this.keys.r ? 1 : 0) - (this.keys.l ? 1 : 0);
    let iy = inp.y + (this.keys.f ? 1 : 0) - (this.keys.b ? 1 : 0);
    const len = Math.hypot(ix, iy);
    if (len > 1) {
      ix /= len;
      iy /= len;
    }
    const sin = Math.sin(this.yaw);
    const cos = Math.cos(this.yaw);
    const wx = cos * ix - sin * iy;
    const wz = -sin * ix - cos * iy;

    this.inWater = this.world.peek(Math.floor(this.pos.x), Math.floor(this.pos.y + 0.4), Math.floor(this.pos.z)) === B.WATER;

    let speed = this.flying ? 10 : 4.8;
    if (this.inWater && !this.flying) speed *= 0.55;
    const k = Math.min(1, (this.onGround || this.flying ? 14 : 5) * dt);
    this.vel.x += (wx * speed - this.vel.x) * k;
    this.vel.z += (wz * speed - this.vel.z) * k;

    if (this.flying) {
      const target = ((inp.jump ? 1 : 0) - (inp.down ? 1 : 0)) * 8;
      this.vel.y += (target - this.vel.y) * Math.min(1, 10 * dt);
    } else if (this.inWater) {
      this.vel.y -= 10 * dt;
      if (inp.jump) this.vel.y = Math.min(this.vel.y + 34 * dt, 3.6);
      this.vel.y = Math.max(this.vel.y, -3);
    } else {
      this.vel.y -= 28 * dt;
      this.vel.y = Math.max(this.vel.y, -50);
      if (inp.jump && this.onGround) this.vel.y = 8.6;
    }

    const wasGround = this.onGround;
    const bx = this.stepAxis(0, this.vel.x * dt);
    const bz = this.stepAxis(2, this.vel.z * dt);
    this.onGround = false;
    const dy = this.vel.y * dt;
    if (this.stepAxis(1, dy) && dy < 0) this.onGround = true;

    // auto-jump over single blocks (mobile friendly)
    if ((bx || bz) && wasGround && !this.flying && len > 0.15) {
      const m = Math.hypot(wx, wz) || 1;
      if (!this.collidesAt(this.pos.x + (wx / m) * 0.35, this.pos.y + 1.02, this.pos.z + (wz / m) * 0.35)) {
        this.vel.y = 8.3;
        this.onGround = false;
      }
    }
    // swim up out of water at shore
    if (this.inWater && (bx || bz) && inp.jump) {
      const m = Math.hypot(wx, wz) || 1;
      if (!this.collidesAt(this.pos.x + (wx / m) * 0.35, this.pos.y + 1.02, this.pos.z + (wz / m) * 0.35)) this.vel.y = 7;
    }

    if (this.flying && this.onGround) {
      this.flying = false;
      this.cb.onFly(false);
    }
  }

  private syncCamera() {
    this.camera.position.set(this.pos.x, this.pos.y + EYE, this.pos.z);
    this.camera.rotation.set(this.pitch, this.yaw, 0);
  }

  private update(dt: number) {
    this.physics(dt);
    this.syncCamera();
    this.underwater = this.world.peek(Math.floor(this.camera.position.x), Math.floor(this.camera.position.y), Math.floor(this.camera.position.z)) === B.WATER;

    // targeting
    this.hitInfo = this.raycast();
    if (this.hitInfo) {
      this.highlight.visible = true;
      this.highlight.position.set(this.hitInfo.x + 0.5, this.hitInfo.y + 0.5, this.hitInfo.z + 0.5);
    } else {
      this.highlight.visible = false;
    }

    if (this.breaking) {
      this.breakTimer -= dt;
      if (this.breakTimer <= 0) {
        this.breakBlock();
        this.breakTimer = 0.26;
      }
    }

    // particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      p.vel.y -= 18 * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      p.mesh.scale.setScalar(Math.max(0.1, p.life * 1.6));
    }

    if (this.saveTimer > 0) {
      this.saveTimer -= dt;
      if (this.saveTimer <= 0 && this.dirty) this.save();
    }
  }

  private updateSky(dt: number) {
    if (this.running) this.time += dt / DAY_LENGTH;
    const ang = this.time * Math.PI * 2;
    const sunH = Math.sin(ang);
    const t = Math.max(0, Math.min(1, (sunH + 0.15) / 0.4));
    const daylight = t * t * (3 - 2 * t);
    const light = 0.3 + 0.7 * daylight;
    this.world.setLight(light);

    const day = new THREE.Color(0x7ec0ee);
    const night = new THREE.Color(0x070b1c);
    this.sky.copy(night).lerp(day, daylight);
    const dusk = Math.max(0, 1 - Math.abs(sunH) / 0.2);
    if (dusk > 0) this.sky.lerp(new THREE.Color(0xe8895a), dusk * 0.45);

    const fog = this.scene.fog as THREE.Fog;
    if (this.underwater) {
      this.sky.set(0x1b3f94).multiplyScalar(light);
      fog.near = 0.5;
      fog.far = 18;
    } else {
      fog.near = 28;
      fog.far = 78;
    }
    fog.color.copy(this.sky);

    const cp = this.camera.position;
    this.sun.position.set(cp.x + Math.cos(ang) * 320, cp.y + sunH * 320, cp.z + 60);
    this.sun.lookAt(cp);
    this.moon.position.set(cp.x - Math.cos(ang) * 320, cp.y - sunH * 320, cp.z - 60);
    this.moon.lookAt(cp);
    this.sun.visible = !this.underwater;
    this.moon.visible = !this.underwater;
    const starMat = this.stars.material as THREE.PointsMaterial;
    starMat.opacity = this.underwater ? 0 : Math.max(0, 1 - daylight * 1.6);
    this.stars.position.copy(cp);
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;

    if (this.running) this.update(dt);
    else {
      // slow cinematic rotation on title / pause screens
      this.yaw += dt * 0.07;
      this.syncCamera();
    }
    this.updateSky(dt);
    this.renderer.render(this.scene, this.camera);

    this.fpsAcc += dt;
    this.fpsCount++;
    if (this.fpsAcc >= 0.5) {
      this.fps = Math.round(this.fpsCount / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsCount = 0;
    }
  };

  private resize() {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    // wider vertical FOV for portrait screens
    this.camera.fov = w / h < 1 ? 85 : 72;
    this.camera.updateProjectionMatrix();
  }

  getInfo() {
    return {
      fps: this.fps,
      x: this.pos.x,
      y: this.pos.y,
      z: this.pos.z,
      time: this.time,
    };
  }

  save = () => {
    if (!this.world || !this.ready) return;
    try {
      const data: SaveData = {
        seed: this.seed,
        edits: [...this.world.edits],
        pos: [this.pos.x, this.pos.y, this.pos.z],
        yaw: this.yaw,
        pitch: this.pitch,
        slot: this.slot,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      this.dirty = false;
    } catch {
      /* storage may be full/unavailable */
    }
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.save();
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('pagehide', this.save);
    this.resizeObs.disconnect();
    this.world?.dispose();
    this.atlasTex.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}

export const WORLD_INFO = { W, D, H };
