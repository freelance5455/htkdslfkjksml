export type Hud = {
  level: number;
  score: number;
  goal: number;
  time: number;
  served: number;
  coins: number;
  starsTotal: number;
  bestStage: number;
};

export type EndInfo = {
  stars: number;
  score: number;
  gain: number;
  coins: number;
  cleared: boolean;
  last: boolean;
  line: string;
};

export type Save = {
  coins: number;
  owned: string[];
  names: [string, string];
  stars: number[];
  sound: boolean;
};

export type MountOpts = {
  onHud: (h: Hud) => void;
  onToast: (t: string) => void;
  onEnd: (e: EndInfo) => void;
  onReady: () => void;
  onPauseToggle: () => void;
};

export type GameApi = {
  destroy: () => void;
  setStick: (id: 0 | 1, x: number, y: number) => void;
  act: (id: 0 | 1) => void;
  toss: (id: 0 | 1) => void;
  deliver: (id: 0 | 1) => void;
  startLevel: (i: number) => void;
  setPaused: (p: boolean) => void;
  setNames: (a: string, b: string) => void;
  setSound: (on: boolean) => void;
  buy: (id: string) => boolean;
  getSave: () => Save;
};

type FoodState = "raw" | "cooked" | "cut" | "ready" | "burnt";
type Item =
  | { plate: true; contents: string[] }
  | { plate: false; k: string; s: FoodState };

type Slot = { item: Item | null; pr: number; bn: number };

type Station = {
  id: string;
  type: "crate" | "board" | "stove" | "plate" | "trash" | "serve";
  kind?: string;
  x: number;
  y: number;
  w: number;
  h: number;
  unlock: number;
  a: Slot;
  b: Slot;
};

type Player = {
  id: 0 | 1;
  x: number;
  y: number;
  vx: number;
  vy: number;
  dx: number;
  dy: number;
  row: number;
  walk: number;
  item: Item | null;
  cool: number;
  r: number;
};

type Order = {
  name: string;
  parts: string[];
  price: number;
  t: number;
  max: number;
};

type Ent = {
  item: Item;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  air: boolean;
  grab: number;
  life: number;
};

type Puff = { x: number; y: number; vx: number; vy: number; life: number; c: string };

const WORLD_W = 1280;
const WORLD_H = 720;
const KEY = "foodchaos-v1";
const G = 900;

const RECIPES: { name: string; parts: string[]; price: number; unlock: number }[] = [
  { name: "روبيان", parts: ["shrimp_cooked"], price: 24, unlock: 1 },
  { name: "برغر", parts: ["salmon_cooked", "bun_cooked"], price: 34, unlock: 2 },
  { name: "مقلية", parts: ["potato_cooked"], price: 18, unlock: 3 },
  { name: "سلطة", parts: ["cabbage_cut", "tomato_cut"], price: 28, unlock: 4 },
  { name: "برغر جبن", parts: ["salmon_cooked", "bun_cooked", "cheese_ready"], price: 46, unlock: 5 },
  { name: "مشروب", parts: ["cola_ready"], price: 14, unlock: 6 },
  { name: "روبيان وبطاطا", parts: ["shrimp_cooked", "potato_cooked"], price: 42, unlock: 7 },
  { name: "وجبة برغر", parts: ["salmon_cooked", "bun_cooked", "potato_cooked"], price: 56, unlock: 8 },
  { name: "سلطة ومشروب", parts: ["cabbage_cut", "tomato_cut", "cola_ready"], price: 44, unlock: 10 },
  { name: "برغر كامل", parts: ["salmon_cooked", "bun_cooked", "cabbage_cut", "tomato_cut"], price: 64, unlock: 12 },
  { name: "طبق الشيف", parts: ["salmon_cooked", "bun_cooked", "shrimp_cooked", "cheese_ready", "potato_cooked"], price: 92, unlock: 16 },
  { name: "وليمة", parts: ["salmon_cooked", "bun_cooked", "cabbage_cut", "tomato_cut", "potato_cooked", "cola_ready"], price: 120, unlock: 22 },
];

const EXTRAS: [string, number, number][] = [
  ["ketchup_ready", 5, 5],
  ["cheese_ready", 8, 5],
  ["tomato_cut", 6, 4],
  ["cabbage_cut", 6, 4],
];

const HINTS: Record<number, string> = {
  1: "الروبيان يسار الأسفل. مرّره للموقد، ضعه في طبق، ثم سلّمه عند البطاقات.",
  2: "السلمون والخبز على اليمين. اقلِهما واجمع البرغر في طبق.",
  3: "كيس البطاطا بجانب الممر. اقله حتى يصير مقلية.",
  4: "قطّع الملفوف والطماطم على لوح التقطيع بضغطات متتابعة.",
  5: "الجبن جاهز. أضفه فوق البرغر من صينية الجبن.",
  6: "المشروب من الخلاط الأزرق في جهة الجزرة.",
};

const BLOCKS: [number, number, number, number][] = [
  [0.0, 0.05, 0.44, 0.16],
  [0.56, 0.05, 0.44, 0.16],
  [0.0, 0.2, 0.13, 0.36],
  [0.2, 0.3, 0.21, 0.26],
  [0.27, 0.56, 0.12, 0.09],
  [0.0, 0.6, 0.09, 0.12],
  [0.0, 0.785, 0.445, 0.215],
  [0.855, 0.2, 0.145, 0.42],
  [0.58, 0.31, 0.25, 0.27],
  [0.875, 0.62, 0.11, 0.12],
  [0.55, 0.785, 0.45, 0.215],
];

const FOOD_INDEX: Record<string, number> = {
  salmon_raw: 0,
  salmon_cooked: 1,
  burnt: 2,
  bun_raw: 3,
  bun_cooked: 4,
  cabbage_raw: 5,
  cabbage_cut: 6,
  tomato_raw: 7,
  tomato_cut: 8,
  potato_raw: 9,
  potato_cooked: 10,
  shrimp_raw: 11,
  shrimp_cooked: 12,
  cheese_ready: 13,
  ketchup_ready: 14,
  cola_ready: 15,
};

const READY = new Set(["cheese", "ketchup", "cola"]);
const CHOP = new Set(["cabbage", "tomato"]);
const COOK = new Set(["salmon", "bun", "shrimp", "potato"]);

function emptySlot(): Slot {
  return { item: null, pr: 0, bn: 0 };
}

function station(
  id: string,
  type: Station["type"],
  x: number,
  y: number,
  w: number,
  h: number,
  unlock = 1,
  kind?: string,
): Station {
  return {
    id,
    type,
    kind,
    x: x * WORLD_W,
    y: y * WORLD_H,
    w: w * WORLD_W,
    h: h * WORLD_H,
    unlock,
    a: emptySlot(),
    b: emptySlot(),
  };
}

function buildStations(): Station[] {
  return [
    station("boardL", "board", 0.2, 0.32, 0.12, 0.16),
    station("ketchup", "crate", 0.33, 0.31, 0.09, 0.13, 5, "ketchup"),
    station("plateL", "plate", 0.0, 0.42, 0.12, 0.13),
    station("trashL", "trash", 0.0, 0.6, 0.1, 0.12),
    station("potato", "crate", 0.26, 0.55, 0.13, 0.11, 3, "potato"),
    station("shrimp", "crate", 0.02, 0.8, 0.13, 0.16, 1, "shrimp"),
    station("tomato", "crate", 0.17, 0.8, 0.13, 0.16, 4, "tomato"),
    station("cabbage", "crate", 0.31, 0.8, 0.13, 0.16, 4, "cabbage"),
    station("stove", "stove", 0.57, 0.06, 0.13, 0.14),
    station("boardTop", "board", 0.72, 0.06, 0.1, 0.14),
    station("plateR", "plate", 0.86, 0.23, 0.13, 0.12),
    station("boardR", "board", 0.86, 0.37, 0.13, 0.14),
    station("cola", "crate", 0.6, 0.34, 0.13, 0.15, 6, "cola"),
    station("trashR", "trash", 0.87, 0.62, 0.12, 0.12),
    station("bun", "crate", 0.56, 0.8, 0.13, 0.16, 2, "bun"),
    station("cheese", "crate", 0.71, 0.8, 0.12, 0.16, 5, "cheese"),
    station("salmon", "crate", 0.84, 0.8, 0.15, 0.16, 2, "salmon"),
    station("serve", "serve", 0.455, 0.26, 0.09, 0.46),
  ];
}

function blocksPx() {
  return BLOCKS.map(([x, y, w, h]) => ({
    x: x * WORLD_W,
    y: y * WORLD_H,
    w: w * WORLD_W,
    h: h * WORLD_H,
  }));
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(src));
    img.src = src;
  });
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function hypot(x: number, y: number) {
  return Math.hypot(x, y);
}

function defaultSave(): Save {
  return { coins: 0, owned: [], names: ["موزة", "جزرة"], stars: Array(40).fill(0), sound: true };
}

function readSave(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    const p = JSON.parse(raw) as Partial<Save>;
    const base = defaultSave();
    return {
      coins: p.coins || 0,
      owned: Array.isArray(p.owned) ? p.owned : [],
      names: [p.names?.[0] || base.names[0], p.names?.[1] || base.names[1]],
      stars: Array.from({ length: 40 }, (_, i) => Number(p.stars?.[i]) || 0),
      sound: p.sound !== false,
    };
  } catch {
    return defaultSave();
  }
}

export function mountKitchen(canvas: HTMLCanvasElement, opts: MountOpts): GameApi {
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("canvas");

  const save = readSave();
  const keys = new Set<string>();
  let injected: string[] | null = null;
  let dead = false;
  let paused = true;
  let live = false;
  let count = 0;
  let li = 0;
  let score = 0;
  let served = 0;
  let timeLeft = 90;
  let timerAcc = 0;
  let earn = 0;
  let nextOrd = 1.2;
  let last = 0;
  let acc = 0;
  const stick: [number, number][] = [
    [0, 0],
    [0, 0],
  ];
  let stations = buildStations();
  const solids = blocksPx();
  const players: Player[] = [
    { id: 0, x: 390, y: 520, vx: 0, vy: 0, dx: 0, dy: 0, row: 0, walk: 0, item: null, cool: 0, r: 18 },
    { id: 1, x: 900, y: 520, vx: 0, vy: 0, dx: 0, dy: 0, row: 2, walk: 0, item: null, cool: 0, r: 18 },
  ];
  let orders: Order[] = [];
  let ents: Ent[] = [];
  let puffs: Puff[] = [];
  let kitchen: HTMLImageElement | null = null;
  let plateImg: HTMLImageElement | null = null;
  const banana: HTMLImageElement[] = [];
  const carrot: HTMLImageElement[] = [];
  const foods: HTMLImageElement[] = [];
  let audio: AudioContext | null = null;
  const debug = typeof location !== "undefined" && location.hash === "#debug";
  const qa = typeof location !== "undefined" && new URLSearchParams(location.search).has("qa");

  function persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(save));
    } catch {
      /* ignore quota */
    }
  }

  function owned(id: string) {
    return save.owned.includes(id);
  }

  function beep(f = 620, d = 0.12, type: OscillatorType = "triangle", v = 0.05) {
    if (!save.sound) return;
    try {
      audio = audio || new AudioContext();
      if (audio.state === "suspended") void audio.resume();
      const o = audio.createOscillator();
      const g = audio.createGain();
      const t = audio.currentTime;
      o.type = type;
      o.frequency.value = f;
      g.gain.setValueAtTime(v, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.connect(g);
      g.connect(audio.destination);
      o.start();
      o.stop(t + d);
    } catch {
      /* autoplay */
    }
  }

  function toast(t: string) {
    opts.onToast(t);
    if (/جاهز|ناجح|اكتمل/.test(t)) beep(880, 0.14, "triangle");
    else if (/احترق|لا يطابق|فات|مقفل/.test(t)) beep(160, 0.18, "sawtooth");
    else if (/تقطيع/.test(t)) beep(340, 0.05, "square", 0.03);
  }

  function puff(x: number, y: number, c: string, n = 6) {
    for (let i = 0; i < n; i++) {
      puffs.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 90,
        vy: -30 - Math.random() * 80,
        life: 0.35 + Math.random() * 0.35,
        c,
      });
    }
  }

  function levelOf(n: number) {
    const openIng = new Set<string>();
    if (n >= 1) openIng.add("shrimp");
    if (n >= 2) openIng.add("salmon").add("bun");
    if (n >= 3) openIng.add("potato");
    if (n >= 4) openIng.add("cabbage").add("tomato");
    if (n >= 5) openIng.add("cheese").add("ketchup");
    if (n >= 6) openIng.add("cola");
    const recipes = RECIPES.filter(
      (r) => r.unlock <= n && r.parts.every((p) => openIng.has(p.split("_")[0] || "")),
    );
    return {
      n,
      recipes,
      t: 100 + Math.min(50, Math.round(n * 1.6)),
      conc: 1 + (n >= 4 ? 1 : 0) + (n >= 12 ? 1 : 0) + (n >= 26 ? 1 : 0),
      ot: Math.max(34, 92 - Math.round(n * 1.35)),
      gap: Math.max(8, 22 - n * 0.32),
      goals: [28 + n * 7, 52 + n * 11, 82 + n * 15] as [number, number, number],
    };
  }

  function hud(): Hud {
    const L = levelOf(li + 1);
    const starsTotal = save.stars.reduce((a, b) => a + b, 0);
    const locked = save.stars.findIndex((s) => !s);
    return {
      level: L.n,
      score,
      goal: L.goals[0],
      time: Math.max(0, Math.ceil(timeLeft)),
      served,
      coins: save.coins,
      starsTotal,
      bestStage: locked < 0 ? 40 : locked + 1,
    };
  }

  function pushHud() {
    opts.onHud(hud());
  }

  function foodFrame(k: string, s: FoodState) {
    if (s === "burnt") return 2;
    const idx = FOOD_INDEX[`${k}_${s}`];
    return idx ?? 0;
  }

  function drawFood(k: string, s: FoodState, x: number, y: number, size: number) {
    const img = foods[foodFrame(k, s)];
    if (!img) return;
    ctx.drawImage(img, x - size / 2, y - size / 2, size, size);
  }

  function drawPlate(x: number, y: number, contents: string[], size: number) {
    if (plateImg) ctx.drawImage(plateImg, x - size / 2, y - size * 0.42, size, size * 0.78);
    contents.forEach((part, i) => {
      const [k, s] = part.split("_");
      if (!k || !s) return;
      const n = contents.length;
      const ang = (i / n) * Math.PI * 2 - Math.PI / 2;
      const rad = n > 1 ? size * (n > 3 ? 0.2 : 0.16) : 0;
      drawFood(k, s as FoodState, x + Math.cos(ang) * rad, y + Math.sin(ang) * rad * 0.55, size * (n > 4 ? 0.28 : 0.36));
    });
  }

  function drawItem(it: Item, x: number, y: number, size: number) {
    if (it.plate) drawPlate(x, y, it.contents, size);
    else drawFood(it.k, it.s, x, y, size);
  }

  function nearest(p: Player) {
    let best: Station | null = null;
    let bd = p.r + 36;
    for (const s of stations) {
      const dx = Math.max(s.x - p.x, 0, p.x - (s.x + s.w));
      const dy = Math.max(s.y - p.y, 0, p.y - (s.y + s.h));
      const d = hypot(dx, dy);
      if (d < bd) {
        bd = d;
        best = s;
      }
    }
    return best;
  }

  function fresh(kind: string): Item {
    return { plate: false, k: kind, s: READY.has(kind) ? "ready" : "raw" };
  }

  function usable(it: Item) {
    if (it.plate) return false;
    if (it.s === "burnt" || it.s === "raw") return false;
    if (it.k === "cabbage" || it.k === "tomato") return it.s === "cut";
    if (COOK.has(it.k)) return it.s === "cooked";
    return it.s === "ready";
  }

  function clearSlot(slot: Slot) {
    slot.item = null;
    slot.pr = 0;
    slot.bn = 0;
  }

  function drop(p: Player) {
    if (!p.item) return;
    ents.push({
      item: p.item,
      x: p.x + (p.row === 1 ? -16 : p.row === 2 ? 16 : 0),
      y: p.y + 8,
      z: 0,
      vx: (p.row === 1 ? -1 : p.row === 2 ? 1 : 0) * 40,
      vy: 30,
      vz: 0,
      air: false,
      grab: 0,
      life: 28,
    });
    p.item = null;
  }

  function act(id: 0 | 1) {
    if (!live || paused) return;
    const p = players[id];
    if (!p || p.cool > 0) return;
    p.cool = 0.16;
    const held = p.item;
    const s = nearest(p);
    if (!s) {
      if (!held) {
        let bi = -1;
        let bd = 42;
        ents.forEach((e, i) => {
          if (e.air || e.z > 8) return;
          const d = hypot(p.x - e.x, p.y - e.y);
          if (d < bd) {
            bd = d;
            bi = i;
          }
        });
        if (bi >= 0) {
          const ent = ents[bi];
          if (ent) {
            p.item = ent.item;
            ents.splice(bi, 1);
            toast("التقطت الغرض");
          }
        } else toast("اقترب من محطة");
      } else {
        drop(p);
        toast("وضعت الغرض");
      }
      return;
    }
    if (s.unlock > li + 1 && s.type === "crate") {
      toast("هذا المكوّن مقفل حتى مرحلة لاحقة");
      return;
    }
    const cx = s.x + s.w / 2;
    const cy = s.y + s.h / 2;
    if (s.type === "crate" && s.kind) {
      if (held) return toast("يداك مشغولتان");
      p.item = fresh(s.kind);
      puff(cx, cy, "#fff6e4", 4);
      return;
    }
    if (s.type === "trash") {
      if (!held) return toast("سلة النفايات");
      p.item = null;
      toast("رميت الغرض");
      return;
    }
    if (s.type === "serve") {
      deliver(id);
      return;
    }
    if (s.type === "board") {
      if (held) {
        if (held.plate || held.s !== "raw" || !CHOP.has(held.k)) return toast("هذا لا يُقطَّع");
        if (s.a.item) return toast("اللوح مشغول");
        s.a.item = held;
        s.a.pr = 0;
        p.item = null;
        return toast("اضغط يد للتقطيع");
      }
      const it = s.a.item;
      if (!it || it.plate) return toast("لوح التقطيع فارغ");
      if (it.s === "cut") {
        p.item = it;
        clearSlot(s.a);
        return toast("أخذت المقطّع");
      }
      const need = owned("knife") ? 2 : 3;
      s.a.pr += 1;
      puff(cx, cy, "#e7f6c8", 3);
      if (s.a.pr >= need) {
        it.s = "cut";
        toast("اكتمل التقطيع");
      } else toast(`تقطيع ${s.a.pr}/${need}`);
      return;
    }
    if (s.type === "stove") {
      const slots = owned("stove2") ? [s.a, s.b] : [s.a];
      if (held) {
        if (held.plate || !COOK.has(held.k) || held.s !== "raw") return toast("هذا لا يُطهى");
        const free = slots.find((sl) => !sl.item);
        if (!free) return toast("الموقد مشغول");
        free.item = held;
        free.pr = 0;
        free.bn = 0;
        p.item = null;
        return toast("بدأ الطبخ");
      }
      const ready = slots.find((sl) => sl.item && !sl.item.plate && sl.item.s !== "raw");
      if (ready?.item) {
        p.item = ready.item;
        clearSlot(ready);
        return toast("أخرجت الطعام");
      }
      if (slots.some((sl) => sl.item)) return toast("ما زال يُطبخ");
      return toast("الموقد فارغ");
    }
    if (s.type === "plate") {
      if (held?.plate) {
        if (s.a.item) return toast("هنا طبق بالفعل");
        s.a.item = held;
        p.item = null;
        return;
      }
      if (held && !held.plate) {
        if (!usable(held)) return toast("حضّر المكوّن أولاً");
        const plate = s.a.item;
        if (!plate || !plate.plate) return toast("خذ طبقاً أولاً واليد فارغة");
        if (plate.contents.length >= 6) return toast("الطبق ممتلئ");
        plate.contents.push(`${held.k}_${held.s}`);
        p.item = null;
        puff(cx, cy, "#fff", 4);
        return;
      }
      if (s.a.item) {
        p.item = s.a.item;
        clearSlot(s.a);
        return toast("أخذت الطبق");
      }
      s.a.item = { plate: true, contents: [] };
      return toast("طبق جاهز. أضف المكونات");
    }
  }

  function deliver(id: 0 | 1) {
    if (!live || paused) return;
    const p = players[id];
    if (!p) return;
    const serve = stations.find((s) => s.type === "serve");
    if (!serve) return;
    const dx = Math.max(serve.x - p.x, 0, p.x - (serve.x + serve.w));
    const dy = Math.max(serve.y - p.y, 0, p.y - (serve.y + serve.h));
    if (hypot(dx, dy) > 70) return toast("اقترب من بطاقات الطلب");
    const held = p.item;
    if (!held?.plate) return toast("أحضر طبقاً جاهزاً");
    const got = [...held.contents].sort().join("|");
    const idx = orders.findIndex((o) => [...o.parts].sort().join("|") === got);
    if (idx < 0) return toast("الطبق لا يطابق أي طلب");
    const order = orders[idx];
    if (!order) return;
    orders.splice(idx, 1);
    const pts = order.price + Math.ceil((order.t / order.max) * 16);
    score += pts;
    served += 1;
    earn += Math.max(1, Math.floor(order.price / 10));
    p.item = null;
    puff(serve.x + serve.w / 2, serve.y + 40, "#f0b429", 14);
    toast(`طلب ناجح +${pts}`);
    pushHud();
  }

  function toss(id: 0 | 1) {
    if (!live || paused) return;
    const p = players[id];
    const other = players[1 - id];
    if (!p || !other) return;
    if (!p.item) return toast("لا تحمل شيئاً لتمريره");
    const ax = other.x - p.x;
    const ay = other.y - p.y;
    const dist = hypot(ax, ay) || 1;
    const tt = clamp(dist / 620, 0.42, 0.85);
    ents.push({
      item: p.item,
      x: p.x,
      y: p.y - 6,
      z: 28,
      vx: ax / tt,
      vy: ay / tt,
      vz: (G * tt) / 2 - 28 / tt,
      air: true,
      grab: 0.25,
      life: 12,
    });
    p.item = null;
    beep(300, 0.08, "triangle");
  }

  function addOrder() {
    const L = levelOf(li + 1);
    const pool = L.recipes;
    if (!pool.length) return;
    const rec = pool[Math.floor(Math.random() * pool.length)];
    if (!rec) return;
    const parts = [...rec.parts];
    let price = rec.price;
    if (parts.length < 6 && Math.random() < 0.34) {
      const extra = EXTRAS.find(
        ([k, , un]) =>
          un <= li + 1 && !parts.includes(k) && (li + 1 >= un),
      );
      if (extra && Math.random() < 0.7) {
        parts.push(extra[0]);
        price += extra[1];
      }
    }
    orders.push({ name: rec.name, parts, price, t: L.ot, max: L.ot });
  }

  function pushCircle(x: number, y: number, r: number) {
    let px = x;
    let py = y;
    for (let n = 0; n < 3; n++) {
      for (const b of solids) {
        const cx = clamp(px, b.x, b.x + b.w);
        const cy = clamp(py, b.y, b.y + b.h);
        let dx = px - cx;
        let dy = py - cy;
        let d = hypot(dx, dy);
        if (d < r) {
          if (d < 0.01) {
            dx = 0;
            dy = -1;
            d = 1;
          }
          const push = r - d;
          px += (dx / d) * push;
          py += (dy / d) * push;
        }
      }
    }
    return { x: px, y: py };
  }

  function update(dt: number) {
    const speed = owned("boots") ? 315 : 255;
    const cookRate = owned("fast") ? 48 : 34;
    for (const p of players) {
      let x = p.dx;
      let y = p.dy;
      let len = hypot(x, y);
      if (len > 1) {
        x /= len;
        y /= len;
        len = 1;
      }
      const k = Math.min(1, (len > 0.08 ? 12 : 8) * dt);
      p.vx += (x * speed - p.vx) * k;
      p.vy += (y * speed - p.vy) * k;
      const sp = hypot(p.vx, p.vy);
      if (sp > 18) {
        if (Math.abs(p.vx) > Math.abs(p.vy)) p.row = p.vx < 0 ? 1 : 2;
        else p.row = p.vy < 0 ? 3 : 0;
        p.walk += sp * dt * 0.09;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      const pushed = pushCircle(p.x, p.y, p.r);
      p.x = clamp(pushed.x, p.r + 4, WORLD_W - p.r - 4);
      p.y = clamp(pushed.y, 150, WORLD_H - p.r - 8);
      p.cool = Math.max(0, p.cool - dt);
    }
    const a = players[0];
    const b = players[1];
    if (a && b) {
      let dx = b.x - a.x;
      let dy = b.y - a.y;
      let d = hypot(dx, dy) || 0.001;
      const min = a.r + b.r - 4;
      if (d < min) {
        const push = (min - d) / 2;
        dx /= d;
        dy /= d;
        a.x -= dx * push;
        a.y -= dy * push;
        b.x += dx * push;
        b.y += dy * push;
      }
    }

    for (const s of stations) {
      if (s.type !== "stove") continue;
      const slots = owned("stove2") ? [s.a, s.b] : [s.a];
      for (const slot of slots) {
        const it = slot.item;
        if (!it || it.plate) continue;
        if (it.s === "raw") {
          slot.pr += dt * cookRate;
          if (slot.pr >= 100) {
            slot.pr = 100;
            it.s = "cooked";
            puff(s.x + s.w / 2, s.y, "#fff", 6);
            toast("الطعام جاهز");
          }
        } else if (it.s === "cooked") {
          slot.bn += dt;
          if (slot.bn > 13) {
            it.s = "burnt";
            toast("احترق الطعام");
          }
        }
      }
    }

    for (let i = ents.length - 1; i >= 0; i--) {
      const e = ents[i];
      if (!e) continue;
      e.life -= dt;
      if (e.life <= 0) {
        ents.splice(i, 1);
        continue;
      }
      e.grab -= dt;
      if (e.air) {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        e.z += e.vz * dt;
        e.vz -= G * dt;
        if (e.z <= 0) {
          e.z = 0;
          if (e.vz < -80) {
            e.vz = -e.vz * 0.28;
            e.vx *= 0.5;
            e.vy *= 0.5;
          } else {
            e.air = false;
            e.vz = 0;
          }
        }
        if (e.z < 46 && e.grab <= 0) {
          for (const p of players) {
            if (!p.item && hypot(p.x - e.x, p.y - e.y) < 34) {
              p.item = e.item;
              puff(p.x, p.y - 20, "#ffe08a", 5);
              beep(660, 0.08, "triangle");
              ents.splice(i, 1);
              e.life = 0;
              break;
            }
          }
        }
      } else {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        const f = Math.exp(-6 * dt);
        e.vx *= f;
        e.vy *= f;
      }
      if (e.life <= 0) continue;
      e.x = clamp(e.x, 16, WORLD_W - 16);
      e.y = clamp(e.y, 160, WORLD_H - 16);
      if (e.z < 8) {
        const pushed = pushCircle(e.x, e.y, 12);
        e.x = pushed.x;
        e.y = pushed.y;
      }
    }

    const L = levelOf(li + 1);
    nextOrd -= dt;
    if (orders.length < L.conc && nextOrd <= 0) {
      addOrder();
      nextOrd = L.gap;
    }
    if (!orders.length) nextOrd = Math.min(nextOrd, 1.4);
    for (let i = orders.length - 1; i >= 0; i--) {
      const o = orders[i];
      if (!o) continue;
      o.t -= dt;
      if (o.t <= 0) {
        orders.splice(i, 1);
        score = Math.max(0, score - 12);
        toast("فات وقت الطلب");
        pushHud();
      }
    }
    for (let i = puffs.length - 1; i >= 0; i--) {
      const q = puffs[i];
      if (!q) continue;
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.vy += 40 * dt;
      q.life -= dt;
      if (q.life <= 0) puffs.splice(i, 1);
    }
    if (count > 0) {
      count -= dt;
      if (count <= 0) {
        live = true;
        toast(HINTS[li + 1] || "الطلبات في الممر. سلّموا الطبق المطابق.");
      }
    }
    if (live) {
      timerAcc += dt;
      while (timerAcc >= 1) {
        timerAcc -= 1;
        timeLeft -= 1;
        pushHud();
        if (timeLeft <= 0) {
          finish();
          break;
        }
      }
    }
  }

  function finish() {
    live = false;
    paused = true;
    const L = levelOf(li + 1);
    const g = L.goals;
    const stars = score >= g[2] ? 3 : score >= g[1] ? 2 : score >= g[0] ? 1 : 0;
    if (stars > (save.stars[li] || 0)) save.stars[li] = stars;
    const gain = earn + stars * 5;
    save.coins += gain;
    persist();
    const cleared = stars > 0;
    opts.onEnd({
      stars,
      score,
      gain,
      coins: save.coins,
      cleared,
      last: li >= 39,
      line: cleared
        ? li >= 39
          ? "أنهيتما كل المراحل"
          : "نجحتما. المرحلة التالية مفتوحة"
        : `يلزم ${g[0]} نقطة لفتح التالية`,
    });
    pushHud();
  }

  function roundRect(x: number, y: number, w: number, h: number, r: number) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
  }

  function drawOrders() {
    orders.forEach((o, i) => {
      const n = o.parts.length;
      const w = Math.max(92, 16 + n * 34);
      const h = 74;
      const x = WORLD_W / 2 - w / 2;
      const y = 188 + i * 82;
      ctx.fillStyle = "rgba(0,0,0,0.18)";
      roundRect(x + 3, y + 4, w, h, 12);
      ctx.fill();
      ctx.fillStyle = "#fff4d8";
      roundRect(x, y, w, h, 12);
      ctx.fill();
      ctx.strokeStyle = "#e7c27a";
      ctx.lineWidth = 2;
      ctx.stroke();
      o.parts.forEach((part, j) => {
        const [k, s] = part.split("_");
        if (!k || !s) return;
        const gap = Math.min(34, (w - 16) / n);
        drawFood(k, s as FoodState, x + w / 2 + (j - (n - 1) / 2) * gap, y + 34, n > 4 ? 28 : 34);
      });
      const f = clamp(o.t / o.max, 0, 1);
      ctx.fillStyle = "#3a2415";
      roundRect(x + 8, y + h - 12, w - 16, 6, 3);
      ctx.fill();
      ctx.fillStyle = f > 0.5 ? "#2f8f45" : f > 0.25 ? "#f0b429" : "#e04b3a";
      roundRect(x + 8, y + h - 12, (w - 16) * f, 6, 3);
      ctx.fill();
    });
  }

  function drawPlayer(p: Player) {
    const sheet = p.id === 0 ? banana : carrot;
    const frame = hypot(p.vx, p.vy) > 18 ? Math.floor(p.walk) % 4 : 0;
    const img = sheet[p.row * 4 + frame];
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.beginPath();
    ctx.ellipse(p.x, p.y + 2, 16, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    const bob = hypot(p.vx, p.vy) > 18 ? Math.abs(Math.sin(p.walk * 1.4)) * 3 : 0;
    if (img) {
      const d = 104;
      ctx.drawImage(img, p.x - d / 2, p.y - d + 10 - bob, d, d);
    }
    if (p.item) {
      const off =
        p.row === 1 ? [-26, -18] : p.row === 2 ? [26, -18] : p.row === 3 ? [0, -52] : [0, 6];
      drawItem(p.item, p.x + (off[0] || 0), p.y + (off[1] || 0) - bob, p.item.plate ? 52 : 40);
    }
    const name = save.names[p.id] || (p.id ? "جزرة" : "موزة");
    ctx.font = "700 16px Tajawal, sans-serif";
    ctx.textAlign = "center";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(0,0,0,0.55)";
    ctx.strokeText(name, p.x, p.y + 22);
    ctx.fillStyle = "#fff6e4";
    ctx.fillText(name, p.x, p.y + 22);
  }

  function drawStations() {
    for (const s of stations) {
      if (s.type === "serve" || s.type === "crate" || s.type === "trash") continue;
      const slots = s.type === "stove" && owned("stove2") ? [s.a, s.b] : [s.a];
      slots.forEach((slot, i) => {
        if (!slot.item) return;
        const ox = slots.length > 1 ? (i === 0 ? -16 : 16) : 0;
        drawItem(slot.item, s.x + s.w / 2 + ox, s.y + s.h * 0.45, slot.item.plate ? 54 : 42);
        const show =
          (s.type === "stove" && slot.item && !slot.item.plate && slot.item.s === "raw") ||
          (s.type === "board" && slot.pr > 0 && slot.item && !slot.item.plate && slot.item.s === "raw");
        if (!show) {
          if (s.type === "stove" && slot.item && !slot.item.plate && slot.item.s === "cooked" && slot.bn > 8) {
            ctx.fillStyle = "#e04b3a";
            ctx.font = "800 18px Tajawal, sans-serif";
            ctx.textAlign = "center";
            ctx.fillText("!", s.x + s.w / 2 + ox, s.y - 4);
          }
          return;
        }
        const need = s.type === "board" ? (owned("knife") ? 2 : 3) : 100;
        const ratio = clamp(slot.pr / need, 0, 1);
        ctx.fillStyle = "#3a2415";
        ctx.fillRect(s.x, s.y - 8, s.w, 5);
        ctx.fillStyle = s.type === "stove" ? "#f0b429" : "#2f8f45";
        ctx.fillRect(s.x, s.y - 8, s.w * ratio, 5);
      });
    }
    if (!debug) return;
    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = "#e04b3a";
    for (const b of solids) ctx.fillRect(b.x, b.y, b.w, b.h);
    ctx.fillStyle = "#2f8f45";
    for (const s of stations) ctx.fillRect(s.x, s.y, s.w, s.h);
    ctx.restore();
  }

  function draw() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = canvas.clientWidth || window.innerWidth;
    const H = canvas.clientHeight || window.innerHeight;
    const bw = Math.max(1, Math.round(W * dpr));
    const bh = Math.max(1, Math.round(H * dpr));
    if (canvas.width !== bw || canvas.height !== bh) {
      canvas.width = bw;
      canvas.height = bh;
    }
    const reserve = H > W * 1.08 ? 176 : 0;
    const top = H > W * 1.08 ? 56 : 0;
    const scale = Math.min(W / WORLD_W, Math.max(1, H - reserve - top) / WORLD_H);
    const ox = (W - WORLD_W * scale) / 2;
    const oy = H > W * 1.08 ? top : (H - WORLD_H * scale) / 2;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#e7d3ae";
    ctx.fillRect(0, 0, W, H);
    ctx.setTransform(dpr * scale, 0, 0, dpr * scale, ox * dpr, oy * dpr);
    if (kitchen) ctx.drawImage(kitchen, 0, 0, WORLD_W, WORLD_H);
    else {
      ctx.fillStyle = "#d7b98a";
      ctx.fillRect(0, 0, WORLD_W, WORLD_H);
    }
    drawStations();
    const fly = [...ents].sort((p, q) => p.y - q.y);
    for (const e of fly) {
      ctx.fillStyle = "rgba(0,0,0,0.16)";
      ctx.beginPath();
      ctx.ellipse(e.x, e.y + 4, 12, 5, 0, 0, Math.PI * 2);
      ctx.fill();
      drawItem(e.item, e.x, e.y - e.z * 0.7, e.item.plate ? 52 : 40);
    }
    [...players].sort((p, q) => p.y - q.y).forEach(drawPlayer);
    for (const q of puffs) {
      ctx.globalAlpha = clamp(q.life / 0.4, 0, 1);
      ctx.fillStyle = q.c;
      ctx.beginPath();
      ctx.arc(q.x, q.y, 3.2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    drawOrders();
    if (count > 0) {
      const n = Math.ceil(count);
      ctx.fillStyle = "rgba(58,36,21,0.35)";
      ctx.fillRect(0, 0, WORLD_W, WORLD_H);
      ctx.fillStyle = "#fff6e4";
      ctx.font = "800 120px Tajawal, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(n > 0 ? String(n) : "هيا", WORLD_W / 2, WORLD_H / 2);
    }
  }

  function readMove() {
    const down = (code: string) => (injected ? injected.includes(code) : keys.has(code));
    const pairs: [Player, number, number][] = [
      [players[0]!, (down("KeyD") ? 1 : 0) - (down("KeyA") ? 1 : 0), (down("KeyS") ? 1 : 0) - (down("KeyW") ? 1 : 0)],
      [
        players[1]!,
        (down("ArrowRight") ? 1 : 0) - (down("ArrowLeft") ? 1 : 0),
        (down("ArrowDown") ? 1 : 0) - (down("ArrowUp") ? 1 : 0),
      ],
    ];
    pairs.forEach(([p, x, y], i) => {
      if (x || y) {
        p.dx = x;
        p.dy = y;
      } else {
        p.dx = stick[i]?.[0] || 0;
        p.dy = stick[i]?.[1] || 0;
      }
    });
  }

  function frame(ts: number) {
    if (dead) return;
    requestAnimationFrame(frame);
    if (!last) last = ts;
    const d = Math.min((ts - last) / 1000, 0.05);
    last = ts;
    if (!paused) {
      acc += d;
      const step = 1 / 60;
      while (acc >= step) {
        readMove();
        update(step);
        acc -= step;
      }
    }
    draw();
  }

  function onKeyDown(e: KeyboardEvent) {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
    keys.add(e.code);
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) e.preventDefault();
    if (e.repeat) return;
    if (e.code === "KeyF") act(0);
    if (e.code === "KeyG") toss(0);
    if (e.code === "KeyH") deliver(0);
    if (e.code === "Enter") act(1);
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") toss(1);
    if (e.code === "Period") deliver(1);
    if (e.code === "Escape") opts.onPauseToggle();
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
  }
  function resumeAudio() {
    if (!audio) return;
    if (audio.state === "suspended") void audio.resume();
  }

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("pointerdown", resumeAudio);
  window.addEventListener("blur", () => keys.clear());

  const probe = {
    setKeys(codes: string[]) {
      injected = codes;
    },
    getSpeed() {
      const p = players[0];
      return p ? hypot(p.vx, p.vy) : 0;
    },
    getX() {
      return players[0]?.x ?? 0;
    },
    getY() {
      return players[0]?.y ?? 0;
    },
    getYaw() {
      return players[0]?.row ?? 0;
    },
  };
  (window as unknown as { __controlsTest?: typeof probe }).__controlsTest = probe;

  requestAnimationFrame(frame);

  const assets = [
    loadImage("/game/kitchen.jpg").then((img) => {
      kitchen = img;
    }),
    loadImage("/game/plate.png").then((img) => {
      plateImg = img;
    }),
    ...Array.from({ length: 16 }, (_, i) =>
      loadImage(`/game/banana/${i + 1}.png`).then((img) => {
        banana[i] = img;
      }),
    ),
    ...Array.from({ length: 16 }, (_, i) =>
      loadImage(`/game/carrot/${i + 1}.png`).then((img) => {
        carrot[i] = img;
      }),
    ),
    ...Array.from({ length: 16 }, (_, i) =>
      loadImage(`/game/food/${i + 1}.png`).then((img) => {
        foods[i] = img;
      }),
    ),
  ];

  void Promise.all(assets)
    .then(() => {
      opts.onReady();
      pushHud();
      if (qa) {
        li = 0;
        score = 0;
        served = 0;
        earn = 0;
        timeLeft = 600;
        orders = [];
        ents = [];
        stations = buildStations();
        count = 0;
        live = true;
        paused = false;
        players[0]!.x = 390;
        players[0]!.y = 520;
        players[1]!.x = 900;
        players[1]!.y = 520;
      }
    })
    .catch(() => opts.onToast("تعذّر تحميل رسوم المطبخ"));

  return {
    destroy() {
      dead = true;
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("pointerdown", resumeAudio);
    },
    setStick(id, x, y) {
      stick[id] = [x, y];
    },
    act,
    toss,
    deliver,
    startLevel(i: number) {
      li = clamp(i, 0, 39);
      score = 0;
      served = 0;
      earn = 0;
      const L = levelOf(li + 1);
      timeLeft = L.t;
      timerAcc = 0;
      orders = [];
      ents = [];
      puffs = [];
      stations = buildStations();
      nextOrd = 1.2;
      players.forEach((p, idx) => {
        p.x = idx ? 900 : 390;
        p.y = 520;
        p.vx = p.vy = p.dx = p.dy = 0;
        p.item = null;
        p.row = idx ? 2 : 0;
        p.walk = 0;
      });
      count = qa ? 0 : 3.2;
      live = qa;
      paused = false;
      pushHud();
      if (!qa) beep(520, 0.08, "triangle");
    },
    setPaused(p: boolean) {
      if (!live && count <= 0 && p) {
        paused = true;
        return;
      }
      paused = p;
      if (p) {
        players.forEach((pl) => {
          pl.dx = 0;
          pl.dy = 0;
          pl.vx = 0;
          pl.vy = 0;
        });
      }
    },
    setNames(a: string, b: string) {
      save.names = [a.trim() || "موزة", b.trim() || "جزرة"];
      persist();
    },
    setSound(on: boolean) {
      save.sound = on;
      persist();
    },
    buy(id: string) {
      const price = id === "boots" ? 120 : id === "knife" ? 140 : id === "fast" ? 180 : id === "stove2" ? 250 : 0;
      if (!price || owned(id)) return false;
      if (save.coins < price) return false;
      save.coins -= price;
      save.owned.push(id);
      persist();
      pushHud();
      return true;
    },
    getSave: () => ({
      coins: save.coins,
      owned: [...save.owned],
      names: [...save.names] as [string, string],
      stars: [...save.stars],
      sound: save.sound,
    }),
  };
}
