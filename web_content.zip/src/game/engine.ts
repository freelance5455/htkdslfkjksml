import * as THREE from "three";
import { audio } from "./audio";
import {
  createBotWeaponModel,
  createCharacter,
  createPickupMesh,
  createVehicleModel,
  createWeaponModel,
  FOX_PALETTE,
  toon,
  type CharacterPalette,
  type CharacterRig,
  type VehicleModel,
  type WeaponId,
  type WeaponModel,
} from "./models";
import { buildArena, type ArenaData, type Destructible, type Obstacle } from "./world";
import type { EngineCallbacks, GameMode, GameResults, HudState, KillFeedItem, Settings, Team } from "./types";

/* ------------------------------------------------------------------ */
/* Definitions                                                         */
/* ------------------------------------------------------------------ */

interface WeaponDef {
  id: WeaponId;
  name: string;
  short: string;
  damage: number;
  pellets: number;
  spread: number;
  fireRate: number;
  mag: number;
  reserve: number;
  reload: number;
  auto: boolean;
  range: number;
  color: string;
  projectile?: boolean;
  splash?: number;
}

const WEAPONS: WeaponDef[] = [
  { id: "pulse", name: "ПУЛЬСАР", short: "AR", damage: 13, pellets: 1, spread: 0.014, fireRate: 0.105, mag: 30, reserve: 150, reload: 1.45, auto: true, range: 90, color: "#3ce0cf" },
  { id: "smg", name: "ОСА", short: "SMG", damage: 8, pellets: 1, spread: 0.024, fireRate: 0.072, mag: 32, reserve: 192, reload: 1.3, auto: true, range: 70, color: "#9fe870" },
  { id: "shotgun", name: "ДРОБОВИК", short: "SG", damage: 11, pellets: 7, spread: 0.075, fireRate: 0.78, mag: 6, reserve: 42, reload: 2.0, auto: false, range: 32, color: "#ffa63c" },
  { id: "sniper", name: "СНАЙПЕР", short: "SR", damage: 78, pellets: 1, spread: 0.0015, fireRate: 1.1, mag: 5, reserve: 30, reload: 2.3, auto: false, range: 150, color: "#a08cff" },
  { id: "pistol", name: "МАГНУМ", short: "HG", damage: 34, pellets: 1, spread: 0.006, fireRate: 0.32, mag: 8, reserve: 48, reload: 1.6, auto: false, range: 80, color: "#ffd45e" },
  { id: "rocket", name: "ГРАНАТОМЁТ", short: "RL", damage: 55, pellets: 1, spread: 0.008, fireRate: 1.25, mag: 4, reserve: 16, reload: 2.5, auto: false, range: 110, color: "#ff6b6b", projectile: true, splash: 62 },
];

const BOT_STYLES: { name: string; palette: CharacterPalette }[] = [
  { name: "Кусь", palette: { primary: 0x39d6c8, secondary: 0xd8fff9, accent: 0xffb43c, dark: 0x243b4a, belly: 0xeafffb } },
  { name: "Бублик", palette: { primary: 0xa08cff, secondary: 0xffe6a8, accent: 0x39d6c8, dark: 0x2b2540, belly: 0xfff1d6 } },
  { name: "Шпрот", palette: { primary: 0x7fc95c, secondary: 0xfff1d6, accent: 0xff6b6b, dark: 0x2b3a2a, belly: 0xf4ffe8 } },
  { name: "Мармелад", palette: { primary: 0xff7fa8, secondary: 0xfff1d6, accent: 0xffd45e, dark: 0x3d2433, belly: 0xfff0f5 } },
  { name: "Тостер", palette: { primary: 0xffb43c, secondary: 0xfff1d6, accent: 0x39d6c8, dark: 0x3d2f1e, belly: 0xfff8e8 } },
  { name: "Плюшка", palette: { primary: 0xe8a06a, secondary: 0xfff1d6, accent: 0xa08cff, dark: 0x3d2a20, belly: 0xfff4e6 } },
  { name: "Вихрь", palette: { primary: 0x5cb8ff, secondary: 0xe8f6ff, accent: 0xffb43c, dark: 0x1f2f45, belly: 0xf0faff } },
  { name: "Сырник", palette: { primary: 0xffd45e, secondary: 0xfff8e0, accent: 0xff7fa8, dark: 0x3d3520, belly: 0xfffdf0 } },
  { name: "Клякса", palette: { primary: 0x5c7cfa, secondary: 0xe8f0ff, accent: 0xffb43c, dark: 0x1f2a4a, belly: 0xf0f5ff } },
  { name: "Плюх", palette: { primary: 0xff9f5c, secondary: 0xfff1d6, accent: 0x39d6c8, dark: 0x3d2a20, belly: 0xfff4e6 } },
];

const PLAYER_SPAWN = new THREE.Vector3(0, 0, 30);
const GRAVITY = 24;
const PLAYER_RADIUS = 0.44;
const MATCH_TIME = 240;
const SCORE_LIMIT = 25;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function rayAABB(origin: THREE.Vector3, dir: THREE.Vector3, min: THREE.Vector3, max: THREE.Vector3): number | null {
  let tmin = 0;
  let tmax = Infinity;
  const axes: ("x" | "y" | "z")[] = ["x", "y", "z"];
  for (const axis of axes) {
    const d = dir[axis];
    const o = origin[axis];
    if (Math.abs(d) < 1e-8) {
      if (o < min[axis] || o > max[axis]) return null;
    } else {
      let t1 = (min[axis] - o) / d;
      let t2 = (max[axis] - o) / d;
      if (t1 > t2) [t1, t2] = [t2, t1];
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}

function raySphere(origin: THREE.Vector3, dir: THREE.Vector3, center: THREE.Vector3, radius: number): number | null {
  const ox = origin.x - center.x;
  const oy = origin.y - center.y;
  const oz = origin.z - center.z;
  const b = ox * dir.x + oy * dir.y + oz * dir.z;
  const c = ox * ox + oy * oy + oz * oz - radius * radius;
  const disc = b * b - c;
  if (disc < 0) return null;
  const t = -b - Math.sqrt(disc);
  return t > 0 ? t : null;
}

function segmentHitsBox(x1: number, z1: number, x2: number, z2: number, o: Obstacle, pad = 0.05) {
  const minX = o.x - o.hw - pad;
  const maxX = o.x + o.hw + pad;
  const minZ = o.z - o.hd - pad;
  const maxZ = o.z + o.hd + pad;
  let tmin = 0;
  let tmax = 1;
  const dx = x2 - x1;
  const dz = z2 - z1;
  for (const [p, d, min, max] of [
    [x1, dx, minX, maxX],
    [z1, dz, minZ, maxZ],
  ] as const) {
    if (Math.abs(d) < 1e-8) {
      if (p < min || p > max) return false;
    } else {
      let t1 = (min - p) / d;
      let t2 = (max - p) / d;
      if (t1 > t2) [t1, t2] = [t2, t1];
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return false;
    }
  }
  return true;
}

function resolveCircle(pos: THREE.Vector3, radius: number, obstacles: Obstacle[]) {
  for (const o of obstacles) {
    if (pos.y > o.height + 0.1) continue;
    const cx = clamp(pos.x, o.x - o.hw, o.x + o.hw);
    const cz = clamp(pos.z, o.z - o.hd, o.z + o.hd);
    const dx = pos.x - cx;
    const dz = pos.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 < radius * radius) {
      if (d2 > 1e-7) {
        const d = Math.sqrt(d2);
        pos.x += (dx / d) * (radius - d);
        pos.z += (dz / d) * (radius - d);
      } else {
        const left = pos.x - (o.x - o.hw);
        const right = o.x + o.hw - pos.x;
        const top = pos.z - (o.z - o.hd);
        const bottom = o.z + o.hd - pos.z;
        const m = Math.min(left, right, top, bottom);
        if (m === left) pos.x = o.x - o.hw - radius;
        else if (m === right) pos.x = o.x + o.hw + radius;
        else if (m === top) pos.z = o.z - o.hd - radius;
        else pos.z = o.z + o.hd + radius;
      }
    }
  }
}

/* ------------------------------------------------------------------ */
/* Internal entity types                                               */
/* ------------------------------------------------------------------ */

interface Bot {
  id: number;
  name: string;
  team: Team | "none";
  rig: CharacterRig;
  weapon: WeaponModel;
  pos: THREE.Vector3;
  yaw: number;
  health: number;
  alive: boolean;
  respawnAt: number;
  deadAt: number;
  targetKind: "player" | "bot" | null;
  targetId: number;
  nextShot: number;
  burst: number;
  burstPause: number;
  ammo: number;
  reloadUntil: number;
  wander: THREE.Vector3;
  wanderUntil: number;
  strafe: number;
  kills: number;
  deaths: number;
  walkPhase: number;
  aimPitch: number;
  reactionUntil: number;
  lastPos: THREE.Vector3;
  stuckTime: number;
  coverPos: THREE.Vector3 | null;
  coverUntil: number;
  grenadeReadyAt: number;
}

interface Vehicle {
  id: number;
  type: "buggy" | "tank";
  team: Team;
  model: VehicleModel;
  pos: THREE.Vector3;
  yaw: number;
  speed: number;
  health: number;
  maxHealth: number;
  occupied: boolean;
  alive: boolean;
  respawnAt: number;
  nextFire: number;
  spawn: { x: number; z: number; yaw: number };
  wheelSpin: number;
}

interface Projectile {
  mesh: THREE.Object3D;
  vel: THREE.Vector3;
  life: number;
  damage: number;
  splash: number;
  radius: number;
  owner: "player" | "bot";
  ownerId: number;
  team: Team | "none";
  gravity: number;
  color: number;
  trail: boolean;
}

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  gravity: number;
  spin: number;
  shrink: boolean;
}

interface Tracer {
  line: THREE.Line;
  life: number;
}

interface Ring {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  grow: number;
}

interface FloatText {
  sprite: THREE.Sprite;
  life: number;
  maxLife: number;
  vel: THREE.Vector3;
}

interface Pickup {
  mesh: THREE.Group;
  kind: "health" | "ammo";
  pos: THREE.Vector3;
  active: boolean;
  respawnAt: number;
  baseY: number;
  phase: number;
  dynamic: boolean;
}

interface FeedEntry extends KillFeedItem {
  at: number;
}

/* ------------------------------------------------------------------ */
/* Engine                                                              */
/* ------------------------------------------------------------------ */

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private callbacks: EngineCallbacks;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private lastFrame = performance.now();
  private arena: ArenaData;
  private baseObstacles: Obstacle[] = [];
  private obstacles: Obstacle[] = [];
  private menuGroup = new THREE.Group();
  private menuBots: CharacterRig[] = [];
  private playerRig: CharacterRig;
  private bots: Bot[] = [];
  private vehicles: Vehicle[] = [];
  private pickups: Pickup[] = [];
  private projectiles: Projectile[] = [];
  private particles: Particle[] = [];
  private tracers: Tracer[] = [];
  private rings: Ring[] = [];
  private floats: FloatText[] = [];
  private weaponModels: Record<WeaponId, WeaponModel>;
  private viewModels: Record<WeaponId, WeaponModel>;
  private state: "menu" | "playing" | "gameover" = "menu";
  private paused = false;
  private mode: GameMode = "dm";
  private nickname = "Игрок";
  private time = 0;
  private timeLeft = MATCH_TIME;
  private scoreLimit = SCORE_LIMIT;
  private teamScores = { sun: 0, tide: 0 };
  private killFeed: FeedEntry[] = [];
  private feedId = 1;
  private hudTimer = 0;
  private slowmo = 0;
  private menuTime = 0;
  private gameOverTime = 0;
  private resultSent = false;
  private settings: Settings;
  private keys = new Set<string>();
  private touchMove = { x: 0, y: 0 };
  private touchCrouch = false;
  private firing = false;
  private semiReady = false;
  private touchAim = false;
  private mouseAim = false;
  private jumpQueued = false;
  private lookDelta = { x: 0, y: 0 };
  private grenadeHoldStart = 0;
  private grenadeHolding = false;
  private pointerLocked = false;
  private suppressPause = false;
  private disposed = false;
  private particleCap = window.matchMedia("(pointer: coarse)").matches ? 150 : 260;
  private particleGeo = new THREE.SphereGeometry(0.09, 5, 4);
  private debrisGeo = new THREE.BoxGeometry(0.14, 0.14, 0.14);
  private particleMats = new Map<number, THREE.MeshBasicMaterial>();
  private textTexCache = new Map<string, THREE.Texture>();
  private tracerMats = new Map<number, THREE.LineBasicMaterial>();
  private muzzleLight: THREE.PointLight;
  private targetPixelRatio = 1;
  private fpsFrames = 0;
  private fpsTime = 0;

  private player = {
    pos: new THREE.Vector3().copy(PLAYER_SPAWN),
    vel: new THREE.Vector3(),
    yaw: Math.PI,
    pitch: -0.05,
    recoilPitch: 0,
    recoilYaw: 0,
    health: 100,
    maxHealth: 100,
    armor: 50,
    maxArmor: 100,
    alive: true,
    respawnAt: 0,
    grounded: true,
    crouch: false,
    weapons: WEAPONS.map((w) => ({ ammo: w.mag, reserve: w.reserve })),
    weaponIndex: 0,
    reloading: false,
    reloadEnd: 0,
    nextFire: 0,
    grenades: 3,
    grenadeReadyAt: 0,
    kills: 0,
    deaths: 0,
    streak: 0,
    bestStreak: 0,
    score: 0,
    shotsFired: 0,
    shotsHit: 0,
    recoil: 0,
    aim: false,
    firstPerson: false,
    inVehicle: null as Vehicle | null,
    lastDamage: -20,
    invulnUntil: 0,
    walkPhase: 0,
    speed: 0,
    flashUntil: 0,
  };

  constructor(canvas: HTMLCanvasElement, callbacks: EngineCallbacks, settings: Settings) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.settings = settings;

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !window.matchMedia("(pointer: coarse)").matches, powerPreference: "high-performance" });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.targetPixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    this.renderer.setPixelRatio(this.targetPixelRatio);
    this.renderer.setSize(canvas.clientWidth || window.innerWidth, canvas.clientHeight || window.innerHeight, false);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0xcfe9df, 100, 330);
    this.camera = new THREE.PerspectiveCamera(72, (canvas.clientWidth || 1) / (canvas.clientHeight || 1), 0.1, 520);
    this.scene.add(this.camera);

    const hemi = new THREE.HemisphereLight(0xd8f4ff, 0xd9b483, 1.55);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xfff2d0, 2.35);
    sun.position.set(26, 38, 18);
    this.scene.add(sun);
    const fill = new THREE.DirectionalLight(0x9fe8ff, 0.7);
    fill.position.set(-20, 16, -24);
    this.scene.add(fill);
    this.muzzleLight = new THREE.PointLight(0xffd27a, 0, 9, 2);
    this.scene.add(this.muzzleLight);

    this.addSky();
    this.arena = buildArena();
    this.scene.add(this.arena.group);
    this.baseObstacles = this.arena.obstacles.filter((o) => !o.destructible);
    this.obstacles = [...this.baseObstacles];

    this.playerRig = createCharacter(FOX_PALETTE, this.nickname, "sun", true);
    this.playerRig.group.visible = false;
    this.scene.add(this.playerRig.group);

    this.weaponModels = {
      pulse: createWeaponModel("pulse"),
      smg: createWeaponModel("smg"),
      shotgun: createWeaponModel("shotgun"),
      sniper: createWeaponModel("sniper"),
      pistol: createWeaponModel("pistol"),
      rocket: createWeaponModel("rocket"),
    };
    for (const id of Object.keys(this.weaponModels) as WeaponId[]) {
      const model = this.weaponModels[id];
      model.group.visible = id === "pulse";
      this.playerRig.weaponMount.add(model.group);
    }
    this.viewModels = {
      pulse: createWeaponModel("pulse"),
      smg: createWeaponModel("smg"),
      shotgun: createWeaponModel("shotgun"),
      sniper: createWeaponModel("sniper"),
      pistol: createWeaponModel("pistol"),
      rocket: createWeaponModel("rocket"),
    };
    for (const id of Object.keys(this.viewModels) as WeaponId[]) {
      const model = this.viewModels[id];
      model.group.position.set(0.3, -0.28, -0.62);
      model.group.rotation.set(0, 0.05, 0);
      model.group.scale.setScalar(0.92);
      model.group.visible = false;
      this.camera.add(model.group);
    }

    this.createBots();
    this.createVehicles();
    this.createPickups();
    this.createMenuScene();
    this.applySettings(settings);
    this.bindEvents();
    this.resize();
    this.renderer.setAnimationLoop(this.tick);
  }

  /* ---------------------------------------------------------------- */
  /* Setup                                                            */
  /* ---------------------------------------------------------------- */

  private addSky() {
    const skyGeo = new THREE.SphereGeometry(420, 20, 14);
    const skyMat = new THREE.ShaderMaterial({
      uniforms: {
        top: { value: new THREE.Color(0x4fb9e8) },
        bottom: { value: new THREE.Color(0xffe9c4) },
      },
      vertexShader: "varying vec3 vPos; void main(){ vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",
      fragmentShader:
        "uniform vec3 top; uniform vec3 bottom; varying vec3 vPos; void main(){ float h = clamp(normalize(vPos).y * 1.4 + 0.15, 0.0, 1.0); gl_FragColor = vec4(mix(bottom, top, h), 1.0); }",
      side: THREE.BackSide,
      depthWrite: false,
    });
    this.scene.add(new THREE.Mesh(skyGeo, skyMat));
    const sunDisc = new THREE.Mesh(new THREE.SphereGeometry(7, 12, 8), new THREE.MeshBasicMaterial({ color: 0xfff3b0 }));
    sunDisc.position.set(150, 120, -200);
    this.scene.add(sunDisc);
  }

  private createBots() {
    for (let i = 0; i < 10; i++) {
      const style = BOT_STYLES[i];
      const team: Team | "none" = this.mode === "tdm" ? (i < 5 ? "sun" : "tide") : "none";
      const rig = createCharacter(style.palette, style.name, team, false, false);
      rig.group.visible = false;
      this.scene.add(rig.group);
      const weapon = createBotWeaponModel();
      rig.weaponMount.add(weapon.group);
      this.bots.push({
        id: i,
        name: style.name,
        team,
        rig,
        weapon,
        pos: new THREE.Vector3(),
        yaw: 0,
        health: 100,
        alive: true,
        respawnAt: 0,
        deadAt: 0,
        targetKind: null,
        targetId: -1,
        nextShot: 0,
        burst: 0,
        burstPause: 0,
        ammo: 30,
        reloadUntil: 0,
        wander: new THREE.Vector3(),
        wanderUntil: 0,
        strafe: Math.random() > 0.5 ? 1 : -1,
        kills: 0,
        deaths: 0,
        walkPhase: Math.random() * 10,
        aimPitch: 0,
        reactionUntil: 0,
        lastPos: new THREE.Vector3(),
        stuckTime: 0,
        coverPos: null,
        coverUntil: 0,
        grenadeReadyAt: 3 + Math.random() * 5,
      });
    }
  }

  private createVehicles() {
    for (let i = 0; i < this.arena.vehicleSpawns.length; i++) {
      const spawn = this.arena.vehicleSpawns[i];
      const model = createVehicleModel(spawn.type, spawn.team);
      model.group.position.set(spawn.x, 0, spawn.z);
      model.group.rotation.y = spawn.yaw;
      this.scene.add(model.group);
      this.vehicles.push({
        id: i,
        type: spawn.type,
        team: spawn.team,
        model,
        pos: new THREE.Vector3(spawn.x, 0, spawn.z),
        yaw: spawn.yaw,
        speed: 0,
        health: spawn.type === "tank" ? 650 : 320,
        maxHealth: spawn.type === "tank" ? 650 : 320,
        occupied: false,
        alive: true,
        respawnAt: 0,
        nextFire: 0,
        spawn: { x: spawn.x, z: spawn.z, yaw: spawn.yaw },
        wheelSpin: 0,
      });
    }
  }

  private createPickups() {
    for (const spawn of this.arena.pickupSpawns) {
      const mesh = createPickupMesh(spawn.kind);
      mesh.position.set(spawn.x, 0, spawn.z);
      this.scene.add(mesh);
      this.pickups.push({
        mesh,
        kind: spawn.kind,
        pos: new THREE.Vector3(spawn.x, 0, spawn.z),
        active: true,
        respawnAt: 0,
        baseY: 0,
        phase: Math.random() * 6,
        dynamic: false,
      });
    }
  }

  private createMenuScene() {
    this.scene.add(this.menuGroup);
    const spots: [number, number, number][] = [
      [-1.7, 0, 9],
      [0.1, 0, 10.2],
      [1.8, 0, 9.1],
    ];
    for (let i = 0; i < 3; i++) {
      const rig = createCharacter(BOT_STYLES[i].palette, BOT_STYLES[i].name, i === 1 ? "tide" : "sun", false);
      rig.group.position.set(spots[i][0], 0, spots[i][2]);
      rig.group.rotation.y = Math.PI + (i - 1) * 0.2;
      rig.tag!.visible = false;
      rig.healthBar!.visible = false;
      rig.healthBarBg!.visible = false;
      this.menuGroup.add(rig.group);
      this.menuBots.push(rig);
    }
    const menuVehicle = createVehicleModel("buggy", "sun");
    menuVehicle.group.position.set(4.4, 0, 7.5);
    menuVehicle.group.rotation.y = -0.7;
    this.menuGroup.add(menuVehicle.group);
  }

  /* ---------------------------------------------------------------- */
  /* Public API                                                       */
  /* ---------------------------------------------------------------- */

  start(mode: GameMode, nickname: string) {
    this.mode = mode;
    this.nickname = nickname.trim() || "Игрок";
    this.playerRig.group.visible = true;
    this.menuGroup.visible = false;
    this.time = 0;
    this.shakeAmount = 0;
    this.slowmo = 0;
    this.mouseAim = false;
    this.resetMatch();
    this.state = "playing";
    this.paused = false;
    this.timeLeft = MATCH_TIME;
    this.scoreLimit = mode === "dm" ? SCORE_LIMIT : 30;
    this.teamScores = { sun: 0, tide: 0 };
    this.killFeed = [];
    this.resultSent = false;
    this.playerRig.group.rotation.set(0, this.player.yaw, 0);
    this.playerRig.group.scale.set(1, 1, 1);
    this.emitHud();
    audio.play("click");
    this.callbacks.onEvent({ type: "toast", text: "В БОЙ! Уничтожай соперников", tone: "good" });
    this.lockPointer();
  }

  toMenu() {
    this.state = "menu";
    this.paused = false;
    this.firing = false;
    this.menuGroup.visible = true;
    this.playerRig.group.visible = false;
    for (const bot of this.bots) bot.rig.group.visible = false;
    for (const model of Object.values(this.viewModels)) model.group.visible = false;
    this.exitPointerLock();
    audio.stopMusic();
  }

  setPaused(paused: boolean) {
    this.paused = paused;
    if (paused) {
      this.firing = false;
      this.mouseAim = false;
      this.touchAim = false;
      this.grenadeHolding = false;
      this.touchMove = { x: 0, y: 0 };
      this.lookDelta = { x: 0, y: 0 };
      this.keys.clear();
      this.exitPointerLock();
    } else if (this.state === "playing") {
      this.lockPointer();
    }
  }

  applySettings(settings: Settings) {
    this.settings = settings;
    const ratio = settings.quality === "low" ? 1 : settings.quality === "medium" ? Math.min(window.devicePixelRatio || 1, 1.5) : Math.min(window.devicePixelRatio || 1, 2);
    this.targetPixelRatio = ratio;
    this.renderer.setPixelRatio(ratio);
    audio.setVolumes(settings.sfx, settings.music);
    this.resize();
  }

  setMove(x: number, y: number) {
    this.touchMove.x = clamp(x, -1, 1);
    this.touchMove.y = clamp(y, -1, 1);
  }

  addLook(dx: number, dy: number) {
    if (this.state !== "playing" || this.paused) return;
    this.lookDelta.x += dx;
    this.lookDelta.y += dy;
  }

  setFiring(firing: boolean) {
    if (firing && !this.firing) this.semiReady = true;
    this.firing = firing;
  }

  setAim(aiming: boolean) {
    this.touchAim = aiming;
  }

  toggleCrouch() {
    this.touchCrouch = !this.touchCrouch;
  }

  selectWeapon(index: number) {
    if (index < 0 || index >= WEAPONS.length || index === this.player.weaponIndex) return;
    this.player.weaponIndex = index;
    this.player.reloading = false;
    this.player.nextFire = this.time + 0.22;
    for (const id of Object.keys(this.weaponModels) as WeaponId[]) {
      this.weaponModels[id].group.visible = false;
      this.viewModels[id].group.visible = false;
    }
    this.weaponModels[WEAPONS[index].id].group.visible = true;
    audio.play("click");
    this.emitHud();
  }

  cycleWeapon() {
    this.selectWeapon((this.player.weaponIndex + 1) % WEAPONS.length);
  }

  reload() {
    const p = this.player;
    const def = WEAPONS[p.weaponIndex];
    const state = p.weapons[p.weaponIndex];
    if (p.reloading || state.ammo >= def.mag || state.reserve <= 0 || !p.alive) return;
    p.reloading = true;
    p.reloadEnd = this.time + def.reload;
    audio.play("reload");
  }

  jump() {
    this.jumpQueued = true;
  }

  useAction() {
    if (this.state !== "playing" || this.paused || !this.player.alive) return;
    if (this.player.inVehicle) {
      this.exitVehicle();
      return;
    }
    const vehicle = this.nearestVehicle();
    if (vehicle) this.enterVehicle(vehicle);
  }

  toggleCamera() {
    this.player.firstPerson = !this.player.firstPerson;
    audio.play("click");
    this.emitHud();
  }

  beginGrenade() {
    if (this.state !== "playing" || this.paused || !this.player.alive || this.player.grenades <= 0) return;
    this.grenadeHolding = true;
    this.grenadeHoldStart = this.time;
  }

  releaseGrenade() {
    if (!this.grenadeHolding) return;
    this.grenadeHolding = false;
    const power = clamp((this.time - this.grenadeHoldStart) / 0.9, 0.25, 1);
    this.throwGrenade(power);
  }

  requestPointerLock() {
    this.lockPointer();
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.unbindEvents();
    this.renderer.dispose();
  }

  /* ---------------------------------------------------------------- */
  /* Events                                                           */
  /* ---------------------------------------------------------------- */

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.state !== "playing" || this.paused) return;
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
    const code = e.code;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(code)) e.preventDefault();
    this.keys.add(code);
    if (code === "Space") this.jumpQueued = true;
    if (code === "KeyR") this.reload();
    if (code === "KeyQ") this.cycleWeapon();
    if (code === "KeyE") this.useAction();
    if (code === "KeyV") this.toggleCamera();
    if (code === "KeyG") this.throwGrenade(0.7);
    if (code === "Digit1") this.selectWeapon(0);
    if (code === "Digit2") this.selectWeapon(1);
    if (code === "Digit3") this.selectWeapon(2);
    if (code === "Digit4") this.selectWeapon(3);
    if (code === "Escape") this.callbacks.onPauseRequest();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onMouseDown = (e: MouseEvent) => {
    if (this.state !== "playing" || this.paused) return;
    if (!this.pointerLocked && !this.isTouch()) this.lockPointer();
    if (e.button === 0) this.setFiring(true);
    if (e.button === 2) this.mouseAim = true;
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.firing = false;
    if (e.button === 2) this.mouseAim = false;
  };

  private onMouseMove = (e: MouseEvent) => {
    if (!this.pointerLocked || this.state !== "playing" || this.paused) return;
    const sens = 0.0021 * this.settings.sensitivity;
    this.player.yaw -= e.movementX * sens;
    this.player.pitch -= e.movementY * sens * (this.settings.invertY ? -1 : 1);
    this.player.pitch = clamp(this.player.pitch, -0.95, 0.85);
  };

  private onPointerLockChange = () => {
    this.pointerLocked = document.pointerLockElement === this.canvas;
    if (!this.pointerLocked && this.state === "playing" && !this.paused && !this.suppressPause && !this.isTouch()) {
      this.callbacks.onPauseRequest();
    }
  };

  private onContext = (e: Event) => e.preventDefault();

  private onVisibility = () => {
    if (document.hidden && this.state === "playing" && !this.paused) this.callbacks.onPauseRequest();
  };

  private onResize = () => this.resize();

  private bindEvents() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    this.canvas.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    window.addEventListener("mousemove", this.onMouseMove);
    this.canvas.addEventListener("contextmenu", this.onContext);
    document.addEventListener("pointerlockchange", this.onPointerLockChange);
    document.addEventListener("visibilitychange", this.onVisibility);
    window.addEventListener("resize", this.onResize);
  }

  private unbindEvents() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.canvas.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("mouseup", this.onMouseUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    this.canvas.removeEventListener("contextmenu", this.onContext);
    document.removeEventListener("pointerlockchange", this.onPointerLockChange);
    document.removeEventListener("visibilitychange", this.onVisibility);
    window.removeEventListener("resize", this.onResize);
  }

  private isTouch() {
    return window.matchMedia("(pointer: coarse)").matches || this.settings.touch;
  }

  private lockPointer() {
    if (this.isTouch() || document.pointerLockElement === this.canvas) return;
    try {
      const result = this.canvas.requestPointerLock() as unknown;
      if (result instanceof Promise) result.catch(() => undefined);
    } catch {
      /* ignore */
    }
  }

  private exitPointerLock() {
    this.suppressPause = true;
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    window.setTimeout(() => {
      this.suppressPause = false;
    }, 60);
  }

  private resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    if (w === 0 || h === 0) return;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  /* ---------------------------------------------------------------- */
  /* Match lifecycle                                                  */
  /* ---------------------------------------------------------------- */

  private resetMatch() {
    this.clearDynamic();
    this.player.pos.copy(this.mode === "tdm" ? this.arena.spawns.sun[1] : this.arena.spawns.dm[0]);
    this.player.vel.set(0, 0, 0);
    this.player.yaw = Math.atan2(this.player.pos.x, this.player.pos.z);
    this.player.pitch = -0.05;
    this.player.recoilPitch = 0;
    this.player.recoilYaw = 0;
    this.player.health = this.player.maxHealth;
    this.player.armor = 50;
    this.player.alive = true;
    this.player.respawnAt = 0;
    this.player.crouch = false;
    this.player.weapons = WEAPONS.map((w) => ({ ammo: w.mag, reserve: w.reserve }));
    this.player.weaponIndex = 0;
    this.player.reloading = false;
    this.player.grenades = 3;
    this.player.kills = 0;
    this.player.deaths = 0;
    this.player.streak = 0;
    this.player.bestStreak = 0;
    this.player.score = 0;
    this.player.shotsFired = 0;
    this.player.shotsHit = 0;
    this.player.inVehicle = null;
    this.player.lastDamage = -20;
    this.player.invulnUntil = this.time + 1.5;
    this.player.firstPerson = false;
    this.playerRig.group.visible = true;
    this.playerRig.group.rotation.set(0, this.player.yaw, 0);
    this.playerRig.group.scale.set(1, 1, 1);
    for (const id of Object.keys(this.weaponModels) as WeaponId[]) {
      this.weaponModels[id].group.visible = id === "pulse";
      this.viewModels[id].group.visible = false;
    }

    // reset destructibles
    for (const d of this.arena.destructibles) {
      d.alive = true;
      d.health = d.maxHealth;
      if (!d.mesh.parent) this.arena.group.add(d.mesh);
      d.mesh.visible = true;
    }
    this.obstacles = [...this.baseObstacles, ...this.arena.destructibles.filter((d) => d.alive).map((d) => d.obstacle)];

    // reset pickups
    for (const p of this.pickups) {
      if (p.dynamic) {
        this.scene.remove(p.mesh);
      } else {
        p.active = true;
        p.mesh.visible = true;
        p.respawnAt = 0;
      }
    }
    this.pickups = this.pickups.filter((p) => !p.dynamic);

    // reset vehicles
    for (const v of this.vehicles) {
      v.pos.set(v.spawn.x, 0, v.spawn.z);
      v.yaw = v.spawn.yaw;
      v.speed = 0;
      v.health = v.maxHealth;
      v.alive = true;
      v.occupied = false;
      v.respawnAt = 0;
      v.model.group.visible = true;
      v.model.group.position.set(v.spawn.x, 0, v.spawn.z);
      v.model.group.rotation.set(0, v.spawn.yaw, 0);
      v.model.group.scale.set(1, 1, 1);
    }

    // reset bots
    const sunSpawns = [...this.arena.spawns.sun];
    const tideSpawns = [...this.arena.spawns.tide];
    const dmSpawns = [...this.arena.spawns.dm];
    for (const bot of this.bots) {
      bot.team = this.mode === "tdm" ? (bot.id < 5 ? "sun" : "tide") : "none";
      if (bot.rig.tag) bot.rig.tag.visible = true;
      const pool = this.mode === "tdm" ? (bot.team === "sun" ? sunSpawns : tideSpawns) : dmSpawns;
      let spawn = pool[Math.floor(Math.random() * pool.length)];
      for (let tries = 0; tries < 8; tries++) {
        const candidate = pool[Math.floor(Math.random() * pool.length)];
        if (candidate.distanceTo(this.player.pos) > 22) {
          spawn = candidate;
          break;
        }
      }
      bot.pos.copy(spawn);
      bot.pos.x += (Math.random() - 0.5) * 2;
      bot.pos.z += (Math.random() - 0.5) * 2;
      bot.yaw = Math.random() * Math.PI * 2;
      bot.health = 100;
      bot.alive = true;
      bot.respawnAt = 0;
      bot.deadAt = 0;
      bot.ammo = 30;
      bot.reloadUntil = 0;
      bot.kills = 0;
      bot.deaths = 0;
      bot.targetKind = null;
      bot.targetId = -1;
      bot.coverPos = null;
      bot.coverUntil = 0;
      bot.grenadeReadyAt = 3 + Math.random() * 5;
      bot.wander.copy(bot.pos);
      bot.wanderUntil = 0;
      bot.rig.group.visible = true;
      bot.rig.group.position.copy(bot.pos);
      bot.rig.group.rotation.set(0, bot.yaw, 0);
      bot.rig.group.scale.set(1, 1, 1);
      bot.weapon.flash.visible = false;
    }
  }

  private clearDynamic() {
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    this.projectiles = [];
    for (const p of this.particles) this.scene.remove(p.mesh);
    this.particles = [];
    for (const t of this.tracers) {
      this.scene.remove(t.line);
      t.line.geometry.dispose();
    }
    this.tracers = [];
    for (const r of this.rings) {
      this.scene.remove(r.mesh);
      r.mesh.geometry.dispose();
      (r.mesh.material as THREE.Material).dispose();
    }
    this.rings = [];
    for (const f of this.floats) this.scene.remove(f.sprite);
    this.floats = [];
    this.muzzleLight.intensity = 0;
  }

  private endMatch(reason: "time" | "score") {
    if (this.state !== "playing" || this.resultSent) return;
    this.resultSent = true;
    this.state = "gameover";
    this.gameOverTime = 0;
    this.firing = false;
    this.exitPointerLock();
    const accuracy = this.player.shotsFired > 0 ? Math.round((this.player.shotsHit / this.player.shotsFired) * 100) : 0;
    let place = 1;
    if (this.mode === "dm") {
      const all = [{ name: this.nickname, kills: this.player.kills }, ...this.bots.map((b) => ({ name: b.name, kills: b.kills }))];
      all.sort((a, b) => b.kills - a.kills);
      place = all.findIndex((p) => p.name === this.nickname) + 1;
    } else {
      place = this.teamScores.sun >= this.teamScores.tide ? 1 : 2;
    }
    const results: GameResults = {
      mode: this.mode,
      score: this.player.score,
      kills: this.player.kills,
      deaths: this.player.deaths,
      accuracy,
      bestStreak: this.player.bestStreak,
      teamScores: { ...this.teamScores },
      won: this.mode === "tdm" ? this.teamScores.sun >= this.teamScores.tide : place === 1,
      reason,
      place,
    };
    audio.play(results.won ? "kill" : "death");
    this.callbacks.onGameOver(results);
  }

  /* ---------------------------------------------------------------- */
  /* Main loop                                                        */
  /* ---------------------------------------------------------------- */

  private tick = () => {
    if (this.disposed) return;
    const now = performance.now();
    const raw = Math.min((now - this.lastFrame) / 1000, 0.05);
    this.lastFrame = now;
    let dt = raw;
    if (this.slowmo > 0) {
      this.slowmo -= raw;
      dt = raw * 0.3;
    }
    this.time += dt;
    this.fpsFrames++;
    this.fpsTime += raw;
    if (this.fpsTime > 2.5) {
      const fps = this.fpsFrames / this.fpsTime;
      const current = this.renderer.getPixelRatio();
      if (fps < 45 && current > 0.75) {
        this.renderer.setPixelRatio(Math.max(0.75, current - 0.25));
      } else if (fps > 58 && current < this.targetPixelRatio) {
        this.renderer.setPixelRatio(Math.min(this.targetPixelRatio, current + 0.25));
      }
      this.fpsFrames = 0;
      this.fpsTime = 0;
    }

    if (this.state === "playing" && !this.paused) {
      this.updatePlaying(dt);
    } else if (this.state === "menu") {
      this.menuTime += raw;
      this.updateMenu(raw);
    } else if (this.state === "gameover") {
      this.gameOverTime += raw;
      this.updateGameOver(raw);
    }

    if (this.state !== "menu") this.updateEffects(dt);
    if (this.state === "playing") this.updateCamera(raw);
    this.renderer.render(this.scene, this.camera);
  };

  private updateMenu(dt: number) {
    const t = this.menuTime;
    const radius = 23;
    this.camera.position.set(Math.cos(t * 0.12) * radius, 8.5 + Math.sin(t * 0.4) * 0.6, Math.sin(t * 0.12) * radius);
    this.camera.lookAt(0, 2.4, 2);
    for (let i = 0; i < this.menuBots.length; i++) {
      const rig = this.menuBots[i];
      rig.body.position.y = Math.sin(t * 2 + i) * 0.03;
      rig.armR.rotation.x = Math.PI / 2 + Math.sin(t * 1.4 + i) * 0.08;
      rig.armL.rotation.x = Math.PI / 2 + Math.sin(t * 1.4 + i + 1) * 0.08;
      rig.tail.rotation.y = Math.sin(t * 2.4 + i) * 0.35;
      rig.head.rotation.y = Math.sin(t * 0.8 + i * 2) * 0.25;
    }
    void dt;
  }

  private updateGameOver(dt: number) {
    const t = this.gameOverTime;
    const center = this.player.pos;
    const radius = 9 + Math.min(t * 0.6, 4);
    this.camera.position.set(center.x + Math.cos(t * 0.25) * radius, 4.5 + Math.sin(t * 0.4) * 0.4, center.z + Math.sin(t * 0.25) * radius);
    this.camera.lookAt(center.x, 1.4, center.z);
    for (const bot of this.bots) {
      if (!bot.alive) continue;
      bot.rig.group.rotation.y += dt * 0.2;
    }
  }

  private updatePlaying(dt: number) {
    this.timeLeft -= dt;
    if (this.timeLeft <= 0) {
      this.timeLeft = 0;
      this.endMatch("time");
      return;
    }
    if (this.mode === "dm" && this.player.kills >= this.scoreLimit) {
      this.endMatch("score");
      return;
    }
    if (this.mode === "tdm" && (this.teamScores.sun >= this.scoreLimit || this.teamScores.tide >= this.scoreLimit)) {
      this.endMatch("score");
      return;
    }

    this.updatePlayer(dt);
    this.updateBots(dt);
    this.updateVehicles(dt);
    this.updateProjectiles(dt);
    this.updatePickups(dt);
    this.updateFeed();

    this.hudTimer += dt;
    if (this.hudTimer >= 0.1) {
      this.hudTimer = 0;
      this.emitHud();
    }
  }

  /* ---------------------------------------------------------------- */
  /* Player                                                           */
  /* ---------------------------------------------------------------- */

  private updatePlayer(dt: number) {
    const p = this.player;
    if (!p.alive) {
      if (this.time >= p.respawnAt) this.respawnPlayer();
      return;
    }

    // look from touch
    if (this.lookDelta.x !== 0 || this.lookDelta.y !== 0) {
      const sens = 0.0032 * this.settings.sensitivity;
      p.yaw -= this.lookDelta.x * sens;
      p.pitch -= this.lookDelta.y * sens * (this.settings.invertY ? -1 : 1);
      p.pitch = clamp(p.pitch, -0.95, 0.85);
      this.lookDelta.x = 0;
      this.lookDelta.y = 0;
    }

    p.recoil = Math.max(0, p.recoil - dt * 7);
    p.recoilPitch *= Math.exp(-dt * 9);
    p.recoilYaw *= Math.exp(-dt * 9);

    if (p.inVehicle) {
      this.updatePlayerVehicle(dt);
      return;
    }

    const forward = new THREE.Vector3(-Math.sin(p.yaw), 0, -Math.cos(p.yaw));
    const right = new THREE.Vector3(Math.cos(p.yaw), 0, -Math.sin(p.yaw));
    let ix = 0;
    let iy = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) iy += 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) iy -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) ix += 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) ix -= 1;
    ix += this.touchMove.x;
    iy += this.touchMove.y;
    const inputLen = Math.hypot(ix, iy);
    if (inputLen > 1) {
      ix /= inputLen;
      iy /= inputLen;
    }
    const move = new THREE.Vector3().addScaledVector(forward, iy).addScaledVector(right, ix);
    if (move.lengthSq() > 1) move.normalize();

    const crouching = this.keys.has("ShiftLeft") || this.keys.has("ShiftRight") || this.touchCrouch;
    p.crouch = crouching;
    const sprint = Math.min(1, Math.hypot(ix, iy)) > 0.92 && !crouching;
    const targetSpeed = crouching ? 3.8 : sprint ? 10.4 : 8.2;
    const targetVel = move.multiplyScalar(targetSpeed * Math.min(1, Math.hypot(ix, iy) + 0.25));
    const accel = p.grounded ? 16 : 6;
    p.vel.x += (targetVel.x - p.vel.x) * Math.min(1, accel * dt);
    p.vel.z += (targetVel.z - p.vel.z) * Math.min(1, accel * dt);
    p.speed = Math.hypot(p.vel.x, p.vel.z);

    if (this.jumpQueued) {
      this.jumpQueued = false;
      if (p.grounded) {
        p.vel.y = 9.0;
        p.grounded = false;
        audio.play("jump");
        this.spawnBurst(new THREE.Vector3(p.pos.x, 0.1, p.pos.z), 0xe8cfa4, 5, 1.6, 0.7, 0.35);
      }
    }
    p.vel.y -= GRAVITY * dt;
    p.pos.y += p.vel.y * dt;
    if (p.pos.y <= 0) {
      p.pos.y = 0;
      p.vel.y = 0;
      p.grounded = true;
    }

    p.pos.x += p.vel.x * dt;
    p.pos.z += p.vel.z * dt;
    resolveCircle(p.pos, PLAYER_RADIUS, this.obstacles);
    const limit = this.arena.bounds - 1.2;
    p.pos.x = clamp(p.pos.x, -limit, limit);
    p.pos.z = clamp(p.pos.z, -limit, limit);

    // health regen
    if (this.time - p.lastDamage > 6 && p.health < p.maxHealth) {
      p.health = Math.min(p.maxHealth, p.health + 9 * dt);
    }

    // reload finish
    if (p.reloading && this.time >= p.reloadEnd) {
      const def = WEAPONS[p.weaponIndex];
      const state = p.weapons[p.weaponIndex];
      const need = def.mag - state.ammo;
      const take = Math.min(need, state.reserve);
      state.ammo += take;
      state.reserve -= take;
      p.reloading = false;
    }

    // auto reload
    const def = WEAPONS[p.weaponIndex];
    const state = p.weapons[p.weaponIndex];
    if (!p.reloading && state.ammo <= 0 && state.reserve > 0) this.reload();

    p.aim = this.touchAim || this.mouseAim;
    this.updateRig(dt, crouching);
    this.updateWeapon(dt);

    if (this.firing) {
      if (def.auto || this.semiReady) {
        this.tryShoot();
        if (!def.auto) this.semiReady = false;
      }
    }

    if (p.health <= 0) this.killPlayer("Бот");
  }

  private updateRig(dt: number, crouching: boolean) {
    const p = this.player;
    const rig = this.playerRig;
    rig.group.position.set(p.pos.x, p.pos.y, p.pos.z);
    rig.group.rotation.y = p.yaw;
    const targetScale = crouching ? 0.8 : 1;
    rig.group.scale.y += (targetScale - rig.group.scale.y) * Math.min(1, dt * 12);
    rig.group.visible = !p.firstPerson;
    const speedFactor = clamp(p.speed / 7, 0, 1);
    p.walkPhase += dt * (4 + p.speed * 1.4);
    const swing = Math.sin(p.walkPhase) * 0.7 * speedFactor;
    rig.legL.rotation.x = swing;
    rig.legR.rotation.x = -swing;
    rig.body.position.y = Math.abs(Math.sin(p.walkPhase)) * 0.05 * speedFactor + (p.grounded ? 0 : 0.04);
    rig.body.rotation.z = Math.sin(p.walkPhase) * 0.03 * speedFactor;
    const aimPitch = p.pitch;
    rig.armR.rotation.x = Math.PI / 2 + aimPitch * 0.85 - p.recoil * 0.22;
    rig.armL.rotation.x = Math.PI / 2 + aimPitch * 0.8;
    rig.armL.rotation.z = 0.5;
    rig.head.rotation.x = aimPitch * 0.25;
    rig.tail.rotation.y = Math.sin(this.time * 3 + p.walkPhase) * 0.3;
    rig.tail.rotation.x = Math.sin(this.time * 2) * 0.1;
  }

  private updateWeapon(dt: number) {
    const p = this.player;
    const def = WEAPONS[p.weaponIndex];
    const model = this.weaponModels[def.id];
    const view = this.viewModels[def.id];
    const bob = Math.sin(p.walkPhase) * 0.012 * clamp(p.speed / 7, 0, 1);
    view.group.position.set(0.3 + Math.cos(p.walkPhase * 0.5) * 0.008, -0.28 + bob, -0.62 + p.recoil * 0.06);
    view.group.rotation.x = p.recoil * 0.12;
    view.group.visible = p.firstPerson && p.alive;
    model.group.visible = !p.firstPerson;
    if (this.time > p.flashUntil) {
      model.flash.visible = false;
      view.flash.visible = false;
    }
    void dt;
  }

  private currentSpread() {
    const p = this.player;
    const def = WEAPONS[p.weaponIndex];
    const moveFactor = clamp(p.speed / 8, 0, 1) * 0.02;
    const airFactor = p.grounded ? 0 : 0.03;
    const aimFactor = p.aim ? 0.35 : 1;
    return (def.spread + moveFactor + airFactor) * aimFactor;
  }

  private tryShoot() {
    const p = this.player;
    const def = WEAPONS[p.weaponIndex];
    const state = p.weapons[p.weaponIndex];
    if (this.time < p.nextFire || p.reloading || !p.alive) return;
    if (state.ammo <= 0) {
      audio.play("empty");
      p.nextFire = this.time + 0.25;
      return;
    }
    state.ammo--;
    p.shotsFired++;
    p.nextFire = this.time + def.fireRate;
    p.recoil = 1;
    p.recoilPitch += def.id === "sniper" ? 0.035 : def.id === "shotgun" ? 0.028 : 0.012;
    p.recoilYaw += (Math.random() - 0.5) * 0.012;
    this.shake(def.id === "sniper" ? 0.35 : def.id === "shotgun" ? 0.28 : 0.1);
    audio.play(def.id === "pulse" ? "pulse" : def.id === "smg" ? "smg" : def.id === "shotgun" ? "shotgun" : def.id === "sniper" ? "sniper" : def.id === "pistol" ? "pistol" : "rocket");

    const model = this.weaponModels[def.id];
    const view = this.viewModels[def.id];
    const flash = p.firstPerson ? view.flash : model.flash;
    flash.visible = true;
    flash.scale.set(1 + Math.random() * 0.5, 1 + Math.random() * 0.5, 2.4);
    p.flashUntil = this.time + 0.055;
    const muzzlePos = new THREE.Vector3();
    if (p.firstPerson) {
      view.muzzle.getWorldPosition(muzzlePos);
    } else {
      model.muzzle.getWorldPosition(muzzlePos);
    }
    this.muzzleLight.position.copy(muzzlePos);
    this.muzzleLight.intensity = 2.4;

    const camDir = new THREE.Vector3();
    this.camera.getWorldDirection(camDir);
    const origin = this.camera.position.clone();
    const spread = this.currentSpread();

    if (def.projectile) {
      const dir = camDir.clone();
      dir.x += (Math.random() - 0.5) * spread;
      dir.y += (Math.random() - 0.5) * spread;
      dir.z += (Math.random() - 0.5) * spread;
      dir.normalize();
      this.spawnRocket(origin.clone().addScaledVector(dir, 0.8), dir, "player", "sun", def.damage, def.splash ?? 50, 0xffa63c);
      this.spawnBurst(muzzlePos, 0xffd27a, 5, 2.5, 0.8, 0.2);
      return;
    }

    let anyHit = false;
    for (let i = 0; i < def.pellets; i++) {
      const dir = camDir.clone();
      dir.x += (Math.random() - 0.5) * spread * 2;
      dir.y += (Math.random() - 0.5) * spread * 2;
      dir.z += (Math.random() - 0.5) * spread * 2;
      dir.normalize();
      const hit = this.hitscan(origin, dir, def.range, "player", "sun");
      if (hit) {
        anyHit = true;
        this.spawnTracer(muzzlePos, hit.point, def.color);
        if (hit.kind === "bot" && hit.bot) {
          const friendly = this.mode === "tdm" && hit.bot.team === "sun";
          if (!friendly) {
            const headshot = hit.head;
            const dmg = def.damage * (headshot ? 2 : 1);
            this.damageBot(hit.bot, dmg, "player", def.name, hit.point, headshot);
            if (headshot) audio.play("headshot");
            this.spawnBurst(hit.point, headshot ? 0xffd45e : 0xff8a6a, headshot ? 10 : 6, 3.2, 0.8, 0.5);
          } else {
            this.spawnBurst(hit.point, 0x39d6c8, 3, 1.5, 0.5, 0.3);
          }
        } else if (hit.kind === "vehicle" && hit.vehicle) {
          this.damageVehicle(hit.vehicle, def.damage, hit.point, true);
          this.spawnBurst(hit.point, 0xffd27a, 5, 2.4, 0.7, 0.4);
        } else if (hit.kind === "destructible" && hit.destructible) {
          this.damageDestructible(hit.destructible, def.damage, hit.point, true);
          this.spawnBurst(hit.point, hit.destructible.kind === "barrel" ? 0xffb43c : 0xc98a4b, 5, 2.2, 0.7, 0.5);
        } else {
          this.spawnBurst(hit.point, 0xe8cfa4, 4, 1.8, 0.6, 0.4);
        }
      } else {
        const end = origin.clone().addScaledVector(dir, def.range);
        this.spawnTracer(muzzlePos, end, def.color);
      }
    }
    if (anyHit) {
      p.shotsHit++;
      this.callbacks.onEvent({ type: "hit" });
      audio.play("hit");
    }
    this.spawnBurst(muzzlePos, 0xffe6a0, 3, 2.2, 0.7, 0.15);
  }

  private hitscan(origin: THREE.Vector3, dir: THREE.Vector3, range: number, owner: "player" | "bot", team: Team | "none") {
    let bestT = range;
    let result: {
      kind: "bot" | "player" | "vehicle" | "destructible" | "world";
      point: THREE.Vector3;
      bot?: Bot;
      vehicle?: Vehicle;
      destructible?: Destructible;
      head?: boolean;
    } | null = null;

    if (owner === "bot" && this.player.alive && !this.player.inVehicle && !(this.mode === "tdm" && team === "sun")) {
      const bodyCenter = new THREE.Vector3(this.player.pos.x, this.player.pos.y + 1.0, this.player.pos.z);
      const headCenter = new THREE.Vector3(this.player.pos.x, this.player.pos.y + 1.58, this.player.pos.z);
      const tb = raySphere(origin, dir, bodyCenter, 0.5);
      const th = raySphere(origin, dir, headCenter, 0.3);
      const t = th !== null && (tb === null || th < tb) ? th : tb;
      if (t !== null && t < bestT) {
        bestT = t;
        result = { kind: "player", point: origin.clone().addScaledVector(dir, t), head: th !== null && t === th };
      }
    }

    for (const bot of this.bots) {
      if (!bot.alive) continue;
      if (owner === "bot" && bot.team === team && this.mode === "tdm") continue;
      const bodyCenter = new THREE.Vector3(bot.pos.x, bot.pos.y + 1.0, bot.pos.z);
      const headCenter = new THREE.Vector3(bot.pos.x, bot.pos.y + 1.62, bot.pos.z);
      const tb = raySphere(origin, dir, bodyCenter, 0.52);
      const th = raySphere(origin, dir, headCenter, 0.32);
      const t = th !== null && (tb === null || th < tb) ? th : tb;
      if (t !== null && t < bestT) {
        bestT = t;
        result = { kind: "bot", point: origin.clone().addScaledVector(dir, t), bot, head: th !== null && t === th };
      }
    }

    for (const vehicle of this.vehicles) {
      if (!vehicle.alive) continue;
      if (owner === "player" && this.player.inVehicle === vehicle) continue;
      const center = new THREE.Vector3(vehicle.pos.x, 1.0, vehicle.pos.z);
      const t = raySphere(origin, dir, center, 1.45);
      if (t !== null && t < bestT) {
        bestT = t;
        result = { kind: "vehicle", point: origin.clone().addScaledVector(dir, t), vehicle };
      }
    }

    for (const o of this.obstacles) {
      const min = new THREE.Vector3(o.x - o.hw, 0, o.z - o.hd);
      const max = new THREE.Vector3(o.x + o.hw, o.height, o.z + o.hd);
      const t = rayAABB(origin, dir, min, max);
      if (t !== null && t < bestT) {
        bestT = t;
        result = { kind: o.destructible ? "destructible" : "world", point: origin.clone().addScaledVector(dir, t), destructible: o.destructible };
      }
    }

    if (dir.y < -0.0001) {
      const t = -origin.y / dir.y;
      if (t > 0 && t < bestT) {
        bestT = t;
        result = { kind: "world", point: origin.clone().addScaledVector(dir, t) };
      }
    }
    return result;
  }

  private damageBot(bot: Bot, damage: number, attacker: "player" | "bot", weaponName: string, point: THREE.Vector3, headshot = false, attackerBotId = -1) {
    if (!bot.alive) return;
    bot.health -= damage;
    if (bot.rig.healthBar) {
      const frac = clamp(bot.health / 100, 0, 1);
      bot.rig.healthBar.scale.x = frac;
      (bot.rig.healthBar.material as THREE.SpriteMaterial).color.setHex(frac > 0.55 ? 0x4be08a : frac > 0.25 ? 0xffc94a : 0xff5c5c);
    }
    if (attacker === "player") {
      this.addFloat(point, `${Math.round(damage)}${headshot ? "!" : ""}`, headshot ? "#ffd45e" : "#fff8ec", headshot ? 1.2 : 0.9);
    }
    if (bot.health <= 0) this.killBot(bot, attacker, weaponName, attackerBotId);
  }

  private killBot(bot: Bot, attacker: "player" | "bot", weaponName: string, attackerBotId = -1) {
    bot.alive = false;
    bot.health = 0;
    bot.deaths++;
    bot.deadAt = this.time;
    bot.respawnAt = this.time + 3.2;
    bot.rig.healthBar!.visible = false;
    bot.rig.healthBarBg!.visible = false;
    if (bot.rig.tag) bot.rig.tag.visible = false;
    this.spawnBurst(new THREE.Vector3(bot.pos.x, 1.1, bot.pos.z), 0xffd45e, 16, 4.5, 1.1, 0.9);
    this.spawnBurst(new THREE.Vector3(bot.pos.x, 1.0, bot.pos.z), 0x39d6c8, 10, 3.2, 0.9, 0.7);

    if (attacker === "player") {
      const p = this.player;
      p.kills++;
      p.streak++;
      p.bestStreak = Math.max(p.bestStreak, p.streak);
      const bonus = Math.min(100, (p.streak - 1) * 25);
      p.score += 100 + bonus;
      this.addFloat(new THREE.Vector3(bot.pos.x, 2.2, bot.pos.z), `+${100 + bonus}`, "#ffd45e", 1.3);
      this.addFeed(this.nickname, bot.name, weaponName, "sun", bot.team, true);
      audio.play("kill");
      this.callbacks.onEvent({ type: "kill", text: `${bot.name} повержен` });
      this.shake(0.45);
      this.slowmo = 0.07;
      if (p.streak === 3) this.callbacks.onEvent({ type: "streak", text: "ТРОЙНОЕ УНИЧТОЖЕНИЕ!" });
      if (p.streak === 5) this.callbacks.onEvent({ type: "streak", text: "НЕУДЕРЖИМЫЙ!" });
      if (p.streak > 5 && p.streak % 5 === 0) this.callbacks.onEvent({ type: "streak", text: `СЕРИЯ ×${p.streak}` });
      if (Math.random() < 0.4) this.dropPickup(bot.pos, Math.random() > 0.5 ? "health" : "ammo");
    } else {
      const killerBot = this.bots.find((b) => b.id === attackerBotId) ?? null;
      const name = killerBot ? killerBot.name : "Бот";
      if (killerBot) killerBot.kills++;
      this.addFeed(name, bot.name, weaponName, killerBot?.team ?? "none", bot.team, false);
      if (this.mode === "tdm" && killerBot) {
        if (killerBot.team === "sun") this.teamScores.sun++;
        else this.teamScores.tide++;
      }
    }
    if (this.mode === "tdm" && attacker === "player") this.teamScores.sun++;
    this.emitHud();
  }

  private killPlayer(killerName: string, killerTeam: Team | "none" = "none") {
    const p = this.player;
    if (!p.alive) return;
    p.alive = false;
    p.health = 0;
    p.deaths++;
    p.streak = 0;
    p.respawnAt = this.time + 3;
    if (p.inVehicle) {
      p.inVehicle.occupied = false;
      p.inVehicle.speed = 0;
      p.inVehicle = null;
    }
    this.playerRig.group.visible = false;
    if (this.mode === "tdm" && killerTeam === "tide") this.teamScores.tide++;
    if (this.mode === "tdm" && killerTeam === "sun") this.teamScores.sun++;
    this.spawnBurst(new THREE.Vector3(p.pos.x, 1.1, p.pos.z), 0xf28b3c, 20, 5, 1.1, 0.9);
    this.addFeed(killerName, this.nickname, "—", killerTeam, "sun", false);
    audio.play("death");
    this.shake(0.8);
    this.callbacks.onEvent({ type: "toast", text: "Вас вывели из строя. Возрождение...", tone: "bad" });
    this.emitHud();
  }

  private respawnPlayer() {
    const p = this.player;
    const spawns = this.mode === "tdm" ? this.arena.spawns.sun : this.arena.spawns.dm;
    let spawn = spawns[Math.floor(Math.random() * spawns.length)];
    for (let i = 0; i < 10; i++) {
      const candidate = spawns[Math.floor(Math.random() * spawns.length)];
      const nearest = this.bots.reduce((min, b) => (b.alive ? Math.min(min, b.pos.distanceTo(candidate)) : min), 999);
      if (nearest > 18) {
        spawn = candidate;
        break;
      }
    }
    p.pos.copy(spawn);
    p.vel.set(0, 0, 0);
    p.health = p.maxHealth;
    p.armor = 50;
    p.alive = true;
    p.invulnUntil = this.time + 1.6;
    p.weapons = WEAPONS.map((w) => ({ ammo: w.mag, reserve: w.reserve }));
    p.grenades = 3;
    p.reloading = false;
    p.nextFire = 0;
    p.grenadeReadyAt = 0;
    p.yaw = Math.atan2(-(0 - p.pos.x), -(0 - p.pos.z));
    this.playerRig.group.visible = true;
    this.playerRig.group.rotation.set(0, p.yaw, 0);
    this.playerRig.group.scale.set(1, 1, 1);
    this.spawnBurst(new THREE.Vector3(p.pos.x, 1, p.pos.z), 0x39d6c8, 14, 3, 0.9, 0.5);
    this.callbacks.onEvent({ type: "toast", text: "Возрождение! В бой!", tone: "good" });
    this.emitHud();
  }

  private damagePlayer(damage: number, attacker: string, attackerTeam: Team | "none" = "none") {
    const p = this.player;
    if (!p.alive || this.time < p.invulnUntil) return;
    if (p.inVehicle) {
      this.damageVehicle(p.inVehicle, damage, p.inVehicle.pos.clone().setY(1), false);
      return;
    }
    let remaining = damage;
    if (p.armor > 0) {
      const absorbed = Math.min(p.armor, damage * 0.6);
      p.armor -= absorbed;
      remaining -= absorbed;
    }
    p.health -= remaining;
    p.lastDamage = this.time;
    this.shake(0.35);
    audio.play("hurt");
    this.callbacks.onEvent({ type: "damage" });
    if (p.health <= 0) this.killPlayer(attacker, attackerTeam);
    this.emitHud();
  }

  /* ---------------------------------------------------------------- */
  /* Bots                                                             */
  /* ---------------------------------------------------------------- */

  private isEnemy(a: Team | "none", b: Team | "none") {
    if (this.mode === "dm") return true;
    return a !== b;
  }

  private updateBots(dt: number) {
    for (const bot of this.bots) {
      if (!bot.alive) {
        if (this.time >= bot.respawnAt) this.respawnBot(bot);
        else {
          const t = clamp((this.time - bot.deadAt) / 0.7, 0, 1);
          bot.rig.group.rotation.z = t * Math.PI * 0.5;
          bot.rig.group.position.y = -t * 0.25;
          if (t >= 1) bot.rig.group.visible = false;
        }
        continue;
      }
      bot.rig.group.visible = true;
      bot.rig.group.rotation.z = 0;
      bot.rig.group.position.y = 0;

      // target acquisition
      let targetPos: THREE.Vector3 | null = null;
      let targetKind: "player" | "bot" | null = null;
      let targetId = -1;
      let bestDist = 52;
      if (this.player.alive && this.isEnemy(bot.team, "sun")) {
        const d = bot.pos.distanceTo(this.player.pos);
        if (d < bestDist) {
          bestDist = d;
          targetPos = this.player.pos;
          targetKind = "player";
          targetId = -1;
        }
      }
      for (const other of this.bots) {
        if (!other.alive || other.id === bot.id) continue;
        if (!this.isEnemy(bot.team, other.team)) continue;
        const d = bot.pos.distanceTo(other.pos);
        if (d < bestDist) {
          bestDist = d;
          targetPos = other.pos;
          targetKind = "bot";
          targetId = other.id;
        }
      }

      const hadTarget = bot.targetKind !== null;
      bot.targetKind = targetKind;
      bot.targetId = targetId;
      if (targetKind && !hadTarget) bot.reactionUntil = this.time + 0.35 + Math.random() * 0.3;

      let moveTarget: THREE.Vector3 | null = null;
      let speed = 4.6;
      let seekingCover = false;
      if (bot.coverPos && this.time < bot.coverUntil) {
        seekingCover = true;
      } else if (bot.health < 55 && targetPos && this.time > bot.coverUntil) {
        const cover = this.findCover(bot, targetPos);
        if (cover) {
          bot.coverPos = cover;
          bot.coverUntil = this.time + 2.2;
          seekingCover = true;
        }
      }
      if (targetPos && bestDist < 42) {
        const toTarget = new THREE.Vector3().subVectors(targetPos, bot.pos);
        const dist = toTarget.length();
        toTarget.normalize();
        const desiredYaw = Math.atan2(-toTarget.x, -toTarget.z);
        let diff = desiredYaw - bot.yaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        bot.yaw += clamp(diff, -6 * dt, 6 * dt);
        const strafeDir = new THREE.Vector3(-toTarget.z, 0, toTarget.x).multiplyScalar(bot.strafe);
        if (dist > 16) moveTarget = toTarget.clone();
        else if (dist < 5.5) moveTarget = toTarget.clone().multiplyScalar(-1);
        else moveTarget = strafeDir;
        speed = dist > 16 ? 5.6 : 3.6;
        if (Math.random() < dt * 0.35) bot.strafe *= -1;
        bot.aimPitch = Math.atan2(targetPos.y + 1.2 - (bot.pos.y + 1.4), Math.max(1, dist));

        const hasLos = !this.obstacles.some(
          (o) => o.height > 1.25 && segmentHitsBox(bot.pos.x, bot.pos.z, targetPos.x, targetPos.z, o, 0.15)
        );
        if (this.time > bot.nextShot && this.time > bot.reloadUntil && this.time > bot.reactionUntil && bestDist < 38 && hasLos) {
          if (bot.ammo <= 0) {
            bot.reloadUntil = this.time + 1.7;
            bot.ammo = 30;
          } else {
            this.botShoot(bot, targetKind === "player" ? "player" : "bot", targetId, targetPos);
            bot.ammo--;
            bot.burst++;
            bot.nextShot = this.time + 0.16;
            if (bot.burst >= 3 + Math.floor(Math.random() * 3)) {
              bot.burst = 0;
              bot.nextShot = this.time + 0.9 + Math.random() * 0.9;
            }
          }
        }
        if (this.time > bot.grenadeReadyAt && bestDist > 8 && bestDist < 26 && hasLos && Math.random() < dt * 0.4) {
          bot.grenadeReadyAt = this.time + 9 + Math.random() * 7;
          this.botGrenade(bot, targetPos);
        }
      } else {
        if (this.time > bot.wanderUntil || bot.pos.distanceTo(bot.wander) < 1.2) {
          const angle = Math.random() * Math.PI * 2;
          const radius = 10 + Math.random() * 40;
          bot.wander.set(clamp(bot.pos.x + Math.cos(angle) * radius, -this.arena.bounds + 6, this.arena.bounds - 6), 0, clamp(bot.pos.z + Math.sin(angle) * radius, -this.arena.bounds + 6, this.arena.bounds - 6));
          bot.wanderUntil = this.time + 5 + Math.random() * 4;
        }
        moveTarget = bot.wander;
        speed = 4.2;
        const toWander = new THREE.Vector3().subVectors(bot.wander, bot.pos);
        if (toWander.lengthSq() > 0.1) {
          const desiredYaw = Math.atan2(-toWander.x, -toWander.z);
          let diff = desiredYaw - bot.yaw;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          bot.yaw += clamp(diff, -4 * dt, 4 * dt);
        }
        bot.aimPitch *= Math.exp(-dt * 4);
      }

      if (moveTarget) {
        const dir = new THREE.Vector3().subVectors(moveTarget, bot.pos);
        dir.y = 0;
        if (dir.lengthSq() > 0.01) {
          dir.normalize();
          bot.pos.x += dir.x * speed * dt;
          bot.pos.z += dir.z * speed * dt;
        }
      }
      // separation
      for (const other of this.bots) {
        if (other.id === bot.id || !other.alive) continue;
        const dx = bot.pos.x - other.pos.x;
        const dz = bot.pos.z - other.pos.z;
        const d2 = dx * dx + dz * dz;
        if (d2 < 1.2 && d2 > 0.001) {
          const d = Math.sqrt(d2);
          bot.pos.x += (dx / d) * (1.1 - d) * 0.5;
          bot.pos.z += (dz / d) * (1.1 - d) * 0.5;
        }
      }
      resolveCircle(bot.pos, 0.42, this.obstacles);
      bot.pos.x = clamp(bot.pos.x, -this.arena.bounds + 4, this.arena.bounds - 4);
      bot.pos.z = clamp(bot.pos.z, -this.arena.bounds + 4, this.arena.bounds - 4);

      // stuck detection
      if (bot.pos.distanceToSquared(bot.lastPos) < 0.0004) {
        bot.stuckTime += dt;
        if (bot.stuckTime > 1) {
          bot.wander.set(clamp(bot.pos.x + (Math.random() - 0.5) * 22, -this.arena.bounds + 6, this.arena.bounds - 6), 0, clamp(bot.pos.z + (Math.random() - 0.5) * 22, -this.arena.bounds + 6, this.arena.bounds - 6));
          bot.wanderUntil = this.time + 3;
          bot.stuckTime = 0;
          bot.strafe *= -1;
        }
      } else {
        bot.stuckTime = 0;
      }
      bot.lastPos.copy(bot.pos);

      if (seekingCover && bot.coverPos) {
        moveTarget = bot.coverPos;
        speed = 5.8;
      }
      if (bot.coverPos && this.time >= bot.coverUntil) {
        bot.coverPos = null;
      }

      // animate
      const rig = bot.rig;
      rig.group.position.set(bot.pos.x, 0, bot.pos.z);
      rig.group.rotation.y = bot.yaw;
      const moving = moveTarget !== null;
      bot.walkPhase += dt * (moving ? 8 : 2);
      const swing = moving ? Math.sin(bot.walkPhase) * 0.65 : 0;
      rig.legL.rotation.x = swing;
      rig.legR.rotation.x = -swing;
      rig.body.position.y = moving ? Math.abs(Math.sin(bot.walkPhase)) * 0.04 : Math.sin(this.time * 2 + bot.id) * 0.02;
      rig.armR.rotation.x = Math.PI / 2 + bot.aimPitch * 0.8;
      rig.armL.rotation.x = Math.PI / 2 + bot.aimPitch * 0.8;
      rig.armL.rotation.z = 0.5;
      rig.tail.rotation.y = Math.sin(this.time * 3 + bot.id) * 0.3;
      if (rig.tag) {
        rig.tag.visible = bot.pos.distanceTo(this.player.pos) < 38;
        if (rig.healthBar) rig.healthBar.visible = bot.health < 100;
        if (rig.healthBarBg) rig.healthBarBg.visible = bot.health < 100;
      }
      if (this.time > bot.nextShot + 0.12) bot.weapon.flash.visible = false;
    }
  }

  private respawnBot(bot: Bot) {
    const pool = this.mode === "tdm" ? (bot.team === "sun" ? this.arena.spawns.sun : this.arena.spawns.tide) : this.arena.spawns.dm;
    const spawn = pool[Math.floor(Math.random() * pool.length)];
    bot.pos.copy(spawn);
    bot.pos.x += (Math.random() - 0.5) * 2;
    bot.pos.z += (Math.random() - 0.5) * 2;
    bot.health = 100;
    bot.alive = true;
    bot.ammo = 30;
    bot.reloadUntil = 0;
    bot.targetKind = null;
    bot.coverPos = null;
    bot.coverUntil = 0;
    bot.grenadeReadyAt = this.time + 3 + Math.random() * 4;
    bot.rig.group.visible = true;
    bot.rig.group.rotation.set(0, bot.yaw, 0);
    bot.rig.group.position.set(bot.pos.x, 0, bot.pos.z);
    if (bot.rig.healthBar) {
      bot.rig.healthBar.visible = false;
      bot.rig.healthBar.scale.x = 1;
    }
    if (bot.rig.healthBarBg) bot.rig.healthBarBg.visible = false;
    if (bot.rig.tag) bot.rig.tag.visible = true;
    this.spawnBurst(new THREE.Vector3(bot.pos.x, 1, bot.pos.z), bot.team === "tide" ? 0x39d6c8 : 0xffb43c, 10, 2.5, 0.8, 0.4);
  }

  private findCover(bot: Bot, target: THREE.Vector3): THREE.Vector3 | null {
    let best: THREE.Vector3 | null = null;
    let bestDist = 18;
    for (const o of this.obstacles) {
      if (o.height < 1.2) continue;
      const dx = o.x - target.x;
      const dz = o.z - target.z;
      const len = Math.hypot(dx, dz) || 1;
      const px = o.x + (dx / len) * (Math.max(o.hw, o.hd) + 1.5);
      const pz = o.z + (dz / len) * (Math.max(o.hw, o.hd) + 1.5);
      if (Math.abs(px) > this.arena.bounds - 5 || Math.abs(pz) > this.arena.bounds - 5) continue;
      let blocked = false;
      for (const other of this.obstacles) {
        if (px > other.x - other.hw - 0.6 && px < other.x + other.hw + 0.6 && pz > other.z - other.hd - 0.6 && pz < other.z + other.hd + 0.6) {
          blocked = true;
          break;
        }
      }
      if (blocked) continue;
      const d = Math.hypot(px - bot.pos.x, pz - bot.pos.z);
      if (d < bestDist) {
        bestDist = d;
        best = new THREE.Vector3(px, 0, pz);
      }
    }
    return best;
  }

  private botGrenade(bot: Bot, target: THREE.Vector3) {
    const origin = new THREE.Vector3(bot.pos.x, 1.4, bot.pos.z);
    const dir = new THREE.Vector3(target.x - bot.pos.x, 0, target.z - bot.pos.z).normalize();
    const dist = origin.distanceTo(target);
    const group = new THREE.Group();
    group.add(new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), toon(0x4f7a4a)));
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.03, 4, 8), toon(0xffd45e));
    band.rotation.x = Math.PI / 2;
    group.add(band);
    group.position.copy(origin);
    this.scene.add(group);
    this.projectiles.push({
      mesh: group,
      vel: dir.multiplyScalar(Math.min(18, 8 + dist * 0.35)).add(new THREE.Vector3(0, 5.5, 0)),
      life: 1.8,
      damage: 55,
      splash: 55,
      radius: 4.5,
      owner: "bot",
      ownerId: bot.id,
      team: bot.team,
      gravity: 22,
      color: 0xffa63c,
      trail: false,
    });
    if (this.player.pos.distanceTo(bot.pos) < 28) audio.play("throw");
  }

  private botShoot(bot: Bot, targetKind: "player" | "bot", targetId: number, targetPos: THREE.Vector3) {
    const origin = new THREE.Vector3(bot.pos.x, 1.35, bot.pos.z);
    const target = targetKind === "player" ? new THREE.Vector3(this.player.pos.x, 1.1, this.player.pos.z) : new THREE.Vector3(targetPos.x, 1.1, targetPos.z);
    const dir = new THREE.Vector3().subVectors(target, origin).normalize();
    const dist = origin.distanceTo(target);
    const spread = 0.025 + dist * 0.0012;
    dir.x += (Math.random() - 0.5) * spread * 2;
    dir.y += (Math.random() - 0.5) * spread * 2;
    dir.z += (Math.random() - 0.5) * spread * 2;
    dir.normalize();
    const hit = this.hitscan(origin, dir, 60, "bot", bot.team);
    const end = hit ? hit.point : origin.clone().addScaledVector(dir, 60);
    this.spawnTracer(origin, end, bot.team === "tide" ? 0x39d6c8 : 0xffb43c);
    bot.weapon.flash.visible = true;
    bot.weapon.flash.scale.set(1, 1, 2);
    if (hit) {
      if (hit.kind === "player") {
        this.damagePlayer(7, bot.name, bot.team);
      } else if (hit.kind === "bot" && hit.bot) {
        if (this.mode === "dm" || hit.bot.team !== bot.team) {
          this.damageBot(hit.bot, 9, "bot", "выстрел", hit.point, false, bot.id);
        }
      } else if (hit.kind === "destructible" && hit.destructible) {
        this.damageDestructible(hit.destructible, 12, hit.point, false);
      } else if (hit.kind === "vehicle" && hit.vehicle) {
        this.damageVehicle(hit.vehicle, 8, hit.point, false);
      }
    }
    if (this.player.pos.distanceTo(bot.pos) < 24) audio.play("pulse");
    void targetId;
  }

  /* ---------------------------------------------------------------- */
  /* Vehicles                                                         */
  /* ---------------------------------------------------------------- */

  private nearestVehicle() {
    let best: Vehicle | null = null;
    let bestDist = 3.6;
    for (const v of this.vehicles) {
      if (!v.alive || v.occupied) continue;
      const d = Math.hypot(v.pos.x - this.player.pos.x, v.pos.z - this.player.pos.z);
      if (d < bestDist) {
        bestDist = d;
        best = v;
      }
    }
    return best;
  }

  private enterVehicle(vehicle: Vehicle) {
    this.player.inVehicle = vehicle;
    vehicle.occupied = true;
    vehicle.speed = 0;
    this.playerRig.group.visible = false;
    this.player.pos.set(vehicle.pos.x, 0, vehicle.pos.z);
    audio.play("vehicle");
    this.callbacks.onEvent({ type: "toast", text: vehicle.type === "tank" ? "Танк «Толок-1» — в бой!" : "Багги «Песок» — газ в пол!", tone: "good" });
    this.emitHud();
  }

  private exitVehicle() {
    const v = this.player.inVehicle;
    if (!v) return;
    v.occupied = false;
    v.speed = 0;
    const right = new THREE.Vector3(Math.cos(v.yaw), 0, -Math.sin(v.yaw));
    this.player.pos.set(v.pos.x + right.x * 2.2, 0, v.pos.z + right.z * 2.2);
    resolveCircle(this.player.pos, PLAYER_RADIUS, this.obstacles);
    this.player.inVehicle = null;
    this.playerRig.group.visible = true;
    audio.play("click");
    this.emitHud();
  }

  private updatePlayerVehicle(dt: number) {
    const v = this.player.inVehicle;
    if (!v) return;
    if (!v.alive) {
      this.exitVehicle();
      return;
    }
    let throttle = 0;
    let steer = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) throttle += 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) throttle -= 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) steer -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) steer += 1;
    throttle += this.touchMove.y;
    steer += this.touchMove.x;
    throttle = clamp(throttle, -1, 1);
    steer = clamp(steer, -1, 1);
    const maxSpeed = v.type === "tank" ? 14 : 26;
    const accel = v.type === "tank" ? 10 : 18;
    v.speed += throttle * accel * dt;
    v.speed *= Math.exp(-dt * (throttle === 0 ? 1.8 : 0.35));
    v.speed = clamp(v.speed, -maxSpeed * 0.45, maxSpeed);
    if (Math.abs(v.speed) < 0.05) v.speed = 0;
    v.yaw += steer * dt * (v.type === "tank" ? 1.1 : 1.7) * clamp(Math.abs(v.speed) / 6, 0.15, 1) * Math.sign(v.speed || 1);
    const forward = new THREE.Vector3(-Math.sin(v.yaw), 0, -Math.cos(v.yaw));
    const before = v.pos.clone();
    v.pos.addScaledVector(forward, v.speed * dt);
    resolveCircle(v.pos, v.type === "tank" ? 1.7 : 1.35, this.obstacles);
    const limit = this.arena.bounds - 2;
    v.pos.x = clamp(v.pos.x, -limit, limit);
    v.pos.z = clamp(v.pos.z, -limit, limit);
    if (before.distanceToSquared(v.pos) < Math.pow(Math.abs(v.speed) * dt, 2) * 0.4) {
      if (Math.abs(v.speed) > 6) {
        this.shake(0.25);
        this.spawnBurst(new THREE.Vector3(v.pos.x, 0.8, v.pos.z), 0xe8cfa4, 6, 2, 0.8, 0.5);
      }
      v.speed *= -0.2;
    }
    this.player.pos.set(v.pos.x, 0, v.pos.z);
    v.model.group.position.set(v.pos.x, 0, v.pos.z);
    v.model.group.rotation.y = v.yaw;
    v.wheelSpin += v.speed * dt * 2.4;
    for (const wheel of v.model.wheels) wheel.rotation.x = v.wheelSpin;
    if (v.model.turret) {
      const desired = this.player.yaw - v.yaw;
      let diff = desired;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      v.model.turret.rotation.y += clamp(diff, -3 * dt, 3 * dt);
    }
    if (this.firing && this.time > v.nextFire) {
      v.nextFire = this.time + (v.type === "tank" ? 1.15 : 0.11);
      const origin = this.camera.position.clone();
      const dir = new THREE.Vector3();
      this.camera.getWorldDirection(dir);
      if (v.type === "tank") {
        this.spawnRocket(origin.clone().addScaledVector(dir, 1.2), dir, "player", "sun", 70, 70, 0xffa63c);
        this.shake(0.5);
        audio.play("rocket");
      } else {
        const hit = this.hitscan(origin, dir, 90, "player", "sun");
        const end = hit ? hit.point : origin.clone().addScaledVector(dir, 90);
        this.spawnTracer(origin, end, 0xffd45e);
        if (hit?.kind === "bot" && hit.bot) {
          if (!(this.mode === "tdm" && hit.bot.team === "sun")) this.damageBot(hit.bot, 14, "player", "багги", hit.point, false);
        } else if (hit?.kind === "vehicle" && hit.vehicle) this.damageVehicle(hit.vehicle, 14, hit.point, true);
        else if (hit?.kind === "destructible" && hit.destructible) this.damageDestructible(hit.destructible, 14, hit.point, true);
        this.shake(0.08);
        audio.play("pulse");
      }
    }
    this.player.speed = Math.abs(v.speed);
    this.player.walkPhase += dt * Math.abs(v.speed) * 0.4;
    this.player.aim = false;
  }

  private updateVehicles(dt: number) {
    for (const v of this.vehicles) {
      if (!v.alive) {
        if (this.time >= v.respawnAt) {
          v.alive = true;
          v.health = v.maxHealth;
          v.pos.set(v.spawn.x, 0, v.spawn.z);
          v.yaw = v.spawn.yaw;
          v.speed = 0;
          v.model.group.visible = true;
          v.model.group.position.set(v.spawn.x, 0, v.spawn.z);
          v.model.group.rotation.set(0, v.spawn.yaw, 0);
          v.model.group.scale.set(1, 1, 1);
          this.spawnBurst(new THREE.Vector3(v.spawn.x, 1, v.spawn.z), 0x39d6c8, 12, 3, 0.9, 0.4);
        }
        continue;
      }
      if (!v.occupied) {
        v.model.group.position.set(v.pos.x, Math.sin(this.time * 1.5 + v.id) * 0.015, v.pos.z);
        v.model.group.rotation.y = v.yaw;
      }
      if (v.model.flag) v.model.flag.rotation.y = Math.sin(this.time * 3 + v.id) * 0.15;
    }
    void dt;
  }

  private damageVehicle(v: Vehicle, damage: number, point: THREE.Vector3, byPlayer = false) {
    if (!v.alive) return;
    v.health -= damage;
    this.spawnBurst(point, 0xffd27a, 4, 2, 0.6, 0.4);
    if (v.health <= 0) {
      v.alive = false;
      v.health = 0;
      v.occupied = false;
      v.respawnAt = this.time + 14;
      v.model.group.visible = false;
      this.explode(new THREE.Vector3(v.pos.x, 1, v.pos.z), 80, 6, byPlayer ? "player" : "bot", "none", -1);
      if (byPlayer && this.player.inVehicle !== v) {
        this.player.score += 150;
        this.addFloat(new THREE.Vector3(v.pos.x, 2.4, v.pos.z), "+150", "#ffd45e", 1.3);
        this.callbacks.onEvent({ type: "toast", text: "Техника уничтожена! +150", tone: "good" });
      }
      if (this.player.inVehicle === v) {
        this.player.inVehicle = null;
        this.playerRig.group.visible = true;
        this.player.pos.set(v.pos.x + 2, 0, v.pos.z);
        this.damagePlayer(25, "Взрыв");
      }
      this.emitHud();
    }
  }

  /* ---------------------------------------------------------------- */
  /* Projectiles, explosions, grenades                                */
  /* ---------------------------------------------------------------- */

  private spawnRocket(pos: THREE.Vector3, dir: THREE.Vector3, owner: "player" | "bot", team: Team | "none", damage: number, splash: number, color: number, ownerId = -1) {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.3, 3, 6), toon(0x4b5563));
    body.rotation.x = Math.PI / 2;
    group.add(body);
    const glow = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 4), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
    glow.position.z = 0.2;
    group.add(glow);
    group.position.copy(pos);
    group.lookAt(pos.clone().add(dir));
    this.scene.add(group);
    this.projectiles.push({
      mesh: group,
      vel: dir.clone().multiplyScalar(34),
      life: 3,
      damage,
      splash,
      radius: 4.5,
      owner,
      ownerId,
      team,
      gravity: 0,
      color,
      trail: true,
    });
  }

  private throwGrenade(power: number) {
    const p = this.player;
    if (p.grenades <= 0 || !p.alive || this.time < p.grenadeReadyAt) return;
    p.grenades--;
    p.grenadeReadyAt = this.time + 0.8;
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    const pos = this.camera.position.clone().addScaledVector(dir, 0.8);
    const group = new THREE.Group();
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), toon(0x4f7a4a));
    group.add(ball);
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.03, 4, 8), toon(0xffd45e));
    band.rotation.x = Math.PI / 2;
    group.add(band);
    group.position.copy(pos);
    this.scene.add(group);
    this.projectiles.push({
      mesh: group,
      vel: dir.multiplyScalar(9 + power * 10).add(new THREE.Vector3(0, 4.5 + power * 2.5, 0)),
      life: 1.9,
      damage: 95,
      splash: 95,
      radius: 5.2,
      owner: "player",
      ownerId: -1,
      team: "sun",
      gravity: 22,
      color: 0xffa63c,
      trail: false,
    });
    audio.play("throw");
    this.emitHud();
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const proj = this.projectiles[i];
      proj.life -= dt;
      proj.vel.y -= proj.gravity * dt;
      proj.mesh.position.addScaledVector(proj.vel, dt);
      if (proj.trail && Math.random() < 0.7) {
        this.spawnBurst(proj.mesh.position.clone(), proj.color, 1, 0.4, 0.5, 0.05, 0.25);
      }
      let hit = false;
      if (proj.mesh.position.y <= 0.12) hit = true;
      if (!hit) {
        for (const o of this.obstacles) {
          if (
            proj.mesh.position.x > o.x - o.hw &&
            proj.mesh.position.x < o.x + o.hw &&
            proj.mesh.position.z > o.z - o.hd &&
            proj.mesh.position.z < o.z + o.hd &&
            proj.mesh.position.y < o.height
          ) {
            hit = true;
            break;
          }
        }
      }
      if (!hit && proj.owner === "player") {
        for (const bot of this.bots) {
          if (!bot.alive) continue;
          if (proj.mesh.position.distanceTo(new THREE.Vector3(bot.pos.x, 1, bot.pos.z)) < 0.9) {
            hit = true;
            break;
          }
        }
      }
      if (!hit && proj.owner === "bot" && this.player.alive) {
        if (proj.mesh.position.distanceTo(new THREE.Vector3(this.player.pos.x, 1, this.player.pos.z)) < 0.9) hit = true;
      }
      if (hit || proj.life <= 0) {
        this.explode(proj.mesh.position.clone(), proj.damage, proj.radius, proj.owner, proj.team, proj.ownerId);
        this.scene.remove(proj.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  private explode(pos: THREE.Vector3, damage: number, radius: number, owner: "player" | "bot", team: Team | "none", ownerId = -1) {
    this.spawnBurst(pos, 0xffd45e, 18, 7, 1.3, 0.8);
    this.spawnBurst(pos, 0xff7a3c, 14, 5, 1.1, 0.6);
    this.spawnBurst(pos, 0x3b3550, 10, 3, 1.4, -0.2, 1.1);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.6, 0.9, 24),
      new THREE.MeshBasicMaterial({ color: 0xffd45e, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(pos.x, 0.12, pos.z);
    this.scene.add(ring);
    this.rings.push({ mesh: ring, life: 0.55, maxLife: 0.55, grow: 9 });
    const scorch = new THREE.Mesh(new THREE.CircleGeometry(radius * 0.45, 16), new THREE.MeshBasicMaterial({ color: 0x3b2a20, transparent: true, opacity: 0.35, depthWrite: false }));
    scorch.rotation.x = -Math.PI / 2;
    scorch.position.set(pos.x, 0.03, pos.z);
    this.scene.add(scorch);
    window.setTimeout(() => this.scene.remove(scorch), 9000);
    audio.play("explosion");
    const distToPlayer = pos.distanceTo(this.player.pos);
    if (distToPlayer < 22) this.shake(clamp(1 - distToPlayer / 22, 0, 1) * 0.9);
    this.callbacks.onEvent({ type: "explosion" });

    for (const bot of this.bots) {
      if (!bot.alive) continue;
      if (this.mode === "tdm" && bot.team === team) continue;
      const d = Math.hypot(bot.pos.x - pos.x, bot.pos.z - pos.z);
      if (d < radius) {
        const falloff = 1 - d / radius;
        this.damageBot(bot, damage * falloff, owner === "player" ? "player" : "bot", "взрыв", new THREE.Vector3(bot.pos.x, 1.2, bot.pos.z), false, ownerId);
      }
    }
    const friendlyTeam = this.mode === "tdm" && team === "sun";
    if (this.player.alive && owner !== "player" && !friendlyTeam && distToPlayer < radius) {
      this.damagePlayer(damage * (1 - distToPlayer / radius) * 0.8, "Взрыв", team);
    } else if (this.player.alive && owner === "player" && distToPlayer < radius * 0.7) {
      this.damagePlayer(damage * (1 - distToPlayer / (radius * 0.7)) * 0.35, "Свой взрыв", "none");
    }
    for (const v of this.vehicles) {
      if (!v.alive) continue;
      const d = Math.hypot(v.pos.x - pos.x, v.pos.z - pos.z);
      if (d < radius + 1) this.damageVehicle(v, damage * (1 - d / (radius + 1)), pos, owner === "player");
    }
    for (const d of this.arena.destructibles) {
      if (!d.alive) continue;
      const dist = Math.hypot(d.x - pos.x, d.z - pos.z);
      if (dist < radius) this.damageDestructible(d, damage * (1 - dist / radius), new THREE.Vector3(d.x, 0.7, d.z), owner === "player");
    }
    if (owner === "player") {
      this.player.score += 15;
      this.emitHud();
    }
    void team;
  }

  private damageDestructible(d: Destructible, damage: number, point: THREE.Vector3, byPlayer: boolean) {
    if (!d.alive) return;
    d.health -= damage;
    if (d.health > 0) return;
    d.alive = false;
    d.mesh.visible = false;
    if (d.mesh.parent) d.mesh.parent.remove(d.mesh);
    const idx = this.obstacles.indexOf(d.obstacle);
    if (idx >= 0) this.obstacles.splice(idx, 1);
    const color = d.kind === "barrel" ? 0xffb43c : 0xc98a4b;
    this.spawnBurst(point, color, 12, 4, 1, 0.8);
    if (byPlayer) {
      this.player.score += 25;
      this.addFloat(new THREE.Vector3(d.x, 1.4, d.z), "+25", "#ffd45e", 1);
    }
    if (d.explosive) {
      this.explode(new THREE.Vector3(d.x, 0.8, d.z), 70, 5.5, byPlayer ? "player" : "bot", "none", -1);
    }
    if (Math.random() < 0.35) this.dropPickup(new THREE.Vector3(d.x, 0, d.z), Math.random() > 0.5 ? "health" : "ammo");
    this.emitHud();
  }

  /* ---------------------------------------------------------------- */
  /* Pickups                                                          */
  /* ---------------------------------------------------------------- */

  private dropPickup(pos: THREE.Vector3, kind: "health" | "ammo") {
    const mesh = createPickupMesh(kind);
    mesh.position.set(pos.x, 0, pos.z);
    this.scene.add(mesh);
    this.pickups.push({
      mesh,
      kind,
      pos: new THREE.Vector3(pos.x, 0, pos.z),
      active: true,
      respawnAt: 0,
      baseY: 0,
      phase: Math.random() * 6,
      dynamic: true,
    });
  }

  private updatePickups(dt: number) {
    for (const p of this.pickups) {
      if (!p.active) {
        if (p.dynamic) continue;
        if (this.time >= p.respawnAt) {
          p.active = true;
          p.mesh.visible = true;
        }
        continue;
      }
      p.phase += dt;
      p.mesh.position.y = 0.15 + Math.sin(p.phase * 2.2) * 0.12;
      p.mesh.rotation.y += dt * 1.4;
      if (this.player.alive && !this.player.inVehicle) {
        const d = Math.hypot(this.player.pos.x - p.pos.x, this.player.pos.z - p.pos.z);
        if (d < 1.35) {
          p.active = false;
          p.mesh.visible = false;
          p.respawnAt = this.time + 14;
          if (p.kind === "health") {
            this.player.health = Math.min(this.player.maxHealth, this.player.health + 40);
            this.player.armor = Math.min(this.player.maxArmor, this.player.armor + 20);
            this.callbacks.onEvent({ type: "pickup", text: "+40 HP" });
          } else {
            for (const state of this.player.weapons) {
              const def = WEAPONS[this.player.weapons.indexOf(state)];
              state.reserve = Math.min(def.reserve, state.reserve + Math.ceil(def.mag * 1.5));
            }
            this.player.grenades = Math.min(4, this.player.grenades + 1);
            this.callbacks.onEvent({ type: "pickup", text: "Боезапас пополнен" });
          }
          this.player.score += 10;
          audio.play("pickup");
          this.spawnBurst(new THREE.Vector3(p.pos.x, 0.8, p.pos.z), p.kind === "health" ? 0x4be08a : 0xffc94a, 10, 2.5, 0.8, 0.3);
          this.emitHud();
        }
      }
    }
  }

  /* ---------------------------------------------------------------- */
  /* Effects                                                          */
  /* ---------------------------------------------------------------- */

  private shake(amount: number) {
    this.player.recoil = Math.min(1.4, this.player.recoil + amount * 0.35);
    this.shakeAmount = Math.min(1.2, this.shakeAmount + amount);
  }

  private shakeAmount = 0;

  private spawnBurst(pos: THREE.Vector3, color: number, count: number, speed: number, size: number, gravity: number, life = 0.6) {
    let mat = this.particleMats.get(color);
    if (!mat) {
      mat = new THREE.MeshBasicMaterial({ color });
      this.particleMats.set(color, mat);
    }
    for (let i = 0; i < count; i++) {
      if (this.particles.length > this.particleCap) {
        const old = this.particles.shift();
        if (old) this.scene.remove(old.mesh);
      }
      const mesh = new THREE.Mesh(Math.random() > 0.5 ? this.particleGeo : this.debrisGeo, mat);
      mesh.position.copy(pos);
      mesh.position.x += (Math.random() - 0.5) * 0.3;
      mesh.position.y += (Math.random() - 0.5) * 0.3;
      mesh.position.z += (Math.random() - 0.5) * 0.3;
      const s = size * (0.6 + Math.random() * 0.8);
      mesh.scale.setScalar(s);
      this.scene.add(mesh);
      const vel = new THREE.Vector3((Math.random() - 0.5) * speed, Math.random() * speed * 0.8 + 0.5, (Math.random() - 0.5) * speed);
      this.particles.push({
        mesh,
        vel,
        life: life * (0.7 + Math.random() * 0.6),
        maxLife: life,
        gravity,
        spin: (Math.random() - 0.5) * 10,
        shrink: true,
      });
    }
  }

  private spawnTracer(from: THREE.Vector3, to: THREE.Vector3, color: string | number) {
    const hex = new THREE.Color(color).getHex();
    let mat = this.tracerMats.get(hex);
    if (!mat) {
      mat = new THREE.LineBasicMaterial({ color: hex, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
      this.tracerMats.set(hex, mat);
    }
    const geo = new THREE.BufferGeometry().setFromPoints([from, to]);
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);
    this.tracers.push({ line, life: 0.07 });
  }

  private addFloat(pos: THREE.Vector3, text: string, color: string, scale: number) {
    const key = text + color;
    let tex = this.textTexCache.get(key);
    if (!tex) {
      const canvas = document.createElement("canvas");
      canvas.width = 256;
      canvas.height = 128;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.font = "900 64px Rubik, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.lineWidth = 12;
        ctx.strokeStyle = "rgba(30,24,48,0.9)";
        ctx.strokeText(text, 128, 64);
        ctx.fillStyle = color;
        ctx.fillText(text, 128, 64);
      }
      tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      this.textTexCache.set(key, tex);
    }
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest: false }));
    sprite.position.copy(pos);
    sprite.scale.set(1.2 * scale, 0.6 * scale, 1);
    sprite.renderOrder = 30;
    this.scene.add(sprite);
    this.floats.push({ sprite, life: 0.9, maxLife: 0.9, vel: new THREE.Vector3((Math.random() - 0.5) * 0.6, 2.2, 0) });
  }

  private updateEffects(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      p.vel.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (p.mesh.position.y < 0.05) {
        p.mesh.position.y = 0.05;
        p.vel.y *= -0.3;
        p.vel.x *= 0.7;
        p.vel.z *= 0.7;
      }
      p.mesh.rotation.x += p.spin * dt;
      p.mesh.rotation.y += p.spin * dt * 0.7;
      if (p.shrink) {
        const f = clamp(p.life / p.maxLife, 0, 1);
        p.mesh.scale.multiplyScalar(0.965);
        if (f < 0.2) p.mesh.scale.multiplyScalar(0.9);
      }
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      }
    }
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.life -= dt;
      if (t.life <= 0) {
        this.scene.remove(t.line);
        t.line.geometry.dispose();
        this.tracers.splice(i, 1);
      }
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.life -= dt;
      const f = 1 - r.life / r.maxLife;
      r.mesh.scale.setScalar(1 + f * r.grow);
      (r.mesh.material as THREE.MeshBasicMaterial).opacity = 0.9 * (1 - f);
      if (r.life <= 0) {
        this.scene.remove(r.mesh);
        r.mesh.geometry.dispose();
        (r.mesh.material as THREE.Material).dispose();
        this.rings.splice(i, 1);
      }
    }
    for (let i = this.floats.length - 1; i >= 0; i--) {
      const f = this.floats[i];
      f.life -= dt;
      f.sprite.position.addScaledVector(f.vel, dt);
      f.vel.y *= 0.96;
      const mat = f.sprite.material as THREE.SpriteMaterial;
      mat.opacity = clamp(f.life / f.maxLife, 0, 1);
      if (f.life <= 0) {
        this.scene.remove(f.sprite);
        this.floats.splice(i, 1);
      }
    }
    if (this.muzzleLight.intensity > 0) this.muzzleLight.intensity = Math.max(0, this.muzzleLight.intensity - dt * 40);
    this.shakeAmount = Math.max(0, this.shakeAmount - dt * 2.6);
  }

  /* ---------------------------------------------------------------- */
  /* Camera                                                           */
  /* ---------------------------------------------------------------- */

  private updateCamera(dt: number) {
    if (this.state === "menu") return;
    const p = this.player;
    const aim = p.aim;
    const inVehicle = p.inVehicle;
    const target = new THREE.Vector3();
    if (inVehicle) {
      target.set(inVehicle.pos.x, 1.6, inVehicle.pos.z);
    } else {
      target.set(p.pos.x, p.pos.y + (p.crouch ? 1.15 : 1.52), p.pos.z);
    }
    const forward = new THREE.Vector3(
      -Math.sin(p.yaw) * Math.cos(p.pitch + p.recoilPitch),
      Math.sin(p.pitch + p.recoilPitch),
      -Math.cos(p.yaw) * Math.cos(p.pitch + p.recoilPitch)
    );
    const right = new THREE.Vector3(Math.cos(p.yaw), 0, -Math.sin(p.yaw));
    target.addScaledVector(right, inVehicle ? 0 : 0.55);

    if (p.firstPerson && !inVehicle) {
      this.camera.position.set(p.pos.x, p.pos.y + (p.crouch ? 1.15 : 1.58), p.pos.z).addScaledVector(forward, 0.18);
      this.camera.rotation.set(p.pitch + p.recoilPitch, p.yaw + p.recoilYaw, 0, "YXZ");
    } else {
      const dist = inVehicle ? (inVehicle.type === "tank" ? 9.5 : 8) : aim ? 2.3 : 4.5;
      const desired = target.clone().addScaledVector(forward, -dist);
      const safe = this.cameraCollision(target, desired);
      this.camera.position.lerp(safe, 1 - Math.exp(-dt * 14));
      const lookAt = target.clone().addScaledVector(forward, 12);
      this.camera.lookAt(lookAt);
      this.camera.rotation.z += p.recoilYaw * 0.4;
    }

    const shake = this.shakeAmount * 0.16;
    if (shake > 0.001) {
      this.camera.position.x += (Math.random() - 0.5) * shake;
      this.camera.position.y += (Math.random() - 0.5) * shake;
      this.camera.position.z += (Math.random() - 0.5) * shake;
      this.camera.rotation.z += (Math.random() - 0.5) * shake * 0.12;
    }
    const targetFov = p.firstPerson ? 78 : inVehicle ? 76 : aim ? 56 : 72;
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 10);
    this.camera.updateProjectionMatrix();
  }

  private cameraCollision(target: THREE.Vector3, desired: THREE.Vector3) {
    const dir = new THREE.Vector3().subVectors(desired, target);
    const dist = dir.length();
    if (dist < 0.001) return desired;
    dir.normalize();
    let nearest = dist;
    for (const o of this.obstacles) {
      const min = new THREE.Vector3(o.x - o.hw - 0.2, 0, o.z - o.hd - 0.2);
      const max = new THREE.Vector3(o.x + o.hw + 0.2, o.height + 0.2, o.z + o.hd + 0.2);
      const t = rayAABB(target, dir, min, max);
      if (t !== null && t < nearest) nearest = t;
    }
    const safe = target.clone().addScaledVector(dir, Math.max(0.6, nearest - 0.35));
    safe.y = Math.max(0.5, safe.y);
    return safe;
  }

  /* ---------------------------------------------------------------- */
  /* HUD & feed                                                       */
  /* ---------------------------------------------------------------- */

  private addFeed(killer: string, victim: string, weapon: string, killerTeam: Team | "none", victimTeam: Team | "none", isPlayer: boolean) {
    this.killFeed.unshift({ id: this.feedId++, killer, victim, weapon, killerTeam, victimTeam, isPlayer, at: this.time });
    if (this.killFeed.length > 5) this.killFeed.pop();
  }

  private updateFeed() {
    this.killFeed = this.killFeed.filter((f) => this.time - f.at < 6);
  }

  private emitHud() {
    const p = this.player;
    const def = WEAPONS[p.weaponIndex];
    const state = p.weapons[p.weaponIndex];
    const near = p.inVehicle ? null : this.nearestVehicle();
    const blips: HudState["blips"] = [];
    if (p.alive) blips.push({ x: p.pos.x, z: p.pos.z, team: "sun", kind: "player", alive: true });
    for (const b of this.bots) {
      if (!b.alive) continue;
      blips.push({ x: b.pos.x, z: b.pos.z, team: b.team, kind: "bot", alive: true });
    }
    for (const v of this.vehicles) {
      if (!v.alive) continue;
      blips.push({ x: v.pos.x, z: v.pos.z, team: v.team, kind: "vehicle", alive: true });
    }
    for (const pk of this.pickups) {
      if (!pk.active) continue;
      blips.push({ x: pk.pos.x, z: pk.pos.z, team: "none", kind: "pickup", alive: true });
    }
    const hud: HudState = {
      health: Math.max(0, Math.round(p.health)),
      maxHealth: p.maxHealth,
      armor: Math.max(0, Math.round(p.armor)),
      maxArmor: p.maxArmor,
      weapons: WEAPONS.map((w, i) => ({
        id: w.id,
        name: w.name,
        short: w.short,
        ammo: p.weapons[i].ammo,
        reserve: p.weapons[i].reserve,
        reloading: p.reloading && i === p.weaponIndex,
        reloadProgress: p.reloading && i === p.weaponIndex ? clamp(1 - (p.reloadEnd - this.time) / w.reload, 0, 1) : 0,
        color: w.color,
      })),
      weaponIndex: p.weaponIndex,
      grenades: p.grenades,
      score: p.score,
      kills: p.kills,
      deaths: p.deaths,
      streak: p.streak,
      bestStreak: p.bestStreak,
      timeLeft: Math.max(0, this.timeLeft),
      mode: this.mode,
      teamScores: { ...this.teamScores },
      killFeed: this.killFeed.map(({ at, ...rest }) => {
        void at;
        return rest;
      }),
      blips,
      obstacles: this.obstacles.map((o) => ({ x: o.x, z: o.z, w: o.hw * 2, d: o.hd * 2 })),
      scoreboard: [
        { name: this.nickname, team: "sun" as const, kills: p.kills, deaths: p.deaths, isPlayer: true },
        ...this.bots.map((b) => ({ name: b.name, team: b.team, kills: b.kills, deaths: b.deaths, isPlayer: false })),
      ].sort((a, b) => b.kills - a.kills || a.deaths - b.deaths),
      player: { x: p.pos.x, z: p.pos.z, yaw: p.yaw, alive: p.alive, respawnIn: Math.max(0, p.respawnAt - this.time) },
      vehicle: p.inVehicle
        ? { name: p.inVehicle.type === "tank" ? "ТОЛОК-1" : "ПЕСОК", health: Math.max(0, Math.round(p.inVehicle.health)), maxHealth: p.inVehicle.maxHealth, speed: Math.round(Math.abs(p.inVehicle.speed) * 3.6) }
        : null,
      nearVehicle: near ? (near.type === "tank" ? "Танк «Толок-1»" : "Багги «Песок»") : null,
      reloading: p.reloading,
      reloadProgress: p.reloading ? clamp(1 - (p.reloadEnd - this.time) / def.reload, 0, 1) : 0,
      spread: clamp(this.currentSpread() * 14, 0.1, 1),
      aiming: p.aim,
      firstPerson: p.firstPerson,
      crouched: p.crouch,
      scoreLimit: this.scoreLimit,
    };
    void state;
    this.callbacks.onHud(hud);
  }
}
