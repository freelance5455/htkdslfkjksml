import { T } from "./data/areas";

export const TILE = 16;

const mk = (w: number, h: number) => {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  return { c, ctx };
};

function rng(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

interface TileStyle {
  base: string;
  dark: string;
  light: string;
  kind: "noise" | "cobble" | "plank" | "wave" | "grass" | "brick" | "tile";
}

const STYLES: Record<number, TileStyle> = {
  [T.GRASS]: { base: "#3d6b34", dark: "#2f5629", light: "#4d8040", kind: "grass" },
  [T.DIRT]: { base: "#7a5c3c", dark: "#63482e", light: "#8d6c49", kind: "noise" },
  [T.STONE]: { base: "#5f636d", dark: "#4b4f58", light: "#727782", kind: "tile" },
  [T.WOOD]: { base: "#7a5535", dark: "#63452b", light: "#8c6440", kind: "plank" },
  [T.WATER]: { base: "#2b5a80", dark: "#214a6c", light: "#3a72a0", kind: "wave" },
  [T.CARPET]: { base: "#6f1e2a", dark: "#571620", light: "#8a2b39", kind: "noise" },
  [T.MARBLE]: { base: "#ada694", dark: "#99927f", light: "#c4bdab", kind: "tile" },
  [T.ROAD]: { base: "#6a665e", dark: "#54514a", light: "#7f7a70", kind: "cobble" },
  [T.MOSS]: { base: "#37552f", dark: "#2b4425", light: "#456a3b", kind: "noise" },
  [T.DARK]: { base: "#35323d", dark: "#282531", light: "#423e4b", kind: "tile" },
  [T.SAND]: { base: "#b0a077", dark: "#96875f", light: "#c6b78f", kind: "noise" },
  [T.GRAVE]: { base: "#474135", dark: "#38342a", light: "#57503f", kind: "noise" },
  [T.CRYPT]: { base: "#332e3a", dark: "#26232d", light: "#413b4a", kind: "tile" },
  [T.WALL_STONE]: { base: "#4a4f5a", dark: "#383c45", light: "#5d636f", kind: "brick" },
  [T.WALL_WOOD]: { base: "#5a4026", dark: "#452f1b", light: "#6e5033", kind: "plank" },
  [T.HEDGE]: { base: "#2e5128", dark: "#23401f", light: "#3d6633", kind: "noise" },
  [T.TREE]: { base: "#24502a", dark: "#1a3a1f", light: "#336638", kind: "noise" },
  [T.ROCK]: { base: "#585860", dark: "#454550", light: "#6c6c76", kind: "noise" },
  [T.BLOCK]: { base: "#39373f", dark: "#2a282f", light: "#474550", kind: "tile" },
};

const tileCache = new Map<number, HTMLCanvasElement[]>();

export function getTileArt(t: number): HTMLCanvasElement[] {
  const cached = tileCache.get(t);
  if (cached) return cached;
  const st = STYLES[t] ?? STYLES[T.STONE];
  const variants: HTMLCanvasElement[] = [];
  for (let v = 0; v < 4; v++) {
    const { c, ctx } = mk(TILE, TILE);
    const r = rng(t * 977 + v * 31 + 7);
    ctx.fillStyle = st.base;
    ctx.fillRect(0, 0, TILE, TILE);
    if (st.kind === "grass") {
      for (let i = 0; i < 14; i++) {
        ctx.fillStyle = r() > 0.5 ? st.dark : st.light;
        ctx.fillRect(Math.floor(r() * TILE), Math.floor(r() * TILE), 1, 2);
      }
    } else if (st.kind === "noise") {
      for (let i = 0; i < 20; i++) {
        ctx.fillStyle = r() > 0.5 ? st.dark : st.light;
        ctx.fillRect(Math.floor(r() * TILE), Math.floor(r() * TILE), 1, 1);
      }
    } else if (st.kind === "tile") {
      ctx.fillStyle = st.dark;
      ctx.fillRect(0, 0, TILE, 1);
      ctx.fillRect(0, 0, 1, TILE);
      for (let i = 0; i < 5; i++) {
        ctx.fillStyle = st.light;
        ctx.fillRect(Math.floor(r() * TILE), Math.floor(r() * TILE), 1, 1);
      }
    } else if (st.kind === "cobble") {
      for (let y = 0; y < TILE; y += 4) {
        for (let x = 0; x < TILE; x += 4) {
          ctx.fillStyle = r() > 0.5 ? st.light : st.base;
          ctx.fillRect(x + 1, y + 1, 3, 3);
          ctx.fillStyle = st.dark;
          ctx.fillRect(x + 1, y + 3, 3, 1);
        }
      }
    } else if (st.kind === "plank") {
      for (let y = 0; y < TILE; y += 5) {
        ctx.fillStyle = st.dark;
        ctx.fillRect(0, y, TILE, 1);
        ctx.fillRect(Math.floor(r() * TILE), y, 1, 5);
      }
    } else if (st.kind === "wave") {
      for (let i = 0; i < 4; i++) {
        ctx.fillStyle = st.light;
        ctx.fillRect(Math.floor(r() * 8), Math.floor(r() * TILE), 4, 1);
      }
    } else if (st.kind === "brick") {
      ctx.fillStyle = st.dark;
      for (let y = 0; y < TILE; y += 4) ctx.fillRect(0, y, TILE, 1);
      for (let y = 0; y < TILE; y += 8) {
        ctx.fillRect(0, y + 4, TILE, 1);
      }
      for (let i = 0; i < 6; i++) {
        ctx.fillStyle = st.light;
        ctx.fillRect(Math.floor(r() * TILE), Math.floor(r() * TILE), 1, 1);
      }
    }
    if (t === T.TREE) {
      ctx.fillStyle = "#3b2a18";
      ctx.fillRect(7, 11, 2, 5);
      ctx.fillStyle = "#1d3f22";
      ctx.fillRect(3, 4, 10, 8);
      ctx.fillStyle = "#2b5a31";
      ctx.fillRect(4, 5, 8, 6);
      ctx.fillStyle = "#39703f";
      ctx.fillRect(5, 4, 4, 2);
    }
    if (t === T.HEDGE) {
      ctx.fillStyle = "#1f3a1c";
      ctx.fillRect(0, 12, TILE, 4);
    }
    variants.push(c);
  }
  tileCache.set(t, variants);
  return variants;
}

/* ------------------------------ characters ------------------------------ */

export interface CharOpts {
  skin: string;
  hair: string;
  cloth: string;
  accent: string;
  dir: "up" | "down" | "left" | "right";
  frame: number;
  crown?: boolean;
  hood?: boolean;
  cape?: boolean;
}

const spriteCache = new Map<string, HTMLCanvasElement>();

export function getCharacterSprite(o: CharOpts): HTMLCanvasElement {
  const key = `${o.skin}|${o.hair}|${o.cloth}|${o.accent}|${o.dir}|${o.frame}|${o.crown ? 1 : 0}|${o.hood ? 1 : 0}|${o.cape ? 1 : 0}`;
  const hit = spriteCache.get(key);
  if (hit) return hit;
  const { c, ctx } = mk(12, 20);
  const bob = o.frame === 1 || o.frame === 3 ? 1 : 0;
  const legA = o.frame === 0 || o.frame === 3 ? 0 : 1;
  const legB = o.frame === 0 || o.frame === 3 ? 1 : 0;
  const up = o.dir === "up";
  const side = o.dir === "left" || o.dir === "right";

  // shadow
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.fillRect(2, 18, 8, 2);

  // legs
  ctx.fillStyle = shade(o.cloth, -0.45);
  ctx.fillRect(3 + legA, 15 + bob, 2, 4);
  ctx.fillRect(7 - legB, 15 + bob, 2, 4);
  ctx.fillStyle = "#2a2118";
  ctx.fillRect(3 + legA, 18 + bob, 2, 1);
  ctx.fillRect(7 - legB, 18 + bob, 2, 1);

  // cape / body back
  if (o.cape) {
    ctx.fillStyle = shade(o.accent, -0.25);
    ctx.fillRect(1, 8 + bob, 10, 8);
  }

  // torso
  ctx.fillStyle = o.cloth;
  ctx.fillRect(3, 8 + bob, 6, 7);
  ctx.fillStyle = shade(o.cloth, -0.2);
  ctx.fillRect(3, 12 + bob, 6, 3);
  // belt
  ctx.fillStyle = o.accent;
  ctx.fillRect(3, 12 + bob, 6, 1);

  // arms
  ctx.fillStyle = shade(o.cloth, 0.12);
  ctx.fillRect(2, 9 + bob, 1, 5);
  ctx.fillRect(9, 9 + bob, 1, 5);
  ctx.fillStyle = o.skin;
  ctx.fillRect(2, 13 + bob, 1, 1);
  ctx.fillRect(9, 13 + bob, 1, 1);

  // head
  ctx.fillStyle = o.skin;
  ctx.fillRect(3, 2 + bob, 6, 6);
  ctx.fillStyle = shade(o.skin, -0.25);
  ctx.fillRect(3, 6 + bob, 6, 2);

  if (o.hood) {
    ctx.fillStyle = shade(o.cloth, -0.15);
    ctx.fillRect(2, 1 + bob, 8, 6);
    ctx.fillStyle = shade(o.cloth, 0.05);
    ctx.fillRect(3, 1 + bob, 6, 2);
    if (!up) {
      ctx.fillStyle = "#15131a";
      ctx.fillRect(4, 4 + bob, 4, 3);
    }
  } else {
    ctx.fillStyle = o.hair;
    ctx.fillRect(2, 1 + bob, 8, 2);
    ctx.fillRect(2, 1 + bob, 2, 4);
    ctx.fillRect(8, 1 + bob, 2, 4);
    if (up) {
      ctx.fillRect(2, 1 + bob, 8, 7);
      ctx.fillStyle = shade(o.hair, -0.15);
      ctx.fillRect(3, 4 + bob, 6, 4);
    }
  }

  // face
  if (!o.hood && !up) {
    ctx.fillStyle = "#20181a";
    if (side) {
      ctx.fillRect(o.dir === "left" ? 4 : 7, 4 + bob, 1, 1);
      ctx.fillRect(o.dir === "left" ? 6 : 5, 6 + bob, 1, 1);
    } else {
      ctx.fillRect(4, 4 + bob, 1, 1);
      ctx.fillRect(7, 4 + bob, 1, 1);
      ctx.fillRect(5, 6 + bob, 2, 1);
    }
  }

  if (o.crown) {
    ctx.fillStyle = "#f0c14b";
    ctx.fillRect(2, 0 + bob, 8, 2);
    ctx.fillRect(2, 0 + bob, 1, 2);
    ctx.fillRect(5, -1 + bob, 2, 2);
    ctx.fillRect(9, 0 + bob, 1, 2);
    ctx.fillStyle = "#e0554a";
    ctx.fillRect(5, 0 + bob, 2, 1);
  }

  spriteCache.set(key, c);
  return c;
}

export function shade(hex: string, amt: number): string {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((x) => x + x).join("") : h, 16);
  let r = (n >> 16) & 255,
    g = (n >> 8) & 255,
    b = n & 255;
  r = Math.max(0, Math.min(255, Math.round(r + 255 * amt)));
  g = Math.max(0, Math.min(255, Math.round(g + 255 * amt)));
  b = Math.max(0, Math.min(255, Math.round(b + 255 * amt)));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

/* -------------------------------- portraits ----------------------------- */

export function drawPortrait(
  ctx: CanvasRenderingContext2D,
  p: { skin: string; hair: string; cloth: string; accent: string },
  w: number,
  h: number,
  crown?: boolean,
  hood?: boolean
) {
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, "#241b2e");
  bg.addColorStop(1, "#120e18");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  const r = rng(p.hair.charCodeAt(1) * 31 + p.skin.charCodeAt(2));
  for (let i = 0; i < 40; i++) {
    ctx.fillStyle = `rgba(255,220,180,${0.02 + r() * 0.04})`;
    ctx.fillRect(Math.floor(r() * w), Math.floor(r() * h), 1, 1);
  }
  const s = Math.min(w / 32, h / 32);
  ctx.translate(w / 2 - 16 * s, h * 0.16);
  ctx.scale(s, s);

  // shoulders
  ctx.fillStyle = p.cloth;
  ctx.fillRect(2, 26, 28, 10);
  ctx.fillStyle = shade(p.cloth, -0.2);
  ctx.fillRect(2, 32, 28, 4);
  ctx.fillStyle = p.accent;
  ctx.fillRect(13, 26, 6, 8);

  // neck
  ctx.fillStyle = shade(p.skin, -0.2);
  ctx.fillRect(13, 22, 6, 5);

  // face
  ctx.fillStyle = p.skin;
  ctx.fillRect(8, 6, 16, 17);
  ctx.fillStyle = shade(p.skin, -0.18);
  ctx.fillRect(8, 19, 16, 4);
  ctx.fillStyle = shade(p.skin, 0.1);
  ctx.fillRect(9, 7, 5, 8);

  // hair
  ctx.fillStyle = p.hair;
  ctx.fillRect(6, 2, 20, 7);
  ctx.fillRect(6, 4, 3, 10);
  ctx.fillRect(23, 4, 3, 10);
  ctx.fillStyle = shade(p.hair, 0.15);
  ctx.fillRect(9, 2, 8, 2);

  // eyes
  ctx.fillStyle = "#20181a";
  ctx.fillRect(11, 12, 2, 2);
  ctx.fillRect(19, 12, 2, 2);
  ctx.fillStyle = "#f4efe6";
  ctx.fillRect(11, 12, 1, 1);
  ctx.fillRect(19, 12, 1, 1);
  // mouth
  ctx.fillStyle = shade(p.skin, -0.45);
  ctx.fillRect(13, 17, 6, 1);
  // brows
  ctx.fillStyle = shade(p.hair, -0.2);
  ctx.fillRect(10, 10, 4, 1);
  ctx.fillRect(18, 10, 4, 1);

  if (crown) {
    ctx.fillStyle = "#f0c14b";
    ctx.fillRect(7, -2, 18, 4);
    ctx.fillRect(7, -2, 2, 4);
    ctx.fillRect(15, -5, 3, 5);
    ctx.fillRect(23, -2, 2, 4);
    ctx.fillStyle = "#e0554a";
    ctx.fillRect(15, -2, 3, 2);
  }
  if (hood) {
    ctx.fillStyle = shade(p.cloth, -0.1);
    ctx.fillRect(5, 0, 22, 12);
    ctx.fillStyle = shade(p.cloth, 0.08);
    ctx.fillRect(7, 0, 18, 3);
    ctx.fillStyle = "#15131a";
    ctx.fillRect(10, 10, 12, 9);
  }
  ctx.restore();
}
