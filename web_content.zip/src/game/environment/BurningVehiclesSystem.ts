import * as THREE from 'three';

export interface BurningVehicle {
  group: THREE.Group;
  light: THREE.PointLight;
  flameMesh: THREE.Mesh;
  smokeMesh: THREE.Mesh;
  baseLightIntensity: number;
}

export class BurningVehiclesSystem {
  private scene: THREE.Scene;
  private vehicles: BurningVehicle[] = [];

  // Reusable materials
  private bodyCharredMat: THREE.MeshStandardMaterial;
  private glassCharredMat: THREE.MeshStandardMaterial;
  private tireMat: THREE.MeshStandardMaterial;
  private rimMat: THREE.MeshStandardMaterial;
  private flameMat: THREE.MeshBasicMaterial;
  private smokeMat: THREE.MeshBasicMaterial;

  constructor(scene: THREE.Scene) {
    this.scene = scene;

    this.bodyCharredMat = new THREE.MeshStandardMaterial({
      color: 0x27272a,
      roughness: 0.85,
      metalness: 0.2,
    });

    this.glassCharredMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      roughness: 0.3,
      metalness: 0.8,
      transparent: true,
      opacity: 0.75,
    });

    this.tireMat = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.9,
    });

    this.rimMat = new THREE.MeshStandardMaterial({
      color: 0x52525b,
      metalness: 0.8,
      roughness: 0.3,
    });

    this.flameMat = new THREE.MeshBasicMaterial({
      color: 0xf97316,
      transparent: true,
      opacity: 0.85,
    });

    this.smokeMat = new THREE.MeshBasicMaterial({
      color: 0x1f2937,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
  }

  clear() {
    for (let i = 0; i < this.vehicles.length; i++) {
      this.scene.remove(this.vehicles[i].group);
    }
    this.vehicles = [];
  }

  // Construct recognizable detailed vehicle model (Requirement 9 & 10)
  addBurningEffect(x: number, y: number, z: number, rotY: number = 0) {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;

    // 1. Lower Chassis & Wheel Wells
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.5, 4.4), this.bodyCharredMat);
    chassis.position.y = 0.5;
    chassis.castShadow = true;
    group.add(chassis);

    // 2. Hood / Engine Compartment
    const hood = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.4, 1.4), this.bodyCharredMat);
    hood.position.set(0, 0.8, -1.3);
    hood.castShadow = true;
    group.add(hood);

    // Front Grille & Headlights
    const grille = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.25, 0.08), new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.5 }));
    grille.position.set(0, 0.75, -2.02);
    group.add(grille);

    const headlightMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.2 });
    [-0.7, 0.7].forEach(hx => {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.18, 0.08), headlightMat);
      hl.position.set(hx, 0.78, -2.01);
      group.add(hl);
    });

    // 3. Passenger Cabin with Roof & Windows
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.65, 1.8), this.bodyCharredMat);
    cabin.position.set(0, 1.15, 0.1);
    cabin.castShadow = true;
    group.add(cabin);

    // Windshield (sloped plane)
    const windshield = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 0.65), this.glassCharredMat);
    windshield.position.set(0, 1.15, -0.81);
    windshield.rotation.x = -Math.PI / 6;
    group.add(windshield);

    // Rear Window
    const rearWindow = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 0.6), this.glassCharredMat);
    rearWindow.position.set(0, 1.15, 1.01);
    rearWindow.rotation.x = Math.PI / 6;
    rearWindow.rotation.y = Math.PI;
    group.add(rearWindow);

    // Side Windows
    [-0.93, 0.93].forEach(wx => {
      const sideGlass = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.45), this.glassCharredMat);
      sideGlass.position.set(wx, 1.15, 0.1);
      sideGlass.rotation.y = wx > 0 ? Math.PI / 2 : -Math.PI / 2;
      group.add(sideGlass);
    });

    // 4. Rear Trunk
    const trunk = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.4, 1.1), this.bodyCharredMat);
    trunk.position.set(0, 0.8, 1.55);
    trunk.castShadow = true;
    group.add(trunk);

    // Taillights
    const tailMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.3 });
    [-0.7, 0.7].forEach(tx => {
      const tl = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.16, 0.08), tailMat);
      tl.position.set(tx, 0.75, 2.11);
      group.add(tl);
    });

    // 5. 4 Cylindrical Rubber Wheels with Rims
    const wheelPositions = [
      [-1.05, 0.4, -1.3],
      [1.05, 0.4, -1.3],
      [-1.05, 0.4, 1.3],
      [1.05, 0.4, 1.3],
    ];

    const wheelGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.32, 10);
    wheelGeo.rotateZ(Math.PI / 2);

    wheelPositions.forEach(([wx, wy, wz]) => {
      const tire = new THREE.Mesh(wheelGeo, this.tireMat);
      tire.position.set(wx, wy, wz);
      tire.castShadow = true;
      group.add(tire);

      // Metal rim hub
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.33, 8), this.rimMat);
      rim.position.set(wx, wy, wz);
      rim.rotation.z = Math.PI / 2;
      group.add(rim);
    });

    // 6. Realistic Multi-Layer Animated Fire on Hood & Engine
    const flameGeo = new THREE.ConeGeometry(0.65, 1.6, 6);
    const flameMesh = new THREE.Mesh(flameGeo, this.flameMat.clone());
    flameMesh.position.set(0, 1.4, -1.1);
    group.add(flameMesh);

    // Inner bright yellow flame core
    const coreGeo = new THREE.ConeGeometry(0.35, 1.0, 5);
    const coreMesh = new THREE.Mesh(coreGeo, new THREE.MeshBasicMaterial({ color: 0xfef08a }));
    coreMesh.position.set(0, 1.1, -1.1);
    group.add(coreMesh);

    // 7. Billowing Smoke Puff
    const smokeGeo = new THREE.DodecahedronGeometry(0.85, 0);
    const smokeMesh = new THREE.Mesh(smokeGeo, this.smokeMat.clone());
    smokeMesh.position.set(0, 2.4, -1.0);
    group.add(smokeMesh);

    // 8. Flickering Fire Light
    const light = new THREE.PointLight(0xf97316, 2.6, 15);
    light.position.set(0, 1.8, -1.1);
    group.add(light);

    this.scene.add(group);

    this.vehicles.push({
      group,
      light,
      flameMesh,
      smokeMesh,
      baseLightIntensity: 2.6,
    });
  }

  update(delta: number) {
    const now = performance.now() * 0.001;

    for (let i = 0; i < this.vehicles.length; i++) {
      const v = this.vehicles[i];

      // Organic flame flicker
      const flicker = Math.sin(now * 12 + i) * 0.5 + Math.cos(now * 18 + i * 2) * 0.3;
      v.light.intensity = Math.max(1.2, v.baseLightIntensity + flicker);

      // Animate flame shape & rotation
      v.flameMesh.scale.set(
        1.0 + Math.sin(now * 8 + i) * 0.18,
        1.0 + Math.cos(now * 10 + i) * 0.22,
        1.0 + Math.sin(now * 7 + i) * 0.18
      );
      v.flameMesh.rotation.y += delta * 1.6;

      // Animate smoke rise and expansion
      v.smokeMesh.position.y += delta * 0.7;
      v.smokeMesh.scale.addScalar(delta * 0.25);
      if (v.smokeMesh.position.y > 4.2) {
        v.smokeMesh.position.y = 2.4;
        v.smokeMesh.scale.setScalar(1.0);
      }
    }
  }
}
