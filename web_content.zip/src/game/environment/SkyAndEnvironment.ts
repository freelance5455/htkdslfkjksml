import * as THREE from 'three';
import { TimeOfDay, QualityPreset } from '../core/GameEngine';

export class SkyAndEnvironment {
  private scene: THREE.Scene;

  // Celestial Sky Dome
  private skyDome: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;

  // Stars Particle Field for Night
  private starsPoints: THREE.Points;

  // Horizon Ground Ring (so camera never looks off the map into empty space)
  private horizonRing: THREE.Mesh;

  // Celestial Bodies
  public sunMesh: THREE.Mesh;
  public sunGlow: THREE.Mesh;
  public moonMesh: THREE.Mesh;
  public moonGlow: THREE.Mesh;

  // Animated Cloud Puffs
  private cloudsGroup: THREE.Group;
  private cloudMeshes: THREE.Mesh[] = [];

  // Volumetric Celestial Rays
  public rayMesh: THREE.Mesh;
  private rayMat: THREE.MeshBasicMaterial;

  constructor(scene: THREE.Scene) {
    this.scene = scene;

    // 1. Expansive 3D Sky Dome (Radius 450m) with atmospheric gradient shader
    const skyGeo = new THREE.SphereGeometry(450, 24, 16);
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        topColor: { value: new THREE.Color(0x1e3a8a) }, // Zenith
        bottomColor: { value: new THREE.Color(0x60a5fa) }, // Horizon
        offset: { value: 15 },
        exponent: { value: 0.6 },
      },
      vertexShader: `
        varying vec3 vWorldPosition;
        void main() {
          vec4 worldPosition = modelMatrix * vec4(position, 1.0);
          vWorldPosition = worldPosition.xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 bottomColor;
        uniform float offset;
        uniform float exponent;
        varying vec3 vWorldPosition;
        void main() {
          float h = normalize(vWorldPosition + offset).y;
          gl_FragColor = vec4(mix(bottomColor, topColor, max(pow(max(h, 0.0), exponent), 0.0)), 1.0);
        }
      `,
      side: THREE.BackSide,
      depthWrite: false,
    });
    this.skyDome = new THREE.Mesh(skyGeo, this.skyMat);
    this.scene.add(this.skyDome);

    // 2. Stars Particle Field for Night
    const starCount = 400;
    const starGeo = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 420;
      starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = Math.abs(r * Math.cos(phi)) + 15; // Above horizon
      starPositions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1.8,
      transparent: true,
      opacity: 0.8,
      sizeAttenuation: false,
    });
    this.starsPoints = new THREE.Points(starGeo, starMat);
    this.starsPoints.visible = false;
    this.scene.add(this.starsPoints);

    // 3. Massive Distant Horizon Ground Ring (Radius 500m)
    // Prevents looking off the 120m map edge into a black void
    const ringGeo = new THREE.RingGeometry(55, 480, 24);
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0x1f2937,
      roughness: 0.95,
      metalness: 0.05,
    });
    this.horizonRing = new THREE.Mesh(ringGeo, ringMat);
    this.horizonRing.rotation.x = -Math.PI / 2;
    this.horizonRing.position.y = -0.15;
    this.horizonRing.receiveShadow = false;
    this.scene.add(this.horizonRing);

    // 4. Sun Mesh & Glowing Corona
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xfffbeb });
    this.sunMesh = new THREE.Mesh(new THREE.SphereGeometry(6, 16, 16), sunMat);
    this.sunMesh.position.set(50, 70, 40);
    this.scene.add(this.sunMesh);

    const sunGlowMat = new THREE.MeshBasicMaterial({
      color: 0xfdba74,
      transparent: true,
      opacity: 0.5,
      side: THREE.BackSide,
    });
    this.sunGlow = new THREE.Mesh(new THREE.SphereGeometry(12, 16, 16), sunGlowMat);
    this.sunMesh.add(this.sunGlow);

    // 5. Moon Mesh & Halo
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xf1f5f9 });
    this.moonMesh = new THREE.Mesh(new THREE.SphereGeometry(5.5, 16, 16), moonMat);
    this.moonMesh.position.set(-45, 65, -40);
    this.scene.add(this.moonMesh);

    const moonGlowMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
      side: THREE.BackSide,
    });
    this.moonGlow = new THREE.Mesh(new THREE.SphereGeometry(10, 16, 16), moonGlowMat);
    this.moonMesh.add(this.moonGlow);

    // 6. Volumetric Celestial Rays
    this.rayMat = new THREE.MeshBasicMaterial({
      color: 0xffedd5,
      transparent: true,
      opacity: 0.2,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const rayGeo = new THREE.ConeGeometry(40, 120, 16, 1, true);
    rayGeo.rotateX(-Math.PI / 2);
    this.rayMesh = new THREE.Mesh(rayGeo, this.rayMat);
    this.rayMesh.position.copy(this.sunMesh.position);
    this.rayMesh.lookAt(0, 0, 0);
    this.scene.add(this.rayMesh);

    // 7. Drifting Clouds Group
    this.cloudsGroup = new THREE.Group();
    this.initClouds();
    this.scene.add(this.cloudsGroup);
  }

  private initClouds() {
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.95,
      transparent: true,
      opacity: 0.7,
      depthWrite: false,
    });

    const puffGeo = new THREE.DodecahedronGeometry(1.2, 0);

    for (let c = 0; c < 20; c++) {
      const cloudPuff = new THREE.Mesh(puffGeo, cloudMat);
      const cx = (Math.random() - 0.5) * 140;
      const cy = 36 + Math.random() * 12;
      const cz = (Math.random() - 0.5) * 140;

      cloudPuff.position.set(cx, cy, cz);
      const s = 7 + Math.random() * 9;
      cloudPuff.scale.set(s * 2.0, s * 0.5, s * 1.3);
      this.cloudsGroup.add(cloudPuff);
      this.cloudMeshes.push(cloudPuff);
    }
  }

  setTimeOfDay(time: TimeOfDay) {
    if (time === 'day') {
      // Sky blue gradient
      this.skyMat.uniforms.topColor.value.setHex(0x0284c7); // Deep sky blue
      this.skyMat.uniforms.bottomColor.value.setHex(0xbae6fd); // Light horizon cyan
      this.starsPoints.visible = false;

      this.sunMesh.visible = true;
      this.moonMesh.visible = false;
      this.sunMesh.position.set(50, 75, 40);
      this.rayMesh.position.copy(this.sunMesh.position);
      this.rayMesh.lookAt(0, 0, 0);
      this.rayMat.color.setHex(0xffedd5);
      this.rayMat.opacity = 0.22;

      (this.horizonRing.material as THREE.MeshStandardMaterial).color.setHex(0x334155);
    } else if (time === 'evening') {
      // Sunset gradient: deep purple/indigo to golden orange
      this.skyMat.uniforms.topColor.value.setHex(0x312e81); // Deep indigo
      this.skyMat.uniforms.bottomColor.value.setHex(0xf97316); // Sunset orange
      this.starsPoints.visible = false;

      this.sunMesh.visible = true;
      this.moonMesh.visible = false;
      this.sunMesh.position.set(65, 30, 45);
      this.rayMesh.position.copy(this.sunMesh.position);
      this.rayMesh.lookAt(0, 0, 0);
      this.rayMat.color.setHex(0xf97316);
      this.rayMat.opacity = 0.25;

      (this.horizonRing.material as THREE.MeshStandardMaterial).color.setHex(0x1c1917);
    } else {
      // Night: deep midnight navy to moonlit haze
      this.skyMat.uniforms.topColor.value.setHex(0x0b1120); // Deep midnight navy
      this.skyMat.uniforms.bottomColor.value.setHex(0x1e293b); // Moonlit horizon
      this.starsPoints.visible = true;

      this.sunMesh.visible = false;
      this.moonMesh.visible = true;
      this.moonMesh.position.set(-50, 70, -45);
      this.rayMesh.position.copy(this.moonMesh.position);
      this.rayMesh.lookAt(0, 0, 0);
      this.rayMat.color.setHex(0x60a5fa);
      this.rayMat.opacity = 0.18;

      (this.horizonRing.material as THREE.MeshStandardMaterial).color.setHex(0x0f172a);
    }
  }

  updateQuality(preset: QualityPreset) {
    if (preset === 'low') {
      this.rayMesh.visible = false;
      this.cloudsGroup.visible = false;
    } else if (preset === 'medium') {
      this.rayMesh.visible = false;
      this.cloudsGroup.visible = true;
    } else {
      this.rayMesh.visible = true;
      this.cloudsGroup.visible = true;
    }
  }

  update(delta: number) {
    for (let i = 0; i < this.cloudMeshes.length; i++) {
      const cl = this.cloudMeshes[i];
      cl.position.x += delta * 1.6;
      if (cl.position.x > 75) {
        cl.position.x = -75;
      }
    }
  }
}
