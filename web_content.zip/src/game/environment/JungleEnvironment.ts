/**
 * SPR - Sahil Powerful Run
 * 3D Coastal Railway & Rio Hillside World
 * Directly inspired by the reference environment:
 * - 3 authentic railway tracks with wooden ties (sleepers) & polished steel rails
 * - Right Side: Coastal ocean promenade, sea cliffs, animated blue water, sailboats,
 *   iconic red & white striped lighthouse, vintage lampposts with royal blue SPR banner flags
 * - Left Side: Terracotta retaining wall with lush tropical bougainvillea & ferns,
 *   stacked colorful Mediterranean/Rio hillside town buildings with tile roofs & balconies,
 *   tall curving tropical palm trees with lush spreading fronds
 * - Backdrop: Towering lush green tropical mountains with mountaintop monument statue,
 *   mountain road trails, and stone mountain tunnel archways spanning across the tracks
 * - Daytime bright blue sky with golden sun, fluffy clouds, and flying seagulls
 * - Full object pooling & zero per-frame garbage generation
 */

import * as THREE from 'three';
import { GAME_CONFIG } from '../constants';
import { GraphicsTierConfig } from '../utils/DeviceTier';
import { textureGenerator } from '../utils/TextureGenerator';
import { InfiniteTrackScroller } from '../systems/InfiniteTrackScroller';

export type ChunkType = 'coastal' | 'town' | 'tunnel' | 'bridge';

export interface ChunkObject {
  group: THREE.Group;
  index: number;
  zStart: number;
  type: ChunkType;
  isBrokenBridge: boolean;
  isDangerZone: boolean;
}

export class JungleEnvironment {
  public scene: THREE.Scene;
  private activeChunks: ChunkObject[] = [];
  private poolCoastal: THREE.Group[] = [];
  private poolTown: THREE.Group[] = [];
  private poolTunnel: THREE.Group[] = [];
  private poolBridge: THREE.Group[] = [];
  private nextChunkIndex: number = 0;
  private chunkLength: number = GAME_CONFIG.SEGMENT_LENGTH;

  // Dynamic lights & Sky
  public dirLight!: THREE.DirectionalLight;
  private ambientLight!: THREE.HemisphereLight;
  private sunMesh!: THREE.Mesh;
  private cloudsGroup!: THREE.Group;
  private cloudsScroller!: InfiniteTrackScroller;
  private seagullsGroup!: THREE.Group;
  private mountainBackdrop!: THREE.Group;

  // Ocean wave animation tracking
  private oceanWaterMeshes: THREE.Mesh[] = [];
  private waveTimer: number = 0;

  // Shared Materials
  private ballastMaterial!: THREE.MeshStandardMaterial;
  private trackPlanksMaterial!: THREE.MeshStandardMaterial;
  private tieMaterial!: THREE.MeshStandardMaterial;
  private steelRailMaterial!: THREE.MeshStandardMaterial;
  private promenadeMaterial!: THREE.MeshStandardMaterial;
  private railingMaterial!: THREE.MeshStandardMaterial;
  private lamppostMaterial!: THREE.MeshStandardMaterial;
  private sprBannerMaterial!: THREE.MeshStandardMaterial;
  private cliffMaterial!: THREE.MeshStandardMaterial;
  private oceanWaterMaterial!: THREE.MeshStandardMaterial;
  private lighthouseMaterial!: THREE.MeshStandardMaterial;
  private lighthouseCapMaterial!: THREE.MeshStandardMaterial;
  private retainingWallMaterial!: THREE.MeshStandardMaterial;
  private foliageGreenMaterial!: THREE.MeshStandardMaterial;
  private flowerPinkMaterial!: THREE.MeshStandardMaterial;
  private flowerOrangeMaterial!: THREE.MeshStandardMaterial;
  private palmTrunkMaterial!: THREE.MeshStandardMaterial;
  private palmLeafMaterial!: THREE.MeshStandardMaterial;
  private buildingMaterials: THREE.MeshStandardMaterial[] = [];
  private roofTileMaterial!: THREE.MeshStandardMaterial;
  private tunnelStoneMaterial!: THREE.MeshStandardMaterial;
  private sailboatMaterial!: THREE.MeshStandardMaterial;

  // Shared Geometries
  private ballastGeo!: THREE.BufferGeometry;
  private trackPlanksGeo!: THREE.BufferGeometry;
  private tieGeo!: THREE.BufferGeometry;
  private railGeo!: THREE.BufferGeometry;
  private promenadeGeo!: THREE.BufferGeometry;
  private railingPostGeo!: THREE.BufferGeometry;
  private railingBarGeo!: THREE.BufferGeometry;
  private lamppostPoleGeo!: THREE.BufferGeometry;
  private lamppostHeadGeo!: THREE.BufferGeometry;
  private bannerFlagGeo!: THREE.BufferGeometry;
  private cliffGeo!: THREE.BufferGeometry;
  private oceanGeo!: THREE.BufferGeometry;
  private lighthouseTowerGeo!: THREE.BufferGeometry;
  private lighthouseCapGeo!: THREE.BufferGeometry;
  private retainingWallGeo!: THREE.BufferGeometry;
  private foliageBushGeo!: THREE.BufferGeometry;
  private flowerClusterGeo!: THREE.BufferGeometry;
  private palmTrunkSegmentGeo!: THREE.BufferGeometry;
  private palmFrondGeo!: THREE.BufferGeometry;
  private buildingSmallGeo!: THREE.BufferGeometry;
  private buildingMediumGeo!: THREE.BufferGeometry;
  private buildingTallGeo!: THREE.BufferGeometry;
  private roofGeo!: THREE.BufferGeometry;
  private tunnelArchGeo!: THREE.BufferGeometry;
  private tunnelPillarGeo!: THREE.BufferGeometry;
  private sailboatHullGeo!: THREE.BufferGeometry;
  private sailGeo!: THREE.BufferGeometry;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.initLightingAndFog();
    this.initSharedMaterials();
    this.initSharedGeometries();
    this.initSkyAndMountains();
    this.initInitialTrack();
  }

  private initLightingAndFog() {
    // 1. Radiant daytime coastal sky & atmospheric blue haze
    this.scene.background = new THREE.Color(GAME_CONFIG.SKY_COLOR);
    this.scene.fog = new THREE.FogExp2(GAME_CONFIG.FOG_COLOR, GAME_CONFIG.FOG_DENSITY);

    // 2. Crisp Warm Sunlight (Directional Light with High Precision Shadowing)
    this.dirLight = new THREE.DirectionalLight(0xfffbeb, 2.4);
    this.dirLight.position.set(30, 60, -25);
    this.dirLight.castShadow = true;
    this.dirLight.shadow.mapSize.width = 1024;
    this.dirLight.shadow.mapSize.height = 1024;
    this.dirLight.shadow.camera.near = 10;
    this.dirLight.shadow.camera.far = 160;
    this.dirLight.shadow.camera.left = -30;
    this.dirLight.shadow.camera.right = 30;
    this.dirLight.shadow.camera.top = 50;
    this.dirLight.shadow.camera.bottom = -30;
    this.dirLight.shadow.bias = -0.001;
    this.scene.add(this.dirLight);
    this.scene.add(this.dirLight.target);

    // 3. Bright Coastal Sky/Ground Bounce Hemisphere Light
    this.ambientLight = new THREE.HemisphereLight(0x38bdf8, 0x86efac, 1.3);
    this.scene.add(this.ambientLight);
  }

  private initSharedMaterials() {
    // 1. Tracks, Rails & Timber Planks
    this.ballastMaterial = new THREE.MeshStandardMaterial({
      color: 0x57534e, // Warm crushed stone ballast
      roughness: 0.95,
      metalness: 0.05,
    });

    this.trackPlanksMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getTrackWoodPlanksTexture(),
      roughness: 0.75,
      metalness: 0.08,
    });

    this.tieMaterial = new THREE.MeshStandardMaterial({
      color: 0x451a03, // Dark treated wood railroad ties
      roughness: 0.85,
      metalness: 0.1,
    });

    this.steelRailMaterial = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1, // Polished steel rails
      roughness: 0.25,
      metalness: 0.9,
    });

    // 2. Promenade & Sidewalk
    this.promenadeMaterial = new THREE.MeshStandardMaterial({
      color: 0xd6d3d1, // Light coastal stone pavers
      roughness: 0.7,
      metalness: 0.1,
    });

    this.railingMaterial = new THREE.MeshStandardMaterial({
      color: 0x78350f, // Warm varnished wood balustrade
      roughness: 0.6,
      metalness: 0.1,
    });

    this.lamppostMaterial = new THREE.MeshStandardMaterial({
      color: 0x1e293b, // Ornate black cast iron
      roughness: 0.5,
      metalness: 0.8,
    });

    this.sprBannerMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getSPRBannerTexture(),
      roughness: 0.6,
      metalness: 0.1,
      side: THREE.DoubleSide,
    });

    // 3. Ocean & Cliffs
    this.cliffMaterial = new THREE.MeshStandardMaterial({
      color: 0x78716c, // Coastal sandstone & granite cliffs
      roughness: 0.9,
      metalness: 0.1,
    });

    this.oceanWaterMaterial = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Vibrant azure blue ocean
      roughness: 0.15,
      metalness: 0.4,
      transparent: true,
      opacity: 0.9,
    });

    this.lighthouseMaterial = new THREE.MeshStandardMaterial({
      map: textureGenerator.getLighthouseTexture(),
      roughness: 0.5,
      metalness: 0.1,
    });

    this.lighthouseCapMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626, // Bright red lighthouse dome
      roughness: 0.4,
      metalness: 0.4,
    });

    // 4. Retaining Wall & Vegetation
    this.retainingWallMaterial = new THREE.MeshStandardMaterial({
      color: 0xa8a29e, // Terracotta/sandstone retaining blocks
      roughness: 0.85,
      metalness: 0.1,
    });

    this.foliageGreenMaterial = new THREE.MeshStandardMaterial({
      color: 0x15803d, // Lush tropical green leaves
      roughness: 0.7,
      metalness: 0.1,
    });

    this.flowerPinkMaterial = new THREE.MeshStandardMaterial({
      color: 0xf43f5e, // Vibrant pink bougainvillea
      roughness: 0.6,
    });

    this.flowerOrangeMaterial = new THREE.MeshStandardMaterial({
      color: 0xf97316, // Orange tropical blossoms
      roughness: 0.6,
    });

    this.palmTrunkMaterial = new THREE.MeshStandardMaterial({
      color: 0x78350f, // Segmented palm bark
      roughness: 0.9,
    });

    this.palmLeafMaterial = new THREE.MeshStandardMaterial({
      color: 0x22c55e, // Spreading emerald palm fronds
      roughness: 0.6,
      side: THREE.DoubleSide,
    });

    // 5. Colorful Hillside Mediterranean / Rio Buildings
    const buildingColors = [
      0xf97316, // Terracotta orange
      0xfbbf24, // Sun-baked ochre yellow
      0xf472b6, // Pastel peach pink
      0x38bdf8, // Sky blue
      0xf8fafc, // Clean off-white
      0xa855f7, // Royal lilac
    ];
    this.buildingMaterials = buildingColors.map(
      (c) =>
        new THREE.MeshStandardMaterial({
          color: c,
          roughness: 0.75,
          metalness: 0.05,
        })
    );

    this.roofTileMaterial = new THREE.MeshStandardMaterial({
      color: 0x991b1b, // Red clay terracotta roof tiles
      roughness: 0.8,
    });

    // 6. Tunnel & Sailboats
    this.tunnelStoneMaterial = new THREE.MeshStandardMaterial({
      color: 0x57534e, // Mountain stone masonry
      roughness: 0.9,
    });

    this.sailboatMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.4,
    });
  }

  private initSharedGeometries() {
    const len = this.chunkLength;

    // 1. Tracks, Timber Planks & Rails
    this.ballastGeo = new THREE.BoxGeometry(11.2, 0.35, len);
    this.trackPlanksGeo = new THREE.BoxGeometry(9.6, 0.08, len); // Wide warm timber boardwalk spanning all 3 tracks
    this.tieGeo = new THREE.BoxGeometry(2.3, 0.18, 0.38);
    this.railGeo = new THREE.BoxGeometry(0.12, 0.18, len);

    // 2. Sidewalk & Railings
    this.promenadeGeo = new THREE.BoxGeometry(4.0, 0.38, len);
    this.railingPostGeo = new THREE.BoxGeometry(0.16, 0.95, 0.16);
    this.railingBarGeo = new THREE.BoxGeometry(0.1, 0.1, len);

    // 3. Ornate Lamppost & Banner
    this.lamppostPoleGeo = new THREE.CylinderGeometry(0.08, 0.12, 5.0, 8);
    this.lamppostHeadGeo = new THREE.ConeGeometry(0.35, 0.55, 6);
    this.bannerFlagGeo = new THREE.PlaneGeometry(1.5, 2.8); // Prominent SPR royal blue banner

    // 4. Cliffs & Ocean
    this.cliffGeo = new THREE.BoxGeometry(24.0, 18.0, len);
    this.oceanGeo = new THREE.PlaneGeometry(120.0, len, 8, 8);
    this.oceanGeo.rotateX(-Math.PI / 2);

    // 5. Lighthouse
    this.lighthouseTowerGeo = new THREE.CylinderGeometry(1.8, 3.2, 22.0, 16);
    this.lighthouseCapGeo = new THREE.ConeGeometry(2.2, 3.5, 16);

    // 6. Retaining Wall & Plants
    this.retainingWallGeo = new THREE.BoxGeometry(1.2, 4.2, len);
    this.foliageBushGeo = new THREE.SphereGeometry(1.2, 7, 7);
    this.flowerClusterGeo = new THREE.SphereGeometry(0.5, 6, 6);

    // 7. Palm Trees
    this.palmTrunkSegmentGeo = new THREE.CylinderGeometry(0.3, 0.45, 10.5, 8);
    this.palmFrondGeo = new THREE.ConeGeometry(1.6, 5.5, 5);
    this.palmFrondGeo.rotateX(Math.PI / 2);

    // 8. Hillside Buildings
    this.buildingSmallGeo = new THREE.BoxGeometry(5.0, 6.0, 6.0);
    this.buildingMediumGeo = new THREE.BoxGeometry(6.0, 9.5, 7.5);
    this.buildingTallGeo = new THREE.BoxGeometry(6.5, 13.0, 8.0);
    this.roofGeo = new THREE.ConeGeometry(4.5, 2.2, 4);
    this.roofGeo.rotateY(Math.PI / 4);

    // 9. Tunnel Arch
    this.tunnelArchGeo = new THREE.BoxGeometry(14.0, 3.5, 12.0);
    this.tunnelPillarGeo = new THREE.BoxGeometry(2.5, 8.0, 12.0);

    // 10. Sailboats
    this.sailboatHullGeo = new THREE.ConeGeometry(1.2, 4.5, 4);
    this.sailboatHullGeo.rotateX(Math.PI / 2);
    this.sailGeo = new THREE.BufferGeometry();
    const sailVertices = new Float32Array([
      0, 0, 0,
      0, 4.2, 0,
      1.8, 0, 0,
    ]);
    this.sailGeo.setAttribute('position', new THREE.BufferAttribute(sailVertices, 3));
    this.sailGeo.computeVertexNormals();
  }

  private initSkyAndMountains() {
    // 1. Radiant Morning/Daytime Sun
    const sunGeo = new THREE.SphereGeometry(24, 24, 24);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xffea79 });
    this.sunMesh = new THREE.Mesh(sunGeo, sunMat);
    this.sunMesh.position.set(80, 95, -280);
    this.scene.add(this.sunMesh);

    // Sun Golden Corona
    const coronaGeo = new THREE.SphereGeometry(36, 24, 24);
    const coronaMat = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
      transparent: true,
      opacity: 0.35,
      side: THREE.BackSide,
    });
    const coronaMesh = new THREE.Mesh(coronaGeo, coronaMat);
    this.sunMesh.add(coronaMesh);

    // 2. Distant Mountains & Mountaintop Monument (framing the bay in the distant background)
    this.mountainBackdrop = new THREE.Group();
    const mountainMat = new THREE.MeshStandardMaterial({
      color: 0x475569, // Coastal granite slate mountain rock
      roughness: 0.9,
      metalness: 0.05,
    });

    // Distant Left mountain ridge (well clear of track area, X < -40)
    const leftRidgeGeo = new THREE.ConeGeometry(75, 110, 8);
    const leftRidge = new THREE.Mesh(leftRidgeGeo, mountainMat);
    leftRidge.position.set(-95, 45, -360);
    this.mountainBackdrop.add(leftRidge);

    // Distant Right coastal mountain ridge (well clear of track area, X > +40)
    const rightRidgeGeo = new THREE.ConeGeometry(70, 95, 8);
    const rightRidge = new THREE.Mesh(rightRidgeGeo, mountainMat);
    rightRidge.position.set(100, 40, -380);
    this.mountainBackdrop.add(rightRidge);

    // Towering Far Center Peak situated deep in the horizon (Z = -520, Y elevated so base never touches ground)
    const centerPeakGeo = new THREE.ConeGeometry(80, 130, 10);
    const centerPeak = new THREE.Mesh(centerPeakGeo, mountainMat);
    centerPeak.position.set(0, 130, -520);
    this.mountainBackdrop.add(centerPeak);

    // Winding mountain switchback road/trail on the distant slope
    const roadMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.85 });
    const railingMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const roadPoints = [
      { x: -18, y: 105, z: -516, len: 36, rot: 0.30 },
      { x: 5, y: 128, z: -518, len: 38, rot: -0.32 },
      { x: -12, y: 152, z: -519, len: 32, rot: 0.26 },
      { x: -2, y: 174, z: -520, len: 24, rot: -0.20 },
    ];
    roadPoints.forEach((rp) => {
      const roadSegment = new THREE.Mesh(new THREE.BoxGeometry(rp.len, 1.8, 4.0), roadMat);
      roadSegment.position.set(rp.x, rp.y, rp.z);
      roadSegment.rotation.z = rp.rot;
      this.mountainBackdrop.add(roadSegment);

      const railMesh = new THREE.Mesh(new THREE.BoxGeometry(rp.len, 1.0, 0.4), railingMat);
      railMesh.position.set(rp.x, rp.y + 1.0, rp.z + 1.8);
      railMesh.rotation.z = rp.rot;
      this.mountainBackdrop.add(railMesh);
    });

    // Mountaintop Monument / Iconic White Statue Silhouette on summit (Christ the Redeemer)
    const statueBaseGeo = new THREE.BoxGeometry(9, 6.0, 9);
    const statueBase = new THREE.Mesh(statueBaseGeo, this.promenadeMaterial);
    statueBase.position.set(0, 196, -520);
    this.mountainBackdrop.add(statueBase);

    const statueBodyGeo = new THREE.BoxGeometry(4.0, 14.0, 4.0);
    const statueArmsGeo = new THREE.BoxGeometry(20.0, 3.2, 3.2); // Wide outstretched arms
    const statueHeadGeo = new THREE.SphereGeometry(2.4, 8, 8);
    const statueMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const statueBody = new THREE.Mesh(statueBodyGeo, statueMat);
    statueBody.position.set(0, 204, -520);
    const statueArms = new THREE.Mesh(statueArmsGeo, statueMat);
    statueArms.position.set(0, 209, -520);
    const statueHead = new THREE.Mesh(statueHeadGeo, statueMat);
    statueHead.position.set(0, 214, -520);

    this.mountainBackdrop.add(statueBody);
    this.mountainBackdrop.add(statueArms);
    this.mountainBackdrop.add(statueHead);

    // Distant Coastal Metropolis Skyline along the ocean coast (as seen in reference background)
    const cityGroup = new THREE.Group();
    const cityMatWhite = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
    const cityMatGlass = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.2, metalness: 0.5 });
    const cityMatCream = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.6 });

    const towers = [
      { x: 50, y: 22, z: -380, w: 12, h: 48, d: 12, mat: cityMatWhite },
      { x: 65, y: 32, z: -390, w: 14, h: 68, d: 14, mat: cityMatGlass },
      { x: 80, y: 26, z: -400, w: 12, h: 56, d: 12, mat: cityMatWhite },
      { x: 95, y: 38, z: -410, w: 15, h: 78, d: 14, mat: cityMatGlass },
      { x: 112, y: 24, z: -420, w: 14, h: 50, d: 12, mat: cityMatCream },
      { x: 128, y: 34, z: -430, w: 13, h: 70, d: 13, mat: cityMatWhite },
    ];
    towers.forEach((t) => {
      const bldg = new THREE.Mesh(new THREE.BoxGeometry(t.w, t.h, t.d), t.mat);
      bldg.position.set(t.x, t.y, t.z);
      cityGroup.add(bldg);

      // Roof antenna spire on taller towers
      if (t.h > 55) {
        const spire = new THREE.Mesh(
          new THREE.CylinderGeometry(0.2, 0.4, 12, 6),
          this.steelRailMaterial
        );
        spire.position.set(t.x, t.y + t.h / 2 + 6, t.z);
        cityGroup.add(spire);
      }
    });
    this.mountainBackdrop.add(cityGroup);

    this.scene.add(this.mountainBackdrop);

    // 3. Fluffy Clouds
    this.cloudsGroup = new THREE.Group();
    const cloudGeo = new THREE.DodecahedronGeometry(14, 1);
    const cloudMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.75,
    });
    for (let c = 0; c < 8; c++) {
      const cloud = new THREE.Mesh(cloudGeo, cloudMat);
      cloud.position.set(
        (Math.random() - 0.5) * 260,
        55 + Math.random() * 35,
        -80 - Math.random() * 200
      );
      cloud.scale.set(1.5 + Math.random(), 0.7, 1.2);
      this.cloudsGroup.add(cloud);
    }
    this.scene.add(this.cloudsGroup);
    // Initialize infinite scroller for drifting background clouds
    this.cloudsScroller = new InfiniteTrackScroller(this.cloudsGroup, {
      scrollSpeed: 4.5,
      tileLength: 120,
    });

    // 4. Flying Seagulls over the ocean
    this.seagullsGroup = new THREE.Group();
    const gullWingGeo = new THREE.BufferGeometry();
    const wingVerts = new Float32Array([
      0, 0, 0,
      -0.9, 0.25, 0.4,
      0, 0, 0.8,
      0, 0, 0,
      0.9, 0.25, 0.4,
      0, 0, 0.8,
    ]);
    gullWingGeo.setAttribute('position', new THREE.BufferAttribute(wingVerts, 3));
    gullWingGeo.computeVertexNormals();
    const gullMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });

    for (let g = 0; g < 5; g++) {
      const gull = new THREE.Mesh(gullWingGeo, gullMat);
      gull.position.set(18 + g * 8, 16 + g * 3, -40 - g * 25);
      gull.rotation.y = -0.4;
      this.seagullsGroup.add(gull);
    }
    this.scene.add(this.seagullsGroup);
  }

  private initInitialTrack() {
    for (let i = 0; i < GAME_CONFIG.VISIBLE_SEGMENTS; i++) {
      const zStart = -i * this.chunkLength;
      const type: ChunkType =
        i === 0 ? 'coastal' : i === 1 ? 'tunnel' : i === 2 ? 'town' : i === 3 ? 'coastal' : i === 4 ? 'tunnel' : i % 2 === 0 ? 'town' : 'coastal';
      this.spawnChunk(zStart, type);
    }
  }

  // --- SPAWN CHUNK VIA OBJECT POOLING ---
  private spawnChunk(zStart: number, type: ChunkType) {
    const chunkGroup = this.getChunkFromPool(type);
    chunkGroup.position.set(0, 0, zStart);
    chunkGroup.visible = true;

    const chunkObj: ChunkObject = {
      group: chunkGroup,
      index: this.nextChunkIndex++,
      zStart,
      type,
      isBrokenBridge: false,
      isDangerZone: false,
    };

    this.activeChunks.push(chunkObj);
  }

  private getChunkFromPool(type: ChunkType): THREE.Group {
    let pool: THREE.Group[];
    switch (type) {
      case 'coastal':
        pool = this.poolCoastal;
        break;
      case 'town':
        pool = this.poolTown;
        break;
      case 'tunnel':
        pool = this.poolTunnel;
        break;
      case 'bridge':
        pool = this.poolBridge;
        break;
    }

    if (pool.length > 0) {
      return pool.pop()!;
    }

    // Otherwise instantiate a new chunk for this pool
    const newChunk = this.createChunkMesh(type);
    this.scene.add(newChunk);
    return newChunk;
  }

  private recycleChunk(chunk: ChunkObject) {
    chunk.group.visible = false;
    switch (chunk.type) {
      case 'coastal':
        this.poolCoastal.push(chunk.group);
        break;
      case 'town':
        this.poolTown.push(chunk.group);
        break;
      case 'tunnel':
        this.poolTunnel.push(chunk.group);
        break;
      case 'bridge':
        this.poolBridge.push(chunk.group);
        break;
    }
  }

  // --- BUILD CHUNK GEOMETRY (Authentic 3D Coastal Runner Scene) ---
  private createChunkMesh(type: ChunkType): THREE.Group {
    const chunk = new THREE.Group();
    const len = this.chunkLength;
    const halfLen = len / 2;

    // 1. BASE RAILWAY TRACK BED & TIMBER BOARDWALK (Shared across all chunk types)
    const ballast = new THREE.Mesh(this.ballastGeo, this.ballastMaterial);
    ballast.name = 'trackBed';
    ballast.position.set(0, -0.18, -halfLen);
    ballast.receiveShadow = true;
    chunk.add(ballast);

    // Warm timber boardwalk planks running down the central track corridor (matching reference image)
    const trackPlanks = new THREE.Mesh(this.trackPlanksGeo, this.trackPlanksMaterial);
    trackPlanks.name = 'trackBed';
    trackPlanks.position.set(0, 0.02, -halfLen);
    trackPlanks.receiveShadow = true;
    chunk.add(trackPlanks);

    // 2. THREE SETS OF RAILWAY TRACKS (Wooden ties + Steel rails)
    const lanePositions = GAME_CONFIG.LANES; // [-3.2, 0, 3.2]

    for (const lx of lanePositions) {
      // Left and Right Steel Rails for this lane
      const railLeft = new THREE.Mesh(this.railGeo, this.steelRailMaterial);
      railLeft.name = 'trackBed';
      railLeft.position.set(lx - 0.72, 0.09, -halfLen);
      railLeft.castShadow = true;
      chunk.add(railLeft);

      const railRight = new THREE.Mesh(this.railGeo, this.steelRailMaterial);
      railRight.name = 'trackBed';
      railRight.position.set(lx + 0.72, 0.09, -halfLen);
      railRight.castShadow = true;
      chunk.add(railRight);

      // Wooden Railroad Ties (Sleepers) spaced every 1.5m along Z
      for (let z = 0.75; z < len; z += 1.5) {
        const tie = new THREE.Mesh(this.tieGeo, this.tieMaterial);
        tie.name = 'trackBed';
        tie.position.set(lx, 0.04, -z);
        tie.receiveShadow = true;
        chunk.add(tie);
      }
    }

    // 3. RIGHT SIDE: COASTAL PROMENADE, BALUSTRADE, PLANTERS & SPR BANNERS
    const promenade = new THREE.Mesh(this.promenadeGeo, this.promenadeMaterial);
    promenade.position.set(6.4, -0.16, -halfLen);
    promenade.receiveShadow = true;
    chunk.add(promenade);

    // Balustrade / Coastal Railing along the cliff edge (x = 5.6)
    const railingTop = new THREE.Mesh(this.railingBarGeo, this.railingMaterial);
    railingTop.position.set(5.6, 0.85, -halfLen);
    chunk.add(railingTop);

    const railingMid = new THREE.Mesh(this.railingBarGeo, this.railingMaterial);
    railingMid.position.set(5.6, 0.45, -halfLen);
    chunk.add(railingMid);

    // Balustrade Posts & Ornate Lampposts with SPR Banners
    for (let z = 2.0; z < len; z += 4.5) {
      const post = new THREE.Mesh(this.railingPostGeo, this.railingMaterial);
      post.position.set(5.6, 0.48, -z);
      post.castShadow = true;
      chunk.add(post);
    }

    // Place ornate vintage lampposts with Royal Blue SPR Banners at fixed prominent positions
    const lamppost1 = this.createLamppostWithSPRBanner();
    lamppost1.position.set(5.8, 0, -16);
    chunk.add(lamppost1);

    const lamppost2 = this.createLamppostWithSPRBanner();
    lamppost2.position.set(5.8, 0, -36);
    chunk.add(lamppost2);

    // Coastal Cliffs dropping down into ocean
    const cliff = new THREE.Mesh(this.cliffGeo, this.cliffMaterial);
    cliff.position.set(18.0, -9.2, -halfLen);
    cliff.receiveShadow = true;
    chunk.add(cliff);

    // Azure Blue Ocean Surface
    const ocean = new THREE.Mesh(this.oceanGeo, this.oceanWaterMaterial);
    ocean.position.set(65.0, -11.5, -halfLen);
    chunk.add(ocean);
    this.oceanWaterMeshes.push(ocean);

    // 4. CHUNK-SPECIFIC UNIQUE 3D FEATURES
    if (type === 'coastal') {
      // Iconic Red & White Striped Lighthouse on coastal cliff promontory
      const lighthouseGroup = this.createLighthouse();
      lighthouseGroup.position.set(14.5, 0.0, -28.0);
      chunk.add(lighthouseGroup);

      // Clustered colorful Mediterranean / Rio hillside buildings visible on left hillside
      this.addHillsideTownBuildings(chunk, len);

      // Sailboat floating on the ocean in the distance
      const sailboat = this.createSailboat();
      sailboat.position.set(45.0 + Math.random() * 25, -11.4, -10 - Math.random() * 30);
      sailboat.rotation.y = 0.6;
      chunk.add(sailboat);

      // Left Retaining Wall along railway edge
      this.addRetainingWall(chunk, halfLen);
    } else if (type === 'town') {
      // Clustered colorful Mediterranean / Rio hillside buildings
      this.addHillsideTownBuildings(chunk, len);

      // Left Retaining Wall
      this.addRetainingWall(chunk, halfLen);
    } else if (type === 'tunnel') {
      // Mountain Ridge & Stone Tunnel Archway spanning across all 3 tracks!
      const tunnelPortal = this.createMountainTunnelArch();
      tunnelPortal.position.set(0, 0, -halfLen);
      chunk.add(tunnelPortal);

      this.addRetainingWall(chunk, halfLen);
    } else if (type === 'bridge') {
      // Coastal Viaduct Bridge
      this.addRetainingWall(chunk, halfLen);
      const sailboat = this.createSailboat();
      sailboat.position.set(50.0, -11.4, -25);
      chunk.add(sailboat);
    }

    // Strict validation: Verify child bounding boxes against playable track corridor
    this.validateAndClearPlayableCorridor(chunk);

    return chunk;
  }

  /**
   * Enforces 100% obstruction-free playable corridor across all 3 tracks.
   * Checks every environment mesh bounding box against the running track envelope
   * (X: -4.6 to +4.6, Y: 0.05 to 5.0).
   * Any environment object (cliffs, terrain, buildings, lampposts) detected inside
   * this playable volume is immediately shifted to the background or rejected.
   */
  private validateAndClearPlayableCorridor(chunk: THREE.Group) {
    const minX = -4.6;
    const maxX = 4.6;
    const minY = 0.08;
    const maxY = 4.8;

    const children = [...chunk.children];
    for (const child of children) {
      // Track beds (rails, ties, gravel ballast at y <= 0.06) are valid track infrastructure
      if (child.name === 'trackBed' || (child.position.y <= 0.06 && Math.abs(child.position.x) < 4.0)) {
        continue;
      }

      // Overhead tunnel arch portal is designed to span elevated overhead (Y >= 4.8)
      if (child.name === 'tunnelPortal') {
        continue;
      }

      const bbox = new THREE.Box3().setFromObject(child);
      const overlapsX = bbox.max.x >= minX && bbox.min.x <= maxX;
      const overlapsY = bbox.max.y >= minY && bbox.min.y <= maxY;

      if (overlapsX && overlapsY) {
        // Environment terrain/mesh intruding into running corridor - relocate or reject
        if (child.position.x <= 0) {
          // Relocate safely into the left hillside
          child.position.x = Math.min(child.position.x, -7.5);
        } else {
          // Relocate safely into the right coastal promenade
          child.position.x = Math.max(child.position.x, 7.5);
        }
        child.updateMatrixWorld(true);

        // Re-check; if still overlapping, remove child from chunk
        const recheckBbox = new THREE.Box3().setFromObject(child);
        if (recheckBbox.max.x >= minX && recheckBbox.min.x <= maxX) {
          chunk.remove(child);
        }
      }
    }
  }

  // --- SUB-ASSEMBLY BUILDERS ---

  /**
   * Vintage Cast-Iron Lamppost with Royal Blue SPR Banner Flag
   */
  private createLamppostWithSPRBanner(): THREE.Group {
    const group = new THREE.Group();

    // Cast-iron pole
    const pole = new THREE.Mesh(this.lamppostPoleGeo, this.lamppostMaterial);
    pole.position.y = 2.5;
    pole.castShadow = true;
    group.add(pole);

    // Lamp head lantern
    const head = new THREE.Mesh(this.lamppostHeadGeo, this.lamppostMaterial);
    head.position.y = 5.2;
    head.castShadow = true;
    group.add(head);

    // Glowing warm bulb inside lantern
    const bulbGeo = new THREE.SphereGeometry(0.2, 8, 8);
    const bulbMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
    const bulb = new THREE.Mesh(bulbGeo, bulbMat);
    bulb.position.y = 5.0;
    group.add(bulb);

    // Horizontal bracket arm holding the banner
    const armGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.6, 6);
    armGeo.rotateZ(Math.PI / 2);
    const arm = new THREE.Mesh(armGeo, this.lamppostMaterial);
    arm.position.set(-0.7, 4.2, 0);
    group.add(arm);

    // Hanging SPR Royal Blue Banner with Golden Lion Crest and "SPR"
    const banner = new THREE.Mesh(this.bannerFlagGeo, this.sprBannerMaterial);
    banner.position.set(-0.7, 2.9, 0);
    banner.rotation.y = -0.15; // Angled facing the runner/camera
    banner.castShadow = true;
    group.add(banner);

    return group;
  }

  /**
   * Iconic Red & White Striped Coastal Lighthouse
   */
  private createLighthouse(): THREE.Group {
    const group = new THREE.Group();

    // Lighthouse conical stone tower with red & white stripes
    const tower = new THREE.Mesh(this.lighthouseTowerGeo, this.lighthouseMaterial);
    tower.position.y = 11.0;
    tower.castShadow = true;
    group.add(tower);

    // Lantern room gallery / walkway
    const galleryGeo = new THREE.CylinderGeometry(2.6, 2.6, 0.6, 16);
    const gallery = new THREE.Mesh(galleryGeo, this.promenadeMaterial);
    gallery.position.y = 22.3;
    group.add(gallery);

    // Glass lamp room
    const glassGeo = new THREE.CylinderGeometry(1.8, 1.8, 2.0, 16);
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.6,
      roughness: 0.1,
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.y = 23.5;
    group.add(glass);

    // Beacon light sphere
    const beaconGeo = new THREE.SphereGeometry(0.8, 8, 8);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
    const beacon = new THREE.Mesh(beaconGeo, beaconMat);
    beacon.position.y = 23.5;
    group.add(beacon);

    // Red conical roof cap
    const cap = new THREE.Mesh(this.lighthouseCapGeo, this.lighthouseCapMaterial);
    cap.position.y = 26.2;
    cap.castShadow = true;
    group.add(cap);

    return group;
  }

  /**
   * Curving Tropical Palm Tree with realistic segmented trunk & spreading fronds
   */
  private createTropicalPalmTree(): THREE.Group {
    const palm = new THREE.Group();

    // Segmented curving trunk
    const trunk = new THREE.Mesh(this.palmTrunkSegmentGeo, this.palmTrunkMaterial);
    trunk.position.set(0, 5.2, 0);
    trunk.rotation.z = -0.15; // Natural gentle curve toward the track
    trunk.castShadow = true;
    palm.add(trunk);

    // Palm fronds crown at top of trunk
    const crown = new THREE.Group();
    crown.position.set(0.8, 10.4, 0);

    const frondCount = 7;
    for (let f = 0; f < frondCount; f++) {
      const angle = (f / frondCount) * Math.PI * 2;
      const frond = new THREE.Mesh(this.palmFrondGeo, this.palmLeafMaterial);
      frond.rotation.y = angle;
      frond.rotation.x = 0.55; // Spread downwards naturally
      crown.add(frond);
    }

    // Coconut cluster
    const coconutGeo = new THREE.SphereGeometry(0.35, 6, 6);
    const coconutMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9 });
    for (let c = 0; c < 3; c++) {
      const nut = new THREE.Mesh(coconutGeo, coconutMat);
      nut.position.set(Math.cos(c * 2) * 0.4, -0.3, Math.sin(c * 2) * 0.4);
      crown.add(nut);
    }

    palm.add(crown);
    return palm;
  }

  /**
   * Clustered Colorful Mediterranean / Rio Hillside Town Buildings
   */
  private addHillsideTownBuildings(chunk: THREE.Group, chunkLen: number) {
    const buildingDefs = [
      { geo: this.buildingMediumGeo, matIdx: 0, x: -12.0, y: 3.5, z: -10, rot: 0.05 },
      { geo: this.buildingTallGeo, matIdx: 1, x: -16.5, y: 7.0, z: -18, rot: -0.08 },
      { geo: this.buildingSmallGeo, matIdx: 2, x: -11.5, y: 2.5, z: -28, rot: 0.0 },
      { geo: this.buildingMediumGeo, matIdx: 3, x: -15.5, y: 6.5, z: -38, rot: 0.06 },
      { geo: this.buildingSmallGeo, matIdx: 4, x: -11.0, y: 2.5, z: -46, rot: -0.04 },
    ];

    buildingDefs.forEach((b) => {
      const bldg = new THREE.Mesh(b.geo, this.buildingMaterials[b.matIdx % this.buildingMaterials.length]);
      bldg.position.set(b.x, b.y, b.z);
      bldg.rotation.y = b.rot;
      bldg.castShadow = true;
      bldg.receiveShadow = true;
      chunk.add(bldg);

      // Terracotta pitched tile roof
      const roof = new THREE.Mesh(this.roofGeo, this.roofTileMaterial);
      const heightOffset = b.geo === this.buildingTallGeo ? 7.2 : b.geo === this.buildingMediumGeo ? 5.4 : 3.6;
      roof.position.set(b.x, b.y + heightOffset, b.z);
      roof.rotation.y = b.rot + Math.PI / 4;
      roof.castShadow = true;
      chunk.add(roof);
    });
  }

  /**
   * Stone Retaining Wall along railway edge
   */
  private addRetainingWall(chunk: THREE.Group, halfLen: number) {
    const wall = new THREE.Mesh(this.retainingWallGeo, this.retainingWallMaterial);
    wall.position.set(-6.8, 1.8, -halfLen);
    wall.castShadow = true;
    wall.receiveShadow = true;
    chunk.add(wall);
  }

  /**
   * Authentic Stone Mountain Tunnel Portal Arch spanning over the 3 railway tracks
   */
  private createMountainTunnelArch(): THREE.Group {
    const tunnel = new THREE.Group();
    tunnel.name = 'tunnelPortal';

    // Left Tunnel Pillar Pier
    const leftPillar = new THREE.Mesh(this.tunnelPillarGeo, this.tunnelStoneMaterial);
    leftPillar.position.set(-7.2, 4.0, 0);
    leftPillar.castShadow = true;
    leftPillar.receiveShadow = true;
    tunnel.add(leftPillar);

    // Right Tunnel Pillar Pier
    const rightPillar = new THREE.Mesh(this.tunnelPillarGeo, this.tunnelStoneMaterial);
    rightPillar.position.set(7.2, 4.0, 0);
    rightPillar.castShadow = true;
    rightPillar.receiveShadow = true;
    tunnel.add(rightPillar);

    // Top Tunnel Arch Portal Face
    const arch = new THREE.Mesh(this.tunnelArchGeo, this.tunnelStoneMaterial);
    arch.position.set(0, 9.0, 0);
    arch.castShadow = true;
    arch.receiveShadow = true;
    tunnel.add(arch);

    // Prominent Keystone block at apex of tunnel arch
    const keystoneGeo = new THREE.BoxGeometry(1.6, 2.2, 12.6);
    const keystone = new THREE.Mesh(keystoneGeo, this.tunnelStoneMaterial);
    keystone.position.set(0, 8.2, 0);
    keystone.castShadow = true;
    tunnel.add(keystone);

    // Mountain Rock Ridge above tunnel
    const ridgeGeo = new THREE.ConeGeometry(22, 16, 7);
    const ridge = new THREE.Mesh(ridgeGeo, this.cliffMaterial);
    ridge.position.set(0, 16.5, 0);
    ridge.rotation.y = 0.4;
    tunnel.add(ridge);

    // Warm glowing amber tunnel lanterns inside ceiling
    const tunnelLightMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const lampGeo = new THREE.SphereGeometry(0.35, 8, 8);
    for (const lz of [-4.0, 4.0]) {
      const lampMesh = new THREE.Mesh(lampGeo, tunnelLightMat);
      lampMesh.position.set(0, 7.8, lz);
      tunnel.add(lampMesh);
    }

    return tunnel;
  }

  /**
   * White Sailboat floating on the ocean
   */
  private createSailboat(): THREE.Group {
    const boat = new THREE.Group();

    // Hull
    const hull = new THREE.Mesh(this.sailboatHullGeo, this.sailboatMaterial);
    hull.position.y = 0.4;
    boat.add(hull);

    // Mast
    const mastGeo = new THREE.CylinderGeometry(0.06, 0.06, 4.8, 6);
    const mast = new THREE.Mesh(mastGeo, this.railingMaterial);
    mast.position.set(0, 2.6, 0);
    boat.add(mast);

    // White Triangular Sail
    const sail = new THREE.Mesh(this.sailGeo, this.sailboatMaterial);
    sail.position.set(0, 0.6, 0);
    boat.add(sail);

    return boat;
  }

  // --- PER-FRAME ANIMATIONS & OBJECT RECYCLING ---
  public update(playerPositionZ: number, delta: number) {
    // 1. Directional Sun follows player smoothly
    this.dirLight.position.z = playerPositionZ - 25;
    this.dirLight.target.position.z = playerPositionZ - 55;
    this.dirLight.target.updateMatrixWorld();

    this.sunMesh.position.z = playerPositionZ - 280;
    if (this.mountainBackdrop) {
      // Distant horizon positioning: always stays deep in the background ahead of player
      this.mountainBackdrop.position.z = playerPositionZ - 450;
    }
    if (this.cloudsGroup) {
      if (this.cloudsScroller) {
        this.cloudsScroller.update(delta);
        // Base Z position stays ahead of the player while clouds scroller loops
        this.cloudsGroup.position.z = playerPositionZ - 260 - (this.cloudsScroller.backgroundPart.position.z % 120);
      } else {
        this.cloudsGroup.position.z = playerPositionZ - 260;
      }
    }

    // 2. Flying Seagulls animation
    if (this.seagullsGroup) {
      this.seagullsGroup.position.z = playerPositionZ * 0.7;
      this.seagullsGroup.children.forEach((gull, idx) => {
        gull.position.y += Math.sin(delta * 4 + idx) * 0.04;
      });
    }

    // 3. Gentle Ocean Waves Animation
    this.waveTimer += delta * 1.5;
    const waveSin = Math.sin(this.waveTimer) * 0.08;
    for (const water of this.oceanWaterMeshes) {
      water.position.y = -11.5 + waveSin;
    }

    // 4. Object Pooling: Recycle chunks passed by player
    const despawnThreshold = playerPositionZ + this.chunkLength * 1.5;

    while (this.activeChunks.length > 0 && this.activeChunks[0].zStart > despawnThreshold) {
      const oldChunk = this.activeChunks.shift()!;
      this.recycleChunk(oldChunk);

      const lastChunk = this.activeChunks[this.activeChunks.length - 1];
      const newZStart = lastChunk.zStart - this.chunkLength;

      // Cycle chunk themes: coastal, town, tunnel, bridge
      const themes: ChunkType[] = ['coastal', 'town', 'tunnel', 'coastal', 'town', 'bridge'];
      const nextTheme = themes[this.nextChunkIndex % themes.length];

      this.spawnChunk(newZStart, nextTheme);
    }
  }

  public getActiveChunks(): ChunkObject[] {
    return this.activeChunks;
  }

  public applyGraphicsTier(tierConfig: GraphicsTierConfig) {
    this.dirLight.castShadow = tierConfig.shadows;
    if (tierConfig.shadows) {
      this.dirLight.shadow.mapSize.width = tierConfig.shadowMapSize;
      this.dirLight.shadow.mapSize.height = tierConfig.shadowMapSize;
      if (this.dirLight.shadow.map) {
        this.dirLight.shadow.map.dispose();
        this.dirLight.shadow.map = null as any;
      }
    }

    this.scene.fog = new THREE.FogExp2(GAME_CONFIG.FOG_COLOR, tierConfig.fogDensity);
  }

  public reset(startZ: number = 0) {
    for (const chunk of this.activeChunks) {
      this.recycleChunk(chunk);
    }
    this.activeChunks = [];
    this.nextChunkIndex = 0;

    for (let i = 0; i < GAME_CONFIG.VISIBLE_SEGMENTS; i++) {
      const zStart = startZ - i * this.chunkLength;
      const type: ChunkType =
        i === 0 ? 'coastal' : i === 2 ? 'town' : i === 4 ? 'tunnel' : i % 2 === 0 ? 'coastal' : 'town';
      this.spawnChunk(zStart, type);
    }
  }

  public destroy() {
    for (const chunk of this.activeChunks) {
      this.recycleChunk(chunk);
    }
    this.activeChunks = [];

    // Remove all pooled chunks from scene
    const allPools = [this.poolCoastal, this.poolTown, this.poolTunnel, this.poolBridge];
    for (const pool of allPools) {
      for (const group of pool) {
        this.scene.remove(group);
      }
    }
    this.poolCoastal = [];
    this.poolTown = [];
    this.poolTunnel = [];
    this.poolBridge = [];

    // Lights & Sky
    if (this.dirLight) {
      if (this.dirLight.shadow && this.dirLight.shadow.map) {
        this.dirLight.shadow.map.dispose();
      }
      this.scene.remove(this.dirLight);
      this.scene.remove(this.dirLight.target);
    }
    if (this.ambientLight) {
      this.scene.remove(this.ambientLight);
    }
    if (this.sunMesh) {
      this.scene.remove(this.sunMesh);
    }
    if (this.mountainBackdrop) {
      this.scene.remove(this.mountainBackdrop);
    }
    if (this.cloudsGroup) {
      this.scene.remove(this.cloudsGroup);
    }
    if (this.seagullsGroup) {
      this.scene.remove(this.seagullsGroup);
    }

    // Geometries
    this.ballastGeo?.dispose();
    this.trackPlanksGeo?.dispose();
    this.tieGeo?.dispose();
    this.railGeo?.dispose();
    this.promenadeGeo?.dispose();
    this.railingPostGeo?.dispose();
    this.railingBarGeo?.dispose();
    this.lamppostPoleGeo?.dispose();
    this.lamppostHeadGeo?.dispose();
    this.bannerFlagGeo?.dispose();
    this.cliffGeo?.dispose();
    this.oceanGeo?.dispose();
    this.lighthouseTowerGeo?.dispose();
    this.lighthouseCapGeo?.dispose();
    this.retainingWallGeo?.dispose();
    this.foliageBushGeo?.dispose();
    this.flowerClusterGeo?.dispose();
    this.palmTrunkSegmentGeo?.dispose();
    this.palmFrondGeo?.dispose();
    this.buildingSmallGeo?.dispose();
    this.buildingMediumGeo?.dispose();
    this.buildingTallGeo?.dispose();
    this.roofGeo?.dispose();
    this.tunnelArchGeo?.dispose();
    this.tunnelPillarGeo?.dispose();
    this.sailboatHullGeo?.dispose();
    this.sailGeo?.dispose();

    // Materials
    this.ballastMaterial?.dispose();
    this.trackPlanksMaterial?.dispose();
    this.tieMaterial?.dispose();
    this.steelRailMaterial?.dispose();
    this.promenadeMaterial?.dispose();
    this.railingMaterial?.dispose();
    this.lamppostMaterial?.dispose();
    this.sprBannerMaterial?.dispose();
    this.cliffMaterial?.dispose();
    this.oceanWaterMaterial?.dispose();
    this.lighthouseMaterial?.dispose();
    this.lighthouseCapMaterial?.dispose();
    this.retainingWallMaterial?.dispose();
    this.foliageGreenMaterial?.dispose();
    this.flowerPinkMaterial?.dispose();
    this.flowerOrangeMaterial?.dispose();
    this.palmTrunkMaterial?.dispose();
    this.palmLeafMaterial?.dispose();
    this.buildingMaterials.forEach((m) => m.dispose());
    this.roofTileMaterial?.dispose();
    this.tunnelStoneMaterial?.dispose();
    this.sailboatMaterial?.dispose();
  }
}
