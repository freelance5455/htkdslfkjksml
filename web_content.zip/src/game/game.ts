import { CarAudio } from "./audio";
import { createSim, stepSim, type SimState } from "./sim";
import { createView } from "./view";

export type HudNodes = {
  speed: HTMLElement | null;
  gear: HTMLElement | null;
  rpm: HTMLElement | null;
  lamp: HTMLElement | null;
  best: HTMLElement | null;
};

export const inputBus = {
  steerTouch: 0,
  touchActive: false,
  padSteer: 0,
  gas: false,
  brake: false,
  shiftUp: 0,
  shiftDown: 0,
  sensitivity: 1,
  tilt: 0,
  tiltOn: false,
  invertTilt: false,
};

const BEST_KEY = "overrun-best-kmh";

type Probe = {
  getYaw: () => number;
  getSpeed: () => number;
  setKeys: (codes: string[]) => void;
  setSteer?: (v: number) => void;
};

declare global {
  interface Window {
    __controlsTest?: Probe;
  }
}

export type GameApi = {
  start: () => void;
  dispose: () => void;
  setMuted: (m: boolean) => void;
  recenterTilt: () => void;
};

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function mountGame(canvas: HTMLCanvasElement, hud: HudNodes): GameApi {
  const sim: SimState = createSim();
  const view = createView(canvas);
  const audio = new CarAudio();
  const keys = new Set<string>();
  let prevE = false;
  let prevQ = false;
  let calib: number | null = null;
  let best = 0;
  try {
    best = Number(localStorage.getItem(BEST_KEY) || 0) || 0;
  } catch {
    best = 0;
  }
  if (hud.best) hud.best.textContent = best > 0 ? String(Math.round(best)) : "—";

  let running = true;
  let last = performance.now();
  let acc = 0;

  function readTilt(e: DeviceOrientationEvent) {
    if (!inputBus.tiltOn) return;
    const ang = window.screen?.orientation?.angle ?? 0;
    const landscape = window.innerWidth > window.innerHeight;
    let tilt = e.gamma ?? 0;
    if (landscape) {
      if (ang === 90) tilt = e.beta ?? 0;
      else if (ang === 270 || ang === -90) tilt = -(e.beta ?? 0);
    }
    if (calib == null) calib = tilt;
    const centered = tilt - calib;
    const sign = inputBus.invertTilt ? 1 : -1;
    inputBus.tilt = clamp((sign * centered) / 28, -1, 1);
  }

  function onKeyDown(e: KeyboardEvent) {
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) {
      e.preventDefault();
    }
    keys.add(e.code);
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
  }
  function onBlur() {
    keys.clear();
    inputBus.gas = false;
    inputBus.brake = false;
    inputBus.padSteer = 0;
    inputBus.touchActive = false;
  }
  function onVis() {
    if (document.visibilityState === "visible" && sim.started) audio.resume();
  }

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  window.addEventListener("deviceorientation", readTilt);
  document.addEventListener("visibilitychange", onVis);
  const onResize = () => view.resize();
  window.addEventListener("resize", onResize);

  const probe: Probe = {
    getYaw: () => sim.yaw,
    getSpeed: () => sim.speed,
    setKeys: (codes: string[]) => {
      keys.clear();
      for (const c of codes) keys.add(c);
      inputBus.touchActive = false;
      inputBus.padSteer = 0;
    },
    setSteer: (v: number) => {
      inputBus.touchActive = true;
      inputBus.steerTouch = v;
    },
  };
  (window as unknown as { __lastDrive?: unknown }).__lastDrive = () => ({
    throttle: sim.throttle,
    brake: sim.brake,
    gear: sim.gear,
    rpm: Math.round(sim.rpm),
    speed: sim.speed,
    clutch: sim.clutch,
    started: sim.started,
    time: sim.time,
    x: sim.x,
    z: sim.z,
    edge: sim.edge,
    wheel: sim.wheel,
  });
  window.__controlsTest = probe;

  function sampleInput() {
    let steer = 0;
    if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
    if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;
    if (steer === 0 && inputBus.padSteer !== 0) steer = inputBus.padSteer;
    else if (steer === 0 && inputBus.touchActive) steer = inputBus.steerTouch;
    else if (steer === 0 && inputBus.tiltOn) steer = inputBus.tilt;

    let throttle = 0;
    if (keys.has("KeyW") || keys.has("ArrowUp")) throttle = 1;
    if (inputBus.gas) throttle = 1;
    let brake = 0;
    if (keys.has("KeyS") || keys.has("ArrowDown") || keys.has("Space")) brake = 1;
    if (inputBus.brake) brake = 1;

    let shift = 0;
    const eNow = keys.has("KeyE");
    const qNow = keys.has("KeyQ");
    if ((eNow && !prevE) || inputBus.shiftUp > 0) {
      shift += 1;
      if (inputBus.shiftUp > 0) inputBus.shiftUp -= 1;
    }
    if ((qNow && !prevQ) || inputBus.shiftDown > 0) {
      if (shift === 0) shift -= 1;
      if (inputBus.shiftDown > 0) inputBus.shiftDown -= 1;
    }
    prevE = eNow;
    prevQ = qNow;

    return {
      steer: clamp(steer, -1, 1),
      throttle,
      brake,
      sensitivity: inputBus.sensitivity,
      shift,
    };
  }

  function paintHud() {
    const kmh = sim.speed * 3.6;
    if (hud.speed) hud.speed.textContent = String(Math.round(kmh));
    if (hud.gear) hud.gear.textContent = sim.gear === 0 ? "N" : String(sim.gear);
    if (hud.rpm) {
      const pct = Math.min(1, Math.max(sim.rpm, sim.flare) / 7000);
      hud.rpm.style.transform = `scaleX(${pct.toFixed(3)})`;
      hud.rpm.style.background = sim.rpm > 6400 ? "var(--color-brake)" : "var(--color-accent)";
    }
    if (hud.lamp) {
      const on = sim.started && sim.rpm > 6100 && sim.gear > 0 && sim.gear < 6 && sim.throttle > 0.4;
      hud.lamp.style.opacity = on ? "1" : "0";
    }
    if (kmh > best + 0.5) {
      best = kmh;
      try {
        localStorage.setItem(BEST_KEY, String(Math.round(best)));
      } catch {
        /* ignore quota */
      }
      if (hud.best) hud.best.textContent = String(Math.round(best));
    }
  }

  function frame(now: number) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    acc += dt;
    const input = sampleInput();
    let steps = 0;
    let shiftLeft = input.shift;
    while (acc >= 1 / 60 && steps < 4) {
      stepSim(sim, 1 / 60, { ...input, shift: shiftLeft });
      shiftLeft = 0;
      acc -= 1 / 60;
      steps += 1;
    }
    view.update(sim, dt || 1 / 60);
    if (sim.started) {
      audio.update(Math.max(sim.rpm, sim.flare), sim.throttle, sim.speed, sim.overrun, sim.edge);
      if (sim.pops.length) {
        audio.pops(sim.pops);
        sim.pops.length = 0;
      }
      if (sim.gearPing) audio.click();
    }
    view.render();
    paintHud();
  }

  view.renderer.setAnimationLoop(frame);

  return {
    start() {
      audio.resume();
      sim.started = true;
      sim.flare = 2300;
      const DOE = DeviceOrientationEvent as unknown as {
        requestPermission?: () => Promise<string>;
      };
      if (typeof DOE.requestPermission === "function") {
        DOE.requestPermission()
          .then((s) => {
            if (s === "granted") inputBus.tiltOn = true;
          })
          .catch(() => {});
      }
    },
    setMuted(m: boolean) {
      audio.setMuted(m);
    },
    recenterTilt() {
      calib = null;
    },
    dispose() {
      running = false;
      view.renderer.setAnimationLoop(null);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      window.removeEventListener("deviceorientation", readTilt);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("resize", onResize);
      if (window.__controlsTest === probe) window.__controlsTest = undefined;
      audio.dispose();
      view.dispose();
    },
  };
}
