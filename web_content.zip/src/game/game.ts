import * as THREE from 'three'
import type { Renderer } from '../engine/renderer'
import { QUALITY_PRESETS } from '../engine/renderer'
import type { Input } from '../engine/input'
import type { AudioManager } from '../engine/audio'
import type { Quality, SaveStore } from '../engine/save'
import { Aircraft } from './aircraft'
import { ChaseCamera } from './chaseCamera'
import { altitudeAboveGround, createContact, detectGroundContact, timeToTerrain, Wreck } from './collision'
import { CONFIG } from './config'
import { FlightModel } from './flight'
import { Particles, type EmitOptions, type RGB } from './particles'
import { RingCourse } from './rings'
import { applyRingMiss, applyRingPass, cardinal, createRun, type RunState } from './rules'
import { Clouds, createLights, createSkyDome, SKY } from './sky'
import { groundHeight, terrainHeight, WATER_LEVEL } from './terrain'
import { TerrainView } from './terrainView'
import { tuning } from './tuning'

export type Mode = 'title' | 'playing' | 'paused' | 'crashing' | 'ended'
export type Warning = 'terrain' | 'stall' | 'ceiling' | null

export type Marker = {
  visible: boolean
  /** CSS pixels from the top-left of the viewport. */
  x: number
  y: number
  /** Arrow direction (radians, 0 = pointing right) when the target is off-screen. */
  angle: number
  onScreen: boolean
}

export type HudData = {
  speedKmh: number
  altitude: number
  agl: number
  heading: number
  compass: string
  throttle: number
  engine: number
  bankDeg: number
  pitchDeg: number
  warning: Warning
  ringDistance: number
  ring: Marker
  pipper: Marker
}

export type GameEvents = {
  ring(info: { points: number; perfect: boolean; multiplier: number; streak: number }): void
  missed(): void
  crashed(run: RunState): void
  ended(run: RunState): void
}

const START = { x: 450, z: 0, yaw: Math.PI / 2 }
const WORLD_UP = new THREE.Vector3(0, 1, 0)
const AXIS_Z = new THREE.Vector3(0, 0, -1)
const _v = new THREE.Vector3()
const _w = new THREE.Vector3()
const _ndc = new THREE.Vector3()
const _q = new THREE.Quaternion()
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v)

const marker = (): Marker => ({ visible: false, x: 0, y: 0, angle: 0, onScreen: false })

export class Game {
  mode: Mode = 'title'
  run: RunState = createRun()
  readonly hud: HudData = {
    speedKmh: 0, altitude: 0, agl: 0, heading: 0, compass: 'N', throttle: 0.5, engine: 0.5, bankDeg: 0, pitchDeg: 0,
    warning: null, ringDistance: 0, ring: marker(), pipper: marker(),
  }
  readonly flight = new FlightModel()
  readonly scene = new THREE.Scene()
  readonly chase = new ChaseCamera()

  private readonly terrain = new TerrainView()
  private readonly clouds = new Clouds(36)
  private readonly sky = createSkyDome()
  private readonly rings = new RingCourse(3)
  private readonly aircraft: Aircraft
  private readonly wreck = new Wreck()
  private readonly smoke = new Particles(1000, false)
  private readonly fire = new Particles(800, true)
  private readonly contact = createContact()

  private readonly prevPos = new THREE.Vector3()
  private readonly prevQuat = new THREE.Quaternion()
  private readonly renderPos = new THREE.Vector3()
  private readonly renderQuat = new THREE.Quaternion()
  private readonly titlePos = new THREE.Vector3()
  private readonly titleQuat = new THREE.Quaternion()

  private time = 0
  private crashClock = 0
  private warnClock = 0
  private spawnClock = 0
  private orbitAngle = 0
  private orbitRadius = 50
  private orbitElevation = 0.3
  private quality: Quality = 'medium'

  constructor(
    private readonly renderer: Renderer,
    private readonly input: Input,
    private readonly audio: AudioManager,
    model: THREE.Object3D,
    private readonly save: SaveStore,
    private readonly events: GameEvents,
  ) {
    const gl = renderer.gl
    this.aircraft = new Aircraft(model, gl.capabilities.getMaxAnisotropy())

    this.scene.add(this.sky, ...createLights(), this.terrain.group, this.clouds.group, this.rings.group, this.aircraft.root, this.smoke.points, this.fire.points)
    this.scene.fog = new THREE.Fog(SKY.horizon, 400, 2100)
    this.scene.background = SKY.horizon

    // Image-based lighting from the same sky so the metal airframe reflects it.
    const envScene = new THREE.Scene()
    envScene.add(createSkyDome())
    const pmrem = new THREE.PMREMGenerator(gl)
    this.scene.environment = pmrem.fromScene(envScene, 0, 0.1, 100).texture
    this.scene.environmentIntensity = 0.3
    // The airframe keeps a strong sky reflection; the terrain only gets a little ambient fill.
    const envMap = this.scene.environment
    this.aircraft.root.traverse(node => {
      const mesh = node as THREE.Mesh
      if (!mesh.isMesh) return
      for (const m of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
        const std = m as THREE.MeshStandardMaterial
        if (std.isMeshStandardMaterial) {
          std.envMap = envMap
          std.envMapIntensity = 1.15
        }
      }
    })
    pmrem.dispose()

    this.wreck.onImpact = (point, strength, water) => {
      if (strength < 5) return
      this.burstDust(point, Math.min(24, Math.round(strength * 0.7)), water, strength > 14 ? 1.3 : 0.8)
    }

    renderer.onResize(() => this.refreshViewport())
    this.setQuality(save.data.quality)
    this.toTitle()
  }

  // ─── lifecycle ──────────────────────────────────────────────────────────
  setQuality(quality: Quality): void {
    this.quality = quality
    const preset = QUALITY_PRESETS[quality]
    this.renderer.applyQuality(quality)
    this.terrain.radius = preset.terrainRadius
    ;(this.scene.fog as THREE.Fog).far = preset.fogFar
    this.clouds.setCount(preset.clouds)
    this.refreshViewport()
  }

  private refreshViewport(): void {
    const w = this.renderer.canvas.clientWidth || window.innerWidth
    const h = this.renderer.canvas.clientHeight || window.innerHeight
    this.chase.camera.aspect = w / h
    this.chase.camera.updateProjectionMatrix()
    for (const p of [this.smoke, this.fire]) p.setScale(this.renderer.pixelHeight, this.chase.camera.fov)
  }

  private spawnPosition(): THREE.Vector3 {
    return new THREE.Vector3(START.x, groundHeight(START.x, START.z) + CONFIG.world.startHeight, START.z)
  }

  /** Back to the showcase view behind the menu. */
  toTitle(): void {
    this.mode = 'title'
    this.run = createRun()
    this.smoke.clear()
    this.fire.clear()
    this.aircraft.setWrecked(false)
    this.rings.group.visible = false
    const pos = this.spawnPosition()
    this.titlePos.copy(pos)
    this.titleQuat.setFromAxisAngle(WORLD_UP, START.yaw)
    this.aircraft.setPose(this.titlePos, this.titleQuat)
    this.chase.shake = 0
    this.audio.silenceEngine()
    this.terrain.warm(pos.x, pos.z)
  }

  /** Begin a new flight. */
  start(): void {
    tuning.activate('run')
    this.run = createRun(tuning.unranked)
    this.run.phase = 'flying'
    this.smoke.clear()
    this.fire.clear()
    this.aircraft.setWrecked(false)
    this.rings.group.visible = true

    const pos = this.spawnPosition()
    const throttle = 0.5
    this.input.throttle = throttle
    const speed = CONFIG.flight.minSpeed + (CONFIG.flight.maxSpeed - CONFIG.flight.minSpeed) * throttle
    this.flight.assist = this.save.data.assist
    this.flight.reset(pos, START.yaw, speed, throttle)
    this.prevPos.copy(this.flight.position)
    this.prevQuat.copy(this.flight.quaternion)
    this.rings.reset(pos, this.flight.forward)
    this.terrain.warm(pos.x, pos.z)
    this.chase.shake = 0
    this.chase.reducedMotion = this.save.data.reducedMotion
    this.chase.snap(pos, this.flight.forward, this.flight.up)
    this.aircraft.setPose(pos, this.flight.quaternion)
    this.crashClock = 0
    this.warnClock = 0
    this.mode = 'playing'
    this.save.update({ flights: this.save.data.flights + 1 })
    this.audio.setPaused(false)
    this.audio.startEngine()
  }

  pause(): void {
    if (this.mode !== 'playing') return
    this.mode = 'paused'
    this.audio.setPaused(true)
  }

  resume(): void {
    if (this.mode !== 'paused') return
    this.mode = 'playing'
    this.audio.setPaused(false)
  }

  // ─── simulation (fixed step) ────────────────────────────────────────────
  step(dt: number): void {
    if (this.mode === 'playing') this.stepFlight(dt)
    else if (this.mode === 'crashing' || this.mode === 'ended') this.stepWreck(dt)
  }

  private controls() {
    const s = this.input.stick
    const sens = this.save.data.sensitivity
    const curve = (v: number) => Math.sign(v) * Math.pow(Math.abs(v), 1.35) * sens
    const roll = Math.max(-1, Math.min(1, curve(s.x)))
    const pitchStick = Math.max(-1, Math.min(1, curve(s.y)))
    // Classic: pulling the stick back (down) raises the nose.
    const pitch = this.save.data.invertY ? pitchStick : -pitchStick
    return { roll, pitch, throttle: this.input.throttle }
  }

  private stepFlight(dt: number): void {
    const f = this.flight
    this.prevPos.copy(f.position)
    this.prevQuat.copy(f.quaternion)
    f.assist = this.save.data.assist
    f.step(dt, this.controls())

    this.run.seconds += dt
    this.run.distance += f.speed * dt
    if (f.position.y > this.run.maxAltitude) this.run.maxAltitude = f.position.y

    const event = this.rings.check(this.prevPos, f.position)
    if (event?.type === 'pass') {
      const { points, perfect } = applyRingPass(this.run, event.centering)
      this.audio.play(perfect ? 'perfect' : 'ring')
      this.events.ring({ points, perfect, multiplier: this.run.multiplier, streak: this.run.streak })
    } else if (event?.type === 'miss') {
      applyRingMiss(this.run)
      this.events.missed()
    }

    if (detectGroundContact(this.prevPos, this.prevQuat, f.position, f.quaternion, f.speed, this.contact)) {
      this.crash()
    }
  }

  private crash(): void {
    const f = this.flight
    this.mode = 'crashing'
    this.run.phase = 'crashed'
    this.run.cause = this.contact.surface
    this.crashClock = 0
    this.audio.play('crash')
    this.audio.silenceEngine()
    this.aircraft.setWrecked(true)
    this.wreck.start(f.position, f.quaternion, f.forward, f.speed, this.contact.normal)
    this.explode(this.contact.point, this.contact.surface === 'water', this.contact.normal)
    this.chase.shake = this.save.data.reducedMotion ? 0 : 1.4
    // Hand the current chase view to the orbit camera without a jump.
    const cam = this.chase.camera.position
    this.orbitAngle = Math.atan2(cam.x - f.position.x, cam.z - f.position.z)
    const d = cam.distanceTo(f.position)
    this.orbitRadius = Math.max(20, d)
    this.orbitElevation = Math.asin(Math.max(-0.5, Math.min(0.9, (cam.y - f.position.y) / Math.max(1, d))))
    this.events.crashed(this.run)
  }

  private stepWreck(dt: number): void {
    this.wreck.step(dt)
    this.crashClock += dt
    if (this.mode === 'crashing' && ((this.wreck.settled && this.crashClock > 1.6) || this.crashClock > 4.2)) {
      this.mode = 'ended'
      this.events.ended(this.run)
    }
  }

  // ─── effects ────────────────────────────────────────────────────────────
  private explode(point: THREE.Vector3, water: boolean, normal: THREE.Vector3): void {
    const R = Math.random
    const dir = (spread: number): [number, number, number] => {
      const x = (R() - 0.5) * 2 * spread + normal.x
      const y = Math.abs((R() - 0.5) * 2 * spread) + normal.y * 1.2
      const z = (R() - 0.5) * 2 * spread + normal.z
      const l = Math.hypot(x, y, z) || 1
      return [x / l, y / l, z / l]
    }
    const flames = water ? 22 : 90
    for (let i = 0; i < flames; i += 1) {
      const [dx, dy, dz] = dir(1)
      const s = 10 + R() * 55
      this.fire.emit(point.x, point.y + 1, point.z, dx * s, dy * s, dz * s, {
        life: 0.5 + R() * 0.9, size0: 5 + R() * 6, size1: 14 + R() * 14,
        color0: [1, 0.85, 0.45], color1: [0.85, 0.18, 0.04], alpha0: 0.95, alpha1: 0, drag: 2.4,
      })
    }
    for (let i = 0; i < 46; i += 1) {
      const [dx, dy, dz] = dir(1.4)
      const s = 40 + R() * 90
      this.fire.emit(point.x, point.y + 1, point.z, dx * s, dy * s, dz * s, {
        life: 0.6 + R() * 0.9, size0: 1.6, size1: 0.5, color0: [1, 0.92, 0.65], color1: [1, 0.4, 0.1], alpha0: 1, alpha1: 0, gravity: -34,
      })
    }
    for (let i = 0; i < 64; i += 1) {
      const [dx, dy, dz] = dir(0.8)
      const s = 4 + R() * 22
      this.smoke.emit(point.x, point.y + 2, point.z, dx * s, dy * s + 4, dz * s, {
        life: 2.6 + R() * 2.6, size0: 6, size1: 26 + R() * 16, color0: [0.14, 0.13, 0.12], color1: [0.36, 0.35, 0.34],
        alpha0: 0.7, alpha1: 0, gravity: 5, drag: 0.7,
      })
    }
    this.burstDust(point, 34, water, 1.0)
    if (water) {
      for (let i = 0; i < 90; i += 1) {
        const a = R() * Math.PI * 2
        const s = 6 + R() * 26
        this.smoke.emit(point.x, point.y, point.z, Math.cos(a) * s * 0.5, 18 + R() * 34, Math.sin(a) * s * 0.5, {
          life: 1.4 + R() * 1.2, size0: 5, size1: 18, color0: [0.92, 0.97, 1], color1: [0.8, 0.9, 0.98], alpha0: 0.7, alpha1: 0, gravity: -26, drag: 0.3,
        })
      }
    }
  }

  private burstDust(point: THREE.Vector3, count: number, water: boolean, scale: number): void {
    const color: RGB = water ? [0.9, 0.96, 1] : [0.72, 0.62, 0.46]
    const end: RGB = water ? [0.8, 0.9, 0.98] : [0.62, 0.55, 0.43]
    for (let i = 0; i < count; i += 1) {
      const a = Math.random() * Math.PI * 2
      const s = (14 + Math.random() * 36) * scale
      this.smoke.emit(point.x, point.y + 1, point.z, Math.cos(a) * s, 3 + Math.random() * 10, Math.sin(a) * s, {
        life: 1.6 + Math.random() * 1.8, size0: 6 * scale, size1: (20 + Math.random() * 16) * scale, color0: color, color1: end,
        alpha0: 0.38, alpha1: 0, drag: 1.4,
      })
    }
  }

  private static readonly EXHAUST: EmitOptions = {
    life: 0.28, size0: 2.6, size1: 0.6, color0: [1, 0.7, 0.3], color1: [0.9, 0.2, 0.05], alpha0: 0.7, alpha1: 0,
  }
  private static readonly VAPOUR: EmitOptions = {
    life: 1.3, size0: 0.9, size1: 3.6, color0: [1, 1, 1], color1: [0.9, 0.95, 1], alpha0: 0.34, alpha1: 0,
  }
  private static readonly WRECK_SMOKE: EmitOptions = {
    life: 2.4, size0: 3, size1: 15, color0: [0.1, 0.1, 0.1], color1: [0.4, 0.4, 0.4], alpha0: 0.55, alpha1: 0, gravity: 4, drag: 0.4,
  }
  private static readonly WRECK_FIRE: EmitOptions = {
    life: 0.4, size0: 5, size1: 1.2, color0: [1, 0.7, 0.25], color1: [0.8, 0.15, 0.03], alpha0: 0.85, alpha1: 0, gravity: 10,
  }

  private flightEffects(frameSeconds: number): void {
    const f = this.flight
    const q = this.renderQuat
    // Exhaust glow trail.
    if (f.engine > 0.3) {
      _v.copy(Aircraft.NOZZLE).applyQuaternion(q).add(this.renderPos)
      this.fire.emit(_v.x, _v.y, _v.z, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, Game.EXHAUST)
    }
    // Wing-tip vapour while manoeuvring or very fast.
    const speed01 = clamp01((f.speed - CONFIG.flight.minSpeed) / (CONFIG.flight.maxSpeed - CONFIG.flight.minSpeed))
    const load = Math.abs(f.pitchRate) * 0.9 + Math.abs(f.rollRate) * 0.25
    if (!this.save.data.reducedMotion && f.speed > 70 && (load > 0.5 || speed01 > 0.85)) {
      for (const tip of Aircraft.WING_TIPS) {
        _v.copy(tip).applyQuaternion(q).add(this.renderPos)
        this.smoke.emit(_v.x, _v.y, _v.z, 0, 0, 0, Game.VAPOUR)
      }
    }
    // Dust or spray kicked up when flying low.
    const agl = altitudeAboveGround(f.position)
    if (agl < 55) {
      this.spawnClock += frameSeconds
      if (this.spawnClock > 0.05) {
        this.spawnClock = 0
        const x = this.renderPos.x + f.forward.x * 10
        const z = this.renderPos.z + f.forward.z * 10
        const water = terrainHeight(x, z) <= WATER_LEVEL
        const g = groundHeight(x, z)
        this.smoke.emit(x, g + 1, z, (Math.random() - 0.5) * 12, 2 + Math.random() * 4, (Math.random() - 0.5) * 12, {
          life: 1.4, size0: 5, size1: 22, color0: water ? [0.92, 0.97, 1] : [0.74, 0.65, 0.5], color1: water ? [0.85, 0.93, 1] : [0.66, 0.58, 0.46],
          alpha0: (0.45 * (55 - agl)) / 55, alpha1: 0, drag: 1,
        })
      }
    }
  }

  private wreckEffects(): void {
    const w = this.wreck
    if (this.crashClock > 9) return
    this.smoke.emit(w.position.x, w.position.y + 1, w.position.z, (Math.random() - 0.5) * 3, 5 + Math.random() * 4, (Math.random() - 0.5) * 3, Game.WRECK_SMOKE)
    if (!w.inWater && this.crashClock < 6) {
      this.fire.emit(w.position.x + (Math.random() - 0.5) * 3, w.position.y + 1, w.position.z + (Math.random() - 0.5) * 3, 0, 5 + Math.random() * 4, 0, Game.WRECK_FIRE)
    }
  }

  // ─── rendering ──────────────────────────────────────────────────────────
  render(alpha: number, frameSeconds: number): void {
    const dt = Math.min(frameSeconds, 0.1)
    const camera = this.chase.camera
    const paused = this.mode === 'paused'
    if (!paused) this.time += dt

    switch (this.mode) {
      case 'title': {
        const bob = Math.sin(this.time * 0.9)
        this.renderQuat.copy(this.titleQuat).multiply(_q.setFromAxisAngle(AXIS_Z, bob * 0.05))
        this.renderPos.copy(this.titlePos)
        this.renderPos.y += bob * 1.2
        this.aircraft.setPose(this.renderPos, this.renderQuat)
        this.aircraft.setEngine(0.35, this.time)
        this.chase.orbit(this.renderPos, 29, 2.35 + this.time * 0.09, 0.2 + Math.sin(this.time * 0.17) * 0.05)
        break
      }
      case 'playing':
      case 'paused': {
        const f = this.flight
        this.renderPos.lerpVectors(this.prevPos, f.position, alpha)
        this.renderQuat.slerpQuaternions(this.prevQuat, f.quaternion, alpha)
        this.aircraft.setPose(this.renderPos, this.renderQuat)
        this.aircraft.setEngine(f.engine, this.time)
        if (!paused) {
          const speed01 = clamp01((f.speed - CONFIG.flight.minSpeed) / (CONFIG.flight.maxSpeed - CONFIG.flight.minSpeed))
          this.chase.update(dt, this.renderPos, f.forward, f.up, speed01, this.time)
          this.flightEffects(dt)
          this.updateAlerts(dt)
          this.audio.setEngine(f.engine, clamp01(f.speed / 190))
        }
        break
      }
      case 'crashing':
      case 'ended': {
        const w = this.wreck
        this.aircraft.setPose(w.position, w.quaternion)
        this.renderPos.copy(w.position)
        this.chase.shake *= Math.exp(-dt * 2.2)
        this.orbitAngle += dt * 0.28
        this.orbitRadius += (62 - this.orbitRadius) * (1 - Math.exp(-dt * 1.6))
        this.orbitElevation += (0.38 - this.orbitElevation) * (1 - Math.exp(-dt * 0.8))
        this.chase.orbit(w.position, this.orbitRadius, this.orbitAngle, this.orbitElevation)
        if (this.chase.shake > 0.02 && !this.save.data.reducedMotion) {
          camera.position.x += Math.sin(this.time * 53) * this.chase.shake
          camera.position.y += Math.sin(this.time * 47 + 1) * this.chase.shake
        }
        this.wreckEffects()
        break
      }
    }

    this.applyViewOffset()

    // World follows the player.
    const fx = this.mode === 'title' ? this.titlePos : this.renderPos
    this.terrain.update(fx.x, fx.z, this.mode === 'playing' ? 2 : 4)
    this.clouds.update(camera.position.x, camera.position.z)
    this.sky.position.copy(camera.position)
    this.sky.scale.setScalar(1000)
    this.rings.update(this.time)
    if (!paused) {
      this.smoke.update(dt)
      this.fire.update(dt)
    }

    camera.updateMatrixWorld()
    camera.matrixWorldInverse.copy(camera.matrixWorld).invert()
    this.updateHud()
    this.renderer.render(this.scene, camera)
  }

  private viewKey = ''

  /** Slide the scene away from the menu panels so the aircraft stays visible beside them. */
  private applyViewOffset(): void {
    const camera = this.chase.camera
    const w = this.renderer.canvas.clientWidth || window.innerWidth
    const h = this.renderer.canvas.clientHeight || window.innerHeight
    let x = 0
    let y = 0
    if (this.mode === 'title') {
      if (w > h) x = -w * 0.2
      else y = h * 0.2
    } else if (this.mode === 'ended') {
      y = h * 0.22
    }
    const key = `${w}x${h}:${x}:${y}`
    if (key === this.viewKey) return
    this.viewKey = key
    if (x === 0 && y === 0) camera.clearViewOffset()
    else camera.setViewOffset(w, h, x, y, w, h)
  }

  /** Warning state and its beeps. */
  private updateAlerts(dt: number): void {
    const f = this.flight
    let warning: Warning = null
    let interval = 1
    const tt = timeToTerrain(f.position, f.forward, f.speed, 5, 24)
    if (tt < Infinity) {
      warning = 'terrain'
      interval = 0.18 + tt * 0.1
    } else if (f.stalled) {
      warning = 'stall'
      interval = 0.45
    } else if (f.overCeiling) {
      warning = 'ceiling'
      interval = 0.9
    }
    this.hud.warning = warning
    if (warning) {
      this.warnClock += dt
      if (this.warnClock >= interval) {
        this.warnClock = 0
        this.audio.play(warning === 'stall' ? 'stall' : 'warn')
      }
    } else {
      this.warnClock = 0
    }
  }

  /** Project a world point to CSS pixels, clamping to the screen edge when it is off-screen. */
  private project(target: THREE.Vector3, out: Marker, edge: boolean): void {
    const camera = this.chase.camera
    const w = this.renderer.canvas.clientWidth || window.innerWidth
    const h = this.renderer.canvas.clientHeight || window.innerHeight
    _w.copy(target).applyMatrix4(camera.matrixWorldInverse)
    const behind = _w.z > 0
    _ndc.copy(target).project(camera)
    let x = _ndc.x
    let y = _ndc.y
    if (behind) {
      x = -x
      y = -y
    }
    const inside = !behind && Math.abs(x) < 0.9 && Math.abs(y) < 0.82
    out.onScreen = inside
    out.visible = inside || edge
    if (!inside) {
      // Keep edge arrows out of the thumb zones at the bottom corners.
      const s = Math.max(Math.abs(x) / 0.86, Math.abs(y) / (y < 0 ? 0.45 : 0.78), 1e-4)
      x /= s
      y /= s
      if (behind && Math.abs(_ndc.x) < 1e-3 && Math.abs(_ndc.y) < 1e-3) y = -0.78
    }
    out.x = (x * 0.5 + 0.5) * w
    out.y = (-y * 0.5 + 0.5) * h
    out.angle = Math.atan2(-y, x)
  }

  private updateHud(): void {
    const hud = this.hud
    const f = this.flight
    hud.throttle = this.input.throttle
    if (this.mode === 'playing' || this.mode === 'paused') {
      hud.speedKmh = f.speed * 3.6
      hud.altitude = f.position.y
      hud.agl = altitudeAboveGround(f.position)
      hud.heading = f.heading
      hud.compass = cardinal(f.heading)
      hud.engine = f.engine
      hud.bankDeg = (f.bank * 180) / Math.PI
      hud.pitchDeg = (f.pitchAngle * 180) / Math.PI
      const ring = this.rings.current
      if (ring) {
        hud.ringDistance = ring.pos.distanceTo(this.renderPos)
        this.project(ring.pos, hud.ring, true)
      } else {
        hud.ring.visible = false
      }
      _v.copy(f.forward).multiplyScalar(500).add(this.renderPos)
      this.project(_v, hud.pipper, false)
    } else {
      hud.ring.visible = false
      hud.pipper.visible = false
      hud.warning = null
    }
  }

  /** Quality currently applied (for the settings screen). */
  get currentQuality(): Quality {
    return this.quality
  }
}
