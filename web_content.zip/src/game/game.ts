import { Renderer } from './render';
import { World, clamp, type Cfg, type Ent } from './world';
import { aiTick } from './ai';
import type { Link } from './net';
import { UNITS, BLD, FACS, ERAS, POW, PCOL_CSS, POP_CAP, fmOf, trainList, buildOpts, unitName, bldName } from './data';
import { sfx, vibrate } from './audio';

export interface HudState {
  res: number; pop: number; cap: number; pows: { ic: string; n: string; cd: number; max: number; ds: string }[]; powSel: number; placing: string | null; am: boolean; box: boolean; hint: string;
  toasts: { id: number; s: string; bad: boolean }[]; lost: boolean; over: boolean; paused: boolean; buffT: number;
  sel: null | { kind: 'units'; count: number; name: string; hp: number; mhp: number; hasWk: boolean; list: string }
  | { kind: 'bld'; id: number; name: string; hp: number; mhp: number; cons: number; q: { n: string; ic: string; p: number }[]; opts: { u: string; n: string; ic: string; cost: number; ok: boolean }[] };
  build: { t: string; n: string; cost: number; ok: boolean; ic: string }[];
}
export interface EndInfo { win: boolean; text: string; stats: string[] }
interface Opts { cfg: Cfg; role: 'solo' | 'host' | 'client'; gl: HTMLCanvasElement; ov: HTMLCanvasElement; touch: HTMLElement; links?: Map<number, Link>; link?: Link; onEnd: (e: EndInfo) => void }

export class Game {
  world: World; R: Renderer; cfg: Cfg; role: Opts['role']; local: number; links: Map<number, Link>; clientLink?: Link;
  sel = new Set<number>(); placing: string | null = null; powSel = -1; am = false; box = false; paused = false; over = false; endSent = false;
  toasts: { id: number; s: string; bad: boolean; t: number }[] = []; tid = 1;
  ov: HTMLCanvasElement; ctx: CanvasRenderingContext2D; touch: HTMLElement; mini: HTMLCanvasElement | null = null; miniBg: HTMLCanvasElement | null = null;
  raf = 0; last = 0; acc = 0; snapT = 0; running = true; frame = 0; ac = new AbortController(); dpr = 1; onEnd: Opts['onEnd'];
  ptrs = new Map<number, { x: number; y: number; sx: number; sy: number; t: number; type: string; btn: number; moved: number; pan: boolean }>();
  gest: { d: number; a: number; mx: number; my: number } | null = null; multi = false; boxRect: { x0: number; y0: number; x1: number; y1: number } | null = null;
  keys = new Set<string>(); marks: { x: number; z: number; t: number; c: string }[] = []; hover: [number, number] | null = null; lastTap = { t: 0, id: 0 };

  constructor(o: Opts) {
    this.cfg = o.cfg; this.role = o.role; this.local = o.cfg.local; this.onEnd = o.onEnd; this.ov = o.ov; this.touch = o.touch; this.ctx = o.ov.getContext('2d')!;
    this.links = o.links || new Map(); this.clientLink = o.link;
    this.world = new World(o.cfg, o.role);
    if (o.role === 'client') this.world.initClientMines([]); else this.world.aiHook = aiTick;
    this.world.onEvent = ev => this.onEv(ev);
    this.world.onMsg = (pi, s, bad) => { if (pi === this.local) this.toast(s, bad); else this.links.get(pi)?.send({ t: 'msg', s, bad }); };
    this.R = new Renderer(o.gl); this.R.loadMap(this.world);
    const st = this.world.map.starts[this.local]; this.R.cx = st.x; this.R.cz = st.z; this.R.yaw = Math.atan2(st.x, st.z); this.R.dist = 50;
    this.buildMiniBg();
    this.bindInput();
    if (o.role === 'host') {
      this.links.forEach((l, idx) => {
        l.onmsg = m => { if (m.t === 'cmd') this.world.exec(idx, m.c); };
        l.onclose = () => { const p = this.world.players[idx]; if (p && p.alive && p.ai < 0) { p.ai = 1; this.toast(p.name + ' غادر - تولى الكمبيوتر جيشه', true); } };
      });
    }
    if (o.role === 'client' && o.link) {
      o.link.onmsg = m => {
        if (m.t === 's') this.world.applySnap(m); else if (m.t === 'msg') this.toast(m.s, m.bad);
        else if (m.t === 'end') this.finish(m.w);
      };
      o.link.onclose = () => { if (!this.over) { this.over = true; this.endSent = true; this.onEnd({ win: false, text: 'انقطع الاتصال بالمضيف', stats: [] }); } };
    }
    this.resize(); this.last = performance.now(); this.raf = requestAnimationFrame(this.loop);
  }
  destroy() {
    this.running = false; cancelAnimationFrame(this.raf); this.ac.abort();
    this.links.forEach(l => { l.onclose = () => { }; l.close(); }); if (this.clientLink) { this.clientLink.onclose = () => { }; this.clientLink.close(); }
    this.R.dispose();
  }
  toast(s: string, bad = false) { this.toasts.push({ id: this.tid++, s, bad, t: performance.now() }); if (this.toasts.length > 4) this.toasts.shift(); sfx(bad ? 'bad' : 'ok'); }
  resize() {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2); const w = this.ov.clientWidth, h = this.ov.clientHeight;
    this.ov.width = w * this.dpr; this.ov.height = h * this.dpr; this.R.resize();
  }

  /* ---------- events ---------- */
  onEv(ev: any) {
    if (ev.k === 'end') { this.finish(ev.w); return; }
    if (ev.k === 'elim' || ev.k === 'rm') return;
    this.R.event(ev);
    const d = Math.hypot((ev.x ?? this.R.cx) - this.R.cx, (ev.z ?? this.R.cz) - this.R.cz); if (d > 90) return;
    const v = 1 / (1 + d / 50);
    if (ev.k === 'x') { if (ev.f === 'big') { sfx('big', v); vibrate(40); } else if (ev.f === 'boom') sfx('boom', v); }
    else if (ev.k === 'p' && !ev.rain) sfx(ev.p === 'bullet' ? 'bullet' : ev.p === 'arrow' ? 'arrow' : ev.p === 'shell' || ev.p === 'arty' ? 'shell' : ev.p === 'rocket' || ev.p === 'missile' || ev.p === 'arcrocket' ? 'rocket' : 'bullet', v * 0.8);
  }
  finish(w: number) {
    if (this.endSent) return; this.endSent = true; this.over = true;
    if (this.role === 'host') this.links.forEach(l => l.send({ t: 'end', w }));
    const win = w === this.local; const me = this.world.players[this.local]; const mins = Math.floor(this.world.time / 60), secs = Math.floor(this.world.time % 60);
    sfx(win ? 'win' : 'bad');
    setTimeout(() => this.onEnd({
      win, text: win ? 'النصر! دمّرت جميع الأعداء' : w >= 0 ? `الفائز: ${this.world.players[w].name} (${FACS[this.world.players[w].fac].n})` : 'انتهت المعركة',
      stats: [`⏱ مدة المعركة: ${mins}:${String(secs).padStart(2, '0')}`, `☠ وحدات دمّرتها: ${me.kills}`, `💔 خسائرك: ${me.lost}`, `🏭 وحدات أنتجتها: ${me.made}`],
    }), 1800);
  }

  /* ---------- commands ---------- */
  cmd(c: any) { if (this.role === 'client') this.clientLink?.send({ t: 'cmd', c }); else this.world.exec(this.local, c); }
  selected(): Ent[] { const o: Ent[] = []; for (const id of this.sel) { const e = this.world.ents.get(id); if (e && e.hp > 0 && e.own === this.local) o.push(e); } return o; }
  select(ids: number[]) { this.sel = new Set(ids); this.cancelModes(); sfx('click'); }
  cancelModes() { this.placing = null; this.powSel = -1; this.R.setGhost(0, 0, 0, null); }
  me() { return this.world.players[this.local]; }
  train(u: string) { const b = this.selected()[0]; if (b && b.b) this.cmd({ k: 'train', b: b.id, u }); }
  cancelQ(i: number) { const b = this.selected()[0]; if (b && b.b) this.cmd({ k: 'cancel', b: b.id, i }); }
  startPlace(t: string) { this.cancelModes(); this.placing = t; }
  usePower(i: number) {
    const pid = FACS[this.me().fac].pw[i]; const pw = POW[pid]; if (!pw) return;
    if (this.me().pcd[i] > 0) { this.toast('القدرة قيد التبريد', true); return; }
    if (pw.t === 'strike' || pw.t === 'spawn') { this.cancelModes(); this.powSel = i; } else this.cmd({ k: 'pow', i });
  }
  toggleAm() { this.am = !this.am; this.cancelModes(); }
  toggleBox() { this.box = !this.box; this.cancelModes(); }
  selectAll() { const ids: number[] = []; this.world.ents.forEach(e => { if (e.own === this.local && !e.b && !e.mine && UNITS[e.t].cls !== 'wk') ids.push(e.id); }); if (!ids.length) this.world.ents.forEach(e => { if (e.own === this.local && !e.b && !e.mine) ids.push(e.id); }); this.select(ids); }
  stopSel() { const ids = this.selected().filter(e => !e.b).map(e => e.id); if (ids.length) this.cmd({ k: 'stop', ids }); }
  centerOn(x: number, z: number) { this.R.cx = x; this.R.cz = z; }
  goBase() { const st = this.world.map.starts[this.local]; const hq = [...this.world.ents.values()].find(e => e.own === this.local && e.t === 'hq'); this.centerOn(hq ? hq.x : st.x, hq ? hq.z : st.z); }

  /* ---------- picking ---------- */
  pick(x: number, y: number): Ent | null {
    const R = this.R; const a = R.project(R.cx, 0, R.cz), b = R.project(R.cx + 1, 0, R.cz); const ppu = Math.max(4, Math.hypot(a[0] - b[0], a[1] - b[1]));
    let best: Ent | null = null, bs = 1e9;
    this.world.ents.forEach(e => {
      const p = R.project(e.x, e.y + (e.b || e.mine ? 1.5 : 1.2), e.z); if (!p[2]) return;
      const rad = Math.max(e.b || e.mine ? 30 : 26, ppu * (e.b || e.mine ? e.sz / 2 + 0.5 : 1.3) + 8); const d = Math.hypot(p[0] - x, p[1] - y); if (d > rad) return;
      const s = (d / rad) * (e.b || e.mine ? 1.2 : 1); if (s < bs) { bs = s; best = e; }
    });
    return best;
  }
  selectBox(r: { x0: number; y0: number; x1: number; y1: number }) {
    const x0 = Math.min(r.x0, r.x1), x1 = Math.max(r.x0, r.x1), y0 = Math.min(r.y0, r.y1), y1 = Math.max(r.y0, r.y1); const ids: number[] = [];
    this.world.ents.forEach(e => { if (e.own !== this.local || e.b || e.mine) return; const p = this.R.project(e.x, e.y + 1, e.z); if (p[0] >= x0 && p[0] <= x1 && p[1] >= y0 && p[1] <= y1) ids.push(e.id); });
    if (ids.length) this.select(ids);
  }
  tap(x: number, y: number, btn: number, type: string) {
    const R = this.R; const g = R.groundAt(x, y);
    if (this.placing) { if (g) { this.cmd({ k: 'build', t: this.placing, x: g[0], z: g[1], ids: this.selected().filter(e => !e.b && UNITS[e.t].cls === 'wk').map(e => e.id) }); this.marks.push({ x: g[0], z: g[1], t: 0, c: '#ffd35a' }); } this.cancelModes(); return; }
    if (this.powSel >= 0) { if (g) this.cmd({ k: 'pow', i: this.powSel, x: g[0], z: g[1] }); this.cancelModes(); return; }
    const pick = this.pick(x, y); const sel = this.selected(); const units = sel.filter(e => !e.b);
    const mouseSelect = type === 'mouse' && btn === 0; const mouseCmd = type === 'mouse' && btn === 2;
    const doSelect = () => {
      if (pick && pick.own === this.local && !pick.mine) {
        const now = performance.now();
        if (!pick.b && this.lastTap.id === pick.id && now - this.lastTap.t < 380) {
          const ids: number[] = []; this.world.ents.forEach(e => { if (e.own === this.local && e.t === pick.t) { const p = R.project(e.x, 1, e.z); if (p[2]) ids.push(e.id); } }); this.select(ids);
        } else this.select([pick.id]);
        this.lastTap = { t: now, id: pick.id };
      } else if (pick && !pick.mine && pick.own !== this.local) { /* enemy: nothing to select */ if (!units.length) this.sel.clear(); }
      else this.sel.clear();
    };
    const command = (): boolean => {
      if (!units.length) return false;
      const ws = units.filter(e => UNITS[e.t].cls === 'wk'), army = units.filter(e => UNITS[e.t].cls !== 'wk');
      if (pick && pick.mine) { if (ws.length) { this.cmd({ k: 'gather', ids: ws.map(e => e.id), tgt: pick.id }); this.marks.push({ x: pick.x, z: pick.z, t: 0, c: '#ffd35a' }); } if (army.length && g) this.cmd({ k: 'move', ids: army.map(e => e.id), x: pick.x, z: pick.z }); return true; }
      if (pick && pick.own !== this.local && pick.own >= 0 && pick.hp > 0) {
        if (army.length) { this.cmd({ k: 'attack', ids: army.map(e => e.id), tgt: pick.id }); this.marks.push({ x: pick.x, z: pick.z, t: 0, c: '#ff5a4a' }); }
        if (ws.length && !army.length && g) this.cmd({ k: 'move', ids: ws.map(e => e.id), x: g[0], z: g[1] }); return true;
      }
      if (pick && pick.own === this.local && pick.b && pick.cons < 1 && ws.length) { this.cmd({ k: 'help', ids: ws.map(e => e.id), b: pick.id }); return true; }
      if (g) { this.cmd({ k: this.am ? 'amove' : 'move', ids: units.map(e => e.id), x: g[0], z: g[1] }); this.marks.push({ x: g[0], z: g[1], t: 0, c: this.am ? '#ff9a4a' : '#7dff9a' }); this.am = false; return true; }
      return false;
    };
    if (mouseSelect) { doSelect(); return; }
    if (mouseCmd) { command(); return; }
    // touch
    if (pick && pick.own === this.local && !pick.mine) {
      if (pick.b && pick.cons < 1 && units.some(e => UNITS[e.t].cls === 'wk')) { command(); return; }
      doSelect(); return;
    }
    if (command()) return;
    this.sel.clear();
  }

  /* ---------- input ---------- */
  pan(dx: number, dy: number) {
    const R = this.R; const k = (R.dist * 0.82) / R.H; const kv = k / Math.sin(R.pitch);
    R.cx += -Math.cos(R.yaw) * dx * k - Math.sin(R.yaw) * dy * kv; R.cz += Math.sin(R.yaw) * dx * k - Math.cos(R.yaw) * dy * kv;
  }
  private rel(e: PointerEvent) { const r = this.touch.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  bindInput() {
    const sg = { signal: this.ac.signal }; const el = this.touch;
    el.addEventListener('contextmenu', e => e.preventDefault(), sg);
    el.addEventListener('pointerdown', e => {
      el.setPointerCapture(e.pointerId); const [x, y] = this.rel(e);
      this.ptrs.set(e.pointerId, { x, y, sx: x, sy: y, t: performance.now(), type: e.pointerType, btn: e.button, moved: 0, pan: false });
      if (this.ptrs.size === 2) { this.multi = true; this.boxRect = null; const [a, b] = [...this.ptrs.values()]; this.gest = { d: Math.hypot(a.x - b.x, a.y - b.y), a: Math.atan2(b.y - a.y, b.x - a.x), mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 }; }
    }, sg);
    el.addEventListener('pointermove', e => {
      const [x, y] = this.rel(e); const p = this.ptrs.get(e.pointerId);
      if (!p) { this.hover = [x, y]; if (this.placing && e.pointerType === 'mouse') this.updateGhost(x, y); return; }
      const dx = x - p.x, dy = y - p.y; p.x = x; p.y = y; p.moved = Math.max(p.moved, Math.hypot(x - p.sx, y - p.sy)); this.hover = [x, y];
      if (this.ptrs.size >= 2 && this.gest) {
        const [a, b] = [...this.ptrs.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y), an = Math.atan2(b.y - a.y, b.x - a.x), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        if (d > 10 && this.gest.d > 10) this.R.dist = clamp(this.R.dist * (this.gest.d / d), 20, 120);
        let da = an - this.gest.a; if (da > Math.PI) da -= Math.PI * 2; if (da < -Math.PI) da += Math.PI * 2; this.R.yaw -= da;
        this.pan(mx - this.gest.mx, my - this.gest.my); this.gest = { d, a: an, mx, my }; return;
      }
      if (this.multi) return;
      const wantBox = (p.type === 'mouse' && p.btn === 0 && !this.placing && this.powSel < 0) || (p.type !== 'mouse' && this.box);
      if (wantBox && p.moved > 8) { this.boxRect = { x0: p.sx, y0: p.sy, x1: x, y1: y }; return; }
      if ((p.type !== 'mouse' && p.moved > 9) || (p.type === 'mouse' && p.btn !== 0 && p.moved > 7)) { p.pan = true; this.pan(dx, dy); }
      if (this.placing && p.type === 'mouse') this.updateGhost(x, y);
    }, sg);
    const up = (e: PointerEvent) => {
      const p = this.ptrs.get(e.pointerId); if (!p) return; this.ptrs.delete(e.pointerId);
      if (this.ptrs.size < 2) this.gest = null; if (this.ptrs.size === 0) { const was = this.multi; this.multi = false; if (was) { this.boxRect = null; return; } } else return;
      if (e.type === 'pointercancel') { this.boxRect = null; return; }
      if (this.boxRect) { this.selectBox(this.boxRect); this.boxRect = null; if (this.box) this.box = false; return; }
      if (p.moved < 10 && !p.pan) this.tap(p.x, p.y, p.btn, p.type);
    };
    el.addEventListener('pointerup', up, sg); el.addEventListener('pointercancel', up, sg);
    el.addEventListener('wheel', e => { e.preventDefault(); this.R.dist = clamp(this.R.dist * (1 + Math.sign(e.deltaY) * 0.1), 20, 120); }, { ...sg, passive: false });
    window.addEventListener('keydown', e => { this.keys.add(e.key.toLowerCase()); if (e.key === 'Escape') { this.cancelModes(); this.sel.clear(); } }, sg);
    window.addEventListener('keyup', e => this.keys.delete(e.key.toLowerCase()), sg);
    window.addEventListener('resize', () => this.resize(), sg);
  }
  updateGhost(x: number, y: number) {
    if (!this.placing) return; const g = this.R.groundAt(x, y); if (!g) return;
    this.R.setGhost(g[0], g[1], BLD[this.placing].sz, !this.world.canPlace(this.placing, g[0], g[1], this.local));
  }
  setMini(c: HTMLCanvasElement | null) {
    this.mini = c; if (!c) return; const move = (e: PointerEvent) => { if (e.buttons === 0 && e.type !== 'pointerdown') return; const r = c.getBoundingClientRect(); const fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height; const s = this.world.map.size; this.centerOn((fx - 0.5) * s, (fy - 0.5) * s); };
    c.addEventListener('pointerdown', move, { signal: this.ac.signal }); c.addEventListener('pointermove', move, { signal: this.ac.signal });
  }

  /* ---------- loop ---------- */
  loop = (t: number) => {
    if (!this.running) return; this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.1, (t - this.last) / 1000); this.last = t; this.frame++;
    const w = this.world;
    if (this.role !== 'client' && !(this.paused && this.role === 'solo')) {
      this.acc += dt; let n = 0; while (this.acc >= 1 / 30 && n < 4) { w.step(1 / 30); this.acc -= 1 / 30; n++; } if (n === 4) this.acc = 0;
      if (this.role === 'host') {
        this.snapT += dt; if (this.snapT >= 0.1) { this.snapT = 0; const s = JSON.stringify(w.snapshot()); this.links.forEach(l => { if (l.open && l.buffered < 300000) l.send(s); }); }
      } else w.evs.length = 0;
    }
    for (const id of this.sel) if (!w.ents.has(id)) this.sel.delete(id);
    // keyboard camera
    const R = this.R; const sp = R.dist * 0.9 * dt;
    if (this.keys.size) {
      const k = this.keys; const fx = -Math.sin(R.yaw), fz = -Math.cos(R.yaw), rx = Math.cos(R.yaw), rz = -Math.sin(R.yaw);
      if (k.has('w') || k.has('arrowup')) { R.cx += fx * sp; R.cz += fz * sp; } if (k.has('s') || k.has('arrowdown')) { R.cx -= fx * sp; R.cz -= fz * sp; }
      if (k.has('d') || k.has('arrowright')) { R.cx += rx * sp; R.cz += rz * sp; } if (k.has('a') || k.has('arrowleft')) { R.cx -= rx * sp; R.cz -= rz * sp; }
      if (k.has('q')) R.yaw -= dt * 1.5; if (k.has('e')) R.yaw += dt * 1.5; if (k.has('+') || k.has('=')) R.dist *= 1 - dt; if (k.has('-')) R.dist *= 1 + dt;
    }
    R.sync(w, dt); R.draw(dt); this.drawOv(dt); if (this.frame % 5 === 0) this.drawMini();
  };

  /* ---------- overlay ---------- */
  drawOv(dt: number) {
    const c = this.ctx, R = this.R, w = this.world; c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); c.clearRect(0, 0, R.W, R.H);
    const a = R.project(R.cx, 0, R.cz), b = R.project(R.cx + 1, 0, R.cz); const ppu = Math.hypot(a[0] - b[0], a[1] - b[1]);
    let n = 0;
    w.ents.forEach(e => {
      if (e.mine) return; const sel = this.sel.has(e.id); const dmg = e.hp < e.mhp - 0.5; const building = e.b && e.cons < 1;
      if (!sel && !dmg && !building) return; if (++n > 260) return;
      const p = R.project(e.x, 0, e.z); if (!p[2]) return; const rad = Math.max(10, ppu * (e.b ? e.sz * 0.62 : UNITS[e.t].cls === 'sge' || UNITS[e.t].cls === 'arm' ? 2.1 : 1.1));
      if (sel) { c.strokeStyle = '#6dff8a'; c.lineWidth = 2; c.beginPath(); c.ellipse(p[0], p[1], rad, rad * 0.55, 0, 0, Math.PI * 2); c.stroke(); }
      const top = R.project(e.x, (e.b ? e.sz * 0.9 + 1 : e.air ? e.y + 3 : 3.2), e.z); const bw = Math.max(26, rad * 1.5), bx = top[0] - bw / 2, by = top[1] - 4;
      c.fillStyle = 'rgba(0,0,0,.65)'; c.fillRect(bx - 1, by - 1, bw + 2, 6); const f = clamp(e.hp / e.mhp, 0, 1);
      c.fillStyle = e.own === this.local ? (f > 0.5 ? '#43d96a' : f > 0.25 ? '#e8c53a' : '#e8503a') : PCOL_CSS[e.own % 4]; c.fillRect(bx, by, bw * f, 4);
      if (building) { c.fillStyle = '#ffd35a'; c.fillRect(bx, by + 6, bw * e.cons, 3); }
    });
    // production bars for selected building
    for (let i = this.marks.length - 1; i >= 0; i--) {
      const m = this.marks[i]; m.t += dt; if (m.t > 0.7) { this.marks.splice(i, 1); continue; }
      const p = R.project(m.x, 0, m.z); const r = 8 + m.t * 26; c.strokeStyle = m.c; c.globalAlpha = 1 - m.t / 0.7; c.lineWidth = 3; c.beginPath(); c.ellipse(p[0], p[1], r, r * 0.55, 0, 0, 7); c.stroke(); c.globalAlpha = 1;
    }
    if (this.powSel >= 0 && this.hover) {
      const pw = POW[FACS[this.me().fac].pw[this.powSel]]; const g = R.groundAt(this.hover[0], this.hover[1]);
      if (g) { const p = R.project(g[0], 0, g[1]); const r = ppu * (pw.rad || 4); c.strokeStyle = '#ff6a4a'; c.fillStyle = 'rgba(255,80,50,.18)'; c.lineWidth = 3; c.beginPath(); c.ellipse(p[0], p[1], r, r * 0.55, 0, 0, 7); c.fill(); c.stroke(); }
    }
    if (this.boxRect) { const r = this.boxRect; c.strokeStyle = '#8dff9a'; c.fillStyle = 'rgba(120,255,140,.15)'; c.lineWidth = 2; c.fillRect(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0); c.strokeRect(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0); }
  }
  buildMiniBg() {
    const m = this.world.map; const c = document.createElement('canvas'); c.width = c.height = 160; const x = c.getContext('2d')!; const k = 160 / m.size; const era = ERAS[this.world.era];
    x.fillStyle = `rgb(${era.gr.map(v => Math.round(v * 255)).join(',')})`; x.fillRect(0, 0, 160, 160);
    const P = (v: number) => (v + m.size / 2) * k;
    x.fillStyle = '#2c6fb0'; for (const r of m.water) x.fillRect(P(r.x - r.w / 2), P(r.z - r.h / 2), r.w * k, r.h * k);
    x.fillStyle = '#8a6a40'; for (const r of m.bridges) x.fillRect(P(r.x - r.w / 2), P(r.z - r.h / 2), r.w * k, r.h * k);
    x.fillStyle = '#6a665e'; for (const r of m.rocks) { x.beginPath(); x.arc(P(r.x), P(r.z), r.r * k, 0, 7); x.fill(); }
    x.fillStyle = 'rgba(30,90,30,.55)'; for (const r of m.forests) { x.beginPath(); x.arc(P(r.x), P(r.z), r.r * k, 0, 7); x.fill(); }
    this.miniBg = c;
  }
  drawMini() {
    const c = this.mini; if (!c || !this.miniBg) return; const x = c.getContext('2d')!; const m = this.world.map; const W = c.width; const k = W / m.size; const P = (v: number) => (v + m.size / 2) * k;
    x.drawImage(this.miniBg, 0, 0, W, W);
    this.world.ents.forEach(e => {
      if (e.mine) { x.fillStyle = '#ffd23a'; x.fillRect(P(e.x) - 2, P(e.z) - 2, 4, 4); return; }
      x.fillStyle = PCOL_CSS[e.own % 4]; const s = e.b ? Math.max(4, e.sz * k) : 2.4; x.fillRect(P(e.x) - s / 2, P(e.z) - s / 2, s, s);
    });
    const R = this.R; const pts = [[0, 0], [R.W, 0], [R.W, R.H], [0, R.H]].map(([px, py]) => R.groundAt(px, py));
    if (pts.every(p => p)) { x.strokeStyle = '#fff'; x.lineWidth = 1.5; x.beginPath(); pts.forEach((p, i) => { const X = P(clamp(p![0], -m.size / 2, m.size / 2)), Y = P(clamp(p![1], -m.size / 2, m.size / 2)); if (i) x.lineTo(X, Y); else x.moveTo(X, Y); }); x.closePath(); x.stroke(); }
  }

  /* ---------- HUD state ---------- */
  hud(): HudState {
    const w = this.world, p = this.me(), f = FACS[p.fac], fm = fmOf(p.fac); const now = performance.now();
    this.toasts = this.toasts.filter(t => now - t.t < 3200);
    const sel = this.selected(); let s: HudState['sel'] = null;
    if (sel.length === 1 && sel[0].b) {
      const b = sel[0]; const list = b.cons >= 1 ? trainList(p.fac, b.t) : [];
      s = { kind: 'bld', id: b.id, name: bldName(w.era, b.t), hp: b.hp, mhp: b.mhp, cons: b.cons, q: b.q.map(q => ({ n: unitName(p.fac, q.u), ic: UNITS[q.u].ic, p: q.p })), opts: list.map(u => { const c = Math.round(UNITS[u].cost * fm.cost); return { u, n: unitName(p.fac, u), ic: UNITS[u].ic, cost: c, ok: p.res >= c }; }) };
    } else if (sel.length) {
      const us = sel.filter(e => !e.b); const cnt: Record<string, number> = {}; us.forEach(e => { cnt[e.t] = (cnt[e.t] || 0) + 1; });
      s = { kind: 'units', count: us.length, name: Object.keys(cnt).length === 1 ? unitName(p.fac, us[0].t) : 'وحدات متنوعة', hp: us.reduce((a, e) => a + e.hp, 0), mhp: us.reduce((a, e) => a + e.mhp, 0), hasWk: us.some(e => UNITS[e.t].cls === 'wk'), list: Object.entries(cnt).map(([t, n]) => `${UNITS[t].ic}×${n}`).join('  ') };
    }
    const bo = buildOpts(w.era).filter(t => t !== 'air' || f.air.length).map(t => { const c = Math.round(BLD[t].cost * fm.cost); return { t, n: bldName(w.era, t), cost: c, ok: p.res >= c, ic: BLD[t].ic }; });
    let hint = ''; if (this.placing) hint = 'اضغط على الأرض لوضع ' + bldName(w.era, this.placing); else if (this.powSel >= 0) hint = 'اختر هدف ' + POW[f.pw[this.powSel]].n; else if (this.am) hint = 'اضغط الهدف للهجوم والتحرك'; else if (this.box) hint = 'اسحب لتحديد الوحدات بمربع';
    return {
      res: Math.floor(p.res), pop: p.pop, cap: POP_CAP, powSel: this.powSel, placing: this.placing, am: this.am, box: this.box, hint, toasts: this.toasts.map(t => ({ id: t.id, s: t.s, bad: t.bad })),
      pows: f.pw.map((id, i) => ({ ic: POW[id].ic, n: POW[id].n, cd: Math.max(0, p.pcd[i]), max: POW[id].cd, ds: POW[id].ds })), lost: !p.alive && !this.over, over: this.over, paused: this.paused, buffT: p.buffT, sel: s, build: bo,
    };
  }
}
