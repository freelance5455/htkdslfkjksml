import * as THREE from 'three';
import { CollisionSystem } from '../physics/CollisionSystem';
import { sound, SurfaceType } from '../../audio/SoundEngine';

export interface PlayerStats {
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  points: number;
  kills: number;
  headshots: number;
  isDead: boolean;
  flashlightOn: boolean;
  characterId: string;
  grenades: number;
}

export interface GrenadeProjectile {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  timer: number;
  exploded: boolean;
}

export class PlayerController {
  public camera: THREE.PerspectiveCamera;
  public collision: CollisionSystem;

  // Position & Dynamic Velocity
  public position = new THREE.Vector3(0, 0, 8);
  public velocity = new THREE.Vector3();
  public horizontalVelocity = new THREE.Vector2();

  public isGrounded = true;
  public isCrouching = false;
  public isSprinting = false;
  public isSliding = false;
  public slideTimer = 0;
  public slideDir = new THREE.Vector3();
  public autoSprint = true;

  // Camera angles & Touch Look
  public yaw = 0;
  public pitch = 0;
  public cameraTilt = 0;
  public landingDip = 0;

  // Sensitivity & Smooth Aim
  public sensX = 1.0;
  public sensY = 1.0;
  public adsSensitivityMult = 0.6;
  public sniperSensitivity = 0.45;
  public opticSensitivity = 0.55;
  public adsBehavior: 'tap' | 'hold' | 'hybrid' = 'hybrid';
  public activeWeaponType: 'rifle' | 'shotgun' | 'pistol' | 'sniper' | 'smg' = 'rifle';
  public acceleration = 1.0;
  public aimSmoothing = 0.0;
  public isAiming = false;

  // Modern CoD Mobile FPS Tuning
  private walkSpeed = 5.8;
  private sprintSpeed = 9.4;
  private crouchSpeed = 3.0;
  private slideSpeed = 13.0;
  private jumpSpeed = 6.8;
  private gravity = -22.0;
  private currentMoveSpeed = 5.8;

  // Snappy Ground Acceleration & Friction
  private groundAccel = 28.0;
  private groundFriction = 15.0;

  // Stance Dimensions
  public radius = 0.45;
  public standHeight = 1.8;
  public crouchHeight = 1.15;
  public slideHeight = 0.85;
  public eyeHeight = 1.65;
  private currentEyeHeight = 1.65;

  // Footstep timing & surface
  private footstepTimer = 0;
  public currentSurface: SurfaceType = 'concrete';

  // First-person lower body & feet group
  public lowerBodyGroup: THREE.Group;
  private leftBoot: THREE.Mesh;
  private rightBoot: THREE.Mesh;
  private leftLegMesh: THREE.Mesh;
  private rightLegMesh: THREE.Mesh;
  private legAnimTimer = 0;

  // Melee & Grenade State
  public isMeleeing = false;
  public meleeTimer = 0;
  public grenades: GrenadeProjectile[] = [];
  private grenadeMat = new THREE.MeshStandardMaterial({ color: 0x15803d, metalness: 0.8, roughness: 0.3 });

  // Player state
  public stats: PlayerStats = {
    health: 250,
    maxHealth: 250,
    armor: 50,
    maxArmor: 100,
    points: 500,
    kills: 0,
    headshots: 0,
    isDead: false,
    flashlightOn: false,
    characterId: 'specter',
    grenades: 2,
  };

  // Regeneration
  private lastDamageTime = 0;
  private regenDelay = 4.0;
  private regenRate = 30;

  // Tactical Flashlight
  public flashlight: THREE.SpotLight;
  public flashlightTarget: THREE.Object3D;

  // Virtual inputs from touch UI
  public virtualMoveX = 0;
  public virtualMoveY = 0;
  public virtualSprint = false;

  // Desktop keyboard state
  private keys: Record<string, boolean> = {};

  // Event callbacks
  public onStatsChange?: (stats: PlayerStats) => void;
  public onDamageTaken?: (amount: number) => void;
  public onInteractPrompt?: (prompt: string | null) => void;
  public onGrenadeExplode?: (pos: THREE.Vector3, radius: number, damage: number) => void;
  public onMeleeHit?: (pos: THREE.Vector3, damage: number) => void;

  constructor(camera: THREE.PerspectiveCamera, collision: CollisionSystem) {
    this.camera = camera;
    this.collision = collision;

    // Flashlight
    this.flashlight = new THREE.SpotLight(0xffffff, 0, 45, Math.PI / 4, 0.45, 1.2);
    this.flashlight.castShadow = true;
    this.flashlight.shadow.mapSize.width = 512;
    this.flashlight.shadow.mapSize.height = 512;
    this.camera.add(this.flashlight);

    this.flashlightTarget = new THREE.Object3D();
    this.flashlightTarget.position.set(0, 0, -12);
    this.camera.add(this.flashlightTarget);
    this.flashlight.target = this.flashlightTarget;

    // First-Person Rigged Lower Body (Legs & Boots visible when pitching camera down)
    this.lowerBodyGroup = new THREE.Group();
    this.lowerBodyGroup.name = 'fps_legs';

    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 });
    const bootMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7, metalness: 0.2 });

    // Left Leg
    this.leftLegMesh = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.75, 0.16), pantsMat);
    this.leftLegMesh.position.set(-0.16, -0.65, 0.12);
    this.leftLegMesh.castShadow = true;
    this.lowerBodyGroup.add(this.leftLegMesh);

    this.leftBoot = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.14, 0.28), bootMat);
    this.leftBoot.position.set(-0.16, -1.05, 0.18);
    this.leftBoot.castShadow = true;
    this.lowerBodyGroup.add(this.leftBoot);

    // Right Leg
    this.rightLegMesh = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.75, 0.16), pantsMat);
    this.rightLegMesh.position.set(0.16, -0.65, 0.12);
    this.rightLegMesh.castShadow = true;
    this.lowerBodyGroup.add(this.rightLegMesh);

    this.rightBoot = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.14, 0.28), bootMat);
    this.rightBoot.position.set(0.16, -1.05, 0.18);
    this.rightBoot.castShadow = true;
    this.lowerBodyGroup.add(this.rightBoot);

    this.camera.add(this.lowerBodyGroup);

    this.setupKeyboardListeners();
  }

  get sensitivity(): number {
    return this.sensX;
  }
  set sensitivity(val: number) {
    this.sensX = val;
    this.sensY = val;
  }

  reset(characterId = 'specter', spawnPos = new THREE.Vector3(0, 0, 8)) {
    this.position.copy(spawnPos);
    this.velocity.set(0, 0, 0);
    this.horizontalVelocity.set(0, 0);
    this.yaw = 0;
    this.pitch = 0;
    this.cameraTilt = 0;
    this.landingDip = 0;
    this.isCrouching = false;
    this.isSprinting = false;
    this.isSliding = false;
    this.slideTimer = 0;
    this.isMeleeing = false;
    this.currentEyeHeight = this.eyeHeight;
    this.currentMoveSpeed = this.walkSpeed;
    this.grenades = [];

    let maxHp = 250;
    let initialArmor = 50;
    if (characterId === 'vanguard') {
      maxHp = 300;
      initialArmor = 100;
    }

    this.stats = {
      health: maxHp,
      maxHealth: maxHp,
      armor: initialArmor,
      maxArmor: 100,
      points: 500,
      kills: 0,
      headshots: 0,
      isDead: false,
      flashlightOn: false,
      characterId,
      grenades: 2,
    };
    this.flashlight.intensity = 0;
    this.notifyStats();

    // Immediately place camera at player eye level facing into the map (eliminates black void or camera dislocation)
    this.camera.position.set(this.position.x, this.position.y + this.eyeHeight, this.position.z);
    const euler = new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ');
    this.camera.quaternion.setFromEuler(euler);
  }

  toggleFlashlight(): boolean {
    this.stats.flashlightOn = !this.stats.flashlightOn;
    this.flashlight.intensity = this.stats.flashlightOn ? 4.5 : 0;
    sound.playUIClick();
    this.notifyStats();
    return this.stats.flashlightOn;
  }

  addPoints(amount: number) {
    this.stats.points += amount;
    this.notifyStats();
  }

  spendPoints(amount: number): boolean {
    if (this.stats.points >= amount) {
      this.stats.points -= amount;
      this.notifyStats();
      return true;
    }
    return false;
  }

  takeDamage(amount: number) {
    if (this.stats.isDead) return;

    this.lastDamageTime = performance.now() / 1000;
    sound.playPlayerHurt();

    if (this.stats.armor > 0) {
      const absorbed = Math.min(this.stats.armor, Math.round(amount * 0.65));
      this.stats.armor -= absorbed;
      amount -= absorbed;
    }

    this.stats.health -= amount;

    if (this.stats.health <= 0) {
      this.stats.health = 0;
      this.stats.isDead = true;
    }

    this.notifyStats();

    if (this.onDamageTaken) {
      this.onDamageTaken(amount);
    }
  }

  heal(amount: number) {
    this.stats.health = Math.min(this.stats.maxHealth, this.stats.health + amount);
    this.notifyStats();
  }

  notifyStats() {
    if (this.onStatsChange) {
      this.onStatsChange({ ...this.stats });
    }
  }

  addLookDelta(deltaX: number, deltaY: number) {
    let aimMult = 1.0;
    if (this.isAiming) {
      if (this.activeWeaponType === 'sniper') {
        aimMult = this.sniperSensitivity;
      } else {
        aimMult = this.adsSensitivityMult;
      }
    }
    const accel = this.acceleration;

    const lookX = deltaX * 0.0024 * this.sensX * aimMult * accel;
    const lookY = deltaY * 0.0024 * this.sensY * aimMult * accel;

    this.yaw -= lookX;
    this.pitch -= lookY;

    const maxPitch = (Math.PI / 2) * 0.94;
    this.pitch = Math.max(-maxPitch, Math.min(maxPitch, this.pitch));
  }

  private setupKeyboardListeners() {
    window.addEventListener('keydown', e => {
      this.keys[e.code] = true;

      if (e.code === 'KeyF') {
        this.toggleFlashlight();
      }
      if (e.code === 'KeyC') {
        if (this.isSprinting) {
          this.triggerSlide();
        } else {
          this.isCrouching = !this.isCrouching;
        }
      }
      if (e.code === 'KeyV') {
        this.melee();
      }
      if (e.code === 'KeyG') {
        this.throwGrenade();
      }
    });

    window.addEventListener('keyup', e => {
      this.keys[e.code] = false;
    });
  }

  jump() {
    if (this.isGrounded && !this.stats.isDead) {
      this.velocity.y = this.jumpSpeed;
      this.isGrounded = false;
      sound.playJumpSound();
      if (this.isSliding) {
        this.isSliding = false;
        this.isCrouching = false;
      }
    }
  }

  // Tactical slide mechanic
  triggerSlide() {
    if (this.isSliding || !this.isGrounded || this.stats.isDead) return;

    this.isSliding = true;
    this.slideTimer = 0.65;
    this.isCrouching = true;
    sound.playSlideSound();

    // Slide forward along current look yaw
    const sinYaw = Math.sin(this.yaw);
    const cosYaw = Math.cos(this.yaw);
    this.slideDir.set(-sinYaw, 0, -cosYaw).normalize();
  }

  melee() {
    if (this.isMeleeing || this.stats.isDead) return;
    this.isMeleeing = true;
    this.meleeTimer = 0.32;
    sound.playZombieAttack();

    const forward = new THREE.Vector3(0, 0, -1).applyEuler(this.camera.rotation).normalize();
    const strikePos = this.camera.position.clone().addScaledVector(forward, 1.8);

    if (this.onMeleeHit) {
      this.onMeleeHit(strikePos, 160);
    }
  }

  throwGrenade(scene?: THREE.Scene) {
    if (this.stats.grenades <= 0 || this.stats.isDead) {
      sound.playDryFire();
      return;
    }
    this.stats.grenades--;
    this.notifyStats();
    sound.playShellClink();

    const geo = new THREE.SphereGeometry(0.12, 10, 10);
    const mesh = new THREE.Mesh(geo, this.grenadeMat);
    mesh.position.copy(this.camera.position);

    const forward = new THREE.Vector3(0, 0, -1).applyEuler(this.camera.rotation).normalize();
    const vel = forward.multiplyScalar(18).add(new THREE.Vector3(0, 3.5, 0));

    const g: GrenadeProjectile = {
      mesh,
      velocity: vel,
      timer: 2.2,
      exploded: false,
    };

    this.grenades.push(g);
    if (scene) scene.add(mesh);
    else if (this.camera.parent) this.camera.parent.add(mesh);
  }

  update(
    delta: number,
    interactiveStations: { id: string; name: string; cost: number; position: THREE.Vector3; radius: number; action: () => void }[],
    scene?: THREE.Scene
  ) {
    if (this.stats.isDead) return;

    const now = performance.now() / 1000;

    // Melee timer
    if (this.isMeleeing) {
      this.meleeTimer -= delta;
      if (this.meleeTimer <= 0) {
        this.isMeleeing = false;
      }
    }

    // Health regen
    if (now - this.lastDamageTime > this.regenDelay && this.stats.health < this.stats.maxHealth) {
      const bonus = this.stats.characterId === 'phoenix' ? 1.6 : 1.0;
      this.stats.health = Math.min(this.stats.maxHealth, this.stats.health + this.regenRate * bonus * delta);
      this.notifyStats();
    }

    // Movement inputs: Keyboard + Virtual Joystick
    let inputX = this.virtualMoveX;
    let inputZ = this.virtualMoveY;

    if (this.keys['KeyW'] || this.keys['ArrowUp']) inputZ -= 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) inputZ += 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) inputX -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) inputX += 1;

    const inputLen = Math.hypot(inputX, inputZ);
    if (inputLen > 1) {
      inputX /= inputLen;
      inputZ /= inputLen;
    }

    // Auto Sprint check
    const wantSprint =
      (this.autoSprint && inputZ < -0.45 && !this.isAiming && !this.isCrouching && !this.isSliding) ||
      ((this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.virtualSprint) && inputZ < -0.1 && !this.isAiming && !this.isSliding);

    this.isSprinting = wantSprint && inputLen > 0.2;

    if (this.keys['Space']) {
      this.jump();
    }

    // Slide state update (Requirement 22: Player returns to standing after slide)
    if (this.isSliding) {
      this.slideTimer -= delta;
      if (this.slideTimer <= 0) {
        this.isSliding = false;
        this.isCrouching = false;
      }
    }

    // Target Speed
    let targetSpeed = this.walkSpeed;
    if (this.isSliding) targetSpeed = this.slideSpeed * (this.slideTimer / 0.65 + 0.3);
    else if (this.isCrouching) targetSpeed = this.crouchSpeed;
    else if (this.isSprinting) targetSpeed = this.sprintSpeed;

    if (this.stats.characterId === 'specter' && this.isSprinting) {
      targetSpeed *= 1.15;
    }

    this.currentMoveSpeed = THREE.MathUtils.lerp(this.currentMoveSpeed, targetSpeed, delta * 14);

    const sinYaw = Math.sin(this.yaw);
    const cosYaw = Math.cos(this.yaw);

    const forward = new THREE.Vector3(-sinYaw, 0, -cosYaw);
    const right = new THREE.Vector3(cosYaw, 0, -sinYaw);

    let targetWish = new THREE.Vector3();
    if (this.isSliding) {
      targetWish.copy(this.slideDir);
    } else {
      targetWish.addScaledVector(right, inputX).addScaledVector(forward, -inputZ);
      if (targetWish.lengthSq() > 1) targetWish.normalize();
    }

    const targetVx = targetWish.x * this.currentMoveSpeed;
    const targetVz = targetWish.z * this.currentMoveSpeed;

    const rate = targetWish.lengthSq() > 0.01 ? this.groundAccel : this.groundFriction;
    this.horizontalVelocity.x = THREE.MathUtils.lerp(this.horizontalVelocity.x, targetVx, delta * rate);
    this.horizontalVelocity.y = THREE.MathUtils.lerp(this.horizontalVelocity.y, targetVz, delta * rate);

    const horizMove = new THREE.Vector3(this.horizontalVelocity.x * delta, 0, this.horizontalVelocity.y * delta);

    // Gravity & vertical physics
    const wasGrounded = this.isGrounded;
    this.velocity.y += this.gravity * delta;
    const vertMove = this.velocity.y * delta;

    // Smooth stance camera height transition
    let targetEyeYOffset = this.eyeHeight;
    if (this.isSliding) targetEyeYOffset = 0.72;
    else if (this.isCrouching) targetEyeYOffset = 0.95;

    this.currentEyeHeight = THREE.MathUtils.lerp(this.currentEyeHeight, targetEyeYOffset, delta * 16);

    let currentH = this.standHeight;
    if (this.isSliding) currentH = this.slideHeight;
    else if (this.isCrouching) currentH = this.crouchHeight;

    const resolved = this.collision.resolveMovement(
      this.position,
      horizMove,
      this.radius,
      currentH,
      0.4
    );

    // Strict map boundary protection (Requirement 2: Player cannot leave playable map)
    this.position.x = THREE.MathUtils.clamp(resolved.position.x, -52, 52);
    this.position.z = THREE.MathUtils.clamp(resolved.position.z, -52, 52);

    const floorY = this.collision.getGroundHeight(this.position.x, this.position.z, this.position.y);
    this.position.y += vertMove;

    if (this.position.y <= floorY) {
      this.position.y = floorY;
      this.velocity.y = 0;
      this.isGrounded = true;

      // Landing detection
      if (!wasGrounded) {
        sound.playLandSound();
        this.landingDip = 0.12; // Camera dips on hard landing
      }
    } else {
      this.isGrounded = false;
    }

    // Recover landing dip
    this.landingDip = THREE.MathUtils.lerp(this.landingDip, 0, delta * 12);

    // Camera tilt when sliding / strafing
    const targetTilt = this.isSliding ? -0.06 : inputX * -0.02;
    this.cameraTilt = THREE.MathUtils.lerp(this.cameraTilt, targetTilt, delta * 10);

    // Surface detection for footsteps
    if (this.position.y <= 0.25 && (this.currentSurface === 'water' || this.position.y <= 0.16)) {
      this.currentSurface = 'water';
    } else {
      this.currentSurface = 'concrete';
    }

    // Footstep audio processing
    const isMovingGrounded = this.isGrounded && this.horizontalVelocity.lengthSq() > 0.4 && !this.isSliding;
    if (isMovingGrounded) {
      this.footstepTimer -= delta;
      const stepInterval = this.isSprinting ? 0.28 : this.isCrouching ? 0.48 : 0.38;
      if (this.footstepTimer <= 0) {
        sound.playFootstep(this.currentSurface);
        this.footstepTimer = stepInterval;
      }
    } else {
      this.footstepTimer = 0.15;
    }

    // Position camera
    this.camera.position.set(
      this.position.x,
      this.position.y + this.currentEyeHeight - this.landingDip,
      this.position.z
    );

    const euler = new THREE.Euler(this.pitch, this.yaw, this.cameraTilt, 'YXZ');
    this.camera.quaternion.setFromEuler(euler);

    // Animate lower body / feet when looking down
    this.updateFirstPersonLegs(delta, isMovingGrounded);

    // Check interaction
    let prompt: string | null = null;
    for (let i = 0; i < interactiveStations.length; i++) {
      const st = interactiveStations[i];
      const d = this.position.distanceTo(st.position);
      if (d <= st.radius) {
        prompt = `BUY ${st.name} [$${st.cost}]`;
        break;
      }
    }
    if (this.onInteractPrompt) {
      this.onInteractPrompt(prompt);
    }

    // Grenade simulation
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i];
      g.timer -= delta;
      g.velocity.y += this.gravity * delta;
      g.mesh.position.addScaledVector(g.velocity, delta);

      const gFloor = this.collision.getGroundHeight(g.mesh.position.x, g.mesh.position.z, g.mesh.position.y);
      if (g.mesh.position.y <= gFloor + 0.12) {
        g.mesh.position.y = gFloor + 0.12;
        g.velocity.y = -g.velocity.y * 0.45;
        g.velocity.x *= 0.7;
        g.velocity.z *= 0.7;
      }

      if (g.timer <= 0 && !g.exploded) {
        g.exploded = true;
        sound.playExplosion();
        if (this.onGrenadeExplode) {
          this.onGrenadeExplode(g.mesh.position.clone(), 9.0, 450);
        }
        if (scene) scene.remove(g.mesh);
        else if (g.mesh.parent) g.mesh.parent.remove(g.mesh);
        this.grenades.splice(i, 1);
      }
    }
  }

  // Update visible boots & legs in first-person when player looks down
  private updateFirstPersonLegs(delta: number, isMoving: boolean) {
    // Only visible when looking down (pitch < -0.35 rad)
    const isLookingDown = this.pitch < -0.35;
    this.lowerBodyGroup.visible = isLookingDown;

    if (!isLookingDown) return;

    if (this.isSliding) {
      // Legs stretched forward during slide
      this.leftBoot.position.set(-0.16, -0.65, -0.45);
      this.rightBoot.position.set(0.16, -0.65, -0.48);
      this.leftLegMesh.rotation.x = -Math.PI / 3;
      this.rightLegMesh.rotation.x = -Math.PI / 3;
    } else if (isMoving) {
      this.legAnimTimer += delta * (this.isSprinting ? 14 : 9);
      const stride = Math.sin(this.legAnimTimer) * 0.22;
      this.leftBoot.position.set(-0.16, -1.05, 0.18 + stride);
      this.rightBoot.position.set(0.16, -1.05, 0.18 - stride);
      this.leftLegMesh.rotation.x = stride * 0.8;
      this.rightLegMesh.rotation.x = -stride * 0.8;
    } else {
      this.leftBoot.position.set(-0.16, -1.05, 0.18);
      this.rightBoot.position.set(0.16, -1.05, 0.18);
      this.leftLegMesh.rotation.x = 0;
      this.rightLegMesh.rotation.x = 0;
    }
  }

  isPlayerMoving(): boolean {
    return (
      Math.abs(this.virtualMoveX) > 0.08 ||
      Math.abs(this.virtualMoveY) > 0.08 ||
      this.horizontalVelocity.lengthSq() > 0.1 ||
      this.keys['KeyW'] ||
      this.keys['KeyS'] ||
      this.keys['KeyA'] ||
      this.keys['KeyD']
    );
  }

  isPlayerSprinting(): boolean {
    return this.isSprinting && this.isPlayerMoving();
  }
}
