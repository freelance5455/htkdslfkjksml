import * as THREE from 'three';

function radialTex(inner: string, outer: string, size = 64) {
  const c = document.createElement('canvas'); c.width = c.height = size; const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2); g.addColorStop(0, inner); g.addColorStop(1, outer);
  ctx.fillStyle = g; ctx.fillRect(0, 0, size, size); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
export function flashTexture() {
  const s = 128; const c = document.createElement('canvas'); c.width = c.height = s; const ctx = c.getContext('2d')!;
  ctx.translate(s / 2, s / 2);
  for (let i = 0; i < 7; i++) {
    ctx.rotate((Math.PI * 2) / 7 + Math.random() * 0.3);
    const g = ctx.createLinearGradient(0, 0, 0, s / 2); g.addColorStop(0, 'rgba(255,240,200,1)'); g.addColorStop(1, 'rgba(255,140,40,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(0, s / 2 * (0.6 + Math.random() * 0.4)); ctx.lineTo(6, 0); ctx.fill();
  }
  const rg = ctx.createRadialGradient(0, 0, 0, 0, 0, 26); rg.addColorStop(0, 'rgba(255,255,230,1)'); rg.addColorStop(1, 'rgba(255,160,60,0)');
  ctx.fillStyle = rg; ctx.beginPath(); ctx.arc(0, 0, 26, 0, 7); ctx.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

const VS = `attribute float size; attribute vec4 pcolor; varying vec4 vColor;
void main(){ vColor = pcolor; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = size * (420.0 / -mv.z); gl_Position = projectionMatrix * mv; }`;
const FS = `uniform sampler2D map; varying vec4 vColor; void main(){ vec4 t = texture2D(map, gl_PointCoord); gl_FragColor = vec4(vColor.rgb, vColor.a * t.a); if(gl_FragColor.a < 0.01) discard; }`;

export class Particles {
  max: number; count = 0;
  pos: Float32Array; vel: Float32Array; life: Float32Array; maxLife: Float32Array; size: Float32Array; baseSize: Float32Array; col: Float32Array; grav: Float32Array; grow: Float32Array;
  geo: THREE.BufferGeometry; points: THREE.Points; mat: THREE.ShaderMaterial; tex: THREE.Texture;
  private cursor = 0;
  constructor(max: number, additive = false) {
    this.max = max;
    this.pos = new Float32Array(max * 3); this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
    this.size = new Float32Array(max); this.baseSize = new Float32Array(max); this.col = new Float32Array(max * 4); this.grav = new Float32Array(max); this.grow = new Float32Array(max);
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('size', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('pcolor', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    this.tex = radialTex('rgba(255,255,255,1)', 'rgba(255,255,255,0)');
    this.mat = new THREE.ShaderMaterial({ uniforms: { map: { value: this.tex } }, vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending });
    this.points = new THREE.Points(this.geo, this.mat); this.points.frustumCulled = false; this.points.renderOrder = 5;
  }
  spawn(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, r: number, g: number, b: number, a: number, grav = 9.8, grow = 0) {
    if (this.max === 0) return;
    const i = this.cursor; this.cursor = (this.cursor + 1) % this.max;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.life[i] = life; this.maxLife[i] = life; this.baseSize[i] = size; this.size[i] = size; this.grav[i] = grav; this.grow[i] = grow;
    this.col[i * 4] = r; this.col[i * 4 + 1] = g; this.col[i * 4 + 2] = b; this.col[i * 4 + 3] = a;
  }
  burst(p: THREE.Vector3, n: THREE.Vector3 | null, count: number, speed: number, life: number, size: number, color: [number, number, number], alpha = 1, grav = 9.8, grow = 0) {
    for (let k = 0; k < count; k++) {
      let vx = (Math.random() - 0.5) * 2, vy = (Math.random() - 0.5) * 2, vz = (Math.random() - 0.5) * 2;
      if (n) { vx += n.x * 1.5; vy += n.y * 1.5; vz += n.z * 1.5; }
      const s = speed * (0.4 + Math.random() * 0.8);
      this.spawn(p.x, p.y, p.z, vx * s, vy * s, vz * s, life * (0.6 + Math.random() * 0.6), size * (0.7 + Math.random() * 0.6), color[0], color[1], color[2], alpha, grav, grow);
    }
  }
  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { this.size[i] = 0; continue; }
      this.life[i] -= dt;
      const k = Math.max(0, this.life[i] / this.maxLife[i]);
      this.vel[i * 3 + 1] -= this.grav[i] * dt;
      const drag = 1 - Math.min(1, dt * 2.5);
      this.vel[i * 3] *= drag; this.vel[i * 3 + 2] *= drag;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.size[i] = this.baseSize[i] * (1 + (1 - k) * this.grow[i]);
      this.col[i * 4 + 3] = Math.min(this.col[i * 4 + 3], k * 1.2);
      if (this.life[i] <= 0) this.size[i] = 0;
    }
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.size as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.pcolor as THREE.BufferAttribute).needsUpdate = true;
  }
  dispose() { this.geo.dispose(); this.mat.dispose(); this.tex.dispose(); }
}

export class Tracers {
  meshes: THREE.Mesh[] = []; life: number[] = []; private i = 0; geo: THREE.BoxGeometry; mat: THREE.MeshBasicMaterial;
  constructor(scene: THREE.Scene, n: number) {
    this.geo = new THREE.BoxGeometry(0.025, 0.025, 1); this.geo.translate(0, 0, -0.5);
    this.mat = new THREE.MeshBasicMaterial({ color: 0xffd890, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    for (let k = 0; k < n; k++) { const m = new THREE.Mesh(this.geo, this.mat.clone()); m.visible = false; m.frustumCulled = false; scene.add(m); this.meshes.push(m); this.life.push(0); }
  }
  fire(from: THREE.Vector3, to: THREE.Vector3, color = 0xffd890) {
    if (!this.meshes.length) return;
    const m = this.meshes[this.i]; this.life[this.i] = 0.07; this.i = (this.i + 1) % this.meshes.length;
    m.position.copy(from); m.lookAt(to); m.scale.set(1, 1, from.distanceTo(to)); m.visible = true;
    (m.material as THREE.MeshBasicMaterial).color.setHex(color); (m.material as THREE.MeshBasicMaterial).opacity = 0.9;
  }
  update(dt: number) {
    for (let k = 0; k < this.meshes.length; k++) {
      if (this.life[k] <= 0) continue; this.life[k] -= dt;
      const m = this.meshes[k]; (m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, this.life[k] / 0.07) * 0.9;
      if (this.life[k] <= 0) m.visible = false;
    }
  }
  dispose() { this.geo.dispose(); this.meshes.forEach(m => (m.material as THREE.Material).dispose()); this.mat.dispose(); }
}

export class Decals {
  mesh: THREE.InstancedMesh; private i = 0; private n: number; private tex: THREE.Texture; private dummy = new THREE.Object3D();
  constructor(scene: THREE.Scene, n: number) {
    this.n = Math.max(1, n);
    this.tex = radialTex('rgba(10,10,10,0.95)', 'rgba(30,30,30,0)', 32);
    const g = new THREE.PlaneGeometry(0.14, 0.14);
    this.mesh = new THREE.InstancedMesh(g, new THREE.MeshBasicMaterial({ map: this.tex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4 }), this.n);
    this.mesh.count = 0; this.mesh.frustumCulled = false; scene.add(this.mesh);
  }
  add(p: THREE.Vector3, n: THREE.Vector3) {
    this.dummy.position.copy(p).addScaledVector(n, 0.01);
    this.dummy.lookAt(p.x + n.x, p.y + n.y, p.z + n.z); this.dummy.rotateZ(Math.random() * 6);
    const s = 0.7 + Math.random() * 0.6; this.dummy.scale.set(s, s, s); this.dummy.updateMatrix();
    this.mesh.setMatrixAt(this.i, this.dummy.matrix); this.i = (this.i + 1) % this.n; this.mesh.count = Math.min(this.n, this.mesh.count + 1);
    this.mesh.instanceMatrix.needsUpdate = true;
  }
  dispose() { this.mesh.geometry.dispose(); (this.mesh.material as THREE.Material).dispose(); this.tex.dispose(); }
}
