import * as THREE from "three";
import type { WarriorConfig } from "./types";
import { glowTexture } from "./textures";

type Key = [number, number];
type Axis = "x" | "y" | "z";
type AxisKeys = Partial<Record<Axis, Key[]>>;
type Pose = Record<string, AxisKeys>;

const HIPS_Y = 1.02;

const BASE: Record<string, [number, number, number]> = {
  hips: [0, 0, 0],
  spine: [0.02, 0, 0],
  chest: [0, 0, 0],
  neck: [0, 0, 0],
  head: [0, 0, 0],
  shoulderL: [0, 0, 0.1],
  elbowL: [-0.18, 0, 0],
  wristL: [0, 0, 0],
  shoulderR: [-0.08, 0, -0.1],
  elbowR: [-0.22, 0, 0],
  wristR: [0, 0, 0],
  hipL: [0, 0, 0.02],
  kneeL: [0.06, 0, 0],
  ankleL: [0, 0, 0],
  hipR: [0, 0, -0.02],
  kneeR: [0.06, 0, 0],
  ankleR: [0, 0, 0],
};

function rotTrack(node: string, axis: Axis, keys: Key[]) {
  return new THREE.NumberKeyframeTrack(
    `${node}.rotation[${axis}]`,
    keys.map((k) => k[0]),
    keys.map((k) => k[1])
  );
}

function buildClip(name: string, duration: number, pose: Pose, hipsY: Key[] = [], fallX: Key[] = []) {
  const tracks: THREE.KeyframeTrack[] = [];
  for (const [node, base] of Object.entries(BASE)) {
    const over = pose[node] ?? {};
    (["x", "y", "z"] as Axis[]).forEach((axis, i) => {
      const keys = over[axis] ?? [
        [0, base[i]],
        [duration, base[i]],
      ];
      tracks.push(rotTrack(node, axis, keys));
    });
  }
  const yKeys = hipsY.length
    ? hipsY.map(([t, v]) => [t, HIPS_Y + v] as Key)
    : ([
        [0, HIPS_Y],
        [duration, HIPS_Y],
      ] as Key[]);
  tracks.push(rotTrack("hips", "x", [[0, 0], [duration, 0]]));
  tracks.push(new THREE.NumberKeyframeTrack("hips.position[y]", yKeys.map((k) => k[0]), yKeys.map((k) => k[1])));
  // every clip resets the fall pivot so a KO never leaks into the next round
  const fallKeys: Key[] = fallX.length
    ? fallX
    : [
        [0, 0],
        [duration, 0],
      ];
  tracks.push(rotTrack("fall", "x", fallKeys));
  return new THREE.AnimationClip(name, duration, tracks);
}

export interface Warrior {
  cfg: WarriorConfig;
  root: THREE.Group;
  fall: THREE.Group;
  joints: Record<string, THREE.Object3D>;
  mixer: THREE.AnimationMixer;
  actions: Record<string, THREE.AnimationAction>;
  weaponTip: THREE.Object3D;
  glowMats: THREE.MeshStandardMaterial[];
  glowSprites: THREE.Sprite[];
  cape: { mesh: THREE.Mesh; base: Float32Array } | null;
  cloth: { mesh: THREE.Mesh; base: Float32Array }[];
  ring: THREE.Mesh;
  current: string;
  play: (name: string, fade?: number) => void;
  update: (dt: number, elapsed: number) => void;
  setGlow: (v: number) => void;
  setMotion: (speed: number) => void;
  dispose: () => void;
}

export function createWarrior(cfg: WarriorConfig): Warrior {
  const p = cfg.palette;
  const root = new THREE.Group();
  root.name = `warrior-${cfg.id}`;
  const fall = new THREE.Group();
  fall.name = "fall";
  fall.position.y = -0.06; // ground the feet exactly on the arena floor
  root.add(fall);

  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const glowMats: THREE.MeshStandardMaterial[] = [];
  const glowSprites: THREE.Sprite[] = [];
  const clothList: { mesh: THREE.Mesh; base: Float32Array }[] = [];

  const M = (opts: THREE.MeshStandardMaterialParameters) => {
    const m = new THREE.MeshStandardMaterial(opts);
    mats.push(m);
    return m;
  };
  const G = (geo: THREE.BufferGeometry) => {
    geos.push(geo);
    return geo;
  };

  const steel = M({ color: p.primary, metalness: 0.92, roughness: 0.3 });
  const darkSteel = M({ color: p.secondary, metalness: 0.85, roughness: 0.42 });
  const blackSteel = M({ color: 0x1b2029, metalness: 0.8, roughness: 0.5 });
  const gold = M({ color: 0xc9a45c, metalness: 1, roughness: 0.26 });
  const bronze = M({ color: 0x8a5a32, metalness: 0.95, roughness: 0.35 });
  const leather = M({ color: p.leather, metalness: 0.1, roughness: 0.92 });
  const cloth = M({ color: p.cloth, metalness: 0.05, roughness: 0.96, side: THREE.DoubleSide });
  const skin = M({ color: p.skin, metalness: 0.05, roughness: 0.72 });
  const glow = M({
    color: p.glow,
    emissive: p.glow,
    emissiveIntensity: 2.4,
    metalness: 0.2,
    roughness: 0.4,
    toneMapped: false,
  });
  glowMats.push(glow);
  const bladeMat = M({
    color: p.blade,
    emissive: p.glow,
    emissiveIntensity: 0.55,
    metalness: 1,
    roughness: 0.16,
  });
  glowMats.push(bladeMat);

  const add = (
    parent: THREE.Object3D,
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    pos: [number, number, number] = [0, 0, 0],
    rot?: [number, number, number],
    scale?: [number, number, number]
  ) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(pos[0], pos[1], pos[2]);
    if (rot) m.rotation.set(rot[0], rot[1], rot[2]);
    if (scale) m.scale.set(scale[0], scale[1], scale[2]);
    m.castShadow = true;
    m.receiveShadow = true;
    parent.add(m);
    return m;
  };

  const joint = (parent: THREE.Object3D, name: string, pos: [number, number, number]) => {
    const g = new THREE.Group();
    g.name = name;
    g.position.set(pos[0], pos[1], pos[2]);
    parent.add(g);
    return g;
  };

  // ── hips / pelvis ────────────────────────────────────────────────
  const hips = joint(fall, "hips", [0, HIPS_Y, 0]);
  add(hips, G(new THREE.SphereGeometry(0.2, 16, 12)), darkSteel, [0, -0.02, 0], undefined, [1.12, 0.82, 0.86]);
  add(hips, G(new THREE.TorusGeometry(0.205, 0.032, 8, 24)), leather, [0, 0.04, 0], [Math.PI / 2, 0, 0]);
  add(hips, G(new THREE.BoxGeometry(0.11, 0.09, 0.05)), gold, [0, 0.04, 0.2]);
  add(hips, G(new THREE.OctahedronGeometry(0.038)), glow, [0, 0.04, 0.235]);
  // tassets (curved armour plates around the hips)
  for (let i = 0; i < 5; i++) {
    const a = -Math.PI * 0.72 + (i / 4) * Math.PI * 1.44;
    add(
      hips,
      G(new THREE.CylinderGeometry(0.215, 0.25, 0.24, 6, 1, true, -0.28, 0.56)),
      i % 2 === 0 ? steel : darkSteel,
      [Math.sin(a) * 0.02, -0.14, Math.cos(a) * 0.02],
      [0.12, a, 0]
    );
  }
  // hanging war cloth (front + back, vertex animated)
  const makeCloth = (w: number, h: number, pos: [number, number, number], rotY = 0) => {
    const geo = G(new THREE.PlaneGeometry(w, h, 4, 6));
    const mesh = add(hips, geo, cloth, pos, [0.06, rotY, 0]);
    mesh.castShadow = false;
    const base = Float32Array.from(geo.attributes.position.array as Float32Array);
    clothList.push({ mesh, base });
    return mesh;
  };
  makeCloth(0.3, 0.52, [0, -0.3, 0.19]);
  makeCloth(0.34, 0.58, [0, -0.32, -0.18], Math.PI);
  // belt studs
  for (let i = -2; i <= 2; i++) {
    add(hips, G(new THREE.SphereGeometry(0.018, 6, 5)), gold, [i * 0.075, 0.04, 0.205]);
  }

  // ── spine / chest ────────────────────────────────────────────────
  const spine = joint(hips, "spine", [0, 0.16, 0]);
  add(spine, G(new THREE.CapsuleGeometry(0.155, 0.16, 4, 12)), darkSteel, [0, 0.08, 0], undefined, [1.05, 1, 0.8]);
  for (let i = 0; i < 3; i++) {
    add(spine, G(new THREE.BoxGeometry(0.24 - i * 0.02, 0.055, 0.06)), steel, [0, 0.02 + i * 0.07, 0.115]);
  }

  const chest = joint(spine, "chest", [0, 0.3, 0]);
  add(chest, G(new THREE.SphereGeometry(0.27, 20, 14)), darkSteel, [0, 0, 0], undefined, [1.12, 0.98, 0.78]);
  add(chest, G(new THREE.SphereGeometry(0.265, 20, 14)), steel, [0, 0.02, 0.02], undefined, [1.08, 0.9, 0.72]);
  // pectoral plates
  add(chest, G(new THREE.SphereGeometry(0.115, 14, 10)), steel, [-0.1, 0.07, 0.16], [0.1, 0.2, 0.1], [1.2, 0.85, 0.5]);
  add(chest, G(new THREE.SphereGeometry(0.115, 14, 10)), steel, [0.1, 0.07, 0.16], [0.1, -0.2, -0.1], [1.2, 0.85, 0.5]);
  add(chest, G(new THREE.BoxGeometry(0.02, 0.2, 0.03)), gold, [0, 0.02, 0.225]);
  add(chest, G(new THREE.TorusGeometry(0.15, 0.022, 6, 20, Math.PI)), gold, [0, 0.17, 0.12], [0.35, 0, 0]);
  add(chest, G(new THREE.OctahedronGeometry(0.06)), glow, [0, 0.0, 0.225], undefined, [1, 1.5, 0.6]);
  // back plate + spine ridge
  add(chest, G(new THREE.BoxGeometry(0.3, 0.3, 0.06)), darkSteel, [0, 0.02, -0.18], [0.1, 0, 0]);
  for (let i = 0; i < 3; i++) {
    add(chest, G(new THREE.ConeGeometry(0.035, 0.1, 5)), gold, [0, 0.16 - i * 0.12, -0.22], [-0.5, 0, 0]);
  }
  // glowing runes on the breastplate
  add(chest, G(new THREE.BoxGeometry(0.1, 0.012, 0.01)), glow, [-0.11, -0.06, 0.205], [0, 0, 0.5]);
  add(chest, G(new THREE.BoxGeometry(0.08, 0.012, 0.01)), glow, [0.12, -0.09, 0.2], [0, 0, -0.6]);

  // ── neck / head ──────────────────────────────────────────────────
  const neck = joint(chest, "neck", [0, 0.28, 0]);
  add(neck, G(new THREE.CylinderGeometry(0.055, 0.07, 0.1, 10)), skin, [0, 0.02, 0]);
  add(neck, G(new THREE.TorusGeometry(0.075, 0.02, 6, 14)), gold, [0, 0.06, 0], [Math.PI / 2, 0, 0]);
  const head = joint(neck, "head", [0, 0.12, 0]);
  add(head, G(new THREE.SphereGeometry(0.125, 18, 14)), skin, [0, 0.1, 0], undefined, [0.94, 1.08, 1]);
  add(head, G(new THREE.BoxGeometry(0.11, 0.05, 0.08)), skin, [0, 0.02, 0.06]);
  // helmet dome
  add(
    head,
    G(new THREE.SphereGeometry(0.142, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.62)),
    steel,
    [0, 0.11, 0],
    undefined,
    [1, 1.06, 1.04]
  );
  add(head, G(new THREE.TorusGeometry(0.14, 0.016, 6, 20)), gold, [0, 0.11, 0], [Math.PI / 2, 0, 0]);
  // brow + cheek guards
  add(head, G(new THREE.BoxGeometry(0.25, 0.03, 0.05)), gold, [0, 0.135, 0.1], [0.15, 0, 0]);
  add(head, G(new THREE.BoxGeometry(0.035, 0.12, 0.1)), darkSteel, [-0.115, 0.055, 0.055], [0, 0.2, 0.08]);
  add(head, G(new THREE.BoxGeometry(0.035, 0.12, 0.1)), darkSteel, [0.115, 0.055, 0.055], [0, -0.2, -0.08]);
  // face mask + glowing eyes
  add(head, G(new THREE.BoxGeometry(0.15, 0.085, 0.05)), blackSteel, [0, 0.045, 0.095]);
  add(head, G(new THREE.BoxGeometry(0.042, 0.014, 0.012)), glow, [-0.037, 0.085, 0.128]);
  add(head, G(new THREE.BoxGeometry(0.042, 0.014, 0.012)), glow, [0.037, 0.085, 0.128]);
  add(head, G(new THREE.BoxGeometry(0.012, 0.05, 0.012)), glow, [0, 0.035, 0.125]);

  if (cfg.id === "aether") {
    // swept crest fin
    add(head, G(new THREE.BoxGeometry(0.022, 0.1, 0.22)), gold, [0, 0.235, -0.01], [-0.12, 0, 0]);
    add(head, G(new THREE.ConeGeometry(0.045, 0.2, 4)), gold, [0, 0.25, -0.16], [-1.15, 0, 0]);
    add(head, G(new THREE.OctahedronGeometry(0.028)), glow, [0, 0.155, 0.135]);
    // small wing blades on the temples
    add(head, G(new THREE.ConeGeometry(0.03, 0.16, 4)), steel, [-0.15, 0.16, -0.01], [0, 0, 1.25]);
    add(head, G(new THREE.ConeGeometry(0.03, 0.16, 4)), steel, [0.15, 0.16, -0.01], [0, 0, -1.25]);
  } else {
    // horned war helm
    const horn = (side: number) => {
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.1 * side, 0.16, 0),
        new THREE.Vector3(0.2 * side, 0.26, -0.02),
        new THREE.Vector3(0.27 * side, 0.38, -0.08),
        new THREE.Vector3(0.25 * side, 0.5, -0.16),
      ]);
      add(head, G(new THREE.TubeGeometry(curve, 12, 0.03, 6, false)), darkSteel);
      add(head, G(new THREE.ConeGeometry(0.035, 0.12, 6)), gold, [0.25 * side, 0.54, -0.19], [-0.4, 0, -0.25 * side]);
    };
    horn(-1);
    horn(1);
    add(head, G(new THREE.BoxGeometry(0.025, 0.08, 0.2)), bronze, [0, 0.235, 0], [-0.1, 0, 0]);
    for (let i = -1; i <= 1; i++) {
      add(head, G(new THREE.ConeGeometry(0.022, 0.1, 5)), gold, [i * 0.06, 0.27, -0.02], [-0.2, 0, i * 0.25]);
    }
    add(head, G(new THREE.BoxGeometry(0.19, 0.02, 0.02)), glow, [0, 0.09, 0.126]);
  }

  // ── pauldrons + arms ─────────────────────────────────────────────
  const buildArm = (side: -1 | 1) => {
    const s = side === -1 ? "R" : "L";
    const shoulder = joint(chest, `shoulder${s}`, [0.3 * side, 0.19, 0]);
    // layered pauldron shells
    for (let i = 0; i < 3; i++) {
      const r = 0.2 - i * 0.022;
      add(
        shoulder,
        G(new THREE.SphereGeometry(r, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55)),
        i === 1 ? darkSteel : steel,
        [0.035 * side, 0.06 - i * 0.075, 0],
        [0, 0, -0.32 * side],
        [1.05, 0.85, 1.05]
      );
      add(
        shoulder,
        G(new THREE.TorusGeometry(r * 0.92, 0.012, 5, 16, Math.PI)),
        gold,
        [0.035 * side, 0.06 - i * 0.075, 0],
        [Math.PI / 2, 0, -0.32 * side]
      );
    }
    add(shoulder, G(new THREE.ConeGeometry(0.032, 0.17, 6)), gold, [0.11 * side, 0.16, -0.02], [0, 0, -0.5 * side]);
    if (cfg.id === "inferno") {
      add(shoulder, G(new THREE.ConeGeometry(0.04, 0.22, 5)), darkSteel, [0.15 * side, 0.1, -0.06], [0.2, 0, -0.9 * side]);
    }
    add(shoulder, G(new THREE.SphereGeometry(0.075, 10, 8)), darkSteel, [0, -0.02, 0]);
    add(shoulder, G(new THREE.CapsuleGeometry(0.058, 0.18, 4, 8)), cloth, [0, -0.16, 0]);
    add(shoulder, G(new THREE.CylinderGeometry(0.082, 0.068, 0.19, 10)), steel, [0, -0.15, 0]);
    add(shoulder, G(new THREE.BoxGeometry(0.03, 0.16, 0.11)), darkSteel, [0.06 * side, -0.15, 0]);

    const elbow = joint(shoulder, `elbow${s}`, [0, -0.32, 0]);
    add(elbow, G(new THREE.SphereGeometry(0.072, 12, 10)), darkSteel);
    add(elbow, G(new THREE.ConeGeometry(0.035, 0.1, 5)), gold, [0, 0, -0.075], [-1.9, 0, 0]);
    add(elbow, G(new THREE.CapsuleGeometry(0.052, 0.16, 4, 8)), cloth, [0, -0.14, 0]);
    add(elbow, G(new THREE.CylinderGeometry(0.078, 0.06, 0.21, 10)), steel, [0, -0.15, 0]);
    add(elbow, G(new THREE.TorusGeometry(0.068, 0.014, 5, 14)), gold, [0, -0.05, 0], [Math.PI / 2, 0, 0]);
    add(elbow, G(new THREE.BoxGeometry(0.022, 0.17, 0.09)), darkSteel, [0.055 * side, -0.15, 0]);
    add(elbow, G(new THREE.BoxGeometry(0.06, 0.012, 0.012)), glow, [0, -0.2, 0.062]);

    const wrist = joint(elbow, `wrist${s}`, [0, -0.3, 0]);
    add(wrist, G(new THREE.BoxGeometry(0.085, 0.1, 0.085)), leather, [0, -0.04, 0]);
    add(wrist, G(new THREE.BoxGeometry(0.09, 0.035, 0.09)), steel, [0, -0.005, 0]);
    add(wrist, G(new THREE.BoxGeometry(0.028, 0.06, 0.06)), darkSteel, [0.045 * side, -0.06, 0.01]);
    return { shoulder, elbow, wrist };
  };
  const armR = buildArm(-1);
  buildArm(1);

  // ── legs ─────────────────────────────────────────────────────────
  const buildLeg = (side: -1 | 1) => {
    const s = side === -1 ? "R" : "L";
    const hip = joint(hips, `hip${s}`, [0.145 * side, -0.06, 0]);
    add(hip, G(new THREE.CapsuleGeometry(0.082, 0.22, 4, 10)), cloth, [0, -0.19, 0]);
    add(hip, G(new THREE.CylinderGeometry(0.105, 0.082, 0.26, 10)), steel, [0, -0.17, 0]);
    add(hip, G(new THREE.BoxGeometry(0.03, 0.2, 0.1)), darkSteel, [0.075 * side, -0.17, 0.01]);
    add(hip, G(new THREE.TorusGeometry(0.088, 0.014, 5, 14)), gold, [0, -0.05, 0], [Math.PI / 2, 0, 0]);

    const knee = joint(hip, `knee${s}`, [0, -0.42, 0]);
    add(knee, G(new THREE.SphereGeometry(0.082, 12, 10)), darkSteel);
    add(knee, G(new THREE.SphereGeometry(0.07, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.6)), steel, [0, 0.01, 0.035], [1.2, 0, 0]);
    add(knee, G(new THREE.ConeGeometry(0.03, 0.09, 5)), gold, [0, 0.01, 0.1], [1.4, 0, 0]);
    add(knee, G(new THREE.CapsuleGeometry(0.068, 0.22, 4, 10)), cloth, [0, -0.19, 0]);
    add(knee, G(new THREE.CylinderGeometry(0.092, 0.068, 0.28, 10)), steel, [0, -0.19, 0]);
    add(knee, G(new THREE.BoxGeometry(0.028, 0.22, 0.09)), darkSteel, [0, -0.19, 0.06]);
    add(knee, G(new THREE.BoxGeometry(0.012, 0.16, 0.012)), glow, [0, -0.2, 0.108]);

    const ankle = joint(knee, `ankle${s}`, [0, -0.4, 0]);
    add(ankle, G(new THREE.SphereGeometry(0.06, 10, 8)), blackSteel);
    add(ankle, G(new THREE.BoxGeometry(0.125, 0.085, 0.24)), leather, [0, -0.035, 0.045]);
    add(ankle, G(new THREE.BoxGeometry(0.12, 0.07, 0.1)), steel, [0, -0.03, 0.16]);
    add(ankle, G(new THREE.BoxGeometry(0.1, 0.05, 0.06)), darkSteel, [0, -0.02, -0.07]);
    return { hip, knee, ankle };
  };
  buildLeg(-1);
  buildLeg(1);

  // ── cape ─────────────────────────────────────────────────────────
  const capeGeo = G(new THREE.PlaneGeometry(0.62, 1.08, 6, 10));
  const cape = add(chest, capeGeo, cloth, [0, -0.28, -0.24], [0.12, 0, 0]);
  cape.castShadow = true;
  const capeBase = Float32Array.from(capeGeo.attributes.position.array as Float32Array);
  // gold trim along the cape bottom
  add(chest, G(new THREE.BoxGeometry(0.6, 0.025, 0.02)), gold, [0, -0.82, -0.29], [0.12, 0, 0]);
  // cape clasp
  add(chest, G(new THREE.TorusGeometry(0.05, 0.016, 6, 12)), gold, [0, 0.19, -0.19], [0.2, 0, 0]);
  add(chest, G(new THREE.OctahedronGeometry(0.032)), glow, [0, 0.19, -0.22]);

  // ── weapon ───────────────────────────────────────────────────────
  const weapon = new THREE.Group();
  weapon.name = "weapon";
  weapon.position.set(0, -0.06, 0.02);
  weapon.rotation.set(-0.95, 0, 0.12);
  armR.wrist.add(weapon);
  const weaponTip = new THREE.Object3D();
  const glowSpriteMat = new THREE.SpriteMaterial({
    map: glowTexture(),
    color: p.glow,
    transparent: true,
    opacity: 0.55,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
  });
  mats.push(glowSpriteMat);

  if (cfg.weapon === "sword") {
    add(weapon, G(new THREE.CylinderGeometry(0.021, 0.023, 0.17, 8)), leather, [0, 0.02, 0]);
    for (let i = 0; i < 5; i++) {
      add(weapon, G(new THREE.TorusGeometry(0.024, 0.005, 4, 8)), gold, [0, -0.04 + i * 0.03, 0], [Math.PI / 2, 0, 0]);
    }
    add(weapon, G(new THREE.SphereGeometry(0.036, 10, 8)), gold, [0, 0.115, 0]);
    add(weapon, G(new THREE.OctahedronGeometry(0.026)), glow, [0, 0.115, 0.03]);
    add(weapon, G(new THREE.BoxGeometry(0.27, 0.032, 0.055)), gold, [0, -0.065, 0]);
    add(weapon, G(new THREE.ConeGeometry(0.035, 0.11, 4)), gold, [-0.16, -0.065, 0], [0, 0, 1.57]);
    add(weapon, G(new THREE.ConeGeometry(0.035, 0.11, 4)), gold, [0.16, -0.065, 0], [0, 0, -1.57]);
    const bladeShape = new THREE.Shape();
    bladeShape.moveTo(-0.055, 0);
    bladeShape.lineTo(0.055, 0);
    bladeShape.lineTo(0.046, -0.68);
    bladeShape.lineTo(0, -0.84);
    bladeShape.lineTo(-0.046, -0.68);
    bladeShape.closePath();
    const bladeGeo = G(
      new THREE.ExtrudeGeometry(bladeShape, {
        depth: 0.022,
        bevelEnabled: true,
        bevelSize: 0.007,
        bevelThickness: 0.007,
        bevelSegments: 1,
        steps: 1,
      })
    );
    bladeGeo.translate(0, 0, -0.011);
    add(weapon, bladeGeo, bladeMat, [0, -0.075, 0]);
    add(weapon, G(new THREE.BoxGeometry(0.012, 0.56, 0.008)), glow, [0, -0.4, 0.019]);
    add(weapon, G(new THREE.BoxGeometry(0.07, 0.012, 0.008)), glow, [0, -0.2, 0.019]);
    weaponTip.position.set(0, -0.9, 0);
    const s1 = new THREE.Sprite(glowSpriteMat);
    s1.scale.set(0.34, 0.9, 1);
    s1.position.set(0, -0.45, 0.02);
    weapon.add(s1);
    glowSprites.push(s1);
  } else {
    add(weapon, G(new THREE.CylinderGeometry(0.026, 0.028, 0.22, 8)), leather, [0, 0.03, 0]);
    for (let i = 0; i < 6; i++) {
      add(weapon, G(new THREE.TorusGeometry(0.029, 0.006, 4, 8)), bronze, [0, -0.05 + i * 0.032, 0], [Math.PI / 2, 0, 0]);
    }
    add(weapon, G(new THREE.SphereGeometry(0.045, 10, 8)), darkSteel, [0, 0.15, 0]);
    add(weapon, G(new THREE.ConeGeometry(0.022, 0.08, 5)), gold, [-0.04, 0.19, 0], [0, 0, 0.5]);
    add(weapon, G(new THREE.ConeGeometry(0.022, 0.08, 5)), gold, [0.04, 0.19, 0], [0, 0, -0.5]);
    add(weapon, G(new THREE.BoxGeometry(0.3, 0.05, 0.08)), bronze, [0, -0.085, 0]);
    add(weapon, G(new THREE.ConeGeometry(0.04, 0.13, 4)), darkSteel, [-0.18, -0.085, 0], [0, 0, 1.57]);
    add(weapon, G(new THREE.ConeGeometry(0.04, 0.13, 4)), darkSteel, [0.18, -0.085, 0], [0, 0, -1.57]);
    const cleaver = new THREE.Shape();
    cleaver.moveTo(-0.06, 0);
    cleaver.lineTo(0.06, 0);
    cleaver.lineTo(0.1, -0.28);
    cleaver.lineTo(0.17, -0.5);
    cleaver.lineTo(0.12, -0.7);
    cleaver.lineTo(-0.01, -0.78);
    cleaver.lineTo(-0.1, -0.58);
    cleaver.lineTo(-0.1, -0.24);
    cleaver.closePath();
    const cleaverGeo = G(
      new THREE.ExtrudeGeometry(cleaver, {
        depth: 0.036,
        bevelEnabled: true,
        bevelSize: 0.01,
        bevelThickness: 0.01,
        bevelSegments: 1,
        steps: 1,
      })
    );
    cleaverGeo.translate(0, 0, -0.018);
    add(weapon, cleaverGeo, darkSteel, [0, -0.1, 0]);
    add(weapon, cleaverGeo, bladeMat, [0, -0.1, 0], undefined, [0.82, 0.97, 1.06]);
    for (let i = 0; i < 3; i++) {
      add(weapon, G(new THREE.BoxGeometry(0.014, 0.16, 0.01)), glow, [0.03 + i * 0.035, -0.3 - i * 0.1, 0.03], [0, 0, 0.5 - i * 0.3]);
    }
    add(weapon, G(new THREE.ConeGeometry(0.03, 0.1, 4)), glow, [0.13, -0.62, 0], [0, 0, -0.6]);
    weaponTip.position.set(0, -0.88, 0);
    const s1 = new THREE.Sprite(glowSpriteMat);
    s1.scale.set(0.4, 1, 1);
    s1.position.set(0.02, -0.42, 0.03);
    weapon.add(s1);
    glowSprites.push(s1);
  }
  weapon.add(weaponTip);

  // team ring under the fighter
  const ringGeo = G(new THREE.RingGeometry(0.44, 0.53, 40));
  const ringMat = new THREE.MeshBasicMaterial({
    color: p.glow,
    transparent: true,
    opacity: 0.4,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
    toneMapped: false,
  });
  mats.push(ringMat);
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.03;
  root.add(ring);

  // ── animation clips ──────────────────────────────────────────────
  const clips: THREE.AnimationClip[] = [
    buildClip("idle", 2.6, {
      spine: { x: [[0, 0.02], [1.3, 0.045], [2.6, 0.02]] },
      chest: { x: [[0, 0], [1.3, -0.025], [2.6, 0]] },
      head: { y: [[0, 0.06], [1.3, -0.06], [2.6, 0.06]], x: [[0, 0], [1.3, 0.02], [2.6, 0]] },
      shoulderL: { z: [[0, 0.1], [1.3, 0.14], [2.6, 0.1]], x: [[0, 0], [1.3, -0.05], [2.6, 0]] },
      shoulderR: { x: [[0, -0.08], [1.3, -0.13], [2.6, -0.08]], z: [[0, -0.1], [1.3, -0.13], [2.6, -0.1]] },
      elbowR: { x: [[0, -0.22], [1.3, -0.3], [2.6, -0.22]] },
      elbowL: { x: [[0, -0.18], [1.3, -0.24], [2.6, -0.18]] },
    }, [[0, 0], [1.3, 0.012], [2.6, 0]]),

    buildClip("walk", 0.86, {
      hipL: { x: [[0, 0.5], [0.215, 0], [0.43, -0.5], [0.645, 0], [0.86, 0.5]] },
      kneeL: { x: [[0, 0.12], [0.215, 0.06], [0.43, 0.12], [0.645, 0.72], [0.86, 0.12]] },
      hipR: { x: [[0, -0.5], [0.215, 0], [0.43, 0.5], [0.645, 0], [0.86, -0.5]] },
      kneeR: { x: [[0, 0.72], [0.215, 0.12], [0.43, 0.12], [0.645, 0.06], [0.86, 0.72]] },
      shoulderL: { x: [[0, -0.34], [0.43, 0.34], [0.86, -0.34]] },
      shoulderR: { x: [[0, 0.16], [0.43, -0.24], [0.86, 0.16]] },
      spine: { y: [[0, 0.09], [0.43, -0.09], [0.86, 0.09]] },
      head: { y: [[0, -0.05], [0.43, 0.05], [0.86, -0.05]] },
      chest: { x: [[0, 0.02], [0.43, 0.05], [0.86, 0.02]] },
    }, [[0, 0], [0.215, 0.03], [0.43, 0], [0.645, 0.03], [0.86, 0]]),

    buildClip("run", 0.56, {
      spine: { x: [[0, 0.2], [0.28, 0.24], [0.56, 0.2]] },
      hipL: { x: [[0, 0.85], [0.14, 0.1], [0.28, -0.7], [0.42, 0.1], [0.56, 0.85]] },
      kneeL: { x: [[0, 0.25], [0.14, 0.1], [0.28, 0.35], [0.42, 1.25], [0.56, 0.25]] },
      hipR: { x: [[0, -0.7], [0.14, 0.1], [0.28, 0.85], [0.42, 0.1], [0.56, -0.7]] },
      kneeR: { x: [[0, 1.25], [0.14, 0.35], [0.28, 0.25], [0.42, 0.1], [0.56, 1.25]] },
      shoulderL: { x: [[0, -0.7], [0.28, 0.6], [0.56, -0.7]] },
      shoulderR: { x: [[0, 0.35], [0.28, -0.45], [0.56, 0.35]] },
      head: { x: [[0, -0.12], [0.28, -0.16], [0.56, -0.12]] },
    }, [[0, 0], [0.14, 0.05], [0.28, 0], [0.42, 0.05], [0.56, 0]]),

    buildClip("light", 0.46, {
      spine: { y: [[0, 0], [0.12, -0.5], [0.22, 0.55], [0.34, 0.3], [0.46, 0]] },
      chest: { y: [[0, 0], [0.12, -0.25], [0.22, 0.3], [0.46, 0]] },
      shoulderR: {
        x: [[0, -0.08], [0.12, -1.2], [0.22, -1.45], [0.34, -1.1], [0.46, -0.08]],
        z: [[0, -0.1], [0.12, -1.05], [0.22, 0.9], [0.34, 0.5], [0.46, -0.1]],
      },
      elbowR: { x: [[0, -0.22], [0.12, -1.0], [0.22, -0.12], [0.46, -0.22]] },
      shoulderL: { x: [[0, 0], [0.12, 0.35], [0.22, -0.55], [0.46, 0]], z: [[0, 0.1], [0.22, 0.5], [0.46, 0.1]] },
      head: { y: [[0, 0], [0.12, 0.25], [0.22, -0.3], [0.46, 0]] },
      hips: { y: [[0, 0], [0.12, -0.3], [0.22, 0.35], [0.46, 0]] },
    }, [[0, 0], [0.12, -0.03], [0.22, -0.07], [0.46, 0]]),

    buildClip("heavy", 0.98, {
      spine: { x: [[0, 0.02], [0.4, -0.22], [0.56, 0.42], [0.75, 0.3], [0.98, 0.02]], y: [[0, 0], [0.4, -0.4], [0.56, 0.35], [0.98, 0]] },
      shoulderR: {
        x: [[0, -0.08], [0.4, -2.95], [0.56, -0.55], [0.75, -0.75], [0.98, -0.08]],
        z: [[0, -0.1], [0.4, -0.35], [0.56, 0.25], [0.98, -0.1]],
      },
      elbowR: { x: [[0, -0.22], [0.4, -0.55], [0.56, -0.1], [0.98, -0.22]] },
      shoulderL: { x: [[0, 0], [0.4, -2.5], [0.56, -0.7], [0.98, 0]], z: [[0, 0.1], [0.4, 0.5], [0.56, 0.2], [0.98, 0.1]] },
      elbowL: { x: [[0, -0.18], [0.4, -0.9], [0.56, -0.4], [0.98, -0.18]] },
      hipL: { x: [[0, 0], [0.4, -0.15], [0.56, 0.35], [0.98, 0]] },
      hipR: { x: [[0, 0], [0.4, 0.1], [0.56, -0.3], [0.98, 0]] },
      kneeL: { x: [[0, 0.06], [0.56, 0.5], [0.98, 0.06]] },
      kneeR: { x: [[0, 0.06], [0.56, 0.45], [0.98, 0.06]] },
      head: { x: [[0, 0], [0.4, -0.2], [0.56, 0.25], [0.98, 0]] },
    }, [[0, 0], [0.4, 0.03], [0.56, -0.14], [0.75, -0.08], [0.98, 0]]),

    buildClip("dodge", 0.5, {
      spine: { x: [[0, 0.02], [0.12, 0.55], [0.3, 0.6], [0.5, 0.02]] },
      chest: { x: [[0, 0], [0.12, 0.2], [0.5, 0]] },
      head: { x: [[0, 0], [0.12, 0.35], [0.5, 0]] },
      hipL: { x: [[0, 0], [0.12, -1.1], [0.3, -0.9], [0.5, 0]] },
      kneeL: { x: [[0, 0.06], [0.12, 1.5], [0.3, 1.2], [0.5, 0.06]] },
      hipR: { x: [[0, 0], [0.12, -0.7], [0.3, -0.5], [0.5, 0]] },
      kneeR: { x: [[0, 0.06], [0.12, 1.3], [0.3, 1.0], [0.5, 0.06]] },
      shoulderL: { x: [[0, 0], [0.12, -0.7], [0.5, 0]] },
      shoulderR: { x: [[0, -0.08], [0.12, -0.5], [0.5, -0.08]] },
    }, [[0, 0], [0.12, -0.32], [0.3, -0.26], [0.5, 0]]),

    buildClip("block", 0.9, {
      spine: { y: [[0, 0.3], [0.45, 0.33], [0.9, 0.3]], x: [[0, 0.08], [0.9, 0.08]] },
      shoulderR: { x: [[0, -1.35], [0.45, -1.4], [0.9, -1.35]], z: [[0, 0.75], [0.9, 0.75]] },
      elbowR: { x: [[0, -1.7], [0.9, -1.7]] },
      shoulderL: { x: [[0, -1.2], [0.45, -1.26], [0.9, -1.2]], z: [[0, -0.55], [0.9, -0.55]] },
      elbowL: { x: [[0, -1.5], [0.9, -1.5]] },
      head: { x: [[0, 0.12], [0.9, 0.12]] },
      hipL: { x: [[0, 0.12], [0.9, 0.12]] },
      hipR: { x: [[0, -0.12], [0.9, -0.12]] },
    }, [[0, -0.04], [0.45, -0.05], [0.9, -0.04]]),

    buildClip("hit", 0.42, {
      spine: { x: [[0, 0.02], [0.08, -0.38], [0.24, -0.2], [0.42, 0.02]] },
      chest: { x: [[0, 0], [0.08, -0.22], [0.42, 0]] },
      head: { x: [[0, 0], [0.08, -0.35], [0.42, 0]] },
      shoulderL: { z: [[0, 0.1], [0.08, 0.55], [0.42, 0.1]], x: [[0, 0], [0.08, 0.4], [0.42, 0]] },
      shoulderR: { z: [[0, -0.1], [0.08, -0.6], [0.42, -0.1]], x: [[0, -0.08], [0.08, 0.3], [0.42, -0.08]] },
      hipL: { x: [[0, 0], [0.08, 0.25], [0.42, 0]] },
      kneeL: { x: [[0, 0.06], [0.08, 0.35], [0.42, 0.06]] },
      hipR: { x: [[0, 0], [0.08, -0.2], [0.42, 0]] },
    }, [[0, 0], [0.08, -0.05], [0.42, 0]]),

    buildClip("special", 1.3, {
      spine: { x: [[0, 0.02], [0.5, -0.25], [0.68, 0.45], [0.9, 0.35], [1.3, 0.02]] },
      shoulderR: {
        x: [[0, -0.08], [0.5, -3.0], [0.68, -0.45], [0.9, -0.6], [1.3, -0.08]],
        z: [[0, -0.1], [0.5, -0.2], [0.68, 0.15], [1.3, -0.1]],
      },
      elbowR: { x: [[0, -0.22], [0.5, -0.4], [0.68, -0.1], [1.3, -0.22]] },
      shoulderL: { x: [[0, 0], [0.5, -2.7], [0.68, -0.5], [1.3, 0]], z: [[0, 0.1], [0.5, 0.35], [0.68, 0.2], [1.3, 0.1]] },
      elbowL: { x: [[0, -0.18], [0.5, -0.7], [0.68, -0.3], [1.3, -0.18]] },
      head: { x: [[0, 0], [0.5, -0.3], [0.68, 0.3], [1.3, 0]] },
      hipL: { x: [[0, 0], [0.5, -0.1], [0.68, 0.3], [1.3, 0]] },
      hipR: { x: [[0, 0], [0.5, 0.1], [0.68, -0.25], [1.3, 0]] },
      kneeL: { x: [[0, 0.06], [0.68, 0.45], [1.3, 0.06]] },
      kneeR: { x: [[0, 0.06], [0.68, 0.4], [1.3, 0.06]] },
    }, [[0, 0], [0.5, 0.04], [0.68, -0.16], [0.9, -0.1], [1.3, 0]]),

    buildClip("victory", 2.4, {
      spine: { x: [[0, -0.08], [1.2, -0.12], [2.4, -0.08]] },
      chest: { x: [[0, -0.1], [1.2, -0.14], [2.4, -0.1]] },
      head: { x: [[0, -0.18], [1.2, -0.24], [2.4, -0.18]] },
      shoulderR: { x: [[0, -2.75], [1.2, -2.85], [2.4, -2.75]], z: [[0, -0.25], [1.2, -0.3], [2.4, -0.25]] },
      elbowR: { x: [[0, -0.35], [1.2, -0.45], [2.4, -0.35]] },
      shoulderL: { x: [[0, -0.35], [1.2, -0.45], [2.4, -0.35]], z: [[0, 0.45], [1.2, 0.55], [2.4, 0.45]] },
      elbowL: { x: [[0, -0.9], [1.2, -1.0], [2.4, -0.9]] },
    }, [[0, 0], [1.2, 0.02], [2.4, 0]]),

    buildClip(
      "ko",
      1.2,
      {
        spine: { x: [[0, 0.02], [0.3, -0.2], [1.2, -0.1]] },
        head: { x: [[0, 0], [0.3, -0.4], [1.2, -0.2]] },
        shoulderL: { z: [[0, 0.1], [0.4, 0.9], [1.2, 0.7]] },
        shoulderR: { z: [[0, -0.1], [0.4, -0.9], [1.2, -0.7]] },
        hipL: { x: [[0, 0], [0.4, -0.5], [1.2, -0.3]] },
        kneeL: { x: [[0, 0.06], [0.4, 0.9], [1.2, 0.5]] },
        hipR: { x: [[0, 0], [0.4, -0.3], [1.2, -0.2]] },
        kneeR: { x: [[0, 0.06], [0.4, 0.7], [1.2, 0.4]] },
      },
      [[0, 0], [0.4, -0.25], [1.2, -0.45]],
      [[0, 0], [0.35, -0.5], [0.75, -1.32], [1.2, -1.42]]
    ),
  ];

  const mixer = new THREE.AnimationMixer(fall);
  const actions: Record<string, THREE.AnimationAction> = {};
  for (const clip of clips) {
    const action = mixer.clipAction(clip);
    if (clip.name === "idle" || clip.name === "walk" || clip.name === "run" || clip.name === "block" || clip.name === "victory") {
      action.setLoop(THREE.LoopRepeat, Infinity);
    } else {
      action.setLoop(THREE.LoopOnce, 1);
      action.clampWhenFinished = true;
    }
    actions[clip.name] = action;
  }

  let current = "";
  const play = (name: string, fade = 0.16) => {
    const next = actions[name];
    if (!next || current === name) return;
    const prev = actions[current];
    next.reset();
    next.setEffectiveWeight(1);
    next.setEffectiveTimeScale(1);
    next.play();
    if (prev && prev !== next) {
      next.fadeIn(fade);
      prev.fadeOut(fade);
    }
    current = name;
  };
  play("idle", 0);

  let motion = 0;
  let glowBoost = 0;
  const capeBasePos = capeGeo.attributes.position as THREE.BufferAttribute;

  const update = (dt: number, elapsed: number) => {
    mixer.update(dt);
    // cloth simulation (cheap vertex sway)
    const pos = capeBasePos;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < arr.length; i += 3) {
      const bx = capeBase[i];
      const by = capeBase[i + 1];
      const depth = Math.max(0, 0.54 - by);
      arr[i] = bx + Math.sin(elapsed * 3 + by * 4) * 0.02 * depth;
      arr[i + 2] = capeBase[i + 2] - depth * (0.16 + motion * 0.35) - Math.sin(elapsed * 2.4 + bx * 3) * 0.02;
    }
    pos.needsUpdate = true;
    capeGeo.computeVertexNormals();
    for (const c of clothList) {
      const cp = c.mesh.geometry.attributes.position as THREE.BufferAttribute;
      const ca = cp.array as Float32Array;
      for (let i = 0; i < ca.length; i += 3) {
        const by = c.base[i + 1];
        const depth = Math.max(0, 0.26 - by);
        ca[i] = c.base[i] + Math.sin(elapsed * 3.4 + by * 5) * 0.012 * depth;
        ca[i + 2] = c.base[i + 2] + Math.sin(elapsed * 2.8 + c.base[i] * 4) * 0.02 * depth + motion * 0.04 * depth;
      }
      cp.needsUpdate = true;
    }
    const pulse = 2.1 + glowBoost * 3.4 + Math.sin(elapsed * 3.2) * 0.5;
    glow.emissiveIntensity = pulse;
    bladeMat.emissiveIntensity = 0.45 + glowBoost * 1.8 + Math.sin(elapsed * 2.4) * 0.12;
    glowSpriteMat.opacity = 0.4 + glowBoost * 0.5;
    ringMat.opacity = 0.28 + Math.sin(elapsed * 2) * 0.08;
  };

  const setGlow = (v: number) => {
    glowBoost = v;
  };

  const setMotion = (speed: number) => {
    motion = THREE.MathUtils.clamp(speed / 5, 0, 1);
  };

  const dispose = () => {
    mixer.stopAllAction();
    mixer.uncacheRoot(fall);
    geos.forEach((g) => g.dispose());
    mats.forEach((m) => m.dispose());
    glowSpriteMat.dispose();
  };

  // tiny decorative meshes do not need to cast shadows (halves the shadow pass)
  root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh && m.geometry) {
      if (!m.geometry.boundingSphere) m.geometry.computeBoundingSphere();
      const r = m.geometry.boundingSphere?.radius ?? 1;
      if (r < 0.075) m.castShadow = false;
    }
  });

  root.scale.setScalar(cfg.scale);
  return {
    cfg,
    root,
    fall,
    joints: { hips, spine, chest, neck, head, fall },
    mixer,
    actions,
    weaponTip,
    glowMats,
    glowSprites,
    cape: { mesh: cape, base: capeBase },
    cloth: clothList,
    ring,
    current,
    play,
    update,
    setGlow,
    setMotion,
    dispose,
  };
}
