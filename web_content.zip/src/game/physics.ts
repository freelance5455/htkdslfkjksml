export interface Collider {
  box: boolean;
  x: number;
  z: number;
  r: number;
  hx: number;
  hz: number;
  c: number;
  s: number;
  top: number;
  bottom: number;
  stamp: number;
}

export function circleCol(x: number, z: number, r: number, top: number, bottom = -1e9): Collider {
  return { box: false, x, z, r, hx: 0, hz: 0, c: 1, s: 0, top, bottom, stamp: 0 };
}
/** oriented box; rot uses same convention as GeoBuilder.box */
export function boxCol(x: number, z: number, hx: number, hz: number, rot: number, top: number, bottom = -1e9): Collider {
  return { box: true, x, z, r: Math.hypot(hx, hz), hx, hz, c: Math.cos(rot), s: Math.sin(rot), top, bottom, stamp: 0 };
}

const SC = 16;
const staticGrid = new Map<number, Collider[]>();
const key = (cx: number, cz: number) => (cx + 1000) * 4000 + (cz + 1000);

export function addStatic(c: Collider) {
  const x0 = Math.floor((c.x - c.r) / SC), x1 = Math.floor((c.x + c.r) / SC);
  const z0 = Math.floor((c.z - c.r) / SC), z1 = Math.floor((c.z + c.r) / SC);
  for (let z = z0; z <= z1; z++)
    for (let x = x0; x <= x1; x++) {
      const k = key(x, z);
      let l = staticGrid.get(k);
      if (!l) staticGrid.set(k, (l = []));
      l.push(c);
    }
}
export function clearStatics() {
  staticGrid.clear();
}

let stampCounter = 1;
export function queryStatic(x: number, z: number, out: Collider[]) {
  const st = ++stampCounter;
  const cx = Math.floor(x / SC), cz = Math.floor(z / SC);
  for (let dz = -1; dz <= 1; dz++)
    for (let dx = -1; dx <= 1; dx++) {
      const l = staticGrid.get(key(cx + dx, cz + dz));
      if (!l) continue;
      for (let i = 0; i < l.length; i++) {
        if (l[i].stamp !== st) {
          l[i].stamp = st;
          out.push(l[i]);
        }
      }
    }
}

/** local coords of point in box space */
function toLocal(c: Collider, x: number, z: number) {
  const rx = x - c.x, rz = z - c.z;
  // inverse of P(lx,lz) = [lx*c + lz*s, -lx*s + lz*c]
  return [rx * c.c - rz * c.s, rx * c.s + rz * c.c];
}
function fromLocal(c: Collider, lx: number, lz: number) {
  return [c.x + lx * c.c + lz * c.s, c.z - lx * c.s + lz * c.c];
}

export function insideCollider(c: Collider, x: number, z: number, pad = 0) {
  if (!c.box) {
    const dx = x - c.x, dz = z - c.z;
    return dx * dx + dz * dz < (c.r + pad) * (c.r + pad);
  }
  const [lx, lz] = toLocal(c, x, z);
  return Math.abs(lx) < c.hx + pad && Math.abs(lz) < c.hz + pad;
}

export const STEP = 0.45;

/** push the player out of colliders; returns ground height contributed by platforms */
export function resolveCollisions(pos: { x: number; y: number; z: number }, radius: number, list: Collider[], height = 1.7): number {
  let ground = -1e9;
  for (let i = 0; i < list.length; i++) {
    const c = list[i];
    const dx0 = pos.x - c.x, dz0 = pos.z - c.z;
    const lim = c.r + radius + 0.2;
    if (dx0 * dx0 + dz0 * dz0 > lim * lim) continue;
    if (pos.y >= c.top - STEP) {
      if (insideCollider(c, pos.x, pos.z, radius * 0.5)) ground = Math.max(ground, c.top);
      continue;
    }
    if (pos.y + height < c.bottom) continue;
    if (!c.box) {
      const d = Math.sqrt(dx0 * dx0 + dz0 * dz0);
      const m = c.r + radius;
      if (d < m) {
        const k = d > 1e-4 ? (m - d) / d : 1;
        pos.x += dx0 * k;
        pos.z += dz0 * k;
      }
    } else {
      const [lx, lz] = toLocal(c, pos.x, pos.z);
      const qx = Math.max(-c.hx, Math.min(c.hx, lx));
      const qz = Math.max(-c.hz, Math.min(c.hz, lz));
      let ox = lx - qx, oz = lz - qz;
      const d = Math.sqrt(ox * ox + oz * oz);
      let nx = lx, nz = lz;
      if (d > 1e-5) {
        if (d < radius) {
          nx = qx + (ox / d) * radius;
          nz = qz + (oz / d) * radius;
        } else continue;
      } else {
        // inside: push out along minimal axis
        const px = c.hx - Math.abs(lx), pz = c.hz - Math.abs(lz);
        if (px < pz) nx = Math.sign(lx || 1) * (c.hx + radius);
        else nz = Math.sign(lz || 1) * (c.hz + radius);
      }
      const [wx, wz] = fromLocal(c, nx, nz);
      pos.x = wx;
      pos.z = wz;
    }
  }
  return ground;
}
