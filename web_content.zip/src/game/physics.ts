import * as THREE from 'three';
import {
  HOUSE_FLOOR_Y,
  WORLD_HALF_SIZE,
  groundHeightAt,
  isInsideMainHouse,
  type ColliderBox,
  type TreePhysicsActor,
} from './world';
import type { BikeCustomization, ControlInputs, GameSettings } from './types';
import type { WeatherPhysicsModifiers } from './weather';

// 140 km/h strict speed cap for the 160cc motorcycle
export const MAX_SPEED_KMH = 140;
export const MAX_SPEED_MS = MAX_SPEED_KMH / 3.6; // ~38.89 m/s

// 5-speed 160cc gearbox target speed ranges (km/h)
const GEAR_MAX_SPEEDS = [0, 34, 62, 92, 118, 140];

export class MotoPhysicsEngine {
  public x = 7;
  public y = 0;
  public z = -10;
  public heading = Math.PI * 0.82; // Facing out of Casa Principal onto Avenida Central
  public speedMs = 0;
  public vy = 0;

  public engineOn = false;
  public cranking = false;
  private crankTimer = 0;

  public rpm = 0;
  public gear = 0; // 0 = Neutro, 1..5
  public steerAngle = 0;
  public leanAngle = 0;

  // Wheelie ("Grau") state
  public wheelieRad = 0; // 0 = flat, ~0.85-1.10 rad = sweet spot, > 1.48 rad = wipeout
  public wheelieVel = 0;
  public isWheelieing = false;
  public isScraping = false;
  public currentGrauScore = 0;
  public bestGrauScore = 0;
  public totalGrauDistM = 0;

  public crashed = false;
  private crashTimer = 0;

  // On-foot player state (when dismounted from the bike)
  public isOnFoot = false;
  public playerX = 7;
  public playerY = 0;
  public playerZ = -10;
  public playerHeading = Math.PI * 0.82;
  public playerSpeed = 0;

  public resetToHouse(): void {
    this.isOnFoot = false;
    this.x = 7;
    this.z = -10;
    this.y = groundHeightAt(this.x, this.z);
    this.heading = Math.PI * 0.82;
    this.speedMs = 0;
    this.vy = 0;
    this.wheelieRad = 0;
    this.wheelieVel = 0;
    this.leanAngle = 0;
    this.steerAngle = 0;
    this.crashed = false;
    this.currentGrauScore = 0;
    this.playerX = this.x;
    this.playerY = this.y;
    this.playerZ = this.z;
    this.playerHeading = this.heading;
    this.playerSpeed = 0;
  }

  public isNearMoto(): boolean {
    return Math.hypot(this.playerX - this.x, this.playerZ - this.z) <= 3.8;
  }

  public dismountMoto(): void {
    if (this.isOnFoot) return;
    this.isOnFoot = true;
    this.speedMs = 0;
    this.wheelieRad = 0;
    this.wheelieVel = 0;
    this.leanAngle = 0;
    this.steerAngle = 0;
    this.crashed = false;
    this.currentGrauScore = 0;
    // Place rider right next to the left side of the parked motorcycle
    this.playerX = this.x - Math.cos(this.heading) * 1.15;
    this.playerZ = this.z + Math.sin(this.heading) * 1.15;
    this.playerY = groundHeightAt(this.playerX, this.playerZ);
    this.playerHeading = this.heading;
    this.playerSpeed = 0;
  }

  public mountMoto(): boolean {
    if (!this.isOnFoot) return true;
    if (!this.isNearMoto()) return false;
    this.isOnFoot = false;
    this.playerSpeed = 0;
    return true;
  }

  public toggleIgnition(): 'started' | 'stopped' | 'cranking' {
    if (this.engineOn) {
      this.engineOn = false;
      this.cranking = false;
      this.gear = 0;
      return 'stopped';
    }
    if (!this.cranking) {
      this.cranking = true;
      this.crankTimer = 0.42;
      return 'cranking';
    }
    return 'cranking';
  }

  public step(
    dt: number,
    inputs: ControlInputs,
    custom: BikeCustomization,
    weatherMod: WeatherPhysicsModifiers,
    colliders: ColliderBox[],
    trees: TreePhysicsActor[],
    onCrash: () => void,
    onTreeHit?: (treeIdx: number, dirX: number, dirZ: number, speedMs: number, isTrunkHit: boolean) => void,
    doorCollider?: ColliderBox,
    doorOpen?: boolean,
    settings?: GameSettings
  ): { wheelSpinDelta: number } {
    const safeDt = Math.min(dt, 0.05);

    // Handle starter motor crank sequence
    if (this.cranking) {
      this.crankTimer -= safeDt;
      this.rpm = 650;
      if (this.crankTimer <= 0) {
        this.cranking = false;
        this.engineOn = true;
        this.rpm = 1450;
        this.gear = 1;
      }
    }

    // Handle crash recovery timer
    if (this.crashed) {
      this.crashTimer -= safeDt;
      this.speedMs *= Math.max(0, 1 - safeDt * 4);
      this.wheelieRad = THREE.MathUtils.damp(this.wheelieRad, 0, 5, safeDt);
      if (this.crashTimer <= 0) {
        this.crashed = false;
        this.wheelieRad = 0;
        this.wheelieVel = 0;
        this.speedMs = 0;
      }
    }

    // Upgrade & tire multipliers (capped at 140 km/h top speed)
    const motorPowerMult = 1 + (custom.motorLevel - 1) * 0.16;
    const gearPunchMult = 1 + (custom.gearRatioLevel - 1) * 0.14;
    const brakeUpgradeMult = 1 + (custom.brakeLevel - 1) * 0.15;
    const suspMult = 1 + (custom.suspensionLevel - 1) * 0.12;

    let tireDryBonus = 1;
    let tireRainBonus = 1;
    if (custom.tire === 'slick') {
      tireDryBonus = 1.12;
      tireRainBonus = 0.85;
    } else if (custom.tire === 'misto') {
      tireDryBonus = 0.96;
      tireRainBonus = 1.18;
    }

    const effectiveGrip =
      weatherMod.gripMultiplier *
      THREE.MathUtils.lerp(tireDryBonus, tireRainBonus, weatherMod.rainFactor);

    const speedKmh = Math.abs(this.speedMs) * 3.6;

    // 5-speed automatic clutch simulation with realistic 160cc shift points
    if (!this.engineOn) {
      this.gear = 0;
      this.rpm = THREE.MathUtils.damp(this.rpm, 0, 8, safeDt);
    } else if (speedKmh < 1.5 && !inputs.throttle) {
      this.gear = 1;
    } else {
      let g = 1;
      for (let i = 1; i <= 5; i++) {
        if (speedKmh <= GEAR_MAX_SPEEDS[i]) {
          g = i;
          break;
        }
        g = 5;
      }
      this.gear = g;
    }

    // Slope gravity along heading
    const aheadX = this.x - Math.sin(this.heading) * 1.4;
    const aheadZ = this.z - Math.cos(this.heading) * 1.4;
    const slopeSin = THREE.MathUtils.clamp(
      (groundHeightAt(aheadX, aheadZ) - groundHeightAt(this.x, this.z)) / 1.4,
      -0.42,
      0.42
    );

    // Longitudinal forces
    if (!this.crashed) {
      if (this.engineOn && inputs.throttle) {
        // Torque curve: strongest in 1st–3rd gear, tapers gently toward 140 km/h rev limiter
        const gearFactor = 1.25 - (this.gear - 1) * 0.16;
        const speedRatio = speedKmh / MAX_SPEED_KMH;
        const revLimiterCut = speedKmh >= MAX_SPEED_KMH - 0.6 ? 0 : 1 - Math.pow(speedRatio, 2.2) * 0.58;
        const accel = 13.8 * motorPowerMult * gearPunchMult * gearFactor * revLimiterCut * effectiveGrip;
        this.speedMs += accel * safeDt;
      } else {
        // Engine braking + aerodynamic drag
        const engineBrake = this.engineOn ? 2.1 : 0.7;
        const aeroDrag = 0.011 * weatherMod.dragMultiplier * this.speedMs * Math.abs(this.speedMs);
        const decel = (engineBrake + Math.abs(aeroDrag)) * safeDt;
        if (this.speedMs > 0) {
          this.speedMs = Math.max(0, this.speedMs - decel);
        } else if (this.speedMs < 0) {
          this.speedMs = Math.min(0, this.speedMs + decel);
        }
      }

      // Braking (when NOT holding wheelie, or strong brake)
      if (inputs.brake) {
        if (this.wheelieRad > 0.14 && this.speedMs > 2) {
          // Projeto Grau 2 rear-brake modulation: gentle speed bleed while pulling nose down!
          this.speedMs = Math.max(0, this.speedMs - 5.5 * safeDt);
        } else if (this.speedMs > 0.25) {
          this.speedMs = Math.max(
            0,
            this.speedMs - 24.5 * weatherMod.brakeMultiplier * brakeUpgradeMult * effectiveGrip * safeDt
          );
        } else {
          // Gentle foot-push reverse when stopped
          this.speedMs = Math.max(-3.6, this.speedMs - 4.5 * safeDt);
        }
      }

      // Slope gravity effect
      this.speedMs -= slopeSin * 9.2 * safeDt;
      this.speedMs = THREE.MathUtils.clamp(this.speedMs, -3.6, MAX_SPEED_MS);
    }

    // RPM calculation
    if (this.engineOn) {
      const gMin = GEAR_MAX_SPEEDS[Math.max(0, this.gear - 1)] * 0.72;
      const gMax = GEAR_MAX_SPEEDS[Math.max(1, this.gear)];
      const ratioInGear = THREE.MathUtils.clamp((speedKmh - gMin) / Math.max(12, gMax - gMin), 0, 1);
      let targetRpm = 1550 + ratioInGear * 7750;
      if (inputs.throttle && this.speedMs < 2.5) {
        targetRpm = Math.max(targetRpm, 5800); // Clutch revving!
      }
      if (speedKmh >= 138.5 && inputs.throttle) {
        targetRpm = 9400 + Math.sin(performance.now() * 0.06) * 450; // Corte de giro at 140 km/h
      }
      this.rpm = THREE.MathUtils.damp(this.rpm, targetRpm, 12, safeDt);
    }

    // Steering & Counter-steer lean (modulated by user sensitivity settings)
    const steerSens = settings?.steeringSensitivity ?? 1.0;
    const wheelieSens = settings?.wheelieSensitivity ?? 1.0;
    const steerInput = (inputs.left ? 1 : 0) - (inputs.right ? 1 : 0);
    const maxSteer = THREE.MathUtils.lerp(0.54, 0.15, Math.min(1, speedKmh / 110)) * Math.min(1.45, 0.65 + steerSens * 0.35);
    const targetSteer = steerInput * maxSteer;
    this.steerAngle = THREE.MathUtils.damp(this.steerAngle, targetSteer, 8.5 + steerSens * 4.5, safeDt);

    const turnRate = (this.speedMs / 1.45) * Math.sin(this.steerAngle) * effectiveGrip * (0.78 + steerSens * 0.22);
    // Slight wet slide attenuation during rain turns
    const wheelieTurnScale = this.wheelieRad > 0.25 ? 0.58 : 1.0;
    this.heading += turnRate * wheelieTurnScale * safeDt;

    const targetLean = -steerInput * Math.min(0.62, (speedKmh / 75) * 0.45 * (0.8 + steerSens * 0.2)) * effectiveGrip;
    this.leanAngle = THREE.MathUtils.damp(this.leanAngle, targetLean, 7 + steerSens * 2.5, safeDt);

    // Realistic Wheelie ("Empinar / Grau") Physics!
    if (!this.crashed) {
      const canPullWheelie = this.engineOn && this.speedMs > 2.2;
      const speedWheelieBand = THREE.MathUtils.clamp(1.2 - (speedKmh / 128) * 0.72, 0.35, 1.15);
      let pitchTorque = 0;

      if (inputs.wheelie && canPullWheelie) {
        const throttleBoost = inputs.throttle ? 1.18 : 0.45;
        pitchTorque += 6.2 * gearPunchMult * wheelieSens * weatherMod.wheelieLiftMultiplier * speedWheelieBand * throttleBoost;
      }

      // Gravity pulling front wheel back down (stronger near flat, lighter near balance point ~58 deg)
      const gravityPull = Math.cos(this.wheelieRad) * 3.65;
      pitchTorque -= gravityPull;

      // Rear brake ("Freio traseiro") brings the front wheel down fast and saves a 12 o'clock loop-out!
      if (inputs.brake && this.wheelieRad > 0.04) {
        pitchTorque -= 6.8 * brakeUpgradeMult * weatherMod.brakeMultiplier;
      }

      // Subtle throttle balance assist near sweet spot (0.78..1.08 rad)
      if (inputs.throttle && !inputs.wheelie && this.wheelieRad > 0.4 && this.wheelieRad < 1.15) {
        pitchTorque += 2.2;
      }

      // Damping
      this.wheelieVel += pitchTorque * safeDt;
      this.wheelieVel *= Math.exp(-3.4 * safeDt);
      this.wheelieRad += this.wheelieVel * safeDt;

      if (this.wheelieRad <= 0) {
        this.wheelieRad = 0;
        if (this.wheelieVel < -2.2) {
          this.wheelieVel = -this.wheelieVel * 0.12 / suspMult; // Fork rebound bounce
        } else {
          this.wheelieVel = 0;
        }
      }

      // Loop-out check (> 86 degrees)
      if (this.wheelieRad > 1.50) {
        this.crashed = true;
        this.crashTimer = 2.8;
        this.currentGrauScore = 0;
        onCrash();
      }
    }

    const wheelieDeg = THREE.MathUtils.radToDeg(this.wheelieRad);
    this.isWheelieing = !this.crashed && wheelieDeg >= 14 && this.speedMs > 2.0;
    this.isScraping = !this.crashed && wheelieDeg >= 73 && this.speedMs > 2.5;

    if (this.isWheelieing) {
      const sweetSpotBonus = wheelieDeg >= 42 && wheelieDeg <= 68 ? 2.2 : 1.0;
      const distStep = Math.abs(this.speedMs) * safeDt;
      this.totalGrauDistM += distStep;
      this.currentGrauScore += Math.round(distStep * 15 * sweetSpotBonus);
      if (this.currentGrauScore > this.bestGrauScore) {
        this.bestGrauScore = this.currentGrauScore;
      }
    } else if (wheelieDeg < 6) {
      this.currentGrauScore = 0;
    }

    // Move horizontally (local forward is -Z)
    const dirX = -Math.sin(this.heading);
    const dirZ = -Math.cos(this.heading);
    let nextX = this.x + dirX * this.speedMs * safeDt;
    let nextZ = this.z + dirZ * this.speedMs * safeDt;

    // 1000 x 1000 world bounds (-492..+492)
    nextX = THREE.MathUtils.clamp(nextX, -WORLD_HALF_SIZE + 8, WORLD_HALF_SIZE - 8);
    nextZ = THREE.MathUtils.clamp(nextZ, -WORLD_HALF_SIZE + 8, WORLD_HALF_SIZE - 8);

    // AABB Collision Resolution against houses, skyscrapers, favela structures, and closed door
    const bikeRadius = 0.72;
    const totalColliders = !doorOpen && doorCollider ? colliders.length + 1 : colliders.length;
    for (let i = 0; i < totalColliders; i++) {
      const c = i < colliders.length ? colliders[i] : (doorCollider as ColliderBox);
      if (
        nextX + bikeRadius > c.minX &&
        nextX - bikeRadius < c.maxX &&
        nextZ + bikeRadius > c.minZ &&
        nextZ - bikeRadius < c.maxZ
      ) {
        const overlapL = nextX + bikeRadius - c.minX;
        const overlapR = c.maxX - (nextX - bikeRadius);
        const overlapT = nextZ + bikeRadius - c.minZ;
        const overlapB = c.maxZ - (nextZ - bikeRadius);
        const minOverlap = Math.min(overlapL, overlapR, overlapT, overlapB);

        if (minOverlap === overlapL) nextX = c.minX - bikeRadius;
        else if (minOverlap === overlapR) nextX = c.maxX + bikeRadius;
        else if (minOverlap === overlapT) nextZ = c.minZ - bikeRadius;
        else nextZ = c.maxZ + bikeRadius;

        if (Math.abs(this.speedMs) > 18 && !this.crashed) {
          this.crashed = true;
          this.crashTimer = 2.8;
          this.speedMs *= 0.2;
          onCrash();
        } else {
          this.speedMs *= 0.45;
        }
      }
    }

    // Cylindrical Tree Trunk & Canopy Physics
    for (let i = 0; i < trees.length; i++) {
      const tr = trees[i];
      if (tr.fallen) continue;
      const dx = nextX - tr.x;
      const dz = nextZ - tr.z;
      const distSq = dx * dx + dz * dz;
      const canopyCheck = tr.canopyRadius + bikeRadius;
      if (distSq > canopyCheck * canopyCheck) continue;

      const dist = Math.sqrt(distSq);
      const minTrunkDist = tr.trunkRadius + bikeRadius;

      if (dist < minTrunkDist && dist > 0.0001) {
        const nx = dx / dist;
        const nz = dz / dist;
        // Push bike radially out of trunk
        nextX = tr.x + nx * minTrunkDist;
        nextZ = tr.z + nz * minTrunkDist;

        const impactSpeed = Math.abs(this.speedMs);
        // Impact direction into tree is (-nx, -nz)
        onTreeHit?.(i, -nx, -nz, impactSpeed, true);

        if (impactSpeed >= 18 && !this.crashed) {
          this.crashed = true;
          this.crashTimer = 2.8;
          this.speedMs *= 0.28;
          onCrash();
        } else {
          this.speedMs *= 0.45;
        }
      } else if (Math.abs(this.speedMs) > 4.5 && dist > 0.0001) {
        // Grazing under tree branches rustles leaves!
        onTreeHit?.(i, dirX, dirZ, Math.abs(this.speedMs), false);
      }
    }

    this.x = nextX;
    this.z = nextZ;

    // Ground height follow + realistic speed-bump & hill jump gravity
    const groundY = groundHeightAt(this.x, this.z);
    const prevSlopeRise = slopeSin * Math.abs(this.speedMs);
    if (this.y > groundY + 0.04 || this.vy > 0) {
      this.vy -= 18.5 * safeDt;
      this.y += this.vy * safeDt;
      if (this.y <= groundY) {
        this.y = groundY;
        this.vy = 0;
      }
    } else {
      if (prevSlopeRise > 2.2 && this.speedMs > 12) {
        this.vy = Math.min(3.8, prevSlopeRise * 0.45);
      }
      this.y = groundY;
    }

    // Wheel spin angle delta (radius ~0.25m)
    const wheelSpinDelta = (this.speedMs * safeDt) / 0.255;
    return { wheelSpinDelta };
  }

  public stepOnFoot(
    dt: number,
    inputs: ControlInputs,
    colliders: ColliderBox[],
    trees: TreePhysicsActor[],
    doorCollider: ColliderBox,
    doorOpen: boolean,
    settings?: GameSettings
  ): void {
    const safeDt = Math.min(dt, 0.05);
    const steerSens = settings?.steeringSensitivity ?? 1.0;
    const turnInput = (inputs.left ? 1 : 0) - (inputs.right ? 1 : 0);
    this.playerHeading += turnInput * (2.35 * (0.7 + steerSens * 0.3)) * safeDt;

    let targetSpeed = 0;
    if (inputs.throttle) targetSpeed = 4.6;
    else if (inputs.brake) targetSpeed = -2.6;
    this.playerSpeed = THREE.MathUtils.damp(this.playerSpeed, targetSpeed, 12, safeDt);

    const dirX = -Math.sin(this.playerHeading);
    const dirZ = -Math.cos(this.playerHeading);
    let nextX = this.playerX + dirX * this.playerSpeed * safeDt;
    let nextZ = this.playerZ + dirZ * this.playerSpeed * safeDt;

    nextX = THREE.MathUtils.clamp(nextX, -WORLD_HALF_SIZE + 8, WORLD_HALF_SIZE - 8);
    nextZ = THREE.MathUtils.clamp(nextZ, -WORLD_HALF_SIZE + 8, WORLD_HALF_SIZE - 8);

    const playerRadius = 0.38;
    const totalColliders = !doorOpen ? colliders.length + 1 : colliders.length;
    for (let i = 0; i < totalColliders; i++) {
      const c = i < colliders.length ? colliders[i] : doorCollider;
      if (
        nextX + playerRadius > c.minX &&
        nextX - playerRadius < c.maxX &&
        nextZ + playerRadius > c.minZ &&
        nextZ - playerRadius < c.maxZ
      ) {
        const overlapL = nextX + playerRadius - c.minX;
        const overlapR = c.maxX - (nextX - playerRadius);
        const overlapT = nextZ + playerRadius - c.minZ;
        const overlapB = c.maxZ - (nextZ - playerRadius);
        const minOverlap = Math.min(overlapL, overlapR, overlapT, overlapB);

        if (minOverlap === overlapL) nextX = c.minX - playerRadius;
        else if (minOverlap === overlapR) nextX = c.maxX + playerRadius;
        else if (minOverlap === overlapT) nextZ = c.minZ - playerRadius;
        else nextZ = c.maxZ + playerRadius;
      }
    }

    // Keep player from walking right through the parked motorcycle
    const bdx = nextX - this.x;
    const bdz = nextZ - this.z;
    const bDistSq = bdx * bdx + bdz * bdz;
    const minBikeDist = 0.88;
    if (bDistSq < minBikeDist * minBikeDist && bDistSq > 0.0001) {
      const bDist = Math.sqrt(bDistSq);
      nextX = this.x + (bdx / bDist) * minBikeDist;
      nextZ = this.z + (bdz / bDist) * minBikeDist;
    }

    for (let i = 0; i < trees.length; i++) {
      const tr = trees[i];
      if (tr.fallen) continue;
      const dx = nextX - tr.x;
      const dz = nextZ - tr.z;
      const minDist = tr.trunkRadius + playerRadius;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist && distSq > 0.0001) {
        const dist = Math.sqrt(distSq);
        nextX = tr.x + (dx / dist) * minDist;
        nextZ = tr.z + (dz / dist) * minDist;
      }
    }

    this.playerX = nextX;
    this.playerZ = nextZ;
    this.playerY = isInsideMainHouse(nextX, nextZ)
      ? HOUSE_FLOOR_Y
      : Math.max(groundHeightAt(nextX, nextZ), Math.abs(nextX) < 12 && nextZ > -35 && nextZ < -17 ? 0.16 : 0);
  }
}
