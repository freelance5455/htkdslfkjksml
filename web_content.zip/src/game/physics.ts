import { World, Vec2, Box, Circle, RevoluteJoint, WeldJoint, Body } from 'planck';
import type { Contact, ContactImpulse } from 'planck';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
export const HOLD = 0;
export const CONTRACT = 1;
export const EXTEND = 2;
export const RELAX = 3;
export const STATE_NAMES = ['Hold', 'Contract', 'Extend', 'Relax'];
export const STATE_COLORS = ['#facc15', '#ef4444', '#22c55e', '#38bdf8'];

export const DT = 1 / 60;
export const TURN_STEPS = 30; // 0.5 s of simulated time per turn
export const MAX_HP = 300;

export const TUNE = { kp: 12, torqueScale: 0.8, vel: 20, pos: 8, hold: 9, sub: 2, gravity: -9 };
const IMPACT_THRESHOLD = 0.34;
const HIT_COOLDOWN = 14; // sub-steps between damaging hits of the same body pair
const MAX_EXCESS = 8; // ignore resting contacts
const DAMAGE_SCALE = 28;
const DISMEMBER_FORCE = 2.6;

// ---------------------------------------------------------------------------
// Body definition (all angles are in the fighter's local frame, facing +x,
// CCW positive; mirrored automatically for the fighter facing left)
// ---------------------------------------------------------------------------
export interface JointDef {
  name: string;
  lo: number;
  hi: number;
  contract: number; // target limit when contracting
  extend: number; // target limit when extending
  speed: number; // rad/s
  torque: number;
}

export interface PartDef {
  id: string;
  name: string;
  parent: number;
  shape: 'box' | 'circle';
  hx: number;
  hy: number;
  pA: [number, number];
  cA: [number, number];
  a0: number;
  dmg: number;
  side: 0 | 1 | 2; // 0 center, 1 near, 2 far
  kind: 'torso' | 'head' | 'arm' | 'hand' | 'leg' | 'foot';
  joint?: JointDef;
}

function buildParts(): PartDef[] {
  const parts: PartDef[] = [];
  parts.push({ id: 'pelvis', name: 'Pelvis', parent: -1, shape: 'box', hx: 0.13, hy: 0.1, pA: [0, 0], cA: [0, 0], a0: 0, dmg: 1.3, side: 0, kind: 'torso' });
  parts.push({
    id: 'abs', name: 'Stomach', parent: 0, shape: 'box', hx: 0.115, hy: 0.12, pA: [0, 0.1], cA: [0, -0.12], a0: 0, dmg: 1, side: 0, kind: 'torso',
    joint: { name: 'Abs', lo: -0.6, hi: 0.35, contract: -0.6, extend: 0.35, speed: 4, torque: 45 },
  });
  parts.push({
    id: 'chest', name: 'Chest', parent: 1, shape: 'box', hx: 0.13, hy: 0.19, pA: [0, 0.12], cA: [0, -0.19], a0: -0.1, dmg: 1, side: 0, kind: 'torso',
    joint: { name: 'Chest', lo: -0.5, hi: 0.35, contract: -0.5, extend: 0.35, speed: 4, torque: 45 },
  });
  parts.push({
    id: 'head', name: 'Head', parent: 2, shape: 'circle', hx: 0.14, hy: 0.14, pA: [0, 0.19], cA: [0, -0.12], a0: 0.1, dmg: 1.7, side: 0, kind: 'head',
    joint: { name: 'Neck', lo: -0.6, hi: 0.6, contract: -0.6, extend: 0.6, speed: 5, torque: 9 },
  });

  const arm = (side: 1 | 2, sh: number, el: number) => {
    const s = side === 1 ? 'R' : 'L';
    const base = parts.length;
    parts.push({
      id: 'uarm' + s, name: 'Upper arm ' + s, parent: 2, shape: 'box', hx: 0.055, hy: 0.16, pA: [0, 0.12], cA: [0, 0.16], a0: sh, dmg: 0.55, side, kind: 'arm',
      joint: { name: s + ' Shoulder', lo: -1.2, hi: 2.4, contract: 2.4, extend: -1.2, speed: 6, torque: 16 },
    });
    parts.push({
      id: 'farm' + s, name: 'Forearm ' + s, parent: base, shape: 'box', hx: 0.05, hy: 0.14, pA: [0, -0.16], cA: [0, 0.14], a0: el, dmg: 0.45, side, kind: 'arm',
      joint: { name: s + ' Elbow', lo: 0, hi: 2.6, contract: 2.6, extend: 0, speed: 9, torque: 12 },
    });
    parts.push({
      id: 'hand' + s, name: 'Hand ' + s, parent: base + 1, shape: 'box', hx: 0.06, hy: 0.07, pA: [0, -0.14], cA: [0, 0.07], a0: 0, dmg: 0, side, kind: 'hand',
      joint: { name: s + ' Wrist', lo: -0.8, hi: 0.8, contract: 0.8, extend: -0.8, speed: 8, torque: 5 },
    });
  };
  const leg = (side: 1 | 2, hip: number, knee: number) => {
    const s = side === 1 ? 'R' : 'L';
    const base = parts.length;
    parts.push({
      id: 'thigh' + s, name: 'Thigh ' + s, parent: 0, shape: 'box', hx: 0.08, hy: 0.225, pA: [0, -0.06], cA: [0, 0.225], a0: hip, dmg: 0.55, side, kind: 'leg',
      joint: { name: s + ' Hip', lo: -1.1, hi: 2.0, contract: 2.0, extend: -1.1, speed: 6, torque: 60 },
    });
    parts.push({
      id: 'shin' + s, name: 'Shin ' + s, parent: base, shape: 'box', hx: 0.065, hy: 0.2, pA: [0, -0.225], cA: [0, 0.2], a0: knee, dmg: 0.45, side, kind: 'leg',
      joint: { name: s + ' Knee', lo: -2.5, hi: 0, contract: -2.5, extend: 0, speed: 8, torque: 55 },
    });
    parts.push({
      id: 'foot' + s, name: 'Foot ' + s, parent: base + 1, shape: 'box', hx: 0.18, hy: 0.05, pA: [0, -0.2], cA: [-0.09, 0.05], a0: -(hip + knee), dmg: 0, side, kind: 'foot',
      joint: { name: s + ' Ankle', lo: -0.9, hi: 0.9, contract: 0.9, extend: -0.9, speed: 6, torque: 40 },
    });
  };
  arm(1, 0.7, 1.6);
  arm(2, 0.9, 1.8);
  leg(1, 0.45, -0.5);
  leg(2, -0.25, -0.18);
  return parts;
}

export const PARTS: PartDef[] = buildParts();
export const NUM_PARTS = PARTS.length;
export const PART_INDEX: Record<string, number> = {};
PARTS.forEach((p, i) => (PART_INDEX[p.id] = i));
export const JOINT_IDS = PARTS.map((p, i) => (p.joint ? i : -1)).filter((i) => i >= 0);
export const HAND_IDS = [PART_INDEX['handR'], PART_INDEX['handL']];

// Draw order: far side first, then center, then near side
export const DRAW_ORDER: number[] = [
  ...PARTS.map((_, i) => i).filter((i) => PARTS[i].side === 2),
  ...PARTS.map((_, i) => i).filter((i) => PARTS[i].side === 0),
  ...PARTS.map((_, i) => i).filter((i) => PARTS[i].side === 1),
];

// Forward kinematics of the initial pose (facing right)
function computePose() {
  const pos: [number, number][] = [];
  const ang: number[] = [];
  PARTS.forEach((p, i) => {
    if (p.parent < 0) {
      pos[i] = [0, 0];
      ang[i] = 0;
      return;
    }
    const pa = ang[p.parent];
    const pp = pos[p.parent];
    const ca = pa + p.a0;
    const ax = pp[0] + p.pA[0] * Math.cos(pa) - p.pA[1] * Math.sin(pa);
    const ay = pp[1] + p.pA[0] * Math.sin(pa) + p.pA[1] * Math.cos(pa);
    ang[i] = ca;
    pos[i] = [ax - (p.cA[0] * Math.cos(ca) - p.cA[1] * Math.sin(ca)), ay - (p.cA[0] * Math.sin(ca) + p.cA[1] * Math.cos(ca))];
  });
  let lowest = Infinity;
  PARTS.forEach((p, i) => {
    if (p.shape === 'circle') lowest = Math.min(lowest, pos[i][1] - p.hx);
    else {
      for (const sx of [-1, 1])
        for (const sy of [-1, 1]) {
          const x = sx * p.hx;
          const y = sy * p.hy;
          lowest = Math.min(lowest, pos[i][1] + x * Math.sin(ang[i]) + y * Math.cos(ang[i]));
        }
    }
  });
  return { pos, ang, shift: -lowest + 0.002 };
}
const POSE = computePose();

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export interface HitEvent {
  x: number;
  y: number;
  dmg: number;
  imp: number;
  victim: number;
  part: number;
  dismember: boolean;
}

export interface Fighter {
  idx: number;
  dir: 1 | -1;
  bodies: Body[];
  joints: (RevoluteJoint | null)[];
  state: number[];
  hold: number[];
  grip: [boolean, boolean]; // near hand, far hand
  gripJoints: [WeldJoint | null, WeldJoint | null];
  damage: number;
  broken: boolean[];
}

export interface Snapshot {
  bodies: number[][][]; // [fighter][part] -> [x,y,a,vx,vy,w]
  state: number[][];
  hold: number[][];
  damage: number[];
}

export interface SimOptions {
  dismember: boolean;
}

interface BodyData {
  f: number;
  p: number;
}

// ---------------------------------------------------------------------------
// Simulation
// ---------------------------------------------------------------------------
export class Sim {
  world: World;
  fighters: Fighter[] = [];
  events: HitEvent[] = [];
  opts: SimOptions;
  stepCount = 0;
  tick = 0;
  lastHit = new Map<number, number>();

  constructor(opts: SimOptions) {
    this.opts = opts;
    this.world = new World({ gravity: new Vec2(0, TUNE.gravity) });

    const ground = this.world.createBody({ type: 'static' });
    ground.createFixture({ shape: new Box(40, 0.5, new Vec2(0, -0.5), 0), friction: 1.0, restitution: 0 });
    ground.createFixture({ shape: new Box(0.5, 12, new Vec2(-9.5, 12), 0), friction: 0.2 });
    ground.createFixture({ shape: new Box(0.5, 12, new Vec2(9.5, 12), 0), friction: 0.2 });

    this.fighters.push(this.makeFighter(0, -1.5, 1));
    this.fighters.push(this.makeFighter(1, 1.5, -1));

    this.world.on('post-solve', (contact: Contact, impulse: ContactImpulse) => this.onPostSolve(contact, impulse));
  }

  private makeFighter(idx: number, rootX: number, dir: 1 | -1): Fighter {
    const bodies: Body[] = [];
    const joints: (RevoluteJoint | null)[] = [];
    PARTS.forEach((p, i) => {
      const body = this.world.createBody({
        type: 'dynamic',
        position: new Vec2(rootX + dir * POSE.pos[i][0], POSE.pos[i][1] + POSE.shift),
        angle: dir * POSE.ang[i],
        linearDamping: 0.03,
        angularDamping: 0.15,
      });
      body.setUserData({ f: idx, p: i } as BodyData);
      const shape = p.shape === 'circle' ? new Circle(p.hx) : new Box(p.hx, p.hy);
      body.createFixture({
        shape,
        density: p.kind === 'foot' ? 1.4 : 1,
        friction: p.kind === 'foot' ? 1.4 : 0.7,
        restitution: 0.02,
        filterGroupIndex: -(idx + 1),
        userData: { f: idx, p: i } as BodyData,
      });
      bodies.push(body);
    });

    PARTS.forEach((p, i) => {
      if (!p.joint) {
        joints.push(null);
        return;
      }
      const j = p.joint;
      const lo = dir === 1 ? j.lo : -j.hi;
      const hi = dir === 1 ? j.hi : -j.lo;
      const joint = new RevoluteJoint({
        bodyA: bodies[p.parent],
        bodyB: bodies[i],
        localAnchorA: new Vec2(p.pA[0] * dir, p.pA[1]),
        localAnchorB: new Vec2(p.cA[0] * dir, p.cA[1]),
        referenceAngle: 0,
        enableLimit: true,
        lowerAngle: lo,
        upperAngle: hi,
        enableMotor: true,
        maxMotorTorque: j.torque,
        motorSpeed: 0,
      });
      this.world.createJoint(joint);
      joints.push(joint);
    });

    return {
      idx,
      dir,
      bodies,
      joints,
      state: PARTS.map(() => HOLD),
      hold: PARTS.map(() => 0),
      grip: [false, false],
      gripJoints: [null, null],
      damage: 0,
      broken: PARTS.map(() => false),
    };
  }

  // -------------------------------------------------------------------------
  jointAngle(f: Fighter, i: number): number {
    const j = f.joints[i];
    return j ? f.dir * j.getJointAngle() : 0;
  }

  jointWorldPos(f: Fighter, i: number): Vec2 {
    const p = PARTS[i];
    return f.bodies[p.parent].getWorldPoint(new Vec2(p.pA[0] * f.dir, p.pA[1]));
  }

  pelvis(f: Fighter): Vec2 {
    return f.bodies[0].getPosition();
  }

  // Called at the start of every turn
  beginTurn() {
    for (const f of this.fighters) {
      for (const i of JOINT_IDS) {
        if (f.joints[i]) f.hold[i] = this.jointAngle(f, i);
      }
      // release grips that were switched off
      for (let h = 0; h < 2; h++) {
        const gj = f.gripJoints[h];
        if (!f.grip[h] && gj) {
          this.world.destroyJoint(gj);
          f.gripJoints[h] = null;
        }
      }
    }
  }

  private applyMotors() {
    for (const f of this.fighters) {
      for (const i of JOINT_IDS) {
        const joint = f.joints[i];
        if (!joint) continue;
        const d = PARTS[i].joint!;
        const st = f.state[i];
        const ang = f.dir * joint.getJointAngle();
        let v = 0;
        let torque = d.torque * TUNE.torqueScale;
        if (st === RELAX) {
          torque = 0.25;
          v = 0;
        } else if (st === HOLD) {
          v = Math.max(-TUNE.hold, Math.min(TUNE.hold, TUNE.kp * (f.hold[i] - ang)));
        } else {
          const target = st === CONTRACT ? d.contract : d.extend;
          const err = target - ang;
          v = Math.max(-d.speed, Math.min(d.speed, err * 40));
        }
        joint.setMaxMotorTorque(torque);
        joint.setMotorSpeed(v * f.dir);
      }
    }
  }

  private onPostSolve(contact: Contact, impulse: ContactImpulse) {
    const fa = contact.getFixtureA();
    const fb = contact.getFixtureB();
    const ua = fa.getUserData() as BodyData | null;
    const ub = fb.getUserData() as BodyData | null;
    if (!ua || !ub || ua.f === ub.f) return;
    const n = impulse.normalImpulses;
    let maxI = 0;
    let total = 0;
    for (let k = 0; k < n.length; k++) {
      maxI = Math.max(maxI, n[k]);
      total += n[k];
    }
    const imp = Math.max(maxI, total * 0.7);
    if (imp < IMPACT_THRESHOLD) return;
    // gripped bodies never hurt each other, and the same pair can't hit every sub-step
    for (const f of this.fighters) {
      for (const gj of f.gripJoints) {
        if (!gj) continue;
        const ga = gj.getBodyA();
        const gb = gj.getBodyB();
        const ba = fa.getBody();
        const bb = fb.getBody();
        if ((ga === ba && gb === bb) || (ga === bb && gb === ba)) return;
      }
    }
    const key = (ua.f * 20 + ua.p) * 40 + (ub.f * 20 + ub.p);
    const last = this.lastHit.get(key);
    if (last !== undefined && this.tick - last < HIT_COOLDOWN) return;
    this.lastHit.set(key, this.tick);
    const wm = contact.getWorldManifold(null);
    const pt = wm && wm.points[0] ? wm.points[0] : fa.getBody().getPosition();
    for (const victim of [ua, ub]) {
      const part = PARTS[victim.p];
      const excess = Math.min(MAX_EXCESS, imp - IMPACT_THRESHOLD);
      const dmg = excess * part.dmg * DAMAGE_SCALE;
      if (dmg <= 0.2) continue;
      const dis = this.opts.dismember && part.kind !== 'torso' && part.dmg > 0 && excess * (part.kind === 'head' ? 0.8 : part.dmg) > DISMEMBER_FORCE;
      this.events.push({ x: pt.x, y: pt.y, dmg, imp, victim: victim.f, part: victim.p, dismember: dis });
    }
  }

  step() {
    const evStart = this.events.length;
    for (let s = 0; s < TUNE.sub; s++) {
      this.applyMotors();
      this.tick++;
      this.world.step(DT / TUNE.sub, TUNE.vel, TUNE.pos);
    }
    this.stepCount++;

    // process hits (outside of the solver)
    for (let k = evStart; k < this.events.length; k++) {
      const e = this.events[k];
      const f = this.fighters[e.victim];
      f.damage += e.dmg;
      if (e.dismember) this.breakJoint(f, e.part);
    }

    // grips
    for (const f of this.fighters) {
      for (let h = 0; h < 2; h++) {
        if (!f.grip[h] || f.gripJoints[h]) continue;
        const hand = f.bodies[HAND_IDS[h]];
        for (let ce = hand.getContactList(); ce; ce = ce.next ?? null) {
          const c = ce.contact;
          if (!c || !ce.other || !c.isTouching()) continue;
          const od = ce.other.getUserData() as BodyData | null;
          if (!od || od.f === f.idx) continue;
          const wm = c.getWorldManifold(null);
          const pt = wm && wm.points[0] ? wm.points[0] : hand.getPosition();
          const other = ce.other;
          const wj = new WeldJoint({
            bodyA: hand,
            bodyB: other,
            localAnchorA: hand.getLocalPoint(pt),
            localAnchorB: other.getLocalPoint(pt),
            referenceAngle: other.getAngle() - hand.getAngle(),
          });
          this.world.createJoint(wj);
          f.gripJoints[h] = wj;
          break;
        }
      }
    }
  }

  breakJoint(f: Fighter, i: number) {
    const j = f.joints[i];
    if (!j) return;
    this.world.destroyJoint(j);
    f.joints[i] = null;
    f.broken[i] = true;
    f.state[i] = RELAX;
    const p = PARTS[i];
    if (p.kind === 'hand') {
      const h = p.side - 1;
      const gj = f.gripJoints[h];
      if (gj) {
        this.world.destroyJoint(gj);
        f.gripJoints[h] = null;
      }
      f.grip[h] = false;
    }
  }

  setAllStates(f: Fighter, s: number) {
    for (const i of JOINT_IDS) if (!f.broken[i]) f.state[i] = s;
  }

  // -------------------------------------------------------------------------
  snapshot(): Snapshot {
    return {
      bodies: this.fighters.map((f) =>
        f.bodies.map((b) => {
          const p = b.getPosition();
          const v = b.getLinearVelocity();
          return [p.x, p.y, b.getAngle(), v.x, v.y, b.getAngularVelocity()];
        })
      ),
      state: this.fighters.map((f) => f.state.slice()),
      hold: this.fighters.map((f) => f.hold.slice()),
      damage: this.fighters.map((f) => f.damage),
    };
  }

  // Restore a snapshot (used by the AI "what-if" simulations)
  restore(s: Snapshot, broken: boolean[][]) {
    this.fighters.forEach((f, fi) => {
      f.bodies.forEach((b, bi) => {
        const d = s.bodies[fi][bi];
        b.setTransform(new Vec2(d[0], d[1]), d[2]);
        b.setLinearVelocity(new Vec2(d[3], d[4]));
        b.setAngularVelocity(d[5]);
        b.setAwake(true);
      });
      f.state = s.state[fi].slice();
      f.hold = s.hold[fi].slice();
      f.damage = s.damage[fi];
      f.grip = [false, false];
      for (let h = 0; h < 2; h++) {
        const gj = f.gripJoints[h];
        if (gj) {
          this.world.destroyJoint(gj);
          f.gripJoints[h] = null;
        }
      }
      broken[fi].forEach((br, i) => {
        if (br && !f.broken[i]) this.breakJoint(f, i);
      });
    });
    this.events.length = 0;
  }
}
