// ============================================================
// DEEP DIG — procedural 3D treasure models (3D environment artist)
// ============================================================
import * as THREE from "three";
import type { TDef } from "./data";
import { mulberry32 } from "./terrain";

let ENV: THREE.Texture | null = null;
const cache = new Map<string, THREE.MeshStandardMaterial>();
export function setEnv(t: THREE.Texture) {
  ENV = t;
  cache.clear();
}
export function getEnv() {
  return ENV;
}

export interface MOpts {
  metal?: number; rough?: number; em?: number; emI?: number; flat?: boolean;
  opacity?: number; env?: number; side?: boolean;
}
export function M(color: number, o: MOpts = {}): THREE.MeshStandardMaterial {
  const key = `${color}|${JSON.stringify(o)}`;
  let m = cache.get(key);
  if (m) return m;
  m = new THREE.MeshStandardMaterial({
    color,
    metalness: o.metal ?? 0,
    roughness: o.rough ?? 0.7,
    flatShading: o.flat ?? false,
    emissive: o.em !== undefined ? o.em : 0x000000,
    emissiveIntensity: o.emI ?? 1,
    transparent: o.opacity !== undefined && o.opacity < 1,
    opacity: o.opacity ?? 1,
    side: o.side ? THREE.DoubleSide : THREE.FrontSide,
    envMap: ENV,
    envMapIntensity: o.env ?? (o.metal ? 1.2 : 0.35),
  });
  cache.set(key, m);
  return m;
}
const gold = (c = 0xffc933) => M(c, { metal: 1, rough: 0.28, env: 1.4 });
const gemMat = (c: number, em = 0.35) => M(c, { metal: 0.15, rough: 0.05, flat: true, em: c, emI: em, env: 1.8 });

export function mesh(geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  m.castShadow = true;
  return m;
}
function jitter(geo: THREE.BufferGeometry, amt: number, seed: number) {
  const r = mulberry32(seed);
  const p = geo.attributes.position;
  const map = new Map<string, number[]>();
  for (let i = 0; i < p.count; i++) {
    const k = `${p.getX(i).toFixed(3)},${p.getY(i).toFixed(3)},${p.getZ(i).toFixed(3)}`;
    let d = map.get(k);
    if (!d) {
      d = [(r() - 0.5) * amt, (r() - 0.5) * amt, (r() - 0.5) * amt];
      map.set(k, d);
    }
    p.setXYZ(i, p.getX(i) + d[0], p.getY(i) + d[1], p.getZ(i) + d[2]);
  }
  geo.computeVertexNormals();
  return geo;
}
function lathe(pts: [number, number][], seg = 16) {
  return new THREE.LatheGeometry(pts.map((p) => new THREE.Vector2(p[0], p[1])), seg);
}
function extrude(pts: [number, number][], depth: number, bevel = 0.015) {
  const s = new THREE.Shape();
  pts.forEach((p, i) => (i ? s.lineTo(p[0], p[1]) : s.moveTo(p[0], p[1])));
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1 });
  g.translate(0, 0, -depth / 2);
  return g;
}
function cutGem(c: number, shape: number, scale = 1): THREE.Group {
  const g = new THREE.Group();
  const m = gemMat(c);
  if (shape === 0) {
    g.add(mesh(lathe([[0, -0.45], [0.5, 0.05], [0.42, 0.2], [0.22, 0.32], [0, 0.32]], 8), m));
  } else if (shape === 1) {
    const s = new THREE.Group();
    s.add(mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.14, 8, 1), m, 0, 0.0, 0));
    s.add(mesh(new THREE.CylinderGeometry(0.42, 0.5, 0.1, 8, 1), m, 0, 0.12, 0));
    s.add(mesh(new THREE.CylinderGeometry(0.28, 0.42, 0.1, 8, 1), m, 0, 0.22, 0));
    s.add(mesh(new THREE.CylinderGeometry(0.5, 0.15, 0.4, 8, 1), m, 0, -0.27, 0));
    s.scale.set(1, 1, 0.7);
    g.add(s);
  } else {
    g.add(mesh(new THREE.ConeGeometry(0.4, 0.35, 6), m, 0, 0.5, 0));
    g.add(mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.45, 6), m, 0, 0.1, 0));
    g.add(mesh(new THREE.ConeGeometry(0.4, 0.35, 6), m, 0, -0.3, 0, Math.PI, 0, 0));
    g.rotation.z = 0.5;
  }
  g.scale.setScalar(scale);
  return g;
}
function crystalCluster(c: number, n: number, seed: number, glow = 0.25, op = 0.9) {
  const g = new THREE.Group();
  const r = mulberry32(seed);
  const m = M(c, { metal: 0.1, rough: 0.12, flat: true, em: c, emI: glow, opacity: op, env: 1.6 });
  for (let i = 0; i < n; i++) {
    const h = 0.35 + r() * 0.5, w = 0.07 + r() * 0.07;
    const cr = new THREE.Group();
    cr.add(mesh(new THREE.CylinderGeometry(w, w * 1.05, h, 6), m, 0, h / 2, 0));
    cr.add(mesh(new THREE.ConeGeometry(w, w * 1.8, 6), m, 0, h + w * 0.9, 0));
    const a = r() * Math.PI * 2, tilt = 0.15 + r() * 0.5;
    cr.rotation.set(Math.sin(a) * tilt, r() * 6, Math.cos(a) * tilt);
    cr.position.set((r() - 0.5) * 0.25, 0, (r() - 0.5) * 0.25);
    g.add(cr);
  }
  return g;
}

export interface TreasureModel {
  obj: THREE.Group;
  halfH: number;
  rad: number;
  glow?: THREE.MeshStandardMaterial;
}

function build(def: TDef): THREE.Group {
  const g = new THREE.Group();
  const c = def.color, c2 = def.color2 ?? 0xffffff;
  const seed = def.id.length * 977 + c;
  switch (def.kind) {
    case "stone": {
      const m = mesh(jitter(new THREE.IcosahedronGeometry(0.5, 1), 0.18, seed), M(c, { rough: 0.95, flat: true }));
      m.scale.set(1, 0.7, 0.85);
      g.add(m);
      g.add(mesh(new THREE.SphereGeometry(0.1, 8, 6), M(0xd9d9d9, { rough: 1 }), 0.2, 0.22, 0.1));
      break;
    }
    case "scallop": {
      const len = 2.0;
      const m = M(c, { rough: 0.6, side: true });
      g.add(mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.06, 24, 1, false, -len / 2, len), m, 0, 0, 0));
      for (let a = -0.85; a <= 0.86; a += 0.17)
        g.add(mesh(new THREE.BoxGeometry(0.035, 0.05, 0.5), M(c2 || 0xe08a6a, { rough: 0.6 }), Math.sin(a) * 0.25, 0.035, Math.cos(a) * 0.25, 0, a, 0));
      g.add(mesh(new THREE.BoxGeometry(0.2, 0.06, 0.08), m, 0, 0.0, -0.02));
      g.rotation.x = -0.1;
      break;
    }
    case "spiral": {
      const sh = new THREE.Group();
      for (let i = 0; i < 6; i++) {
        const r = 0.32 * Math.pow(0.78, i);
        const m = mesh(new THREE.SphereGeometry(r, 14, 10), M(i % 2 ? def.color2! : c, { rough: 0.35, env: 0.8 }));
        m.position.set(Math.sin(i * 0.8) * 0.03, i * 0.2 - Math.pow(i, 1.25) * 0.02, 0);
        m.scale.y = 0.8;
        sh.add(m);
      }
      sh.add(mesh(new THREE.SphereGeometry(0.2, 12, 8), M(0xf2a5a0, { rough: 0.3 }), 0.22, -0.18, 0.12));
      sh.rotation.z = Math.PI / 2 - 0.2;
      g.add(sh);
      break;
    }
    case "starfish": {
      const pts: [number, number][] = [];
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2, r = i % 2 ? 0.17 : 0.5;
        pts.push([Math.cos(a) * r, Math.sin(a) * r]);
      }
      const geo = extrude(pts, 0.06, 0.03);
      geo.rotateX(-Math.PI / 2);
      g.add(mesh(geo, M(c, { rough: 0.9 })));
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        for (let k = 1; k < 4; k++) g.add(mesh(new THREE.SphereGeometry(0.02, 6, 4), M(0xf6d6a8), Math.cos(a) * 0.1 * k + 0.02, 0.06, Math.sin(a) * 0.1 * k));
      }
      break;
    }
    case "coin": {
      const dub = def.id === "doubloon";
      const body = M(c, { metal: 0.95, rough: dub ? 0.3 : 0.45, env: 1.3 });
      g.add(mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.07, dub ? 9 : 32), body));
      g.add(mesh(new THREE.TorusGeometry(0.45, 0.03, 6, dub ? 9 : 32), body, 0, 0.035, 0, Math.PI / 2));
      const em = M(def.color2 ?? 0x8a4a2a, { metal: 0.9, rough: 0.4 });
      g.add(mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.09, 16), em));
      if (dub) {
        g.add(mesh(new THREE.BoxGeometry(0.4, 0.1, 0.07), body, 0, 0, 0));
        g.add(mesh(new THREE.BoxGeometry(0.07, 0.1, 0.4), body, 0, 0, 0));
      } else {
        g.add(mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.1, 6), body));
      }
      g.rotation.z = 0.05;
      break;
    }
    case "fossil": {
      const slab = mesh(jitter(new THREE.CylinderGeometry(0.5, 0.52, 0.14, 9), 0.06, seed), M(0x8a7e70, { rough: 1, flat: true }));
      g.add(slab);
      for (let i = 0; i < 16; i++) {
        const t = i * 0.55;
        const r = 0.36 * Math.exp(-0.16 * t);
        const s = 0.07 * Math.exp(-0.1 * t) + 0.02;
        const m = mesh(new THREE.SphereGeometry(s, 8, 6), M(0xc9b9a0, { rough: 0.8 }), Math.cos(t) * r, 0.1, Math.sin(t) * r);
        m.scale.y = 1.2;
        g.add(m);
      }
      break;
    }
    case "glass": {
      const m = mesh(jitter(new THREE.IcosahedronGeometry(0.5, 0), 0.12, seed), M(c, { rough: 0.25, flat: true, opacity: 0.78, env: 1.2, em: c, emI: 0.15 }));
      m.scale.set(1, 0.4, 0.75);
      g.add(m);
      break;
    }
    case "button": {
      const m = M(c, { metal: 0.9, rough: 0.4 });
      g.add(mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.1, 24), m));
      g.add(mesh(new THREE.TorusGeometry(0.4, 0.04, 6, 24), m, 0, 0.05, 0, Math.PI / 2));
      for (const [x, z] of [[-0.08, -0.08], [0.08, -0.08], [-0.08, 0.08], [0.08, 0.08]]) g.add(mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.12, 6), M(0x3a2a14), x, 0.01, z));
      g.add(mesh(new THREE.TorusGeometry(0.16, 0.02, 6, 16), m, 0, 0.06, 0, Math.PI / 2));
      break;
    }
    case "arrowhead": {
      g.add(mesh(extrude([[0, 0.6], [0.3, -0.05], [0.13, -0.12], [0.1, -0.5], [-0.1, -0.5], [-0.13, -0.12], [-0.3, -0.05]], 0.07, 0.02).rotateX(-Math.PI / 2), M(c, { rough: 0.55, flat: true })));
      break;
    }
    case "bone": {
      const m = M(c, { rough: 0.85 });
      g.add(mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.8, 8), m, 0, 0, 0, 0, 0, Math.PI / 2));
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) g.add(mesh(new THREE.SphereGeometry(0.1, 8, 6), m, sx * 0.42, 0, sz * 0.07));
      break;
    }
    case "gem": {
      g.add(cutGem(c, def.shape || 0));
      break;
    }
    case "crystal": {
      g.add(crystalCluster(c, 4, seed, 0.2, 0.92));
      break;
    }
    case "vase": {
      const body = M(c, { rough: 0.8 });
      const v = new THREE.Group();
      v.add(mesh(lathe([[0, -0.5], [0.2, -0.5], [0.3, -0.35], [0.4, -0.08], [0.36, 0.16], [0.2, 0.34], [0.16, 0.44], [0.22, 0.52], [0.2, 0.52], [0.12, 0.46], [0, 0.44]], 16), body));
      const band = M(c2, { rough: 0.7 });
      v.add(mesh(new THREE.TorusGeometry(0.385, 0.018, 6, 20), band, 0, -0.02, 0, Math.PI / 2));
      v.add(mesh(new THREE.TorusGeometry(0.31, 0.018, 6, 20), band, 0, 0.2, 0, Math.PI / 2));
      v.add(mesh(new THREE.TorusGeometry(0.34, 0.012, 6, 20), band, 0, -0.2, 0, Math.PI / 2));
      for (const s of [-1, 1]) v.add(mesh(new THREE.TorusGeometry(0.12, 0.025, 6, 12, Math.PI), body, s * 0.2, 0.36, 0, 0, 0, s > 0 ? -Math.PI / 2 : Math.PI / 2));
      v.rotation.z = 1.1;
      g.add(v);
      break;
    }
    case "geode": {
      const shell = new THREE.SphereGeometry(0.5, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2);
      g.add(mesh(jitter(shell, 0.04, seed), M(0x6b5f55, { rough: 1, flat: true, side: true })));
      g.add(mesh(new THREE.SphereGeometry(0.42, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), M(c, { rough: 0.3, em: c, emI: 0.3, side: true }), 0, 0.01, 0));
      const r = mulberry32(seed);
      const cm = M(c, { metal: 0.1, rough: 0.1, flat: true, em: c, emI: 0.5, env: 1.6 });
      for (let i = 0; i < 16; i++) {
        const a = r() * Math.PI * 2, e = r() * 1.2, rr = 0.4;
        const x = Math.cos(a) * Math.sin(e) * rr, y = Math.cos(e) * rr, z = Math.sin(a) * Math.sin(e) * rr;
        const cone = mesh(new THREE.ConeGeometry(0.045, 0.16 + r() * 0.08, 5), cm, x, y, z);
        cone.lookAt(0, 0.1, 0);
        cone.rotateX(-Math.PI / 2);
        cone.position.set(x, y, z);
        g.add(cone);
      }
      break;
    }
    case "compass": {
      const br = M(c, { metal: 0.9, rough: 0.35 });
      g.add(mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.14, 28), br));
      g.add(mesh(new THREE.TorusGeometry(0.47, 0.035, 8, 28), br, 0, 0.07, 0, Math.PI / 2));
      g.add(mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.03, 28), M(0xf4ecd6, { rough: 0.6 }), 0, 0.075, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.43, 0.43, 0.02, 28), M(0xbfe6ff, { rough: 0.05, opacity: 0.25, env: 1.5 }), 0, 0.12, 0));
      g.add(mesh(new THREE.ConeGeometry(0.06, 0.7, 4), M(0xc92a2a), 0, 0.1, -0.17, Math.PI / 2, 0, 0));
      const n2 = mesh(new THREE.ConeGeometry(0.06, 0.7, 4), M(0xeeeeee), 0, 0.1, 0.17, -Math.PI / 2, 0, 0);
      n2.scale.set(1, 0.5, 1);
      g.add(n2);
      g.add(mesh(new THREE.TorusGeometry(0.1, 0.03, 6, 12), br, 0, 0.04, -0.58, Math.PI / 2));
      for (let i = 0; i < 4; i++) g.add(mesh(new THREE.BoxGeometry(0.02, 0.02, 0.1), M(0x222222), Math.sin((i * Math.PI) / 2) * 0.34, 0.095, Math.cos((i * Math.PI) / 2) * 0.34, 0, (i * Math.PI) / 2, 0));
      break;
    }
    case "watch": {
      const s = M(c, { metal: 1, rough: 0.25, env: 1.4 });
      g.add(mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.12, 28), s));
      g.add(mesh(new THREE.TorusGeometry(0.4, 0.035, 8, 28), s, 0, 0.06, 0, Math.PI / 2));
      g.add(mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.02, 28), M(0xf5f0e0), 0, 0.065, 0));
      g.add(mesh(new THREE.BoxGeometry(0.02, 0.02, 0.26), M(0x151515), 0.03, 0.085, -0.1, 0, 0.4, 0));
      g.add(mesh(new THREE.BoxGeometry(0.02, 0.02, 0.2), M(0x151515), -0.04, 0.085, -0.06, 0, -0.8, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.12, 10), s, 0, 0.03, -0.46, Math.PI / 2, 0, 0));
      g.add(mesh(new THREE.TorusGeometry(0.1, 0.02, 6, 12), s, 0, 0.03, -0.58, Math.PI / 2));
      for (let i = 0; i < 6; i++) g.add(mesh(new THREE.TorusGeometry(0.05, 0.012, 5, 8), s, 0.05 * Math.sin(i), 0.02, -0.7 - i * 0.07, i % 2 ? Math.PI / 2 : 0, 0, 0));
      break;
    }
    case "pearl": {
      g.add(mesh(new THREE.SphereGeometry(0.5, 24, 16), M(c, { metal: 0.25, rough: 0.12, em: 0xfff2e6, emI: 0.18, env: 1.8 })));
      break;
    }
    case "key": {
      const m = M(c, { metal: 0.7, rough: 0.6 });
      g.add(mesh(new THREE.TorusGeometry(0.16, 0.05, 8, 18), m, -0.38, 0, 0));
      g.add(mesh(new THREE.TorusGeometry(0.07, 0.03, 6, 10), m, -0.38, 0, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.7, 8), m, 0.08, 0, 0, 0, 0, Math.PI / 2));
      g.add(mesh(new THREE.BoxGeometry(0.1, 0.18, 0.05), m, 0.4, -0.07, 0));
      g.add(mesh(new THREE.BoxGeometry(0.08, 0.12, 0.05), m, 0.27, -0.05, 0));
      g.add(mesh(new THREE.TorusGeometry(0.06, 0.025, 6, 10), m, -0.12, 0, 0, 0, Math.PI / 2, 0));
      break;
    }
    case "mineral": {
      const m = M(c, { metal: 0.1, rough: 0.15, flat: true, em: c, emI: 0.25, opacity: 0.92, env: 1.5 });
      const base = mesh(jitter(new THREE.IcosahedronGeometry(0.3, 0), 0.1, seed), M(0x55504a, { rough: 1, flat: true }));
      base.scale.y = 0.6;
      g.add(base);
      const r = mulberry32(seed);
      for (let i = 0; i < 7; i++) {
        const s = 0.14 + r() * 0.12;
        const b = mesh(new THREE.BoxGeometry(s, s, s), m, (r() - 0.5) * 0.5, 0.1 + r() * 0.2, (r() - 0.5) * 0.5, r() * 2, r() * 2, r() * 2);
        g.add(b);
      }
      break;
    }
    case "nugget": {
      const gm = M(c, { metal: 1, rough: 0.38, flat: false, env: 1.5 });
      g.add(mesh(jitter(new THREE.IcosahedronGeometry(0.5, 2), 0.28, seed), gm));
      g.add(mesh(jitter(new THREE.IcosahedronGeometry(0.22, 1), 0.14, seed + 3), gm, 0.42, -0.1, 0.15));
      g.children[0].scale.set(1, 0.72, 0.85);
      break;
    }
    case "ring": {
      const gm = gold(c);
      const rg = new THREE.Group();
      rg.add(mesh(new THREE.TorusGeometry(0.3, 0.07, 10, 28), gm));
      rg.add(mesh(new THREE.CylinderGeometry(0.1, 0.07, 0.08, 6), gm, 0, 0.37, 0));
      const gem = cutGem(def.color2 ?? 0xe0143c, 0, 0.17);
      gem.position.set(0, 0.5, 0);
      rg.add(gem);
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + 0.78;
        rg.add(mesh(new THREE.SphereGeometry(0.02, 6, 4), gm, Math.cos(a) * 0.09, 0.44, Math.sin(a) * 0.09));
      }
      rg.rotation.x = 1.1;
      g.add(rg);
      break;
    }
    case "necklace": {
      const pm = M(c, { metal: 0.2, rough: 0.15, em: 0xfff2e6, emI: 0.15, env: 1.7 });
      const n = 26;
      for (let i = 0; i < n; i++) {
        const a = -Math.PI * 0.15 + (i / (n - 1)) * Math.PI * 1.3;
        g.add(mesh(new THREE.SphereGeometry(0.045, 10, 8), pm, Math.cos(a - Math.PI / 2) * 0.42, 0.045, Math.sin(a - Math.PI / 2) * 0.5 + 0.1));
      }
      g.add(mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.12, 8), gold(def.color2), 0.03, 0.045, -0.4, 0, 0, Math.PI / 2));
      const pend = cutGem(0x2bd29a, 0, 0.12);
      pend.position.set(0, 0.07, 0.57);
      g.add(pend);
      break;
    }
    case "scarab": {
      const gm = gold(c);
      const body = mesh(new THREE.SphereGeometry(0.5, 20, 14), gm);
      body.scale.set(0.85, 0.42, 1.1);
      g.add(body);
      const head = mesh(new THREE.SphereGeometry(0.2, 12, 8), gm, 0, 0, 0.55);
      head.scale.set(1.2, 0.6, 0.8);
      g.add(head);
      g.add(mesh(new THREE.BoxGeometry(0.02, 0.03, 0.9), M(0x6a4a10, { metal: 0.6, rough: 0.5 }), 0, 0.2, -0.05));
      for (const s of [-1, 1]) {
        g.add(mesh(new THREE.SphereGeometry(0.1, 10, 8), M(def.color2!, { rough: 0.25, em: def.color2!, emI: 0.3 }), s * 0.2, 0.18, 0.1));
        for (let i = 0; i < 3; i++) g.add(mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.3, 5), gm, s * 0.5, -0.02, -0.2 + i * 0.28, 0, 0, s * 1.2));
      }
      break;
    }
    case "goblet": {
      const sm = M(c, { metal: 1, rough: 0.22, env: 1.5 });
      const v = new THREE.Group();
      v.add(mesh(lathe([[0, -0.5], [0.28, -0.5], [0.3, -0.45], [0.1, -0.4], [0.05, -0.2], [0.07, -0.1], [0.3, 0.05], [0.36, 0.3], [0.34, 0.5], [0.31, 0.5], [0.32, 0.3], [0.27, 0.08], [0, 0.0]], 18), sm, 0, 0, 0));
      v.add(mesh(new THREE.TorusGeometry(0.2, 0.012, 6, 20), M(0x707680, { metal: 1, rough: 0.5 }), 0, 0.25, 0, Math.PI / 2));
      v.add(mesh(new THREE.SphereGeometry(0.07, 10, 8), sm, 0, -0.18, 0));
      v.rotation.z = 1.25;
      g.add(v);
      break;
    }
    case "mask": {
      const jm = M(c, { rough: 0.2, em: c, emI: 0.1, env: 1.0 });
      const f = mesh(new THREE.SphereGeometry(0.5, 20, 16), jm);
      f.scale.set(0.78, 1, 0.42);
      g.add(f);
      for (const s of [-1, 1]) {
        const eye = mesh(new THREE.SphereGeometry(0.1, 10, 8), M(0x0a1410), s * 0.18, 0.1, 0.19);
        eye.scale.set(1.2, 0.55, 0.5);
        g.add(eye);
        g.add(mesh(new THREE.BoxGeometry(0.2, 0.04, 0.05), jm, s * 0.19, 0.2, 0.2, 0, 0, s * -0.25));
      }
      g.add(mesh(new THREE.ConeGeometry(0.06, 0.25, 4), jm, 0, -0.03, 0.22, 0.1, 0, 0));
      g.add(mesh(new THREE.BoxGeometry(0.2, 0.05, 0.05), M(0x0a1410), 0, -0.25, 0.18));
      g.add(mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.04, 14, 1, false, 0, Math.PI), gold(0xf2b928), 0, 0.42, 0.1, Math.PI / 2 - 0.4, 0, 0));
      g.add(cutGem(0xe0143c, 0, 0.1).translateY(0.27).translateZ(0.22));
      g.rotation.x = -Math.PI / 2;
      break;
    }
    case "tablet": {
      const cm = M(c, { rough: 0.95 });
      g.add(mesh(extrude([[-0.4, -0.5], [0.4, -0.5], [0.42, 0.42], [0.1, 0.5], [-0.38, 0.46]], 0.1, 0.03).rotateX(-Math.PI / 2), cm));
      const r = mulberry32(seed);
      for (let row = 0; row < 7; row++)
        for (let k = 0; k < 5; k++)
          g.add(mesh(new THREE.ConeGeometry(0.025, 0.07, 3), M(0x6a4a2c, { rough: 1 }), -0.25 + k * 0.12 + (r() - 0.5) * 0.03, 0.065, -0.36 + row * 0.12, Math.PI / 2, 0, r() * 3));
      break;
    }
    case "amber": {
      const am = mesh(jitter(new THREE.SphereGeometry(0.5, 20, 14), 0.04, seed), M(c, { rough: 0.15, opacity: 0.8, em: c, emI: 0.35, env: 1.6 }));
      am.scale.set(1, 0.72, 0.8);
      g.add(am);
      const inner = new THREE.Group();
      inner.add(mesh(new THREE.SphereGeometry(0.06, 8, 6), M(0x2a1a0a), 0, 0, 0));
      for (const s of [-1, 1]) {
        const w = mesh(new THREE.SphereGeometry(0.1, 8, 6), M(0xfff0c0, { opacity: 0.6, rough: 0.2 }), s * 0.08, 0.04, -0.04);
        w.scale.set(1, 0.1, 0.5);
        w.rotation.z = s * 0.3;
        inner.add(w);
        for (let i = 0; i < 3; i++) inner.add(mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.1, 3), M(0x2a1a0a), s * 0.04, -0.04, -0.03 + i * 0.03, 0, 0, s * 1.1));
      }
      inner.rotation.set(0.3, 0.7, 0);
      g.add(inner);
      break;
    }
    case "idol": {
      const gm = gold(c);
      g.add(mesh(new THREE.BoxGeometry(0.62, 0.14, 0.5), gm, 0, -0.5, 0));
      const torso = mesh(new THREE.CylinderGeometry(0.2, 0.28, 0.55, 10), gm, 0, -0.15, 0);
      g.add(torso);
      g.add(mesh(new THREE.SphereGeometry(0.2, 14, 10), gm, 0, 0.27, 0));
      for (const s of [-1, 1]) {
        g.add(mesh(new THREE.SphereGeometry(0.035, 8, 6), M(c2, { rough: 0.1, em: c2, emI: 0.8 }), s * 0.08, 0.3, 0.18));
        g.add(mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.4, 6), gm, s * 0.3, -0.12, 0.05, 0, 0, s * 0.35));
      }
      g.add(mesh(new THREE.BoxGeometry(0.1, 0.03, 0.04), M(0x6a4a10, { metal: 1 }), 0, 0.2, 0.2));
      for (let i = -3; i <= 3; i++) g.add(mesh(new THREE.ConeGeometry(0.035, 0.28 - Math.abs(i) * 0.03, 5), gm, i * 0.075, 0.5 - Math.abs(i) * 0.02, 0, 0, 0, -i * 0.2));
      g.add(mesh(new THREE.TorusGeometry(0.2, 0.025, 6, 16), gm, 0, 0.38, 0, Math.PI / 2));
      break;
    }
    case "crown": {
      const gm = gold(c);
      g.add(mesh(new THREE.CylinderGeometry(0.4, 0.34, 0.26, 24, 1, true), M(c, { metal: 1, rough: 0.25, side: true, env: 1.4 })));
      g.add(mesh(new THREE.TorusGeometry(0.37, 0.035, 8, 28), gm, 0, -0.13, 0, Math.PI / 2));
      g.add(mesh(new THREE.TorusGeometry(0.4, 0.03, 8, 28), gm, 0, 0.13, 0, Math.PI / 2));
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        const tall = i % 2 === 0;
        const x = Math.cos(a) * 0.4, z = Math.sin(a) * 0.4;
        g.add(mesh(new THREE.ConeGeometry(0.07, tall ? 0.36 : 0.24, 5), gm, x, 0.3 + (tall ? 0.05 : 0), z));
        g.add(mesh(new THREE.SphereGeometry(0.045, 10, 8), M(tall ? 0xe0143c : 0xeeeeff, { rough: 0.1, em: tall ? 0xe0143c : 0xaaaaff, emI: 0.5, env: 1.6 }), x, tall ? 0.52 : 0.44, z));
        if (i % 2) g.add(cutGem(c2, 0, 0.1).translateX(Math.cos(a + 0.4) * 0.395).translateZ(Math.sin(a + 0.4) * 0.395));
      }
      const dome = mesh(new THREE.SphereGeometry(0.4, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), M(0x8a1030, { rough: 0.9, side: true }), 0, -0.05, 0);
      dome.scale.set(0.9, 0.6, 0.9);
      g.add(dome);
      break;
    }
    case "scepter": {
      const gm = gold(c);
      g.add(mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.1, 10), gm, 0, 0, 0, 0, 0, Math.PI / 2));
      for (const x of [-0.3, 0, 0.3]) g.add(mesh(new THREE.TorusGeometry(0.035, 0.015, 6, 12), gm, x, 0, 0, 0, Math.PI / 2, 0));
      const s = cutGem(c2, 2, 0.17);
      s.position.set(0.68, 0, 0);
      s.rotation.z = -Math.PI / 2;
      g.add(s);
      for (let i = 0; i < 4; i++) g.add(mesh(new THREE.TorusGeometry(0.12, 0.012, 6, 14, Math.PI), gm, 0.66, 0, 0, 0, (i / 4) * Math.PI, 0));
      g.add(mesh(new THREE.TorusGeometry(0.14, 0.035, 8, 16, Math.PI * 1.4), gm, -0.66, 0, 0.1, Math.PI / 2, 0, 0.3));
      g.add(mesh(new THREE.SphereGeometry(0.05, 8, 6), gm, -0.55, 0, 0));
      break;
    }
    case "chest": {
      const wood = M(c, { rough: 0.85 });
      const iron = M(0x2b2b30, { metal: 0.8, rough: 0.45 });
      const gm = gold(c2);
      g.add(mesh(new THREE.BoxGeometry(0.9, 0.45, 0.6), wood, 0, 0, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.9, 16, 1, false, 0, Math.PI), wood, 0, 0.225, 0, 0, 0, Math.PI / 2));
      for (const x of [-0.32, 0.32]) {
        g.add(mesh(new THREE.BoxGeometry(0.07, 0.46, 0.62), iron, x, 0, 0));
        g.add(mesh(new THREE.CylinderGeometry(0.31, 0.31, 0.07, 16, 1, false, 0, Math.PI), iron, x, 0.225, 0, 0, 0, Math.PI / 2));
      }
      g.add(mesh(new THREE.BoxGeometry(0.92, 0.06, 0.62), gm, 0, 0.2, 0));
      g.add(mesh(new THREE.BoxGeometry(0.12, 0.16, 0.05), gm, 0, 0.18, 0.32));
      g.add(mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.06, 6), M(0x111111), 0, 0.17, 0.35, Math.PI / 2, 0, 0));
      for (const x of [-0.44, 0.44]) for (const z of [-0.29, 0.29]) g.add(mesh(new THREE.SphereGeometry(0.04, 8, 6), gm, x, -0.2, z));
      break;
    }
    case "relics": {
      const gm = gold(c);
      const sv = M(c2, { metal: 0.9, rough: 0.35 });
      g.add(mesh(lathe([[0, -0.2], [0.14, -0.2], [0.2, -0.05], [0.16, 0.1], [0.09, 0.18], [0.12, 0.24], [0, 0.22]], 12), gm, -0.3, 0.2, 0.1));
      g.add(mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.04, 20), gm, 0.25, 0.0, 0.3));
      for (let i = 0; i < 12; i++) g.add(mesh(new THREE.ConeGeometry(0.025, 0.12, 4), gm, 0.25 + Math.cos(i * 0.52) * 0.33, 0.0, 0.3 + Math.sin(i * 0.52) * 0.33, 0, 0, 0).rotateZ(0));
      g.add(mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.06, 14), sv, 0.25, 0.04, 0.3));
      g.add(mesh(extrude([[0, 0.6], [0.06, 0.2], [0.04, -0.4], [-0.04, -0.4], [-0.06, 0.2]], 0.02, 0.005).rotateX(Math.PI / 2), sv, 0, -0.04, -0.3));
      g.add(mesh(new THREE.BoxGeometry(0.24, 0.04, 0.05), gm, 0, -0.02, -0.7));
      g.add(mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.2, 8), gm, 0, -0.02, -0.82, Math.PI / 2, 0, 0));
      break;
    }
    case "heart": {
      const m = M(c, { metal: 0.1, rough: 0.1, flat: true, em: c, emI: 0.9, opacity: 0.93, env: 1.8 });
      const big = new THREE.Group();
      big.add(mesh(new THREE.CylinderGeometry(0.18, 0.2, 0.7, 6), m, 0, 0.35, 0));
      big.add(mesh(new THREE.ConeGeometry(0.18, 0.45, 6), m, 0, 0.92, 0));
      g.add(big);
      const r = mulberry32(seed);
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * Math.PI * 2;
        const h = 0.25 + r() * 0.3;
        const cr = new THREE.Group();
        cr.add(mesh(new THREE.CylinderGeometry(0.07, 0.08, h, 6), m, 0, h / 2, 0));
        cr.add(mesh(new THREE.ConeGeometry(0.07, 0.2, 6), m, 0, h + 0.1, 0));
        cr.position.set(Math.cos(a) * 0.3, 0, Math.sin(a) * 0.3);
        cr.rotation.set(Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5);
        g.add(cr);
      }
      g.userData.glow = m;
      break;
    }
    case "hoard": {
      const gm = gold(c);
      const r = mulberry32(seed);
      const mound = mesh(new THREE.SphereGeometry(0.45, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), gm);
      mound.scale.set(1, 0.4, 1);
      g.add(mound);
      for (let i = 0; i < 34; i++) {
        const a = r() * Math.PI * 2, d = Math.sqrt(r()) * 0.4;
        const y = 0.2 * (1 - (d / 0.45) * (d / 0.45)) + r() * 0.05;
        const mc = mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.018, 12), M(r() < 0.3 ? 0xd9dde2 : c, { metal: 1, rough: 0.3, env: 1.4 }), Math.cos(a) * d, y, Math.sin(a) * d, (r() - 0.5) * 1.6, r() * 3, (r() - 0.5) * 1.6);
        g.add(mc);
      }
      for (let i = 0; i < 4; i++) {
        const a = r() * 6;
        const gem = cutGem(i % 2 ? 0xe0143c : 0x12c46a, 0, 0.1);
        gem.position.set(Math.cos(a) * 0.22, 0.2, Math.sin(a) * 0.22);
        g.add(gem);
      }
      g.add(mesh(new THREE.TorusGeometry(0.07, 0.015, 6, 12), gm, 0.1, 0.22, 0.05, 1.2, 0.3, 0));
      g.add(mesh(new THREE.TorusGeometry(0.12, 0.02, 6, 14), gm, -0.15, 0.24, -0.1, 0.4, 0, 0.3));
      break;
    }
    case "dagger": {
      const sv = M(0xdfe4ea, { metal: 1, rough: 0.2, env: 1.5 });
      const gm = gold(c);
      g.add(mesh(extrude([[0.7, 0], [0.1, 0.07], [-0.1, 0.07], [-0.1, -0.07], [0.1, -0.07]], 0.02, 0.005).rotateX(Math.PI / 2), sv));
      g.add(mesh(new THREE.BoxGeometry(0.06, 0.04, 0.36), gm, -0.12, 0, 0));
      g.add(mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.3, 8), gm, -0.3, 0, 0, 0, 0, Math.PI / 2));
      for (let i = 0; i < 4; i++) g.add(mesh(new THREE.TorusGeometry(0.037, 0.008, 5, 10), M(0x6a4a10, { metal: 1 }), -0.2 - i * 0.07, 0, 0, 0, Math.PI / 2, 0));
      g.add(mesh(new THREE.SphereGeometry(0.06, 10, 8), gm, -0.47, 0, 0));
      g.add(cutGem(c2, 0, 0.1).translateX(-0.12).translateY(0.04));
      g.add(cutGem(c2, 1, 0.07).translateX(-0.5).translateY(0.05));
      break;
    }
    case "diamond": {
      const dm = M(c, { metal: 0.0, rough: 0.0, flat: true, em: 0x9ed8ff, emI: 0.35, env: 3.0 });
      g.add(mesh(lathe([[0, -0.5], [0.5, 0.1], [0.4, 0.22], [0.2, 0.3], [0, 0.3]], 12), dm));
      const inner = mesh(lathe([[0, -0.45], [0.46, 0.09], [0.36, 0.2], [0.18, 0.27], [0, 0.27]], 12), dm);
      inner.rotation.y = Math.PI / 12;
      g.add(inner);
      g.userData.glow = dm;
      break;
    }
    default:
      g.add(mesh(new THREE.IcosahedronGeometry(0.4, 0), M(c)));
  }
  return g;
}

export function buildTreasure(def: TDef): TreasureModel {
  const raw = build(def);
  const box = new THREE.Box3().setFromObject(raw);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const s = def.size / Math.max(size.x, size.y, size.z);
  const wrap = new THREE.Group();
  raw.scale.setScalar(s);
  raw.position.copy(center).multiplyScalar(-s);
  wrap.add(raw);
  return {
    obj: wrap,
    halfH: (size.y * s) / 2,
    rad: (Math.max(size.x, size.z) * s) / 2,
    glow: raw.userData.glow,
  };
}
