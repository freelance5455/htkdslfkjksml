// ═══════════════════════════════════════════════════════════════
// DARK GHOUL V2 — الأنظمة المساعدة: رياضيات، صوت، حفظ
// ═══════════════════════════════════════════════════════════════
import { DEFAULT_SETTINGS, SaveData } from "./data";

// ── رياضيات ──
export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const damp = (a: number, b: number, l: number, dt: number) => lerp(a, b, 1 - Math.exp(-l * dt));
export const angDamp = (a: number, b: number, l: number, dt: number) => {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * (1 - Math.exp(-l * dt));
};
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ── الحفظ ──
const KEY = "dark_ghoul_v2_save";
export function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const d = JSON.parse(raw);
    return { ...defaultSave(), ...d, settings: { ...DEFAULT_SETTINGS, ...(d.settings || {}) } };
  } catch { return null; }
}
export function defaultSave(): SaveData {
  return {
    charId: "kuro", level: 1, xp: 0, cells: 2, skills: [], missionIdx: 0, done: [],
    unlocked: ["kuro", "rin", "daisuke"], flags: [], pos: null,
    settings: { ...DEFAULT_SETTINGS }, playTime: 0,
  };
}
export function storeSave(s: SaveData) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* ignore */ }
}
export function clearSave() {
  try { localStorage.removeItem(KEY); } catch { /* ignore */ }
}

// ── الصوت (WebAudio إجرائي بالكامل — لا ملفات خارجية) ──
export class AudioEngine {
  ctx: AudioContext | null = null;
  master!: GainNode; music!: GainNode; sfx!: GainNode;
  rainGain: GainNode | null = null;
  musicOn = true;
  started = false;

  ensure() {
    if (this.ctx) { if (this.ctx.state === "suspended") this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain(); this.master.gain.value = 0.9; this.master.connect(this.ctx.destination);
      this.music = this.ctx.createGain(); this.music.connect(this.master);
      this.sfx = this.ctx.createGain(); this.sfx.connect(this.master);
    } catch { this.ctx = null; }
  }
  setVolumes(m: number, s: number) {
    if (!this.ctx) return;
    this.music.gain.value = m; this.sfx.gain.value = s;
  }

  startMusic() {
    if (!this.ctx || this.started) return;
    this.started = true;
    const c = this.ctx;
    // طبقة درون مظلمة
    const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 260; lp.connect(this.music);
    [55, 55.4, 82.4].forEach((f, i) => {
      const o = c.createOscillator(); o.type = i === 2 ? "triangle" : "sawtooth"; o.frequency.value = f;
      const g = c.createGain(); g.gain.value = i === 2 ? 0.05 : 0.09;
      const lfo = c.createOscillator(); lfo.frequency.value = 0.05 + i * 0.03;
      const lg = c.createGain(); lg.gain.value = 0.035;
      lfo.connect(lg); lg.connect(g.gain);
      o.connect(g); g.connect(lp); o.start(); lfo.start();
    });
    // نغمة بيانو معتمة عشوائية (سلم ري الصغير)
    const scale = [73.4, 87.3, 98, 110, 130.8, 146.8, 174.6];
    const pluck = () => {
      if (!this.ctx) return;
      const f = scale[Math.floor(Math.random() * scale.length)] * (Math.random() < 0.3 ? 2 : 1);
      const o = this.ctx.createOscillator(); o.type = "triangle"; o.frequency.value = f;
      const g = this.ctx.createGain();
      const t0 = this.ctx.currentTime;
      g.gain.setValueAtTime(0, t0);
      g.gain.linearRampToValueAtTime(0.11, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 3.2);
      o.connect(g); g.connect(this.music);
      o.start(t0); o.stop(t0 + 3.4);
      setTimeout(pluck, 2600 + Math.random() * 4200);
    };
    setTimeout(pluck, 1200);
  }

  private noise(dur: number): AudioBufferSourceNode | null {
    if (!this.ctx) return null;
    const c = this.ctx, b = c.createBuffer(1, c.sampleRate * dur, c.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource(); s.buffer = b; return s;
  }
  private env(g: GainNode, t0: number, peak: number, dur: number) {
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(peak, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  }

  hit(power = 1) {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const n = this.noise(0.18)!; const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 900;
    const g = c.createGain(); this.env(g, t0, 0.35 * power, 0.16);
    n.connect(bp); bp.connect(g); g.connect(this.sfx); n.start(t0);
    const o = c.createOscillator(); o.type = "sine"; o.frequency.setValueAtTime(160, t0); o.frequency.exponentialRampToValueAtTime(45, t0 + 0.14);
    const g2 = c.createGain(); this.env(g2, t0, 0.4 * power, 0.18);
    o.connect(g2); g2.connect(this.sfx); o.start(t0); o.stop(t0 + 0.2);
  }
  slash() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const n = this.noise(0.25)!; const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(400, t0); bp.frequency.exponentialRampToValueAtTime(2600, t0 + 0.16);
    const g = c.createGain(); this.env(g, t0, 0.22, 0.22);
    n.connect(bp); bp.connect(g); g.connect(this.sfx); n.start(t0);
  }
  whoosh() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const n = this.noise(0.5)!; const bp = c.createBiquadFilter(); bp.type = "highpass";
    bp.frequency.setValueAtTime(300, t0); bp.frequency.exponentialRampToValueAtTime(3000, t0 + 0.4);
    const g = c.createGain(); this.env(g, t0, 0.16, 0.45);
    n.connect(bp); bp.connect(g); g.connect(this.sfx); n.start(t0);
  }
  boom() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const o = c.createOscillator(); o.type = "sine"; o.frequency.setValueAtTime(90, t0); o.frequency.exponentialRampToValueAtTime(28, t0 + 0.5);
    const g = c.createGain(); this.env(g, t0, 0.7, 0.6);
    o.connect(g); g.connect(this.sfx); o.start(t0); o.stop(t0 + 0.65);
  }
  transform() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const n = this.noise(1.6)!; const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = 2;
    bp.frequency.setValueAtTime(150, t0); bp.frequency.exponentialRampToValueAtTime(1400, t0 + 1.1);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(0.3, t0 + 0.9); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.6);
    n.connect(bp); bp.connect(g); g.connect(this.sfx); n.start(t0);
    setTimeout(() => this.boom(), 850);
    [110, 111.5].forEach((f) => {
      const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.setValueAtTime(f, t0); o.frequency.linearRampToValueAtTime(f * 1.9, t0 + 1.1);
      const og = c.createGain(); og.gain.setValueAtTime(0.0001, t0); og.gain.linearRampToValueAtTime(0.1, t0 + 0.7); og.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.5);
      o.connect(og); og.connect(this.sfx); o.start(t0); o.stop(t0 + 1.6);
    });
  }
  roar() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    [62, 63.5, 124].forEach((f) => {
      const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.setValueAtTime(f * 1.8, t0); o.frequency.exponentialRampToValueAtTime(f * 0.7, t0 + 1.1);
      const g = c.createGain(); this.env(g, t0, 0.16, 1.2);
      o.connect(g); g.connect(this.sfx); o.start(t0); o.stop(t0 + 1.25);
    });
  }
  step(alt: boolean) {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const n = this.noise(0.07)!; const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = alt ? 500 : 420;
    const g = c.createGain(); this.env(g, t0, 0.09, 0.07);
    n.connect(lp); lp.connect(g); g.connect(this.sfx); n.start(t0);
  }
  pickup() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    [660, 990].forEach((f, i) => {
      const o = c.createOscillator(); o.type = "sine"; o.frequency.value = f;
      const g = c.createGain(); this.env(g, t0 + i * 0.07, 0.12, 0.25);
      o.connect(g); g.connect(this.sfx); o.start(t0 + i * 0.07); o.stop(t0 + i * 0.07 + 0.3);
    });
  }
  ui() {
    if (!this.ctx) return;
    const c = this.ctx, t0 = c.currentTime;
    const o = c.createOscillator(); o.type = "square"; o.frequency.value = 220;
    const g = c.createGain(); this.env(g, t0, 0.06, 0.06);
    o.connect(g); g.connect(this.sfx); o.start(t0); o.stop(t0 + 0.08);
  }
  close() {
    try { this.ctx?.close(); } catch { /* ignore */ }
    this.ctx = null;
    this.started = false;
    this.rainGain = null;
  }
  rainStart(intensity: number) {
    if (!this.ctx) return;
    if (this.rainGain) { this.rainGain.gain.value = intensity * 0.1; return; }
    const n = this.noise(2)!; n.loop = true;
    const hp = this.ctx.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 900;
    this.rainGain = this.ctx.createGain(); this.rainGain.gain.value = intensity * 0.1;
    n.connect(hp); hp.connect(this.rainGain); this.rainGain.connect(this.sfx); n.start();
  }
  rainStop() { if (this.rainGain) this.rainGain.gain.value = 0; }
}
