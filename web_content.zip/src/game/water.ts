import * as THREE from "three";
import { LAKES, RIVERS, WATERFALL_X, cliffZ } from "./worldData";
import { makeWaterMat, makeWaterfallMat, makeFoamMat, shared, fallUniforms } from "./materials";
import { GeoBuilder } from "./geo";
import { mulberry32 } from "./noise";

export class WaterSystem {
  group = new THREE.Group();
  waterMat = makeWaterMat();
  private ducks: THREE.InstancedMesh | null = null;
  private duckData: { cx: number; cz: number; r: number; sp: number; ph: number; y: number }[] = [];
  private birds: THREE.InstancedMesh;
  private fireflies: THREE.Points;
  private ffCenter = new THREE.Vector3(1e9, 0, 0);
  private mist: THREE.Sprite[] = [];
  private splashMat: THREE.ShaderMaterial;
  private m = new THREE.Matrix4();
  private q = new THREE.Quaternion();
  private e = new THREE.Euler();
  private v = new THREE.Vector3();
  private s = new THREE.Vector3(1, 1, 1);
  fireflyMat: THREE.ShaderMaterial;

  constructor(vegMat: THREE.Material, structMat: THREE.Material) {
    // ---- Lakes ----
    LAKES.forEach((L) => {
      const seg = 48;
      const R = L.r * 1.3;
      const pos: number[] = [], uv: number[] = [], sp: number[] = [];
      for (let i = 0; i < seg; i++) {
        const a0 = (i / seg) * Math.PI * 2, a1 = ((i + 1) / seg) * Math.PI * 2;
        const p = [
          [0, 0], [Math.cos(a1) * R, Math.sin(a1) * R], [Math.cos(a0) * R, Math.sin(a0) * R],
        ];
        for (const [x, z] of p) {
          pos.push(x, 0, z);
          uv.push(L.x + x, L.z + z);
          sp.push(0);
        }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
      g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
      g.setAttribute("aSpeed", new THREE.Float32BufferAttribute(sp, 1));
      g.computeBoundingSphere();
      const mesh = new THREE.Mesh(g, this.waterMat);
      mesh.position.set(L.x, L.level!, L.z);
      mesh.renderOrder = 2;
      this.group.add(mesh);
    });

    // ---- Rivers ----
    const inLake = (x: number, z: number) => LAKES.some((L) => Math.hypot(x - L.x, z - L.z) < L.r * 0.8);
    RIVERS.forEach((r, ri) => {
      const samples: { x: number; z: number; hw: number; l: number; dx: number; dz: number; s: number }[] = [];
      let acc = 0;
      for (let i = 0; i < r.pts.length - 1; i++) {
        const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1];
        const len = Math.hypot(bx - ax, bz - az);
        const n = Math.max(1, Math.ceil(len / 3));
        for (let k = 0; k < n + (i === r.pts.length - 2 ? 1 : 0); k++) {
          const t = k / n;
          samples.push({
            x: ax + (bx - ax) * t, z: az + (bz - az) * t,
            hw: r.hw[i] + (r.hw[i + 1] - r.hw[i]) * t,
            l: r.levels![i] + (r.levels![i + 1] - r.levels![i]) * t,
            dx: (bx - ax) / len, dz: (bz - az) / len, s: acc + len * t,
          });
        }
        acc += len;
      }
      // smooth directions at joints
      for (let i = 1; i < samples.length - 1; i++) {
        const a = samples[i - 1], c = samples[i + 1];
        const dx = c.x - a.x, dz = c.z - a.z, l = Math.hypot(dx, dz);
        samples[i].dx = dx / l;
        samples[i].dz = dz / l;
      }
      const pos: number[] = [], uv: number[] = [], sp: number[] = [];
      const speed = ri === 0 ? 1.8 : 1.2;
      for (let i = 0; i < samples.length - 1; i++) {
        const a = samples[i], b = samples[i + 1];
        if (inLake(a.x, a.z) && inLake(b.x, b.z)) continue;
        const wa = a.hw + 2.2, wb = b.hw + 2.2;
        const A = [a.x - a.dz * wa, a.l, a.z + a.dx * wa], B = [a.x + a.dz * wa, a.l, a.z - a.dx * wa];
        const C = [b.x - b.dz * wb, b.l, b.z + b.dx * wb], D = [b.x + b.dz * wb, b.l, b.z - b.dx * wb];
        const quad = [A, D, B, A, C, D];
        const quv = [[-wa, a.s], [wb, b.s], [wa, a.s], [-wa, a.s], [-wb, b.s], [wb, b.s]];
        for (let k = 0; k < 6; k++) {
          pos.push(quad[k][0], quad[k][1], quad[k][2]);
          uv.push(quv[k][0], quv[k][1]);
          sp.push(speed);
        }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
      g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
      g.setAttribute("aSpeed", new THREE.Float32BufferAttribute(sp, 1));
      g.computeBoundingSphere();
      const mesh = new THREE.Mesh(g, this.waterMat);
      mesh.renderOrder = 2;
      this.group.add(mesh);
    });

    // ---- Waterfall ----
    const cz = cliffZ(WATERFALL_X);
    const Lup = RIVERS[0].levels![RIVERS[0].levels!.length - 1];
    const Lpool = LAKES[1].level!;
    {
      const rows = 14;
      const pos: number[] = [], uv: number[] = [];
      const pts: [number, number, number][] = [];
      pts.push([0, Lup, cz - 5.5]);
      for (let i = 0; i <= rows; i++) {
        const t = i / rows;
        pts.push([t, Lup - (Lup - Lpool + 0.3) * t, cz - 3.6 + 9.5 * Math.pow(t, 0.7)]);
      }
      let acc = 0;
      const accs: number[] = [0];
      for (let i = 1; i < pts.length; i++) {
        acc += Math.hypot(pts[i][1] - pts[i - 1][1], pts[i][2] - pts[i - 1][2]);
        accs.push(acc);
      }
      for (let i = 0; i < pts.length - 1; i++) {
        const a = pts[i], b = pts[i + 1];
        const wa = 4.4 + a[0] * 1.6, wb = 4.4 + b[0] * 1.6;
        const P = [
          [WATERFALL_X - wa, a[1], a[2], 0, accs[i]], [WATERFALL_X + wa, a[1], a[2], 1, accs[i]],
          [WATERFALL_X + wb, b[1], b[2], 1, accs[i + 1]], [WATERFALL_X - wb, b[1], b[2], 0, accs[i + 1]],
        ];
        for (const k of [0, 1, 2, 0, 2, 3]) {
          pos.push(P[k][0], P[k][1], P[k][2]);
          uv.push(P[k][3], P[k][4]);
        }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
      g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
      g.computeBoundingSphere();
      const fall = new THREE.Mesh(g, makeWaterfallMat());
      fall.renderOrder = 3;
      this.group.add(fall);
      // side trickles
      for (const sd of [-1, 1]) {
        const g2 = g.clone();
        const m = new THREE.Mesh(g2, fall.material);
        m.scale.set(0.18, 1, 1);
        m.position.set(WATERFALL_X * (1 - 0.18) + sd * 7.2, -0.5, 0.4);
        m.renderOrder = 3;
        this.group.add(m);
      }
      // foam
      const foam = new THREE.Mesh(new THREE.PlaneGeometry(16, 11), makeFoamMat());
      foam.rotation.x = -Math.PI / 2;
      foam.position.set(WATERFALL_X, Lpool + 0.06, cz + 7.5);
      foam.renderOrder = 4;
      this.group.add(foam);
      // splash particles
      const n = 70;
      const r = mulberry32(99);
      const pp = new Float32Array(n * 3), seed = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        pp[i * 3] = WATERFALL_X; pp[i * 3 + 1] = Lpool; pp[i * 3 + 2] = cz + 6.2;
        seed[i * 3] = r(); seed[i * 3 + 1] = r(); seed[i * 3 + 2] = r();
      }
      const pg = new THREE.BufferGeometry();
      pg.setAttribute("position", new THREE.BufferAttribute(pp, 3));
      pg.setAttribute("aSeed", new THREE.BufferAttribute(seed, 3));
      this.splashMat = new THREE.ShaderMaterial({
        uniforms: { uTime: shared.uTime, uLight: fallUniforms.uLight },
        transparent: true,
        depthWrite: false,
        vertexShader: `
          attribute vec3 aSeed; uniform float uTime; varying float vA;
          void main(){
            float t = fract(uTime * (0.5 + aSeed.z * 0.5) + aSeed.x);
            vec3 p = position;
            p.x += (aSeed.y - 0.5) * 11.0;
            p.z += (aSeed.z - 0.5) * 3.0 + t * (1.5 + aSeed.x * 2.0);
            p.y += sin(t * 3.14159) * (1.2 + aSeed.z * 2.5);
            vec4 mv = modelViewMatrix * vec4(p, 1.0);
            gl_Position = projectionMatrix * mv;
            gl_PointSize = clamp(90.0 / -mv.z, 1.0, 4.0);
            vA = 1.0 - t;
          }`,
        fragmentShader: `
          uniform float uLight; varying float vA;
          void main(){ gl_FragColor = vec4(vec3(0.95, 0.98, 1.0) * uLight, vA * 0.9); }`,
      });
      const pts2 = new THREE.Points(pg, this.splashMat);
      pts2.renderOrder = 5;
      pts2.frustumCulled = false;
      this.group.add(pts2);
      // mist sprites
      const cv = document.createElement("canvas");
      cv.width = cv.height = 16;
      const cx = cv.getContext("2d")!;
      for (let y = 0; y < 16; y++)
        for (let x = 0; x < 16; x++) {
          const d = Math.hypot(x - 7.5, y - 7.5) / 8;
          const a = Math.max(0, 1 - d) ** 1.5;
          cx.fillStyle = `rgba(235,245,255,${(Math.round(a * 4) / 4).toFixed(2)})`;
          cx.fillRect(x, y, 1, 1);
        }
      const mt = new THREE.CanvasTexture(cv);
      mt.magFilter = THREE.NearestFilter;
      mt.minFilter = THREE.NearestFilter;
      for (let i = 0; i < 3; i++) {
        const sm = new THREE.SpriteMaterial({ map: mt, transparent: true, opacity: 0.22, depthWrite: false });
        const sp = new THREE.Sprite(sm);
        sp.position.set(WATERFALL_X + (i - 1) * 4, Lpool + 2 + i, cz + 7 + i);
        sp.scale.set(10, 7, 1);
        sp.renderOrder = 6;
        this.mist.push(sp);
        this.group.add(sp);
      }
    }

    // ---- Lily pads ----
    const deco = new GeoBuilder();
    LAKES.forEach((L, li) => {
      if (!L.lilies && !L.ducks) return;
      const rnd = mulberry32(li * 31 + 7);
      const n = L.lilies ? 16 : 6;
      for (let i = 0; i < n; i++) {
        const a = rnd() * 6.28, d = L.r * (0.35 + rnd() * 0.45);
        const x = L.x + Math.cos(a) * d, z = L.z + Math.sin(a) * d, y = L.level! + 0.04;
        const rr = 0.4 + rnd() * 0.35;
        const k = 0.8 + rnd() * 0.3;
        for (let s = 0; s < 6; s++) {
          if (s === 0) continue;
          const a0 = (s / 6) * 6.28, a1 = ((s + 1) / 6) * 6.28;
          deco.tri(x, y, z, x + Math.cos(a1) * rr, y, z + Math.sin(a1) * rr, x + Math.cos(a0) * rr, y, z + Math.sin(a0) * rr, 0.22 * k, 0.46 * k, 0.2 * k);
        }
        if (rnd() < 0.35) deco.octa(x, y + 0.12, z, 0.14, 0.1, 0.14, 0.95, 0.6, 0.8, rnd());
      }
    });
    if (deco.count) this.group.add(new THREE.Mesh(deco.build(), vegMat));

    // ---- Ducks ----
    const duck = new GeoBuilder();
    const dr = mulberry32(5);
    duck.blob(0, 0.15, 0, 0.28, 0.2, 0.42, 0.55, 0.42, 0.3, dr, 0, 0.1);
    duck.blob(0, 0.42, 0.3, 0.14, 0.14, 0.14, 0.15, 0.4, 0.22, dr, 0, 0.05);
    duck.octa(0, 0.4, 0.46, 0.05, 0.035, 0.09, 0.95, 0.6, 0.15);
    duck.box(0, 0.22, -0.38, 0.14, 0.12, 0.12, 0, 0.3, 0.24, 0.18);
    const duckLakes = LAKES.filter((l) => l.ducks);
    const count = duckLakes.length * 3;
    this.ducks = new THREE.InstancedMesh(duck.build(), structMat, count);
    this.ducks.frustumCulled = false;
    duckLakes.forEach((L, i) => {
      for (let k = 0; k < 3; k++)
        this.duckData.push({ cx: L.x + (i % 2 ? 3 : -3), cz: L.z, r: L.r * (0.25 + k * 0.12), sp: 0.08 + k * 0.02, ph: k * 0.7 + i, y: L.level! - 0.02 });
    });
    this.group.add(this.ducks);

    // ---- Birds ----
    const bird = new GeoBuilder();
    bird.tri(0, 0, 0.3, -1.1, 0.25, -0.1, 0, 0, -0.3, 0.12, 0.1, 0.12);
    bird.tri(0, 0, -0.3, 1.1, 0.25, -0.1, 0, 0, 0.3, 0.12, 0.1, 0.12);
    this.birds = new THREE.InstancedMesh(bird.build(), new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide }), 9);
    this.birds.frustumCulled = false;
    this.group.add(this.birds);

    // ---- Fireflies ----
    const fn = 40;
    const fp = new Float32Array(fn * 3), fs = new Float32Array(fn * 3);
    const fr = mulberry32(77);
    for (let i = 0; i < fn; i++) {
      fp[i * 3] = (fr() - 0.5) * 50; fp[i * 3 + 1] = 0; fp[i * 3 + 2] = (fr() - 0.5) * 50;
      fs[i * 3] = fr(); fs[i * 3 + 1] = fr(); fs[i * 3 + 2] = fr();
    }
    const fg = new THREE.BufferGeometry();
    fg.setAttribute("position", new THREE.BufferAttribute(fp, 3));
    fg.setAttribute("aSeed", new THREE.BufferAttribute(fs, 3));
    this.fireflyMat = new THREE.ShaderMaterial({
      uniforms: { uTime: shared.uTime, uNight: { value: 0 } },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute vec3 aSeed; uniform float uTime; varying float vA;
        void main(){
          vec3 p = position;
          float t = uTime * (0.3 + aSeed.z * 0.3) + aSeed.x * 20.0;
          p.x += sin(t) * 2.0; p.z += cos(t * 0.8) * 2.0; p.y += 0.8 + sin(t * 1.3) * 0.6 + aSeed.y * 1.5;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = clamp(60.0 / -mv.z, 1.0, 3.0);
          vA = step(0.4, sin(uTime * 2.0 + aSeed.y * 30.0) * 0.5 + 0.5);
        }`,
      fragmentShader: `
        uniform float uNight; varying float vA;
        void main(){ gl_FragColor = vec4(0.85, 1.0, 0.45, vA * uNight); }`,
    });
    this.fireflies = new THREE.Points(fg, this.fireflyMat);
    this.fireflies.frustumCulled = false;
    this.group.add(this.fireflies);
  }

  update(t: number, player: THREE.Vector3, night: number, groundAt: (x: number, z: number) => number, day: number) {
    // ducks
    if (this.ducks) {
      this.duckData.forEach((d, i) => {
        const a = t * d.sp + d.ph;
        const x = d.cx + Math.cos(a) * d.r, z = d.cz + Math.sin(a) * d.r;
        this.e.set(0, -a + Math.PI, 0);
        this.q.setFromEuler(this.e);
        this.v.set(x, d.y + Math.sin(t * 2 + i) * 0.03, z);
        this.m.compose(this.v, this.q, this.s);
        this.ducks!.setMatrixAt(i, this.m);
      });
      this.ducks.instanceMatrix.needsUpdate = true;
    }
    // birds circle around the player region in day time
    const vis = day > 0.3;
    this.birds.visible = vis;
    if (vis) {
      for (let i = 0; i < 9; i++) {
        const flock = i < 5 ? 0 : 1;
        const a = t * (0.12 + flock * 0.05) + i * 0.18 + flock * 3;
        const R = 50 + flock * 30 + (i % 3) * 3;
        const cx = Math.floor(player.x / 200) * 200 + 100 * flock, cz = Math.floor(player.z / 200) * 200;
        const x = cx + Math.cos(a) * R, z = cz + Math.sin(a) * R;
        const y = 45 + flock * 12 + Math.sin(t + i) * 2 + (i % 3) * 1.5;
        const flap = Math.sin(t * 9 + i * 1.3);
        this.e.set(0, -a, 0);
        this.q.setFromEuler(this.e);
        this.v.set(x, y + Math.max(0, player.y * 0.5), z);
        this.s.set(1, flap > 0 ? 1 : -0.6, 1);
        this.m.compose(this.v, this.q, this.s);
        this.birds.setMatrixAt(i, this.m);
      }
      this.s.set(1, 1, 1);
      this.birds.instanceMatrix.needsUpdate = true;
    }
    // fireflies follow player region
    this.fireflyMat.uniforms.uNight.value = night;
    this.fireflies.visible = night > 0.3;
    if (this.fireflies.visible && this.ffCenter.distanceTo(player) > 20) {
      this.ffCenter.copy(player);
      const p = this.fireflies.geometry.getAttribute("position") as THREE.BufferAttribute;
      const r = mulberry32(Math.floor(player.x * 13 + player.z * 7));
      for (let i = 0; i < p.count; i++) {
        const x = player.x + (r() - 0.5) * 50, z = player.z + (r() - 0.5) * 50;
        p.setXYZ(i, x, groundAt(x, z), z);
      }
      p.needsUpdate = true;
    }
    for (let i = 0; i < this.mist.length; i++) {
      (this.mist[i].material as THREE.SpriteMaterial).opacity = (0.16 + Math.sin(t * 0.8 + i * 2) * 0.06) * (0.4 + day * 0.6);
    }
  }
}
