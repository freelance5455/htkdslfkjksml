import {
  BOARD_H,
  BOARD_W,
  DEATH_Y,
  PALETTE,
  R,
  SHOOTER_X,
  SHOOTER_Y,
  aimPath,
  cellPos,
  type GameState,
} from "./engine";

function bubble(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  color: number,
  alpha: number,
) {
  const swatch = PALETTE[color] ?? PALETTE[0];
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(x, y + radius * 0.08, radius * 0.92, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(70, 40, 110, 0.16)";
  ctx.fill();

  const grad = ctx.createRadialGradient(
    x - radius * 0.35,
    y - radius * 0.4,
    radius * 0.15,
    x,
    y + radius * 0.1,
    radius,
  );
  grad.addColorStop(0, swatch.light);
  grad.addColorStop(0.42, swatch.core);
  grad.addColorStop(1, swatch.dark);
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.lineWidth = 1.25;
  ctx.strokeStyle = "rgba(50, 24, 80, 0.28)";
  ctx.stroke();

  ctx.beginPath();
  ctx.ellipse(
    x - radius * 0.28,
    y - radius * 0.34,
    radius * 0.28,
    radius * 0.15,
    -0.6,
    0,
    Math.PI * 2,
  );
  ctx.fillStyle = "rgba(255,255,255,0.78)";
  ctx.fill();
  ctx.restore();
}

function drawBubbleGrid(ctx: CanvasRenderingContext2D, state: GameState) {
  const slide = state.dropSlide;
  for (const b of state.bubbles) {
    const p = cellPos(b.row, b.col, state.minRow);
    bubble(ctx, p.x, p.y - slide, R * 0.96, b.color, 1);
  }
}

export function render(ctx: CanvasRenderingContext2D, state: GameState) {
  ctx.clearRect(0, 0, BOARD_W, BOARD_H);
  const sky = ctx.createLinearGradient(0, 0, 0, BOARD_H);
  sky.addColorStop(0, "#f7f4ff");
  sky.addColorStop(0.5, "#e7dcfc");
  sky.addColorStop(1, "#cbb6f2");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, BOARD_W, BOARD_H);

  ctx.save();
  if (!state.reduced && state.shake > 0) {
    const mag = state.shake * state.shake * 8;
    ctx.translate(Math.sin(state.time * 46) * mag, Math.cos(state.time * 39) * mag * 0.65);
  }

  if (state.phase !== "menu") {
    const low = state.bubbles.reduce((max, b) => {
      const y = cellPos(b.row, b.col, state.minRow).y;
      return y > max ? y : max;
    }, 0);
    const danger = low > DEATH_Y - 78;
    ctx.save();
    ctx.setLineDash([7, 7]);
    ctx.lineWidth = 2;
    ctx.strokeStyle = danger ? "rgba(212, 51, 90, 0.9)" : "rgba(90, 62, 140, 0.28)";
    ctx.beginPath();
    ctx.moveTo(14, DEATH_Y);
    ctx.lineTo(BOARD_W - 14, DEATH_Y);
    ctx.stroke();
    ctx.restore();
    if (danger && state.phase === "playing") {
      ctx.font = "800 13px Nunito, ui-rounded, sans-serif";
      ctx.fillStyle = "#d4335a";
      ctx.textAlign = "center";
      ctx.fillText("Watch the line", BOARD_W / 2, DEATH_Y - 8);
    }
  }

  drawBubbleGrid(ctx, state);

  for (const pop of state.popping) {
    const t = 1 - pop.life / pop.max;
    const scale = t < 0.35 ? 1 + t * 0.8 : 1.28 * (1 - (t - 0.35) / 0.65);
    bubble(ctx, pop.x, pop.y, R * 0.96 * Math.max(0.05, scale), pop.color, 1 - t);
  }

  for (const fall of state.falling) {
    bubble(ctx, fall.x, fall.y, R * 0.96, fall.color, Math.max(0, Math.min(1, fall.life)));
  }

  const showAim = state.phase === "playing" && !state.flying;
  if (showAim) {
    const path = aimPath(state);
    const swatch = PALETTE[state.current] ?? PALETTE[0];
    ctx.fillStyle = swatch.core;
    for (let i = 0; i < path.points.length; i++) {
      const p = path.points[i];
      if (!p) continue;
      const fade = 0.9 - (i / path.points.length) * 0.55;
      ctx.globalAlpha = fade;
      ctx.beginPath();
      ctx.arc(p.x, p.y, i % 3 === 0 ? 3.4 : 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    if (path.ghost) {
      const g = cellPos(path.ghost.row, path.ghost.col, state.minRow);
      const losing = g.y > DEATH_Y;
      bubble(ctx, g.x, g.y - state.dropSlide, R * 0.96, state.current, losing ? 0.28 : 0.4);
      if (losing) {
        ctx.beginPath();
        ctx.arc(g.x, g.y - state.dropSlide, R * 0.7, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(212, 51, 90, 0.9)";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }
  }

  if (state.flying) {
    const f = state.flying;
    const ang = Math.atan2(f.vy, f.vx);
    ctx.save();
    ctx.translate(f.x, f.y);
    ctx.rotate(ang);
    ctx.scale(1.08, 0.93);
    bubble(ctx, 0, 0, R * 0.96, f.color, 1);
    ctx.restore();
  }

  ctx.beginPath();
  ctx.ellipse(SHOOTER_X, SHOOTER_Y + R * 0.85, R * 0.7, R * 0.28, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(70, 40, 110, 0.18)";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(SHOOTER_X, SHOOTER_Y, R + 5, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.92)";
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(SHOOTER_X, SHOOTER_Y, R + 5, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(80, 50, 130, 0.35)";
  ctx.lineWidth = 1;
  ctx.stroke();
  if (!state.flying || state.phase === "menu") {
    bubble(ctx, SHOOTER_X, SHOOTER_Y, R * 0.96, state.current, 1);
  } else {
    bubble(ctx, SHOOTER_X, SHOOTER_Y, R * 0.96, state.current, 1);
  }

  for (const bit of state.particles) {
    ctx.globalAlpha = Math.max(0, bit.life / bit.max);
    ctx.fillStyle = bit.color;
    ctx.beginPath();
    ctx.arc(bit.x, bit.y, bit.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  ctx.textAlign = "center";
  ctx.lineJoin = "round";
  for (const text of state.texts) {
    const alpha = Math.max(0, text.life / text.max);
    ctx.globalAlpha = alpha;
    ctx.font = text.text.startsWith("+")
      ? "800 20px Nunito, ui-rounded, sans-serif"
      : "800 18px Nunito, ui-rounded, sans-serif";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(255,255,255,0.92)";
    ctx.strokeText(text.text, text.x, text.y);
    ctx.fillStyle = "#2a2142";
    ctx.fillText(text.text, text.x, text.y);
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}
