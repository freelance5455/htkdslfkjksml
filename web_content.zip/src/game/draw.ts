import type { BallResult, Delivery, Innings, Shot } from "./logic";
import { BALL_SECONDS, CONTACT_AT } from "./logic";

export interface DrawState {
  delivery: Delivery | null;
  innings: Innings;
  target: number;
  /** 0..1+ progress of current ball animation */
  progress: number;
  shot: Shot | null;
  result: BallResult | null;
  shake: number;
  batterName: string;
  bowlerName: string;
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function drawPitch(ctx: CanvasRenderingContext2D, w: number, h: number, s: DrawState) {
  ctx.clearRect(0, 0, w, h);
  const sky = ctx.createLinearGradient(0, 0, 0, h);
  sky.addColorStop(0, "#07111c");
  sky.addColorStop(0.45, "#0c2418");
  sky.addColorStop(1, "#12351f");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, h);

  // stands
  ctx.fillStyle = "#0d1c14";
  ctx.fillRect(0, h * 0.18, w, h * 0.22);
  for (let i = 0; i < 48; i++) {
    const x = ((i * 97) % w);
    const y = h * 0.22 + ((i * 53) % (h * 0.14));
    ctx.fillStyle = i % 3 === 0 ? "#e8b84a" : i % 3 === 1 ? "#f4efe4" : "#2f6b45";
    ctx.globalAlpha = 0.55;
    ctx.fillRect(x, y, 4, 4);
    ctx.globalAlpha = 1;
  }

  // lights
  for (const lx of [w * 0.18, w * 0.82]) {
    const g = ctx.createRadialGradient(lx, h * 0.08, 4, lx, h * 0.2, w * 0.28);
    g.addColorStop(0, "rgba(244,239,228,0.35)");
    g.addColorStop(1, "rgba(244,239,228,0)");
    ctx.fillStyle = g;
    ctx.fillRect(lx - w * 0.28, 0, w * 0.56, h * 0.55);
    ctx.fillStyle = "#d7d2c4";
    ctx.fillRect(lx - 16, h * 0.05, 32, 8);
  }

  const groundY = h * 0.62;
  const grass = ctx.createLinearGradient(0, groundY - 20, 0, h);
  grass.addColorStop(0, "#1f8a40");
  grass.addColorStop(1, "#0e4d24");
  ctx.fillStyle = grass;
  ctx.fillRect(0, groundY - 10, w, h);

  // pitch
  const px = w * 0.18;
  const pw = w * 0.64;
  const py = groundY;
  const ph = h * 0.16;
  ctx.fillStyle = "#c4a36a";
  ctx.beginPath();
  ctx.moveTo(px + pw * 0.08, py);
  ctx.lineTo(px + pw * 0.92, py);
  ctx.lineTo(px + pw, py + ph);
  ctx.lineTo(px, py + ph);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.35)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // crease
  ctx.strokeStyle = "rgba(255,255,255,0.8)";
  ctx.lineWidth = 2;
  const creaseX = px + pw * 0.78;
  ctx.beginPath();
  ctx.moveTo(creaseX, py + 6);
  ctx.lineTo(creaseX, py + ph - 6);
  ctx.stroke();

  drawStumps(ctx, px + pw * 0.16, py + ph * 0.15, h * 0.055, false);
  const bailFly = s.result?.wicket && s.result.how === "بولډ" ? Math.min(1, (s.progress - CONTACT_AT) * 4) : 0;
  drawStumps(ctx, creaseX + 8, py + ph * 0.05, h * 0.09, true, bailFly);

  // fielders
  const spots = [
    [0.3, 0.5],
    [0.55, 0.48],
    [0.42, 0.78],
    [0.7, 0.84],
    [0.12, 0.72],
    [0.88, 0.7],
  ];
  for (const [fx, fy] of spots) {
    drawFielder(ctx, w * fx, h * fy);
  }

  const ballT = s.delivery ? Math.min(Math.max(s.progress, 0), 1) : 0;
  const bowlerX = px + pw * 0.2;
  const batterX = creaseX - w * 0.03;
  const run = Math.min(ballT / 0.28, 1);
  drawBowler(ctx, bowlerX - (1 - run) * w * 0.08, py + ph * 0.35, h);

  const flight = ballT < 0.28 ? 0 : (ballT - 0.28) / 0.72;
  const startX = bowlerX + 10;
  const endX = batterX + 6;
  const bx = startX + (endX - startX) * Math.min(flight, 1);
  const lengthHop =
    s.delivery?.length === "bouncer" ? 0.34 : s.delivery?.length === "short" ? 0.24 : s.delivery?.length === "yorker" ? 0.08 : 0.16;
  const arc = Math.sin(Math.min(flight, 1) * Math.PI) * h * lengthHop;
  const by = py + ph * 0.45 - arc;

  if (s.delivery && flight > 0 && flight < 1.05) {
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.ellipse(bx, py + ph * 0.72, 7, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f4efe4";
    ctx.beginPath();
    ctx.arc(bx, by, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#c0392b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(bx, by, 7, 0.2, 1.4);
    ctx.stroke();
  }

  const swinging = s.shot != null && ballT > CONTACT_AT - 0.08;
  drawBatter(ctx, batterX, py + ph * 0.15, h, swinging, s.shot);

  // timing ring
  if (s.delivery && !s.result && ballT > 0.35 && ballT < CONTACT_AT + 0.08 && !s.shot) {
    const remain = (CONTACT_AT - ballT) / (CONTACT_AT - 0.35);
    const radius = 18 + remain * 46;
    ctx.beginPath();
    ctx.arc(batterX + 18, py + ph * 0.35, radius, 0, Math.PI * 2);
    ctx.strokeStyle = remain < 0.18 ? "#e8b84a" : "rgba(244,239,228,0.85)";
    ctx.lineWidth = 3;
    ctx.stroke();
  }

  if (s.result && s.progress > CONTACT_AT) {
    const label = s.result.wicket ? "اوټ" : s.result.runs === 0 ? "۰" : String(s.result.runs);
    ctx.save();
    ctx.translate((s.shake || 0) * 4, 0);
    ctx.fillStyle = s.result.wicket ? "#e15b4a" : s.result.runs >= 4 ? "#e8b84a" : "#f4efe4";
    ctx.font = `700 ${Math.floor(h * 0.16)}px Oswald, sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(label, w * 0.5, h * 0.28);
    ctx.restore();
  }

  // length hint during flight
  if (s.delivery && ballT > 0.3 && ballT < 0.7 && !s.result) {
    ctx.fillStyle = "rgba(7,20,12,0.72)";
    roundRect(ctx, w * 0.38, h * 0.08, w * 0.24, h * 0.07, 8);
    ctx.fill();
    ctx.fillStyle = "#f4efe4";
    ctx.font = `700 ${Math.floor(h * 0.035)}px "Noto Sans Arabic", sans-serif`;
    ctx.textAlign = "center";
    const hint =
      s.delivery.length === "yorker"
        ? "یارکر"
        : s.delivery.length === "full"
          ? "فل"
          : s.delivery.length === "good"
            ? "ښه اوږدوالی"
            : s.delivery.length === "short"
              ? "لنډ"
              : "بانسر";
    ctx.fillText(hint, w * 0.5, h * 0.125);
  }
}

function drawStumps(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  h: number,
  near: boolean,
  bailFly = 0,
) {
  ctx.strokeStyle = near ? "#f4efe4" : "#d9d3c4";
  ctx.lineWidth = near ? 3 : 2;
  const gap = near ? 7 : 5;
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath();
    ctx.moveTo(x + i * gap, y);
    ctx.lineTo(x + i * gap, y + h);
    ctx.stroke();
  }
  ctx.strokeStyle = "#e8b84a";
  ctx.lineWidth = 2;
  ctx.beginPath();
  const by = y - bailFly * 28;
  const bx = bailFly * 18;
  ctx.moveTo(x - gap + bx, by);
  ctx.lineTo(x + gap + bx, by);
  ctx.stroke();
}

function drawFielder(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.fillStyle = "#163e28";
  ctx.beginPath();
  ctx.arc(x, y - 10, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(x - 4, y - 6, 8, 12);
}

function drawBowler(ctx: CanvasRenderingContext2D, x: number, y: number, h: number) {
  const s = h * 0.012;
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = "#1d4ed8";
  ctx.fillRect(-6 * s, -18 * s, 12 * s, 22 * s);
  ctx.fillStyle = "#f4efe4";
  ctx.beginPath();
  ctx.arc(0, -24 * s, 6 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#1d4ed8";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(4 * s, -12 * s);
  ctx.lineTo(16 * s, -22 * s);
  ctx.stroke();
  ctx.restore();
}

function drawBatter(ctx: CanvasRenderingContext2D, x: number, y: number, h: number, swing: boolean, shot: Shot | null) {
  const s = h * 0.016;
  ctx.save();
  ctx.translate(x, y);
  // pads
  ctx.fillStyle = "#f4efe4";
  ctx.fillRect(-4 * s, 2 * s, 5 * s, 16 * s);
  ctx.fillRect(2 * s, 2 * s, 5 * s, 16 * s);
  // body — gold jersey
  ctx.fillStyle = "#e8b84a";
  ctx.fillRect(-7 * s, -16 * s, 14 * s, 18 * s);
  ctx.fillStyle = "#2a1d05";
  ctx.fillRect(-7 * s, -10 * s, 14 * s, 3 * s);
  // head + helmet
  ctx.fillStyle = "#2a1d05";
  ctx.beginPath();
  ctx.arc(0, -22 * s, 6.5 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#e8b84a";
  ctx.lineWidth = 2;
  ctx.stroke();
  // bat
  ctx.save();
  ctx.translate(8 * s, -4 * s);
  const ang = swing ? (shot === "pull" || shot === "sweep" ? -1.4 : shot === "block" ? -0.3 : -1.05) : -0.45;
  ctx.rotate(ang);
  ctx.fillStyle = "#f3e2b8";
  ctx.fillRect(-2 * s, -18 * s, 4 * s, 22 * s);
  ctx.fillStyle = "#8d5a2b";
  ctx.fillRect(-2.4 * s, 2 * s, 4.8 * s, 8 * s);
  ctx.restore();
  ctx.restore();
}

export function ballProgressSeconds(elapsed: number): number {
  return elapsed / BALL_SECONDS;
}
