import type { Enemy, Sim, Sprites } from "@/game/types";
import { H, W } from "@/game/types";

const INK = "#07080f";
const FG = "#e8eef8";
const MUTED = "#8b93a7";
const CYAN = "#3ee0ff";
const AMBER = "#ffb020";
const THREAT = "#ff3d7a";

function bannerAlpha(remaining: number, total = 1.05) {
  const age = total - remaining;
  return Math.max(0, Math.min(1, age / 0.16, remaining / 0.28));
}

export function draw(ctx: CanvasRenderingContext2D, sim: Sim, sprites: Sprites) {
  const canvas = ctx.canvas;
  const mag = sim.shake;
  const sx = Math.sin(sim.clock * 48) * mag;
  const sy = Math.cos(sim.clock * 57) * mag;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const scaleX = canvas.width / W;
  const scaleY = canvas.height / H;
  ctx.setTransform(scaleX, 0, 0, scaleY, sx * scaleX, sy * scaleY);
  ctx.imageSmoothingEnabled = true;

  ctx.fillStyle = INK;
  ctx.fillRect(-30, -30, W + 60, H + 60);
  wash(ctx, sim.clock);

  for (const star of sim.stars) {
    if (star.layer !== 0) continue;
    ctx.globalAlpha = star.a * 0.55;
    ctx.fillStyle = "#9bb0d0";
    ctx.fillRect(star.x, star.y, star.r, star.r);
  }
  ctx.globalAlpha = 1;
  for (const star of sim.stars) {
    if (star.layer !== 1) continue;
    ctx.globalAlpha = star.a * 0.8;
    ctx.fillStyle = FG;
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  for (const star of sim.stars) {
    if (star.layer !== 2) continue;
    ctx.globalAlpha = star.a;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(star.x, star.y, star.r, star.r * 2.4);
  }
  ctx.globalAlpha = 1;

  for (const p of sim.particles) {
    if (!p.alive) continue;
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  for (const item of sim.pickups) {
    if (!item.alive) continue;
    drawPickup(ctx, sim, sprites, item.kind, item.x, item.y + Math.sin(sim.clock * 4 + item.x) * 3);
  }

  for (const b of sim.bullets) {
    if (!b.alive || b.friendly) continue;
    drawEnemyShot(ctx, b.x, b.y);
  }

  for (const e of sim.enemies) {
    if (!e.alive) continue;
    drawEnemy(ctx, sim, sprites, e);
  }

  for (const b of sim.bullets) {
    if (!b.alive || !b.friendly) continue;
    drawPlayerShot(ctx, b.x, b.y, b.vx, b.vy);
  }

  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const f of sim.flashes) {
    if (!f.alive) continue;
    const k = f.life / f.max;
    const rad = 18 * k;
    const g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, rad);
    g.addColorStop(0, `rgba(255,255,255,${0.95 * k})`);
    g.addColorStop(0.35, `rgba(62,224,255,${0.75 * k})`);
    g.addColorStop(1, "rgba(62,224,255,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(f.x, f.y, rad, 0, Math.PI * 2);
    ctx.fill();
    ctx.save();
    ctx.translate(f.x, f.y);
    ctx.rotate(f.angle);
    ctx.fillStyle = `rgba(255,236,200,${0.85 * k})`;
    ctx.fillRect(-2.2, -16 * k, 4.4, 20 * k);
    ctx.restore();
  }
  ctx.restore();

  if (sim.phase === "title") {
    const bob = Math.sin(sim.clock * 1.5) * 7;
    drawPlayerSprite(ctx, sprites, W / 2, H * 0.78 + bob, Math.sin(sim.clock * 0.8) * 0.08, 1);
  } else if (sim.player.alive && sim.phase !== "over") {
    const p = sim.player;
    const blink = p.iframes > 0 && Math.floor(sim.clock * 16) % 2 === 0;
    if (!blink) {
      const bank = Math.max(-0.4, Math.min(0.4, p.vx / 320));
      drawPlayerSprite(ctx, sprites, p.x, p.y, bank, 1);
    }
    if (p.shield > 0) {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(sim.clock * 2.2);
      ctx.strokeStyle = CYAN;
      ctx.globalAlpha = p.shield < 2 ? 0.45 + Math.sin(sim.clock * 18) * 0.35 : 0.85;
      ctx.lineWidth = 2;
      ctx.setLineDash([7, 5]);
      ctx.beginPath();
      ctx.arc(0, 0, 26, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }
  } else if (!sim.player.alive) {
    drawPlayerSprite(ctx, sprites, sim.player.x, sim.player.y, 0, 0.25);
  }

  for (const f of sim.floats) {
    if (!f.alive) continue;
    ctx.globalAlpha = Math.max(0, f.life / f.max);
    ctx.fillStyle = f.color;
    ctx.font = "700 14px Exo 2, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(f.text, f.x, f.y);
  }
  ctx.globalAlpha = 1;

  if (sim.phase !== "title") drawHud(ctx, sim);

  if (sim.waveState === "banner" && sim.phase === "playing") {
    ctx.globalAlpha = bannerAlpha(sim.waveTimer);
    ctx.fillStyle = FG;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "700 28px Exo 2, sans-serif";
    ctx.fillText(sim.banner, W / 2, H * 0.34);
    ctx.globalAlpha = 1;
  }

  if (sim.phase === "playing" && sim.runTime < 4.2) {
    const a = sim.runTime < 3 ? 0.9 : Math.max(0, 0.9 * (1 - (sim.runTime - 3) / 1.2));
    ctx.globalAlpha = a;
    ctx.fillStyle = FG;
    ctx.font = "600 13px Sora, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("WASD or drag  ·  guns are live", W / 2, H * 0.46);
    ctx.globalAlpha = 1;
  }

  if (sim.hurtFlash > 0) {
    ctx.fillStyle = `rgba(255,61,122,${sim.hurtFlash * 0.28})`;
    ctx.fillRect(-20, -20, W + 40, H + 40);
  }

  if (sim.phase === "paused" || sim.phase === "over") {
    ctx.fillStyle = "rgba(7,8,15,0.5)";
    ctx.fillRect(-20, -20, W + 40, H + 40);
  }
}

function wash(ctx: CanvasRenderingContext2D, t: number) {
  ctx.save();
  ctx.globalAlpha = 0.55;
  const a = ctx.createRadialGradient(W * 0.5, H * 0.15, 20, W * 0.5, H * 0.2, 280);
  a.addColorStop(0, "rgba(62,224,255,0.09)");
  a.addColorStop(1, "rgba(62,224,255,0)");
  ctx.fillStyle = a;
  ctx.fillRect(0, 0, W, H);
  const b = ctx.createRadialGradient(
    W * (0.2 + Math.sin(t * 0.15) * 0.05),
    H * 0.7,
    10,
    W * 0.3,
    H * 0.75,
    220,
  );
  b.addColorStop(0, "rgba(255,176,32,0.06)");
  b.addColorStop(1, "rgba(255,176,32,0)");
  ctx.fillStyle = b;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

function drawPlayerSprite(
  ctx: CanvasRenderingContext2D,
  sprites: Sprites,
  x: number,
  y: number,
  rot: number,
  alpha: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.globalAlpha = alpha;
  const img = sprites.player;
  if (img) {
    ctx.drawImage(img, -40, -40, 80, 80);
  } else {
    drawVectorPlayer(ctx);
  }
  ctx.restore();
}

function drawVectorPlayer(ctx: CanvasRenderingContext2D) {
  const g = ctx.createLinearGradient(0, -30, 0, 28);
  g.addColorStop(0, "#f4fbff");
  g.addColorStop(0.45, CYAN);
  g.addColorStop(1, "#12343f");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(0, -32);
  ctx.lineTo(16, 10);
  ctx.lineTo(7, 6);
  ctx.lineTo(11, 26);
  ctx.lineTo(0, 16);
  ctx.lineTo(-11, 26);
  ctx.lineTo(-7, 6);
  ctx.lineTo(-16, 10);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = AMBER;
  ctx.fillRect(-6, 16, 4, 8);
  ctx.fillRect(2, 16, 4, 8);
}

function enemyRotation(e: Enemy) {
  if (e.kind === "boss") return Math.PI + Math.max(-0.22, Math.min(0.22, e.vx / 500));
  if (e.kind === "gunner" && e.pattern !== "swoop") {
    return Math.PI + Math.max(-0.18, Math.min(0.18, e.vx / 220));
  }
  return Math.atan2(e.vy, e.vx) + Math.PI / 2;
}

function drawEnemy(ctx: CanvasRenderingContext2D, sim: Sim, sprites: Sprites, e: Enemy) {
  const rot = enemyRotation(e);
  ctx.save();
  ctx.translate(e.x, e.y);
  ctx.rotate(rot);
  if (e.flash > 0) ctx.filter = "brightness(2.4)";
  const img = sprites[e.kind];
  if (img) {
    const s = e.r * 3.1;
    ctx.drawImage(img, -s / 2, -s / 2, s, s);
  } else if (e.kind === "dart") drawDart(ctx, e.r);
  else if (e.kind === "weaver") drawWeaver(ctx, e.r);
  else if (e.kind === "gunner") drawGunner(ctx, e.r);
  else drawBoss(ctx, e.r, sim.clock);
  ctx.filter = "none";
  ctx.restore();

  if (e.kind === "gunner" || e.kind === "boss") {
    const bw = e.kind === "boss" ? 92 : 32;
    const y = e.y - e.r - 14;
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    ctx.fillRect(e.x - bw / 2, y, bw, 4);
    ctx.fillStyle = e.kind === "boss" ? AMBER : THREAT;
    ctx.fillRect(e.x - bw / 2, y, bw * Math.max(0, e.hp / e.maxHp), 4);
  }

  if ((e.kind === "gunner" || e.kind === "boss") && e.shoot < 0.32 && e.shoot > 0 && e.y > 20) {
    ctx.save();
    ctx.translate(e.x, e.y + e.r * 0.85);
    ctx.rotate(Math.PI / 4);
    ctx.fillStyle = THREAT;
    ctx.globalAlpha = 0.85;
    ctx.fillRect(-4, -4, 8, 8);
    ctx.restore();
    ctx.globalAlpha = 1;
  }
}

function drawDart(ctx: CanvasRenderingContext2D, r: number) {
  const g = ctx.createLinearGradient(0, -r * 1.5, 0, r);
  g.addColorStop(0, "#ffd0dc");
  g.addColorStop(0.4, THREAT);
  g.addColorStop(1, "#3a0d18");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(0, -r * 1.55);
  ctx.lineTo(r * 0.78, r * 0.95);
  ctx.lineTo(0, r * 0.45);
  ctx.lineTo(-r * 0.78, r * 0.95);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = AMBER;
  ctx.beginPath();
  ctx.arc(0, r * 0.72, r * 0.18, 0, Math.PI * 2);
  ctx.fill();
}

function drawWeaver(ctx: CanvasRenderingContext2D, r: number) {
  ctx.fillStyle = "#0e3d36";
  ctx.beginPath();
  ctx.ellipse(0, 2, r * 1.35, r * 0.62, 0, 0, Math.PI * 2);
  ctx.fill();
  const g = ctx.createLinearGradient(-r, 0, r, 0);
  g.addColorStop(0, "#06352e");
  g.addColorStop(0.5, "#1aa88a");
  g.addColorStop(1, "#06352e");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(-r * 1.45, r * 0.15);
  ctx.quadraticCurveTo(0, -r * 1.35, r * 1.45, r * 0.15);
  ctx.quadraticCurveTo(0, r * 0.15, -r * 1.45, r * 0.15);
  ctx.fill();
  ctx.fillStyle = "#d8fff6";
  ctx.beginPath();
  ctx.arc(0, -r * 0.05, r * 0.28, 0, Math.PI * 2);
  ctx.fill();
}

function drawGunner(ctx: CanvasRenderingContext2D, r: number) {
  ctx.fillStyle = "#243044";
  ctx.beginPath();
  ctx.roundRect(-r * 0.95, -r * 0.85, r * 1.9, r * 1.7, 8);
  ctx.fill();
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#d5e2f2");
  g.addColorStop(0.5, "#7f97b8");
  g.addColorStop(1, "#1c2838");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.roundRect(-r * 0.72, -r * 0.7, r * 1.44, r * 1.45, 6);
  ctx.fill();
  ctx.fillStyle = "#c47a3a";
  ctx.fillRect(-r * 0.12, -r * 1.35, r * 0.24, r * 0.7);
  ctx.fillStyle = AMBER;
  ctx.fillRect(-r * 0.55, r * 0.45, r * 0.28, r * 0.22);
  ctx.fillRect(r * 0.27, r * 0.45, r * 0.28, r * 0.22);
}

function drawBoss(ctx: CanvasRenderingContext2D, r: number, t: number) {
  ctx.fillStyle = "#14110e";
  ctx.beginPath();
  ctx.moveTo(0, -r * 1.15);
  ctx.lineTo(r * 1.35, -r * 0.2);
  ctx.lineTo(r * 1.15, r * 0.85);
  ctx.lineTo(0, r * 0.55);
  ctx.lineTo(-r * 1.15, r * 0.85);
  ctx.lineTo(-r * 1.35, -r * 0.2);
  ctx.closePath();
  ctx.fill();
  const g = ctx.createLinearGradient(0, -r, 0, r);
  g.addColorStop(0, "#4a3b28");
  g.addColorStop(0.4, "#2a241c");
  g.addColorStop(1, "#0e0c0a");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.95);
  ctx.lineTo(r * 1.05, -r * 0.15);
  ctx.lineTo(r * 0.9, r * 0.62);
  ctx.lineTo(0, r * 0.38);
  ctx.lineTo(-r * 0.9, r * 0.62);
  ctx.lineTo(-r * 1.05, -r * 0.15);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = AMBER;
  for (const x of [-r * 0.38, 0, r * 0.38]) ctx.fillRect(x - 3, -r * 1.2, 6, r * 0.38);
  ctx.fillStyle = CYAN;
  ctx.globalAlpha = 0.75 + Math.sin(t * 6) * 0.25;
  ctx.fillRect(-r * 0.45, -r * 0.15, r * 0.9, 3);
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#ff7a1a";
  ctx.fillRect(-r * 0.7, r * 0.48, r * 0.28, r * 0.16);
  ctx.fillRect(r * 0.42, r * 0.48, r * 0.28, r * 0.16);
}

function drawPickup(
  ctx: CanvasRenderingContext2D,
  sim: Sim,
  sprites: Sprites,
  kind: "multi" | "shield" | "speed",
  x: number,
  y: number,
) {
  const img = sprites[kind];
  ctx.save();
  ctx.translate(x, y);
  const pulse = 1 + Math.sin(sim.clock * 5) * 0.06;
  ctx.scale(pulse, pulse);
  if (img && kind !== "speed") {
    ctx.drawImage(img, -16, -16, 32, 32);
  } else if (kind === "multi") {
    ctx.fillStyle = CYAN;
    ctx.beginPath();
    ctx.roundRect(-11, -11, 22, 22, 6);
    ctx.fill();
    ctx.fillStyle = INK;
    ctx.fillRect(-5, -7, 2, 10);
    ctx.fillRect(-1, -7, 2, 10);
    ctx.fillRect(3, -7, 2, 10);
  } else if (kind === "shield") {
    ctx.strokeStyle = CYAN;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(0, -12);
    ctx.lineTo(11, -4);
    ctx.lineTo(8, 10);
    ctx.lineTo(0, 14);
    ctx.lineTo(-8, 10);
    ctx.lineTo(-11, -4);
    ctx.closePath();
    ctx.stroke();
  } else {
    ctx.fillStyle = AMBER;
    ctx.beginPath();
    ctx.moveTo(0, -13);
    ctx.lineTo(11, 2);
    ctx.lineTo(3, 2);
    ctx.lineTo(6, 13);
    ctx.lineTo(-8, 0);
    ctx.lineTo(1, 0);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function drawPlayerShot(ctx: CanvasRenderingContext2D, x: number, y: number, vx: number, vy: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(Math.atan2(vy, vx) + Math.PI / 2);
  const g = ctx.createLinearGradient(0, -12, 0, 8);
  g.addColorStop(0, "#ffffff");
  g.addColorStop(0.4, CYAN);
  g.addColorStop(1, "rgba(62,224,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(-1.6, -12, 3.2, 16);
  ctx.restore();
}

function drawEnemyShot(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.fillStyle = THREAT;
  ctx.beginPath();
  ctx.arc(x, y, 4.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffd0dc";
  ctx.beginPath();
  ctx.arc(x, y, 1.7, 0, Math.PI * 2);
  ctx.fill();
}

function drawHud(ctx: CanvasRenderingContext2D, sim: Sim) {
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillStyle = MUTED;
  ctx.font = "600 11px Exo 2, sans-serif";
  ctx.fillText("SCORE", 16, 16);
  ctx.fillStyle = FG;
  ctx.font = "700 22px Exo 2, sans-serif";
  ctx.fillText(sim.score.toLocaleString("en-US"), 16, 30);

  ctx.fillStyle = MUTED;
  ctx.font = "600 11px Exo 2, sans-serif";
  ctx.fillText("LIVES", 16, 60);
  for (let i = 0; i < sim.lives; i++) {
    ctx.fillStyle = CYAN;
    ctx.beginPath();
    ctx.moveTo(62 + i * 14, 64);
    ctx.lineTo(68 + i * 14, 74);
    ctx.lineTo(56 + i * 14, 74);
    ctx.closePath();
    ctx.fill();
  }

  ctx.textAlign = "center";
  ctx.fillStyle = CYAN;
  ctx.font = "600 13px Exo 2, sans-serif";
  const boss = sim.enemies.find((e) => e.alive && e.kind === "boss");
  ctx.fillText(boss ? "DREADNOUGHT" : `WAVE ${sim.wave}`, W / 2, 16);
  if (boss) {
    const bw = 140;
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    ctx.fillRect(W / 2 - bw / 2, 36, bw, 5);
    ctx.fillStyle = AMBER;
    ctx.fillRect(W / 2 - bw / 2, 36, bw * Math.max(0, boss.hp / boss.maxHp), 5);
  }

  const chips: { label: string; value: number; max: number; color: string }[] = [];
  if (sim.player.multi > 0) chips.push({ label: `SPREAD ${sim.player.multi}`, value: 1, max: 1, color: CYAN });
  if (sim.player.shield > 0) chips.push({ label: "SHIELD", value: sim.player.shield, max: 9, color: CYAN });
  if (sim.player.speedT > 0) chips.push({ label: "BOOST", value: sim.player.speedT, max: 8, color: AMBER });
  if (chips.length) {
    const gap = 8;
    const w = 78;
    const total = chips.length * w + (chips.length - 1) * gap;
    let x = W / 2 - total / 2;
    for (const chip of chips) {
      ctx.fillStyle = "rgba(18,23,34,0.8)";
      ctx.beginPath();
      ctx.roundRect(x, H - 58, w, 28, 8);
      ctx.fill();
      ctx.strokeStyle = chip.color;
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = FG;
      ctx.font = "600 10px Exo 2, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(chip.label, x + w / 2, H - 50);
      if (chip.max > 1) {
        ctx.fillStyle = "rgba(255,255,255,0.15)";
        ctx.fillRect(x + 8, H - 38, w - 16, 3);
        ctx.fillStyle = chip.color;
        ctx.fillRect(x + 8, H - 38, (w - 16) * Math.max(0, Math.min(1, chip.value / chip.max)), 3);
      }
      x += w + gap;
    }
  }
}
