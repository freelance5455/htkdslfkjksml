import * as THREE from 'three';
import {
  PAINT_COLORS,
  type BikeCustomization,
  type BikeModelType,
  type ExhaustType,
  type HandlebarType,
} from './types';

export interface RiderRig {
  root: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftFoot: THREE.Mesh;
  rightFoot: THREE.Mesh;
}

export interface MotoRig {
  root: THREE.Group; // Pivot at rear wheel contact patch (y=0)
  chassisGroup: THREE.Group; // Pitches up around rear axle during wheelie!
  steeringAssembly: THREE.Group; // Front forks + wheel + handlebar + headlight
  frontWheel: THREE.Group;
  rearWheel: THREE.Group;
  swingarm: THREE.Group;
  headlightSpot: THREE.SpotLight;
  headlightBulbMat: THREE.MeshStandardMaterial;
  tailLightMat: THREE.MeshStandardMaterial;
  paintMaterials: THREE.MeshPhysicalMaterial[];
  tireMeshes: THREE.Mesh[];
  exhaustGroups: Record<ExhaustType, THREE.Group>;
  handlebarGroups: Record<HandlebarType, THREE.Group>;
  tailBarGroup: THREE.Group;
  rider: RiderRig;
  applyCustomization: (custom: BikeCustomization) => void;
  updateAnimation: (params: {
    wheelSpinDelta: number;
    steerAngle: number;
    wheelieRad: number;
    speedKmh: number;
    throttle: boolean;
    braking: boolean;
    nightFactor: number;
    timeSec: number;
  }) => void;
}

function createTankDecalTexture(accentHex: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 256, 128);
    ctx.fillStyle = accentHex;
    ctx.beginPath();
    ctx.moveTo(18, 76);
    ctx.lineTo(180, 38);
    ctx.lineTo(242, 56);
    ctx.lineTo(62, 96);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText('CG', 114, 72);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText('160', 148, 88);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createDigitalDashTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 64;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#041226';
    ctx.fillRect(0, 0, 128, 64);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.strokeRect(3, 3, 122, 58);
    ctx.fillStyle = '#7dd3fc';
    ctx.font = 'bold 26px monospace';
    ctx.fillText('160', 14, 34);
    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 14px sans-serif';
    ctx.fillText('WIN', 80, 26);
    ctx.fillStyle = '#22c55e';
    ctx.fillRect(14, 44, 96, 8);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createMercosulPlateTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 96;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, 128, 96);
    ctx.fillStyle = '#1d4ed8';
    ctx.fillRect(0, 0, 128, 22);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('BRASIL', 42, 15);
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 26px monospace';
    ctx.fillText('MOT', 36, 52);
    ctx.fillText('0160', 28, 82);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createRiderJacketTexture(baseHex = '#1c222d'): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = baseHex;
    ctx.fillRect(0, 0, 256, 256);

    // Technical ripstop nylon weave
    for (let i = 0; i < 2000; i++) {
      ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.11)';
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
    }

    // Two-tone racing V-chevron across chest & upper back
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(256, 0);
    ctx.lineTo(256, 76);
    ctx.lineTo(128, 108);
    ctx.lineTo(0, 76);
    ctx.closePath();
    ctx.fill();

    // Crisp gold-amber & white racing piping
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(0, 78);
    ctx.lineTo(128, 110);
    ctx.lineTo(256, 78);
    ctx.stroke();

    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 88);
    ctx.lineTo(128, 120);
    ctx.lineTo(256, 88);
    ctx.stroke();

    // Center metallic zipper seam & pull tab
    ctx.fillStyle = '#475569';
    ctx.fillRect(124, 0, 8, 256);
    ctx.fillStyle = '#e2e8f0';
    for (let y = 8; y < 256; y += 9) {
      ctx.fillRect(126, y, 4, 4);
    }

    // Chest shield crest
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(156, 124, 34, 16);
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('WIN', 162, 136);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createDenimTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#1e324d';
    ctx.fillRect(0, 0, 128, 128);
    for (let y = 0; y < 128; y += 3) {
      ctx.fillStyle = y % 6 === 0 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.09)';
      ctx.fillRect(0, y, 128, 1);
    }
    // Subtle worn knee fade
    const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 52);
    grad.addColorStop(0, 'rgba(148,163,184,0.18)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 128, 128);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createTireGeometry(width: number, radius: number, tube: number): THREE.TorusGeometry {
  void width;
  return new THREE.TorusGeometry(radius, tube, 14, 30);
}

function buildWheel(
  isFront: boolean,
  tireMat: THREE.MeshStandardMaterial,
  rimMat: THREE.MeshStandardMaterial,
  discMat: THREE.MeshStandardMaterial
): THREE.Group {
  const wheel = new THREE.Group();

  const tireRadius = isFront ? 0.255 : 0.245;
  const tireTube = isFront ? 0.055 : 0.068;

  const tire = new THREE.Mesh(createTireGeometry(0.1, tireRadius, tireTube), tireMat);
  tire.rotation.y = Math.PI / 2;
  tire.castShadow = true;
  tire.name = 'tireMesh';
  wheel.add(tire);

  const rim = new THREE.Mesh(new THREE.TorusGeometry(tireRadius - 0.05, 0.018, 10, 24), rimMat);
  rim.rotation.y = Math.PI / 2;
  wheel.add(rim);

  // 5-spoke Y alloy wheel (Titan/Fan 160 style)
  for (let i = 0; i < 5; i++) {
    const angle = (i / 5) * Math.PI * 2;
    const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.022, tireRadius - 0.04, 0.024), rimMat);
    spoke.position.set(0, Math.cos(angle) * (tireRadius * 0.44), Math.sin(angle) * (tireRadius * 0.44));
    spoke.rotation.x = angle;
    wheel.add(spoke);
  }

  // Hub
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.052, 0.11, 14), rimMat);
  hub.rotation.z = Math.PI / 2;
  wheel.add(hub);

  // Brake disc (front) or rear sprocket
  const disc = new THREE.Mesh(
    new THREE.CylinderGeometry(isFront ? 0.125 : 0.115, isFront ? 0.125 : 0.115, 0.014, 20),
    discMat
  );
  disc.rotation.z = Math.PI / 2;
  disc.position.x = isFront ? 0.062 : -0.068;
  wheel.add(disc);

  return wheel;
}

function buildDetailedHelmet(helmetColor: number): THREE.Group {
  const head = new THREE.Group();

  const skinMat = new THREE.MeshStandardMaterial({ color: 0xc68b63, roughness: 0.65 });
  const helmetMat = new THREE.MeshPhysicalMaterial({
    color: helmetColor,
    roughness: 0.12,
    metalness: 0.48,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
  });
  const trimMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.55, metalness: 0.3 });
  const accentMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.3, metalness: 0.4 });
  const visorMat = new THREE.MeshPhysicalMaterial({
    color: 0x22d3ee,
    emissive: 0x0c4a6e,
    emissiveIntensity: 0.38,
    roughness: 0.04,
    metalness: 0.92,
    clearcoat: 1.0,
    clearcoatRoughness: 0.03,
  });

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.064, 0.1, 10), skinMat);
  neck.position.set(0, 0.02, 0);
  head.add(neck);

  // Main aerodynamic race helmet shell
  const helmetShell = new THREE.Mesh(new THREE.SphereGeometry(0.152, 22, 18), helmetMat);
  helmetShell.position.set(0, 0.145, -0.005);
  helmetShell.scale.set(0.95, 1.04, 1.18);
  helmetShell.castShadow = true;
  head.add(helmetShell);

  // Aggressive dual-wing rear aero spoiler
  const spoiler = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.04, 0.14), trimMat);
  spoiler.position.set(0, 0.215, 0.13);
  spoiler.rotation.x = -0.32;
  head.add(spoiler);

  const spoilerEdge = new THREE.Mesh(new THREE.BoxGeometry(0.185, 0.014, 0.035), accentMat);
  spoilerEdge.position.set(0, 0.232, 0.185);
  spoilerEdge.rotation.x = -0.32;
  head.add(spoilerEdge);

  // Twin brow air intakes
  for (const side of [-1, 1]) {
    const browVent = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.022, 0.1), trimMat);
    browVent.position.set(side * 0.052, 0.285, -0.02);
    head.add(browVent);
  }

  const chinGuard = new THREE.Mesh(new THREE.BoxGeometry(0.188, 0.094, 0.135), helmetMat);
  chinGuard.position.set(0, 0.075, -0.108);
  head.add(chinGuard);

  const chinVent = new THREE.Mesh(new THREE.BoxGeometry(0.088, 0.038, 0.032), trimMat);
  chinVent.position.set(0, 0.078, -0.17);
  head.add(chinVent);

  // Racing stripe along helmet crown
  const crownStripe = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.018, 0.25), accentMat);
  crownStripe.position.set(0, 0.292, 0.02);
  head.add(crownStripe);

  // Curved reflective iridium visor + rubber seal
  const visor = new THREE.Mesh(
    new THREE.CylinderGeometry(0.148, 0.148, 0.092, 18, 1, true, -0.98, 1.96),
    visorMat
  );
  visor.position.set(0, 0.152, -0.038);
  visor.rotation.y = Math.PI;
  head.add(visor);

  const visorSeal = new THREE.Mesh(new THREE.BoxGeometry(0.215, 0.016, 0.085), trimMat);
  visorSeal.position.set(0, 0.20, -0.128);
  head.add(visorSeal);

  return head;
}

function buildStylishStreetHead(): THREE.Group {
  const head = new THREE.Group();
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xc68b63, roughness: 0.62 });
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x111318, roughness: 0.85 });
  const frameMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.85, roughness: 0.2 });
  const lensMat = new THREE.MeshPhysicalMaterial({
    color: 0x38bdf8,
    emissive: 0x0c4a6e,
    emissiveIntensity: 0.32,
    roughness: 0.05,
    metalness: 0.9,
    clearcoat: 1.0,
  });

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.062, 0.1, 10), skinMat);
  neck.position.set(0, 0.02, 0);
  head.add(neck);

  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.122, 18, 16), skinMat);
  skull.position.set(0, 0.15, 0);
  skull.scale.set(0.95, 1.06, 1.02);
  skull.castShadow = true;
  head.add(skull);

  // Tapered fade haircut crown
  const hairTop = new THREE.Mesh(new THREE.BoxGeometry(0.195, 0.085, 0.21), hairMat);
  hairTop.position.set(0, 0.255, 0.005);
  hairTop.rotation.x = -0.08;
  head.add(hairTop);

  const hairBack = new THREE.Mesh(
    new THREE.SphereGeometry(0.125, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.56),
    hairMat
  );
  hairBack.position.set(0, 0.175, 0.015);
  hairBack.rotation.x = -0.35;
  head.add(hairBack);

  // Mirrored Juliet-style sport sunglasses
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.018, 0.03), frameMat);
  bridge.position.set(0, 0.17, -0.124);
  head.add(bridge);

  for (const side of [-1, 1]) {
    const lens = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.036, 0.02), lensMat);
    lens.position.set(side * 0.048, 0.165, -0.126);
    lens.rotation.y = side * -0.18;
    head.add(lens);

    const temple = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.014, 0.15), frameMat);
    temple.position.set(side * 0.095, 0.17, -0.05);
    head.add(temple);
  }

  return head;
}

function buildRealisticRider(jacketHex = '#1c222d', helmetColor = 0xdc2626): RiderRig {
  const root = new THREE.Group();

  const jacketTex = createRiderJacketTexture(jacketHex);
  const denimTex = createDenimTexture();

  const jacketMat = new THREE.MeshStandardMaterial({ map: jacketTex, roughness: 0.68, metalness: 0.1 });
  const armorMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.5, metalness: 0.35 });
  const jeansMat = new THREE.MeshStandardMaterial({ map: denimTex, roughness: 0.85 });
  const sneakerMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.55 });
  const sneakerTrimMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
  const gloveMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7 });
  const packMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.78 });

  // Pelvis seated on bike saddle
  const pelvis = new THREE.Mesh(new THREE.CapsuleGeometry(0.115, 0.12, 6, 12), jeansMat);
  pelvis.rotation.z = Math.PI / 2;
  pelvis.castShadow = true;
  root.add(pelvis);

  // Torso group pivoted at hip
  const torso = new THREE.Group();
  torso.position.set(0, 0.05, 0);
  root.add(torso);

  const chest = new THREE.Mesh(new THREE.CapsuleGeometry(0.152, 0.32, 8, 14), jacketMat);
  chest.position.set(0, 0.25, 0);
  chest.scale.set(1.12, 1, 0.8);
  chest.castShadow = true;
  torso.add(chest);

  // Collar + Shoulder armor pads
  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.095, 0.06, 12), armorMat);
  collar.position.set(0, 0.47, 0);
  torso.add(collar);

  for (const side of [-1, 1]) {
    const shoulderPad = new THREE.Mesh(new THREE.SphereGeometry(0.072, 10, 10), armorMat);
    shoulderPad.scale.set(1.1, 0.85, 1.05);
    shoulderPad.position.set(side * 0.19, 0.43, 0);
    torso.add(shoulderPad);
  }

  // Street rider backpack
  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.3, 0.11), packMat);
  backpack.position.set(0, 0.27, 0.14);
  backpack.castShadow = true;
  torso.add(backpack);

  const packStrap = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.028, 0.12), new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 }));
  packStrap.position.set(0, 0.34, 0.145);
  torso.add(packStrap);

  // Detailed Full-Face Helmet
  const head = buildDetailedHelmet(helmetColor);
  head.position.set(0, 0.52, -0.02);
  torso.add(head);

  // Articulated Arms (shoulder -> elbow guard -> forearm -> armored glove)
  const makeArm = (side: -1 | 1): THREE.Group => {
    const arm = new THREE.Group();
    arm.position.set(side * 0.195, 0.42, 0);

    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.052, 0.22, 6, 10), jacketMat);
    upper.position.set(0, -0.12, -0.08);
    upper.rotation.x = 0.65;
    upper.castShadow = true;
    arm.add(upper);

    const elbowPad = new THREE.Mesh(new THREE.SphereGeometry(0.056, 8, 8), armorMat);
    elbowPad.position.set(0, -0.22, -0.15);
    arm.add(elbowPad);

    const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.22, 6, 10), jacketMat);
    forearm.position.set(0, -0.20, -0.27);
    forearm.rotation.x = 1.25;
    forearm.castShadow = true;
    arm.add(forearm);

    const glove = new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.06, 0.09), gloveMat);
    glove.position.set(0, -0.22, -0.40);
    arm.add(glove);

    const knuckle = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.02, 0.03), armorMat);
    knuckle.position.set(0, -0.19, -0.41);
    arm.add(knuckle);

    return arm;
  };

  const leftArm = makeArm(-1);
  const rightArm = makeArm(1);
  torso.add(leftArm, rightArm);

  // Articulated Legs with knee guards & two-tone sneakers
  const makeLeg = (side: -1 | 1): { leg: THREE.Group; foot: THREE.Mesh } => {
    const leg = new THREE.Group();
    leg.position.set(side * 0.115, 0.02, -0.02);

    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.28, 6, 10), jeansMat);
    thigh.position.set(side * 0.04, -0.10, -0.14);
    thigh.rotation.x = 1.05;
    thigh.rotation.z = side * -0.12;
    thigh.castShadow = true;
    leg.add(thigh);

    const kneePad = new THREE.Mesh(new THREE.SphereGeometry(0.066, 8, 8), armorMat);
    kneePad.position.set(side * 0.055, -0.19, -0.25);
    leg.add(kneePad);

    const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.054, 0.30, 6, 10), jeansMat);
    shin.position.set(side * 0.06, -0.33, -0.18);
    shin.rotation.x = -0.22;
    shin.castShadow = true;
    leg.add(shin);

    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.068, 0.20), sneakerMat);
    foot.position.set(side * 0.06, -0.49, -0.14);
    foot.castShadow = true;

    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.096, 0.024, 0.21), sneakerTrimMat);
    sole.position.set(0, -0.034, 0);
    foot.add(sole);

    const stripeShoe = new THREE.Mesh(new THREE.BoxGeometry(0.094, 0.018, 0.11), sneakerTrimMat);
    stripeShoe.position.set(0, 0.005, -0.02);
    foot.add(stripeShoe);

    leg.add(foot);
    return { leg, foot };
  };

  const left = makeLeg(-1);
  const right = makeLeg(1);
  root.add(left.leg, right.leg);

  return {
    root,
    torso,
    head,
    leftArm,
    rightArm,
    leftLeg: left.leg,
    rightLeg: right.leg,
    leftFoot: left.foot,
    rightFoot: right.foot,
  };
}

export interface OnFootPlayerRig {
  group: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  updateWalkAnimation: (speedMs: number, elapsedSec: number, isFirstPerson: boolean) => void;
}

export function createOnFootPlayer(jacketHex = '#1c222d', helmetColor = 0xdc2626): OnFootPlayerRig {
  const group = new THREE.Group();

  const jacketTex = createRiderJacketTexture(jacketHex);
  const denimTex = createDenimTexture();

  const jacketMat = new THREE.MeshStandardMaterial({ map: jacketTex, roughness: 0.68, metalness: 0.1 });
  const armorMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.5, metalness: 0.35 });
  const jeansMat = new THREE.MeshStandardMaterial({ map: denimTex, roughness: 0.85 });
  const sneakerMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.55 });
  const sneakerTrimMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
  const gloveMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7 });
  const packMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.78 });

  // Pelvis
  const pelvis = new THREE.Mesh(new THREE.CapsuleGeometry(0.115, 0.12, 6, 10), jeansMat);
  pelvis.position.set(0, 0.9, 0);
  pelvis.rotation.z = Math.PI / 2;
  pelvis.castShadow = true;
  group.add(pelvis);

  // Torso
  const torso = new THREE.Group();
  torso.position.set(0, 0.94, 0);
  group.add(torso);

  const chest = new THREE.Mesh(new THREE.CapsuleGeometry(0.152, 0.32, 6, 12), jacketMat);
  chest.position.set(0, 0.25, 0);
  chest.scale.set(1.12, 1, 0.8);
  chest.castShadow = true;
  torso.add(chest);

  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.3, 0.11), packMat);
  backpack.position.set(0, 0.27, 0.14);
  backpack.castShadow = true;
  torso.add(backpack);

  for (const side of [-1, 1]) {
    const shoulderPad = new THREE.Mesh(new THREE.SphereGeometry(0.072, 8, 8), armorMat);
    shoulderPad.position.set(side * 0.19, 0.43, 0);
    torso.add(shoulderPad);
  }

  // Head + Cool Street Hair & Mirrored Sunglasses when walking on foot
  void helmetColor;
  const head = buildStylishStreetHead();
  head.position.set(0, 0.52, -0.01);
  torso.add(head);

  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.095, 0.058, 12), armorMat);
  collar.position.set(0, 0.47, 0);
  torso.add(collar);

  const hoodFold = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.08, 0.12), jacketMat);
  hoodFold.position.set(0, 0.45, 0.09);
  hoodFold.rotation.x = 0.25;
  torso.add(hoodFold);

  // Hanging arms
  const makeWalkArm = (side: -1 | 1): THREE.Group => {
    const arm = new THREE.Group();
    arm.position.set(side * 0.2, 0.42, 0);
    const limb = new THREE.Mesh(new THREE.CapsuleGeometry(0.048, 0.4, 5, 8), jacketMat);
    limb.position.set(0, -0.23, 0);
    limb.castShadow = true;
    arm.add(limb);

    const elbowPad = new THREE.Mesh(new THREE.SphereGeometry(0.052, 8, 8), armorMat);
    elbowPad.position.set(0, -0.22, 0.01);
    arm.add(elbowPad);

    const glove = new THREE.Mesh(new THREE.BoxGeometry(0.068, 0.06, 0.08), gloveMat);
    glove.position.set(0, -0.47, 0);
    arm.add(glove);
    return arm;
  };

  const leftArm = makeWalkArm(-1);
  const rightArm = makeWalkArm(1);
  torso.add(leftArm, rightArm);

  // Standing legs with knee pad & two-tone sneakers
  const makeWalkLeg = (side: -1 | 1): THREE.Group => {
    const leg = new THREE.Group();
    leg.position.set(side * 0.1, 0.88, 0);

    const thighShin = new THREE.Mesh(new THREE.CapsuleGeometry(0.064, 0.62, 5, 8), jeansMat);
    thighShin.position.set(0, -0.39, 0);
    thighShin.castShadow = true;
    leg.add(thighShin);

    const kneePad = new THREE.Mesh(new THREE.SphereGeometry(0.062, 8, 8), armorMat);
    kneePad.position.set(0, -0.39, -0.03);
    leg.add(kneePad);

    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.068, 0.2), sneakerMat);
    foot.position.set(0, -0.82, -0.04);
    foot.castShadow = true;
    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.096, 0.024, 0.21), sneakerTrimMat);
    sole.position.set(0, -0.034, 0);
    foot.add(sole);
    leg.add(foot);

    return leg;
  };

  const leftLeg = makeWalkLeg(-1);
  const rightLeg = makeWalkLeg(1);
  group.add(leftLeg, rightLeg);

  const updateWalkAnimation = (speedMs: number, elapsedSec: number, isFirstPerson: boolean) => {
    head.visible = !isFirstPerson;
    const absSpeed = Math.abs(speedMs);
    if (absSpeed > 0.2) {
      const swing = Math.sin(elapsedSec * 9.5) * Math.min(0.65, absSpeed * 0.16);
      leftLeg.rotation.x = swing;
      rightLeg.rotation.x = -swing;
      leftArm.rotation.x = -swing * 0.8;
      rightArm.rotation.x = swing * 0.8;
      torso.position.y = 0.94 + Math.abs(Math.cos(elapsedSec * 9.5)) * 0.035;
    } else {
      leftLeg.rotation.x *= 0.8;
      rightLeg.rotation.x *= 0.8;
      leftArm.rotation.x *= 0.8;
      rightArm.rotation.x *= 0.8;
      torso.position.y = 0.94 + Math.sin(elapsedSec * 2.2) * 0.008;
    }
  };

  return {
    group,
    head,
    torso,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    updateWalkAnimation,
  };
}

export function createMoto160(
  initialCustom: BikeCustomization,
  options?: { isPolice?: boolean; isRacer?: boolean; isRemote?: boolean }
): MotoRig {
  const root = new THREE.Group();
  const chassisGroup = new THREE.Group();
  // Rear axle pivot sits at y = 0.31, z = +0.63 (forward is -Z)
  chassisGroup.position.set(0, 0.31, 0.63);
  root.add(chassisGroup);

  const initialColor = options?.isPolice
    ? { hex: '#14171c', accentHex: '#f8fafc' }
    : options?.isRacer
      ? { hex: '#0284c7', accentHex: '#facc15' }
      : PAINT_COLORS.find((c) => c.id === initialCustom.colorId) ?? PAINT_COLORS[0];

  const paintMat = new THREE.MeshPhysicalMaterial({
    color: initialColor.hex,
    metalness: 0.48,
    roughness: 0.18,
    clearcoat: 1.0,
    clearcoatRoughness: 0.06,
  });

  const frameMat = new THREE.MeshStandardMaterial({ color: 0x16181d, roughness: 0.55, metalness: 0.7 });
  const engineMat = new THREE.MeshStandardMaterial({ color: 0x7c8490, roughness: 0.35, metalness: 0.85 });
  const chromeMat = new THREE.MeshStandardMaterial({ color: 0xdbe2ea, roughness: 0.14, metalness: 0.95 });
  const rimMat = new THREE.MeshStandardMaterial({ color: 0x22262e, roughness: 0.32, metalness: 0.8 });
  const discMat = new THREE.MeshStandardMaterial({ color: 0xb6bec8, roughness: 0.25, metalness: 0.9 });
  const tireMat = new THREE.MeshStandardMaterial({ color: 0x141518, roughness: 0.88, metalness: 0.05 });
  const seatMat = new THREE.MeshStandardMaterial({ color: 0x18191e, roughness: 0.85, metalness: 0.05 });
  const blinkerMat = new THREE.MeshStandardMaterial({
    color: 0xf97316,
    emissive: 0xea580c,
    emissiveIntensity: 0.35,
    roughness: 0.25,
  });

  // Rear swingarm & rear wheel
  const swingarm = new THREE.Group();
  chassisGroup.add(swingarm);

  const swingLeft = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.05, 0.48), frameMat);
  swingLeft.position.set(-0.095, 0.02, -0.22);
  swingarm.add(swingLeft);
  const swingRight = swingLeft.clone();
  swingRight.position.x = 0.095;
  swingarm.add(swingRight);

  // Chain & chain guard on left side
  const chainStrip = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.024, 0.52), frameMat);
  chainStrip.position.set(-0.075, 0.035, -0.24);
  swingarm.add(chainStrip);

  const rearWheel = buildWheel(false, tireMat, rimMat, discMat);
  swingarm.add(rearWheel);

  // Rear shock absorber springs (twin shock CG 160 style)
  for (const side of [-1, 1]) {
    const shock = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.33, 10), chromeMat);
    shock.position.set(side * 0.105, 0.19, -0.05);
    shock.rotation.x = 0.26;
    chassisGroup.add(shock);
  }

  // Footpegs & Brake/Shift Pedals
  for (const side of [-1, 1]) {
    const peg = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.11, 8), frameMat);
    peg.rotation.z = Math.PI / 2;
    peg.position.set(side * 0.18, -0.02, -0.44);
    chassisGroup.add(peg);
  }

  // Main tubular chassis & detailed 160cc OHC engine block with cooling fins
  const engineBlock = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.24, 0.30), engineMat);
  engineBlock.position.set(0, 0.08, -0.58);
  engineBlock.castShadow = true;
  chassisGroup.add(engineBlock);

  const clutchCover = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.27, 14), chromeMat);
  clutchCover.rotation.z = Math.PI / 2;
  clutchCover.position.set(0, 0.06, -0.56);
  chassisGroup.add(clutchCover);

  const cylinderHead = new THREE.Mesh(new THREE.CylinderGeometry(0.082, 0.088, 0.22, 12), engineMat);
  cylinderHead.position.set(0, 0.25, -0.64);
  cylinderHead.rotation.x = 0.28;
  cylinderHead.castShadow = true;
  chassisGroup.add(cylinderHead);

  // Cylinder cooling fins
  for (let f = 0; f < 4; f++) {
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.012, 0.19), engineMat);
    fin.position.set(0, 0.19 + f * 0.036, -0.63 - f * 0.01);
    fin.rotation.x = 0.28;
    chassisGroup.add(fin);
  }

  // Skid plate (for Bros 160 trail look)
  const skidPlate = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.04, 0.34), chromeMat);
  skidPlate.position.set(0, -0.05, -0.64);
  skidPlate.rotation.x = -0.25;
  chassisGroup.add(skidPlate);

  // Frame backbone
  const backbone = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.88, 8), frameMat);
  backbone.position.set(0, 0.35, -0.62);
  backbone.rotation.x = Math.PI / 2 - 0.18;
  chassisGroup.add(backbone);

  // Side covers (tampas laterais 160)
  const sideCover = new THREE.Mesh(new THREE.BoxGeometry(0.23, 0.16, 0.34), paintMat);
  sideCover.position.set(0, 0.30, -0.44);
  sideCover.castShadow = true;
  chassisGroup.add(sideCover);

  // Sculpted Fuel Tank (CG 160 Titan/Fan/Bros profile)
  const tankGroup = new THREE.Group();
  tankGroup.position.set(0, 0.45, -0.76);
  chassisGroup.add(tankGroup);

  const tankBody = new THREE.Mesh(new THREE.CapsuleGeometry(0.132, 0.28, 8, 16), paintMat);
  tankBody.rotation.x = Math.PI / 2 + 0.1;
  tankBody.scale.set(1.12, 1, 0.88);
  tankBody.castShadow = true;
  tankGroup.add(tankBody);

  // Titan/Bros wing shrouds (toggled by bikeModel)
  const titanShroudsGroup = new THREE.Group();
  for (const side of [-1, 1]) {
    const shroud = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.145, 0.27), paintMat);
    shroud.position.set(side * 0.142, -0.02, -0.08);
    shroud.rotation.y = side * 0.18;
    shroud.rotation.x = 0.2;
    shroud.castShadow = true;
    titanShroudsGroup.add(shroud);
  }
  tankGroup.add(titanShroudsGroup);

  // Tank cap
  const tankCap = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.036, 0.02, 12), chromeMat);
  tankCap.position.set(0, 0.115, -0.04);
  tankGroup.add(tankCap);

  // Decal planes
  const decalTex = createTankDecalTexture(initialColor.accentHex);
  const decalMat = new THREE.MeshBasicMaterial({
    map: decalTex,
    transparent: true,
    polygonOffset: true,
    polygonOffsetFactor: -1,
  });
  for (const side of [-1, 1]) {
    const decal = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.12), decalMat);
    decal.position.set(side * 0.165, 0.01, -0.03);
    decal.rotation.y = side > 0 ? Math.PI / 2 : -Math.PI / 2;
    tankGroup.add(decal);
  }

  // Ribbed Seat
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.09, 0.56), seatMat);
  seat.position.set(0, 0.41, -0.34);
  seat.rotation.x = -0.06;
  seat.castShadow = true;
  chassisGroup.add(seat);

  // Rear Tail Fairing (Rabeta) & Taillight & Mercosul Plate + Blinkers
  const tailFairing = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.09, 0.28), paintMat);
  tailFairing.position.set(0, 0.40, 0.02);
  tailFairing.rotation.x = -0.18;
  tailFairing.castShadow = true;
  chassisGroup.add(tailFairing);

  const tailLightMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    emissive: 0x7f1d1d,
    emissiveIntensity: 0.7,
    roughness: 0.25,
  });
  const tailLight = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.055, 0.04), tailLightMat);
  tailLight.position.set(0, 0.39, 0.155);
  chassisGroup.add(tailLight);

  const rearFender = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.02, 0.26), frameMat);
  rearFender.position.set(0, 0.29, 0.17);
  rearFender.rotation.x = -0.68;
  chassisGroup.add(rearFender);

  // Mercosul Brazilian Plate
  const plateTex = createMercosulPlateTexture();
  const plateMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.14, 0.105, 0.012),
    new THREE.MeshBasicMaterial({ map: plateTex })
  );
  plateMesh.position.set(0, 0.26, 0.22);
  plateMesh.rotation.x = -0.42;
  chassisGroup.add(plateMesh);

  for (const side of [-1, 1]) {
    const rearBlinker = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.026, 0.03), blinkerMat);
    rearBlinker.position.set(side * 0.105, 0.34, 0.155);
    chassisGroup.add(rearBlinker);
  }

  // Alça de Grau (Grab Bar)
  const tailBarGroup = new THREE.Group();
  tailBarGroup.position.set(0, 0.44, 0.08);
  const barLoop = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.016, 8, 18, Math.PI), chromeMat);
  barLoop.rotation.x = Math.PI / 2;
  barLoop.rotation.z = Math.PI;
  tailBarGroup.add(barLoop);
  chassisGroup.add(tailBarGroup);

  // Exhaust variants
  const makeExhaust = (kind: ExhaustType): THREE.Group => {
    const g = new THREE.Group();
    const headerCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.05, 0.20, -0.74),
      new THREE.Vector3(0.14, 0.04, -0.66),
      new THREE.Vector3(0.15, -0.06, -0.35),
      new THREE.Vector3(0.16, 0.03, -0.05),
    ]);
    const headerMesh = new THREE.Mesh(
      new THREE.TubeGeometry(headerCurve, 18, kind === 'direto' ? 0.022 : 0.019, 8, false),
      kind === 'dore' || kind === 'direto' ? chromeMat : frameMat
    );
    g.add(headerMesh);

    if (kind === 'original') {
      const muffler = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.044, 0.42, 12), frameMat);
      muffler.rotation.x = Math.PI / 2 - 0.18;
      muffler.position.set(0.165, 0.08, 0.11);
      g.add(muffler);
      const shield = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.065, 0.28), chromeMat);
      shield.position.set(0.205, 0.08, 0.10);
      shield.rotation.x = -0.18;
      g.add(shield);
    } else if (kind === 'dore') {
      const can = new THREE.Mesh(new THREE.CylinderGeometry(0.046, 0.038, 0.36, 14), chromeMat);
      can.rotation.x = Math.PI / 2 - 0.26;
      can.position.set(0.165, 0.10, 0.10);
      g.add(can);
    } else if (kind === 'trioval') {
      const can = new THREE.Mesh(
        new THREE.CylinderGeometry(0.055, 0.048, 0.38, 6),
        new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.85, roughness: 0.28 })
      );
      can.rotation.x = Math.PI / 2 - 0.24;
      can.position.set(0.165, 0.10, 0.11);
      g.add(can);
    } else {
      const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.024, 0.24, 12), chromeMat);
      tip.rotation.x = Math.PI / 2 - 0.15;
      tip.position.set(0.16, 0.04, 0.06);
      g.add(tip);
    }
    return g;
  };

  const exhaustGroups: Record<ExhaustType, THREE.Group> = {
    original: makeExhaust('original'),
    dore: makeExhaust('dore'),
    trioval: makeExhaust('trioval'),
    direto: makeExhaust('direto'),
  };
  Object.values(exhaustGroups).forEach((eg) => chassisGroup.add(eg));

  // Front Steering Assembly
  const steeringAssembly = new THREE.Group();
  steeringAssembly.position.set(0, 0.49, -0.98);
  chassisGroup.add(steeringAssembly);

  const forkRakeGroup = new THREE.Group();
  forkRakeGroup.rotation.x = -0.34;
  steeringAssembly.add(forkRakeGroup);

  for (const side of [-1, 1]) {
    const upperFork = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.42, 10), chromeMat);
    upperFork.position.set(side * 0.095, -0.14, 0);
    forkRakeGroup.add(upperFork);

    const lowerFork = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.024, 0.32, 10), frameMat);
    lowerFork.position.set(side * 0.095, -0.38, 0);
    forkRakeGroup.add(lowerFork);
  }

  // Triple clamp + front caliper
  const tripleClamp = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.03, 0.07), frameMat);
  tripleClamp.position.set(0, 0.06, 0);
  forkRakeGroup.add(tripleClamp);

  // Low Front Mudguard (Titan / Fan)
  const frontFender = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.28, 0.12, 14, 1, true, -0.9, 1.8),
    paintMat
  );
  frontFender.rotation.z = Math.PI / 2;
  frontFender.rotation.y = Math.PI / 2;
  frontFender.position.set(0, -0.45, -0.02);
  forkRakeGroup.add(frontFender);

  // High Trail Mudguard (Bros 160)
  const highFrontFender = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.032, 0.38), paintMat);
  highFrontFender.position.set(0, -0.08, -0.17);
  highFrontFender.rotation.x = 0.14;
  forkRakeGroup.add(highFrontFender);

  // Front wheel
  const frontWheel = buildWheel(true, tireMat, rimMat, discMat);
  frontWheel.position.set(0, -0.52, 0);
  forkRakeGroup.add(frontWheel);

  // Headlight variants: Angular Cowl (Titan/Bros) vs Classic Round (CG Fan/Start Montadinha)
  const headlightCowl = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.19, 0.15), paintMat);
  headlightCowl.position.set(0, 0.02, -0.11);
  headlightCowl.castShadow = true;
  steeringAssembly.add(headlightCowl);

  const roundHeadlightBucket = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.085, 0.13, 16), chromeMat);
  roundHeadlightBucket.rotation.x = Math.PI / 2;
  roundHeadlightBucket.position.set(0, 0.02, -0.11);
  steeringAssembly.add(roundHeadlightBucket);

  const headlightBulbMat = new THREE.MeshStandardMaterial({
    color: 0xfffbeb,
    emissive: 0xfef08a,
    emissiveIntensity: 0.65,
    roughness: 0.1,
  });
  const headlightLens = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.11), headlightBulbMat);
  headlightLens.position.set(0, 0.01, -0.188);
  headlightLens.rotation.y = Math.PI;
  steeringAssembly.add(headlightLens);

  for (const side of [-1, 1]) {
    const frontBlinker = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.026, 0.03), blinkerMat);
    frontBlinker.position.set(side * 0.14, 0.03, -0.10);
    steeringAssembly.add(frontBlinker);
  }

  // Glowing Digital Speedometer Pod
  const dashPod = new THREE.Mesh(new THREE.BoxGeometry(0.145, 0.042, 0.085), frameMat);
  dashPod.position.set(0, 0.13, -0.08);
  dashPod.rotation.x = 0.52;
  steeringAssembly.add(dashPod);

  const dashTex = createDigitalDashTexture();
  const dashScreen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.12, 0.06),
    new THREE.MeshBasicMaterial({ map: dashTex })
  );
  dashScreen.position.set(0, 0.152, -0.08);
  dashScreen.rotation.x = -Math.PI / 2 + 0.52;
  steeringAssembly.add(dashScreen);

  // Headlight SpotLight
  const headlightSpot = new THREE.SpotLight(0xfff6d6, 0, 55, Math.PI / 5, 0.55, 1.3);
  headlightSpot.position.set(0, 0.02, -0.2);
  const headlightTarget = new THREE.Object3D();
  headlightTarget.position.set(0, -0.8, -14);
  steeringAssembly.add(headlightTarget);
  headlightSpot.target = headlightTarget;
  steeringAssembly.add(headlightSpot);

  // Police lightbar if police bike
  if (options?.isPolice) {
    const sirenRed = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.05, 0.06),
      new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 1.5 })
    );
    sirenRed.position.set(-0.06, 0.16, -0.11);
    steeringAssembly.add(sirenRed);

    const sirenBlue = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.05, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x3b82f6, emissive: 0x3b82f6, emissiveIntensity: 1.5 })
    );
    sirenBlue.position.set(0.06, 0.16, -0.11);
    steeringAssembly.add(sirenBlue);
  }

  // Handlebar variants
  const makeHandlebar = (kind: HandlebarType): THREE.Group => {
    const hb = new THREE.Group();
    hb.position.set(0, 0.13, 0);
    const width = kind === 'oxxy' ? 0.72 : kind === 'esportivo' ? 0.58 : 0.64;
    const rise = kind === 'esportivo' ? -0.02 : kind === 'oxxy' ? 0.07 : 0.04;
    const barColor = kind === 'oxxy' ? 0xeab308 : 0xcbd5e1;
    const barMat = new THREE.MeshStandardMaterial({ color: barColor, metalness: 0.85, roughness: 0.25 });

    const mainBar = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, width, 10), barMat);
    mainBar.rotation.z = Math.PI / 2;
    mainBar.position.set(0, rise, 0.02);
    hb.add(mainBar);

    if (kind === 'oxxy') {
      const brace = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.34, 8), chromeMat);
      brace.rotation.z = Math.PI / 2;
      brace.position.set(0, rise + 0.045, 0.02);
      hb.add(brace);
    }

    for (const side of [-1, 1]) {
      const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.13, 10), seatMat);
      grip.rotation.z = Math.PI / 2;
      grip.position.set(side * (width * 0.5 - 0.05), rise, 0.02);
      hb.add(grip);

      if (kind !== 'esportivo') {
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.14, 6), frameMat);
        stem.position.set(side * (width * 0.32), rise + 0.07, 0.01);
        stem.rotation.z = side * -0.25;
        hb.add(stem);

        const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.085, 0.05, 0.016), frameMat);
        mirror.position.set(side * (width * 0.37), rise + 0.135, 0.01);
        hb.add(mirror);
      }
    }
    return hb;
  };

  const handlebarGroups: Record<HandlebarType, THREE.Group> = {
    original: makeHandlebar('original'),
    esportivo: makeHandlebar('esportivo'),
    oxxy: makeHandlebar('oxxy'),
  };
  Object.values(handlebarGroups).forEach((hg) => steeringAssembly.add(hg));

  // Rider positioned on the seat relative to chassisGroup
  const rider = buildRealisticRider(
    options?.isPolice ? '#0f172a' : options?.isRacer ? '#7c2d12' : '#1c222d',
    options?.isPolice ? 0xf8fafc : options?.isRacer ? 0x0284c7 : 0xdc2626
  );
  rider.root.position.set(0, 0.46, -0.34);
  chassisGroup.add(rider.root);

  // Soft contact shadow directly under bike
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 128;
  shadowCanvas.height = 128;
  const sCtx = shadowCanvas.getContext('2d');
  if (sCtx) {
    const grad = sCtx.createRadialGradient(64, 64, 6, 64, 64, 60);
    grad.addColorStop(0, 'rgba(0,0,0,0.55)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, 128, 128);
  }
  const shadowTex = new THREE.CanvasTexture(shadowCanvas);
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(0.95, 1.9),
    new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.set(0, 0.025, 0);
  root.add(contactShadow);

  const tireMeshes = [
    frontWheel.getObjectByName('tireMesh') as THREE.Mesh,
    rearWheel.getObjectByName('tireMesh') as THREE.Mesh,
  ].filter(Boolean);

  const applyCustomization = (custom: BikeCustomization) => {
    if (!options?.isPolice && !options?.isRacer) {
      const colorOpt = PAINT_COLORS.find((c) => c.id === custom.colorId) ?? PAINT_COLORS[0];
      paintMat.color.set(colorOpt.hex);
    }

    const model: BikeModelType = custom.bikeModel ?? 'cg_titan_160';
    titanShroudsGroup.visible = model !== 'cg_fan_160';
    headlightCowl.visible = model !== 'cg_fan_160';
    roundHeadlightBucket.visible = model === 'cg_fan_160';
    frontFender.visible = model !== 'bros_160';
    highFrontFender.visible = model === 'bros_160';
    skidPlate.visible = model === 'bros_160';

    const tireScale = custom.tire === 'slick' ? 1.12 : custom.tire === 'misto' ? 1.18 : 1.0;
    const tireRough = custom.tire === 'slick' ? 0.58 : custom.tire === 'misto' ? 0.96 : 0.85;
    tireMat.roughness = tireRough;
    tireMeshes.forEach((tm) => {
      tm.scale.set(1, 1, tireScale);
    });

    (Object.keys(exhaustGroups) as ExhaustType[]).forEach((k) => {
      exhaustGroups[k].visible = k === custom.exhaust;
    });
    (Object.keys(handlebarGroups) as HandlebarType[]).forEach((k) => {
      handlebarGroups[k].visible = k === custom.handlebar;
    });
    tailBarGroup.visible = custom.tailBar === 'alca_grau';
  };

  applyCustomization(initialCustom);

  const updateAnimation = (params: {
    wheelSpinDelta: number;
    steerAngle: number;
    wheelieRad: number;
    speedKmh: number;
    throttle: boolean;
    braking: boolean;
    nightFactor: number;
    timeSec: number;
  }) => {
    frontWheel.rotation.x -= params.wheelSpinDelta;
    rearWheel.rotation.x -= params.wheelSpinDelta;
    steeringAssembly.rotation.y = params.steerAngle;

    chassisGroup.rotation.x = params.wheelieRad;

    tailLightMat.emissiveIntensity = params.braking ? 2.8 : 0.7 + params.nightFactor * 0.7;
    const hlPower = params.nightFactor > 0.2 ? 0.8 + params.nightFactor * 2.2 : 0.35;
    headlightBulbMat.emissiveIntensity = hlPower;
    headlightSpot.intensity = options?.isRemote ? 0 : params.nightFactor * 45;

    const speedTuck = Math.min(1, params.speedKmh / 140) * 0.25;
    const wheelieCounterLean = -params.wheelieRad * 0.42;
    rider.torso.rotation.x = -0.22 - speedTuck + wheelieCounterLean;
    rider.head.rotation.x = 0.14 + speedTuck * 0.5 - wheelieCounterLean * 0.35;

    rider.leftArm.rotation.y = params.steerAngle * 0.45;
    rider.rightArm.rotation.y = params.steerAngle * 0.45;
    rider.leftArm.rotation.x = -wheelieCounterLean * 0.45;
    rider.rightArm.rotation.x = -wheelieCounterLean * 0.45;

    const stoppedBlend = 1 - Math.min(1, params.speedKmh / 9);
    rider.leftLeg.rotation.z = stoppedBlend * 0.32;
    rider.leftLeg.rotation.x = stoppedBlend * -0.18;
    rider.rightLeg.rotation.z = 0;

    if (params.speedKmh < 2) {
      chassisGroup.position.y = 0.31 + Math.sin(params.timeSec * 38) * 0.0025;
    } else {
      chassisGroup.position.y = 0.31;
    }
  };

  return {
    root,
    chassisGroup,
    steeringAssembly,
    frontWheel,
    rearWheel,
    swingarm,
    headlightSpot,
    headlightBulbMat,
    tailLightMat,
    paintMaterials: [paintMat],
    tireMeshes,
    exhaustGroups,
    handlebarGroups,
    tailBarGroup,
    rider,
    applyCustomization,
    updateAnimation,
  };
}
