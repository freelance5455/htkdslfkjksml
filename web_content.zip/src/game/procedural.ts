import { Tile, TileType, ResourceNode, ResourceType, PointOfInterest, BiomeType } from '../types/game';

// Seeded PRNG (Mulberry32)
export class PRNG {
  private s: number;

  constructor(seed: number) {
    this.s = seed;
  }

  public next(): number {
    let t = (this.s += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  public range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  public int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }
}

// 2D Value Noise function for terrain height and moisture maps
function createNoise2D(prng: PRNG) {
  const perm: number[] = [];
  for (let i = 0; i < 256; i++) {
    perm[i] = i;
  }
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(prng.next() * (i + 1));
    const tmp = perm[i];
    perm[i] = perm[j];
    perm[j] = tmp;
  }
  const p = [...perm, ...perm];

  return function noise(x: number, y: number): number {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);

    const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
    const u = fade(xf);
    const v = fade(yf);

    const aa = p[p[X] + Y];
    const ab = p[p[X] + Y + 1];
    const ba = p[p[X + 1] + Y];
    const bb = p[p[X + 1] + Y + 1];

    const grad = (hash: number) => (hash % 2 === 0 ? 1 : -1) * ((hash & 2) === 0 ? 0.7 : 0.3);

    const x1 = (1 - u) * grad(aa) + u * grad(ba);
    const x2 = (1 - u) * grad(ab) + u * grad(bb);
    return (1 - v) * x1 + v * x2;
  };
}

export const WORLD_WIDTH = 140; // Expanded Archipelago Island (tiles)
export const WORLD_HEIGHT = 140; // Expanded Archipelago Island (tiles)
export const TILE_SIZE = 32;

export interface GeneratedWorld {
  seed: number;
  tiles: Tile[][];
  resources: ResourceNode[];
  pois: PointOfInterest[];
  spawnX: number;
  spawnY: number;
}

export function generateWorld(seed: number = Math.floor(Math.random() * 1000000)): GeneratedWorld {
  const prng = new PRNG(seed);
  const heightNoise = createNoise2D(prng);
  const moistureNoise = createNoise2D(new PRNG(seed + 42));

  const tiles: Tile[][] = [];
  const resources: ResourceNode[] = [];
  const pois: PointOfInterest[] = [];

  const spawnTileX = 70;
  const spawnTileY = 70;

  for (let y = 0; y < WORLD_HEIGHT; y++) {
    tiles[y] = [];
    for (let x = 0; x < WORLD_WIDTH; x++) {
      // Distance from center / spawn
      const distFromSpawn = Math.hypot(x - spawnTileX, y - spawnTileY);

      // Multi-octave noise samples
      const nx = x / 20;
      const ny = y / 20;
      const h = heightNoise(nx, ny) + 0.5 * heightNoise(nx * 2, ny * 2) - (distFromSpawn / (WORLD_WIDTH * 0.55));
      const m = moistureNoise(nx * 0.7, ny * 0.7);

      let tileType: TileType = 'grass';
      let biome: BiomeType = 'forest';
      let walkable = true;

      // Determine Biome and Tile
      if (distFromSpawn < 6) {
        tileType = 'grass';
        biome = 'forest';
      } else if (h < -0.36) {
        tileType = 'deep_water';
        walkable = false;
        biome = 'beach';
      } else if (h < -0.22) {
        tileType = 'water';
        walkable = false;
        biome = 'beach';
      } else if (h < -0.1) {
        tileType = 'sand';
        biome = 'beach';
      } else if (h > 0.38) {
        tileType = 'dirt';
        biome = 'rocky';
      } else if (m > 0.28) {
        tileType = 'grass_dense';
        biome = 'dense_forest';
      } else if (m < -0.2 && h < 0.1) {
        tileType = 'dirt';
        biome = 'wetland';
      } else if (m > 0.1) {
        tileType = 'grass_dense';
        biome = 'forest';
      } else {
        tileType = 'grass';
        biome = 'forest';
      }

      // Edge of world ocean boundary
      if (x <= 2 || y <= 2 || x >= WORLD_WIDTH - 3 || y >= WORLD_HEIGHT - 3) {
        tileType = 'deep_water';
        walkable = false;
        biome = 'beach';
      }

      tiles[y][x] = {
        type: tileType,
        walkable,
        variant: prng.int(0, 3),
        biome,
      };

      // Resource Generation on Walkable Land
      if (walkable && distFromSpawn >= 4) {
        const rand = prng.next();
        const worldX = x * TILE_SIZE + 16;
        const worldY = y * TILE_SIZE + 16;

        if (biome === 'dense_forest') {
          // Towering pine trees, ancient oaks, mushrooms & berry bushes
          if (rand < 0.16) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'tree_pine',
              x: worldX,
              y: worldY,
              health: 120,
              maxHealth: 120,
              harvested: false,
              width: 44,
              height: 64,
            });
          } else if (rand < 0.24) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'tree_oak',
              x: worldX,
              y: worldY,
              health: 110,
              maxHealth: 110,
              harvested: false,
              width: 48,
              height: 64,
            });
          } else if (rand < 0.3) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'bush_berry',
              x: worldX,
              y: worldY,
              health: 35,
              maxHealth: 35,
              harvested: false,
              width: 32,
              height: 32,
            });
          }
        } else if (biome === 'forest') {
          // Lush Oak, Birch, Flowers & Berries
          if (rand < 0.12) {
            const isBirch = prng.next() < 0.4;
            resources.push({
              id: `res_${x}_${y}`,
              type: isBirch ? 'tree_birch' : 'tree_oak',
              x: worldX,
              y: worldY,
              health: 100,
              maxHealth: 100,
              harvested: false,
              width: 48,
              height: 64,
            });
          } else if (rand < 0.17) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'bush_berry',
              x: worldX,
              y: worldY,
              health: 30,
              maxHealth: 30,
              harvested: false,
              width: 32,
              height: 32,
            });
          } else if (rand < 0.23) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'flower',
              x: worldX,
              y: worldY,
              health: 10,
              maxHealth: 10,
              harvested: false,
              width: 24,
              height: 24,
            });
          } else if (rand < 0.26) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'rock',
              x: worldX,
              y: worldY,
              health: 120,
              maxHealth: 120,
              harvested: false,
              width: 32,
              height: 32,
            });
          }
        } else if (biome === 'rocky') {
          // Rocky Highlands: Granite, Iron Ore, Coal Outcrops
          if (rand < 0.14) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'rock',
              x: worldX,
              y: worldY,
              health: 130,
              maxHealth: 130,
              harvested: false,
              width: 32,
              height: 32,
            });
          } else if (rand < 0.21) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'rock_iron',
              x: worldX,
              y: worldY,
              health: 160,
              maxHealth: 160,
              harvested: false,
              width: 32,
              height: 32,
            });
          } else if (rand < 0.27) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'rock_coal',
              x: worldX,
              y: worldY,
              health: 120,
              maxHealth: 120,
              harvested: false,
              width: 32,
              height: 32,
            });
          }
        } else if (biome === 'beach') {
          // Sandy Shore: Driftwood logs & shell stones
          if (rand < 0.05) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'rock',
              x: worldX,
              y: worldY,
              health: 80,
              maxHealth: 80,
              harvested: false,
              width: 28,
              height: 28,
            });
          }
        } else if (biome === 'wetland') {
          // Reeds and water flora
          if (rand < 0.15) {
            resources.push({
              id: `res_${x}_${y}`,
              type: 'flower',
              x: worldX,
              y: worldY,
              health: 15,
              maxHealth: 15,
              harvested: false,
              width: 24,
              height: 24,
            });
          }
        }
      }
    }
  }

  // Generate Unique Points of Interest (POIs)
  pois.push({
    id: 'poi_ruins',
    type: 'ruins',
    x: (spawnTileX + 22) * TILE_SIZE,
    y: (spawnTileY - 20) * TILE_SIZE,
    nameAr: 'أطلال المعبد القديم',
    descAr: 'بقايا أثرية حجرية غامضة تحوي صندوق أسرار ومؤن نادرة.',
    discovered: false,
  });

  pois.push({
    id: 'poi_camp',
    type: 'abandoned_camp',
    x: (spawnTileX - 24) * TILE_SIZE,
    y: (spawnTileY + 18) * TILE_SIZE,
    nameAr: 'مخيم المستكشف المهجور',
    descAr: 'مأوى خشبي وموقد نار قديم تركه ناجون سابقون.',
    discovered: false,
  });

  pois.push({
    id: 'poi_spring',
    type: 'hidden_spring',
    x: (spawnTileX - 18) * TILE_SIZE,
    y: (spawnTileY - 22) * TILE_SIZE,
    nameAr: 'النبع النقي السري',
    descAr: 'بركة مياه نقية منعزلة تحيط بها نباتات وأزهار نادرة.',
    discovered: false,
  });

  pois.push({
    id: 'poi_ore_ridge',
    type: 'ore_cluster',
    x: (spawnTileX + 26) * TILE_SIZE,
    y: (spawnTileY + 24) * TILE_SIZE,
    nameAr: 'هضبة خامات الحديد',
    descAr: 'نتوء جبلي غني بعروق خام الحديد والفحم.',
    discovered: false,
  });

  // Starter resources around spawn for immediate gameplay
  resources.push({
    id: 'starter_tree_1',
    type: 'tree_oak',
    x: (spawnTileX - 3) * TILE_SIZE + 16,
    y: (spawnTileY - 2) * TILE_SIZE + 16,
    health: 100,
    maxHealth: 100,
    harvested: false,
    width: 48,
    height: 64,
  });
  resources.push({
    id: 'starter_rock_1',
    type: 'rock',
    x: (spawnTileX + 3) * TILE_SIZE + 16,
    y: (spawnTileY + 2) * TILE_SIZE + 16,
    health: 120,
    maxHealth: 120,
    harvested: false,
    width: 32,
    height: 32,
  });
  resources.push({
    id: 'starter_berry_1',
    type: 'bush_berry',
    x: (spawnTileX + 2) * TILE_SIZE + 16,
    y: (spawnTileY - 3) * TILE_SIZE + 16,
    health: 30,
    maxHealth: 30,
    harvested: false,
    width: 32,
    height: 32,
  });

  return {
    seed,
    tiles,
    resources,
    pois,
    spawnX: spawnTileX * TILE_SIZE + 16,
    spawnY: spawnTileY * TILE_SIZE + 16,
  };
}
