import * as THREE from "three";

/** Growable merged, non-indexed geometry builder with flat normals, vertex colors & wind sway weights */
export class GeoBuilder {
  pos: number[] = [];
  col: number[] = [];
  sway: number[] = [];
  private m: THREE.Matrix4 | null = null;
  private v = new THREE.Vector3();
  swayBase = 0;
  swayScale = 0; // sway added per unit of local height

  setTransform(m: THREE.Matrix4 | null) {
    this.m = m;
  }

  private push(x: number, y: number, z: number, sw: number) {
    if (this.m) {
      this.v.set(x, y, z).applyMatrix4(this.m);
      this.pos.push(this.v.x, this.v.y, this.v.z);
    } else this.pos.push(x, y, z);
    this.sway.push(sw);
  }

  tri(
    ax: number, ay: number, az: number,
    bx: number, by: number, bz: number,
    cx: number, cy: number, cz: number,
    r: number, g: number, b: number,
    sa = 0, sb = 0, sc = 0
  ) {
    this.push(ax, ay, az, sa);
    this.push(bx, by, bz, sb);
    this.push(cx, cy, cz, sc);
    this.col.push(r, g, b, r, g, b, r, g, b);
  }

  quad(p: number[], r: number, g: number, b: number, s = [0, 0, 0, 0]) {
    // p: 4 points (x,y,z)*4 counter-clockwise
    this.tri(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], r, g, b, s[0], s[1], s[2]);
    this.tri(p[0], p[1], p[2], p[6], p[7], p[8], p[9], p[10], p[11], r, g, b, s[0], s[2], s[3]);
  }

  /** box centered at (cx, y0..y0+h, cz), rotated around Y */
  box(cx: number, y0: number, cz: number, sx: number, h: number, sz: number, rot: number, r: number, g: number, b: number, shadeTop = 1.08, bottom = false) {
    const c = Math.cos(rot), s = Math.sin(rot);
    const hx = sx / 2, hz = sz / 2;
    const P = (lx: number, lz: number) => [cx + lx * c + lz * s, cz - lx * s + lz * c];
    const a = P(-hx, -hz), bb = P(hx, -hz), cc = P(hx, hz), d = P(-hx, hz);
    const y1 = y0 + h;
    // sides
    const sides = [[a, bb, 0.86], [bb, cc, 0.95], [cc, d, 1.0], [d, a, 0.9]] as const;
    for (const [p, q, k] of sides) {
      this.quad([p[0], y0, p[1], p[0], y1, p[1], q[0], y1, q[1], q[0], y0, q[1]], r * k, g * k, b * k);
    }
    this.quad([a[0], y1, a[1], d[0], y1, d[1], cc[0], y1, cc[1], bb[0], y1, bb[1]], Math.min(1, r * shadeTop), Math.min(1, g * shadeTop), Math.min(1, b * shadeTop));
    if (bottom) this.quad([a[0], y0, a[1], bb[0], y0, bb[1], cc[0], y0, cc[1], d[0], y0, d[1]], r * 0.6, g * 0.6, b * 0.6);
  }

  /** gable roof prism: ridge along local x */
  roof(cx: number, y0: number, cz: number, sx: number, sz: number, h: number, rot: number, r: number, g: number, b: number) {
    const c = Math.cos(rot), s = Math.sin(rot);
    const hx = sx / 2, hz = sz / 2;
    const P = (lx: number, ly: number, lz: number) => [cx + lx * c + lz * s, y0 + ly, cz - lx * s + lz * c];
    const a = P(-hx, 0, -hz), bb = P(hx, 0, -hz), cc = P(hx, 0, hz), d = P(-hx, 0, hz);
    const t0 = P(-hx, h, 0), t1 = P(hx, h, 0);
    this.quad([...a, ...t0, ...t1, ...bb], r * 0.82, g * 0.82, b * 0.82);
    this.quad([...cc, ...t1, ...t0, ...d], r, g, b);
    this.tri(...(d as [number, number, number]), ...(t0 as [number, number, number]), ...(a as [number, number, number]), r * 0.7, g * 0.7, b * 0.7);
    this.tri(...(bb as [number, number, number]), ...(t1 as [number, number, number]), ...(cc as [number, number, number]), r * 0.7, g * 0.7, b * 0.7);
    // underside
    this.quad([...bb, ...cc, ...d, ...a], r * 0.4, g * 0.4, b * 0.4);
  }

  /** cone / cylinder with n sides (r2 = top radius) */
  cyl(cx: number, y0: number, cz: number, r1: number, r2: number, h: number, n: number, r: number, g: number, b: number, sw0 = 0, sw1 = 0, rot0 = 0, cap = true) {
    const y1 = y0 + h;
    for (let i = 0; i < n; i++) {
      const a0 = rot0 + (i / n) * Math.PI * 2;
      const a1 = rot0 + ((i + 1) / n) * Math.PI * 2;
      const k = 0.78 + 0.22 * (0.5 + 0.5 * Math.cos(a0 - 0.8));
      const x0 = Math.cos(a0), z0 = Math.sin(a0), x1 = Math.cos(a1), z1 = Math.sin(a1);
      if (r2 <= 0.0001) {
        this.tri(cx + x0 * r1, y0, cz + z0 * r1, cx, y1, cz, cx + x1 * r1, y0, cz + z1 * r1, r * k, g * k, b * k, sw0, sw1, sw0);
      } else {
        this.quad([cx + x0 * r1, y0, cz + z0 * r1, cx + x0 * r2, y1, cz + z0 * r2, cx + x1 * r2, y1, cz + z1 * r2, cx + x1 * r1, y0, cz + z1 * r1], r * k, g * k, b * k, [sw0, sw1, sw1, sw0]);
        if (cap) this.tri(cx, y1, cz, cx + x1 * r2, y1, cz + z1 * r2, cx + x0 * r2, y1, cz + z0 * r2, Math.min(1, r * 1.05), Math.min(1, g * 1.05), Math.min(1, b * 1.05), sw1, sw1, sw1);
      }
    }
  }

  /** low poly blob (icosahedron) */
  blob(cx: number, cy: number, cz: number, sx: number, sy: number, sz: number, r: number, g: number, b: number, rnd: () => number, sw = 0, jitter = 0.18) {
    const V = ICO_V;
    const pts: number[] = [];
    for (let i = 0; i < V.length; i += 3) {
      const j = 1 + (rnd() - 0.5) * jitter * 2;
      pts.push(cx + V[i] * sx * j, cy + V[i + 1] * sy * j, cz + V[i + 2] * sz * j);
    }
    for (let i = 0; i < ICO_F.length; i += 3) {
      const a = ICO_F[i] * 3, bb = ICO_F[i + 1] * 3, c = ICO_F[i + 2] * 3;
      const ny = (V[a + 1] + V[bb + 1] + V[c + 1]) / 3;
      const k = 0.72 + 0.4 * (ny * 0.5 + 0.5) + (rnd() - 0.5) * 0.08;
      const swa = sw * (0.5 + 0.5 * (V[a + 1] * 0.5 + 0.5));
      const swb = sw * (0.5 + 0.5 * (V[bb + 1] * 0.5 + 0.5));
      const swc = sw * (0.5 + 0.5 * (V[c + 1] * 0.5 + 0.5));
      this.tri(pts[a], pts[a + 1], pts[a + 2], pts[bb], pts[bb + 1], pts[bb + 2], pts[c], pts[c + 1], pts[c + 2], Math.min(1, r * k), Math.min(1, g * k), Math.min(1, b * k), swa, swb, swc);
    }
  }

  /** octahedron (crystals / tiny props) */
  octa(cx: number, cy: number, cz: number, sx: number, sy: number, sz: number, r: number, g: number, b: number, rot = 0) {
    const c = Math.cos(rot), s = Math.sin(rot);
    const P = (x: number, y: number, z: number) => [cx + x * sx * c + z * sz * s, cy + y * sy, cz - x * sx * s + z * sz * c];
    const top = P(0, 1, 0), bot = P(0, -1, 0);
    const ring = [P(1, 0, 0), P(0, 0, 1), P(-1, 0, 0), P(0, 0, -1)];
    for (let i = 0; i < 4; i++) {
      const a = ring[i], bb = ring[(i + 1) % 4];
      const k = 0.75 + i * 0.09;
      this.tri(a[0], a[1], a[2], top[0], top[1], top[2], bb[0], bb[1], bb[2], Math.min(1, r * k * 1.15), Math.min(1, g * k * 1.15), Math.min(1, b * k * 1.15));
      this.tri(bb[0], bb[1], bb[2], bot[0], bot[1], bot[2], a[0], a[1], a[2], r * k * 0.7, g * k * 0.7, b * k * 0.7);
    }
  }

  get count() {
    return this.pos.length / 3;
  }

  build(withSway = false): THREE.BufferGeometry {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute("color", new THREE.Float32BufferAttribute(this.col, 3));
    if (withSway) g.setAttribute("aSway", new THREE.Float32BufferAttribute(this.sway, 1));
    g.computeVertexNormals();
    g.computeBoundingSphere();
    return g;
  }
}

// Icosahedron data
const t = (1 + Math.sqrt(5)) / 2;
const raw = [-1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, 0, 0, -1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, t, 0, -1, t, 0, 1, -t, 0, -1, -t, 0, 1];
const ICO_V: number[] = [];
for (let i = 0; i < raw.length; i += 3) {
  const l = Math.hypot(raw[i], raw[i + 1], raw[i + 2]);
  ICO_V.push(raw[i] / l, raw[i + 1] / l, raw[i + 2] / l);
}
const ICO_F = [0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11, 1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8, 3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9, 4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1];
