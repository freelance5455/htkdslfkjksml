import { GameState, Gender } from './types';

export interface RandomEventDef {
  id: string;
  category: 'family' | 'work' | 'city' | 'crime' | 'crisis' | 'opportunity';
  title: string;
  condition?: (state: GameState) => boolean;
  text: (state: GameState) => string;
  options: {
    label: string;
    description?: string;
    execute: (state: GameState) => { outcome: string; stateMod: Partial<GameState> };
  }[];
}

export const RANDOM_EVENTS_POOL: RandomEventDef[] = [
  // ---------------- 1. FAMILY, PREGNANCY & SPOUSE ----------------
  {
    id: 'pregnant_craving',
    category: 'family',
    title: '🍓 وحم مفاجئ لزوجتك',
    condition: (s) => s.married && s.pregnancyDaysRemaining > 0,
    text: (s) => `استيقظت ${s.partnerName} في وقت متأخر وهي تشتهي فاكهة طازجة وحلويات خاصة بالوحم. ماذا تفعل؟`,
    options: [
      {
        label: 'أنزل فوراً وأشتري طلباتها (80 ج.م)',
        description: 'يزيد الحب والسعادة الأسرية بشكل كبير',
        execute: (s) => ({
          outcome: `نزلت واشتريت لها ما طلبت، ابتسمت ${s.partnerName} وشعرت بحبك واهتمامك العميق.`,
          stateMod: {
            money: Math.max(0, s.money - 80),
            love: Math.min(100, s.love + 8),
            familyMood: Math.min(100, s.familyMood + 10),
            trust: Math.min(100, s.trust + 5)
          }
        })
      },
      {
        label: 'اعتذر بهدوء وحضّر لها مشروباً دافئاً في البيت',
        description: 'بدون مصاريف، لكن استجابة معنوية مقبولة',
        execute: (s) => ({
          outcome: `حضّرت لها شاياً بالأعشاب، تفهمت الموقف وقدرت محاولتك لتخفيف الأمر.`,
          stateMod: {
            love: Math.min(100, s.love + 2)
          }
        })
      }
    ]
  },
  {
    id: 'mother_in_law_visit',
    category: 'family',
    title: '👵 زيارة مفاجئة للحمات في البيت',
    condition: (s) => s.married,
    text: (s) => `والدة ${s.partnerName} زارتكم على غداء الجمعة لتطمئن على أحوال البيت والأسرة ومستواكم المعيشي.`,
    options: [
      {
        label: 'استقبال فاخر وغداء مشويات محترم (280 ج.م)',
        description: 'انطباع رائع يرفع مكانتك وهيبتك عند العائلة',
        execute: (s) => ({
          outcome: `أثنت والدتها على كرمك وحسن ضيافتك ودعت لكم بالبركة، وفرحت ${s.partnerName} جداً باحترامك لأهلها.`,
          stateMod: {
            money: Math.max(0, s.money - 280),
            love: Math.min(100, s.love + 10),
            trust: Math.min(100, s.trust + 8),
            familyMood: Math.min(100, s.familyMood + 12),
            rep: Math.min(100, s.rep + 4)
          }
        })
      },
      {
        label: 'ضيافة عادية وشاي مع حلوى البيت',
        description: 'اقتصادي وهادئ بدون تكاليف إضافية',
        execute: () => ({
          outcome: 'مرت الجلسة بسلام وتبادلتم الأحاديث العائلية الودية.',
          stateMod: {
            familyMood: Math.min(100, 75)
          }
        })
      }
    ]
  },
  {
    id: 'anniversary_surprise',
    category: 'family',
    title: '🌹 ذكرى خاصة تجمعك بشريكتك',
    condition: (s) => s.married || s.engaged,
    text: (s) => `اليوم يصادف ذكرى ارتباطكم الأول! لاحظت أن ${s.partnerName} تتذكر اليوم وتنتظر منك مفاجأة خاصة.`,
    options: [
      {
        label: 'حجز سهرة وهدية راقية (350 ج.م)',
        execute: (s) => ({
          outcome: `دمعت عيناها من الفرحة! "كنت واثقة إنك عمرك ما هتنسى يومنا". اشتعلت الرومانسية بينكم.`,
          stateMod: {
            money: Math.max(0, s.money - 350),
            love: Math.min(100, s.love + 18),
            trust: Math.min(100, s.trust + 10),
            mood: Math.min(100, s.mood + 15)
          }
        })
      },
      {
        label: 'رسالة رومانسية مكتوبة بخط اليد ووردة',
        execute: (s) => ({
          outcome: 'قرأت الكلمات وتأثرت بمشاعرك الصادقة واحتضنتك بامتنان.',
          stateMod: {
            love: Math.min(100, s.love + 8),
            trust: Math.min(100, s.trust + 5)
          }
        })
      }
    ]
  },
  {
    id: 'kid_school_award',
    category: 'family',
    title: '🏆 تفوق أحد الأولاد في المدرسة',
    condition: (s) => s.children.length > 0 && s.children.some(c => c.education >= 40),
    text: (s) => {
      const topKid = s.children.find(c => c.education >= 40) || s.children[0];
      return `عاد ${topKid.name} من المدرسة حاملاً شهادة تفوق في صفه الدراسي! المعلمون يثنون على أدبه واجتهاده.`;
    },
    options: [
      {
        label: 'أقِم حفلة عائلية وهدية تشجيعية (150 ج.م)',
        execute: (s) => ({
          outcome: 'فرح الأطفال جميعاً وارتفعت الروح المعنوية في البيت لأسابيع قادمة!',
          stateMod: {
            money: Math.max(0, s.money - 150),
            familyMood: Math.min(100, s.familyMood + 16),
            rep: Math.min(100, s.rep + 3)
          }
        })
      },
      {
        label: 'حضن وكلمات فخر ودعاء طيب',
        execute: () => ({
          outcome: 'شعر ابنك بالفخر بكلماتك وتشجيعك الصادق.',
          stateMod: {
            familyMood: Math.min(100, 75)
          }
        })
      }
    ]
  },
  {
    id: 'kid_fever_visit',
    category: 'crisis',
    title: '🌡️ ارتفاع حرارة مفاجئ لطفلك',
    condition: (s) => s.children.length > 0,
    text: (s) => {
      const kid = s.children[0];
      return `استيقظ ${kid.name} بحرارة مرتفعة وسعال مستمر. يحتاج كشفاً طبياً وأدوية.`;
    },
    options: [
      {
        label: 'اصطحبه لعيادة طبيب أطفال خاص (220 ج.م)',
        execute: (s) => ({
          outcome: 'فحصه الطبيب ووصف له علاجاً فعالاً، واستقرت حالته الصحية بفضل الله.',
          stateMod: {
            money: Math.max(0, s.money - 220),
            familyMood: Math.min(100, s.familyMood + 6),
            trust: Math.min(100, s.trust + 4)
          }
        })
      },
      {
        label: 'كمادات وأدوية مسكنة من الصيدلية (60 ج.م)',
        execute: (s) => ({
          outcome: 'انخفضت الحرارة تدريجياً، وقضيت الليل تسهر بجواره مما أرهق طاقتك.',
          stateMod: {
            money: Math.max(0, s.money - 60),
            energy: Math.max(0, s.energy - 20)
          }
        })
      }
    ]
  },
  {
    id: 'kid_curious_question',
    category: 'family',
    title: '🤔 سؤال عميق ومحرج من طفلك',
    condition: (s) => s.children.length > 0 && s.children.some(c => c.ageDays >= 6),
    text: (s) => {
      const kid = s.children[0];
      return `جلس ${kid.name} بجوارك وسألك بعيون بريئة: "يا بابا، إحنا ليه بنشتغل ونتعب؟ وهل الفلوس هي أهم حاجة في الدنيا؟"`;
    },
    options: [
      {
        label: 'شرح تربوي حكيم عن الشرف والبركة والكرامة',
        description: 'يرفع انضباط الطفل وثقته فيك كقدوة',
        execute: (s) => {
          const target = s.children[0];
          target.discipline = Math.min(100, (target.discipline || 70) + 12);
          target.education = Math.min(100, target.education + 5);
          return {
            outcome: `استمع لك ${target.name} بانبهار وقال لك: "أنا عايز أطلع راجل شريف ومكافح زيك يا بابا!".`,
            stateMod: {
              mood: Math.min(100, s.mood + 10),
              familyMood: Math.min(100, s.familyMood + 8)
            }
          };
        }
      },
      {
        label: 'ابتسم وأعطه قطعة شوكولاتة وقل له: "لما تكبر هتفهم"',
        execute: () => ({
          outcome: 'أكل الحلوى وذهب ليلعب، لكن السؤال ظل يدور في باله.',
          stateMod: {}
        })
      }
    ]
  },

  // ---------------- 2. WORKPLACE & CAREER DILEMMAS ----------------
  {
    id: 'competitor_poaching_offer',
    category: 'work',
    title: '💼 عرض مغرٍ وسري من شركة منافسة',
    condition: (s) => s.daysWorked >= 10 && s.skill >= 20,
    text: () => 'تواصل معك مسؤول توظيف من شركة منافسة في السوق وعرض عليك الانتقال لهم براتب إضافي 35% فورياً، ولكن مع تسليم بعض خطط عمل شركتك الحالية!',
    options: [
      {
        label: 'الرفض بحزم: "الأمانة المهنية لا تُباع بالمال"',
        description: 'يحمي سمعتك ويرفع مكانتك عند إدارتك الحالية',
        execute: (s) => ({
          outcome: 'علم مديرك الحالي بموقفك النبيل، فمنحك مكافأة فورية 600 ج.م وشهادة تقدير!',
          stateMod: {
            money: s.money + 600,
            rep: Math.min(100, s.rep + 8),
            mood: Math.min(100, s.mood + 10)
          }
        })
      },
      {
        label: 'الموافقة والانتقال للشركة المنافسة (+2,200 ج.م)',
        description: 'مكسب مالي فوري لكنه يضر بسمعتك المهنية',
        execute: (s) => ({
          outcome: 'أخذت المكافأة والانتقال، لكن زملاءك القدامى شعروا بالخيانة وراجت شائعات عنك.',
          stateMod: {
            money: s.money + 2200,
            rep: Math.max(0, s.rep - 10),
            trust: Math.max(0, s.trust - 5)
          }
        })
      }
    ]
  },
  {
    id: 'office_audit_crisis',
    category: 'work',
    title: '📊 جرد مفاجئ وفقدان مستند هام',
    condition: (s) => s.currentCareerTrack === 'corporate' || s.currentCareerTrack === 'commerce',
    text: () => 'لجنة تفتيش من الإدارة العليا طلبت فحص ملف الحسابات، وهناك فاتورة بقيمة 1,200 ج.م مفقودة من الأرشيف!',
    options: [
      {
        label: 'السهر للبحث عنها ومراجعة الأرشيف بدقة',
        description: 'يستهلك 25 طاقة ولكنه ينقذك بالكامل',
        execute: (s) => ({
          outcome: 'وجدت الفاتورة مسجلة بالخطأ في ملف آخر، وقدمتها للجنة ونلت إشادة على دقة مراجعتك!',
          stateMod: {
            energy: Math.max(0, s.energy - 25),
            skill: Math.min(100, s.skill + 3),
            rep: Math.min(100, s.rep + 6)
          }
        })
      },
      {
        label: 'دفع قيمة العجز من جيبك لتفادي الشبهات (1,200 ج.م)',
        execute: (s) => ({
          outcome: 'أغلقت الملف سريعاً لكنك خسرت مبلغاً مؤثراً من مدخراتك.',
          stateMod: {
            money: Math.max(0, s.money - 1200),
            mood: Math.max(0, s.mood - 12)
          }
        })
      }
    ]
  },
  {
    id: 'tech_server_outage',
    category: 'work',
    title: '🚨 انهيار خوادم الشركة في منتصف الليل',
    condition: (s) => s.currentCareerTrack === 'tech',
    text: () => 'رن هاتفك الساعة 2 صباحاً: خوادم الشركة تعرضت لهجوم سيبراني وتوقفت بالكامل! العملاء يصرخون والمدير يستغيث بك.',
    options: [
      {
        label: 'فتح اللابتوب فوراً والتصدي للاختراق وتأمين النظام',
        execute: (s) => {
          if (s.skill >= 35) {
            return {
              outcome: 'أنقذت الشركة من خسارة ملايين! أشاد بك مجلس الإدارة ومُنحت بونص استثنائي 1,800 ج.م!',
              stateMod: {
                money: s.money + 1800,
                skill: Math.min(100, s.skill + 5),
                rep: Math.min(100, s.rep + 10),
                energy: Math.max(0, s.energy - 30)
              }
            };
          } else {
            return {
              outcome: 'حاولت بقدر استطاعتك واستعدت جزءاً من البيانات، استهلكت ليلتك في كفاح تقني مرير.',
              stateMod: {
                skill: Math.min(100, s.skill + 3),
                energy: Math.max(0, s.energy - 35)
              }
            };
          }
        }
      },
      {
        label: 'تجاهل الاتصال وإغلاق الهاتف للنوم',
        execute: (s) => ({
          outcome: 'استيقظت على توبيخ رسمي وخصم 3 أيام من راتبك لعدم الاستجابة لحالة الطوارئ.',
          stateMod: {
            money: Math.max(0, s.money - 450),
            rep: Math.max(0, s.rep - 6)
          }
        })
      }
    ]
  },
  {
    id: 'generous_client_tip',
    category: 'work',
    title: '💎 إكرامية غير متوقعة من عميل VIP',
    condition: (s) => s.daysWorked >= 3,
    text: () => 'أعجب عميل ثري بأمانتك وسرعة تنفيذك لطلبه، وترك لك ظرفاً مغلقاً كهدية تقدير شخصية!',
    options: [
      {
        label: 'شكر العميل وقبول الهدية (+500 ج.م)',
        execute: (s) => ({
          outcome: 'فتحت الظرف ووجدت 500 ج.م مع بطاقة شكر لطيفة أنعشت يومك!',
          stateMod: {
            money: s.money + 500,
            mood: Math.min(100, s.mood + 14)
          }
        })
      },
      {
        label: 'شراء حلوى وتوزيعها على الزملاء في العمل',
        execute: (s) => ({
          outcome: 'احتفلت مع زملائك، وزادت محبتك وشعبيتك في مكان العمل بشكل لا يُنسى.',
          stateMod: {
            money: s.money + 250,
            rep: Math.min(100, s.rep + 8),
            mood: Math.min(100, s.mood + 16)
          }
        })
      }
    ]
  },

  // ---------------- 3. STREET & CITY ENCOUNTERS ----------------
  {
    id: 'lost_wallet_found',
    category: 'opportunity',
    title: '👛 محفظة مفقودة في الشارع',
    text: () => 'وأنت عائد إلى البيت، وجدت محفظة جلدية سميكة على الرصيف وبداخلها 1,800 ج.م وبطاقة هوية لصاحبها!',
    options: [
      {
        label: 'الاتصال بالرقم الموجود في البطاقة وإعادتها لأمانة',
        execute: (s) => ({
          outcome: 'فرح صاحب المحفظة كثيراً لأنها تحتوي على أوراق مهمة، وقدم لك مكافأة 300 ج.م ودعوات بالبركة والستر.',
          stateMod: {
            money: s.money + 300,
            rep: Math.min(100, s.rep + 8),
            mood: Math.min(100, s.mood + 14),
            trust: Math.min(100, s.trust + 6)
          }
        })
      },
      {
        label: 'أخذ الأموال وتجاهل المحفظة (+1,800 ج.م)',
        execute: (s) => ({
          outcome: 'أخذت الأموال لنفسك، لكن ضميرك يؤنبك وشعرت بعدم الراحة.',
          stateMod: {
            money: s.money + 1800,
            mood: Math.max(0, s.mood - 18),
            rep: Math.max(0, s.rep - 4)
          }
        })
      }
    ]
  },
  {
    id: 'fender_bender_accident',
    category: 'crisis',
    title: '🚗 حادث تصادم خفيف في الزحام',
    condition: (s) => s.assets.includes('car') || s.assets.includes('bike') || s.assets.includes('luxcar'),
    text: () => 'أثناء القيادة في شارع مزدحم، صدم سائق تاكسي سيارتك من الخلف صدمة متوسطة أدت لكسر الفانوس وخدش الصدام.',
    options: [
      {
        label: 'التصالح الودي وتفهم ظروفه المعيشية (إصلاح بـ 180 ج.م)',
        execute: (s) => ({
          outcome: 'دعا لك السائق بالستر والبركة، وأصلحت العطل بهدوء دون شجار.',
          stateMod: {
            money: Math.max(0, s.money - 180),
            rep: Math.min(100, s.rep + 4),
            mood: Math.min(100, s.mood + 2)
          }
        })
      },
      {
        label: 'طلب تعويض كامل وإلزام السائق بسداده (كسب 400 ج.م)',
        execute: (s) => ({
          outcome: 'استلمت التعويض لكن الموقف كان مشحوناً وأخذ وقتاً وتوتراً.',
          stateMod: {
            money: s.money + 220,
            energy: Math.max(0, s.energy - 15),
            mood: Math.max(0, s.mood - 8)
          }
        })
      }
    ]
  },
  {
    id: 'street_injured_kitten',
    category: 'city',
    title: '🐾 قطة صغيرة مصابة في مدخل العمارة',
    text: () => 'وجدت قطة صغيرة تعاني من كسر في ساقها وتموء بألم عند مدخل بيتك.',
    options: [
      {
        label: 'أخذها للعيادة البيطرية وعلاجها (120 ج.م)',
        description: 'عمل إنساني نبيل ينال إعجاب عائلتك',
        execute: (s) => ({
          outcome: 'تم تجبير ساق القطة وتعافت، وفرحت زوجتك وأولادك بهذا الموقف الرحيم.',
          stateMod: {
            money: Math.max(0, s.money - 120),
            love: Math.min(100, s.love + 5),
            familyMood: Math.min(100, s.familyMood + 10),
            mood: Math.min(100, s.mood + 12)
          }
        })
      },
      {
        label: 'وضع طبق لبن وطعام لها في الخارج',
        execute: () => ({
          outcome: 'أكلت القطة وسكن جوعها.',
          stateMod: {
            mood: Math.min(100, 75)
          }
        })
      }
    ]
  },
  {
    id: 'power_grid_blackout',
    category: 'crisis',
    title: '🕯️ انقطاع كهرباء مفاجئ في الحي',
    text: () => 'انقطعت الكهرباء عن الحي بالكامل في ليلة صيفية حارة، والإنترنت والمكيفات توقفت.',
    options: [
      {
        label: 'إشعال الشموع وجلسة سمر وحكايات عائلية دافئة',
        execute: (s) => ({
          outcome: 'تحولت الأزمة إلى أمسية من أجمل الأمسيات، ضحكتم وتحدثتم بعيداً عن شاشات الموبايل.',
          stateMod: {
            familyMood: Math.min(100, s.familyMood + 14),
            love: Math.min(100, s.love + 6),
            mood: Math.min(100, s.mood + 8)
          }
        })
      },
      {
        label: 'النزول لقضاء الوقت في مقهى مكيف بالشارع التجاري (70 ج.م)',
        execute: (s) => ({
          outcome: 'جلست في المقهى حتى عادت الكهرباء في وقت متأخر.',
          stateMod: {
            money: Math.max(0, s.money - 70)
          }
        })
      }
    ]
  },

  // ---------------- 4. UNDERWORLD & CRIME ENCOUNTERS ----------------
  {
    id: 'crime_recruiter_whisper',
    category: 'crime',
    title: '🕶️ عرض مالي مشبوه في مقهى شعبي',
    condition: (s) => s.path !== 'dark' && s.money < 1500,
    text: () => 'جلس بجوارك شخص ذو ملامح صارمة وقال بصوت خافت: "شكلك شاب محتاج وفيك عزم، الريس سعد عنده مهمة توصيل شنطة من غير أسئلة بـ 1,500 ج.م كاش الليلة.. تيجي؟"',
    options: [
      {
        label: 'اقبل العرض وادخل عالم الظلام (+1,500 ج.م)',
        execute: (s) => ({
          outcome: 'سلّمت الشنطة بنجاح واستلمت 1,500 ج.م، لكن اسمك الآن دخل سجلات العالم السفلي!',
          stateMod: {
            money: s.money + 1500,
            path: 'dark',
            gang: 1,
            heat: Math.min(100, s.heat + 15),
            suspicion: Math.min(100, s.suspicion + 10),
            cleanDays: 0
          }
        })
      },
      {
        label: 'ارفض بحزم: "أنا عايش بقرشي الحلال"',
        execute: (s) => ({
          outcome: 'غادر الرجل بصمت، وشعرت براحة ضمير واعتزاز بكرامتك.',
          stateMod: {
            rep: Math.min(100, s.rep + 4),
            cleanDays: s.cleanDays + 2,
            mood: Math.min(100, s.mood + 6)
          }
        })
      }
    ]
  },
  {
    id: 'rival_gang_threat',
    category: 'crime',
    title: '⚔️ تهديد مباشر من عصابة منافسة',
    condition: (s) => s.path === 'dark' && s.gang >= 2,
    text: () => 'حاصرك 3 رجال من عصابة المعلم فتوح في زقاق ضيق: "قول للريس سعد منطقتنا خط أحمر، ولازم تسلم 1,000 ج.م كضريبة عبور الآن!"',
    options: [
      {
        label: 'القتال والدفاع عن كرامتك وشرف العصابة',
        execute: (s) => {
          if (s.energy >= 40 && s.fitnessLevel >= 3) {
            return {
              outcome: 'بفضل لياقتك وقوتك البدنية تغلبت عليهم وفروا هاربين! ارتفعت هيبتك عند الريس سعد.',
              stateMod: {
                loyalty: Math.min(100, s.loyalty + 18),
                rep: Math.min(100, s.rep + 6),
                energy: Math.max(0, s.energy - 35)
              }
            };
          } else {
            return {
              outcome: 'تعرضت لإصابات وكدمات مؤلمة وأخذوا ما معك من نقود!',
              stateMod: {
                health: Math.max(0, s.health - 25),
                money: Math.max(0, s.money - 600),
                energy: Math.max(0, s.energy - 30)
              }
            };
          }
        }
      },
      {
        label: 'دفع 1,000 ج.م والانسحاب بهدوء لحماية حياتك',
        execute: (s) => ({
          outcome: 'انسحبت بسلام لكنك شعرت بمرارة الإهانة في هذا العالم الموحش.',
          stateMod: {
            money: Math.max(0, s.money - 1000),
            mood: Math.max(0, s.mood - 15)
          }
        })
      }
    ]
  },
  {
    id: 'police_search_warrant',
    category: 'crime',
    title: '🚨 المباحث تطرق باب شقتك!',
    condition: (s) => s.path === 'dark' && s.suspicion >= 50,
    text: (s) => `طرقات عنيفة على باب بيتك.. المفتش كريم يقف ومعه قوة تفتيش: "معانا إذن نيابة بتفتيش المسكن". نظرت ${s.partnerName} إليك برعب وصدمة!`,
    options: [
      {
        label: 'السماح لهم بالتفتيش ومحاولة إخفاء الأدلة بمهارة',
        execute: (s) => {
          if (Math.random() > 0.4) {
            return {
              outcome: 'لم يعثروا على شيء يدينك وغادروا، لكن ثقة زوجتك اهتزت بشدة!',
              stateMod: {
                suspicion: Math.max(0, s.suspicion - 15),
                trust: Math.max(0, s.trust - 25),
                partnerKnowsDark: true
              }
            };
          } else {
            return {
              outcome: 'عثروا على طرد مشبوه وتم اقتيادك للقسم فورياً!',
              stateMod: {
                jail: s.jail + 1,
                money: Math.max(0, s.money - 1200),
                trust: Math.max(0, s.trust - 40),
                partnerKnowsDark: true
              }
            };
          }
        }
      },
      {
        label: 'الاعتراف الكامل للمفتش وعقد صفقة توبة وحماية عائلتك',
        execute: (s) => ({
          outcome: 'أسقط المفتش الإجراءات مقابل خروجك النهائي من العصابة وتقديم معلومات أمنية.',
          stateMod: {
            path: 'clean',
            gang: 0,
            heat: 0,
            suspicion: 10,
            cleanDays: 1,
            trust: Math.min(100, s.trust + 5)
          }
        })
      }
    ]
  },
  // ---------------- 5. NEW EXPANDED CREATIVE DILEMMAS & EVENTS ----------------
  {
    id: 'partner_home_business',
    category: 'opportunity',
    title: '💡 فكرة مشروع منزلي من شريكتك',
    condition: (s) => (s.married || s.engaged) && s.money >= 500,
    text: (s) => `جلست معك ${s.partnerName} بحماس وعرضت عليك فكرة إطلاق مشروع أونلاين لصنع حلويات ومنتجات منزلية مميزة، وتحتاج تمويلاً بسيطاً بقيمة 800 ج.م لشراء الخامات والعبوات!`,
    options: [
      {
        label: 'ادعمها بالتمويل والتشجيع الكامل (800 ج.م)',
        description: 'استثمار عائلي يعزز المحبة وله عوائد ربحية ممتازة',
        execute: (s) => {
          const success = Math.random() > 0.3;
          const returnMoney = success ? 1750 : 600;
          return {
            outcome: success
              ? `نجح المشروع بشكل باهر! باعت كل المنتجات وحققت أرباحاً صافية وأعادت لك 1,750 ج.م مع قبلة امتنان!`
              : `واجه المشروع بعض التحديات لكنها باعت جزءاً واستردت 600 ج.م، وشكرتك من أعماق قلبها على وقفتك معها.`,
            stateMod: {
              money: s.money - 800 + returnMoney,
              love: Math.min(100, s.love + 15),
              trust: Math.min(100, s.trust + 10),
              familyMood: Math.min(100, s.familyMood + 12),
              mood: Math.min(100, s.mood + 10)
            }
          };
        }
      },
      {
        label: 'ساعدها في التسويق والتصميم مجاناً واقترح بداية بأقل تكلفة',
        description: 'يستهلك 15 طاقة بدون مصاريف مالية',
        execute: (s) => ({
          outcome: `صممت لها لوجو وإعلاناً لطيفاً، وأطلقت صفحة تجريبية حظيت بطلبات أولى مشجعة.`,
          stateMod: {
            love: Math.min(100, s.love + 8),
            energy: Math.max(0, s.energy - 15),
            skill: Math.min(100, s.skill + 3)
          }
        })
      },
      {
        label: 'الاعتذار بلطف وتأجيل الفكرة لحين استقرار الميزانية',
        description: 'لا مخاطرة مالية',
        execute: () => ({
          outcome: 'تفهمت موقفك وقررت تأجيل الفكرة لوقت لاحق.',
          stateMod: {}
        })
      }
    ]
  },
  {
    id: 'school_educational_camp',
    category: 'family',
    title: '🚌 رحلة ومخيم علمي مدرسي للأولاد',
    condition: (s) => s.children.length > 0 && s.children.some(c => c.ageDays >= 4),
    text: (s) => {
      const kid = s.children[0];
      return `أحضرت المدرسة استمارة اشتراك لـ ${kid.name} في مخيم علمي وتطوير مهارات الذكاء لمدة يومين، وتكلفة الاشتراك 260 ج.م.`;
    },
    options: [
      {
        label: 'الموافقة ودفع اشتراك المخيم (260 ج.م)',
        description: 'يرفع تعليم وانضباط وسعادة الطفل بشكل كبير',
        execute: (s) => {
          const kid = s.children[0];
          kid.education = Math.min(100, kid.education + 14);
          kid.discipline = Math.min(100, (kid.discipline || 70) + 10);
          return {
            outcome: `عاد ${kid.name} منبهرًا من المخيم، تعلم مهارات تفكير جديدة وحصل على ميدالية تفوق!`,
            stateMod: {
              money: Math.max(0, s.money - 260),
              familyMood: Math.min(100, s.familyMood + 15),
              mood: Math.min(100, s.mood + 10)
            }
          };
        }
      },
      {
        label: 'الاعتذار وتعويضه بنزهة عائلية بسيطة بالحديقة',
        execute: (s) => ({
          outcome: 'قضيتم يوماً عائلياً لطيفاً معاً بالحديقة بأقل التكاليف.',
          stateMod: {
            familyMood: Math.min(100, s.familyMood + 6)
          }
        })
      }
    ]
  },
  {
    id: 'charity_food_drive',
    category: 'city',
    title: '🍲 مائدة إطعام وكفالة أسر محتاجة',
    text: () => 'مبادرة خيرية من شباب الحي لتجهيز كراتين طعام وإطعام الأسر المتعففة وكبار السن.',
    options: [
      {
        label: 'التبرع بمبلغ 200 ج.م والمشاركة في التوزيع',
        description: 'بركة وسمعة طيبة وراحة نفسية عميقة',
        execute: (s) => ({
          outcome: 'شاركت بمالك وجهدك في إدخال السرور على أهالي منطقتك، وشعرت بسكينة ورضا عظيم وارتفعت سمعتك في الحي.',
          stateMod: {
            money: Math.max(0, s.money - 200),
            rep: Math.min(100, s.rep + 8),
            mood: Math.min(100, s.mood + 18),
            energy: Math.max(0, s.energy - 10)
          }
        })
      },
      {
        label: 'التطوع بالجهد البدني فقط لمدة ساعتين',
        description: 'بدون تكلفة مالية',
        execute: (s) => ({
          outcome: 'ساعدت في تنظيم الكراتين وحملها ونلت شكر ودعوات الجميع.',
          stateMod: {
            rep: Math.min(100, s.rep + 5),
            mood: Math.min(100, s.mood + 12),
            energy: Math.max(0, s.energy - 18)
          }
        })
      }
    ]
  },
  {
    id: 'building_elevator_dispute',
    category: 'city',
    title: '🏢 أزمة مصعد العمارة وخلاف الجيران',
    condition: (s) => s.assets.includes('flat') || s.assets.includes('home'),
    text: () => 'تعطل أسانسير العمارة واحتدم النقاش بين السكان حول دفع تكلفة الصيانة الشاملة، وطلب الجيران رأيك لكونك شخصاً موثوقاً.',
    options: [
      {
        label: 'قيادة مبادرة الحل والتفاوض مع شركة الصيانة (دفع حصتك 250 ج.م)',
        execute: (s) => ({
          outcome: 'أصلحت الأسانسير بسعر ممتاز وأشاد كل سكان العمارة بحكمتك وحسن إدارتك للموقف!',
          stateMod: {
            money: Math.max(0, s.money - 250),
            rep: Math.min(100, s.rep + 10),
            mood: Math.min(100, s.mood + 8)
          }
        })
      },
      {
        label: 'دفع حصتك المقررة بصمت دون التدخل في الشجار (250 ج.م)',
        execute: (s) => ({
          outcome: 'دفعت نصيبك وانتهى الخلاف بعد أيام.',
          stateMod: {
            money: Math.max(0, s.money - 250)
          }
        })
      }
    ]
  },
  {
    id: 'underworld_customs_tip',
    category: 'crime',
    title: '📦 شحنة أجهزة جمركية مهربة عالية القيمة',
    condition: (s) => s.path === 'dark' && s.gang >= 1,
    text: () => 'تلقيت معلومة من داخل الميناء عن حاوية بضائع إلكترونية لم يتم تسجيلها، وعرض عليك الشركاء بيعها واقتسام الغنيمة!',
    options: [
      {
        label: 'تنظيم العملية وتصريف البضاعة في السوق السوداء',
        description: 'مكسب ضخم جداً لكن الشبهات والخطورة عالية للغاية',
        execute: (s) => {
          if (Math.random() > 0.45) {
            return {
              outcome: 'نجحت الصفقة بدهاء وحصلت على حصة صافية بلغت 4,800 ج.م!',
              stateMod: {
                money: s.money + 4800,
                heat: Math.min(100, s.heat + 25),
                suspicion: Math.min(100, s.suspicion + 20),
                energy: Math.max(0, s.energy - 30)
              }
            };
          } else {
            return {
              outcome: 'داهمت فرقة مكافحة التهريب المستودع، هربت بأعجوبة لكن صودرت البضاعة وطوردت!',
              stateMod: {
                heat: Math.min(100, s.heat + 40),
                suspicion: Math.min(100, s.suspicion + 30),
                energy: 20,
                health: Math.max(0, s.health - 20)
              }
            };
          }
        }
      },
      {
        label: 'الرفض والابتعاد: "المخاطرة الجمركية ثمنها السجن المشدد"',
        execute: () => ({
          outcome: 'نجوت بنفسك، وتبين لاحقاً أن المباحث ضبطت كل من تورط فيها.',
          stateMod: {
            mood: Math.min(100, 80)
          }
        })
      }
    ]
  }
];

export function getEligibleRandomEvent(state: GameState): RandomEventDef | null {
  const eligible = RANDOM_EVENTS_POOL.filter(ev => !ev.condition || ev.condition(state));
  if (!eligible.length) return null;
  return eligible[Math.floor(Math.random() * eligible.length)];
}
