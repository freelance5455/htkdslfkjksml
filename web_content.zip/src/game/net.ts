/* WebRTC data-channel link with QR-friendly compact signalling (works on a local network without internet). */

function toB64(hex: string) {
  const bytes = hex.split(':').map(h => parseInt(h, 16));
  return btoa(String.fromCharCode(...bytes)).replace(/=+$/, '');
}
function fromB64(s: string) {
  const bin = atob(s); return Array.from(bin, c => c.charCodeAt(0).toString(16).padStart(2, '0').toUpperCase()).join(':');
}
const SETUP: Record<string, string> = { actpass: 'x', active: 'a', passive: 'p' };
const SETUP_R: Record<string, string> = { x: 'actpass', a: 'active', p: 'passive' };

export function compressSdp(sdp: string): string {
  const g = (re: RegExp) => { const m = re.exec(sdp); if (!m) throw new Error('sdp'); return m[1]; };
  const cands: string[] = [];
  for (const m of sdp.matchAll(/a=candidate:\S+ \d+ udp \d+ (\S+) (\d+) typ host/g)) if (!m[1].includes(':')) cands.push(`${m[1]}:${m[2]}`);
  if (!cands.length) throw new Error('nocand');
  return ['1', g(/a=ice-ufrag:(\S+)/), g(/a=ice-pwd:(\S+)/), toB64(g(/a=fingerprint:sha-256 (\S+)/)), SETUP[g(/a=setup:(\S+)/)] || 'a', cands.join(';')].join('|');
}
export function expandSdp(code: string): string {
  const [v, u, p, fp, st, cs] = code.trim().split('|'); if (v !== '1' || !cs) throw new Error('bad');
  const lines = ['v=0', 'o=- 4611731400430051336 2 IN IP4 127.0.0.1', 's=-', 't=0 0', 'a=group:BUNDLE 0', 'a=msid-semantic: WMS', 'm=application 9 UDP/DTLS/SCTP webrtc-datachannel', 'c=IN IP4 0.0.0.0',
    'a=ice-ufrag:' + u, 'a=ice-pwd:' + p, 'a=fingerprint:sha-256 ' + fromB64(fp), 'a=setup:' + (SETUP_R[st] || 'active'), 'a=mid:0', 'a=sctp-port:5000', 'a=max-message-size:262144'];
  cs.split(';').forEach((c, i) => { const k = c.lastIndexOf(':'); lines.push(`a=candidate:${i + 1} 1 udp ${2113937151 - i * 256} ${c.slice(0, k)} ${c.slice(k + 1)} typ host generation 0`); });
  return lines.join('\r\n') + '\r\n';
}
function gather(pc: RTCPeerConnection) {
  return new Promise<void>(res => {
    if (pc.iceGatheringState === 'complete') return res();
    const t = setTimeout(() => res(), 3500);
    pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } });
  });
}
/** Ask for camera once so the browser exposes real LAN IPs (instead of mDNS names) and so scanning is allowed. */
export async function primeCamera() {
  try { const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); s.getTracks().forEach(t => t.stop()); return true; } catch { return false; }
}

export class Link {
  pc: RTCPeerConnection; dc: RTCDataChannel; onmsg: (m: any) => void = () => { }; onopen: () => void = () => { }; onclose: () => void = () => { }; closed = false;
  constructor() {
    this.pc = new RTCPeerConnection({ iceServers: [] });
    this.dc = this.pc.createDataChannel('g', { negotiated: true, id: 0 });
    this.dc.onopen = () => this.onopen();
    this.dc.onclose = () => this.fireClose();
    this.dc.onmessage = e => { try { this.onmsg(JSON.parse(e.data)); } catch { /* ignore */ } };
    this.pc.onconnectionstatechange = () => { if (['failed', 'disconnected', 'closed'].includes(this.pc.connectionState)) this.fireClose(); };
  }
  private fireClose() { if (this.closed) return; this.closed = true; this.onclose(); }
  get open() { return this.dc.readyState === 'open'; }
  get buffered() { return this.dc.bufferedAmount; }
  send(m: any) { if (this.dc.readyState === 'open') { try { this.dc.send(typeof m === 'string' ? m : JSON.stringify(m)); } catch { /* ignore */ } } }
  async makeOffer() { const o = await this.pc.createOffer(); await this.pc.setLocalDescription(o); await gather(this.pc); return compressSdp(this.pc.localDescription!.sdp); }
  async acceptAnswer(code: string) { await this.pc.setRemoteDescription({ type: 'answer', sdp: expandSdp(code) }); }
  async makeAnswer(offer: string) {
    await this.pc.setRemoteDescription({ type: 'offer', sdp: expandSdp(offer) });
    const a = await this.pc.createAnswer(); await this.pc.setLocalDescription(a); await gather(this.pc); return compressSdp(this.pc.localDescription!.sdp);
  }
  close() { this.closed = true; try { this.dc.close(); } catch { /* ignore */ } try { this.pc.close(); } catch { /* ignore */ } }
}
