import { useEffect, useLayoutEffect, useMemo, useRef, type ReactNode } from "react";
import * as THREE from "three";
import { useFrame, useThree } from "@react-three/fiber";
import {
  COTTAGE,
  DECOR,
  FIRE,
  ISLAND_R,
  NIA,
  NODES,
  PADS,
  PAL,
  POND,
  SPAWN,
  STARTERS,
  SPECIES,
  daylight,
  type Decor,
} from "./data";
import {
  BerryBush,
  HarvestRock,
  HarvestTree,
  KeeperModel,
  PalModel,
  PlayerModel,
} from "./models";
import { frame, getSim, type Sim } from "./sim";
import { useHud } from "./store";

const _desired = new THREE.Vector3();
const _look = new THREE.Vector3();
const _dummy = new THREE.Object3D();
const _fogA = new THREE.Color(PAL.skyNight);
const _fogB = new THREE.Color(PAL.skyFog);
const _dayTop = new THREE.Color("#6eb6e0");
const _nightTop = new THREE.Color(PAL.nightTop);
const _dayHor = new THREE.Color("#f3e2c4");
const _nightHor = new THREE.Color("#2a3c55");
const _sunCool = new THREE.Color("#9bb4d2");
const _sunWarm = new THREE.Color("#fff1d2");
const _col = new THREE.Color();

const palRefs = new Map<number, THREE.Group>();

function grassTexture() {
  const s = 1024;
  const c = document.createElement("canvas");
  c.width = s;
  c.height = s;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = "#67b255";
  g.fillRect(0, 0, s, s);
  for (let i = 0; i < 420; i += 1) {
    const x = Math.random() * s;
    const y = Math.random() * s;
    const r = 18 + Math.random() * 80;
    g.fillStyle = Math.random() > 0.5 ? "rgba(86,150,58,0.38)" : "rgba(140,196,86,0.28)";
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  for (let i = 0; i < 1800; i += 1) {
    g.fillStyle = Math.random() > 0.55 ? "rgba(40,90,36,0.22)" : "rgba(236,224,150,0.13)";
    g.fillRect(Math.random() * s, Math.random() * s, 2, 3);
  }
  const glow = g.createRadialGradient(s / 2, s / 2, 30, s / 2, s / 2, s * 0.28);
  glow.addColorStop(0, "rgba(176,214,104,0.5)");
  glow.addColorStop(1, "rgba(176,214,104,0)");
  g.fillStyle = glow;
  g.fillRect(0, 0, s, s);
  const shore = g.createRadialGradient(s / 2, s / 2, s * 0.36, s / 2, s / 2, s * 0.5);
  shore.addColorStop(0, "rgba(0,0,0,0)");
  shore.addColorStop(1, "rgba(214,186,122,0.9)");
  g.fillStyle = shore;
  g.fillRect(0, 0, s, s);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

const skyVert = `
  varying vec3 vPos;
  void main() {
    vPos = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
const skyFrag = `
  varying vec3 vPos;
  uniform vec3 uTop;
  uniform vec3 uHorizon;
  void main() {
    float h = normalize(vPos).y;
    float t = smoothstep(-0.05, 0.55, h);
    gl_FragColor = vec4(mix(uHorizon, uTop, t), 1.0);
  }
`;
const waterVert = `
  uniform float uTime;
  varying vec2 vUv;
  void main() {
    vUv = uv;
    vec3 p = position;
    p.z += sin(position.x * 0.28 + uTime * 1.3) * cos(position.y * 0.24 + uTime * 0.9) * 0.07;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;
const waterFrag = `
  uniform float uTime;
  varying vec2 vUv;
  void main() {
    float rip = 0.5 + 0.5 * sin(vUv.x * 40.0 + uTime) * sin(vUv.y * 36.0 - uTime * 0.8);
    vec3 deep = vec3(0.12, 0.42, 0.58);
    vec3 lite = vec3(0.55, 0.82, 0.86);
    vec3 col = mix(deep, lite, rip * 0.35 + 0.1);
    gl_FragColor = vec4(col, 0.92);
  }
`;

function Instanced({
  items,
  yOf,
  color,
  children,
  cast = false,
}: {
  items: Decor[];
  yOf: (d: Decor) => number;
  color: string;
  children: ReactNode;
  cast?: boolean;
}) {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    items.forEach((d, i) => {
      _dummy.position.set(d.x, yOf(d), d.z);
      _dummy.rotation.set(0, d.ry, 0);
      _dummy.scale.setScalar(d.s);
      _dummy.updateMatrix();
      mesh.setMatrixAt(i, _dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
  }, [items, yOf]);
  if (!items.length) return null;
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, items.length]} castShadow={cast} receiveShadow>
      {children}
      <meshStandardMaterial color={color} roughness={0.9} />
    </instancedMesh>
  );
}

function Island() {
  const tex = useMemo(() => grassTexture(), []);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.04, 0]} receiveShadow>
        <circleGeometry args={[ISLAND_R + 6, 64]} />
        <meshStandardMaterial color={PAL.sand} roughness={1} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]} receiveShadow>
        <circleGeometry args={[ISLAND_R, 72]} />
        <meshStandardMaterial map={tex ?? undefined} roughness={1} />
      </mesh>
    </group>
  );
}

function Water() {
  const mat = useRef<THREE.ShaderMaterial>(null);
  useFrame(() => {
    if (mat.current) mat.current.uniforms.uTime.value = getSim().time;
  });
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.16, 0]}>
      <circleGeometry args={[150, 48]} />
      <shaderMaterial
        ref={mat}
        transparent
        vertexShader={waterVert}
        fragmentShader={waterFrag}
        uniforms={{ uTime: { value: 0 } }}
      />
    </mesh>
  );
}

function SkyDome() {
  const mat = useRef<THREE.ShaderMaterial>(null);
  const uniforms = useMemo(
    () => ({
      uTop: { value: _dayTop.clone() },
      uHorizon: { value: _dayHor.clone() },
    }),
    [],
  );
  useFrame(() => {
    const k = daylight(getSim().day);
    const m = mat.current;
    if (!m) return;
    (m.uniforms.uTop.value as THREE.Color).copy(_nightTop).lerp(_dayTop, k);
    (m.uniforms.uHorizon.value as THREE.Color).copy(_nightHor).lerp(_dayHor, k);
  });
  return (
    <mesh frustumCulled={false}>
      <sphereGeometry args={[90, 24, 16]} />
      <shaderMaterial ref={mat} side={THREE.BackSide} vertexShader={skyVert} fragmentShader={skyFrag} uniforms={uniforms} />
    </mesh>
  );
}

function DecorField() {
  const trees = useMemo(() => DECOR.filter((d) => d.kind === "tree"), []);
  const pines = useMemo(() => DECOR.filter((d) => d.kind === "pine"), []);
  const rocks = useMemo(() => DECOR.filter((d) => d.kind === "rock"), []);
  const flowersA = useMemo(() => DECOR.filter((d) => d.kind === "flower" && d.tint < 0.55), []);
  const flowersB = useMemo(() => DECOR.filter((d) => d.kind === "flower" && d.tint >= 0.55), []);
  const reeds = useMemo(() => DECOR.filter((d) => d.kind === "reed"), []);
  const crates = useMemo(() => DECOR.filter((d) => d.kind === "crate"), []);
  const trunkY = useMemo(() => (d: Decor) => 0.45 * d.s, []);
  const canopyY = useMemo(() => (d: Decor) => 1.15 * d.s, []);
  const rockY = useMemo(() => (d: Decor) => 0.22 * d.s, []);
  const flowerY = useMemo(() => () => 0.12, []);
  const reedY = useMemo(() => (d: Decor) => 0.35 * d.s, []);
  return (
    <group>
      <Instanced items={trees} yOf={trunkY} color={PAL.wood}>
        <cylinderGeometry args={[0.14, 0.18, 0.9, 6]} />
      </Instanced>
      <Instanced items={trees} yOf={canopyY} color={PAL.leaf}>
        <sphereGeometry args={[0.55, 8, 7]} />
      </Instanced>
      <Instanced items={pines} yOf={trunkY} color={PAL.woodDark}>
        <cylinderGeometry args={[0.1, 0.16, 0.8, 6]} />
      </Instanced>
      <Instanced items={pines} yOf={canopyY} color={PAL.mossDeep}>
        <coneGeometry args={[0.55, 1.3, 7]} />
      </Instanced>
      <Instanced items={rocks} yOf={rockY} color={PAL.stone}>
        <dodecahedronGeometry args={[0.45, 0]} />
      </Instanced>
      <Instanced items={flowersA} yOf={flowerY} color={PAL.cream}>
        <sphereGeometry args={[0.12, 6, 5]} />
      </Instanced>
      <Instanced items={flowersB} yOf={flowerY} color={PAL.amber}>
        <sphereGeometry args={[0.1, 6, 5]} />
      </Instanced>
      <Instanced items={reeds} yOf={reedY} color={PAL.leafLite}>
        <cylinderGeometry args={[0.03, 0.04, 0.7, 5]} />
      </Instanced>
      {crates.map((d) => (
        <mesh key={`${d.x}-${d.z}`} position={[d.x, 0.22 * d.s, d.z]} rotation={[0, d.ry, 0]} scale={d.s} castShadow>
          <boxGeometry args={[0.46, 0.42, 0.46]} />
          <meshStandardMaterial color={PAL.wood} roughness={0.85} />
        </mesh>
      ))}
    </group>
  );
}

function Cottage() {
  return (
    <group position={[COTTAGE.x, 0, COTTAGE.z]}>
      <mesh position={[0, 0.7, 0]} castShadow receiveShadow>
        <boxGeometry args={[3.3, 1.4, 2.5]} />
        <meshStandardMaterial color={PAL.creamDeep} roughness={0.88} />
      </mesh>
      <mesh position={[0, 1.7, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
        <coneGeometry args={[2.35, 1.15, 4]} />
        <meshStandardMaterial color={PAL.wood} roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.45, 1.28]}>
        <boxGeometry args={[0.55, 0.9, 0.08]} />
        <meshStandardMaterial color={PAL.woodDark} />
      </mesh>
      <mesh position={[-0.85, 0.85, 1.27]}>
        <boxGeometry args={[0.42, 0.42, 0.06]} />
        <meshStandardMaterial color={PAL.glow} emissive={PAL.amber} emissiveIntensity={0.45} />
      </mesh>
      <mesh position={[1.15, 0.2, 0.4]} castShadow>
        <boxGeometry args={[0.7, 0.4, 0.7]} />
        <meshStandardMaterial color={PAL.stone} />
      </mesh>
      <mesh position={[1.15, 1.55, 0.4]}>
        <boxGeometry args={[0.28, 0.7, 0.28]} />
        <meshStandardMaterial color={PAL.stoneLite} />
      </mesh>
      {[-1.8, 1.8].map((x) =>
        [-1.4, 1.4].map((z) => (
          <mesh key={`${x}-${z}`} position={[x, 0.35, z]} castShadow>
            <cylinderGeometry args={[0.06, 0.08, 0.7, 6]} />
            <meshStandardMaterial color={PAL.woodDark} />
          </mesh>
        )),
      )}
    </group>
  );
}

function Campfire() {
  const flame = useRef<THREE.Mesh>(null);
  const light = useRef<THREE.PointLight>(null);
  useFrame(() => {
    const sim = getSim();
    const k = 1 - daylight(sim.day);
    if (flame.current) {
      const s = 0.85 + Math.sin(sim.time * 14) * 0.12;
      flame.current.scale.set(1, s, 1);
    }
    if (light.current) light.current.intensity = 0.6 + k * 2.4 + Math.sin(sim.time * 16) * 0.25;
  });
  return (
    <group position={[FIRE.x, 0, FIRE.z]}>
      <mesh rotation={[0, 0.4, Math.PI / 2]} position={[0, 0.12, 0]} castShadow>
        <cylinderGeometry args={[0.08, 0.1, 0.7, 6]} />
        <meshStandardMaterial color={PAL.woodDark} />
      </mesh>
      <mesh rotation={[0, 1.2, Math.PI / 2]} position={[0, 0.16, 0]} castShadow>
        <cylinderGeometry args={[0.07, 0.09, 0.62, 6]} />
        <meshStandardMaterial color={PAL.wood} />
      </mesh>
      <mesh ref={flame} position={[0, 0.48, 0]}>
        <coneGeometry args={[0.16, 0.42, 7]} />
        <meshBasicMaterial color={PAL.amber} />
      </mesh>
      <mesh position={[0, 0.62, 0]}>
        <coneGeometry args={[0.08, 0.22, 6]} />
        <meshBasicMaterial color={PAL.glow} />
      </mesh>
      <pointLight ref={light} position={[0, 1.1, 0]} color={PAL.amber} distance={9} decay={2} />
    </group>
  );
}

function Nodes() {
  const refs = useRef<(THREE.Group | null)[]>([]);
  useFrame(() => {
    const nodes = getSim().nodes;
    nodes.forEach((n, i) => {
      const g = refs.current[i];
      if (!g) return;
      g.visible = n.amount > 0;
      g.position.set(n.x, 0, n.z);
      g.rotation.y = n.kind === "wood" ? getSim().time * 0.4 : 0;
    });
  });
  return (
    <group>
      {NODES.map((n, i) => (
        <group key={`${n.kind}-${i}`} ref={(el) => { refs.current[i] = el; }}>
          {n.kind === "wood" ? <HarvestTree /> : n.kind === "stone" ? <HarvestRock /> : <BerryBush />}
        </group>
      ))}
    </group>
  );
}

function BuildingMesh({ id }: { id: number }) {
  const blades = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (blades.current) blades.current.rotation.y += dt * 1.5;
  });
  const b = getSim().buildings.find((item) => item.id === id);
  if (!b) return null;
  const pad = PADS[b.pad];
  if (!pad) return null;
  return (
    <group position={[pad.x, 0, pad.z]}>
      {b.type === "garden" && (
        <group>
          <mesh position={[0, 0.12, 0]} receiveShadow>
            <boxGeometry args={[1.8, 0.22, 1.3]} />
            <meshStandardMaterial color={PAL.wood} />
          </mesh>
          <mesh position={[0, 0.28, 0]}>
            <boxGeometry args={[1.55, 0.12, 1.05]} />
            <meshStandardMaterial color={PAL.woodDark} />
          </mesh>
          {[-0.4, 0, 0.4].map((x) => (
            <mesh key={x} position={[x, 0.5, 0]}>
              <coneGeometry args={[0.12, 0.32, 6]} />
              <meshStandardMaterial color={PAL.leafLite} />
            </mesh>
          ))}
        </group>
      )}
      {b.type === "mill" && (
        <group>
          <mesh position={[0, 0.7, 0]} castShadow>
            <cylinderGeometry args={[0.18, 0.28, 1.4, 8]} />
            <meshStandardMaterial color={PAL.creamDeep} />
          </mesh>
          <group ref={blades} position={[0, 1.45, 0]}>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} rotation={[0, 0, (i * Math.PI) / 2]} position={[0.45, 0, 0]}>
                <boxGeometry args={[0.9, 0.12, 0.06]} />
                <meshStandardMaterial color={PAL.wood} />
              </mesh>
            ))}
          </group>
        </group>
      )}
      {b.type === "kiln" && (
        <group>
          <mesh position={[0, 0.45, 0]} castShadow>
            <cylinderGeometry args={[0.55, 0.7, 0.9, 8]} />
            <meshStandardMaterial color={PAL.stone} />
          </mesh>
          <mesh position={[0, 0.95, 0]}>
            <cylinderGeometry args={[0.28, 0.4, 0.3, 8]} />
            <meshStandardMaterial color={PAL.stoneLite} />
          </mesh>
          <mesh position={[0, 0.55, 0.62]}>
            <circleGeometry args={[0.16, 10]} />
            <meshBasicMaterial color={PAL.ember} />
          </mesh>
        </group>
      )}
      {b.type === "nest" && (
        <group>
          <mesh position={[0, 0.35, 0]} scale={[1.2, 0.55, 1.2]} castShadow>
            <sphereGeometry args={[0.7, 16, 12]} />
            <meshStandardMaterial color={PAL.wood} roughness={1} />
          </mesh>
          <mesh position={[0, 0.55, 0]}>
            <sphereGeometry args={[0.22, 12, 10]} />
            <meshStandardMaterial color={PAL.cream} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function Buildings() {
  const rev = useHud((s) => s.rosterRev);
  void rev;
  const list = getSim().buildings;
  return (
    <group>
      {list.map((b) => (
        <BuildingMesh key={b.id} id={b.id} />
      ))}
    </group>
  );
}

function PalView({ id, species }: { id: number; species: Sim["pals"][number]["species"] }) {
  return (
    <group
      ref={(el) => {
        if (el) palRefs.set(id, el);
        else palRefs.delete(id);
      }}
    >
      <PalModel species={species} />
    </group>
  );
}

function Pals() {
  const rev = useHud((s) => s.rosterRev);
  void rev;
  const list = getSim().pals.filter((p) => p.alive);
  return (
    <group>
      {list.map((p) => (
        <PalView key={p.id} id={p.id} species={p.species} />
      ))}
    </group>
  );
}

function Orbs() {
  const refs = useRef<(THREE.Mesh | null)[]>([]);
  useFrame(() => {
    const list = getSim().projs;
    for (let i = 0; i < 4; i += 1) {
      const m = refs.current[i];
      const p = list[i];
      if (!m) continue;
      if (!p || !p.alive) {
        m.visible = false;
        continue;
      }
      m.visible = true;
      m.position.set(p.x, p.y, p.z);
    }
  });
  return (
    <group>
      {Array.from({ length: 4 }, (_, i) => (
        <mesh key={i} ref={(el) => { refs.current[i] = el; }} visible={false}>
          <sphereGeometry args={[0.16, 16, 14]} />
          <meshStandardMaterial color={PAL.glow} emissive={PAL.amber} emissiveIntensity={0.85} roughness={0.28} />
        </mesh>
      ))}
    </group>
  );
}

function TargetRing() {
  const ref = useRef<THREE.Mesh>(null);
  useFrame(() => {
    const sim = getSim();
    const m = ref.current;
    if (!m) return;
    const t = sim.pals.find((p) => p.id === sim.targetId && p.alive && p.wild);
    if (!t || sim.mode !== "play") {
      m.visible = false;
      return;
    }
    m.visible = true;
    m.position.set(t.x, 0.06, t.z);
    const pulse = 1 + Math.sin(sim.time * 6) * 0.06;
    m.scale.setScalar(pulse);
  });
  return (
    <mesh ref={ref} rotation={[-Math.PI / 2, 0, 0]} visible={false}>
      <ringGeometry args={[0.55, 0.72, 28]} />
      <meshBasicMaterial color={PAL.amber} transparent opacity={0.9} side={THREE.DoubleSide} />
    </mesh>
  );
}

function Sparks() {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => new Float32Array(180 * 3), []);
  useFrame(() => {
    const pts = getSim().particles;
    for (let i = 0; i < 180; i += 1) {
      const p = pts[i];
      if (!p) {
        positions[i * 3 + 1] = -50;
        continue;
      }
      positions[i * 3] = p.x;
      positions[i * 3 + 1] = p.y;
      positions[i * 3 + 2] = p.z;
    }
    const attr = ref.current?.geometry.attributes.position;
    if (attr) attr.needsUpdate = true;
  });
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color={PAL.glow} size={0.12} transparent depthWrite={false} />
    </points>
  );
}

function Showcase() {
  const refs = useRef<(THREE.Group | null)[]>([]);
  useFrame(() => {
    const sim = getSim();
    const show = sim.mode === "title";
    const preview = useHud.getState().preview;
    STARTERS.forEach((id, i) => {
      const g = refs.current[i];
      if (!g) return;
      g.visible = show;
      if (!show) return;
      const base = i === 0 ? [-1.2, -4.2] : i === 1 ? [2.3, -3.2] : [0.5, -6.1];
      const bob = Math.sin(sim.time * 2.2 + i) * 0.08;
      g.position.set(base[0] ?? 0, bob, base[1] ?? 0);
      g.rotation.y = sim.titleYaw;
      const s = (preview === id ? 1.18 : 0.92) * (1 + Math.sin(sim.time * 3 + i) * 0.02);
      g.scale.setScalar(s);
    });
  });
  return (
    <group>
      {STARTERS.map((id, i) => (
        <group key={id} ref={(el) => { refs.current[i] = el; }}>
          <PalModel species={id} />
        </group>
      ))}
    </group>
  );
}

function syncPal(sim: Sim, pal: Sim["pals"][number]) {
  const g = palRefs.get(pal.id);
  if (!g) return;
  if (!pal.alive || sim.mode !== "play") {
    g.visible = false;
    return;
  }
  g.visible = true;
  const spec = SPECIES[pal.species];
  const specHop = pal.speed > 0.5 ? 10 : 3;
  const hop = Math.abs(Math.sin(sim.time * specHop + pal.id)) * (pal.speed > 0.5 ? 0.07 : 0.02);
  const hover = spec.hover ? 0.7 + Math.sin(sim.time * 2.3 + pal.id) * 0.08 : 0;
  let s = spec.scale;
  if (pal.shrink > 0) s *= Math.max(0.04, pal.shrink / 0.4);
  if (pal.faint > 0) s *= Math.max(0.04, pal.faint / 0.48);
  const scale = s;
  g.scale.setScalar(scale);
  g.position.set(pal.x, hover + hop * s, pal.z);
  g.rotation.y = pal.yaw + Math.PI;
  const flash = g.getObjectByName("flash") as THREE.Mesh | undefined;
  if (flash) {
    const mat = flash.material as THREE.MeshBasicMaterial;
    mat.opacity = pal.flash > 0 ? 0.7 : 0;
  }
  const hp = g.getObjectByName("hp");
  if (hp) {
    hp.visible = pal.wild && pal.hp < pal.maxHp - 0.5;
    hp.rotation.y = sim.camYaw - (pal.yaw + Math.PI);
    const fill = hp.getObjectByName("fill") as THREE.Mesh | undefined;
    if (fill) {
      const k = Math.max(0.04, pal.hp / pal.maxHp);
      fill.scale.x = k;
      fill.position.x = -0.38 * (1 - k);
    }
  }
  const wingL = g.getObjectByName("wingL");
  const wingR = g.getObjectByName("wingR");
  if (wingL && wingR) {
    const flap = Math.sin(sim.time * 8 + pal.id) * 0.5;
    wingL.rotation.z = flap;
    wingR.rotation.z = -flap;
  }
}

function Sync() {
  const camera = useThree((s) => s.camera);
  const scene = useThree((s) => s.scene);
  const player = useRef<THREE.Group>(null);
  const sun = useRef<THREE.DirectionalLight>(null);
  useFrame((_, delta) => {
    const sim = getSim();
    frame(sim, delta);
    const title = sim.mode === "title";
    const yaw = title ? sim.titleYaw : sim.camYaw;
    const fx = title ? -0.6 : sim.player.x;
    const fz = title ? -4.2 : sim.player.z;
    const dist = title ? 15.5 : 12.4;
    const height = title ? 8.8 : 8.5;
    _desired.set(fx + Math.sin(yaw) * dist, height, fz + Math.cos(yaw) * dist);
    const blend = 1 - Math.exp(-4.4 * Math.min(delta, 0.1));
    camera.position.lerp(_desired, blend);
    _look.set(fx, title ? 0.7 : 1.15, fz);
    camera.lookAt(_look);
    if (sim.shake > 0 && !title) {
      camera.position.x += Math.sin(sim.time * 73) * sim.shake * 0.25;
      camera.position.y += Math.cos(sim.time * 57) * sim.shake * 0.18;
      sim.shake = Math.max(0, sim.shake - delta * 1.5);
    }
    const k = daylight(sim.day);
    const fog = scene.fog as THREE.Fog | null;
    if (fog) fog.color.copy(_fogA).lerp(_fogB, k);
    if (sun.current) {
      const px = title ? -1 : sim.player.x;
      const pz = title ? -4 : sim.player.z;
      sun.current.intensity = 0.18 + k * 1.35;
      sun.current.position.set(px + 11, 8 + k * 12, pz + 6);
      sun.current.target.position.set(px, 0, pz);
      sun.current.target.updateMatrixWorld();
      _col.copy(_sunCool).lerp(_sunWarm, k);
      sun.current.color.copy(_col);
    }
    const body = player.current;
    if (body) {
      body.visible = !title;
      const lunge = sim.player.lunge > 0 ? Math.sin(((0.18 - sim.player.lunge) / 0.18) * Math.PI) * 0.32 : 0;
      const fxv = -Math.sin(sim.player.yaw);
      const fzv = -Math.cos(sim.player.yaw);
      body.position.set(sim.player.x + fxv * lunge, 0, sim.player.z + fzv * lunge);
      body.rotation.y = sim.player.yaw + Math.PI;
      const swing = Math.sin(sim.time * 9.5) * Math.min(0.65, sim.player.speed * 0.085);
      const legL = body.getObjectByName("legL");
      const legR = body.getObjectByName("legR");
      const armL = body.getObjectByName("armL");
      const armR = body.getObjectByName("armR");
      if (legL && legR && armL && armR) {
        legL.rotation.x = swing;
        legR.rotation.x = -swing;
        armL.rotation.x = -swing * 0.7;
        armR.rotation.x = sim.player.lunge > 0 ? -0.8 : swing * 0.7;
      }
      const flash = body.getObjectByName("flash") as THREE.Mesh | undefined;
      if (flash) {
        const mat = flash.material as THREE.MeshBasicMaterial;
        mat.opacity = sim.player.iframes > 0.35 ? 0.45 : 0;
      }
    }
    for (const pal of sim.pals) syncPal(sim, pal);
    const arm = scene.getObjectByName("niaArm");
    if (arm) arm.rotation.x = Math.sin(sim.time * 2) * 0.35;
  });
  const niaYaw = Math.atan2(-(SPAWN.x - NIA.x), -(SPAWN.z - NIA.z));
  return (
    <group>
      <directionalLight
        ref={sun}
        name="sun"
        castShadow
        position={[12, 18, 8]}
        intensity={1.2}
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-near={1}
        shadow-camera-far={48}
        shadow-camera-left={-16}
        shadow-camera-right={16}
        shadow-camera-top={16}
        shadow-camera-bottom={-16}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
      />
      <group ref={player}>
        <PlayerModel />
      </group>
      <group position={[NIA.x, 0, NIA.z]} rotation={[0, niaYaw + Math.PI, 0]}>
        <KeeperModel />
      </group>
    </group>
  );
}

function LookDrag() {
  const gl = useThree((s) => s.gl);
  useEffect(() => {
    const el = gl.domElement;
    const down = (e: PointerEvent) => {
      if (e.button !== 2 && e.button !== 1) return;
      const stage = el.closest(".game-stage");
      const angle = (Number(stage?.getAttribute("data-rot") ?? "0") * Math.PI) / 180;
      const move = (ev: PointerEvent) => {
        const cos = Math.cos(-angle);
        const sin = Math.sin(-angle);
        const dx = ev.movementX * cos - ev.movementY * sin;
        const sim = getSim();
        if (sim.mode === "title") sim.titleYaw -= dx * 0.005;
        else {
          sim.camYaw -= dx * 0.005;
          sim.autoCam = false;
        }
      };
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    };
    el.addEventListener("pointerdown", down);
    return () => el.removeEventListener("pointerdown", down);
  }, [gl]);
  return null;
}

export function World() {
  const { scene } = useThree();
  useEffect(() => {
    const sun = scene.getObjectByName("sun") as THREE.DirectionalLight | undefined;
    if (sun) scene.add(sun.target);
  }, [scene]);
  return (
    <>
      <color attach="background" args={[PAL.sky]} />
      <fog attach="fog" args={[PAL.skyFog, 30, 82]} />
      <hemisphereLight args={[PAL.sky, PAL.moss, 0.62]} />
      <Sync />
      <LookDrag />
      <SkyDome />
      <Island />
      <Water />
      <DecorField />
      <Cottage />
      <Campfire />
      <Nodes />
      <Buildings />
      <Pals />
      <Orbs />
      <Showcase />
      <TargetRing />
      <Sparks />
    </>
  );
}

export const POND_POS = POND;
