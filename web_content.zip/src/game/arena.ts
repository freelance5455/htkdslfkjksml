import * as THREE from "three";

export type AttackKind = "punch" | "kick";
export type GameMode = "menu" | "playing" | "paused" | "gameover";
export type GameResult = "player" | "enemy" | "draw";

interface AttackState {
  kind: AttackKind;
  elapsed: number;
  duration: number;
  didHit: boolean;
}

interface FighterState {
  x: number;
  hp: number;
  facing: number;
  attack: AttackState | null;
  attackCooldown: number;
  bufferedAttack: AttackKind | null;
  bufferTimer: number;
  jumpY: number;
  jumpVelocity: number;
  guard: boolean;
  guardTimer: number;
  stun: number;
  flash: number;
  knockback: number;
  walkPhase: number;
}

export interface ParticleState {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export interface PopupState {
  id: number;
  text: string;
  x: number;
  y: number;
  z: number;
  life: number;
  maxLife: number;
  color: string;
}

export interface CombatEvent {
  kind: "hit" | "block";
  playerAttack: boolean;
}

export interface GameRuntime {
  player: FighterState;
  enemy: FighterState;
  time: number;
  score: number;
  combo: number;
  comboTimer: number;
  bestCombo: number;
  shake: number;
  visualTime: number;
  fightCue: number;
  enemyThink: number;
  enemyMove: number;
  rng: number;
  nextPopupId: number;
  particles: ParticleState[];
  popups: PopupState[];
  events: CombatEvent[];
}

export interface ArenaRenderer {
  render(runtime: GameRuntime, mode: GameMode): void;
  dispose(): void;
}

const ARENA_LIMIT = 6.15;
const PLAYER_SPEED = 5.15;
const ENEMY_SPEED = 3.35;
const ROUND_LENGTH = 60;

function makeFighter(x: number): FighterState {
  return {
    x,
    hp: 100,
    facing: x < 0 ? 1 : -1,
    attack: null,
    attackCooldown: 0,
    bufferedAttack: null,
    bufferTimer: 0,
    jumpY: 0,
    jumpVelocity: 0,
    guard: false,
    guardTimer: 0,
    stun: 0,
    flash: 0,
    knockback: 0,
    walkPhase: 0,
  };
}

export function createRuntime(): GameRuntime {
  return {
    player: makeFighter(-2.3),
    enemy: makeFighter(2.3),
    time: ROUND_LENGTH,
    score: 0,
    combo: 0,
    comboTimer: 0,
    bestCombo: 0,
    shake: 0,
    visualTime: 0,
    fightCue: 0,
    enemyThink: 0.2,
    enemyMove: 0,
    rng: 230419,
    nextPopupId: 1,
    particles: [],
    popups: [],
    events: [],
  };
}

export function resetRuntime(runtime: GameRuntime): void {
  Object.assign(runtime, createRuntime(), { fightCue: 0.9 });
}

function random(runtime: GameRuntime): number {
  runtime.rng = (runtime.rng * 1664525 + 1013904223) >>> 0;
  return runtime.rng / 4294967296;
}

function startAttack(fighter: FighterState, kind: AttackKind): void {
  const duration = kind === "punch" ? 0.42 : 0.62;
  fighter.attack = { kind, elapsed: 0, duration, didHit: false };
  fighter.attackCooldown = kind === "punch" ? 0.34 : 0.58;
}

function addPopup(
  runtime: GameRuntime,
  text: string,
  x: number,
  color: string,
): void {
  runtime.popups.push({
    id: runtime.nextPopupId++,
    text,
    x,
    y: 1.65,
    z: 0.2,
    life: 0.72,
    maxLife: 0.72,
    color,
  });
}

function burst(runtime: GameRuntime, x: number, color: string, count = 16): void {
  for (let i = 0; i < count; i += 1) {
    const angle = random(runtime) * Math.PI * 2;
    const speed = 1.3 + random(runtime) * 4.2;
    runtime.particles.push({
      x,
      y: 1.25 + random(runtime) * 0.65,
      z: 0.15 + (random(runtime) - 0.5) * 0.65,
      vx: Math.cos(angle) * speed,
      vy: 1.4 + random(runtime) * 4.4,
      vz: (random(runtime) - 0.5) * 2.8,
      life: 0.28 + random(runtime) * 0.42,
      maxLife: 0.7,
      color: i % 4 === 0 ? "#f5e7c2" : color,
      size: 0.045 + random(runtime) * 0.08,
    });
  }
}

function resolveAttack(
  runtime: GameRuntime,
  attacker: FighterState,
  target: FighterState,
  isPlayer: boolean,
): void {
  const attack = attacker.attack;
  if (!attack || attack.didHit) return;

  const activeAt = attack.kind === "punch" ? 0.14 : 0.24;
  if (attack.elapsed < activeAt) return;

  attack.didHit = true;
  const delta = target.x - attacker.x;
  const range = attack.kind === "punch" ? 1.28 : 1.75;
  const inFront = Math.sign(delta) === attacker.facing;
  if (!inFront || Math.abs(delta) > range || target.jumpY > 0.68) return;

  const blocked = target.guard || target.guardTimer > 0;
  const baseDamage = attack.kind === "punch" ? 11 : 15;
  const damage = Math.max(1, Math.round(baseDamage * (blocked ? 0.24 : 1)));
  target.hp = Math.max(0, target.hp - damage);
  target.flash = blocked ? 0.12 : 0.2;
  target.stun = blocked ? 0.06 : 0.27;
  target.knockback = attacker.facing * (blocked ? 1.2 : 3.2);

  runtime.shake = Math.min(0.28, runtime.shake + (blocked ? 0.08 : 0.2));
  burst(runtime, target.x, blocked ? "#65e5d2" : isPlayer ? "#ffbd69" : "#66ddf0", blocked ? 9 : 18);
  runtime.events.push({ kind: blocked ? "block" : "hit", playerAttack: isPlayer });

  if (isPlayer) {
    if (blocked) {
      addPopup(runtime, "BLOCK", target.x, "#75e9d6");
    } else {
      runtime.combo = runtime.comboTimer > 0 ? runtime.combo + 1 : 1;
      runtime.comboTimer = 1.65;
      runtime.bestCombo = Math.max(runtime.bestCombo, runtime.combo);
      const points = (attack.kind === "punch" ? 120 : 170) + (runtime.combo - 1) * 45;
      runtime.score += points;
      addPopup(runtime, `+${points}`, target.x, "#ffd18b");
    }
  } else if (blocked) {
    addPopup(runtime, "GUARD", target.x, "#75e9d6");
  } else {
    runtime.combo = 0;
    runtime.comboTimer = 0;
    addPopup(runtime, "HIT", target.x, "#9be7ff");
  }
}

function updateFighter(fighter: FighterState, dt: number): void {
  fighter.attackCooldown = Math.max(0, fighter.attackCooldown - dt);
  fighter.bufferTimer = Math.max(0, fighter.bufferTimer - dt);
  if (fighter.bufferTimer === 0) fighter.bufferedAttack = null;
  fighter.guardTimer = Math.max(0, fighter.guardTimer - dt);
  fighter.stun = Math.max(0, fighter.stun - dt);
  fighter.flash = Math.max(0, fighter.flash - dt);

  if (fighter.attack) {
    fighter.attack.elapsed += dt;
    if (fighter.attack.elapsed >= fighter.attack.duration) fighter.attack = null;
  }

  if (fighter.jumpY > 0 || fighter.jumpVelocity > 0) {
    fighter.jumpY += fighter.jumpVelocity * dt;
    fighter.jumpVelocity -= 22 * dt;
    if (fighter.jumpY <= 0) {
      fighter.jumpY = 0;
      fighter.jumpVelocity = 0;
    }
  }

}

export function stepRuntime(
  runtime: GameRuntime,
  dt: number,
  held: Set<string>,
  pressed: string[],
): GameResult | null {
  runtime.events.length = 0;
  runtime.visualTime += dt;
  runtime.fightCue = Math.max(0, runtime.fightCue - dt);
  runtime.shake = Math.max(0, runtime.shake - dt * 1.5);
  runtime.comboTimer = Math.max(0, runtime.comboTimer - dt);
  if (runtime.comboTimer === 0) runtime.combo = 0;
  runtime.time = Math.max(0, runtime.time - dt);

  const player = runtime.player;
  const enemy = runtime.enemy;
  updateFighter(player, dt);
  updateFighter(enemy, dt);

  player.guard = held.has("guard");
  enemy.guard = enemy.guardTimer > 0;

  if (pressed.includes("jump") && player.jumpY === 0 && player.stun <= 0) {
    player.jumpVelocity = 8.6;
    player.jumpY = 0.01;
  }
  if (pressed.includes("punch")) {
    player.bufferedAttack = "punch";
    player.bufferTimer = 0.18;
  }
  if (pressed.includes("kick")) {
    player.bufferedAttack = "kick";
    player.bufferTimer = 0.18;
  }

  if (
    player.bufferedAttack &&
    player.bufferTimer > 0 &&
    player.attackCooldown <= 0 &&
    !player.attack &&
    player.stun <= 0
  ) {
    startAttack(player, player.bufferedAttack);
    player.bufferedAttack = null;
    player.bufferTimer = 0;
  }

  const distance = enemy.x - player.x;
  const towardPlayer = Math.sign(-distance);
  runtime.enemyThink -= dt;
  if (runtime.enemyThink <= 0) {
    runtime.enemyThink = 0.14 + random(runtime) * 0.16;
    const gap = Math.abs(distance);
    runtime.enemyMove = gap > 1.45 ? towardPlayer : gap < 0.8 ? -towardPlayer * 0.45 : 0;

    if (gap < 1.95 && !enemy.attack && enemy.stun <= 0 && enemy.attackCooldown < 0.15) {
      if (player.attack && random(runtime) < 0.33) {
        enemy.guardTimer = 0.48;
        enemy.guard = true;
        runtime.enemyMove = 0;
      } else if (random(runtime) < (gap < 1.55 ? 0.74 : 0.38)) {
        enemy.bufferedAttack = random(runtime) < 0.68 ? "punch" : "kick";
        enemy.bufferTimer = 0.2;
        runtime.enemyMove = 0;
      }
    }
  }

  if (
    enemy.bufferedAttack &&
    enemy.bufferTimer > 0 &&
    enemy.attackCooldown <= 0 &&
    !enemy.attack &&
    enemy.stun <= 0 &&
    enemy.guardTimer <= 0
  ) {
    startAttack(enemy, enemy.bufferedAttack);
    enemy.bufferedAttack = null;
    enemy.bufferTimer = 0;
  }

  if (!player.attack && player.stun <= 0) {
    let direction = Number(held.has("right")) - Number(held.has("left"));
    if (player.guard) direction *= 0.28;
    if (direction !== 0) {
      player.x += direction * PLAYER_SPEED * dt;
      player.walkPhase += dt * 10;
    }
  }

  if (!enemy.attack && enemy.stun <= 0) {
    enemy.x += runtime.enemyMove * ENEMY_SPEED * dt;
    if (runtime.enemyMove !== 0) enemy.walkPhase += dt * 8;
  }

  player.x += player.knockback * dt;
  enemy.x += enemy.knockback * dt;
  player.knockback *= Math.exp(-8 * dt);
  enemy.knockback *= Math.exp(-8 * dt);

  player.x = THREE.MathUtils.clamp(player.x, -ARENA_LIMIT, ARENA_LIMIT);
  enemy.x = THREE.MathUtils.clamp(enemy.x, -ARENA_LIMIT, ARENA_LIMIT);
  if (Math.abs(enemy.x - player.x) < 0.82) {
    const direction = player.x < enemy.x ? 1 : -1;
    const overlap = 0.82 - Math.abs(enemy.x - player.x);
    player.x -= direction * overlap * 0.5;
    enemy.x += direction * overlap * 0.5;
  }

  player.facing = enemy.x >= player.x ? 1 : -1;
  enemy.facing = player.x >= enemy.x ? 1 : -1;

  resolveAttack(runtime, player, enemy, true);
  resolveAttack(runtime, enemy, player, false);

  for (let i = runtime.particles.length - 1; i >= 0; i -= 1) {
    const particle = runtime.particles[i];
    particle.life -= dt;
    particle.x += particle.vx * dt;
    particle.y += particle.vy * dt;
    particle.z += particle.vz * dt;
    particle.vy -= 8.5 * dt;
    particle.vx *= Math.exp(-1.5 * dt);
    if (particle.life <= 0 || particle.y < 0) runtime.particles.splice(i, 1);
  }
  for (let i = runtime.popups.length - 1; i >= 0; i -= 1) {
    const popup = runtime.popups[i];
    popup.life -= dt;
    popup.y += dt * 0.72;
    if (popup.life <= 0) runtime.popups.splice(i, 1);
  }

  if (player.hp <= 0 && enemy.hp <= 0) return "draw";
  if (enemy.hp <= 0) return "player";
  if (player.hp <= 0) return "enemy";
  if (runtime.time <= 0) {
    if (player.hp > enemy.hp) return "player";
    if (enemy.hp > player.hp) return "enemy";
    return "draw";
  }
  return null;
}

function makeCityTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 520;
  const context = canvas.getContext("2d");
  if (!context) return new THREE.CanvasTexture(canvas);

  const sky = context.createLinearGradient(0, 0, 0, canvas.height);
  sky.addColorStop(0, "#0a1220");
  sky.addColorStop(0.58, "#152034");
  sky.addColorStop(1, "#271a2c");
  context.fillStyle = sky;
  context.fillRect(0, 0, canvas.width, canvas.height);

  const haze = context.createRadialGradient(600, 360, 0, 600, 360, 530);
  haze.addColorStop(0, "rgba(104, 73, 111, .34)");
  haze.addColorStop(1, "rgba(26, 22, 42, 0)");
  context.fillStyle = haze;
  context.fillRect(0, 0, canvas.width, canvas.height);

  let seed = 713;
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  let x = -8;
  while (x < canvas.width + 20) {
    const width = 34 + rand() * 84;
    const height = 78 + rand() * 190;
    const top = canvas.height - height;
    context.fillStyle = rand() > 0.55 ? "#101726" : "#111a28";
    context.fillRect(x, top, width, height);
    context.fillStyle = "rgba(216, 164, 105, .3)";
    for (let wy = top + 18; wy < canvas.height - 16; wy += 17) {
      for (let wx = x + 9; wx < x + width - 5; wx += 15) {
        if (rand() > 0.63) context.fillRect(wx, wy, 4, 6);
      }
    }
    x += width - 3;
  }

  context.fillStyle = "rgba(5, 9, 16, .92)";
  context.fillRect(0, 395, canvas.width, 125);
  context.strokeStyle = "rgba(255, 181, 104, .76)";
  context.lineWidth = 3;
  context.shadowColor = "#ff8c5d";
  context.shadowBlur = 18;
  context.strokeRect(438, 220, 324, 87);
  context.shadowBlur = 0;
  context.fillStyle = "#f6d6aa";
  context.font = "bold 31px Arial, sans-serif";
  context.textAlign = "center";
  context.fillText("AFTER HOURS", 600, 254);
  context.fillStyle = "rgba(195, 207, 225, .75)";
  context.font = "13px Arial, sans-serif";
  context.letterSpacing = "5px";
  context.fillText("TEHRAN   /   FIGHT NIGHT", 600, 281);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = false;
  return texture;
}

function addBox(
  parent: THREE.Object3D,
  geometry: THREE.BufferGeometry,
  material: THREE.Material,
  position: [number, number, number],
  scale?: [number, number, number],
): THREE.Mesh {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(...position);
  if (scale) mesh.scale.set(...scale);
  parent.add(mesh);
  return mesh;
}

function addLine(
  scene: THREE.Scene,
  points: THREE.Vector3[],
  color: number,
  opacity: number,
): THREE.Line {
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity });
  const line = new THREE.Line(geometry, material);
  scene.add(line);
  return line;
}

function createArenaScene(scene: THREE.Scene): {
  beams: THREE.Mesh[];
  movingLights: { light: THREE.SpotLight; target: THREE.Object3D; phase: number }[];
} {
  const city = new THREE.Mesh(
    new THREE.PlaneGeometry(31, 13.5),
    new THREE.MeshBasicMaterial({ map: makeCityTexture(), transparent: false }),
  );
  city.position.set(0, 5.8, -12.8);
  scene.add(city);

  const floorMat = new THREE.MeshStandardMaterial({ color: 0x111720, metalness: 0.52, roughness: 0.36 });
  const rimMat = new THREE.MeshStandardMaterial({ color: 0x1b2530, metalness: 0.72, roughness: 0.25 });
  addBox(scene, new THREE.BoxGeometry(18.2, 0.34, 10.8), floorMat, [0, -0.27, 0]);
  addBox(scene, new THREE.BoxGeometry(18.5, 0.16, 11.1), rimMat, [0, -0.49, 0]);

  const deck = new THREE.Mesh(
    new THREE.PlaneGeometry(17.9, 10.5),
    new THREE.MeshStandardMaterial({ color: 0x171b23, metalness: 0.36, roughness: 0.43 }),
  );
  deck.rotation.x = -Math.PI / 2;
  deck.position.y = -0.085;
  scene.add(deck);

  const gridMat = new THREE.LineBasicMaterial({ color: 0x61717c, transparent: true, opacity: 0.17 });
  const gridPoints: THREE.Vector3[] = [];
  for (let x = -8; x <= 8; x += 1) {
    gridPoints.push(new THREE.Vector3(x, -0.075, -5.1), new THREE.Vector3(x, -0.075, 5.1));
  }
  for (let z = -5; z <= 5; z += 1) {
    gridPoints.push(new THREE.Vector3(-8.8, -0.075, z), new THREE.Vector3(8.8, -0.075, z));
  }
  const grid = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(gridPoints), gridMat);
  scene.add(grid);

  const torusMat = (color: number, emissive: number) =>
    new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: 1.15, metalness: 0.6, roughness: 0.25 });
  const cyanRing = new THREE.Mesh(new THREE.TorusGeometry(6.1, 0.034, 6, 112), torusMat(0x4ad5d2, 0x167b85));
  cyanRing.rotation.x = -Math.PI / 2;
  cyanRing.position.y = -0.01;
  scene.add(cyanRing);
  const amberRing = new THREE.Mesh(new THREE.TorusGeometry(4.95, 0.022, 5, 112), torusMat(0xf5a35f, 0x9b4826));
  amberRing.rotation.x = -Math.PI / 2;
  amberRing.position.y = -0.012;
  scene.add(amberRing);

  const edgeMat = new THREE.MeshStandardMaterial({ color: 0x28303a, metalness: 0.72, roughness: 0.26 });
  const cyanEdgeMat = new THREE.MeshStandardMaterial({ color: 0x38c7c6, emissive: 0x0c555e, emissiveIntensity: 0.9 });
  const redEdgeMat = new THREE.MeshStandardMaterial({ color: 0xff8765, emissive: 0x853a30, emissiveIntensity: 0.8 });
  for (const sign of [-1, 1]) {
    const post = addBox(scene, new THREE.BoxGeometry(0.24, 2.05, 0.24), edgeMat, [sign * 7.45, 0.88, -0.55]);
    post.rotation.z = sign * -0.03;
    const cap = addBox(scene, new THREE.BoxGeometry(0.38, 0.12, 0.36), sign < 0 ? redEdgeMat : cyanEdgeMat, [sign * 7.45, 1.95, -0.55]);
    cap.rotation.y = Math.PI / 4;
  }
  addLine(scene, [new THREE.Vector3(-7.8, 0.02, -4.25), new THREE.Vector3(7.8, 0.02, -4.25)], 0x45a9b7, 0.6);
  addLine(scene, [new THREE.Vector3(-7.8, 0.02, 4.25), new THREE.Vector3(7.8, 0.02, 4.25)], 0xf08b64, 0.5);

  const crowdGeometry = new THREE.SphereGeometry(0.105, 7, 6);
  const crowdMaterial = new THREE.MeshStandardMaterial({ color: 0x111724, roughness: 0.94, metalness: 0.05 });
  const crowd = new THREE.InstancedMesh(crowdGeometry, crowdMaterial, 180);
  const dummy = new THREE.Object3D();
  let crowdIndex = 0;
  for (let row = 0; row < 3; row += 1) {
    for (let i = 0; i < 60; i += 1) {
      const x = -8.8 + i * 0.3 + (row % 2) * 0.12;
      const z = -3.25 - row * 0.36;
      const height = 0.62 + ((i * 17 + row * 5) % 9) * 0.065;
      dummy.position.set(x, height, z);
      dummy.scale.set(1, 1.15 + (i % 3) * 0.15, 0.8);
      dummy.updateMatrix();
      crowd.setMatrixAt(crowdIndex++, dummy.matrix);
    }
  }
  crowd.instanceMatrix.needsUpdate = true;
  scene.add(crowd);

  const colorDots = new THREE.Group();
  for (let i = 0; i < 34; i += 1) {
    const color = i % 3 === 0 ? 0xffa56f : i % 3 === 1 ? 0x57d8d4 : 0xada1d8;
    const dot = new THREE.Mesh(
      new THREE.SphereGeometry(0.035, 6, 5),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.75 }),
    );
    dot.position.set(-8.2 + (i * 0.51) % 16.4, 1.5 + ((i * 7) % 11) * 0.1, -2.8 - (i % 4) * 0.18);
    colorDots.add(dot);
  }
  scene.add(colorDots);

  const beamColors = [0xff865e, 0x45d6d3, 0x9267ed, 0xffbb75];
  const beams: THREE.Mesh[] = [];
  beamColors.forEach((color, index) => {
    const beam = new THREE.Mesh(
      new THREE.ConeGeometry(2.1, 8.8, 24, 1, true),
      new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.055,
        depthWrite: false,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
      }),
    );
    beam.position.set(index < 2 ? -5.5 : 5.5, 4.25, index % 2 === 0 ? -1.6 : -3.1);
    beam.rotation.z = index % 2 === 0 ? 0.32 : -0.3;
    scene.add(beam);
    beams.push(beam);
  });

  const movingLights: { light: THREE.SpotLight; target: THREE.Object3D; phase: number }[] = [];
  for (let i = 0; i < 2; i += 1) {
    const target = new THREE.Object3D();
    target.position.set(i === 0 ? -2.8 : 2.8, 0, 0.2);
    scene.add(target);
    const light = new THREE.SpotLight(i === 0 ? 0xff9369 : 0x62e1db, 42, 24, 0.55, 0.72, 1.3);
    light.position.set(i === 0 ? -6.5 : 6.5, 8.3, 3.8);
    light.target = target;
    scene.add(light);
    scene.add(light.target);
    movingLights.push({ light, target, phase: i * Math.PI });
  }

  const trussMat = new THREE.MeshStandardMaterial({ color: 0x252d37, metalness: 0.78, roughness: 0.29 });
  addBox(scene, new THREE.BoxGeometry(19, 0.16, 0.24), trussMat, [0, 7.5, -2.2]);
  for (const x of [-8.8, -5.4, 5.4, 8.8]) {
    const fixture = addBox(scene, new THREE.BoxGeometry(0.27, 0.22, 0.32), x < 0 ? redEdgeMat : cyanEdgeMat, [x, 7.32, -2.2]);
    fixture.rotation.z = x < 0 ? 0.16 : -0.16;
  }

  return { beams, movingLights };
}

function makeMaterial(
  color: number,
  options: { metalness?: number; roughness?: number; emissive?: number } = {},
): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color,
    metalness: options.metalness ?? 0.18,
    roughness: options.roughness ?? 0.62,
    emissive: options.emissive ?? 0x000000,
  });
}

interface FighterVisual {
  root: THREE.Group;
  torso: THREE.Group;
  frontArm: THREE.Group;
  backArm: THREE.Group;
  frontLeg: THREE.Group;
  backLeg: THREE.Group;
  bodyParts: THREE.Mesh[];
}

function createLimb(
  parent: THREE.Group,
  x: number,
  y: number,
  gloveMaterial: THREE.Material,
  sleeveMaterial: THREE.Material,
  gloveScale = 1,
): THREE.Group {
  const limb = new THREE.Group();
  limb.position.set(x, y, 0);
  const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.135, 0.36, 4, 7), sleeveMaterial);
  upper.position.y = -0.22;
  limb.add(upper);
  const elbow = new THREE.Mesh(new THREE.SphereGeometry(0.13, 9, 7), sleeveMaterial);
  elbow.position.y = -0.43;
  limb.add(elbow);
  const forearm = new THREE.Group();
  forearm.position.y = -0.4;
  const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.115, 0.34, 4, 7), sleeveMaterial);
  arm.position.y = -0.2;
  forearm.add(arm);
  const glove = new THREE.Mesh(new THREE.SphereGeometry(0.16 * gloveScale, 10, 8), gloveMaterial);
  glove.position.set(0, -0.4, 0.035);
  forearm.add(glove);
  limb.add(forearm);
  limb.userData.forearm = forearm;
  parent.add(limb);
  return limb;
}

function createLeg(parent: THREE.Group, x: number, pants: THREE.Material, boot: THREE.Material): THREE.Group {
  const leg = new THREE.Group();
  leg.position.set(x, 0.9, 0);
  const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.39, 4, 7), pants);
  thigh.position.y = -0.23;
  leg.add(thigh);
  const knee = new THREE.Mesh(new THREE.SphereGeometry(0.165, 9, 8), pants);
  knee.position.y = -0.45;
  leg.add(knee);
  const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.145, 0.37, 4, 7), pants);
  shin.position.y = -0.7;
  leg.add(shin);
  const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.19, 0.52), boot);
  shoe.position.set(0.025, -0.93, 0.11);
  leg.add(shoe);
  parent.add(leg);
  return leg;
}

function createFighterVisual(style: "tataloo" | "sasy"): FighterVisual {
  const playerStyle = style === "tataloo";
  const palette = playerStyle
    ? { skin: 0xc18161, hair: 0x15151b, jacket: 0x20242d, accent: 0xe56e4e, pants: 0x15181f, boot: 0x292d34, glove: 0xc85343, metal: 0xe2c58f }
    : { skin: 0xd4a17e, hair: 0x49312a, jacket: 0x187c81, accent: 0x69ded2, pants: 0x22252e, boot: 0xd5dce1, glove: 0x45c6c3, metal: 0xd6e3e2 };
  const skin = makeMaterial(palette.skin, { roughness: 0.79 });
  const hair = makeMaterial(palette.hair, { roughness: 0.82 });
  const jacket = makeMaterial(palette.jacket, { roughness: 0.57, metalness: 0.22 });
  const accent = makeMaterial(palette.accent, { roughness: 0.4, metalness: 0.22, emissive: playerStyle ? 0x31100b : 0x063a3b });
  const pants = makeMaterial(palette.pants, { roughness: 0.82 });
  const boot = makeMaterial(palette.boot, { roughness: 0.4, metalness: 0.25 });
  const glove = makeMaterial(palette.glove, { roughness: 0.38, metalness: 0.24, emissive: playerStyle ? 0x2a0b08 : 0x063538 });
  const metal = makeMaterial(palette.metal, { roughness: 0.24, metalness: 0.78, emissive: playerStyle ? 0x332317 : 0x143b3a });
  const shades = makeMaterial(0x10131a, { roughness: 0.2, metalness: 0.28 });
  const pale = makeMaterial(0xf1e7d5, { roughness: 0.65 });

  const root = new THREE.Group();
  const torso = new THREE.Group();
  root.add(torso);
  const bodyParts: THREE.Mesh[] = [];
  const addPart = (mesh: THREE.Mesh) => {
    torso.add(mesh);
    bodyParts.push(mesh);
    return mesh;
  };

  addPart(new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.38, 0.42, 10), jacket)).position.set(0, 0.94, 0);
  const chest = addPart(new THREE.Mesh(new THREE.CylinderGeometry(0.29, 0.43, 0.91, 10), jacket));
  chest.position.set(0, 1.45, 0);
  chest.rotation.z = -0.025;
  const shirt = addPart(new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.67, 0.07), pale));
  shirt.position.set(0, 1.46, 0.345);
  const stripe = addPart(new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.72, 0.09), accent));
  stripe.position.set(playerStyle ? 0.18 : -0.19, 1.45, 0.34);
  const collar = addPart(new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 5, 22), metal));
  collar.position.set(0, 1.84, 0.025);
  collar.rotation.x = Math.PI / 2;

  const shoulderLeft = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), jacket));
  shoulderLeft.position.set(-0.43, 1.72, 0);
  const shoulderRight = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), jacket));
  shoulderRight.position.set(0.43, 1.72, 0);
  const trim = addPart(new THREE.Mesh(new THREE.BoxGeometry(0.63, 0.055, 0.06), accent));
  trim.position.set(0, 1.08, 0.34);

  const head = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.295, 14, 12), skin));
  head.scale.set(0.88, 1.08, 0.9);
  head.position.set(0, 2.2, 0);
  const hairCap = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 9), hair));
  hairCap.scale.set(playerStyle ? 1.04 : 0.98, playerStyle ? 0.68 : 0.54, 0.94);
  hairCap.position.set(0, 2.43, -0.02);
  if (playerStyle) {
    for (let i = 0; i < 5; i += 1) {
      const lock = addPart(new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.2 + (i % 2) * 0.08, 3, 5), hair));
      lock.position.set(-0.22 + i * 0.11, 2.18 - (i % 2) * 0.08, -0.17);
      lock.rotation.z = (i - 2) * 0.08;
    }
    const beard = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.205, 10, 8), hair));
    beard.scale.set(1.06, 0.64, 0.72);
    beard.position.set(0, 2.04, 0.115);
  } else {
    const swoop = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), hair));
    swoop.scale.set(1.12, 0.54, 0.92);
    swoop.position.set(-0.09, 2.47, 0.08);
  }
  const glasses = addPart(new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.095, 0.055), shades));
  glasses.position.set(0, 2.28, 0.253);
  const bridge = addPart(new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.03, 0.08), metal));
  bridge.position.set(0, 2.29, 0.27);
  const earLeft = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.055, 7, 6), skin));
  earLeft.position.set(-0.267, 2.18, 0);
  const earRight = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.055, 7, 6), skin));
  earRight.position.set(0.267, 2.18, 0);

  const frontArm = createLimb(torso, 0.46, 1.68, glove, jacket, 1.05);
  const backArm = createLimb(torso, -0.46, 1.68, glove, jacket, 0.92);
  frontArm.rotation.z = 0.2;
  backArm.rotation.z = -0.2;
  const frontLeg = createLeg(torso, 0.21, pants, boot);
  const backLeg = createLeg(torso, -0.21, pants, boot);

  if (!playerStyle) {
    const hoodie = addPart(new THREE.Mesh(new THREE.SphereGeometry(0.26, 10, 8), jacket));
    hoodie.scale.set(0.92, 0.72, 0.58);
    hoodie.position.set(0, 1.91, -0.2);
    const cuff = addPart(new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.035, 5, 18), accent));
    cuff.position.set(-0.52, 1.12, 0);
    cuff.rotation.x = Math.PI / 2;
  } else {
    const chain = addPart(new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.024, 5, 18), metal));
    chain.position.set(0, 1.48, 0.365);
    chain.rotation.x = Math.PI / 2;
  }

  return { root, torso, frontArm, backArm, frontLeg, backLeg, bodyParts };
}

function createTextTexture(text: string, color: string): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 160;
  const context = canvas.getContext("2d");
  if (context) {
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.font = "900 76px Arial, sans-serif";
    context.textAlign = "center";
    context.textBaseline = "middle";
    context.shadowColor = color;
    context.shadowBlur = 22;
    context.fillStyle = color;
    context.fillText(text, canvas.width / 2, canvas.height / 2);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createPopupSprite(text: string, color: string): THREE.Sprite {
  const material = new THREE.SpriteMaterial({
    map: createTextTexture(text, color),
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(text.length > 6 ? 2.45 : 1.85, 0.58, 1);
  return sprite;
}

export function createArenaRenderer(host: HTMLElement): ArenaRenderer {
  const renderer = new THREE.WebGLRenderer({
    antialias: (window.devicePixelRatio || 1) <= 1.5,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(host.clientWidth, host.clientHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.22;
  renderer.domElement.setAttribute("aria-label", "سه بعدی میدان مبارزه کوچه فایت");
  renderer.domElement.style.display = "block";
  renderer.domElement.style.width = "100%";
  renderer.domElement.style.height = "100%";
  host.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b1019);
  scene.fog = new THREE.Fog(0x0b1019, 18, 40);
  const camera = new THREE.PerspectiveCamera(36, host.clientWidth / Math.max(1, host.clientHeight), 0.1, 70);
  const baseCameraPosition = new THREE.Vector3(0, 4.05, 13.2);
  const cameraTarget = new THREE.Vector3(0, 1.38, 0);
  camera.position.copy(baseCameraPosition);
  camera.lookAt(cameraTarget);

  scene.add(new THREE.HemisphereLight(0x8798c4, 0x16121b, 1.65));
  const keyLight = new THREE.DirectionalLight(0xffd3ad, 2.05);
  keyLight.position.set(-3.7, 8.5, 5.5);
  scene.add(keyLight);
  const coolFill = new THREE.PointLight(0x3e9eaf, 22, 18, 2);
  coolFill.position.set(5.6, 4.2, -1.5);
  scene.add(coolFill);
  const warmFill = new THREE.PointLight(0xe66e4e, 15, 18, 2);
  warmFill.position.set(-5.5, 3.6, -1);
  scene.add(warmFill);

  const arenaParts = createArenaScene(scene);
  const playerVisual = createFighterVisual("tataloo");
  const enemyVisual = createFighterVisual("sasy");
  scene.add(playerVisual.root, enemyVisual.root);

  const shadowMaterial = new THREE.MeshBasicMaterial({ color: 0x05070b, transparent: true, opacity: 0.52, depthWrite: false });
  const playerShadow = new THREE.Mesh(new THREE.CircleGeometry(0.78, 24), shadowMaterial);
  const enemyShadow = new THREE.Mesh(new THREE.CircleGeometry(0.78, 24), shadowMaterial.clone());
  playerShadow.rotation.x = enemyShadow.rotation.x = -Math.PI / 2;
  playerShadow.position.set(-2.3, -0.04, 0.06);
  enemyShadow.position.set(2.3, -0.04, 0.06);
  scene.add(playerShadow, enemyShadow);

  const particleGeometry = new THREE.BufferGeometry();
  const positions = new Float32Array(240 * 3);
  const colors = new Float32Array(240 * 3);
  particleGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
  particleGeometry.setAttribute("color", new THREE.BufferAttribute(colors, 3).setUsage(THREE.DynamicDrawUsage));
  const particleCloud = new THREE.Points(
    particleGeometry,
    new THREE.PointsMaterial({ size: 0.17, vertexColors: true, transparent: true, opacity: 0.96, depthWrite: false, sizeAttenuation: true }),
  );
  scene.add(particleCloud);

  const popupSprites = new Map<number, THREE.Sprite>();
  let fightSprite: THREE.Sprite | null = null;
  if (typeof document !== "undefined") {
    fightSprite = createPopupSprite("FIGHT!", "#ffd09b");
    fightSprite.scale.set(3.2, 1.0, 1);
    fightSprite.position.set(0, 3.0, 0);
    fightSprite.visible = false;
    scene.add(fightSprite);
  }

  const resize = () => {
    const width = Math.max(1, host.clientWidth);
    const height = Math.max(1, host.clientHeight);
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
  };
  const observer = new ResizeObserver(resize);
  observer.observe(host);

  const scratchColor = new THREE.Color();
  return {
    render(runtime, mode) {
      const visualTime = runtime.visualTime;
      arenaParts.beams.forEach((beam, index) => {
        beam.rotation.z = Math.sin(visualTime * 0.54 + index * 1.7) * 0.46;
        beam.rotation.x = Math.sin(visualTime * 0.32 + index) * 0.14;
      });
      arenaParts.movingLights.forEach(({ light, target, phase }) => {
        target.position.x = Math.sin(visualTime * 0.72 + phase) * 3.7;
        target.position.z = Math.cos(visualTime * 0.42 + phase) * 1.4;
        light.intensity = 38 + Math.sin(visualTime * 1.1 + phase) * 4;
      });

      const updateFighterVisual = (visual: FighterVisual, fighter: FighterState, shadow: THREE.Mesh, offset: number) => {
        const attack = fighter.attack;
        const phase = fighter.walkPhase;
        const extension = attack ? Math.sin(Math.min(1, attack.elapsed / attack.duration) * Math.PI) : 0;
        visual.root.position.set(fighter.x, fighter.jumpY, 0.15);
        visual.root.rotation.y = fighter.facing > 0 ? 0.52 : -0.52;
        visual.root.rotation.z = fighter.stun > 0 ? Math.sin(visualTime * 45 + offset) * 0.075 : 0;
        visual.torso.position.y = Math.sin(visualTime * 4.4 + offset) * 0.035;

        const guard = fighter.guard || fighter.guardTimer > 0;
        visual.frontArm.rotation.set(
          guard ? -1.05 : attack?.kind === "punch" ? -0.22 - extension * 1.62 : -0.2 + Math.sin(phase) * 0.08,
          0,
          guard ? 0.34 : 0.22,
        );
        visual.backArm.rotation.set(
          guard ? -0.92 : attack?.kind === "punch" ? 0.1 - extension * 0.42 : -0.16 - Math.sin(phase) * 0.08,
          0,
          -0.22,
        );
        visual.frontLeg.rotation.set(
          attack?.kind === "kick" ? -extension * 1.28 : Math.sin(phase) * (fighter.attack ? 0.04 : 0.2),
          0,
          0,
        );
        visual.backLeg.rotation.x = attack?.kind === "kick" ? extension * 0.25 : -Math.sin(phase) * 0.16;
        visual.root.scale.setScalar(fighter.flash > 0 ? 1.035 : 1);

        for (const part of visual.bodyParts) {
          const material = part.material;
          if (material instanceof THREE.MeshStandardMaterial) {
            material.emissive.setHex(fighter.flash > 0 ? 0x71614d : 0x000000);
            material.emissiveIntensity = fighter.flash > 0 ? 1.5 : 1;
          }
        }

        shadow.position.x = fighter.x;
        shadow.scale.setScalar(Math.max(0.62, 1 - fighter.jumpY * 0.08));
        (shadow.material as THREE.MeshBasicMaterial).opacity = Math.max(0.22, 0.52 - fighter.jumpY * 0.14);
      };

      updateFighterVisual(playerVisual, runtime.player, playerShadow, 0);
      updateFighterVisual(enemyVisual, runtime.enemy, enemyShadow, 2.1);

      const positionAttribute = particleGeometry.getAttribute("position") as THREE.BufferAttribute;
      const colorAttribute = particleGeometry.getAttribute("color") as THREE.BufferAttribute;
      const visibleParticles = Math.min(runtime.particles.length, 240);
      for (let i = 0; i < visibleParticles; i += 1) {
        const particle = runtime.particles[i];
        positions[i * 3] = particle.x;
        positions[i * 3 + 1] = particle.y;
        positions[i * 3 + 2] = particle.z;
        scratchColor.set(particle.color);
        const fade = Math.min(1, particle.life / 0.18);
        colors[i * 3] = scratchColor.r * fade;
        colors[i * 3 + 1] = scratchColor.g * fade;
        colors[i * 3 + 2] = scratchColor.b * fade;
      }
      positionAttribute.needsUpdate = true;
      colorAttribute.needsUpdate = true;
      particleGeometry.setDrawRange(0, visibleParticles);

      const activePopupIds = new Set<number>();
      runtime.popups.forEach((popup) => {
        activePopupIds.add(popup.id);
        let sprite = popupSprites.get(popup.id);
        if (!sprite) {
          sprite = createPopupSprite(popup.text, popup.color);
          popupSprites.set(popup.id, sprite);
          scene.add(sprite);
        }
        sprite.position.set(popup.x, popup.y, popup.z + 0.4);
        sprite.material.opacity = Math.min(1, popup.life / 0.16);
        const scale = 1 + (1 - popup.life / popup.maxLife) * 0.16;
        sprite.scale.set((popup.text.length > 6 ? 2.45 : 1.85) * scale, 0.58 * scale, 1);
      });
      popupSprites.forEach((sprite, id) => {
        if (!activePopupIds.has(id)) {
          scene.remove(sprite);
          sprite.material.map?.dispose();
          sprite.material.dispose();
          popupSprites.delete(id);
        }
      });

      if (fightSprite) {
        fightSprite.visible = runtime.fightCue > 0 && mode === "playing";
        if (fightSprite.visible) {
          const scale = 1 + (0.9 - runtime.fightCue) * 0.15;
          fightSprite.scale.set(3.2 * scale, scale, 1);
          (fightSprite.material as THREE.SpriteMaterial).opacity = Math.min(1, runtime.fightCue * 2.2);
        }
      }

      const centerX = (runtime.player.x + runtime.enemy.x) * 0.5;
      const shakeX = runtime.shake > 0 ? (Math.random() - 0.5) * runtime.shake : 0;
      const shakeY = runtime.shake > 0 ? (Math.random() - 0.5) * runtime.shake * 0.45 : 0;
      camera.position.x += (centerX * 0.06 + shakeX - camera.position.x) * 0.06;
      camera.position.y += (baseCameraPosition.y + shakeY - camera.position.y) * 0.08;
      camera.position.z += (baseCameraPosition.z - camera.position.z) * 0.08;
      camera.lookAt(centerX * 0.04, cameraTarget.y, 0);
      renderer.render(scene, camera);
    },
    dispose() {
      observer.disconnect();
      popupSprites.forEach((sprite) => {
        sprite.material.map?.dispose();
        sprite.material.dispose();
      });
      renderer.dispose();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Line || object instanceof THREE.Points) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
      if (renderer.domElement.parentElement === host) host.removeChild(renderer.domElement);
    },
  };
}

export function roundLength(): number {
  return ROUND_LENGTH;
}