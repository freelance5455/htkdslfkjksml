import * as THREE from 'three';
import { Reflector } from 'three/examples/jsm/objects/Reflector.js';

export const ARENA_R = 8.4;

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function canvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return { c, g: c.getContext('2d')! };
}

function tex(c: HTMLCanvasElement, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

export function glowTexture() {
  const { c, g } = canvas(128, 128);
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,255,255,1)');
  gr.addColorStop(0.25, 'rgba(255,255,255,0.55)');
  gr.addColorStop(0.6, 'rgba(255,255,255,0.12)');
  gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  return tex(c);
}

function asphaltTexture() {
  const r = rng(7);
  const { c, g } = canvas(512, 512);
  g.fillStyle = '#26282c'; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 9000; i++) {
    const v = 20 + r() * 46;
    g.fillStyle = `rgba(${v},${v + 2},${v + 6},${0.25 + r() * 0.5})`;
    g.fillRect(r() * 512, r() * 512, 1 + r() * 2.5, 1 + r() * 2.5);
  }
  for (let i = 0; i < 14; i++) {
    g.strokeStyle = `rgba(5,5,7,${0.4 + r() * 0.4})`;
    g.lineWidth = 0.8 + r() * 1.6;
    g.beginPath();
    let x = r() * 512, y = r() * 512;
    g.moveTo(x, y);
    for (let k = 0; k < 9; k++) {
      x += (r() - 0.5) * 70; y += (r() - 0.5) * 70;
      g.lineTo(x, y);
    }
    g.stroke();
  }
  const t = tex(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(10, 10);
  return t;
}

function puddleMask() {
  const r = rng(21);
  const { c, g } = canvas(512, 512);
  g.fillStyle = 'rgb(190,190,190)'; g.fillRect(0, 0, 512, 512);
  const blob = (x: number, y: number, rad: number, v: number) => {
    const gr = g.createRadialGradient(x, y, rad * 0.2, x, y, rad);
    gr.addColorStop(0, `rgba(${v},${v},${v},1)`);
    gr.addColorStop(0.7, `rgba(${v},${v},${v},0.85)`);
    gr.addColorStop(1, `rgba(${v},${v},${v},0)`);
    g.fillStyle = gr;
    g.save();
    g.translate(x, y); g.scale(1 + r() * 0.8, 0.6 + r() * 0.5); g.translate(-x, -y);
    g.beginPath(); g.arc(x, y, rad, 0, Math.PI * 2); g.fill();
    g.restore();
  };
  // the ground plane is 50m => 512px; arena centre = 256,256 (r~8.4m = 86px)
  for (let i = 0; i < 22; i++) {
    const a = r() * Math.PI * 2, d = r() * 110;
    blob(256 + Math.cos(a) * d, 256 + Math.sin(a) * d, 22 + r() * 40, 30 + r() * 25);
  }
  for (let i = 0; i < 30; i++) blob(r() * 512, r() * 512, 15 + r() * 40, 35 + r() * 40);
  const t = tex(c, false);
  return t;
}

function skyTexture() {
  const r = rng(5);
  const { c, g } = canvas(1024, 512);
  const gr = g.createLinearGradient(0, 0, 0, 512);
  gr.addColorStop(0, '#03050a');
  gr.addColorStop(0.45, '#0a1220');
  gr.addColorStop(0.62, '#1b2a36');
  gr.addColorStop(0.75, '#2b3b44');
  gr.addColorStop(1, '#0d1317');
  g.fillStyle = gr; g.fillRect(0, 0, 1024, 512);
  for (let i = 0; i < 120; i++) {
    const x = r() * 1024, y = 120 + r() * 160, w = 80 + r() * 220, h = 14 + r() * 36;
    const cg = g.createRadialGradient(x, y, 0, x, y, w);
    cg.addColorStop(0, `rgba(60,75,90,${0.06 + r() * 0.08})`);
    cg.addColorStop(1, 'rgba(60,75,90,0)');
    g.fillStyle = cg;
    g.save(); g.translate(x, y); g.scale(1, h / w); g.translate(-x, -y);
    g.beginPath(); g.arc(x, y, w, 0, Math.PI * 2); g.fill(); g.restore();
  }
  // faint moon
  const mg = g.createRadialGradient(700, 190, 0, 700, 190, 90);
  mg.addColorStop(0, 'rgba(190,210,235,0.75)');
  mg.addColorStop(0.15, 'rgba(150,175,210,0.35)');
  mg.addColorStop(1, 'rgba(100,130,170,0)');
  g.fillStyle = mg; g.fillRect(550, 40, 300, 300);
  const t = tex(c);
  t.mapping = THREE.EquirectangularReflectionMapping;
  return t;
}

function facadeTexture(seed: number, base: string, accent: string) {
  const r = rng(seed);
  const { c, g } = canvas(256, 512);
  const { c: ce, g: ge } = canvas(256, 512);
  g.fillStyle = base; g.fillRect(0, 0, 256, 512);
  ge.fillStyle = '#000'; ge.fillRect(0, 0, 256, 512);
  for (let i = 0; i < 2500; i++) {
    const v = r() * 40;
    g.fillStyle = `rgba(${v},${v},${v},${0.15 + r() * 0.3})`;
    g.fillRect(r() * 256, r() * 512, 2 + r() * 8, 1 + r() * 4);
  }
  // streaks
  for (let i = 0; i < 30; i++) {
    g.fillStyle = `rgba(0,0,0,${0.1 + r() * 0.2})`;
    g.fillRect(r() * 256, r() * 300, 2 + r() * 4, 80 + r() * 260);
  }
  const cols = 6, rows = 14;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const px = 12 + x * 40, py = 14 + y * 36;
      g.fillStyle = '#05070a';
      g.fillRect(px, py, 24, 24);
      g.strokeStyle = accent; g.lineWidth = 2;
      g.strokeRect(px - 1, py - 1, 26, 26);
      const q = r();
      if (q < 0.07) {
        const warm = r() < 0.7;
        ge.fillStyle = warm ? `rgb(${190 + r() * 60},${110 + r() * 50},40)` : 'rgb(70,150,170)';
        ge.fillRect(px + 2, py + 2, 20, 20);
        g.fillStyle = warm ? '#7a5424' : '#2f5f6b';
        g.fillRect(px + 2, py + 2, 20, 20);
      } else if (q < 0.35) {
        g.fillStyle = '#0c1118';
        g.fillRect(px + 2, py + 2, 20, 9);
        g.strokeStyle = '#000';
        g.beginPath(); g.moveTo(px, py + 24); g.lineTo(px + 24, py); g.stroke();
      }
    }
  }
  return { map: tex(c), emi: tex(ce) };
}

function signTexture(text: string, color: string, bg: string, w = 512, h = 128) {
  const { c, g } = canvas(w, h);
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.strokeStyle = color; g.lineWidth = 6; g.strokeRect(8, 8, w - 16, h - 16);
  g.fillStyle = color;
  g.font = `900 ${h * 0.5}px Impact, "Arial Black", sans-serif`;
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, w / 2, h / 2 + 4);
  return tex(c);
}

export class Prop {
  mesh: THREE.Object3D;
  r: number;
  vel = new THREE.Vector3();
  av = 0;
  kind: 'crate' | 'barrel' | 'cone' | 'trash';
  hp = 2;
  broken = false;
  tip = 0;
  tilt = new THREE.Vector2();
  constructor(mesh: THREE.Object3D, r: number, kind: Prop['kind']) {
    this.mesh = mesh; this.r = r; this.kind = kind;
  }
}

interface Debris {
  m: THREE.Mesh; v: THREE.Vector3; w: THREE.Vector3; life: number;
}

export class Arena {
  scene: THREE.Scene;
  renderer: THREE.WebGLRenderer;
  group = new THREE.Group();
  props: Prop[] = [];
  debris: Debris[] = [];
  reflector: Reflector | null = null;
  groundMat!: THREE.MeshStandardMaterial;
  puddleMap!: THREE.Texture;
  moon!: THREE.DirectionalLight;
  hemi!: THREE.HemisphereLight;
  key!: THREE.SpotLight;
  rimA!: THREE.DirectionalLight;
  rimB!: THREE.DirectionalLight;
  fires: { light: THREE.PointLight; sprites: THREE.Sprite[]; seed: number }[] = [];
  lampMats: { mat: THREE.MeshBasicMaterial; halo: THREE.Sprite; seed: number }[] = [];
  flicker: { mat: THREE.MeshBasicMaterial; seed: number; a: number; b: number }[] = [];
  smoke: { s: THREE.Sprite; t: number; x: number; z: number }[] = [];
  rain!: THREE.LineSegments;
  rainMat!: THREE.ShaderMaterial;
  rainCount = 2200;
  flash = 0;
  nextFlash = 6;
  thunderCb: (() => void) | null = null;
  quality = 1;
  glow: THREE.Texture;
  time = 0;
  sirenMats: THREE.MeshBasicMaterial[] = [];
  sirenHalos: THREE.Sprite[] = [];
  bgTex: THREE.Texture;

  constructor(scene: THREE.Scene, renderer: THREE.WebGLRenderer) {
    this.scene = scene;
    this.renderer = renderer;
    this.glow = glowTexture();
    scene.add(this.group);
    this.bgTex = skyTexture();
    scene.background = this.bgTex;
    scene.fog = new THREE.FogExp2(0x0a1117, 0.034);
    this.buildEnvironmentMap();
    this.buildLights();
    this.buildGround();
    this.buildBuildings();
    this.buildProps();
    this.buildRain();
    this.buildDebris();
  }

  // ---- environment map used for glossy reflections on wet ground / chrome ----
  buildEnvironmentMap() {
    const env = new THREE.Scene();
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(50, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0x0d1822, side: THREE.BackSide }),
    );
    env.add(sky);
    const strip = (x: number, y: number, z: number, w: number, h: number, c: number, i: number) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(i), side: THREE.DoubleSide }));
      m.position.set(x, y, z);
      m.lookAt(0, 0, 0);
      env.add(m);
    };
    strip(12, 14, -8, 10, 3, 0xffd9a0, 3);
    strip(-14, 10, 10, 8, 3, 0x5ec0ff, 4);
    strip(0, 22, 0, 18, 18, 0x9ab4d8, 1.2);
    strip(10, 6, 18, 5, 4, 0xff8a7a, 0.7);
    strip(-10, 5, -16, 6, 2, 0xffa860, 1.5);
    const pm = new THREE.PMREMGenerator(this.renderer);
    const rt = pm.fromScene(env, 0.02);
    this.scene.environment = rt.texture;
    (this.scene as any).environmentIntensity = 0.45;
    pm.dispose();
    env.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) { m.geometry.dispose(); (m.material as THREE.Material).dispose(); }
    });
  }

  buildLights() {
    const s = this.scene;
    this.hemi = new THREE.HemisphereLight(0x5b7595, 0x1c1714, 0.95);
    s.add(this.hemi);

    this.moon = new THREE.DirectionalLight(0x9cb8e6, 1.5);
    this.moon.position.set(-9, 16, 8);
    this.moon.castShadow = true;
    this.moon.shadow.mapSize.set(1024, 1024);
    const sc = this.moon.shadow.camera;
    sc.left = -11; sc.right = 11; sc.top = 11; sc.bottom = -11; sc.near = 4; sc.far = 40;
    this.moon.shadow.bias = -0.0006;
    this.moon.shadow.normalBias = 0.03;
    s.add(this.moon);

    this.key = new THREE.SpotLight(0xffd2a0, 420, 0, 0.75, 0.7, 2);
    this.key.position.set(4.5, 9, -3);
    this.key.target.position.set(0, 0, 0);
    s.add(this.key, this.key.target);

    this.rimA = new THREE.DirectionalLight(0x3a68ff, 0.8);
    this.rimA.position.set(-6, 9, 8);
    this.rimB = new THREE.DirectionalLight(0xff6a2a, 0.6);
    this.rimB.position.set(7, 9, -8);
    s.add(this.rimA, this.rimB);
  }

  buildGround() {
    const asphalt = asphaltTexture();
    this.puddleMap = puddleMask();
    this.groundMat = new THREE.MeshStandardMaterial({
      color: 0xb8bcc4,
      map: asphalt,
      roughness: 1.0,
      roughnessMap: this.puddleMap,
      metalness: 0.25,
      alphaMap: this.puddleMap,
      transparent: true,
      envMapIntensity: 1.6,
    });
    this.groundMat.envMap = this.scene.environment;
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(50, 50), this.groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    ground.receiveShadow = true;
    ground.renderOrder = 1;
    this.group.add(ground);

    // outer dark floor so nothing beyond is missing
    const outer = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: 0x0b0d10, roughness: 0.6 }));
    outer.rotation.x = -Math.PI / 2;
    outer.position.y = -0.03;
    this.group.add(outer);

    try {
      const refl = new Reflector(new THREE.PlaneGeometry(50, 50), {
        color: 0x8a95a0,
        textureWidth: 512,
        textureHeight: 256,
        clipBias: 0.004,
      });
      refl.rotation.x = -Math.PI / 2;
      refl.position.y = -0.012;
      // avoid re-rendering shadow maps in the mirrored pass
      const orig = refl.onBeforeRender.bind(refl);
      refl.onBeforeRender = (r: any, sc: any, cam: any, g: any, m: any, gr: any) => {
        const sm = r.shadowMap;
        const au = sm.autoUpdate, nu = sm.needsUpdate;
        sm.autoUpdate = false; sm.needsUpdate = false;
        try { orig(r, sc, cam, g, m, gr); } finally { sm.autoUpdate = au; sm.needsUpdate = nu; }
      };
      this.reflector = refl;
      this.group.add(refl);
    } catch (e) {
      console.warn('Reflector unavailable', e);
      this.reflector = null;
    }

    // road markings
    const paint = new THREE.MeshStandardMaterial({ color: 0xb9b49a, roughness: 0.6, transparent: true, opacity: 0.55, polygonOffset: true, polygonOffsetFactor: -2 });
    const yellow = new THREE.MeshStandardMaterial({ color: 0xc2a02a, roughness: 0.6, transparent: true, opacity: 0.55, polygonOffset: true, polygonOffsetFactor: -2 });
    const strip = (x: number, z: number, w: number, d: number, m: THREE.Material) => {
      const p = new THREE.Mesh(new THREE.PlaneGeometry(w, d), m);
      p.rotation.x = -Math.PI / 2;
      p.position.set(x, 0.006, z);
      p.receiveShadow = true;
      p.renderOrder = 2;
      this.group.add(p);
    };
    for (let i = -4; i <= 4; i++) strip(i * 1.2, -11.4, 0.6, 3.0, paint);
    for (let i = -4; i <= 4; i++) strip(i * 1.2, 11.4, 0.6, 3.0, paint);
    for (let i = 0; i < 6; i++) { strip(-24 + i * 3.2 - 5, 0.2, 1.8, 0.14, yellow); strip(-24 + i * 3.2 - 5, -0.2, 1.8, 0.14, yellow); }
    for (let i = 0; i < 6; i++) { strip(12 + i * 3.2, 0.2, 1.8, 0.14, yellow); strip(12 + i * 3.2, -0.2, 1.8, 0.14, yellow); }

    // arena ring painted marking (subtle)
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(ARENA_R + 0.2, ARENA_R + 0.35, 64),
      new THREE.MeshBasicMaterial({ color: 0x701018, transparent: true, opacity: 0.35, depthWrite: false }),
    );
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.01; ring.renderOrder = 3;
    this.group.add(ring);

    // manhole + steam
    const mh = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.04, 20), new THREE.MeshStandardMaterial({ color: 0x1d1f22, roughness: 0.5, metalness: 0.8 }));
    mh.position.set(-3.2, 0.02, 3.4);
    mh.receiveShadow = true;
    this.group.add(mh);
    for (let i = 0; i < 5; i++) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glow, color: 0x7f8a92, transparent: true, opacity: 0.0, depthWrite: false }));
      this.group.add(sp);
      this.smoke.push({ s: sp, t: i / 5, x: -3.2, z: 3.4 });
    }

  }

  buildBuildings() {
    const r = rng(33);
    const variants = [
      facadeTexture(1, '#2a2926', '#15130f'),
      facadeTexture(2, '#2b2f33', '#101214'),
      facadeTexture(3, '#33241f', '#150e0b'),
      facadeTexture(4, '#222c2c', '#0d1313'),
    ];
    const mats = variants.map((v) => new THREE.MeshStandardMaterial({
      map: v.map, emissiveMap: v.emi, emissive: 0xffffff, emissiveIntensity: 0.45, roughness: 0.9, metalness: 0.05,
    }));
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x121416, roughness: 0.9 });
    const n = 22;
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + r() * 0.05;
      // keep gaps for the 4 streets
      const q = ((ang + Math.PI / 4) % (Math.PI / 2)) / (Math.PI / 2);
      void q;
      const sx = Math.cos(ang), sz = Math.sin(ang);
      if (Math.abs(sx) > 0.94 || Math.abs(sz) > 0.94) continue;
      const w = 9 + r() * 4, h = 14 + r() * 20, d = 9 + r() * 4;
      const dist = 17.5 + r() * 3;
      const m = mats[Math.floor(r() * mats.length)];
      const mt = m.clone();
      mt.map = m.map!.clone(); mt.emissiveMap = m.emissiveMap!.clone();
      mt.map.needsUpdate = true; mt.emissiveMap.needsUpdate = true;
      mt.map.wrapS = mt.map.wrapT = THREE.RepeatWrapping;
      mt.emissiveMap.wrapS = mt.emissiveMap.wrapT = THREE.RepeatWrapping;
      mt.map.repeat.set(w / 9, h / 14);
      mt.emissiveMap.repeat.set(w / 9, h / 14);
      const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), [mt, mt, roofMat, roofMat, mt, mt]);
      b.position.set(sx * dist, h / 2 - 0.5, sz * dist);
      b.lookAt(0, h / 2 - 0.5, 0);
      b.receiveShadow = false;
      this.group.add(b);
    }

    // far skyline silhouettes
    const far = new THREE.MeshBasicMaterial({ color: 0x070b10 });
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2 + r() * 0.2;
      const h = 18 + r() * 30;
      const m = new THREE.Mesh(new THREE.BoxGeometry(7 + r() * 8, h, 7 + r() * 6), far);
      m.position.set(Math.cos(a) * 46, h / 2, Math.sin(a) * 46);
      this.group.add(m);
    }
  }

  addLamp(x: number, z: number, rot: number, broken = false) {
    const pole = new THREE.MeshStandardMaterial({ color: 0x1c1f22, roughness: 0.5, metalness: 0.7 });
    const g = new THREE.Group();
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.09, 6.4, 8), pole);
    p.position.y = 3.2; p.castShadow = true; g.add(p);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.07, 0.07), pole);
    arm.position.set(0.7, 6.35, 0); g.add(arm);
    const bulbMat = new THREE.MeshBasicMaterial({ color: broken ? 0x806040 : 0xffd9a0 });
    const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.22), bulbMat);
    bulb.position.set(1.3, 6.28, 0); g.add(bulb);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glow, color: 0xffc680, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }));
    halo.scale.set(3.4, 3.4, 1); halo.position.set(1.3, 6.2, 0); g.add(halo);
    g.position.set(x, 0, z);
    g.rotation.y = rot;
    this.group.add(g);
    this.lampMats.push({ mat: bulbMat, halo, seed: Math.random() * 100 });
    if (broken) g.rotation.z = 0.06;
  }

  addFire(x: number, z: number) {
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.3, 0.9, 12), new THREE.MeshStandardMaterial({ color: 0x3b2a20, roughness: 0.6, metalness: 0.6 }));
    barrel.position.set(x, 0.45, z);
    barrel.castShadow = true;
    this.group.add(barrel);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.025, 6, 14), new THREE.MeshStandardMaterial({ color: 0x555a5e, metalness: 0.9, roughness: 0.4 }));
    rim.rotation.x = Math.PI / 2; rim.position.set(x, 0.9, z); this.group.add(rim);
    const sprites: THREE.Sprite[] = [];
    for (let i = 0; i < 4; i++) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glow, color: i < 2 ? 0xff7a1a : 0xffc04a, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
      sp.position.set(x, 1.1, z);
      this.group.add(sp);
      sprites.push(sp);
    }
    const light = new THREE.PointLight(0xff7a30, 30, 11, 2);
    light.position.set(x, 1.5, z);
    this.group.add(light);
    this.fires.push({ light, sprites, seed: Math.random() * 50 });
  }

  addCar(x: number, z: number, rot: number, color: number, police = false) {
    const g = new THREE.Group();
    const body = new THREE.MeshStandardMaterial({ color, roughness: 0.35, metalness: 0.6 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x0a0c0e, roughness: 0.2, metalness: 0.5 });
    const lower = new THREE.Mesh(new THREE.BoxGeometry(4.3, 0.7, 1.8), body);
    lower.position.y = 0.6; lower.castShadow = true; g.add(lower);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.62, 1.6), dark);
    cab.position.set(-0.2, 1.2, 0); g.add(cab);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.06, 1.65), body);
    roof.position.set(-0.2, 1.53, 0); g.add(roof);
    const wm = new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 0.9 });
    for (const sx of [-1.35, 1.35]) for (const sz of [-0.9, 0.9]) {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.25, 12), wm);
      w.rotation.x = Math.PI / 2; w.position.set(sx, 0.34, sz); g.add(w);
    }
    for (const sz of [-0.6, 0.6]) {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 0.3), new THREE.MeshBasicMaterial({ color: 0x909070 }));
      hl.position.set(2.16, 0.7, sz); g.add(hl);
    }
    if (police) {
      const s1 = new THREE.MeshBasicMaterial({ color: 0xff1010 });
      const s2 = new THREE.MeshBasicMaterial({ color: 0x1030ff });
      const l1 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.12, 0.45), s1); l1.position.set(-0.2, 1.62, 0.4);
      const l2 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.12, 0.45), s2); l2.position.set(-0.2, 1.62, -0.4);
      g.add(l1, l2);
      this.sirenMats.push(s1, s2);
      for (const [c, z] of [[0xff2020, 0.4], [0x2050ff, -0.4]] as const) {
        const h = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glow, color: c, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }));
        h.scale.set(2.6, 2.6, 1); h.position.set(-0.2, 1.7, z); g.add(h);
        this.sirenHalos.push(h);
      }
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.32, 0.25, 1.82), new THREE.MeshStandardMaterial({ color: 0xe8e8e8, roughness: 0.4 }));
      stripe.position.y = 0.62; g.add(stripe);
    }
    g.position.set(x, 0, z);
    g.rotation.y = rot;
    // slight wreck tilt
    g.rotation.z = (Math.random() - 0.5) * 0.04;
    this.group.add(g);
  }

  buildProps() {
    const r = rng(77);
    // street lamps
    this.addLamp(-9.6, -5, Math.PI, false);
    this.addLamp(9.8, 4, 0, true);
    this.addLamp(-6, 10.5, Math.PI / 2 * 3, false);
    this.addLamp(7, -10.8, Math.PI / 2, false);
    // fires
    this.addFire(-8.9, 0.8);
    this.addFire(8.6, -3.2);
    // wrecked cars and police
    this.addCar(0, 14.2, Math.PI / 2 + 0.15, 0x5b1214);
    this.addCar(-12, 9.5, -0.7, 0x20303a, true);
    this.addCar(13, 7, -0.5, 0x2f3033);
    this.addCar(0, -15, Math.PI / 2 - 0.12, 0x3b3a2c);

    // concrete barriers + sandbags + fences around the rim
    const conc = new THREE.MeshStandardMaterial({ color: 0x55575a, roughness: 0.95 });
    const sand = new THREE.MeshStandardMaterial({ color: 0x6d6248, roughness: 1 });
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2 + 0.2;
      const d = 10.3 + r() * 0.8;
      if (i % 3 === 0) {
        const b = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.9, 0.5), conc);
        b.position.set(Math.cos(a) * d, 0.45, Math.sin(a) * d);
        b.rotation.y = -a + Math.PI / 2 + (r() - 0.5) * 0.3;
        b.castShadow = true; b.receiveShadow = true;
        this.group.add(b);
      } else if (i % 3 === 1) {
        for (let k = 0; k < 6; k++) {
          const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.4, 3, 6), sand);
          s.rotation.z = Math.PI / 2;
          s.position.set(Math.cos(a) * d + Math.cos(a + 1.57) * ((k % 3) * 0.55 - 0.55), 0.18 + Math.floor(k / 3) * 0.3, Math.sin(a) * d + Math.sin(a + 1.57) * ((k % 3) * 0.55 - 0.55));
          s.rotation.y = -a;
          s.castShadow = true;
          this.group.add(s);
        }
      } else {
        const fm = new THREE.MeshStandardMaterial({ color: 0x2a2d2f, metalness: 0.8, roughness: 0.5, wireframe: true });
        const f = new THREE.Mesh(new THREE.BoxGeometry(3, 1.8, 0.02), fm);
        f.position.set(Math.cos(a) * d, 0.9, Math.sin(a) * d);
        f.rotation.y = -a + Math.PI / 2;
        this.group.add(f);
      }
    }

    // billboard & neon signs
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(7, 1.75), new THREE.MeshBasicMaterial({ map: signTexture('RACCOON CITY', '#d8d0b0', '#121212') }));
    sign.position.set(-16.2, 8.4, 6);
    sign.lookAt(0, 6, 0);
    this.group.add(sign);
    const qm = new THREE.MeshBasicMaterial({ map: signTexture('QUARANTINE', '#ff3a2a', '#1a0505', 384, 96) });
    const q1 = new THREE.Mesh(new THREE.PlaneGeometry(4.5, 1.1), qm);
    q1.position.set(14.2, 4.8, -9);
    q1.lookAt(0, 4, 0);
    this.group.add(q1);
    this.flicker.push({ mat: qm, seed: 3, a: 0.4, b: 1 });
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glow, color: 0xff2a1a, transparent: true, opacity: 0.1, blending: THREE.AdditiveBlending, depthWrite: false }));
    halo.scale.set(6, 3, 1); halo.position.copy(q1.position); halo.position.multiplyScalar(0.97);
    this.group.add(halo);

    // destructible props: crates and barrels
    const crateMat = new THREE.MeshStandardMaterial({ color: 0x6b4a2b, roughness: 0.85 });
    const crateBand = new THREE.MeshStandardMaterial({ color: 0x2b2118, roughness: 0.9 });
    const barrelMat = new THREE.MeshStandardMaterial({ color: 0x2f4a3a, roughness: 0.55, metalness: 0.5 });
    const barrelRed = new THREE.MeshStandardMaterial({ color: 0x7a1a14, roughness: 0.55, metalness: 0.5 });
    const mkCrate = (x: number, z: number, s: number, rot: number) => {
      const g = new THREE.Group();
      const b = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), crateMat);
      b.castShadow = true; b.receiveShadow = true;
      g.add(b);
      for (const k of [-1, 1]) {
        const bd = new THREE.Mesh(new THREE.BoxGeometry(s * 1.02, s * 0.1, s * 1.02), crateBand);
        bd.position.y = k * s * 0.38; g.add(bd);
      }
      g.position.set(x, s / 2, z);
      g.rotation.y = rot;
      this.group.add(g);
      const p = new Prop(g, s * 0.75, 'crate');
      p.hp = 3;
      (p as any).h = s / 2;
      this.props.push(p);
    };
    const mkBarrel = (x: number, z: number, red: boolean) => {
      const g = new THREE.Group();
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.3, 0.9, 12), red ? barrelRed : barrelMat);
      b.castShadow = true;
      g.add(b);
      for (const k of [-0.28, 0, 0.28]) {
        const rg = new THREE.Mesh(new THREE.TorusGeometry(0.315, 0.018, 5, 14), crateBand);
        rg.rotation.x = Math.PI / 2; rg.position.y = k; g.add(rg);
      }
      g.position.set(x, 0.45, z);
      this.group.add(g);
      const p = new Prop(g, 0.4, 'barrel');
      p.hp = 4;
      (p as any).h = 0.45;
      this.props.push(p);
    };
    mkCrate(-6.2, -5.4, 0.9, 0.3);
    mkCrate(-6.9, -4.5, 0.7, 0.9);
    mkCrate(6.4, 5.4, 1.0, -0.4);
    mkCrate(5.4, 6.4, 0.7, 0.2);
    mkCrate(3.6, -7.2, 0.8, 0.5);
    mkBarrel(-7.2, 3.6, false);
    mkBarrel(-6.7, 4.4, true);
    mkBarrel(7.1, -1.3, true);
    mkBarrel(-3.4, -7.4, false);
    mkBarrel(2.0, 7.9, true);
    // traffic cones
    const coneMat = new THREE.MeshStandardMaterial({ color: 0xd8501a, roughness: 0.6 });
    for (let i = 0; i < 4; i++) {
      const c = new THREE.Mesh(new THREE.ConeGeometry(0.17, 0.5, 10), coneMat);
      const a = r() * Math.PI * 2, d = 6 + r() * 2;
      c.position.set(Math.cos(a) * d, 0.25, Math.sin(a) * d);
      c.castShadow = true;
      this.group.add(c);
      const p = new Prop(c, 0.22, 'cone');
      p.hp = 99;
      (p as any).h = 0.25;
      this.props.push(p);
    }
    // scattered debris/paper
    const paper = new THREE.MeshStandardMaterial({ color: 0x8c8a80, roughness: 1 });
    for (let i = 0; i < 26; i++) {
      const p = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.2), paper);
      p.rotation.x = -Math.PI / 2; p.rotation.z = r() * 6;
      const a = r() * Math.PI * 2, d = r() * 11;
      p.position.set(Math.cos(a) * d, 0.012, Math.sin(a) * d);
      this.group.add(p);
    }
  }

  buildDebris() {
    const g = new THREE.BoxGeometry(0.16, 0.06, 0.06);
    const m = new THREE.MeshStandardMaterial({ color: 0x7a5530, roughness: 0.9 });
    for (let i = 0; i < 28; i++) {
      const mesh = new THREE.Mesh(g, m);
      mesh.visible = false;
      mesh.castShadow = true;
      this.group.add(mesh);
      this.debris.push({ m: mesh, v: new THREE.Vector3(), w: new THREE.Vector3(), life: 0 });
    }
  }

  buildRain() {
    const N = 3600;
    const pos = new Float32Array(N * 2 * 3);
    const end = new Float32Array(N * 2);
    const rr = rng(99);
    for (let i = 0; i < N; i++) {
      const x = (rr() - 0.5) * 30, y = rr() * 22, z = (rr() - 0.5) * 30;
      pos.set([x, y, z, x, y, z], i * 6);
      end[i * 2] = 0; end[i * 2 + 1] = 1;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aEnd', new THREE.BufferAttribute(end, 1));
    this.rainMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: { uTime: { value: 0 }, uCenter: { value: new THREE.Vector3() }, uAlpha: { value: 0.22 } },
      vertexShader: `
        uniform float uTime; uniform vec3 uCenter; attribute float aEnd; varying float vA;
        void main(){
          vec3 p = position;
          p.y = mod(p.y - uTime * 26.0, 22.0);
          p.x += p.y * 0.12;
          p.xz = mod(p.xz - uCenter.xz + 15.0, 30.0) - 15.0 + uCenter.xz;
          p.y += aEnd * 0.75;
          p.x -= aEnd * 0.09;
          vA = 1.0 - aEnd * 0.8;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          vA *= 1.0 - smoothstep(4.0, 32.0, -mv.z);
        }`,
      fragmentShader: `
        uniform float uAlpha; varying float vA;
        void main(){ gl_FragColor = vec4(0.68, 0.78, 0.9, uAlpha * vA); }`,
    });
    this.rain = new THREE.LineSegments(geo, this.rainMat);
    this.rain.frustumCulled = false;
    this.rain.renderOrder = 10;
    this.scene.add(this.rain);
    this.setRainCount(this.rainCount);
  }

  setRainCount(n: number) {
    this.rainCount = n;
    this.rain.geometry.setDrawRange(0, n * 2);
  }

  setQuality(q: number, w: number, h: number, pr: number) {
    this.quality = q;
    this.setRainCount([700, 1800, 3600][q]);
    const useRefl = q >= 1 && !!this.reflector;
    if (this.reflector) {
      this.reflector.visible = useRefl;
      const scale = q === 1 ? 0.32 : 0.55;
      this.reflector.getRenderTarget().setSize(Math.max(64, Math.floor(w * pr * scale)), Math.max(64, Math.floor(h * pr * scale)));
    }
    const gm = this.groundMat;
    const wantAlpha = useRefl;
    if (gm.transparent !== wantAlpha) {
      gm.transparent = wantAlpha;
      gm.alphaMap = wantAlpha ? this.puddleMap : null;
      gm.needsUpdate = true;
    }
    this.moon.castShadow = true;
    const size = q === 0 ? 512 : q === 1 ? 1024 : 2048;
    if (this.moon.shadow.mapSize.x !== size) {
      this.moon.shadow.mapSize.set(size, size);
      this.moon.shadow.map?.dispose();
      this.moon.shadow.map = null;
    }
    this.rimB.visible = q >= 1;
    this.fires[1] && (this.fires[1].light.visible = q >= 1);
  }

  // ---- props physics ----
  pushProp(p: Prop, dir: THREE.Vector3, speed: number) {
    if (p.broken) return;
    p.vel.x += dir.x * speed;
    p.vel.z += dir.z * speed;
    p.av += (Math.random() - 0.5) * speed * 0.8;
    p.tip = Math.min(1, p.tip + speed * 0.12);
    p.tilt.set((Math.random() - 0.5) * 0.7, (Math.random() - 0.5) * 0.7);
  }

  damageProp(p: Prop, dmg: number, emit: (pos: THREE.Vector3) => void) {
    if (p.broken || p.kind === 'cone') return;
    p.hp -= dmg;
    if (p.hp <= 0) {
      p.broken = true;
      p.mesh.visible = false;
      const pos = p.mesh.position;
      emit(pos);
      let n = 0;
      for (const d of this.debris) {
        if (d.life > 0) continue;
        d.life = 2.5 + Math.random();
        d.m.visible = true;
        d.m.position.set(pos.x, 0.5 + Math.random() * 0.4, pos.z);
        d.v.set((Math.random() - 0.5) * 6, 2 + Math.random() * 4, (Math.random() - 0.5) * 6);
        d.w.set(Math.random() * 12, Math.random() * 12, Math.random() * 12);
        d.m.scale.setScalar(0.7 + Math.random() * 1.2);
        if (++n >= 9) break;
      }
    }
  }

  update(dt: number, camPos: THREE.Vector3) {
    this.time += dt;
    const t = this.time;
    this.rainMat.uniforms.uTime.value = t;
    this.rainMat.uniforms.uCenter.value.copy(camPos);

    // lightning
    this.nextFlash -= dt;
    if (this.nextFlash < 0) {
      this.flash = 1;
      this.nextFlash = 9 + Math.random() * 14;
      setTimeout(() => this.thunderCb && this.thunderCb(), 500 + Math.random() * 900);
    }
    this.flash = Math.max(0, this.flash - dt * 2.2);
    const fl = this.flash > 0 ? this.flash * (0.6 + 0.4 * Math.sin(t * 60)) : 0;
    this.hemi.intensity = 0.95 + fl * 3.5;
    this.moon.intensity = 1.5 + fl * 3;
    (this.scene as any).backgroundIntensity = 1 + fl * 2.5;

    // lamps flicker
    for (const l of this.lampMats) {
      const n = Math.sin(t * 17 + l.seed) * Math.sin(t * 5.3 + l.seed * 2);
      const on = n > -0.82 ? 1 : 0.25;
      l.halo.material.opacity = 0.5 * on + 0.3;
      l.mat.color.setScalar(0.45 + 0.55 * on).multiply(new THREE.Color(1, 0.85, 0.6));
    }
    this.key.intensity = 420 * (0.92 + 0.08 * Math.sin(t * 23) * Math.sin(t * 3.1)) + fl * 300;
    for (const f of this.flicker) {
      const v = Math.sin(t * 31 + f.seed) > 0.8 || Math.sin(t * 2 + f.seed) > 0.97 ? f.a : f.b;
      f.mat.color.setScalar(v);
    }
    // fires
    for (const f of this.fires) {
      const n = 0.75 + 0.25 * Math.sin(t * 13 + f.seed) * Math.sin(t * 7.1 + f.seed);
      f.light.intensity = 30 * n;
      f.sprites.forEach((s, i) => {
        const ph = (t * (1.6 + i * 0.3) + i * 0.37 + f.seed) % 1;
        s.position.y = 1.0 + ph * 0.9;
        s.position.x += (Math.sin(t * 9 + i) * 0.002);
        const sz = (1 - ph) * (0.9 + i * 0.1) + 0.2;
        s.scale.set(sz, sz * 1.4, 1);
        s.material.opacity = 0.9 * (1 - ph);
      });
    }
    // sirens
    if (this.sirenMats.length) {
      const a = Math.sin(t * 9) > 0 ? 1 : 0.1;
      this.sirenMats[0].color.setRGB(1 * a, 0.05, 0.05);
      this.sirenMats[1].color.setRGB(0.05, 0.15, 1 * (1.1 - a));
      this.sirenHalos[0].material.opacity = 0.9 * a;
      this.sirenHalos[1].material.opacity = 0.9 * (1.1 - a);
      this.sirenHalos[2] && (this.sirenHalos[2].material.opacity = 0.9 * a);
      this.sirenHalos[3] && (this.sirenHalos[3].material.opacity = 0.9 * (1.1 - a));
    }
    // steam
    for (const s of this.smoke) {
      s.t = (s.t + dt * 0.18) % 1;
      s.s.position.set(s.x + Math.sin(s.t * 6) * 0.2, 0.2 + s.t * 2.8, s.z);
      const sz = 0.6 + s.t * 2.4;
      s.s.scale.set(sz, sz, 1);
      s.s.material.opacity = Math.sin(s.t * Math.PI) * 0.22;
    }

    // props
    for (const p of this.props) {
      if (p.broken) continue;
      const m = p.mesh;
      const h = (p as any).h as number;
      const sp = Math.hypot(p.vel.x, p.vel.z);
      if (sp > 0.02 || Math.abs(p.av) > 0.02) {
        m.position.x += p.vel.x * dt;
        m.position.z += p.vel.z * dt;
        const f = Math.exp(-2.4 * dt);
        p.vel.multiplyScalar(f);
        p.av *= Math.exp(-2.5 * dt);
        m.rotation.y += p.av * dt;
        const d = Math.hypot(m.position.x, m.position.z);
        if (d > ARENA_R + 1.5) {
          const nx = m.position.x / d, nz = m.position.z / d;
          m.position.x = nx * (ARENA_R + 1.5);
          m.position.z = nz * (ARENA_R + 1.5);
          const dot = p.vel.x * nx + p.vel.z * nz;
          if (dot > 0) { p.vel.x -= 1.6 * dot * nx; p.vel.z -= 1.6 * dot * nz; }
        }
      }
      if (p.kind === 'barrel') {
        const target = p.tip > 0.5 ? Math.PI / 2 : 0;
        m.rotation.z += (target - m.rotation.z) * Math.min(1, dt * 6);
        const ty = target > 0.1 ? 0.31 : h;
        m.position.y += (ty - m.position.y) * Math.min(1, dt * 8);
        if (sp < 0.05 && p.tip < 0.5) m.rotation.z *= 0.9;
      } else if (p.kind === 'crate') {
        const k = Math.min(1, sp * 0.25);
        m.rotation.x += (p.tilt.x * k - m.rotation.x) * Math.min(1, dt * 7);
        m.rotation.z += (p.tilt.y * k - m.rotation.z) * Math.min(1, dt * 7);
        m.position.y = h + Math.abs(Math.sin(t * 8)) * 0.0 + (sp > 1 ? 0.04 : 0);
      }
      if (sp < 0.1) p.tip = Math.max(p.tip, p.kind === 'barrel' ? p.tip : 0);
    }
    for (const d of this.debris) {
      if (d.life <= 0) continue;
      d.life -= dt;
      d.v.y -= 14 * dt;
      d.m.position.addScaledVector(d.v, dt);
      if (d.m.position.y < 0.04) {
        d.m.position.y = 0.04;
        d.v.y *= -0.3; d.v.x *= 0.6; d.v.z *= 0.6; d.w.multiplyScalar(0.6);
      }
      d.m.rotation.x += d.w.x * dt; d.m.rotation.y += d.w.y * dt; d.m.rotation.z += d.w.z * dt;
      if (d.life <= 0) d.m.visible = false;
    }
  }
}
