import * as THREE from "three";
import type { ArenaId, Quality } from "./types";
import { ARENAS } from "./types";
import { bannerTexture, flameTexture, floorTextures, glowTexture, stoneTexture } from "./textures";

export interface Arena {
  group: THREE.Group;
  update: (dt: number, elapsed: number) => void;
  dispose: () => void;
  sun: THREE.DirectionalLight;
}

const TAU = Math.PI * 2;

export function buildArena(scene: THREE.Scene, id: ArenaId, quality: Quality): Arena {
  const pal = ARENAS[id];
  const group = new THREE.Group();
  group.name = `arena-${id}`;
  scene.add(group);
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const animated: { obj: THREE.Object3D; kind: string; seed: number; base?: number }[] = [];
  const flames: { sprite: THREE.Sprite; light?: THREE.PointLight; seed: number }[] = [];
  const G = <T extends THREE.BufferGeometry>(g: T) => {
    geos.push(g);
    return g;
  };
  const M = <T extends THREE.Material>(m: T): T => {
    mats.push(m);
    return m;
  };

  const stoneTex = stoneTexture(id);
  const floor = floorTextures(id);
  const stoneMat = M(
    new THREE.MeshStandardMaterial({ color: pal.stone, map: stoneTex, roughness: 0.92, metalness: 0.06 })
  );
  const darkStoneMat = M(
    new THREE.MeshStandardMaterial({ color: pal.stoneDark, map: stoneTex, roughness: 0.95, metalness: 0.04 })
  );
  const trimMat = M(new THREE.MeshStandardMaterial({ color: pal.trim, metalness: 0.95, roughness: 0.32 }));
  const runeMat = M(
    new THREE.MeshStandardMaterial({
      color: pal.rune,
      emissive: pal.rune,
      emissiveIntensity: 2.2,
      toneMapped: false,
      roughness: 0.4,
    })
  );
  const emberMat = M(
    new THREE.MeshStandardMaterial({
      color: pal.ember,
      emissive: pal.ember,
      emissiveIntensity: 1.6,
      toneMapped: false,
    })
  );
  const bannerMat = M(
    new THREE.MeshStandardMaterial({
      map: bannerTexture(id),
      roughness: 0.95,
      metalness: 0,
      side: THREE.DoubleSide,
      transparent: true,
      alphaTest: 0.45,
    })
  );

  // ── sky dome ─────────────────────────────────────────────────────
  const skyGeo = G(new THREE.SphereGeometry(120, 24, 16));
  const skyMat = M(
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        top: { value: new THREE.Color(pal.sky).multiplyScalar(0.55) },
        bottom: { value: new THREE.Color(pal.fog) },
        glow: { value: new THREE.Color(pal.rune) },
      },
      vertexShader: `varying vec3 vPos; void main(){ vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `
        uniform vec3 top; uniform vec3 bottom; uniform vec3 glow; varying vec3 vPos;
        void main(){
          float h = normalize(vPos).y;
          vec3 col = mix(bottom, top, smoothstep(-0.15, 0.7, h));
          float horizon = exp(-abs(h)*9.0);
          col += glow * horizon * 0.16;
          float band = smoothstep(0.02, 0.0, abs(h-0.02));
          col += glow * band * 0.05;
          gl_FragColor = vec4(col, 1.0);
        }`,
    })
  );
  const sky = new THREE.Mesh(skyGeo, skyMat);
  group.add(sky);

  // ── distant mountains / temple silhouettes ───────────────────────
  const detailed = quality !== "low";
  const mountainMat = M(new THREE.MeshStandardMaterial({ color: pal.stoneDark, roughness: 1, metalness: 0 }));
  const mountainCount = detailed ? 16 : 10;
  for (let i = 0; i < mountainCount; i++) {
    const a = (i / mountainCount) * TAU + 0.2;
    const r = 46 + Math.random() * 22;
    const h = 12 + Math.random() * 26;
    const m = new THREE.Mesh(G(new THREE.ConeGeometry(8 + Math.random() * 9, h, 5)), mountainMat);
    m.position.set(Math.cos(a) * r, h / 2 - 6, Math.sin(a) * r);
    m.rotation.y = Math.random() * TAU;
    group.add(m);
  }
  // giant background arch
  const archMat = darkStoneMat;
  const arch = new THREE.Group();
  arch.position.set(0, 0, -26);
  const archGeo = G(new THREE.TorusGeometry(8, 1.1, 8, 24, Math.PI));
  const archTop = new THREE.Mesh(archGeo, archMat);
  archTop.position.y = 9;
  arch.add(archTop);
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(G(new THREE.CylinderGeometry(1.1, 1.4, 9, 10)), archMat);
    leg.position.set(8 * s, 4.5, 0);
    arch.add(leg);
    const cap = new THREE.Mesh(G(new THREE.BoxGeometry(3.2, 0.8, 3.2)), trimMat);
    cap.position.set(8 * s, 9.2, 0);
    arch.add(cap);
  }
  group.add(arch);

  // ── arena platform ───────────────────────────────────────────────
  const base = new THREE.Mesh(G(new THREE.CylinderGeometry(9.4, 10.2, 1.4, 64)), darkStoneMat);
  base.position.y = -0.7;
  base.receiveShadow = true;
  group.add(base);
  for (let i = 0; i < 3; i++) {
    const step = new THREE.Mesh(G(new THREE.CylinderGeometry(9.6 + i * 0.7, 9.9 + i * 0.7, 0.26, 64)), stoneMat);
    step.position.y = -0.13 - i * 0.26;
    step.receiveShadow = true;
    group.add(step);
  }
  const floorMat = M(
    new THREE.MeshStandardMaterial({
      map: floor.map,
      emissiveMap: floor.emissive,
      emissive: new THREE.Color(pal.rune),
      emissiveIntensity: 1.15,
      color: 0xffffff,
      roughness: 0.78,
      metalness: 0.18,
    })
  );
  const floorMesh = new THREE.Mesh(G(new THREE.CircleGeometry(9.35, 64)), floorMat);
  floorMesh.rotation.x = -Math.PI / 2;
  floorMesh.position.y = 0.005;
  floorMesh.receiveShadow = true;
  group.add(floorMesh);

  const rim = new THREE.Mesh(G(new THREE.TorusGeometry(9.3, 0.1, 8, 96)), trimMat);
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 0.03;
  group.add(rim);
  const rimGlow = new THREE.Mesh(G(new THREE.TorusGeometry(9.05, 0.035, 6, 96)), runeMat);
  rimGlow.rotation.x = Math.PI / 2;
  rimGlow.position.y = 0.04;
  group.add(rimGlow);

  // boundary rune stones
  for (let i = 0; i < 20; i++) {
    const a = (i / 20) * TAU;
    const stone = new THREE.Mesh(G(new THREE.BoxGeometry(0.34, 0.5, 0.22)), darkStoneMat);
    stone.position.set(Math.cos(a) * 8.9, 0.22, Math.sin(a) * 8.9);
    stone.rotation.y = -a;
    stone.castShadow = true;
    group.add(stone);
    const cap = new THREE.Mesh(G(new THREE.BoxGeometry(0.2, 0.05, 0.12)), runeMat);
    cap.position.set(Math.cos(a) * 8.9, 0.49, Math.sin(a) * 8.9);
    cap.rotation.y = -a;
    group.add(cap);
  }

  // rotating magic circle
  const circle = new THREE.Group();
  circle.position.y = 0.03;
  const cRing1 = new THREE.Mesh(G(new THREE.RingGeometry(3.1, 3.18, 64)), runeMat);
  cRing1.rotation.x = -Math.PI / 2;
  circle.add(cRing1);
  const cRing2 = new THREE.Mesh(G(new THREE.RingGeometry(3.5, 3.54, 64)), runeMat);
  cRing2.rotation.x = -Math.PI / 2;
  circle.add(cRing2);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    const tick = new THREE.Mesh(G(new THREE.BoxGeometry(0.05, 0.01, 0.28)), runeMat);
    tick.position.set(Math.cos(a) * 3.34, 0, Math.sin(a) * 3.34);
    tick.rotation.y = -a;
    circle.add(tick);
  }
  group.add(circle);
  animated.push({ obj: circle, kind: "spin", seed: 0.06 });

  // ── pillars ──────────────────────────────────────────────────────
  const pillarCount = detailed ? 10 : 8;
  for (let i = 0; i < pillarCount; i++) {
    const a = (i / pillarCount) * TAU + 0.31;
    const r = 12.4;
    const broken = i % 3 === 1;
    const h = broken ? 2.2 + Math.random() * 1.6 : 5.4 + Math.random() * 1.4;
    const px = Math.cos(a) * r;
    const pz = Math.sin(a) * r;
    const pil = new THREE.Group();
    pil.position.set(px, 0, pz);
    pil.rotation.y = -a;
    const plinth = new THREE.Mesh(G(new THREE.BoxGeometry(1.7, 0.5, 1.7)), stoneMat);
    plinth.position.y = 0.25;
    plinth.castShadow = true;
    plinth.receiveShadow = true;
    pil.add(plinth);
    const baseRing = new THREE.Mesh(G(new THREE.CylinderGeometry(0.78, 0.86, 0.24, 16)), trimMat);
    baseRing.position.y = 0.6;
    pil.add(baseRing);
    const shaft = new THREE.Mesh(G(new THREE.CylinderGeometry(0.6, 0.68, h, 16)), stoneMat);
    shaft.position.y = 0.7 + h / 2;
    shaft.castShadow = true;
    shaft.receiveShadow = true;
    pil.add(shaft);
    // fluting (skipped on the low preset to save draw calls)
    if (detailed) {
      for (let f = 0; f < 8; f++) {
        const fa = (f / 8) * TAU;
        const flute = new THREE.Mesh(G(new THREE.BoxGeometry(0.07, h * 0.94, 0.07)), darkStoneMat);
        flute.position.set(Math.cos(fa) * 0.62, 0.7 + h / 2, Math.sin(fa) * 0.62);
        pil.add(flute);
      }
    }
    if (!broken) {
      const cap = new THREE.Mesh(G(new THREE.BoxGeometry(1.6, 0.36, 1.6)), stoneMat);
      cap.position.y = 0.7 + h + 0.18;
      cap.castShadow = true;
      pil.add(cap);
      const abacus = new THREE.Mesh(G(new THREE.BoxGeometry(1.9, 0.22, 1.9)), trimMat);
      abacus.position.y = 0.7 + h + 0.45;
      pil.add(abacus);
      const band = new THREE.Mesh(G(new THREE.TorusGeometry(0.64, 0.035, 6, 20)), runeMat);
      band.rotation.x = Math.PI / 2;
      band.position.y = 0.7 + h * 0.55;
      pil.add(band);
    } else {
      const jag = new THREE.Mesh(G(new THREE.ConeGeometry(0.62, 0.7, 7)), stoneMat);
      jag.position.y = 0.7 + h + 0.2;
      jag.rotation.z = 0.12;
      pil.add(jag);
    }
    group.add(pil);
    // banner on some pillars
    if (i % 2 === 0) {
      const banner = new THREE.Mesh(G(new THREE.PlaneGeometry(1.25, 2.6, 4, 8)), bannerMat);
      banner.position.set(px * 0.94, 3.1, pz * 0.94);
      banner.lookAt(0, 3.1, 0);
      group.add(banner);
      animated.push({ obj: banner, kind: "banner", seed: i * 1.7 });
    }
  }

  // ── statues ──────────────────────────────────────────────────────
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * TAU + Math.PI / 4;
    const r = 11.2;
    const st = new THREE.Group();
    st.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
    st.rotation.y = -a + Math.PI;
    const ped = new THREE.Mesh(G(new THREE.BoxGeometry(1.5, 1.2, 1.5)), stoneMat);
    ped.position.y = 0.6;
    ped.castShadow = true;
    ped.receiveShadow = true;
    st.add(ped);
    const pedTrim = new THREE.Mesh(G(new THREE.BoxGeometry(1.7, 0.16, 1.7)), trimMat);
    pedTrim.position.y = 1.22;
    st.add(pedTrim);
    const robe = new THREE.Mesh(
      G(
        new THREE.LatheGeometry(
          [
            new THREE.Vector2(0.05, 0),
            new THREE.Vector2(0.46, 0.1),
            new THREE.Vector2(0.4, 0.7),
            new THREE.Vector2(0.3, 1.3),
            new THREE.Vector2(0.34, 1.6),
            new THREE.Vector2(0.22, 1.75),
            new THREE.Vector2(0.05, 1.8),
          ],
          12
        )
      ),
      darkStoneMat
    );
    robe.position.y = 1.3;
    robe.castShadow = true;
    st.add(robe);
    const head = new THREE.Mesh(G(new THREE.SphereGeometry(0.2, 12, 10)), darkStoneMat);
    head.position.y = 3.25;
    st.add(head);
    const crown = new THREE.Mesh(G(new THREE.ConeGeometry(0.26, 0.3, 6)), trimMat);
    crown.position.y = 3.48;
    st.add(crown);
    for (const s of [-1, 1]) {
      const arm = new THREE.Mesh(G(new THREE.CylinderGeometry(0.09, 0.11, 0.9, 8)), darkStoneMat);
      arm.position.set(0.32 * s, 2.6, 0.05);
      arm.rotation.z = 0.5 * s;
      st.add(arm);
    }
    const spear = new THREE.Mesh(G(new THREE.CylinderGeometry(0.035, 0.035, 3.4, 6)), trimMat);
    spear.position.set(0.62, 2.6, 0.1);
    spear.rotation.z = 0.08;
    st.add(spear);
    const tip = new THREE.Mesh(G(new THREE.ConeGeometry(0.1, 0.4, 6)), trimMat);
    tip.position.set(0.75, 4.35, 0.1);
    st.add(tip);
    group.add(st);
  }

  // ── braziers ─────────────────────────────────────────────────────
  const flameTex = flameTexture();
  const glowTex = glowTexture();
  const brazierPositions: [number, number][] = [
    [-6.6, -6.6],
    [6.6, -6.6],
    [-6.6, 6.6],
    [6.6, 6.6],
  ];
  brazierPositions.forEach(([x, z], i) => {
    const b = new THREE.Group();
    b.position.set(x, 0, z);
    const stand = new THREE.Mesh(G(new THREE.CylinderGeometry(0.16, 0.34, 1.1, 8)), darkStoneMat);
    stand.position.y = 0.55;
    stand.castShadow = true;
    b.add(stand);
    const bowl = new THREE.Mesh(
      G(new THREE.SphereGeometry(0.46, 14, 8, 0, TAU, Math.PI * 0.5, Math.PI * 0.5)),
      trimMat
    );
    bowl.position.y = 1.16;
    bowl.rotation.x = Math.PI;
    b.add(bowl);
    const coals = new THREE.Mesh(G(new THREE.SphereGeometry(0.3, 10, 6)), emberMat);
    coals.position.y = 1.14;
    coals.scale.y = 0.4;
    b.add(coals);
    const spriteMat = new THREE.SpriteMaterial({
      map: flameTex,
      color: 0xffa04a,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });
    mats.push(spriteMat);
    const sprite = new THREE.Sprite(spriteMat);
    sprite.position.y = 1.55;
    sprite.scale.set(1.1, 1.7, 1);
    b.add(sprite);
    const haloMat = new THREE.SpriteMaterial({
      map: glowTex,
      color: pal.ember,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });
    mats.push(haloMat);
    const halo = new THREE.Sprite(haloMat);
    halo.position.y = 1.4;
    halo.scale.set(2.6, 2.6, 1);
    b.add(halo);
    let light: THREE.PointLight | undefined;
    if (quality !== "low" && i < 2) {
      light = new THREE.PointLight(pal.ember, 26, 13, 2);
      light.position.y = 1.7;
      b.add(light);
    }
    group.add(b);
    flames.push({ sprite, light, seed: i * 2.3 });
  });

  // ── rubble & fallen columns ──────────────────────────────────────
  const rubbleCount = detailed ? 14 : 6;
  for (let i = 0; i < rubbleCount; i++) {
    const a = Math.random() * TAU;
    const r = 10.5 + Math.random() * 6;
    const s = 0.3 + Math.random() * 0.8;
    const rock = new THREE.Mesh(G(new THREE.DodecahedronGeometry(s, 0)), i % 3 === 0 ? stoneMat : darkStoneMat);
    rock.position.set(Math.cos(a) * r, s * 0.4, Math.sin(a) * r);
    rock.rotation.set(Math.random(), Math.random(), Math.random());
    rock.castShadow = true;
    rock.receiveShadow = true;
    group.add(rock);
  }
  const fallenCount = detailed ? 3 : 1;
  for (let i = 0; i < fallenCount; i++) {
    const a = 1.2 + i * 2.1;
    const fallen = new THREE.Mesh(G(new THREE.CylinderGeometry(0.55, 0.6, 4.4, 12)), stoneMat);
    fallen.position.set(Math.cos(a) * 15, 0.5, Math.sin(a) * 15);
    fallen.rotation.set(0, a, Math.PI / 2);
    fallen.castShadow = true;
    fallen.receiveShadow = true;
    group.add(fallen);
  }

  // ── particles: floating dust + embers ────────────────────────────
  const dustCount = quality === "low" ? 90 : quality === "medium" ? 170 : 260;
  const dustGeo = G(new THREE.BufferGeometry());
  const dustPos = new Float32Array(dustCount * 3);
  const dustSeed = new Float32Array(dustCount);
  for (let i = 0; i < dustCount; i++) {
    const a = Math.random() * TAU;
    const r = Math.random() * 16;
    dustPos[i * 3] = Math.cos(a) * r;
    dustPos[i * 3 + 1] = Math.random() * 9;
    dustPos[i * 3 + 2] = Math.sin(a) * r;
    dustSeed[i] = Math.random();
  }
  dustGeo.setAttribute("position", new THREE.BufferAttribute(dustPos, 3));
  const dustMat = M(
    new THREE.PointsMaterial({
      color: pal.ember,
      size: 0.055,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
      toneMapped: false,
    })
  );
  const dust = new THREE.Points(dustGeo, dustMat);
  group.add(dust);

  const emberCount = quality === "low" ? 40 : 90;
  const emberGeo = G(new THREE.BufferGeometry());
  const emberPos = new Float32Array(emberCount * 3);
  const emberVel = new Float32Array(emberCount);
  for (let i = 0; i < emberCount; i++) {
    const b = brazierPositions[i % brazierPositions.length];
    emberPos[i * 3] = b[0] + (Math.random() - 0.5) * 0.5;
    emberPos[i * 3 + 1] = 1.4 + Math.random() * 3;
    emberPos[i * 3 + 2] = b[1] + (Math.random() - 0.5) * 0.5;
    emberVel[i] = 0.25 + Math.random() * 0.6;
  }
  emberGeo.setAttribute("position", new THREE.BufferAttribute(emberPos, 3));
  const emberMatP = M(
    new THREE.PointsMaterial({
      color: 0xffb066,
      size: 0.075,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  const embers = new THREE.Points(emberGeo, emberMatP);
  group.add(embers);

  // ground mist sprites
  for (let i = 0; i < 5; i++) {
    const mistMat = new THREE.SpriteMaterial({
      map: glowTex,
      color: pal.fog,
      transparent: true,
      opacity: 0.16,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    mats.push(mistMat);
    const mist = new THREE.Sprite(mistMat);
    const a = (i / 5) * TAU;
    mist.position.set(Math.cos(a) * 7, 0.5, Math.sin(a) * 7);
    mist.scale.set(12, 4, 1);
    group.add(mist);
    animated.push({ obj: mist, kind: "mist", seed: i });
  }

  // ── lighting ─────────────────────────────────────────────────────
  const hemi = new THREE.HemisphereLight(pal.ambient, 0x0a0806, 1.15);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(pal.sun, pal.sunIntensity);
  sun.position.set(9, 16, 8);
  sun.castShadow = quality !== "low";
  if (sun.castShadow) {
    const size = quality === "high" ? 2048 : 1024;
    sun.shadow.mapSize.set(size, size);
    sun.shadow.camera.left = -14;
    sun.shadow.camera.right = 14;
    sun.shadow.camera.top = 14;
    sun.shadow.camera.bottom = -14;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 45;
    sun.shadow.bias = -0.0012;
    sun.shadow.normalBias = 0.03;
  }
  scene.add(sun);
  const rimA = new THREE.DirectionalLight(pal.rimA, 1.5);
  rimA.position.set(-12, 6, -6);
  scene.add(rimA);
  const rimB = new THREE.DirectionalLight(pal.rimB, 1.2);
  rimB.position.set(12, 5, -8);
  scene.add(rimB);
  const fill = new THREE.PointLight(pal.rune, 22, 24, 2);
  fill.position.set(0, 7, 0);
  scene.add(fill);

  const update = (dt: number, elapsed: number) => {
    for (const f of flames) {
      const flick = 0.82 + Math.sin(elapsed * 11 + f.seed) * 0.1 + Math.sin(elapsed * 23 + f.seed * 2) * 0.06;
      f.sprite.scale.set(1.05 * flick, 1.7 * flick, 1);
      f.sprite.position.y = 1.5 + Math.sin(elapsed * 7 + f.seed) * 0.05;
      if (f.light) f.light.intensity = 22 * flick;
    }
    for (const a of animated) {
      if (a.kind === "spin") a.obj.rotation.y += dt * a.seed;
      else if (a.kind === "banner") a.obj.rotation.z = Math.sin(elapsed * 1.4 + a.seed) * 0.045;
      else if (a.kind === "mist") {
        a.obj.position.x += Math.sin(elapsed * 0.2 + a.seed) * dt * 0.15;
        (a.obj as THREE.Sprite).material.opacity = 0.12 + Math.sin(elapsed * 0.5 + a.seed) * 0.04;
      }
    }
    const dp = dustGeo.attributes.position as THREE.BufferAttribute;
    const da = dp.array as Float32Array;
    for (let i = 0; i < dustCount; i++) {
      da[i * 3 + 1] += dt * (0.08 + dustSeed[i] * 0.16);
      da[i * 3] += Math.sin(elapsed * 0.4 + dustSeed[i] * 10) * dt * 0.12;
      if (da[i * 3 + 1] > 9) da[i * 3 + 1] = 0;
    }
    dp.needsUpdate = true;
    const ep = emberGeo.attributes.position as THREE.BufferAttribute;
    const ea = ep.array as Float32Array;
    for (let i = 0; i < emberCount; i++) {
      ea[i * 3 + 1] += dt * emberVel[i];
      ea[i * 3] += Math.sin(elapsed * 2 + i) * dt * 0.16;
      if (ea[i * 3 + 1] > 5.5) {
        const b = brazierPositions[i % brazierPositions.length];
        ea[i * 3] = b[0] + (Math.random() - 0.5) * 0.5;
        ea[i * 3 + 1] = 1.4;
        ea[i * 3 + 2] = b[1] + (Math.random() - 0.5) * 0.5;
      }
    }
    ep.needsUpdate = true;
    runeMat.emissiveIntensity = 1.9 + Math.sin(elapsed * 1.6) * 0.45;
    floorMat.emissiveIntensity = 1.0 + Math.sin(elapsed * 1.2) * 0.2;
  };

  const dispose = () => {
    scene.remove(group);
    scene.remove(hemi);
    scene.remove(sun);
    scene.remove(rimA);
    scene.remove(rimB);
    scene.remove(fill);
    geos.forEach((g) => g.dispose());
    mats.forEach((m) => m.dispose());
  };

  return { group, update, dispose, sun };
}
