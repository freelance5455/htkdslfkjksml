import * as THREE from 'three'
import { AIRCRAFT_LENGTH } from './collision'

/**
 * The player's aircraft: the supplied `pampa.glb` model, scaled to its real size and re-oriented so
 * that its nose points along -Z (the model itself faces +X). The root group carries the gameplay
 * pose; everything visual hangs below it so the mesh never drifts from the physics body.
 */
export class Aircraft {
  readonly root = new THREE.Group()
  private readonly body = new THREE.Group()
  private readonly materials: THREE.MeshStandardMaterial[] = []
  private readonly flameOuter: THREE.Mesh
  private readonly flameInner: THREE.Mesh
  private wrecked = false

  /** Nozzle position in aircraft space. */
  static readonly NOZZLE = new THREE.Vector3(0, -0.15, 5.55)
  /** Wing tip positions in aircraft space (for vapour trails). */
  static readonly WING_TIPS: readonly THREE.Vector3[] = [new THREE.Vector3(-3.75, 0.05, 1.6), new THREE.Vector3(3.75, 0.05, 1.6)]

  constructor(model: THREE.Object3D, maxAnisotropy: number) {
    model.rotation.y = Math.PI / 2 // model +X (nose) → game -Z
    model.scale.setScalar(AIRCRAFT_LENGTH)
    model.traverse(o => {
      const mesh = o as THREE.Mesh
      if (!mesh.isMesh) return
      mesh.frustumCulled = false
      const mat = mesh.material as THREE.MeshStandardMaterial
      mat.envMapIntensity = 0.85
      for (const tex of [mat.map, mat.normalMap, mat.metalnessMap, mat.roughnessMap]) {
        if (tex) tex.anisotropy = Math.min(8, maxAnisotropy)
      }
      this.materials.push(mat)
    })
    this.body.add(model)
    this.root.add(this.body)

    const cone = (radius: number, color: number, opacity: number) => {
      const geometry = new THREE.ConeGeometry(radius, 1, 16, 1, true).translate(0, 0.5, 0).rotateX(Math.PI / 2)
      const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, side: THREE.DoubleSide })
      const mesh = new THREE.Mesh(geometry, material)
      mesh.position.copy(Aircraft.NOZZLE)
      mesh.frustumCulled = false
      this.root.add(mesh)
      return mesh
    }
    this.flameOuter = cone(0.55, 0xff8a2a, 0.55)
    this.flameInner = cone(0.28, 0xbfdcff, 0.8)
    this.setEngine(0.5, 0)
  }

  /** Engine output 0..1 drives the flame length; `time` adds flicker. */
  setEngine(engine: number, time: number): void {
    const flicker = 1 + Math.sin(time * 60) * 0.08 + Math.sin(time * 37) * 0.06
    const power = this.wrecked ? 0 : engine
    this.flameOuter.visible = this.flameInner.visible = power > 0.04
    this.flameOuter.scale.set(1, 1, (0.6 + power * 6.5) * flicker)
    this.flameInner.scale.set(1, 1, (0.4 + power * 3.6) * flicker)
  }

  setPose(position: THREE.Vector3, quaternion: THREE.Quaternion): void {
    this.root.position.copy(position)
    this.root.quaternion.copy(quaternion)
  }

  /** Burnt, dark airframe after a crash. */
  setWrecked(wrecked: boolean): void {
    this.wrecked = wrecked
    for (const m of this.materials) m.color.setScalar(wrecked ? 0.22 : 1)
    if (wrecked) this.flameOuter.visible = this.flameInner.visible = false
  }
}
