import { GameSettings, PlayerAppearance, PlayerStats, SaveData } from '../types/gameTypes';

const SAVE_STORAGE_KEY = 'fantasy_world_rpg_save_v1';

export function createDefaultStats(): PlayerStats {
  return {
    level: 1,
    xp: 0,
    xpToNext: 100,
    hp: 150,
    maxHp: 150,
    mana: 100,
    maxMana: 100,
    stamina: 100,
    maxStamina: 100,
    hunger: 100,
    maxHunger: 100,
    gold: 75,
    skillPoints: 1,
    baseStrength: 12,
    baseDefense: 8,
    baseMagic: 14,
    baseSpeed: 9.2,
  };
}

export function createDefaultAppearance(): PlayerAppearance {
  return {
    name: 'Aelindor',
    hairStyle: 'short',
    hairColor: '#451a03',
    skinColor: '#f1c27d',
    faceStyle: 'determined',
    tunicColor: '#1e40af',
    armorColor: '#64748b',
    accessory: 'cape',
  };
}

export function createDefaultSettings(): GameSettings {
  const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);
  return {
    graphics: isTouch ? 'Medium' : 'High',
    survivalMode: true,
    audioEnabled: true,
    musicVolume: 0.25,
    sfxVolume: 0.5,
    invertY: false,
    cameraSensitivity: 1.0,
    hudLayout: {
      joystickScale: 1.0,
      buttonsScale: 1.0,
      elementalOffsetY: 0,
      showTouchControls: 'auto',
    },
  };
}

export function createNewSaveData(): SaveData {
  return {
    version: 1,
    savedAt: Date.now(),
    position: { x: 0, y: 2.0, z: 16, yaw: Math.PI },
    stats: createDefaultStats(),
    appearance: createDefaultAppearance(),
    equipped: {
      weapon: 'iron_sword',
      shield: 'wooden_buckler',
      chest: 'traveler_tunic',
      helmet: 'traveler_hood',
    },
    inventory: [
      { itemId: 'iron_sword', quantity: 1 },
      { itemId: 'wooden_buckler', quantity: 1 },
      { itemId: 'traveler_tunic', quantity: 1 },
      { itemId: 'traveler_hood', quantity: 1 },
      { itemId: 'arcane_oak_staff', quantity: 1 },
      { itemId: 'health_potion', quantity: 3 },
      { itemId: 'mana_potion', quantity: 3 },
      { itemId: 'cooked_meat', quantity: 3 },
      { itemId: 'wood', quantity: 10 },
      { itemId: 'stone', quantity: 8 },
      { itemId: 'herbs', quantity: 4 },
      { itemId: 'magic_dust', quantity: 3 },
    ],
    unlockedSpells: [
      'fireball',
      'ice_projectile',
      'water_projectile',
      'lightning_bolt',
    ],
    spellLevels: {
      fireball: 1,
      ice_projectile: 1,
      water_projectile: 1,
      lightning_bolt: 1,
    },
    selectedSpells: {
      fire: 'fireball',
      ice: 'ice_projectile',
      water: 'water_projectile',
      lightning: 'lightning_bolt',
    },
    skillRanks: {},
    quests: {
      main_1_awakening: {
        questId: 'main_1_awakening',
        counts: { talk_lyra: 0, kill_goblins: 0 },
        completed: false,
        claimed: false,
      },
    },
    discoveredRegions: ['green_forest'],
    defeatedBosses: [],
    tamedCompanion: false,
    tamedMount: false,
    structures: [],
    timeOfDay: 10.5,
    settings: createDefaultSettings(),
  };
}

export function loadSavedGame(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SaveData;
    if (!parsed || !parsed.stats || !parsed.appearance) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveGameToDisk(data: SaveData): boolean {
  try {
    localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify({ ...data, savedAt: Date.now() }));
    return true;
  } catch {
    return false;
  }
}

export function clearSavedGame(): void {
  localStorage.removeItem(SAVE_STORAGE_KEY);
}
