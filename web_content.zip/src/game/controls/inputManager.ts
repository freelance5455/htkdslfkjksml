export interface InputSnapshot {
  moveX: number; // -1 left, +1 right
  moveY: number; // +1 forward, -1 backward
  lookDeltaX: number;
  lookDeltaY: number;
  zoomDelta: number;
  jumpPressed: boolean;
  sprintActive: boolean;
  dashPressed: boolean;
  attackPressed: boolean;
  interactPressed: boolean;
  blockActive: boolean;
}

export class InputManager {
  private keys = new Set<string>();
  private joyX = 0;
  private joyY = 0;
  private joySprinting = false;
  private uiSprintToggle = false;
  private uiBlockHeld = false;
  private rightMouseHeld = false;
  private lookAccumX = 0;
  private lookAccumY = 0;
  private zoomAccum = 0;
  private jumpQueued = false;
  private dashQueued = false;
  private attackQueued = false;
  private interactQueued = false;

  private canvas: HTMLElement | null = null;
  private activeLookPointerId: number | null = null;
  private lastLookClientX = 0;
  private lastLookClientY = 0;

  private onToggleCameraCb: (() => void) | null = null;

  constructor(onToggleCamera?: () => void) {
    this.onToggleCameraCb = onToggleCamera ?? null;
  }

  public attach(canvasElement: HTMLElement): () => void {
    this.canvas = canvasElement;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyV' && !e.repeat) {
        this.onToggleCameraCb?.();
        return;
      }
      if (e.code === 'Space' && !e.repeat) {
        this.jumpQueued = true;
      }
      if ((e.code === 'KeyQ' || e.code === 'KeyF') && !e.repeat) {
        this.dashQueued = true;
      }
      if ((e.code === 'KeyE' || e.code === 'KeyJ') && !e.repeat) {
        this.attackQueued = true;
      }
      if (e.code === 'KeyR' && !e.repeat) {
        this.interactQueued = true;
      }
      this.keys.add(e.code);
    };

    const onKeyUp = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.target !== this.canvas) return;
      if (e.button === 2) {
        this.rightMouseHeld = true;
      }
      if (this.activeLookPointerId === null) {
        this.activeLookPointerId = e.pointerId;
        this.lastLookClientX = e.clientX;
        this.lastLookClientY = e.clientY;
        try {
          this.canvas?.setPointerCapture(e.pointerId);
        } catch {
          // Safe fallback
        }
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      if (e.pointerId === this.activeLookPointerId) {
        const dx = e.clientX - this.lastLookClientX;
        const dy = e.clientY - this.lastLookClientY;
        this.lastLookClientX = e.clientX;
        this.lastLookClientY = e.clientY;
        this.lookAccumX += dx;
        this.lookAccumY += dy;
      } else if (document.pointerLockElement === this.canvas) {
        this.lookAccumX += e.movementX;
        this.lookAccumY += e.movementY;
      }
    };

    const onPointerUpOrCancel = (e: PointerEvent) => {
      if (e.button === 2) {
        this.rightMouseHeld = false;
      }
      if (e.pointerId === this.activeLookPointerId) {
        this.activeLookPointerId = null;
        try {
          this.canvas?.releasePointerCapture(e.pointerId);
        } catch {
          // Ignore
        }
      }
    };

    const onContextMenu = (e: MouseEvent) => {
      if (e.target === this.canvas) e.preventDefault();
    };

    const onWheel = (e: WheelEvent) => {
      if (e.target !== this.canvas) return;
      this.zoomAccum += Math.sign(e.deltaY) * 0.7;
    };

    const onBlur = () => {
      this.keys.clear();
      this.rightMouseHeld = false;
      this.uiBlockHeld = false;
      this.activeLookPointerId = null;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    canvasElement.addEventListener('pointerdown', onPointerDown);
    canvasElement.addEventListener('contextmenu', onContextMenu);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUpOrCancel);
    window.addEventListener('pointercancel', onPointerUpOrCancel);
    canvasElement.addEventListener('wheel', onWheel, { passive: true });

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      canvasElement.removeEventListener('pointerdown', onPointerDown);
      canvasElement.removeEventListener('contextmenu', onContextMenu);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUpOrCancel);
      window.removeEventListener('pointercancel', onPointerUpOrCancel);
      canvasElement.removeEventListener('wheel', onWheel);
    };
  }

  public setJoystick(x: number, y: number, sprinting: boolean): void {
    this.joyX = x;
    this.joyY = y;
    this.joySprinting = sprinting;
  }

  public addLookDelta(dx: number, dy: number): void {
    this.lookAccumX += dx;
    this.lookAccumY += dy;
  }

  public triggerJump(): void {
    this.jumpQueued = true;
  }

  public triggerDash(): void {
    this.dashQueued = true;
  }

  public triggerAttack(): void {
    this.attackQueued = true;
  }

  public triggerInteract(): void {
    this.interactQueued = true;
  }

  public setSprintToggle(enabled: boolean): void {
    this.uiSprintToggle = enabled;
  }

  public setBlockHeld(held: boolean): void {
    this.uiBlockHeld = held;
  }

  public consumeSnapshot(): InputSnapshot {
    let kx = 0;
    let ky = 0;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) kx -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) kx += 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) ky += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) ky -= 1;

    let moveX = kx !== 0 ? kx : this.joyX;
    let moveY = ky !== 0 ? ky : this.joyY;
    const mag = Math.hypot(moveX, moveY);
    if (mag > 1) {
      moveX /= mag;
      moveY /= mag;
    }

    // Walking/joystick movement never drains stamina unless player explicitly toggles Sprint or holds Shift
    const sprintActive =
      this.keys.has('ShiftLeft') ||
      this.keys.has('ShiftRight') ||
      this.uiSprintToggle ||
      this.joySprinting;

    const blockActive =
      this.keys.has('KeyK') || this.rightMouseHeld || this.uiBlockHeld;

    const snap: InputSnapshot = {
      moveX,
      moveY,
      lookDeltaX: this.lookAccumX,
      lookDeltaY: this.lookAccumY,
      zoomDelta: this.zoomAccum,
      jumpPressed: this.jumpQueued,
      sprintActive,
      dashPressed: this.dashQueued,
      attackPressed: this.attackQueued,
      interactPressed: this.interactQueued,
      blockActive,
    };

    this.lookAccumX = 0;
    this.lookAccumY = 0;
    this.zoomAccum = 0;
    this.jumpQueued = false;
    this.dashQueued = false;
    this.attackQueued = false;
    this.interactQueued = false;

    return snap;
  }
}

