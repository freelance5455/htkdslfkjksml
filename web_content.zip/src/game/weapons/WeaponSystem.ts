import * as THREE from 'three';
import { WEAPON_REGISTRY, WeaponDef, WeaponModels } from '../models/WeaponModels';
import { sound } from '../../audio/SoundEngine';
import { CollisionSystem } from '../physics/CollisionSystem';
import { ObjectPool } from '../core/ObjectPool';

export interface WeaponState {
  def: WeaponDef;
  currentAmmo: number;
  reserveAmmo: number;
  isReloading: boolean;
  reloadProgress: number;
  isAiming: boolean;
}

export class WeaponSystem {
  private camera: THREE.PerspectiveCamera;
  private collision: CollisionSystem;
  private pool: ObjectPool;

  private weaponRig: THREE.Group;
  private currentModelGroup: THREE.Group | null = null;
  private currentMagMesh: THREE.Mesh | null = null;
  private currentMuzzlePos = new THREE.Vector3(0, 0, -0.5);

  // High-fidelity Realistic Muzzle Fire
  private muzzleFlashGroup: THREE.Group;
  private muzzleFlashMeshes: THREE.Mesh[] = [];
  private muzzleLight: THREE.PointLight;
  private flashTimer = 0;

  // Active weapons
  public primary: WeaponState;
  public secondary: WeaponState;
  public activeWeapon: WeaponState;

  // Recoil & Animation
  private recoilOffset = new THREE.Vector3();
  private recoilRot = new THREE.Euler();
  private swayOffset = new THREE.Vector2();
  private bobTimer = 0;
  private lastShotTime = 0;
  private isDrawing = false;
  private drawProgress = 1;

  // Temp vectors for raycasting without allocation
  private tempRayDir = new THREE.Vector3();
  private tempRayOrigin = new THREE.Vector3();
  private tempRay = new THREE.Ray();
  private tempHeadCenter = new THREE.Vector3();
  private tempBodyCenter = new THREE.Vector3();

  // Callbacks for UI
  public onShoot?: () => void;
  public onHit?: (isHeadshot: boolean, damage: number, point: THREE.Vector3) => void;
  public onAmmoChange?: (current: number, reserve: number) => void;

  constructor(camera: THREE.PerspectiveCamera, collision: CollisionSystem, pool: ObjectPool) {
    this.camera = camera;
    this.collision = collision;
    this.pool = pool;

    // Create weapon rig attached strictly to camera
    this.weaponRig = new THREE.Group();
    this.camera.add(this.weaponRig);

    // Muzzle Flash Group with 4 geometric variations
    this.muzzleFlashGroup = new THREE.Group();
    this.initMuzzleFlashes();

    // High-intensity short duration muzzle light
    this.muzzleLight = new THREE.PointLight(0xffa500, 0, 8);
    this.muzzleFlashGroup.add(this.muzzleLight);

    // Setup initial weapons
    this.primary = {
      def: WEAPON_REGISTRY.rifle,
      currentAmmo: WEAPON_REGISTRY.rifle.magSize,
      reserveAmmo: WEAPON_REGISTRY.rifle.maxAmmo,
      isReloading: false,
      reloadProgress: 0,
      isAiming: false,
    };

    this.secondary = {
      def: WEAPON_REGISTRY.pistol,
      currentAmmo: WEAPON_REGISTRY.pistol.magSize,
      reserveAmmo: WEAPON_REGISTRY.pistol.maxAmmo,
      isReloading: false,
      reloadProgress: 0,
      isAiming: false,
    };

    this.activeWeapon = this.primary;
    this.equipWeapon(this.activeWeapon.def.id);
  }

  // Pre-generate realistic 3D muzzle flash variations
  private initMuzzleFlashes() {
    const flashColors = [0xffaa22, 0xffd044, 0xff7711, 0xffffff];

    // Variation 1: Multi-point Starburst
    const geo1 = new THREE.DodecahedronGeometry(0.09, 0);
    geo1.scale(1, 1, 2.5);
    const mat1 = new THREE.MeshBasicMaterial({ color: flashColors[0], transparent: true, opacity: 0 });
    const m1 = new THREE.Mesh(geo1, mat1);
    this.muzzleFlashMeshes.push(m1);
    this.muzzleFlashGroup.add(m1);

    // Variation 2: Cross Spikes
    const geo2 = new THREE.OctahedronGeometry(0.11, 0);
    geo2.scale(1.8, 0.4, 3.2);
    const mat2 = new THREE.MeshBasicMaterial({ color: flashColors[1], transparent: true, opacity: 0 });
    const m2 = new THREE.Mesh(geo2, mat2);
    this.muzzleFlashMeshes.push(m2);
    this.muzzleFlashGroup.add(m2);

    // Variation 3: Core Jet Flame
    const geo3 = new THREE.ConeGeometry(0.06, 0.28, 8);
    geo3.rotateX(-Math.PI / 2);
    const mat3 = new THREE.MeshBasicMaterial({ color: flashColors[3], transparent: true, opacity: 0 });
    const m3 = new THREE.Mesh(geo3, mat3);
    this.muzzleFlashMeshes.push(m3);
    this.muzzleFlashGroup.add(m3);
  }

  equipWeapon(weaponId: string) {
    const def = WEAPON_REGISTRY[weaponId] || WEAPON_REGISTRY.rifle;
    this.activeWeapon.def = def;
    this.activeWeapon.currentAmmo = Math.min(this.activeWeapon.currentAmmo, def.magSize);
    if (this.activeWeapon.currentAmmo === 0) this.activeWeapon.currentAmmo = def.magSize;

    if (this.currentModelGroup) {
      this.currentModelGroup.remove(this.muzzleFlashGroup);
      this.weaponRig.remove(this.currentModelGroup);
      this.currentModelGroup = null;
      this.currentMagMesh = null;
    }

    const built = WeaponModels.buildWeapon(def.id, def.skin || 'tactical');
    this.currentModelGroup = built.model;
    this.currentMagMesh = built.mag;
    this.currentMuzzlePos.copy(built.muzzlePos);

    // Position muzzle flash directly at barrel tip
    this.muzzleFlashGroup.position.copy(built.muzzlePos);
    this.currentModelGroup.add(this.muzzleFlashGroup);

    this.weaponRig.add(this.currentModelGroup);
    this.weaponRig.position.copy(def.hipOffset);

    this.isDrawing = true;
    this.drawProgress = 0;

    if (this.onAmmoChange) {
      this.onAmmoChange(this.activeWeapon.currentAmmo, this.activeWeapon.reserveAmmo);
    }
  }

  switchWeapon() {
    if (this.activeWeapon.isReloading) return;
    this.activeWeapon = this.activeWeapon === this.primary ? this.secondary : this.primary;
    this.equipWeapon(this.activeWeapon.def.id);
    sound.playReload();
  }

  setWeapon(slot: 'primary' | 'secondary', weaponId: string, skin?: import('../models/WeaponModels').WeaponSkin) {
    const baseDef = WEAPON_REGISTRY[weaponId];
    if (!baseDef) return;
    const def = { ...baseDef, skin: skin || baseDef.skin || 'tactical' };
    const target = slot === 'primary' ? this.primary : this.secondary;
    target.def = def;
    target.currentAmmo = def.magSize;
    target.reserveAmmo = def.maxAmmo;
    target.isReloading = false;
    if (this.activeWeapon === target) {
      this.equipWeapon(def.id);
    }
  }

  refillAmmo() {
    this.primary.currentAmmo = this.primary.def.magSize;
    this.primary.reserveAmmo = this.primary.def.maxAmmo;
    this.secondary.currentAmmo = this.secondary.def.magSize;
    this.secondary.reserveAmmo = this.secondary.def.maxAmmo;
    if (this.onAmmoChange) {
      this.onAmmoChange(this.activeWeapon.currentAmmo, this.activeWeapon.reserveAmmo);
    }
  }

  setAim(aiming: boolean) {
    this.activeWeapon.isAiming = aiming;
  }

  reload() {
    if (this.activeWeapon.isReloading) return;
    if (this.activeWeapon.currentAmmo >= this.activeWeapon.def.magSize) return;
    if (this.activeWeapon.reserveAmmo <= 0) {
      sound.playDryFire();
      return;
    }

    this.activeWeapon.isReloading = true;
    this.activeWeapon.reloadProgress = 0;
    this.activeWeapon.isAiming = false;
    sound.playReload();
    if (Math.random() < 0.65) {
      setTimeout(() => sound.playCharacterVoice('reload'), 250);
    }
  }

  // Realistic Gunfire Execution with Muzzle Fire Variations
  shoot(
    raycastTargets: {
      id: string;
      position: THREE.Vector3;
      radius: number;
      height: number;
      headY: number;
      takeDamage: (amount: number, isHeadshot: boolean) => void;
    }[]
  ): boolean {
    const now = performance.now() / 1000;
    const minInterval = 1 / this.activeWeapon.def.fireRate;

    if (now - this.lastShotTime < minInterval) return false;
    if (this.activeWeapon.isReloading) return false;

    if (this.activeWeapon.currentAmmo <= 0) {
      this.lastShotTime = now;
      sound.playDryFire();
      this.reload();
      return false;
    }

    this.lastShotTime = now;
    this.activeWeapon.currentAmmo--;

    if (this.onAmmoChange) {
      this.onAmmoChange(this.activeWeapon.currentAmmo, this.activeWeapon.reserveAmmo);
    }

    // Audio
    sound.playShoot(this.activeWeapon.def.type);

    // Trigger Realistic Muzzle Flash Variation
    this.triggerMuzzleFlash();

    // Spawn pooled shell casing
    this.ejectShellCasing();

    // Spawn subtle barrel smoke puff
    this.spawnBarrelSmoke();

    // Recoil Kick
    const def = this.activeWeapon.def;
    const kickMult = this.activeWeapon.isAiming ? 0.45 : 1.0;
    this.recoilOffset.z += def.recoilKick * kickMult;
    this.recoilRot.x += def.recoilClimb * kickMult;
    this.recoilRot.y += (Math.random() - 0.5) * def.recoilClimb * 0.35 * kickMult;

    if (this.onShoot) this.onShoot();

    // Raycast hit detection
    const pellets = def.pellets || 1;
    for (let p = 0; p < pellets; p++) {
      this.fireBulletRay(raycastTargets);
    }

    if (this.activeWeapon.currentAmmo === 0) {
      this.reload();
    }

    return true;
  }

  private triggerMuzzleFlash() {
    this.flashTimer = 0.045; // Ultra-crisp duration

    // Pick random flash shape variation
    const pick = Math.floor(Math.random() * this.muzzleFlashMeshes.length);
    for (let i = 0; i < this.muzzleFlashMeshes.length; i++) {
      const m = this.muzzleFlashMeshes[i];
      const mat = m.material as THREE.MeshBasicMaterial;
      if (i === pick) {
        mat.opacity = 1;
        m.rotation.z = Math.random() * Math.PI * 2;
        m.scale.setScalar(0.85 + Math.random() * 0.45);
      } else {
        mat.opacity = 0;
      }
    }

    this.muzzleLight.intensity = 3.5;
  }

  private ejectShellCasing() {
    // Eject to right & rear in world space
    const worldMuzzle = this.muzzleFlashGroup.getWorldPosition(new THREE.Vector3());
    const right = new THREE.Vector3(1, 0.45 + Math.random() * 0.3, -0.15)
      .applyEuler(this.camera.rotation)
      .multiplyScalar(2.6);

    this.pool.spawnShell(worldMuzzle, right);
  }

  private spawnBarrelSmoke() {
    const worldMuzzle = this.muzzleFlashGroup.getWorldPosition(new THREE.Vector3());
    const forward = new THREE.Vector3(0, 0, -1).applyEuler(this.camera.rotation);
    this.pool.spawnSmoke(worldMuzzle, forward);
  }

  private fireBulletRay(
    targets: {
      id: string;
      position: THREE.Vector3;
      radius: number;
      height: number;
      headY: number;
      takeDamage: (amount: number, isHeadshot: boolean) => void;
    }[]
  ) {
    const def = this.activeWeapon.def;
    const spread = this.activeWeapon.isAiming ? def.spread * 0.3 : def.spread;

    this.tempRayDir.set(
      (Math.random() - 0.5) * spread,
      (Math.random() - 0.5) * spread,
      -1
    )
      .normalize()
      .applyEuler(this.camera.rotation);

    this.tempRayOrigin.copy(this.camera.position);
    this.tempRay.set(this.tempRayOrigin, this.tempRayDir);

    const envHit = this.collision.raycast(this.tempRay, 80);
    const maxDist = envHit ? envHit.distance : 80;

    let closestZombieHit: {
      target: (typeof targets)[0];
      distance: number;
      isHeadshot: boolean;
      hitPoint: THREE.Vector3;
    } | null = null;

    let closestDist = maxDist;

    for (let i = 0; i < targets.length; i++) {
      const t = targets[i];

      // 1. Head hit check
      this.tempHeadCenter.copy(t.position).add({ x: 0, y: t.headY, z: 0 });
      const headDist = this.tempRay.distanceToPoint(this.tempHeadCenter);

      if (headDist <= 0.32) {
        const d = this.tempRayOrigin.distanceTo(this.tempHeadCenter);
        if (d < closestDist) {
          closestDist = d;
          closestZombieHit = {
            target: t,
            distance: d,
            isHeadshot: true,
            hitPoint: this.tempHeadCenter.clone(),
          };
          continue;
        }
      }

      // 2. Body cylinder check
      this.tempBodyCenter.copy(t.position).add({ x: 0, y: t.height * 0.5, z: 0 });
      const bodyDist = this.tempRay.distanceToPoint(this.tempBodyCenter);

      if (bodyDist <= t.radius + 0.15) {
        const d = this.tempRayOrigin.distanceTo(this.tempBodyCenter);
        if (d < closestDist) {
          closestDist = d;
          closestZombieHit = {
            target: t,
            distance: d,
            isHeadshot: false,
            hitPoint: this.tempBodyCenter.clone(),
          };
        }
      }
    }

    if (closestZombieHit) {
      const isHeadshot = closestZombieHit.isHeadshot;
      const damage = isHeadshot ? def.damage * 2.5 : def.damage;
      closestZombieHit.target.takeDamage(damage, isHeadshot);
      sound.playHitMarker(isHeadshot);
      sound.playBulletHit(isHeadshot ? 'headshot' : 'flesh');

      if (this.onHit) {
        this.onHit(isHeadshot, damage, closestZombieHit.hitPoint);
      }
    }
  }

  addSway(deltaX: number, deltaY: number) {
    this.swayOffset.x = THREE.MathUtils.clamp(this.swayOffset.x - deltaX * 0.0014, -0.04, 0.04);
    this.swayOffset.y = THREE.MathUtils.clamp(this.swayOffset.y + deltaY * 0.0014, -0.04, 0.04);
  }

  update(delta: number, isMoving: boolean, isSprinting: boolean) {
    const def = this.activeWeapon.def;

    // Reload animation
    if (this.activeWeapon.isReloading) {
      this.activeWeapon.reloadProgress += delta / def.reloadTime;

      if (this.currentMagMesh) {
        if (this.activeWeapon.reloadProgress < 0.4) {
          this.currentMagMesh.position.y = -0.11 - this.activeWeapon.reloadProgress * 0.6;
        } else if (this.activeWeapon.reloadProgress < 0.8) {
          this.currentMagMesh.position.y = -0.35 + (this.activeWeapon.reloadProgress - 0.4) * 0.6;
        } else {
          this.currentMagMesh.position.y = -0.11;
        }
      }

      if (this.activeWeapon.reloadProgress >= 1) {
        this.activeWeapon.isReloading = false;
        this.activeWeapon.reloadProgress = 0;
        const needed = def.magSize - this.activeWeapon.currentAmmo;
        const toLoad = Math.min(needed, this.activeWeapon.reserveAmmo);
        this.activeWeapon.currentAmmo += toLoad;
        this.activeWeapon.reserveAmmo -= toLoad;

        if (this.currentMagMesh) {
          this.currentMagMesh.position.y = -0.11;
        }

        if (this.onAmmoChange) {
          this.onAmmoChange(this.activeWeapon.currentAmmo, this.activeWeapon.reserveAmmo);
        }
      }
    }

    // Draw transition
    if (this.isDrawing) {
      this.drawProgress += delta * 4.0;
      if (this.drawProgress >= 1) {
        this.drawProgress = 1;
        this.isDrawing = false;
      }
    }

    // Flash decay
    if (this.flashTimer > 0) {
      this.flashTimer -= delta;
      if (this.flashTimer <= 0) {
        for (let i = 0; i < this.muzzleFlashMeshes.length; i++) {
          (this.muzzleFlashMeshes[i].material as THREE.MeshBasicMaterial).opacity = 0;
        }
        this.muzzleLight.intensity = 0;
      }
    }

    // Target weapon offset: ADS vs Hip
    const targetOffset = this.activeWeapon.isAiming ? def.adsOffset.clone() : def.hipOffset.clone();

    if (this.isDrawing) {
      targetOffset.y -= (1 - this.drawProgress) * 0.35;
    }

    // Head bobbing & sway
    if (isMoving) {
      const bobFreq = isSprinting ? 12 : 8;
      const bobAmp = isSprinting ? 0.022 : 0.01;
      this.bobTimer += delta * bobFreq;
      targetOffset.x += Math.sin(this.bobTimer * 0.5) * bobAmp * (this.activeWeapon.isAiming ? 0.2 : 1.0);
      targetOffset.y += Math.abs(Math.cos(this.bobTimer)) * bobAmp * (this.activeWeapon.isAiming ? 0.2 : 1.0);
    } else {
      this.bobTimer += delta * 2;
      targetOffset.y += Math.sin(this.bobTimer) * 0.002;
    }

    // Snappy recoil recovery
    this.recoilOffset.lerp(new THREE.Vector3(), delta * 15);
    this.recoilRot.x = THREE.MathUtils.lerp(this.recoilRot.x, 0, delta * 16);
    this.recoilRot.y = THREE.MathUtils.lerp(this.recoilRot.y, 0, delta * 16);

    // Sway recovery
    this.swayOffset.lerp(new THREE.Vector2(), delta * 10);

    const finalPos = targetOffset
      .clone()
      .add(this.recoilOffset)
      .add(new THREE.Vector3(this.swayOffset.x, this.swayOffset.y, 0));

    this.weaponRig.position.lerp(finalPos, delta * (this.activeWeapon.isAiming ? 22 : 16));

    this.weaponRig.rotation.set(
      this.recoilRot.x - this.swayOffset.y * 0.5,
      this.recoilRot.y - this.swayOffset.x * 0.5,
      0
    );

    // Smooth ADS FOV zoom
    const targetFov = this.activeWeapon.isAiming ? def.adsFov : 75;
    this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, delta * 18);
    this.camera.updateProjectionMatrix();
  }
}
