/**
 * Сетка проходимости и A* .
 * Река дорогая, море закрыто, дорога поверх реки — мост.
 */
import { CITIES, CITY_BY_ID, FORESTS, HILLS, RIVER, ROADS, SEAS, WORLD_H, WORLD_W } from "./content";

export const NAV = 64;
export const COLS = Math.ceil(WORLD_W / NAV);
export const ROWS = Math.ceil(WORLD_H / NAV);
export const TERRAIN = {
  plain: 0,
  forest: 1,
  hill: 2,
  road: 3,
  city: 4,
  river: 5,
  sea: 6,
} as const;

const COST = [1, 1.85, 1.45, 0.62, 1.05, 7.2, 0];

let grid: Uint8Array = new Uint8Array(COLS * ROWS);

export function bakeTerrain() {
  grid = new Uint8Array(COLS * ROWS);
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const x = c * NAV + NAV / 2;
      const y = r * NAV + NAV / 2;
      grid[r * COLS + c] = sample(x, y);
    }
  }
}

function sample(x: number, y: number): number {
  if (inSea(x, y)) return TERRAIN.sea;
  if (nearRoad(x, y, 16)) return TERRAIN.road;
  if (nearRiver(x, y, 30)) return TERRAIN.river;
  if (nearCity(x, y, 36)) return TERRAIN.city;
  if (inBlob(x, y, FORESTS)) return TERRAIN.forest;
  if (inBlob(x, y, HILLS)) return TERRAIN.hill;
  return TERRAIN.plain;
}

function nearCity(x: number, y: number, rad: number) {
  for (const c of CITIES) {
    const dx = x - c.x;
    const dy = y - c.y;
    if (dx * dx + dy * dy <= rad * rad) return true;
  }
  return false;
}

function inBlob(x: number, y: number, blobs: { x: number; y: number; rx: number; ry: number }[]) {
  for (const b of blobs) {
    const dx = (x - b.x) / b.rx;
    const dy = (y - b.y) / b.ry;
    if (dx * dx + dy * dy <= 1) return true;
  }
  return false;
}

function nearRiver(x: number, y: number, rad: number) {
  for (let i = 1; i < RIVER.length; i++) {
    const a = RIVER[i - 1]!;
    const b = RIVER[i]!;
    if (distSeg(x, y, a[0], a[1], b[0], b[1]) <= rad) return true;
  }
  return false;
}

function nearRoad(x: number, y: number, rad: number) {
  for (const [ia, ib] of ROADS) {
    const a = CITY_BY_ID[ia];
    const b = CITY_BY_ID[ib];
    if (!a || !b) continue;
    if (distSeg(x, y, a.x, a.y, b.x, b.y) <= rad) return true;
  }
  return false;
}

export function inSea(x: number, y: number) {
  for (const poly of SEAS) if (pointInPoly(x, y, poly)) return true;
  return false;
}

export function terrainAt(x: number, y: number): number {
  if (!grid.length) bakeTerrain();
  const c = clamp(Math.floor(x / NAV), 0, COLS - 1);
  const r = clamp(Math.floor(y / NAV), 0, ROWS - 1);
  return grid[r * COLS + c] ?? TERRAIN.plain;
}

export function cellIndex(x: number, y: number) {
  const c = clamp(Math.floor(x / NAV), 0, COLS - 1);
  const r = clamp(Math.floor(y / NAV), 0, ROWS - 1);
  return r * COLS + c;
}

export function cellCenter(i: number) {
  const c = i % COLS;
  const r = Math.floor(i / COLS);
  return { x: c * NAV + NAV / 2, y: r * NAV + NAV / 2 };
}

export function isSeaIndex(i: number) {
  return grid[i] === TERRAIN.sea;
}

interface Node {
  i: number;
  f: number;
}

class Heap {
  a: Node[] = [];
  push(n: Node) {
    const a = this.a;
    a.push(n);
    let i = a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (a[p]!.f <= a[i]!.f) break;
      const tmp = a[p]!;
      a[p] = a[i]!;
      a[i] = tmp;
      i = p;
    }
  }
  pop(): Node | undefined {
    const a = this.a;
    if (!a.length) return undefined;
    const top = a[0];
    const last = a.pop()!;
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (;;) {
        const l = i * 2 + 1;
        const r = l + 1;
        let s = i;
        if (l < a.length && a[l]!.f < a[s]!.f) s = l;
        if (r < a.length && a[r]!.f < a[s]!.f) s = r;
        if (s === i) break;
        const tmp = a[s]!;
        a[s] = a[i]!;
        a[i] = tmp;
        i = s;
      }
    }
    return top;
  }
  get size() {
    return this.a.length;
  }
}

const DIRS = [
  [1, 0, 1],
  [-1, 0, 1],
  [0, 1, 1],
  [0, -1, 1],
  [1, 1, 1.41421356],
  [1, -1, 1.41421356],
  [-1, 1, 1.41421356],
  [-1, -1, 1.41421356],
];

const gStamp = new Int32Array(COLS * ROWS);
const gScore = new Float32Array(COLS * ROWS);
const came = new Int32Array(COLS * ROWS);
const closed = new Int32Array(COLS * ROWS);
let stamp = 1;

function heuristic(c1: number, r1: number, c2: number, r2: number) {
  const dx = Math.abs(c1 - c2);
  const dy = Math.abs(r1 - r2);
  const D = 0.62;
  const D2 = 0.62 * 1.41421356;
  return D * (dx + dy) + (D2 - D) * Math.min(dx, dy);
}

export function findPath(x0: number, y0: number, x1: number, y1: number): { x: number; y: number }[] {
  if (!grid.length) bakeTerrain();
  const s = nearestWalkable(x0, y0);
  const g = nearestWalkable(x1, y1);
  if (s < 0 || g < 0) return [{ x: x0, y: y0 }, { x: x1, y: y1 }];
  if (s === g) return [cellCenter(g), { x: x1, y: y1 }];
  stamp++;
  if (stamp > 2_000_000_000) {
    gStamp.fill(0);
    closed.fill(0);
    stamp = 1;
  }
  const heap = new Heap();
  gStamp[s] = stamp;
  gScore[s] = 0;
  came[s] = -1;
  const sc = s % COLS;
  const sr = Math.floor(s / COLS);
  const gc = g % COLS;
  const gr = Math.floor(g / COLS);
  heap.push({ i: s, f: heuristic(sc, sr, gc, gr) });
  let guard = 0;
  while (heap.size && guard++ < 6000) {
    const cur = heap.pop()!;
    if (closed[cur.i] === stamp) continue;
    closed[cur.i] = stamp;
    if (cur.i === g) break;
    const cc = cur.i % COLS;
    const rr = Math.floor(cur.i / COLS);
    for (const d of DIRS) {
      const nc = cc + d[0]!;
      const nr = rr + d[1]!;
      if (nc < 0 || nr < 0 || nc >= COLS || nr >= ROWS) continue;
      if (d[0] !== 0 && d[1] !== 0) {
        const a = rr * COLS + nc;
        const b = nr * COLS + cc;
        if (grid[a] === TERRAIN.sea || grid[b] === TERRAIN.sea) continue;
      }
      const ni = nr * COLS + nc;
      if (grid[ni] === TERRAIN.sea) continue;
      if (closed[ni] === stamp) continue;
      const step = (COST[grid[ni]!] ?? 1) * d[2]!;
      const ng = gScore[cur.i]! + step;
      if (gStamp[ni] === stamp && ng >= gScore[ni]!) continue;
      gStamp[ni] = stamp;
      gScore[ni] = ng;
      came[ni] = cur.i;
      heap.push({ i: ni, f: ng + heuristic(nc, nr, gc, gr) });
    }
  }
  if (gStamp[g] !== stamp) return [{ x: x0, y: y0 }, { x: x1, y: y1 }];
  const cells: number[] = [];
  let cur = g;
  cells.push(cur);
  let safety = 0;
  while (came[cur] !== -1 && came[cur] !== undefined && safety++ < 2000) {
    cur = came[cur]!;
    cells.push(cur);
    if (cur === s) break;
  }
  cells.reverse();
  const pts = cells.map(cellCenter);
  pts[pts.length - 1] = { x: x1, y: y1 };
  return smooth(pts);
}

function smooth(pts: { x: number; y: number }[]) {
  if (pts.length <= 2) return pts;
  const out = [pts[0]!];
  let anchor = 0;
  while (anchor < pts.length - 1) {
    let next = pts.length - 1;
    while (next > anchor + 1 && !walkableLine(pts[anchor]!, pts[next]!)) next--;
    out.push(pts[next]!);
    anchor = next;
  }
  return out;
}

function walkableLine(a: { x: number; y: number }, b: { x: number; y: number }) {
  const dist = Math.hypot(b.x - a.x, b.y - a.y);
  const steps = Math.max(1, Math.ceil(dist / 24));
  let river = 0;
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const x = a.x + (b.x - a.x) * t;
    const y = a.y + (b.y - a.y) * t;
    const terr = terrainAt(x, y);
    if (terr === TERRAIN.sea) return false;
    if (terr === TERRAIN.river) river++;
  }
  return river < 2;
}

function nearestWalkable(x: number, y: number) {
  let c = clamp(Math.floor(x / NAV), 0, COLS - 1);
  let r = clamp(Math.floor(y / NAV), 0, ROWS - 1);
  if (grid[r * COLS + c] !== TERRAIN.sea) return r * COLS + c;
  for (let rad = 1; rad < 8; rad++) {
    for (let rr = r - rad; rr <= r + rad; rr++) {
      for (let cc = c - rad; cc <= c + rad; cc++) {
        if (cc < 0 || rr < 0 || cc >= COLS || rr >= ROWS) continue;
        if (grid[rr * COLS + cc] !== TERRAIN.sea) return rr * COLS + cc;
      }
    }
  }
  return -1;
}

export function distSeg(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
  const dx = bx - ax;
  const dy = by - ay;
  const l2 = dx * dx + dy * dy || 1;
  let t = ((px - ax) * dx + (py - ay) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  const x = ax + t * dx;
  const y = ay + t * dy;
  return Math.hypot(px - x, py - y);
}

export function pointInPoly(x: number, y: number, poly: [number, number][]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i]![0];
    const yi = poly[i]![1];
    const xj = poly[j]![0];
    const yj = poly[j]![1];
    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi || 1e-6) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function terrainName(t: number) {
  switch (t) {
    case TERRAIN.forest:
      return "forest";
    case TERRAIN.hill:
      return "hill";
    case TERRAIN.road:
      return "road";
    case TERRAIN.city:
      return "city";
    case TERRAIN.river:
      return "river";
    case TERRAIN.sea:
      return "sea";
    default:
      return "plain";
  }
}
