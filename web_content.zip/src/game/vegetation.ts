import * as THREE from "three";
import { GeoBuilder } from "./geo";

type R = () => number;
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _v = new THREE.Vector3();
const _s = new THREE.Vector3(1, 1, 1);

export function pine(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R, snowy: boolean) {
  const tr = 0.3 + rnd() * 0.06;
  b.cyl(x, y - 0.3, z, 0.26 * s, 0.18 * s, 2.0 * s, 5, tr, tr * 0.68, tr * 0.45);
  const layers = 3 + (rnd() < 0.5 ? 1 : 0);
  const g0 = 0.8 + rnd() * 0.35;
  const hue = rnd();
  let cr = 0.12 * g0, cg = 0.3 * g0, cb = 0.17 * g0;
  if (hue < 0.3) { cr = 0.16 * g0; cg = 0.33 * g0; cb = 0.14 * g0; }
  for (let i = 0; i < layers; i++) {
    const yb = y + (1.1 + i * 1.15) * s;
    const rad = (2.0 - i * (1.5 / layers)) * s;
    const hh = 2.3 * s;
    const sw0 = (yb - y) * 0.12;
    const sw1 = (yb - y + hh) * 0.14;
    const k = 1 + i * 0.07;
    b.cyl(x, yb, z, rad, 0, hh, 7, cr * k, cg * k, cb * k, sw0, sw1, rnd() * 6);
    if (snowy && i >= layers - 2) b.cyl(x, yb + hh * 0.55, z, rad * 0.48, 0, hh * 0.46, 7, 0.9, 0.93, 0.97, sw1 * 0.8, sw1, rnd() * 6);
  }
}

export function oak(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R) {
  const tr = 0.32 + rnd() * 0.05;
  b.cyl(x, y - 0.3, z, 0.38 * s, 0.24 * s, 3.0 * s, 6, tr, tr * 0.7, tr * 0.46);
  let r = 0.24, g = 0.44, bl = 0.16;
  const v = rnd();
  if (v < 0.07) { r = 0.55; g = 0.45; bl = 0.14; } // autumn touch
  else if (v < 0.35) { r = 0.3; g = 0.48; bl = 0.17; }
  else if (v < 0.55) { r = 0.19; g = 0.38; bl = 0.15; }
  const k = 0.9 + rnd() * 0.2;
  r *= k; g *= k; bl *= k;
  const cy = y + 3.4 * s;
  b.blob(x, cy, z, 2.2 * s, 1.8 * s, 2.2 * s, r, g, bl, rnd, 0.5 * s);
  const a = rnd() * 6.28;
  b.blob(x + Math.cos(a) * 1.4 * s, cy + 0.9 * s, z + Math.sin(a) * 1.4 * s, 1.4 * s, 1.2 * s, 1.4 * s, r * 1.1, g * 1.1, bl * 1.1, rnd, 0.7 * s);
  if (s > 1.05) b.blob(x - Math.cos(a) * 1.3 * s, cy - 0.3 * s, z - Math.sin(a) * 1.3 * s, 1.3 * s, 1.1 * s, 1.3 * s, r * 0.9, g * 0.9, bl * 0.9, rnd, 0.5 * s);
}

export function birch(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R) {
  b.cyl(x, y - 0.3, z, 0.17 * s, 0.12 * s, 4.6 * s, 5, 0.86, 0.85, 0.8);
  // bark marks
  for (let i = 0; i < 3; i++) {
    const yy = y + (0.8 + i * 1.2 + rnd() * 0.4) * s;
    b.box(x, yy, z, 0.36 * s, 0.14 * s, 0.36 * s, rnd() * 3, 0.2, 0.19, 0.18, 1);
  }
  const k = 0.9 + rnd() * 0.25;
  const yl = rnd() < 0.3;
  const r = (yl ? 0.62 : 0.45) * k, g = (yl ? 0.6 : 0.63) * k, bl = 0.22 * k;
  b.blob(x, y + 4.8 * s, z, 1.3 * s, 2.1 * s, 1.3 * s, r, g, bl, rnd, 0.8 * s);
  b.blob(x + 0.6 * s, y + 3.9 * s, z + 0.3 * s, 0.9 * s, 1.1 * s, 0.9 * s, r * 0.9, g * 0.9, bl * 0.9, rnd, 0.6 * s);
}

export function bush(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R, berries: boolean) {
  const k = 0.8 + rnd() * 0.4;
  const r = 0.2 * k, g = 0.4 * k, bl = 0.15 * k;
  b.blob(x, y + 0.45 * s, z, 1.0 * s, 0.75 * s, 1.0 * s, r, g, bl, rnd, 0.25);
  b.blob(x + 0.6 * s, y + 0.35 * s, z + 0.2 * s, 0.6 * s, 0.5 * s, 0.6 * s, r * 1.1, g * 1.1, bl, rnd, 0.2);
  if (berries) {
    for (let i = 0; i < 4; i++) {
      const a = rnd() * 6.28;
      b.octa(x + Math.cos(a) * 0.8 * s, y + (0.5 + rnd() * 0.4) * s, z + Math.sin(a) * 0.8 * s, 0.1, 0.1, 0.1, 0.8, 0.12, 0.2);
    }
  }
}

export function fern(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R) {
  const n = 6;
  const k = 0.8 + rnd() * 0.3;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * 6.28 + rnd();
    const ca = Math.cos(a), sa = Math.sin(a);
    const l = (0.9 + rnd() * 0.5) * s;
    const w = 0.22 * s;
    b.tri(x - sa * w, y, z + ca * w, x + ca * l, y + 0.55 * s, z + sa * l, x + sa * w, y, z - ca * w, 0.22 * k, 0.45 * k, 0.16 * k, 0, 0.6, 0);
  }
}

export function rock(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R, mossy: boolean) {
  const k = 0.85 + rnd() * 0.3;
  const warm = rnd() * 0.04;
  b.blob(x, y + 0.15 * s, z, 1.1 * s, 0.7 * s, 0.95 * s, (0.46 + warm) * k, 0.45 * k, (0.43 - warm) * k, rnd, 0, 0.28);
  if (mossy) b.blob(x, y + 0.55 * s, z, 0.8 * s, 0.3 * s, 0.7 * s, 0.28, 0.42, 0.18, rnd, 0, 0.2);
}

export function log(b: GeoBuilder, x: number, y: number, z: number, len: number, ang: number, rnd: R) {
  _e.set(0, ang, Math.PI / 2);
  _q.setFromEuler(_e);
  _v.set(x, y + 0.32, z);
  _m.compose(_v, _q, _s);
  b.setTransform(_m);
  const k = 0.85 + rnd() * 0.2;
  b.cyl(0, -len / 2, 0, 0.36, 0.32, len, 6, 0.36 * k, 0.25 * k, 0.16 * k, 0, 0, 0, false);
  b.cyl(0, -len / 2 - 0.02, 0, 0.001, 0.36, 0.02, 6, 0.6, 0.48, 0.3, 0, 0, 0, true);
  b.cyl(0, len / 2, 0, 0.32, 0.001, 0.02, 6, 0.6, 0.48, 0.3, 0, 0, 0, false);
  b.setTransform(null);
  // moss/mushrooms
  if (rnd() < 0.6) {
    const t = (rnd() - 0.5) * len * 0.6;
    b.octa(x + Math.cos(ang) * t, y + 0.72, z - Math.sin(ang) * t, 0.18, 0.1, 0.18, 0.85, 0.3, 0.2);
  }
}

export function grassTuft(b: GeoBuilder, x: number, y: number, z: number, s: number, rnd: R, r: number, g: number, bl: number) {
  for (let i = 0; i < 3; i++) {
    const a = rnd() * 6.28;
    const ca = Math.cos(a), sa = Math.sin(a);
    const w = 0.09 * s;
    const h = (0.45 + rnd() * 0.45) * s;
    const lean = (rnd() - 0.5) * 0.4;
    const ox = (rnd() - 0.5) * 0.4, oz = (rnd() - 0.5) * 0.4;
    const k = 0.85 + rnd() * 0.3;
    b.tri(x + ox - ca * w, y - 0.05, z + oz - sa * w, x + ox + ca * lean, y + h, z + oz + sa * lean, x + ox + ca * w, y - 0.05, z + oz + sa * w, r * k, g * k, bl * k, 0, 1, 0);
  }
}

const FLOWER_COLS: [number, number, number][] = [
  [0.95, 0.95, 0.92], [0.98, 0.85, 0.25], [0.7, 0.35, 0.9], [0.9, 0.3, 0.3], [0.45, 0.55, 0.95], [0.95, 0.55, 0.75],
];
export function flower(b: GeoBuilder, x: number, y: number, z: number, rnd: R, palette = -1) {
  const c = FLOWER_COLS[palette >= 0 ? palette : Math.floor(rnd() * FLOWER_COLS.length)];
  const h = 0.35 + rnd() * 0.3;
  b.tri(x - 0.04, y, z, x, y + h, z, x + 0.04, y, z, 0.25, 0.45, 0.18, 0, 0.8, 0);
  b.octa(x, y + h, z, 0.12, 0.07, 0.12, c[0], c[1], c[2], rnd() * 3);
}

export function reeds(b: GeoBuilder, x: number, y: number, z: number, rnd: R) {
  for (let i = 0; i < 5; i++) {
    const ox = (rnd() - 0.5) * 0.9, oz = (rnd() - 0.5) * 0.9;
    const h = 1.0 + rnd() * 0.8;
    const a = rnd() * 6.28;
    const ca = Math.cos(a) * 0.05, sa = Math.sin(a) * 0.05;
    const k = 0.8 + rnd() * 0.3;
    b.tri(x + ox - ca, y - 0.3, z + oz - sa, x + ox + (rnd() - 0.5) * 0.2, y + h, z + oz, x + ox + ca, y - 0.3, z + oz + sa, 0.3 * k, 0.45 * k, 0.2 * k, 0, 1, 0);
    if (i < 2) b.box(x + ox, y + h * 0.7, z + oz, 0.1, 0.28, 0.1, 0, 0.4, 0.26, 0.14, 1);
  }
}

export function mushroom(b: GeoBuilder, x: number, y: number, z: number, rnd: R) {
  b.cyl(x, y, z, 0.05, 0.05, 0.22, 4, 0.9, 0.88, 0.8);
  const red = rnd() < 0.5;
  b.cyl(x, y + 0.2, z, 0.18, 0, 0.14, 6, red ? 0.8 : 0.6, red ? 0.2 : 0.45, red ? 0.15 : 0.3);
}
