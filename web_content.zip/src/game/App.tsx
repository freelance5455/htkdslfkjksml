import { useEffect } from "react";
import { Archive } from "./screens/Archive";
import { Combat } from "./screens/Combat";
import { Episodes } from "./screens/Episodes";
import { Menu } from "./screens/Menu";
import { Play } from "./screens/Play";
import { Rewards } from "./screens/Rewards";
import { Settings } from "./screens/Settings";
import { Squad } from "./screens/Squad";
import { useGame } from "./store";
import { persistSave } from "./save";
import { unlockAudio } from "./audio";
import { Label, Shell } from "./components/Shell";

export function GameApp() {
  const hydrated = useGame((s) => s.hydrated);
  const screen = useGame((s) => s.screen);
  const hydrate = useGame((s) => s.hydrate);

  useEffect(() => {
    let cancelled = false;
    const assets = [
      "/game/bg/loading.jpg",
      "/game/bg/hall.jpg",
      "/game/bg/outpost.jpg",
      "/game/bg/vault.jpg",
    ];
    Promise.all(assets.map((src) => new Promise<void>((resolve) => {
      const img = new Image();
      img.onload = () => resolve();
      img.onerror = () => resolve();
      img.src = src;
    }))).then(() => {
      if (!cancelled) hydrate();
    });
    return () => { cancelled = true; };
  }, [hydrate]);

  useEffect(() => {
    const onHide = () => {
      const { save } = useGame.getState();
      if (save.hasSave) persistSave(save);
    };
    const onVis = () => {
      if (document.visibilityState === "hidden") onHide();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pagehide", onHide);
    const unlock = () => unlockAudio();
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pagehide", onHide);
    };
  }, []);

  if (!hydrated || screen === "boot") {
    return (
      <Shell bg="loading" dim={false}>
        <div className="flex flex-1 flex-col justify-between px-6 py-8 sm:px-12 sm:py-10">
          <div className="flex items-center gap-3">
            <span className="text-2xl text-white/90">✦</span>
            <h1 className="font-display text-xl font-semibold tracking-[0.25em] text-white sm:text-2xl">
              MAYONIN CHRONICLES
            </h1>
          </div>
          <div className="max-w-lg self-end text-right">
            <p className="text-sm italic leading-relaxed text-white/85 sm:text-base">
              “The world is not empty. It’s just waiting.”
            </p>
            <p className="mt-2 text-xs tracking-wide text-white/60">— Arden</p>
          </div>
          <div className="flex items-center justify-end gap-3">
            <span className="text-xs uppercase tracking-[0.2em] text-white/70">Loading…</span>
            <div className="h-1 w-24 overflow-hidden rounded bg-white/20">
              <div className="h-full w-2/3 animate-pulse bg-white/70" />
            </div>
          </div>
        </div>
      </Shell>
    );
  }

  if (screen === "menu") return <Menu />;
  if (screen === "episodes") return <Episodes />;
  if (screen === "squad") return <Squad />;
  if (screen === "archive") return <Archive />;
  if (screen === "settings") return <Settings />;
  if (screen === "play") return <Play />;
  if (screen === "combat") return <Combat />;
  if (screen === "rewards") return <Rewards />;
  return <Menu />;
}
