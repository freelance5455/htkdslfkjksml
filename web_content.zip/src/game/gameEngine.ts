import {
  Camera,
  Chicken,
  ClimbableWall,
  GameDifficulty,
  GameState,
  GameStats,
  HidingSpot,
  MazeData,
  Particle,
  Player,
  Point,
} from '../types/game';
import { sounds } from '../audio/soundManager';
import { generateMaze, TILE_SIZE } from './mazeGenerator';
import { findPath, getDistance, hasLineOfSight, isWalkable } from './pathfinding';

export interface EngineCallbacks {
  onGameOver: (stats: GameStats) => void;
  onVictory: (stats: GameStats) => void;
  onChaseChange: (isChased: boolean) => void;
  onStatsUpdate: (stats: GameStats) => void;
  onLadderAvailableChange: (available: ClimbableWall | null) => void;
  onPortalLockedWarning?: (warning: string | null) => void;
}

export class GameEngine {
  public maze: MazeData;
  public player: Player;
  public chickens: Chicken[];
  public particles: Particle[] = [];
  public camera: Camera;
  public state: GameState = 'menu';
  public difficulty: GameDifficulty = 'normal';

  public stats: GameStats = {
    timeElapsed: 0,
    chaseCount: 0,
    hidesUsed: 0,
    laddersUsed: 0,
    crystalsCollected: 0,
    totalCrystals: 3,
    difficulty: 'normal',
    score: 0,
  };

  public portalWarningTimer: number = 0;

  private callbacks: EngineCallbacks;
  private animFrameId: number | null = null;
  private anyChickenChasing: boolean = false;
  private nearestChickenDistance: number = 9999;
  private ladderHammerTick: number = 0;
  private keyState: { [key: string]: boolean } = {};
  private joystickVector: { x: number; y: number } = { x: 0, y: 0 };

  constructor(callbacks: EngineCallbacks, difficulty: GameDifficulty = 'normal') {
    this.callbacks = callbacks;
    this.difficulty = difficulty;
    this.maze = generateMaze(difficulty);
    this.player = this.createInitialPlayer();
    this.chickens = this.maze.initialChickens;

    // Elevated 2.5D camera tuned for full-screen 9:16 portrait view
    this.camera = {
      x: this.player.x,
      y: this.player.y,
      zoom: 0.90,
    };
  }

  private createInitialPlayer(): Player {
    const startGrid = this.maze.playerStartGrid;
    // Provide plenty of ladders for the randomly distributed climbable walls
    const maxLadders = this.difficulty === 'easy' ? 4 : this.difficulty === 'normal' ? 3 : 2;

    return {
      x: startGrid.x * TILE_SIZE + TILE_SIZE / 2,
      y: startGrid.y * TILE_SIZE + TILE_SIZE / 2,
      vx: 0,
      vy: 0,
      // Player base speed slightly faster than chickens (122 vs 108)
      speed: 124,
      isHiding: false,
      isAtFakeBush: false,
      hiddenInSpotId: null,
      facing: 'down',
      animTick: 0,
      path: [],
      isPlacingLadder: false,
      ladderTimeRemaining: 0,
      activeLadderWall: null,
      laddersAvailable: maxLadders,
    };
  }

  public startRun(difficulty: GameDifficulty = this.difficulty) {
    this.difficulty = difficulty;
    this.maze = generateMaze(difficulty);
    this.player = this.createInitialPlayer();
    this.chickens = this.maze.initialChickens;
    this.particles = [];
    this.state = 'playing';

    this.stats = {
      timeElapsed: 0,
      chaseCount: 0,
      hidesUsed: 0,
      laddersUsed: 0,
      crystalsCollected: 0,
      totalCrystals: 3,
      difficulty,
      score: 0,
    };

    this.portalWarningTimer = 0;
    this.camera.x = this.player.x;
    this.camera.y = this.player.y;
    this.ladderHammerTick = 0;
    this.anyChickenChasing = false;
    this.callbacks.onChaseChange(false);
    this.callbacks.onPortalLockedWarning?.(null);
    this.callbacks.onStatsUpdate(this.stats);

    sounds.playClick();
  }

  public setKeyboard(key: string, pressed: boolean) {
    this.keyState[key.toLowerCase()] = pressed;
    // Any direct movement key breaks hiding or leaves fake bush
    if (pressed && (this.player.isHiding || this.player.isAtFakeBush)) {
      this.exitHiding();
    }
  }

  public setJoystick(x: number, y: number) {
    this.joystickVector = { x, y };
    if ((Math.abs(x) > 0.15 || Math.abs(y) > 0.15) && (this.player.isHiding || this.player.isAtFakeBush)) {
      this.exitHiding();
    }
  }

  // Tap or click on world coordinate
  public handleWorldClick(worldX: number, worldY: number) {
    if (this.state !== 'playing') return;

    // If currently inside a real bush or fake bush, click exits it
    if (this.player.isHiding || this.player.isAtFakeBush) {
      this.exitHiding();
      return;
    }

    // If currently placing ladder, cannot move
    if (this.player.isPlacingLadder) return;

    // Check if clicked directly on an adjacent or nearby bush
    const clickedHidingSpot = this.maze.hidingSpots.find((spot) => {
      return Math.hypot(spot.x - worldX, spot.y - worldY) < TILE_SIZE * 0.75;
    });

    if (clickedHidingSpot) {
      const distToSpot = Math.hypot(this.player.x - clickedHidingSpot.x, this.player.y - clickedHidingSpot.y);
      if (distToSpot < TILE_SIZE * 1.35) {
        this.enterHiding(clickedHidingSpot);
        return;
      }
    }

    // Otherwise calculate walkable path to clicked destination
    const targetGridX = Math.floor(worldX / TILE_SIZE);
    const targetGridY = Math.floor(worldY / TILE_SIZE);

    if (isWalkable(this.maze.tiles, targetGridX, targetGridY)) {
      const startGridX = Math.floor(this.player.x / TILE_SIZE);
      const startGridY = Math.floor(this.player.y / TILE_SIZE);

      const pathNodes = findPath(
        this.maze.tiles,
        { x: startGridX, y: startGridY },
        { x: targetGridX, y: targetGridY }
      );

      if (pathNodes.length > 0) {
        // Convert to pixel waypoints
        this.player.path = pathNodes.map((node) => ({
          x: node.x * TILE_SIZE + TILE_SIZE / 2,
          y: node.y * TILE_SIZE + TILE_SIZE / 2,
        }));
        // Target destination dot particle
        this.addSparkleParticle(worldX, worldY, '#38bdf8');
      }
    }
  }

  public enterHiding(spot: HidingSpot) {
    if (this.player.isPlacingLadder) return;
    if (this.player.isHiding && this.player.hiddenInSpotId === spot.id) return;

    spot.isOccupied = true;
    spot.revealed = true;
    this.player.hiddenInSpotId = spot.id;
    this.player.x = spot.x;
    this.player.y = spot.y;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.path = [];

    if (!spot.isFake) {
      // REAL HIDING BUSH:
      // "When the player enters, make them semi-transparent and completely immune to chickens.
      // All chickens must immediately stop chasing and forget the player's location.
      // They cannot detect, attack, or catch the hidden player."
      this.player.isHiding = true;
      this.player.isAtFakeBush = false;
      this.stats.hidesUsed++;
      sounds.playRustle();

      // All pursuing chickens immediately stop chasing and forget player's location
      for (const chk of this.chickens) {
        if (chk.state === 'chase' || chk.state === 'investigate') {
          chk.state = 'patrol';
          chk.path = [];
          chk.lastKnownPlayerPos = null;
          chk.squawkBubble = 'BAWK?';
          chk.squawkTimer = 1.0;
        }
      }
      this.anyChickenChasing = false;
      sounds.stopHeartbeat();
      this.callbacks.onChaseChange(false);

      // Lush green leaf burst
      for (let i = 0; i < 9; i++) {
        this.particles.push({
          x: spot.x + (Math.random() - 0.5) * 16,
          y: spot.y + (Math.random() - 0.5) * 16,
          vx: (Math.random() - 0.5) * 45,
          vy: (Math.random() - 0.5) * 45 - 20,
          life: 0.65,
          maxLife: 0.65,
          color: '#22c55e',
          size: 3.5,
          type: 'dust',
        });
      }
    } else {
      // FAKE HIDING BUSH:
      // "Fake bushes: Provide no protection. The player remains visible and can be chased and caught normally."
      this.player.isHiding = false; // NOT immune! Remains visible and targetable!
      this.player.isAtFakeBush = true;
      sounds.playFakeBush();

      // Dry brittle twigs / dust warning burst
      for (let i = 0; i < 9; i++) {
        this.particles.push({
          x: spot.x + (Math.random() - 0.5) * 16,
          y: spot.y + (Math.random() - 0.5) * 16,
          vx: (Math.random() - 0.5) * 50,
          vy: (Math.random() - 0.5) * 50 - 15,
          life: 0.55,
          maxLife: 0.55,
          color: '#eab308',
          size: 3,
          type: 'dust',
        });
      }
      // Chasing chickens continue chasing, can detect, attack, and catch the player!
    }
  }

  public exitHiding() {
    if (!this.player.isHiding && !this.player.isAtFakeBush) return;

    if (this.player.hiddenInSpotId) {
      const spot = this.maze.hidingSpots.find((s) => s.id === this.player.hiddenInSpotId);
      if (spot) {
        spot.isOccupied = false;
      }
    }

    const wasRealHiding = this.player.isHiding;
    this.player.isHiding = false;
    this.player.isAtFakeBush = false;
    this.player.hiddenInSpotId = null;

    if (wasRealHiding) {
      sounds.playRustle();
    }
  }

  // Ladder Mechanic: 5-second placement countdown
  public startLadderPlacement(wall: ClimbableWall) {
    if (this.player.laddersAvailable <= 0 || this.player.isPlacingLadder || wall.isUsed) {
      return;
    }

    this.player.isPlacingLadder = true;
    this.player.ladderTimeRemaining = 5.0; // exactly 5.0 seconds
    this.player.activeLadderWall = wall;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.path = [];
    this.ladderHammerTick = 0;

    sounds.playLadderHammer(1);
  }

  public cancelLadderPlacement() {
    if (this.player.isPlacingLadder) {
      this.player.isPlacingLadder = false;
      this.player.ladderTimeRemaining = 0;
      this.player.activeLadderWall = null;
    }
  }

  private completeLadderPlacement() {
    const wall = this.player.activeLadderWall;
    if (!wall) return;

    this.player.isPlacingLadder = false;
    this.player.laddersAvailable--;
    this.stats.laddersUsed++;
    wall.isUsed = true;

    // Determine target corridor side
    const playerGridX = Math.floor(this.player.x / TILE_SIZE);
    const playerGridY = Math.floor(this.player.y / TILE_SIZE);

    const distToA = Math.hypot(playerGridX - wall.sideA.x, playerGridY - wall.sideA.y);
    const landing = distToA < 1.5 ? wall.sideB : wall.sideA;

    // Safely teleport / land player on the valid corridor on the other side
    this.player.x = landing.x * TILE_SIZE + TILE_SIZE / 2;
    this.player.y = landing.y * TILE_SIZE + TILE_SIZE / 2;
    this.player.activeLadderWall = null;

    sounds.playLadderComplete();

    // Wood chips / sparkle burst
    for (let i = 0; i < 14; i++) {
      this.particles.push({
        x: this.player.x,
        y: this.player.y,
        vx: (Math.random() - 0.5) * 80,
        vy: (Math.random() - 0.5) * 80,
        life: 0.8,
        maxLife: 0.8,
        color: '#eab308',
        size: 3.5,
        type: 'wood',
      });
    }
  }

  // Check if player is currently adjacent to an unused climbable wall
  private getNearbyClimbableWall(): ClimbableWall | null {
    if (this.player.isHiding) return null;

    const pgx = Math.floor(this.player.x / TILE_SIZE);
    const pgy = Math.floor(this.player.y / TILE_SIZE);

    for (const cw of this.maze.climbableWalls) {
      if (cw.isUsed) continue;
      const isAtA = pgx === cw.sideA.x && pgy === cw.sideA.y;
      const isAtB = pgx === cw.sideB.x && pgy === cw.sideB.y;
      if (isAtA || isAtB) {
        return cw;
      }
    }
    return null;
  }

  public update(dt: number) {
    if (this.state !== 'playing') return;

    // Cap delta time to prevent physics anomalies
    const delta = Math.min(dt, 0.1);

    this.stats.timeElapsed += delta;
    this.callbacks.onStatsUpdate(this.stats);

    // 1. Update Ladder 5-second placement if active
    if (this.player.isPlacingLadder) {
      this.updateLadderPlacement(delta);
    } else if (!this.player.isHiding) {
      // 2. Update Player Movement (Keyboard, Joystick, or Click-path)
      this.updatePlayerMovement(delta);
    }

    // 3. Check Crystal Collection
    for (const crystal of this.maze.crystals) {
      if (!crystal.collected) {
        const dist = Math.hypot(this.player.x - crystal.x, this.player.y - crystal.y);
        if (dist < 26) {
          crystal.collected = true;
          this.stats.crystalsCollected++;
          sounds.playCrystalCollect(this.stats.crystalsCollected);

          // Crystal collection sparkle burst
          for (let i = 0; i < 18; i++) {
            const ang = Math.random() * Math.PI * 2;
            const spd = 30 + Math.random() * 65;
            this.particles.push({
              x: crystal.x,
              y: crystal.y,
              vx: Math.cos(ang) * spd,
              vy: Math.sin(ang) * spd,
              life: 0.65,
              maxLife: 0.65,
              color: crystal.color,
              size: 3.5,
              type: 'sparkle',
            });
          }

          // Check if all 3 crystals collected -> unlock the central portal!
          if (this.stats.crystalsCollected >= 3) {
            this.maze.portalUnlocked = true;
            sounds.playPortalUnlocked();

            // Big unlock burst at portal
            const portalCenterPx = this.maze.portalGrid.x * TILE_SIZE + TILE_SIZE / 2;
            const portalCenterPy = this.maze.portalGrid.y * TILE_SIZE + TILE_SIZE / 2;
            for (let i = 0; i < 28; i++) {
              const ang = Math.random() * Math.PI * 2;
              const spd = 40 + Math.random() * 70;
              this.particles.push({
                x: portalCenterPx,
                y: portalCenterPy,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd,
                life: 0.9,
                maxLife: 0.9,
                color: Math.random() > 0.5 ? '#38bdf8' : '#fbbf24',
                size: 4,
                type: 'portal',
              });
            }
          }

          this.callbacks.onStatsUpdate(this.stats);
        }
      }
    }

    // 4. Check Portal Condition (Locked until 3 crystals collected)
    const portalCenterPx = this.maze.portalGrid.x * TILE_SIZE + TILE_SIZE / 2;
    const portalCenterPy = this.maze.portalGrid.y * TILE_SIZE + TILE_SIZE / 2;
    const distToPortal = Math.hypot(this.player.x - portalCenterPx, this.player.y - portalCenterPy);

    if (distToPortal < 34) {
      if (this.maze.portalUnlocked) {
        if (distToPortal < 28) {
          this.triggerVictory();
          return;
        }
      } else {
        // Portal is locked!
        if (this.portalWarningTimer <= 0) {
          this.portalWarningTimer = 2.4;
          sounds.playPortalLocked();

          // Pushback barrier ring ripple particles
          for (let i = 0; i < 12; i++) {
            const ang = (i / 12) * Math.PI * 2;
            this.particles.push({
              x: portalCenterPx + Math.cos(ang) * 26,
              y: portalCenterPy + Math.sin(ang) * 26,
              vx: Math.cos(ang) * 35,
              vy: Math.sin(ang) * 35,
              life: 0.4,
              maxLife: 0.4,
              color: '#f87171',
              size: 3,
              type: 'portal',
            });
          }
        }
      }
    }

    if (this.portalWarningTimer > 0) {
      this.portalWarningTimer -= delta;
      this.callbacks.onPortalLockedWarning?.(
        this.portalWarningTimer > 0
          ? `COLLECT ALL 3 CRYSTALS! (${this.stats.crystalsCollected}/3)`
          : null
      );
    }

    // 5. Update Chickens (Patrol, Line of Sight, Chase, Investigate, Catch)
    this.updateChickens(delta);

    // 5. Update Nearby Climbable Wall detection for UI Ladder button
    const nearbyWall = this.getNearbyClimbableWall();
    this.callbacks.onLadderAvailableChange(
      nearbyWall && this.player.laddersAvailable > 0 ? nearbyWall : null
    );

    // 6. Update Particles
    this.updateParticles(delta);

    // 7. Update Elevated Camera Position
    this.updateCamera(delta);
  }

  private updateLadderPlacement(dt: number) {
    this.player.ladderTimeRemaining -= dt;
    this.ladderHammerTick += dt;

    if (this.ladderHammerTick >= 1.0) {
      this.ladderHammerTick -= 1.0;
      const secondPassed = 5 - Math.floor(this.player.ladderTimeRemaining);
      sounds.playLadderHammer(secondPassed);

      // Wood chip particle
      this.particles.push({
        x: this.player.x + (Math.random() - 0.5) * 12,
        y: this.player.y + (Math.random() - 0.5) * 12,
        vx: (Math.random() - 0.5) * 30,
        vy: -35,
        life: 0.4,
        maxLife: 0.4,
        color: '#b45309',
        size: 3,
        type: 'wood',
      });
    }

    if (this.player.ladderTimeRemaining <= 0) {
      this.completeLadderPlacement();
    }
  }

  private updatePlayerMovement(dt: number) {
    const player = this.player;

    // Check keyboard input
    let dirX = 0;
    let dirY = 0;

    if (this.keyState['arrowup'] || this.keyState['w']) dirY -= 1;
    if (this.keyState['arrowdown'] || this.keyState['s']) dirY += 1;
    if (this.keyState['arrowleft'] || this.keyState['a']) dirX -= 1;
    if (this.keyState['arrowright'] || this.keyState['d']) dirX += 1;

    // Apply virtual joystick if active
    if (Math.abs(this.joystickVector.x) > 0.1 || Math.abs(this.joystickVector.y) > 0.1) {
      dirX = this.joystickVector.x;
      dirY = this.joystickVector.y;
    }

    // Direct directional input takes priority over tap-path
    if (dirX !== 0 || dirY !== 0) {
      if (this.player.isAtFakeBush) {
        this.exitHiding();
      }
      player.path = []; // cancel click path
      const len = Math.hypot(dirX, dirY);
      const normX = (dirX / len) * player.speed;
      const normY = (dirY / len) * player.speed;

      this.moveEntityWithCollision(player, normX * dt, normY * dt);

      // Facing
      if (Math.abs(dirX) > Math.abs(dirY)) {
        player.facing = dirX > 0 ? 'right' : 'left';
      } else {
        player.facing = dirY > 0 ? 'down' : 'up';
      }
      player.animTick += dt;

      // Footstep sound & dust puff
      if (Math.random() < 0.12) {
        sounds.playStep();
        this.addDustParticle(player.x, player.y + 8);
      }
    } else if (player.path.length > 0) {
      // Follow tap-to-move waypoints
      const target = player.path[0];
      const dx = target.x - player.x;
      const dy = target.y - player.y;
      const dist = Math.hypot(dx, dy);

      if (dist < 5) {
        player.path.shift();
        // If finished path, check if arrived at a bush
        if (player.path.length === 0) {
          const reachedBush = this.maze.hidingSpots.find(
            (s) => Math.hypot(s.x - player.x, s.y - player.y) < 18
          );
          if (reachedBush && !player.isHiding && !player.isAtFakeBush) {
            this.enterHiding(reachedBush);
          }
        }
      } else {
        const moveDist = Math.min(dist, player.speed * dt);
        player.x += (dx / dist) * moveDist;
        player.y += (dy / dist) * moveDist;

        if (Math.abs(dx) > Math.abs(dy)) {
          player.facing = dx > 0 ? 'right' : 'left';
        } else {
          player.facing = dy > 0 ? 'down' : 'up';
        }
        player.animTick += dt;

        if (Math.random() < 0.12) {
          sounds.playStep();
          this.addDustParticle(player.x, player.y + 8);
        }
      }
    }
  }

  // Move circle entity with sliding against solid maze walls
  private moveEntityWithCollision(
    entity: { x: number; y: number },
    dx: number,
    dy: number,
    radius = 12
  ) {
    const newX = entity.x + dx;
    const newY = entity.y + dy;

    // Check X axis movement
    if (!this.checkWallCollision(newX, entity.y, radius)) {
      entity.x = newX;
    }

    // Check Y axis movement
    if (!this.checkWallCollision(entity.x, newY, radius)) {
      entity.y = newY;
    }
  }

  private checkWallCollision(x: number, y: number, radius: number): boolean {
    const minGx = Math.floor((x - radius) / TILE_SIZE);
    const maxGx = Math.floor((x + radius) / TILE_SIZE);
    const minGy = Math.floor((y - radius) / TILE_SIZE);
    const maxGy = Math.floor((y + radius) / TILE_SIZE);

    for (let gy = minGy; gy <= maxGy; gy++) {
      for (let gx = minGx; gx <= maxGx; gx++) {
        if (!isWalkable(this.maze.tiles, gx, gy)) {
          const tileLeft = gx * TILE_SIZE;
          const tileRight = tileLeft + TILE_SIZE;
          const tileTop = gy * TILE_SIZE;
          const tileBottom = tileTop + TILE_SIZE;

          // Closest point on wall AABB
          const closestX = Math.max(tileLeft, Math.min(x, tileRight));
          const closestY = Math.max(tileTop, Math.min(y, tileBottom));

          const distSq = (x - closestX) ** 2 + (y - closestY) ** 2;
          if (distSq < radius * radius) {
            return true;
          }
        }
      }
    }
    return false;
  }

  private updateChickens(dt: number) {
    let currentlyChasingCount = 0;
    let minChickenDist = 9999;

    const playerPos: Point = { x: this.player.x, y: this.player.y };
    const playerHidden = this.player.isHiding;

    this.chickens.forEach((chk) => {
      chk.animTick += dt;

      // Squawk speech timer
      if (chk.squawkTimer > 0) {
        chk.squawkTimer -= dt;
        if (chk.squawkTimer <= 0) chk.squawkBubble = null;
      }

      const distToPlayer = getDistance(chk, playerPos);
      if (distToPlayer < minChickenDist) {
        minChickenDist = distToPlayer;
      }

      // Check Real Line of Sight: Raycast through walls
      // (Chickens cannot see through walls or into bushes)
      const canSeePlayer =
        !playerHidden &&
        distToPlayer < 400 &&
        hasLineOfSight(this.maze.tiles, chk, playerPos, TILE_SIZE);

      // State transitions:
      // Requirement 3: Once a chicken sees the player, it must keep chasing even when
      // the chicken goes off-screen or the player runs far away.
      // It must stop chasing ONLY when the player successfully hides inside a bush or gets caught.
      if (playerHidden) {
        // Player is hidden in a bush: chicken completely loses player and stops chasing
        if (chk.state === 'chase' || chk.state === 'investigate') {
          chk.state = 'patrol';
          chk.path = [];
          chk.lastKnownPlayerPos = null;
          chk.squawkBubble = 'BAWK?';
          chk.squawkTimer = 1.0;
        }
      } else if (canSeePlayer) {
        // Chicken spots player with direct unobstructed sight line
        if (chk.state !== 'chase') {
          chk.state = 'chase';
          chk.alertAnimationTime = 1.0;
          chk.squawkBubble = 'SQUAWK!';
          chk.squawkTimer = 1.2;
          sounds.playAlertSquawk();
          this.stats.chaseCount++;
        }
        chk.lastKnownPlayerPos = { x: playerPos.x, y: playerPos.y };
      }
      // If chicken was already chasing and line of sight is broken (e.g. player turned corner or ran far away),
      // it KEEPS CHASING relentlessly through the maze corridors! It does NOT stop or switch to investigate.

      // Execute AI behavior based on state
      if (chk.state === 'chase') {
        currentlyChasingCount++;
        this.runChickenChase(chk, playerPos, dt);
      } else {
        this.runChickenPatrol(chk, dt);
      }

      // Random occasional chicken cluck in patrol
      if (chk.state === 'patrol' && Math.random() < 0.003) {
        sounds.playCluck();
      }

      // Catch check: if chicken catches player
      if (distToPlayer < 22 && !this.player.isHiding) {
        this.triggerDefeat();
      }
    });

    this.nearestChickenDistance = minChickenDist;

    // Trigger heartbeat & chase callback
    const isNowChased = currentlyChasingCount > 0;
    if (isNowChased !== this.anyChickenChasing) {
      this.anyChickenChasing = isNowChased;
      this.callbacks.onChaseChange(isNowChased);
      if (isNowChased) {
        sounds.startHeartbeat();
      } else {
        sounds.stopHeartbeat();
      }
    }
  }

  // Chicken corridor navigation without flying, jumping over walls, or getting stuck
  private runChickenChase(chk: Chicken, playerPos: Point, dt: number) {
    if (chk.repathTimer === undefined) chk.repathTimer = 0;
    chk.repathTimer -= dt;

    const chkGridX = Math.floor(chk.x / TILE_SIZE);
    const chkGridY = Math.floor(chk.y / TILE_SIZE);
    const pGridX = Math.floor(playerPos.x / TILE_SIZE);
    const pGridY = Math.floor(playerPos.y / TILE_SIZE);

    // Staggered frequent repathing to track player across corners, junctions, and long distances
    if (chk.path.length === 0 || chk.repathTimer <= 0) {
      chk.repathTimer = 0.22 + Math.random() * 0.12;
      const nodes = findPath(
        this.maze.tiles,
        { x: chkGridX, y: chkGridY },
        { x: pGridX, y: pGridY },
        1200
      );

      if (nodes.length > 1) {
        // Waypoints along corridor tile centers
        chk.path = nodes.slice(1).map((n) => ({
          x: n.x * TILE_SIZE + TILE_SIZE / 2,
          y: n.y * TILE_SIZE + TILE_SIZE / 2,
        }));
      } else if (nodes.length === 1) {
        chk.path = [{ x: playerPos.x, y: playerPos.y }];
      }
    }

    if (chk.path.length > 0) {
      const target = chk.path[0];
      const dx = target.x - chk.x;
      const dy = target.y - chk.y;
      const dist = Math.hypot(dx, dy);

      if (dist < 8) {
        // Reached current corridor waypoint, move to next waypoint
        chk.path.shift();
      } else {
        const moveDist = Math.min(dist, chk.speed * dt);
        const stepX = (dx / dist) * moveDist;
        const stepY = (dy / dist) * moveDist;

        // Ground-bound corridor movement with solid wall collision:
        // Chickens cannot fly, jump over walls, or pass through walls!
        this.moveEntityWithCollision(chk, stepX, stepY, 11);

        if (Math.abs(dx) > Math.abs(dy)) {
          chk.facing = dx > 0 ? 'right' : 'left';
        } else {
          chk.facing = dy > 0 ? 'down' : 'up';
        }

        // Footstep dust puff on the ground
        if (Math.random() < 0.08) {
          this.addDustParticle(chk.x, chk.y + 6);
        }
      }
    }
  }

  private runChickenPatrol(chk: Chicken, dt: number) {
    if (chk.patrolRoute.length === 0) return;

    const target = chk.patrolRoute[chk.patrolIdx];
    const dx = target.x - chk.x;
    const dy = target.y - chk.y;
    const dist = Math.hypot(dx, dy);

    if (dist < 8) {
      chk.patrolIdx = (chk.patrolIdx + 1) % chk.patrolRoute.length;
    } else {
      const moveDist = Math.min(dist, (chk.speed * 0.6) * dt);
      const stepX = (dx / dist) * moveDist;
      const stepY = (dy / dist) * moveDist;

      // Grounded corridor movement with solid wall collision
      this.moveEntityWithCollision(chk, stepX, stepY, 11);

      if (Math.abs(dx) > Math.abs(dy)) {
        chk.facing = dx > 0 ? 'right' : 'left';
      } else {
        chk.facing = dy > 0 ? 'down' : 'up';
      }
    }
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // Ambient portal sparkles around center
    if (Math.random() < 0.4) {
      const px = this.maze.portalGrid.x * TILE_SIZE + TILE_SIZE / 2;
      const py = this.maze.portalGrid.y * TILE_SIZE + TILE_SIZE / 2;
      const angle = Math.random() * Math.PI * 2;
      const rad = 10 + Math.random() * 32;

      this.particles.push({
        x: px + Math.cos(angle) * rad,
        y: py + Math.sin(angle) * rad,
        vx: -Math.cos(angle) * 15,
        vy: -Math.sin(angle) * 15,
        life: 0.6,
        maxLife: 0.6,
        color: Math.random() > 0.5 ? '#38bdf8' : '#c084fc',
        size: 2.5,
        type: 'portal',
      });
    }
  }

  private addDustParticle(x: number, y: number) {
    this.particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 18,
      vy: (Math.random() - 0.5) * 18,
      life: 0.35,
      maxLife: 0.35,
      color: 'rgba(148, 163, 184, 0.4)',
      size: 2.2,
      type: 'dust',
    });
  }

  private addSparkleParticle(x: number, y: number, color: string) {
    for (let i = 0; i < 4; i++) {
      this.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 35,
        vy: (Math.random() - 0.5) * 35,
        life: 0.4,
        maxLife: 0.4,
        color,
        size: 2.5,
        type: 'sparkle',
      });
    }
  }

  // Smooth elevated camera tracking
  private updateCamera(dt: number) {
    // Lerp smoothly to player coordinates
    const lerpSpeed = 7.0;
    this.camera.x += (this.player.x - this.camera.x) * Math.min(1, lerpSpeed * dt);
    this.camera.y += (this.player.y - this.camera.y) * Math.min(1, lerpSpeed * dt);
  }

  private triggerVictory() {
    this.state = 'victory';
    sounds.stopHeartbeat();
    sounds.playVictory();

    // Calculate score: Base 5000 - time penalties + difficulty bonus
    const timePenalty = Math.floor(this.stats.timeElapsed * 15);
    const diffBonus = this.difficulty === 'hard' ? 3000 : this.difficulty === 'normal' ? 1500 : 500;
    this.stats.score = Math.max(500, 5000 + diffBonus - timePenalty);

    this.callbacks.onVictory(this.stats);
  }

  private triggerDefeat() {
    this.state = 'gameover';
    sounds.stopHeartbeat();
    sounds.playDefeat();
    this.callbacks.onGameOver(this.stats);
  }

  public getAnyChickenChasing(): boolean {
    return this.anyChickenChasing;
  }

  public getNearestChickenDistance(): number {
    return this.nearestChickenDistance;
  }

  public destroy() {
    sounds.stopHeartbeat();
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
  }
}
