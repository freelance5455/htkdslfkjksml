import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { buildIndianFamilyHouse, BoxCollider } from './houseBuilder';
import {
  createAyushCharacter,
  createAravCharacter,
  createAkshharaCharacter,
  createRipinCharacter,
  createAnjeetaCharacter,
  AnimatedCharacter,
} from './characterFactory';
import { ItemsManager, WorldItem } from './itemsManager';
import { soundEngine } from '../audio/soundSystem';
import { CharacterId } from '../types/game';

// Pre-allocated reusable math objects outside loop (Zero GC)
const _playerMoveVec = new THREE.Vector3();
const _desiredCamPos = new THREE.Vector3();
const _camLookAt = new THREE.Vector3();
const _tempVecA = new THREE.Vector3();
const _tempVecB = new THREE.Vector3();

export interface InputState {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  run: boolean;
  jump: boolean;
  interact: boolean;
  virtualJoystickX: number;
  virtualJoystickY: number;
}

export interface EngineCallbacks {
  onCollectCoin: (count: number) => void;
  onCollectStar: (count: number) => void;
  onCollectMissionItem: (itemId: string, name: string) => void;
  onNearInteractable: (target: { id: string; name: string; type: 'character' | 'item'; characterId?: CharacterId } | null) => void;
}

export class GameEngine {
  private container: HTMLDivElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private clock = new THREE.Clock();
  private animFrameId: number | null = null;
  private isDestroyed = false;

  // World Elements
  private colliders: BoxCollider[] = [];
  public itemsManager: ItemsManager;

  // Characters
  public ayush: AnimatedCharacter;
  public arav: AnimatedCharacter;
  public akshhara: AnimatedCharacter;
  public ripin: AnimatedCharacter;
  public anjeeta: AnimatedCharacter;

  // Player Physics & Kinematics
  private playerPos = new THREE.Vector3(0, 0, 7); // Start in Living Room center
  private playerVelocityY = 0;
  private playerRotationY = Math.PI; // Face north towards TV and courtyard
  private isGrounded = true;
  private currentFloorY = 0;

  // Camera Orbit & Spring
  private camDistance = 4.8;
  private camHeight = 2.4;
  private camAngleX = 0;
  private camAngleY = 0.28;

  // Input
  public input: InputState = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    run: false,
    jump: false,
    interact: false,
    virtualJoystickX: 0,
    virtualJoystickY: 0,
  };

  private callbacks: EngineCallbacks;
  public currentLevel = 1;
  public isCutscene = false;

  constructor(container: HTMLDivElement, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Scene & Horizon Fog
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xfef08a); // warm sunny Indian daylight
    this.scene.fog = new THREE.Fog(0xfef08a, 20, 50);

    // 2. Camera
    const aspect = container.clientWidth / container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(50, aspect, 0.1, 80);
    this.camera.position.set(0, 3, 14);

    // 3. Renderer with Three.js r160+ directives
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. RoomEnvironment reflection map
    const pmremGen = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGen.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGen.dispose();

    // 5. Studio Lighting Rig (Warm Key + Cool Fill)
    const sunLight = new THREE.DirectionalLight(0xffedd5, 1.6);
    sunLight.position.set(12, 22, 10);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 45;
    const d = 20;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0004;
    sunLight.shadow.normalBias = 0.02;
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(0xfff7ed, 0x93c5fd, 0.85);
    this.scene.add(hemiLight);

    // 6. Build House World
    const houseWorld = buildIndianFamilyHouse();
    this.scene.add(houseWorld.group);
    this.colliders = houseWorld.colliders;

    // 7. Instantiate Characters
    this.ayush = createAyushCharacter();
    this.ayush.group.position.copy(this.playerPos);
    this.scene.add(this.ayush.group);

    this.arav = createAravCharacter();
    this.akshhara = createAkshharaCharacter();
    this.ripin = createRipinCharacter();
    this.anjeeta = createAnjeetaCharacter();

    this.scene.add(this.arav.group);
    this.scene.add(this.akshhara.group);
    this.scene.add(this.ripin.group);
    this.scene.add(this.anjeeta.group);

    // 8. Items & Collectibles Manager
    this.itemsManager = new ItemsManager(this.scene);

    // 9. Position Characters according to Level 1
    this.setLevel(1);

    // Pre-warm renderer
    this.renderer.compile(this.scene, this.camera);

    // 10. Start Animation Loop
    this.bindEvents();
    this.animate();
  }

  // Setup character locations and mission items per level
  public setLevel(level: number) {
    this.currentLevel = level;
    this.itemsManager.spawnMissionItems(level);

    switch (level) {
      case 1:
        // Living room: Arav & Akshhara arguing in front of TV, Papa in study, Mom in kitchen
        this.arav.group.position.set(-1.4, 0, 6.5);
        this.arav.group.rotation.y = Math.PI * 0.25;

        this.akshhara.group.position.set(1.4, 0, 6.5);
        this.akshhara.group.rotation.y = -Math.PI * 0.25;

        this.ripin.group.position.set(10.5, 0, 13.5);
        this.ripin.group.rotation.y = -Math.PI * 0.5;

        this.anjeeta.group.position.set(-10, 0, 13.5);
        this.anjeeta.group.rotation.y = Math.PI * 0.5;
        break;

      case 2:
        // Kitchen Trouble: Mom in kitchen, Kids watching or helping
        this.anjeeta.group.position.set(-11, 0, 12.5);
        this.anjeeta.group.rotation.y = 0;

        this.arav.group.position.set(-9, 0, 8);
        this.arav.group.rotation.y = Math.PI;

        this.akshhara.group.position.set(2, 0, 8);
        this.akshhara.group.rotation.y = -Math.PI * 0.4;

        this.ripin.group.position.set(11, 0, 14);
        this.ripin.group.rotation.y = -Math.PI * 0.5;
        break;

      case 3:
        // Dad's Challenge: Dad in center living room inspecting, Mom at dining
        this.ripin.group.position.set(0, 0, 6.5);
        this.ripin.group.rotation.y = 0;

        this.anjeeta.group.position.set(-11, 0, 7.5);
        this.anjeeta.group.rotation.y = Math.PI * 0.5;

        this.arav.group.position.set(10, 0, 6);
        this.arav.group.rotation.y = 0;

        this.akshhara.group.position.set(6, 0, -6);
        this.akshhara.group.rotation.y = Math.PI;
        break;

      case 4:
        // Sibling Argument: Courtyard garden face-off near the Jhoola swing
        this.arav.group.position.set(4.8, 0, -8);
        this.arav.group.rotation.y = -Math.PI * 0.4;

        this.akshhara.group.position.set(7.2, 0, -8);
        this.akshhara.group.rotation.y = Math.PI * 0.4;

        this.ripin.group.position.set(2, 0, -5);
        this.ripin.group.rotation.y = -Math.PI * 0.2;

        this.anjeeta.group.position.set(0, 0, -5);
        this.anjeeta.group.rotation.y = 0;
        break;

      case 5:
        // Grand Family Treasure Hunt: Whole family gathering on the Rooftop Terrace!
        this.ripin.group.position.set(-2, 3.8, 10);
        this.ripin.group.rotation.y = 0;

        this.anjeeta.group.position.set(1, 3.8, 10);
        this.anjeeta.group.rotation.y = 0;

        this.arav.group.position.set(-4, 3.8, 11);
        this.arav.group.rotation.y = 0.3;

        this.akshhara.group.position.set(3, 3.8, 11);
        this.akshhara.group.rotation.y = -0.3;
        break;
    }
  }

  // Respawn or move Ayush to specific room
  public teleportPlayer(x: number, y: number, z: number) {
    this.playerPos.set(x, y, z);
    this.ayush.group.position.set(x, y, z);
    this.playerVelocityY = 0;
  }

  // Main Event Listeners
  private onKeyDown = (e: KeyboardEvent) => {
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.input.forward = true;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.input.backward = true;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.input.left = true;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.input.right = true;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.input.run = true;
        break;
      case 'Space':
        if (this.isGrounded) {
          this.input.jump = true;
          this.playerVelocityY = 7.5;
          this.isGrounded = false;
          soundEngine.playJump();
        }
        break;
      case 'KeyE':
      case 'Enter':
        this.input.interact = true;
        this.triggerInteraction();
        break;
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.input.forward = false;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.input.backward = false;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.input.left = false;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.input.right = false;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.input.run = false;
        break;
      case 'Space':
        this.input.jump = false;
        break;
      case 'KeyE':
      case 'Enter':
        this.input.interact = false;
        break;
    }
  };

  private onPointerDownX = 0;
  private isPointerDown = false;

  private onPointerDown = (e: PointerEvent) => {
    if (e.button === 0) {
      this.isPointerDown = true;
      this.onPointerDownX = e.clientX;
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (this.isPointerDown) {
      const deltaX = e.clientX - this.onPointerDownX;
      this.camAngleX -= deltaX * 0.005;
      this.onPointerDownX = e.clientX;
    }
  };

  private onPointerUp = () => {
    this.isPointerDown = false;
  };

  private onResize = () => {
    if (!this.container || this.isDestroyed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    this.container.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
  }

  // Trigger Action button (from keyboard E or virtual button)
  public triggerInteraction() {
    const near = this.getNearestInteractable();
    if (near) {
      if (near.type === 'item') {
        const item = this.itemsManager.items.find((i) => i.id === near.id);
        if (item && !item.collected) {
          item.collected = true;
          if (item.type === 'coin') {
            soundEngine.playCoin();
            this.callbacks.onCollectCoin(1);
          } else if (item.type === 'star') {
            soundEngine.playStar();
            this.callbacks.onCollectStar(1);
          } else if (item.type === 'mission') {
            soundEngine.playStar();
            this.callbacks.onCollectMissionItem(item.id, item.name);
          }
        }
      }
    }
  }

  // Find nearest interactive character or item
  public getNearestInteractable(): {
    id: string;
    name: string;
    type: 'character' | 'item';
    characterId?: CharacterId;
  } | null {
    // 1. Check family members
    const chars: { id: CharacterId; name: string; pos: THREE.Vector3 }[] = [
      { id: 'arav', name: 'Arav', pos: this.arav.group.position },
      { id: 'akshhara', name: 'Akshhara', pos: this.akshhara.group.position },
      { id: 'ripin', name: 'Mr. Ripin (Papa)', pos: this.ripin.group.position },
      { id: 'anjeeta', name: 'Mrs. Anjeeta (Mummy)', pos: this.anjeeta.group.position },
    ];

    for (const c of chars) {
      const dist = this.playerPos.distanceTo(c.pos);
      if (dist < 2.4) {
        return {
          id: c.id,
          name: c.name,
          type: 'character',
          characterId: c.id,
        };
      }
    }

    // 2. Check mission items
    for (const item of this.itemsManager.items) {
      if (!item.collected && item.type === 'mission') {
        const dist = this.playerPos.distanceTo(item.group.position);
        if (dist < item.radius + 0.5) {
          return {
            id: item.id,
            name: item.name,
            type: 'item',
          };
        }
      }
    }

    return null;
  }

  // Check collision against house box colliders
  private checkCollision(newPos: THREE.Vector3, playerRadius = 0.35): boolean {
    const minX = newPos.x - playerRadius;
    const maxX = newPos.x + playerRadius;
    const minZ = newPos.z - playerRadius;
    const maxZ = newPos.z + playerRadius;
    const playerFeet = newPos.y;
    const playerHead = newPos.y + 1.4;

    for (const c of this.colliders) {
      // Overlap test
      if (
        maxX > c.min.x &&
        minX < c.max.x &&
        maxZ > c.min.z &&
        minZ < c.max.z &&
        playerHead > c.min.y &&
        playerFeet < c.max.y - 0.15 // step height tolerance
      ) {
        return true;
      }
    }
    return false;
  }

  // Find floor height underneath player
  private getFloorHeightAt(x: number, z: number): number {
    let highestFloor = 0;

    for (const c of this.colliders) {
      if (x >= c.min.x && x <= c.max.x && z >= c.min.z && z <= c.max.z) {
        // If it's a climbable surface (step, sofa, roof) below player's current elevation + step buffer
        if (c.max.y <= this.playerPos.y + 0.55 && c.max.y > highestFloor) {
          highestFloor = c.max.y;
        }
      }
    }
    return highestFloor;
  }

  // Main 60fps Animation Loop
  private animate = () => {
    if (this.isDestroyed) return;
    this.animFrameId = requestAnimationFrame(this.animate);

    const rawDt = this.clock.getDelta();
    const dt = Math.min(rawDt, 0.05); // clamped dt
    const time = this.clock.getElapsedTime();

    // 1. Process Player Input & Movement
    let moveX = 0;
    let moveZ = 0;

    if (this.input.forward) moveZ -= 1;
    if (this.input.backward) moveZ += 1;
    if (this.input.left) moveX -= 1;
    if (this.input.right) moveX += 1;

    // Merge virtual touch joystick input
    if (Math.abs(this.input.virtualJoystickX) > 0.1 || Math.abs(this.input.virtualJoystickY) > 0.1) {
      moveX += this.input.virtualJoystickX;
      moveZ += this.input.virtualJoystickY;
    }

    const isMoving = Math.abs(moveX) > 0.05 || Math.abs(moveZ) > 0.05;
    const isRunning = this.input.run && isMoving;
    const moveSpeed = isRunning ? 7.2 : 4.5;

    if (isMoving && !this.isCutscene) {
      // Transform relative to camera angle
      _playerMoveVec.set(moveX, 0, moveZ).normalize();
      _playerMoveVec.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.camAngleX);

      const targetRot = Math.atan2(_playerMoveVec.x, _playerMoveVec.z);
      // Smooth rotation interpolation
      this.playerRotationY = THREE.MathUtils.damp(this.playerRotationY, targetRot, 14, dt);

      // Attempt movement with wall collisions
      const dx = _playerMoveVec.x * moveSpeed * dt;
      const dz = _playerMoveVec.z * moveSpeed * dt;

      // X axis collision test
      _tempVecA.copy(this.playerPos).add(new THREE.Vector3(dx, 0, 0));
      if (!this.checkCollision(_tempVecA)) {
        this.playerPos.x += dx;
      }

      // Z axis collision test
      _tempVecB.copy(this.playerPos).add(new THREE.Vector3(0, 0, dz));
      if (!this.checkCollision(_tempVecB)) {
        this.playerPos.z += dz;
      }

      // Footstep sound periodically
      if (Math.floor(time * (isRunning ? 9 : 6)) % 2 === 0) {
        soundEngine.playStep();
      }
    }

    // 2. Vertical Physics (Gravity & Floor height)
    this.currentFloorY = this.getFloorHeightAt(this.playerPos.x, this.playerPos.z);

    if (!this.isGrounded) {
      this.playerVelocityY -= 20 * dt; // gravity
      this.playerPos.y += this.playerVelocityY * dt;

      if (this.playerPos.y <= this.currentFloorY) {
        this.playerPos.y = this.currentFloorY;
        this.playerVelocityY = 0;
        this.isGrounded = true;
      }
    } else {
      // Stay glued to ground / climb steps smoothly
      this.playerPos.y = THREE.MathUtils.damp(this.playerPos.y, this.currentFloorY, 16, dt);
    }

    // Update Ayush Model Position & Rotation
    this.ayush.group.position.copy(this.playerPos);
    this.ayush.group.rotation.y = this.playerRotationY;
    this.ayush.update(time, isMoving, isRunning, !this.isGrounded);

    // 3. Update NPC Animations
    this.arav.update(time, false, false, false);
    if (this.currentLevel === 1 || this.currentLevel === 4) {
      this.arav.playArgueAnimation?.(time);
    }

    this.akshhara.update(time, false, false, false);
    if (this.currentLevel === 1 || this.currentLevel === 4) {
      this.akshhara.playArgueAnimation?.(time);
    }

    this.ripin.update(time, false, false, false);
    this.anjeeta.update(time, false, false, false);

    // 4. Update Collectibles & Beacons
    this.itemsManager.update(time);

    // Auto-collect nearby coins and stars when Ayush walks over them
    for (const item of this.itemsManager.items) {
      if (!item.collected && (item.type === 'coin' || item.type === 'star')) {
        const dist = this.playerPos.distanceTo(item.group.position);
        if (dist < item.radius) {
          item.collected = true;
          if (item.type === 'coin') {
            soundEngine.playCoin();
            this.callbacks.onCollectCoin(1);
          } else if (item.type === 'star') {
            soundEngine.playStar();
            this.callbacks.onCollectStar(1);
          }
        }
      }
    }

    // Check nearest interactive target for HUD prompt
    const nearest = this.getNearestInteractable();
    this.callbacks.onNearInteractable(nearest);

    // 5. Smooth Camera Tracking with Damping
    const camOffsetZ = Math.cos(this.camAngleX) * this.camDistance;
    const camOffsetX = Math.sin(this.camAngleX) * this.camDistance;

    _desiredCamPos.set(
      this.playerPos.x + camOffsetX,
      this.playerPos.y + this.camHeight + this.camAngleY * 2,
      this.playerPos.z + camOffsetZ
    );

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _desiredCamPos.x, 8, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _desiredCamPos.y, 8, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _desiredCamPos.z, 8, dt);

    _camLookAt.set(this.playerPos.x, this.playerPos.y + 1.1, this.playerPos.z);
    this.camera.lookAt(_camLookAt);

    // 6. Render
    this.renderer.render(this.scene, this.camera);
  };

  // Clean disposal
  public dispose() {
    this.isDestroyed = true;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    this.container.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);

    this.renderer.dispose();
    if (this.container.contains(this.renderer.domElement)) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
