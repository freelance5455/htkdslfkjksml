import { playCollect, playStep, playWin } from "@/game/audio";
import {
  CELL,
  COLS,
  PLAYER_R,
  ROWS,
  WALL_T,
  basis,
  cellOf,
  circleHits,
  generateMaze,
  resolveCircle,
  type Cell,
  type V2,
  type WorldData,
} from "@/game/maze";

export type Phase = "menu" | "play" | "pause" | "won";

export type Particle = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  color: number;
};

export type Snap = {
  version: number;
  phase: Phase;
  seed: number;
  collected: number;
  total: number;
  timeMs: number;
  bestMs: number | null;
  isNewBest: boolean;
  exploreGen: number;
  muted: boolean;
};

const BEST_KEY = "lantern-grove-best-ms";
const STEP = 1 / 60;
const WALK = 4.35;
const SPRINT = 6.7;
const RESP = 16;

export type ControlsProbe = {
  getYaw: () => number;
  getSpeed: () => number;
  getPos: () => { x: number; z: number };
  setKeys: (codes: string[]) => void;
  setSteer?: (v: number) => void;
  setYaw?: (yaw: number) => void;
  placeAt: (x: number, z: number) => void;
  getPhase: () => Phase;
  getCollected: () => number;
  getExit: () => V2;
  getGems: () => V2[];
  insideWall: () => boolean;
};

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
  }
}

type Session = WorldData & {
  phase: Phase;
  seed: number;
  x: number;
  z: number;
  yaw: number;
  pitch: number;
  vx: number;
  vz: number;
  got: boolean[];
  collected: number;
  explored: Uint8Array;
  exploreGen: number;
  timeMs: number;
  bestMs: number | null;
  isNewBest: boolean;
  bob: number;
  bobPhase: number;
  stepMark: number;
  trauma: number;
  muted: boolean;
  touch: boolean;
  reduce: boolean;
  touchForward: number;
  touchStrafe: number;
  touchSprint: boolean;
  realKeys: Set<string>;
  forced: string[] | null;
  canvas: HTMLCanvasElement | null;
  hadLock: boolean;
  particles: Particle[];
  version: number;
  acc: number;
};

function readBest(): number | null {
  try {
    const raw = localStorage.getItem(BEST_KEY);
    if (!raw) return null;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
}

function writeBest(ms: number) {
  try {
    localStorage.setItem(BEST_KEY, String(Math.round(ms)));
  } catch {
    /* private mode */
  }
}

export const session = {
  phase: "menu",
  realKeys: new Set<string>(),
  forced: null,
  particles: [] as Particle[],
  got: [] as boolean[],
  explored: new Uint8Array(COLS * ROWS),
} as Session;

let snap: Snap = {
  version: 0,
  phase: "menu",
  seed: 0,
  collected: 0,
  total: 0,
  timeMs: 0,
  bestMs: null,
  isNewBest: false,
  exploreGen: 0,
  muted: false,
};

const listeners = new Set<() => void>();

let queued = false;
function publish() {
  session.version += 1;
  snap = {
    version: session.version,
    phase: session.phase,
    seed: session.seed,
    collected: session.collected,
    total: session.gems.length,
    timeMs: session.timeMs,
    bestMs: session.bestMs,
    isNewBest: session.isNewBest,
    exploreGen: session.exploreGen,
    muted: session.muted,
  };
  if (queued) return;
  queued = true;
  queueMicrotask(() => {
    queued = false;
    for (const fn of listeners) fn();
  });
}

export function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function getSnap() {
  return snap;
}

export function randomSeed() {
  return (Math.random() * 0x7fffffff) | 0;
}

function reveal(c: number, r: number) {
  if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return false;
  const i = r * COLS + c;
  if (session.explored[i]) return false;
  session.explored[i] = 1;
  return true;
}

function revealVisible(c: number, r: number) {
  let changed = reveal(c, r);
  if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return changed;
  const cell = session.cells[r * COLS + c];
  if (!cell) return changed;
  if (!cell.n) changed = reveal(c, r - 1) || changed;
  if (!cell.s) changed = reveal(c, r + 1) || changed;
  if (!cell.w) changed = reveal(c - 1, r) || changed;
  if (!cell.e) changed = reveal(c + 1, r) || changed;
  return changed;
}

export function loadRun(seed: number) {
  const world = generateMaze(seed);
  session.seed = seed;
  session.cells = world.cells;
  session.walls = world.walls;
  session.gems = world.gems;
  session.flowers = world.flowers;
  session.trees = world.trees;
  session.flies = world.flies;
  session.startX = world.startX;
  session.startZ = world.startZ;
  session.exitX = world.exitX;
  session.exitZ = world.exitZ;
  session.exitC = world.exitC;
  session.exitR = world.exitR;
  session.x = world.startX;
  session.z = world.startZ;
  session.yaw = world.yaw;
  session.pitch = -0.06;
  session.vx = 0;
  session.vz = 0;
  session.got = world.gems.map(() => false);
  session.collected = 0;
  session.explored = new Uint8Array(COLS * ROWS);
  session.exploreGen = 0;
  session.timeMs = 0;
  session.bestMs = readBest();
  session.isNewBest = false;
  session.bob = 0;
  session.bobPhase = 0;
  session.stepMark = 0;
  session.trauma = 0;
  session.particles = [];
  session.realKeys.clear();
  session.forced = null;
  session.touchForward = 0;
  session.touchStrafe = 0;
  session.touchSprint = false;
  session.phase = "menu";
  session.acc = 0;
  const sc = cellOf(world.startX, world.startZ);
  revealVisible(sc.c, sc.r);
  session.exploreGen += 1;
}

export function spawnBurst(x: number, z: number, count = 12) {
  if (session.reduce) return;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    const sp = 1.3 + Math.random() * 1.5;
    session.particles.push({
      x,
      y: 0.85,
      z,
      vx: Math.cos(a) * sp,
      vy: 1.6 + Math.random() * 1.8,
      vz: Math.sin(a) * sp,
      life: 0.5 + Math.random() * 0.25,
      max: 0.75,
      color: i % 2 === 0 ? 0xe36b4a : 0xe39b2b,
    });
  }
  if (session.particles.length > 72) {
    session.particles.splice(0, session.particles.length - 72);
  }
}

export function tickParticles(dt: number) {
  const list = session.particles;
  for (let i = list.length - 1; i >= 0; i--) {
    const p = list[i]!;
    p.life -= dt;
    if (p.life <= 0) {
      list.splice(i, 1);
      continue;
    }
    p.vy -= 7.2 * dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;
  }
}

function isDown(code: string) {
  if (session.realKeys.has(code)) return true;
  return session.forced?.includes(code) ?? false;
}

function win() {
  if (session.phase !== "play") return;
  session.phase = "won";
  session.vx = 0;
  session.vz = 0;
  const best = readBest();
  if (best == null || session.timeMs < best) {
    session.isNewBest = true;
    session.bestMs = session.timeMs;
    writeBest(session.timeMs);
  } else {
    session.isNewBest = false;
    session.bestMs = best;
  }
  session.trauma = Math.min(1, session.trauma + 0.85);
  spawnBurst(session.exitX, session.exitZ, 22);
  playWin();
  document.exitPointerLock?.();
  publish();
}

export function simStep(dt: number) {
  if (session.phase !== "play") return;

  let f = 0;
  let s = 0;
  if (isDown("KeyW") || isDown("ArrowUp")) f += 1;
  if (isDown("KeyS") || isDown("ArrowDown")) f -= 1;
  if (isDown("KeyD") || isDown("ArrowRight")) s += 1;
  if (isDown("KeyA") || isDown("ArrowLeft")) s -= 1;
  f += session.touchForward;
  s += session.touchStrafe;
  const len = Math.hypot(f, s);
  if (len > 1) {
    f /= len;
    s /= len;
  }

  const { fx, fz, rx, rz } = basis(session.yaw);
  const wishX = fx * f + rx * s;
  const wishZ = fz * f + rz * s;
  const sprint = isDown("ShiftLeft") || isDown("ShiftRight") || session.touchSprint;
  const speed = sprint ? SPRINT : WALK;
  const k = 1 - Math.exp(-RESP * dt);
  session.vx += (wishX * speed - session.vx) * k;
  session.vz += (wishZ * speed - session.vz) * k;

  const attemptX = session.vx * dt;
  const attemptZ = session.vz * dt;
  const resolved = resolveCircle(session.x + attemptX, session.z + attemptZ, PLAYER_R, session.walls);
  const movedX = resolved.x - session.x;
  const movedZ = resolved.z - session.z;
  if (Math.abs(attemptX) > 1e-5 && Math.abs(movedX) < Math.abs(attemptX) * 0.35) session.vx = 0;
  if (Math.abs(attemptZ) > 1e-5 && Math.abs(movedZ) < Math.abs(attemptZ) * 0.35) session.vz = 0;

  const inner = WALL_T / 2 + PLAYER_R + 0.01;
  const maxX = COLS * CELL - inner;
  const maxZ = ROWS * CELL - inner;
  session.x = Math.min(maxX, Math.max(inner, resolved.x));
  session.z = Math.min(maxZ, Math.max(inner, resolved.z));

  const sp = Math.hypot(session.vx, session.vz);
  if (!session.reduce && sp > 0.45) session.bobPhase += sp * dt * 2.35;
  const targetBob = !session.reduce && sp > 0.45 ? Math.sin(session.bobPhase) * 0.042 : 0;
  session.bob += (targetBob - session.bob) * (1 - Math.exp(-10 * dt));
  if (sp > 1.15 && !session.reduce) {
    const mark = Math.floor(session.bobPhase / Math.PI);
    if (mark !== session.stepMark) {
      session.stepMark = mark;
      playStep();
    }
  }

  const here = cellOf(session.x, session.z);
  if (revealVisible(here.c, here.r)) {
    session.exploreGen += 1;
    publish();
  }

  let picked = false;
  for (let i = 0; i < session.gems.length; i++) {
    if (session.got[i]) continue;
    const g = session.gems[i]!;
    const dx = g.x - session.x;
    const dz = g.z - session.z;
    if (dx * dx + dz * dz > 0.78 * 0.78) continue;
    session.got[i] = true;
    session.collected += 1;
    session.trauma = Math.min(1, session.trauma + 0.38);
    spawnBurst(g.x, g.z, 14);
    playCollect();
    picked = true;
  }
  if (picked) publish();

  const ex = session.exitX - session.x;
  const ez = session.exitZ - session.z;
  if (ex * ex + ez * ez < 1.05 * 1.05) win();

  session.timeMs += dt * 1000;
  if (session.trauma > 0) session.trauma = Math.max(0, session.trauma - dt * 1.7);
}

export function frameSim(delta: number) {
  const dt = Math.min(delta, 0.1);
  tickParticles(dt);
  if (session.phase !== "play") {
    session.acc = 0;
    return;
  }
  session.acc += dt;
  let guard = 0;
  while (session.acc >= STEP && guard < 5) {
    simStep(STEP);
    session.acc -= STEP;
    guard += 1;
  }
}

export function clampPitch() {
  const limit = Math.PI / 2 - 0.08;
  if (session.pitch > limit) session.pitch = limit;
  if (session.pitch < -limit) session.pitch = -limit;
}

export function nudgeLook(dx: number, dy: number, sens: number) {
  session.yaw -= dx * sens;
  session.pitch -= dy * sens;
  clampPitch();
}

export function toggleMute() {
  session.muted = !session.muted;
  publish();
}

export function startFromMenu() {
  if (session.phase !== "menu") return;
  session.phase = "play";
  session.hadLock = false;
  session.timeMs = 0;
  publish();
}

export function resumePlay() {
  if (session.phase !== "pause") return;
  session.phase = "play";
  publish();
}

export function pausePlay() {
  if (session.phase !== "play") return;
  session.phase = "pause";
  session.vx = 0;
  session.vz = 0;
  session.touchForward = 0;
  session.touchStrafe = 0;
  session.touchSprint = false;
  publish();
}

export function playAgain() {
  loadRun(randomSeed());
  session.phase = "play";
  session.hadLock = false;
  publish();
}

export function lockLook() {
  const canvas = session.canvas;
  if (!canvas || session.touch || navigator.webdriver) return;
  const el = canvas as HTMLElement & {
    requestPointerLock?: (opts?: { unadjustedMovement?: boolean }) => void | Promise<void>;
  };
  try {
    const pending = el.requestPointerLock?.({ unadjustedMovement: true });
    void Promise.resolve(pending).catch(() => {
      try {
        canvas.requestPointerLock();
      } catch {
        /* already unlocked */
      }
    });
  } catch {
    try {
      canvas.requestPointerLock();
    } catch {
      /* ignore */
    }
  }
}

function onKeyDown(e: KeyboardEvent) {
  session.realKeys.add(e.code);
  if (e.code.startsWith("Arrow")) e.preventDefault();
  if (e.code === "Escape") pausePlay();
  if (e.code === "KeyM") toggleMute();
}

function onKeyUp(e: KeyboardEvent) {
  session.realKeys.delete(e.code);
}

function onMouse(e: MouseEvent) {
  if (navigator.webdriver) return;
  if (session.phase !== "play") return;
  if (document.pointerLockElement !== session.canvas) return;
  nudgeLook(e.movementX, e.movementY, 0.00215);
}

function onLockChange() {
  const locked = document.pointerLockElement === session.canvas;
  if (locked) session.hadLock = true;
  else if (session.hadLock && session.phase === "play") pausePlay();
}

function onBlur() {
  session.realKeys.clear();
  session.touchForward = 0;
  session.touchStrafe = 0;
  session.touchSprint = false;
}

function onVis() {
  if (document.hidden) pausePlay();
}

export function attachInput() {
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("mousemove", onMouse);
  window.addEventListener("blur", onBlur);
  document.addEventListener("pointerlockchange", onLockChange);
  document.addEventListener("visibilitychange", onVis);
}

export function detachInput() {
  window.removeEventListener("keydown", onKeyDown);
  window.removeEventListener("keyup", onKeyUp);
  window.removeEventListener("mousemove", onMouse);
  window.removeEventListener("blur", onBlur);
  document.removeEventListener("pointerlockchange", onLockChange);
  document.removeEventListener("visibilitychange", onVis);
}

export function attachProbe() {
  window.__controlsTest = {
    getYaw: () => session.yaw,
    getSpeed: () => Math.hypot(session.vx, session.vz),
    getPos: () => ({ x: session.x, z: session.z }),
    setKeys: (codes: string[]) => {
      session.forced = codes;
    },
    // FPS strafe, not vehicle steer. A/D move on `right`, they do not yaw.
    setSteer: () => {},
    setYaw: (yaw: number) => {
      session.yaw = yaw;
    },
    placeAt: (x: number, z: number) => {
      const p = resolveCircle(x, z, PLAYER_R, session.walls);
      session.x = p.x;
      session.z = p.z;
      session.vx = 0;
      session.vz = 0;
    },
    getPhase: () => session.phase,
    getCollected: () => session.collected,
    getExit: () => ({ x: session.exitX, z: session.exitZ }),
    getGems: () => session.gems.filter((_, i) => !session.got[i]),
    insideWall: () => solidHere(),
  };
}

loadRun(randomSeed());
publish();

export function solidHere() {
  return circleHits(session.x, session.z, PLAYER_R * 0.96, session.walls);
}

export function formatTime(ms: number) {
  const clamped = Math.max(0, ms);
  const total = Math.floor(clamped / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  const tenth = Math.floor((clamped % 1000) / 100);
  return `${m}:${s.toString().padStart(2, "0")}.${tenth}`;
}

export function groveCode(seed: number) {
  return seed.toString(36).toUpperCase().padStart(4, "0");
}

export type { Cell };
