import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { memo, useMemo, useRef } from "react";
import { createCar, type CarRig } from "./CarModel";
import {
  makeBuildingTexture,
  makeGlowTexture,
  makeGroundTexture,
  makeRoadTexture,
  makeShadowTexture,
  makeSkyTexture,
} from "./textures";
import { input } from "./input";
import { blip, crashSound, stopEngine, updateEngine } from "./audio";
import { saveBest, setState, showToast } from "./store";
import { clamp, LANES, PLAY_LIMIT, ROAD_HALF, ROAD_LENGTH, world } from "./world";

type Kind = "car" | "cone" | "barrier";

interface Obstacle {
  group: THREE.Group;
  rig?: CarRig;
  kind: Kind;
  lane: number;
  x: number;
  z: number;
  /** 1 = same direction, -1 = oncoming, 0 = static */
  dir: 1 | -1 | 0;
  spd: number;
  active: boolean;
  passed: boolean;
  halfW: number;
  halfL: number;
}

interface Pickup {
  group: THREE.Group;
  lane: number;
  x: number;
  z: number;
  taken: boolean;
}

interface SceneryItem {
  obj: THREE.Object3D;
  z: number;
  span: number;
}

const CAR_COLORS = [
  "#3b82f6",
  "#eab308",
  "#22c55e",
  "#a855f7",
  "#f1f5f9",
  "#ef4444",
  "#14b8a6",
];

function makeCone(): THREE.Group {
  const group = new THREE.Group();
  const orange = new THREE.MeshStandardMaterial({
    color: "#ff6b35",
    roughness: 0.6,
    emissive: new THREE.Color("#5a1c00"),
    emissiveIntensity: 0.6,
  });
  const white = new THREE.MeshStandardMaterial({ color: "#f4f7ff", roughness: 0.5 });
  const dark = new THREE.MeshStandardMaterial({ color: "#15161c", roughness: 0.9 });

  const cone = new THREE.Mesh(new THREE.ConeGeometry(0.4, 1, 16), orange);
  cone.position.y = 0.5;
  group.add(cone);

  const band = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.3, 0.18, 16), white);
  band.position.y = 0.52;
  group.add(band);

  const base = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.08, 0.85), dark);
  base.position.y = 0.04;
  group.add(base);

  return group;
}

function makeBarrier(): THREE.Group {
  const group = new THREE.Group();
  const white = new THREE.MeshStandardMaterial({ color: "#e8eefc", roughness: 0.55 });
  const red = new THREE.MeshStandardMaterial({
    color: "#ff2b3f",
    roughness: 0.5,
    emissive: new THREE.Color("#ff1020"),
    emissiveIntensity: 0.5,
  });

  const bar = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.55, 0.28), white);
  bar.position.y = 0.8;
  group.add(bar);

  for (let i = 0; i < 5; i++) {
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.57, 0.32), red);
    stripe.position.set(-1.05 + i * 0.52, 0.8, 0);
    group.add(stripe);
  }

  for (const sx of [-1.1, 1.1]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.95, 0.16), white);
    leg.position.set(sx, 0.45, 0);
    group.add(leg);
  }

  const glow = new THREE.Mesh(
    new THREE.BoxGeometry(2.8, 0.08, 0.3),
    new THREE.MeshBasicMaterial({ color: "#ff3355" }),
  );
  glow.position.y = 1.09;
  group.add(glow);

  return group;
}

function GameScene() {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;

  const roadTex = useMemo(() => makeRoadTexture(), []);
  const groundTex = useMemo(() => makeGroundTexture(), []);
  const skyTex = useMemo(() => makeSkyTexture(), []);
  const glowTex = useMemo(() => makeGlowTexture("rgba(255,255,255,1)"), []);
  const shadowTex = useMemo(() => makeShadowTexture(), []);
  const buildingTex = useMemo(() => makeBuildingTexture(), []);

  const player = useMemo(
    () =>
      createCar({
        color: "#ff7a18",
        hero: true,
        glowTexture: glowTex,
        shadowTexture: shadowTex,
      }),
    [glowTex, shadowTex],
  );

  /* ------------------------------------------------------------------ */
  /* pools                                                              */
  /* ------------------------------------------------------------------ */

  const cars = useMemo(() => {
    const list: Obstacle[] = [];
    const colors = [...CAR_COLORS];
    for (let lane = 0; lane < 3; lane++) {
      for (let i = 0; i < 5; i++) {
        const rig = createCar({ color: colors[(lane * 5 + i) % colors.length] });
        const oncoming = Math.random() < 0.3;
        list.push({
          group: rig.group,
          rig,
          kind: "car",
          lane,
          x: LANES[lane] + (Math.random() - 0.5) * 0.7,
          z: -62 - i * 50 - Math.random() * 14,
          dir: oncoming ? -1 : 1,
          spd: oncoming ? 26 + Math.random() * 14 : 10 + Math.random() * 16,
          active: true,
          passed: false,
          halfW: 1.1,
          halfL: 2.3,
        });
      }
    }
    return list;
  }, []);

  const cones = useMemo(() => {
    const list: Obstacle[] = [];
    for (let i = 0; i < 7; i++) {
      list.push({
        group: makeCone(),
        kind: "cone",
        lane: i % 3,
        x: LANES[i % 3] + (Math.random() - 0.5) * 1.6,
        z: -40 - i * 52 - Math.random() * 20,
        dir: 0,
        spd: 0,
        active: true,
        passed: false,
        halfW: 0.5,
        halfL: 0.5,
      });
    }
    return list;
  }, []);

  const barriers = useMemo(() => {
    const list: Obstacle[] = [];
    for (let i = 0; i < 4; i++) {
      list.push({
        group: makeBarrier(),
        kind: "barrier",
        lane: i % 3,
        x: LANES[i % 3],
        z: -70 - i * 90 - Math.random() * 30,
        dir: 0,
        spd: 0,
        active: true,
        passed: false,
        halfW: 1.5,
        halfL: 0.4,
      });
    }
    return list;
  }, []);

  const pickups = useMemo(() => {
    const list: Pickup[] = [];
    for (let i = 0; i < 9; i++) {
      const group = new THREE.Group();
      const core = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.55),
        new THREE.MeshStandardMaterial({
          color: "#5ef2ff",
          emissive: new THREE.Color("#22e6ff"),
          emissiveIntensity: 2.4,
          roughness: 0.2,
          metalness: 0.3,
        }),
      );
      group.add(core);
      const halo = new THREE.Mesh(
        new THREE.PlaneGeometry(3.2, 3.2),
        new THREE.MeshBasicMaterial({
          map: glowTex,
          transparent: true,
          opacity: 0.6,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          color: "#39e7ff",
        }),
      );
      halo.rotation.x = -Math.PI / 2;
      halo.position.y = -0.4;
      group.add(halo);
      const lane = i % 3;
      list.push({
        group,
        lane,
        x: LANES[lane],
        z: -30 - i * 42 - Math.random() * 18,
        taken: false,
      });
    }
    return list;
  }, [glowTex]);

  /* ------------------------------------------------------------------ */
  /* scenery                                                            */
  /* ------------------------------------------------------------------ */

  const scenery = useMemo(() => {
    const items: SceneryItem[] = [];
    const span = 340;

    const treeMat = new THREE.MeshStandardMaterial({
      color: "#0f7a4d",
      roughness: 0.9,
    });
    const trunkMat = new THREE.MeshStandardMaterial({ color: "#3a2418", roughness: 1 });
    const rockMat = new THREE.MeshStandardMaterial({ color: "#3b3d52", roughness: 1 });
    const poleMat = new THREE.MeshStandardMaterial({ color: "#20222e", roughness: 0.8 });
    const lampMat = new THREE.MeshStandardMaterial({
      color: "#fff3cf",
      emissive: new THREE.Color("#ffd88a"),
      emissiveIntensity: 3,
    });

    // trees
    for (let i = 0; i < 20; i++) {
      const g = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.24, 2, 6), trunkMat);
      trunk.position.y = 1;
      g.add(trunk);
      const crown = new THREE.Mesh(new THREE.ConeGeometry(1.5, 3.6, 7), treeMat);
      crown.position.y = 3.4;
      g.add(crown);
      const side = new THREE.Mesh(new THREE.ConeGeometry(1.05, 2.4, 7), treeMat);
      side.position.set(0.7, 2.4, 0.2);
      g.add(side);
      const side2 = side.clone();
      side2.position.set(-0.8, 2.2, -0.3);
      g.add(side2);
      const s = 0.8 + Math.random() * 0.8;
      g.scale.setScalar(s);
      const side_ = Math.random() > 0.5 ? 1 : -1;
      g.position.set(side_ * (10 + Math.random() * 16), 0, -Math.random() * span);
      items.push({ obj: g, z: g.position.z, span });
    }

    // rocks
    for (let i = 0; i < 14; i++) {
      const g = new THREE.Group();
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.8 + Math.random() * 0.7), rockMat);
      rock.position.y = 0.5;
      rock.rotation.set(Math.random(), Math.random(), Math.random());
      g.add(rock);
      const s = 0.7 + Math.random() * 1.4;
      g.scale.setScalar(s);
      const side = Math.random() > 0.5 ? 1 : -1;
      g.position.set(side * (9 + Math.random() * 22), 0, -Math.random() * span);
      items.push({ obj: g, z: g.position.z, span });
    }

    // buildings
    for (let i = 0; i < 14; i++) {
      const g = new THREE.Group();
      const h = 6 + Math.random() * 22;
      const w = 4 + Math.random() * 6;
      const b = new THREE.Mesh(
        new THREE.BoxGeometry(w, h, w),
        new THREE.MeshStandardMaterial({
          map: buildingTex,
          roughness: 0.9,
          emissive: new THREE.Color("#101a30"),
          emissiveIntensity: 0.6,
        }),
      );
      b.position.y = h / 2;
      g.add(b);
      const side = Math.random() > 0.5 ? 1 : -1;
      g.position.set(side * (22 + Math.random() * 26), 0, -Math.random() * span);
      items.push({ obj: g, z: g.position.z, span });
    }

    // street lights with light pools
    for (let i = 0; i < 16; i++) {
      const g = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 7, 8), poleMat);
      pole.position.y = 3.5;
      g.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.16, 0.16), poleMat);
      arm.position.set(-1.05, 6.9, 0);
      g.add(arm);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.22, 0.5), lampMat);
      lamp.position.set(-2, 6.75, 0);
      g.add(lamp);

      const pool = new THREE.Mesh(
        new THREE.PlaneGeometry(9, 14),
        new THREE.MeshBasicMaterial({
          map: glowTex,
          transparent: true,
          opacity: 0.32,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          color: "#ffca7a",
        }),
      );
      pool.rotation.x = -Math.PI / 2;
      pool.position.set(-2, 0.05, 0);
      g.add(pool);

      const side = i % 2 === 0 ? 1 : -1;
      g.position.set(side * 9.6, 0, -Math.random() * span);
      g.rotation.y = side > 0 ? 0 : Math.PI;
      items.push({ obj: g, z: g.position.z, span });
    }

    // guard posts
    for (let i = 0; i < 40; i++) {
      const g = new THREE.Group();
      const post = new THREE.Mesh(
        new THREE.BoxGeometry(0.16, 1.1, 0.16),
        new THREE.MeshStandardMaterial({
          color: "#8ef0ff",
          emissive: new THREE.Color("#3fd8ff"),
          emissiveIntensity: 1.4,
          roughness: 0.6,
        }),
      );
      post.position.y = 0.55;
      g.add(post);
      const side = i % 2 === 0 ? 1 : -1;
      g.position.set(side * 8.9, 0, -Math.random() * span);
      items.push({ obj: g, z: g.position.z, span });
    }

    return items;
  }, [buildingTex, glowTex]);

  /* ------------------------------------------------------------------ */
  /* particles                                                          */
  /* ------------------------------------------------------------------ */

  const particles = useMemo(() => {
    const geo = new THREE.BoxGeometry(0.3, 0.3, 0.3);
    const mat = new THREE.MeshBasicMaterial({ color: "#ffb347" });
    const list: THREE.Mesh[] = [];
    for (let i = 0; i < 30; i++) {
      const m = new THREE.Mesh(geo, mat.clone());
      m.visible = false;
      list.push(m);
    }
    return list;
  }, []);

  const particleState = useRef(
    particles.map(() => ({
      p: new THREE.Vector3(),
      v: new THREE.Vector3(),
    })),
  );

  const stars = useMemo(() => {
    const positions = new Float32Array(600 * 3);
    for (let i = 0; i < 600; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 0.85 + 0.05);
      const r = 340;
      positions[i * 3] = Math.sin(phi) * Math.cos(theta) * r;
      positions[i * 3 + 1] = Math.cos(phi) * r + 10;
      positions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * r;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return geo;
  }, []);

  const lookTarget = useRef(new THREE.Vector3(0, 1.5, -16));
  const fillLight = useRef<THREE.PointLight>(null);
  const hudTimer = useRef(0);
  const publishedPhase = useRef(world.phase);

  /* ------------------------------------------------------------------ */
  /* helpers                                                            */
  /* ------------------------------------------------------------------ */

  function laneFarthest(lane: number, except?: Obstacle) {
    let min = Infinity;
    for (const c of cars) {
      if (c === except || c.lane !== lane || !c.active) continue;
      if (c.z < min) min = c.z;
    }
    return min === Infinity ? -200 : min;
  }

  function laneFarthestPickup(lane: number, except?: Pickup) {
    let min = Infinity;
    for (const p of pickups) {
      if (p === except || p.lane !== lane) continue;
      if (p.z < min) min = p.z;
    }
    return min === Infinity ? -200 : min;
  }

  /** puts every obstacle back on its starting grid (used on restart) */
  function resetField() {
    cars.forEach((c, i) => {
      const lane = i % 3;
      c.lane = lane;
      c.x = LANES[lane];
      c.z = -62 - Math.floor(i / 3) * 52;
      c.dir = 1;
      c.spd = 14;
      c.passed = false;
      c.group.visible = true;
      c.group.position.set(c.x, 0, c.z);
    });
    cones.forEach((c, i) => {
      const lane = i % 2;
      c.lane = lane;
      c.x = LANES[lane];
      c.z = -95 - Math.floor(i / 2) * 95;
      c.passed = false;
      c.group.visible = true;
      c.group.position.set(c.x, 0, c.z);
    });
    barriers.forEach((b, i) => {
      const lane = i % 3;
      b.lane = lane;
      b.x = LANES[lane];
      b.z = -110 - i * 90;
      b.passed = false;
      b.group.visible = true;
      b.group.position.set(b.x, 0, b.z);
    });
    pickups.forEach((p, i) => {
      const lane = i % 3;
      p.lane = lane;
      p.x = LANES[lane];
      p.z = -55 - Math.floor(i / 3) * 72;
      p.taken = false;
      p.group.visible = true;
      p.group.position.set(p.x, 1.1, p.z);
    });
    particleState.current.forEach((ps, i) => {
      particles[i].visible = false;
      ps.v.set(0, 0, 0);
    });
  }

  function triggerCrash() {
    if (world.phase !== "playing") return;
    world.phase = "crashed";
    world.crashTimer = 0;
    world.shake = 1.4;
    world.boosting = false;
    player.group.visible = false;
    showToast("تصادف کردی!");
    crashSound();
    // spawn explosion
    particleState.current.forEach((ps, i) => {
      const m = particles[i];
      m.visible = true;
      ps.p.set(world.x, 0.7, 0);
      ps.v.set(
        (Math.random() - 0.5) * 14,
        Math.random() * 9 + 2,
        (Math.random() - 0.5) * 14,
      );
      (m.material as THREE.MeshBasicMaterial).color.setHSL(
        0.02 + Math.random() * 0.12,
        1,
        0.55,
      );
    });
  }

  /* ------------------------------------------------------------------ */
  /* frame loop                                                         */
  /* ------------------------------------------------------------------ */

  useFrame((_state, rawDelta) => {
    const dt = Math.min(rawDelta, 0.05);
    world.elapsed += dt;

    const w = world;

    if (w.phase === "countdown") {
      w.countdown -= dt;
      w.speed += (0 - w.speed) * Math.min(1, 3 * dt);
      if (w.countdown <= 0) {
        w.countdown = 0;
        w.phase = "playing";
        showToast("بزن بریم!");
      }
    } else if (w.phase === "playing") {
      /* ---------------- steering ---------------- */
      const steer = (input.right ? 1 : 0) - (input.left ? 1 : 0);
      w.steer = steer;
      w.vx += steer * 30 * dt;
      w.vx -= w.vx * Math.min(1, 3.6 * dt);
      w.vx = clamp(w.vx, -12, 12);
      w.x += w.vx * dt;

      const offRoad = Math.abs(w.x) > ROAD_HALF - 1.2;
      if (w.x < -PLAY_LIMIT) {
        w.x = -PLAY_LIMIT;
        w.vx = -w.vx * 0.3;
      }
      if (w.x > PLAY_LIMIT) {
        w.x = PLAY_LIMIT;
        w.vx = -w.vx * 0.3;
      }

      /* ---------------- speed ---------------- */
      const base = 27 + Math.min(28, w.distance / 120);
      let target = base;
      if (offRoad) target *= 0.72;
      w.boosting = input.boost && w.nitro > 1;
      if (w.boosting) {
        target *= 1.75;
        w.nitro = Math.max(0, w.nitro - 34 * dt);
      } else {
        w.nitro = Math.min(100, w.nitro + 7 * dt);
      }
      if (input.brake) target *= 0.5;
      if (input.accel) target *= 1.12;
      w.speed += (target - w.speed) * Math.min(1, 1.9 * dt);
      w.distance += w.speed * dt;

      /* ---------------- traffic ---------------- */
      const allObstacles: Obstacle[] = [...cars, ...cones, ...barriers];
      for (const o of allObstacles) {
        if (!o.active) continue;
        const rel =
          o.dir === 0
            ? w.speed
            : o.dir === 1
              ? w.speed - o.spd
              : w.speed + o.spd;
        o.z += rel * dt;
        o.group.position.set(o.x, 0, o.z);
        if (o.rig) {
          const spin = (o.dir === -1 ? rel : -rel) / 0.46;
          for (const wheel of o.rig.wheels) {
            wheel.rotation.x += spin * dt;
          }
          if (o.dir === -1) {
            o.group.rotation.y = Math.PI;
          } else {
            o.group.rotation.y = 0;
          }
        }

        const dx = Math.abs(o.x - w.x);
        const dz = Math.abs(o.z);

        if (dz < o.halfL + 2.1 && dx < o.halfW + 1.05) {
          if (o.kind === "cone") {
            if (!o.passed) {
              o.passed = true;
              o.group.visible = false;
              w.speed *= 0.55;
              w.shake = Math.max(w.shake, 0.6);
              showToast("به مخروط خوردید! (-سرعت)");
            }
          } else {
            triggerCrash();
            break;
          }
        }

        if (!o.passed && o.z > 0.5) {
          o.passed = true;
          if (o.kind === "car" && dx < 3.2 && dx > 1.9) {
            w.bonus += 25;
            showToast("نزدیک رد شدی! +۲۵");
          }
        }

        // recycle
        if (o.z > 34) {
          o.passed = false;
          o.group.visible = true;
          if (o.kind === "car") {
            const far = laneFarthest(o.lane, o);
            o.z = far - (30 + Math.random() * 34);
            o.x = LANES[o.lane] + (Math.random() - 0.5) * 0.7;
            const oncoming = Math.random() < 0.3;
            o.dir = oncoming ? -1 : 1;
            o.spd = oncoming ? 26 + Math.random() * 14 : 10 + Math.random() * 16;
            if (o.rig) {
              o.rig.setColor(
                CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)],
              );
            }
          } else if (o.kind === "cone") {
            o.lane = Math.floor(Math.random() * 3);
            o.x = LANES[o.lane] + (Math.random() - 0.5) * 1.6;
            o.z = -170 - Math.random() * 60;
          } else {
            o.lane = Math.floor(Math.random() * 3);
            o.x = LANES[o.lane];
            o.z = -190 - Math.random() * 60;
          }
        } else if (o.z < -330) {
          o.passed = false;
          o.group.visible = true;
          o.z = -250;
        }
      }

      /* ---------------- pickups ---------------- */
      for (const p of pickups) {
        p.z += w.speed * dt;

        if (!p.taken) {
          p.group.position.set(
            p.x,
            1.1 + Math.sin(world.elapsed * 3 + p.z) * 0.18,
            p.z,
          );
          p.group.rotation.y += dt * 2.4;
          p.group.rotation.x += dt * 1.1;
          if (Math.abs(p.x - w.x) < 1.9 && Math.abs(p.z) < 2.4) {
            p.taken = true;
            p.group.visible = false;
            w.pickups += 1;
            w.nitro = Math.min(100, w.nitro + 30);
            w.bonus += 75;
            showToast("+۷۵ امتیاز  ⚡ نیترو");
            blip(720, 0.16, "triangle", 0.14);
          }
        }

        if (p.z > 34) {
          p.taken = false;
          p.group.visible = true;
          const far = laneFarthestPickup(p.lane, p);
          p.z = far - (45 + Math.random() * 45);
          p.lane = Math.floor(Math.random() * 3);
          p.x = LANES[p.lane];
        }
      }

      w.score = Math.floor(w.distance * 0.55 + w.bonus);
    } else if (w.phase === "crashed") {
      w.crashTimer += dt;
      w.speed += (0 - w.speed) * Math.min(1, 1.8 * dt);
      if (w.crashTimer > 1.8) {
        w.phase = "gameover";
        saveBest(w.score);
        stopEngine();
      }
    } else {
      w.speed += (0 - w.speed) * Math.min(1, 3 * dt);
    }

    /* ---------------- particles ---------------- */
    particleState.current.forEach((ps, i) => {
      const m = particles[i];
      if (!m.visible) return;
      ps.v.y -= 16 * dt;
      ps.p.addScaledVector(ps.v, dt);
      m.position.copy(ps.p);
      m.rotation.x += dt * 6;
      m.rotation.y += dt * 4;
      (m.material as THREE.MeshBasicMaterial).opacity = Math.max(
        0,
        1 - w.crashTimer / 1.8,
      );
      (m.material as THREE.MeshBasicMaterial).transparent = true;
    });

    /* ---------------- world motion ---------------- */
    const scroll = w.speed * dt;
    roadTex.offset.y += (scroll * 30) / ROAD_LENGTH;
    groundTex.offset.y += (scroll * 26) / 1200;

    for (const item of scenery) {
      item.z += scroll;
      if (item.z > 40) item.z -= item.span;
      item.obj.position.z = item.z;
    }

    /* ---------------- player transform ---------------- */
    if (player.group.visible) {
      player.group.position.x = w.x;
      player.group.rotation.z = -w.vx * 0.045;
      player.group.rotation.y = -w.vx * 0.035;
      player.group.rotation.x = clamp((input.brake ? 0.03 : 0) + (input.accel ? -0.02 : 0), -0.05, 0.05);
      player.group.position.y = Math.sin(world.elapsed * 14) * 0.012;
      for (const wheel of player.wheels) {
        wheel.rotation.x -= (w.speed / 0.46) * dt;
      }
      const light = player.tailGlow.material as THREE.MeshStandardMaterial;
      light.emissiveIntensity = w.boosting ? 3.6 : 2.2;
    }

    if (w.phase === "playing" || w.phase === "countdown") {
      updateEngine(w.speed, w.boosting);
    }

    if (fillLight.current) {
      fillLight.current.position.set(w.x, 6.5, 5);
    }

    /* ---------------- camera ---------------- */
    const speedRatio = clamp(w.speed / 95, 0, 1);
    const desired = new THREE.Vector3(
      w.x * 0.45,
      4.1 + speedRatio * 0.9,
      10.4 + speedRatio * 3.2,
    );
    camera.position.lerp(desired, 1 - Math.pow(0.0015, dt));
    lookTarget.current.lerp(
      new THREE.Vector3(w.x * 0.32, 1.5, -17),
      1 - Math.pow(0.002, dt),
    );
    if (w.shake > 0) {
      w.shake = Math.max(0, w.shake - dt * 1.7);
      const s = w.shake * w.shake;
      camera.position.x += (Math.random() - 0.5) * s * 1.4;
      camera.position.y += (Math.random() - 0.5) * s * 1.1;
    }
    camera.lookAt(lookTarget.current);

    const targetFov = 60 + speedRatio * 16 + (w.boosting ? 4 : 0);
    camera.fov += (targetFov - camera.fov) * Math.min(1, 3 * dt);
    camera.updateProjectionMatrix();

    /* ---------------- HUD publishing ---------------- */
    hudTimer.current += dt;
    if (hudTimer.current > 0.06) {
      hudTimer.current = 0;
      setState({
        speed: Math.round(w.speed * 3.6),
        score: w.score,
        distance: Math.floor(w.distance),
        nitro: Math.round(w.nitro),
        pickups: w.pickups,
        boosting: w.boosting,
        countdown: Math.ceil(w.countdown),
      });
    }

    if (publishedPhase.current !== w.phase) {
      publishedPhase.current = w.phase;
      setState({ phase: w.phase });
      if (w.phase === "countdown") {
        resetField();
        player.group.visible = true;
      }
      if (w.phase === "playing") player.group.visible = true;
    }
  });

  return (
    <group>
      {/* sky */}
      <mesh>
        <sphereGeometry args={[420, 32, 20]} />
        <meshBasicMaterial map={skyTex} side={THREE.BackSide} fog={false} />
      </mesh>

      <points geometry={stars} frustumCulled={false}>
        <pointsMaterial
          size={1.7}
          sizeAttenuation={false}
          color="#dfe6ff"
          transparent
          opacity={0.85}
          fog={false}
        />
      </points>

      {/* moon */}
      <group position={[-120, 70, -300]}>
        <mesh>
          <circleGeometry args={[16, 40]} />
          <meshBasicMaterial color="#f4f1ff" fog={false} />
        </mesh>
        <mesh position={[0, 0, -1]}>
          <planeGeometry args={[90, 90]} />
          <meshBasicMaterial
            map={glowTex}
            transparent
            opacity={0.5}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
            color="#8ea8ff"
            fog={false}
          />
        </mesh>
      </group>

      {/* lights */}
      <ambientLight intensity={0.55} color="#6b7cb0" />
      <hemisphereLight args={["#5a74ff", "#1a1030", 0.9]} />
      <directionalLight
        position={[14, 26, 16]}
        intensity={1.45}
        color="#ffd9a8"
      />
      {/* soft fill light that follows the player so the car always reads well */}
      <pointLight
        ref={fillLight}
        position={[0, 6, 6]}
        intensity={30}
        distance={30}
        decay={2}
        color="#9fd0ff"
      />

      {/* ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.06, -320]}>
        <planeGeometry args={[1200, 1200]} />
        <meshStandardMaterial map={groundTex} roughness={1} metalness={0} />
      </mesh>

      {/* road */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0, -ROAD_LENGTH / 2 + 40]}
      >
        <planeGeometry args={[ROAD_HALF * 2, ROAD_LENGTH]} />
        <meshStandardMaterial
          map={roadTex}
          roughness={0.82}
          metalness={0.15}
        />
      </mesh>

      {/* neon road edges */}
      {[-1, 1].map((side) => (
        <mesh
          key={side}
          rotation={[-Math.PI / 2, 0, 0]}
          position={[side * (ROAD_HALF - 0.12), 0.03, -ROAD_LENGTH / 2 + 40]}
        >
          <planeGeometry args={[0.24, ROAD_LENGTH]} />
          <meshBasicMaterial color="#4fe3ff" transparent opacity={0.85} />
        </mesh>
      ))}

      {/* scenery */}
      {scenery.map((item, i) => (
        <primitive key={i} object={item.obj} />
      ))}

      {/* traffic */}
      {cars.map((c, i) => (
        <primitive key={`car-${i}`} object={c.group} />
      ))}
      {cones.map((c, i) => (
        <primitive key={`cone-${i}`} object={c.group} />
      ))}
      {barriers.map((b, i) => (
        <primitive key={`barrier-${i}`} object={b.group} />
      ))}
      {pickups.map((p, i) => (
        <primitive key={`pickup-${i}`} object={p.group} />
      ))}

      {/* player */}
      <primitive object={player.group} />

      {/* crash particles */}
      {particles.map((p, i) => (
        <primitive key={`p-${i}`} object={p} />
      ))}
    </group>
  );
}

export default memo(GameScene);
