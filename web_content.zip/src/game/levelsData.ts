/**
 * Levels configuration and environment themes for Subway Mom Runner 3D.
 */

import { LevelConfig } from '../types/game';

export const GAME_LEVELS: LevelConfig[] = [
  {
    id: 1,
    title: 'حي الحارة القديمة',
    subtitle: 'اهرب من ماما في أزقة الحارة الشعبية الملونة!',
    targetDistance: 1000,
    targetCoins: 60,
    skyColor: 0x60a5fa,
    fogColor: 0x93c5fd,
    roadColor: 0x334155,
    buildingStyle: 'oriental',
    unlocked: true,
    stars: 0
  },
  {
    id: 2,
    title: 'شارع الأبراج الحديثة',
    subtitle: 'حافلات مسرعة وشوارع زجاجية عريضة!',
    targetDistance: 1600,
    targetCoins: 100,
    skyColor: 0x38bdf8,
    fogColor: 0x7dd3fc,
    roadColor: 0x1e293b,
    buildingStyle: 'downtown',
    unlocked: false,
    stars: 0
  },
  {
    id: 3,
    title: 'كورنيش البحر عند الغروب',
    subtitle: 'نسيم البحر والنخيل مع وهج الغروب البرتقالي الساحر!',
    targetDistance: 2200,
    targetCoins: 140,
    skyColor: 0xf97316,
    fogColor: 0xfdba74,
    roadColor: 0x374151,
    buildingStyle: 'coastal',
    unlocked: false,
    stars: 0
  },
  {
    id: 4,
    title: 'الجسر المعلق السريع',
    subtitle: 'حركة مرور سريعة ومسارات ضيقة فوق الماء!',
    targetDistance: 2800,
    targetCoins: 180,
    skyColor: 0x6366f1,
    fogColor: 0xa5b4fc,
    roadColor: 0x0f172a,
    buildingStyle: 'highway',
    unlocked: false,
    stars: 0
  },
  {
    id: 5,
    title: 'السوق الشعبي الكبير',
    subtitle: 'فوانيس، زينات، وعوائق خشبية تتطلب تركيزاً خارقاً!',
    targetDistance: 3500,
    targetCoins: 250,
    skyColor: 0xd97706,
    fogColor: 0xfde68a,
    roadColor: 0x451a03,
    buildingStyle: 'oriental',
    unlocked: false,
    stars: 0
  }
];
