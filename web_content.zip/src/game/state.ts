import {
  ECONOMY,
  FISH_META,
  FISHING,
  PLAYER,
  STORAGE_KEY,
  type FishKind,
} from './config'

export type Phase = 'title' | 'play' | 'fishing'

export type FloatText = {
  x: number
  y: number
  text: string
  color: string
  life: number
  maxLife: number
  vy: number
}

export type Particle = {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  color: string
  size: number
}

export type CatchBag = {
  kind: FishKind
  count: number
}

export type GameState = {
  phase: Phase
  gold: number
  bait: number
  baitTier: 0 | 1 | 2
  basket: CatchBag[]
  totalCaught: number
  bestGold: number

  player: { x: number; y: number; facing: 1 | -1; anim: number; moving: boolean }
  cam: { x: number; y: number }

  /** fishing mini-game */
  fish: {
    waiting: number
    bar: number
    barDir: 1 | -1
    target: FishKind | null
    result: 'none' | 'ok' | 'miss'
    resultTimer: number
  }

  toast: { text: string; life: number }
  floats: FloatText[]
  particles: Particle[]
  trauma: number
  time: number
  waterPulse: number

  /** one-shot flags for SFX from update → App */
  sfx: string | null
}

function loadBest(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return 0
    const data = JSON.parse(raw) as { bestGold?: number }
    return typeof data.bestGold === 'number' ? data.bestGold : 0
  } catch {
    return 0
  }
}

export function saveBest(gold: number, best: number): number {
  const next = Math.max(gold, best)
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ bestGold: next }))
  } catch {
    // ignore quota / private mode
  }
  return next
}

export function createInitialState(): GameState {
  return {
    phase: 'title',
    gold: ECONOMY.startGold,
    bait: ECONOMY.startBait,
    baitTier: 0,
    basket: [],
    totalCaught: 0,
    bestGold: loadBest(),

    player: {
      x: PLAYER.startX,
      y: PLAYER.startY,
      facing: 1,
      anim: 0,
      moving: false,
    },
    cam: { x: 0, y: 0 },

    fish: {
      waiting: 0,
      bar: 0.5,
      barDir: 1,
      target: null,
      result: 'none',
      resultTimer: 0,
    },

    toast: { text: '', life: 0 },
    floats: [],
    particles: [],
    trauma: 0,
    time: 0,
    waterPulse: 0,
    sfx: null,
  }
}

export function resetRun(state: GameState): void {
  state.phase = 'play'
  state.gold = ECONOMY.startGold
  state.bait = ECONOMY.startBait
  state.baitTier = 0
  state.basket = []
  state.totalCaught = 0
  state.player.x = PLAYER.startX
  state.player.y = PLAYER.startY
  state.player.facing = 1
  state.player.anim = 0
  state.player.moving = false
  state.fish.waiting = 0
  state.fish.bar = 0.5
  state.fish.target = null
  state.fish.result = 'none'
  state.fish.resultTimer = 0
  state.toast = { text: '', life: 0 }
  state.floats.length = 0
  state.particles.length = 0
  state.trauma = 0
  state.sfx = null
}

export function basketCount(state: GameState): number {
  return state.basket.reduce((n, c) => n + c.count, 0)
}

export function basketValue(state: GameState): number {
  return state.basket.reduce((n, c) => n + c.count * ECONOMY.fishValue[c.kind], 0)
}

export function addCatch(state: GameState, kind: FishKind): void {
  const slot = state.basket.find((c) => c.kind === kind)
  if (slot) slot.count += 1
  else state.basket.push({ kind, count: 1 })
  state.totalCaught += 1
}

export function pickFish(tier: 0 | 1 | 2): FishKind {
  const w = FISHING.weightsByBait[tier]
  const r = Math.random()
  if (r < w[0]) return 'common'
  if (r < w[0] + w[1]) return 'rare'
  return 'legend'
}

export function fishLabel(kind: FishKind): string {
  return FISH_META[kind].label
}

export function showToast(state: GameState, text: string, life = 2.2): void {
  state.toast = { text, life }
}

export function spawnFloat(
  state: GameState,
  x: number,
  y: number,
  text: string,
  color: string,
): void {
  state.floats.push({
    x,
    y,
    text,
    color,
    life: 1.1,
    maxLife: 1.1,
    vy: -36,
  })
}

export function burst(
  state: GameState,
  x: number,
  y: number,
  color: string,
  n = 14,
): void {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2
    const sp = 50 + Math.random() * 140
    state.particles.push({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: 0.45 + Math.random() * 0.35,
      maxLife: 0.8,
      color,
      size: 2 + Math.random() * 3,
    })
  }
}
