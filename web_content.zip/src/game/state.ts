import {
  FAIL_COVERAGE,
  INK_COLORS,
  PAINT_COLS,
  PAINT_ROWS,
  START_COVERAGE_GRACE,
} from './config'

export type Phase = 'title' | 'playing' | 'ended'

export type Stain = {
  x: number
  y: number
  r: number
  life: number
  age: number
  flash: number
}

export type Particle = {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  color: string
  size: number
}

export type Floater = {
  x: number
  y: number
  text: string
  life: number
  maxLife: number
  color: string
}

export type GameState = {
  phase: Phase
  elapsed: number
  score: number
  displayScore: number
  best: number
  coverage: number
  combo: number
  comboCells: number
  paintColorIdx: number
  colorTimer: number
  polvo: { x: number; y: number; targetX: number; targetY: number; bob: number }
  dragging: boolean
  stains: Stain[]
  stainTimer: number
  particles: Particle[]
  floaters: Floater[]
  trauma: number
  freeze: number
  /** 0 empty, 1 painted, 2 stained */
  grid: Uint8Array
  paintedCount: number
  stainedCount: number
  totalCells: number
  w: number
  h: number
  ready: boolean
  muted: boolean
  titlePulse: number
  endFlash: number
}

export function createInitialState(best = 0): GameState {
  return {
    phase: 'title',
    elapsed: 0,
    score: 0,
    displayScore: 0,
    best,
    coverage: 0,
    combo: 1,
    comboCells: 0,
    paintColorIdx: 0,
    colorTimer: 0,
    polvo: { x: 0, y: 0, targetX: 0, targetY: 0, bob: 0 },
    dragging: false,
    stains: [],
    stainTimer: 1.2,
    particles: [],
    floaters: [],
    trauma: 0,
    freeze: 0,
    grid: new Uint8Array(PAINT_COLS * PAINT_ROWS),
    paintedCount: 0,
    stainedCount: 0,
    totalCells: PAINT_COLS * PAINT_ROWS,
    w: 0,
    h: 0,
    ready: false,
    muted: false,
    titlePulse: 0,
    endFlash: 0,
  }
}

export function resetRun(state: GameState): void {
  state.phase = 'playing'
  state.elapsed = 0
  state.score = 0
  state.displayScore = 0
  state.coverage = 0
  state.combo = 1
  state.comboCells = 0
  state.paintColorIdx = 0
  state.colorTimer = 0
  state.stains.length = 0
  state.stainTimer = 1.2
  state.particles.length = 0
  state.floaters.length = 0
  state.trauma = 0
  state.freeze = 0
  state.grid.fill(0)
  state.paintedCount = 0
  state.stainedCount = 0
  state.endFlash = 0
  state.dragging = false
  const cx = state.w * 0.5
  const cy = state.h * 0.55
  state.polvo.x = cx
  state.polvo.y = cy
  state.polvo.targetX = cx
  state.polvo.targetY = cy
}

export function paintColor(state: GameState): string {
  return INK_COLORS[state.paintColorIdx % INK_COLORS.length]
}

export function canFail(state: GameState): boolean {
  return state.elapsed >= START_COVERAGE_GRACE && state.coverage < FAIL_COVERAGE
}
