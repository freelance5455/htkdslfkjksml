/**
 * Gear items: Hoverboards and Backpacks/Jetpacks data
 */

import { HoverboardItem, BackpackItem } from '../types/game';

export interface VehicleItem extends HoverboardItem {
  vehicleType: 'board' | 'bike' | 'kart' | 'scooter' | 'rocket' | 'carpet';
}

export const HOVERBOARDS: VehicleItem[] = [
  {
    id: 'classic',
    name: 'لوح صبواي الأصلي (Skateboard)',
    speedMultiplier: 1.15,
    vehicleType: 'board',
    unlocked: true,
    cost: 0,
    description: 'اللوح الكلاسيكي ذو العجلات الأربع، رشيق وخفيف ويوفر درع حماية ضد أول اصطدام.',
    primaryColor: '#ef4444',
    trailColor: '#f97316',
    hasSparks: false
  },
  {
    id: 'hover_bike',
    name: 'الدباب الهوائي النفاث (Hoverbike)',
    speedMultiplier: 1.3,
    vehicleType: 'bike',
    unlocked: true,
    cost: 0,
    description: 'دراجة نارية هوائية مستقبلية تطير فوق السكك الحديدية بمحركات نفاثة قوية!',
    primaryColor: '#3b82f6',
    trailColor: '#60a5fa',
    hasSparks: true
  },
  {
    id: 'mini_kart',
    name: 'سيارة الكارت الرياضية (Mini Kart)',
    speedMultiplier: 1.35,
    vehicleType: 'kart',
    unlocked: false,
    cost: 500,
    description: 'سيارة سباق صغيرة بمقود رياضي وإطارات عريضة تحطم المطبات دون أن تفقد توازنك.',
    primaryColor: '#f59e0b',
    trailColor: '#fbbf24',
    hasSparks: true
  },
  {
    id: 'city_scooter',
    name: 'سكوتر المدينة السريع (E-Scooter)',
    speedMultiplier: 1.25,
    vehicleType: 'scooter',
    unlocked: false,
    cost: 400,
    description: 'سكوتر كهربائي خفيف الوزن بمقود مضيء، يمنحك مناورات فائقة الدقة بين القطارات.',
    primaryColor: '#10b981',
    trailColor: '#34d399',
    hasSparks: false
  },
  {
    id: 'space_rocket',
    name: 'صاروخ الركوب الفضائي (Space Rocket)',
    speedMultiplier: 1.5,
    vehicleType: 'rocket',
    unlocked: false,
    cost: 1500,
    description: 'مركبة صاروخية بمحركات دافعة تترك ذيلاً نيرانياً وتطير بك بسرعة خارقة!',
    primaryColor: '#8b5cf6',
    trailColor: '#c084fc',
    hasSparks: true
  },
  {
    id: 'dragon_flame',
    name: 'لهيب التنين الناري (Dragon Board)',
    speedMultiplier: 1.4,
    vehicleType: 'board',
    unlocked: false,
    cost: 1000,
    description: 'لوح ناري أسطوري يترك خلفه أثراً مشتعلاً يرهب ماما ويضاعف مسافة الأمان!',
    primaryColor: '#dc2626',
    trailColor: '#f97316',
    hasSparks: true
  },
  {
    id: 'magic_carpet',
    name: 'بساط الريح السحري (Magic Carpet)',
    speedMultiplier: 1.45,
    vehicleType: 'carpet',
    unlocked: false,
    cost: 1200,
    description: 'بساط شرقي فاخر منسوج من الحرير والذهب، يطفو فوق العوائق بخفة وسلاسة.',
    primaryColor: '#a855f7',
    trailColor: '#eab308',
    hasSparks: true
  },
  {
    id: 'gold_rush',
    name: 'مركبة الملياردير الذهبية (Gold Cruiser)',
    speedMultiplier: 1.4,
    vehicleType: 'kart',
    unlocked: false,
    cost: 2500,
    description: 'مصنوعة من الذهب الخالص عيار 24، تجذب العملات تلقائياً نحو اللاعب.',
    primaryColor: '#eab308',
    trailColor: '#fef08a',
    hasSparks: true
  }
];

export const BACKPACKS: BackpackItem[] = [
  {
    id: 'school_bag',
    name: 'حقيبة المدرسة المشاغبة',
    bonus: 'سعة تخزين +10% عملات إضافية',
    unlocked: true,
    cost: 0,
    primaryColor: '#3b82f6',
    isJetpack: false
  },
  {
    id: 'rocket_jetpack',
    name: 'حقيبة النفاثة الصاروخية',
    bonus: 'تزيد مدة طيران النفاثة +4 ثوانٍ في السماء',
    unlocked: false,
    cost: 1500,
    primaryColor: '#ef4444',
    isJetpack: true
  },
  {
    id: 'golden_wings',
    name: 'أجنحة الصقر الذهبي',
    bonus: 'تمنحك قفزة مضاعفة خفيفة عند الحاجة',
    unlocked: false,
    cost: 3200,
    primaryColor: '#eab308',
    isJetpack: false
  },
  {
    id: 'cyber_battery',
    name: 'مولد الطاقة السايبر',
    bonus: 'تطيل زمن كل المعززات (المغناطيس والمضاعف) +25%',
    unlocked: false,
    cost: 5000,
    primaryColor: '#06b6d4',
    isJetpack: true
  }
];
