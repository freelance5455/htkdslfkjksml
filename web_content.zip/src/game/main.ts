/**
 * ТОЧКИ ФРОНТА — минималистичная RTS в духе War of Dots.
 *
 * Как играть
 * ----------
 * Красные точки — восток, синие — запад. В режиме «все против всех» есть ещё
 * зелёные и янтарные. Это абстрактная партия на стилизованной карте, не хроника.
 *
 * Город даёт очки и кормит армию (лёгкая точка ест 1, тяжёлая — 2). Лишние
 * голодают, отрезанные от своих городов тают быстро.
 * Лёгкая (цена 1) быстрая и хороша в лесу. Тяжёлая (цена 3) живучая на степи
 * и почти бесполезна в чаще. Реку переходите по мостам-дорогам.
 * Бой начинается сам, когда точки соприкасаются.
 * Город берётся, если в его кольце постоять без защитников хозяина.
 *
 * Телефон: тап — выбор, «Марш» и второй тап — приказ, щипок — масштаб,
 * одним пальцем — двигать карту.
 * Компьютер: левый клик — выбор, протяжка — рамка, правый клик — марш,
 * колесо — масштаб, WASD — камера, пробел — пауза, 1/2 — производство, M — марш.
 */
import {
  ACHIEVEMENTS,
  BALANCE,
  CAMPAIGN,
  CITIES,
  CITY_BY_ID,
  FACTIONS,
  FORESTS,
  HILLS,
  RIVER,
  ROADS,
  SEAS,
  WORLD_H,
  WORLD_W,
  autoSpawns,
  lex,
  skirmishScenario,
  templateScenario,
  worldScenario,
  type CityDef,
  type Diff,
  type FactionId,
  type Kind,
  type Lang,
  type OwnerId,
  type Scenario,
  type Spawn,
} from "./content";
import { Sound } from "./audio";
import { SaveSystem, type ReplayData } from "./save";
import {
  COLS,
  ROWS,
  TERRAIN,
  bakeTerrain,
  cellIndex,
  findPath,
  isSeaIndex,
  terrainAt,
} from "./nav";

const TAU = Math.PI * 2;
const STEP = 1 / 30;
const MAX_UNITS = 380;
const HASH = 64;
const HCOLS = Math.ceil(WORLD_W / HASH);
const HROWS = Math.ceil(WORLD_H / HASH);
const FOG_CELL = 40;
const FCOLS = Math.ceil(WORLD_W / FOG_CELL);
const FROWS = Math.ceil(WORLD_H / FOG_CELL);

type Screen =
  | "menu"
  | "help"
  | "settings"
  | "achievements"
  | "campaign"
  | "world"
  | "editor"
  | "setup"
  | "brief"
  | "pause"
  | "end"
  | "replay"
  | "none";

interface Unit {
  id: number;
  alive: boolean;
  owner: FactionId;
  kind: Kind;
  x: number;
  y: number;
  px: number;
  py: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  wps: { x: number; y: number }[];
  wi: number;
  order: "idle" | "move";
  targetId: number;
  still: number;
  supply: 0 | 1 | 2;
  aiLock: number;
  repathAt: number;
  stuck: number;
  flash: number;
  age: number;
  hitBy: number;
}

interface CityRt {
  def: CityDef;
  active: boolean;
  owner: OwnerId;
  cap: number;
  capBy: OwnerId;
  queue: Kind[];
  progress: number;
  dur: number;
}

interface Player {
  id: FactionId;
  human: boolean;
  points: number;
  aiCool: number;
  inPlay: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  r: number;
}

interface Toast {
  msg: string;
  life: number;
}

interface Drag {
  id: number;
  sx: number;
  sy: number;
  button: number;
  pointerType: string;
  moved: boolean;
  box: boolean;
  camX: number;
  camY: number;
}

interface Pinch {
  dist: number;
  zoom: number;
  wx: number;
  wy: number;
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function hypot(x: number, y: number) {
  return Math.hypot(x, y);
}

function esc(s: string) {
  return s.replace(/[&<>"']/g, (c) => {
    switch (c) {
      case "&":
        return "&" + "amp;";
      case "<":
        return "&" + "lt;";
      case ">":
        return "&" + "gt;";
      case '"':
        return "&" + "quot;";
      default:
        return "&" + "#39;";
    }
  });
}

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
}

function formation(i: number, n: number, gap: number) {
  const cols = Math.max(1, Math.ceil(Math.sqrt(n)));
  const rows = Math.ceil(n / cols);
  return {
    x: ((i % cols) - (cols - 1) / 2) * gap,
    y: (Math.floor(i / cols) - (rows - 1) / 2) * gap,
  };
}

function buildDur(kind: Kind, level: number) {
  const base = kind === "light" ? 4.3 : 10.6;
  return base / (0.55 + 0.42 * level);
}

function blankUnit(): Unit {
  return {
    id: 0,
    alive: false,
    owner: 0,
    kind: "light",
    x: 0,
    y: 0,
    px: 0,
    py: 0,
    vx: 0,
    vy: 0,
    hp: 0,
    maxHp: 0,
    wps: [],
    wi: 0,
    order: "idle",
    targetId: -1,
    still: 0,
    supply: 0,
    aiLock: 0,
    repathAt: 0,
    stuck: 0,
    flash: 0,
    age: 0,
    hitBy: -1,
  };
}

class Spatial {
  private buckets: number[][] = Array.from({ length: HCOLS * HROWS }, () => []);
  private used: number[] = [];
  clear() {
    for (const i of this.used) this.buckets[i]!.length = 0;
    this.used.length = 0;
  }
  insert(index: number, x: number, y: number) {
    const c = clamp(Math.floor(x / HASH), 0, HCOLS - 1);
    const r = clamp(Math.floor(y / HASH), 0, HROWS - 1);
    const i = r * HCOLS + c;
    const b = this.buckets[i]!;
    if (b.length === 0) this.used.push(i);
    b.push(index);
  }
  query(x: number, y: number, rad: number, out: number[]) {
    out.length = 0;
    const c0 = clamp(Math.floor((x - rad) / HASH), 0, HCOLS - 1);
    const c1 = clamp(Math.floor((x + rad) / HASH), 0, HCOLS - 1);
    const r0 = clamp(Math.floor((y - rad) / HASH), 0, HROWS - 1);
    const r1 = clamp(Math.floor((y + rad) / HASH), 0, HROWS - 1);
    const r2 = rad * rad;
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const b = this.buckets[r * HCOLS + c]!;
        for (let k = 0; k < b.length; k++) out.push(b[k]!);
      }
    }
    void r2;
    return out;
  }
}

class Front {
  private host: HTMLElement;
  private ac = new AbortController();
  private save = new SaveSystem();
  private audio = new Sound();
  private hash = new Spatial();
  private qbuf: number[] = [];
  private dmg = new Float32Array(512);
  private hitFrom = new Int16Array(512);

  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private mini: HTMLCanvasElement;
  private mctx: CanvasRenderingContext2D;
  private terrain: HTMLCanvasElement;
  private fogCanvas: HTMLCanvasElement;
  private fogCtx: CanvasRenderingContext2D;
  private fogImg: ImageData;
  private explored: Uint8Array;
  private visible: Uint8Array;

  private hud: HTMLElement;
  private dock: HTMLElement;
  private overlay: HTMLElement;
  private toastsEl: HTMLElement;
  private tutorEl: HTMLElement;
  private objectiveEl: HTMLElement;
  private elPoints: HTMLElement;
  private elSupply: HTMLElement;
  private elTime: HTMLElement;
  private elSide: HTMLElement;

  private raf = 0;
  private last = 0;
  private acc = 0;
  private viewW = 800;
  private viewH = 600;
  private dpr = 1;
  private camX = WORLD_W / 2;
  private camY = WORLD_H / 2;
  private zoom = 0.6;
  private shake = 0;
  private demoT = 0;
  private reduced: boolean;

  private screen: Screen = "menu";
  private returnScreen: Screen = "menu";
  private uiSig = "";
  private uiRev = 0;
  private dockSig = "";
  private toastSig = "";
  private tutSig = "";

  private battle = false;
  private ended = false;
  private accounted = false;
  private scenario: Scenario | null = null;
  private human: FactionId = 0;
  private difficulty: Diff = 1;
  private fogOn = false;
  private speed = 1;
  private time = 0;
  private hold = 0;
  private outcome: "win" | "lose" | null = null;
  private pending: "win" | "lose" | null = null;
  private endDelay = 0;
  private lostCity = false;
  private nextId = 1;
  private pathBudget = 4;
  private supplyAcc = 0;
  private fogAcc = 0;
  private recAcc = 0;
  private saveAcc = 0;
  private warnCut = 0;
  private warnHungry = 0;
  private armed = false;
  private selCity: string | null = null;
  private selected = new Set<number>();
  private groups: number[][] = [[], [], [], [], [], [], [], [], [], []];
  private tutStep = -1;

  private units: Unit[] = [];
  private cities: CityRt[] = [];
  private players: Player[] = [];
  private idMap = new Map<number, number>();
  private particles: Particle[] = [];
  private toasts: Toast[] = [];
  private battleStat = { kills: 0, losses: 0, cities: 0, starved: 0 };

  private setupFfa: 2 | 3 | 4 = 2;
  private setupSide: FactionId = 0;
  private editorDraft = "";
  private editorMsg = "";

  private replay: ReplayData | null = null;
  private playingReplay = false;
  private replayOn = false;
  private playT = 0;
  private replayRate = 1;
  private recording = true;

  private keys = new Set<string>();
  private pointers = new Map<number, { x: number; y: number }>();
  private drag: Drag | null = null;
  private pinch: Pinch | null = null;
  private pointerX = 0;
  private pointerY = 0;
  private gpOn = false;
  private gpCursor = { x: WORLD_W * 0.72, y: WORLD_H * 0.5 };
  private gpPrev: boolean[] = [];

  constructor(host: HTMLElement) {
    this.host = host;
    this.save.load();
    this.audio.setEnabled(this.save.data.sound);
    this.audio.setVolume(this.save.data.volume);
    this.reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    bakeTerrain();
    this.editorDraft = JSON.stringify(this.publicScenario(templateScenario()), null, 2);

    host.innerHTML = `
      <canvas class="view"></canvas>
      <div class="hud hidden">
        <header class="topbar">
          <div class="chip" id="el-side"><i class="swatch"></i><strong></strong></div>
          <div class="chip" id="el-points"></div>
          <div class="chip" id="el-supply"></div>
          <div class="chip" id="el-time"></div>
          <div class="speeds">
            <button type="button" data-act="speed" data-arg="0">II</button>
            <button type="button" data-act="speed" data-arg="1">1×</button>
            <button type="button" data-act="speed" data-arg="2">2×</button>
            <button type="button" data-act="speed" data-arg="3">3×</button>
          </div>
          <button type="button" class="icon-btn" data-act="open-pause"></button>
        </header>
        <div class="mini-wrap"><canvas class="mini"></canvas></div>
        <div class="objective" id="el-obj"></div>
        <div class="toasts" id="el-toasts"></div>
        <div class="tutor hidden" id="el-tutor"></div>
        <footer class="dock" id="el-dock"></footer>
      </div>
      <div class="overlay" id="el-overlay"></div>
    `;
    this.canvas = host.querySelector(".view") as HTMLCanvasElement;
    this.mini = host.querySelector(".mini") as HTMLCanvasElement;
    const ctx = this.canvas.getContext("2d");
    const mctx = this.mini.getContext("2d");
    if (!ctx || !mctx) throw new Error("canvas");
    this.ctx = ctx;
    this.mctx = mctx;
    this.hud = host.querySelector(".hud") as HTMLElement;
    this.dock = host.querySelector("#el-dock") as HTMLElement;
    this.overlay = host.querySelector("#el-overlay") as HTMLElement;
    this.toastsEl = host.querySelector("#el-toasts") as HTMLElement;
    this.tutorEl = host.querySelector("#el-tutor") as HTMLElement;
    this.objectiveEl = host.querySelector("#el-obj") as HTMLElement;
    this.elPoints = host.querySelector("#el-points") as HTMLElement;
    this.elSupply = host.querySelector("#el-supply") as HTMLElement;
    this.elTime = host.querySelector("#el-time") as HTMLElement;
    this.elSide = host.querySelector("#el-side") as HTMLElement;

    this.terrain = document.createElement("canvas");
    const sc = 0.42;
    this.terrain.width = Math.floor(WORLD_W * sc);
    this.terrain.height = Math.floor(WORLD_H * sc);
    const tctx = this.terrain.getContext("2d");
    if (!tctx) throw new Error("terrain");
    tctx.scale(sc, sc);
    this.paintTerrain(tctx);

    this.fogCanvas = document.createElement("canvas");
    this.fogCanvas.width = FCOLS;
    this.fogCanvas.height = FROWS;
    const fctx = this.fogCanvas.getContext("2d");
    if (!fctx) throw new Error("fog");
    this.fogCtx = fctx;
    this.fogImg = fctx.createImageData(FCOLS, FROWS);
    this.explored = new Uint8Array(FCOLS * FROWS);
    this.visible = new Uint8Array(FCOLS * FROWS);

    this.bind();
    this.resize();
    this.frameCamera(false);
    this.syncOverlay(true);
    this.raf = requestAnimationFrame(this.frame);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.ac.abort();
    this.audio.close();
    const w = window as unknown as { __front?: unknown };
    if (w.__front) delete w.__front;
  }

  private get lang(): Lang {
    return this.save.data.lang;
  }

  private get t() {
    return lex(this.lang);
  }

  private bind() {
    const opt = { signal: this.ac.signal };
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(this.host);
    this.ac.signal.addEventListener("abort", () => ro.disconnect());
    window.addEventListener("keydown", this.onKeyDown, opt);
    window.addEventListener("keyup", this.onKeyUp, opt);
    window.addEventListener("pointerdown", () => this.audio.unlock(), opt);
    window.addEventListener("visibilitychange", () => this.audio.resumeOnFocus(), opt);
    this.canvas.addEventListener("pointerdown", this.onPointerDown, opt);
    this.canvas.addEventListener("pointermove", this.onPointerMove, opt);
    this.canvas.addEventListener("pointerup", this.onPointerUp, opt);
    this.canvas.addEventListener("pointercancel", this.onPointerUp, opt);
    this.canvas.addEventListener("contextmenu", (e) => e.preventDefault(), opt);
    this.canvas.addEventListener("wheel", this.onWheel, { ...opt, passive: false });
    this.mini.addEventListener("pointerdown", this.onMini, opt);
    this.mini.addEventListener("pointermove", this.onMini, opt);
    this.host.addEventListener("click", this.onClick, opt);
    this.host.addEventListener("input", this.onInput, opt);
    const w = window as unknown as {
      __front?: {
        ready: boolean;
        screen: () => Screen;
        alive: () => number;
        startSkirmish: () => void;
      };
    };
    w.__front = {
      ready: true,
      screen: () => this.screen,
      alive: () => this.units.filter((u) => u.alive).length,
      startSkirmish: () => {
        this.begin(skirmishScenario(2, 0, false));
        this.act("fight", "");
      },
    };
  }

  private resize() {
    const r = this.host.getBoundingClientRect();
    this.viewW = Math.max(1, r.width);
    this.viewH = Math.max(1, r.height);
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.round(this.viewW * this.dpr);
    this.canvas.height = Math.round(this.viewH * this.dpr);
    const mw = this.mini.clientWidth || 164;
    const mh = this.mini.clientHeight || 102;
    this.mini.width = Math.round(mw * this.dpr);
    this.mini.height = Math.round(mh * this.dpr);
    if (!this.battle) this.frameCamera(false);
  }

  private frame = (now: number) => {
    if (!this.last) this.last = now;
    let raw = (now - this.last) / 1000;
    this.last = now;
    if (raw < 0) raw = 0;
    if (raw > 0.05) raw = 0.05;
    if (!this.battle) this.demoT += raw;
    if (this.playingReplay && this.replayOn && this.replay) {
      this.playT = Math.min(this.replay.duration, this.playT + raw * this.replayRate);
    }
    if (!this.battle) {
      this.camX = WORLD_W * 0.62 + Math.sin(this.demoT * 0.08) * 180;
      this.camY = WORLD_H * 0.48 + Math.cos(this.demoT * 0.055) * 90;
      this.zoom = clamp(Math.max(this.viewW / 1500, this.viewH / 1100), 0.45, 1);
    }
    if (this.playingReplay && this.replay) {
      const label = this.overlay.querySelector("#replay-time");
      if (label) label.textContent = `${fmt(this.playT)} / ${fmt(this.replay.duration)}`;
      const scrub = this.overlay.querySelector<HTMLInputElement>("#scrub");
      if (scrub && document.activeElement !== scrub) {
        scrub.value = String(this.replay.duration ? this.playT / this.replay.duration : 0);
      }
    }
    const run = this.screen === "none" && this.battle && !this.ended;
    this.acc += raw * (run ? this.speed : 0);
    let n = 0;
    while (this.acc >= STEP && n < 5) {
      this.step(STEP);
      this.acc -= STEP;
      n++;
    }
    if (n === 5) this.acc = 0;
    this.panKeys(raw);
    this.gamepad(raw);
    this.fadeToasts(raw);
    this.shake = Math.max(0, this.shake - raw * 1.3);
    this.draw();
    this.syncOverlay(false);
    this.syncHud();
    this.raf = requestAnimationFrame(this.frame);
  };

  private panKeys(raw: number) {
    if (!this.battle && this.screen !== "replay") return;
    if (this.screen !== "none" && this.screen !== "pause" && this.screen !== "brief" && this.screen !== "replay") return;
    const typing = this.typing();
    if (typing) return;
    let x = 0;
    let y = 0;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) x -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) x += 1;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) y -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) y += 1;
    if (!x && !y) return;
    const sp = (680 * raw) / this.zoom;
    this.camX += x * sp;
    this.camY += y * sp;
    this.clampCam();
  }

  private typing() {
    const el = document.activeElement;
    if (!el) return false;
    const tag = el.tagName;
    return tag === "INPUT" || tag === "TEXTAREA";
  }

  private step(dt: number) {
    this.time += dt;
    this.pathBudget = 4;
    this.hash.clear();
    for (let i = 0; i < this.units.length; i++) {
      const u = this.units[i]!;
      if (u.alive) this.hash.insert(i, u.x, u.y);
    }
    const human = this.human;
    let cut = 0;
    let hungry = 0;

    for (let i = 0; i < this.units.length; i++) {
      const u = this.units[i]!;
      if (!u.alive) continue;
      u.age += dt;
      u.flash = Math.max(0, u.flash - dt);
      this.steer(u, dt);
    }

    this.hash.clear();
    for (let i = 0; i < this.units.length; i++) {
      const u = this.units[i]!;
      if (u.alive) this.hash.insert(i, u.x, u.y);
    }

    if (this.dmg.length < this.units.length) {
      this.dmg = new Float32Array(this.units.length + 32);
      this.hitFrom = new Int16Array(this.units.length + 32);
    }
    this.dmg.fill(0, 0, this.units.length);
    this.hitFrom.fill(-1, 0, this.units.length);

    for (let i = 0; i < this.units.length; i++) {
      const u = this.units[i]!;
      if (!u.alive || u.age < 0.25) continue;
      const stat = BALANCE[u.kind];
      const reach = stat.range + stat.r;
      this.hash.query(u.x, u.y, reach, this.qbuf);
      let best = -1;
      let bestD = reach;
      const prefer = u.targetId;
      for (let k = 0; k < this.qbuf.length; k++) {
        const j = this.qbuf[k]!;
        if (j === i) continue;
        const o = this.units[j]!;
        if (!o.alive || o.owner === u.owner) continue;
        const d = hypot(o.x - u.x, o.y - u.y);
        const limit = (stat.range + BALANCE[o.kind].r) * 0.92;
        if (d < limit && (d < bestD || o.id === prefer)) {
          if (o.id === prefer) {
            best = j;
            bestD = d;
            break;
          }
          best = j;
          bestD = d;
        }
      }
      if (best >= 0) {
        const o = this.units[best]!;
        const ma = this.mods(u);
        const mb = this.mods(o);
        this.dmg[best] = (this.dmg[best] ?? 0) + stat.dps * ma.out * mb.taken * dt;
        this.hitFrom[best] = u.owner;
        if (u.owner === human || o.owner === human) this.audio.shot();
      }
    }

    for (let i = 0; i < this.units.length; i++) {
      const u = this.units[i]!;
      if (!u.alive) continue;
      const dealt = this.dmg[i] ?? 0;
      if (dealt > 0) {
        u.hp -= dealt;
        u.flash = 0.08;
        u.hitBy = this.hitFrom[i] ?? -1;
        if (!this.reduced && Math.random() < 0.25) this.burst(u.x, u.y, FACTIONS[u.owner].color, 2);
      }
      if (u.age > 0.9) {
        if (u.supply === 2) u.hp -= BALANCE.starveCut * dt;
        else if (u.supply === 1) u.hp -= BALANCE.starveHungry * dt;
      }
      if (u.hp <= 0) this.kill(u, dealt > 0 ? u.hitBy : u.supply > 0 ? -2 : u.hitBy);
    }

    this.capture(dt);
    this.produce(dt);
    for (const p of this.players) {
      if (!p.inPlay) continue;
      p.points = Math.min(48, p.points + this.income(p.id) * dt);
      if (!p.human) {
        p.aiCool -= dt;
        if (p.aiCool <= 0) {
          p.aiCool = this.difficulty === 0 ? 1.25 : this.difficulty === 1 ? 0.82 : 0.52;
          this.aiAct(p.id);
        }
      }
    }

    this.supplyAcc += dt;
    if (this.supplyAcc >= 0.45) {
      this.supplyAcc = 0;
      this.refreshSupply();
    }
    for (const u of this.units) {
      if (!u.alive || u.owner !== human) continue;
      if (u.supply === 2) cut++;
      else if (u.supply === 1) hungry++;
    }
    if (cut > 0 && this.time > this.warnCut) {
      this.warnCut = this.time + 9;
      this.toast(this.t.armyCut);
      this.audio.warn();
    }
    if (hungry > 0 && cut === 0 && this.time > this.warnHungry) {
      this.warnHungry = this.time + 12;
      this.toast(this.t.supplyLow);
    }
    this.checkSwarm();

    if (this.fogOn) {
      this.fogAcc += dt;
      if (this.fogAcc >= 0.22) {
        this.fogAcc = 0;
        this.updateFog();
      }
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i]!;
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }

    if (this.recording) {
      this.recAcc += dt;
      if (this.recAcc >= 1) {
        this.recAcc = 0;
        this.pushSnap();
      }
    }
    this.saveAcc += dt;
    if (this.saveAcc > 20) {
      this.saveAcc = 0;
      this.save.persist();
    }
    this.checkEnd(dt);
    if (this.pending) {
      this.endDelay -= dt;
      if (this.endDelay <= 0) this.finish(this.pending);
    }
  }

  private steer(u: Unit, dt: number) {
    u.px = u.x;
    u.py = u.y;
    const stat = BALANCE[u.kind];
    if (u.targetId > 0) {
      const tgt = this.unitById(u.targetId);
      if (!tgt || !tgt.alive || tgt.owner === u.owner) u.targetId = -1;
      else {
        const d = hypot(tgt.x - u.x, tgt.y - u.y);
        const end = u.wps.length ? u.wps[u.wps.length - 1] : null;
        const far = !end || hypot(end.x - tgt.x, end.y - tgt.y) > 56;
        if (d > stat.range && far && this.time >= u.repathAt && this.pathBudget > 0) {
          this.pathBudget--;
          u.repathAt = this.time + 1.15;
          u.wps = findPath(u.x, u.y, tgt.x, tgt.y);
          u.wi = 0;
          u.order = "move";
        } else if (end) {
          end.x = tgt.x;
          end.y = tgt.y;
        }
      }
    }
    let tx = u.x;
    let ty = u.y;
    let moving = false;
    if (u.order === "move" && u.wps.length) {
      const wp = u.wps[Math.min(u.wi, u.wps.length - 1)]!;
      tx = wp.x;
      ty = wp.y;
      moving = true;
      if (hypot(u.x - tx, u.y - ty) < 18) {
        u.wi++;
        if (u.wi >= u.wps.length) {
          u.order = "idle";
          u.wps = [];
          moving = false;
          if (u.targetId < 0) u.targetId = -1;
        } else {
          const nwp = u.wps[u.wi]!;
          tx = nwp.x;
          ty = nwp.y;
        }
      }
    }
    const mods = this.mods(u);
    let maxSp = stat.speed * mods.speed;
    let dx = tx - u.x;
    let dy = ty - u.y;
    let dist = hypot(dx, dy) || 1;
    let desired = moving ? maxSp : 0;
    if (moving && dist < 42) desired *= dist / 42;
    if (u.targetId > 0) {
      const tgt = this.unitById(u.targetId);
      if (tgt && hypot(tgt.x - u.x, tgt.y - u.y) < stat.range * 0.88) desired = 0;
    }
    let tvx = moving ? (dx / dist) * desired : 0;
    let tvy = moving ? (dy / dist) * desired : 0;
    this.hash.query(u.x, u.y, 36, this.qbuf);
    const ur = stat.r;
    for (let k = 0; k < this.qbuf.length; k++) {
      const j = this.qbuf[k]!;
      const o = this.units[j]!;
      if (!o.alive || o === u) continue;
      const ddx = u.x - o.x;
      const ddy = u.y - o.y;
      const dd = hypot(ddx, ddy) || 0.001;
      const orad = BALANCE[o.kind].r;
      const min = o.owner === u.owner ? ur + orad + 3 : (ur + orad) * 0.7;
      if (dd < min) {
        const push = ((min - dd) / min) * (o.owner === u.owner ? 80 : 46);
        tvx += (ddx / dd) * push;
        tvy += (ddy / dd) * push;
      }
    }
    const tlen = hypot(tvx, tvy);
    const capSp = maxSp * 1.25;
    if (tlen > capSp) {
      tvx = (tvx / tlen) * capSp;
      tvy = (tvy / tlen) * capSp;
    }
    const blend = Math.min(1, dt * 6);
    u.vx += (tvx - u.vx) * blend;
    u.vy += (tvy - u.vy) * blend;
    u.x += u.vx * dt;
    u.y += u.vy * dt;
    if (terrainAt(u.x, u.y) === TERRAIN.sea) {
      for (let a = 0; a < 8; a++) {
        const ang = (a / 8) * TAU;
        const nx = u.x + Math.cos(ang) * 40;
        const ny = u.y + Math.sin(ang) * 40;
        if (terrainAt(nx, ny) !== TERRAIN.sea) {
          u.x = nx;
          u.y = ny;
          break;
        }
      }
    }
    u.x = clamp(u.x, 16, WORLD_W - 16);
    u.y = clamp(u.y, 16, WORLD_H - 16);
    const sp = hypot(u.vx, u.vy);
    if (sp < 14) u.still += dt;
    else u.still = 0;
    if (u.order === "move") {
      const moved = hypot(u.x - u.px, u.y - u.py);
      if (moved < 8 * dt) u.stuck += dt;
      else u.stuck = 0;
      if (u.stuck > 1.8 && this.pathBudget > 0 && u.wps.length) {
        u.stuck = 0;
        this.pathBudget--;
        const goal = u.wps[u.wps.length - 1]!;
        u.wps = findPath(u.x, u.y, goal.x, goal.y);
        u.wi = 0;
      }
    }
  }

  private mods(u: Unit) {
    const t = terrainAt(u.x, u.y);
    const heavy = u.kind === "heavy";
    let speed = 1;
    let out = 1;
    let taken = 1;
    if (t === TERRAIN.forest) {
      speed = heavy ? 0.5 : 0.8;
      out = heavy ? 0.45 : 1.15;
    } else if (t === TERRAIN.river) {
      speed = 0.32;
      taken = 1.14;
    } else if (t === TERRAIN.hill) {
      speed = 0.8;
      taken = 0.84;
    } else if (t === TERRAIN.city) {
      speed = 0.88;
      taken = 0.78;
    } else if (t === TERRAIN.road) {
      speed = 1.42;
    }
    if (u.still > BALANCE.stillDelay) taken *= BALANCE.stillTaken;
    if (u.supply === 2) out *= 0.55;
    else if (u.supply === 1) out *= 0.85;
    return { speed, out, taken };
  }

  private kill(u: Unit, cause: number) {
    if (!u.alive) return;
    u.alive = false;
    u.hp = 0;
    this.selected.delete(u.id);
    this.burst(u.x, u.y, FACTIONS[u.owner].color, this.reduced ? 3 : 8);
    if (cause >= 0 && cause === this.human && u.owner !== this.human) {
      this.battleStat.kills++;
      if (this.save.unlock("first_blood")) this.toast(`${this.t.achGet}: ${ACHIEVEMENTS[0]!.name[this.lang]}`);
    }
    if (u.owner === this.human) {
      this.battleStat.losses++;
      if (cause === -2) this.battleStat.starved++;
    } else if (cause === -2) {
      if (this.save.unlock("encircle")) {
        const ach = ACHIEVEMENTS.find((a) => a.id === "encircle");
        if (ach) this.toast(`${this.t.achGet}: ${ach.name[this.lang]}`);
      }
    }
  }

  private capture(dt: number) {
    const active = this.scenario?.factions ?? [];
    for (const c of this.cities) {
      if (!c.active) continue;
      const counts = [0, 0, 0, 0];
      let defenders = 0;
      for (const u of this.units) {
        if (!u.alive) continue;
        const d = hypot(u.x - c.def.x, u.y - c.def.y);
        if (c.owner >= 0 && u.owner === c.owner && d <= BALANCE.defendRadius) defenders++;
        if (d <= BALANCE.captureRadius) counts[u.owner] = (counts[u.owner] ?? 0) + 1;
      }
      if (defenders > 0) {
        c.cap = Math.max(0, c.cap - dt * 40);
        continue;
      }
      let best: OwnerId = -1;
      let bestN = 0;
      let tie = false;
      for (const f of active) {
        if (f === c.owner) continue;
        const n = counts[f] ?? 0;
        if (n > bestN) {
          best = f;
          bestN = n;
          tie = false;
        } else if (n > 0 && n === bestN) tie = true;
      }
      if (best >= 0 && !tie) {
        c.cap += dt * (8 + bestN * 7);
        c.capBy = best;
        if (c.cap >= 100) this.flip(c, best as FactionId);
      } else c.cap = Math.max(0, c.cap - dt * 12);
    }
  }

  private flip(c: CityRt, next: FactionId) {
    const prev = c.owner;
    c.owner = next;
    c.cap = 0;
    c.queue = [];
    c.progress = 0;
    c.dur = 0;
    if (this.replay) this.replay.events.push({ t: this.time, id: c.def.id, owner: next });
    const name = c.def.name[this.lang];
    if (next === this.human) {
      this.battleStat.cities++;
      this.toast(`${this.t.cityTaken}: ${name}`);
      this.audio.capture();
      if (!this.reduced) this.shake = Math.min(1, this.shake + 0.65);
      if (this.save.unlock("city_taken")) {
        const ach = ACHIEVEMENTS.find((a) => a.id === "city_taken");
        if (ach) this.toast(`${this.t.achGet}: ${ach.name[this.lang]}`);
      }
    } else if (prev === this.human) {
      this.lostCity = true;
      this.toast(`${this.t.cityLost}: ${name}`);
      this.audio.lost();
    }
    this.dockSig = "";
  }

  private produce(dt: number) {
    if (this.aliveCount() >= MAX_UNITS) return;
    for (const c of this.cities) {
      if (!c.active || c.owner < 0 || !c.queue.length) continue;
      const owner = c.owner as FactionId;
      const kind = c.queue[0]!;
      if (c.dur <= 0) c.dur = buildDur(kind, c.def.level);
      c.progress += dt;
      if (c.progress >= c.dur) {
        c.queue.shift();
        c.progress = 0;
        const nextKind = c.queue[0];
        c.dur = nextKind ? buildDur(nextKind, c.def.level) : 0;
        this.spawn(c, kind, owner);
        this.dockSig = "";
      }
    }
  }

  private spawn(c: CityRt, kind: Kind, owner: FactionId) {
    if (this.aliveCount() >= MAX_UNITS) return;
    let slot = -1;
    for (let i = 0; i < this.units.length; i++) if (!this.units[i]!.alive) {
      slot = i;
      break;
    }
    let u: Unit;
    if (slot < 0) {
      u = blankUnit();
      slot = this.units.length;
      this.units.push(u);
    } else u = this.units[slot]!;
    const fresh = blankUnit();
    Object.assign(u, fresh);
    u.alive = true;
    u.owner = owner;
    u.kind = kind;
    u.maxHp = BALANCE[kind].hp;
    u.hp = u.maxHp;
    u.id = this.nextId++;
    let ang = Math.random() * TAU;
    const enemy = this.nearestCity(c.def.x, c.def.y, (id) => id !== owner);
    if (enemy) ang = Math.atan2(enemy.def.y - c.def.y, enemy.def.x - c.def.x);
    ang += (Math.random() - 0.5) * 1.4;
    let x = c.def.x;
    let y = c.def.y;
    for (let k = 0; k < 10; k++) {
      const a = ang + (k - 4) * 0.35;
      const d = 34 + (k % 3) * 8;
      const nx = c.def.x + Math.cos(a) * d;
      const ny = c.def.y + Math.sin(a) * d;
      if (terrainAt(nx, ny) !== TERRAIN.sea) {
        x = nx;
        y = ny;
        break;
      }
    }
    u.x = x;
    u.y = y;
    u.px = x;
    u.py = y;
    this.idMap.set(u.id, slot);
  }

  private income(fid: FactionId) {
    let inc = 0;
    for (const c of this.cities) {
      if (c.active && c.owner === fid) inc += BALANCE.incomeBase + BALANCE.incomePerLevel * c.def.level;
    }
    const p = this.players[fid];
    if (p && !p.human && this.difficulty === 0) inc *= 0.78;
    return inc;
  }

  private refreshSupply() {
    const present = new Int16Array(COLS * ROWS * 4);
    for (const u of this.units) {
      if (!u.alive) continue;
      present[cellIndex(u.x, u.y) * 4 + u.owner]!++;
    }
    const factions = this.scenario?.factions ?? [];
    for (const fid of factions) {
      const reach = new Uint8Array(COLS * ROWS);
      const q: number[] = [];
      for (const c of this.cities) {
        if (!c.active || c.owner !== fid) continue;
        const i = cellIndex(c.def.x, c.def.y);
        if (!reach[i]) {
          reach[i] = 1;
          q.push(i);
        }
      }
      let qi = 0;
      while (qi < q.length) {
        const i = q[qi++]!;
        const cc = i % COLS;
        const rr = Math.floor(i / COLS);
        for (const d of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ]) {
          const nc = cc + d[0]!;
          const nr = rr + d[1]!;
          if (nc < 0 || nr < 0 || nc >= COLS || nr >= ROWS) continue;
          const ni = nr * COLS + nc;
          if (reach[ni] || isSeaIndex(ni)) continue;
          let enemy = 0;
          for (const f of factions) if (f !== fid) enemy += present[ni * 4 + f] ?? 0;
          const friend = present[ni * 4 + fid] ?? 0;
          if (enemy > 0 && friend === 0) continue;
          reach[ni] = 1;
          q.push(ni);
        }
      }
      const mine: Unit[] = [];
      for (const u of this.units) {
        if (!u.alive || u.owner !== fid) continue;
        u.supply = reach[cellIndex(u.x, u.y)] ? 0 : 2;
        if (u.supply === 0) mine.push(u);
      }
      let cap = 0;
      for (const c of this.cities) if (c.active && c.owner === fid) cap += c.def.supply;
      mine.sort((a, b) => this.distToOwn(b, fid) - this.distToOwn(a, fid));
      let over = mine.reduce((s, u) => s + BALANCE.use[u.kind], 0) - cap;
      if (over > 0) {
        for (const u of mine) {
          if (over <= 0) break;
          u.supply = 1;
          over -= BALANCE.use[u.kind];
        }
      }
    }
  }

  private distToOwn(u: Unit, fid: FactionId) {
    let best = 1e9;
    for (const c of this.cities) {
      if (!c.active || c.owner !== fid) continue;
      const d = hypot(u.x - c.def.x, u.y - c.def.y);
      if (d < best) best = d;
    }
    return best;
  }

  private aiAct(fid: FactionId) {
    const diff = this.difficulty;
    const now = this.time;
    const me: Unit[] = [];
    const enemies: Unit[] = [];
    for (const u of this.units) {
      if (!u.alive) continue;
      if (u.owner === fid) me.push(u);
      else if (this.canSee(fid, u)) enemies.push(u);
    }
    const reserved = new Set<number>();
    if (diff > 0) {
      for (const u of me) {
        if (u.hp > u.maxHp * 0.34 || now < u.aiLock) continue;
        if (!enemies.some((e) => hypot(e.x - u.x, e.y - u.y) < 120)) continue;
        const home = this.nearestCity(u.x, u.y, (id) => id === fid);
        if (!home || hypot(home.def.x - u.x, home.def.y - u.y) < 48) continue;
        this.orderUnits([u], home.def.x, home.def.y, -1);
        u.aiLock = now + 6;
        reserved.add(u.id);
      }
    }
    for (const c of this.cities) {
      if (!c.active || c.owner !== fid) continue;
      const threat = enemies.filter((e) => hypot(e.x - c.def.x, e.y - c.def.y) < 230);
      if (!threat.length && c.cap < 12) continue;
      const tStr = threat.reduce((s, u) => s + this.str(u), 0) + (c.cap > 20 ? 2 : 0);
      const local = me.filter((u) => hypot(u.x - c.def.x, u.y - c.def.y) < 210);
      const lStr = local.reduce((s, u) => s + this.str(u), 0);
      for (const u of local) reserved.add(u.id);
      if (tStr <= lStr * 0.85) continue;
      const idle = me
        .filter((u) => !reserved.has(u.id) && u.order === "idle" && now >= u.aiLock)
        .sort((a, b) => hypot(a.x - c.def.x, a.y - c.def.y) - hypot(b.x - c.def.x, b.y - c.def.y));
      const send = idle.slice(0, Math.min(8, Math.max(2, threat.length)));
      if (!send.length) continue;
      this.orderUnits(send, c.def.x, c.def.y, -1);
      for (const u of send) {
        reserved.add(u.id);
        u.aiLock = now + 5;
      }
    }
    this.aiBuild(fid);
    const attackers = me.filter((u) => !reserved.has(u.id) && u.order === "idle" && u.hp > u.maxHp * 0.5 && now >= u.aiLock);
    if (attackers.length < (diff === 0 ? 4 : 3)) return;
    const target = this.pickTarget(fid, attackers);
    if (!target) return;
    const need = this.threatAt(target, fid) * (diff === 2 ? 1.05 : 1.3) + 1.4;
    const sorted = attackers.slice().sort(
      (a, b) => hypot(a.x - target.def.x, a.y - target.def.y) - hypot(b.x - target.def.x, b.y - target.def.y),
    );
    const group: Unit[] = [];
    let acc = 0;
    for (const u of sorted) {
      group.push(u);
      acc += this.str(u);
      if (acc >= need && group.length >= 4) break;
      if (group.length >= (diff === 2 ? 16 : 12)) break;
    }
    const minRatio = diff === 2 ? 0.58 : diff === 1 ? 0.72 : 0.92;
    if (acc < need * minRatio) return;
    let via: { x: number; y: number } | undefined;
    if (diff > 0 && Math.random() < (diff === 2 ? 0.62 : 0.32)) {
      const src = this.nearestCity(target.def.x, target.def.y, (id) => id === fid);
      const ang = Math.atan2(target.def.y - (src?.def.y ?? group[0]!.y), target.def.x - (src?.def.x ?? group[0]!.x));
      const side = Math.random() < 0.5 ? 1 : -1;
      via = {
        x: clamp(target.def.x + Math.cos(ang + side * Math.PI * 0.5) * 150, 30, WORLD_W - 30),
        y: clamp(target.def.y + Math.sin(ang + side * Math.PI * 0.5) * 150, 30, WORLD_H - 30),
      };
      if (terrainAt(via.x, via.y) === TERRAIN.sea) via = undefined;
    }
    this.orderUnits(group, target.def.x, target.def.y, -1, via);
    for (const u of group) u.aiLock = now + 8;
  }

  private aiBuild(fid: FactionId) {
    const p = this.players[fid];
    if (!p) return;
    if (this.difficulty === 0 && Math.random() < 0.4) return;
    const cap = this.supplyCap(fid);
    const use = this.supplyUse(fid);
    if (use >= cap) return;
    const cities = this.cities.filter((c) => c.active && c.owner === fid && c.queue.length < 4);
    if (!cities.length) return;
    const focus = this.nearestCity(cities[0]!.def.x, cities[0]!.def.y, (id) => id !== fid);
    const wooded = focus ? terrainAt(focus.def.x, focus.def.y) === TERRAIN.forest : false;
    const heavies = this.countKind(fid, "heavy");
    const lights = this.countKind(fid, "light");
    const wantHeavy =
      !wooded &&
      this.difficulty > 0 &&
      p.points >= 3 &&
      use + 2 <= cap &&
      heavies < Math.max(1, lights / 4) &&
      Math.random() < 0.4;
    const kind: Kind = wantHeavy ? "heavy" : "light";
    if (p.points < BALANCE.cost[kind]) return;
    if (kind === "light" && use + 1 > cap) return;
    cities.sort((a, b) => b.def.level - a.def.level || a.queue.length - b.queue.length);
    this.enqueue(cities[0]!, kind);
  }

  private pickTarget(fid: FactionId, from: Unit[]) {
    let best: CityRt | null = null;
    let bestScore = -1e9;
    const ax = from.reduce((s, u) => s + u.x, 0) / from.length;
    const ay = from.reduce((s, u) => s + u.y, 0) / from.length;
    for (const c of this.cities) {
      if (!c.active || c.owner === fid) continue;
      const d = hypot(c.def.x - ax, c.def.y - ay);
      const g = this.threatAt(c, fid);
      let score = this.difficulty === 0 ? -d + (c.owner < 0 ? 80 : 0) : 110 - d * 0.05 - g * 7 + (c.owner < 0 ? 26 : 0);
      if (this.difficulty === 2 && (c.def.id === "dnipro" || c.def.id === "zaporizhzhia" || c.def.id === "kherson")) score += 14;
      if (score > bestScore) {
        bestScore = score;
        best = c;
      }
    }
    return best;
  }

  private threatAt(c: CityRt, fid: FactionId) {
    let s = c.owner >= 0 && c.owner !== fid ? 1.3 : 0;
    for (const u of this.units) {
      if (!u.alive || u.owner === fid) continue;
      if (!this.canSee(fid, u)) continue;
      if (hypot(u.x - c.def.x, u.y - c.def.y) < 110) s += this.str(u);
    }
    return s;
  }

  private str(u: Unit) {
    const base = u.kind === "heavy" ? 2.7 : 1;
    return base * clamp(u.hp / u.maxHp, 0.2, 1);
  }

  private canSee(viewer: FactionId, u: Unit) {
    if (!this.fogOn || u.owner === viewer) return true;
    for (const c of this.cities) {
      if (!c.active || c.owner !== viewer) continue;
      const vision = BALANCE.cityVision * (0.82 + 0.08 * c.def.level);
      if (hypot(c.def.x - u.x, c.def.y - u.y) <= vision) return true;
    }
    for (const f of this.units) {
      if (!f.alive || f.owner !== viewer) continue;
      const vision = f.kind === "heavy" ? 150 : BALANCE.unitVision;
      if (hypot(f.x - u.x, f.y - u.y) <= vision) return true;
    }
    return false;
  }

  private checkEnd(dt: number) {
    if (this.pending || this.ended || !this.scenario || this.time < 1.5) return;
    const sc = this.scenario;
    const own = this.cities.some((c) => c.active && c.owner === this.human);
    const fallen = sc.loseIfCityFalls.some((id) => this.cityById(id)?.owner !== this.human);
    if (!own || fallen) {
      this.pending = "lose";
      this.endDelay = 0.7;
      return;
    }
    const enemies = sc.factions.filter((f) => f !== this.human);
    const beaten = enemies.every((f) => !this.cities.some((c) => c.active && c.owner === f));
    if (sc.win === "hold") {
      const safe = sc.loseIfCityFalls.every((id) => this.cityById(id)?.owner === this.human);
      if (safe) this.hold += dt;
    }
    let win = false;
    if (sc.win === "eliminate") win = beaten;
    else if (sc.win === "capture") win = sc.capture.every((id) => this.cityById(id)?.owner === this.human) || beaten;
    else win = this.hold >= sc.holdSec || beaten;
    if (win) {
      this.pending = "win";
      this.endDelay = 0.65;
    }
  }

  private checkSwarm() {
    const lights = this.countKind(this.human, "light");
    const heavies = this.countKind(this.human, "heavy");
    if (lights >= 36 && this.save.unlock("swarm")) this.toastAch("swarm");
    if (heavies >= 8 && this.save.unlock("heavies")) this.toastAch("heavies");
  }

  private toastAch(id: string) {
    const ach = ACHIEVEMENTS.find((a) => a.id === id);
    if (ach) this.toast(`${this.t.achGet}: ${ach.name[this.lang]}`);
  }

  private orderUnits(list: Unit[], x: number, y: number, targetId: number, via?: { x: number; y: number }) {
    if (!list.length) return;
    const n = list.length;
    const src =
      n === 1
        ? { x: list[0]!.x, y: list[0]!.y }
        : {
            x: list.reduce((s, u) => s + u.x, 0) / n,
            y: list.reduce((s, u) => s + u.y, 0) / n,
          };
    let wps = findPath(src.x, src.y, via ? via.x : x, via ? via.y : y);
    if (via) wps = wps.concat(findPath(via.x, via.y, x, y).slice(1));
    list.forEach((u, i) => {
      const off = formation(i, n, u.kind === "heavy" ? 22 : 15);
      const path = wps.map((p) => ({ x: p.x, y: p.y }));
      if (!path.length) path.push({ x, y });
      path[path.length - 1] = { x: x + off.x, y: y + off.y };
      u.wps = path;
      u.wi = 0;
      u.order = "move";
      u.targetId = targetId;
      u.stuck = 0;
    });
    if (list.some((u) => u.owner === this.human)) {
      this.audio.order();
      if (this.tutStep === 3) this.tutStep = 4;
    }
  }

  private enqueue(c: CityRt, kind: Kind) {
    if (c.owner < 0) return false;
    const fid = c.owner;
    if (!this.players[fid]?.inPlay) return false;
    if (c.queue.length >= 5) return false;
    const cost = BALANCE.cost[kind];
    const p = this.players[fid]!;
    if (p.points + 1e-4 < cost) return false;
    p.points -= cost;
    c.queue.push(kind);
    if (c.queue.length === 1) {
      c.progress = 0;
      c.dur = buildDur(kind, c.def.level);
    }
    if (fid === this.human && this.tutStep === 1 && this.selCity) this.tutStep = 2;
    this.dockSig = "";
    return true;
  }

  private cancelQueue(c: CityRt) {
    if (c.owner < 0 || !c.queue.length) return;
    const kind = c.queue.pop()!;
    const p = this.players[c.owner];
    if (p) p.points += BALANCE.cost[kind];
    if (!c.queue.length) {
      c.progress = 0;
      c.dur = 0;
    }
    this.dockSig = "";
  }

  private begin(sc: Scenario) {
    this.scenario = sc;
    this.battle = true;
    this.ended = false;
    this.accounted = false;
    this.outcome = null;
    this.pending = null;
    this.playingReplay = false;
    this.human = sc.player;
    this.difficulty = sc.campaign || sc.world ? sc.ai : this.save.data.difficulty;
    this.fogOn = sc.fog;
    this.speed = 1;
    this.time = 0;
    this.hold = 0;
    this.lostCity = false;
    this.selected.clear();
    this.selCity = null;
    this.armed = false;
    this.tutStep = -1;
    this.particles = [];
    this.toasts = [];
    this.battleStat = { kills: 0, losses: 0, cities: 0, starved: 0 };
    this.units = [];
    this.idMap.clear();
    this.nextId = 1;
    this.explored.fill(0);
    this.cities = CITIES.map((def) => ({
      def,
      active: Object.prototype.hasOwnProperty.call(sc.owners, def.id),
      owner: (sc.owners[def.id] ?? -1) as OwnerId,
      cap: 0,
      capBy: -1 as OwnerId,
      queue: [],
      progress: 0,
      dur: 0,
    }));
    this.players = ([0, 1, 2, 3] as FactionId[]).map((id) => ({
      id,
      human: id === sc.player,
      points: sc.factions.includes(id) ? sc.points[id] : 0,
      aiCool: id === sc.player ? 99 : (sc.ai === 0 ? 10 : sc.ai === 1 ? 2.4 : 0.45) + id * 0.25,
      inPlay: sc.factions.includes(id),
    }));
    for (const sp of sc.spawns) {
      const city = this.cityById(sp.city);
      if (!city || !city.active) continue;
      for (let i = 0; i < sp.n; i++) this.spawn(city, sp.kind, sp.owner);
    }
    for (const u of this.units) u.age = 2;
    this.supplyAcc = 10;
    this.refreshSupply();
    if (this.fogOn) this.updateFog();
    this.recording = this.save.data.recordReplay;
    this.replay = {
      title: sc.title[this.lang],
      duration: 0,
      snaps: [],
      initCities: this.cities.filter((c) => c.active).map((c) => ({ id: c.def.id, owner: c.owner })),
      events: [],
    };
    this.recAcc = 0;
    this.frameCamera(true);
    this.screen = "brief";
    this.uiRev++;
    this.dockSig = "";
  }

  private fight() {
    if (!this.scenario) return;
    this.screen = "none";
    this.time = 0;
    this.hold = 0;
    this.pending = null;
    this.ended = false;
    for (const u of this.units) u.age = 0;
    if (this.scenario.tutorial && !this.save.data.tutorialDone) this.tutStep = 0;
    this.pushSnap();
    this.uiRev++;
    this.audio.unlock();
  }

  private finish(kind: "win" | "lose") {
    if (this.ended) return;
    this.ended = true;
    this.pending = null;
    this.outcome = kind;
    this.speed = 0;
    this.armed = false;
    if (this.replay) {
      this.pushSnap();
      this.replay.duration = Math.max(this.time, this.replay.snaps.at(-1)?.t ?? 0);
    }
    if (kind === "win") this.audio.win();
    else this.audio.defeat();
    this.screen = "end";
    this.uiRev++;
  }

  private commit() {
    if (this.accounted || !this.outcome || !this.scenario) return;
    this.accounted = true;
    const s = this.save.data;
    s.stats.kills += this.battleStat.kills;
    s.stats.losses += this.battleStat.losses;
    s.stats.cities += this.battleStat.cities;
    s.stats.time += this.time;
    s.stats.battles += 1;
    if (s.stats.battles >= 10) this.save.unlock("veteran");
    if (s.stats.cities >= 10) this.save.unlock("ten_cities");
    if (this.outcome === "win" && !this.lostCity) this.save.unlock("no_loss");
    if (this.scenario.campaign && this.outcome === "win") {
      if (!s.campaignCleared.includes(this.scenario.id)) s.campaignCleared.push(this.scenario.id);
      const idx = CAMPAIGN.findIndex((c) => c.id === this.scenario!.id);
      if (idx >= 0) s.campaignUnlocked = Math.max(s.campaignUnlocked, idx + 1);
      if (CAMPAIGN.every((c) => s.campaignCleared.includes(c.id))) this.save.unlock("campaign");
    }
    if (this.scenario.world) {
      if (this.outcome === "win") s.worldFront = Math.min(6, s.worldFront + 1);
      else s.worldFront = Math.max(0, s.worldFront - 1);
      if (s.worldFront >= 6) this.save.unlock("capital");
    }
    if (this.replay && s.recordReplay && this.replay.snaps.length > 1) this.save.saveReplay(this.replay);
    this.save.persist();
  }

  private updateFog() {
    this.visible.fill(0);
    const stamp = (x: number, y: number, radius: number) => {
      const cx = x / FOG_CELL;
      const cy = y / FOG_CELL;
      const r = radius / FOG_CELL;
      const x0 = clamp(Math.floor(cx - r), 0, FCOLS - 1);
      const x1 = clamp(Math.ceil(cx + r), 0, FCOLS - 1);
      const y0 = clamp(Math.floor(cy - r), 0, FROWS - 1);
      const y1 = clamp(Math.ceil(cy + r), 0, FROWS - 1);
      for (let yy = y0; yy <= y1; yy++) {
        for (let xx = x0; xx <= x1; xx++) {
          const dx = xx + 0.5 - cx;
          const dy = yy + 0.5 - cy;
          if (dx * dx + dy * dy <= r * r) this.visible[yy * FCOLS + xx] = 1;
        }
      }
    };
    for (const u of this.units) {
      if (!u.alive || u.owner !== this.human) continue;
      stamp(u.x, u.y, u.kind === "heavy" ? 150 : BALANCE.unitVision);
    }
    for (const c of this.cities) {
      if (!c.active || c.owner !== this.human) continue;
      stamp(c.def.x, c.def.y, BALANCE.cityVision * (0.82 + 0.08 * c.def.level));
    }
    const data = this.fogImg.data;
    for (let i = 0; i < this.visible.length; i++) {
      if (this.visible[i]) this.explored[i] = 1;
      const a = this.visible[i] ? 0 : this.explored[i] ? 88 : 168;
      const o = i * 4;
      data[o] = 6;
      data[o + 1] = 10;
      data[o + 2] = 8;
      data[o + 3] = a;
    }
    this.fogCtx.putImageData(this.fogImg, 0, 0);
  }

  private pushSnap() {
    if (!this.replay || !this.recording) return;
    const u: number[] = [];
    for (const unit of this.units) {
      if (!unit.alive) continue;
      u.push(unit.id, unit.owner, unit.kind === "heavy" ? 1 : 0, Math.round(unit.x), Math.round(unit.y), Math.round(unit.hp));
    }
    this.replay.snaps.push({ t: this.time, u });
    if (this.replay.snaps.length > 480) this.replay.snaps = this.replay.snaps.filter((_, i) => i % 2 === 0);
  }

  private paintTerrain(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = "#1a2820";
    ctx.fillRect(0, 0, WORLD_W, WORLD_H);
    ctx.strokeStyle = "rgba(255,255,255,0.035)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= WORLD_W; x += 160) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, WORLD_H);
      ctx.stroke();
    }
    for (let y = 0; y <= WORLD_H; y += 160) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(WORLD_W, y);
      ctx.stroke();
    }
    for (const h of HILLS) {
      const g = ctx.createRadialGradient(h.x, h.y, 10, h.x, h.y, Math.max(h.rx, h.ry));
      g.addColorStop(0, "#314238");
      g.addColorStop(1, "rgba(36,52,42,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(h.x, h.y, h.rx, h.ry, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(214, 206, 180, 0.18)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(h.x, h.y, h.rx * 0.62, h.ry * 0.62, 0, 0, TAU);
      ctx.stroke();
    }
    for (const f of FORESTS) {
      ctx.fillStyle = "#10241c";
      ctx.beginPath();
      ctx.ellipse(f.x, f.y, f.rx, f.ry, 0, 0, TAU);
      ctx.fill();
    }
    let seed = 1337;
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed & 2147483646) / 2147483647;
    };
    ctx.fillStyle = "#1d4a36";
    for (const f of FORESTS) {
      const n = Math.floor((f.rx * f.ry) / 380);
      for (let i = 0; i < n; i++) {
        const a = rnd() * TAU;
        const m = Math.sqrt(rnd());
        ctx.globalAlpha = 0.35 + rnd() * 0.5;
        ctx.fillRect(f.x + Math.cos(a) * f.rx * m, f.y + Math.sin(a) * f.ry * m, 3.2, 3.2);
      }
    }
    ctx.globalAlpha = 1;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#143848";
    ctx.lineWidth = 70;
    ctx.beginPath();
    RIVER.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
    ctx.stroke();
    ctx.strokeStyle = "#1f6f88";
    ctx.lineWidth = 16;
    ctx.stroke();
    ctx.strokeStyle = "#6d5d40";
    ctx.lineWidth = 10;
    for (const [ia, ib] of ROADS) {
      const a = CITY_BY_ID[ia];
      const b = CITY_BY_ID[ib];
      if (!a || !b) continue;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(232, 214, 170, 0.45)";
    ctx.lineWidth = 2;
    for (const [ia, ib] of ROADS) {
      const a = CITY_BY_ID[ia];
      const b = CITY_BY_ID[ib];
      if (!a || !b) continue;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.fillStyle = "#0c1c26";
    for (const poly of SEAS) {
      ctx.beginPath();
      poly.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
      ctx.closePath();
      ctx.fill();
    }
  }

  private draw() {
    const ctx = this.ctx;
    const dpr = this.dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#0c1210";
    ctx.fillRect(0, 0, this.viewW, this.viewH);
    const sh = this.reduced ? 0 : this.shake;
    const ox = (Math.random() - 0.5) * sh * 12;
    const oy = (Math.random() - 0.5) * sh * 12;
    ctx.translate(this.viewW / 2 + ox, this.viewH / 2 + oy);
    ctx.scale(this.zoom, this.zoom);
    ctx.translate(-this.camX, -this.camY);
    ctx.drawImage(this.terrain, 0, 0, WORLD_W, WORLD_H);
    if (this.fogOn && this.battle && !this.playingReplay) {
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(this.fogCanvas, 0, 0, WORLD_W, WORLD_H);
    }
    if (this.playingReplay && this.replay) this.drawReplay(ctx);
    else if (this.battle) {
      this.drawOrders(ctx);
      for (const c of this.cities) if (c.active) this.drawCity(ctx, c);
      for (const u of this.units) {
        if (!u.alive) continue;
        if (u.owner !== this.human && this.fogOn && !this.canSee(this.human, u)) continue;
        this.drawUnit(ctx, u);
      }
      this.drawParticles(ctx);
    } else this.drawDemo(ctx);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.drawLabels(ctx);
    if (this.drag?.box) {
      const x = Math.min(this.drag.sx, this.pointerX);
      const y = Math.min(this.drag.sy, this.pointerY);
      const w = Math.abs(this.pointerX - this.drag.sx);
      const h = Math.abs(this.pointerY - this.drag.sy);
      ctx.strokeStyle = "#d4a24c";
      ctx.fillStyle = "rgba(212,162,76,0.14)";
      ctx.lineWidth = 1.5;
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
    }
    if (this.gpOn && this.battle) {
      const p = this.worldToScreen(this.gpCursor.x, this.gpCursor.y);
      ctx.strokeStyle = "#d4a24c";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(p.x - 8, p.y - 8, 16, 16);
    }
    if (this.battle || this.playingReplay) this.drawMini();
  }

  private drawDemo(ctx: CanvasRenderingContext2D) {
    for (const c of CITIES) {
      const owner: OwnerId = c.x > 1900 ? 0 : c.x < 1200 ? 1 : -1;
      this.drawCity(ctx, {
        def: c,
        active: true,
        owner,
        cap: 0,
        capBy: -1,
        queue: [],
        progress: 0,
        dur: 0,
      });
    }
    for (let i = 0; i < ROADS.length; i++) {
      const pair = ROADS[i]!;
      const a = CITY_BY_ID[pair[0]];
      const b = CITY_BY_ID[pair[1]];
      if (!a || !b) continue;
      const t = (this.demoT * 0.045 + i / ROADS.length) % 1;
      const x = a.x + (b.x - a.x) * t;
      const y = a.y + (b.y - a.y) * t;
      const owner: FactionId = x > 1700 ? 0 : 1;
      ctx.beginPath();
      ctx.fillStyle = FACTIONS[owner].soft;
      ctx.arc(x, y, 14, 0, TAU);
      ctx.fill();
      ctx.beginPath();
      ctx.fillStyle = FACTIONS[owner].color;
      ctx.arc(x, y, 5.2, 0, TAU);
      ctx.fill();
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = "rgba(255,255,255,0.8)";
      ctx.stroke();
    }
  }

  private drawCity(ctx: CanvasRenderingContext2D, c: CityRt) {
    const R = Math.max(c.def.level === 3 ? 20 : 16, 13 / this.zoom);
    ctx.beginPath();
    ctx.fillStyle = "#101814";
    ctx.arc(c.def.x, c.def.y, R, 0, TAU);
    ctx.fill();
    ctx.lineWidth = 2.5 / this.zoom;
    ctx.strokeStyle = c.owner < 0 ? "#d7d0c2" : FACTIONS[c.owner].color;
    ctx.stroke();
    ctx.beginPath();
    ctx.fillStyle = c.owner < 0 ? "#d7d0c2" : FACTIONS[c.owner].color;
    ctx.arc(c.def.x, c.def.y, Math.max(3.4, 3 / this.zoom), 0, TAU);
    ctx.fill();
    if (c.cap > 2 && c.capBy >= 0) {
      ctx.beginPath();
      ctx.strokeStyle = FACTIONS[c.capBy].color;
      ctx.lineWidth = 3 / this.zoom;
      ctx.arc(c.def.x, c.def.y, R + 5 / this.zoom, -Math.PI / 2, -Math.PI / 2 + TAU * (c.cap / 100));
      ctx.stroke();
    }
  }

  private drawUnit(ctx: CanvasRenderingContext2D, u: Unit) {
    const base = BALANCE[u.kind].r;
    const floor = (u.kind === "light" ? 4.1 : 6.3) / this.zoom;
    const r = Math.max(base, floor);
    const col = FACTIONS[u.owner];
    if (this.zoom > 0.62) {
      ctx.beginPath();
      ctx.fillStyle = col.soft;
      ctx.arc(u.x, u.y, r * 2.15, 0, TAU);
      ctx.fill();
    }
    if (u.supply === 2) {
      ctx.beginPath();
      ctx.setLineDash([4 / this.zoom, 3 / this.zoom]);
      ctx.strokeStyle = "#ffb089";
      ctx.lineWidth = 1.4 / this.zoom;
      ctx.arc(u.x, u.y, r + 5 / this.zoom, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.beginPath();
    ctx.fillStyle = u.flash > 0 ? "#fff4ea" : col.color;
    ctx.arc(u.x, u.y, r, 0, TAU);
    ctx.fill();
    ctx.lineWidth = Math.max(1 / this.zoom, 1.3 / this.zoom);
    ctx.strokeStyle = "rgba(255,255,255,0.88)";
    ctx.stroke();
    if (u.kind === "heavy") {
      ctx.beginPath();
      ctx.fillStyle = "rgba(0,0,0,0.28)";
      ctx.arc(u.x, u.y, r * 0.42, 0, TAU);
      ctx.fill();
    }
    if (this.selected.has(u.id)) {
      ctx.beginPath();
      ctx.strokeStyle = "#f0d48a";
      ctx.lineWidth = 1.6 / this.zoom;
      ctx.arc(u.x, u.y, r + 4.5 / this.zoom, 0, TAU);
      ctx.stroke();
    }
    if (u.hp < u.maxHp * 0.98) {
      const p = clamp(u.hp / u.maxHp, 0, 1);
      ctx.beginPath();
      ctx.strokeStyle = "rgba(0,0,0,0.45)";
      ctx.lineWidth = 2 / this.zoom;
      ctx.arc(u.x, u.y, r + 3.2 / this.zoom, 0, TAU);
      ctx.stroke();
      ctx.beginPath();
      ctx.strokeStyle = p > 0.45 ? "#e7efe9" : "#ffb089";
      ctx.arc(u.x, u.y, r + 3.2 / this.zoom, -Math.PI / 2, -Math.PI / 2 + TAU * p);
      ctx.stroke();
    }
  }

  private drawOrders(ctx: CanvasRenderingContext2D) {
    ctx.setLineDash([7 / this.zoom, 6 / this.zoom]);
    ctx.strokeStyle = "rgba(212,162,76,0.8)";
    ctx.lineWidth = 1.4 / this.zoom;
    let n = 0;
    for (const id of this.selected) {
      if (n++ > 28) break;
      const u = this.unitById(id);
      if (!u || !u.alive || !u.wps.length || u.owner !== this.human) continue;
      ctx.beginPath();
      ctx.moveTo(u.x, u.y);
      for (let i = u.wi; i < u.wps.length; i++) ctx.lineTo(u.wps[i]!.x, u.wps[i]!.y);
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }

  private drawParticles(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  private drawReplay(ctx: CanvasRenderingContext2D) {
    const replay = this.replay;
    if (!replay) return;
    const ownerAt = (id: string) => {
      let o = replay.initCities.find((c) => c.id === id)?.owner ?? -1;
      for (const ev of replay.events) if (ev.id === id && ev.t <= this.playT) o = ev.owner;
      return o as OwnerId;
    };
    for (const init of replay.initCities) {
      const def = CITY_BY_ID[init.id];
      if (!def) continue;
      this.drawCity(ctx, {
        def,
        active: true,
        owner: ownerAt(init.id),
        cap: 0,
        capBy: -1,
        queue: [],
        progress: 0,
        dur: 0,
      });
    }
    const snaps = replay.snaps;
    if (!snaps.length) return;
    let i = 0;
    while (i < snaps.length - 1 && snaps[i + 1]!.t < this.playT) i++;
    const a = snaps[i]!;
    const b = snaps[Math.min(snaps.length - 1, i + 1)]!;
    const span = Math.max(0.001, b.t - a.t);
    const k = clamp((this.playT - a.t) / span, 0, 1);
    const mapB = new Map<number, number>();
    for (let p = 0; p < b.u.length; p += 6) mapB.set(b.u[p]!, p);
    for (let p = 0; p < a.u.length; p += 6) {
      const id = a.u[p]!;
      const q = mapB.get(id);
      const ax = a.u[p + 3]!;
      const ay = a.u[p + 4]!;
      const bx = q === undefined ? ax : b.u[q + 3]!;
      const by = q === undefined ? ay : b.u[q + 4]!;
      const u = blankUnit();
      u.alive = true;
      u.id = id;
      u.owner = a.u[p + 1] as FactionId;
      u.kind = a.u[p + 2] ? "heavy" : "light";
      u.x = ax + (bx - ax) * k;
      u.y = ay + (by - ay) * k;
      u.maxHp = BALANCE[u.kind].hp;
      u.hp = a.u[p + 5]!;
      this.drawUnit(ctx, u);
    }
  }

  private drawLabels(ctx: CanvasRenderingContext2D) {
    ctx.font = "600 12px Avenir Next, Segoe UI, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    const list: CityRt[] = [];
    if (this.playingReplay && this.replay) {
      for (const init of this.replay.initCities) {
        const def = CITY_BY_ID[init.id];
        if (!def) continue;
        let o = init.owner;
        for (const ev of this.replay.events) if (ev.id === init.id && ev.t <= this.playT) o = ev.owner;
        list.push({ def, active: true, owner: o as OwnerId, cap: 0, capBy: -1, queue: [], progress: 0, dur: 0 });
      }
    } else if (this.battle) {
      for (const c of this.cities) if (c.active) list.push(c);
    } else {
      for (const def of CITIES) {
        if (this.zoom < 0.5 && def.level < 2) continue;
        list.push({ def, active: true, owner: def.x > 1900 ? 0 : def.x < 1200 ? 1 : -1, cap: 0, capBy: -1, queue: [], progress: 0, dur: 0 });
      }
    }
    for (const c of list) {
      if (this.zoom < 0.42 && c.def.level < 3 && this.selCity !== c.def.id) continue;
      const p = this.worldToScreen(c.def.x, c.def.y);
      const R = Math.max(c.def.level === 3 ? 20 : 16, 13 / this.zoom) * this.zoom;
      if (p.x < -30 || p.y < -20 || p.x > this.viewW + 30 || p.y > this.viewH + 20) continue;
      const name = c.def.name[this.lang];
      ctx.fillStyle = "rgba(8,12,10,0.72)";
      ctx.fillText(name, p.x + 1, p.y + R + 6);
      ctx.fillStyle = "#e7efe9";
      ctx.fillText(name, p.x, p.y + R + 5);
    }
  }

  private drawMini() {
    const ctx = this.mctx;
    const w = this.mini.width;
    const h = this.mini.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#14211b";
    ctx.fillRect(0, 0, w, h);
    const X = (x: number) => (x / WORLD_W) * w;
    const Y = (y: number) => (y / WORLD_H) * h;
    ctx.strokeStyle = "#1f6f88";
    ctx.lineWidth = 2;
    ctx.beginPath();
    RIVER.forEach((p, i) => (i ? ctx.lineTo(X(p[0]), Y(p[1])) : ctx.moveTo(X(p[0]), Y(p[1]))));
    ctx.stroke();
    ctx.fillStyle = "#0c1c26";
    for (const poly of SEAS) {
      ctx.beginPath();
      poly.forEach((p, i) => (i ? ctx.lineTo(X(p[0]), Y(p[1])) : ctx.moveTo(X(p[0]), Y(p[1]))));
      ctx.closePath();
      ctx.fill();
    }
    const cities = this.playingReplay && this.replay
      ? this.replay.initCities.map((c) => ({ id: c.id, owner: c.owner }))
      : this.cities.filter((c) => c.active).map((c) => ({ id: c.def.id, owner: c.owner as number }));
    for (const c of cities) {
      const def = CITY_BY_ID[c.id];
      if (!def) continue;
      ctx.fillStyle = c.owner < 0 ? "#d7d0c2" : FACTIONS[c.owner as FactionId].color;
      ctx.beginPath();
      ctx.arc(X(def.x), Y(def.y), c.owner < 0 ? 2.5 : 3.4, 0, TAU);
      ctx.fill();
    }
    if (!this.playingReplay) {
      for (const u of this.units) {
        if (!u.alive) continue;
        if (u.owner !== this.human && this.fogOn && !this.canSee(this.human, u)) continue;
        ctx.fillStyle = FACTIONS[u.owner].color;
        ctx.fillRect(X(u.x) - 1, Y(u.y) - 1, u.kind === "heavy" ? 3 : 2, u.kind === "heavy" ? 3 : 2);
      }
    }
    const vw = this.viewW / this.zoom;
    const vh = this.viewH / this.zoom;
    ctx.strokeStyle = "#f0d48a";
    ctx.lineWidth = 1;
    ctx.strokeRect(X(this.camX - vw / 2), Y(this.camY - vh / 2), (vw / WORLD_W) * w, (vh / WORLD_H) * h);
  }

  private burst(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      if (this.particles.length > 160) this.particles.shift();
      const a = Math.random() * TAU;
      const s = 20 + Math.random() * 70;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.35 + Math.random() * 0.25,
        max: 0.55,
        color,
        r: 1.6 + Math.random() * 1.8,
      });
    }
  }

  private worldToScreen(x: number, y: number) {
    return { x: (x - this.camX) * this.zoom + this.viewW / 2, y: (y - this.camY) * this.zoom + this.viewH / 2 };
  }

  private screenToWorld(sx: number, sy: number) {
    return { x: (sx - this.viewW / 2) / this.zoom + this.camX, y: (sy - this.viewH / 2) / this.zoom + this.camY };
  }

  private clampCam() {
    const m = 120;
    const vw = this.viewW / (2 * this.zoom);
    const vh = this.viewH / (2 * this.zoom);
    if (vw * 2 >= WORLD_W + m) this.camX = WORLD_W / 2;
    else this.camX = clamp(this.camX, vw - m, WORLD_W - vw + m);
    if (vh * 2 >= WORLD_H + m) this.camY = WORLD_H / 2;
    else this.camY = clamp(this.camY, vh - m, WORLD_H - vh + m);
  }

  private frameCamera(battle: boolean) {
    if (!battle) {
      this.camX = WORLD_W * 0.62;
      this.camY = WORLD_H * 0.48;
      this.zoom = clamp(Math.max(this.viewW / WORLD_W, this.viewH / 1100), 0.42, 0.95);
      return;
    }
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let n = 0;
    for (const c of this.cities) {
      if (!c.active) continue;
      n++;
      minX = Math.min(minX, c.def.x);
      minY = Math.min(minY, c.def.y);
      maxX = Math.max(maxX, c.def.x);
      maxY = Math.max(maxY, c.def.y);
    }
    if (!n) {
      this.frameCamera(false);
      return;
    }
    minX -= 180;
    minY -= 160;
    maxX += 180;
    maxY += 180;
    this.camX = (minX + maxX) / 2;
    this.camY = (minY + maxY) / 2;
    const zw = (this.viewW * 0.84) / Math.max(80, maxX - minX);
    const zh = (this.viewH * 0.7) / Math.max(80, maxY - minY);
    this.zoom = clamp(Math.min(zw, zh), 0.32, 1.55);
    this.clampCam();
  }

  private localPoint(e: PointerEvent | WheelEvent | MouseEvent) {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  private onPointerDown = (e: PointerEvent) => {
    this.audio.unlock();
    const p = this.localPoint(e);
    this.pointerX = p.x;
    this.pointerY = p.y;
    this.pointers.set(e.pointerId, p);
    this.canvas.setPointerCapture?.(e.pointerId);
    if (this.pointers.size >= 2) {
      const pts = [...this.pointers.values()];
      const a = pts[0]!;
      const b = pts[1]!;
      const mx = (a.x + b.x) / 2;
      const my = (a.y + b.y) / 2;
      const w = this.screenToWorld(mx, my);
      this.pinch = { dist: hypot(a.x - b.x, a.y - b.y) || 1, zoom: this.zoom, wx: w.x, wy: w.y };
      this.drag = null;
      return;
    }
    const w = this.screenToWorld(p.x, p.y);
    this.drag = {
      id: e.pointerId,
      sx: p.x,
      sy: p.y,
      button: e.button,
      pointerType: e.pointerType,
      moved: false,
      box: false,
      camX: this.camX,
      camY: this.camY,
    };
    void w;
  };

  private onPointerMove = (e: PointerEvent) => {
    const p = this.localPoint(e);
    this.pointerX = p.x;
    this.pointerY = p.y;
    if (!this.pointers.has(e.pointerId)) return;
    this.pointers.set(e.pointerId, p);
    if (this.pointers.size >= 2 && this.pinch) {
      const pts = [...this.pointers.values()];
      const a = pts[0]!;
      const b = pts[1]!;
      const dist = hypot(a.x - b.x, a.y - b.y) || 1;
      const mx = (a.x + b.x) / 2;
      const my = (a.y + b.y) / 2;
      this.zoom = clamp(this.pinch.zoom * (dist / this.pinch.dist), 0.28, 2.35);
      this.camX = this.pinch.wx - (mx - this.viewW / 2) / this.zoom;
      this.camY = this.pinch.wy - (my - this.viewH / 2) / this.zoom;
      this.clampCam();
      return;
    }
    const drag = this.drag;
    if (!drag || drag.id !== e.pointerId) return;
    const dx = p.x - drag.sx;
    const dy = p.y - drag.sy;
    if (hypot(dx, dy) > 8) drag.moved = true;
    const pan = drag.pointerType === "touch" || drag.button === 1 || drag.button === 2;
    if (drag.moved && pan) {
      this.camX = drag.camX - dx / this.zoom;
      this.camY = drag.camY - dy / this.zoom;
      this.clampCam();
    } else if (drag.moved && drag.pointerType !== "touch" && drag.button === 0) drag.box = true;
  };

  private onPointerUp = (e: PointerEvent) => {
    const drag = this.drag;
    this.pointers.delete(e.pointerId);
    if (this.pointers.size < 2) this.pinch = null;
    if (!drag || drag.id !== e.pointerId) return;
    this.drag = null;
    if (!drag.moved) {
      const w = this.screenToWorld(drag.sx, drag.sy);
      this.onTap(w.x, w.y, drag.button, drag.pointerType);
    } else if (drag.box) this.boxSelect(drag.sx, drag.sy, this.pointerX, this.pointerY);
  };

  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    const p = this.localPoint(e);
    const before = this.screenToWorld(p.x, p.y);
    this.zoom = clamp(this.zoom * (e.deltaY < 0 ? 1.08 : 0.92), 0.28, 2.35);
    this.camX = before.x - (p.x - this.viewW / 2) / this.zoom;
    this.camY = before.y - (p.y - this.viewH / 2) / this.zoom;
    this.clampCam();
  };

  private onMini = (e: PointerEvent) => {
    if (e.type === "pointermove" && e.buttons === 0) return;
    const r = this.mini.getBoundingClientRect();
    const mx = clamp((e.clientX - r.left) / r.width, 0, 1);
    const my = clamp((e.clientY - r.top) / r.height, 0, 1);
    this.camX = mx * WORLD_W;
    this.camY = my * WORLD_H;
    this.clampCam();
  };

  private onTap(wx: number, wy: number, button: number, pointerType: string) {
    if (this.screen !== "none" || !this.battle || this.ended) return;
    const unit = this.pickUnit(wx, wy);
    const city = this.pickCity(wx, wy);
    const mine = this.selectedHuman();
    const right = button === 2;
    if (this.armed && mine.length) {
      this.issue(mine, wx, wy, unit, city);
      this.armed = false;
      this.dockSig = "";
      return;
    }
    if (right && mine.length) {
      this.issue(mine, wx, wy, unit, city);
      return;
    }
    if (pointerType !== "touch" && mine.length && button === 0 && !unit) {
      if (!city || hypot(city.def.x - wx, city.def.y - wy) > 26) {
        this.issue(mine, wx, wy, null, city);
        return;
      }
    }
    if (unit) {
      this.selectUnit(unit, this.keys.has("ShiftLeft") || this.keys.has("ShiftRight"));
      return;
    }
    if (city) {
      this.selected.clear();
      this.selCity = city.def.id;
      this.armed = false;
      if (this.tutStep === 0) this.tutStep = 1;
      this.dockSig = "";
      return;
    }
    this.selected.clear();
    this.selCity = null;
    this.armed = false;
    this.dockSig = "";
  }

  private issue(mine: Unit[], wx: number, wy: number, unit: Unit | null, city: CityRt | null) {
    if (unit && unit.owner !== this.human) this.orderUnits(mine, unit.x, unit.y, unit.id);
    else if (city) this.orderUnits(mine, city.def.x, city.def.y, -1);
    else this.orderUnits(mine, wx, wy, -1);
    this.dockSig = "";
  }

  private selectUnit(unit: Unit, shift: boolean) {
    if (this.fogOn && unit.owner !== this.human && !this.canSee(this.human, unit)) return;
    if (shift && this.selected.size) {
      const first = this.unitById([...this.selected][0] ?? -1);
      if (!first || first.owner !== unit.owner) return;
      if (this.selected.has(unit.id)) this.selected.delete(unit.id);
      else this.selected.add(unit.id);
    } else {
      this.selected.clear();
      this.selected.add(unit.id);
    }
    this.selCity = null;
    this.armed = false;
    if (unit.owner === this.human && this.tutStep === 2) this.tutStep = 3;
    this.dockSig = "";
  }

  private boxSelect(x0: number, y0: number, x1: number, y1: number) {
    const minX = Math.min(x0, x1);
    const maxX = Math.max(x0, x1);
    const minY = Math.min(y0, y1);
    const maxY = Math.max(y0, y1);
    this.selected.clear();
    for (const u of this.units) {
      if (!u.alive || u.owner !== this.human) continue;
      const p = this.worldToScreen(u.x, u.y);
      if (p.x >= minX && p.x <= maxX && p.y >= minY && p.y <= maxY) this.selected.add(u.id);
    }
    this.selCity = null;
    this.armed = false;
    this.dockSig = "";
  }

  private pickUnit(wx: number, wy: number) {
    const min = 16 / this.zoom;
    let best: Unit | null = null;
    let bestD = Infinity;
    for (const u of this.units) {
      if (!u.alive) continue;
      if (u.owner !== this.human && this.fogOn && !this.canSee(this.human, u)) continue;
      const r = Math.max(BALANCE[u.kind].r + 8, min);
      const d = hypot(u.x - wx, u.y - wy);
      if (d <= r && d < bestD) {
        best = u;
        bestD = d;
      }
    }
    return best;
  }

  private pickCity(wx: number, wy: number) {
    const min = 20 / this.zoom;
    let best: CityRt | null = null;
    let bestD = Infinity;
    for (const c of this.cities) {
      if (!c.active) continue;
      const r = Math.max(36, min);
      const d = hypot(c.def.x - wx, c.def.y - wy);
      if (d <= r && d < bestD) {
        best = c;
        bestD = d;
      }
    }
    return best;
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.code === "Space") e.preventDefault();
    this.keys.add(e.code);
    if (e.repeat || this.typing()) return;
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) e.preventDefault();
    if (e.code === "Escape") {
      if (this.screen === "none") {
        if (this.selected.size || this.selCity || this.armed) {
          this.selected.clear();
          this.selCity = null;
          this.armed = false;
          this.dockSig = "";
        } else this.screen = "pause";
      } else if (this.screen === "pause") this.screen = "none";
      else if (this.screen === "replay") this.stopReplay();
      else if (this.screen !== "end") this.back();
      this.uiRev++;
      return;
    }
    if (this.screen === "brief" && (e.code === "Enter" || e.code === "Space")) {
      this.fight();
      return;
    }
    if (this.screen === "none" && e.code === "Space") {
      this.speed = this.speed === 0 ? 1 : 0;
      return;
    }
    if (this.screen !== "none" || !this.battle || this.ended) return;
    if (e.code === "KeyM") {
      const mine = this.selectedHuman();
      if (mine.length) {
        this.armed = !this.armed;
        this.dockSig = "";
      }
    }
    const digit = /^Digit([1-9])$/.exec(e.code);
    if (digit) {
      const n = Number(digit[1]);
      if (e.ctrlKey || e.metaKey) {
        this.groups[n] = this.selectedHuman().map((u) => u.id);
        return;
      }
      if (this.selCity && (n === 1 || n === 2)) {
        const city = this.cityById(this.selCity);
        if (city && city.owner === this.human) this.enqueue(city, n === 1 ? "light" : "heavy");
        return;
      }
      const ids = this.groups[n] ?? [];
      const live = ids.map((id) => this.unitById(id)).filter((u): u is Unit => Boolean(u && u.alive && u.owner === this.human));
      if (!live.length) return;
      this.selected.clear();
      for (const u of live) this.selected.add(u.id);
      this.selCity = null;
      this.camX = live.reduce((s, u) => s + u.x, 0) / live.length;
      this.camY = live.reduce((s, u) => s + u.y, 0) / live.length;
      this.clampCam();
      this.dockSig = "";
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onClick = (e: MouseEvent) => {
    const node = e.target as HTMLElement | null;
    const el = node?.closest("[data-act]") as HTMLElement | null;
    if (!el || !this.host.contains(el)) return;
    e.preventDefault();
    this.audio.unlock();
    this.audio.ui();
    this.act(el.dataset.act || "", el.dataset.arg || "");
  };

  private onInput = (e: Event) => {
    const el = e.target as HTMLInputElement | HTMLTextAreaElement | null;
    if (!el) return;
    if (el.id === "raw") this.editorDraft = el.value;
    if (el.id === "vol") {
      this.save.data.volume = Number(el.value);
      this.audio.setVolume(this.save.data.volume);
      this.save.persist();
    }
    if (el.id === "scrub" && this.replay) {
      this.playT = Number(el.value) * this.replay.duration;
      this.replayOn = false;
    }
  };

  private act(act: string, arg: string) {
    const t = this.t;
    if (act === "menu-skirmish") {
      this.setupFfa = 2;
      this.setupSide = 0;
      this.screen = "setup";
    } else if (act === "menu-ffa") {
      this.setupFfa = 4;
      this.setupSide = 0;
      this.screen = "setup";
    } else if (act === "menu-camp") this.screen = "campaign";
    else if (act === "menu-world") this.screen = "world";
    else if (act === "menu-help") {
      this.returnScreen = this.screen === "pause" ? "pause" : "menu";
      this.screen = "help";
    } else if (act === "menu-set") {
      this.returnScreen = this.screen === "pause" ? "pause" : this.screen === "setup" ? "setup" : "menu";
      this.screen = "settings";
    } else if (act === "menu-ach") this.screen = "achievements";
    else if (act === "menu-edit") {
      this.editorMsg = "";
      this.screen = "editor";
    } else if (act === "menu-continue") this.screen = this.ended ? "end" : "none";
    else if (act === "back") this.back();
    else if (act === "ffa-n") this.setupFfa = arg === "3" ? 3 : arg === "2" ? 2 : 4;
    else if (act === "side") this.setupSide = Number(arg) as FactionId;
    else if (act === "diff") {
      const d = Number(arg);
      this.save.data.difficulty = (d === 0 || d === 2 ? d : 1) as Diff;
      this.save.persist();
    } else if (act === "fog") this.save.data.fog = !this.save.data.fog;
    else if (act === "lang") this.save.data.lang = arg === "en" ? "en" : "ru";
    else if (act === "sound") {
      this.save.data.sound = !this.save.data.sound;
      this.audio.setEnabled(this.save.data.sound);
    } else if (act === "record") this.save.data.recordReplay = !this.save.data.recordReplay;
    else if (act === "start-skirmish") {
      const factions: FactionId[] = this.setupFfa === 2 ? [0, 1] : this.setupFfa === 3 ? [0, 1, 2] : [0, 1, 2, 3];
      const side = factions.includes(this.setupSide) ? this.setupSide : 0;
      this.begin(skirmishScenario(this.setupFfa, side, this.save.data.fog));
    } else if (act === "camp") {
      const i = Number(arg);
      if (i <= this.save.data.campaignUnlocked && CAMPAIGN[i]) this.begin(CAMPAIGN[i]!);
    } else if (act === "world-fight") {
      if (this.save.data.worldFront < 6) this.begin(worldScenario(this.save.data.worldFront));
    } else if (act === "fight") this.fight();
    else if (act === "open-pause") this.screen = this.screen === "none" ? "pause" : "none";
    else if (act === "resume") this.screen = "none";
    else if (act === "to-menu") {
      this.commit();
      this.screen = "menu";
      if (!this.battle) this.frameCamera(false);
    } else if (act === "retry") {
      if (this.scenario) this.begin(this.scenario);
    } else if (act === "next") this.goNext();
    else if (act === "replay") this.startReplay();
    else if (act === "replay-toggle") this.replayOn = !this.replayOn;
    else if (act === "replay-rate") this.replayRate = Number(arg) || 1;
    else if (act === "replay-close") this.stopReplay();
    else if (act === "speed") this.speed = clamp(Number(arg) || 0, 0, 3);
    else if (act === "march") {
      if (this.selectedHuman().length) this.armed = !this.armed;
    } else if (act === "stop") {
      for (const u of this.selectedHuman()) {
        u.order = "idle";
        u.wps = [];
        u.targetId = -1;
        u.vx = 0;
        u.vy = 0;
      }
      this.armed = false;
    } else if (act === "build") {
      const city = this.selCity ? this.cityById(this.selCity) : null;
      if (city && city.owner === this.human) this.enqueue(city, arg === "heavy" ? "heavy" : "light");
    } else if (act === "cancel-q") {
      const city = this.selCity ? this.cityById(this.selCity) : null;
      if (city && city.owner === this.human) this.cancelQueue(city);
    } else if (act === "template") {
      this.editorDraft = JSON.stringify(this.publicScenario(templateScenario()), null, 2);
      this.editorMsg = "";
    } else if (act === "validate") {
      const parsed = this.parse(this.editorDraft);
      this.editorMsg = typeof parsed === "string" ? parsed : t.okJson;
    } else if (act === "save-sc") {
      const parsed = this.parse(this.editorDraft);
      if (typeof parsed === "string") this.editorMsg = parsed;
      else {
        this.save.data.custom.unshift({ name: parsed.title[this.lang], raw: this.editorDraft });
        this.save.data.custom = this.save.data.custom.slice(0, 12);
        this.save.persist();
        this.editorMsg = t.okJson;
      }
    } else if (act === "play-draft") {
      const parsed = this.parse(this.editorDraft);
      if (typeof parsed === "string") this.editorMsg = parsed;
      else this.begin(parsed);
    } else if (act === "play-custom") {
      const item = this.save.data.custom[Number(arg)];
      if (!item) return;
      const parsed = this.parse(item.raw);
      if (typeof parsed === "string") {
        this.editorMsg = parsed;
        this.screen = "editor";
      } else this.begin(parsed);
    } else if (act === "del-custom") {
      this.save.data.custom.splice(Number(arg), 1);
      this.save.persist();
    } else if (act === "tut-next") {
      if (this.tutStep >= 4) {
        this.tutStep = -1;
        this.save.data.tutorialDone = true;
        this.save.persist();
      } else if (this.tutStep === 0) this.tutStep = 1;
    } else if (act === "tut-skip") {
      this.tutStep = -1;
      this.save.data.tutorialDone = true;
      this.save.persist();
    }
    if (act === "diff" || act === "fog" || act === "lang" || act === "sound" || act === "record" || act === "side" || act === "ffa-n") {
      this.save.persist();
    }
    this.uiRev++;
    this.dockSig = "";
  }

  private back() {
    if (this.screen === "brief") {
      this.battle = false;
      this.scenario = null;
      this.units = [];
      this.screen = "menu";
      this.frameCamera(false);
      return;
    }
    if (this.screen === "help" || this.screen === "settings") {
      this.screen = this.returnScreen === "pause" || this.returnScreen === "setup" ? this.returnScreen : "menu";
      return;
    }
    if (this.screen === "pause") {
      this.screen = "none";
      return;
    }
    this.screen = "menu";
  }

  private goNext() {
    this.commit();
    if (!this.scenario) {
      this.screen = "menu";
      return;
    }
    if (this.scenario.campaign && this.outcome === "win") {
      const idx = CAMPAIGN.findIndex((c) => c.id === this.scenario!.id);
      const next = CAMPAIGN[idx + 1];
      if (next && idx + 1 <= this.save.data.campaignUnlocked) {
        this.begin(next);
        return;
      }
      this.screen = "campaign";
      return;
    }
    if (this.scenario.world) {
      this.screen = "world";
      return;
    }
    this.screen = "menu";
  }

  private startReplay() {
    if (!this.replay || this.replay.snaps.length < 1) {
      this.replay = this.save.loadReplay();
    }
    if (!this.replay || !this.replay.snaps.length) {
      this.toast(this.t.noBattle);
      return;
    }
    this.playingReplay = true;
    this.replayOn = true;
    this.playT = 0;
    this.replayRate = 1;
    this.screen = "replay";
    this.battle = true;
  }

  private stopReplay() {
    this.playingReplay = false;
    this.replayOn = false;
    this.screen = this.outcome ? "end" : "menu";
  }

  private gamepad(raw: number) {
    const pads = navigator.getGamepads?.();
    if (!pads) return;
    let pad: Gamepad | null = null;
    for (const p of pads) if (p) pad = p;
    if (!pad) return;
    this.gpOn = true;
    const ax = (i: number) => pad!.axes[i] ?? 0;
    const lx = Math.abs(ax(0)) > 0.18 ? ax(0) : 0;
    const ly = Math.abs(ax(1)) > 0.18 ? ax(1) : 0;
    if (lx || ly) {
      this.camX += (lx * 740 * raw) / this.zoom;
      this.camY += (ly * 740 * raw) / this.zoom;
      this.clampCam();
    }
    const rx = Math.abs(ax(2)) > 0.18 ? ax(2) : 0;
    const ry = Math.abs(ax(3)) > 0.18 ? ax(3) : 0;
    if (rx || ry) {
      this.gpCursor.x = clamp(this.gpCursor.x + rx * 520 * raw, 0, WORLD_W);
      this.gpCursor.y = clamp(this.gpCursor.y + ry * 520 * raw, 0, WORLD_H);
    }
    const pressed = (i: number) => Boolean(pad!.buttons[i]?.pressed);
    const edge = (i: number) => {
      const now = pressed(i);
      const was = this.gpPrev[i] ?? false;
      this.gpPrev[i] = now;
      return now && !was;
    };
    if (edge(9)) this.act(this.screen === "none" ? "open-pause" : "resume", "");
    if (edge(5)) this.speed = (this.speed + 1) % 4;
    if (this.screen !== "none" || !this.battle || this.ended) return;
    if (edge(0)) {
      const mine = this.selectedHuman();
      if (mine.length) this.issue(mine, this.gpCursor.x, this.gpCursor.y, this.pickUnit(this.gpCursor.x, this.gpCursor.y), this.pickCity(this.gpCursor.x, this.gpCursor.y));
      else this.onTap(this.gpCursor.x, this.gpCursor.y, 0, "mouse");
    }
    if (edge(1)) {
      this.selected.clear();
      this.selCity = null;
      this.armed = false;
      this.dockSig = "";
    }
  }

  private syncOverlay(force: boolean) {
    const sig = `${this.screen}|${this.lang}|${this.uiRev}|${this.editorMsg}|${this.setupFfa}|${this.setupSide}`;
    if (!force && sig === this.uiSig) return;
    this.uiSig = sig;
    const open = this.screen !== "none";
    this.overlay.classList.toggle("hidden", !open);
    this.overlay.classList.toggle("sheet", this.screen === "replay");
    if (!open) {
      this.overlay.innerHTML = "";
      return;
    }
    this.overlay.innerHTML = this.overlayHtml();
    const raw = this.overlay.querySelector<HTMLTextAreaElement>("#raw");
    if (raw) raw.value = this.editorDraft;
    const vol = this.overlay.querySelector<HTMLInputElement>("#vol");
    if (vol) vol.value = String(this.save.data.volume);
  }

  private overlayHtml() {
    const t = this.t;
    const lang = this.lang;
    if (this.screen === "menu") {
      return `<div class="card"><div class="lockup"><span class="dots" aria-hidden="true"><i class="d-r lg"></i><i class="d-b"></i><i class="d-u lg"></i></span><div><p class="kicker">${esc(t.kicker)}</p><h1>${esc(t.title)}</h1></div></div><p class="lede">${esc(t.tagline)}</p><div class="stack">${
        this.battle && !this.ended ? `<button type="button" class="btn btn-brass" data-act="menu-continue">${esc(t.continue)}</button>` : ""
      }<button type="button" class="btn btn-brass" data-act="menu-skirmish">${esc(t.skirmish)}</button><button type="button" class="btn" data-act="menu-ffa">${esc(t.ffa)}</button><button type="button" class="btn" data-act="menu-camp">${esc(t.campaign)}</button><button type="button" class="btn" data-act="menu-world">${esc(t.world)}</button><div class="row"><button type="button" class="btn btn-ghost grow" data-act="menu-help">${esc(t.help)}</button><button type="button" class="btn btn-ghost grow" data-act="menu-set">${esc(t.settings)}</button></div><div class="row"><button type="button" class="btn btn-ghost grow" data-act="menu-ach">${esc(t.achievements)}</button><button type="button" class="btn btn-ghost grow" data-act="menu-edit">${esc(t.editor)}</button></div></div></div>`;
    }
    if (this.screen === "help") {
      return `<div class="card wide help"><p class="kicker">${esc(t.help)}</p><h2>${esc(t.title)}</h2>${t.helpBody.map((p) => `<p>${esc(p)}</p>`).join("")}<button type="button" class="btn" data-act="back">${esc(t.back)}</button></div>`;
    }
    if (this.screen === "settings") {
      const d = this.save.data.difficulty;
      return `<div class="card"><p class="kicker">${esc(t.settings)}</p><h2>${esc(t.settings)}</h2><div class="field">${esc(t.language)}<div class="seg"><button type="button" class="btn ${lang === "ru" ? "is-on" : ""}" data-act="lang" data-arg="ru">RU</button><button type="button" class="btn ${lang === "en" ? "is-on" : ""}" data-act="lang" data-arg="en">EN</button></div></div><div class="field">${esc(t.difficulty)}<div class="seg">${this.diffButtons(d)}</div></div><div class="row"><button type="button" class="btn ${this.save.data.fog ? "is-on" : ""}" data-act="fog">${esc(t.fog)}</button><button type="button" class="btn ${this.save.data.sound ? "is-on" : ""}" data-act="sound">${esc(t.sound)}</button><button type="button" class="btn ${this.save.data.recordReplay ? "is-on" : ""}" data-act="record">${esc(t.record)}</button></div><label class="field">${esc(t.volume)}<input id="vol" type="range" min="0" max="1" step="0.01" /></label><button type="button" class="btn" data-act="back">${esc(t.back)}</button></div>`;
    }
    if (this.screen === "achievements") {
      return `<div class="card"><p class="kicker">${esc(t.achievements)}</p><h2>${esc(t.achievements)}</h2>${ACHIEVEMENTS.map((a) => {
        const on = this.save.data.achievements.includes(a.id);
        return `<div class="ach ${on ? "" : "off"}"><strong>${esc(a.name[lang])}</strong><span>${esc(a.desc[lang])}</span></div>`;
      }).join("")}<button type="button" class="btn" data-act="back">${esc(t.back)}</button></div>`;
    }
    if (this.screen === "campaign") {
      return `<div class="card"><p class="kicker">${esc(t.campaign)}</p><h2>${esc(t.campaign)}</h2><div class="stack">${CAMPAIGN.map((sc, i) => {
        const locked = i > this.save.data.campaignUnlocked;
        const cleared = this.save.data.campaignCleared.includes(sc.id);
        return `<button type="button" class="btn list-btn" data-act="camp" data-arg="${i}" ${locked ? "disabled" : ""}><span>${esc(sc.title[lang])}</span><small>${esc(locked ? t.locked : cleared ? t.cleared : sc.objective[lang])}</small></button>`;
      }).join("")}</div><button type="button" class="btn btn-ghost" data-act="back">${esc(t.back)}</button></div>`;
    }
    if (this.screen === "world") {
      const front = this.save.data.worldFront;
      const sectors = [0, 1, 2, 3, 4, 5].map((i) => {
        const sc = worldScenario(i);
        const cls = i < front ? "done" : i === front ? "now" : "";
        return `<div class="sector ${cls}"><i></i><div><strong>${esc(sc.title[lang])}</strong><div class="note">${esc(sc.objective[lang])}</div></div></div>`;
      }).join("");
      return `<div class="card"><p class="kicker">${esc(t.world)}</p><h2>${esc(t.world)}</h2><p class="lede">${esc(t.worldBlurb)}</p>${sectors}${
        front >= 6
          ? `<p class="note">${esc(t.worldDone)}</p>`
          : `<button type="button" class="btn btn-brass" data-act="world-fight">${esc(t.worldFight)}</button>`
      }<button type="button" class="btn btn-ghost" data-act="back">${esc(t.back)}</button></div>`;
    }
    if (this.screen === "setup") {
      const factions: FactionId[] = this.setupFfa >= 4 ? [0, 1, 2, 3] : this.setupFfa === 3 ? [0, 1, 2] : [0, 1];
      return `<div class="card"><p class="kicker">${esc(this.setupFfa === 2 ? t.skirmish : t.ffa)}</p><h2>${esc(t.side)}</h2><div class="seg">${factions
        .map((id) => `<button type="button" class="btn ${this.setupSide === id ? "is-on" : ""}" data-act="side" data-arg="${id}">${esc(FACTIONS[id].name[lang])}</button>`)
        .join("")}</div>${
        this.setupFfa > 2
          ? `<div class="field">${esc(t.players)}<div class="seg"><button type="button" class="btn ${this.setupFfa === 3 ? "is-on" : ""}" data-act="ffa-n" data-arg="3">${esc(t.three)}</button><button type="button" class="btn ${this.setupFfa === 4 ? "is-on" : ""}" data-act="ffa-n" data-arg="4">${esc(t.four)}</button></div></div>`
          : ""
      }<div class="field">${esc(t.difficulty)}<div class="seg">${this.diffButtons(this.save.data.difficulty)}</div></div><button type="button" class="btn ${this.save.data.fog ? "is-on" : ""}" data-act="fog">${esc(t.fog)}</button><div class="row"><button type="button" class="btn btn-ghost grow" data-act="back">${esc(t.back)}</button><button type="button" class="btn btn-brass grow" data-act="start-skirmish">${esc(t.fight)}</button></div></div>`;
    }
    if (this.screen === "brief" && this.scenario) {
      const sc = this.scenario;
      return `<div class="card"><p class="kicker">${esc(t.briefing)}</p><h2>${esc(sc.title[lang])}</h2><p class="lede">${esc(sc.brief[lang])}</p><p class="note"><strong>${esc(t.objective)}.</strong> ${esc(sc.objective[lang])}</p><div class="row"><button type="button" class="btn btn-ghost grow" data-act="back">${esc(t.back)}</button><button type="button" class="btn btn-brass grow" data-act="fight">${esc(t.fight)}</button></div></div>`;
    }
    if (this.screen === "pause") {
      return `<div class="card"><p class="kicker">${esc(t.pause)}</p><h2>${esc(this.scenario?.title[lang] ?? t.pause)}</h2><div class="stack"><button type="button" class="btn btn-brass" data-act="resume">${esc(t.resume)}</button><button type="button" class="btn" data-act="retry">${esc(t.retry)}</button><button type="button" class="btn" data-act="menu-set">${esc(t.settings)}</button><button type="button" class="btn btn-danger" data-act="to-menu">${esc(t.toMenu)}</button></div></div>`;
    }
    if (this.screen === "end" && this.scenario && this.outcome) {
      const win = this.outcome === "win";
      const idx = CAMPAIGN.findIndex((c) => c.id === this.scenario!.id);
      const hasNext = win && this.scenario.campaign && idx >= 0 && idx < CAMPAIGN.length - 1;
      const worldNext = this.scenario.world;
      return `<div class="card"><p class="kicker">${esc(win ? t.victory : t.defeat)}</p><h2>${esc(win ? t.victory : t.defeat)}</h2><p class="lede">${esc(this.scenario.title[lang])}</p><div class="meta"><div><span>${esc(t.kills)}</span><strong>${this.battleStat.kills}</strong></div><div><span>${esc(t.losses)}</span><strong>${this.battleStat.losses}</strong></div><div><span>${esc(t.citiesTaken)}</span><strong>${this.battleStat.cities}</strong></div><div><span>${esc(t.starved)}</span><strong>${this.battleStat.starved}</strong></div><div><span>${esc(t.battleTime)}</span><strong>${fmt(this.time)}</strong></div><div><span>${esc(t.supply)}</span><strong>${this.supplyUse(this.human)}/${this.supplyCap(this.human)}</strong></div></div><div class="stack"><button type="button" class="btn btn-brass" data-act="retry">${esc(t.retry)}</button>${
        this.replay && this.replay.snaps.length > 1 ? `<button type="button" class="btn" data-act="replay">${esc(t.replay)}</button>` : ""
      }${hasNext || worldNext ? `<button type="button" class="btn" data-act="next">${esc(t.next)}</button>` : ""}<button type="button" class="btn btn-ghost" data-act="to-menu">${esc(t.toMenu)}</button></div></div>`;
    }
    if (this.screen === "replay" && this.replay) {
      return `<div class="card"><p class="kicker">${esc(t.replayTitle)}</p><h2>${esc(this.replay.title)}</h2><label class="field"><span id="replay-time">${fmt(this.playT)} / ${fmt(this.replay.duration)}</span><input id="scrub" type="range" min="0" max="1" step="0.001" value="${this.replay.duration ? this.playT / this.replay.duration : 0}" /></label><div class="row"><button type="button" class="btn btn-brass" data-act="replay-toggle">${this.replayOn ? "II" : esc(t.play)}</button><button type="button" class="btn ${this.replayRate === 1 ? "is-on" : ""}" data-act="replay-rate" data-arg="1">1×</button><button type="button" class="btn ${this.replayRate === 2 ? "is-on" : ""}" data-act="replay-rate" data-arg="2">2×</button><button type="button" class="btn ${this.replayRate === 4 ? "is-on" : ""}" data-act="replay-rate" data-arg="4">4×</button><button type="button" class="btn btn-ghost" data-act="replay-close">${esc(t.exitReplay)}</button></div></div>`;
    }
    if (this.screen === "editor") {
      const saved = this.save.data.custom
        .map(
          (c, i) =>
            `<div class="row"><button type="button" class="btn grow" data-act="play-custom" data-arg="${i}">${esc(c.name)}</button><button type="button" class="btn btn-danger" data-act="del-custom" data-arg="${i}">${esc(t.del)}</button></div>`,
        )
        .join("");
      return `<div class="card wide"><p class="kicker">${esc(t.editor)}</p><h2>${esc(t.editor)}</h2><p class="note">${esc(t.editorHelp)}</p><textarea id="raw" class="raw"></textarea><p class="msg">${esc(this.editorMsg)}</p><div class="row"><button type="button" class="btn" data-act="template">${esc(t.template)}</button><button type="button" class="btn" data-act="validate">${esc(t.validate)}</button><button type="button" class="btn" data-act="save-sc">${esc(t.saveSc)}</button><button type="button" class="btn btn-brass" data-act="play-draft">${esc(t.play)}</button></div>${
        saved ? `<p class="kicker">${esc(t.saved)}</p>${saved}` : ""
      }<button type="button" class="btn btn-ghost" data-act="back">${esc(t.back)}</button></div>`;
    }
    return "";
  }

  private diffButtons(d: Diff) {
    const t = this.t;
    return [
      [0, t.easy],
      [1, t.normal],
      [2, t.hard],
    ]
      .map(([n, label]) => `<button type="button" class="btn ${d === n ? "is-on" : ""}" data-act="diff" data-arg="${n}">${esc(String(label))}</button>`)
      .join("");
  }

  private syncHud() {
    const show = this.screen === "none" && this.battle && !this.playingReplay;
    this.hud.classList.toggle("hidden", !show);
    if (!show) return;
    const t = this.t;
    const p = this.players[this.human];
    const fac = FACTIONS[this.human];
    const sw = this.elSide.querySelector(".swatch") as HTMLElement | null;
    const name = this.elSide.querySelector("strong");
    if (sw) sw.style.background = fac.color;
    if (name) name.textContent = fac.name[this.lang];
    const inc = this.income(this.human);
    this.elPoints.textContent = `${(p?.points ?? 0).toFixed(1)}  +${inc.toFixed(2)}`;
    const use = this.supplyUse(this.human);
    const cap = this.supplyCap(this.human);
    let cut = 0;
    for (const u of this.units) if (u.alive && u.owner === this.human && u.supply === 2) cut++;
    this.elSupply.textContent = cut ? `${use}/${cap}  ${t.enc} ${cut}` : `${use}/${cap}`;
    this.elSupply.classList.toggle("warn", use > cap || cut > 0);
    this.elTime.textContent = fmt(this.time);
    const menu = this.hud.querySelector<HTMLButtonElement>("[data-act=open-pause]");
    if (menu) menu.textContent = t.pause;
    this.hud.querySelectorAll<HTMLButtonElement>("[data-act=speed]").forEach((b) => {
      b.classList.toggle("is-on", Number(b.dataset.arg) === this.speed);
    });
    this.objectiveEl.textContent = this.scenario ? `${t.objective}: ${this.scenario.objective[this.lang]}` : "";
    this.syncDock();
    this.syncTutor();
    const bar = this.dock.querySelector<HTMLElement>("#buildbar");
    const city = this.selCity ? this.cityById(this.selCity) : null;
    if (bar && city && city.dur > 0) bar.style.width = `${clamp(city.progress / city.dur, 0, 1) * 100}%`;
  }

  private syncDock() {
    const ids = [...this.selected].join(",");
    const city = this.selCity ? this.cityById(this.selCity) : null;
    const sig = `${this.selCity}|${ids}|${this.armed}|${city?.queue.join("")}|${city?.owner}|${Math.floor((this.players[this.human]?.points ?? 0) * 2)}|${this.lang}|${this.tutStep}`;
    if (sig === this.dockSig) return;
    this.dockSig = sig;
    this.dock.innerHTML = `<div class="dock-card">${this.dockInner()}</div>`;
  }

  private dockInner() {
    const t = this.t;
    const lang = this.lang;
    const city = this.selCity ? this.cityById(this.selCity) : null;
    if (city) {
      const owner = city.owner < 0 ? t.neutral : FACTIONS[city.owner].name[lang];
      const mine = city.owner === this.human;
      const points = this.players[this.human]?.points ?? 0;
      const gar = this.units.filter((u) => u.alive && hypot(u.x - city.def.x, u.y - city.def.y) < BALANCE.captureRadius).length;
      return `<div><div class="who">${esc(city.def.name[lang])}</div><p>${esc(owner)} · ${esc(t.level)} ${city.def.level} · ${esc(t.supply)} ${city.def.supply} · ${esc(t.garrison)} ${gar}</p></div>${
        mine
          ? `<button type="button" class="btn btn-brass" data-act="build" data-arg="light" ${points < 1 ? "disabled" : ""}>${esc(t.light)}</button><button type="button" class="btn" data-act="build" data-arg="heavy" ${points < 3 ? "disabled" : ""}>${esc(t.heavy)}</button><button type="button" class="btn btn-ghost" data-act="cancel-q" ${city.queue.length ? "" : "disabled"}>${esc(t.cancelQ)}</button><div class="bar" title="${esc(t.queue)}"><span id="buildbar"></span></div>`
          : ""
      }`;
    }
    const sel = [...this.selected].map((id) => this.unitById(id)).filter((u): u is Unit => Boolean(u && u.alive));
    if (sel.length) {
      const mine = sel.every((u) => u.owner === this.human);
      const lights = sel.filter((u) => u.kind === "light").length;
      return `<div><div class="who">${esc(t.selected)} ${sel.length}</div><p>${lights} / ${sel.length - lights}${mine ? "" : ` · ${esc(FACTIONS[sel[0]!.owner].name[lang])}`}</p></div>${
        mine
          ? `<button type="button" class="btn btn-brass ${this.armed ? "is-on" : ""}" data-act="march">${esc(this.armed ? t.marching : t.march)}</button><button type="button" class="btn" data-act="stop">${esc(t.stop)}</button>`
          : ""
      }`;
    }
    return `<p>${esc(this.armed ? t.hintMarch : t.hintIdle)}</p>`;
  }

  private syncTutor() {
    const show = this.tutStep >= 0 && this.screen === "none";
    this.tutorEl.classList.toggle("hidden", !show);
    if (!show) return;
    const sig = `${this.tutStep}|${this.lang}`;
    if (sig === this.tutSig) return;
    this.tutSig = sig;
    const text = this.t.tut[this.tutStep] ?? "";
    const wait = this.tutStep === 0 || this.tutStep >= 4;
    this.tutorEl.innerHTML = `<p>${esc(text)}</p><div class="row">${
      wait ? `<button type="button" class="btn btn-brass" data-act="tut-next">${esc(this.tutStep >= 4 ? this.t.gotIt : this.t.nextTip)}</button>` : ""
    }<button type="button" class="btn btn-ghost" data-act="tut-skip">${esc(this.t.skip)}</button></div>`;
  }

  private fadeToasts(raw: number) {
    let dirty = false;
    for (const toast of this.toasts) toast.life -= raw;
    if (this.toasts.some((toast) => toast.life <= 0)) {
      this.toasts = this.toasts.filter((toast) => toast.life > 0);
      dirty = true;
    }
    const sig = this.toasts.map((toast) => toast.msg).join("|");
    if (dirty || sig !== this.toastSig) {
      this.toastSig = sig;
      this.toastsEl.innerHTML = this.toasts.map((toast) => `<div class="toast">${esc(toast.msg)}</div>`).join("");
    }
  }

  private toast(msg: string) {
    this.toasts.unshift({ msg, life: 3.4 });
    this.toasts = this.toasts.slice(0, 3);
    this.toastSig = "";
  }

  private parse(raw: string): Scenario | string {
    let data: unknown;
    try {
      data = JSON.parse(raw);
    } catch {
      return this.t.badJson;
    }
    if (!data || typeof data !== "object") return this.t.badJson;
    const o = data as Record<string, unknown>;
    const text = (v: unknown, fallback: string): Record<Lang, string> => {
      if (typeof v === "string") return { ru: v, en: v };
      if (v && typeof v === "object") {
        const r = v as Record<string, unknown>;
        const ru = typeof r.ru === "string" ? r.ru : fallback;
        const en = typeof r.en === "string" ? r.en : ru;
        return { ru, en };
      }
      return { ru: fallback, en: fallback };
    };
    if (!o.owners || typeof o.owners !== "object") return this.t.badJson;
    const owners: Record<string, OwnerId> = {};
    for (const [k, v] of Object.entries(o.owners as Record<string, unknown>)) {
      if (!CITY_BY_ID[k]) continue;
      const n = Number(v);
      if (n === -1 || n === 0 || n === 1 || n === 2 || n === 3) owners[k] = n as OwnerId;
    }
    if (!Object.keys(owners).length) return this.t.badJson;
    const factions = (Array.isArray(o.factions) ? o.factions : [0, 1])
      .map((n) => Number(n))
      .filter((n): n is FactionId => n === 0 || n === 1 || n === 2 || n === 3);
    if (!factions.length) factions.push(0, 1);
    let player = Number(o.player);
    if (!factions.includes(player as FactionId)) player = factions[0]!;
    const spawns: Spawn[] = [];
    if (Array.isArray(o.spawns)) {
      for (const item of o.spawns) {
        if (!item || typeof item !== "object") continue;
        const sp = item as Record<string, unknown>;
        const city = String(sp.city ?? "");
        const owner = Number(sp.owner);
        const kind: Kind = sp.kind === "heavy" ? "heavy" : "light";
        const n = clamp(Math.floor(Number(sp.n) || 0), 0, 24);
        if (!CITY_BY_ID[city] || !(owner === 0 || owner === 1 || owner === 2 || owner === 3)) continue;
        spawns.push({ city, owner: owner as FactionId, kind, n });
      }
    }
    const pointsIn = Array.isArray(o.points) ? o.points : [5, 5, 5, 5];
    const win = o.win === "capture" || o.win === "hold" ? o.win : "eliminate";
    const aiN = Number(o.ai);
    return {
      id: `custom-${Date.now()}`,
      title: text(o.title, "Custom"),
      brief: text(o.brief, ""),
      objective: text(o.objective, ""),
      win,
      capture: Array.isArray(o.capture) ? o.capture.map(String).filter((id) => CITY_BY_ID[id]) : [],
      holdSec: Math.max(0, Number(o.holdSec) || 0),
      loseIfCityFalls: Array.isArray(o.loseIfCityFalls) ? o.loseIfCityFalls.map(String).filter((id) => CITY_BY_ID[id]) : [],
      player: player as FactionId,
      factions,
      fog: Boolean(o.fog),
      points: [Number(pointsIn[0]) || 0, Number(pointsIn[1]) || 0, Number(pointsIn[2]) || 0, Number(pointsIn[3]) || 0],
      owners,
      spawns: spawns.length ? spawns : autoSpawns(owners),
      ai: (aiN === 0 || aiN === 2 ? aiN : 1) as Diff,
      tutorial: false,
      campaign: false,
      world: false,
    };
  }

  private publicScenario(sc: Scenario) {
    return {
      title: sc.title,
      brief: sc.brief,
      objective: sc.objective,
      win: sc.win,
      capture: sc.capture,
      holdSec: sc.holdSec,
      loseIfCityFalls: sc.loseIfCityFalls,
      player: sc.player,
      factions: sc.factions,
      fog: sc.fog,
      points: sc.points,
      owners: sc.owners,
      spawns: sc.spawns,
      ai: sc.ai,
    };
  }

  private cityById(id: string) {
    return this.cities.find((c) => c.def.id === id) ?? null;
  }

  private unitById(id: number) {
    const i = this.idMap.get(id);
    if (i === undefined) return null;
    const u = this.units[i];
    if (!u || u.id !== id) return null;
    return u;
  }

  private selectedHuman() {
    const out: Unit[] = [];
    for (const id of this.selected) {
      const u = this.unitById(id);
      if (u && u.alive && u.owner === this.human) out.push(u);
    }
    return out;
  }

  private nearestCity(x: number, y: number, test: (owner: OwnerId) => boolean) {
    let best: CityRt | null = null;
    let bestD = Infinity;
    for (const c of this.cities) {
      if (!c.active || !test(c.owner)) continue;
      const d = hypot(c.def.x - x, c.def.y - y);
      if (d < bestD) {
        bestD = d;
        best = c;
      }
    }
    return best;
  }

  private supplyCap(fid: FactionId) {
    let n = 0;
    for (const c of this.cities) if (c.active && c.owner === fid) n += c.def.supply;
    return n;
  }

  private supplyUse(fid: FactionId) {
    let n = 0;
    for (const u of this.units) if (u.alive && u.owner === fid) n += BALANCE.use[u.kind];
    return n;
  }

  private countKind(fid: FactionId, kind: Kind) {
    let n = 0;
    for (const u of this.units) if (u.alive && u.owner === fid && u.kind === kind) n++;
    return n;
  }

  private aliveCount() {
    let n = 0;
    for (const u of this.units) if (u.alive) n++;
    return n;
  }
}

export function mountFront(host: HTMLElement) {
  const game = new Front(host);
  return { destroy: () => game.destroy() };
}
