import { Building, PlayerState } from '../types/game';
import { ITEMS } from './items';
import { getSkillEffect } from './skills';

export interface LightSource {
  x: number;
  y: number;
  radius: number;
  color: string;
  intensity: number;
}

export class LightingEngine {
  // Returns ambient darkness alpha from 0 (day) to 0.88 (deep night) and color tint
  public getAmbient(timeOfDayMinutes: number): { alpha: number; color: string; isNight: boolean } {
    const hour = timeOfDayMinutes / 60;

    // 05:00 - 07:00 Dawn
    if (hour >= 5 && hour < 7) {
      const progress = (hour - 5) / 2;
      return {
        alpha: (1 - progress) * 0.75,
        color: 'rgba(28, 25, 43, ',
        isNight: false,
      };
    }
    // 07:00 - 18:00 Full Day
    if (hour >= 7 && hour < 18) {
      return {
        alpha: 0.0,
        color: 'rgba(10, 15, 30, ',
        isNight: false,
      };
    }
    // 18:00 - 20:30 Sunset
    if (hour >= 18 && hour < 20.5) {
      const progress = (hour - 18) / 2.5;
      return {
        alpha: progress * 0.85,
        color: 'rgba(24, 18, 48, ',
        isNight: progress > 0.6,
      };
    }
    // 20:30 - 05:00 Deep Night
    return {
      alpha: 0.86,
      color: 'rgba(8, 10, 24, ',
      isNight: true,
    };
  }

  // Render dynamic lighting mask over world viewport
  public renderLighting(
    ctx: CanvasRenderingContext2D,
    viewW: number,
    viewH: number,
    camX: number,
    camY: number,
    timeOfDayMinutes: number,
    player: PlayerState,
    buildings: Building[],
    tick: number
  ) {
    const ambient = this.getAmbient(timeOfDayMinutes);
    if (ambient.alpha <= 0.02) return; // Daylight, no dark mask needed

    // Offscreen / in-place darkness mask using radial gradients
    ctx.save();

    // Create an offscreen buffer canvas for the darkness mask
    const lightCanvas = document.createElement('canvas');
    lightCanvas.width = viewW;
    lightCanvas.height = viewH;
    const lCtx = lightCanvas.getContext('2d')!;

    // Fill with ambient darkness
    lCtx.fillStyle = `${ambient.color}${ambient.alpha})`;
    lCtx.fillRect(0, 0, viewW, viewH);

    // Punch out holes of light using destination-out
    lCtx.globalCompositeOperation = 'destination-out';

    // 1. Torch equipped in player active slot
    const lightMultiplier = 1 + getSkillEffect(player, 'lightRadius');
    const activeItemDef = player.activeTool ? ITEMS[player.activeTool] : null;
    if (activeItemDef && activeItemDef.lightRadius) {
      const px = player.x - camX;
      const py = player.y - camY;
      const flicker = Math.sin(tick * 0.15) * 4;
      const r = (activeItemDef.lightRadius + flicker) * lightMultiplier;

      const grad = lCtx.createRadialGradient(px, py, 15, px, py, r);
      grad.addColorStop(0, 'rgba(0,0,0,1)');
      grad.addColorStop(0.7, 'rgba(0,0,0,0.85)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');

      lCtx.fillStyle = grad;
      lCtx.beginPath();
      lCtx.arc(px, py, r, 0, Math.PI * 2);
      lCtx.fill();
    } else {
      // Subtle natural eyesight around player
      const px = player.x - camX;
      const py = player.y - camY;
      const r = 45 * lightMultiplier;
      const grad = lCtx.createRadialGradient(px, py, 10, px, py, r);
      grad.addColorStop(0, 'rgba(0,0,0,0.7)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      lCtx.fillStyle = grad;
      lCtx.beginPath();
      lCtx.arc(px, py, r, 0, Math.PI * 2);
      lCtx.fill();
    }

    // 2. Campfires in view
    buildings.forEach((b) => {
      if (b.type === 'campfire') {
        const bx = b.tileX * 32 + 16 - camX;
        const by = b.tileY * 32 + 16 - camY;

        // Check if inside screen bounds with padding
        if (bx >= -100 && bx <= viewW + 100 && by >= -100 && by <= viewH + 100) {
          const flicker = Math.sin(tick * 0.2 + b.tileX) * 6 + Math.cos(tick * 0.1) * 3;
          const r = 180 + flicker;

          const grad = lCtx.createRadialGradient(bx, by, 20, bx, by, r);
          grad.addColorStop(0, 'rgba(0,0,0,1)');
          grad.addColorStop(0.65, 'rgba(0,0,0,0.85)');
          grad.addColorStop(1, 'rgba(0,0,0,0)');

          lCtx.fillStyle = grad;
          lCtx.beginPath();
          lCtx.arc(bx, by, r, 0, Math.PI * 2);
          lCtx.fill();
        }
      }
    });

    // Draw darkness mask onto the main game canvas
    ctx.drawImage(lightCanvas, 0, 0);

    // Warm orange light tint on fire areas
    ctx.globalCompositeOperation = 'lighter';
    buildings.forEach((b) => {
      if (b.type === 'campfire') {
        const bx = b.tileX * 32 + 16 - camX;
        const by = b.tileY * 32 + 16 - camY;
        if (bx >= -100 && bx <= viewW + 100 && by >= -100 && by <= viewH + 100) {
          const warmGrad = ctx.createRadialGradient(bx, by, 5, bx, by, 120);
          warmGrad.addColorStop(0, 'rgba(249, 115, 22, 0.28)');
          warmGrad.addColorStop(1, 'rgba(249, 115, 22, 0)');
          ctx.fillStyle = warmGrad;
          ctx.beginPath();
          ctx.arc(bx, by, 120, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    });

    ctx.restore();
  }
}

export const lighting = new LightingEngine();
