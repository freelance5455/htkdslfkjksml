import React, { useRef } from 'react';
import { Flame, Hand, Snowflake, Sparkles, Shield, Swords, Video, Waves, Zap, ArrowUp } from 'lucide-react';
import { ELEMENT_META, SPELL_MAP } from '../config/magic';
import { CameraMode, ElementType, HudLayoutConfig } from '../types/gameTypes';

interface TouchControlsProps {
  visibleControls: boolean;
  hudLayout: HudLayoutConfig;
  selectedSpells: Record<ElementType, string>;
  spellCooldowns: Record<string, number>;
  nearbyPrompt: string | null;
  cameraMode: CameraMode;
  sprinting: boolean;
  onMove: (x: number, y: number) => void;
  onLook: (dx: number, dy: number) => void;
  onAttack: () => void;
  onAttackHold?: (active: boolean) => void;
  onJump: () => void;
  onDodge: () => void;
  onInteract: () => void;
  onToggleSprint: () => void;
  onToggleCamera: () => void;
  onCastElement: (el: ElementType) => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  visibleControls,
  hudLayout,
  selectedSpells,
  spellCooldowns,
  nearbyPrompt,
  cameraMode,
  sprinting,
  onMove,
  onLook,
  onAttack,
  onAttackHold,
  onJump,
  onDodge,
  onInteract,
  onToggleSprint,
  onToggleCamera,
  onCastElement,
}) => {
  // Independent pointer IDs & direct DOM knob ref so joystick drag NEVER triggers React re-renders
  const joyPointerId = useRef<number | null>(null);
  const joyCenter = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const knobRef = useRef<HTMLDivElement | null>(null);

  const lookPointerId = useRef<number | null>(null);
  const lookPrev = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lookDragDist = useRef(0);

  const maxJoyRadius = 46 * hudLayout.joystickScale;

  const setKnobTransform = (kx: number, ky: number) => {
    if (knobRef.current) {
      knobRef.current.style.transform = `translate3d(${kx}px, ${ky}px, 0)`;
    }
  };

  const updateJoystick = (cx: number, cy: number) => {
    const dx = cx - joyCenter.current.x;
    const dy = cy - joyCenter.current.y;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, maxJoyRadius);
    const angle = Math.atan2(dy, dx);
    const kx = Math.cos(angle) * clamped;
    const ky = Math.sin(angle) * clamped;
    setKnobTransform(kx, ky);
    onMove(kx / maxJoyRadius, ky / maxJoyRadius);
  };

  const handleJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (joyPointerId.current !== null) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    joyPointerId.current = e.pointerId;
    const rect = e.currentTarget.getBoundingClientRect();
    joyCenter.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    joyPointerId.current = null;
    setKnobTransform(0, 0);
    onMove(0, 0);
  };

  // Dedicated Right-Side Camera Rotation Zone (never moves player)
  const handleLookDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== null) return;
    if (e.pointerType === 'touch' && e.clientX < window.innerWidth * 0.35) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    lookPointerId.current = e.pointerId;
    lookPrev.current = { x: e.clientX, y: e.clientY };
    lookDragDist.current = 0;
  };

  const handleLookMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    const dx = e.clientX - lookPrev.current.x;
    const dy = e.clientY - lookPrev.current.y;
    lookDragDist.current += Math.hypot(dx, dy);
    lookPrev.current = { x: e.clientX, y: e.clientY };
    onLook(dx, dy);
  };

  const handleLookUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    lookPointerId.current = null;
    // Allow quick left-click on desktop canvas to attack while moving/jumping
    if (e.pointerType === 'mouse' && e.button === 0 && lookDragDist.current < 5) {
      onAttack();
    }
  };

  const elements: Array<{ el: ElementType; icon: React.ReactNode }> = [
    { el: 'fire', icon: <Flame className="w-5 h-5 text-orange-400" /> },
    { el: 'ice', icon: <Snowflake className="w-5 h-5 text-sky-300" /> },
    { el: 'water', icon: <Waves className="w-5 h-5 text-blue-400" /> },
    { el: 'lightning', icon: <Zap className="w-5 h-5 text-yellow-300" /> },
  ];

  const fireInstant = (fn: () => void) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    fn();
  };

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none">
      {/* Camera Drag Surface (Right-side on touch, full canvas drag on mouse) */}
      <div
        className="absolute inset-0 pointer-events-auto touch-none"
        onPointerDown={handleLookDown}
        onPointerMove={handleLookMove}
        onPointerUp={handleLookUp}
        onPointerCancel={handleLookUp}
      />

      {/* Contextual Interact Banner (Center-Bottom above controls) */}
      {nearbyPrompt && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 pointer-events-auto touch-none">
          <button
            type="button"
            onPointerDown={fireInstant(onInteract)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#111827]/95 border border-amber-400/50 text-amber-100 text-sm font-semibold shadow-lg hover:bg-amber-950/80 active:scale-95 transition-transform whitespace-nowrap touch-none"
          >
            <Hand className="w-4 h-4 text-amber-400" />
            <span>{nearbyPrompt}</span>
            <span className="text-xs text-amber-300/80 font-mono-num">[E]</span>
          </button>
        </div>
      )}

      {/* Left Virtual Movement Joystick */}
      {visibleControls && (
        <div
          className="absolute bottom-6 left-5 pointer-events-auto touch-none"
          style={{ transform: `scale(${hudLayout.joystickScale})`, transformOrigin: 'bottom left' }}
        >
          <div
            onPointerDown={handleJoyDown}
            onPointerMove={handleJoyMove}
            onPointerUp={handleJoyUp}
            onPointerCancel={handleJoyUp}
            className="relative w-32 h-32 rounded-full bg-slate-900/65 border-2 border-slate-400/35 flex items-center justify-center shadow-xl touch-none"
          >
            <div className="w-20 h-20 rounded-full border border-slate-400/20 pointer-events-none" />
            <div
              ref={knobRef}
              className="absolute w-14 h-14 rounded-full bg-amber-500/85 border-2 border-amber-200 shadow-lg pointer-events-none will-change-transform"
              style={{ transform: 'translate3d(0px, 0px, 0)' }}
            />
          </div>
          <div className="mt-1.5 flex items-center justify-center gap-2">
            <button
              type="button"
              onPointerDown={fireInstant(onToggleSprint)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold border transition-colors min-h-[38px] touch-none ${
                sprinting
                  ? 'bg-amber-500 text-slate-950 border-amber-300'
                  : 'bg-slate-900/85 text-slate-200 border-slate-600/60'
              }`}
            >
              {sprinting ? 'Running' : 'Sprint'}
            </button>
          </div>
        </div>
      )}

      {/* Right Action Cluster + Elemental Magic Row (Multi-touch enabled, instant pointerDown response!) */}
      <div
        className="absolute bottom-5 right-5 flex flex-col items-end gap-3 pointer-events-auto touch-none"
        style={{
          transform: `scale(${hudLayout.buttonsScale}) translateY(${hudLayout.elementalOffsetY}px)`,
          transformOrigin: 'bottom right',
        }}
      >
        {/* Elemental Magic Bar (4 distinct non-overlapping buttons) */}
        <div className="flex items-center gap-2">
          {elements.map(({ el, icon }) => {
            const spellId = selectedSpells[el];
            const spell = SPELL_MAP[spellId];
            const cd = spellCooldowns[spellId] || 0;
            const meta = ELEMENT_META[el];
            return (
              <button
                key={el}
                type="button"
                onPointerDown={fireInstant(() => onCastElement(el))}
                title={`${meta.label}: ${spell?.name || ''}`}
                className="relative w-12 h-12 min-w-[44px] min-h-[44px] rounded-xl border border-white/25 flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform touch-none"
                style={{ backgroundColor: meta.bg }}
              >
                {icon}
                <span className="text-[10px] font-medium text-white/90 leading-none mt-0.5">{meta.label}</span>
                {cd > 0.05 && (
                  <span className="absolute inset-0 rounded-xl bg-slate-950/80 flex items-center justify-center text-xs font-mono-num font-bold text-white pointer-events-none">
                    {cd.toFixed(1)}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Combat & Movement Action Buttons */}
        <div className="flex items-end gap-2.5">
          <button
            type="button"
            onPointerDown={fireInstant(onToggleCamera)}
            title="Switch 1st / 3rd Person Camera (V)"
            className="w-11 h-11 min-w-[44px] min-h-[44px] rounded-full bg-slate-900/90 border border-slate-500/50 flex flex-col items-center justify-center text-slate-100 active:scale-95 touch-none"
          >
            <Video className="w-4 h-4 text-sky-300" />
            <span className="text-[9px] leading-none mt-0.5">{cameraMode === 'first' ? '1st' : '3rd'}</span>
          </button>

          <button
            type="button"
            onPointerDown={fireInstant(onDodge)}
            title="Dodge Roll (Q)"
            className="w-12 h-12 min-w-[44px] min-h-[44px] rounded-full bg-slate-900/90 border border-emerald-400/50 flex flex-col items-center justify-center text-emerald-200 active:scale-95 touch-none"
          >
            <Shield className="w-4 h-4" />
            <span className="text-[9px] leading-none mt-0.5">Dodge</span>
          </button>

          <button
            type="button"
            onPointerDown={fireInstant(onJump)}
            title="Jump / Swim Up (Space)"
            className="w-12 h-12 min-w-[44px] min-h-[44px] rounded-full bg-slate-900/90 border border-sky-400/50 flex flex-col items-center justify-center text-sky-100 active:scale-95 touch-none"
          >
            <ArrowUp className="w-5 h-5" />
            <span className="text-[9px] leading-none mt-0.5">Jump</span>
          </button>

          <button
            type="button"
            onPointerDown={fireInstant(onInteract)}
            title="Interact / Gather / Mount (E)"
            className="w-12 h-12 min-w-[44px] min-h-[44px] rounded-full bg-slate-900/90 border border-amber-400/60 flex flex-col items-center justify-center text-amber-200 active:scale-95 touch-none"
          >
            <Sparkles className="w-4 h-4" />
            <span className="text-[9px] leading-none mt-0.5">Act</span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (onAttackHold) onAttackHold(true);
              else onAttack();
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onAttackHold?.(false);
            }}
            onPointerCancel={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onAttackHold?.(false);
            }}
            title="Weapon Attack (F or Hold)"
            className="w-16 h-16 min-w-[56px] min-h-[56px] rounded-full bg-red-700/95 border-2 border-amber-300/80 flex flex-col items-center justify-center text-white shadow-xl active:scale-95 touch-none"
          >
            <Swords className="w-6 h-6" />
            <span className="text-[10px] font-bold leading-none mt-0.5">Attack</span>
          </button>
        </div>
      </div>
    </div>
  );
};

