import React, { useEffect, useRef, useState } from 'react';
import { Hammer, MapPin, Shield, Sparkles, Swords, X } from 'lucide-react';
import { BOSSES } from '../config/bosses';
import { BUILDABLES, CRAFTING_RECIPES } from '../config/craftingAndBuilding';
import { CREATURES } from '../config/creatures';
import { ENEMIES } from '../config/enemies';
import { ITEM_MAP } from '../config/items';
import { ELEMENT_META, SKILL_TREE, SPELLS } from '../config/magic';
import { QUEST_MAP, QUESTS } from '../config/questsAndNpcs';
import { REGION_LIST, REGIONS } from '../config/regions';
import { WORLD_RADIUS } from '../world/TerrainMath';
import { getWorldMapCanvas, WORLD_MAP_PX } from '../world/WorldMapRenderer';
import {
  ElementType,
  EquipmentSlot,
  RegionId,
  SaveData,
  StructureType,
} from '../types/gameTypes';

const RARITY_COLOR: Record<string, string> = {
  Common: 'text-slate-300',
  Uncommon: 'text-emerald-400',
  Rare: 'text-sky-400',
  Epic: 'text-purple-400',
  Legendary: 'text-amber-400',
  Mythical: 'text-rose-400',
};

interface RpgPanelsProps {
  activeTab: 'inventory' | 'magic' | 'craft' | 'quests' | 'map';
  saveData: SaveData;
  playerPos?: { x: number; z: number };
  computedStats: { atk: number; def: number; mag: number; spd: number };
  onClose: () => void;
  onEquipItem: (itemId: string) => void;
  onUseConsumable: (itemId: string) => void;
  onSelectSpell: (element: ElementType, spellId: string) => void;
  onUnlockOrUpgradeSpell: (spellId: string) => void;
  onUpgradeSkill: (skillId: string) => void;
  onCraftRecipe: (recipeId: string) => void;
  onStartBuilding: (type: StructureType) => void;
  onClaimQuest: (questId: string) => void;
  onAcceptQuest: (questId: string) => void;
  onTeleportRegion: (regionId: RegionId) => void;
}

const InteractiveWorldMap: React.FC<{
  saveData: SaveData;
  playerPos: { x: number; z: number };
  onSelectRegion: (rid: RegionId) => void;
}> = ({ saveData, playerPos, onSelectRegion }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const size = 440;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const base = getWorldMapCanvas();
    const span = WORLD_RADIUS * 2;
    const toPx = (wx: number, wz: number) => ({
      x: ((wx + WORLD_RADIUS) / span) * size,
      y: ((wz + WORLD_RADIUS) / span) * size,
    });

    ctx.clearRect(0, 0, size, size);
    ctx.drawImage(base, 0, 0, WORLD_MAP_PX, WORLD_MAP_PX, 0, 0, size, size);

    // Region borders & labels
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const r of REGION_LIST) {
      const p = toPx(r.centerX, r.centerZ);
      const rad = (r.radius / span) * size * 0.72;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, rad, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      const label = r.name.split('&')[0].trim();
      ctx.font = 'bold 11px sans-serif';
      ctx.fillStyle = 'rgba(11, 18, 32, 0.78)';
      const w = ctx.measureText(label).width + 12;
      ctx.fillRect(p.x - w / 2, p.y - 24, w, 17);
      ctx.fillStyle = saveData.discoveredRegions.includes(r.id) ? '#fde68a' : '#cbd5e1';
      ctx.fillText(label, p.x, p.y - 15.5);
    }

    // Boss Markers
    for (const b of BOSSES) {
      const bp = toPx(b.arenaX, b.arenaZ);
      const defeated = saveData.defeatedBosses.includes(b.id);
      ctx.fillStyle = defeated ? '#10b981' : b.accentColor;
      ctx.strokeStyle = '#090d16';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(bp.x, bp.y, 5.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    // Live Player Diamond Marker
    const pp = toPx(playerPos.x, playerPos.z);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(pp.x, pp.y - 8);
    ctx.lineTo(pp.x + 6, pp.y);
    ctx.lineTo(pp.x, pp.y + 8);
    ctx.lineTo(pp.x - 6, pp.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }, [saveData, playerPos]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    const wx = nx * (WORLD_RADIUS * 2) - WORLD_RADIUS;
    const wz = ny * (WORLD_RADIUS * 2) - WORLD_RADIUS;

    let nearest = REGION_LIST[0].id;
    let best = Infinity;
    for (const r of Object.values(REGIONS)) {
      const d = Math.hypot(wx - r.centerX, wz - r.centerZ) / r.radius;
      if (d < best) {
        best = d;
        nearest = r.id;
      }
    }
    onSelectRegion(nearest);
  };

  return (
    <div className="flex flex-col items-center gap-2 bg-slate-950/75 border border-slate-800 rounded-xl p-3">
      <div className="relative rounded-xl overflow-hidden border border-amber-400/40 shadow-2xl">
        <canvas
          ref={canvasRef}
          width={size}
          height={size}
          onClick={handleCanvasClick}
          className="w-full max-w-[380px] aspect-square cursor-pointer block"
          title="Click any region on the map to Fast Travel"
        />
      </div>
      <div className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-slate-300">
        <span>White Diamond: You</span>
        <span>·</span>
        <span className="text-amber-300">Gold Square: Castles</span>
        <span>·</span>
        <span className="text-orange-300">Box: Ruins</span>
        <span>·</span>
        <span className="text-purple-300">Triangle: Crypts</span>
        <span>·</span>
        <span className="text-amber-200">Click any region to Fast Travel</span>
      </div>
    </div>
  );
};

export const RpgPanels: React.FC<RpgPanelsProps> = ({
  activeTab,
  saveData,
  playerPos = { x: saveData.position.x, z: saveData.position.z },
  computedStats,
  onClose,
  onEquipItem,
  onUseConsumable,
  onSelectSpell,
  onUnlockOrUpgradeSpell,
  onUpgradeSkill,
  onCraftRecipe,
  onStartBuilding,
  onClaimQuest,
  onAcceptQuest,
  onTeleportRegion,
}) => {
  const [craftSub, setCraftSub] = useState<'craft' | 'build'>('craft');
  const [questSub, setQuestSub] = useState<'quests' | 'bestiary'>('quests');
  const [bestiaryFilter, setBestiaryFilter] = useState<'creatures' | 'enemies' | 'bosses'>('creatures');

  const getCount = (id: string) => saveData.inventory.find((i) => i.itemId === id)?.quantity || 0;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-3 sm:p-6">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-2xl bg-[#0e1420] border border-slate-700/80 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-[#131b2b]">
          <h2 className="font-display text-lg sm:text-xl font-bold text-amber-100">
            {activeTab === 'inventory' && 'Inventory & Equipment'}
            {activeTab === 'magic' && 'Elemental Magic & Skill Tree'}
            {activeTab === 'craft' && 'Crafting & Realm Building'}
            {activeTab === 'quests' && 'Quests & Field Codex'}
            {activeTab === 'map' && 'World Map & Boss Seals'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto rpg-scroll p-4 sm:p-5 space-y-5">
          {/* ==================== INVENTORY & EQUIPMENT ==================== */}
          {activeTab === 'inventory' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-slate-300">Equipped Gear</h3>
                <div className="space-y-1.5 bg-slate-900/70 p-3 rounded-xl border border-slate-800">
                  {(['weapon', 'shield', 'helmet', 'chest', 'gloves', 'boots', 'ring', 'amulet'] as EquipmentSlot[]).map(
                    (slot) => {
                      const itemId = saveData.equipped[slot];
                      const item = itemId ? ITEM_MAP[itemId] : null;
                      return (
                        <div key={slot} className="flex items-center justify-between text-xs py-1 border-b border-slate-800/70 last:border-0">
                          <span className="capitalize text-slate-400">{slot}</span>
                          <span className={`font-medium truncate max-w-[160px] ${item ? RARITY_COLOR[item.rarity] : 'text-slate-600'}`}>
                            {item ? item.name : 'Empty'}
                          </span>
                        </div>
                      );
                    }
                  )}
                </div>

                <div className="bg-slate-900/70 p-3 rounded-xl border border-slate-800 grid grid-cols-2 gap-2 text-xs">
                  <div>Attack: <span className="font-mono-num text-amber-300 font-semibold">{computedStats.atk}</span></div>
                  <div>Defense: <span className="font-mono-num text-sky-300 font-semibold">{computedStats.def}</span></div>
                  <div>Magic: <span className="font-mono-num text-purple-300 font-semibold">{computedStats.mag}</span></div>
                  <div>Speed: <span className="font-mono-num text-emerald-300 font-semibold">{computedStats.spd.toFixed(1)}</span></div>
                  <div>Gold: <span className="font-mono-num text-yellow-400 font-semibold">{saveData.stats.gold}</span></div>
                  <div>Skill Pts: <span className="font-mono-num text-cyan-300 font-semibold">{saveData.stats.skillPoints}</span></div>
                </div>
              </div>

              <div className="md:col-span-2 space-y-3">
                <h3 className="text-sm font-semibold text-slate-300">Backpack ({saveData.inventory.length} items)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {saveData.inventory.map((entry) => {
                    const item = ITEM_MAP[entry.itemId];
                    if (!item) return null;
                    const isEquipped = item.slot && saveData.equipped[item.slot] === item.id;
                    const isConsumable = item.category === 'food' || item.category === 'potion';
                    return (
                      <div
                        key={entry.itemId}
                        className="flex items-center justify-between gap-2 p-3 rounded-xl bg-slate-900/80 border border-slate-800"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 text-sm font-semibold">
                            <span className={`truncate ${RARITY_COLOR[item.rarity]}`}>{item.name}</span>
                            <span className="text-xs font-mono-num text-slate-400">x{entry.quantity}</span>
                          </div>
                          <p className="text-xs text-slate-400 truncate">
                            {item.rarity} · {item.description}
                          </p>
                        </div>
                        {item.slot && (
                          <button
                            type="button"
                            onClick={() => onEquipItem(item.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 ${
                              isEquipped ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 hover:bg-slate-700 text-slate-100'
                            }`}
                          >
                            {isEquipped ? 'Equipped' : 'Equip'}
                          </button>
                        )}
                        {isConsumable && (
                          <button
                            type="button"
                            onClick={() => onUseConsumable(item.id)}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shrink-0"
                          >
                            Use
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ==================== ELEMENTAL MAGIC & SKILL TREE ==================== */}
          {activeTab === 'magic' && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-slate-200">Four Elements (16 Spells)</h3>
                  <span className="text-xs text-slate-400">
                    Level {saveData.stats.level} · Skill Points:{' '}
                    <strong className="font-mono-num text-amber-300">{saveData.stats.skillPoints}</strong>
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(['fire', 'ice', 'water', 'lightning'] as ElementType[]).map((el) => {
                    const meta = ELEMENT_META[el];
                    const elSpells = SPELLS.filter((s) => s.element === el);
                    return (
                      <div key={el} className="p-3.5 rounded-xl bg-slate-900/75 border border-slate-800 space-y-2.5">
                        <div className="text-sm font-bold" style={{ color: meta.color }}>
                          {meta.label} Magic
                        </div>
                        {elSpells.map((sp) => {
                          const unlocked = saveData.unlockedSpells.includes(sp.id);
                          const lvl = saveData.spellLevels[sp.id] || 0;
                          const equipped = saveData.selectedSpells[el] === sp.id;
                          return (
                            <div key={sp.id} className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80">
                              <div className="min-w-0">
                                <div className="text-xs font-semibold text-slate-100 flex items-center gap-2">
                                  <span>{sp.name}</span>
                                  {unlocked && <span className="font-mono-num text-amber-300">Lv.{lvl}</span>}
                                </div>
                                <div className="text-[11px] text-slate-400">
                                  Mana {sp.manaCost} · Power {sp.baseDamage} · Req Lv.{sp.unlockLevel}
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                {unlocked && (
                                  <button
                                    type="button"
                                    onClick={() => onSelectSpell(el, sp.id)}
                                    className={`px-2.5 py-1.5 rounded text-xs font-semibold ${
                                      equipped ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-200'
                                    }`}
                                  >
                                    {equipped ? 'Active' : 'Select'}
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => onUnlockOrUpgradeSpell(sp.id)}
                                  className="px-2.5 py-1.5 rounded text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white"
                                >
                                  {unlocked ? 'Upgrade' : 'Unlock'}
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-slate-200 mb-3">Hero Skill Tree</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {SKILL_TREE.map((node) => {
                    const rank = saveData.skillRanks[node.id] || 0;
                    const canBuy = rank < node.maxRank && saveData.stats.skillPoints >= node.costPerRank;
                    return (
                      <div key={node.id} className="p-3 rounded-xl bg-slate-900/75 border border-slate-800 flex flex-col justify-between gap-2">
                        <div>
                          <div className="flex items-center justify-between text-xs font-bold text-slate-100">
                            <span>{node.name}</span>
                            <span className="font-mono-num text-amber-300">
                              {rank}/{node.maxRank}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-1">{node.description}</p>
                        </div>
                        <button
                          type="button"
                          disabled={!canBuy}
                          onClick={() => onUpgradeSkill(node.id)}
                          className={`w-full py-1.5 rounded-lg text-xs font-semibold ${
                            canBuy
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          {rank >= node.maxRank ? 'Maxed' : 'Train (1 Pt)'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ==================== CRAFTING & BUILDING ==================== */}
          {activeTab === 'craft' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-1 bg-slate-900 rounded-lg w-fit">
                <button
                  type="button"
                  onClick={() => setCraftSub('craft')}
                  className={`px-4 py-2 rounded-md text-xs font-semibold ${
                    craftSub === 'craft' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'
                  }`}
                >
                  Crafting & Cooking
                </button>
                <button
                  type="button"
                  onClick={() => setCraftSub('build')}
                  className={`px-4 py-2 rounded-md text-xs font-semibold ${
                    craftSub === 'build' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'
                  }`}
                >
                  Build Structures
                </button>
              </div>

              {craftSub === 'craft' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {CRAFTING_RECIPES.map((rec) => {
                    const out = ITEM_MAP[rec.resultItemId];
                    const canCraft = rec.ingredients.every((ing) => getCount(ing.itemId) >= ing.count);
                    return (
                      <div key={rec.id} className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-slate-100">
                            {out?.name} {rec.resultCount > 1 ? `x${rec.resultCount}` : ''}
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            {rec.category} · Needs:{' '}
                            {rec.ingredients
                              .map((ing) => `${ITEM_MAP[ing.itemId]?.name} (${getCount(ing.itemId)}/${ing.count})`)
                              .join(', ')}
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={!canCraft}
                          onClick={() => onCraftRecipe(rec.id)}
                          className={`px-3.5 py-2 rounded-lg text-xs font-semibold shrink-0 flex items-center gap-1.5 ${
                            canCraft
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          <Hammer className="w-3.5 h-3.5" />
                          Craft
                        </button>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {BUILDABLES.map((b) => {
                    const canBuild = b.cost.every((c) => getCount(c.itemId) >= c.count);
                    return (
                      <div key={b.type} className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold text-slate-100">{b.name}</div>
                          <p className="text-xs text-slate-400">{b.description}</p>
                          <div className="text-xs text-amber-300/90 mt-1">
                            Cost: {b.cost.map((c) => `${ITEM_MAP[c.itemId]?.name} (${getCount(c.itemId)}/${c.count})`).join(', ')}
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={!canBuild}
                          onClick={() => onStartBuilding(b.type)}
                          className={`px-3.5 py-2 rounded-lg text-xs font-semibold shrink-0 ${
                            canBuild ? 'bg-sky-600 hover:bg-sky-500 text-white' : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          Place
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ==================== QUESTS & BESTIARY ==================== */}
          {activeTab === 'quests' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-1 bg-slate-900 rounded-lg w-fit">
                <button
                  type="button"
                  onClick={() => setQuestSub('quests')}
                  className={`px-4 py-2 rounded-md text-xs font-semibold ${
                    questSub === 'quests' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'
                  }`}
                >
                  Quests & Story
                </button>
                <button
                  type="button"
                  onClick={() => setQuestSub('bestiary')}
                  className={`px-4 py-2 rounded-md text-xs font-semibold ${
                    questSub === 'bestiary' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'
                  }`}
                >
                  Field Codex (10 / 40 / 8)
                </button>
              </div>

              {questSub === 'quests' ? (
                <div className="space-y-3">
                  {QUESTS.map((q) => {
                    const prog = saveData.quests[q.id];
                    const prereqDone = !q.prerequisiteQuestId || saveData.quests[q.prerequisiteQuestId]?.claimed;
                    return (
                      <div key={q.id} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <div className="text-sm font-bold text-amber-100">
                              {q.title}{' '}
                              <span className="text-xs font-normal text-slate-400">· {q.type} Quest</span>
                            </div>
                            <p className="text-xs text-slate-300 mt-0.5">{q.description}</p>
                          </div>
                          {prog?.claimed ? (
                            <span className="text-xs font-semibold text-emerald-400 shrink-0">Completed</span>
                          ) : prog?.completed ? (
                            <button
                              type="button"
                              onClick={() => onClaimQuest(q.id)}
                              className="px-3.5 py-2 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold shrink-0"
                            >
                              Claim Reward
                            </button>
                          ) : prog ? (
                            <span className="text-xs font-semibold text-sky-400 shrink-0">Active</span>
                          ) : prereqDone ? (
                            <button
                              type="button"
                              onClick={() => onAcceptQuest(q.id)}
                              className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shrink-0"
                            >
                              Accept
                            </button>
                          ) : (
                            <span className="text-xs text-slate-500 shrink-0">Locked</span>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
                          {q.objectives.map((obj) => {
                            const cur = prog?.counts[obj.id] || 0;
                            return (
                              <div key={obj.id} className="flex items-center justify-between px-2.5 py-1 rounded bg-slate-950/60 text-slate-300">
                                <span>{obj.description}</span>
                                <span className="font-mono-num text-amber-300">
                                  {cur}/{obj.requiredCount}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setBestiaryFilter('creatures')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                        bestiaryFilter === 'creatures' ? 'bg-sky-600 text-white' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      10 Peaceful Creatures
                    </button>
                    <button
                      type="button"
                      onClick={() => setBestiaryFilter('enemies')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                        bestiaryFilter === 'enemies' ? 'bg-red-600 text-white' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      40 Combat Enemies
                    </button>
                    <button
                      type="button"
                      onClick={() => setBestiaryFilter('bosses')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                        bestiaryFilter === 'bosses' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      8 Legendary Bosses
                    </button>
                  </div>

                  {bestiaryFilter === 'creatures' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {CREATURES.map((c) => (
                        <div key={c.id} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs flex justify-between gap-2">
                          <div>
                            <div className="font-bold text-sky-200">{c.name}</div>
                            <div className="text-slate-400 mt-0.5">{c.description}</div>
                          </div>
                          <div className="text-right font-mono-num text-emerald-300 shrink-0">
                            <div>HP {c.hp}</div>
                            <div className="text-slate-400">SPD {c.speed}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {bestiaryFilter === 'enemies' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {ENEMIES.map((e) => (
                        <div key={e.id} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs flex justify-between gap-2">
                          <div>
                            <div className="font-bold text-red-200">
                              #{e.index} {e.name}
                            </div>
                            <div className="text-slate-400">
                              Weak: {e.weakness} · Resists: {e.resistance}
                            </div>
                          </div>
                          <div className="text-right font-mono-num text-slate-300 shrink-0">
                            <div>HP {e.hp}</div>
                            <div>DMG {e.damage}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {bestiaryFilter === 'bosses' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {BOSSES.map((b) => {
                        const defeated = saveData.defeatedBosses.includes(b.id);
                        return (
                          <div key={b.id} className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                            <div className="flex items-center justify-between font-bold text-amber-200">
                              <span>
                                {b.order}. {b.name} — {b.title}
                              </span>
                              <span className={defeated ? 'text-emerald-400' : 'text-slate-400'}>
                                {defeated ? 'Defeated' : `HP ${b.hp}`}
                              </span>
                            </div>
                            <p className="text-slate-400">{b.description}</p>
                            <div className="text-slate-300">
                              Arena: ({b.arenaX}, {b.arenaZ}) · Weakness: {b.weakness}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ==================== WORLD MAP & BOSS SEALS ==================== */}
          {activeTab === 'map' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
                <div>
                  Regional Boss Seals Broken:{' '}
                  <strong className="font-mono-num text-amber-300">
                    {saveData.defeatedBosses.filter((id) => id !== 'boss_lord_of_darkness').length} / 7
                  </strong>
                </div>
                <div className="text-slate-400">
                  Defeat all 7 Regional Bosses to unlock the Lord of Darkness at (0, 675).
                </div>
              </div>

              <InteractiveWorldMap
                saveData={saveData}
                playerPos={playerPos}
                onSelectRegion={(rid) => {
                  onTeleportRegion(rid);
                  onClose();
                }}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {REGION_LIST.map((r) => {
                  const discovered = saveData.discoveredRegions.includes(r.id);
                  const boss = BOSSES.find((b) => b.region === r.id);
                  const bossDefeated = boss ? saveData.defeatedBosses.includes(boss.id) : false;
                  return (
                    <div key={r.id} className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 text-sm font-bold text-slate-100">
                          <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: r.groundColor }} />
                          <span className="truncate">{r.name}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{r.subtitle}</p>
                        <div className="text-[11px] text-slate-300 mt-1 font-mono-num">
                          Rec. Lv.{r.recommendedLevel} · ({r.centerX}, {r.centerZ}){' '}
                          {boss && `· Boss: ${boss.name} (${bossDefeated ? 'Defeated' : 'Active'})`}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          onTeleportRegion(r.id);
                          onClose();
                        }}
                        className="px-3 py-2 rounded-lg text-xs font-semibold shrink-0 flex items-center gap-1 bg-sky-600 hover:bg-sky-500 text-white"
                      >
                        <MapPin className="w-3.5 h-3.5" />
                        {discovered ? 'Travel' : 'Scout'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
