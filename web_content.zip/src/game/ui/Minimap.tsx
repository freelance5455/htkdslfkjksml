import React, { useEffect, useRef } from 'react';
import { HudSnapshot } from '../GameEngine';
import { WORLD_RADIUS } from '../world/TerrainMath';
import { getWorldMapCanvas, WORLD_MAP_PX } from '../world/WorldMapRenderer';

interface MinimapProps {
  hud: HudSnapshot;
  onOpenMap: () => void;
}

export const Minimap: React.FC<MinimapProps> = ({ hud, onOpenMap }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 124;
    const half = size / 2;
    const viewRadiusWorld = 165; // 165m visible radius around player
    const scale = half / viewRadiusWorld;

    const baseMap = getWorldMapCanvas();
    const span = WORLD_RADIUS * 2;
    const px = hud.position.x;
    const pz = hud.position.z;

    const centerMapX = ((px + WORLD_RADIUS) / span) * WORLD_MAP_PX;
    const centerMapZ = ((pz + WORLD_RADIUS) / span) * WORLD_MAP_PX;
    const srcHalf = (viewRadiusWorld / span) * WORLD_MAP_PX;

    ctx.clearRect(0, 0, size, size);
    ctx.save();
    ctx.beginPath();
    ctx.arc(half, half, half - 2, 0, Math.PI * 2);
    ctx.clip();

    // Dark ocean backdrop if near edge
    ctx.fillStyle = '#0c1c2e';
    ctx.fillRect(0, 0, size, size);

    // Draw topographic terrain slice centered on player
    ctx.drawImage(
      baseMap,
      centerMapX - srcHalf,
      centerMapZ - srcHalf,
      srcHalf * 2,
      srcHalf * 2,
      0,
      0,
      size,
      size
    );

    // Subtle dark vignette for crisp entity dot legibility
    ctx.fillStyle = 'rgba(7, 11, 20, 0.22)';
    ctx.fillRect(0, 0, size, size);

    // Subtle radar rings
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(half, half, 26, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(half, half, 50, 0, Math.PI * 2);
    ctx.stroke();

    const drawDot = (wx: number, wz: number, color: string, r: number, outline = false) => {
      const mx = half + (wx - px) * scale;
      const my = half + (wz - pz) * scale;
      if (Math.hypot(mx - half, my - half) > half - 5) return;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(mx, my, r, 0, Math.PI * 2);
      ctx.fill();
      if (outline) {
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    };

    for (const c of hud.fpsEntities.creatures) drawDot(c.x, c.z, '#38bdf8', 2.4, true);
    for (const n of hud.fpsEntities.npcs) drawDot(n.x, n.z, '#facc15', 3.0, true);
    for (const e of hud.fpsEntities.enemies) drawDot(e.x, e.z, '#ef4444', 2.5, true);
    for (const b of hud.fpsEntities.bosses) {
      if (!b.defeated) drawDot(b.x, b.z, '#d946ef', 4.2, true);
    }

    // Player directional chevron
    ctx.save();
    ctx.translate(half, half);
    ctx.rotate(-hud.position.yaw);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(5, 5.5);
    ctx.lineTo(0, 3);
    ctx.lineTo(-5, 5.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    ctx.restore();

    // Outer circular compass bezel + N/E/S/W
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.55)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(half, half, half - 1.5, 0, Math.PI * 2);
    ctx.stroke();

    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fde68a';
    ctx.fillText('N', half, 9);
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText('S', half, size - 9);
    ctx.fillText('W', 9, half);
    ctx.fillText('E', size - 9, half);
  }, [hud]);

  return (
    <button
      type="button"
      onClick={onOpenMap}
      title="Open Interactive World Map"
      className="relative flex flex-col items-center rounded-2xl overflow-hidden border border-amber-400/40 bg-[#0b1220] p-1 shadow-xl active:scale-95 transition-transform"
    >
      <canvas ref={canvasRef} width={124} height={124} className="block w-24 h-24 sm:w-[116px] sm:h-[116px]" />
      <span className="mt-0.5 text-[10px] font-mono-num text-amber-100/90">
        {Math.round(hud.position.x)}, {Math.round(hud.position.z)}
      </span>
    </button>
  );
};
