import React, { useState } from 'react';
import { Download, Globe, Save, Send, Trash2, Upload, User, Wifi, WifiOff, X } from 'lucide-react';
import { ITEM_MAP } from '../config/items';
import { NPCS, QUEST_MAP } from '../config/questsAndNpcs';
import {
  ChatMessage,
  GameSettings,
  GraphicsQuality,
  PlayerAppearance,
  RemotePlayer,
  SaveData,
} from '../types/gameTypes';
import { usePWAInstall } from './usePWAInstall';

interface CharacterModalProps {
  appearance: PlayerAppearance;
  onSave: (a: PlayerAppearance) => void;
  onClose: () => void;
}

export const CharacterCustomizerModal: React.FC<CharacterModalProps> = ({ appearance, onSave, onClose }) => {
  const [draft, setDraft] = useState<PlayerAppearance>({ ...appearance });

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-lg rounded-2xl bg-[#0e1420] border border-slate-700/80 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-[#131b2b]">
          <h2 className="font-display text-lg font-bold text-amber-100 flex items-center gap-2">
            <User className="w-5 h-5 text-amber-400" />
            Customize Hero
          </h2>
          <button type="button" onClick={onClose} className="p-2 rounded-lg bg-slate-800 text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Hero Name</label>
            <input
              type="text"
              maxLength={18}
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Hair Style</label>
              <select
                value={draft.hairStyle}
                onChange={(e) => setDraft({ ...draft, hairStyle: e.target.value as PlayerAppearance['hairStyle'] })}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100"
              >
                <option value="short">Short</option>
                <option value="long">Long</option>
                <option value="ponytail">Ponytail</option>
                <option value="hooded">Ranger Hood</option>
                <option value="crown">Royal Crown</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Face Expression</label>
              <select
                value={draft.faceStyle}
                onChange={(e) => setDraft({ ...draft, faceStyle: e.target.value as PlayerAppearance['faceStyle'] })}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100"
              >
                <option value="determined">Determined</option>
                <option value="calm">Calm</option>
                <option value="scarred">Battle-Hardened</option>
                <option value="mystic">Mystic Eyes</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Skin</label>
              <input type="color" value={draft.skinColor} onChange={(e) => setDraft({ ...draft, skinColor: e.target.value })} className="w-full h-9 rounded cursor-pointer bg-transparent" />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Hair</label>
              <input type="color" value={draft.hairColor} onChange={(e) => setDraft({ ...draft, hairColor: e.target.value })} className="w-full h-9 rounded cursor-pointer bg-transparent" />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Tunic</label>
              <input type="color" value={draft.tunicColor} onChange={(e) => setDraft({ ...draft, tunicColor: e.target.value })} className="w-full h-9 rounded cursor-pointer bg-transparent" />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Armor</label>
              <input type="color" value={draft.armorColor} onChange={(e) => setDraft({ ...draft, armorColor: e.target.value })} className="w-full h-9 rounded cursor-pointer bg-transparent" />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Back Accessory</label>
            <select
              value={draft.accessory}
              onChange={(e) => setDraft({ ...draft, accessory: e.target.value as PlayerAppearance['accessory'] })}
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100"
            >
              <option value="none">None</option>
              <option value="cape">Crimson Cape</option>
              <option value="quiver">Ranger Quiver</option>
              <option value="wings_charm">Golden Wings Charm</option>
            </select>
          </div>

          <button
            type="button"
            onClick={() => {
              onSave(draft);
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm"
          >
            Apply Appearance
          </button>
        </div>
      </div>
    </div>
  );
};

interface NpcModalProps {
  npcId: string;
  saveData: SaveData;
  onBuyItem: (itemId: string) => void;
  onSellItem: (itemId: string) => void;
  onAcceptQuest: (questId: string) => void;
  onClaimQuest: (questId: string) => void;
  onClose: () => void;
}

export const NpcDialogueModal: React.FC<NpcModalProps> = ({
  npcId,
  saveData,
  onBuyItem,
  onSellItem,
  onAcceptQuest,
  onClaimQuest,
  onClose,
}) => {
  const npc = NPCS.find((n) => n.id === npcId);
  if (!npc) return null;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-2xl max-h-[85vh] flex flex-col rounded-2xl bg-[#0e1420] border border-slate-700/80 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-[#131b2b]">
          <div>
            <h2 className="font-display text-lg font-bold text-amber-100">{npc.name}</h2>
            <div className="text-xs text-slate-400">
              {npc.role} · Gold: <span className="font-mono-num text-yellow-400 font-semibold">{saveData.stats.gold}</span>
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-lg bg-slate-800 text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto rpg-scroll p-5 space-y-5 text-xs">
          <p className="text-sm text-slate-200 bg-slate-900/75 p-3.5 rounded-xl border border-slate-800">
            "{npc.greeting}"
          </p>

          {npc.questIds.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold text-amber-300">Quests</h3>
              {npc.questIds.map((qid) => {
                const q = QUEST_MAP[qid];
                if (!q) return null;
                const prog = saveData.quests[qid];
                const prereqOk = !q.prerequisiteQuestId || saveData.quests[q.prerequisiteQuestId]?.claimed;
                return (
                  <div key={qid} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-slate-100">{q.title}</div>
                      <div className="text-slate-400">{q.description}</div>
                    </div>
                    {prog?.claimed ? (
                      <span className="text-emerald-400 font-semibold shrink-0">Done</span>
                    ) : prog?.completed ? (
                      <button type="button" onClick={() => onClaimQuest(qid)} className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold shrink-0">
                        Claim
                      </button>
                    ) : prog ? (
                      <span className="text-sky-400 font-semibold shrink-0">In Progress</span>
                    ) : prereqOk ? (
                      <button type="button" onClick={() => onAcceptQuest(qid)} className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-semibold shrink-0">
                        Accept
                      </button>
                    ) : (
                      <span className="text-slate-500 shrink-0">Locked</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {npc.shopItemIds && npc.shopItemIds.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold text-emerald-300">Buy Goods</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {npc.shopItemIds.map((id) => {
                  const item = ITEM_MAP[id];
                  if (!item) return null;
                  const canAfford = saveData.stats.gold >= item.value;
                  return (
                    <div key={id} className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2">
                      <div>
                        <div className="font-semibold text-slate-100">{item.name}</div>
                        <div className="text-slate-400 font-mono-num">{item.value} Gold</div>
                      </div>
                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => onBuyItem(id)}
                        className={`px-3 py-1.5 rounded-lg font-semibold ${
                          canAfford ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        Buy
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <h3 className="font-semibold text-slate-300">Sell from Backpack</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {saveData.inventory.slice(0, 8).map((entry) => {
                const item = ITEM_MAP[entry.itemId];
                if (!item) return null;
                const sellVal = Math.max(2, Math.floor(item.value * 0.55));
                return (
                  <div key={entry.itemId} className="p-2 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-2">
                    <span className="truncate text-slate-200">
                      {item.name} x{entry.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => onSellItem(entry.itemId)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 font-mono-num shrink-0"
                    >
                      +{sellVal}g
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface SystemModalProps {
  saveData: SaveData;
  mpStatus: 'offline' | 'connecting' | 'online';
  mpRoom: string;
  remotePlayers: RemotePlayer[];
  chatMessages: ChatMessage[];
  onUpdateSettings: (s: GameSettings) => void;
  onManualSave: () => void;
  onResetSave: () => void;
  onConnectRoom: (roomCode: string) => void;
  onDisconnectRoom: () => void;
  onSendChat: (text: string) => void;
  onClose: () => void;
}

export const SystemAndOnlineModal: React.FC<SystemModalProps> = ({
  saveData,
  mpStatus,
  mpRoom,
  remotePlayers,
  chatMessages,
  onUpdateSettings,
  onManualSave,
  onResetSave,
  onConnectRoom,
  onDisconnectRoom,
  onSendChat,
  onClose,
}) => {
  const [tab, setTab] = useState<'settings' | 'online' | 'save'>('settings');
  const [roomInput, setRoomInput] = useState(mpRoom || 'REALM-1');
  const [chatInput, setChatInput] = useState('');
  const { isInstallable, isInstalled, isIOS, isOnline, install } = usePWAInstall();
  const s = saveData.settings;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-2xl max-h-[88vh] flex flex-col rounded-2xl bg-[#0e1420] border border-slate-700/80 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-[#131b2b]">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setTab('settings')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${tab === 'settings' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-200'}`}
            >
              Settings & Controls
            </button>
            <button
              type="button"
              onClick={() => setTab('online')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${tab === 'online' ? 'bg-sky-500 text-slate-950' : 'bg-slate-800 text-slate-200'}`}
            >
              <Globe className="w-3.5 h-3.5" />
              Online Co-op
            </button>
            <button
              type="button"
              onClick={() => setTab('save')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${tab === 'save' ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-200'}`}
            >
              Save & Offline PWA
            </button>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-lg bg-slate-800 text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto rpg-scroll p-5 space-y-4 text-xs">
          {tab === 'settings' && (
            <div className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-200 mb-1.5">Graphics Preset (Android GPU Optimization)</label>
                <div className="grid grid-cols-4 gap-2">
                  {(['Low', 'Medium', 'High', 'Ultra'] as GraphicsQuality[]).map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => onUpdateSettings({ ...s, graphics: q })}
                      className={`py-2 rounded-lg font-semibold border ${
                        s.graphics === q
                          ? 'bg-amber-500 text-slate-950 border-amber-300'
                          : 'bg-slate-900 text-slate-300 border-slate-700'
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="font-semibold text-slate-200">Survival Hunger System</span>
                  <input
                    type="checkbox"
                    checked={s.survivalMode}
                    onChange={(e) => onUpdateSettings({ ...s, survivalMode: e.target.checked })}
                  />
                </label>
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="font-semibold text-slate-200">Invert Camera Y</span>
                  <input
                    type="checkbox"
                    checked={s.invertY}
                    onChange={(e) => onUpdateSettings({ ...s, invertY: e.target.checked })}
                  />
                </label>
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="font-semibold text-slate-200">Sound & Music</span>
                  <input
                    type="checkbox"
                    checked={s.audioEnabled}
                    onChange={(e) => onUpdateSettings({ ...s, audioEnabled: e.target.checked })}
                  />
                </label>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="flex justify-between mb-1">
                    <span>Touch Controls Visibility</span>
                  </div>
                  <select
                    value={s.hudLayout.showTouchControls}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...s,
                        hudLayout: { ...s.hudLayout, showTouchControls: e.target.value as 'auto' | 'always' | 'hidden' },
                      })
                    }
                    className="w-full px-2 py-1.5 rounded bg-slate-800 text-slate-100"
                  >
                    <option value="auto">Auto (Touch Devices)</option>
                    <option value="always">Always Show</option>
                    <option value="hidden">Hide Touch Overlay</option>
                  </select>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="font-semibold text-slate-200">Customize Mobile Controls Size & Position</div>
                <div>
                  <div className="flex justify-between text-slate-400">
                    <span>Camera Sensitivity</span>
                    <span className="font-mono-num">{s.cameraSensitivity.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.4"
                    max="2.2"
                    step="0.1"
                    value={s.cameraSensitivity}
                    onChange={(e) => onUpdateSettings({ ...s, cameraSensitivity: Number(e.target.value) })}
                    className="w-full"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-slate-400">
                    <span>Joystick Scale</span>
                    <span className="font-mono-num">{Math.round(s.hudLayout.joystickScale * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.7"
                    max="1.4"
                    step="0.05"
                    value={s.hudLayout.joystickScale}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...s,
                        hudLayout: { ...s.hudLayout, joystickScale: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-slate-400">
                    <span>Right Action & Magic Buttons Scale</span>
                    <span className="font-mono-num">{Math.round(s.hudLayout.buttonsScale * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.7"
                    max="1.35"
                    step="0.05"
                    value={s.hudLayout.buttonsScale}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...s,
                        hudLayout: { ...s.hudLayout, buttonsScale: Number(e.target.value) },
                      })
                    }
                    className="w-full"
                  />
                </div>
              </div>
            </div>
          )}

          {tab === 'online' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-100">Multiplayer Mode (WebSocket Sync)</span>
                  <span className={`font-semibold ${mpStatus === 'online' ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {mpStatus === 'online' ? `Connected: ${mpRoom}` : mpStatus === 'connecting' ? 'Connecting...' : 'Offline Solo'}
                  </span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={roomInput}
                    onChange={(e) => setRoomInput(e.target.value.toUpperCase())}
                    placeholder="Room code (e.g. REALM-1)"
                    className="flex-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 font-mono-num"
                  />
                  {mpStatus === 'online' ? (
                    <button
                      type="button"
                      onClick={onDisconnectRoom}
                      className="px-4 py-2 rounded-lg bg-red-600 text-white font-semibold"
                    >
                      Disconnect
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onConnectRoom(roomInput)}
                      className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-semibold"
                    >
                      Join / Host Room
                    </button>
                  )}
                </div>
                <div className="text-slate-400">
                  Share the same room code with friends to explore, build structures, and battle bosses together in real time.
                  Active Co-op Allies: <strong className="font-mono-num text-sky-300">{remotePlayers.length}</strong>
                </div>
              </div>

              {mpStatus === 'online' && (
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="font-semibold text-slate-200">Party Chat</div>
                  <div className="h-32 overflow-y-auto rpg-scroll bg-slate-950/70 rounded-lg p-2 space-y-1">
                    {chatMessages.length === 0 ? (
                      <div className="text-slate-500">No messages yet. Say hello to your party!</div>
                    ) : (
                      chatMessages.map((m) => (
                        <div key={m.id}>
                          <span className="font-semibold text-amber-300">{m.senderName}: </span>
                          <span className="text-slate-200">{m.text}</span>
                        </div>
                      ))
                    )}
                  </div>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (chatInput.trim()) {
                        onSendChat(chatInput);
                        setChatInput('');
                      }
                    }}
                    className="flex gap-2"
                  >
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Send message..."
                      className="flex-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100"
                    />
                    <button type="submit" className="px-3.5 py-2 rounded-lg bg-sky-600 text-white font-semibold">
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}

          {tab === 'save' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isOnline ? <Wifi className="w-4 h-4 text-emerald-400" /> : <WifiOff className="w-4 h-4 text-amber-400" />}
                  <span>
                    Network Status: <strong>{isOnline ? 'Online (PWA Cached)' : 'Offline Mode Active'}</strong>
                  </span>
                </div>
                {!isInstalled && isInstallable && (
                  <button
                    type="button"
                    onClick={install}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Install Android / Desktop App
                  </button>
                )}
                {!isInstalled && isIOS && (
                  <span className="text-slate-300">iOS: Tap Share → Add to Home Screen</span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={onManualSave}
                  className="p-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-semibold flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Save Progress Now
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const blob = new Blob([JSON.stringify(saveData, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'fantasy-world-rpg-save.json';
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold flex items-center justify-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  Export Save File
                </button>
              </div>

              <a
                href="/api/download-game.zip"
                download="fantasy-world-rpg.zip"
                className="w-full p-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center justify-center gap-2 shadow-lg"
              >
                <Download className="w-4 h-4" />
                Download Game Package (.zip)
              </a>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Start fresh adventure (resets local save)</span>
                <button
                  type="button"
                  onClick={onResetSave}
                  className="px-3.5 py-2 rounded-lg bg-red-900/70 hover:bg-red-800 text-red-200 font-semibold flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  New Game
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
