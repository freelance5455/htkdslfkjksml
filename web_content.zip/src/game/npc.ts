// Pedestrians, police officers and AI traffic.
import * as THREE from 'three';
import { Human } from './character';
import { Vehicle, VEHICLE_SPECS, CAR_PAINT } from './vehicles';
import { BLOCK, ROAD_W, SIDEWALK_W, World } from './world';
import { damp, makeRng, rand, Rng, angleLerp } from './util';

export type PedState = 'walk' | 'idle' | 'flee' | 'dead' | 'chase' | 'cower';

export class Ped {
  human: Human;
  group = new THREE.Group();
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  target = new THREE.Vector3();
  heading = 0;
  hp = 60;
  maxHp = 60;
  state: PedState = 'walk';
  dead = false;
  isCop = false;
  fleeTimer = 0;
  idleTimer = 0;
  attackCd = 0;
  hitFlash = 0;

  constructor(isCop: boolean, rng: Rng) {
    this.isCop = isCop;
    if (isCop) {
      this.human = new Human({
        shirt: 0x1b2a4a,
        pants: 0x14161c,
        hair: rand(rng, 0x1a120c, 0x4a3324),
        height: rand(rng, 1.74, 1.9),
        bulk: rand(rng, 1.05, 1.2),
        vest: true,
      });
      this.maxHp = 120;
      this.hp = 120;
    } else {
      const shirts = [0x9a4b3c, 0x3c6a9a, 0x4b9a5c, 0x7a6a3c, 0x5c3c8a, 0x33383f, 0xc06a2c];
      const pants = [0x22252b, 0x3a3f46, 0x2f3a2a, 0x4a3b2c, 0x1f2a3a];
      this.human = new Human({
        shirt: shirts[Math.floor(rng() * shirts.length)],
        pants: pants[Math.floor(rng() * pants.length)],
        hair: rand(rng, 0x120c08, 0x6a4a2c),
        skin: rand(rng, 0x4e2f1c, 0xf0c8a0),
        height: rand(rng, 1.58, 1.88),
        bulk: rand(rng, 0.9, 1.15),
        female: rng() < 0.45,
      });
      this.maxHp = 60;
      this.hp = 60;
    }
    this.group.add(this.human.group);
    this.group.position.y = 0;
  }

  setDead() {
    this.dead = true;
    this.state = 'dead';
    this.human.setPose('dead');
    this.group.rotation.x = -Math.PI / 2 + 0.05;
    this.group.position.y = 0.32;
  }

  update(dt: number, playerPos: THREE.Vector3, time: number) {
    if (this.dead) return;
    this.hitFlash = Math.max(0, this.hitFlash - dt * 3);
    const toPlayer = new THREE.Vector3().subVectors(playerPos, this.pos);
    const dist = toPlayer.length();

    if (this.state === 'flee') {
      this.fleeTimer -= dt;
      if (this.fleeTimer <= 0) this.state = 'walk';
    }

    if (this.isCop && this.state !== 'cower') {
      if (dist < 60) this.state = 'chase';
    }

    let speed = 0;
    if (this.state === 'chase') {
      speed = 4.6;
      const desired = toPlayer.clone().setY(0).normalize();
      this.heading = angleLerp(this.heading, Math.atan2(desired.x, desired.z), 1 - Math.exp(-7 * dt));
      if (dist < 2.0) {
        speed = 0;
        this.attackCd -= dt;
        if (this.attackCd <= 0) {
          this.attackCd = 1.1;
          this.human.triggerPunch();
          return 'attack';
        }
      }
      this.human.setPose(dist < 2.2 ? 'punch' : 'run');
    } else if (this.state === 'flee') {
      speed = 5.2;
      const away = toPlayer.clone().negate().setY(0).normalize();
      this.heading = angleLerp(this.heading, Math.atan2(away.x, away.z), 1 - Math.exp(-8 * dt));
      this.human.setPose('run');
    } else if (this.state === 'idle' || this.state === 'cower') {
      speed = 0;
      this.human.setPose('idle');
      if (this.state === 'idle') {
        this.idleTimer -= dt;
        if (this.idleTimer <= 0) this.state = 'walk';
      }
    } else {
      speed = 1.35;
      const dir = this.target.clone().sub(this.pos).setY(0);
      if (dir.lengthSq() < 1.2) {
        this.pickTarget();
        this.idleTimer = rand(Math.random, 0, 6);
        if (Math.random() < 0.35) this.state = 'idle';
      }
      if (dir.lengthSq() > 0.001) {
        const desired = dir.normalize();
        this.heading = angleLerp(this.heading, Math.atan2(desired.x, desired.z), 1 - Math.exp(-6 * dt));
      }
      this.human.setPose('walk');
    }

    if (speed > 0) {
      const fwd = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
      this.pos.addScaledVector(fwd, speed * dt);
      this.group.position.copy(this.pos);
    }
    this.group.rotation.y = this.heading;
    this.human.update(dt, speed, true, { aim: 0 });
    void time;
    return undefined;
  }

  pickTarget() {
    const rng = Math.random;
    const i = Math.round(this.pos.x / BLOCK);
    const j = Math.round(this.pos.z / BLOCK);
    const off = ROAD_W / 2 + SIDEWALK_W / 2 + 0.4;
    const si = rng() < 0.5 ? -1 : 1;
    const sj = rng() < 0.5 ? -1 : 1;
    const ni = i + (rng() < 0.3 ? si : 0);
    const nj = j + (rng() < 0.3 ? sj : 0);
    this.target.set(ni * BLOCK + si * off, 0, nj * BLOCK + sj * off);
  }
}

export class PedManager {
  peds: Ped[] = [];
  group = new THREE.Group();
  private rng = makeRng(987654);
  private maxPeds = 26;
  setDensity(quality: 'low' | 'medium' | 'high') {
    this.maxPeds = quality === 'low' ? 10 : quality === 'medium' ? 16 : 26;
  }

  constructor(private world: World) {
    this.group.name = 'peds';
  }

  update(dt: number, playerPos: THREE.Vector3, time: number) {
    // spawn new peds near the player
    if (this.peds.length < this.maxPeds) {
      const tries = 4;
      for (let t = 0; t < tries; t++) {
        const ang = this.rng() * Math.PI * 2;
        const r = 40 + this.rng() * 70;
        const x = playerPos.x + Math.cos(ang) * r;
        const z = playerPos.z + Math.sin(ang) * r;
        if (this.world.onRoad(x, z)) continue;
        const ped = new Ped(false, this.rng);
        ped.pos.set(x, 0, z);
        ped.pickTarget();
        this.peds.push(ped);
        this.group.add(ped.group);
        break;
      }
    }
    for (let i = this.peds.length - 1; i >= 0; i--) {
      const p = this.peds[i];
      const d = p.pos.distanceTo(playerPos);
      if (d > 240) {
        this.group.remove(p.group);
        p.human.dispose();
        this.peds.splice(i, 1);
        continue;
      }
      p.update(dt, playerPos, time);
    }
  }

  spawnCop(x: number, z: number) {
    const cop = new Ped(true, this.rng);
    cop.pos.set(x, 0, z);
    cop.state = 'chase';
    this.peds.push(cop);
    this.group.add(cop.group);
    return cop;
  }

  nearestCop(pos: THREE.Vector3, maxDist = 3) {
    let best: Ped | null = null;
    let bd = maxDist;
    for (const p of this.peds) {
      if (!p.isCop || p.dead) continue;
      const d = p.pos.distanceTo(pos);
      if (d < bd) {
        bd = d;
        best = p;
      }
    }
    return best;
  }

  panic(pos: THREE.Vector3, radius = 26) {
    for (const p of this.peds) {
      if (p.isCop || p.dead) continue;
      if (p.pos.distanceTo(pos) < radius) {
        p.state = 'flee';
        p.fleeTimer = 8 + Math.random() * 6;
      }
    }
  }

  clear() {
    this.peds.forEach((p) => this.group.remove(p.group));
    this.peds = [];
  }
}

export class TrafficManager {
  group = new THREE.Group();
  cars: Vehicle[] = [];
  private rng = makeRng(31415);
  private world: World;
  maxCars = 14;
  setDensity(quality: 'low' | 'medium' | 'high') {
    this.maxCars = quality === 'low' ? 6 : quality === 'medium' ? 10 : 14;
  }

  constructor(world: World) {
    this.world = world;
    this.group.name = 'traffic';
  }

  private lanePoint(i: number, j: number, dir: number): [number, number] {
    const off = ROAD_W / 4 + 1.2;
    if (dir === 0) return [i * BLOCK + off, j * BLOCK];
    if (dir === 1) return [i * BLOCK, j * BLOCK + off];
    if (dir === 2) return [i * BLOCK - off, j * BLOCK];
    return [i * BLOCK, j * BLOCK - off];
  }

  update(dt: number, playerPos: THREE.Vector3, night: boolean) {
    void this.world;
    if (this.cars.length < this.maxCars) {
      const ang = this.rng() * Math.PI * 2;
      const r = 60 + this.rng() * 90;
      const x = playerPos.x + Math.cos(ang) * r;
      const z = playerPos.z + Math.sin(ang) * r;
      const dir = Math.floor(this.rng() * 4);
      const i = Math.round(x / BLOCK);
      const j = Math.round(z / BLOCK);
      const [px, pz] = this.lanePoint(i, j, dir);
      const types = ['sedan', 'sedan', 'suv', 'taxi', 'van', 'ev', 'bus'];
      const type = types[Math.floor(this.rng() * types.length)];
      const car = new Vehicle(type, CAR_PAINT[Math.floor(this.rng() * CAR_PAINT.length)], this.plateFor(type));
      car.pos.set(px, 0, pz);
      car.heading = dir === 0 ? Math.PI / 2 : dir === 1 ? Math.PI : dir === 2 ? -Math.PI / 2 : 0;
      car.speed = 8 + this.rng() * 5;
      (car as any).dir = dir;
      (car as any).blockI = i;
      (car as any).blockJ = j;
      (car as any).cruise = 9 + this.rng() * 5;
      this.cars.push(car);
      this.group.add(car.group);
    }

    for (let i = this.cars.length - 1; i >= 0; i--) {
      const car = this.cars[i];
      const d = car.pos.distanceTo(playerPos);
      if (d > 260) {
        this.group.remove(car.group);
        this.cars.splice(i, 1);
        continue;
      }
      const dir = (car as any).dir;
      let target = car.speed;
      // slow for cars ahead
      for (const o of this.cars) {
        if (o === car) continue;
        const dd = o.pos.distanceTo(car.pos);
        if (dd < 14 && dd > 0.1) {
          target = Math.min(target, Math.max(0, car.speed - (14 - dd) * 1.4));
        }
      }
      car.throttle = target > car.speed ? 0.5 : 0;
      car.brake = target < car.speed - 0.5 ? 1 : 0;
      car.speed = damp(car.speed, target, 2.2, dt);
      car.steer = 0;
      car.heading += car.speed * 0.002 * dt * 0;
      const fwd = new THREE.Vector3(Math.sin(car.heading), 0, Math.cos(car.heading));
      car.pos.addScaledVector(fwd, car.speed * dt);
      car.updateVisual(dt, performance.now() / 1000);
      // headlights at night
      car.setLightsOn(night);
      // intersection handling
      const gi = Math.round(car.pos.x / BLOCK);
      const gj = Math.round(car.pos.z / BLOCK);
      if (gi !== (car as any).blockI || gj !== (car as any).blockJ) {
        (car as any).blockI = gi;
        (car as any).blockJ = gj;
        const r = this.rng();
        let ndir = dir;
        if (r < 0.16) ndir = (dir + 1) % 4;
        else if (r < 0.32) ndir = (dir + 3) % 4;
        (car as any).dir = ndir;
        const off = ROAD_W / 4 + 1.2;
        if (ndir === 0) {
          car.pos.x = gi * BLOCK + off;
          car.heading = Math.PI / 2;
        } else if (ndir === 1) {
          car.pos.z = gj * BLOCK + off;
          car.heading = Math.PI;
        } else if (ndir === 2) {
          car.pos.x = gi * BLOCK - off;
          car.heading = -Math.PI / 2;
        } else {
          car.pos.z = gj * BLOCK - off;
          car.heading = 0;
        }
      }
    }
  }

  plateFor(type: string) {
    void type;
    const letters = 'ABCDEFGHJKLMNPRSTUVWXYZ';
    const l = () => letters[Math.floor(this.rng() * letters.length)];
    return `${l()}${l()}${l()}-${Math.floor(this.rng() * 9000 + 1000)}`;
  }
}

export const POLICE_VEHICLE_TYPES = ['police'];
export { VEHICLE_SPECS };
