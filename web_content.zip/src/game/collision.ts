import * as THREE from 'three'
import { groundHeight, terrainNormal, terrainHeight, WATER_LEVEL } from './terrain'

/**
 * Collision between the aircraft and the terrain.
 *
 * The terrain is an analytic height field, so contact is exact: a handful of probe points on the
 * airframe are tested against the ground height beneath them. Probes are checked at several poses
 * between the previous and the current simulation step so a fast aircraft cannot tunnel through a ridge.
 */
export const AIRCRAFT_LENGTH = 11

/** Contact points in aircraft space (-Z is the nose): nose, tail, wing tips, belly/gear, canopy, fin. */
export const PROBES: readonly THREE.Vector3[] = [
  new THREE.Vector3(0, -0.2, -5.4),
  new THREE.Vector3(0, 0.2, 5.4),
  new THREE.Vector3(-3.7, 0, 0.4),
  new THREE.Vector3(3.7, 0, 0.4),
  new THREE.Vector3(0, -1.9, -1.0),
  new THREE.Vector3(0, -1.9, 2.2),
  new THREE.Vector3(0, 1.6, 1.5),
  new THREE.Vector3(0, 2.0, 4.8),
]

export type Contact = {
  point: THREE.Vector3
  normal: THREE.Vector3
  /** Speed of the aircraft at impact (m/s). */
  speed: number
  surface: 'terrain' | 'water'
}

const _p = new THREE.Vector3()
const _q = new THREE.Quaternion()
const _w = new THREE.Vector3()
const _n = { x: 0, y: 1, z: 0 }

function probeHit(position: THREE.Vector3, quaternion: THREE.Quaternion, margin: number, out: THREE.Vector3): boolean {
  for (const probe of PROBES) {
    _w.copy(probe).applyQuaternion(quaternion).add(position)
    if (_w.y < groundHeight(_w.x, _w.z) + margin) {
      out.copy(_w)
      return true
    }
  }
  return false
}

/**
 * Returns true and fills `out` when the aircraft touched the ground while moving from the previous
 * pose to the current one.
 */
export function detectGroundContact(
  prevPos: THREE.Vector3, prevQuat: THREE.Quaternion,
  pos: THREE.Vector3, quat: THREE.Quaternion,
  speed: number, out: Contact,
): boolean {
  const distance = prevPos.distanceTo(pos)
  const steps = Math.max(1, Math.ceil(distance / 2.5))
  for (let i = 1; i <= steps; i += 1) {
    const t = i / steps
    _p.lerpVectors(prevPos, pos, t)
    _q.slerpQuaternions(prevQuat, quat, t)
    if (probeHit(_p, _q, 0, out.point)) {
      terrainNormal(out.point.x, out.point.z, _n)
      out.normal.set(_n.x, _n.y, _n.z)
      out.speed = speed
      out.surface = terrainHeight(out.point.x, out.point.z) > WATER_LEVEL ? 'terrain' : 'water'
      return true
    }
  }
  return false
}

export function createContact(): Contact {
  return { point: new THREE.Vector3(), normal: new THREE.Vector3(0, 1, 0), speed: 0, surface: 'terrain' }
}

/** Height of the aircraft above the surface directly beneath it. */
export function altitudeAboveGround(position: THREE.Vector3): number {
  return position.y - groundHeight(position.x, position.z)
}

/**
 * Seconds until the current flight path comes within `clearance` metres of the ground (looking up
 * to `horizon` s ahead), or Infinity when the way is clear.
 */
export function timeToTerrain(position: THREE.Vector3, forward: THREE.Vector3, speed: number, horizon = 6, clearance = 30): number {
  const step = 0.4
  for (let t = step; t <= horizon; t += step) {
    const x = position.x + forward.x * speed * t
    const y = position.y + forward.y * speed * t
    const z = position.z + forward.z * speed * t
    if (y - groundHeight(x, z) < clearance) return t
  }
  return Infinity
}

/**
 * The wrecked airframe: a rigid body that tumbles, bounces and slides until it comes to rest.
 * A sphere approximates the fuselage for ground contact.
 */
export class Wreck {
  readonly position = new THREE.Vector3()
  readonly quaternion = new THREE.Quaternion()
  readonly velocity = new THREE.Vector3()
  readonly angular = new THREE.Vector3()
  readonly radius = 2.4
  grounded = false
  inWater = false
  restTime = 0
  /** Bounce callback: contact point and impact strength (m/s along the normal). */
  onImpact?: (point: THREE.Vector3, strength: number, water: boolean) => void

  private readonly axis = new THREE.Vector3()
  private readonly nrm = new THREE.Vector3()
  private readonly tangent = new THREE.Vector3()

  start(position: THREE.Vector3, quaternion: THREE.Quaternion, forward: THREE.Vector3, speed: number, contactNormal: THREE.Vector3): void {
    this.position.copy(position)
    this.quaternion.copy(quaternion)
    // The crash scrubs most of the energy: keep part of the velocity along the surface, bounce a little.
    this.velocity.copy(forward).multiplyScalar(speed * 0.62)
    const vn = this.velocity.dot(contactNormal)
    if (vn < 0) this.velocity.addScaledVector(contactNormal, -vn * 1.25)
    this.angular.set(0.9 + Math.random() * 1.6, (Math.random() - 0.5) * 2.4, (Math.random() - 0.5) * 3.6)
    this.grounded = false
    this.inWater = false
    this.restTime = 0
  }

  get settled(): boolean {
    return this.restTime > 0.6
  }

  step(dt: number): void {
    this.velocity.y -= 26 * dt
    this.position.addScaledVector(this.velocity, dt)

    const g = groundHeight(this.position.x, this.position.z)
    this.grounded = false
    this.inWater = terrainHeight(this.position.x, this.position.z) <= WATER_LEVEL
    if (this.position.y - this.radius < g) {
      this.position.y = g + this.radius
      terrainNormal(this.position.x, this.position.z, _n)
      this.nrm.set(_n.x, _n.y, _n.z)
      const vn = this.velocity.dot(this.nrm)
      if (vn < 0) {
        const restitution = this.inWater ? 0.05 : 0.28
        this.velocity.addScaledVector(this.nrm, -(1 + restitution) * vn)
        const keep = this.inWater ? 0.35 : 0.72
        this.tangent.copy(this.velocity).addScaledVector(this.nrm, -this.velocity.dot(this.nrm))
        this.velocity.addScaledVector(this.tangent, -(1 - keep))
        this.angular.multiplyScalar(this.inWater ? 0.4 : 0.8)
        this.onImpact?.(this.position, -vn, this.inWater)
      }
      this.grounded = true
    }

    // Grounded drag brings the wreck to rest; air drag is negligible.
    if (this.grounded) {
      const drag = Math.exp(-dt * (this.inWater ? 3.2 : 1.4))
      this.velocity.x *= drag
      this.velocity.z *= drag
      this.angular.multiplyScalar(Math.exp(-dt * 1.8))
    }

    const spin = this.angular.length()
    if (spin > 1e-4) {
      this.axis.copy(this.angular).divideScalar(spin)
      _q.setFromAxisAngle(this.axis, spin * dt)
      this.quaternion.multiply(_q).normalize()
    }

    if (this.grounded && this.velocity.length() < 3.5 && spin < 0.5) this.restTime += dt
    else this.restTime = 0
  }
}
