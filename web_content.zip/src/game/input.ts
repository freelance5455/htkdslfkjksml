export const input = {
  joyX: 0,
  joyY: 0,
  lookDx: 0,
  lookDy: 0,
  interact: false,
};

export function pushLook(dx: number, dy: number): void {
  input.lookDx += dx;
  input.lookDy += dy;
}

export function requestInteract(): void {
  input.interact = true;
}

export function radialDeadzone(x: number, y: number, dz = 0.16): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz || m === 0) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

type Api = {
  start: () => void;
  nextDay: () => void;
  retry: () => void;
  pause: () => void;
  resume: () => void;
  quit: () => void;
  toggleMute: () => void;
};

let api: Api | null = null;
const queued: Array<keyof Api> = [];

export function bindApi(next: Api | null): void {
  api = next;
  if (!next) return;
  const pending = queued.splice(0, queued.length);
  for (const cmd of pending) next[cmd]();
}

export function gameCommand(cmd: keyof Api): void {
  if (api) api[cmd]();
  else if (cmd === "start" || cmd === "toggleMute") queued.push(cmd);
}
