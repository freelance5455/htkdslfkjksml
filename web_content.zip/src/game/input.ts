export interface InputState {
  throttle: number; // 0..1
  brake: number; // 0..1
  steer: number; // -1..1 (negative = left, positive = right)
  handbrake: boolean;
}

export class InputManager {
  private keys = new Set<string>();
  touchGas = false;
  touchBrake = false;
  touchLeft = false;
  touchRight = false;
  touchHandbrake = false;
  gamepadEnabled = true;

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    // prevent scrolling with arrows/space
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    this.keys.add(k);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };
  private onBlur = () => this.keys.clear();

  attach() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
  }
  detach() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
  }

  setTouch(control: 'gas' | 'brake' | 'left' | 'right' | 'handbrake', pressed: boolean) {
    if (control === 'gas') this.touchGas = pressed;
    else if (control === 'brake') this.touchBrake = pressed;
    else if (control === 'left') this.touchLeft = pressed;
    else if (control === 'right') this.touchRight = pressed;
    else if (control === 'handbrake') this.touchHandbrake = pressed;
  }

  private readGamepad(): { throttle: number; brake: number; steer: number; handbrake: boolean } {
    let throttle = 0;
    let brake = 0;
    let steer = 0;
    let handbrake = false;
    try {
      if (!this.gamepadEnabled) return { throttle, brake, steer, handbrake };
      const pads = navigator.getGamepads ? navigator.getGamepads() : [];
      for (const pad of pads) {
        if (!pad || !pad.connected) continue;
        const dz = (v: number) => (Math.abs(v) < 0.12 ? 0 : v);
        const ax = dz(pad.axes[0] ?? 0);
        if (Math.abs(ax) > Math.abs(steer)) steer = ax;
        // triggers
        const rt = pad.buttons[7]?.value ?? 0;
        const lt = pad.buttons[6]?.value ?? 0;
        if (rt > throttle) throttle = rt;
        if (lt > brake) brake = lt;
        // face buttons: A gas, B/X brake
        if (pad.buttons[0]?.pressed) throttle = Math.max(throttle, 1);
        if (pad.buttons[1]?.pressed || pad.buttons[2]?.pressed) brake = Math.max(brake, 1);
        // dpad steering
        if (pad.buttons[14]?.pressed) steer = -1;
        if (pad.buttons[15]?.pressed) steer = 1;
        if (pad.buttons[4]?.pressed || pad.buttons[5]?.pressed) handbrake = true;
        if (pad.buttons[9]?.pressed) handbrake = true;
        break; // use first connected pad
      }
    } catch {
      /* ignore */
    }
    return { throttle, brake, steer, handbrake };
  }

  getState(): InputState {
    const k = this.keys;
    let throttle = 0;
    let brake = 0;
    let steer = 0;

    if (k.has('arrowup') || k.has('w')) throttle = 1;
    if (k.has('arrowdown') || k.has('s')) brake = 1;
    if (k.has('arrowleft') || k.has('a')) steer -= 1;
    if (k.has('arrowright') || k.has('d')) steer += 1;
    let handbrake = k.has(' ') || k.has('shift');

    if (this.touchGas) throttle = 1;
    if (this.touchBrake) brake = 1;
    if (this.touchLeft) steer -= 1;
    if (this.touchRight) steer += 1;
    if (this.touchHandbrake) handbrake = true;

    const gp = this.readGamepad();
    throttle = Math.max(throttle, gp.throttle);
    brake = Math.max(brake, gp.brake);
    if (gp.steer !== 0) steer = Math.max(-1, Math.min(1, steer + gp.steer));
    handbrake = handbrake || gp.handbrake;

    steer = Math.max(-1, Math.min(1, steer));
    return { throttle, brake, steer, handbrake };
  }

  get gamepadConnected(): boolean {
    try {
      const pads = navigator.getGamepads ? navigator.getGamepads() : [];
      for (const p of pads) if (p && p.connected) return true;
    } catch {
      /* ignore */
    }
    return false;
  }
}
