export interface InputState {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  sprint: boolean;
  crouch: boolean;
  jump: boolean;
  justJumped: boolean;
  shoot: boolean;
  justShot: boolean;
  aimDownSights: boolean;
  reload: boolean;
  useMedkit: boolean;
  deployGlooWall: boolean;
  switchSlot1: boolean;
  switchSlot2: boolean;
  switchSlot3: boolean;
  switchGlooWall: boolean;
  toggleMap: boolean;
  pause: boolean;

  // Mouse delta
  lookDeltaX: number;
  lookDeltaY: number;

  isPointerLocked: boolean;
}

export class InputManager {
  public state: InputState = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    sprint: false,
    crouch: false,
    jump: false,
    justJumped: false,
    shoot: false,
    justShot: false,
    aimDownSights: false,
    reload: false,
    useMedkit: false,
    deployGlooWall: false,
    switchSlot1: false,
    switchSlot2: false,
    switchSlot3: false,
    switchGlooWall: false,
    toggleMap: false,
    pause: false,
    lookDeltaX: 0,
    lookDeltaY: 0,
    isPointerLocked: false,
  };

  private targetElement: HTMLElement | null = null;
  private isPointerLockActive: boolean = false;
  public mouseSensitivity: number = 0.0022;

  public init(element: HTMLElement) {
    this.targetElement = element;
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('mousemove', this.handleMouseMove);
    window.addEventListener('mousedown', this.handleMouseDown);
    window.addEventListener('mouseup', this.handleMouseUp);
    window.addEventListener('contextmenu', this.handleContextMenu);
    window.addEventListener('blur', this.handleBlur);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
  }

  public requestPointerLock() {
    if (this.targetElement && document.pointerLockElement !== this.targetElement) {
      try {
        this.targetElement.requestPointerLock();
      } catch (err) {
        console.warn('Pointer lock request error', err);
      }
    }
  }

  public exitPointerLock() {
    if (document.pointerLockElement) {
      try {
        document.exitPointerLock();
      } catch (err) {
        console.warn('Pointer lock exit error', err);
      }
    }
  }

  private handlePointerLockChange = () => {
    this.isPointerLockActive = document.pointerLockElement === this.targetElement;
    this.state.isPointerLocked = this.isPointerLockActive;
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.state.forward = true;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.state.backward = true;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.state.left = true;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.state.right = true;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.state.sprint = true;
        break;
      case 'KeyC':
        this.state.crouch = !this.state.crouch;
        break;
      case 'Space':
        this.state.jump = true;
        this.state.justJumped = true;
        e.preventDefault();
        break;
      case 'KeyR':
        this.state.reload = true;
        break;
      case 'Digit1':
        this.state.switchSlot1 = true;
        break;
      case 'Digit2':
        this.state.switchSlot2 = true;
        break;
      case 'Digit3':
        this.state.switchSlot3 = true;
        break;
      case 'Digit4':
      case 'KeyG':
      case 'KeyE':
        this.state.deployGlooWall = true;
        break;
      case 'KeyH':
      case 'KeyF':
        this.state.useMedkit = true;
        break;
      case 'KeyM':
        this.state.toggleMap = true;
        break;
      case 'Escape':
        this.state.pause = true;
        break;
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    switch (e.code) {
      case 'KeyW':
      case 'ArrowUp':
        this.state.forward = false;
        break;
      case 'KeyS':
      case 'ArrowDown':
        this.state.backward = false;
        break;
      case 'KeyA':
      case 'ArrowLeft':
        this.state.left = false;
        break;
      case 'KeyD':
      case 'ArrowRight':
        this.state.right = false;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
        this.state.sprint = false;
        break;
      case 'Space':
        this.state.jump = false;
        break;
    }
  };

  private handleMouseDown = (e: MouseEvent) => {
    if (e.button === 0) {
      // Left click
      this.state.shoot = true;
      this.state.justShot = true;
    } else if (e.button === 2) {
      // Right click: ADS
      this.state.aimDownSights = true;
    }
  };

  private handleMouseUp = (e: MouseEvent) => {
    if (e.button === 0) {
      this.state.shoot = false;
    } else if (e.button === 2) {
      this.state.aimDownSights = false;
    }
  };

  private handleMouseMove = (e: MouseEvent) => {
    if (this.isPointerLockActive) {
      this.state.lookDeltaX += e.movementX * this.mouseSensitivity;
      this.state.lookDeltaY += e.movementY * this.mouseSensitivity;
    }
  };

  private handleContextMenu = (e: MouseEvent) => {
    e.preventDefault();
  };

  private handleBlur = () => {
    // Clear all held inputs on blur to prevent phantom stuck keys
    this.state.forward = false;
    this.state.backward = false;
    this.state.left = false;
    this.state.right = false;
    this.state.sprint = false;
    this.state.jump = false;
    this.state.shoot = false;
    this.state.aimDownSights = false;
  };

  // Called at the end of each frame to reset edge-triggered flags
  public endFrame() {
    this.state.justJumped = false;
    this.state.justShot = false;
    this.state.reload = false;
    this.state.useMedkit = false;
    this.state.deployGlooWall = false;
    this.state.switchSlot1 = false;
    this.state.switchSlot2 = false;
    this.state.switchSlot3 = false;
    this.state.switchGlooWall = false;
    this.state.toggleMap = false;
    this.state.pause = false;
    this.state.lookDeltaX = 0;
    this.state.lookDeltaY = 0;
  }

  // Virtual touch controls helpers
  public setVirtualMove(x: number, y: number) {
    this.state.forward = y < -0.2;
    this.state.backward = y > 0.2;
    this.state.left = x < -0.2;
    this.state.right = x > 0.2;
    this.state.sprint = Math.hypot(x, y) > 0.75;
  }

  public addVirtualLook(dx: number, dy: number) {
    this.state.lookDeltaX += dx * this.mouseSensitivity * 1.5;
    this.state.lookDeltaY += dy * this.mouseSensitivity * 1.5;
  }

  public triggerAction(action: 'shoot' | 'jump' | 'crouch' | 'reload' | 'gloo' | 'medkit' | 'ads', active: boolean = true) {
    switch (action) {
      case 'shoot':
        this.state.shoot = active;
        if (active) this.state.justShot = true;
        break;
      case 'jump':
        this.state.jump = active;
        if (active) this.state.justJumped = true;
        break;
      case 'crouch':
        if (active) this.state.crouch = !this.state.crouch;
        break;
      case 'reload':
        if (active) this.state.reload = true;
        break;
      case 'gloo':
        if (active) this.state.deployGlooWall = true;
        break;
      case 'medkit':
        if (active) this.state.useMedkit = true;
        break;
      case 'ads':
        this.state.aimDownSights = active;
        break;
    }
  }

  public destroy() {
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('mousemove', this.handleMouseMove);
    window.removeEventListener('mousedown', this.handleMouseDown);
    window.removeEventListener('mouseup', this.handleMouseUp);
    window.removeEventListener('contextmenu', this.handleContextMenu);
    window.removeEventListener('blur', this.handleBlur);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);
  }
}
