import type { Actions } from "@/game/types";

const GAME_KEYS = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Space",
  "ShiftLeft",
  "ShiftRight",
  "KeyR",
  "Escape",
  "KeyF",
]);

function radialDeadzone(x: number, y: number, dz = 0.16): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

function clampMag(x: number, y: number): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m <= 1) return { x, y };
  return { x: x / m, y: y / m };
}

export class Input {
  private keys = new Set<string>();
  private injected = new Set<string>();
  touchMoveX = 0;
  touchMoveY = 0;
  fireHeld = false;
  private lookX = 0;
  private lookY = 0;
  private reloadQueued = false;
  private pauseQueued = false;
  private bound = false;

  private onKeyDown = (e: KeyboardEvent) => {
    if (GAME_KEYS.has(e.code)) e.preventDefault();
    this.keys.add(e.code);
    if (e.code === "KeyR") this.reloadQueued = true;
    if (e.code === "Escape") this.pauseQueued = true;
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
    this.fireHeld = false;
  };

  attach() {
    if (this.bound) return;
    this.bound = true;
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
  }

  detach() {
    if (!this.bound) return;
    this.bound = false;
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.keys.clear();
  }

  addLook(dx: number, dy: number) {
    this.lookX += dx;
    this.lookY += dy;
  }

  setInjected(codes: string[]) {
    this.injected.clear();
    for (const c of codes) this.injected.add(c);
  }

  queueReload() {
    this.reloadQueued = true;
  }

  queuePause() {
    this.pauseQueued = true;
  }

  sample(): Actions {
    const down = this.injected.size ? this.injected : this.keys;
    let moveX = this.touchMoveX;
    let moveY = this.touchMoveY;
    if (down.has("KeyA") || down.has("ArrowLeft")) moveX -= 1;
    if (down.has("KeyD") || down.has("ArrowRight")) moveX += 1;
    if (down.has("KeyW") || down.has("ArrowUp")) moveY += 1;
    if (down.has("KeyS") || down.has("ArrowDown")) moveY -= 1;

    let padFire = false;
    const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
    if (pads) {
      for (const pad of pads) {
        if (!pad || pad.mapping !== "standard") continue;
        const ls = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
        moveX += ls.x;
        moveY -= ls.y;
        const rs = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0, 0.12);
        this.lookX += rs.x * 14;
        this.lookY += rs.y * 14;
        if (pad.buttons[7]?.pressed || pad.buttons[0]?.pressed) padFire = true;
        if (pad.buttons[2]?.pressed) this.reloadQueued = true;
        if (pad.buttons[9]?.pressed) this.pauseQueued = true;
      }
    }

    const move = clampMag(moveX, moveY);
    const lookDx = this.lookX;
    const lookDy = this.lookY;
    this.lookX = 0;
    this.lookY = 0;

    const fire = this.fireHeld || padFire || down.has("Space") || down.has("KeyF");
    const reload = this.reloadQueued;
    const pause = this.pauseQueued;
    this.reloadQueued = false;
    this.pauseQueued = false;

    return {
      moveX: move.x,
      moveY: move.y,
      lookDx,
      lookDy,
      fire,
      reload,
      sprint: down.has("ShiftLeft") || down.has("ShiftRight"),
      pause,
    };
  }
}
