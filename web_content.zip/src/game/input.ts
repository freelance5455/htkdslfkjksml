export interface TouchJoystickState {
  active: boolean;
  touchId: number | null;
  baseX: number;
  baseY: number;
  currentX: number;
  currentY: number;
  dx: number; // -1..1
  dy: number;
}

export class InputManager {
  public keysHeld: Set<string> = new Set();
  public keysJustPressed: Set<string> = new Set();
  public mousePos: { x: number; y: number } = { x: 0, y: 0 };
  public mouseDown: boolean = false;
  public mouseJustPressed: boolean = false;

  // Virtual Joystick on mobile
  public joystick: TouchJoystickState = {
    active: false,
    touchId: null,
    baseX: 0,
    baseY: 0,
    currentX: 0,
    currentY: 0,
    dx: 0,
    dy: 0,
  };

  // Virtual touch action buttons
  public virtualActions: Record<string, boolean> = {
    attack: false,
    special: false,
    roll: false,
    guard: false,
    heal: false,
    interact: false,
    lockon: false,
    sprint: false,
  };
  public virtualActionsJustPressed: Set<string> = new Set();

  private keyBuffer: Map<string, number> = new Map(); // Input buffering timer (seconds)

  constructor() {
    this.setupListeners();
  }

  private setupListeners() {
    if (typeof window === 'undefined') return;

    window.addEventListener('keydown', (e) => {
      // Prevent browser scroll on space/arrows
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
      if (!this.keysHeld.has(e.code)) {
        this.keysJustPressed.add(e.code);
        this.keyBuffer.set(e.code, 0.2); // 200ms buffer
      }
      this.keysHeld.add(e.code);
    });

    window.addEventListener('keyup', (e) => {
      this.keysHeld.delete(e.code);
    });

    window.addEventListener('mousemove', (e) => {
      this.mousePos.x = e.clientX;
      this.mousePos.y = e.clientY;
    });

    window.addEventListener('mousedown', (e) => {
      if (e.button === 0) {
        this.mouseDown = true;
        this.mouseJustPressed = true;
        this.keyBuffer.set('Mouse0', 0.2);
      } else if (e.button === 2) {
        this.keyBuffer.set('Mouse2', 0.2);
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) {
        this.mouseDown = false;
      }
    });

    // Disable context menu on right click to allow Special Attack
    window.addEventListener('contextmenu', (e) => {
      e.preventDefault();
    });

    // Clear held keys on blur & visibility loss
    window.addEventListener('blur', () => this.clearAll());
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.clearAll();
    });
  }

  public clearAll() {
    this.keysHeld.clear();
    this.keysJustPressed.clear();
    this.keyBuffer.clear();
    this.mouseDown = false;
    this.mouseJustPressed = false;
    this.joystick.active = false;
    this.joystick.dx = 0;
    this.joystick.dy = 0;
    Object.keys(this.virtualActions).forEach((k) => (this.virtualActions[k] = false));
    this.virtualActionsJustPressed.clear();
  }

  // Update input buffer timers each frame
  public update(dt: number) {
    // Expire buffered keys
    for (const [key, timer] of this.keyBuffer.entries()) {
      const next = timer - dt;
      if (next <= 0) {
        this.keyBuffer.delete(key);
      } else {
        this.keyBuffer.set(key, next);
      }
    }
  }

  // Called strictly at the END of the simulation tick so actions can be consumed
  public endFrame() {
    this.keysJustPressed.clear();
    this.mouseJustPressed = false;
    this.virtualActionsJustPressed.clear();
  }

  // Query directional movement vector (-1..1)
  public getMovementVector(): { dx: number; dy: number } {
    let dx = 0;
    let dy = 0;

    // Keyboard (WASD / Arrows)
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) dx -= 1;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) dx += 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) dy -= 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) dy += 1;

    // Normalize keyboard diagonal
    if (dx !== 0 && dy !== 0) {
      const len = Math.hypot(dx, dy);
      dx /= len;
      dy /= len;
    }

    // Touch joystick overlay
    if (this.joystick.active && (this.joystick.dx !== 0 || this.joystick.dy !== 0)) {
      dx = this.joystick.dx;
      dy = this.joystick.dy;
    }

    return { dx, dy };
  }

  public isHeld(action: 'sprint' | 'attack' | 'special' | 'guard' | 'heal'): boolean {
    switch (action) {
      case 'sprint':
        return (
          this.keysHeld.has('ShiftLeft') ||
          this.keysHeld.has('ShiftRight') ||
          this.virtualActions['sprint']
        );
      case 'attack':
        return (
          this.keysHeld.has('KeyJ') ||
          this.keysHeld.has('KeyZ') ||
          this.mouseDown ||
          this.virtualActions['attack']
        );
      case 'special':
        return (
          this.keysHeld.has('KeyK') ||
          this.keysHeld.has('KeyX') ||
          this.virtualActions['special']
        );
      case 'guard':
        return (
          this.keysHeld.has('KeyL') ||
          this.keysHeld.has('KeyC') ||
          this.virtualActions['guard']
        );
      case 'heal':
        return this.virtualActions['heal'];
    }
  }

  public isJustPressed(
    action:
      | 'attack'
      | 'special'
      | 'roll'
      | 'guard'
      | 'heal'
      | 'interact'
      | 'lockon'
      | 'pause'
      | 'nextItem'
      | 'prevItem'
  ): boolean {
    const checkAndConsume = (keys: string[]): boolean => {
      for (const k of keys) {
        if (this.keysJustPressed.has(k) || this.keyBuffer.has(k)) {
          this.keysJustPressed.delete(k);
          this.keyBuffer.delete(k);
          return true;
        }
      }
      return false;
    };

    switch (action) {
      case 'attack': {
        if (this.virtualActionsJustPressed.has('attack') || this.virtualActions['attack']) {
          this.virtualActionsJustPressed.delete('attack');
          return true;
        }
        if (this.mouseJustPressed) {
          this.mouseJustPressed = false;
          return true;
        }
        return checkAndConsume(['KeyJ', 'KeyZ', 'Mouse0']);
      }

      case 'special': {
        if (this.virtualActionsJustPressed.has('special')) {
          this.virtualActionsJustPressed.delete('special');
          return true;
        }
        return checkAndConsume(['KeyK', 'KeyX', 'Mouse2']);
      }

      case 'roll': {
        if (this.virtualActionsJustPressed.has('roll')) {
          this.virtualActionsJustPressed.delete('roll');
          return true;
        }
        return checkAndConsume(['Space']);
      }

      case 'guard': {
        if (this.virtualActionsJustPressed.has('guard')) {
          this.virtualActionsJustPressed.delete('guard');
          return true;
        }
        return checkAndConsume(['KeyL', 'KeyC']);
      }

      case 'heal': {
        if (this.virtualActionsJustPressed.has('heal')) {
          this.virtualActionsJustPressed.delete('heal');
          return true;
        }
        return checkAndConsume(['KeyH', 'KeyF']);
      }

      case 'interact': {
        if (this.virtualActionsJustPressed.has('interact')) {
          this.virtualActionsJustPressed.delete('interact');
          return true;
        }
        return checkAndConsume(['KeyE']);
      }

      case 'lockon': {
        if (this.virtualActionsJustPressed.has('lockon')) {
          this.virtualActionsJustPressed.delete('lockon');
          return true;
        }
        return checkAndConsume(['KeyQ', 'Tab']);
      }

      case 'pause': {
        return checkAndConsume(['Escape', 'KeyP']);
      }

      case 'nextItem': {
        return checkAndConsume(['Digit2', 'BracketRight']);
      }

      case 'prevItem': {
        return checkAndConsume(['Digit1', 'BracketLeft']);
      }
    }
  }

  // Trigger virtual button from mobile UI touch or mouse click
  public triggerVirtualButton(button: string, isDown: boolean) {
    if (isDown) {
      this.virtualActionsJustPressed.add(button);
      this.keyBuffer.set(`Virtual_${button}`, 0.25);
    }
    this.virtualActions[button] = isDown;
  }
}
