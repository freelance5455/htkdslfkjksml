export type Actions = {
  moveX: number;
  moveY: number;
  lookX: number;
  lookY: number;
  sprint: boolean;
  interact: boolean;
  interactDown: boolean;
};

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowLeft",
  "ArrowDown",
  "ArrowRight",
  "ShiftLeft",
  "ShiftRight",
  "KeyE",
  "Space",
  "KeyF",
]);

function radialDeadzone(x: number, y: number, dz = 0.15): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class Input {
  keys = new Set<string>();
  injected: string[] | null = null;
  stick = { x: 0, y: 0 };
  look = { x: 0, y: 0 };
  sprintTouch = false;
  interactHeld = false;
  private interactWas = false;
  private lookAcc = { x: 0, y: 0 };
  enabled = true;

  attach(el: HTMLElement): () => void {
    const onDown = (e: KeyboardEvent) => {
      if (!this.enabled) return;
      this.keys.add(e.code);
      if (GAME_CODES.has(e.code)) e.preventDefault();
    };
    const onUp = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    };
    const clear = () => this.keys.clear();
    const onMouse = (e: MouseEvent) => {
      if (!this.enabled) return;
      if (e.buttons === 1 || document.pointerLockElement === el) {
        this.lookAcc.x += e.movementX;
        this.lookAcc.y += e.movementY;
      }
    };
    window.addEventListener("keydown", onDown);
    window.addEventListener("keyup", onUp);
    window.addEventListener("blur", clear);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) clear();
    });
    el.addEventListener("mousemove", onMouse);
    return () => {
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
      el.removeEventListener("mousemove", onMouse);
    };
  }

  setKeys(codes: string[]): void {
    this.injected = codes;
  }

  consumeLook(): { x: number; y: number } {
    const v = { x: this.lookAcc.x + this.look.x * 14, y: this.lookAcc.y + this.look.y * 14 };
    this.lookAcc.x = 0;
    this.lookAcc.y = 0;
    return v;
  }

  sample(): Actions {
    const held = this.injected ? new Set(this.injected) : this.keys;
    let mx = this.stick.x;
    let my = -this.stick.y;
    if (held.has("KeyD") || held.has("ArrowRight")) mx += 1;
    if (held.has("KeyA") || held.has("ArrowLeft")) mx -= 1;
    if (held.has("KeyW") || held.has("ArrowUp")) my += 1;
    if (held.has("KeyS") || held.has("ArrowDown")) my -= 1;

    try {
      const pads = navigator.getGamepads?.() ?? [];
      const pad = pads.find((p) => p && p.mapping === "standard");
      if (pad) {
        const st = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
        mx += st.x;
        my -= st.y;
        const look = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0, 0.12);
        this.lookAcc.x += look.x * 18;
        this.lookAcc.y += look.y * 12;
        if (pad.buttons[0]?.pressed) this.interactHeld = true;
        if (pad.buttons[1]?.pressed) this.sprintTouch = true;
      }
    } catch {
      /* ignore */
    }

    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }

    const interact = this.interactHeld || held.has("KeyE") || held.has("Space") || held.has("KeyF");
    const interactDown = interact && !this.interactWas;
    this.interactWas = interact;

    return {
      moveX: mx,
      moveY: my,
      lookX: 0,
      lookY: 0,
      sprint: this.sprintTouch || held.has("ShiftLeft") || held.has("ShiftRight"),
      interact,
      interactDown,
    };
  }
}
