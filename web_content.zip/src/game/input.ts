export type Btn = 'punch' | 'heavy' | 'kick' | 'special' | 'dodge';

export const input = {
  jx: 0,
  jy: 0,
  kx: 0,
  ky: 0,
  block: false,
  keyBlock: false,
  pressed: { punch: false, heavy: false, kick: false, special: false, dodge: false } as Record<Btn, boolean>,
  vibrate: true,
};

export function press(b: Btn) {
  input.pressed[b] = true;
  if (input.vibrate && typeof navigator !== 'undefined' && navigator.vibrate) {
    try { navigator.vibrate(8); } catch { /* ignore */ }
  }
}

export function consume(b: Btn) {
  const v = input.pressed[b];
  input.pressed[b] = false;
  return v;
}

export function clearInput() {
  input.jx = input.jy = input.kx = input.ky = 0;
  input.block = input.keyBlock = false;
  for (const k of Object.keys(input.pressed) as Btn[]) input.pressed[k] = false;
}

const keys = new Set<string>();
function recompute() {
  input.kx = (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
  input.ky = (keys.has('s') || keys.has('arrowdown') ? 1 : 0) - (keys.has('w') || keys.has('arrowup') ? 1 : 0);
  input.keyBlock = keys.has('shift') || keys.has('b');
}
const map: Record<string, Btn> = { j: 'punch', k: 'heavy', l: 'kick', ' ': 'dodge', e: 'special', u: 'special', i: 'heavy' };

function down(e: KeyboardEvent) {
  const k = e.key.toLowerCase();
  if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
  if (!e.repeat && map[k]) press(map[k]);
  keys.add(k);
  recompute();
}
function up(e: KeyboardEvent) {
  keys.delete(e.key.toLowerCase());
  recompute();
}
function blur() { keys.clear(); recompute(); }

export function attachKeyboard() {
  window.addEventListener('keydown', down);
  window.addEventListener('keyup', up);
  window.addEventListener('blur', blur);
  return () => {
    window.removeEventListener('keydown', down);
    window.removeEventListener('keyup', up);
    window.removeEventListener('blur', blur);
  };
}
