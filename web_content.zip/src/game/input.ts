import type { TouchState } from "./types";

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "KeyR",
  "KeyF",
  "KeyE",
  "KeyQ",
  "KeyC",
  "KeyM",
  "Space",
  "ShiftLeft",
  "ShiftRight",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "Escape",
  "Tab",
  "KeyP",
  "KeyV",
]);

function radialDeadzone(x: number, y: number, dz = 0.16) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class Input {
  keys = new Set<string>();
  qaKeys: Set<string> | null = null;
  qaSteer: number | null = null;
  touch: TouchState = { throttle: 0, steer: 0, pitch: 0, boost: false, scan: false };
  scanEdge = false;
  warpEdge = false;
  pauseEdge = false;
  catalogEdge = false;
  muteEdge = false;
  dimensionEdge = false;
  prevScan = false;
  prevWarp = false;
  prevPause = false;
  prevCatalog = false;
  prevMute = false;
  prevDimension = false;
  private attached = false;

  private onDown = (e: KeyboardEvent) => {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    this.keys.add(e.code);
    if (GAME_CODES.has(e.code)) e.preventDefault();
  };

  private onUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => {
    this.keys.clear();
  };

  attach() {
    if (this.attached) return;
    this.attached = true;
    addEventListener("keydown", this.onDown);
    addEventListener("keyup", this.onUp);
    addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
  }

  detach() {
    if (!this.attached) return;
    this.attached = false;
    removeEventListener("keydown", this.onDown);
    removeEventListener("keyup", this.onUp);
    removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.keys.clear();
  }

  setKeys(codes: string[]) {
    this.qaKeys = new Set(codes);
  }

  setSteer(v: number) {
    this.qaSteer = v;
  }

  setTouch(next: Partial<TouchState>) {
    Object.assign(this.touch, next);
  }

  held(code: string) {
    const src = this.qaKeys ?? this.keys;
    return src.has(code);
  }

  sample() {
    const src = this.qaKeys ?? this.keys;
    let throttle = this.touch.throttle;
    if (src.has("KeyW")) throttle += 1;
    if (src.has("KeyS")) throttle -= 1;
    throttle = Math.max(-1, Math.min(1, throttle));

    let steer = this.touch.steer;
    if (src.has("KeyA") || src.has("ArrowLeft")) steer += 1;
    if (src.has("KeyD") || src.has("ArrowRight")) steer -= 1;
    if (this.qaSteer !== null) steer = this.qaSteer;
    steer = Math.max(-1, Math.min(1, steer));

    let pitch = this.touch.pitch;
    if (src.has("KeyR") || src.has("ArrowUp")) pitch += 1;
    if (src.has("KeyF") || src.has("ArrowDown")) pitch -= 1;
    pitch = Math.max(-1, Math.min(1, pitch));

    let boost = this.touch.boost || src.has("ShiftLeft") || src.has("ShiftRight");
    let scan = this.touch.scan || src.has("KeyE") || src.has("Space");
    let warp = src.has("KeyQ");
    let pause = src.has("KeyP") || src.has("Escape");
    let catalog = src.has("KeyC") || src.has("Tab");
    let mute = src.has("KeyM");
    let dimension = src.has("KeyV");

    const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
    if (pads) {
      for (const pad of pads) {
        if (!pad || pad.mapping !== "standard") continue;
        const ls = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
        const rs = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0);
        steer += -ls.x;
        throttle += -ls.y;
        pitch += -rs.y;
        if (pad.buttons[7]?.value > 0.4 || pad.buttons[0]?.pressed) boost = true;
        if (pad.buttons[2]?.pressed) scan = true;
        if (pad.buttons[3]?.pressed) warp = true;
        if (pad.buttons[9]?.pressed) pause = true;
        if (pad.buttons[8]?.pressed) catalog = true;
      }
    }

    throttle = Math.max(-1, Math.min(1, throttle));
    steer = Math.max(-1, Math.min(1, steer));
    pitch = Math.max(-1, Math.min(1, pitch));

    this.scanEdge = scan && !this.prevScan;
    this.warpEdge = warp && !this.prevWarp;
    this.pauseEdge = pause && !this.prevPause;
    this.catalogEdge = catalog && !this.prevCatalog;
    this.muteEdge = mute && !this.prevMute;
    this.dimensionEdge = dimension && !this.prevDimension;
    this.prevScan = scan;
    this.prevWarp = warp;
    this.prevPause = pause;
    this.prevCatalog = catalog;
    this.prevMute = mute;
    this.prevDimension = dimension;

    return { throttle, steer, pitch, boost, scan };
  }
}
