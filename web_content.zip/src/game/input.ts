const MOVE: Record<string, [number, number]> = {
  KeyW: [0, 1], ArrowUp: [0, 1],
  KeyS: [0, -1], ArrowDown: [0, -1],
  KeyA: [-1, 0], ArrowLeft: [-1, 0],
  KeyD: [1, 0], ArrowRight: [1, 0],
};
const ACTIONS: Record<string, string> = {
  Space: 'jump',
  KeyR: 'reload',
  KeyE: 'pick',
  KeyF: 'heal',
  Digit1: 'slot0',
  Digit2: 'slot1',
  KeyQ: 'swap',
};

export interface InputFrame {
  move: { x: number; y: number };
  look: { x: number; y: number };
  fire: boolean;
  ads: boolean;
  sprint: boolean;
  actions: string[];
}

function isTyping(t: EventTarget | null): boolean {
  return t instanceof HTMLElement && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
}

/**
 * Unified input. Keyboard (WASD/arrows), mouse (pointer-locked look, hold to fire,
 * right-click to aim) and touch (joystick and look delta set by the touch overlay).
 */
export class Input {
  private keys = new Set<string>();
  private joyX = 0;
  private joyY = 0;
  private look = { x: 0, y: 0 };
  private mouseFire = false;
  private mouseAds = false;
  private touchFire = false;
  private touchAds = false;
  private queued: string[] = [];
  private el: HTMLElement | null = null;
  locked = false;
  onLockChange: ((locked: boolean) => void) | null = null;

  attach(el: HTMLElement) {
    this.el = el;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    window.addEventListener('mousemove', this.onMouseMove);
    window.addEventListener('mouseup', this.onMouseUp);
    el.addEventListener('mousedown', this.onMouseDown);
    el.addEventListener('contextmenu', this.onContext);
    document.addEventListener('pointerlockchange', this.onLockChanged);
  }

  detach() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mouseup', this.onMouseUp);
    document.removeEventListener('pointerlockchange', this.onLockChanged);
    this.el?.removeEventListener('mousedown', this.onMouseDown);
    this.el?.removeEventListener('contextmenu', this.onContext);
    this.el = null;
    this.reset();
  }

  reset() {
    this.keys.clear();
    this.joyX = 0;
    this.joyY = 0;
    this.mouseFire = false;
    this.mouseAds = false;
    this.touchFire = false;
    this.touchAds = false;
    this.queued = [];
  }

  releaseLock() {
    if (document.pointerLockElement) document.exitPointerLock();
  }

  // ---- touch API (called by the touch overlay) ----
  setJoy(x: number, y: number) {
    this.joyX = x;
    this.joyY = y;
  }
  addLook(dx: number, dy: number) {
    this.look.x += dx;
    this.look.y += dy;
  }
  setTouchFire(on: boolean) {
    this.touchFire = on;
  }
  setTouchAds(on: boolean) {
    this.touchAds = on;
  }
  queue(action: string) {
    this.queued.push(action);
  }

  /** Called once per simulation step. Returns this step's intent and clears one-shot inputs. */
  consume(): InputFrame {
    let mx = 0;
    let my = 0;
    this.keys.forEach((k) => {
      const m = MOVE[k];
      if (m) {
        mx += m[0];
        my += m[1];
      }
    });
    mx += this.joyX;
    my += this.joyY;
    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }
    const frame: InputFrame = {
      move: { x: mx, y: my },
      look: { x: this.look.x, y: this.look.y },
      fire: this.mouseFire || this.touchFire,
      ads: this.mouseAds || this.touchAds,
      sprint: this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || Math.hypot(this.joyX, this.joyY) > 0.92,
      actions: this.queued.splice(0),
    };
    this.look.x = 0;
    this.look.y = 0;
    return frame;
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (isTyping(e.target)) return;
    if (MOVE[e.code] || ACTIONS[e.code]) e.preventDefault();
    if (!e.repeat && ACTIONS[e.code]) this.queued.push(ACTIONS[e.code]);
    this.keys.add(e.code);
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onBlur = () => this.reset();

  private onContext = (e: Event) => e.preventDefault();

  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 0) {
      this.mouseFire = true;
      if (!this.locked && this.el && this.el.requestPointerLock) {
        try {
          this.el.requestPointerLock();
        } catch {
          /* not supported */
        }
      }
    } else if (e.button === 2) {
      this.mouseAds = true;
    }
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.mouseFire = false;
    if (e.button === 2) this.mouseAds = false;
  };

  private onMouseMove = (e: MouseEvent) => {
    if (this.locked || this.mouseFire || this.mouseAds) {
      this.look.x += e.movementX;
      this.look.y += e.movementY;
    }
  };

  private onLockChanged = () => {
    const now = document.pointerLockElement === this.el;
    if (now === this.locked) return;
    this.locked = now;
    this.onLockChange?.(now);
  };
}
