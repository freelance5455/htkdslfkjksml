import { store, type Action } from './save';

export type TouchAction = Action | 'fire' | 'ads' | 'pause' | 'swap';

/** Shared touch state written by the TouchControls component (no React re-renders) */
export const touchState = {
  moveX: 0, moveY: 0, lookDX: 0, lookDY: 0,
  held: new Set<TouchAction>(), pressed: new Set<TouchAction>(),
  active: false,
  reset() { this.moveX = this.moveY = this.lookDX = this.lookDY = 0; this.held.clear(); this.pressed.clear(); },
};

export class Input {
  keys = new Set<string>();
  pressedKeys = new Set<string>();
  mouseButtons = new Set<number>();
  mousePressed = new Set<number>();
  dx = 0; dy = 0;
  locked = false;
  wheel = 0;
  private el: HTMLElement;
  private fallbackLook = false;
  onLockChange: (locked: boolean) => void = () => {};

  constructor(el: HTMLElement) {
    this.el = el;
    window.addEventListener('keydown', this.kd);
    window.addEventListener('keyup', this.ku);
    window.addEventListener('blur', this.blur);
    el.addEventListener('mousedown', this.md);
    window.addEventListener('mouseup', this.mu);
    window.addEventListener('mousemove', this.mm);
    el.addEventListener('wheel', this.wh, { passive: true });
    el.addEventListener('contextmenu', this.cm);
    document.addEventListener('pointerlockchange', this.plc);
  }
  dispose() {
    window.removeEventListener('keydown', this.kd); window.removeEventListener('keyup', this.ku); window.removeEventListener('blur', this.blur);
    this.el.removeEventListener('mousedown', this.md); window.removeEventListener('mouseup', this.mu); window.removeEventListener('mousemove', this.mm);
    this.el.removeEventListener('wheel', this.wh); this.el.removeEventListener('contextmenu', this.cm);
    document.removeEventListener('pointerlockchange', this.plc);
    if (document.pointerLockElement) document.exitPointerLock();
  }
  requestLock() {
    try {
      const r = this.el.requestPointerLock() as unknown as Promise<void> | undefined;
      if (r && typeof r.catch === 'function') r.catch(() => { this.fallbackLook = true; });
    } catch { this.fallbackLook = true; }
  }
  private kd = (e: KeyboardEvent) => {
    if (e.code === 'Tab' || e.code === 'Space' || e.code.startsWith('Arrow')) e.preventDefault();
    if (!this.keys.has(e.code)) this.pressedKeys.add(e.code);
    this.keys.add(e.code);
  };
  private ku = (e: KeyboardEvent) => { this.keys.delete(e.code); };
  private blur = () => { this.keys.clear(); this.mouseButtons.clear(); };
  private md = (e: MouseEvent) => { this.mouseButtons.add(e.button); this.mousePressed.add(e.button); };
  private mu = (e: MouseEvent) => { this.mouseButtons.delete(e.button); };
  private mm = (e: MouseEvent) => { if (this.locked || this.fallbackLook) { this.dx += e.movementX || 0; this.dy += e.movementY || 0; } };
  private wh = (e: WheelEvent) => { this.wheel += Math.sign(e.deltaY); };
  private cm = (e: Event) => e.preventDefault();
  private plc = () => { this.locked = document.pointerLockElement === this.el; if (this.locked) this.fallbackLook = false; this.onLockChange(this.locked); };

  private code(a: Action) { return store.settings.controls.bindings[a]; }
  down(a: Action): boolean {
    const c = this.code(a);
    if (a === 'sprint' && (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')) && c === 'ShiftLeft') return true;
    return this.keys.has(c) || touchState.held.has(a);
  }
  pressed(a: Action): boolean { return this.pressedKeys.has(this.code(a)) || touchState.pressed.has(a); }
  get fire() { return this.mouseButtons.has(0) || touchState.held.has('fire'); }
  get firePressed() { return this.mousePressed.has(0) || touchState.pressed.has('fire'); }
  get ads() { return this.mouseButtons.has(2) || touchState.held.has('ads'); }
  get adsPressed() { return this.mousePressed.has(2) || touchState.pressed.has('ads'); }
  /** call at end of frame */
  endFrame() { this.pressedKeys.clear(); this.mousePressed.clear(); this.dx = 0; this.dy = 0; this.wheel = 0; touchState.pressed.clear(); touchState.lookDX = 0; touchState.lookDY = 0; }
  releaseAll() { this.keys.clear(); this.mouseButtons.clear(); touchState.reset(); }
}
