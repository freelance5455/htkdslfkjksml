export type Actions = {
  moveX: number;
  moveY: number;
  sprint: boolean;
  pass: boolean;
  through: boolean;
  shoot: boolean;
  shootHeld: boolean;
  tackle: boolean;
  switchP: boolean;
  pause: boolean;
};

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowLeft",
  "ArrowDown",
  "ArrowRight",
  "ShiftLeft",
  "ShiftRight",
  "Space",
  "KeyJ",
  "KeyK",
  "KeyL",
  "KeyF",
  "KeyE",
  "KeyQ",
  "ControlLeft",
  "ControlRight",
  "Escape",
  "KeyP",
]);

function radialDeadzone(x: number, y: number, dz = 0.15) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export class Input {
  keys = new Set<string>();
  injected: string[] | null = null;
  stickX = 0;
  stickY = 0;
  touch = {
    sprint: false,
    pass: false,
    through: false,
    shoot: false,
    tackle: false,
    switchP: false,
  };
  private prevPass = false;
  private prevThrough = false;
  private prevShoot = false;
  private prevTackle = false;
  private prevSwitch = false;
  private prevPause = false;
  private attached = false;

  attach() {
    if (this.attached) return;
    this.attached = true;
    this.onKeyDown = this.onKeyDown.bind(this);
    this.onKeyUp = this.onKeyUp.bind(this);
    this.onBlur = this.onBlur.bind(this);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onBlur);
  }

  detach() {
    if (!this.attached) return;
    this.attached = false;
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onBlur);
    this.keys.clear();
  }

  setKeys(codes: string[]) {
    this.injected = codes;
  }

  private onKeyDown(e: KeyboardEvent) {
    if (GAME_CODES.has(e.code)) e.preventDefault();
    this.keys.add(e.code);
  }

  private onKeyUp(e: KeyboardEvent) {
    this.keys.delete(e.code);
  }

  private onBlur() {
    this.keys.clear();
  }

  private held(code: string) {
    if (this.injected) return this.injected.includes(code);
    return this.keys.has(code);
  }

  samplePad(): { x: number; y: number; sprint: boolean; pass: boolean; through: boolean; shoot: boolean; tackle: boolean; switchP: boolean; pause: boolean } {
    const pads = navigator.getGamepads?.() ?? [];
    let x = 0;
    let y = 0;
    let sprint = false;
    let pass = false;
    let through = false;
    let shoot = false;
    let tackle = false;
    let switchP = false;
    let pause = false;
    for (const pad of pads) {
      if (!pad) continue;
      const st = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0, 0.18);
      if (Math.hypot(st.x, st.y) > Math.hypot(x, y)) {
        x = st.x;
        y = st.y;
      }
      const b = pad.buttons;
      if (b[0]?.pressed) pass = true;
      if (b[1]?.pressed) shoot = true;
      if (b[2]?.pressed) through = true;
      if (b[3]?.pressed) switchP = true;
      if (b[5]?.pressed || (b[7]?.value ?? 0) > 0.4) sprint = true;
      if (b[4]?.pressed) tackle = true;
      if (b[9]?.pressed) pause = true;
      if (b[12]?.pressed) y -= 1;
      if (b[13]?.pressed) y += 1;
      if (b[14]?.pressed) x -= 1;
      if (b[15]?.pressed) x += 1;
    }
    return { x, y, sprint, pass, through, shoot, tackle, switchP, pause };
  }

  sample(): Actions {
    const pad = this.samplePad();
    let mx = 0;
    let my = 0;
    if (this.held("KeyA") || this.held("ArrowLeft")) mx -= 1;
    if (this.held("KeyD") || this.held("ArrowRight")) mx += 1;
    if (this.held("KeyW") || this.held("ArrowUp")) my -= 1;
    if (this.held("KeyS") || this.held("ArrowDown")) my += 1;
    mx += this.stickX + pad.x;
    my += this.stickY + pad.y;
    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }

    const passDown =
      this.held("Space") || this.held("KeyJ") || this.touch.pass || pad.pass;
    const throughDown = this.held("KeyK") || this.touch.through || pad.through;
    const shootDown = this.held("KeyL") || this.held("KeyF") || this.touch.shoot || pad.shoot;
    const tackleDown =
      this.held("ControlLeft") || this.held("ControlRight") || this.touch.tackle || pad.tackle;
    const switchDown = this.held("KeyE") || this.held("KeyQ") || this.touch.switchP || pad.switchP;
    const pauseDown = this.held("Escape") || this.held("KeyP") || pad.pause;

    const actions: Actions = {
      moveX: mx,
      moveY: my,
      sprint: this.held("ShiftLeft") || this.held("ShiftRight") || this.touch.sprint || pad.sprint,
      pass: passDown && !this.prevPass,
      through: throughDown && !this.prevThrough,
      shoot: !shootDown && this.prevShoot,
      shootHeld: shootDown,
      tackle: tackleDown && !this.prevTackle,
      switchP: switchDown && !this.prevSwitch,
      pause: pauseDown && !this.prevPause,
    };

    this.prevPass = passDown;
    this.prevThrough = throughDown;
    this.prevShoot = shootDown;
    this.prevTackle = tackleDown;
    this.prevSwitch = switchDown;
    this.prevPause = pauseDown;
    return actions;
  }
}
