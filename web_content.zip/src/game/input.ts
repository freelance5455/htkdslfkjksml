export interface InputState {
  left: boolean;
  right: boolean;
  accel: boolean;
  brake: boolean;
  boost: boolean;
}

export const input: InputState = {
  left: false,
  right: false,
  accel: false,
  brake: false,
  boost: false,
};

type Action = "confirm" | "pause";

const keyMap: Record<string, keyof InputState> = {
  ArrowLeft: "left",
  a: "left",
  A: "left",
  ArrowRight: "right",
  d: "right",
  D: "right",
  ArrowUp: "accel",
  w: "accel",
  W: "accel",
  ArrowDown: "brake",
  s: "brake",
  S: "brake",
  Shift: "boost",
  " ": "boost",
};

export function resetInput() {
  input.left = false;
  input.right = false;
  input.accel = false;
  input.brake = false;
  input.boost = false;
}

export function attachInput(onAction?: (action: Action) => void) {
  const onKeyDown = (e: KeyboardEvent) => {
    const mapped = keyMap[e.key];
    if (mapped) {
      input[mapped] = true;
      if (e.key !== " ") e.preventDefault();
    }
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      if (!e.repeat) onAction?.("confirm");
    }
    if (e.key === "p" || e.key === "P") onAction?.("pause");
  };

  const onKeyUp = (e: KeyboardEvent) => {
    const mapped = keyMap[e.key];
    if (mapped) {
      input[mapped] = false;
      if (e.key !== " ") e.preventDefault();
    }
  };

  const onBlur = () => resetInput();

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);

  return () => {
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", onBlur);
  };
}
