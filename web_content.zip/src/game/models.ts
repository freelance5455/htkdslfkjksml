import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import type { Team } from "./types";

/* ------------------------------------------------------------------ */
/* Shared materials & geometry                                         */
/* ------------------------------------------------------------------ */

const gradientData = new Uint8Array([70, 135, 200, 255]);
const gradientMap = new THREE.DataTexture(gradientData, gradientData.length, 1, THREE.RedFormat);
gradientMap.minFilter = THREE.NearestFilter;
gradientMap.magFilter = THREE.NearestFilter;
gradientMap.needsUpdate = true;

const matCache = new Map<string, THREE.MeshToonMaterial>();

export function toon(color: number, opts: { emissive?: number; emissiveIntensity?: number; map?: THREE.Texture | null; transparent?: boolean; opacity?: number } = {}) {
  const key = `${color}-${opts.emissive ?? 0}-${opts.emissiveIntensity ?? 0}-${opts.map?.uuid ?? "none"}-${opts.transparent ? opts.opacity : 1}`;
  const cached = matCache.get(key);
  if (cached) return cached;
  const mat = new THREE.MeshToonMaterial({
    color,
    gradientMap,
    map: opts.map ?? null,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
  });
  matCache.set(key, mat);
  return mat;
}

export function flat(color: number, opts: { transparent?: boolean; opacity?: number; side?: THREE.Side; map?: THREE.Texture | null } = {}) {
  return new THREE.MeshBasicMaterial({
    color,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
    map: opts.map ?? null,
    depthWrite: !(opts.transparent ?? false),
  });
}

const geoCache = new Map<string, THREE.BufferGeometry>();

export function roundedGeo(w: number, h: number, d: number, r = 0.08) {
  const key = `r${w.toFixed(2)}-${h.toFixed(2)}-${d.toFixed(2)}-${r.toFixed(2)}`;
  let g = geoCache.get(key);
  if (!g) {
    g = new RoundedBoxGeometry(w, h, d, 2, Math.min(r, Math.min(w, h, d) / 2.05));
    geoCache.set(key, g);
  }
  return g;
}

export function boxGeo(w: number, h: number, d: number) {
  const key = `b${w}-${h}-${d}`;
  let g = geoCache.get(key);
  if (!g) {
    g = new THREE.BoxGeometry(w, h, d);
    geoCache.set(key, g);
  }
  return g;
}

export function cylGeo(rt: number, rb: number, h: number, seg = 8) {
  const key = `c${rt}-${rb}-${h}-${seg}`;
  let g = geoCache.get(key);
  if (!g) {
    g = new THREE.CylinderGeometry(rt, rb, h, seg);
    geoCache.set(key, g);
  }
  return g;
}

export function sphereGeo(r: number, seg = 10) {
  const key = `s${r}-${seg}`;
  let g = geoCache.get(key);
  if (!g) {
    g = new THREE.SphereGeometry(r, seg, Math.max(4, Math.floor(seg * 0.7)));
    geoCache.set(key, g);
  }
  return g;
}

export function coneGeo(r: number, h: number, seg = 6) {
  const key = `k${r}-${h}-${seg}`;
  let g = geoCache.get(key);
  if (!g) {
    g = new THREE.ConeGeometry(r, h, seg);
    geoCache.set(key, g);
  }
  return g;
}

export function part(parent: THREE.Object3D, geo: THREE.BufferGeometry, material: THREE.Material, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  parent.add(m);
  return m;
}

const outlineMaterial = new THREE.MeshBasicMaterial({ color: 0x241a35, side: THREE.BackSide });

export function addOutline(mesh: THREE.Mesh, scale = 1.06) {
  const o = new THREE.Mesh(mesh.geometry, outlineMaterial);
  o.scale.setScalar(scale);
  o.renderOrder = -1;
  mesh.add(o);
  return o;
}

function mergeDirectMeshes(group: THREE.Group, outline = false) {
  const meshes = group.children.filter((child): child is THREE.Mesh => (child as THREE.Mesh).isMesh);
  if (meshes.length < 2) return;
  const byMaterial = new Map<THREE.Material, { mesh: THREE.Mesh; geo: THREE.BufferGeometry }[]>();
  for (const mesh of meshes) {
    let geo = mesh.geometry.clone();
    if (geo.index) {
      const nonIndexed = geo.toNonIndexed();
      geo.dispose();
      geo = nonIndexed;
    }
    mesh.updateMatrix();
    geo.applyMatrix4(mesh.matrix);
    const material = mesh.material as THREE.Material;
    if (!byMaterial.has(material)) byMaterial.set(material, []);
    byMaterial.get(material)!.push({ mesh, geo });
  }
  const mergedMeshes: THREE.Mesh[] = [];
  const mergedGeos: THREE.BufferGeometry[] = [];
  for (const [material, items] of byMaterial) {
    const geometry = mergeGeometries(items.map((item) => item.geo), false);
    for (const item of items) item.geo.dispose();
    if (!geometry) {
      for (const mesh of mergedMeshes) {
        group.remove(mesh);
        mesh.geometry.dispose();
      }
      return;
    }
    const mesh = new THREE.Mesh(geometry, material);
    mergedMeshes.push(mesh);
    mergedGeos.push(geometry);
  }
  for (const mesh of meshes) group.remove(mesh);
  for (const mesh of mergedMeshes) group.add(mesh);
  if (outline && mergedGeos.length) {
    const all = mergeGeometries(mergedGeos, false);
    if (all) {
      const outlineMesh = new THREE.Mesh(all, outlineMaterial);
      outlineMesh.scale.setScalar(1.045);
      outlineMesh.renderOrder = -1;
      group.add(outlineMesh);
    }
  }
}

export function shadowBlob(radius = 0.55, opacity = 0.22) {
  const m = new THREE.Mesh(
    new THREE.CircleGeometry(radius, 16),
    new THREE.MeshBasicMaterial({ color: 0x1b1430, transparent: true, opacity, depthWrite: false })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.02;
  m.renderOrder = 1;
  return m;
}

/* ------------------------------------------------------------------ */
/* Canvas textures                                                     */
/* ------------------------------------------------------------------ */

export function canvasTexture(w: number, h: number, draw: (ctx: CanvasRenderingContext2D) => void) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d");
  if (ctx) draw(ctx);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

const crateTexCache = new Map<string, THREE.Texture>();
export function crateTexture(base = "#d99a4e", dark = "#8a5426") {
  const key = base + dark;
  const hit = crateTexCache.get(key);
  if (hit) return hit;
  const tex = canvasTexture(256, 256, (ctx) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 90; i++) {
      ctx.fillStyle = `rgba(90,50,20,${Math.random() * 0.09})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 20 + Math.random() * 50, 2);
    }
    ctx.strokeStyle = dark;
    ctx.lineWidth = 16;
    ctx.strokeRect(8, 8, 240, 240);
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(16, 16);
    ctx.lineTo(240, 240);
    ctx.moveTo(240, 16);
    ctx.lineTo(16, 240);
    ctx.stroke();
    ctx.fillStyle = "#f7d9a0";
    ctx.fillRect(96, 96, 64, 64);
    ctx.fillStyle = dark;
    ctx.font = "bold 42px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("T", 128, 142);
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.fillRect(16, 16, 224, 6);
  });
  crateTexCache.set(key, tex);
  return tex;
}

const barrelTexCache = new Map<string, THREE.Texture>();
export function barrelTexture(base = "#ef6a4c") {
  const hit = barrelTexCache.get(base);
  if (hit) return hit;
  const tex = canvasTexture(256, 256, (ctx) => {
    const grad = ctx.createLinearGradient(0, 0, 256, 0);
    grad.addColorStop(0, "#00000033");
    grad.addColorStop(0.25, "#ffffff22");
    grad.addColorStop(0.55, "#00000000");
    grad.addColorStop(1, "#00000044");
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = "#2b2540";
    ctx.fillRect(0, 30, 256, 18);
    ctx.fillRect(0, 208, 256, 18);
    ctx.fillStyle = "#ffd45e";
    ctx.beginPath();
    ctx.moveTo(128, 74);
    ctx.lineTo(176, 166);
    ctx.lineTo(80, 166);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#2b2540";
    ctx.font = "bold 54px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("!", 128, 156);
  });
  barrelTexCache.set(base, tex);
  return tex;
}

const facadeCache = new Map<string, THREE.Texture>();
export function facadeTexture(wall: string, accent: string, trim: string, variant = 0) {
  const key = wall + accent + trim + variant;
  const hit = facadeCache.get(key);
  if (hit) return hit;
  const tex = canvasTexture(256, 256, (ctx) => {
    ctx.fillStyle = wall;
    ctx.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 50; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 30, 3);
    }
    ctx.fillStyle = trim;
    ctx.fillRect(0, 0, 256, 16);
    ctx.fillRect(0, 240, 256, 16);
    const drawWindow = (x: number, y: number, w: number, h: number) => {
      ctx.fillStyle = trim;
      roundRect(ctx, x - 5, y - 5, w + 10, h + 10, 6);
      ctx.fill();
      const g = ctx.createLinearGradient(x, y, x + w, y + h);
      g.addColorStop(0, "#7fe6e0");
      g.addColorStop(1, "#2b8fa8");
      ctx.fillStyle = g;
      roundRect(ctx, x, y, w, h, 4);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.beginPath();
      ctx.moveTo(x + 6, y + h - 6);
      ctx.lineTo(x + w * 0.55, y + 6);
      ctx.lineTo(x + w * 0.8, y + 6);
      ctx.lineTo(x + 6, y + h * 0.55);
      ctx.closePath();
      ctx.fill();
    };
    if (variant % 2 === 0) {
      drawWindow(34, 52, 58, 52);
      drawWindow(164, 52, 58, 52);
      drawWindow(34, 142, 58, 52);
      drawWindow(164, 142, 58, 52);
    } else {
      drawWindow(30, 46, 84, 62);
      drawWindow(148, 46, 78, 62);
      drawWindow(30, 140, 84, 62);
      drawWindow(148, 140, 78, 62);
    }
    ctx.fillStyle = accent;
    ctx.fillRect(0, 108, 256, 14);
    ctx.fillStyle = trim;
    ctx.fillRect(96, 196, 64, 60);
    ctx.fillStyle = accent;
    ctx.fillRect(104, 204, 48, 52);
  });
  facadeCache.set(key, tex);
  return tex;
}

/* ------------------------------------------------------------------ */
/* Characters                                                          */
/* ------------------------------------------------------------------ */

export interface CharacterPalette {
  primary: number;
  secondary: number;
  accent: number;
  dark: number;
  belly: number;
}

export const FOX_PALETTE: CharacterPalette = {
  primary: 0xf28b3c,
  secondary: 0xffd9a0,
  accent: 0x1fb9ad,
  dark: 0x2b2540,
  belly: 0xfff1d6,
};

export interface CharacterRig {
  group: THREE.Group;
  body: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  tail: THREE.Group;
  weaponMount: THREE.Group;
  muzzle: THREE.Object3D;
  tag: THREE.Sprite | null;
  healthBar: THREE.Sprite | null;
  healthBarBg: THREE.Sprite | null;
  height: number;
  radius: number;
  headHeight: number;
}

function makeNameTag(name: string, color: string) {
  const tex = canvasTexture(256, 64, (ctx) => {
    ctx.clearRect(0, 0, 256, 64);
    ctx.fillStyle = "rgba(30,24,48,0.82)";
    roundRect(ctx, 6, 8, 244, 44, 14);
    ctx.fill();
    ctx.fillStyle = color;
    roundRect(ctx, 6, 8, 12, 44, 6);
    ctx.fill();
    ctx.fillStyle = "#fff8ec";
    ctx.font = "bold 26px Rubik, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(name.slice(0, 12), 136, 31);
  });
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest: false }));
  sprite.scale.set(1.9, 0.475, 1);
  sprite.position.y = 2.42;
  sprite.renderOrder = 20;
  return sprite;
}

function makeBar(color: number, width: number, height: number) {
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ color, transparent: true, depthWrite: false, depthTest: false }));
  sprite.center.set(0, 0.5);
  sprite.scale.set(width, height, 1);
  sprite.renderOrder = 21;
  return sprite;
}

export function createCharacter(palette: CharacterPalette, name: string, team: Team | "none", isPlayer = false, outline = true): CharacterRig {
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);
  group.add(shadowBlob(0.62, 0.24));

  const primary = toon(palette.primary);
  const secondary = toon(palette.secondary);
  const accent = toon(palette.accent);
  const dark = toon(palette.dark);
  const belly = toon(palette.belly);

  // legs
  const legL = new THREE.Group();
  const legR = new THREE.Group();
  legL.position.set(-0.17, 0.6, 0);
  legR.position.set(0.17, 0.6, 0);
  body.add(legL, legR);
  for (const [leg, side] of [
    [legL, -1],
    [legR, 1],
  ] as const) {
    part(leg, roundedGeo(0.23, 0.48, 0.26, 0.08), primary, 0, -0.24, 0);
    part(leg, roundedGeo(0.27, 0.16, 0.42, 0.07), dark, 0, -0.5, 0.07);
    part(leg, roundedGeo(0.28, 0.07, 0.2, 0.03), accent, 0, -0.43, -0.02);
    void side;
  }

  // torso
  part(body, roundedGeo(0.66, 0.64, 0.44, 0.14), primary, 0, 0.98, 0);
  part(body, roundedGeo(0.42, 0.42, 0.08, 0.1), belly, 0, 0.94, 0.22);
  part(body, roundedGeo(0.7, 0.18, 0.48, 0.06), accent, 0, 1.06, 0);
  part(body, roundedGeo(0.16, 0.2, 0.1, 0.03), dark, 0.22, 1.07, 0.25);
  part(body, roundedGeo(0.4, 0.42, 0.22, 0.08), dark, 0, 1.0, -0.3);
  part(body, cylGeo(0.07, 0.07, 0.34, 8), accent, -0.12, 1.06, -0.43);
  part(body, cylGeo(0.07, 0.07, 0.34, 8), toon(0xffd45e), 0.12, 1.06, -0.43);

  // scarf
  const scarf = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.075, 6, 12), accent);
  scarf.rotation.x = Math.PI / 2;
  scarf.position.y = 1.3;
  body.add(scarf);
  const scarfTail = part(body, roundedGeo(0.16, 0.5, 0.08, 0.04), accent, 0.16, 1.08, -0.3);
  scarfTail.rotation.z = -0.25;

  // head
  const head = new THREE.Group();
  head.position.y = 1.5;
  body.add(head);
  part(head, roundedGeo(0.54, 0.48, 0.5, 0.16), primary, 0, 0.12, 0);
  part(head, roundedGeo(0.28, 0.2, 0.2, 0.08), secondary, 0, 0.03, 0.28);
  part(head, roundedGeo(0.1, 0.08, 0.08, 0.03), dark, 0, 0.07, 0.39);
  part(head, roundedGeo(0.2, 0.05, 0.04, 0.02), dark, 0, -0.03, 0.36);
  // eyes
  for (const s of [-1, 1]) {
    part(head, sphereGeo(0.085, 8), toon(0xfffaf0), s * 0.13, 0.17, 0.235);
    part(head, sphereGeo(0.045, 8), dark, s * 0.13, 0.17, 0.3);
    part(head, sphereGeo(0.016, 6), toon(0xffffff), s * 0.115, 0.19, 0.335);
    // ear
    const ear = part(head, coneGeo(0.14, 0.34, 4), primary, s * 0.18, 0.44, -0.02);
    ear.rotation.z = s * -0.18;
    const inner = part(head, coneGeo(0.075, 0.22, 4), toon(0xff9db0), s * 0.18, 0.43, 0.02);
    inner.rotation.z = s * -0.18;
  }
  // goggles on forehead
  part(head, roundedGeo(0.5, 0.1, 0.1, 0.03), dark, 0, 0.32, 0.2);
  for (const s of [-1, 1]) {
    const lens = part(head, cylGeo(0.1, 0.1, 0.06, 10), toon(0x6ff2e4, { emissive: 0x1b8f88, emissiveIntensity: 0.5 }), s * 0.13, 0.33, 0.27);
    lens.rotation.x = Math.PI / 2;
  }
  // tuft
  const tuft = part(head, coneGeo(0.1, 0.24, 5), secondary, 0, 0.4, 0.12);
  tuft.rotation.x = -0.4;

  // arms
  const armL = new THREE.Group();
  const armR = new THREE.Group();
  armL.position.set(-0.4, 1.18, 0);
  armR.position.set(0.4, 1.18, 0);
  body.add(armL, armR);
  for (const arm of [armL, armR]) {
    part(arm, roundedGeo(0.17, 0.46, 0.19, 0.07), primary, 0, -0.2, 0);
    part(arm, sphereGeo(0.115, 8), secondary, 0, -0.45, 0);
  }
  armL.rotation.z = 0.45;
  armR.rotation.z = -0.08;

  const weaponMount = new THREE.Group();
  weaponMount.position.set(0, -0.47, 0.02);
  weaponMount.rotation.x = -Math.PI / 2;
  armR.add(weaponMount);
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0, -0.9);
  weaponMount.add(muzzle);

  // tail
  const tail = new THREE.Group();
  tail.position.set(0, 0.72, -0.24);
  body.add(tail);
  const tail1 = part(tail, roundedGeo(0.2, 0.2, 0.42, 0.09), primary, 0, 0, -0.18);
  tail1.rotation.x = 0.25;
  const tail2 = part(tail, roundedGeo(0.17, 0.17, 0.36, 0.08), primary, 0, 0.12, -0.48);
  tail2.rotation.x = 0.5;
  part(tail, roundedGeo(0.16, 0.16, 0.2, 0.07), secondary, 0, 0.24, -0.68);

  let tag: THREE.Sprite | null = null;
  let healthBar: THREE.Sprite | null = null;
  let healthBarBg: THREE.Sprite | null = null;
  if (!isPlayer) {
    tag = makeNameTag(name, team === "sun" ? "#ffb43c" : team === "tide" ? "#39d6c8" : "#c6a6ff");
    group.add(tag);
    healthBarBg = makeBar(0x241a35, 1.04, 0.13);
    healthBarBg.position.set(-0.52, 2.16, 0);
    group.add(healthBarBg);
    healthBar = makeBar(team === "sun" ? 0xffb43c : team === "tide" ? 0x39d6c8 : 0xc6a6ff, 1, 0.09);
    healthBar.position.set(-0.5, 2.16, 0);
    group.add(healthBar);
  }

  mergeDirectMeshes(head, outline);
  mergeDirectMeshes(body, outline);

  return {
    group,
    body,
    head,
    armL,
    armR,
    legL,
    legR,
    tail,
    weaponMount,
    muzzle,
    tag,
    healthBar,
    healthBarBg,
    height: 1.9,
    radius: 0.42,
    headHeight: 1.62,
  };
}

/* ------------------------------------------------------------------ */
/* Weapons                                                             */
/* ------------------------------------------------------------------ */

export type WeaponId = "pulse" | "smg" | "shotgun" | "sniper" | "pistol" | "rocket";

export interface WeaponModel {
  group: THREE.Group;
  muzzle: THREE.Object3D;
  flash: THREE.Mesh;
}

export function createWeaponModel(id: WeaponId): WeaponModel {
  const group = new THREE.Group();
  const dark = toon(0x2b2540);
  const metal = toon(0x59617a);
  const accent = toon(id === "pulse" ? 0x3ce0cf : id === "shotgun" ? 0xffa63c : id === "sniper" ? 0x8f7bff : 0xff6b6b);
  const cream = toon(0xfff1d6);
  let muzzleZ = -0.9;

  if (id === "pulse") {
    part(group, roundedGeo(0.17, 0.2, 0.72, 0.05), dark, 0, 0, -0.18);
    part(group, roundedGeo(0.2, 0.08, 0.34, 0.03), accent, 0, 0.11, -0.22);
    part(group, cylGeo(0.035, 0.045, 0.46, 8), metal, 0, 0.02, -0.68).rotation.x = Math.PI / 2;
    part(group, roundedGeo(0.1, 0.24, 0.14, 0.03), dark, 0, -0.17, -0.02);
    part(group, roundedGeo(0.12, 0.2, 0.16, 0.03), accent, 0, -0.14, -0.26);
    part(group, roundedGeo(0.08, 0.1, 0.22, 0.02), metal, 0, 0.13, -0.38);
    part(group, roundedGeo(0.16, 0.16, 0.26, 0.05), dark, 0, -0.02, 0.24);
    muzzleZ = -0.94;
  } else if (id === "smg") {
    part(group, roundedGeo(0.16, 0.18, 0.5, 0.05), dark, 0, 0, -0.14);
    part(group, roundedGeo(0.18, 0.07, 0.26, 0.03), accent, 0, 0.1, -0.16);
    part(group, cylGeo(0.03, 0.035, 0.26, 8), metal, 0, 0.02, -0.48).rotation.x = Math.PI / 2;
    part(group, roundedGeo(0.09, 0.26, 0.12, 0.03), dark, 0, -0.17, 0.02);
    part(group, roundedGeo(0.1, 0.22, 0.12, 0.03), accent, 0, -0.16, -0.16);
    part(group, roundedGeo(0.14, 0.14, 0.2, 0.04), dark, 0, -0.02, 0.22);
    part(group, roundedGeo(0.05, 0.08, 0.16, 0.02), metal, 0, 0.13, -0.3);
    muzzleZ = -0.64;
  } else if (id === "shotgun") {
    part(group, roundedGeo(0.22, 0.2, 0.66, 0.06), dark, 0, 0, -0.2);
    for (const s of [-1, 1]) {
      const barrel = part(group, cylGeo(0.055, 0.055, 0.72, 8), metal, s * 0.065, 0.04, -0.62);
      barrel.rotation.x = Math.PI / 2;
    }
    part(group, roundedGeo(0.26, 0.14, 0.28, 0.05), accent, 0, -0.06, -0.42);
    part(group, roundedGeo(0.2, 0.24, 0.3, 0.06), toon(0xb06a34), 0, -0.05, 0.28);
    part(group, roundedGeo(0.1, 0.18, 0.12, 0.03), dark, 0, -0.18, -0.04);
    part(group, roundedGeo(0.06, 0.08, 0.1, 0.02), cream, 0, 0.14, -0.5);
    muzzleZ = -1.0;
  } else if (id === "sniper") {
    part(group, roundedGeo(0.16, 0.18, 0.9, 0.05), dark, 0, 0, -0.2);
    const barrel = part(group, cylGeo(0.03, 0.04, 0.95, 8), metal, 0, 0.03, -0.9);
    barrel.rotation.x = Math.PI / 2;
    part(group, cylGeo(0.075, 0.075, 0.34, 10), dark, 0, 0.16, -0.24).rotation.x = Math.PI / 2;
    part(group, cylGeo(0.085, 0.085, 0.05, 10), accent, 0, 0.16, -0.42).rotation.x = Math.PI / 2;
    part(group, roundedGeo(0.18, 0.22, 0.34, 0.06), toon(0x6b5a8f), 0, -0.04, 0.3);
    part(group, roundedGeo(0.1, 0.2, 0.12, 0.03), dark, 0, -0.17, -0.02);
    part(group, roundedGeo(0.05, 0.26, 0.05, 0.02), metal, -0.08, -0.2, -0.62);
    part(group, roundedGeo(0.05, 0.26, 0.05, 0.02), metal, 0.08, -0.2, -0.62);
    muzzleZ = -1.4;
  } else if (id === "pistol") {
    part(group, roundedGeo(0.14, 0.16, 0.42, 0.05), dark, 0, 0.02, -0.16);
    part(group, roundedGeo(0.15, 0.08, 0.36, 0.03), metal, 0, 0.1, -0.18);
    part(group, cylGeo(0.035, 0.035, 0.2, 8), metal, 0, 0.03, -0.42).rotation.x = Math.PI / 2;
    part(group, roundedGeo(0.11, 0.24, 0.14, 0.04), accent, 0, -0.15, 0.02);
    part(group, roundedGeo(0.04, 0.06, 0.08, 0.02), cream, 0, 0.15, -0.3);
    part(group, roundedGeo(0.1, 0.1, 0.16, 0.03), dark, 0, -0.02, 0.2);
    muzzleZ = -0.54;
  } else {
    part(group, cylGeo(0.11, 0.12, 0.95, 10), toon(0x4f7a4a), 0, 0, -0.25).rotation.x = Math.PI / 2;
    part(group, cylGeo(0.14, 0.14, 0.12, 10), dark, 0, 0, -0.7).rotation.x = Math.PI / 2;
    part(group, coneGeo(0.13, 0.3, 8), accent, 0, 0, -0.86).rotation.x = -Math.PI / 2;
    part(group, roundedGeo(0.12, 0.22, 0.14, 0.03), dark, 0, -0.17, -0.02);
    part(group, roundedGeo(0.16, 0.12, 0.26, 0.03), accent, 0, 0.13, -0.1);
    part(group, roundedGeo(0.2, 0.2, 0.26, 0.05), dark, 0, -0.02, 0.28);
    muzzleZ = -1.02;
  }

  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0.02, muzzleZ);
  group.add(muzzle);
  const flash = new THREE.Mesh(
    new THREE.SphereGeometry(0.13, 6, 4),
    new THREE.MeshBasicMaterial({ color: 0xffe6a0, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false })
  );
  flash.scale.set(1, 1, 2.4);
  flash.position.copy(muzzle.position);
  flash.visible = false;
  group.add(flash);
  return { group, muzzle, flash };
}

export function createBotWeaponModel(): WeaponModel {
  const group = new THREE.Group();
  part(group, roundedGeo(0.16, 0.18, 0.6, 0.05), toon(0x2b2540), 0, 0, -0.2);
  const barrel = part(group, cylGeo(0.035, 0.04, 0.4, 6), toon(0x59617a), 0, 0.02, -0.6);
  barrel.rotation.x = Math.PI / 2;
  part(group, roundedGeo(0.12, 0.08, 0.2, 0.03), toon(0x39d6c8), 0, 0.1, -0.2);
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0.02, -0.8);
  group.add(muzzle);
  const flash = new THREE.Mesh(
    new THREE.SphereGeometry(0.1, 5, 4),
    new THREE.MeshBasicMaterial({ color: 0xffe6a0, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false })
  );
  flash.position.copy(muzzle.position);
  flash.visible = false;
  group.add(flash);
  return { group, muzzle, flash };
}

/* ------------------------------------------------------------------ */
/* Vehicles                                                            */
/* ------------------------------------------------------------------ */

export interface VehicleModel {
  group: THREE.Group;
  body: THREE.Group;
  wheels: THREE.Object3D[];
  turret: THREE.Group | null;
  muzzle: THREE.Object3D | null;
  flag: THREE.Mesh | null;
}

function makeWheel(radius: number, width: number, x: number, y: number, z: number) {
  const pivot = new THREE.Group();
  pivot.position.set(x, y, z);
  const tire = new THREE.Mesh(cylGeo(radius, radius, width, 12), toon(0x2b2540));
  tire.rotation.z = Math.PI / 2;
  pivot.add(tire);
  const hub = new THREE.Mesh(cylGeo(radius * 0.48, radius * 0.48, width + 0.03, 8), toon(0xffd45e));
  hub.rotation.z = Math.PI / 2;
  pivot.add(hub);
  return pivot;
}

export function createVehicleModel(type: "buggy" | "tank", team: Team): VehicleModel {
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);
  group.add(shadowBlob(type === "buggy" ? 1.5 : 1.9, 0.26));
  const teamColor = team === "sun" ? 0xffb43c : 0x39d6c8;
  const wheels: THREE.Object3D[] = [];
  let turret: THREE.Group | null = null;
  let muzzle: THREE.Object3D | null = null;
  let flag: THREE.Mesh | null = null;

  if (type === "buggy") {
    const orange = toon(0xf07a35);
    const cream = toon(0xfff1d6);
    const dark = toon(0x2b2540);
    const accent = toon(teamColor);
    part(body, roundedGeo(1.7, 0.42, 2.9, 0.16), orange, 0, 0.68, 0);
    part(body, roundedGeo(1.5, 0.24, 0.9, 0.1), cream, 0, 0.9, -0.95);
    part(body, roundedGeo(1.3, 0.3, 1.2, 0.1), dark, 0, 0.92, 0.35);
    part(body, roundedGeo(0.9, 0.16, 0.7, 0.06), accent, 0, 1.08, 0.35);
    part(body, roundedGeo(0.7, 0.55, 0.16, 0.06), dark, 0, 1.2, 0.72).rotation.x = -0.2;
    // roll cage
    const barMat = toon(0x3b3550);
    for (const s of [-1, 1]) {
      const bar = part(body, cylGeo(0.055, 0.055, 1.25, 6), barMat, s * 0.62, 1.35, 0.5);
      bar.rotation.x = 0.22;
      const bar2 = part(body, cylGeo(0.05, 0.05, 1.1, 6), barMat, s * 0.62, 1.7, 0.05);
      bar2.rotation.x = Math.PI / 2;
    }
    part(body, cylGeo(0.05, 0.05, 1.3, 6), barMat, 0, 1.95, 0.5).rotation.z = Math.PI / 2;
    // steering
    const wheel = part(body, new THREE.TorusGeometry(0.16, 0.035, 5, 10), dark, -0.32, 1.18, 0.05);
    wheel.rotation.x = -0.5;
    // lights
    for (const s of [-1, 1]) {
      part(body, cylGeo(0.12, 0.12, 0.1, 8), toon(0xfff3b0, { emissive: 0xffd45e, emissiveIntensity: 0.8 }), s * 0.55, 0.76, -1.46).rotation.x = Math.PI / 2;
    }
    part(body, roundedGeo(1.5, 0.08, 0.3, 0.03), accent, 0, 1.16, -1.2);
    // wheels
    for (const x of [-0.92, 0.92]) {
      for (const z of [-0.95, 0.95]) {
        const w = makeWheel(0.44, 0.32, x, 0.44, z);
        group.add(w);
        wheels.push(w);
      }
    }
    // flag
    const pole = part(body, cylGeo(0.025, 0.025, 1.1, 5), dark, 0.7, 1.7, 1.0);
    void pole;
    flag = part(body, new THREE.PlaneGeometry(0.55, 0.34), accent, 0.98, 2.05, 1.0);
    flag.rotation.y = Math.PI / 2;
  } else {
    const olive = toon(0x7c9a4e);
    const dark = toon(0x2b2540);
    const metal = toon(0x4b5563);
    const accent = toon(teamColor);
    part(body, roundedGeo(2.3, 0.7, 3.4, 0.14), olive, 0, 0.85, 0);
    part(body, roundedGeo(2.4, 0.26, 3.5, 0.08), dark, 0, 0.5, 0);
    for (const s of [-1, 1]) {
      part(body, roundedGeo(0.52, 0.72, 3.7, 0.1), dark, s * 1.25, 0.5, 0);
      for (const z of [-1.2, -0.4, 0.4, 1.2]) {
        const w = makeWheel(0.34, 0.2, s * 1.5, 0.4, z);
        group.add(w);
        wheels.push(w);
      }
      part(body, roundedGeo(0.1, 0.18, 2.6, 0.03), accent, s * 1.2, 0.95, 0);
    }
    part(body, roundedGeo(1.9, 0.3, 1.2, 0.08), olive, 0, 1.25, -0.9);
    turret = new THREE.Group();
    turret.position.set(0, 1.32, 0.15);
    body.add(turret);
    part(turret, cylGeo(0.72, 0.82, 0.42, 10), olive, 0, 0.2, 0);
    part(turret, roundedGeo(1.1, 0.36, 1.2, 0.12), olive, 0, 0.46, 0);
    part(turret, roundedGeo(0.5, 0.16, 0.5, 0.05), accent, 0, 0.66, 0.1);
    const barrel = part(turret, cylGeo(0.09, 0.12, 2.1, 8), metal, 0, 0.42, -1.3);
    barrel.rotation.x = Math.PI / 2;
    part(turret, cylGeo(0.15, 0.15, 0.26, 8), dark, 0, 0.42, -2.3).rotation.x = Math.PI / 2;
    muzzle = new THREE.Object3D();
    muzzle.position.set(0, 0.42, -2.45);
    turret.add(muzzle);
    part(turret, cylGeo(0.03, 0.03, 0.9, 5), dark, 0.5, 0.9, 0.4);
    flag = part(turret, new THREE.PlaneGeometry(0.5, 0.3), accent, 0.76, 1.25, 0.4);
    flag.rotation.y = Math.PI / 2;
  }

  return { group, body, wheels, turret, muzzle, flag };
}

/* ------------------------------------------------------------------ */
/* Props & environment                                                 */
/* ------------------------------------------------------------------ */

export function createCrate(size = 1.1, base = "#d99a4e") {
  const g = new THREE.Group();
  const mat = toon(0xffffff, { map: crateTexture(base) });
  part(g, roundedGeo(size, size, size, 0.06), mat, 0, size / 2, 0);
  return g;
}

export function createBarrel(color = "#ef6a4c") {
  const g = new THREE.Group();
  const mat = toon(0xffffff, { map: barrelTexture(color) });
  part(g, cylGeo(0.42, 0.42, 1.05, 12), mat, 0, 0.525, 0);
  part(g, cylGeo(0.44, 0.44, 0.07, 12), toon(0x2b2540), 0, 0.12, 0);
  part(g, cylGeo(0.44, 0.44, 0.07, 12), toon(0x2b2540), 0, 0.94, 0);
  return g;
}

export function createPickupMesh(kind: "health" | "ammo") {
  const g = new THREE.Group();
  const color = kind === "health" ? 0x4be08a : 0xffc94a;
  const base = part(g, cylGeo(0.36, 0.42, 0.16, 10), toon(0x2b2540), 0, 0.08, 0);
  void base;
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(0.44, 0.035, 5, 16),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8 })
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.18;
  g.add(ring);
  if (kind === "health") {
    part(g, roundedGeo(0.4, 0.4, 0.4, 0.1), toon(0xfff8ec), 0, 0.55, 0);
    part(g, roundedGeo(0.28, 0.09, 0.1, 0.02), toon(0x2fbf71), 0, 0.55, 0.21);
    part(g, roundedGeo(0.09, 0.28, 0.1, 0.02), toon(0x2fbf71), 0, 0.55, 0.21);
  } else {
    part(g, roundedGeo(0.5, 0.32, 0.34, 0.06), toon(0x4a5568), 0, 0.45, 0);
    part(g, roundedGeo(0.52, 0.08, 0.36, 0.02), toon(0xffc94a), 0, 0.55, 0);
    part(g, roundedGeo(0.16, 0.1, 0.02, 0.01), toon(0x2b2540), 0, 0.45, 0.18);
  }
  return g;
}

export function createBuilding(w: number, h: number, d: number, wall: string, accent: string, trim: string, variant = 0) {
  const g = new THREE.Group();
  const tex = facadeTexture(wall, accent, trim, variant);
  const mat = toon(0xffffff, { map: tex });
  const accentHex = new THREE.Color(accent).getHex();
  const trimHex = new THREE.Color(trim).getHex();
  part(g, boxGeo(w, h, d), mat, 0, h / 2, 0);
  part(g, roundedGeo(w + 0.4, 0.28, d + 0.4, 0.06), toon(accentHex), 0, h + 0.1, 0);
  part(g, roundedGeo(w * 0.7, 0.16, d * 0.7, 0.05), toon(trimHex), 0, h + 0.3, 0);
  // awning
  const awning = part(g, roundedGeo(w * 0.55, 0.12, 0.9, 0.04), toon(accentHex), 0, h * 0.42, d / 2 + 0.4);
  awning.rotation.x = 0.16;
  return g;
}

export function createPalm() {
  const g = new THREE.Group();
  const trunk = toon(0xa9713f);
  const leaf = toon(0x4fbf6a);
  let y = 0;
  for (let i = 0; i < 4; i++) {
    const seg = part(g, cylGeo(0.16 - i * 0.02, 0.2 - i * 0.02, 0.9, 6), trunk, Math.sin(i * 0.5) * 0.12, y + 0.45, 0);
    seg.rotation.z = Math.sin(i * 0.5) * 0.12;
    y += 0.85;
  }
  for (let i = 0; i < 6; i++) {
    const leafMesh = part(g, coneGeo(0.22, 1.5, 4), leaf, 0, y + 0.1, 0);
    leafMesh.rotation.z = Math.PI / 2 - 0.25;
    leafMesh.rotation.y = (i / 6) * Math.PI * 2;
    leafMesh.position.x = Math.cos((i / 6) * Math.PI * 2) * 0.55;
    leafMesh.position.z = Math.sin((i / 6) * Math.PI * 2) * 0.55;
  }
  part(g, sphereGeo(0.16, 6), toon(0x8a5426), 0, y - 0.05, 0);
  return g;
}

export function createCactus() {
  const g = new THREE.Group();
  const green = toon(0x4fae72);
  part(g, cylGeo(0.26, 0.32, 1.7, 7), green, 0, 0.85, 0);
  part(g, sphereGeo(0.26, 7), green, 0, 1.7, 0);
  for (const s of [-1, 1]) {
    const arm = part(g, cylGeo(0.14, 0.16, 0.6, 6), green, s * 0.36, 1.05, 0);
    arm.rotation.z = s * 0.9;
    part(g, cylGeo(0.14, 0.14, 0.45, 6), green, s * 0.55, 1.35, 0);
  }
  return g;
}

export function createCloud() {
  const g = new THREE.Group();
  const mat = toon(0xffffff, { emissive: 0xbfe8ff, emissiveIntensity: 0.25 });
  for (let i = 0; i < 4; i++) {
    const s = part(g, sphereGeo(1.1 + Math.random() * 0.5, 7), mat, i * 1.2 - 1.8, Math.random() * 0.5, Math.random() * 0.6);
    s.scale.y = 0.65;
  }
  return g;
}

export function createMountain(radius: number, height: number, color: number) {
  const m = new THREE.Mesh(coneGeo(radius, height, 5), toon(color));
  m.position.y = height / 2 - 0.5;
  return m;
}

export function createFlag(color: number) {
  const g = new THREE.Group();
  part(g, cylGeo(0.04, 0.04, 3.2, 5), toon(0x2b2540), 0, 1.6, 0);
  const flag = part(g, new THREE.PlaneGeometry(1.1, 0.65), toon(color, { emissive: color, emissiveIntensity: 0.1 }), 0.58, 2.7, 0);
  flag.rotation.y = 0.2;
  return g;
}

export function createFence(length: number) {
  const g = new THREE.Group();
  const wood = toon(0xc98a4b);
  const dark = toon(0x8a5426);
  for (let i = 0; i <= Math.floor(length / 1.2); i++) {
    part(g, roundedGeo(0.14, 1.1, 0.14, 0.03), dark, -length / 2 + i * 1.2, 0.55, 0);
  }
  part(g, roundedGeo(length, 0.14, 0.1, 0.03), wood, 0, 0.8, 0);
  part(g, roundedGeo(length, 0.14, 0.1, 0.03), wood, 0, 0.4, 0);
  return g;
}

export function createCrateStack() {
  const g = new THREE.Group();
  const a = createCrate(1.2);
  a.position.y = 0;
  g.add(a);
  const b = createCrate(1.0);
  b.position.set(0.1, 1.2, 0.05);
  b.rotation.y = 0.2;
  g.add(b);
  const c = createCrate(0.8);
  c.position.set(-0.9, 0, 0.4);
  c.rotation.y = -0.3;
  g.add(c);
  return g;
}

export function createPlaza(radius: number) {
  const tex = canvasTexture(512, 512, (ctx) => {
    ctx.fillStyle = "#e8cfa4";
    ctx.fillRect(0, 0, 512, 512);
    for (let r = 40; r < 260; r += 44) {
      ctx.strokeStyle = r % 88 === 0 ? "#c9a878" : "#f4e2c2";
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.arc(256, 256, r, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.fillStyle = "#f2b544";
    ctx.beginPath();
    ctx.arc(256, 256, 34, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#2b2540";
    ctx.font = "bold 40px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("T", 256, 270);
    for (let i = 0; i < 220; i++) {
      ctx.fillStyle = `rgba(120,90,50,${Math.random() * 0.08})`;
      ctx.fillRect(Math.random() * 512, Math.random() * 512, 3, 3);
    }
  });
  const mesh = new THREE.Mesh(new THREE.CircleGeometry(radius, 40), toon(0xffffff, { map: tex }));
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.012;
  return mesh;
}

export function createGroundTexture() {
  return canvasTexture(512, 512, (ctx) => {
    ctx.fillStyle = "#e6cfa6";
    ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 900; i++) {
      const shade = Math.random();
      ctx.fillStyle = shade > 0.5 ? `rgba(255,244,214,${Math.random() * 0.35})` : `rgba(150,112,66,${Math.random() * 0.16})`;
      const s = 1 + Math.random() * 4;
      ctx.fillRect(Math.random() * 512, Math.random() * 512, s, s);
    }
    ctx.strokeStyle = "rgba(160,124,76,0.22)";
    ctx.lineWidth = 2;
    for (let i = 0; i <= 512; i += 128) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }
    for (let i = 0; i < 22; i++) {
      ctx.strokeStyle = `rgba(120,90,50,${0.05 + Math.random() * 0.08})`;
      ctx.lineWidth = 1 + Math.random() * 2;
      ctx.beginPath();
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      ctx.moveTo(x, y);
      ctx.lineTo(x + 20 + Math.random() * 40, y + Math.random() * 10);
      ctx.stroke();
    }
  });
}
