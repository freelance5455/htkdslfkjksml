import * as THREE from 'three';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type {TextureAtlasBundle} from './textureAtlas';
import {PROTAGONISTS, type AtlasTileId, type ProtagonistId, type QualityTier} from './types';

export type VehicleVariant = 'sports' | 'muscle' | 'pickup' | 'police' | 'armored';

export interface VehicleRig {
  group: THREE.Group;
  wheels: THREE.Object3D[];
  frontSteerPivots: THREE.Object3D[];
  sirenLeft?: THREE.Mesh;
  sirenRight?: THREE.Mesh;
}

export interface CharacterRig {
  group: THREE.Group;
  leftLeg: THREE.Object3D;
  rightLeg: THREE.Object3D;
  leftArm: THREE.Object3D;
  rightArm: THREE.Object3D;
  muzzleFlash: THREE.Mesh;
}

export interface BuildingCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
}

export interface RampZone {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  dirX: number;
  dirZ: number;
  height: number;
}

export interface WorldBuildResult {
  worldGroup: THREE.Group;
  mergedCityMesh: THREE.Mesh;
  waterMesh: THREE.Mesh;
  waterUniforms: {uTime: {value: number}};
  colliders: BuildingCollider[];
  ramps: RampZone[];
  roadCoords: number[];
  dispose: () => void;
}

let sharedContactShadowTex: THREE.CanvasTexture | null = null;
function getContactShadowTexture(): THREE.CanvasTexture {
  if (sharedContactShadowTex) return sharedContactShadowTex;
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0,0,0,0.65)');
  grad.addColorStop(0.6, 'rgba(0,0,0,0.28)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  sharedContactShadowTex = new THREE.CanvasTexture(c);
  sharedContactShadowTex.colorSpace = THREE.SRGBColorSpace;
  return sharedContactShadowTex;
}

export function createVehicleMesh(
  variant: VehicleVariant,
  paintColor: number,
  tier: QualityTier,
): VehicleRig {
  const group = new THREE.Group();
  const isHigh = tier === 'pc-high';

  const bodyMat = isHigh
    ? new THREE.MeshPhysicalMaterial({
        color: paintColor,
        metalness: 0.72,
        roughness: 0.24,
        clearcoat: 1.0,
        clearcoatRoughness: 0.12,
      })
    : new THREE.MeshStandardMaterial({
        color: paintColor,
        metalness: 0.65,
        roughness: 0.28,
      });

  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x181c22,
    roughness: 0.75,
    metalness: 0.25,
  });

  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.1,
    metalness: 0.9,
    transparent: true,
    opacity: 0.82,
  });

  const tireMat = new THREE.MeshStandardMaterial({color: 0x16181c, roughness: 0.92, metalness: 0.05});
  const rimMat = new THREE.MeshStandardMaterial({color: 0xd4d4d8, roughness: 0.22, metalness: 0.88});
  const headMat = new THREE.MeshStandardMaterial({color: 0xfef9c3, emissive: 0xfef08a, emissiveIntensity: 1.4});
  const tailMat = new THREE.MeshStandardMaterial({color: 0xef4444, emissive: 0xdc2626, emissiveIntensity: 1.2});

  const length = variant === 'armored' ? 5.8 : variant === 'pickup' ? 4.9 : 4.4;
  const width = variant === 'armored' ? 2.35 : variant === 'pickup' ? 2.1 : 1.96;
  const chassisH = variant === 'armored' ? 1.85 : variant === 'pickup' ? 0.85 : 0.68;

  // Ground contact shadow
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(width * 1.35, length * 1.2),
    new THREE.MeshBasicMaterial({
      map: getContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.03;
  group.add(shadowPlane);

  // Lower chassis / bumper skirt
  const lowerHull = new THREE.Mesh(new THREE.BoxGeometry(width, chassisH * 0.48, length), trimMat);
  lowerHull.position.y = 0.42;
  lowerHull.castShadow = isHigh;
  group.add(lowerHull);

  // Sculpted extruded body silhouette
  const profile = new THREE.Shape();
  const hl = length * 0.5;
  if (variant === 'armored') {
    profile.moveTo(-hl, 0);
    profile.lineTo(hl, 0);
    profile.lineTo(hl, 1.5);
    profile.lineTo(hl * 0.65, 2.0);
    profile.lineTo(-hl * 0.95, 2.0);
    profile.lineTo(-hl, 1.85);
    profile.closePath();
  } else if (variant === 'pickup') {
    profile.moveTo(-hl, 0);
    profile.lineTo(hl, 0);
    profile.lineTo(hl, 0.72);
    profile.lineTo(hl * 0.42, 0.85);
    profile.lineTo(hl * 0.2, 1.48);
    profile.lineTo(-hl * 0.35, 1.48);
    profile.lineTo(-hl * 0.42, 0.82);
    profile.lineTo(-hl, 0.82);
    profile.closePath();
  } else {
    profile.moveTo(-hl, 0);
    profile.lineTo(hl, 0);
    profile.lineTo(hl, 0.46);
    profile.lineTo(hl * 0.42, 0.68);
    profile.lineTo(hl * 0.08, 1.24);
    profile.lineTo(-hl * 0.52, 1.24);
    profile.lineTo(-hl * 0.84, 0.72);
    profile.lineTo(-hl, 0.64);
    profile.closePath();
  }

  const extrudeGeo = new THREE.ExtrudeGeometry(profile, {
    depth: width * 0.92,
    bevelEnabled: true,
    bevelThickness: 0.06,
    bevelSize: 0.05,
    bevelSegments: 2,
  });
  extrudeGeo.center();
  // Rotate so X is width and Z is length (+Z forward)
  extrudeGeo.rotateY(Math.PI / 2);
  const bodyMesh = new THREE.Mesh(extrudeGeo, bodyMat);
  bodyMesh.position.y = variant === 'armored' ? 1.22 : variant === 'pickup' ? 0.98 : 0.86;
  bodyMesh.castShadow = isHigh;
  bodyMesh.receiveShadow = true;
  group.add(bodyMesh);

  // Police white doors contrast
  if (variant === 'police') {
    const doorMat = new THREE.MeshStandardMaterial({color: 0xf8fafc, roughness: 0.3, metalness: 0.2});
    const doorBand = new THREE.Mesh(new THREE.BoxGeometry(width + 0.02, 0.52, length * 0.42), doorMat);
    doorBand.position.set(0, 0.76, -0.05);
    group.add(doorBand);
  }

  // Cabin glass canopy
  if (variant !== 'armored') {
    const cabinW = width * 0.82;
    const cabinL = variant === 'pickup' ? length * 0.28 : length * 0.46;
    const cabinMesh = new THREE.Mesh(new THREE.BoxGeometry(cabinW, 0.44, cabinL), glassMat);
    cabinMesh.position.set(0, variant === 'pickup' ? 1.32 : 1.18, variant === 'pickup' ? 0.22 : -0.2);
    group.add(cabinMesh);
  } else {
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(width * 0.8, 0.42, 0.14), glassMat);
    windshield.position.set(0, 1.72, hl * 0.72);
    group.add(windshield);
  }

  // Spoiler on sports/muscle
  if (variant === 'sports' || variant === 'muscle') {
    const wing = new THREE.Mesh(new THREE.BoxGeometry(width * 0.86, 0.07, 0.28), trimMat);
    wing.position.set(0, 1.18, -hl + 0.26);
    group.add(wing);
    [-0.55, 0.55].forEach((sx) => {
      const strut = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.2, 0.14), trimMat);
      strut.position.set(sx, 1.08, -hl + 0.26);
      group.add(strut);
    });
  }

  // Headlights & Taillights
  [-width * 0.33, width * 0.33].forEach((lx) => {
    const hlMesh = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.14, 0.08), headMat);
    hlMesh.position.set(lx, 0.64, hl + 0.01);
    group.add(hlMesh);

    const tlMesh = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.14, 0.08), tailMat);
    tlMesh.position.set(lx, 0.72, -hl - 0.01);
    group.add(tlMesh);
  });

  // Exhaust tips
  [-width * 0.26, width * 0.26].forEach((ex) => {
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.22, 8), rimMat);
    pipe.rotation.x = Math.PI / 2;
    pipe.position.set(ex, 0.28, -hl - 0.04);
    group.add(pipe);
  });

  // Police strobe lightbar
  let sirenLeft: THREE.Mesh | undefined;
  let sirenRight: THREE.Mesh | undefined;
  if (variant === 'police') {
    const barBase = new THREE.Mesh(new THREE.BoxGeometry(width * 0.62, 0.1, 0.28), trimMat);
    barBase.position.set(0, 1.54, -0.15);
    group.add(barBase);

    sirenLeft = new THREE.Mesh(
      new THREE.BoxGeometry(width * 0.26, 0.12, 0.24),
      new THREE.MeshStandardMaterial({color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 2.2}),
    );
    sirenLeft.position.set(-width * 0.16, 1.56, -0.15);
    group.add(sirenLeft);

    sirenRight = new THREE.Mesh(
      new THREE.BoxGeometry(width * 0.26, 0.12, 0.24),
      new THREE.MeshStandardMaterial({color: 0x3b82f6, emissive: 0x3b82f6, emissiveIntensity: 2.2}),
    );
    sirenRight.position.set(width * 0.16, 1.56, -0.15);
    group.add(sirenRight);
  }

  // 4 Wheels with rim hubs
  const wheelRadius = variant === 'pickup' || variant === 'armored' ? 0.42 : 0.36;
  const wheelGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, 0.28, 14);
  wheelGeo.rotateZ(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(wheelRadius * 0.56, wheelRadius * 0.56, 0.3, 10);
  hubGeo.rotateZ(Math.PI / 2);

  const wheels: THREE.Object3D[] = [];
  const frontSteerPivots: THREE.Object3D[] = [];
  const wheelZ = length * 0.31;
  const wheelX = width * 0.48;

  const positions: [number, number, boolean][] = [
    [-wheelX, wheelZ, true],
    [wheelX, wheelZ, true],
    [-wheelX, -wheelZ, false],
    [wheelX, -wheelZ, false],
  ];

  for (const [wx, wz, isFront] of positions) {
    const steerPivot = new THREE.Group();
    steerPivot.position.set(wx, wheelRadius, wz);
    const wheelGroup = new THREE.Group();
    const tire = new THREE.Mesh(wheelGeo, tireMat);
    const rim = new THREE.Mesh(hubGeo, rimMat);
    wheelGroup.add(tire, rim);
    steerPivot.add(wheelGroup);
    group.add(steerPivot);
    wheels.push(wheelGroup);
    if (isFront) frontSteerPivots.push(steerPivot);
  }

  return {group, wheels, frontSteerPivots, sirenLeft, sirenRight};
}

export function createCharacterMesh(
  kind: ProtagonistId | 'police' | 'guard',
): CharacterRig {
  const group = new THREE.Group();

  let suitColor = 0x1e3a8a;
  let shirtColor = 0x172554;
  let skinColor = 0xd9a882;
  let hairColor = 0x1c1917;
  let pantsColor = 0x0f172a;

  if (kind === 'michael' || kind === 'franklin' || kind === 'trevor') {
    const prof = PROTAGONISTS[kind];
    suitColor = prof.suitColor;
    shirtColor = prof.shirtColor;
    skinColor = prof.skinColor;
    hairColor = prof.hairColor;
    pantsColor = kind === 'michael' ? 0x1e293b : kind === 'franklin' ? 0x18181b : 0x3f3f46;
  } else if (kind === 'police') {
    suitColor = 0x1e3a5f;
    shirtColor = 0x172554;
    pantsColor = 0x0f172a;
  } else {
    suitColor = 0x27272a;
    shirtColor = 0x991b1b;
    pantsColor = 0x18181b;
  }

  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(1.1, 1.1),
    new THREE.MeshBasicMaterial({
      map: getContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.5,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.02;
  group.add(shadowPlane);

  const jacketMat = new THREE.MeshStandardMaterial({color: suitColor, roughness: 0.72, metalness: 0.08});
  const shirtMat = new THREE.MeshStandardMaterial({color: shirtColor, roughness: 0.78});
  const pantsMat = new THREE.MeshStandardMaterial({color: pantsColor, roughness: 0.85});
  const skinMat = new THREE.MeshStandardMaterial({color: skinColor, roughness: 0.65});
  const hairMat = new THREE.MeshStandardMaterial({color: hairColor, roughness: 0.82});
  const gunMat = new THREE.MeshStandardMaterial({color: 0x111827, roughness: 0.35, metalness: 0.85});

  // Legs (bottom-center pivot at y=0.78 hip)
  const makeLeg = (x: number) => {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.78, 0);
    const legMesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.7, 0.22), pantsMat);
    legMesh.position.y = -0.35;
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.12, 0.28), gunMat);
    shoe.position.set(0, -0.72, 0.03);
    pivot.add(legMesh, shoe);
    group.add(pivot);
    return pivot;
  };
  const leftLeg = makeLeg(-0.14);
  const rightLeg = makeLeg(0.14);

  // Torso
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.66, 0.3), jacketMat);
  torso.position.y = 1.11;
  group.add(torso);

  const chestV = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.5, 0.31), shirtMat);
  chestV.position.set(0, 1.14, 0.01);
  group.add(chestV);

  // Arms
  const makeArm = (x: number, withGun: boolean) => {
    const pivot = new THREE.Group();
    pivot.position.set(x, 1.38, 0);
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.56, 0.18), jacketMat);
    sleeve.position.y = -0.24;
    const hand = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.14), skinMat);
    hand.position.y = -0.56;
    pivot.add(sleeve, hand);
    if (withGun) {
      const gunBarrel = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.34), gunMat);
      gunBarrel.position.set(0, -0.54, 0.16);
      pivot.add(gunBarrel);
    }
    group.add(pivot);
    return pivot;
  };
  const leftArm = makeArm(-0.37, false);
  const rightArm = makeArm(0.37, true);

  // Muzzle flash attached to rightArm
  const muzzleFlash = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 6, 6),
    new THREE.MeshBasicMaterial({color: 0xfef08a}),
  );
  muzzleFlash.position.set(0, -0.54, 0.38);
  muzzleFlash.visible = false;
  rightArm.add(muzzleFlash);

  // Head + hair/cap/shades
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.36, 0.34), skinMat);
  head.position.y = 1.66;
  group.add(head);

  const hair = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.13, 0.36), hairMat);
  hair.position.set(0, 1.82, -0.01);
  group.add(hair);

  if (kind === 'michael') {
    const shades = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.07, 0.06), gunMat);
    shades.position.set(0, 1.69, 0.16);
    group.add(shades);
  } else if (kind === 'franklin' || kind === 'police') {
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.35, 0.05, 0.18),
      new THREE.MeshStandardMaterial({color: kind === 'police' ? 0x1e3a8a : 0x15803d}),
    );
    visor.position.set(0, 1.78, 0.16);
    group.add(visor);
  }

  return {group, leftLeg, rightLeg, leftArm, rightArm, muzzleFlash};
}

export function buildAtlasWorld(
  atlas: TextureAtlasBundle,
  tier: QualityTier,
): WorldBuildResult {
  const worldGroup = new THREE.Group();
  const colliders: BuildingCollider[] = [];
  const ramps: RampZone[] = [];
  const parts: THREE.BufferGeometry[] = [];

  const addAtlasBox = (
    w: number,
    h: number,
    d: number,
    x: number,
    y: number,
    z: number,
    tileId: AtlasTileId,
    repeatU = 1,
    repeatV = 1,
    collider = false,
  ) => {
    const geo = new THREE.BoxGeometry(w, h, d);
    atlas.remapBoxUVs(geo, tileId, repeatU, repeatV);
    geo.translate(x, y, z);
    parts.push(geo);
    if (collider) {
      colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
        height: h,
      });
    }
  };

  const addAtlasTilePlane = (
    w: number,
    d: number,
    x: number,
    y: number,
    z: number,
    tileId: AtlasTileId,
  ) => {
    const geo = new THREE.PlaneGeometry(w, d);
    geo.rotateX(-Math.PI / 2);
    atlas.remapBoxUVs(geo, tileId, 1, 1);
    geo.translate(x, y, z);
    parts.push(geo);
  };

  // Road grid coordinates: -120, -60, 0, 60, 120
  const roadCoords = [-120, -60, 0, 60, 120];
  const worldMin = -180;
  const worldMax = 180;
  const roadWidth = 14;

  // 1. District ground tiles (chunked 30m x 30m tiles for sharp UV density in 1 draw call)
  const tileStep = 30;
  for (let gx = worldMin; gx < worldMax; gx += tileStep) {
    for (let gz = worldMin; gz < worldMax; gz += tileStep) {
      const cx = gx + tileStep / 2;
      const cz = gz + tileStep / 2;
      let groundTile: AtlasTileId = 'sidewalk_concrete';
      if (cx > 65 && cz < -45) {
        groundTile = 'desert_sand'; // Sandy Shores NE
      } else if (cx < -135 && cz > 10) {
        groundTile = 'desert_sand'; // Vespucci Golden Beach West
      } else if (cx < -65 && cz < -45) {
        groundTile = 'grass_park'; // Rockford Hills & Vinewood NW
      } else if (cx > 55 && cz > 65) {
        groundTile = 'water_tile'; // Port of Los Santos SE
      } else if (cx < -10 && cz > 75 && cx > -75) {
        groundTile = 'grass_park'; // Strawberry / Grove Park
      }
      addAtlasTilePlane(tileStep, tileStep, cx, 0, cz, groundTile);
    }
  }

  // 2. Road network (merged segmented strips using asphalt_road, road_lane_yellow, road_crosswalk)
  const segLen = 20;
  for (const rc of roadCoords) {
    // North-South avenues
    for (let z = -170; z <= 150; z += segLen) {
      const cz = z + segLen / 2;
      const isIntersection = roadCoords.some((ir) => Math.abs(cz - ir) < 8);
      if (!isIntersection) {
        addAtlasTilePlane(roadWidth, segLen, rc, 0.03, cz, 'road_lane_yellow');
      }
    }
    // East-West streets
    for (let x = -170; x <= 150; x += segLen) {
      const cx = x + segLen / 2;
      const isIntersection = roadCoords.some((ir) => Math.abs(cx - ir) < 8);
      if (!isIntersection) {
        const geo = new THREE.PlaneGeometry(roadWidth, segLen);
        geo.rotateX(-Math.PI / 2);
        geo.rotateY(Math.PI / 2);
        atlas.remapBoxUVs(geo, 'road_lane_yellow', 1, 1);
        geo.translate(cx, 0.03, rc);
        parts.push(geo);
      }
    }
  }

  // Intersection asphalt pads + crosswalks
  for (const ix of roadCoords) {
    for (const iz of roadCoords) {
      addAtlasTilePlane(roadWidth + 2, roadWidth + 2, ix, 0.04, iz, 'asphalt_road');
      addAtlasTilePlane(roadWidth, 4, ix, 0.05, iz + 9, 'road_crosswalk');
      addAtlasTilePlane(roadWidth, 4, ix, 0.05, iz - 9, 'road_crosswalk');
    }
  }

  // 3. Sandy Flats Airfield Runway (NE District)
  for (let rz = -165; rz <= -75; rz += 22) {
    addAtlasTilePlane(16, 22, 125, 0.05, rz, 'airfield_runway');
  }
  // Airfield Hangar
  addAtlasBox(20, 9, 22, 148, 4.5, -105, 'cargo_steel', 2, 1, true);

  // 4. Downtown Financial District & Landmarks
  // Union Reserve Bank (Mission 6 Finale)
  addAtlasBox(24, 34, 24, 78, 17, -28, 'skyscraper_stone', 2, 3, true);
  addAtlasBox(26, 4, 26, 78, 35, -28, 'metal_trim', 1, 1, false);

  // Vangelico Jewelers (Mission 2)
  addAtlasBox(20, 12, 18, -76, 0 + 6, -18, 'storefront_luxury', 2, 1, true);

  // Downtown Skyscrapers inside blocks between [-48..48]
  const skyscraperSpecs: [number, number, number, number, number, AtlasTileId][] = [
    [-30, -30, 18, 44, 18, 'skyscraper_glass'],
    [30, -30, 20, 56, 20, 'skyscraper_glass'],
    [-30, 30, 20, 38, 18, 'skyscraper_stone'],
    [30, 30, 18, 48, 18, 'skyscraper_glass'],
    [90, 30, 20, 34, 20, 'skyscraper_glass'],
    [-90, 30, 18, 24, 18, 'brick_southside'],
    [30, 90, 20, 28, 18, 'skyscraper_stone'],
    [-90, 90, 20, 14, 18, 'brick_southside'],
    [-30, 145, 22, 12, 16, 'brick_southside'],
    [30, -90, 20, 26, 18, 'skyscraper_glass'],
    [-30, -90, 18, 22, 18, 'skyscraper_stone'],
  ];

  for (const [bx, bz, w, h, d, tile] of skyscraperSpecs) {
    addAtlasBox(w, h, d, bx, h / 2, bz, tile, Math.max(1, Math.round(w / 10)), Math.max(1, Math.round(h / 12)), true);
    // Rooftop mechanical crown
    addAtlasBox(w * 0.55, 2.6, d * 0.55, bx, h + 1.3, bz, 'metal_trim', 1, 1, false);
  }

  // 5. Vinecrest Hills Mansions (NW)
  const mansionCoords: [number, number, number, number][] = [
    [-102, -135, 22, 14],
    [-145, -100, 18, 20],
    [-145, -40, 18, 16],
    [-92, -32, 16, 16],
  ];
  for (const [mx, mz, mw, md] of mansionCoords) {
    addAtlasBox(mw, 8.5, md, mx, 4.25, mz, 'mansion_stucco', 2, 1, true);
    addAtlasBox(mw + 1.4, 0.8, md + 1.4, mx, 8.8, mz, 'metal_trim', 1, 1, false);
  }

  // 6. Harbor Cargo Containers (SE Docks - Mission 4)
  const containers: [number, number, number, number][] = [
    [94, 96, 14, 5],
    [94, 104, 14, 5],
    [136, 98, 5, 14],
    [136, 132, 5, 14],
    [104, 138, 14, 5],
  ];
  for (const [cx, cz, cw, cd] of containers) {
    addAtlasBox(cw, 4.4, cd, cx, 2.2, cz, 'cargo_steel', 1, 1, true);
  }

  // 7. Stunt Ramps placed on key avenues for GTA-style jumps!
  const rampSpecs: [number, number, number, number][] = [
    [0, 32, 0, -1],
    [60, -45, 0, 1],
    [95, -95, 1, 0],
  ];
  for (const [rx, rz, dx, dz] of rampSpecs) {
    addAtlasBox(6, 1.4, 9, rx, 0.4, rz, 'metal_trim', 1, 1, false);
    ramps.push({
      minX: rx - 3.2,
      maxX: rx + 3.2,
      minZ: rz - 4.8,
      maxZ: rz + 4.8,
      dirX: dx,
      dirZ: dz,
      height: 1.6,
    });
  }

  // Merge all static city geometry into ONE SINGLE DRAW CALL!
  const mergedGeo = mergeGeometries(parts, false);
  parts.forEach((p) => p.dispose());
  const mergedCityMesh = new THREE.Mesh(mergedGeo, atlas.material);
  mergedCityMesh.receiveShadow = true;
  mergedCityMesh.castShadow = tier === 'pc-high';
  worldGroup.add(mergedCityMesh);

  // 8. Instanced Palm Trees & Streetlights (1 draw call each!)
  const palmPositions: [number, number][] = [
    [-12, -16], [-12, 16], [12, -16], [12, 16],
    [-48, -48], [-48, 48], [48, -48], [48, 48],
    [-85, -85], [-130, -85], [-85, -135],
    [-48, 92], [-48, 132], [48, 92],
    [12, -85], [12, 85], [-12, 85], [-12, -85],
    [76, 76], [76, 135], [-105, 12], [-105, -12],
  ];
  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.35, 6.2, 6);
  trunkGeo.translate(0, 3.1, 0);
  const trunkMat = new THREE.MeshStandardMaterial({color: 0x6b4f35, roughness: 0.9});
  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, palmPositions.length);

  const crownGeo = new THREE.ConeGeometry(2.6, 2.0, 6);
  crownGeo.translate(0, 6.6, 0);
  const crownMat = new THREE.MeshStandardMaterial({color: 0x2e7d32, roughness: 0.78});
  const crownInst = new THREE.InstancedMesh(crownGeo, crownMat, palmPositions.length);

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();
  palmPositions.forEach(([px, pz], idx) => {
    const scale = 0.85 + ((idx * 17) % 30) / 100;
    dummy.position.set(px, 0, pz);
    dummy.rotation.y = idx * 1.1;
    dummy.scale.set(scale, scale, scale);
    dummy.updateMatrix();
    trunkInst.setMatrixAt(idx, dummy.matrix);
    crownInst.setMatrixAt(idx, dummy.matrix);
    tint.setHSL(0.32 + (idx % 3) * 0.02, 0.45, 0.35 + (idx % 4) * 0.04);
    crownInst.setColorAt(idx, tint);
  });
  trunkInst.instanceMatrix.needsUpdate = true;
  crownInst.instanceMatrix.needsUpdate = true;
  if (crownInst.instanceColor) crownInst.instanceColor.needsUpdate = true;
  trunkInst.computeBoundingSphere();
  crownInst.computeBoundingSphere();
  worldGroup.add(trunkInst, crownInst);

  // Instanced Streetlamps along main avenues
  const lampPositions: [number, number][] = [];
  for (const rc of [-60, 0, 60]) {
    for (let p = -140; p <= 140; p += 40) {
      lampPositions.push([rc - 8.5, p]);
      lampPositions.push([rc + 8.5, p]);
    }
  }
  const poleGeo = new THREE.CylinderGeometry(0.1, 0.14, 5.4, 6);
  poleGeo.translate(0, 2.7, 0);
  const poleMat = new THREE.MeshStandardMaterial({color: 0x334155, metalness: 0.7, roughness: 0.4});
  const poleInst = new THREE.InstancedMesh(poleGeo, poleMat, lampPositions.length);

  const bulbGeo = new THREE.BoxGeometry(0.45, 0.18, 0.45);
  bulbGeo.translate(0, 5.4, 0);
  const bulbMat = new THREE.MeshBasicMaterial({color: 0xfef3c7});
  const bulbInst = new THREE.InstancedMesh(bulbGeo, bulbMat, lampPositions.length);

  lampPositions.forEach(([lx, lz], i) => {
    dummy.position.set(lx, 0, lz);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    poleInst.setMatrixAt(i, dummy.matrix);
    bulbInst.setMatrixAt(i, dummy.matrix);
  });
  poleInst.instanceMatrix.needsUpdate = true;
  bulbInst.instanceMatrix.needsUpdate = true;
  poleInst.computeBoundingSphere();
  bulbInst.computeBoundingSphere();
  worldGroup.add(poleInst, bulbInst);

  // 9. Animated Coastal Harbor & Ocean Border (extending beyond playable 360x360 zone)
  const waterUniforms = {uTime: {value: 0}};
  const waterGeo = new THREE.PlaneGeometry(1200, 1200, 32, 32);
  waterGeo.rotateX(-Math.PI / 2);
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x0e5e78,
    roughness: 0.18,
    metalness: 0.55,
  });
  waterMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = waterUniforms.uTime;
    shader.vertexShader =
      `uniform float uTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         transformed.y += sin(position.x * 0.05 + uTime * 1.4) * 0.25 + cos(position.z * 0.06 + uTime * 1.1) * 0.25;`,
      );
  };
  const waterMesh = new THREE.Mesh(waterGeo, waterMat);
  waterMesh.position.y = -0.65;
  worldGroup.add(waterMesh);

  // Outer perimeter mountain ridge in far NE/NW so world feels bounded naturally
  const ridgeGeo = new THREE.ConeGeometry(42, 38, 7);
  const ridgeMat = new THREE.MeshStandardMaterial({color: 0x7c6855, roughness: 0.95});
  const ridgeCoords: [number, number, number][] = [
    [-210, -200, 1.4], [-140, -215, 1.1], [-60, -220, 1.3],
    [30, -220, 1.0], [120, -215, 1.5], [205, -195, 1.6], [215, -110, 1.2],
  ];
  const ridgeInst = new THREE.InstancedMesh(ridgeGeo, ridgeMat, ridgeCoords.length);
  ridgeCoords.forEach(([rx, rz, rs], i) => {
    dummy.position.set(rx, 14, rz);
    dummy.rotation.y = i * 0.7;
    dummy.scale.set(rs, rs, rs);
    dummy.updateMatrix();
    ridgeInst.setMatrixAt(i, dummy.matrix);
  });
  ridgeInst.instanceMatrix.needsUpdate = true;
  ridgeInst.computeBoundingSphere();
  worldGroup.add(ridgeInst);

  // 10. Iconic Los Santos Landmarks: Maze Bank Tower Crown, Vinewood Sign, Del Perro Pier, Backyard Pool
  const landmarkGroup = new THREE.Group();

  // Maze Bank Tower cylindrical glass core + red rooftop crown at (30, -30)
  const mazeCoreGeo = new THREE.CylinderGeometry(11.5, 13.5, 68, 16);
  const mazeCoreMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.78,
    roughness: 0.22,
  });
  const mazeCore = new THREE.Mesh(mazeCoreGeo, mazeCoreMat);
  mazeCore.position.set(30, 34, -30);
  landmarkGroup.add(mazeCore);

  const mazeCrownGeo = new THREE.TorusGeometry(10.8, 0.85, 8, 24);
  mazeCrownGeo.rotateX(Math.PI / 2);
  const mazeCrownMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    emissive: 0x991b1b,
    emissiveIntensity: 0.9,
    roughness: 0.35,
  });
  const mazeCrown = new THREE.Mesh(mazeCrownGeo, mazeCrownMat);
  mazeCrown.position.set(30, 68.5, -30);
  landmarkGroup.add(mazeCrown);

  // Giant VINEWOOD Sign overlooking northern hills (z = -196)
  const signMat = new THREE.MeshStandardMaterial({color: 0xf8fafc, roughness: 0.55});
  const strutMat = new THREE.MeshStandardMaterial({color: 0x475569, roughness: 0.8});
  const letterPatterns: number[][] = [
    // V I N E W O O D simplified crisp 3D block strokes
    [0, 1, 0, 1, 0], // V (built via dedicated blocks below)
  ];
  void letterPatterns;
  const vinewoodLetters = ['V', 'I', 'N', 'E', 'W', 'O', 'O', 'D'];
  vinewoodLetters.forEach((ch, idx) => {
    const lx = -58 + idx * 12.5;
    const ly = 26;
    const lz = -194;
    // Support truss
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.6, 16, 0.6), strutMat);
    post.position.set(lx, 17, lz - 1.5);
    landmarkGroup.add(post);

    const addStroke = (ox: number, oy: number, w: number, h: number, rotZ = 0) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 1.4), signMat);
      m.position.set(lx + ox, ly + oy, lz);
      m.rotation.z = rotZ;
      landmarkGroup.add(m);
    };

    if (ch === 'V') {
      addStroke(-1.8, 0, 1.8, 10.5, 0.24);
      addStroke(1.8, 0, 1.8, 10.5, -0.24);
    } else if (ch === 'I') {
      addStroke(0, 0, 2.0, 10.0);
    } else if (ch === 'N') {
      addStroke(-2.6, 0, 1.7, 10.0);
      addStroke(2.6, 0, 1.7, 10.0);
      addStroke(0, 0, 1.7, 11.2, 0.45);
    } else if (ch === 'E') {
      addStroke(-2.2, 0, 1.8, 10.0);
      addStroke(0.4, 4.1, 5.2, 1.8);
      addStroke(0.1, 0.2, 4.4, 1.6);
      addStroke(0.4, -4.1, 5.2, 1.8);
    } else if (ch === 'W') {
      addStroke(-3.2, 0, 1.6, 10.0, 0.14);
      addStroke(-1.0, -0.5, 1.5, 8.5, -0.2);
      addStroke(1.0, -0.5, 1.5, 8.5, 0.2);
      addStroke(3.2, 0, 1.6, 10.0, -0.14);
    } else if (ch === 'O') {
      addStroke(-2.5, 0, 1.7, 10.0);
      addStroke(2.5, 0, 1.7, 10.0);
      addStroke(0, 4.1, 6.2, 1.8);
      addStroke(0, -4.1, 6.2, 1.8);
    } else if (ch === 'D') {
      addStroke(-2.4, 0, 1.8, 10.0);
      addStroke(2.2, 0, 1.7, 8.2);
      addStroke(0, 4.1, 5.6, 1.8);
      addStroke(0, -4.1, 5.6, 1.8);
    }
  });

  // Del Perro Pier + Ferris Wheel extending out into Pacific Ocean (West)
  const pierDeck = new THREE.Mesh(
    new THREE.BoxGeometry(58, 1.2, 12),
    new THREE.MeshStandardMaterial({color: 0x78553a, roughness: 0.9}),
  );
  pierDeck.position.set(-206, 0.9, 64);
  landmarkGroup.add(pierDeck);

  const ferrisRing = new THREE.Mesh(
    new THREE.TorusGeometry(9.5, 0.45, 8, 24),
    new THREE.MeshStandardMaterial({color: 0xf43f5e, emissive: 0xe11d48, emissiveIntensity: 0.8}),
  );
  ferrisRing.position.set(-224, 12.5, 64);
  landmarkGroup.add(ferrisRing);

  // Michael's Rockford Hills Swimming Pool
  const poolWater = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 8),
    new THREE.MeshStandardMaterial({color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.35, roughness: 0.1}),
  );
  poolWater.rotation.x = -Math.PI / 2;
  poolWater.position.set(-102, 0.08, -120);
  landmarkGroup.add(poolWater);

  // California Sky Dome Gradient
  const skyGeo = new THREE.SphereGeometry(480, 24, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      topColor: {value: new THREE.Color(0x2563eb)},
      horizonColor: {value: new THREE.Color(0xfde68a)},
    },
    vertexShader: `
      varying vec3 vWorldPos;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 topColor;
      uniform vec3 horizonColor;
      varying vec3 vWorldPos;
      void main() {
        float h = normalize(vWorldPos).y;
        float t = pow(clamp(h, 0.0, 1.0), 0.55);
        gl_FragColor = vec4(mix(horizonColor, topColor, t), 1.0);
      }
    `,
  });
  const skyDome = new THREE.Mesh(skyGeo, skyMat);
  landmarkGroup.add(skyDome);

  worldGroup.add(landmarkGroup);

  return {
    worldGroup,
    mergedCityMesh,
    waterMesh,
    waterUniforms,
    colliders,
    ramps,
    roadCoords,
    dispose: () => {
      mergedGeo.dispose();
      trunkGeo.dispose();
      trunkMat.dispose();
      crownGeo.dispose();
      crownMat.dispose();
      poleGeo.dispose();
      poleMat.dispose();
      bulbGeo.dispose();
      bulbMat.dispose();
      waterGeo.dispose();
      waterMat.dispose();
      ridgeGeo.dispose();
      ridgeMat.dispose();
      mazeCoreGeo.dispose();
      mazeCoreMat.dispose();
      mazeCrownGeo.dispose();
      mazeCrownMat.dispose();
      signMat.dispose();
      strutMat.dispose();
      skyGeo.dispose();
      skyMat.dispose();
    },
  };
}
