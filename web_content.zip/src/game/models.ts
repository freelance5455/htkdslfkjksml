import * as THREE from 'three';
import type { WeaponDef } from './weapons';
import type { SkinColors } from './store';
import { skinTexture } from './textures';

const std = (color: string, rough = 0.7, metal = 0.1) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });

function box(g: THREE.Object3D, w: number, h: number, d: number, mat: THREE.Material, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  g.add(m);
  return m;
}

function cyl(g: THREE.Object3D, r: number, len: number, mat: THREE.Material, x = 0, y = 0, z = 0, seg = 10) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg), mat);
  m.rotation.x = Math.PI / 2;
  m.position.set(x, y, z);
  g.add(m);
  return m;
}

export interface GunModel {
  group: THREE.Group;
  muzzle: THREE.Object3D;
  mag: THREE.Object3D | null;
}

export function buildGun(def: WeaponDef, skin: SkinColors, hands = true, sleeve = '#3d4a2c'): GunModel {
  const g = new THREE.Group();
  const tex = skinTexture(skin);
  const sk = new THREE.MeshStandardMaterial({ map: tex, roughness: skin.metal ? 0.28 : 0.65, metalness: skin.metal ? 0.85 : 0.15 });
  const dark = std('#1b1c1f', 0.4, 0.7);
  const acc = new THREE.MeshStandardMaterial({ color: skin.c3, roughness: 0.6, metalness: skin.metal ? 0.5 : 0.1 });
  const L = def.len;
  const muzzle = new THREE.Object3D();
  let mag: THREE.Object3D | null = null;

  switch (def.type) {
    case 'knife': {
      const shape = new THREE.Shape();
      shape.moveTo(0, 0);
      shape.quadraticCurveTo(0.06, 0.02, 0.1, 0.1);
      shape.quadraticCurveTo(0.12, 0.17, 0.08, 0.2);
      shape.quadraticCurveTo(0.09, 0.13, 0.05, 0.08);
      shape.quadraticCurveTo(0.03, 0.04, 0, 0.025);
      shape.lineTo(0, 0);
      const bladeGeo = new THREE.ExtrudeGeometry(shape, { depth: 0.006, bevelEnabled: true, bevelThickness: 0.002, bevelSize: 0.003, bevelSegments: 1 });
      const blade = new THREE.Mesh(bladeGeo, skin.pattern === 'solid' && !skin.metal ? std('#c9ccd2', 0.2, 0.95) : sk);
      blade.rotation.set(-Math.PI / 2, 0, Math.PI / 2);
      blade.position.set(0, 0.01, -0.03);
      g.add(blade);
      box(g, 0.03, 0.035, 0.11, acc, 0, 0, 0.03);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.022, 0.006, 6, 14), dark);
      ring.position.set(0, 0, 0.1); ring.rotation.y = Math.PI / 2; g.add(ring);
      muzzle.position.set(0, 0, -0.15);
      break;
    }
    case 'grenade': {
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.045, 12, 10), std('#3c4a2a', 0.6, 0.2));
      body.scale.set(1, 1.2, 1); g.add(body);
      box(g, 0.02, 0.03, 0.02, dark, 0, 0.06, 0);
      box(g, 0.012, 0.08, 0.02, dark, 0.02, 0.03, 0, 0, 0, -0.2);
      const pin = new THREE.Mesh(new THREE.TorusGeometry(0.015, 0.003, 6, 12), std('#bbb', 0.3, 0.9));
      pin.position.set(-0.02, 0.075, 0); g.add(pin);
      break;
    }
    case 'pistol': {
      box(g, 0.038, 0.042, L, sk, 0, 0.02, -L / 2 + 0.06);
      box(g, 0.034, 0.03, L * 0.75, dark, 0, -0.01, -L * 0.4 + 0.06);
      const grip = box(g, 0.034, 0.12, 0.05, acc, 0, -0.06, 0.04, -0.22);
      mag = grip;
      box(g, 0.006, 0.012, 0.006, dark, 0, 0.045, -L + 0.08);
      if (def.id === 'usp') cyl(g, 0.017, 0.14, dark, 0, 0.02, -L - 0.01, 12);
      if (def.id === 'deagle') box(g, 0.042, 0.012, L * 0.9, std('#888', 0.3, 0.9), 0, 0.045, -L / 2 + 0.06);
      muzzle.position.set(0, 0.02, -L + (def.id === 'usp' ? -0.08 : 0.04));
      break;
    }
    case 'sniper': {
      box(g, 0.065, 0.085, L * 0.42, sk, 0, 0, -L * 0.12);
      cyl(g, 0.016, L * 0.55, dark, 0, 0.01, -L * 0.6);
      cyl(g, 0.024, 0.06, dark, 0, 0.01, -L * 0.88);
      box(g, 0.055, 0.1, L * 0.35, sk, 0, -0.02, L * 0.24);
      box(g, 0.05, 0.05, 0.12, acc, 0, 0.04, L * 0.22);
      box(g, 0.04, 0.12, 0.05, acc, 0, -0.08, 0.02, -0.35);
      mag = box(g, 0.045, 0.08, 0.08, dark, 0, -0.07, -L * 0.15);
      const scope = cyl(g, 0.026, 0.3, dark, 0, 0.085, -L * 0.12, 14);
      void scope;
      cyl(g, 0.034, 0.05, dark, 0, 0.085, -L * 0.12 - 0.16, 14);
      cyl(g, 0.032, 0.05, dark, 0, 0.085, -L * 0.12 + 0.15, 14);
      const lens = new THREE.Mesh(new THREE.CircleGeometry(0.03, 14), new THREE.MeshStandardMaterial({ color: '#4fb3ff', emissive: '#103050', roughness: 0.1, metalness: 0.8 }));
      lens.position.set(0, 0.085, -L * 0.12 - 0.186); lens.rotation.y = Math.PI; g.add(lens);
      box(g, 0.02, 0.04, 0.02, dark, 0, 0.055, -L * 0.2);
      box(g, 0.02, 0.04, 0.02, dark, 0, 0.055, -L * 0.02);
      box(g, 0.05, 0.015, 0.015, dark, 0.04, 0.02, 0.0);
      muzzle.position.set(0, 0.01, -L * 0.92);
      break;
    }
    case 'shotgun': {
      box(g, 0.06, 0.08, L * 0.35, sk, 0, 0, -L * 0.1);
      cyl(g, 0.016, L * 0.6, dark, 0, 0.02, -L * 0.55);
      cyl(g, 0.014, L * 0.5, dark, 0, -0.015, -L * 0.5);
      mag = box(g, 0.055, 0.055, L * 0.22, acc, 0, -0.015, -L * 0.5);
      box(g, 0.05, 0.09, L * 0.32, acc, 0, -0.03, L * 0.22, 0.08);
      box(g, 0.04, 0.1, 0.05, acc, 0, -0.07, 0.03, -0.3);
      muzzle.position.set(0, 0.02, -L * 0.86);
      break;
    }
    case 'lmg': {
      box(g, 0.08, 0.11, L * 0.45, sk, 0, 0, -L * 0.12);
      box(g, 0.07, 0.07, L * 0.25, dark, 0, -0.005, -L * 0.45);
      cyl(g, 0.018, L * 0.35, dark, 0, 0.01, -L * 0.72);
      mag = box(g, 0.1, 0.1, 0.12, std('#3c4a2a', 0.7, 0.2), -0.02, -0.1, -L * 0.15);
      box(g, 0.055, 0.09, L * 0.28, acc, 0, -0.01, L * 0.22);
      box(g, 0.04, 0.11, 0.05, acc, 0, -0.08, 0.03, -0.3);
      box(g, 0.02, 0.05, 0.12, dark, 0, 0.08, -L * 0.15);
      box(g, 0.01, 0.12, 0.01, dark, 0.03, -0.06, -L * 0.6, 0, 0, 0.3);
      box(g, 0.01, 0.12, 0.01, dark, -0.03, -0.06, -L * 0.6, 0, 0, -0.3);
      muzzle.position.set(0, 0.01, -L * 0.9);
      break;
    }
    default: { // rifle & smg
      const isAk = def.id === 'ak47';
      const isP90 = def.id === 'p90';
      const isFamas = def.id === 'famas';
      box(g, 0.065, 0.095, L * 0.42, sk, 0, 0, -L * 0.12);
      box(g, 0.06, 0.072, L * 0.3, isAk ? acc : sk, 0, -0.005, -L * 0.47);
      cyl(g, 0.012, L * 0.32, dark, 0, 0.012, -L * 0.74);
      box(g, 0.008, 0.035, 0.012, dark, 0, 0.04, -L * 0.82);
      if (isP90) {
        box(g, 0.05, 0.03, L * 0.5, std('#555', 0.3, 0.3), 0, 0.065, -L * 0.2);
        box(g, 0.05, 0.1, L * 0.25, sk, 0, -0.03, L * 0.16);
      } else {
        mag = box(g, 0.042, 0.16, 0.065, isAk ? std('#7a4a1a', 0.5, 0.3) : dark, 0, -0.11, isFamas ? L * 0.12 : -L * 0.2, isAk ? 0.3 : 0.12);
        box(g, 0.05, 0.085, L * 0.3, isAk ? acc : sk, 0, -0.02, L * 0.24, 0.04);
      }
      box(g, 0.04, 0.11, 0.05, acc, 0, -0.08, 0.03, -0.3);
      if (!isAk) box(g, 0.026, 0.02, L * 0.38, dark, 0, 0.058, -L * 0.15);
      if (isFamas) box(g, 0.02, 0.05, L * 0.4, dark, 0, 0.08, -L * 0.15);
      muzzle.position.set(0, 0.012, -L * 0.9);
    }
  }
  g.add(muzzle);

  if (hands && def.type !== 'grenade') {
    const glove = std('#202124', 0.8, 0.05);
    const sl = std(sleeve, 0.9, 0.0);
    const skinM = std('#c08a62', 0.7, 0.0);
    // right hand
    const rh = new THREE.Group();
    box(rh, 0.06, 0.07, 0.09, glove, 0, 0, 0);
    box(rh, 0.075, 0.075, 0.08, skinM, 0, -0.005, 0.08);
    box(rh, 0.09, 0.09, 0.32, sl, 0.005, -0.01, 0.27);
    rh.position.set(0.02, -0.09, 0.07);
    rh.rotation.set(0.35, 0.05, 0);
    g.add(rh);
    if (def.type !== 'knife' && def.type !== 'pistol') {
      const lh = new THREE.Group();
      box(lh, 0.065, 0.06, 0.09, glove, 0, 0, 0);
      box(lh, 0.075, 0.075, 0.08, skinM, 0, -0.005, 0.08);
      box(lh, 0.09, 0.09, 0.4, sl, 0, -0.01, 0.3);
      lh.position.set(-0.03, -0.06, -L * 0.45);
      lh.rotation.set(0.25, -0.55, 0.1);
      g.add(lh);
    } else if (def.type === 'pistol') {
      const lh = new THREE.Group();
      box(lh, 0.06, 0.07, 0.08, glove, 0, 0, 0);
      box(lh, 0.09, 0.09, 0.4, sl, 0, -0.01, 0.25);
      lh.position.set(-0.04, -0.1, 0.07);
      lh.rotation.set(0.35, -0.5, 0.2);
      g.add(lh);
    }
  } else if (hands && def.type === 'grenade') {
    const glove = std('#202124', 0.8, 0.05);
    const sl = std(sleeve, 0.9, 0.0);
    box(g, 0.08, 0.06, 0.09, glove, 0, -0.04, 0.03);
    box(g, 0.09, 0.09, 0.35, sl, 0, -0.06, 0.25, 0.3);
  }

  g.traverse(o => { if ((o as THREE.Mesh).isMesh) { (o as THREE.Mesh).castShadow = false; } });
  return { group: g, muzzle, mag };
}

/* ---------- Characters ---------- */
export interface CharModel {
  group: THREE.Group;
  body: THREE.Group;
  legL: THREE.Object3D; legR: THREE.Object3D;
  armL: THREE.Object3D; armR: THREE.Object3D;
  head: THREE.Object3D;
  gun: THREE.Mesh | null;
  xray: THREE.Mesh[];
}

const charMatCache = new Map<string, THREE.Material>();
function cm(color: string, rough = 0.85, metal = 0.05) {
  const k = color + rough + metal;
  if (!charMatCache.has(k)) charMatCache.set(k, std(color, rough, metal));
  return charMatCache.get(k)!;
}

const xrayMats: Record<string, THREE.MeshBasicMaterial> = {};
function xrayMat(color: string) {
  if (!xrayMats[color]) xrayMats[color] = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.45, depthTest: false, depthWrite: false });
  return xrayMats[color];
}

export function buildChar(kind: 'ct' | 't' | 'z' | 'ffa', gunLen = 0.7, tint?: string): CharModel {
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);
  let pants = '#2d3a52', shirt = '#34486b', vest = '#1f2a3d', skin = '#c99a74', headwear = '#1f2a3d';
  if (kind === 't') { pants = '#5a4a32'; shirt = '#7a6440'; vest = '#3a2e1e'; headwear = '#1a1a1a'; }
  if (kind === 'z') { pants = '#3b3226'; shirt = '#6a2a22'; vest = '#4a1c18'; skin = '#7f9a62'; headwear = ''; }
  if (kind === 'ffa') { pants = '#3a3a3a'; shirt = tint || '#5a2a6a'; vest = '#222'; headwear = '#333'; }

  const legs: THREE.Object3D[] = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.12, 0.9, 0);
    box(pivot, 0.18, 0.5, 0.2, cm(pants), 0, -0.25, 0);
    box(pivot, 0.16, 0.42, 0.18, cm(pants), 0, -0.66, 0);
    box(pivot, 0.18, 0.1, 0.28, cm('#1a1a1a'), 0, -0.86, -0.04);
    body.add(pivot); legs.push(pivot);
  }
  box(body, 0.46, 0.62, 0.26, cm(shirt), 0, 1.2, 0);
  box(body, 0.5, 0.42, 0.32, cm(vest), 0, 1.25, 0);
  box(body, 0.48, 0.1, 0.3, cm('#2a2a2a'), 0, 0.92, 0);
  if (kind !== 'z') {
    box(body, 0.12, 0.12, 0.06, cm('#3a3a2a'), -0.12, 1.15, -0.18);
    box(body, 0.12, 0.12, 0.06, cm('#3a3a2a'), 0.12, 1.15, -0.18);
  }
  const head = new THREE.Group();
  head.position.set(0, 1.66, 0);
  box(head, 0.26, 0.28, 0.26, cm(skin), 0, 0, 0);
  if (kind === 'ct') {
    box(head, 0.3, 0.14, 0.31, cm(headwear, 0.6, 0.2), 0, 0.12, 0.01);
    box(head, 0.22, 0.06, 0.04, cm('#111', 0.2, 0.6), 0, 0.03, -0.14);
  } else if (kind === 't' || kind === 'ffa') {
    box(head, 0.28, 0.3, 0.28, cm(headwear), 0, 0.02, 0);
    box(head, 0.2, 0.05, 0.02, cm(skin), 0, 0.03, -0.142);
  } else {
    box(head, 0.06, 0.04, 0.02, cm('#ff3020', 0.3, 0), -0.06, 0.03, -0.135);
    box(head, 0.06, 0.04, 0.02, cm('#ff3020', 0.3, 0), 0.06, 0.03, -0.135);
    box(head, 0.14, 0.04, 0.02, cm('#3a1010'), 0, -0.08, -0.135);
  }
  body.add(head);

  const arms: THREE.Object3D[] = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.31, 1.45, 0);
    box(pivot, 0.14, 0.3, 0.14, cm(shirt), 0, -0.14, 0);
    box(pivot, 0.12, 0.3, 0.12, cm(kind === 'z' ? skin : shirt), 0, -0.42, 0);
    box(pivot, 0.12, 0.1, 0.12, cm(kind === 'z' ? skin : '#1d1d1d'), 0, -0.6, 0);
    body.add(pivot); arms.push(pivot);
  }
  let gun: THREE.Mesh | null = null;
  if (kind === 'z') {
    arms[0].rotation.x = -1.45; arms[1].rotation.x = -1.35;
  } else {
    arms[0].rotation.set(-1.25, 0.5, 0);
    arms[1].rotation.set(-1.35, -0.15, 0);
    gun = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.12, gunLen), cm('#1b1b1d', 0.4, 0.6));
    gun.position.set(0.12, 1.28, -0.35 - gunLen * 0.3);
    body.add(gun);
  }

  const xray: THREE.Mesh[] = [];
  const xcol = kind === 'z' ? '#7dff3a' : '#ff2a2a';
  const meshes: THREE.Mesh[] = [];
  group.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh) { m.castShadow = true; meshes.push(m); } });
  for (const m of meshes) {
    const x = new THREE.Mesh(m.geometry, xrayMat(xcol));
    x.renderOrder = 999;
    x.visible = false;
    m.add(x);
    xray.push(x);
  }
  return { group, body, legL: legs[0], legR: legs[1], armL: arms[0], armR: arms[1], head, gun, xray };
}
