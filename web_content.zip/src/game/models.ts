import * as THREE from 'three';
import { type WeaponDef, type AttachConfig, getSkin, sanitizeAttachments } from './data/weapons';

const matCache = new Map<string, THREE.Material>();
export function stdMat(color: number, rough = 0.7, metal = 0.2, emissive = 0): THREE.MeshStandardMaterial {
  const k = `s${color}_${rough}_${metal}_${emissive}`;
  let m = matCache.get(k) as THREE.MeshStandardMaterial | undefined;
  if (!m) { m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, emissive: emissive ? color : 0x000000, emissiveIntensity: emissive }); matCache.set(k, m); }
  return m;
}
const geoCache = new Map<string, THREE.BufferGeometry>();
function boxGeo(w: number, h: number, d: number) {
  const k = `b${w.toFixed(3)}_${h.toFixed(3)}_${d.toFixed(3)}`;
  let g = geoCache.get(k); if (!g) { g = new THREE.BoxGeometry(w, h, d); geoCache.set(k, g); } return g;
}
function cylGeo(r: number, len: number, seg = 10) {
  const k = `c${r.toFixed(3)}_${len.toFixed(3)}_${seg}`;
  let g = geoCache.get(k); if (!g) { g = new THREE.CylinderGeometry(r, r, len, seg); g.rotateX(Math.PI / 2); geoCache.set(k, g); } return g;
}

function box(parent: THREE.Object3D, w: number, h: number, d: number, x: number, y: number, z: number, mat: THREE.Material, rx = 0) {
  const m = new THREE.Mesh(boxGeo(w, h, d), mat); m.position.set(x, y, z); m.rotation.x = rx; parent.add(m); return m;
}
function cyl(parent: THREE.Object3D, r: number, len: number, x: number, y: number, z: number, mat: THREE.Material, seg = 10) {
  const m = new THREE.Mesh(cylGeo(r, len, seg), mat); m.position.set(x, y, z); parent.add(m); return m;
}

export interface WeaponModel { group: THREE.Group; muzzle: THREE.Object3D; sightY: number; mag: THREE.Object3D | null; length: number }

/** Procedural weapon model: every weapon gets a distinct silhouette from its ModelSpec; attachments are visible */
export function buildWeaponModel(def: WeaponDef, cfgIn: AttachConfig = {}, skinId = 'default'): WeaponModel {
  const cfg = sanitizeAttachments(def, cfgIn);
  const spec = def.model; const t = spec.thick;
  const skin = getSkin(skinId);
  const bodyMat = stdMat(skin.color ?? spec.color, skin.metal ? 0.35 : 0.65, skin.metal ?? 0.35);
  const accMat = stdMat(spec.accent, 0.6, 0.3);
  const dark = stdMat(0x121314, 0.5, 0.7);
  const lens = stdMat(0x3060a0, 0.1, 0.9, 0.4);
  const g = new THREE.Group();
  const isPistol = def.category === 'PISTOL';
  let barrelLen = spec.barrel * (cfg.barrel === 'bar_long' ? 1.35 : cfg.barrel === 'bar_short' ? 0.7 : 1);
  const recvH = (isPistol ? 0.075 : 0.085) * t, recvW = (isPistol ? 0.045 : 0.06) * t;
  const L = spec.body;
  let topY = recvH / 2;
  let zMuzzle = -spec.body;

  if (isPistol) {
    box(g, recvW, recvH * 0.55, L, 0, recvH * 0.22, -L / 2 + 0.04, bodyMat); // slide
    box(g, recvW * 0.92, recvH * 0.45, L * 0.85, 0, -recvH * 0.25, -L / 2 + 0.06, dark); // frame
    box(g, recvW * 0.9, 0.12, 0.05, 0, -0.08, 0.02, accMat, 0.25); // grip
    box(g, recvW * 0.3, 0.012, 0.012, 0, recvH * 0.52, -L + 0.06, dark); // front sight
    if (def.id === 'p02') cyl(g, 0.032, 0.06, 0, recvH * 0.0, -0.06, dark, 8); // cylinder
    topY = recvH * 0.5;
  } else {
    const zFront = -L + 0.1;
    box(g, recvW, recvH, L, 0, 0, -L / 2 + 0.1, bodyMat); // receiver
    box(g, recvW * 1.15, recvH * 0.75, L * 0.45, 0, -0.005, zFront + L * 0.22, accMat); // handguard
    box(g, recvW * 0.4, 0.012, L * 0.85, 0, recvH / 2 + 0.006, -L / 2 + 0.1, dark); // top rail
    box(g, recvW * 0.85, 0.11, 0.045, 0, -0.08, 0.04, dark, 0.3); // pistol grip
    // stock
    switch (spec.stock) {
      case 'full': box(g, recvW * 0.9, recvH * 1.1, 0.24, 0, -0.01, 0.28, bodyMat); box(g, recvW, recvH * 1.4, 0.03, 0, -0.015, 0.4, dark); break;
      case 'heavy': box(g, recvW * 1.1, recvH * 1.5, 0.28, 0, -0.02, 0.3, bodyMat); box(g, recvW * 1.15, recvH * 1.7, 0.04, 0, -0.025, 0.45, dark); break;
      case 'skeleton': box(g, 0.012, 0.012, 0.26, 0, 0.02, 0.27, dark); box(g, 0.012, 0.012, 0.26, 0, -0.04, 0.27, dark); box(g, recvW, recvH * 1.3, 0.025, 0, -0.01, 0.4, dark); break;
      case 'bullpup': box(g, recvW * 1.05, recvH * 1.2, 0.18, 0, -0.01, 0.2, bodyMat); break;
      case 'none': break;
    }
    if (cfg.stock === 'stk_heavy') box(g, recvW * 1.3, recvH * 1.4, 0.06, 0, -0.03, 0.42, accMat);
    if (cfg.stock === 'stk_light') box(g, 0.01, 0.06, 0.2, 0, 0, 0.3, accMat);
    // magazine
    let mag: THREE.Object3D | null = new THREE.Group();
    const magZ = spec.stock === 'bullpup' ? 0.14 : -L * 0.3;
    const ext = cfg.mag === 'mag_ext' ? 1.45 : 1;
    switch (spec.mag) {
      case 'curved': for (let i = 0; i < 3; i++) box(mag, recvW * 0.7, 0.06 * ext, 0.05, 0, -0.06 - i * 0.05 * ext, -i * 0.015, i % 2 ? accMat : dark, -0.18 * i); break;
      case 'straight': box(mag, recvW * 0.7, 0.16 * ext, 0.045, 0, -0.11 * ext, 0, dark); break;
      case 'box': box(mag, recvW * 0.8, 0.07 * ext, 0.07, 0, -0.07, 0, dark); break;
      case 'drum': { const d = cyl(mag, 0.07 * Math.sqrt(ext), 0.07, 0, -0.1, 0, dark, 14); d.rotation.y = Math.PI / 2; break; }
      case 'tube': cyl(g, 0.016, barrelLen * 0.9, 0, -0.035, zFront - barrelLen * 0.4, dark); box(g, recvW * 1.25, recvH * 0.7, 0.12, 0, -0.04, zFront - 0.04, accMat); mag = null; break;
      case 'top': box(mag, recvW * 1.1, 0.03, L * 0.8 * ext, 0, recvH * 0.5 + 0.015, -L * 0.25 + 0.3, accMat); break;
      case 'pistol': mag = null; break;
    }
    if (mag) { mag.position.set(0, 0, spec.mag === 'top' ? -0.3 : magZ); g.add(mag); if (spec.mag === 'top') topY += 0.03; }
    // barrel
    cyl(g, 0.012 * t + 0.003, barrelLen, 0, 0.005, zFront - barrelLen / 2, dark);
    // underbarrel
    if (cfg.grip === 'grip_vert') box(g, 0.03, 0.09, 0.035, 0, -0.085, zFront + L * 0.15, dark);
    if (cfg.grip === 'grip_angle') box(g, 0.03, 0.04, 0.09, 0, -0.06, zFront + L * 0.15, dark, -0.5);
    if (cfg.grip === 'grip_laser') { box(g, 0.03, 0.03, 0.08, 0.04, -0.01, zFront + 0.05, dark); cyl(g, 0.006, 0.01, 0.04, -0.01, zFront, stdMat(0xff2020, 0.2, 0, 2)); }
    zMuzzle = zFront - barrelLen;
    // integrated sights from model spec when no optic
    if (!cfg.optic) {
      if (spec.scope === 'dot') { box(g, 0.035, 0.035, 0.06, 0, topY + 0.025, -L * 0.35, dark); box(g, 0.025, 0.022, 0.003, 0, topY + 0.028, -L * 0.35 - 0.03, lens); topY += 0.03; }
      else if (spec.scope === 'big') { cyl(g, 0.024, 0.26, 0, topY + 0.04, -L * 0.35, dark, 12); box(g, 0.02, 0.04, 0.02, 0, topY + 0.015, -L * 0.25, dark); box(g, 0.02, 0.04, 0.02, 0, topY + 0.015, -L * 0.45, dark); topY += 0.04; }
      else { box(g, 0.012, 0.03, 0.012, 0, topY + 0.015, zFront + 0.02, dark); box(g, 0.03, 0.025, 0.012, 0, topY + 0.012, -0.02, dark); topY += 0.02; }
    }
  }
  // optics
  if (cfg.optic) {
    const oz = isPistol ? -0.08 : -L * 0.35;
    if (cfg.optic === 'opt_dot') { box(g, 0.03, 0.03, 0.05, 0, topY + 0.02, oz, dark); box(g, 0.022, 0.02, 0.003, 0, topY + 0.024, oz - 0.025, lens); topY += 0.025; }
    if (cfg.optic === 'opt_holo') { box(g, 0.05, 0.012, 0.08, 0, topY + 0.006, oz, dark); box(g, 0.05, 0.045, 0.006, 0, topY + 0.03, oz - 0.035, dark); box(g, 0.04, 0.032, 0.002, 0, topY + 0.032, oz - 0.03, lens); topY += 0.03; }
    if (cfg.optic === 'opt_acog') { cyl(g, 0.022, 0.14, 0, topY + 0.035, oz, accMat, 8); box(g, 0.03, 0.03, 0.06, 0, topY + 0.012, oz, dark); topY += 0.035; }
    if (cfg.optic === 'opt_8x') { cyl(g, 0.028, 0.3, 0, topY + 0.042, oz, dark, 12); cyl(g, 0.034, 0.05, 0, topY + 0.042, oz - 0.14, dark, 12); topY += 0.042; }
  }
  // muzzle
  let zm: number = isPistol ? -spec.body + 0.04 : zMuzzle;
  if (def.suppressed || cfg.muzzle === 'muz_supp') { cyl(g, 0.022, 0.16, 0, 0.005, zm - 0.08, dark, 10); zm -= 0.16; }
  else if (cfg.muzzle === 'muz_comp') { box(g, 0.035, 0.035, 0.06, 0, 0.005, zm - 0.03, accMat); zm -= 0.06; }
  else if (cfg.muzzle === 'muz_flash') { cyl(g, 0.018, 0.06, 0, 0.005, zm - 0.03, dark, 6); zm -= 0.06; }
  const muzzle = new THREE.Object3D(); muzzle.position.set(0, 0.005, zm); g.add(muzzle);
  g.traverse(o => { if ((o as THREE.Mesh).isMesh) { o.castShadow = true; } });
  return { group: g, muzzle, sightY: topY, mag: g.children.find(c => c.type === 'Group') ?? null, length: -zm };
}

// ---------------- SOLDIER ----------------
export interface SoldierRefs {
  root: THREE.Group; body: THREE.Group; head: THREE.Object3D; legL: THREE.Group; legR: THREE.Group; armL: THREE.Group; armR: THREE.Group; gun: THREE.Object3D; chest: THREE.Object3D;
}
export interface SoldierColors { uniform: number; vest: number; skin: number; helmet: number; accent: number }

export function buildSoldier(c: SoldierColors, detailed = false): SoldierRefs {
  const uni = stdMat(c.uniform, 0.9, 0), vest = stdMat(c.vest, 0.8, 0.05), skin = stdMat(c.skin, 0.7, 0), helm = stdMat(c.helmet, 0.6, 0.2);
  const acc = stdMat(c.accent, 0.5, 0.2, detailed ? 0.25 : 0.6), dark = stdMat(0x18191b, 0.6, 0.4), boot = stdMat(0x1e1a16, 0.9, 0);
  const root = new THREE.Group(); const body = new THREE.Group(); root.add(body);
  const mkLeg = (x: number) => { const p = new THREE.Group(); p.position.set(x, 0.92, 0); box(p, 0.19, 0.48, 0.22, 0, -0.24, 0, uni); box(p, 0.18, 0.46, 0.2, 0, -0.68, 0.0, uni); box(p, 0.2, 0.12, 0.3, 0, -0.86, -0.04, boot); if (detailed) box(p, 0.2, 0.12, 0.08, 0, -0.5, -0.1, dark); body.add(p); return p; };
  const legL = mkLeg(-0.12), legR = mkLeg(0.12);
  const chest = new THREE.Group(); chest.position.y = 0.92; body.add(chest);
  box(chest, 0.48, 0.6, 0.26, 0, 0.3, 0, uni);
  box(chest, 0.52, 0.42, 0.32, 0, 0.36, 0, vest);
  box(chest, 0.44, 0.06, 0.02, 0, 0.5, -0.165, acc); // team stripe
  if (detailed) {
    for (let i = -1; i <= 1; i++) box(chest, 0.1, 0.13, 0.06, i * 0.14, 0.24, -0.18, dark);
    box(chest, 0.38, 0.42, 0.18, 0, 0.36, 0.24, vest); // backpack
    box(chest, 0.02, 0.4, 0.02, 0.14, 0.75, 0.28, dark); // antenna
    box(chest, 0.5, 0.08, 0.3, 0, 0.04, 0, dark); // belt
  }
  const head = new THREE.Group(); head.position.y = 0.62; chest.add(head);
  box(head, 0.2, 0.1, 0.22, 0, 0.05, 0, skin); // neck/jaw
  box(head, 0.22, 0.22, 0.24, 0, 0.17, 0, skin);
  box(head, 0.26, 0.12, 0.28, 0, 0.3, 0.01, helm); // helmet
  box(head, 0.28, 0.03, 0.3, 0, 0.245, -0.01, helm);
  box(head, 0.2, 0.05, 0.02, 0, 0.19, -0.125, dark); // goggles/visor
  if (detailed) { box(head, 0.06, 0.06, 0.06, 0, 0.36, -0.13, dark); box(head, 0.22, 0.08, 0.03, 0, 0.1, -0.125, stdMat(c.vest, 0.9, 0)); }
  const mkArm = (x: number) => { const p = new THREE.Group(); p.position.set(x, 0.52, 0); box(p, 0.15, 0.32, 0.15, 0, -0.16, 0, uni); box(p, 0.13, 0.3, 0.13, 0, -0.45, 0, uni); box(p, 0.11, 0.1, 0.12, 0, -0.63, 0, stdMat(0x2a2620, 0.9, 0)); chest.add(p); return p; };
  const armL = mkArm(-0.31), armR = mkArm(0.31);
  armR.rotation.x = -1.25; armL.rotation.x = -1.4; armL.rotation.z = 0.5; armR.rotation.z = -0.1;
  const gun = new THREE.Group(); gun.position.set(0.12, 0.32, -0.42); chest.add(gun);
  box(gun, 0.07, 0.1, 0.7, 0, 0, 0, dark); box(gun, 0.05, 0.14, 0.06, 0, -0.1, 0.05, dark); box(gun, 0.03, 0.03, 0.3, 0, 0.01, -0.45, dark);
  root.traverse(o => { if ((o as THREE.Mesh).isMesh) { o.castShadow = true; } });
  return { root, body, head, legL, legR, armL, armR, gun, chest };
}

/** Procedural animation: walk cycle, aim pitch, crouch and death fall */
export function animateSoldier(r: SoldierRefs, phase: number, speed: number, aimPitch: number, crouch: number, deadT: number) {
  if (deadT > 0) {
    const k = Math.min(1, deadT * 2.5);
    r.body.rotation.x = k * 1.45; r.body.position.y = -k * 0.15 + Math.sin(k * Math.PI) * 0.15; r.body.position.z = k * 0.6;
    r.legL.rotation.x = r.legR.rotation.x = 0; return;
  }
  r.body.rotation.x = 0; r.body.position.z = 0;
  const sw = Math.sin(phase) * Math.min(1, speed / 4) * 0.7;
  r.legL.rotation.x = sw - crouch * 0.9; r.legR.rotation.x = -sw - crouch * 0.9;
  r.body.position.y = -crouch * 0.35 + Math.abs(Math.cos(phase)) * Math.min(1, speed / 4) * 0.04;
  r.chest.rotation.x = aimPitch * 0.5 + crouch * 0.25;
  r.head.rotation.x = aimPitch * 0.5;
}
