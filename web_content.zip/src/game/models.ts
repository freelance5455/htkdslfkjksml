import * as THREE from 'three';
import { WeaponType, LootType } from './types';

// Shared materials and geometries for efficiency
const playerMaterial = new THREE.MeshStandardMaterial({
  color: 0xf59e0b, // Free Fire golden yellow
  roughness: 0.4,
  metalness: 0.1,
});

const vestMaterial = new THREE.MeshStandardMaterial({
  color: 0x1e293b,
  roughness: 0.8,
  metalness: 0.2,
});

const skinMaterial = new THREE.MeshStandardMaterial({
  color: 0xd97706,
  roughness: 0.6,
  metalness: 0.05,
});

const visorMaterial = new THREE.MeshStandardMaterial({
  color: 0x06b6d4,
  roughness: 0.1,
  metalness: 0.9,
  emissive: 0x0891b2,
  emissiveIntensity: 0.4,
});

const bootMaterial = new THREE.MeshStandardMaterial({
  color: 0x0f172a,
  roughness: 0.9,
  metalness: 0.1,
});

// Helper for bot colors
export function createBotMaterial(variant: number) {
  const colors = [0xdc2626, 0x2563eb, 0x16a34a, 0x7c3aed, 0xe11d48];
  return new THREE.MeshStandardMaterial({
    color: colors[variant % colors.length],
    roughness: 0.45,
    metalness: 0.15,
  });
}

/**
 * Creates a high-detail composite character (10 distinct parts)
 * Bottom-center pivot so it sits flush on terrain
 */
export function createCharacterModel(isPlayer: boolean = false, botIndex: number = 0) {
  const root = new THREE.Group();

  const mainMat = isPlayer ? playerMaterial : createBotMaterial(botIndex);

  // 1. Pelvis / Hips (pivot near y=0.95)
  const pelvisGeo = new THREE.BoxGeometry(0.5, 0.25, 0.35);
  const pelvis = new THREE.Mesh(pelvisGeo, vestMaterial);
  pelvis.position.y = 0.95;
  pelvis.castShadow = true;
  root.add(pelvis);

  // Tactical belt with ammo pouches
  const beltGeo = new THREE.BoxGeometry(0.54, 0.08, 0.38);
  const beltMat = new THREE.MeshStandardMaterial({ color: 0x0a0f1d, roughness: 0.9 });
  const belt = new THREE.Mesh(beltGeo, beltMat);
  belt.position.y = 0.98;
  root.add(belt);

  // Pouch 1 & 2
  const pouchGeo = new THREE.BoxGeometry(0.12, 0.1, 0.08);
  const pouch1 = new THREE.Mesh(pouchGeo, vestMaterial);
  pouch1.position.set(0.18, 0.95, 0.2);
  const pouch2 = new THREE.Mesh(pouchGeo, vestMaterial);
  pouch2.position.set(-0.18, 0.95, 0.2);
  root.add(pouch1, pouch2);

  // 2. Torso (Vest + Under-shirt)
  const torsoGroup = new THREE.Group();
  torsoGroup.position.y = 1.05;

  const shirtGeo = new THREE.BoxGeometry(0.52, 0.55, 0.36);
  const shirt = new THREE.Mesh(shirtGeo, mainMat);
  shirt.position.y = 0.28;
  shirt.castShadow = true;
  torsoGroup.add(shirt);

  // Tactical Chest Armor / Vest
  const vestGeo = new THREE.BoxGeometry(0.56, 0.45, 0.4);
  const vest = new THREE.Mesh(vestGeo, vestMaterial);
  vest.position.y = 0.28;
  vest.castShadow = true;
  torsoGroup.add(vest);

  // 3. Head & Helmet / Headband
  const headGroup = new THREE.Group();
  headGroup.position.y = 0.6;

  const headGeo = new THREE.BoxGeometry(0.28, 0.3, 0.28);
  const head = new THREE.Mesh(headGeo, skinMaterial);
  head.position.y = 0.16;
  head.castShadow = true;
  headGroup.add(head);

  // Combat Visor / Cyber Sunglasses (Free Fire look)
  const visorGeo = new THREE.BoxGeometry(0.3, 0.1, 0.14);
  const visor = new THREE.Mesh(visorGeo, visorMaterial);
  visor.position.set(0, 0.18, 0.12);
  headGroup.add(visor);

  // Combat cap / helmet
  const capGeo = new THREE.BoxGeometry(0.32, 0.12, 0.32);
  const cap = new THREE.Mesh(capGeo, isPlayer ? vestMaterial : mainMat);
  cap.position.y = 0.32;
  headGroup.add(cap);

  torsoGroup.add(headGroup);
  root.add(torsoGroup);

  // 4. Arms (Left & Right)
  const leftArmGroup = new THREE.Group();
  leftArmGroup.position.set(-0.35, 1.48, 0);

  const armGeo = new THREE.BoxGeometry(0.14, 0.5, 0.14);
  const leftArm = new THREE.Mesh(armGeo, mainMat);
  leftArm.position.y = -0.22;
  leftArm.castShadow = true;
  leftArmGroup.add(leftArm);

  // Tactical Glove
  const gloveGeo = new THREE.BoxGeometry(0.15, 0.16, 0.15);
  const leftGlove = new THREE.Mesh(gloveGeo, bootMaterial);
  leftGlove.position.y = -0.42;
  leftArmGroup.add(leftGlove);
  root.add(leftArmGroup);

  const rightArmGroup = new THREE.Group();
  rightArmGroup.position.set(0.35, 1.48, 0);

  const rightArm = new THREE.Mesh(armGeo, mainMat);
  rightArm.position.y = -0.22;
  rightArm.castShadow = true;
  rightArmGroup.add(rightArm);

  const rightGlove = new THREE.Mesh(gloveGeo, bootMaterial);
  rightGlove.position.y = -0.42;
  rightArmGroup.add(rightGlove);

  // Weapon attachment point
  const weaponHolder = new THREE.Group();
  weaponHolder.position.set(0, -0.42, 0.2);
  rightArmGroup.add(weaponHolder);
  root.add(rightArmGroup);

  // 5. Legs (Left & Right)
  const leftLegGroup = new THREE.Group();
  leftLegGroup.position.set(-0.16, 0.9, 0);

  const legGeo = new THREE.BoxGeometry(0.18, 0.58, 0.2);
  const leftLeg = new THREE.Mesh(legGeo, vestMaterial);
  leftLeg.position.y = -0.26;
  leftLeg.castShadow = true;
  leftLegGroup.add(leftLeg);

  // Knee pad
  const padGeo = new THREE.BoxGeometry(0.2, 0.14, 0.08);
  const leftPad = new THREE.Mesh(padGeo, isPlayer ? playerMaterial : bootMaterial);
  leftPad.position.set(0, -0.22, 0.1);
  leftLegGroup.add(leftPad);

  // Combat boot
  const bootGeo = new THREE.BoxGeometry(0.19, 0.2, 0.28);
  const leftBoot = new THREE.Mesh(bootGeo, bootMaterial);
  leftBoot.position.set(0, -0.58, 0.04);
  leftBoot.castShadow = true;
  leftLegGroup.add(leftBoot);
  root.add(leftLegGroup);

  const rightLegGroup = new THREE.Group();
  rightLegGroup.position.set(0.16, 0.9, 0);

  const rightLeg = new THREE.Mesh(legGeo, vestMaterial);
  rightLeg.position.y = -0.26;
  rightLeg.castShadow = true;
  rightLegGroup.add(rightLeg);

  const rightPad = new THREE.Mesh(padGeo, isPlayer ? playerMaterial : bootMaterial);
  rightPad.position.set(0, -0.22, 0.1);
  rightLegGroup.add(rightPad);

  const rightBoot = new THREE.Mesh(bootGeo, bootMaterial);
  rightBoot.position.set(0, -0.58, 0.04);
  rightBoot.castShadow = true;
  rightLegGroup.add(rightBoot);
  root.add(rightLegGroup);

  // Contact shadow
  const shadowGeo = new THREE.PlaneGeometry(1.2, 1.2);
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 64;
  shadowCanvas.height = 64;
  const ctx = shadowCanvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.55)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  const shadowTex = new THREE.CanvasTexture(shadowCanvas);
  shadowTex.colorSpace = THREE.SRGBColorSpace;

  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    depthWrite: false,
  });
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.rotation.x = -Math.PI / 2;
  shadowMesh.position.y = 0.02;
  root.add(shadowMesh);

  return {
    root,
    torsoGroup,
    headGroup,
    leftArmGroup,
    rightArmGroup,
    leftLegGroup,
    rightLegGroup,
    weaponHolder,
  };
}

/**
 * Creates 3D Weapon Models (Composite 4-8 parts)
 */
export function createWeaponModel(type: WeaponType): THREE.Group {
  const group = new THREE.Group();
  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x1f2937,
    roughness: 0.35,
    metalness: 0.85,
  });
  const darkMetal = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.25,
    metalness: 0.9,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x854d0e,
    roughness: 0.75,
    metalness: 0.05,
  });
  const goldAccentMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.2,
    metalness: 0.85,
  });

  if (type === 'ar') {
    // AK-47 style
    // Receiver
    const rec = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, 0.55), metalMat);
    rec.position.z = 0.1;
    group.add(rec);

    // Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.65, 8), darkMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.z = 0.65;
    group.add(barrel);

    // Muzzle brake
    const muzzle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.1, 8), darkMetal);
    muzzle.rotation.x = Math.PI / 2;
    muzzle.position.z = 0.98;
    group.add(muzzle);

    // Curved Banana Magazine
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.28, 0.14), goldAccentMat);
    mag.position.set(0, -0.16, 0.18);
    mag.rotation.x = 0.25;
    group.add(mag);

    // Wood Stock
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.16, 0.35), woodMat);
    stock.position.set(0, -0.04, -0.3);
    group.add(stock);

    // Handguard
    const handguard = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.1, 0.32), woodMat);
    handguard.position.set(0, 0, 0.45);
    group.add(handguard);

    // Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.18, 0.08), woodMat);
    grip.position.set(0, -0.12, -0.05);
    grip.rotation.x = -0.3;
    group.add(grip);
  } else if (type === 'shotgun') {
    // M1887 Double Barrel
    // Twin barrels
    const barrel1 = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.7, 8), darkMetal);
    barrel1.rotation.x = Math.PI / 2;
    barrel1.position.set(0.025, 0.03, 0.4);

    const barrel2 = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.7, 8), darkMetal);
    barrel2.rotation.x = Math.PI / 2;
    barrel2.position.set(-0.025, 0.03, 0.4);
    group.add(barrel1, barrel2);

    // Receiver
    const rec = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.12, 0.3), metalMat);
    rec.position.z = 0.05;
    group.add(rec);

    // Grip / Stock
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 0.4), woodMat);
    stock.position.set(0, -0.06, -0.22);
    stock.rotation.x = -0.15;
    group.add(stock);

    // Lever guard
    const lever = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.015, 6, 12, Math.PI), metalMat);
    lever.position.set(0, -0.1, -0.05);
    lever.rotation.y = Math.PI / 2;
    group.add(lever);
  } else if (type === 'sniper') {
    // AWM Sniper Rifle
    const sniperBodyMat = new THREE.MeshStandardMaterial({
      color: 0x15803d, // Military olive green
      roughness: 0.5,
      metalness: 0.2,
    });

    // Heavy long stock & chassis
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.14, 0.8), sniperBodyMat);
    body.position.z = 0.1;
    group.add(body);

    // Long Barrel
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.95, 8), darkMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.z = 0.85;
    group.add(barrel);

    // Muzzle suppressor/brake
    const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.18), darkMetal);
    muzzle.position.z = 1.35;
    group.add(muzzle);

    // High-tech Optic Scope
    const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.38, 8), darkMetal);
    scopeTube.rotation.x = Math.PI / 2;
    scopeTube.position.set(0, 0.14, 0.15);
    group.add(scopeTube);

    // Scope lens
    const lensMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.05,
      metalness: 0.9,
      emissive: 0x0284c7,
      emissiveIntensity: 0.5,
    });
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.035, 12), lensMat);
    lens.position.set(0, 0.14, 0.34);
    group.add(lens);

    // Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.18, 0.09), darkMetal);
    grip.position.set(0, -0.12, -0.1);
    grip.rotation.x = -0.3;
    group.add(grip);
  } else {
    // Pistol / Desert Eagle
    const slide = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.09, 0.28), metalMat);
    slide.position.z = 0.06;
    group.add(slide);

    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.18, 0.08), darkMetal);
    grip.position.set(0, -0.1, -0.05);
    grip.rotation.x = -0.25;
    group.add(grip);

    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.12, 8), darkMetal);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.z = 0.22;
    group.add(barrel);
  }

  // Scale weapon appropriately
  group.scale.set(1.1, 1.1, 1.1);
  return group;
}

/**
 * Creates Free Fire's iconic GLOO WALL!
 * An ice-blue futuristic nano-shield with cyber metallic brackets
 */
export function createGlooWallMesh(): THREE.Group {
  const wallGroup = new THREE.Group();

  // Curved holographic ice shield
  const shieldGeo = new THREE.CylinderGeometry(3.2, 3.2, 2.5, 18, 1, true, -Math.PI * 0.35, Math.PI * 0.7);
  const shieldMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    roughness: 0.15,
    metalness: 0.3,
    transparent: true,
    opacity: 0.88,
    emissive: 0x0284c7,
    emissiveIntensity: 0.6,
    side: THREE.DoubleSide,
  });
  const shield = new THREE.Mesh(shieldGeo, shieldMat);
  shield.position.y = 1.25;
  shield.castShadow = true;
  shield.receiveShadow = true;
  wallGroup.add(shield);

  // Outer ice crest border
  const crestGeo = new THREE.TorusGeometry(3.25, 0.08, 6, 20, Math.PI * 0.7);
  const crestMat = new THREE.MeshStandardMaterial({
    color: 0xbae6fd,
    roughness: 0.1,
    metalness: 0.8,
    emissive: 0x38bdf8,
    emissiveIntensity: 0.8,
  });
  const topCrest = new THREE.Mesh(crestGeo, crestMat);
  topCrest.rotation.x = Math.PI / 2;
  topCrest.rotation.z = Math.PI * 0.15;
  topCrest.position.y = 2.5;
  wallGroup.add(topCrest);

  // Base metal anchors
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.6,
    metalness: 0.7,
  });
  for (let i = -2; i <= 2; i++) {
    const anchor = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.4, 0.5), baseMat);
    const angle = (i / 2) * 0.3 * Math.PI;
    anchor.position.set(Math.sin(angle) * 3.2, 0.2, Math.cos(angle) * 3.2 - 3.0);
    anchor.rotation.y = angle;
    anchor.castShadow = true;
    wallGroup.add(anchor);
  }

  return wallGroup;
}

/**
 * Creates 3D Palm Tree (Composite: segmented trunk, crown fronds, coconuts)
 */
export function createPalmTree(): THREE.Group {
  const tree = new THREE.Group();

  const trunkMat = new THREE.MeshStandardMaterial({
    color: 0x78350f,
    roughness: 0.85,
    metalness: 0.05,
  });
  const leafMat = new THREE.MeshStandardMaterial({
    color: 0x15803d,
    roughness: 0.55,
    metalness: 0.05,
    side: THREE.DoubleSide,
  });

  // Curved segmented trunk (4 segments)
  let currentY = 0;
  let currentX = 0;
  for (let i = 0; i < 5; i++) {
    const segHeight = 1.2;
    const seg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24 - i * 0.02, 0.28 - i * 0.02, segHeight, 7),
      trunkMat
    );
    seg.position.set(currentX, currentY + segHeight / 2, 0);
    seg.rotation.z = -0.06;
    seg.castShadow = true;
    tree.add(seg);
    currentY += segHeight * 0.95;
    currentX += 0.08;
  }

  // Palm Crown Fronds (8 leaflets radiating outward and bending downward)
  const leafCount = 8;
  for (let i = 0; i < leafCount; i++) {
    const angle = (i / leafCount) * Math.PI * 2;
    const frondGroup = new THREE.Group();
    frondGroup.position.set(currentX, currentY, 0);
    frondGroup.rotation.y = angle;

    const frondGeo = new THREE.ConeGeometry(0.7, 3.2, 4);
    frondGeo.scale(1, 1, 0.15);
    const frond = new THREE.Mesh(frondGeo, leafMat);
    frond.position.set(0, -0.4, 1.4);
    frond.rotation.x = 1.1; // bent down
    frond.castShadow = true;

    frondGroup.add(frond);
    tree.add(frondGroup);
  }

  // Coconuts
  const nutMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9 });
  for (let i = 0; i < 3; i++) {
    const nut = new THREE.Mesh(new THREE.DodecahedronGeometry(0.18), nutMat);
    const ang = (i / 3) * Math.PI * 2;
    nut.position.set(currentX + Math.sin(ang) * 0.25, currentY - 0.2, Math.cos(ang) * 0.25);
    tree.add(nut);
  }

  return tree;
}

/**
 * Creates Pine / Fir Tree (Composite: trunk + 3 layered conical crowns)
 */
export function createPineTree(): THREE.Group {
  const tree = new THREE.Group();
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9 });
  const needleMat = new THREE.MeshStandardMaterial({ color: 0x14532d, roughness: 0.6 });

  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.45, 2.5, 8), trunkMat);
  trunk.position.y = 1.25;
  trunk.castShadow = true;
  tree.add(trunk);

  // 3 conical foliage layers
  const layers = [
    { y: 3.2, r: 2.2, h: 2.5 },
    { y: 4.8, r: 1.7, h: 2.2 },
    { y: 6.2, r: 1.1, h: 1.9 },
  ];

  layers.forEach((l) => {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(l.r, l.h, 7), needleMat);
    cone.position.y = l.y;
    cone.castShadow = true;
    tree.add(cone);
  });

  return tree;
}

/**
 * Creates Shipping Container obstacle
 */
export function createContainer(color: number = 0xb91c1c): THREE.Group {
  const group = new THREE.Group();
  const mainMat = new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.4 });
  const trimMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.8, metalness: 0.3 });

  // Main hull
  const hull = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.4, 6.0), mainMat);
  hull.position.y = 1.2;
  hull.castShadow = true;
  hull.receiveShadow = true;
  group.add(hull);

  // Corner posts
  const postGeo = new THREE.BoxGeometry(0.2, 2.45, 0.2);
  const corners = [
    [-1.3, -3.0],
    [1.3, -3.0],
    [-1.3, 3.0],
    [1.3, 3.0],
  ];
  corners.forEach(([cx, cz]) => {
    const post = new THREE.Mesh(postGeo, trimMat);
    post.position.set(cx, 1.2, cz);
    post.castShadow = true;
    group.add(post);
  });

  return group;
}

/**
 * Creates Village Building / Bunker
 */
export function createHouse(): THREE.Group {
  const group = new THREE.Group();
  const wallMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.9 });
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.5, metalness: 0.3 });
  const timberMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 });

  // Base concrete platform
  const foundation = new THREE.Mesh(
    new THREE.BoxGeometry(8.2, 0.4, 8.2),
    new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.9 })
  );
  foundation.position.y = 0.2;
  foundation.receiveShadow = true;
  group.add(foundation);

  // Main walls (box with door opening)
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(8, 3.2, 0.4), wallMat);
  backWall.position.set(0, 2.0, -3.8);
  backWall.castShadow = true;
  group.add(backWall);

  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.2, 7.6), wallMat);
  leftWall.position.set(-3.8, 2.0, 0);
  leftWall.castShadow = true;
  group.add(leftWall);

  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.2, 7.6), wallMat);
  rightWall.position.set(3.8, 2.0, 0);
  rightWall.castShadow = true;
  group.add(rightWall);

  // Front wall segments with door gap
  const frontLeft = new THREE.Mesh(new THREE.BoxGeometry(2.8, 3.2, 0.4), wallMat);
  frontLeft.position.set(-2.6, 2.0, 3.8);
  frontLeft.castShadow = true;
  group.add(frontLeft);

  const frontRight = new THREE.Mesh(new THREE.BoxGeometry(2.8, 3.2, 0.4), wallMat);
  frontRight.position.set(2.6, 2.0, 3.8);
  frontRight.castShadow = true;
  group.add(frontRight);

  const doorHeader = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.8, 0.4), timberMat);
  doorHeader.position.set(0, 3.2, 3.8);
  group.add(doorHeader);

  // Pitched Roof
  const roof = new THREE.Mesh(new THREE.ConeGeometry(6.2, 2.2, 4), roofMat);
  roof.position.y = 4.7;
  roof.rotation.y = Math.PI / 4;
  roof.castShadow = true;
  group.add(roof);

  return group;
}

/**
 * Creates Military Watchtower
 */
export function createWatchtower(): THREE.Group {
  const group = new THREE.Group();
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x5a3825, roughness: 0.85 });
  const steelMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.8 });

  // 4 Legs
  const legGeo = new THREE.CylinderGeometry(0.12, 0.16, 7.5, 6);
  const legCoords = [
    [-1.6, -1.6],
    [1.6, -1.6],
    [-1.6, 1.6],
    [1.6, 1.6],
  ];

  legCoords.forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(legGeo, woodMat);
    leg.position.set(lx, 3.75, lz);
    leg.castShadow = true;
    group.add(leg);
  });

  // Cross struts
  const strutMat = woodMat;
  for (let y = 2; y <= 6; y += 2) {
    const strut = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.1, 0.1), strutMat);
    strut.position.set(0, y, -1.6);
    group.add(strut);
    const strut2 = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.1, 0.1), strutMat);
    strut2.position.set(0, y, 1.6);
    group.add(strut2);
  }

  // Upper Platform
  const floor = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.25, 3.8), woodMat);
  floor.position.y = 7.5;
  floor.castShadow = true;
  floor.receiveShadow = true;
  group.add(floor);

  // Platform Railing
  const railing = new THREE.Mesh(new THREE.BoxGeometry(3.7, 0.9, 0.08), woodMat);
  railing.position.set(0, 8.0, 1.85);
  group.add(railing);

  // Sheet metal roof
  const roof = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.15, 4.2), steelMat);
  roof.position.y = 9.8;
  roof.castShadow = true;
  group.add(roof);

  return group;
}

/**
 * Creates Rocks / Boulders
 */
export function createRock(): THREE.Group {
  const group = new THREE.Group();
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    roughness: 0.9,
    metalness: 0.1,
  });

  const geo = new THREE.DodecahedronGeometry(1.4, 1);
  const rock = new THREE.Mesh(geo, rockMat);
  rock.scale.set(1.4, 0.85, 1.1);
  rock.position.y = 0.6;
  rock.castShadow = true;
  rock.receiveShadow = true;
  group.add(rock);

  return group;
}

/**
 * Creates Airdrop Supply Crate (Free Fire classic with beacon smoke!)
 */
export function createAirdropCrate(): THREE.Group {
  const group = new THREE.Group();
  const boxMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626, // Bright red
    roughness: 0.4,
    metalness: 0.3,
  });
  const topMat = new THREE.MeshStandardMaterial({
    color: 0x2563eb, // Blue tarp top
    roughness: 0.6,
  });

  const box = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.5, 1.6), boxMat);
  box.position.y = 0.75;
  box.castShadow = true;
  box.receiveShadow = true;
  group.add(box);

  const tarp = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.25, 1.65), topMat);
  tarp.position.y = 1.5;
  group.add(tarp);

  // Vertical light beacon column reaching up
  const beamGeo = new THREE.CylinderGeometry(0.12, 0.6, 40, 12, 1, true);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0xfacc15, // Golden yellow beacon light
    transparent: true,
    opacity: 0.6,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const beam = new THREE.Mesh(beamGeo, beamMat);
  beam.position.y = 20;
  group.add(beam);

  return group;
}

/**
 * Creates 3D Ground Loot Pickups with floating glowing aura
 */
export function createLootMesh(type: LootType): THREE.Group {
  const group = new THREE.Group();

  // Floating pedestal ring
  const ringGeo = new THREE.RingGeometry(0.4, 0.6, 16);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0xf59e0b,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.7,
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.05;
  group.add(ring);

  // Item centerpiece
  if (type === 'medkit') {
    const medGeo = new THREE.BoxGeometry(0.4, 0.25, 0.3);
    const medMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.3 }); // Green Medkit
    const med = new THREE.Mesh(medGeo, medMat);
    med.position.y = 0.4;
    group.add(med);

    // Red cross on medkit
    const cross1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.02, 0.2), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    cross1.position.set(0, 0.53, 0);
    const cross2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.02, 0.08), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    cross2.position.set(0, 0.53, 0);
    group.add(cross1, cross2);
  } else if (type === 'gloowall') {
    // Gloo wall grenade grenade item
    const grenadeMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      roughness: 0.2,
      metalness: 0.8,
      emissive: 0x0891b2,
      emissiveIntensity: 0.5,
    });
    const grenade = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 12), grenadeMat);
    grenade.position.y = 0.45;
    group.add(grenade);
  } else if (type === 'vest') {
    const vestMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5, metalness: 0.5 });
    const vest = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.4, 0.25), vestMat);
    vest.position.y = 0.45;
    group.add(vest);
  } else if (type === 'mushroom') {
    // Free Fire Mushroom for EP
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.3, 8), new THREE.MeshStandardMaterial({ color: 0xfef08a }));
    stem.position.y = 0.2;
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.2, 10), new THREE.MeshStandardMaterial({ color: 0xeab308, emissive: 0xca8a04, emissiveIntensity: 0.4 }));
    cap.position.y = 0.38;
    group.add(stem, cap);
  } else if (type.startsWith('ammo')) {
    // Ammo box
    const ammoMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.4, metalness: 0.4 });
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, 0.35), ammoMat);
    box.position.y = 0.25;
    group.add(box);
  } else {
    // Weapon pickup representation
    const wepType: WeaponType = type === 'weapon_ar' ? 'ar' : type === 'weapon_shotgun' ? 'shotgun' : 'sniper';
    const wep = createWeaponModel(wepType);
    wep.scale.set(0.65, 0.65, 0.65);
    wep.position.y = 0.4;
    group.add(wep);
  }

  return group;
}
