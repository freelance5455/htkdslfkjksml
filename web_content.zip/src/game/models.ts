import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

type C = number | 'T' | 'A' | 'B';
type Geos = { body?: THREE.BufferGeometry; team?: THREE.BufferGeometry; acc?: THREE.BufferGeometry; sec?: THREE.BufferGeometry };

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _p = new THREE.Vector3(), _s = new THREE.Vector3(1, 1, 1);

class MB {
  body: THREE.BufferGeometry[] = []; team: THREE.BufferGeometry[] = []; acc: THREE.BufferGeometry[] = []; sec: THREE.BufferGeometry[] = [];
  private add(g: THREE.BufferGeometry, x: number, y: number, z: number, c: C, rx = 0, ry = 0, rz = 0) {
    _e.set(rx, ry, rz); _q.setFromEuler(_e); _p.set(x, y, z); _m.compose(_p, _q, _s);
    g.applyMatrix4(_m); g.deleteAttribute('uv');
    if (typeof c === 'number') {
      const col = new THREE.Color(c); const n = g.attributes.position.count; const arr = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { arr[i * 3] = col.r; arr[i * 3 + 1] = col.g; arr[i * 3 + 2] = col.b; }
      g.setAttribute('color', new THREE.BufferAttribute(arr, 3)); this.body.push(g);
    } else (c === 'T' ? this.team : c === 'A' ? this.acc : this.sec).push(g);
  }
  box(w: number, h: number, d: number, x: number, y: number, z: number, c: C, rx = 0, ry = 0, rz = 0) { this.add(new THREE.BoxGeometry(w, h, d), x, y, z, c, rx, ry, rz); }
  cyl(rt: number, rb: number, h: number, x: number, y: number, z: number, c: C, seg = 8, rx = 0, ry = 0, rz = 0) { this.add(new THREE.CylinderGeometry(rt, rb, h, seg), x, y, z, c, rx, ry, rz); }
  cone(r: number, h: number, x: number, y: number, z: number, c: C, seg = 8) { this.add(new THREE.CylinderGeometry(0, r, h, seg), x, y, z, c); }
  sph(r: number, x: number, y: number, z: number, c: C, sy = 1, sx = 1, sz = 1) {
    const g = new THREE.SphereGeometry(r, 8, 6); g.scale(sx, sy, sz); this.add(g, x, y, z, c);
  }
}
class Model {
  main = new MB(); parts: Record<string, { pos: [number, number, number]; mb: MB }> = {};
  part(name: string, x: number, y: number, z: number) { const mb = new MB(); this.parts[name] = { pos: [x, y, z], mb }; return mb; }
}
const REG: Record<string, (m: Model) => void> = {};
const cache: Record<string, { main: Geos; parts: Record<string, { pos: [number, number, number]; geo: Geos }> }> = {};
const mrg = (a: THREE.BufferGeometry[]) => (a.length ? mergeGeometries(a, false) || undefined : undefined);
const geos = (mb: MB): Geos => ({ body: mrg(mb.body), team: mrg(mb.team), acc: mrg(mb.acc), sec: mrg(mb.sec) });

export interface Mats { body: THREE.Material; team: THREE.Material; acc: THREE.Material; sec: THREE.Material }
const matCache: Record<string, Mats> = {};
const bodyMat = new THREE.MeshLambertMaterial({ vertexColors: true });
export function getMats(team: number, a: number[], b: number[]): Mats {
  const k = team + '|' + a.join() + '|' + b.join();
  if (!matCache[k]) matCache[k] = {
    body: bodyMat,
    team: new THREE.MeshLambertMaterial({ color: team, emissive: team, emissiveIntensity: 0.25 }),
    acc: new THREE.MeshLambertMaterial({ color: new THREE.Color(a[0], a[1], a[2]) }),
    sec: new THREE.MeshLambertMaterial({ color: new THREE.Color(b[0], b[1], b[2]) }),
  };
  return matCache[k];
}
function attach(g: THREE.Object3D, geo: Geos, mats: Mats, shadow: boolean) {
  const add = (bg: THREE.BufferGeometry | undefined, mt: THREE.Material) => { if (bg) { const ms = new THREE.Mesh(bg, mt); ms.castShadow = shadow; g.add(ms); } };
  add(geo.body, mats.body); add(geo.team, mats.team); add(geo.acc, mats.acc); add(geo.sec, mats.sec);
}
export function makeModel(key: string, mats: Mats, shadow = false): THREE.Group {
  let d = cache[key];
  if (!d) {
    const m = new Model(); (REG[key] || REG.fallback)(m);
    const parts: Record<string, { pos: [number, number, number]; geo: Geos }> = {};
    for (const k in m.parts) parts[k] = { pos: m.parts[k].pos, geo: geos(m.parts[k].mb) };
    d = cache[key] = { main: geos(m.main), parts };
  }
  const g = new THREE.Group(); attach(g, d.main, mats, shadow);
  const parts: Record<string, THREE.Group> = {};
  for (const k in d.parts) { const pg = new THREE.Group(); pg.position.set(...d.parts[k].pos); attach(pg, d.parts[k].geo, mats, shadow); g.add(pg); parts[k] = pg; }
  g.userData.parts = parts; return g;
}

/* ---------- humans ---------- */
interface H { cloth: C; pants?: C; skin?: number; hat?: string; hatC?: C; w?: string; shield?: C; armor?: number; belt?: number; big?: number }
function human(m: Model, o: H) {
  const mb = m.main; const skin = o.skin ?? 0xd2a074; const pants = o.pants ?? 0x4b3f33; const k = o.big ?? 1;
  mb.box(0.72 * k, 0.95, 0.42 * k, 0, 1.5, 0, o.armor ?? o.cloth);
  mb.box(0.74 * k, 0.18, 0.44 * k, 0, 1.1, 0, o.belt ?? 0x3a2a1a);
  mb.box(0.5, 0.5, 0.18, 0, 1.55, -0.3 * k, 'T');
  mb.sph(0.27, 0, 2.25, 0, skin);
  const hc = o.hatC ?? 0x6a7060;
  if (o.hat === 'helm') mb.sph(0.31, 0, 2.31, 0, hc, 0.8);
  else if (o.hat === 'turban') mb.sph(0.33, 0, 2.34, 0, hc, 0.8);
  else if (o.hat === 'cap') { mb.cyl(0.3, 0.3, 0.1, 0, 2.43, 0, hc, 8); mb.box(0.5, 0.06, 0.18, 0, 2.45, 0.28, hc); }
  else if (o.hat === 'hard') { mb.sph(0.31, 0, 2.34, 0, hc, 0.7); mb.box(0.62, 0.06, 0.2, 0, 2.38, 0.28, hc); }
  else if (o.hat === 'beret') mb.cyl(0.33, 0.28, 0.1, 0.03, 2.47, 0, hc, 8);
  else if (o.hat === 'tall') { mb.sph(0.33, 0, 2.34, 0, hc, 0.85); mb.box(0.06, 0.4, 0.34, 0, 2.62, 0, 'T'); }
  const lg = (name: string, s: number) => { const l = m.part(name, s * 0.2, 1.05, 0); l.box(0.3 * k, 1.05, 0.32, 0, -0.52, 0, pants); l.box(0.32 * k, 0.16, 0.42, 0, -0.98, 0.05, 0x2a2018); };
  lg('legL', -1); lg('legR', 1);
  const sl = o.armor ?? o.cloth;
  const al = m.part('armL', -0.5 * k, 1.9, 0); al.box(0.2, 0.85, 0.2, 0, -0.4, 0, sl); al.box(0.2, 0.2, 0.2, 0, -0.85, 0, skin);
  const ar = m.part('armR', 0.5 * k, 1.9, 0); ar.box(0.2, 0.85, 0.2, 0, -0.4, 0, sl); ar.box(0.2, 0.2, 0.2, 0, -0.85, 0, skin);
  const w = o.w;
  if (w === 'sword') { ar.box(0.08, 0.95, 0.16, 0, -1.4, 0, 0xcfd3d8); ar.box(0.4, 0.08, 0.1, 0, -0.95, 0, 0x8a6a2a); }
  else if (w === 'pick') { ar.cyl(0.04, 0.04, 1.3, 0, -1.1, 0, 0x7a5a36, 5); ar.box(0.5, 0.09, 0.09, 0, -1.7, 0, 0x777b82); }
  else if (w === 'mace') { ar.cyl(0.05, 0.05, 1.0, 0, -1.2, 0, 0x6a4a2a, 5); ar.sph(0.2, 0, -1.8, 0, 0x777b82); }
  else if (w === 'spear') { mb.cyl(0.04, 0.04, 3.6, 0.58 * k, 1.9, 0.3, 0x7a5a36, 5); mb.cone(0.1, 0.45, 0.58 * k, 3.9, 0.3, 0xcfd3d8, 5); }
  else if (w === 'bow') { mb.box(0.06, 1.5, 0.08, -0.62 * k, 1.7, 0.4, 0x6b4a2a); mb.box(0.03, 1.4, 0.03, -0.62 * k, 1.7, 0.3, 0xeeeeee); mb.box(0.06, 0.4, 0.08, -0.62 * k, 2.4, 0.33, 0x6b4a2a, 0.6); mb.box(0.06, 0.4, 0.08, -0.62 * k, 1.0, 0.33, 0x6b4a2a, -0.6); }
  else if (w === 'rifle') { mb.box(0.1, 0.13, 1.15, 0.26 * k, 1.6, 0.5, 0x2a2a2a); mb.box(0.12, 0.25, 0.4, 0.26 * k, 1.5, 0.05, 0x5a4020); }
  else if (w === 'mg') { mb.box(0.12, 0.16, 1.3, 0.26 * k, 1.62, 0.6, 0x222222); mb.box(0.3, 0.2, 0.5, 0.26 * k, 1.58, 0.1, 0x333333); mb.box(0.04, 0.5, 0.04, 0.2, 1.3, 1.1, 0x222222, 0, 0, 0.4); mb.box(0.04, 0.5, 0.04, 0.34, 1.3, 1.1, 0x222222, 0, 0, -0.4); }
  else if (w === 'rpg') { mb.cyl(0.12, 0.12, 1.5, 0.36 * k, 2.05, 0.2, 0x4a5240, 8, PI2); mb.cone(0.2, 0.4, 0.36 * k, 2.05, 1.15, 'T', 6); }
  else if (w === 'stinger') { mb.cyl(0.14, 0.14, 1.7, 0.36 * k, 2.05, 0.3, 0x3d4a3a, 8, PI2); mb.box(0.22, 0.2, 0.2, 0.36 * k, 2.2, 0.2, 'T'); }
  else if (w === 'scope') { mb.box(0.1, 0.13, 1.2, 0.26 * k, 1.6, 0.5, 0x151515); mb.box(0.08, 0.1, 0.4, 0.26 * k, 1.75, 0.5, 0x222222); }
  if (o.shield !== undefined) { mb.box(0.12, 1.1, 0.85, -0.66 * k, 1.5, 0.22, o.shield); mb.sph(0.16, -0.74 * k, 1.5, 0.22, 'T'); }
}
const PI2 = Math.PI / 2;

REG.fallback = (m) => { m.main.box(1, 1, 1, 0, 0.5, 0, 'A'); };
REG.wk_a = (m) => human(m, { cloth: 0xe2d4ac, pants: 0xe2d4ac, hat: 'cap', hatC: 0xd8b860, w: 'pick', belt: 0x8a6a2a });
REG.spear = (m) => human(m, { cloth: 'A', pants: 0xcdbb90, hat: 'helm', hatC: 0xb08a3a, w: 'spear', shield: 'B' });
REG.archer = (m) => human(m, { cloth: 'A', pants: 0xcdbb90, hat: 'turban', hatC: 'B', w: 'bow' });
REG.sword = (m) => human(m, { cloth: 'A', pants: 0xcdbb90, hat: 'helm', hatC: 0xb08a3a, w: 'sword', shield: 'B' });
REG.heavy = (m) => human(m, { cloth: 'A', armor: 0x7d838c, pants: 0x3a3a3f, hat: 'tall', hatC: 0x8a9098, w: 'sword', shield: 'A', big: 1.25 });
REG.shield = (m) => human(m, { cloth: 'A', pants: 0x3a3a3f, hat: 'helm', hatC: 0x8a6a2a, w: 'mace', shield: 'B', big: 1.15 });
REG.wk_w = (m) => human(m, { cloth: 0x7a6a4a, pants: 0x5a5040, hat: 'hard', hatC: 0xe0b020, w: 'pick' });
REG.rifle = (m) => human(m, { cloth: 'A', pants: 0x5a5a48, hat: 'helm', hatC: 0x6a7060, w: 'rifle' });
REG.mg = (m) => human(m, { cloth: 'A', pants: 0x5a5a48, hat: 'helm', hatC: 0x6a7060, w: 'mg', big: 1.1 });
REG.at = (m) => human(m, { cloth: 'A', pants: 0x5a5a48, hat: 'helm', hatC: 0x6a7060, w: 'rpg' });
REG.cmdo = (m) => human(m, { cloth: 0x2b302b, pants: 0x202420, hat: 'beret', hatC: 'T', w: 'scope', skin: 0xb88a60 });
REG.wk_m = (m) => human(m, { cloth: 0xe08a1a, pants: 0x3a4250, hat: 'hard', hatC: 0xf2f2f2, w: 'pick' });
REG.minf = (m) => human(m, { cloth: 'A', pants: 'A', hat: 'helm', hatC: 'B', w: 'rifle' });
REG.mrpg = (m) => human(m, { cloth: 'A', pants: 'A', hat: 'helm', hatC: 'B', w: 'rpg' });
REG.maa = (m) => human(m, { cloth: 'A', pants: 'A', hat: 'helm', hatC: 'B', w: 'stinger' });

/* ---------- vehicles ---------- */
interface T { L: number; W: number; H: number; bl: number; hull: C; tur: C; ts?: number }
function tank(m: Model, o: T) {
  const mb = m.main; const trk = 0x2a2a2e;
  for (const s of [-1, 1]) {
    mb.box(0.7, o.H * 0.8, o.L + 0.4, s * (o.W / 2 + 0.2), o.H * 0.4 + 0.1, 0, trk);
    mb.cyl(o.H * 0.45, o.H * 0.45, 0.72, s * (o.W / 2 + 0.2), o.H * 0.45, o.L / 2 + 0.1, trk, 8, 0, 0, PI2);
    mb.cyl(o.H * 0.45, o.H * 0.45, 0.72, s * (o.W / 2 + 0.2), o.H * 0.45, -o.L / 2 - 0.1, trk, 8, 0, 0, PI2);
  }
  mb.box(o.W, o.H * 0.7, o.L, 0, o.H * 0.7 + 0.15, 0, o.hull);
  mb.box(o.W * 0.9, o.H * 0.3, o.L * 0.35, 0, o.H * 0.85 + 0.2, o.L * 0.4, o.hull, -0.35);
  mb.box(o.W * 0.5, 0.08, 0.6, 0, o.H * 1.05 + 0.2, -o.L * 0.3, 'T');
  const ts = o.ts ?? 1; const ty = o.H * 1.05 + 0.2;
  const t = m.part('turret', 0, ty, -o.L * 0.05);
  t.box(o.W * 0.72 * ts, o.H * 0.6, o.L * 0.5 * ts, 0, o.H * 0.3, 0, o.tur);
  t.cyl(o.H * 0.28, o.H * 0.28, 0.2, 0, o.H * 0.66, -0.2, 0x333338, 8);
  t.cyl(0.11, 0.13, o.bl, 0, o.H * 0.35, o.L * 0.25 * ts + o.bl / 2, 0x2d2f33, 6, PI2);
  t.cyl(0.18, 0.18, 0.4, 0, o.H * 0.35, o.L * 0.25 * ts + o.bl - 0.1, 0x222226, 6, PI2);
  t.box(o.W * 0.5, 0.08, 0.5, 0, o.H * 0.62, 0.15, 'T');
}
REG.ltank = (m) => tank(m, { L: 3.6, W: 2.0, H: 0.9, bl: 2.0, hull: 'A', tur: 'B', ts: 0.9 });
REG.mtank = (m) => tank(m, { L: 4.4, W: 2.4, H: 1.1, bl: 2.7, hull: 'A', tur: 'A' });
REG.htank = (m) => { tank(m, { L: 5.2, W: 2.9, H: 1.3, bl: 3.5, hull: 'A', tur: 'A', ts: 1.1 }); for (const s of [-1, 1]) m.main.box(0.12, 0.8, 4.6, s * 1.75, 0.95, 0, 'B'); };
REG.mbt = (m) => { tank(m, { L: 4.8, W: 2.5, H: 1.0, bl: 3.2, hull: 'A', tur: 'B', ts: 1 }); m.main.box(1.4, 0.2, 0.9, 0, 1.45, -1.5, 0x3a3f46); };
REG.art = (m) => {
  const mb = m.main; mb.box(2.4, 0.5, 2.2, 0, 0.55, 0, 'A'); mb.box(0.35, 0.35, 2.4, -0.7, 0.35, -1.9, 0x3a3a3a, 0, 0.3); mb.box(0.35, 0.35, 2.4, 0.7, 0.35, -1.9, 0x3a3a3a, 0, -0.3);
  for (const s of [-1, 1]) mb.cyl(0.7, 0.7, 0.3, s * 1.35, 0.7, 0, 0x2a2a2e, 10, 0, 0, PI2);
  const t = m.part('turret', 0, 1.0, 0); t.box(1.8, 0.9, 0.2, 0, 0.5, 0.7, 'B'); t.cyl(0.14, 0.18, 4, 0, 0.6, 2.2, 0x35383c, 6, PI2); t.cyl(0.24, 0.24, 0.6, 0, 0.6, 1.0, 0x2a2c30, 6, PI2); t.box(0.9, 0.5, 0.9, 0, 0.3, 0, 'A');
};
function wheels(m: Model, pts: [number, number, number][], r: number, w = 0.4) {
  pts.forEach((p, i) => { const g = m.part('whl' + i, p[0], p[1], p[2]); g.cyl(r, r, w, 0, 0, 0, 0x1c1c1f, 10, 0, 0, PI2); g.box(w + 0.02, r * 0.5, 0.12, 0, 0, 0, 0x777777); });
}
REG.mlrs = (m) => {
  const mb = m.main; mb.box(2.4, 0.7, 6, 0, 1.0, 0, 0x3a4048); mb.box(2.3, 1.3, 1.8, 0, 1.9, 2.0, 'A'); mb.box(2.0, 0.5, 0.1, 0, 2.2, 2.95, 0x7aa0c0);
  wheels(m, [[-1.35, 0.7, 2.2], [1.35, 0.7, 2.2], [-1.35, 0.7, -0.4], [1.35, 0.7, -0.4], [-1.35, 0.7, -2.2], [1.35, 0.7, -2.2]], 0.7, 0.5);
  const t = m.part('turret', 0, 1.5, -1.3); t.box(2.1, 0.3, 2.6, 0, 0, 0, 0x2a2e33);
  t.box(1.9, 1.3, 3.2, 0, 0.9, -0.2, 'B', -0.3); for (let i = 0; i < 6; i++) t.cyl(0.18, 0.18, 3.4, -0.7 + (i % 3) * 0.7, 0.8 + Math.floor(i / 3) * 0.55, 0.0, 0x20242a, 8, PI2 - 0.3);
  t.box(1.9, 0.12, 0.6, 0, 1.4, -1.0, 'T');
};
REG.tech = (m) => {
  const mb = m.main; mb.box(2.0, 0.6, 4.2, 0, 1.0, 0, 'A'); mb.box(1.9, 0.9, 1.5, 0, 1.7, 0.9, 'A'); mb.box(1.8, 0.45, 0.1, 0, 1.95, 1.66, 0x7aa0c0);
  mb.box(1.9, 0.2, 1.8, 0, 1.4, -1.2, 'B'); mb.box(2.0, 0.08, 1, 0, 1.45, -0.2, 'T');
  wheels(m, [[-1.1, 0.55, 1.4], [1.1, 0.55, 1.4], [-1.1, 0.55, -1.3], [1.1, 0.55, -1.3]], 0.55);
  const t = m.part('turret', 0, 1.55, -1.1); t.box(0.6, 0.5, 0.6, 0, 0.3, 0, 0x2a2a2e); t.box(0.14, 0.14, 1.5, 0, 0.5, 0.9, 0x1c1c1f); t.box(0.7, 0.45, 0.1, 0, 0.6, 0.35, 0x444a50);
};
REG.chariot = (m) => {
  const mb = m.main; mb.box(2.0, 0.25, 1.8, 0, 0.8, -0.6, 0x8a5a2a); mb.box(0.1, 0.8, 1.7, -1.0, 1.2, -0.6, 'A'); mb.box(0.1, 0.8, 1.7, 1.0, 1.2, -0.6, 'A'); mb.box(2.0, 0.8, 0.1, 0, 1.2, -1.5, 'A');
  mb.box(0.12, 0.12, 3.0, 0, 0.85, 1.2, 0x6a4a22); mb.box(0.4, 0.6, 0.25, 0, 1.45, -1.35, 'T');
  mb.box(0.5, 0.8, 0.4, 0, 1.6, -0.7, 'B'); mb.sph(0.24, 0, 2.2, -0.7, 0xd2a074); mb.sph(0.27, 0, 2.28, -0.7, 0xb08a3a, 0.7);
  wheels(m, [[-1.15, 0.7, -0.6], [1.15, 0.7, -0.6]], 0.7, 0.18);
  for (const s of [-0.55, 0.55]) { mb.box(0.55, 0.8, 1.8, s, 1.35, 2.4, 0x7a4a2a); mb.box(0.3, 0.9, 0.5, s, 1.9, 3.3, 0x7a4a2a, 0.5); mb.box(0.15, 0.5, 0.45, s, 2.45, 3.45, 'T'); for (const z of [1.7, 3.0]) mb.box(0.18, 1.0, 0.18, s + (s > 0 ? 0.15 : -0.15), 0.5, z, 0x5a3a1a); mb.box(0.5, 0.15, 0.4, s, 1.8, 2.3, 'A'); }
};
REG.hchar = (m) => {
  const mb = m.main; mb.box(2.6, 0.3, 2.4, 0, 0.85, -0.7, 0x5a4a3a); mb.box(0.14, 1.0, 2.3, -1.3, 1.4, -0.7, 'A'); mb.box(0.14, 1.0, 2.3, 1.3, 1.4, -0.7, 'A'); mb.box(2.6, 1.0, 0.14, 0, 1.4, -1.9, 'A');
  mb.box(0.14, 0.14, 3.2, 0, 0.9, 1.4, 0x3a2a18); mb.box(0.8, 0.9, 0.3, 0, 1.9, -1.5, 'T');
  mb.box(0.7, 1.0, 0.5, 0, 1.9, -0.6, 0x7d838c); mb.sph(0.28, 0, 2.65, -0.6, 0xd2a074); mb.sph(0.32, 0, 2.7, -0.6, 0x8a9098, 0.8);
  wheels(m, [[-1.5, 0.8, -0.7], [1.5, 0.8, -0.7]], 0.8, 0.22);
  for (const s of [-0.7, 0.7]) { mb.box(0.7, 0.95, 2.0, s, 1.45, 2.6, 0x35353a); mb.box(0.4, 1.0, 0.6, s, 2.0, 3.6, 0x35353a, 0.5); mb.box(0.8, 0.12, 2.0, s, 1.95, 2.6, 'B'); for (const z of [1.8, 3.3]) mb.box(0.2, 1.1, 0.2, s, 0.55, z, 0x3a3a3a); }
  mb.cone(0.2, 0.7, -1.5, 0.8, -0.7, 0x888888, 5);
};
REG.cat = (m) => {
  const mb = m.main; mb.box(2.2, 0.35, 4, 0, 0.85, 0, 0x7a5030); mb.box(0.3, 1.5, 0.3, -0.8, 1.6, 0, 0x6a4424); mb.box(0.3, 1.5, 0.3, 0.8, 1.6, 0, 0x6a4424); mb.box(2.1, 0.3, 0.3, 0, 2.3, 0, 0x6a4424);
  mb.box(0.8, 0.12, 0.6, 0, 1.07, -1.7, 'T'); mb.box(0.12, 0.8, 1.6, 0, 1.3, 1.2, 'A', 0.3);
  wheels(m, [[-1.25, 0.65, 1.2], [1.25, 0.65, 1.2], [-1.25, 0.65, -1.2], [1.25, 0.65, -1.2]], 0.65, 0.25);
  const a = m.part('cArm', 0, 2.3, 0); a.box(0.26, 0.26, 4.2, 0, 0, -1.0, 0x8a6038); a.box(0.9, 0.5, 0.9, 0, 0.25, 1.1, 'A'); a.sph(0.4, 0, 0.7, 1.1, 0x6a6a6a); a.box(0.5, 0.12, 0.5, 0, 0, -3, 'T');
};
REG.ram = (m) => {
  const mb = m.main; mb.box(2.6, 0.3, 4.6, 0, 0.8, 0, 0x6a4424); for (const s of [-1.2, 1.2]) for (const z of [-2, 2]) mb.box(0.2, 1.5, 0.2, s, 1.6, z, 0x5a3a1a);
  mb.box(2.8, 0.2, 5, 0, 2.5, 0, 'A', 0, 0, 0); mb.box(2.6, 0.6, 5, 0, 2.7, 0, 'B', 0, 0, 0.0); mb.box(2.4, 0.1, 2, 0, 3.05, 0, 'T');
  wheels(m, [[-1.4, 0.55, 1.6], [1.4, 0.55, 1.6], [-1.4, 0.55, -1.6], [1.4, 0.55, -1.6]], 0.55, 0.3);
  const l = m.part('ramLog', 0, 1.3, 0); l.cyl(0.38, 0.38, 5.2, 0, 0, 0.6, 0x5a3a1a, 8, PI2); l.cyl(0, 0.5, 0.9, 0, 0, 3.4, 0x555a60, 8, PI2);
};

/* ---------- aircraft ---------- */
REG.fighter = (m) => {
  const mb = m.main; mb.cyl(0.55, 0.3, 5.2, 0, 0, 0, 'A', 8, PI2); mb.cyl(0.4, 0.56, 1.2, 0, 0, 2.6, 'B', 8, PI2); mb.box(7.2, 0.14, 1.5, 0, -0.05, 0.3, 'A'); mb.box(2.8, 0.1, 0.8, 0, 0.05, -2.3, 'A'); mb.box(0.1, 1.1, 0.9, 0, 0.55, -2.3, 'A');
  mb.sph(0.4, 0, 0.45, 0.5, 0x8ec8e8, 0.8, 1, 1.8); mb.box(0.8, 0.05, 0.8, -2.6, 0.1, 0.3, 'T'); mb.box(0.8, 0.05, 0.8, 2.6, 0.1, 0.3, 'T'); mb.box(0.1, 0.4, 0.5, 0, 1.0, -2.3, 'T');
  const r = m.part('rotZ1', 0, 0, 3.3); r.box(0.18, 2.6, 0.05, 0, 0, 0, 0x222222); r.box(2.6, 0.18, 0.05, 0, 0, 0, 0x222222, 0, 0, 0.8);
};
REG.bomber = (m) => {
  const mb = m.main; mb.cyl(1.0, 0.45, 9, 0, 0, 0, 'A', 8, PI2); mb.sph(1.0, 0, 0, 4.6, 0x8ec8e8, 0.9, 1, 0.8); mb.box(14, 0.28, 2.4, 0, -0.2, 0.4, 'A'); mb.box(4.6, 0.18, 1.3, 0, 0.1, -4, 'A'); mb.box(0.15, 1.8, 1.4, 0, 0.9, -4, 'A');
  mb.box(1.2, 0.08, 1.2, -4.5, -0.04, 0.4, 'T'); mb.box(1.2, 0.08, 1.2, 4.5, -0.04, 0.4, 'T'); mb.box(0.15, 0.6, 0.9, 0, 1.6, -4, 'T');
  [[-5, 1], [-2.4, 2], [2.4, 3], [5, 4]].forEach(([x, i]) => { mb.cyl(0.35, 0.3, 2, x, -0.2, 1.6, 'B', 8, PI2); const r = m.part('rotZ' + i, x, -0.2, 2.7); r.box(0.14, 2.3, 0.05, 0, 0, 0, 0x222222); r.box(2.3, 0.14, 0.05, 0, 0, 0, 0x222222); });
};
REG.jet = (m) => {
  const mb = m.main; mb.cyl(0.5, 0.45, 6, 0, 0, -0.3, 'A', 8, PI2); mb.cone(0.5, 2.2, 0, 0, 3.8, 'B', 8); mb.box(0.1, 0.1, 0.1, 0, 0, 0, 'A');
  mb.box(5.4, 0.1, 2.8, 0, -0.1, -0.8, 'A', 0, 0, 0); mb.box(2.4, 0.1, 1.2, 0, 0, -2.6, 'A'); mb.box(0.1, 1.0, 1.2, -0.55, 0.6, -2.5, 'A', 0, 0, 0.3); mb.box(0.1, 1.0, 1.2, 0.55, 0.6, -2.5, 'A', 0, 0, -0.3);
  mb.sph(0.4, 0, 0.45, 0.9, 0x8ec8e8, 0.7, 1, 2); mb.cyl(0.3, 0.38, 0.5, -0.3, 0, -3.1, 0xff9030, 8, PI2); mb.cyl(0.3, 0.38, 0.5, 0.3, 0, -3.1, 0xff9030, 8, PI2);
  mb.box(0.7, 0.05, 0.7, -2, 0.0, -0.8, 'T'); mb.box(0.7, 0.05, 0.7, 2, 0.0, -0.8, 'T'); mb.cone(0.12, 0.8, -1.8, -0.35, 0.2, 0x555555, 5); mb.cone(0.12, 0.8, 1.8, -0.35, 0.2, 0x555555, 5);
};
REG.drone = (m) => {
  const mb = m.main; mb.sph(0.5, 0, 0, 0, 'A', 0.6, 1, 1.5); mb.cone(0.25, 0.8, 0, 0, 0.9, 'T', 6); mb.box(0.12, 0.12, 0.1, 0, 0, 0, 'B');
  [[-1, 1], [1, 1], [-1, -1], [1, -1]].forEach(([x, z], i) => { mb.box(1.2, 0.06, 0.08, x * 0.5, 0.15, z * 0.5, 0x222222, 0, -x * z * 0.78); const r = m.part('rotY' + i, x, 0.25, z); r.cyl(0.55, 0.55, 0.03, 0, 0, 0, 'B', 10); });
};
REG.heli = (m) => {
  const mb = m.main; mb.sph(1.0, 0, 0, 0.3, 'A', 0.8, 0.9, 1.8); mb.box(0.4, 0.4, 3.2, 0, 0.2, -3, 'A'); mb.box(0.12, 1.1, 0.8, 0, 0.7, -4.4, 'A'); mb.sph(0.7, 0, 0.2, 1.5, 0x8ec8e8, 0.6, 0.9, 1);
  mb.box(0.14, 0.14, 2.4, -0.9, -1.0, 0.2, 0x222222); mb.box(0.14, 0.14, 2.4, 0.9, -1.0, 0.2, 0x222222); mb.box(0.1, 0.9, 0.1, -0.8, -0.6, 0.8, 0x222222); mb.box(0.1, 0.9, 0.1, 0.8, -0.6, 0.8, 0x222222);
  mb.box(0.5, 0.15, 1.2, -1.2, -0.2, 0.5, 'B'); mb.box(0.5, 0.15, 1.2, 1.2, -0.2, 0.5, 'B'); mb.box(0.5, 0.25, 0.4, 0, 0.7, -0.3, 'T'); mb.box(0.1, 0.1, 1.0, 0, -0.5, 1.9, 0x222222);
  mb.cyl(0.12, 0.12, 0.4, 0, 1.0, 0, 0x333333, 6);
  const r = m.part('rotY1', 0, 1.25, 0); r.box(7.2, 0.05, 0.3, 0, 0, 0, 0x2a2a2a); r.box(0.3, 0.05, 7.2, 0, 0, 0, 0x2a2a2a);
  const t = m.part('rotX1', 0.2, 0.7, -4.5); t.box(0.04, 1.4, 0.2, 0, 0, 0, 0x2a2a2a); t.box(0.04, 0.2, 1.4, 0, 0, 0, 0x2a2a2a);
};

/* ---------- buildings ---------- */
const SAND = 0xd6bb82, STONE = 0xbfa56c, BRICK = 0xb98c5a, WOOD = 0x7a5a36, CONC = 0x9a9a92, DARK = 0x3a3a3f, GLASS = 0x7fa6c4;
function flag(mb: MB, x: number, z: number, h: number) { mb.cyl(0.07, 0.07, h, x, h / 2, z, 0x5a4a3a, 5); mb.box(0.06, 0.9, 1.3, x, h - 0.5, z + 0.7, 'T'); }
REG.b_anc_hq = (m) => {
  const mb = m.main; mb.box(8, 0.6, 8, 0, 0.3, 0, 0xc8ab70); mb.box(7, 0.6, 7, 0, 0.9, 0, 0xd2b67e); mb.box(5.8, 0.6, 5.8, 0, 1.5, 0, SAND);
  mb.box(4.4, 2.6, 4.4, 0, 3.1, 0, 0xe3c892); mb.box(5.2, 0.4, 5.2, 0, 4.6, 0, 'A'); mb.box(3.4, 0.5, 3.4, 0, 5.05, 0, STONE); mb.cone(1.0, 3.0, 0, 6.8, 0, 'B', 4);
  for (const x of [-2.6, 2.6]) for (const z of [-2.6, 2.6]) mb.cyl(0.32, 0.38, 3.4, x, 3.0, z, 0xf0e0b0, 8);
  mb.box(1.6, 1.8, 0.2, 0, 2.8, 2.3, 0x3a2a18); flag(mb, 3.4, 3.4, 5); flag(mb, -3.4, 3.4, 5);
};
REG.b_anc_rax = (m) => {
  const mb = m.main; mb.box(6, 0.4, 6, 0, 0.2, 0, 0xc8ab70); mb.box(5, 2.2, 5, 0, 1.5, 0, BRICK); mb.box(5.5, 0.35, 5.5, 0, 2.75, 0, WOOD); mb.box(5.7, 0.2, 5.7, 0, 3.0, 0, 'A');
  mb.box(1.3, 1.5, 0.15, 0, 1.15, 2.55, 0x3a2a18); for (const x of [-2.3, 2.3]) for (const z of [-2.3, 2.3]) mb.cyl(0.14, 0.14, 2.6, x, 1.7, z, WOOD, 5);
  flag(mb, 2.5, 2.5, 4.4); mb.cyl(0.05, 0.05, 2, -1.6, 1.3, 2.7, 0x7a5a36, 5, 0, 0, 0.25); mb.cyl(0.05, 0.05, 2, -1.2, 1.3, 2.7, 0x7a5a36, 5, 0, 0, 0.25); mb.sph(0.5, 1.8, 0.9, 2.8, 'B');
};
REG.b_anc_fac = (m) => {
  const mb = m.main; mb.box(7, 0.35, 7, 0, 0.18, 0, 0xc8ab70);
  for (const x of [-3.1, 3.1]) for (const z of [-3.1, 3.1]) mb.cyl(0.25, 0.25, 3.4, x, 1.9, z, WOOD, 6);
  mb.box(7.2, 0.3, 7.2, 0, 3.7, 0, 'A'); mb.box(6.4, 0.6, 6.4, 0, 4.1, 0, 'B', 0, 0, 0); mb.box(5, 0.5, 5, 0, 4.6, 0, 'T');
  mb.box(5.8, 0.15, 0.5, 0, 0.9, -3.0, 0x5a3a1a); mb.cyl(0.7, 0.7, 0.2, -2, 1.1, -1.5, 0x5a3a1a, 10, 0, 0, PI2); mb.cyl(0.7, 0.7, 0.2, 0, 1.1, -1.5, 0x5a3a1a, 10, 0, 0, PI2); mb.box(1.2, 0.8, 0.8, 2.3, 0.8, -1.2, 0x555a60);
};
REG.b_anc_tow = (m) => {
  const mb = m.main; mb.cyl(1.35, 1.7, 5, 0, 2.5, 0, 0xc8ab70, 10); mb.cyl(1.9, 1.5, 0.9, 0, 5.4, 0, 'A', 10); for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; mb.box(0.5, 0.6, 0.5, Math.cos(a) * 1.7, 6.1, Math.sin(a) * 1.7, STONE); }
  mb.box(0.4, 0.9, 0.15, 0, 3, 1.5, 0x2a2018); flag(mb, 0, 0, 8.2);
  const t = m.part('turret', 0, 5.9, 0); t.box(0.2, 0.2, 1.2, 0, 0, 1.2, WOOD);
};
const hut = (m: Model, r: number, len: number, col: C) => { m.main.cyl(r, r, len, 0, 0, 0, col, 12, PI2); };
REG.b_ww2_hq = (m) => {
  const mb = m.main; mb.box(8, 3.2, 7, 0, 1.6, 0, CONC); mb.box(8.1, 0.5, 7.1, 0, 2.3, 0, 'A'); mb.box(5.4, 1.8, 4.2, 0, 4.1, 0, 0x8c8c84); mb.box(8.4, 0.3, 7.4, 0, 3.3, 0, 0x6e6e68); mb.box(5.8, 0.25, 4.6, 0, 5.1, 0, 0x6e6e68);
  mb.box(1.6, 2, 0.2, 0, 1.2, 3.55, DARK); for (const x of [-2.6, -1.3, 1.3, 2.6]) mb.box(0.8, 0.8, 0.15, x, 2.0, 3.55, 0x6a8090);
  for (const x of [-3, -1.6, 1.6, 3]) mb.box(1.1, 0.6, 0.7, x, 0.3, 4.1, 0xa89a70);
  mb.cyl(0.1, 0.1, 3.5, -2, 6.9, -1, 0x333333, 5); mb.box(1.4, 0.06, 0.8, -2, 8.6, -1, 0x444444, 0.3); flag(mb, 3, 2.5, 7.6); mb.box(0.8, 0.6, 0.6, 2, 5.5, -1, 'B');
};
REG.b_ww2_rax = (m) => {
  const mb = m.main; hut(m, 2.7, 6.2, 'A'); mb.box(5.4, 0.2, 6.3, 0, 0.1, 0, 0x5a5a4a); mb.box(0.7, 0.12, 6.0, 0, 2.7, 0, 'T');
  mb.box(1.6, 1.8, 0.15, 0, 0.9, 3.1, DARK); mb.cyl(0.8, 0.8, 0.8, -1.3, 0.4, 3.5, 0x8a7a50, 8); mb.cyl(0.8, 0.8, 0.8, 1.3, 0.4, 3.5, 0x8a7a50, 8); flag(mb, 3, 3, 5);
  for (let i = -2; i <= 2; i++) mb.box(0.06, 5.4, 0.2, 0, 0, i * 1.3, 0x4a4a3a, 0, 0, 0);
};
REG.b_ww2_fac = (m) => {
  const mb = m.main; mb.box(7, 3, 6.4, 0, 1.5, 0, CONC); mb.box(7.1, 0.5, 6.5, 0, 2.2, 0, 'A');
  for (let i = -2; i <= 2; i++) { mb.box(1.1, 1.1, 6.5, i * 1.4, 3.5, 0, 0x6e6e68, 0, 0, 0); mb.box(0.1, 0.9, 6.4, i * 1.4 + 0.55, 4.1, 0, 0x6a8090, 0, 0, 0.0); }
  mb.cyl(0.5, 0.6, 5, -2.8, 4.5, -2.5, 0x555550, 8); mb.box(4, 2.4, 0.2, 0, 1.2, 3.25, DARK); mb.box(3.4, 0.5, 0.15, 0, 3.0, 3.3, 'T'); mb.box(1, 0.7, 1, 3, 0.4, 3.6, 0x777b82);
  mb.cyl(0.6, 0.6, 0.25, 2.4, 0.4, -3.8, 0x4a4a42, 8, PI2);
};
REG.b_ww2_air = (m) => {
  const mb = m.main; hut(m, 3.9, 8, 'A'); mb.box(7.8, 0.2, 8.1, 0, 0.1, 0, 0x5a5a4a); mb.box(6.4, 3.4, 0.2, 0, 1.7, 4.0, DARK); mb.box(0.8, 0.14, 7.5, 0, 3.9, 0, 'T');
  mb.box(5, 0.08, 16, 0, 0.05, 11.5, 0x3a3a3c); for (let i = 0; i < 6; i++) mb.box(0.3, 0.1, 1.4, 0, 0.1, 5 + i * 2.4, 0xe8e8e0);
  mb.box(1.4, 3.2, 1.4, 5, 1.6, 2, CONC); mb.box(1.8, 0.9, 1.8, 5, 3.6, 2, 0x6a8090); flag(mb, -4.5, 4, 6);
};
REG.b_ww2_tow = (m) => {
  const mb = m.main; mb.cyl(1.7, 2.0, 1.4, 0, 0.7, 0, CONC, 10); mb.cyl(1.4, 1.7, 0.6, 0, 1.7, 0, 'A', 10);
  for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; mb.box(0.8, 0.5, 0.5, Math.cos(a) * 2.2, 0.25, Math.sin(a) * 2.2, 0xa89a70, 0, -a); }
  mb.box(0.5, 0.1, 0.5, 1.0, 2.1, 0, 'T'); const t = m.part('turret', 0, 2.2, 0); t.sph(0.9, 0, 0, 0, 'B', 0.7); t.box(0.2, 0.2, 1.6, -0.2, 0.15, 1.1, 0x222222); t.box(0.2, 0.2, 1.6, 0.2, 0.15, 1.1, 0x222222);
};
REG.b_mod_hq = (m) => {
  const mb = m.main; mb.box(8, 1.2, 8, 0, 0.6, 0, 0x6a7078); mb.box(4.4, 7, 4.4, 0, 4.7, 0, GLASS); mb.box(4.6, 0.5, 4.6, 0, 2, 0, 'A'); mb.box(4.6, 0.5, 4.6, 0, 5, 0, 'A'); mb.box(4.7, 0.4, 4.7, 0, 8.4, 0, 0x555b63);
  mb.box(3.4, 1.8, 3.4, -1.8, 2.1, 2.5, 0x8d939b); mb.cyl(1.5, 1.5, 0.15, 2.4, 1.3, -2.4, 0x444a50, 12); mb.box(1.2, 0.05, 0.2, 2.4, 1.4, -2.4, 0xffffff); mb.box(0.2, 0.05, 1.2, 2.4, 1.4, -2.4, 0xffffff);
  mb.cyl(0.08, 0.08, 4, 1, 10.6, 1, 0x333333, 5); mb.sph(0.7, -1, 9.2, -1, 0xdddddd, 0.5); mb.cyl(0.07, 0.07, 3, 1.7, 9.9, -1.7, 0x5a4a3a, 5); mb.box(0.06, 0.9, 1.3, 1.7, 10.9, -1.0, 'T');
  mb.box(1.8, 1.8, 0.2, 0, 1.9, 4.1, 0x2a3a4a);
};
REG.b_mod_rax = (m) => {
  const mb = m.main; mb.box(6, 0.4, 6, 0, 0.2, 0, 0x6a7078); mb.box(5.2, 2.4, 3.2, 0, 1.6, -0.8, 0x7b8a6a); mb.box(5.4, 0.3, 3.4, 0, 2.95, -0.8, 'A'); mb.box(3.2, 2.0, 2.2, -0.8, 1.4, 1.8, 0x8d939b); mb.box(3.4, 0.25, 2.4, -0.8, 2.5, 1.8, 'B');
  for (const x of [-1.8, -0.6, 0.6, 1.8]) mb.box(0.7, 0.6, 0.12, x, 1.9, 0.84, GLASS); mb.box(1.2, 1.6, 0.1, 1.5, 1.2, 2.9, DARK); mb.cyl(0.9, 0.9, 0.2, 2, 3.4, -1.5, 0xdddddd, 10, 0.5); flag(mb, 2.6, 2.6, 5);
  mb.box(0.8, 0.8, 0.9, -2.5, 0.8, 2.8, 0x5a6a4a);
};
REG.b_mod_fac = (m) => {
  const mb = m.main; mb.box(7, 3.4, 6.4, 0, 1.7, 0, 0x848a92); mb.box(7.1, 0.5, 6.5, 0, 2.2, 0, 'A'); mb.box(7.3, 0.3, 6.7, 0, 3.55, 0, 0x555b63);
  for (let i = -2; i <= 2; i++) mb.box(0.8, 0.5, 1.4, i * 1.3, 3.9, -1.5, 0x666c74);
  mb.box(4.4, 2.6, 0.2, 0, 1.3, 3.25, DARK); mb.box(3.6, 0.5, 0.15, 0, 3.0, 3.3, 'T'); mb.cyl(0.4, 0.4, 3, 3, 4.5, 2, 0x6a7078, 8); mb.cyl(0.4, 0.4, 3, 2, 4.5, 2, 0x6a7078, 8);
  mb.box(1.4, 1.2, 1.4, -3.9, 0.7, 2.8, 0x6a7078); mb.box(1.4, 1.2, 1.4, -3.9, 0.7, -2.8, 'B');
};
REG.b_mod_air = (m) => {
  const mb = m.main; mb.cyl(3.9, 3.9, 8, 0, 0, 0, 0x8d939b, 14, PI2); mb.cyl(3.95, 3.95, 0.5, 0, 0, 3.6, 'A', 14, PI2); mb.box(7.8, 0.2, 8.1, 0, 0.1, 0, 0x5a6068); mb.box(6.2, 3.4, 0.2, 0, 1.7, 4.0, DARK); mb.box(0.8, 0.14, 7.5, 0, 3.9, 0, 'T');
  mb.box(5, 0.08, 16, 0, 0.05, 11.5, 0x35373a); for (let i = 0; i < 6; i++) mb.box(0.3, 0.1, 1.4, 0, 0.1, 5 + i * 2.4, 0xe8e8e0);
  mb.cyl(0.4, 0.5, 4, 5, 2, -2, 0x6a7078, 8); const r = m.part('rotY1', 5, 4.3, -2); r.box(2.6, 0.9, 0.12, 0, 0.4, 0, 0xdddddd); r.box(0.2, 0.2, 0.5, 0, 0, 0.3, 0x333333); flag(mb, -4.5, 4, 6);
};
REG.b_mod_tow = (m) => {
  const mb = m.main; mb.cyl(1.3, 1.7, 1.2, 0, 0.6, 0, 0x6a7078, 10); mb.cyl(0.9, 1.1, 1.6, 0, 1.9, 0, 'A', 10); mb.box(0.5, 0.1, 0.5, 1.0, 2.5, 0, 'T');
  const t = m.part('turret', 0, 3.1, 0); t.box(1.6, 0.6, 1.6, 0, 0, 0, 'B'); t.box(0.5, 0.5, 1.7, -0.5, 0.5, 0.5, 0x333840, -0.2); t.box(0.5, 0.5, 1.7, 0.5, 0.5, 0.5, 0x333840, -0.2); t.cone(0.1, 0.4, -0.5, 0.65, 1.4, 'T', 5); t.cone(0.1, 0.4, 0.5, 0.65, 1.4, 'T', 5);
};
REG.mine = (m) => {
  const mb = m.main; mb.sph(2.0, 0, 0.5, 0, 0x5a5348, 0.6); mb.sph(1.3, 1.3, 0.3, 0.9, 0x6a6358, 0.7); mb.sph(1.1, -1.3, 0.3, -0.7, 0x4a4338, 0.7);
  for (const [x, y, z, s] of [[0, 1.5, 0.2, 1.0], [1.0, 1.0, 1.4, 0.8], [-1.2, 0.9, 1.0, 0.8], [0.5, 1.1, -1.3, 0.7], [-0.6, 1.3, -0.5, 0.7]]) mb.box(s, s, s, x, y, z, 0xffd21e, 0.4, 0.7, 0.3);
};
export const ALL_MODELS = () => Object.keys(REG);
