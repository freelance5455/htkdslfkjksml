import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { AfterimagePass } from 'three/examples/jsm/postprocessing/AfterimagePass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { buildMap, type MapData, type TargetSpec } from './maps';
import { Input, touchState } from './input';
import { audio } from './audio';
import { Particles, Tracers, Decals, flashTexture } from './effects';
import { Bot, type Actor, type AIContext, type Noise } from './ai';
import { buildWeaponModel, buildSoldier, stdMat, type WeaponModel } from './models';
import { raySphere, rayCylinder, type World } from './world';
import { store, type Loadout, type MatchResult, isTouchDevice } from './save';
import {
  WEAPONS, getWeapon, computeStats, sanitizeAttachments, randomLootAttachments, RARITY_HEX, RARITY_NAMES,
  type WeaponDef, type FinalStats, type AttachConfig, type Rarity,
} from './data/weapons';
import { getDifficulty, getOperator, type ModeId, type MapId, type Difficulty, type DifficultyDef } from './data/content';

export interface GameOptions { mode: ModeId; map: MapId; difficulty: Difficulty; loadout: Loadout; operator: string; brZone: boolean }
export interface WeaponInst { def: WeaponDef; stats: FinalStats; attachments: AttachConfig; skin: string; rarity: Rarity; mag: number; reserve: number; vm: WeaponModel | null }
interface Loot { id: number; kind: 'weapon' | 'ammo' | 'armor' | 'medkit'; pos: THREE.Vector3; mesh: THREE.Object3D; taken: boolean; weapon?: WeaponInst; rarity: Rarity; spin: number }
interface Crate { pos: THREE.Vector3; mesh: THREE.Group; lid: THREE.Object3D; opened: boolean; openT: number }
interface RangeTarget { spec: TargetSpec; pos: THREE.Vector3; health: number; maxHealth: number; downT: number; group: THREE.Group; dir: number; plate: boolean; fall: number }
interface FloatText { x: number; y: number; z: number; text: string; color: string; t: number; big: boolean }
interface KillFeedEntry { id: number; killer: string; victim: string; weapon: string; head: boolean; kTeam: number; vTeam: number; t: number }

export interface HudState {
  mode: ModeId; health: number; maxHealth: number; armor: number; plates: number; medkits: number; alive: boolean; respawnIn: number;
  weapon: { name: string; category: string; mag: number; magSize: number; reserve: number; rarity: number; mode: string } | null;
  slots: ({ name: string; rarity: number } | null)[]; active: number; reload: number; useProgress: number; useLabel: string;
  score: number; multiplier: number; kills: number; timeText: string; enemiesLeft: number; wave: number; maxWave: number;
  teamScore: [number, number]; scoreLimit: number; killfeed: KillFeedEntry[]; prompt: string | null;
  banner: { text: string; sub: string; id: number } | null; zone: { text: string; outside: boolean } | null; objective: string;
  range: { hits: number; misses: number; acc: number; time: number; targets: number } | null; fps: number; streakText: string | null; paused: boolean;
}
export interface GameCallbacks { onEnd: (r: MatchResult) => void; onPause: (p: boolean) => void }

const PLAYER_R = 0.35, STAND_H = 1.75, CROUCH_H = 1.15;
const TEAM_COLORS = [
  { uniform: 0x3a4a5a, vest: 0x24303c, skin: 0xc49a78, helmet: 0x2c3a48, accent: 0x3aa0ff },
  { uniform: 0x5a3a32, vest: 0x3a2622, skin: 0xb88a68, helmet: 0x4a2c26, accent: 0xff4a3a },
];
const BOT_NAMES = ['Kestrel', 'Bishop', 'Mako', 'Raven', 'Jackal', 'Onyx', 'Drift', 'Saber', 'Wolfe', 'Cipher', 'Talon', 'Grim', 'Hex', 'Rook', 'Blitz', 'Vandal', 'Nova', 'Sledge', 'Ash', 'Fang', 'Lynx', 'Vex', 'Brute', 'Hawk'];
const BOT_WEAPONS = WEAPONS.filter(w => ['AR', 'SMG', 'LMG', 'MR', 'SG'].includes(w.category));
const v1 = new THREE.Vector3(), v2 = new THREE.Vector3(), v3 = new THREE.Vector3();

export class Game {
  // core
  container: HTMLElement; hudCanvas: HTMLCanvasElement; hud: CanvasRenderingContext2D;
  renderer: THREE.WebGLRenderer; scene = new THREE.Scene(); camera: THREE.PerspectiveCamera;
  vmScene = new THREE.Scene(); vmCamera = new THREE.PerspectiveCamera(58, 1, 0.01, 10); vmRoot = new THREE.Group();
  composer: EffectComposer | null = null; sun!: THREE.DirectionalLight; dome: THREE.Object3D | null = null;
  map: MapData; world: World; input: Input; opts: GameOptions; cb: GameCallbacks; diff: DifficultyDef;
  private raf = 0; private last = 0; private lastRender = 0; private disposed = false;
  baseDpr = 1; curScale = 1; private perfAcc = 0; private perfFrames = 0; private perfGood = 0; fps = 60;
  touch: boolean;
  // player
  pos = new THREE.Vector3(); vel = new THREE.Vector3(); yaw = 0; pitch = 0; ground = { onGround: true };
  crouched = false; crouchK = 0; slideT = 0; slideDir = new THREE.Vector3(); sprinting = false; parachute = false;
  health = 100; maxHealth = 100; armor = 0; plates = 0; medkits = 0; alive = true; lastHurt = -10; respawnAt = 0; deathT = 0;
  useT = 0; useKind: 'heal' | 'plate' | null = null;
  player: Actor;
  // weapons
  weapons: (WeaponInst | null)[] = [null, null]; active = 0; switchT = 0; reloadT = 0; reloadDur = 0; reloadStage = 0;
  nextFire = 0; burstQueue = 0; adsT = 0; adsToggle = false; bloom = 0; recoilRecover = 0; vmKick = 0; inspectT = 0; landDip = 0;
  shake = 0; stepAcc = 0; bobPhase = 0; swayX = 0; swayY = 0; flashT = 0; muzzleFlash: THREE.Mesh; muzzleLight: THREE.PointLight;
  arms: THREE.Group; autoReloadT = -1;
  // world entities
  bots: Bot[] = []; targets: RangeTarget[] = []; loot: Loot[] = []; crates: Crate[] = []; noises: Noise[] = [];
  particles: Particles; sparks: Particles; tracers: Tracers; decals: Decals;
  zoneMesh: THREE.Mesh | null = null; zone = { x: 0, z: 0, r: 9999, fromR: 9999, toR: 9999, fromX: 0, fromZ: 0, toX: 0, toZ: 0, phase: 0, t: 0, shrinking: false, enabled: false };
  // match
  time = 0; matchTime = 0; phase: 'playing' | 'ending' | 'ended' = 'playing'; endT = 0; paused = false;
  score = 0; kills = 0; deaths = 0; headshots = 0; shots = 0; hits = 0; streak = 0; multiplier = 1; lastKillT = -10; multiKill = 0;
  wave = 0; waveTime = 0; maxWave = 5; waveRemaining = 0; waveSpawnQueue = 0; intermission = 0; teamScore: [number, number] = [0, 0]; scoreLimit = 30; timeLimit = 0;
  crateCount = 0; rangeTargets = 0; longestShot = 0; weaponsWithKills = new Set<string>(); placement = 0;
  killfeed: KillFeedEntry[] = []; banner: HudState['banner'] = null; bannerT = 0; prompt: string | null = null; streakText: string | null = null; streakT = 0;
  floats: FloatText[] = []; hitmarkT = 0; hitmarkKill = false; hitmarkHead = false; dmgIndicators: { angle: number; t: number }[] = []; hurtFlash = 0;
  private lootId = 1; private feedId = 1; private bannerId = 1; private maxBots = 12;
  private budget = { paths: 2, cover: 1 };
  private aiCtx!: AIContext;
  private settingsUnsub: () => void;

  constructor(container: HTMLElement, hudCanvas: HTMLCanvasElement, opts: GameOptions, cb: GameCallbacks) {
    this.container = container; this.hudCanvas = hudCanvas; this.hud = hudCanvas.getContext('2d')!; this.opts = opts; this.cb = cb;
    this.diff = getDifficulty(opts.difficulty);
    this.touch = store.settings.controls.touchMode === 'on' || (store.settings.controls.touchMode === 'auto' && isTouchDevice());
    const g = store.settings.graphics;
    this.renderer = new THREE.WebGLRenderer({ antialias: g.antialias, powerPreference: 'high-performance', stencil: false });
    this.baseDpr = Math.min(window.devicePixelRatio || 1, 2) * g.renderScale; this.curScale = 1;
    this.renderer.setPixelRatio(this.baseDpr);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace; this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = g.shadows > 0; this.renderer.shadowMap.type = g.shadows >= 2 ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    this.renderer.autoClear = false;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;touch-action:none;';
    this.camera = new THREE.PerspectiveCamera(g.fov, 1, 0.05, g.viewDistance + 60);
    this.camera.rotation.order = 'YXZ';

    // map
    this.map = buildMap(opts.map, { textures: g.textures, shadows: g.shadows > 0, lowMat: g.preset === 'low' || g.textures === 0 });
    this.world = this.map.world;
    this.scene.add(this.map.group);
    this.dome = this.map.group.children.find(c => c.renderOrder === -10) ?? null;
    const sky = this.map.sky;
    this.scene.fog = new THREE.Fog(sky.fog, g.viewDistance * 0.35, g.viewDistance);
    this.scene.background = new THREE.Color(sky.fog);
    const hemi = new THREE.HemisphereLight(sky.amb, 0x6a5a48, sky.ambI); this.scene.add(hemi);
    this.sun = new THREE.DirectionalLight(sky.sun, sky.sunI); this.scene.add(this.sun); this.scene.add(this.sun.target);
    if (g.shadows > 0) {
      this.sun.castShadow = true; const sz = [0, 1024, 2048, 4096][g.shadows]; this.sun.shadow.mapSize.set(sz, sz);
      const ext = g.shadows === 3 ? 60 : 42; const sc = this.sun.shadow.camera; sc.left = -ext; sc.right = ext; sc.top = ext; sc.bottom = -ext; sc.near = 1; sc.far = 220;
      this.sun.shadow.bias = -0.0006; this.sun.shadow.normalBias = 0.03;
    }
    // effects (scaled by effects quality)
    const fx = g.effects;
    this.particles = new Particles([150, 400, 900][fx]); this.scene.add(this.particles.points);
    this.sparks = new Particles([80, 200, 400][fx], true); this.scene.add(this.sparks.points);
    this.tracers = new Tracers(this.scene, [8, 20, 32][fx]);
    this.decals = new Decals(this.scene, [30, 90, 200][fx]);
    this.muzzleLight = new THREE.PointLight(0xffb060, 0, 9, 2); this.scene.add(this.muzzleLight);

    // viewmodel scene
    this.vmScene.add(new THREE.HemisphereLight(0xffffff, 0x404040, 1.6));
    const vmSun = new THREE.DirectionalLight(sky.sun, 1.6); vmSun.position.set(0.5, 1, 0.3); this.vmScene.add(vmSun);
    this.vmScene.add(this.vmRoot);
    const ftex = flashTexture();
    const fm = new THREE.MeshBasicMaterial({ map: ftex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const fg = new THREE.PlaneGeometry(0.28, 0.28);
    this.muzzleFlash = new THREE.Mesh(fg, fm); const f2 = new THREE.Mesh(fg, fm); f2.rotation.y = Math.PI / 2; this.muzzleFlash.add(f2);
    const f3 = new THREE.Mesh(fg, fm); f3.rotation.x = Math.PI / 2; f3.scale.setScalar(0.6); this.muzzleFlash.add(f3);
    this.muzzleFlash.visible = false;
    const op = getOperator(opts.operator);
    this.arms = this.buildArms(op.uniform, op.accent);
    this.vmRoot.add(this.arms);

    if (g.motionBlur) {
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      const after = new AfterimagePass(0.55); this.composer.addPass(after);
      const vmPass = new RenderPass(this.vmScene, this.vmCamera); vmPass.clear = false; vmPass.clearDepth = true; this.composer.addPass(vmPass);
      this.composer.addPass(new OutputPass());
    }

    // player actor
    this.player = { id: 1, team: 0, name: store.profile.name || 'YOU', pos: this.pos, vel: this.vel, height: STAND_H, alive: true, health: 100, maxHealth: 100, armor: 0, isPlayer: true, lastFiredAt: -10, crouching: false, kills: 0 };
    this.input = new Input(this.renderer.domElement);
    this.input.onLockChange = locked => { if (!locked && !this.touch && this.phase === 'playing' && !this.paused) this.setPaused(true); };

    this.aiCtx = {
      world: this.world, time: 0, actors: [], diff: this.diff, mode: opts.mode, patrol: this.map.patrol, noises: this.noises, zone: null,
      botFire: (b, ox, oy, oz, dx, dy, dz) => this.botFire(b, ox, oy, oz, dx, dy, dz), budget: this.budget,
      onFootstep: b => { if (b.pos.distanceTo(this.pos) < 30) audio.footstep(0, { x: b.pos.x, y: b.pos.y, z: b.pos.z }, 0.9); },
    };
    const preset = g.preset === 'custom' ? 'medium' : g.preset;
    this.maxBots = { low: 8, medium: 12, high: 16, ultra: 20 }[preset];
    this.setupMode();
    this.onResize();
    window.addEventListener('resize', this.onResize);
    this.settingsUnsub = store.subscribe(() => this.applyLiveSettings());
    audio.startAmbient(opts.map === 'dust' ? 'wind' : opts.map === 'iron' ? 'city' : 'range');
    audio.stopMusic();
    audio.stinger('start');
    try { this.renderer.compile(this.scene, this.camera); } catch { /* optional warmup */ }
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  // ------------------------------------------------------------ setup
  private buildArms(uniform: number, accent: number) {
    const g = new THREE.Group(); const sleeve = stdMat(uniform, 0.9, 0), glove = stdMat(0x1c1c1c, 0.8, 0.1), band = stdMat(accent, 0.5, 0.2, 0.3);
    const r = new THREE.Group(); const rs = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.09, 0.42), sleeve); rs.position.set(0, -0.02, 0.24); r.add(rs);
    const rg = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.08, 0.1), glove); rg.position.set(0, -0.04, 0.02); r.add(rg);
    const rb = new THREE.Mesh(new THREE.BoxGeometry(0.095, 0.095, 0.03), band); rb.position.set(0, -0.02, 0.1); r.add(rb);
    r.name = 'R'; g.add(r);
    const l = new THREE.Group(); const ls = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.09, 0.45), sleeve); ls.position.set(-0.06, -0.03, 0.25); ls.rotation.y = 0.35; l.add(ls);
    const lg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.11), glove); lg.position.set(0, -0.03, 0); l.add(lg);
    l.name = 'L'; g.add(l);
    return g;
  }

  makeWeapon(def: WeaponDef, att: AttachConfig = {}, skin = 'default', rarity: Rarity = 0): WeaponInst {
    const clean = sanitizeAttachments(def, att);
    const stats = computeStats(def, clean, rarity * 0.025);
    return { def, stats, attachments: clean, skin, rarity, mag: stats.mag, reserve: stats.reserve, vm: null };
  }

  private setupMode() {
    const o = this.opts; const lo = o.loadout;
    const prim = this.makeWeapon(getWeapon(lo.primary.weapon), lo.primary.attachments, lo.primary.skin);
    const sec = this.makeWeapon(getWeapon(lo.secondary.weapon), lo.secondary.attachments, lo.secondary.skin);
    this.pos.copy(this.map.playerStart); this.yaw = Math.PI;
    if (o.mode === 'range') {
      this.weapons = [prim, sec];
      for (const t of this.map.targets) this.spawnTarget(t);
      this.showBanner('PRACTICE RANGE', 'Open the armory with [B] or the ARMORY button');
      this.yaw = 0;
    } else if (o.mode === 'combat') {
      this.weapons = [prim, sec];
      this.maxBots = Math.min(this.maxBots, 10);
      this.intermission = 1.2; this.wave = 0;
      this.spawnAmmoCaches(10);
    } else if (o.mode === 'tdm') {
      this.weapons = [prim, sec];
      const per = Math.max(4, Math.min(6, Math.floor(this.maxBots / 2) + 0));
      this.scoreLimit = per >= 6 ? 30 : 25; this.timeLimit = 360;
      const s0 = this.map.teamSpawns[0]; this.pos.copy(s0[0]);
      this.yaw = Math.atan2(-(this.map.teamSpawns[1][0].x - this.pos.x), -(this.map.teamSpawns[1][0].z - this.pos.z));
      for (let i = 0; i < per - 1; i++) this.addBot(0, s0[(i + 1) % s0.length]);
      for (let i = 0; i < per; i++) this.addBot(1, this.map.teamSpawns[1][i % this.map.teamSpawns[1].length]);
      this.showBanner('TEAM DEATHMATCH', `First to ${this.scoreLimit} eliminations`);
      this.spawnAmmoCaches(8);
    } else if (o.mode === 'br') {
      this.weapons = [null, this.makeWeapon(getWeapon('p01'))]; this.active = 1;
      this.maxHealth = 100; this.health = 100;
      const n = { 8: 9, 12: 13, 16: 17, 20: 21 }[this.maxBots] ?? 11;
      const spots = this.randomWalkableSpots(n + 1, 30);
      this.pos.copy(spots[0]); this.pos.y += 70; this.parachute = true; this.ground.onGround = false;
      for (let i = 1; i <= n; i++) { const b = this.addBot(i, spots[i] ?? spots[0]); b.weapon = BOT_WEAPONS[Math.floor(Math.random() * 6)]; b.mag = b.weapon.mag; }
      this.spawnLoot();
      this.zone.enabled = o.brZone;
      if (this.zone.enabled) {
        const b = this.world.bounds; const size = b.maxX - b.minX;
        this.zone.x = this.zone.toX = this.zone.fromX = (Math.random() - 0.5) * size * 0.25; this.zone.z = this.zone.toZ = this.zone.fromZ = (Math.random() - 0.5) * size * 0.25;
        this.zone.r = this.zone.fromR = this.zone.toR = size * 0.75; this.zone.phase = 0; this.zone.t = 30; this.zone.shrinking = false;
        const zg = new THREE.CylinderGeometry(1, 1, 160, 64, 1, true);
        this.zoneMesh = new THREE.Mesh(zg, new THREE.MeshBasicMaterial({ color: 0x3aa0ff, transparent: true, opacity: 0.18, side: THREE.DoubleSide, depthWrite: false, fog: false }));
        this.zoneMesh.position.y = 40; this.scene.add(this.zoneMesh);
      }
      this.showBanner('BATTLE ROYALE', 'Steer your descent with WASD / joystick. Loot up and survive.');
    }
    for (const w of this.weapons) if (w) w.vm = null;
    this.equip(this.weapons[this.active] ? this.active : (this.weapons[0] ? 0 : 1), true);
  }

  private randomWalkableSpots(n: number, minSep: number) {
    const out: THREE.Vector3[] = []; const b = this.world.bounds;
    for (let i = 0; i < n * 40 && out.length < n; i++) {
      const x = b.minX + 8 + Math.random() * (b.maxX - b.minX - 16), z = b.minZ + 8 + Math.random() * (b.maxZ - b.minZ - 16);
      if (!this.world.walkable(x, z)) continue;
      if (out.some(p => Math.hypot(p.x - x, p.z - z) < minSep)) continue;
      out.push(new THREE.Vector3(x, this.world.ground(x, z), z));
    }
    while (out.length < n) out.push(this.map.spawns[out.length % this.map.spawns.length].clone());
    return out;
  }

  private addBot(team: number, at: THREE.Vector3) {
    const name = BOT_NAMES[this.bots.length % BOT_NAMES.length] + (this.bots.length >= BOT_NAMES.length ? '-2' : '');
    const colors = this.opts.mode === 'br' ? (team % 2 ? TEAM_COLORS[1] : { ...TEAM_COLORS[1], uniform: 0x4a4a3a, accent: 0xffa030 }) : TEAM_COLORS[team === 0 ? 0 : 1];
    const w = BOT_WEAPONS[Math.floor(Math.random() * BOT_WEAPONS.length)];
    const b = new Bot(team, name, w, colors, this.scene, this.diff.health);
    b.spawn(at.clone().add(v1.set((Math.random() - 0.5) * 2, 0, (Math.random() - 0.5) * 2)));
    const p = this.world.nearestWalkable(b.pos.x, b.pos.z); b.pos.set(p.x, this.world.ground(p.x, p.z), p.z);
    this.bots.push(b);
    return b;
  }

  private spawnTarget(spec: TargetSpec) {
    const g = new THREE.Group(); const plate = spec.kind === 'static';
    if (plate) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.4, 0.08), stdMat(0x333333)); post.position.y = 0.7; g.add(post);
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.06, 24), stdMat(0xd04030));
      disc.rotation.x = Math.PI / 2; disc.position.y = 1.55; g.add(disc);
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.07, 20), stdMat(0xf0ead8)); ring.rotation.x = Math.PI / 2; ring.position.y = 1.55; g.add(ring);
      const bull = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.08, 16), stdMat(0xd04030)); bull.rotation.x = Math.PI / 2; bull.position.y = 1.55; g.add(bull);
    } else {
      const s = buildSoldier({ uniform: 0xc8b890, vest: 0xa89870, skin: 0xd8c8a0, helmet: 0xb0a080, accent: 0xff6020 });
      s.gun.visible = false; s.armL.rotation.set(0, 0, 0.2); s.armR.rotation.set(0, 0, -0.2); g.add(s.root);
      const base = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.1, 0.6), stdMat(0x333333)); g.add(base);
    }
    g.position.set(spec.x, 0, spec.z); g.traverse(o => { o.castShadow = true; });
    this.scene.add(g);
    this.targets.push({ spec, pos: g.position, health: plate ? 100 : 150, maxHealth: plate ? 100 : 150, downT: 0, group: g, dir: 1, plate, fall: 0 });
  }

  private lootMesh(kind: Loot['kind'], rarity: Rarity, w?: WeaponInst) {
    const g = new THREE.Group();
    if (kind === 'weapon' && w) { const m = buildWeaponModel(w.def, w.attachments, w.skin).group; m.scale.setScalar(1.5); m.rotation.y = Math.PI / 2; m.position.y = 0.45; g.add(m); }
    else if (kind === 'ammo') { const b = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.28, 0.3), stdMat(0x4a5a30, 0.7, 0.2)); b.position.y = 0.2; g.add(b); const s = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.06, 0.31), stdMat(0xd0b040, 0.5, 0.4)); s.position.y = 0.28; g.add(s); }
    else if (kind === 'armor') { const b = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.08), stdMat(0x2a6ab0, 0.4, 0.5, 0.2)); b.position.y = 0.4; g.add(b); }
    else { const b = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.28, 0.3), stdMat(0xe8e8e8, 0.6, 0)); b.position.y = 0.2; g.add(b); const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.31), stdMat(0xd02020, 0.5, 0, 0.5)); c1.position.y = 0.2; g.add(c1); const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.06, 0.31), stdMat(0xd02020, 0.5, 0, 0.5)); c2.position.y = 0.2; g.add(c2); }
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.2, 6), new THREE.MeshBasicMaterial({ color: RARITY_HEX[rarity], transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false }));
    beam.position.y = 1.1; g.add(beam);
    return g;
  }

  addLoot(kind: Loot['kind'], pos: THREE.Vector3, rarity: Rarity = 0, w?: WeaponInst) {
    const mesh = this.lootMesh(kind, rarity, w); mesh.position.copy(pos); this.scene.add(mesh);
    const l: Loot = { id: this.lootId++, kind, pos: mesh.position, mesh, taken: false, weapon: w, rarity, spin: Math.random() * 6 };
    this.loot.push(l); return l;
  }
  private randomRarity(): Rarity { const r = Math.random(); return (r < 0.4 ? 0 : r < 0.68 ? 1 : r < 0.86 ? 2 : r < 0.96 ? 3 : 4) as Rarity; }
  private randomLootWeapon(): WeaponInst {
    const def = WEAPONS[Math.floor(Math.random() * WEAPONS.length)]; const rarity = this.randomRarity();
    const w = this.makeWeapon(def, randomLootAttachments(def, rarity), 'default', rarity); w.reserve = w.stats.mag * 2; return w;
  }
  private spawnLoot() {
    const spots = [...this.map.lootSpots, ...this.randomWalkableSpots(30, 6)];
    for (const s of spots) {
      const r = Math.random(); const p = s.clone();
      if (r < 0.42) { const w = this.randomLootWeapon(); this.addLoot('weapon', p, w.rarity, w); }
      else if (r < 0.65) this.addLoot('ammo', p);
      else if (r < 0.83) this.addLoot('armor', p, 2);
      else this.addLoot('medkit', p, 1);
    }
    for (const c of this.map.crateSpots) this.addCrate(c);
  }
  private spawnAmmoCaches(n: number) {
    const spots = this.randomWalkableSpots(n, 15);
    for (const s of spots) this.addLoot('ammo', s);
    for (const c of this.map.crateSpots.slice(0, 6)) this.addCrate(c);
  }
  private addCrate(p: THREE.Vector3) {
    const g = new THREE.Group(); const body = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.6, 0.7), stdMat(0x3a4a2a, 0.7, 0.3)); body.position.y = 0.3; g.add(body);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.08, 0.72), stdMat(0xe0b030, 0.4, 0.3, 0.6)); stripe.position.y = 0.45; g.add(stripe);
    const lid = new THREE.Group(); lid.position.set(0, 0.6, 0.35); const lm = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.1, 0.7), stdMat(0x2e3c22, 0.7, 0.3)); lm.position.z = -0.35; lid.add(lm); g.add(lid);
    const fixed = this.world.nearestWalkable(p.x, p.z);
    g.position.set(fixed.x, p.y > 0.5 ? p.y : this.world.ground(fixed.x, fixed.z), fixed.z); g.traverse(o => { o.castShadow = true; }); this.scene.add(g);
    this.crates.push({ pos: g.position, mesh: g, lid, opened: false, openT: 0 });
  }

  // ------------------------------------------------------------ settings / lifecycle
  private applyLiveSettings() {
    const g = store.settings.graphics;
    this.camera.far = g.viewDistance + 60; this.camera.updateProjectionMatrix();
    if (this.scene.fog instanceof THREE.Fog) { this.scene.fog.near = g.viewDistance * 0.35; this.scene.fog.far = g.viewDistance; }
    const newBase = Math.min(window.devicePixelRatio || 1, 2) * g.renderScale;
    if (Math.abs(newBase - this.baseDpr) > 0.01) { this.baseDpr = newBase; this.curScale = 1; this.renderer.setPixelRatio(this.baseDpr); this.onResize(); }
  }
  onResize = () => {
    const w = this.container.clientWidth || window.innerWidth, h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); this.vmCamera.aspect = w / h; this.vmCamera.updateProjectionMatrix();
    this.composer?.setSize(w, h); this.composer?.setPixelRatio(this.baseDpr * this.curScale);
    const d = Math.min(window.devicePixelRatio || 1, 2); this.hudCanvas.width = w * d; this.hudCanvas.height = h * d; this.hudCanvas.style.width = w + 'px'; this.hudCanvas.style.height = h + 'px';
  };
  setPaused(p: boolean) {
    if (this.phase === 'ended' || this.paused === p) return;
    this.paused = p; this.input.releaseAll(); audio.suspendGame(p); this.cb.onPause(p);
    if (p && document.pointerLockElement) document.exitPointerLock();
    if (!p && !this.touch) this.input.requestLock();
  }
  requestLock() { if (!this.touch && !this.paused && this.phase === 'playing') this.input.requestLock(); }

  dispose() {
    if (this.disposed) return; this.disposed = true;
    cancelAnimationFrame(this.raf); window.removeEventListener('resize', this.onResize); this.settingsUnsub();
    this.input.dispose(); audio.stopAmbient(); touchState.reset();
    for (const b of this.bots) b.dispose(this.scene);
    this.particles.dispose(); this.sparks.dispose(); this.tracers.dispose(); this.decals.dispose();
    this.map.dispose();
    this.scene.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh && m.geometry && !m.geometry.userData.shared) { /* cached geometries stay in model cache */ } });
    this.composer?.dispose();
    this.renderer.dispose(); this.renderer.forceContextLoss(); this.renderer.domElement.remove();
  }

  // ------------------------------------------------------------ main loop
  private frame = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    const lim = store.settings.graphics.fpsLimit;
    if (lim > 0 && now - this.lastRender < 1000 / lim - 1.5) return;
    this.lastRender = now;
    const dt = Math.min(0.05, Math.max(0.0001, (now - this.last) / 1000)); this.last = now;
    this.perf(dt);
    try {
      if (!this.paused && this.phase !== 'ended') this.update(dt);
      this.render(dt);
      this.drawHud(dt);
    } catch (e) { console.error('Frame error', e); }
    this.input.endFrame();
  };

  private perf(dt: number) {
    this.perfAcc += dt; this.perfFrames++;
    if (this.perfAcc >= 1) {
      this.fps = Math.round(this.perfFrames / this.perfAcc); this.perfAcc = 0; this.perfFrames = 0;
      if (store.settings.graphics.dynamicRes && !this.paused) {
        if (this.fps < 45 && this.curScale > 0.55) { this.curScale = Math.max(0.55, this.curScale - 0.1); this.renderer.setPixelRatio(this.baseDpr * this.curScale); this.onResize(); this.perfGood = 0; }
        else if (this.fps >= 58) { this.perfGood++; if (this.perfGood > 4 && this.curScale < 1) { this.curScale = Math.min(1, this.curScale + 0.1); this.renderer.setPixelRatio(this.baseDpr * this.curScale); this.onResize(); this.perfGood = 0; } }
      }
    }
  }

  private update(dt: number) {
    this.time += dt; this.matchTime += dt; this.aiCtx.time = this.time;
    this.budget.paths = 2; this.budget.cover = 1;
    // noises older than 1s are dropped
    while (this.noises.length && this.time - this.noises[0].time > 1) this.noises.shift();
    if (this.input.pressed('inspect') && this.reloadT <= 0 && this.switchT <= 0) this.inspectT = 2.2;
    if (touchState.pressed.has('pause')) this.setPaused(true);

    this.updatePlayer(dt);
    this.updateWeapon(dt);
    this.updateMode(dt);
    // bots
    this.aiCtx.actors.length = 0; this.aiCtx.actors.push(this.player); for (const b of this.bots) this.aiCtx.actors.push(b);
    this.aiCtx.zone = this.zone.enabled ? { x: this.zone.toX, z: this.zone.toZ, r: this.zone.shrinking ? this.zone.toR : this.zone.r } : null;
    for (const b of this.bots) b.update(dt, this.aiCtx);
    this.updateTargets(dt);
    this.updateLoot(dt);
    this.particles.update(dt); this.sparks.update(dt); this.tracers.update(dt);
    this.map.animate(this.time);
    // timers
    this.bannerT -= dt; if (this.bannerT <= 0) this.banner = null;
    this.streakT -= dt; if (this.streakT <= 0) this.streakText = null;
    this.killfeed = this.killfeed.filter(k => this.time - k.t < 6);
    if (this.phase === 'ending') { this.endT -= dt; if (this.endT <= 0) this.finish(); }
  }

  // ------------------------------------------------------------ player
  private updatePlayer(dt: number) {
    const c = store.settings.controls; const inp = this.input;
    if (!this.alive) {
      this.deathT += dt;
      if (this.opts.mode === 'tdm' && this.time >= this.respawnAt) this.respawnPlayer();
      return;
    }
    // look
    const w = this.weapons[this.active];
    const zoom = w ? 1 + (w.stats.zoom - 1) * this.adsT : 1;
    const sens = c.sensitivity * 0.0022 * (this.adsT > 0.5 ? c.adsSensitivity / Math.sqrt(zoom) : 1);
    const inv = c.invertY ? -1 : 1;
    this.yaw -= inp.dx * sens; this.pitch -= inp.dy * sens * inv;
    const ts = c.touchSensitivity * 0.0045 * (this.adsT > 0.5 ? c.adsSensitivity / Math.sqrt(zoom) : 1);
    this.yaw -= touchState.lookDX * ts; this.pitch -= touchState.lookDY * ts * inv;
    this.swayX += inp.dx * 0.0006 + touchState.lookDX * 0.001; this.swayY += inp.dy * 0.0006 + touchState.lookDY * 0.001;
    this.pitch = Math.max(-1.52, Math.min(1.52, this.pitch));
    // recoil recovery
    if (this.recoilRecover > 0) { const r = Math.min(this.recoilRecover, dt * 6 * Math.max(0.02, this.recoilRecover)); this.pitch -= r * 0.6; this.recoilRecover -= r; }

    // move input
    let mx = 0, mz = 0;
    if (inp.down('forward')) mz -= 1; if (inp.down('back')) mz += 1; if (inp.down('left')) mx -= 1; if (inp.down('right')) mx += 1;
    mx += touchState.moveX; mz += touchState.moveY;
    const ml = Math.hypot(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
    const touchSprint = touchState.moveY < -0.92 && Math.hypot(touchState.moveX, touchState.moveY) > 0.95;
    const wantSprint = (inp.down('sprint') || touchSprint) && mz < -0.3 && this.adsT < 0.3 && !this.useKind;
    if (inp.pressed('crouch')) {
      if (this.sprinting && this.ground.onGround && this.slideT <= 0) { this.slideT = 0.8; this.slideDir.set(this.vel.x, 0, this.vel.z).normalize(); this.crouched = true; this.shake += 0.15; audio.land(2); }
      else this.crouched = !this.crouched;
    }
    if (this.crouched && !this.canStand()) this.crouched = true;
    this.sprinting = wantSprint && !this.crouched && this.ground.onGround ? true : (this.sprinting && wantSprint && !this.ground.onGround);
    if (inp.pressed('jump')) {
      if (this.crouched && this.canStand()) { this.crouched = false; }
      else if (this.ground.onGround && !this.parachute) { this.vel.y = 7.4; this.ground.onGround = false; audio.jump(); this.slideT = 0; this.vmKick += 0.4; }
    }
    const stat = w?.stats.move ?? 1;
    let speed = (this.sprinting ? 7.2 : 4.7) * stat;
    if (this.crouched) speed = 2.4; if (this.adsT > 0.3) speed *= 0.6; if (this.useKind) speed *= 0.5;
    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const wx = mx * cos + mz * sin, wz = -mx * sin + mz * cos;
    if (this.parachute) {
      this.vel.x = THREE.MathUtils.lerp(this.vel.x, wx * 14, Math.min(1, dt * 2)); this.vel.z = THREE.MathUtils.lerp(this.vel.z, wz * 14, Math.min(1, dt * 2));
      this.vel.y = Math.max(this.vel.y, -11); if (this.vel.y < -11) this.vel.y = -11;
    } else if (this.slideT > 0) {
      this.slideT -= dt; const s = 4 + this.slideT * 9; this.vel.x = this.slideDir.x * s; this.vel.z = this.slideDir.z * s;
      if (this.slideT <= 0) this.sprinting = false;
    } else {
      const accel = this.ground.onGround ? 14 : 2.5;
      this.vel.x = THREE.MathUtils.lerp(this.vel.x, wx * speed, Math.min(1, dt * accel)); this.vel.z = THREE.MathUtils.lerp(this.vel.z, wz * speed, Math.min(1, dt * accel));
    }
    this.crouchK = THREE.MathUtils.lerp(this.crouchK, this.crouched ? 1 : 0, Math.min(1, dt * 12));
    const h = STAND_H + (CROUCH_H - STAND_H) * this.crouchK;
    const preY = this.vel.y;
    if (this.parachute) this.vel.y += 24 * dt * 0.92; // counteract most of gravity
    const landed = this.world.moveCharacter(this.pos, this.vel, PLAYER_R, h, dt, this.ground);
    if (this.parachute && this.ground.onGround) { this.parachute = false; this.landDip = 0.25; audio.land(4); this.shake += 0.3; }
    else if (landed > 5) {
      this.landDip = Math.min(0.3, landed * 0.02); audio.land(landed); this.shake += landed * 0.02;
      if (landed > 15 && this.opts.mode !== 'range') this.damagePlayer((landed - 15) * 7, null, null);
    }
    void preY;
    this.player.height = h; this.player.crouching = this.crouched;
    // footsteps
    const hs = Math.hypot(this.vel.x, this.vel.z);
    if (this.ground.onGround && hs > 1) {
      this.bobPhase += hs * dt * 1.6; this.stepAcc += hs * dt;
      const stride = this.sprinting ? 2.6 : 2.1;
      if (this.stepAcc > stride) {
        this.stepAcc = 0; if (!this.crouched) { audio.footstep(this.opts.map === 'dust' ? 1 : 0, undefined, this.sprinting ? 1 : 0.6); this.addNoise(this.sprinting ? 16 : 8); }
      }
    }
    // anti-stuck / out-of-world safety
    if (this.pos.y < -15 || !isFinite(this.pos.x)) { this.pos.copy(this.map.playerStart); this.vel.set(0, 0, 0); }
    // health regen (not BR)
    if (this.opts.mode !== 'br' && this.time - this.lastHurt > 4 && this.health < this.maxHealth) this.health = Math.min(this.maxHealth, this.health + 30 * dt);
    // BR consumables
    if (this.useKind) {
      this.useT -= dt;
      if (this.sprinting || this.reloadT > 0) { this.useKind = null; }
      else if (this.useT <= 0) {
        if (this.useKind === 'heal' && this.medkits > 0) { this.medkits--; this.health = this.maxHealth; audio.heal(); this.addFloatSelf('+HEALTH', '#4ade80'); }
        if (this.useKind === 'plate' && this.plates > 0 && this.armor < 150) { this.plates--; this.armor = Math.min(150, this.armor + 50); audio.plate(); this.addFloatSelf('+ARMOR', '#38bdf8'); }
        this.useKind = null;
      }
    } else {
      if (inp.pressed('heal')) { if (this.medkits > 0 && this.health < this.maxHealth) { this.useKind = 'heal'; this.useT = 2.2; } else audio.deny(); }
      if (inp.pressed('plate')) { if (this.plates > 0 && this.armor < 150) { this.useKind = 'plate'; this.useT = 1.1; } else audio.deny(); }
    }
    this.player.health = this.health; this.player.armor = this.armor;
  }

  private canStand() { return this.world.ceilingAt(this.pos.x, this.pos.z, PLAYER_R * 0.7, this.pos.y + CROUCH_H) > this.pos.y + STAND_H + 0.02; }
  private addNoise(radius: number) { this.noises.push({ x: this.pos.x, y: this.pos.y, z: this.pos.z, radius, time: this.time, team: 0 }); }

  private respawnPlayer() {
    const spawns = this.map.teamSpawns[0];
    let best = spawns[0]; let bestD = -1;
    for (const s of spawns) { let md = Infinity; for (const b of this.bots) if (b.alive && b.team !== 0) md = Math.min(md, b.pos.distanceTo(s)); if (md > bestD) { bestD = md; best = s; } }
    this.pos.copy(best); this.vel.set(0, 0, 0); this.alive = true; this.player.alive = true; this.health = this.maxHealth; this.armor = 0;
    this.deathT = 0; this.crouched = false; this.reloadT = 0;
    for (const w of this.weapons) if (w) { w.mag = w.stats.mag; w.reserve = Math.max(w.reserve, w.stats.reserve); }
    this.equip(0, true);
  }

  // ------------------------------------------------------------ weapons
  equip(slot: number, instant = false) {
    const w = this.weapons[slot]; if (!w) return;
    if (slot === this.active && !instant && this.vmRoot.children.includes(w.vm?.group as THREE.Object3D)) return;
    this.reloadT = 0; this.burstQueue = 0; this.inspectT = 0;
    const prev = this.weapons[this.active];
    if (prev?.vm) this.vmRoot.remove(prev.vm.group);
    this.active = slot;
    if (!w.vm) w.vm = buildWeaponModel(w.def, w.attachments, w.skin);
    w.vm.group.traverse(o => { o.castShadow = false; });
    this.vmRoot.add(w.vm.group);
    this.muzzleFlash.removeFromParent(); w.vm.muzzle.add(this.muzzleFlash);
    const L = this.arms.getObjectByName('L')!; L.position.set(-0.02, -0.06, -Math.min(0.45, w.vm.length * 0.55));
    this.switchT = instant ? 0.25 : 0.45;
    this.nextFire = Math.min(this.nextFire, this.time + this.switchT); // cooldown doesn't carry across weapons
    this.adsToggle = false;
  }

  private updateWeapon(dt: number) {
    const inp = this.input; const w = this.weapons[this.active];
    this.flashT -= dt; this.muzzleFlash.visible = this.flashT > 0; this.muzzleLight.intensity = this.flashT > 0 ? 30 : 0;
    this.vmKick *= Math.exp(-dt * 14); this.bloom = Math.max(0, this.bloom - dt * 6); this.shake *= Math.exp(-dt * 9);
    this.landDip *= Math.exp(-dt * 7); this.inspectT = Math.max(0, this.inspectT - dt); this.swayX *= Math.exp(-dt * 8); this.swayY *= Math.exp(-dt * 8);
    if (!this.alive) return;
    // switching
    if (inp.pressed('slot1') && this.weapons[0] && this.active !== 0) this.equip(0);
    if (inp.pressed('slot2') && this.weapons[1] && this.active !== 1) this.equip(1);
    if ((inp.pressed('melee') || inp.wheel !== 0 || touchState.pressed.has('swap')) && this.weapons[1 - this.active]) this.equip(1 - this.active);
    if (this.switchT > 0) { this.switchT -= dt; }
    if (!w) return;
    // ADS
    const tog = store.settings.controls.toggleAds;
    if (tog && inp.adsPressed) this.adsToggle = !this.adsToggle;
    const adsWant = (tog ? this.adsToggle : inp.ads) && !this.sprinting && this.switchT <= 0 && this.alive && !this.parachute;
    this.adsT = THREE.MathUtils.clamp(this.adsT + (adsWant ? 1 : -1) * dt / Math.max(0.08, w.stats.adsTime), 0, 1);
    // reload
    if (this.reloadT > 0) {
      this.reloadT -= dt; const p = 1 - this.reloadT / this.reloadDur;
      if (this.reloadStage === 0 && p > 0.15) { audio.reload(0); this.reloadStage = 1; }
      if (this.reloadStage === 1 && p > 0.55) { audio.reload(1); this.reloadStage = 2; }
      if (this.reloadStage === 2 && p > 0.85) { audio.reload(2); this.reloadStage = 3; }
      if (this.reloadT <= 0) this.finishReload(w);
    }
    if (inp.pressed('reload')) this.startReload(w);
    if (this.autoReloadT > 0) { this.autoReloadT -= dt; if (this.autoReloadT <= 0) { this.autoReloadT = -1; this.startReload(w); } }
    if (this.opts.mode === 'range') w.reserve = Math.max(w.reserve, w.stats.mag * 3);

    // firing
    const ready = this.switchT <= 0 && this.reloadT <= 0 && !this.useKind && !this.parachute;
    const s = w.stats;
    const fireHeld = inp.fire, firePressed = inp.firePressed;
    if ((fireHeld || firePressed) && this.sprinting) { this.sprinting = false; }
    if (firePressed && w.mag <= 0 && this.reloadT <= 0) { audio.click(); if (w.reserve > 0) this.startReload(w); }
    const interval = 60 / s.rpm;
    if (ready && w.mag > 0 && this.time >= this.nextFire) {
      let shoot = false;
      if (s.mode === 'auto') shoot = fireHeld;
      else if (s.mode === 'semi' || s.mode === 'bolt') shoot = firePressed || (this.touch && fireHeld && s.mode === 'semi');
      else if (s.mode === 'burst') { if (firePressed && this.burstQueue <= 0) this.burstQueue = 3; shoot = this.burstQueue > 0; }
      if (shoot) {
        this.shoot(w);
        if (s.mode === 'burst') { this.burstQueue--; this.nextFire = this.time + (this.burstQueue > 0 ? interval : 0.32); }
        else this.nextFire = this.time + interval;
      }
    }
    if (w.mag <= 0) this.burstQueue = 0;
  }

  private startReload(w: WeaponInst) {
    if (this.reloadT > 0 || w.mag >= w.stats.mag || w.reserve <= 0 || this.switchT > 0) return;
    this.reloadDur = w.stats.reload * (w.mag === 0 ? 1.15 : 1); this.reloadT = this.reloadDur; this.reloadStage = 0; this.inspectT = 0; this.burstQueue = 0;
  }
  /** Ammo transfer: never negative, never duplicated */
  private finishReload(w: WeaponInst) {
    const need = Math.max(0, w.stats.mag - w.mag); const take = Math.min(need, Math.max(0, w.reserve));
    w.mag += take; w.reserve -= take; this.reloadT = 0;
  }

  private shoot(w: WeaponInst) {
    const s = w.stats; w.mag = Math.max(0, w.mag - 1); this.shots++; this.player.lastFiredAt = s.suppressed ? this.player.lastFiredAt : this.time;
    this.inspectT = 0;
    const hs = Math.hypot(this.vel.x, this.vel.z);
    let spread = THREE.MathUtils.lerp(s.spreadHip, s.spreadAds, this.adsT) + hs * 0.22 * (1 - this.adsT * 0.8) + (this.ground.onGround ? 0 : 2.5) + this.bloom * (1 - this.adsT * 0.6);
    if (this.crouched) spread *= 0.8;
    if (s.mode === 'bolt' && this.adsT > 0.95 && w.def.category === 'SR') spread = s.spreadAds;
    const camPos = this.camera.getWorldPosition(v1).clone();
    const fwd = this.camera.getWorldDirection(v2).clone();
    const right = v3.crossVectors(fwd, this.camera.up).normalize().clone(); const up = new THREE.Vector3().crossVectors(right, fwd);
    const muzzleWorld = this.muzzleWorld();
    let anyHit = false;
    for (let p = 0; p < s.pellets; p++) {
      const a = Math.random() * Math.PI * 2, r = Math.tan(THREE.MathUtils.degToRad(spread)) * Math.sqrt(Math.random());
      const dir = fwd.clone().addScaledVector(right, Math.cos(a) * r).addScaledVector(up, Math.sin(a) * r).normalize();
      const hit = this.trace(camPos, dir, 400, this.player);
      const end = camPos.clone().addScaledVector(dir, hit ? hit.t : 400);
      if (p === 0 || s.pellets <= 3 || p % 3 === 0) this.tracers.fire(muzzleWorld, end);
      if (!hit) continue;
      if (hit.bot || hit.target) {
        anyHit = true;
        const falloff = hit.t <= s.range ? 1 : Math.max(s.minDmg, 1 - (hit.t - s.range) / (s.range * 1.5) * (1 - s.minDmg));
        const dmg = s.damage * falloff * (hit.head ? s.headMult : 1);
        this.longestShot = Math.max(this.longestShot, hit.t);
        if (hit.bot) this.damageBot(hit.bot, dmg, this.player, hit.head, w.def, end);
        else if (hit.target) this.damageTarget(hit.target, dmg, hit.head, end);
      } else {
        const n = new THREE.Vector3(hit.nx, hit.ny, hit.nz);
        this.decals.add(end, n);
        const dust: [number, number, number] = this.opts.map === 'dust' ? [0.75, 0.62, 0.45] : [0.6, 0.6, 0.58];
        this.particles.burst(end, n, store.settings.graphics.effects > 0 ? 6 : 3, 2.5, 0.6, 0.25, dust, 0.8, 3, 2);
        if (hit.metal) this.sparks.burst(end, n, 6, 6, 0.25, 0.06, [1, 0.8, 0.4], 1, 12);
        if (p === 0 && Math.random() < 0.5) audio.impact({ x: end.x, y: end.y, z: end.z }, !!hit.metal);
      }
    }
    if (anyHit) this.hits++;
    // feedback: recoil, kick, shake, flash, audio
    const adsK = 1 - this.adsT * 0.25;
    const kickV = THREE.MathUtils.degToRad(s.recoilV * adsK * (0.85 + Math.random() * 0.3));
    this.pitch += kickV; this.recoilRecover += kickV * 0.9;
    this.yaw += THREE.MathUtils.degToRad(s.recoilH * adsK * (Math.random() * 2 - 1));
    this.bloom = Math.min(6, this.bloom + s.recoilV * 0.5);
    this.vmKick += 0.6 + s.recoilV * 0.15;
    this.shake += (0.03 + s.recoilV * 0.025) * store.settings.gameplay.screenShake;
    this.flashT = s.suppressed ? 0.02 : 0.045;
    this.muzzleFlash.rotation.z = Math.random() * 6; this.muzzleFlash.scale.setScalar((s.suppressed ? 0.35 : 0.8 + Math.random() * 0.5) * (w.def.category === 'SG' ? 1.4 : 1));
    this.muzzleLight.position.copy(muzzleWorld);
    audio.shot(w.def.sound, s.suppressed);
    this.addNoise(s.suppressed ? 15 : 75);
    if (store.settings.graphics.effects > 0) this.sparks.spawn(muzzleWorld.x, muzzleWorld.y, muzzleWorld.z, (Math.random() - 0.5), 1, (Math.random() - 0.5), 0.5, 0.2, 0.5, 0.5, 0.5, 0.25, -1, 3);
    if (w.mag === 0 && w.reserve > 0) this.autoReloadT = 0.25;
  }

  muzzleWorld() {
    const w = this.weapons[this.active];
    if (!w?.vm) return this.camera.getWorldPosition(new THREE.Vector3());
    this.vmRoot.updateMatrixWorld(true);
    const p = w.vm.muzzle.getWorldPosition(new THREE.Vector3());
    return this.camera.localToWorld(p);
  }

  /** Hitscan trace against world, bots (head sphere + body cylinder) and range targets */
  trace(o: THREE.Vector3, d: THREE.Vector3, max: number, ignore: Actor | null) {
    const wh = this.world.raycast(o.x, o.y, o.z, d.x, d.y, d.z, max);
    let best: { t: number; nx: number; ny: number; nz: number; metal?: boolean; bot?: Bot; target?: RangeTarget; head: boolean; player?: boolean } | null = wh ? { t: wh.dist, nx: wh.nx, ny: wh.ny, nz: wh.nz, metal: wh.box?.metal, head: false } : null;
    const lim = () => (best ? best.t : max);
    for (const b of this.bots) {
      if (!b.alive || b === ignore || (ignore && ignore.team === b.team && this.opts.mode !== 'br')) continue;
      const th = raySphere(o.x, o.y, o.z, d.x, d.y, d.z, b.pos.x, b.headY, b.pos.z, 0.19);
      const tb = rayCylinder(o.x, o.y, o.z, d.x, d.y, d.z, b.pos.x, b.pos.z, b.pos.y, b.pos.y + b.height - 0.28, 0.34);
      if (th >= 0 && th < lim() && (tb < 0 || th <= tb + 0.15)) best = { t: th, nx: 0, ny: 0, nz: 0, bot: b, head: true };
      else if (tb >= 0 && tb < lim()) best = { t: tb, nx: 0, ny: 0, nz: 0, bot: b, head: false };
    }
    if (ignore !== this.player && this.alive && !(ignore && ignore.team === 0 && this.opts.mode !== 'br')) {
      const p = this.pos; const h = this.player.height;
      const th = raySphere(o.x, o.y, o.z, d.x, d.y, d.z, p.x, p.y + h - 0.14, p.z, 0.2);
      const tb = rayCylinder(o.x, o.y, o.z, d.x, d.y, d.z, p.x, p.z, p.y, p.y + h - 0.28, 0.36);
      if (th >= 0 && th < lim()) best = { t: th, nx: 0, ny: 0, nz: 0, head: true, player: true };
      else if (tb >= 0 && tb < lim()) best = { t: tb, nx: 0, ny: 0, nz: 0, head: false, player: true };
    }
    for (const tg of this.targets) {
      if (tg.downT > 0) continue;
      const p = tg.pos;
      if (tg.plate) {
        const th = raySphere(o.x, o.y, o.z, d.x, d.y, d.z, p.x, 1.55, p.z, 0.45);
        if (th >= 0 && th < lim()) { const hp = o.clone().addScaledVector(d, th); const center = Math.hypot(hp.x - p.x, hp.y - 1.55) < 0.12; best = { t: th, nx: 0, ny: 0, nz: 1, target: tg, head: center }; }
      } else {
        const th = raySphere(o.x, o.y, o.z, d.x, d.y, d.z, p.x, 1.66, p.z, 0.19);
        const tb = rayCylinder(o.x, o.y, o.z, d.x, d.y, d.z, p.x, p.z, 0, 1.52, 0.34);
        if (th >= 0 && th < lim() && (tb < 0 || th <= tb + 0.15)) best = { t: th, nx: 0, ny: 0, nz: 0, target: tg, head: true };
        else if (tb >= 0 && tb < lim()) best = { t: tb, nx: 0, ny: 0, nz: 0, target: tg, head: false };
      }
    }
    return best;
  }

  private damageBot(b: Bot, dmg: number, from: Actor, head: boolean, wdef: WeaponDef | null, at: THREE.Vector3) {
    if (!b.alive) return;
    let dealt = dmg;
    if (b.armor > 0) { const a = Math.min(b.armor, dmg * 0.7); b.armor -= a; dealt = dmg - a; }
    b.health -= dealt; b.onDamaged(from, this.time);
    const killed = b.health <= 0;
    if (from === this.player) {
      this.hitmarkT = 0.18; this.hitmarkKill = killed; this.hitmarkHead = head;
      audio.hit(head, killed);
      if (store.settings.gameplay.damageNumbers) this.floats.push({ x: at.x, y: at.y + 0.3, z: at.z, text: String(Math.round(dmg)), color: head ? '#fbbf24' : '#ffffff', t: 0.9, big: head });
    }
    this.particles.burst(at, null, 5, 1.5, 0.45, 0.18, [0.55, 0.05, 0.05], 0.9, 6, 1.5);
    if (killed) this.onKill(from, b, head, wdef?.name ?? '');
  }

  private damageTarget(t: RangeTarget, dmg: number, head: boolean, at: THREE.Vector3) {
    t.health -= dmg; this.hitmarkT = 0.15; this.hitmarkHead = head; this.hitmarkKill = t.health <= 0;
    audio.hit(head, t.health <= 0);
    if (store.settings.gameplay.damageNumbers) this.floats.push({ x: at.x, y: at.y + 0.3, z: at.z, text: String(Math.round(dmg)), color: head ? '#fbbf24' : '#ffffff', t: 0.9, big: head });
    this.score += head ? 25 : 10;
    this.sparks.burst(at, new THREE.Vector3(0, 0, 1), 5, 3, 0.25, 0.05, [1, 0.85, 0.5], 1, 9);
    if (t.health <= 0) { t.downT = 2.5; this.rangeTargets++; this.score += 50; this.addFloatAt(at, 'TARGET DOWN', '#4ade80'); }
  }

  private botFire(b: Bot, ox: number, oy: number, oz: number, dx: number, dy: number, dz: number) {
    const o = new THREE.Vector3(ox, oy, oz), d = new THREE.Vector3(dx, dy, dz).normalize();
    const hit = this.trace(o, d, 220, b);
    const end = o.clone().addScaledVector(d, hit ? hit.t : 220);
    const fwd = v1.set(-Math.sin(b.yaw), 0, -Math.cos(b.yaw));
    const muz = new THREE.Vector3(ox + fwd.x * 0.7, oy, oz + fwd.z * 0.7);
    const nearPlayer = b.pos.distanceTo(this.pos) < 120;
    if (nearPlayer && Math.random() < 0.7) this.tracers.fire(muz, end, b.team === 0 && this.opts.mode !== 'br' ? 0x90d0ff : 0xff9a60);
    if (nearPlayer) this.sparks.spawn(muz.x, muz.y, muz.z, 0, 0.5, 0, 0.06, 0.45, 1, 0.75, 0.35, 1, 0, 0);
    if (Math.random() < (b.weapon.mode === 'auto' ? 0.8 : 1)) audio.shot(b.weapon.sound, !!b.weapon.suppressed, { x: ox, y: oy, z: oz }, 0.8);
    this.noises.push({ x: ox, y: oy, z: oz, radius: b.weapon.suppressed ? 15 : 60, time: this.time, team: b.team });
    // near miss whiz
    if (!hit?.player && this.alive) {
      const toP = v2.subVectors(this.camera.position, o); const along = toP.dot(d);
      if (along > 0 && along < (hit ? hit.t : 220)) { const closest = o.clone().addScaledVector(d, along); if (closest.distanceTo(this.camera.position) < 1.8) audio.whiz({ x: closest.x, y: closest.y, z: closest.z }); }
    }
    if (!hit) return;
    const dist = hit.t; const w = b.weapon;
    const falloff = dist <= w.range ? 1 : Math.max(w.minDmg, 1 - (dist - w.range) / (w.range * 1.5) * (1 - w.minDmg));
    const dmg = w.damage * falloff * this.diff.dmg * (hit.head ? 1.3 : 1);
    if (hit.player) this.damagePlayer(dmg, b, b.pos);
    else if (hit.bot) this.damageBot(hit.bot, dmg, b, hit.head, w, end);
    else if (nearPlayer && store.settings.graphics.effects > 0) { const n = new THREE.Vector3(hit.nx, hit.ny, hit.nz); this.particles.burst(end, n, 3, 2, 0.5, 0.2, [0.6, 0.58, 0.55], 0.7, 3, 2); if (dist < 60) this.decals.add(end, n); }
  }

  damagePlayer(amount: number, from: Actor | null, srcPos: THREE.Vector3 | null) {
    if (!this.alive || this.phase !== 'playing' || this.opts.mode === 'range') return;
    let a = amount;
    if (this.armor > 0) { const ab = Math.min(this.armor, a); this.armor -= ab; a -= ab; }
    this.health -= a; this.lastHurt = this.time; this.hurtFlash = Math.min(1, this.hurtFlash + 0.35 + amount / 80);
    this.shake += 0.12 * store.settings.gameplay.screenShake; audio.hurt();
    if (this.useKind === 'heal') this.useKind = null; // damage interrupts healing (plating continues)
    if (srcPos) { const ang = Math.atan2(srcPos.x - this.pos.x, srcPos.z - this.pos.z); this.dmgIndicators.push({ angle: ang, t: 1.2 }); }
    if (this.health <= 0) { this.health = 0; this.playerDie(from); }
  }

  private playerDie(from: Actor | null) {
    this.alive = false; this.player.alive = false; this.deaths++; this.streak = 0; this.multiplier = 1; this.deathT = 0; this.reloadT = 0; this.adsT = 0;
    this.pushFeed(from ? from.name : 'Zone', this.player.name, from instanceof Bot ? from.weapon.name : '', false, from?.team ?? -1, 0);
    if (from instanceof Bot) { from.kills++; if (this.opts.mode === 'tdm') this.teamScore[from.team]++; }
    if (this.opts.mode === 'tdm') { this.respawnAt = this.time + 3.5; this.checkTdmEnd(); }
    else {
      this.placement = this.bots.filter(b => b.alive).length + 1;
      this.endMatch(false, this.opts.mode === 'br' ? `ELIMINATED · #${this.placement}` : 'KIA', 2.5);
    }
  }

  private onKill(killer: Actor, victim: Bot, head: boolean, weaponName: string) {
    victim.alive = false; victim.deadT = 0; victim.health = 0;
    killer.kills++;
    this.pushFeed(killer.name, victim.name, weaponName, head, killer.team, victim.team);
    if (killer === this.player) {
      this.kills++; if (head) this.headshots++;
      const w = this.weapons[this.active]; if (w) this.weaponsWithKills.add(w.def.id);
      this.streak++; this.multiplier = Math.min(3, 1 + (this.streak - 1) * 0.25);
      const pts = Math.round((100 + (head ? 50 : 0)) * this.multiplier); this.score += pts;
      this.addFloatAt(victim.pos.clone().setY(victim.pos.y + 2.2), `+${pts}${head ? ' HEADSHOT' : ''}`, head ? '#fbbf24' : '#ffffff');
      this.multiKill = this.time - this.lastKillT < 4 ? this.multiKill + 1 : 1; this.lastKillT = this.time;
      const names = ['', '', 'DOUBLE KILL', 'TRIPLE KILL', 'QUAD KILL', 'RAMPAGE'];
      if (this.multiKill >= 2) { this.streakText = names[Math.min(5, this.multiKill)]; this.streakT = 2; this.score += 50 * this.multiKill; }
      else if ([3, 5, 10, 15].includes(this.streak)) { this.streakText = `${this.streak} KILL STREAK`; this.streakT = 2; }
      this.shake += 0.1;
    }
    if (this.opts.mode === 'tdm') { this.teamScore[killer.team === 0 ? 0 : 1]++; victim.respawnAt = this.time + 4.5; this.checkTdmEnd(); }
    if ((this.opts.mode === 'combat' || this.opts.mode === 'tdm') && Math.random() < 0.45) this.addLoot('ammo', victim.pos.clone());
    if (this.opts.mode === 'br') {
      const def = victim.weapon; const rar = this.randomRarity();
      const w = this.makeWeapon(def, randomLootAttachments(def, rar), 'default', rar); w.reserve = w.stats.mag * 2;
      this.addLoot('weapon', victim.pos.clone(), rar, w);
      this.addLoot('ammo', victim.pos.clone().add(v1.set(0.8, 0, 0.4)));
      if (Math.random() < 0.5) this.addLoot('armor', victim.pos.clone().add(v1.set(-0.7, 0, 0.5)), 2);
      const alive = this.bots.filter(b => b.alive).length;
      if (alive === 0 && this.alive) { this.placement = 1; this.endMatch(true, 'VICTORY · #1', 2); }
    }
    if (this.opts.mode === 'combat') this.waveRemaining = Math.max(0, this.waveRemaining - 1);
  }

  private pushFeed(killer: string, victim: string, weapon: string, head: boolean, kTeam: number, vTeam: number) {
    this.killfeed.push({ id: this.feedId++, killer, victim, weapon, head, kTeam, vTeam, t: this.time }); if (this.killfeed.length > 5) this.killfeed.shift();
  }
  showBanner(text: string, sub = '', dur = 3) { this.banner = { text, sub, id: this.bannerId++ }; this.bannerT = dur; }
  private addFloatAt(p: THREE.Vector3, text: string, color: string) { this.floats.push({ x: p.x, y: p.y, z: p.z, text, color, t: 1.3, big: true }); }
  private addFloatSelf(text: string, color: string) { const f = this.camera.getWorldDirection(new THREE.Vector3()); const p = this.camera.position.clone().addScaledVector(f, 3); this.addFloatAt(p, text, color); }

  // ------------------------------------------------------------ modes
  private updateMode(dt: number) {
    const m = this.opts.mode;
    if (m === 'combat') {
      if (this.intermission > 0) {
        this.intermission -= dt;
        if (this.intermission <= 0) {
          this.wave++;
          const count = 3 + this.wave * 2; this.waveRemaining = count; this.waveSpawnQueue = count; this.waveTime = 0;
          this.showBanner(`WAVE ${this.wave} / ${this.maxWave}`, `${count} hostiles inbound`, 2.5);
          audio.announce(`Wave ${this.wave}. Hostiles inbound.`);
        }
      } else if (this.phase === 'playing') {
        const aliveBots = this.bots.filter(b => b.alive).length;
        if (this.waveSpawnQueue > 0 && aliveBots < this.maxBots) { this.spawnEnemyFar(); this.waveSpawnQueue--; }
        // keep waves flowing: after 40s, remaining hostiles are radioed the player's APPROXIMATE position every 8s
        this.waveTime += dt;
        if (this.waveTime > 40 && Math.floor(this.waveTime / 8) !== Math.floor((this.waveTime - dt) / 8)) {
          for (const b of this.bots) if (b.alive && b.state !== 'engage') b.alert(this.pos.clone().add(v1.set((Math.random() - 0.5) * 16, 0, (Math.random() - 0.5) * 16)));
        }
        if (this.waveRemaining <= 0 && this.waveSpawnQueue <= 0) {
          this.score += 500 * this.wave;
          if (this.wave >= this.maxWave) this.endMatch(true, 'OPERATION COMPLETE', 2);
          else { this.intermission = 7; this.showBanner(`WAVE ${this.wave} CLEARED`, `+${500 * this.wave} · Resupplied`, 3); audio.stinger(true); for (const w of this.weapons) if (w) w.reserve = Math.max(w.reserve, w.stats.mag * 4); }
          // remove old corpses
          this.bots = this.bots.filter(b => { if (!b.alive && b.deadT > 3) { b.dispose(this.scene); return false; } return true; });
        }
      }
    } else if (m === 'tdm') {
      for (const b of this.bots) if (!b.alive && b.respawnAt > 0 && this.time >= b.respawnAt) {
        const spawns = this.map.teamSpawns[b.team === 0 ? 0 : 1]; b.spawn(spawns[Math.floor(Math.random() * spawns.length)]); b.respawnAt = 0;
        const p = this.world.nearestWalkable(b.pos.x, b.pos.z); b.pos.set(p.x, this.world.ground(p.x, p.z), p.z);
      }
      if (this.phase === 'playing' && this.matchTime >= this.timeLimit) this.checkTdmEnd(true);
    } else if (m === 'br') {
      this.updateZone(dt);
    }
  }

  private spawnEnemyFar() {
    const cands = [...this.map.spawns, ...this.map.patrol];
    let pick = cands[0]; let tries = 0;
    for (;;) {
      const c = cands[Math.floor(Math.random() * cands.length)]; const d = c.distanceTo(this.pos); tries++;
      if ((d > 30 && d < 75 && !this.world.lineOfSight(v1.set(c.x, c.y + 1.5, c.z), v2.set(this.pos.x, this.pos.y + 1.5, this.pos.z))) || tries > 30) { pick = c; break; }
    }
    const b = this.addBot(1, pick);
    // hunting: move toward player's approximate area
    b.alert(this.pos.clone().add(v1.set((Math.random() - 0.5) * 20, 0, (Math.random() - 0.5) * 20)));
  }

  private checkTdmEnd(timeUp = false) {
    if (this.phase !== 'playing') return;
    const [a, b] = this.teamScore;
    if (a >= this.scoreLimit || b >= this.scoreLimit || timeUp) {
      const win = a > b; const draw = a === b;
      this.endMatch(win, draw ? 'DRAW' : win ? 'YOUR TEAM WINS' : 'ENEMY TEAM WINS', 1.5);
    }
  }

  private updateZone(dt: number) {
    const z = this.zone; if (!z.enabled) return;
    const size = this.world.bounds.maxX - this.world.bounds.minX;
    const radii = [size * 0.75, size * 0.42, size * 0.25, size * 0.13, size * 0.06, 4];
    const dps = [1, 2, 4, 7, 12, 20];
    z.t -= dt;
    if (!z.shrinking && z.t <= 0 && z.phase < radii.length - 1) {
      z.shrinking = true; z.t = 25; z.fromR = z.r; z.toR = radii[z.phase + 1]; z.fromX = z.x; z.fromZ = z.z;
      const maxOff = Math.max(0, z.fromR - z.toR) * 0.6; const a = Math.random() * Math.PI * 2; const off = Math.random() * maxOff;
      z.toX = THREE.MathUtils.clamp(z.x + Math.cos(a) * off, this.world.bounds.minX + z.toR * 0.5, this.world.bounds.maxX - z.toR * 0.5);
      z.toZ = THREE.MathUtils.clamp(z.z + Math.sin(a) * off, this.world.bounds.minZ + z.toR * 0.5, this.world.bounds.maxZ - z.toR * 0.5);
      this.showBanner('ZONE COLLAPSING', 'Move to the safe area', 2.5); audio.zoneWarn(); audio.announce('Zone collapsing.');
    } else if (z.shrinking) {
      const k = 1 - Math.max(0, z.t) / 25;
      z.r = THREE.MathUtils.lerp(z.fromR, z.toR, k); z.x = THREE.MathUtils.lerp(z.fromX, z.toX, k); z.z = THREE.MathUtils.lerp(z.fromZ, z.toZ, k);
      if (z.t <= 0) { z.shrinking = false; z.phase++; z.t = 28; }
    }
    if (this.zoneMesh) { this.zoneMesh.position.set(z.x, 40, z.z); this.zoneMesh.scale.set(z.r, 1, z.r); }
    const d = dps[Math.min(dps.length - 1, z.phase)] * dt;
    if (this.alive && !this.parachute && Math.hypot(this.pos.x - z.x, this.pos.z - z.z) > z.r) { this.damagePlayer(d, null, null); if (Math.random() < dt) audio.zoneWarn(); }
    for (const b of this.bots) if (b.alive && Math.hypot(b.pos.x - z.x, b.pos.z - z.z) > z.r) {
      b.health -= d; if (b.health <= 0) { b.alive = false; b.deadT = 0; this.pushFeed('Zone', b.name, '', false, -1, b.team); if (!this.bots.some(o => o.alive) && this.alive) { this.placement = 1; this.endMatch(true, 'VICTORY · #1', 2); } }
    }
  }

  private updateTargets(dt: number) {
    for (const t of this.targets) {
      if (t.spec.kind === 'moving' && t.downT <= 0) {
        t.pos.x += t.dir * (t.spec.speed ?? 3) * dt;
        if (t.pos.x > (t.spec.maxX ?? 10)) t.dir = -1; if (t.pos.x < (t.spec.minX ?? -10)) t.dir = 1;
      }
      if (t.downT > 0) { t.downT -= dt; t.fall = Math.min(1, t.fall + dt * 5); if (t.downT <= 0) { t.health = t.maxHealth; } }
      else t.fall = Math.max(0, t.fall - dt * 4);
      t.group.rotation.x = -t.fall * (Math.PI / 2) * 0.95;
    }
  }

  private updateLoot(dt: number) {
    this.prompt = null; if (!this.alive) return;
    const camF = this.camera.getWorldDirection(v1);
    let bestItem: Loot | null = null; let bestScore = Infinity;
    for (const l of this.loot) {
      if (l.taken) continue;
      const d = l.pos.distanceTo(this.pos);
      // distance culling: loot models beyond 55m are hidden (big draw-call saving in BR)
      const vis = d < 55; if (l.mesh.visible !== vis) l.mesh.visible = vis;
      if (!vis) continue;
      l.spin += dt; const child = l.mesh.children[0]; if (child) { child.rotation.y = l.spin; child.position.y = (l.kind === 'weapon' ? 0.45 : 0.2) + Math.sin(l.spin * 2) * 0.05; }
      if (d > 2.6) continue;
      if (l.kind === 'ammo' && d < 1.3) { this.takeLoot(l); continue; }
      const toL = v2.subVectors(l.pos, this.camera.position).normalize(); const dot = toL.dot(camF);
      const score = d - dot * 1.5; if (score < bestScore && (dot > 0.3 || d < 1.3)) { bestScore = score; bestItem = l; }
    }
    let bestCrate: Crate | null = null;
    for (const c of this.crates) {
      if (c.opened) { c.openT = Math.min(1, c.openT + dt * 3); c.lid.rotation.x = -c.openT * 1.9; continue; }
      if (c.pos.distanceTo(this.pos) < 2.4) bestCrate = c;
    }
    const keyName = this.touch ? 'USE' : `[${store.settings.controls.bindings.interact.replace('Key', '')}]`;
    if (bestItem) {
      const l = bestItem;
      this.prompt = l.kind === 'weapon' && l.weapon ? `${keyName} ${this.weapons[0] && this.weapons[1] ? 'SWAP FOR' : 'PICK UP'} ${l.weapon.def.name} · ${RARITY_NAMES[l.rarity]}` : `${keyName} PICK UP ${l.kind === 'armor' ? 'ARMOR PLATE' : l.kind === 'medkit' ? 'MEDKIT' : 'AMMO'}`;
      if (this.input.pressed('interact')) this.takeLoot(l);
    } else if (bestCrate) {
      this.prompt = `${keyName} OPEN SUPPLY CRATE`;
      if (this.input.pressed('interact')) this.openCrate(bestCrate);
    }
  }

  private takeLoot(l: Loot) {
    if (l.taken) return;
    if (l.kind === 'ammo') {
      let added = false;
      for (const w of this.weapons) if (w) { const cap = w.stats.mag * 8; if (w.reserve < cap) { w.reserve = Math.min(cap, w.reserve + w.stats.mag * 2); added = true; } }
      if (!added) return; // full: leave on ground
      this.addFloatSelf('+AMMO', '#fbbf24');
    } else if (l.kind === 'armor') {
      if (this.plates >= 3) { this.addFloatSelf('PLATES FULL', '#f87171'); audio.deny(); return; }
      this.plates++;
    } else if (l.kind === 'medkit') {
      if (this.medkits >= 3) { this.addFloatSelf('MEDKITS FULL', '#f87171'); audio.deny(); return; }
      this.medkits++;
    } else if (l.kind === 'weapon' && l.weapon) {
      const nw = l.weapon; nw.vm = null;
      let slot = this.weapons.findIndex(w => !w);
      if (slot === -1) slot = this.active;
      const old = this.weapons[slot];
      if (old) { if (old.vm) this.vmRoot.remove(old.vm.group); old.vm = null; this.addLoot('weapon', this.pos.clone().add(v1.set(Math.sin(this.yaw) * -0.8, 0, Math.cos(this.yaw) * -0.8)), old.rarity, old); }
      this.weapons[slot] = nw;
      this.equip(slot, true);
    }
    l.taken = true; this.scene.remove(l.mesh); audio.pickup();
    this.loot = this.loot.filter(x => !x.taken);
  }

  private openCrate(c: Crate) {
    if (c.opened) return; c.opened = true; this.crateCount++; audio.crate();
    const n = 2 + Math.floor(Math.random() * 2);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2; const p = c.pos.clone().add(v1.set(Math.cos(a) * 1.3, 0, Math.sin(a) * 1.3));
      p.y = this.world.floorAt(p.x, p.z, 0.2, c.pos.y + 0.6);
      const r = Math.random();
      if (this.opts.mode === 'br' && r < 0.45) { const w = this.randomLootWeapon(); if (w.rarity < 2) { w.rarity = 2; } this.addLoot('weapon', p, w.rarity, w); }
      else if (r < 0.7 || this.opts.mode !== 'br') this.addLoot('ammo', p);
      else if (r < 0.85) this.addLoot('armor', p, 2); else this.addLoot('medkit', p, 1);
    }
    this.sparks.burst(c.pos.clone().setY(c.pos.y + 0.8), new THREE.Vector3(0, 1, 0), 14, 4, 0.6, 0.08, [1, 0.85, 0.3], 1, 6);
  }

  // ------------------------------------------------------------ range armory
  setWeaponFromArmory(slot: number, id: string, att: AttachConfig, skin = 'default') {
    const def = getWeapon(id); const old = this.weapons[slot];
    if (old?.vm) this.vmRoot.remove(old.vm.group);
    this.weapons[slot] = this.makeWeapon(def, att, skin);
    this.equip(slot, true);
  }
  resetRangeStats() { this.shots = 0; this.hits = 0; this.score = 0; this.rangeTargets = 0; this.matchTime = 0; for (const t of this.targets) { t.health = t.maxHealth; t.downT = 0; } this.showBanner('STATS RESET', '', 1.5); }
  endRangeSession() { this.endMatch(true, 'SESSION COMPLETE', 0.1); }

  // ------------------------------------------------------------ end of match
  private endMatch(victory: boolean, text: string, delay: number) {
    if (this.phase !== 'playing') return;
    this.phase = 'ending'; this.endT = delay; this.endVictory = victory; this.endText = text;
    this.showBanner(text, victory ? 'Mission accomplished' : 'Mission failed', delay + 1);
    audio.stinger(victory); audio.announce(victory ? (this.opts.mode === 'range' ? 'Session complete.' : 'Victory.') : 'Mission failed.');
  }
  private endVictory = false; private endText = '';
  private finish() {
    this.phase = 'ended'; if (document.pointerLockElement) document.exitPointerLock();
    const acc = this.shots > 0 ? this.hits / this.shots : 0;
    let score = this.score;
    if (this.opts.mode === 'br') score += Math.max(0, (14 - this.placement)) * 100 + (this.endVictory ? 1500 : 0);
    if (this.opts.mode === 'tdm' && this.endVictory) score += 1000;
    if (this.opts.mode === 'range') score += Math.round(acc * 500);
    this.cb.onEnd({
      mode: this.opts.mode, map: this.opts.map, victory: this.endVictory, resultText: this.endText, score: Math.round(score), kills: this.kills, deaths: this.deaths,
      headshots: this.headshots, shots: this.shots, hits: this.hits, time: Math.round(this.matchTime), placement: this.opts.mode === 'br' ? this.placement : undefined,
      cratesOpened: this.crateCount, rangeTargets: this.rangeTargets, longestShot: this.longestShot, weaponsWithKills: [...this.weaponsWithKills],
      teamScore: this.opts.mode === 'tdm' ? [...this.teamScore] as [number, number] : undefined,
    });
  }

  // ------------------------------------------------------------ render
  private render(dt: number) {
    const g = store.settings.graphics; const w = this.weapons[this.active];
    // camera
    const eye = this.alive ? (STAND_H + (CROUCH_H - STAND_H) * this.crouchK) - 0.12 : Math.max(0.3, 1.6 - this.deathT * 2);
    const hs = Math.hypot(this.vel.x, this.vel.z);
    const bob = this.ground.onGround && this.alive ? Math.sin(this.bobPhase * 2) * Math.min(1, hs / 6) * 0.035 * (1 - this.adsT * 0.85) : 0;
    const sh = this.shake;
    this.camera.position.set(this.pos.x + (Math.random() - 0.5) * sh * 0.15, this.pos.y + eye + bob - this.landDip + (Math.random() - 0.5) * sh * 0.15, this.pos.z + (Math.random() - 0.5) * sh * 0.15);
    const roll = (this.slideT > 0 ? 0.08 : 0) + (Math.random() - 0.5) * sh * 0.04 + (this.alive ? 0 : Math.min(0.5, this.deathT * 0.4));
    this.camera.rotation.set(this.pitch + (Math.random() - 0.5) * sh * 0.02, this.yaw, roll);
    const zoom = w ? 1 + (w.stats.zoom - 1) * this.adsT : 1;
    const fov = g.fov * (this.sprinting ? 1.06 : 1) / zoom;
    if (Math.abs(this.camera.fov - fov) > 0.01) { this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, fov, Math.min(1, dt * 18)); this.camera.updateProjectionMatrix(); }
    this.camera.updateMatrixWorld();
    if (this.dome) { this.dome.position.copy(this.camera.position); this.dome.scale.setScalar(Math.min(1, (this.camera.far * 0.9) / 600)); }
    // sun follows player for shadows
    const sd = this.map.sky.sunDir; this.sun.position.set(this.pos.x + sd.x * 90, this.pos.y + sd.y * 90, this.pos.z + sd.z * 90); this.sun.target.position.copy(this.pos);
    // audio listener
    const f = this.camera.getWorldDirection(v1); audio.setListener(this.camera.position, f);
    // viewmodel
    this.updateViewmodel(dt, w);
    const scoped = !!w && w.stats.zoom >= 2.3 && this.adsT > 0.92;
    this.vmRoot.visible = this.alive && !scoped;
    this.renderer.clear();
    if (this.composer) { this.composer.render(dt); }
    else {
      this.renderer.render(this.scene, this.camera);
      this.renderer.clearDepth();
      this.renderer.render(this.vmScene, this.vmCamera);
    }
  }

  private updateViewmodel(_dt: number, w: WeaponInst | null) {
    if (!w?.vm) return;
    const vm = w.vm; const a = this.adsT; const hs = Math.hypot(this.vel.x, this.vel.z);
    const hip = v1.set(0.17, -0.19, -0.42), ads = v2.set(0, -vm.sightY - 0.0, -0.3);
    const p = hip.clone().lerp(ads, THREE.MathUtils.smoothstep(a, 0, 1));
    const bobK = this.ground.onGround ? Math.min(1, hs / 5) * (1 - a * 0.9) : 0;
    p.x += Math.cos(this.bobPhase) * 0.012 * bobK * (this.sprinting ? 2 : 1);
    p.y += Math.abs(Math.sin(this.bobPhase)) * 0.012 * bobK * (this.sprinting ? 2 : 1) - this.landDip * 0.3;
    p.z += this.vmKick * 0.035 * (1 - a * 0.5);
    let rx = this.vmKick * 0.05 * (1 - a * 0.6) - this.swayY * 0.6, ry = -this.swayX * 0.8, rz = 0;
    if (this.sprinting && this.adsT < 0.1) { p.x += 0.05; p.y -= 0.05; ry += 0.55; rx -= 0.25; rz += 0.2; }
    if (this.crouched) { p.y -= 0.01; rz += 0.04 * (1 - a); }
    // reload animation
    if (this.reloadT > 0) {
      const t = 1 - this.reloadT / this.reloadDur; const k = Math.sin(Math.min(1, t) * Math.PI);
      p.y -= k * 0.09; rz += k * 0.55; rx += k * 0.25;
      if (vm.mag) { const m = t < 0.2 ? t / 0.2 : t < 0.55 ? 1 : t < 0.8 ? 1 - (t - 0.55) / 0.25 : 0; vm.mag.position.y = -m * 0.25; }
    } else if (vm.mag) vm.mag.position.y = 0;
    // switch animation
    if (this.switchT > 0) { const k = Math.min(1, this.switchT / 0.3); p.y -= k * 0.3; rx -= k * 0.6; }
    // inspect
    if (this.inspectT > 0) { const t = 1 - this.inspectT / 2.2; const k = Math.sin(t * Math.PI); ry += k * 1.0; rz += k * 0.6; p.x -= k * 0.08; p.z += k * 0.05; }
    if (!this.alive) p.y -= 0.6;
    this.vmRoot.position.copy(p); this.vmRoot.rotation.set(rx, ry, rz);
    this.vmCamera.fov = 58 - a * 10; this.vmCamera.updateProjectionMatrix();
  }

  // ------------------------------------------------------------ HUD canvas (fast, per-frame)
  private drawHud(dt: number) {
    const c = this.hud; const W = this.hudCanvas.width, H = this.hudCanvas.height; const d = Math.min(window.devicePixelRatio || 1, 2);
    c.clearRect(0, 0, W, H);
    const cx = W / 2, cy = H / 2; const w = this.weapons[this.active];
    // hurt vignette & low health
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 1.6);
    const low = this.alive ? Math.max(0, 1 - this.health / (this.maxHealth * 0.45)) : 1;
    const vig = Math.min(0.85, this.hurtFlash * 0.6 + low * 0.45);
    if (vig > 0.01) { const gr = c.createRadialGradient(cx, cy, Math.min(W, H) * 0.3, cx, cy, Math.max(W, H) * 0.7); gr.addColorStop(0, 'rgba(160,0,0,0)'); gr.addColorStop(1, `rgba(160,0,0,${vig})`); c.fillStyle = gr; c.fillRect(0, 0, W, H); }
    // outside zone tint
    if (this.zone.enabled && this.alive && Math.hypot(this.pos.x - this.zone.x, this.pos.z - this.zone.z) > this.zone.r) { c.fillStyle = 'rgba(40,120,255,0.18)'; c.fillRect(0, 0, W, H); }
    if (!this.alive) { c.fillStyle = `rgba(0,0,0,${Math.min(0.6, this.deathT * 0.4)})`; c.fillRect(0, 0, W, H); }
    // scope overlay
    const scoped = !!w && w.stats.zoom >= 2.3 && this.adsT > 0.92 && this.alive;
    if (scoped) {
      const r = Math.min(W, H) * 0.44;
      c.save(); c.fillStyle = '#000'; c.beginPath(); c.rect(0, 0, W, H); c.arc(cx, cy, r, 0, Math.PI * 2, true); c.fill('evenodd');
      c.strokeStyle = 'rgba(0,0,0,0.9)'; c.lineWidth = 1.5 * d; c.beginPath(); c.moveTo(cx - r, cy); c.lineTo(cx + r, cy); c.moveTo(cx, cy - r); c.lineTo(cx, cy + r); c.stroke();
      c.lineWidth = 4 * d; c.beginPath(); c.moveTo(cx - r, cy); c.lineTo(cx - r * 0.12, cy); c.moveTo(cx + r * 0.12, cy); c.lineTo(cx + r, cy); c.moveTo(cx, cy + r * 0.12); c.lineTo(cx, cy + r); c.stroke();
      c.fillStyle = '#ff3030'; c.beginPath(); c.arc(cx, cy, 2 * d, 0, 7); c.fill();
      const gr = c.createRadialGradient(cx, cy, r * 0.8, cx, cy, r); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.85)'); c.fillStyle = gr; c.beginPath(); c.arc(cx, cy, r, 0, 7); c.fill();
      c.restore();
    }
    // crosshair
    if (this.alive && w && !scoped && !this.sprinting) {
      const hs = Math.hypot(this.vel.x, this.vel.z);
      const spreadDeg = THREE.MathUtils.lerp(w.stats.spreadHip, w.stats.spreadAds, this.adsT) + hs * 0.22 * (1 - this.adsT * 0.8) + (this.ground.onGround ? 0 : 2.5) + this.bloom;
      const px = Math.tan(THREE.MathUtils.degToRad(spreadDeg)) / Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)) * (H / 2);
      const gap = Math.max(4 * d, px); const len = 7 * d; const alpha = 1 - this.adsT * 0.85;
      c.strokeStyle = `rgba(255,255,255,${alpha})`; c.lineWidth = 2 * d; c.shadowColor = 'rgba(0,0,0,0.8)'; c.shadowBlur = 3 * d;
      c.beginPath();
      if (w.def.category === 'SG') { c.arc(cx, cy, gap, 0, Math.PI * 2); }
      else { c.moveTo(cx - gap - len, cy); c.lineTo(cx - gap, cy); c.moveTo(cx + gap, cy); c.lineTo(cx + gap + len, cy); c.moveTo(cx, cy + gap); c.lineTo(cx, cy + gap + len); c.moveTo(cx, cy - gap - len); c.lineTo(cx, cy - gap); }
      c.stroke();
      c.fillStyle = `rgba(255,255,255,${0.9 * (this.adsT > 0.5 ? 1 : alpha)})`; c.fillRect(cx - d, cy - d, 2 * d, 2 * d);
      c.shadowBlur = 0;
    }
    // hitmarker
    if (this.hitmarkT > 0) {
      this.hitmarkT -= dt; const k = this.hitmarkT / 0.18; const s = (8 + (1 - k) * 4) * d, g = 5 * d;
      c.strokeStyle = this.hitmarkKill ? '#ff3b3b' : this.hitmarkHead ? '#fbbf24' : '#ffffff'; c.lineWidth = (this.hitmarkKill ? 3.5 : 2.5) * d; c.globalAlpha = Math.min(1, k * 2);
      c.beginPath(); c.moveTo(cx - g - s, cy - g - s); c.lineTo(cx - g, cy - g); c.moveTo(cx + g + s, cy - g - s); c.lineTo(cx + g, cy - g); c.moveTo(cx - g - s, cy + g + s); c.lineTo(cx - g, cy + g); c.moveTo(cx + g + s, cy + g + s); c.lineTo(cx + g, cy + g); c.stroke();
      c.globalAlpha = 1;
    }
    // floating damage numbers / popups
    c.textAlign = 'center'; c.textBaseline = 'middle';
    for (const f of this.floats) {
      f.t -= dt; f.y += dt * 0.6;
      v3.set(f.x, f.y, f.z).project(this.camera);
      if (v3.z > 1 || f.t <= 0) continue;
      const sx = (v3.x * 0.5 + 0.5) * W, sy = (-v3.y * 0.5 + 0.5) * H;
      c.globalAlpha = Math.min(1, f.t * 2.5); c.font = `800 ${(f.big ? 20 : 15) * d}px ui-sans-serif, system-ui`;
      c.lineWidth = 3 * d; c.strokeStyle = 'rgba(0,0,0,0.7)'; c.strokeText(f.text, sx, sy); c.fillStyle = f.color; c.fillText(f.text, sx, sy);
    }
    c.globalAlpha = 1; this.floats = this.floats.filter(f => f.t > 0);
    // damage direction indicators
    for (const di of this.dmgIndicators) {
      di.t -= dt; const rel = di.angle - Math.atan2(-Math.sin(this.yaw), -Math.cos(this.yaw));
      c.save(); c.translate(cx, cy); c.rotate(-rel + Math.PI); c.globalAlpha = Math.min(1, di.t);
      c.fillStyle = 'rgba(255,40,40,0.85)'; c.beginPath(); const R = Math.min(W, H) * 0.18; c.arc(0, 0, R, -Math.PI / 2 - 0.3, -Math.PI / 2 + 0.3); c.arc(0, 0, R + 10 * d, -Math.PI / 2 + 0.25, -Math.PI / 2 - 0.25, true); c.fill(); c.restore();
    }
    c.globalAlpha = 1; this.dmgIndicators = this.dmgIndicators.filter(x => x.t > 0);
    // use (heal/plate) progress ring
    if (this.useKind) {
      const tot = this.useKind === 'heal' ? 2.2 : 1.1; const k = 1 - this.useT / tot;
      c.strokeStyle = 'rgba(255,255,255,0.25)'; c.lineWidth = 5 * d; c.beginPath(); c.arc(cx, cy + 70 * d, 18 * d, 0, 7); c.stroke();
      c.strokeStyle = this.useKind === 'heal' ? '#4ade80' : '#38bdf8'; c.beginPath(); c.arc(cx, cy + 70 * d, 18 * d, -Math.PI / 2, -Math.PI / 2 + k * Math.PI * 2); c.stroke();
    }
    this.drawMinimap(c, d);
  }

  private drawMinimap(c: CanvasRenderingContext2D, d: number) {
    const size = (this.touch ? 110 : 160) * d; const x0 = 14 * d, y0 = 14 * d; const R = size / 2; const cx = x0 + R, cy = y0 + R;
    const b = this.world.bounds; const worldSize = b.maxX - b.minX; const range = this.opts.mode === 'range' ? 80 : 70; // metres shown across radius
    const scale = R / range;
    c.save(); c.beginPath(); c.arc(cx, cy, R, 0, Math.PI * 2); c.clip();
    c.fillStyle = 'rgba(10,14,18,0.8)'; c.fillRect(x0, y0, size, size);
    c.translate(cx, cy); c.rotate(this.yaw);
    const mm = this.map.minimap; const pxPerM = mm.width / worldSize;
    c.globalAlpha = 0.85;
    c.drawImage(mm, (b.minX - this.pos.x) * scale, (b.minZ - this.pos.z) * scale, worldSize * scale, (b.maxZ - b.minZ) * scale);
    void pxPerM; c.globalAlpha = 1;
    // zone
    if (this.zone.enabled) {
      c.strokeStyle = '#3aa0ff'; c.lineWidth = 2 * d; c.beginPath(); c.arc((this.zone.x - this.pos.x) * scale, (this.zone.z - this.pos.z) * scale, this.zone.r * scale, 0, 7); c.stroke();
      if (this.zone.shrinking || this.zone.toR < this.zone.r) { c.strokeStyle = '#ffffff'; c.setLineDash([4 * d, 4 * d]); c.beginPath(); c.arc((this.zone.toX - this.pos.x) * scale, (this.zone.toZ - this.pos.z) * scale, this.zone.toR * scale, 0, 7); c.stroke(); c.setLineDash([]); }
    }
    // actors
    for (const bot of this.bots) {
      if (!bot.alive) continue;
      const ally = bot.team === 0 && this.opts.mode !== 'br';
      const revealed = ally || (this.time - bot.lastFiredAt < 1.5 && !bot.weapon.suppressed) || bot.pos.distanceTo(this.pos) < 6;
      if (!revealed) continue;
      c.fillStyle = ally ? '#3aa0ff' : '#ff3b3b'; c.beginPath(); c.arc((bot.pos.x - this.pos.x) * scale, (bot.pos.z - this.pos.z) * scale, 3.5 * d, 0, 7); c.fill();
    }
    for (const t of this.targets) { c.fillStyle = t.downT > 0 ? '#555' : '#fbbf24'; c.fillRect((t.pos.x - this.pos.x) * scale - 2 * d, (t.pos.z - this.pos.z) * scale - 2 * d, 4 * d, 4 * d); }
    c.restore();
    // player arrow
    c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(cx, cy - 7 * d); c.lineTo(cx - 5 * d, cy + 5 * d); c.lineTo(cx + 5 * d, cy + 5 * d); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 1.5 * d; c.beginPath(); c.arc(cx, cy, R, 0, 7); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.8)'; c.font = `700 ${10 * d}px ui-sans-serif`; c.textAlign = 'center';
    c.fillText('N', cx - Math.sin(this.yaw) * (R - 8 * d), cy - Math.cos(this.yaw) * (R - 8 * d));
  }

  // ------------------------------------------------------------ HUD state for React (polled ~10Hz)
  getHud(): HudState {
    const w = this.weapons[this.active]; const m = this.opts.mode;
    const t = m === 'tdm' ? Math.max(0, this.timeLimit - this.matchTime) : this.matchTime;
    const timeText = `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
    let zone: HudState['zone'] = null;
    if (m === 'br' && this.zone.enabled) {
      const outside = Math.hypot(this.pos.x - this.zone.x, this.pos.z - this.zone.z) > this.zone.r;
      zone = { text: this.zone.shrinking ? `ZONE CLOSING · ${Math.ceil(this.zone.t)}s` : this.zone.phase >= 5 ? 'FINAL ZONE' : `ZONE SHRINKS IN ${Math.ceil(this.zone.t)}s`, outside };
    }
    const enemiesLeft = m === 'combat' ? this.waveRemaining : m === 'br' ? this.bots.filter(b => b.alive).length : this.bots.filter(b => b.alive && b.team !== 0).length;
    const objective = m === 'combat' ? (this.intermission > 0 ? 'Prepare for the next wave' : `Eliminate all hostiles — wave ${this.wave}/${this.maxWave}`)
      : m === 'tdm' ? `First team to ${this.scoreLimit} wins` : m === 'br' ? (this.parachute ? 'Steer your landing' : 'Be the last operator standing') : 'Train on targets · [B] Armory';
    return {
      mode: m, health: Math.ceil(this.health), maxHealth: this.maxHealth, armor: Math.ceil(this.armor), plates: this.plates, medkits: this.medkits, alive: this.alive,
      respawnIn: !this.alive && m === 'tdm' ? Math.max(0, this.respawnAt - this.time) : 0,
      weapon: w ? { name: w.def.name, category: w.def.category, mag: w.mag, magSize: w.stats.mag, reserve: w.reserve, rarity: w.rarity, mode: w.stats.mode.toUpperCase() } : null,
      slots: this.weapons.map(x => (x ? { name: x.def.name, rarity: x.rarity } : null)), active: this.active,
      reload: this.reloadT > 0 ? 1 - this.reloadT / this.reloadDur : 0, useProgress: this.useKind ? 1 - this.useT / (this.useKind === 'heal' ? 2.2 : 1.1) : 0, useLabel: this.useKind === 'heal' ? 'HEALING' : this.useKind ? 'PLATING' : '',
      score: Math.round(this.score), multiplier: this.multiplier, kills: this.kills, timeText, enemiesLeft, wave: this.wave, maxWave: this.maxWave,
      teamScore: [...this.teamScore] as [number, number], scoreLimit: this.scoreLimit, killfeed: [...this.killfeed], prompt: this.prompt, banner: this.banner, zone, objective,
      range: m === 'range' ? { hits: this.hits, misses: this.shots - this.hits, acc: this.shots ? Math.round((this.hits / this.shots) * 100) : 0, time: Math.floor(this.matchTime), targets: this.rangeTargets } : null,
      fps: this.fps, streakText: this.streakText, paused: this.paused,
    };
  }
}
