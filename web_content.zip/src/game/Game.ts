import * as THREE from "three";
import { EngineAudio } from "@/game/audio";
import { createCar, disposeCar, disposeCarGeometries, type CarVisual } from "@/game/carMesh";
import { formatTime } from "@/game/format";
import { SAVE_KEY } from "@/game/save";
import { SKINS, skinById } from "@/game/skins";
import { LAPS, TRACK, indexAtDist } from "@/game/track";
import type { ControlsProbe, GameHandle, GameOptions, HudBind, Phase, RacerResult, SaveData } from "@/game/types";
import { buildWorld, type WorldBundle } from "@/game/world";

const STEP = 1 / 60;
const MAX_STEPS = 5;

type Slot = { name: string; player: boolean; pace: number; lat0: number; dist0: number };

type Racer = Slot & {
  skinId: string;
  visual: CarVisual;
  x: number;
  y: number;
  z: number;
  yaw: number;
  vx: number;
  vz: number;
  next: number;
  lastCp: number;
  lap: number;
  finished: boolean;
  finishTime: number;
  lapStamp: number;
  drift: number;
  driftArmed: boolean;
  boost: number;
  kick: number;
  stuck: number;
  sIdx: number;
  prevX: number;
  prevZ: number;
  teleport: boolean;
  pitch: number;
  steer: number;
  fs: number;
};

const SLOTS: Slot[] = [
  { name: "أنت", player: true, pace: 1, lat0: -1.7, dist0: 20 },
  { name: "شهاب", player: false, pace: 0.93, lat0: 1.7, dist0: 30 },
  { name: "رعد", player: false, pace: 0.96, lat0: 1.7, dist0: 12 },
  { name: "غيمة", player: false, pace: 0.86, lat0: -1.7, dist0: 4 },
];

function bindHud(root: HTMLElement): HudBind {
  const q = (name: string) => {
    const el = root.querySelector(`[data-hud="${name}"]`);
    if (!(el instanceof HTMLElement)) throw new Error(`missing hud ${name}`);
    return el;
  };
  return {
    speed: q("speed"),
    lap: q("lap"),
    pos: q("pos"),
    lapTime: q("lapTime"),
    raceTime: q("raceTime"),
    best: q("best"),
    drift: q("drift"),
    wrong: q("wrong"),
    flash: q("flash"),
    count: q("count"),
    countWrap: q("countWrap"),
    boost: q("boost"),
  };
}

export function createGame(opts: GameOptions): GameHandle {
  return new Game(opts);
}

class Game implements GameHandle {
  private opts: GameOptions;
  private hud: HudBind;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(68, 1, 0.12, 480);
  private renderer: THREE.WebGLRenderer;
  private world: WorldBundle;
  private audio = new EngineAudio();
  private racers: Racer[] = [];
  private phase: Phase = "garage";
  private skinId: string;
  private auto: boolean;
  private mute: boolean;
  private bestLap: number;
  private bestRace: number;
  private count = 3;
  private raceTime = 0;
  private acc = 0;
  private last = -1;
  private shake = 0;
  private flash = "";
  private flashT = 0;
  private wrongT = 0;
  private view = 0;
  private camInit = false;
  private camX = 0;
  private camY = 6;
  private camZ = 12;
  private lookX = 0;
  private lookY = 1;
  private lookZ = 0;
  private pad: number | null = null;
  private hold = { gas: false, brake: false, drift: false };
  private keys = new Set<string>();
  private qaKeys: Set<string> | null = null;
  private reduce: boolean;
  private raf = 0;
  private ro: ResizeObserver;
  private probe: ControlsProbe;
  private mapBounds: { minX: number; maxX: number; minZ: number; maxZ: number } | null = null;
  private sparkN = 140;
  private sparkPos = new Float32Array(140 * 3);
  private sparkVel = new Float32Array(140 * 3);
  private sparkLife = new Float32Array(140);
  private sparkCol = new Float32Array(140 * 3);
  private sparkI = 0;
  private sparkAttr: THREE.BufferAttribute;
  private sparkColAttr: THREE.BufferAttribute;
  private disposed = false;

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys.add(e.code);
    if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
    if (e.code === "KeyC") this.cycleCam();
    if (e.code === "KeyR") this.rescue();
    if (e.code === "Escape") this.togglePause();
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };
  private onBlur = () => {
    this.keys.clear();
    this.pad = null;
    this.hold.gas = false;
    this.hold.brake = false;
    this.hold.drift = false;
  };
  private onVis = () => {
    if (!document.hidden) {
      this.last = -1;
      if (!this.mute) this.audio.unlock();
    }
  };
  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    this.frame(now);
  };

  constructor(opts: GameOptions) {
    this.opts = opts;
    this.hud = bindHud(opts.hudRoot);
    this.skinId = opts.save.skin;
    this.auto = opts.save.auto;
    this.mute = opts.save.mute;
    this.bestLap = opts.save.bestLap;
    this.bestRace = opts.save.bestRace;
    this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    this.renderer = new THREE.WebGLRenderer({
      canvas: opts.view,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor("#0c1016", 1);
    this.world = buildWorld(this.scene);

    for (let i = 0; i < this.sparkN; i++) this.sparkPos[i * 3 + 1] = -40;
    const sparkGeo = new THREE.BufferGeometry();
    this.sparkAttr = new THREE.BufferAttribute(this.sparkPos, 3);
    this.sparkColAttr = new THREE.BufferAttribute(this.sparkCol, 3);
    sparkGeo.setAttribute("position", this.sparkAttr);
    sparkGeo.setAttribute("color", this.sparkColAttr);
    this.scene.add(
      new THREE.Points(
        sparkGeo,
        new THREE.PointsMaterial({
          size: 0.28,
          vertexColors: true,
          transparent: true,
          opacity: 0.92,
          depthWrite: false,
        }),
      ),
    );

    this.spawnRacers();
    this.resetPositions();
    this.audio.setMuted(this.mute);
    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(opts.view.parentElement ?? opts.view);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onVis);

    this.probe = {
      getYaw: () => this.player.yaw,
      getSpeed: () => Math.hypot(this.player.vx, this.player.vz),
      setKeys: (codes) => this.applyKeys(codes),
    };
    window.__controlsTest = this.probe;
    this.raf = requestAnimationFrame(this.loop);
  }

  private get player(): Racer {
    return this.racers[0];
  }

  private skinList(): string[] {
    const others = SKINS.map((s) => s.id).filter((id) => id !== this.skinId);
    return [this.skinId, others[0], others[1], others[2]];
  }

  private spawnRacers(): void {
    const ids = this.skinList();
    SLOTS.forEach((slot, i) => {
      const visual = createCar(skinById(ids[i]), slot.player);
      this.scene.add(visual.root);
      this.racers.push({
        ...slot,
        skinId: ids[i],
        visual,
        x: 0,
        y: 0,
        z: 0,
        yaw: 0,
        vx: 0,
        vz: 0,
        next: 1,
        lastCp: 0,
        lap: 0,
        finished: false,
        finishTime: 0,
        lapStamp: 0,
        drift: 0,
        driftArmed: false,
        boost: 0,
        kick: 0,
        stuck: 0,
        sIdx: 0,
        prevX: 0,
        prevZ: 0,
        teleport: true,
        pitch: 0,
        steer: 0,
        fs: 0,
      });
    });
  }

  private syncSkins(): void {
    const ids = this.skinList();
    this.racers.forEach((car, i) => {
      if (car.skinId === ids[i]) return;
      disposeCar(car.visual);
      car.skinId = ids[i];
      car.visual = createCar(skinById(ids[i]), car.player);
      this.scene.add(car.visual.root);
    });
  }

  private resetPositions(): void {
    for (const car of this.racers) {
      const idx = indexAtDist(car.dist0);
      const s = TRACK.samples[idx];
      car.x = s.x + s.rx * car.lat0;
      car.z = s.z + s.rz * car.lat0;
      car.y = s.y;
      car.yaw = Math.atan2(-s.tx, -s.tz);
      car.vx = 0;
      car.vz = 0;
      car.sIdx = idx;
      car.prevX = car.x;
      car.prevZ = car.z;
      car.teleport = true;
      car.lap = 0;
      car.finished = false;
      car.finishTime = 0;
      car.drift = 0;
      car.driftArmed = false;
      car.boost = 0;
      car.kick = 0;
      car.stuck = 0;
      car.fs = 0;
      car.steer = 0;
      car.pitch = 0;
      car.lapStamp = 0;
      let next = 0;
      for (let i = 0; i < TRACK.checkpoints.length; i++) {
        if (TRACK.samples[TRACK.checkpoints[i]].dist > s.dist + 1.5) {
          next = i;
          break;
        }
      }
      car.next = next;
      car.lastCp = (next - 1 + TRACK.checkpoints.length) % TRACK.checkpoints.length;
    }
    this.raceTime = 0;
    this.wrongT = 0;
    this.shake = 0;
    this.acc = 0;
  }

  private persist(): void {
    const data: SaveData = {
      skin: this.skinId,
      auto: this.auto,
      mute: this.mute,
      bestLap: this.bestLap,
      bestRace: this.bestRace,
    };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch {
      /* ignore quota */
    }
  }

  private emit(): void {
    this.opts.onPhase(this.phase, {
      bestLap: this.bestLap,
      bestRace: this.bestRace,
      results: this.phase === "finish" ? this.results() : undefined,
    });
  }

  private resize(): void {
    const w = this.opts.view.clientWidth;
    const h = this.opts.view.clientHeight;
    if (w < 2 || h < 2) return;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  start(): void {
    this.syncSkins();
    this.resetPositions();
    this.phase = "countdown";
    this.count = 3.01;
    this.camInit = false;
    this.unlock();
    this.emit();
  }

  pause(): void {
    if (this.phase !== "race") return;
    this.phase = "paused";
    this.emit();
  }

  resume(): void {
    if (this.phase !== "paused") return;
    this.phase = "race";
    this.last = -1;
    this.emit();
  }

  toGarage(): void {
    this.phase = "garage";
    this.syncSkins();
    this.resetPositions();
    this.emit();
  }

  setSkin(id: string): void {
    if (!SKINS.some((s) => s.id === id)) return;
    if (this.phase === "race" || this.phase === "countdown") return;
    this.skinId = id;
    this.syncSkins();
    this.persist();
  }

  setPad(v: number | null): void {
    this.pad = v;
  }

  setHold(key: "gas" | "brake" | "drift", v: boolean): void {
    this.hold[key] = v;
  }

  setAuto(v: boolean): void {
    this.auto = v;
    this.persist();
  }

  setMute(v: boolean): void {
    this.mute = v;
    this.audio.setMuted(v);
    if (!v) this.audio.unlock();
    this.persist();
  }

  cycleCam(): void {
    this.view = this.view === 0 ? 1 : 0;
    this.camInit = false;
  }

  rescue(): void {
    if (this.phase !== "race") return;
    this.teleport(this.player);
  }

  unlock(): void {
    if (!this.mute) this.audio.unlock();
  }

  private togglePause(): void {
    if (this.phase === "race") this.pause();
    else if (this.phase === "paused") this.resume();
  }

  private applyKeys(codes: string[]): void {
    this.qaKeys = new Set(codes);
    const drive = codes.some((c) =>
      ["KeyW", "KeyA", "KeyD", "ArrowUp", "ArrowLeft", "ArrowRight"].includes(c),
    );
    if (drive && this.phase !== "race") {
      if (this.phase !== "countdown") {
        this.syncSkins();
        this.resetPositions();
      }
      this.beginRace();
    }
  }

  private beginRace(): void {
    this.phase = "race";
    this.acc = 0;
    this.raceTime = 0;
    this.last = -1;
    for (const c of this.racers) c.lapStamp = 0;
    this.camInit = false;
    this.emit();
  }

  private teleport(car: Racer): void {
    const gate = TRACK.checkpoints[car.lastCp];
    const s = TRACK.samples[gate];
    const lat = car.player ? -1.2 : car.lat0;
    car.x = s.x + s.tx * 5 + s.rx * lat;
    car.z = s.z + s.tz * 5 + s.rz * lat;
    car.y = s.y;
    car.yaw = Math.atan2(-s.tx, -s.tz);
    const fx = -Math.sin(car.yaw);
    const fz = -Math.cos(car.yaw);
    car.vx = fx * 18;
    car.vz = fz * 18;
    car.sIdx = gate;
    car.prevX = car.x;
    car.prevZ = car.z;
    car.teleport = true;
    car.stuck = 0;
  }

  private frame(now: number): void {
    if (this.last < 0) this.last = now;
    const frameDt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    if (this.phase === "countdown") {
      this.count -= frameDt;
      if (this.count <= 0) this.beginRace();
    }
    if (this.phase === "race") {
      this.acc += frameDt;
      let steps = 0;
      while (this.acc >= STEP && steps < MAX_STEPS) {
        this.simulate(STEP);
        this.acc -= STEP;
        steps += 1;
      }
    }
    this.present(frameDt);
  }

  private simulate(dt: number): void {
    if (!this.player.finished) this.raceTime += dt;
    for (const car of this.racers) this.stepCar(car, dt);
    for (let i = 0; i < this.sparkN; i++) {
      if (this.sparkLife[i] <= 0) continue;
      this.sparkLife[i] -= dt;
      const o = i * 3;
      this.sparkPos[o] += this.sparkVel[o] * dt;
      this.sparkPos[o + 1] += this.sparkVel[o + 1] * dt;
      this.sparkPos[o + 2] += this.sparkVel[o + 2] * dt;
      this.sparkVel[o + 1] -= 4 * dt;
      if (this.sparkLife[i] <= 0) this.sparkPos[o + 1] = -40;
    }
    this.sparkAttr.needsUpdate = true;
    this.sparkColAttr.needsUpdate = true;
  }

  private inputFor(car: Racer): { throttle: number; steer: number; drift: boolean } {
    if (this.phase !== "race" || car.finished) return { throttle: 0, steer: 0, drift: false };
    if (!car.player) return this.aiInput(car);
    const keys = this.qaKeys ?? this.keys;
    const usingQa = this.qaKeys !== null;
    let steer = 0;
    // Chase cam: A / left must increase yaw (nose left).
    if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
    if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;
    if (!usingQa && this.pad !== null) steer += this.pad;
    steer = Math.max(-1, Math.min(1, steer));
    let throttle = 0;
    if (keys.has("KeyW") || keys.has("ArrowUp")) throttle += 1;
    if (keys.has("KeyS") || keys.has("ArrowDown")) throttle -= 1;
    if (!usingQa && this.hold.gas) throttle += 1;
    if (!usingQa && this.hold.brake) throttle -= 1;
    if (
      !usingQa &&
      this.auto &&
      throttle === 0 &&
      !this.hold.brake &&
      !keys.has("KeyS") &&
      !keys.has("ArrowDown")
    ) {
      throttle = 1;
    }
    throttle = Math.max(-1, Math.min(1, throttle));
    const drift = keys.has("Space") || keys.has("ShiftLeft") || (!usingQa && this.hold.drift);
    if (drift && throttle > 0) throttle = 0.42;
    return { throttle, steer, drift };
  }

  private aiInput(car: Racer): { throttle: number; steer: number; drift: boolean } {
    const look = TRACK.samples[(car.sIdx + 12) % TRACK.samples.length];
    const dx = look.x - car.x;
    const dz = look.z - car.z;
    const len = Math.hypot(dx, dz) || 1;
    const desired = Math.atan2(-dx / len, -dz / len);
    let diff = desired - car.yaw;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    const steer = Math.max(-1, Math.min(1, diff / 0.42));
    let throttle = Math.abs(diff) > 0.38 ? 0.42 : 1;
    throttle *= car.pace;
    return { throttle, steer, drift: false };
  }

  private stepCar(car: Racer, dt: number): void {
    const input = this.inputFor(car);
    car.steer = input.steer;
    const speedNow = Math.hypot(car.vx, car.vz);
    const alongNow = car.vx * -Math.sin(car.yaw) + car.vz * -Math.cos(car.yaw);
    const forwardSign = alongNow >= 0 ? 1 : -1;
    const speedFactor = Math.max(0.25, Math.min(1, speedNow / 11)) * (1 - 0.22 * Math.min(1, speedNow / 42));
    const driftTurn = input.drift && speedNow > 8 ? 1.28 : 1;
    if (!car.finished) car.yaw += input.steer * 2.15 * speedFactor * forwardSign * driftTurn * dt;
    if (car.yaw > Math.PI) car.yaw -= Math.PI * 2;
    if (car.yaw < -Math.PI) car.yaw += Math.PI * 2;

    const fx = -Math.sin(car.yaw);
    const fz = -Math.cos(car.yaw);
    const rx = Math.cos(car.yaw);
    const rz = -Math.sin(car.yaw);
    let fs = car.vx * fx + car.vz * fz;
    let ls = car.vx * rx + car.vz * rz;
    const drifting = input.drift && Math.abs(fs) > 8 && Math.abs(input.steer) > 0.12;
    if (drifting) {
      car.drift = Math.min(1, car.drift + dt * 0.62);
      car.driftArmed = true;
    } else if (!input.drift && car.driftArmed && car.drift > 0.38) {
      car.boost = 0.45 + car.drift * 1.05;
      car.kick = 8 + car.drift * 14;
      if (car.player) {
        this.shake = Math.max(this.shake, this.reduce ? 0 : 0.32 + car.drift * 0.35);
        this.flash = "دفعة";
        this.flashT = 0.7;
        if (!this.reduce) {
          try {
            navigator.vibrate?.(16);
          } catch {
            /* ignore */
          }
        }
      }
      car.drift = 0;
      car.driftArmed = false;
    } else {
      car.drift = Math.max(0, car.drift - dt * (input.drift ? 0.25 : 0.9));
      if (!input.drift) car.driftArmed = false;
    }

    const s0 = TRACK.samples[car.sIdx];
    const lat0 = (car.x - s0.x) * s0.rx + (car.z - s0.z) * s0.rz;
    let drag = Math.abs(input.throttle) > 0.15 ? 0.26 : 0.82;
    if (Math.abs(lat0) > TRACK.halfRoad) drag += 3.4;
    ls *= Math.exp(-(car.driftArmed ? 1.25 : 8.4) * dt);
    fs *= Math.exp(-drag * dt);
    if (!car.finished) fs += input.throttle * 32 * dt;
    if (car.kick) {
      fs += car.kick;
      car.kick = 0;
    }
    const cap = car.boost > 0 ? 56 : 42;
    if (fs > cap) fs = cap;
    if (fs < -14) fs = -14;
    if (car.boost > 0) car.boost -= dt;

    car.fs = fs;
    car.vx = fx * fs + rx * ls;
    car.vz = fz * fs + rz * ls;
    if (car.finished) {
      car.vx *= Math.exp(-1.4 * dt);
      car.vz *= Math.exp(-1.4 * dt);
    }
    car.prevX = car.x;
    car.prevZ = car.z;
    car.x += car.vx * dt;
    car.z += car.vz * dt;

    car.sIdx = this.nearest(car.x, car.z, car.sIdx);
    const s = TRACK.samples[car.sIdx];
    let lat = (car.x - s.x) * s.rx + (car.z - s.z) * s.rz;
    if (Math.abs(lat) > TRACK.wall) {
      const clamped = Math.sign(lat) * TRACK.wall;
      car.x = s.x + s.rx * clamped;
      car.z = s.z + s.rz * clamped;
      fs *= 0.9;
      if ((lat > 0 && ls > 0) || (lat < 0 && ls < 0)) ls = 0;
      car.fs = fs;
      car.vx = fx * fs + rx * ls;
      car.vz = fz * fs + rz * ls;
      lat = clamped;
    }
    const ahead = TRACK.samples[(car.sIdx + 4) % TRACK.samples.length];
    const ds = Math.max(0.8, Math.hypot(ahead.x - s.x, ahead.z - s.z));
    car.pitch = -Math.atan2(ahead.y - s.y, ds);
    car.y = s.y;

    if (!car.finished && this.phase === "race" && !car.teleport) this.considerGate(car);
    car.teleport = false;

    if (!car.player && !car.finished && Math.hypot(car.vx, car.vz) < 2.2) {
      car.stuck += dt;
      if (car.stuck > 2.4) this.teleport(car);
    } else car.stuck = 0;

    if (car.player && (car.driftArmed || Math.abs(lat) > TRACK.halfRoad + 0.3)) {
      const col: [number, number, number] = car.driftArmed
        ? car.drift > 0.55
          ? [1, 0.42, 0.18]
          : [0.25, 0.9, 0.78]
        : [0.8, 0.62, 0.35];
      for (const side of [-0.75, 0.75]) {
        this.spawnSpark(car.x - fx * 1.35 + rx * side, car.y + 0.28, car.z - fz * 1.35 + rz * side, col);
      }
    }
    if (car.player) {
      const along = car.vx * s.tx + car.vz * s.tz;
      if (along < -6) this.wrongT = Math.min(2, this.wrongT + dt);
      else this.wrongT = Math.max(0, this.wrongT - dt * 2);
    }
    car.visual.brake.emissiveIntensity = input.throttle < 0 ? 3.4 : 0.55;
  }

  private nearest(x: number, z: number, hint: number): number {
    const samples = TRACK.samples;
    const n = samples.length;
    let best = Infinity;
    let idx = hint;
    for (let k = -20; k <= 20; k++) {
      const i = (hint + k + n) % n;
      const s = samples[i];
      const d = (x - s.x) ** 2 + (z - s.z) ** 2;
      if (d < best) {
        best = d;
        idx = i;
      }
    }
    return idx;
  }

  private considerGate(car: Racer): void {
    const s = TRACK.samples[TRACK.checkpoints[car.next]];
    const d0 = (car.prevX - s.x) * s.tx + (car.prevZ - s.z) * s.tz;
    const d1 = (car.x - s.x) * s.tx + (car.z - s.z) * s.tz;
    const lat = Math.abs((car.x - s.x) * s.rx + (car.z - s.z) * s.rz);
    if (lat > TRACK.wall + 3) return;
    if (d0 <= 0 && d1 > 0) {
      const id = car.next;
      car.lastCp = id;
      car.next = (id + 1) % TRACK.checkpoints.length;
      if (id === 0) {
        const lapTime = this.raceTime - car.lapStamp;
        car.lap += 1;
        if (car.player && lapTime > 2 && (this.bestLap === 0 || lapTime < this.bestLap)) {
          this.bestLap = lapTime;
          this.persist();
        }
        if (car.player) {
          this.flash = `لفة ${car.lap}`;
          this.flashT = 1.1;
        }
        car.lapStamp = this.raceTime;
        if (car.lap >= LAPS) {
          car.finished = true;
          car.finishTime = this.raceTime;
          if (car.player) {
            if (this.bestRace === 0 || this.raceTime < this.bestRace) this.bestRace = this.raceTime;
            this.persist();
            this.phase = "finish";
            this.emit();
          }
        }
      }
    } else if (d0 >= 0 && d1 < 0 && car.player) {
      this.wrongT = Math.min(2, this.wrongT + 0.35);
    }
  }

  private spawnSpark(x: number, y: number, z: number, color: [number, number, number]): void {
    const i = this.sparkI;
    this.sparkI = (i + 1) % this.sparkN;
    const o = i * 3;
    this.sparkPos[o] = x;
    this.sparkPos[o + 1] = y;
    this.sparkPos[o + 2] = z;
    this.sparkVel[o] = (Math.random() - 0.5) * 2.4;
    this.sparkVel[o + 1] = 1.2 + Math.random() * 2;
    this.sparkVel[o + 2] = (Math.random() - 0.5) * 2.4;
    this.sparkLife[i] = 0.28 + Math.random() * 0.22;
    this.sparkCol[o] = color[0];
    this.sparkCol[o + 1] = color[1];
    this.sparkCol[o + 2] = color[2];
  }

  private progress(c: Racer): number {
    return c.lap * TRACK.length + TRACK.samples[c.sIdx].dist;
  }

  private ranked(): Racer[] {
    return [...this.racers].sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      if (a.finished) return -1;
      if (b.finished) return 1;
      return this.progress(b) - this.progress(a);
    });
  }

  private results(): RacerResult[] {
    return this.ranked().map((c, i) => ({
      name: c.name,
      player: c.player,
      place: i + 1,
      time: c.finished ? c.finishTime : null,
    }));
  }

  private present(frameDt: number): void {
    for (const car of this.racers) {
      const g = car.visual.root;
      g.visible = this.phase !== "garage" || car.player;
      g.position.set(car.x, car.y, car.z);
      g.rotation.order = "YXZ";
      g.rotation.y = car.yaw + Math.PI;
      g.rotation.x = car.pitch;
      g.rotation.z = this.reduce ? 0 : -car.steer * 0.1 * Math.min(1, Math.abs(car.fs) / 18);
      for (const w of car.visual.wheels) w.rotation.x += car.fs * frameDt * 1.5;
      for (const p of car.visual.steerPivots) p.rotation.y = -car.steer * 0.34;
    }
    this.updateCamera(frameDt);
    this.paintHud(frameDt);
    this.drawMap();
    this.audio.update(this.player.fs, this.player.driftArmed, this.player.boost > 0);
    this.renderer.render(this.scene, this.camera);
  }

  private updateCamera(frameDt: number): void {
    const p = this.player;
    if (this.phase === "garage") {
      const ang = performance.now() * 0.00035;
      this.camX = p.x + Math.sin(ang) * 8.2;
      this.camY = p.y + 2.35;
      this.camZ = p.z + Math.cos(ang) * 8.2;
      this.camera.position.set(this.camX, this.camY, this.camZ);
      this.camera.lookAt(p.x, p.y + 0.7, p.z);
      this.camInit = false;
      return;
    }
    const back = this.view === 0 ? 7.6 : 3.5;
    const up = this.view === 0 ? 2.7 : 1.65;
    const lookA = this.view === 0 ? 6.4 : 12;
    const fx = -Math.sin(p.yaw);
    const fz = -Math.cos(p.yaw);
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    let dx = p.x - fx * back + rx * p.steer * 0.4;
    let dy = p.y + up;
    let dz = p.z - fz * back + rz * p.steer * 0.4;
    if (this.shake > 0) {
      this.shake *= Math.exp(-3.2 * frameDt);
      dx += (Math.random() - 0.5) * this.shake;
      dy += (Math.random() - 0.5) * this.shake * 0.35;
    }
    const tx = p.x + fx * lookA;
    const ty = p.y + 0.9;
    const tz = p.z + fz * lookA;
    if (!this.camInit) {
      this.camX = dx;
      this.camY = dy;
      this.camZ = dz;
      this.lookX = tx;
      this.lookY = ty;
      this.lookZ = tz;
      this.camInit = true;
    } else {
      const k = 1 - Math.exp(-4.5 * frameDt);
      this.camX += (dx - this.camX) * k;
      this.camY += (dy - this.camY) * k;
      this.camZ += (dz - this.camZ) * k;
      this.lookX += (tx - this.lookX) * k;
      this.lookY += (ty - this.lookY) * k;
      this.lookZ += (tz - this.lookZ) * k;
    }
    this.camera.position.set(this.camX, this.camY, this.camZ);
    this.camera.lookAt(this.lookX, this.lookY, this.lookZ);
    const fov = this.reduce ? 68 : 68 + Math.min(14, Math.abs(p.fs) * 0.22) + (p.boost > 0 ? 6 : 0);
    if (Math.abs(this.camera.fov - fov) > 0.25) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
  }

  private paintHud(frameDt: number): void {
    const p = this.player;
    const hud = this.hud;
    hud.speed.textContent = String(Math.round(Math.hypot(p.vx, p.vz) * 3.6));
    const showLap = p.finished ? LAPS : Math.min(LAPS, p.lap + 1);
    hud.lap.textContent = `${showLap}/${LAPS}`;
    const place = this.ranked().findIndex((c) => c.player) + 1;
    hud.pos.textContent = `${place}/${this.racers.length}`;
    const running = this.phase === "race" || this.phase === "paused" || this.phase === "finish";
    hud.lapTime.textContent = formatTime(running ? Math.max(0, this.raceTime - p.lapStamp) : 0);
    hud.raceTime.textContent = formatTime(this.raceTime);
    hud.best.textContent = formatTime(this.bestLap);
    hud.drift.style.transform = `scaleX(${Math.max(0, Math.min(1, p.drift))})`;
    hud.wrong.style.opacity = this.wrongT > 0.35 ? "1" : "0";
    hud.boost.style.opacity = p.boost > 0 ? "1" : "0";
    if (this.flashT > 0) this.flashT -= frameDt;
    hud.flash.style.opacity = this.flashT > 0 ? "1" : "0";
    hud.flash.textContent = this.flash;
    hud.count.textContent = String(Math.max(1, Math.ceil(this.count)));
    hud.countWrap.style.display = this.phase === "countdown" ? "grid" : "none";
  }

  private drawMap(): void {
    const canvas = this.opts.map;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (w < 2 || h < 2) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const bw = Math.floor(w * dpr);
    const bh = Math.floor(h * dpr);
    if (canvas.width !== bw || canvas.height !== bh) {
      canvas.width = bw;
      canvas.height = bh;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (!this.mapBounds) {
      let minX = Infinity;
      let maxX = -Infinity;
      let minZ = Infinity;
      let maxZ = -Infinity;
      for (const s of TRACK.samples) {
        minX = Math.min(minX, s.x);
        maxX = Math.max(maxX, s.x);
        minZ = Math.min(minZ, s.z);
        maxZ = Math.max(maxZ, s.z);
      }
      this.mapBounds = { minX, maxX, minZ, maxZ };
    }
    const b = this.mapBounds;
    const sc = Math.min((w - 16) / (b.maxX - b.minX), (h - 16) / (b.maxZ - b.minZ));
    const ox = (w - (b.maxX - b.minX) * sc) / 2;
    const oy = (h - (b.maxZ - b.minZ) * sc) / 2;
    const px = (x: number) => ox + (x - b.minX) * sc;
    const py = (z: number) => oy + (z - b.minZ) * sc;
    ctx.beginPath();
    TRACK.samples.forEach((s, i) => {
      const x = px(s.x);
      const y = py(s.z);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.strokeStyle = "#3ee0c5";
    ctx.lineWidth = 2;
    ctx.stroke();
    for (const car of this.racers) {
      if (this.phase === "garage" && !car.player) continue;
      ctx.fillStyle = car.player ? "#e8c27a" : "#f4efe6";
      ctx.beginPath();
      ctx.arc(px(car.x), py(car.z), car.player ? 3.4 : 2.3, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    if (window.__controlsTest === this.probe) delete window.__controlsTest;
    for (const car of this.racers) disposeCar(car.visual);
    disposeCarGeometries();
    this.world.dispose();
    this.renderer.dispose();
    this.audio.dispose();
  }
}
