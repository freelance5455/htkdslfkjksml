import * as THREE from "three";
import { initTerrain, bridgeHeightAt, bridgeLocal, sampleTerrain, newSample, waterAt } from "./terrain";
import { ChunkManager, FarTerrain } from "./chunks";
import { makeTerrainMat, makeVegMat, makeStructMat, shared, waterUniforms, fallUniforms, makeWaterMat, makeWaterfallMat } from "./materials";
import { makeSky, skyAt, newSkyState } from "./sky";
import { buildStructures, StructuresResult, Interactable, LORE } from "./structures";
import { WaterSystem } from "./water";
import { buildProceduralSprites, loadCustomSprites, SpriteSet, Dir } from "./sprites";
import { Cave } from "./cave";
import { CAVES, LOCATIONS, WORLD_HALF } from "./worldData";
import { Collider, queryStatic, resolveCollisions } from "./physics";
import { ZombieManager, DropManager, ZWorld } from "./zombies";
import { Inventory, ITEMS, ItemId, Slot, HOT } from "./items";
import { buildSwordTexture, buildSlashTexture } from "./zombieSprites";
import { sfx, setSound } from "./sfx";

export interface InvState {
  slots: (Slot | null)[];
  selected: number;
}

export type Quality = "baixa" | "media" | "alta";
export interface Settings {
  sensitivity: number;
  invertY: boolean;
  quality: Quality;
  dayLength: number; // seconds per full day
  showFps: boolean;
  sound?: boolean;
}
export interface UIState {
  interact: string | null;
  hour: number;
  region: string;
  discovered: number;
  totalLoc: number;
  crystals: number;
  inCave: boolean;
  stamina: number;
  fps: number;
  panorama: string | null;
  running: boolean;
  swimming: boolean;
  px: number;
  pz: number;
  yaw: number;
  facing: number;
  hp: number;
  maxHp: number;
  zombiesNear: number;
}
export interface GameCallbacks {
  onState(s: UIState): void;
  onToast(msg: string): void;
  onDialog(title: string, text: string): void;
  onFade(on: boolean): void;
  onToggleMap(): void;
  onInventory?(s: InvState): void;
  onHurt?(): void;
  onToggleInventory?(): void;
}

const QUALITY: Record<Quality, { vres: number; radius: number; grass: number; density: number; shadows: boolean; fog: number }> = {
  baixa: { vres: 210, radius: 2, grass: 0, density: 0.55, shadows: false, fog: 480 },
  media: { vres: 280, radius: 3, grass: 1, density: 1, shadows: false, fog: 620 },
  alta: { vres: 380, radius: 4, grass: 1, density: 1.35, shadows: true, fog: 780 },
};

// Hand-picked pixel-art palettes are authored directly in display space
THREE.ColorManagement.enabled = false;

const SAVE_KEY = "terras-ametista-save-v1";
interface SaveData {
  discovered: string[];
  collected: string[];
  opened: string[];
  crystals: number;
  pos?: [number, number, number];
  hour?: number;
  inv?: (Slot | null)[];
  hp?: number;
  selected?: number;
  rest?: [number, number, number];
}

const DEFAULT_SPAWN: [number, number] = [62, 21];

export class Game {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  canvas: HTMLCanvasElement;
  cb: GameCallbacks;
  settings: Settings;

  input = { mx: 0, my: 0, run: false, jump: false, lookDX: 0, lookDY: 0, zoom: 0, attack: false };
  private keys = new Set<string>();

  private worldGroup = new THREE.Group();
  private chunks: ChunkManager;
  private far: FarTerrain;
  private structures: StructuresResult;
  private water: WaterSystem;
  private sky: ReturnType<typeof makeSky>;
  private skyS = newSkyState();
  private hemi: THREE.HemisphereLight;
  private sun: THREE.DirectionalLight;
  private playerLight: THREE.PointLight;
  private fireLight: THREE.PointLight;
  private mats: { terrain: THREE.MeshLambertMaterial; veg: THREE.MeshLambertMaterial; struct: THREE.MeshLambertMaterial };
  private caveMats: { rock: THREE.Material; glow: THREE.Material; water: THREE.Material; fall: THREE.Material };

  private sprites: SpriteSet;
  private playerMesh: THREE.Mesh;
  private playerMat: THREE.MeshBasicMaterial;
  private shadowBlob: THREE.Mesh;

  player = {
    pos: new THREE.Vector3(),
    vel: new THREE.Vector3(),
    facing: Math.PI,
    grounded: true,
    stamina: 100,
    exhausted: false,
    swimming: false,
    wading: false,
    running: false,
    anim: 0,
  };
  cam = { yaw: 0, pitch: 0.38, dist: 7, curDist: 7, target: new THREE.Vector3() };
  hour = 9;
  private elapsed = 0;
  private raf = 0;
  private last = 0;
  private running = false;

  private cave: Cave | null = null;
  private caveIdx = -1;
  private caveReturn = new THREE.Vector3();
  private caveReturnYaw = 0;
  private panorama: { name: string } | null = null;
  private busy = false;

  private save: SaveData;
  private discovered: Set<string>;
  private collected: Set<string>;
  private opened: Set<string>;

  private nearInteract: Interactable | null = null;
  private timers = { interact: 0, discover: 0, ui: 0, save: 0, fps: 0, light: 0 };
  private frames = 0;
  private fps = 60;
  private region = "";
  private colList: Collider[] = [];
  private smp = newSample();
  private lightLevel = 1;
  private currentLightSpot: { x: number; y: number; z: number; color: number; night: boolean } | null = null;

  // ---- combat / inventory (added) ----
  inv = new Inventory();
  selected = 0;
  hp = 100;
  maxHp = 100;
  private dead = false;
  private hurtT = 0;
  private invulnT = 0;
  private sinceHurt = 99;
  private kb = new THREE.Vector2();
  private swingT = 0;
  private swingWeapon = false;
  private hitPending = false;
  private attackCd = 0;
  private spawnT = 3;
  private groanT = 5;
  private restPos: THREE.Vector3 | null = null;
  private zombies = new ZombieManager();
  private drops = new DropManager();
  private swordPivot = new THREE.Group();
  private swordArm = new THREE.Group();
  private swordMat!: THREE.MeshBasicMaterial;
  private slash!: THREE.Mesh;
  private zWorld!: ZWorld;
  private zCol: Collider[] = [];

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks, settings: Settings) {
    this.canvas = canvas;
    this.cb = cb;
    this.settings = { ...settings };
    initTerrain();

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance", stencil: false });
    this.renderer.setPixelRatio(1);
    this.renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
    this.renderer.shadowMap.type = THREE.BasicShadowMap;
    this.camera = new THREE.PerspectiveCamera(62, 1, 0.15, 1500);
    this.scene.fog = new THREE.Fog(0xb6d6ee, 80, 620);

    this.mats = { terrain: makeTerrainMat(), veg: makeVegMat(), struct: makeStructMat() };
    this.caveMats = {
      rock: this.mats.struct,
      glow: new THREE.MeshBasicMaterial({ vertexColors: true }),
      water: makeWaterMat(),
      fall: makeWaterfallMat(),
    };

    this.sky = makeSky();
    this.scene.add(this.sky.mesh);
    this.hemi = new THREE.HemisphereLight(0xbfd8ff, 0x4a4030, 0.8);
    this.sun = new THREE.DirectionalLight(0xffffff, 1.5);
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -38; sc.right = 38; sc.top = 38; sc.bottom = -38; sc.near = 1; sc.far = 220;
    this.sun.shadow.bias = -0.0015;
    this.playerLight = new THREE.PointLight(0xffb070, 0, 18, 1.2);
    this.fireLight = new THREE.PointLight(0xff9040, 0, 26, 1.2);
    this.scene.add(this.hemi, this.sun, this.sun.target, this.playerLight, this.fireLight);

    this.scene.add(this.worldGroup);
    this.far = new FarTerrain(this.mats.terrain);
    this.worldGroup.add(this.far.mesh);
    this.chunks = new ChunkManager(this.worldGroup, { terrain: this.mats.terrain, veg: this.mats.veg });
    this.structures = buildStructures(this.mats.struct, this.mats.veg);
    this.worldGroup.add(this.structures.group);
    this.water = new WaterSystem(this.mats.veg, this.mats.struct);
    this.worldGroup.add(this.water.group);

    // player
    this.sprites = buildProceduralSprites();
    loadCustomSprites(this.sprites).catch(() => {});
    const pg = new THREE.PlaneGeometry(1, 1);
    pg.translate(0, 0.5, 0);
    this.playerMat = new THREE.MeshBasicMaterial({ map: this.sprites.idle.back[0].tex, alphaTest: 0.5, side: THREE.DoubleSide, fog: true });
    this.playerMesh = new THREE.Mesh(pg, this.playerMat);
    this.playerMesh.renderOrder = 1;
    this.scene.add(this.playerMesh);
    const cv = document.createElement("canvas");
    cv.width = cv.height = 16;
    const cx = cv.getContext("2d")!;
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
      const d = Math.hypot(x - 7.5, y - 7.5) / 8;
      if (d < 1) { cx.fillStyle = `rgba(0,0,0,${d < 0.6 ? 0.45 : 0.25})`; cx.fillRect(x, y, 1, 1); }
    }
    const st = new THREE.CanvasTexture(cv);
    st.magFilter = THREE.NearestFilter;
    st.minFilter = THREE.NearestFilter;
    const sg = new THREE.PlaneGeometry(1.3, 0.9);
    sg.rotateX(-Math.PI / 2);
    this.shadowBlob = new THREE.Mesh(sg, new THREE.MeshBasicMaterial({ map: st, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }));
    this.scene.add(this.shadowBlob);

    // save data
    this.save = this.loadSave();
    this.discovered = new Set(this.save.discovered);
    this.collected = new Set(this.save.collected);
    this.opened = new Set(this.save.opened);
    if (this.save.pos) this.player.pos.set(...this.save.pos);
    else this.player.pos.set(DEFAULT_SPAWN[0], 0, DEFAULT_SPAWN[1]);
    if (typeof this.save.hour === "number") this.hour = this.save.hour;
    this.cam.yaw = 0.6;

    // ---- combat / inventory setup (added) ----
    if (this.save.inv) this.inv.load(this.save.inv);
    else this.giveStarterKit();
    if (typeof this.save.hp === "number") this.hp = Math.max(20, Math.min(this.maxHp, this.save.hp));
    if (typeof this.save.selected === "number") this.selected = Math.max(0, Math.min(HOT - 1, this.save.selected));
    if (this.save.rest) this.restPos = new THREE.Vector3(...this.save.rest);
    this.scene.add(this.zombies.group, this.drops.group);
    const sw = buildSwordTexture();
    const swG = new THREE.PlaneGeometry(sw.w / 24, sw.h / 24);
    swG.translate(0, (sw.h / 24) * 0.5 - (sw.h - 21) / 24, 0); // grip at origin
    this.swordMat = new THREE.MeshBasicMaterial({ map: sw.tex, alphaTest: 0.5, side: THREE.DoubleSide, fog: true });
    const swordMesh = new THREE.Mesh(swG, this.swordMat);
    swordMesh.renderOrder = 2;
    this.swordArm.add(swordMesh);
    this.swordPivot.add(this.swordArm);
    const slG = new THREE.PlaneGeometry(2.4, 2.4);
    this.slash = new THREE.Mesh(slG, new THREE.MeshBasicMaterial({ map: buildSlashTexture(), transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: true }));
    this.slash.renderOrder = 6;
    this.slash.visible = false;
    this.swordPivot.add(this.slash);
    this.scene.add(this.swordPivot);
    this.zWorld = {
      ground: (x, z, y) => this.groundAt(x, z, y),
      water: (x, z) => this.waterLevel(x, z),
      collide: (p, r) => {
        if (this.cave) {
          this.cave.resolve(p, r);
          return;
        }
        this.zCol.length = 0;
        this.chunks.collidersNear(p.x, p.z, this.zCol);
        queryStatic(p.x, p.z, this.zCol);
        resolveCollisions(p, r, this.zCol);
      },
    };
    setSound(this.settings.sound !== false);
    setTimeout(() => this.emitInventory(), 0);

    this.applySettings(this.settings, true);
    this.chunks.update(this.player.pos.x, this.player.pos.z, 1e9);
    this.far.setHidden(new Set(this.chunks.chunks.keys()));
    this.chunks.changed = false;
    this.player.pos.y = this.groundAt(this.player.pos.x, this.player.pos.z, 1e9);
    this.cam.target.copy(this.player.pos).add(new THREE.Vector3(0, 1.5, 0));

    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    this.onResize();
  }

  // ---------------- lifecycle ----------------
  start() {
    this.running = true;
    this.last = performance.now();
    const loop = (t: number) => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (t - this.last) / 1000);
      this.last = t;
      this.update(dt);
      this.renderer.render(this.scene, this.camera);
    };
    this.raf = requestAnimationFrame(loop);
  }

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.writeSave();
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.chunks.clearAll();
    this.cave?.dispose();
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
    this.renderer.dispose();
  }

  get minimap() {
    return this.far.mapCanvas;
  }
  get discoveredSet() {
    return this.discovered;
  }

  applySettings(s: Settings, initial = false) {
    const prevQ = this.settings.quality;
    this.settings = { ...s };
    setSound(s.sound !== false);
    const q = QUALITY[s.quality];
    this.chunks.radius = q.radius;
    this.chunks.grassRadius = q.grass;
    const shadowsChanged = this.chunks.shadows !== q.shadows;
    this.chunks.shadows = q.shadows;
    this.renderer.shadowMap.enabled = q.shadows;
    this.sun.castShadow = q.shadows;
    if (shadowsChanged && !initial) {
      Object.values(this.mats).forEach((m) => (m.needsUpdate = true));
    }
    if (this.chunks.grassDensity !== q.density || (!initial && (prevQ !== s.quality))) {
      this.chunks.grassDensity = q.density;
      if (!initial) this.chunks.clearAll();
    }
    this.onResize();
  }

  private onResize = () => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    const q = QUALITY[this.settings.quality];
    const scale = Math.max(1, h / q.vres);
    const rw = Math.max(64, Math.round(w / scale)), rh = Math.max(64, Math.round(h / scale));
    this.renderer.setSize(rw, rh, false);
    this.camera.aspect = rw / rh;
    this.camera.updateProjectionMatrix();
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if ((e.target as HTMLElement)?.tagName === "INPUT") return;
    this.keys.add(k);
    if (k === " ") { this.input.jump = true; e.preventDefault(); }
    if (k === "e") this.interact();
    if (k === "m") this.cb.onToggleMap();
    // combat / inventory keys (added)
    if (k === "f" || k === "j") this.input.attack = true;
    if (k === "q") this.useSlot(this.selected);
    if (k === "i" || k === "tab") { e.preventDefault(); this.cb.onToggleInventory?.(); }
    if (k >= "1" && k <= "8") this.selectSlot(parseInt(k) - 1, false);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    this.keys.delete(k);
    if (k === "f" || k === "j") this.input.attack = false;
  };

  // ---------------- save ----------------
  private loadSave(): SaveData {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) return JSON.parse(raw);
    } catch { /* ignore */ }
    return { discovered: [], collected: [], opened: [], crystals: 0 };
  }
  private writeSave() {
    try {
      const pos: [number, number, number] = this.cave ? [this.caveReturn.x, this.caveReturn.y, this.caveReturn.z] : [this.player.pos.x, this.player.pos.y, this.player.pos.z];
      const d: SaveData = {
        discovered: [...this.discovered], collected: [...this.collected], opened: [...this.opened],
        crystals: this.save.crystals, pos, hour: this.hour,
        inv: this.inv.serialize(), hp: Math.round(this.hp), selected: this.selected,
        rest: this.restPos ? [this.restPos.x, this.restPos.y, this.restPos.z] : undefined,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(d));
    } catch { /* ignore */ }
  }
  resetProgress() {
    this.save = { discovered: [], collected: [], opened: [], crystals: 0 };
    this.discovered.clear();
    this.collected.clear();
    this.opened.clear();
    if (this.cave) this.exitCave(true);
    this.player.pos.set(DEFAULT_SPAWN[0], 0, DEFAULT_SPAWN[1]);
    this.player.pos.y = this.groundAt(this.player.pos.x, this.player.pos.z, 1e9);
    this.giveStarterKit();
    this.hp = this.maxHp;
    this.restPos = null;
    this.zombies.clear();
    this.drops.clear();
    this.emitInventory();
    this.writeSave();
  }
  setHour(h: number) {
    this.hour = ((h % 24) + 24) % 24;
  }

  // ---------------- world queries ----------------
  private groundAt(x: number, z: number, y: number) {
    if (this.cave) return this.cave.groundAt(x, z);
    let g = this.chunks.ground(x, z);
    const b = bridgeHeightAt(x, z);
    if (b > -1e8 && y > b - 1.3) g = Math.max(g, b);
    return g;
  }
  private waterLevel(x: number, z: number) {
    if (this.cave) return this.cave.waterAt(x, z);
    return waterAt(x, z);
  }
  private steepness(x: number, z: number) {
    const c = this.chunks;
    const gx = (c.ground(x + 0.8, z) - c.ground(x - 0.8, z)) / 1.6;
    const gz = (c.ground(x, z + 0.8) - c.ground(x, z - 0.8)) / 1.6;
    return Math.sqrt(gx * gx + gz * gz);
  }

  // ---------------- main update ----------------
  private update(dt: number) {
    this.elapsed += dt;
    shared.uTime.value = this.elapsed;
    if (!this.cave) this.hour = (this.hour + (dt * 24) / this.settings.dayLength) % 24;

    this.updatePlayer(dt);
    this.updateCamera(dt);
    if (!this.cave) {
      this.chunks.update(this.player.pos.x, this.player.pos.z, 5);
      if (this.chunks.changed) {
        this.chunks.changed = false;
        this.far.setHidden(new Set(this.chunks.chunks.keys()));
      }
    }
    this.updateEnv(dt);
    this.updateCombat(dt);
    this.updateSprite(dt);

    const T = this.timers;
    T.interact -= dt; T.discover -= dt; T.ui -= dt; T.save -= dt; T.fps += dt;
    this.frames++;
    if (T.fps >= 1) { this.fps = Math.round(this.frames / T.fps); this.frames = 0; T.fps = 0; }
    if (T.interact <= 0) { T.interact = 0.15; this.findInteract(); }
    if (T.discover <= 0) { T.discover = 0.5; this.checkDiscovery(); }
    if (T.save <= 0) { T.save = 10; this.writeSave(); }
    if (T.ui <= 0) {
      T.ui = 0.12;
      this.cb.onState({
        interact: this.panorama ? null : this.nearInteract?.label ?? null,
        hour: this.hour,
        region: this.region,
        discovered: this.discovered.size,
        totalLoc: LOCATIONS.length,
        crystals: this.save.crystals,
        inCave: !!this.cave,
        stamina: this.player.stamina,
        fps: this.fps,
        panorama: this.panorama?.name ?? null,
        running: this.player.running,
        swimming: this.player.swimming,
        px: this.player.pos.x,
        pz: this.player.pos.z,
        yaw: this.cam.yaw,
        facing: this.player.facing,
        hp: this.hp,
        maxHp: this.maxHp,
        zombiesNear: this.zombies.aliveCount,
      });
    }
    this.input.jump = false;
  }

  private updatePlayer(dt: number) {
    const P = this.player;
    const inp = this.input;
    let mx = inp.mx, my = inp.my;
    const K = this.keys;
    if (K.has("w") || K.has("arrowup")) my += 1;
    if (K.has("s") || K.has("arrowdown")) my -= 1;
    if (K.has("a") || K.has("arrowleft")) mx -= 1;
    if (K.has("d") || K.has("arrowright")) mx += 1;
    let len = Math.hypot(mx, my);
    if (len > 1) { mx /= len; my /= len; len = 1; }
    if (this.panorama && (len > 0.2 || inp.jump)) this.panorama = null;
    if (this.busy || this.panorama || this.dead) { mx = 0; my = 0; len = 0; }

    const yaw = this.cam.yaw;
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    const rx = Math.cos(yaw), rz = -Math.sin(yaw);
    const dx = fx * my + rx * mx, dz = fz * my + rz * mx;
    const moving = len > 0.08;

    const wantRun = (inp.run || K.has("shift")) && moving && !P.swimming;
    if (P.exhausted && P.stamina > 30) P.exhausted = false;
    P.running = wantRun && !P.exhausted;
    if (P.running) {
      P.stamina -= 13 * dt;
      if (P.stamina <= 0) { P.stamina = 0; P.exhausted = true; }
    } else P.stamina = Math.min(100, P.stamina + 20 * dt);

    const speed = (P.running ? 8.6 : 4.3) * Math.min(1, len * 1.15) * (P.swimming ? 0.5 : P.wading ? 0.75 : 1);
    const acc = P.grounded || P.swimming ? 12 : 3.5;
    const k = 1 - Math.exp(-acc * dt);
    P.vel.x += (dx / (len || 1) * speed - P.vel.x) * k;
    P.vel.z += (dz / (len || 1) * speed - P.vel.z) * k;
    if (moving) {
      const tf = Math.atan2(dx, dz);
      let d = tf - P.facing;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      P.facing += d * (1 - Math.exp(-14 * dt));
    }

    const pos = P.pos;
    let nx = pos.x + (P.vel.x + this.kb.x) * dt, nz = pos.z + (P.vel.z + this.kb.y) * dt;
    this.kb.multiplyScalar(Math.exp(-8 * dt));
    let platform = -1e9;
    if (this.cave) {
      const tmp = { x: nx, y: pos.y, z: nz };
      this.cave.resolve(tmp, 0.35);
      platform = resolveCollisions(tmp, 0.35, this.cave.colliders);
      this.cave.resolve(tmp, 0.35);
      nx = tmp.x; nz = tmp.z;
    } else {
      // slope limit
      if (P.grounded && (nx !== pos.x || nz !== pos.z)) {
        const gc = this.groundAt(pos.x, pos.z, pos.y);
        const blocked = (x: number, z: number) => {
          const gn = this.groundAt(x, z, pos.y);
          if (gn - gc < 0.02) return false;
          if (bridgeHeightAt(x, z) > -1e8) return false;
          if (this.steepness(x, z) < 1.15) return false;
          return sampleTerrain(x, z, this.smp).road < 0.4;
        };
        if (blocked(nx, nz)) {
          if (!blocked(nx, pos.z)) nz = pos.z;
          else if (!blocked(pos.x, nz)) nx = pos.x;
          else { nx = pos.x; nz = pos.z; P.vel.x *= 0.3; P.vel.z *= 0.3; }
        }
      }
      // bridge rails
      const onB = bridgeHeightAt(pos.x, pos.z);
      if (onB > -1e8 && Math.abs(pos.y - onB) < 0.7) {
        const br = bridgeLocal.b!;
        const rxl = nx - br.x, rzl = nz - br.z;
        const s = rxl * br.dx + rzl * br.dz;
        const a = -rxl * br.dz + rzl * br.dx;
        if (Math.abs(s) < br.half - 1.5 && Math.abs(a) > br.width * 0.5 - 0.35) {
          const lim = (br.width * 0.5 - 0.35) * Math.sign(a);
          nx = br.x + br.dx * s - br.dz * lim;
          nz = br.z + br.dz * s + br.dx * lim;
        }
      }
      const tmp = { x: nx, y: pos.y, z: nz };
      this.colList.length = 0;
      this.chunks.collidersNear(nx, nz, this.colList);
      queryStatic(nx, nz, this.colList);
      platform = resolveCollisions(tmp, 0.35, this.colList);
      nx = Math.max(-WORLD_HALF + 30, Math.min(WORLD_HALF - 30, tmp.x));
      nz = Math.max(-WORLD_HALF + 30, Math.min(WORLD_HALF - 30, tmp.z));
    }
    pos.x = nx;
    pos.z = nz;

    let ground = Math.max(this.groundAt(nx, nz, pos.y), platform);
    const wl = this.waterLevel(nx, nz);
    P.swimming = wl > ground + 1.05;
    P.wading = !P.swimming && wl > ground + 0.3;
    if (P.swimming) ground = Math.max(ground, wl - 1.05);

    if (inp.jump && (P.grounded || P.swimming) && !this.busy && !this.dead) {
      P.vel.y = P.swimming ? 4.5 : 7.6;
      P.grounded = false;
    }
    P.vel.y -= 22 * dt;
    pos.y += P.vel.y * dt;
    if (pos.y <= ground) {
      pos.y = ground;
      P.vel.y = 0;
      P.grounded = true;
    } else if (P.grounded && P.vel.y <= 0 && pos.y - ground < 0.7) {
      pos.y = ground;
      P.vel.y = 0;
    } else P.grounded = false;
  }

  private updateCamera(dt: number) {
    const C = this.cam;
    const sens = this.settings.sensitivity;
    C.yaw -= this.input.lookDX * 0.0052 * sens;
    C.pitch += this.input.lookDY * 0.0042 * sens * (this.settings.invertY ? -1 : 1);
    this.input.lookDX = 0;
    this.input.lookDY = 0;
    if (this.input.zoom) {
      C.dist = Math.max(3.5, Math.min(16, C.dist + this.input.zoom));
      this.input.zoom = 0;
    }
    C.pitch = Math.max(-0.2, Math.min(1.3, C.pitch));
    let dist = C.dist;
    let pitch = C.pitch;
    const fog = this.scene.fog as THREE.Fog;
    const q = QUALITY[this.settings.quality];
    if (this.panorama) {
      C.yaw += dt * 0.12;
      dist = 30;
      pitch = 0.2;
      fog.far += (1300 - fog.far) * (1 - Math.exp(-dt * 1.5));
    } else if (!this.cave) {
      fog.far += (q.fog - fog.far) * (1 - Math.exp(-dt * 2));
      fog.near = fog.far * 0.12;
    }
    C.curDist += (dist - C.curDist) * (1 - Math.exp(-dt * (this.panorama ? 1.2 : 8)));
    const p = this.player.pos;
    const tgt = new THREE.Vector3(p.x, p.y + 1.45, p.z);
    C.target.lerp(tgt, 1 - Math.exp(-dt * 14));
    const cp = Math.cos(pitch);
    const ox = Math.sin(C.yaw) * cp, oy = Math.sin(pitch), oz = Math.cos(C.yaw) * cp;
    let d = C.curDist;
    if (this.cave) {
      for (let s = 0.4; s < d; s += 0.25) {
        if (this.cave.solid(C.target.x + ox * s, C.target.z + oz * s)) { d = Math.max(0.8, s - 0.4); break; }
      }
    }
    const cam = this.camera.position;
    cam.set(C.target.x + ox * d, C.target.y + oy * d, C.target.z + oz * d);
    if (this.cave) cam.y = Math.min(cam.y, 6.8);
    else {
      const g = this.chunks.ground(cam.x, cam.z) + 0.6;
      if (cam.y < g) cam.y = g;
      const wl = waterAt(cam.x, cam.z);
      if (wl > -1e8 && cam.y < wl + 0.4) cam.y = wl + 0.4;
    }
    this.camera.lookAt(C.target);
    this.sky.mesh.position.copy(cam);
  }

  private updateEnv(dt: number) {
    const S = skyAt(this.hour, this.skyS);
    const U = this.sky.uniforms;
    const fog = this.scene.fog as THREE.Fog;
    const P = this.player.pos;
    if (this.cave) {
      fog.color.setRGB(0.01, 0.01, 0.02);
      this.hemi.color.setRGB(0.35, 0.4, 0.6);
      this.hemi.groundColor.setRGB(0.1, 0.08, 0.1);
      this.hemi.intensity = 1.1;
      this.sun.intensity = 0;
      this.playerLight.intensity = 7;
      waterUniforms.uSky.value.setRGB(0.1, 0.12, 0.2);
      waterUniforms.uDeep.value.setRGB(0.03, 0.08, 0.14);
      waterUniforms.uShallow.value.setRGB(0.1, 0.25, 0.35);
      waterUniforms.uDay.value = 0.2;
      fallUniforms.uLight.value = 0.6;
      this.lightLevel = 0.85;
    } else {
      U.uTop.value.copy(S.top);
      U.uHor.value.copy(S.hor);
      U.uSunDir.value.copy(S.sunDir);
      U.uSunCol.value.copy(S.sun);
      U.uCloud.value.copy(S.cloud);
      U.uNight.value = S.night;
      fog.color.copy(S.hor).lerp(S.top, 0.15);
      this.hemi.color.copy(S.top).lerp(new THREE.Color(1, 1, 1), 0.45);
      this.hemi.groundColor.setRGB(0.32, 0.28, 0.2).multiplyScalar(0.5 + S.day * 0.5);
      this.hemi.intensity = S.hemi * 2.5;
      this.sun.color.copy(S.sun);
      this.sun.intensity = S.sunI * 2.25;
      this.sun.position.set(P.x + S.lightDir.x * 90, P.y + S.lightDir.y * 90, P.z + S.lightDir.z * 90);
      this.sun.target.position.copy(P);
      this.playerLight.intensity = S.night * 4;
      waterUniforms.uSky.value.copy(S.hor).lerp(S.top, 0.35);
      waterUniforms.uDeep.value.setRGB(0.1, 0.29, 0.37).lerp(new THREE.Color(0.03, 0.06, 0.12), S.night);
      waterUniforms.uShallow.value.setRGB(0.24, 0.53, 0.55).lerp(new THREE.Color(0.06, 0.12, 0.2), S.night);
      waterUniforms.uSunDir.value.copy(S.sunDir);
      waterUniforms.uSunCol.value.copy(S.sun);
      waterUniforms.uDay.value = S.day;
      fallUniforms.uLight.value = 0.35 + 0.65 * S.day;
      this.structures.windowMat.color.setRGB(0.28, 0.3, 0.38).lerp(new THREE.Color(1.15, 1.1, 1), S.night);
      this.lightLevel = Math.min(1.08, 0.42 + S.sunI * 0.48 + S.night * 0.15);
      this.water.update(this.elapsed, P, S.night, (x, z) => this.chunks.ground(x, z), S.day);
    }
    this.playerLight.position.set(P.x, P.y + 2.2, P.z);

    // nearest light spot (campfire / crystals)
    this.timers.light -= dt;
    if (this.timers.light <= 0) {
      this.timers.light = 0.4;
      const list = this.cave ? this.cave.lights.map((l) => ({ ...l, night: false })) : this.structures.lights;
      let best: { x: number; y: number; z: number; color: number; night: boolean } | null = null;
      let bd = this.cave ? 30 : 45;
      for (const l of list) {
        if (l.night && S.night < 0.05 && !this.cave) continue;
        const d = Math.hypot(l.x - P.x, l.z - P.z);
        if (d < bd) { bd = d; best = l; }
      }
      this.currentLightSpot = best;
      if (best) {
        this.fireLight.position.set(best.x, best.y, best.z);
        this.fireLight.color.setHex(best.color);
      }
    }
    const L = this.currentLightSpot;
    const flick = 0.85 + Math.sin(this.elapsed * 13) * 0.08 + Math.sin(this.elapsed * 7.3) * 0.07;
    this.fireLight.intensity = L ? (L.night ? S.night * 8 * flick : this.cave ? 7 : 2.5 + S.night * 4) : 0;
    for (const f of this.structures.fires) {
      const s = 0.8 + Math.sin(this.elapsed * 11 + f.x) * 0.15 + Math.sin(this.elapsed * 17 + f.z) * 0.1;
      f.mesh.scale.set(1, s, 1);
      f.mesh.rotation.y = this.elapsed * 2;
    }
  }

  private updateSprite(dt: number) {
    const P = this.player;
    const hs = Math.hypot(P.vel.x, P.vel.z);
    const moving = hs > 0.6;
    const camAng = Math.atan2(-Math.sin(this.cam.yaw), -Math.cos(this.cam.yaw));
    let diff = P.facing - camAng;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    let dir: Dir = "back";
    let flip = 1;
    const ad = Math.abs(diff);
    if (ad < Math.PI * 0.27) dir = "back";
    else if (ad > Math.PI * 0.73) dir = "front";
    else { dir = "side"; flip = diff < 0 ? 1 : -1; }
    const set = moving ? this.sprites.walk[dir] : this.sprites.idle[dir];
    P.anim += dt * (moving ? hs * 0.95 + 1.5 : 1.4);
    let idx = Math.floor(P.anim) % set.length;
    if (!P.grounded && !P.swimming) idx = Math.min(1, set.length - 1);
    const fr = set[idx];
    if (this.playerMat.map !== fr.tex) {
      this.playerMat.map = fr.tex;
    }
    const h = 2.05;
    this.playerMesh.scale.set(h * fr.aspect * flip, h, 1);
    this.playerMesh.position.copy(P.pos);
    if (P.swimming) this.playerMesh.position.y += 0.1 + Math.sin(this.elapsed * 3) * 0.05;
    this.playerMesh.rotation.y = this.cam.yaw;
    this.playerMat.color.setScalar(this.lightLevel);
    const g = this.groundAt(P.pos.x, P.pos.z, P.pos.y);
    this.shadowBlob.position.set(P.pos.x, g + 0.04, P.pos.z);
    const hk = Math.max(0, 1 - (P.pos.y - g) / 4);
    this.shadowBlob.visible = !P.swimming;
    this.shadowBlob.scale.setScalar(0.6 + hk * 0.4);

    // ---- hurt flash + held sword (added) ----
    if (this.hurtT > 0) this.playerMat.color.setRGB(1.5, 0.45, 0.45);
    else if (this.invulnT > 0 && Math.floor(this.elapsed * 16) % 2 === 0) this.playerMat.color.setScalar(this.lightLevel * 1.3);
    const held = this.inv.get(this.selected);
    const hasSword = !!held && ITEMS[held.id].kind === "weapon";
    this.swordPivot.visible = !P.swimming && !this.dead && (hasSword || this.swingT > 0);
    this.swordArm.visible = hasSword;
    this.swordPivot.position.copy(this.playerMesh.position);
    this.swordPivot.rotation.y = this.cam.yaw;
    const sign = dir === "back" ? 1 : dir === "front" ? -1 : -flip;
    const side = dir === "back" ? 0.5 : dir === "front" ? -0.5 : flip * 0.32;
    const bobY = moving ? Math.abs(Math.sin(P.anim * Math.PI)) * 0.05 : 0;
    let ang = -0.35 * sign, lift = 0;
    if (this.swingT > 0) {
      const t = Math.min(1, this.swingT / 0.26);
      const e = 1 - (1 - t) * (1 - t);
      ang = (-1.1 + e * 3.3) * sign;
      lift = Math.sin(t * Math.PI) * 0.25;
    }
    this.swordArm.position.set(side - (this.swingT > 0 ? Math.sin(Math.min(1, this.swingT / 0.26) * Math.PI) * side * 0.8 : 0), 0.78 + bobY + lift, dir === "front" ? 0.18 : 0.12);
    this.swordArm.rotation.z = ang;
    this.swordMat.color.setScalar(this.lightLevel);
    // slash arc
    if (this.swingT > 0.04 && this.swingT < 0.3) {
      this.slash.visible = true;
      const t = (this.swingT - 0.04) / 0.26;
      this.slash.position.set(0, 1.0, 0.35);
      this.slash.rotation.z = (sign > 0 ? 0.4 : -0.4) + (1 - t) * 0.6 * sign;
      this.slash.scale.set(sign > 0 ? -1 : 1, 1, 1);
      (this.slash.material as THREE.MeshBasicMaterial).opacity = 1 - t;
      this.slash.scale.multiplyScalar(this.swingWeapon ? 1 : 0.6);
    } else this.slash.visible = false;
  }

  // =============== COMBAT / INVENTORY (added) ===============
  private giveStarterKit() {
    this.inv.load(undefined);
    this.inv.slots[0] = { id: "espada", n: 1 };
    this.inv.slots[1] = { id: "maca", n: 3 };
    this.inv.slots[2] = { id: "atadura", n: 1 };
    this.selected = 0;
  }

  emitInventory() {
    this.cb.onInventory?.({ slots: this.inv.serialize(), selected: this.selected });
  }

  selectSlot(i: number, useIfSelected = true) {
    if (i < 0 || i >= HOT) return;
    if (useIfSelected && this.selected === i) {
      const s = this.inv.get(i);
      if (s && ITEMS[s.id].kind === "food") this.useSlot(i);
      return;
    }
    this.selected = i;
    this.emitInventory();
  }

  useSlot(i: number) {
    const s = this.inv.get(i);
    if (!s || this.dead) return;
    const def = ITEMS[s.id];
    if (def.kind === "food") {
      if (this.hp >= this.maxHp) { this.cb.onToast("Sua vida já está cheia."); return; }
      const before = this.hp;
      this.hp = Math.min(this.maxHp, this.hp + (def.heal ?? 0));
      this.inv.remove(i, 1);
      sfx.eat();
      this.cb.onToast(`${def.name}: +${Math.round(this.hp - before)} ❤`);
    } else if (def.kind === "weapon") {
      if (i >= HOT) {
        this.inv.move(i, this.selected);
        this.cb.onToast(`${def.name} equipada.`);
      } else this.selected = i;
    } else {
      this.cb.onToast(`${def.name} é um material.`);
      return;
    }
    this.emitInventory();
  }

  moveItem(from: number, to: number) {
    this.inv.move(from, to);
    this.emitInventory();
  }

  dropSlot(i: number) {
    const s = this.inv.get(i);
    if (!s) return;
    const P = this.player.pos;
    this.drops.add(s.id, s.n, P.x + Math.sin(P.x) * 0.2 + Math.sin(this.player.facing) * 1.2, P.y, P.z + Math.cos(this.player.facing) * 1.2, 2.5);
    this.inv.slots[i] = null;
    this.emitInventory();
  }

  craftBandage() {
    if (this.inv.count("pano") < 2) return false;
    this.inv.removeId("pano", 2);
    const left = this.inv.add("atadura", 1);
    if (left > 0) {
      const P = this.player.pos;
      this.drops.add("atadura", 1, P.x, P.y, P.z, 2);
    }
    sfx.pickup();
    this.cb.onToast("Você criou uma Atadura.");
    this.emitInventory();
    return true;
  }

  attack() {
    if (this.dead || this.busy || this.panorama || this.attackCd > 0 || this.player.swimming) return;
    const held = this.inv.get(this.selected);
    this.swingWeapon = !!held && ITEMS[held.id].kind === "weapon";
    this.attackCd = this.swingWeapon ? 0.48 : 0.42;
    this.swingT = 0.0001;
    this.hitPending = true;
    this.player.stamina = Math.max(0, this.player.stamina - 4);
    // aim assist: turn toward the closest zombie in reach
    const z = this.zombies.nearest(this.player.pos, 3.6);
    if (z) this.player.facing = Math.atan2(z.pos.x - this.player.pos.x, z.pos.z - this.player.pos.z);
    sfx.swing();
  }

  private pickup(id: ItemId, n: number) {
    const left = this.inv.add(id, n);
    if (left === n) {
      return false;
    }
    sfx.pickup();
    this.cb.onToast(`+${n - left} ${ITEMS[id].name}`);
    this.emitInventory();
    return left === 0;
  }

  private dropLoot(p: THREE.Vector3) {
    const r = Math.random;
    if (r() < 0.5) this.drops.add("carne", 1, p.x, p.y, p.z);
    if (r() < 0.4) this.drops.add("pano", 1, p.x, p.y, p.z);
    if (r() < 0.25) this.drops.add("osso", 1, p.x, p.y, p.z);
    if (r() < 0.14) this.drops.add(r() < 0.5 ? "maca" : "frutas", 1, p.x, p.y, p.z);
    if (r() < 0.07) this.drops.add("pocao", 1, p.x, p.y, p.z);
  }

  private onZombieAttack(dmg: number, fx: number, fz: number) {
    if (this.dead || this.invulnT > 0 || this.busy) return;
    this.hp -= dmg;
    this.hurtT = 0.22;
    this.invulnT = 0.6;
    this.sinceHurt = 0;
    const P = this.player.pos;
    const dx = P.x - fx, dz = P.z - fz, d = Math.hypot(dx, dz) || 1;
    this.kb.set((dx / d) * 8, (dz / d) * 8);
    sfx.hurt();
    this.cb.onHurt?.();
    if (this.hp <= 0) this.die();
  }

  private die() {
    this.hp = 0;
    this.dead = true;
    this.swingT = 0;
    setTimeout(() => {
      this.cb.onFade(true);
      setTimeout(() => {
        if (this.cave) this.exitCave(true);
        this.zombies.clear();
        this.drops.clear();
        const R = this.restPos;
        if (R) this.player.pos.copy(R);
        else this.player.pos.set(DEFAULT_SPAWN[0], 0, DEFAULT_SPAWN[1]);
        this.chunks.update(this.player.pos.x, this.player.pos.z, 1e9);
        this.player.pos.y = this.groundAt(this.player.pos.x, this.player.pos.z, 1e9);
        this.player.vel.set(0, 0, 0);
        this.kb.set(0, 0);
        this.cam.target.set(this.player.pos.x, this.player.pos.y + 1.45, this.player.pos.z);
        this.hp = this.maxHp * 0.6;
        this.player.stamina = 100;
        this.dead = false;
        this.spawnT = 8;
        this.invulnT = 2;
        this.writeSave();
        setTimeout(() => {
          this.cb.onFade(false);
          this.cb.onDialog("Você desmaiou...", "Você acorda em um lugar seguro, ferido mas vivo. Seus itens continuam na mochila. Cuidado com os zumbis, principalmente à noite!");
        }, 300);
      }, 450);
    }, 700);
  }

  private trySpawnZombie() {
    const P = this.player.pos;
    const night = this.skyS.night > 0.5;
    for (let t = 0; t < 6; t++) {
      const a = Math.random() * Math.PI * 2;
      const d = 36 + Math.random() * 26;
      const x = P.x + Math.sin(a) * d, z = P.z + Math.cos(a) * d;
      if (Math.abs(x) > WORLD_HALF - 60 || Math.abs(z) > WORLD_HALF - 60) continue;
      // don't spawn in the camera's direct view too close
      if (Math.hypot(x - 85, z - 20) < 60) continue; // village is a safe zone
      const s = sampleTerrain(x, z, this.smp);
      if (s.water > s.h - 0.3 || s.pad > 0.05 || s.h > 95) continue;
      if (!night && s.forest < 0.35 && s.mount < 0.35) continue;
      if (this.steepness(x, z) > 1.0) continue;
      const g = this.groundAt(x, z, 1e9);
      this.zombies.spawn(x, g, z, night && Math.random() < 0.25);
      return;
    }
  }

  private spawnCaveZombies(large: boolean) {
    const c = this.cave!;
    const n = large ? 4 : 2;
    let placed = 0;
    for (let t = 0; t < 300 && placed < n; t++) {
      const i = Math.floor(Math.random() * c.W), j = Math.floor(Math.random() * c.H);
      const x = (i + 0.5) * 2.5, z = (j + 0.5) * 2.5;
      if (c.cellAt(x, z) !== 0) continue;
      if (Math.hypot(x - c.spawn.x, z - c.spawn.z) < 14) continue;
      this.zombies.spawn(x, 0, z, Math.random() < 0.4);
      placed++;
    }
  }

  private updateCombat(dt: number) {
    this.hurtT -= dt;
    this.invulnT -= dt;
    this.attackCd -= dt;
    this.sinceHurt += dt;
    if (this.input.attack) this.attack();
    // regen out of combat
    if (!this.dead && this.sinceHurt > 8 && this.hp < this.maxHp) this.hp = Math.min(this.maxHp, this.hp + 1.2 * dt);

    if (this.swingT > 0) {
      this.swingT += dt;
      if (this.hitPending && this.swingT >= 0.11) {
        this.hitPending = false;
        const held = this.inv.get(this.selected);
        const dmg = this.swingWeapon && held ? ITEMS[held.id].damage ?? 10 : 8;
        const range = this.swingWeapon ? 2.4 : 1.6;
        const res = this.zombies.hit(this.player.pos, this.player.facing, range, dmg);
        if (res.hits > 0) sfx.hit();
        for (const k of res.killed) {
          sfx.zombieDie();
          this.dropLoot(k);
        }
      }
      if (this.swingT > 0.32) this.swingT = 0;
    }

    // spawning (surface only)
    if (!this.cave) {
      this.spawnT -= dt;
      if (this.spawnT <= 0) {
        this.spawnT = 2.5;
        const night = this.skyS.night > 0.5;
        const qk = this.settings.quality === "baixa" ? 0.6 : this.settings.quality === "alta" ? 1.25 : 1;
        const target = Math.round((night ? 7 : 3) * qk);
        this.zombies.despawnFar(this.player.pos, 95);
        if (this.zombies.aliveCount < target && !this.panorama) this.trySpawnZombie();
      }
    }

    this.zombies.update(dt, {
      player: this.player.pos,
      playerAlive: !this.dead && !this.busy,
      playerSwimming: this.player.swimming,
      camYaw: this.cam.yaw,
      light: this.lightLevel,
      night: this.cave ? 1 : this.skyS.night,
      world: this.zWorld,
      onAttack: (d, x, z) => this.onZombieAttack(d, x, z),
    });
    this.drops.update(dt, this.player.pos, this.lightLevel, (x, z, y) => this.groundAt(x, z, y), (id, n) => this.pickup(id, n));

    this.groanT -= dt;
    if (this.groanT <= 0) {
      this.groanT = 4 + Math.random() * 6;
      if (this.zombies.nearest(this.player.pos, 14)) sfx.groan();
    }
  }

  // ---------------- interactions ----------------
  private findInteract() {
    const list = this.cave ? this.cave.interactables : this.structures.interactables;
    const P = this.player.pos;
    let best: Interactable | null = null, bd = 1e9;
    for (const it of list) {
      const d = Math.hypot(it.x - P.x, it.z - P.z);
      if (d < it.r && d < bd && Math.abs(P.y - it.y) < 4.5) { bd = d; best = it; }
    }
    this.nearInteract = best;
  }

  interact() {
    if (this.panorama) { this.panorama = null; return; }
    const it = this.nearInteract;
    if (!it || this.busy) return;
    switch (it.kind) {
      case "rest": {
        this.fadeAction(() => {
          const night = this.hour >= 19 || this.hour < 6;
          this.hour = night ? 7 : (this.hour + 3) % 24;
          this.player.stamina = 100;
          this.hp = this.maxHp;
          this.restPos = this.player.pos.clone();
          this.cb.onToast(night ? "Você descansou até o amanhecer." : "Você descansou por algumas horas.");
        });
        break;
      }
      case "cave":
        this.fadeAction(() => this.enterCave(it.data as number));
        break;
      case "exit":
        this.fadeAction(() => this.exitCave());
        break;
      case "view":
        this.panorama = { name: it.data as string };
        this.cb.onToast(`${it.data}`);
        break;
      case "lore": {
        let key = it.data as string;
        if (key === "temple") {
          if (this.collected.has("temple")) key = "templeDone";
          else {
            this.collected.add("temple");
            this.save.crystals += 2;
          }
        }
        const [t, txt] = LORE[key];
        this.cb.onDialog(t, txt);
        break;
      }
      case "crystal": {
        if (!this.cave) break;
        const m = this.cave.collectibles.get(it.id);
        m?.removeFromParent();
        this.cave.collectibles.delete(it.id);
        this.cave.interactables = this.cave.interactables.filter((x) => x !== it);
        this.collected.add(it.id);
        this.save.crystals += 1;
        this.cb.onToast("+1 Cristal de Ametista");
        this.writeSave();
        break;
      }
      case "secret": {
        if (!this.cave) break;
        this.cave.openSecret();
        this.opened.add(it.id);
        this.cave.interactables = this.cave.interactables.filter((x) => x !== it);
        this.cb.onToast("A parede desmoronou! Uma passagem secreta se abriu.");
        this.writeSave();
        break;
      }
      case "chest": {
        if (!this.cave) break;
        this.collected.add(it.id);
        this.save.crystals += 3;
        if (this.inv.add("pocao", 2) > 0) this.drops.add("pocao", 1, this.player.pos.x, this.player.pos.y, this.player.pos.z);
        this.emitInventory();
        this.cave.interactables = this.cave.interactables.filter((x) => x !== it);
        this.cb.onDialog("Baú antigo", "Dentro do baú empoeirado você encontra 3 cristais raros e um mapa desgastado das montanhas.");
        this.writeSave();
        break;
      }
    }
    this.nearInteract = null;
  }

  private fadeAction(fn: () => void) {
    this.busy = true;
    this.cb.onFade(true);
    setTimeout(() => {
      fn();
      setTimeout(() => {
        this.cb.onFade(false);
        this.busy = false;
      }, 250);
    }, 380);
  }

  private enterCave(idx: number) {
    const def = CAVES[idx];
    const ent = this.structures.caveEntrances.find((c) => c.idx === idx)!;
    this.caveReturn.set(ent.x, ent.y, ent.z);
    this.caveReturnYaw = Math.atan2(-ent.fx, -ent.fz);
    this.cave = new Cave(def, idx, this.caveMats, this.collected, this.opened);
    this.caveIdx = idx;
    this.scene.add(this.cave.group);
    this.worldGroup.visible = false;
    this.sky.mesh.visible = false;
    this.scene.background = new THREE.Color(0x020203);
    const fog = this.scene.fog as THREE.Fog;
    fog.near = 6;
    fog.far = 40;
    this.player.pos.set(this.cave.spawn.x, 0, this.cave.spawn.z);
    this.player.vel.set(0, 0, 0);
    this.player.facing = Math.PI;
    this.cam.yaw = 0;
    this.cam.pitch = 0.3;
    this.cam.target.set(this.player.pos.x, 1.45, this.player.pos.z);
    this.region = def.name;
    this.discover(def.name);
    this.zombies.clear();
    this.drops.clear();
    this.spawnCaveZombies(def.large);
  }

  private exitCave(silent = false) {
    if (!this.cave) return;
    this.cave.dispose();
    this.cave = null;
    this.caveIdx = -1;
    this.zombies.clear();
    this.drops.clear();
    this.spawnT = 4;
    this.worldGroup.visible = true;
    this.sky.mesh.visible = true;
    this.scene.background = null;
    this.player.pos.copy(this.caveReturn);
    this.player.vel.set(0, 0, 0);
    this.player.pos.y = this.groundAt(this.player.pos.x, this.player.pos.z, 1e9);
    this.cam.yaw = this.caveReturnYaw;
    this.player.facing = Math.atan2(-Math.sin(this.cam.yaw), -Math.cos(this.cam.yaw));
    this.cam.target.set(this.player.pos.x, this.player.pos.y + 1.45, this.player.pos.z);
    const fog = this.scene.fog as THREE.Fog;
    fog.far = QUALITY[this.settings.quality].fog;
    fog.near = fog.far * 0.12;
    if (!silent) this.cb.onToast("Você voltou à superfície.");
  }

  private discover(name: string) {
    if (this.discovered.has(name)) return;
    this.discovered.add(name);
    this.cb.onToast(`Novo local descoberto: ${name}`);
    this.writeSave();
  }

  private checkDiscovery() {
    if (this.cave) { this.region = CAVES[this.caveIdx]?.name ?? ""; return; }
    const P = this.player.pos;
    let reg = "", br = 1e9;
    for (const l of LOCATIONS) {
      const d = Math.hypot(l.x - P.x, l.z - P.z);
      if (d < l.r) {
        this.discover(l.name);
        if (l.r < br) { br = l.r; reg = l.name; }
      }
    }
    if (!reg) {
      const s = sampleTerrain(P.x, P.z, this.smp);
      if (s.h > 70 || s.mount > 0.6) reg = "Montanhas";
      else if (s.plateau > 0.5) reg = "Planalto Norte";
      else if (s.forest > 0.55) reg = "Floresta Densa";
      else if (s.light > 0.5) reg = "Bosque Aberto";
      else if (s.road > 0.5) reg = "Estrada";
      else if (s.water > s.h) reg = "Rio";
      else reg = "Campos Verdes";
    }
    this.region = reg;
  }
}
