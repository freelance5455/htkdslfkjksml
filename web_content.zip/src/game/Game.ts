import * as THREE from 'three';
import { Arena, ARENA_R } from './arena';
import { Fighter, DEFS, newCtl, type Ctl } from './fighter';
import { CHAINS, KNOCK_DUR, type Move } from './anim';
import type { FighterId } from './character';
import { AI, type Difficulty } from './ai';
import { Particles, Flashes } from './fx';
import { input, consume, clearInput } from './input';
import { sfx } from './audio';
import { glowTexture } from './arena';

export type Mode = 'menu' | 'intro' | 'fight' | 'roundEnd' | 'matchEnd';

export interface HudState {
  mode: Mode;
  round: number;
  time: number;
  hp: [number, number];
  stam: [number, number];
  spec: [number, number];
  wins: [number, number];
  combo: { who: number; n: number };
  player: number;
  noStam: boolean;
  counter: boolean;
}

export interface Settings {
  quality: 0 | 1 | 2;
  sound: boolean;
  shake: boolean;
  vibrate: boolean;
}

export interface GameCallbacks {
  onHud: (h: HudState) => void;
  onBanner: (text: string, sub?: string, kind?: string) => void;
  onPopup: (text: string, kind: string) => void;
  onMatchEnd: (r: { playerWon: boolean; wins: [number, number] }) => void;
  onError: (msg: string) => void;
}

const DODGE_COST = 18;
const DODGE_DUR = 0.42;
const ROUND_TIME = 60;
const WINS_NEEDED = 2;
const TAU = Math.PI * 2;

const lerpAngle = (a: number, b: number, t: number) => {
  let d = ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI;
  return a + d * t;
};
const turnToward = (cur: number, target: number, maxStep: number) => {
  const d = ((target - cur + Math.PI) % TAU + TAU) % TAU - Math.PI;
  return cur + Math.max(-maxStep, Math.min(maxStep, d));
};

const v1 = new THREE.Vector3();
const v2 = new THREE.Vector3();

export class Game {
  canvas: HTMLCanvasElement;
  cb: GameCallbacks;
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(55, 16 / 9, 0.1, 140);
  arena!: Arena;
  fighters: Fighter[] = [];
  sparks!: Particles;
  dust!: Particles;
  flashes!: Flashes;
  settings: Settings = { quality: 1, sound: true, shake: true, vibrate: true };

  mode: Mode = 'menu';
  modeT = 0;
  paused = false;
  playerIdx = 0;
  ai = new AI('normal');
  round = 1;
  wins: [number, number] = [0, 0];
  timeLeft = ROUND_TIME;
  timeScale = 1;
  slowT = 0;
  hitStop = 0;
  t = 0;
  lastTs = 0;
  raf = 0;
  disposed = false;
  shake = 0;
  fovKick = 0;
  camYaw = 0;
  camSnap = true;
  look = new THREE.Vector3();
  menuAngle = 0.6;
  menuFocus: FighterId | null = null;
  menuCenter = new THREE.Vector3();
  menuRadius = 6.5;
  hudT = 0;
  introBanner = 0;
  roundWinner = -1;
  comboShow = { who: -1, n: 0, t: 0 };
  diff: Difficulty = 'normal';
  matchPlayer: FighterId = 'leon';
  frameAcc = 0;
  frameN = 0;
  perfT = 0;
  lowFpsT = 0;
  ready = false;
  size = { w: 1, h: 1, pr: 1 };
  lostCtx = false;

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks, settings?: Partial<Settings>) {
    this.canvas = canvas;
    this.cb = cb;
    Object.assign(this.settings, settings);
    try {
      this.init();
      this.ready = true;
      (window as any).__game = this;
    } catch (e) {
      console.error(e);
      cb.onError('WebGL could not be initialised on this device.');
    }
  }

  private init() {
    const q = this.settings.quality;
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas, antialias: q >= 1, powerPreference: 'high-performance', alpha: false, stencil: false,
    });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.setClearColor(0x05070a);

    this.canvas.addEventListener('webglcontextlost', this.onLost as EventListener);
    this.canvas.addEventListener('webglcontextrestored', this.onRestored as EventListener);

    this.arena = new Arena(this.scene, this.renderer);
    this.arena.thunderCb = () => sfx.thunder();

    const glow = glowTexture();
    this.sparks = new Particles(this.scene, 260, 0.16, true, glow, 0.8);
    this.dust = new Particles(this.scene, 80, 0.7, false, glow, 1.5);
    this.flashes = new Flashes(this.scene, glow);

    for (const id of ['leon', 'ada'] as FighterId[]) {
      const f = new Fighter(id);
      this.scene.add(f.rig.root);
      this.fighters.push(f);
    }
    this.resize();
    this.applyQuality();
    this.setMenu(null);
    window.addEventListener('resize', this.resize);
    document.addEventListener('visibilitychange', this.onVis);
    this.lastTs = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  private onLost = (e: Event) => { e.preventDefault(); this.lostCtx = true; };
  private onRestored = () => { this.lostCtx = false; };
  private onVis = () => { if (document.hidden && this.mode === 'fight') this.paused = true; };

  // ------------------------------------------------------------------ settings
  setSettings(s: Partial<Settings>) {
    Object.assign(this.settings, s);
    sfx.setEnabled(this.settings.sound);
    input.vibrate = this.settings.vibrate;
    if (this.ready) this.applyQuality();
  }

  resize = () => {
    if (!this.renderer) return;
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.size.w = w; this.size.h = h;
    this.applyQuality();
  };

  applyQuality() {
    const q = this.settings.quality;
    const { w, h } = this.size;
    const cap = [1, 1.5, 2][q];
    const maxPix = [0.75e6, 1.5e6, 2.8e6][q];
    const pr = Math.max(0.6, Math.min(window.devicePixelRatio || 1, cap, Math.sqrt(maxPix / (w * h))));
    this.size.pr = pr;
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.updateFov();
    this.arena.setQuality(q, w, h, pr);
    this.renderer.shadowMap.enabled = true;
    this.sparks.points.visible = true;
  }

  updateFov() {
    const a = this.camera.aspect;
    this.camera.fov = (a < 1.4 ? 70 : 54) + this.fovKick;
    this.camera.updateProjectionMatrix();
  }

  // ------------------------------------------------------------------ menu / match control
  setMenu(focus: FighterId | null) {
    this.menuFocus = focus;
    if (this.mode !== 'menu') {
      this.mode = 'menu';
    }
    const [l, a] = this.fighters;
    l.reset(-1.4, 0, Math.PI / 2);
    a.reset(1.4, 0, -Math.PI / 2);
    l.rig.root.visible = a.rig.root.visible = true;
    if (focus) {
      const f = focus === 'leon' ? l : a;
      const other = focus === 'leon' ? a : l;
      f.reset(0, 0, 0.15);
      other.rig.root.visible = false;
    }
    this.timeScale = 1; this.slowT = 0; this.hitStop = 0;
    clearInput();
  }

  startMatch(player: FighterId, diff: Difficulty) {
    sfx.init();
    sfx.setEnabled(this.settings.sound);
    this.matchPlayer = player;
    this.diff = diff;
    this.playerIdx = player === 'leon' ? 0 : 1;
    this.ai = new AI(diff);
    this.wins = [0, 0];
    this.round = 1;
    this.paused = false;
    this.startRound();
  }

  restart() {
    this.startMatch(this.matchPlayer, this.diff);
  }

  quitToMenu() {
    this.paused = false;
    this.setMenu(this.menuFocus);
    this.mode = 'menu';
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (p) clearInput();
  }

  private startRound() {
    const p = this.fighters[this.playerIdx];
    const o = this.fighters[1 - this.playerIdx];
    p.reset(0, -1.7, 0);
    o.reset(0, 1.7, Math.PI);
    for (const f of this.fighters) f.dmgMul = 1;
    o.dmgMul = this.ai.dmgMul;
    this.mode = 'intro';
    this.modeT = 0;
    this.introBanner = 0;
    this.timeLeft = ROUND_TIME;
    this.timeScale = 1; this.slowT = 0; this.hitStop = 0;
    this.camSnap = true;
    this.roundWinner = -1;
    this.comboShow = { who: -1, n: 0, t: 0 };
    clearInput();
    this.cb.onBanner(`ROUND ${this.round}`, `${this.wins[0] + this.wins[1] === 0 ? 'GET READY' : ''}`, 'round');
    sfx.bell();
  }

  private endRound(winner: Fighter | null, reason: 'ko' | 'time') {
    if (this.mode !== 'fight') return;
    this.mode = 'roundEnd';
    this.modeT = 0;
    const wi = winner ? this.fighters.indexOf(winner) : -1;
    this.roundWinner = wi;
    if (wi >= 0) this.wins[wi]++;
    for (const f of this.fighters) {
      f.buffer = null;
      if (f !== winner && f.state !== 'dead' && wi >= 0) { f.state = 'dead'; f.st = 0; f.move = null; f.normaliseSpin(); }
    }
    if (reason === 'ko') { this.slowT = 1.5; sfx.ko(); }
    this.cb.onBanner(reason === 'ko' ? 'K.O.' : wi < 0 ? 'DRAW' : 'TIME UP', winner ? `${winner.def.name} WINS THE ROUND` : 'NO WINNER', 'ko');
  }

  // ------------------------------------------------------------------ main loop
  private frame = (ts: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    if (this.lostCtx) return;
    const real = Math.min(0.05, (ts - this.lastTs) / 1000);
    this.lastTs = ts;
    if (real <= 0) return;
    this.perf(real);
    try {
      this.tick(real);
      this.renderer.render(this.scene, this.camera);
    } catch (e) {
      console.error(e);
    }
  };

  private perf(real: number) {
    this.perfT += real;
    this.frameAcc += real; this.frameN++;
    if (this.perfT > 2) {
      const avg = this.frameAcc / this.frameN;
      if (avg > 1 / 26 && this.settings.quality > 0 && !this.paused) this.lowFpsT++;
      else this.lowFpsT = 0;
      if (this.lowFpsT >= 2) {
        this.lowFpsT = 0;
        this.settings.quality = (this.settings.quality - 1) as 0 | 1 | 2;
        this.applyQuality();
      }
      this.perfT = 0; this.frameAcc = 0; this.frameN = 0;
    }
  }

  private tick(real: number) {
    this.t += real;
    const paused = this.paused;
    if (!paused) {
      if (this.slowT > 0) {
        this.slowT -= real;
        this.timeScale = 0.3;
        if (this.slowT <= 0) this.timeScale = 1;
      }
      let dt = real * this.timeScale;
      let hs = false;
      if (this.hitStop > 0) { this.hitStop -= real; dt = 0; hs = true; }
      this.simulate(dt, real, hs);
      this.sparks.update(real * (hs ? 0.15 : this.timeScale));
      this.dust.update(real * this.timeScale);
      this.flashes.update(real);
    }
    this.updateCamera(real);
    this.arena.update(paused ? 0 : real, this.camera.position);
    this.hudT -= real;
    if (this.hudT <= 0) { this.hudT = 0.05; this.emitHud(); }
  }

  private simulate(dt: number, real: number, hs: boolean) {
    const [leon, ada] = this.fighters;
    if (this.mode === 'menu') {
      for (const f of this.fighters) f.animate(dt, this.t, false);
      return;
    }
    this.modeT += real;
    const p = this.fighters[this.playerIdx];
    const o = this.fighters[1 - this.playerIdx];

    // controls
    let pc: Ctl = newCtl();
    let oc: Ctl = newCtl();
    if (this.mode === 'fight') {
      pc = this.playerCtl(p, o);
      oc = this.ai.update(dt, o, p, true);
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        const a = p.hp, b = o.hp;
        this.endRound(a === b ? null : a > b ? p : o, 'time');
      }
    } else {
      // discard presses
      this.playerCtl(p, o);
    }

    if (this.mode === 'intro') {
      if (this.introBanner === 0 && this.modeT > 1.7) {
        this.introBanner = 1;
        this.cb.onBanner('FIGHT!', '', 'fight');
        sfx.click();
      }
      if (this.modeT > 2.5) this.mode = 'fight';
    }

    const live = this.mode === 'fight' || this.mode === 'roundEnd';
    this.updateFighter(p, o, this.mode === 'fight' ? pc : null, dt, live);
    this.updateFighter(o, p, this.mode === 'fight' ? oc : null, dt, live);

    // separation + arena bounds + props
    if (dt > 0) {
      const dx = o.pos.x - p.pos.x, dz = o.pos.z - p.pos.z;
      const d = Math.hypot(dx, dz) || 0.001;
      const min = 0.85;
      if (d < min) {
        const push = (min - d) * 0.5;
        p.pos.x -= (dx / d) * push; p.pos.z -= (dz / d) * push;
        o.pos.x += (dx / d) * push; o.pos.z += (dz / d) * push;
      }
      for (const f of this.fighters) {
        const r = Math.hypot(f.pos.x, f.pos.z);
        if (r > ARENA_R) {
          f.pos.x *= ARENA_R / r; f.pos.z *= ARENA_R / r;
          // bounce knock velocity off the invisible wall
          const nx = f.pos.x / ARENA_R, nz = f.pos.z / ARENA_R;
          const dot = f.kvel.x * nx + f.kvel.z * nz;
          if (dot > 0) { f.kvel.x -= 1.4 * dot * nx; f.kvel.z -= 1.4 * dot * nz; }
        }
        this.propCollide(f);
      }
    }

    // round end flow
    if (this.mode === 'roundEnd') {
      const wi = this.roundWinner;
      if (wi >= 0 && this.modeT > 1.5) {
        const w = this.fighters[wi];
        if (w.state === 'idle' || w.state === 'block') { w.state = 'win'; w.st = 0; }
      }
      if (this.modeT > 4.2) {
        const champ = this.wins.findIndex((w) => w >= WINS_NEEDED);
        if (champ >= 0) {
          this.mode = 'matchEnd';
          this.modeT = 0;
          this.cb.onMatchEnd({ playerWon: champ === this.playerIdx, wins: [...this.wins] as [number, number] });
        } else {
          this.round++;
          this.startRound();
        }
      }
    }
    if (this.mode === 'matchEnd') {
      const wi = this.wins[0] > this.wins[1] ? 0 : 1;
      const w = this.fighters[wi];
      if (w.state === 'idle' || w.state === 'block') { w.state = 'win'; w.st = 0; }
    }
    void leon; void ada;
    for (const f of this.fighters) f.animate(dt, this.t, hs);
  }

  // ------------------------------------------------------------------ input -> ctl
  private playerCtl(p: Fighter, o: Fighter): Ctl {
    const c = newCtl();
    let jx = input.jx + input.kx, jy = input.jy + input.ky;
    const m = Math.hypot(jx, jy);
    if (m > 1) { jx /= m; jy /= m; }
    const fx = Math.sin(this.camYaw), fz = Math.cos(this.camYaw);
    const rx = -fz, rz = fx;
    c.mx = fx * -jy + rx * jx;
    c.mz = fz * -jy + rz * jx;
    const joyMag = Math.hypot(input.jx, input.jy);
    const dist = Math.hypot(o.pos.x - p.pos.x, o.pos.z - p.pos.z);
    c.run = joyMag > 0.88 || (Math.hypot(input.kx, input.ky) > 0 && dist > 4 && input.ky < 0);
    c.block = input.block || input.keyBlock;
    c.punch = consume('punch');
    c.heavy = consume('heavy');
    c.kick = consume('kick');
    c.special = consume('special');
    c.dodge = consume('dodge');
    return c;
  }

  // ------------------------------------------------------------------ fighter logic
  private startMove(f: Fighter, m: Move, btn: string, n: number) {
    f.state = 'attack';
    f.st = 0;
    f.move = m;
    f.moveT = 0;
    f.hitDone = false;
    f.landed = false;
    f.atkId++;
    f.chainBtn = btn;
    f.chainN = n;
    f.chainT = 0;
    f.buffer = null;
    f.stamina -= m.cost;
    f.stamDelay = 0.7;
    if (Math.abs(f.cur.bs) > 5.5) f.cur.bs = 0;
    if (Math.abs(f.cur.bx) > 5.5) f.cur.bx = 0;
    if (m.special) { f.special = 0; sfx.special(); this.popup(f, `${m.name.toUpperCase()}`, 'special'); }
    sfx.whoosh(!!m.heavy);
  }

  private startDodge(f: Fighter, ctl: Ctl | null, nx: number, nz: number) {
    let dx = -nx, dz = -nz;
    if (ctl) {
      const m = Math.hypot(ctl.mx, ctl.mz);
      if (m > 0.3) { dx = ctl.mx / m; dz = ctl.mz / m; }
    }
    f.dodgeDir.set(dx, 0, dz);
    const fx = Math.sin(f.yaw), fz = Math.cos(f.yaw);
    f.dodgeLz = dx * fx + dz * fz;
    f.dodgeLx = dx * fz + dz * -fx;
    f.state = 'dodge';
    f.st = 0;
    f.invuln = 0.3;
    f.stamina -= DODGE_COST;
    f.stamDelay = 0.55;
    f.buffer = null;
    f.move = null;
    f.normaliseSpin();
    sfx.dodge();
    this.puff(f.pos.x, f.pos.z, 4);
  }

  private tryConsume(f: Fighter, ctl: Ctl | null, nx: number, nz: number) {
    const b = f.buffer;
    if (!b) return;
    if (b === 'dodge') {
      f.buffer = null;
      if (f.stamina >= DODGE_COST) this.startDodge(f, ctl, nx, nz);
      else f.stamFlash = 0.4;
      return;
    }
    const list = CHAINS[b];
    if (!list) { f.buffer = null; return; }
    if (b === 'special' && f.special < 100) { f.buffer = null; f.stamFlash = 0.4; return; }
    const n = f.chainBtn === b && f.chainT < 0.65 ? (f.chainN + 1) % list.length : 0;
    const m = f.moves[list[n]];
    if (f.stamina < m.cost) { f.buffer = null; f.stamFlash = 0.4; return; }
    this.startMove(f, m, b, n);
  }

  private updateFighter(f: Fighter, foe: Fighter, ctl: Ctl | null, dt: number, live: boolean) {
    const def = f.def;
    f.invuln = Math.max(0, f.invuln - dt);
    f.counterT = Math.max(0, f.counterT - dt);
    f.stamFlash = Math.max(0, f.stamFlash - dt);
    f.flinch = Math.max(0, f.flinch - dt);
    f.comboT -= dt;
    f.chainT += dt;
    f.st += dt;
    f.bufT -= dt;
    if (f.bufT <= 0) f.buffer = null;

    v1.set(foe.pos.x - f.pos.x, 0, foe.pos.z - f.pos.z);
    const dist = v1.length();
    if (dist > 1e-4) v1.divideScalar(dist); else v1.set(0, 0, 1);
    const nx = v1.x, nz = v1.z;
    const faceYaw = Math.atan2(nx, nz);

    if (ctl) {
      for (const b of ['punch', 'heavy', 'kick', 'special', 'dodge'] as const) {
        if (ctl[b]) { f.buffer = b; f.bufT = 0.4; }
      }
    }

    // stamina regen
    if (f.stamDelay > 0) f.stamDelay -= dt;
    else if (f.state !== 'attack' && f.state !== 'dodge' && f.state !== 'dead') {
      f.stamina = Math.min(100, f.stamina + def.regen * (f.state === 'block' ? 0.35 : 1) * dt);
    }

    // knockback integration
    f.pos.x += f.kvel.x * dt;
    f.pos.z += f.kvel.z * dt;
    const kd = Math.exp(-6 * dt);
    f.kvel.x *= kd; f.kvel.z *= kd;
    f.vel.set(0, 0, 0);

    switch (f.state) {
      case 'idle':
      case 'block': {
        if (!live || !ctl) { f.yaw = turnToward(f.yaw, faceYaw, dt * 10); break; }
        if (ctl.block && f.stamina > 1) {
          if (f.state !== 'block') { f.state = 'block'; f.blockT = 0; f.st = 0; }
          f.blockT += dt;
        } else if (f.state === 'block') { f.state = 'idle'; f.blockT = 0; }
        if (f.buffer) this.tryConsume(f, ctl, nx, nz);
        if (f.state === 'idle' || f.state === 'block') {
          const mag = Math.hypot(ctl.mx, ctl.mz);
          if (mag > 0.08) {
            let speed = f.state === 'block' ? def.walk * 0.4 : ctl.run ? def.run : def.walk * Math.min(1, mag);
            const k = speed / mag;
            const sx = ctl.mx * (mag > 1 ? 1 / mag : 1), sz = ctl.mz * (mag > 1 ? 1 / mag : 1);
            void k;
            const n = Math.hypot(sx, sz) || 1;
            f.vel.set((sx / n) * speed, 0, (sz / n) * speed);
            f.pos.x += f.vel.x * dt; f.pos.z += f.vel.z * dt;
          }
          f.yaw = turnToward(f.yaw, faceYaw, dt * 14);
        }
        break;
      }
      case 'attack': {
        const m = f.move!;
        f.moveT += dt * def.atkSpeed;
        if (f.moveT < m.hit[0]) f.yaw = turnToward(f.yaw, faceYaw, dt * 9);
        else if (f.moveT < m.hit[1]) f.yaw = turnToward(f.yaw, faceYaw, dt * 2.5);
        if (m.lunge && f.moveT >= m.lunge[0] && f.moveT <= m.lunge[1] && dist > 0.95) {
          const sp = m.lunge[2] * def.atkSpeed;
          f.pos.x += Math.sin(f.yaw) * sp * dt;
          f.pos.z += Math.cos(f.yaw) * sp * dt;
        }
        if (!f.hitDone && f.moveT >= m.hit[0] && f.moveT <= m.hit[1] && live) this.tryHit(f, foe, m);
        if (f.state === 'attack' && ctl && live) {
          if (f.moveT >= m.cancel && f.buffer) {
            const b = f.buffer;
            if (b === 'dodge') this.tryConsume(f, ctl, nx, nz);
            else if (b !== 'special') this.tryConsume(f, ctl, nx, nz);
          }
          if (f.state === 'attack' && f.moveT >= m.dur) this.endMove(f);
          else if (f.state === 'attack' && ctl.block && f.moveT >= Math.max(m.hit[1] + 0.05, m.cancel)) {
            this.endMove(f);
            f.state = 'block'; f.blockT = 0; f.st = 0;
          }
        } else if (f.state === 'attack' && f.moveT >= m.dur) this.endMove(f);
        break;
      }
      case 'dodge': {
        const s = Math.max(0, 1 - f.st / DODGE_DUR);
        const v0 = (def.dodgeDist * 3) / DODGE_DUR;
        const sp = v0 * s * s;
        f.pos.x += f.dodgeDir.x * sp * dt;
        f.pos.z += f.dodgeDir.z * sp * dt;
        f.vel.set(f.dodgeDir.x * 0.01, 0, f.dodgeDir.z * 0.01);
        f.yaw = turnToward(f.yaw, faceYaw, dt * 8);
        if (f.st > DODGE_DUR * 0.7 && f.buffer && ctl && live && f.buffer !== 'dodge') {
          f.state = 'idle';
          this.tryConsume(f, ctl, nx, nz);
        }
        if (f.state === 'dodge' && f.st >= DODGE_DUR) { f.state = 'idle'; f.st = 0; }
        break;
      }
      case 'hit':
        if (f.st >= f.stun) { f.state = 'idle'; f.st = 0; f.chainT = 9; }
        break;
      case 'knock':
        if (f.st >= KNOCK_DUR) { f.state = 'idle'; f.st = 0; f.chainT = 9; f.invuln = 0.3; }
        break;
      case 'dead':
        break;
      case 'win':
        f.yaw = turnToward(f.yaw, faceYaw, dt * 3);
        break;
    }

    if (f.comboT <= 0 && f.state !== 'attack') f.combo = 0;
  }

  private endMove(f: Fighter) {
    f.state = 'idle';
    f.st = 0;
    f.chainT = 0;
    f.move = null;
    if (Math.abs(f.cur.bs) > 5.5) f.cur.bs = 0;
    if (Math.abs(f.cur.bx) > 5.5) f.cur.bx = 0;
  }

  // ------------------------------------------------------------------ hit resolution
  private tryHit(a: Fighter, d: Fighter, m: Move) {
    const dx = d.pos.x - a.pos.x, dz = d.pos.z - a.pos.z;
    const dist = Math.hypot(dx, dz) || 0.001;
    if (dist > m.reach) return;
    const fx = Math.sin(a.yaw), fz = Math.cos(a.yaw);
    const cos = (dx * fx + dz * fz) / dist;
    if (Math.acos(Math.max(-1, Math.min(1, cos))) > m.arc) return;
    if (d.state === 'knock' || d.state === 'dead' || d.state === 'win') return;
    const nx = dx / dist, nz = dz / dist;
    const hitPos = v2.set(d.pos.x - nx * 0.25, m.limb === 'lf' || m.limb === 'rf' ? 1.05 : 1.3, d.pos.z - nz * 0.25).clone();
    a.hitDone = true;
    const playerHit = d === this.fighters[this.playerIdx];

    // dodged
    if (d.invuln > 0 && d.state === 'dodge') {
      d.counterT = 1.5;
      sfx.dodge();
      this.popup(d, 'PERFECT DODGE', 'dodge');
      return;
    }
    if (d.invuln > 0) return;

    // blocked
    if (d.state === 'block') {
      if (d.blockT < 0.24) {
        // perfect block / parry
        a.state = 'hit'; a.st = 0; a.stun = 0.95; a.heavyHit = true; a.hitSide = Math.random() < 0.5 ? 1 : -1;
        a.move = null; a.normaliseSpin(); a.buffer = null;
        a.kvel.set(-nx * 2.6 * 6 / 2, 0, -nz * 2.6 * 6 / 2);
        d.counterT = 1.8;
        d.stamina = Math.min(100, d.stamina + 15);
        d.special = Math.min(100, d.special + 12);
        this.spark(hitPos, 22, 1, 0.8, 0.3, 7);
        this.flashes.spawn(hitPos, 0xffd070, 1.8);
        sfx.parry();
        this.popup(d, 'PERFECT BLOCK', 'parry');
        this.addShake(0.12);
        this.hitStop = 0.14;
        this.vibrate(playerHit ? 25 : 0);
        return;
      }
      const dmg = Math.max(1, m.dmg * a.def.dmg * a.dmgMul * 0.12);
      d.hp = Math.max(1, d.hp - dmg);
      d.stamina -= m.dmg * 1.5 + (m.heavy ? 6 : 0);
      d.stamDelay = 0.9;
      d.flinch = 0.2;
      d.kvel.x += nx * (m.kb * 0.5 + 0.4) * 6;
      d.kvel.z += nz * (m.kb * 0.5 + 0.4) * 6;
      a.landed = true;
      a.special = Math.min(100, a.special + 3);
      this.spark(hitPos, 8, 0.6, 0.8, 1, 5);
      this.flashes.spawn(hitPos, 0x9fd0ff, 0.9);
      sfx.block();
      this.addShake(0.08);
      this.hitStop = 0.05;
      if (d.stamina <= 0) {
        d.stamina = 0;
        d.state = 'hit'; d.st = 0; d.stun = 1.0; d.heavyHit = true; d.hitSide = 1; d.buffer = null;
        this.popup(d, 'GUARD BREAK', 'break');
        sfx.crack();
        this.addShake(0.2);
      }
      return;
    }

    // clean hit
    const chain = d.state === 'hit';
    a.combo = chain && a.comboT > 0 ? a.combo + 1 : 1;
    a.comboT = 1.7;
    d.combo = 0;
    let dmg = m.dmg * a.def.dmg * a.dmgMul * Math.max(0.55, 1 - 0.09 * (a.combo - 1));
    const counter = a.counterT > 0;
    if (counter) { dmg *= 1.5; a.counterT = 0; this.popup(a, 'COUNTER!', 'counter'); }
    d.hp = Math.max(0, d.hp - dmg);
    const kill = d.hp <= 0;
    const knock = !!m.kd || kill || a.combo >= 5;
    if (d.state === 'attack') { d.move = null; d.normaliseSpin(); }
    d.buffer = null;
    d.stamDelay = 0.7;
    if (knock) {
      d.state = kill ? 'dead' : 'knock';
      d.st = 0;
      const dist2 = Math.max(m.kb, 2.0);
      d.kvel.set(nx * dist2 * 6, 0, nz * dist2 * 6);
      d.invuln = 0;
    } else {
      d.state = 'hit';
      d.st = 0;
      d.stun = m.stun * (counter ? 1.3 : 1);
      d.heavyHit = !!m.heavy || m.kb >= 1;
      d.hitSide = Math.random() < 0.5 ? 1 : -1;
      d.kvel.set(nx * m.kb * 6, 0, nz * m.kb * 6);
    }
    a.landed = true;
    a.special = Math.min(100, a.special + 6 + dmg * 0.6);
    d.special = Math.min(100, d.special + dmg * 0.45);

    const heavy = !!m.heavy || knock;
    this.spark(hitPos, heavy ? 26 : 14, 1, 0.55 + Math.random() * 0.3, 0.2, heavy ? 8 : 5.5);
    this.flashes.spawn(hitPos, heavy ? 0xffa060 : 0xffe0b0, heavy ? 2.1 : 1.3);
    if (knock) this.puff(d.pos.x, d.pos.z, 8);
    sfx.hit(heavy);
    if (knock) sfx.thud();
    this.addShake(heavy ? 0.35 : 0.16);
    this.fovKick = Math.max(this.fovKick, heavy ? 4 : 1.8);
    this.hitStop = Math.max(this.hitStop, kill ? 0.25 : heavy ? 0.11 : 0.06);
    this.vibrate(playerHit ? (heavy ? 45 : 20) : 0);

    // physics props near the impact
    for (const p of this.arena.props) {
      if (p.broken) continue;
      const px = p.mesh.position.x - hitPos.x, pz = p.mesh.position.z - hitPos.z;
      const pd = Math.hypot(px, pz);
      if (pd < 1.6) {
        v1.set(px / (pd || 1), 0, pz / (pd || 1));
        this.arena.pushProp(p, v1, heavy ? 6 : 3);
        if (heavy) this.arena.damageProp(p, 1, (pos) => this.propBreak(pos));
      }
    }

    // combo display
    if (a.combo >= 2) this.comboShow = { who: this.fighters.indexOf(a), n: a.combo, t: 1.6 };

    if (kill) this.endRound(a, 'ko');
  }

  private propCollide(f: Fighter) {
    const speed = Math.hypot(f.vel.x + f.kvel.x, f.vel.z + f.kvel.z);
    for (const p of this.arena.props) {
      if (p.broken) continue;
      const dx = p.mesh.position.x - f.pos.x, dz = p.mesh.position.z - f.pos.z;
      const d = Math.hypot(dx, dz);
      const min = p.r + 0.3;
      if (d < min) {
        v1.set(dx / (d || 1), 0, dz / (d || 1));
        this.arena.pushProp(p, v1, 1.2 + speed * 0.9);
        p.mesh.position.x += v1.x * (min - d) * 0.6;
        p.mesh.position.z += v1.z * (min - d) * 0.6;
        if (f.state === 'knock' && speed > 5 && p.kind !== 'cone') {
          this.arena.damageProp(p, 2, (pos) => this.propBreak(pos));
          sfx.crack();
          this.addShake(0.2);
          f.kvel.multiplyScalar(0.55);
        }
      }
    }
  }

  private propBreak(pos: THREE.Vector3) {
    this.puff(pos.x, pos.z, 6);
    for (let i = 0; i < 14; i++) {
      this.sparks.emit(pos.x, 0.6, pos.z, (Math.random() - 0.5) * 6, 2 + Math.random() * 3, (Math.random() - 0.5) * 6, 0.6, 0.8, 0.5, 0.2, 10);
    }
  }

  // ------------------------------------------------------------------ fx helpers
  private spark(p: THREE.Vector3, n: number, r: number, g: number, b: number, speed: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU, e = (Math.random() - 0.3) * 1.6;
      const s = speed * (0.4 + Math.random());
      this.sparks.emit(p.x, p.y, p.z, Math.cos(a) * s, Math.sin(e) * s + 1.5, Math.sin(a) * s, 0.25 + Math.random() * 0.35, r, g, b, 12);
    }
  }

  private puff(x: number, z: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU;
      this.dust.emit(x + Math.cos(a) * 0.2, 0.1, z + Math.sin(a) * 0.2, Math.cos(a) * 1.4, 0.4 + Math.random() * 0.5, Math.sin(a) * 1.4, 0.7, 0.22, 0.25, 0.28, -0.3);
    }
  }

  private addShake(v: number) {
    if (this.settings.shake) this.shake = Math.min(0.6, this.shake + v);
  }

  private vibrate(ms: number) {
    if (ms > 0 && this.settings.vibrate && navigator.vibrate) {
      try { navigator.vibrate(ms); } catch { /* ignore */ }
    }
  }

  private popup(f: Fighter, text: string, kind: string) {
    const mine = f === this.fighters[this.playerIdx];
    this.cb.onPopup(text, mine ? kind : `${kind} enemy`);
  }

  // ------------------------------------------------------------------ camera
  private updateCamera(real: number) {
    const cam = this.camera;
    if (this.fovKick > 0) {
      this.fovKick = Math.max(0, this.fovKick - real * 14);
      this.updateFov();
    }
    if (this.mode === 'menu') {
      this.menuAngle += real * 0.12;
      if (this.menuFocus) {
        const a = Math.sin(this.t * 0.5) * 0.45;
        cam.position.set(Math.sin(a) * 4.6, 1.3, Math.cos(a) * 4.6);
        this.menuCenter.set(0, 0.25, 0);
        cam.lookAt(this.menuCenter);
        return;
      }
      this.menuCenter.lerp(v1.set(0, 1.2, 0), 1 - Math.exp(-4 * real));
      cam.position.set(Math.sin(this.menuAngle) * 6.4, 2.3, Math.cos(this.menuAngle) * 6.4);
      cam.lookAt(this.menuCenter);
      return;
    }
    const p = this.fighters[this.playerIdx];
    const o = this.fighters[1 - this.playerIdx];
    const dx = o.pos.x - p.pos.x, dz = o.pos.z - p.pos.z;
    const sep = Math.hypot(dx, dz);
    const target = Math.atan2(dx, dz);
    if (this.camSnap) { this.camYaw = target; this.camSnap = false; this.look.set(p.pos.x, 1.3, p.pos.z); }
    this.camYaw = lerpAngle(this.camYaw, target, 1 - Math.exp(-4.5 * real));

    let yaw = this.camYaw;
    let dist = 3.7 + sep * 0.4;
    let h = 1.85 + sep * 0.12;
    let side = 1.35;
    if (this.mode === 'intro') {
      const e = Math.min(1, this.modeT / 2.4);
      const k = 1 - e * e * (3 - 2 * e);
      yaw += k * 1.9;
      dist += k * 2.5;
      h += k * 0.4;
      side *= 1 - k;
    } else if (this.mode === 'roundEnd' || this.mode === 'matchEnd') {
      const wi = this.mode === 'matchEnd' ? (this.wins[0] > this.wins[1] ? 0 : 1) : this.roundWinner;
      const t = Math.min(this.modeT, 3.5);
      yaw += t * 0.38 + 0.4;
      dist = 3.6 + sep * 0.25;
      h = 1.35;
      side = 0;
      void wi;
    }
    const fx = Math.sin(yaw), fz = Math.cos(yaw);
    const rx = -fz, rz = fx;
    let cx = p.pos.x - fx * dist + rx * side;
    let cz = p.pos.z - fz * dist + rz * side;
    // keep camera inside the street canyon
    const cr = Math.hypot(cx, cz);
    if (cr > 13) { cx *= 13 / cr; cz *= 13 / cr; }
    v2.set(cx, h, cz);
    if (this.mode === 'intro' && this.modeT < 0.05) cam.position.copy(v2);
    cam.position.lerp(v2, 1 - Math.exp(-11 * real));

    let tx = p.pos.x + (o.pos.x - p.pos.x) * 0.5, tz = p.pos.z + (o.pos.z - p.pos.z) * 0.5;
    let ty = 1.0;
    if (this.mode === 'roundEnd' || this.mode === 'matchEnd') {
      const wi = this.mode === 'matchEnd' ? (this.wins[0] > this.wins[1] ? 0 : 1) : this.roundWinner;
      const w = this.fighters[wi >= 0 ? wi : this.playerIdx];
      tx = w.pos.x * 0.6 + tx * 0.4; tz = w.pos.z * 0.6 + tz * 0.4; ty = 1.0;
    }
    v1.set(tx, ty, tz);
    this.look.lerp(v1, 1 - Math.exp(-9 * real));
    if (this.shake > 0.001) {
      const s = this.shake;
      cam.position.x += (Math.random() - 0.5) * s * 0.35;
      cam.position.y += (Math.random() - 0.5) * s * 0.35;
      cam.position.z += (Math.random() - 0.5) * s * 0.35;
      this.shake *= Math.exp(-7 * real);
    }
    cam.lookAt(this.look);
  }

  // ------------------------------------------------------------------ HUD
  private emitHud() {
    const [a, b] = this.fighters;
    const p = this.fighters[this.playerIdx];
    if (this.comboShow.t > 0) this.comboShow.t -= 0.05;
    this.cb.onHud({
      mode: this.mode,
      round: this.round,
      time: Math.ceil(this.timeLeft),
      hp: [Math.round(a.hp * 10) / 10, Math.round(b.hp * 10) / 10],
      stam: [Math.round(a.stamina), Math.round(b.stamina)],
      spec: [Math.round(a.special), Math.round(b.special)],
      wins: [...this.wins] as [number, number],
      combo: this.comboShow.t > 0 ? { who: this.comboShow.who, n: this.comboShow.n } : { who: -1, n: 0 },
      player: this.playerIdx,
      noStam: p.stamFlash > 0,
      counter: p.counterT > 0,
    });
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize);
    document.removeEventListener('visibilitychange', this.onVis);
    this.canvas.removeEventListener('webglcontextlost', this.onLost as EventListener);
    this.canvas.removeEventListener('webglcontextrestored', this.onRestored as EventListener);
    try { this.renderer.dispose(); } catch { /* ignore */ }
  }
}

export { DEFS };
