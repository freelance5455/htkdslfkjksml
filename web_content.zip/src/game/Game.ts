import * as THREE from 'three';
import { buildWorld, LIMIT, type Building, type WorldData } from './world';
import { createCharacter, type Character } from './character';
import {
  DEFAULT_APPEARANCE,
  MISSIONS,
  SHOP_ITEMS,
  type Appearance,
  type HudState,
  type SaveData,
} from './types';

const SAVE_KEY = 'miniverse-mobile-save-v1';
const DAY_SECONDS = 600; // one full day/night cycle = 10 minutes
const FRAME_MS = 1000 / 30; // capped at 30 FPS for older phones
const WALK = 6.2;
const RUN = 11;
const GRAVITY = 30;
const JUMP_V = 11;
const PLAYER_R = 0.45;
const CAR_R = 1.5;
const CAR_MAX = 24;
const CAR_BOOST = 34;

const NPC_NAMES = ['Mia', 'Leo', 'Ruby', 'Max', 'Zoe'];
const NPC_LINES = [
  'Welcome to Miniverse! Coins are scattered all over town.',
  'Hop in a car and explore the streets. Watch your speed!',
  'Have you found the Secret Garden yet? Look for the golden beams.',
  'Shops sell cool outfits. Check the cosmetics store!',
  'It gets dark at night. Stay on the bright streets.',
  'The mountains surround the city. Some treasures are rare!',
];
const SKINS = [0xffd7b5, 0xe0ac7e, 0xa96f4a, 0x6b4226];
const SHIRTS = [0xd9423b, 0x3ccf91, 0xff6fb1, 0xf5c542, 0x2b2d33, 0x2d7ff9];
const PANTS = [0x3557a6, 0x6b7a3a, 0x7c4dff, 0x222428, 0xf1f1f1];
const HAIRS = [0x3b2a1e, 0xf2d16b, 0x222222, 0x6b4226];
const CAR_COLORS = [0xe53935, 0xffb300, 0x43a047, 0x8e24aa, 0x1e88e5, 0xf4511e];

type ActKind = 'car' | 'exit' | 'npc' | 'shop' | 'house' | null;

interface Car {
  group: THREE.Group;
  x: number;
  z: number;
  rot: number;
  speed: number;
}

interface Npc {
  char: Character;
  name: string;
  lines: string[];
  x: number;
  z: number;
  axis: 'x' | 'z';
  min: number;
  max: number;
  dir: number;
  talk: number;
}

interface Hidden {
  x: number;
  z: number;
  name: string;
  found: boolean;
  ring: THREE.Mesh;
}

export interface GameCallbacks {
  onHud: (h: HudState) => void;
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function lerpAngle(a: number, b: number, t: number) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function loadSave(): SaveData {
  const fallback: SaveData = {
    coins: 0,
    owned: [],
    appearance: { ...DEFAULT_APPEARANCE },
    mission: 0,
    progress: 0,
    found: [],
    lowGfx: false,
  };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return fallback;
    const d = JSON.parse(raw) as Partial<SaveData>;
    return {
      coins: d.coins ?? 0,
      owned: d.owned ?? [],
      appearance: { ...DEFAULT_APPEARANCE, ...(d.appearance ?? {}) },
      mission: d.mission ?? 0,
      progress: d.progress ?? 0,
      found: d.found ?? [],
      lowGfx: d.lowGfx ?? false,
    };
  } catch {
    return fallback;
  }
}

export class Game {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(55, 1, 0.3, 1000);
  private sun = new THREE.DirectionalLight(0xfff1d6, 1);
  private hemi = new THREE.HemisphereLight(0xbfe4ff, 0x5a6b3a, 0.6);
  private fog = new THREE.Fog(0xbfe6ff, 90, 400);
  private skyMat: THREE.ShaderMaterial;
  private sky: THREE.Mesh;
  private starMat: THREE.PointsMaterial;
  private stars: THREE.Points;
  private sunMesh: THREE.Mesh;
  private moonMesh: THREE.Mesh;
  private cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
  private cloudMesh: THREE.InstancedMesh;
  private cloudBase: { x: number; y: number; z: number; sx: number; sy: number; sz: number }[] = [];
  private cloudT = 0;

  private world!: WorldData;
  private player!: Character;
  private cars: Car[] = [];
  private npcs: Npc[] = [];
  private coinMesh!: THREE.InstancedMesh;
  private coins: { x: number; z: number; taken: boolean }[] = [];
  private hidden: Hidden[] = [];
  private visited = new Set<number>();
  private dummy = new THREE.Object3D();

  private vSun = new THREE.Vector3();
  private vDir = new THREE.Vector3();
  private vCam = new THREE.Vector3();
  private cA = new THREE.Color();
  private cB = new THREE.Color();
  private cC = new THREE.Color();

  input = { mx: 0, my: 0, sprint: false, jumpHeld: false };
  private jumpQueued = false;

  private pos = new THREE.Vector3(28, 0, 0);
  private vy = 0;
  private onGround = true;
  private facing = 0;
  private yaw = 0;
  private pitch = 0.5;
  private lookDX = 0;
  private lookDY = 0;
  private dragIdle = 9;
  private inCar: Car | null = null;
  private act: { kind: ActKind; target: unknown; label: string | null } = { kind: null, target: null, label: null };
  private clock = 9;
  private time = 0;
  private nightF = 0;
  private curSpeed = 0;

  private save: SaveData;
  private coinsTotal: number;
  private appearance: Appearance;
  private owned: Set<string>;
  private lowGfx: boolean;
  private shopOpen = false;
  private toast: string | null = null;
  private toastT = 0;
  private dialogue: { name: string; text: string } | null = null;
  private dialogueT = 0;

  private disposed = false;
  private raf = 0;
  private last = 0;
  private hudT = 0;
  private lastHud = '';
  private fps = 0;
  private fpsN = 0;
  private fpsT0 = 0;
  private cb: GameCallbacks;
  private canvas: HTMLCanvasElement;

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks) {
    this.canvas = canvas;
    this.cb = cb;
    this.save = loadSave();
    this.coinsTotal = this.save.coins;
    this.appearance = { ...this.save.appearance };
    this.lowGfx = this.save.lowGfx;
    this.owned = new Set<string>([...this.save.owned, ...SHOP_ITEMS.filter((i) => i.price === 0).map((i) => i.id)]);

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      alpha: false,
      stencil: false,
      powerPreference: 'low-power',
    });
    this.renderer.shadowMap.enabled = !this.lowGfx;
    this.renderer.shadowMap.type = THREE.BasicShadowMap;

    // Sky dome with vertical gradient (day/night colours are updated per frame)
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        skyTop: { value: new THREE.Color(0x3f8fe0) },
        skyBot: { value: new THREE.Color(0xbfe6ff) },
      },
      vertexShader: 'varying vec3 vPos; void main(){ vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader:
        'uniform vec3 skyTop; uniform vec3 skyBot; varying vec3 vPos; void main(){ float h = clamp(normalize(vPos).y * 1.8, 0.0, 1.0); gl_FragColor = vec4(mix(skyBot, skyTop, h), 1.0); }',
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(900, 16, 10), this.skyMat);
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);

    // Stars
    const sp = new Float32Array(250 * 3);
    for (let i = 0; i < 250; i++) {
      const a = Math.random() * Math.PI * 2;
      const y = 0.15 + Math.random() * 0.85;
      const r = Math.sqrt(1 - y * y) * 800;
      sp[i * 3] = Math.cos(a) * r;
      sp[i * 3 + 1] = y * 800;
      sp[i * 3 + 2] = Math.sin(a) * r;
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
    this.starMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 2,
      sizeAttenuation: false,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      fog: false,
    });
    this.stars = new THREE.Points(sg, this.starMat);
    this.stars.frustumCulled = false;
    this.scene.add(this.stars);

    // Sun and moon discs
    this.sunMesh = new THREE.Mesh(new THREE.SphereGeometry(22, 10, 8), new THREE.MeshBasicMaterial({ color: 0xfff3b0, fog: false }));
    this.moonMesh = new THREE.Mesh(new THREE.SphereGeometry(13, 10, 8), new THREE.MeshBasicMaterial({ color: 0xe6eeff, fog: false }));
    this.scene.add(this.sunMesh, this.moonMesh);

    // Clouds: one instanced draw call
    const CLOUD_N = 36;
    this.cloudMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), this.cloudMat, CLOUD_N);
    this.cloudMesh.frustumCulled = false;
    for (let i = 0; i < CLOUD_N; i++) {
      this.cloudBase.push({
        x: Math.random() * 800 - 400,
        y: 70 + Math.random() * 25,
        z: Math.random() * 800 - 400,
        sx: 12 + Math.random() * 20,
        sy: 4 + Math.random() * 3,
        sz: 9 + Math.random() * 12,
      });
    }
    this.scene.add(this.cloudMesh);

    // Lights
    this.sun.castShadow = !this.lowGfx;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -42;
    sc.right = 42;
    sc.top = 42;
    sc.bottom = -42;
    sc.near = 1;
    sc.far = 260;
    this.sun.shadow.bias = -0.001;
    this.scene.add(this.sun, this.sun.target, this.hemi);
    this.scene.fog = this.fog;

    window.addEventListener('resize', this.onResize);
  }

  private onResize = () => this.resize();

  private resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.renderer.setPixelRatio(this.lowGfx ? 0.75 : 1);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  async init(onProgress: (p: number) => void): Promise<void> {
    this.world = await buildWorld(this.scene, onProgress);
    if (this.disposed) return;
    this.buildEntities();
    this.resize();
    this.last = performance.now();
    this.fpsT0 = this.last;
    this.raf = requestAnimationFrame(this.loop);
  }

  private buildEntities() {
    const rng = (a: number, b: number) => a + Math.random() * (b - a);
    const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
    const roads = this.world.roadXs;

    // Player
    this.player = createCharacter(this.appearance);
    this.scene.add(this.player.group);

    // Coins (instanced)
    for (const c of this.world.coinSpots) this.coins.push({ x: c.x, z: c.z, taken: false });
    const coinGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.14, 10);
    coinGeo.rotateX(Math.PI / 2);
    const coinMat = new THREE.MeshLambertMaterial({ color: 0xffc62e, emissive: 0x4a3300 });
    this.coinMesh = new THREE.InstancedMesh(coinGeo, coinMat, this.coins.length);
    this.coinMesh.frustumCulled = false;
    this.coinMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(this.coinMesh);

    // Cars
    for (let k = 0; k < 6; k++) {
      const r = pick(roads);
      const group = this.buildCar(pick(CAR_COLORS));
      let car: Car;
      if (Math.random() < 0.5) {
        car = { group, x: r + 3, z: rng(-200, 200), rot: Math.random() < 0.5 ? 0 : Math.PI, speed: 0 };
      } else {
        car = { group, x: rng(-200, 200), z: r + 3, rot: Math.random() < 0.5 ? Math.PI / 2 : -Math.PI / 2, speed: 0 };
      }
      this.cars.push(car);
      this.scene.add(group);
    }

    // NPCs walking along the streets
    for (let k = 0; k < 5; k++) {
      const r = pick(roads);
      const char = createCharacter({
        ...DEFAULT_APPEARANCE,
        skin: pick(SKINS),
        shirt: pick(SHIRTS),
        pants: pick(PANTS),
        hair: pick(HAIRS),
        hat: Math.random() < 0.3 ? 'cap' : 'none',
      });
      const axis: 'x' | 'z' = Math.random() < 0.5 ? 'z' : 'x';
      const npc: Npc = {
        char,
        name: NPC_NAMES[k % NPC_NAMES.length],
        lines: NPC_LINES,
        x: axis === 'z' ? r + 3 : rng(-200, 200),
        z: axis === 'z' ? rng(-200, 200) : r - 3,
        axis,
        min: -230,
        max: 230,
        dir: Math.random() < 0.5 ? 1 : -1,
        talk: 0,
      };
      char.group.position.set(npc.x, 0, npc.z);
      this.npcs.push(npc);
      this.scene.add(char.group);
    }

    // Hidden locations with glowing ground rings
    for (const h of this.world.hidden) {
      const found = this.save.found.includes(h.name);
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(2.5, 3.6, 20),
        new THREE.MeshBasicMaterial({ color: 0xffe066, transparent: true, opacity: 0.75, depthWrite: false })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(h.x, 0.25, h.z);
      ring.visible = !found;
      this.scene.add(ring);
      this.hidden.push({ x: h.x, z: h.z, name: h.name, found, ring });
    }
  }

  private buildCar(color: number): THREE.Group {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.8, 4.4), new THREE.MeshLambertMaterial({ color }));
    body.position.y = 0.6;
    body.castShadow = true;
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.75, 2.2), new THREE.MeshLambertMaterial({ color: 0x9fd8ff }));
    cabin.position.set(0, 1.35, -0.2);
    const wheelGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.3, 8);
    wheelGeo.rotateZ(Math.PI / 2);
    const wheelMat = new THREE.MeshLambertMaterial({ color: 0x222222 });
    const light = new THREE.MeshBasicMaterial({ color: 0xfff6a0 });
    const tail = new THREE.MeshBasicMaterial({ color: 0xff3333 });
    g.add(body, cabin);
    for (const sx of [-1.1, 1.1]) {
      for (const sz of [-1.4, 1.4]) {
        const w = new THREE.Mesh(wheelGeo, wheelMat);
        w.position.set(sx, 0.42, sz);
        g.add(w);
      }
    }
    for (const sx of [-0.7, 0.7]) {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.1), light);
      hl.position.set(sx, 0.7, 2.2);
      const tl = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.1), tail);
      tl.position.set(sx, 0.7, -2.2);
      g.add(hl, tl);
    }
    return g;
  }

  // ---------------------------------------------------------------- public API
  start() {
    /* gameplay is always running; kept for API symmetry */
  }

  setMove(mx: number, my: number) {
    this.input.mx = mx;
    this.input.my = my;
  }

  look(dx: number, dy: number) {
    this.lookDX += dx;
    this.lookDY += dy;
  }

  setSprint(on: boolean) {
    this.input.sprint = on;
  }

  setJumpHeld(on: boolean) {
    this.input.jumpHeld = on;
  }

  pressJump() {
    this.jumpQueued = true;
  }

  interact() {
    if (this.shopOpen) return;
    const a = this.act;
    switch (a.kind) {
      case 'car':
        this.enterCar(a.target as Car);
        break;
      case 'exit':
        this.exitCar();
        break;
      case 'npc':
        this.talk(a.target as Npc);
        break;
      case 'shop':
        this.openShop(true);
        this.progress('visit', 1);
        break;
      case 'house': {
        const idx = a.target as number;
        this.visited.add(idx);
        this.addCoins(5);
        this.notify('Visited a house! +5 coins');
        this.progress('visit', 1);
        this.persist();
        break;
      }
      default:
        break;
    }
  }

  openShop(open: boolean) {
    if (open && this.inCar) {
      this.notify('Exit the car first');
      return;
    }
    this.shopOpen = open;
    if (open) {
      this.input.mx = 0;
      this.input.my = 0;
    }
    this.emitHud(true);
  }

  buyOrEquip(id: string) {
    const item = SHOP_ITEMS.find((i) => i.id === id);
    if (!item) return;
    if (!this.owned.has(item.id)) {
      if (this.coinsTotal < item.price) {
        this.notify('Not enough coins!');
        return;
      }
      this.coinsTotal -= item.price;
      this.owned.add(item.id);
      this.notify(`Bought ${item.name}!`);
    }
    Object.assign(this.appearance, item.patch);
    this.player.apply(this.appearance);
    this.persist();
    this.emitHud(true);
  }

  setLowGraphics(on: boolean) {
    this.lowGfx = on;
    this.renderer.shadowMap.enabled = !on;
    this.sun.castShadow = !on;
    this.cloudMesh.visible = !on;
    this.resize();
    this.persist();
    this.emitHud(true);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
  }

  // ---------------------------------------------------------------- loop
  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const el = now - this.last;
    if (el < FRAME_MS - 3) return;
    this.last = now;
    const dt = Math.min(0.05, el / 1000);
    this.update(dt, now);
    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number, now: number) {
    this.time += dt;
    this.clock = (this.clock + (dt * 24) / DAY_SECONDS) % 24;

    this.fpsN++;
    if (now - this.fpsT0 >= 1000) {
      this.fps = Math.round((this.fpsN * 1000) / (now - this.fpsT0));
      this.fpsN = 0;
      this.fpsT0 = now;
    }
    if (this.toastT > 0) {
      this.toastT -= dt;
      if (this.toastT <= 0) this.toast = null;
    }
    if (this.dialogueT > 0) {
      this.dialogueT -= dt;
      if (this.dialogueT <= 0) this.dialogue = null;
    }

    if (!this.shopOpen) {
      if (this.inCar) this.updateCar(dt);
      else this.updateFoot(dt);
    } else {
      this.curSpeed = 0;
      this.player.animate(dt, 0, false, this.time);
    }

    this.updateCoins();
    this.updateHidden();
    this.updateNpcs(dt);
    this.updateCamera(dt);
    this.updateSky(dt);
    this.updateAction();

    this.hudT += dt;
    if (this.hudT > 0.25) {
      this.hudT = 0;
      this.emitHud(false);
    }
  }

  private updateFoot(dt: number) {
    const { mx, my } = this.input;
    const mag = Math.min(1, Math.hypot(mx, my));
    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);
    let wx = 0;
    let wz = 0;
    if (mag > 0.05) {
      wx = rx * mx + fx * my;
      wz = rz * mx + fz * my;
      const l = Math.hypot(wx, wz) || 1;
      wx /= l;
      wz /= l;
    }
    const speed = mag > 0.05 ? (this.input.sprint ? RUN : WALK) * mag : 0;
    this.curSpeed = speed;
    if (speed > 0) this.facing = lerpAngle(this.facing, Math.atan2(wx, wz), Math.min(1, dt * 12));

    this.pos.x += wx * speed * dt;
    this.pos.z += wz * speed * dt;
    if (speed > 0) this.progress('walk', speed * dt);

    if (this.jumpQueued && this.onGround) {
      this.vy = JUMP_V;
      this.onGround = false;
    }
    this.jumpQueued = false;
    this.vy -= GRAVITY * dt;
    this.pos.y += this.vy * dt;
    if (this.pos.y <= 0) {
      this.pos.y = 0;
      this.vy = 0;
      this.onGround = true;
    }

    const p = { x: this.pos.x, z: this.pos.z };
    this.collide(p, PLAYER_R);
    this.pos.x = clamp(p.x, -LIMIT, LIMIT);
    this.pos.z = clamp(p.z, -LIMIT, LIMIT);

    this.player.group.visible = true;
    this.player.group.position.copy(this.pos);
    this.player.group.rotation.y = this.facing;
    this.player.animate(dt, speed, !this.onGround, this.time);

    if (speed > 0.5 && this.dragIdle > 1.5) {
      this.yaw = lerpAngle(this.yaw, this.facing + Math.PI, Math.min(1, dt * 1.2));
    }
  }

  private updateCar(dt: number) {
    const car = this.inCar;
    if (!car) return;
    const { mx, my, sprint, jumpHeld } = this.input;

    let target = 0;
    if (my > 0.05) target = my * (sprint ? CAR_BOOST : CAR_MAX);
    else if (my < -0.05) target = my * 10;
    let accel = 16;
    if (jumpHeld) {
      target = 0;
      accel = 40; // handbrake
    }
    const diff = target - car.speed;
    car.speed += Math.max(-accel * dt, Math.min(accel * dt, diff));
    this.curSpeed = Math.abs(car.speed);

    if (Math.abs(car.speed) > 0.5) {
      car.rot -= mx * Math.sign(car.speed) * dt * 1.8 * Math.min(1, Math.abs(car.speed) / 10);
    }

    const ox = car.x;
    const oz = car.z;
    car.x += Math.sin(car.rot) * car.speed * dt;
    car.z += Math.cos(car.rot) * car.speed * dt;
    const p = { x: car.x, z: car.z };
    if (this.collide(p, CAR_R)) {
      car.speed *= -0.25;
      car.x = p.x;
      car.z = p.z;
    }
    car.x = clamp(car.x, -LIMIT, LIMIT);
    car.z = clamp(car.z, -LIMIT, LIMIT);

    const moved = Math.hypot(car.x - ox, car.z - oz);
    if (moved > 0) this.progress('drive', moved);

    car.group.position.set(car.x, 0, car.z);
    car.group.rotation.y = car.rot;
    this.pos.set(car.x, 0, car.z);
  }

  private collide(p: { x: number; z: number }, r: number): boolean {
    let hit = false;
    for (let iter = 0; iter < 2; iter++) {
      for (const b of this.world.colliders) {
        const minX = b.minX - r;
        const maxX = b.maxX + r;
        const minZ = b.minZ - r;
        const maxZ = b.maxZ + r;
        if (p.x > minX && p.x < maxX && p.z > minZ && p.z < maxZ) {
          hit = true;
          const dl = p.x - minX;
          const dr = maxX - p.x;
          const dn = p.z - minZ;
          const df = maxZ - p.z;
          const m = Math.min(dl, dr, dn, df);
          if (m === dl) p.x = minX;
          else if (m === dr) p.x = maxX;
          else if (m === dn) p.z = minZ;
          else p.z = maxZ;
        }
      }
    }
    return hit;
  }

  private enterCar(car: Car) {
    this.inCar = car;
    car.speed = 0;
    this.player.group.visible = false;
    this.notify('Driving! Joystick steers, sprint boosts.');
  }

  private exitCar() {
    const car = this.inCar;
    if (!car) return;
    if (Math.abs(car.speed) > 3) {
      this.notify('Slow down before exiting!');
      return;
    }
    const sx = -Math.cos(car.rot) * 2.6;
    const sz = Math.sin(car.rot) * 2.6;
    const p = { x: car.x + sx, z: car.z + sz };
    this.collide(p, PLAYER_R);
    this.pos.set(p.x, 0, p.z);
    this.facing = car.rot;
    this.inCar = null;
    this.player.group.visible = true;
  }

  private talk(n: Npc) {
    n.talk = 5;
    const line = n.lines[Math.floor(Math.random() * n.lines.length)];
    this.dialogue = { name: n.name, text: line };
    this.dialogueT = 5;
    this.progress('talk', 1);
  }

  private updateCoins() {
    const car = this.inCar;
    const px = car ? car.x : this.pos.x;
    const pz = car ? car.z : this.pos.z;
    let touched = false;
    for (let i = 0; i < this.coins.length; i++) {
      const c = this.coins[i];
      if (!c.taken && Math.hypot(c.x - px, c.z - pz) < 2.2) {
        c.taken = true;
        touched = true;
        this.coinsTotal++;
        this.progress('coins', 1);
      }
      this.dummy.position.set(c.x, 1.1 + Math.sin(this.time * 3 + i) * 0.15, c.z);
      this.dummy.rotation.set(0, this.time * 2.5 + i, 0);
      this.dummy.scale.setScalar(c.taken ? 0.0001 : 1);
      this.dummy.updateMatrix();
      this.coinMesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.coinMesh.instanceMatrix.needsUpdate = true;
    if (touched) this.persist();
  }

  private updateHidden() {
    const car = this.inCar;
    const px = car ? car.x : this.pos.x;
    const pz = car ? car.z : this.pos.z;
    for (const h of this.hidden) {
      if (h.found) continue;
      const s = 1 + Math.sin(this.time * 4) * 0.1;
      h.ring.scale.setScalar(s);
      if (Math.hypot(h.x - px, h.z - pz) < 7) {
        h.found = true;
        h.ring.visible = false;
        this.save.found.push(h.name);
        this.addCoins(50);
        this.progress('hidden', 1);
        this.notify(`Hidden spot found: ${h.name}! +50 coins`);
        this.persist();
      }
    }
  }

  private updateNpcs(dt: number) {
    for (const n of this.npcs) {
      if (n.talk > 0) {
        n.talk -= dt;
        n.char.animate(dt, 0, false, this.time);
        n.char.group.rotation.y = Math.atan2(this.pos.x - n.x, this.pos.z - n.z);
        continue;
      }
      const step = 2.4 * dt * n.dir;
      if (n.axis === 'z') {
        n.z += step;
        if (n.z > n.max) {
          n.z = n.max;
          n.dir = -1;
        } else if (n.z < n.min) {
          n.z = n.min;
          n.dir = 1;
        }
        n.char.group.rotation.y = n.dir > 0 ? 0 : Math.PI;
      } else {
        n.x += step;
        if (n.x > n.max) {
          n.x = n.max;
          n.dir = -1;
        } else if (n.x < n.min) {
          n.x = n.min;
          n.dir = 1;
        }
        n.char.group.rotation.y = n.dir > 0 ? Math.PI / 2 : -Math.PI / 2;
      }
      n.char.group.position.set(n.x, 0, n.z);
      n.char.animate(dt, 2.4, false, this.time);
    }
  }

  private updateAction() {
    let kind: ActKind = null;
    let target: unknown = null;
    let label: string | null = null;
    if (this.inCar) {
      kind = 'exit';
      label = 'Exit car';
    } else {
      let best = 4.8;
      for (const c of this.cars) {
        const d = Math.hypot(c.x - this.pos.x, c.z - this.pos.z);
        if (d < best) {
          best = d;
          kind = 'car';
          target = c;
          label = 'Enter car';
        }
      }
      if (kind === null) {
        for (const n of this.npcs) {
          if (Math.hypot(n.x - this.pos.x, n.z - this.pos.z) < 3.8) {
            kind = 'npc';
            target = n;
            label = 'Talk';
            break;
          }
        }
      }
      if (kind === null) {
        const bs = this.world.buildings;
        for (let i = 0; i < bs.length; i++) {
          const b: Building = bs[i];
          if (b.kind !== 'shop' && b.kind !== 'house') continue;
          if (b.kind === 'house' && this.visited.has(i)) continue;
          const d = Math.hypot(b.x - this.pos.x, b.z - this.pos.z);
          if (d < Math.max(b.w, b.d) / 2 + 3.5) {
            kind = b.kind === 'shop' ? 'shop' : 'house';
            target = i;
            label = b.kind === 'shop' ? 'Enter shop' : 'Visit house';
            break;
          }
        }
      }
    }
    this.act = { kind, target, label };
  }

  private updateCamera(dt: number) {
    if (this.lookDX !== 0 || this.lookDY !== 0) {
      this.yaw -= this.lookDX * 0.0065;
      this.pitch = clamp(this.pitch + this.lookDY * 0.004, 0.2, 1.2);
      this.lookDX = 0;
      this.lookDY = 0;
      this.dragIdle = 0;
    } else {
      this.dragIdle += dt;
    }

    let tx: number;
    let tz: number;
    let ty: number;
    let dist: number;
    const car = this.inCar;
    if (car) {
      if (this.dragIdle > 1.5) this.yaw = lerpAngle(this.yaw, car.rot + Math.PI, Math.min(1, dt * 1.6));
      tx = car.x;
      tz = car.z;
      ty = 1.4;
      dist = 13;
    } else {
      tx = this.pos.x;
      tz = this.pos.z;
      ty = 1.7;
      dist = 9.5;
    }
    const h = Math.cos(this.pitch) * dist;
    const cy = ty + Math.sin(this.pitch) * dist;
    this.vCam.set(tx + Math.sin(this.yaw) * h, Math.max(1.2, cy), tz + Math.cos(this.yaw) * h);
    this.camera.position.lerp(this.vCam, 1 - Math.exp(-dt * 12));
    this.camera.lookAt(tx, ty, tz);
  }

  private updateSky(dt: number) {
    // Sun travels in an arc; dusk/dawn tint the horizon.
    const th = (this.clock / 24) * Math.PI * 2 - Math.PI / 2;
    const elev = Math.sin(th);
    const dayF = clamp(elev * 4, 0, 1);
    const nightF = clamp(-elev * 4, 0, 1);
    const sunsetF = clamp(1 - Math.abs(elev) * 6, 0, 1);
    this.nightF = nightF;

    this.vSun.set(Math.cos(th) * 0.8, elev, 0.4).normalize();
    this.vDir.copy(this.vSun);
    if (elev < 0) this.vDir.negate();

    const pos = this.pos;
    this.sun.position.copy(pos).addScaledVector(this.vDir, 90);
    this.sun.target.position.copy(pos);
    this.sun.target.updateMatrixWorld();
    this.sun.intensity = elev >= 0 ? dayF * 1.1 : nightF * 0.3;
    const warm = this.cA.set(0xfff1d6).lerp(this.cB.set(0xff9a5c), sunsetF);
    this.sun.color.copy(elev >= 0 ? warm : this.cC.set(0xa9c2ff));

    this.hemi.intensity = 0.5 + 0.25 * dayF;
    this.hemi.color.lerpColors(this.cA.set(0x2a3f75), this.cB.set(0xbfe4ff), dayF);
    this.hemi.groundColor.lerpColors(this.cA.set(0x1a2233), this.cB.set(0x5a6b3a), dayF);

    const top = this.cA.lerpColors(this.cC.set(0x060b25), this.cB.set(0x3f8fe0), dayF);
    const bot = this.cA.clone().lerpColors(this.cB.set(0x1b2a55), this.cC.set(0xbfe6ff), dayF);
    bot.lerp(this.cB.set(0xff9b62), sunsetF * 0.85);
    this.skyMat.uniforms.skyTop.value.copy(top);
    this.skyMat.uniforms.skyBot.value.copy(bot);
    this.fog.color.copy(bot);
    this.renderer.setClearColor(bot);

    this.starMat.opacity = nightF * 0.9;
    this.cloudMat.color.lerpColors(this.cA.set(0xffffff), this.cB.set(0x3a4566), nightF * 0.85);

    const cam = this.camera.position;
    this.sky.position.copy(cam);
    this.stars.position.copy(cam);
    this.sunMesh.position.copy(cam).addScaledVector(this.vSun, 500);
    this.moonMesh.position.copy(cam).addScaledVector(this.vSun, -500);
    this.sunMesh.visible = elev > -0.1;
    this.moonMesh.visible = elev < 0.1;

    // Drifting clouds
    this.cloudT += dt * 2.5;
    for (let i = 0; i < this.cloudBase.length; i++) {
      const b = this.cloudBase[i];
      const x = ((b.x + this.cloudT + 420) % 840) - 420;
      this.dummy.position.set(x, b.y, b.z);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.scale.set(b.sx, b.sy, b.sz);
      this.dummy.updateMatrix();
      this.cloudMesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.cloudMesh.instanceMatrix.needsUpdate = true;
  }

  // ---------------------------------------------------------------- mission & HUD
  private progress(kind: string, amt: number) {
    const m = MISSIONS[this.save.mission];
    if (!m || m.kind !== kind) return;
    this.save.progress += amt;
    if (this.save.progress >= m.target) {
      this.save.progress = 0;
      this.save.mission++;
      this.addCoins(50);
      this.notify('Mission complete! +50 coins');
      this.persist();
    }
  }

  private addCoins(n: number) {
    this.coinsTotal += n;
  }

  private notify(text: string) {
    this.toast = text;
    this.toastT = 2.6;
  }

  private persist() {
    this.save.coins = this.coinsTotal;
    this.save.appearance = { ...this.appearance };
    this.save.owned = [...this.owned];
    this.save.lowGfx = this.lowGfx;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.save));
    } catch {
      /* storage unavailable */
    }
  }

  private emitHud(force: boolean) {
    const idx = Math.min(this.save.mission, MISSIONS.length - 1);
    const m = MISSIONS[idx];
    const done = this.save.mission >= MISSIONS.length;
    const hh = Math.floor(this.clock);
    const mm = Math.floor((this.clock - hh) * 60);
    const pad = (n: number) => (n < 10 ? '0' : '') + n;
    const equipped = SHOP_ITEMS.filter((i) =>
      (Object.keys(i.patch) as (keyof Appearance)[]).every((k) => this.appearance[k] === i.patch[k])
    ).map((i) => i.id);
    const h: HudState = {
      coins: this.coinsTotal,
      speed: Math.round(this.curSpeed * 3.6),
      clock: `${pad(hh)}:${pad(mm)}`,
      night: this.nightF > 0.3,
      inCar: !!this.inCar,
      action: this.act.label,
      mission: done ? 'All missions complete! Keep exploring.' : `${idx + 1}/${MISSIONS.length}: ${m.text}`,
      missionProgress: done ? '' : `${Math.floor(Math.min(this.save.progress, m.target))}/${m.target}`,
      missionPct: done ? 100 : Math.min(100, (this.save.progress / m.target) * 100),
      missionDone: done,
      discovered: this.hidden.filter((x) => x.found).length,
      totalHidden: this.hidden.length,
      toast: this.toast,
      dialogue: this.dialogue,
      shopOpen: this.shopOpen,
      owned: [...this.owned],
      equipped,
      appearance: this.appearance,
      lowGfx: this.lowGfx,
      fps: this.fps,
    };
    const json = JSON.stringify(h);
    if (force || json !== this.lastHud) {
      this.lastHud = json;
      this.cb.onHud(h);
    }
  }

  get element() {
    return this.canvas;
  }
}
