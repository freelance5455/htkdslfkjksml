import * as THREE from 'three';
import { ZombieModels, ZombieRig, ZombieType } from '../models/ZombieModels';
import { CollisionSystem } from '../physics/CollisionSystem';
import { NavigationSystem } from '../ai/NavigationSystem';
import { ObjectPool } from '../core/ObjectPool';
import { DifficultyManager, DifficultySettings } from '../difficulty/DifficultyManager';
import { sound } from '../../audio/SoundEngine';

export interface ActiveZombie {
  id: string;
  rig: ZombieRig;
  type: ZombieType;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  attackRange: number;
  attackCooldown: number;
  lastAttackTime: number;
  isAttacking: boolean;
  attackAnimTime: number;
  isDead: boolean;
  deathTime: number;
  animTimer: number;
  currentPath: THREE.Vector3[];
  pathIndex: number;
  pathRecalcTimer: number;
  groanTimer: number;
  poolIndex: number;
}

export class ZombieManager {
  private scene: THREE.Scene;
  private collision: CollisionSystem;
  private nav: NavigationSystem;
  private pool: ObjectPool;
  private spawnPoints: THREE.Vector3[] = [];

  // Active zombies
  public zombies: ActiveZombie[] = [];

  // Zombie Rig Pool (Pre-allocated 32 rigs: 10 walkers, 10 runners, 6 brutes, 6 crawlers)
  private rigPool: { rig: ZombieRig; inUse: boolean; type: ZombieType }[] = [];

  // Difficulty Settings
  public difficulty: DifficultySettings;

  // 100+ Wave Management System
  public currentWave = 1;
  public zombiesRemainingToSpawn = 0;
  public totalWaveZombies = 0;
  public isWaveIntermission = false;
  public intermissionTimer = 0;
  private spawnTimer = 0;
  private spawnInterval = 2.0;

  // Staggered AI & Global Groan Audio Throttling
  private pathfindBudgetThisFrame = 2;
  private lastGlobalGroanTime = 0;

  // Player state reference
  public playerPos: THREE.Vector3 = new THREE.Vector3();
  public barricadeSystem?: import('../map/BarricadeAndDoorSystem').BarricadeAndDoorSystem;
  public onPlayerHurt?: (damage: number) => void;
  public onZombieKilled?: (zombie: ActiveZombie, isHeadshot: boolean, points: number) => void;
  public onWaveChange?: (wave: number, isIntermission: boolean) => void;
  public onZombieCountChange?: (remaining: number, total: number) => void;

  constructor(
    scene: THREE.Scene,
    collision: CollisionSystem,
    nav: NavigationSystem,
    spawnPoints: THREE.Vector3[],
    pool: ObjectPool
  ) {
    this.scene = scene;
    this.collision = collision;
    this.nav = nav;
    this.spawnPoints = spawnPoints;
    this.pool = pool;
    this.difficulty = DifficultyManager.get();

    this.initRigPool();
  }

  // Pre-allocate zombie 3D rigs once
  private initRigPool() {
    const types: ZombieType[] = [
      'walker', 'walker', 'walker', 'walker', 'walker', 'walker', 'walker', 'walker', 'walker', 'walker',
      'runner', 'runner', 'runner', 'runner', 'runner', 'runner', 'runner', 'runner', 'runner', 'runner',
      'brute', 'brute', 'brute', 'brute', 'brute', 'brute',
      'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler',
    ];

    for (const type of types) {
      const rig = ZombieModels.buildZombie(type);
      rig.root.visible = false;
      this.scene.add(rig.root);
      this.rigPool.push({
        rig,
        inUse: false,
        type,
      });
    }
  }

  setDifficulty(settings: DifficultySettings) {
    this.difficulty = { ...settings };
  }

  setSpawnPoints(points: THREE.Vector3[]) {
    this.spawnPoints = points;
  }

  startNewGame() {
    this.clearAllZombies();
    this.currentWave = 1;
    this.isWaveIntermission = false;
    this.setupWave(1);
  }

  clearAllZombies() {
    for (const z of this.zombies) {
      z.rig.root.visible = false;
      this.rigPool[z.poolIndex].inUse = false;
    }
    this.zombies = [];
  }

  // Scalable 100+ Wave generator
  setupWave(waveNumber: number) {
    this.currentWave = waveNumber;

    // Smooth curve for zombie count up to 100+ waves
    this.totalWaveZombies = Math.min(140, Math.floor(8 + Math.pow(waveNumber, 0.78) * 4));
    this.zombiesRemainingToSpawn = this.totalWaveZombies;

    const rateModifier = this.difficulty.spawnRate === 'fast' ? 0.75 : this.difficulty.spawnRate === 'slow' ? 1.3 : 1.0;
    this.spawnInterval = Math.max(0.4, (2.2 - Math.log10(waveNumber + 1) * 0.9) * rateModifier);
    this.spawnTimer = 1.0;

    sound.playRoundStart();
    sound.playWaveWarningHorde();
    setTimeout(() => {
      sound.playCharacterVoice('new_wave');
    }, 1200);

    if (this.onWaveChange) {
      this.onWaveChange(this.currentWave, false);
    }
    this.notifyCounts();
  }

  private notifyCounts() {
    const aliveCount = this.zombies.filter(z => !z.isDead).length + this.zombiesRemainingToSpawn;
    if (this.onZombieCountChange) {
      this.onZombieCountChange(aliveCount, this.totalWaveZombies);
    }
  }

  spawnZombie() {
    if (this.spawnPoints.length === 0) return;

    const sp = this.spawnPoints[Math.floor(Math.random() * this.spawnPoints.length)];

    const isSpecialWave = this.currentWave % 5 === 0;
    let type: ZombieType = 'walker';
    const rand = Math.random();

    if (isSpecialWave) {
      type = rand < 0.65 ? 'runner' : 'brute';
    } else if (this.currentWave >= 8 && rand < 0.16) {
      type = 'brute';
    } else if (this.currentWave >= 3 && rand < 0.45) {
      type = 'runner';
    } else if (this.currentWave >= 5 && rand < 0.65) {
      type = 'crawler';
    }

    let poolIndex = -1;
    for (let i = 0; i < this.rigPool.length; i++) {
      if (!this.rigPool[i].inUse && this.rigPool[i].type === type) {
        poolIndex = i;
        break;
      }
    }
    if (poolIndex === -1) {
      for (let i = 0; i < this.rigPool.length; i++) {
        if (!this.rigPool[i].inUse) {
          poolIndex = i;
          type = this.rigPool[i].type;
          break;
        }
      }
    }
    if (poolIndex === -1) return;

    const pooledRig = this.rigPool[poolIndex];
    pooledRig.inUse = true;

    const rig = pooledRig.rig;
    const spawnY = this.collision.getGroundHeight(sp.x, sp.z);
    rig.root.position.set(sp.x + (Math.random() - 0.5) * 2, spawnY, sp.z + (Math.random() - 0.5) * 2);
    rig.root.rotation.set(0, 0, 0);
    rig.root.visible = true;

    rig.leftArm.rotation.set(0, 0, 0);
    rig.rightArm.rotation.set(0, 0, 0);
    rig.leftLeg.rotation.set(0, 0, 0);
    rig.rightLeg.rotation.set(0, 0, 0);

    const waveScaling = 1 + Math.log2(this.currentWave) * 0.35;
    let baseHp = 95;
    let speed = 2.4;
    let dmg = 25;
    let range = 2.1; // Solid 2.1m attack range for reliable hits

    if (type === 'runner') {
      baseHp = 75;
      speed = 3.6; // Controlled speed so zombies feel like zombies, not racecars
      dmg = 20;
      range = 2.0;
    } else if (type === 'brute') {
      baseHp = 350;
      speed = 1.9;
      dmg = 55;
      range = 2.8;
    } else if (type === 'crawler') {
      baseHp = 55;
      speed = 2.4;
      dmg = 18;
      range = 1.7;
    }

    // Apply difficulty scaling
    const health = Math.round(baseHp * waveScaling * this.difficulty.healthMultiplier);
    const finalDamage = Math.round((dmg + this.currentWave * 0.3) * this.difficulty.damageMultiplier);
    const finalSpeed = speed * this.difficulty.speedMultiplier;

    const id = `zombie_${Date.now()}_${Math.random()}`;

    const zombie: ActiveZombie = {
      id,
      rig,
      type,
      health,
      maxHealth: health,
      speed: finalSpeed,
      damage: Math.min(85, finalDamage),
      attackRange: range,
      attackCooldown: this.difficulty.attackCooldown,
      lastAttackTime: 0,
      isAttacking: false,
      attackAnimTime: 0,
      isDead: false,
      deathTime: 0,
      animTimer: Math.random() * 10,
      currentPath: [],
      pathIndex: 0,
      pathRecalcTimer: Math.random() * 0.5,
      groanTimer: 3 + Math.random() * 6,
      poolIndex,
    };

    this.zombies.push(zombie);
    this.zombiesRemainingToSpawn--;

    const now = performance.now() / 1000;
    if (now - this.lastGlobalGroanTime > 1.2) {
      this.lastGlobalGroanTime = now;
      sound.playZombieGroan(type === 'brute' ? 'brute' : type === 'runner' ? 'runner' : 'walker');
    }

    this.notifyCounts();
  }

  damageZombie(zombieId: string, damage: number, isHeadshot: boolean, hitPoint?: THREE.Vector3) {
    const z = this.zombies.find(item => item.id === zombieId && !item.isDead);
    if (!z) return;

    z.health -= damage;

    const spawnPt = hitPoint || z.rig.root.position.clone().add({ x: 0, y: 1.2, z: 0 });
    this.pool.spawnBlood(spawnPt, isHeadshot ? 14 : 7);

    if (z.health <= 0) {
      this.killZombie(z, isHeadshot);
    } else {
      sound.playZombieHurt();
    }
  }

  applyAreaDamage(center: THREE.Vector3, radius: number, maxDamage: number) {
    for (let i = 0; i < this.zombies.length; i++) {
      const z = this.zombies[i];
      if (z.isDead) continue;
      const d = z.rig.root.position.distanceTo(center);
      if (d <= radius) {
        const falloff = 1 - (d / radius);
        const dmg = Math.round(maxDamage * falloff);
        this.damageZombie(z.id, dmg, false, z.rig.root.position.clone().add({ x: 0, y: 1.0, z: 0 }));
      }
    }
  }

  applyMeleeDamage(center: THREE.Vector3, radius: number, damage: number) {
    for (let i = 0; i < this.zombies.length; i++) {
      const z = this.zombies[i];
      if (z.isDead) continue;
      const d = z.rig.root.position.distanceTo(center);
      if (d <= radius) {
        this.damageZombie(z.id, damage, false, z.rig.root.position.clone().add({ x: 0, y: 1.2, z: 0 }));
      }
    }
  }

  private killZombie(z: ActiveZombie, isHeadshot: boolean) {
    z.isDead = true;
    z.deathTime = performance.now() / 1000;

    sound.playZombieDeath();

    const points = isHeadshot ? 150 : 100;
    if (this.onZombieKilled) {
      this.onZombieKilled(z, isHeadshot, points);
    }

    this.notifyCounts();

    const remainingAlive = this.zombies.filter(item => !item.isDead).length;
    if (remainingAlive === 0 && this.zombiesRemainingToSpawn === 0) {
      this.triggerWaveIntermission();
    }
  }

  private triggerWaveIntermission() {
    this.isWaveIntermission = true;
    this.intermissionTimer = 6.0;
    if (this.onWaveChange) {
      this.onWaveChange(this.currentWave, true);
    }
  }

  getRaycastTargets() {
    return this.zombies
      .filter(z => !z.isDead)
      .map(z => ({
        id: z.id,
        position: z.rig.root.position,
        radius: z.rig.radius,
        height: z.rig.height,
        headY: z.type === 'crawler' ? 0.45 : z.type === 'brute' ? 2.05 : 1.68,
        takeDamage: (amount: number, isHeadshot: boolean) => {
          this.damageZombie(z.id, amount, isHeadshot);
        },
      }));
  }

  update(delta: number, playerPos: THREE.Vector3) {
    this.playerPos.copy(playerPos);
    const now = performance.now() / 1000;

    // 1. Spawning with difficulty max cap
    if (!this.isWaveIntermission && this.zombiesRemainingToSpawn > 0) {
      this.spawnTimer -= delta;
      const activeCount = this.zombies.filter(z => !z.isDead).length;
      if (this.spawnTimer <= 0 && activeCount < this.difficulty.maxZombies) {
        this.spawnZombie();
        this.spawnTimer = this.spawnInterval;
      }
    }

    // 2. Intermission countdown
    if (this.isWaveIntermission) {
      this.intermissionTimer -= delta;
      if (this.intermissionTimer <= 0) {
        this.isWaveIntermission = false;
        this.setupWave(this.currentWave + 1);
      }
    }

    this.pathfindBudgetThisFrame = this.difficulty.intelligence === 'tactical' ? 3 : 2;

    // 3. Update active zombies
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];

      if (z.isDead) {
        const timeDead = now - z.deathTime;
        if (timeDead > 2.5) {
          z.rig.root.position.y -= delta * 1.2;
          if (timeDead > 3.5) {
            z.rig.root.visible = false;
            this.rigPool[z.poolIndex].inUse = false;
            this.zombies.splice(i, 1);
            continue;
          }
        } else {
          z.rig.root.rotation.x = THREE.MathUtils.lerp(z.rig.root.rotation.x, -Math.PI / 2, delta * 5);
        }
        continue;
      }

      const dx = this.playerPos.x - z.rig.root.position.x;
      const dz = this.playerPos.z - z.rig.root.position.z;
      const horizDistSq = dx * dx + dz * dz;
      const horizDist = Math.sqrt(horizDistSq);

      // Groan sound
      z.groanTimer -= delta;
      if (z.groanTimer <= 0) {
        z.groanTimer = 6 + Math.random() * 8;
        if (horizDistSq < 625 && now - this.lastGlobalGroanTime > 1.2) {
          this.lastGlobalGroanTime = now;
          const mood = horizDist < 14 ? 'chase' : horizDist > 26 ? 'distant' : 'idle';
          const pan = THREE.MathUtils.clamp(-dx / 15, -1, 1);
          sound.playZombieGroan(z.type, mood, pan);
        }
      }

      // Path Navigation update
      z.pathRecalcTimer -= delta;
      if (horizDistSq < 324) { // Within 18m
        if (z.pathRecalcTimer <= 0 && this.pathfindBudgetThisFrame > 0) {
          z.currentPath = this.nav.findPath(z.rig.root.position, this.playerPos);
          z.pathIndex = 0;
          z.pathRecalcTimer = 1.0 + Math.random() * 0.4;
          this.pathfindBudgetThisFrame--;
        }
      } else {
        if (z.pathRecalcTimer <= 0 && this.pathfindBudgetThisFrame > 0) {
          z.currentPath = this.nav.findPath(z.rig.root.position, this.playerPos);
          z.pathIndex = 0;
          z.pathRecalcTimer = 2.2 + Math.random() * 0.8;
          this.pathfindBudgetThisFrame--;
        }
      }

      // Barricade Attack & Damage Behavior (Requirement 9 & 20)
      let isAttackingBarricade = false;
      if (this.barricadeSystem && this.barricadeSystem.barricades.length > 0) {
        for (let bIdx = 0; bIdx < this.barricadeSystem.barricades.length; bIdx++) {
          const b = this.barricadeSystem.barricades[bIdx];
          if (b.planks > 0 && z.rig.root.position.distanceTo(b.position) <= 2.4) {
            isAttackingBarricade = true;
            z.rig.root.lookAt(b.position.x, z.rig.root.position.y, b.position.z);
            if (now - z.lastAttackTime >= z.attackCooldown) {
              z.lastAttackTime = now;
              z.isAttacking = true;
              z.attackAnimTime = 0;
              this.barricadeSystem.damageNearestBarricade(z.rig.root.position);
            }
            break;
          }
        }
      }

      // Attack check: When within attack range, attack the player!
      if (isAttackingBarricade) {
        // Stopped attacking barricade
      } else if (horizDist <= z.attackRange) {
        z.rig.root.rotation.y = Math.atan2(dx, dz);

        if (now - z.lastAttackTime >= z.attackCooldown) {
          z.lastAttackTime = now;
          z.isAttacking = true;
          z.attackAnimTime = 0;
          sound.playZombieAttack();

          // CRITICAL: Player damage dealt on hit
          if (this.onPlayerHurt) {
            this.onPlayerHurt(z.damage);
          }
        }
      } else {
        // Move toward player or path waypoint
        let targetPoint = this.playerPos;
        if (z.currentPath.length > 0 && z.pathIndex < z.currentPath.length) {
          targetPoint = z.currentPath[z.pathIndex];
          const distToNodeSq =
            (z.rig.root.position.x - targetPoint.x) * (z.rig.root.position.x - targetPoint.x) +
            (z.rig.root.position.z - targetPoint.z) * (z.rig.root.position.z - targetPoint.z);

          if (distToNodeSq < 2.0 && z.pathIndex < z.currentPath.length - 1) {
            z.pathIndex++;
            targetPoint = z.currentPath[z.pathIndex];
          }
        }

        const moveX = targetPoint.x - z.rig.root.position.x;
        const moveZ = targetPoint.z - z.rig.root.position.z;
        const lenSq = moveX * moveX + moveZ * moveZ;

        if (lenSq > 0.005) {
          const invLen = 1 / Math.sqrt(lenSq);
          const dirX = moveX * invLen;
          const dirZ = moveZ * invLen;

          z.rig.root.rotation.y = Math.atan2(dirX, dirZ);

          const step = z.speed * delta;

          if (horizDistSq < 625) {
            const resolved = this.collision.resolveMovement(
              z.rig.root.position,
              new THREE.Vector3(dirX * step, 0, dirZ * step),
              z.rig.radius,
              z.rig.height,
              0.4
            );
            z.rig.root.position.copy(resolved.position);
          } else {
            z.rig.root.position.x += dirX * step;
            z.rig.root.position.z += dirZ * step;
          }

          z.rig.root.position.y = this.collision.getGroundHeight(
            z.rig.root.position.x,
            z.rig.root.position.z,
            z.rig.root.position.y
          );
        }
      }

      // Animate Zombie
      if (horizDistSq < 900) {
        z.animTimer += delta * (z.speed * 2.2);
        this.animateZombie(z, delta);
      }
    }
  }

  private animateZombie(z: ActiveZombie, delta: number) {
    if (z.isAttacking) {
      z.attackAnimTime += delta * 4.5;
      const swing = Math.sin(z.attackAnimTime * Math.PI);

      // Articulated dual-arm claw strike
      z.rig.leftArm.rotation.x = -Math.PI / 3 - swing * 1.1;
      z.rig.rightArm.rotation.x = -Math.PI / 2.8 - swing * 1.2;
      z.rig.torso.rotation.x = swing * 0.25;

      if (z.attackAnimTime >= 1) {
        z.isAttacking = false;
        z.rig.torso.rotation.x = 0;
      }
    } else {
      // Natural walking & limping cadence
      const swing = Math.sin(z.animTimer);
      const armSwing = z.type === 'runner' ? swing * 0.9 : swing * 0.6;

      // Arms raised forward in shambling zombie pose
      z.rig.leftArm.rotation.x = -Math.PI / 2.5 + armSwing * 0.35;
      z.rig.rightArm.rotation.x = -Math.PI / 2.5 - armSwing * 0.35;

      if (z.type !== 'crawler') {
        z.rig.leftLeg.rotation.x = swing * 0.55;
        z.rig.rightLeg.rotation.x = -swing * 0.55;
      }

      z.rig.head.rotation.z = Math.sin(z.animTimer * 0.5) * 0.12;
    }
  }
}
