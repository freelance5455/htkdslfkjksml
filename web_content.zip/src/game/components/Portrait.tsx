import { cn } from "@/lib/utils";

export function Portrait({
  name,
  mark,
  color,
  size = "md",
  emotion,
}: {
  name: string;
  mark: string;
  color: string;
  size?: "sm" | "md" | "lg";
  emotion?: string;
}) {
  const px = size === "sm" ? "h-10 w-10 text-sm" : size === "lg" ? "h-20 w-20 text-2xl" : "h-14 w-14 text-lg";
  const shift =
    emotion === "angry" || emotion === "determined" ? "translate-y-px"
    : emotion === "sad" || emotion === "fearful" ? "translate-y-0.5 opacity-90"
    : emotion === "happy" ? "-translate-y-px"
    : "";
  return (
    <div
      className={cn("relative shrink-0 overflow-hidden border border-line bg-elevated", px, shift)}
      style={{ borderRadius: 2 }}
      aria-label={name}
    >
      <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, ${color}55, ${color}18)` }} />
      <div className="absolute inset-x-2 top-2 h-[38%] rounded-sm" style={{ background: color, opacity: 0.35 }} />
      <div className="absolute left-1/2 top-[42%] h-[28%] w-[42%] -translate-x-1/2" style={{ background: color, opacity: 0.55, clipPath: "polygon(20% 0, 80% 0, 100% 100%, 0 100%)" }} />
      <span className="relative z-10 flex h-full items-end justify-center pb-1 font-display font-semibold tracking-wide text-fg">
        {mark}
      </span>
    </div>
  );
}
