import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

const BG: Record<string, string> = {
  hall: "/game/bg/hall.jpg",
  outpost: "/game/bg/outpost.jpg",
  vault: "/game/bg/vault.jpg",
  loading: "/game/bg/loading.jpg",
};

export function Shell({
  children,
  bg = "hall",
  dim = true,
}: {
  children: ReactNode;
  bg?: "hall" | "outpost" | "vault" | "loading";
  dim?: boolean;
}) {
  return (
    <div className="ash-shell">
      <div className={cn("ash-bg", !dim && "brightness-75")} style={{ backgroundImage: `url(${BG[bg]})` }} />
      <div className="ash-grain" />
      <div className="ash-frame">{children}</div>
    </div>
  );
}

export function TopBar({
  left,
  right,
}: {
  left: ReactNode;
  right?: ReactNode;
}) {
  return (
    <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 sm:px-6">
      <div className="min-w-0">{left}</div>
      <div className="flex shrink-0 items-center gap-2">{right}</div>
    </header>
  );
}

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("border border-line bg-surface/90 p-4 sm:p-5", className)} style={{ borderRadius: 14 }}>
      {children}
    </div>
  );
}

export function GhostBtn({
  children,
  onClick,
  disabled,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "h-11 min-w-11 inline-flex items-center justify-center border border-line px-4 text-sm font-medium tracking-wide text-fg transition-opacity duration-150",
        "hover:border-line-strong disabled:opacity-40",
        className,
      )}
      style={{ borderRadius: 4 }}
    >
      {children}
    </button>
  );
}

export function BoneBtn({
  children,
  onClick,
  disabled,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "h-11 inline-flex items-center justify-center border border-bone bg-bone px-5 text-sm font-semibold tracking-wide text-ink transition-transform duration-150",
        "active:scale-[0.98] disabled:opacity-40",
        className,
      )}
      style={{ borderRadius: 4 }}
    >
      {children}
    </button>
  );
}

export function Label({ children }: { children: ReactNode }) {
  return (
    <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted">{children}</p>
  );
}
