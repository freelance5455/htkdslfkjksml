import { useEffect, useRef, useState } from "react";
import { CHAR_BY_ID } from "../data/characters";
import { Portrait } from "./Portrait";
import { BoneBtn, Label } from "./Shell";
import { playVoice, sfxLib } from "../audio";

const BG: Record<string, string> = {
  vault: "/game/bg/vault.jpg",
  hall: "/game/bg/hall.jpg",
  outpost: "/game/bg/outpost.jpg",
};

type Beat = {
  speaker?: string;
  emotion?: string;
  text?: string;
  actor?: string;
  effect?: "none" | "spark" | "blackout" | "slash" | "chain" | "resolve";
  duration: number;
  caption?: string;
};

const BEATS: Beat[] = [
  { actor: "arden", speaker: "Arden", emotion: "determined", text: "It ends here.", duration: 2300, caption: "Father reaches 0 HP. The battlefield falls silent." },
  { actor: "father", speaker: "Father", emotion: "calm", text: "Not yet.", effect: "spark", duration: 1800, caption: "The Mayonin blade rises at the last possible moment." },
  { actor: "arden", speaker: "Arden", emotion: "angry", text: "Then clash with me.", effect: "spark", duration: 1700, caption: "Steel collides. Sparks tear across the dark hall." },
  { actor: "father", speaker: "Father", emotion: "determined", text: "Show me what twenty years taught you.", effect: "spark", duration: 1900, caption: "The final Clash accelerates." },
  { actor: "arden", speaker: "Arden", emotion: "determined", text: "DEATH HIT.", effect: "blackout", duration: 1500, caption: "The screen goes completely black." },
  { actor: "arden", effect: "slash", duration: 1700, caption: "A single dangerous slash cuts through the silence." },
  { actor: "father", effect: "none", duration: 1900, caption: "Color returns. Arden stands far behind his father. His father remains frozen." },
  { actor: "father", effect: "none", duration: 2100, caption: "The father finally falls. The Mayonin sword slips from his hand." },
  { actor: "arden", speaker: "Arden", emotion: "fearful", text: "...Father.", duration: 1900, caption: "The victory does not feel like victory." },
  { actor: "arden", speaker: "Arden", emotion: "sad", text: "I was afraid of you. I still am. But I forgive you.", duration: 3000, caption: "Arden lowers his weapon." },
  { actor: "arden", effect: "chain", duration: 2200, caption: "Ancient chains behind his father begin to shake." },
  { actor: "arden", effect: "chain", duration: 2300, caption: "Arden pulls. One chain breaks. Then another." },
  { actor: "arden", effect: "resolve", duration: 2300, caption: "The final chain snaps. A light-filled relic falls into the dust." },
  { actor: "arden", speaker: "Arden", emotion: "shocked", text: "A broken sword...", duration: 2200, caption: "A fragment of an ancient blade glows in the darkness." },
  { actor: "arden", speaker: "Arden", emotion: "calm", text: "The Ancestor's Broken Blade. The earliest Mayonin ancestors forged it before the Empire became what we know.", duration: 3800, caption: "Its metal carries a quiet ancestral resonance." },
  { actor: "arden", speaker: "Arden", emotion: "determined", text: "They did not forge it to conquer. They forged it to protect what came after them.", duration: 3600, caption: "The Archive begins recording the relic." },
  { actor: "arden", speaker: "Arden", emotion: "determined", text: "Then I'll find out why they left it behind.", effect: "resolve", duration: 3000, caption: "NEW DISCOVERY — ANCESTOR'S BROKEN BLADE" },
];

function character(id: string) {
  if (id === "father") return { id: "father", name: "Father", mark: "F", color: "#8a1f24" };
  return CHAR_BY_ID[id];
}

export function CinematicScene({ background, onComplete }: { background: keyof typeof BG; onComplete: () => void }) {
  const [index, setIndex] = useState(0);
  const [black, setBlack] = useState(false);
  const done = useRef(false);
  const beat = BEATS[index];

  useEffect(() => {
    done.current = false;
    setBlack(beat.effect === "blackout");
    if (beat.speaker) {
      const id = beat.speaker.toLowerCase() === "father" ? "father" : beat.speaker.toLowerCase();
      playVoice(id);
    }
    if (beat.effect === "spark") sfxLib.spark();
    if (beat.effect === "slash") sfxLib.slash();
    if (beat.effect === "chain") sfxLib.chain();
    if (beat.effect === "blackout") sfxLib.blackout();
    if (beat.effect === "resolve") sfxLib.resolve();
    const timer = window.setTimeout(() => {
      if (index >= BEATS.length - 1) {
        if (!done.current) {
          done.current = true;
          onComplete();
        }
      } else {
        setIndex((v) => v + 1);
      }
    }, beat.duration);
    return () => window.clearTimeout(timer);
  }, [index]);

  function advance() {
    if (index >= BEATS.length - 1) {
      if (!done.current) {
        done.current = true;
        onComplete();
      }
      return;
    }
    setIndex((v) => v + 1);
  }

  const actor = beat.actor ? character(beat.actor) : undefined;
  return (
    <div className="mayonin-cinematic" style={{ backgroundImage: `url(${BG[background]})` }} onClick={advance}>
      <div className="mayonin-cinematic-vignette" />
      <div className="mayonin-cinematic-top">
        <Label>IMPERIAL END · FINAL SCENE</Label>
        <span>{index + 1}/{BEATS.length}</span>
      </div>

      {!black && (
        <>
          <div className="mayonin-actors">
            {actor && (
              <div className={`mayonin-actor ${actor.id === "father" ? "right" : "left"}`}>
                <Portrait name={actor.name} mark={actor.mark} color={actor.color} size="lg" emotion={beat.emotion} />
                <div className="mayonin-actor-name">{actor.name}</div>
              </div>
            )}
            {index <= 4 && (
              <div className="mayonin-sword-line" aria-hidden="true" />
            )}
          </div>
          {beat.effect === "spark" && <div className="mayonin-sparks" aria-hidden="true"><i/><i/><i/><i/><i/><i/></div>}
          {beat.effect === "slash" && <div className="mayonin-final-slash" aria-hidden="true" />}
          {beat.effect === "chain" && <div className="mayonin-chain-break" aria-hidden="true"><span/><span/><span/></div>}
          {index >= 12 && <div className="mayonin-relic" aria-hidden="true"><span className="mayonin-broken-blade">╲╱</span></div>}
        </>
      )}

      {black && <div className="mayonin-blackout" />}

      {(beat.speaker || beat.caption) && !black && (
        <div className="mayonin-dialogue" onClick={(e) => e.stopPropagation()}>
          {beat.speaker && <div className="mayonin-dialogue-name">{beat.speaker}</div>}
          {beat.text && <div className="mayonin-dialogue-text">{beat.text}</div>}
          {beat.caption && <div className="mayonin-dialogue-caption">{beat.caption}</div>}
        </div>
      )}

      {!beat.speaker && !black && beat.caption && (
        <div className="mayonin-cinematic-caption">{beat.caption}</div>
      )}

      {black && <div className="mayonin-death-hit">DEATH HIT</div>}
      <div className="mayonin-tap">Tap to continue · Scene advances automatically</div>
    </div>
  );
}
