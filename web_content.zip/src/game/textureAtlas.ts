import * as THREE from 'three';
import type {AtlasTileId, QualityTier} from './types';

export interface AtlasTileMeta {
  id: AtlasTileId;
  label: string;
  col: number;
  row: number;
  u0: number;
  v0: number;
  u1: number;
  v1: number;
  roughness: number;
  metalness: number;
}

export interface TextureAtlasBundle {
  albedoCanvas: HTMLCanvasElement;
  albedoTexture: THREE.CanvasTexture;
  roughnessTexture: THREE.CanvasTexture | null;
  material: THREE.MeshStandardMaterial;
  tiles: Record<AtlasTileId, AtlasTileMeta>;
  tileList: AtlasTileMeta[];
  resolution: number;
  tileSizePx: number;
  gutterPx: number;
  remapBoxUVs: (geometry: THREE.BufferGeometry, tileId: AtlasTileId, repeatU?: number, repeatV?: number) => THREE.BufferGeometry;
  dispose: () => void;
}

const TILE_ORDER: {id: AtlasTileId; label: string; roughness: number; metalness: number}[] = [
  {id: 'asphalt_road', label: 'Asphalt Road', roughness: 0.9, metalness: 0.04},
  {id: 'road_lane_yellow', label: 'Highway Lanes', roughness: 0.88, metalness: 0.04},
  {id: 'road_crosswalk', label: 'Crosswalk', roughness: 0.88, metalness: 0.04},
  {id: 'sidewalk_concrete', label: 'Sidewalk Pavers', roughness: 0.85, metalness: 0.02},
  {id: 'skyscraper_glass', label: 'Glass Curtain Wall', roughness: 0.22, metalness: 0.65},
  {id: 'skyscraper_stone', label: 'Reserve Limestone', roughness: 0.72, metalness: 0.08},
  {id: 'mansion_stucco', label: 'Vinecrest Stucco', roughness: 0.78, metalness: 0.04},
  {id: 'storefront_luxury', label: 'Vangelico Facade', roughness: 0.35, metalness: 0.45},
  {id: 'desert_sand', label: 'Sandy Flats Dirt', roughness: 0.95, metalness: 0.0},
  {id: 'airfield_runway', label: 'Airfield Tarmac', roughness: 0.85, metalness: 0.05},
  {id: 'cargo_steel', label: 'Cargo Container', roughness: 0.55, metalness: 0.45},
  {id: 'water_tile', label: 'Harbor Pier', roughness: 0.65, metalness: 0.1},
  {id: 'grass_park', label: 'Palms Turf', roughness: 0.92, metalness: 0.0},
  {id: 'foliage_palm', label: 'Palm Frond & Bark', roughness: 0.82, metalness: 0.0},
  {id: 'brick_southside', label: 'Southside Brick', roughness: 0.86, metalness: 0.04},
  {id: 'metal_trim', label: 'Gunmetal Trim', roughness: 0.38, metalness: 0.75},
];

function pseudoRand(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (1664525 * s + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function drawTileContent(ctx: CanvasRenderingContext2D, tileId: AtlasTileId, x: number, y: number, w: number, h: number) {
  const rand = pseudoRand(tileId.length * 997 + tileId.charCodeAt(0) * 131);
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, w, h);
  ctx.clip();

  const u = (frac: number) => x + frac * w;
  const v = (frac: number) => y + frac * h;

  switch (tileId) {
    case 'asphalt_road': {
      ctx.fillStyle = '#242933';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 420; i++) {
        const shade = 28 + Math.floor(rand() * 24);
        ctx.fillStyle = `rgb(${shade},${shade + 3},${shade + 8})`;
        ctx.fillRect(u(rand()), v(rand()), Math.max(1, w * 0.015), Math.max(1, h * 0.015));
      }
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.fillRect(x, y, w, h * 0.04);
      ctx.fillRect(x, y + h * 0.96, w, h * 0.04);
      break;
    }

    case 'road_lane_yellow': {
      ctx.fillStyle = '#232832';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 320; i++) {
        const shade = 26 + Math.floor(rand() * 22);
        ctx.fillStyle = `rgb(${shade},${shade + 2},${shade + 7})`;
        ctx.fillRect(u(rand()), v(rand()), Math.max(1, w * 0.015), Math.max(1, h * 0.015));
      }
      // Side solid white edge lines
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(u(0.05), y, w * 0.025, h);
      ctx.fillRect(u(0.925), y, w * 0.025, h);
      // Center double amber divider
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(u(0.475), y, w * 0.018, h);
      ctx.fillRect(u(0.507), y, w * 0.018, h);
      // Dashed lane markings
      ctx.fillStyle = 'rgba(226,232,240,0.75)';
      for (let row = 0; row < 4; row++) {
        ctx.fillRect(u(0.25), v(row * 0.25 + 0.05), w * 0.016, h * 0.13);
        ctx.fillRect(u(0.735), v(row * 0.25 + 0.05), w * 0.016, h * 0.13);
      }
      break;
    }

    case 'road_crosswalk': {
      ctx.fillStyle = '#232832';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#e2e8f0';
      for (let i = 0; i < 6; i++) {
        ctx.fillRect(u(0.07 + i * 0.155), v(0.22), w * 0.095, h * 0.56);
      }
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(x, v(0.1), w, h * 0.05);
      ctx.fillRect(x, v(0.85), w, h * 0.05);
      break;
    }

    case 'sidewalk_concrete': {
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#a6b3c4';
      ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
      ctx.strokeStyle = 'rgba(30,41,59,0.28)';
      ctx.lineWidth = Math.max(1, w * 0.012);
      for (let i = 1; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(u(i * 0.25), y);
        ctx.lineTo(u(i * 0.25), y + h);
        ctx.moveTo(x, v(i * 0.25));
        ctx.lineTo(x + w, v(i * 0.25));
        ctx.stroke();
      }
      for (let i = 0; i < 140; i++) {
        ctx.fillStyle = rand() > 0.5 ? 'rgba(255,255,255,0.08)' : 'rgba(15,23,42,0.08)';
        ctx.fillRect(u(rand()), v(rand()), Math.max(1, w * 0.012), Math.max(1, h * 0.012));
      }
      break;
    }

    case 'skyscraper_glass': {
      const grad = ctx.createLinearGradient(x, y, x, y + h);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(1, '#1e293b');
      ctx.fillStyle = grad;
      ctx.fillRect(x, y, w, h);
      const cols = 6;
      const rows = 8;
      const padX = w * 0.025;
      const padY = h * 0.02;
      const cellW = w / cols;
      const cellH = h / rows;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const lit = rand();
          if (lit > 0.72) {
            ctx.fillStyle = '#fef3c7';
          } else if (lit > 0.42) {
            ctx.fillStyle = '#38bdf8';
          } else {
            ctx.fillStyle = '#1e3a5f';
          }
          ctx.fillRect(x + c * cellW + padX, y + r * cellH + padY, cellW - padX * 2, cellH - padY * 2);
          ctx.fillStyle = 'rgba(255,255,255,0.18)';
          ctx.fillRect(x + c * cellW + padX, y + r * cellH + padY, cellW - padX * 2, (cellH - padY * 2) * 0.25);
        }
      }
      break;
    }

    case 'skyscraper_stone': {
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#94a3b8';
      for (let r = 0; r < 8; r++) {
        ctx.fillRect(x, y + r * (h / 8), w, h * 0.018);
      }
      for (let r = 0; r < 4; r++) {
        for (let c = 0; c < 4; c++) {
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(u(0.06 + c * 0.24), v(0.06 + r * 0.24), w * 0.14, h * 0.16);
          ctx.fillStyle = '#64748b';
          ctx.fillRect(u(0.07 + c * 0.24), v(0.07 + r * 0.24), w * 0.12, h * 0.03);
        }
      }
      break;
    }

    case 'mansion_stucco': {
      ctx.fillStyle = '#f1efe8';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#d6cfc2';
      ctx.fillRect(x, y, w, h * 0.08);
      ctx.fillRect(x, v(0.5), w, h * 0.04);
      // Warm modern glass panes
      for (let c = 0; c < 3; c++) {
        ctx.fillStyle = '#1f2937';
        ctx.fillRect(u(0.08 + c * 0.3), v(0.14), w * 0.22, h * 0.28);
        ctx.fillStyle = '#fbbf24';
        ctx.globalAlpha = 0.28;
        ctx.fillRect(u(0.09 + c * 0.3), v(0.15), w * 0.2, h * 0.26);
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#1f2937';
        ctx.fillRect(u(0.08 + c * 0.3), v(0.6), w * 0.22, h * 0.3);
      }
      break;
    }

    case 'storefront_luxury': {
      ctx.fillStyle = '#111827';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#d97706';
      ctx.fillRect(x, v(0.08), w, h * 0.08);
      ctx.fillStyle = '#0ea5e9';
      ctx.globalAlpha = 0.35;
      ctx.fillRect(u(0.08), v(0.28), w * 0.38, h * 0.62);
      ctx.fillRect(u(0.54), v(0.28), w * 0.38, h * 0.62);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = Math.max(1, w * 0.015);
      ctx.strokeRect(u(0.08), v(0.28), w * 0.38, h * 0.62);
      ctx.strokeRect(u(0.54), v(0.28), w * 0.38, h * 0.62);
      break;
    }

    case 'desert_sand': {
      ctx.fillStyle = '#c89b68';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 380; i++) {
        ctx.fillStyle = rand() > 0.5 ? '#b38352' : '#ddb482';
        ctx.fillRect(u(rand()), v(rand()), Math.max(1, w * 0.025), Math.max(1, h * 0.014));
      }
      break;
    }

    case 'airfield_runway': {
      ctx.fillStyle = '#333942';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#e5e7eb';
      ctx.fillRect(u(0.06), y, w * 0.03, h);
      ctx.fillRect(u(0.91), y, w * 0.03, h);
      ctx.fillStyle = '#facc15';
      for (let i = 0; i < 4; i++) {
        ctx.fillRect(u(0.475), v(i * 0.25 + 0.04), w * 0.05, h * 0.14);
      }
      break;
    }

    case 'cargo_steel': {
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 12; i++) {
        ctx.fillStyle = i % 2 === 0 ? 'rgba(0,0,0,0.22)' : 'rgba(255,255,255,0.1)';
        ctx.fillRect(x + i * (w / 12), y, w / 24, h);
      }
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(u(0.15), v(0.35), w * 0.45, h * 0.14);
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(x, y, w, h * 0.06);
      ctx.fillRect(x, v(0.94), w, h * 0.06);
      break;
    }

    case 'water_tile': {
      ctx.fillStyle = '#475569';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 8; i++) {
        ctx.fillStyle = i % 2 === 0 ? '#64748b' : '#475569';
        ctx.fillRect(x, y + i * (h / 8), w, h / 8 - 1);
      }
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(x, v(0.88), w, h * 0.12);
      break;
    }

    case 'grass_park': {
      ctx.fillStyle = '#3b6e3c';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 320; i++) {
        ctx.fillStyle = rand() > 0.5 ? '#488249' : '#2f5b30';
        ctx.fillRect(u(rand()), v(rand()), Math.max(1, w * 0.02), Math.max(1, h * 0.02));
      }
      break;
    }

    case 'foliage_palm': {
      ctx.fillStyle = '#4b3621';
      ctx.fillRect(x, y, w, h);
      for (let i = 0; i < 10; i++) {
        ctx.fillStyle = i % 2 === 0 ? '#5c4228' : '#3d2b1a';
        ctx.fillRect(x, y + i * (h / 10), w, h / 12);
      }
      break;
    }

    case 'brick_southside': {
      ctx.fillStyle = '#7c3f2c';
      ctx.fillRect(x, y, w, h);
      const bRows = 8;
      const bCols = 4;
      for (let r = 0; r < bRows; r++) {
        const offset = (r % 2) * (w / (bCols * 2));
        for (let c = -1; c <= bCols; c++) {
          ctx.fillStyle = rand() > 0.4 ? '#8c4732' : '#6c3525';
          ctx.fillRect(
            x + c * (w / bCols) + offset + 2,
            y + r * (h / bRows) + 2,
            w / bCols - 4,
            h / bRows - 4,
          );
        }
      }
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(u(0.18), v(0.22), w * 0.24, h * 0.28);
      ctx.fillRect(u(0.58), v(0.22), w * 0.24, h * 0.28);
      break;
    }

    case 'metal_trim': {
      const grad = ctx.createLinearGradient(x, y, x + w, y + h);
      grad.addColorStop(0, '#334155');
      grad.addColorStop(0.5, '#64748b');
      grad.addColorStop(1, '#1e293b');
      ctx.fillStyle = grad;
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(x, v(0.85), w, h * 0.15);
      break;
    }
  }
  ctx.restore();
}

function drawTileWithGutter(
  ctx: CanvasRenderingContext2D,
  tileId: AtlasTileId,
  slotX: number,
  slotY: number,
  slotSize: number,
  gutter: number,
) {
  const innerSize = slotSize - gutter * 2;
  const innerX = slotX + gutter;
  const innerY = slotY + gutter;
  // Draw inner tile
  drawTileContent(ctx, tileId, innerX, innerY, innerSize, innerSize);
  // Edge bleed clamping into gutter so mipmaps / linear filtering never bleed into neighbors
  if (gutter > 0) {
    // Top gutter
    ctx.drawImage(ctx.canvas, innerX, innerY, innerSize, 1, innerX, slotY, innerSize, gutter);
    // Bottom gutter
    ctx.drawImage(ctx.canvas, innerX, innerY + innerSize - 1, innerSize, 1, innerX, innerY + innerSize, innerSize, gutter);
    // Left gutter
    ctx.drawImage(ctx.canvas, innerX, slotY, 1, slotSize, slotX, slotY, gutter, slotSize);
    // Right gutter
    ctx.drawImage(ctx.canvas, innerX + innerSize - 1, slotY, 1, slotSize, innerX + innerSize, slotY, gutter, slotSize);
  }
}

export function createTextureAtlas(tier: QualityTier, maxAnisotropy: number): TextureAtlasBundle {
  const resolution = tier === 'pc-high' ? 2048 : tier === 'mobile-balanced' ? 1024 : 512;
  const gridCols = 4;
  const slotSize = resolution / gridCols;
  const gutterPx = tier === 'pc-high' ? 8 : tier === 'mobile-balanced' ? 4 : 2;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = resolution;
  albedoCanvas.height = resolution;
  const ctx = albedoCanvas.getContext('2d')!;
  ctx.fillStyle = '#111827';
  ctx.fillRect(0, 0, resolution, resolution);

  let roughCanvas: HTMLCanvasElement | null = null;
  let roughCtx: CanvasRenderingContext2D | null = null;
  if (tier !== 'mobile-eco') {
    roughCanvas = document.createElement('canvas');
    roughCanvas.width = resolution;
    roughCanvas.height = resolution;
    roughCtx = roughCanvas.getContext('2d');
  }

  const tiles = {} as Record<AtlasTileId, AtlasTileMeta>;
  const tileList: AtlasTileMeta[] = [];

  TILE_ORDER.forEach((entry, index) => {
    const col = index % gridCols;
    const row = Math.floor(index / gridCols);
    const slotX = col * slotSize;
    const slotY = row * slotSize;

    drawTileWithGutter(ctx, entry.id, slotX, slotY, slotSize, gutterPx);

    if (roughCtx) {
      const rVal = Math.round(entry.roughness * 255);
      roughCtx.fillStyle = `rgb(${rVal},${rVal},${rVal})`;
      roughCtx.fillRect(slotX, slotY, slotSize, slotSize);
    }

    // Canvas Y=0 is top, WebGL UV v=1 is top (because flipY=true by default on CanvasTexture)
    const innerSize = slotSize - gutterPx * 2;
    const u0 = (slotX + gutterPx) / resolution;
    const u1 = (slotX + gutterPx + innerSize) / resolution;
    const v1 = 1 - (slotY + gutterPx) / resolution;
    const v0 = 1 - (slotY + gutterPx + innerSize) / resolution;

    const meta: AtlasTileMeta = {
      id: entry.id,
      label: entry.label,
      col,
      row,
      u0,
      v0,
      u1,
      v1,
      roughness: entry.roughness,
      metalness: entry.metalness,
    };
    tiles[entry.id] = meta;
    tileList.push(meta);
  });

  const albedoTexture = new THREE.CanvasTexture(albedoCanvas);
  albedoTexture.colorSpace = THREE.SRGBColorSpace;
  albedoTexture.wrapS = THREE.ClampToEdgeWrapping;
  albedoTexture.wrapT = THREE.ClampToEdgeWrapping;
  albedoTexture.minFilter = THREE.LinearMipmapLinearFilter;
  albedoTexture.magFilter = THREE.LinearFilter;
  albedoTexture.anisotropy = tier === 'pc-high' ? Math.min(maxAnisotropy, 16) : tier === 'mobile-balanced' ? Math.min(maxAnisotropy, 4) : 1;
  albedoTexture.needsUpdate = true;

  let roughnessTexture: THREE.CanvasTexture | null = null;
  if (roughCanvas) {
    roughnessTexture = new THREE.CanvasTexture(roughCanvas);
    roughnessTexture.wrapS = THREE.ClampToEdgeWrapping;
    roughnessTexture.wrapT = THREE.ClampToEdgeWrapping;
    roughnessTexture.minFilter = THREE.LinearMipmapLinearFilter;
    roughnessTexture.magFilter = THREE.LinearFilter;
    roughnessTexture.needsUpdate = true;
  }

  const material = new THREE.MeshStandardMaterial({
    map: albedoTexture,
    roughnessMap: roughnessTexture ?? undefined,
    roughness: roughnessTexture ? 1.0 : 0.78,
    metalness: 0.08,
    envMapIntensity: 0.9,
  });

  const remapBoxUVs = (
    geometry: THREE.BufferGeometry,
    tileId: AtlasTileId,
    repeatU = 1,
    repeatV = 1,
  ): THREE.BufferGeometry => {
    const meta = tiles[tileId];
    const uvAttr = geometry.attributes.uv;
    if (!uvAttr) return geometry;
    const du = meta.u1 - meta.u0;
    const dv = meta.v1 - meta.v0;
    for (let i = 0; i < uvAttr.count; i++) {
      const rawU = uvAttr.getX(i) * repeatU;
      const rawV = uvAttr.getY(i) * repeatV;
      // Clamp/wrap into [0,1] safely inside tile rect
      const uClamped = rawU > 1 ? rawU - Math.floor(rawU) || 1 : rawU < 0 ? rawU - Math.floor(rawU) : rawU;
      const vClamped = rawV > 1 ? rawV - Math.floor(rawV) || 1 : rawV < 0 ? rawV - Math.floor(rawV) : rawV;
      uvAttr.setXY(i, meta.u0 + uClamped * du, meta.v0 + vClamped * dv);
    }
    uvAttr.needsUpdate = true;
    return geometry;
  };

  return {
    albedoCanvas,
    albedoTexture,
    roughnessTexture,
    material,
    tiles,
    tileList,
    resolution,
    tileSizePx: slotSize - gutterPx * 2,
    gutterPx,
    remapBoxUVs,
    dispose: () => {
      albedoTexture.dispose();
      roughnessTexture?.dispose();
      material.dispose();
    },
  };
}
