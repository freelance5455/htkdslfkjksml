import * as THREE from 'three';
import { SpatialHint } from '../audio/soundEngine';
import {
  ALL_ENTITY_DEFS,
  BOSSES,
  CREATURES,
  MONSTERS,
  SKELETON_MONSTERS,
  VILLAGE_CENTER,
  VILLAGE_NPCS,
} from '../data/entities';
import { BuiltEntityVisual, SharedEntityGeometryPool } from '../entities/entityModels';
import {
  ActiveBossHud,
  ActiveSummonEntry,
  BestiaryRecord,
  BiomeId,
  DungeonPortalInfo,
  ElementId,
  EntityArchetype,
  EntityRank,
  EntityTemplateDef,
  LocationKind,
  NpcDefinition,
  OverheadNameplate,
  SkeletonVariant,
  TargetEnemyHud,
} from '../types';
import { CombatVfxPool } from '../vfx/combatPool';
import { getBiomeIdAt, getWorldHeight, WATER_LEVEL } from '../world/biomes';
import { DungeonEnemySpawn, DungeonInstance } from '../world/dungeonGenerator';

const _projVec = new THREE.Vector3();
const _measureBox = new THREE.Box3();

function resolveEntityRank(def: EntityTemplateDef): EntityRank {
  if (def.rank) return def.rank;
  if (def.category === 'boss') return 'boss';
  if (def.skeletonVariant === 'commander') return 'elite';
  if (def.skeletonVariant === 'rare') return 'rare';
  return 'common';
}

interface LiveEntity {
  uid: string;
  def: EntityTemplateDef;
  visual: BuiltEntityVisual;
  rank: EntityRank;
  scaleMult: number;
  attackMult: number;
  headOffsetY: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  hp: number;
  displayHp: number;
  trailHp: number;
  maxHp: number;
  level: number;
  isSummon: boolean;
  isRebel: boolean;
  durationSec: number;
  remainingSec: number;
  supportCd: number;
  isDungeonEnemy: boolean;
  isDungeonBoss: boolean;
  isHostile: boolean;
  state: 'idle' | 'wander' | 'chase' | 'flee';
  wanderAngle: number;
  wanderTimer: number;
  attackCd: number;
  rangedCd: number;
  hitFlash: number;
  attackAnimTimer: number;
  dyingTimer: number;
  spawnProgress: number;
  phase: 1 | 2;
  animTime: number;
  aiAccum: number;
  killReported: boolean;
  rallyTimer: number;
  combatTime: number;
  evolved: boolean;
  skillTimer: number;
  telegraphTimer: number;
  pendingSkillIdx: number;
  activeSkillAr: string | null;
}

interface LiveNpc {
  def: NpcDefinition;
  visual: BuiltEntityVisual;
  homeX: number;
  homeZ: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  attackCd: number;
  animTime: number;
  strollAngle: number;
  strollTimer: number;
}

interface EnemyBolt {
  active: boolean;
  mesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  damage: number;
}

export interface EntityKillEvent {
  def: EntityTemplateDef;
  x: number;
  y: number;
  z: number;
  isDungeonBoss: boolean;
  rank?: EntityRank;
  bySummon?: boolean;
  wasRebelSummon?: boolean;
}

export type CreatureSoundCb = (
  archetype: EntityArchetype,
  action: 'aggro' | 'hit' | 'death',
  spatial?: SpatialHint,
  variant?: SkeletonVariant,
) => void;

export interface EntityUpdateContext {
  dt: number;
  playerX: number;
  playerY: number;
  playerZ: number;
  playerYaw: number;
  viewDistanceMeters: number;
  inDungeon: boolean;
  dungeon: DungeonInstance | null;
  seed: number;
  isNight: boolean;
  nearbyLocationKind?: LocationKind | null;
  combatVfx: CombatVfxPool;
  bestiary: Record<string, BestiaryRecord>;
  onPlayerDamaged: (rawDamage: number, attackerNameAr: string) => void;
  onEntityDiscovered: (def: EntityTemplateDef) => void;
  onEntityEvolved?: (oldDef: EntityTemplateDef, newDef: EntityTemplateDef) => void;
  onSummonExpired?: (uid: string, def: EntityTemplateDef, wasRebel: boolean) => void;
  onSupportPulse?: (def: EntityTemplateDef) => void;
  onGuardKill: (evt: EntityKillEvent) => void;
  onCreatureSound?: CreatureSoundCb;
}

function lerpAngle(current: number, target: number, factor: number): number {
  let diff = ((target - current + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return current + diff * factor;
}

export class EntityManager {
  private scene: THREE.Scene;
  private pool: SharedEntityGeometryPool;
  private entities: LiveEntity[] = [];
  private npcs: LiveNpc[] = [];
  private interiorGuards: LiveNpc[] = [];
  private bolts: EnemyBolt[] = [];
  private boltGeo: THREE.SphereGeometry;
  private boltMats: THREE.MeshBasicMaterial[] = [];

  private spawnTimer = 0.6;
  private uidCounter = 1;
  private castShadows = false;
  private lastPlayerX = 0;
  private lastPlayerZ = 0;
  private lastPlayerYaw = 0;
  private targetUid: string | null = null;
  private targetDecay = 0;
  public inCombat = false;

  constructor(scene: THREE.Scene, seed: number, castShadows: boolean) {
    this.scene = scene;
    this.castShadows = castShadows;
    this.pool = new SharedEntityGeometryPool();

    for (const def of VILLAGE_NPCS) {
      const visual = this.pool.buildNpc(def, castShadows);
      const y = getWorldHeight(def.x, def.z, seed);
      visual.root.position.set(def.x, y, def.z);
      this.scene.add(visual.root);
      this.npcs.push({
        def,
        visual,
        homeX: def.x,
        homeZ: def.z,
        x: def.x,
        y,
        z: def.z,
        yaw: 0,
        attackCd: 0,
        animTime: Math.random() * 5,
        strollAngle: Math.random() * Math.PI * 2,
        strollTimer: 2 + Math.random() * 4,
      });
    }

    this.boltGeo = new THREE.SphereGeometry(0.24, 8, 6);
    for (let i = 0; i < 8; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xf43f5e });
      this.boltMats.push(mat);
      const mesh = new THREE.Mesh(this.boltGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.bolts.push({
        active: false,
        mesh,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        damage: 10,
      });
    }
  }

  public setShadowCasting(cast: boolean): void {
    this.castShadows = cast;
    const applyTo = (list: Array<{ visual: BuiltEntityVisual }>) => {
      for (const item of list) {
        item.visual.root.traverse((o) => {
          if ((o as THREE.Mesh).isMesh) {
            o.castShadow = cast;
            o.receiveShadow = cast;
          }
        });
      }
    };
    applyTo(this.npcs);
    applyTo(this.interiorGuards);
    applyTo(this.entities);
  }

  public setVillageVisible(visible: boolean): void {
    for (const npc of this.npcs) {
      npc.visual.root.visible = visible;
    }
  }

  public clearOverworldEntities(): void {
    for (let i = this.entities.length - 1; i >= 0; i--) {
      if (!this.entities[i].isSummon) {
        this.removeEntityAt(i);
      }
    }
    this.clearBolts();
  }

  public clearDungeonEntities(): void {
    for (let i = this.entities.length - 1; i >= 0; i--) {
      if (this.entities[i].isDungeonEnemy) {
        this.removeEntityAt(i);
      }
    }
    for (const g of this.interiorGuards) {
      this.scene.remove(g.visual.root);
      g.visual.disposeMaterials();
    }
    this.interiorGuards.length = 0;
    this.clearBolts();
  }

  private clearBolts(): void {
    for (const b of this.bolts) {
      b.active = false;
      b.mesh.visible = false;
    }
  }

  public addSummon(
    entityId: string,
    playerX: number,
    playerY: number,
    playerZ: number,
    opts?: { durationSec?: number; isRebel?: boolean; masteryLevel?: number },
  ): ActiveSummonEntry | null {
    const def = ALL_ENTITY_DEFS[entityId];
    if (!def) return null;

    const currentSummons = this.entities.filter((e) => e.isSummon && e.hp > 0);
    if (currentSummons.length >= 3) {
      const oldestIdx = this.entities.findIndex((e) => e.isSummon);
      if (oldestIdx >= 0) this.removeEntityAt(oldestIdx);
    }

    const visual = this.pool.buildCreatureOrMonster(def, this.castShadows);
    visual.root.position.set(0, 0, 0);
    visual.root.updateMatrixWorld(true);
    _measureBox.setFromObject(visual.root);
    const headOffsetY = Math.max(
      1.2,
      (_measureBox.isEmpty() ? 1.8 * def.scale : _measureBox.max.y) + 0.35,
    );

    const slotOffset = currentSummons.length;
    const ang = slotOffset * 2.1 + 0.7;
    const sx = playerX + Math.cos(ang) * 2.2;
    const sz = playerZ + Math.sin(ang) * 2.2;
    visual.root.position.set(sx, playerY, sz);
    this.scene.add(visual.root);

    const masteryMult = 1 + Math.max(0, (opts?.masteryLevel ?? 1) - 1) * 0.04;
    const isRebel = Boolean(opts?.isRebel);
    const durationSec = opts?.durationSec ?? def.summonDurationSec ?? 45;
    const maxHp = Math.round(def.maxHp * 1.85 * masteryMult);

    const ent: LiveEntity = {
      uid: `summon_${this.uidCounter++}`,
      def,
      visual,
      rank: resolveEntityRank(def),
      scaleMult: 1,
      attackMult: masteryMult,
      headOffsetY,
      x: sx,
      y: playerY,
      z: sz,
      yaw: 0,
      hp: maxHp,
      displayHp: maxHp,
      trailHp: maxHp,
      maxHp,
      level: def.level,
      isSummon: true,
      isRebel,
      durationSec,
      remainingSec: durationSec,
      supportCd: 3.5,
      isDungeonEnemy: false,
      isDungeonBoss: false,
      isHostile: isRebel,
      state: isRebel ? 'chase' : 'idle',
      wanderAngle: 0,
      wanderTimer: 1,
      attackCd: 0.4,
      rangedCd: 0.8,
      hitFlash: 0,
      attackAnimTimer: 0,
      dyingTimer: 0,
      spawnProgress: 0.25,
      phase: 1,
      animTime: 0,
      aiAccum: 0,
      killReported: false,
      rallyTimer: 0,
      combatTime: 0,
      evolved: false,
      skillTimer: 99,
      telegraphTimer: 0,
      pendingSkillIdx: 0,
      activeSkillAr: null,
    };

    if (isRebel) {
      visual.primaryMat.emissive.setHex(0xef4444);
      visual.primaryMat.emissiveIntensity = 0.42;
    }

    this.entities.push(ent);
    return this.toSummonHudEntry(ent);
  }

  public syncSummons(
    entityIds: string[],
    playerX: number,
    playerY: number,
    playerZ: number,
    masteryLevel = 1,
  ): void {
    this.clearAllSummons();
    for (let i = 0; i < Math.min(3, entityIds.length); i++) {
      this.addSummon(entityIds[i], playerX, playerY, playerZ, { masteryLevel });
    }
  }

  public syncSummon(
    entityId: string | null,
    playerX: number,
    playerY: number,
    playerZ: number,
  ): void {
    if (!entityId) {
      this.clearAllSummons();
      return;
    }
    const existing = this.entities.find((e) => e.isSummon);
    if (existing && existing.def.id === entityId) return;
    this.clearAllSummons();
    this.addSummon(entityId, playerX, playerY, playerZ);
  }

  public removeSummonByUid(uid?: string): boolean {
    if (!uid) {
      const had = this.entities.some((e) => e.isSummon);
      this.clearAllSummons();
      return had;
    }
    const idx = this.entities.findIndex((e) => e.isSummon && e.uid === uid);
    if (idx < 0) return false;
    this.removeEntityAt(idx);
    return true;
  }

  public clearAllSummons(): void {
    for (let i = this.entities.length - 1; i >= 0; i--) {
      if (this.entities[i].isSummon) this.removeEntityAt(i);
    }
  }

  public reclaimSummon(uid: string): EntityTemplateDef | null {
    const ent = this.entities.find((e) => e.isSummon && e.uid === uid && e.isRebel && e.hp > 0);
    if (!ent) return null;
    ent.isRebel = false;
    ent.isHostile = false;
    ent.state = 'idle';
    ent.remainingSec = Math.max(ent.remainingSec, Math.round(ent.durationSec * 0.75));
    ent.visual.primaryMat.emissive.setHex(0x000000);
    ent.visual.primaryMat.emissiveIntensity = 0;
    return ent.def;
  }

  public getSummonByUid(uid: string): ActiveSummonEntry | null {
    const ent = this.entities.find((e) => e.isSummon && e.uid === uid && e.hp > 0);
    return ent ? this.toSummonHudEntry(ent) : null;
  }

  public getActiveSummonsHud(): ActiveSummonEntry[] {
    const res: ActiveSummonEntry[] = [];
    for (const ent of this.entities) {
      if (ent.isSummon && ent.hp > 0) {
        res.push(this.toSummonHudEntry(ent));
      }
    }
    return res;
  }

  public getUsedSoulPower(includeRebels = false): number {
    let sum = 0;
    for (const ent of this.entities) {
      if (ent.isSummon && ent.hp > 0 && (includeRebels || !ent.isRebel)) {
        sum += ent.def.soulPower ?? 8;
      }
    }
    return sum;
  }

  private toSummonHudEntry(ent: LiveEntity): ActiveSummonEntry {
    return {
      uid: ent.uid,
      entityId: ent.def.id,
      nameAr: ent.def.nameAr,
      role: ent.def.summonRole ?? 'dps',
      rank: ent.rank,
      soulPower: ent.def.soulPower ?? 8,
      hp: Math.max(0, Math.round(ent.hp)),
      maxHp: ent.maxHp,
      remainingSec: Math.max(0, Math.round(ent.remainingSec)),
      durationSec: ent.durationSec,
      isRebel: ent.isRebel,
    };
  }

  public spawnDungeonEntities(portal: DungeonPortalInfo, spawns: DungeonEnemySpawn[]): void {
    this.clearOverworldEntities();
    this.clearDungeonEntities();

    const biomePool = MONSTERS.filter((m) => m.biomeIds.includes(portal.biomeId));
    const monsterPool = biomePool.length > 0 ? biomePool : MONSTERS;
    const undeadFavored =
      portal.kind === 'crypt' ||
      portal.kind === 'ruin' ||
      portal.subtype === 'abandoned_castle' ||
      portal.subtype === 'monster_castle';

    const bossPool = BOSSES.filter((b) => b.biomeIds.includes(portal.biomeId));
    const bossDef =
      portal.kind === 'crypt'
        ? BOSSES.find((b) => b.id === 'boss_bone_dragon') ?? BOSSES[0]
        : portal.kind === 'castle'
          ? BOSSES.find((b) => b.id === 'boss_shadow_lord' || b.id === 'boss_ice_king') ??
            bossPool[0] ??
            BOSSES[0]
          : bossPool[0] ?? BOSSES[0];

    for (let i = 0; i < spawns.length; i++) {
      const sp = spawns[i];
      if (sp.isFriendlyGuard) {
        const guardDef: NpcDefinition = {
          id: `castle_guard_${i}`,
          nameAr: i === 0 ? 'فارس القلعة باسل' : 'فارس القلعة ليث',
          role: 'guard',
          titleAr: 'حارس القلعة الملكية',
          greetingAr: 'الوحوش تسللت إلى أعماق القلعة! سنساعدك في القتال وحماية الكنوز.',
          x: sp.x,
          z: sp.z,
          robeHex: 0x334155,
          accentHex: 0xfbbf24,
        };
        const visual = this.pool.buildNpc(guardDef, this.castShadows);
        visual.root.position.set(sp.x, 0, sp.z);
        this.scene.add(visual.root);
        this.interiorGuards.push({
          def: guardDef,
          visual,
          homeX: sp.x,
          homeZ: sp.z,
          x: sp.x,
          y: 0,
          z: sp.z,
          yaw: Math.PI,
          attackCd: 0,
          animTime: i * 1.2,
          strollAngle: 0,
          strollTimer: 5,
        });
        continue;
      }

      if (sp.isBoss) {
        const scaledHp = Math.round(bossDef.maxHp * (0.65 + portal.level * 0.06));
        this.spawnOne(bossDef, sp.x, 0, sp.z, {
          isDungeonEnemy: true,
          isDungeonBoss: true,
          levelOverride: Math.max(portal.level + 2, bossDef.level),
          hpOverride: scaledHp,
        });
      } else {
        const useSkel = undeadFavored
          ? i % 3 !== 2
          : portal.kind === 'cave' && i % 4 === 0;
        let mDef: EntityTemplateDef;
        if (useSkel) {
          if (i === spawns.length - 2 && portal.level >= 5) {
            mDef = SKELETON_MONSTERS.find((s) => s.skeletonVariant === 'commander') ?? SKELETON_MONSTERS[0];
          } else {
            const normalSkels = SKELETON_MONSTERS.filter(
              (s) => s.skeletonVariant !== 'commander' && s.skeletonVariant !== 'rare',
            );
            mDef = normalSkels[(i + portal.level) % normalSkels.length];
          }
        } else {
          mDef = monsterPool[(i + portal.level) % monsterPool.length];
        }
        const scaledHp = Math.round(mDef.maxHp * (0.85 + portal.level * 0.08));
        this.spawnOne(mDef, sp.x, 0, sp.z, {
          isDungeonEnemy: true,
          isDungeonBoss: false,
          levelOverride: portal.level,
          hpOverride: scaledHp,
        });
      }
    }
  }

  public spawnWorldEventWave(
    kind: 'skeleton_raid' | 'wolf_pack' | 'rare_elite',
    playerX: number,
    playerZ: number,
    seed: number,
  ): string {
    const baseAngle = Math.random() * Math.PI * 2;
    const spawnNear = (def: EntityTemplateDef, angOffset: number, dist: number) => {
      const sx = playerX + Math.cos(baseAngle + angOffset) * dist;
      const sz = playerZ + Math.sin(baseAngle + angOffset) * dist;
      const sy = getWorldHeight(sx, sz, seed);
      if (sy < WATER_LEVEL + 0.35) return;
      this.spawnOne(def, sx, sy, sz, {
        isDungeonEnemy: false,
        isDungeonBoss: false,
      });
    };

    if (kind === 'skeleton_raid') {
      const warrior = SKELETON_MONSTERS.find((s) => s.skeletonVariant === 'warrior') ?? SKELETON_MONSTERS[0];
      const archer = SKELETON_MONSTERS.find((s) => s.skeletonVariant === 'archer') ?? SKELETON_MONSTERS[1];
      const guard = SKELETON_MONSTERS.find((s) => s.skeletonVariant === 'guard') ?? SKELETON_MONSTERS[6];
      spawnNear(warrior, -0.35, 19);
      spawnNear(archer, 0.0, 22);
      spawnNear(guard, 0.35, 19);
      return 'غارة هياكل عظمية قريبة!';
    }
    if (kind === 'wolf_pack') {
      const wolf =
        MONSTERS.find((m) => m.id === 'm_shadow_wolf') ??
        MONSTERS.find((m) => m.archetype === 'quadruped') ??
        MONSTERS[0];
      spawnNear(wolf, -0.4, 18);
      spawnNear(wolf, 0.0, 20);
      spawnNear(wolf, 0.4, 18);
      return 'قطيع ذئاب هائجة يتعقبك!';
    }
    const rareSkel = SKELETON_MONSTERS.find((s) => s.skeletonVariant === 'rare') ?? SKELETON_MONSTERS[7];
    spawnNear(rareSkel, 0, 20);
    return 'ظهور وحش نادر مشحون بالسحر!';
  }

  private spawnOne(
    def: EntityTemplateDef,
    x: number,
    y: number,
    z: number,
    opts: {
      isDungeonEnemy: boolean;
      isDungeonBoss: boolean;
      levelOverride?: number;
      hpOverride?: number;
      rankOverride?: EntityRank;
      scaleMult?: number;
      attackMult?: number;
    },
  ): void {
    const scaleMult = opts.scaleMult ?? 1;
    const visual = this.pool.buildCreatureOrMonster(def, this.castShadows);
    visual.root.position.set(0, 0, 0);
    visual.root.updateMatrixWorld(true);
    _measureBox.setFromObject(visual.root);
    const headOffsetY =
      Math.max(1.05, (_measureBox.isEmpty() ? 1.8 * def.scale : _measureBox.max.y) + 0.34) *
      scaleMult;

    visual.root.position.set(x, y, z);
    visual.root.scale.setScalar(def.scale * scaleMult * 0.15);
    this.scene.add(visual.root);

    const maxHp = opts.hpOverride ?? def.maxHp;
    const hostile =
      def.category === 'boss' ||
      def.temperament === 'aggressive' ||
      def.temperament === 'ranged';

    const rank = opts.rankOverride ?? resolveEntityRank(def);
    if (rank === 'elite' || rank === 'legendary') {
      visual.primaryMat.emissive.setHex(def.glowHex);
      visual.primaryMat.emissiveIntensity = 0.16;
    }

    this.entities.push({
      uid: `ent_${this.uidCounter++}`,
      def,
      visual,
      rank,
      scaleMult,
      attackMult: opts.attackMult ?? 1,
      headOffsetY,
      x,
      y,
      z,
      yaw: Math.random() * Math.PI * 2,
      hp: maxHp,
      displayHp: maxHp,
      trailHp: maxHp,
      maxHp,
      level: opts.levelOverride ?? def.level,
      isSummon: false,
      isRebel: false,
      durationSec: 0,
      remainingSec: 0,
      supportCd: 0,
      isDungeonEnemy: opts.isDungeonEnemy,
      isDungeonBoss: opts.isDungeonBoss,
      isHostile: hostile,
      state: 'wander',
      wanderAngle: Math.random() * Math.PI * 2,
      wanderTimer: 1 + Math.random() * 2.5,
      attackCd: 0.6,
      rangedCd: 1.5,
      hitFlash: 0,
      attackAnimTimer: 0,
      dyingTimer: 0,
      spawnProgress: 0.15,
      phase: 1,
      animTime: Math.random() * 6,
      aiAccum: 0,
      killReported: false,
      rallyTimer: 0,
      combatTime: 0,
      evolved: false,
      skillTimer: 4.5 + Math.random() * 1.5,
      telegraphTimer: 0,
      pendingSkillIdx: 0,
      activeSkillAr: null,
    });
  }

  private tryEvolveEntity(
    ent: LiveEntity,
    combatVfx: CombatVfxPool,
    ctx: EntityUpdateContext,
  ): void {
    if (ent.evolved || !ent.def.evolvesTo) return;
    const nextDef = ALL_ENTITY_DEFS[ent.def.evolvesTo];
    if (!nextDef) return;

    const oldDef = ent.def;
    this.scene.remove(ent.visual.root);
    ent.visual.disposeMaterials();

    const nextVisual = this.pool.buildCreatureOrMonster(nextDef, this.castShadows);
    nextVisual.root.position.set(0, 0, 0);
    nextVisual.root.updateMatrixWorld(true);
    _measureBox.setFromObject(nextVisual.root);
    ent.headOffsetY =
      Math.max(1.05, (_measureBox.isEmpty() ? 1.8 * nextDef.scale : _measureBox.max.y) + 0.34) *
      ent.scaleMult;

    nextVisual.root.position.set(ent.x, ent.y, ent.z);
    nextVisual.root.rotation.y = ent.yaw;
    this.scene.add(nextVisual.root);

    ent.def = nextDef;
    ent.visual = nextVisual;
    ent.rank = ent.rank === 'elite' ? 'elite' : resolveEntityRank(nextDef);
    ent.level = Math.max(ent.level + 2, nextDef.level);
    const hpRatio = ent.hp / Math.max(1, ent.maxHp);
    ent.maxHp = Math.max(nextDef.maxHp, Math.round(ent.maxHp * 1.38));
    ent.hp = Math.min(ent.maxHp, Math.round(ent.maxHp * Math.max(0.55, hpRatio + 0.25)));
    ent.displayHp = ent.hp;
    ent.trailHp = ent.hp;
    ent.spawnProgress = 0.4;
    ent.evolved = true;
    ent.isHostile = true;

    combatVfx.spawnRing(ent.x, ent.y, ent.z, nextDef.glowHex, 4.2, 0.7);
    combatVfx.spawnBurst(ent.x, ent.y + 1.1, ent.z, nextDef.glowHex, 10);
    ctx.onEntityEvolved?.(oldDef, nextDef);
  }

  private removeEntityAt(index: number): void {
    const ent = this.entities[index];
    this.scene.remove(ent.visual.root);
    ent.visual.disposeMaterials();
    this.entities.splice(index, 1);
  }

  private pickOverworldDef(
    biomeId: BiomeId,
    allowBoss: boolean,
    isNight: boolean,
    isWater: boolean,
    nearbyLocationKind?: LocationKind | null,
  ): EntityTemplateDef {
    if (isWater) {
      const aquaticPool = [...CREATURES, ...MONSTERS].filter((e) => e.isAquatic);
      if (aquaticPool.length > 0) {
        return aquaticPool[Math.floor(Math.random() * aquaticPool.length)];
      }
    }

    const roll = Math.random();
    if (allowBoss && roll < 0.08) {
      const bMatches = BOSSES.filter((b) => b.biomeIds.includes(biomeId));
      if (bMatches.length > 0) {
        return bMatches[Math.floor(Math.random() * bMatches.length)];
      }
    }
    const creatureCutoff = isNight ? 0.24 : 0.42;
    if (roll < creatureCutoff) {
      const cMatches = CREATURES.filter((c) => !c.isAquatic && c.biomeIds.includes(biomeId));
      const pool = cMatches.length > 0 ? cMatches : CREATURES.filter((c) => !c.isAquatic);
      return pool[Math.floor(Math.random() * pool.length)];
    }

    // Skeleton priority near ruins/castles/crypts/caves or at Night
    const nearUndeadSite =
      nearbyLocationKind === 'crypt' ||
      nearbyLocationKind === 'ruin' ||
      nearbyLocationKind === 'castle' ||
      nearbyLocationKind === 'cave';
    const skelChance = nearUndeadSite ? 0.52 : isNight ? 0.38 : 0.18;
    if (Math.random() < skelChance) {
      const skelMatches = SKELETON_MONSTERS.filter((s) => s.biomeIds.includes(biomeId));
      const pool = skelMatches.length > 0 ? skelMatches : SKELETON_MONSTERS;
      if (Math.random() < 0.14) {
        return pool[Math.floor(Math.random() * pool.length)];
      }
      const commonSkels = pool.filter(
        (s) => s.skeletonVariant !== 'rare' && s.skeletonVariant !== 'commander',
      );
      if (commonSkels.length > 0) {
        return commonSkels[Math.floor(Math.random() * commonSkels.length)];
      }
      return pool[Math.floor(Math.random() * pool.length)];
    }

    const mMatches = MONSTERS.filter((m) => !m.isAquatic && m.biomeIds.includes(biomeId));
    const pool = mMatches.length > 0 ? mMatches : MONSTERS.filter((m) => !m.isAquatic);
    return pool[Math.floor(Math.random() * pool.length)];
  }

  private trySpawnOverworld(
    playerX: number,
    playerZ: number,
    seed: number,
    isNight: boolean,
    nearbyLocationKind?: LocationKind | null,
  ): void {
    const cap = isNight ? 18 : 15;
    const activeNonSummon = this.entities.filter((e) => !e.isSummon).length;
    if (activeNonSummon >= cap) return;

    const hasNearbyBoss = this.entities.some(
      (e) =>
        !e.isSummon &&
        e.def.category === 'boss' &&
        Math.hypot(e.x - playerX, e.z - playerZ) < 55,
    );

    const ang = Math.random() * Math.PI * 2;
    const dist = 11 + Math.random() * 21;
    const sx = playerX + Math.cos(ang) * dist;
    const sz = playerZ + Math.sin(ang) * dist;

    const distToVillage = Math.hypot(sx - VILLAGE_CENTER.x, sz - VILLAGE_CENTER.z);
    const biomeId = getBiomeIdAt(sx, sz, seed);
    const wy = getWorldHeight(sx, sz, seed);
    const isWater = wy < WATER_LEVEL + 0.35;
    const allowBoss = !hasNearbyBoss && distToVillage > 32 && !isWater;

    let def = this.pickOverworldDef(biomeId, allowBoss, isNight, isWater, nearbyLocationKind);
    if (
      distToVillage < 18 &&
      (def.category === 'boss' ||
        def.temperament === 'aggressive' ||
        def.temperament === 'ranged')
    ) {
      const peaceful = CREATURES.filter((c) => c.temperament === 'peaceful' && !c.isAquatic);
      def = peaceful[Math.floor(Math.random() * peaceful.length)];
    }

    if (isWater && !def.isAquatic && def.archetype !== 'serpent') return;
    const spawnY = def.isAquatic && wy < WATER_LEVEL - 0.15 ? WATER_LEVEL - 0.35 : wy;

    let rankOverride: EntityRank | undefined;
    let hpOverride: number | undefined;
    let scaleMult = 1;
    let attackMult = 1;
    if (def.category === 'monster' && (!def.rank || def.rank === 'common') && distToVillage > 24) {
      const variantRoll = Math.random();
      if (variantRoll < 0.03) {
        rankOverride = 'elite';
        hpOverride = Math.round(def.maxHp * 1.85);
        attackMult = 1.38;
        scaleMult = 1.24;
      } else if (variantRoll < 0.11) {
        rankOverride = 'rare';
        hpOverride = Math.round(def.maxHp * 1.4);
        attackMult = 1.2;
        scaleMult = 1.14;
      }
    }

    this.spawnOne(def, sx, spawnY, sz, {
      isDungeonEnemy: false,
      isDungeonBoss: false,
      rankOverride,
      hpOverride,
      scaleMult,
      attackMult,
    });
  }

  private spawnEnemyBolt(
    sx: number,
    sy: number,
    sz: number,
    tx: number,
    ty: number,
    tz: number,
    colorHex: number,
    damage: number,
  ): void {
    const slot = this.bolts.find((b) => !b.active) ?? this.bolts[0];
    const dx = tx - sx;
    const dy = ty - sy;
    const dz = tz - sz;
    const len = Math.max(0.01, Math.hypot(dx, dy, dz));
    const speed = 13.5;

    slot.active = true;
    slot.x = sx;
    slot.y = sy;
    slot.z = sz;
    slot.vx = (dx / len) * speed;
    slot.vy = (dy / len) * speed;
    slot.vz = (dz / len) * speed;
    slot.life = 2.6;
    slot.damage = damage;
    (slot.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
    slot.mesh.position.set(sx, sy, sz);
    slot.mesh.visible = true;
  }

  private spatialFor(x: number, z: number): SpatialHint {
    return {
      dx: x - this.lastPlayerX,
      dz: z - this.lastPlayerZ,
      playerYaw: this.lastPlayerYaw,
    };
  }

  public update(ctx: EntityUpdateContext): void {
    const {
      dt,
      playerX,
      playerY,
      playerZ,
      playerYaw,
      viewDistanceMeters,
      inDungeon,
      dungeon,
      seed,
      isNight,
      nearbyLocationKind,
      combatVfx,
    } = ctx;

    this.lastPlayerX = playerX;
    this.lastPlayerZ = playerZ;
    this.lastPlayerYaw = playerYaw;
    if (this.targetDecay > 0) {
      this.targetDecay = Math.max(0, this.targetDecay - dt);
      if (this.targetDecay <= 0) this.targetUid = null;
    }

    // 1. Overworld ambient spawning
    if (!inDungeon) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = isNight ? 0.85 : 1.05;
        this.trySpawnOverworld(playerX, playerZ, seed, isNight, nearbyLocationKind);
      }
    }

    // Commander Skeleton rally pulse
    for (const cmd of this.entities) {
      if (cmd.hp > 0 && cmd.def.skeletonVariant === 'commander') {
        for (const ally of this.entities) {
          if (ally !== cmd && ally.hp > 0 && ally.def.archetype === 'skeleton') {
            const d = Math.hypot(ally.x - cmd.x, ally.z - cmd.z);
            if (d < 12) ally.rallyTimer = 0.5;
          }
        }
      }
    }

    let anyChasing = false;
    const lodDetailDist = viewDistanceMeters * 0.55;
    const maxVisibleDist = inDungeon ? 68 : viewDistanceMeters + 6;

    // 2. Despawn distant overworld entities, handle dying collapse & active AI
    for (let i = this.entities.length - 1; i >= 0; i--) {
      const ent = this.entities[i];
      const dToPlayer = Math.hypot(ent.x - playerX, ent.z - playerZ);

      if (!ent.isSummon && !inDungeon && dToPlayer > Math.max(62, viewDistanceMeters + 16)) {
        this.removeEntityAt(i);
        continue;
      }

      if (ent.hp <= 0) {
        ent.dyingTimer += dt;
        const progress = Math.min(1, ent.dyingTimer / 0.45);
        ent.visual.root.rotation.z = progress * (Math.PI * 0.48);
        ent.visual.root.scale.setScalar(ent.def.scale * (1 - progress * 0.72));
        ent.visual.root.position.y = ent.y - progress * 0.35;
        if (ent.dyingTimer >= 0.45) {
          this.removeEntityAt(i);
        }
        continue;
      }

      if (ent.spawnProgress < 1) {
        ent.spawnProgress = Math.min(1, ent.spawnProgress + dt * 3.2);
      }
      if (ent.rallyTimer > 0) {
        ent.rallyTimer = Math.max(0, ent.rallyTimer - dt);
      }

      const visible = dToPlayer <= maxVisibleDist;
      ent.visual.root.visible = visible;
      if (visible && ent.visual.detailParts.length > 0) {
        const showDetail = dToPlayer <= lodDetailDist;
        for (let dIdx = 0; dIdx < ent.visual.detailParts.length; dIdx++) {
          ent.visual.detailParts[dIdx].visible = showDetail;
        }
      }

      if (ent.hitFlash > 0) {
        ent.hitFlash = Math.max(0, ent.hitFlash - dt);
        if (ent.isRebel) {
          ent.visual.primaryMat.emissive.setHex(ent.hitFlash > 0 ? 0xffffff : 0xef4444);
          ent.visual.primaryMat.emissiveIntensity = ent.hitFlash > 0 ? 0.7 : 0.42;
        } else {
          ent.visual.primaryMat.emissive.setHex(
            ent.hitFlash > 0
              ? 0xffffff
              : ent.rank === 'elite' || ent.rank === 'legendary'
                ? ent.def.glowHex
                : 0x000000,
          );
          ent.visual.primaryMat.emissiveIntensity =
            ent.hitFlash > 0
              ? 0.65
              : ent.rank === 'elite' || ent.rank === 'legendary'
                ? 0.16
                : 0;
        }
      }
      if (ent.attackAnimTimer > 0) {
        ent.attackAnimTimer = Math.max(0, ent.attackAnimTimer - dt);
      }
      if (ent.attackCd > 0) ent.attackCd = Math.max(0, ent.attackCd - dt);
      if (ent.rangedCd > 0) ent.rangedCd = Math.max(0, ent.rangedCd - dt);

      if (!ent.isSummon && dToPlayer < 16) {
        const rec = ctx.bestiary[ent.def.id];
        if (!rec?.discovered) {
          ctx.bestiary[ent.def.id] = {
            discovered: true,
            defeatedCount: rec?.defeatedCount ?? 0,
            summonUnlocked: rec?.summonUnlocked ?? false,
          };
          ctx.onEntityDiscovered(ent.def);
        }
      }

      let aiDt = dt;
      if (!ent.isSummon && !inDungeon && dToPlayer > 24) {
        if (dToPlayer > 44) continue;
        ent.aiAccum += dt;
        if (ent.aiAccum < 0.1) continue;
        aiDt = ent.aiAccum;
        ent.aiAccum = 0;
      }

      let moveSpeed = 0;
      let targetYaw = ent.yaw;

      if (ent.isSummon) {
        ent.remainingSec -= dt;
        if (ent.remainingSec <= 0) {
          const expiredDef = ent.def;
          const wasRebel = ent.isRebel;
          const uid = ent.uid;
          combatVfx.spawnBurst(ent.x, ent.y + 1.0, ent.z, wasRebel ? 0xef4444 : ent.def.glowHex, 8);
          this.removeEntityAt(i);
          ctx.onSummonExpired?.(uid, expiredDef, wasRebel);
          continue;
        }

        if (ent.isRebel) {
          anyChasing = true;
          const dx = playerX - ent.x;
          const dz = playerZ - ent.z;
          const dist = Math.max(0.01, Math.hypot(dx, dz));
          targetYaw = Math.atan2(dx, dz);
          const meleeRange = 1.65 + ent.def.scale * 0.5;
          if (dist > meleeRange) {
            moveSpeed = ent.def.speed * 1.18;
            ent.x += (dx / dist) * moveSpeed * aiDt;
            ent.z += (dz / dist) * moveSpeed * aiDt;
          }
          if ((ent.def.summonRole === 'ranged' || ent.def.temperament === 'ranged') && dist > 3.5 && dist < 18 && ent.rangedCd <= 0) {
            ent.rangedCd = 2.0;
            ent.attackAnimTimer = 0.25;
            this.spawnEnemyBolt(
              ent.x,
              ent.y + 1.2 * ent.def.scale,
              ent.z,
              playerX,
              playerY + 1.0,
              playerZ,
              0xef4444,
              Math.max(8, Math.round(ent.def.attack * 0.9)),
            );
          }
          if (dist <= meleeRange + 0.4 && ent.attackCd <= 0) {
            ent.attackCd = 1.15;
            ent.attackAnimTimer = 0.25;
            ctx.onPlayerDamaged(Math.max(8, Math.round(ent.def.attack * 0.95)), `${ent.def.nameAr} (متمرد)`);
            combatVfx.spawnBurst(playerX, playerY + 1.0, playerZ, 0xef4444, 5);
          }
        } else if (dToPlayer > 26) {
          ent.x = playerX + 1.9;
          ent.z = playerZ + 1.9;
          ent.y = playerY;
        } else {
          if (ent.def.summonRole === 'support') {
            ent.supportCd -= dt;
            if (ent.supportCd <= 0) {
              ent.supportCd = 5.5;
              combatVfx.spawnRing(ent.x, ent.y, ent.z, 0x34d399, 3.2, 0.45);
              ctx.onSupportPulse?.(ent.def);
            }
          }

          let targetEnemy: LiveEntity | null = null;
          let bestEnemyDist = 15.5;
          for (const other of this.entities) {
            if (other.hp <= 0) continue;
            if (other.isSummon && !other.isRebel) continue;
            if (!other.isSummon && !other.isHostile) continue;
            const d = Math.hypot(other.x - ent.x, other.z - ent.z);
            if (d < bestEnemyDist) {
              bestEnemyDist = d;
              targetEnemy = other;
            }
          }

          if (targetEnemy) {
            const dx = targetEnemy.x - ent.x;
            const dz = targetEnemy.z - ent.z;
            const dist = Math.max(0.01, Math.hypot(dx, dz));
            targetYaw = Math.atan2(dx, dz);
            const isRangedRole = ent.def.summonRole === 'ranged';
            const stopDist = isRangedRole ? 6.0 : 1.85;
            if (dist > stopDist) {
              moveSpeed = ent.def.speed * 1.15;
              ent.x += (dx / dist) * moveSpeed * aiDt;
              ent.z += (dz / dist) * moveSpeed * aiDt;
            }
            if (ent.attackCd <= 0 && (dist <= 2.3 || (isRangedRole && dist <= 13))) {
              ent.attackCd = isRangedRole ? 1.1 : 0.92;
              ent.attackAnimTimer = 0.25;
              const dmg = Math.max(10, Math.round((ent.def.attack * 1.15 + 8) * ent.attackMult));
              combatVfx.spawnBurst(
                targetEnemy.x,
                targetEnemy.y + 1.0,
                targetEnemy.z,
                ent.def.glowHex,
                5,
              );
              this.applyDirectDamage(
                targetEnemy,
                dmg,
                ent.def.weakness,
                combatVfx,
                (killEvt) => ctx.onGuardKill({ ...killEvt, bySummon: true }),
                ctx.onCreatureSound,
              );
            }
          } else if (dToPlayer > 3.2) {
            const fx = playerX - ent.x;
            const fz = playerZ - ent.z;
            const dist = Math.max(0.01, Math.hypot(fx, fz));
            targetYaw = Math.atan2(fx, fz);
            moveSpeed = Math.min(7.8, ent.def.speed * 1.25);
            ent.x += (fx / dist) * moveSpeed * aiDt;
            ent.z += (fz / dist) * moveSpeed * aiDt;
          }
        }
      } else {
        if (ent.def.category === 'boss' && ent.hp < ent.maxHp * 0.5 && ent.phase === 1) {
          ent.phase = 2;
          combatVfx.spawnRing(ent.x, ent.y, ent.z, ent.def.glowHex, 6.0, 0.8);
          ctx.onCreatureSound?.(
            ent.def.archetype,
            'aggro',
            this.spatialFor(ent.x, ent.z),
            ent.def.skeletonVariant,
          );
        }

        const baseAggro = ent.def.category === 'boss' ? 22 : ent.isDungeonEnemy ? 16 : 14;
        const aggroRange = !inDungeon && isNight ? baseAggro + 3.5 : baseAggro;
        if (ent.isHostile && dToPlayer < aggroRange) {
          if (ent.state !== 'chase') {
            ctx.onCreatureSound?.(
              ent.def.archetype,
              'aggro',
              this.spatialFor(ent.x, ent.z),
              ent.def.skeletonVariant,
            );
          }
          ent.state = 'chase';
          anyChasing = true;
        } else if (ent.state === 'chase' && dToPlayer > aggroRange + 7) {
          ent.state = 'wander';
          ent.activeSkillAr = null;
          ent.telegraphTimer = 0;
        }

        if (ent.state === 'flee') {
          const dx = ent.x - playerX;
          const dz = ent.z - playerZ;
          const dist = Math.max(0.01, Math.hypot(dx, dz));
          if (dist > 22) {
            ent.state = 'wander';
          } else {
            targetYaw = Math.atan2(dx, dz);
            moveSpeed = ent.def.speed * 1.25;
            ent.x += (dx / dist) * moveSpeed * aiDt;
            ent.z += (dz / dist) * moveSpeed * aiDt;
          }
        } else if (ent.state === 'chase') {
          anyChasing = true;
          ent.combatTime += aiDt;
          if (
            !ent.evolved &&
            ent.def.evolvesTo &&
            (ent.combatTime >= 12 ||
              (ent.combatTime >= 5 && !inDungeon && isNight && (!ent.def.evolveBiome || getBiomeIdAt(ent.x, ent.z, seed) === ent.def.evolveBiome)))
          ) {
            this.tryEvolveEntity(ent, combatVfx, ctx);
          }

          const dx = playerX - ent.x;
          const dz = playerZ - ent.z;
          const dist = Math.max(0.01, Math.hypot(dx, dz));
          targetYaw = Math.atan2(dx, dz);
          const enrageMult =
            (ent.phase === 2 ? 1.24 : 1.0) *
            (ent.rallyTimer > 0 ? 1.18 : 1.0) *
            (!inDungeon && isNight ? 1.1 : 1.0);

          // Boss Multi-Ability Telegraphs & Signature Patterns
          if (ent.def.category === 'boss' && ent.def.abilities && ent.def.abilities.length > 0 && dToPlayer < 22) {
            if (ent.telegraphTimer > 0) {
              ent.telegraphTimer -= aiDt;
              if (ent.telegraphTimer <= 0) {
                const skillIdx = ent.pendingSkillIdx;
                ent.activeSkillAr = null;
                ent.skillTimer = ent.phase === 2 ? 4.2 : 5.6;
                ent.attackAnimTimer = 0.32;
                const skillDmg = Math.round(ent.def.attack * ent.attackMult * (ent.phase === 2 ? 1.5 : 1.25));
                if (skillIdx % 3 === 0) {
                  // Radial Shockwave AoE Slam
                  combatVfx.spawnRing(ent.x, ent.y, ent.z, ent.def.glowHex, 5.8, 0.75);
                  combatVfx.spawnBurst(ent.x, ent.y + 1.0, ent.z, ent.def.glowHex, 10);
                  if (dist < 5.6) {
                    ctx.onPlayerDamaged(skillDmg, ent.def.nameAr);
                  }
                } else if (skillIdx % 3 === 1) {
                  // Triple Spread Elemental Bolts
                  const baseAng = Math.atan2(dx, dz);
                  for (let s = -1; s <= 1; s++) {
                    const ang = baseAng + s * 0.28;
                    const tx = ent.x + Math.sin(ang) * 14;
                    const tz = ent.z + Math.cos(ang) * 14;
                    this.spawnEnemyBolt(
                      ent.x,
                      ent.y + 1.35 * ent.def.scale,
                      ent.z,
                      tx,
                      playerY + 1.0,
                      tz,
                      ent.def.glowHex,
                      Math.round(skillDmg * 0.85),
                    );
                  }
                } else {
                  // Phase-2 Minion Summon or Dash Nova Burst
                  combatVfx.spawnRing(ent.x, ent.y, ent.z, ent.def.glowHex, 4.5, 0.65);
                  const nearbyMonsters = this.entities.filter(
                    (e) => !e.isSummon && e.def.category !== 'boss' && e.hp > 0,
                  ).length;
                  if (ent.phase === 2 && nearbyMonsters < 5 && MONSTERS.length > 0) {
                    const helperPool = MONSTERS.filter((m) => m.level <= ent.def.level);
                    const helperDef =
                      helperPool[Math.floor(Math.random() * helperPool.length)] ?? MONSTERS[0];
                    this.spawnOne(helperDef, ent.x + 2.6, ent.y, ent.z + 2.2, {
                      isDungeonEnemy: ent.isDungeonEnemy,
                      isDungeonBoss: false,
                    });
                  } else if (dist < 4.5) {
                    ctx.onPlayerDamaged(skillDmg, ent.def.nameAr);
                  }
                }
              }
            } else {
              ent.skillTimer -= aiDt;
              if (ent.skillTimer <= 0) {
                ent.pendingSkillIdx = (ent.pendingSkillIdx + 1) % ent.def.abilities.length;
                ent.activeSkillAr = ent.def.abilities[ent.pendingSkillIdx];
                ent.telegraphTimer = 0.85;
                combatVfx.spawnRing(ent.x, ent.y, ent.z, 0xfbbf24, 3.2, 0.55);
              }
            }
          }

          const meleeRange = 1.65 + ent.def.scale * ent.scaleMult * 0.55;
          const stopDist = ent.def.temperament === 'ranged' ? 6.5 : meleeRange;

          if (dist > stopDist) {
            moveSpeed = ent.def.speed * enrageMult;
            ent.x += (dx / dist) * moveSpeed * aiDt;
            ent.z += (dz / dist) * moveSpeed * aiDt;
          }

          if (
            (ent.def.temperament === 'ranged' || ent.def.category === 'boss') &&
            dist > 3.5 &&
            dist < 20 &&
            ent.rangedCd <= 0
          ) {
            ent.rangedCd = ent.phase === 2 ? 1.75 : 2.5;
            ent.attackAnimTimer = 0.25;
            this.spawnEnemyBolt(
              ent.x,
              ent.y + 1.25 * ent.def.scale * ent.scaleMult,
              ent.z,
              playerX,
              playerY + 1.1,
              playerZ,
              ent.def.glowHex,
              Math.round(ent.def.attack * ent.attackMult * (ent.phase === 2 ? 1.2 : 0.95)),
            );
          }

          if (dist <= meleeRange + 0.45 && ent.attackCd <= 0) {
            ent.attackCd = ent.phase === 2 ? 1.05 : 1.35;
            ent.attackAnimTimer = 0.25;
            const dmg = Math.round(ent.def.attack * ent.attackMult * (ent.phase === 2 ? 1.25 : 1.0));
            ctx.onPlayerDamaged(dmg, ent.def.nameAr);
            combatVfx.spawnBurst(playerX, playerY + 1.0, playerZ, ent.def.glowHex, 4);
          }
        } else {
          ent.wanderTimer -= aiDt;
          if (ent.wanderTimer <= 0) {
            ent.wanderTimer = 2.0 + Math.random() * 3.0;
            ent.wanderAngle += (Math.random() - 0.5) * 2.2;
          }
          moveSpeed = ent.def.speed * 0.38;
          targetYaw = ent.wanderAngle;
          ent.x += Math.sin(ent.wanderAngle) * moveSpeed * aiDt;
          ent.z += Math.cos(ent.wanderAngle) * moveSpeed * aiDt;
        }
      }

      if (inDungeon && dungeon) {
        const clamped = dungeon.clampPosition(ent.x, ent.z, 0.5 * ent.def.scale * ent.scaleMult);
        ent.x = clamped.x;
        ent.z = clamped.z;
        ent.y = 0;
      } else {
        const wy = getWorldHeight(ent.x, ent.z, seed);
        ent.y = ent.def.isAquatic && wy < WATER_LEVEL - 0.15 ? WATER_LEVEL - 0.35 : wy;
      }

      // Smooth HP interpolation for overhead bar & trailing damage flash
      ent.displayHp = THREE.MathUtils.damp(ent.displayHp, Math.max(0, ent.hp), 14, dt);
      ent.trailHp = THREE.MathUtils.damp(ent.trailHp, Math.max(0, ent.hp), 3.6, dt);

      ent.yaw = lerpAngle(ent.yaw, targetYaw, 1 - Math.exp(-8 * dt));
      const lungeForward =
        ent.attackAnimTimer > 0 ? Math.sin((ent.attackAnimTimer / 0.25) * Math.PI) * 0.35 : 0;
      const hoverBob =
        ent.def.archetype === 'winged' || ent.def.archetype === 'wisp' || ent.def.isAerial
          ? Math.sin(ent.animTime * 1.45) * 0.16
          : 0;
      const slimeBounce =
        ent.def.archetype === 'slime' ? Math.abs(Math.sin(ent.animTime * 1.35)) * 0.14 : 0;

      ent.visual.root.position.set(
        ent.x + Math.sin(ent.yaw) * lungeForward,
        ent.y + hoverBob + slimeBounce,
        ent.z + Math.cos(ent.yaw) * lungeForward,
      );
      ent.visual.root.rotation.y = ent.yaw;
      ent.visual.root.rotation.x = ent.hitFlash > 0 ? -0.18 : lungeForward * 0.45;
      const squashY =
        ent.def.archetype === 'slime' ? 1 + Math.sin(ent.animTime * 2.7) * 0.08 : 1;
      const totalScale = ent.def.scale * ent.scaleMult * ent.spawnProgress;
      ent.visual.root.scale.set(totalScale, totalScale * squashY, totalScale);

      if (visible) {
        ent.animTime += dt * (moveSpeed > 0.3 ? 6.5 : 2.2);
        const stride = moveSpeed > 0.3 ? 0.52 : 0.09;
        if (ent.visual.segments && ent.visual.segments.length > 0) {
          ent.visual.segments.forEach((seg, sIdx) => {
            seg.position.x = Math.sin(ent.animTime * 1.2 - sIdx * 0.85) * (0.09 + sIdx * 0.035);
          });
        } else {
          ent.visual.limbs.forEach((limb, idx) => {
            const phase = idx % 2 === 0 ? 1 : -1;
            limb.rotation.x = Math.sin(ent.animTime) * stride * phase;
          });
        }
        if (ent.visual.head) {
          ent.visual.head.rotation.x =
            ent.attackAnimTimer > 0
              ? -0.22
              : Math.sin(ent.animTime * 0.85) * (ent.state === 'chase' ? 0.1 : 0.05);
          ent.visual.head.rotation.y = Math.sin(ent.animTime * 0.45) * 0.08;
        }
        if (ent.visual.jaw) {
          ent.visual.jaw.rotation.x =
            ent.attackAnimTimer > 0
              ? 0.48
              : ent.state === 'chase'
                ? 0.14 + Math.abs(Math.sin(ent.animTime * 1.8)) * 0.14
                : 0.03;
        }
        if (ent.visual.tail) {
          ent.visual.tail.rotation.y = Math.sin(ent.animTime * 1.6) * (ent.state === 'chase' ? 0.35 : 0.16);
        }
        ent.visual.wings.forEach((w, idx) => {
          if (ent.def.archetype === 'wisp') {
            w.rotation.y = ent.animTime * 0.9;
          } else {
            w.rotation.z =
              (idx === 0 ? 0.24 : -0.24) +
              Math.sin(ent.animTime * 1.55) * 0.34 * (idx === 0 ? 1 : -1);
          }
        });
        if (ent.visual.auraRing) {
          ent.visual.auraRing.rotation.z += dt * (ent.phase === 2 ? 2.6 : 1.1);
        }
      }
    }

    this.inCombat = anyChasing;

    // 3. Update Village NPCs (with living villager strolls) + Interior Castle Guards
    const activeNpcList = inDungeon ? this.interiorGuards : this.npcs;
    for (const npc of activeNpcList) {
      npc.animTime += dt * 2.2;
      if (npc.attackCd > 0) npc.attackCd = Math.max(0, npc.attackCd - dt);
      const dToPlayer = Math.hypot(npc.x - playerX, npc.z - playerZ);
      npc.visual.root.visible = inDungeon || dToPlayer <= maxVisibleDist;

      let strolling = false;
      if (npc.def.role === 'guard') {
        let threat: LiveEntity | null = null;
        let bestDist = 14;
        for (const ent of this.entities) {
          if (ent.isSummon || !ent.isHostile || ent.hp <= 0) continue;
          const d = Math.hypot(ent.x - npc.x, ent.z - npc.z);
          if (d < bestDist) {
            bestDist = d;
            threat = ent;
          }
        }
        if (threat) {
          npc.yaw = Math.atan2(threat.x - npc.x, threat.z - npc.z);
          if (bestDist <= 3.2 && npc.attackCd <= 0) {
            npc.attackCd = 1.1;
            combatVfx.spawnSlash(npc.x, npc.y, npc.z, npc.yaw, 0x38bdf8);
            this.applyDirectDamage(
              threat,
              22,
              undefined,
              combatVfx,
              ctx.onGuardKill,
              ctx.onCreatureSound,
            );
          }
        } else if (dToPlayer < 8) {
          npc.yaw = lerpAngle(
            npc.yaw,
            Math.atan2(playerX - npc.x, playerZ - npc.z),
            1 - Math.exp(-5 * dt),
          );
        }
      } else if (dToPlayer < 6.5) {
        npc.yaw = lerpAngle(
          npc.yaw,
          Math.atan2(playerX - npc.x, playerZ - npc.z),
          1 - Math.exp(-5 * dt),
        );
      } else if (!inDungeon && npc.def.role === 'villager') {
        npc.strollTimer -= dt;
        if (npc.strollTimer <= 0) {
          npc.strollTimer = 3.0 + Math.random() * 4.0;
          const toHomeX = npc.homeX - npc.x;
          const toHomeZ = npc.homeZ - npc.z;
          if (Math.hypot(toHomeX, toHomeZ) > 2.8) {
            npc.strollAngle = Math.atan2(toHomeX, toHomeZ);
          } else {
            npc.strollAngle = Math.random() * Math.PI * 2;
          }
        }
        if (npc.strollTimer > 1.2) {
          strolling = true;
          npc.x += Math.sin(npc.strollAngle) * 1.15 * dt;
          npc.z += Math.cos(npc.strollAngle) * 1.15 * dt;
          npc.y = getWorldHeight(npc.x, npc.z, seed);
          npc.yaw = lerpAngle(npc.yaw, npc.strollAngle, 1 - Math.exp(-4 * dt));
          npc.visual.root.position.set(npc.x, npc.y, npc.z);
        }
      }

      npc.visual.root.rotation.y = npc.yaw;
      const limbStride = strolling ? 0.35 : 0.04;
      npc.visual.limbs.forEach((l, idx) => {
        l.rotation.x = Math.sin(npc.animTime * (strolling ? 2.4 : 1)) * limbStride * (idx % 2 === 0 ? 1 : -1);
      });
      if (npc.visual.wings[0]) {
        npc.visual.wings[0].position.y = 2.25 + Math.sin(npc.animTime) * 0.1;
        npc.visual.wings[0].rotation.y = npc.animTime;
      }
    }

    // 4. Update Enemy Projectiles
    for (const b of this.bolts) {
      if (!b.active) continue;
      b.life -= dt;
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.z += b.vz * dt;
      b.mesh.position.set(b.x, b.y, b.z);

      const dPlayer = Math.hypot(b.x - playerX, b.y - (playerY + 1.0), b.z - playerZ);
      if (dPlayer < 1.1) {
        ctx.onPlayerDamaged(b.damage, 'هجوم سحري معادٍ');
        combatVfx.spawnBurst(b.x, b.y, b.z, 0xf43f5e, 5);
        b.active = false;
        b.mesh.visible = false;
        continue;
      }

      if (b.life <= 0) {
        b.active = false;
        b.mesh.visible = false;
      }
    }
  }

  private applyDirectDamage(
    ent: LiveEntity,
    baseDamage: number,
    elementId: ElementId | undefined,
    combatVfx: CombatVfxPool,
    onKill: (evt: EntityKillEvent) => void,
    onCreatureSound?: CreatureSoundCb,
  ): boolean {
    if (ent.hp <= 0) return false;
    let mult = 1.0;
    let isWeakness = false;
    if (elementId) {
      if (ent.def.weakness === elementId) {
        mult = 1.4;
        isWeakness = true;
      } else if (ent.def.resistance === elementId) {
        mult = 0.7;
      }
    }
    const finalDmg = Math.max(1, Math.round(baseDamage * mult));
    ent.hp -= finalDmg;
    ent.hitFlash = 0.14;
    this.targetUid = ent.uid;
    this.targetDecay = 5.5;

    if (ent.def.temperament === 'peaceful') {
      ent.state = 'flee';
    } else if (ent.def.temperament === 'neutral') {
      ent.isHostile = true;
      ent.state = 'chase';
    }

    const spatial = this.spatialFor(ent.x, ent.z);

    if (ent.hp <= 0 && !ent.killReported) {
      ent.killReported = true;
      ent.dyingTimer = 0.001;
      if (this.targetUid === ent.uid) this.targetUid = null;
      combatVfx.spawnBurst(ent.x, ent.y + 1.0, ent.z, ent.def.glowHex, 9);
      onCreatureSound?.(ent.def.archetype, 'death', spatial, ent.def.skeletonVariant);
      onKill({
        def: ent.def,
        x: ent.x,
        y: ent.y,
        z: ent.z,
        isDungeonBoss: ent.isDungeonBoss,
        rank: ent.rank,
        wasRebelSummon: ent.isSummon && ent.isRebel,
      });
    } else {
      onCreatureSound?.(ent.def.archetype, 'hit', spatial, ent.def.skeletonVariant);
    }
    return isWeakness;
  }

  public damageEntitiesInRadius(
    x: number,
    z: number,
    radius: number,
    baseDamage: number,
    elementId: ElementId | undefined,
    combatVfx: CombatVfxPool,
    onKill: (evt: EntityKillEvent) => void,
    onCreatureSound?: CreatureSoundCb,
  ): { hits: number; weaknessTriggered: boolean } {
    let hits = 0;
    let weaknessTriggered = false;
    for (let i = this.entities.length - 1; i >= 0; i--) {
      const ent = this.entities[i];
      if ((ent.isSummon && !ent.isRebel) || ent.hp <= 0) continue;

      const effectiveR = radius + 0.65 * ent.def.scale * ent.scaleMult;
      const dx = ent.x - x;
      const dz = ent.z - z;
      if (dx * dx + dz * dz <= effectiveR * effectiveR) {
        hits++;
        const dist = Math.max(0.1, Math.hypot(dx, dz));
        ent.x += (dx / dist) * 0.45;
        ent.z += (dz / dist) * 0.45;

        const weak = this.applyDirectDamage(
          ent,
          baseDamage,
          elementId,
          combatVfx,
          onKill,
          onCreatureSound,
        );
        if (weak) weaknessTriggered = true;
      }
    }
    return { hits, weaknessTriggered };
  }

  public getNearbyNpc(x: number, z: number, inDungeon = false, maxDist = 3.4): NpcDefinition | null {
    let best: NpcDefinition | null = null;
    let bestSq = maxDist * maxDist;
    const list = inDungeon ? this.interiorGuards : this.npcs;
    for (const npc of list) {
      const dSq = (npc.x - x) * (npc.x - x) + (npc.z - z) * (npc.z - z);
      if (dSq < bestSq) {
        bestSq = dSq;
        best = npc.def;
      }
    }
    return best;
  }

  public getActiveBossHud(playerX: number, playerZ: number, inDungeon: boolean): ActiveBossHud | null {
    let best: LiveEntity | null = null;
    let bestDist = inDungeon ? 60 : 30;
    for (const ent of this.entities) {
      if (ent.isSummon || ent.def.category !== 'boss' || ent.hp <= 0) continue;
      const d = Math.hypot(ent.x - playerX, ent.z - playerZ);
      if (d < bestDist) {
        bestDist = d;
        best = ent;
      }
    }
    if (!best) return null;
    return {
      id: best.def.id,
      nameAr: best.def.nameAr,
      hp: Math.max(0, Math.round(best.hp)),
      maxHp: best.maxHp,
      phase: best.phase,
      activeSkillAr: best.activeSkillAr,
    };
  }

  public getTargetEnemyHud(playerX: number, playerZ: number): TargetEnemyHud | null {
    let best: LiveEntity | null = null;
    if (this.targetUid) {
      best = this.entities.find(
        (e) => e.uid === this.targetUid && e.hp > 0 && e.def.category !== 'boss',
      ) ?? null;
    }
    if (!best) {
      let bestDist = 11.5;
      for (const ent of this.entities) {
        if ((ent.isSummon && !ent.isRebel) || ent.def.category === 'boss' || ent.hp <= 0 || ent.state !== 'chase') {
          continue;
        }
        const d = Math.hypot(ent.x - playerX, ent.z - playerZ);
        if (d < bestDist) {
          bestDist = d;
          best = ent;
        }
      }
    }
    if (!best) return null;
    return {
      id: best.def.id,
      nameAr: best.def.nameAr,
      level: best.level,
      hp: Math.max(0, Math.round(best.hp)),
      maxHp: best.maxHp,
      weakness: best.def.weakness,
      rank: best.rank,
      isRare: best.rank !== 'common' || best.def.skeletonVariant === 'rare' || best.def.skeletonVariant === 'commander',
    };
  }

  public getProjectedNameplates(
    camera: THREE.Camera,
    viewW: number,
    viewH: number,
    outList: OverheadNameplate[],
  ): void {
    outList.length = 0;
    if (viewW <= 0 || viewH <= 0) return;

    for (let i = 0; i < this.entities.length; i++) {
      const ent = this.entities[i];
      if (ent.hp <= 0 || !ent.visual.root.visible) continue;

      const d = Math.hypot(ent.x - this.lastPlayerX, ent.z - this.lastPlayerZ);
      const isBoss = ent.def.category === 'boss';
      const isTargeted = this.targetUid === ent.uid;
      const isDamaged = ent.hp < ent.maxHp;
      const maxBarDist = isBoss ? 38 : isTargeted || isDamaged || ent.isSummon ? 30 : 26;
      if (d > maxBarDist) continue;

      _projVec.set(ent.x, ent.visual.root.position.y + ent.headOffsetY, ent.z);
      _projVec.project(camera);
      if (_projVec.z < -1 || _projVec.z > 1) continue;

      const sx = (_projVec.x * 0.5 + 0.5) * viewW;
      const sy = (-_projVec.y * 0.5 + 0.5) * viewH;
      if (sx < -80 || sx > viewW + 80 || sy < -40 || sy > viewH + 40) continue;

      const fadeStart = maxBarDist * 0.72;
      const opacity =
        d <= fadeStart ? 1 : Math.max(0.15, 1 - (d - fadeStart) / Math.max(1, maxBarDist - fadeStart));
      const scale = THREE.MathUtils.clamp(1.06 - d * 0.014, 0.76, 1.04);

      outList.push({
        uid: ent.uid,
        nameAr: ent.def.nameAr,
        level: ent.level,
        rank: ent.rank,
        category: ent.def.category,
        hp: Math.max(0, ent.hp),
        displayHp: Math.max(0, ent.displayHp),
        trailHp: Math.max(0, ent.trailHp),
        maxHp: ent.maxHp,
        phase: isBoss ? ent.phase : undefined,
        isSummon: ent.isSummon,
        isRebel: ent.isRebel,
        isTargeted,
        screenX: sx,
        screenY: sy,
        scale,
        opacity,
      });
    }

    if (outList.length > 14) {
      outList.sort((a, b) => {
        if (a.isTargeted !== b.isTargeted) return a.isTargeted ? -1 : 1;
        if ((a.category === 'boss') !== (b.category === 'boss')) {
          return a.category === 'boss' ? -1 : 1;
        }
        return b.scale - a.scale;
      });
      outList.length = 14;
    }
  }

  public dispose(): void {
    for (let i = this.entities.length - 1; i >= 0; i--) {
      this.removeEntityAt(i);
    }
    for (const g of this.interiorGuards) {
      this.scene.remove(g.visual.root);
      g.visual.disposeMaterials();
    }
    this.interiorGuards.length = 0;
    for (const npc of this.npcs) {
      this.scene.remove(npc.visual.root);
      npc.visual.disposeMaterials();
    }
    this.npcs.length = 0;
    for (const b of this.bolts) {
      this.scene.remove(b.mesh);
    }
    this.boltGeo.dispose();
    this.boltMats.forEach((m) => m.dispose());
    this.pool.dispose();
  }
}

