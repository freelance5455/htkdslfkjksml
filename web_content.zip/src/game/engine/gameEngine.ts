import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { InputManager } from '../controls/inputManager';
import {
  ELEMENTS,
  getActiveFusion,
  getMasteryXpRequired,
} from '../data/elements';
import {
  ALL_ENTITY_DEFS,
  BLACKSMITH_FORGE,
  QUESTS,
  VILLAGE_CENTER,
} from '../data/entities';
import { computePlayerStats, ITEMS } from '../data/items';
import { PlayerModel } from '../entities/playerModel';
import { SoundEngine } from '../audio/soundEngine';
import { getDefaultAudioSettings } from '../storage/saveSystem';
import {
  AudioSettings,
  BiomeId,
  CameraMode,
  DungeonPortalInfo,
  ElementId,
  EquipSlot,
  GraphicsSettings,
  NearbyInteractable,
  NpcDefinition,
  ObstacleCollider,
  OverheadNameplate,
  PerfMetrics,
  SaveDataV1,
  WeatherKind,
} from '../types';
import { CombatVfxPool } from '../vfx/combatPool';
import { BIOMES, getBiomeIdAt, getWorldHeight, WATER_LEVEL } from '../world/biomes';
import { ChunkManager, HarvestReward } from '../world/chunkManager';
import { DungeonInstance } from '../world/dungeonGenerator';
import { TemplateRegistry } from '../world/templates';
import { EntityKillEvent, EntityManager } from './entityManager';

const _skyTarget = new THREE.Color();
const _fogTarget = new THREE.Color();
const _nightColor = new THREE.Color(0x0b1024);
const _sunsetColor = new THREE.Color(0xc26d4a);
const _castleFogColor = new THREE.Color(0x3a3254);
const _ruinFogColor = new THREE.Color(0x4b5563);
const _rainFogColor = new THREE.Color(0x526170);
const _stormFogColor = new THREE.Color(0x283444);
const _snowFogColor = new THREE.Color(0xdcebf7);
const _colliders: ObstacleCollider[] = [];
const _rewards: HarvestReward[] = [];
const _nameplatesBuf: OverheadNameplate[] = [];

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return false;
  }
}

function lerpAngle(current: number, target: number, factor: number): number {
  let diff = ((target - current + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return current + diff * factor;
}

export interface EngineCallbacks {
  onMetrics: (metrics: PerfMetrics, snapshot: SaveDataV1, cooldowns: Record<string, number>) => void;
  onNameplates?: (items: OverheadNameplate[]) => void;
  onCameraModeChange: (mode: CameraMode) => void;
  onNotice: (message: string) => void;
  onOpenNpc: (npc: NpcDefinition) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  private isSoftwareGl: boolean;

  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fog: THREE.FogExp2;

  private templates: TemplateRegistry;
  private chunkManager: ChunkManager;
  private entityManager: EntityManager;
  private dungeon: DungeonInstance | null = null;
  private savedOverworldPos: { x: number; y: number; z: number } | null = null;
  private currentNearby: NearbyInteractable | null = null;
  private currentPortal: DungeonPortalInfo | null = null;
  private currentNpc: NpcDefinition | null = null;
  private playerModel: PlayerModel;
  private combatVfx: CombatVfxPool;
  public readonly input: InputManager;

  private saveData: SaveDataV1;
  private settings: GraphicsSettings;
  private audioSettings: AudioSettings;
  private soundEngine: SoundEngine;
  private discoveredBiomes = new Set<BiomeId>();

  // Atmosphere, Time & Weather
  private timeOfDay = 0.28; // 0..1 (0.28 = bright morning)
  private weather: WeatherKind = 'clear';
  private weatherTimer = 95;
  private clouds: THREE.Mesh[] = [];
  private weatherDrops: Array<{ mesh: THREE.Mesh; x: number; y: number; z: number; speed: number }> = [];
  private weatherDropGeo: THREE.BoxGeometry;
  private weatherDropMat: THREE.MeshBasicMaterial;
  private footstepTimer = 0;
  private lightningFlash = 0;
  private lightningTimer = 8.5;

  // World Events & Hidden Treasure Chest
  private worldEventTimer = 78;
  private activeEventLabelAr: string | null = null;
  private activeEventBannerTimer = 0;
  private eventChest: {
    active: boolean;
    x: number;
    y: number;
    z: number;
    timer: number;
    group: THREE.Group;
    geometries: THREE.BufferGeometry[];
    materials: THREE.Material[];
  } | null = null;

  // Player kinematic state
  private posX = 0;
  private posY = 6;
  private posZ = 0;
  private velY = 0;
  private yaw = 0;
  private pitch = -0.18;
  private facingYaw = 0;
  private cameraMode: CameraMode = 'third';
  private thirdPersonDist = 6.2;
  private currentCamX = 0;
  private currentCamY = 8;
  private currentCamZ = 6;
  private isGrounded = true;
  private isSwimming = false;
  private isBlocking = false;
  private dashTimer = 0;
  private dashCooldown = 0;
  private attackCooldown = 0;
  private hasteTimer = 0;

  // RPG Live Vitals
  private hp = 120;
  private mana = 80;
  private stamina = 100;
  private abilityCooldowns: Record<string, number> = {};

  // Loop & performance tracking
  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;
  private lastRenderTime = 0;
  private fpsAccumTime = 0;
  private fpsFrames = 0;
  private currentFps = 60;
  private lastUiSyncTime = 0;
  private detachInputs: (() => void) | null = null;
  private detachAudioUnlock: (() => void) | null = null;
  private cleanupResize: (() => void) | null = null;

  constructor(container: HTMLElement, initialSave: SaveDataV1, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.saveData = structuredClone(initialSave);
    this.settings = this.saveData.graphics;
    this.audioSettings = this.saveData.audio ?? getDefaultAudioSettings();
    this.soundEngine = new SoundEngine(this.audioSettings);
    this.saveData.discoveredBiomes.forEach((b) => this.discoveredBiomes.add(b));

    this.isSoftwareGl = detectSoftwareWebGL();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && this.settings.preset !== 'low',
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.applyRendererSettings();

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.className = 'touch-none-zone';
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const startBiome =
      BIOMES[getBiomeIdAt(this.saveData.player.x, this.saveData.player.z, this.saveData.seed)];
    this.scene.background = new THREE.Color(startBiome.skyHex);
    this.fog = new THREE.FogExp2(startBiome.fogHex, startBiome.fogDensity);
    this.scene.fog = this.fog;

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(
      64,
      width / height,
      0.12,
      this.settings.viewDistanceMeters + 16,
    );

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(roomEnv, 0.04).texture;
    roomEnv.dispose();
    pmrem.dispose();

    this.hemiLight = new THREE.HemisphereLight(0xcbeafe, 0x3b4d36, 0.84);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff3d9, 1.68);
    this.sunLight.position.set(28, 46, 22);
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);
    this.configureShadowLight();

    this.templates = new TemplateRegistry(
      this.settings.textureQuality,
      this.renderer.capabilities.getMaxAnisotropy(),
    );
    this.chunkManager = new ChunkManager(
      this.scene,
      this.templates,
      this.saveData.seed,
      this.settings,
      this.saveData.discoveredChunks,
      this.saveData.harvestedNodes ?? [],
    );

    this.playerModel = new PlayerModel();
    this.playerModel.setShadowCasting(this.settings.shadowQuality !== 'off');
    this.scene.add(this.playerModel.root);

    this.entityManager = new EntityManager(
      this.scene,
      this.saveData.seed,
      !this.isSoftwareGl && this.settings.shadowQuality !== 'off',
    );

    this.combatVfx = new CombatVfxPool(this.scene);

    // Lightweight Sky Clouds
    for (let i = 0; i < 10; i++) {
      const c = new THREE.Mesh(this.templates.cloudGeo, this.templates.cloudMaterial);
      const ang = (i / 10) * Math.PI * 2;
      const rad = 28 + (i % 3) * 18;
      c.position.set(Math.cos(ang) * rad, 42 + (i % 3) * 4, Math.sin(ang) * rad);
      c.scale.setScalar(1.2 + (i % 3) * 0.45);
      c.visible = this.settings.preset !== 'low';
      this.scene.add(c);
      this.clouds.push(c);
    }

    // Pooled Weather Rain/Snow Particles
    this.weatherDropGeo = new THREE.BoxGeometry(0.05, 0.55, 0.05);
    this.weatherDropMat = new THREE.MeshBasicMaterial({
      color: 0xcbeafe,
      transparent: true,
      opacity: 0.58,
    });
    for (let i = 0; i < 34; i++) {
      const m = new THREE.Mesh(this.weatherDropGeo, this.weatherDropMat);
      m.visible = false;
      this.scene.add(m);
      this.weatherDrops.push({
        mesh: m,
        x: (Math.random() - 0.5) * 28,
        y: Math.random() * 14,
        z: (Math.random() - 0.5) * 28,
        speed: 14 + Math.random() * 6,
      });
    }

    // Pooled Hidden Event Treasure Chest
    const chestGroup = new THREE.Group();
    const chestBodyGeo = new THREE.BoxGeometry(1.1, 0.72, 0.8);
    const chestTrimGeo = new THREE.BoxGeometry(1.16, 0.16, 0.86);
    const chestBeamGeo = new THREE.CylinderGeometry(0.18, 0.45, 7.0, 8, 1, true);
    const chestWoodMat = new THREE.MeshStandardMaterial({
      color: 0x92400e,
      roughness: 0.65,
      flatShading: true,
    });
    const chestGoldMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      emissive: 0xd97706,
      emissiveIntensity: 0.55,
      metalness: 0.65,
      roughness: 0.25,
    });
    const chestBeamMat = new THREE.MeshBasicMaterial({
      color: 0xfde047,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
    });
    const cBody = new THREE.Mesh(chestBodyGeo, chestWoodMat);
    cBody.position.y = 0.36;
    const cTrim = new THREE.Mesh(chestTrimGeo, chestGoldMat);
    cTrim.position.y = 0.68;
    const cBeam = new THREE.Mesh(chestBeamGeo, chestBeamMat);
    cBeam.position.y = 3.8;
    chestGroup.add(cBody, cTrim, cBeam);
    chestGroup.visible = false;
    this.scene.add(chestGroup);
    this.eventChest = {
      active: false,
      x: 0,
      y: 0,
      z: 0,
      timer: 0,
      group: chestGroup,
      geometries: [chestBodyGeo, chestTrimGeo, chestBeamGeo],
      materials: [chestWoodMat, chestGoldMat, chestBeamMat],
    };

    this.applyPlayerFromSave(this.saveData);

    this.chunkManager.ensureSpawnChunks(this.posX, this.posZ);
    const groundY = getWorldHeight(this.posX, this.posZ, this.saveData.seed);
    if (this.posY < groundY) this.posY = groundY;

    const initSummonIds =
      this.saveData.player.activeSummonIds && this.saveData.player.activeSummonIds.length > 0
        ? this.saveData.player.activeSummonIds
        : this.saveData.player.activeSummonId
          ? [this.saveData.player.activeSummonId]
          : [];
    if (initSummonIds.length > 0) {
      this.entityManager.syncSummons(
        initSummonIds,
        this.posX,
        this.posY,
        this.posZ,
        this.saveData.player.summonMasteryLevel ?? 1,
      );
    }

    this.input = new InputManager(() => this.toggleCameraMode());
    this.detachInputs = this.input.attach(this.renderer.domElement);

    const onUnlockAudio = () => this.soundEngine.unlock();
    window.addEventListener('pointerdown', onUnlockAudio, { passive: true });
    window.addEventListener('keydown', onUnlockAudio, { passive: true });
    this.detachAudioUnlock = () => {
      window.removeEventListener('pointerdown', onUnlockAudio);
      window.removeEventListener('keydown', onUnlockAudio);
    };

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    const handleResize = () => {
      if (this.disposed) return;
      const w = Math.max(1, this.container.clientWidth);
      const h = Math.max(1, this.container.clientHeight);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h, false);
    };
    window.addEventListener('resize', handleResize);
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(this.container);
    this.cleanupResize = () => {
      window.removeEventListener('resize', handleResize);
      resizeObserver.disconnect();
    };

    this.clock.start();
    this.startLoop();
  }

  private applyPlayerFromSave(save: SaveDataV1): void {
    this.posX = save.player.x;
    this.posY = save.player.y;
    this.posZ = save.player.z;
    this.yaw = save.player.yaw;
    this.pitch = save.player.pitch;
    this.facingYaw = save.player.yaw;
    this.cameraMode = save.player.cameraMode;

    const stats = computePlayerStats(save.player.level, save.player.equipment);
    this.hp = Math.min(stats.maxHp, save.player.hp);
    this.mana = Math.min(stats.maxMana, save.player.mana);
    this.stamina = Math.min(stats.maxStamina, save.player.stamina);
    this.saveData.player.maxHp = stats.maxHp;
    this.saveData.player.maxMana = stats.maxMana;
    this.saveData.player.maxStamina = stats.maxStamina;

    this.playerModel.setFirstPersonHidden(this.cameraMode === 'first');
    this.playerModel.syncEquipmentVisuals(save.player.equipment);

    this.currentCamX = this.posX + Math.sin(this.yaw) * this.thirdPersonDist;
    this.currentCamY = this.posY + 3.0;
    this.currentCamZ = this.posZ + Math.cos(this.yaw) * this.thirdPersonDist;
  }

  private applyRendererSettings(): void {
    const dpr = this.isSoftwareGl
      ? 1
      : Math.min(window.devicePixelRatio || 1, 2) * this.settings.renderScale;
    this.renderer.setPixelRatio(Math.max(0.5, dpr));
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(w, h, false);

    const shadowsOn = !this.isSoftwareGl && this.settings.shadowQuality !== 'off';
    this.renderer.shadowMap.enabled = shadowsOn;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  }

  private configureShadowLight(): void {
    const shadowsOn = !this.isSoftwareGl && this.settings.shadowQuality !== 'off';
    this.sunLight.castShadow = shadowsOn;
    if (!shadowsOn) return;

    const mapSize =
      this.settings.shadowQuality === 'high'
        ? 2048
        : this.settings.shadowQuality === 'medium'
          ? 1024
          : 512;
    if (this.sunLight.shadow.mapSize.width !== mapSize) {
      this.sunLight.shadow.mapSize.set(mapSize, mapSize);
      this.sunLight.shadow.map?.dispose();
      this.sunLight.shadow.map = null;
    }
    const bound = 26;
    this.sunLight.shadow.camera.left = -bound;
    this.sunLight.shadow.camera.right = bound;
    this.sunLight.shadow.camera.top = bound;
    this.sunLight.shadow.camera.bottom = -bound;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 110;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.025;
  }

  public applyGraphicsSettings(newSettings: GraphicsSettings): void {
    this.settings = { ...newSettings };
    this.saveData.graphics = this.settings;
    this.applyRendererSettings();
    this.configureShadowLight();
    this.templates.updateQuality(
      this.settings.textureQuality,
      this.renderer.capabilities.getMaxAnisotropy(),
    );
    this.playerModel.setShadowCasting(this.settings.shadowQuality !== 'off');
    this.entityManager.setShadowCasting(!this.isSoftwareGl && this.settings.shadowQuality !== 'off');
    this.chunkManager.updateSettings(this.settings);
    const showClouds = !this.dungeon && this.settings.preset !== 'low';
    for (const c of this.clouds) {
      c.visible = showClouds;
    }
  }

  public applyAudioSettings(nextAudio: AudioSettings): void {
    this.audioSettings = { ...nextAudio };
    this.saveData.audio = { ...nextAudio };
    this.soundEngine.updateSettings(nextAudio);
  }

  public toggleCameraMode(): CameraMode {
    this.cameraMode = this.cameraMode === 'third' ? 'first' : 'third';
    this.playerModel.setFirstPersonHidden(this.cameraMode === 'first');
    this.callbacks.onCameraModeChange(this.cameraMode);
    return this.cameraMode;
  }

  public resetWithSave(newSave: SaveDataV1): void {
    if (this.dungeon) {
      this.dungeon.dispose();
      this.dungeon = null;
      this.savedOverworldPos = null;
    }
    this.entityManager.dispose();
    this.chunkManager.disposeAll();
    this.saveData = structuredClone(newSave);
    this.settings = { ...this.saveData.graphics };
    this.audioSettings = this.saveData.audio ?? getDefaultAudioSettings();
    this.soundEngine.updateSettings(this.audioSettings);
    this.discoveredBiomes.clear();
    this.saveData.discoveredBiomes.forEach((b) => this.discoveredBiomes.add(b));
    this.chunkManager = new ChunkManager(
      this.scene,
      this.templates,
      this.saveData.seed,
      this.settings,
      this.saveData.discoveredChunks,
      this.saveData.harvestedNodes ?? [],
    );
    this.entityManager = new EntityManager(
      this.scene,
      this.saveData.seed,
      !this.isSoftwareGl && this.settings.shadowQuality !== 'off',
    );
    this.applyGraphicsSettings(this.settings);
    this.applyPlayerFromSave(this.saveData);
    this.chunkManager.ensureSpawnChunks(this.posX, this.posZ);
    const gy = getWorldHeight(this.posX, this.posZ, this.saveData.seed);
    if (this.posY < gy) this.posY = gy;
    const resetSummonIds =
      this.saveData.player.activeSummonIds && this.saveData.player.activeSummonIds.length > 0
        ? this.saveData.player.activeSummonIds
        : this.saveData.player.activeSummonId
          ? [this.saveData.player.activeSummonId]
          : [];
    if (resetSummonIds.length > 0) {
      this.entityManager.syncSummons(
        resetSummonIds,
        this.posX,
        this.posY,
        this.posZ,
        this.saveData.player.summonMasteryLevel ?? 1,
      );
    }
    this.callbacks.onCameraModeChange(this.cameraMode);
  }

  // --- Inventory, Equipment, Survival & Magic Actions ---

  public addItemToInventory(itemId: string, quantity: number): void {
    const def = ITEMS[itemId];
    if (!def || quantity <= 0) return;
    if (def.stackable) {
      const existing = this.saveData.player.inventory.find((i) => i.itemId === itemId);
      if (existing) {
        existing.quantity += quantity;
        return;
      }
    }
    for (let i = 0; i < (def.stackable ? 1 : quantity); i++) {
      this.saveData.player.inventory.push({
        itemId,
        quantity: def.stackable ? quantity : 1,
      });
    }
  }

  public useInventoryItem(index: number): void {
    const entry = this.saveData.player.inventory[index];
    if (!entry) return;
    const def = ITEMS[entry.itemId];
    if (!def) return;

    if (def.equipSlot) {
      this.equipInventoryItem(index);
      return;
    }

    if (!def.consumable) {
      this.callbacks.onNotice('هذا المورد يُستخدم في التصنيع أو التطوير.');
      return;
    }

    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    const c = def.consumable;
    if (c.hp) this.hp = Math.min(stats.maxHp, this.hp + c.hp);
    if (c.mana) this.mana = Math.min(stats.maxMana, this.mana + c.mana);
    if (c.stamina) this.stamina = Math.min(stats.maxStamina, this.stamina + c.stamina);
    if (c.hunger) {
      this.saveData.player.survival.hunger = Math.min(
        100,
        this.saveData.player.survival.hunger + c.hunger,
      );
    }
    if (c.thirst) {
      this.saveData.player.survival.thirst = Math.min(
        100,
        this.saveData.player.survival.thirst + c.thirst,
      );
    }
    if (c.tempDelta) {
      this.saveData.player.survival.temperature = THREE.MathUtils.clamp(
        this.saveData.player.survival.temperature + c.tempDelta,
        -20,
        50,
      );
    }

    entry.quantity -= 1;
    if (entry.quantity <= 0) {
      this.saveData.player.inventory.splice(index, 1);
    }
    this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, 0x34d399, 2.5, 0.45);
    this.callbacks.onNotice(`تم استخدام: ${def.nameAr}`);
  }

  public equipInventoryItem(index: number): void {
    const entry = this.saveData.player.inventory[index];
    if (!entry) return;
    const def = ITEMS[entry.itemId];
    if (!def?.equipSlot) return;

    const slot = def.equipSlot;
    const prevId = this.saveData.player.equipment[slot];

    // Remove 1 from inventory
    entry.quantity -= 1;
    if (entry.quantity <= 0) {
      this.saveData.player.inventory.splice(index, 1);
    }

    // Return previous item to inventory
    if (prevId) {
      this.addItemToInventory(prevId, 1);
    }

    this.saveData.player.equipment[slot] = def.id;
    this.playerModel.syncEquipmentVisuals(this.saveData.player.equipment);
    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    this.saveData.player.maxHp = stats.maxHp;
    this.saveData.player.maxMana = stats.maxMana;
    this.saveData.player.maxStamina = stats.maxStamina;
    this.hp = Math.min(this.hp, stats.maxHp);
    this.mana = Math.min(this.mana, stats.maxMana);
    this.stamina = Math.min(this.stamina, stats.maxStamina);
    this.callbacks.onNotice(`تم تجهيز: ${def.nameAr}`);
  }

  public unequipSlot(slot: EquipSlot): void {
    const prevId = this.saveData.player.equipment[slot];
    if (!prevId) return;
    const def = ITEMS[prevId];
    this.saveData.player.equipment[slot] = null;
    this.playerModel.syncEquipmentVisuals(this.saveData.player.equipment);
    this.addItemToInventory(prevId, 1);

    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    this.saveData.player.maxHp = stats.maxHp;
    this.saveData.player.maxMana = stats.maxMana;
    this.saveData.player.maxStamina = stats.maxStamina;
    this.hp = Math.min(this.hp, stats.maxHp);
    this.mana = Math.min(this.mana, stats.maxMana);
    this.stamina = Math.min(this.stamina, stats.maxStamina);
    if (def) this.callbacks.onNotice(`تمت إزالة: ${def.nameAr}`);
  }

  public dropInventoryItem(index: number): void {
    const entry = this.saveData.player.inventory[index];
    if (!entry) return;
    const def = ITEMS[entry.itemId];
    this.saveData.player.inventory.splice(index, 1);
    if (def) this.callbacks.onNotice(`تم التخلص من: ${def.nameAr}`);
  }

  public restAtCamp(): void {
    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    this.saveData.player.survival.rest = 100;
    this.saveData.player.survival.temperature = 22;
    this.hp = Math.min(stats.maxHp, this.hp + Math.round(stats.maxHp * 0.35));
    this.mana = Math.min(stats.maxMana, this.mana + Math.round(stats.maxMana * 0.45));
    this.stamina = stats.maxStamina;
    this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, 0xfbbf24, 3.0, 0.55);
    this.callbacks.onNotice('أخذت قسطاً من الراحة واستعدت نشاطك.');
  }

  public unlockElement(elementId: ElementId): void {
    const prog = this.saveData.player.elements[elementId];
    const def = ELEMENTS[elementId];
    if (!prog || !def || prog.unlocked) return;
    if (this.saveData.player.elementShards < def.unlockCostShards) {
      this.callbacks.onNotice(
        `تحتاج إلى ${def.unlockCostShards} شظايا عنصرية لفتح ${def.nameAr}.`,
      );
      return;
    }
    this.saveData.player.elementShards -= def.unlockCostShards;
    prog.unlocked = true;
    prog.masteryLevel = 1;
    prog.xp = 0;

    // Auto-equip in empty slot 2 if available
    if (
      this.saveData.player.equippedElements[1] === null &&
      this.saveData.player.equippedElements[0] !== elementId
    ) {
      this.saveData.player.equippedElements[1] = elementId;
    }
    this.callbacks.onNotice(`تم فتح عنصر ${def.nameAr}!`);
  }

  public setEquippedElementSlot(slotIndex: 0 | 1, elementId: ElementId | null): void {
    if (elementId !== null && !this.saveData.player.elements[elementId]?.unlocked) {
      return;
    }
    const otherSlot: 0 | 1 = slotIndex === 0 ? 1 : 0;
    // Prevent equipping the same element twice
    if (elementId !== null && this.saveData.player.equippedElements[otherSlot] === elementId) {
      this.callbacks.onNotice('لا يمكن تجهيز العنصر نفسه في الخانتين.');
      return;
    }
    // Keep at least slot 0 active if user tries to empty both? Allow emptying slot 1 freely!
    if (slotIndex === 0 && elementId === null) {
      this.callbacks.onNotice('يفضل إبقاء الخانة الأولى مجهزة بعنصر.');
      return;
    }
    this.saveData.player.equippedElements[slotIndex] = elementId;
  }

  private grantPlayerXp(amount: number): void {
    this.saveData.player.xp += amount;
    let needed = 80 + (this.saveData.player.level - 1) * 55;
    while (this.saveData.player.xp >= needed) {
      this.saveData.player.xp -= needed;
      this.saveData.player.level += 1;
      this.saveData.player.elementShards += 1;
      const stats = computePlayerStats(
        this.saveData.player.level,
        this.saveData.player.equipment,
      );
      this.hp = stats.maxHp;
      this.mana = stats.maxMana;
      this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, 0xfbbf24, 4.5, 0.7);
      this.soundEngine.playPickup('levelup');
      this.callbacks.onNotice(`ارتفع مستواك إلى ${this.saveData.player.level}! (+1 شظية عنصرية)`);
      needed = 80 + (this.saveData.player.level - 1) * 55;
    }
  }

  private grantElementMasteryXp(elementId: ElementId, xpAmount: number): void {
    const prog = this.saveData.player.elements[elementId];
    if (!prog || !prog.unlocked || prog.masteryLevel >= 50) return;
    prog.xp += xpAmount;
    let req = getMasteryXpRequired(prog.masteryLevel);
    while (prog.xp >= req && prog.masteryLevel < 50) {
      prog.xp -= req;
      prog.masteryLevel += 1;
      this.callbacks.onNotice(
        `ارتفع إتقان ${ELEMENTS[elementId].nameAr} إلى المستوى ${prog.masteryLevel}!`,
      );
      req = getMasteryXpRequired(prog.masteryLevel);
    }
  }

  private processHarvestRewards(rewards: HarvestReward[]): void {
    for (const r of rewards) {
      this.addItemToInventory(r.itemId, r.quantity);
      this.saveData.player.elementShards += r.shardReward;
      this.saveData.player.gold += r.kind === 'crate' ? 12 : 6;
      this.grantPlayerXp(r.xpReward);
      this.soundEngine.playPickup(r.kind === 'crate' ? 'crate' : 'crystal');
      const itemName = ITEMS[r.itemId]?.nameAr ?? r.itemId;
      const shardText = r.shardReward > 0 ? ` +${r.shardReward} شظية` : '';
      this.callbacks.onNotice(`حصلت على: ${itemName} ×${r.quantity}${shardText}`);
      this.combatVfx.spawnBurst(
        r.x,
        r.y + 0.8,
        r.z,
        r.kind === 'crystal' ? 0x38bdf8 : 0xfbbf24,
        8,
      );
    }
  }

  private handleEntityKill = (evt: EntityKillEvent): void => {
    const { def, isDungeonBoss, rank, bySummon, wasRebelSummon } = evt;
    if (wasRebelSummon) {
      this.grantSummonMasteryXp(18);
      this.syncSummonSaveFields();
      this.callbacks.onNotice(`تم إخماد تمرد ${def.nameAr}! (+18 خبرة استحضار)`);
      return;
    }

    const prevRec = this.saveData.player.bestiary[def.id];
    const firstKill = !prevRec || !prevRec.summonUnlocked;
    this.saveData.player.bestiary[def.id] = {
      discovered: true,
      defeatedCount: (prevRec?.defeatedCount ?? 0) + 1,
      summonUnlocked: true,
    };

    const rankMult = rank === 'elite' ? 1.75 : rank === 'rare' ? 1.35 : rank === 'legendary' ? 2.2 : 1.0;
    const goldGain = Math.round(def.goldReward * rankMult);
    const xpGain = Math.round(def.xpReward * rankMult);
    const shardGain = def.shardReward + (rank === 'elite' || rank === 'legendary' ? 1 : 0);

    this.saveData.player.gold += goldGain;
    this.saveData.player.elementShards += shardGain;
    this.grantPlayerXp(xpGain);
    if (bySummon) this.grantSummonMasteryXp(10);

    const dropNames: string[] = [];
    for (const d of def.drops) {
      if (Math.random() <= d.chance) {
        this.addItemToInventory(d.itemId, d.qty);
        const itemDef = ITEMS[d.itemId];
        if (itemDef) dropNames.push(`${itemDef.nameAr}×${d.qty}`);
      }
    }

    if (def.category === 'monster' || def.category === 'boss') {
      this.saveData.player.monstersKilled += 1;
      this.advanceQuest('kill_monsters', 1);
    }
    if (def.category === 'boss') {
      this.saveData.player.bossesDefeated += 1;
      this.advanceQuest('defeat_boss', 1);
    }

    if (isDungeonBoss && this.dungeon) {
      const pId = this.dungeon.portal.id;
      this.saveData.player.dungeonsCleared += 1;
      if (!this.saveData.clearedDungeons) this.saveData.clearedDungeons = [];
      if (!this.saveData.clearedDungeons.includes(pId)) {
        this.saveData.clearedDungeons.push(pId);
      }
      this.advanceQuest('clear_dungeon', 1);
      this.callbacks.onNotice(`تم تطهير ${this.dungeon.portal.nameAr}! افتح صندوق الكنز أو عد عبر البوابة.`);
      return;
    }

    const dropText = dropNames.length > 0 ? ` • غنيمة: ${dropNames.join('، ')}` : '';
    const unlockText = firstKill ? ' • فُتح الاستحضار!' : '';
    this.callbacks.onNotice(`هزمت ${def.nameAr} (+${goldGain} ذهب)${dropText}${unlockText}`);
  };

  private advanceQuest(targetType: 'kill_monsters' | 'clear_dungeon' | 'defeat_boss', delta: number): void {
    for (const qDef of QUESTS) {
      if (qDef.targetType !== targetType) continue;
      const qp = this.saveData.player.quests[qDef.id];
      if (!qp || !qp.accepted || qp.completed) continue;
      qp.progress = Math.min(qDef.targetCount, qp.progress + delta);
      if (qp.progress >= qDef.targetCount) {
        qp.completed = true;
        this.callbacks.onNotice(`اكتملت المهمة: ${qDef.titleAr}! عد إلى الحكيم أوريون للمكافأة.`);
      }
    }
  }

  private handlePlayerDamaged = (rawDamage: number, attackerNameAr: string): void => {
    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    const shieldMult = this.combatVfx.isShieldActive ? 0.45 : 1.0;
    const blockMult = this.isBlocking ? 0.35 : 1.0;
    const mitigated = Math.max(
      1,
      Math.round((rawDamage - stats.defense * 0.42) * shieldMult * blockMult),
    );
    if (this.isBlocking) {
      this.soundEngine.playBlockClang();
      this.combatVfx.spawnBlockSparks(this.posX, this.posY, this.posZ, this.facingYaw);
    } else {
      this.playerModel.triggerHurt();
    }
    this.hp = Math.max(0, this.hp - mitigated);
    if (this.hp <= 0) {
      if (this.dungeon) {
        this.exitDungeon(true);
      }
      const vy = getWorldHeight(VILLAGE_CENTER.x, VILLAGE_CENTER.z, this.saveData.seed);
      this.posX = VILLAGE_CENTER.x;
      this.posY = vy;
      this.posZ = VILLAGE_CENTER.z + 2;
      this.velY = 0;
      this.hp = Math.round(stats.maxHp * 0.7);
      this.mana = Math.round(stats.maxMana * 0.7);
      this.callbacks.onNotice(`سقطت أمام ${attackerNameAr}! تمت إعادتك بأمان إلى قرية إيثيريا.`);
    }
  };

  public enterDungeon(portal: DungeonPortalInfo): void {
    if (this.dungeon) return;
    this.soundEngine.playPortal();
    this.savedOverworldPos = { x: this.posX, y: this.posY, z: this.posZ };
    this.chunkManager.setVisible(false);
    this.entityManager.setVillageVisible(false);
    for (const c of this.clouds) c.visible = false;

    const castShadows = !this.isSoftwareGl && this.settings.shadowQuality !== 'off';
    this.dungeon = new DungeonInstance(this.scene, portal, this.saveData.seed, castShadows);
    this.entityManager.spawnDungeonEntities(portal, this.dungeon.enemySpawns);

    this.posX = 0;
    this.posY = 0;
    this.posZ = 0;
    this.velY = 0;
    this.yaw = 0;
    this.facingYaw = Math.PI;
    this.currentCamX = 0;
    this.currentCamY = 3.2;
    this.currentCamZ = 4.5;

    const dungeonSummons = this.entityManager
      .getActiveSummonsHud()
      .filter((s) => !s.isRebel)
      .map((s) => s.entityId);
    if (dungeonSummons.length > 0) {
      this.entityManager.syncSummons(
        dungeonSummons,
        0,
        0,
        0,
        this.saveData.player.summonMasteryLevel ?? 1,
      );
    }
    this.callbacks.onNotice(`دخلت ${portal.nameAr} (المستوى ${portal.level})`);
  }

  public exitDungeon(silent = false): void {
    if (!this.dungeon) return;
    if (!silent) this.soundEngine.playPortal();
    const prevName = this.dungeon.portal.nameAr;
    this.entityManager.clearDungeonEntities();
    this.dungeon.dispose();
    this.dungeon = null;

    this.chunkManager.setVisible(true);
    this.entityManager.setVillageVisible(true);
    const showClouds = this.settings.preset !== 'low';
    for (const c of this.clouds) c.visible = showClouds;

    if (this.savedOverworldPos) {
      this.posX = this.savedOverworldPos.x;
      this.posY = this.savedOverworldPos.y;
      this.posZ = this.savedOverworldPos.z;
      this.savedOverworldPos = null;
    } else {
      this.posX = 0;
      this.posZ = 0;
      this.posY = getWorldHeight(0, 0, this.saveData.seed);
    }
    this.velY = 0;
    this.currentCamX = this.posX;
    this.currentCamY = this.posY + 3.0;
    this.currentCamZ = this.posZ + 5.0;

    const exitSummons = this.entityManager
      .getActiveSummonsHud()
      .filter((s) => !s.isRebel)
      .map((s) => s.entityId);
    if (exitSummons.length > 0) {
      this.entityManager.syncSummons(
        exitSummons,
        this.posX,
        this.posY,
        this.posZ,
        this.saveData.player.summonMasteryLevel ?? 1,
      );
    }
    if (!silent) {
      this.callbacks.onNotice(`خرجت من ${prevName} إلى العالم المفتوح.`);
    }
  }

  public interactWithNearby(): void {
    if (!this.currentNearby) return;
    if (this.currentNearby.kind === 'dungeon_exit') {
      this.exitDungeon();
      return;
    }
    if (this.currentNearby.kind === 'dungeon_chest' && this.currentNearby.id === 'world_event_chest' && this.eventChest?.active) {
      const chest = this.eventChest;
      chest.active = false;
      chest.group.visible = false;
      this.soundEngine.playPickup('chest');
      const gold = 65 + Math.floor(Math.random() * 45);
      const shards = 2;
      const lootPool = ['bone_plated_shield', 'runic_blade', 'ember_axe', 'necromancer_ring', 'arcane_crystal', 'healing_potion'];
      const lootId = lootPool[Math.floor(Math.random() * lootPool.length)];
      this.saveData.player.gold += gold;
      this.saveData.player.elementShards += shards;
      this.addItemToInventory(lootId, 1);
      this.combatVfx.spawnBurst(chest.x, chest.y + 0.9, chest.z, 0xfbbf24, 14);
      const itemName = ITEMS[lootId]?.nameAr ?? lootId;
      this.callbacks.onNotice(`كنز الحدث المخفي: +${gold} ذهب، +${shards} شظية، ${itemName}!`);
      return;
    }
    if (this.currentNearby.kind === 'dungeon_chest' && this.dungeon) {
      const chest = this.dungeon.getNearbyChest(this.posX, this.posZ, 3.0);
      if (chest) {
        this.dungeon.markChestOpened(chest);
        this.soundEngine.playPickup('chest');
        const secretBonus = chest.isSecret ? 40 : 0;
        const gold = 45 + this.dungeon.portal.level * 12 + secretBonus;
        const shards = 1 + (this.dungeon.portal.level >= 6 ? 1 : 0) + (chest.isSecret ? 1 : 0);
        const lootOptions = chest.isSecret
          ? ['runic_blade', 'ember_axe', 'arcane_tome', 'jade_amulet']
          : ['healing_potion', 'mana_potion', 'arcane_crystal', 'runic_blade', 'steel_helm'];
        const lootId = lootOptions[Math.floor(Math.random() * lootOptions.length)];
        this.saveData.player.gold += gold;
        this.saveData.player.elementShards += shards;
        this.addItemToInventory(lootId, 1);
        this.combatVfx.spawnBurst(chest.x, 1.0, chest.z, 0xfbbf24, 12);
        const itemName = ITEMS[lootId]?.nameAr ?? lootId;
        const prefix = chest.isSecret ? 'كنز الغرفة السرية' : 'كنز المكان';
        this.callbacks.onNotice(`${prefix}: +${gold} ذهب، +${shards} شظية، ${itemName}!`);
      }
      return;
    }
    if (this.currentNearby.kind === 'portal' && this.currentPortal) {
      this.enterDungeon(this.currentPortal);
      return;
    }
    if (this.currentNearby.kind === 'npc' && this.currentNpc) {
      this.callbacks.onOpenNpc(this.currentNpc);
    }
  }

  public addMapMarker(x: number, z: number, labelAr: string, colorHex: string): void {
    if (!this.saveData.mapMarkers) this.saveData.mapMarkers = [];
    this.saveData.mapMarkers.push({
      id: `m_${Date.now()}_${Math.floor(Math.random() * 999)}`,
      x: Math.round(x),
      z: Math.round(z),
      labelAr,
      colorHex,
    });
  }

  public removeMapMarker(id: string): void {
    if (!this.saveData.mapMarkers) return;
    this.saveData.mapMarkers = this.saveData.mapMarkers.filter((m) => m.id !== id);
  }

  // --- NPC Shop / Blacksmith / Healer / Quest / Summon Actions ---

  public buyMerchantItem(itemId: string, price: number): void {
    const def = ITEMS[itemId];
    if (!def) return;
    if (this.saveData.player.gold < price) {
      this.callbacks.onNotice('الذهب غير كافٍ لشراء هذا الغرض.');
      return;
    }
    this.saveData.player.gold -= price;
    this.addItemToInventory(itemId, 1);
    this.callbacks.onNotice(`اشتريت: ${def.nameAr}`);
  }

  public sellInventoryItem(index: number): void {
    const entry = this.saveData.player.inventory[index];
    if (!entry) return;
    const def = ITEMS[entry.itemId];
    if (!def) return;
    const sellPrice = Math.max(4, Math.round(def.valueGold * 0.55));
    entry.quantity -= 1;
    if (entry.quantity <= 0) {
      this.saveData.player.inventory.splice(index, 1);
    }
    this.saveData.player.gold += sellPrice;
    this.callbacks.onNotice(`بعت ${def.nameAr} مقابل ${sellPrice} ذهب.`);
  }

  public craftBlacksmithItem(forgeIndex: number): void {
    const recipe = BLACKSMITH_FORGE[forgeIndex];
    if (!recipe) return;
    const def = ITEMS[recipe.itemId];
    if (!def) return;
    if (this.saveData.player.gold < recipe.goldCost) {
      this.callbacks.onNotice(`تحتاج إلى ${recipe.goldCost} ذهب للصناعة.`);
      return;
    }
    for (const mat of recipe.materials) {
      const inv = this.saveData.player.inventory.find((i) => i.itemId === mat.itemId);
      if (!inv || inv.quantity < mat.qty) {
        const mName = ITEMS[mat.itemId]?.nameAr ?? mat.itemId;
        this.callbacks.onNotice(`ينقصك: ${mName} (المطلوب ${mat.qty}).`);
        return;
      }
    }
    // Deduct materials & gold
    this.saveData.player.gold -= recipe.goldCost;
    for (const mat of recipe.materials) {
      const idx = this.saveData.player.inventory.findIndex((i) => i.itemId === mat.itemId);
      if (idx >= 0) {
        this.saveData.player.inventory[idx].quantity -= mat.qty;
        if (this.saveData.player.inventory[idx].quantity <= 0) {
          this.saveData.player.inventory.splice(idx, 1);
        }
      }
    }
    this.addItemToInventory(recipe.itemId, 1);
    this.combatVfx.spawnBurst(this.posX, this.posY + 1.2, this.posZ, 0xf97316, 10);
    this.callbacks.onNotice(`صنعت سلاحاً/درعاً جديداً: ${def.nameAr}!`);
  }

  public healAtNpc(): void {
    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    this.hp = stats.maxHp;
    this.mana = stats.maxMana;
    this.stamina = stats.maxStamina;
    this.saveData.player.survival = { hunger: 100, thirst: 100, temperature: 22, rest: 100 };
    this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, 0x34d399, 3.6, 0.55);
    this.callbacks.onNotice('عالجتك ليرا واستعدت كامل الصحة والطاقة!');
  }

  public acceptQuest(questId: string): void {
    const qp = this.saveData.player.quests[questId];
    const def = QUESTS.find((q) => q.id === questId);
    if (!qp || !def || qp.accepted) return;
    qp.accepted = true;
    this.callbacks.onNotice(`قبلت المهمة: ${def.titleAr}`);
  }

  public claimQuest(questId: string): void {
    const qp = this.saveData.player.quests[questId];
    const def = QUESTS.find((q) => q.id === questId);
    if (!qp || !def || !qp.completed || qp.claimed) return;
    qp.claimed = true;
    this.saveData.player.gold += def.rewardGold;
    this.saveData.player.elementShards += def.rewardShards;
    this.addItemToInventory(def.rewardItemId, 1);
    this.grantPlayerXp(def.rewardXp);
    this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, 0xfbbf24, 4.0, 0.65);
    this.callbacks.onNotice(`استلمت مكافأة مهمة ${def.titleAr}!`);
  }

  public getSoulControlMax(): number {
    const p = this.saveData.player;
    const mastery = p.summonMasteryLevel ?? 1;
    const acc = p.equipment.accessory;
    const accBonus = acc === 'necromancer_ring' ? 12 : acc === 'jade_amulet' ? 8 : 0;
    const skillBonus = (p.skillRanks?.['summon_capacity'] ?? 0) * 6;
    return 16 + p.level * 3 + (mastery - 1) * 5 + accBonus + skillBonus;
  }

  private grantSummonMasteryXp(amount: number): void {
    const p = this.saveData.player;
    p.summonMasteryLevel = p.summonMasteryLevel ?? 1;
    p.summonMasteryXp = (p.summonMasteryXp ?? 0) + amount;
    let req = 45 + (p.summonMasteryLevel - 1) * 35;
    while (p.summonMasteryXp >= req && p.summonMasteryLevel < 50) {
      p.summonMasteryXp -= req;
      p.summonMasteryLevel += 1;
      this.callbacks.onNotice(
        `ارتفع إتقان الاستحضار إلى المستوى ${p.summonMasteryLevel}! (+5 سعة سيطرة أرواح)`,
      );
      req = 45 + (p.summonMasteryLevel - 1) * 35;
    }
  }

  private syncSummonSaveFields(): void {
    const loyalIds = this.entityManager
      .getActiveSummonsHud()
      .filter((s) => !s.isRebel)
      .map((s) => s.entityId);
    this.saveData.player.activeSummonIds = loyalIds;
    this.saveData.player.activeSummonId = loyalIds[0] ?? null;
  }

  public summonMonster(entityId: string): void {
    const rec = this.saveData.player.bestiary[entityId];
    const def = ALL_ENTITY_DEFS[entityId];
    if (!def || !rec?.summonUnlocked) {
      this.callbacks.onNotice('اهزم هذا الكائن أولاً لفتح استحضاره.');
      return;
    }
    const cds = (this.saveData.player.summonCooldowns ??= {});
    const cd = cds[entityId] ?? 0;
    if (cd > 0) {
      this.callbacks.onNotice(`هذا المخلوق في فترة انتظار (${Math.ceil(cd)}ث).`);
      return;
    }
    if (this.mana < def.summonManaCost) {
      this.callbacks.onNotice(`تحتاج إلى ${def.summonManaCost} Mana لاستحضار ${def.nameAr}.`);
      return;
    }

    const soulMax = this.getSoulControlMax();
    const currentUsed = this.entityManager.getUsedSoulPower(false);
    const addedSoul = def.soulPower ?? 8;
    const willRebel = currentUsed + addedSoul > soulMax;

    this.mana -= def.summonManaCost;
    cds[entityId] = def.summonCooldownSec ?? 16;

    const entry = this.entityManager.addSummon(entityId, this.posX, this.posY, this.posZ, {
      durationSec: def.summonDurationSec ?? 45,
      isRebel: willRebel,
      masteryLevel: this.saveData.player.summonMasteryLevel ?? 1,
    });
    if (!entry) return;

    this.syncSummonSaveFields();
    this.combatVfx.spawnRing(
      this.posX,
      this.posY,
      this.posZ,
      willRebel ? 0xef4444 : def.glowHex,
      4.2,
      0.65,
    );

    if (willRebel) {
      this.soundEngine.playCreatureSound(def.archetype, 'aggro', undefined, def.skeletonVariant);
      this.callbacks.onNotice(
        `تحذير: تجاوزت طاقة السيطرة (${currentUsed + addedSoul}/${soulMax})! تمرد ${def.nameAr}!`,
      );
    } else {
      this.grantSummonMasteryXp(12);
      this.callbacks.onNotice(`استُحضر ${def.nameAr} (${entry.durationSec}ث) للقتال بجانبك!`);
    }
  }

  public reclaimRebelSummon(uid: string): void {
    const entry = this.entityManager.getSummonByUid(uid);
    if (!entry || !entry.isRebel) return;
    const def = ALL_ENTITY_DEFS[entry.entityId];
    if (!def) return;

    const soulMax = this.getSoulControlMax();
    const currentUsed = this.entityManager.getUsedSoulPower(false);
    if (currentUsed + entry.soulPower > soulMax) {
      this.callbacks.onNotice(
        `سعة السيطرة غير كافية (${currentUsed + entry.soulPower}/${soulMax}) — اصرف مستحضراً أو طوّر مستواك!`,
      );
      return;
    }
    const reclaimCost = Math.max(8, Math.round(def.summonManaCost * 0.6));
    if (this.mana < reclaimCost) {
      this.callbacks.onNotice(`تحتاج إلى ${reclaimCost} MP لإعادة إخضاع ${def.nameAr}.`);
      return;
    }
    this.mana -= reclaimCost;
    this.entityManager.reclaimSummon(uid);
    this.syncSummonSaveFields();
    this.grantSummonMasteryXp(15);
    this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, 0x22d3ee, 3.6, 0.55);
    this.callbacks.onNotice(`تمت إعادة إخضاع روح ${def.nameAr} بنجاح!`);
  }

  public dismissSummon(uid?: string): void {
    const removed = this.entityManager.removeSummonByUid(uid);
    this.syncSummonSaveFields();
    if (removed) {
      this.callbacks.onNotice('تم صرف المخلوق المستحضر.');
    }
  }

  public performAttack(): void {
    if (this.attackCooldown > 0) return;
    this.attackCooldown = 0.34;
    this.playerModel.triggerAttack();
    this.soundEngine.playSlash();

    const dirX = Math.sin(this.facingYaw);
    const dirZ = Math.cos(this.facingYaw);
    const hitX = this.posX + dirX * 1.5;
    const hitZ = this.posZ + dirZ * 1.5;

    this.combatVfx.spawnSlash(this.posX, this.posY, this.posZ, this.facingYaw, 0xfef08a);

    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    let totalHits = 0;

    if (!this.dungeon) {
      const nodeHits = this.chunkManager.damageNodesInRadius(hitX, hitZ, 2.3, stats.attack, _rewards);
      totalHits += nodeHits;
      if (_rewards.length > 0) {
        this.processHarvestRewards(_rewards);
      }
    } else {
      const innerHits = this.dungeon.damageInteriorNodesInRadius(hitX, hitZ, 2.3, stats.attack, _rewards);
      totalHits += innerHits;
      if (_rewards.length > 0) {
        this.processHarvestRewards(_rewards);
      }
    }

    const mobRes = this.entityManager.damageEntitiesInRadius(
      hitX,
      hitZ,
      2.35,
      stats.attack,
      undefined,
      this.combatVfx,
      this.handleEntityKill,
      (arch, action, spatial, variant) =>
        this.soundEngine.playCreatureSound(arch, action, spatial, variant),
    );
    totalHits += mobRes.hits;

    if (totalHits > 0) {
      this.soundEngine.playHit(mobRes.weaknessTriggered);
      this.combatVfx.spawnBurst(hitX, this.posY + 0.9, hitZ, 0xfde047, 5);
    }
  }

  public castElementAbility(elementId: ElementId, abilityIndex: 0 | 1 | 2 | 3): void {
    const def = ELEMENTS[elementId];
    const prog = this.saveData.player.elements[elementId];
    if (!def || !prog?.unlocked) return;
    const ab = def.abilities[abilityIndex];
    if (!ab) return;

    if (prog.masteryLevel < ab.unlockMastery) {
      this.callbacks.onNotice(`تتطلب هذه القدرة مستوى إتقان ${ab.unlockMastery}.`);
      return;
    }

    const cd = this.abilityCooldowns[ab.id] ?? 0;
    if (cd > 0) return;

    if (this.mana < ab.manaCost) {
      this.callbacks.onNotice('طاقة السحر (Mana) غير كافية!');
      return;
    }

    this.mana -= ab.manaCost;
    this.abilityCooldowns[ab.id] = ab.cooldownSec;
    this.playerModel.triggerCast();
    this.soundEngine.playElementSpell(elementId, ab.kind);

    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    const masteryMult = 1 + (prog.masteryLevel - 1) * 0.04;
    const spellPower = Math.round((ab.power + stats.magic * 0.8) * masteryMult);

    const aimX = -Math.sin(this.yaw);
    const aimZ = -Math.cos(this.yaw);
    const aimY = this.cameraMode === 'first' ? Math.sin(this.pitch) : 0.04;

    if (ab.kind === 'attack') {
      this.combatVfx.spawnProjectile(
        this.posX + aimX * 0.9,
        this.posY + 1.25,
        this.posZ + aimZ * 0.9,
        aimX,
        aimY,
        aimZ,
        24,
        spellPower,
        def.accentHex,
        1.1,
        elementId,
      );
    } else if (ab.kind === 'defense') {
      this.combatVfx.activateShield(def.accentHex, 5.5);
      if (elementId === 'lightning' || elementId === 'time' || elementId === 'wind') {
        this.hasteTimer = 5.0;
      }
      if (elementId === 'nature' || elementId === 'light') {
        this.hp = Math.min(stats.maxHp, this.hp + Math.round(spellPower * 0.9));
      }
      if (elementId === 'water' || elementId === 'ice') {
        this.saveData.player.survival.temperature = Math.max(
          18,
          this.saveData.player.survival.temperature - 5,
        );
      }
      this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, def.accentHex, 3.2, 0.5);
    } else {
      const radius = ab.kind === 'ultimate' ? 6.8 : 4.4;
      this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, def.accentHex, radius, 0.72);
      if (!this.dungeon) {
        this.chunkManager.damageNodesInRadius(this.posX, this.posZ, radius, spellPower, _rewards);
        if (_rewards.length > 0) this.processHarvestRewards(_rewards);
      } else {
        this.dungeon.damageInteriorNodesInRadius(this.posX, this.posZ, radius, spellPower, _rewards);
        if (_rewards.length > 0) this.processHarvestRewards(_rewards);
      }
      const res = this.entityManager.damageEntitiesInRadius(
        this.posX,
        this.posZ,
        radius,
        spellPower,
        elementId,
        this.combatVfx,
        this.handleEntityKill,
        (arch, action, spatial, variant) =>
          this.soundEngine.playCreatureSound(arch, action, spatial, variant),
      );
      if (res.hits > 0) this.soundEngine.playHit(res.weaknessTriggered);

      if (elementId === 'light' || elementId === 'nature') {
        this.hp = Math.min(stats.maxHp, this.hp + Math.round(spellPower * 0.65));
      }
    }

    this.grantElementMasteryXp(elementId, ab.kind === 'ultimate' ? 18 : 10);
  }

  public castFusion(): void {
    const [slotA, slotB] = this.saveData.player.equippedElements;
    const fusion = getActiveFusion(slotA, slotB, this.saveData.player.elements);
    if (!fusion) return;

    const cd = this.abilityCooldowns[fusion.id] ?? 0;
    if (cd > 0) return;
    if (this.mana < fusion.manaCost) {
      this.callbacks.onNotice('طاقة السحر (Mana) غير كافية للدمج!');
      return;
    }

    this.mana -= fusion.manaCost;
    this.abilityCooldowns[fusion.id] = fusion.cooldownSec;
    this.playerModel.triggerCast();
    this.soundEngine.playElementSpell(slotA ?? 'fire', 'fusion');

    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    const power = fusion.power + stats.magic * 1.4;

    this.combatVfx.spawnRing(this.posX, this.posY, this.posZ, fusion.accentHex, 7.5, 0.85);
    this.combatVfx.spawnBurst(this.posX, this.posY + 1.1, this.posZ, fusion.accentHex, 10);

    const aimX = -Math.sin(this.yaw);
    const aimZ = -Math.cos(this.yaw);
    this.combatVfx.spawnProjectile(
      this.posX + aimX,
      this.posY + 1.3,
      this.posZ + aimZ,
      aimX,
      0.02,
      aimZ,
      26,
      power,
      fusion.accentHex,
      1.6,
      slotA ?? undefined,
    );

    if (!this.dungeon) {
      this.chunkManager.damageNodesInRadius(this.posX, this.posZ, 7.5, power, _rewards);
      if (_rewards.length > 0) this.processHarvestRewards(_rewards);
    } else {
      this.dungeon.damageInteriorNodesInRadius(this.posX, this.posZ, 7.5, power, _rewards);
      if (_rewards.length > 0) this.processHarvestRewards(_rewards);
    }
    const res = this.entityManager.damageEntitiesInRadius(
      this.posX,
      this.posZ,
      7.5,
      power,
      slotA ?? undefined,
      this.combatVfx,
      this.handleEntityKill,
      (arch, action, spatial, variant) =>
        this.soundEngine.playCreatureSound(arch, action, spatial, variant),
    );
    if (res.hits > 0) this.soundEngine.playHit(res.weaknessTriggered);

    if (slotA) this.grantElementMasteryXp(slotA, 15);
    if (slotB) this.grantElementMasteryXp(slotB, 15);
    this.callbacks.onNotice(`دمج عنصري: ${fusion.nameAr}!`);
  }

  public getSaveSnapshot(): SaveDataV1 {
    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
    const savePos = this.dungeon && this.savedOverworldPos ? this.savedOverworldPos : {
      x: this.posX,
      y: this.posY,
      z: this.posZ,
    };
    this.saveData.player = {
      ...this.saveData.player,
      x: Number(savePos.x.toFixed(2)),
      y: Number(savePos.y.toFixed(2)),
      z: Number(savePos.z.toFixed(2)),
      yaw: Number(this.yaw.toFixed(3)),
      pitch: Number(this.pitch.toFixed(3)),
      cameraMode: this.cameraMode,
      hp: Math.round(this.hp),
      maxHp: stats.maxHp,
      mana: Math.round(this.mana),
      maxMana: stats.maxMana,
      stamina: Math.round(this.stamina),
      maxStamina: stats.maxStamina,
    };
    this.saveData.discoveredBiomes = Array.from(this.discoveredBiomes);
    this.saveData.discoveredChunks = this.chunkManager.getDiscoveredChunks();
    this.saveData.harvestedNodes = this.chunkManager.getHarvestedNodes();
    this.saveData.graphics = { ...this.settings };
    this.saveData.audio = { ...this.audioSettings };
    return structuredClone(this.saveData);
  }

  private startLoop(): void {
    const afterDraw = (cb: () => void) => {
      const gl = this.renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      if (!sync) {
        this.frameId = window.setTimeout(cb, 80);
        return;
      }
      const poll = () => {
        if (this.disposed) {
          gl.deleteSync(sync);
          return;
        }
        const state = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          this.frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          this.frameId = window.setTimeout(cb, 80);
        }
      };
      this.frameId = window.setTimeout(poll, 5);
    };

    const tick = (now = performance.now()) => {
      if (this.disposed) return;

      if (!this.isSoftwareGl && this.settings.maxFps === 30) {
        if (now - this.lastRenderTime < 31) {
          this.frameId = requestAnimationFrame(tick);
          return;
        }
      }
      this.lastRenderTime = now;

      const rawDt = this.clock.getDelta();
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

      this.updateSimulation(dt, rawDt, now);
      this.renderer.render(this.scene, this.camera);

      if (this.callbacks.onNameplates) {
        this.camera.updateMatrixWorld();
        this.entityManager.getProjectedNameplates(
          this.camera,
          this.container.clientWidth,
          this.container.clientHeight,
          _nameplatesBuf,
        );
        this.callbacks.onNameplates(_nameplatesBuf);
      }

      if (this.isSoftwareGl) {
        afterDraw(() => tick(performance.now()));
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    this.frameId = requestAnimationFrame(tick);
  }

  private updateSimulation(dt: number, rawDt: number, now: number): void {
    this.saveData.playTimeSeconds += dt;
    const snap = this.input.consumeSnapshot();
    const stats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);

    // Cooldowns tick
    if (this.attackCooldown > 0) this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    if (this.hasteTimer > 0) this.hasteTimer = Math.max(0, this.hasteTimer - dt);
    for (const k of Object.keys(this.abilityCooldowns)) {
      if (this.abilityCooldowns[k] > 0) {
        this.abilityCooldowns[k] = Math.max(0, this.abilityCooldowns[k] - dt);
      }
    }
    if (this.saveData.player.summonCooldowns) {
      for (const sKey of Object.keys(this.saveData.player.summonCooldowns)) {
        if (this.saveData.player.summonCooldowns[sKey] > 0) {
          this.saveData.player.summonCooldowns[sKey] = Math.max(
            0,
            this.saveData.player.summonCooldowns[sKey] - dt,
          );
        }
      }
    }

    if (snap.attackPressed) {
      this.performAttack();
    }
    if (snap.interactPressed) {
      this.interactWithNearby();
    }

    // 1. Camera look rotation
    const lookSensitivity = 0.0048;
    this.yaw -= snap.lookDeltaX * lookSensitivity;
    this.pitch = THREE.MathUtils.clamp(
      this.pitch - snap.lookDeltaY * lookSensitivity,
      this.cameraMode === 'first' ? -1.35 : -1.15,
      this.cameraMode === 'first' ? 1.35 : 0.48,
    );

    if (snap.zoomDelta !== 0 && this.cameraMode === 'third') {
      this.thirdPersonDist = THREE.MathUtils.clamp(this.thirdPersonDist + snap.zoomDelta, 3.2, 11.5);
    }

    const fwdX = -Math.sin(this.yaw);
    const fwdZ = -Math.cos(this.yaw);
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);

    // 2. Dash & Sprint Stamina logic (Walking NEVER consumes stamina!)
    if (this.dashCooldown > 0) this.dashCooldown = Math.max(0, this.dashCooldown - dt);
    if (this.dashTimer > 0) this.dashTimer = Math.max(0, this.dashTimer - dt);

    const hasMoveInput = Math.hypot(snap.moveX, snap.moveY) > 0.06;
    if (snap.dashPressed && this.dashCooldown <= 0 && this.stamina >= 18) {
      this.dashTimer = 0.22;
      this.dashCooldown = 1.05;
      this.stamina = Math.max(0, this.stamina - 18);
    }

    const canSprint = snap.sprintActive && hasMoveInput && this.stamina > 2 && !this.isSwimming;
    if (canSprint) {
      this.stamina = Math.max(0, this.stamina - dt * 12);
    } else {
      this.stamina = Math.min(stats.maxStamina, this.stamina + dt * 22);
    }

    this.isBlocking = snap.blockActive && !this.isSwimming && this.dashTimer <= 0;
    this.playerModel.setBlocking(this.isBlocking);

    // 3. Movement velocity
    const hasteMult = this.hasteTimer > 0 ? 1.32 : 1.0;
    const blockMoveMult = this.isBlocking ? 0.65 : 1.0;
    const baseSpeed =
      (this.isSwimming ? 5.4 : canSprint ? 10.4 : 6.6) *
      stats.speedMultiplier *
      hasteMult *
      blockMoveMult;
    const speed = this.dashTimer > 0 ? 18.5 : baseSpeed;

    let moveDirX = rightX * snap.moveX + fwdX * snap.moveY;
    let moveDirZ = rightZ * snap.moveX + fwdZ * snap.moveY;
    const moveMag = Math.hypot(moveDirX, moveDirZ);
    if (moveMag > 0.001) {
      const clampedMag = Math.min(1, moveMag);
      moveDirX = (moveDirX / moveMag) * clampedMag;
      moveDirZ = (moveDirZ / moveMag) * clampedMag;
    }

    const horizSpeed = moveMag > 0.05 ? speed * Math.min(1, moveMag) : 0;
    this.posX += moveDirX * speed * dt;
    this.posZ += moveDirZ * speed * dt;

    // 4. Obstacle / Dungeon Wall collision resolution
    const playerRadius = 0.42;
    if (this.dungeon) {
      const clamped = this.dungeon.clampPosition(this.posX, this.posZ, playerRadius);
      this.posX = clamped.x;
      this.posZ = clamped.z;
    } else {
      this.chunkManager.getNearbyColliders(this.posX, this.posZ, _colliders);
      for (let i = 0; i < _colliders.length; i++) {
        const c = _colliders[i];
        if (this.posY > c.topY) continue;
        const dx = this.posX - c.x;
        const dz = this.posZ - c.z;
        const minDist = playerRadius + c.radius;
        const distSq = dx * dx + dz * dz;
        if (distSq < minDist * minDist && distSq > 0.00001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          this.posX += (dx / dist) * push;
          this.posZ += (dz / dist) * push;
        }
      }
    }

    // 5. Vertical physics & swimming
    const groundY = this.dungeon ? 0 : getWorldHeight(this.posX, this.posZ, this.saveData.seed);
    const waterSurfacePlayerY = WATER_LEVEL - 0.65;
    this.isSwimming = !this.dungeon && groundY < waterSurfacePlayerY && this.posY <= WATER_LEVEL - 0.35;

    if (this.isSwimming) {
      const targetSwimY = Math.max(groundY, waterSurfacePlayerY);
      this.posY = THREE.MathUtils.damp(this.posY, targetSwimY, 6, dt);
      this.velY = snap.jumpPressed ? 6.8 : 0;
      this.isGrounded = false;
    } else {
      if (snap.jumpPressed && this.isGrounded) {
        this.velY = 8.8;
        this.isGrounded = false;
      }
      this.velY -= 22.0 * dt;
      this.posY += this.velY * dt;

      if (this.posY <= groundY) {
        this.posY = groundY;
        this.velY = 0;
        this.isGrounded = true;
      } else if (this.posY - groundY < 0.08 && this.velY <= 0) {
        this.posY = groundY;
        this.velY = 0;
        this.isGrounded = true;
      } else {
        this.isGrounded = false;
      }
    }

    // 6. Player model & facing
    if (moveMag > 0.08 && this.cameraMode === 'third') {
      const targetFace = Math.atan2(moveDirX, moveDirZ);
      this.facingYaw = lerpAngle(this.facingYaw, targetFace, 1 - Math.exp(-12 * dt));
    } else if (this.cameraMode === 'first') {
      this.facingYaw = this.yaw + Math.PI;
    }

    this.playerModel.root.position.set(this.posX, this.posY, this.posZ);
    this.playerModel.root.rotation.y = this.facingYaw;
    this.playerModel.updateAnimation(
      dt,
      horizSpeed,
      this.isGrounded,
      this.isSwimming,
      this.dashTimer > 0,
    );

    // 7. Camera positioning
    if (this.cameraMode === 'first') {
      const eyeY = this.posY + (this.isSwimming ? 1.25 : 1.62);
      this.camera.position.set(this.posX, eyeY, this.posZ);
      const lookX = this.posX + fwdX * Math.cos(this.pitch) * 10;
      const lookY = eyeY + Math.sin(this.pitch) * 10;
      const lookZ = this.posZ + fwdZ * Math.cos(this.pitch) * 10;
      this.camera.lookAt(lookX, lookY, lookZ);
    } else {
      const targetY = this.posY + 1.48;
      const horizDist = this.thirdPersonDist * Math.cos(this.pitch);
      const vertOffset = -this.thirdPersonDist * Math.sin(this.pitch);

      const desiredCamX = this.posX - fwdX * horizDist;
      const desiredCamZ = this.posZ - fwdZ * horizDist;
      const camGround = this.dungeon
        ? 0
        : getWorldHeight(desiredCamX, desiredCamZ, this.saveData.seed);
      const maxCamY = this.dungeon ? 4.3 : 999;
      const desiredCamY = Math.min(maxCamY, Math.max(targetY + vertOffset, camGround + 0.65));

      this.currentCamX = THREE.MathUtils.damp(this.currentCamX, desiredCamX, 16, dt);
      this.currentCamY = THREE.MathUtils.damp(this.currentCamY, desiredCamY, 16, dt);
      this.currentCamZ = THREE.MathUtils.damp(this.currentCamZ, desiredCamZ, 16, dt);

      this.camera.position.set(this.currentCamX, this.currentCamY, this.currentCamZ);
      this.camera.lookAt(this.posX, targetY, this.posZ);
    }

    const targetFov = this.dashTimer > 0 ? 73 : canSprint || this.hasteTimer > 0 ? 68 : 64;
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 10, dt);
      this.camera.updateProjectionMatrix();
    }

    // 8. Combat VFX & Projectile collisions with entities + world crystals/crates
    this.combatVfx.update(dt, this.posX, this.posY, this.posZ, (proj) => {
      const mobRes = this.entityManager.damageEntitiesInRadius(
        proj.x,
        proj.z,
        proj.radius + 0.55,
        proj.power,
        proj.elementId,
        this.combatVfx,
        this.handleEntityKill,
        (arch, action, spatial, variant) =>
          this.soundEngine.playCreatureSound(arch, action, spatial, variant),
      );
      if (mobRes.hits > 0) {
        this.soundEngine.playHit(mobRes.weaknessTriggered);
        return true;
      }

      const pGround = this.dungeon ? 0 : getWorldHeight(proj.x, proj.z, this.saveData.seed);
      if (proj.y <= pGround) {
        if (!this.dungeon) {
          this.chunkManager.damageNodesInRadius(proj.x, proj.z, 2.0, proj.power, _rewards);
          if (_rewards.length > 0) this.processHarvestRewards(_rewards);
        } else {
          this.dungeon.damageInteriorNodesInRadius(proj.x, proj.z, 2.0, proj.power, _rewards);
          if (_rewards.length > 0) this.processHarvestRewards(_rewards);
        }
        return true;
      }
      if (!this.dungeon) {
        const hitCount = this.chunkManager.damageNodesInRadius(
          proj.x,
          proj.z,
          proj.radius + 0.5,
          proj.power,
          _rewards,
        );
        if (_rewards.length > 0) this.processHarvestRewards(_rewards);
        return hitCount > 0;
      }
      return false;
    });

    // 8.5 Entities, NPCs, Bosses & Dungeon logic
    const currentBiomeId = getBiomeIdAt(this.posX, this.posZ, this.saveData.seed);
    const biome = BIOMES[currentBiomeId];
    const isNight = this.timeOfDay >= 0.84 || this.timeOfDay < 0.18;
    const locAtmo = !this.dungeon
      ? this.chunkManager.getNearbyLocationAtmosphere(this.posX, this.posZ)
      : { kind: null, dist: 999 };

    // Footstep sound cadence
    if ((this.isGrounded || this.isSwimming) && horizSpeed > 1.2) {
      this.footstepTimer -= dt * (horizSpeed / 6.0);
      if (this.footstepTimer <= 0) {
        this.footstepTimer = 0.42;
        const surface = this.isSwimming
          ? 'water'
          : this.dungeon
            ? 'stone'
            : currentBiomeId === 'snow_peaks' || this.posY > 17.5
              ? 'snow'
              : currentBiomeId === 'desert_dunes' || currentBiomeId === 'sunlit_coast'
                ? 'sand'
                : 'grass';
        this.soundEngine.playFootstep(surface);
      }
    }

    this.entityManager.update({
      dt,
      playerX: this.posX,
      playerY: this.posY,
      playerZ: this.posZ,
      playerYaw: this.yaw,
      viewDistanceMeters: this.settings.viewDistanceMeters,
      inDungeon: Boolean(this.dungeon),
      dungeon: this.dungeon,
      seed: this.saveData.seed,
      isNight,
      nearbyLocationKind: locAtmo.kind,
      combatVfx: this.combatVfx,
      bestiary: this.saveData.player.bestiary,
      onPlayerDamaged: this.handlePlayerDamaged,
      onEntityDiscovered: (def) => {
        this.callbacks.onNotice(`تم توثيق ${def.nameAr} في الموسوعة.`);
      },
      onEntityEvolved: (oldDef, newDef) => {
        this.soundEngine.playCreatureSound(newDef.archetype, 'aggro', undefined, newDef.skeletonVariant);
        this.callbacks.onNotice(`تطور وحش! ${oldDef.nameAr} تحوّل إلى ${newDef.nameAr}!`);
      },
      onSummonExpired: (_uid, def, wasRebel) => {
        this.syncSummonSaveFields();
        this.callbacks.onNotice(
          wasRebel ? `تلاشت روح ${def.nameAr} المتمردة.` : `انتهت مدة استحضار ${def.nameAr}.`,
        );
      },
      onSupportPulse: (def) => {
        const curStats = computePlayerStats(this.saveData.player.level, this.saveData.player.equipment);
        this.hp = Math.min(curStats.maxHp, this.hp + Math.max(6, Math.round(def.level * 1.4)));
        this.mana = Math.min(curStats.maxMana, this.mana + Math.max(5, Math.round(def.level * 1.2)));
      },
      onGuardKill: this.handleEntityKill,
      onCreatureSound: (arch, action, spatial, variant) =>
        this.soundEngine.playCreatureSound(arch, action, spatial, variant),
    });

    if (this.dungeon) {
      this.dungeon.update(dt);
    }

    // Event chest timer & overworld auto-discovery of nearby portals (within 36m)
    if (!this.dungeon && this.eventChest?.active) {
      this.eventChest.timer -= dt;
      this.eventChest.group.rotation.y += dt * 0.4;
      if (this.eventChest.timer <= 0) {
        this.eventChest.active = false;
        this.eventChest.group.visible = false;
      }
    } else if (this.dungeon && this.eventChest?.active) {
      this.eventChest.group.visible = false;
    }

    if (!this.dungeon) {
      const discoverPortal = this.chunkManager.getNearbyPortal(this.posX, this.posZ, 36);
      if (discoverPortal) {
        if (!this.saveData.discoveredLocations) this.saveData.discoveredLocations = [];
        if (!this.saveData.discoveredLocations.some((l) => l.id === discoverPortal.id)) {
          this.saveData.discoveredLocations.push({
            id: discoverPortal.id,
            nameAr: discoverPortal.nameAr,
            kind: discoverPortal.kind,
            subtype: discoverPortal.subtype,
            x: Math.round(discoverPortal.x),
            z: Math.round(discoverPortal.z),
            level: discoverPortal.level,
          });
          this.callbacks.onNotice(`اكتشفت معلماً: ${discoverPortal.nameAr}`);
        }
      }
    }

    // Proximity interaction detection
    this.currentPortal = null;
    this.currentNpc = null;
    if (this.dungeon) {
      const guardNpc = this.entityManager.getNearbyNpc(this.posX, this.posZ, true, 3.4);
      const chest = this.dungeon.getNearbyChest(this.posX, this.posZ, 2.8);
      if (chest) {
        this.currentNearby = {
          kind: 'dungeon_chest',
          id: chest.id,
          labelAr: chest.isSecret ? 'فتح الكنز السري' : 'فتح الكنز',
          subLabelAr: chest.isSecret ? 'غرفة الكنز المخفية' : 'صندوق كنز قديم',
        };
      } else if (guardNpc) {
        this.currentNpc = guardNpc;
        this.currentNearby = {
          kind: 'npc',
          id: guardNpc.id,
          labelAr: `تحدث مع ${guardNpc.nameAr}`,
          subLabelAr: guardNpc.titleAr,
        };
      } else if (this.dungeon.isNearExit(this.posX, this.posZ, 2.8)) {
        this.currentNearby = {
          kind: 'dungeon_exit',
          id: 'exit',
          labelAr: 'الخروج للعالم',
          subLabelAr: this.dungeon.portal.nameAr,
        };
      } else {
        this.currentNearby = null;
      }
    } else {
      const eventChestDist =
        this.eventChest?.active
          ? Math.hypot(this.posX - this.eventChest.x, this.posZ - this.eventChest.z)
          : 999;
      const npc = this.entityManager.getNearbyNpc(this.posX, this.posZ, false, 3.4);
      if (eventChestDist < 3.0) {
        this.currentNearby = {
          kind: 'dungeon_chest',
          id: 'world_event_chest',
          labelAr: 'فتح الصندوق المخفي',
          subLabelAr: 'كنز حدث عشوائي',
        };
      } else if (npc) {
        this.currentNpc = npc;
        this.currentNearby = {
          kind: 'npc',
          id: npc.id,
          labelAr: `تحدث مع ${npc.nameAr}`,
          subLabelAr: npc.titleAr,
        };
      } else {
        const portal = this.chunkManager.getNearbyPortal(this.posX, this.posZ, 4.2);
        if (portal) {
          this.currentPortal = portal;
          this.currentNearby = {
            kind: 'portal',
            id: portal.id,
            labelAr: `دخول ${portal.nameAr}`,
            subLabelAr: `مستوى ${portal.level}`,
          };
        } else {
          this.currentNearby = null;
        }
      }
    }

    // 9. Easy Survival, Campfire Hearth Warmth & Passive Regeneration
    const surv = this.saveData.player.survival;
    const campPos = this.chunkManager.getCampfirePosition();
    const nearCampfireDist = this.dungeon
      ? 999
      : Math.hypot(this.posX - campPos.x, this.posZ - campPos.z);
    const nearCampfire = nearCampfireDist < 4.5;

    surv.hunger = Math.max(0, surv.hunger - dt * 0.11);
    surv.thirst = Math.max(0, surv.thirst - dt * 0.14);
    surv.rest = nearCampfire
      ? Math.min(100, surv.rest + dt * 4.5)
      : Math.max(0, surv.rest - dt * 0.07);
    const targetTemp = nearCampfire
      ? 24
      : this.dungeon
        ? 14
        : this.isSwimming
          ? Math.min(biome.ambientTempC, 16)
          : biome.ambientTempC;
    surv.temperature = THREE.MathUtils.damp(surv.temperature, targetTemp, nearCampfire ? 1.1 : 0.25, dt);

    const comfortBonus = nearCampfire
      ? 2.2
      : surv.hunger > 35 && surv.thirst > 35 && surv.rest > 25
        ? 1.0
        : 0.35;
    this.hp = Math.min(stats.maxHp, this.hp + dt * 1.4 * comfortBonus);
    this.mana = Math.min(stats.maxMana, this.mana + dt * 3.2 * comfortBonus);

    // 10. Dynamic Time-of-Day, Weather, Random World Events, Fog & Chunks
    this.timeOfDay = (this.timeOfDay + dt / 480) % 1; // ~8 minute full day-night cycle
    const timeLabelAr =
      this.timeOfDay < 0.22
        ? 'الفجر'
        : this.timeOfDay < 0.48
          ? 'الصباح'
          : this.timeOfDay < 0.68
            ? 'الظهيرة'
            : this.timeOfDay < 0.82
              ? 'الغروب'
              : 'الليل';

    if (this.activeEventBannerTimer > 0) {
      this.activeEventBannerTimer = Math.max(0, this.activeEventBannerTimer - dt);
      if (this.activeEventBannerTimer <= 0) {
        this.activeEventLabelAr = null;
      }
    }

    if (!this.dungeon) {
      this.weatherTimer -= dt;
      if (this.weatherTimer <= 0) {
        this.weatherTimer = 85 + Math.random() * 55;
        const r = Math.random();
        if (currentBiomeId === 'snow_peaks') {
          this.weather = r < 0.35 ? 'clear' : r < 0.6 ? 'mist' : 'snow';
        } else if (currentBiomeId === 'desert_dunes' || currentBiomeId === 'volcanic_ridge') {
          this.weather = r < 0.72 ? 'clear' : 'mist';
        } else if (currentBiomeId === 'misty_marsh' || currentBiomeId === 'mystic_woods') {
          this.weather = r < 0.28 ? 'clear' : r < 0.62 ? 'mist' : r < 0.86 ? 'rain' : 'storm';
        } else {
          this.weather = r < 0.5 ? 'clear' : r < 0.72 ? 'mist' : r < 0.9 ? 'rain' : 'storm';
        }
      }

      // Non-spammy Random Dynamic World Events outside village
      const distFromVillage = Math.hypot(this.posX - VILLAGE_CENTER.x, this.posZ - VILLAGE_CENTER.z);
      if (distFromVillage > 28) {
        this.worldEventTimer -= dt;
        if (this.worldEventTimer <= 0) {
          this.worldEventTimer = 95 + Math.random() * 40;
          const evRoll = Math.random();
          if (evRoll < 0.32) {
            this.entityManager.spawnWorldEventWave('skeleton_raid', this.posX, this.posZ, this.saveData.seed);
            this.activeEventLabelAr = 'حدث عالمي: غارة هياكل عظمية قريبة!';
            this.activeEventBannerTimer = 14;
            this.callbacks.onNotice(this.activeEventLabelAr);
          } else if (evRoll < 0.58) {
            this.entityManager.spawnWorldEventWave('wolf_pack', this.posX, this.posZ, this.saveData.seed);
            this.activeEventLabelAr = 'حدث عالمي: قطيع ذئاب يتربص بك!';
            this.activeEventBannerTimer = 14;
            this.callbacks.onNotice(this.activeEventLabelAr);
          } else if (evRoll < 0.8) {
            this.entityManager.spawnWorldEventWave('rare_elite', this.posX, this.posZ, this.saveData.seed);
            this.activeEventLabelAr = 'حدث عالمي: ظهر وحش نادر في الجوار!';
            this.activeEventBannerTimer = 14;
            this.callbacks.onNotice(this.activeEventLabelAr);
          } else if (this.eventChest && !this.eventChest.active) {
            const ang = this.yaw + (Math.random() - 0.5) * 1.4;
            const cx = this.posX - Math.sin(ang) * 18;
            const cz = this.posZ - Math.cos(ang) * 18;
            const cy = getWorldHeight(cx, cz, this.saveData.seed);
            if (cy > WATER_LEVEL + 0.4) {
              this.eventChest.active = true;
              this.eventChest.x = cx;
              this.eventChest.y = cy;
              this.eventChest.z = cz;
              this.eventChest.timer = 90;
              this.eventChest.group.position.set(cx, cy, cz);
              this.eventChest.group.visible = true;
              this.activeEventLabelAr = 'حدث عالمي: لمعان صندوق كنز مخفي قريب!';
              this.activeEventBannerTimer = 14;
              this.callbacks.onNotice(this.activeEventLabelAr);
            }
          }
        }
      }
    }

    const desiredFar = this.dungeon ? 78 : this.settings.viewDistanceMeters + 16;
    if (Math.abs(this.camera.far - desiredFar) > 0.5) {
      this.camera.far = desiredFar;
      this.camera.updateProjectionMatrix();
    }

    this.sunLight.position.set(this.posX + 26, this.posY + 42, this.posZ + 20);
    this.sunLight.target.position.set(this.posX, this.posY, this.posZ);
    this.sunLight.target.updateMatrixWorld();

    if (!this.dungeon) {
      if (!this.discoveredBiomes.has(currentBiomeId)) {
        this.discoveredBiomes.add(currentBiomeId);
        this.callbacks.onNotice(`اكتشفت منطقة جديدة: ${biome.nameAr}`);
      }

      if (this.lightningFlash > 0) {
        this.lightningFlash = Math.max(0, this.lightningFlash - dt * 3.8);
      }
      if (this.weather === 'storm') {
        this.lightningTimer -= dt;
        if (this.lightningTimer <= 0) {
          this.lightningTimer = 7 + Math.random() * 8;
          this.lightningFlash = 1.0;
          this.soundEngine.playThunder();
        }
      }

      const daySun = Math.sin(Math.max(0, Math.min(1, (this.timeOfDay - 0.15) / 0.7)) * Math.PI);
      const stormDim = this.weather === 'storm' ? 0.65 : 1.0;
      this.sunLight.intensity = (0.45 + daySun * 1.25) * stormDim + this.lightningFlash * 1.8;
      this.hemiLight.intensity = (0.42 + daySun * 0.38) * stormDim + this.lightningFlash * 0.9;

      _skyTarget.setHex(biome.skyHex);
      _fogTarget.setHex(biome.fogHex);

      // Blend sunset & night tones smoothly
      if (this.timeOfDay > 0.68 && this.timeOfDay < 0.84) {
        const st = 1 - Math.abs(this.timeOfDay - 0.76) / 0.08;
        _skyTarget.lerp(_sunsetColor, st * 0.45);
        _fogTarget.lerp(_sunsetColor, st * 0.35);
      } else if (isNight) {
        _skyTarget.lerp(_nightColor, 0.72);
        _fogTarget.lerp(_nightColor, 0.65);
      }

      // Blend mysterious Castle / Ruin fog when nearby
      let locFogBoost = 1.0;
      if (locAtmo.kind === 'castle') {
        const t = THREE.MathUtils.clamp(1 - locAtmo.dist / 36, 0, 1);
        _fogTarget.lerp(_castleFogColor, t * 0.65);
        locFogBoost = 1 + t * 0.45;
      } else if (locAtmo.kind === 'ruin') {
        const t = THREE.MathUtils.clamp(1 - locAtmo.dist / 32, 0, 1);
        _fogTarget.lerp(_ruinFogColor, t * 0.6);
        locFogBoost = 1 + t * 0.35;
      }

      // Weather fog modulation + view-distance fog coupling
      const weatherFogMult =
        this.weather === 'mist'
          ? 1.55
          : this.weather === 'storm'
            ? 1.5
            : this.weather === 'rain' || this.weather === 'snow'
              ? 1.32
              : 1.0;
      if (this.weather === 'storm') {
        _skyTarget.lerp(_stormFogColor, 0.62);
        _fogTarget.lerp(_stormFogColor, 0.58);
      } else if (this.weather === 'rain') {
        _skyTarget.lerp(_rainFogColor, 0.42);
        _fogTarget.lerp(_rainFogColor, 0.38);
      } else if (this.weather === 'snow') {
        _skyTarget.lerp(_snowFogColor, 0.45);
        _fogTarget.lerp(_snowFogColor, 0.42);
      }
      if (this.lightningFlash > 0.05) {
        _skyTarget.lerp(_snowFogColor, this.lightningFlash * 0.65);
      }
      const viewDistScale = THREE.MathUtils.clamp(80 / Math.max(45, this.settings.viewDistanceMeters), 0.75, 1.85);
      const targetFogDensity = biome.fogDensity * locFogBoost * weatherFogMult * viewDistScale;

      (this.scene.background as THREE.Color).lerp(_skyTarget, dt * 1.8);
      this.fog.color.lerp(_fogTarget, dt * 1.8);
      this.fog.density = THREE.MathUtils.damp(this.fog.density, targetFogDensity, 2.0, dt);

      // Drift sky clouds gently around player
      if (this.settings.preset !== 'low') {
        for (let i = 0; i < this.clouds.length; i++) {
          const c = this.clouds[i];
          const ang = (i / this.clouds.length) * Math.PI * 2 + this.saveData.playTimeSeconds * 0.012;
          const rad = 28 + (i % 3) * 18;
          c.position.set(
            this.posX + Math.cos(ang) * rad,
            42 + (i % 3) * 4,
            this.posZ + Math.sin(ang) * rad,
          );
        }
      }

      // Update pooled weather droplets (Rain, Storm or Snow)
      const isSnowing =
        this.weather === 'snow' || (currentBiomeId === 'snow_peaks' && this.weather !== 'clear');
      const isStorm = this.weather === 'storm';
      const showWeather =
        this.settings.effectsQuality !== 'low' &&
        (this.weather === 'rain' || isStorm || isSnowing);
      if (showWeather) {
        this.weatherDropMat.color.setHex(isSnowing ? 0xf8fafc : isStorm ? 0x93c5fd : 0xcbeafe);
        for (let i = 0; i < this.weatherDrops.length; i++) {
          const d = this.weatherDrops[i];
          d.mesh.visible = true;
          d.y -= (isSnowing ? 4.2 : isStorm ? d.speed * 1.45 : d.speed) * dt;
          if (isStorm) d.x -= 4.2 * dt;
          if (d.y < 0) {
            d.y = 12 + Math.random() * 5;
            d.x = (Math.random() - 0.5) * 26;
            d.z = (Math.random() - 0.5) * 26;
          }
          d.mesh.position.set(this.posX + d.x, this.posY + d.y, this.posZ + d.z);
        }
      } else {
        for (let i = 0; i < this.weatherDrops.length; i++) {
          this.weatherDrops[i].mesh.visible = false;
        }
      }

      this.templates.animateEnvironment(dt);
      this.chunkManager.update(
        this.posX,
        this.posZ,
        fwdX,
        fwdZ,
        this.settings.viewDistanceMeters,
        this.camera,
      );
    } else {
      for (let i = 0; i < this.weatherDrops.length; i++) {
        this.weatherDrops[i].mesh.visible = false;
      }
      this.sunLight.intensity = 0.65;
      this.hemiLight.intensity = 0.55;
      _skyTarget.setHex(this.dungeon.bgHex);
      _fogTarget.setHex(this.dungeon.fogHex);
      (this.scene.background as THREE.Color).lerp(_skyTarget, dt * 3.0);
      this.fog.color.lerp(_fogTarget, dt * 3.0);
      this.fog.density = THREE.MathUtils.damp(this.fog.density, 0.024, 3.0, dt);
    }

    // Update ambient nature motes (fireflies / embers / pollen)
    this.combatVfx.updateAmbientMotes(
      dt,
      this.posX,
      this.posY,
      this.posZ,
      currentBiomeId,
      isNight,
      Boolean(this.dungeon),
      this.settings.effectsQuality !== 'low',
    );

    // Update Adaptive Ambient & Music
    const activeBoss = this.entityManager.getActiveBossHud(
      this.posX,
      this.posZ,
      Boolean(this.dungeon),
    );
    const nearWaterfallDist = this.dungeon
      ? 999
      : this.chunkManager.getNearestWaterfallDist(this.posX, this.posZ);
    this.soundEngine.updateAmbientAndMusic(dt, {
      biomeId: currentBiomeId,
      inDungeon: Boolean(this.dungeon),
      weather: this.weather,
      inCombat: this.entityManager.inCombat,
      isBossFight: Boolean(activeBoss),
      isNight,
      nearCampfireDist,
      nearWaterfallDist,
    });

    // 11. Throttled UI Metrics Sync (~8 Hz)
    this.fpsFrames += 1;
    this.fpsAccumTime += rawDt;
    if (this.fpsAccumTime >= 0.5) {
      this.currentFps = Math.round(this.fpsFrames / this.fpsAccumTime);
      this.fpsFrames = 0;
      this.fpsAccumTime = 0;
    }

    if (now - this.lastUiSyncTime >= 120) {
      this.lastUiSyncTime = now;
      const activeSummons = this.entityManager.getActiveSummonsHud();
      const activeSummonName = activeSummons[0]?.nameAr ?? null;
      const soulPowerUsed = this.entityManager.getUsedSoulPower(false);
      const soulControlMax = this.getSoulControlMax();
      const targetEnemy = activeBoss
        ? null
        : this.entityManager.getTargetEnemyHud(this.posX, this.posZ);
      const metrics: PerfMetrics = {
        fps: this.currentFps,
        frameTimeMs: Math.round(rawDt * 1000),
        drawCalls: this.renderer.info.render.calls,
        triangles: this.renderer.info.render.triangles,
        geometries: this.renderer.info.memory.geometries,
        textures: this.renderer.info.memory.textures,
        activeChunks: this.chunkManager.activeChunkCount,
        queuedChunks: this.chunkManager.queuedChunkCount,
        biomeId: currentBiomeId,
        biomeNameAr: this.dungeon ? this.dungeon.portal.nameAr : biome.nameAr,
        inDungeon: Boolean(this.dungeon),
        dungeonNameAr: this.dungeon?.portal.nameAr,
        weather: this.weather,
        timeOfDay: this.timeOfDay,
        timeOfDayLabelAr: timeLabelAr,
        x: Math.round(this.posX),
        y: Math.round(this.posY),
        z: Math.round(this.posZ),
        yaw: this.yaw,
        isSwimming: this.isSwimming,
        isGrounded: this.isGrounded,
        isBlocking: this.isBlocking,
        nearbyInteractable: this.currentNearby,
        activeBoss,
        targetEnemy,
        activeSummonName,
        activeSummons,
        soulPowerUsed,
        soulControlMax,
        activeEventLabelAr: this.activeEventLabelAr,
      };
      this.callbacks.onMetrics(metrics, this.getSaveSnapshot(), { ...this.abilityCooldowns });
    }
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.detachInputs?.();
    this.detachAudioUnlock?.();
    this.cleanupResize?.();
    this.soundEngine.dispose();
    if (this.dungeon) {
      this.dungeon.dispose();
      this.dungeon = null;
    }
    if (this.eventChest) {
      this.scene.remove(this.eventChest.group);
      this.eventChest.geometries.forEach((g) => g.dispose());
      this.eventChest.materials.forEach((m) => m.dispose());
    }
    for (const c of this.clouds) this.scene.remove(c);
    for (const d of this.weatherDrops) this.scene.remove(d.mesh);
    this.weatherDropGeo.dispose();
    this.weatherDropMat.dispose();
    this.entityManager.dispose();
    this.combatVfx.dispose();
    this.chunkManager.disposeAll();
    this.playerModel.dispose();
    this.templates.dispose();
    this.scene.environment?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
