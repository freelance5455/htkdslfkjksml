import * as THREE from 'three';

const MAX_PARTICLES = 320;
const TRACERS = 24;
const FLASHES = 6;

let glowTex: THREE.CanvasTexture | null = null;
function getGlow(): THREE.CanvasTexture {
  if (glowTex) return glowTex;
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 64;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.25, 'rgba(255,220,150,0.8)');
  grd.addColorStop(1, 'rgba(255,160,60,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  glowTex = new THREE.CanvasTexture(c);
  return glowTex;
}

interface Tracer {
  line: THREE.Line;
  mat: THREE.LineBasicMaterial;
  life: number;
}

interface Flash {
  sprite: THREE.Sprite;
  mat: THREE.SpriteMaterial;
  life: number;
}

/** Pooled 3D effects: bullet tracers, muzzle flashes and debris/blood particles. */
export class Fx {
  private tracers: Tracer[] = [];
  private flashes: Flash[] = [];
  private tracerCursor = 0;
  private flashCursor = 0;
  private points: THREE.Points;
  private pos = new Float32Array(MAX_PARTICLES * 3);
  private col = new Float32Array(MAX_PARTICLES * 3);
  private base = new Float32Array(MAX_PARTICLES * 3);
  private vel = new Float32Array(MAX_PARTICLES * 3);
  private life = new Float32Array(MAX_PARTICLES);
  private maxLife = new Float32Array(MAX_PARTICLES);
  private cursor = 0;

  constructor(private scene: THREE.Scene) {
    for (let i = 0; i < TRACERS; i++) {
      const mat = new THREE.LineBasicMaterial({ color: 0xffe2a0, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
      const line = new THREE.Line(geo, mat);
      line.frustumCulled = false;
      scene.add(line);
      this.tracers.push({ line, mat, life: 0 });
    }
    for (let i = 0; i < FLASHES; i++) {
      const mat = new THREE.SpriteMaterial({ map: getGlow(), color: 0xffc070, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
      const sprite = new THREE.Sprite(mat);
      sprite.scale.setScalar(0.8);
      scene.add(sprite);
      this.flashes.push({ sprite, mat, life: 0 });
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    for (let i = 0; i < MAX_PARTICLES; i++) this.pos[i * 3 + 1] = -1000;
    this.points = new THREE.Points(
      geo,
      new THREE.PointsMaterial({ size: 0.13, vertexColors: true, transparent: true, depthWrite: false, sizeAttenuation: true }),
    );
    this.points.frustumCulled = false;
    scene.add(this.points);
  }

  tracer(a: THREE.Vector3, b: THREE.Vector3) {
    const t = this.tracers[this.tracerCursor];
    this.tracerCursor = (this.tracerCursor + 1) % TRACERS;
    const p = (t.line.geometry.attributes.position as THREE.BufferAttribute).array as Float32Array;
    p[0] = a.x; p[1] = a.y; p[2] = a.z;
    p[3] = b.x; p[4] = b.y; p[5] = b.z;
    (t.line.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    t.mat.opacity = 0.9;
    t.life = 0.1;
  }

  muzzle(p: THREE.Vector3) {
    const f = this.flashes[this.flashCursor];
    this.flashCursor = (this.flashCursor + 1) % FLASHES;
    f.sprite.position.copy(p);
    f.sprite.material.rotation = Math.random() * Math.PI;
    f.mat.opacity = 1;
    f.sprite.scale.setScalar(0.55 + Math.random() * 0.3);
    f.life = 0.06;
  }

  blood(p: THREE.Vector3) {
    this.emit(p, 0.55, 0.05, 0.12, 3.2, 0.5, 0.12, 0.02);
  }

  dust(p: THREE.Vector3) {
    this.emit(p, 0.72, 0.62, 0.42, 1.8, 0.45, 0.08, 0.5);
  }

  sparks(p: THREE.Vector3) {
    this.emit(p, 1.0, 0.78, 0.35, 4, 0.2, 0.06, 0);
  }

  private emit(p: THREE.Vector3, r: number, g: number, b: number, speed: number, life: number, _size: number, up: number) {
    for (let i = 0; i < 6; i++) {
      const k = this.cursor;
      this.cursor = (this.cursor + 1) % MAX_PARTICLES;
      this.pos[k * 3] = p.x;
      this.pos[k * 3 + 1] = p.y;
      this.pos[k * 3 + 2] = p.z;
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.4 + Math.random() * 0.6);
      this.vel[k * 3] = Math.cos(a) * s;
      this.vel[k * 3 + 1] = up * s + Math.random() * 1.5;
      this.vel[k * 3 + 2] = Math.sin(a) * s;
      this.base[k * 3] = r;
      this.base[k * 3 + 1] = g;
      this.base[k * 3 + 2] = b;
      this.life[k] = life * (0.6 + Math.random() * 0.6);
      this.maxLife[k] = this.life[k];
    }
  }

  update(dt: number) {
    for (const t of this.tracers) {
      if (t.life > 0) {
        t.life -= dt;
        t.mat.opacity = Math.max(0, t.life / 0.1) * 0.9;
      }
    }
    for (const f of this.flashes) {
      if (f.life > 0) {
        f.life -= dt;
        f.mat.opacity = Math.max(0, f.life / 0.06);
      }
    }
    for (let i = 0; i < MAX_PARTICLES; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      const k = this.life[i] / this.maxLife[i];
      this.vel[i * 3 + 1] -= 9 * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      if (this.pos[i * 3 + 1] < 0) {
        this.pos[i * 3 + 1] = 0;
        this.vel[i * 3 + 1] = 0;
        this.vel[i * 3] *= 0.6;
        this.vel[i * 3 + 2] *= 0.6;
      }
      const kk = Math.max(0, k);
      this.col[i * 3] = this.base[i * 3] * kk;
      this.col[i * 3 + 1] = this.base[i * 3 + 1] * kk;
      this.col[i * 3 + 2] = this.base[i * 3 + 2] * kk;
      if (this.life[i] <= 0) {
        this.pos[i * 3 + 1] = -1000;
        this.col[i * 3] = this.col[i * 3 + 1] = this.col[i * 3 + 2] = 0;
      }
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose() {
    for (const t of this.tracers) {
      this.scene.remove(t.line);
      t.line.geometry.dispose();
      t.mat.dispose();
    }
    for (const f of this.flashes) {
      this.scene.remove(f.sprite);
      f.mat.dispose();
    }
    this.scene.remove(this.points);
    this.points.geometry.dispose();
    (this.points.material as THREE.Material).dispose();
  }
}
