import * as THREE from 'three';

export class Particles {
  points: THREE.Points;
  max: number;
  pos: Float32Array;
  col: Float32Array;
  vel: Float32Array;
  life: Float32Array;
  maxLife: Float32Array;
  grav: Float32Array;
  base: Float32Array;
  idx = 0;
  drag: number;

  constructor(scene: THREE.Scene, max: number, size: number, additive: boolean, map: THREE.Texture | null, drag = 0.5) {
    this.max = max;
    this.drag = drag;
    this.pos = new Float32Array(max * 3).fill(-999);
    this.col = new Float32Array(max * 3);
    this.base = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max).fill(1);
    this.grav = new Float32Array(max);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    const m = new THREE.PointsMaterial({
      size, vertexColors: true, transparent: true, depthWrite: false, map: map ?? undefined,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, sizeAttenuation: true, opacity: 1,
    });
    this.points = new THREE.Points(g, m);
    this.points.frustumCulled = false;
    this.points.renderOrder = 8;
    scene.add(this.points);
  }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, r: number, g: number, b: number, grav = 9) {
    const i = this.idx;
    this.idx = (this.idx + 1) % this.max;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.base[i * 3] = r; this.base[i * 3 + 1] = g; this.base[i * 3 + 2] = b;
    this.life[i] = life; this.maxLife[i] = life; this.grav[i] = grav;
  }

  update(dt: number) {
    const df = Math.exp(-this.drag * dt);
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      const k = i * 3;
      if (this.life[i] <= 0) {
        this.pos[k + 1] = -999;
        this.col[k] = this.col[k + 1] = this.col[k + 2] = 0;
        continue;
      }
      this.vel[k + 1] -= this.grav[i] * dt;
      this.vel[k] *= df; this.vel[k + 2] *= df;
      this.pos[k] += this.vel[k] * dt;
      this.pos[k + 1] += this.vel[k + 1] * dt;
      this.pos[k + 2] += this.vel[k + 2] * dt;
      if (this.pos[k + 1] < 0.02) { this.pos[k + 1] = 0.02; this.vel[k + 1] *= -0.35; }
      const f = this.life[i] / this.maxLife[i];
      this.col[k] = this.base[k] * f; this.col[k + 1] = this.base[k + 1] * f; this.col[k + 2] = this.base[k + 2] * f;
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
}

export class Flashes {
  sprites: { s: THREE.Sprite; t: number; dur: number; size: number }[] = [];
  constructor(scene: THREE.Scene, glow: THREE.Texture) {
    for (let i = 0; i < 8; i++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false }));
      s.renderOrder = 12;
      s.visible = false;
      scene.add(s);
      this.sprites.push({ s, t: 0, dur: 0.2, size: 1 });
    }
  }
  spawn(pos: THREE.Vector3, color: number, size: number) {
    const f = this.sprites.find((x) => x.t <= 0) ?? this.sprites[0];
    f.t = f.dur = 0.22;
    f.size = size;
    f.s.position.copy(pos);
    (f.s.material as THREE.SpriteMaterial).color.setHex(color);
    f.s.visible = true;
  }
  update(dt: number) {
    for (const f of this.sprites) {
      if (f.t <= 0) continue;
      f.t -= dt;
      if (f.t <= 0) { f.s.visible = false; continue; }
      const p = 1 - f.t / f.dur;
      const sz = f.size * (0.4 + p * 1.2);
      f.s.scale.set(sz, sz, 1);
      (f.s.material as THREE.SpriteMaterial).opacity = (1 - p) * 0.95;
    }
  }
}
