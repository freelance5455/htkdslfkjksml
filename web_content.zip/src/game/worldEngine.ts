import * as THREE from 'three';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {ProceduralAudioEngine} from './audioEngine';
import {
  buildAtlasWorld,
  createCharacterMesh,
  createVehicleMesh,
  type BuildingCollider,
  type CharacterRig,
  type VehicleRig,
  type VehicleVariant,
  type WorldBuildResult,
} from './models';
import {STORY_MISSIONS} from './storyMissions';
import {createTextureAtlas, type TextureAtlasBundle} from './textureAtlas';
import {
  getDistrictAt,
  PROTAGONISTS,
  type HudSnapshot,
  type MissionDef,
  type PortableSaveData,
  type ProtagonistId,
  type QualityTier,
  type RadarBlip,
  type TouchInputState,
} from './types';

interface ActiveVehicle {
  id: string;
  label: string;
  variant: VehicleVariant;
  rig: VehicleRig;
  x: number;
  y: number;
  z: number;
  vy: number;
  heading: number;
  speed: number;
  steerAngle: number;
  isTraffic: boolean;
  isPolice: boolean;
  trafficAxis?: 'x' | 'z';
  trafficDir?: number;
  occupiedByPlayer: boolean;
}

interface HostileNPC {
  id: string;
  rig: CharacterRig;
  x: number;
  z: number;
  heading: number;
  hp: number;
  shootCooldown: number;
  isPolice: boolean;
}

interface LootPickup {
  mesh: THREE.Mesh;
  x: number;
  z: number;
  collected: boolean;
}

interface BulletTracer {
  mesh: THREE.Mesh;
  vx: number;
  vz: number;
  life: number;
  fromPlayer: boolean;
}

// Reusable module-scope math objects (zero GC in animation loop)
const _vecA = new THREE.Vector3();
const _vecB = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function detectDefaultQualityTier(): QualityTier {
  const isTouch =
    typeof window !== 'undefined' &&
    ('ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth < 820);
  if (!isTouch) return 'pc-high';
  const cores = navigator.hardwareConcurrency || 4;
  return cores <= 4 ? 'mobile-eco' : 'mobile-balanced';
}

export class LosSolisEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private qualityTier: QualityTier;
  private atlas: TextureAtlasBundle;
  private world: WorldBuildResult;
  private audio = new ProceduralAudioEngine();
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private envMap: THREE.Texture;

  private onHudUpdate: (snap: HudSnapshot) => void;
  private frameId = 0;
  private disposed = false;
  private lastTime = performance.now();
  private lastRenderTime = performance.now();
  private mobile30FpsCap = true;
  private lowFpsDuration = 0;
  private hudAccum = 0;
  private fpsSamples: number[] = [];
  private currentFps = 60;

  // Player & protagonists (start with ONLY Franklin unlocked in Los Santos)
  private activeProtagonist: ProtagonistId = 'franklin';
  private unlocked: Set<ProtagonistId> = new Set(['franklin']);
  private newlyUnlockedCharacter: ProtagonistId | null = null;
  private cash: Record<ProtagonistId, number> = {
    michael: 250000,
    franklin: 1200,
    trevor: 42000,
  };
  private protagonistStates: Record<
    ProtagonistId,
    {x: number; y: number; z: number; vy: number; heading: number; hp: number; armor: number; ammo: number}
  > = {
    michael: {x: -110, y: 0, z: -105, vy: 0, heading: 0, hp: 100, armor: 80, ammo: 90},
    franklin: {x: -35, y: 0, z: 95, vy: 0, heading: Math.PI, hp: 100, armor: 50, ammo: 60},
    trevor: {x: 130, y: 0, z: -135, vy: 0, heading: 0, hp: 100, armor: 100, ammo: 120},
  };
  private playerRig: CharacterRig;
  private specialCharge = 100;
  private specialActive = false;
  private specialTimer = 0;
  private walkAnimTime = 0;
  private shootCooldown = 0;
  private muzzleTimer = 0;
  private wasted = false;
  private wastedTimer = 0;

  // Camera
  private camYaw = 0;
  private camPitch = 0.28;
  private cameraMode: 'chase' | 'hood' | 'cinematic' = 'chase';
  private pointerDragging = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // Vehicles & Entities
  private vehicles: ActiveVehicle[] = [];
  private playerVehicle: ActiveVehicle | null = null;
  private hostiles: HostileNPC[] = [];
  private lootPickups: LootPickup[] = [];
  private tracers: BulletTracer[] = [];
  private waypointRing: THREE.Mesh;
  private waypointBeacon: THREE.Mesh;

  // Wanted & Mission State
  private wantedLevel = 0;
  private wantedCooldown = 0;
  private activeMission: MissionDef | null = null;
  private activeStageIdx = 0;
  private stageProgress = 0;
  private completedMissions: Set<string> = new Set();
  private dialogue: {speaker: string; text: string; color: string} | null = null;
  private dialogueTimer = 0;
  private banner: {title: string; subtitle: string; reward?: string} | null = null;
  private bannerTimer = 0;

  // Input state
  private keys: Record<string, boolean> = {};
  private touchInput: TouchInputState = {
    moveX: 0,
    moveY: 0,
    sprint: false,
    attack: false,
    gas: false,
    brake: false,
    handbrake: false,
    cameraDeltaX: 0,
    cameraDeltaY: 0,
  };

  constructor(
    container: HTMLElement,
    initialTier: QualityTier,
    onHudUpdate: (snap: HudSnapshot) => void,
  ) {
    this.container = container;
    this.qualityTier = initialTier;
    this.onHudUpdate = onHudUpdate;
    this.isSoftwareGl = detectSoftwareGl();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && initialTier === 'pc-high',
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.applyRendererTierSettings();
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const skyColor = new THREE.Color(0x9bc4e2);
    this.scene.background = skyColor;
    this.scene.fog = new THREE.FogExp2(0x9bc4e2, initialTier === 'pc-high' ? 0.0024 : 0.0036);

    const aspect = (container.clientWidth || window.innerWidth) / Math.max(1, container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(62, aspect, 0.25, initialTier === 'pc-high' ? 520 : 280);

    // Studio Reflection Environment (RoomEnvironment)
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.envMap = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = this.envMap;
    pmrem.dispose();

    // Warm sun + cool hemisphere fill
    this.hemiLight = new THREE.HemisphereLight(0xbbe1fa, 0x475569, 0.72);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff1d6, 1.65);
    this.sunLight.position.set(80, 120, 60);
    this.sunLight.castShadow = !this.isSoftwareGl && initialTier !== 'mobile-eco';
    this.sunLight.shadow.mapSize.set(initialTier === 'pc-high' ? 2048 : 1024, initialTier === 'pc-high' ? 2048 : 1024);
    this.sunLight.shadow.camera.near = 10;
    this.sunLight.shadow.camera.far = 260;
    const d = 80;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.02;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Build Texture Atlas & Open World
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.atlas = createTextureAtlas(initialTier, maxAniso);
    this.world = buildAtlasWorld(this.atlas, initialTier);
    this.scene.add(this.world.worldGroup);

    // Build Protagonist Rig
    this.playerRig = createCharacterMesh(this.activeProtagonist);
    this.scene.add(this.playerRig.group);

    // Mission Waypoint Beacon
    this.waypointRing = new THREE.Mesh(
      new THREE.RingGeometry(2.6, 3.3, 32),
      new THREE.MeshBasicMaterial({color: 0xfacc15, side: THREE.DoubleSide, transparent: true, opacity: 0.9}),
    );
    this.waypointRing.rotation.x = -Math.PI / 2;
    this.waypointRing.position.y = 0.14;
    this.waypointRing.visible = false;
    this.scene.add(this.waypointRing);

    this.waypointBeacon = new THREE.Mesh(
      new THREE.CylinderGeometry(0.45, 0.45, 36, 12, 1, true),
      new THREE.MeshBasicMaterial({color: 0xfacc15, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false}),
    );
    this.waypointBeacon.visible = false;
    this.scene.add(this.waypointBeacon);

    this.spawnInitialVehicles();
    this.bindEvents();

    // Start GTA V Prologue flashback (or Mission 1 if Prologue already completed)
    this.startMission(STORY_MISSIONS[0].id);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.lastTime = performance.now();
    this.tick();
  }

  private applyRendererTierSettings() {
    const dpr = window.devicePixelRatio || 1;
    const cap = this.isSoftwareGl
      ? 1
      : this.qualityTier === 'pc-high'
        ? Math.min(dpr, 2.0)
        : this.qualityTier === 'mobile-balanced'
          ? Math.min(dpr, 1.5)
          : 1.0;
    this.renderer.setPixelRatio(cap);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl && this.qualityTier !== 'mobile-eco';
    this.renderer.shadowMap.type = this.qualityTier === 'pc-high' ? THREE.PCFSoftShadowMap : THREE.BasicShadowMap;
  }

  public setQualityTier(tier: QualityTier) {
    if (tier === this.qualityTier) return;
    this.qualityTier = tier;
    this.applyRendererTierSettings();
    this.camera.far = tier === 'pc-high' ? 520 : 280;
    this.camera.updateProjectionMatrix();
    (this.scene.fog as THREE.FogExp2).density = tier === 'pc-high' ? 0.0024 : 0.0036;
    this.sunLight.castShadow = !this.isSoftwareGl && tier !== 'mobile-eco';

    // Rebuild Texture Atlas & World at the new atlas resolution!
    this.scene.remove(this.world.worldGroup);
    this.world.dispose();
    this.atlas.dispose();

    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.atlas = createTextureAtlas(tier, maxAniso);
    this.world = buildAtlasWorld(this.atlas, tier);
    this.scene.add(this.world.worldGroup);
    this.emitHud();
  }

  public getAtlasCanvas(): HTMLCanvasElement {
    return this.atlas.albedoCanvas;
  }

  public getAtlasTileList() {
    return this.atlas.tileList;
  }

  public getAudio(): ProceduralAudioEngine {
    return this.audio;
  }

  private spawnInitialVehicles() {
    // 3 Protagonist hero cars + Vespucci repo sports car
    const heroCars: {id: string; label: string; variant: VehicleVariant; color: number; x: number; z: number; h: number}[] = [
      {id: 'car_michael', label: PROTAGONISTS.michael.vehicleLabel, variant: 'sports', color: 0x141820, x: -110, z: -105, h: 0},
      {id: 'car_franklin', label: PROTAGONISTS.franklin.vehicleLabel, variant: 'muscle', color: 0xf8fafc, x: -42, z: 95, h: Math.PI / 2},
      {id: 'car_trevor', label: PROTAGONISTS.trevor.vehicleLabel, variant: 'pickup', color: 0x991b1b, x: 124, z: -130, h: 0},
      // Vespucci Beach repo coupe (Mission 1) & downtown getaway rides
      {id: 'car_vespucci_repo', label: '9F Cabrio', variant: 'sports', color: 0xef4444, x: -112, z: 58, h: 0},
      {id: 'car_downtown_1', label: 'Comet S2', variant: 'sports', color: 0xf59e0b, x: -64, z: 8, h: Math.PI / 2},
      {id: 'car_harbor_1', label: 'Vapid Dominator', variant: 'muscle', color: 0x2563eb, x: 86, z: 118, h: 0},
      {id: 'car_armored', label: 'Gruppe Sechs Rig', variant: 'armored', color: 0x334155, x: 5, z: 5, h: Math.PI / 2},
    ];

    for (const c of heroCars) {
      this.spawnVehicle(c.id, c.label, c.variant, c.color, c.x, c.z, c.h, false, false);
    }

    // Roaming traffic cars on avenues
    const trafficColors = [0xdc2626, 0x2563eb, 0xf59e0b, 0x94a3b8, 0x059669, 0xe2e8f0];
    const trafficCount = this.qualityTier === 'mobile-eco' ? 6 : 10;
    for (let i = 0; i < trafficCount; i++) {
      const axis: 'x' | 'z' = i % 2 === 0 ? 'z' : 'x';
      const dir = i % 4 < 2 ? 1 : -1;
      const laneCoord = this.world.roadCoords[i % this.world.roadCoords.length] + (dir > 0 ? 3.2 : -3.2);
      const along = -130 + ((i * 53) % 260);
      const x = axis === 'z' ? laneCoord : along;
      const z = axis === 'z' ? along : laneCoord;
      const heading = axis === 'z' ? (dir > 0 ? 0 : Math.PI) : dir > 0 ? Math.PI / 2 : -Math.PI / 2;
      const v = this.spawnVehicle(
        `traffic_${i}`,
        i % 3 === 0 ? 'Rancher XL' : 'Tailgater',
        i % 3 === 0 ? 'pickup' : 'muscle',
        trafficColors[i % trafficColors.length],
        x,
        z,
        heading,
        true,
        false,
      );
      v.trafficAxis = axis;
      v.trafficDir = dir;
      v.speed = 11 + (i % 4) * 2;
    }
  }

  private spawnVehicle(
    id: string,
    label: string,
    variant: VehicleVariant,
    color: number,
    x: number,
    z: number,
    heading: number,
    isTraffic: boolean,
    isPolice: boolean,
  ): ActiveVehicle {
    const rig = createVehicleMesh(variant, color, this.qualityTier);
    rig.group.position.set(x, 0, z);
    rig.group.rotation.y = heading;
    this.scene.add(rig.group);
    const v: ActiveVehicle = {
      id,
      label,
      variant,
      rig,
      x,
      y: 0,
      z,
      vy: 0,
      heading,
      speed: 0,
      steerAngle: 0,
      isTraffic,
      isPolice,
      occupiedByPlayer: false,
    };
    this.vehicles.push(v);
    return v;
  }

  public startMission(missionId: string) {
    const mission = STORY_MISSIONS.find((m) => m.id === missionId);
    if (!mission) return;

    // Enforce story progression lock if prerequisite mission is incomplete
    if (mission.requiredMissionId && !this.completedMissions.has(mission.requiredMissionId)) {
      const req = STORY_MISSIONS.find((m) => m.id === mission.requiredMissionId);
      this.showDialogue(
        'Story Locked',
        `Complete Mission ${req?.number ?? ''}: ${req?.title ?? ''} first to unlock this mission.`,
        '#f59e0b',
      );
      this.emitHud();
      return;
    }

    this.clearMissionEntities();
    this.activeMission = mission;
    this.activeStageIdx = 0;
    this.stageProgress = 0;
    this.wantedLevel = 0;
    this.newlyUnlockedCharacter = null;

    // Switch atmosphere for North Yankton snow flashback vs Sunny Los Santos
    const fogColor = mission.isSnowFlashback ? 0xdbeafe : 0x9bc4e2;
    (this.scene.background as THREE.Color).setHex(fogColor);
    (this.scene.fog as THREE.FogExp2).color.setHex(fogColor);
    (this.scene.fog as THREE.FogExp2).density = mission.isSnowFlashback ? 0.0065 : this.qualityTier === 'pc-high' ? 0.0024 : 0.0036;

    // Switch to mission protagonist cleanly (Prologue temporarily lets you play Michael flashback without permanently unlocking him)
    if (this.playerVehicle) {
      this.playerVehicle.occupiedByPlayer = false;
      this.playerVehicle = null;
    }
    this.activeProtagonist = mission.protagonist;
    const st = this.protagonistStates[this.activeProtagonist];
    st.x = mission.startPos[0];
    st.y = mission.startPos[1];
    st.z = mission.startPos[2];
    st.hp = 100;
    st.armor = 100;
    this.rebuildPlayerMesh();

    this.banner = {
      title: mission.number === 0 ? 'PROLOGUE' : `MISSION ${mission.number}: ${mission.title.toUpperCase()}`,
      subtitle: mission.act,
    };
    this.bannerTimer = 4.2;

    this.setupCurrentStage();
    this.emitHud();
  }

  private setupCurrentStage() {
    if (!this.activeMission) {
      this.waypointRing.visible = false;
      this.waypointBeacon.visible = false;
      return;
    }
    const stage = this.activeMission.stages[this.activeStageIdx];
    if (!stage) return;

    this.stageProgress = 0;
    if (stage.triggerWanted) {
      this.setWantedLevel(stage.triggerWanted);
    }
    if (stage.dialogueSpeaker && stage.dialogueLine) {
      this.showDialogue(stage.dialogueSpeaker, stage.dialogueLine, PROTAGONISTS[this.activeProtagonist].accentColor);
    }

    this.waypointRing.position.set(stage.targetPos[0], 0.14, stage.targetPos[2]);
    this.waypointBeacon.position.set(stage.targetPos[0], 18, stage.targetPos[2]);
    this.waypointRing.visible = true;
    this.waypointBeacon.visible = true;

    if (stage.type === 'collect_loot') {
      const count = stage.countTarget || 3;
      const geo = new THREE.BoxGeometry(1.1, 0.7, 0.8);
      const mat = new THREE.MeshStandardMaterial({
        color: 0xfacc15,
        emissive: 0xca8a04,
        emissiveIntensity: 0.8,
        metalness: 0.7,
        roughness: 0.25,
      });
      for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2;
        const dist = 4 + (i % 2) * 4;
        const lx = stage.targetPos[0] + Math.cos(angle) * dist;
        const lz = stage.targetPos[2] + Math.sin(angle) * dist;
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(lx, 0.7, lz);
        this.scene.add(mesh);
        this.lootPickups.push({mesh, x: lx, z: lz, collected: false});
      }
    } else if (stage.type === 'eliminate') {
      const count = stage.countTarget || 4;
      for (let i = 0; i < count; i++) {
        const angle = (i / count) * Math.PI * 2;
        const dist = 7 + (i % 2) * 4;
        const gx = stage.targetPos[0] + Math.cos(angle) * dist;
        const gz = stage.targetPos[2] + Math.sin(angle) * dist;
        this.spawnHostile(gx, gz, false);
      }
    }
  }

  private spawnHostile(x: number, z: number, isPolice: boolean) {
    const rig = createCharacterMesh(isPolice ? 'police' : 'guard');
    rig.group.position.set(x, 0, z);
    this.scene.add(rig.group);
    this.hostiles.push({
      id: `hostile_${Math.random().toString(36).slice(2, 8)}`,
      rig,
      x,
      z,
      heading: 0,
      hp: isPolice ? 60 : 50,
      shootCooldown: 0.8 + Math.random() * 0.9,
      isPolice,
    });
  }

  private clearMissionEntities() {
    for (const lp of this.lootPickups) {
      this.scene.remove(lp.mesh);
    }
    this.lootPickups = [];
    for (const h of this.hostiles) {
      if (!h.isPolice) {
        this.scene.remove(h.rig.group);
      }
    }
    this.hostiles = this.hostiles.filter((h) => h.isPolice);
  }

  private advanceStage() {
    if (!this.activeMission) return;
    this.clearMissionEntities();
    this.audio.playPickup();
    this.activeStageIdx++;

    if (this.activeStageIdx >= this.activeMission.stages.length) {
      // Mission Passed!
      const m = this.activeMission;
      this.completedMissions.add(m.id);
      this.cash[this.activeProtagonist] += m.rewardCash;
      this.wantedLevel = 0;
      this.audio.playMissionComplete();
      this.activeMission = null;
      this.waypointRing.visible = false;
      this.waypointBeacon.visible = false;

      if (m.unlocksCharacter) {
        this.unlocked.add(m.unlocksCharacter);
        this.newlyUnlockedCharacter = m.unlocksCharacter;
        const unlockedProf = PROTAGONISTS[m.unlocksCharacter];
        this.banner = {
          title: 'CHARACTER UNLOCKED',
          subtitle: `${unlockedProf.name} is now playable on the Character Wheel`,
          reward: m.rewardCash > 0 ? `+$${m.rewardCash.toLocaleString()}` : undefined,
        };
      } else {
        this.banner = {
          title: 'MISSION PASSED',
          subtitle: m.title,
          reward: m.rewardCash > 0 ? `+$${m.rewardCash.toLocaleString()}` : undefined,
        };
      }
      this.bannerTimer = 5.2;

      // Restore sunny Los Santos after Prologue and auto-transition into Franklin's story
      if (m.id === 'm0_prologue') {
        (this.scene.background as THREE.Color).setHex(0x9bc4e2);
        (this.scene.fog as THREE.FogExp2).color.setHex(0x9bc4e2);
        (this.scene.fog as THREE.FogExp2).density = this.qualityTier === 'pc-high' ? 0.0024 : 0.0036;
        this.saveToLocalStorage();
        this.startMission('m1_franklin_lamar');
        return;
      }

      this.saveToLocalStorage();
    } else {
      this.setupCurrentStage();
    }
    this.emitHud();
  }

  private showDialogue(speaker: string, text: string, color: string) {
    this.dialogue = {speaker, text, color};
    this.dialogueTimer = 6.5;
  }

  private setWantedLevel(stars: number) {
    const clamped = Math.max(0, Math.min(5, stars));
    if (clamped > this.wantedLevel) {
      this.wantedLevel = clamped;
      this.wantedCooldown = 16;
      this.ensurePolicePursuit();
    } else {
      this.wantedLevel = clamped;
    }
  }

  private ensurePolicePursuit() {
    const activePoliceCars = this.vehicles.filter((v) => v.isPolice).length;
    const neededCars = Math.min(3, this.wantedLevel);
    const p = this.getPlayerPos();

    for (let i = activePoliceCars; i < neededCars; i++) {
      const angle = (i * 2.1) + Math.random();
      const dist = 55 + i * 15;
      const sx = THREE.MathUtils.clamp(p.x + Math.cos(angle) * dist, -155, 155);
      const sz = THREE.MathUtils.clamp(p.z + Math.sin(angle) * dist, -155, 155);
      this.spawnVehicle(`police_${Date.now()}_${i}`, 'LSPD Cruiser', 'police', 0x0f172a, sx, sz, 0, false, true);
    }

    const activePoliceFoot = this.hostiles.filter((h) => h.isPolice).length;
    if (activePoliceFoot < this.wantedLevel) {
      const angle = Math.random() * Math.PI * 2;
      const sx = THREE.MathUtils.clamp(p.x + Math.cos(angle) * 32, -155, 155);
      const sz = THREE.MathUtils.clamp(p.z + Math.sin(angle) * 32, -155, 155);
      this.spawnHostile(sx, sz, true);
    }
  }

  public switchProtagonist(target: ProtagonistId) {
    if (target === this.activeProtagonist) return;
    if (!this.unlocked.has(target)) {
      const prof = PROTAGONISTS[target];
      this.showDialogue(`${prof.name} Locked`, prof.unlockRequirement, '#f59e0b');
      this.emitHud();
      return;
    }
    this.audio.playSwitch();
    if (this.playerVehicle) {
      this.playerVehicle.occupiedByPlayer = false;
      this.playerVehicle = null;
    }
    this.activeProtagonist = target;
    this.specialActive = false;
    this.specialTimer = 0;
    this.rebuildPlayerMesh();
    const prof = PROTAGONISTS[target];
    this.showDialogue(prof.name, `Switched to ${prof.name} in ${prof.district}.`, prof.accentColor);
    this.emitHud();
  }

  private rebuildPlayerMesh() {
    this.scene.remove(this.playerRig.group);
    this.playerRig = createCharacterMesh(this.activeProtagonist);
    const st = this.protagonistStates[this.activeProtagonist];
    this.playerRig.group.position.set(st.x, st.y, st.z);
    this.playerRig.group.rotation.y = st.heading;
    this.scene.add(this.playerRig.group);
  }

  public activateSpecialAbility() {
    if (this.specialCharge < 35 || this.specialActive) return;
    this.specialActive = true;
    this.specialTimer = 7.0;
    this.audio.playSwitch();
    this.emitHud();
  }

  public cycleCameraMode() {
    this.cameraMode =
      this.cameraMode === 'chase' ? 'hood' : this.cameraMode === 'hood' ? 'cinematic' : 'chase';
    this.emitHud();
  }

  public toggleEnterExitVehicle() {
    this.audio.unlock();
    const st = this.protagonistStates[this.activeProtagonist];

    if (this.playerVehicle) {
      // Exit vehicle to left side
      const v = this.playerVehicle;
      v.occupiedByPlayer = false;
      st.x = v.x - Math.cos(v.heading) * 2.2;
      st.z = v.z + Math.sin(v.heading) * 2.2;
      st.y = 0;
      st.heading = v.heading;
      this.playerVehicle = null;
      this.playerRig.group.visible = true;
      this.emitHud();
      return;
    }

    const nearest = this.findNearestVehicle(5.2);
    if (nearest) {
      if (nearest.isTraffic) {
        nearest.isTraffic = false;
        this.setWantedLevel(Math.max(this.wantedLevel, 1));
      }
      if (nearest.isPolice) {
        this.setWantedLevel(Math.max(this.wantedLevel, 2));
      }
      this.playerVehicle = nearest;
      nearest.occupiedByPlayer = true;
      this.playerRig.group.visible = false;
      this.audio.playPickup();
      this.emitHud();
    }
  }

  private findNearestVehicle(maxDist: number): ActiveVehicle | null {
    const st = this.protagonistStates[this.activeProtagonist];
    let best: ActiveVehicle | null = null;
    let bestD = maxDist * maxDist;
    for (const v of this.vehicles) {
      const dx = v.x - st.x;
      const dz = v.z - st.z;
      const d2 = dx * dx + dz * dz;
      if (d2 < bestD) {
        bestD = d2;
        best = v;
      }
    }
    return best;
  }

  public triggerAttack() {
    this.audio.unlock();
    if (this.playerVehicle || this.shootCooldown > 0 || this.wasted) return;
    const st = this.protagonistStates[this.activeProtagonist];
    if (st.ammo <= 0) st.ammo = 30;
    st.ammo--;
    this.shootCooldown = this.specialActive && this.activeProtagonist === 'michael' ? 0.14 : 0.24;
    this.muzzleTimer = 0.08;
    this.playerRig.muzzleFlash.visible = true;
    this.audio.playShot();

    // Shoot along camera/player forward
    const aimAngle = st.heading;
    const dirX = Math.sin(aimAngle);
    const dirZ = Math.cos(aimAngle);

    const tracerMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.12, 6, 6),
      new THREE.MeshBasicMaterial({color: 0xfef08a}),
    );
    tracerMesh.position.set(st.x + dirX * 0.8, 1.25, st.z + dirZ * 0.8);
    this.scene.add(tracerMesh);
    this.tracers.push({
      mesh: tracerMesh,
      vx: dirX * 58,
      vz: dirZ * 58,
      life: 0.65,
      fromPlayer: true,
    });

    if (this.wantedLevel === 0 && !this.activeMission) {
      // Shooting near police triggers wanted
      for (const h of this.hostiles) {
        if (Math.hypot(h.x - st.x, h.z - st.z) < 40) {
          this.setWantedLevel(1);
          break;
        }
      }
    }
  }

  public setTouchInput(partial: Partial<TouchInputState>) {
    Object.assign(this.touchInput, partial);
  }

  public exportSaveData(): PortableSaveData {
    return {
      version: 1,
      savedAt: new Date().toISOString(),
      protagonist: this.activeProtagonist,
      unlocked: Array.from(this.unlocked),
      cash: {...this.cash},
      completedMissions: Array.from(this.completedMissions),
      qualityTier: this.qualityTier,
    };
  }

  public importSaveData(save: PortableSaveData) {
    if (!save || typeof save !== 'object') return;
    const validUnlocked = Array.isArray(save.unlocked)
      ? save.unlocked.filter((id): id is ProtagonistId => id in PROTAGONISTS)
      : [];
    const hasValidSave = validUnlocked.length > 0;
    if (!hasValidSave) {
      // Stale/legacy save from previous build — ignore and start fresh GTA V campaign
      return;
    }

    this.unlocked = new Set<ProtagonistId>(['franklin', ...validUnlocked]);
    if (save.cash && typeof save.cash === 'object') {
      (['michael', 'franklin', 'trevor'] as ProtagonistId[]).forEach((id) => {
        const val = save.cash[id];
        if (typeof val === 'number' && Number.isFinite(val) && val >= 0) {
          this.cash[id] = val;
        }
      });
    }

    const validMissionIds = new Set(STORY_MISSIONS.map((m) => m.id));
    if (Array.isArray(save.completedMissions)) {
      this.completedMissions = new Set(save.completedMissions.filter((id) => validMissionIds.has(id)));
    }
    if (save.qualityTier) this.setQualityTier(save.qualityTier);

    if (this.completedMissions.has('m0_prologue')) {
      // Clear initial prologue flashback & switch to sunny Los Santos
      if (this.activeMission?.id === 'm0_prologue') {
        this.clearMissionEntities();
        this.activeMission = null;
        this.waypointRing.visible = false;
        this.waypointBeacon.visible = false;
        (this.scene.background as THREE.Color).setHex(0x9bc4e2);
        (this.scene.fog as THREE.FogExp2).color.setHex(0x9bc4e2);
        (this.scene.fog as THREE.FogExp2).density = this.qualityTier === 'pc-high' ? 0.0024 : 0.0036;
      }

      if (!this.completedMissions.has('m1_franklin_lamar')) {
        this.startMission('m1_franklin_lamar');
      } else if (save.protagonist && this.unlocked.has(save.protagonist)) {
        this.activeProtagonist = save.protagonist;
        this.rebuildPlayerMesh();
      } else {
        this.activeProtagonist = 'franklin';
        this.rebuildPlayerMesh();
      }
    }

    this.saveToLocalStorage();
    this.emitHud();
  }

  private saveToLocalStorage() {
    try {
      localStorage.setItem('los_solis_v_save', JSON.stringify(this.exportSaveData()));
    } catch {
      // ignore storage quota errors
    }
  }

  public loadFromLocalStorage() {
    try {
      const raw = localStorage.getItem('los_solis_v_save');
      if (raw) {
        const parsed = JSON.parse(raw) as PortableSaveData;
        this.importSaveData(parsed);
      }
    } catch {
      // ignore invalid local save
    }
  }

  private getPlayerPos(): {x: number; z: number; heading: number} {
    if (this.playerVehicle) {
      return {x: this.playerVehicle.x, z: this.playerVehicle.z, heading: this.playerVehicle.heading};
    }
    const st = this.protagonistStates[this.activeProtagonist];
    return {x: st.x, z: st.z, heading: st.heading};
  }

  private resolveBuildingCollision(x: number, z: number, radius: number): {x: number; z: number; hit: boolean} {
    let rx = THREE.MathUtils.clamp(x, -172, 172);
    let rz = THREE.MathUtils.clamp(z, -172, 172);
    let hit = rx !== x || rz !== z;

    for (const c of this.world.colliders) {
      const nearX = THREE.MathUtils.clamp(rx, c.minX, c.maxX);
      const nearZ = THREE.MathUtils.clamp(rz, c.minZ, c.maxZ);
      const dx = rx - nearX;
      const dz = rz - nearZ;
      const d2 = dx * dx + dz * dz;
      if (d2 < radius * radius) {
        hit = true;
        if (d2 > 0.0001) {
          const dist = Math.sqrt(d2);
          rx = nearX + (dx / dist) * radius;
          rz = nearZ + (dz / dist) * radius;
        } else {
          // Inside box fallback push
          const penL = Math.abs(rx - c.minX);
          const penR = Math.abs(c.maxX - rx);
          const penT = Math.abs(rz - c.minZ);
          const penB = Math.abs(c.maxZ - rz);
          const minPen = Math.min(penL, penR, penT, penB);
          if (minPen === penL) rx = c.minX - radius;
          else if (minPen === penR) rx = c.maxX + radius;
          else if (minPen === penT) rz = c.minZ - radius;
          else rz = c.maxZ + radius;
        }
      }
    }
    return {x: rx, z: rz, hit};
  }

  public setMobile30FpsCap(enabled: boolean) {
    this.mobile30FpsCap = enabled;
  }

  public getMobile30FpsCap(): boolean {
    return this.mobile30FpsCap;
  }

  private tick = () => {
    if (this.disposed) return;

    const now = performance.now();
    const isMobileTier = this.qualityTier !== 'pc-high';
    if (!this.isSoftwareGl && isMobileTier && this.mobile30FpsCap) {
      if (now - this.lastRenderTime < 32.5) {
        this.frameId = requestAnimationFrame(this.tick);
        return;
      }
    }
    this.lastRenderTime = now;

    const rawDt = Math.min(0.066, Math.max(0.001, (now - this.lastTime) / 1000));
    this.lastTime = now;

    // Track FPS & adaptive thermal governor for low-end mobile
    this.fpsSamples.push(1 / rawDt);
    if (this.fpsSamples.length > 20) this.fpsSamples.shift();
    this.currentFps = Math.round(this.fpsSamples.reduce((a, b) => a + b, 0) / this.fpsSamples.length);

    if (!this.isSoftwareGl && this.qualityTier === 'mobile-balanced') {
      if (this.currentFps < 25) {
        this.lowFpsDuration += rawDt;
        if (this.lowFpsDuration > 2.2) {
          this.lowFpsDuration = 0;
          this.setQualityTier('mobile-eco');
        }
      } else {
        this.lowFpsDuration = Math.max(0, this.lowFpsDuration - rawDt * 0.5);
      }
    }

    // Michael Bullet-Time slow-mo time scale
    const worldDt = this.specialActive && this.activeProtagonist === 'michael' ? rawDt * 0.55 : rawDt;

    this.updateTimers(rawDt);
    this.updatePlayer(rawDt, worldDt);
    this.updateVehicles(worldDt);
    this.updateHostilesAndTracers(worldDt);
    this.updateMissionProgress(rawDt);
    this.updateCamera(rawDt);

    // Animate coastal water & waypoint
    this.world.waterUniforms.uTime.value += rawDt;
    if (this.waypointRing.visible) {
      const pulse = 1 + Math.sin(now * 0.006) * 0.08;
      this.waypointRing.scale.set(pulse, pulse, 1);
    }
    for (const lp of this.lootPickups) {
      if (!lp.collected) {
        lp.mesh.rotation.y += rawDt * 2.4;
      }
    }

    // Move sun shadow frustum smoothly with player
    const p = this.getPlayerPos();
    this.sunLight.position.set(p.x + 80, 120, p.z + 60);
    this.sunLight.target.position.set(p.x, 0, p.z);

    // Audio continuous update
    const speedRatio = this.playerVehicle ? Math.abs(this.playerVehicle.speed) / 36 : 0;
    this.audio.updateContinuous(Boolean(this.playerVehicle), speedRatio, this.wantedLevel, now * 0.001);

    this.renderer.render(this.scene, this.camera);

    this.hudAccum += rawDt;
    if (this.hudAccum >= 0.075) {
      this.hudAccum = 0;
      this.emitHud();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private updateTimers(dt: number) {
    if (this.dialogueTimer > 0) {
      this.dialogueTimer -= dt;
      if (this.dialogueTimer <= 0) this.dialogue = null;
    }
    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) this.banner = null;
    }
    if (this.shootCooldown > 0) this.shootCooldown -= dt;
    if (this.muzzleTimer > 0) {
      this.muzzleTimer -= dt;
      if (this.muzzleTimer <= 0) this.playerRig.muzzleFlash.visible = false;
    }
    if (this.specialActive) {
      this.specialTimer -= dt;
      this.specialCharge = Math.max(0, (this.specialTimer / 7.0) * 100);
      if (this.specialTimer <= 0) {
        this.specialActive = false;
      }
    } else {
      this.specialCharge = Math.min(100, this.specialCharge + dt * 6);
    }

    if (this.wantedLevel > 0) {
      this.wantedCooldown -= dt;
      if (this.wantedCooldown <= 0) {
        this.wantedLevel = Math.max(0, this.wantedLevel - 1);
        this.wantedCooldown = 14;
      }
    }

    if (this.wasted) {
      this.wastedTimer -= dt;
      if (this.wastedTimer <= 0) {
        this.wasted = false;
        const st = this.protagonistStates[this.activeProtagonist];
        const prof = PROTAGONISTS[this.activeProtagonist];
        st.x = prof.spawnPos[0];
        st.z = prof.spawnPos[2];
        st.y = 0;
        st.hp = 100;
        st.armor = 50;
        this.wantedLevel = 0;
        if (this.playerVehicle) {
          this.playerVehicle.occupiedByPlayer = false;
          this.playerVehicle = null;
          this.playerRig.group.visible = true;
        }
        this.banner = {title: 'RECOVERED', subtitle: `Discharged near ${prof.district}`};
        this.bannerTimer = 3.0;
      }
    }
  }

  private updatePlayer(dt: number, worldDt: number) {
    if (this.wasted) return;

    // Camera keyboard/touch pan
    if (this.keys['KeyQ']) this.camYaw += dt * 2.1;
    if (this.keys['KeyE']) this.camYaw -= dt * 2.1;
    if (Math.abs(this.touchInput.cameraDeltaX) > 0.0001 || Math.abs(this.touchInput.cameraDeltaY) > 0.0001) {
      this.camYaw -= this.touchInput.cameraDeltaX * 0.0055;
      this.camPitch = THREE.MathUtils.clamp(this.camPitch + this.touchInput.cameraDeltaY * 0.0035, 0.08, 0.95);
      this.touchInput.cameraDeltaX = 0;
      this.touchInput.cameraDeltaY = 0;
    }

    if (this.playerVehicle) {
      const v = this.playerVehicle;
      const isApex = this.specialActive && this.activeProtagonist === 'franklin';
      const maxSpeed = v.variant === 'sports' ? 42 : v.variant === 'muscle' ? 38 : v.variant === 'armored' ? 28 : 34;
      const accel = (isApex ? 44 : 26) * (v.variant === 'sports' ? 1.15 : 1);

      const throttle =
        (this.keys['KeyW'] || this.keys['ArrowUp'] || this.touchInput.gas ? 1 : 0) -
        (this.keys['KeyS'] || this.keys['ArrowDown'] || this.touchInput.brake ? 1 : 0);
      const steerInput =
        (this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0) -
        (this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0) -
        this.touchInput.moveX;
      const handbrake = Boolean(this.keys['Space'] || this.touchInput.handbrake);

      if (throttle > 0) {
        v.speed += accel * dt;
      } else if (throttle < 0) {
        v.speed -= accel * 1.1 * dt;
      } else {
        v.speed *= Math.exp(-1.9 * dt);
      }

      if (handbrake) {
        v.speed *= Math.exp(-3.4 * dt);
      }

      v.speed = THREE.MathUtils.clamp(v.speed, -16, isApex ? maxSpeed * 1.25 : maxSpeed);
      const targetSteer = THREE.MathUtils.clamp(steerInput, -1, 1) * (handbrake ? 0.55 : 0.42);
      v.steerAngle = THREE.MathUtils.damp(v.steerAngle, targetSteer, isApex ? 14 : 9, dt);

      const turnFactor = Math.min(1, Math.abs(v.speed) / 5) * (v.speed >= 0 ? 1 : -1);
      v.heading += v.steerAngle * turnFactor * (isApex ? 3.1 : 2.35) * dt;

      // Keep protagonist synced inside vehicle
      const st = this.protagonistStates[this.activeProtagonist];
      st.x = v.x;
      st.y = v.y;
      st.z = v.z;
      st.heading = v.heading;
      return;
    }

    // On-foot movement
    const st = this.protagonistStates[this.activeProtagonist];
    let inX = (this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0) - (this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0) + this.touchInput.moveX;
    let inY = (this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0) - (this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0) - this.touchInput.moveY;
    const len = Math.hypot(inX, inY);

    if (this.keys['KeyJ'] || this.touchInput.attack) {
      this.triggerAttack();
    }

    if (len > 0.08) {
      inX /= Math.max(1, len);
      inY /= Math.max(1, len);
      const sprint = Boolean(this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchInput.sprint);
      const moveSpeed = sprint ? 12.5 : 7.4;

      // Camera-relative planar movement
      const sinY = Math.sin(this.camYaw);
      const cosY = Math.cos(this.camYaw);
      const forwardX = -sinY;
      const forwardZ = -cosY;
      const rightX = cosY;
      const rightZ = -sinY;

      const dirX = forwardX * inY + rightX * inX;
      const dirZ = forwardZ * inY + rightZ * inX;

      const nx = st.x + dirX * moveSpeed * worldDt;
      const nz = st.z + dirZ * moveSpeed * worldDt;
      const col = this.resolveBuildingCollision(nx, nz, 0.55);
      st.x = col.x;
      st.z = col.z;

      const targetHeading = Math.atan2(dirX, dirZ);
      let diff = targetHeading - st.heading;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      st.heading += diff * Math.min(1, 12 * dt);

      // Walk cycle swing
      this.walkAnimTime += worldDt * (sprint ? 14 : 9);
      const swing = Math.sin(this.walkAnimTime) * 0.65;
      this.playerRig.leftLeg.rotation.x = swing;
      this.playerRig.rightLeg.rotation.x = -swing;
      this.playerRig.leftArm.rotation.x = -swing * 0.8;
      this.playerRig.rightArm.rotation.x = this.muzzleTimer > 0 ? -Math.PI / 2 : swing * 0.6;
    } else {
      this.playerRig.leftLeg.rotation.x = THREE.MathUtils.damp(this.playerRig.leftLeg.rotation.x, 0, 10, dt);
      this.playerRig.rightLeg.rotation.x = THREE.MathUtils.damp(this.playerRig.rightLeg.rotation.x, 0, 10, dt);
      this.playerRig.leftArm.rotation.x = THREE.MathUtils.damp(this.playerRig.leftArm.rotation.x, 0, 10, dt);
      this.playerRig.rightArm.rotation.x = THREE.MathUtils.damp(
        this.playerRig.rightArm.rotation.x,
        this.muzzleTimer > 0 ? -Math.PI / 2 : 0,
        10,
        dt,
      );
    }

    // Jump & gravity
    if (this.keys['Space'] && st.y <= 0.01) {
      st.vy = 6.8;
    }
    st.vy -= 19.6 * dt;
    st.y += st.vy * dt;
    if (st.y < 0) {
      st.y = 0;
      st.vy = 0;
    }

    this.playerRig.group.position.set(st.x, st.y, st.z);
    this.playerRig.group.rotation.y = st.heading;
  }

  private updateVehicles(dt: number) {
    const playerPos = this.getPlayerPos();
    const nowSec = performance.now() * 0.008;

    for (const v of this.vehicles) {
      if (v.isTraffic) {
        // Simple road cruising AI
        if (v.trafficAxis === 'z') {
          v.z += (v.trafficDir || 1) * v.speed * dt;
          if (v.z > 165) v.z = -165;
          if (v.z < -165) v.z = 165;
        } else {
          v.x += (v.trafficDir || 1) * v.speed * dt;
          if (v.x > 165) v.x = -165;
          if (v.x < -165) v.x = 165;
        }
      } else if (v.isPolice && !v.occupiedByPlayer) {
        if (this.wantedLevel > 0) {
          const dx = playerPos.x - v.x;
          const dz = playerPos.z - v.z;
          const dist = Math.hypot(dx, dz);
          const targetH = Math.atan2(dx, dz);
          let diff = targetH - v.heading;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          v.heading += THREE.MathUtils.clamp(diff, -2.1 * dt, 2.1 * dt);
          v.speed = dist > 12 ? 23 + this.wantedLevel * 2.2 : 0;
          const nx = v.x + Math.sin(v.heading) * v.speed * dt;
          const nz = v.z + Math.cos(v.heading) * v.speed * dt;
          const col = this.resolveBuildingCollision(nx, nz, 1.45);
          v.x = col.x;
          v.z = col.z;
          if (col.hit) v.heading += 0.8;
        } else {
          v.speed *= Math.exp(-3 * dt);
        }

        // Flash police lightbar
        if (v.rig.sirenLeft && v.rig.sirenRight) {
          const leftOn = Math.sin(nowSec * 2.2) > 0;
          (v.rig.sirenLeft.material as THREE.MeshStandardMaterial).emissiveIntensity =
            this.wantedLevel > 0 ? (leftOn ? 3.5 : 0.2) : 0.2;
          (v.rig.sirenRight.material as THREE.MeshStandardMaterial).emissiveIntensity =
            this.wantedLevel > 0 ? (!leftOn ? 3.5 : 0.2) : 0.2;
        }
      } else if (v.occupiedByPlayer || Math.abs(v.speed) > 0.1) {
        const nx = v.x + Math.sin(v.heading) * v.speed * dt;
        const nz = v.z + Math.cos(v.heading) * v.speed * dt;
        const col = this.resolveBuildingCollision(nx, nz, 1.35);
        v.x = col.x;
        v.z = col.z;
        if (col.hit && Math.abs(v.speed) > 8) {
          v.speed *= -0.35;
          this.audio.playImpact();
        }
        if (!v.occupiedByPlayer) {
          v.speed *= Math.exp(-2.8 * dt);
        }

        // Stunt ramp vertical launch!
        for (const r of this.world.ramps) {
          if (v.x >= r.minX && v.x <= r.maxX && v.z >= r.minZ && v.z <= r.maxZ && v.y < 0.2 && Math.abs(v.speed) > 15) {
            v.vy = Math.min(11, Math.abs(v.speed) * 0.34);
          }
        }
        v.vy -= 19.6 * dt;
        v.y += v.vy * dt;
        if (v.y < 0) {
          v.y = 0;
          v.vy = 0;
        }
      }

      // Update wheel spin & steering pivots
      const spin = v.speed * dt * 2.2;
      for (const w of v.rig.wheels) w.rotation.x += spin;
      for (const p of v.rig.frontSteerPivots) p.rotation.y = v.steerAngle;

      v.rig.group.position.set(v.x, v.y, v.z);
      v.rig.group.rotation.y = v.heading;
    }
  }

  private updateHostilesAndTracers(dt: number) {
    const playerPos = this.getPlayerPos();
    const st = this.protagonistStates[this.activeProtagonist];

    // Update hostiles
    for (let i = this.hostiles.length - 1; i >= 0; i--) {
      const h = this.hostiles[i];
      if (h.isPolice && this.wantedLevel === 0) {
        this.scene.remove(h.rig.group);
        this.hostiles.splice(i, 1);
        continue;
      }

      const dx = playerPos.x - h.x;
      const dz = playerPos.z - h.z;
      const dist = Math.hypot(dx, dz);
      if (dist < 42) {
        h.heading = Math.atan2(dx, dz);
        if (dist > 9) {
          const speed = h.isPolice ? 5.2 : 4.2;
          const col = this.resolveBuildingCollision(
            h.x + (dx / dist) * speed * dt,
            h.z + (dz / dist) * speed * dt,
            0.5,
          );
          h.x = col.x;
          h.z = col.z;
          const swing = Math.sin(performance.now() * 0.01 + i) * 0.5;
          h.rig.leftLeg.rotation.x = swing;
          h.rig.rightLeg.rotation.x = -swing;
        }
        h.shootCooldown -= dt;
        if (h.shootCooldown <= 0 && dist < 26) {
          h.shootCooldown = 1.15 + Math.random() * 0.7;
          const dirX = dx / Math.max(0.1, dist);
          const dirZ = dz / Math.max(0.1, dist);
          const mesh = new THREE.Mesh(
            new THREE.SphereGeometry(0.11, 5, 5),
            new THREE.MeshBasicMaterial({color: 0xf87171}),
          );
          mesh.position.set(h.x + dirX * 0.8, 1.25, h.z + dirZ * 0.8);
          this.scene.add(mesh);
          this.tracers.push({mesh, vx: dirX * 38, vz: dirZ * 38, life: 0.9, fromPlayer: false});
        }
      }
      h.rig.group.position.set(h.x, 0, h.z);
      h.rig.group.rotation.y = h.heading;
    }

    // Update bullet tracers
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.life -= dt;
      t.mesh.position.x += t.vx * dt;
      t.mesh.position.z += t.vz * dt;

      let remove = t.life <= 0;
      if (!remove && t.fromPlayer) {
        const dmg = this.specialActive && this.activeProtagonist === 'trevor' ? 60 : 30;
        for (let hi = this.hostiles.length - 1; hi >= 0; hi--) {
          const h = this.hostiles[hi];
          if (Math.hypot(t.mesh.position.x - h.x, t.mesh.position.z - h.z) < 0.95) {
            h.hp -= dmg;
            remove = true;
            this.audio.playImpact();
            if (h.hp <= 0) {
              this.scene.remove(h.rig.group);
              this.hostiles.splice(hi, 1);
              if (h.isPolice) {
                this.setWantedLevel(Math.min(5, this.wantedLevel + 1));
              }
              if (this.activeMission?.stages[this.activeStageIdx]?.type === 'eliminate') {
                this.stageProgress++;
              }
            }
            break;
          }
        }
      } else if (!remove && !t.fromPlayer) {
        if (Math.hypot(t.mesh.position.x - playerPos.x, t.mesh.position.z - playerPos.z) < 0.9) {
          remove = true;
          let dmg = this.playerVehicle ? 4 : 9;
          if (this.specialActive && this.activeProtagonist === 'trevor') dmg *= 0.3;
          if (st.armor > 0) {
            const absorb = Math.min(st.armor, dmg * 0.7);
            st.armor -= absorb;
            dmg -= absorb;
          }
          st.hp = Math.max(0, st.hp - dmg);
          if (st.hp <= 0 && !this.wasted) {
            this.wasted = true;
            this.wastedTimer = 2.8;
            this.banner = {title: 'WASTED', subtitle: 'Medical extraction inbound...'};
            this.bannerTimer = 2.8;
          }
        }
      }

      if (remove) {
        this.scene.remove(t.mesh);
        t.mesh.geometry.dispose();
        (t.mesh.material as THREE.Material).dispose();
        this.tracers.splice(i, 1);
      }
    }
  }

  private updateMissionProgress(dt: number) {
    if (!this.activeMission) return;
    const stage = this.activeMission.stages[this.activeStageIdx];
    if (!stage) return;

    const p = this.getPlayerPos();
    const dist = Math.hypot(p.x - stage.targetPos[0], p.z - stage.targetPos[2]);

    switch (stage.type) {
      case 'goto':
        if (dist <= stage.radius) this.advanceStage();
        break;
      case 'steal_vehicle':
        if (this.playerVehicle && dist > stage.radius) this.advanceStage();
        break;
      case 'collect_loot': {
        for (const lp of this.lootPickups) {
          if (!lp.collected && Math.hypot(p.x - lp.x, p.z - lp.z) < 2.6) {
            lp.collected = true;
            lp.mesh.visible = false;
            this.stageProgress++;
            this.audio.playPickup();
          }
        }
        if (this.stageProgress >= (stage.countTarget || 1)) {
          this.advanceStage();
        }
        break;
      }
      case 'eliminate':
        if (this.stageProgress >= (stage.countTarget || 1)) {
          this.advanceStage();
        }
        break;
      case 'escape_wanted':
        if (this.wantedLevel > 0) {
          // Decay wanted faster when driving fast away from cops
          const speed = this.playerVehicle ? Math.abs(this.playerVehicle.speed) : 0;
          if (speed > 20) {
            this.wantedCooldown -= dt * 1.4;
          }
        }
        if (dist <= stage.radius) {
          this.advanceStage();
        }
        break;
    }
  }

  private updateCamera(dt: number) {
    const p = this.getPlayerPos();
    const st = this.protagonistStates[this.activeProtagonist];

    if (this.playerVehicle && this.cameraMode === 'hood') {
      const v = this.playerVehicle;
      _camDesired.set(
        v.x + Math.sin(v.heading) * 0.8,
        v.y + 1.55,
        v.z + Math.cos(v.heading) * 0.8,
      );
      _camTarget.set(
        v.x + Math.sin(v.heading) * 18,
        v.y + 1.2,
        v.z + Math.cos(v.heading) * 18,
      );
      this.camera.position.lerp(_camDesired, Math.min(1, 22 * dt));
      this.camera.lookAt(_camTarget);
      return;
    }

    // Smooth auto-follow yaw behind vehicle when driving
    if (this.playerVehicle && !this.pointerDragging) {
      const targetYaw = this.playerVehicle.heading + Math.PI;
      let diff = targetYaw - this.camYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.camYaw += diff * Math.min(1, 3.2 * dt);
    }

    const baseDist = this.playerVehicle
      ? this.cameraMode === 'cinematic'
        ? 14.5
        : 9.8
      : 5.6;
    const heightOffset = this.playerVehicle ? 3.2 : 1.9 + st.y;

    // Speed FOV widening
    const targetFov = this.playerVehicle
      ? 62 + Math.min(14, Math.abs(this.playerVehicle.speed) * 0.35)
      : 60;
    if (Math.abs(this.camera.fov - targetFov) > 0.1) {
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 6, dt);
      this.camera.updateProjectionMatrix();
    }

    const horizDist = Math.cos(this.camPitch) * baseDist;
    const vertDist = Math.sin(this.camPitch) * baseDist;

    _camDesired.set(
      p.x + Math.sin(this.camYaw) * horizDist,
      heightOffset + vertDist,
      p.z + Math.cos(this.camYaw) * horizDist,
    );
    _camTarget.set(p.x, (this.playerVehicle ? 1.2 : 1.35) + st.y, p.z);

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _camDesired.x, 10, dt);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _camDesired.y, 10, dt);
    this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _camDesired.z, 10, dt);
    this.camera.lookAt(_camTarget);
  }

  private emitHud() {
    const st = this.protagonistStates[this.activeProtagonist];
    const nearVehicle = this.playerVehicle ? null : this.findNearestVehicle(5.2);
    const stage = this.activeMission?.stages[this.activeStageIdx];

    const blips: RadarBlip[] = [];
    if (stage) {
      blips.push({x: stage.targetPos[0], z: stage.targetPos[2], kind: 'mission', color: '#facc15'});
    }
    for (const v of this.vehicles) {
      if (v.occupiedByPlayer) continue;
      if (v.isPolice && this.wantedLevel > 0) {
        blips.push({x: v.x, z: v.z, kind: 'police', color: '#ef4444'});
      } else if (!v.isTraffic) {
        blips.push({x: v.x, z: v.z, kind: 'vehicle', color: '#94a3b8'});
      }
    }
    for (const lp of this.lootPickups) {
      if (!lp.collected) blips.push({x: lp.x, z: lp.z, kind: 'loot', color: '#10b981'});
    }

    const progText =
      stage?.type === 'collect_loot' || stage?.type === 'eliminate'
        ? `${this.stageProgress} / ${stage.countTarget || 1}`
        : '';

    const px = this.playerVehicle ? this.playerVehicle.x : st.x;
    const pz = this.playerVehicle ? this.playerVehicle.z : st.z;

    this.onHudUpdate({
      protagonist: this.activeProtagonist,
      unlocked: Array.from(this.unlocked),
      cash: {...this.cash},
      health: Math.round(st.hp),
      armor: Math.round(st.armor),
      specialCharge: Math.round(this.specialCharge),
      specialActive: this.specialActive,
      wantedLevel: this.wantedLevel,
      wantedCooldown: Math.ceil(this.wantedCooldown),
      inVehicle: Boolean(this.playerVehicle),
      vehicleName: this.playerVehicle?.label ?? '',
      speedKmh: this.playerVehicle ? Math.round(Math.abs(this.playerVehicle.speed) * 3.6) : 0,
      canEnterVehicle: Boolean(nearVehicle),
      nearVehicleName: nearVehicle?.label ?? '',
      ammo: st.ammo,
      districtName: this.activeMission?.isSnowFlashback ? 'Ludendorff · North Yankton' : getDistrictAt(px, pz),
      activeMissionId: this.activeMission?.id ?? null,
      activeStageIndex: this.activeStageIdx,
      missionObjective: stage ? stage.instruction : 'Free Roam — Explore Los Santos or launch the next story mission',
      missionProgressText: progText,
      completedMissions: Array.from(this.completedMissions),
      newlyUnlockedCharacter: this.newlyUnlockedCharacter,
      dialogue: this.dialogue,
      banner: this.banner,
      cameraMode: this.cameraMode,
      playerX: px,
      playerZ: pz,
      playerHeading: this.playerVehicle ? this.playerVehicle.heading : st.heading,
      radarBlips: blips,
      atlasMetrics: {
        atlasResolution: this.atlas.resolution,
        tileCount: this.atlas.tileList.length,
        tileSizePx: this.atlas.tileSizePx,
        gutterPx: this.atlas.gutterPx,
        drawCalls: this.renderer.info.render.calls,
        triangles: this.renderer.info.render.triangles,
        geometries: this.renderer.info.memory.geometries,
        textures: this.renderer.info.memory.textures,
        fps: this.currentFps,
        qualityTier: this.qualityTier,
        pixelRatio: this.renderer.getPixelRatio(),
        isSoftwareGl: this.isSoftwareGl,
      },
      wasted: this.wasted,
    });
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    this.audio.unlock();
    this.keys[e.code] = true;
    if (e.code === 'KeyF') this.toggleEnterExitVehicle();
    if (e.code === 'KeyR') this.activateSpecialAbility();
    if (e.code === 'KeyC') this.cycleCameraMode();
    if (e.code === 'Digit1') this.switchProtagonist('michael');
    if (e.code === 'Digit2') this.switchProtagonist('franklin');
    if (e.code === 'Digit3') this.switchProtagonist('trevor');
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private handlePointerDown = (e: PointerEvent) => {
    if (e.target !== this.renderer.domElement) return;
    this.audio.unlock();
    this.pointerDragging = true;
    this.lastPointerX = e.clientX;
    this.lastPointerY = e.clientY;
    if (e.pointerType === 'mouse' && e.button === 0 && !this.playerVehicle) {
      this.triggerAttack();
    }
  };

  private handlePointerMove = (e: PointerEvent) => {
    if (!this.pointerDragging) return;
    const dx = e.clientX - this.lastPointerX;
    const dy = e.clientY - this.lastPointerY;
    this.lastPointerX = e.clientX;
    this.lastPointerY = e.clientY;
    this.camYaw -= dx * 0.005;
    this.camPitch = THREE.MathUtils.clamp(this.camPitch + dy * 0.003, 0.08, 0.95);
  };

  private handlePointerUp = () => {
    this.pointerDragging = false;
  };

  private handleResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
  };

  private bindEvents() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('resize', this.handleResize);
    const canvas = this.renderer.domElement;
    canvas.addEventListener('pointerdown', this.handlePointerDown);
    window.addEventListener('pointermove', this.handlePointerMove);
    window.addEventListener('pointerup', this.handlePointerUp);
    canvas.addEventListener('webglcontextlost', this.handleContextLost);
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('resize', this.handleResize);
    const canvas = this.renderer.domElement;
    canvas.removeEventListener('pointerdown', this.handlePointerDown);
    window.removeEventListener('pointermove', this.handlePointerMove);
    window.removeEventListener('pointerup', this.handlePointerUp);
    canvas.removeEventListener('webglcontextlost', this.handleContextLost);

    this.audio.dispose();
    this.world.dispose();
    this.atlas.dispose();
    this.envMap.dispose();
    this.renderer.dispose();
    if (canvas.parentElement === this.container) {
      this.container.removeChild(canvas);
    }
  }
}
