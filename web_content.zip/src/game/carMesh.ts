import * as THREE from "three";
import type { Skin } from "@/game/skins";

export type CarVisual = {
  root: THREE.Group;
  wheels: THREE.Object3D[];
  steerPivots: THREE.Object3D[];
  brake: THREE.MeshStandardMaterial;
};

const GEO = new Map<string, THREE.BufferGeometry>();

function box(w: number, h: number, d: number): THREE.BufferGeometry {
  const key = `b:${w}:${h}:${d}`;
  let g = GEO.get(key);
  if (!g) {
    g = new THREE.BoxGeometry(w, h, d);
    GEO.set(key, g);
  }
  return g;
}

function wheelGeo(r: number, width: number): THREE.BufferGeometry {
  const key = `w:${r}:${width}`;
  let g = GEO.get(key);
  if (!g) {
    g = new THREE.CylinderGeometry(r, r, width, 18);
    g.rotateZ(Math.PI / 2);
    GEO.set(key, g);
  }
  return g;
}

function noseGeo(): THREE.BufferGeometry {
  const key = "nose";
  let g = GEO.get(key);
  if (!g) {
    g = new THREE.ConeGeometry(0.72, 1.35, 4);
    g.rotateX(Math.PI / 2);
    GEO.set(key, g);
  }
  return g;
}

function glowGeo(): THREE.BufferGeometry {
  const key = "glow";
  let g = GEO.get(key);
  if (!g) {
    g = new THREE.CircleGeometry(1.15, 20);
    GEO.set(key, g);
  }
  return g;
}

export function disposeCarGeometries(): void {
  for (const g of GEO.values()) g.dispose();
  GEO.clear();
}

export function disposeCar(visual: CarVisual): void {
  visual.root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const m of mats) m.dispose();
  });
  visual.root.parent?.remove(visual.root);
}

export function createCar(skin: Skin, headlights: boolean): CarVisual {
  const root = new THREE.Group();
  const wheels: THREE.Object3D[] = [];
  const steerPivots: THREE.Object3D[] = [];
  const body = new THREE.MeshStandardMaterial({
    color: skin.body,
    metalness: 0.72,
    roughness: 0.28,
    emissive: skin.body,
    emissiveIntensity: 0.22,
  });
  const accent = new THREE.MeshStandardMaterial({
    color: skin.accent,
    emissive: skin.accent,
    emissiveIntensity: 1.6,
    metalness: 0.4,
    roughness: 0.35,
  });
  const dark = new THREE.MeshStandardMaterial({
    color: "#14161c",
    metalness: 0.5,
    roughness: 0.45,
  });
  const glass = new THREE.MeshStandardMaterial({
    color: skin.glass,
    transparent: true,
    opacity: 0.48,
    roughness: 0.04,
    metalness: 0.15,
    emissive: skin.glass,
    emissiveIntensity: 0.12,
  });
  const tireMat = new THREE.MeshStandardMaterial({ color: "#1a1c20", roughness: 0.9, metalness: 0.1 });
  const rimMat = new THREE.MeshStandardMaterial({
    color: skin.accent,
    emissive: skin.accent,
    emissiveIntensity: 0.45,
    metalness: 0.8,
    roughness: 0.25,
  });
  const brake = new THREE.MeshStandardMaterial({
    color: "#ff2a2a",
    emissive: "#ff1e1e",
    emissiveIntensity: 0.7,
  });
  const lamp = new THREE.MeshStandardMaterial({
    color: "#fff4d2",
    emissive: "#fff1c4",
    emissiveIntensity: 2.4,
  });

  const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, shadow = true) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = shadow;
    m.receiveShadow = shadow;
    root.add(m);
    return m;
  };

  const buggy = skin.style === "buggy";
  const wr = buggy ? 0.5 : 0.36;
  const bodyY = buggy ? 0.62 : skin.style === "muscle" ? 0.55 : 0.46;
  const bodyH = buggy ? 0.28 : skin.style === "wedge" ? 0.3 : skin.style === "muscle" ? 0.48 : 0.4;
  const bodyL = skin.style === "wedge" ? 4.15 : skin.style === "muscle" ? 3.55 : buggy ? 3.3 : 3.9;
  const bodyW = buggy ? 1.55 : skin.style === "muscle" ? 1.85 : 1.72;

  add(box(bodyW, bodyH, bodyL), body, 0, bodyY, 0);
  if (skin.style === "wedge") {
    add(noseGeo(), body, 0, 0.42, 1.85);
  } else if (skin.style === "muscle") {
    add(box(1.55, 0.18, 1.15), body, 0, 0.78, 0.85);
  } else if (!buggy) {
    add(box(1.35, 0.22, 0.7), body, 0, bodyY, 1.55);
  }

  if (!buggy) {
    const cabZ = skin.style === "wedge" ? -0.35 : -0.15;
    const cabH = skin.style === "wedge" ? 0.26 : 0.38;
    const cab = add(
      box(bodyW * 0.78, cabH, skin.style === "muscle" ? 1.25 : 1.45),
      glass,
      0,
      bodyY + bodyH * 0.55,
      cabZ,
      false,
    );
    cab.castShadow = false;
  } else {
    add(box(0.08, 0.55, 0.08), dark, -0.55, 0.95, -0.4, false);
    add(box(0.08, 0.55, 0.08), dark, 0.55, 0.95, -0.4, false);
    add(box(0.08, 0.55, 0.08), dark, -0.55, 0.95, 0.45, false);
    add(box(0.08, 0.55, 0.08), dark, 0.55, 0.95, 0.45, false);
    add(box(1.2, 0.06, 0.06), accent, 0, 1.22, 0.05, false);
  }

  add(box(bodyW * 0.72, 0.06, bodyL * 0.55), accent, 0, bodyY + bodyH * 0.5 + 0.01, 0.1, false);

  if (skin.style !== "buggy") {
    add(box(bodyW * 0.7, 0.08, 0.35), dark, 0, bodyY + bodyH * 0.72, -bodyL * 0.42);
  }

  add(box(0.28, 0.12, 0.16), lamp, -0.48, bodyY, bodyL * 0.48, false);
  add(box(0.28, 0.12, 0.16), lamp, 0.48, bodyY, bodyL * 0.48, false);
  add(box(0.32, 0.1, 0.08), brake, -0.5, bodyY, -bodyL * 0.48, false);
  add(box(0.32, 0.1, 0.08), brake, 0.5, bodyY, -bodyL * 0.48, false);

  const glowMat = new THREE.MeshBasicMaterial({
    color: skin.accent,
    transparent: true,
    opacity: 0.8,
  });
  const glow = add(glowGeo(), glowMat, 0, 0.05, 0, false);
  glow.rotation.x = -Math.PI / 2;
  glow.castShadow = false;
  glow.receiveShadow = false;

  const trackW = buggy ? 0.95 : 0.78;
  const zs = [bodyL * 0.32, -bodyL * 0.32];
  zs.forEach((z, i) => {
    ([trackW, -trackW] as const).forEach((x) => {
      const spin = new THREE.Group();
      const tire = new THREE.Mesh(wheelGeo(wr, buggy ? 0.34 : 0.28), tireMat);
      const rim = new THREE.Mesh(wheelGeo(wr * 0.52, buggy ? 0.36 : 0.3), rimMat);
      tire.castShadow = true;
      rim.castShadow = true;
      spin.add(tire, rim);
      if (i === 0) {
        const pivot = new THREE.Group();
        pivot.position.set(x, wr, z);
        pivot.add(spin);
        root.add(pivot);
        steerPivots.push(pivot);
      } else {
        spin.position.set(x, wr, z);
        root.add(spin);
      }
      wheels.push(spin);
    });
  });

  if (headlights) {
    const spot = new THREE.SpotLight("#fff2d0", 55, 36, 0.62, 0.55, 1);
    spot.position.set(0, 0.75, 1.5);
    spot.target.position.set(0, 0.25, 10);
    root.add(spot);
    root.add(spot.target);
  }

  return { root, wheels, steerPivots, brake };
}
