import {
  Camera,
  Chicken,
  ClimbableWall,
  Crystal,
  HidingSpot,
  MazeData,
  Particle,
  Player,
} from '../types/game';
import { TILE_SIZE } from './mazeGenerator';

export class GameRenderer {
  private ctx: CanvasRenderingContext2D;
  private canvasWidth: number;
  private canvasHeight: number;
  private portalAngle: number = 0;

  constructor(ctx: CanvasRenderingContext2D, width: number, height: number) {
    this.ctx = ctx;
    this.canvasWidth = width;
    this.canvasHeight = height;
  }

  public updateDimensions(width: number, height: number) {
    this.canvasWidth = width;
    this.canvasHeight = height;
  }

  public render(
    maze: MazeData,
    player: Player,
    chickens: Chicken[],
    particles: Particle[],
    camera: Camera,
    anyChickenChasing: boolean,
    nearestChickenDist: number
  ) {
    const ctx = this.ctx;
    const cw = this.canvasWidth;
    const ch = this.canvasHeight;

    this.portalAngle += 0.035;

    // Clear background: dark atmospheric stone backdrop
    ctx.fillStyle = '#080d18';
    ctx.fillRect(0, 0, cw, ch);

    ctx.save();
    // Center camera on screen with zoom
    ctx.translate(cw / 2, ch / 2);
    ctx.scale(camera.zoom, camera.zoom);
    ctx.translate(-camera.x, -camera.y);

    // Compute visible tile bounds to cull rendering
    const viewHalfW = (cw / (2 * camera.zoom)) + TILE_SIZE * 2;
    const viewHalfH = (ch / (2 * camera.zoom)) + TILE_SIZE * 2;
    const minGridX = Math.max(0, Math.floor((camera.x - viewHalfW) / TILE_SIZE));
    const maxGridX = Math.min(maze.width - 1, Math.ceil((camera.x + viewHalfW) / TILE_SIZE));
    const minGridY = Math.max(0, Math.floor((camera.y - viewHalfH) / TILE_SIZE));
    const maxGridY = Math.min(maze.height - 1, Math.ceil((camera.y + viewHalfH) / TILE_SIZE));

    // 1. Draw Maze Floor & Corridor Grid
    this.renderFloor(maze, minGridX, maxGridX, minGridY, maxGridY);

    // 2. Draw Central Portal (with Locked vs Unlocked states)
    this.renderPortal(maze, maze.portalGrid.x * TILE_SIZE + TILE_SIZE / 2, maze.portalGrid.y * TILE_SIZE + TILE_SIZE / 2);

    // 3. Render 2.5D Elevated Walls (Base and Front Depth Faces)
    this.renderWalls(maze, minGridX, maxGridX, minGridY, maxGridY);

    // 4. Render Climbable Wall Ladders/Markings
    this.renderClimbableWalls(maze.climbableWalls);

    // 5. Render Hiding Spots (Bushes)
    this.renderHidingSpots(maze.hidingSpots);

    // 6. Render 3 Corner Collectible Crystals
    this.renderCrystals(maze.crystals);

    // 7. Render Tap-to-move path trail for player if active
    if (player.path.length > 0 && !player.isHiding) {
      this.renderPlayerPath(player);
    }

    // 7. Y-Sort Characters (Player, Chickens) and draw them
    const renderEntities: Array<{
      y: number;
      draw: () => void;
    }> = [];

    // Player rendering:
    // Real bushes: "When the player enters, make them semi-transparent and completely immune to chickens."
    // Fake bushes: "Provide no protection. The player remains visible and can be chased and caught normally."
    renderEntities.push({
      y: player.y,
      draw: () => {
        if (player.isHiding) {
          ctx.save();
          ctx.globalAlpha = 0.52; // Semi-transparent when safely hidden in real bush!
          this.renderPlayer(player);
          ctx.restore();
        } else {
          this.renderPlayer(player);
        }
      },
    });

    // Chickens
    chickens.forEach((chk) => {
      renderEntities.push({
        y: chk.y,
        draw: () => this.renderChicken(chk),
      });
    });

    renderEntities.sort((a, b) => a.y - b.y);
    renderEntities.forEach((entity) => entity.draw());

    // 8. Render Particles (dust, sparkles, feathers)
    this.renderParticles(particles);

    // 9. Render Ladder Countdown if placing
    if (player.isPlacingLadder) {
      this.renderLadderProgress(player);
    }

    ctx.restore();

    // 10. Screen overlays: Red Chase Vignette / Danger Pulse
    if (anyChickenChasing) {
      this.renderChaseVignette(nearestChickenDist);
    }
  }

  private renderFloor(
    maze: MazeData,
    minX: number,
    maxX: number,
    minY: number,
    maxY: number
  ) {
    const ctx = this.ctx;

    for (let gy = minY; gy <= maxY; gy++) {
      for (let gx = minX; gx <= maxX; gx++) {
        const px = gx * TILE_SIZE;
        const py = gy * TILE_SIZE;

        if (maze.tiles[gy][gx] === 0 || maze.tiles[gy][gx] === 2) {
          // Checkerboard subtle floor stone tiles
          const isEven = (gx + gy) % 2 === 0;
          ctx.fillStyle = isEven ? '#1e293b' : '#172033';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

          // Tile border
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 0.5, py + 0.5, TILE_SIZE - 1, TILE_SIZE - 1);

          // Subtle stone flagstone detail
          ctx.fillStyle = isEven ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.08)';
          ctx.fillRect(px + 4, py + 4, TILE_SIZE - 8, 4);
        }
      }
    }
  }

  private renderPortal(maze: MazeData, px: number, py: number) {
    const ctx = this.ctx;
    const isUnlocked = maze.portalUnlocked;

    ctx.save();
    ctx.translate(px, py);

    if (isUnlocked) {
      // FULL ACTIVE UNLOCKED PORTAL (Radiant swirling escape vortex)
      const glowRad = 52 + Math.sin(this.portalAngle * 3) * 7;
      const grad = ctx.createRadialGradient(0, 0, 10, 0, 0, glowRad);
      grad.addColorStop(0, 'rgba(56, 189, 248, 0.95)');
      grad.addColorStop(0.35, 'rgba(168, 85, 247, 0.7)');
      grad.addColorStop(0.75, 'rgba(59, 130, 246, 0.3)');
      grad.addColorStop(1, 'rgba(30, 58, 138, 0)');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, glowRad, 0, Math.PI * 2);
      ctx.fill();

      // Rotating spiral vortex rings
      for (let r = 0; r < 3; r++) {
        ctx.save();
        ctx.rotate(this.portalAngle * (r % 2 === 0 ? 1 : -1) + (r * Math.PI) / 3);
        ctx.strokeStyle = r === 0 ? '#38bdf8' : r === 1 ? '#c084fc' : '#e0e7ff';
        ctx.lineWidth = 3 - r * 0.5;
        ctx.setLineDash([12, 8, 4, 8]);
        ctx.beginPath();
        ctx.ellipse(0, 0, 28 - r * 6, 20 - r * 4, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Portal core
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(0, 0, 12 + Math.sin(this.portalAngle * 4) * 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Portal label
      ctx.fillStyle = '#1e1b4b';
      ctx.font = 'bold 11px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('EXIT', 0, 0);

      // Overhead active badge
      ctx.fillStyle = '#38bdf8';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.5;
      ctx.font = 'bold 11px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.strokeText('✨ PORTAL OPEN! ESCAPE!', 0, -36);
      ctx.fillText('✨ PORTAL OPEN! ESCAPE!', 0, -36);
    } else {
      // DORMANT LOCKED PORTAL WITH 3 CRYSTAL SOCKETS
      const pulse = Math.sin(this.portalAngle * 2) * 3;
      const glowRad = 42 + pulse;
      const grad = ctx.createRadialGradient(0, 0, 8, 0, 0, glowRad);
      grad.addColorStop(0, 'rgba(147, 51, 234, 0.45)');
      grad.addColorStop(0.6, 'rgba(239, 68, 68, 0.25)');
      grad.addColorStop(1, 'rgba(15, 23, 42, 0)');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, glowRad, 0, Math.PI * 2);
      ctx.fill();

      // Outer barrier ring with dashed security field
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.arc(0, 0, 26, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Portal stone core
      ctx.fillStyle = '#1e1b4b';
      ctx.strokeStyle = '#6b21a8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Padlock icon
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 14px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🔒', 0, 0);

      // Render the 3 Crystal Sockets around the portal ring
      const collectedCount = maze.crystals.filter((c) => c.collected).length;
      const socketAngles = [-Math.PI / 2, Math.PI / 6, (5 * Math.PI) / 6];

      maze.crystals.forEach((c, idx) => {
        const ang = socketAngles[idx] || (idx * Math.PI * 2) / 3;
        const sx = Math.cos(ang) * 36;
        const sy = Math.sin(ang) * 36;

        ctx.save();
        ctx.translate(sx, sy);
        if (c.collected) {
          // Socket filled with glowing collected crystal
          ctx.fillStyle = c.color;
          ctx.shadowColor = c.glowColor;
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        } else {
          // Empty socket slot waiting for crystal
          ctx.fillStyle = '#0f172a';
          ctx.strokeStyle = c.color;
          ctx.lineWidth = 1.5;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.arc(0, 0, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
        ctx.restore();
      });

      // Overhead text
      ctx.fillStyle = '#f87171';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.5;
      ctx.font = 'bold 11px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.strokeText(`🔒 LOCKED (${collectedCount}/3 CRYSTALS)`, 0, -42);
      ctx.fillText(`🔒 LOCKED (${collectedCount}/3 CRYSTALS)`, 0, -42);
    }

    ctx.restore();
  }

  private renderCrystals(crystals: Crystal[]) {
    const ctx = this.ctx;
    const time = Date.now() * 0.003;

    for (const crystal of crystals) {
      if (crystal.collected) continue;

      const px = crystal.x;
      const hoverY = crystal.y + Math.sin(time * 3 + px) * 4;

      ctx.save();
      ctx.translate(px, hoverY);

      // Soft ground shadow that scales with hover
      const shadowScale = 1 - Math.sin(time * 3 + px) * 0.15;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(0, 16 - (hoverY - crystal.y), 11 * shadowScale, 5 * shadowScale, 0, 0, Math.PI * 2);
      ctx.fill();

      // Glowing aura
      const auraGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, 24);
      auraGrad.addColorStop(0, crystal.glowColor);
      auraGrad.addColorStop(0.5, crystal.color + '66');
      auraGrad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 24, 0, Math.PI * 2);
      ctx.fill();

      // Shimmering star sparkle
      ctx.save();
      ctx.rotate(time * 2);
      ctx.strokeStyle = crystal.glowColor;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-10, 0);
      ctx.lineTo(10, 0);
      ctx.moveTo(0, -10);
      ctx.lineTo(0, 10);
      ctx.stroke();
      ctx.restore();

      // 3D Cartoon Crystal Diamond Facets
      ctx.fillStyle = crystal.glowColor;
      ctx.beginPath();
      ctx.moveTo(0, -14);
      ctx.lineTo(-9, -3);
      ctx.lineTo(0, 0);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(0, -14);
      ctx.lineTo(9, -3);
      ctx.lineTo(0, 0);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = crystal.color;
      ctx.beginPath();
      ctx.moveTo(-9, -3);
      ctx.lineTo(0, 12);
      ctx.lineTo(0, 0);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = crystal.color;
      ctx.beginPath();
      ctx.moveTo(9, -3);
      ctx.lineTo(0, 12);
      ctx.lineTo(0, 0);
      ctx.closePath();
      ctx.fill();

      // Dark facet outline
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, -14);
      ctx.lineTo(-9, -3);
      ctx.lineTo(0, 12);
      ctx.lineTo(9, -3);
      ctx.closePath();
      ctx.stroke();

      // Badge overhead: "💎 CRYSTAL"
      ctx.fillStyle = crystal.glowColor;
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.5;
      ctx.font = 'bold 10px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.strokeText(`💎 ${crystal.name.toUpperCase()}`, 0, -16);
      ctx.fillText(`💎 ${crystal.name.toUpperCase()}`, 0, -16);

      ctx.restore();
    }
  }

  // 2.5D Elevated Walls: Reveals top bevel, front wall height, depth cast shadows
  private renderWalls(
    maze: MazeData,
    minX: number,
    maxX: number,
    minY: number,
    maxY: number
  ) {
    const ctx = this.ctx;
    const wallHeight = 16; // 2.5D elevation height

    for (let gy = minY; gy <= maxY; gy++) {
      for (let gx = minX; gx <= maxX; gx++) {
        if (maze.tiles[gy][gx] === 1) {
          const px = gx * TILE_SIZE;
          const py = gy * TILE_SIZE;

          // Check if south neighbor is floor/corridor to render front 3D wall face
          const southIsFloor = gy < maze.height - 1 && maze.tiles[gy + 1][gx] !== 1;
          const eastIsFloor = gx < maze.width - 1 && maze.tiles[gy][gx + 1] !== 1;

          // Drop shadow cast onto floor below
          if (southIsFloor) {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
            ctx.fillRect(px, py + TILE_SIZE, TILE_SIZE, wallHeight * 0.7);
          }

          // Wall Front Face (if facing south)
          if (southIsFloor) {
            const frontGrad = ctx.createLinearGradient(px, py + TILE_SIZE - wallHeight, px, py + TILE_SIZE);
            frontGrad.addColorStop(0, '#334155');
            frontGrad.addColorStop(1, '#1e293b');
            ctx.fillStyle = frontGrad;
            ctx.fillRect(px, py + TILE_SIZE - wallHeight, TILE_SIZE, wallHeight);

            // Brick lines on front face
            ctx.strokeStyle = '#0f172a';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(px, py + TILE_SIZE - wallHeight / 2);
            ctx.lineTo(px + TILE_SIZE, py + TILE_SIZE - wallHeight / 2);
            ctx.moveTo(px + TILE_SIZE / 2, py + TILE_SIZE - wallHeight);
            ctx.lineTo(px + TILE_SIZE / 2, py + TILE_SIZE - wallHeight / 2);
            ctx.stroke();
          }

          // Wall Top Face (Elevated)
          const topGrad = ctx.createLinearGradient(px, py, px + TILE_SIZE, py + TILE_SIZE);
          topGrad.addColorStop(0, '#64748b');
          topGrad.addColorStop(1, '#475569');

          ctx.fillStyle = topGrad;
          ctx.fillRect(px, py, TILE_SIZE, southIsFloor ? TILE_SIZE - wallHeight : TILE_SIZE);

          // Top highlight bevel edge
          ctx.strokeStyle = '#94a3b8';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(px, py + (southIsFloor ? TILE_SIZE - wallHeight : TILE_SIZE));
          ctx.lineTo(px, py);
          ctx.lineTo(px + TILE_SIZE, py);
          ctx.stroke();

          // Dark corner shadow on inner edges
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(px + TILE_SIZE, py);
          ctx.lineTo(px + TILE_SIZE, py + (southIsFloor ? TILE_SIZE - wallHeight : TILE_SIZE));
          ctx.lineTo(px, py + (southIsFloor ? TILE_SIZE - wallHeight : TILE_SIZE));
          ctx.stroke();

          // East edge bevel if corridor to the east
          if (eastIsFloor) {
            ctx.fillStyle = 'rgba(0,0,0,0.2)';
            ctx.fillRect(px + TILE_SIZE - 3, py, 3, TILE_SIZE);
          }
        }
      }
    }
  }

  private renderClimbableWalls(climbableWalls: ClimbableWall[]) {
    const ctx = this.ctx;

    for (const cw of climbableWalls) {
      if (cw.isUsed) continue;

      const px = cw.gridX * TILE_SIZE;
      const py = cw.gridY * TILE_SIZE;

      ctx.save();
      // Glowing highlight around climbable wall to distinguish it clearly
      ctx.strokeStyle = 'rgba(234, 179, 8, 0.85)';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4);

      // Wooden ladder rungs painted on the wall
      ctx.fillStyle = '#b45309';
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([]);

      if (cw.direction === 'horizontal') {
        // Vertical ladder rungs across the horizontal wall
        ctx.fillRect(px + 12, py + 4, 5, TILE_SIZE - 8);
        ctx.fillRect(px + TILE_SIZE - 17, py + 4, 5, TILE_SIZE - 8);
        for (let ry = py + 8; ry < py + TILE_SIZE - 6; ry += 8) {
          ctx.fillRect(px + 12, ry, TILE_SIZE - 24, 3);
        }
      } else {
        // Horizontal ladder rungs across vertical wall
        ctx.fillRect(px + 4, py + 12, TILE_SIZE - 8, 5);
        ctx.fillRect(px + 4, py + TILE_SIZE - 17, TILE_SIZE - 8, 5);
        for (let rx = px + 8; rx < px + TILE_SIZE - 6; rx += 8) {
          ctx.fillRect(rx, py + 12, 3, TILE_SIZE - 24);
        }
      }

      // Small ladder icon badge above
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(px + TILE_SIZE / 2, py + TILE_SIZE / 2, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#451a03';
      ctx.font = 'bold 11px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🪜', px + TILE_SIZE / 2, py + TILE_SIZE / 2 + 1);

      ctx.restore();
    }
  }

  private renderHidingSpots(hidingSpots: HidingSpot[]) {
    const ctx = this.ctx;

    for (const spot of hidingSpots) {
      const px = spot.x;
      const py = spot.y;

      ctx.save();
      ctx.translate(px, py);

      // Subtle shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(0, 14, 18, 9, 0, 0, Math.PI * 2);
      ctx.fill();

      if (spot.type === 'bush') {
        // Cartoon Bush: fluffy green cluster
        ctx.fillStyle = '#15803d';
        ctx.beginPath();
        ctx.arc(-10, 0, 14, 0, Math.PI * 2);
        ctx.arc(10, 0, 14, 0, Math.PI * 2);
        ctx.arc(0, -8, 16, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(-8, -4, 11, 0, Math.PI * 2);
        ctx.arc(8, -4, 11, 0, Math.PI * 2);
        ctx.arc(0, -12, 12, 0, Math.PI * 2);
        ctx.fill();

        // Little berries
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(-6, 2, 2.5, 0, Math.PI * 2);
        ctx.arc(5, -6, 2.5, 0, Math.PI * 2);
        ctx.arc(8, 4, 2.5, 0, Math.PI * 2);
        ctx.fill();
      } else if (spot.type === 'crate') {
        // Large Wooden Crate
        ctx.fillStyle = '#92400e';
        ctx.fillRect(-16, -16, 32, 32);

        ctx.fillStyle = '#b45309';
        ctx.fillRect(-14, -14, 28, 28);

        // Cross braces
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 3;
        ctx.strokeRect(-13, -13, 26, 26);
        ctx.beginPath();
        ctx.moveTo(-13, -13);
        ctx.lineTo(13, 13);
        ctx.moveTo(13, -13);
        ctx.lineTo(-13, 13);
        ctx.stroke();
      } else if (spot.type === 'shelter') {
        // Small Storage Shelter
        ctx.fillStyle = '#475569';
        ctx.fillRect(-17, -10, 34, 26);

        // Tin roof slant
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.moveTo(-20, -10);
        ctx.lineTo(0, -22);
        ctx.lineTo(20, -10);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#991b1b';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Dark opening door
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-6, -2, 12, 18);
      } else {
        // Tall Metal Container
        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.roundRect(-15, -18, 30, 34, 6);
        ctx.fill();
        ctx.strokeStyle = '#0369a1';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Container ribs
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-11, -8);
        ctx.lineTo(11, -8);
        ctx.moveTo(-11, 2);
        ctx.lineTo(11, 2);
        ctx.moveTo(-11, 10);
        ctx.lineTo(11, 10);
        ctx.stroke();
      }

      // Feedback when occupied by player:
      // Real bushes: "safe bush" badge
      // Fake bushes: "FAKE BUSH! NO COVER!" warning
      if (spot.isOccupied) {
        if (!spot.isFake) {
          ctx.fillStyle = '#4ade80';
          ctx.strokeStyle = '#052e16';
          ctx.lineWidth = 2.5;
          ctx.font = 'bold 12px Fredoka, sans-serif';
          ctx.textAlign = 'center';
          ctx.shadowColor = '#166534';
          ctx.shadowBlur = 6;
          ctx.strokeText('🌿 SAFE BUSH (HIDDEN)', 0, -26);
          ctx.fillText('🌿 SAFE BUSH (HIDDEN)', 0, -26);
          ctx.shadowBlur = 0;
        } else {
          const pulse = 1 + Math.sin(Date.now() * 0.015) * 0.1;
          ctx.save();
          ctx.scale(pulse, pulse);
          ctx.fillStyle = '#f87171';
          ctx.strokeStyle = '#450a0a';
          ctx.lineWidth = 2.5;
          ctx.font = 'bold 12px Fredoka, sans-serif';
          ctx.textAlign = 'center';
          ctx.shadowColor = '#dc2626';
          ctx.shadowBlur = 8;
          ctx.strokeText('⚠️ FAKE BUSH! NO COVER!', 0, -26);
          ctx.fillText('⚠️ FAKE BUSH! NO COVER!', 0, -26);
          ctx.restore();
        }
      }

      ctx.restore();
    }
  }

  private renderPlayerPath(player: Player) {
    const ctx = this.ctx;
    ctx.save();
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.lineWidth = 3;
    ctx.setLineDash([6, 6]);

    ctx.beginPath();
    ctx.moveTo(player.x, player.y);
    for (const pt of player.path) {
      ctx.lineTo(pt.x, pt.y);
    }
    ctx.stroke();

    // Target marker dot
    const dest = player.path[player.path.length - 1];
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(dest.x, dest.y, 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // Cartoon Player Character: Explorer with backpack, hat, bobbing run
  private renderPlayer(player: Player) {
    const ctx = this.ctx;
    const px = player.x;
    const py = player.y;

    const isMoving = Math.hypot(player.vx, player.vy) > 0.1 || player.path.length > 0;
    const bob = isMoving ? Math.sin(player.animTick * 12) * 2.5 : 0;
    const legSwing = isMoving ? Math.sin(player.animTick * 12) * 5 : 0;

    ctx.save();
    ctx.translate(px, py);

    // Drop shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, 11, 13, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Legs
    ctx.fillStyle = '#1e3a8a';
    // Left leg
    ctx.fillRect(-7, 4 - bob, 4, 8 + legSwing);
    // Right leg
    ctx.fillRect(3, 4 - bob, 4, 8 - legSwing);

    // Shoes
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-8, 11 - bob + Math.max(0, legSwing), 6, 3);
    ctx.fillRect(2, 11 - bob + Math.max(0, -legSwing), 6, 3);

    // Backpack
    ctx.fillStyle = '#b45309';
    ctx.beginPath();
    ctx.roundRect(-10, -8 - bob, 20, 13, 3);
    ctx.fill();

    // Explorer Jacket / Torso
    ctx.fillStyle = '#0284c7';
    ctx.beginPath();
    ctx.roundRect(-8, -9 - bob, 16, 15, 4);
    ctx.fill();

    // Belt
    ctx.fillStyle = '#451a03';
    ctx.fillRect(-8, 2 - bob, 16, 3);
    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(-2, 2 - bob, 4, 3);

    // Head
    ctx.fillStyle = '#fed7aa'; // Skin tone
    ctx.beginPath();
    ctx.arc(0, -14 - bob, 8, 0, Math.PI * 2);
    ctx.fill();

    // Eyes
    ctx.fillStyle = '#0f172a';
    let eyeOffsetX = 0;
    if (player.facing === 'left') eyeOffsetX = -3;
    if (player.facing === 'right') eyeOffsetX = 3;

    ctx.beginPath();
    ctx.arc(-2.5 + eyeOffsetX, -15 - bob, 1.8, 0, Math.PI * 2);
    ctx.arc(2.5 + eyeOffsetX, -15 - bob, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // Explorer Cap / Hat
    ctx.fillStyle = '#ea580c';
    ctx.beginPath();
    ctx.ellipse(eyeOffsetX * 0.5, -20 - bob, 11, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#c2410c';
    ctx.beginPath();
    ctx.arc(eyeOffsetX * 0.5, -21 - bob, 7, Math.PI, 0);
    ctx.fill();

    // Visor of cap
    ctx.fillStyle = '#ea580c';
    ctx.beginPath();
    const visorDir = player.facing === 'left' ? -6 : player.facing === 'right' ? 6 : 0;
    ctx.roundRect(visorDir - 4, -20 - bob, 8, 3, 1);
    ctx.fill();

    ctx.restore();
  }

  // Cartoon Chicken: strictly grounded on the corridor floor with running waddle, red comb & wattle
  private renderChicken(chicken: Chicken) {
    const ctx = this.ctx;
    const px = chicken.x;
    const py = chicken.y;

    const isMoving = Math.hypot(chicken.vx, chicken.vy) > 0.1 || chicken.path.length > 0;
    const isChasing = chicken.state === 'chase';
    // Gentle grounded waddle, never flying or floating off the floor
    const bob = isMoving ? Math.sin(chicken.animTick * 14) * 1.2 : 0;
    const wingFlap = isChasing
      ? Math.sin(chicken.animTick * 18) * 2.0
      : isMoving
      ? Math.sin(chicken.animTick * 10) * 1.2
      : 0;

    ctx.save();
    ctx.translate(px, py);

    // Drop shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, 11, 13, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Chicken feet (orange)
    ctx.fillStyle = '#f97316';
    const footSwing = isMoving ? Math.sin(chicken.animTick * 16) * 4 : 0;
    ctx.fillRect(-6, 7 + footSwing, 3, 5);
    ctx.fillRect(3, 7 - footSwing, 3, 5);

    // Chicken body color: 0: White/Cream, 1: Golden Yellow, 2: Mottled Brown
    let bodyColor = '#fef08a';
    let wingColor = '#fde047';
    if (chicken.colorVariant === 1) {
      bodyColor = '#fef9c3';
      wingColor = '#fef08a';
    } else if (chicken.colorVariant === 2) {
      bodyColor = '#fed7aa';
      wingColor = '#fdba74';
    }

    // Wings
    ctx.fillStyle = wingColor;
    ctx.beginPath();
    ctx.ellipse(-11, -2 - bob + wingFlap, 5, 8, -0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(11, -2 - bob - wingFlap, 5, 8, 0.3, 0, Math.PI * 2);
    ctx.fill();

    // Main plump body
    ctx.fillStyle = bodyColor;
    ctx.beginPath();
    ctx.ellipse(0, -2 - bob, 11, 11, 0, 0, Math.PI * 2);
    ctx.fill();

    // Chicken Head
    const headX = chicken.facing === 'left' ? -5 : chicken.facing === 'right' ? 5 : 0;
    const headY = -14 - bob;
    ctx.beginPath();
    ctx.arc(headX, headY, 7.5, 0, Math.PI * 2);
    ctx.fill();

    // Red Comb on head
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.arc(headX - 3, headY - 8, 3, 0, Math.PI * 2);
    ctx.arc(headX, headY - 9, 3.5, 0, Math.PI * 2);
    ctx.arc(headX + 3, headY - 8, 3, 0, Math.PI * 2);
    ctx.fill();

    // Red Wattle below beak
    ctx.beginPath();
    ctx.ellipse(headX + (chicken.facing === 'left' ? -4 : chicken.facing === 'right' ? 4 : 0), headY + 5, 2.5, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Yellow/Orange Beak
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    if (chicken.facing === 'left') {
      ctx.moveTo(headX - 6, headY - 2);
      ctx.lineTo(headX - 12, headY);
      ctx.lineTo(headX - 6, headY + 3);
    } else if (chicken.facing === 'right') {
      ctx.moveTo(headX + 6, headY - 2);
      ctx.lineTo(headX + 12, headY);
      ctx.lineTo(headX + 6, headY + 3);
    } else {
      ctx.moveTo(headX - 3, headY + 1);
      ctx.lineTo(headX, headY + 5);
      ctx.lineTo(headX + 3, headY + 1);
    }
    ctx.closePath();
    ctx.fill();

    // Eyes: If chasing, glowing angry red; otherwise cartoon black dots
    if (isChasing) {
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(headX - 2.5, headY - 2, 2.5, 0, Math.PI * 2);
      ctx.arc(headX + 2.5, headY - 2, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(headX - 2, headY - 2, 1, 0, Math.PI * 2);
      ctx.arc(headX + 3, headY - 2, 1, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(headX - 2.5, headY - 2, 1.8, 0, Math.PI * 2);
      ctx.arc(headX + 2.5, headY - 2, 1.8, 0, Math.PI * 2);
      ctx.fill();
    }

    // Overhead Alert Bubble: ! for chase, ? for investigate/confused
    if (chicken.state === 'chase') {
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(0, -32 - bob, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('!', 0, -31 - bob);
    } else if (chicken.state === 'investigate' || chicken.state === 'confused') {
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(0, -32 - bob, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 13px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('?', 0, -31 - bob);
    }

    // Squawk text bubble if active (e.g. "BAWK!", "SQUAWK!")
    if (chicken.squawkBubble && chicken.squawkTimer > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(-24, -54 - bob, 48, 18, 4);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#dc2626';
      ctx.font = 'bold 10px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(chicken.squawkBubble, 0, -45 - bob);
    }

    ctx.restore();
  }

  // 5-second countdown progress ring over player when placing ladder
  private renderLadderProgress(player: Player) {
    const ctx = this.ctx;
    const px = player.x;
    const py = player.y - 32;

    const remaining = Math.max(0, player.ladderTimeRemaining);
    const progress = (5.0 - remaining) / 5.0;

    ctx.save();
    ctx.translate(px, py);

    // Circular background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Progress arc
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.arc(0, 0, 18, -Math.PI / 2, -Math.PI / 2 + progress * Math.PI * 2);
    ctx.stroke();

    // Text countdown: 5, 4, 3, 2, 1s
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${remaining.toFixed(1)}s`, 0, 1);

    // Hammering label
    ctx.fillStyle = '#fde047';
    ctx.font = 'bold 10px Fredoka, sans-serif';
    ctx.fillText('PLACING LADDER...', 0, -24);

    ctx.restore();
  }

  private renderParticles(particles: Particle[]) {
    const ctx = this.ctx;

    for (const p of particles) {
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;

      if (p.type === 'feather') {
        ctx.translate(p.x, p.y);
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size * 0.4, p.life * 5, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.type === 'sparkle' || p.type === 'portal') {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Dust or wood
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  // Intense red chase vignette that pulses at the edge of the 16:9 screen
  private renderChaseVignette(distToChicken: number) {
    const ctx = this.ctx;
    const cw = this.canvasWidth;
    const ch = this.canvasHeight;

    const intensity = Math.max(0.2, Math.min(0.65, 1 - distToChicken / 400));
    const pulse = 0.85 + Math.sin(Date.now() * 0.008) * 0.15;

    const grad = ctx.createRadialGradient(
      cw / 2,
      ch / 2,
      Math.min(cw, ch) * 0.35,
      cw / 2,
      ch / 2,
      Math.max(cw, ch) * 0.75
    );
    grad.addColorStop(0, 'rgba(239, 68, 68, 0)');
    grad.addColorStop(0.7, `rgba(220, 38, 38, ${0.15 * intensity * pulse})`);
    grad.addColorStop(1, `rgba(185, 28, 28, ${0.55 * intensity * pulse})`);

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, cw, ch);
  }
}
