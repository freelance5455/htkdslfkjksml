import * as THREE from 'three';
import { WEAPONS, type WeaponId } from './weapons';

export interface Outfit {
  shirt: number;
  pants: number;
  skin: number;
  helmet: number;
  vest: number;
}

/** Builds a gun whose grip sits at the origin and whose barrel points down -Z. */
export function buildGun(id: WeaponId): { group: THREE.Group; muzzle: THREE.Object3D } {
  const def = WEAPONS[id];
  const L = def.len;
  const group = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x17191c, roughness: 0.5, metalness: 0.6 });
  const body = new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.42, metalness: 0.55 });
  const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, rx = 0) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.rotation.x = rx;
    m.castShadow = true;
    group.add(m);
    return m;
  };

  const bodyW = id === 'shotgun' ? 0.075 : 0.06;
  add(new THREE.BoxGeometry(bodyW, 0.11, L * 0.65), body, 0, 0.03, -L * 0.42);
  add(new THREE.CylinderGeometry(0.016, 0.016, L * 0.3, 8), dark, 0, 0.03, -L * 0.9, Math.PI / 2);
  add(new THREE.BoxGeometry(0.045, 0.14, 0.06), dark, 0, -0.09, -0.02);

  if (id !== 'pistol') {
    add(new THREE.BoxGeometry(0.05, 0.1, L * 0.3), dark, 0, 0.01, L * 0.12);
  }
  if (id === 'smg' || id === 'ar') {
    add(new THREE.BoxGeometry(0.05, 0.17, 0.07), dark, 0, -0.12, -0.2);
  }
  if (id === 'sniper') {
    add(new THREE.CylinderGeometry(0.035, 0.035, 0.3, 10), dark, 0, 0.11, -L * 0.45, Math.PI / 2);
  }
  if (id === 'shotgun') {
    add(new THREE.BoxGeometry(0.07, 0.05, 0.22), dark, 0, -0.05, -L * 0.62);
  }

  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0.03, -L * 1.02);
  group.add(muzzle);
  return { group, muzzle };
}

export class Humanoid {
  readonly root = new THREE.Group();
  private legL = new THREE.Group();
  private legR = new THREE.Group();
  private armL = new THREE.Group();
  private armR = new THREE.Group();
  private head = new THREE.Group();
  private holder = new THREE.Group();
  private vest: THREE.Mesh;
  private chute = new THREE.Group();
  private gun: THREE.Group | null = null;
  private muzzle: THREE.Object3D | null = null;
  private weaponId: WeaponId | null = null;
  private phase = 0;
  private aim = 0;
  private recoil = 0;
  private dyingT = 0;
  private dying = false;

  constructor(o: Outfit) {
    this.root.rotation.order = 'YXZ';
    const mat = (c: number, r = 0.8, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
    const shirt = mat(o.shirt);
    const pants = mat(o.pants);
    const skin = mat(o.skin, 0.6);
    const boots = mat(0x15171a, 0.7);
    const helmetM = mat(o.helmet, 0.5, 0.15);
    const vestM = mat(o.vest, 0.9);

    const part = (parent: THREE.Object3D, geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number) => {
      const mesh = new THREE.Mesh(geo, m);
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      parent.add(mesh);
      return mesh;
    };

    // Legs (pivot at hip)
    this.legL.position.set(-0.12, 0.9, 0);
    this.legR.position.set(0.12, 0.9, 0);
    for (const leg of [this.legL, this.legR]) {
      part(leg, new THREE.BoxGeometry(0.17, 0.84, 0.18), pants, 0, -0.42, 0);
      part(leg, new THREE.BoxGeometry(0.18, 0.1, 0.25), boots, 0, -0.86, -0.03);
      this.root.add(leg);
    }

    // Torso
    part(this.root, new THREE.BoxGeometry(0.22, 0.2, 0.2), pants, 0, 0.98, 0);
    part(this.root, new THREE.BoxGeometry(0.44, 0.6, 0.26), shirt, 0, 1.27, 0);
    this.vest = part(this.root, new THREE.BoxGeometry(0.48, 0.42, 0.3), vestM, 0, 1.32, 0);
    this.vest.visible = false;

    // Head + helmet
    this.head.position.set(0, 1.7, 0);
    part(this.head, new THREE.SphereGeometry(0.135, 18, 14), skin, 0, 0, 0);
    part(this.head, new THREE.SphereGeometry(0.15, 18, 10, 0, Math.PI * 2, 0, Math.PI * 0.5), helmetM, 0, 0.02, 0);
    this.root.add(this.head);

    // Arms (pivot at shoulder)
    this.armL.position.set(-0.31, 1.55, 0);
    this.armR.position.set(0.31, 1.55, 0);
    for (const arm of [this.armL, this.armR]) {
      part(arm, new THREE.BoxGeometry(0.15, 0.6, 0.15), shirt, 0, -0.3, 0);
      part(arm, new THREE.SphereGeometry(0.07, 10, 8), skin, 0, -0.63, 0);
      this.root.add(arm);
    }
    this.holder.position.set(0, -0.62, 0);
    this.armR.add(this.holder);

    // Parachute canopy (only visible during the drop)
    const canopy = new THREE.Mesh(
      new THREE.SphereGeometry(1.8, 22, 12, 0, Math.PI * 2, 0, Math.PI * 0.5),
      new THREE.MeshStandardMaterial({ color: 0xff7a1a, roughness: 0.7, side: THREE.DoubleSide }),
    );
    canopy.position.set(0, 4.2, 0);
    canopy.castShadow = true;
    this.chute.add(canopy);
    this.chute.visible = false;
    this.root.add(this.chute);
  }

  setWeapon(id: WeaponId | null) {
    if (id === this.weaponId) return;
    if (this.gun) this.holder.remove(this.gun);
    this.gun = null;
    this.muzzle = null;
    this.weaponId = id;
    if (id) {
      const g = buildGun(id);
      this.gun = g.group;
      this.muzzle = g.muzzle;
      this.holder.add(this.gun);
    }
  }

  setArmor(on: boolean) {
    this.vest.visible = on;
  }

  setChute(on: boolean) {
    this.chute.visible = on;
  }

  kick(amount: number) {
    this.recoil = Math.max(this.recoil, amount);
  }

  muzzleWorld(out: THREE.Vector3): THREE.Vector3 {
    if (this.muzzle) this.muzzle.getWorldPosition(out);
    else out.set(0, 1.4, 0).applyMatrix4(this.root.matrixWorld);
    return out;
  }

  die() {
    this.dying = true;
  }

  /**
   * @param speed01 0 = idle, 1 = full sprint
   * @param aiming  aim-down-sights pose
   * @param pitch   vertical look angle (radians, up is positive)
   */
  update(dt: number, speed01: number, aiming: boolean, pitch: number) {
    if (this.dying) {
      this.dyingT = Math.min(1, this.dyingT + dt * 2.2);
      this.root.rotation.x = (this.dyingT * Math.PI) / 2;
      return;
    }
    this.phase += dt * (3 + speed01 * 9);
    const sw = Math.sin(this.phase) * 0.75 * Math.min(1, speed01 * 1.3);
    this.legL.rotation.x = sw;
    this.legR.rotation.x = -sw;

    this.aim += ((aiming ? 1 : 0) - this.aim) * Math.min(1, dt * 12);
    this.recoil *= Math.exp(-dt * 14);

    const armed = this.weaponId !== null;
    const aimAngle = 1.5 + Math.max(-0.9, Math.min(1, pitch));
    if (armed) {
      const hip = 0.4;
      this.armR.rotation.x = hip + (aimAngle - hip) * this.aim - this.recoil * 0.25;
      this.armL.rotation.x = hip + (aimAngle - hip) * this.aim;
      this.armL.rotation.z = 0.14 * this.aim;
      this.armR.rotation.z = -0.05 * this.aim;
    } else {
      this.armR.rotation.x = -sw * 0.6;
      this.armL.rotation.x = sw * 0.6;
      this.armL.rotation.z = 0.02;
      this.armR.rotation.z = -0.02;
    }
  }
}
