import * as THREE from "three";
import type { Quality } from "./types";
import { glowTexture } from "./textures";

interface Spark {
  vel: THREE.Vector3;
  life: number;
  max: number;
}

interface RingFx {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  life: number;
  max: number;
  from: number;
  to: number;
}

interface SpriteFx {
  sprite: THREE.Sprite;
  mat: THREE.SpriteMaterial;
  life: number;
  max: number;
  from: number;
  to: number;
  vel: THREE.Vector3;
}

export class Vfx {
  private scene: THREE.Scene;
  private sparkCount: number;
  private sparkGeo: THREE.BufferGeometry;
  private sparkPos: Float32Array;
  private sparkCol: Float32Array;
  private sparks: Spark[] = [];
  private sparkPoints: THREE.Points;
  private sparkMat: THREE.PointsMaterial;
  private rings: RingFx[] = [];
  private flashes: SpriteFx[] = [];
  private trails: SpriteFx[] = [];
  private glow = glowTexture();
  private ringGeo = new THREE.RingGeometry(0.82, 1, 40);
  private arcGeo = new THREE.RingGeometry(0.55, 1.35, 20, 1, -0.2, Math.PI * 0.95);

  constructor(scene: THREE.Scene, quality: Quality) {
    this.scene = scene;
    this.sparkCount = quality === "low" ? 90 : quality === "medium" ? 170 : 260;
    this.sparkGeo = new THREE.BufferGeometry();
    this.sparkPos = new Float32Array(this.sparkCount * 3);
    this.sparkCol = new Float32Array(this.sparkCount * 3);
    for (let i = 0; i < this.sparkCount; i++) {
      this.sparkPos[i * 3 + 1] = -100;
      this.sparks.push({ vel: new THREE.Vector3(), life: 0, max: 1 });
    }
    this.sparkGeo.setAttribute("position", new THREE.BufferAttribute(this.sparkPos, 3));
    this.sparkGeo.setAttribute("color", new THREE.BufferAttribute(this.sparkCol, 3));
    this.sparkMat = new THREE.PointsMaterial({
      size: quality === "low" ? 0.09 : 0.075,
      vertexColors: true,
      transparent: true,
      opacity: 1,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
      toneMapped: false,
    });
    this.sparkPoints = new THREE.Points(this.sparkGeo, this.sparkMat);
    this.sparkPoints.frustumCulled = false;
    scene.add(this.sparkPoints);

    const ringCount = quality === "low" ? 5 : 9;
    for (let i = 0; i < ringCount; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
        toneMapped: false,
      });
      const mesh = new THREE.Mesh(this.ringGeo, mat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.visible = false;
      scene.add(mesh);
      this.rings.push({ mesh, mat, life: 0, max: 1, from: 0.4, to: 3 });
    }
    const spriteCount = quality === "low" ? 6 : 12;
    for (let i = 0; i < spriteCount; i++) {
      const mat = new THREE.SpriteMaterial({
        map: this.glow,
        color: 0xffffff,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      });
      const sprite = new THREE.Sprite(mat);
      sprite.visible = false;
      scene.add(sprite);
      this.flashes.push({ sprite, mat, life: 0, max: 1, from: 1, to: 2, vel: new THREE.Vector3() });
    }
    const trailCount = quality === "low" ? 26 : 54;
    for (let i = 0; i < trailCount; i++) {
      const mat = new THREE.SpriteMaterial({
        map: this.glow,
        color: 0xffffff,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      });
      const sprite = new THREE.Sprite(mat);
      sprite.visible = false;
      scene.add(sprite);
      this.trails.push({ sprite, mat, life: 0, max: 0.24, from: 0.3, to: 0.02, vel: new THREE.Vector3() });
    }
  }

  private freeSpark(): number {
    for (let i = 0; i < this.sparks.length; i++) if (this.sparks[i].life <= 0) return i;
    return Math.floor(Math.random() * this.sparks.length);
  }

  sparksBurst(pos: THREE.Vector3, color: number, count = 16, power = 1) {
    const c = new THREE.Color(color);
    for (let n = 0; n < count; n++) {
      const i = this.freeSpark();
      const s = this.sparks[i];
      s.life = 0.28 + Math.random() * 0.4;
      s.max = s.life;
      const dir = new THREE.Vector3(
        Math.random() - 0.5,
        Math.random() * 0.9 + 0.1,
        Math.random() - 0.5
      ).normalize();
      s.vel.copy(dir).multiplyScalar((1.6 + Math.random() * 3.4) * power);
      this.sparkPos[i * 3] = pos.x + (Math.random() - 0.5) * 0.16;
      this.sparkPos[i * 3 + 1] = pos.y + (Math.random() - 0.5) * 0.16;
      this.sparkPos[i * 3 + 2] = pos.z + (Math.random() - 0.5) * 0.16;
      this.sparkCol[i * 3] = c.r;
      this.sparkCol[i * 3 + 1] = c.g;
      this.sparkCol[i * 3 + 2] = c.b;
    }
    (this.sparkGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.sparkGeo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }

  ring(pos: THREE.Vector3, color: number, to = 3.2, life = 0.55, y = 0.06) {
    const fx = this.rings.find((r) => r.life <= 0) ?? this.rings[0];
    fx.life = life;
    fx.max = life;
    fx.from = 0.35;
    fx.to = to;
    fx.mat.color.setHex(color);
    fx.mat.opacity = 0.85;
    fx.mesh.position.set(pos.x, y, pos.z);
    fx.mesh.scale.setScalar(0.35);
    fx.mesh.visible = true;
  }

  flash(pos: THREE.Vector3, color: number, size = 1.6, life = 0.2) {
    const fx = this.flashes.find((f) => f.life <= 0) ?? this.flashes[0];
    fx.life = life;
    fx.max = life;
    fx.from = size * 0.5;
    fx.to = size;
    fx.mat.color.setHex(color);
    fx.mat.opacity = 0.95;
    fx.sprite.position.copy(pos);
    fx.sprite.scale.setScalar(size * 0.5);
    fx.sprite.visible = true;
  }

  slash(pos: THREE.Vector3, color: number, heavy = false, camera?: THREE.Camera) {
    const fx = this.flashes.find((f) => f.life <= 0) ?? this.flashes[0];
    fx.life = heavy ? 0.26 : 0.18;
    fx.max = fx.life;
    fx.from = heavy ? 1.4 : 0.9;
    fx.to = heavy ? 2.6 : 1.7;
    fx.mat.color.setHex(color);
    fx.mat.opacity = 0.8;
    fx.sprite.position.copy(pos);
    fx.sprite.scale.setScalar(fx.from);
    fx.sprite.visible = true;
    if (camera) {
      // crescent slash oriented toward the camera for readability
      const mat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
        toneMapped: false,
      });
      const mesh = new THREE.Mesh(this.arcGeo, mat);
      mesh.position.copy(pos);
      mesh.quaternion.copy(camera.quaternion);
      mesh.rotateZ(Math.random() * Math.PI * 2);
      mesh.scale.setScalar(heavy ? 1.5 : 1);
      this.scene.add(mesh);
      const start = performance.now();
      const tick = () => {
        const t = (performance.now() - start) / (heavy ? 260 : 180);
        if (t >= 1) {
          this.scene.remove(mesh);
          mat.dispose();
          return;
        }
        mat.opacity = 0.85 * (1 - t);
        mesh.scale.setScalar((heavy ? 1.5 : 1) * (1 + t * 0.7));
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }
  }

  trail(pos: THREE.Vector3, color: number) {
    const fx = this.trails.find((f) => f.life <= 0);
    if (!fx) return;
    fx.life = fx.max;
    fx.mat.color.setHex(color);
    fx.mat.opacity = 0.5;
    fx.sprite.position.copy(pos);
    fx.sprite.scale.setScalar(fx.from);
    fx.sprite.visible = true;
  }

  update(dt: number) {
    let dirty = false;
    for (let i = 0; i < this.sparks.length; i++) {
      const s = this.sparks[i];
      if (s.life <= 0) continue;
      s.life -= dt;
      dirty = true;
      if (s.life <= 0) {
        this.sparkPos[i * 3 + 1] = -100;
        this.sparkCol[i * 3] = 0;
        this.sparkCol[i * 3 + 1] = 0;
        this.sparkCol[i * 3 + 2] = 0;
        continue;
      }
      s.vel.y -= 9.5 * dt;
      this.sparkPos[i * 3] += s.vel.x * dt;
      this.sparkPos[i * 3 + 1] += s.vel.y * dt;
      this.sparkPos[i * 3 + 2] += s.vel.z * dt;
      const k = Math.max(0, s.life / s.max);
      this.sparkCol[i * 3] *= 0.965;
      this.sparkCol[i * 3 + 1] *= 0.965;
      this.sparkCol[i * 3 + 2] *= 0.965;
      if (k < 0.2) {
        this.sparkCol[i * 3] *= 0.9;
        this.sparkCol[i * 3 + 1] *= 0.9;
        this.sparkCol[i * 3 + 2] *= 0.9;
      }
    }
    if (dirty) {
      (this.sparkGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      (this.sparkGeo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    }
    for (const r of this.rings) {
      if (r.life <= 0) continue;
      r.life -= dt;
      const t = 1 - Math.max(0, r.life) / r.max;
      const s = r.from + (r.to - r.from) * (1 - Math.pow(1 - t, 2));
      r.mesh.scale.setScalar(s);
      r.mat.opacity = 0.85 * (1 - t);
      if (r.life <= 0) r.mesh.visible = false;
    }
    for (const f of this.flashes) {
      if (f.life <= 0) continue;
      f.life -= dt;
      const t = 1 - Math.max(0, f.life) / f.max;
      f.sprite.scale.setScalar(f.from + (f.to - f.from) * t);
      f.mat.opacity = 0.95 * (1 - t);
      if (f.life <= 0) f.sprite.visible = false;
    }
    for (const f of this.trails) {
      if (f.life <= 0) continue;
      f.life -= dt;
      const t = 1 - Math.max(0, f.life) / f.max;
      f.mat.opacity = 0.5 * (1 - t);
      f.sprite.scale.setScalar(f.from * (1 - t * 0.7));
      if (f.life <= 0) f.sprite.visible = false;
    }
  }

  dispose() {
    this.scene.remove(this.sparkPoints);
    this.sparkGeo.dispose();
    this.sparkMat.dispose();
    this.rings.forEach((r) => {
      this.scene.remove(r.mesh);
      r.mat.dispose();
    });
    this.flashes.forEach((f) => {
      this.scene.remove(f.sprite);
      f.mat.dispose();
    });
    this.trails.forEach((f) => {
      this.scene.remove(f.sprite);
      f.mat.dispose();
    });
    this.ringGeo.dispose();
    this.arcGeo.dispose();
  }
}
