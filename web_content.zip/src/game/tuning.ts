import { CONFIG, DEFAULT_CONFIG } from './config'

/**
 * Tweak bridge: the controls below are the flight values a designer may adjust live in Preview.
 * Source defaults stay immutable; Apply only changes the active CONFIG for this session.
 */
type Mode = 'LIVE' | 'NEXT_RUN'
type Boundary = 'run'
type Control = {
  id: string; type: 'number'; category: string; label: string; description: string; unit: string
  default: number; min: number; max: number; step: number; applyMode: Mode; integrity: 'COSMETIC' | 'GAMEPLAY'
}
type Binding = { control: Control; boundary?: Boundary; read(): number; write(value: number): void }

const CATEGORY: Record<string, string> = { flight: 'Vuelo', camera: 'Cámara', rings: 'Anillos' }
const bindings: Binding[] = []

function number<S extends 'flight' | 'camera' | 'rings'>(
  section: S, key: keyof typeof CONFIG[S] & string,
  label: string, min: number, max: number, step: number, unit: string, boundary?: Boundary,
): void {
  const values = CONFIG[section] as Record<string, number>
  const defaults = DEFAULT_CONFIG[section] as Record<string, number>
  bindings.push({
    control: Object.freeze({
      id: `${section}.${key}`, type: 'number', category: CATEGORY[section], label,
      description: boundary === 'run' ? 'Se aplica al empezar un nuevo vuelo.' : 'Se actualiza en la vista previa al instante.',
      unit, default: defaults[key], min, max, step,
      applyMode: boundary === 'run' ? 'NEXT_RUN' : 'LIVE',
      integrity: section === 'camera' ? 'COSMETIC' : 'GAMEPLAY',
    }),
    boundary,
    read: () => values[key],
    write: value => { values[key] = value },
  })
}

number('flight', 'minSpeed', 'Velocidad mínima (acelerador 0)', 34, 80, 1, 'm/s')
number('flight', 'maxSpeed', 'Velocidad máxima (acelerador 100)', 90, 190, 1, 'm/s')
number('flight', 'pitchRate', 'Velocidad de cabeceo', 0.5, 2, 0.05, 'rad/s')
number('flight', 'rollRate', 'Velocidad de alabeo', 1, 4, 0.1, 'rad/s')
number('flight', 'turnRate', 'Viraje por inclinación', 0.3, 1.6, 0.05, 'rad/s')
number('flight', 'levelling', 'Autonivelación', 0, 4, 0.1, '1/s')
number('camera', 'fov', 'Campo de visión', 45, 95, 1, '°')
number('camera', 'distance', 'Distancia de cámara', 14, 50, 1, 'm')
number('camera', 'height', 'Altura de cámara', 2, 18, 0.5, 'm')
number('camera', 'follow', 'Suavidad de seguimiento', 2, 14, 0.5, '')
number('rings', 'spacing', 'Separación entre anillos', 350, 900, 10, 'm', 'run')

const byId = new Map(bindings.map(binding => [binding.control.id, binding]))
let requested = Object.fromEntries(bindings.map(({ control }) => [control.id, control.default]))
const valid = (values: Record<string, number>) => values['flight.minSpeed'] < values['flight.maxSpeed']
let unranked = false
const gameplayModified = () => bindings.some(binding => binding.control.integrity === 'GAMEPLAY' && binding.read() !== binding.control.default)

export const tuning = {
  get unranked(): boolean { return unranked },
  controls: Object.freeze(bindings.map(binding => binding.control)),
  read() {
    return { requested: { ...requested }, active: Object.fromEntries(bindings.map(binding => [binding.control.id, binding.read()])) }
  },
  apply(patch: unknown): void {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('Invalid patch')
    const entries = Object.entries(patch)
    if (entries.length > bindings.length) throw new Error('Invalid patch')
    for (const [id, value] of entries) {
      const control = byId.get(id)?.control
      if (!control || typeof value !== 'number' || !Number.isFinite(value) || value < control.min || value > control.max) throw new Error('Invalid value')
      const steps = (value - control.min) / control.step
      if (value !== control.default && Math.abs(steps - Math.round(steps)) > 1e-7) throw new Error('Invalid increment')
    }
    const candidate = { ...requested, ...patch } as Record<string, number>
    const nextActive = this.read().active
    for (const [id, value] of entries) if (byId.get(id)!.control.applyMode === 'LIVE') nextActive[id] = value
    if (!valid(candidate) || !valid(nextActive)) throw new Error('La velocidad mínima debe ser menor que la máxima')
    // All writes are simple assignments, synchronously committed before the next
    // physics/render callback. No engine callbacks run during this transaction.
    requested = candidate
    for (const [id, value] of entries) {
      const binding = byId.get(id)!
      if (binding.control.applyMode === 'LIVE') binding.write(value)
    }
    unranked ||= gameplayModified()
  },
  activate(boundary: Boundary): void {
    for (const binding of bindings) if (binding.boundary === boundary) binding.write(requested[binding.control.id])
    // Reset only at a new run; resetting values mid-run cannot restore eligibility.
    unranked = boundary === 'run' ? gameplayModified() : unranked || gameplayModified()
  },
}
