import { Milestone } from '../types/game';

export const INITIAL_MILESTONES: Milestone[] = [
  {
    id: 'first_tree',
    titleAr: 'حطاب الغابة',
    descriptionAr: 'اقطع أول شجرة واجمع الخشب لبدء رحلة البقاء.',
    icon: 'tree',
    completed: false,
  },
  {
    id: 'first_tool',
    titleAr: 'صانع الأدوات',
    descriptionAr: 'اصنع أول أداة عمل يدوية (فأس أو معول).',
    icon: 'axe',
    completed: false,
  },
  {
    id: 'first_campfire',
    titleAr: 'دفء الليل',
    descriptionAr: 'ابنِ موقد نار لتأمين الدفء والضوء وطهي الطعام.',
    icon: 'flame',
    completed: false,
  },
  {
    id: 'first_night',
    titleAr: 'ناجي الليلة الأولى',
    descriptionAr: 'اصمد حتى شروق شمس اليوم الثاني.',
    icon: 'moon',
    completed: false,
  },
  {
    id: 'first_enemy',
    titleAr: 'شجاعة المحارب',
    descriptionAr: 'اهزم أول وحش يهاجمك في البرية.',
    icon: 'sword',
    completed: false,
  },
  {
    id: 'first_chest',
    titleAr: 'خازن المؤن',
    descriptionAr: 'اصنع صندوق تخزين لحفظ مواردك الثمينة.',
    icon: 'box',
    completed: false,
  },
  {
    id: 'survive_3_days',
    titleAr: 'المستكشف الصامد',
    descriptionAr: 'ابقَ على قيد الحياة لمدة 3 أيام متتالية.',
    icon: 'tent',
    completed: false,
  },
  {
    id: 'survive_7_days',
    titleAr: 'أسطورة البراري',
    descriptionAr: 'اصمد بنجاح لمدة 7 أيام وتغلب على قسوة الطبيعة.',
    icon: 'trophy',
    completed: false,
  },
];
