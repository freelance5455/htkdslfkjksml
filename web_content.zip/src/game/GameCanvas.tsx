import { useEffect, useMemo, useRef } from "react";
import { getSkin, type World } from "./data";
import { coinRewardFor, getLevel, scoreFor, starsFor, type LevelDef } from "./levels";
import { haptic, sfx, unlockAudio } from "./audio";

export type Hud = {
  score: number;
  combo: number;
  maxCombo: number;
  bounces: number;
  cleared: number;
  total: number;
  time: number;
  gems: number;
  depth: number;
  holding: boolean;
  started: boolean;
  finished: boolean;
};

export type EngineResult = {
  level: number;
  score: number;
  bounces: number;
  maxCombo: number;
  timeSeconds: number;
  stars: 1 | 2 | 3;
  gems: number;
  coins: number;
  layers: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  rot: number;
  vr: number;
  shard: boolean;
  gravity: number;
};

type FloatText = {
  x: number;
  y: number;
  vy: number;
  life: number;
  maxLife: number;
  text: string;
  color: string;
  size: number;
};

type Dust = { x: number; y: number; r: number; a: number; speed: number; phase: number };

type Engine = {
  level: LevelDef;
  current: number;
  camera: number;
  rotations: number[];
  holding: boolean;
  started: boolean;
  finished: boolean;
  finishTimer: number;
  resultSent: boolean;
  time: number;
  score: number;
  combo: number;
  maxCombo: number;
  bounces: number;
  gems: number;
  cooldown: number;
  bounceY: number;
  bounceVel: number;
  smashPulse: number;
  shake: number;
  particles: Particle[];
  texts: FloatText[];
  trail: { x: number; y: number; life: number; color: string }[];
  dust: Dust[];
  stars: Dust[];
  elapsed: number;
  lastHud: number;
};

type Size = { w: number; h: number; dpr: number };

const DEG = Math.PI / 180;

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace("#", "");
  const full = clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgba(hex: string, alpha: number) {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${alpha})`;
}

function mix(a: string, b: string, t: number) {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  const r = Math.round(r1 + (r2 - r1) * t);
  const g = Math.round(g1 + (g2 - g1) * t);
  const bl = Math.round(b1 + (b2 - b1) * t);
  return `rgb(${r},${g},${bl})`;
}

function makeEngine(level: LevelDef): Engine {
  return {
    level,
    current: 0,
    camera: 0,
    rotations: level.layers.map((l) => l.rot),
    holding: false,
    started: false,
    finished: false,
    finishTimer: 0,
    resultSent: false,
    time: 0,
    score: 0,
    combo: 0,
    maxCombo: 0,
    bounces: 0,
    gems: 0,
    cooldown: 0.1,
    bounceY: 0,
    bounceVel: 0,
    smashPulse: 0,
    shake: 0,
    particles: [],
    texts: [],
    trail: [],
    dust: Array.from({ length: 24 }, (_, i) => ({
      x: Math.random(),
      y: Math.random(),
      r: 1 + Math.random() * 3.4,
      a: 0.08 + Math.random() * 0.24,
      speed: 3 + Math.random() * 12,
      phase: i,
    })),
    stars: Array.from({ length: 52 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: 0.4 + Math.random() * 1.5,
      a: 0.1 + Math.random() * 0.5,
      speed: 0,
      phase: Math.random() * Math.PI * 2,
    })),
    elapsed: 0,
    lastHud: 0,
  };
}

type Props = {
  levelNumber: number;
  skinId: string;
  haptics: boolean;
  paused: boolean;
  daily?: boolean;
  onHud: (hud: Hud) => void;
  onFinish: (result: EngineResult) => void;
};

export default function GameCanvas({
  levelNumber,
  skinId,
  haptics,
  paused,
  daily = false,
  onHud,
  onFinish,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const sizeRef = useRef<Size>({ w: 0, h: 0, dpr: 1 });
  const level = useMemo(() => getLevel(levelNumber), [levelNumber]);
  const engineRef = useRef<Engine>(makeEngine(level));
  const pausedRef = useRef(paused);
  const hapticsRef = useRef(haptics);
  const skinRef = useRef(getSkin(skinId));
  const onHudRef = useRef(onHud);
  const onFinishRef = useRef(onFinish);
  const holdRef = useRef(false);
  const dailyRef = useRef(daily);

  onHudRef.current = onHud;
  onFinishRef.current = onFinish;
  hapticsRef.current = haptics;
  skinRef.current = getSkin(skinId);
  dailyRef.current = daily;
  pausedRef.current = paused;

  useEffect(() => {
    engineRef.current = makeEngine(level);
    holdRef.current = false;
  }, [level]);

  // keyboard press / release handlers
  useEffect(() => {
    const press = () => {
      if (pausedRef.current) return;
      unlockAudio();
      const e = engineRef.current;
      if (e.finished) return;
      holdRef.current = true;
      e.holding = true;
      e.started = true;
      if (e.current === 0 && e.time < 0.05) {
        sfx.click();
      }
    };
    const release = () => {
      holdRef.current = false;
      engineRef.current.holding = false;
    };
    const onKeyDown = (ev: KeyboardEvent) => {
      if (ev.code === "Space" || ev.code === "Enter" || ev.code === "ArrowDown") {
        if (
          ev.target instanceof HTMLElement &&
          ["INPUT", "TEXTAREA", "BUTTON", "SELECT"].includes(ev.target.tagName)
        ) {
          return;
        }
        ev.preventDefault();
        if (!ev.repeat) press();
      }
    };
    const onKeyUp = (ev: KeyboardEvent) => {
      if (ev.code === "Space" || ev.code === "Enter" || ev.code === "ArrowDown") {
        release();
      }
    };
    const onBlur = () => release();
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, []);

  // resize
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      sizeRef.current = { w: rect.width, h: rect.height, dpr };
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    window.addEventListener("orientationchange", resize);
    return () => {
      ro.disconnect();
      window.removeEventListener("orientationchange", resize);
    };
  }, []);

  // main loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const rawDt = (now - last) / 1000;
      last = now;
      const dt = Math.min(0.04, Math.max(0, rawDt));
      const e = engineRef.current;
      const size = sizeRef.current;

      if (!pausedRef.current) {
        update(e, dt, size, {
          haptics: hapticsRef.current,
          onFinish: (r) => onFinishRef.current(r),
        });
      }

      const hudTimer = now - e.lastHud;
      if (hudTimer > 100) {
        e.lastHud = now;
        onHudRef.current(buildHud(e));
      }

      draw(ctx, e, size, skinRef.current, dailyRef.current);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div
      ref={wrapRef}
      className="absolute inset-0 select-none"
      onPointerDown={(ev) => {
        if (pausedRef.current) return;
        ev.currentTarget.setPointerCapture?.(ev.pointerId);
        unlockAudio();
        const e = engineRef.current;
        if (e.finished) return;
        holdRef.current = true;
        e.holding = true;
        e.started = true;
        if (e.current === 0 && e.time < 0.05) sfx.click();
      }}
      onPointerUp={() => {
        holdRef.current = false;
        engineRef.current.holding = false;
      }}
      onPointerCancel={() => {
        holdRef.current = false;
        engineRef.current.holding = false;
      }}
      onPointerLeave={() => {
        if (!holdRef.current) return;
        holdRef.current = false;
        engineRef.current.holding = false;
      }}
      onContextMenu={(ev) => ev.preventDefault()}
    >
      <canvas ref={canvasRef} className="stage-canvas" aria-label="Stack Ball play field — hold to smash" />
    </div>
  );
}

function buildHud(e: Engine): Hud {
  return {
    score: e.score,
    combo: e.combo,
    maxCombo: e.maxCombo,
    bounces: e.bounces,
    cleared: e.current,
    total: e.level.layers.length,
    time: e.time,
    gems: e.gems,
    depth: e.level.layers.length ? (e.current / e.level.layers.length) * 100 : 0,
    holding: e.holding,
    started: e.started,
    finished: e.finished,
  };
}

function update(
  e: Engine,
  dt: number,
  size: Size,
  ctx: { haptics: boolean; onFinish: (r: EngineResult) => void },
) {
  e.elapsed += dt;
  if (!e.finished) {
    e.time = e.started ? e.time + dt : 0;
  }

  // spin the visible layers
  const total = e.level.layers.length;
  for (let i = e.current; i < Math.min(total, e.current + 11); i += 1) {
    const layer = e.level.layers[i];
    e.rotations[i] += layer.dir * layer.speed * dt;
  }

  e.camera += (e.current - e.camera) * Math.min(1, dt * 22);
  if (Math.abs(e.camera - e.current) < 0.002) e.camera = e.current;

  // bounce physics
  e.bounceVel += 2200 * dt;
  e.bounceY = Math.min(0, e.bounceY + e.bounceVel * dt);
  if (e.bounceY <= 0) {
    e.bounceY = 0;
    e.bounceVel = 0;
  }
  e.cooldown = Math.max(0, e.cooldown - dt);
  e.shake = Math.max(0, e.shake - dt * 26);
  e.smashPulse = Math.max(0, e.smashPulse - dt * 3.4);

  // particles
  for (const p of e.particles) {
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += p.gravity * dt;
    p.rot += p.vr * dt;
  }
  e.particles = e.particles.filter((p) => p.life > 0);
  for (const t of e.texts) {
    t.life -= dt;
    t.y += t.vy * dt;
    t.vy *= 0.97;
  }
  e.texts = e.texts.filter((t) => t.life > 0);
  for (const tr of e.trail) tr.life -= dt * 2.4;
  e.trail = e.trail.filter((t) => t.life > 0);

  if (e.finished) {
    e.finishTimer -= dt;
    if (e.finishTimer <= 0 && !e.resultSent) {
      e.resultSent = true;
      const stars = starsFor(e.bounces);
      const score = scoreFor({
        layers: total,
        maxCombo: e.maxCombo,
        bounces: e.bounces,
        timeSeconds: e.time,
        targetTime: e.level.targetTime,
        stars,
      }) + e.gems * 75;
      const coins = coinRewardFor(stars, e.level.number, e.bounces) + e.gems * 2;
      ctx.onFinish({
        level: e.level.number,
        score,
        bounces: e.bounces,
        maxCombo: e.maxCombo,
        timeSeconds: e.time,
        stars,
        gems: e.gems,
        coins,
        layers: total,
      });
    }
    return;
  }

  if (!e.holding || e.bounceY < -2 || e.cooldown > 0) return;
  if (e.current >= total) return;

  const layer = e.level.layers[e.current];
  const segments = layer.sectors.length;
  const segAngle = 360 / segments;
  const rot = ((e.rotations[e.current] % 360) + 360) % 360;
  const local = (90 - rot + 360) % 360;
  const idx = Math.min(segments - 1, Math.floor(local / segAngle));
  const kind = layer.sectors[idx];

  const cy = size.h ? size.h * 0.44 : 260;
  const baseR = Math.min((size.w || 380) * 0.335, (size.h || 560) * 0.25, 188);
  const ballR = Math.max(17, Math.min(31, baseR * 0.185));

  if (kind === "solid") {
    e.bounces += 1;
    e.combo = 0;
    e.cooldown = 0.17;
    e.bounceVel = -Math.max(440, (size.h || 560) * 0.72);
    e.bounceY = 0;
    e.shake = 9;
    e.texts.push({
      x: size.w / 2,
      y: cy - ballR * 2.2,
      vy: -42,
      life: 0.8,
      maxLife: 0.8,
      text: "BLOCKED",
      color: "#ff8496",
      size: 13,
    });
    spawnParticles(e, size.w / 2, cy + baseR * 0.3, "#ff758b", 12, 180, 120);
    sfx.bounce();
    haptic([16, 32, 16], ctx.haptics);
    return;
  }

  // successful smash
  const isGem = kind === "gem";
  e.combo += 1;
  e.bounceY = 0;
  e.maxCombo = Math.max(e.maxCombo, e.combo);
  const gain = 100 + Math.min(e.combo, 25) * 20 + (isGem ? 200 : 0);
  e.score += gain;
  e.current += 1;
  e.cooldown = 0.125;
  e.smashPulse = 1;
  e.shake = 2.6;
  if (isGem) {
    e.gems += 1;
    sfx.gem();
    haptic([10, 24, 10], ctx.haptics);
  } else {
    sfx.smash(e.combo);
    haptic(8, ctx.haptics);
  }

  const wedgeColor = isGem ? "#ffd76b" : e.combo % 5 === 0 ? e.level.world.accent2 : e.level.world.accent;
  spawnParticles(e, size.w / 2, cy + baseR * 0.26, wedgeColor, isGem ? 22 : 13, 260, 210);
  e.texts.push({
    x: size.w / 2 + (Math.random() - 0.5) * 26,
    y: cy - ballR * 1.6,
    vy: -78,
    life: 0.78,
    maxLife: 0.78,
    text: isGem ? `GEM +${gain}` : `+${gain}`,
    color: isGem ? "#ffe29a" : "#e9e6ff",
    size: isGem ? 16 : 14,
  });
  if (e.combo > 0 && e.combo % 10 === 0) {
    e.texts.push({
      x: size.w / 2,
      y: cy - ballR * 3.2,
      vy: -34,
      life: 1.15,
      maxLife: 1.15,
      text: `×${e.combo} HEAT`,
      color: "#ffbe5c",
      size: 20,
    });
    e.shake = 6;
  }

  if (e.current >= total) {
    e.finished = true;
    e.finishTimer = 1.05;
    e.holding = false;
    e.shake = 11;
    for (let i = 0; i < 60; i += 1) {
      spawnParticles(e, size.w / 2, cy, i % 3 === 0 ? "#38e8ff" : i % 3 === 1 ? "#ffd76b" : "#a78bfa", 1, 460, 380);
    }
    sfx.finish();
    haptic([30, 50, 30, 50, 80], ctx.haptics);
  }
}

function spawnParticles(
  e: Engine,
  x: number,
  y: number,
  color: string,
  count: number,
  spread: number,
  upward: number,
) {
  for (let i = 0; i < count; i += 1) {
    const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.9;
    const speed = upward * (0.35 + Math.random() * 0.9);
    const life = 0.4 + Math.random() * 0.6;
    e.particles.push({
      x: x + (Math.random() - 0.5) * spread * 0.5,
      y: y + (Math.random() - 0.5) * 16,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - Math.random() * 60,
      size: 2 + Math.random() * 5.5,
      color: Math.random() < 0.22 ? "#ffffff" : color,
      life,
      maxLife: life,
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 12,
      shard: Math.random() > 0.35,
      gravity: 900 + Math.random() * 420,
    });
  }
  if (e.particles.length > 220) e.particles.splice(0, e.particles.length - 220);
}

function draw(
  ctx: CanvasRenderingContext2D,
  e: Engine,
  size: Size,
  skin: ReturnType<typeof getSkin>,
  daily: boolean,
) {
  const { w, h, dpr } = size;
  if (!w || !h) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  const world = e.level.world;

  // background
  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, world.bg[0]);
  bg.addColorStop(0.52, world.bg[1]);
  bg.addColorStop(1, world.bg[2]);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  const cx = w / 2;
  const anchorY = h * 0.44;
  const baseR = Math.min(w * 0.335, h * 0.25, 188);
  const ballR = Math.max(17, Math.min(31, baseR * 0.185));

  // ambient glow
  const glow = ctx.createRadialGradient(cx, anchorY + baseR * 0.1, 10, cx, anchorY, baseR * 3.1);
  glow.addColorStop(0, rgba(world.glow, 0.24));
  glow.addColorStop(0.55, rgba(world.glow, 0.07));
  glow.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);

  // overhead light shaft
  const shaft = ctx.createLinearGradient(cx, 0, cx, anchorY + baseR * 1.4);
  shaft.addColorStop(0, rgba(world.accent2, 0.14));
  shaft.addColorStop(0.55, rgba(world.accent2, 0.045));
  shaft.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = shaft;
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.045, -10);
  ctx.lineTo(cx + w * 0.045, -10);
  ctx.lineTo(cx + baseR * 1.55, anchorY + baseR * 1.5);
  ctx.lineTo(cx - baseR * 1.55, anchorY + baseR * 1.5);
  ctx.closePath();
  ctx.fill();

  // orbital rings behind the tower
  for (let i = 0; i < 3; i += 1) {
    const oy = anchorY - baseR * 0.25 + i * baseR * 0.92;
    const rx = baseR * (1.32 + i * 0.055);
    ctx.save();
    ctx.strokeStyle = rgba(i === 1 ? world.accent2 : world.accent, 0.14 - i * 0.02);
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 9]);
    ctx.lineDashOffset = e.elapsed * (i % 2 === 0 ? 14 : -11);
    ctx.beginPath();
    ctx.ellipse(cx, oy, rx, rx * 0.26, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  // stars
  for (const s of e.stars) {
    const tw = 0.55 + 0.45 * Math.sin(e.elapsed * 1.4 + s.phase);
    ctx.fillStyle = `rgba(255,255,255,${s.a * tw})`;
    ctx.beginPath();
    ctx.arc(s.x * w, s.y * h * 0.9, s.r, 0, Math.PI * 2);
    ctx.fill();
  }
  // rising dust
  for (const d of e.dust) {
    const y = ((d.y * h - e.elapsed * d.speed) % h + h) % h;
    ctx.fillStyle = rgba(world.accent2, d.a * 0.5);
    ctx.beginPath();
    ctx.arc(d.x * w, y, d.r, 0, Math.PI * 2);
    ctx.fill();
  }

  // distant horizon platform glow
  const rim = ctx.createRadialGradient(cx, anchorY + baseR * 0.6, baseR * 0.2, cx, anchorY + baseR * 0.6, baseR * 1.8);
  rim.addColorStop(0, rgba(world.accent2, 0.08));
  rim.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = rim;
  ctx.fillRect(0, anchorY - baseR, w, h - anchorY + baseR);

  const shakeX = (Math.random() - 0.5) * e.shake;
  const shakeY = (Math.random() - 0.5) * e.shake;
  ctx.save();
  ctx.translate(shakeX, shakeY);

  const gap = Math.max(27, Math.min(46, baseR * 0.27));
  const cumulativeGap = (offset: number) => {
    let total = 0;
    const n = Math.max(0, offset);
    for (let i = 0; i < n; i += 1) total += gap * Math.pow(0.955, i);
    return total + (offset < 0 ? offset * gap * 0.86 : 0);
  };

  const activeLayer = e.level.layers[e.current];
  let frontKind: "break" | "gem" | "solid" = "break";
  if (activeLayer) {
    const segments = activeLayer.sectors.length;
    const rotation = ((e.rotations[e.current] % 360) + 360) % 360;
    const local = (90 - rotation + 360) % 360;
    frontKind = activeLayer.sectors[Math.min(segments - 1, Math.floor(local / (360 / segments)))];
  }

  const visible = 9;
  for (let i = e.current + visible; i >= e.current; i -= 1) {
    if (i >= e.level.layers.length) continue;
    const offset = i - e.camera;
    if (offset < -0.9) continue;
    const y = anchorY + cumulativeGap(offset);
    const scale = Math.max(0.58, 1 - Math.max(0, offset) * 0.026);
    const radius = baseR * scale;
    const ry = baseR * 0.29 * scale;
    drawLayer(
      ctx,
      cx,
      y,
      radius,
      ry,
      e.rotations[i],
      e.level.layers[i].sectors,
      world,
      i === e.current,
      Math.max(0, offset),
      e.elapsed,
      baseR,
      frontKind,
    );
  }

  // core crystal beneath the last disc
  const remaining = e.level.layers.length - e.current;
  if (remaining <= visible) {
    const coreY = anchorY + cumulativeGap(remaining) + gap * 0.2;
    const pulse = 0.6 + Math.sin(e.elapsed * 2.2) * 0.18;
    const coreGlow = ctx.createRadialGradient(cx, coreY, 2, cx, coreY, baseR * 0.85);
    coreGlow.addColorStop(0, rgba(world.accent2, 0.4 * pulse));
    coreGlow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = coreGlow;
    ctx.beginPath();
    ctx.arc(cx, coreY, baseR * 0.85, 0, Math.PI * 2);
    ctx.fill();
    ctx.save();
    ctx.translate(cx, coreY);
    ctx.rotate(e.elapsed * 0.4);
    ctx.fillStyle = rgba(world.accent2, 0.85);
    ctx.beginPath();
    for (let p = 0; p < 6; p += 1) {
      const a = (p / 6) * Math.PI * 2;
      const rr = p % 2 === 0 ? baseR * 0.16 : baseR * 0.08;
      ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr * 0.5);
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // trail
  for (const tr of e.trail) {
    ctx.fillStyle = rgba(tr.color, Math.max(0, tr.life) * 0.28);
    ctx.beginPath();
    ctx.arc(tr.x, tr.y, ballR * 0.6 * tr.life, 0, Math.PI * 2);
    ctx.fill();
  }

  // ball shadow on the active disc
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.38)";
  ctx.beginPath();
  ctx.ellipse(
    cx,
    anchorY + baseR * 0.245,
    ballR * 0.95 * (1 + Math.min(1.6, -e.bounceY / 90) * 0.35),
    ballR * 0.32 * (1 + Math.min(1.6, -e.bounceY / 90) * 0.35),
    0,
    0,
    Math.PI * 2,
  );
  ctx.fill();
  ctx.restore();

  // ball
  const ballY = anchorY + baseR * 0.29 * 0.95 + e.bounceY - ballR * 0.22 + e.smashPulse * 8;
  const squash = 1 + e.smashPulse * 0.12;
  if (e.bounceY < -0.4 || e.holding) {
    e.trail.push({ x: cx, y: ballY + ballR * 0.55, life: 1, color: skin.trail });
    if (e.trail.length > 24) e.trail.shift();
  }
  ctx.save();
  ctx.translate(cx, ballY);
  ctx.scale(1 / squash, squash);
  const ballGlow = ctx.createRadialGradient(0, 0, ballR * 0.4, 0, 0, ballR * 2.7);
  ballGlow.addColorStop(0, rgba(skin.glow, 0.42));
  ballGlow.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = ballGlow;
  ctx.beginPath();
  ctx.arc(0, 0, ballR * 2.7, 0, Math.PI * 2);
  ctx.fill();
  const ball = ctx.createRadialGradient(-ballR * 0.36, -ballR * 0.42, ballR * 0.08, 0, 0, ballR * 1.18);
  ball.addColorStop(0, skin.inner);
  ball.addColorStop(0.36, skin.core);
  ball.addColorStop(1, skin.outer);
  ctx.fillStyle = ball;
  ctx.beginPath();
  ctx.arc(0, 0, ballR, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.beginPath();
  ctx.ellipse(-ballR * 0.33, -ballR * 0.43, ballR * 0.27, ballR * 0.17, -0.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.18)";
  ctx.beginPath();
  ctx.ellipse(ballR * 0.12, ballR * 0.5, ballR * 0.5, ballR * 0.19, 0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.4)";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(0, 0, ballR * 0.99, Math.PI * 0.9, Math.PI * 1.9);
  ctx.stroke();
  ctx.restore();

  // particles
  for (const p of e.particles) {
    const alpha = Math.max(0, Math.min(1, p.life / p.maxLife));
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = p.color;
    if (p.shard) {
      ctx.fillRect(-p.size / 2, -p.size / 4, p.size * 1.25, p.size * 0.6);
    } else {
      ctx.beginPath();
      ctx.arc(0, 0, p.size * 0.45, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
  ctx.globalAlpha = 1;

  // floating texts
  for (const t of e.texts) {
    const alpha = Math.max(0, Math.min(1, t.life / t.maxLife));
    ctx.globalAlpha = alpha;
    ctx.font = `800 ${t.size}px Sora, sans-serif`;
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.fillText(t.text, t.x + 1, t.y + 2);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, t.x, t.y);
    ctx.globalAlpha = 1;
  }

  ctx.restore();

  // progress meter arc on the right edge
  drawSideMeter(ctx, e, w, h, world);

  // vignette
  const vignette = ctx.createRadialGradient(cx, h * 0.46, Math.min(w, h) * 0.24, cx, h * 0.46, Math.max(w, h) * 0.78);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(0,0,0,0.5)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, w, h);

  // daily stamp
  if (daily) {
    ctx.font = "800 10px Sora, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,.55)";
    ctx.textAlign = "left";
    ctx.fillText("DAILY DESCENT", 14, 22);
  }
}

function drawSideMeter(ctx: CanvasRenderingContext2D, e: Engine, w: number, h: number, world: World) {
  const total = e.level.layers.length;
  const pct = total ? e.current / total : 0;
  const x = w - 18;
  const top = h * 0.24;
  const bottom = h * 0.72;
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.1)";
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x, top);
  ctx.lineTo(x, bottom);
  ctx.stroke();
  const y = top + (bottom - top) * pct;
  const g = ctx.createLinearGradient(x, top, x, bottom);
  g.addColorStop(0, world.accent2);
  g.addColorStop(1, world.accent);
  ctx.strokeStyle = g;
  ctx.shadowColor = world.accent;
  ctx.shadowBlur = 12;
  ctx.beginPath();
  ctx.moveTo(x, top);
  ctx.lineTo(x, y);
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(x, y, 3.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.font = "700 9px Sora, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,.5)";
  ctx.textAlign = "center";
  ctx.fillText(`${Math.round(pct * 100)}%`, x, h * 0.76);
  ctx.restore();
}

function drawLayer(
  ctx: CanvasRenderingContext2D,
  cx: number,
  y: number,
  R: number,
  ry: number,
  rotationDeg: number,
  sectors: ("break" | "gem" | "solid")[],
  world: World,
  active: boolean,
  depth: number,
  time: number,
  baseR: number,
  frontKind: "break" | "gem" | "solid" = "break",
) {
  const darken = Math.min(0.55, depth * 0.08);
  const thickness = Math.max(8, R * 0.125);

  // side wall
  const wallTop = mix(world.bg[0], "#000000", 0.1);
  const wall = ctx.createLinearGradient(cx, y, cx, y + thickness + ry);
  wall.addColorStop(0, mix(world.accent, "#0a0b12", 0.55));
  wall.addColorStop(1, wallTop);
  ctx.beginPath();
  ctx.ellipse(cx, y, R, ry, 0, 0, Math.PI);
  ctx.ellipse(cx, y + thickness, R, ry, 0, Math.PI, 0, true);
  ctx.closePath();
  ctx.fillStyle = wall;
  ctx.fill();

  // bottom rim light
  ctx.beginPath();
  ctx.ellipse(cx, y + thickness, R, ry, 0, 0.12, Math.PI - 0.12);
  ctx.strokeStyle = rgba(world.accent, active ? 0.6 : 0.18);
  ctx.lineWidth = 1.4;
  ctx.stroke();

  // top sector wedges
  const segments = sectors.length;
  const segAngle = 360 / segments;
  for (let i = 0; i < segments; i += 1) {
    const kind = sectors[i];
    const a0 = (rotationDeg + i * segAngle) * DEG;
    const a1 = (rotationDeg + (i + 1) * segAngle) * DEG;
    let color: string;
    if (kind === "solid") {
      color = mix(world.solid, "#05060b", 0.32 + darken * 0.4);
    } else if (kind === "gem") {
      color = "#f7c95c";
    } else {
      const base = i % 2 === 0 ? world.accent : world.accent2;
      color = mix(base, world.bg[1], 0.22 + (i % 3) * 0.1 + darken);
    }
    ctx.beginPath();
    ctx.moveTo(cx, y);
    ctx.ellipse(cx, y, R, ry, 0, a0, a1);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();

    // hazard marks on unbreakable plates
    if (kind === "solid" && R > 90) {
      ctx.save();
      ctx.clip();
      const mid = (a0 + a1) / 2;
      const px = cx + Math.cos(mid) * R * 0.7;
      const py = y + Math.sin(mid) * ry * 0.7;
      ctx.strokeStyle = "rgba(255,120,138,0.55)";
      ctx.lineWidth = Math.max(1.2, R * 0.012);
      ctx.beginPath();
      ctx.moveTo(px - 4, py - 4);
      ctx.lineTo(px + 4, py + 4);
      ctx.moveTo(px + 4, py - 4);
      ctx.lineTo(px - 4, py + 4);
      ctx.stroke();
      ctx.restore();
    }
    if (kind === "gem") {
      ctx.save();
      ctx.fillStyle = "rgba(255,255,255,.75)";
      const mid = (a0 + a1) / 2;
      const px = cx + Math.cos(mid) * R * 0.72;
      const py = y + Math.sin(mid) * ry * 0.72;
      ctx.beginPath();
      ctx.moveTo(px, py - 4.5);
      ctx.lineTo(px + 3.5, py);
      ctx.lineTo(px, py + 4.5);
      ctx.lineTo(px - 3.5, py);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  // subtle seams
  if (R > 70) {
    ctx.strokeStyle = "rgba(255,255,255,0.07)";
    ctx.lineWidth = 1;
    for (let i = 0; i < segments; i += 1) {
      const a = (rotationDeg + i * segAngle) * DEG;
      ctx.beginPath();
      ctx.moveTo(cx, y);
      ctx.lineTo(cx + Math.cos(a) * R, y + Math.sin(a) * ry);
      ctx.stroke();
    }
  }

  // lighting overlay
  const light = ctx.createRadialGradient(cx - R * 0.32, y - ry * 1.1, R * 0.05, cx, y, R * 1.15);
  light.addColorStop(0, "rgba(255,255,255,0.2)");
  light.addColorStop(0.45, "rgba(255,255,255,0.03)");
  light.addColorStop(1, "rgba(0,0,0,0.3)");
  ctx.beginPath();
  ctx.ellipse(cx, y, R, ry, 0, 0, Math.PI * 2);
  ctx.closePath();
  ctx.fillStyle = light;
  ctx.fill();

  // outer ring
  ctx.beginPath();
  ctx.ellipse(cx, y, R, ry, 0, 0, Math.PI * 2);
  ctx.strokeStyle = active ? rgba(world.accent2, 0.8) : rgba(world.accent, 0.28);
  ctx.lineWidth = active ? 1.8 : 1;
  if (active) {
    ctx.shadowColor = world.accent2;
    ctx.shadowBlur = 16;
  }
  ctx.stroke();
  ctx.shadowBlur = 0;

  // inner ring detail
  ctx.beginPath();
  ctx.ellipse(cx, y, R * 0.55, ry * 0.55, 0, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;
  ctx.stroke();

  // active front hit marker — colour shows what is directly under the ball
  if (active) {
    const pulse = 0.6 + Math.sin(time * 4) * 0.3;
    const segRad = (segAngle * DEG) / 2;
    const front = Math.PI / 2;
    const markerColor =
      frontKind === "solid" ? "#ff758b" : frontKind === "gem" ? "#ffd76b" : world.accent2;
    ctx.beginPath();
    ctx.ellipse(cx, y, R, ry, 0, front - segRad, front + segRad);
    ctx.strokeStyle = markerColor;
    ctx.lineWidth = Math.max(2.5, baseR * 0.016);
    ctx.shadowColor = markerColor;
    ctx.shadowBlur = 12 + pulse * 8;
    ctx.stroke();
    ctx.shadowBlur = 0;
    // chevrons
    ctx.strokeStyle = markerColor;
    ctx.lineWidth = 2.4;
    ctx.lineCap = "round";
    for (let c = 0; c < 2; c += 1) {
      const cy2 = y + ry + 12 + c * 6 + Math.sin(time * 3 + c) * 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - 8, cy2 - 4);
      ctx.lineTo(cx, cy2 + 2);
      ctx.lineTo(cx + 8, cy2 - 4);
      ctx.stroke();
    }
    // glowing landing point at the near lip
    ctx.fillStyle = markerColor;
    ctx.globalAlpha = 0.5 + pulse * 0.4;
    ctx.beginPath();
    ctx.ellipse(cx, y + ry, baseR * 0.075, baseR * 0.023, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
}
