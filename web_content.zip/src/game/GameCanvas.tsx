import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  type MutableRefObject,
} from "react";
import type { Car, RunResult } from "../data/game";
import { sound } from "./audio";
import { renderWorld } from "./render";
import {
  createWorld,
  resizeWorld,
  resetWorld,
  snapshot,
  tickWorld,
  type HudSnapshot,
  type Input,
  type Phase,
  type World,
} from "./world";

export type GameHandle = {
  setControl: (key: "left" | "right" | "up" | "down" | "nitro", value: boolean) => void;
  restart: () => void;
};

type Props = {
  car: Car;
  phase: Phase;
  runToken: number;
  soundOn: boolean;
  onHud: (hud: HudSnapshot) => void;
  onPhaseRequest: (phase: Phase | "restart") => void;
  onRunEnd: (result: RunResult, hud: HudSnapshot) => void;
  onMilestone: (level: number) => void;
  onFirstMove?: () => void;
};

const emptyInput = (): Input => ({
  left: false,
  right: false,
  up: false,
  down: false,
  nitro: false,
  pointerX: null,
});

export const GameCanvas = forwardRef<GameHandle, Props>(function GameCanvas(
  { car, phase, runToken, soundOn, onHud, onPhaseRequest, onRunEnd, onMilestone, onFirstMove },
  ref,
) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const worldRef = useRef<World>(createWorld());
  const inputRef = useRef<Input>(emptyInput());
  const phaseRef = useRef<Phase>(phase);
  const carRef = useRef<Car>(car);
  const runTokenRef = useRef(runToken);
  const endedRef = useRef(false);
  const crashSoundRef = useRef(false);
  const hudClockRef = useRef(0);
  const callbacksRef = useRef({ onHud, onPhaseRequest, onRunEnd, onMilestone, onFirstMove });
  const pointerActiveRef = useRef(false);
  const mutesRef = useRef(soundOn);

  phaseRef.current = phase;
  carRef.current = car;
  callbacksRef.current = { onHud, onPhaseRequest, onRunEnd, onMilestone, onFirstMove };
  mutesRef.current = soundOn;

  useImperativeHandle(ref, () => ({
    setControl(key, value) {
      if (phaseRef.current !== "playing") return;
      inputRef.current[key] = value;
    },
    restart() {
      inputRef.current = emptyInput();
    },
  }));

  // Reset the world whenever the player starts a fresh run.
  useEffect(() => {
    if (runToken === 0) return;
    if (runTokenRef.current === runToken) return;
    runTokenRef.current = runToken;
    endedRef.current = false;
    crashSoundRef.current = false;
    inputRef.current = emptyInput();
    resetWorld(worldRef.current, carRef.current);
    callbacksRef.current.onHud(snapshot(worldRef.current));
  }, [runToken]);

  // Audio follows the phase + mute preference.
  useEffect(() => {
    sound.setMuted(!soundOn);
    if (soundOn && phase === "playing") sound.startEngine();
    if (phase !== "playing") sound.stopEngine();
    if (!soundOn) return;
    return () => {
      sound.stopEngine();
    };
  }, [phase, soundOn]);

  // Main loop.
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    let raf = 0;
    let last = performance.now();
    const world = worldRef.current;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      if (rect.width < 2 || rect.height < 2) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      resizeWorld(world, rect.width, rect.height);
    };

    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();

    const loop = (now: number) => {
      const dt = Math.min(0.045, Math.max(0.001, (now - last) / 1000));
      last = now;
      const activePhase = phaseRef.current;
      const activeCar = carRef.current;

      if (activePhase === "playing") {
        const events = tickWorld(world, inputRef.current, dt, activeCar);
        if (events.hit) sound.hit();
        if (events.nearMiss) sound.nearMiss();
        if (events.collected) sound.spark();
        if (events.levelUp) {
          sound.levelUp();
          callbacksRef.current.onMilestone(events.levelUp);
        }
        if (world.crashed && !crashSoundRef.current) {
          crashSoundRef.current = true;
          sound.crash();
        }
        sound.updateEngine(world.speed, true);

        hudClockRef.current += dt;
        if (hudClockRef.current >= 0.08) {
          hudClockRef.current = 0;
          callbacksRef.current.onHud(snapshot(world));
        }

        if (world.crashed && world.overTimer <= 0 && !endedRef.current) {
          endedRef.current = true;
          const hud = snapshot(world);
          callbacksRef.current.onHud(hud);
          callbacksRef.current.onRunEnd(
            {
              distance: hud.distance,
              score: hud.score,
              topSpeed: Math.round(world.topSpeed),
              level: world.level,
              nearMisses: world.nearMisses,
              sparks: world.sparks,
              carId: activeCar.id,
              carName: activeCar.name,
            },
            hud,
          );
        }
      } else {
        sound.updateEngine(world.speed, false);
        if (activePhase === "idle") {
          world.roadOffset += dt * 68;
          hudClockRef.current += dt;
          if (hudClockRef.current > 0.3) {
            hudClockRef.current = 0;
            callbacksRef.current.onHud(snapshot(world));
          }
        }
      }

      renderWorld(ctx, world, activeCar, activePhase, now / 1000);
      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, []);

  // Keyboard controls.
  useEffect(() => {
    const isTyping = (target: EventTarget | null) => {
      const element = target as HTMLElement | null;
      return Boolean(element && ["INPUT", "TEXTAREA", "SELECT"].includes(element.tagName));
    };

    const down = (event: KeyboardEvent) => {
      if (isTyping(event.target)) return;
      const key = event.key.toLowerCase();
      const current = phaseRef.current;

      if (["arrowleft", "arrowright", "arrowup", "arrowdown", " "].includes(key)) {
        if (current === "playing" || current === "paused" || current === "countdown") event.preventDefault();
      }

      if (key === "p" || key === "escape") {
        if (current === "playing" || current === "paused") {
          event.preventDefault();
          callbacksRef.current.onPhaseRequest(current === "playing" ? "paused" : "playing");
        }
        return;
      }
      if (key === "r" && (current === "playing" || current === "paused" || current === "over")) {
        event.preventDefault();
        callbacksRef.current.onPhaseRequest("restart");
        return;
      }
      if (current !== "playing") return;

      if (key === "arrowleft" || key === "a") inputRef.current.left = true;
      if (key === "arrowright" || key === "d") inputRef.current.right = true;
      if (key === "arrowup" || key === "w") inputRef.current.up = true;
      if (key === "arrowdown" || key === "s") inputRef.current.down = true;
      if (key === "shift" || key === "n" || key === " ") inputRef.current.nitro = true;
      if (event.repeat) return;
      callbacksRef.current.onFirstMove?.();
    };

    const up = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (key === "arrowleft" || key === "a") inputRef.current.left = false;
      if (key === "arrowright" || key === "d") inputRef.current.right = false;
      if (key === "arrowup" || key === "w") inputRef.current.up = false;
      if (key === "arrowdown" || key === "s") inputRef.current.down = false;
      if (key === "shift" || key === "n" || key === " ") inputRef.current.nitro = false;
    };

    const blur = () => {
      inputRef.current = { ...emptyInput() };
      if (phaseRef.current === "playing") callbacksRef.current.onPhaseRequest("paused");
    };

    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
    };
  }, []);

  // Pointer / touch steering on the canvas.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const pointToRoad = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      void x;
      inputRef.current.pointerX = x;
    };

    const down = (event: PointerEvent) => {
      if (phaseRef.current !== "playing") return;
      pointerActiveRef.current = true;
      canvas.setPointerCapture?.(event.pointerId);
      pointToRoad(event);
      callbacksRef.current.onFirstMove?.();
    };
    const move = (event: PointerEvent) => {
      if (!pointerActiveRef.current || phaseRef.current !== "playing") return;
      pointToRoad(event);
    };
    const up = () => {
      pointerActiveRef.current = false;
      inputRef.current.pointerX = null;
    };

    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);
    return () => {
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="game-canvas absolute inset-0 h-full w-full"
      aria-label="Night highway game area. Use arrow keys or A and D to steer, Shift for nitro, P to pause."
      role="img"
    />
  );
});

export type { HudSnapshot };
export type HudRef = MutableRefObject<HudSnapshot | null>;
