import * as THREE from 'three';

export interface CarBuild {
  group: THREE.Group;
  wheels: THREE.Group[];
  bodyMat: THREE.MeshStandardMaterial;
  brakeLights: THREE.MeshStandardMaterial;
  headLights: THREE.MeshStandardMaterial;
}

function roundedBox(w: number, h: number, d: number, _r: number, seg = 3): THREE.BoxGeometry {
  // Approximate rounded box via BoxGeometry (bevel faked with extra segments + vertex tweak is overkill).
  // We use Box with more segments and rely on smooth normals via material.
  const g = new THREE.BoxGeometry(w, h, d, seg, seg, seg);
  return g;
}

/** Build a detailed rally car from profile extrusion — not a plain box. */
export function buildRallyCar(color = '#d21f2b', opts: { detail?: 'high' | 'low' } = {}): CarBuild {
  const detail = opts.detail ?? 'high';
  const group = new THREE.Group();
  const wheels: THREE.Group[] = [];

  const bodyMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(color),
    metalness: 0.72,
    roughness: 0.24,
    envMapIntensity: 1.35,
  });
  const darkMat = new THREE.MeshStandardMaterial({ color: '#14161c', metalness: 0.35, roughness: 0.62 });
  const glassMat = new THREE.MeshStandardMaterial({
    color: '#0b1622',
    metalness: 0.94,
    roughness: 0.08,
    envMapIntensity: 1.65,
  });
  const chromeMat = new THREE.MeshStandardMaterial({ color: '#e2e8f0', metalness: 1, roughness: 0.15, envMapIntensity: 1.5 });
  const rimMat = new THREE.MeshStandardMaterial({ color: '#eef2f6', metalness: 0.96, roughness: 0.2, envMapIntensity: 1.4 });
  const tireMat = new THREE.MeshStandardMaterial({ color: '#151618', metalness: 0.08, roughness: 0.86 });
  const brakeMat = new THREE.MeshStandardMaterial({ color: '#550000', emissive: '#ff1a1a', emissiveIntensity: 0.75, roughness: 0.25 });
  const headMat = new THREE.MeshStandardMaterial({ color: '#fffbe8', emissive: '#fff4c8', emissiveIntensity: 1.05, roughness: 0.15 });

  // --- Lower body via side-profile extrusion for realistic silhouette ---
  const s = new THREE.Shape();
  // car length ~4.4 (x from -2.2 to 2.2 in shape space), height up to 0.75
  s.moveTo(-2.2, 0.25);
  s.lineTo(-2.2, 0.55);
  s.quadraticCurveTo(-2.15, 0.68, -1.95, 0.7); // trunk lip
  s.lineTo(-0.9, 0.74); // rear deck
  s.lineTo(0.9, 0.72); // hood line start (cabin sits above)
  s.quadraticCurveTo(1.7, 0.7, 1.95, 0.55); // nose slope
  s.lineTo(2.2, 0.5);
  s.quadraticCurveTo(2.25, 0.35, 2.15, 0.28);
  s.lineTo(1.84, 0.2); // underbody front
  // front wheel arch (travels right -> left over the top)
  s.absarc(1.35, 0.26, 0.44, 0, Math.PI, false);
  s.lineTo(-0.86, 0.2); // underbody middle
  // rear wheel arch
  s.absarc(-1.35, 0.26, 0.44, 0, Math.PI, false);
  s.lineTo(-2.1, 0.18);
  s.closePath();

  const extrudeSettings: THREE.ExtrudeGeometryOptions = {
    depth: 1.7,
    bevelEnabled: true,
    bevelThickness: 0.12,
    bevelSize: 0.1,
    bevelSegments: detail === 'high' ? 3 : 2,
    curveSegments: detail === 'high' ? 16 : 12,
  };
  const bodyGeo = new THREE.ExtrudeGeometry(s, extrudeSettings);
  bodyGeo.translate(0, 0, -0.85);
  bodyGeo.rotateY(Math.PI / 2);
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 0.28;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  // --- Cabin / greenhouse ---
  const cab = new THREE.Shape();
  cab.moveTo(-1.05, 0);
  cab.quadraticCurveTo(-0.9, 0.5, -0.35, 0.55);
  cab.lineTo(0.25, 0.55);
  cab.quadraticCurveTo(0.75, 0.5, 0.95, 0);
  cab.closePath();
  const cabGeo = new THREE.ExtrudeGeometry(cab, {
    depth: 1.35,
    bevelEnabled: true,
    bevelThickness: 0.08,
    bevelSize: 0.08,
    bevelSegments: detail === 'high' ? 3 : 2,
    curveSegments: detail === 'high' ? 12 : 8,
  });
  cabGeo.translate(0, 0, -0.675);
  cabGeo.rotateY(Math.PI / 2);
  const cabin = new THREE.Mesh(cabGeo, glassMat);
  cabin.position.set(0, 1.0, 0.15);
  cabin.castShadow = true;
  group.add(cabin);

  // roof panel (body color over glass)
  const roof = new THREE.Mesh(roundedBox(1.25, 0.08, 1.15, 0.03), bodyMat);
  roof.position.set(0, 1.62, 0.18);
  roof.castShadow = true;
  group.add(roof);

  // hood scoop (rally!)
  const scoop = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.12, 0.4), darkMat);
  scoop.position.set(0, 1.12, -1.15);
  scoop.castShadow = true;
  group.add(scoop);
  const scoopHole = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.06, 0.28), new THREE.MeshStandardMaterial({ color: '#000' }));
  scoopHole.position.set(0, 1.18, -1.15);
  group.add(scoopHole);

  // front bumper + splitter
  const bumperF = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.28, 0.35), darkMat);
  bumperF.position.set(0, 0.42, -2.2);
  bumperF.castShadow = true;
  group.add(bumperF);
  const splitter = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.06, 0.5), new THREE.MeshStandardMaterial({ color: '#0c0d11', roughness: 0.5 }));
  splitter.position.set(0, 0.28, -2.3);
  group.add(splitter);

  // rear bumper + diffuser
  const bumperR = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.3, 0.3), darkMat);
  bumperR.position.set(0, 0.45, 2.2);
  group.add(bumperR);

  // grille + front intercooler detail
  const grille = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.18, 0.06), new THREE.MeshStandardMaterial({ color: '#08090c', roughness: 0.5, metalness: 0.4 }));
  grille.position.set(0, 0.62, -2.32);
  group.add(grille);
  const intercooler = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.16, 0.05), chromeMat);
  intercooler.position.set(0, 0.39, -2.36);
  group.add(intercooler);

  // headlights
  const headGeo = new THREE.BoxGeometry(0.42, 0.16, 0.08);
  const hl1 = new THREE.Mesh(headGeo, headMat);
  hl1.position.set(-0.62, 0.78, -2.28);
  hl1.rotation.y = 0.12;
  group.add(hl1);
  const hl2 = new THREE.Mesh(headGeo, headMat);
  hl2.position.set(0.62, 0.78, -2.28);
  hl2.rotation.y = -0.12;
  group.add(hl2);
  // rally light pod on roof
  if (detail === 'high') {
    const podBar = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.07, 0.12), darkMat);
    podBar.position.set(0, 1.72, -0.35);
    group.add(podBar);
    for (let i = -1; i <= 1; i++) {
      const pod = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.08, 12), headMat);
      pod.rotation.x = Math.PI / 2;
      pod.position.set(i * 0.32, 1.72, -0.44);
      group.add(pod);
    }
  }

  // taillights (full-width bar + sides)
  const tlBar = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.12, 0.06), brakeMat);
  tlBar.position.set(0, 0.82, 2.3);
  group.add(tlBar);

  // side skirts
  const skirtGeo = new THREE.BoxGeometry(0.12, 0.16, 2.6);
  const sk1 = new THREE.Mesh(skirtGeo, darkMat);
  sk1.position.set(-1.0, 0.32, 0);
  group.add(sk1);
  const sk2 = new THREE.Mesh(skirtGeo, darkMat);
  sk2.position.set(1.0, 0.32, 0);
  group.add(sk2);

  // mirrors
  const mirGeo = new THREE.BoxGeometry(0.18, 0.1, 0.08);
  const m1 = new THREE.Mesh(mirGeo, bodyMat);
  m1.position.set(-0.95, 1.25, -0.55);
  group.add(m1);
  const m2 = new THREE.Mesh(mirGeo, bodyMat);
  m2.position.set(0.95, 1.25, -0.55);
  group.add(m2);

  // big rally wing
  const wingPylonGeo = new THREE.BoxGeometry(0.08, 0.35, 0.25);
  const p1 = new THREE.Mesh(wingPylonGeo, darkMat);
  p1.position.set(-0.6, 1.15, 2.05);
  group.add(p1);
  const p2 = new THREE.Mesh(wingPylonGeo, darkMat);
  p2.position.set(0.6, 1.15, 2.05);
  group.add(p2);
  const wing = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.08, 0.45), bodyMat);
  wing.position.set(0, 1.36, 2.1);
  wing.castShadow = true;
  group.add(wing);
  const wingEndGeo = new THREE.BoxGeometry(0.06, 0.28, 0.5);
  const w1 = new THREE.Mesh(wingEndGeo, darkMat);
  w1.position.set(-0.95, 1.28, 2.1);
  group.add(w1);
  const w2 = new THREE.Mesh(wingEndGeo, darkMat);
  w2.position.set(0.95, 1.28, 2.1);
  group.add(w2);

  // exhausts
  const exGeo = new THREE.CylinderGeometry(0.055, 0.055, 0.25, 10);
  const e1 = new THREE.Mesh(exGeo, chromeMat);
  e1.rotation.x = Math.PI / 2;
  e1.position.set(-0.3, 0.36, 2.35);
  group.add(e1);
  const e2 = new THREE.Mesh(exGeo, chromeMat);
  e2.rotation.x = Math.PI / 2;
  e2.position.set(0.3, 0.36, 2.35);
  group.add(e2);

  // racing stripe
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.02, 4.1), new THREE.MeshStandardMaterial({ color: '#f5f5f5', metalness: 0.4, roughness: 0.4 }));
  stripe.position.set(0, 1.045, 0.1);
  group.add(stripe);
  const stripe2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.02, 1.1), stripe.material);
  stripe2.position.set(0, 1.67, 0.18);
  group.add(stripe2);

  // number plate
  const plate = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.03), new THREE.MeshStandardMaterial({ color: '#f8fafc' }));
  plate.position.set(0, 0.55, -2.39);
  group.add(plate);

  // --- Wheels ---
  const wheelPositions: [number, number][] = [
    [-0.95, -1.35],
    [0.95, -1.35],
    [-0.95, 1.35],
    [0.95, 1.35],
  ];
  const tireGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.32, detail === 'high' ? 20 : 12);
  tireGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.34, 6);
  rimGeo.rotateZ(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.36, 8);
  hubGeo.rotateZ(Math.PI / 2);

  const caliperMat = new THREE.MeshStandardMaterial({ color: '#e11d48', metalness: 0.6, roughness: 0.35 });
  const flapMat = new THREE.MeshStandardMaterial({ color: '#1b1d24', roughness: 0.85 });
  for (const [x, z] of wheelPositions) {
    const wg = new THREE.Group();
    wg.rotation.order = 'YXZ';
    const tire = new THREE.Mesh(tireGeo, tireMat);
    tire.castShadow = true;
    wg.add(tire);
    const rim = new THREE.Mesh(rimGeo, rimMat);
    wg.add(rim);
    const hub = new THREE.Mesh(hubGeo, darkMat);
    wg.add(hub);
    // spokes detail
    if (detail === 'high') {
      for (let i = 0; i < 5; i++) {
        const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.07, 0.09), rimMat);
        spoke.rotation.x = (i / 5) * Math.PI * 2;
        wg.add(spoke);
      }
      // brake disc & rally caliper
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 0.35, 14), new THREE.MeshStandardMaterial({ color: '#94a3b8', metalness: 0.92, roughness: 0.3 }));
      disc.rotation.z = Math.PI / 2;
      wg.add(disc);
      const cal = new THREE.Mesh(new THREE.BoxGeometry(0.37, 0.14, 0.09), caliperMat);
      cal.position.set(0, 0.08, -0.12);
      wg.add(cal);
    }
    wg.position.set(x, 0.42, z);
    group.add(wg);
    wheels.push(wg);

    // rally mudflap behind each wheel
    const flap = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.28, 0.03), flapMat);
    flap.position.set(x, 0.28, z + 0.46);
    group.add(flap);
  }

  group.traverse((o) => {
    if (o instanceof THREE.Mesh) {
      o.castShadow = o.castShadow ?? false;
    }
  });

  return { group, wheels, bodyMat, brakeLights: brakeMat, headLights: headMat };
}

/** Simpler traffic car variants */
export function buildTrafficCar(color: string, kind: number): CarBuild {
  // kind 0 sedan, 1 suv, 2 hatch, 3 taxi
  const g = new THREE.Group();
  const wheels: THREE.Group[] = [];
  const bodyMat = new THREE.MeshStandardMaterial({ color, metalness: 0.5, roughness: 0.45 });
  const glassMat = new THREE.MeshStandardMaterial({ color: '#101c28', metalness: 0.8, roughness: 0.2 });
  const darkMat = new THREE.MeshStandardMaterial({ color: '#17191f', roughness: 0.8 });
  const tireMat = new THREE.MeshStandardMaterial({ color: '#141414', roughness: 0.9 });
  const rimMat = new THREE.MeshStandardMaterial({ color: '#c9d2dc', metalness: 0.9, roughness: 0.3 });
  const brakeMat = new THREE.MeshStandardMaterial({ color: '#550000', emissive: '#ff2222', emissiveIntensity: 0.4 });
  const headMat = new THREE.MeshStandardMaterial({ color: '#fffbe8', emissive: '#ffeeaa', emissiveIntensity: 0.7 });

  const tall = kind === 1 ? 0.25 : 0;
  const len = kind === 1 ? 4.5 : 4.2;

  const lower = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.62 + tall * 0.5, len), bodyMat);
  lower.position.y = 0.62;
  lower.castShadow = true;
  g.add(lower);
  // rounded hood/trunk via extra angled boxes
  const hood = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.3, 0.7), bodyMat);
  hood.position.set(0, 0.82, -len / 2 + 0.2);
  hood.rotation.x = -0.12;
  g.add(hood);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.55 + tall, 2.0), glassMat);
  cabin.position.set(0, 1.15 + tall * 0.7, 0.25);
  cabin.castShadow = true;
  g.add(cabin);
  const roofT = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.07, 1.5), bodyMat);
  roofT.position.set(0, 1.45 + tall * 1.2, 0.25);
  g.add(roofT);

  const bumpF = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.3, 0.25), darkMat);
  bumpF.position.set(0, 0.4, -len / 2 - 0.05);
  g.add(bumpF);
  const bumpR = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.3, 0.25), darkMat);
  bumpR.position.set(0, 0.4, len / 2 + 0.05);
  g.add(bumpR);

  const hlG = new THREE.BoxGeometry(0.4, 0.14, 0.06);
  const h1 = new THREE.Mesh(hlG, headMat);
  h1.position.set(-0.6, 0.72, -len / 2 - 0.12);
  g.add(h1);
  const h2 = new THREE.Mesh(hlG, headMat);
  h2.position.set(0.6, 0.72, -len / 2 - 0.12);
  g.add(h2);
  const tl = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.12, 0.06), brakeMat);
  tl.position.set(0, 0.78, len / 2 + 0.12);
  g.add(tl);

  if (kind === 3) {
    const sign = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.18, 0.3), new THREE.MeshStandardMaterial({ color: '#ffd21f', emissive: '#ffcf00', emissiveIntensity: 0.5 }));
    sign.position.set(0, 1.62, 0.25);
    g.add(sign);
  }

  const tireGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.28, 12);
  tireGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.3, 6);
  rimGeo.rotateZ(Math.PI / 2);
  const pos: [number, number][] = [[-0.85, -1.35], [0.85, -1.35], [-0.85, 1.35], [0.85, 1.35]];
  for (const [x, z] of pos) {
    const wg = new THREE.Group();
    wg.add(new THREE.Mesh(tireGeo, tireMat));
    wg.add(new THREE.Mesh(rimGeo, rimMat));
    wg.position.set(x, 0.38, z);
    g.add(wg);
    wheels.push(wg);
  }

  return { group: g, wheels, bodyMat, brakeLights: brakeMat, headLights: headMat };
}
