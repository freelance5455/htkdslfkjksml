// Vehicle construction + arcade-but-plausible driving physics.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { clamp, damp } from './util';
import { plateTexture } from './textures';

export type PlateColor = 'yellow' | 'green' | 'white' | 'black';

export interface VehicleSpec {
  type: string;
  displayName: string;
  length: number;
  width: number;
  height: number;
  wheelR: number;
  maxSpeed: number; // m/s
  accel: number;
  mass: number;
  grip: number;
  plate: PlateColor;
  topSpeedKmh: number;
}

export const VEHICLE_SPECS: Record<string, VehicleSpec> = {
  m8: {
    type: 'm8',
    displayName: 'Vortex M8 Competition',
    length: 4.9,
    width: 2.0,
    height: 1.36,
    wheelR: 0.35,
    maxSpeed: 88,
    accel: 15.5,
    mass: 1,
    grip: 1.25,
    plate: 'white',
    topSpeedKmh: 317,
  },
  sedan: {
    type: 'sedan',
    displayName: 'Corveta S7 Sedan',
    length: 4.8,
    width: 1.86,
    height: 1.46,
    wheelR: 0.34,
    maxSpeed: 52,
    accel: 8.4,
    mass: 1.2,
    grip: 1.0,
    plate: 'white',
    topSpeedKmh: 200,
  },
  suv: {
    type: 'suv',
    displayName: 'Ridgeline TX SUV',
    length: 5.1,
    width: 2.0,
    height: 1.86,
    wheelR: 0.4,
    maxSpeed: 46,
    accel: 7.6,
    mass: 1.6,
    grip: 1.0,
    plate: 'white',
    topSpeedKmh: 180,
  },
  taxi: {
    type: 'taxi',
    displayName: 'City Cab',
    length: 4.9,
    width: 1.9,
    height: 1.5,
    wheelR: 0.35,
    maxSpeed: 48,
    accel: 7.2,
    mass: 1.3,
    grip: 0.98,
    plate: 'yellow',
    topSpeedKmh: 170,
  },
  bus: {
    type: 'bus',
    displayName: 'Metro Transit 40',
    length: 11.5,
    width: 2.55,
    height: 3.1,
    wheelR: 0.52,
    maxSpeed: 32,
    accel: 4.2,
    mass: 4,
    grip: 0.85,
    plate: 'yellow',
    topSpeedKmh: 110,
  },
  police: {
    type: 'police',
    displayName: 'Patrol Interceptor',
    length: 5.0,
    width: 1.95,
    height: 1.5,
    wheelR: 0.36,
    maxSpeed: 60,
    accel: 10.5,
    mass: 1.3,
    grip: 1.15,
    plate: 'white',
    topSpeedKmh: 230,
  },
  van: {
    type: 'van',
    displayName: 'Cargo Panel Van',
    length: 5.6,
    width: 2.05,
    height: 2.35,
    wheelR: 0.38,
    maxSpeed: 40,
    accel: 5.6,
    mass: 1.9,
    grip: 0.9,
    plate: 'white',
    topSpeedKmh: 150,
  },
  ev: {
    type: 'ev',
    displayName: 'Voltara E-Tron',
    length: 4.75,
    width: 1.95,
    height: 1.44,
    wheelR: 0.36,
    maxSpeed: 62,
    accel: 13.5,
    mass: 1.1,
    grip: 1.15,
    plate: 'green',
    topSpeedKmh: 240,
  },
  vip: {
    type: 'vip',
    displayName: 'Phantom LWB',
    length: 5.6,
    width: 2.0,
    height: 1.5,
    wheelR: 0.37,
    maxSpeed: 60,
    accel: 9.5,
    mass: 1.6,
    grip: 1.05,
    plate: 'black',
    topSpeedKmh: 235,
  },
  super: {
    type: 'super',
    displayName: 'Aurelia GT-X',
    length: 4.6,
    width: 2.02,
    height: 1.2,
    wheelR: 0.36,
    maxSpeed: 95,
    accel: 18,
    mass: 0.95,
    grip: 1.35,
    plate: 'black',
    topSpeedKmh: 340,
  },
};

const PLATE_BG: Record<PlateColor, string> = {
  yellow: '#f2c114',
  green: '#1f9d55',
  white: '#f2f2f0',
  black: '#141416',
};
const PLATE_FG: Record<PlateColor, string> = {
  yellow: '#181818',
  green: '#f4fff7',
  white: '#16181c',
  black: '#e8e6df',
};

export const CAR_PAINT = [
  0x0d0f12, 0xf2f3f5, 0x9aa3ad, 0x2a3f6b, 0x6d1f22, 0x1d4d3a, 0xb4b9bf,
  0x3b3f47, 0x8c5a2b, 0x2f6f7d, 0xe0e3e6, 0x101820,
];

export class Vehicle {
  group = new THREE.Group();
  spec: VehicleSpec;
  wheels: THREE.Group[] = [];
  frontWheels: THREE.Group[] = [];
  body!: THREE.Group;
  headlights: THREE.Mesh[] = [];
  taillights: THREE.Mesh[] = [];
  headlightSpot: THREE.SpotLight | null = null;
  plateMesh!: THREE.Mesh;
  sirenLights: THREE.Mesh[] = [];
  private glassMat!: THREE.MeshStandardMaterial;
  private headlightMat!: THREE.MeshStandardMaterial;
  private taillightMat!: THREE.MeshStandardMaterial;

  // physics
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  heading = 0;
  speed = 0;
  steer = 0;
  throttle = 0;
  brake = 0;
  wheelSpin = 0;
  rpm = 0.15;
  health = 100;
  onGround = true;
  isPolice = false;
  isPlayer = false;
  sirenOn = false;
  private sirenT = 0;
  private bodyGroup!: THREE.Group;

  constructor(type: string, color: number, plateText: string, isPolice = false) {
    this.spec = VEHICLE_SPECS[type] ?? VEHICLE_SPECS.sedan;
    this.isPolice = isPolice;
    this.build(color, plateText);
  }

  private build(color: number, plateText: string) {
    const s = this.spec;
    const paint = new THREE.MeshStandardMaterial({
      color,
      metalness: 0.62,
      roughness: 0.28,
    });
    const dark = new THREE.MeshStandardMaterial({ color: 0x14161a, roughness: 0.55, metalness: 0.3 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xd8dbe0, metalness: 1, roughness: 0.14 });
    this.glassMat = new THREE.MeshStandardMaterial({
      color: 0x101820,
      metalness: 0.4,
      roughness: 0.06,
      transparent: true,
      opacity: 0.52,
    });

    const bodyRoot = new THREE.Group();
    bodyRoot.position.y = 0.42;
    this.group.add(bodyRoot);
    this.body = bodyRoot;
    this.bodyGroup = bodyRoot;

    const L = s.length;
    const W = s.width;
    const H = s.height;

    if (s.type === 'bus') {
      const shell = new THREE.Mesh(new RoundedBoxGeometry(W, H, L, 3, 0.22), paint);
      shell.position.y = H / 2 - 0.1;
      shell.castShadow = true;
      bodyRoot.add(shell);
      const winMat = this.glassMat;
      for (let i = 0; i < 6; i++) {
        const win = new THREE.Mesh(new RoundedBoxGeometry(W + 0.03, 0.85, 1.6, 2, 0.08), winMat);
        win.position.set(0, H * 0.62, -L / 2 + 1.6 + i * 1.7);
        bodyRoot.add(win);
      }
      const windshield = new THREE.Mesh(new RoundedBoxGeometry(W - 0.16, 1.0, 0.1, 2, 0.06), winMat);
      windshield.position.set(0, H * 0.62, L / 2 + 0.02);
      bodyRoot.add(windshield);
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(W + 0.04, 0.3, L - 0.2), chrome);
      stripe.position.y = H * 0.3;
      bodyRoot.add(stripe);
    } else if (s.type === 'suv' || s.type === 'van') {
      const lower = new THREE.Mesh(new RoundedBoxGeometry(W, H * 0.5, L, 3, 0.2), paint);
      lower.position.y = H * 0.28;
      lower.castShadow = true;
      bodyRoot.add(lower);
      const upper = new THREE.Mesh(new RoundedBoxGeometry(W - 0.16, H * 0.56, L * 0.55, 3, 0.2), paint);
      upper.position.set(0, H * 0.52, -L * 0.08);
      upper.castShadow = true;
      bodyRoot.add(upper);
      const glassBand = new THREE.Mesh(
        new RoundedBoxGeometry(W - 0.1, H * 0.3, L * 0.56, 2, 0.08),
        this.glassMat
      );
      glassBand.position.set(0, H * 0.62, -L * 0.08);
      bodyRoot.add(glassBand);
      if (s.type === 'van') {
        const rear = new THREE.Mesh(new RoundedBoxGeometry(W - 0.06, H * 0.42, L * 0.42, 2, 0.1), paint);
        rear.position.set(0, H * 0.72, -L * 0.32);
        bodyRoot.add(rear);
      }
    } else {
      // sedan / coupe / sports silhouette
      const isSport = s.type === 'm8' || s.type === 'super';
      const beltline = H * 0.52;
      const lower = new THREE.Mesh(new RoundedBoxGeometry(W, beltline, L, 4, isSport ? 0.26 : 0.2), paint);
      lower.position.y = beltline / 2;
      lower.castShadow = true;
      bodyRoot.add(lower);

      const hoodLen = isSport ? L * 0.42 : L * 0.36;
      const cabinLen = isSport ? L * 0.4 : L * 0.46;
      const cabinZ = -L * 0.02;
      const roofH = H - beltline;
      const cabin = new THREE.Mesh(
        new RoundedBoxGeometry(W - 0.22, roofH, cabinLen, 4, 0.18),
        this.glassMat
      );
      cabin.position.set(0, beltline + roofH / 2 - 0.03, cabinZ);
      cabin.castShadow = true;
      bodyRoot.add(cabin);

      // roof panel (opaque) over the cabin
      const roof = new THREE.Mesh(
        new RoundedBoxGeometry(W - 0.34, 0.09, cabinLen * 0.82, 3, 0.06),
        paint
      );
      roof.position.set(0, beltline + roofH - 0.02, cabinZ - 0.03);
      roof.castShadow = true;
      bodyRoot.add(roof);

      // hood & trunk shaping
      const hood = new THREE.Mesh(new RoundedBoxGeometry(W - 0.08, 0.16, hoodLen, 3, 0.1), paint);
      hood.position.set(0, beltline + 0.02, L / 2 - hoodLen / 2 - 0.05);
      hood.castShadow = true;
      bodyRoot.add(hood);
      const trunk = new THREE.Mesh(new RoundedBoxGeometry(W - 0.14, 0.14, L * 0.2, 3, 0.08), paint);
      trunk.position.set(0, beltline + 0.01, -L / 2 + L * 0.1 + 0.04);
      trunk.castShadow = true;
      bodyRoot.add(trunk);

      if (isSport) {
        // side skirts + aggressive splitter + spoiler
        const skirt = new THREE.Mesh(new RoundedBoxGeometry(W + 0.05, 0.16, L * 0.55, 2, 0.05), dark);
        skirt.position.set(0, 0.14, 0.02);
        bodyRoot.add(skirt);
        const splitter = new THREE.Mesh(new RoundedBoxGeometry(W - 0.1, 0.07, 0.4, 2, 0.03), dark);
        splitter.position.set(0, 0.09, L / 2 - 0.1);
        bodyRoot.add(splitter);
        const spoilerPost = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.16, 0.1), dark);
        [-0.5, 0.5].forEach((sx) => {
          const p = spoilerPost.clone();
          p.position.set(sx * (W / 2 - 0.35), beltline + 0.14, -L / 2 + 0.32);
          bodyRoot.add(p);
        });
        const wing = new THREE.Mesh(new RoundedBoxGeometry(W - 0.2, 0.05, 0.34, 2, 0.02), dark);
        wing.position.set(0, beltline + 0.22, -L / 2 + 0.3);
        wing.castShadow = true;
        bodyRoot.add(wing);
        // hood vents
        for (let i = 0; i < 2; i++) {
          const vent = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.03, 0.5), dark);
          vent.position.set((i === 0 ? -1 : 1) * 0.32, beltline + 0.1, L / 2 - hoodLen * 0.55);
          bodyRoot.add(vent);
        }
      }

      // grille
      const grille = new THREE.Mesh(new RoundedBoxGeometry(W * 0.62, 0.2, 0.08, 2, 0.04), dark);
      grille.position.set(0, beltline * 0.55, L / 2 + 0.01);
      bodyRoot.add(grille);
      const intake = new THREE.Mesh(new RoundedBoxGeometry(W * 0.8, 0.16, 0.07, 2, 0.03), dark);
      intake.position.set(0, 0.14, L / 2 + 0.01);
      bodyRoot.add(intake);
      // side mirrors
      [-1, 1].forEach((sx) => {
        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 0.05), dark);
        arm.position.set(sx * (W / 2 - 0.05), beltline + 0.12, cabinZ + cabinLen / 2 - 0.05);
        bodyRoot.add(arm);
        const mir = new THREE.Mesh(new RoundedBoxGeometry(0.08, 0.12, 0.18, 2, 0.03), paint);
        mir.position.set(sx * (W / 2 + 0.06), beltline + 0.13, cabinZ + cabinLen / 2 - 0.05);
        bodyRoot.add(mir);
        // door handles
        const dh = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.05, 0.18), chrome);
        dh.position.set(sx * (W / 2 + 0.005), beltline * 0.72, cabinZ - 0.1);
        bodyRoot.add(dh);
      });
      // interior: seats + wheel
      const seatMat = new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: 0.85 });
      [-1, 1].forEach((sx) => {
        const seat = new THREE.Mesh(new RoundedBoxGeometry(0.46, 0.5, 0.2, 2, 0.06), seatMat);
        seat.position.set(sx * 0.36, beltline + 0.18, cabinZ - 0.25);
        bodyRoot.add(seat);
      });
      const dash = new THREE.Mesh(new RoundedBoxGeometry(W - 0.4, 0.2, 0.3, 2, 0.05), seatMat);
      dash.position.set(0, beltline + 0.1, cabinZ + cabinLen / 2 - 0.2);
      bodyRoot.add(dash);
      const wheelMesh = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.025, 8, 18), dark);
      wheelMesh.position.set(-0.36, beltline + 0.16, cabinZ + cabinLen / 2 - 0.28);
      wheelMesh.rotation.x = -0.4;
      bodyRoot.add(wheelMesh);
      this.steeringWheel = wheelMesh;
    }

    // headlights
    this.headlightMat = new THREE.MeshStandardMaterial({
      color: 0xfff4dd,
      emissive: 0xfff0cc,
      emissiveIntensity: 0.25,
      roughness: 0.15,
      metalness: 0.1,
    });
    const hlY = s.type === 'bus' || s.type === 'van' || s.type === 'suv' ? H * 0.55 : H * 0.55;
    const hlZ = L / 2 + 0.02;
    const hlSize = s.type === 'bus' ? 0.28 : 0.3;
    [-1, 1].forEach((sx) => {
      const hl = new THREE.Mesh(
        new RoundedBoxGeometry(hlSize, hlSize * 0.55, 0.08, 2, 0.03),
        this.headlightMat
      );
      hl.position.set(sx * (W / 2 - hlSize * 0.85), hlY, hlZ);
      bodyRoot.add(hl);
      this.headlights.push(hl);
    });

    // tail lights
    this.taillightMat = new THREE.MeshStandardMaterial({
      color: 0x6a0d0d,
      emissive: 0xff2200,
      emissiveIntensity: 0.5,
      roughness: 0.3,
    });
    [-1, 1].forEach((sx) => {
      const tl = new THREE.Mesh(
        new RoundedBoxGeometry(s.type === 'bus' ? 0.5 : 0.36, 0.14, 0.06, 2, 0.02),
        this.taillightMat
      );
      tl.position.set(sx * (W / 2 - 0.3), hlY * 0.92, -L / 2 - 0.01);
      bodyRoot.add(tl);
      this.taillights.push(tl);
    });

    // wheels
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x121316, roughness: 0.92 });
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xb9bec6, metalness: 0.95, roughness: 0.22 });
    const wr = s.wheelR;
    const ww = s.type === 'm8' || s.type === 'super' ? 0.3 : 0.24;
    const axleZ = s.length * (s.type === 'bus' ? 0.36 : 0.33);
    const axleX = s.width / 2 - ww / 2 - 0.06;
    const positions: [number, number][] = [
      [-axleX, axleZ],
      [axleX, axleZ],
      [-axleX, -axleZ],
      [axleX, -axleZ],
    ];
    positions.forEach(([x, z], i) => {
      const pivot = new THREE.Group();
      pivot.position.set(x, wr, z);
      bodyRoot.add(pivot);
      const tire = new THREE.Mesh(new THREE.CylinderGeometry(wr, wr, ww, 18), tireMat);
      tire.rotation.z = Math.PI / 2;
      tire.castShadow = true;
      pivot.add(tire);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(wr * 0.62, wr * 0.62, ww + 0.01, 12), rimMat);
      rim.rotation.z = Math.PI / 2;
      pivot.add(rim);
      for (let k = 0; k < 5; k++) {
        const spoke = new THREE.Mesh(new THREE.BoxGeometry(ww + 0.02, wr * 0.95, 0.05), rimMat);
        spoke.rotation.x = (k / 5) * Math.PI;
        pivot.add(spoke);
      }
      // wheel arch shadow
      this.wheels.push(pivot);
      if (i < 2) this.frontWheels.push(pivot);
    });

    // license plate (rear)
    const plateBg = PLATE_BG[s.plate];
    const plateTex = plateTexture(plateText, plateBg, PLATE_FG[s.plate]);
    const plateMat = new THREE.MeshStandardMaterial({
      map: plateTex,
      roughness: 0.5,
      metalness: 0.1,
    });
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.52, 0.13), plateMat);
    plate.position.set(0, s.type === 'bus' ? 0.55 : 0.55, -L / 2 - 0.045);
    plate.rotation.y = Math.PI;
    bodyRoot.add(plate);
    this.plateMesh = plate;

    if (this.isPolice) {
      const bar = new THREE.Mesh(
        new RoundedBoxGeometry(W * 0.8, 0.08, 0.22, 2, 0.03),
        new THREE.MeshStandardMaterial({ color: 0x1a1c20, roughness: 0.6 })
      );
      bar.position.set(0, H * 0.62, 0.1);
      bodyRoot.add(bar);
      const red = new THREE.MeshStandardMaterial({
        color: 0xff2222,
        emissive: 0xff0000,
        emissiveIntensity: 1,
      });
      const blue = new THREE.MeshStandardMaterial({
        color: 0x2255ff,
        emissive: 0x0044ff,
        emissiveIntensity: 1,
      });
      const rl = new THREE.Mesh(new RoundedBoxGeometry(0.3, 0.12, 0.2, 2, 0.04), red);
      rl.position.set(-0.3, H * 0.68, 0.1);
      const bl = new THREE.Mesh(new RoundedBoxGeometry(0.3, 0.12, 0.2, 2, 0.04), blue);
      bl.position.set(0.3, H * 0.68, 0.1);
      bodyRoot.add(rl, bl);
      this.sirenLights.push(rl, bl);
    }

    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = false;
      }
    });
  }

  private steeringWheel?: THREE.Object3D;

  addHeadlightSpot() {
    if (this.headlightSpot) return;
    const s = this.spec;
    const spot = new THREE.SpotLight(0xfff0d0, 0, 60, 0.52, 0.45, 1.4);
    spot.position.set(0, s.height * 0.55, s.length / 2);
    const target = new THREE.Object3D();
    target.position.set(0, -0.6, s.length / 2 + 22);
    this.group.add(spot);
    this.group.add(target);
    spot.target = target;
    this.headlightSpot = spot;
  }

  setLightsOn(on: boolean) {
    this.headlightMat.emissiveIntensity = on ? 2.6 : 0.2;
    if (this.headlightSpot) this.headlightSpot.intensity = on ? 6 : 0;
  }

  setBrake(on: boolean) {
    this.taillightMat.emissiveIntensity = on ? 3.2 : 0.5;
  }

  updateVisual(dt: number, time: number) {
    void time;
    // wheel spin + steer
    this.wheelSpin += (this.speed / Math.max(0.1, this.spec.wheelR)) * dt;
    for (const w of this.wheels) w.rotation.x = this.wheelSpin;
    const steerAngle = this.steer * 0.52;
    this.frontWheels.forEach((w) => (w.rotation.y = steerAngle));
    if (this.steeringWheel) this.steeringWheel.rotation.z = -this.steer * 1.6;
    // body roll / pitch (suspension)
    const targetRoll = -this.steer * clamp(Math.abs(this.speed) / 30, 0, 1) * 0.09;
    const targetPitch = clamp(this.throttle * 0.02, -0.05, 0.05);
    this.bodyGroup.rotation.z = damp(this.bodyGroup.rotation.z, targetRoll, 8, dt);
    this.bodyGroup.rotation.x = damp(this.bodyGroup.rotation.x, targetPitch, 8, dt);
    // siren flash
    if (this.sirenLights.length === 2) {
      this.sirenT += dt;
      const on = this.sirenOn && Math.sin(this.sirenT * 9) > 0;
      (this.sirenLights[0].material as THREE.MeshStandardMaterial).emissiveIntensity = on ? 4 : 0.2;
      (this.sirenLights[1].material as THREE.MeshStandardMaterial).emissiveIntensity =
        !on && this.sirenOn ? 4 : 0.2;
    }
  }

  get kmh() {
    return Math.abs(this.speed) * 3.6;
  }

  forward(out = new THREE.Vector3()) {
    return out.set(Math.sin(this.heading), 0, Math.cos(this.heading));
  }
}
