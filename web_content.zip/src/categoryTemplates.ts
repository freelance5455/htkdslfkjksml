import type { Category } from './types';

export interface CategoryFeatureTemplate {
  subCategoryLabel: string;
  subCategories: string[];
  brandLabel: string;
  brands: string[];
  modelLabel: string;
  modelsByBrand?: Record<string, string[]>;
  genericModels: string[];
  variantLabel: string;
  variants: string[];
  defaultUnit: string;
  units: string[];
  isWeightedDefault?: boolean;
}

export const ALL_UNITS = ['pcs', 'kg', 'g', 'L', 'ml', 'pack', 'box', 'dozen', 'meter', 'pair', 'set'];

const PHONE_MODELS_BY_BRAND: Record<string, string[]> = {
  Samsung: [
    'Galaxy A05',
    'Galaxy A05s',
    'Galaxy A14',
    'Galaxy A15',
    'Galaxy A24',
    'Galaxy A25',
    'Galaxy A34',
    'Galaxy A35',
    'Galaxy A54',
    'Galaxy A55',
    'Galaxy M14',
    'Galaxy M34',
    'Galaxy F14',
    'Galaxy S23 Ultra',
    'Galaxy S24',
    'Galaxy S24 Ultra',
  ],
  'Apple iPhone': [
    'iPhone X / XS',
    'iPhone 11',
    'iPhone 11 Pro Max',
    'iPhone 12',
    'iPhone 12 Pro Max',
    'iPhone 13',
    'iPhone 13 Pro',
    'iPhone 13 Pro Max',
    'iPhone 14',
    'iPhone 14 Pro Max',
    'iPhone 15',
    'iPhone 15 Pro',
    'iPhone 15 Pro Max',
    'iPhone 16',
    'iPhone 16 Pro Max',
  ],
  'Xiaomi / Redmi': [
    'Redmi 12',
    'Redmi 13C',
    'Redmi A3',
    'Redmi Note 11',
    'Redmi Note 12',
    'Redmi Note 13',
    'Redmi Note 13 Pro',
    'Redmi Note 13 Pro+',
    'Poco C65',
    'Poco M6 Pro',
    'Poco X6 Pro',
  ],
  Realme: [
    'Realme C51',
    'Realme C53',
    'Realme C55',
    'Realme C65',
    'Realme C67',
    'Realme 11',
    'Realme 12',
    'Realme 12 Pro',
    'Narzo N53',
  ],
  Oppo: [
    'Oppo A17',
    'Oppo A18',
    'Oppo A38',
    'Oppo A58',
    'Oppo A78',
    'Oppo A79',
    'Oppo Reno 10',
    'Oppo Reno 11',
    'Oppo F25 Pro',
  ],
  Vivo: [
    'Vivo Y02t',
    'Vivo Y17s',
    'Vivo Y27',
    'Vivo Y28',
    'Vivo Y36',
    'Vivo V27',
    'Vivo V29',
    'Vivo V30',
  ],
  OnePlus: [
    'OnePlus Nord CE 3 Lite',
    'OnePlus Nord CE 4',
    'OnePlus Nord 3',
    'OnePlus 11R',
    'OnePlus 12',
    'OnePlus 12R',
  ],
  Infinix: ['Smart 8', 'Hot 30', 'Hot 40', 'Hot 40 Pro', 'Note 30', 'Note 40 Pro'],
  Tecno: ['Pop 8', 'Spark 10', 'Spark 20', 'Spark 20 Pro', 'Camon 20', 'Camon 30'],
  Itel: ['A70', 'P55', 'S23', 'S23 Plus'],
  'Google Pixel': ['Pixel 6a', 'Pixel 7', 'Pixel 7a', 'Pixel 8', 'Pixel 8 Pro', 'Pixel 9'],
};

const CATEGORY_TEMPLATES: Record<string, CategoryFeatureTemplate> = {
  'Mobile & Gadgets': {
    subCategoryLabel: 'Item Type (e.g. Back Cover, Glass, Charger)',
    subCategories: [
      'Back Cover / Case',
      'Tempered Glass / Screen Protector',
      'Fast Charger / Adapter',
      'Data / Charging Cable',
      'TWS / Earphones',
      'Power Bank',
      'Phone Stand / Holder',
      'Memory Card / Pen Drive',
      'Smart Watch / Strap',
    ],
    brandLabel: 'Phone / Gadget Brand',
    brands: [
      'Samsung',
      'Apple iPhone',
      'Xiaomi / Redmi',
      'Realme',
      'Oppo',
      'Vivo',
      'OnePlus',
      'Infinix',
      'Tecno',
      'Itel',
      'Google Pixel',
      'Baseus',
      'Anker',
      'Ugreen',
      'Oraimo',
    ],
    modelLabel: 'Phone / Device Model',
    modelsByBrand: PHONE_MODELS_BY_BRAND,
    genericModels: ['Universal', 'Type-C', 'Lightning', 'Micro-USB', '10000mAh', '20000mAh', '20W', '33W', '65W'],
    variantLabel: 'Cover Material / Color / Spec',
    variants: [
      'Silicone',
      'Clear Transparent',
      'Shockproof Armor',
      'MagSafe Magnetic',
      'Leather Flip',
      'Matte Hard',
      'Camera Lens Guard',
      'Black',
      'Blue',
      'Green',
      'Pink',
    ],
    defaultUnit: 'pcs',
    units: ['pcs', 'box', 'pack'],
  },
  Electronics: {
    subCategoryLabel: 'Product Type',
    subCategories: [
      'Bluetooth Speaker',
      'Headphone / Earbud',
      'WiFi Router',
      'Smart TV / Monitor',
      'Electric Kettle / Iron',
      'Mini / Rechargeable Fan',
      'Extension Board / Multiplug',
      'Calculator / Torch',
    ],
    brandLabel: 'Brand',
    brands: ['Samsung', 'Sony', 'JBL', 'Xiaomi', 'TP-Link', 'Walton', 'Vision', 'Havit', 'Awei', 'Logitech'],
    modelLabel: 'Model / Wattage',
    genericModels: ['Standard', 'Pro', 'Mini', 'Wireless', 'Bluetooth 5.3', 'Dual Band', 'Heavy Duty'],
    variantLabel: 'Color / Power Spec',
    variants: ['Black', 'White', 'Silver', 'Rechargeable', 'AC/DC', '1 Year Warranty'],
    defaultUnit: 'pcs',
    units: ['pcs', 'box', 'set'],
  },
  Accessories: {
    subCategoryLabel: 'Accessory Type',
    subCategories: ['Back Cover', 'Cable', 'Adapter', 'Screen Glass', 'Earphone', 'OTG / Hub', 'Pouch / Sleeve'],
    brandLabel: 'Brand',
    brands: ['Samsung', 'Apple iPhone', 'Xiaomi / Redmi', 'Realme', 'Baseus', 'Ugreen', 'Anker', 'Hoco', 'Remax'],
    modelLabel: 'Compatible Model / Length',
    modelsByBrand: PHONE_MODELS_BY_BRAND,
    genericModels: ['1 Meter', '1.5 Meter', '2 Meter', 'Type-C to Type-C', 'USB to Type-C', 'Lightning', 'Universal'],
    variantLabel: 'Color / Style',
    variants: ['Black', 'White', 'Clear', 'Braided', 'Silicone', 'Matte'],
    defaultUnit: 'pcs',
    units: ['pcs', 'pack', 'box'],
  },
  Groceries: {
    subCategoryLabel: 'Grocery Type',
    subCategories: [
      'Rice & Grains',
      'Cooking Oil',
      'Lentils / Dal',
      'Loose Biscuits / Dry Food',
      'Sugar & Salt',
      'Atta / Flour / Suji',
      'Spices & Masala',
      'Noodles & Pasta',
      'Tea & Milk Powder',
    ],
    brandLabel: 'Brand / Origin',
    brands: ['ACI Pure', 'Teer', 'Fresh', 'Rupchanda', 'Pran', 'Radhuni', 'Bashundhara', 'Chashi', 'Ispahani', 'Open / Loose'],
    modelLabel: 'Pack Size / Weight',
    genericModels: ['Loose (per kg)', '100g', '250g', '500g', '1kg', '2kg', '5kg', '1L', '2L', '5L'],
    variantLabel: 'Grade / Type',
    variants: ['Miniket', 'Nazirshail', 'Chinigura', 'Basmati', 'Soybean', 'Mustard', 'Moshur', 'Loose / Bulk', 'Standard Pack'],
    defaultUnit: 'kg',
    units: ['kg', 'g', 'L', 'ml', 'pack', 'pcs', 'box'],
    isWeightedDefault: true,
  },
  'Beverages & Snacks': {
    subCategoryLabel: 'Drink / Snack Type',
    subCategories: [
      'Juice / Fruit Drink',
      'Soft Drink / Soda',
      'Energy Drink',
      'Mineral Water',
      'Biscuits (Loose / per kg)',
      'Biscuits & Cookies (Pack)',
      'Chips & Chanachur',
      'Chocolate & Wafer',
      'Tea & Coffee',
    ],
    brandLabel: 'Brand',
    brands: ['Frutika', 'Pran', 'Coca-Cola', 'Pepsi', 'Sprite', '7Up', 'Mojo', 'Speed', 'Fresh', 'Mum', 'Olympic', 'Haque', 'Danish', 'Bombay Sweets', 'Ruchi', 'Nestle'],
    modelLabel: 'Volume / Pack Size',
    genericModels: ['150ml', '200ml', '250ml', '400ml', '500ml', '1L', '1.25L', '2L', 'Small Pack', 'Family Pack', 'Loose (per kg)'],
    variantLabel: 'Flavor / Container',
    variants: ['Mango', 'Orange', 'Apple', 'Litchi', 'Lemon', 'Cola', 'PET Bottle', 'Can', 'Tetra Pack', 'Plain Biscuit', 'Cream Biscuit', 'Spicy'],
    defaultUnit: 'pcs',
    units: ['pcs', 'kg', 'g', 'L', 'ml', 'pack', 'box'],
    isWeightedDefault: true,
  },
  'Bakery & Dairy': {
    subCategoryLabel: 'Bakery / Dairy Type',
    subCategories: ['Biscuits / Cookies (kg)', 'Toast / Rusk', 'Bread & Bun', 'Cake & Pastry', 'Liquid Milk', 'Powder Milk', 'Yogurt / Doi', 'Butter & Ghee'],
    brandLabel: 'Brand / Bakery',
    brands: ['Aarong Dairy', 'Milk Vita', 'Pran Dairy', 'Danish', 'Olympic', 'Well Food', 'Coopers', 'All Time', 'Local Bakery'],
    modelLabel: 'Weight / Pack Size',
    genericModels: ['Loose (per kg)', '200g', '250g', '400g', '500g', '1kg', '250ml', '500ml', '1L'],
    variantLabel: 'Flavor / Freshness',
    variants: ['Butter', 'Chocolate', 'Plain', 'Sweet', 'Salted', 'Low Fat', 'Full Cream', 'Fresh Daily'],
    defaultUnit: 'pcs',
    units: ['pcs', 'kg', 'g', 'L', 'ml', 'pack', 'box'],
    isWeightedDefault: true,
  },
  Cosmetics: {
    subCategoryLabel: 'Cosmetic Type',
    subCategories: ['Face Wash', 'Cream / Moisturizer', 'Body Lotion', 'Serum / Toner', 'Perfume / Body Spray', 'Lipstick / Makeup', 'Hair Oil / Shampoo', 'Sunscreen'],
    brandLabel: 'Brand',
    brands: ['Ponds', 'Nivea', 'Vaseline', 'Garnier', 'L\'Oreal', 'Dove', 'Himalaya', 'Parachute', 'Sunsilk', 'Fogg', 'Axe', 'Lakme', 'Biotique'],
    modelLabel: 'Net Volume / Weight',
    genericModels: ['30ml', '50ml', '100ml', '150ml', '200ml', '400ml', '25g', '50g', '100g'],
    variantLabel: 'Skin Type / Shade / Scent',
    variants: ['All Skin', 'Oily Skin', 'Dry Skin', 'Brightening', 'Matte', 'Natural', 'Rose', 'Aloe Vera', 'Men', 'Women'],
    defaultUnit: 'pcs',
    units: ['pcs', 'pack', 'box'],
  },
  'Personal Care & Hygiene': {
    subCategoryLabel: 'Care Type',
    subCategories: ['Bath Soap', 'Toothpaste & Brush', 'Shampoo & Conditioner', 'Hand Wash & Sanitizer', 'Tissue & Wipes', 'Shaving & Razor', 'Deodorant'],
    brandLabel: 'Brand',
    brands: ['Lux', 'Lifebuoy', 'Dettol', 'Savlon', 'Pepsodent', 'CloseUp', 'Colgate', 'Clear', 'Head & Shoulders', 'Bashundhara', 'Gillette'],
    modelLabel: 'Pack / Weight',
    genericModels: ['50g', '75g', '100g', '150g', '100ml', '200ml', '400ml', 'Single', 'Combo Pack'],
    variantLabel: 'Variant / Scent',
    variants: ['Original', 'Lemon', 'Menthol / Cool', 'Herbal', 'Sensitive', 'Family Pack'],
    defaultUnit: 'pcs',
    units: ['pcs', 'pack', 'dozen', 'box'],
  },
  'Fashion & Clothing': {
    subCategoryLabel: 'Garment Type',
    subCategories: ['T-Shirt / Polo', 'Casual / Formal Shirt', 'Panjabi / Kurta', 'Jeans / Trouser', 'Saree / Three-Piece', 'Kids Wear', 'Hoodie / Jacket', 'Socks / Innerwear'],
    brandLabel: 'Brand / Label',
    brands: ['Aarong', 'Yellow', 'Ecstasy', 'Richman', 'Apex', 'Export Quality', 'Local Boutique'],
    modelLabel: 'Size',
    genericModels: ['S', 'M', 'L', 'XL', 'XXL', 'Free Size', '28', '30', '32', '34', '36'],
    variantLabel: 'Color / Fabric',
    variants: ['100% Cotton', 'Denim', 'Linen', 'Polyester', 'Black', 'White', 'Navy Blue', 'Grey', 'Maroon'],
    defaultUnit: 'pcs',
    units: ['pcs', 'pair', 'set', 'pack'],
  },
  'Footwear & Bags': {
    subCategoryLabel: 'Footwear / Bag Type',
    subCategories: ['Sneakers / Casual Shoes', 'Formal Shoes', 'Sandals / Slippers', 'School Bag / Backpack', 'Ladies Handbag', 'Wallet / Belt'],
    brandLabel: 'Brand',
    brands: ['Bata', 'Apex', 'Lotto', 'Nike', 'Adidas', 'Bay', 'President', 'Local Leather'],
    modelLabel: 'Size',
    genericModels: ['36', '37', '38', '39', '40', '41', '42', '43', '44', 'Standard', 'Medium', 'Large'],
    variantLabel: 'Color / Material',
    variants: ['Leather', 'Synthetic', 'Canvas', 'Rubber', 'Black', 'Brown', 'White', 'Tan'],
    defaultUnit: 'pair',
    units: ['pair', 'pcs', 'box'],
  },
  'Health & Pharmacy': {
    subCategoryLabel: 'Medicine / Health Type',
    subCategories: ['Tablet / Capsule', 'Syrup / Suspension', 'Ointment / Gel', 'Antiseptic / Bandage', 'Vitamin / Supplement', 'Surgical / Mask'],
    brandLabel: 'Pharma / Brand',
    brands: ['Square', 'Beximco', 'Incepta', 'Renata', 'Acme', 'ACI', 'Opsonin', 'Eskayef', 'Savlon'],
    modelLabel: 'Strength / Volume',
    genericModels: ['10mg', '20mg', '50mg', '100mg', '500mg', '60ml', '100ml', '1 Strip (10 pcs)', '1 Box'],
    variantLabel: 'Packaging / Usage',
    variants: ['Adult', 'Pediatric / Kids', 'OTC', 'Sugar Free', 'Per Strip', 'Per Piece'],
    defaultUnit: 'pcs',
    units: ['pcs', 'pack', 'box'],
  },
  'Hardware & Tools': {
    subCategoryLabel: 'Tool / Hardware Type',
    subCategories: ['Screwdriver / Wrench', 'Hammer / Pliers', 'Drill / Cutter', 'Padlock / Door Lock', 'Nuts, Bolts & Screws', 'Glue / Tape / Sealant', 'Paint & Brush'],
    brandLabel: 'Brand',
    brands: ['Total', 'Ingco', 'Bosch', 'Makita', 'RFL', 'Super Glue', '3M', 'Local Heavy'],
    modelLabel: 'Size / Spec',
    genericModels: ['Small', 'Medium', 'Large', '4 inch', '6 inch', '8 inch', '12 inch', 'Heavy Duty', 'Per kg'],
    variantLabel: 'Material / Finish',
    variants: ['Stainless Steel', 'Carbon Steel', 'Brass', 'PVC', 'Waterproof'],
    defaultUnit: 'pcs',
    units: ['pcs', 'kg', 'box', 'set', 'pack'],
    isWeightedDefault: true,
  },
  'Electrical & Lighting': {
    subCategoryLabel: 'Electrical Item',
    subCategories: ['LED Bulb', 'Tube Light / Panel', 'Switch & Socket', 'Circuit Breaker (MCB)', 'Electric Wire / Cable', 'Multi-Plug / Board', 'Holder & Regulator'],
    brandLabel: 'Brand',
    brands: ['Super Star', 'Walton', 'BRB Cable', 'BBS Cable', 'Click', 'Energypac', 'Philips', 'Havells'],
    modelLabel: 'Wattage / Rating',
    genericModels: ['5W', '9W', '12W', '15W', '20W', '30W', '10A', '16A', '32A', '1.5mm', '2.5mm'],
    variantLabel: 'Color / Light Tone',
    variants: ['Daylight White', 'Warm White', 'Pin Type (B22)', 'Screw Type (E27)', 'Copper Wire', 'Fireproof'],
    defaultUnit: 'pcs',
    units: ['pcs', 'meter', 'box', 'pack'],
  },
  'Fruits & Vegetables': {
    subCategoryLabel: 'Produce Type',
    subCategories: ['Fresh Fruits', 'Leafy Vegetables', 'Root Vegetables (Potato/Onion)', 'Cooking Herbs / Chili / Garlic'],
    brandLabel: 'Origin / Grade',
    brands: ['Local Fresh', 'Organic', 'Imported', 'Premium Grade A'],
    modelLabel: 'Weight Unit',
    genericModels: ['Per kg', '500g', '1kg', '2kg', '5kg', 'Per Dozen', 'Per Piece'],
    variantLabel: 'Grade / Ripeness',
    variants: ['Fresh Harvest', 'Large Size', 'Medium Size', 'Ripe', 'Sweet'],
    defaultUnit: 'kg',
    units: ['kg', 'g', 'dozen', 'pcs'],
    isWeightedDefault: true,
  },
  'Frozen & Meat': {
    subCategoryLabel: 'Frozen / Meat Type',
    subCategories: ['Chicken / Poultry', 'Beef / Mutton', 'Fish / Seafood', 'Frozen Snacks (Nuggets/Paratha)', 'Ice Cream'],
    brandLabel: 'Brand',
    brands: ['Kazi Farms', 'CP', 'Aftab', 'Golden Harvest', 'Igloo', 'Polar', 'Fresh Cut'],
    modelLabel: 'Weight / Pack',
    genericModels: ['250g', '500g', '1kg', 'Per kg', 'Family Tub'],
    variantLabel: 'Cut / Flavor',
    variants: ['Curry Cut', 'Boneless', 'Whole', 'Halal Fresh', 'Vanilla', 'Chocolate', 'Mango'],
    defaultUnit: 'kg',
    units: ['kg', 'g', 'pack', 'pcs'],
    isWeightedDefault: true,
  },
};

const GENERIC_TEMPLATE: CategoryFeatureTemplate = {
  subCategoryLabel: 'Sub-Category / Product Type',
  subCategories: ['Standard', 'Premium', 'Budget', 'Loose / Bulk', 'Gift Pack', 'Combo'],
  brandLabel: 'Brand / Manufacturer',
  brands: ['Generic / Local', 'RFL', 'Pran', 'Walton', 'Fresh', 'Apex', 'Imported'],
  modelLabel: 'Model / Size / Weight',
  genericModels: ['Standard', 'Small', 'Medium', 'Large', '100g', '250g', '500g', '1kg', '1L', 'Pack'],
  variantLabel: 'Color / Spec / Flavor',
  variants: ['Standard', 'Black', 'White', 'Blue', 'Red', 'Original', 'Special'],
  defaultUnit: 'pcs',
  units: ALL_UNITS,
};

export const getCategoryTemplate = (categoryName: string, categories?: Category[]): CategoryFeatureTemplate => {
  const exact = CATEGORY_TEMPLATES[categoryName];
  const matchedCat = categories?.find((c) => c.name.toLowerCase() === categoryName.toLowerCase());
  const customModels = matchedCat?.models || [];

  if (exact) {
    return {
      ...exact,
      genericModels: Array.from(new Set([...customModels, ...exact.genericModels])),
    };
  }

  // Smart fuzzy fallback for sub-categories by name keywords
  const lower = (categoryName || '').toLowerCase();
  let base = GENERIC_TEMPLATE;
  if (lower.includes('mobile') || lower.includes('phone') || lower.includes('gadget')) base = CATEGORY_TEMPLATES['Mobile & Gadgets'];
  else if (lower.includes('electron')) base = CATEGORY_TEMPLATES['Electronics'];
  else if (lower.includes('grocer') || lower.includes('rice') || lower.includes('spice')) base = CATEGORY_TEMPLATES['Groceries'];
  else if (lower.includes('bev') || lower.includes('drink') || lower.includes('snack')) base = CATEGORY_TEMPLATES['Beverages & Snacks'];
  else if (lower.includes('cosmet') || lower.includes('beauty')) base = CATEGORY_TEMPLATES['Cosmetics'];
  else if (lower.includes('cloth') || lower.includes('fashion')) base = CATEGORY_TEMPLATES['Fashion & Clothing'];
  else if (lower.includes('bakery') || lower.includes('dairy')) base = CATEGORY_TEMPLATES['Bakery & Dairy'];
  else if (lower.includes('fruit') || lower.includes('veg')) base = CATEGORY_TEMPLATES['Fruits & Vegetables'];
  else if (lower.includes('meat') || lower.includes('frozen')) base = CATEGORY_TEMPLATES['Frozen & Meat'];
  else if (lower.includes('pharm') || lower.includes('health')) base = CATEGORY_TEMPLATES['Health & Pharmacy'];
  else if (lower.includes('hard') || lower.includes('tool')) base = CATEGORY_TEMPLATES['Hardware & Tools'];
  else if (lower.includes('electr') || lower.includes('light')) base = CATEGORY_TEMPLATES['Electrical & Lighting'];
  else if (lower.includes('household') || lower.includes('clean')) {
    base = {
      subCategoryLabel: 'Cleaning / Home Type',
      subCategories: ['Detergent / Washing Powder', 'Dishwash Liquid', 'Floor / Glass Cleaner', 'Mop / Broom', 'Air Freshener'],
      brandLabel: 'Brand',
      brands: ['Wheel', 'Surf Excel', 'Rin', 'Vim', 'Harpic', 'Lizol', 'RFL', 'ACI'],
      modelLabel: 'Weight / Volume',
      genericModels: ['250ml', '500ml', '1L', '200g', '500g', '1kg', '2kg'],
      variantLabel: 'Scent / Spec',
      variants: ['Lemon', 'Lavender', 'Pine', 'Ultra Clean', 'Refill Pack'],
      defaultUnit: 'pcs',
      units: ['pcs', 'kg', 'L', 'pack'],
    };
  } else if (lower.includes('stationery') || lower.includes('book')) {
    base = {
      subCategoryLabel: 'Stationery Type',
      subCategories: ['Pen & Pencil', 'Notebook / Khata', 'A4 Paper / File', 'Marker & Highlighter', 'Scale & Geometry', 'Text / Story Book'],
      brandLabel: 'Brand',
      brands: ['Matador', 'Good Luck', 'Bashundhara', 'Faber-Castell', 'Deli', 'Casio'],
      modelLabel: 'Pack / Page / Size',
      genericModels: ['Single', '12 pcs Box', 'A4', '100 Pages', '200 Pages', '300 Pages'],
      variantLabel: 'Color / Type',
      variants: ['Blue Ink', 'Black Ink', 'Red Ink', 'Ruled', 'White Page', 'Graph'],
      defaultUnit: 'pcs',
      units: ['pcs', 'pack', 'box', 'dozen'],
    };
  } else if (lower.includes('kitchen') || lower.includes('homeware')) {
    base = {
      subCategoryLabel: 'Kitchen Item Type',
      subCategories: ['Plate / Bowl / Cup', 'Cooking Pot / Pan', 'Flask / Water Bottle', 'Knife / Spoon / Peeler', 'Food Container'],
      brandLabel: 'Brand',
      brands: ['RFL', 'Kiam', 'Noor', 'Miyako', 'Prestige', 'Milton'],
      modelLabel: 'Size / Capacity',
      genericModels: ['Small', 'Medium', 'Large', '500ml', '1L', '6 pcs Set', '12 pcs Set'],
      variantLabel: 'Material / Color',
      variants: ['Melamine', 'Stainless Steel', 'Non-Stick', 'Glass', 'Food-Grade Plastic'],
      defaultUnit: 'pcs',
      units: ['pcs', 'set', 'pack', 'box'],
    };
  } else if (lower.includes('baby') || lower.includes('kid')) {
    base = {
      subCategoryLabel: 'Baby Care Type',
      subCategories: ['Diaper / Pants', 'Baby Food / Cerelac', 'Baby Lotion / Powder', 'Feeding Bottle / Nipple', 'Baby Wipes'],
      brandLabel: 'Brand',
      brands: ['Bashundhara', 'Twinkle', 'Huggies', 'Pampers', 'Johnson\'s', 'Nestle Cerelac', 'Lactogen'],
      modelLabel: 'Size / Stage',
      genericModels: ['Newborn (NB)', 'Small (S)', 'Medium (M)', 'Large (L)', 'XL', 'Stage 1', 'Stage 2', '400g', '500g'],
      variantLabel: 'Pack / Flavor',
      variants: ['Mega Pack', 'Mini Pack', 'Wheat', 'Honey', 'Mild & Gentle'],
      defaultUnit: 'pack',
      units: ['pack', 'pcs', 'box'],
    };
  } else if (lower.includes('toy') || lower.includes('gift')) {
    base = {
      subCategoryLabel: 'Toy / Gift Type',
      subCategories: ['Remote Control Car', 'Doll / Action Figure', 'Puzzle / Board Game', 'Soft Toy / Teddy', 'Gift Box / Mug'],
      brandLabel: 'Brand',
      brands: ['Hot Wheels', 'Lego', 'Barbie', 'Funskool', 'Imported Gift'],
      modelLabel: 'Size / Age',
      genericModels: ['Small', 'Medium', 'Large', '3+ Years', '5+ Years', 'Gift Box'],
      variantLabel: 'Color / Theme',
      variants: ['Battery Operated', 'Rechargeable', 'Red', 'Pink', 'Blue', 'Wooden'],
      defaultUnit: 'pcs',
      units: ['pcs', 'box', 'set'],
    };
  } else if (lower.includes('sport') || lower.includes('fit')) {
    base = {
      subCategoryLabel: 'Sports Item',
      subCategories: ['Cricket Bat / Ball', 'Football / Volleyball', 'Badminton Racket / Shuttle', 'Skipping Rope / Dumbbell', 'Jersey / Gloves'],
      brandLabel: 'Brand',
      brands: ['Yonex', 'SS', 'SG', 'Nivia', 'Cosco', 'Nike', 'Adidas'],
      modelLabel: 'Size / Weight',
      genericModels: ['Standard', 'Size 4', 'Size 5', '2kg', '5kg', 'Pro Grade'],
      variantLabel: 'Material / Color',
      variants: ['Kashmir Willow', 'English Willow', 'Feather', 'Nylon', 'Leather'],
      defaultUnit: 'pcs',
      units: ['pcs', 'pair', 'set', 'box'],
    };
  } else if (lower.includes('jewel') || lower.includes('watch')) {
    base = {
      subCategoryLabel: 'Jewelry / Watch Type',
      subCategories: ['Wrist Watch', 'Bracelet / Bangle', 'Necklace / Chain', 'Earrings', 'Ring'],
      brandLabel: 'Brand',
      brands: ['Casio', 'Curren', 'Naviforce', 'Skmei', 'Titan', 'Fashion Imitation'],
      modelLabel: 'Style / Dial',
      genericModels: ['Men', 'Women', 'Couple Set', 'Analog', 'Digital', 'Free Size'],
      variantLabel: 'Finish / Color',
      variants: ['Gold Plated', 'Silver', 'Rose Gold', 'Leather Strap', 'Chain Strap'],
      defaultUnit: 'pcs',
      units: ['pcs', 'pair', 'set', 'box'],
    };
  } else if (lower.includes('pet')) {
    base = {
      subCategoryLabel: 'Pet Supply Type',
      subCategories: ['Cat Food (Dry/Wet)', 'Dog Food', 'Cat Litter', 'Collar / Leash', 'Pet Shampoo'],
      brandLabel: 'Brand',
      brands: ['Me-O', 'Whiskas', 'Lara', 'Drools', 'Pedigree', 'Royal Canin'],
      modelLabel: 'Weight / Pack',
      genericModels: ['80g Pouch', '400g', '1.2kg', '3kg', '7kg', '5L', '10L'],
      variantLabel: 'Flavor / Age',
      variants: ['Tuna', 'Ocean Fish', 'Salmon', 'Chicken', 'Kitten', 'Adult'],
      defaultUnit: 'pack',
      units: ['pack', 'kg', 'pcs'],
    };
  } else if (lower.includes('auto') || lower.includes('bike')) {
    base = {
      subCategoryLabel: 'Bike / Auto Part',
      subCategories: ['Engine Oil / Mobil', 'Helmet', 'Brake Pad / Chain', 'LED Headlight / Horn', 'Polish & Cleaner'],
      brandLabel: 'Brand',
      brands: ['Motul', 'Shell', 'Castrol', 'Havoline', 'Studds', 'Vega', 'MT'],
      modelLabel: 'Grade / Size',
      genericModels: ['10W-30', '10W-40', '20W-40', '800ml', '1L', 'M', 'L', 'XL'],
      variantLabel: 'Type / Spec',
      variants: ['Synthetic', 'Mineral', 'Full Face', 'Half Face', 'Universal'],
      defaultUnit: 'pcs',
      units: ['pcs', 'L', 'set', 'box'],
    };
  }

  return {
    ...base,
    genericModels: Array.from(new Set([...customModels, ...base.genericModels])),
  };
};

export const fmtQty = (qty: number, unit?: string): string => {
  const num = Number(qty || 0);
  const rounded = Math.round(num * 1000) / 1000;
  const numStr = Number.isInteger(rounded) ? String(rounded) : String(rounded);
  return unit && unit !== 'pcs' ? `${numStr} ${unit}` : numStr;
};
