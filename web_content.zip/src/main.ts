import './styles/main.css'
import { Assets } from './engine/assets'
import { AudioManager } from './engine/audio'
import { I18n } from './engine/i18n'
import { Input } from './engine/input'
import { GameLoop } from './engine/loop'
import { SAVE_KEY, SaveStore, type SaveData } from './engine/save'
import { ASSETS } from './game/assetTable'
import type { Game } from './game/game'
import { isBetter, type RunState } from './game/rules'
import { Ui } from './ui/ui'

async function boot(): Promise<void> {
  const canvas = document.querySelector<HTMLCanvasElement>('#game')!
  const firstRun = safeGet(SAVE_KEY) === null
  const save = new SaveStore()
  const i18n = new I18n()
  const input = new Input(canvas)
  const audio = new AudioManager()
  const assets = new Assets()
  let game: Game | undefined
  let loop!: GameLoop

  const applySettings = (d: SaveData) => {
    audio.setVolumes(d.musicVolume, d.sfxVolume, d.muted)
    document.documentElement.classList.toggle('reduce-motion', d.reducedMotion)
    if (game) game.chase.reducedMotion = d.reducedMotion
  }

  const startRun = () => {
    if (!game) return
    audio.unlock()
    audio.startMusic()
    game.start()
    ui.show('hud')
    loop.resetAccumulator()
    input.clearActions()
  }
  const pause = () => {
    if (game?.mode !== 'playing') return
    game.pause()
    ui.show('pause')
  }
  const resume = () => {
    if (game?.mode !== 'paused') return
    game.resume()
    ui.show('hud')
    loop.resetAccumulator()
  }

  const ui = new Ui(i18n, save, audio, input, {
    play: startRun,
    restart: startRun,
    resume,
    pause,
    quit: () => {
      audio.stopMusic()
      game?.toTitle()
      ui.show('title')
    },
    settings: patch => {
      const qualityChanged = patch.quality !== undefined && patch.quality !== save.data.quality
      save.update(patch)
      applySettings(save.data)
      if (qualityChanged) game?.setQuality(save.data.quality)
    },
  })
  ui.show('boot')
  applySettings(save.data)

  const finishRun = (run: RunState) => {
    const best = save.data.best
    const candidate = { score: run.score, rings: run.rings, distance: run.distance, seconds: run.seconds }
    const newBest = !run.unranked && run.score > 0 && isBetter(candidate, best)
    if (newBest) save.update({ best: candidate })
    window.setTimeout(() => {
      if (game?.mode === 'ended') ui.showResults(run, newBest)
    }, 350)
  }

  const startLoop = async (g: Game): Promise<void> => {
    if (import.meta.env.DEV) {
      const [{ registerGameTuning }, { tuning }] = await Promise.all([import('../scripts/manus-tuning/adapter.js'), import('./game/tuning')])
      await registerGameTuning(tuning)
    }
    loop = new GameLoop({
      beforeFrame: frameSeconds => input.update(frameSeconds),
      step: dt => g.step(dt),
      render: (alpha, frameSeconds) => {
        if (input.consume('pause')) {
          if (g.mode === 'playing') pause()
          else if (g.mode === 'paused' && ui.screen === 'pause') resume()
        }
        // A gamepad's A button presses whichever button has focus.
        if (input.consume('confirm') && input.method === 'gamepad') {
          const focused = document.activeElement as HTMLElement | null
          if (focused?.matches('button')) focused.click()
        }
        loop.paused = g.mode === 'paused'
        g.render(alpha, frameSeconds)
        ui.frame()
        if (ui.screen === 'hud') ui.updateHud(g)
      },
    })
    loop.start()
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) pause()
    })
    window.addEventListener('game:pause', pause)
    window.setTimeout(() => ui.show('title'), 250)
    // Debug/test hook (read-only use): smoke tests inspect the run through it.
    ;(window as unknown as { __game: unknown }).__game = { game: g, ui, input, save }
  }

  // Load the engine chunk, the renderer and the player's aircraft behind the progress bar.
  const load = async (): Promise<void> => {
    try {
      ui.setBootProgress(0.05)
      const [{ Game }, { Renderer, suggestQuality }] = await Promise.all([import('./game/game'), import('./engine/renderer')])
      ui.setBootProgress(0.2)
      await document.fonts.ready
      const gltf = await assets.gltf(ASSETS.aircraft, fraction => ui.setBootProgress(0.2 + fraction * 0.7))
      ui.setBootProgress(0.92)
      if (firstRun) {
        save.update({ quality: suggestQuality() })
        ui.refreshSettings()
      }
      const renderer = new Renderer(canvas, save.data.quality)
      game = new Game(renderer, input, audio, gltf.scene, save, {
        ring: info => ui.ring(info),
        missed: () => ui.missed(),
        crashed: () => ui.crashed(),
        ended: finishRun,
      })
      applySettings(save.data)
      ui.setBootProgress(1)
      await startLoop(game)
    } catch (error) {
      console.error(error)
      ui.bootError(() => void load())
    }
  }

  await load()
}

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}

boot().catch(err => {
  console.error(err)
  const el = document.getElementById('ui')
  if (el) el.innerHTML = `<div class="fatal">No se pudo iniciar el juego: ${String((err as Error)?.message ?? err).replace(/[<>&]/g, '')}</div>`
})
