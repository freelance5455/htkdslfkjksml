/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowGameEngine } from './game/engine';
import { ShapeDrawingBoard } from './game/drawing';
import { INITIAL_LEVELS } from './game/levels';
import { generateProceduralLevel } from './game/generator';
import { storage } from './game/storage';
import { sound } from './game/audio';
import { getHintArrowId, validateAndEvaluatePuzzle } from './game/solver';
import { adManager } from './game/ads';
import {
  checkHintAvailability,
  consumeAvailableHint,
  createFreshHintState,
  grantRewardedHint,
  LevelHintState,
  nextHintRewardEventId,
} from './game/hints';
import { CustomLevel, LevelData, ScreenState } from './game/types';

class ArrowMasterApp {
  private currentScreen: ScreenState = 'HOME';
  private returnScreen: ScreenState = 'HOME';
  private gameEngine!: ArrowGameEngine;
  private previewEngine!: ArrowGameEngine;
  private drawingBoard!: ShapeDrawingBoard;

  private currentLevelData: LevelData | null = null;
  private currentLevelIndex: number = 1;
  private pendingGeneratedLevel: LevelData | null = null;
  private hearts: number = 3;
  private mistakes: number = 0;
  private hasUsedExtraHeartInAttempt: boolean = false;
  private currentGameOverEventId: string | null = null;
  private isWatchingRewardedAd: boolean = false;
  private hintState: LevelHintState = createFreshHintState(1);
  private hintBannerTimer: number | null = null;

  // DOM Elements cache
  private elScreenSplash = document.getElementById('screen-splash');
  private elScreenHome = document.getElementById('screen-home')!;
  private elScreenGame = document.getElementById('screen-game')!;
  private elScreenLevels = document.getElementById('screen-levels')!;
  private elScreenCreator = document.getElementById('screen-creator')!;
  private elScreenMyLevels = document.getElementById('screen-my-levels')!;

  // Modals
  private elModalVictory = document.getElementById('modal-victory')!;
  private elModalGameOver = document.getElementById('modal-gameover')!;
  private elModalHintReward = document.getElementById('modal-hint-reward')!;
  private elModalPause = document.getElementById('modal-pause')!;
  private elModalSettings = document.getElementById('modal-settings')!;

  // HUD elements
  private elHeartsContainer = document.getElementById('hearts-container')!;
  private elLevelTitle = document.getElementById('game-level-title')!;
  private elDifficultyBadge = document.getElementById('game-difficulty-badge')!;
  private elArrowsLeft = document.getElementById('game-arrows-left')!;
  private elComboBadge = document.getElementById('combo-badge')!;
  private elHintUnlockedBanner = document.getElementById('hint-unlocked-banner');
  private elBtnGrid = document.getElementById('btn-game-grid')!;
  private elBtnZoomReset = document.getElementById('btn-zoom-reset')!;

  // Creator elements
  private elDrawingCanvas = document.getElementById('drawing-canvas') as HTMLCanvasElement;
  private elPreviewCanvas = document.getElementById('preview-canvas') as HTMLCanvasElement;
  private elPreviewBadge = document.getElementById('preview-mode-badge')!;
  private elCreatorDrawControls = document.getElementById('creator-draw-controls')!;
  private elCreatorPreviewControls = document.getElementById('creator-preview-controls')!;
  private elCreatorHeaderTitle = document.getElementById('creator-header-title')!;
  private elCreatorShapeStatus = document.getElementById('creator-shape-status')!;
  private elPreviewPuzzleStats = document.getElementById('preview-puzzle-stats')!;

  constructor() {
    this.initEngines();
    this.bindDOMEvents();
    this.syncSettingsUI();
    this.updateHomeUI();
    this.renderLevelGrid();
    void adManager.initialize().then(() => this.syncPrivacyButtonUI());
    this.initSplashScreen();
  }

  private initSplashScreen() {
    const splash = this.elScreenSplash;
    if (!splash) return;

    let dismissed = false;
    let completionStarted = false;

    const finalizeDismissSplash = () => {
      if (dismissed) return;
      dismissed = true;
      splash.classList.add('splash-hidden');
      setTimeout(() => {
        splash.classList.add('hidden');
      }, 500);
    };

    const completeSplashSequence = async () => {
      if (completionStarted) return;
      completionStarted = true;
      // Show preloaded App Open Ad only if ready, eligible, and consent-permitted.
      // Never stalls splash if unavailable.
      await adManager.tryShowSplashAppOpenAd();
      finalizeDismissSplash();
    };

    const timer = window.setTimeout(() => {
      void completeSplashSequence();
    }, 2500);

    // Allow optional early tap after initial fade-in settles
    const mountedAt = performance.now();
    splash.addEventListener('click', () => {
      if (performance.now() - mountedAt > 600) {
        window.clearTimeout(timer);
        void completeSplashSequence();
      }
    });
  }

  private initEngines() {
    const gameCanvas = document.getElementById('game-canvas') as HTMLCanvasElement;
    this.gameEngine = new ArrowGameEngine(gameCanvas);

    this.gameEngine.onMistake = () => this.handleMistake();
    this.gameEngine.onArrowEscaped = (remaining) => this.handleArrowEscaped(remaining);
    this.gameEngine.onLevelCompleted = () => this.handleLevelVictory();
    this.gameEngine.onCombo = (combo) => this.showComboBadge(combo);
    this.gameEngine.onZoomChange = (zoom) => {
      if (this.elBtnZoomReset) {
        this.elBtnZoomReset.textContent = `${Math.round(zoom * 100)}%`;
      }
    };

    // Interactive Preview Engine inside Draw Your Own Level screen
    this.previewEngine = new ArrowGameEngine(this.elPreviewCanvas);
    this.previewEngine.onLevelCompleted = () => {
      // Reload preview puzzle cleanly if user tests solving the whole thing in preview
      if (this.pendingGeneratedLevel) {
        setTimeout(() => {
          if (this.pendingGeneratedLevel && !this.elPreviewCanvas.classList.contains('hidden')) {
            this.previewEngine.loadLevel(this.pendingGeneratedLevel);
          }
        }, 700);
      }
    };

    this.drawingBoard = new ShapeDrawingBoard(this.elDrawingCanvas);
    this.drawingBoard.onShapeChange = ({ hasShape, recognized }) => {
      if (this.elCreatorShapeStatus) {
        this.elCreatorShapeStatus.textContent = hasShape
          ? `Detected: ${recognized}`
          : 'Draw any closed shape';
      }
    };
  }

  private switchScreen(screen: ScreenState) {
    this.currentScreen = screen;
    adManager.setGameplayActive(screen === 'PLAYING');
    sound.playClick();

    [
      this.elScreenHome,
      this.elScreenGame,
      this.elScreenLevels,
      this.elScreenCreator,
      this.elScreenMyLevels,
    ].forEach((s) => s.classList.add('hidden'));

    switch (screen) {
      case 'HOME':
        this.elScreenHome.classList.remove('hidden');
        this.updateHomeUI();
        break;
      case 'PLAYING':
        this.elScreenGame.classList.remove('hidden');
        requestAnimationFrame(() => {
          this.gameEngine.handleResize();
        });
        setTimeout(() => this.gameEngine.handleResize(), 60);
        break;
      case 'LEVEL_SELECT':
        this.elScreenLevels.classList.remove('hidden');
        this.renderLevelGrid();
        break;
      case 'DRAWING':
        this.elScreenCreator.classList.remove('hidden');
        this.enterCreatorDrawMode();
        requestAnimationFrame(() => {
          this.drawingBoard.handleResize();
        });
        setTimeout(() => this.drawingBoard.handleResize(), 60);
        break;
      case 'MY_LEVELS':
        this.elScreenMyLevels.classList.remove('hidden');
        this.renderMyLevelsList();
        break;
    }
  }

  private enterCreatorDrawMode() {
    this.pendingGeneratedLevel = null;
    this.elDrawingCanvas.classList.remove('hidden');
    this.elPreviewCanvas.classList.add('hidden');
    this.elPreviewBadge.classList.add('hidden');
    this.elCreatorDrawControls.classList.remove('hidden');
    this.elCreatorPreviewControls.classList.add('hidden');

    const nextNum = storage.getNextCustomLevelNumber();
    this.elCreatorHeaderTitle.textContent = `Create Level ${nextNum}`;

    requestAnimationFrame(() => this.drawingBoard.handleResize());
  }

  private enterCreatorPreviewMode(level: LevelData) {
    this.pendingGeneratedLevel = level;
    this.elDrawingCanvas.classList.add('hidden');
    this.elPreviewCanvas.classList.remove('hidden');
    this.elPreviewBadge.classList.remove('hidden');
    this.elCreatorDrawControls.classList.add('hidden');
    this.elCreatorPreviewControls.classList.remove('hidden');

    const check = validateAndEvaluatePuzzle(level.arrows);
    this.elPreviewPuzzleStats.textContent = `Level ${level.levelNumber} · ${level.arrows.length} Arrows · Solvable (${check.metrics.waveDepth} waves)`;

    this.previewEngine.loadLevel(level);
    requestAnimationFrame(() => {
      this.previewEngine.handleResize();
      this.previewEngine.loadLevel(level);
    });
  }

  private generatePreviewPuzzle() {
    if (!this.drawingBoard.hasValidShape()) {
      this.elCreatorShapeStatus.textContent = 'Please draw a closed shape or pick a preset first!';
      sound.playBlocked();
      return;
    }

    const nextNum = storage.getNextCustomLevelNumber();
    const generated = this.drawingBoard.generatePuzzle(nextNum);
    if (!generated) {
      this.elCreatorShapeStatus.textContent = 'Shape too small — draw a slightly larger closed shape!';
      sound.playBlocked();
      return;
    }

    this.enterCreatorPreviewMode(generated);
  }

  private savePendingCustomLevel() {
    if (!this.pendingGeneratedLevel) return;

    const custom: CustomLevel = {
      ...this.pendingGeneratedLevel,
      createdAt: Date.now(),
      stars: 0,
    };

    storage.addCustomLevel(custom);
    sound.playStar(2);
    this.pendingGeneratedLevel = null;
    this.startLevel(custom, 'MY_LEVELS');
  }

  private updateHomeUI() {
    const data = storage.getData();
    let totalStars = 0;
    Object.values(data.completedLevels).forEach((lvl) => {
      totalStars += lvl.stars || 0;
    });

    const elStars = document.getElementById('home-total-stars');
    if (elStars) elStars.textContent = String(totalStars);

    const elCoins = document.getElementById('home-total-coins');
    if (elCoins) elCoins.textContent = String(data.coins);

    const elPlayText = document.getElementById('home-play-text');
    if (elPlayText) {
      const nextLvl = data.currentLevel || 1;
      elPlayText.textContent = nextLvl === 1 ? 'Play Game' : `Continue (Level ${nextLvl})`;
    }

    const badge = document.getElementById('badge-creator-lock');
    if (badge) {
      if (storage.isEditorUnlocked()) {
        badge.textContent = 'Unlocked';
        badge.className =
          'ml-auto text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-medium';
      } else {
        badge.textContent = 'Unlocks Lv.10';
        badge.className =
          'ml-auto text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-medium';
      }
    }
  }

  private renderLevelGrid() {
    const grid = document.getElementById('levels-grid');
    if (!grid) return;
    grid.innerHTML = '';

    const data = storage.getData();

    INITIAL_LEVELS.forEach((level) => {
      const isUnlocked = storage.isLevelUnlocked(level.levelNumber);
      const progress = data.completedLevels[String(level.levelNumber)];
      const starsEarned = progress ? progress.stars : 0;

      const card = document.createElement('button');
      card.className = `p-4 rounded-2xl border text-left flex flex-col justify-between transition-all min-h-[110px] ${
        isUnlocked
          ? 'bg-white border-slate-200/90 hover:border-blue-400 hover:shadow-md cursor-pointer'
          : 'bg-slate-50 border-slate-200/60 opacity-60 cursor-not-allowed'
      }`;

      let starsHTML = '';
      for (let s = 1; s <= 3; s++) {
        starsHTML += `
          <svg class="w-3.5 h-3.5 ${
            s <= starsEarned ? 'text-amber-500 fill-current' : 'text-slate-200 fill-current'
          }" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        `;
      }

      card.innerHTML = `
        <div class="flex items-center justify-between w-full">
          <span class="text-xs font-bold ${
            isUnlocked ? 'text-blue-600' : 'text-slate-400'
          }">LEVEL ${level.levelNumber}</span>
          ${
            isUnlocked
              ? `<div class="flex gap-0.5">${starsHTML}</div>`
              : `<svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>`
          }
        </div>
        <div>
          <div class="text-sm font-bold text-slate-900 truncate">${level.title}</div>
          <div class="text-[11px] text-slate-400">${level.difficulty} · ${level.arrows.length} Arrows</div>
        </div>
      `;

      if (isUnlocked) {
        card.addEventListener('click', () => {
          this.startLevel(level, 'LEVEL_SELECT');
        });
      }

      grid.appendChild(card);
    });

    // Render Custom Created Levels (11+) inside Level Selection as well
    const customSection = document.getElementById('levels-custom-section');
    const customGrid = document.getElementById('levels-custom-grid');
    if (customSection && customGrid) {
      const sortedCustom = [...(data.customLevels || [])].sort(
        (a, b) => (a.levelNumber || 0) - (b.levelNumber || 0)
      );
      if (sortedCustom.length > 0) {
        customSection.classList.remove('hidden');
        customGrid.innerHTML = '';
        sortedCustom.forEach((lvl) => {
          const progress = data.completedLevels[String(lvl.id)];
          const starsEarned = progress ? progress.stars : 0;
          const card = document.createElement('button');
          card.className =
            'p-4 rounded-2xl border border-slate-200/90 bg-white hover:border-blue-400 hover:shadow-md text-left flex flex-col justify-between transition-all min-h-[104px] cursor-pointer';

          let starsHTML = '';
          for (let s = 1; s <= 3; s++) {
            starsHTML += `
              <svg class="w-3.5 h-3.5 ${
                s <= starsEarned ? 'text-amber-500 fill-current' : 'text-slate-200 fill-current'
              }" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            `;
          }

          card.innerHTML = `
            <div class="flex items-center justify-between w-full">
              <span class="text-xs font-bold text-blue-600">LEVEL ${lvl.levelNumber}</span>
              <div class="flex gap-0.5">${starsHTML}</div>
            </div>
            <div>
              <div class="text-sm font-bold text-slate-900 truncate">${lvl.title}</div>
              <div class="text-[11px] text-slate-400">${lvl.difficulty} · ${lvl.arrows.length} Arrows</div>
            </div>
          `;
          card.addEventListener('click', () => {
            this.startLevel(lvl, 'LEVEL_SELECT');
          });
          customGrid.appendChild(card);
        });
      } else {
        customSection.classList.add('hidden');
      }
    }
  }

  private renderMyLevelsList() {
    const list = document.getElementById('mylevels-list');
    if (!list) return;
    list.innerHTML = '';

    const data = storage.getData();
    const customLevels = [...(data.customLevels || [])].sort(
      (a, b) => (b.levelNumber || 0) - (a.levelNumber || 0)
    );

    if (customLevels.length === 0) {
      list.innerHTML = `
        <div class="text-center py-12 px-4">
          <div class="w-16 h-16 bg-blue-50 text-blue-500 rounded-3xl mx-auto flex items-center justify-center mb-3">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
          </div>
          <h3 class="text-sm font-bold text-slate-900">No Custom Levels Yet</h3>
          <p class="text-xs text-slate-500 mt-1 mb-4">Draw any shape and turn it into a playable arrow puzzle!</p>
          <button id="btn-empty-draw-now" class="btn-primary text-xs py-2 px-4 mx-auto">
            Create First Level
          </button>
        </div>
      `;
      const btn = document.getElementById('btn-empty-draw-now');
      if (btn) btn.addEventListener('click', () => this.switchScreen('DRAWING'));
      return;
    }

    customLevels.forEach((lvl) => {
      const item = document.createElement('div');
      item.className =
        'p-3.5 rounded-2xl border border-slate-200/90 bg-white shadow-xs flex items-center justify-between';
      item.innerHTML = `
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs uppercase">
            Lv.${lvl.levelNumber || '?'}
          </div>
          <div>
            <div class="text-sm font-bold text-slate-900">${lvl.title}</div>
            <div class="text-[11px] text-slate-400">${lvl.arrows.length} Arrows · ${lvl.shapeType || 'custom'} · ${new Date(
        lvl.createdAt
      ).toLocaleDateString()}</div>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <button class="btn-play-custom btn-primary py-1.5 px-3 text-xs" data-id="${lvl.id}">
            Play
          </button>
          <button class="btn-del-custom text-slate-400 hover:text-rose-500 p-1.5" data-id="${lvl.id}" aria-label="Delete">
            ✕
          </button>
        </div>
      `;

      item.querySelector('.btn-play-custom')?.addEventListener('click', () => {
        this.startLevel(lvl, 'MY_LEVELS');
      });

      item.querySelector('.btn-del-custom')?.addEventListener('click', () => {
        if (confirm(`Delete "${lvl.title}"?`)) {
          storage.deleteCustomLevel(lvl.id);
          this.renderMyLevelsList();
        }
      });

      list.appendChild(item);
    });
  }

  public startLevel(level: LevelData, fromScreen?: ScreenState) {
    if (fromScreen) {
      this.returnScreen = fromScreen;
    } else if (this.currentScreen !== 'PLAYING') {
      this.returnScreen = this.currentScreen;
    }

    this.currentLevelData = level;
    this.currentLevelIndex = typeof level.levelNumber === 'number' ? level.levelNumber : 1;
    this.hearts = 3;
    this.mistakes = 0;
    this.hasUsedExtraHeartInAttempt = false;
    this.currentGameOverEventId = null;
    this.isWatchingRewardedAd = false;
    this.hintState = createFreshHintState(this.currentLevelIndex);

    this.elModalHintReward?.classList.add('hidden');
    if (this.hintBannerTimer !== null) {
      window.clearTimeout(this.hintBannerTimer);
      this.hintBannerTimer = null;
    }
    this.elHintUnlockedBanner?.classList.add('hidden');

    this.renderHearts();
    this.updateHUD();
    adManager.preloadRewardedAd();

    this.gameEngine.loadLevel(level);
    this.switchScreen('PLAYING');
  }

  private updateHUD() {
    if (!this.currentLevelData) return;
    this.elLevelTitle.textContent = `Level ${this.currentLevelIndex}`;
    this.elDifficultyBadge.textContent = this.currentLevelData.difficulty;
    this.elArrowsLeft.textContent = String(this.currentLevelData.arrows.length);
  }

  private renderHearts() {
    this.elHeartsContainer.innerHTML = '';
    for (let i = 0; i < 3; i++) {
      const filled = i < this.hearts;
      const heart = document.createElement('div');
      heart.innerHTML = `
        <svg class="w-6 h-6 ${
          filled ? 'text-rose-500 fill-current drop-shadow-xs' : 'text-slate-200 fill-current'
        } transition-colors" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd" />
        </svg>
      `;
      this.elHeartsContainer.appendChild(heart.firstElementChild!);
    }
  }

  private handleMistake() {
    this.mistakes++;
    this.hearts = Math.max(0, this.hearts - 1);
    this.renderHearts();

    if (this.hearts === 0) {
      sound.playGameOver();
      this.gameEngine.setInteractive(false);
      this.currentGameOverEventId = `gameover_${this.currentLevelIndex}_${Date.now()}_${Math.random()
        .toString(36)
        .slice(2, 7)}`;
      setTimeout(() => {
        this.showGameOverModal();
      }, 350);
    }
  }

  private showGameOverModal() {
    const elTitle = document.getElementById('gameover-title');
    const elSubtitle = document.getElementById('gameover-subtitle');
    const elAdOffer = document.getElementById('gameover-ad-offer');
    const elAdStatus = document.getElementById('gameover-ad-status');
    const elStandardActions = document.getElementById('gameover-standard-actions');
    const btnWatchAd = document.getElementById('btn-gameover-watch-ad') as HTMLButtonElement | null;
    const btnNoThanks = document.getElementById('btn-gameover-no-thanks') as HTMLButtonElement | null;

    if (elTitle) elTitle.textContent = 'OUT OF HEARTS!';
    if (elAdStatus) {
      elAdStatus.textContent = '';
      elAdStatus.classList.add('hidden');
    }
    if (btnWatchAd) {
      btnWatchAd.disabled = false;
      btnWatchAd.textContent = 'WATCH AD';
    }
    if (btnNoThanks) {
      btnNoThanks.disabled = false;
    }

    if (!this.hasUsedExtraHeartInAttempt) {
      if (elSubtitle) elSubtitle.textContent = 'You have used all your lives.';
      elAdOffer?.classList.remove('hidden');
      elStandardActions?.classList.add('hidden');
      adManager.preloadRewardedAd();
    } else {
      if (elSubtitle) {
        elSubtitle.textContent = 'Look for outer arrows whose exit ray is completely clear first!';
      }
      elAdOffer?.classList.add('hidden');
      elStandardActions?.classList.remove('hidden');
    }

    this.elModalGameOver.classList.remove('hidden');
  }

  private async handleWatchExtraHeartAd() {
    if (this.isWatchingRewardedAd || this.hasUsedExtraHeartInAttempt || !this.currentGameOverEventId) {
      return;
    }

    const btnWatchAd = document.getElementById('btn-gameover-watch-ad') as HTMLButtonElement | null;
    const btnNoThanks = document.getElementById('btn-gameover-no-thanks') as HTMLButtonElement | null;
    const elAdStatus = document.getElementById('gameover-ad-status');
    const elStandardActions = document.getElementById('gameover-standard-actions');

    this.isWatchingRewardedAd = true;
    sound.playClick();

    if (btnWatchAd) {
      btnWatchAd.disabled = true;
      btnWatchAd.textContent = 'Loading Ad...';
    }
    if (btnNoThanks) {
      btnNoThanks.disabled = true;
    }
    if (elAdStatus) {
      elAdStatus.textContent = '';
      elAdStatus.classList.add('hidden');
    }

    try {
      const outcome = await adManager.showRewardedExtraHeartAd(this.currentGameOverEventId);

      // Strictly award 1 extra heart ONLY on confirmed official AdMob reward callback
      if (outcome.granted && outcome.status === 'rewarded' && outcome.rewardAmount === 1) {
        this.hasUsedExtraHeartInAttempt = true;
        this.hearts = 1;
        this.renderHearts();
        this.elModalGameOver.classList.add('hidden');
        this.gameEngine.setInteractive(true);
        sound.playStar(1);
        return;
      }

      // Ad failed, unavailable, or closed early without earning reward — grant 0 hearts
      if (elAdStatus) {
        elAdStatus.textContent =
          outcome.message || 'Video ad could not be completed. No extra heart was granted.';
        elAdStatus.classList.remove('hidden');
      }
      if (btnWatchAd) {
        btnWatchAd.disabled = false;
        btnWatchAd.textContent = 'RETRY AD';
      }
      if (btnNoThanks) {
        btnNoThanks.disabled = false;
      }
      // Provide direct restart/menu access cleanly alongside retry
      elStandardActions?.classList.remove('hidden');
    } finally {
      this.isWatchingRewardedAd = false;
    }
  }

  private handleArrowEscaped(remainingCount: number) {
    this.elArrowsLeft.textContent = String(remainingCount);
  }

  private handleLevelVictory() {
    let stars = 3;
    if (this.mistakes === 1) stars = 2;
    else if (this.mistakes >= 2) stars = 1;

    if (this.currentLevelData) {
      storage.completeLevel(this.currentLevelData.id, stars, this.mistakes);
      // Also mark numbered level progress if this was a custom level at levelNumber >= 11
      if (typeof this.currentLevelData.levelNumber === 'number' && this.currentLevelData.levelNumber >= 11) {
        storage.completeLevel(this.currentLevelData.levelNumber, stars, this.mistakes);
      }
    }

    const sub = document.getElementById('victory-subtitle');
    if (sub) {
      sub.textContent =
        stars === 3 ? 'Flawless Victory!' : stars === 2 ? 'Great Strategy!' : 'Level Cleared!';
    }

    const coinsText = document.getElementById('victory-coins-earned');
    if (coinsText) {
      coinsText.textContent = `+${15 + stars * 5} Coins`;
    }

    const mistText = document.getElementById('victory-mistakes-text');
    if (mistText) {
      mistText.textContent = `${this.mistakes} Mistake${this.mistakes === 1 ? '' : 's'}`;
    }

    for (let i = 1; i <= 3; i++) {
      const starEl = document.getElementById(`star-${i}`);
      if (starEl) {
        starEl.classList.remove('filled');
        if (i <= stars) {
          setTimeout(() => {
            starEl.classList.add('filled');
            sound.playStar(i);
          }, i * 200);
        }
      }
    }

    this.elModalVictory.classList.remove('hidden');
    this.updateHomeUI();
  }

  private showComboBadge(combo: number) {
    this.elComboBadge.textContent = `${combo}x COMBO!`;
    this.elComboBadge.style.opacity = '1';
    setTimeout(() => {
      this.elComboBadge.style.opacity = '0';
    }, 1200);
  }

  private triggerHint() {
    if (!this.currentLevelData || this.hearts <= 0 || this.isWatchingRewardedAd) return;

    const activeArrows = this.gameEngine.getActiveArrows();
    const bestArrowId = getHintArrowId(activeArrows);
    if (!bestArrowId) return;

    const availability = checkHintAvailability(this.hintState);
    if (availability.canUseNow) {
      const consumed = consumeAvailableHint(this.hintState);
      if (consumed.consumed) {
        sound.playHint();
        this.gameEngine.setHint(bestArrowId);
      }
      return;
    }

    // Free hint already used and no extra hints available — prompt for rewarded ad
    sound.playClick();
    this.openHintRewardModal();
  }

  private openHintRewardModal() {
    const elStatus = document.getElementById('hint-ad-status');
    const btnWatch = document.getElementById('btn-hint-watch-ad') as HTMLButtonElement | null;
    const btnCancel = document.getElementById('btn-hint-cancel') as HTMLButtonElement | null;

    if (elStatus) {
      elStatus.textContent = '';
      elStatus.classList.add('hidden');
    }
    if (btnWatch) {
      btnWatch.disabled = false;
      btnWatch.textContent = 'WATCH AD & GET 1 HINT';
    }
    if (btnCancel) {
      btnCancel.disabled = false;
    }

    adManager.preloadRewardedAd();
    this.elModalHintReward?.classList.remove('hidden');
  }

  private showHintUnlockedBanner() {
    const banner = this.elHintUnlockedBanner;
    if (!banner) return;

    if (this.hintBannerTimer !== null) {
      window.clearTimeout(this.hintBannerTimer);
      this.hintBannerTimer = null;
    }

    banner.textContent = '🎉 1 EXTRA HINT UNLOCKED!';
    banner.classList.remove('hidden');
    this.hintBannerTimer = window.setTimeout(() => {
      banner.classList.add('hidden');
      this.hintBannerTimer = null;
    }, 2600);
  }

  private async handleWatchHintRewardAd() {
    if (this.isWatchingRewardedAd || !this.currentLevelData) {
      return;
    }

    const activeAttemptId = this.hintState.levelAttemptId;
    const eventId = nextHintRewardEventId(this.hintState);

    const elStatus = document.getElementById('hint-ad-status');
    const btnWatch = document.getElementById('btn-hint-watch-ad') as HTMLButtonElement | null;
    const btnCancel = document.getElementById('btn-hint-cancel') as HTMLButtonElement | null;

    this.isWatchingRewardedAd = true;
    sound.playClick();

    if (btnWatch) {
      btnWatch.disabled = true;
      btnWatch.textContent = 'Loading Ad...';
    }
    if (btnCancel) {
      btnCancel.disabled = true;
    }
    if (elStatus) {
      elStatus.textContent = '';
      elStatus.classList.add('hidden');
    }

    try {
      const outcome = await adManager.showRewardedHintAd(eventId);

      // Ignore stale callback if player restarted or changed levels during ad
      if (this.hintState.levelAttemptId !== activeAttemptId) {
        return;
      }

      // Grant strictly 1 extra hint ONLY upon confirmed official AdMob reward callback
      if (outcome.granted && outcome.status === 'rewarded' && outcome.rewardAmount === 1) {
        grantRewardedHint(this.hintState);
        this.elModalHintReward?.classList.add('hidden');
        this.showHintUnlockedBanner();

        const activeArrows = this.gameEngine.getActiveArrows();
        const bestArrowId = getHintArrowId(activeArrows);
        if (bestArrowId) {
          consumeAvailableHint(this.hintState);
          sound.playHint();
          this.gameEngine.setHint(bestArrowId);
        }
        return;
      }

      // Closed early, failed to load, or unavailable (including browser preview) — grant 0 hints
      if (elStatus) {
        elStatus.textContent =
          outcome.message || 'Ad is not available. Please try again.';
        elStatus.classList.remove('hidden');
      }
      if (btnWatch) {
        btnWatch.disabled = false;
        btnWatch.textContent = 'WATCH AD & GET 1 HINT';
      }
      if (btnCancel) {
        btnCancel.disabled = false;
      }
    } finally {
      this.isWatchingRewardedAd = false;
    }
  }

  private openSettingsModal() {
    sound.playClick();
    this.syncSettingsUI();
    this.elModalSettings.classList.remove('hidden');
  }

  private closeSettingsModal() {
    sound.playClick();
    this.elModalSettings.classList.add('hidden');
  }

  private bindDOMEvents() {
    // Home Screen buttons
    document.getElementById('btn-home-play')?.addEventListener('click', () => {
      const data = storage.getData();
      const nextNum = data.currentLevel || 1;
      this.loadLevelByNumber(nextNum, 'HOME');
    });

    document.getElementById('btn-home-levels')?.addEventListener('click', () => {
      this.switchScreen('LEVEL_SELECT');
    });

    document.getElementById('btn-home-creator')?.addEventListener('click', () => {
      if (storage.isEditorUnlocked()) {
        this.switchScreen('DRAWING');
      } else {
        if (
          confirm(
            'Level 10 unlocks the Custom Creator. Would you like to preview and test it now?'
          )
        ) {
          storage.unlockEditorCheat();
          this.updateHomeUI();
          this.switchScreen('DRAWING');
        }
      }
    });

    document.getElementById('btn-home-mylevels')?.addEventListener('click', () => {
      this.switchScreen('MY_LEVELS');
    });

    document.getElementById('btn-home-settings')?.addEventListener('click', () => {
      this.openSettingsModal();
    });

    // Home Screen Social Media Links (Android App Deep-Link + Browser Fallback)
    this.bindSocialLinks();

    // Gameplay Screen Header & Footer & Zoom buttons
    document.getElementById('btn-game-back')?.addEventListener('click', () => {
      this.switchScreen(this.returnScreen || 'HOME');
    });

    document.getElementById('btn-game-settings')?.addEventListener('click', () => {
      this.openSettingsModal();
    });

    document.getElementById('btn-game-footer-settings')?.addEventListener('click', () => {
      this.openSettingsModal();
    });

    document.getElementById('btn-game-hint')?.addEventListener('click', () => {
      this.triggerHint();
    });

    document.getElementById('btn-game-grid')?.addEventListener('click', () => {
      sound.playClick();
      const nextGrid = !this.gameEngine.getShowGrid();
      this.gameEngine.setShowGrid(nextGrid);
      storage.updateSettings({ showGrid: nextGrid });
      this.syncGridButtonUI();
    });

    document.getElementById('btn-game-restart')?.addEventListener('click', () => {
      sound.playClick();
      if (this.currentLevelData) {
        this.startLevel(this.currentLevelData);
      }
    });

    document.getElementById('btn-zoom-in')?.addEventListener('click', () => {
      sound.playClick();
      this.gameEngine.zoomIn();
    });

    document.getElementById('btn-zoom-out')?.addEventListener('click', () => {
      sound.playClick();
      this.gameEngine.zoomOut();
    });

    document.getElementById('btn-zoom-reset')?.addEventListener('click', () => {
      sound.playClick();
      this.gameEngine.resetZoom();
    });

    // Pause Modal buttons
    document.getElementById('btn-pause-resume')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalPause.classList.add('hidden');
    });

    document.getElementById('btn-pause-restart')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalPause.classList.add('hidden');
      if (this.currentLevelData) this.startLevel(this.currentLevelData);
    });

    document.getElementById('btn-pause-levels')?.addEventListener('click', () => {
      this.elModalPause.classList.add('hidden');
      this.switchScreen('LEVEL_SELECT');
    });

    document.getElementById('btn-pause-menu')?.addEventListener('click', () => {
      this.elModalPause.classList.add('hidden');
      this.switchScreen('HOME');
    });

    // Victory Modal buttons
    document.getElementById('btn-victory-next')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalVictory.classList.add('hidden');
      this.loadLevelByNumber(this.currentLevelIndex + 1);
    });

    document.getElementById('btn-victory-replay')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalVictory.classList.add('hidden');
      if (this.currentLevelData) this.startLevel(this.currentLevelData);
    });

    document.getElementById('btn-victory-menu')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalVictory.classList.add('hidden');
      this.switchScreen('HOME');
    });

    // Game Over / Rewarded Ad Extra Heart Modal buttons
    document.getElementById('btn-gameover-watch-ad')?.addEventListener('click', () => {
      void this.handleWatchExtraHeartAd();
    });

    document.getElementById('btn-gameover-no-thanks')?.addEventListener('click', () => {
      if (this.isWatchingRewardedAd) return;
      sound.playClick();
      document.getElementById('gameover-ad-offer')?.classList.add('hidden');
      document.getElementById('gameover-standard-actions')?.classList.remove('hidden');
      const elSubtitle = document.getElementById('gameover-subtitle');
      if (elSubtitle) {
        elSubtitle.textContent = 'Look for outer arrows whose exit ray is completely clear first!';
      }
    });

    document.getElementById('btn-gameover-retry')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalGameOver.classList.add('hidden');
      if (this.currentLevelData) this.startLevel(this.currentLevelData);
    });

    document.getElementById('btn-gameover-menu')?.addEventListener('click', () => {
      sound.playClick();
      this.elModalGameOver.classList.add('hidden');
      this.switchScreen('HOME');
    });

    // Rewarded Hint Modal buttons
    document.getElementById('btn-hint-watch-ad')?.addEventListener('click', () => {
      void this.handleWatchHintRewardAd();
    });

    document.getElementById('btn-hint-cancel')?.addEventListener('click', () => {
      if (this.isWatchingRewardedAd) return;
      sound.playClick();
      this.elModalHintReward?.classList.add('hidden');
    });

    // Navigation back buttons
    document.getElementById('btn-levels-back')?.addEventListener('click', () => {
      this.switchScreen('HOME');
    });

    document.getElementById('btn-creator-back')?.addEventListener('click', () => {
      this.switchScreen('HOME');
    });

    document.getElementById('btn-mylevels-back')?.addEventListener('click', () => {
      this.switchScreen('HOME');
    });

    document.getElementById('btn-mylevels-add')?.addEventListener('click', () => {
      this.switchScreen('DRAWING');
    });

    document.getElementById('btn-play-endless')?.addEventListener('click', () => {
      const data = storage.getData();
      const lvl = Math.max(11, data.currentLevel);
      this.loadLevelByNumber(lvl, 'LEVEL_SELECT');
    });

    // Drawing & Preview Creator controls
    document.getElementById('btn-creator-clear')?.addEventListener('click', () => {
      if (!this.elPreviewCanvas.classList.contains('hidden')) {
        this.enterCreatorDrawMode();
      }
      this.drawingBoard.clear();
    });

    document.getElementById('btn-creator-undo')?.addEventListener('click', () => {
      this.drawingBoard.undo();
    });

    document.getElementById('btn-creator-preview')?.addEventListener('click', () => {
      this.generatePreviewPuzzle();
    });

    document.getElementById('btn-creator-generate')?.addEventListener('click', () => {
      this.generatePreviewPuzzle();
    });

    document.getElementById('btn-creator-regenerate')?.addEventListener('click', () => {
      this.generatePreviewPuzzle();
    });

    document.getElementById('btn-creator-retry')?.addEventListener('click', () => {
      sound.playClick();
      this.enterCreatorDrawMode();
    });

    document.getElementById('btn-creator-save')?.addEventListener('click', () => {
      this.savePendingCustomLevel();
    });

    document.querySelectorAll('.btn-template').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const shape = (e.currentTarget as HTMLElement).dataset.shape as
          | 'freehand'
          | 'circle'
          | 'square'
          | 'triangle'
          | 'star'
          | 'heart';
        if (shape) {
          this.drawingBoard.setTemplate(shape);
          document.querySelectorAll('.btn-template').forEach((b) => {
            b.className =
              'btn-template px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium bg-slate-50 active:bg-blue-50 shrink-0';
          });
          (e.currentTarget as HTMLElement).className =
            'btn-template px-3 py-1.5 rounded-lg border border-blue-500 text-xs font-semibold bg-blue-50 text-blue-700 shrink-0';
        }
      });
    });

    const slider = document.getElementById('slider-arrow-count') as HTMLInputElement;
    const label = document.getElementById('label-arrow-count');
    if (slider && label) {
      slider.addEventListener('input', () => {
        const val = parseInt(slider.value, 10);
        label.textContent = String(val);
        this.drawingBoard.setTargetArrows(val);
      });
    }

    // --- Advanced Audio & Vibration Settings Modal ---

    document.getElementById('btn-settings-close')?.addEventListener('click', () => {
      this.closeSettingsModal();
    });
    document.getElementById('btn-settings-done')?.addEventListener('click', () => {
      this.closeSettingsModal();
    });

    const toggleMusic = document.getElementById('toggle-music') as HTMLInputElement;
    if (toggleMusic) {
      toggleMusic.addEventListener('change', () => {
        sound.setMusicEnabled(toggleMusic.checked);
        storage.updateSettings({ music: toggleMusic.checked });
        sound.playClick();
        this.syncSettingsUI();
      });
    }

    const sliderMusic = document.getElementById('slider-music-volume') as HTMLInputElement;
    const labelMusic = document.getElementById('label-music-volume');
    if (sliderMusic) {
      sliderMusic.addEventListener('input', () => {
        const vol = parseInt(sliderMusic.value, 10);
        sound.setMusicVolume(vol);
        if (labelMusic) labelMusic.textContent = `${vol}%`;
        storage.updateSettings({ musicVolume: vol });
      });
    }

    const toggleSound = document.getElementById('toggle-sound') as HTMLInputElement;
    if (toggleSound) {
      toggleSound.addEventListener('change', () => {
        sound.setSoundEnabled(toggleSound.checked);
        storage.updateSettings({ sound: toggleSound.checked });
        this.syncSettingsUI();
        if (toggleSound.checked) sound.playClick();
      });
    }

    const sliderSfx = document.getElementById('slider-sfx-volume') as HTMLInputElement;
    const labelSfx = document.getElementById('label-sfx-volume');
    if (sliderSfx) {
      sliderSfx.addEventListener('input', () => {
        const vol = parseInt(sliderSfx.value, 10);
        sound.setSfxVolume(vol);
        if (labelSfx) labelSfx.textContent = `${vol}%`;
        storage.updateSettings({ soundVolume: vol });
      });
      sliderSfx.addEventListener('change', () => {
        sound.playTap();
      });
    }

    const toggleHaptics = document.getElementById('toggle-haptics') as HTMLInputElement;
    if (toggleHaptics) {
      toggleHaptics.addEventListener('change', () => {
        sound.setHapticsEnabled(toggleHaptics.checked);
        storage.updateSettings({ haptics: toggleHaptics.checked });
        sound.playClick();
        if (toggleHaptics.checked) {
          sound.vibrate(30);
        }
      });
    }

    document.getElementById('btn-settings-reset-audio')?.addEventListener('click', () => {
      storage.resetSettings();
      this.syncSettingsUI();
      sound.playClick();
    });

    document.getElementById('btn-settings-privacy')?.addEventListener('click', () => {
      sound.playClick();
      void adManager.openPrivacyOptions().then(() => this.syncPrivacyButtonUI());
    });

    document.getElementById('btn-settings-reset')?.addEventListener('click', () => {
      if (confirm('Are you sure you want to reset all game progress?')) {
        storage.resetProgress();
        this.updateHomeUI();
        this.renderLevelGrid();
        this.elModalSettings.classList.add('hidden');
      }
    });
  }

  private syncPrivacyButtonUI() {
    const btnPrivacy = document.getElementById('btn-settings-privacy');
    if (!btnPrivacy) return;
    if (adManager.isPrivacyOptionsRequired()) {
      btnPrivacy.classList.remove('hidden');
    } else {
      btnPrivacy.classList.add('hidden');
    }
  }

  private bindSocialLinks() {
    const socialConfigs: Record<
      string,
      { webUrl: string; androidPackage: string; appScheme: string }
    > = {
      instagram: {
        webUrl: 'https://www.instagram.com/sonu__babbu__9/',
        androidPackage: 'com.instagram.android',
        appScheme: 'instagram://user?username=sonu__babbu__9',
      },
      youtube1: {
        webUrl: 'https://youtube.com/@mujjustoryhub?si=cXxMA0PQPBCg2bm_',
        androidPackage: 'com.google.android.youtube',
        appScheme: 'vnd.youtube://www.youtube.com/@mujjustoryhub',
      },
      youtube2: {
        webUrl: 'https://youtube.com/@allfactrush?si=P4iHNpA8hGqM1Qrg',
        androidPackage: 'com.google.android.youtube',
        appScheme: 'vnd.youtube://www.youtube.com/@allfactrush',
      },
    };

    document.querySelectorAll<HTMLAnchorElement>('[data-social]').forEach((anchor) => {
      anchor.addEventListener('click', (e) => {
        sound.playClick();
        const key = anchor.dataset.social || '';
        const cfg = socialConfigs[key];
        if (!cfg) return;

        const ua = navigator.userAgent || '';
        const isAndroid = /Android/i.test(ua);
        const cap = (
          window as unknown as {
            Capacitor?: {
              isNativePlatform?: () => boolean;
              Plugins?: {
                AppLauncher?: {
                  canOpenUrl?: (opts: { url: string }) => Promise<{ value: boolean }>;
                  openUrl?: (opts: { url: string }) => Promise<void>;
                };
                Browser?: { open?: (opts: { url: string }) => Promise<void> };
              };
            };
          }
        ).Capacitor;

        const isNativeCapacitor = Boolean(cap?.isNativePlatform?.());

        if (isNativeCapacitor && isAndroid) {
          e.preventDefault();
          const openWithCapacitor = async () => {
            try {
              if (cap?.Plugins?.AppLauncher?.openUrl) {
                const canOpen = cap.Plugins.AppLauncher.canOpenUrl
                  ? await cap.Plugins.AppLauncher.canOpenUrl({ url: cfg.appScheme })
                  : { value: true };
                if (canOpen.value) {
                  await cap.Plugins.AppLauncher.openUrl({ url: cfg.appScheme });
                  return;
                }
              }
            } catch {
              // Fall back to browser below
            }
            if (cap?.Plugins?.Browser?.open) {
              try {
                await cap.Plugins.Browser.open({ url: cfg.webUrl });
                return;
              } catch {
                // Fall back to intent/href below
              }
            }
            window.location.href = cfg.webUrl;
          };
          void openWithCapacitor();
          return;
        }

        // On standalone Android browser (not inside an iframe), use Android Intent with browser fallback
        if (isAndroid && window.top === window.self) {
          e.preventDefault();
          const cleanHostPath = cfg.webUrl.replace(/^https?:\/\//, '');
          const intentUrl = `intent://${cleanHostPath}#Intent;package=${cfg.androidPackage};scheme=https;S.browser_fallback_url=${encodeURIComponent(
            cfg.webUrl
          )};end`;
          window.location.href = intentUrl;
        }
        // Desktop & preview iframe: native <a href="..." target="_blank" rel="noopener noreferrer"> opens directly
      });
    });
  }

  private loadLevelByNumber(num: number, fromScreen?: ScreenState) {
    if (num <= 10) {
      const lvl = INITIAL_LEVELS.find((l) => l.levelNumber === num) || INITIAL_LEVELS[0];
      this.startLevel(lvl, fromScreen);
    } else {
      // Check if player created a custom level assigned to this level number first
      const savedCustom = storage.getCustomLevelByNumber(num);
      if (savedCustom) {
        this.startLevel(savedCustom, fromScreen);
        return;
      }
      const generated = generateProceduralLevel(num);
      this.startLevel(generated, fromScreen);
    }
  }

  private syncGridButtonUI() {
    const isGrid = this.gameEngine.getShowGrid();
    if (isGrid) {
      this.elBtnGrid.classList.add('active');
    } else {
      this.elBtnGrid.classList.remove('active');
    }
  }

  private syncSettingsUI() {
    const settings = storage.getData().settings;

    sound.setSoundEnabled(settings.sound);
    sound.setSfxVolume(settings.soundVolume);
    sound.setMusicEnabled(settings.music);
    sound.setMusicVolume(settings.musicVolume);
    sound.setHapticsEnabled(settings.haptics);
    this.gameEngine.setShowGrid(settings.showGrid);
    this.syncGridButtonUI();

    const toggleMusic = document.getElementById('toggle-music') as HTMLInputElement;
    if (toggleMusic) toggleMusic.checked = settings.music;

    const sliderMusic = document.getElementById('slider-music-volume') as HTMLInputElement;
    const labelMusic = document.getElementById('label-music-volume');
    if (sliderMusic) {
      sliderMusic.value = String(settings.musicVolume);
      sliderMusic.disabled = !settings.music;
    }
    if (labelMusic) {
      labelMusic.textContent = settings.music ? `${settings.musicVolume}%` : 'Muted';
    }

    const toggleSound = document.getElementById('toggle-sound') as HTMLInputElement;
    if (toggleSound) toggleSound.checked = settings.sound;

    const sliderSfx = document.getElementById('slider-sfx-volume') as HTMLInputElement;
    const labelSfx = document.getElementById('label-sfx-volume');
    if (sliderSfx) {
      sliderSfx.value = String(settings.soundVolume);
      sliderSfx.disabled = !settings.sound;
    }
    if (labelSfx) {
      labelSfx.textContent = settings.sound ? `${settings.soundVolume}%` : 'Muted';
    }

    const toggleHaptics = document.getElementById('toggle-haptics') as HTMLInputElement;
    const labelHaptics = document.getElementById('label-haptics-support');
    if (toggleHaptics) {
      toggleHaptics.checked = settings.haptics;
      if (!sound.isHapticsSupported()) {
        toggleHaptics.disabled = true;
        if (labelHaptics) labelHaptics.textContent = 'Not supported on this browser/device';
      } else {
        toggleHaptics.disabled = false;
        if (labelHaptics) labelHaptics.textContent = 'Haptic feedback on errors & wins';
      }
    }
    this.syncPrivacyButtonUI();
  }
}

window.addEventListener('DOMContentLoaded', () => {
  new ArrowMasterApp();
});
