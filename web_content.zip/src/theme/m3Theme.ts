/**
 * Material Design 3 (M3) Dynamic Tonal Palette Engine
 * Generates tonal palettes and semantic CSS variables conforming to Material You standards.
 */

export interface M3Palette {
  primary: string;
  onPrimary: string;
  primaryContainer: string;
  onPrimaryContainer: string;
  secondary: string;
  onSecondary: string;
  secondaryContainer: string;
  onSecondaryContainer: string;
  tertiary: string;
  onTertiary: string;
  tertiaryContainer: string;
  onTertiaryContainer: string;
  error: string;
  onError: string;
  errorContainer: string;
  onErrorContainer: string;
  background: string;
  onBackground: string;
  surface: string;
  onSurface: string;
  surfaceVariant: string;
  onSurfaceVariant: string;
  surfaceContainerLowest: string;
  surfaceContainerLow: string;
  surfaceContainer: string;
  surfaceContainerHigh: string;
  surfaceContainerHighest: string;
  outline: string;
  outlineVariant: string;
  inverseSurface: string;
  inverseOnSurface: string;
  inversePrimary: string;
}

export type ThemeMode = 'preset' | 'manual' | 'auto';
export type ColorSchemePreference = 'system' | 'light' | 'dark';

export interface ThemePreset {
  id: string;
  name: string;
  seedHex: string;
  secondaryHex?: string;
  tertiaryHex?: string;
}

export const M3_PRESETS: ThemePreset[] = [
  { id: 'ocean-blue', name: 'Ocean Blue', seedHex: '#1E88E5', secondaryHex: '#0284C7', tertiaryHex: '#0D9488' },
  { id: 'blue-grey', name: 'Blue Grey', seedHex: '#546E7A', secondaryHex: '#64748B', tertiaryHex: '#475569' },
  { id: 'lavender', name: 'Lavender', seedHex: '#7E57C2', secondaryHex: '#9333EA', tertiaryHex: '#C026D3' },
  { id: 'emerald', name: 'Emerald', seedHex: '#10B981', secondaryHex: '#059669', tertiaryHex: '#14B8A6' },
  { id: 'rose', name: 'Rose', seedHex: '#E91E63', secondaryHex: '#F43F5E', tertiaryHex: '#FB7185' },
  { id: 'amber', name: 'Amber', seedHex: '#F59E0B', secondaryHex: '#D97706', tertiaryHex: '#EA580C' },
  { id: 'graphite', name: 'Graphite', seedHex: '#374151', secondaryHex: '#4B5563', tertiaryHex: '#1F2937' },
];

// Helper: Convert HEX to RGB
export function hexToRgb(hex: string): [number, number, number] {
  let c = hex.replace('#', '').trim();
  if (c.length === 3) {
    c = c.split('').map(x => x + x).join('');
  }
  const num = parseInt(c, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

// Helper: Convert RGB to HEX
export function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  const toHex = (v: number) => clamp(v).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

// Helper: Convert RGB to HSL
export function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}

// Helper: Convert HSL to RGB
export function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  h = (h % 360 + 360) % 360;
  s = Math.max(0, Math.min(100, s)) / 100;
  l = Math.max(0, Math.min(100, l)) / 100;

  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs((h / 60) % 2 - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;

  if (0 <= h && h < 60) { r = c; g = x; b = 0; }
  else if (60 <= h && h < 120) { r = x; g = c; b = 0; }
  else if (120 <= h && h < 180) { r = 0; g = c; b = x; }
  else if (180 <= h && h < 240) { r = 0; g = x; b = c; }
  else if (240 <= h && h < 300) { r = x; g = 0; b = c; }
  else if (300 <= h && h < 360) { r = c; g = 0; b = x; }

  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}

// Generate an M3 tonal step (Tone 0..100) given a base hue and saturation
export function toneToHex(h: number, s: number, tone: number): string {
  // Tone is perceptual lightness 0..100
  // Saturation adjusts slightly with tone to prevent oversaturation in deep tones
  const adjustedS = tone > 90 ? s * 0.6 : tone < 20 ? s * 0.8 : s;
  const [r, g, b] = hslToRgb(h, adjustedS, tone);
  return rgbToHex(r, g, b);
}

/**
 * Generates complete Material Design 3 Light and Dark schemes from a seed hex color
 */
export function generateM3Theme(seedHex: string): { light: M3Palette; dark: M3Palette } {
  const [r, g, b] = hexToRgb(seedHex);
  const [h, s] = rgbToHsl(r, g, b);

  // Derive secondary hue (harmonized slightly shifted hue or complementary)
  const secondaryHue = (h + 15) % 360;
  const secondarySat = Math.max(16, Math.min(45, s * 0.5));

  // Derive tertiary hue (60 degrees offset)
  const tertiaryHue = (h + 60) % 360;
  const tertiarySat = Math.max(25, Math.min(65, s * 0.7));

  // Neutral and Neutral Variant hues (desaturated primary)
  const neutralHue = h;
  const neutralSat = Math.min(10, Math.max(4, s * 0.12));
  const neutralVariantSat = Math.min(16, Math.max(8, s * 0.2));

  // Light Scheme
  const light: M3Palette = {
    primary: toneToHex(h, s, 40),
    onPrimary: toneToHex(h, s, 100),
    primaryContainer: toneToHex(h, s, 90),
    onPrimaryContainer: toneToHex(h, s, 10),
    
    secondary: toneToHex(secondaryHue, secondarySat, 40),
    onSecondary: toneToHex(secondaryHue, secondarySat, 100),
    secondaryContainer: toneToHex(secondaryHue, secondarySat, 90),
    onSecondaryContainer: toneToHex(secondaryHue, secondarySat, 10),

    tertiary: toneToHex(tertiaryHue, tertiarySat, 40),
    onTertiary: toneToHex(tertiaryHue, tertiarySat, 100),
    tertiaryContainer: toneToHex(tertiaryHue, tertiarySat, 90),
    onTertiaryContainer: toneToHex(tertiaryHue, tertiarySat, 10),

    error: '#BA1A1A',
    onError: '#FFFFFF',
    errorContainer: '#FFDAD6',
    onErrorContainer: '#410002',

    background: toneToHex(neutralHue, neutralSat, 98),
    onBackground: toneToHex(neutralHue, neutralSat, 10),
    surface: toneToHex(neutralHue, neutralSat, 98),
    onSurface: toneToHex(neutralHue, neutralSat, 10),
    surfaceVariant: toneToHex(neutralHue, neutralVariantSat, 90),
    onSurfaceVariant: toneToHex(neutralHue, neutralVariantSat, 30),

    surfaceContainerLowest: '#FFFFFF',
    surfaceContainerLow: toneToHex(neutralHue, neutralSat, 96),
    surfaceContainer: toneToHex(neutralHue, neutralSat, 94),
    surfaceContainerHigh: toneToHex(neutralHue, neutralSat, 92),
    surfaceContainerHighest: toneToHex(neutralHue, neutralSat, 90),

    outline: toneToHex(neutralHue, neutralVariantSat, 50),
    outlineVariant: toneToHex(neutralHue, neutralVariantSat, 80),
    inverseSurface: toneToHex(neutralHue, neutralSat, 20),
    inverseOnSurface: toneToHex(neutralHue, neutralSat, 95),
    inversePrimary: toneToHex(h, s, 80),
  };

  // Dark Scheme
  const dark: M3Palette = {
    primary: toneToHex(h, s, 80),
    onPrimary: toneToHex(h, s, 20),
    primaryContainer: toneToHex(h, s, 30),
    onPrimaryContainer: toneToHex(h, s, 90),

    secondary: toneToHex(secondaryHue, secondarySat, 80),
    onSecondary: toneToHex(secondaryHue, secondarySat, 20),
    secondaryContainer: toneToHex(secondaryHue, secondarySat, 30),
    onSecondaryContainer: toneToHex(secondaryHue, secondarySat, 90),

    tertiary: toneToHex(tertiaryHue, tertiarySat, 80),
    onTertiary: toneToHex(tertiaryHue, tertiarySat, 20),
    tertiaryContainer: toneToHex(tertiaryHue, tertiarySat, 30),
    onTertiaryContainer: toneToHex(tertiaryHue, tertiarySat, 90),

    error: '#FFB4AB',
    onError: '#690005',
    errorContainer: '#93000A',
    onErrorContainer: '#FFDAD6',

    background: toneToHex(neutralHue, neutralSat, 6),
    onBackground: toneToHex(neutralHue, neutralSat, 90),
    surface: toneToHex(neutralHue, neutralSat, 8),
    onSurface: toneToHex(neutralHue, neutralSat, 90),
    surfaceVariant: toneToHex(neutralHue, neutralVariantSat, 30),
    onSurfaceVariant: toneToHex(neutralHue, neutralVariantSat, 80),

    surfaceContainerLowest: toneToHex(neutralHue, neutralSat, 4),
    surfaceContainerLow: toneToHex(neutralHue, neutralSat, 10),
    surfaceContainer: toneToHex(neutralHue, neutralSat, 12),
    surfaceContainerHigh: toneToHex(neutralHue, neutralSat, 17),
    surfaceContainerHighest: toneToHex(neutralHue, neutralSat, 22),

    outline: toneToHex(neutralHue, neutralVariantSat, 60),
    outlineVariant: toneToHex(neutralHue, neutralVariantSat, 30),
    inverseSurface: toneToHex(neutralHue, neutralSat, 90),
    inverseOnSurface: toneToHex(neutralHue, neutralSat, 20),
    inversePrimary: toneToHex(h, s, 40),
  };

  return { light, dark };
}

/**
 * Injects M3 CSS custom properties onto the document root
 */
export function applyM3ThemeToCss(palette: M3Palette, isDark: boolean): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;

  const mapping: Record<string, string> = {
    '--md-sys-color-primary': palette.primary,
    '--md-sys-color-on-primary': palette.onPrimary,
    '--md-sys-color-primary-container': palette.primaryContainer,
    '--md-sys-color-on-primary-container': palette.onPrimaryContainer,
    '--md-sys-color-secondary': palette.secondary,
    '--md-sys-color-on-secondary': palette.onSecondary,
    '--md-sys-color-secondary-container': palette.secondaryContainer,
    '--md-sys-color-on-secondary-container': palette.onSecondaryContainer,
    '--md-sys-color-tertiary': palette.tertiary,
    '--md-sys-color-on-tertiary': palette.onTertiary,
    '--md-sys-color-tertiary-container': palette.tertiaryContainer,
    '--md-sys-color-on-tertiary-container': palette.onTertiaryContainer,
    '--md-sys-color-error': palette.error,
    '--md-sys-color-on-error': palette.onError,
    '--md-sys-color-error-container': palette.errorContainer,
    '--md-sys-color-on-error-container': palette.onErrorContainer,
    '--md-sys-color-background': palette.background,
    '--md-sys-color-on-background': palette.onBackground,
    '--md-sys-color-surface': palette.surface,
    '--md-sys-color-on-surface': palette.onSurface,
    '--md-sys-color-surface-variant': palette.surfaceVariant,
    '--md-sys-color-on-surface-variant': palette.onSurfaceVariant,
    '--md-sys-color-surface-container-lowest': palette.surfaceContainerLowest,
    '--md-sys-color-surface-container-low': palette.surfaceContainerLow,
    '--md-sys-color-surface-container': palette.surfaceContainer,
    '--md-sys-color-surface-container-high': palette.surfaceContainerHigh,
    '--md-sys-color-surface-container-highest': palette.surfaceContainerHighest,
    '--md-sys-color-outline': palette.outline,
    '--md-sys-color-outline-variant': palette.outlineVariant,
    '--md-sys-color-inverse-surface': palette.inverseSurface,
    '--md-sys-color-inverse-on-surface': palette.inverseOnSurface,
    '--md-sys-color-inverse-primary': palette.inversePrimary,
  };

  for (const [key, value] of Object.entries(mapping)) {
    root.style.setProperty(key, value);
  }

  // Set color-scheme
  root.style.colorScheme = isDark ? 'dark' : 'light';
  if (isDark) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  // Also update meta theme-color tag
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    metaTheme.setAttribute('content', palette.surface);
  }
}
