/**
 * Client-Side Image Wallpaper Dominant Color Extractor
 * Extracts dominant accent colors from uploaded images for Material 3 dynamic theming.
 */

import { rgbToHex, rgbToHsl } from './m3Theme';

export interface ExtractedColor {
  hex: string;
  count: number;
  hue: number;
  saturation: number;
  lightness: number;
  score: number;
}

/**
 * Extracts candidate theme colors from an image File or Data URL
 */
export async function extractColorsFromImage(imageSource: File | string, maxColors = 6): Promise<{ dominantHex: string; palette: string[] }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';

    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({ dominantHex: '#1E88E5', palette: ['#1E88E5'] });
          return;
        }

        // Downscale for fast and smooth sampling
        const width = 80;
        const height = Math.round((img.height / img.width) * width) || 80;
        canvas.width = width;
        canvas.height = height;

        ctx.drawImage(img, 0, 0, width, height);
        const imgData = ctx.getImageData(0, 0, width, height).data;

        // Bucket colors into coarse RGB buckets (quantization)
        const bucketMap = new Map<string, { r: number; g: number; b: number; count: number }>();

        for (let i = 0; i < imgData.length; i += 4) {
          const a = imgData[i + 3];
          if (a < 128) continue; // Skip transparent

          const r = imgData[i];
          const g = imgData[i + 1];
          const b = imgData[i + 2];

          // Quantize to 16 levels per channel
          const qr = Math.floor(r / 16) * 16;
          const qg = Math.floor(g / 16) * 16;
          const qb = Math.floor(b / 16) * 16;

          const key = `${qr},${qg},${qb}`;
          const current = bucketMap.get(key);
          if (current) {
            current.count += 1;
          } else {
            bucketMap.set(key, { r: qr + 8, g: qg + 8, b: qb + 8, count: 1 });
          }
        }

        // Score buckets based on saturation, natural lightness, and frequency
        const candidates: ExtractedColor[] = [];

        for (const bucket of bucketMap.values()) {
          const [h, s, l] = rgbToHsl(bucket.r, bucket.g, bucket.b);

          // Discard pure blacks, pure whites, and muddy grays for seed color
          if (l < 15 || l > 92) continue;
          if (s < 12) continue;

          // Material You prioritizes colors with high chroma and pleasant midtone lightness
          const saturationScore = s / 100;
          const lightnessPenalty = 1 - Math.abs(l - 50) / 50;
          const countWeight = Math.log10(bucket.count + 1);

          const score = (saturationScore * 1.5 + lightnessPenalty * 0.8) * countWeight;

          candidates.push({
            hex: rgbToHex(bucket.r, bucket.g, bucket.b),
            count: bucket.count,
            hue: h,
            saturation: s,
            lightness: l,
            score,
          });
        }

        // Sort by score descending
        candidates.sort((a, b) => b.score - a.score);

        // Pick distinct hues (at least 35 degrees apart)
        const uniquePalette: string[] = [];
        for (const c of candidates) {
          const isTooClose = uniquePalette.some(hex => {
            const [cr, cg, cb] = hexToRgb(hex);
            const [ch] = rgbToHsl(cr, cg, cb);
            const diff = Math.min(Math.abs(ch - c.hue), 360 - Math.abs(ch - c.hue));
            return diff < 30;
          });

          if (!isTooClose) {
            uniquePalette.push(c.hex);
            if (uniquePalette.length >= maxColors) break;
          }
        }

        if (uniquePalette.length === 0) {
          // Fallback to average or preset
          uniquePalette.push('#1E88E5', '#546E7A', '#10B981');
        }

        resolve({
          dominantHex: uniquePalette[0],
          palette: uniquePalette,
        });
      } catch (err) {
        console.error('Failed to extract colors from image:', err);
        resolve({ dominantHex: '#1E88E5', palette: ['#1E88E5'] });
      }
    };

    img.onerror = (err) => {
      reject(err);
    };

    if (typeof imageSource === 'string') {
      img.src = imageSource;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(imageSource);
    }
  });
}

function hexToRgb(hex: string): [number, number, number] {
  let c = hex.replace('#', '').trim();
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  const num = parseInt(c, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}
