/**
 * xvBOARD Advanced Stylus & Palm Rejection Engine
 * High-precision pointer event processor, palm contact filtering, and pressure interpolation.
 */

import { StylusSettings, StrokePoint } from './types';
import { calculatePressureWidth } from './geometry';

export interface PointerInputState {
  isPenActive: boolean;
  penPointerId: number | null;
  activeTouchPointers: Map<number, { x: number; y: number; width?: number; height?: number; time: number }>;
  lastPenHover: { x: number; y: number; pressure: number } | null;
  isTwoFingerNavigating: boolean;
  twoFingerStartDistance: number;
  twoFingerStartCenter: { x: number; y: number };
}

export class StylusManager {
  private settings: StylusSettings;
  private state: PointerInputState = {
    isPenActive: false,
    penPointerId: null,
    activeTouchPointers: new Map(),
    lastPenHover: null,
    isTwoFingerNavigating: false,
    twoFingerStartDistance: 0,
    twoFingerStartCenter: { x: 0, y: 0 },
  };

  constructor(settings: StylusSettings) {
    this.settings = settings;
  }

  public updateSettings(settings: StylusSettings): void {
    this.settings = settings;
  }

  /**
   * Evaluates incoming pointer event against palm rejection heuristics
   * Returns:
   * - 'pen-draw': Active pen drawing input
   * - 'touch-draw': Valid touch drawing input (if pen-only is disabled)
   * - 'palm-reject': Rejected accidental palm or edge contact
   * - 'touch-navigation': Two-finger pan/zoom navigation gesture
   * - 'hover': Stylus hovering above the screen
   */
  public evaluatePointerDown(e: React.PointerEvent): 'pen-draw' | 'touch-draw' | 'palm-reject' | 'touch-navigation' {
    const isPen = e.pointerType === 'pen';
    const isTouch = e.pointerType === 'touch';

    // 1. Stylus / Pen Input
    if (isPen) {
      this.state.isPenActive = true;
      this.state.penPointerId = e.pointerId;
      // When stylus touches down, discard any active touch pointers to prevent palm interference
      this.state.activeTouchPointers.clear();
      this.state.isTwoFingerNavigating = false;
      return 'pen-draw';
    }

    // 2. Touch Input
    if (isTouch) {
      // If stylus is currently active or recently drew, immediately reject any touch down
      if (this.state.isPenActive && this.settings.palmRejectionSensitivity !== 'off') {
        return 'palm-reject';
      }

      // Check contact dimensions for palm rejection (Huawei M-Pen, Samsung S-Pen, iPad pencil touch models)
      // Browsers supporting touch contact area report e.width and e.height in CSS pixels
      const contactWidth = e.width || 0;
      const contactHeight = e.height || 0;
      const palmThreshold = this.settings.palmRejectionSensitivity === 'high' ? 24 :
                             this.settings.palmRejectionSensitivity === 'medium' ? 32 : 44;

      if (this.settings.palmRejectionSensitivity !== 'off' && (contactWidth > palmThreshold || contactHeight > palmThreshold)) {
        return 'palm-reject';
      }

      // Track touch pointer
      this.state.activeTouchPointers.set(e.pointerId, {
        x: e.clientX,
        y: e.clientY,
        width: contactWidth,
        height: contactHeight,
        time: Date.now(),
      });

      // Check for two-finger navigation
      if (this.state.activeTouchPointers.size === 2) {
        this.state.isTwoFingerNavigating = true;
        const pts = Array.from(this.state.activeTouchPointers.values());
        this.state.twoFingerStartDistance = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
        this.state.twoFingerStartCenter = {
          x: (pts[0].x + pts[1].x) / 2,
          y: (pts[0].y + pts[1].y) / 2,
        };
        return 'touch-navigation';
      }

      // If Pen-Only Inking is enabled in settings, finger is NEVER for drawing, only panning
      if (this.settings.penOnlyInking) {
        return 'touch-navigation';
      }

      return 'touch-draw';
    }

    // Mouse or default pointer
    return 'touch-draw';
  }

  public evaluatePointerMove(e: React.PointerEvent): {
    action: 'draw-move' | 'palm-reject' | 'nav-move' | 'hover';
    pressure: number;
    point: StrokePoint;
  } {
    const isPen = e.pointerType === 'pen';
    const isTouch = e.pointerType === 'touch';

    // Stylus Hover (pen in range without touching display)
    if (isPen && e.buttons === 0) {
      this.state.lastPenHover = { x: e.clientX, y: e.clientY, pressure: 0 };
      return {
        action: 'hover',
        pressure: 0,
        point: { x: e.clientX, y: e.clientY, pressure: 0 },
      };
    }

    // Pen Active Drawing
    if (isPen && (e.buttons > 0 || this.state.isPenActive)) {
      const pressure = this.settings.pressureSensitivity && e.pressure > 0 ? e.pressure : 0.5;
      return {
        action: 'draw-move',
        pressure,
        point: { x: e.clientX, y: e.clientY, pressure },
      };
    }

    // Touch moving while pen is active -> Reject as palm slide
    if (isTouch && this.state.isPenActive && this.settings.palmRejectionSensitivity !== 'off') {
      return {
        action: 'palm-reject',
        pressure: 0,
        point: { x: e.clientX, y: e.clientY },
      };
    }

    // Update touch pointer tracking
    if (isTouch && this.state.activeTouchPointers.has(e.pointerId)) {
      this.state.activeTouchPointers.set(e.pointerId, {
        x: e.clientX,
        y: e.clientY,
        time: Date.now(),
      });
    }

    // Two finger navigation
    if (this.state.isTwoFingerNavigating || this.state.activeTouchPointers.size >= 2) {
      return {
        action: 'nav-move',
        pressure: 0,
        point: { x: e.clientX, y: e.clientY },
      };
    }

    if (this.settings.penOnlyInking && isTouch) {
      return {
        action: 'nav-move',
        pressure: 0,
        point: { x: e.clientX, y: e.clientY },
      };
    }

    return {
      action: 'draw-move',
      pressure: 0.5,
      point: { x: e.clientX, y: e.clientY, pressure: 0.5 },
    };
  }

  public handlePointerUp(e: React.PointerEvent): void {
    if (e.pointerType === 'pen') {
      this.state.isPenActive = false;
      this.state.penPointerId = null;
    }
    this.state.activeTouchPointers.delete(e.pointerId);
    if (this.state.activeTouchPointers.size < 2) {
      this.state.isTwoFingerNavigating = false;
    }
  }

  public reset(): void {
    this.state.isPenActive = false;
    this.state.penPointerId = null;
    this.state.activeTouchPointers.clear();
    this.state.isTwoFingerNavigating = false;
    this.state.lastPenHover = null;
  }

  public getHoverState() {
    return this.settings.showHoverCursor ? this.state.lastPenHover : null;
  }
}
