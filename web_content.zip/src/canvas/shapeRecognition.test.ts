import { describe, it } from 'node:test';
import assert from 'node:assert';
import { recognizeShape } from './shapeRecognition';
import { StrokePoint } from './types';

describe('xvBOARD Shape Recognition Engine', () => {
  it('recognizes a straight horizontal line and snaps dy to 0', () => {
    // Generate rough line from (100, 100) to (300, 102)
    const points: StrokePoint[] = [];
    for (let x = 100; x <= 300; x += 10) {
      const noisyY = 100 + (Math.sin(x) * 1.5);
      points.push({ x, y: noisyY, pressure: 0.5 });
    }

    const recognized = recognizeShape(points, '#38bdf8', 4);
    assert.ok(recognized !== null, 'Should recognize horizontal line');
    assert.strictEqual(recognized.type, 'line');
    assert.strictEqual(recognized.height, 0, 'Should snap slight deviation to exact horizontal');
  });

  it('recognizes a straight vertical line and snaps dx to 0', () => {
    const points: StrokePoint[] = [];
    for (let y = 50; y <= 250; y += 10) {
      const noisyX = 200 + (Math.cos(y) * 1.2);
      points.push({ x: noisyX, y, pressure: 0.5 });
    }

    const recognized = recognizeShape(points, '#10b981', 3);
    assert.ok(recognized !== null, 'Should recognize vertical line');
    assert.strictEqual(recognized.type, 'line');
    assert.strictEqual(recognized.width, 0, 'Should snap slight deviation to exact vertical');
  });

  it('recognizes a rough hand-drawn circle (1:1 ratio)', () => {
    const points: StrokePoint[] = [];
    const cx = 200;
    const cy = 200;
    const radius = 60;
    // 36 steps around circle with slight radial noise
    for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.15) {
      const r = radius + (Math.sin(a * 4) * 2.5);
      points.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a), pressure: 0.5 });
    }

    const recognized = recognizeShape(points, '#c084fc', 4);
    assert.ok(recognized !== null, 'Should recognize circle');
    assert.strictEqual(recognized.type, 'circle');
    // Equalized width and height for a perfect circle
    assert.strictEqual(recognized.width, recognized.height);
  });

  it('recognizes a rough hand-drawn oval / ellipse', () => {
    const points: StrokePoint[] = [];
    const cx = 300;
    const cy = 150;
    const rx = 120;
    const ry = 40;
    for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.15) {
      const noise = Math.sin(a * 5) * 1.5;
      points.push({ x: cx + (rx + noise) * Math.cos(a), y: cy + (ry + noise) * Math.sin(a), pressure: 0.5 });
    }

    const recognized = recognizeShape(points, '#f43f5e', 4);
    assert.ok(recognized !== null, 'Should recognize oval');
    assert.strictEqual(recognized.type, 'circle');
    assert.notStrictEqual(recognized.width, recognized.height, 'Oval should retain non-1:1 aspect ratio');
  });

  it('recognizes a rough hand-drawn rectangle', () => {
    const points: StrokePoint[] = [];
    // Draw 4 sides of rectangle (width 200, height 80)
    // Top
    for (let x = 100; x <= 300; x += 10) points.push({ x, y: 100 + Math.sin(x) * 1.2 });
    // Right
    for (let y = 100; y <= 180; y += 10) points.push({ x: 300 + Math.cos(y) * 1.2, y });
    // Bottom
    for (let x = 300; x >= 100; x -= 10) points.push({ x, y: 180 + Math.sin(x) * 1.2 });
    // Left
    for (let y = 180; y >= 100; y -= 10) points.push({ x: 100 + Math.cos(y) * 1.2, y });

    const recognized = recognizeShape(points, '#38bdf8', 3);
    assert.ok(recognized !== null, 'Should recognize rectangle');
    assert.strictEqual(recognized.type, 'rect');
    assert.ok(recognized.width > recognized.height * 1.8, 'Rectangle dimensions should reflect width > height');
  });

  it('recognizes a rough hand-drawn square', () => {
    const points: StrokePoint[] = [];
    // Draw 4 sides of square (100x100)
    for (let x = 100; x <= 200; x += 10) points.push({ x, y: 100 + Math.sin(x) });
    for (let y = 100; y <= 200; y += 10) points.push({ x: 200 + Math.cos(y), y });
    for (let x = 200; x >= 100; x -= 10) points.push({ x, y: 200 + Math.sin(x) });
    for (let y = 200; y >= 100; y -= 10) points.push({ x: 100 + Math.cos(y), y });

    const recognized = recognizeShape(points, '#f59e0b', 3);
    assert.ok(recognized !== null, 'Should recognize square');
    assert.strictEqual(recognized.type, 'rect');
    assert.strictEqual(recognized.width, recognized.height, 'Square should have equal width and height');
  });

  it('recognizes a rough hand-drawn triangle', () => {
    const points: StrokePoint[] = [];
    // Triangle vertices: (200, 100), (300, 260), (100, 260)
    // Side 1: Top to bottom-right
    for (let t = 0; t <= 1; t += 0.1) {
      points.push({ x: 200 + 100 * t + Math.sin(t * 10), y: 100 + 160 * t + Math.cos(t * 10) });
    }
    // Side 2: bottom-right to bottom-left
    for (let t = 0; t <= 1; t += 0.1) {
      points.push({ x: 300 - 200 * t + Math.sin(t * 10), y: 260 + Math.cos(t * 10) });
    }
    // Side 3: bottom-left back to top
    for (let t = 0; t <= 1; t += 0.1) {
      points.push({ x: 100 + 100 * t + Math.sin(t * 10), y: 260 - 160 * t + Math.cos(t * 10) });
    }

    const recognized = recognizeShape(points, '#ec4899', 3);
    assert.ok(recognized !== null, 'Should recognize triangle');
    assert.strictEqual(recognized.type, 'triangle');
  });

  it('recognizes an arrow stroke with a terminal arrowhead fold', () => {
    const points: StrokePoint[] = [];
    // Shaft from (100, 200) to (300, 200)
    for (let x = 100; x <= 300; x += 15) {
      points.push({ x, y: 200 + Math.sin(x) * 1.2 });
    }
    // Arrow barb fold back from (300, 200) to (270, 180)
    points.push({ x: 290, y: 190 });
    points.push({ x: 280, y: 185 });
    points.push({ x: 270, y: 180 });

    const recognized = recognizeShape(points, '#38bdf8', 3);
    assert.ok(recognized !== null, 'Should recognize arrow');
    assert.strictEqual(recognized.type, 'arrow');
    assert.ok(recognized.width > 150, 'Arrow width should reflect shaft');
  });

  it('preserves irregular squiggles / handwriting by returning null', () => {
    const points: StrokePoint[] = [];
    // Chaotic squiggle: high curvature, non-closed, non-straight
    for (let t = 0; t < 60; t++) {
      points.push({
        x: 100 + t * 4 + Math.sin(t * 0.8) * 45,
        y: 100 + Math.cos(t * 0.5) * 50,
      });
    }

    const recognized = recognizeShape(points, '#ffffff', 2);
    assert.strictEqual(recognized, null, 'Should not force recognize random squiggles');
  });
});
