/**
 * xvBOARD Canvas Data Types & Specifications
 */

export type ElementType =
  | 'pen'
  | 'pencil'
  | 'highlighter'
  | 'rect'
  | 'rounded-rect'
  | 'circle'
  | 'triangle'
  | 'diamond'
  | 'arrow'
  | 'line'
  | 'connector'
  | 'sticky'
  | 'text'
  | 'image';

export type ToolType =
  | 'select'
  | 'hand'
  | 'pen'
  | 'pencil'
  | 'highlighter'
  | 'eraser'
  | 'rect'
  | 'rounded-rect'
  | 'circle'
  | 'triangle'
  | 'diamond'
  | 'arrow'
  | 'line'
  | 'connector'
  | 'sticky'
  | 'text'
  | 'image';

export interface StrokePoint {
  x: number;
  y: number;
  pressure?: number;
  time?: number;
}

export interface CanvasElement {
  id: string;
  type: ElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation?: number; // In radians or degrees (0 default)
  zIndex: number;
  
  // Stroke & Fill
  strokeColor?: string;
  strokeWidth?: number;
  strokeDash?: number[];
  fillColor?: string;
  opacity?: number;

  // Freehand path points
  points?: StrokePoint[];

  // Text & Sticky
  text?: string;
  fontSize?: number;
  fontWeight?: 'normal' | 'bold';
  fontStyle?: 'normal' | 'italic';
  textAlign?: 'left' | 'center' | 'right';
  fontFamily?: 'sans' | 'handwritten' | 'mono';
  stickyColor?: string; // M3 sticky preset background

  // Connector
  startPoint?: { x: number; y: number };
  endPoint?: { x: number; y: number };
  startElementId?: string;
  endElementId?: string;
  connectorStyle?: 'straight' | 'curved' | 'orthogonal';

  // Image
  imageUrl?: string;
  originalWidth?: number;
  originalHeight?: number;

  // Metadata
  isLocked?: boolean;
}

export type CanvasBackgroundType = 'dots' | 'grid' | 'plain';

export interface Viewport {
  x: number;
  y: number;
  zoom: number; // 0.1 to 5.0
}

export interface Board {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  isFavorite: boolean;
  thumbnail?: string; // Data URL of thumbnail
  bgType: CanvasBackgroundType;
  bgColor: string; // Background color hex or theme token
  viewport: Viewport;
  elements: CanvasElement[];
}

export interface StylusSettings {
  palmRejectionSensitivity: 'high' | 'medium' | 'low' | 'off';
  penOnlyInking: boolean; // Only pen draws, finger always pans
  pressureSensitivity: boolean;
  showHoverCursor: boolean;
  minBrushWidthRatio: number;
  maxBrushWidthRatio: number;
}

export interface AppSettings {
  themeMode: 'preset' | 'manual' | 'auto';
  presetKey: string;
  customSeedHex: string;
  wallpaperData?: string;
  colorSchemePreference: 'system' | 'light' | 'dark';
  stylusSettings: StylusSettings;
  gridSnap: boolean;
  shapeRecognition: boolean;
}
