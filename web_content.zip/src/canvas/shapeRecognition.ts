/**
 * xvBOARD Shape Recognition Engine
 * Real-time geometric recognizer converting hand-drawn strokes into clean vector shapes:
 * - Straight lines & Snapped lines (horizontal, vertical, 45-degree diagonal)
 * - Directional arrows
 * - Circles (1:1 aspect ratio)
 * - Ovals / Ellipses
 * - Squares (1:1 aspect ratio)
 * - Rectangles
 * - Triangles
 *
 * Preserves original drawings when confidence score is below threshold.
 */

import { StrokePoint, CanvasElement } from './types';

export interface RecognitionResult {
  element: CanvasElement;
  confidence: number;
  detectedType: 'line' | 'arrow' | 'circle' | 'oval' | 'square' | 'rect' | 'triangle';
}

/**
 * Calculates Euclidean distance between two points
 */
function dist(p1: { x: number; y: number }, p2: { x: number; y: number }): number {
  return Math.hypot(p2.x - p1.x, p2.y - p1.y);
}

/**
 * Total cumulative path length of the stroke
 */
function calculatePathLength(points: StrokePoint[]): number {
  let len = 0;
  for (let i = 1; i < points.length; i++) {
    len += dist(points[i - 1], points[i]);
  }
  return len;
}

/**
 * Bounding box of points
 */
function getBounds(points: StrokePoint[]): { minX: number; maxX: number; minY: number; maxY: number; width: number; height: number } {
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;

  for (const p of points) {
    if (p.x < minX) minX = p.x;
    if (p.x > maxX) maxX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.y > maxY) maxY = p.y;
  }

  return {
    minX,
    maxX,
    minY,
    maxY,
    width: Math.max(1, maxX - minX),
    height: Math.max(1, maxY - minY),
  };
}

/**
 * Perpendicular distance of point P from line segment (A, B)
 */
function distToSegment(p: StrokePoint, a: StrokePoint, b: StrokePoint): number {
  const l2 = (b.x - a.x) ** 2 + (b.y - a.y) ** 2;
  if (l2 === 0) return dist(p, a);
  let t = ((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)) / l2;
  t = Math.max(0, Math.min(1, t));
  const projX = a.x + t * (b.x - a.x);
  const projY = a.y + t * (b.y - a.y);
  return Math.hypot(p.x - projX, p.y - projY);
}

/**
 * Polygon Area via Shoelace Formula
 */
function polygonArea(points: StrokePoint[]): number {
  let area = 0;
  const n = points.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    area += points[i].x * points[j].y;
    area -= points[j].x * points[i].y;
  }
  return Math.abs(area) / 2;
}

/**
 * Ramer-Douglas-Peucker (RDP) polygon simplification
 */
export function simplifyRDP(points: StrokePoint[], epsilon: number): StrokePoint[] {
  if (points.length <= 2) return points;

  let maxDist = 0;
  let index = 0;
  const start = points[0];
  const end = points[points.length - 1];

  for (let i = 1; i < points.length - 1; i++) {
    const d = distToSegment(points[i], start, end);
    if (d > maxDist) {
      maxDist = d;
      index = i;
    }
  }

  if (maxDist > epsilon) {
    const left = simplifyRDP(points.slice(0, index + 1), epsilon);
    const right = simplifyRDP(points.slice(index), epsilon);
    return left.slice(0, left.length - 1).concat(right);
  } else {
    return [start, end];
  }
}

/**
 * Tests if the stroke is an Arrow:
 * Usually drawn in a single stroke: shaft from start to tip, then a sharp fold (arrowhead barb)
 * or shaft followed by tip back-fold.
 */
function testArrow(points: StrokePoint[], totalLength: number, boundsDiag: number): { isArrow: boolean; confidence: number; start: StrokePoint; tip: StrokePoint } | null {
  if (points.length < 8 || totalLength < 25) return null;

  // Search for the apex (tip of the arrow) in the second half of the stroke
  // The apex is typically the furthest forward point or point of sharpest direction reversal
  let bestApexIdx = -1;
  let maxAngleChange = 0;

  const minIdx = Math.floor(points.length * 0.55);
  const maxIdx = Math.floor(points.length * 0.90);

  for (let i = minIdx; i <= maxIdx; i++) {
    const pPrev = points[Math.max(0, i - 4)];
    const pCurr = points[i];
    const pNext = points[Math.min(points.length - 1, i + 4)];

    const v1x = pCurr.x - pPrev.x;
    const v1y = pCurr.y - pPrev.y;
    const v2x = pNext.x - pCurr.x;
    const v2y = pNext.y - pCurr.y;

    const dot = v1x * v2x + v1y * v2y;
    const m1 = Math.hypot(v1x, v1y);
    const m2 = Math.hypot(v2x, v2y);

    if (m1 > 3 && m2 > 3) {
      const cosAngle = dot / (m1 * m2);
      // Sharp turn: cosAngle < -0.2 (angle > ~100 deg)
      if (cosAngle < -0.2) {
        const angleChange = Math.acos(Math.max(-1, Math.min(1, cosAngle)));
        if (angleChange > maxAngleChange) {
          maxAngleChange = angleChange;
          bestApexIdx = i;
        }
      }
    }
  }

  if (bestApexIdx !== -1) {
    const start = points[0];
    const tip = points[bestApexIdx];
    const shaftLength = dist(start, tip);

    // Shaft must be reasonably straight
    let maxShaftDev = 0;
    for (let i = 0; i <= bestApexIdx; i++) {
      const d = distToSegment(points[i], start, tip);
      if (d > maxShaftDev) maxShaftDev = d;
    }

    if (shaftLength > 20 && maxShaftDev / shaftLength < 0.20) {
      const confidence = Math.min(0.95, 0.70 + (maxAngleChange / Math.PI) * 0.2 - (maxShaftDev / shaftLength) * 0.3);
      return { isArrow: true, confidence, start, tip };
    }
  }

  return null;
}

/**
 * Main recognition function
 * Converts rough hand-drawn strokes into clean vector shapes.
 * Returns null if confidence is below 0.72 so original freehand stroke is preserved.
 */
export function recognizeShape(
  points: StrokePoint[],
  strokeColor: string = '#38bdf8',
  strokeWidth: number = 3,
  opacity: number = 1
): CanvasElement | null {
  if (!points || points.length < 5) return null;

  const totalLength = calculatePathLength(points);
  const bounds = getBounds(points);
  const boundsDiag = Math.hypot(bounds.width, bounds.height);

  // Ignore tiny gestures/clicks
  if (totalLength < 16 || boundsDiag < 12) return null;

  const startPt = points[0];
  const endPt = points[points.length - 1];
  const startEndDist = dist(startPt, endPt);
  const closureRatio = startEndDist / totalLength;
  const closureDiagRatio = startEndDist / boundsDiag;

  // =========================================================================
  // 1. OPEN STROKE DETECTION: Straight Lines & Arrows
  // =========================================================================
  if (closureRatio > 0.40 || closureDiagRatio > 0.35) {
    // Check for Arrow first
    const arrowCheck = testArrow(points, totalLength, boundsDiag);
    if (arrowCheck && arrowCheck.confidence >= 0.72) {
      let dx = arrowCheck.tip.x - arrowCheck.start.x;
      let dy = arrowCheck.tip.y - arrowCheck.start.y;
      const angle = (Math.atan2(dy, dx) * 180) / Math.PI;

      // Snap close angles to 0, 90, 180, -90
      if (Math.abs(angle) < 6 || Math.abs(Math.abs(angle) - 180) < 6) {
        dy = 0;
      } else if (Math.abs(Math.abs(angle) - 90) < 6) {
        dx = 0;
      }

      return {
        id: `shape-arrow-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        type: 'arrow',
        x: arrowCheck.start.x,
        y: arrowCheck.start.y,
        width: dx,
        height: dy,
        zIndex: 1,
        strokeColor,
        strokeWidth,
        opacity,
      };
    }

    // Straight Line Test
    let maxDev = 0;
    let sumDev = 0;
    for (let i = 1; i < points.length - 1; i++) {
      const d = distToSegment(points[i], startPt, endPt);
      if (d > maxDev) maxDev = d;
      sumDev += d;
    }
    const avgDev = sumDev / (points.length - 2);
    const lineRatio = startEndDist / totalLength;
    const maxDevRatio = maxDev / startEndDist;

    if (lineRatio >= 0.86 && maxDevRatio <= 0.16) {
      let x1 = startPt.x;
      let y1 = startPt.y;
      let x2 = endPt.x;
      let y2 = endPt.y;

      let dx = x2 - x1;
      let dy = y2 - y1;
      const angleRad = Math.atan2(dy, dx);
      let angleDeg = (angleRad * 180) / Math.PI;
      if (angleDeg < 0) angleDeg += 360;

      // Snapping to horizontal (0, 180, 360) within 7 degrees
      if (angleDeg < 7 || angleDeg > 353 || Math.abs(angleDeg - 180) < 7) {
        y2 = y1;
        dy = 0;
      }
      // Snapping to vertical (90, 270) within 7 degrees
      else if (Math.abs(angleDeg - 90) < 7 || Math.abs(angleDeg - 270) < 7) {
        x2 = x1;
        dx = 0;
      }
      // Snapping to 45 degree diagonal (45, 135, 225, 315) within 6 degrees
      else if (
        Math.abs(angleDeg - 45) < 6 ||
        Math.abs(angleDeg - 135) < 6 ||
        Math.abs(angleDeg - 225) < 6 ||
        Math.abs(angleDeg - 315) < 6
      ) {
        const signX = dx >= 0 ? 1 : -1;
        const signY = dy >= 0 ? 1 : -1;
        const avgSpan = (Math.abs(dx) + Math.abs(dy)) / 2;
        dx = signX * avgSpan;
        dy = signY * avgSpan;
      }

      return {
        id: `shape-line-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        type: 'line',
        x: x1,
        y: y1,
        width: dx,
        height: dy,
        zIndex: 1,
        strokeColor,
        strokeWidth,
        opacity,
      };
    }
  }

  // =========================================================================
  // 2. CLOSED STROKE DETECTION: Circle, Oval, Square, Rect, Triangle
  // =========================================================================
  if (closureRatio <= 0.32 || closureDiagRatio <= 0.28) {
    const centerX = bounds.minX + bounds.width / 2;
    const centerY = bounds.minY + bounds.height / 2;
    const rx = bounds.width / 2;
    const ry = bounds.height / 2;

    const bboxArea = bounds.width * bounds.height;
    const polyArea = polygonArea(points);
    const areaRatio = polyArea / bboxArea; // Triangle ~0.45-0.55, Ellipse ~0.785, Rect ~0.85-1.0

    // Normalized Radial Variance (for Ellipse / Circle)
    let sumNormR = 0;
    let sumNormR2 = 0;
    for (const p of points) {
      const normR = Math.hypot((p.x - centerX) / rx, (p.y - centerY) / ry);
      sumNormR += normR;
      sumNormR2 += normR * normR;
    }
    const meanNormR = sumNormR / points.length;
    const varNormR = Math.max(0, sumNormR2 / points.length - meanNormR * meanNormR);
    const stdNormR = Math.sqrt(varNormR);

    // Polygon simplification to inspect corner vertices
    const simplified = simplifyRDP(points, boundsDiag * 0.05);
    // Number of vertices excluding duplicate closure endpoint
    const vertexCount = dist(simplified[0], simplified[simplified.length - 1]) < boundsDiag * 0.15
      ? simplified.length - 1
      : simplified.length;

    // A. Circle / Oval check
    // Low radial deviation around normalized center and area close to pi/4 (~0.785)
    if (stdNormR < 0.22 && areaRatio >= 0.62 && areaRatio <= 0.94) {
      const aspectRatio = bounds.width / bounds.height;

      // Circle if aspect ratio is roughly 1:1 (between 0.82 and 1.22)
      if (aspectRatio >= 0.82 && aspectRatio <= 1.22) {
        const size = (bounds.width + bounds.height) / 2;
        return {
          id: `shape-circle-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          type: 'circle',
          x: centerX - size / 2,
          y: centerY - size / 2,
          width: size,
          height: size,
          zIndex: 1,
          strokeColor,
          strokeWidth,
          fillColor: 'transparent',
          opacity,
        };
      } else {
        // Oval / Ellipse
        return {
          id: `shape-oval-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          type: 'circle', // Canvas renders circle as ellipse when width != height
          x: bounds.minX,
          y: bounds.minY,
          width: bounds.width,
          height: bounds.height,
          zIndex: 1,
          strokeColor,
          strokeWidth,
          fillColor: 'transparent',
          opacity,
        };
      }
    }

    // B. Triangle check
    // 3 prominent vertices, areaRatio around 0.35 to 0.65
    if (vertexCount === 3 || (vertexCount <= 4 && areaRatio >= 0.32 && areaRatio <= 0.65 && stdNormR > 0.18)) {
      return {
        id: `shape-triangle-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        type: 'triangle',
        x: bounds.minX,
        y: bounds.minY,
        width: bounds.width,
        height: bounds.height,
        zIndex: 1,
        strokeColor,
        strokeWidth,
        fillColor: 'transparent',
        opacity,
      };
    }

    // C. Rectangle / Square check
    // High bounding box fill factor (areaRatio >= 0.72) and not a smooth circle
    if (areaRatio >= 0.72) {
      const aspectRatio = bounds.width / bounds.height;

      // Square check: aspect ratio close to 1:1 (0.84 to 1.19)
      if (aspectRatio >= 0.84 && aspectRatio <= 1.19) {
        const size = (bounds.width + bounds.height) / 2;
        return {
          id: `shape-square-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          type: 'rect',
          x: centerX - size / 2,
          y: centerY - size / 2,
          width: size,
          height: size,
          zIndex: 1,
          strokeColor,
          strokeWidth,
          fillColor: 'transparent',
          opacity,
        };
      } else {
        // Rectangle
        return {
          id: `shape-rect-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          type: 'rect',
          x: bounds.minX,
          y: bounds.minY,
          width: bounds.width,
          height: bounds.height,
          zIndex: 1,
          strokeColor,
          strokeWidth,
          fillColor: 'transparent',
          opacity,
        };
      }
    }
  }

  // Not recognized with sufficient confidence — keep raw stroke unchanged
  return null;
}
