/**
 * xvBOARD Export & Backup Engine
 * High-resolution PNG rendering, JSON backups, and export utilities.
 */

import { Board, CanvasElement } from './types';
import { getSelectionBounds, getElementBounds } from './geometry';

/**
 * Renders board elements onto an offscreen canvas and triggers a PNG download
 */
export async function exportBoardToPNG(
  board: Board,
  options: {
    selectedOnly?: boolean;
    selectedIds?: string[];
    transparentBg?: boolean;
    scale?: number;
    filename?: string;
  } = {}
): Promise<string> {
  const {
    selectedOnly = false,
    selectedIds = [],
    transparentBg = false,
    scale = 2, // 2x DPI for ultra-crisp output
    filename = `${board.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_export.png`,
  } = options;

  let elementsToRender = board.elements;
  if (selectedOnly && selectedIds.length > 0) {
    elementsToRender = board.elements.filter(el => selectedIds.includes(el.id));
  }

  if (elementsToRender.length === 0) {
    throw new Error('No elements to export');
  }

  const bounds = getSelectionBounds(elementsToRender);
  if (!bounds) throw new Error('Invalid elements bounds');

  // Add 40px comfortable margin around export
  const padding = 40;
  const contentWidth = bounds.width + padding * 2;
  const contentHeight = bounds.height + padding * 2;

  const canvas = document.createElement('canvas');
  canvas.width = Math.round(contentWidth * scale);
  canvas.height = Math.round(contentHeight * scale);

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');

  ctx.scale(scale, scale);

  // Background
  if (!transparentBg) {
    ctx.fillStyle = board.bgColor || '#121418';
    ctx.fillRect(0, 0, contentWidth, contentHeight);
  }

  // Translate so bounds.minX - padding maps to (0,0)
  ctx.translate(-bounds.minX + padding, -bounds.minY + padding);

  // Render elements in z-order
  const sorted = [...elementsToRender].sort((a, b) => a.zIndex - b.zIndex);
  for (const el of sorted) {
    renderElementToContext(ctx, el);
  }

  const dataUrl = canvas.toDataURL('image/png');

  // Trigger download
  const link = document.createElement('a');
  link.download = filename;
  link.href = dataUrl;
  link.click();

  return dataUrl;
}

/**
 * Generate quick small thumbnail DataURL for board cards
 */
export function generateThumbnailDataUrl(board: Board): string {
  if (typeof document === 'undefined') return '';
  if (board.elements.length === 0) return '';

  try {
    const bounds = getSelectionBounds(board.elements);
    if (!bounds || bounds.width <= 0 || bounds.height <= 0) return '';

    const width = 320;
    const height = 180;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    // Background
    ctx.fillStyle = board.bgColor || '#121418';
    ctx.fillRect(0, 0, width, height);

    // Fit content inside thumbnail
    const scaleX = (width - 32) / bounds.width;
    const scaleY = (height - 32) / bounds.height;
    const fitScale = Math.min(scaleX, scaleY, 0.4);

    const offsetX = (width - bounds.width * fitScale) / 2 - bounds.minX * fitScale;
    const offsetY = (height - bounds.height * fitScale) / 2 - bounds.minY * fitScale;

    ctx.translate(offsetX, offsetY);
    ctx.scale(fitScale, fitScale);

    for (const el of board.elements) {
      renderElementToContext(ctx, el);
    }

    return canvas.toDataURL('image/jpeg', 0.7);
  } catch (e) {
    console.warn('Thumbnail generation skipped:', e);
    return '';
  }
}

/**
 * Helper to render an element onto a 2D canvas context
 */
export function renderElementToContext(ctx: CanvasRenderingContext2D, el: CanvasElement): void {
  ctx.save();

  if (el.opacity !== undefined) {
    ctx.globalAlpha = el.opacity;
  }

  if (el.rotation) {
    const cx = el.x + el.width / 2;
    const cy = el.y + el.height / 2;
    ctx.translate(cx, cy);
    ctx.rotate((el.rotation * Math.PI) / 180);
    ctx.translate(-cx, -cy);
  }

  // 1. Sticky Note
  if (el.type === 'sticky') {
    ctx.fillStyle = el.stickyColor || '#fef08a';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 4;

    const r = 12;
    ctx.beginPath();
    ctx.roundRect(el.x, el.y, el.width, el.height, r);
    ctx.fill();

    ctx.shadowColor = 'transparent';
    ctx.lineWidth = 1;
    ctx.strokeStyle = el.strokeColor || 'rgba(0,0,0,0.1)';
    ctx.stroke();

    // Render text inside sticky note
    if (el.text) {
      ctx.fillStyle = '#1e293b';
      ctx.font = `${el.fontSize || 15}px "Caveat", "Google Sans", cursive, sans-serif`;
      wrapText(ctx, el.text, el.x + 14, el.y + 26, el.width - 28, (el.fontSize || 15) * 1.35);
    }
    ctx.restore();
    return;
  }

  // 2. Freehand strokes (Pen, Pencil, Highlighter)
  if (el.type === 'pen' || el.type === 'pencil' || el.type === 'highlighter') {
    if (!el.points || el.points.length === 0) {
      ctx.restore();
      return;
    }

    if (el.type === 'highlighter') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = el.opacity || 0.45;
      ctx.strokeStyle = el.strokeColor || '#fde047';
      ctx.lineWidth = el.strokeWidth || 24;
      ctx.lineCap = 'square';
      ctx.lineJoin = 'bevel';
    } else {
      ctx.strokeStyle = el.strokeColor || '#38bdf8';
      ctx.lineWidth = el.strokeWidth || (el.type === 'pencil' ? 2 : 4);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }

    ctx.beginPath();
    const pts = el.points;
    ctx.moveTo(pts[0].x, pts[0].y);

    for (let i = 1; i < pts.length; i++) {
      const midX = (pts[i - 1].x + pts[i].x) / 2;
      const midY = (pts[i - 1].y + pts[i].y) / 2;
      ctx.quadraticCurveTo(pts[i - 1].x, pts[i - 1].y, midX, midY);
    }
    ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
    ctx.stroke();
    ctx.restore();
    return;
  }

  // 3. Text box
  if (el.type === 'text') {
    ctx.fillStyle = el.strokeColor || '#ffffff';
    const weight = el.fontWeight || 'normal';
    const style = el.fontStyle || 'normal';
    const size = el.fontSize || 18;
    ctx.font = `${style} ${weight} ${size}px "Google Sans", "Roboto", sans-serif`;
    ctx.textBaseline = 'top';
    wrapText(ctx, el.text || '', el.x, el.y, el.width, size * 1.35);
    ctx.restore();
    return;
  }

  // 4. Shapes & Lines
  ctx.strokeStyle = el.strokeColor || '#38bdf8';
  ctx.lineWidth = el.strokeWidth || 3;
  ctx.fillStyle = el.fillColor || 'transparent';

  if (el.type === 'rect') {
    ctx.beginPath();
    ctx.rect(el.x, el.y, el.width, el.height);
    if (el.fillColor && el.fillColor !== 'transparent') ctx.fill();
    ctx.stroke();
  } else if (el.type === 'rounded-rect') {
    ctx.beginPath();
    ctx.roundRect(el.x, el.y, el.width, el.height, 16);
    if (el.fillColor && el.fillColor !== 'transparent') ctx.fill();
    ctx.stroke();
    if (el.text) {
      ctx.fillStyle = el.strokeColor || '#ffffff';
      ctx.font = `bold ${el.fontSize || 15}px "Google Sans", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const lines = el.text.split('\n');
      const startY = el.y + el.height / 2 - ((lines.length - 1) * 20) / 2;
      lines.forEach((l, idx) => {
        ctx.fillText(l, el.x + el.width / 2, startY + idx * 20);
      });
    }
  } else if (el.type === 'circle') {
    ctx.beginPath();
    const rx = Math.abs(el.width / 2);
    const ry = Math.abs(el.height / 2);
    ctx.ellipse(el.x + rx, el.y + ry, rx, ry, 0, 0, Math.PI * 2);
    if (el.fillColor && el.fillColor !== 'transparent') ctx.fill();
    ctx.stroke();
  } else if (el.type === 'triangle') {
    ctx.beginPath();
    ctx.moveTo(el.x + el.width / 2, el.y);
    ctx.lineTo(el.x + el.width, el.y + el.height);
    ctx.lineTo(el.x, el.y + el.height);
    ctx.closePath();
    if (el.fillColor && el.fillColor !== 'transparent') ctx.fill();
    ctx.stroke();
  } else if (el.type === 'diamond') {
    ctx.beginPath();
    ctx.moveTo(el.x + el.width / 2, el.y);
    ctx.lineTo(el.x + el.width, el.y + el.height / 2);
    ctx.lineTo(el.x + el.width / 2, el.y + el.height);
    ctx.lineTo(el.x, el.y + el.height / 2);
    ctx.closePath();
    if (el.fillColor && el.fillColor !== 'transparent') ctx.fill();
    ctx.stroke();
  } else if (el.type === 'line') {
    ctx.beginPath();
    ctx.moveTo(el.x, el.y);
    ctx.lineTo(el.x + el.width, el.y + el.height);
    ctx.stroke();
  } else if (el.type === 'arrow') {
    const x1 = el.x;
    const y1 = el.y;
    const x2 = el.x + el.width;
    const y2 = el.y + el.height;
    drawArrow(ctx, x1, y1, x2, y2, el.strokeWidth || 3);
  } else if (el.type === 'connector') {
    const p1 = el.startPoint || { x: el.x, y: el.y };
    const p2 = el.endPoint || { x: el.x + el.width, y: el.y + el.height };
    drawArrow(ctx, p1.x, p1.y, p2.x, p2.y, el.strokeWidth || 3);
  }

  ctx.restore();
}

function drawArrow(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, strokeWidth: number): void {
  const headLength = Math.max(14, strokeWidth * 3.5);
  const angle = Math.atan2(y2 - y1, x2 - x1);

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - headLength * Math.cos(angle - Math.PI / 6), y2 - headLength * Math.sin(angle - Math.PI / 6));
  ctx.lineTo(x2 - headLength * Math.cos(angle + Math.PI / 6), y2 - headLength * Math.sin(angle + Math.PI / 6));
  ctx.closePath();
  ctx.fillStyle = ctx.strokeStyle;
  ctx.fill();
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number
): void {
  const paragraphs = text.split('\n');
  let currentY = y;

  for (const para of paragraphs) {
    const words = para.split(' ');
    let line = '';

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line, x, currentY);
        line = words[n] + ' ';
        currentY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, currentY);
    currentY += lineHeight;
  }
}

/**
 * Single board JSON export
 */
export function exportBoardToJSON(board: Board): void {
  const json = JSON.stringify(board, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.download = `${board.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.xvboard`;
  a.href = url;
  a.click();
  URL.revokeObjectURL(url);
}
