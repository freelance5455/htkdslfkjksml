/**
 * xvBOARD Canvas Geometry & Mathematics Engine
 * Pure mathematical functions decoupled from UI rendering.
 */

import { CanvasElement, StrokePoint, Viewport } from './types';

export interface BoundingBox {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  width: number;
  height: number;
}

export interface TransformHandle {
  id: 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'rotate';
  x: number;
  y: number;
  cursor: string;
}

/**
 * Converts screen coordinates (CSS pixels relative to canvas) to world coordinates
 */
export function screenToWorld(screenX: number, screenY: number, viewport: Viewport): { x: number; y: number } {
  return {
    x: (screenX - viewport.x) / viewport.zoom,
    y: (screenY - viewport.y) / viewport.zoom,
  };
}

/**
 * Converts world coordinates to screen coordinates
 */
export function worldToScreen(worldX: number, worldY: number, viewport: Viewport): { x: number; y: number } {
  return {
    x: worldX * viewport.zoom + viewport.x,
    y: worldY * viewport.zoom + viewport.y,
  };
}

/**
 * Computes bounding box for any canvas element
 */
export function getElementBounds(element: CanvasElement): BoundingBox {
  if (element.type === 'pen' || element.type === 'pencil' || element.type === 'highlighter') {
    if (!element.points || element.points.length === 0) {
      return {
        minX: element.x,
        minY: element.y,
        maxX: element.x + element.width,
        maxY: element.y + element.height,
        width: element.width,
        height: element.height,
      };
    }

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    for (const p of element.points) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }

    const padding = (element.strokeWidth || 4) / 2 + 4;
    minX -= padding;
    minY -= padding;
    maxX += padding;
    maxY += padding;

    return {
      minX,
      minY,
      maxX,
      maxY,
      width: Math.max(1, maxX - minX),
      height: Math.max(1, maxY - minY),
    };
  }

  if (element.type === 'connector') {
    const p1 = element.startPoint || { x: element.x, y: element.y };
    const p2 = element.endPoint || { x: element.x + element.width, y: element.y + element.height };
    const minX = Math.min(p1.x, p2.x) - 10;
    const minY = Math.min(p1.y, p2.y) - 10;
    const maxX = Math.max(p1.x, p2.x) + 10;
    const maxY = Math.max(p1.y, p2.y) + 10;
    return {
      minX,
      minY,
      maxX,
      maxY,
      width: maxX - minX,
      height: maxY - minY,
    };
  }

  return {
    minX: element.x,
    minY: element.y,
    maxX: element.x + element.width,
    maxY: element.y + element.height,
    width: element.width,
    height: element.height,
  };
}

/**
 * Computes bounding box containing a group of elements
 */
export function getSelectionBounds(elements: CanvasElement[]): BoundingBox | null {
  if (elements.length === 0) return null;

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const el of elements) {
    const b = getElementBounds(el);
    if (b.minX < minX) minX = b.minX;
    if (b.minY < minY) minY = b.minY;
    if (b.maxX > maxX) maxX = b.maxX;
    if (b.maxY > maxY) maxY = b.maxY;
  }

  return {
    minX,
    minY,
    maxX,
    maxY,
    width: maxX - minX,
    height: maxY - minY,
  };
}

/**
 * Returns transform handles for a bounding box
 */
export function getTransformHandles(box: BoundingBox, handleSize = 10): TransformHandle[] {
  const { minX, minY, maxX, maxY } = box;
  const midX = (minX + maxX) / 2;
  const midY = (minY + maxY) / 2;
  const rotateDistance = 28;

  return [
    { id: 'nw', x: minX, y: minY, cursor: 'nwse-resize' },
    { id: 'n', x: midX, y: minY, cursor: 'ns-resize' },
    { id: 'ne', x: maxX, y: minY, cursor: 'nesw-resize' },
    { id: 'e', x: maxX, y: midY, cursor: 'ew-resize' },
    { id: 'se', x: maxX, y: maxY, cursor: 'nwse-resize' },
    { id: 's', x: midX, y: maxY, cursor: 'ns-resize' },
    { id: 'sw', x: minX, y: maxY, cursor: 'nesw-resize' },
    { id: 'w', x: minX, y: midY, cursor: 'ew-resize' },
    { id: 'rotate', x: midX, y: minY - rotateDistance, cursor: 'grab' },
  ];
}

/**
 * Hit test: Checks if world point (px, py) is inside element
 */
export function hitTestElement(px: number, py: number, element: CanvasElement, tolerance = 8): boolean {
  const box = getElementBounds(element);

  // Quick bounding box check
  if (
    px < box.minX - tolerance ||
    px > box.maxX + tolerance ||
    py < box.minY - tolerance ||
    py > box.maxY + tolerance
  ) {
    return false;
  }

  // Precision check for freehand strokes
  if (element.type === 'pen' || element.type === 'pencil' || element.type === 'highlighter') {
    if (!element.points || element.points.length < 2) return true;
    const hitRadius = (element.strokeWidth || 4) / 2 + tolerance;
    for (let i = 0; i < element.points.length - 1; i++) {
      const p1 = element.points[i];
      const p2 = element.points[i + 1];
      if (pointToSegmentDistance(px, py, p1.x, p1.y, p2.x, p2.y) <= hitRadius) {
        return true;
      }
    }
    return false;
  }

  // Precision check for circles
  if (element.type === 'circle') {
    const rx = element.width / 2;
    const ry = element.height / 2;
    const cx = element.x + rx;
    const cy = element.y + ry;
    if (rx <= 0 || ry <= 0) return false;
    const normalizedX = (px - cx) / rx;
    const normalizedY = (py - cy) / ry;
    return normalizedX * normalizedX + normalizedY * normalizedY <= 1;
  }

  // Precision check for straight line
  if (element.type === 'line' || element.type === 'arrow') {
    return pointToSegmentDistance(px, py, element.x, element.y, element.x + element.width, element.y + element.height) <= tolerance + (element.strokeWidth || 2);
  }

  return true;
}

/**
 * Distance from point (px, py) to line segment (x1, y1) -> (x2, y2)
 */
export function pointToSegmentDistance(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const l2 = dx * dx + dy * dy;
  if (l2 === 0) return Math.hypot(px - x1, py - y1);

  let t = ((px - x1) * dx + (py - y1) * dy) / l2;
  t = Math.max(0, Math.min(1, t));

  const projX = x1 + t * dx;
  const projY = y1 + t * dy;
  return Math.hypot(px - projX, py - projY);
}

/**
 * Checks if element intersects with a marquee rectangular area
 */
export function elementIntersectsRect(
  element: CanvasElement,
  rectX: number,
  rectY: number,
  rectW: number,
  rectH: number
): boolean {
  const rMinX = Math.min(rectX, rectX + rectW);
  const rMaxX = Math.max(rectX, rectX + rectW);
  const rMinY = Math.min(rectY, rectY + rectH);
  const rMaxY = Math.max(rectY, rectY + rectH);

  const b = getElementBounds(element);

  return !(b.maxX < rMinX || b.minX > rMaxX || b.maxY < rMinY || b.minY > rMaxY);
}

/**
 * Applies handle drag to resize a bounding box
 */
export function calculateResizedBox(
  initialBox: BoundingBox,
  handleId: TransformHandle['id'],
  dx: number,
  dy: number,
  lockAspectRatio = false
): BoundingBox {
  let { minX, minY, maxX, maxY } = initialBox;
  const initialWidth = initialBox.width;
  const initialHeight = initialBox.height;

  switch (handleId) {
    case 'nw':
      minX += dx;
      minY += dy;
      break;
    case 'n':
      minY += dy;
      break;
    case 'ne':
      maxX += dx;
      minY += dy;
      break;
    case 'e':
      maxX += dx;
      break;
    case 'se':
      maxX += dx;
      maxY += dy;
      break;
    case 's':
      maxY += dy;
      break;
    case 'sw':
      minX += dx;
      maxY += dy;
      break;
    case 'w':
      minX += dx;
      break;
  }

  // Prevent inverting / collapsing below minimum 10px
  if (maxX - minX < 10) {
    if (handleId.includes('w')) minX = maxX - 10;
    else maxX = minX + 10;
  }
  if (maxY - minY < 10) {
    if (handleId.includes('n')) minY = maxY - 10;
    else maxY = minY + 10;
  }

  let width = maxX - minX;
  let height = maxY - minY;

  if (lockAspectRatio && initialWidth > 0 && initialHeight > 0) {
    const ratio = initialWidth / initialHeight;
    if (width / height > ratio) {
      width = height * ratio;
    } else {
      height = width / ratio;
    }
  }

  return {
    minX,
    minY,
    maxX: minX + width,
    maxY: minY + height,
    width,
    height,
  };
}

/**
 * Computes pressure-interpolated width for stylus drawing
 */
export function calculatePressureWidth(
  baseStrokeWidth: number,
  pressure = 0.5,
  pressureEnabled = true
): number {
  if (!pressureEnabled || pressure === undefined || pressure <= 0) {
    return baseStrokeWidth;
  }
  // Clamp pressure between 0.05 and 1.0
  const p = Math.max(0.05, Math.min(1.0, pressure));
  // Dynamic scaling: at light pressure 35% of base, at full pressure 165% of base
  return baseStrokeWidth * (0.35 + 1.3 * p);
}
