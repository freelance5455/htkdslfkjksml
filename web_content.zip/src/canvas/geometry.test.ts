import test from 'node:test';
import assert from 'node:assert/strict';
import {
  screenToWorld,
  worldToScreen,
  getElementBounds,
  getSelectionBounds,
  hitTestElement,
  elementIntersectsRect,
  calculateResizedBox,
  calculatePressureWidth,
} from './geometry';
import { CanvasElement } from './types';

test('screenToWorld and worldToScreen invert each other correctly', () => {
  const viewport = { x: 100, y: 50, zoom: 1.5 };
  const worldPoint = { x: 250, y: 180 };

  const screenPoint = worldToScreen(worldPoint.x, worldPoint.y, viewport);
  assert.equal(screenPoint.x, 250 * 1.5 + 100);
  assert.equal(screenPoint.y, 180 * 1.5 + 50);

  const convertedBack = screenToWorld(screenPoint.x, screenPoint.y, viewport);
  assert.ok(Math.abs(convertedBack.x - worldPoint.x) < 0.001);
  assert.ok(Math.abs(convertedBack.y - worldPoint.y) < 0.001);
});

test('getElementBounds returns accurate bounds for standard shapes', () => {
  const rect: CanvasElement = {
    id: 'rect-1',
    type: 'rect',
    x: 10,
    y: 20,
    width: 100,
    height: 80,
    zIndex: 1,
  };
  const bounds = getElementBounds(rect);
  assert.equal(bounds.minX, 10);
  assert.equal(bounds.minY, 20);
  assert.equal(bounds.maxX, 110);
  assert.equal(bounds.maxY, 100);
  assert.equal(bounds.width, 100);
  assert.equal(bounds.height, 80);
});

test('getElementBounds handles freehand stroke point clouds with padding', () => {
  const penStroke: CanvasElement = {
    id: 'pen-1',
    type: 'pen',
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    zIndex: 1,
    strokeWidth: 6,
    points: [
      { x: 10, y: 15 },
      { x: 60, y: 80 },
      { x: 120, y: 40 },
    ],
  };
  const bounds = getElementBounds(penStroke);
  // strokeWidth=6, padding = 6/2 + 4 = 7
  assert.equal(bounds.minX, 10 - 7);
  assert.equal(bounds.maxX, 120 + 7);
  assert.equal(bounds.minY, 15 - 7);
  assert.equal(bounds.maxY, 80 + 7);
});

test('getSelectionBounds wraps multiple elements into one bounding box', () => {
  const el1: CanvasElement = {
    id: '1',
    type: 'rect',
    x: 10,
    y: 10,
    width: 50,
    height: 50,
    zIndex: 1,
  };
  const el2: CanvasElement = {
    id: '2',
    type: 'rect',
    x: 100,
    y: 80,
    width: 60,
    height: 40,
    zIndex: 2,
  };
  const bounds = getSelectionBounds([el1, el2]);
  assert.ok(bounds !== null);
  assert.equal(bounds.minX, 10);
  assert.equal(bounds.minY, 10);
  assert.equal(bounds.maxX, 160);
  assert.equal(bounds.maxY, 120);
});

test('hitTestElement accurately detects point hits inside rectangle and circle', () => {
  const rect: CanvasElement = {
    id: 'r',
    type: 'rect',
    x: 50,
    y: 50,
    width: 100,
    height: 100,
    zIndex: 1,
  };
  assert.equal(hitTestElement(70, 70, rect), true);
  assert.equal(hitTestElement(180, 70, rect), false);

  const circle: CanvasElement = {
    id: 'c',
    type: 'circle',
    x: 100,
    y: 100,
    width: 100,
    height: 100,
    zIndex: 1,
  };
  // Center is (150, 150), radius is 50
  assert.equal(hitTestElement(150, 150, circle), true);
  // Corner of square (105, 105) is outside circle radius
  assert.equal(hitTestElement(105, 105, circle), false);
});

test('elementIntersectsRect handles marquee intersection', () => {
  const rect: CanvasElement = {
    id: 'r1',
    type: 'rect',
    x: 100,
    y: 100,
    width: 50,
    height: 50,
    zIndex: 1,
  };
  // Overlapping marquee
  assert.equal(elementIntersectsRect(rect, 80, 80, 60, 60), true);
  // Distant marquee
  assert.equal(elementIntersectsRect(rect, 200, 200, 50, 50), false);
});

test('calculatePressureWidth scales dynamically with stylus pressure', () => {
  const base = 10;
  // Pressure off returns base
  assert.equal(calculatePressureWidth(base, 0.8, false), 10);
  // Light pressure
  const light = calculatePressureWidth(base, 0.1, true);
  // High pressure
  const heavy = calculatePressureWidth(base, 1.0, true);
  assert.ok(light < base);
  assert.ok(heavy > base);
  assert.equal(Math.round(heavy), 17); // 10 * (0.35 + 1.3) = 16.5 -> 17
});
