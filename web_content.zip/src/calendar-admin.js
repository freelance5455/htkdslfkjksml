import {
  setOfficialLunarThursdays,
  setOfficialRegularSeasonEndDate,
  setOfficialIntergalacticDate,
  getCalendarReadiness
} from './competition-calendar.js';

/** Applique la configuration officielle sur une copie, puis ne retourne que si tout est valide. */
export function applyOfficialCalendarConfiguration(state, configuration) {
  if (!configuration || !Array.isArray(configuration.lunarThursdays) || configuration.lunarThursdays.length !== 7) {
    throw new Error('Sept jeudis lunaires officiels sont nécessaires pour les sept tours de la Coupe des Clubs.');
  }
  const candidate = structuredClone(state);
  setOfficialLunarThursdays(candidate, configuration.lunarThursdays);
  setOfficialRegularSeasonEndDate(candidate, {
    ...configuration.fgdRegularSeasonEnd,
    phase: 'end-of-regular-season',
    source: 'FGD'
  });
  setOfficialIntergalacticDate(candidate, 'intergalactique', {
    ...configuration.agdGalaxiesDate,
    phase: 'after-regular-season',
    source: 'AGD'
  });
  setOfficialIntergalacticDate(candidate, 'intergalactique-clubs', {
    ...configuration.agdClubsDate,
    phase: 'after-regular-season',
    source: 'AGD'
  });
  if (candidate.calendar.scheduleValidation?.valid === false) {
    throw new Error('Les dates officielles créent un chevauchement ou ne respectent pas le jour complet de repos.');
  }
  return { state: candidate, readiness: getCalendarReadiness(candidate) };
}
