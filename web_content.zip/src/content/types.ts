export type Ayah = {
  g: number;
  n: number;
  t: string;
  j: number;
  p: number;
  sajda: boolean;
};

export type Surah = {
  id: number;
  name: string;
  shortName: string;
  englishName: string;
  type: string;
  ayahs: Ayah[];
};

export type SurahMeta = {
  id: number;
  name: string;
  shortName: string;
  englishName: string;
  type: string;
  count: number;
  page: number;
  juz: number;
};

export type DhikrItem = {
  id: string;
  listId: string;
  title: string;
  text: string;
  count: number;
  source: string;
  book: string;
  surahId?: number;
  ayah?: number;
};

export type DhikrList = {
  id: string;
  title: string;
  kind: "adhkar" | "dua";
  blurb: string;
  source: string;
  items: DhikrItem[];
};

export type LibrarySection = {
  id: string;
  number?: number;
  title: string;
  body: string;
};

export type LibraryBook = {
  id: string;
  title: string;
  author: string;
  category: "hadith" | "aqeedah" | "fiqh" | "tajweed";
  source: string;
  blurb: string;
  comingSoon?: boolean;
  sections: LibrarySection[];
};
