export type Lang = { en: string; am: string };

export type Question = {
  id: string;
  prompt: Lang;
  choices: Lang[];
  answer: number;
  explain: Lang;
};

export type Chapter = {
  id: string;
  grades: number[];
  title: Lang;
  summary: Lang;
  paragraphs: Lang[];
  questions: Question[];
};

export type SubjectIcon = "calculator" | "languages" | "book" | "flask" | "map" | "landmark";

export type Subject = {
  id: string;
  title: Lang;
  blurb: Lang;
  icon: SubjectIcon;
  chapters: Chapter[];
};

export type Exam = {
  id: "grade-6" | "grade-8";
  grade: 6 | 8;
  title: Lang;
  minutes: number;
  questions: Question[];
};

const L = (en: string, am: string): Lang => ({ en, am });

function ch(
  id: string,
  grades: number[],
  title: Lang,
  summary: Lang,
  paragraphs: Lang[],
  questions: Question[],
): Chapter {
  return { id, grades, title, summary, paragraphs, questions };
}

export const subjects: Subject[] = [
  {
    id: "mathematics",
    title: L("Mathematics", "ሒሳብ"),
    blurb: L("Numbers, fractions, percent, and equations.", "ቁጥሮች፣ ክፍልፋዮች፣ መቶኛ እና እኩልታዎች።"),
    icon: "calculator",
    chapters: [
      ch(
        "place-value",
        [4, 5],
        L("Place value", "የቦታ ዋጋ"),
        L("Read big numbers by the place of each digit.", "እያንዳንዱ አሃዝ በቦታው ዋጋውን ይነግረናል።"),
        [
          L(
            "A digit’s place tells us its value. In 4,582 the 4 means 4 thousands, the 5 means 5 hundreds, the 8 means 8 tens, and the 2 means 2 ones.",
            "የአሃዝ ቦታ ዋጋውን ይነግረናል። በ4,582 ውስጥ 4 ማለት 4 ሺህ፣ 5 ማለት 5 መቶ፣ 8 ማለት 8 አስር፣ 2 ማለት 2 አንድ ነው።",
          ),
          L(
            "We group digits in threes so large numbers are easier to read: ones, thousands, then millions. Prices, distances, and populations all use place value.",
            "ትልልቅ ቁጥሮችን ለማንበብ አሃዞችን በሦስት ሦስት እንከፍላለን፦ አንድ፣ ሺህ፣ ከዚያ ሚሊዮን። ዋጋ፣ ርቀት እና የሰው ብዛት የቦታ ዋጋ ይጠቀማሉ።",
          ),
        ],
        [
          {
            id: "pv1",
            prompt: L("In 3,407, which place is the 4 in?", "በ3,407 ውስጥ 4 በየትኛው ቦታ ነው?"),
            choices: [
              L("Tens", "አስር"),
              L("Hundreds", "መቶ"),
              L("Thousands", "ሺህ"),
              L("Ones", "አንድ"),
            ],
            answer: 1,
            explain: L(
              "From the right: 7 ones, 0 tens, 4 hundreds, 3 thousands.",
              "ከቀኝ፦ 7 አንድ፣ 0 አስር፣ 4 መቶ፣ 3 ሺህ።",
            ),
          },
          {
            id: "pv2",
            prompt: L("What is the value of the 6 in 6,250?", "በ6,250 ውስጥ የ6 ዋጋ ስንት ነው?"),
            choices: [L("6", "6"), L("60", "60"), L("600", "600"), L("6,000", "6,000")],
            answer: 3,
            explain: L("The 6 is in the thousands place, so its value is 6,000.", "6 በሺህ ቦታ ነው፣ ስለዚህ ዋጋው 6,000 ነው።"),
          },
          {
            id: "pv3",
            prompt: L("Which number is the greatest?", "የትኛው ቁጥር ይበልጣል?"),
            choices: [L("2,895", "2,895"), L("2,985", "2,985"), L("2,859", "2,859"), L("2,589", "2,589")],
            answer: 1,
            explain: L(
              "All start with 2 thousands. Compare hundreds: 9 is the greatest, so 2,985 is greatest.",
              "ሁሉም በ2 ሺህ ይጀምራሉ። መቶዎቹን ስናነጻጽር 9 ይበልጣል፣ ስለዚህ 2,985 ይበልጣል።",
            ),
          },
        ],
      ),
      ch(
        "fractions",
        [4, 5, 6],
        L("Fractions", "ክፍልፋዮች"),
        L("Parts of a whole, and adding fractions.", "የሙሉ ክፍሎች እና ክፍልፋዮች መደመር።"),
        [
          L(
            "A fraction is part of a whole. The bottom number, the denominator, says how many equal parts. The top number, the numerator, says how many of those parts we have. One half is 1/2.",
            "ክፍልፋይ የሙሉ ክፍል ነው። ታችኛው ቁጥር (መለያ) ሙሉው በስንት እኩል ክፍሎች እንደተከፈለ ይነግራል። ላይኛው (ቁጥር) ከእነዚህ ስንት እንዳለን ይነግራል። አንድ አጋማሽ 1/2 ነው።",
          ),
          L(
            "To add fractions, the denominators must match. 1/2 is the same as 2/4, so 1/2 + 1/4 = 2/4 + 1/4 = 3/4.",
            "ክፍልፋዮችን ለመደመር መለያዎቹ እኩል መሆን አለባቸው። 1/2 ከ2/4 ጋር እኩል ነው፣ ስለዚህ 1/2 + 1/4 = 2/4 + 1/4 = 3/4።",
          ),
        ],
        [
          {
            id: "fr1",
            prompt: L("What is 1/2 + 1/4?", "1/2 + 1/4 ስንት ነው?"),
            choices: [L("2/6", "2/6"), L("1/4", "1/4"), L("3/4", "3/4"), L("2/4", "2/4")],
            answer: 2,
            explain: L("1/2 = 2/4. Then 2/4 + 1/4 = 3/4.", "1/2 = 2/4። ከዚያ 2/4 + 1/4 = 3/4።"),
          },
          {
            id: "fr2",
            prompt: L("Which fraction equals 1/2?", "ከ1/2 ጋር የሚጣጣመው የትኛው ነው?"),
            choices: [L("1/3", "1/3"), L("2/4", "2/4"), L("2/3", "2/3"), L("3/4", "3/4")],
            answer: 1,
            explain: L("2/4 simplifies by 2: 2÷2 over 4÷2 = 1/2.", "2/4 በ2 ይቀነሳል፦ 1/2።"),
          },
          {
            id: "fr3",
            prompt: L("A loaf is cut into 8 equal slices. You eat 3. What fraction is left?", "ዳቦ በ8 እኩል ተቆርጧል። 3 ከበላህ ስንት ይቀራል?"),
            choices: [L("3/8", "3/8"), L("5/8", "5/8"), L("8/3", "8/3"), L("1/8", "1/8")],
            answer: 1,
            explain: L("8 − 3 = 5 slices remain, so 5/8 of the loaf is left.", "8 − 3 = 5 ቁራጭ ይቀራል፣ ማለት 5/8።"),
          },
        ],
      ),
      ch(
        "percent",
        [6, 7, 8],
        L("Percent", "መቶኛ"),
        L("Percent means out of 100.", "መቶኛ ማለት ከ100 ውስጥ ማለት ነው።"),
        [
          L(
            "Percent means “per hundred.” 25% is 25 out of 100, which is the same as 1/4. To find 25% of a number, divide by 4, or multiply by 25 and divide by 100.",
            "መቶኛ ማለት «ከመቶ» ነው። 25% ማለት ከ100 ውስጥ 25 ነው፣ ከ1/4 ጋር እኩል ነው። የአንድ ቁጥር 25% ለማግኘት ለ4 እናካፍላለን፣ ወይም በ25 እናባዛለን እና ለ100 እናካፍላለን።",
          ),
          L(
            "A shop discount is a percent off the price. If a book costs 80 birr and the discount is 10%, you save 8 birr and pay 72 birr.",
            "ቅናሽ ከዋጋው የሚቀነስ መቶኛ ነው። መጽሐፍ 80 ብር ከሆነ እና ቅናሹ 10% ከሆነ፣ 8 ብር ትቆጥባለህ እና 72 ብር ትከፍላለህ።",
          ),
        ],
        [
          {
            id: "pc1",
            prompt: L("What is 25% of 40?", "የ40 25% ስንት ነው?"),
            choices: [L("8", "8"), L("10", "10"), L("15", "15"), L("25", "25")],
            answer: 1,
            explain: L("25% is one quarter. 40 ÷ 4 = 10.", "25% ሩብ ነው። 40 ÷ 4 = 10።"),
          },
          {
            id: "pc2",
            prompt: L("10% of 80 birr is:", "የ80 ብር 10% ስንት ነው?"),
            choices: [L("8 birr", "8 ብር"), L("10 birr", "10 ብር"), L("18 birr", "18 ብር"), L("70 birr", "70 ብር")],
            answer: 0,
            explain: L("10% means divide by 10. 80 ÷ 10 = 8.", "10% ማለት ለ10 ማካፈል ነው። 80 ÷ 10 = 8።"),
          },
          {
            id: "pc3",
            prompt: L("Which fraction equals 50%?", "ከ50% ጋር የሚጣጣመው ክፍልፋይ የትኛው ነው?"),
            choices: [L("1/4", "1/4"), L("1/5", "1/5"), L("1/2", "1/2"), L("1/10", "1/10")],
            answer: 2,
            explain: L("50 out of 100 is 1/2.", "ከ100 ውስጥ 50 ማለት 1/2 ነው።"),
          },
        ],
      ),
      ch(
        "equations",
        [7, 8],
        L("Simple equations", "ቀላል እኩልታዎች"),
        L("Find the unknown by keeping both sides equal.", "ሁለቱን ወገኖች እኩል በማድረግ የማናውቀውን እንፈልጋለን።"),
        [
          L(
            "An equation says two amounts are equal. In 2x + 3 = 11, x stands for an unknown number. We undo the steps: subtract 3 from both sides, then divide by 2.",
            "እኩልታ ሁለት መጠኖች እኩል መሆናቸውን ይናገራል። በ2x + 3 = 11 ውስጥ x የማናውቀው ቁጥር ነው። ደረጃዎቹን እንመልሳለን፦ ከሁለቱም ወገን 3 እንቀንሳለን፣ ከዚያ ለ2 እናካፍላለን።",
          ),
          L(
            "Check your answer by putting it back. If x = 4, then 2(4) + 3 = 8 + 3 = 11. Both sides match, so the solution is correct.",
            "መልስህን በመመለስ አረጋግጥ። x = 4 ከሆነ 2(4) + 3 = 8 + 3 = 11። ሁለቱ ወገኖች ይጣጣማሉ።",
          ),
        ],
        [
          {
            id: "eq1",
            prompt: L("Solve 2x + 3 = 11.", "2x + 3 = 11 ን ፍታ።"),
            choices: [L("x = 3", "x = 3"), L("x = 4", "x = 4"), L("x = 7", "x = 7"), L("x = 8", "x = 8")],
            answer: 1,
            explain: L("Subtract 3: 2x = 8. Divide by 2: x = 4.", "3 ቀንስ፦ 2x = 8። ለ2 ክፈል፦ x = 4።"),
          },
          {
            id: "eq2",
            prompt: L("If 3x = 12, what is x?", "3x = 12 ከሆነ x ስንት ነው?"),
            choices: [L("3", "3"), L("4", "4"), L("9", "9"), L("36", "36")],
            answer: 1,
            explain: L("Divide both sides by 3. 12 ÷ 3 = 4.", "ሁለቱንም ወገን ለ3 ክፈል። 12 ÷ 3 = 4።"),
          },
          {
            id: "eq3",
            prompt: L("Which value makes x − 5 = 9 true?", "x − 5 = 9 የሚያስተካክለው የትኛው ነው?"),
            choices: [L("x = 4", "x = 4"), L("x = 14", "x = 14"), L("x = 45", "x = 45"), L("x = −4", "x = −4")],
            answer: 1,
            explain: L("Add 5 to both sides. x = 14.", "በሁለቱም ወገን 5 ጨምር። x = 14።"),
          },
        ],
      ),
    ],
  },
  {
    id: "english",
    title: L("English", "እንግሊዝኛ"),
    blurb: L("Reading, tense, and clear sentences.", "ንባብ፣ ጊዜ እና ግልጽ ዓረፍተ ነገር።"),
    icon: "languages",
    chapters: [
      ch(
        "reading-school",
        [4, 5],
        L("A morning at school", "ጠዋት በትምህርት ቤት"),
        L("Read a short story and notice the details.", "አጭር ታሪክ አንብበህ ዝርዝሮቹን ተመልከት።"),
        [
          L(
            "Hana walks to school with her brother. The road is dusty, so they walk slowly. At the gate she greets her teacher and puts her mathematics book on the desk.",
            "ሃና ከወንድሟ ጋር ወደ ትምህርት ቤት ትሄዳለች። መንገዱ አቧራማ ስለሆነ ቀስ ብለው ይሄዳሉ። በሩ ላይ መምህሯን ታቀባበላለች እና የሒሳብ መጽሐፏን በጠረጴዛው ላይ ታስቀምጣለች።",
          ),
          L(
            "Good readers ask: Who? Where? What happens? Here the people are Hana and her brother. The place is the road and the school. The action is walking, greeting, and getting ready.",
            "ጥሩ አንባቢ ይጠይቃል፦ ማን? የት? ምን ይሆናል? እዚህ ሰዎቹ ሃና እና ወንድሟ ናቸው። ቦታው መንገድ እና ትምህርት ቤት ነው። ተግባሩ መሄድ፣ መቀበል እና መዘጋጀት ነው።",
          ),
        ],
        [
          {
            id: "en1",
            prompt: L("Who walks with Hana?", "ከሃና ጋር የሚሄደው ማን ነው?"),
            choices: [
              L("Her teacher", "መምህሯ"),
              L("Her brother", "ወንድሟ"),
              L("Her friend", "ጓደኛዋ"),
              L("She walks alone", "ብቻዋን ትሄዳለች"),
            ],
            answer: 1,
            explain: L("The first sentence says she walks with her brother.", "የመጀመሪያው ዓረፍተ ነገር ከወንድሟ ጋር እንደምትሄድ ይናገራል።"),
          },
          {
            id: "en2",
            prompt: L("Why do they walk slowly?", "ለምን ቀስ ብለው ይሄዳሉ?"),
            choices: [
              L("The road is dusty", "መንገዱ አቧራማ ነው"),
              L("They are late", "ዘግይተዋል"),
              L("The book is heavy", "መጽሐፉ ከባድ ነው"),
              L("The gate is closed", "በሩ ተዘግቷል"),
            ],
            answer: 0,
            explain: L("The story says the road is dusty, so they walk slowly.", "ታሪኩ መንገዱ አቧራማ ስለሆነ ቀስ እንደሚሄዱ ይናገራል።"),
          },
          {
            id: "en3",
            prompt: L("Which book does Hana put on the desk?", "ሃና በጠረጴዛው ላይ የምታስቀምጠው የትኛው መጽሐፍ ነው?"),
            choices: [
              L("English", "እንግሊዝኛ"),
              L("Science", "ሳይንስ"),
              L("Mathematics", "ሒሳብ"),
              L("Amharic", "አማርኛ"),
            ],
            answer: 2,
            explain: L("She puts her mathematics book on the desk.", "የሒሳብ መጽሐፏን በጠረጴዛው ላይ ታስቀምጣለች።"),
          },
        ],
      ),
      ch(
        "past-tense",
        [5, 6, 7],
        L("Simple past", "ያለፈ ጊዜ"),
        L("Talk about what already happened.", "ስለ ስለተከሰተ ነገር ተናገር።"),
        [
          L(
            "The simple past tells us an action is finished. Regular verbs add -ed: walk becomes walked, play becomes played. Some verbs change shape: go becomes went, see becomes saw, eat becomes ate.",
            "ያለፈ ጊዜ ተግባሩ መጠናቀቁን ይነግረናል። መደበኛ ግሶች -ed ይጨምራሉ፦ walk ወደ walked። አንዳንድ ግሶች ቅርጻቸውን ይቀይራሉ፦ go ወደ went፣ see ወደ saw፣ eat ወደ ate።",
          ),
          L(
            "Use past time words with these verbs: yesterday, last week, this morning. “Yesterday we went to the market” is past. “Every day we go to the market” is present.",
            "ከእነዚህ ግሶች ጋር የጊዜ ቃላት ተጠቀም፦ yesterday፣ last week፣ this morning። “Yesterday we went to the market” ያለፈ ነው። “Every day we go to the market” የአሁን ነው።",
          ),
        ],
        [
          {
            id: "pt1",
            prompt: L("What is the past of “go”?", "የ “go” ያለፈ ጊዜ ምንድን ነው?"),
            choices: [L("goed", "goed"), L("went", "went"), L("going", "going"), L("goes", "goes")],
            answer: 1,
            explain: L("Go is irregular. The past is went.", "Go መደበኛ አይደለም። ያለፈው went ነው።"),
          },
          {
            id: "pt2",
            prompt: L("Choose the correct sentence.", "ትክክለኛውን ዓረፍተ ነገር ምረጥ።"),
            choices: [
              L("Yesterday she walk to school.", "Yesterday she walk to school."),
              L("Yesterday she walked to school.", "Yesterday she walked to school."),
              L("Yesterday she walking to school.", "Yesterday she walking to school."),
              L("Yesterday she walks to school yesterday.", "Yesterday she walks to school yesterday."),
            ],
            answer: 1,
            explain: L("Yesterday needs the past form walked.", "Yesterday ያለፈውን walked ይፈልጋል።"),
          },
          {
            id: "pt3",
            prompt: L("The past of “eat” is:", "የ “eat” ያለፈ ጊዜ፦"),
            choices: [L("eated", "eated"), L("eaten", "eaten"), L("ate", "ate"), L("eating", "eating")],
            answer: 2,
            explain: L("Eat → ate. Eaten is the past participle, used with have.", "Eat → ate። Eaten ከ have ጋር ይመጣል።"),
          },
        ],
      ),
      ch(
        "paragraphs",
        [6, 7, 8],
        L("Writing a paragraph", "አንቀጽ መጻፍ"),
        L("One idea, a few details, a clear ending.", "አንድ ሐሳብ፣ ጥቂት ዝርዝሮች፣ ግልጽ መደምደሚያ።"),
        [
          L(
            "A paragraph has one main idea. The first sentence tells the reader that idea. The next sentences give details or an example. The last sentence closes the idea without starting a new one.",
            "አንቀጽ አንድ ዋና ሐሳብ አለው። የመጀመሪያው ዓረፍተ ነገር ሐሳቡን ይነግራል። ቀጣዮቹ ዝርዝር ወይም ምሳሌ ይሰጣሉ። የመጨረሻው ሐሳቡን ይዘጋል፣ አዲስ ሐሳብ አይጀምርም።",
          ),
          L(
            "Weak: “Markets are nice. I like football. My uncle is tall.” These sentences do not share one idea. Strong: “The Saturday market is busy. Farmers sell onions and coffee. People talk while they buy food for the week.”",
            "ደካማ፦ “Markets are nice. I like football. My uncle is tall.” እነዚህ አንድ ሐሳብ አይጋሩም። ጠንካራ፦ “The Saturday market is busy. Farmers sell onions and coffee. People talk while they buy food for the week.”",
          ),
        ],
        [
          {
            id: "pg1",
            prompt: L("What should the first sentence of a paragraph do?", "የአንቀጽ የመጀመሪያ ዓረፍተ ነገር ምን ሊያደርግ ይገባል?"),
            choices: [
              L("Tell the main idea", "ዋናውን ሐሳብ ይንገር"),
              L("List every fact", "ሁሉንም እውነታ ይዘርዝር"),
              L("Ask three questions", "ሦስት ጥያቄዎችን ይጠይቅ"),
              L("End the story", "ታሪኩን ይጨርስ"),
            ],
            answer: 0,
            explain: L("The topic sentence states the one main idea.", "የርዕስ ዓረፍተ ነገር አንዱን ዋና ሐሳብ ይገልጻል።"),
          },
          {
            id: "pg2",
            prompt: L("Which line does NOT belong with a paragraph about a market?", "ስለ ገበያ በሆነ አንቀጽ ውስጥ የማይገባው የትኛው ነው?"),
            choices: [
              L("Farmers sell coffee.", "ገበሬዎች ቡና ይሸጣሉ።"),
              L("The road is crowded.", "መንገዱ ተጨናንቋል።"),
              L("My favorite subject is music.", "የምወደው ትምህርት ሙዚቃ ነው።"),
              L("People buy onions.", "ሰዎች ሽንኩርት ይገዛሉ።"),
            ],
            answer: 2,
            explain: L("Music is a new idea. The other lines are about the market.", "ሙዚቃ አዲስ ሐሳብ ነው። ሌሎቹ ስለ ገበያ ናቸው።"),
          },
          {
            id: "pg3",
            prompt: L("A good paragraph should have:", "ጥሩ አንቀጽ ሊኖረው የሚገባው፦"),
            choices: [
              L("Many unrelated ideas", "ብዙ ያልተያያዙ ሐሳቦች"),
              L("One main idea", "አንድ ዋና ሐሳብ"),
              L("Only one word", "አንድ ቃል ብቻ"),
              L("No examples", "ምሳሌ የለም"),
            ],
            answer: 1,
            explain: L("Stick to one main idea and support it.", "በአንድ ዋና ሐሳብ ተጣበቅ እና ደግፈው።"),
          },
        ],
      ),
      ch(
        "comprehension",
        [7, 8],
        L("Reading for meaning", "ለትርጉም ማንበብ"),
        L("Use the text, not a guess.", "ጽሑፉን ተጠቀም፣ ግምትን አይደለም።"),
        [
          L(
            "Some questions are answered in the words. Others ask you to infer: use clues, but do not invent facts that the text never suggests. If the text says “Abel closed his book and sighed,” we can say he may be tired. We cannot say he failed a test.",
            "አንዳንድ ጥያቄዎች በቃላቱ ይመለሳሉ። ሌሎች መረዳት ይጠይቃሉ፦ ፍንጭ ተጠቀም፣ ጽሑፉ የማይጠቁመውን እውነታ አትፍጠር። ጽሑፉ “Abel closed his book and sighed” ካለ ደክሞ ሊሆን ይችላል እንላለን። ፈተና ወድቋል ማለት አንችልም።",
          ),
          L(
            "Underline the sentence that proves your answer. If you cannot point to a clue, choose the safer answer that stays inside the text.",
            "መልስህን የሚያረጋግጠውን ዓረፍተ ነገር አስምርበት። ፍንጭ ማመልከት ካልቻልክ በጽሑፉ ውስጥ የሚቆየውን መልስ ምረጥ።",
          ),
        ],
        [
          {
            id: "rc1",
            prompt: L(
              "“The sky turned dark and people opened umbrellas.” What can we infer?",
              "“The sky turned dark and people opened umbrellas.” ምን መረዳት እንችላለን?",
            ),
            choices: [
              L("It is probably raining", "ምናልባት ዝናብ እየዘነበ ነው"),
              L("It is midnight", "እኩለ ሌሊት ነው"),
              L("School is closed", "ትምህርት ቤት ተዘግቷል"),
              L("They are inside a shop", "በሱቅ ውስጥ ናቸው"),
            ],
            answer: 0,
            explain: L("Dark sky plus umbrellas is a clue for rain. The other ideas are not in the text.", "ጨለማ ሰማይ እና ጃንጥላ የዝናብ ፍንጭ ናቸው።"),
          },
          {
            id: "rc2",
            prompt: L("A fact stated in a text is called:", "በጽሑፍ ውስጥ በቀጥታ የተነገረ እውነታ ምን ይባላል?"),
            choices: [
              L("An inference", "ግምት"),
              L("A detail you can point to", "ማመልከት የምትችለው ዝርዝር"),
              L("A title", "ርዕስ"),
              L("A rhyme", "ግጥም"),
            ],
            answer: 1,
            explain: L("A stated detail is right there to point to. An inference is a careful conclusion.", "የተገለጸ ዝርዝር እዚያው አለ። ግምት ግን ጥንቃቄ የተሞላበት መደምደሚያ ነው።"),
          },
          {
            id: "rc3",
            prompt: L("Which inference is too far?", "የትኛው ግምት በጣም ይርቃል?"),
            choices: [
              L("Sighing may show tiredness", "ማቃተት ድካም ሊያሳይ ይችላል"),
              L("An umbrella suggests rain", "ጃንጥላ ዝናብን ይጠቁማል"),
              L("Closing a book proves someone moved to another country", "መጽሐፍ መዝጋት ሰው ወደ ሌላ አገር መሄዱን ያረጋግጣል"),
              L("A crowded road suggests many people", "የተጨናነቀ መንገድ ብዙ ሰው እንዳለ ይጠቁማል"),
            ],
            answer: 2,
            explain: L("Closing a book does not tell us someone moved countries.", "መጽሐፍ መዝጋት ሰው አገር እንደቀየረ አይነግረንም።"),
          },
        ],
      ),
    ],
  },
  {
    id: "amharic",
    title: L("Amharic", "አማርኛ"),
    blurb: L("Words, sentences, and short writing.", "ቃላት፣ ዓረፍተ ነገሮች እና አጭር ጽሑፍ።"),
    icon: "book",
    chapters: [
      ch(
        "words",
        [4, 5],
        L("Words we use every day", "በየቀኑ የምንጠቀምባቸው ቃላት"),
        L("Name people, places, and actions.", "ሰዎችን፣ ቦታዎችን እና ተግባሮችን ሰይም።"),
        [
          L(
            "A noun names a person, place, or thing: ተማሪ፣ ትምህርት ቤት፣ መጽሐፍ። A verb tells the action: ያነባል፣ ይጻፋል፣ ይሄዳል።",
            "ስም ሰውን፣ ቦታን ወይም ነገርን ይሰይማል፦ ተማሪ፣ ትምህርት ቤት፣ መጽሐፍ። ግስ ተግባሩን ይነግራል፦ ያነባል፣ ይጻፋል፣ ይሄዳል።",
          ),
          L(
            "When you meet a new word, say it aloud, write it once, and use it in a short sentence of your own. That is how a word stays in memory.",
            "አዲስ ቃል ስታገኝ ጮክ ብለህ ተናገረው፣ አንድ ጊዜ ጻፈው፣ እና በራስህ አጭር ዓረፍተ ነገር ተጠቀምበት። ቃሉ በዚህ መንገድ በትዝታ ይቆያል።",
          ),
        ],
        [
          {
            id: "am1",
            prompt: L("Which word is a noun?", "የትኛው ቃል ስም ነው?"),
            choices: [L("ያነባል", "ያነባል"), L("መጽሐፍ", "መጽሐፍ"), L("በፍጥነት", "በፍጥነት"), L("እና", "እና")],
            answer: 1,
            explain: L("መጽሐፍ names a thing. ያነባል is a verb.", "መጽሐፍ ነገርን ይሰይማል። ያነባል ግስ ነው።"),
          },
          {
            id: "am2",
            prompt: L("Which word is a verb?", "የትኛው ቃል ግስ ነው?"),
            choices: [L("ትምህርት ቤት", "ትምህርት ቤት"), L("ሄኖክ", "ሄኖክ"), L("ይጻፋል", "ይጻፋል"), L("ደብተር", "ደብተር")],
            answer: 2,
            explain: L("ይጻፋል tells an action. The others name a place, a person, and a thing.", "ይጻፋል ተግባር ነው። ሌሎቹ ስሞች ናቸው።"),
          },
          {
            id: "am3",
            prompt: L("A good way to remember a new word is to:", "አዲስ ቃል ለማስታወስ ጥሩ መንገድ፦"),
            choices: [
              L("Skip it", "ዝለለው"),
              L("Use it in your own sentence", "በራስህ ዓረፍተ ነገር ተጠቀምበት"),
              L("Read it only once in silence and never again", "አንድ ጊዜ ዝም ብለህ አንብበህ ተወው"),
              L("Change the letters", "ፊደላቱን ቀይር"),
            ],
            answer: 1,
            explain: L("Saying, writing, and using a word helps you keep it.", "መናገር፣ መጻፍ እና መጠቀም ቃሉን ያስቀራል።"),
          },
        ],
      ),
      ch(
        "sentences",
        [5, 6, 7],
        L("Building a sentence", "ዓረፍተ ነገር መሥራት"),
        L("A sentence needs a naming part and an action.", "ዓረፍተ ነገር ስም እና ተግባር ይፈልጋል።"),
        [
          L(
            "ሄኖክ መጽሐፍ ያነባል። Here ሄኖክ is who, and ያነባል is the action. A line of words with no action is not yet a sentence: “ትልቅ አረንጓዴ መጽሐፍ” only names something.",
            "ሄኖክ መጽሐፍ ያነባል። እዚህ ሄኖክ ማን እንደሆነ፣ ያነባል ደግሞ ተግባሩ ነው። ተግባር የሌለው የቃላት መስመር ገና ዓረፍተ ነገር አይደለም፦ “ትልቅ አረንጓዴ መጽሐፍ” ነገርን ብቻ ይሰይማል።",
          ),
          L(
            "You can grow a sentence with where or when: ሄኖክ በምሽት መጽሐፍ ያነባል። Keep the who and the verb clear so the reader is not lost.",
            "ዓረፍተ ነገርን በቦታ ወይም በጊዜ ማሳደግ ትችላለህ፦ ሄኖክ በምሽት መጽሐፍ ያነባል። አንባቢው እንዳይጠፋ ማን እና ግሱ ግልጽ ይሁኑ።",
          ),
        ],
        [
          {
            id: "sn1",
            prompt: L("Which line is a full sentence?", "የትኛው ሙሉ ዓረፍተ ነገር ነው?"),
            choices: [
              L("አረንጓዴ ደብተር", "አረንጓዴ ደብተር"),
              L("ሃና ደብተሯን ትጽፋለች", "ሃና ደብተሯን ትጽፋለች"),
              L("በጣም ትልቅ", "በጣም ትልቅ"),
              L("የሒሳብ መጽሐፍ", "የሒሳብ መጽሐፍ"),
            ],
            answer: 1,
            explain: L("It has who (ሃና) and an action (ትጽፋለች).", "ማን (ሃና) እና ተግባር (ትጽፋለች) አለው።"),
          },
          {
            id: "sn2",
            prompt: L("In “ሄኖክ ይሄዳል” the verb is:", "በ“ሄኖክ ይሄዳል” ግሱ የትኛው ነው?"),
            choices: [L("ሄኖክ", "ሄኖክ"), L("ይሄዳል", "ይሄዳል"), L("both words", "ሁለቱም"), L("neither", "አንዳቸውም")],
            answer: 1,
            explain: L("ይሄዳል is the action. ሄኖክ is the name.", "ይሄዳል ተግባር ነው። ሄኖክ ስም ነው።"),
          },
          {
            id: "sn3",
            prompt: L("Which word adds time to a sentence?", "ጊዜ የሚጨምረው ቃል የትኛው ነው?"),
            choices: [L("በምሽት", "በምሽት"), L("መጽሐፍ", "መጽሐፍ"), L("ተማሪ", "ተማሪ"), L("እርሳስ", "እርሳስ")],
            answer: 0,
            explain: L("በምሽት tells when. The others name things.", "በምሽት መቼ እንደሆነ ይነግራል።"),
          },
        ],
      ),
      ch(
        "story",
        [6, 7, 8],
        L("A short folktale shape", "የአጭር ተረት አቋም"),
        L("Beginning, problem, and ending.", "መጀመሪያ፣ ችግር እና መጨረሻ።"),
        [
          L(
            "Many short stories follow three beats. Beginning: we meet the character. Middle: a problem appears. Ending: the character acts and something changes. A clever hare, a proud lion, or a careful student can all follow this shape.",
            "ብዙ አጫጭር ታሪኮች ሦስት ምቶች አሏቸው። መጀመሪያ፦ ገጸ ባህሪውን እናውቃለን። መካከል፦ ችግር ይመጣል። መጨረሻ፦ ገጸ ባህሪው ይሠራል እና ነገር ይቀየራል።",
          ),
          L(
            "When you retell a story, keep the events in order. Do not skip the problem, or the ending will not make sense. One honest detail is better than five mixed-up events.",
            "ታሪክ ስትተርክ ክስተቶችን በቅደም ተከተል ጠብቅ። ችግሩን አትዝለል፣ ካዘለልክ መጨረሻው አይገባም። አንድ ትክክለኛ ዝርዝር ከአምስት ከተደባለቁ ክስተቶች ይሻላል።",
          ),
        ],
        [
          {
            id: "st1",
            prompt: L("What usually comes in the middle of a short story?", "በአጭር ታሪክ መካከል ብዙ ጊዜ ምን ይመጣል?"),
            choices: [
              L("The title only", "ርዕሱ ብቻ"),
              L("A problem", "ችግር"),
              L("The writer’s address", "የጸሐፊው አድራሻ"),
              L("A blank page", "ባዶ ገጽ"),
            ],
            answer: 1,
            explain: L("The middle brings the problem the character must face.", "መካከሉ ገጸ ባህሪው ሊገጥመው የሚገባውን ችግር ያመጣል።"),
          },
          {
            id: "st2",
            prompt: L("Why keep events in order?", "ክስተቶችን በቅደም ተከተል የምንጠብቀው ለምንድን ነው?"),
            choices: [
              L("So the ending makes sense", "መጨረሻው እንዲገባ"),
              L("So the story is longer", "ታሪኩ እንዲረዝም"),
              L("So we can skip the problem", "ችግሩን እንድንዘል"),
              L("Order does not matter", "ቅደም ተከተል አያስፈልግም"),
            ],
            answer: 0,
            explain: L("If the problem is skipped or moved, the ending is confusing.", "ችግሩ ከተዘለለ መጨረሻው ግራ ያጋባል።"),
          },
          {
            id: "st3",
            prompt: L("A story ending should show:", "የታሪክ መጨረሻ ሊያሳየን የሚገባው፦"),
            choices: [
              L("That something changed", "ነገር መቀየሩን"),
              L("A new unrelated topic", "አዲስ ያልተያያዘ ርዕስ"),
              L("Only the character’s name", "የገጸ ባህሪውን ስም ብቻ"),
              L("The first line again with no change", "የመጀመሪያውን መስመር ሳይቀየር"),
            ],
            answer: 0,
            explain: L("The ending lands because the character’s action changed something.", "መጨረሻው የሚያርፈው ተግባሩ ነገር ስለቀየረ ነው።"),
          },
        ],
      ),
      ch(
        "writing",
        [7, 8],
        L("A short opinion", "አጭር አስተያየት"),
        L("Say what you think, then give a reason.", "የምታስበውን በል፣ ከዚያ ምክንያት ስጥ።"),
        [
          L(
            "An opinion sentence tells your view: የቤተ መጻሕፍት ጊዜ ለተማሪዎች ይጠቅማል። The next sentence must give a reason, not a repeat: መጽሐፍ ሲያገኙ አዲስ ቃላት ይማራሉ።",
            "የአስተያየት ዓረፍተ ነገር እይታህን ይናገራል፦ የቤተ መጻሕፍት ጊዜ ለተማሪዎች ይጠቅማል። ቀጣዩ ዓረፍተ ነገር ምክንያት መስጠት አለበት እንጂ መደገም አይደለም፦ መጽሐፍ ሲያገኙ አዲስ ቃላት ይማራሉ።",
          ),
          L(
            "A reason answers “why?” If you cannot answer why, the sentence is only a wish. Read your two sentences aloud. If they sound like one idea, you are ready to stop.",
            "ምክንያት «ለምን?» የሚለውን ይመልሳል። ለምን ማለት ካልቻልክ ዓረፍተ ነገሩ ምኞት ብቻ ነው። ሁለቱን ዓረፍተ ነገሮች ጮክ ብለህ አንብብ። እንደ አንድ ሐሳብ ከሰሙ መቆም ትችላለህ።",
          ),
        ],
        [
          {
            id: "wr1",
            prompt: L("Which line is a reason, not only an opinion?", "የትኛው ምክንያት ነው እንጂ አስተያየት ብቻ አይደለም?"),
            choices: [
              L("ስፖርት ጥሩ ነው።", "ስፖርት ጥሩ ነው።"),
              L("ስፖርት ሰውነታችንን ያንቀሳቅሳል።", "ስፖርት ሰውነታችንን ያንቀሳቅሳል።"),
              L("ስፖርት!", "ስፖርት!"),
              L("በጣም በጣም ጥሩ።", "በጣም በጣም ጥሩ።"),
            ],
            answer: 1,
            explain: L("It answers why sport helps: it moves the body.", "ስፖርት ለምን እንደሚረዳ ይመልሳል፦ ሰውነትን ያንቀሳቅሳል።"),
          },
          {
            id: "wr2",
            prompt: L("A reason should answer:", "ምክንያት ሊመልስ የሚገባው፦"),
            choices: [L("Why?", "ለምን?"), L("What color is the cover?", "የሽፋኑ ቀለም ምንድን ነው?"), L("How many pages, always", "ሁልጊዜ ስንት ገጽ"), L("Who printed it", "ማን አተመው")],
            answer: 0,
            explain: L("If it does not answer why, it is not yet a reason.", "ለምን ካልመለሰ ገና ምክንያት አይደለም።"),
          },
          {
            id: "wr3",
            prompt: L("After an opinion, the next sentence should:", "ከአስተያየት በኋላ ቀጣዩ ዓረፍተ ነገር፦"),
            choices: [
              L("Give a reason", "ምክንያት ይስጥ"),
              L("Repeat the same words only", "ተመሳሳይ ቃላትን ብቻ ይድገም"),
              L("Start a new topic", "አዲስ ርዕስ ይጀምር"),
              L("Leave a blank", "ባዶ ይተው"),
            ],
            answer: 0,
            explain: L("Opinion plus reason is the smallest strong paragraph.", "አስተያየት እና ምክንያት ትንሹ ጠንካራ አንቀጽ ነው።"),
          },
        ],
      ),
    ],
  },
  {
    id: "science",
    title: L("Science", "ሳይንስ"),
    blurb: L("Living things, water, the body, and matter.", "ሕያዋን፣ ውሃ፣ ሰውነት እና ቁስ።"),
    icon: "flask",
    chapters: [
      ch(
        "habitats",
        [4, 5],
        L("Habitats", "መኖሪያዎች"),
        L("Living things match the place they live.", "ሕያዋን ከሚኖሩበት ቦታ ጋር ይጣጣማሉ።"),
        [
          L(
            "A habitat is the place a living thing needs: food, water, shelter, and space. Highland forests, lakes, and hot lowlands are different habitats. A fish needs water. A gelada needs highland grass and cliffs.",
            "መኖሪያ ሕያው ነገር የሚያስፈልገው ቦታ ነው፦ ምግብ፣ ውሃ፣ መጠለያ እና ቦታ። የደጋ ደን፣ ሐይቅ እና ሞቃት ቆላ የተለያዩ መኖሪያዎች ናቸው። ዓሣ ውሃ ይፈልጋል። ጭላዳ የደጋ ሣር እና ቋጥኝ ይፈልጋል።",
          ),
          L(
            "If a habitat changes too fast — a lake dries, or trees are all cut — the animals and plants that depend on it struggle. Caring for a habitat means caring for the living things in it.",
            "መኖሪያ በፍጥነት ከተቀየረ — ሐይቅ ከደረቀ ወይም ዛፎች በሙሉ ከተቆረጡ — በእሱ ላይ የሚመኩ እንስሳት እና እፅዋት ይቸገራሉ። መኖሪያን መጠበቅ በውስጡ ያሉትን ሕያዋን መጠበቅ ነው።",
          ),
        ],
        [
          {
            id: "hb1",
            prompt: L("A habitat must provide:", "መኖሪያ ሊሰጥ የሚገባው፦"),
            choices: [
              L("Only bright colors", "ደማቅ ቀለም ብቻ"),
              L("Food, water, shelter, and space", "ምግብ፣ ውሃ፣ መጠለያ እና ቦታ"),
              L("A name", "ስም"),
              L("A road", "መንገድ"),
            ],
            answer: 1,
            explain: L("Those four needs make a place livable.", "እነዚህ አራት ነገሮች ቦታውን ለመኖር ያስችላሉ።"),
          },
          {
            id: "hb2",
            prompt: L("Which animal fits a highland habitat?", "ለደጋ መኖሪያ የሚስማማው የትኛው ነው?"),
            choices: [L("Gelada", "ጭላዳ"), L("A fish that never leaves water", "ከውሃ የማይወጣ ዓሣ"), L("Seaweed", "የባሕር አረም"), L("A camel in a hot desert only", "በሞቃት በረሃ ብቻ የሚኖር ግመል")],
            answer: 0,
            explain: L("Geladas live on highland grass and cliffs.", "ጭላዳዎች በደጋ ሣር እና ቋጥኝ ይኖራሉ።"),
          },
          {
            id: "hb3",
            prompt: L("If a lake dries up, fish there will:", "ሐይቅ ከደረቀ እዚያ ያሉ ዓሦች፦"),
            choices: [
              L("Have no water habitat", "የውሃ መኖሪያ አይኖራቸውም"),
              L("Grow wings at once", "ወዲያው ክንፍ ያበቅላሉ"),
              L("Not be affected", "አይጎዱም"),
              L("Become trees", "ዛፍ ይሆናሉ"),
            ],
            answer: 0,
            explain: L("Fish depend on water. Losing the lake removes their habitat.", "ዓሦች በውሃ ይመካሉ።"),
          },
        ],
      ),
      ch(
        "water-cycle",
        [5, 6, 7],
        L("The water cycle", "የውሃ ዑደት"),
        L("Water moves, changes form, and returns.", "ውሃ ይንቀሳቀሳል፣ ቅርጽ ይቀይራል፣ ይመለሳል።"),
        [
          L(
            "Heat from the sun turns liquid water into vapor. That change is evaporation. The vapor rises, cools, and becomes tiny drops. That change is condensation, and the drops make clouds.",
            "የፀሐይ ሙቀት ፈሳሽ ውሃን ወደ ትነት ይቀይረዋል። ይህ ለውጥ ትነት (evaporation) ነው። ትነቱ ይወጣል፣ ይቀዘቅዛል፣ ጥቃቅን ጠብታዎች ይሆናል። ይህ መከማቸት (condensation) ነው፣ ጠብታዎቹም ደመና ይሠራሉ።",
          ),
          L(
            "When the drops grow heavy, they fall as rain or, if it is cold enough, as hail. That is precipitation. The water collects in rivers and lakes, and the cycle can begin again. The water is not used up; it keeps moving.",
            "ጠብታዎቹ ሲከብዱ እንደ ዝናብ ይወድቃሉ፣ በቂ ቅዝቃዜ ካለ ደግሞ እንደ በረዶ። ይህ ዝናብ (precipitation) ነው። ውሃው በወንዞች እና በሐይቆች ይሰበሰባል፣ ዑደቱም እንደገና ሊጀምር ይችላል።",
          ),
        ],
        [
          {
            id: "wc1",
            prompt: L("Evaporation is when:", "ትነት ማለት፦"),
            choices: [
              L("Liquid water becomes vapor", "ፈሳሽ ውሃ ትነት ይሆናል"),
              L("Rain falls", "ዝናብ ይወርዳል"),
              L("Clouds disappear into rock", "ደመና ወደ ድንጋይ ይጠፋል"),
              L("Ice becomes a plant", "በረዶ ተክል ይሆናል"),
            ],
            answer: 0,
            explain: L("Heat turns liquid water into vapor. That is evaporation.", "ሙቀት ፈሳሽ ውሃን ወደ ትነት ይቀይራል።"),
          },
          {
            id: "wc2",
            prompt: L("Clouds form mainly by:", "ደመናዎች በዋናነት የሚሠሩት በ፦"),
            choices: [
              L("Condensation", "መከማቸት"),
              L("Planting seeds", "ዘር በመዝራት"),
              L("Boiling rocks", "ድንጋይ በማፍላት"),
              L("Cutting trees", "ዛፍ በመቁረጥ"),
            ],
            answer: 0,
            explain: L("Vapor cools into tiny drops. Those drops are the cloud.", "ትነት ሲቀዘቅዝ ጥቃቅን ጠብታ ይሆናል።"),
          },
          {
            id: "wc3",
            prompt: L("Rain falling from clouds is called:", "ከደመና የሚወርድ ዝናብ ይባላል፦"),
            choices: [
              L("Evaporation", "ትነት"),
              L("Precipitation", "ዝናብ / precipitation"),
              L("Habitat", "መኖሪያ"),
              L("Fraction", "ክፍልፋይ"),
            ],
            answer: 1,
            explain: L("Water falling from the sky — rain or hail — is precipitation.", "ከሰማይ የሚወርድ ውሃ ዝናብ ነው።"),
          },
        ],
      ),
      ch(
        "digestion",
        [6, 7, 8],
        L("Digestion", "የምግብ መፈጨት"),
        L("Food is broken down so the body can use it.", "ሰውነት ሊጠቀምበት ምግብ ይፈጫል።"),
        [
          L(
            "Digestion starts in the mouth. Teeth break food into smaller pieces and saliva begins to soften it. You swallow, and the food moves down the esophagus to the stomach.",
            "መፈጨት በአፍ ይጀምራል። ጥርሶች ምግቡን ያነሳሳሉ፣ ምራቅም ማለስለስ ይጀምራል። ስትውጥ ምግቡ በጉሮሮ ቱቦ (esophagus) ወደ ሆድ ይሄዳል።",
          ),
          L(
            "The stomach churns food with acid and juices. Then the small intestine takes in most of the useful parts — nutrients — into the blood. The large intestine takes water from what is left. Waste leaves the body.",
            "ሆዱ ምግቡን በአሲድ እና በጭማቂ ያነሳሳል። ከዚያ ትንሹ አንጀት ጠቃሚዎቹን ክፍሎች (ንጥረ ነገሮች) ወደ ደም ያስገባል። ትልቁ አንጀት ከቀሪው ውሃ ይወስዳል። ቆሻሻው ከሰውነት ይወጣል።",
          ),
        ],
        [
          {
            id: "dg1",
            prompt: L("Where does digestion begin?", "መፈጨት የሚጀምረው የት ነው?"),
            choices: [L("The mouth", "በአፍ"), L("The large intestine", "በትልቁ አንጀት"), L("The heart", "በልብ"), L("The skin", "በቆዳ")],
            answer: 0,
            explain: L("Teeth and saliva start the work in the mouth.", "ጥርስ እና ምራቅ ሥራውን በአፍ ይጀምራሉ።"),
          },
          {
            id: "dg2",
            prompt: L("Most nutrients pass into the blood from the:", "አብዛኛው ንጥረ ነገር ወደ ደም የሚገባው ከ፦"),
            choices: [
              L("Small intestine", "ትንሹ አንጀት"),
              L("Hair", "ፀጉር"),
              L("Bones only", "ከአጥንት ብቻ"),
              L("Ears", "ጆሮ"),
            ],
            answer: 0,
            explain: L("The small intestine absorbs most nutrients.", "ትንሹ አንጀት አብዛኛውን ንጥረ ነገር ይቀበላል።"),
          },
          {
            id: "dg3",
            prompt: L("The tube from mouth to stomach is the:", "ከአፍ ወደ ሆድ ያለው ቱቦ፦"),
            choices: [
              L("Esophagus", "የጉሮሮ ቱቦ"),
              L("Heart", "ልብ"),
              L("Lung", "ሳንባ"),
              L("Skull", "የራስ ቅል"),
            ],
            answer: 0,
            explain: L("Swallowed food travels down the esophagus.", "የተዋጠ ምግብ በጉሮሮ ቱቦ ይወርዳል።"),
          },
        ],
      ),
      ch(
        "matter",
        [7, 8],
        L("States of matter", "የቁስ ሁኔታዎች"),
        L("Solid, liquid, and gas.", "ጠጣር፣ ፈሳሽ እና ጋዝ።"),
        [
          L(
            "Matter is anything that has mass and takes up space. A solid keeps its shape. A liquid flows and takes the shape of its container. A gas spreads out to fill the space it is in.",
            "ቁስ ክብደት ያለው እና ቦታ የሚይዝ ማንኛውም ነገር ነው። ጠጣር ቅርጹን ይጠብቃል። ፈሳሽ ይፈስሳል እና የዕቃውን ቅርጽ ይይዛል። ጋዝ ተዘርግቶ ባለበት ቦታ ይሞላል።",
          ),
          L(
            "Heating and cooling can change the state. Ice (solid water) melts into liquid water. Liquid water evaporates into vapor, a gas. Cooling can reverse these changes. The substance is still water; its state changed.",
            "ማሞቅ እና ማቀዝቀዝ ሁኔታውን ሊቀይር ይችላል። በረዶ (ጠጣር ውሃ) ወደ ፈሳሽ ይቀልጣል። ፈሳሽ ውሃ ወደ ትነት፣ ማለትም ጋዝ፣ ይለወጣል። ማቀዝቀዝ እነዚህን ሊመልስ ይችላል። ንጥረ ነገሩ አሁንም ውሃ ነው፣ ሁኔታው ተቀይሯል።",
          ),
        ],
        [
          {
            id: "mt1",
            prompt: L("Which state keeps its own shape?", "የራሱን ቅርጽ የሚጠብቀው የትኛው ሁኔታ ነው?"),
            choices: [L("Solid", "ጠጣር"), L("Liquid", "ፈሳሽ"), L("Gas", "ጋዝ"), L("None of them", "አንዳቸውም")],
            answer: 0,
            explain: L("A solid holds its shape. Liquids and gases do not.", "ጠጣር ቅርጹን ይይዛል።"),
          },
          {
            id: "mt2",
            prompt: L("Ice melting becomes:", "በረዶ ሲቀልጥ ይሆናል፦"),
            choices: [
              L("Liquid water", "ፈሳሽ ውሃ"),
              L("A new metal", "አዲስ ብረት"),
              L("Soil", "አፈር"),
              L("Wood", "እንጨት"),
            ],
            answer: 0,
            explain: L("Melting changes solid water to liquid water. It is still water.", "መቅለጥ ጠጣር ውሃን ወደ ፈሳሽ ይቀይራል።"),
          },
          {
            id: "mt3",
            prompt: L("A gas will:", "ጋዝ፦"),
            choices: [
              L("Spread to fill its space", "ባለበት ቦታ ይሞላል"),
              L("Always keep a box shape", "ሁልጊዜ የሳጥን ቅርጽ ይዞ ይቆያል"),
              L("Never move", "ፈጽሞ አይንቀሳቀስም"),
              L("Have no mass", "ክብደት የለውም"),
            ],
            answer: 0,
            explain: L("Gas particles spread through the space available.", "የጋዝ ቅንጣቶች ባለው ቦታ ይዘረጋሉ።"),
          },
        ],
      ),
    ],
  },
  {
    id: "social",
    title: L("Social studies", "ማኅበራዊ ጥናት"),
    blurb: L("Maps, communities, and Ethiopian places.", "ካርታ፣ ማኅበረሰብ እና የኢትዮጵያ ቦታዎች።"),
    icon: "map",
    chapters: [
      ch(
        "maps",
        [4, 5],
        L("Maps and directions", "ካርታ እና አቅጣጫ"),
        L("A map is a drawing of a place from above.", "ካርታ ቦታን ከላይ የሚያሳይ ሥዕል ነው።"),
        [
          L(
            "A map uses symbols. A key, or legend, tells you what the symbols mean. Most classroom maps put north at the top. If you know north, you can find east, south, and west.",
            "ካርታ ምልክቶችን ይጠቀማል። ቁልፉ (legend) ምልክቶቹ ምን ማለት እንደሆኑ ይነግርሃል። አብዛኛው የክፍል ካርታ ሰሜንን ወደ ላይ ያደርጋል። ሰሜንን ካወቅህ ምሥራቅ፣ ደቡብ እና ምዕራብ ታገኛለህ።",
          ),
          L(
            "Addis Ababa is the capital city of Ethiopia. A map of the country helps you see regions, rivers, and neighboring countries without traveling there first. The scale tells you how a distance on the map matches a distance on the ground.",
            "አዲስ አበባ የኢትዮጵያ ዋና ከተማ ናት። የአገሪቱ ካርታ ክልሎችን፣ ወንዞችን እና ጎረቤት አገሮችን ሳትጓዝ እንድታይ ይረዳሃል። መለኪያው በካርታው ላይ ያለ ርቀት በምድር ላይ ካለው ርቀት ጋር እንዴት እንደሚጣጣም ይነግራል።",
          ),
        ],
        [
          {
            id: "mp1",
            prompt: L("On most classroom maps, which direction is at the top?", "በአብዛኛው የክፍል ካርታ ላይ ወደ ላይ ያለው አቅጣጫ የትኛው ነው?"),
            choices: [L("North", "ሰሜን"), L("South", "ደቡብ"), L("East", "ምሥራቅ"), L("West", "ምዕራብ")],
            answer: 0,
            explain: L("North is usually placed at the top.", "ሰሜን ብዙ ጊዜ ወደ ላይ ይቀመጣል።"),
          },
          {
            id: "mp2",
            prompt: L("The capital city of Ethiopia is:", "የኢትዮጵያ ዋና ከተማ፦"),
            choices: [
              L("Addis Ababa", "አዲስ አበባ"),
              L("Nairobi", "ናይሮቢ"),
              L("Cairo", "ካይሮ"),
              L("Lagos", "ላጎስ"),
            ],
            answer: 0,
            explain: L("Addis Ababa is Ethiopia’s capital.", "አዲስ አበባ የኢትዮጵያ ዋና ከተማ ናት።"),
          },
          {
            id: "mp3",
            prompt: L("A map key helps you:", "የካርታ ቁልፍ የሚረዳህ፦"),
            choices: [
              L("Understand the symbols", "ምልክቶቹን ለመረዳት"),
              L("Write an exam", "ፈተና ለመጻፍ"),
              L("Count your age", "ዕድሜህን ለመቁጠር"),
              L("Boil water", "ውሃ ለማፍላት"),
            ],
            answer: 0,
            explain: L("The key explains what each symbol stands for.", "ቁልፉ እያንዳንዱ ምልክት ምን እንደሚወክል ያብራራል።"),
          },
        ],
      ),
      ch(
        "community",
        [5, 6, 7],
        L("Communities", "ማኅበረሰቦች"),
        L("People share work, language, and places.", "ሰዎች ሥራ፣ ቋንቋ እና ቦታ ይጋራሉ።"),
        [
          L(
            "A community is a group of people who share a place and help each other. Families, schools, markets, and religious places are parts of a community. Different communities in Ethiopia speak different languages and keep different festivals, and they still share one country.",
            "ማኅበረሰብ ቦታ የሚጋሩ እና የሚተጋገዙ ሰዎች ናቸው። ቤተሰብ፣ ትምህርት ቤት፣ ገበያ እና የእምነት ቦታዎች የማኅበረሰብ ክፍሎች ናቸው። በኢትዮጵያ ያሉ ማኅበረሰቦች የተለያዩ ቋንቋዎችን ይናገራሉ፣ የተለያዩ በዓላትንም ይጠብቃሉ፣ አንድ አገር ግን ይጋራሉ።",
          ),
          L(
            "Respect starts with listening. When a classmate explains a custom you do not share, you can ask a polite question instead of laughing. Learning one true detail about another community makes the map of your country fuller.",
            "አክብሮት በማዳመጥ ይጀምራል። የክፍል ጓደኛህ የማታውቀውን ልማድ ሲያብራራ ከመሳቅ ይልቅ ጨዋ ጥያቄ መጠየቅ ትችላለህ። ስለ ሌላ ማኅበረሰብ አንድ እውነተኛ ዝርዝር መማር የአገርህን ካርታ የበለጠ ያደርገዋል።",
          ),
        ],
        [
          {
            id: "cm1",
            prompt: L("A community is mainly:", "ማኅበረሰብ በዋናነት፦"),
            choices: [
              L("People who share a place and help each other", "ቦታ የሚጋሩ እና የሚተጋገዙ ሰዎች"),
              L("Only one building", "አንድ ሕንጻ ብቻ"),
              L("A kind of rock", "የድንጋይ ዓይነት"),
              L("A math sign", "የሒሳብ ምልክት"),
            ],
            answer: 0,
            explain: L("People, a shared place, and mutual help make a community.", "ሰዎች፣ የጋራ ቦታ እና መተጋገዝ ማኅበረሰብ ይሠራሉ።"),
          },
          {
            id: "cm2",
            prompt: L("Which is part of a school community?", "የትምህርት ቤት ማኅበረሰብ ክፍል የትኛው ነው?"),
            choices: [
              L("Students and teachers", "ተማሪዎች እና መምህራን"),
              L("A cloud only", "ደመና ብቻ"),
              L("A fraction", "ክፍልፋይ"),
              L("A verb tense", "የግስ ጊዜ"),
            ],
            answer: 0,
            explain: L("Students, teachers, and families form the school community.", "ተማሪዎች፣ መምህራን እና ቤተሰቦች የትምህርት ቤቱን ማኅበረሰብ ይሠራሉ።"),
          },
          {
            id: "cm3",
            prompt: L("A respectful response to a new custom is to:", "አዲስ ልማድ ሲያጋጥምህ አክብሮት ያለው ምላሽ፦"),
            choices: [
              L("Ask a polite question", "ጨዋ ጥያቄ መጠየቅ"),
              L("Laugh at it", "መሳቅበት"),
              L("Ignore the person", "ሰውየውን መተው"),
              L("Change their words", "ቃላቸውን መቀየር"),
            ],
            answer: 0,
            explain: L("Listening and a polite question show respect.", "ማዳመጥ እና ጨዋ ጥያቄ አክብሮት ያሳያሉ።"),
          },
        ],
      ),
      ch(
        "heritage",
        [6, 7, 8],
        L("Places in Ethiopian history", "በኢትዮጵያ ታሪክ ውስጥ ያሉ ቦታዎች"),
        L("Axum and Lalibela, in plain words.", "አክሱም እና ላሊበላ፣ በቀላል ቃላት።"),
        [
          L(
            "Axum was a powerful ancient kingdom in the north. Traders linked it to lands across the Red Sea. Tall stone stelae still stand there, and Ge'ez was an important written language of that world. Axum later became a center of Christianity in the region.",
            "አክሱም በሰሜን የነበረ ኃያል ጥንታዊ መንግሥት ነበር። ነጋዴዎች ከቀይ ባሕር ማዶ ካሉ አገሮች ጋር ያገናኙት ነበር። ረጃጅም የድንጋይ ሐውልቶች እስካሁን ቆመዋል፣ ግዕዝም የዚያ ዓለም አስፈላጊ የጽሑፍ ቋንቋ ነበር። አክሱም በኋላ በክልሉ የክርስትና ማዕከል ሆነ።",
          ),
          L(
            "Lalibela, in the highlands, is known for churches carved down into the rock during the Zagwe period, linked with King Lalibela. They were made by cutting stone away rather than by building walls upward. Both places are part of Ethiopia’s heritage and are cared for as historic sites.",
            "ላሊበላ በደጋ ላይ ትገኛለች፣ በዛጔው ዘመን በድንጋይ ውስጥ ለተፈለፈሉ አብያተ ክርስቲያናት ትታወቃለች፣ ከንጉሥ ላሊበላ ጋርም ትያያዛለች። ግድግዳ ወደ ላይ ከመሥራት ይልቅ ድንጋዩን በመቆፈር ተሠሩ። ሁለቱም ቦታዎች የኢትዮጵያ ቅርስ ናቸው።",
          ),
        ],
        [
          {
            id: "ht1",
            prompt: L("Axum is especially known for:", "አክሱም በተለይ የምትታወቀው በ፦"),
            choices: [
              L("Stone stelae and an ancient kingdom", "የድንጋይ ሐውልቶች እና ጥንታዊ መንግሥት"),
              L("Being a modern seaport in Kenya", "በኬንያ ዘመናዊ ወደብ በመሆን"),
              L("The source of the Nile in Egypt", "በግብጽ የናይል ምንጭ"),
              L("A desert with no history", "ታሪክ የሌለው በረሃ"),
            ],
            answer: 0,
            explain: L("Axum’s stelae and kingdom are central to its history.", "የአክሱም ሐውልቶች እና መንግሥት የታሪኳ ማዕከል ናቸው።"),
          },
          {
            id: "ht2",
            prompt: L("Lalibela’s famous churches were:", "የላሊበላ ታዋቂ አብያተ ክርስቲያናት፦"),
            choices: [
              L("Carved into rock", "በድንጋይ ተፈልፍለዋል"),
              L("Built of glass last year", "ባለፈው ዓመት ከመስታወት ተሠርተዋል"),
              L("Floating on a lake", "በሐይቅ ላይ ይንሳፈፋሉ"),
              L("Made only of paper", "ከወረቀት ብቻ"),
            ],
            answer: 0,
            explain: L("The churches were carved down into solid rock.", "አብያተ ክርስቲያናቱ በጠንካራ ድንጋይ ተፈልፍለዋል።"),
          },
          {
            id: "ht3",
            prompt: L("Ge'ez was:", "ግዕዝ፦"),
            choices: [
              L("An important written language of ancient Axum", "የጥንቷ አክሱም አስፈላጊ የጽሑፍ ቋንቋ"),
              L("A kind of rock", "የድንጋይ ዓይነት"),
              L("A river in West Africa", "በምዕራብ አፍሪካ ያለ ወንዝ"),
              L("A unit of length", "የርዝመት መለኪያ"),
            ],
            answer: 0,
            explain: L("Ge'ez was used for writing in the Axumite world and in the church.", "ግዕዝ በአክሱም ዓለም እና በቤተ ክርስቲያን ለጽሑፍ አገልግሏል።"),
          },
        ],
      ),
      ch(
        "horn",
        [7, 8],
        L("Ethiopia and its neighbors", "ኢትዮጵያ እና ጎረቤቶቿ"),
        L("A country sits among other countries.", "አገር ከሌሎች አገሮች መካከል ትገኛለች።"),
        [
          L(
            "Ethiopia is in the Horn of Africa. It shares borders with Eritrea, Djibouti, Somalia, Kenya, South Sudan, and Sudan. It does not have its own seacoast; Djibouti and other neighbors do. That is why ports in neighboring countries matter for trade.",
            "ኢትዮጵያ በአፍሪካ ቀንድ ትገኛለች። ከኤርትራ፣ ጅቡቲ፣ ሶማሊያ፣ ኬንያ፣ ደቡብ ሱዳን እና ሱዳን ጋር ትዋሰናለች። የራሷ የባሕር ዳርቻ የላትም። ስለዚህ በጎረቤት አገሮች ያሉ ወደቦች ለንግድ አስፈላጊ ናቸው።",
          ),
          L(
            "The Great Rift Valley runs through the region. Highlands are cooler, and lowlands are hotter. Rain does not fall the same way everywhere, so farming and daily life change from place to place. A map of neighbors plus a map of high and low land tells a fuller story than either map alone.",
            "ታላቁ ስምጥ ሸለቆ በክልሉ ያልፋል። ደጋዎች ቀዝቃዛ ናቸው፣ ቆላዎችም ሞቃት ናቸው። ዝናብ በሁሉም ቦታ አንድ ዓይነት አይዘንብም፣ ስለዚህ ግብርና እና ኑሮ ከቦታ ቦታ ይለያያል።",
          ),
        ],
        [
          {
            id: "hn1",
            prompt: L("Which country shares a border with Ethiopia?", "ከኢትዮጵያ ጋር የሚዋሰነው አገር የትኛው ነው?"),
            choices: [L("Kenya", "ኬንያ"), L("Ghana", "ጋና"), L("Morocco", "ሞሮኮ"), L("Madagascar", "ማዳጋስካር")],
            answer: 0,
            explain: L("Kenya is on Ethiopia’s southern border. The others are far away.", "ኬንያ በኢትዮጵያ ደቡብ ድንበር ትገኛለች።"),
          },
          {
            id: "hn2",
            prompt: L("Ethiopia’s own seacoast is:", "የኢትዮጵያ የራሷ የባሕር ዳርቻ፦"),
            choices: [
              L("None — it is landlocked", "የለም — በየብስ የተከበበች ናት"),
              L("Along the Atlantic", "በአትላንቲክ ላይ"),
              L("The whole Red Sea", "መላው ቀይ ባሕር"),
              L("The Mediterranean", "ሜድትራኒያን"),
            ],
            answer: 0,
            explain: L("Ethiopia is landlocked. Neighbors such as Djibouti have ports.", "ኢትዮጵያ በየብስ የተከበበች ናት።"),
          },
          {
            id: "hn3",
            prompt: L("Highlands are usually:", "ደጋዎች ብዙ ጊዜ፦"),
            choices: [
              L("Cooler than lowlands", "ከቆላዎች ይበልጥ ቀዝቃዛ"),
              L("Under the ocean", "ከውቅያኖስ በታች"),
              L("Always desert", "ሁልጊዜ በረሃ"),
              L("Outside Africa", "ከአፍሪካ ውጭ"),
            ],
            answer: 0,
            explain: L("Higher land is cooler. Lowlands are hotter.", "ከፍ ያለ መሬት ቀዝቃዛ ነው።"),
          },
        ],
      ),
    ],
  },
  {
    id: "civics",
    title: L("Civics", "ዜግነት"),
    blurb: L("Rights, honesty, and living together.", "መብቶች፣ ታማኝነት እና አብሮ መኖር።"),
    icon: "landmark",
    chapters: [
      ch(
        "school-rules",
        [4, 5, 6],
        L("Rights and duties at school", "በትምህርት ቤት መብት እና ግዴታ"),
        L("You have rights, and you have responsibilities.", "መብት አለህ፣ ግዴታም አለህ።"),
        [
          L(
            "At school you have the right to learn, to be safe, and to ask questions. A right is something others should respect. A responsibility is something you should do: come ready, listen, tell the truth, and take care of shared books and desks.",
            "በትምህርት ቤት የመማር፣ ደህንነት የማግኘት እና ጥያቄ የመጠየቅ መብት አለህ። መብት ሌሎች ሊያከብሩት የሚገባ ነገር ነው። ግዴታ አንተ ልታደርገው የሚገባ ነገር ነው፦ ተዘጋጅተህ መምጣት፣ ማዳመጥ፣ እውነት መናገር፣ የጋራ መጽሐፍትን እና ጠረጴዛዎችን መጠበቅ።",
          ),
          L(
            "Rights and duties go together. If everyone uses a right and nobody keeps a duty, the classroom becomes unfair. If you want a quiet place to read, you also help keep the place quiet for others.",
            "መብት እና ግዴታ አብረው ይሄዳሉ። ሁሉም መብት ብቻ ቢጠቀም እና ማንም ግዴታ ባይጠብቅ ክፍሉ ፍትሐዊ አይሆንም።",
          ),
        ],
        [
          {
            id: "sc1",
            prompt: L("Which is a right at school?", "በትምህርት ቤት መብት የትኛው ነው?"),
            choices: [
              L("To be safe", "ደህንነት ማግኘት"),
              L("To damage a shared book", "የጋራ መጽሐፍ ማበላሸት"),
              L("To stop others from learning", "ሌሎች እንዳይማሩ ማድረግ"),
              L("To hide the truth", "እውነትን መደበቅ"),
            ],
            answer: 0,
            explain: L("Safety is a right. Harming books or classmates is not.", "ደህንነት መብት ነው።"),
          },
          {
            id: "sc2",
            prompt: L("Which is a responsibility?", "ግዴታ የትኛው ነው?"),
            choices: [
              L("Telling the truth", "እውነት መናገር"),
              L("Taking someone’s pen", "የሰውን እስክሪብቶ መውሰድ"),
              L("Shouting over a lesson", "በትምህርት ላይ መጮህ"),
              L("Leaving litter on the desk", "ቆሻሻን በጠረጴዛው ላይ መተው"),
            ],
            answer: 0,
            explain: L("Honesty is a duty you owe the class.", "ታማኝነት ለክፍሉ ያለብህ ግዴታ ነው።"),
          },
          {
            id: "sc3",
            prompt: L("Rights and duties should:", "መብቶች እና ግዴታዎች፦"),
            choices: [
              L("Go together", "አብረው መሄድ አለባቸው"),
              L("Never be mentioned", "ፈጽሞ መጠቀስ የለባቸውም"),
              L("Belong only to teachers", "ለመምህራን ብቻ ናቸው"),
              L("Replace learning", "ትምህርትን ይተካሉ"),
            ],
            answer: 0,
            explain: L("Using a right well includes keeping the matching duty.", "መብትን በትክክል መጠቀም ተመጣጣኝ ግዴታን መጠበቅን ያካትታል።"),
          },
        ],
      ),
      ch(
        "honesty",
        [5, 6, 7, 8],
        L("Honesty", "ታማኝነት"),
        L("Truth makes a class fair.", "እውነት ክፍልን ፍትሐዊ ያደርጋል።"),
        [
          L(
            "Honesty means your words match what happened. If you forget homework, saying so is more honest than copying a friend’s page and pretending it is yours. Copying on a test is not a small trick. It hides what you still need to learn.",
            "ታማኝነት ማለት ቃልህ ከተከሰተው ነገር ጋር መጣጣም ነው። የቤት ሥራ ከረሳህ መናገር፣ የጓደኛህን ገጽ ገልብጠህ የራስህ አድርገህ ከማቅረብ ይሻላል። በፈተና ላይ መገልበጥ ትንሽ ተንኮል አይደለም። ገና ምን መማር እንዳለብህ ይደብቃል።",
          ),
          L(
            "Honesty also means returning what is not yours. A pen left on a desk still belongs to someone. Giving it to the teacher is a civic act, even when nobody is watching.",
            "ታማኝነት የራስህ ያልሆነውን መመለስንም ይጨምራል። በጠረጴዛ ላይ የቀረ እስክሪብቶ አሁንም የሰው ነው። ለመምህር ማስረከብ፣ ማንም ባያይም፣ የዜግነት ተግባር ነው።",
          ),
        ],
        [
          {
            id: "hnsty1",
            prompt: L("Copying a friend’s test answers is:", "የጓደኛህን የፈተና መልስ መገልበጥ፦"),
            choices: [
              L("Dishonest", "ታማኝ አይደለም"),
              L("Required", "ግዴታ ነው"),
              L("A right", "መብት ነው"),
              L("The same as studying", "ከመማር ጋር እኩል ነው"),
            ],
            answer: 0,
            explain: L("The work would not be yours, so it is dishonest.", "ሥራው የአንተ አይሆንም፣ ስለዚህ ታማኝ አይደለም።"),
          },
          {
            id: "hnsty2",
            prompt: L("You find a pen that is not yours. The honest act is to:", "የራስህ ያልሆነ እስክሪብቶ ካገኘህ ታማኝ ተግባር፦"),
            choices: [
              L("Give it to the teacher", "ለመምህር አስረክብ"),
              L("Hide it", "ደብቀው"),
              L("Sell it", "ሽጠው"),
              L("Break it", "ስበረው"),
            ],
            answer: 0,
            explain: L("Returning lost property respects the owner.", "የጠፋን ንብረት መመለስ ባለቤቱን ያከብራል።"),
          },
          {
            id: "hnsty3",
            prompt: L("Honesty helps a teacher to:", "ታማኝነት መምህርን የሚረዳው፦"),
            choices: [
              L("See what you still need to learn", "ገና ምን መማር እንዳለብህ ለማየት"),
              L("Ignore the class", "ክፍሉን ለመተው"),
              L("Hide the lesson", "ትምህርቱን ለመደበቅ"),
              L("Skip grading", "ውጤት ላለመስጠት"),
            ],
            answer: 0,
            explain: L("True work shows the real next step.", "እውነተኛ ሥራ ቀጣዩን እውነተኛ ደረጃ ያሳያል።"),
          },
        ],
      ),
      ch(
        "together",
        [6, 7, 8],
        L("Deciding together", "አብሮ መወሰን"),
        L("Fair rules and a chance to speak.", "ፍትሐዊ ደንብ እና የመናገር እድል።"),
        [
          L(
            "A simple democratic habit is this: people affected by a choice get a chance to speak, and the same rules apply to everyone. A class choosing a project can list ideas, listen, and vote. The vote does not insult the people who lost. It is a way to decide.",
            "ቀላል ዴሞክራሲያዊ ልማድ ይህ ነው፦ በውሳኔው የሚነኩ ሰዎች የመናገር እድል ያገኛሉ፣ ተመሳሳይ ደንብም ለሁሉም ይሠራል። ክፍል ፕሮጀክት ሲመርጥ ሐሳቦችን መዘርዘር፣ ማዳመጥ እና መምረጥ ይችላል።",
          ),
          L(
            "Majority is not a license to harm. A vote cannot take away someone’s safety or right to learn. Rules that protect those rights stand above a sudden wish of the crowd.",
            "ብዛት ለመጉዳት ፈቃድ አይደለም። ድምጽ የሰውን ደህንነት ወይም የመማር መብት ሊነጥቅ አይችልም። እነዚህን መብቶች የሚጠብቁ ደንቦች ከድንገተኛ ፍላጎት በላይ ናቸው።",
          ),
        ],
        [
          {
            id: "tg1",
            prompt: L("A fair class vote should:", "ፍትሐዊ የክፍል ምርጫ፦"),
            choices: [
              L("Give people a chance to speak", "ለሰዎች የመናገር እድል ይስጥ"),
              L("Let only one student talk", "አንድ ተማሪ ብቻ እንዲናገር"),
              L("Change the rules for friends", "ለጓደኞች ደንቡን ይቀይር"),
              L("Hide the choices", "ምርጫዎቹን ይደብቅ"),
            ],
            answer: 0,
            explain: L("Speaking and shared rules make the decision fairer.", "መናገር እና የጋራ ደንብ ውሳኔውን ፍትሐዊ ያደርጉታል።"),
          },
          {
            id: "tg2",
            prompt: L("A vote must not:", "ድምጽ የማይገባው፦"),
            choices: [
              L("Remove someone’s right to be safe", "የሰውን የደህንነት መብት መንሳት"),
              L("Choose a class project", "የክፍል ፕሮጀክት መምረጥ"),
              L("Follow the same rule for all", "ለሁሉም አንድ ደንብ መከተል"),
              L("End after people have spoken", "ሰዎች ከተናገሩ በኋላ መጠናቀቅ"),
            ],
            answer: 0,
            explain: L("Safety is a right a majority cannot vote away.", "ደህንነት ብዛት ሊያስወግደው የማይችል መብት ነው።"),
          },
          {
            id: "tg3",
            prompt: L("The same rule for everyone means:", "ለሁሉም አንድ ደንብ ማለት፦"),
            choices: [
              L("Friends do not get a secret exception", "ጓደኞች ሚስጥራዊ ልዩነት አያገኙም"),
              L("Rules change every minute", "ደንቦች በየደቂቃው ይቀየራሉ"),
              L("Only older students must follow rules", "ታላላቅ ተማሪዎች ብቻ ደንብ ይከተላሉ"),
              L("There are no rules", "ደንብ የለም"),
            ],
            answer: 0,
            explain: L("Equal rules are part of fairness.", "እኩል ደንብ የፍትሕ ክፍል ነው።"),
          },
        ],
      ),
      ch(
        "environment",
        [7, 8],
        L("Citizens and the environment", "ዜጎች እና አካባቢ"),
        L("Shared land needs shared care.", "የጋራ መሬት የጋራ እንክብካቤ ይፈልጋል።"),
        [
          L(
            "Air, rivers, and school grounds are shared. One person throwing waste into a river affects people downstream. A citizen’s duty is not only to avoid harm, but to leave a shared place usable for the next person.",
            "አየር፣ ወንዞች እና የትምህርት ቤት ግቢ የጋራ ናቸው። አንድ ሰው ቆሻሻን ወደ ወንዝ መጣል ከታች ያሉ ሰዎችን ይጎዳል። የዜጋ ግዴታ ጉዳት ከመከልከል ብቻ አይደለም፣ ቦታውን ለቀጣዩ ሰው ጠቃሚ ማድረግም ነው።",
          ),
          L(
            "Small acts add up: putting litter in a bin, not wasting water, and planting or protecting a tree at school. These are not extra credit. They are part of living with other people on the same land.",
            "ትናንሽ ተግባሮች ይደመራሉ፦ ቆሻሻን በሳጥን ማስገባት፣ ውሃ አለማባከን፣ በትምህርት ቤት ዛፍ መትከል ወይም መጠበቅ። እነዚህ ተጨማሪ ነጥብ ብቻ አይደሉም። ከሌሎች ሰዎች ጋር በአንድ መሬት የመኖር ክፍል ናቸው።",
          ),
        ],
        [
          {
            id: "ev1",
            prompt: L("Throwing waste in a river harms:", "ቆሻሻን ወደ ወንዝ መጣል የሚጎዳው፦"),
            choices: [
              L("People who use the water later", "ውሃውን በኋላ የሚጠቀሙ ሰዎች"),
              L("Nobody", "ማንም"),
              L("Only the person who threw it, and nobody else", "የጣለውን ሰው ብቻ"),
              L("The idea of fractions", "የክፍልፋይ ሐሳብ"),
            ],
            answer: 0,
            explain: L("A river is shared. Waste travels downstream.", "ወንዝ የጋራ ነው። ቆሻሻው ወደ ታች ይጓዛል።"),
          },
          {
            id: "ev2",
            prompt: L("Which act cares for a shared place?", "የጋራ ቦታን የሚጠብቅ ተግባር የትኛው ነው?"),
            choices: [
              L("Putting litter in a bin", "ቆሻሻን በሳጥን ማስገባት"),
              L("Leaving food on the desk", "ምግብን በጠረጴዛው ላይ መተው"),
              L("Wasting a full tank of water", "ሙሉ ውሃ ማባከን"),
              L("Breaking a young tree", "ትንሽ ዛፍ መስበር"),
            ],
            answer: 0,
            explain: L("A bin keeps waste out of the shared ground and water.", "ሳጥን ቆሻሻን ከጋራ ቦታ ይርቃል።"),
          },
          {
            id: "ev3",
            prompt: L("Caring for the environment is:", "አካባቢን መጠበቅ፦"),
            choices: [
              L("Part of living with other people", "ከሌሎች ሰዎች ጋር የመኖር ክፍል"),
              L("Only a game", "ጨዋታ ብቻ"),
              L("Impossible for students", "ለተማሪዎች የማይቻል"),
              L("Against school rules", "የትምህርት ቤት ደንብ ተቃራኒ"),
            ],
            answer: 0,
            explain: L("Shared land needs everyday civic care.", "የጋራ መሬት የዕለት ተዕለት የዜግነት እንክብካቤ ይፈልጋል።"),
          },
        ],
      ),
    ],
  },
];

export const exams: Exam[] = [
  {
    id: "grade-6",
    grade: 6,
    title: L("Grade 6 practice exam", "የ6ኛ ክፍል የልምምድ ፈተና"),
    minutes: 30,
    questions: [
      {
        id: "g6q1",
        prompt: L("What is 1/2 + 1/4?", "1/2 + 1/4 ስንት ነው?"),
        choices: [L("1/6", "1/6"), L("2/6", "2/6"), L("3/4", "3/4"), L("2/4", "2/4")],
        answer: 2,
        explain: L("1/2 = 2/4, and 2/4 + 1/4 = 3/4.", "1/2 = 2/4፣ 2/4 + 1/4 = 3/4።"),
      },
      {
        id: "g6q2",
        prompt: L("What is 10% of 80?", "የ80 10% ስንት ነው?"),
        choices: [L("8", "8"), L("10", "10"), L("18", "18"), L("70", "70")],
        answer: 0,
        explain: L("10% means divide by 10. 80 ÷ 10 = 8.", "10% ማለት ለ10 ማካፈል ነው።"),
      },
      {
        id: "g6q3",
        prompt: L("Choose the past-tense sentence.", "ያለፈ ጊዜ ያለውን ዓረፍተ ነገር ምረጥ።"),
        choices: [
          L("She goes to the market every day.", "She goes to the market every day."),
          L("Yesterday she went to the market.", "Yesterday she went to the market."),
          L("She going to the market.", "She going to the market."),
          L("She go yesterday.", "She go yesterday."),
        ],
        answer: 1,
        explain: L("Yesterday and went mark a finished action.", "Yesterday እና went ያለፈ ተግባርን ያሳያሉ።"),
      },
      {
        id: "g6q4",
        prompt: L("Which word is a verb?", "የትኛው ቃል ግስ ነው?"),
        choices: [L("ደብተር", "ደብተር"), L("ያነባል", "ያነባል"), L("ተማሪ", "ተማሪ"), L("ቤት", "ቤት")],
        answer: 1,
        explain: L("ያነባል is an action. The others are nouns.", "ያነባል ተግባር ነው። ሌሎቹ ስሞች ናቸው።"),
      },
      {
        id: "g6q5",
        prompt: L("Clouds form when water vapor cools and becomes drops. This is:", "ደመና የሚሠራው የውሃ ትነት ቀዝቅዞ ጠብታ ሲሆን ነው። ይህ፦"),
        choices: [
          L("Condensation", "መከማቸት"),
          L("A habitat", "መኖሪያ"),
          L("A fraction", "ክፍልፋይ"),
          L("A border", "ድንበር"),
        ],
        answer: 0,
        explain: L("Cooling vapor into drops is condensation.", "ትነት ቀዝቅዞ ጠብታ መሆን መከማቸት ነው።"),
      },
      {
        id: "g6q6",
        prompt: L("Digestion begins in the:", "መፈጨት የሚጀምረው በ፦"),
        choices: [L("Mouth", "አፍ"), L("Heart", "ልብ"), L("Knee", "ጉልበት"), L("Hair", "ፀጉር")],
        answer: 0,
        explain: L("Teeth and saliva start digestion in the mouth.", "ጥርስ እና ምራቅ መፈጨትን በአፍ ይጀምራሉ።"),
      },
      {
        id: "g6q7",
        prompt: L("The capital of Ethiopia is:", "የኢትዮጵያ ዋና ከተማ፦"),
        choices: [L("Addis Ababa", "አዲስ አበባ"), L("Axum only in ancient times and nowhere now", "አክሱም ብቻ"), L("Lalibela", "ላሊበላ"), L("Dire Dawa", "ድሬዳዋ")],
        answer: 0,
        explain: L("Addis Ababa is the capital city.", "አዲስ አበባ ዋና ከተማ ናት።"),
      },
      {
        id: "g6q8",
        prompt: L("Lalibela is known for churches that were:", "ላሊበላ የምትታወቀው አብያተ ክርስቲያናት በመሆን ነው፣ እነሱም፦"),
        choices: [
          L("Carved into rock", "በድንጋይ የተፈለፈሉ"),
          L("Built last year from plastic", "ባለፈው ዓመት ከፕላስቲክ"),
          L("Located in Ghana", "በጋና ያሉ"),
          L("Made of paper", "ከወረቀት"),
        ],
        answer: 0,
        explain: L("The churches are rock-hewn.", "አብያተ ክርስቲያናቱ በድንጋይ ተፈልፍለዋል።"),
      },
      {
        id: "g6q9",
        prompt: L("Which act is honest?", "ታማኝ ተግባር የትኛው ነው?"),
        choices: [
          L("Saying you forgot the homework", "የቤት ሥራውን መርሳትህን መናገር"),
          L("Copying a friend’s test", "የጓደኛህን ፈተና መገልበጥ"),
          L("Hiding a found pen", "ያገኘኸውን እስክሪብቶ መደበቅ"),
          L("Putting your name on someone else’s work", "ስምህን በሌላ ሰው ሥራ ላይ ማድረግ"),
        ],
        answer: 0,
        explain: L("Matching your words to what happened is honesty.", "ቃልህ ከተከሰተው ጋር መጣጣም ታማኝነት ነው።"),
      },
      {
        id: "g6q10",
        prompt: L("On a classroom map, north is usually:", "በክፍል ካርታ ላይ ሰሜን ብዙ ጊዜ፦"),
        choices: [L("At the top", "ወደ ላይ"), L("At the bottom", "ወደ ታች"), L("Missing", "የለም"), L("In the key only as a color of water", "የውሃ ቀለም ብቻ")],
        answer: 0,
        explain: L("North is placed at the top on most school maps.", "ሰሜን በአብዛኛው ወደ ላይ ነው።"),
      },
    ],
  },
  {
    id: "grade-8",
    grade: 8,
    title: L("Grade 8 practice exam", "የ8ኛ ክፍል የልምምድ ፈተና"),
    minutes: 40,
    questions: [
      {
        id: "g8q1",
        prompt: L("Solve 2x + 3 = 11.", "2x + 3 = 11 ን ፍታ።"),
        choices: [L("x = 4", "x = 4"), L("x = 7", "x = 7"), L("x = 11", "x = 11"), L("x = 3", "x = 3")],
        answer: 0,
        explain: L("2x = 8, so x = 4.", "2x = 8፣ ስለዚህ x = 4።"),
      },
      {
        id: "g8q2",
        prompt: L("A shirt costs 200 birr. It is discounted by 20%. What do you pay?", "ሸሚዝ 200 ብር ነው። ቅናሹ 20% ነው። ስንት ትከፍላለህ?"),
        choices: [L("160 birr", "160 ብር"), L("180 birr", "180 ብር"), L("40 birr", "40 ብር"), L("220 birr", "220 ብር")],
        answer: 0,
        explain: L("20% of 200 is 40. 200 − 40 = 160.", "የ200 20% 40 ነው። 200 − 40 = 160።"),
      },
      {
        id: "g8q3",
        prompt: L("What is −3 + 7?", "−3 + 7 ስንት ነው?"),
        choices: [L("4", "4"), L("−10", "−10"), L("10", "10"), L("−4", "−4")],
        answer: 0,
        explain: L("From −3, move 7 steps toward the positives. You land on 4.", "ከ−3 ሰባት ደረጃ ወደ አወንታዊ ትሄዳለህ፣ 4 ላይ ትደርሳለህ።"),
      },
      {
        id: "g8q4",
        prompt: L(
          "“Abel shut his book and looked at the clock.” Which inference stays closest to the text?",
          "“Abel shut his book and looked at the clock.” ወደ ጽሑፉ ቅርብ የሆነው ግምት የትኛው ነው?",
        ),
        choices: [
          L("He is noticing the time", "ጊዜውን እያየ ነው"),
          L("He has moved to another country", "ወደ ሌላ አገር ሄዷል"),
          L("The book is about chemistry only", "መጽሐፉ ስለ ኬሚስትሪ ብቻ ነው"),
          L("He failed every subject", "ሁሉንም ትምህርት ወድቋል"),
        ],
        answer: 0,
        explain: L("Looking at the clock supports noticing the time. The other claims are not suggested.", "ሰዓቱን ማየት ጊዜ መመልከትን ይደግፋል።"),
      },
      {
        id: "g8q5",
        prompt: L("Which pair is an opinion plus a reason?", "አስተያየት እና ምክንያት የሆነው ጥንድ የትኛው ነው?"),
        choices: [
          L(
            "የቤተ መጻሕፍት ጊዜ ይጠቅማል፣ ምክንያቱም አዲስ ቃላት እንማራለን።",
            "የቤተ መጻሕፍት ጊዜ ይጠቅማል፣ ምክንያቱም አዲስ ቃላት እንማራለን።",
          ),
          L("ጥሩ ነው። ጥሩ ነው።", "ጥሩ ነው። ጥሩ ነው።"),
          L("መጽሐፍ።", "መጽሐፍ።"),
          L("ለምን? ለምን?", "ለምን? ለምን?"),
        ],
        answer: 0,
        explain: L("The second clause answers why.", "ሁለተኛው ክፍል ለምን የሚለውን ይመልሳል።"),
      },
      {
        id: "g8q6",
        prompt: L("Most nutrients enter the blood from the:", "አብዛኛው ንጥረ ነገር ወደ ደም የሚገባው ከ፦"),
        choices: [L("Small intestine", "ትንሹ አንጀት"), L("Skull", "የራስ ቅል"), L("Hair", "ፀጉር"), L("Fingernail", "ጥፍር")],
        answer: 0,
        explain: L("The small intestine absorbs most nutrients.", "ትንሹ አንጀት አብዛኛውን ንጥረ ነገር ይቀበላል።"),
      },
      {
        id: "g8q7",
        prompt: L("Melting changes ice into:", "መቅለጥ በረዶን ይቀይረዋል ወደ፦"),
        choices: [L("Liquid water", "ፈሳሽ ውሃ"), L("Iron", "ብረት"), L("Soil", "አፈር"), L("A new element that is not water", "ውሃ ያልሆነ አዲስ ንጥረ ነገር")],
        answer: 0,
        explain: L("The state changes. The substance is still water.", "ሁኔታው ይቀየራል። ንጥረ ነገሩ ግን ውሃ ነው።"),
      },
      {
        id: "g8q8",
        prompt: L("Which statement about Ethiopia is correct?", "ስለ ኢትዮጵያ ትክክለኛው የትኛው ነው?"),
        choices: [
          L("It is landlocked in the Horn of Africa", "በአፍሪካ ቀንድ በየብስ የተከበበች ናት"),
          L("It borders Ghana", "ከጋና ጋር ትዋሰናለች"),
          L("Its capital is Nairobi", "ዋና ከተማዋ ናይሮቢ ናት"),
          L("It lies in South America", "በደቡብ አሜሪካ ትገኛለች"),
        ],
        answer: 0,
        explain: L("Ethiopia is landlocked in the Horn of Africa.", "ኢትዮጵያ በአፍሪካ ቀንድ በየብስ የተከበበች ናት።"),
      },
      {
        id: "g8q9",
        prompt: L("A fair vote in class still cannot:", "ፍትሐዊ የክፍል ድምጽ አሁንም የማይችለው፦"),
        choices: [
          L("Take away someone’s safety", "የሰውን ደህንነት መንሳት"),
          L("Choose between two projects", "በሁለት ፕሮጀክቶች መካከል መምረጥ"),
          L("Use the same rule for everyone", "ለሁሉም አንድ ደንብ መጠቀም"),
          L("Let people speak first", "ሰዎች መጀመሪያ እንዲናገሩ መፍቀድ"),
        ],
        answer: 0,
        explain: L("Basic safety is not something a majority may remove.", "መሠረታዊ ደህንነት ብዛት ሊያስወግደው አይገባም።"),
      },
      {
        id: "g8q10",
        prompt: L("Axum’s stone stelae are best described as:", "የአክሱም የድንጋይ ሐውልቶች በተሻለ የሚገለጹት፦"),
        choices: [
          L("Historic monuments of an ancient kingdom", "የጥንታዊ መንግሥት ታሪካዊ ሐውልቶች"),
          L("Modern apartment blocks", "ዘመናዊ አፓርታማዎች"),
          L("A river system", "የወንዝ ሥርዓት"),
          L("A kind of cloud", "የደመና ዓይነት"),
        ],
        answer: 0,
        explain: L("The stelae belong to ancient Axum’s heritage.", "ሐውልቶቹ የጥንቷ አክሱም ቅርስ ናቸው።"),
      },
    ],
  },
];

export function lessonItemId(subjectId: string, chapterId: string) {
  return `${subjectId}/${chapterId}`;
}

export function quizItemId(subjectId: string, chapterId: string) {
  return `${subjectId}/${chapterId}#quiz`;
}

export function findSubject(id: string) {
  return subjects.find((subject) => subject.id === id) ?? null;
}

export function findChapter(subjectId: string, chapterId: string) {
  const subject = findSubject(subjectId);
  const chapter = subject?.chapters.find((item) => item.id === chapterId) ?? null;
  return { subject, chapter };
}

export function chaptersForGrade(subject: Subject, grade: number) {
  return subject.chapters.filter((chapter) => chapter.grades.includes(grade));
}

export function findExam(id: string) {
  return exams.find((exam) => exam.id === id) ?? null;
}

export function visibleSubjects(grade: number) {
  return subjects
    .map((subject) => ({ subject, chapters: chaptersForGrade(subject, grade) }))
    .filter((item) => item.chapters.length > 0);
}
