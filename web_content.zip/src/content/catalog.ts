import type { DhikrList, LibraryBook, Surah, SurahMeta } from "./types";
import quranMetaJson from "./generated/quran-meta.json";
import adhkarJson from "./generated/adhkar.json";
import libraryJson from "./generated/library.json";

export const quranMeta = quranMetaJson as {
  surahs: SurahMeta[];
  source: { name: string; publisher: string; via: string; note: string };
};

export const adhkarData = adhkarJson as {
  source: { name: string; author: string; via: string };
  lists: DhikrList[];
};

export const libraryData = libraryJson as { books: LibraryBook[] };

export const adhkarLists = adhkarData.lists;
export const libraryBooks = libraryData.books;

export function getList(id: string): DhikrList | undefined {
  return adhkarLists.find((l) => l.id === id);
}

export function getBook(id: string): LibraryBook | undefined {
  return libraryBooks.find((b) => b.id === id);
}

export function getSurahMeta(id: number): SurahMeta | undefined {
  return quranMeta.surahs.find((s) => s.id === id);
}

let quranCache: Surah[] | null = null;

export async function loadQuran(): Promise<Surah[]> {
  if (quranCache) return quranCache;
  const mod = await import("./generated/quran.json");
  const data = mod as { default?: { surahs: Surah[] }; surahs?: Surah[] };
  quranCache = data.surahs ?? data.default?.surahs ?? [];
  return quranCache;
}

export async function loadSurah(id: number): Promise<Surah | undefined> {
  const all = await loadQuran();
  return all.find((s) => s.id === id);
}

export type TafsirAyah = { n: number; t: string };

const tafsirMem = new Map<number, TafsirAyah[]>();

export async function loadTafsir(surahId: number): Promise<TafsirAyah[]> {
  const hit = tafsirMem.get(surahId);
  if (hit) return hit;
  const res = await fetch(`/content/tafsir/${String(surahId).padStart(3, "0")}.json`);
  if (!res.ok) throw new Error("تعذر تحميل التفسير");
  const data = (await res.json()) as { ayahs: TafsirAyah[] };
  tafsirMem.set(surahId, data.ayahs);
  return data.ayahs;
}

export const CATEGORY_LABEL: Record<LibraryBook["category"], string> = {
  hadith: "الحديث",
  aqeedah: "العقيدة",
  fiqh: "الفقه",
  tajweed: "التجويد",
};

export const ADHKAR_GROUPS = [
  {
    id: "adhkar",
    title: "الأذكار",
    ids: ["morning", "evening", "after-prayer", "sleep", "wakeup", "travel", "food", "general"],
  },
  {
    id: "duas",
    title: "الأدعية",
    ids: [
      "dua-quran",
      "dua-sunnah",
      "dua-sick",
      "dua-travel",
      "dua-distress",
      "dua-rizq",
      "dua-parents",
      "dua-misc",
    ],
  },
] as const;
