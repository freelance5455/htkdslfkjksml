# Digital Diary Pro — Android project

This is the Android Studio project for the Simple Digital Diary Pro prototype.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on an Android phone.

The diary UI is bundled as an offline asset and stores notes in local browser storage inside the app WebView.
