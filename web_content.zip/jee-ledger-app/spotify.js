/* Spotify for the installed app.
   Sign in with PKCE (no server needed) and play through the Web Playback SDK.
   Spotify Premium is required for in-app playback. */
(function(){
  'use strict';
  var SCOPES='streaming user-read-email user-read-private user-read-playback-state user-modify-playback-state';
  var MOODQ=['deep focus','rain piano study','lofi night study','morning focus instrumental'];
  var K_CLIENT='jee-sp-client',K_TOK='jee-sp-tok',K_VER='jee-sp-ver';
  var S={tok:null,player:null,dev:null,paused:true,track:null,ready:false,sdk:false,err:'',busy:false};

  function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){}return null}
  function $(s){return document.querySelector(s)}
  function esc(t){return String(t).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function redirectUri(){return location.origin+location.pathname}
  function clientId(){return (ls(K_CLIENT)||'').trim()}
  function rand(n){var a=new Uint8Array(n);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(b){return ('0'+b.toString(16)).slice(-2)}).join('')}
  function b64u(buf){var s='',b=new Uint8Array(buf);for(var i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
  function sha256(t){return crypto.subtle.digest('SHA-256',new TextEncoder().encode(t))}
  function saved(){try{return JSON.parse(ls(K_TOK)||'null')}catch(e){return null}}
  function connected(){return !!saved()}

  /* sign in */
  function login(){
    var id=clientId();
    if(!id){S.err='Paste your Spotify Client ID first.';ui();return}
    var ver=rand(48);ls(K_VER,ver);
    sha256(ver).then(function(h){
      var q=new URLSearchParams({response_type:'code',client_id:id,scope:SCOPES,redirect_uri:redirectUri(),code_challenge_method:'S256',code_challenge:b64u(h)});
      location.href='https://accounts.spotify.com/authorize?'+q.toString();
    });
  }
  function tokenReq(body){
    return fetch('https://accounts.spotify.com/api/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(body).toString()})
      .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error_description||j.error||'Sign-in failed');return j})});
  }
  function store(j,old){
    var t={tok:j.access_token,exp:Date.now()+(j.expires_in||3600)*1000,ref:j.refresh_token||(old&&old.ref)||''};
    ls(K_TOK,JSON.stringify(t));return t;
  }
  function token(){
    var t=saved();if(!t)return Promise.reject(new Error('Not connected'));
    if(Date.now()<t.exp-60000)return Promise.resolve(t.tok);
    return tokenReq({grant_type:'refresh_token',refresh_token:t.ref,client_id:clientId()}).then(function(j){return store(j,t).tok});
  }
  function finishLogin(){
    var p=new URLSearchParams(location.search);
    if(p.get('error')){S.err='Spotify said: '+p.get('error');history.replaceState(null,'',redirectUri()+'#study');location.hash='#study';return Promise.resolve()}
    var code=p.get('code');if(!code)return Promise.resolve();
    var ver=ls(K_VER);
    return tokenReq({grant_type:'authorization_code',code:code,redirect_uri:redirectUri(),client_id:clientId(),code_verifier:ver||''})
      .then(function(j){store(j);ls(K_VER,null)})
      .catch(function(e){S.err=e.message})
      .then(function(){history.replaceState(null,'',redirectUri()+'#study');location.hash='#study';ui()});
  }
  function logout(){
    if(S.player){try{S.player.disconnect()}catch(e){}}
    S.player=null;S.dev=null;S.ready=false;S.track=null;S.paused=true;S.sdk=false;
    ls(K_TOK,null);S.err='';ui();
  }

  /* api */
  function api(path,opt){
    return token().then(function(t){
      var o=opt||{};o.headers={'Authorization':'Bearer '+t,'Content-Type':'application/json'};
      return fetch('https://api.spotify.com/v1'+path,o);
    }).then(function(r){
      if(r.status===204)return null;
      return r.text().then(function(x){var j=x?JSON.parse(x):null;if(!r.ok)throw new Error((j&&j.error&&j.error.message)||('Spotify error '+r.status));return j});
    });
  }

  /* player */
  function loadSdk(){
    if(S.sdk||!connected())return;
    S.sdk=true;
    window.onSpotifyWebPlaybackSDKReady=initPlayer;
    var s=document.createElement('script');s.src='https://sdk.scdn.co/spotify-player.js';s.async=true;
    s.onerror=function(){S.err='Could not load the Spotify player. Check your connection.';S.sdk=false;ui()};
    document.head.appendChild(s);
  }
  function initPlayer(){
    var p=new window.Spotify.Player({name:'JEE Ledger',getOAuthToken:function(cb){token().then(cb).catch(function(){logout()})},volume:.7});
    p.addListener('ready',function(e){S.dev=e.device_id;S.ready=true;S.err='';ui()});
    p.addListener('not_ready',function(){S.ready=false;ui()});
    p.addListener('player_state_changed',function(st){
      if(!st)return;
      S.paused=st.paused;S.track=st.track_window&&st.track_window.current_track;ui();
    });
    p.addListener('account_error',function(){S.err='Spotify Premium is needed to play inside the app.';ui()});
    ['initialization_error','authentication_error','playback_error'].forEach(function(ev){p.addListener(ev,function(e){S.err=e.message||'Playback error';ui()})});
    p.connect();S.player=p;
  }
  function playMood(i){
    if(!S.dev)return Promise.resolve();
    var q=MOODQ[((i%MOODQ.length)+MOODQ.length)%MOODQ.length];
    S.err='';
    return api('/search?type=playlist&limit=8&q='+encodeURIComponent(q)).then(function(r){
      var items=(r&&r.playlists&&r.playlists.items||[]).filter(Boolean);
      if(items.length)return api('/me/player/play?device_id='+S.dev,{method:'PUT',body:JSON.stringify({context_uri:items[0].uri})});
      return api('/search?type=track&limit=20&q='+encodeURIComponent(q)).then(function(t){
        var u=(t&&t.tracks&&t.tracks.items||[]).filter(Boolean).map(function(x){return x.uri});
        if(!u.length)throw new Error('Nothing found for that mood.');
        return api('/me/player/play?device_id='+S.dev,{method:'PUT',body:JSON.stringify({uris:u})});
      });
    }).catch(function(e){S.err=e.message;ui()});
  }
  function toggle(){
    if(!S.player)return;
    var amb=document.querySelector('#music.on');if(amb)amb.click();
    S.player.activateElement&&S.player.activateElement();
    S.player.getCurrentState().then(function(st){
      if(!st){return api('/me/player',{method:'PUT',body:JSON.stringify({device_ids:[S.dev],play:false})}).then(function(){return playMood(window.PL?window.PL.i:0)})}
      return S.player.togglePlay();
    }).catch(function(e){S.err=e.message;ui()});
  }

  /* interface inside the player card */
  function ui(){
    var box=$('#sp-box'),pl=$('#player');
    if(pl)pl.classList.toggle('on',S.ready&&!S.paused);
    if(!box)return;
    var h='';
    if(!connected()){
      var id=clientId();
      if(!id){
        h+='<p><b>Connect Spotify</b></p><p>Create an app at developer.spotify.com, add this redirect URI, then paste its Client ID.</p><p><code>'+esc(redirectUri())+'</code></p>';
        h+='<div class="row"><input class="in" id="sp-id" type="text" placeholder="Client ID" aria-label="Spotify Client ID" autocomplete="off"><button type="button" class="btn ghost" data-sp="save">Save</button></div>';
      }else{
        h+='<p><b>Connect Spotify</b></p><p>Sign in to play your music here. Spotify Premium is needed.</p><div class="row"><button type="button" class="btn" data-sp="login">Connect Spotify</button><button type="button" class="btn ghost" data-sp="clear">Change Client ID</button></div>';
      }
    }else{
      if(S.track){
        var im=S.track.album&&S.track.album.images&&S.track.album.images[0];
        h+='<div class="spnow">'+(im?'<img src="'+esc(im.url)+'" alt="">':'')+'<div><b>'+esc(S.track.name)+'</b><span>'+esc((S.track.artists||[]).map(function(a){return a.name}).join(', '))+'</span></div></div>';
      }else{
        h+='<p>'+(S.ready?'<b>Spotify connected.</b> Press play to start the '+esc(window.MOODS?window.MOODS[window.PL.i].n:'current')+' mood.':'Starting the Spotify player…')+'</p>';
      }
      h+='<div class="row"><button type="button" class="btn ghost" data-sp="out">Disconnect</button></div>';
    }
    if(S.err)h+='<p role="alert">'+esc(S.err)+'</p>';
    box.innerHTML=h;
  }
  function mount(){
    var note=document.querySelector('#player .pfoot p');
    if(note)note.textContent='Sign in with Spotify to play here. Without it, the built-in ambient loop plays.';
    ui();
    if(connected())loadSdk();
  }
  document.addEventListener('click',function(e){
    var b=e.target.closest&&e.target.closest('[data-sp]');if(!b)return;
    var a=b.getAttribute('data-sp');
    if(a==='save'){var v=($('#sp-id').value||'').trim();if(!/^[a-z0-9]{20,40}$/i.test(v)){S.err='That does not look like a Client ID.';ui();return}ls(K_CLIENT,v);S.err='';ui()}
    else if(a==='login')login();
    else if(a==='clear'){ls(K_CLIENT,null);ui()}
    else if(a==='out')logout();
  });

  window.SPOTIFY={
    mount:mount,
    connected:connected,
    active:function(){return connected()&&S.ready},
    playing:function(){return S.ready&&!S.paused},
    toggle:toggle,
    mood:playMood
  };
  /* handle the redirect back from Spotify, then start the player */
  finishLogin().then(function(){if(connected()&&document.querySelector('#sp-box'))mount()});
})();
