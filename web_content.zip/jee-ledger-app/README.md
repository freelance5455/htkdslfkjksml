# JEE Ledger app

An installable web app (PWA). It needs to be hosted once over https, then it installs like a normal app.

## 1. Put it online (free, about two minutes)

Easiest: open https://app.netlify.com/drop and drag this whole folder onto the page. Netlify gives you an https address.
Other options: GitHub Pages, Vercel or Cloudflare Pages. Upload the files in this folder as they are.

## 2. Install it on your phone

- Android (Chrome): open the address, then menu, then Install app.
- iPhone (Safari): open the address, then Share, then Add to Home Screen.

It opens full screen with its own icon and keeps working offline. Your progress is saved on the phone.

## 3. Connect Spotify (optional, Spotify Premium needed)

1. Go to https://developer.spotify.com/dashboard and create an app. Choose Web Playback SDK when asked which API you use.
2. Add your app address as a Redirect URI. Use the exact address of this app, for example https://your-name.netlify.app/
3. Copy the Client ID.
4. Open the Study room in the app. In the player card, paste the Client ID, press Save, then Connect Spotify.

After you sign in, the play button plays the current mood through Spotify on this device. Without Spotify, the built-in ambient loop plays.
