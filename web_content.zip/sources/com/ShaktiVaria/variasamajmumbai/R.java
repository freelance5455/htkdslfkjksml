package com.ShaktiVaria.variasamajmumbai;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
    }

    public static final class dimen {
        public static final int activity_horizontal_margin = 0x7f050000;
        public static final int activity_vertical_margin = 0x7f050001;
    }

    public static final class drawable {
        public static final int ic_launcher = 0x7f020000;
        public static final int splash = 0x7f020001;
    }

    public static final class id {
        public static final int action_settings = 0x7f090000;
    }

    public static final class layout {
        public static final int activity_main = 0x7f030000;
    }

    public static final class menu {
        public static final int main = 0x7f080000;
    }

    public static final class string {
        public static final int action_settings = 0x7f060001;
        public static final int app_name = 0x7f060000;
        public static final int hello_world = 0x7f060002;
    }

    public static final class style {
        public static final int AppBaseTheme = 0x7f070000;
        public static final int AppTheme = 0x7f070001;
    }

    public static final class xml {
        public static final int config = 0x7f040000;
    }
}
