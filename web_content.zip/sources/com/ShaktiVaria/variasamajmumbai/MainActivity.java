package com.ShaktiVaria.variasamajmumbai;

import android.os.Bundle;
import org.apache.cordova.DroidGap;

/* JADX INFO: loaded from: classes.dex */
public class MainActivity extends DroidGap {
    @Override // org.apache.cordova.DroidGap, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(1024, 3072);
        super.setIntegerProperty("splashscreen", R.drawable.splash);
        super.loadUrl("file:///android_asset/www/index.html", 3000);
    }
}
