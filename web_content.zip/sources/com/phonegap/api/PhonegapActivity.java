package com.phonegap.api;

import android.app.Activity;
import org.apache.cordova.api.CordovaInterface;

/* JADX INFO: loaded from: classes.dex */
public abstract class PhonegapActivity extends Activity implements CordovaInterface {
}
