package com.phonegap.api;

/* JADX INFO: loaded from: classes.dex */
public interface IPlugin extends org.apache.cordova.api.IPlugin {
}
