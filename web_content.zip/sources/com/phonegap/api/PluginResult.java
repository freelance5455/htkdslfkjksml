package com.phonegap.api;

import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class PluginResult extends org.apache.cordova.api.PluginResult {
    public PluginResult(PluginResult.Status status) {
        super(status);
    }

    public PluginResult(PluginResult.Status status, String message) {
        super(status, message);
    }

    public PluginResult(PluginResult.Status status, JSONArray message) {
        super(status, message);
    }

    public PluginResult(PluginResult.Status status, JSONObject message) {
        super(status, message);
    }

    public PluginResult(PluginResult.Status status, int i) {
        super(status, i);
    }

    public PluginResult(PluginResult.Status status, float f) {
        super(status, f);
    }

    public PluginResult(PluginResult.Status status, boolean b) {
        super(status, b);
    }
}
