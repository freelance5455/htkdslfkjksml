package com.phonegap.api;

/* JADX INFO: loaded from: classes.dex */
public class LOG extends org.apache.cordova.api.LOG {
}
