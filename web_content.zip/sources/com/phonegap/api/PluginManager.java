package com.phonegap.api;

import android.webkit.WebView;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.api.CordovaInterface;

/* JADX INFO: loaded from: classes.dex */
public class PluginManager extends org.apache.cordova.api.PluginManager {
    public PluginManager(WebView app, CordovaInterface ctx) throws Exception {
        super((CordovaWebView) app, ctx);
    }
}
