package com.phonegap.api;

/* JADX INFO: loaded from: classes.dex */
public abstract class Plugin extends org.apache.cordova.api.Plugin {
}
