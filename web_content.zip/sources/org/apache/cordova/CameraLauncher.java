package org.apache.cordova;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.codec.binary.Base64;
import org.apache.cordova.api.LOG;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
public class CameraLauncher extends Plugin implements MediaScannerConnection.MediaScannerConnectionClient {
    private static final int ALLMEDIA = 2;
    private static final int CAMERA = 1;
    private static final int DATA_URL = 0;
    private static final int FILE_URI = 1;
    private static final String GET_All = "Get All";
    private static final String GET_PICTURE = "Get Picture";
    private static final String GET_VIDEO = "Get Video";
    private static final int JPEG = 0;
    private static final String LOG_TAG = "CameraLauncher";
    private static final int PHOTOLIBRARY = 0;
    private static final int PICTURE = 0;
    private static final int PNG = 1;
    private static final int SAVEDPHOTOALBUM = 2;
    private static final int VIDEO = 1;
    private boolean allowEdit;
    public String callbackId;
    private MediaScannerConnection conn;
    private boolean correctOrientation;
    private int encodingType;
    private Uri imageUri;
    private int mQuality;
    private int mediaType;
    private int numPics;
    private boolean saveToPhotoAlbum;
    private Uri scanMe;
    private int targetHeight;
    private int targetWidth;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult.Status status = PluginResult.Status.OK;
        this.callbackId = callbackId;
        try {
            if (action.equals("takePicture")) {
                this.saveToPhotoAlbum = false;
                this.targetHeight = 0;
                this.targetWidth = 0;
                this.encodingType = 0;
                this.mediaType = 0;
                this.mQuality = 80;
                this.mQuality = args.getInt(0);
                int destType = args.getInt(1);
                int srcType = args.getInt(2);
                this.targetWidth = args.getInt(3);
                this.targetHeight = args.getInt(4);
                this.encodingType = args.getInt(5);
                this.mediaType = args.getInt(6);
                this.allowEdit = args.getBoolean(7);
                this.correctOrientation = args.getBoolean(8);
                this.saveToPhotoAlbum = args.getBoolean(9);
                if (this.targetWidth < 1) {
                    this.targetWidth = -1;
                }
                if (this.targetHeight < 1) {
                    this.targetHeight = -1;
                }
                if (srcType == 1) {
                    takePicture(destType, this.encodingType);
                } else if (srcType == 0 || srcType == 2) {
                    getImage(srcType, destType);
                }
                PluginResult r = new PluginResult(PluginResult.Status.NO_RESULT);
                r.setKeepCallback(true);
                return r;
            }
            PluginResult r2 = new PluginResult(status, "");
            return r2;
        } catch (JSONException e) {
            e.printStackTrace();
            PluginResult r3 = new PluginResult(PluginResult.Status.JSON_EXCEPTION);
            return r3;
        }
    }

    public void takePicture(int returnType, int encodingType) {
        this.numPics = queryImgDB(whichContentStore()).getCount();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        File photo = createCaptureFile(encodingType);
        intent.putExtra("output", Uri.fromFile(photo));
        this.imageUri = Uri.fromFile(photo);
        if (this.cordova != null) {
            this.cordova.startActivityForResult(this, intent, returnType + 32 + 1);
        }
    }

    private File createCaptureFile(int encodingType) {
        if (encodingType == 0) {
            File photo = new File(DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()), ".Pic.jpg");
            return photo;
        }
        if (encodingType == 1) {
            File photo2 = new File(DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()), ".Pic.png");
            return photo2;
        }
        throw new IllegalArgumentException("Invalid Encoding Type: " + encodingType);
    }

    public void getImage(int srcType, int returnType) {
        Intent intent = new Intent();
        String title = GET_PICTURE;
        if (this.mediaType == 0) {
            intent.setType("image/*");
        } else if (this.mediaType == 1) {
            intent.setType("video/*");
            title = GET_VIDEO;
        } else if (this.mediaType == 2) {
            intent.setType("*/*");
            title = GET_All;
        }
        intent.setAction("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        if (this.cordova != null) {
            this.cordova.startActivityForResult(this, Intent.createChooser(intent, new String(title)), ((srcType + 1) * 16) + returnType + 1);
        }
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        String exifPath;
        int srcType = (requestCode / 16) - 1;
        int destType = (requestCode % 16) - 1;
        int rotate = 0;
        if (srcType == 1) {
            ExifHelper exif = new ExifHelper();
            try {
                if (this.encodingType == 0) {
                    exif.createInFile(DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()) + "/.Pic.jpg");
                    exif.readExifData();
                    rotate = exif.getOrientation();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (resultCode == -1) {
                Bitmap bitmap = null;
                Uri uri = null;
                try {
                    if (destType == 0) {
                        bitmap = getScaledBitmap(FileUtils.stripFileProtocol(this.imageUri.toString()));
                        if (rotate != 0 && this.correctOrientation) {
                            bitmap = getRotatedBitmap(rotate, bitmap, exif);
                        }
                        processPicture(bitmap);
                        checkForDuplicateImage(0);
                    } else if (destType == 1) {
                        if (!this.saveToPhotoAlbum) {
                            uri = Uri.fromFile(new File(DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()), System.currentTimeMillis() + ".jpg"));
                        } else {
                            uri = getUriFromMediaStore();
                        }
                        if (uri == null) {
                            failPicture("Error capturing image - no media storage found.");
                        }
                        if (this.targetHeight == -1 && this.targetWidth == -1 && this.mQuality == 100 && rotate == 0) {
                            writeUncompressedImage(uri);
                            success(new PluginResult(PluginResult.Status.OK, uri.toString()), this.callbackId);
                        } else {
                            bitmap = getScaledBitmap(FileUtils.stripFileProtocol(this.imageUri.toString()));
                            if (rotate != 0 && this.correctOrientation) {
                                bitmap = getRotatedBitmap(rotate, bitmap, exif);
                            }
                            OutputStream os = this.cordova.getActivity().getContentResolver().openOutputStream(uri);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, this.mQuality, os);
                            os.close();
                            if (this.encodingType == 0) {
                                if (this.saveToPhotoAlbum) {
                                    exifPath = FileUtils.getRealPathFromURI(uri, this.cordova);
                                } else {
                                    exifPath = uri.getPath();
                                }
                                exif.createOutFile(exifPath);
                                exif.writeExifData();
                            }
                        }
                        success(new PluginResult(PluginResult.Status.OK, uri.toString()), this.callbackId);
                    }
                    cleanup(1, this.imageUri, uri, bitmap);
                    return;
                } catch (IOException e2) {
                    e2.printStackTrace();
                    failPicture("Error capturing image.");
                    return;
                }
            }
            if (resultCode == 0) {
                failPicture("Camera cancelled.");
                return;
            } else {
                failPicture("Did not complete!");
                return;
            }
        }
        if (srcType == 0 || srcType == 2) {
            if (resultCode == -1) {
                Uri uri2 = intent.getData();
                if (this.mediaType != 0) {
                    success(new PluginResult(PluginResult.Status.OK, uri2.toString()), this.callbackId);
                    return;
                }
                if (this.targetHeight == -1 && this.targetWidth == -1 && this.mQuality == 100 && destType == 1 && !this.correctOrientation) {
                    success(new PluginResult(PluginResult.Status.OK, uri2.toString()), this.callbackId);
                    return;
                }
                String imagePath = FileUtils.getRealPathFromURI(uri2, this.cordova);
                Bitmap bitmap2 = getScaledBitmap(imagePath);
                if (this.correctOrientation) {
                    String[] cols = {"orientation"};
                    Cursor cursor = this.cordova.getActivity().getContentResolver().query(intent.getData(), cols, null, null, null);
                    if (cursor != null) {
                        cursor.moveToPosition(0);
                        rotate = cursor.getInt(0);
                        cursor.close();
                    }
                    if (rotate != 0) {
                        Matrix matrix = new Matrix();
                        matrix.setRotate(rotate);
                        bitmap2 = Bitmap.createBitmap(bitmap2, 0, 0, bitmap2.getWidth(), bitmap2.getHeight(), matrix, true);
                    }
                }
                if (destType == 0) {
                    processPicture(bitmap2);
                } else if (destType == 1) {
                    if (this.targetHeight > 0 && this.targetWidth > 0) {
                        try {
                            String resizePath = DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()) + "/resize.jpg";
                            ExifHelper exif2 = new ExifHelper();
                            try {
                                if (this.encodingType == 0) {
                                    exif2.createInFile(resizePath);
                                    exif2.readExifData();
                                    exif2.getOrientation();
                                }
                            } catch (IOException e3) {
                                e3.printStackTrace();
                            }
                            OutputStream os2 = new FileOutputStream(resizePath);
                            bitmap2.compress(Bitmap.CompressFormat.JPEG, this.mQuality, os2);
                            os2.close();
                            if (this.encodingType == 0) {
                                exif2.createOutFile(FileUtils.getRealPathFromURI(uri2, this.cordova));
                                exif2.writeExifData();
                            }
                            success(new PluginResult(PluginResult.Status.OK, "file://" + resizePath + "?" + System.currentTimeMillis()), this.callbackId);
                        } catch (Exception e4) {
                            e4.printStackTrace();
                            failPicture("Error retrieving image.");
                        }
                    } else {
                        success(new PluginResult(PluginResult.Status.OK, uri2.toString()), this.callbackId);
                    }
                }
                bitmap2.recycle();
                System.gc();
                return;
            }
            if (resultCode == 0) {
                failPicture("Selection cancelled.");
            } else {
                failPicture("Selection did not complete!");
            }
        }
    }

    private Bitmap getRotatedBitmap(int rotate, Bitmap bitmap, ExifHelper exif) {
        Matrix matrix = new Matrix();
        if (rotate == 180) {
            matrix.setRotate(rotate);
        } else {
            matrix.setRotate(rotate, bitmap.getWidth() / 2.0f, bitmap.getHeight() / 2.0f);
        }
        Bitmap bitmap2 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        exif.resetOrientation();
        return bitmap2;
    }

    private void writeUncompressedImage(Uri uri) throws IOException {
        FileInputStream fis = new FileInputStream(FileUtils.stripFileProtocol(this.imageUri.toString()));
        OutputStream os = this.cordova.getActivity().getContentResolver().openOutputStream(uri);
        byte[] buffer = new byte[4096];
        while (true) {
            int len = fis.read(buffer);
            if (len != -1) {
                os.write(buffer, 0, len);
            } else {
                os.flush();
                os.close();
                fis.close();
                return;
            }
        }
    }

    private Uri getUriFromMediaStore() {
        ContentValues values = new ContentValues();
        values.put("mime_type", "image/jpeg");
        try {
            return this.cordova.getActivity().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        } catch (UnsupportedOperationException e) {
            LOG.d(LOG_TAG, "Can't write to external media storage.");
            try {
                return this.cordova.getActivity().getContentResolver().insert(MediaStore.Images.Media.INTERNAL_CONTENT_URI, values);
            } catch (UnsupportedOperationException e2) {
                LOG.d(LOG_TAG, "Can't write to internal media storage.");
                return null;
            }
        }
    }

    private Bitmap getScaledBitmap(String imagePath) {
        if (this.targetWidth <= 0 && this.targetHeight <= 0) {
            return BitmapFactory.decodeFile(imagePath);
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, options);
        int[] widthHeight = calculateAspectRatio(options.outWidth, options.outHeight);
        options.inJustDecodeBounds = false;
        options.inSampleSize = calculateSampleSize(options.outWidth, options.outHeight, this.targetWidth, this.targetHeight);
        Bitmap unscaledBitmap = BitmapFactory.decodeFile(imagePath, options);
        return Bitmap.createScaledBitmap(unscaledBitmap, widthHeight[0], widthHeight[1], true);
    }

    public int[] calculateAspectRatio(int origWidth, int origHeight) {
        int newWidth = this.targetWidth;
        int newHeight = this.targetHeight;
        if (newWidth <= 0 && newHeight <= 0) {
            newWidth = origWidth;
            newHeight = origHeight;
        } else if (newWidth > 0 && newHeight <= 0) {
            newHeight = (newWidth * origHeight) / origWidth;
        } else if (newWidth <= 0 && newHeight > 0) {
            newWidth = (newHeight * origWidth) / origHeight;
        } else {
            double newRatio = ((double) newWidth) / ((double) newHeight);
            double origRatio = ((double) origWidth) / ((double) origHeight);
            if (origRatio > newRatio) {
                newHeight = (newWidth * origHeight) / origWidth;
            } else if (origRatio < newRatio) {
                newWidth = (newHeight * origWidth) / origHeight;
            }
        }
        int[] retval = {newWidth, newHeight};
        return retval;
    }

    public static int calculateSampleSize(int srcWidth, int srcHeight, int dstWidth, int dstHeight) {
        float srcAspect = srcWidth / srcHeight;
        float dstAspect = dstWidth / dstHeight;
        return srcAspect > dstAspect ? srcWidth / dstWidth : srcHeight / dstHeight;
    }

    private Cursor queryImgDB(Uri contentStore) {
        return this.cordova.getActivity().getContentResolver().query(contentStore, new String[]{"_id"}, null, null, null);
    }

    private void cleanup(int imageType, Uri oldImage, Uri newImage, Bitmap bitmap) {
        if (bitmap != null) {
            bitmap.recycle();
        }
        new File(FileUtils.stripFileProtocol(oldImage.toString())).delete();
        checkForDuplicateImage(imageType);
        if (this.saveToPhotoAlbum && newImage != null) {
            scanForGallery(newImage);
        }
        System.gc();
    }

    private void checkForDuplicateImage(int type) {
        int diff = 1;
        Uri contentStore = whichContentStore();
        Cursor cursor = queryImgDB(contentStore);
        int currentNumOfImages = cursor.getCount();
        if (type == 1 && this.saveToPhotoAlbum) {
            diff = 2;
        }
        if (currentNumOfImages - this.numPics == diff) {
            cursor.moveToLast();
            int id = Integer.valueOf(cursor.getString(cursor.getColumnIndex("_id"))).intValue();
            if (diff == 2) {
                id--;
            }
            Uri uri = Uri.parse(contentStore + "/" + id);
            this.cordova.getActivity().getContentResolver().delete(uri, null, null);
        }
    }

    private Uri whichContentStore() {
        return Environment.getExternalStorageState().equals("mounted") ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.INTERNAL_CONTENT_URI;
    }

    public void processPicture(Bitmap bitmap) {
        ByteArrayOutputStream jpeg_data = new ByteArrayOutputStream();
        try {
            if (bitmap.compress(Bitmap.CompressFormat.JPEG, this.mQuality, jpeg_data)) {
                byte[] code = jpeg_data.toByteArray();
                byte[] output = Base64.encodeBase64(code);
                String js_out = new String(output);
                success(new PluginResult(PluginResult.Status.OK, js_out), this.callbackId);
            }
        } catch (Exception e) {
            failPicture("Error compressing image.");
        }
    }

    public void failPicture(String err) {
        error(new PluginResult(PluginResult.Status.ERROR, err), this.callbackId);
    }

    private void scanForGallery(Uri newImage) {
        this.scanMe = newImage;
        if (this.conn != null) {
            this.conn.disconnect();
        }
        this.conn = new MediaScannerConnection(this.ctx.getActivity().getApplicationContext(), this);
        this.conn.connect();
    }

    @Override // android.media.MediaScannerConnection.MediaScannerConnectionClient
    public void onMediaScannerConnected() {
        try {
            this.conn.scanFile(this.scanMe.toString(), "image/*");
        } catch (IllegalStateException e) {
            LOG.e(LOG_TAG, "Can't scan file in MediaScanner aftering taking picture");
        }
    }

    @Override // android.media.MediaScannerConnection.OnScanCompletedListener
    public void onScanCompleted(String path, Uri uri) {
        this.conn.disconnect();
    }
}
