package org.apache.cordova;

import android.util.Log;
import android.webkit.WebView;
import java.util.HashMap;
import org.apache.cordova.api.CordovaInterface;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public abstract class ContactAccessor {
    protected final String LOG_TAG = "ContactsAccessor";
    protected CordovaInterface mApp;
    protected WebView mView;

    public abstract JSONObject getContactById(String str) throws JSONException;

    public abstract boolean remove(String str);

    public abstract String save(JSONObject jSONObject);

    public abstract JSONArray search(JSONArray jSONArray, JSONObject jSONObject);

    protected boolean isRequired(String key, HashMap<String, Boolean> map) {
        Boolean retVal = map.get(key);
        if (retVal == null) {
            return false;
        }
        return retVal.booleanValue();
    }

    protected HashMap<String, Boolean> buildPopulationSet(JSONArray fields) {
        HashMap<String, Boolean> map = new HashMap<>();
        try {
            if (fields.length() == 1 && fields.getString(0).equals("*")) {
                map.put("displayName", true);
                map.put("name", true);
                map.put("nickname", true);
                map.put("phoneNumbers", true);
                map.put("emails", true);
                map.put("addresses", true);
                map.put("ims", true);
                map.put("organizations", true);
                map.put("birthday", true);
                map.put("note", true);
                map.put("urls", true);
                map.put("photos", true);
                map.put("categories", true);
            } else {
                for (int i = 0; i < fields.length(); i++) {
                    String key = fields.getString(i);
                    if (key.startsWith("displayName")) {
                        map.put("displayName", true);
                    } else if (key.startsWith("name")) {
                        map.put("displayName", true);
                        map.put("name", true);
                    } else if (key.startsWith("nickname")) {
                        map.put("nickname", true);
                    } else if (key.startsWith("phoneNumbers")) {
                        map.put("phoneNumbers", true);
                    } else if (key.startsWith("emails")) {
                        map.put("emails", true);
                    } else if (key.startsWith("addresses")) {
                        map.put("addresses", true);
                    } else if (key.startsWith("ims")) {
                        map.put("ims", true);
                    } else if (key.startsWith("organizations")) {
                        map.put("organizations", true);
                    } else if (key.startsWith("birthday")) {
                        map.put("birthday", true);
                    } else if (key.startsWith("note")) {
                        map.put("note", true);
                    } else if (key.startsWith("urls")) {
                        map.put("urls", true);
                    } else if (key.startsWith("photos")) {
                        map.put("photos", true);
                    } else if (key.startsWith("categories")) {
                        map.put("categories", true);
                    }
                }
            }
        } catch (JSONException e) {
            Log.e("ContactsAccessor", e.getMessage(), e);
        }
        return map;
    }

    protected String getJsonString(JSONObject obj, String property) {
        String value = null;
        if (obj == null) {
            return null;
        }
        try {
            value = obj.getString(property);
            if (value.equals("null")) {
                Log.d("ContactsAccessor", property + " is string called 'null'");
                return null;
            }
            return value;
        } catch (JSONException e) {
            Log.d("ContactsAccessor", "Could not get = " + e.getMessage());
            return value;
        }
    }

    class WhereOptions {
        private String where;
        private String[] whereArgs;

        WhereOptions() {
        }

        public void setWhere(String where) {
            this.where = where;
        }

        public String getWhere() {
            return this.where;
        }

        public void setWhereArgs(String[] whereArgs) {
            this.whereArgs = whereArgs;
        }

        public String[] getWhereArgs() {
            return this.whereArgs;
        }
    }
}
