package org.apache.cordova;

import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.channels.FileChannel;
import org.apache.commons.codec.binary.Base64;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.apache.cordova.file.EncodingException;
import org.apache.cordova.file.FileExistsException;
import org.apache.cordova.file.InvalidModificationException;
import org.apache.cordova.file.NoModificationAllowedException;
import org.apache.cordova.file.TypeMismatchException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class FileUtils extends Plugin {
    private static final String LOG_TAG = "FileUtils";
    private static final String _DATA = "_data";
    FileReader f_in;
    FileWriter f_out;
    public static int NOT_FOUND_ERR = 1;
    public static int SECURITY_ERR = 2;
    public static int ABORT_ERR = 3;
    public static int NOT_READABLE_ERR = 4;
    public static int ENCODING_ERR = 5;
    public static int NO_MODIFICATION_ALLOWED_ERR = 6;
    public static int INVALID_STATE_ERR = 7;
    public static int SYNTAX_ERR = 8;
    public static int INVALID_MODIFICATION_ERR = 9;
    public static int QUOTA_EXCEEDED_ERR = 10;
    public static int TYPE_MISMATCH_ERR = 11;
    public static int PATH_EXISTS_ERR = 12;
    public static int TEMPORARY = 0;
    public static int PERSISTENT = 1;
    public static int RESOURCE = 2;
    public static int APPLICATION = 3;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult pluginResult;
        PluginResult.Status status = PluginResult.Status.OK;
        try {
            if (action.equals("testSaveLocationExists")) {
                boolean b = DirectoryManager.testSaveLocationExists();
                pluginResult = new PluginResult(status, b);
            } else if (action.equals("getFreeDiskSpace")) {
                long l = DirectoryManager.getFreeDiskSpace(false);
                pluginResult = new PluginResult(status, l);
            } else if (action.equals("testFileExists")) {
                boolean b2 = DirectoryManager.testFileExists(args.getString(0));
                pluginResult = new PluginResult(status, b2);
            } else if (action.equals("testDirectoryExists")) {
                boolean b3 = DirectoryManager.testFileExists(args.getString(0));
                pluginResult = new PluginResult(status, b3);
            } else if (action.equals("readAsText")) {
                String s = readAsText(args.getString(0), args.getString(1));
                pluginResult = new PluginResult(status, s);
            } else if (action.equals("readAsDataURL")) {
                String s2 = readAsDataURL(args.getString(0));
                pluginResult = new PluginResult(status, s2);
            } else if (action.equals("write")) {
                long fileSize = write(args.getString(0), args.getString(1), args.getInt(2));
                pluginResult = new PluginResult(status, fileSize);
            } else if (action.equals("truncate")) {
                long fileSize2 = truncateFile(args.getString(0), args.getLong(1));
                pluginResult = new PluginResult(status, fileSize2);
            } else if (action.equals("requestFileSystem")) {
                long size = args.optLong(1);
                if (size != 0 && size > DirectoryManager.getFreeDiskSpace(true) * 1024) {
                    pluginResult = new PluginResult(PluginResult.Status.ERROR, QUOTA_EXCEEDED_ERR);
                } else {
                    JSONObject obj = requestFileSystem(args.getInt(0));
                    pluginResult = new PluginResult(status, obj);
                }
            } else if (action.equals("resolveLocalFileSystemURI")) {
                JSONObject obj2 = resolveLocalFileSystemURI(args.getString(0));
                pluginResult = new PluginResult(status, obj2);
            } else if (action.equals("getMetadata")) {
                pluginResult = new PluginResult(status, getMetadata(args.getString(0)));
            } else if (action.equals("getFileMetadata")) {
                JSONObject obj3 = getFileMetadata(args.getString(0));
                pluginResult = new PluginResult(status, obj3);
            } else if (action.equals("getParent")) {
                JSONObject obj4 = getParent(args.getString(0));
                pluginResult = new PluginResult(status, obj4);
            } else if (action.equals("getDirectory")) {
                JSONObject obj5 = getFile(args.getString(0), args.getString(1), args.optJSONObject(2), true);
                pluginResult = new PluginResult(status, obj5);
            } else if (action.equals("getFile")) {
                JSONObject obj6 = getFile(args.getString(0), args.getString(1), args.optJSONObject(2), false);
                pluginResult = new PluginResult(status, obj6);
            } else if (action.equals("remove")) {
                boolean success = remove(args.getString(0));
                if (success) {
                    notifyDelete(args.getString(0));
                    pluginResult = new PluginResult(status);
                } else {
                    pluginResult = new PluginResult(PluginResult.Status.ERROR, NO_MODIFICATION_ALLOWED_ERR);
                }
            } else if (action.equals("removeRecursively")) {
                boolean success2 = removeRecursively(args.getString(0));
                if (success2) {
                    pluginResult = new PluginResult(status);
                } else {
                    pluginResult = new PluginResult(PluginResult.Status.ERROR, NO_MODIFICATION_ALLOWED_ERR);
                }
            } else if (action.equals("moveTo")) {
                JSONObject entry = transferTo(args.getString(0), args.getString(1), args.getString(2), true);
                pluginResult = new PluginResult(status, entry);
            } else if (action.equals("copyTo")) {
                JSONObject entry2 = transferTo(args.getString(0), args.getString(1), args.getString(2), false);
                pluginResult = new PluginResult(status, entry2);
            } else if (action.equals("readEntries")) {
                JSONArray entries = readEntries(args.getString(0));
                pluginResult = new PluginResult(status, entries);
            } else {
                pluginResult = new PluginResult(status, "");
            }
            return pluginResult;
        } catch (FileNotFoundException e) {
            return new PluginResult(PluginResult.Status.ERROR, NOT_FOUND_ERR);
        } catch (MalformedURLException e2) {
            return new PluginResult(PluginResult.Status.ERROR, ENCODING_ERR);
        } catch (IOException e3) {
            return new PluginResult(PluginResult.Status.ERROR, INVALID_MODIFICATION_ERR);
        } catch (EncodingException e4) {
            return new PluginResult(PluginResult.Status.ERROR, ENCODING_ERR);
        } catch (FileExistsException e5) {
            return new PluginResult(PluginResult.Status.ERROR, PATH_EXISTS_ERR);
        } catch (InvalidModificationException e6) {
            return new PluginResult(PluginResult.Status.ERROR, INVALID_MODIFICATION_ERR);
        } catch (NoModificationAllowedException e7) {
            return new PluginResult(PluginResult.Status.ERROR, NO_MODIFICATION_ALLOWED_ERR);
        } catch (TypeMismatchException e8) {
            return new PluginResult(PluginResult.Status.ERROR, TYPE_MISMATCH_ERR);
        } catch (JSONException e9) {
            return new PluginResult(PluginResult.Status.ERROR, NO_MODIFICATION_ALLOWED_ERR);
        }
    }

    private void notifyDelete(String filePath) {
        String newFilePath = stripFileProtocol(filePath);
        this.cordova.getActivity().getContentResolver().delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "_data = ?", new String[]{newFilePath});
    }

    private JSONObject resolveLocalFileSystemURI(String url) throws JSONException, IOException {
        File fp;
        String decoded = URLDecoder.decode(url, "UTF-8");
        if (decoded.startsWith("content:")) {
            Cursor cursor = this.cordova.getActivity().managedQuery(Uri.parse(decoded), new String[]{_DATA}, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(_DATA);
            cursor.moveToFirst();
            fp = new File(cursor.getString(column_index));
        } else {
            new URL(decoded);
            if (decoded.startsWith("file://")) {
                int questionMark = decoded.indexOf("?");
                if (questionMark < 0) {
                    fp = new File(decoded.substring(7, decoded.length()));
                } else {
                    fp = new File(decoded.substring(7, questionMark));
                }
            } else {
                fp = new File(decoded);
            }
        }
        if (!fp.exists()) {
            throw new FileNotFoundException();
        }
        if (!fp.canRead()) {
            throw new IOException();
        }
        return getEntry(fp);
    }

    private JSONArray readEntries(String fileName) throws JSONException, FileNotFoundException {
        File fp = createFileObject(fileName);
        if (!fp.exists()) {
            throw new FileNotFoundException();
        }
        JSONArray entries = new JSONArray();
        if (fp.isDirectory()) {
            File[] files = fp.listFiles();
            for (File file : files) {
                entries.put(getEntry(file));
            }
        }
        return entries;
    }

    private JSONObject transferTo(String fileName, String newParent, String newName, boolean move) throws JSONException, InvalidModificationException, EncodingException, NoModificationAllowedException, IOException {
        String fileName2 = stripFileProtocol(fileName);
        String newParent2 = stripFileProtocol(newParent);
        if (newName != null && newName.contains(":")) {
            throw new EncodingException("Bad file name");
        }
        File source = new File(fileName2);
        if (!source.exists()) {
            throw new FileNotFoundException("The source does not exist");
        }
        File destinationDir = new File(newParent2);
        if (!destinationDir.exists()) {
            throw new FileNotFoundException("The source does not exist");
        }
        File destination = createDestination(newName, source, destinationDir);
        if (source.getAbsolutePath().equals(destination.getAbsolutePath())) {
            throw new InvalidModificationException("Can't copy a file onto itself");
        }
        if (source.isDirectory()) {
            if (move) {
                return moveDirectory(source, destination);
            }
            return copyDirectory(source, destination);
        }
        if (move) {
            return moveFile(source, destination);
        }
        return copyFile(source, destination);
    }

    private File createDestination(String newName, File fp, File destination) {
        if ("null".equals(newName) || "".equals(newName)) {
            newName = null;
        }
        if (newName != null) {
            File destFile = new File(destination.getAbsolutePath() + File.separator + newName);
            return destFile;
        }
        File destFile2 = new File(destination.getAbsolutePath() + File.separator + fp.getName());
        return destFile2;
    }

    private JSONObject copyFile(File srcFile, File destFile) throws JSONException, InvalidModificationException, IOException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new InvalidModificationException("Can't rename a file to a directory");
        }
        FileChannel input = new FileInputStream(srcFile).getChannel();
        FileChannel output = new FileOutputStream(destFile).getChannel();
        input.transferTo(0L, input.size(), output);
        input.close();
        output.close();
        return getEntry(destFile);
    }

    private JSONObject copyDirectory(File srcDir, File destinationDir) throws JSONException, InvalidModificationException, NoModificationAllowedException, IOException {
        if (destinationDir.exists() && destinationDir.isFile()) {
            throw new InvalidModificationException("Can't rename a file to a directory");
        }
        if (isCopyOnItself(srcDir.getAbsolutePath(), destinationDir.getAbsolutePath())) {
            throw new InvalidModificationException("Can't copy itself into itself");
        }
        if (!destinationDir.exists() && !destinationDir.mkdir()) {
            throw new NoModificationAllowedException("Couldn't create the destination direcotry");
        }
        File[] arr$ = srcDir.listFiles();
        for (File file : arr$) {
            if (file.isDirectory()) {
                copyDirectory(file, destinationDir);
            } else {
                File destination = new File(destinationDir.getAbsoluteFile() + File.separator + file.getName());
                copyFile(file, destination);
            }
        }
        return getEntry(destinationDir);
    }

    private boolean isCopyOnItself(String src, String dest) {
        return dest.startsWith(src) && dest.indexOf(File.separator, src.length() + (-1)) != -1;
    }

    private JSONObject moveFile(File srcFile, File destFile) throws JSONException, InvalidModificationException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new InvalidModificationException("Can't rename a file to a directory");
        }
        if (!srcFile.renameTo(destFile)) {
        }
        return getEntry(destFile);
    }

    private JSONObject moveDirectory(File srcDir, File destinationDir) throws JSONException, InvalidModificationException {
        if (destinationDir.exists() && destinationDir.isFile()) {
            throw new InvalidModificationException("Can't rename a file to a directory");
        }
        if (isCopyOnItself(srcDir.getAbsolutePath(), destinationDir.getAbsolutePath())) {
            throw new InvalidModificationException("Can't move itself into itself");
        }
        if (destinationDir.exists() && destinationDir.list().length > 0) {
            throw new InvalidModificationException("directory is not empty");
        }
        if (!srcDir.renameTo(destinationDir)) {
        }
        return getEntry(destinationDir);
    }

    private boolean removeRecursively(String filePath) throws FileExistsException {
        File fp = createFileObject(filePath);
        if (atRootDirectory(filePath)) {
            return false;
        }
        return removeDirRecursively(fp);
    }

    private boolean removeDirRecursively(File directory) throws FileExistsException {
        if (directory.isDirectory()) {
            File[] arr$ = directory.listFiles();
            for (File file : arr$) {
                removeDirRecursively(file);
            }
        }
        if (!directory.delete()) {
            throw new FileExistsException("could not delete: " + directory.getName());
        }
        return true;
    }

    private boolean remove(String filePath) throws InvalidModificationException, NoModificationAllowedException {
        File fp = createFileObject(filePath);
        if (atRootDirectory(filePath)) {
            throw new NoModificationAllowedException("You can't delete the root directory");
        }
        if (fp.isDirectory() && fp.list().length > 0) {
            throw new InvalidModificationException("You can't delete a directory that is not empty.");
        }
        return fp.delete();
    }

    private JSONObject getFile(String dirPath, String fileName, JSONObject options, boolean directory) throws JSONException, FileExistsException, EncodingException, IOException, TypeMismatchException {
        boolean create = false;
        boolean exclusive = false;
        if (options != null && (create = options.optBoolean("create"))) {
            exclusive = options.optBoolean("exclusive");
        }
        if (fileName.contains(":")) {
            throw new EncodingException("This file has a : in it's name");
        }
        File fp = createFileObject(dirPath, fileName);
        if (create) {
            if (exclusive && fp.exists()) {
                throw new FileExistsException("create/exclusive fails");
            }
            if (directory) {
                fp.mkdir();
            } else {
                fp.createNewFile();
            }
            if (!fp.exists()) {
                throw new FileExistsException("create fails");
            }
        } else {
            if (!fp.exists()) {
                throw new FileNotFoundException("path does not exist");
            }
            if (directory) {
                if (fp.isFile()) {
                    throw new TypeMismatchException("path doesn't exist or is file");
                }
            } else if (fp.isDirectory()) {
                throw new TypeMismatchException("path doesn't exist or is directory");
            }
        }
        return getEntry(fp);
    }

    private File createFileObject(String dirPath, String fileName) {
        if (fileName.startsWith("/")) {
            File fp = new File(fileName);
            return fp;
        }
        File fp2 = new File(stripFileProtocol(dirPath) + File.separator + fileName);
        return fp2;
    }

    private JSONObject getParent(String filePath) throws JSONException {
        String filePath2 = stripFileProtocol(filePath);
        return atRootDirectory(filePath2) ? getEntry(filePath2) : getEntry(new File(filePath2).getParent());
    }

    private boolean atRootDirectory(String filePath) {
        String filePath2 = stripFileProtocol(filePath);
        return filePath2.equals(new StringBuilder().append(Environment.getExternalStorageDirectory().getAbsolutePath()).append("/Android/data/").append(this.cordova.getActivity().getPackageName()).append("/cache").toString()) || filePath2.equals(Environment.getExternalStorageDirectory().getAbsolutePath()) || filePath2.equals(new StringBuilder().append("/data/data/").append(this.cordova.getActivity().getPackageName()).toString());
    }

    public static String stripFileProtocol(String filePath) {
        if (filePath.startsWith("file://")) {
            return filePath.substring(7);
        }
        return filePath;
    }

    private File createFileObject(String filePath) {
        File file = new File(stripFileProtocol(filePath));
        return file;
    }

    private long getMetadata(String filePath) throws FileNotFoundException {
        File file = createFileObject(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("Failed to find file in getMetadata");
        }
        return file.lastModified();
    }

    private JSONObject getFileMetadata(String filePath) throws JSONException, FileNotFoundException {
        File file = createFileObject(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("File: " + filePath + " does not exist.");
        }
        JSONObject metadata = new JSONObject();
        metadata.put("size", file.length());
        metadata.put("type", getMimeType(filePath));
        metadata.put("name", file.getName());
        metadata.put("fullPath", file.getAbsolutePath());
        metadata.put("lastModifiedDate", file.lastModified());
        return metadata;
    }

    private JSONObject requestFileSystem(int type) throws JSONException, IOException {
        JSONObject fs = new JSONObject();
        if (type == TEMPORARY) {
            fs.put("name", "temporary");
            if (Environment.getExternalStorageState().equals("mounted")) {
                File fp = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data/" + this.cordova.getActivity().getPackageName() + "/cache/");
                fp.mkdirs();
                fs.put("root", getEntry(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data/" + this.cordova.getActivity().getPackageName() + "/cache/"));
            } else {
                File fp2 = new File("/data/data/" + this.cordova.getActivity().getPackageName() + "/cache/");
                fp2.mkdirs();
                fs.put("root", getEntry("/data/data/" + this.cordova.getActivity().getPackageName() + "/cache/"));
            }
        } else if (type == PERSISTENT) {
            fs.put("name", "persistent");
            if (Environment.getExternalStorageState().equals("mounted")) {
                fs.put("root", getEntry(Environment.getExternalStorageDirectory()));
            } else {
                fs.put("root", getEntry("/data/data/" + this.cordova.getActivity().getPackageName()));
            }
        } else {
            throw new IOException("No filesystem of type requested");
        }
        return fs;
    }

    public JSONObject getEntry(File file) throws JSONException {
        JSONObject entry = new JSONObject();
        entry.put("isFile", file.isFile());
        entry.put("isDirectory", file.isDirectory());
        entry.put("name", file.getName());
        entry.put("fullPath", "file://" + file.getAbsolutePath());
        return entry;
    }

    private JSONObject getEntry(String path) throws JSONException {
        return getEntry(new File(path));
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        return action.equals("testSaveLocationExists") || action.equals("getFreeDiskSpace") || action.equals("testFileExists") || action.equals("testDirectoryExists");
    }

    public String readAsText(String filename, String encoding) throws IOException {
        byte[] bytes = new byte[1000];
        BufferedInputStream bis = new BufferedInputStream(getPathFromUri(filename), 1024);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while (true) {
            int numRead = bis.read(bytes, 0, 1000);
            if (numRead >= 0) {
                bos.write(bytes, 0, numRead);
            } else {
                return new String(bos.toByteArray(), encoding);
            }
        }
    }

    public String readAsDataURL(String filename) throws IOException {
        String contentType;
        byte[] bytes = new byte[1000];
        BufferedInputStream bis = new BufferedInputStream(getPathFromUri(filename), 1024);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while (true) {
            int numRead = bis.read(bytes, 0, 1000);
            if (numRead < 0) {
                break;
            }
            bos.write(bytes, 0, numRead);
        }
        if (filename.startsWith("content:")) {
            Uri fileUri = Uri.parse(filename);
            contentType = this.cordova.getActivity().getContentResolver().getType(fileUri);
        } else {
            contentType = getMimeType(filename);
        }
        byte[] base64 = Base64.encodeBase64(bos.toByteArray());
        String data = "data:" + contentType + ";base64," + new String(base64);
        return data;
    }

    public static String getMimeType(String filename) {
        MimeTypeMap map = MimeTypeMap.getSingleton();
        return map.getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(filename));
    }

    public long write(String filename, String data, int offset) throws IOException {
        String filename2 = stripFileProtocol(filename);
        boolean append = false;
        if (offset > 0) {
            truncateFile(filename2, offset);
            append = true;
        }
        byte[] rawData = data.getBytes();
        ByteArrayInputStream in = new ByteArrayInputStream(rawData);
        FileOutputStream out = new FileOutputStream(filename2, append);
        byte[] buff = new byte[rawData.length];
        in.read(buff, 0, buff.length);
        out.write(buff, 0, rawData.length);
        out.flush();
        out.close();
        return rawData.length;
    }

    private long truncateFile(String filename, long size) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(stripFileProtocol(filename), "rw");
        if (raf.length() < size) {
            return raf.length();
        }
        FileChannel channel = raf.getChannel();
        channel.truncate(size);
        return size;
    }

    private InputStream getPathFromUri(String path) throws FileNotFoundException {
        if (path.startsWith("content")) {
            Uri uri = Uri.parse(path);
            return this.cordova.getActivity().getContentResolver().openInputStream(uri);
        }
        return new FileInputStream(stripFileProtocol(path));
    }

    protected static String getRealPathFromURI(Uri contentUri, CordovaInterface cordova) {
        String[] proj = {_DATA};
        Cursor cursor = cordova.getActivity().managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(_DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
}
