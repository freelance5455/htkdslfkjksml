package org.apache.cordova;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.cordova.api.LOG;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class Capture extends Plugin {
    private static final String AUDIO_3GPP = "audio/3gpp";
    private static final int CAPTURE_AUDIO = 0;
    private static final int CAPTURE_IMAGE = 1;
    private static final int CAPTURE_INTERNAL_ERR = 0;
    private static final int CAPTURE_NOT_SUPPORTED = 20;
    private static final int CAPTURE_NO_MEDIA_FILES = 3;
    private static final int CAPTURE_VIDEO = 2;
    private static final String IMAGE_JPEG = "image/jpeg";
    private static final String LOG_TAG = "Capture";
    private static final String VIDEO_3GPP = "video/3gpp";
    private static final String VIDEO_MP4 = "video/mp4";
    private String callbackId;
    private double duration;
    private Uri imageUri;
    private long limit;
    private int numPics;
    private JSONArray results;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        this.callbackId = callbackId;
        this.limit = 1L;
        this.duration = 0.0d;
        this.results = new JSONArray();
        JSONObject options = args.optJSONObject(0);
        if (options != null) {
            this.limit = options.optLong("limit", 1L);
            this.duration = options.optDouble("duration", 0.0d);
        }
        if (action.equals("getFormatData")) {
            try {
                JSONObject obj = getFormatData(args.getString(0), args.getString(1));
                return new PluginResult(PluginResult.Status.OK, obj);
            } catch (JSONException e) {
                return new PluginResult(PluginResult.Status.ERROR);
            }
        }
        if (action.equals("captureAudio")) {
            captureAudio();
        } else if (action.equals("captureImage")) {
            captureImage();
        } else if (action.equals("captureVideo")) {
            captureVideo(this.duration);
        }
        PluginResult r = new PluginResult(PluginResult.Status.NO_RESULT);
        r.setKeepCallback(true);
        return r;
    }

    private JSONObject getFormatData(String filePath, String mimeType) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("height", 0);
            obj.put("width", 0);
            obj.put("bitrate", 0);
            obj.put("duration", 0);
            obj.put("codecs", "");
            if (mimeType == null || mimeType.equals("")) {
                mimeType = FileUtils.getMimeType(filePath);
            }
            Log.d(LOG_TAG, "Mime type = " + mimeType);
            if (mimeType.equals(IMAGE_JPEG) || filePath.endsWith(".jpg")) {
                return getImageData(filePath, obj);
            }
            if (mimeType.endsWith(AUDIO_3GPP)) {
                return getAudioVideoData(filePath, obj, false);
            }
            if (mimeType.equals(VIDEO_3GPP) || mimeType.equals(VIDEO_MP4)) {
                return getAudioVideoData(filePath, obj, true);
            }
            return obj;
        } catch (JSONException e) {
            Log.d(LOG_TAG, "Error: setting media file data object");
            return obj;
        }
    }

    private JSONObject getImageData(String filePath, JSONObject obj) throws JSONException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(FileUtils.stripFileProtocol(filePath), options);
        obj.put("height", options.outHeight);
        obj.put("width", options.outWidth);
        return obj;
    }

    private JSONObject getAudioVideoData(String filePath, JSONObject obj, boolean video) throws JSONException {
        MediaPlayer player = new MediaPlayer();
        try {
            player.setDataSource(filePath);
            player.prepare();
            obj.put("duration", player.getDuration() / 1000);
            if (video) {
                obj.put("height", player.getVideoHeight());
                obj.put("width", player.getVideoWidth());
            }
        } catch (IOException e) {
            Log.d(LOG_TAG, "Error: loading video file");
        }
        return obj;
    }

    private void captureAudio() {
        Intent intent = new Intent("android.provider.MediaStore.RECORD_SOUND");
        this.cordova.startActivityForResult(this, intent, 0);
    }

    private void captureImage() {
        this.numPics = queryImgDB(whichContentStore()).getCount();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        File photo = new File(DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()), "Capture.jpg");
        intent.putExtra("output", Uri.fromFile(photo));
        this.imageUri = Uri.fromFile(photo);
        this.cordova.startActivityForResult(this, intent, 1);
    }

    private void captureVideo(double duration) {
        Intent intent = new Intent("android.media.action.VIDEO_CAPTURE");
        this.cordova.startActivityForResult(this, intent, 2);
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Uri uri;
        if (resultCode == -1) {
            if (requestCode == 0) {
                Uri data = intent.getData();
                this.results.put(createMediaFile(data));
                if (this.results.length() >= this.limit) {
                    success(new PluginResult(PluginResult.Status.OK, this.results), this.callbackId);
                    return;
                } else {
                    captureAudio();
                    return;
                }
            }
            if (requestCode == 1) {
                try {
                    ContentValues values = new ContentValues();
                    values.put("mime_type", IMAGE_JPEG);
                    try {
                        uri = this.cordova.getActivity().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    } catch (UnsupportedOperationException e) {
                        LOG.d(LOG_TAG, "Can't write to external media storage.");
                        try {
                            uri = this.cordova.getActivity().getContentResolver().insert(MediaStore.Images.Media.INTERNAL_CONTENT_URI, values);
                        } catch (UnsupportedOperationException e2) {
                            LOG.d(LOG_TAG, "Can't write to internal media storage.");
                            fail(createErrorObject(0, "Error capturing image - no media storage found."));
                            return;
                        }
                    }
                    FileInputStream fis = new FileInputStream(DirectoryManager.getTempDirectoryPath(this.cordova.getActivity()) + "/Capture.jpg");
                    OutputStream os = this.cordova.getActivity().getContentResolver().openOutputStream(uri);
                    byte[] buffer = new byte[4096];
                    while (true) {
                        int len = fis.read(buffer);
                        if (len == -1) {
                            break;
                        } else {
                            os.write(buffer, 0, len);
                        }
                    }
                    os.flush();
                    os.close();
                    fis.close();
                    this.results.put(createMediaFile(uri));
                    checkForDuplicateImage();
                    if (this.results.length() >= this.limit) {
                        success(new PluginResult(PluginResult.Status.OK, this.results), this.callbackId);
                        return;
                    } else {
                        captureImage();
                        return;
                    }
                } catch (IOException e3) {
                    e3.printStackTrace();
                    fail(createErrorObject(0, "Error capturing image."));
                    return;
                }
            }
            if (requestCode == 2) {
                Uri data2 = intent.getData();
                this.results.put(createMediaFile(data2));
                if (this.results.length() >= this.limit) {
                    success(new PluginResult(PluginResult.Status.OK, this.results), this.callbackId);
                    return;
                } else {
                    captureVideo(this.duration);
                    return;
                }
            }
            return;
        }
        if (resultCode == 0) {
            if (this.results.length() > 0) {
                success(new PluginResult(PluginResult.Status.OK, this.results), this.callbackId);
                return;
            } else {
                fail(createErrorObject(3, "Canceled."));
                return;
            }
        }
        if (this.results.length() > 0) {
            success(new PluginResult(PluginResult.Status.OK, this.results), this.callbackId);
        } else {
            fail(createErrorObject(3, "Did not complete!"));
        }
    }

    private JSONObject createMediaFile(Uri data) {
        File fp = new File(FileUtils.getRealPathFromURI(data, this.cordova));
        JSONObject obj = new JSONObject();
        try {
            obj.put("name", fp.getName());
            obj.put("fullPath", "file://" + fp.getAbsolutePath());
            if (fp.getAbsoluteFile().toString().endsWith(".3gp") || fp.getAbsoluteFile().toString().endsWith(".3gpp")) {
                if (data.toString().contains("/audio/")) {
                    obj.put("type", AUDIO_3GPP);
                } else {
                    obj.put("type", VIDEO_3GPP);
                }
            } else {
                obj.put("type", FileUtils.getMimeType(fp.getAbsolutePath()));
            }
            obj.put("lastModifiedDate", fp.lastModified());
            obj.put("size", fp.length());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return obj;
    }

    private JSONObject createErrorObject(int code, String message) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("code", code);
            obj.put("message", message);
        } catch (JSONException e) {
        }
        return obj;
    }

    public void fail(JSONObject err) {
        error(new PluginResult(PluginResult.Status.ERROR, err), this.callbackId);
    }

    private Cursor queryImgDB(Uri contentStore) {
        return this.cordova.getActivity().getContentResolver().query(contentStore, new String[]{"_id"}, null, null, null);
    }

    private void checkForDuplicateImage() {
        Uri contentStore = whichContentStore();
        Cursor cursor = queryImgDB(contentStore);
        int currentNumOfImages = cursor.getCount();
        if (currentNumOfImages - this.numPics == 2) {
            cursor.moveToLast();
            int id = Integer.valueOf(cursor.getString(cursor.getColumnIndex("_id"))).intValue() - 1;
            Uri uri = Uri.parse(contentStore + "/" + id);
            this.cordova.getActivity().getContentResolver().delete(uri, null, null);
        }
    }

    private Uri whichContentStore() {
        return Environment.getExternalStorageState().equals("mounted") ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.INTERNAL_CONTENT_URI;
    }
}
