package org.apache.cordova;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import java.util.HashMap;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.IPlugin;
import org.apache.cordova.api.LOG;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class DroidGap extends Activity implements CordovaInterface {
    protected boolean activityResultKeepRunning;
    protected CordovaWebView appView;
    protected LinearLayout root;
    protected Dialog splashDialog;
    protected CordovaWebViewClient webViewClient;
    public static String TAG = "DroidGap";
    private static int ACTIVITY_STARTING = 0;
    private static int ACTIVITY_RUNNING = 1;
    private static int ACTIVITY_EXITING = 2;
    protected boolean cancelLoadUrl = false;
    protected ProgressDialog spinnerDialog = null;
    private int activityState = 0;
    String baseUrl = null;
    protected IPlugin activityResultCallback = null;
    private int backgroundColor = -16777216;
    protected int splashscreen = 0;
    protected int splashscreenTime = 0;
    protected int loadUrlTimeoutValue = 20000;
    protected boolean keepRunning = true;

    public void setAuthenticationToken(AuthenticationToken authenticationToken, String host, String realm) {
        if (this.appView != null && this.appView.viewClient != null) {
            this.appView.viewClient.setAuthenticationToken(authenticationToken, host, realm);
        }
    }

    public AuthenticationToken removeAuthenticationToken(String host, String realm) {
        if (this.appView == null || this.appView.viewClient == null) {
            return null;
        }
        return this.appView.viewClient.removeAuthenticationToken(host, realm);
    }

    public AuthenticationToken getAuthenticationToken(String host, String realm) {
        if (this.appView == null || this.appView.viewClient == null) {
            return null;
        }
        return this.appView.viewClient.getAuthenticationToken(host, realm);
    }

    public void clearAuthenticationTokens() {
        if (this.appView != null && this.appView.viewClient != null) {
            this.appView.viewClient.clearAuthenticationTokens();
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        LOG.d(TAG, "DroidGap.onCreate()");
        super.onCreate(savedInstanceState);
        if (!getBooleanProperty("showTitle", false)) {
            getWindow().requestFeature(1);
        }
        if (getBooleanProperty("setFullscreen", false)) {
            getWindow().setFlags(1024, 1024);
        } else {
            getWindow().setFlags(2048, 2048);
        }
        Display display = getWindowManager().getDefaultDisplay();
        int width = display.getWidth();
        int height = display.getHeight();
        this.root = new LinearLayoutSoftKeyboardDetect(this, width, height);
        this.root.setOrientation(1);
        this.root.setBackgroundColor(this.backgroundColor);
        this.root.setLayoutParams(new LinearLayout.LayoutParams(-1, -1, 0.0f));
        setVolumeControlStream(3);
    }

    @Override // org.apache.cordova.api.CordovaInterface
    public Activity getActivity() {
        return this;
    }

    public void init() {
        CordovaWebView webView = new CordovaWebView(this);
        init(webView, new CordovaWebViewClient(this, webView), new CordovaChromeClient(this, webView));
    }

    public void init(CordovaWebView webView, CordovaWebViewClient webViewClient, CordovaChromeClient webChromeClient) {
        LOG.d(TAG, "DroidGap.init()");
        this.appView = webView;
        this.appView.setId(100);
        this.appView.setWebViewClient(webViewClient);
        this.appView.setWebChromeClient(webChromeClient);
        webViewClient.setWebView(this.appView);
        webChromeClient.setWebView(this.appView);
        this.appView.setLayoutParams(new LinearLayout.LayoutParams(-1, -1, 1.0f));
        this.appView.setVisibility(4);
        this.root.addView(this.appView);
        setContentView(this.root);
        this.cancelLoadUrl = false;
    }

    public void loadUrl(String url) {
        if (this.appView == null) {
            init();
        }
        this.backgroundColor = getIntegerProperty("backgroundColor", -16777216);
        this.root.setBackgroundColor(this.backgroundColor);
        this.keepRunning = getBooleanProperty("keepRunning", true);
        loadSpinner();
        this.appView.loadUrl(url);
    }

    void loadSpinner() {
        String loading;
        if (this.appView == null || !this.appView.canGoBack()) {
            loading = getStringProperty("loadingDialog", null);
        } else {
            loading = getStringProperty("loadingPageDialog", null);
        }
        if (loading != null) {
            String title = "";
            String message = "Loading Application...";
            if (loading.length() > 0) {
                int comma = loading.indexOf(44);
                if (comma > 0) {
                    title = loading.substring(0, comma);
                    message = loading.substring(comma + 1);
                } else {
                    title = "";
                    message = loading;
                }
            }
            spinnerStart(title, message);
        }
    }

    public void loadUrl(String url, int time) {
        if (this.appView == null) {
            init();
        }
        this.splashscreenTime = time;
        this.appView.loadUrl(url, time);
    }

    @Override // org.apache.cordova.api.CordovaInterface
    @Deprecated
    public void cancelLoadUrl() {
        this.cancelLoadUrl = true;
    }

    public void clearCache() {
        if (this.appView == null) {
            init();
        }
        this.appView.clearCache(true);
    }

    public void clearHistory() {
        this.appView.clearHistory();
    }

    public boolean backHistory() {
        if (this.appView != null) {
            return this.appView.backHistory();
        }
        return false;
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public boolean getBooleanProperty(String name, boolean defaultValue) {
        Boolean p;
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            try {
                p = (Boolean) bundle.get(name);
            } catch (ClassCastException e) {
                String s = bundle.get(name).toString();
                if ("true".equals(s)) {
                    p = true;
                } else {
                    p = false;
                }
            }
            return p != null ? p.booleanValue() : defaultValue;
        }
        return defaultValue;
    }

    public int getIntegerProperty(String name, int defaultValue) {
        Integer p;
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            try {
                p = (Integer) bundle.get(name);
            } catch (ClassCastException e) {
                p = Integer.valueOf(Integer.parseInt(bundle.get(name).toString()));
            }
            return p != null ? p.intValue() : defaultValue;
        }
        return defaultValue;
    }

    public String getStringProperty(String name, String defaultValue) {
        String p;
        Bundle bundle = getIntent().getExtras();
        return (bundle == null || (p = bundle.getString(name)) == null) ? defaultValue : p;
    }

    public double getDoubleProperty(String name, double defaultValue) {
        Double p;
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            try {
                p = (Double) bundle.get(name);
            } catch (ClassCastException e) {
                p = Double.valueOf(Double.parseDouble(bundle.get(name).toString()));
            }
            return p != null ? p.doubleValue() : defaultValue;
        }
        return defaultValue;
    }

    public void setBooleanProperty(String name, boolean value) {
        getIntent().putExtra(name, value);
    }

    public void setIntegerProperty(String name, int value) {
        getIntent().putExtra(name, value);
    }

    public void setStringProperty(String name, String value) {
        getIntent().putExtra(name, value);
    }

    public void setDoubleProperty(String name, double value) {
        getIntent().putExtra(name, value);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        if (this.activityState != ACTIVITY_EXITING && this.appView != null) {
            this.appView.loadUrl("javascript:try{cordova.fireDocumentEvent('pause');}catch(e){console.log('exception firing pause event from native');};");
            if (this.appView.pluginManager != null) {
                this.appView.pluginManager.onPause(this.keepRunning);
            }
            if (!this.keepRunning) {
                this.appView.pauseTimers();
            }
            removeSplashScreen();
        }
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (this.appView != null && this.appView.pluginManager != null) {
            this.appView.pluginManager.onNewIntent(intent);
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.activityState == ACTIVITY_STARTING) {
            this.activityState = ACTIVITY_RUNNING;
            return;
        }
        if (this.appView != null) {
            this.appView.loadUrl("javascript:try{cordova.fireDocumentEvent('resume');}catch(e){console.log('exception firing resume event from native');};");
            if (this.appView.pluginManager != null) {
                this.appView.pluginManager.onResume(this.keepRunning || this.activityResultKeepRunning);
            }
            if (!this.keepRunning || this.activityResultKeepRunning) {
                if (this.activityResultKeepRunning) {
                    this.keepRunning = this.activityResultKeepRunning;
                    this.activityResultKeepRunning = false;
                }
                this.appView.resumeTimers();
            }
        }
    }

    @Override // android.app.Activity
    public void onDestroy() {
        LOG.d(TAG, "onDestroy()");
        super.onDestroy();
        removeSplashScreen();
        if (this.appView != null) {
            this.appView.loadUrl("javascript:try{cordova.require('cordova/channel').onDestroy.fire();}catch(e){console.log('exception firing destroy event from native');};");
            this.appView.loadUrl("about:blank");
            if (this.appView.pluginManager != null) {
                this.appView.pluginManager.onDestroy();
                return;
            }
            return;
        }
        endActivity();
    }

    public void postMessage(String id, Object data) {
        if (this.appView != null) {
            this.appView.postMessage(id, data);
        }
    }

    public void addService(String serviceType, String className) {
        if (this.appView != null && this.appView.pluginManager != null) {
            this.appView.pluginManager.addService(serviceType, className);
        }
    }

    public void sendJavascript(String statement) {
        if (this.appView != null && this.appView.callbackServer != null) {
            this.appView.callbackServer.sendJavascript(statement);
        }
    }

    public void spinnerStart(String title, String message) {
        if (this.spinnerDialog != null) {
            this.spinnerDialog.dismiss();
            this.spinnerDialog = null;
        }
        this.spinnerDialog = ProgressDialog.show(this, title, message, true, true, new DialogInterface.OnCancelListener() { // from class: org.apache.cordova.DroidGap.1
            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialog) {
                this.spinnerDialog = null;
            }
        });
    }

    public void spinnerStop() {
        if (this.spinnerDialog != null) {
            this.spinnerDialog.dismiss();
            this.spinnerDialog = null;
        }
    }

    public void endActivity() {
        this.activityState = ACTIVITY_EXITING;
        super.finish();
    }

    @Override // org.apache.cordova.api.CordovaInterface
    public void startActivityForResult(IPlugin command, Intent intent, int requestCode) {
        this.activityResultCallback = command;
        this.activityResultKeepRunning = this.keepRunning;
        if (command != null) {
            this.keepRunning = false;
        }
        super.startActivityForResult(intent, requestCode);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        IPlugin callback = this.activityResultCallback;
        if (callback != null) {
            callback.onActivityResult(requestCode, resultCode, intent);
        }
    }

    @Override // org.apache.cordova.api.CordovaInterface
    public void setActivityResultCallback(IPlugin plugin) {
        this.activityResultCallback = plugin;
    }

    public void onReceivedError(int errorCode, final String description, final String failingUrl) {
        spinnerStop();
        final String errorUrl = getStringProperty("errorUrl", null);
        if (errorUrl != null && ((errorUrl.startsWith("file://") || errorUrl.indexOf(this.baseUrl) == 0 || this.appView.isUrlWhiteListed(errorUrl)) && !failingUrl.equals(errorUrl))) {
            runOnUiThread(new Runnable() { // from class: org.apache.cordova.DroidGap.2
                @Override // java.lang.Runnable
                public void run() {
                    this.appView.showWebPage(errorUrl, false, true, null);
                }
            });
        } else {
            final boolean exit = errorCode != -2;
            runOnUiThread(new Runnable() { // from class: org.apache.cordova.DroidGap.3
                @Override // java.lang.Runnable
                public void run() {
                    if (exit) {
                        this.appView.setVisibility(8);
                        this.displayError("Application Error", description + " (" + failingUrl + ")", "OK", exit);
                    }
                }
            });
        }
    }

    public void displayError(final String title, final String message, final String button, final boolean exit) {
        runOnUiThread(new Runnable() { // from class: org.apache.cordova.DroidGap.4
            @Override // java.lang.Runnable
            public void run() {
                try {
                    AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                    dlg.setMessage(message);
                    dlg.setTitle(title);
                    dlg.setCancelable(false);
                    dlg.setPositiveButton(button, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.DroidGap.4.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            if (exit) {
                                this.endActivity();
                            }
                        }
                    });
                    dlg.create();
                    dlg.show();
                } catch (Exception e) {
                    DroidGap.this.finish();
                }
            }
        });
    }

    public boolean isUrlWhiteListed(String url) {
        if (this.appView != null) {
            return this.appView.isUrlWhiteListed(url);
        }
        return false;
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        postMessage("onCreateOptionsMenu", menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        postMessage("onPrepareOptionsMenu", menu);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        postMessage("onOptionsItemSelected", item);
        return true;
    }

    @Override // org.apache.cordova.api.CordovaInterface
    public Context getContext() {
        LOG.d(TAG, "This will be deprecated December 2012");
        return this;
    }

    public void showWebPage(String url, boolean openExternal, boolean clearHistory, HashMap<String, Object> params) {
        if (this.appView != null) {
            this.appView.showWebPage(url, openExternal, clearHistory, params);
        }
    }

    public void removeSplashScreen() {
        if (this.splashDialog != null && this.splashDialog.isShowing()) {
            this.splashDialog.dismiss();
            this.splashDialog = null;
        }
    }

    protected void showSplashScreen(final int time) {
        Runnable runnable = new Runnable() { // from class: org.apache.cordova.DroidGap.5
            @Override // java.lang.Runnable
            public void run() {
                Display display = DroidGap.this.getWindowManager().getDefaultDisplay();
                LinearLayout root = new LinearLayout(this.getActivity());
                root.setMinimumHeight(display.getHeight());
                root.setMinimumWidth(display.getWidth());
                root.setOrientation(1);
                root.setBackgroundColor(this.getIntegerProperty("backgroundColor", -16777216));
                root.setLayoutParams(new LinearLayout.LayoutParams(-1, -1, 0.0f));
                root.setBackgroundResource(this.splashscreen);
                DroidGap.this.splashDialog = new Dialog(this, R.style.Theme.Translucent.NoTitleBar);
                if ((DroidGap.this.getWindow().getAttributes().flags & 1024) == 1024) {
                    DroidGap.this.splashDialog.getWindow().setFlags(1024, 1024);
                }
                DroidGap.this.splashDialog.setContentView(root);
                DroidGap.this.splashDialog.setCancelable(false);
                DroidGap.this.splashDialog.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() { // from class: org.apache.cordova.DroidGap.5.1
                    @Override // java.lang.Runnable
                    public void run() {
                        DroidGap.this.removeSplashScreen();
                    }
                }, time);
            }
        };
        runOnUiThread(runnable);
    }

    @Override // org.apache.cordova.api.CordovaInterface
    public Object onMessage(String id, Object data) {
        LOG.d(TAG, "onMessage(" + id + "," + data + ")");
        if ("splashscreen".equals(id)) {
            if ("hide".equals(data.toString())) {
                removeSplashScreen();
                return null;
            }
            this.splashscreen = getIntegerProperty("splashscreen", 0);
            showSplashScreen(this.splashscreenTime);
            return null;
        }
        if ("spinner".equals(id)) {
            if ("stop".equals(data.toString())) {
                spinnerStop();
                this.appView.setVisibility(0);
                return null;
            }
            return null;
        }
        if ("onReceivedError".equals(id)) {
            JSONObject d = (JSONObject) data;
            try {
                onReceivedError(d.getInt("errorCode"), d.getString("description"), d.getString("url"));
                return null;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }
        if ("exit".equals(id)) {
            endActivity();
            return null;
        }
        return null;
    }
}
