package org.apache.cordova;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Vibrator;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
public class Notification extends Plugin {
    public int confirmResult = -1;
    public ProgressDialog spinnerDialog = null;
    public ProgressDialog progressDialog = null;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult.Status status = PluginResult.Status.OK;
        try {
            if (action.equals("beep")) {
                beep(args.getLong(0));
            } else if (action.equals("vibrate")) {
                vibrate(args.getLong(0));
            } else {
                if (action.equals("alert")) {
                    alert(args.getString(0), args.getString(1), args.getString(2), callbackId);
                    PluginResult r = new PluginResult(PluginResult.Status.NO_RESULT);
                    r.setKeepCallback(true);
                    return r;
                }
                if (action.equals("confirm")) {
                    confirm(args.getString(0), args.getString(1), args.getString(2), callbackId);
                    PluginResult r2 = new PluginResult(PluginResult.Status.NO_RESULT);
                    r2.setKeepCallback(true);
                    return r2;
                }
                if (action.equals("activityStart")) {
                    activityStart(args.getString(0), args.getString(1));
                } else if (action.equals("activityStop")) {
                    activityStop();
                } else if (action.equals("progressStart")) {
                    progressStart(args.getString(0), args.getString(1));
                } else if (action.equals("progressValue")) {
                    progressValue(args.getInt(0));
                } else if (action.equals("progressStop")) {
                    progressStop();
                }
            }
            return new PluginResult(status, "");
        } catch (JSONException e) {
            return new PluginResult(PluginResult.Status.JSON_EXCEPTION);
        }
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        return action.equals("alert") || action.equals("confirm") || action.equals("activityStart") || action.equals("activityStop") || action.equals("progressStart") || action.equals("progressValue") || action.equals("progressStop");
    }

    public void beep(long count) {
        Uri ringtone = RingtoneManager.getDefaultUri(2);
        Ringtone notification = RingtoneManager.getRingtone(this.cordova.getActivity().getBaseContext(), ringtone);
        if (notification != null) {
            for (long i = 0; i < count; i++) {
                notification.play();
                long timeout = 5000;
                while (notification.isPlaying() && timeout > 0) {
                    timeout -= 100;
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }
    }

    public void vibrate(long time) {
        if (time == 0) {
            time = 500;
        }
        Vibrator vibrator = (Vibrator) this.cordova.getActivity().getSystemService("vibrator");
        vibrator.vibrate(time);
    }

    public synchronized void alert(final String message, final String title, final String buttonLabel, final String callbackId) {
        final CordovaInterface cordova = this.cordova;
        Runnable runnable = new Runnable() { // from class: org.apache.cordova.Notification.1
            @Override // java.lang.Runnable
            public void run() {
                AlertDialog.Builder dlg = new AlertDialog.Builder(cordova.getActivity());
                dlg.setMessage(message);
                dlg.setTitle(title);
                dlg.setCancelable(false);
                dlg.setPositiveButton(buttonLabel, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.Notification.1.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        this.success(new PluginResult(PluginResult.Status.OK, 0), callbackId);
                    }
                });
                dlg.create();
                dlg.show();
            }
        };
        this.cordova.getActivity().runOnUiThread(runnable);
    }

    public synchronized void confirm(final String message, final String title, String buttonLabels, final String callbackId) {
        final CordovaInterface cordova = this.cordova;
        final String[] fButtons = buttonLabels.split(",");
        Runnable runnable = new Runnable() { // from class: org.apache.cordova.Notification.2
            @Override // java.lang.Runnable
            public void run() {
                AlertDialog.Builder dlg = new AlertDialog.Builder(cordova.getActivity());
                dlg.setMessage(message);
                dlg.setTitle(title);
                dlg.setCancelable(false);
                if (fButtons.length > 0) {
                    dlg.setNegativeButton(fButtons[0], new DialogInterface.OnClickListener() { // from class: org.apache.cordova.Notification.2.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            this.success(new PluginResult(PluginResult.Status.OK, 1), callbackId);
                        }
                    });
                }
                if (fButtons.length > 1) {
                    dlg.setNeutralButton(fButtons[1], new DialogInterface.OnClickListener() { // from class: org.apache.cordova.Notification.2.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            this.success(new PluginResult(PluginResult.Status.OK, 2), callbackId);
                        }
                    });
                }
                if (fButtons.length > 2) {
                    dlg.setPositiveButton(fButtons[2], new DialogInterface.OnClickListener() { // from class: org.apache.cordova.Notification.2.3
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            this.success(new PluginResult(PluginResult.Status.OK, 3), callbackId);
                        }
                    });
                }
                dlg.create();
                dlg.show();
            }
        };
        this.cordova.getActivity().runOnUiThread(runnable);
    }

    public synchronized void activityStart(final String title, final String message) {
        if (this.spinnerDialog != null) {
            this.spinnerDialog.dismiss();
            this.spinnerDialog = null;
        }
        final CordovaInterface cordova = this.cordova;
        Runnable runnable = new Runnable() { // from class: org.apache.cordova.Notification.3
            @Override // java.lang.Runnable
            public void run() {
                this.spinnerDialog = ProgressDialog.show(cordova.getActivity(), title, message, true, true, new DialogInterface.OnCancelListener() { // from class: org.apache.cordova.Notification.3.1
                    @Override // android.content.DialogInterface.OnCancelListener
                    public void onCancel(DialogInterface dialog) {
                        this.spinnerDialog = null;
                    }
                });
            }
        };
        this.cordova.getActivity().runOnUiThread(runnable);
    }

    public synchronized void activityStop() {
        if (this.spinnerDialog != null) {
            this.spinnerDialog.dismiss();
            this.spinnerDialog = null;
        }
    }

    public synchronized void progressStart(final String title, final String message) {
        if (this.progressDialog != null) {
            this.progressDialog.dismiss();
            this.progressDialog = null;
        }
        final CordovaInterface cordova = this.cordova;
        Runnable runnable = new Runnable() { // from class: org.apache.cordova.Notification.4
            @Override // java.lang.Runnable
            public void run() {
                this.progressDialog = new ProgressDialog(cordova.getActivity());
                this.progressDialog.setProgressStyle(1);
                this.progressDialog.setTitle(title);
                this.progressDialog.setMessage(message);
                this.progressDialog.setCancelable(true);
                this.progressDialog.setMax(100);
                this.progressDialog.setProgress(0);
                this.progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: org.apache.cordova.Notification.4.1
                    @Override // android.content.DialogInterface.OnCancelListener
                    public void onCancel(DialogInterface dialog) {
                        this.progressDialog = null;
                    }
                });
                this.progressDialog.show();
            }
        };
        this.cordova.getActivity().runOnUiThread(runnable);
    }

    public synchronized void progressValue(int value) {
        if (this.progressDialog != null) {
            this.progressDialog.setProgress(value);
        }
    }

    public synchronized void progressStop() {
        if (this.progressDialog != null) {
            this.progressDialog.dismiss();
            this.progressDialog = null;
        }
    }
}
