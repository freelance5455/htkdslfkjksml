package org.apache.cordova;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import java.io.File;

/* JADX INFO: loaded from: classes.dex */
public class DirectoryManager {
    private static final String LOG_TAG = "DirectoryManager";

    protected static boolean testFileExists(String name) {
        if (testSaveLocationExists() && !name.equals("")) {
            File path = Environment.getExternalStorageDirectory();
            File newPath = constructFilePaths(path.toString(), name);
            boolean status = newPath.exists();
            return status;
        }
        return false;
    }

    protected static long getFreeDiskSpace(boolean checkInternal) {
        long freeSpace;
        String status = Environment.getExternalStorageState();
        if (status.equals("mounted")) {
            freeSpace = freeSpaceCalculation(Environment.getExternalStorageDirectory().getPath());
        } else if (checkInternal) {
            freeSpace = freeSpaceCalculation("/");
        } else {
            return -1L;
        }
        return freeSpace;
    }

    private static long freeSpaceCalculation(String path) {
        StatFs stat = new StatFs(path);
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return (availableBlocks * blockSize) / 1024;
    }

    protected static boolean testSaveLocationExists() {
        String sDCardStatus = Environment.getExternalStorageState();
        if (sDCardStatus.equals("mounted")) {
            return true;
        }
        return false;
    }

    private static File constructFilePaths(String file1, String file2) {
        if (file2.startsWith(file1)) {
            File newPath = new File(file2);
            return newPath;
        }
        File newPath2 = new File(file1 + "/" + file2);
        return newPath2;
    }

    protected static String getTempDirectoryPath(Context ctx) {
        File cache;
        if (Environment.getExternalStorageState().equals("mounted")) {
            cache = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data/" + ctx.getPackageName() + "/cache/");
        } else {
            cache = ctx.getCacheDir();
        }
        if (!cache.exists()) {
            cache.mkdirs();
        }
        return cache.getAbsolutePath();
    }
}
