package org.apache.cordova.file;

/* JADX INFO: loaded from: classes.dex */
public class NoModificationAllowedException extends Exception {
    public NoModificationAllowedException(String message) {
        super(message);
    }
}
