package org.apache.cordova.file;

/* JADX INFO: loaded from: classes.dex */
public class InvalidModificationException extends Exception {
    public InvalidModificationException(String message) {
        super(message);
    }
}
