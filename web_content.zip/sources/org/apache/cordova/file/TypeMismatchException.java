package org.apache.cordova.file;

/* JADX INFO: loaded from: classes.dex */
public class TypeMismatchException extends Exception {
    public TypeMismatchException(String message) {
        super(message);
    }
}
