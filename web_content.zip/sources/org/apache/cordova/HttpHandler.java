package org.apache.cordova;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

/* JADX INFO: loaded from: classes.dex */
public class HttpHandler {
    protected Boolean get(String url, String file) {
        HttpEntity entity = getHttpEntity(url);
        try {
            writeToDisk(entity, file);
            try {
                entity.consumeContent();
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            return false;
        }
    }

    private HttpEntity getHttpEntity(String url) {
        try {
            DefaultHttpClient httpclient = new DefaultHttpClient();
            HttpGet httpget = new HttpGet(url);
            HttpResponse response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity();
            return entity;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void writeToDisk(HttpEntity entity, String file) throws IllegalStateException, IOException {
        String FilePath = "/sdcard/" + file;
        InputStream in = entity.getContent();
        byte[] buff = new byte[1024];
        FileOutputStream out = new FileOutputStream(FilePath);
        while (true) {
            int numread = in.read(buff);
            if (numread > 0) {
                out.write(buff, 0, numread);
            } else {
                out.flush();
                out.close();
                return;
            }
        }
    }
}
