package org.apache.cordova;

import android.net.Uri;
import android.util.Log;
import android.webkit.CookieManager;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class FileTransfer extends Plugin {
    private static final String BOUNDARY = "*****";
    private static final String LINE_END = "\r\n";
    private static final String LINE_START = "--";
    private static final String LOG_TAG = "FileTransfer";
    public static int FILE_NOT_FOUND_ERR = 1;
    public static int INVALID_URL_ERR = 2;
    public static int CONNECTION_ERR = 3;
    static final HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() { // from class: org.apache.cordova.FileTransfer.1
        @Override // javax.net.ssl.HostnameVerifier
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    };
    private SSLSocketFactory defaultSSLSocketFactory = null;
    private HostnameVerifier defaultHostnameVerifier = null;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        try {
            String source = URLDecoder.decode(args.getString(0));
            String target = args.getString(1);
            if (action.equals("upload")) {
                return upload(source, target, args);
            }
            if (action.equals("download")) {
                return download(source, target);
            }
            return new PluginResult(PluginResult.Status.INVALID_ACTION);
        } catch (JSONException e) {
            Log.d(LOG_TAG, "Missing source or target");
            return new PluginResult(PluginResult.Status.JSON_EXCEPTION, "Missing source or target");
        }
    }

    private PluginResult upload(String source, String target, JSONArray args) {
        PluginResult pluginResult;
        HttpURLConnection conn;
        Log.d(LOG_TAG, "upload " + source + " to " + target);
        HttpURLConnection conn2 = null;
        try {
            try {
                try {
                    try {
                        try {
                            String fileKey = getArgument(args, 2, "file");
                            String fileName = getArgument(args, 3, "image.jpg");
                            String mimeType = getArgument(args, 4, "image/jpeg");
                            JSONObject params = args.optJSONObject(5);
                            if (params == null) {
                                params = new JSONObject();
                            }
                            boolean trustEveryone = args.optBoolean(6);
                            boolean chunkedMode = args.optBoolean(7) || args.isNull(7);
                            Log.d(LOG_TAG, "fileKey: " + fileKey);
                            Log.d(LOG_TAG, "fileName: " + fileName);
                            Log.d(LOG_TAG, "mimeType: " + mimeType);
                            Log.d(LOG_TAG, "params: " + params);
                            Log.d(LOG_TAG, "trustEveryone: " + trustEveryone);
                            Log.d(LOG_TAG, "chunkedMode: " + chunkedMode);
                            FileUploadResult result = new FileUploadResult();
                            FileInputStream fileInputStream = (FileInputStream) getPathFromUri(source);
                            URL url = new URL(target);
                            if (!url.getProtocol().toLowerCase().equals("https")) {
                                conn = (HttpURLConnection) url.openConnection();
                            } else if (trustEveryone) {
                                trustAllHosts();
                                HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
                                this.defaultHostnameVerifier = https.getHostnameVerifier();
                                https.setHostnameVerifier(DO_NOT_VERIFY);
                                conn = https;
                            } else {
                                conn = (HttpsURLConnection) url.openConnection();
                            }
                            conn.setDoInput(true);
                            conn.setDoOutput(true);
                            conn.setUseCaches(false);
                            conn.setRequestMethod("POST");
                            conn.setRequestProperty("Connection", "Keep-Alive");
                            conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=*****");
                            try {
                                JSONObject headers = params.getJSONObject("headers");
                                Iterator<String> itKeys = headers.keys();
                                while (itKeys.hasNext()) {
                                    String headerKey = itKeys.next().toString();
                                    conn.setRequestProperty(headerKey, headers.getString(headerKey));
                                }
                            } catch (JSONException e) {
                            }
                            String cookie = CookieManager.getInstance().getCookie(target);
                            if (cookie != null) {
                                conn.setRequestProperty("Cookie", cookie);
                            }
                            String extraParams = "";
                            try {
                                Iterator<String> itKeys2 = params.keys();
                                while (itKeys2.hasNext()) {
                                    Object key = itKeys2.next();
                                    if (!String.valueOf(key).equals("headers")) {
                                        extraParams = ((((extraParams + "--*****\r\n") + "Content-Disposition: form-data; name=\"" + key.toString() + "\";") + "\r\n\r\n") + params.getString(key.toString())) + LINE_END;
                                    }
                                }
                            } catch (JSONException e2) {
                                Log.e(LOG_TAG, e2.getMessage(), e2);
                            }
                            byte[] extraBytes = ((extraParams + "--*****\r\n") + "Content-Disposition: form-data; name=\"" + fileKey + "\"; filename=\"").getBytes("UTF-8");
                            String midParams = "\"\r\nContent-Type: " + mimeType + LINE_END + LINE_END;
                            byte[] fileNameBytes = fileName.getBytes("UTF-8");
                            if (chunkedMode) {
                                conn.setChunkedStreamingMode(8096);
                            } else {
                                int stringLength = extraBytes.length + midParams.length() + "\r\n--*****--\r\n".length() + fileNameBytes.length;
                                Log.d(LOG_TAG, "String Length: " + stringLength);
                                int fixedLength = ((int) fileInputStream.getChannel().size()) + stringLength;
                                Log.d(LOG_TAG, "Content Length: " + fixedLength);
                                conn.setFixedLengthStreamingMode(fixedLength);
                            }
                            DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                            dos.write(extraBytes);
                            dos.write(fileNameBytes);
                            dos.writeBytes(midParams);
                            int bytesAvailable = fileInputStream.available();
                            int bufferSize = Math.min(bytesAvailable, 8096);
                            byte[] buffer = new byte[bufferSize];
                            int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                            long totalBytes = 0;
                            while (bytesRead > 0) {
                                totalBytes += (long) bytesRead;
                                result.setBytesSent(totalBytes);
                                dos.write(buffer, 0, bufferSize);
                                int bytesAvailable2 = fileInputStream.available();
                                bufferSize = Math.min(bytesAvailable2, 8096);
                                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                            }
                            dos.writeBytes("\r\n--*****--\r\n");
                            fileInputStream.close();
                            dos.flush();
                            dos.close();
                            StringBuffer responseString = new StringBuffer("");
                            try {
                                DataInputStream inStream = new DataInputStream(conn.getInputStream());
                                while (true) {
                                    String line = inStream.readLine();
                                    if (line == null) {
                                        break;
                                    }
                                    responseString.append(line);
                                }
                                Log.d(LOG_TAG, "got response from server");
                                Log.d(LOG_TAG, responseString.toString());
                                result.setResponseCode(conn.getResponseCode());
                                result.setResponse(responseString.toString());
                                inStream.close();
                                if (trustEveryone && url.getProtocol().toLowerCase().equals("https")) {
                                    ((HttpsURLConnection) conn).setHostnameVerifier(this.defaultHostnameVerifier);
                                    HttpsURLConnection.setDefaultSSLSocketFactory(this.defaultSSLSocketFactory);
                                }
                                Log.d(LOG_TAG, "****** About to return a result from upload");
                                pluginResult = new PluginResult(PluginResult.Status.OK, result.toJSONObject());
                                if (conn != null) {
                                    conn.disconnect();
                                }
                            } catch (FileNotFoundException e3) {
                                Log.e(LOG_TAG, e3.toString(), e3);
                                throw new IOException("Received error from server");
                            }
                        } catch (FileNotFoundException e4) {
                            JSONObject error = createFileTransferError(FILE_NOT_FOUND_ERR, source, target, (HttpURLConnection) null);
                            Log.e(LOG_TAG, error.toString(), e4);
                            pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error);
                            if (0 != 0) {
                                conn2.disconnect();
                            }
                        }
                    } catch (JSONException e5) {
                        Log.e(LOG_TAG, e5.getMessage(), e5);
                        pluginResult = new PluginResult(PluginResult.Status.JSON_EXCEPTION);
                        if (0 != 0) {
                            conn2.disconnect();
                        }
                    }
                } catch (Throwable t) {
                    JSONObject error2 = createFileTransferError(CONNECTION_ERR, source, target, (HttpURLConnection) null);
                    Log.e(LOG_TAG, error2.toString(), t);
                    pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error2);
                    if (0 != 0) {
                        conn2.disconnect();
                    }
                }
            } catch (MalformedURLException e6) {
                JSONObject error3 = createFileTransferError(INVALID_URL_ERR, source, target, (HttpURLConnection) null);
                Log.e(LOG_TAG, error3.toString(), e6);
                pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error3);
                if (0 != 0) {
                    conn2.disconnect();
                }
            } catch (IOException e7) {
                JSONObject error4 = createFileTransferError(CONNECTION_ERR, source, target, (HttpURLConnection) null);
                Log.e(LOG_TAG, error4.toString(), e7);
                pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error4);
                if (0 != 0) {
                    conn2.disconnect();
                }
            }
            return pluginResult;
        } catch (Throwable th) {
            if (0 != 0) {
                conn2.disconnect();
            }
            throw th;
        }
    }

    private void trustAllHosts() {
        TrustManager[] trustAllCerts = {new X509TrustManager() { // from class: org.apache.cordova.FileTransfer.2
            @Override // javax.net.ssl.X509TrustManager
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            @Override // javax.net.ssl.X509TrustManager
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }

            @Override // javax.net.ssl.X509TrustManager
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }
        }};
        try {
            this.defaultSSLSocketFactory = HttpsURLConnection.getDefaultSSLSocketFactory();
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            Log.e(LOG_TAG, e.getMessage(), e);
        }
    }

    private JSONObject createFileTransferError(int errorCode, String source, String target, HttpURLConnection connection) {
        Integer httpStatus = null;
        if (connection != null) {
            try {
                httpStatus = Integer.valueOf(connection.getResponseCode());
            } catch (IOException e) {
                Log.w(LOG_TAG, "Error getting HTTP status code from connection.", e);
            }
        }
        return createFileTransferError(errorCode, source, target, httpStatus);
    }

    private JSONObject createFileTransferError(int errorCode, String source, String target, Integer httpStatus) {
        JSONObject error = null;
        try {
            JSONObject error2 = new JSONObject();
            try {
                error2.put("code", errorCode);
                error2.put("source", source);
                error2.put("target", target);
                if (httpStatus != null) {
                    error2.put("http_status", httpStatus);
                }
                return error2;
            } catch (JSONException e) {
                e = e;
                error = error2;
                Log.e(LOG_TAG, e.getMessage(), e);
                return error;
            }
        } catch (JSONException e2) {
            e = e2;
        }
    }

    private String getArgument(JSONArray args, int position, String defaultString) {
        if (args.length() < position) {
            return defaultString;
        }
        String arg = args.optString(position);
        if (arg == null || "null".equals(arg)) {
            return defaultString;
        }
        return arg;
    }

    private PluginResult download(String source, String target) {
        PluginResult pluginResult;
        Log.d(LOG_TAG, "download " + source + " to " + target);
        HttpURLConnection connection = null;
        try {
            try {
                try {
                    try {
                        File file = getFileFromPath(target);
                        file.getParentFile().mkdirs();
                        if (this.webView.isUrlWhiteListed(source)) {
                            URL url = new URL(source);
                            HttpURLConnection connection2 = (HttpURLConnection) url.openConnection();
                            connection2.setRequestMethod("GET");
                            String cookie = CookieManager.getInstance().getCookie(source);
                            if (cookie != null) {
                                connection2.setRequestProperty("cookie", cookie);
                            }
                            connection2.connect();
                            Log.d(LOG_TAG, "Download file: " + url);
                            connection2.connect();
                            Log.d(LOG_TAG, "Download file:" + url);
                            InputStream inputStream = connection2.getInputStream();
                            byte[] buffer = new byte[1024];
                            FileOutputStream outputStream = new FileOutputStream(file);
                            while (true) {
                                int bytesRead = inputStream.read(buffer);
                                if (bytesRead <= 0) {
                                    break;
                                }
                                outputStream.write(buffer, 0, bytesRead);
                            }
                            outputStream.close();
                            Log.d(LOG_TAG, "Saved file: " + target);
                            FileUtils fileUtil = new FileUtils();
                            JSONObject fileEntry = fileUtil.getEntry(file);
                            pluginResult = new PluginResult(PluginResult.Status.OK, fileEntry);
                            if (connection2 != null) {
                                connection2.disconnect();
                            }
                        } else {
                            Log.w(LOG_TAG, "Source URL is not in white list: '" + source + "'");
                            pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, createFileTransferError(CONNECTION_ERR, source, target, (Integer) 401));
                            if (0 != 0) {
                                connection.disconnect();
                            }
                        }
                    } catch (MalformedURLException e) {
                        JSONObject error = createFileTransferError(INVALID_URL_ERR, source, target, (HttpURLConnection) null);
                        Log.e(LOG_TAG, error.toString(), e);
                        pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error);
                        if (0 != 0) {
                            connection.disconnect();
                        }
                    }
                } catch (FileNotFoundException e2) {
                    JSONObject error2 = createFileTransferError(FILE_NOT_FOUND_ERR, source, target, (HttpURLConnection) null);
                    Log.e(LOG_TAG, error2.toString(), e2);
                    pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error2);
                    if (0 != 0) {
                        connection.disconnect();
                    }
                }
            } catch (Exception e3) {
                JSONObject error3 = createFileTransferError(CONNECTION_ERR, source, target, (HttpURLConnection) null);
                Log.e(LOG_TAG, error3.toString(), e3);
                pluginResult = new PluginResult(PluginResult.Status.IO_EXCEPTION, error3);
                if (0 != 0) {
                    connection.disconnect();
                }
            }
            return pluginResult;
        } catch (Throwable th) {
            if (0 != 0) {
                connection.disconnect();
            }
            throw th;
        }
    }

    private InputStream getPathFromUri(String path) throws FileNotFoundException {
        if (path.startsWith("content:")) {
            Uri uri = Uri.parse(path);
            return this.cordova.getActivity().getContentResolver().openInputStream(uri);
        }
        if (path.startsWith("file://")) {
            int question = path.indexOf("?");
            if (question == -1) {
                return new FileInputStream(path.substring(7));
            }
            return new FileInputStream(path.substring(7, question));
        }
        return new FileInputStream(path);
    }

    private File getFileFromPath(String path) throws FileNotFoundException {
        File file;
        if (path.startsWith("file://")) {
            file = new File(path.substring("file://".length()));
        } else {
            file = new File(path);
        }
        if (file.getParent() == null) {
            throw new FileNotFoundException();
        }
        return file;
    }
}
