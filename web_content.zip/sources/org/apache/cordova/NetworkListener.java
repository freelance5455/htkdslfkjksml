package org.apache.cordova;

import android.location.LocationManager;

/* JADX INFO: loaded from: classes.dex */
public class NetworkListener extends CordovaLocationListener {
    public NetworkListener(LocationManager locationManager, GeoBroker m) {
        super(locationManager, m, "[Cordova NetworkListener]");
    }
}
