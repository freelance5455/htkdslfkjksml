package org.apache.cordova;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import java.util.TimeZone;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.LOG;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class Device extends Plugin {
    public static final String TAG = "Device";
    public static String cordovaVersion = "2.0.0";
    public static String platform = "Android";
    public static String uuid;
    BroadcastReceiver telephonyReceiver = null;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void setContext(CordovaInterface cordova) {
        super.setContext(cordova);
        uuid = getUuid();
        initTelephonyReceiver();
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult pluginResult;
        PluginResult.Status status = PluginResult.Status.OK;
        try {
            if (action.equals("getDeviceInfo")) {
                JSONObject r = new JSONObject();
                r.put("uuid", uuid);
                r.put("version", getOSVersion());
                r.put("platform", platform);
                r.put("name", getProductName());
                r.put("cordova", cordovaVersion);
                pluginResult = new PluginResult(status, r);
            } else {
                pluginResult = new PluginResult(status, "");
            }
            return pluginResult;
        } catch (JSONException e) {
            return new PluginResult(PluginResult.Status.JSON_EXCEPTION);
        }
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        return action.equals("getDeviceInfo");
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onDestroy() {
        this.cordova.getActivity().unregisterReceiver(this.telephonyReceiver);
    }

    private void initTelephonyReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.PHONE_STATE");
        this.telephonyReceiver = new BroadcastReceiver() { // from class: org.apache.cordova.Device.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                if (intent != null && intent.getAction().equals("android.intent.action.PHONE_STATE") && intent.hasExtra("state")) {
                    String extraData = intent.getStringExtra("state");
                    if (extraData.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                        LOG.i(Device.TAG, "Telephone RINGING");
                        Device.this.webView.postMessage("telephone", "ringing");
                    } else if (extraData.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                        LOG.i(Device.TAG, "Telephone OFFHOOK");
                        Device.this.webView.postMessage("telephone", "offhook");
                    } else if (extraData.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                        LOG.i(Device.TAG, "Telephone IDLE");
                        Device.this.webView.postMessage("telephone", "idle");
                    }
                }
            }
        };
        this.cordova.getActivity().registerReceiver(this.telephonyReceiver, intentFilter);
    }

    public String getPlatform() {
        return platform;
    }

    public String getUuid() {
        String uuid2 = Settings.Secure.getString(this.cordova.getActivity().getContentResolver(), "android_id");
        return uuid2;
    }

    public String getCordovaVersion() {
        return cordovaVersion;
    }

    public String getModel() {
        String model = Build.MODEL;
        return model;
    }

    public String getProductName() {
        String productname = Build.PRODUCT;
        return productname;
    }

    public String getOSVersion() {
        String osversion = Build.VERSION.RELEASE;
        return osversion;
    }

    public String getSDKVersion() {
        String sdkversion = Build.VERSION.SDK;
        return sdkversion;
    }

    public String getTimeZoneID() {
        TimeZone tz = TimeZone.getDefault();
        return tz.getID();
    }
}
