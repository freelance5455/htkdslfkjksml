package org.apache.cordova;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.util.List;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class AccelListener extends Plugin implements SensorEventListener {
    private String callbackId;
    private Sensor mSensor;
    private SensorManager sensorManager;
    private int status;
    public static int STOPPED = 0;
    public static int STARTING = 1;
    public static int RUNNING = 2;
    public static int ERROR_FAILED_TO_START = 3;
    private int accuracy = 0;
    private float x = 0.0f;
    private float y = 0.0f;
    private float z = 0.0f;
    private long timestamp = 0;

    public AccelListener() {
        setStatus(STOPPED);
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void setContext(CordovaInterface cordova) {
        super.setContext(cordova);
        this.sensorManager = (SensorManager) cordova.getActivity().getSystemService("sensor");
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult.Status status = PluginResult.Status.NO_RESULT;
        PluginResult result = new PluginResult(status, "");
        result.setKeepCallback(true);
        if (action.equals("start")) {
            this.callbackId = callbackId;
            if (this.status != RUNNING) {
                start();
                return result;
            }
            return result;
        }
        if (action.equals("stop")) {
            if (this.status == RUNNING) {
                stop();
                return result;
            }
            return result;
        }
        return new PluginResult(PluginResult.Status.INVALID_ACTION);
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onDestroy() {
        stop();
    }

    private int start() {
        if (this.status == RUNNING || this.status == STARTING) {
            return this.status;
        }
        setStatus(STARTING);
        List<Sensor> list = this.sensorManager.getSensorList(1);
        if (list != null && list.size() > 0) {
            this.mSensor = list.get(0);
            this.sensorManager.registerListener(this, this.mSensor, 2);
            setStatus(STARTING);
            long timeout = 2000;
            while (this.status == STARTING && timeout > 0) {
                timeout -= 100;
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (timeout == 0) {
                setStatus(ERROR_FAILED_TO_START);
                fail(ERROR_FAILED_TO_START, "Accelerometer could not be started.");
            }
            return this.status;
        }
        setStatus(ERROR_FAILED_TO_START);
        fail(ERROR_FAILED_TO_START, "No sensors found to register accelerometer listening to.");
        return this.status;
    }

    private void stop() {
        if (this.status != STOPPED) {
            this.sensorManager.unregisterListener(this);
        }
        setStatus(STOPPED);
        this.accuracy = 0;
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (sensor.getType() == 1 && this.status != STOPPED) {
            this.accuracy = accuracy;
        }
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == 1 && this.status != STOPPED) {
            setStatus(RUNNING);
            if (this.accuracy >= 2) {
                this.timestamp = System.currentTimeMillis();
                this.x = event.values[0];
                this.y = event.values[1];
                this.z = event.values[2];
                win();
            }
        }
    }

    private void fail(int code, String message) {
        JSONObject errorObj = new JSONObject();
        try {
            errorObj.put("code", code);
            errorObj.put("message", message);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        PluginResult err = new PluginResult(PluginResult.Status.ERROR, errorObj);
        err.setKeepCallback(true);
        error(err, this.callbackId);
    }

    private void win() {
        PluginResult result = new PluginResult(PluginResult.Status.OK, getAccelerationJSON());
        result.setKeepCallback(true);
        success(result, this.callbackId);
    }

    private void setStatus(int status) {
        this.status = status;
    }

    private JSONObject getAccelerationJSON() {
        JSONObject r = new JSONObject();
        try {
            r.put("x", this.x);
            r.put("y", this.y);
            r.put("z", this.z);
            r.put("timestamp", this.timestamp);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return r;
    }
}
