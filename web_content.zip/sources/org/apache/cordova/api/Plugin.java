package org.apache.cordova.api;

import android.content.Intent;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public abstract class Plugin implements IPlugin {
    public CordovaInterface cordova;
    public LegacyContext ctx;
    public String id;
    public CordovaWebView webView;

    @Override // org.apache.cordova.api.IPlugin
    public abstract PluginResult execute(String str, JSONArray jSONArray, String str2);

    @Override // org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        return false;
    }

    @Override // org.apache.cordova.api.IPlugin
    public void setContext(CordovaInterface ctx) {
        this.cordova = ctx;
        this.ctx = new LegacyContext(this.cordova);
    }

    @Override // org.apache.cordova.api.IPlugin
    public void setView(CordovaWebView webView) {
        this.webView = webView;
    }

    @Override // org.apache.cordova.api.IPlugin
    public void onPause(boolean multitasking) {
    }

    @Override // org.apache.cordova.api.IPlugin
    public void onResume(boolean multitasking) {
    }

    @Override // org.apache.cordova.api.IPlugin
    public void onNewIntent(Intent intent) {
    }

    @Override // org.apache.cordova.api.IPlugin
    public void onDestroy() {
    }

    @Override // org.apache.cordova.api.IPlugin
    public Object onMessage(String id, Object data) {
        return null;
    }

    @Override // org.apache.cordova.api.IPlugin
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
    }

    @Override // org.apache.cordova.api.IPlugin
    public boolean onOverrideUrlLoading(String url) {
        return false;
    }

    public void sendJavascript(String statement) {
        this.webView.sendJavascript(statement);
    }

    public void success(PluginResult pluginResult, String callbackId) {
        this.webView.sendJavascript(pluginResult.toSuccessCallbackString(callbackId));
    }

    public void success(JSONObject message, String callbackId) {
        this.webView.sendJavascript(new PluginResult(PluginResult.Status.OK, message).toSuccessCallbackString(callbackId));
    }

    public void success(String message, String callbackId) {
        this.webView.sendJavascript(new PluginResult(PluginResult.Status.OK, message).toSuccessCallbackString(callbackId));
    }

    public void error(PluginResult pluginResult, String callbackId) {
        this.webView.sendJavascript(pluginResult.toErrorCallbackString(callbackId));
    }

    public void error(JSONObject message, String callbackId) {
        this.webView.sendJavascript(new PluginResult(PluginResult.Status.ERROR, message).toErrorCallbackString(callbackId));
    }

    public void error(String message, String callbackId) {
        this.webView.sendJavascript(new PluginResult(PluginResult.Status.ERROR, message).toErrorCallbackString(callbackId));
    }
}
