package org.apache.cordova.api;

import org.apache.cordova.CordovaWebView;

/* JADX INFO: loaded from: classes.dex */
public class PluginEntry {
    public boolean onload;
    public IPlugin plugin = null;
    public String pluginClass;
    public String service;

    public PluginEntry(String service, String pluginClass, boolean onload) {
        this.service = "";
        this.pluginClass = "";
        this.onload = false;
        this.service = service;
        this.pluginClass = pluginClass;
        this.onload = onload;
    }

    public IPlugin createPlugin(CordovaWebView webView, CordovaInterface ctx) {
        if (this.plugin != null) {
            return this.plugin;
        }
        try {
            Class c = getClassByName(this.pluginClass);
            if (isCordovaPlugin(c)) {
                this.plugin = (IPlugin) c.newInstance();
                this.plugin.setContext(ctx);
                this.plugin.setView(webView);
                return this.plugin;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error adding plugin " + this.pluginClass + ".");
        }
        return null;
    }

    private Class getClassByName(String clazz) throws ClassNotFoundException {
        if (clazz == null) {
            return null;
        }
        return Class.forName(clazz);
    }

    private boolean isCordovaPlugin(Class c) {
        if (c != null) {
            return Plugin.class.isAssignableFrom(c) || IPlugin.class.isAssignableFrom(c);
        }
        return false;
    }
}
