package org.apache.cordova.api;

import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class PluginResult {
    public static String[] StatusMessages = {"No result", "OK", "Class not found", "Illegal access", "Instantiation error", "Malformed url", "IO error", "Invalid action", "JSON error", "Error"};
    private boolean keepCallback = false;
    private final String message;
    private final int status;

    public enum Status {
        NO_RESULT,
        OK,
        CLASS_NOT_FOUND_EXCEPTION,
        ILLEGAL_ACCESS_EXCEPTION,
        INSTANTIATION_EXCEPTION,
        MALFORMED_URL_EXCEPTION,
        IO_EXCEPTION,
        INVALID_ACTION,
        JSON_EXCEPTION,
        ERROR
    }

    public PluginResult(Status status) {
        this.status = status.ordinal();
        this.message = "\"" + StatusMessages[this.status] + "\"";
    }

    public PluginResult(Status status, String message) {
        this.status = status.ordinal();
        this.message = JSONObject.quote(message);
    }

    public PluginResult(Status status, JSONArray message) {
        this.status = status.ordinal();
        this.message = message.toString();
    }

    public PluginResult(Status status, JSONObject message) {
        this.status = status.ordinal();
        this.message = message.toString();
    }

    public PluginResult(Status status, int i) {
        this.status = status.ordinal();
        this.message = "" + i;
    }

    public PluginResult(Status status, float f) {
        this.status = status.ordinal();
        this.message = "" + f;
    }

    public PluginResult(Status status, boolean b) {
        this.status = status.ordinal();
        this.message = "" + b;
    }

    public void setKeepCallback(boolean b) {
        this.keepCallback = b;
    }

    public int getStatus() {
        return this.status;
    }

    public String getMessage() {
        return this.message;
    }

    public boolean getKeepCallback() {
        return this.keepCallback;
    }

    public String getJSONString() {
        return "{\"status\":" + this.status + ",\"message\":" + this.message + ",\"keepCallback\":" + this.keepCallback + "}";
    }

    public String toSuccessCallbackString(String callbackId) {
        return "cordova.callbackSuccess('" + callbackId + "'," + getJSONString() + ");";
    }

    public String toErrorCallbackString(String callbackId) {
        return "cordova.callbackError('" + callbackId + "', " + getJSONString() + ");";
    }
}
