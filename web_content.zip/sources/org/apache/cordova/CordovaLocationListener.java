package org.apache.cordova;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class CordovaLocationListener implements LocationListener {
    public static int PERMISSION_DENIED = 1;
    public static int POSITION_UNAVAILABLE = 2;
    public static int TIMEOUT = 3;
    private String TAG;
    protected LocationManager locationManager;
    private GeoBroker owner;
    protected boolean running = false;
    public HashMap<String, String> watches = new HashMap<>();
    private List<String> callbacks = new ArrayList();

    public CordovaLocationListener(LocationManager manager, GeoBroker broker, String tag) {
        this.TAG = "[Cordova Location Listener]";
        this.locationManager = manager;
        this.owner = broker;
        this.TAG = tag;
    }

    protected void fail(int code, String message) {
        for (String callbackId : this.callbacks) {
            this.owner.fail(code, message, callbackId);
        }
        this.callbacks.clear();
        Iterator<Map.Entry<String, String>> it = this.watches.entrySet().iterator();
        while (it.hasNext()) {
            this.owner.fail(code, message, it.next().getValue());
        }
    }

    private void win(Location loc) {
        for (String callbackId : this.callbacks) {
            this.owner.win(loc, callbackId);
        }
        this.callbacks.clear();
        Iterator<Map.Entry<String, String>> it = this.watches.entrySet().iterator();
        while (it.hasNext()) {
            this.owner.win(loc, it.next().getValue());
        }
    }

    @Override // android.location.LocationListener
    public void onProviderDisabled(String provider) {
        Log.d(this.TAG, "Location provider '" + provider + "' disabled.");
        fail(POSITION_UNAVAILABLE, "GPS provider disabled.");
    }

    @Override // android.location.LocationListener
    public void onProviderEnabled(String provider) {
        Log.d(this.TAG, "Location provider " + provider + " has been enabled");
    }

    @Override // android.location.LocationListener
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d(this.TAG, "The status of the provider " + provider + " has changed");
        if (status == 0) {
            Log.d(this.TAG, provider + " is OUT OF SERVICE");
            fail(POSITION_UNAVAILABLE, "Provider " + provider + " is out of service.");
        } else if (status == 1) {
            Log.d(this.TAG, provider + " is TEMPORARILY_UNAVAILABLE");
        } else {
            Log.d(this.TAG, provider + " is AVAILABLE");
        }
    }

    @Override // android.location.LocationListener
    public void onLocationChanged(Location location) {
        Log.d(this.TAG, "The location has been updated!");
        win(location);
    }

    public int size() {
        return this.watches.size() + this.callbacks.size();
    }

    public void addWatch(String timerId, String callbackId) {
        this.watches.put(timerId, callbackId);
        if (size() == 1) {
            start();
        }
    }

    public void addCallback(String callbackId) {
        this.callbacks.add(callbackId);
        if (size() == 1) {
            start();
        }
    }

    public void clearWatch(String timerId) {
        if (this.watches.containsKey(timerId)) {
            this.watches.remove(timerId);
        }
        if (size() == 0) {
            stop();
        }
    }

    public void destroy() {
        stop();
    }

    protected void start() {
        if (!this.running) {
            if (this.locationManager.getProvider("network") != null) {
                this.running = true;
                this.locationManager.requestLocationUpdates("network", 60000L, 10.0f, this);
            } else {
                fail(POSITION_UNAVAILABLE, "Network provider is not available.");
            }
        }
    }

    private void stop() {
        if (this.running) {
            this.locationManager.removeUpdates(this);
            this.running = false;
        }
    }
}
