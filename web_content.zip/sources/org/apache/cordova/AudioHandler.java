package org.apache.cordova;

import android.media.AudioManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.cordova.AudioPlayer;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
public class AudioHandler extends Plugin {
    public static String TAG = "AudioHandler";
    HashMap<String, AudioPlayer> players = new HashMap<>();
    ArrayList<AudioPlayer> pausedForPhone = new ArrayList<>();

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult.Status status = PluginResult.Status.OK;
        try {
            if (action.equals("startRecordingAudio")) {
                startRecordingAudio(args.getString(0), args.getString(1));
            } else if (action.equals("stopRecordingAudio")) {
                stopRecordingAudio(args.getString(0));
            } else if (action.equals("startPlayingAudio")) {
                startPlayingAudio(args.getString(0), args.getString(1));
            } else if (action.equals("seekToAudio")) {
                seekToAudio(args.getString(0), args.getInt(1));
            } else if (action.equals("pausePlayingAudio")) {
                pausePlayingAudio(args.getString(0));
            } else if (action.equals("stopPlayingAudio")) {
                stopPlayingAudio(args.getString(0));
            } else if (action.equals("setVolume")) {
                try {
                    setVolume(args.getString(0), Float.parseFloat(args.getString(1)));
                } catch (NumberFormatException e) {
                }
            } else {
                if (action.equals("getCurrentPositionAudio")) {
                    float f = getCurrentPositionAudio(args.getString(0));
                    return new PluginResult(status, f);
                }
                if (action.equals("getDurationAudio")) {
                    float f2 = getDurationAudio(args.getString(0), args.getString(1));
                    return new PluginResult(status, f2);
                }
                if (action.equals("create")) {
                    String id = args.getString(0);
                    String src = args.getString(1);
                    AudioPlayer audio = new AudioPlayer(this, id, src);
                    this.players.put(id, audio);
                } else if (action.equals("release")) {
                    boolean b = release(args.getString(0));
                    return new PluginResult(status, b);
                }
            }
            return new PluginResult(status, "");
        } catch (JSONException e2) {
            e2.printStackTrace();
            return new PluginResult(PluginResult.Status.JSON_EXCEPTION);
        }
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        return action.equals("getCurrentPositionAudio") || action.equals("getDurationAudio");
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onDestroy() {
        for (AudioPlayer audio : this.players.values()) {
            audio.destroy();
        }
        this.players.clear();
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public Object onMessage(String id, Object data) {
        if (id.equals("telephone")) {
            if ("ringing".equals(data) || "offhook".equals(data)) {
                for (AudioPlayer audio : this.players.values()) {
                    if (audio.getState() == AudioPlayer.STATE.MEDIA_RUNNING.ordinal()) {
                        this.pausedForPhone.add(audio);
                        audio.pausePlaying();
                    }
                }
            } else if ("idle".equals(data)) {
                Iterator<AudioPlayer> it = this.pausedForPhone.iterator();
                while (it.hasNext()) {
                    it.next().startPlaying(null);
                }
                this.pausedForPhone.clear();
            }
        }
        return null;
    }

    private boolean release(String id) {
        if (!this.players.containsKey(id)) {
            return false;
        }
        AudioPlayer audio = this.players.get(id);
        this.players.remove(id);
        audio.destroy();
        return true;
    }

    public void startRecordingAudio(String id, String file) {
        AudioPlayer audio = this.players.get(id);
        if (audio == null) {
            audio = new AudioPlayer(this, id, file);
            this.players.put(id, audio);
        }
        audio.startRecording(file);
    }

    public void stopRecordingAudio(String id) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            audio.stopRecording();
            this.players.remove(id);
        }
    }

    public void startPlayingAudio(String id, String file) {
        AudioPlayer audio = this.players.get(id);
        if (audio == null) {
            audio = new AudioPlayer(this, id, file);
            this.players.put(id, audio);
        }
        audio.startPlaying(file);
    }

    public void seekToAudio(String id, int milliseconds) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            audio.seekToPlaying(milliseconds);
        }
    }

    public void pausePlayingAudio(String id) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            audio.pausePlaying();
        }
    }

    public void stopPlayingAudio(String id) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            audio.stopPlaying();
        }
    }

    public float getCurrentPositionAudio(String id) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            return audio.getCurrentPosition() / 1000.0f;
        }
        return -1.0f;
    }

    public float getDurationAudio(String id, String file) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            return audio.getDuration(file);
        }
        AudioPlayer audio2 = new AudioPlayer(this, id, file);
        this.players.put(id, audio2);
        return audio2.getDuration(file);
    }

    public void setAudioOutputDevice(int output) {
        AudioManager audiMgr = (AudioManager) this.cordova.getActivity().getSystemService("audio");
        if (output == 2) {
            audiMgr.setRouting(0, 2, -1);
        } else if (output == 1) {
            audiMgr.setRouting(0, 1, -1);
        } else {
            System.out.println("AudioHandler.setAudioOutputDevice() Error: Unknown output device.");
        }
    }

    public int getAudioOutputDevice() {
        AudioManager audiMgr = (AudioManager) this.cordova.getActivity().getSystemService("audio");
        if (audiMgr.getRouting(0) == 1) {
            return 1;
        }
        return audiMgr.getRouting(0) == 2 ? 2 : -1;
    }

    public void setVolume(String id, float volume) {
        AudioPlayer audio = this.players.get(id);
        if (audio != null) {
            audio.setVolume(volume);
        } else {
            System.out.println("AudioHandler.setVolume() Error: Unknown Audio Player " + id);
        }
    }
}
