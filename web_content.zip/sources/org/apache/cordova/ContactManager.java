package org.apache.cordova;

import org.apache.cordova.api.Plugin;

/* JADX INFO: loaded from: classes.dex */
public class ContactManager extends Plugin {
    public static final int INVALID_ARGUMENT_ERROR = 1;
    public static final int IO_ERROR = 4;
    private static final String LOG_TAG = "Contact Query";
    public static final int NOT_SUPPORTED_ERROR = 5;
    public static final int PENDING_OPERATION_ERROR = 3;
    public static final int PERMISSION_DENIED_ERROR = 20;
    public static final int TIMEOUT_ERROR = 2;
    public static final int UNKNOWN_ERROR = 0;
    private ContactAccessor contactAccessor;

    /* JADX WARN: Removed duplicated region for block: B:27:0x0094 A[Catch: JSONException -> 0x0044, TRY_LEAVE, TryCatch #0 {JSONException -> 0x0044, blocks: (B:9:0x0026, B:11:0x002e, B:15:0x0056, B:17:0x005e, B:19:0x006b, B:21:0x0073, B:27:0x0094, B:22:0x0079, B:24:0x0081, B:26:0x008e), top: B:30:0x0026 }] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:14:0x0045 -> B:29:0x0016). Please report as a decompilation issue!!! */
    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public org.apache.cordova.api.PluginResult execute(java.lang.String r9, org.json.JSONArray r10, java.lang.String r11) {
        /*
            r8 = this;
            org.apache.cordova.api.PluginResult$Status r4 = org.apache.cordova.api.PluginResult.Status.OK
            java.lang.String r3 = ""
            java.lang.String r5 = android.os.Build.VERSION.RELEASE
            java.lang.String r6 = "1."
            boolean r5 = r5.startsWith(r6)
            if (r5 == 0) goto L17
            org.apache.cordova.api.PluginResult r5 = new org.apache.cordova.api.PluginResult
            org.apache.cordova.api.PluginResult$Status r6 = org.apache.cordova.api.PluginResult.Status.ERROR
            r7 = 5
            r5.<init>(r6, r7)
        L16:
            return r5
        L17:
            org.apache.cordova.ContactAccessor r5 = r8.contactAccessor
            if (r5 != 0) goto L26
            org.apache.cordova.ContactAccessorSdk5 r5 = new org.apache.cordova.ContactAccessorSdk5
            org.apache.cordova.CordovaWebView r6 = r8.webView
            org.apache.cordova.api.CordovaInterface r7 = r8.cordova
            r5.<init>(r6, r7)
            r8.contactAccessor = r5
        L26:
            java.lang.String r5 = "search"
            boolean r5 = r9.equals(r5)     // Catch: org.json.JSONException -> L44
            if (r5 == 0) goto L56
            org.apache.cordova.ContactAccessor r5 = r8.contactAccessor     // Catch: org.json.JSONException -> L44
            r6 = 0
            org.json.JSONArray r6 = r10.getJSONArray(r6)     // Catch: org.json.JSONException -> L44
            r7 = 1
            org.json.JSONObject r7 = r10.optJSONObject(r7)     // Catch: org.json.JSONException -> L44
            org.json.JSONArray r2 = r5.search(r6, r7)     // Catch: org.json.JSONException -> L44
            org.apache.cordova.api.PluginResult r5 = new org.apache.cordova.api.PluginResult     // Catch: org.json.JSONException -> L44
            r5.<init>(r4, r2)     // Catch: org.json.JSONException -> L44
            goto L16
        L44:
            r0 = move-exception
            java.lang.String r5 = "Contact Query"
            java.lang.String r6 = r0.getMessage()
            android.util.Log.e(r5, r6, r0)
            org.apache.cordova.api.PluginResult r5 = new org.apache.cordova.api.PluginResult
            org.apache.cordova.api.PluginResult$Status r6 = org.apache.cordova.api.PluginResult.Status.JSON_EXCEPTION
            r5.<init>(r6)
            goto L16
        L56:
            java.lang.String r5 = "save"
            boolean r5 = r9.equals(r5)     // Catch: org.json.JSONException -> L44
            if (r5 == 0) goto L79
            org.apache.cordova.ContactAccessor r5 = r8.contactAccessor     // Catch: org.json.JSONException -> L44
            r6 = 0
            org.json.JSONObject r6 = r10.getJSONObject(r6)     // Catch: org.json.JSONException -> L44
            java.lang.String r1 = r5.save(r6)     // Catch: org.json.JSONException -> L44
            if (r1 == 0) goto L94
            org.apache.cordova.ContactAccessor r5 = r8.contactAccessor     // Catch: org.json.JSONException -> L44
            org.json.JSONObject r2 = r5.getContactById(r1)     // Catch: org.json.JSONException -> L44
            if (r2 == 0) goto L94
            org.apache.cordova.api.PluginResult r5 = new org.apache.cordova.api.PluginResult     // Catch: org.json.JSONException -> L44
            r5.<init>(r4, r2)     // Catch: org.json.JSONException -> L44
            goto L16
        L79:
            java.lang.String r5 = "remove"
            boolean r5 = r9.equals(r5)     // Catch: org.json.JSONException -> L44
            if (r5 == 0) goto L94
            org.apache.cordova.ContactAccessor r5 = r8.contactAccessor     // Catch: org.json.JSONException -> L44
            r6 = 0
            java.lang.String r6 = r10.getString(r6)     // Catch: org.json.JSONException -> L44
            boolean r5 = r5.remove(r6)     // Catch: org.json.JSONException -> L44
            if (r5 == 0) goto L94
            org.apache.cordova.api.PluginResult r5 = new org.apache.cordova.api.PluginResult     // Catch: org.json.JSONException -> L44
            r5.<init>(r4, r3)     // Catch: org.json.JSONException -> L44
            goto L16
        L94:
            org.apache.cordova.api.PluginResult r5 = new org.apache.cordova.api.PluginResult     // Catch: org.json.JSONException -> L44
            org.apache.cordova.api.PluginResult$Status r6 = org.apache.cordova.api.PluginResult.Status.ERROR     // Catch: org.json.JSONException -> L44
            r7 = 0
            r5.<init>(r6, r7)     // Catch: org.json.JSONException -> L44
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.ContactManager.execute(java.lang.String, org.json.JSONArray, java.lang.String):org.apache.cordova.api.PluginResult");
    }
}
