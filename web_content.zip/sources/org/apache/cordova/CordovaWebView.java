package org.apache.cordova;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.XmlResourceParser;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.LOG;
import org.apache.cordova.api.PluginManager;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: loaded from: classes.dex */
public class CordovaWebView extends WebView {
    public static final String TAG = "CordovaWebView";
    String baseUrl;
    private boolean bound;
    public CallbackServer callbackServer;
    private CordovaChromeClient chromeClient;
    private CordovaInterface cordova;
    private ArrayList<Integer> keyDownCodes;
    private ArrayList<Integer> keyUpCodes;
    int loadUrlTimeout;
    public PluginManager pluginManager;
    private String url;
    private Stack<String> urls;
    boolean useBrowserHistory;
    CordovaWebViewClient viewClient;
    private boolean volumedownBound;
    private boolean volumeupBound;
    private ArrayList<Pattern> whiteList;
    private HashMap<String, Boolean> whiteListCache;

    /* JADX WARN: Multi-variable type inference failed */
    public CordovaWebView(Context context) {
        super(context);
        this.whiteList = new ArrayList<>();
        this.whiteListCache = new HashMap<>();
        this.keyDownCodes = new ArrayList<>();
        this.keyUpCodes = new ArrayList<>();
        this.urls = new Stack<>();
        this.useBrowserHistory = false;
        this.loadUrlTimeout = 0;
        if (CordovaInterface.class.isInstance(context)) {
            this.cordova = (CordovaInterface) context;
        } else {
            Log.d(TAG, "Your activity must implement CordovaInterface to work");
        }
        loadConfiguration();
        setup();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public CordovaWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.whiteList = new ArrayList<>();
        this.whiteListCache = new HashMap<>();
        this.keyDownCodes = new ArrayList<>();
        this.keyUpCodes = new ArrayList<>();
        this.urls = new Stack<>();
        this.useBrowserHistory = false;
        this.loadUrlTimeout = 0;
        if (CordovaInterface.class.isInstance(context)) {
            this.cordova = (CordovaInterface) context;
        } else {
            Log.d(TAG, "Your activity must implement CordovaInterface to work");
        }
        setWebChromeClient(new CordovaChromeClient(this.cordova, this));
        setWebViewClient(new CordovaWebViewClient(this.cordova, this));
        loadConfiguration();
        setup();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public CordovaWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.whiteList = new ArrayList<>();
        this.whiteListCache = new HashMap<>();
        this.keyDownCodes = new ArrayList<>();
        this.keyUpCodes = new ArrayList<>();
        this.urls = new Stack<>();
        this.useBrowserHistory = false;
        this.loadUrlTimeout = 0;
        if (CordovaInterface.class.isInstance(context)) {
            this.cordova = (CordovaInterface) context;
        } else {
            Log.d(TAG, "Your activity must implement CordovaInterface to work");
        }
        setWebChromeClient(new CordovaChromeClient(this.cordova, this));
        setWebViewClient(new CordovaWebViewClient(this.cordova, this));
        loadConfiguration();
        setup();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public CordovaWebView(Context context, AttributeSet attrs, int defStyle, boolean privateBrowsing) {
        super(context, attrs, defStyle, privateBrowsing);
        this.whiteList = new ArrayList<>();
        this.whiteListCache = new HashMap<>();
        this.keyDownCodes = new ArrayList<>();
        this.keyUpCodes = new ArrayList<>();
        this.urls = new Stack<>();
        this.useBrowserHistory = false;
        this.loadUrlTimeout = 0;
        if (CordovaInterface.class.isInstance(context)) {
            this.cordova = (CordovaInterface) context;
        } else {
            Log.d(TAG, "Your activity must implement CordovaInterface to work");
        }
        setWebChromeClient(new CordovaChromeClient(this.cordova));
        setWebViewClient(new CordovaWebViewClient(this.cordova));
        loadConfiguration();
        setup();
    }

    private void setup() {
        setInitialScale(0);
        setVerticalScrollBarEnabled(false);
        requestFocusFromTouch();
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        if (Build.VERSION.SDK_INT < 11) {
            settings.setNavDump(true);
        }
        settings.setDatabaseEnabled(true);
        String databasePath = this.cordova.getActivity().getApplicationContext().getDir("database", 0).getPath();
        settings.setDatabasePath(databasePath);
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        try {
            this.pluginManager = new PluginManager(this, this.cordova);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setWebViewClient(CordovaWebViewClient client) {
        this.viewClient = client;
        super.setWebViewClient((WebViewClient) client);
    }

    public void setWebChromeClient(CordovaChromeClient client) {
        this.chromeClient = client;
        super.setWebChromeClient((WebChromeClient) client);
    }

    public void addWhiteListEntry(String origin, boolean subdomains) {
        try {
            if (origin.compareTo("*") == 0) {
                LOG.d(TAG, "Unlimited access to network resources");
                this.whiteList.add(Pattern.compile(".*"));
            } else {
                if (subdomains) {
                    if (origin.startsWith("http")) {
                        this.whiteList.add(Pattern.compile(origin.replaceFirst("https?://", "^https?://(.*\\.)?")));
                    } else {
                        this.whiteList.add(Pattern.compile("^https?://(.*\\.)?" + origin));
                    }
                    LOG.d(TAG, "Origin to allow with subdomains: %s", origin);
                    return;
                }
                if (origin.startsWith("http")) {
                    this.whiteList.add(Pattern.compile(origin.replaceFirst("https?://", "^https?://")));
                } else {
                    this.whiteList.add(Pattern.compile("^https?://" + origin));
                }
                LOG.d(TAG, "Origin to allow: %s", origin);
            }
        } catch (Exception e) {
            LOG.d(TAG, "Failed to add origin %s", origin);
        }
    }

    public boolean isUrlWhiteListed(String url) {
        if (this.whiteListCache.get(url) != null) {
            return true;
        }
        for (Pattern p : this.whiteList) {
            Matcher m = p.matcher(url);
            if (m.find()) {
                this.whiteListCache.put(url, true);
                return true;
            }
        }
        return false;
    }

    @Override // android.webkit.WebView
    public void loadUrl(String url) {
        if (url.equals("about:blank") || url.startsWith("javascript:")) {
            loadUrlNow(url);
            return;
        }
        String initUrl = getProperty("url", null);
        if (initUrl == null || this.urls.size() > 0) {
            loadUrlIntoView(url);
        } else {
            loadUrlIntoView(initUrl);
        }
    }

    public void loadUrl(String url, int time) {
        String initUrl = getProperty("url", null);
        if (initUrl == null || this.urls.size() > 0) {
            loadUrlIntoView(url, time);
        } else {
            loadUrlIntoView(initUrl);
        }
    }

    public void loadUrlIntoView(final String url) {
        LOG.d(TAG, ">>> loadUrl(" + url + ")");
        this.url = url;
        if (this.baseUrl == null) {
            int i = url.lastIndexOf(47);
            if (i > 0) {
                this.baseUrl = url.substring(0, i + 1);
            } else {
                this.baseUrl = this.url + "/";
            }
            this.pluginManager.init();
            if (!this.useBrowserHistory) {
                this.urls.push(url);
            }
        }
        final int currentLoadUrlTimeout = this.loadUrlTimeout;
        final int loadUrlTimeoutValue = Integer.parseInt(getProperty("loadUrlTimeoutValue", "20000"));
        final Runnable loadError = new Runnable() { // from class: org.apache.cordova.CordovaWebView.1
            @Override // java.lang.Runnable
            public void run() {
                this.stopLoading();
                LOG.e(CordovaWebView.TAG, "CordovaWebView: TIMEOUT ERROR!");
                if (CordovaWebView.this.viewClient != null) {
                    CordovaWebView.this.viewClient.onReceivedError(this, -6, "The connection to the server was unsuccessful.", url);
                }
            }
        };
        final Runnable timeoutCheck = new Runnable() { // from class: org.apache.cordova.CordovaWebView.2
            @Override // java.lang.Runnable
            public void run() {
                try {
                    synchronized (this) {
                        wait(loadUrlTimeoutValue);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (this.loadUrlTimeout == currentLoadUrlTimeout) {
                    this.cordova.getActivity().runOnUiThread(loadError);
                }
            }
        };
        this.cordova.getActivity().runOnUiThread(new Runnable() { // from class: org.apache.cordova.CordovaWebView.3
            @Override // java.lang.Runnable
            public void run() {
                Thread thread = new Thread(timeoutCheck);
                thread.start();
                this.loadUrlNow(url);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadUrlNow(String url) {
        LOG.d(TAG, ">>> loadUrlNow()");
        super.loadUrl(url);
    }

    public void loadUrlIntoView(String url, int time) {
        if (!url.startsWith("javascript:") && this.urls.size() <= 0 && !canGoBack()) {
            LOG.d(TAG, "DroidGap.loadUrl(%s, %d)", url, Integer.valueOf(time));
            postMessage("splashscreen", "show");
        }
        loadUrlIntoView(url);
    }

    public void sendJavascript(String statement) {
        if (this.callbackServer != null) {
            this.callbackServer.sendJavascript(statement);
        }
    }

    public void postMessage(String id, Object data) {
        if (this.pluginManager != null) {
            this.pluginManager.postMessage(id, data);
        }
    }

    public String peekAtUrlStack() {
        return this.urls.size() > 0 ? this.urls.peek() : "";
    }

    public void pushUrl(String url) {
        this.urls.push(url);
    }

    public boolean backHistory() {
        if (super.canGoBack()) {
            super.goBack();
            return true;
        }
        if (this.urls.size() > 1) {
            this.urls.pop();
            String url = this.urls.pop();
            loadUrl(url);
            return true;
        }
        return false;
    }

    @Override // android.webkit.WebView
    public boolean canGoBack() {
        return super.canGoBack() || this.urls.size() > 1;
    }

    public void showWebPage(String url, boolean openExternal, boolean clearHistory, HashMap<String, Object> params) {
        LOG.d(TAG, "showWebPage(%s, %b, %b, HashMap", url, Boolean.valueOf(openExternal), Boolean.valueOf(clearHistory));
        if (clearHistory) {
            clearHistory();
        }
        if (!openExternal) {
            if (url.startsWith("file://") || url.indexOf(this.baseUrl) == 0 || isUrlWhiteListed(url)) {
                if (clearHistory) {
                    this.urls.clear();
                }
                loadUrl(url);
                return;
            }
            LOG.w(TAG, "showWebPage: Cannot load URL into webview since it is not in white list.  Loading into browser instead. (URL=" + url + ")");
            try {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse(url));
                this.cordova.getActivity().startActivity(intent);
                return;
            } catch (ActivityNotFoundException e) {
                LOG.e(TAG, "Error loading url " + url, e);
                return;
            }
        }
        try {
            Intent intent2 = new Intent("android.intent.action.VIEW");
            intent2.setData(Uri.parse(url));
            this.cordova.getActivity().startActivity(intent2);
        } catch (ActivityNotFoundException e2) {
            LOG.e(TAG, "Error loading url " + url, e2);
        }
    }

    private void loadConfiguration() {
        int id = getResources().getIdentifier("config", "xml", this.cordova.getActivity().getPackageName());
        if (id == 0) {
            id = getResources().getIdentifier("cordova", "xml", this.cordova.getActivity().getPackageName());
            Log.i("CordovaLog", "config.xml missing, reverting to cordova.xml");
        }
        if (id == 0) {
            LOG.i("CordovaLog", "cordova.xml missing. Ignoring...");
            return;
        }
        XmlResourceParser xml = getResources().getXml(id);
        int eventType = -1;
        while (eventType != 1) {
            if (eventType == 2) {
                String strNode = xml.getName();
                if (strNode.equals("access")) {
                    String origin = xml.getAttributeValue(null, "origin");
                    String subdomains = xml.getAttributeValue(null, "subdomains");
                    if (origin != null) {
                        addWhiteListEntry(origin, subdomains != null && subdomains.compareToIgnoreCase("true") == 0);
                    }
                } else if (strNode.equals("log")) {
                    String level = xml.getAttributeValue(null, "level");
                    LOG.i("CordovaLog", "Found log level %s", level);
                    if (level != null) {
                        LOG.setLogLevel(level);
                    }
                } else if (strNode.equals("preference")) {
                    String name = xml.getAttributeValue(null, "name");
                    String value = xml.getAttributeValue(null, "value");
                    LOG.i("CordovaLog", "Found preference for %s=%s", name, value);
                    Log.d("CordovaLog", "Found preference for " + name + "=" + value);
                    this.cordova.getActivity().getIntent().putExtra(name, value);
                }
            }
            try {
                eventType = xml.next();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (XmlPullParserException e2) {
                e2.printStackTrace();
            }
        }
        if ("true".equals(getProperty("useBrowserHistory", "false"))) {
            this.useBrowserHistory = true;
        } else {
            this.useBrowserHistory = false;
        }
        if ("true".equals(getProperty("fullscreen", "false"))) {
            this.cordova.getActivity().getWindow().clearFlags(2048);
            this.cordova.getActivity().getWindow().setFlags(1024, 1024);
        }
    }

    public String getProperty(String name, String defaultValue) {
        Object p;
        Bundle bundle = this.cordova.getActivity().getIntent().getExtras();
        return (bundle == null || (p = bundle.get(name)) == null) ? defaultValue : p.toString();
    }

    @Override // android.webkit.WebView, android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (this.keyDownCodes.contains(Integer.valueOf(keyCode))) {
            if (keyCode == 25) {
                LOG.d(TAG, "Down Key Hit");
                loadUrl("javascript:cordova.fireDocumentEvent('volumedownbutton');");
                return true;
            }
            if (keyCode == 24) {
                LOG.d(TAG, "Up Key Hit");
                loadUrl("javascript:cordova.fireDocumentEvent('volumeupbutton');");
                return true;
            }
            return super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override // android.webkit.WebView, android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        Log.d(TAG, "KeyDown has been triggered on the view");
        if (keyCode == 4) {
            if (!this.bound) {
                return backHistory();
            }
            loadUrl("javascript:cordova.fireDocumentEvent('backbutton');");
            return true;
        }
        if (keyCode == 82) {
            loadUrl("javascript:cordova.fireDocumentEvent('menubutton');");
            return super.onKeyUp(keyCode, event);
        }
        if (keyCode == 84) {
            loadUrl("javascript:cordova.fireDocumentEvent('searchbutton');");
            return true;
        }
        if (this.keyUpCodes.contains(Integer.valueOf(keyCode))) {
            return super.onKeyUp(keyCode, event);
        }
        Log.d(TAG, "KeyUp has been triggered on the view");
        return false;
    }

    public void bindButton(boolean override) {
        this.bound = override;
    }

    public void bindButton(String button, boolean override) {
        if (button.compareTo("volumeup") == 0) {
            this.keyDownCodes.add(24);
        } else if (button.compareTo("volumedown") == 0) {
            this.keyDownCodes.add(25);
        }
    }

    public void bindButton(int keyCode, boolean keyDown, boolean override) {
        if (keyDown) {
            this.keyDownCodes.add(Integer.valueOf(keyCode));
        } else {
            this.keyUpCodes.add(Integer.valueOf(keyCode));
        }
    }

    public boolean isBackButtonBound() {
        return this.bound;
    }
}
