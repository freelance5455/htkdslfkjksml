package org.apache.cordova;

import android.location.LocationManager;

/* JADX INFO: loaded from: classes.dex */
public class GPSListener extends CordovaLocationListener {
    public GPSListener(LocationManager locationManager, GeoBroker m) {
        super(locationManager, m, "[Cordova GPSListener]");
    }

    @Override // org.apache.cordova.CordovaLocationListener
    protected void start() {
        if (!this.running) {
            if (this.locationManager.getProvider("gps") != null) {
                this.running = true;
                this.locationManager.requestLocationUpdates("gps", 60000L, 0.0f, this);
            } else {
                fail(CordovaLocationListener.POSITION_UNAVAILABLE, "GPS provider is not available.");
            }
        }
    }
}
