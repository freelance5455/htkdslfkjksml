package org.apache.cordova;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class StandAlone extends DroidGap {
    @Override // org.apache.cordova.DroidGap, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.loadUrl("file:///android_asset/www/index.html");
    }
}
