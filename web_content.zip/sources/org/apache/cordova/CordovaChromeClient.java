package org.apache.cordova;

import android.R;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.KeyEvent;
import android.webkit.ConsoleMessage;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.widget.EditText;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.LOG;
import org.json.JSONArray;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
public class CordovaChromeClient extends WebChromeClient {
    private CordovaWebView appView;
    private CordovaInterface cordova;
    private String TAG = "CordovaLog";
    private long MAX_QUOTA = 104857600;

    public CordovaChromeClient(CordovaInterface cordova) {
        this.cordova = cordova;
    }

    public CordovaChromeClient(CordovaInterface ctx, CordovaWebView app) {
        this.cordova = ctx;
        this.appView = app;
    }

    public void setWebView(CordovaWebView view) {
        this.appView = view;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
        AlertDialog.Builder dlg = new AlertDialog.Builder(this.cordova.getActivity());
        dlg.setMessage(message);
        dlg.setTitle("Alert");
        dlg.setCancelable(true);
        dlg.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.CordovaChromeClient.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                result.confirm();
            }
        });
        dlg.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: org.apache.cordova.CordovaChromeClient.2
            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialog) {
                result.cancel();
            }
        });
        dlg.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: org.apache.cordova.CordovaChromeClient.3
            @Override // android.content.DialogInterface.OnKeyListener
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode != 4) {
                    return true;
                }
                result.confirm();
                return false;
            }
        });
        dlg.create();
        dlg.show();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
        AlertDialog.Builder dlg = new AlertDialog.Builder(this.cordova.getActivity());
        dlg.setMessage(message);
        dlg.setTitle("Confirm");
        dlg.setCancelable(true);
        dlg.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.CordovaChromeClient.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                result.confirm();
            }
        });
        dlg.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.CordovaChromeClient.5
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                result.cancel();
            }
        });
        dlg.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: org.apache.cordova.CordovaChromeClient.6
            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialog) {
                result.cancel();
            }
        });
        dlg.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: org.apache.cordova.CordovaChromeClient.7
            @Override // android.content.DialogInterface.OnKeyListener
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode != 4) {
                    return true;
                }
                result.cancel();
                return false;
            }
        });
        dlg.create();
        dlg.show();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
        boolean reqOk = false;
        if (url.startsWith("file://") || url.indexOf(this.appView.baseUrl) == 0 || this.appView.isUrlWhiteListed(url)) {
            reqOk = true;
        }
        if (reqOk && defaultValue != null && defaultValue.length() > 3 && defaultValue.substring(0, 4).equals("gap:")) {
            try {
                JSONArray array = new JSONArray(defaultValue.substring(4));
                String service = array.getString(0);
                String action = array.getString(1);
                String callbackId = array.getString(2);
                boolean async = array.getBoolean(3);
                result.confirm(this.appView.pluginManager.exec(service, action, callbackId, message, async));
                return true;
            } catch (JSONException e) {
                e.printStackTrace();
                return true;
            }
        }
        if (reqOk && defaultValue != null && defaultValue.equals("gap_poll:")) {
            result.confirm(this.appView.callbackServer.getJavascript());
            return true;
        }
        if (defaultValue != null && defaultValue.equals("gap_init:")) {
            result.confirm("OK");
            return true;
        }
        if (reqOk && defaultValue != null && defaultValue.equals("gap_callbackServer:")) {
            String r = "";
            if (message.equals("usePolling")) {
                r = "" + this.appView.callbackServer.usePolling();
            } else if (message.equals("restartServer")) {
                this.appView.callbackServer.restartServer();
            } else if (message.equals("getPort")) {
                r = Integer.toString(this.appView.callbackServer.getPort());
            } else if (message.equals("getToken")) {
                r = this.appView.callbackServer.getToken();
            }
            result.confirm(r);
            return true;
        }
        AlertDialog.Builder dlg = new AlertDialog.Builder(this.cordova.getActivity());
        dlg.setMessage(message);
        final EditText input = new EditText(this.cordova.getActivity());
        if (defaultValue != null) {
            input.setText(defaultValue);
        }
        dlg.setView(input);
        dlg.setCancelable(false);
        dlg.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.CordovaChromeClient.8
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                String usertext = input.getText().toString();
                result.confirm(usertext);
            }
        });
        dlg.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: org.apache.cordova.CordovaChromeClient.9
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                result.cancel();
            }
        });
        dlg.create();
        dlg.show();
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public void onExceededDatabaseQuota(String url, String databaseIdentifier, long currentQuota, long estimatedSize, long totalUsedQuota, WebStorage.QuotaUpdater quotaUpdater) {
        LOG.d(this.TAG, "DroidGap:  onExceededDatabaseQuota estimatedSize: %d  currentQuota: %d  totalUsedQuota: %d", Long.valueOf(estimatedSize), Long.valueOf(currentQuota), Long.valueOf(totalUsedQuota));
        if (estimatedSize < this.MAX_QUOTA) {
            LOG.d(this.TAG, "calling quotaUpdater.updateQuota newQuota: %d", Long.valueOf(estimatedSize));
            quotaUpdater.updateQuota(estimatedSize);
        } else {
            quotaUpdater.updateQuota(currentQuota);
        }
    }

    @Override // android.webkit.WebChromeClient
    public void onConsoleMessage(String message, int lineNumber, String sourceID) {
        LOG.d(this.TAG, "%s: Line %d : %s", sourceID, Integer.valueOf(lineNumber), message);
        super.onConsoleMessage(message, lineNumber, sourceID);
    }

    @Override // android.webkit.WebChromeClient
    public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        if (consoleMessage.message() != null) {
            LOG.d(this.TAG, consoleMessage.message());
        }
        return super.onConsoleMessage(consoleMessage);
    }

    @Override // android.webkit.WebChromeClient
    public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
        super.onGeolocationPermissionsShowPrompt(origin, callback);
        callback.invoke(origin, true, false);
    }
}
