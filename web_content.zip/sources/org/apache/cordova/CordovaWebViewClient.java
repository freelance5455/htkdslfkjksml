package org.apache.cordova;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.LOG;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class CordovaWebViewClient extends WebViewClient {
    private static final String TAG = "Cordova";
    CordovaWebView appView;
    CordovaInterface cordova;
    private boolean doClearHistory = false;
    private Hashtable<String, AuthenticationToken> authenticationTokens = new Hashtable<>();

    public CordovaWebViewClient(CordovaInterface cordova) {
        this.cordova = cordova;
    }

    public CordovaWebViewClient(CordovaInterface cordova, CordovaWebView view) {
        this.cordova = cordova;
        this.appView = view;
    }

    public void setWebView(CordovaWebView view) {
        this.appView = view;
    }

    @Override // android.webkit.WebViewClient
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        String address;
        if (this.appView.pluginManager == null || !this.appView.pluginManager.onOverrideUrlLoading(url)) {
            if (url.startsWith("tel:")) {
                try {
                    Intent intent = new Intent("android.intent.action.DIAL");
                    intent.setData(Uri.parse(url));
                    this.cordova.getActivity().startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    LOG.e(TAG, "Error dialing " + url + ": " + e.toString());
                }
            } else if (url.startsWith("geo:")) {
                try {
                    Intent intent2 = new Intent("android.intent.action.VIEW");
                    intent2.setData(Uri.parse(url));
                    this.cordova.getActivity().startActivity(intent2);
                } catch (ActivityNotFoundException e2) {
                    LOG.e(TAG, "Error showing map " + url + ": " + e2.toString());
                }
            } else if (url.startsWith("mailto:")) {
                try {
                    Intent intent3 = new Intent("android.intent.action.VIEW");
                    intent3.setData(Uri.parse(url));
                    this.cordova.getActivity().startActivity(intent3);
                } catch (ActivityNotFoundException e3) {
                    LOG.e(TAG, "Error sending email " + url + ": " + e3.toString());
                }
            } else if (url.startsWith("sms:")) {
                try {
                    Intent intent4 = new Intent("android.intent.action.VIEW");
                    int parmIndex = url.indexOf(63);
                    if (parmIndex == -1) {
                        address = url.substring(4);
                    } else {
                        address = url.substring(4, parmIndex);
                        Uri uri = Uri.parse(url);
                        String query = uri.getQuery();
                        if (query != null && query.startsWith("body=")) {
                            intent4.putExtra("sms_body", query.substring(5));
                        }
                    }
                    intent4.setData(Uri.parse("sms:" + address));
                    intent4.putExtra("address", address);
                    intent4.setType("vnd.android-dir/mms-sms");
                    this.cordova.getActivity().startActivity(intent4);
                } catch (ActivityNotFoundException e4) {
                    LOG.e(TAG, "Error sending sms " + url + ":" + e4.toString());
                }
            } else if (url.startsWith("file://") || url.indexOf(this.appView.baseUrl) == 0 || this.appView.isUrlWhiteListed(url)) {
                if (this.appView.useBrowserHistory) {
                    return false;
                }
                this.appView.loadUrl(url);
            } else {
                try {
                    Intent intent5 = new Intent("android.intent.action.VIEW");
                    intent5.setData(Uri.parse(url));
                    this.cordova.getActivity().startActivity(intent5);
                } catch (ActivityNotFoundException e5) {
                    LOG.e(TAG, "Error loading url " + url, e5);
                }
            }
        }
        return true;
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
        AuthenticationToken token = getAuthenticationToken(host, realm);
        if (token != null) {
            handler.proceed(token.getUserName(), token.getPassword());
        }
    }

    @Override // android.webkit.WebViewClient
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        if (!this.appView.useBrowserHistory) {
            view.clearHistory();
            this.doClearHistory = true;
        }
        if (this.appView.callbackServer == null) {
            this.appView.callbackServer = new CallbackServer();
            this.appView.callbackServer.init(url);
        } else {
            this.appView.callbackServer.reinit(url);
        }
        this.appView.postMessage("onPageStarted", url);
    }

    @Override // android.webkit.WebViewClient
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        LOG.d(TAG, "onPageFinished(" + url + ")");
        if (this.doClearHistory) {
            view.clearHistory();
            this.doClearHistory = false;
        }
        this.appView.loadUrlTimeout++;
        if (!url.equals("about:blank")) {
            this.appView.loadUrl("javascript:try{ cordova.require('cordova/channel').onNativeReady.fire();}catch(e){_nativeReady = true;}");
            this.appView.postMessage("onNativeReady", null);
        }
        this.appView.postMessage("onPageFinished", url);
        if (this.appView.getVisibility() == 4) {
            Thread t = new Thread(new Runnable() { // from class: org.apache.cordova.CordovaWebViewClient.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(2000L);
                        CordovaWebViewClient.this.cordova.getActivity().runOnUiThread(new Runnable() { // from class: org.apache.cordova.CordovaWebViewClient.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                CordovaWebViewClient.this.appView.postMessage("spinner", "stop");
                            }
                        });
                    } catch (InterruptedException e) {
                    }
                }
            });
            t.start();
        }
        if (url.equals("about:blank")) {
            if (this.appView.callbackServer != null) {
                this.appView.callbackServer.destroy();
            }
            this.appView.postMessage("exit", null);
        }
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        LOG.d(TAG, "CordovaWebViewClient.onReceivedError: Error code=%s Description=%s URL=%s", Integer.valueOf(errorCode), description, failingUrl);
        this.appView.loadUrlTimeout++;
        JSONObject data = new JSONObject();
        try {
            data.put("errorCode", errorCode);
            data.put("description", description);
            data.put("url", failingUrl);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.appView.postMessage("onReceivedError", data);
    }

    @Override // android.webkit.WebViewClient
    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        String packageName = this.cordova.getActivity().getPackageName();
        PackageManager pm = this.cordova.getActivity().getPackageManager();
        try {
            ApplicationInfo appInfo = pm.getApplicationInfo(packageName, 128);
            if ((appInfo.flags & 2) != 0) {
                handler.proceed();
            } else {
                super.onReceivedSslError(view, handler, error);
            }
        } catch (PackageManager.NameNotFoundException e) {
            super.onReceivedSslError(view, handler, error);
        }
    }

    @Override // android.webkit.WebViewClient
    public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
        if (!this.appView.peekAtUrlStack().equals(url)) {
            this.appView.pushUrl(url);
        }
    }

    public void setAuthenticationToken(AuthenticationToken authenticationToken, String host, String realm) {
        if (host == null) {
            host = "";
        }
        if (realm == null) {
            realm = "";
        }
        this.authenticationTokens.put(host.concat(realm), authenticationToken);
    }

    public AuthenticationToken removeAuthenticationToken(String host, String realm) {
        return this.authenticationTokens.remove(host.concat(realm));
    }

    public AuthenticationToken getAuthenticationToken(String host, String realm) {
        AuthenticationToken token = this.authenticationTokens.get(host.concat(realm));
        if (token == null) {
            AuthenticationToken token2 = this.authenticationTokens.get(host);
            if (token2 == null) {
                token2 = this.authenticationTokens.get(realm);
            }
            if (token2 == null) {
                return this.authenticationTokens.get("");
            }
            return token2;
        }
        return token;
    }

    public void clearAuthenticationTokens() {
        this.authenticationTokens.clear();
    }

    @Override // android.webkit.WebViewClient
    public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
        return (url.contains("?") || url.contains("#")) ? generateWebResourceResponse(url) : super.shouldInterceptRequest(view, url);
    }

    private WebResourceResponse generateWebResourceResponse(String url) {
        if (url.startsWith("file:///android_asset/")) {
            String niceUrl = url.replaceFirst("file:///android_asset/", "");
            if (niceUrl.contains("?")) {
                niceUrl = niceUrl.split("\\?")[0];
            } else if (niceUrl.contains("#")) {
                niceUrl = niceUrl.split("#")[0];
            }
            String mimetype = null;
            if (niceUrl.endsWith(".html")) {
                mimetype = "text/html";
            }
            try {
                AssetManager assets = this.cordova.getActivity().getAssets();
                Uri uri = Uri.parse(niceUrl);
                InputStream stream = assets.open(uri.getPath(), 2);
                return new WebResourceResponse(mimetype, "UTF-8", stream);
            } catch (IOException e) {
                LOG.e("generateWebResourceResponse", e.getMessage(), e);
            }
        }
        return null;
    }
}
