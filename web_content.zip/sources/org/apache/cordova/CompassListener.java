package org.apache.cordova;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.util.List;
import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class CompassListener extends Plugin implements SensorEventListener {
    int accuracy;
    long lastAccessTime;
    Sensor mSensor;
    private SensorManager sensorManager;
    int status;
    public static int STOPPED = 0;
    public static int STARTING = 1;
    public static int RUNNING = 2;
    public static int ERROR_FAILED_TO_START = 3;
    public long TIMEOUT = 30000;
    float heading = 0.0f;
    long timeStamp = 0;

    public CompassListener() {
        setStatus(STOPPED);
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void setContext(CordovaInterface cordova) {
        super.setContext(cordova);
        this.sensorManager = (SensorManager) cordova.getActivity().getSystemService("sensor");
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        PluginResult.Status status = PluginResult.Status.OK;
        try {
            if (action.equals("start")) {
                start();
            } else if (action.equals("stop")) {
                stop();
            } else {
                if (action.equals("getStatus")) {
                    int i = getStatus();
                    return new PluginResult(status, i);
                }
                if (action.equals("getHeading")) {
                    if (this.status != RUNNING) {
                        int r = start();
                        if (r == ERROR_FAILED_TO_START) {
                            return new PluginResult(PluginResult.Status.IO_EXCEPTION, ERROR_FAILED_TO_START);
                        }
                        long timeout = 2000;
                        while (this.status == STARTING && timeout > 0) {
                            timeout -= 100;
                            try {
                                Thread.sleep(100L);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        if (timeout == 0) {
                            return new PluginResult(PluginResult.Status.IO_EXCEPTION, ERROR_FAILED_TO_START);
                        }
                    }
                    return new PluginResult(status, getCompassHeading());
                }
                if (action.equals("setTimeout")) {
                    setTimeout(args.getLong(0));
                } else {
                    if (action.equals("getTimeout")) {
                        long l = getTimeout();
                        return new PluginResult(status, l);
                    }
                    return new PluginResult(PluginResult.Status.INVALID_ACTION);
                }
            }
            return new PluginResult(status, "");
        } catch (JSONException e2) {
            e2.printStackTrace();
            return new PluginResult(PluginResult.Status.JSON_EXCEPTION);
        }
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        if (action.equals("getStatus")) {
            return true;
        }
        if (action.equals("getHeading")) {
            if (this.status == RUNNING) {
                return true;
            }
        } else if (action.equals("getTimeout")) {
            return true;
        }
        return false;
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onDestroy() {
        stop();
    }

    public int start() {
        if (this.status == RUNNING || this.status == STARTING) {
            return this.status;
        }
        List<Sensor> list = this.sensorManager.getSensorList(3);
        if (list != null && list.size() > 0) {
            this.mSensor = list.get(0);
            this.sensorManager.registerListener(this, this.mSensor, 3);
            this.lastAccessTime = System.currentTimeMillis();
            setStatus(STARTING);
        } else {
            setStatus(ERROR_FAILED_TO_START);
        }
        return this.status;
    }

    public void stop() {
        if (this.status != STOPPED) {
            this.sensorManager.unregisterListener(this);
        }
        setStatus(STOPPED);
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent event) {
        float heading = event.values[0];
        this.timeStamp = System.currentTimeMillis();
        this.heading = heading;
        setStatus(RUNNING);
        if (this.timeStamp - this.lastAccessTime > this.TIMEOUT) {
            stop();
        }
    }

    public int getStatus() {
        return this.status;
    }

    public float getHeading() {
        this.lastAccessTime = System.currentTimeMillis();
        return this.heading;
    }

    public void setTimeout(long timeout) {
        this.TIMEOUT = timeout;
    }

    public long getTimeout() {
        return this.TIMEOUT;
    }

    private void setStatus(int status) {
        this.status = status;
    }

    private JSONObject getCompassHeading() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("magneticHeading", getHeading());
            obj.put("trueHeading", getHeading());
            obj.put("headingAccuracy", 0);
            obj.put("timestamp", this.timeStamp);
        } catch (JSONException e) {
        }
        return obj;
    }
}
