package org.apache.cordova;

import android.location.Location;
import android.location.LocationManager;
import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class GeoBroker extends Plugin {
    private GPSListener gpsListener;
    private LocationManager locationManager;
    private NetworkListener networkListener;

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public PluginResult execute(String action, JSONArray args, String callbackId) {
        if (this.locationManager == null) {
            this.locationManager = (LocationManager) this.cordova.getActivity().getSystemService("location");
            this.networkListener = new NetworkListener(this.locationManager, this);
            this.gpsListener = new GPSListener(this.locationManager, this);
        }
        PluginResult.Status status = PluginResult.Status.NO_RESULT;
        PluginResult result = new PluginResult(status, "");
        result.setKeepCallback(true);
        try {
            if (action.equals("getLocation")) {
                boolean enableHighAccuracy = args.getBoolean(0);
                int maximumAge = args.getInt(1);
                Location last = this.locationManager.getLastKnownLocation(enableHighAccuracy ? "gps" : "network");
                if (System.currentTimeMillis() - last.getTime() <= maximumAge) {
                    result = new PluginResult(PluginResult.Status.OK, returnLocationJSON(last));
                } else {
                    getCurrentLocation(callbackId, enableHighAccuracy);
                }
            } else if (action.equals("addWatch")) {
                String id = args.getString(0);
                addWatch(id, callbackId, args.getBoolean(1));
            } else if (action.equals("clearWatch")) {
                String id2 = args.getString(0);
                clearWatch(id2);
            }
            return result;
        } catch (JSONException e) {
            return new PluginResult(PluginResult.Status.JSON_EXCEPTION, e.getMessage());
        }
    }

    private void clearWatch(String id) {
        this.gpsListener.clearWatch(id);
        this.networkListener.clearWatch(id);
    }

    private void getCurrentLocation(String callbackId, boolean enableHighAccuracy) {
        if (enableHighAccuracy) {
            this.gpsListener.addCallback(callbackId);
        } else {
            this.networkListener.addCallback(callbackId);
        }
    }

    private void addWatch(String timerId, String callbackId, boolean enableHighAccuracy) {
        if (enableHighAccuracy) {
            this.gpsListener.addWatch(timerId, callbackId);
        } else {
            this.networkListener.addWatch(timerId, callbackId);
        }
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public boolean isSynch(String action) {
        return true;
    }

    @Override // org.apache.cordova.api.Plugin, org.apache.cordova.api.IPlugin
    public void onDestroy() {
        this.networkListener.destroy();
        this.gpsListener.destroy();
        this.networkListener = null;
        this.gpsListener = null;
    }

    public JSONObject returnLocationJSON(Location loc) {
        Float fValueOf = null;
        JSONObject o = new JSONObject();
        try {
            o.put("latitude", loc.getLatitude());
            o.put("longitude", loc.getLongitude());
            o.put("altitude", loc.hasAltitude() ? Double.valueOf(loc.getAltitude()) : null);
            o.put("accuracy", loc.getAccuracy());
            if (loc.hasBearing() && loc.hasSpeed()) {
                fValueOf = Float.valueOf(loc.getBearing());
            }
            o.put("heading", fValueOf);
            o.put("speed", loc.getSpeed());
            o.put("timestamp", loc.getTime());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return o;
    }

    public void win(Location loc, String callbackId) {
        PluginResult result = new PluginResult(PluginResult.Status.OK, returnLocationJSON(loc));
        success(result, callbackId);
    }

    public void fail(int code, String msg, String callbackId) {
        PluginResult result;
        JSONObject obj = new JSONObject();
        String backup = null;
        try {
            obj.put("code", code);
            obj.put("message", msg);
        } catch (JSONException e) {
            obj = null;
            backup = "{'code':" + code + ",'message':'" + msg.replaceAll("'", "'") + "'}";
        }
        if (obj != null) {
            result = new PluginResult(PluginResult.Status.ERROR, obj);
        } else {
            result = new PluginResult(PluginResult.Status.ERROR, backup);
        }
        error(result, callbackId);
    }
}
