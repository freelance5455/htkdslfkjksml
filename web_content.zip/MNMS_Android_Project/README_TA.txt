MNMS Small Finance Android Studio Project

இந்த ZIP ஒரு Android Studio project source. இது APK அல்ல.
APK உருவாக்க:
1. கணினியில் Android Studio நிறுவவும்.
2. இந்த ZIP-ஐ Extract செய்து Android Studio-வில் Open செய்யவும்.
3. Gradle Sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
4. app/build/outputs/apk/debug/app-debug.apk உருவாகும்.

கவனம்: இது local demo. Data இந்த app/browser storage-ல் மட்டுமே இருக்கும். Secure login, cloud backup, encrypted KYC vault, multi-user sync இல்லை. உண்மையான Aadhaar/PAN தரவை demo-வில் சேமிக்க வேண்டாம்.
