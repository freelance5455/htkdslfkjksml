package com.piet1.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean onMess = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setWebViewClient(new WebViewClient());
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setSupportZoom(false); s.setUseWideViewPort(false); s.setLoadWithOverviewMode(false); s.setTextZoom(100);
        webView.addJavascriptInterface(new Bridge(),"Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }
    private class Bridge { @JavascriptInterface public void exitApp(){ runOnUiThread(()->finish()); } }
    @Override public void onBackPressed(){
        webView.evaluateJavascript("document.getElementById('mess').style.display === 'block' ? 'mess' : 'home'", value -> {
            if ("\"mess\"".equals(value)) webView.evaluateJavascript("backHome()",null);
            else webView.evaluateJavascript("showExit()",null);
        });
    }
    @Override protected void onDestroy(){ if(webView!=null){webView.stopLoading();webView.destroy();webView=null;} super.onDestroy(); }
}
