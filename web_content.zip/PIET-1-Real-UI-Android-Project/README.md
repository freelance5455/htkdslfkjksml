# PIET-1 — Real UI Android WebView Project

This project renders the supplied PIET-1 information as actual HTML/CSS/SVG UI components. It does **not** use the supplied screenshots as a screen/background image.

Only the supplied app data is used:
- PIET-1
- ROSHAN SAHANI
- 8822102450
- 2503031460311@paruluniversity.ac.in
- AI & ML
- Semester 3
- Division: AI & ML - 3 - 3AIML24(2026-2027)
- Roll No. 42
- Batch 2
- Mess Pass: hostel ABRAHAM LINCOLN (requested change), Medical Mess, PIET-1, BTech/Computer Science course text shown in the supplied app, duration 01-07-2026 to 30-06-2027, contact 8822102450

The Mess Pass date/time is generated from the phone clock and updates every second.

## Build
Open this folder in Android Studio and use **Build > Build APK(s)**.

APK output name is configured as `PIET-1.apk`.

The app loads `file:///android_asset/www/index.html` and requires no website/server.
