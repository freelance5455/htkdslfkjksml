Robot 3D V14 ULTRA — Android

Orientation: automatic. The game follows the phone sensor and supports both portrait and landscape. UI and camera resize for the active orientation.

Build: open in Android Studio, sync Gradle, then Build > Generate Signed App Bundle / APK.
