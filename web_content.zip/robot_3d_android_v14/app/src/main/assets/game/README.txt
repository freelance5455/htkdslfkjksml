Robot 3D V12 — Graphics/Gameplay Overhaul

- Procedural high-detail environment: roads, houses, windows, lamps, trees, rocks, clouds.
- Improved lighting, shadows, tone mapping, fog and materials.
- More responsive third-person camera and subtle impact shake.
- More detailed attack/jump/footstep particles and sword effects.
- Improved robot animation and death presentation.
- Cinematic mission/story cards for stage transitions.
- Existing story, radial sword damage and mobile controls retained.

Note: the game remains procedurally generated and optimized rather than being padded with useless data. The ZIP size is intentionally kept much smaller than 400 MB so it loads faster on mobile.
