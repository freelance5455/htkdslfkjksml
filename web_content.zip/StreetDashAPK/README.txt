STREET DASH - PROJETO ANDROID

Este projeto coloca o HTML do Street Dash dentro de um aplicativo Android usando WebView.

PARA GERAR O APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta StreetDashAPK no Android Studio (Open).
3. Aguarde a sincronização do Gradle.
4. Se o Android Studio pedir, instale Android SDK Platform 35 e Build Tools.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será gerado em app/build/outputs/apk/debug/app-debug.apk.

OBSERVAÇÕES:
- O jogo é carregado do arquivo local app/src/main/assets/index.html.
- O HTML original carrega Three.js e a fonte Fredoka de serviços online; por isso, a primeira abertura e esses recursos exigem internet.
- O progresso salvo pelo jogo permanece no armazenamento local do WebView neste aparelho.
- Este pacote é o projeto Android pronto para compilar, não um APK já compilado.
