# PocketWise — independent hosting source

This source has been detached from AppDeploy-specific SDK imports and backend files. The app UI and local storage remain in the React frontend.

## Run locally
1. Install Node.js (LTS).
2. In this folder run `npm install`.
3. Run `npm run dev` and open the local URL printed by Vite.
4. Run `npm run build` before publishing; the static output is in `dist/`.

## Important functional change
The AI Audit screen now creates a basic rules-based report locally on the device. It does not send transactions, lending records, or saved reports to an AI service. This is not an AI assessment and is explicitly labelled in the report. The AppDeploy-only backend was removed. If you later want genuine AI audit reports, configure a separate backend you control and use its own secure authentication and privacy disclosures; do not put provider secrets in frontend code.

## The preview toolbar
The floating share/ChatGPT/platform toolbar in the screenshot is not part of the React app source. It is likely injected by the preview/hosting interface, so removing code references cannot remove a toolbar that the host overlays outside the page. Open the deployed URL directly in a browser or host it independently to verify the clean page.
