# ورشة باباگر - Android APK

هذا المشروع يحول ملف HTML المحلي إلى تطبيق Android يعمل بدون إنترنت.

## فتح المشروع
1. افتح Android Studio.
2. اختر Open.
3. اختر مجلد `WorkshopBabagarAndroid`.
4. انتظر Gradle Sync.
5. من القائمة: Build > Build APK(s).
6. ملف APK سيكون داخل `app/build/outputs/apk/apk/debug/`.

رمز الدخول الموجود في النظام: 2580.
