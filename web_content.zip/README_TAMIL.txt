SAB Finance - Android APK Project

இந்த ZIP-ல் உங்கள் FINSAB.html கோப்பு Android WebView app-ஆக இயக்குவதற்கான Android Studio project உள்ளது.

முக்கியம்:
- இது APK file அல்ல; APK உருவாக்குவதற்கான project ZIP.
- இங்கே Android SDK/Gradle build environment இல்லாததால் signed APK-ஐ நேரடியாக உருவாக்கி சோதிக்க முடியவில்லை.
- HTML கோப்பின் UI/logic-ஐ திட்டமிட்டு மாற்றவில்லை. Android wrapper மட்டும் சேர்க்கப்பட்டுள்ளது.
- HTML-ல் Tailwind CSS மற்றும் Google Fonts போன்ற இணைய வளங்கள் உள்ளதால், அவை load ஆக இணைய இணைப்பு தேவைப்படலாம்.
- WebView-ல் JavaScript, local storage மற்றும் file chooser இயக்கப்பட்டுள்ளது; Android Back button-ல் WebView page history இருந்தால் பின்னோக்கிச் செல்லும்.

APK உருவாக்குவது:
1. ZIP-ஐ extract செய்யவும்.
2. Android Studio-வில் அந்த folder-ஐ Open செய்யவும்.
3. Gradle sync முடியும் வரை காத்திருக்கவும்.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
5. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk-ல் கிடைக்கும்.

Signed APK:
Android Studio-வில் Build > Generate Signed Bundle / APK... தேர்வு செய்து APK உருவாக்கலாம்.
Keystore/password-ஐ பாதுகாப்பாக வைத்துக் கொள்ளவும்.

App name: SAB Finance
Package: com.sabfinance.app
Minimum Android: Android 6.0 (API 23)
