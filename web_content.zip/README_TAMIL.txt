இந்தது mobile browser-ல் திறக்கக்கூடிய clean Medical Billing web app.

Free/no-watermark HTML-to-APK builder-ல் இந்த web folder-ஐ ZIP செய்து upload செய்யலாம்.
Batch/Expiry data தற்போது DEMO. உண்மையான pharmacy data source இணைக்கப்பட வேண்டும்.
