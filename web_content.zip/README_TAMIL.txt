SIDDIQUE DEMOLITION - Android Studio Project

1. ZIP-ஐ extract செய்யவும்.
2. Android Studio-ல் இந்த folder-ஐ Open செய்யவும்.
3. Gradle Sync முடியும் வரை காத்திருக்கவும்.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
5. APK உருவானதும் Android Studio காட்டும் 'locate' இணைப்பில் பெறலாம்.

முக்கியம்:
- Photo/Video தேர்வுக்கு Android system document picker பயன்படுத்தப்படுகிறது; இதற்கு எல்லா storage permission-களையும் கேட்க வேண்டியதில்லை.
- Camera/Microphone-ஐ webpage கேட்டால் Android runtime permission கேட்கும்.
- இந்த project இன்னும் Android Studio-வில் build செய்து சாதனத்தில் சோதிக்கப்படவில்லை.
- Firebase Storage இதில் இணைக்கப்படவில்லை. HTML-ல் உள்ள app செயல்பாடுகள் மட்டுமே உள்ளூர் WebView-ல் இயங்கும்; cloud upload தனியாக Firebase அமைப்பு தேவைப்படும்.
- இணைய இணைப்பு அனுமதி சேர்க்கப்பட்டுள்ளது.
