GAMER TAMILZAN TV — COMPLETE SOURCE PROJECT
===========================================

இந்த ZIP-ல் உள்ளவை:
1) website/index.html — மொபைல்-நட்பு TV website prototype
2) android-wrapper/ — Android WebView APK-க்கான source template
3) Gradle project files

முக்கியம்:
- இது SOURCE PROJECT; ஏற்கனவே build செய்யப்பட்ட APK அல்ல.
- APK உருவாக்க Android build environment (Android Studio அல்லது cloud Android build service) தேவை.
- இந்த project-ஐ மொபைலில் edit/preview செய்யலாம்; APK build செய்வதற்கு ஆதரவு உள்ள cloud builder பயன்படுத்தலாம்.
- Live channels தற்போது demo placeholders மட்டுமே. ஒளிபரப்பாளர் வழங்கிய, பொதுப் பயன்பாட்டுக்கு அனுமதிக்கப்பட்ட official free stream URL இருந்தால் மட்டுமே சேர்க்கவும்.
- கட்டணச் சேனல் playlist, தனிப்பட்ட link அல்லது அனுமதியற்ற retransmission சேர்க்க வேண்டாம்.

Website preview:
website/index.html-ஐ Chrome-ல் திறக்கவும்.

Android source:
android-wrapper/app/src/main/assets/index.html மற்றும் MainActivity.java உள்ளன.
Android build செய்யும் போது Gradle project அமைப்பில் app module-ஐ பயன்படுத்தவும்.
