TO DO'S Android APK build

Indha ZIP Android Studio project + GitHub Actions APK builder.

Mukkiyam:
- Indha chat-la direct-aa signed/ready APK compile panna Android build environment illai.
- ZIP-ai GitHub repository-ku upload pannina, Actions automatic-aa debug APK build pannum.
- GitHub repository private-aa vechukkonga.
- Firebase Firestore rules test mode-la irundhaal database public risk irukkum. Real employee data use pannaadheenga; rules secure pannunga.
- App login passwords HTML-la irukku; idhu demo-only. Production security illai.

GitHub-la:
1. New repository create pannunga (private recommended).
2. ZIP extract panni ullae irukkira files/folders ellam repo root-ku upload pannunga.
3. Commit to main.
4. Repository > Actions open pannunga.
5. "Build To Dos APK" workflow select panni Run workflow click pannunga (push automatic-aa start aagavillai endraal).
6. Green success run open pannunga.
7. Artifacts section-la ToDos-debug-apk download pannunga.
8. ZIP extract pannina app-debug.apk kidaikkum. Android phone-la install pannunga.

Install panna "Allow from this source" permission ketta, browser/files app-ku allow pannunga.
