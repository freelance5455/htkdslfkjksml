# Pocket Money Retro Android project

This is a native Android APK project wrapper for the offline Pocket Money Retro interface.

## Build an APK
1. Open this folder in Android Studio.
2. Let Gradle sync finish (Android Studio may download the Android Gradle Plugin and SDK).
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show a link to the generated debug APK.

The app works offline and stores transaction data in WebView local storage on the device. It does not connect to UPI or move real money. The tiny brown patterned dot in the top-right opens Money Vault. Vault tabs show each payment method's net total; each transaction can be edited (amount and payment method) or deleted.

For release/distribution, use **Build > Generate Signed Bundle / APK** and keep the signing key safe.
