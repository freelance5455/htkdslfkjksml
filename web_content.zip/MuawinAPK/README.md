# المعاون الذكي - تطبيق أندرويد (WebView)

مشروع أندرويد جاهز لتحويل تطبيق الويب HTML (المعاون) إلى ملف APK.

## المحتوى
- الواجهة كاملة داخل `app/src/main/assets/index.html`
- أيقونة التطبيق مأخوذة من شعار وزارة التربية
- دعم الحواف الآمنة (safe area) عبر `mwSetInsets`
- دعم الطباعة عبر `AndroidPrint`
- دعم اختيار الملفات من الجهاز

## كيفية بناء الـ APK

### الطريقة الأسهل (موصى بها)
1. ثبّت **Android Studio** من الموقع الرسمي.
2. افتح المجلد `MuawinAPK` كمشروع (Open).
3. انتظر حتى ينتهي Gradle من التحميل.
4. من القائمة: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. بعد الانتهاء ستجد ملف الـ APK في:
   `app/build/outputs/apk/debug/app-debug.apk`

### بناء نسخة Release (للتوزيع)
1. أنشئ مفتاح توقيع (keystore) من Android Studio أو عبر `keytool`.
2. أضف إعدادات التوقيع في `app/build.gradle`.
3. اختر **Build → Generate Signed Bundle / APK**.

### من سطر الأوامر (بعد تثبيت Android SDK)
```bash
cd MuawinAPK
./gradlew assembleDebug
```

## ملاحظات
- الحد الأدنى لنظام أندرويد: 7.0 (API 24)
- التطبيق يعمل بدون إنترنت بعد التثبيت (كل المحتوى محلي).
- إذا أردت تغيير الاسم أو الحزمة عدّل `applicationId` و `app_name`.

---
جمهورية العراق - وزارة التربية  
المعاون الذكي
