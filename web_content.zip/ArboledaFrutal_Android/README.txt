Arboleda Frutal — Mi Caja (proyecto Android)

Proyecto Android Studio que abre una interfaz local en WebView. No es un APK ya compilado.

Funciones incluidas en esta versión corregida:
- Ventas con varios productos en una sola venta.
- Fecha editable para ventas, gastos y compras.
- Historial filtrable por rango de fechas.
- Editar o borrar movimientos.
- Inventario de pulpas por sabor, vasos y pitillos, con mínimos y aviso visual de reposición.
- Al registrar una venta con productos de Jugos, solicita sabor de pulpa y descuenta pulpa(s), vasos y pitillos según cantidad.
- Exportar/importar respaldo JSON.

Importante:
- Los datos quedan en el almacenamiento local del WebView de ese dispositivo. Exporta un respaldo antes de actualizar o reinstalar.
- El inventario inicia en cero para cada insumo nuevo; registra las existencias actuales en Inventario.
- Este ZIP contiene el código fuente del proyecto, no un APK compilado.
- Para abrirlo: Android Studio > Open > selecciona la carpeta ArboledaFrutal_Android > sincroniza Gradle y ejecuta en dispositivo/emulador.
