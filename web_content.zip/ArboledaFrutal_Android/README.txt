ARBOLEDA FRUTAL — MI CAJA PRO
Proyecto Android para abrir en Android Studio y compilar como APK.
Incluye registro de ventas, gastos y compras con fecha editable; historial con filtro por rango; edición y eliminación de movimientos; balance por rango de fechas; cierre de caja; catálogo de productos; exportación/importación de respaldo JSON.
Los datos se guardan localmente en el dispositivo/navegador. Exporta un respaldo periódicamente y antes de cambiar o reinstalar la app.
Paquete: com.arboledafrutal.app
Para usar: abre la carpeta ArboledaFrutal_Android en Android Studio y compila el APK.
NOTA: esta entrega mejora el registro y control financiero. No se afirma que tenga todas las funciones de Treinta/Alegra ni sincronización en la nube.

Ventas múltiples: agrega varios productos y cantidades al carrito; se guardan juntos en un único movimiento de venta con el total consolidado.
