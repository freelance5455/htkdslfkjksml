-- KOR Training Center: safe, repeatable Supabase setup
-- Run in Supabase Dashboard -> SQL Editor. Existing rows are preserved.

ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS series_no integer,
  ADD COLUMN IF NOT EXISTS batch_no integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS training_months text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS finishing_date date,
  ADD COLUMN IF NOT EXISTS passport_photos jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS payment_slip_path text,
  ADD COLUMN IF NOT EXISTS remark text;

ALTER TABLE public.inventory
  ADD COLUMN IF NOT EXISTS item_code text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS item_condition text;

-- Private bucket for trainee passport photos and payment slip images.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('kor-student-files', 'kor-student-files', false, 10485760,
        ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/heic'])
ON CONFLICT (id) DO UPDATE
SET public = false,
    file_size_limit = 10485760,
    allowed_mime_types = EXCLUDED.allowed_mime_types;

-- Only authenticated staff can read or manage files in this private bucket.
DROP POLICY IF EXISTS "KOR staff read trainee files" ON storage.objects;
CREATE POLICY "KOR staff read trainee files" ON storage.objects
FOR SELECT TO authenticated
USING (bucket_id = 'kor-student-files');

DROP POLICY IF EXISTS "KOR staff upload trainee files" ON storage.objects;
CREATE POLICY "KOR staff upload trainee files" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'kor-student-files');

DROP POLICY IF EXISTS "KOR staff update trainee files" ON storage.objects;
CREATE POLICY "KOR staff update trainee files" ON storage.objects
FOR UPDATE TO authenticated
USING (bucket_id = 'kor-student-files')
WITH CHECK (bucket_id = 'kor-student-files');

DROP POLICY IF EXISTS "KOR staff delete trainee files" ON storage.objects;
CREATE POLICY "KOR staff delete trainee files" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'kor-student-files');

-- The app also syncs payments using these existing columns:
-- student_id, amount, payment_date, payment_method, description.
-- Keep the existing public.students, attendance, payments and inventory rows.
-- Existing authenticated-user RLS policies must allow the signed-in staff role
-- to access the relevant rows. Never put a service-role key in browser code.
