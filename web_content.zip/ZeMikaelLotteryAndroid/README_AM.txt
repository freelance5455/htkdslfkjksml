ዘ ሚካኤል Lottery — Android APK ለመገንባት

ይህ የAndroid Studio ፕሮጀክት ነው፤ APK ፋይል አይደለም። በዚህ የስራ አካባቢ Android SDK/Gradle ስላልተገኙ ቀጥታ APK ማቀናበር አልተቻለም።

1. ZIP ፋይሉን አውርደህ አውጣው።
2. Android Studio ክፈት።
3. Open በመጫን ZeMikaelLotteryAndroid ፎልደሩን ምረጥ።
4. Gradle sync እስኪጨርስ ጠብቅ።
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ምረጥ።
6. የAPK ፋይሉ ብዙ ጊዜ app/build/outputs/apk/debug/app-debug.apk ውስጥ ይገኛል።

ማስታወሻዎች:
- አፑ Firebase Realtime Database ለመጠቀም ኢንተርኔት ይፈልጋል።
- በAPK ላይ ሙሉ የስራ ሙከራ አልተደረገም። ከማሰራጨት በፊት በስልክ ላይ ፈትሽ።
- ይህ የUser App ነው፤ Admin App አይደለም።
