# zip2apk

ZIP ফাইল আপলোড করলে APK বানিয়ে দেয়। ফোনের ব্রাউজার থেকেই ব্যবহার করা যায়।

## চালানো
    docker build -t zip2apk .
    docker run -p 8080:8080 -v zip2apk-data:/data -e API_KEY=আপনার-গোপন-কী zip2apk

তারপর ব্রাউজারে `http://<সার্ভারের-IP>:8080` খুলুন (একই Wi-Fi-তে ফোন থেকেও চলবে)।

## সাপোর্টেড প্রজেক্ট
| ধরন | কীভাবে চেনে | বিল্ড |
|---|---|---|
| Web (HTML/CSS/JS) | `index.html` | WebView টেমপ্লেটে মোড়ানো |
| Vite/React/Vue ইত্যাদি | `package.json` + `build` script | `npm run build` → WebView |
| Android Studio | `gradlew` / `settings.gradle` | `assembleDebug` |
| Flutter | `pubspec.yaml` | `flutter build apk` |
| React Native | `react-native` dependency | `assembleRelease` |
| Expo | `expo` dependency | `expo prebuild` + Gradle |
| Capacitor | `@capacitor/core` | `cap sync` + Gradle |
| Cordova | `config.xml` | `cordova build android` |

## গুরুত্বপূর্ণ
- সার্ভারে কমপক্ষে **4 GB RAM** ও **10 GB+ ডিস্ক** রাখুন; বিল্ড ধীর।
- ZIP-এর ভেতরের কোড সার্ভারে চলে। তাই সার্ভার পাবলিক করলে অবশ্যই `API_KEY` দিন এবং অচেনা ফাইল চালাবেন না।
- সব APK একটি ডিবাগ কী দিয়ে সাইন হয়। Play Store-এর জন্য নিজের release keystore দিয়ে সাইন করতে হবে।
- ফাইল ৬ ঘণ্টা পরে মুছে যায়।
