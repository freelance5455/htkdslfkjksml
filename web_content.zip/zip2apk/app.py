"""zip2apk build server: upload a project .zip -> get an installable .apk."""
import os, re, json, shutil, subprocess, threading, time, uuid, zipfile
from pathlib import Path
from flask import Flask, request, jsonify, send_file, send_from_directory, abort

BASE = Path(os.environ.get("WORK_DIR", "/data"))
JOBS_DIR = BASE / "jobs"
TEMPLATE = Path(__file__).parent / "webview_template"
API_KEY = os.environ.get("API_KEY", "")
MAX_MB = int(os.environ.get("MAX_UPLOAD_MB", "300"))
STEP_TIMEOUT = int(os.environ.get("STEP_TIMEOUT_SEC", "2400"))
JOB_TTL = 6 * 3600
JOBS_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = MAX_MB * 1024 * 1024
jobs = {}
build_slot = threading.Semaphore(int(os.environ.get("BUILD_SLOTS", "1")))


# ---------- helpers ----------
class BuildError(Exception):
    pass


def run(cmd, cwd, log, env=None, timeout=STEP_TIMEOUT):
    log.write(f"\n$ {' '.join(map(str, cmd))}\n"); log.flush()
    e = {**os.environ, "CI": "true", **(env or {})}
    p = subprocess.Popen(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, env=e)
    try:
        code = p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        raise BuildError(f"Timed out: {cmd[0]}")
    if code != 0:
        raise BuildError(f"Command failed ({code}): {' '.join(map(str, cmd[:3]))}")


def safe_extract(zpath, dest):
    dest = dest.resolve()
    with zipfile.ZipFile(zpath) as z:
        for m in z.infolist():
            if (m.external_attr >> 16) & 0o170000 == 0o120000:
                continue  # skip symlinks
            target = (dest / m.filename).resolve()
            if dest != target and dest not in target.parents:
                raise BuildError("Unsafe path in zip")
            z.extract(m, dest)
            mode = (m.external_attr >> 16) & 0o777
            if mode and not m.is_dir():
                try: os.chmod(target, mode | 0o600)
                except OSError: pass


def read_pkg(d):
    try:
        return json.loads((d / "package.json").read_text())
    except Exception:
        return None


def detect(d):
    """Return project type for directory d, or None."""
    if (d / "pubspec.yaml").exists():
        return "flutter"
    pkg = read_pkg(d)
    if pkg:
        deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
        if "react-native" in deps and "expo" not in deps: return "react-native"
        if "expo" in deps: return "expo"
        if "@capacitor/core" in deps: return "capacitor"
        if "cordova" in deps or (d / "config.xml").exists(): return "cordova"
    if any((d / f).exists() for f in ("gradlew", "settings.gradle", "settings.gradle.kts")):
        return "android"
    if (d / "index.html").exists():
        return "web"
    if pkg and "build" in pkg.get("scripts", {}):
        return "node-web"
    return None


def find_project(dest):
    best = None
    for dirpath, dirs, _ in os.walk(dest):
        dirs[:] = [x for x in dirs if x not in ("node_modules", "__MACOSX", ".git")]
        depth = Path(dirpath).relative_to(dest).parts
        if len(depth) > 3:
            dirs[:] = []
            continue
        t = detect(Path(dirpath))
        if t and (best is None or len(depth) < best[2]):
            best = (Path(dirpath), t, len(depth))
    if not best:
        raise BuildError("Could not recognise the project type (no index.html, package.json, pubspec.yaml or Gradle files found).")
    return best[0], best[1]


def sdk_tool(name):
    home = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT") or ""
    c = sorted(Path(home, "build-tools").glob(f"*/{name}"), reverse=True)
    return str(c[0]) if c else None


def sign_apk(apk, log):
    ks = BASE / "debug.keystore"
    if not ks.exists():
        run(["keytool", "-genkeypair", "-keystore", str(ks), "-storepass", "android", "-keypass", "android",
             "-alias", "key", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
             "-dname", "CN=zip2apk"], BASE, log)
    aligned, signed = apk.with_name("aligned.apk"), apk.with_name("signed.apk")
    za, asg = sdk_tool("zipalign"), sdk_tool("apksigner")
    if not za or not asg:
        raise BuildError("zipalign/apksigner not found in Android SDK")
    run([za, "-f", "-p", "4", str(apk), str(aligned)], apk.parent, log)
    run([asg, "sign", "--ks", str(ks), "--ks-pass", "pass:android", "--out", str(signed), str(aligned)], apk.parent, log)
    return signed


def pick_apk(root, since):
    c = [p for p in root.rglob("*.apk")
         if "node_modules" not in p.parts and "androidTest" not in p.name and p.stat().st_mtime >= since]
    if not c:
        raise BuildError("Build finished but no APK was produced")
    return max(c, key=lambda p: p.stat().st_mtime)


def gradle(root, task, log):
    lp = root / "local.properties"
    if lp.exists(): lp.unlink()  # stale sdk.dir from the author's machine
    gw = root / "gradlew"
    if gw.exists():
        gw.chmod(0o755); cmd = [str(gw)]
    else:
        cmd = ["gradle"]
    run(cmd + [task, "--no-daemon", "--console=plain"], root, log)


def node_install(root, log):
    if (root / "yarn.lock").exists(): run(["yarn", "install"], root, log)
    elif (root / "pnpm-lock.yaml").exists(): run(["pnpm", "install"], root, log)
    elif (root / "package-lock.json").exists(): run(["npm", "ci"], root, log)
    else: run(["npm", "install"], root, log)


def has_script(root, name):
    pkg = read_pkg(root) or {}
    return name in pkg.get("scripts", {})


# ---------- builders ----------
def build_android(root, log):
    try:
        gradle(root, "assembleDebug", log)
    except BuildError:
        gradle(root, "assembleRelease", log)


def build_flutter(root, log):
    try:
        run(["flutter", "build", "apk", "--release"], root, log)
    except BuildError:
        run(["flutter", "build", "apk", "--debug"], root, log)


def build_rn(root, log):
    node_install(root, log)
    gradle(root / "android", "assembleRelease", log)


def build_expo(root, log):
    node_install(root, log)
    run(["npx", "expo", "prebuild", "--platform", "android", "--no-install"], root, log)
    gradle(root / "android", "assembleRelease", log)


def build_capacitor(root, log):
    node_install(root, log)
    if has_script(root, "build"): run(["npm", "run", "build"], root, log)
    if not (root / "android").exists(): run(["npx", "cap", "add", "android"], root, log)
    run(["npx", "cap", "sync", "android"], root, log)
    gradle(root / "android", "assembleDebug", log)


def build_cordova(root, log):
    node_install(root, log) if (root / "package.json").exists() else None
    if not (root / "platforms" / "android").exists():
        run(["npx", "--yes", "cordova", "platform", "add", "android"], root, log)
    run(["npx", "--yes", "cordova", "build", "android"], root, log)


def find_web_dir(root):
    for name in ("dist", "build", "out", "public", "www"):
        if (root / name / "index.html").exists():
            return root / name
    if (root / "index.html").exists():
        return root
    raise BuildError("No index.html found after build")


def xml_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def build_web(webdir, job_dir, name, log):
    """Wrap static web files into the bundled WebView template."""
    tpl = job_dir / "template"
    shutil.copytree(TEMPLATE, tpl)
    assets = tpl / "app/src/main/assets"
    shutil.rmtree(assets, ignore_errors=True)
    shutil.copytree(webdir, assets, ignore=shutil.ignore_patterns("node_modules", ".git"))
    slug = re.sub(r"[^a-z0-9]", "", name.lower()) or "app"
    if slug[0].isdigit(): slug = "a" + slug
    for f, reps in {"app/build.gradle": {"__APP_ID__": f"com.zip2apk.{slug}"},
                    "app/src/main/AndroidManifest.xml": {"__APP_NAME__": xml_escape(name)}}.items():
        p = tpl / f
        t = p.read_text()
        for k, v in reps.items(): t = t.replace(k, v)
        p.write_text(t)
    gradle(tpl, "assembleDebug", log)
    return tpl


def process(job_id, zpath, name):
    job = jobs[job_id]
    jdir = JOBS_DIR / job_id
    with build_slot, open(jdir / "build.log", "a") as log:
        try:
            job["status"] = "building"
            since = time.time()
            src = jdir / "src"; src.mkdir()
            safe_extract(zpath, src)
            root, kind = find_project(src)
            job["type"] = kind
            log.write(f"Detected project type: {kind} ({root.relative_to(src)})\n"); log.flush()
            name = name or root.name or "My App"
            search_root = root
            if kind == "android": build_android(root, log)
            elif kind == "flutter": build_flutter(root, log)
            elif kind == "react-native": build_rn(root, log)
            elif kind == "expo": build_expo(root, log)
            elif kind == "capacitor": build_capacitor(root, log)
            elif kind == "cordova": build_cordova(root, log)
            elif kind == "web": search_root = build_web(root, jdir, name, log)
            elif kind == "node-web":
                node_install(root, log); run(["npm", "run", "build"], root, log)
                search_root = build_web(find_web_dir(root), jdir, name, log)
            apk = pick_apk(search_root, since)
            if "unsigned" in apk.name:
                apk = sign_apk(apk, log)
            final = jdir / "app.apk"
            shutil.copy(apk, final)
            job["status"] = "done"
            log.write(f"\nDONE: {final.stat().st_size // 1024} KB\n")
        except Exception as e:
            job["status"] = "failed"; job["error"] = str(e)
            log.write(f"\nERROR: {e}\n")
        finally:
            shutil.rmtree(jdir / "src", ignore_errors=True)
            shutil.rmtree(jdir / "template", ignore_errors=True)
            zpath.unlink(missing_ok=True)


def check_key():
    if API_KEY and request.headers.get("X-API-Key") != API_KEY:
        abort(401)


def valid_id(i):
    if not re.fullmatch(r"[0-9a-f]{32}", i) or i not in jobs:
        abort(404)


# ---------- routes ----------
@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/config")
def config():
    return jsonify(needs_key=bool(API_KEY), max_mb=MAX_MB)


@app.post("/api/build")
def build():
    check_key()
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".zip"):
        return jsonify(error="Upload a .zip file"), 400
    job_id = uuid.uuid4().hex
    jdir = JOBS_DIR / job_id; jdir.mkdir()
    zpath = jdir / "upload.zip"; f.save(zpath)
    if not zipfile.is_zipfile(zpath):
        shutil.rmtree(jdir); return jsonify(error="Not a valid zip file"), 400
    jobs[job_id] = {"status": "queued", "type": None, "error": None, "created": time.time()}
    threading.Thread(target=process, args=(job_id, zpath, request.form.get("name", "").strip()[:60]), daemon=True).start()
    return jsonify(id=job_id)


@app.get("/api/status/<job_id>")
def status(job_id):
    check_key(); valid_id(job_id)
    j = jobs[job_id]
    lp = JOBS_DIR / job_id / "build.log"
    log = lp.read_text(errors="replace")[-4000:] if lp.exists() else ""
    return jsonify(status=j["status"], type=j["type"], error=j["error"], log=log)


@app.get("/api/download/<job_id>")
def download(job_id):
    check_key(); valid_id(job_id)
    p = JOBS_DIR / job_id / "app.apk"
    if not p.exists(): abort(404)
    return send_file(p, as_attachment=True, download_name="app.apk",
                     mimetype="application/vnd.android.package-archive")


def janitor():
    while True:
        time.sleep(600)
        for i, j in list(jobs.items()):
            if time.time() - j["created"] > JOB_TTL and j["status"] in ("done", "failed"):
                shutil.rmtree(JOBS_DIR / i, ignore_errors=True); jobs.pop(i, None)


threading.Thread(target=janitor, daemon=True).start()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")), threaded=True)
