SAJAD ASADI SCANNER — Android project V2

این پوشه پروژه اندروید است که نسخه دوم اسکنر BNB و TRON را داخل WebView اجرا می‌کند.

ساخت APK:
1) Android Studio را نصب کنید.
2) از File > Open همین پوشه SAJAD_ASADI_SCANNER_ANDROID را باز کنید.
3) منتظر بمانید Gradle Sync کامل شود و در صورت درخواست، Android SDK Platform 35 و JDK 17 را نصب کنید.
4) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) استفاده کنید.
5) فایل APK معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نیازمندی‌ها:
- Android Studio و Android SDK
- JDK 17
- اتصال اینترنت در زمان استفاده از داده‌های بلاکچین

نکته:
- این محیط Android SDK و Gradle نصب‌شده ندارد؛ بنابراین APK امضاشده/نهایی از اینجا کامپایل نشده است.
- این پروژه سورس آماده Android Studio است، نه فایل APK.
- اپ فقط اطلاعات عمومی را می‌خواند و تراکنش را امضا یا ارسال نمی‌کند.
- برای قابلیت‌های API و تاریخچه/توکن‌ها، کلیدهای API مربوطه را فقط در فیلدهای اختیاری برنامه وارد کنید.
