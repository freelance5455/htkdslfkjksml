可爱豆丁｜Android 项目 ZIP

这个 ZIP 是 Android Studio 工程源码包，不是可直接点击安装的 APK。
内含：当前网页版本 index.html，以及用于 Android WebView 的外壳工程。

重要说明：
1. 需要使用 Android Studio（电脑）打开本文件夹并构建 APK；首次构建通常需要联网下载 Gradle/Android SDK 组件。
2. 如果你只有手机、没有电脑，这个 ZIP 本身不能直接安装。需要使用支持 Android 项目构建的手机端 IDE/云构建服务来生成 APK。
3. 数据保存在应用 WebView 的本地存储中。卸载应用或清除应用数据可能导致数据丢失，请定期使用应用内的备份/导出功能。
4. 应用名：可爱豆丁；包名：com.keaidouding.ledger；最低 Android 版本：Android 6.0（API 23）。

用 Android Studio 构建：
- 解压 ZIP
- Android Studio 选择 Open，打开解压后的“可爱豆丁_安卓项目”文件夹
- 等待 Gradle Sync 完成
- 选择 Build > Build APK(s)
- APK 通常位于 app/build/outputs/apk/debug/app-debug.apk
