NEXUS V1 — PACOTE WEB EXPANDIDO
================================

O QUE ESTE ZIP CONTÉM
- Interface futurista responsiva, em português.
- Navegação: Início, Chat, Matemática, Aprender e Biblioteca.
- Seleção e prévia de fotos de exercícios.
- Calculadora local com aritmética básica e suporte limitado a equações lineares do tipo ax+b=c.
- Preferências de aprendizagem salvas localmente.
- Contagem demonstrativa de exercícios resolvidos.
- Importação local de arquivos de texto (TXT, MD, JSON, CSV), busca por palavras-chave e remoção de documentos.
- Chat demonstrativo com busca nos textos importados e cálculos simples.
- Teste de fala usando recursos disponíveis no navegador.
- Manifest e service worker para uso como PWA em hospedagem/local server compatível.

O QUE NÃO ESTÁ IMPLEMENTADO COMO IA REAL
Este ZIP NÃO contém uma IA generativa local completa, modelo GGUF/ONNX/TFLite, OCR matemático para ler a foto, embeddings semânticos, um motor de voz offline garantido, ou um aplicativo Android nativo compilável. Portanto não pode, sozinho, fazer tudo o que foi planejado para o NEXUS definitivo. As telas e recursos demonstrativos estão incluídos, mas alguns dependem de componentes que ainda precisam ser integrados.

POR QUE NÃO INCLUI UM MODELO DE IA GRANDE
Modelos locais ocupam centenas de MB a vários GB, e é necessário escolher um modelo compatível com o processador, RAM, armazenamento e runtime Android do dispositivo. Não é seguro prometer que um modelo qualquer funcionará em todos os celulares. Também não seria correto fingir que um ZIP de HTML é um APK Android nativo.

COMO TESTAR
1. Baixe este ZIP e extraia TODOS os arquivos.
2. Os arquivos index.html, style.css, app.js, manifest.json e sw.js devem ficar juntos na mesma pasta.
3. Se seu conversor oferece "HTML/Website/WebView", selecione a pasta extraída ou index.html, de acordo com as instruções do conversor.
4. Se o conversor exige uma URL hospedada, não aceita HTML local ou exige um projeto Android/Gradle, este pacote não basta para esse aplicativo específico.
5. Abra index.html num navegador para testar a interface. Algumas funções de PWA/service worker funcionam apenas em HTTPS ou localhost.

IMPORTANTE SOBRE VOZ E OFFLINE
A interface e o código de cálculo/busca funcionam localmente. SpeechRecognition e SpeechSynthesis dependem do suporte do navegador e podem utilizar serviços externos; não garantem voz totalmente offline. Não insira dados sensíveis em ambientes de teste.

PRIVACIDADE E ARMAZENAMENTO
Biblioteca, preferências e progresso são guardados em localStorage do navegador. Limpar dados do navegador/app pode apagar essas informações. A importação de documentos tem limites para evitar ocupar armazenamento excessivo. Este protótipo não envia os documentos a um servidor por código próprio.

PRÓXIMAS INTEGRAÇÕES NECESSÁRIAS PARA A VERSÃO COMPLETA
1. Runtime de inferência local Android e modelo de linguagem compatível.
2. OCR matemático local para imagens e confirmação da expressão reconhecida.
3. Resolvedor simbólico mais robusto e verificação independente de passos.
4. Banco de dados local/indexação semântica para biblioteca e citações.
5. Reconhecimento de fala e síntese de voz realmente offline.
6. Aplicação Android nativa/empacotamento testado no aparelho.
7. Testes de desempenho, consumo de RAM, bateria, permissões e segurança.

Este arquivo é um protótipo expandido e uma base de projeto, não uma alegação de que a IA completa está pronta.
