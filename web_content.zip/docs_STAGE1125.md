# CPLS V2 — Stage 1125

## Futures chart interaction hardening
- Added pinch zoom on touch devices.
- Added horizontal drag/pan while preserving the full candle dataset.
- Added mouse-wheel zoom for desktop/browser testing.
- Candle selection remains available and now respects the visible viewport.
- Timeframe changes reset the viewport to the latest candles.
- No undocumented Futures WebSocket subscription payload was introduced.

This is a source ZIP stage; live LBank connectivity and APK build were not performed in this environment.
