WildNotes — web app package (pre-release)

WHAT WAS FIXED
- Added the web app manifest link to the page.
- Added service-worker registration for HTTPS/localhost hosting.
- Fixed the service worker's broken logo cache path (the old path did not exist and could prevent offline installation).
- Updated cache version and cache cleanup.

HOW TO TEST
1. Upload the CONTENTS of the wildstudy_work folder to a new HTTPS static host (for example, a new Netlify site).
2. Open the hosted site on an Android phone in Chrome.
3. Test every section, reload the page, test offline mode after the first load, upload/download files, and export/import a backup.
4. Check the browser console for errors.

IMPORTANT LIMITATIONS
- Sticky notes are saved in this browser/app's local storage. They remain available when WildNotes is reopened, but this web app cannot display a floating note over other apps after it is closed.
- A ZIP-to-APK converter does not automatically create a true Android system overlay. That requires a native Android implementation (draw-over-other-apps permission, foreground service/notification as applicable) and a proper Android project/build.
- This package has not been certified or tested on real Android devices and is NOT guaranteed Google Play-ready. Google Play publishing requires a signed Android App Bundle (AAB), target API compliance, privacy/data safety disclosures, and device testing. Do not submit the ZIP directly.

TO-DO LIST FIX
- The To-do List now runs as an isolated module so an unrelated page script error will not prevent it from loading.
- Add tasks using the text field and Add button, tick them complete, edit/delete tasks, and clear completed tasks.
- Tasks save to local browser storage when available. If storage is blocked, they remain usable for the current session but may not persist after closing.
