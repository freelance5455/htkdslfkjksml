plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.flyers.selphycp1300photoprintconverter"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.flyers.selphycp1300photoprintconverter"
        minSdk = 24
        targetSdk = 36
        versionCode = 12
        versionName = "1.2"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.webkit:webkit:1.14.0")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
