package cz.flyers.selphyconverter

import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {
    private var adView: AdView? = null

    companion object {
        // Google test banner. Replace only this value with your own AdMob banner ID for release.
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupWebView()
        MobileAds.initialize(this) {
            runOnUiThread { loadBanner() }
        }
    }

    private fun loadBanner() {
        val container = findViewById<FrameLayout>(R.id.adContainer)
        if (adView != null) return

        val view = AdView(this)
        view.adUnitId = BANNER_AD_UNIT_ID
        val widthPx = container.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val widthDp = (widthPx / resources.displayMetrics.density).toInt().coerceAtLeast(1)
        view.setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, widthDp))
        container.removeAllViews()
        container.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        adView = view
        view.loadAd(AdRequest.Builder().build())
    }

    private fun setupWebView() {
        val webView = findViewById<WebView>(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            @Suppress("DEPRECATION")
            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(android.net.Uri.parse(url))
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onDestroy() {
        adView?.destroy()
        adView = null
        super.onDestroy()
    }
}
