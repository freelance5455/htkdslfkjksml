# SELPHY CP1300 PHOTO PRINT CONVERTER — BETA 1.2 + AdMob

Build-ready Android WebView project based on the verified BETA 1.2 HTML.

## Included
- BETA 1.2 HTML with the working calibration-test fix.
- Native Google AdMob anchored adaptive banner at the very top.
- WebViewAssetLoader local asset loading.
- Portrait-only app, Android API 24+, target/compile SDK 36.
- Package: `com.flyers.selphycp1300photoprintconverter`
- Version: `1.2` / code `12`.
- Google test App ID and test banner ID are included so the APK can be tested safely.

## Important before publishing
The project currently uses Google's official test IDs. They are safe for development but do not generate your revenue.
Replace:
1. `ca-app-pub-3940256099942544~3347511713` in `AndroidManifest.xml` with your AdMob App ID.
2. `ca-app-pub-3940256099942544/9214589741` in `MainActivity.kt` with your AdMob banner ad-unit ID.

For EEA/UK/Switzerland distribution, add Google's consent flow before serving personalized ads.

## Build
Open in Android Studio, allow Gradle sync, then Build > Build APK(s).
