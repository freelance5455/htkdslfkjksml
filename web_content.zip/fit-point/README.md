# FIT POINT MEN'S WEAR

A connected e-commerce starter with a Kotlin/Jetpack Compose Android customer app, separate responsive admin web dashboard, and shared development API. Branding follows the supplied reference: charcoal/black, white shopping surfaces, and orange accents.

## Current implementation status

- **Implemented in this workspace:** Node.js API; customer registration/login/session endpoints; password hashing with scrypt; role-separated admin login; catalog/search/categories; profile and address endpoints; wishlist endpoints; COD order creation with server-side price/stock checks; order history/cancellation; admin product/category/order/customer/inventory/settings/analytics endpoints; image upload endpoint; responsive admin UI; Android Compose source for authentication, catalog, product detail, cart, COD checkout, order history and profile; API smoke tests.
- **Not yet production-ready:** the API persists to a local JSON file for development rather than a transactional production database; uploaded images are local disk; admin authorization currently has a single admin role; customer wishlist UI is a placeholder; Android product photos are not yet rendered from remote image URLs; address edit/delete, forgot-password/OTP, returns/support tickets, full review/rating flow and complete analytics date filtering are not implemented. Some end-to-end mobile paths need build/device verification.
- **Not verified:** Android APK build, because this environment did not expose Gradle or an Android SDK in the initial inspection. Source build files are included.

## Requirements

- Node.js 20 or newer.
- Android Studio with Android SDK 35 and Gradle support to build the Android app.
- A device/emulator for testing. The default API URL `http://10.0.2.2:4100` is for the Android emulator talking to the host machine.

## Start the API

```bash
cd backend
npm start
```

Health check: `http://localhost:4100/health`.

The first start creates `backend/data/db.json` with the seven required categories. This JSON store is strictly for local development and must not be deployed to a public production environment. Do not run multiple API instances against the same JSON file.

## Create the first admin securely

Set credentials in your shell (not in source files):

```bash
cd backend
export ADMIN_EMAIL='your-admin@example.com'
export ADMIN_PASSWORD='use-a-unique-password-at-least-12-chars'
export ADMIN_NAME='Store Owner'
node src/bootstrap-admin.js
```

The bootstrap script refuses short passwords and duplicate admin emails. There is no hardcoded production admin account.

## Run the Admin Dashboard

Serve `admin/` from a local static server at `http://localhost:5173` (or configure `CORS_ORIGIN` to match your server). For example, if Python is installed:

```bash
cd admin
python3 -m http.server 5173
```

Open `http://localhost:5173`. Sign in with the administrator created above. The dashboard uses the shared API; it does not use a separate demo product dataset. Set the API URL in the browser console before refreshing if needed: `localStorage.setItem('fp_api','http://localhost:4100')`.

## Build Android

Open the `android/` directory in Android Studio, allow Gradle sync, install SDK Platform 35, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Or from the Android directory where Gradle is installed:

```bash
gradle assembleDebug
```

APK output is normally `android/app/build/outputs/apk/debug/app-debug.apk`. The Android source uses `10.0.2.2` for emulator networking. For a physical device, change `API_BASE_URL` in `android/app/build.gradle.kts` to your development machine's LAN IP and use a development-only cleartext network policy. Production must use HTTPS and disable cleartext traffic.

## Tests

```bash
cd backend
npm test
```

The current test suite covers API startup, registration/login behavior, customer session access, catalog retrieval and customer-vs-admin endpoint separation. It is not a substitute for full integration, concurrency, security and device testing.

## Production hardening before launch

1. Replace the JSON file store with PostgreSQL or a properly configured managed database. Use database transactions/row locks for stock reservation and idempotency keys for order creation.
2. Replace local uploads with private object storage, content inspection, image resizing and signed/authorized uploads.
3. Put the API behind HTTPS and configure exact CORS origins, rate limiting, request size limits, logging, backups and monitoring.
4. Use a dedicated identity provider or reviewed authentication/session implementation; add rate limiting, email/mobile verification and password reset.
5. Add database-level row/role security, separate fine-grained admin permissions, and security review before exposing admin customer data.
6. Configure the store's actual terms, privacy policy, support contact, delivery policy, taxes, inventory, licensed product photos and cancellation policy.
7. Configure a real deployment and Android signing key. Never commit signing keys or secrets.

## Shared data model (development JSON schema)

`users` (customer identity, password hash, addresses, wishlist), `admins` (separate admin identities and password hashes), `products` (catalog, image references, variant inventory), `categories`, `orders` (customer, line items, COD/payment collection status, delivery address and status history), `settings`, `tokens`, and `audit`. A production migration should normalize this into relational tables and enforce foreign keys and constraints.
