# FIT POINT Android APK ഉണ്ടാക്കാനുള്ള മലയാളം ഗൈഡ്

## ആദ്യം അറിയേണ്ടത്
ഈ ZIP-ൽ Android ആപ്പിന്റെ source code, Admin Dashboard, backend API എന്നിവയുണ്ട്. APK ഇതിനകം നിർമ്മിച്ചിട്ടില്ല. APK നിർമ്മിക്കാൻ കമ്പ്യൂട്ടറിൽ Android Studioയും Android SDKയും ആവശ്യമാണ്.

## 1. ആവശ്യമായ സോഫ്റ്റ്‌വെയർ
- Android Studio (പുതിയ സ്ഥിരതയുള്ള പതിപ്പ്)
- Android SDK Platform 35
- Android Studio-യിൽ ലഭിക്കുന്ന Gradle/JDK പിന്തുണ
- Backend പ്രവർത്തിപ്പിക്കാൻ Node.js 20 അല്ലെങ്കിൽ അതിനുമുകളിൽ

## 2. Android പ്രോജക്ട് തുറക്കുക
1. ZIP extract ചെയ്യുക.
2. Android Studio തുറക്കുക.
3. `fit-point/android` എന്ന ഫോൾഡർ `Open` വഴി തുറക്കുക. ZIP ഫയൽ നേരിട്ട് തുറക്കരുത്.
4. Gradle Sync പൂർത്തിയാകുന്നതുവരെ കാത്തിരിക്കുക.
5. SDK 35 ഇൻസ്റ്റാൾ ചെയ്യണമെന്ന് ആവശ്യപ്പെട്ടാൽ Android Studio SDK Manager വഴി ഇൻസ്റ്റാൾ ചെയ്യുക.

## 3. APK നിർമ്മിക്കുക
Android Studio മെനുവിൽ:
1. `Build` തിരഞ്ഞെടുക്കുക.
2. `Build Bundle(s) / APK(s)` തിരഞ്ഞെടുക്കുക.
3. `Build APK(s)` അമർത്തുക.
4. Build വിജയിച്ചാൽ വരുന്ന `Locate` ലിങ്ക് അമർത്തി APK കണ്ടെത്തുക.

സാധാരണ Debug APK പാത:
`android/app/build/outputs/apk/debug/app-debug.apk`

അല്ലെങ്കിൽ Android Studio Terminal-ൽ `android` ഫോൾഡറിനുള്ളിൽ `gradle assembleDebug` പ്രവർത്തിപ്പിക്കാം, പക്ഷേ Gradle കമാൻഡ് ലഭ്യമായിരിക്കണം. Build വിജയിച്ചതിന് ശേഷമേ APK ഉണ്ടാകൂ.

## 4. Backend പ്രവർത്തിപ്പിക്കുക
കമ്പ്യൂട്ടറിൽ Node.js 20+ ഇൻസ്റ്റാൾ ചെയ്തശേഷം Terminal-ൽ:

```bash
cd fit-point/backend
npm install
npm start
```

API ആരോഗ്യ പരിശോധന: `http://localhost:4100/health`

Android Emulator ഉപയോഗിക്കുമ്പോൾ ആപ്പിലെ API വിലാസം `http://10.0.2.2:4100` ആണ്. യഥാർത്ഥ Android ഫോണിൽ ടെസ്റ്റ് ചെയ്യുമ്പോൾ `10.0.2.2` പ്രവർത്തിക്കില്ല; കമ്പ്യൂട്ടറിന്റെ LAN IP ഉപയോഗിച്ച് `android/app/build.gradle.kts`-ലെ `API_BASE_URL` മാറ്റണം. ഫോണും കമ്പ്യൂട്ടറും ഒരേ Wi-Fi നെറ്റ്‌വർക്കിൽ ആയിരിക്കണം; firewall-ൽ ആവശ്യമായ port അനുവദിക്കണം.

## 5. Admin Dashboard
Backend പ്രവർത്തിക്കുന്നതിനുശേഷം മറ്റൊരു Terminal-ൽ:

```bash
cd fit-point/admin
python3 -m http.server 5173
```

Browser-ൽ `http://localhost:5173` തുറക്കുക. Admin account സൃഷ്ടിക്കുന്നതിനുള്ള നിർദ്ദേശങ്ങൾ പ്രധാന `README.md`-ൽ ഉണ്ട്.

## 6. പ്രധാന മുന്നറിയിപ്പുകൾ
- APK നിർമ്മിച്ചതുകൊണ്ട് മാത്രം app production-ready ആകില്ല.
- ഇപ്പോഴത്തെ backend development ആവശ്യത്തിനുള്ള JSON ഫയൽ സ്റ്റോറേജ് ഉപയോഗിക്കുന്നു. യഥാർത്ഥ ഉപഭോക്താക്കൾക്കായി ഉപയോഗിക്കുന്നതിന് മുമ്പ് സുരക്ഷിതമായ production database, HTTPS, rate limiting, transaction-safe inventory, production image storage എന്നിവ സജ്ജീകരിക്കണം.
- ഈ പ്രോജക്ടിന്റെ APK build ഈ പാക്കേജ് തയ്യാറാക്കിയ പരിതസ്ഥിതിയിൽ സ്ഥിരീകരിച്ചിട്ടില്ല. Android Studio Gradle sync/build പിശക് കാണിച്ചാൽ പിശകിന്റെ മുഴുവൻ സന്ദേശം പങ്കിടുക.
- യഥാർത്ഥ credentials അല്ലെങ്കിൽ secret keys source code-ൽ ചേർക്കരുത്.
