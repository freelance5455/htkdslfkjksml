# മൊബൈൽ ഫോൺ മാത്രം ഉപയോഗിച്ച് FIT POINT APK നിർമ്മിക്കാൻ

## പ്രധാനമായി അറിയുക
ഈ ZIP-ൽ Android source code, Admin Dashboard, backend source code, README എന്നിവ ഉൾപ്പെടുന്നു. **APK ഫയൽ ഇതിനകം ഇതിൽ ഇല്ല**; അത് Android build app ഉപയോഗിച്ച് നിർമ്മിക്കണം. ഫോണിൽ build വിജയിക്കുമെന്നത് നിങ്ങളുടെ ഫോണിന്റെ RAM, Android പതിപ്പ്, AndroidIDE/Gradle/SDK പിന്തുണ എന്നിവയെ ആശ്രയിക്കും.

## 1. ZIP extract ചെയ്യുക
1. ZIP ഫയൽ ഫോണിലേക്ക് ഡൗൺലോഡ് ചെയ്യുക.
2. Files / My Files ആപ്പിൽ ZIP കണ്ടെത്തി Extract ചെയ്യുക.
3. Extract ചെയ്ത `fit-point` ഫോൾഡർ കണ്ടെത്തുക.

## 2. ഫോണിൽ APK build ചെയ്യാൻ ശ്രമിക്കുക
1. AndroidIDE പോലുള്ള Android development IDE-ийг അതിന്റെ ഔദ്യോഗിക സ്രോതസ്സിൽ നിന്ന് ഇൻസ്റ്റാൾ ചെയ്യുക.
2. IDE-യിൽ `fit-point/android` ഫോൾഡർ തുറക്കുക (മുഴുവൻ project root അല്ല, `android` ഫോൾഡർ).
3. ആവശ്യമായ JDK, Android SDK, Gradle എന്നിവ IDE സജ്ജീകരിക്കാൻ അനുവദിക്കുക.
4. Gradle Sync വിജയിച്ചാൽ `assembleDebug` task പ്രവർത്തിപ്പിക്കുക.
5. Build വിജയിച്ചാൽ സാധാരണയായി `app/build/outputs/apk/debug/app-debug.apk` എന്ന പാതയിൽ APK ഉണ്ടാകും.
6. APK ഇൻസ്റ്റാൾ ചെയ്യുന്നതിന് മുമ്പ് Android ആവശ്യപ്പെടുന്നുവെങ്കിൽ ആ ഫയൽ മാനേജറിന് “Install unknown apps” അനുമതി നൽകുക. പരിചയമില്ലാത്ത APK-കൾ ഇൻസ്റ്റാൾ ചെയ്യരുത്.

**കുറിപ്പ്:** ഈ project-ന്റെ APK build ഇതുവരെ സ്ഥിരീകരിച്ചിട്ടില്ല. AndroidIDE എല്ലാ Gradle/SDK ആവശ്യങ്ങളും പിന്തുണയ്ക്കുമെന്ന് ഉറപ്പില്ല. Sync/build പിശക് വന്നാൽ പിശകിന്റെ screenshot അല്ലെങ്കിൽ മുഴുവൻ സന്ദേശം ആവശ്യമാണ്.

## 3. Backend ഫോണിൽ പ്രവർത്തിപ്പിക്കാനുള്ള പരിധികൾ
Backend Node.js ആവശ്യപ്പെടുന്നു. Termux പോലുള്ള പരിസ്ഥിതിയിൽ Node.js ഇൻസ്റ്റാൾ ചെയ്ത് development-നായി backend പ്രവർത്തിപ്പിക്കാൻ ശ്രമിക്കാം; എന്നാൽ Android background restrictions കാരണം അത് എല്ലായ്പ്പോഴും പ്രവർത്തിക്കണമെന്നില്ല. Termux-ൽ project folder access, Node.js install, `npm install`, `npm start` എന്നിവ സജ്ജീകരിക്കേണ്ടിവരും.

APK build ചെയ്യുന്നതും backend ഹോസ്റ്റ് ചെയ്യുന്നതും രണ്ട് വ്യത്യസ്ത കാര്യങ്ങളാണ്. ഫോണിൽ APK നിർമ്മിച്ചാൽ മാത്രം ഓൺലൈൻ ഷോപ്പ് പ്രവർത്തിക്കില്ല. മറ്റുള്ളവരുടെ ഫോണുകളിൽ നിന്ന് ഉപയോഗിക്കണമെങ്കിൽ backend-ഉം database-ഉം ഇന്റർനെറ്റിൽ സുരക്ഷിതമായി deploy ചെയ്യണം. ഫോൺ മാത്രം ഉപയോഗിച്ച് hosting dashboard-ുകൾ വഴി deployment ചെയ്യാൻ സാധിക്കാം, പക്ഷേ hosting/database അക്കൗണ്ടുകളും configuration-ഉം ആവശ്യമാണ്.

## 4. നിലവിലെ പരിധികൾ
- APK ഇപ്പോൾ ഉൾപ്പെടുത്തിയിട്ടില്ല.
- Backend ഇപ്പോൾ development JSON file storage ആണ്; production database അല്ല.
- Production HTTPS, transaction-safe inventory, cloud image storage, rate limiting, deployment എന്നിവ ഇനിയും ആവശ്യമാണ്.
- COD മാത്രമാണ് ഉദ്ദേശിച്ച payment method; യഥാർത്ഥ order flow-കൾ device-ൽ end-to-end പരിശോധിക്കണം.

## 5. ഉൾപ്പെടുത്തിയ ഫയലുകൾ
- `android/` — Kotlin / Jetpack Compose Android source
- `admin/` — Admin Dashboard
- `backend/` — Node.js API source
- `README.md` — setup and API instructions
- `APK-BUILD-GUIDE-MALAYALAM.md` — APK build guide
