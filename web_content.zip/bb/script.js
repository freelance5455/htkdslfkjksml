// JavaScript logic for Video Downloader UI
document.addEventListener('DOMContentLoaded', () => {
    const videoUrlInput = document.getElementById('videoUrl');
    const pasteBtn = document.getElementById('pasteBtn');
    const fetchBtn = document.getElementById('fetchBtn');
    const loadingState = document.getElementById('loadingState');
    const resultCard = document.getElementById('resultCard');
    
    const thumbnail = document.getElementById('thumbnail');
    const videoTitle = document.getElementById('videoTitle');
    const historyList = document.getElementById('historyList');

    const downloadHD = document.getElementById('downloadHD');
    const downloadSD = document.getElementById('downloadSD');
    const downloadAudio = document.getElementById('downloadAudio');

    let history = [];

    // Clipboard Paste Button
    pasteBtn.addEventListener('click', async () => {
        try {
            const text = await navigator.clipboard.readText();
            videoUrlInput.value = text;
        } catch (err) {
            alert('Paste feature requires clipboard permissions.');
        }
    });

    // Fetch Video Details
    fetchBtn.addEventListener('click', () => {
        const url = videoUrlInput.value.trim();
        if (!url) {
            alert('ကျေးဇူးပြု၍ Video Link တစ်ခုခု ထည့်ပေးပါ။');
            return;
        }

        // Show Loading
        loadingState.classList.remove('hidden');
        resultCard.classList.add('hidden');

        // Simulate API Fetch Delay
        setTimeout(() => {
            loadingState.classList.add('hidden');
            resultCard.classList.remove('hidden');

            // Sample Demo Output
            const sampleTitle = "Sample High Quality Social Media Video";
            const sampleThumb = "https://picsum.photos/300/200?random=1";

            thumbnail.src = sampleThumb;
            videoTitle.textContent = sampleTitle;

            // Direct demo download link or alert for showcase
            const dummyDownloadLink = url;
            downloadHD.href = dummyDownloadLink;
            downloadSD.href = dummyDownloadLink;
            downloadAudio.href = dummyDownloadLink;

            downloadHD.onclick = () => alert("Downloading 1080p Full HD Video...");
            downloadSD.onclick = () => alert("Downloading 720p HD Video...");
            downloadAudio.onclick = () => alert("Downloading MP3 Audio File...");

            // Add to history
            addToHistory(sampleTitle);
        }, 1500);
    });

    function addToHistory(title) {
        history.unshift(title);
        if (history.length > 3) history.pop();

        historyList.innerHTML = '';
        history.forEach(item => {
            const div = document.createElement('div');
            div.className = 'history-item';
            div.innerHTML = `
                <span class="history-item-title">${item}</span>
                <i class="fa-solid fa-circle-check" style="color: #10b981;"></i>
            `;
            historyList.appendChild(div);
        });
    }
});
