import subprocess

def listen_once():
    """Uses Android speech recognition through Termux:API; starts only on request."""
    try:
        p = subprocess.run(
            ["termux-speech-to-text"], capture_output=True, text=True, timeout=60
        )
        text = (p.stdout or "").strip()
        return text if text else "I did not hear anything. Please try again."
    except FileNotFoundError:
        return "Speech input unavailable. Install the Termux:API app and run: pkg install termux-api"
    except Exception as exc:
        return f"Speech input error: {exc}"

def speak(text):
    try:
        # Keep speech manageable; terminal/dashboard still displays the full answer.
        subprocess.run(["termux-tts-speak", text[:2500]], timeout=45,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
