FOREX 30 — PROYECTO ANDROID

Este archivo ZIP contiene el proyecto fuente de una app Android que envuelve la aplicación personal Forex 30 en una WebView. No es todavía un APK compilado.

CÓMO GENERAR EL APK
1. Instala Android Studio en una computadora.
2. Descomprime este ZIP.
3. En Android Studio, elige Open y selecciona la carpeta Forex30_Android_Project.
4. Espera a que Gradle sincronice el proyecto. Se requiere conexión a internet la primera vez para descargar las herramientas de compilación.
5. Selecciona Build > Build APK(s).
6. Android Studio mostrará la ubicación del APK generado. Normalmente estará en app/build/outputs/apk/debug/app-debug.apk.
7. Transfiere el APK a tu teléfono Android y ábrelo para instalarlo. Puede que debas autorizar temporalmente la instalación desde esa fuente.

NOTAS
- La app funciona sin conexión porque el HTML está incluido dentro del APK.
- El diario guarda datos en el almacenamiento local de la WebView de la app. Desinstalar la app puede borrar esos datos; exporta regularmente tu diario CSV.
- No se conecta a un bróker, no ejecuta operaciones ni ofrece señales financieras.
- Para distribuirla públicamente o instalarla en muchos dispositivos, conviene revisar firma, privacidad y política de datos.
