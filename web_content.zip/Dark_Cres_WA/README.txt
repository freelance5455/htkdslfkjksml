DARK CRES WA — TDKR V3
========================

Cara pakai:
1. Ekstrak ZIP.
2. Buka index.html menggunakan Chrome.
3. Masukkan key: freev1
4. Masukkan nomor dengan format +62 lalu pilih alat.

Catatan:
- Ini adalah dashboard alat bantu kontak yang aman.
- Tombol membuka chat WhatsApp melalui wa.me atau menyalin nomor.
- Tidak ada fitur untuk mengunci, merusak, membanjiri, atau mengganggu WhatsApp orang lain.
- Tidak meminta OTP, PIN, atau kata sandi WhatsApp.
- Perlu koneksi internet untuk membuka WhatsApp Web/deep link.
