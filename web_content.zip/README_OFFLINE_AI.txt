FORGELIFE 2.9 — FORGE AI AUTOMATIC FIRST-RUN MODEL SETUP

Forge AI is the primary assistant. On first launch, the native Android app downloads
Qwen3 0.6B INT4 no-thinking in LiteRT-LM format directly into the app's private
files directory, validates that the download is plausibly complete, then initializes
the on-device runtime. The model is retained between launches. Once downloaded,
chat inference runs locally and does not require internet access.

MODEL
- Repository: litert-community/Qwen3-0.6B-int4
- File: qwen3_0.6b_nothink_q4_block32_ekv1280.litertlm
- Approximate download: 347 MB
- License shown by repository: Apache-2.0
- Download occurs inside the app on first launch; the model is deliberately not
  embedded in the APK. Android's current LiteRT guidance recommends storing model
  files in app-private filesDir rather than APK assets. This also avoids producing
  a huge APK and avoids copying a second copy from the APK on first launch.

FIRST RUN
1. Install the APK while connected to the internet.
2. Open ForgeLife. Forge AI automatically downloads the model and displays progress.
3. Keep the app open until the status says LOCAL AI READY.
4. After that, enable airplane mode and chat with Forge AI.
5. On later launches, the cached model loads without downloading again.

If download fails, check the connection and reopen the app. A partially downloaded
file is discarded. The existing manual .litertlm import option remains available.

BUILD
1. Extract this ZIP and open the project folder in Android Studio.
2. Allow Gradle sync and install the required Android SDK.
3. Build > Build APK(s), then install the APK on Android 8.0+.
4. The app needs internet only for the first model download. The runtime dependency
   is LiteRT-LM Android 0.18.0. Test on the target device; actual speed and memory
   use depend on its chipset and available RAM.

LIMITATIONS
This is source code, not a compiled APK. It has not been compiled or tested on a
physical device in this environment. The download path, model initialization, and
actual offline inference must be verified in Android Studio on the target phone.
The model download requires roughly 350 MB of data and additional free storage.
