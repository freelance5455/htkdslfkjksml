# STYLEHUB – Firebase & Deployment Setup Guide

## 1. Project Folder Structure

- `firebase-applet-config.json` — Provisioned Firebase client configuration (`apiKey`, `projectId`, `firestoreDatabaseId`, `storageBucket`, etc.)
- `firebase-blueprint.json` — Entity & collection schema blueprint
- `firestore.rules` — Production Firestore Security Rules (enforces admin RBAC, customer PII isolation, and server-side order price/quantity/stock validation)
- `storage.rules` — Firebase Storage rules restricting product image uploads to verified admins
- `src/lib/firebase.ts` — Firebase App, Auth, Firestore, Storage initialization, `testConnection()`, and structured `handleFirestoreError()` helper
- `src/lib/catalogDefaults.ts` — Curated initial STYLEHUB fashion collection & categories for one-click admin seeding
- `src/types/store.ts` — TypeScript domain interfaces (`Product`, `Category`, `Order`, `OrderItem`, `UserProfile`, `AdminUser`, `StoreSettings`)
- `src/context/AuthContext.tsx` — Firebase Auth session, verified admin authorization check, and customer profile sync
- `src/context/CartContext.tsx` — Shopping bag state with quantity, stock clamping, and subtotal calculation
- `src/components/Navbar.tsx` — Minimalist 3-zone top navigation bar & responsive mobile bottom navigation bar
- `src/components/HeroSection.tsx` — Full-width editorial fashion hero banner
- `src/components/ProductCard.tsx` — Editorial product card with pricing, discount, sizes, Add to Cart & Buy Now
- `src/components/ProductDetailModal.tsx` — Product detail view with size/color selection & stock availability
- `src/components/CartDrawer.tsx` — Slide-over shopping bag with quantity steppers and checkout entry
- `src/components/CheckoutModal.tsx` — Validated delivery checkout form writing atomic Firestore order batches
- `src/components/CustomerAccountView.tsx` — Customer login/registration, profile management, order history & live order tracking
- `src/components/AdminLoginView.tsx` — Dedicated Admin Authentication portal
- `src/components/AdminDashboardView.tsx` — Full Admin Console (KPIs, Add/Edit/Delete Products with Firebase Storage upload, Manage Orders, Customers, Categories, Order History, Settings)
- `src/components/ErrorBoundary.tsx` — Resilient application error boundary

## 2. Firebase Console Configuration

1. **Authentication**:
   - **Google Sign-In** is enabled automatically by AI Studio provisioning and works immediately for both Customers and Admins.
   - To also allow **Email & Password** sign-in/registration, open [Firebase Console → Authentication → Sign-in method](https://console.firebase.google.com/) and enable **Email/Password**.
2. **Firestore Security Rules**:
   - Deployed via `firestore.rules`. Always review rules before sharing broadly.
3. **Firebase Storage**:
   - Enable **Storage** in the Firebase Console and paste `storage.rules` into **Storage → Rules** so verified admins can upload product photography directly to `/products/{productId}/...`.

## 3. Installation & Deployment

```bash
npm install
npm run lint
npm run build
```
