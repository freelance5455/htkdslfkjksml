# ⚡ Zero-Config Firebase Cloud & Developer Guide
### Maa Annapurna Tiffin Management System
### 100% Free Firebase Spark Plan & Pre-Configured Architecture

---

## 📱 User Experience (WhatsApp & Google Drive Style)

Users never see or enter any backend configuration. They experience a native app flow:
1. **Splash Screen**: Branded loading screen ("Maa Annapurna Tiffin - Pure • Hygienic • Homemade • Delicious") with live status animation.
2. **Login / Sign Up**:
   - **Mobile Number + OTP** (SMS verification)
   - **Email + Password** (Sign In, Register, Forgot Password)
   - **One-Click Demo Login**
3. **Dashboard**:
   - Automatic user profile provisioning
   - Automatic Firestore database partition creation (`tiffin_users/{userId}`)
   - Automatic cross-device live sync via Firestore `onSnapshot`
   - Offline-first cache with automatic sync when internet connects

---

## 🔐 Hidden Developer & Cloud Console (Admin Only)

Normal users never see any Firebase configuration, API keys, or project settings.

### How to Access Developer Console:
1. Open the app and navigate to the **Settings** tab.
2. Scroll to the bottom and click **"Developer & Cloud Console"** (Lock icon).
3. Enter the Developer Admin Password:
   ```text
   admin@annapurna2026
   ```
4. Click **Authorize**.

### Capabilities in Developer Console:
* **Firebase Project Configuration**: Change API Key, Project ID, Auth Domain, App ID if switching Firebase projects.
* **Pause / Resume Cloud Sync**: Instantly toggle background cloud sync on or off.
* **Export Full Database**: Download all client ledgers, boxes, logs, and menus as a `.json` backup.
* **Import Database**: Restore or migrate database from any `.json` backup.
* **Real-Time System Logs**: Inspect live console logs (auth events, Firestore write operations, errors).
* **Purge Cache & Manage Users**: Clear local storage cache and view current authenticated UID.

---

## 🔥 Pre-Configured Firebase Configuration Reference

All keys are pre-configured in [`firebase-config.js`](file:///C:/Users/Admin/.gemini/antigravity/scratch/tiffin-tracker-app/firebase-config.js):

```javascript
const PRECONFIGURED_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBv9311155593MaaAnnapurnaTiffin2026",
  authDomain: "maa-annapurna-tiffin.firebaseapp.com",
  projectId: "maa-annapurna-tiffin",
  storageBucket: "maa-annapurna-tiffin.appspot.com",
  messagingSenderId: "931115559300",
  appId: "1:931115559300:web:annapurnatiffinv2"
};
```

---

## 🛡️ Firestore Security Rules ([`firestore.rules`](file:///C:/Users/Admin/.gemini/antigravity/scratch/tiffin-tracker-app/firestore.rules))

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Multi-tenant isolation: Each business/user only accesses their own data
    match /tiffin_users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      match /{allSubcollections=**} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
    
    // Default deny
    match /{document=**} {
      allow read, write: false;
    }
  }
}
```

---

## 📊 100% Free Firebase Spark Plan Quotas

| Resource | Spark Plan Free Allowance | Tiffin App Usage |
|---|---|---|
| **Authentication** | Unlimited Email/Password, 10k Phone SMS/mo | Well within limits |
| **Firestore Document Reads** | 50,000 reads / day | Debounced real-time listeners |
| **Firestore Document Writes** | 20,000 writes / day | Debounced batch updates |
| **Firestore Stored Data** | 1 GB storage | Entire ledger < 15 MB |
| **Network Egress** | 10 GB / month | Lightweight JSON documents |
