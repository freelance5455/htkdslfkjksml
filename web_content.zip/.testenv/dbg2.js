const fs=require('fs'),path=require('path'),{JSDOM,VirtualConsole}=require('jsdom');
const P='/home/user/project';
let html=fs.readFileSync(path.join(P,'service-details.html'),'utf8');
html=html.replace('<script src="app.js"></script>','<script>'+fs.readFileSync(path.join(P,'app.js'),'utf8')+'</script>');
html=html.replace('<script src="services.js"></script>','<script>'+fs.readFileSync(path.join(P,'services.js'),'utf8')+'</script>');
const vc=new VirtualConsole();vc.on('jsdomError',e=>console.log('JSDOMERR',e.message));
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://x.test/service-details.html?office=registrar',virtualConsole:vc});
const w=dom.window;
console.log('page:',w.currentPageName&&w.currentPageName());
console.log('fn:',typeof w.initServiceDetailsPage);
console.log('content len:',w.document.getElementById('serviceDetailContent').innerHTML.length);
try{w.initServiceDetailsPage();}catch(e){console.log('THROW',e.message);}
console.log('bell:',(function(){try{w.renderNotificationBell();return 'ok'}catch(e){return e.message}})());console.log('rem:',(function(){try{w.startReminderWatcher();return 'ok'}catch(e){return e.message}})());console.log('after len:',w.document.getElementById('serviceDetailContent').innerHTML.length);
process.exit(0);
