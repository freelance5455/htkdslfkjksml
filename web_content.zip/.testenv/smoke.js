const fs=require('fs'),path=require('path'),{JSDOM}=require('jsdom');
const P='/home/user/project';
function build(page,search=''){
  let html=fs.readFileSync(path.join(P,page),'utf8');
  html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+fs.readFileSync(path.join(P,'style.css'),'utf8')+'</style>');
  html=html.replace('<script src="app.js"></script>','<script>'+fs.readFileSync(path.join(P,'app.js'),'utf8')+'</script>');
  html=html.replace('<script src="services.js"></script>','<script>'+fs.readFileSync(path.join(P,'services.js'),'utf8')+'</script>');
  const vc=new (require('jsdom').VirtualConsole)();
  const errs=[];vc.on('jsdomError',e=>errs.push(e.message));vc.on('error',e=>errs.push(String(e)));
  const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://x.test/'+page+search,virtualConsole:vc,pretendToBeVisual:true});
  dom.window.__errs=errs;
  dom.window.innerWidth=1400;dom.window.innerHeight=900;
  return dom;
}
const ready=dom=>new Promise(r=>{if(dom.window.document.readyState==='complete'||dom.window.document.readyState==='interactive')return r();dom.window.document.addEventListener('DOMContentLoaded',()=>setTimeout(r,0));setTimeout(r,500);});
let pass=0,fail=0;
const a=(c,m)=>{c?(pass++):(fail++,console.log('  FAIL: '+m));};
function login(dom,u,id){const w=dom.window,d=w.document;
  w.document.getElementById('navLoginBtn')?.click();
  d.getElementById('chooseStudentLogin')?.click();
  d.getElementById('studentLoginUsername').value=u;d.getElementById('studentLoginId').value=id;d.getElementById('studentLoginPassword').value='x';
  d.getElementById('studentLoginForm').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));}

(async()=>{
// 1 service details + booking
let dom=build('service-details.html','?office=registrar');await ready(dom);const w=dom.window,d=w.document;
a(d.querySelectorAll('.service-item').length>0,'service items render');
a(d.querySelector('[data-book]')!==null,'book button exists');
d.querySelector('[data-queue]').click();
a(d.getElementById('studentLoginModal') && !d.getElementById('studentLoginModal').hidden,'queue requires login');
login(dom,'Juan Dela Cruz','2026-00123');
a(w.isStudentLoggedIn(),'login ok');
d.querySelector('[data-book]').click();
a(!d.getElementById('bookingModal').hidden,'booking modal opens after login');
a(d.getElementById('bookingStudentId').value==='2026-00123','student id prefilled read-only');
a(d.getElementById('bookingStudentId').readOnly,'id read-only');
const di=d.getElementById('bookingDate');const nd=new Date(Date.now()+9*86400000);while(nd.getDay()===0||nd.getDay()===6)nd.setDate(nd.getDate()+1);
di.value=nd.toISOString().slice(0,10);di.dispatchEvent(new w.Event('change',{bubbles:true}));
const slots=d.querySelectorAll('.slot-btn');
a(slots.length>0,'slots render ('+slots.length+')');
slots[slots.length-1].click();
d.getElementById('bookingCourse').value='BSIT 3A';
d.getElementById('bookingPurpose').value='Request documents';
d.getElementById('bookingRequirements').checked=true;
d.getElementById('bookingForm').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
const conf=d.getElementById('conflictModal');
if(conf && !conf.hidden){d.getElementById('conflictBookAnyway').click();}
if(d.getElementById('confirmationModal').hidden){console.log('  DEBUG slotErr:',d.getElementById('bookingSlotError').textContent,'| formErr:',d.getElementById('bookingFormError').textContent,'| courseErr:',d.getElementById('bookingCourseError').textContent,'| purpose:',d.getElementById('bookingPurposeError').textContent,'| date:',d.getElementById('bookingDateError').textContent);}
a(!d.getElementById('confirmationModal').hidden,'confirmation shows');
const ref=d.getElementById('confirmationReference').textContent;
a(/^APT-\d{4}-\d{4}$/.test(ref),'reference format '+ref);
a(JSON.parse(w.localStorage.getItem('ccsjdm_appointments')).some(x=>x.reference===ref),'appointment persisted');
a(w.__errs.length===0,'no jsdom errors on service-details: '+w.__errs.join('|'));
const store=w.localStorage;

// 2 my schedule
let d2=build('my-events.html');await ready(d2);
const w2=d2.window,dd=d2.window.document;
login(d2,'Juan Dela Cruz','2026-00123');
a(dd.getElementById('myEventsMain').hidden===false,'schedule visible after login');
a(Number(dd.getElementById('apptCount').textContent)>=2,'appointments tab count '+dd.getElementById('apptCount').textContent);
a(dd.getElementById('myQueueList').textContent.includes('R-'),'queue ticket listed');
a(dd.getElementById('nextItemCard').textContent.length>10,'next item card populated');
a(dd.querySelectorAll('.calendar-cell').length===42,'month calendar 42 cells');
dd.querySelector('[data-calview="week"]').click();
a(dd.querySelectorAll('.calendar-cell').length===7,'week view 7 cells');
dd.querySelector('[data-reschedule]')&&dd.querySelector('[data-reschedule]').click();
a(!dd.getElementById('rescheduleModal').hidden,'reschedule modal opens');
const rs=dd.querySelectorAll('#rescheduleSlotGrid .slot-btn');
if(rs.length){rs[0].click();dd.getElementById('confirmRescheduleBtn').click();}
a(dd.getElementById('rescheduleModal').hidden,'reschedule confirmed');
dd.querySelectorAll('.tab-btn')[4].click();
a(dd.getElementById('historyTab').classList.contains('active'),'history tab switches');
const fb=dd.querySelector('[data-feedback]');
a(dd.getElementById('historyList').textContent.includes('You rated this visit'),'seeded feedback shown in history');
if(fb){fb.click();dd.querySelectorAll('.star-btn')[4].click();dd.getElementById('submitFeedbackBtn').click();
a(JSON.parse(w2.localStorage.getItem('ccsjdm_feedback')).length>=4,'feedback saved');}
a(dd.getElementById('notificationBellBtn')!==null,'notification bell present');
dd.getElementById('notificationBellBtn').click();
a(!dd.getElementById('notificationDropdown').hidden,'bell dropdown opens');
a(w2.__errs.length===0,'no jsdom errors on my-events: '+w2.__errs.join('|'));

// 3 host
let d3=build('officer.html');await ready(d3);const w3=d3.window,d3d=w3.document;
w3.innerWidth=1400;
d3d.getElementById('openLoginModalBtn').click();
d3d.getElementById('loginPassword').value = 'demo';d3d.getElementById('loginOrganizerId').value='fac-001';
d3d.getElementById('loginForm').dispatchEvent(new w3.Event('submit',{bubbles:true,cancelable:true}));
a(d3d.getElementById('officerMain').hidden===false,'host dashboard visible');
a(d3d.getElementById('hostOfficeSelect').options.length===6,'6 offices in picker');
a(d3d.getElementById('hostAppointmentsBody').children.length>0,'appointments table rows');
d3d.querySelector('[data-hosttab="queue"]').click();
a(d3d.getElementById('queueHostTab').classList.contains('active'),'queue tab active');
a(d3d.getElementById('callNextBtn')!==null,'call next button');
d3d.getElementById('callNextBtn').click();
a(d3d.getElementById('queueConsole').textContent.includes('R-'),'queue console shows codes');
d3d.querySelector('[data-hosttab="officecheckin"]').click();
d3d.getElementById('officeCheckinInput').value='NOPE';d3d.getElementById('officeCheckinBtn').click();
a(d3d.getElementById('officeCheckinResult').className.includes('error'),'bad check-in shows error');
d3d.querySelector('[data-hosttab="reports"]').click();
a(d3d.getElementById('reportTableBody').children.length>0,'report rows');
a(d3d.querySelectorAll('#reportChart .bar').length>0,'chart bars');
d3d.querySelector('[data-hosttab="feedback"]').click();
a(d3d.getElementById('feedbackSummary').textContent.length>0||d3d.getElementById('hostFeedbackList').textContent.length>0,'feedback tab content');
a(d3d.getElementById('resetDemoDataBtn')!==null,'reset demo data button');
a(w3.__errs.length===0,'no jsdom errors on officer: '+w3.__errs.join('|'));

// 4 theme + home
let d4=build('index.html');await ready(d4);const w4=d4.window,d4d=w4.document;
a(d4d.getElementById('themeToggleBtn')!==null,'theme toggle exists');
d4d.getElementById('themeToggleBtn').click();
a(d4d.documentElement.getAttribute('data-theme')==='dark','dark mode toggles');
d4d.getElementById('themeToggleBtn').click();
a(d4d.documentElement.getAttribute('data-theme')==='contrast','high contrast toggles');
a(d4d.querySelectorAll('#homeOfficeGrid .office-card').length===3,'home office cards');
a(Number(d4d.getElementById('homeSlotsToday').textContent)>=0,'slots today stat');
a(d4d.querySelector('.skip-link')!==null,'skip link');
a(w4.__errs.length===0,'no jsdom errors on index: '+w4.__errs.join('|'));
console.log('SMOKE: '+pass+' passed, '+fail+' failed');process.exit(0);
})();
