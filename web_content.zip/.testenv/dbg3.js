const fs=require('fs'),path=require('path'),{JSDOM,VirtualConsole}=require('jsdom');
const P='/home/user/project';
let html=fs.readFileSync(path.join(P,'service-details.html'),'utf8');
html=html.replace('<script src="app.js"></script>','<script>'+fs.readFileSync(path.join(P,'app.js'),'utf8')+'</script>');
html=html.replace('<script src="services.js"></script>','<script>try{'+fs.readFileSync(path.join(P,'services.js'),'utf8')+'}catch(e){document.title="ERR:"+e.message}</script>');
const vc=new VirtualConsole();
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://x.test/service-details.html?office=registrar',virtualConsole:vc});
console.log(dom.window.document.title);
process.exit(0);
