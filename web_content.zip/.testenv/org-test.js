const fs=require('fs'),path=require('path'),{JSDOM,VirtualConsole}=require('jsdom');
const P='/home/user/project';
function build(page,pre){
  let html=fs.readFileSync(path.join(P,page),'utf8');
  html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+fs.readFileSync(path.join(P,'style.css'),'utf8')+'</style>');
  html=html.replace('<script src="app.js"></script>','<script>'+fs.readFileSync(path.join(P,'app.js'),'utf8')+'</script>');
  html=html.replace('<script src="services.js"></script>','<script>'+fs.readFileSync(path.join(P,'services.js'),'utf8')+'</script>');
  const vc=new VirtualConsole();const errs=[];vc.on('jsdomError',e=>errs.push(e.message));
  const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://x.test/'+page,virtualConsole:vc,pretendToBeVisual:true,
    beforeParse(win){ if(pre) for(const k of Object.keys(pre)) win.localStorage.setItem(k,pre[k]); }});
  dom.window.__errs=errs;return dom;}
const ready=dom=>new Promise(r=>{dom.window.document.addEventListener('DOMContentLoaded',()=>setTimeout(r,0));setTimeout(r,400);});
let pass=0,fail=0;const a=(c,m)=>{c?pass++:(fail++,console.log('  FAIL: '+m));};
const submit=(w,el)=>el.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
(async()=>{
 let dom=build('index.html');await ready(dom);let w=dom.window,d=w.document;
 d.getElementById('navLoginBtn').click();
 const labels=[...d.querySelectorAll('#authChoiceModal .auth-choice-label')].map(x=>x.textContent);
 a(labels.join('|')==='Student Login|Professor Login|Event Organizer Login','chooser order: '+labels.join('|'));
 d.getElementById('chooseHostLogin').click();
 a(d.getElementById('loginModal').querySelector('h2').textContent==='Event Organizer Login','organizer modal title');
 a(d.getElementById('loginPassword')!==null && d.getElementById('loginPassword').type==='password','organizer modal has a password field');
 a(d.getElementById('loginOrganizerId')!==null && d.querySelector('label[for=loginOrganizerId]').textContent==='Faculty or Staff ID','organizer modal asks for faculty or staff ID');
 a(d.getElementById('loginModal').textContent.indexOf('Host')===-1,'no "Host" wording in organizer modal');
 w.document.getElementById('loginPassword').value = 'demo';
 submit(w,d.getElementById('loginForm'));
 a(!d.getElementById('loginError').hidden,'empty organizer fields rejected');
 d.getElementById('loginPassword').value = 'demo';d.getElementById('loginOrganizerId').value='2026-00123';
 submit(w,d.getElementById('loginForm'));
 a(!w.isHostLoggedIn(),'student ID number refused at the organizer login');
 a(d.getElementById('loginError').textContent.includes('Student ID numbers'),'student ID refusal message');
 d.getElementById('loginOrganizerId').value='STF-001';
 submit(w,d.getElementById('loginForm'));
 a(w.isHostLoggedIn(),'staff ID accepted');
 a(w.getHostSession().organizationName==='Office of the Dean','staff account name stored');
 a(d.querySelector('.brand-title').textContent==='Appointments and schedule','brand text singular');
 a(d.title==='Appointments and schedule','title singular: '+d.title);
 a(w.localStorage.getItem('ccsjdm_host_session').includes('STF-001'),'staff account stored with the session');
 dom.window.close();

 dom=build('officer.html');await ready(dom);w=dom.window;d=w.document;
 d.getElementById('openLoginModalBtn').click();
 d.getElementById('loginPassword').value = 'demo';d.getElementById('loginOrganizerId').value='fac-002';
 submit(w,d.getElementById('loginForm'));
 a(d.getElementById('navAuthArea').textContent.includes('Event Dashboard'),'nav shows Event Dashboard after login');
 a(!d.getElementById('navAuthArea').textContent.includes('Host Dashboard'),'no Host Dashboard label');
 dom.window.close();

 const session=JSON.stringify({username:'Dr. Celine',organizationId:'ORG-003',organizationName:'Office of the Dean',loginTime:'2026-10-10T01:00:00.000Z'});
 dom=build('events.html',{ccsjdm_host_session:session,ccsjdm_greeting_shown:'2026-10-10T01:00:00.000Z'});await ready(dom);w=dom.window;d=w.document;
 a(d.getElementById('userGreeting').hidden,'greeting hidden on the next page after it was shown once');
 a(d.getElementById('userGreeting').textContent.trim()==='','greeting empty on later pages');
 a(d.getElementById('navAuthArea').textContent.includes('Event Dashboard'),'nav persists on later pages');
 dom.window.close();

 dom=build('officer.html',{ccsjdm_host_session:session});await ready(dom);w=dom.window;d=w.document;
 a(d.querySelector('.dashboard-header h2').textContent.trim()==='Event Dashboard','dashboard heading renamed');
 a(d.title.indexOf('Event Dashboard')===0,'dashboard title renamed');
 const gateText=d.getElementById('hostGateMessage');
 a(gateText!==null,'gate message element still present');
 dom.window.close();

 dom=build('officer.html');await ready(dom);w=dom.window;d=w.document;
 a(d.getElementById('hostGateMessage').textContent==='You need to be a host to access this. Please log in.','logged-out gate text exact');
 dom.window.close();

 dom=build('events.html',{ccsjdm_host_session:session});await ready(dom);w=dom.window;d=w.document;
 const logo=d.querySelector('.logo-container');
 a(logo.tagName==='DIV','logo block is no longer a link');
 a(d.querySelector('.logo-link').getAttribute('href')==='https://ccsjdm.com','only the logo links to ccsjdm.com');
 a(d.querySelector('.brand-title').closest('a')===null,'brand text is not a link');
 a(w.__errs.length===0,'no jsdom errors');
 dom.window.close();

 dom=build('index.html');await ready(dom);w=dom.window;d=w.document;
 d.getElementById('navLoginBtn').click();d.getElementById('chooseStudentLogin').click();
 d.getElementById('studentLoginUsername').value='Juan';d.getElementById('studentLoginId').value='2026-00123';d.getElementById('studentLoginPassword').value='x';
 submit(w,d.getElementById('studentLoginForm'));
 a(d.getElementById('userGreeting').textContent.includes('Signed in as Student'),'student greeting after login');
 const sGreet=d.getElementById('userGreeting').hidden;
 const greetFirst=d.getElementById('userGreeting').textContent;
 a(greetFirst.includes('Welcome back, Juan'),'student greeting names the student');
 a(sGreet===false,'student greeting shown once after login');
 dom.window.close();
 console.log('ORG: '+pass+' passed, '+fail+' failed');process.exit(0);
})();
