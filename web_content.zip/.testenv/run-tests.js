const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const PROJECT = '/home/user/project';
let passed = 0;
let failed = 0;

function assert(condition, label) {
    if (condition) {
        passed++;
        console.log('  PASS: ' + label);
    } else {
        failed++;
        console.log('  FAIL: ' + label);
    }
}

async function runPage(file, query, seedStorage) {
    const appJs = fs.readFileSync(path.join(PROJECT, 'app.js'), 'utf8');
    const servicesJs = fs.readFileSync(path.join(PROJECT, 'services.js'), 'utf8');
    let html = fs.readFileSync(path.join(PROJECT, file), 'utf8');
    const screenScript = global.__screenWidth
        ? '<script>Object.defineProperty(window, "innerWidth", { value: ' + global.__screenWidth + ', configurable: true });'
          + 'Object.defineProperty(document.documentElement, "clientWidth", { value: ' + global.__screenWidth + ', configurable: true });<\/script>'
        : '';
    const seedScript = seedStorage
        ? '<script>Object.entries(' + JSON.stringify(seedStorage) + ').forEach(([k, v]) => localStorage.setItem(k, v));</script>'
        : '';
    const css = fs.readFileSync(path.join(PROJECT, 'style.css'), 'utf8');
    html = html.replace('<link rel="stylesheet" href="style.css">', '<style>' + css + '</style>');
    html = html.replace('<script src="services.js"></script>', '<script>' + servicesJs + '</script>');
    html = html.replace('<script src="app.js"></script>', screenScript + seedScript + '<script>' + appJs + '</script>');
    const dom = new JSDOM(html, {
        runScripts: 'dangerously',
        pretendToBeVisual: true,
        url: 'http://localhost:8000/' + file + (query || '')
    });
    await new Promise(resolve => dom.window.addEventListener('load', resolve));
    await new Promise(resolve => setTimeout(resolve, 60));
    return dom;
}

function storageSnapshot(dom) {
    const out = {};
    for (let i = 0; i < dom.window.localStorage.length; i++) {
        const key = dom.window.localStorage.key(i);
        out[key] = dom.window.localStorage.getItem(key);
    }
    return out;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

function loginStudent(dom, username, id, password) {
    const doc = dom.window.document;
    doc.getElementById('navLoginBtn').click();
    doc.getElementById('chooseStudentLogin').click();
    doc.getElementById('studentLoginUsername').value = username;
    doc.getElementById('studentLoginId').value = id;
    doc.getElementById('studentLoginPassword').value = password;
    doc.getElementById('studentLoginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
}


(async function main() {
    console.log('TEST 1: Events directory (student flow, no login needed)');
    {
        const dom = await runPage('events.html');
        const doc = dom.window.document;
        assert(doc.querySelectorAll('.event-card').length === 4, 'renders 4 upcoming event cards');
        assert(doc.getElementById('navLoginBtn') !== null, 'navbar shows a Log In button');
        assert(doc.getElementById('officerMain') === null, 'no dashboard content on events page');
        const orgOptions = doc.querySelectorAll('#orgFilter option').length;
        assert(orgOptions === 4, 'organization dropdown populated dynamically (All + 3 organizers), got ' + orgOptions);
        const eventDates = ['2026-10-10', '2026-10-15', '2026-10-22', '2026-10-29'];
        const daysAway = iso => {
            const p = iso.split('-').map(Number);
            const target = new Date(p[0], p[1] - 1, p[2]);
            const now = new Date();
            return Math.ceil((target - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
        };
        const expectThisWeek = eventDates.filter(d => daysAway(d) >= 0 && daysAway(d) <= 7).length;
        const expectNextWeek = eventDates.filter(d => daysAway(d) >= 8 && daysAway(d) <= 14).length;

        doc.getElementById('dateFilter').value = 'next-week';
        doc.getElementById('dateFilter').dispatchEvent(new dom.window.Event('change'));
        assert(doc.querySelectorAll('.event-card').length === expectNextWeek, 'date filter "Next Two Weeks" matches the real calendar (' + expectNextWeek + ')');
        doc.getElementById('dateFilter').value = 'this-week';
        doc.getElementById('dateFilter').dispatchEvent(new dom.window.Event('change'));
        assert(doc.querySelectorAll('.event-card').length === expectThisWeek, 'date filter "This Week" matches the real calendar (' + expectThisWeek + ')');
        doc.getElementById('dateFilter').value = 'all';
        doc.getElementById('dateFilter').dispatchEvent(new dom.window.Event('change'));
        doc.getElementById('searchInput').value = 'cultural';
        doc.getElementById('searchInput').dispatchEvent(new dom.window.Event('input'));
        assert(doc.querySelectorAll('.event-card').length === 1, 'search filter works');
        dom.window.close();
    }

    console.log('TEST 2: Event details - register button opens FORM, validation, success modal stays open');
    {
        const dom = await runPage('event-details.html', '?id=3');
        const doc = dom.window.document;
        loginStudent(dom, 'Pedro Reyes', '2026-00777', 'demo123');
        const regBtn = doc.getElementById('confirmRegisterBtn');
        assert(regBtn !== null, 'Register Now button exists (no login required for students)');
        assert(doc.getElementById('registerModal').hidden === true, 'registration form modal initially closed');
        regBtn.click();
        assert(doc.getElementById('registerModal').hidden === false, 'register button OPENS the registration form');
        assert(doc.getElementById('regName').value.length > 0, 'form prefilled from stored student profile (convenience)');

        doc.getElementById('regName').value = '';
        doc.getElementById('regStudentId').value = '';
        doc.getElementById('regCourse').value = '';
        doc.getElementById('registerForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('regNameError').hidden === false, 'cleared form blocked with field errors');
        assert(doc.getElementById('successModal').hidden === true, 'no registration created without valid submission');
        assert(JSON.parse(dom.window.localStorage.getItem('ccsjdm_registrations')).filter(r => r.eventId === 3 && r.studentId === '2026-00123').length === 0, 'no registration stored for invalid submission');

        doc.getElementById('regName').value = 'Pedro Reyes';
        doc.getElementById('regStudentId').readOnly = false;
        doc.getElementById('regStudentId').value = 'BAD-ID';
        doc.getElementById('regCourse').value = 'BSCS 2B';
        doc.getElementById('registerForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('regStudentIdError').hidden === false, 'invalid Student ID format rejected');
        assert(doc.getElementById('successModal').hidden === true, 'registration NOT complete until form valid');

        doc.getElementById('regStudentId').value = '2026-00777';
        doc.getElementById('registerForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        const stored = JSON.parse(dom.window.localStorage.getItem('ccsjdm_registrations'));
        const pedro = stored.find(r => r.studentId === '2026-00777');
        assert(pedro !== undefined, 'valid submission creates the registration');
        assert(pedro && pedro.eventCode === '2026-00777', 'pass code is the student ID: ' + (pedro ? pedro.eventCode : 'none'));
        assert(doc.getElementById('successModal').hidden === false, 'success modal shown after submission');
        assert(doc.getElementById('registerModal').hidden === true, 'registration form closed after success');

        console.log('  ...waiting 3.5s to prove the confirmation does NOT close automatically');
        await sleep(3500);
        assert(doc.getElementById('successModal').hidden === false, 'success modal STILL OPEN after 3.5s (no auto-close)');

        doc.getElementById('closeModalBtn').click();
        assert(doc.getElementById('successModal').hidden === true, 'student closes it manually');
        assert(doc.getElementById('confirmRegisterBtn') === null && doc.querySelector('.registered-success-box') !== null,
            'page re-renders into registered state after manual close');
        const snapshot = storageSnapshot(dom);
        dom.window.close();
        global.pedroStorage = snapshot;
    }

    console.log('TEST 3: Host dashboard - blocked when NOT logged in');
    {
        const dom = await runPage('officer.html', '', global.pedroStorage);
        const doc = dom.window.document;
        delete global.pedroStorage.ccsjdm_host_session;
        assert(doc.getElementById('officerMain').hidden === true, 'dashboard content HIDDEN for unauthenticated visitor');
        assert(doc.getElementById('hostLoginGate').hidden === false, 'login gate shown instead (blocked)');
        assert(doc.getElementById('desktopOnlyNotice') !== null, 'desktop-only notice element present (CSS-driven)');

        assert(doc.getElementById('hostGateMessage').textContent.trim() === 'You need to be a host to access this. Please log in.',
            'exact required logged-out message shown');
        assert(doc.getElementById('loginModal').hidden === true, 'login pop-up closed until the Login button is clicked');
        doc.getElementById('openLoginModalBtn').click();
        assert(doc.getElementById('loginModal').hidden === false, 'Login button opens the pop-up window');

        doc.getElementById('loginPassword').value = 'demo';
        doc.getElementById('loginOrganizerId').value = 'fac-999';
        doc.getElementById('loginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('loginError').hidden === false, 'unknown organization ID rejected with error message');
        assert(doc.getElementById('officerMain').hidden === true, 'dashboard STILL hidden after failed login');
        assert(dom.window.localStorage.getItem('ccsjdm_host_session') === null, 'no session created for wrong credentials');

        doc.getElementById('loginPassword').value = 'demo';
        doc.getElementById('loginOrganizerId').value = 'STF-404';
        doc.getElementById('loginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('officerMain').hidden === true, 'unlisted organization ID is refused');

        doc.getElementById('loginPassword').value = 'demo';
        doc.getElementById('loginOrganizerId').value = 'fac-001';
        doc.getElementById('loginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('officerMain').hidden === false, 'organization ID ORG-001 grants dashboard access without a password');
        assert(doc.getElementById('loginModal').hidden === true, 'pop-up closes after successful login');
        assert(doc.getElementById('hostLoginGate').hidden === true, 'login gate hidden after login');
        assert(doc.querySelectorAll('#registrantsTableBody tr').length >= 3, 'registrants table includes Pedro (got ' + doc.querySelectorAll('#registrantsTableBody tr').length + ' rows)');
        const pedroRow = [...doc.querySelectorAll('#registrantsTableBody tr')].some(tr => tr.textContent.includes('Pedro Reyes'));
        assert(pedroRow, 'newly registered student visible to host');

        doc.getElementById('officerSearchInput').value = 'cultural';
        doc.getElementById('officerSearchInput').dispatchEvent(new dom.window.Event('input'));
        assert(doc.querySelectorAll('#officerEventsTableBody tr').length === 1, 'officer event search works (was dead code before)');
        doc.getElementById('officerSearchInput').value = '';
        doc.getElementById('officerSearchInput').dispatchEvent(new dom.window.Event('input'));

        const sessionSnapshot = storageSnapshot(dom);
        doc.getElementById('logoutBtn').click();
        assert(doc.getElementById('officerMain').hidden === true, 'logout hides dashboard again');
        assert(doc.getElementById('hostLoginGate').hidden === false, 'logout returns to login gate');
        dom.window.close();
        global.loggedInStorage = sessionSnapshot;
    }

    console.log('TEST 4: Direct dashboard access WITH valid session');
    {
        const dom = await runPage('officer.html', '', global.loggedInStorage);
        const doc = dom.window.document;
        assert(doc.getElementById('officerMain').hidden === false, 'session persists - dashboard opens directly');
        assert(doc.getElementById('hostUserBadge').textContent.includes('Logged in as'), 'badge shows the logged-in account');
        dom.window.close();
    }

    console.log('TEST 5: My Schedule shows the registered event, cancel works');
    {
        const seed5 = Object.assign({}, global.loggedInStorage, {
            ccsjdm_student_session: JSON.stringify({ username: 'Pedro Reyes', studentId: '2026-00777', loginTime: new Date().toISOString() })
        });
        const dom = await runPage('my-events.html', '', seed5);
        const doc = dom.window.document;
        assert(doc.getElementById('myEventsMain').hidden === false, 'logged-in student sees their schedule');
        assert(doc.getElementById('regCount').textContent === '1', 'profile-based count = 1 (Pedro)');
        assert(doc.getElementById('studentProfileSummary').textContent.includes('Pedro Reyes'), 'profile summary rendered dynamically');
        assert(doc.querySelector('#myRegisteredGrid .event-card') !== null, 'registered event card shown with QR');
        assert(doc.querySelector('#myRegisteredGrid img[src^="data:image/svg+xml"]') !== null, 'QR mock rendered as self-contained data URI');
        dom.window.confirm = () => true;
        doc.querySelector('[data-action="cancel-registration"]').click();
        const after = JSON.parse(dom.window.localStorage.getItem('ccsjdm_registrations'));
        assert(!after.some(r => r.studentId === '2026-00777'), 'cancel removes the registration');
        dom.window.close();
    }

    console.log('TEST 6: Check-in desk - code check-in, duplicate guard, walk-in validation');
    {
        const seed = JSON.parse(JSON.stringify(global.loggedInStorage));
        seed.ccsjdm_host_session = JSON.stringify({ username: 'Adminhost', loginTime: new Date().toISOString() });
        const dom = await runPage('checkin.html', '?event=1', seed);
        const doc = dom.window.document;
        assert(doc.getElementById('checkinMain').hidden === false, 'host session unlocks the check-in desk');
        assert(doc.getElementById('checkinEventSelect').value === '1', 'event preselected via URL param');

        doc.getElementById('eventCodeInput').value = '2026-00123';
        doc.getElementById('codeCheckinForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        let regs = JSON.parse(dom.window.localStorage.getItem('ccsjdm_registrations'));
        assert(regs.find(r => r.eventCode === '2026-00123').attendanceStatus === 'Attended', 'valid student ID checks the student in');
        assert(doc.getElementById('statAttended').textContent === '1', 'live stats updated');
        assert(doc.getElementById('checkinFeedbackBox').hidden === false, 'feedback box shown');

        doc.getElementById('eventCodeInput').value = '2026-00123';
        doc.getElementById('codeCheckinForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('checkinFeedbackBox').classList.contains('warning'), 'duplicate check-in shows warning state');

        doc.getElementById('eventCodeInput').value = '2025-00456';
        doc.getElementById('codeCheckinForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('checkinFeedbackBox').classList.contains('warning'), 'code from another event rejected for selected event');

        doc.getElementById('openWalkinModalBtn').click();
        assert(doc.getElementById('walkinModal').hidden === false, 'walk-in modal opens');
        doc.getElementById('walkinName').value = 'Ana Cruz';
        doc.getElementById('walkinId').value = 'nope';
        doc.getElementById('walkinCourse').value = 'BSIT 1A';
        doc.getElementById('walkinForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('walkinFormError').hidden === false, 'walk-in with invalid Student ID blocked');
        doc.getElementById('walkinId').value = '2026-00888';
        doc.getElementById('walkinForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        regs = JSON.parse(dom.window.localStorage.getItem('ccsjdm_registrations'));
        const ana = regs.find(r => r.studentId === '2026-00888');
        assert(ana !== undefined && ana.attendanceStatus === 'Attended', 'valid walk-in added and checked in');
        assert(doc.getElementById('walkinModal').hidden === true, 'walk-in modal closes after success');
        dom.window.close();
    }

    console.log('TEST 7: Navbar Log In button and the two-choice pop-up');
    {
        for (const page of ['index.html', 'events.html', 'my-events.html']) {
            const dom = await runPage(page);
            const doc = dom.window.document;
            assert(doc.getElementById('navLoginBtn') !== null, page + ': Log In button in the top-right');
            assert(doc.querySelector('#navLinks a.nav-link-host') === null, page + ': Host Dashboard link replaced by Log In');
            doc.getElementById('navLoginBtn').click();
            const choice = doc.getElementById('authChoiceModal');
            assert(choice.hidden === false, page + ': pop-up opens');
            assert(dom.window.getComputedStyle(choice).backdropFilter.includes('blur'), page + ': background is blurred');
            assert(doc.getElementById('chooseStudentLogin') !== null && doc.getElementById('chooseHostLogin') !== null,
                page + ': pop-up offers Student and Host login');
            dom.window.close();
        }
    }

    console.log('TEST 8: Public pages remain fully usable with no login');
    {
        const dom = await runPage('events.html');
        const doc = dom.window.document;
        assert(doc.querySelectorAll('.event-card').length === 4, 'event directory public');
        dom.window.close();
        const det = await runPage('event-details.html', '?id=4');
        assert(det.window.document.getElementById('confirmRegisterBtn') !== null, 'event details viewable without logging in');
        assert(det.window.document.querySelector('.event-title').textContent.length > 0, 'event info public');
        det.window.close();
    }

    console.log('TEST 9: Log In control and branding on every page');
    {
        for (const page of ['index.html', 'events.html', 'event-details.html', 'my-events.html']) {
            const dom = await runPage(page, page === 'event-details.html' ? '?id=1' : '');
            const doc = dom.window.document;
            assert(doc.getElementById('navLoginBtn') !== null, page + ': navbar has the Log In button');
            const footerLink = [...doc.querySelectorAll('footer a')].some(a => a.getAttribute('href') === 'officer.html');
            assert(footerLink === false, page + ': footer no longer has a Host Dashboard link');
            const checkinLink = [...doc.querySelectorAll('#navLinks a')].some(a => (a.getAttribute('href') || '').includes('checkin'));
            assert(checkinLink === false, page + ': Check-in Desk is NOT in the public navbar');
            const logo = doc.querySelector('a.logo-link');
            assert(logo !== null && logo.getAttribute('href') === 'https://ccsjdm.com', page + ': logo links to ccsjdm.com');
            assert(doc.querySelector('a.logo-link img.logo') !== null, page + ': logo uses the college seal image');
            assert(doc.querySelector('.brand-title') && doc.querySelector('.brand-title').closest('a') === null, page + ': brand text is not a link');
            dom.window.close();
        }
    }

    console.log('TEST 10: Burger menu opens and exposes the Log In control');
    {
        const dom = await runPage('events.html');
        const doc = dom.window.document;
        const toggle = doc.getElementById('navToggle');
        const links = doc.getElementById('navLinks');
        assert(toggle !== null, 'burger button exists in the header');
        assert(links.classList.contains('show') === false, 'menu starts closed');
        toggle.click();
        assert(links.classList.contains('show') === true, 'burger click opens the menu');
        assert(toggle.getAttribute('aria-expanded') === 'true', 'aria-expanded reflects open state');
        assert(links.querySelector('#navAuthArea') !== null, 'login control is inside the burger menu');
        assert(links.querySelector('#navLoginBtn') !== null, 'Log In button reachable from the burger menu');
        toggle.click();
        assert(links.classList.contains('show') === false, 'burger click closes the menu');
        dom.window.close();
    }

    console.log('TEST 11: Desktop gate (>= 1024px wide viewport, so tablet desktop mode works)');
    {
        global.__screenWidth = 1920;
        const dom = await runPage('officer.html');
        const doc = dom.window.document;
        assert(doc.documentElement.classList.contains('device-blocked') === false, '1920px viewport is not blocked');
        assert(doc.getElementById('hostLoginGate').hidden === false, 'login gate reachable on desktop');
        assert(doc.getElementById('desktopOnlyNotice').hidden === true, 'desktop notice hidden on desktop');
        dom.window.close();

        global.__screenWidth = 390;
        const phone = await runPage('officer.html');
        const pdoc = phone.window.document;
        assert(pdoc.documentElement.classList.contains('device-blocked') === true, '390px viewport flagged as blocked');
        assert(pdoc.getElementById('desktopOnlyNotice').hidden === false, 'phone sees the Desktop Access Only notice');
        assert(pdoc.getElementById('hostLoginGate').hidden === true, 'phone cannot see the login gate');
        assert(pdoc.getElementById('officerMain').hidden === true, 'phone cannot see the dashboard');
        pdoc.getElementById('openLoginModalBtn').click();
        assert(pdoc.getElementById('loginModal').hidden === true, 'login pop-up refuses to open on a phone');
        phone.window.close();

        global.__screenWidth = 390;
        const forced = await runPage('officer.html');
        const fdoc = forced.window.document;
        fdoc.documentElement.classList.remove('device-blocked');
        fdoc.getElementById('loginPassword').value = 'demo';
        fdoc.getElementById('loginOrganizerId').value = 'fac-001';
        fdoc.getElementById('loginForm').dispatchEvent(new forced.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(fdoc.getElementById('officerMain').hidden === true, 'JS still blocks login if the CSS class is tampered with');
        assert(forced.window.localStorage.getItem('ccsjdm_host_session') === null, 'no session granted on a blocked device');
        forced.window.close();
        global.__screenWidth = null;
    }

    console.log('TEST 12: Home page is a real introduction, not a copy of Events');
    {
        const dom = await runPage('index.html');
        const doc = dom.window.document;
        assert(doc.getElementById('eventsGrid') === null, 'home has no full event directory');
        assert(doc.getElementById('searchInput') === null, 'home has no search/filter bar');
        assert(doc.querySelector('.hero h1') !== null, 'home has an introduction hero');
        assert(doc.querySelectorAll('#homeOfficeGrid .office-card').length === 3, 'home leads with offices and services');
        assert(doc.querySelectorAll('.steps-list li').length === 4, 'home explains how it works');
        assert(parseInt(doc.getElementById('homeEventCount').textContent, 10) === 4, 'home shows live upcoming event count');
        assert(parseInt(doc.getElementById('homeInQueue').textContent, 10) >= 0, 'home shows people in queue');
        assert(doc.querySelector('.hero-actions .btn-primary').getAttribute('href') === 'services.html', 'hero primary action books an appointment');
        assert(doc.querySelectorAll('#featuredEventsGrid .event-card').length === 3, 'home shows 3 featured events');
        const wordmark = doc.querySelector('.hero-brand img');
        assert(wordmark !== null && wordmark.getAttribute('src').includes('wordmark'), 'wordmark logo placed in the hero');
        assert(doc.querySelector('.info-split-seal img') !== null, 'college seal also featured on the home page');
        dom.window.close();

        const ev = await runPage('events.html');
        assert(ev.window.document.getElementById('eventsGrid') !== null, 'events page holds the directory');
        assert(ev.window.document.getElementById('searchInput') !== null, 'events page holds the search/filters');
        ev.window.close();
    }

    console.log('TEST 13: Check-in Desk is host-only (students cannot self-mark attendance)');
    {
        const dom = await runPage('checkin.html');
        const doc = dom.window.document;
        assert(doc.getElementById('checkinMain').hidden === true, 'check-in tools hidden from the public');
        assert(doc.getElementById('hostLoginGate').hidden === false, 'check-in shows the host login gate');
        assert(doc.getElementById('hostGateMessage').textContent.includes('You need to be a host'), 'correct gate message');
        assert(doc.getElementById('codeCheckinForm') !== null, 'check-in form exists but is gated');

        doc.getElementById('openLoginModalBtn').click();
        doc.getElementById('loginPassword').value = 'demo';
        doc.getElementById('loginOrganizerId').value = 'fac-001';
        doc.getElementById('loginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('checkinMain').hidden === false, 'host login unlocks the check-in desk');
        assert(doc.getElementById('checkinEventSelect').options.length === 4, 'event list loads after login');
        doc.getElementById('logoutBtn').click();
        assert(doc.getElementById('checkinMain').hidden === true, 'logout re-locks the check-in desk');
        dom.window.close();

        global.__screenWidth = 390;
        const phone = await runPage('checkin.html');
        assert(phone.window.document.getElementById('checkinMain').hidden === true, 'check-in blocked on small screens too');
        assert(phone.window.document.getElementById('desktopOnlyNotice').hidden === false, 'check-in shows desktop-only notice');
        phone.window.close();
        global.__screenWidth = null;
    }

    console.log('TEST 14: Student ID is the pass code (no random codes)');
    {
        const dom = await runPage('event-details.html', '?id=4');
        const doc = dom.window.document;
        doc.getElementById('confirmRegisterBtn').click();
        doc.getElementById('regName').value = 'Liza Santos';
        doc.getElementById('regStudentId').value = '2026-00321';
        doc.getElementById('regCourse').value = 'BSIT 2A';
        doc.getElementById('registerForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        const reg = JSON.parse(dom.window.localStorage.getItem('ccsjdm_registrations')).find(r => r.studentId === '2026-00321');
        assert(reg.eventCode === '2026-00321', 'pass code equals the student ID, got ' + reg.eventCode);
        assert(doc.getElementById('assignedEventCode').textContent === '2026-00321', 'confirmation shows the student ID');
        assert(/^\d{4}-\d{5}$/.test(reg.eventCode), 'no random letter code generated');
        const snap = storageSnapshot(dom);
        dom.window.close();

        global.__screenWidth = 1920;
        const desk = await runPage('checkin.html', '?event=4', Object.assign(snap, { ccsjdm_host_session: JSON.stringify({ username: 'Adminhost', loginTime: new Date().toISOString() }) }));
        const ddoc = desk.window.document;
        assert(ddoc.getElementById('checkinMain').hidden === false, 'host session unlocks desk');
        ddoc.getElementById('eventCodeInput').value = '2026-00321';
        ddoc.getElementById('codeCheckinForm').dispatchEvent(new desk.window.Event('submit', { bubbles: true, cancelable: true }));
        const after = JSON.parse(desk.window.localStorage.getItem('ccsjdm_registrations')).find(r => r.studentId === '2026-00321');
        assert(after.attendanceStatus === 'Attended', 'student checks in using their student ID number');
        desk.window.close();
        global.__screenWidth = null;
    }

    console.log('TEST 15: Hidden elements are ACTUALLY invisible (computed style, not just the property)');
    {
        global.__screenWidth = 1920;
        const dom = await runPage('officer.html', '', {
            ccsjdm_host_session: JSON.stringify({ username: 'Adminhost', loginTime: new Date().toISOString() })
        });
        const doc = dom.window.document;
        const vis = el => dom.window.getComputedStyle(el).display;

        assert(doc.getElementById('officerMain').hidden === false, 'dashboard open for logged-in host');
        assert(vis(doc.getElementById('hostLoginGate')) === 'none', 'login gate is COMPUTED as hidden after login');
        assert(vis(doc.getElementById('loginModal')) === 'none', 'login pop-up is COMPUTED as hidden after login');
        assert(vis(doc.getElementById('desktopOnlyNotice')) === 'none', 'desktop notice computed hidden on desktop');
        dom.window.close();

        const out = await runPage('officer.html');
        const odoc = out.window.document;
        const ovis = el => out.window.getComputedStyle(el).display;
        assert(ovis(odoc.getElementById('hostLoginGate')) !== 'none', 'gate visible when logged out');
        assert(ovis(odoc.getElementById('officerMain')) === 'none', 'dashboard computed hidden when logged out');
        assert(ovis(odoc.getElementById('loginModal')) === 'none', 'pop-up computed hidden until opened');
        odoc.getElementById('openLoginModalBtn').click();
        assert(ovis(odoc.getElementById('loginModal')) !== 'none', 'pop-up computed visible once opened');
        out.window.close();

        const desk = await runPage('checkin.html', '', {
            ccsjdm_host_session: JSON.stringify({ username: 'Adminhost', loginTime: new Date().toISOString() })
        });
        const ddoc = desk.window.document;
        const dvis = el => desk.window.getComputedStyle(el).display;
        assert(dvis(ddoc.getElementById('hostLoginGate')) === 'none', 'check-in gate computed hidden after login');
        assert(dvis(ddoc.getElementById('checkinFeedbackBox')) === 'none', 'feedback box computed hidden before any scan');
        desk.window.close();
        global.__screenWidth = null;
    }

    console.log('TEST 16: Student login (demo: any input works) and greeting');
    {
        const dom = await runPage('index.html');
        const doc = dom.window.document;
        assert(doc.getElementById('userGreeting').hidden === true, 'no greeting before login');

        doc.getElementById('navLoginBtn').click();
        doc.getElementById('chooseStudentLogin').click();
        assert(doc.getElementById('studentLoginModal').hidden === false, 'student login form opens');
        assert(doc.getElementById('studentLoginUsername') !== null, 'asks for Username');
        assert(doc.getElementById('studentLoginId') !== null, 'asks for ID Number');
        assert(doc.getElementById('studentLoginPassword') !== null, 'asks for Password');

        doc.getElementById('studentLoginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('studentLoginUsernameError').hidden === false, 'empty form still shows field errors');
        assert(dom.window.localStorage.getItem('ccsjdm_student_session') === null, 'no session created from an empty form');

        loginStudent(dom, 'Ana Cruz', '2026-01111', 'anything');
        const session = JSON.parse(dom.window.localStorage.getItem('ccsjdm_student_session'));
        assert(session && session.username === 'Ana Cruz', 'any typed credentials are accepted (demo mode)');
        assert(doc.getElementById('studentLoginModal').hidden === true, 'pop-up closes after login');
        assert(dom.window.location.pathname.includes('index.html'), 'student stays on the home page after logging in');
        assert(doc.getElementById('userGreeting').hidden === false, 'greeting appears on the home page');
        assert(doc.getElementById('userGreeting').textContent.includes('Ana Cruz'), 'greeting shows the username');
        assert(doc.getElementById('navAuthArea').textContent.includes('Ana Cruz'), 'navbar shows the logged-in student');
        assert(doc.getElementById('navLoginBtn') === null, 'Log In button replaced once signed in');

        doc.getElementById('navLogoutBtn').click();
        assert(dom.window.localStorage.getItem('ccsjdm_student_session') === null, 'logout clears the student session');
        assert(doc.getElementById('userGreeting').hidden === true, 'greeting disappears after logout');
        assert(doc.getElementById('navLoginBtn') !== null, 'Log In button returns');
        dom.window.close();
    }

    console.log('TEST 17: Greeting also shows on the Events page');
    {
        const dom = await runPage('events.html');
        loginStudent(dom, 'Mark Lim', '2026-02222', 'pw');
        const doc = dom.window.document;
        assert(doc.getElementById('userGreeting').hidden === false, 'greeting shown on events page');
        assert(doc.getElementById('userGreeting').textContent.includes('Mark Lim'), 'greeting names the student');
        assert(doc.querySelectorAll('.event-card').length === 4, 'directory still renders after login');
        dom.window.close();
    }

    console.log('TEST 18: Privacy - students only ever see their own schedule');
    {
        const dom = await runPage('my-events.html');
        const doc = dom.window.document;
        assert(doc.getElementById('myEventsMain').hidden === true, 'schedule hidden when nobody is logged in');
        assert(doc.getElementById('studentLoginGate').hidden === false, 'login prompt shown instead');
        assert(doc.getElementById('myRegisteredGrid').innerHTML.trim() === '', 'no other student data rendered while logged out');

        loginStudent(dom, 'Juan Dela Cruz', '2026-00123', 'pw');
        assert(doc.getElementById('myEventsMain').hidden === false, 'schedule unlocks after login');
        assert(doc.getElementById('regCount').textContent === '2', 'Juan sees his seeded registrations');
        assert(doc.getElementById('myRegisteredGrid').textContent.includes('Leadership Seminar'), 'Juan sees his own event');
        assert(doc.getElementById('myRegisteredGrid').textContent.includes('Maria') === false, 'Juan cannot see Maria\'s data');
        const snap = storageSnapshot(dom);
        dom.window.close();

        const other = await runPage('my-events.html', '', Object.assign({}, snap, {
            ccsjdm_student_session: JSON.stringify({ username: 'Maria Santos', studentId: '2026-00456', loginTime: new Date().toISOString() })
        }));
        const odoc = other.window.document;
        assert(odoc.getElementById('regCount').textContent === '1', 'Maria sees only her own 1 registration');
        assert(odoc.getElementById('myRegisteredGrid').textContent.includes('Freshmen Orientation'), 'Maria sees her own event');
        assert(odoc.getElementById('myRegisteredGrid').textContent.includes('Leadership Seminar') === false, 'Maria cannot see Juan\'s data');
        other.window.close();
    }

    console.log('TEST 19: Registration requires a student login and auto-fills');
    {
        const dom = await runPage('event-details.html', '?id=4');
        const doc = dom.window.document;
        doc.getElementById('confirmRegisterBtn').click();
        assert(doc.getElementById('registerModal').hidden === true, 'register form does NOT open when logged out');
        assert(doc.getElementById('studentLoginModal').hidden === false, 'student login is prompted instead');

        doc.getElementById('studentLoginUsername').value = 'Rico Dizon';
        doc.getElementById('studentLoginId').value = '2026-03333';
        doc.getElementById('studentLoginPassword').value = 'pw';
        doc.getElementById('studentLoginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('registerModal').hidden === false, 'register form opens automatically after logging in');
        assert(doc.getElementById('regName').value === 'Rico Dizon', 'name auto-filled from the account');
        assert(doc.getElementById('regStudentId').value === '2026-03333', 'ID auto-filled from the account');
        assert(doc.getElementById('regStudentId').readOnly === true, 'ID is locked to the logged-in account');
        dom.window.close();
    }

    console.log('TEST 20: Host login from the pop-up still needs real credentials');
    {
        global.__screenWidth = 1920;
        const dom = await runPage('index.html');
        const doc = dom.window.document;
        doc.getElementById('navLoginBtn').click();
        doc.getElementById('chooseHostLogin').click();
        assert(doc.getElementById('loginModal').hidden === false, 'host login form opens from the pop-up');

        doc.getElementById('loginPassword').value = 'demo';
        doc.getElementById('loginOrganizerId').value = 'fac-999';
        doc.getElementById('loginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(doc.getElementById('loginError').hidden === false, 'host login REJECTS arbitrary input');
        assert(dom.window.localStorage.getItem('ccsjdm_host_session') === null, 'no host session from bad credentials');

        doc.getElementById('loginPassword').value = 'demo';
        doc.getElementById('loginOrganizerId').value = 'fac-001';
        doc.getElementById('loginForm').dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
        assert(dom.window.localStorage.getItem('ccsjdm_host_session') !== null, 'valid organization ID accepted');
        dom.window.close();
        global.__screenWidth = null;
    }

    console.log('TEST 21: Service directory renders offices and faculty');
    {
        const dom = await runPage('services.html');
        const doc = dom.window.document;
        assert(doc.querySelectorAll('#officeGrid .office-card').length === 6, 'all 6 offices listed, got ' + doc.querySelectorAll('#officeGrid .office-card').length);
        const names = doc.getElementById('officeGrid').textContent;
        ['Registrar', 'Clinic', 'Guidance', 'Quality Assurance', 'Student Affairs', 'Faculty'].forEach(function (office) {
            assert(names.includes(office), 'directory includes ' + office);
        });
        assert(doc.querySelectorAll('#facultyGrid .faculty-card').length === 6, 'all 6 professors listed');
        assert(doc.getElementById('facultyPanel').hidden === true, 'faculty panel hidden until its tab is chosen');

        doc.querySelector('.directory-tab[data-directory="faculty"]').click();
        assert(doc.getElementById('facultyPanel').hidden === false, 'faculty tab switches panel');
        assert(doc.getElementById('officePanel').hidden === true, 'office panel hides');

        assert(doc.getElementById('officeGrid').textContent.includes('Open now') ||
               doc.getElementById('officeGrid').textContent.includes('Closed') ||
               doc.getElementById('officeGrid').textContent.includes('Opens at') ||
               doc.getElementById('officeGrid').textContent.includes('On break'), 'offices show a live open/closed status');
        dom.window.close();
    }

    console.log('TEST 22: Directory search and department filter');
    {
        const dom = await runPage('services.html');
        const doc = dom.window.document;
        const search = doc.getElementById('serviceSearchInput');

        search.value = 'transcript';
        search.dispatchEvent(new dom.window.Event('input'));
        assert(doc.querySelectorAll('#officeGrid .office-card').length === 1, 'searching a SERVICE finds its office');
        assert(doc.getElementById('officeGrid').textContent.includes('Registrar'), 'transcript maps to the Registrar');

        search.value = 'thermodynamics';
        search.dispatchEvent(new dom.window.Event('input'));
        assert(doc.querySelectorAll('#facultyGrid .faculty-card').length === 1, 'searching a SUBJECT finds the professor');
        assert(doc.getElementById('facultyGrid').textContent.includes('Michael Santos'), 'thermodynamics maps to Prof. Santos');

        search.value = 'zzzz-no-such-service';
        search.dispatchEvent(new dom.window.Event('input'));
        assert(doc.querySelector('#officeGrid .empty-state') !== null, 'empty state shown when nothing matches');

        search.value = '';
        search.dispatchEvent(new dom.window.Event('input'));
        const dept = doc.getElementById('departmentFilter');
        assert(dept.options.length === 6, 'department filter populated from the faculty list');
        dept.value = 'College of Computer Studies';
        dept.dispatchEvent(new dom.window.Event('change'));
        assert(doc.querySelectorAll('#facultyGrid .faculty-card').length === 2, 'department filter narrows the list');
        dom.window.close();
    }

    console.log('TEST 23: Queue engine - numbering, position, wait estimate, limits');
    {
        const dom = await runPage('services.html');
        const w = dom.window;
        w.loadServiceData();

        const r1 = w.issueQueueTicket('registrar', 'registrar-enrolment', { id: '2026-00001', name: 'Student One' });
        const r2 = w.issueQueueTicket('registrar', 'registrar-enrolment', { id: '2026-00002', name: 'Student Two' });
        const r3 = w.issueQueueTicket('registrar', 'registrar-enrolment', { id: '2026-00003', name: 'Student Three' });

        const openNow = w.isOfficeOpenNow(w.findOffice('registrar'));
        if (openNow) {
            assert(r1.ok && r1.ticket.code === 'R-001', 'first ticket is R-001, got ' + (r1.ticket && r1.ticket.code));
            assert(r2.ticket.code === 'R-002' && r3.ticket.code === 'R-003', 'queue numbers increment per office');
            assert(w.queuePosition(r3.ticket) === 2, 'third ticket has 2 people ahead');
            assert(w.estimatedWaitMinutes(r3.ticket) === 18, 'wait estimate = position x service time (2 x 9 = 18)');

            const dup = w.issueQueueTicket('registrar', 'registrar-enrolment', { id: '2026-00001', name: 'Student One' });
            assert(dup.ok === false, 'same student cannot take two active numbers at one office');

            const other = w.issueQueueTicket('clinic', 'clinic-consult', { id: '2026-00001', name: 'Student One' });
            assert(other.ok === true && other.ticket.code === 'C-001', 'different office has its own series');

            const served = w.callNextTicket('registrar');
            assert(served.code === 'R-001', 'staff calls the lowest waiting number first');
            assert(w.getQueueState('registrar').nowServing === 1, 'now-serving updates');
            assert(w.queuePosition(r3.ticket) === 1, 'position moves up once someone is served');

            w.callNextTicket('registrar');
            assert(w.queueTickets.find(t => t.code === 'R-001').status === 'Completed', 'previous ticket auto-completes');
        } else {
            assert(r1.ok === false, 'queue correctly refuses tickets outside office hours');
            assert(r1.message.length > 10, 'refusal explains why and offers an alternative');
        }

        const guidance = w.issueQueueTicket('guidance', 'guidance-counseling', { id: '2026-00009', name: 'Student Nine' });
        assert(guidance.ok === false, 'appointment-only office refuses walk-in numbers');
        assert(guidance.message.includes('appointment'), 'and explains that an appointment is needed');
        dom.window.close();
    }

    console.log('TEST 24: Appointment engine - slots, booking, conflicts, cancellation');
    {
        const dom = await runPage('services.html');
        const w = dom.window;
        w.loadServiceData();

        function nextWeekday(targetDays) {
            const d = new Date();
            for (let i = 1; i <= 14; i++) {
                const probe = new Date(d.getFullYear(), d.getMonth(), d.getDate() + i);
                if (targetDays.indexOf(probe.getDay()) !== -1) return w.todayKey(probe);
            }
            return null;
        }

        const guidanceDate = nextWeekday([1, 2, 3, 4, 5]);
        const slots = w.availableSlots('guidance', guidanceDate);
        assert(slots.length > 0, 'guidance has bookable slots on a weekday, got ' + slots.length);
        assert(slots.indexOf('12:00') === -1, 'lunch break is excluded from slots');

        const booking = w.bookAppointment({
            targetId: 'guidance', serviceId: 'guidance-counseling', serviceName: 'Personal Counseling Session',
            studentId: '2026-00010', studentName: 'Ana Reyes', date: guidanceDate, time: slots[0],
            purpose: 'Academic stress', requirementsConfirmed: true
        });
        assert(booking.ok === true, 'appointment booked');
        assert(/^APT-\d{4}-\d{4}$/.test(booking.appointment.reference), 'reference generated: ' + booking.appointment.reference);
        assert(booking.appointment.status === 'Confirmed', 'status is Confirmed');

        assert(w.availableSlots('guidance', guidanceDate).indexOf(slots[0]) === -1, 'booked slot is no longer offered');

        const clash = w.bookAppointment({
            targetId: 'guidance', serviceId: 'guidance-counseling', studentId: '2026-00011',
            studentName: 'Ben Cruz', date: guidanceDate, time: slots[0]
        });
        assert(clash.ok === false, 'double-booking the same slot is refused');

        const sameDay = w.bookAppointment({
            targetId: 'guidance', serviceId: 'guidance-counseling', studentId: '2026-00010',
            studentName: 'Ana Reyes', date: guidanceDate, time: slots[1]
        });
        assert(sameDay.ok === false, 'same student cannot double-book the same office on one day');

        const facultyDate = nextWeekday([1, 3, 5]);
        const facultySlots = w.availableSlots('fac-001', facultyDate);
        assert(facultySlots.length > 0, 'professor consultation slots available on their days');
        const sunday = (function () {
            const d = new Date();
            for (let i = 1; i <= 7; i++) {
                const probe = new Date(d.getFullYear(), d.getMonth(), d.getDate() + i);
                if (probe.getDay() === 0) return w.todayKey(probe);
            }
            return null;
        })();
        assert(w.availableSlots('fac-001', sunday).length === 0, 'no slots on a day the professor is unavailable');

        assert(w.cancelAppointment(booking.appointment.id) === true, 'appointment cancelled');
        assert(w.availableSlots('guidance', guidanceDate).indexOf(slots[0]) !== -1, 'cancelled slot is released back');

        const notes = w.notificationsForStudent('2026-00010');
        assert(notes.length >= 2, 'student received booking and cancellation notifications');
        dom.window.close();
    }

    console.log('');
    console.log('RESULTS: ' + passed + ' passed, ' + failed + ' failed');
    process.exit(failed ? 1 : 0);
})();
