<?php
declare(strict_types=1);
require_once __DIR__ . '/app/auth.php';
$isAuthenticated = auth_user() !== null;
$flow = (string)($_GET['flow'] ?? 'signup');
$flow = in_array($flow, ['login','signup'], true) ? $flow : 'signup';
$requestedNext = (string)($_GET['next'] ?? 'dashboard.php');
$allowedNext = ['dashboard.php','realtime/','image/','video/','voice/','lip-sync/','agents/'];
$basePath = app_base_path();
$basePrefix = rtrim($basePath, '/');
if ($basePrefix !== '' && str_starts_with($requestedNext, $basePrefix . '/')) $requestedNext = substr($requestedNext, strlen($basePrefix));
$requestedPath = ltrim($requestedNext, '/');
$legacyNext = ['index.php'=>'realtime/','image-studio.php'=>'image/','video-studio.php'=>'video/','voice-studio.php'=>'voice/','lip-sync.php'=>'lip-sync/','agent-studio.php'=>'agents/'];
$requestedPath = $legacyNext[$requestedPath] ?? $requestedPath;
$next = in_array($requestedPath, $allowedNext, true) ? $basePath . $requestedPath : $basePath . 'dashboard.php';
$target = $isAuthenticated ? $next : (($flow === 'login' ? 'login.php' : 'register.php') . '?direct=1&next=' . rawurlencode($next));
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#08090b"><meta name="description" content="Explore the ANONYMOUX STUDIO creative workspaces.">
<title>Explore the studios · ANONYMOUX STUDIO</title>
<link rel="stylesheet" href="assets/tour.css?v=2.5.0">
<link rel="stylesheet" href="assets/glass-notifications.css?v=2.5.8">
</head><body>
<main class="tour" id="tour">
<header class="tour-top">
<a class="tour-brand" href="onboarding.php"><span class="tour-mark">A</span><span>ANONYMOUX<small>STUDIO</small></span></a>
<a class="skip" href="<?=htmlspecialchars($target,ENT_QUOTES,'UTF-8')?>">Skip intro <span>→</span></a>
</header>
<div class="progress" aria-label="Introduction progress"><div class="progress-fill" id="progressFill"></div></div>
<section class="tour-stage" aria-live="polite">
<div class="tour-visual" id="tourVisual">
<img id="tourImage" src="assets/login-workspaces/realtime-edit.webp" alt="Realtime AI video editing workspace preview">
<div class="visual-shade"></div><div class="visual-tag" id="visualTag">LIVE TRANSFORMATION / 01</div>
</div>
<div class="tour-content">
<div class="tour-count"><span id="slideCount">01</span> / 05 <span class="count-line"></span></div>
<h1 id="slideTitle">Realtime Video Edit</h1>
<p id="slideDescription">Transform live video as it happens with a guided creative workflow.</p>
<div class="tour-actions">
<button class="back" id="backBtn" type="button" aria-label="Previous slide" disabled>←</button>
<button class="next" id="nextBtn" type="button"><span id="nextLabel">Next</span><span>→</span></button>
</div>
<div class="tour-dots" id="tourDots" aria-label="Choose introduction slide">
<button type="button" aria-label="Slide 1" class="active"></button><button type="button" aria-label="Slide 2"></button><button type="button" aria-label="Slide 3"></button><button type="button" aria-label="Slide 4"></button><button type="button" aria-label="Slide 5"></button>
</div>
</div>
</section>
<footer class="tour-footer"><span>ANONYMOUS VISUALS. LOUD IMPACT.</span><span>01—05 · CREATIVE WORKSPACES</span></footer>
</main>
<script>window.ANON_TOUR_TARGET=<?=json_encode($target,JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script>
<script src="assets/tour.js?v=2.5.0" defer></script>
</body></html>
