========================================
  ControlMax Pro - Punto de Venta
  Versión Offline para Cuba
========================================

CONTENIDO DEL ZIP
-----------------
index.html              → Pantalla principal
css/styles.css          → Estilos
js/license.js           → Sistema de licencia offline
js/db.js                → Base de datos (localStorage)
js/app.js               → Lógica de la aplicación
licencia_ejemplo.dat    → Licencia de prueba
README.txt              → Este archivo


CÓMO CREAR LA APK CON APKFORGE
------------------------------
1. Abre APKForge
2. Selecciona la carpeta "ControlMax_Pro" completa
3. Archivo principal: index.html
4. Configura:
   - Nombre de la app: ControlMax Pro
   - Package name: com.tuempresa.controlmaxpro
   - Versión: 1.0.0
   - Orientación: Sensor (recomendado)
5. Icono: usa una imagen que represente punto de venta
   (ver sugerencias de icono más abajo)
6. Compila la APK


CÓMO GENERAR LICENCIAS (SOLO TÚ)
--------------------------------
1. Abre el index.html en Chrome o Firefox
2. Presiona F12 → pestaña Console
3. Escribe:

   generarLicenciaArchivo("Nombre del Cliente", "2027-06-30", "6 meses")

   Ejemplos:
   generarLicenciaArchivo("Bodega El Sol", "2027-01-31", "3 meses")
   generarLicenciaArchivo("Tienda La Esperanza", "2027-10-31", "12 meses")
   generarLicenciaArchivo("Minimarket Pérez", "2026-11-30", "1 mes")

4. Se descarga automáticamente un archivo .dat
5. Entrégale ese archivo al cliente


CÓMO ACTIVA EL CLIENTE LA LICENCIA
----------------------------------
1. Abre la app
2. Aparece el aviso de licencia
3. Toca "Cargar Archivo de Licencia"
4. Selecciona el archivo .dat
5. Listo. Queda activada hasta la fecha de vencimiento.


FUNCIONES DE LA APP
-------------------
✓ Catálogo de productos (nombre, código, precio, stock)
✓ Punto de venta con carrito
✓ Descuentos
✓ Métodos de pago: Efectivo, Transferencia, Tarjeta, Mixto
✓ Control de stock automático
✓ Ventas del día e historial
✓ Ticket térmico 58mm
✓ Logo en el ticket
✓ Tema claro / oscuro
✓ Backup exportar / importar
✓ 100% Offline


ICONO RECOMENDADO PARA LA APK
-----------------------------
La app es un Punto de Venta (POS). Busca o diseña un icono que transmita:

  - Caja registradora / terminal de pago
  - Carrito de compras + ticket
  - Código de barras + dinero
  - Tablet o celular con pantalla de venta

Ideas concretas:
  1. Caja registradora moderna de color azul/verde
  2. Ticket de compra con símbolo $
  3. Lector de código de barras estilizado
  4. Carrito de supermercado con check de confirmación

Colores sugeridos: azul (#2563eb) o verde (#16a34a) sobre fondo blanco/oscuro.
Tamaño ideal: 512x512 px (PNG con fondo transparente).


NOTAS
-----
- Datos guardados en el dispositivo.
- Recomienda hacer backups periódicos.
- Licencia de ejemplo incluida (válida hasta 2027-12-31).
