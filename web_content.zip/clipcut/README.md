# ClipCut (MVP)

Mobile video editor: add clips, trim, split, reorder, add captions, export.
Plain HTML/JS in `www/index.html`, wrapped with Capacitor for Android.

## Try it in a browser first
Open `www/index.html` in Chrome (or `npx serve www`). Export downloads a file.

## Build the APK
Requirements: Node 18+, JDK 17, Android Studio (or just the Android SDK).

    npm install
    npx cap add android      # first time only
    npm run apk

APK lands at `android/app/build/outputs/apk/debug/app-debug.apk`.
Copy it to your phone and install (allow "install unknown apps").
Or: `npx cap open android` -> Build > Build APK(s), or press Run with the phone plugged in.

After editing www/index.html run `npx cap sync android` again.

## Known MVP limits
- Export is real-time (a 30 s edit takes 30 s) and keep the app open while it runs.
- Output is WebM (or MP4 if the phone's WebView supports it).
- One caption per clip, no transitions, filters or music yet.

## Next steps
Multi-track audio, per-clip speed/volume, overlays, ffmpeg.wasm for faster
MP4 export, or a native FFmpeg plugin.
