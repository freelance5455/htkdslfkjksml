TRUVORA — FINAL RELEASE SOURCE

This package contains the updated Truvora app source. Dashboard income, expense and balance tiles use a clean rectangular design. Transaction categories have been expanded for income and expenses. Import/export backup controls have been removed. User records are saved locally in the app's browser storage on the device.

Important: uninstalling the app or clearing its app/browser storage can delete locally saved records. Test storage persistence and Android packaging on the target device before publishing.
