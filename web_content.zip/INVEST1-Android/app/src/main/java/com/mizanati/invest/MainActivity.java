package com.mizanati.invest;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.print.*;
import android.webkit.*;
import android.widget.Toast;
import androidx.documentfile.provider.DocumentFile;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final ExecutorService NETWORK = Executors.newFixedThreadPool(3);
    private WebView web;
    private Uri treeUri;
    private static final int PICK_TREE=41, PICK_FILE=42;
    @Override public void onCreate(Bundle b){super.onCreate(b);String saved=getPreferences(MODE_PRIVATE).getString("backupTree",null);if(saved!=null)treeUri=Uri.parse(saved);getWindow().setStatusBarColor(android.graphics.Color.WHITE);getWindow().setNavigationBarColor(android.graphics.Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(true);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){fileCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,PICK_FILE);return true;}});web.addJavascriptInterface(new Bridge(),"AndroidBridge");web.loadUrl("file:///android_asset/index.html");}
    private void cb(String id,String json){String js="window.__nb("+JSONObject.quote(id)+","+json+")";runOnUiThread(()->web.evaluateJavascript(js,null));}
    private JSONObject result(boolean ok,String key,String val){JSONObject j=new JSONObject();try{j.put("ok",ok);if(key!=null)j.put(key,val);}catch(Exception ignored){}return j;}
    private String safe(String s){return s==null?"":s;}
    public class Bridge {
        @JavascriptInterface public void httpGet(String id,String url){NETWORK.execute(()->{HttpURLConnection c=null;try{URL parsed=new URL(url);if(!"https".equalsIgnoreCase(parsed.getProtocol()))throw new IOException("HTTPS required");c=(HttpURLConnection)parsed.openConnection();c.setRequestMethod("GET");c.setInstanceFollowRedirects(true);c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setUseCaches(false);c.setRequestProperty("User-Agent","MizanatiInvest-Android/1.2");c.setRequestProperty("Accept","application/json,text/plain,*/*");c.setRequestProperty("Cache-Control","no-cache");int code=c.getResponseCode();InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream();ByteArrayOutputStream o=new ByteArrayOutputStream();if(in!=null){try(InputStream stream=in){byte[] buf=new byte[8192];int n;while((n=stream.read(buf))>0)o.write(buf,0,n);}}JSONObject j=new JSONObject();j.put("ok",code>=200&&code<400);j.put("text",o.toString(StandardCharsets.UTF_8));if(code<200||code>=400)j.put("err","HTTP "+code);cb(id,j.toString());}catch(Exception e){cb(id,result(false,"err",e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage())).toString());}finally{if(c!=null)c.disconnect();}});}
        @JavascriptInterface public void folderInfo(String id){JSONObject j=result(true,"name",treeUri==null?"التخزين المختار":"المجلد المختار");try{j.put("granted",treeUri!=null);DocumentFile d=treeUri==null?null:DocumentFile.fromTreeUri(MainActivity.this,treeUri);j.put("hasApp",d!=null&&d.findFile("INVEST_BACKUP_MIZANATI")!=null);}catch(Exception ignored){}cb(id,j.toString());}
        @JavascriptInterface public void pickFolder(String id){runOnUiThread(()->{pending=id;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_TREE);});}
        @JavascriptInterface public void saveBackup(String id,String name,String data){try{if(treeUri==null){cb(id,result(false,"err","اختر مجلداً أولاً").toString());return;}DocumentFile root=DocumentFile.fromTreeUri(MainActivity.this,treeUri);DocumentFile dir=root.findFile("INVEST_BACKUP_MIZANATI");if(dir==null)dir=root.createDirectory("INVEST_BACKUP_MIZANATI");if(dir==null)throw new IOException("تعذر إنشاء مجلد النسخ الاحتياطي");DocumentFile f=dir.createFile("application/json",name);if(f==null)throw new IOException("تعذر إنشاء الملف");try(OutputStream o=getContentResolver().openOutputStream(f.getUri())){o.write(data.getBytes(StandardCharsets.UTF_8));}cb(id,result(true,"name",name).toString());}catch(Exception e){cb(id,result(false,"err",e.toString()).toString());}}
        @JavascriptInterface public void shareFile(String id,String name,String b64,String mime){try{byte[] bytes=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);File f=new File(getCacheDir(),name);try(FileOutputStream o=new FileOutputStream(f)){o.write(bytes);}Uri u=androidx.core.content.FileProvider.getUriForFile(MainActivity.this,getPackageName()+".provider",f);Intent it=new Intent(Intent.ACTION_SEND);it.setType(safe(mime).isEmpty()?"application/octet-stream":mime);it.putExtra(Intent.EXTRA_STREAM,u);it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(it,"مشاركة الملف"));cb(id,result(true,null,null).toString());}catch(Exception e){cb(id,result(false,"err",e.toString()).toString());}}
        @JavascriptInterface public void printPage(String title){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=19){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print(title,web.createPrintDocumentAdapter(title),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf","PDF",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());}});}
    }
    private String pending;
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_TREE){if(res==RESULT_OK&&data!=null){treeUri=data.getData();int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(treeUri,flags);getPreferences(MODE_PRIVATE).edit().putString("backupTree",treeUri.toString()).apply();cb(pending,result(true,"name","مجلد مختار").toString());}else cb(pending,result(false,"err","لم يتم اختيار مجلد").toString());}else if(req==PICK_FILE&&fileCallback!=null){fileCallback.onReceiveValue(res==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);fileCallback=null;}}
    private ValueCallback<Uri[]> fileCallback;
    @Override public void onBackPressed(){web.evaluateJavascript("window.__onBack&&window.__onBack()",v->{if(v==null||v.equals("false"))MainActivity.super.onBackPressed();});}
}
