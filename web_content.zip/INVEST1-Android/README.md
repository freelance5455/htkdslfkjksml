# MIZANATI INVEST — مشروع Android

مشروع Android Studio لتشغيل التطبيق داخل WebView، باسم وأيقونة **MIZANATI INVEST**. تخزين بيانات التطبيق JSON محليًا في `localStorage` فقط، مع قاعدة JSON للنسخ الاحتياطية المشفّرة؛ لا يحتوي هذا الإصدار على SQLite أو sql.js/WASM. ملفات النسخ الاحتياطي JSON مشفّرة بـ AES-GCM-256 مع PBKDF2، ولا تُرسل أو تُحفظ عبارة المرور. على Android تُحفظ النسخ في المجلد `INVEST_BACKUP_MIZANATI` داخل المكان الذي تختاره.

## البناء
1. افتح مجلد `INVEST1-Android` في Android Studio أو CodeAssist.
2. استخدم Android SDK Platform 35 وJDK 17 أو أحدث.
3. نفّذ `./gradlew assembleDebug` أو اختر Build → Build APK(s).
4. الناتج: `app/build/outputs/apk/debug/app-debug.apk`.

يستخدم الإصدار `compileSdk 35` و`targetSdk 34` لتجنب فرض edge-to-edge مع الحفاظ على التوافق مع Android 12. الإصدار الحالي `1.3.3`، `versionCode 7`، ومعرّف الحزمة ثابت `com.mizanati.invest` لتثبيته كتحديث.
