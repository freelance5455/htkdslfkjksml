ANONYMOUX STUDIO 2.5.3 — LANDING & SERVICES UPDATE
=================================================

Changes
-------
- Added a continuously scrolling services row for Image Editing, Image Creation,
  Video Editing, Video Creation, Lip Syncing, Voice Cloning, Document Editing,
  Document Creation and custom Creative Solutions.
- Every service card opens WhatsApp with a prefilled service-specific enquiry.
- WhatsApp contact: +234 815 802 1899.
- Added Instagram, Telegram, TikTok and X links to the landing-page footer.
- Expanded the marketing workspace directory to the seven existing routes:
  Image Studio, Video Studio, Realtime Studio, Voice Studio, Lip Sync Studio,
  Agent Studio and Shorts Studio.
- Corrected onboarding-tour next-route handling so valid workspace destinations
  survive sign-up/sign-in routing. Destinations are allowlisted.
- Added responsive layout, pause-on-hover/focus, and reduced-motion behavior
  for the services marquee.

Verification
------------
- PHP syntax: onboarding.php and onboarding-tour.php passed.
- JavaScript syntax: assets/landing.js passed Node syntax check.
- Workspace route targets were checked against files present in this source tree.
- This is a source-level update; live WhatsApp handoff, hosting behavior,
  authentication flow and mobile-browser rendering still require deployment testing.
