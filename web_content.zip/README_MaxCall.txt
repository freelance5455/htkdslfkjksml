MAX CALL — yangilangan interfeys loyihasi

Fayllar:
- index.html: Max Call ilovasining WebView ichidagi interfeysi; yangilangan zamonaviy ko‘rinish.

Muhim:
- Bu APK ichidan olingan HTML interfeys yangilandi. Tayyor APK qayta yig‘ilmadi va imzolanmadi.
- Oddiy SIM qo‘ng‘irog‘i telefonning standart terish oynasini ochadi.
- Video/internet qo‘ng‘irog‘i hozircha demo interfeys. Haqiqiy foydalanuvchilar orasida audio/video aloqa uchun WebRTC yoki ZEGOCLOUD kabi xizmat, loyiha kalitlari va server sozlamalari zarur.
- Kontaktlar/tarix kabi mavjud imkoniyatlar HTML loyihasida saqlangan.

APK qilish uchun bu index.html faylini Android/WebView loyiha ichidagi assets/web/index.html o‘rniga qo‘yib, Android loyihasini build qilib APK sifatida imzolash kerak.
