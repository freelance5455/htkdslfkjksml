/* Apkomini — TwinRD Engine interstitial (fires on every click / tab)
   Zone: 01M1B24QG59XSDFPGP0TFC8HSC
   Injects <ins data-tr-zone="..."> + adlib.js and re-arms on every user
   interaction, so the interstitial can show on every click. */
(function () {
  var ZONE = "01M1B24QG59XSDFPGP0TFC8HSC";
  var SRC = "https://s.ad.twinrdengine.com/adlib.js";

  function inject() {
    try {
      var ins = document.createElement("ins");
      ins.setAttribute("data-tr-zone", ZONE);
      ins.setAttribute("data-tr-fired", Date.now() + "" + Math.floor(Math.random() * 1e6));
      (document.body || document.documentElement).appendChild(ins);

      var s = document.createElement("script");
      s.type = "text/javascript";
      s.async = true;
      s.src = SRC + "?r=" + Date.now() + Math.random();
      s.setAttribute("data-tr-loader", "1");
      (document.body || document.head || document.documentElement).appendChild(s);

      // keep DOM clean: drop old ins tags, keep the newest few
      var all = document.querySelectorAll("ins[data-tr-zone]");
      for (var i = 0; i < all.length - 3; i++) {
        if (all[i].parentNode) all[i].parentNode.removeChild(all[i]);
      }
    } catch (e) {}
  }

  function start() {
    inject();
    document.addEventListener("click", function () { inject(); }, true);
    document.addEventListener("touchstart", function () { inject(); }, true);
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) inject();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }

  window.ApkominiTR = { fire: inject };
})();
