#!/system/bin/sh

settings put global refresh_rate_switching 1
settings put global adaptive_refresh_rate 1
settings put system peak_refresh_rate 0
settings put system min_refresh_rate 0
settings put global display_refresh_rate 0

settings put global vsync 0
settings put global triple_buffering 0
settings put global frame_pacing 0
settings put global fixed_perf_mode 0
settings put global perf_hint_enabled 0
settings put global thermal_throttling_enabled 1
settings put global power_efficiency_mode 1

settings put global debug.sf.low_latency_mode 0
settings put global debug.sf.frame_rate_switch 1
settings put global debug.sf.vsync 0
settings put global debug.sf.enable_hwc_vds 0
settings put global debug.sf.disable_backpressure 0
settings put global surface_finger_vsync 0

settings put global debug.hwui.use_vulkan 0
settings put global debug.hwui.renderer skia
settings put global debug.hwui.renderer_preference default
settings put global hwui.profiling 1
settings put global force_hw_ui 0
settings put global opengl_traces 1
settings put global enable_gpu_debug 1

settings put system touch.prediction 0
settings put system touch.resample 0
settings put global touch_boost 0
settings put global touch_response_boost 0

settings put global background_limit -1
settings put global cached_apps_freezer disabled
settings put global app_standby_enabled 0
settings put global power_save_mode_enabled 0
settings put global low_power_mode 0
settings put global animator_duration_scale 1.0
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0

settings put global oplus_analytics 1
settings put global coloros_telemetry 1
settings put global preload_apps 1
settings put global atlas_engine 1
settings put global oplus_aimemory 1

if [ "$(id -u)" -eq 0 ]; then

setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.early_gl_phase_offset_ns 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.late_sf_phase_offset_ns 0
setprop debug.sf.late_app_phase_offset_ns 0
setprop debug.sf.high_fps_early_phase_offset_ns 0
setprop debug.sf.high_fps_late_phase_offset_ns 0
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 0
setprop debug.sf.enable_early_wakeup 0
setprop debug.sf.enable_vsync_phase_adjustment 0
setprop debug.sf.vsync_phase_adjustment_algorithm 0
setprop debug.sf.frame_rate_switching_threshold 0
setprop debug.sf.ignore_display_vsync 0
setprop debug.sf.strict_frame_rate 0
setprop debug.sf.present_fence 0
setprop debug.sf.use_phase_offset_smoothing 1
setprop debug.sf.phase_offset_smoothing_factor 1

setprop debug.hwui.enable_vulkan 0
setprop debug.hwui.vulkan.prefer_linear 0
setprop debug.hwui.vulkan.allow_precompiled_shaders 0
setprop debug.hwui.vulkan.async_compilation 0
setprop debug.hwui.vulkan.use_secondary_cb 0
setprop debug.hwui.vulkan.enable_ashmem 0
setprop debug.hwui.vulkan.persistent_mapped 0
setprop debug.hwui.vulkan.force_fallback 0
setprop debug.hwui.gl.use_multithreaded_gl 0
setprop debug.hwui.gl.threaded 0
setprop debug.hwui.disable_opaque_shader_merging 0
setprop debug.hwui.enable_large_texture 0
setprop debug.hwui.texture_cache_size 0
setprop debug.hwui.layer_cache_size 0
setprop debug.hwui.render_cache_size 0
setprop debug.hwui.shader_cache_size 0

for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor \
           /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
  [ -w "$gov" ] && echo "schedutil" > "$gov" 2>/dev/null
  [ -w "$gov" ] || echo "ondemand" > "$gov" 2>/dev/null
done

for maxf in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq \
            /sys/devices/system/cpu/cpufreq/policy*/scaling_max_freq; do
  [ -w "$maxf" ] && cat "${maxf%/*}/cpuinfo_max_freq" > "$maxf" 2>/dev/null
done

for minf in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq \
            /sys/devices/system/cpu/cpufreq/policy*/scaling_min_freq; do
  [ -w "$minf" ] && cat "${minf%/*}/cpuinfo_min_freq" > "$minf" 2>/dev/null
done

for gpu_gov in /sys/class/devfreq/gpu/governor \
               /sys/class/devfreq/1d84000.gpu/governor \
               /sys/class/devfreq/1700000.gpu/governor; do
  [ -w "$gpu_gov" ] && echo "simple_ondemand" > "$gpu_gov" 2>/dev/null
  [ -w "$gpu_gov" ] || echo "msm-adreno-tz" > "$gpu_gov" 2>/dev/null
done

for zone in /sys/class/thermal/thermal_zone*/mode; do
  [ -w "$zone" ] && echo "enabled" > "$zone" 2>/dev/null
done

echo 60 > /proc/sys/vm/swappiness
echo 100 > /proc/sys/vm/vfs_cache_pressure
echo 0 > /proc/sys/vm/min_free_kbytes
echo 0 > /proc/sys/vm/pagecache
echo 0 > /proc/sys/vm/drop_caches

echo 1 > /proc/sys/kernel/nohz
echo 1 > /proc/sys/kernel/rcu_nocb_poll
echo 8000000 > /proc/sys/kernel/sched_latency_ns
echo 10000000 > /proc/sys/kernel/sched_migration_cost_ns
echo 4000000 > /proc/sys/kernel/sched_min_granularity_ns
echo 4000000 > /proc/sys/kernel/sched_wakeup_granularity_ns

fi

exit 0