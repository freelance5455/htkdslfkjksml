#!/system/bin/sh

MODDIR="${0%/*}"
case "$0" in
    */*) MODDIR="${0%/*}" ;;
    *) MODDIR="$(pwd 2>/dev/null || echo /data/adb/modules/Switchmat)" ;;
esac

if [ -f "$MODDIR/monitor.pid" ]; then
    kill "$(cat "$MODDIR/monitor.pid" 2>/dev/null)" 2>/dev/null
fi
pkill -f "$MODDIR/service.sh" 2>/dev/null
sleep 1

RESETPROP=""
if command -v resetprop >/dev/null 2>&1; then
    RESETPROP="resetprop"
elif [ -x /data/adb/magisk/resetprop ]; then
    RESETPROP="/data/adb/magisk/resetprop"
elif [ -x /data/adb/ksu/bin/resetprop ]; then
    RESETPROP="/data/adb/ksu/bin/resetprop"
fi

if [ -f "$MODDIR/lib/props.sh" ]; then
    . "$MODDIR/lib/props.sh" 2>/dev/null
fi

if [ -n "$RESETPROP" ]; then
    echo "$PROPS" | while IFS= read -r line; do
        [ -z "$line" ] && continue
        name="${line%%|*}"
        "$RESETPROP" --delete "$name" 2>/dev/null
        "$RESETPROP" -d "$name" 2>/dev/null
    done
    "$RESETPROP" --delete debug.hwui.renderer 2>/dev/null
    "$RESETPROP" -d debug.hwui.renderer 2>/dev/null
    "$RESETPROP" --delete ro.hwui.use_vulkan 2>/dev/null
    "$RESETPROP" -d ro.hwui.use_vulkan 2>/dev/null
    if [ -f "$MODDIR/props_backup" ]; then
        while IFS= read -r ln; do
            [ -z "$ln" ] && continue
            name="${ln%%=*}"
            val="${ln#*=}"
            if [ -n "$val" ]; then
                "$RESETPROP" "$name" "$val" 2>/dev/null
            fi
        done < "$MODDIR/props_backup"
    fi
fi

rm -f "$MODDIR/config.conf" "$MODDIR/games.conf" "$MODDIR/current_mode" \
      "$MODDIR/last_focus" "$MODDIR/monitor.pid" \
      "$MODDIR/config.conf.tmp" "$MODDIR/props_backup" 2>/dev/null
rm -f /data/local/tmp/vulkan_engine.log /data/local/tmp/vulkan_engine.log.old 2>/dev/null

exit 0
