#!/system/bin/sh
MODDIR="${0%/*}"
. "$MODDIR/lib/common.sh"
restore_settings
rm -rf /data/local/tmp/TM_Otimizacoes 2>/dev/null || true
exit 0
