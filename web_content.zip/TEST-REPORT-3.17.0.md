# RISEUP 3.17.0 — Balanced XP Rewards

## Changes
- Daily core task completion reward increased from 10 XP to 20 XP.
- Side task difficulty rewards: Easy 5 XP, Medium 7 XP, Hard 10 XP.
- Side task difficulty is selected when adding a task and shown in task cards.
- Existing unfinished side tasks with the old 1 XP reward migrate to Easy (5 XP). Previously completed side tasks retain their historical XP value.
- Missed core task penalty remains -20 XP; streak reset and non-negative XP balance behavior are unchanged.
- No other gameplay systems were intentionally changed.

## Verification
- `npm test` passed: static, PWA shell, gameplay, artwork, and sound checks.
- No Android device installation test was performed.
