import { useSyncExternalStore } from 'react';
import {
  BackupRecord,
  Bill,
  BillLineItem,
  Category,
  CreditNote,
  CreditNoteLineItem,
  Customer,
  CustomerDebtPayment,
  DailyClosing,
  Language,
  OwnerAlert,
  PosState,
  Product,
  RestockOrder,
  ShopConfig,
  Supplier,
  UserAccount,
} from '../types/pos';

const STORAGE_KEY = 'khazna_pos_state_v1';
const THEME_STORAGE_KEY = 'khazna_pos_theme_v1';

export function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function getDayKey(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getMonthKey(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${month}${year}`; // MMYYYY
}

export function sanitizeShopPrefix(shopName: string): string {
  const normalized = shopName
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '');
  return normalized || 'KHAZNA';
}

function createEmptyState(): PosState {
  return {
    shop: null,
    users: [],
    currentUserId: null,
    language: 'fr',
    categories: [],
    products: [],
    suppliers: [],
    restockOrders: [],
    customers: [],
    customerDebtPayments: [],
    bills: [],
    creditNotes: [],
    dailyClosings: [],
    backups: [],
    monthlyCounter: {
      monthKey: getMonthKey(),
      lastCounter: 0,
    },
  };
}

// Synchronous in-memory cache + debounced localStorage persistence
let memoryState: PosState | null = null;
let writeTimer: ReturnType<typeof setTimeout> | null = null;
const listeners = new Set<() => void>();

function loadStateFromDisk(): PosState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createEmptyState();
    const parsed = JSON.parse(raw) as Partial<PosState>;
    return {
      ...createEmptyState(),
      ...parsed,
      monthlyCounter: parsed.monthlyCounter ?? {
        monthKey: getMonthKey(),
        lastCounter: 0,
      },
    };
  } catch {
    return createEmptyState();
  }
}

export function getPosState(): PosState {
  if (!memoryState) {
    memoryState = loadStateFromDisk();
  }
  return memoryState;
}

function flushPersist(): void {
  if (writeTimer) {
    clearTimeout(writeTimer);
    writeTimer = null;
  }
  if (!memoryState) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memoryState));
  } catch {
    // Ignore storage quota errors gracefully
  }
}

function schedulePersist(): void {
  if (writeTimer) {
    clearTimeout(writeTimer);
  }
  writeTimer = setTimeout(() => {
    flushPersist();
  }, 250);
}

if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', flushPersist);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      flushPersist();
    }
  });
}

function commitState(next: PosState, immediate = false): void {
  memoryState = next;
  if (immediate) {
    flushPersist();
  } else {
    schedulePersist();
  }
  listeners.forEach((l) => l());
}

export function refreshStoreFromStorage(): PosState {
  if (writeTimer) {
    flushPersist();
  }
  memoryState = loadStateFromDisk();
  listeners.forEach((l) => l());
  return memoryState;
}

export function subscribePosStore(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function usePosStore(): PosState {
  return useSyncExternalStore(subscribePosStore, getPosState, getPosState);
}

// Theme storage helpers
export function getStoredTheme(): 'light' | 'dark' | 'system' {
  try {
    const val = localStorage.getItem(THEME_STORAGE_KEY);
    if (val === 'light' || val === 'dark' || val === 'system') return val;
  } catch {
    // ignore
  }
  return 'system';
}

export function saveStoredTheme(theme: 'light' | 'dark' | 'system'): void {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
    // ignore
  }
}

// Seed sample grocery data (Algerian Dinar grocery store)
function createGrocerySeed(ownerId: string) {
  const now = new Date().toISOString();
  const catBoissons: Category = { id: uid('cat'), name: 'Boissons & Eaux' };
  const catLaitier: Category = { id: uid('cat'), name: 'Produits Laitiers' };
  const catEpicerie: Category = { id: uid('cat'), name: 'Épicerie Sèche' };
  const catVrac: Category = { id: uid('cat'), name: 'Fruits, Légumes & Vrac' };
  const catHygiene: Category = { id: uid('cat'), name: 'Hygiène & Entretien' };

  const categories = [catBoissons, catLaitier, catEpicerie, catVrac, catHygiene];

  const products: Product[] = [
    {
      id: uid('prd'),
      barcode: '6130001000011',
      name: 'Eau Minérale Ifri',
      variantLabel: '1.5L',
      purchasePrice: 28,
      sellingPrice: 40,
      quantity: 48,
      categoryId: catBoissons.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130001000028',
      name: 'Eau Minérale Ifri',
      variantLabel: '0.5L',
      purchasePrice: 18,
      sellingPrice: 25,
      quantity: 36,
      categoryId: catBoissons.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130002000014',
      name: 'Lait Candia Viva',
      variantLabel: '1L',
      purchasePrice: 115,
      sellingPrice: 135,
      quantity: 24,
      categoryId: catLaitier.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130002000021',
      name: 'Yaourt Soummam Acti+',
      variantLabel: 'Pot 100g',
      purchasePrice: 26,
      sellingPrice: 35,
      quantity: 4,
      lowStockThreshold: 6,
      categoryId: catLaitier.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130003000017',
      name: 'Huile Elio',
      variantLabel: '2L',
      purchasePrice: 250,
      sellingPrice: 290,
      quantity: 18,
      categoryId: catEpicerie.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130003000024',
      name: 'Sucre Cristal Cevital',
      variantLabel: '1kg',
      purchasePrice: 82,
      sellingPrice: 95,
      quantity: 30,
      categoryId: catEpicerie.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130003000031',
      name: 'Café Moulu Bonal',
      variantLabel: '250g',
      purchasePrice: 210,
      sellingPrice: 260,
      quantity: 14,
      categoryId: catEpicerie.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '6130005000019',
      name: 'Détergent Isis',
      variantLabel: '1kg',
      purchasePrice: 195,
      sellingPrice: 240,
      quantity: 0,
      categoryId: catHygiene.id,
      unitType: 'UNIT',
      createdAt: now,
      updatedAt: now,
    },
    // Weighed products (no barcode)
    {
      id: uid('prd'),
      barcode: '',
      name: 'Tomates Fraîches',
      purchasePrice: 80,
      sellingPrice: 120,
      quantity: 25,
      categoryId: catVrac.id,
      unitType: 'KG',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '',
      name: 'Pommes de Terre',
      purchasePrice: 65,
      sellingPrice: 95,
      quantity: 40,
      categoryId: catVrac.id,
      unitType: 'KG',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: uid('prd'),
      barcode: '',
      name: 'Olives Vertes Vrac',
      purchasePrice: 45,
      sellingPrice: 70,
      quantity: 1500,
      lowStockThreshold: 300,
      categoryId: catVrac.id,
      unitType: 'GRAM',
      createdAt: now,
      updatedAt: now,
    },
  ];

  const sup1: Supplier = {
    id: uid('sup'),
    name: 'SARL Distri-Alimentaire',
    phone: '0550 12 34 56',
    notes: 'Livraison Mardi & Vendredi',
  };
  const sup2: Supplier = {
    id: uid('sup'),
    name: 'Grossiste Primeurs Mitidja',
    phone: '0661 78 90 12',
    notes: 'Légumes et fruits en gros',
  };

  const cust1: Customer = {
    id: uid('cus'),
    name: 'Karim Benali',
    phone: '0770 45 22 10',
    notes: 'Voisin immeuble B',
    balanceOwed: 1450,
    createdAt: now,
  };

  const cashier1: UserAccount = {
    id: uid('usr'),
    name: 'Yacine (Caissier)',
    role: 'cashier',
    pin: '0000',
    active: true,
    biometricEnabled: false,
    createdAt: now,
  };

  // One unpaid supplier invoice from 35 days ago to show reminder
  const oldDate = new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString();
  const restock1: RestockOrder = {
    id: uid('rst'),
    supplierId: sup1.id,
    supplierName: sup1.name,
    arrivalDate: getDayKey(oldDate),
    billingDate: oldDate,
    dueDate: getDayKey(new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)),
    lineItems: [
      {
        productId: products[4].id,
        productName: `${products[4].name} (${products[4].variantLabel})`,
        barcode: products[4].barcode,
        quantity: 20,
        purchasePrice: 250,
      },
    ],
    totalAmount: 5000,
    paidAmount: 2000,
    status: 'received',
    paymentStatus: 'partial',
    notes: 'Reste à régler sur facture #842',
    paymentHistory: [
      {
        id: uid('pay'),
        amount: 2000,
        date: oldDate,
        note: 'Avance espèces',
      },
    ],
  };

  void ownerId;
  return {
    categories,
    products,
    suppliers: [sup1, sup2],
    restockOrders: [restock1],
    customers: [cust1],
    extraUsers: [cashier1],
  };
}

// Onboarding & Auth
export function setupShop(input: {
  shopName: string;
  ownerName: string;
  address: string;
  phone: string;
  logoDataUrl?: string;
  ownerPin: string;
  lowStockThreshold: number;
  seedDemo: boolean;
}): void {
  const now = new Date().toISOString();
  const owner: UserAccount = {
    id: uid('usr'),
    name: input.ownerName.trim(),
    role: 'owner',
    pin: input.ownerPin.trim(),
    active: true,
    biometricEnabled: true,
    createdAt: now,
  };

  const shop: ShopConfig = {
    name: input.shopName.trim(),
    ownerName: input.ownerName.trim(),
    address: input.address.trim(),
    phone: input.phone.trim(),
    logoDataUrl: input.logoDataUrl,
    currency: 'DA',
    defaultLanguage: 'fr',
    lowStockThreshold: Math.max(1, input.lowStockThreshold || 5),
    createdAt: now,
  };

  const base = createEmptyState();
  if (input.seedDemo) {
    const seed = createGrocerySeed(owner.id);
    base.categories = seed.categories;
    base.products = seed.products;
    base.suppliers = seed.suppliers;
    base.restockOrders = seed.restockOrders;
    base.customers = seed.customers;
    base.users = [owner, ...seed.extraUsers];
  } else {
    base.categories = [
      { id: uid('cat'), name: 'Général' },
      { id: uid('cat'), name: 'Boissons' },
      { id: uid('cat'), name: 'Vrac / Pesé' },
    ];
    base.users = [owner];
  }

  base.shop = shop;
  base.currentUserId = owner.id;
  commitState(base, true);
}

export function loginWithPin(userId: string, pin: string): boolean {
  const state = getPosState();
  const user = state.users.find((u) => u.id === userId && u.active);
  if (!user || user.pin !== pin) return false;
  commitState({ ...state, currentUserId: user.id }, true);
  return true;
}

export function loginOwnerBiometric(): boolean {
  const state = getPosState();
  const owner = state.users.find((u) => u.role === 'owner' && u.active && u.biometricEnabled);
  if (!owner) return false;
  commitState({ ...state, currentUserId: owner.id }, true);
  return true;
}

export function logoutUser(): void {
  const state = getPosState();
  commitState({ ...state, currentUserId: null }, true);
}

export function verifyOwnerPin(pin: string): boolean {
  const state = getPosState();
  const owner = state.users.find((u) => u.role === 'owner');
  return Boolean(owner && owner.pin === pin);
}

export function deleteAllAccountData(pin: string): boolean {
  if (!verifyOwnerPin(pin)) return false;
  if (writeTimer) {
    clearTimeout(writeTimer);
    writeTimer = null;
  }
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
  memoryState = createEmptyState();
  listeners.forEach((l) => l());
  return true;
}

// Language & Shop settings
export function setAppLanguage(language: Language): void {
  const state = getPosState();
  commitState({
    ...state,
    language,
    shop: state.shop ? { ...state.shop, defaultLanguage: language } : null,
  });
}

export function updateShopSettings(updates: Partial<ShopConfig>): void {
  const state = getPosState();
  if (!state.shop) return;
  commitState({
    ...state,
    shop: { ...state.shop, ...updates },
  });
}

export function updateOwnerBiometric(enabled: boolean): void {
  const state = getPosState();
  commitState({
    ...state,
    users: state.users.map((u) => (u.role === 'owner' ? { ...u, biometricEnabled: enabled } : u)),
  });
}

export function upsertCashierAccount(input: {
  id?: string;
  name: string;
  pin: string;
  active: boolean;
}): void {
  const state = getPosState();
  const now = new Date().toISOString();
  if (input.id) {
    commitState({
      ...state,
      users: state.users.map((u) =>
        u.id === input.id ? { ...u, name: input.name.trim(), pin: input.pin.trim(), active: input.active } : u
      ),
    });
  } else {
    const newCashier: UserAccount = {
      id: uid('usr'),
      name: input.name.trim(),
      role: 'cashier',
      pin: input.pin.trim(),
      active: input.active,
      biometricEnabled: false,
      createdAt: now,
    };
    commitState({
      ...state,
      users: [...state.users, newCashier],
    });
  }
}

// Categories
export function addCategory(name: string): Category {
  const state = getPosState();
  const cat: Category = { id: uid('cat'), name: name.trim() };
  commitState({ ...state, categories: [...state.categories, cat] });
  return cat;
}

export function updateCategory(id: string, name: string): void {
  const state = getPosState();
  commitState({
    ...state,
    categories: state.categories.map((c) => (c.id === id ? { ...c, name: name.trim() } : c)),
  });
}

export function deleteCategory(id: string): void {
  const state = getPosState();
  const fallback = state.categories.find((c) => c.id !== id)?.id ?? '';
  commitState({
    ...state,
    categories: state.categories.filter((c) => c.id !== id),
    products: state.products.map((p) => (p.categoryId === id ? { ...p, categoryId: fallback } : p)),
  });
}

// Products
export function upsertProduct(
  input: Omit<Product, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
): { ok: boolean; error?: string; product?: Product } {
  const state = getPosState();
  const cleanBarcode = input.barcode.trim();

  if (input.unitType === 'UNIT' && cleanBarcode) {
    const duplicate = state.products.find(
      (p) => p.barcode === cleanBarcode && p.id !== input.id
    );
    if (duplicate) {
      return { ok: false, error: `Barcode ${cleanBarcode} already belongs to "${duplicate.name}"` };
    }
  }

  const now = new Date().toISOString();
  if (input.id) {
    let updatedProduct: Product | undefined;
    const products = state.products.map((p) => {
      if (p.id === input.id) {
        updatedProduct = {
          ...p,
          ...input,
          barcode: cleanBarcode,
          updatedAt: now,
        };
        return updatedProduct;
      }
      return p;
    });
    commitState({ ...state, products });
    return { ok: true, product: updatedProduct };
  }

  const created: Product = {
    ...input,
    id: uid('prd'),
    barcode: cleanBarcode,
    createdAt: now,
    updatedAt: now,
  };
  commitState({ ...state, products: [created, ...state.products] });
  return { ok: true, product: created };
}

export function deleteProduct(id: string): void {
  const state = getPosState();
  commitState({
    ...state,
    products: state.products.filter((p) => p.id !== id),
  });
}

// Day lock check
export function isDayLocked(dayKey: string = getDayKey()): boolean {
  const state = getPosState();
  return state.dailyClosings.some((c) => c.dayKey === dayKey);
}

// Bill Number Generator: <SHOPNAME>-<MM><YYYY>-<5-digit counter>
function allocateNextBillNumber(state: PosState, now = new Date()): {
  billNumber: string;
  monthlyCounter: { monthKey: string; lastCounter: number };
} {
  const monthKey = getMonthKey(now);
  const prefix = sanitizeShopPrefix(state.shop?.name ?? 'KHAZNA');
  const nextCounter =
    state.monthlyCounter.monthKey === monthKey ? state.monthlyCounter.lastCounter + 1 : 1;
  const padded = String(nextCounter).padStart(5, '0');
  return {
    billNumber: `${prefix}-${monthKey}-${padded}`,
    monthlyCounter: { monthKey, lastCounter: nextCounter },
  };
}

// Create Sale Bill
export function createSaleBill(input: {
  items: BillLineItem[];
  paymentType: 'cash' | 'credit';
  customerId?: string;
}): { ok: boolean; error?: string; bill?: Bill } {
  const state = getPosState();
  const currentUser = state.users.find((u) => u.id === state.currentUserId);
  if (!currentUser) return { ok: false, error: 'No active user' };

  const now = new Date();
  const dayKey = getDayKey(now);
  if (isDayLocked(dayKey)) {
    return { ok: false, error: 'Day is locked after closing' };
  }

  if (input.items.length === 0) {
    return { ok: false, error: 'Cart is empty' };
  }

  if (input.paymentType === 'credit' && currentUser.role !== 'owner') {
    return { ok: false, error: 'Only Owner can record credit sales' };
  }

  const customer = input.customerId
    ? state.customers.find((c) => c.id === input.customerId)
    : undefined;
  if (input.paymentType === 'credit' && !customer) {
    return { ok: false, error: 'Customer required for credit sale' };
  }

  const { billNumber, monthlyCounter } = allocateNextBillNumber(state, now);
  const total = Math.round(input.items.reduce((sum, it) => sum + it.total, 0) * 100) / 100;

  const bill: Bill = {
    id: uid('bil'),
    billNumber,
    date: now.toISOString(),
    dayKey,
    cashierId: currentUser.id,
    cashierName: currentUser.name,
    items: input.items,
    subtotal: total,
    total,
    paymentType: input.paymentType,
    customerId: customer?.id,
    customerName: customer?.name,
  };

  // Decrement stock for tracked products
  const products = state.products.map((prod) => {
    const soldQty = input.items
      .filter((it) => !it.isOther && it.productId === prod.id)
      .reduce((acc, it) => acc + it.quantity, 0);
    if (soldQty <= 0) return prod;
    return {
      ...prod,
      quantity: Math.max(0, Math.round((prod.quantity - soldQty) * 1000) / 1000),
      updatedAt: now.toISOString(),
    };
  });

  // Update customer balance if credit sale
  const customers =
    input.paymentType === 'credit' && customer
      ? state.customers.map((c) =>
          c.id === customer.id ? { ...c, balanceOwed: Math.round((c.balanceOwed + total) * 100) / 100 } : c
        )
      : state.customers;

  commitState(
    {
      ...state,
      products,
      customers,
      bills: [bill, ...state.bills],
      monthlyCounter,
    },
    true
  );

  return { ok: true, bill };
}

// Owner Edit Bill (supports modifying quantities, removing lines, AND adding new products!)
export function updateBillItems(
  billId: string,
  newItems: BillLineItem[]
): { ok: boolean; error?: string; bill?: Bill } {
  const state = getPosState();
  const currentUser = state.users.find((u) => u.id === state.currentUserId);
  if (!currentUser || currentUser.role !== 'owner') {
    return { ok: false, error: 'Owner only' };
  }

  const existing = state.bills.find((b) => b.id === billId);
  if (!existing) return { ok: false, error: 'Bill not found' };
  if (isDayLocked(existing.dayKey)) return { ok: false, error: 'Day is locked' };
  if (existing.isCancelled) return { ok: false, error: 'Cancelled bill cannot be edited' };
  if (newItems.length === 0) return { ok: false, error: 'Bill must have at least one item' };

  const now = new Date().toISOString();

  // Compute stock delta per productId (oldQty - newQty => positive returns to stock, negative deducts from stock)
  const oldByProd = new Map<string, number>();
  for (const it of existing.items) {
    if (!it.isOther && it.productId) {
      oldByProd.set(it.productId, (oldByProd.get(it.productId) ?? 0) + it.quantity);
    }
  }
  const newByProd = new Map<string, number>();
  for (const it of newItems) {
    if (!it.isOther && it.productId) {
      newByProd.set(it.productId, (newByProd.get(it.productId) ?? 0) + it.quantity);
    }
  }

  const products = state.products.map((prod) => {
    const oldQty = oldByProd.get(prod.id) ?? 0;
    const newQty = newByProd.get(prod.id) ?? 0;
    const delta = oldQty - newQty;
    if (delta === 0) return prod;
    return {
      ...prod,
      quantity: Math.max(0, Math.round((prod.quantity + delta) * 1000) / 1000),
      updatedAt: now,
    };
  });

  const newTotal = Math.round(newItems.reduce((s, it) => s + it.total, 0) * 100) / 100;
  const totalDelta = newTotal - existing.total;

  // Adjust customer credit balance if credit sale
  const customers =
    existing.paymentType === 'credit' && existing.customerId && totalDelta !== 0
      ? state.customers.map((c) =>
          c.id === existing.customerId
            ? { ...c, balanceOwed: Math.max(0, Math.round((c.balanceOwed + totalDelta) * 100) / 100) }
            : c
        )
      : state.customers;

  const updatedBill: Bill = {
    ...existing,
    items: newItems,
    subtotal: newTotal,
    total: newTotal,
    editedAt: now,
  };

  commitState(
    {
      ...state,
      products,
      customers,
      bills: state.bills.map((b) => (b.id === billId ? updatedBill : b)),
    },
    true
  );

  return { ok: true, bill: updatedBill };
}

// Issue Credit Note (Partial or Full Cancellation)
export function issueCreditNote(input: {
  billId: string;
  itemsToReturn: Array<{ lineItemId: string; quantity: number }>;
  isFull: boolean;
  reason?: string;
}): { ok: boolean; error?: string; creditNote?: CreditNote } {
  const state = getPosState();
  const currentUser = state.users.find((u) => u.id === state.currentUserId);
  if (!currentUser || currentUser.role !== 'owner') {
    return { ok: false, error: 'Owner only' };
  }

  const bill = state.bills.find((b) => b.id === input.billId);
  if (!bill) return { ok: false, error: 'Bill not found' };
  if (isDayLocked(bill.dayKey)) return { ok: false, error: 'Day is locked' };
  if (bill.isCancelled) return { ok: false, error: 'Already cancelled' };

  const existingNotesForBill = state.creditNotes.filter((cn) => cn.billId === bill.id);
  const seq = String(existingNotesForBill.length + 1).padStart(2, '0');
  const creditNoteNumber = `AV-${bill.billNumber}-${seq}`;

  const cnItems: CreditNoteLineItem[] = [];
  for (const req of input.itemsToReturn) {
    if (req.quantity <= 0) continue;
    const orig = bill.items.find((it) => it.id === req.lineItemId);
    if (!orig) continue;
    const alreadyReturned = existingNotesForBill.reduce((sum, cn) => {
      const found = cn.items.find((ci) => ci.lineItemId === orig.id);
      return sum + (found ? found.quantity : 0);
    }, 0);
    const maxReturnable = Math.max(0, orig.quantity - alreadyReturned);
    const qty = Math.min(req.quantity, maxReturnable);
    if (qty <= 0) continue;
    cnItems.push({
      lineItemId: orig.id,
      productId: orig.productId,
      name: orig.name,
      quantity: qty,
      unitPrice: orig.unitPrice,
      total: Math.round(qty * orig.unitPrice * 100) / 100,
    });
  }

  if (cnItems.length === 0) {
    return { ok: false, error: 'No valid quantities selected to return' };
  }

  const now = new Date();
  const totalRefund = Math.round(cnItems.reduce((s, it) => s + it.total, 0) * 100) / 100;

  const creditNote: CreditNote = {
    id: uid('cn'),
    creditNoteNumber,
    billId: bill.id,
    billNumber: bill.billNumber,
    date: now.toISOString(),
    dayKey: getDayKey(now),
    items: cnItems,
    totalRefund,
    isFull: input.isFull,
    reason: input.reason?.trim(),
    createdByUserId: currentUser.id,
  };

  // Return quantities to stock
  const products = state.products.map((prod) => {
    const retQty = cnItems
      .filter((ci) => ci.productId === prod.id)
      .reduce((s, ci) => s + ci.quantity, 0);
    if (retQty <= 0) return prod;
    return {
      ...prod,
      quantity: Math.round((prod.quantity + retQty) * 1000) / 1000,
      updatedAt: now.toISOString(),
    };
  });

  // If credit sale, reduce customer balance
  const customers =
    bill.paymentType === 'credit' && bill.customerId
      ? state.customers.map((c) =>
          c.id === bill.customerId
            ? { ...c, balanceOwed: Math.max(0, Math.round((c.balanceOwed - totalRefund) * 100) / 100) }
            : c
        )
      : state.customers;

  // Check if all items are now returned -> mark bill cancelled
  const totalReturnedAll =
    existingNotesForBill.reduce((s, cn) => s + cn.totalRefund, 0) + totalRefund;
  const fullyReturned = input.isFull || totalReturnedAll >= bill.total - 0.01;

  const bills = state.bills.map((b) =>
    b.id === bill.id ? { ...b, isCancelled: fullyReturned } : b
  );

  commitState(
    {
      ...state,
      products,
      customers,
      bills,
      creditNotes: [creditNote, ...state.creditNotes],
    },
    true
  );

  return { ok: true, creditNote };
}

// Suppliers & Restock Orders
export function upsertSupplier(input: Omit<Supplier, 'id'> & { id?: string }): Supplier {
  const state = getPosState();
  if (input.id) {
    const updated: Supplier = { ...input, id: input.id };
    commitState({
      ...state,
      suppliers: state.suppliers.map((s) => (s.id === input.id ? updated : s)),
    });
    return updated;
  }
  const created: Supplier = { ...input, id: uid('sup') };
  commitState({ ...state, suppliers: [created, ...state.suppliers] });
  return created;
}

export function createRestockOrder(input: {
  supplierId: string;
  arrivalDate: string;
  dueDate: string;
  lineItems: RestockOrder['lineItems'];
  markPaidNow: boolean;
  markReceivedNow: boolean;
  notes: string;
}): RestockOrder | null {
  const state = getPosState();
  const supplier = state.suppliers.find((s) => s.id === input.supplierId);
  if (!supplier || input.lineItems.length === 0) return null;

  const now = new Date().toISOString();
  const totalAmount = Math.round(
    input.lineItems.reduce((s, it) => s + it.quantity * it.purchasePrice, 0) * 100
  ) / 100;

  const order: RestockOrder = {
    id: uid('rst'),
    supplierId: supplier.id,
    supplierName: supplier.name,
    arrivalDate: input.arrivalDate || getDayKey(now),
    billingDate: now,
    dueDate: input.dueDate || getDayKey(now),
    lineItems: input.lineItems,
    totalAmount,
    paidAmount: input.markPaidNow ? totalAmount : 0,
    status: input.markReceivedNow ? 'received' : 'pending',
    paymentStatus: input.markPaidNow ? 'paid' : 'unpaid',
    notes: input.notes.trim(),
    paymentHistory: input.markPaidNow
      ? [{ id: uid('pay'), amount: totalAmount, date: now, note: 'Payé à la commande' }]
      : [],
  };

  let products = state.products;
  if (input.markReceivedNow) {
    products = state.products.map((prod) => {
      const addQty = input.lineItems
        .filter((li) => li.productId === prod.id)
        .reduce((s, li) => s + li.quantity, 0);
      if (addQty <= 0) return prod;
      const latestItem = input.lineItems.find((li) => li.productId === prod.id);
      return {
        ...prod,
        quantity: Math.round((prod.quantity + addQty) * 1000) / 1000,
        purchasePrice: latestItem ? latestItem.purchasePrice : prod.purchasePrice,
        updatedAt: now,
      };
    });
  }

  commitState({
    ...state,
    products,
    restockOrders: [order, ...state.restockOrders],
  });
  return order;
}

export function markRestockOrderReceived(orderId: string): void {
  const state = getPosState();
  const order = state.restockOrders.find((o) => o.id === orderId);
  if (!order || order.status === 'received') return;
  const now = new Date().toISOString();

  const products = state.products.map((prod) => {
    const addQty = order.lineItems
      .filter((li) => li.productId === prod.id)
      .reduce((s, li) => s + li.quantity, 0);
    if (addQty <= 0) return prod;
    return {
      ...prod,
      quantity: Math.round((prod.quantity + addQty) * 1000) / 1000,
      updatedAt: now,
    };
  });

  commitState({
    ...state,
    products,
    restockOrders: state.restockOrders.map((o) =>
      o.id === orderId ? { ...o, status: 'received' } : o
    ),
  });
}

// Supplier Debt Payment: supports PARTIAL or TOTAL payment!
export function paySupplierOrder(orderId: string, amount: number, note?: string): void {
  const state = getPosState();
  const order = state.restockOrders.find((o) => o.id === orderId);
  if (!order) return;

  const remaining = Math.max(0, order.totalAmount - order.paidAmount);
  const payAmount = Math.min(remaining, Math.max(0, Math.round(amount * 100) / 100));
  if (payAmount <= 0) return;

  const newPaid = Math.round((order.paidAmount + payAmount) * 100) / 100;
  const paymentStatus: RestockOrder['paymentStatus'] =
    newPaid >= order.totalAmount - 0.01 ? 'paid' : 'partial';

  commitState({
    ...state,
    restockOrders: state.restockOrders.map((o) =>
      o.id === orderId
        ? {
            ...o,
            paidAmount: newPaid,
            paymentStatus,
            paymentHistory: [
              ...o.paymentHistory,
              { id: uid('pay'), amount: payAmount, date: new Date().toISOString(), note },
            ],
          }
        : o
    ),
  });
}

// Customers & Customer Debt Payments (automatically added to daily closing as payement dettes!)
export function upsertCustomer(input: {
  id?: string;
  name: string;
  phone: string;
  notes: string;
}): Customer {
  const state = getPosState();
  if (input.id) {
    let updated!: Customer;
    const customers = state.customers.map((c) => {
      if (c.id === input.id) {
        updated = { ...c, name: input.name.trim(), phone: input.phone.trim(), notes: input.notes.trim() };
        return updated;
      }
      return c;
    });
    commitState({ ...state, customers });
    return updated;
  }
  const created: Customer = {
    id: uid('cus'),
    name: input.name.trim(),
    phone: input.phone.trim(),
    notes: input.notes.trim(),
    balanceOwed: 0,
    createdAt: new Date().toISOString(),
  };
  commitState({ ...state, customers: [created, ...state.customers] });
  return created;
}

export function recordCustomerDebtPayment(
  customerId: string,
  amount: number,
  note?: string
): CustomerDebtPayment | null {
  const state = getPosState();
  const currentUser = state.users.find((u) => u.id === state.currentUserId);
  const customer = state.customers.find((c) => c.id === customerId);
  if (!customer || !currentUser) return null;

  const payAmount = Math.min(customer.balanceOwed, Math.max(0, Math.round(amount * 100) / 100));
  if (payAmount <= 0) return null;

  const now = new Date();
  const dayKey = getDayKey(now);

  const payment: CustomerDebtPayment = {
    id: uid('cdp'),
    customerId: customer.id,
    customerName: customer.name,
    amount: payAmount,
    date: now.toISOString(),
    dayKey,
    note: note?.trim(),
    recordedByUserId: currentUser.id,
  };

  commitState(
    {
      ...state,
      customers: state.customers.map((c) =>
        c.id === customerId
          ? { ...c, balanceOwed: Math.max(0, Math.round((c.balanceOwed - payAmount) * 100) / 100) }
          : c
      ),
      customerDebtPayments: [payment, ...state.customerDebtPayments],
    },
    true
  );

  return payment;
}

// Daily Closing Computation & Lock
export interface DayClosingMetrics {
  dayKey: string;
  totalSales: number;
  cashSales: number;
  creditSales: number;
  creditSalesCount: number;
  debtPaymentsTotal: number;
  totalRefunds: number;
  cogs: number;
  dailyGains: number;
  billCount: number;
  expectedCash: number;
  openSupplierDebtAtClose: number;
  isClosed: boolean;
}

export function computeDayClosingMetrics(dayKey: string = getDayKey()): DayClosingMetrics {
  const state = getPosState();
  const dayBills = state.bills.filter((b) => b.dayKey === dayKey);
  const dayNotes = state.creditNotes.filter((cn) => cn.dayKey === dayKey);
  const dayDebtPayments = state.customerDebtPayments.filter((p) => p.dayKey === dayKey);

  let totalSales = 0;
  let cashSales = 0;
  let creditSales = 0;
  let creditSalesCount = 0;
  let cogs = 0;

  for (const b of dayBills) {
    totalSales += b.total;
    if (b.paymentType === 'cash') {
      cashSales += b.total;
    } else {
      creditSales += b.total;
      creditSalesCount += 1;
    }
    for (const item of b.items) {
      cogs += item.purchasePrice * item.quantity;
    }
  }

  let totalRefunds = 0;
  let cashRefunds = 0;
  for (const cn of dayNotes) {
    totalRefunds += cn.totalRefund;
    const origBill = state.bills.find((b) => b.id === cn.billId);
    if (!origBill || origBill.paymentType === 'cash') {
      cashRefunds += cn.totalRefund;
    }
  }

  const debtPaymentsTotal = dayDebtPayments.reduce((s, p) => s + p.amount, 0);
  const netSales = totalSales - totalRefunds;
  const dailyGains = Math.round((netSales - cogs) * 100) / 100;
  const expectedCash = Math.round((cashSales + debtPaymentsTotal - cashRefunds) * 100) / 100;

  const openSupplierDebtAtClose = state.restockOrders
    .filter((o) => o.paymentStatus !== 'paid')
    .reduce((s, o) => s + Math.max(0, o.totalAmount - o.paidAmount), 0);

  return {
    dayKey,
    totalSales: Math.round(totalSales * 100) / 100,
    cashSales: Math.round(cashSales * 100) / 100,
    creditSales: Math.round(creditSales * 100) / 100,
    creditSalesCount,
    debtPaymentsTotal: Math.round(debtPaymentsTotal * 100) / 100,
    totalRefunds: Math.round(totalRefunds * 100) / 100,
    cogs: Math.round(cogs * 100) / 100,
    dailyGains,
    billCount: dayBills.length,
    expectedCash,
    openSupplierDebtAtClose: Math.round(openSupplierDebtAtClose * 100) / 100,
    isClosed: isDayLocked(dayKey),
  };
}

export function finalizeDailyClosing(
  countedCash: number,
  notes?: string,
  backupFilename?: string
): { ok: boolean; closing?: DailyClosing; backup?: BackupRecord } {
  const state = getPosState();
  const currentUser = state.users.find((u) => u.id === state.currentUserId);
  if (!currentUser || currentUser.role !== 'owner') return { ok: false };

  const dayKey = getDayKey();
  if (isDayLocked(dayKey)) return { ok: false };

  const metrics = computeDayClosingMetrics(dayKey);
  const now = new Date();
  const closing: DailyClosing = {
    id: uid('cls'),
    dayKey,
    closedAt: now.toISOString(),
    closedByUserId: currentUser.id,
    totalSales: metrics.totalSales,
    cashSales: metrics.cashSales,
    creditSales: metrics.creditSales,
    creditSalesCount: metrics.creditSalesCount,
    debtPaymentsTotal: metrics.debtPaymentsTotal,
    totalRefunds: metrics.totalRefunds,
    cogs: metrics.cogs,
    dailyGains: metrics.dailyGains,
    billCount: metrics.billCount,
    expectedCash: metrics.expectedCash,
    countedCash: Math.round(countedCash * 100) / 100,
    cashDifference: Math.round((countedCash - metrics.expectedCash) * 100) / 100,
    openSupplierDebtAtClose: metrics.openSupplierDebtAtClose,
    notes: notes?.trim(),
  };

  const prefix = sanitizeShopPrefix(state.shop?.name ?? 'KHAZNA');
  const filename = backupFilename || `${prefix}_Backup_${dayKey}.xlsx`;
  const snapshotState = { ...state, dailyClosings: [closing, ...state.dailyClosings] };
  const backup: BackupRecord = {
    id: uid('bkp'),
    dayKey,
    monthKey: getMonthKey(now),
    createdAt: now.toISOString(),
    type: 'auto_close',
    filename,
    summary: {
      bills: metrics.billCount,
      sales: metrics.totalSales,
      products: state.products.length,
    },
    snapshotJson: JSON.stringify({ ...snapshotState, backups: [] }),
  };

  commitState(
    {
      ...state,
      dailyClosings: [closing, ...state.dailyClosings],
      backups: [backup, ...state.backups],
    },
    true
  );

  return { ok: true, closing, backup };
}

export function saveManualBackupRecord(filename: string): BackupRecord {
  const state = getPosState();
  const now = new Date();
  const dayKey = getDayKey(now);
  const backup: BackupRecord = {
    id: uid('bkp'),
    dayKey,
    monthKey: getMonthKey(now),
    createdAt: now.toISOString(),
    type: 'manual',
    filename,
    summary: {
      bills: state.bills.length,
      sales: state.bills.reduce((s, b) => s + b.total, 0),
      products: state.products.length,
    },
    snapshotJson: JSON.stringify({ ...state, backups: [] }),
  };
  commitState({ ...state, backups: [backup, ...state.backups] }, true);
  return backup;
}

export function restoreFromBackupJson(jsonString: string): { ok: boolean; error?: string } {
  try {
    const parsed = JSON.parse(jsonString) as Partial<PosState>;
    if (!parsed.shop || !Array.isArray(parsed.users) || !Array.isArray(parsed.products)) {
      return { ok: false, error: 'Invalid backup format' };
    }
    const current = getPosState();
    const owner = parsed.users.find((u) => u.role === 'owner');
    commitState(
      {
        ...createEmptyState(),
        ...parsed,
        currentUserId: owner?.id ?? current.currentUserId,
        backups: current.backups,
      },
      true
    );
    return { ok: true };
  } catch {
    return { ok: false, error: 'Could not parse backup file' };
  }
}

// Owner Alerts: Low Stock, Out of Stock, Unpaid Supplier Invoices (>= 1 month), Unpaid Customer Credit (>= 1 month)
export function getOwnerAlerts(): OwnerAlert[] {
  const state = getPosState();
  const alerts: OwnerAlert[] = [];
  const defaultThreshold = state.shop?.lowStockThreshold ?? 5;
  const nowMs = Date.now();
  const monthMs = 30 * 24 * 60 * 60 * 1000;

  // Stock alerts
  for (const p of state.products) {
    const threshold = p.lowStockThreshold ?? defaultThreshold;
    if (p.quantity <= 0) {
      alerts.push({
        id: `stk_0_${p.id}`,
        type: 'out_of_stock',
        title: p.variantLabel ? `${p.name} (${p.variantLabel})` : p.name,
        description: `Stock: 0`,
        severity: 'critical',
        entityId: p.id,
      });
    } else if (p.quantity <= threshold) {
      alerts.push({
        id: `stk_low_${p.id}`,
        type: 'low_stock',
        title: p.variantLabel ? `${p.name} (${p.variantLabel})` : p.name,
        description: `Stock: ${p.quantity} / ${threshold}`,
        severity: 'warning',
        entityId: p.id,
      });
    }
  }

  // Supplier unpaid invoices >= 1 month (reminded monthly)
  for (const order of state.restockOrders) {
    if (order.paymentStatus === 'paid') continue;
    const elapsedMs = nowMs - new Date(order.billingDate).getTime();
    if (elapsedMs >= monthMs) {
      const months = Math.floor(elapsedMs / monthMs);
      const owed = Math.max(0, order.totalAmount - order.paidAmount);
      alerts.push({
        id: `sup_due_${order.id}_m${months}`,
        type: 'supplier_overdue',
        title: order.supplierName,
        description: `${owed} DA (${months} mois)`,
        severity: 'critical',
        monthsElapsed: months,
        entityId: order.id,
      });
    }
  }

  // Customer unpaid credit bills >= 1 month (where customer still owes balance)
  for (const cust of state.customers) {
    if (cust.balanceOwed <= 0) continue;
    const oldestCreditBill = state.bills
      .filter((b) => b.paymentType === 'credit' && b.customerId === cust.id && !b.isCancelled)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0];

    const refDate = oldestCreditBill ? oldestCreditBill.date : cust.createdAt;
    const elapsedMs = nowMs - new Date(refDate).getTime();
    if (elapsedMs >= monthMs) {
      const months = Math.floor(elapsedMs / monthMs);
      alerts.push({
        id: `cus_due_${cust.id}_m${months}`,
        type: 'customer_overdue',
        title: cust.name,
        description: `${cust.balanceOwed} DA (${months} mois)`,
        severity: 'warning',
        monthsElapsed: months,
        entityId: cust.id,
      });
    }
  }

  return alerts;
}
