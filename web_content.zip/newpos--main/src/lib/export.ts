import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { jsPDF } from 'jspdf';
import { Bill, CreditNote, PosState, ShopConfig } from '../types/pos';
import { formatDA } from './i18n';
import { getDayKey, getMonthKey, sanitizeShopPrefix } from './store';

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function buildWorkbookFromState(state: PosState, dayKeyFilter?: string): XLSX.WorkBook {
  const wb = XLSX.utils.book_new();

  const bills = dayKeyFilter ? state.bills.filter((b) => b.dayKey === dayKeyFilter) : state.bills;
  const creditNotes = dayKeyFilter
    ? state.creditNotes.filter((c) => c.dayKey === dayKeyFilter)
    : state.creditNotes;
  const debtPayments = dayKeyFilter
    ? state.customerDebtPayments.filter((p) => p.dayKey === dayKeyFilter)
    : state.customerDebtPayments;

  const billRows = bills.map((b) => ({
    BillNumber: b.billNumber,
    Date: b.date,
    Day: b.dayKey,
    Cashier: b.cashierName,
    PaymentType: b.paymentType,
    Customer: b.customerName ?? '',
    Total_DA: b.total,
    Cancelled: b.isCancelled ? 'YES' : 'NO',
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(billRows), 'Bills');

  const itemRows = bills.flatMap((b) =>
    b.items.map((it) => ({
      BillNumber: b.billNumber,
      Product: it.name,
      Barcode: it.barcode ?? '',
      Unit: it.unitType,
      Quantity: it.quantity,
      UnitPrice_DA: it.unitPrice,
      Total_DA: it.total,
    }))
  );
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(itemRows), 'BillItems');

  const productRows = state.products.map((p) => ({
    ID: p.id,
    Barcode: p.barcode,
    Name: p.name,
    Variant: p.variantLabel ?? '',
    Unit: p.unitType,
    PurchasePrice_DA: p.purchasePrice,
    SellingPrice_DA: p.sellingPrice,
    Quantity: p.quantity,
    CategoryID: p.categoryId,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(productRows), 'Stock');

  const cnRows = creditNotes.map((cn) => ({
    CreditNote: cn.creditNoteNumber,
    OriginalBill: cn.billNumber,
    Date: cn.date,
    TotalRefund_DA: cn.totalRefund,
    Full: cn.isFull ? 'YES' : 'NO',
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(cnRows), 'CreditNotes');

  const debtRows = debtPayments.map((dp) => ({
    Customer: dp.customerName,
    Amount_DA: dp.amount,
    Date: dp.date,
    Note: dp.note ?? '',
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(debtRows), 'DebtPayments');

  const closingRows = state.dailyClosings.map((c) => ({
    Day: c.dayKey,
    TotalSales_DA: c.totalSales,
    CashSales_DA: c.cashSales,
    CreditSales_DA: c.creditSales,
    DebtPayments_DA: c.debtPaymentsTotal,
    Refunds_DA: c.totalRefunds,
    DailyGains_DA: c.dailyGains,
    ExpectedCash_DA: c.expectedCash,
    CountedCash_DA: c.countedCash,
    Difference_DA: c.cashDifference,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(closingRows), 'DailyClosings');

  // Embedded full JSON snapshot sheet for lossless restore
  const jsonChunks = JSON.stringify({ ...state, backups: [] }).match(/.{1,30000}/g) ?? [];
  const snapshotRows = jsonChunks.map((chunk, idx) => ({ Part: idx + 1, Data: chunk }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(snapshotRows), '_KhaznaSnapshot');

  return wb;
}

export function exportDailyXlsx(state: PosState, dayKey?: string): string {
  const prefix = sanitizeShopPrefix(state.shop?.name ?? 'KHAZNA');
  const day = dayKey ?? getDayKey();
  const filename = `${prefix}_Backup_${day}.xlsx`;
  const wb = buildWorkbookFromState(state, dayKey);
  const arrayBuf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  triggerDownload(
    new Blob([arrayBuf], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    }),
    filename
  );
  return filename;
}

export async function exportMonthlyZipArchive(state: PosState, monthKey?: string): Promise<string> {
  const targetMonth = monthKey ?? getMonthKey();
  const prefix = sanitizeShopPrefix(state.shop?.name ?? 'KHAZNA');
  const zip = new JSZip();

  const monthBackups = state.backups.filter((b) => b.monthKey === targetMonth);
  if (monthBackups.length > 0) {
    for (const bkp of monthBackups) {
      try {
        const snapState = JSON.parse(bkp.snapshotJson) as PosState;
        const wb = buildWorkbookFromState(snapState, bkp.dayKey);
        const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        zip.file(bkp.filename, buf);
      } catch {
        zip.file(`${bkp.dayKey}.json`, bkp.snapshotJson);
      }
    }
  } else {
    const wb = buildWorkbookFromState(state);
    const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    zip.file(`${prefix}_Month_${targetMonth}.xlsx`, buf);
  }

  zip.file(`${prefix}_FullState_${targetMonth}.json`, JSON.stringify({ ...state, backups: [] }, null, 2));

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  const filename = `${prefix}_Archive_${targetMonth}.zip`;
  triggerDownload(zipBlob, filename);
  return filename;
}

export async function parseBackupFile(file: File): Promise<string | null> {
  const name = file.name.toLowerCase();
  if (name.endsWith('.json')) {
    return await file.text();
  }
  if (name.endsWith('.xlsx')) {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const snapSheet = wb.Sheets['_KhaznaSnapshot'];
    if (!snapSheet) return null;
    const rows = XLSX.utils.sheet_to_json<{ Part: number; Data: string }>(snapSheet);
    return rows
      .sort((a, b) => a.Part - b.Part)
      .map((r) => r.Data)
      .join('');
  }
  if (name.endsWith('.zip')) {
    const zip = await JSZip.loadAsync(file);
    const jsonEntry = Object.values(zip.files).find((f) => f.name.endsWith('.json') && !f.dir);
    if (jsonEntry) {
      return await jsonEntry.async('text');
    }
  }
  return null;
}

// PDF Receipt Generator (58mm thermal width roll format)
export function downloadBillPdf(
  bill: Bill,
  shop: ShopConfig,
  creditNotes: CreditNote[] = []
): void {
  const heightMm = Math.max(130, 85 + bill.items.length * 9 + creditNotes.length * 14);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [58, heightMm],
  });

  let y = 7;
  const centerX = 29;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(shop.name.slice(0, 26), centerX, y, { align: 'center' });
  y += 4.5;

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  if (shop.address) {
    doc.text(shop.address.slice(0, 34), centerX, y, { align: 'center' });
    y += 3.8;
  }
  if (shop.phone) {
    doc.text(`Tel: ${shop.phone}`, centerX, y, { align: 'center' });
    y += 3.8;
  }

  doc.line(3, y, 55, y);
  y += 4;

  doc.setFontSize(7.5);
  doc.text(`N°: ${bill.billNumber}`, 3, y);
  y += 3.8;
  doc.text(`Date: ${new Date(bill.date).toLocaleString('fr-FR')}`, 3, y);
  y += 3.8;
  doc.text(`Caissier: ${bill.cashierName}`, 3, y);
  y += 3.8;
  if (bill.customerName) {
    doc.text(`Client: ${bill.customerName} (${bill.paymentType.toUpperCase()})`, 3, y);
    y += 3.8;
  }

  doc.line(3, y, 55, y);
  y += 4;

  for (const item of bill.items) {
    doc.setFont('helvetica', 'bold');
    doc.text(item.name.slice(0, 30), 3, y);
    y += 3.5;
    doc.setFont('helvetica', 'normal');
    const qtyStr =
      item.unitType === 'KG'
        ? `${item.quantity} kg`
        : item.unitType === 'GRAM'
          ? `${item.quantity} g`
          : `x${item.quantity}`;
    doc.text(`${qtyStr} x ${formatDA(item.unitPrice)}`, 3, y);
    doc.text(formatDA(item.total), 55, y, { align: 'right' });
    y += 4.5;
  }

  doc.line(3, y, 55, y);
  y += 5;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL:', 3, y);
  doc.text(formatDA(bill.total), 55, y, { align: 'right' });
  y += 5;

  if (creditNotes.length > 0) {
    doc.setFontSize(7.5);
    for (const cn of creditNotes) {
      doc.text(`${cn.creditNoteNumber}: -${formatDA(cn.totalRefund)}`, 3, y);
      y += 4;
    }
  }

  y += 2;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('Merci de votre visite', centerX, y, { align: 'center' });

  doc.save(`${bill.billNumber}.pdf`);
}

// ESC/POS 58mm Thermal Printer Byte Builder + Web Bluetooth Classic/GATT sender
export function buildEscPosReceiptBytes(bill: Bill, shop: ShopConfig): Uint8Array {
  const encoder = new TextEncoder();
  const chunks: number[] = [
    0x1b, 0x40, // ESC @ Init
    0x1b, 0x61, 0x01, // Center
    0x1b, 0x45, 0x01, // Bold ON
  ];

  const pushText = (txt: string) => {
    chunks.push(...Array.from(encoder.encode(txt + '\n')));
  };

  pushText(shop.name);
  chunks.push(0x1b, 0x45, 0x00); // Bold OFF
  if (shop.address) pushText(shop.address);
  if (shop.phone) pushText(`Tel: ${shop.phone}`);
  pushText('--------------------------------');
  chunks.push(0x1b, 0x61, 0x00); // Left
  pushText(`Bill: ${bill.billNumber}`);
  pushText(`Date: ${new Date(bill.date).toLocaleString('fr-FR')}`);
  pushText(`Cashier: ${bill.cashierName}`);
  pushText('--------------------------------');
  for (const item of bill.items) {
    pushText(`${item.name}`);
    pushText(`  ${item.quantity} x ${item.unitPrice} = ${item.total} DA`);
  }
  pushText('--------------------------------');
  chunks.push(0x1b, 0x45, 0x01);
  pushText(`TOTAL: ${bill.total} DA`);
  chunks.push(0x1b, 0x45, 0x00);
  chunks.push(0x1b, 0x61, 0x01);
  pushText('Merci / Shukran');
  chunks.push(0x1d, 0x56, 0x41, 0x10); // Cut paper

  return new Uint8Array(chunks);
}

export async function sendToBluetoothPrinter(
  bill: Bill,
  shop: ShopConfig
): Promise<{ ok: boolean; message: string }> {
  const nav = navigator as Navigator & {
    bluetooth?: {
      requestDevice: (opts: { acceptAllDevices?: boolean; optionalServices?: string[] }) => Promise<{
        name?: string;
        gatt?: {
          connect: () => Promise<{
            getPrimaryServices: () => Promise<
              Array<{
                getCharacteristics: () => Promise<
                  Array<{
                    properties: { write?: boolean; writeWithoutResponse?: boolean };
                    writeValue: (val: Uint8Array) => Promise<void>;
                  }>
                >;
              }>
            >;
          }>;
        };
      }>;
    };
  };

  if (!nav.bluetooth) {
    window.print();
    return { ok: true, message: 'Dialogue d’impression système ouvert (WebBluetooth non disponible).' };
  }

  try {
    const device = await nav.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb'],
    });
    if (!device.gatt) {
      return { ok: false, message: 'GATT non pris en charge par cet appareil.' };
    }
    const server = await device.gatt.connect();
    const services = await server.getPrimaryServices();
    const bytes = buildEscPosReceiptBytes(bill, shop);
    for (const service of services) {
      const chars = await service.getCharacteristics();
      const writable = chars.find((c) => c.properties.write || c.properties.writeWithoutResponse);
      if (writable) {
        const chunkSize = 180;
        for (let i = 0; i < bytes.length; i += chunkSize) {
          await writable.writeValue(bytes.slice(i, i + chunkSize));
        }
        return { ok: true, message: `Imprimé sur ${device.name || 'Imprimante 58mm'}` };
      }
    }
    return { ok: false, message: 'Aucune caractéristique d’écriture ESC/POS trouvée.' };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : 'Impression Bluetooth annulée.',
    };
  }
}
