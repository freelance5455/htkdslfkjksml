import React, { useState } from 'react';
import {
  Archive,
  Bluetooth,
  FileSpreadsheet,
  Fingerprint,
  Moon,
  Plus,
  Sun,
  Monitor,
  Trash2,
  Upload,
  UserCheck,
  AlertOctagon,
} from 'lucide-react';
import { Language, PosState, ThemeMode, UserAccount } from '../types/pos';
import { t } from '../lib/i18n';
import {
  deleteAllAccountData,
  getMonthKey,
  restoreFromBackupJson,
  saveManualBackupRecord,
  setAppLanguage,
  updateOwnerBiometric,
  updateShopSettings,
  upsertCashierAccount,
} from '../lib/store';
import { exportDailyXlsx, exportMonthlyZipArchive, parseBackupFile } from '../lib/export';
import { useTheme } from '../components/ThemeProvider';
import { ModalDrawer } from '../components/ui/ModalDrawer';

interface SettingsScreenProps {
  state: PosState;
}

export function SettingsScreen({ state }: SettingsScreenProps) {
  const lang = state.language;
  const shop = state.shop!;
  const owner = state.users.find((u) => u.role === 'owner');
  const cashiers = state.users.filter((u) => u.role === 'cashier');
  const { theme, setTheme } = useTheme();

  // Shop edit form
  const [shopName, setShopName] = useState(shop.name);
  const [ownerName, setOwnerName] = useState(shop.ownerName);
  const [address, setAddress] = useState(shop.address);
  const [phone, setPhone] = useState(shop.phone);
  const [threshold, setThreshold] = useState(String(shop.lowStockThreshold));
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  // Cashier modal
  const [cashierModalOpen, setCashierModalOpen] = useState(false);
  const [editingCashier, setEditingCashier] = useState<UserAccount | null>(null);
  const [cashierName, setCashierName] = useState('');
  const [cashierPin, setCashierPin] = useState('');
  const [cashierActive, setCashierActive] = useState(true);

  // Restore backup state
  const [pendingRestoreJson, setPendingRestoreJson] = useState<string | null>(null);
  const [backupNotice, setBackupNotice] = useState<string | null>(null);

  // Delete Account modal with PIN re-entry
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deletePin, setDeletePin] = useState('');
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const handleSaveShopInfo = (e: React.FormEvent) => {
    e.preventDefault();
    updateShopSettings({
      name: shopName.trim() || shop.name,
      ownerName: ownerName.trim() || shop.ownerName,
      address: address.trim(),
      phone: phone.trim(),
      lowStockThreshold: Math.max(1, parseInt(threshold, 10) || 5),
    });
    setSavedNotice(t(lang, 'save'));
    setTimeout(() => setSavedNotice(null), 2000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, 160 / Math.max(img.width, img.height));
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          updateShopSettings({ logoDataUrl: canvas.toDataURL('image/png') });
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handlePairBluetoothPrinter = async () => {
    const nav = navigator as Navigator & {
      bluetooth?: {
        requestDevice: (opts: { acceptAllDevices?: boolean; optionalServices?: string[] }) => Promise<{
          id?: string;
          name?: string;
        }>;
      };
    };
    if (!nav.bluetooth) {
      updateShopSettings({ bluetoothPrinterName: '58mm Thermal (Système)' });
      return;
    }
    try {
      const device = await nav.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb'],
      });
      updateShopSettings({
        bluetoothPrinterName: device.name || 'Imprimante 58mm',
        bluetoothPrinterId: device.id,
      });
    } catch {
      // User cancelled
    }
  };

  const handleFileRestoreSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const json = await parseBackupFile(file);
    if (!json) {
      setBackupNotice('Format de fichier non reconnu.');
      return;
    }
    setPendingRestoreJson(json);
    e.target.value = '';
  };

  const handleConfirmDeleteAccount = (e: React.FormEvent) => {
    e.preventDefault();
    setDeleteError(null);
    if (!deleteAllAccountData(deletePin)) {
      setDeleteError(t(lang, 'wrongPin'));
      return;
    }
    setDeleteModalOpen(false);
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <h1 className="text-xl font-bold">{t(lang, 'settingsTitle')}</h1>

      {/* Appearance & Language */}
      <section className="p-5 rounded-3xl bg-card border border-border space-y-4">
        <h2 className="text-sm font-bold text-muted-foreground">
          {t(lang, 'appearanceSection')}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'themeLabel')}
            </div>
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-muted border border-border">
              {(
                [
                  { mode: 'light', label: t(lang, 'themeLight'), icon: Sun },
                  { mode: 'dark', label: t(lang, 'themeDark'), icon: Moon },
                  { mode: 'system', label: t(lang, 'themeSystem'), icon: Monitor },
                ] as const
              ).map(({ mode, label, icon: Icon }) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setTheme(mode as ThemeMode)}
                  className={`min-h-[44px] sm:min-h-[38px] px-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    theme === mode
                      ? 'bg-card text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'languageLabel')}
            </div>
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-muted border border-border">
              {(
                [
                  { code: 'fr', label: 'Français' },
                  { code: 'ar', label: 'العربية' },
                  { code: 'en', label: 'English' },
                ] as const
              ).map((item) => (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => setAppLanguage(item.code as Language)}
                  className={`min-h-[44px] sm:min-h-[38px] px-2 rounded-lg text-xs font-semibold transition-colors ${
                    lang === item.code
                      ? 'bg-card text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Shop Info & Threshold */}
      <form
        onSubmit={handleSaveShopInfo}
        className="p-5 rounded-3xl bg-card border border-border space-y-4"
      >
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-bold text-muted-foreground">
            {t(lang, 'shopInfoSection')}
          </h2>
          {savedNotice && (
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              ✓ {savedNotice}
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'shopName')}
            </label>
            <input
              type="text"
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'ownerFullName')}
            </label>
            <input
              type="text"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'address')}
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'phone')}
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'lowStockDefault')}
            </label>
            <input
              type="number"
              min="1"
              value={threshold}
              onChange={(e) => setThreshold(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono"
            />
          </div>

          <div className="flex items-end gap-2">
            <label className="press flex-1 min-h-[44px] px-4 rounded-xl border border-border bg-secondary text-secondary-foreground text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4" />
              <span>{t(lang, 'uploadLogo')}</span>
              <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
            </label>
            {shop.logoDataUrl && (
              <button
                type="button"
                onClick={() => updateShopSettings({ logoDataUrl: undefined })}
                className="min-h-[44px] px-3 rounded-xl border border-border text-xs font-semibold text-destructive"
              >
                {t(lang, 'removeLogo')}
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-border">
          <button
            type="button"
            onClick={() => updateOwnerBiometric(!(owner?.biometricEnabled ?? true))}
            className="min-h-[44px] px-3.5 rounded-xl border border-border bg-background text-xs font-semibold flex items-center gap-2"
          >
            <Fingerprint
              className={`w-4 h-4 ${
                owner?.biometricEnabled ? 'text-primary' : 'text-muted-foreground'
              }`}
            />
            <span>
              {t(lang, 'biometricUnlock')}: {owner?.biometricEnabled ? 'ON' : 'OFF'}
            </span>
          </button>

          <button
            type="submit"
            className="press min-h-[44px] px-6 rounded-xl bg-primary text-primary-foreground text-sm font-semibold"
          >
            {t(lang, 'save')}
          </button>
        </div>
      </form>

      {/* Cashier Accounts */}
      <section className="p-5 rounded-3xl bg-card border border-border space-y-3.5">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-bold text-muted-foreground">{t(lang, 'usersSection')}</h2>
          <button
            type="button"
            onClick={() => {
              setEditingCashier(null);
              setCashierName('');
              setCashierPin('');
              setCashierActive(true);
              setCashierModalOpen(true);
            }}
            className="press min-h-[44px] sm:min-h-[38px] px-3.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>{t(lang, 'addCashier')}</span>
          </button>
        </div>

        <div className="space-y-2">
          {cashiers.map((c) => (
            <div
              key={c.id}
              className="p-3 rounded-2xl border border-border bg-background flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <UserCheck
                  className={`w-4 h-4 shrink-0 ${
                    c.active ? 'text-emerald-500' : 'text-muted-foreground'
                  }`}
                />
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{c.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {c.active ? 'Actif' : 'Désactivé'} · PIN: ••••
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditingCashier(c);
                  setCashierName(c.name);
                  setCashierPin(c.pin);
                  setCashierActive(c.active);
                  setCashierModalOpen(true);
                }}
                className="min-h-[44px] sm:min-h-[36px] px-3 rounded-xl border border-border text-xs font-semibold hover:bg-muted"
              >
                {t(lang, 'edit')}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Bluetooth 58mm Printer */}
      <section className="p-5 rounded-3xl bg-card border border-border flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-muted-foreground">{t(lang, 'printerSection')}</h2>
          <p className="text-xs text-foreground mt-1 font-mono">
            {shop.bluetoothPrinterName || 'Aucune imprimante appairée'}
          </p>
        </div>
        <button
          type="button"
          onClick={handlePairBluetoothPrinter}
          className="press min-h-[44px] px-4 rounded-xl border border-border bg-secondary text-secondary-foreground text-xs font-semibold flex items-center gap-2"
        >
          <Bluetooth className="w-4 h-4" />
          <span>{t(lang, 'pairPrinterBtn')}</span>
        </button>
      </section>

      {/* Backups & Restore */}
      <section className="p-5 rounded-3xl bg-card border border-border space-y-3.5">
        <h2 className="text-sm font-bold text-muted-foreground">{t(lang, 'backupsSection')}</h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => {
              const fn = exportDailyXlsx(state);
              saveManualBackupRecord(fn);
              setBackupNotice(`Exporté: ${fn}`);
            }}
            className="press min-h-[44px] px-3.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center justify-center gap-2"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{t(lang, 'exportXlsxNow')}</span>
          </button>

          <button
            type="button"
            onClick={async () => {
              const fn = await exportMonthlyZipArchive(state, getMonthKey());
              setBackupNotice(`Archive créée: ${fn}`);
            }}
            className="press min-h-[44px] px-3.5 rounded-xl border border-border bg-secondary text-secondary-foreground text-xs font-semibold flex items-center justify-center gap-2"
          >
            <Archive className="w-4 h-4" />
            <span>{t(lang, 'exportMonthlyZip')}</span>
          </button>

          <label className="press min-h-[44px] px-3.5 rounded-xl border border-border bg-card text-foreground text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer hover:bg-muted">
            <Upload className="w-4 h-4" />
            <span>{t(lang, 'restoreBackupBtn')}</span>
            <input
              type="file"
              accept=".xlsx,.json,.zip"
              onChange={handleFileRestoreSelect}
              className="hidden"
            />
          </label>
        </div>

        {backupNotice && (
          <p className="text-xs font-semibold text-primary">{backupNotice}</p>
        )}

        {state.backups.length > 0 && (
          <div className="space-y-1.5 pt-2 border-t border-border max-h-40 overflow-y-auto scroll-pane">
            {state.backups.slice(0, 10).map((b) => (
              <div key={b.id} className="flex items-center justify-between text-xs py-1">
                <span className="font-mono truncate">{b.filename}</span>
                <span className="text-muted-foreground shrink-0">{b.dayKey}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Danger Zone: Delete Account with PIN re-entry */}
      <section className="p-5 rounded-3xl bg-destructive/5 border border-destructive/25 space-y-3">
        <div className="flex items-start gap-3">
          <AlertOctagon className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h2 className="text-sm font-bold text-destructive">{t(lang, 'dangerZone')}</h2>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {t(lang, 'deleteAccountDesc')}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            setDeletePin('');
            setDeleteError(null);
            setDeleteModalOpen(true);
          }}
          className="press min-h-[44px] px-4 rounded-xl bg-destructive text-destructive-foreground text-xs font-semibold flex items-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          <span>{t(lang, 'deleteAccountBtn')}</span>
        </button>
      </section>

      {/* Cashier Add/Edit Modal */}
      <ModalDrawer
        open={cashierModalOpen}
        onClose={() => setCashierModalOpen(false)}
        title={editingCashier ? t(lang, 'edit') : t(lang, 'addCashier')}
        maxWidthClass="sm:max-w-sm"
      >
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!cashierName.trim() || !/^\d{4,6}$/.test(cashierPin.trim())) return;
            upsertCashierAccount({
              id: editingCashier?.id,
              name: cashierName,
              pin: cashierPin,
              active: cashierActive,
            });
            setCashierModalOpen(false);
          }}
          className="space-y-4"
        >
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'cashierName')} *
            </label>
            <input
              type="text"
              required
              value={cashierName}
              onChange={(e) => setCashierName(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              PIN (4–6) *
            </label>
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              required
              value={cashierPin}
              onChange={(e) => setCashierPin(e.target.value.replace(/\D/g, ''))}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono"
            />
          </div>
          <button
            type="button"
            onClick={() => setCashierActive((v) => !v)}
            className="w-full min-h-[44px] px-3.5 rounded-xl border border-border flex items-center justify-between text-xs font-semibold"
          >
            <span>{t(lang, 'activeFlag')}</span>
            <span className={cashierActive ? 'text-primary' : 'text-muted-foreground'}>
              {cashierActive ? 'ON' : 'OFF'}
            </span>
          </button>
          <button
            type="submit"
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
          >
            {t(lang, 'save')}
          </button>
        </form>
      </ModalDrawer>

      {/* Restore Confirmation Modal */}
      <ModalDrawer
        open={Boolean(pendingRestoreJson)}
        onClose={() => setPendingRestoreJson(null)}
        title={t(lang, 'restoreBackupBtn')}
        maxWidthClass="sm:max-w-sm"
      >
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">{t(lang, 'restoreConfirmMsg')}</p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setPendingRestoreJson(null)}
              className="flex-1 min-h-[44px] rounded-xl border border-border text-sm font-semibold"
            >
              {t(lang, 'cancel')}
            </button>
            <button
              type="button"
              onClick={() => {
                if (pendingRestoreJson) {
                  const res = restoreFromBackupJson(pendingRestoreJson);
                  setBackupNotice(res.ok ? 'Restauration réussie !' : res.error || 'Erreur');
                }
                setPendingRestoreJson(null);
              }}
              className="press flex-1 min-h-[44px] rounded-xl bg-primary text-primary-foreground text-sm font-semibold"
            >
              {t(lang, 'confirm')}
            </button>
          </div>
        </div>
      </ModalDrawer>

      {/* Delete Account PIN Verification Modal */}
      <ModalDrawer
        open={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        title={t(lang, 'deleteAccountBtn')}
        maxWidthClass="sm:max-w-sm"
      >
        <form onSubmit={handleConfirmDeleteAccount} className="space-y-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            {t(lang, 'deleteAccountDesc')}
          </p>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-foreground">
              {t(lang, 'confirmPinPrompt')}
            </label>
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              required
              autoFocus
              value={deletePin}
              onChange={(e) => setDeletePin(e.target.value.replace(/\D/g, ''))}
              placeholder="••••"
              className="w-full min-h-[48px] px-4 rounded-xl border border-input bg-background text-lg font-mono tracking-widest"
            />
          </div>
          {deleteError && <p className="text-xs font-semibold text-destructive">{deleteError}</p>}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setDeleteModalOpen(false)}
              className="flex-1 min-h-[44px] rounded-xl border border-border text-sm font-semibold"
            >
              {t(lang, 'cancel')}
            </button>
            <button
              type="submit"
              className="press flex-1 min-h-[44px] rounded-xl bg-destructive text-destructive-foreground text-sm font-semibold"
            >
              {t(lang, 'confirmDeleteFinal')}
            </button>
          </div>
        </form>
      </ModalDrawer>
    </div>
  );
}
