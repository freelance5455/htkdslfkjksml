import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, FileSpreadsheet, Lock } from 'lucide-react';
import { PosState } from '../types/pos';
import { formatDA, t } from '../lib/i18n';
import {
  computeDayClosingMetrics,
  finalizeDailyClosing,
  getDayKey,
  getPosState,
} from '../lib/store';
import { exportDailyXlsx } from '../lib/export';

interface ClosingScreenProps {
  state: PosState;
}

export function ClosingScreen({ state }: ClosingScreenProps) {
  const lang = state.language;
  const todayKey = getDayKey();
  const metrics = computeDayClosingMetrics(todayKey);

  const [countedCash, setCountedCash] = useState(String(metrics.expectedCash));
  const [notes, setNotes] = useState('');
  const [closedMessage, setClosedMessage] = useState<string | null>(null);

  const parsedCounted = parseFloat(countedCash) || 0;
  const difference = Math.round((parsedCounted - metrics.expectedCash) * 100) / 100;

  const handleCloseDay = (e: React.FormEvent) => {
    e.preventDefault();
    const filename = exportDailyXlsx(getPosState(), todayKey);
    const res = finalizeDailyClosing(parsedCounted, notes, filename);
    if (res.ok) {
      setClosedMessage(`${t(lang, 'dayAlreadyClosed')} · ${filename}`);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">{t(lang, 'closingTitle')}</h1>
          <p className="text-xs text-muted-foreground font-mono">{todayKey}</p>
        </div>
        {metrics.isClosed && (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            <Lock className="w-4 h-4" />
            <span>{t(lang, 'dayAlreadyClosed')}</span>
          </div>
        )}
      </div>

      {/* Warning if open unpaid supplier invoices exist */}
      {metrics.openSupplierDebtAtClose > 0 && (
        <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-800 dark:text-amber-200 flex items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-2 font-medium">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <span>{t(lang, 'openSupplierWarning')}</span>
          </div>
          <span className="font-mono font-bold shrink-0">
            {formatDA(metrics.openSupplierDebtAtClose, lang)}
          </span>
        </div>
      )}

      {/* Daily Financial Summary (Only shown in Closing per spec!) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-card border border-border space-y-1">
          <div className="text-xs text-muted-foreground">{t(lang, 'totalSalesDay')}</div>
          <div className="text-xl font-bold font-mono tabular-nums text-primary">
            {formatDA(metrics.totalSales, lang)}
          </div>
          <div className="text-xs text-muted-foreground tabular-nums">
            {metrics.billCount} {t(lang, 'billsCountLabel')}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-card border border-border space-y-1">
          <div className="text-xs text-muted-foreground">{t(lang, 'debtPaymentsCollected')}</div>
          <div className="text-xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
            {formatDA(metrics.debtPaymentsTotal, lang)}
          </div>
          <div className="text-xs text-muted-foreground">Payement dettes</div>
        </div>

        <div className="p-4 rounded-2xl bg-card border border-border space-y-1">
          <div className="text-xs text-muted-foreground">{t(lang, 'dailyGainsLabel')}</div>
          <div className="text-xl font-bold font-mono tabular-nums">
            {formatDA(metrics.dailyGains, lang)}
          </div>
          <div className="text-xs text-muted-foreground tabular-nums">
            COGS: {formatDA(metrics.cogs, lang)}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-card border border-border space-y-1">
          <div className="text-xs text-muted-foreground">{t(lang, 'totalRefundsLabel')}</div>
          <div className="text-xl font-bold font-mono tabular-nums text-destructive">
            {formatDA(metrics.totalRefunds, lang)}
          </div>
          <div className="text-xs text-muted-foreground tabular-nums">
            {t(lang, 'creditBillsCountLabel')}: {metrics.creditSalesCount} (
            {formatDA(metrics.creditSales, lang)})
          </div>
        </div>
      </div>

      {/* Cash Reconciliation Form */}
      {!metrics.isClosed && (
        <form
          onSubmit={handleCloseDay}
          className="p-5 rounded-3xl bg-card border border-border space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
            <div>
              <div className="text-xs text-muted-foreground">{t(lang, 'expectedCashLabel')}</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-primary mt-0.5">
                {formatDA(metrics.expectedCash, lang)}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5 tabular-nums">
                {formatDA(metrics.cashSales, lang)} + {formatDA(metrics.debtPaymentsTotal, lang)}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'countedCashLabel')}
              </label>
              <input
                type="number"
                step="any"
                required
                value={countedCash}
                onChange={(e) => setCountedCash(e.target.value)}
                className="w-full min-h-[48px] px-4 rounded-xl border border-input bg-background text-lg font-mono font-bold tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="sm:text-end">
              <div className="text-xs text-muted-foreground">{t(lang, 'cashDifferenceLabel')}</div>
              <div
                className={`text-2xl font-bold font-mono tabular-nums mt-0.5 ${
                  difference === 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : difference > 0
                      ? 'text-primary'
                      : 'text-destructive'
                }`}
              >
                {difference > 0 ? '+' : ''}
                {formatDA(difference, lang)}
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'notesLabel')}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>

          <button
            type="submit"
            className="press w-full min-h-[48px] px-5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2"
          >
            <FileSpreadsheet className="w-5 h-5" />
            <span>{t(lang, 'closeDayBtn')}</span>
          </button>
        </form>
      )}

      {closedMessage && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>{closedMessage}</span>
        </div>
      )}

      {/* Past Closings History */}
      {state.dailyClosings.length > 0 && (
        <div className="space-y-2.5">
          <h2 className="text-sm font-bold text-muted-foreground">
            {t(lang, 'pastClosingsTitle')}
          </h2>
          <div className="space-y-2">
            {state.dailyClosings.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-card border border-border flex flex-wrap items-center justify-between gap-3 text-sm"
              >
                <div>
                  <div className="font-mono font-bold">{c.dayKey}</div>
                  <div className="text-xs text-muted-foreground tabular-nums">
                    {c.billCount} factures · Dettes: {formatDA(c.debtPaymentsTotal, lang)} · Gains:{' '}
                    {formatDA(c.dailyGains, lang)}
                  </div>
                </div>
                <div className="text-end font-mono tabular-nums">
                  <div className="font-bold text-primary">{formatDA(c.totalSales, lang)}</div>
                  <div className="text-xs text-muted-foreground">
                    Écart: {c.cashDifference > 0 ? '+' : ''}
                    {formatDA(c.cashDifference, lang)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
