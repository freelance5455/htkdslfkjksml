import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Banknote,
  FolderOpen,
  Lock,
  Minus,
  Plus,
  QrCode,
  Scale,
  Search,
  ShoppingBag,
  Trash2,
  UserCheck,
  Zap,
} from 'lucide-react';
import { Bill, BillLineItem, PosState, Product, UserAccount } from '../types/pos';
import { formatDA, t } from '../lib/i18n';
import { createSaleBill, getDayKey, isDayLocked, uid } from '../lib/store';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';
import { ModalDrawer } from '../components/ui/ModalDrawer';
import { SelectSheet } from '../components/ui/SelectSheet';
import { ReceiptModal } from '../components/ReceiptModal';

interface PosScreenProps {
  state: PosState;
  currentUser: UserAccount;
  selectedCategoryId: string | null;
  onSelectCategory: (catId: string | null) => void;
}

export function PosScreen({
  state,
  currentUser,
  selectedCategoryId,
  onSelectCategory,
}: PosScreenProps) {
  const lang = state.language;
  const isOwner = currentUser.role === 'owner';
  const todayLocked = isDayLocked(getDayKey());

  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<BillLineItem[]>([]);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scanNotice, setScanNotice] = useState<string | null>(null);

  // Modals
  const [otherModalOpen, setOtherModalOpen] = useState(false);
  const [otherPrice, setOtherPrice] = useState('');

  const [weighedProduct, setWeighedProduct] = useState<Product | null>(null);
  const [weightInput, setWeightInput] = useState('');
  const [weighedPriceOverride, setWeighedPriceOverride] = useState('');

  const [mobileCartOpen, setMobileCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [paymentType, setPaymentType] = useState<'cash' | 'credit'>('cash');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [cashReceived, setCashReceived] = useState('');
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  const [lastCreatedBill, setLastCreatedBill] = useState<Bill | null>(null);

  const weighedProducts = useMemo(
    () => state.products.filter((p) => p.unitType === 'KG' || p.unitType === 'GRAM'),
    [state.products]
  );

  const categoryCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const p of state.products) {
      map.set(p.categoryId, (map.get(p.categoryId) ?? 0) + 1);
    }
    return map;
  }, [state.products]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (q) {
      return state.products.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.variantLabel && p.variantLabel.toLowerCase().includes(q)) ||
          (p.barcode && p.barcode.toLowerCase().includes(q))
      );
    }
    if (selectedCategoryId) {
      if (selectedCategoryId === '__ALL__') return state.products;
      return state.products.filter((p) => p.categoryId === selectedCategoryId);
    }
    return [];
  }, [state.products, search, selectedCategoryId]);

  const cartTotal = useMemo(
    () => Math.round(cart.reduce((s, it) => s + it.total, 0) * 100) / 100,
    [cart]
  );

  const cartCount = useMemo(() => cart.length, [cart]);

  const addUnitProductToCart = (product: Product) => {
    if (todayLocked) return;
    const displayName = product.variantLabel
      ? `${product.name} (${product.variantLabel})`
      : product.name;

    setCart((prev) => {
      const idx = prev.findIndex((it) => !it.isOther && it.productId === product.id);
      if (idx >= 0) {
        return prev.map((it, i) => {
          if (i !== idx) return it;
          const nextQty = it.quantity + 1;
          return {
            ...it,
            quantity: nextQty,
            total: Math.round(nextQty * it.unitPrice * 100) / 100,
          };
        });
      }
      return [
        ...prev,
        {
          id: uid('li'),
          productId: product.id,
          name: displayName,
          barcode: product.barcode,
          unitType: product.unitType,
          quantity: 1,
          purchasePrice: product.purchasePrice,
          unitPrice: product.sellingPrice,
          total: product.sellingPrice,
        },
      ];
    });
  };

  const handleProductTap = (product: Product) => {
    if (todayLocked) return;
    if (product.unitType === 'KG' || product.unitType === 'GRAM') {
      setWeighedProduct(product);
      setWeightInput('');
      setWeighedPriceOverride('');
    } else {
      addUnitProductToCart(product);
    }
  };

  const handleBarcodeDetected = (code: string) => {
    const found = state.products.find((p) => p.barcode && p.barcode === code);
    if (found) {
      handleProductTap(found);
      setScanNotice(`+ ${found.name}`);
      setTimeout(() => setScanNotice(null), 2000);
    } else {
      setSearch(code);
      setScanNotice(`${code} — ${t(lang, 'noProductsFound')}`);
      setTimeout(() => setScanNotice(null), 3000);
    }
  };

  const handleAddOtherItem = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseFloat(otherPrice);
    if (!Number.isFinite(price) || price <= 0) return;
    setCart((prev) => [
      ...prev,
      {
        id: uid('li'),
        name: 'Autre',
        unitType: 'OTHER',
        quantity: 1,
        purchasePrice: 0,
        unitPrice: Math.round(price * 100) / 100,
        total: Math.round(price * 100) / 100,
        isOther: true,
      },
    ]);
    setOtherPrice('');
    setOtherModalOpen(false);
  };

  const handleAddWeighedItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!weighedProduct) return;
    let qty = parseFloat(weightInput);
    let total = parseFloat(weighedPriceOverride);

    if (Number.isFinite(total) && total > 0 && (!Number.isFinite(qty) || qty <= 0)) {
      qty = Math.round((total / weighedProduct.sellingPrice) * 1000) / 1000;
    } else if (Number.isFinite(qty) && qty > 0 && (!Number.isFinite(total) || total <= 0)) {
      total = Math.round(qty * weighedProduct.sellingPrice * 100) / 100;
    }

    if (!Number.isFinite(qty) || qty <= 0 || !Number.isFinite(total) || total <= 0) return;

    setCart((prev) => [
      ...prev,
      {
        id: uid('li'),
        productId: weighedProduct.id,
        name: weighedProduct.name,
        unitType: weighedProduct.unitType,
        quantity: qty,
        purchasePrice: weighedProduct.purchasePrice,
        unitPrice: weighedProduct.sellingPrice,
        total: Math.round(total * 100) / 100,
      },
    ]);
    setWeighedProduct(null);
  };

  const updateCartQty = (lineId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((it) => {
          if (it.id !== lineId) return it;
          const step = it.unitType === 'KG' ? 0.25 : it.unitType === 'GRAM' ? 50 : 1;
          const nextQty = Math.round((it.quantity + delta * step) * 1000) / 1000;
          if (nextQty <= 0) return null;
          return {
            ...it,
            quantity: nextQty,
            total: Math.round(nextQty * it.unitPrice * 100) / 100,
          };
        })
        .filter((x): x is BillLineItem => x !== null)
    );
  };

  const openCheckout = (type: 'cash' | 'credit') => {
    if (cart.length === 0 || todayLocked) return;
    setPaymentType(type);
    setCashReceived(String(cartTotal));
    setSelectedCustomerId(state.customers[0]?.id ?? '');
    setCheckoutError(null);
    setCheckoutOpen(true);
  };

  const handleConfirmSale = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutError(null);
    const res = createSaleBill({
      items: cart,
      paymentType,
      customerId: paymentType === 'credit' ? selectedCustomerId : undefined,
    });
    if (!res.ok || !res.bill) {
      setCheckoutError(res.error || 'Error');
      return;
    }
    setCart([]);
    setCheckoutOpen(false);
    setMobileCartOpen(false);
    setLastCreatedBill(res.bill);
  };

  const activeCategoryName =
    selectedCategoryId === '__ALL__'
      ? t(lang, 'allCategories')
      : state.categories.find((c) => c.id === selectedCategoryId)?.name;

  const CartContent = (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-border">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-5 h-5 text-primary" />
          <h2 className="text-base font-bold">{t(lang, 'cartTitle')}</h2>
          <span className="text-xs text-muted-foreground tabular-nums">({cartCount})</span>
        </div>
        {cart.length > 0 && (
          <button
            type="button"
            onClick={() => setCart([])}
            className="min-h-[44px] sm:min-h-[34px] px-3 rounded-xl text-xs font-semibold text-destructive hover:bg-destructive/10 transition-colors"
          >
            {t(lang, 'clearCart')}
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto scroll-pane py-3 space-y-2">
        {cart.length === 0 ? (
          <div className="py-12 text-center text-sm text-muted-foreground">
            {t(lang, 'cartEmpty')}
          </div>
        ) : (
          cart.map((item) => (
            <div
              key={item.id}
              className="p-3 rounded-2xl bg-muted/40 border border-border flex items-center justify-between gap-2"
            >
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold truncate">{item.name}</div>
                <div className="text-xs text-muted-foreground tabular-nums">
                  {formatDA(item.unitPrice, lang)}{' '}
                  {item.unitType === 'KG' ? '/kg' : item.unitType === 'GRAM' ? '/g' : ''}
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {!item.isOther && (
                  <>
                    <button
                      type="button"
                      onClick={() => updateCartQty(item.id, -1)}
                      aria-label="Decrease quantity"
                      className="press min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl border border-border bg-card flex items-center justify-center hover:bg-muted"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="min-w-[40px] text-center text-xs font-mono font-semibold tabular-nums">
                      {item.quantity}
                      {item.unitType === 'KG' ? 'kg' : item.unitType === 'GRAM' ? 'g' : ''}
                    </span>
                    <button
                      type="button"
                      onClick={() => updateCartQty(item.id, 1)}
                      aria-label="Increase quantity"
                      className="press min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl border border-border bg-card flex items-center justify-center hover:bg-muted"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </>
                )}
                <div className="min-w-[70px] text-end text-sm font-bold font-mono tabular-nums">
                  {formatDA(item.total, lang)}
                </div>
                <button
                  type="button"
                  onClick={() => setCart((prev) => prev.filter((x) => x.id !== item.id))}
                  aria-label={t(lang, 'delete')}
                  className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl flex items-center justify-center text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="pt-3 border-t border-border space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-muted-foreground">{t(lang, 'totalToPay')}</span>
          <span className="text-2xl font-bold font-mono tabular-nums text-primary">
            {formatDA(cartTotal, lang)}
          </span>
        </div>

        <div className={`grid gap-2 ${isOwner ? 'grid-cols-2' : 'grid-cols-1'}`}>
          <button
            type="button"
            disabled={cart.length === 0 || todayLocked}
            onClick={() => openCheckout('cash')}
            className="press min-h-[48px] px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-45"
          >
            <Banknote className="w-4 h-4" />
            <span>{t(lang, 'payCash')}</span>
          </button>

          {isOwner && (
            <button
              type="button"
              disabled={cart.length === 0 || todayLocked || state.customers.length === 0}
              onClick={() => openCheckout('credit')}
              className="press min-h-[48px] px-4 py-2.5 rounded-xl bg-secondary text-secondary-foreground border border-border font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-45"
            >
              <UserCheck className="w-4 h-4" />
              <span>{t(lang, 'payCredit')}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {todayLocked && (
        <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-800 dark:text-amber-200 flex items-center gap-2.5 text-sm font-medium">
          <Lock className="w-5 h-5 shrink-0" />
          <span>{t(lang, 'dayLockedWarning')}</span>
        </div>
      )}

      {scanNotice && (
        <div className="p-3 rounded-xl bg-primary/15 text-primary text-sm font-semibold text-center">
          {scanNotice}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Catalog / Category-First Area */}
        <div className="lg:col-span-7 space-y-4">
          {/* Search + Scan + Autre Toolbar */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
            <div className="relative flex-1 min-w-[180px]">
              <Search className="w-4 h-4 text-muted-foreground absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && search.trim()) {
                    const exact = state.products.find((p) => p.barcode === search.trim());
                    if (exact) {
                      handleProductTap(exact);
                      setSearch('');
                    }
                  }
                }}
                placeholder={t(lang, 'searchProductPlaceholder')}
                className="w-full min-h-[46px] ps-10 pe-3 rounded-2xl border border-input bg-card text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <button
              type="button"
              onClick={() => setScannerOpen(true)}
              aria-label={t(lang, 'scanBarcodeQr')}
              className="press min-h-[46px] px-4 rounded-2xl bg-primary text-primary-foreground text-xs sm:text-sm font-semibold flex items-center gap-2 shrink-0"
            >
              <QrCode className="w-4 h-4" />
              <span>{t(lang, 'scanBarcodeQr')}</span>
            </button>

            <button
              type="button"
              disabled={todayLocked}
              onClick={() => setOtherModalOpen(true)}
              className="press min-h-[46px] px-4 rounded-2xl bg-card border border-border hover:bg-muted text-xs sm:text-sm font-semibold flex items-center gap-1.5 shrink-0 disabled:opacity-45"
            >
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Autre</span>
            </button>
          </div>

          {/* Home: Categories instead of full product list, OR active Category/Search products */}
          {!search.trim() && !selectedCategoryId ? (
            <div className="space-y-5">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h2 className="text-sm font-bold text-muted-foreground">
                    {t(lang, 'categoriesTitle')}
                  </h2>
                  <button
                    type="button"
                    onClick={() => onSelectCategory('__ALL__')}
                    className="min-h-[44px] sm:min-h-[32px] px-2 text-xs font-semibold text-primary hover:underline"
                  >
                    {t(lang, 'allCategories')}
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {state.categories.map((cat) => {
                    const count = categoryCounts.get(cat.id) ?? 0;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => onSelectCategory(cat.id)}
                        className="press min-h-[84px] p-4 rounded-2xl bg-card border border-border hover:border-primary/50 hover:bg-accent/30 text-start flex flex-col justify-between gap-2 transition-colors"
                      >
                        <FolderOpen className="w-5 h-5 text-primary" />
                        <div>
                          <div className="text-sm font-bold truncate">{cat.name}</div>
                          <div className="text-xs text-muted-foreground tabular-nums">
                            {count} {t(lang, 'productsInCategory')}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Weighed Products Quick-Shortcuts */}
              {weighedProducts.length > 0 && (
                <div className="space-y-2.5">
                  <h2 className="text-sm font-bold text-muted-foreground flex items-center gap-1.5">
                    <Scale className="w-4 h-4 text-primary" />
                    <span>{t(lang, 'weighedShortcuts')}</span>
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {weighedProducts.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        disabled={todayLocked}
                        onClick={() => handleProductTap(p)}
                        className="press min-h-[76px] p-3.5 rounded-2xl bg-card border border-border hover:border-primary/50 text-start flex flex-col justify-between transition-colors disabled:opacity-45"
                      >
                        <span className="text-sm font-semibold line-clamp-1">{p.name}</span>
                        <span className="text-xs font-mono font-bold text-primary tabular-nums">
                          {formatDA(p.sellingPrice, lang)} /{' '}
                          {p.unitType === 'KG' ? 'kg' : 'g'}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSearch('');
                    onSelectCategory(null);
                  }}
                  className="press min-h-[44px] sm:min-h-[36px] px-3 rounded-xl bg-card border border-border text-xs font-semibold flex items-center gap-1.5 hover:bg-muted"
                >
                  <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
                  <span>{t(lang, 'backToCategories')}</span>
                </button>
                {activeCategoryName && !search.trim() && (
                  <span className="text-sm font-bold truncate">{activeCategoryName}</span>
                )}
              </div>

              {filteredProducts.length === 0 ? (
                <div className="p-10 rounded-2xl border border-dashed border-border text-center text-sm text-muted-foreground">
                  {t(lang, 'noProductsFound')}
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {filteredProducts.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      disabled={todayLocked}
                      onClick={() => handleProductTap(p)}
                      className="press min-h-[92px] p-3.5 rounded-2xl bg-card border border-border hover:border-primary/50 text-start flex flex-col justify-between gap-2 transition-colors disabled:opacity-45"
                    >
                      <div>
                        <div className="text-sm font-semibold leading-snug line-clamp-2">
                          {p.name}
                          {p.variantLabel ? ` · ${p.variantLabel}` : ''}
                        </div>
                      </div>
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-sm font-bold font-mono tabular-nums text-primary">
                          {formatDA(p.sellingPrice, lang)}
                        </span>
                        <span className="text-xs text-muted-foreground font-mono tabular-nums">
                          {p.unitType === 'KG'
                            ? `${p.quantity}kg`
                            : p.unitType === 'GRAM'
                              ? `${p.quantity}g`
                              : p.quantity}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Desktop Cart Panel */}
        <div className="hidden lg:block lg:col-span-5 bg-card border border-border rounded-3xl p-5 sticky top-20 min-h-[480px] max-h-[calc(100vh-8rem)] flex flex-col">
          {CartContent}
        </div>
      </div>

      {/* Mobile Floating Cart Trigger Bar */}
      <div className="lg:hidden fixed bottom-[calc(4.4rem+env(safe-area-inset-bottom))] inset-x-3 z-30">
        <button
          type="button"
          onClick={() => setMobileCartOpen(true)}
          className="press w-full min-h-[52px] px-4 py-3 rounded-2xl bg-primary text-primary-foreground shadow-lg flex items-center justify-between gap-3"
        >
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5" />
            <span className="text-sm font-bold">
              {t(lang, 'cartTitle')} ({cartCount})
            </span>
          </div>
          <span className="text-base font-bold font-mono tabular-nums">
            {formatDA(cartTotal, lang)}
          </span>
        </button>
      </div>

      {/* Mobile Cart Drawer */}
      <ModalDrawer
        open={mobileCartOpen}
        onClose={() => setMobileCartOpen(false)}
        title={t(lang, 'cartTitle')}
      >
        <div className="min-h-[340px] flex flex-col">{CartContent}</div>
      </ModalDrawer>

      {/* Camera Barcode & QR Scanner */}
      <BarcodeScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onDetected={handleBarcodeDetected}
        language={lang}
      />

      {/* "Autre" Quick Price Item Modal */}
      <ModalDrawer
        open={otherModalOpen}
        onClose={() => setOtherModalOpen(false)}
        title={t(lang, 'otherItemTitle')}
        maxWidthClass="sm:max-w-sm"
      >
        <form onSubmit={handleAddOtherItem} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'enterPriceOnly')}
            </label>
            <input
              type="number"
              step="any"
              min="1"
              autoFocus
              required
              value={otherPrice}
              onChange={(e) => setOtherPrice(e.target.value)}
              placeholder="150"
              className="w-full min-h-[48px] px-4 rounded-xl border border-input bg-background text-lg font-mono font-bold tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <button
            type="submit"
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
          >
            {t(lang, 'addToCart')}
          </button>
        </form>
      </ModalDrawer>

      {/* Weighed Product Modal */}
      <ModalDrawer
        open={Boolean(weighedProduct)}
        onClose={() => setWeighedProduct(null)}
        title={weighedProduct ? weighedProduct.name : t(lang, 'weighedItemTitle')}
        maxWidthClass="sm:max-w-sm"
      >
        {weighedProduct && (
          <form onSubmit={handleAddWeighedItem} className="space-y-4">
            <div className="text-xs text-muted-foreground">
              {t(lang, 'unitPriceLabel')}:{' '}
              <span className="font-mono font-bold text-foreground">
                {formatDA(weighedProduct.sellingPrice, lang)} /{' '}
                {weighedProduct.unitType === 'KG' ? 'kg' : 'g'}
              </span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {weighedProduct.unitType === 'KG'
                  ? t(lang, 'weightKg')
                  : t(lang, 'weightGrams')}
              </label>
              <input
                type="number"
                step="any"
                min="0.001"
                value={weightInput}
                onChange={(e) => {
                  const v = e.target.value;
                  setWeightInput(v);
                  const n = parseFloat(v);
                  if (Number.isFinite(n) && n > 0) {
                    setWeighedPriceOverride(
                      String(Math.round(n * weighedProduct.sellingPrice * 100) / 100)
                    );
                  } else {
                    setWeighedPriceOverride('');
                  }
                }}
                placeholder={weighedProduct.unitType === 'KG' ? '0.5' : '250'}
                className="w-full min-h-[46px] px-3.5 rounded-xl border border-input bg-background text-base font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'priceOverride')}
              </label>
              <input
                type="number"
                step="any"
                min="1"
                value={weighedPriceOverride}
                onChange={(e) => {
                  const v = e.target.value;
                  setWeighedPriceOverride(v);
                  const n = parseFloat(v);
                  if (Number.isFinite(n) && n > 0 && weighedProduct.sellingPrice > 0) {
                    setWeightInput(
                      String(Math.round((n / weighedProduct.sellingPrice) * 1000) / 1000)
                    );
                  }
                }}
                placeholder="100"
                className="w-full min-h-[46px] px-3.5 rounded-xl border border-input bg-background text-base font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <button
              type="submit"
              className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
            >
              {t(lang, 'addToCart')}
            </button>
          </form>
        )}
      </ModalDrawer>

      {/* Checkout Modal */}
      <ModalDrawer
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        title={paymentType === 'cash' ? t(lang, 'payCash') : t(lang, 'payCredit')}
        maxWidthClass="sm:max-w-md"
      >
        <form onSubmit={handleConfirmSale} className="space-y-4">
          <div className="p-4 rounded-2xl bg-muted/50 flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">
              {t(lang, 'totalToPay')}
            </span>
            <span className="text-2xl font-bold font-mono tabular-nums text-primary">
              {formatDA(cartTotal, lang)}
            </span>
          </div>

          {paymentType === 'cash' ? (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">
                  {t(lang, 'amountReceived')}
                </label>
                <input
                  type="number"
                  step="any"
                  min={0}
                  value={cashReceived}
                  onChange={(e) => setCashReceived(e.target.value)}
                  className="w-full min-h-[48px] px-4 rounded-xl border border-input bg-background text-lg font-mono font-bold tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div className="flex items-center justify-between text-sm px-1">
                <span className="text-muted-foreground">{t(lang, 'changeDue')}</span>
                <span className="font-mono font-bold tabular-nums">
                  {formatDA(Math.max(0, (parseFloat(cashReceived) || 0) - cartTotal), lang)}
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'selectCustomer')}
              </label>
              <SelectSheet
                value={selectedCustomerId}
                onChange={setSelectedCustomerId}
                label={t(lang, 'selectCustomer')}
                searchable
                options={state.customers.map((c) => ({
                  value: c.id,
                  label: c.name,
                  sublabel: `${c.phone || ''} · ${formatDA(c.balanceOwed, lang)}`,
                }))}
              />
            </div>
          )}

          {checkoutError && (
            <p className="text-sm text-destructive font-medium">{checkoutError}</p>
          )}

          <button
            type="submit"
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
          >
            {t(lang, 'confirmSale')}
          </button>
        </form>
      </ModalDrawer>

      {/* Receipt Preview / Print Modal */}
      {state.shop && (
        <ReceiptModal
          bill={lastCreatedBill}
          shop={state.shop}
          creditNotes={state.creditNotes}
          language={lang}
          onClose={() => setLastCreatedBill(null)}
        />
      )}
    </div>
  );
}
