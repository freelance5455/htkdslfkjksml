import React, { useMemo, useState } from 'react';
import {
  Banknote,
  CheckCircle2,
  PackageCheck,
  Plus,
  Truck,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  Customer,
  PosState,
  RestockLineItem,
  RestockOrder,
  Supplier,
} from '../types/pos';
import { formatDA, t } from '../lib/i18n';
import {
  createRestockOrder,
  getDayKey,
  markRestockOrderReceived,
  paySupplierOrder,
  recordCustomerDebtPayment,
  upsertCustomer,
  upsertSupplier,
} from '../lib/store';
import { ModalDrawer } from '../components/ui/ModalDrawer';
import { SelectSheet } from '../components/ui/SelectSheet';

interface DebtsScreenProps {
  state: PosState;
  subTab: 'customers' | 'suppliers';
  onSubTabChange: (tab: 'customers' | 'suppliers') => void;
}

export function DebtsScreen({ state, subTab, onSubTabChange }: DebtsScreenProps) {
  const lang = state.language;

  // Customer modals
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custNotes, setCustNotes] = useState('');

  const [payCust, setPayCust] = useState<Customer | null>(null);
  const [custPayAmount, setCustPayAmount] = useState('');
  const [custPayNote, setCustPayNote] = useState('');

  // Supplier modals
  const [supModalOpen, setSupModalOpen] = useState(false);
  const [editingSup, setEditingSup] = useState<Supplier | null>(null);
  const [supName, setSupName] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supNotes, setSupNotes] = useState('');

  // Restock order modal
  const [restockModalOpen, setRestockModalOpen] = useState(false);
  const [orderSupId, setOrderSupId] = useState('');
  const [orderArrival, setOrderArrival] = useState(getDayKey());
  const [orderDue, setOrderDue] = useState(getDayKey());
  const [orderNotes, setOrderNotes] = useState('');
  const [orderPaidNow, setOrderPaidNow] = useState(false);
  const [orderReceivedNow, setOrderReceivedNow] = useState(true);
  const [orderLines, setOrderLines] = useState<RestockLineItem[]>([]);
  const [pickProductId, setPickProductId] = useState('');
  const [pickQty, setPickQty] = useState('10');
  const [pickCost, setPickCost] = useState('');

  // Supplier debt payment modal (Partial OR Total!)
  const [payOrder, setPayOrder] = useState<RestockOrder | null>(null);
  const [supPayAmount, setSupPayAmount] = useState('');
  const [supPayNote, setSupPayNote] = useState('');

  const supplierDebtsBySupId = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of state.restockOrders) {
      const owed = Math.max(0, o.totalAmount - o.paidAmount);
      map.set(o.supplierId, (map.get(o.supplierId) ?? 0) + owed);
    }
    return map;
  }, [state.restockOrders]);

  const openNewCustomer = (c?: Customer) => {
    setEditingCustomer(c ?? null);
    setCustName(c?.name ?? '');
    setCustPhone(c?.phone ?? '');
    setCustNotes(c?.notes ?? '');
    setCustomerModalOpen(true);
  };

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim()) return;
    upsertCustomer({
      id: editingCustomer?.id,
      name: custName,
      phone: custPhone,
      notes: custNotes,
    });
    setCustomerModalOpen(false);
  };

  const handleCustomerPay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payCust) return;
    const amt = parseFloat(custPayAmount);
    if (!Number.isFinite(amt) || amt <= 0) return;
    recordCustomerDebtPayment(payCust.id, amt, custPayNote);
    setPayCust(null);
  };

  const openNewSupplier = (s?: Supplier) => {
    setEditingSup(s ?? null);
    setSupName(s?.name ?? '');
    setSupPhone(s?.phone ?? '');
    setSupNotes(s?.notes ?? '');
    setSupModalOpen(true);
  };

  const handleSaveSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName.trim()) return;
    upsertSupplier({
      id: editingSup?.id,
      name: supName,
      phone: supPhone,
      notes: supNotes,
    });
    setSupModalOpen(false);
  };

  const openRestockModal = () => {
    setOrderSupId(state.suppliers[0]?.id ?? '');
    setOrderArrival(getDayKey());
    setOrderDue(getDayKey(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)));
    setOrderNotes('');
    setOrderPaidNow(false);
    setOrderReceivedNow(true);
    setOrderLines([]);
    const firstProd = state.products[0];
    setPickProductId(firstProd?.id ?? '');
    setPickCost(firstProd ? String(firstProd.purchasePrice) : '');
    setPickQty('10');
    setRestockModalOpen(true);
  };

  const handleAddRestockLine = () => {
    const prod = state.products.find((p) => p.id === pickProductId);
    const qty = parseFloat(pickQty);
    const cost = parseFloat(pickCost);
    if (!prod || !Number.isFinite(qty) || qty <= 0 || !Number.isFinite(cost) || cost < 0) return;
    setOrderLines((prev) => [
      ...prev,
      {
        productId: prod.id,
        productName: prod.variantLabel ? `${prod.name} (${prod.variantLabel})` : prod.name,
        barcode: prod.barcode,
        quantity: qty,
        purchasePrice: cost,
      },
    ]);
  };

  const handleCreateRestockOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderSupId || orderLines.length === 0) return;
    createRestockOrder({
      supplierId: orderSupId,
      arrivalDate: orderArrival,
      dueDate: orderDue,
      lineItems: orderLines,
      markPaidNow: orderPaidNow,
      markReceivedNow: orderReceivedNow,
      notes: orderNotes,
    });
    setRestockModalOpen(false);
  };

  const handlePaySupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payOrder) return;
    const amt = parseFloat(supPayAmount);
    if (!Number.isFinite(amt) || amt <= 0) return;
    paySupplierOrder(payOrder.id, amt, supPayNote);
    setPayOrder(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold">{t(lang, 'debtsTitle')}</h1>
      </div>

      {/* Sub-navigation */}
      <div className="flex p-1 rounded-2xl bg-muted border border-border max-w-md">
        <button
          type="button"
          onClick={() => onSubTabChange('customers')}
          className={`flex-1 min-h-[44px] rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${
            subTab === 'customers'
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{t(lang, 'tabCustomers')}</span>
        </button>
        <button
          type="button"
          onClick={() => onSubTabChange('suppliers')}
          className={`flex-1 min-h-[44px] rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${
            subTab === 'suppliers'
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>{t(lang, 'tabSuppliers')}</span>
        </button>
      </div>

      {subTab === 'customers' ? (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => openNewCustomer()}
              className="press min-h-[44px] px-4 rounded-xl bg-primary text-primary-foreground text-sm font-semibold flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>{t(lang, 'addCustomer')}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {state.customers.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-card border border-border flex flex-col justify-between gap-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-base font-bold truncate">{c.name}</div>
                    <div className="text-xs text-muted-foreground font-mono">
                      {c.phone || '—'}
                    </div>
                    {c.notes && <div className="text-xs text-muted-foreground mt-1">{c.notes}</div>}
                  </div>
                  <div className="text-end shrink-0">
                    <div
                      className={`text-lg font-bold font-mono tabular-nums ${
                        c.balanceOwed > 0 ? 'text-destructive' : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {formatDA(c.balanceOwed, lang)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
                  <button
                    type="button"
                    onClick={() => openNewCustomer(c)}
                    className="min-h-[44px] sm:min-h-[36px] px-3 rounded-xl border border-border text-xs font-semibold hover:bg-muted"
                  >
                    {t(lang, 'edit')}
                  </button>
                  {c.balanceOwed > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setPayCust(c);
                        setCustPayAmount(String(c.balanceOwed));
                        setCustPayNote('');
                      }}
                      className="press min-h-[44px] sm:min-h-[36px] px-4 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Banknote className="w-4 h-4" />
                      <span>{t(lang, 'recordPayment')}</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {state.customerDebtPayments.length > 0 && (
            <div className="space-y-2 pt-2">
              <h2 className="text-sm font-bold text-muted-foreground">
                {t(lang, 'paymentHistory')}
              </h2>
              <div className="space-y-2">
                {state.customerDebtPayments.slice(0, 10).map((dp) => (
                  <div
                    key={dp.id}
                    className="p-3 rounded-xl bg-card border border-border flex items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <span className="font-semibold">{dp.customerName}</span>
                      <span className="text-muted-foreground">
                        {' '}
                        · {new Date(dp.date).toLocaleDateString(lang === 'ar' ? 'ar-DZ' : 'fr-FR')}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      + {formatDA(dp.amount, lang)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          <div className="flex flex-wrap justify-end gap-2">
            <button
              type="button"
              onClick={() => openNewSupplier()}
              className="press min-h-[44px] px-4 rounded-xl border border-border bg-card text-sm font-semibold flex items-center gap-2 hover:bg-muted"
            >
              <Plus className="w-4 h-4" />
              <span>{t(lang, 'addSupplier')}</span>
            </button>
            <button
              type="button"
              disabled={state.suppliers.length === 0 || state.products.length === 0}
              onClick={openRestockModal}
              className="press min-h-[44px] px-4 rounded-xl bg-primary text-primary-foreground text-sm font-semibold flex items-center gap-2 disabled:opacity-45"
            >
              <Truck className="w-4 h-4" />
              <span>{t(lang, 'newRestockOrder')}</span>
            </button>
          </div>

          {/* Suppliers Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {state.suppliers.map((sup) => {
              const owed = supplierDebtsBySupId.get(sup.id) ?? 0;
              return (
                <div
                  key={sup.id}
                  className="p-4 rounded-2xl bg-card border border-border flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-bold truncate">{sup.name}</div>
                    <div className="text-xs text-muted-foreground font-mono">
                      {sup.phone || '—'}
                    </div>
                    {sup.notes && (
                      <div className="text-xs text-muted-foreground truncate mt-0.5">
                        {sup.notes}
                      </div>
                    )}
                  </div>
                  <div className="text-end shrink-0 space-y-1">
                    <div
                      className={`text-base font-bold font-mono tabular-nums ${
                        owed > 0 ? 'text-destructive' : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {formatDA(owed, lang)}
                    </div>
                    <button
                      type="button"
                      onClick={() => openNewSupplier(sup)}
                      className="text-xs font-semibold text-primary hover:underline"
                    >
                      {t(lang, 'edit')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Restock Orders & Partial / Total Debt Payment */}
          <div className="space-y-2.5">
            <h2 className="text-sm font-bold text-muted-foreground">
              {t(lang, 'newRestockOrder')}s
            </h2>
            {state.restockOrders.map((order) => {
              const remaining = Math.max(0, order.totalAmount - order.paidAmount);
              const ageDays = Math.floor(
                (Date.now() - new Date(order.billingDate).getTime()) / (1000 * 60 * 60 * 24)
              );

              return (
                <div
                  key={order.id}
                  className="p-4 rounded-2xl bg-card border border-border space-y-3"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="text-sm font-bold">{order.supplierName}</div>
                      <div className="text-xs text-muted-foreground">
                        {order.arrivalDate} · {order.lineItems.length} art. ·{' '}
                        {ageDays > 0 ? `${ageDays}j` : 'Aujourd’hui'}
                      </div>
                    </div>
                    <div className="text-end">
                      <div className="text-base font-bold font-mono tabular-nums">
                        {formatDA(order.totalAmount, lang)}
                      </div>
                      <div className="text-xs font-semibold">
                        {order.paymentStatus === 'paid' ? (
                          <span className="text-emerald-600 dark:text-emerald-400">
                            {t(lang, 'paidStatus')}
                          </span>
                        ) : order.paymentStatus === 'partial' ? (
                          <span className="text-amber-600 dark:text-amber-400">
                            {t(lang, 'partialStatus')} · {t(lang, 'remainingDebt')}:{' '}
                            {formatDA(remaining, lang)}
                          </span>
                        ) : (
                          <span className="text-destructive">
                            {t(lang, 'unpaidStatus')} · {formatDA(remaining, lang)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {order.paymentHistory.length > 0 && (
                    <div className="text-xs text-muted-foreground space-y-1 border-t border-border pt-2">
                      {order.paymentHistory.map((ph) => (
                        <div key={ph.id} className="flex justify-between">
                          <span>
                            {new Date(ph.date).toLocaleDateString(
                              lang === 'ar' ? 'ar-DZ' : 'fr-FR'
                            )}
                            {ph.note ? ` · ${ph.note}` : ''}
                          </span>
                          <span className="font-mono font-semibold text-foreground">
                            {formatDA(ph.amount, lang)}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-border">
                    {order.status === 'pending' ? (
                      <button
                        type="button"
                        onClick={() => markRestockOrderReceived(order.id)}
                        className="press min-h-[44px] sm:min-h-[36px] px-3.5 rounded-xl bg-secondary text-secondary-foreground text-xs font-semibold flex items-center gap-1.5"
                      >
                        <PackageCheck className="w-4 h-4" />
                        <span>{t(lang, 'markReceived')}</span>
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 me-auto">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{t(lang, 'receivedStatus')}</span>
                      </span>
                    )}

                    {remaining > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setPayOrder(order);
                          setSupPayAmount(String(remaining));
                          setSupPayNote('');
                        }}
                        className="press min-h-[44px] sm:min-h-[36px] px-4 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1.5"
                      >
                        <Banknote className="w-4 h-4" />
                        <span>{t(lang, 'paySupplierDebt')}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Customer Form Modal */}
      <ModalDrawer
        open={customerModalOpen}
        onClose={() => setCustomerModalOpen(false)}
        title={t(lang, 'addCustomer')}
        maxWidthClass="sm:max-w-md"
      >
        <form onSubmit={handleSaveCustomer} className="space-y-3.5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'customerName')} *
            </label>
            <input
              type="text"
              required
              value={custName}
              onChange={(e) => setCustName(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'phone')}
            </label>
            <input
              type="tel"
              value={custPhone}
              onChange={(e) => setCustPhone(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'notesLabel')}
            </label>
            <input
              type="text"
              value={custNotes}
              onChange={(e) => setCustNotes(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <button
            type="submit"
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
          >
            {t(lang, 'save')}
          </button>
        </form>
      </ModalDrawer>

      {/* Customer Payment Modal (Auto reduces debt & adds to Today's Closing!) */}
      <ModalDrawer
        open={Boolean(payCust)}
        onClose={() => setPayCust(null)}
        title={payCust ? `${t(lang, 'recordPayment')} · ${payCust.name}` : ''}
        maxWidthClass="sm:max-w-md"
      >
        {payCust && (
          <form onSubmit={handleCustomerPay} className="space-y-4">
            <div className="p-3.5 rounded-xl bg-accent/50 text-accent-foreground text-xs leading-relaxed">
              {t(lang, 'debtPaymentAddedToClosing')}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setCustPayAmount(String(payCust.balanceOwed))}
                className="flex-1 min-h-[44px] rounded-xl border border-border bg-secondary text-xs font-semibold"
              >
                {t(lang, 'totalPayment')} ({formatDA(payCust.balanceOwed, lang)})
              </button>
              <button
                type="button"
                onClick={() =>
                  setCustPayAmount(String(Math.round((payCust.balanceOwed / 2) * 100) / 100))
                }
                className="flex-1 min-h-[44px] rounded-xl border border-border bg-card text-xs font-semibold"
              >
                50% ({t(lang, 'partialPayment')})
              </button>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'paymentAmount')}
              </label>
              <input
                type="number"
                step="any"
                min="1"
                max={payCust.balanceOwed}
                required
                value={custPayAmount}
                onChange={(e) => setCustPayAmount(e.target.value)}
                className="w-full min-h-[48px] px-4 rounded-xl border border-input bg-background text-lg font-mono font-bold tabular-nums"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'notesLabel')}
              </label>
              <input
                type="text"
                value={custPayNote}
                onChange={(e) => setCustPayNote(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
              />
            </div>
            <button
              type="submit"
              className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
            >
              {t(lang, 'confirm')}
            </button>
          </form>
        )}
      </ModalDrawer>

      {/* Supplier Form Modal */}
      <ModalDrawer
        open={supModalOpen}
        onClose={() => setSupModalOpen(false)}
        title={t(lang, 'addSupplier')}
        maxWidthClass="sm:max-w-md"
      >
        <form onSubmit={handleSaveSupplier} className="space-y-3.5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'supplierLabel')} *
            </label>
            <input
              type="text"
              required
              value={supName}
              onChange={(e) => setSupName(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'phone')}
            </label>
            <input
              type="tel"
              value={supPhone}
              onChange={(e) => setSupPhone(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'notesLabel')}
            </label>
            <input
              type="text"
              value={supNotes}
              onChange={(e) => setSupNotes(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
            />
          </div>
          <button
            type="submit"
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
          >
            {t(lang, 'save')}
          </button>
        </form>
      </ModalDrawer>

      {/* New Restock Order Modal */}
      <ModalDrawer
        open={restockModalOpen}
        onClose={() => setRestockModalOpen(false)}
        title={t(lang, 'newRestockOrder')}
      >
        <form onSubmit={handleCreateRestockOrder} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'supplierLabel')}
            </label>
            <SelectSheet
              value={orderSupId}
              onChange={setOrderSupId}
              label={t(lang, 'supplierLabel')}
              searchable
              options={state.suppliers.map((s) => ({
                value: s.id,
                label: s.name,
                sublabel: s.phone,
              }))}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'arrivalDate')}
              </label>
              <input
                type="date"
                value={orderArrival}
                onChange={(e) => setOrderArrival(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-xl border border-input bg-background text-sm font-mono"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'dueDate')}
              </label>
              <input
                type="date"
                value={orderDue}
                onChange={(e) => setOrderDue(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-xl border border-input bg-background text-sm font-mono"
              />
            </div>
          </div>

          {/* Add line items using SelectSheet */}
          <div className="p-3 rounded-2xl border border-border bg-muted/30 space-y-2.5">
            <SelectSheet
              value={pickProductId}
              onChange={(pid) => {
                setPickProductId(pid);
                const p = state.products.find((x) => x.id === pid);
                if (p) setPickCost(String(p.purchasePrice));
              }}
              label={t(lang, 'productName')}
              searchable
              options={state.products.map((p) => ({
                value: p.id,
                label: p.variantLabel ? `${p.name} (${p.variantLabel})` : p.name,
                sublabel: p.barcode || p.unitType,
              }))}
            />
            <div className="grid grid-cols-3 gap-2">
              <input
                type="number"
                step="any"
                min="0.01"
                value={pickQty}
                onChange={(e) => setPickQty(e.target.value)}
                placeholder={t(lang, 'qty')}
                className="min-h-[44px] px-3 rounded-xl border border-input bg-background text-sm font-mono"
              />
              <input
                type="number"
                step="any"
                min="0"
                value={pickCost}
                onChange={(e) => setPickCost(e.target.value)}
                placeholder={t(lang, 'purchasePrice')}
                className="min-h-[44px] px-3 rounded-xl border border-input bg-background text-sm font-mono"
              />
              <button
                type="button"
                onClick={handleAddRestockLine}
                className="press min-h-[44px] rounded-xl bg-secondary text-secondary-foreground text-xs font-semibold"
              >
                + {t(lang, 'add')}
              </button>
            </div>

            {orderLines.map((li, i) => (
              <div
                key={i}
                className="flex items-center justify-between text-xs py-1.5 border-t border-border"
              >
                <span className="truncate font-medium">
                  {li.productName} ({li.quantity} × {formatDA(li.purchasePrice, lang)})
                </span>
                <span className="font-mono font-bold">
                  {formatDA(li.quantity * li.purchasePrice, lang)}
                </span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setOrderReceivedNow((v) => !v)}
              className={`min-h-[44px] px-3 rounded-xl border text-xs font-semibold ${
                orderReceivedNow
                  ? 'bg-accent text-accent-foreground border-primary/40'
                  : 'bg-background border-border'
              }`}
            >
              {t(lang, 'markReceived')}
            </button>
            <button
              type="button"
              onClick={() => setOrderPaidNow((v) => !v)}
              className={`min-h-[44px] px-3 rounded-xl border text-xs font-semibold ${
                orderPaidNow
                  ? 'bg-accent text-accent-foreground border-primary/40'
                  : 'bg-background border-border'
              }`}
            >
              {t(lang, 'paidStatus')}
            </button>
          </div>

          <button
            type="submit"
            disabled={orderLines.length === 0}
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm disabled:opacity-45"
          >
            {t(lang, 'save')} (
            {formatDA(
              orderLines.reduce((s, l) => s + l.quantity * l.purchasePrice, 0),
              lang
            )}
            )
          </button>
        </form>
      </ModalDrawer>

      {/* Supplier Debt Payment Modal: Partial OR Total Payment */}
      <ModalDrawer
        open={Boolean(payOrder)}
        onClose={() => setPayOrder(null)}
        title={payOrder ? `${t(lang, 'paySupplierDebt')} · ${payOrder.supplierName}` : ''}
        maxWidthClass="sm:max-w-md"
      >
        {payOrder && (
          <form onSubmit={handlePaySupplier} className="space-y-4">
            {(() => {
              const remaining = Math.max(0, payOrder.totalAmount - payOrder.paidAmount);
              return (
                <>
                  <div className="p-3.5 rounded-2xl bg-muted/50 flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">{t(lang, 'remainingDebt')}</span>
                    <span className="text-lg font-bold font-mono text-destructive tabular-nums">
                      {formatDA(remaining, lang)}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSupPayAmount(String(remaining))}
                      className="flex-1 min-h-[44px] rounded-xl border border-border bg-secondary text-xs font-semibold"
                    >
                      {t(lang, 'totalPayment')} ({formatDA(remaining, lang)})
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setSupPayAmount(String(Math.round((remaining / 2) * 100) / 100))
                      }
                      className="flex-1 min-h-[44px] rounded-xl border border-border bg-card text-xs font-semibold"
                    >
                      {t(lang, 'partialPayment')}
                    </button>
                  </div>
                </>
              );
            })()}

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'paymentAmount')}
              </label>
              <input
                type="number"
                step="any"
                min="1"
                max={Math.max(0, payOrder.totalAmount - payOrder.paidAmount)}
                required
                value={supPayAmount}
                onChange={(e) => setSupPayAmount(e.target.value)}
                className="w-full min-h-[48px] px-4 rounded-xl border border-input bg-background text-lg font-mono font-bold tabular-nums"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'notesLabel')}
              </label>
              <input
                type="text"
                value={supPayNote}
                onChange={(e) => setSupPayNote(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
              />
            </div>

            <button
              type="submit"
              className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
            >
              {t(lang, 'confirm')}
            </button>
          </form>
        )}
      </ModalDrawer>
    </div>
  );
}
