import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CopyPlus,
  Edit3,
  FolderCog,
  Plus,
  QrCode,
  Search,
  Trash2,
} from 'lucide-react';
import { PosState, Product, UnitType } from '../types/pos';
import { formatDA, t } from '../lib/i18n';
import {
  addCategory,
  deleteCategory,
  deleteProduct,
  updateCategory,
  upsertProduct,
} from '../lib/store';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';
import { ModalDrawer } from '../components/ui/ModalDrawer';
import { SelectSheet } from '../components/ui/SelectSheet';

interface StockScreenProps {
  state: PosState;
}

export function StockScreen({ state }: StockScreenProps) {
  const lang = state.language;
  const defaultThreshold = state.shop?.lowStockThreshold ?? 5;

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [alertFilter, setAlertFilter] = useState<'all' | 'alerts'>('all');

  // Product modal state
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | undefined>(undefined);
  const [barcode, setBarcode] = useState('');
  const [name, setName] = useState('');
  const [variantLabel, setVariantLabel] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [unitType, setUnitType] = useState<UnitType>('UNIT');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [lowStockThreshold, setLowStockThreshold] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const [scannerOpen, setScannerOpen] = useState(false);

  // Category manager modal
  const [catModalOpen, setCatModalOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState('');

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.products.filter((p) => {
      if (categoryFilter !== 'ALL' && p.categoryId !== categoryFilter) return false;
      const threshold = p.lowStockThreshold ?? defaultThreshold;
      if (alertFilter === 'alerts' && p.quantity > threshold) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        (p.variantLabel && p.variantLabel.toLowerCase().includes(q)) ||
        (p.barcode && p.barcode.toLowerCase().includes(q))
      );
    });
  }, [state.products, search, categoryFilter, alertFilter, defaultThreshold]);

  const openNewProduct = (prefill?: Partial<Product>) => {
    setEditingId(undefined);
    setBarcode('');
    setName(prefill?.name ?? '');
    setVariantLabel('');
    setCategoryId(prefill?.categoryId ?? state.categories[0]?.id ?? '');
    setUnitType(prefill?.unitType ?? 'UNIT');
    setPurchasePrice(prefill?.purchasePrice ? String(prefill.purchasePrice) : '');
    setSellingPrice(prefill?.sellingPrice ? String(prefill.sellingPrice) : '');
    setQuantity('0');
    setLowStockThreshold('');
    setFormError(null);
    setProductModalOpen(true);
  };

  const openEditProduct = (p: Product) => {
    setEditingId(p.id);
    setBarcode(p.barcode);
    setName(p.name);
    setVariantLabel(p.variantLabel ?? '');
    setCategoryId(p.categoryId);
    setUnitType(p.unitType);
    setPurchasePrice(String(p.purchasePrice));
    setSellingPrice(String(p.sellingPrice));
    setQuantity(String(p.quantity));
    setLowStockThreshold(p.lowStockThreshold !== undefined ? String(p.lowStockThreshold) : '');
    setFormError(null);
    setProductModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!name.trim()) {
      setFormError(t(lang, 'requiredField'));
      return;
    }
    const res = upsertProduct({
      id: editingId,
      barcode,
      name: name.trim(),
      variantLabel: variantLabel.trim() || undefined,
      categoryId: categoryId || state.categories[0]?.id || '',
      unitType,
      purchasePrice: Math.max(0, parseFloat(purchasePrice) || 0),
      sellingPrice: Math.max(0, parseFloat(sellingPrice) || 0),
      quantity: Math.max(0, parseFloat(quantity) || 0),
      lowStockThreshold: lowStockThreshold ? Math.max(0, parseFloat(lowStockThreshold)) : undefined,
    });
    if (!res.ok) {
      setFormError(res.error || 'Error');
      return;
    }
    setProductModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* Header Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold">{t(lang, 'stockTitle')}</h1>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCatModalOpen(true)}
            className="press min-h-[44px] px-3.5 rounded-xl border border-border bg-card text-sm font-semibold flex items-center gap-2 hover:bg-muted"
          >
            <FolderCog className="w-4 h-4 text-primary" />
            <span>{t(lang, 'manageCategories')}</span>
          </button>
          <button
            type="button"
            onClick={() => openNewProduct()}
            className="press min-h-[44px] px-4 rounded-xl bg-primary text-primary-foreground text-sm font-semibold flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{t(lang, 'addProduct')}</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
        <div className="sm:col-span-5 relative">
          <Search className="w-4 h-4 text-muted-foreground absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t(lang, 'searchProductPlaceholder')}
            className="w-full min-h-[44px] ps-10 pe-3 rounded-xl border border-input bg-card text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="sm:col-span-4">
          <SelectSheet
            value={categoryFilter}
            onChange={setCategoryFilter}
            label={t(lang, 'categoryLabel')}
            options={[
              { value: 'ALL', label: t(lang, 'allCategories') },
              ...state.categories.map((c) => ({ value: c.id, label: c.name })),
            ]}
          />
        </div>

        <div className="sm:col-span-3 flex items-center p-1 rounded-xl bg-muted border border-border">
          <button
            type="button"
            onClick={() => setAlertFilter('all')}
            className={`flex-1 min-h-[36px] rounded-lg text-xs font-semibold transition-colors ${
              alertFilter === 'all' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'
            }`}
          >
            {t(lang, 'allProductsFilter')}
          </button>
          <button
            type="button"
            onClick={() => setAlertFilter('alerts')}
            className={`flex-1 min-h-[36px] rounded-lg text-xs font-semibold transition-colors ${
              alertFilter === 'alerts'
                ? 'bg-card text-destructive shadow-sm'
                : 'text-muted-foreground'
            }`}
          >
            {t(lang, 'lowStockFilter')}
          </button>
        </div>
      </div>

      {/* Product List */}
      {filteredProducts.length === 0 ? (
        <div className="p-10 rounded-2xl border border-dashed border-border text-center text-sm text-muted-foreground">
          {t(lang, 'noProductsFound')}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredProducts.map((p) => {
            const catName = state.categories.find((c) => c.id === p.categoryId)?.name ?? '—';
            const threshold = p.lowStockThreshold ?? defaultThreshold;
            const isOut = p.quantity <= 0;
            const isLow = !isOut && p.quantity <= threshold;

            return (
              <div
                key={p.id}
                className="p-4 rounded-2xl bg-card border border-border flex flex-col justify-between gap-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-bold truncate">
                      {p.name}
                      {p.variantLabel ? ` · ${p.variantLabel}` : ''}
                    </div>
                    <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-0.5">
                      <span>{catName}</span>
                      {p.barcode && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono">{p.barcode}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="text-end shrink-0">
                    <div className="text-sm font-bold font-mono tabular-nums text-primary">
                      {formatDA(p.sellingPrice, lang)}
                    </div>
                    <div className="text-xs text-muted-foreground font-mono tabular-nums">
                      {formatDA(p.purchasePrice, lang)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
                  <div className="flex items-center gap-2 text-xs font-semibold">
                    {(isOut || isLow) && (
                      <AlertTriangle
                        className={`w-4 h-4 ${isOut ? 'text-destructive' : 'text-amber-500'}`}
                      />
                    )}
                    <span
                      className={`font-mono tabular-nums ${
                        isOut
                          ? 'text-destructive'
                          : isLow
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {p.quantity} {p.unitType === 'KG' ? 'kg' : p.unitType === 'GRAM' ? 'g' : ''}
                    </span>
                    <span className="text-muted-foreground">
                      ·{' '}
                      {isOut
                        ? t(lang, 'outOfStockBadge')
                        : isLow
                          ? t(lang, 'lowStockBadge')
                          : t(lang, 'inStockBadge')}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    {p.unitType === 'UNIT' && (
                      <button
                        type="button"
                        onClick={() =>
                          openNewProduct({
                            name: p.name,
                            categoryId: p.categoryId,
                            unitType: p.unitType,
                            purchasePrice: p.purchasePrice,
                            sellingPrice: p.sellingPrice,
                          })
                        }
                        aria-label={t(lang, 'addVariant')}
                        title={t(lang, 'addVariant')}
                        className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground"
                      >
                        <CopyPlus className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => openEditProduct(p)}
                      aria-label={t(lang, 'edit')}
                      className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteProduct(p.id)}
                      aria-label={t(lang, 'delete')}
                      className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl hover:bg-destructive/10 flex items-center justify-center text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Product Modal (with Camera QR/Barcode Scan!) */}
      <ModalDrawer
        open={productModalOpen}
        onClose={() => setProductModalOpen(false)}
        title={editingId ? t(lang, 'editProduct') : t(lang, 'addProduct')}
      >
        <form onSubmit={handleSaveProduct} className="space-y-3.5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground">
              {t(lang, 'barcodeLabel')}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="6130001000011"
                disabled={unitType !== 'UNIT'}
                className="flex-1 min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50"
              />
              {unitType === 'UNIT' && (
                <button
                  type="button"
                  onClick={() => setScannerOpen(true)}
                  aria-label={t(lang, 'scanWithCamera')}
                  className="press min-h-[44px] px-3.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1.5 shrink-0"
                >
                  <QrCode className="w-4 h-4" />
                  <span>{t(lang, 'scanWithCamera')}</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'productName')} *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'variantLabel')}
              </label>
              <input
                type="text"
                value={variantLabel}
                onChange={(e) => setVariantLabel(e.target.value)}
                placeholder="1.5L / L / M"
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'categoryLabel')}
              </label>
              <SelectSheet
                value={categoryId}
                onChange={setCategoryId}
                label={t(lang, 'categoryLabel')}
                options={state.categories.map((c) => ({ value: c.id, label: c.name }))}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'unitTypeLabel')}
              </label>
              <SelectSheet
                value={unitType}
                onChange={(v) => setUnitType(v as UnitType)}
                label={t(lang, 'unitTypeLabel')}
                options={[
                  { value: 'UNIT', label: t(lang, 'unitPiece') },
                  { value: 'KG', label: t(lang, 'unitKg') },
                  { value: 'GRAM', label: t(lang, 'unitGram') },
                ]}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'purchasePrice')}
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'sellingPrice')}
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'quantityInStock')}
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'customLowThreshold')}
              </label>
              <input
                type="number"
                step="any"
                min="0"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                placeholder={String(defaultThreshold)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </div>

          {formError && (
            <div className="p-3 rounded-xl bg-destructive/10 text-destructive text-xs font-semibold">
              {formError}
            </div>
          )}

          <button
            type="submit"
            className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
          >
            {t(lang, 'save')}
          </button>
        </form>
      </ModalDrawer>

      {/* Camera QR/Barcode Scanner for Product Creation */}
      <BarcodeScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onDetected={(code) => setBarcode(code)}
        language={lang}
        title={t(lang, 'scanBarcodeQr')}
      />

      {/* Category Management Modal */}
      <ModalDrawer
        open={catModalOpen}
        onClose={() => setCatModalOpen(false)}
        title={t(lang, 'manageCategories')}
        maxWidthClass="sm:max-w-md"
      >
        <div className="space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newCatName.trim()) return;
              addCategory(newCatName);
              setNewCatName('');
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              placeholder={t(lang, 'newCategoryName')}
              className="flex-1 min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              className="press min-h-[44px] px-4 rounded-xl bg-primary text-primary-foreground text-xs font-semibold shrink-0"
            >
              {t(lang, 'addCategory')}
            </button>
          </form>

          <div className="space-y-2">
            {state.categories.map((cat) => (
              <div
                key={cat.id}
                className="p-2.5 rounded-xl border border-border bg-muted/30 flex items-center justify-between gap-2"
              >
                {editingCatId === cat.id ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (editingCatName.trim()) {
                        updateCategory(cat.id, editingCatName);
                      }
                      setEditingCatId(null);
                    }}
                    className="flex-1 flex gap-2"
                  >
                    <input
                      type="text"
                      value={editingCatName}
                      onChange={(e) => setEditingCatName(e.target.value)}
                      className="flex-1 min-h-[40px] px-3 rounded-lg border border-input bg-background text-sm"
                    />
                    <button
                      type="submit"
                      className="min-h-[40px] px-3 rounded-lg bg-primary text-primary-foreground text-xs font-semibold"
                    >
                      {t(lang, 'save')}
                    </button>
                  </form>
                ) : (
                  <>
                    <span className="text-sm font-medium px-2 truncate">{cat.name}</span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingCatId(cat.id);
                          setEditingCatName(cat.name);
                        }}
                        aria-label={t(lang, 'edit')}
                        className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      {state.categories.length > 1 && (
                        <button
                          type="button"
                          onClick={() => deleteCategory(cat.id)}
                          aria-label={t(lang, 'delete')}
                          className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-lg hover:bg-destructive/10 flex items-center justify-center text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </ModalDrawer>
    </div>
  );
}
