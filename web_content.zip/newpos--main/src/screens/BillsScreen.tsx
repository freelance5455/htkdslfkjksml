import React, { useMemo, useState } from 'react';
import {
  Edit3,
  Minus,
  Plus,
  Printer,
  QrCode,
  RotateCcw,
  Search,
  Trash2,
} from 'lucide-react';
import { Bill, BillLineItem, PosState, Product, UserAccount } from '../types/pos';
import { formatDA, t } from '../lib/i18n';
import { isDayLocked, issueCreditNote, uid, updateBillItems } from '../lib/store';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';
import { ModalDrawer } from '../components/ui/ModalDrawer';
import { ReceiptModal } from '../components/ReceiptModal';
import { SelectSheet } from '../components/ui/SelectSheet';

interface BillsScreenProps {
  state: PosState;
  currentUser: UserAccount;
}

export function BillsScreen({ state, currentUser }: BillsScreenProps) {
  const lang = state.language;
  const isOwner = currentUser.role === 'owner';

  const [search, setSearch] = useState('');
  const [cashierFilter, setCashierFilter] = useState('ALL');
  const [dateFilter, setDateFilter] = useState('');

  const [receiptBill, setReceiptBill] = useState<Bill | null>(null);

  // Owner Bill Edit state (supports adding new products + camera barcode scan!)
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [editItems, setEditItems] = useState<BillLineItem[]>([]);
  const [addProdSearch, setAddProdSearch] = useState('');
  const [editScannerOpen, setEditScannerOpen] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Credit Note state
  const [cnBill, setCnBill] = useState<Bill | null>(null);
  const [cnMode, setCnMode] = useState<'full' | 'partial'>('full');
  const [cnQuantities, setCnQuantities] = useState<Record<string, number>>({});
  const [cnReason, setCnReason] = useState('');
  const [cnError, setCnError] = useState<string | null>(null);

  const visibleBills = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.bills.filter((b) => {
      // Cashiers ONLY see their own bills
      if (!isOwner && b.cashierId !== currentUser.id) return false;
      if (isOwner && cashierFilter !== 'ALL' && b.cashierId !== cashierFilter) return false;
      if (dateFilter && b.dayKey !== dateFilter) return false;
      if (!q) return true;
      return (
        b.billNumber.toLowerCase().includes(q) ||
        (b.customerName && b.customerName.toLowerCase().includes(q)) ||
        b.cashierName.toLowerCase().includes(q)
      );
    });
  }, [state.bills, isOwner, currentUser.id, cashierFilter, dateFilter, search]);

  const matchingAddProducts = useMemo(() => {
    const q = addProdSearch.trim().toLowerCase();
    if (!q) return state.products.slice(0, 6);
    return state.products
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.barcode && p.barcode.toLowerCase().includes(q))
      )
      .slice(0, 8);
  }, [state.products, addProdSearch]);

  const openEditModal = (bill: Bill) => {
    setEditingBill(bill);
    setEditItems(bill.items.map((it) => ({ ...it })));
    setAddProdSearch('');
    setEditError(null);
  };

  const addProductToEditedBill = (product: Product) => {
    const displayName = product.variantLabel
      ? `${product.name} (${product.variantLabel})`
      : product.name;
    setEditItems((prev) => {
      const idx = prev.findIndex((it) => !it.isOther && it.productId === product.id);
      if (idx >= 0) {
        return prev.map((it, i) => {
          if (i !== idx) return it;
          const nextQty = Math.round((it.quantity + 1) * 1000) / 1000;
          return { ...it, quantity: nextQty, total: Math.round(nextQty * it.unitPrice * 100) / 100 };
        });
      }
      return [
        ...prev,
        {
          id: uid('li'),
          productId: product.id,
          name: displayName,
          barcode: product.barcode,
          unitType: product.unitType,
          quantity: 1,
          purchasePrice: product.purchasePrice,
          unitPrice: product.sellingPrice,
          total: product.sellingPrice,
        },
      ];
    });
    setAddProdSearch('');
  };

  const handleEditBarcodeDetected = (code: string) => {
    const found = state.products.find((p) => p.barcode && p.barcode === code);
    if (found) {
      addProductToEditedBill(found);
      setEditError(null);
    } else {
      setAddProdSearch(code);
      setEditError(`${code} — ${t(lang, 'noProductsFound')}`);
    }
  };

  const handleSaveEditBill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBill) return;
    const res = updateBillItems(editingBill.id, editItems);
    if (!res.ok || !res.bill) {
      setEditError(res.error || 'Error');
      return;
    }
    setEditingBill(null);
    setReceiptBill(res.bill); // Automatically opens updated receipt/PDF for reprint!
  };

  const openCreditNoteModal = (bill: Bill) => {
    setCnBill(bill);
    setCnMode('full');
    const init: Record<string, number> = {};
    for (const it of bill.items) {
      init[it.id] = it.quantity;
    }
    setCnQuantities(init);
    setCnReason('');
    setCnError(null);
  };

  const handleConfirmCreditNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cnBill) return;
    const itemsToReturn = cnBill.items.map((it) => ({
      lineItemId: it.id,
      quantity: cnMode === 'full' ? it.quantity : cnQuantities[it.id] || 0,
    }));
    const res = issueCreditNote({
      billId: cnBill.id,
      itemsToReturn,
      isFull: cnMode === 'full',
      reason: cnReason,
    });
    if (!res.ok) {
      setCnError(res.error || 'Error');
      return;
    }
    setCnBill(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-xl font-bold">{t(lang, 'billsTitle')}</h1>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
        <div className={`${isOwner ? 'sm:col-span-5' : 'sm:col-span-8'} relative`}>
          <Search className="w-4 h-4 text-muted-foreground absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t(lang, 'searchBillPlaceholder')}
            className="w-full min-h-[44px] ps-10 pe-3 rounded-xl border border-input bg-card text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {isOwner && (
          <div className="sm:col-span-4">
            <SelectSheet
              value={cashierFilter}
              onChange={setCashierFilter}
              label={t(lang, 'filterByCashier')}
              options={[
                { value: 'ALL', label: t(lang, 'filterByCashier') },
                ...state.users.map((u) => ({ value: u.id, label: u.name })),
              ]}
            />
          </div>
        )}

        <div className={`${isOwner ? 'sm:col-span-3' : 'sm:col-span-4'}`}>
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            aria-label={t(lang, 'filterByDate')}
            className="w-full min-h-[44px] px-3 rounded-xl border border-input bg-card text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>

      {/* Bills List */}
      {visibleBills.length === 0 ? (
        <div className="p-10 rounded-2xl border border-dashed border-border text-center text-sm text-muted-foreground">
          {t(lang, 'noProductsFound')}
        </div>
      ) : (
        <div className="space-y-2.5">
          {visibleBills.map((bill) => {
            const locked = isDayLocked(bill.dayKey);
            const attachedNotes = state.creditNotes.filter((cn) => cn.billId === bill.id);
            return (
              <div
                key={bill.id}
                className="p-4 rounded-2xl bg-card border border-border flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-sm font-bold">{bill.billNumber}</span>
                    {bill.isCancelled && (
                      <span className="text-xs font-semibold text-destructive">
                        · {t(lang, 'billCancelledLabel')}
                      </span>
                    )}
                    {bill.editedAt && !bill.isCancelled && (
                      <span className="text-xs font-medium text-amber-600 dark:text-amber-400">
                        · {t(lang, 'billEditedLabel')}
                      </span>
                    )}
                    {bill.paymentType === 'credit' && (
                      <span className="text-xs font-semibold text-primary">
                        · {t(lang, 'creditSaleLabel')} ({bill.customerName})
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-2">
                    <span>{new Date(bill.date).toLocaleString(lang === 'ar' ? 'ar-DZ' : 'fr-FR')}</span>
                    <span aria-hidden="true">·</span>
                    <span>{bill.cashierName}</span>
                    <span aria-hidden="true">·</span>
                    <span>{bill.items.length} art.</span>
                  </div>
                  {attachedNotes.length > 0 && (
                    <div className="text-xs font-mono text-destructive">
                      {attachedNotes
                        .map((cn) => `${cn.creditNoteNumber} (-${formatDA(cn.totalRefund, lang)})`)
                        .join(' · ')}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                  <span className="text-base font-bold font-mono tabular-nums">
                    {formatDA(bill.total, lang)}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setReceiptBill(bill)}
                      aria-label={t(lang, 'printReceipt')}
                      className="press min-h-[44px] min-w-[44px] sm:min-h-[36px] sm:min-w-[36px] rounded-xl border border-border bg-background hover:bg-muted flex items-center justify-center"
                    >
                      <Printer className="w-4 h-4" />
                    </button>

                    {isOwner && !locked && !bill.isCancelled && (
                      <>
                        <button
                          type="button"
                          onClick={() => openEditModal(bill)}
                          aria-label={t(lang, 'editBill')}
                          className="press min-h-[44px] min-w-[44px] sm:min-h-[36px] sm:min-w-[36px] rounded-xl border border-border bg-background hover:bg-muted flex items-center justify-center"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openCreditNoteModal(bill)}
                          aria-label={t(lang, 'cancelCreditNote')}
                          className="press min-h-[44px] min-w-[44px] sm:min-h-[36px] sm:min-w-[36px] rounded-xl border border-border bg-background hover:bg-destructive/10 text-destructive flex items-center justify-center"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Owner Edit Bill Modal (with Adding New Products + Camera Barcode Search!) */}
      <ModalDrawer
        open={Boolean(editingBill)}
        onClose={() => setEditingBill(null)}
        title={editingBill ? `${t(lang, 'editBill')} · ${editingBill.billNumber}` : ''}
      >
        {editingBill && (
          <form onSubmit={handleSaveEditBill} className="space-y-4">
            {/* Add product via search or camera barcode inside bill edit */}
            <div className="p-3 rounded-2xl bg-muted/40 border border-border space-y-2.5">
              <div className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'addProductToBill')}
              </div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-muted-foreground absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={addProdSearch}
                    onChange={(e) => setAddProdSearch(e.target.value)}
                    placeholder={t(lang, 'searchProductPlaceholder')}
                    className="w-full min-h-[44px] ps-9 pe-3 rounded-xl border border-input bg-background text-sm"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setEditScannerOpen(true)}
                  aria-label={t(lang, 'scanWithCamera')}
                  className="press min-h-[44px] px-3.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1.5 shrink-0"
                >
                  <QrCode className="w-4 h-4" />
                  <span>{t(lang, 'scanWithCamera')}</span>
                </button>
              </div>

              {addProdSearch.trim() && (
                <div className="space-y-1 max-h-40 overflow-y-auto scroll-pane">
                  {matchingAddProducts.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => addProductToEditedBill(p)}
                      className="press w-full min-h-[44px] px-3 py-2 rounded-xl bg-card border border-border hover:bg-accent/40 flex items-center justify-between text-start text-xs"
                    >
                      <span className="font-semibold truncate">
                        {p.name}
                        {p.variantLabel ? ` (${p.variantLabel})` : ''}
                      </span>
                      <span className="font-mono font-bold text-primary shrink-0">
                        + {formatDA(p.sellingPrice, lang)}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Editable Line Items */}
            <div className="space-y-2">
              {editItems.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-xl border border-border bg-background flex items-center justify-between gap-2"
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold truncate">{item.name}</div>
                    <div className="text-xs text-muted-foreground font-mono">
                      {formatDA(item.unitPrice, lang)}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      aria-label="Decrease quantity"
                      onClick={() =>
                        setEditItems((prev) =>
                          prev
                            .map((it) => {
                              if (it.id !== item.id) return it;
                              const nextQty = Math.max(0, Math.round((it.quantity - 1) * 1000) / 1000);
                              return nextQty <= 0
                                ? null
                                : {
                                    ...it,
                                    quantity: nextQty,
                                    total: Math.round(nextQty * it.unitPrice * 100) / 100,
                                  };
                            })
                            .filter((x): x is BillLineItem => x !== null)
                        )
                      }
                      className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl border border-border flex items-center justify-center"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="min-w-[36px] text-center font-mono text-xs font-bold tabular-nums">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      aria-label="Increase quantity"
                      onClick={() =>
                        setEditItems((prev) =>
                          prev.map((it) => {
                            if (it.id !== item.id) return it;
                            const nextQty = Math.round((it.quantity + 1) * 1000) / 1000;
                            return {
                              ...it,
                              quantity: nextQty,
                              total: Math.round(nextQty * it.unitPrice * 100) / 100,
                            };
                          })
                        )
                      }
                      className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl border border-border flex items-center justify-center"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={t(lang, 'delete')}
                      onClick={() => setEditItems((prev) => prev.filter((x) => x.id !== item.id))}
                      className="min-h-[44px] min-w-[44px] sm:min-h-[34px] sm:min-w-[34px] rounded-xl text-destructive hover:bg-destructive/10 flex items-center justify-center"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-border">
              <span className="text-sm font-medium text-muted-foreground">{t(lang, 'total')}</span>
              <span className="text-xl font-bold font-mono tabular-nums text-primary">
                {formatDA(
                  editItems.reduce((s, it) => s + it.total, 0),
                  lang
                )}
              </span>
            </div>

            {editError && <p className="text-xs font-semibold text-destructive">{editError}</p>}

            <button
              type="submit"
              className="press w-full min-h-[48px] rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
            >
              {t(lang, 'save')} &amp; {t(lang, 'printReceipt')}
            </button>
          </form>
        )}
      </ModalDrawer>

      {/* Camera Barcode Scanner inside Bill Editing */}
      <BarcodeScannerModal
        open={editScannerOpen}
        onClose={() => setEditScannerOpen(false)}
        onDetected={handleEditBarcodeDetected}
        language={lang}
      />

      {/* Credit Note (Partial or Full Cancellation) Modal */}
      <ModalDrawer
        open={Boolean(cnBill)}
        onClose={() => setCnBill(null)}
        title={cnBill ? `${t(lang, 'creditNoteTitle')} · ${cnBill.billNumber}` : ''}
      >
        {cnBill && (
          <form onSubmit={handleConfirmCreditNote} className="space-y-4">
            <div className="flex p-1 rounded-xl bg-muted border border-border">
              <button
                type="button"
                onClick={() => setCnMode('full')}
                className={`flex-1 min-h-[40px] rounded-lg text-xs font-semibold ${
                  cnMode === 'full' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'
                }`}
              >
                {t(lang, 'creditNoteFull')}
              </button>
              <button
                type="button"
                onClick={() => setCnMode('partial')}
                className={`flex-1 min-h-[40px] rounded-lg text-xs font-semibold ${
                  cnMode === 'partial'
                    ? 'bg-card text-foreground shadow-sm'
                    : 'text-muted-foreground'
                }`}
              >
                {t(lang, 'creditNotePartial')}
              </button>
            </div>

            {cnMode === 'partial' && (
              <div className="space-y-2">
                {cnBill.items.map((it) => (
                  <div
                    key={it.id}
                    className="p-3 rounded-xl border border-border flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-semibold truncate">{it.name}</div>
                      <div className="text-xs text-muted-foreground font-mono">
                        Max: {it.quantity} · {formatDA(it.unitPrice, lang)}
                      </div>
                    </div>
                    <input
                      type="number"
                      step="any"
                      min={0}
                      max={it.quantity}
                      value={cnQuantities[it.id] ?? 0}
                      onChange={(e) =>
                        setCnQuantities((prev) => ({
                          ...prev,
                          [it.id]: Math.min(it.quantity, Math.max(0, parseFloat(e.target.value) || 0)),
                        }))
                      }
                      aria-label={t(lang, 'returnQty')}
                      className="w-24 min-h-[44px] px-3 rounded-xl border border-input bg-background text-sm font-mono text-end"
                    />
                  </div>
                ))}
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(lang, 'notesLabel')}
              </label>
              <input
                type="text"
                value={cnReason}
                onChange={(e) => setCnReason(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm"
              />
            </div>

            {cnError && <p className="text-xs text-destructive font-semibold">{cnError}</p>}

            <button
              type="submit"
              className="press w-full min-h-[48px] rounded-xl bg-destructive text-destructive-foreground font-semibold text-sm"
            >
              {t(lang, 'confirmCreditNote')}
            </button>
          </form>
        )}
      </ModalDrawer>

      {state.shop && (
        <ReceiptModal
          bill={receiptBill}
          shop={state.shop}
          creditNotes={state.creditNotes}
          language={lang}
          onClose={() => setReceiptBill(null)}
        />
      )}
    </div>
  );
}
