import React, { useState } from 'react';
import { Store, Upload, X, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Language } from '../types/pos';
import { t } from '../lib/i18n';
import { setAppLanguage, setupShop } from '../lib/store';

interface OnboardingWizardProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

export function OnboardingWizard({ language, onLanguageChange }: OnboardingWizardProps) {
  const [shopName, setShopName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [ownerPin, setOwnerPin] = useState('');
  const [lowStockThreshold, setLowStockThreshold] = useState('5');
  const [logoDataUrl, setLogoDataUrl] = useState<string | undefined>(undefined);
  const [seedDemo, setSeedDemo] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxSide = 160;
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          setLogoDataUrl(canvas.toDataURL('image/png'));
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!shopName.trim() || !ownerName.trim()) {
      setError(t(language, 'requiredField'));
      return;
    }
    if (!/^\d{4,6}$/.test(ownerPin.trim())) {
      setError(t(language, 'pinValidationErr'));
      return;
    }
    setupShop({
      shopName,
      ownerName,
      address,
      phone,
      logoDataUrl,
      ownerPin,
      lowStockThreshold: Number(lowStockThreshold) || 5,
      seedDemo,
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col justify-center py-8 px-4 pt-[calc(1.5rem+env(safe-area-inset-top))] pb-[calc(2rem+env(safe-area-inset-bottom))]">
      <div className="w-full max-w-xl mx-auto bg-card border border-border rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                {t(language, 'onboardingTitle')}
              </h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                {t(language, 'onboardingSubtitle')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 p-1 rounded-xl bg-muted shrink-0">
            {(['fr', 'ar', 'en'] as Language[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => {
                  onLanguageChange(lang);
                  setAppLanguage(lang);
                }}
                className={`min-h-[36px] px-2.5 rounded-lg text-xs font-semibold uppercase transition-colors ${
                  language === lang
                    ? 'bg-card text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(language, 'shopName')} *
              </label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="Épicerie Ali"
                required
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(language, 'ownerFullName')} *
              </label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="Ali Mansouri"
                required
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(language, 'address')}
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Rue Didouche Mourad, Alger"
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(language, 'phone')}
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0550 00 00 00"
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(language, 'ownerPin')} *
              </label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={ownerPin}
                onChange={(e) => setOwnerPin(e.target.value.replace(/\D/g, ''))}
                placeholder="1234"
                required
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">
                {t(language, 'lowStockDefault')}
              </label>
              <input
                type="number"
                min={1}
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl border border-border bg-muted/40">
            <div className="flex items-center gap-3">
              {logoDataUrl ? (
                <img
                  src={logoDataUrl}
                  alt="Shop logo"
                  className="w-12 h-12 rounded-xl object-contain bg-white border border-border"
                />
              ) : (
                <div className="w-12 h-12 rounded-xl bg-background border border-border flex items-center justify-center text-muted-foreground">
                  <Upload className="w-5 h-5" />
                </div>
              )}
              <div>
                <div className="text-sm font-medium">{t(language, 'shopLogo')}</div>
                <div className="text-xs text-muted-foreground">PNG / JPG · 58mm Receipt</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {logoDataUrl && (
                <button
                  type="button"
                  onClick={() => setLogoDataUrl(undefined)}
                  aria-label={t(language, 'removeLogo')}
                  className="min-h-[44px] px-3 rounded-xl border border-border text-xs font-medium hover:bg-muted flex items-center gap-1"
                >
                  <X className="w-4 h-4" />
                  <span>{t(language, 'removeLogo')}</span>
                </button>
              )}
              <label className="press min-h-[44px] px-4 rounded-xl bg-secondary text-secondary-foreground text-xs font-semibold flex items-center gap-2 cursor-pointer">
                <Upload className="w-4 h-4" />
                <span>{t(language, 'uploadLogo')}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSeedDemo((v) => !v)}
            className="w-full min-h-[48px] px-4 py-3 rounded-2xl border border-border bg-background hover:bg-muted/50 flex items-center justify-between gap-3 text-start transition-colors"
          >
            <div className="flex items-center gap-3">
              <CheckCircle2
                className={`w-5 h-5 shrink-0 ${seedDemo ? 'text-primary' : 'text-muted-foreground'}`}
              />
              <span className="text-sm font-medium">{t(language, 'seedDemoData')}</span>
            </div>
            <span className="text-xs font-semibold text-primary">
              {seedDemo ? 'ON' : 'OFF'}
            </span>
          </button>

          {error && (
            <div className="p-3 rounded-xl bg-destructive/10 text-destructive text-sm font-medium">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="press w-full min-h-[48px] px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2 shadow-sm hover:opacity-95 transition-opacity"
          >
            <ShieldCheck className="w-5 h-5" />
            <span>{t(language, 'createShopBtn')}</span>
          </button>
        </form>
      </div>
    </div>
  );
}
