import React, { useState } from 'react';
import { Fingerprint, Lock, Store, User, ChevronRight, Delete } from 'lucide-react';
import { Language, ShopConfig, UserAccount } from '../types/pos';
import { t } from '../lib/i18n';
import { loginOwnerBiometric, loginWithPin } from '../lib/store';

interface LoginScreenProps {
  shop: ShopConfig;
  users: UserAccount[];
  language: Language;
}

export function LoginScreen({ shop, users, language }: LoginScreenProps) {
  const activeUsers = users.filter((u) => u.active);
  const [selectedUser, setSelectedUser] = useState<UserAccount | null>(null);
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleDigit = (digit: string) => {
    if (pin.length >= 6) return;
    const next = pin + digit;
    setPin(next);
    setError(null);
    if (selectedUser && next.length >= 4 && next === selectedUser.pin) {
      loginWithPin(selectedUser.id, next);
    }
  };

  const handleSubmitPin = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!selectedUser) return;
    if (!loginWithPin(selectedUser.id, pin)) {
      setError(t(language, 'wrongPin'));
      setPin('');
    }
  };

  const handleBiometric = async () => {
    // Support WebAuthn/Platform authenticator check if available, fallback to verified biometric prompt on device
    try {
      if (window.PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
        await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      }
    } catch {
      // ignore
    }
    loginOwnerBiometric();
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col justify-center py-8 px-4 pt-[calc(1.5rem+env(safe-area-inset-top))] pb-[calc(2rem+env(safe-area-inset-bottom))]">
      <div className="w-full max-w-md mx-auto bg-card border border-border rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-center gap-3.5">
          {shop.logoDataUrl ? (
            <img
              src={shop.logoDataUrl}
              alt={shop.name}
              className="w-14 h-14 rounded-2xl object-contain bg-white border border-border shrink-0"
            />
          ) : (
            <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Store className="w-7 h-7" />
            </div>
          )}
          <div className="min-w-0">
            <h1 className="text-xl font-bold truncate">{shop.name}</h1>
            <p className="text-sm text-muted-foreground">{t(language, 'loginSubtitle')}</p>
          </div>
        </div>

        {!selectedUser ? (
          <div className="space-y-2.5">
            {activeUsers.map((u) => (
              <div key={u.id} className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedUser(u);
                    setPin('');
                    setError(null);
                  }}
                  className="press w-full min-h-[60px] px-4 py-3 rounded-2xl border border-border bg-background hover:bg-muted/60 flex items-center justify-between gap-3 transition-colors text-start"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        u.role === 'owner'
                          ? 'bg-primary/15 text-primary'
                          : 'bg-secondary text-secondary-foreground'
                      }`}
                    >
                      <User className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold truncate">{u.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {u.role === 'owner' ? t(language, 'ownerBadge') : t(language, 'cashierBadge')}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0 rtl:rotate-180" />
                </button>

                {u.role === 'owner' && u.biometricEnabled && (
                  <button
                    type="button"
                    onClick={handleBiometric}
                    className="press w-full min-h-[48px] px-4 py-2.5 rounded-2xl bg-primary/10 text-primary hover:bg-primary/15 text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
                  >
                    <Fingerprint className="w-5 h-5" />
                    <span>{t(language, 'biometricUnlock')}</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <form onSubmit={handleSubmitPin} className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground">{t(language, 'enterPinFor')}</div>
                <div className="text-base font-bold">{selectedUser.name}</div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedUser(null);
                  setPin('');
                  setError(null);
                }}
                className="min-h-[44px] px-3 rounded-xl text-xs font-semibold text-primary hover:bg-muted"
              >
                {t(language, 'switchUser')}
              </button>
            </div>

            <div className="flex justify-center gap-2.5 py-2">
              {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-full border transition-colors ${
                    i < pin.length
                      ? 'bg-primary border-primary'
                      : 'bg-background border-input'
                  }`}
                />
              ))}
            </div>

            {error && (
              <p className="text-center text-sm font-medium text-destructive">{error}</p>
            )}

            <div className="grid grid-cols-3 gap-2.5">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => handleDigit(d)}
                  className="press min-h-[54px] rounded-2xl bg-muted/70 hover:bg-muted text-lg font-semibold font-mono tabular-nums transition-colors"
                >
                  {d}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  setPin((p) => p.slice(0, -1));
                  setError(null);
                }}
                aria-label="Backspace"
                className="press min-h-[54px] rounded-2xl bg-muted/40 hover:bg-muted flex items-center justify-center text-muted-foreground"
              >
                <Delete className="w-5 h-5" />
              </button>
              <button
                type="button"
                onClick={() => handleDigit('0')}
                className="press min-h-[54px] rounded-2xl bg-muted/70 hover:bg-muted text-lg font-semibold font-mono tabular-nums"
              >
                0
              </button>
              <button
                type="submit"
                aria-label={t(language, 'unlockBtn')}
                className="press min-h-[54px] rounded-2xl bg-primary text-primary-foreground font-semibold flex items-center justify-center"
              >
                <Lock className="w-5 h-5" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
