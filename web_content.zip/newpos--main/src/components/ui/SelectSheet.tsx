import React, { useState } from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';

export interface SelectOption {
  value: string;
  label: string;
  sublabel?: string;
}

interface SelectSheetProps {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  label?: string;
  searchable?: boolean;
  className?: string;
  disabled?: boolean;
  ariaLabel?: string;
}

export function SelectSheet({
  value,
  onChange,
  options,
  placeholder = 'Select...',
  label,
  searchable = false,
  className = '',
  disabled = false,
  ariaLabel,
}: SelectSheetProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const reduceMotion = useReducedMotion();

  const selected = options.find((o) => o.value === value);
  const filtered = query.trim()
    ? options.filter(
        (o) =>
          o.label.toLowerCase().includes(query.toLowerCase()) ||
          (o.sublabel && o.sublabel.toLowerCase().includes(query.toLowerCase()))
      )
    : options;

  return (
    <>
      <button
        type="button"
        disabled={disabled}
        aria-label={ariaLabel || label || placeholder}
        aria-expanded={open}
        onClick={() => {
          if (!disabled) {
            setQuery('');
            setOpen(true);
          }
        }}
        className={`press flex items-center justify-between gap-2 w-full min-h-[44px] sm:min-h-[40px] px-3.5 py-2 text-sm rounded-xl border border-input bg-card text-foreground hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring transition-colors disabled:opacity-50 ${className}`}
      >
        <span className={`truncate text-start ${selected ? 'text-foreground' : 'text-muted-foreground'}`}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown className="w-4 h-4 shrink-0 text-muted-foreground" />
      </button>

      <AnimatePresence>
        {open && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: reduceMotion ? 0 : 0.15 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-[2px]"
            />
            <motion.div
              initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 24 }}
              transition={{ duration: reduceMotion ? 0 : 0.18, ease: [0.16, 1, 0.3, 1] }}
              className="relative z-10 w-full sm:max-w-md bg-popover text-popover-foreground rounded-t-3xl sm:rounded-2xl border border-border shadow-xl max-h-[80vh] flex flex-col pb-[env(safe-area-inset-bottom)]"
            >
              <div className="w-10 h-1.5 bg-muted-foreground/30 rounded-full mx-auto mt-3 mb-1 sm:hidden" />
              <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-border">
                <h3 className="text-base font-semibold truncate">{label || placeholder}</h3>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  aria-label="Close"
                  className="min-h-[44px] min-w-[44px] sm:min-h-[36px] sm:min-w-[36px] flex items-center justify-center rounded-xl hover:bg-muted text-muted-foreground"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {(searchable || options.length > 7) && (
                <div className="p-3 border-b border-border">
                  <div className="relative">
                    <Search className="w-4 h-4 text-muted-foreground absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="..."
                      className="w-full min-h-[44px] sm:min-h-[38px] ps-9 pe-3 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>
              )}

              <div className="overflow-y-auto scroll-pane p-2 space-y-1">
                {filtered.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-6">—</p>
                ) : (
                  filtered.map((opt) => {
                    const isSelected = opt.value === value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => {
                          onChange(opt.value);
                          setOpen(false);
                        }}
                        className={`press w-full min-h-[48px] sm:min-h-[42px] px-3.5 py-2.5 rounded-xl flex items-center justify-between gap-3 text-start transition-colors ${
                          isSelected
                            ? 'bg-accent text-accent-foreground font-semibold'
                            : 'hover:bg-muted text-foreground'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="text-sm truncate">{opt.label}</div>
                          {opt.sublabel && (
                            <div className="text-xs text-muted-foreground truncate">{opt.sublabel}</div>
                          )}
                        </div>
                        {isSelected && <Check className="w-4 h-4 shrink-0 text-primary" />}
                      </button>
                    );
                  })
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
