import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Camera, Keyboard, QrCode } from 'lucide-react';
import { ModalDrawer } from './ui/ModalDrawer';
import { Language } from '../types/pos';
import { t } from '../lib/i18n';

interface BarcodeScannerModalProps {
  open: boolean;
  onClose: () => void;
  onDetected: (code: string) => void;
  language: Language;
  title?: string;
}

export function BarcodeScannerModal({
  open,
  onClose,
  onDetected,
  language,
  title,
}: BarcodeScannerModalProps) {
  const [manualCode, setManualCode] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const detectedRef = useRef(false);
  const readerElementId = 'khazna-qr-barcode-reader';

  useEffect(() => {
    if (!open) return;
    detectedRef.current = false;
    setCameraError(null);
    setManualCode('');
    setIsStarting(true);

    let active = true;
    const startTimer = setTimeout(async () => {
      try {
        const html5Qr = new Html5Qrcode(readerElementId);
        scannerRef.current = html5Qr;
        await html5Qr.start(
          { facingMode: 'environment' },
          {
            fps: 10,
            qrbox: { width: 240, height: 150 },
            aspectRatio: 1.333,
          },
          (decodedText) => {
            if (!active || detectedRef.current) return;
            detectedRef.current = true;
            onDetected(decodedText.trim());
            onClose();
          },
          () => {
            // ignore frame decode misses
          }
        );
        if (active) setIsStarting(false);
      } catch (err) {
        if (active) {
          setIsStarting(false);
          setCameraError(
            err instanceof Error
              ? err.message
              : 'Caméra indisponible — utilisez la saisie manuelle ci-dessous.'
          );
        }
      }
    }, 150);

    return () => {
      active = false;
      clearTimeout(startTimer);
      const instance = scannerRef.current;
      scannerRef.current = null;
      if (instance) {
        instance
          .stop()
          .then(() => instance.clear())
          .catch(() => {});
      }
    };
  }, [open, onClose, onDetected]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    onDetected(manualCode.trim());
    onClose();
  };

  return (
    <ModalDrawer
      open={open}
      onClose={onClose}
      title={title || t(language, 'scanBarcodeQr')}
      maxWidthClass="sm:max-w-md"
    >
      <div className="space-y-4">
        <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-border min-h-[220px] flex items-center justify-center">
          <div id={readerElementId} className="w-full" />
          {isStarting && !cameraError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-slate-300 bg-slate-950/80">
              <Camera className="w-7 h-7" />
              <span className="text-xs">Initialisation caméra (Code-barres &amp; QR)...</span>
            </div>
          )}
          {cameraError && (
            <div className="p-6 text-center space-y-2 text-slate-300">
              <QrCode className="w-8 h-8 mx-auto text-slate-400" />
              <p className="text-xs text-slate-300">{cameraError}</p>
            </div>
          )}
        </div>

        <form onSubmit={handleManualSubmit} className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
            <Keyboard className="w-3.5 h-3.5" />
            <span>{t(language, 'barcodeLabel')}</span>
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="6130001000011..."
              autoFocus
              className="flex-1 min-h-[44px] px-3.5 rounded-xl border border-input bg-background text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              className="press min-h-[44px] px-4 rounded-xl bg-primary text-primary-foreground text-sm font-semibold whitespace-nowrap shrink-0"
            >
              {t(language, 'confirm')}
            </button>
          </div>
        </form>
      </div>
    </ModalDrawer>
  );
}
