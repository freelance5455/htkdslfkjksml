import React, { useState } from 'react';
import { Bluetooth, FileDown, Printer } from 'lucide-react';
import { Bill, CreditNote, Language, ShopConfig } from '../types/pos';
import { formatDA, t } from '../lib/i18n';
import { downloadBillPdf, sendToBluetoothPrinter } from '../lib/export';
import { ModalDrawer } from './ui/ModalDrawer';

interface ReceiptModalProps {
  bill: Bill | null;
  shop: ShopConfig;
  creditNotes: CreditNote[];
  language: Language;
  onClose: () => void;
}

export function ReceiptModal({
  bill,
  shop,
  creditNotes,
  language,
  onClose,
}: ReceiptModalProps) {
  const [btStatus, setBtStatus] = useState<string | null>(null);

  if (!bill) return null;
  const billNotes = creditNotes.filter((cn) => cn.billId === bill.id);

  const handleBluetoothPrint = async () => {
    setBtStatus(null);
    const res = await sendToBluetoothPrinter(bill, shop);
    setBtStatus(res.message);
  };

  return (
    <ModalDrawer
      open={Boolean(bill)}
      onClose={onClose}
      title={`${t(language, 'billNo')} ${bill.billNumber}`}
      maxWidthClass="sm:max-w-md"
    >
      <div className="space-y-4">
        {/* 58mm thermal receipt preview */}
        <div
          id="thermal-receipt-print"
          className="selectable-text mx-auto w-full max-w-[300px] bg-white text-slate-900 border border-slate-200 rounded-xl p-4 font-mono text-xs shadow-sm space-y-2.5"
        >
          <div className="text-center space-y-1 border-b border-dashed border-slate-300 pb-2.5">
            {shop.logoDataUrl && (
              <img
                src={shop.logoDataUrl}
                alt={shop.name}
                referrerPolicy="no-referrer"
                className="w-12 h-12 object-contain mx-auto rounded-md"
              />
            )}
            <div className="text-sm font-bold">{shop.name}</div>
            {shop.address && <div className="text-[11px] text-slate-600">{shop.address}</div>}
            {shop.phone && <div className="text-[11px] text-slate-600">{shop.phone}</div>}
          </div>

          <div className="space-y-0.5 text-[11px] border-b border-dashed border-slate-300 pb-2">
            <div className="flex justify-between gap-2">
              <span>{t(language, 'billNo')}:</span>
              <span className="font-semibold">{bill.billNumber}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span>{t(language, 'date')}:</span>
              <span>{new Date(bill.date).toLocaleString(language === 'ar' ? 'ar-DZ' : 'fr-FR')}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span>{t(language, 'cashier')}:</span>
              <span>{bill.cashierName}</span>
            </div>
            {bill.customerName && (
              <div className="flex justify-between gap-2">
                <span>Client:</span>
                <span>
                  {bill.customerName} ({bill.paymentType})
                </span>
              </div>
            )}
          </div>

          <div className="space-y-1.5 border-b border-dashed border-slate-300 pb-2.5">
            {bill.items.map((item) => (
              <div key={item.id} className="space-y-0.5">
                <div className="font-semibold leading-tight">{item.name}</div>
                <div className="flex justify-between text-[11px] text-slate-700 tabular-nums">
                  <span>
                    {item.quantity}{' '}
                    {item.unitType === 'KG' ? 'kg' : item.unitType === 'GRAM' ? 'g' : 'x'} ×{' '}
                    {formatDA(item.unitPrice, language)}
                  </span>
                  <span className="font-semibold text-slate-900">
                    {formatDA(item.total, language)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center text-sm font-bold tabular-nums pt-0.5">
            <span>{t(language, 'total').toUpperCase()}</span>
            <span>{formatDA(bill.total, language)}</span>
          </div>

          {billNotes.length > 0 && (
            <div className="border-t border-dashed border-slate-300 pt-2 space-y-1 text-[11px] text-red-700">
              {billNotes.map((cn) => (
                <div key={cn.id} className="flex justify-between">
                  <span>{cn.creditNoteNumber}</span>
                  <span>-{formatDA(cn.totalRefund, language)}</span>
                </div>
              ))}
            </div>
          )}

          <div
            dir="rtl"
            className="text-center pt-2 border-t border-dashed border-slate-300 text-xs font-semibold"
          >
            نشكركم على زيارتكم ومرحبا بكم
          </div>
        </div>

        {btStatus && (
          <p className="text-xs text-center text-muted-foreground bg-muted px-3 py-2 rounded-xl">
            {btStatus}
          </p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="press min-h-[44px] px-3 py-2.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold flex items-center justify-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>{t(language, 'printReceipt')}</span>
          </button>
          <button
            type="button"
            onClick={() => downloadBillPdf(bill, shop, billNotes)}
            className="press min-h-[44px] px-3 py-2.5 rounded-xl border border-border bg-secondary text-secondary-foreground text-xs font-semibold flex items-center justify-center gap-2"
          >
            <FileDown className="w-4 h-4" />
            <span>{t(language, 'downloadPdf')}</span>
          </button>
          <button
            type="button"
            onClick={handleBluetoothPrint}
            className="press min-h-[44px] px-3 py-2.5 rounded-xl border border-border bg-card text-foreground text-xs font-semibold flex items-center justify-center gap-2 hover:bg-muted"
          >
            <Bluetooth className="w-4 h-4" />
            <span>{t(language, 'bluetoothPrint')}</span>
          </button>
        </div>
      </div>
    </ModalDrawer>
  );
}
