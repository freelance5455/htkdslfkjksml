export type Language = 'fr' | 'ar' | 'en';
export type ThemeMode = 'light' | 'dark' | 'system';
export type UserRole = 'owner' | 'cashier';
export type UnitType = 'UNIT' | 'KG' | 'GRAM';

export interface UserAccount {
  id: string;
  name: string;
  role: UserRole;
  pin: string;
  active: boolean;
  biometricEnabled: boolean;
  createdAt: string;
}

export interface ShopConfig {
  name: string;
  ownerName: string;
  address: string;
  phone: string;
  logoDataUrl?: string;
  currency: 'DA';
  defaultLanguage: Language;
  lowStockThreshold: number;
  bluetoothPrinterName?: string;
  bluetoothPrinterId?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface Product {
  id: string;
  barcode: string;
  name: string;
  variantLabel?: string;
  parentGroup?: string;
  purchasePrice: number;
  sellingPrice: number;
  quantity: number;
  lowStockThreshold?: number;
  categoryId: string;
  unitType: UnitType;
  createdAt: string;
  updatedAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  notes: string;
}

export interface RestockLineItem {
  productId: string;
  productName: string;
  barcode: string;
  quantity: number;
  purchasePrice: number;
}

export interface SupplierPaymentRecord {
  id: string;
  amount: number;
  date: string;
  note?: string;
}

export interface RestockOrder {
  id: string;
  supplierId: string;
  supplierName: string;
  arrivalDate: string;
  billingDate: string;
  dueDate: string;
  lineItems: RestockLineItem[];
  totalAmount: number;
  paidAmount: number;
  status: 'pending' | 'received';
  paymentStatus: 'paid' | 'partial' | 'unpaid';
  notes: string;
  paymentHistory: SupplierPaymentRecord[];
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  notes: string;
  balanceOwed: number;
  createdAt: string;
}

export interface CustomerDebtPayment {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  date: string;
  dayKey: string;
  note?: string;
  recordedByUserId: string;
}

export interface BillLineItem {
  id: string;
  productId?: string;
  name: string;
  barcode?: string;
  unitType: UnitType | 'OTHER';
  quantity: number;
  purchasePrice: number;
  unitPrice: number;
  total: number;
  isOther?: boolean;
}

export interface Bill {
  id: string;
  billNumber: string;
  date: string;
  dayKey: string;
  cashierId: string;
  cashierName: string;
  items: BillLineItem[];
  subtotal: number;
  total: number;
  paymentType: 'cash' | 'credit';
  customerId?: string;
  customerName?: string;
  editedAt?: string;
  isCancelled?: boolean;
}

export interface CreditNoteLineItem {
  lineItemId: string;
  productId?: string;
  name: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface CreditNote {
  id: string;
  creditNoteNumber: string;
  billId: string;
  billNumber: string;
  date: string;
  dayKey: string;
  items: CreditNoteLineItem[];
  totalRefund: number;
  isFull: boolean;
  reason?: string;
  createdByUserId: string;
}

export interface DailyClosing {
  id: string;
  dayKey: string;
  closedAt: string;
  closedByUserId: string;
  totalSales: number;
  cashSales: number;
  creditSales: number;
  creditSalesCount: number;
  debtPaymentsTotal: number;
  totalRefunds: number;
  cogs: number;
  dailyGains: number;
  billCount: number;
  expectedCash: number;
  countedCash: number;
  cashDifference: number;
  openSupplierDebtAtClose: number;
  notes?: string;
}

export interface BackupRecord {
  id: string;
  dayKey: string;
  monthKey: string;
  createdAt: string;
  type: 'auto_close' | 'manual';
  filename: string;
  summary: {
    bills: number;
    sales: number;
    products: number;
  };
  snapshotJson: string;
}

export interface OwnerAlert {
  id: string;
  type: 'low_stock' | 'out_of_stock' | 'supplier_overdue' | 'customer_overdue';
  title: string;
  description: string;
  severity: 'warning' | 'critical';
  monthsElapsed?: number;
  entityId: string;
}

export interface PosState {
  shop: ShopConfig | null;
  users: UserAccount[];
  currentUserId: string | null;
  language: Language;
  categories: Category[];
  products: Product[];
  suppliers: Supplier[];
  restockOrders: RestockOrder[];
  customers: Customer[];
  customerDebtPayments: CustomerDebtPayment[];
  bills: Bill[];
  creditNotes: CreditNote[];
  dailyClosings: DailyClosing[];
  backups: BackupRecord[];
  monthlyCounter: {
    monthKey: string;
    lastCounter: number;
  };
}
