import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Calculator,
  LogOut,
  Package,
  Receipt,
  RefreshCw,
  Settings,
  ShoppingCart,
  Store,
  Users,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { ThemeProvider } from './components/ThemeProvider';
import { OnboardingWizard } from './components/OnboardingWizard';
import { LoginScreen } from './components/LoginScreen';
import { PosScreen } from './screens/PosScreen';
import { BillsScreen } from './screens/BillsScreen';
import { StockScreen } from './screens/StockScreen';
import { DebtsScreen } from './screens/DebtsScreen';
import { ClosingScreen } from './screens/ClosingScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { ModalDrawer } from './components/ui/ModalDrawer';
import { t } from './lib/i18n';
import {
  getOwnerAlerts,
  logoutUser,
  refreshStoreFromStorage,
  setAppLanguage,
  usePosStore,
} from './lib/store';

type TabKey = 'pos' | 'bills' | 'stock' | 'debts' | 'closing' | 'settings';

function PosShell() {
  const state = usePosStore();
  const lang = state.language;
  const reduceMotion = useReducedMotion();

  const [activeTab, setActiveTab] = useState<TabKey>(() => {
    const hash = window.location.hash.replace('#/', '') as TabKey;
    if (['pos', 'bills', 'stock', 'debts', 'closing', 'settings'].includes(hash)) {
      return hash;
    }
    return 'pos';
  });

  // Per-tab remembered sub-state (re-tapping active tab resets to root)
  const [posCategoryId, setPosCategoryId] = useState<string | null>(null);
  const [debtsSubTab, setDebtsSubTab] = useState<'customers' | 'suppliers'>('customers');

  const [alertsOpen, setAlertsOpen] = useState(false);

  // Pull-to-refresh state on main scrollable pane
  const scrollPaneRef = useRef<HTMLDivElement | null>(null);
  const pullStartYRef = useRef<number | null>(null);
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Keep HTML dir & lang synced for Arabic RTL
  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const currentUser = useMemo(
    () => state.users.find((u) => u.id === state.currentUserId && u.active) ?? null,
    [state.users, state.currentUserId]
  );

  const isOwner = currentUser?.role === 'owner';

  // Ensure cashier cannot stay on owner-only tabs
  useEffect(() => {
    if (currentUser && !isOwner && activeTab !== 'pos' && activeTab !== 'bills') {
      setActiveTab('pos');
    }
  }, [currentUser, isOwner, activeTab]);

  // Sync URL hash
  useEffect(() => {
    const sub =
      activeTab === 'pos' && posCategoryId
        ? `?cat=${posCategoryId}`
        : activeTab === 'debts'
          ? `?tab=${debtsSubTab}`
          : '';
    const nextHash = `#/${activeTab}${sub}`;
    if (window.location.hash !== nextHash) {
      window.history.replaceState(null, '', nextHash);
    }
  }, [activeTab, posCategoryId, debtsSubTab]);

  const ownerAlerts = useMemo(
    () => (isOwner && state.shop ? getOwnerAlerts() : []),
    [isOwner, state.shop, state.products, state.restockOrders, state.customers, state.bills]
  );

  // First-launch onboarding wizard
  if (!state.shop) {
    return (
      <OnboardingWizard
        language={lang}
        onLanguageChange={(next) => setAppLanguage(next)}
      />
    );
  }

  // Login screen
  if (!currentUser) {
    return <LoginScreen shop={state.shop} users={state.users} language={lang} />;
  }

  const tabs: Array<{ key: TabKey; label: string; icon: React.ComponentType<{ className?: string }> }> =
    isOwner
      ? [
          { key: 'pos', label: t(lang, 'tabPos'), icon: ShoppingCart },
          { key: 'bills', label: t(lang, 'tabBills'), icon: Receipt },
          { key: 'stock', label: t(lang, 'tabStock'), icon: Package },
          { key: 'debts', label: t(lang, 'tabDebts'), icon: Users },
          { key: 'closing', label: t(lang, 'tabClosing'), icon: Calculator },
          { key: 'settings', label: t(lang, 'tabSettings'), icon: Settings },
        ]
      : [
          { key: 'pos', label: t(lang, 'tabPos'), icon: ShoppingCart },
          { key: 'bills', label: t(lang, 'tabBills'), icon: Receipt },
        ];

  const handleTabPress = (tabKey: TabKey) => {
    if (tabKey === activeTab) {
      // Re-tap active tab: reset to that tab's root!
      if (tabKey === 'pos') setPosCategoryId(null);
      if (tabKey === 'debts') setDebtsSubTab('customers');
      scrollPaneRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setActiveTab(tabKey);
    }
  };

  // Pull-to-refresh touch handlers on main scrollable pane
  const handleTouchStart = (e: React.TouchEvent) => {
    if (scrollPaneRef.current && scrollPaneRef.current.scrollTop <= 0) {
      pullStartYRef.current = e.touches[0].clientY;
    } else {
      pullStartYRef.current = null;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (pullStartYRef.current === null || isRefreshing) return;
    const delta = e.touches[0].clientY - pullStartYRef.current;
    if (delta > 0 && scrollPaneRef.current && scrollPaneRef.current.scrollTop <= 0) {
      setPullDistance(Math.min(76, delta * 0.45));
    }
  };

  const handleTouchEnd = () => {
    if (pullDistance >= 52 && !isRefreshing) {
      setIsRefreshing(true);
      refreshStoreFromStorage();
      setTimeout(() => {
        setIsRefreshing(false);
        setPullDistance(0);
      }, 320);
    } else {
      setPullDistance(0);
    }
    pullStartYRef.current = null;
  };

  return (
    <div className="h-[100dvh] flex flex-col bg-background text-foreground overflow-hidden">
      {/* Top App Bar with safe-area-inset-top & horizontal safe-area padding */}
      <header className="shrink-0 z-30 bg-card/90 backdrop-blur-md border-b border-border pt-[env(safe-area-inset-top)] px-[max(1rem,env(safe-area-inset-left))] pe-[max(1rem,env(safe-area-inset-right))]">
        <div className="h-14 flex items-center justify-between gap-4 max-w-7xl mx-auto">
          <div className="flex items-center gap-2.5 min-w-0">
            {state.shop.logoDataUrl ? (
              <img
                src={state.shop.logoDataUrl}
                alt={state.shop.name}
                className="w-8 h-8 rounded-lg object-contain bg-white border border-border shrink-0"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                <Store className="w-4 h-4" />
              </div>
            )}
            <span className="text-base font-bold truncate">{state.shop.name}</span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {isOwner && (
              <button
                type="button"
                onClick={() => setAlertsOpen(true)}
                aria-label={t(lang, 'alertsTitle')}
                className="relative min-h-[44px] min-w-[44px] sm:min-h-[38px] sm:min-w-[38px] rounded-xl hover:bg-muted flex items-center justify-center"
              >
                <Bell className="w-5 h-5" />
                {ownerAlerts.length > 0 && (
                  <span className="absolute top-1.5 end-1.5 min-w-[16px] h-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[11px] font-bold flex items-center justify-center tabular-nums">
                    {ownerAlerts.length}
                  </span>
                )}
              </button>
            )}

            <span className="hidden sm:inline text-xs font-medium text-muted-foreground px-2 truncate max-w-[140px]">
              {currentUser.name}
            </span>

            <button
              type="button"
              onClick={logoutUser}
              aria-label={t(lang, 'logout')}
              className="press min-h-[44px] min-w-[44px] sm:min-h-[38px] sm:px-3 rounded-xl hover:bg-muted flex items-center justify-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">{t(lang, 'logout')}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace (Sidebar on Desktop + Scrollable Pane) */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex flex-col w-56 shrink-0 border-e border-border bg-sidebar p-3 gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => handleTabPress(tab.key)}
                className={`press w-full min-h-[44px] px-3.5 rounded-xl flex items-center gap-3 text-sm font-semibold transition-colors ${
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-sidebar-foreground hover:bg-muted'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Scrollable Content Pane with Pull-to-Refresh */}
        <main
          ref={scrollPaneRef}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          className="flex-1 overflow-y-auto scroll-pane relative"
        >
          {/* Pull-to-refresh indicator */}
          {(pullDistance > 8 || isRefreshing) && (
            <div
              style={{ height: isRefreshing ? 44 : pullDistance }}
              className="flex items-center justify-center gap-2 text-xs font-medium text-muted-foreground overflow-hidden transition-all"
            >
              <RefreshCw
                className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-primary' : ''}`}
              />
              <span>
                {isRefreshing
                  ? t(lang, 'refreshing')
                  : pullDistance >= 52
                    ? t(lang, 'releaseToRefresh')
                    : t(lang, 'pullToRefresh')}
              </span>
            </div>
          )}

          <div className="max-w-6xl mx-auto p-4 sm:p-6 pb-36 md:pb-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={reduceMotion ? false : { opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduceMotion ? undefined : { opacity: 0, y: -6 }}
                transition={{ duration: reduceMotion ? 0 : 0.18, ease: [0.16, 1, 0.3, 1] }}
              >
                {activeTab === 'pos' && (
                  <PosScreen
                    state={state}
                    currentUser={currentUser}
                    selectedCategoryId={posCategoryId}
                    onSelectCategory={setPosCategoryId}
                  />
                )}
                {activeTab === 'bills' && (
                  <BillsScreen state={state} currentUser={currentUser} />
                )}
                {activeTab === 'stock' && isOwner && <StockScreen state={state} />}
                {activeTab === 'debts' && isOwner && (
                  <DebtsScreen
                    state={state}
                    subTab={debtsSubTab}
                    onSubTabChange={setDebtsSubTab}
                  />
                )}
                {activeTab === 'closing' && isOwner && <ClosingScreen state={state} />}
                {activeTab === 'settings' && isOwner && <SettingsScreen state={state} />}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Mobile Bottom Tab Bar with pb-[env(safe-area-inset-bottom)] */}
      <nav
        aria-label="Primary Navigation"
        className="md:hidden shrink-0 z-40 bg-card/95 backdrop-blur-md border-t border-border pb-[env(safe-area-inset-bottom)]"
      >
        <div
          className="grid items-center h-16"
          style={{ gridTemplateColumns: `repeat(${tabs.length}, minmax(0, 1fr))` }}
        >
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => handleTabPress(tab.key)}
                className={`press min-h-[48px] flex flex-col items-center justify-center gap-0.5 px-1 transition-colors ${
                  isActive ? 'text-primary font-bold' : 'text-muted-foreground font-medium'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs leading-tight truncate max-w-full">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Owner Alerts Drawer (Low Stock, Empty Stock, 1-month+ Unpaid Supplier & Customer Invoices) */}
      <ModalDrawer
        open={alertsOpen}
        onClose={() => setAlertsOpen(false)}
        title={t(lang, 'alertsTitle')}
        maxWidthClass="sm:max-w-md"
      >
        {ownerAlerts.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            {t(lang, 'noAlerts')}
          </p>
        ) : (
          <div className="space-y-2.5">
            {ownerAlerts.map((al) => (
              <div
                key={al.id}
                className={`p-3.5 rounded-2xl border flex items-start gap-3 ${
                  al.severity === 'critical'
                    ? 'bg-destructive/10 border-destructive/25'
                    : 'bg-amber-500/10 border-amber-500/25'
                }`}
              >
                <AlertTriangle
                  className={`w-5 h-5 shrink-0 mt-0.5 ${
                    al.severity === 'critical' ? 'text-destructive' : 'text-amber-500'
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-bold truncate">{al.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{al.description}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ModalDrawer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <PosShell />
    </ThemeProvider>
  );
}
