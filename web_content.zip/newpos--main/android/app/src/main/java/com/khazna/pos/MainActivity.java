package com.khazna.pos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
