# Virdiya Clinic — Android app (offline, Excel storage)

## APK banavvani rit (PC par, Android Studio vagar, free)

1. github.com par free account banavo -> **New repository** (Private) -> naam: `virdiya-clinic`
2. Aa zip extract karo. Andar ni badhi files (android, www, .github, package.json ...) repository ma **Add file -> Upload files** thi upload karo.
   - `.github` folder dekhay nahi to: **Add file -> Create new file**, naam `.github/workflows/build-apk.yml` lakho ane file ni content paste karo.
3. **Actions** tab -> **Build APK** -> **Run workflow**. 5-8 minute ma green tick aavse.
4. Run kholo -> niche **Artifacts** ma `VirdiyaClinic-APK` download karo -> zip ma `VirdiyaClinic.apk` chhe.
5. APK phone ma moklo (USB / WhatsApp / Drive) -> tap karo -> "Install unknown apps" allow karo -> Install.

## Android Studio hoy to
```
npm install
npx cap sync android
npx cap open android      # Build > Build APK(s)
```

## Data
- Badho data phone ma save thay chhe ane sathe Excel file: `Documents/VirdiyaClinic/VirdiyaClinic_Data.xlsx`
  (Android permission na aape to app-folder ma save thay; Excel tab ma exact path dekhay chhe).
- Excel tab: Save now / Share copy / Import from Excel.
- AI summary: Excel tab ma Claude API key nakho. Key vagar pan har patient ma offline "Snapshot" male chhe.

## Tests
`npm install && npm test`
