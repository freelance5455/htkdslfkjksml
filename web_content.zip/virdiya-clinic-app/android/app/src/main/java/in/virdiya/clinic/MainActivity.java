package in.virdiya.clinic;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
