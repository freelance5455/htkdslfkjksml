/* Virdiya Clinic — offline clinic manager. All data lives on the phone and is mirrored to an Excel file. */
(function () {
  'use strict';
  const L = window.ClinicLogic, X = window.XLSX;
  const Cap = window.Capacitor;
  const native = !!(Cap && typeof Cap.isNativePlatform === 'function' && Cap.isNativePlatform());
  const FS = native ? Cap.Plugins.Filesystem : null;
  const SHARE = native ? Cap.Plugins.Share : null;

  const KEY = 'virdiya.clinic.db.v1';
  const FOLDER = 'VirdiyaClinic', FILE = 'VirdiyaClinic_Data.xlsx';
  const inr = L.inr;

  let db = L.emptyDB();
  const ui = { tab: 'home', pid: null, q: '', date: L.todayStr(), mode: 'day', form: null, aiBusy: false, saved: null, savePath: '', saveErr: '', lastSaved: '' };

  /* ---------------- helpers ---------------- */
  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  function fmtDate(s) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? (+m[3]) + ' ' + MON[+m[2] - 1] + ' ' + m[1] : (s || ''); }
  function fmtLong(s) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); if (!m) return s; const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])); return DAY[d.getUTCDay()] + ', ' + (+m[3]) + ' ' + MON[+m[2] - 1] + ' ' + m[1]; }
  function fmtTime(t) { const m = /^(\d{1,2}):(\d{2})$/.exec(t || ''); if (!m) return t || '—'; let h = +m[1]; const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return h + ':' + m[2] + ' ' + ap; }
  const initials = n => (n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const pname = id => { const p = L.patient(db, id); return p ? p.name : '(deleted patient)'; };
  const sortedPatients = () => db.patients.slice().sort((a, b) => a.name.localeCompare(b.name));

  let toastTimer;
  function toast(msg, err) {
    const t = $('#toast'); t.textContent = msg; t.className = 'show' + (err ? ' err' : '');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.className = ''; }, err ? 4200 : 2200);
  }

  /* ---------------- storage: phone memory + Excel file ---------------- */
  function loadLocal() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const d = JSON.parse(raw), base = L.emptyDB();
        db = Object.assign(base, d); db.settings = Object.assign(base.settings, d.settings || {});
        return true;
      }
    } catch (e) { /* fall through */ }
    return false;
  }
  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { toast('Phone storage is full or blocked', true); }
    scheduleExcel();
  }

  let excelTimer = null, excelPending = false;
  function scheduleExcel() { excelPending = true; clearTimeout(excelTimer); excelTimer = setTimeout(() => saveExcel(false), 700); }
  function flushExcel() { if (excelPending) { clearTimeout(excelTimer); saveExcel(false); } }

  const DIRS = [['DOCUMENTS', 'Documents'], ['EXTERNAL', 'App storage']];

  async function saveExcel(manual) {
    excelPending = false;
    let b64;
    try { b64 = L.workbookBase64(X, db); } catch (e) { ui.saved = false; ui.saveErr = 'Could not build Excel: ' + e.message; paintStatus(); return false; }
    if (!native) {
      ui.saved = false; ui.saveErr = 'Preview mode — the Excel file is written only inside the installed app. Use “Share / download Excel”.'; paintStatus(); return false;
    }
    let lastErr = '';
    for (const [dir, label] of DIRS) {
      try {
        await FS.writeFile({ path: FOLDER + '/' + FILE, data: b64, directory: dir, recursive: true });
        let where = label + '/' + FOLDER + '/' + FILE;
        try { const u = await FS.getUri({ path: FOLDER + '/' + FILE, directory: dir }); if (u && u.uri) where = decodeURIComponent(u.uri.replace('file://', '')); } catch (e) { /* keep label */ }
        ui.saved = true; ui.saveErr = ''; ui.savePath = where; ui.usedDir = dir; ui.lastSaved = new Date().toLocaleString('en-IN');
        paintStatus(); if (manual) toast('Excel saved'); return true;
      } catch (e) { lastErr = (e && e.message) || String(e); }
    }
    ui.saved = false; ui.saveErr = 'Could not write the Excel file: ' + lastErr; paintStatus();
    if (manual) toast('Excel not saved — see Excel tab', true);
    return false;
  }

  async function restoreFromExcel() {
    if (!native) return false;
    for (const [dir] of DIRS) {
      try {
        const r = await FS.readFile({ path: FOLDER + '/' + FILE, directory: dir });
        const wb = X.read(r.data, { type: 'base64' });
        const d = L.workbookToDB(X, wb);
        if (d.patients.length || d.sessions.length || d.payments.length || d.appointments.length) { db = d; return true; }
      } catch (e) { /* try next */ }
    }
    return false;
  }

  function paintStatus() {
    const d = $('#savedot'); if (d) d.className = 'savedot' + (ui.saved === false ? ' bad' : '');
    const s = $('#statusbox'); if (s) s.innerHTML = statusHtml();
  }

  /* ---------------- SVG gauge (goniometer) ---------------- */
  function gauge(done, total) {
    const cx = 110, cy = 104, R = 84, ang = total ? 180 * done / total : 0;
    let t = '';
    for (let a = 0; a <= 180; a += 10) {
      const rad = a * Math.PI / 180, maj = a % 30 === 0, r1 = R - (maj ? 14 : 8), r2 = R;
      const x1 = cx - r1 * Math.cos(rad), y1 = cy - r1 * Math.sin(rad), x2 = cx - r2 * Math.cos(rad), y2 = cy - r2 * Math.sin(rad);
      t += '<line class="tick' + (maj ? ' maj' : '') + (a <= ang && total ? ' on' : '') + '" x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '"/>';
    }
    return '<svg class="gauge" viewBox="0 0 220 116" aria-hidden="true"><line class="base" x1="' + (cx - R - 10) + '" y1="' + cy + '" x2="' + (cx + R + 10) + '" y2="' + cy + '"/>' + t +
      '<g class="arm" id="arm" style="transform:rotate(0deg)" data-ang="' + ang + '"><line x1="' + cx + '" y1="' + cy + '" x2="' + (cx - R + 6) + '" y2="' + cy + '"/></g><circle class="hub" cx="' + cx + '" cy="' + cy + '" r="6"/></svg>';
  }
  function swingArm() {
    const a = document.getElementById('arm'); if (!a) return;
    const ang = a.getAttribute('data-ang');
    requestAnimationFrame(() => requestAnimationFrame(() => { a.style.transform = 'rotate(' + ang + 'deg)'; }));
  }

  /* ---------------- small html pieces ---------------- */
  const chip = s => '<span class="chip ' + esc(s) + '">' + esc(s) + '</span>';
  function balChip(b) { return b.due > 0 ? '<span class="chip due">Due ' + inr(b.due) + '</span>' : b.advance > 0 ? '<span class="chip adv">Advance ' + inr(b.advance) + '</span>' : '<span class="chip clear">Clear</span>'; }
  const empty = msg => '<div class="empty">' + msg + '</div>';

  function apptRow(a, showDate) {
    return '<div class="row" tabindex="0" data-act="edit-appt" data-id="' + esc(a.id) + '"><div class="time">' + (showDate ? esc(fmtDate(a.date).replace(/ 20\d\d$/, '')) + '<br><small>' + esc(fmtTime(a.time)) + '</small>' : esc(fmtTime(a.time))) + '</div>' +
      '<div class="grow"><b>' + esc(pname(a.pid)) + '</b><small>' + esc(a.purpose || 'Session') + '</small></div>' + chip(a.status) +
      (a.status === 'Scheduled' ? '<button class="mini" data-act="complete-appt" data-id="' + esc(a.id) + '">Done</button>' : '') + '</div>';
  }

  /* ---------------- views ---------------- */
  function viewHome() {
    const t = L.todayStr();
    const list = db.appointments.filter(a => a.date === t).sort(L.byDateTime);
    const active = list.filter(a => a.status !== 'Cancelled' && a.status !== 'No-show');
    const done = active.filter(a => a.status === 'Completed').length;
    const tt = L.totals(db, t);
    return {
      title: 'Today',
      html: '<section class="hero">' + gauge(done, active.length) + '<div><div class="big">' + done + ' of ' + active.length + '</div><div>patients seen</div><div class="date">' + esc(fmtLong(t)) + '</div></div></section>' +
        '<div class="stats"><div class="stat"><span>Dues pending</span><b class="clay">' + inr(tt.due) + '</b><small>' + tt.dueCount + ' patient' + (tt.dueCount === 1 ? '' : 's') + '</small></div>' +
        '<div class="stat"><span>Advance held</span><b class="tealc">' + inr(tt.advance) + '</b><small>' + tt.advCount + ' patient' + (tt.advCount === 1 ? '' : 's') + '</small></div>' +
        '<div class="stat"><span>This month</span><b>' + inr(tt.monthCollected) + '</b><small>collected</small></div></div>' +
        '<div class="quick"><button class="btn" data-act="new-patient">New patient</button><button class="btn ghost" data-act="new-appt">Book appointment</button></div>' +
        '<h2>Today’s appointments</h2>' + (list.length ? list.map(a => apptRow(a)).join('') : empty('No appointments today.<br>Book one with the button above.'))
    };
  }

  function patientList() {
    const q = ui.q.trim().toLowerCase();
    let ps = sortedPatients();
    if (q) ps = ps.filter(p => (p.name + ' ' + p.phone + ' ' + p.id).toLowerCase().includes(q));
    if (!ps.length) return empty(db.patients.length ? 'No patient matches “' + esc(ui.q) + '”.' : 'No patients yet.<br>Tap “+ Patient” to add the first one.');
    return ps.map(p => '<div class="row" tabindex="0" data-act="open-patient" data-id="' + esc(p.id) + '"><div class="avatar">' + esc(initials(p.name)) + '</div><div class="grow"><b>' + esc(p.name) + '</b><small>' + esc(p.id) + (p.phone ? ' · ' + esc(p.phone) : '') + '</small></div>' + balChip(L.balanceOf(db, p.id)) + '</div>').join('');
  }
  function viewPatients() {
    return { title: 'Patients (' + db.patients.length + ')', html: '<div class="search"><input id="q" type="search" placeholder="Search name, phone or VPC ID" value="' + esc(ui.q) + '" autocomplete="off"></div><div id="plist">' + patientList() + '</div><button class="fab" data-act="new-patient">+ Patient</button>' };
  }

  function viewPatient(id) {
    const p = L.patient(db, id);
    if (!p) { ui.pid = null; return viewPatients(); }
    const b = L.balanceOf(db, id), t = L.todayStr();
    const items = [];
    db.sessions.filter(s => s.pid === id).forEach(s => items.push({ k: 'sess', d: s.date, tm: '', o: s }));
    db.payments.filter(x => x.pid === id).forEach(x => items.push({ k: 'pay', d: x.date, tm: '', o: x }));
    db.appointments.filter(a => a.pid === id).forEach(a => items.push({ k: 'appt', d: a.date, tm: a.time, o: a }));
    items.sort((a, c) => (c.d + c.tm).localeCompare(a.d + a.tm));
    const tl = items.map(i => {
      const o = i.o;
      if (i.k === 'sess') return '<div class="ti" tabindex="0" data-act="edit-session" data-id="' + esc(o.id) + '"><div class="grow"><b>Session · ' + esc(fmtDate(o.date)) + '</b><small class="n">' + esc(o.treatment || 'Treatment not noted') + (o.pain !== '' ? '\nPain ' + esc(o.pain) + '/10' : '') + (o.notes ? '\n' + esc(o.notes) : '') + '</small></div><div class="amt">' + (o.charge ? inr(o.charge) : '') + '</div></div>';
      if (i.k === 'pay') return '<div class="ti pay" tabindex="0" data-act="edit-pay" data-id="' + esc(o.id) + '"><div class="grow"><b>' + esc(o.type) + ' · ' + esc(fmtDate(o.date)) + '</b><small class="n">' + esc(o.id) + ' · ' + esc(o.mode) + (o.note ? '\n' + esc(o.note) : '') + '</small></div><div class="amt in">' + (o.type === 'Refund' ? '−' : '+') + inr(o.amount) + '</div></div>';
      return '<div class="ti appt" tabindex="0" data-act="edit-appt" data-id="' + esc(o.id) + '"><div class="grow"><b>Appointment · ' + esc(fmtDate(o.date)) + ' ' + esc(fmtTime(o.time)) + '</b><small class="n">' + esc(o.purpose || '') + '</small></div>' + chip(o.status) + '</div>';
    }).join('');
    const aiBlock = p.aiSummary ? '<div class="ai"><small>AI summary · ' + esc(fmtDate(p.aiDate)) + '</small>' + esc(p.aiSummary) + '</div>' : '';
    return {
      title: p.id,
      html: '<button class="back" data-act="back">‹ All patients</button>' +
        '<div class="card"><div class="cardhead"><div class="grow"><div class="pname">' + esc(p.name) + '</div><div class="meta">' + esc([p.age ? p.age + ' yr' : '', p.gender].filter(Boolean).join(', ')) + (p.phone ? ' · <a href="tel:' + esc(p.phone) + '">' + esc(p.phone) + '</a>' : '') + '</div>' +
        '<div class="meta">' + esc(p.complaint || 'No complaint recorded') + '</div></div><button class="mini" data-act="edit-patient" data-id="' + esc(p.id) + '">Edit</button></div></div>' +
        '<div class="card bal"><div><span>Billed</span><b>' + inr(b.charged) + '</b></div><div><span>Received</span><b>' + inr(b.paid) + '</b></div><div class="main' + (b.due > 0 ? ' due' : '') + '"><span>' + (b.due > 0 ? 'Due' : b.advance > 0 ? 'Advance' : 'Balance') + '</span><b class="' + (b.due > 0 ? 'clay' : 'tealc') + '">' + inr(b.due || b.advance) + '</b></div></div>' +
        '<div class="actions"><button class="btn" data-act="new-session" data-pid="' + esc(id) + '">Add session</button><button class="btn clayb" data-act="new-pay" data-pid="' + esc(id) + '">Take payment</button>' +
        '<button class="btn ghost" data-act="new-appt" data-pid="' + esc(id) + '">Book appointment</button><button class="btn ghost" data-act="ai" data-id="' + esc(id) + '"' + (ui.aiBusy ? ' disabled' : '') + '>' + (ui.aiBusy ? 'Writing…' : p.aiSummary ? 'Refresh AI summary' : 'AI summary') + '</button></div>' +
        aiBlock + '<div class="card"><b>Snapshot</b><ul class="sumlist">' + L.localSummary(db, id, t).map(l => '<li>' + esc(l) + '</li>').join('') + '</ul></div>' +
        '<h2>History</h2>' + (items.length ? '<div class="tl">' + tl + '</div>' : empty('Nothing recorded yet.<br>Add a session or book an appointment.'))
    };
  }

  function viewSched() {
    const t = L.todayStr();
    let body = '';
    if (ui.mode === 'day') {
      const list = db.appointments.filter(a => a.date === ui.date).sort(L.byDateTime);
      body = '<div class="daynav"><button data-act="day-prev" aria-label="Previous day">‹</button><input type="date" id="sd" value="' + esc(ui.date) + '"><button data-act="day-next" aria-label="Next day">›</button><button data-act="day-today">Today</button></div>' +
        '<div class="dayhead">' + esc(fmtLong(ui.date)) + ' · ' + list.length + ' appointment' + (list.length === 1 ? '' : 's') + '</div>' +
        (list.length ? list.map(a => apptRow(a)).join('') : empty('Nothing booked for this day.'));
    } else {
      const list = db.appointments.filter(a => a.status === 'Scheduled' && a.date >= t).sort(L.byDateTime);
      let last = '';
      body = list.length ? list.map(a => { let h = ''; if (a.date !== last) { last = a.date; h = '<div class="dayhead">' + esc(fmtLong(a.date)) + '</div>'; } return h + apptRow(a); }).join('') : empty('No upcoming appointments.');
    }
    return { title: 'Schedule', html: '<div class="seg"><button data-act="mode" data-mode="day" class="' + (ui.mode === 'day' ? 'on' : '') + '">Day</button><button data-act="mode" data-mode="up" class="' + (ui.mode === 'up' ? 'on' : '') + '">Upcoming</button></div>' + body + '<button class="fab" data-act="new-appt">+ Appointment</button>' };
  }

  function viewMoney() {
    const t = L.todayStr(), tt = L.totals(db, t);
    const rows = db.patients.map(p => ({ p, b: L.balanceOf(db, p.id) }));
    const dues = rows.filter(r => r.b.due > 0).sort((a, c) => c.b.due - a.b.due);
    const advs = rows.filter(r => r.b.advance > 0).sort((a, c) => c.b.advance - a.b.advance);
    const pays = db.payments.slice().sort(L.byDateTime).reverse().slice(0, 15);
    const prow = r => '<div class="row" tabindex="0" data-act="open-patient" data-id="' + esc(r.p.id) + '"><div class="avatar">' + esc(initials(r.p.name)) + '</div><div class="grow"><b>' + esc(r.p.name) + '</b><small>' + esc(r.p.id) + (r.p.phone ? ' · ' + esc(r.p.phone) : '') + '</small></div><b class="' + (r.b.due ? 'clay' : 'tealc') + '">' + inr(r.b.due || r.b.advance) + '</b>' + (r.b.due ? '<button class="mini" data-act="new-pay" data-pid="' + esc(r.p.id) + '">Collect</button>' : '') + '</div>';
    return {
      title: 'Money',
      html: '<div class="stats"><div class="stat"><span>Dues pending</span><b class="clay">' + inr(tt.due) + '</b></div><div class="stat"><span>Advance held</span><b class="tealc">' + inr(tt.advance) + '</b></div><div class="stat"><span>This month</span><b>' + inr(tt.monthCollected) + '</b></div></div>' +
        '<h2>Dues to collect</h2>' + (dues.length ? dues.map(prow).join('') : empty('No dues. Everyone is settled.')) +
        (advs.length ? '<h2>Advance in hand</h2>' + advs.map(prow).join('') : '') +
        '<h2>Recent payments</h2>' + (pays.length ? pays.map(x => '<div class="row" tabindex="0" data-act="edit-pay" data-id="' + esc(x.id) + '"><div class="grow"><b>' + esc(pname(x.pid)) + '</b><small>' + esc(x.id) + ' · ' + esc(fmtDate(x.date)) + ' · ' + esc(x.mode) + '</small></div><b class="tealc">' + (x.type === 'Refund' ? '−' : '+') + inr(x.amount) + '</b>' + (x.type === 'Advance' ? chip('Advance').replace('chip Advance', 'chip adv') : '') + '</div>').join('') : empty('No payments recorded yet.'))
    };
  }

  function statusHtml() {
    if (ui.saved === true) return '<div class="status"><span class="dot"></span><div><b>Excel file is up to date</b><div class="path">' + esc(ui.savePath) + '</div><small>Last saved ' + esc(ui.lastSaved) + '</small>' + (ui.usedDir === 'EXTERNAL' ? '<div class="note">Android would not allow the public Documents folder, so the file is in the app’s own folder. Use “Share / save copy” to put a copy anywhere (Drive, WhatsApp, Files).</div>' : '') + '</div></div>';
    if (ui.saved === false) return '<div class="status"><span class="dot bad"></span><div><b>Excel file not saved</b><div class="path">' + esc(ui.saveErr) + '</div></div></div>';
    return '<div class="status"><span class="dot"></span><div><b>Saving Excel…</b></div></div>';
  }
  function viewData() {
    const s = db.settings;
    const f = (id, label, val, type, ph) => '<label class="fld"><span>' + label + '</span><input id="' + id + '" type="' + (type || 'text') + '" value="' + esc(val) + '" placeholder="' + esc(ph || '') + '" autocomplete="off"></label>';
    return {
      title: 'Excel & settings',
      html: '<div class="card" id="statusbox">' + statusHtml() + '</div>' +
        '<div class="btnrow" style="margin-top:0"><button class="btn" data-act="save-excel">Save Excel now</button><button class="btn ghost" data-act="share-excel">Share / save copy</button><button class="btn ghost" data-act="import-excel">Import from Excel</button></div>' +
        '<div class="note">Every change is saved to the Excel file automatically. Sheets: Patients, Appointments, Sessions, Payments, Balances.</div>' +
        '<h2>Clinic details</h2><div class="card inline">' + f('s_clinicName', 'Clinic name', s.clinicName) + f('s_address', 'Address', s.address) + f('s_doctor', 'Doctor', s.doctor) + f('s_defaultFee', 'Default fee per session (₹)', s.defaultFee, 'number') + '</div>' +
        '<h2>AI summary</h2><div class="card inline">' + f('s_aiKey', 'Claude API key', s.aiKey, 'password', 'sk-ant-…') +
        '<label class="fld"><span>Summary language</span><select id="s_aiLang">' + ['English', 'Gujarati', 'Hindi'].map(l => '<option' + (s.aiLang === l ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></label>' + f('s_aiModel', 'Model', s.aiModel) +
        '<div class="note">The Snapshot on each patient works offline. “AI summary” needs internet and your key; it sends that patient’s visit notes (not phone or address) to Anthropic. The key stays on this phone and is never written to Excel.</div></div>' +
        '<div class="quick"><button class="btn" data-act="save-settings">Save settings</button></div>'
    };
  }

  /* ---------------- render ---------------- */
  function render() {
    const v = ui.pid ? viewPatient(ui.pid) : ({ home: viewHome, patients: viewPatients, sched: viewSched, money: viewMoney, data: viewData }[ui.tab])();
    $('#view').innerHTML = v.html;
    $('#ttl').textContent = v.title;
    $('#clinic').textContent = db.settings.clinicName || 'Virdiya Clinic';
    document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === ui.tab));
    paintStatus();
    if (!ui.pid && ui.tab === 'home') swingArm();
  }

  /* ---------------- forms ---------------- */
  function openForm(o) {
    ui.form = o;
    const vals = o.values || {};
    const body = o.fields.map(f => {
      const v = vals[f.k] != null ? vals[f.k] : (f.def != null ? f.def : '');
      let inp;
      if (f.type === 'select') inp = '<select name="' + f.k + '">' + f.options.map(op => '<option value="' + esc(op) + '"' + (String(op) === String(v) ? ' selected' : '') + '>' + esc(op) + '</option>').join('') + '</select>';
      else if (f.type === 'pselect') inp = '<select name="' + f.k + '"><option value="">Choose patient…</option>' + sortedPatients().map(p => '<option value="' + esc(p.id) + '"' + (p.id === v ? ' selected' : '') + '>' + esc(p.name + ' (' + p.id + ')') + '</option>').join('') + '</select>';
      else if (f.type === 'textarea') inp = '<textarea name="' + f.k + '" rows="' + (f.rows || 3) + '" placeholder="' + esc(f.ph || '') + '">' + esc(v) + '</textarea>';
      else inp = '<input name="' + f.k + '" type="' + (f.type || 'text') + '" value="' + esc(v) + '" placeholder="' + esc(f.ph || '') + '"' + (f.type === 'number' ? ' inputmode="decimal" step="any" min="' + (f.min != null ? f.min : 0) + '"' + (f.max != null ? ' max="' + f.max + '"' : '') : '') + (f.type === 'tel' ? ' inputmode="tel"' : '') + ' autocomplete="off">';
      return '<label class="fld' + (f.half ? ' half' : '') + '"><span>' + esc(f.label) + (f.req ? ' *' : '') + '</span>' + inp + '</label>';
    }).join('');
    $('#modal').innerHTML = '<div class="scrim"></div><form class="sheet" id="mform" novalidate><div class="sheet-h"><b>' + esc(o.title) + '</b><button type="button" class="x" data-act="close-modal" aria-label="Close">✕</button></div><div class="sheet-b">' + body + '</div><div class="sheet-f">' + (o.onDelete ? '<button type="button" class="btn danger" data-act="form-delete">Delete</button>' : '') + '<button type="submit" class="btn">' + esc(o.saveLabel || 'Save') + '</button></div></form>';
    const first = document.querySelector('#mform input:not([type=date]):not([type=time]), #mform select');
    if (first && !first.value) setTimeout(() => { try { first.focus(); } catch (e) { /* ignore */ } }, 250);
  }
  function closeModal() { ui.form = null; $('#modal').innerHTML = ''; }
  function afterSave(msg) { persist(); closeModal(); render(); toast(msg || 'Saved'); }

  function patientForm(p) {
    openForm({
      title: p ? 'Edit patient' : 'New patient', values: p || {},
      fields: [
        { k: 'name', label: 'Full name', req: true },
        { k: 'age', label: 'Age', type: 'number', half: true, max: 120 },
        { k: 'gender', label: 'Gender', type: 'select', options: ['', 'Male', 'Female', 'Other'], half: true },
        { k: 'phone', label: 'Phone', type: 'tel' },
        { k: 'address', label: 'Address' },
        { k: 'complaint', label: 'Complaint / diagnosis', type: 'textarea', rows: 2 },
        { k: 'referredBy', label: 'Referred by' },
        { k: 'notes', label: 'Notes', type: 'textarea', rows: 2 }
      ],
      onSave: v => {
        if (!v.name.trim()) return 'Enter the patient’s name';
        if (p) { Object.assign(p, v, { name: v.name.trim() }); afterSave('Patient updated'); }
        else { const np = Object.assign({ id: L.nextPatientId(db), registered: L.todayStr(), aiSummary: '', aiDate: '' }, v, { name: v.name.trim() }); db.patients.push(np); ui.tab = 'patients'; ui.pid = np.id; afterSave('Added ' + np.id); }
      },
      onDelete: p ? () => {
        if (!confirm('Delete ' + p.name + ' and all their sessions, payments and appointments? This cannot be undone.')) return;
        db.patients = db.patients.filter(x => x.id !== p.id); db.sessions = db.sessions.filter(x => x.pid !== p.id);
        db.payments = db.payments.filter(x => x.pid !== p.id); db.appointments = db.appointments.filter(x => x.pid !== p.id);
        ui.pid = null; afterSave('Patient deleted');
      } : null
    });
  }

  function apptForm(a, pre) {
    if (!db.patients.length) { toast('Add a patient first', true); return; }
    const isNew = !a;
    openForm({
      title: isNew ? 'Book appointment' : 'Edit appointment',
      values: a || Object.assign({ status: 'Scheduled', time: '10:00', purpose: 'Physiotherapy session', date: L.todayStr() }, pre),
      fields: [
        { k: 'pid', label: 'Patient', type: 'pselect', req: true },
        { k: 'date', label: 'Date', type: 'date', half: true, req: true },
        { k: 'time', label: 'Time', type: 'time', half: true, req: true },
        { k: 'purpose', label: 'Purpose' },
        { k: 'status', label: 'Status', type: 'select', options: L.STATUSES },
        { k: 'notes', label: 'Notes', type: 'textarea', rows: 2 }
      ],
      onSave: v => {
        if (!v.pid) return 'Choose a patient';
        if (!v.date || !v.time) return 'Set the date and time';
        const clash = db.appointments.find(x => (!a || x.id !== a.id) && x.date === v.date && x.time === v.time && x.status === 'Scheduled' && v.status === 'Scheduled');
        if (clash && !confirm(pname(clash.pid) + ' is already booked at ' + fmtTime(v.time) + '. Book this one too?')) return false;
        if (a) { Object.assign(a, v); afterSave('Appointment updated'); }
        else { db.appointments.push(Object.assign({ id: L.nextApptId(db) }, v)); ui.date = v.date; afterSave('Appointment booked'); }
      },
      onDelete: a ? () => { if (!confirm('Delete this appointment?')) return; db.appointments = db.appointments.filter(x => x.id !== a.id); afterSave('Appointment deleted'); } : null
    });
  }

  function sessionForm(s, pre) {
    const isNew = !s;
    openForm({
      title: isNew ? 'Add session' : 'Edit session',
      values: s || Object.assign({ date: L.todayStr(), charge: db.settings.defaultFee }, pre),
      fields: [
        { k: 'pid', label: 'Patient', type: 'pselect', req: true },
        { k: 'date', label: 'Date', type: 'date', half: true, req: true },
        { k: 'pain', label: 'Pain (0–10)', type: 'number', half: true, min: 0, max: 10 },
        { k: 'treatment', label: 'Treatment given', type: 'textarea', rows: 2, ph: 'e.g. IFT, hot pack, core exercises' },
        { k: 'notes', label: 'Progress notes', type: 'textarea', rows: 3, ph: 'Findings, response, home advice' },
        { k: 'charge', label: 'Charge (₹)', type: 'number', half: isNew },
      ].concat(isNew ? [{ k: 'paidNow', label: 'Paid now (₹)', type: 'number', half: true }, { k: 'mode', label: 'Payment mode', type: 'select', options: ['Cash', 'UPI', 'Card', 'Other'] }] : []),
      onSave: v => {
        if (!v.pid) return 'Choose a patient';
        if (!v.date) return 'Set the date';
        if (v.pain !== '' && (+v.pain < 0 || +v.pain > 10)) return 'Pain must be between 0 and 10';
        const rec = { pid: v.pid, date: v.date, treatment: v.treatment.trim(), pain: v.pain, notes: v.notes.trim(), charge: v.charge };
        if (s) { Object.assign(s, rec); afterSave('Session updated'); return; }
        db.sessions.push(Object.assign({ id: L.nextSessionId(db) }, rec));
        if (L.num(v.paidNow) > 0) db.payments.push({ id: L.nextReceiptId(db, v.date), pid: v.pid, date: v.date, type: 'Payment', amount: v.paidNow, mode: v.mode || 'Cash', note: 'With session' });
        afterSave('Session added');
      },
      onDelete: s ? () => { if (!confirm('Delete this session?')) return; db.sessions = db.sessions.filter(x => x.id !== s.id); afterSave('Session deleted'); } : null
    });
  }

  function payForm(x, pre) {
    const isNew = !x;
    openForm({
      title: isNew ? 'Take payment' : 'Edit payment ' + x.id,
      values: x || Object.assign({ date: L.todayStr(), type: 'Payment', mode: 'Cash' }, pre),
      fields: [
        { k: 'pid', label: 'Patient', type: 'pselect', req: true },
        { k: 'date', label: 'Date', type: 'date', half: true, req: true },
        { k: 'type', label: 'Type', type: 'select', options: L.PAY_TYPES, half: true },
        { k: 'amount', label: 'Amount (₹)', type: 'number', half: true, req: true },
        { k: 'mode', label: 'Mode', type: 'select', options: ['Cash', 'UPI', 'Card', 'Other'], half: true },
        { k: 'note', label: 'Note', ph: 'e.g. 10-session package advance' }
      ],
      onSave: v => {
        if (!v.pid) return 'Choose a patient';
        if (!(L.num(v.amount) > 0)) return 'Enter an amount above zero';
        if (x) { Object.assign(x, v); afterSave('Payment updated'); }
        else { db.payments.push(Object.assign({ id: L.nextReceiptId(db, v.date) }, v)); afterSave('Payment recorded'); }
      },
      onDelete: x ? () => { if (!confirm('Delete payment ' + x.id + '?')) return; db.payments = db.payments.filter(y => y.id !== x.id); afterSave('Payment deleted'); } : null
    });
  }

  /* ---------------- AI summary ---------------- */
  async function aiSummary(pid) {
    const s = db.settings;
    if (!s.aiKey) { toast('Add your Claude API key in the Excel tab first', true); return; }
    if (ui.aiBusy) return;
    ui.aiBusy = true; render();
    try {
      const pr = L.buildAIPrompt(db, pid, s.aiLang, L.todayStr());
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': s.aiKey.trim(), 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify({ model: s.aiModel || 'claude-sonnet-5', max_tokens: 900, system: pr.system, messages: [{ role: 'user', content: pr.user }] })
      });
      const j = await r.json();
      if (!r.ok) throw new Error((j.error && j.error.message) || ('HTTP ' + r.status));
      const text = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
      if (!text) throw new Error('Empty reply');
      const p = L.patient(db, pid); p.aiSummary = text; p.aiDate = L.todayStr(); persist(); toast('AI summary saved to this patient');
    } catch (e) {
      toast('AI summary failed: ' + ((e && e.message) || e) + (navigator.onLine === false ? ' (no internet)' : ''), true);
    } finally { ui.aiBusy = false; render(); }
  }

  /* ---------------- Excel export / import ---------------- */
  async function shareExcel() {
    const b64 = L.workbookBase64(X, db);
    if (native && SHARE) {
      try {
        await FS.writeFile({ path: 'VirdiyaClinic_Backup.xlsx', data: b64, directory: 'CACHE' });
        const u = await FS.getUri({ path: 'VirdiyaClinic_Backup.xlsx', directory: 'CACHE' });
        await SHARE.share({ title: 'Virdiya Clinic data', text: 'Clinic data (Excel)', url: u.uri, dialogTitle: 'Save or send Excel' });
        return;
      } catch (e) { if (e && /cancel/i.test(e.message || '')) return; toast('Share failed: ' + (e.message || e), true); return; }
    }
    const blob = new Blob([Uint8Array.from(atob(b64), c => c.charCodeAt(0))], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = FILE; document.body.appendChild(a); a.click(); a.remove();
  }
  function importExcel(file) {
    const rd = new FileReader();
    rd.onload = () => {
      try {
        const wb = X.read(rd.result, { type: 'array' });
        const d = L.workbookToDB(X, wb, db.settings);
        const n = d.patients.length;
        if (!n && !d.sessions.length) { toast('No clinic data found in that file', true); return; }
        if (!confirm('Replace everything on this phone with ' + n + ' patients from this file?')) return;
        db = d; persist(); ui.pid = null; render(); toast('Imported ' + n + ' patients');
      } catch (e) { toast('Could not read that Excel file', true); }
    };
    rd.readAsArrayBuffer(file);
  }

  /* ---------------- events ---------------- */
  const A = {
    tab: d => { ui.tab = d.tab; ui.pid = null; render(); window.scrollTo(0, 0); },
    back: () => { ui.pid = null; render(); },
    'open-patient': d => { ui.tab = ui.tab === 'money' ? 'patients' : ui.tab; ui.pid = d.id; render(); window.scrollTo(0, 0); },
    'new-patient': () => patientForm(),
    'edit-patient': d => patientForm(L.patient(db, d.id)),
    'new-appt': d => apptForm(null, { pid: d.pid || ui.pid || '', date: ui.tab === 'sched' && !ui.pid ? ui.date : L.todayStr() }),
    'edit-appt': d => apptForm(db.appointments.find(a => a.id === d.id)),
    'complete-appt': d => { const a = db.appointments.find(x => x.id === d.id); if (!a) return; a.status = 'Completed'; persist(); render(); toast('Marked complete'); sessionForm(null, { pid: a.pid, date: a.date }); },
    'new-session': d => sessionForm(null, { pid: d.pid || ui.pid || '' }),
    'edit-session': d => sessionForm(db.sessions.find(s => s.id === d.id)),
    'new-pay': d => { const b = d.pid ? L.balanceOf(db, d.pid) : null; payForm(null, { pid: d.pid || ui.pid || '', amount: b && b.due ? b.due : '' }); },
    'edit-pay': d => payForm(db.payments.find(p => p.id === d.id)),
    ai: d => aiSummary(d.id),
    'close-modal': closeModal,
    'form-delete': () => { const f = ui.form; if (f && f.onDelete) f.onDelete(); },
    'day-prev': () => { ui.date = L.addDays(ui.date, -1); render(); },
    'day-next': () => { ui.date = L.addDays(ui.date, 1); render(); },
    'day-today': () => { ui.date = L.todayStr(); render(); },
    mode: d => { ui.mode = d.mode; render(); },
    'save-excel': () => saveExcel(true),
    'share-excel': shareExcel,
    'import-excel': () => $('#importfile').click(),
    'save-settings': () => {
      const g = id => ($('#' + id) || {}).value || '';
      Object.assign(db.settings, { clinicName: g('s_clinicName').trim() || 'Virdiya Clinic', address: g('s_address').trim(), doctor: g('s_doctor').trim(), defaultFee: g('s_defaultFee'), aiKey: g('s_aiKey').trim(), aiLang: g('s_aiLang') || 'English', aiModel: g('s_aiModel').trim() || 'claude-sonnet-5' });
      persist(); render(); toast('Settings saved');
    }
  };

  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const fn = A[el.dataset.act];
    if (fn) { e.preventDefault(); fn(el.dataset); }
  });
  document.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.row[data-act],.ti[data-act]')) { e.preventDefault(); e.target.click(); }
  });
  document.addEventListener('input', e => {
    if (e.target.id === 'q') { ui.q = e.target.value; const l = $('#plist'); if (l) l.innerHTML = patientList(); }
  });
  document.addEventListener('change', e => {
    if (e.target.id === 'sd' && e.target.value) { ui.date = e.target.value; render(); }
    if (e.target.id === 'importfile' && e.target.files[0]) { importExcel(e.target.files[0]); e.target.value = ''; }
  });
  document.addEventListener('submit', e => {
    if (e.target.id !== 'mform') return;
    e.preventDefault();
    const f = ui.form; if (!f) return;
    const v = {};
    f.fields.forEach(fl => { const el = e.target.elements[fl.k]; v[fl.k] = el ? el.value : ''; });
    const missing = f.fields.find(fl => fl.req && !String(v[fl.k]).trim());
    if (missing) { toast(missing.label + ' is required', true); return; }
    const res = f.onSave(v);
    if (typeof res === 'string') toast(res, true);
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushExcel(); });

  if (native && Cap.Plugins.App) {
    Cap.Plugins.App.addListener('backButton', () => {
      if (ui.form) closeModal();
      else if (ui.pid) { ui.pid = null; render(); }
      else if (ui.tab !== 'home') { ui.tab = 'home'; render(); }
      else Cap.Plugins.App.exitApp();
    });
    Cap.Plugins.App.addListener('pause', flushExcel);
  }

  /* ---------------- start ---------------- */
  async function start() {
    const had = loadLocal();
    if (!had) {
      const restored = await restoreFromExcel();
      if (restored) { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { /* ignore */ } }
    }
    render();
    if (native) { try { await FS.requestPermissions(); } catch (e) { /* not needed on newer Android */ } }
    await saveExcel(false);
    if (!had && !db.patients.length) toast('Ready. Add your first patient.');
  }
  window.__clinic = { get db() { return db; }, ui, A, render, saveExcel, persist };
  start();
})();
