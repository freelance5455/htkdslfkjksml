/* Virdiya Clinic — data logic (no DOM). Works in the app and in Node tests. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ClinicLogic = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const HEAD = {
    patients: ['Patient ID', 'Name', 'Age', 'Gender', 'Phone', 'Address', 'Complaint / Diagnosis', 'Referred By', 'Registered On', 'Notes', 'AI Summary', 'AI Summary Date'],
    appointments: ['Appt ID', 'Patient ID', 'Patient Name', 'Date', 'Time', 'Purpose', 'Status', 'Notes'],
    sessions: ['Session ID', 'Patient ID', 'Patient Name', 'Date', 'Treatment Given', 'Pain (0-10)', 'Progress Notes', 'Charge (INR)'],
    payments: ['Receipt No', 'Patient ID', 'Patient Name', 'Date', 'Type', 'Amount (INR)', 'Mode', 'Note'],
    balances: ['Patient ID', 'Name', 'Phone', 'Sessions', 'Total Charged (INR)', 'Total Paid (INR)', 'Due (INR)', 'Advance (INR)', 'Last Visit', 'Next Appointment']
  };

  const STATUSES = ['Scheduled', 'Completed', 'Cancelled', 'No-show'];
  const PAY_TYPES = ['Payment', 'Advance', 'Refund'];

  function emptyDB() {
    return {
      patients: [], appointments: [], sessions: [], payments: [],
      settings: {
        clinicName: 'Virdiya Clinic & Physiotherapy Centre',
        address: '', doctor: '', defaultFee: '',
        aiKey: '', aiModel: 'claude-sonnet-5', aiLang: 'English'
      }
    };
  }

  /* ---------- small helpers ---------- */
  const pad = (n, w) => String(n).padStart(w, '0');
  const round2 = n => Math.round((Number(n) || 0) * 100) / 100;
  const num = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };

  function todayStr(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1, 2) + '-' + pad(d.getDate(), 2);
  }
  function parseDate(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '');
    return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) : NaN;
  }
  function addDays(s, n) {
    const t = parseDate(s);
    if (isNaN(t)) return s;
    const d = new Date(t + n * 86400000);
    return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1, 2) + '-' + pad(d.getUTCDate(), 2);
  }
  function diffDays(a, b) { return Math.round((parseDate(a) - parseDate(b)) / 86400000); }

  // Indian digit grouping: 1,23,456.50
  function inr(n) {
    n = round2(n);
    const neg = n < 0; n = Math.abs(n);
    const parts = n.toFixed(2).split('.');
    let i = parts[0], out = i;
    if (i.length > 3) {
      const last3 = i.slice(-3), rest = i.slice(0, -3);
      out = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + last3;
    }
    return (neg ? '-' : '') + '₹' + out + (parts[1] === '00' ? '' : '.' + parts[1]);
  }

  /* ---------- IDs: VPC-0001 patients, INV-YYYY-0001 receipts ---------- */
  function maxSeq(list, re) {
    let m = 0;
    list.forEach(x => { const r = re.exec(x); if (r) m = Math.max(m, +r[r.length - 1]); });
    return m;
  }
  function nextPatientId(db) { return 'VPC-' + pad(maxSeq(db.patients.map(p => p.id), /^VPC-(\d+)$/) + 1, 4); }
  function nextApptId(db) { return 'A-' + pad(maxSeq(db.appointments.map(p => p.id), /^A-(\d+)$/) + 1, 4); }
  function nextSessionId(db) { return 'S-' + pad(maxSeq(db.sessions.map(p => p.id), /^S-(\d+)$/) + 1, 4); }
  function nextReceiptId(db, date) {
    const y = (date || todayStr()).slice(0, 4);
    const re = new RegExp('^INV-' + y + '-(\\d+)$');
    return 'INV-' + y + '-' + pad(maxSeq(db.payments.map(p => p.id), re) + 1, 4);
  }

  /* ---------- lookups & money ---------- */
  const patient = (db, id) => db.patients.find(p => p.id === id);

  // paid = Payment + Advance - Refund ; balance = paid - charged (negative = due, positive = advance)
  function balanceOf(db, pid) {
    let charged = 0, paid = 0;
    db.sessions.forEach(s => { if (s.pid === pid) charged += num(s.charge); });
    db.payments.forEach(p => {
      if (p.pid !== pid) return;
      paid += p.type === 'Refund' ? -num(p.amount) : num(p.amount);
    });
    charged = round2(charged); paid = round2(paid);
    const bal = round2(paid - charged);
    return { charged, paid, bal, due: bal < 0 ? -bal : 0, advance: bal > 0 ? bal : 0 };
  }

  function totals(db, today) {
    const month = (today || todayStr()).slice(0, 7);
    let due = 0, dueCount = 0, advance = 0, advCount = 0, monthCollected = 0;
    db.patients.forEach(p => {
      const b = balanceOf(db, p.id);
      if (b.due > 0) { due += b.due; dueCount++; }
      if (b.advance > 0) { advance += b.advance; advCount++; }
    });
    db.payments.forEach(p => {
      if ((p.date || '').slice(0, 7) === month) monthCollected += p.type === 'Refund' ? -num(p.amount) : num(p.amount);
    });
    return { due: round2(due), dueCount, advance: round2(advance), advCount, monthCollected: round2(monthCollected) };
  }

  const byDateTime = (a, b) => ((a.date || '') + (a.time || '')).localeCompare((b.date || '') + (b.time || ''));

  function lastVisit(db, pid) {
    const ds = db.sessions.filter(s => s.pid === pid).map(s => s.date).sort();
    return ds.length ? ds[ds.length - 1] : '';
  }
  function nextAppt(db, pid, today) {
    const list = db.appointments
      .filter(a => a.pid === pid && a.status === 'Scheduled' && a.date >= today)
      .sort(byDateTime);
    return list[0] || null;
  }

  /* ---------- date/time normalisation for imported Excel ---------- */
  function normDate(v) {
    if (v === '' || v == null) return '';
    if (typeof v === 'number') {
      const d = new Date(Math.round((v - 25569) * 86400000));
      return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1, 2) + '-' + pad(d.getUTCDate(), 2);
    }
    const s = String(v).trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const m = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(s); // day-first (India)
    if (m) return m[3] + '-' + pad(m[2], 2) + '-' + pad(m[1], 2);
    return s;
  }
  function normTime(v) {
    if (v === '' || v == null) return '';
    if (typeof v === 'number') {
      const mins = Math.round((v % 1) * 1440);
      return pad(Math.floor(mins / 60) % 24, 2) + ':' + pad(mins % 60, 2);
    }
    const s = String(v).trim();
    const m = /^(\d{1,2}):(\d{2})/.exec(s);
    return m ? pad(m[1], 2) + ':' + m[2] : s;
  }

  /* ---------- Excel <-> DB ---------- */
  function dbToWorkbook(XLSX, db, today) {
    today = today || todayStr();
    const wb = XLSX.utils.book_new();
    const nameOf = id => { const p = patient(db, id); return p ? p.name : ''; };
    const numOrBlank = v => (v === '' || v == null || isNaN(parseFloat(v))) ? '' : parseFloat(v);

    const data = {
      Patients: db.patients.map(p => [p.id, p.name, numOrBlank(p.age), p.gender, p.phone, p.address, p.complaint, p.referredBy, p.registered, p.notes, p.aiSummary || '', p.aiDate || '']),
      Appointments: db.appointments.slice().sort(byDateTime).map(a => [a.id, a.pid, nameOf(a.pid), a.date, a.time, a.purpose, a.status, a.notes]),
      Sessions: db.sessions.slice().sort(byDateTime).map(s => [s.id, s.pid, nameOf(s.pid), s.date, s.treatment, numOrBlank(s.pain), s.notes, numOrBlank(s.charge)]),
      Payments: db.payments.slice().sort(byDateTime).map(p => [p.id, p.pid, nameOf(p.pid), p.date, p.type, numOrBlank(p.amount), p.mode, p.note]),
      Balances: db.patients.map(p => {
        const b = balanceOf(db, p.id), n = nextAppt(db, p.id, today);
        return [p.id, p.name, p.phone, db.sessions.filter(s => s.pid === p.id).length, b.charged, b.paid, b.due, b.advance, lastVisit(db, p.id), n ? n.date + ' ' + (n.time || '') : ''];
      })
    };
    const heads = { Patients: HEAD.patients, Appointments: HEAD.appointments, Sessions: HEAD.sessions, Payments: HEAD.payments, Balances: HEAD.balances };
    const widths = {
      Patients: [11, 22, 6, 9, 14, 28, 30, 16, 13, 30, 60, 14],
      Appointments: [9, 11, 22, 12, 8, 24, 11, 30],
      Sessions: [10, 11, 22, 12, 34, 10, 40, 12],
      Payments: [15, 11, 22, 12, 10, 13, 9, 30],
      Balances: [11, 22, 14, 9, 18, 16, 11, 13, 12, 20]
    };
    Object.keys(data).forEach(name => {
      const ws = XLSX.utils.aoa_to_sheet([heads[name]].concat(data[name]));
      ws['!cols'] = widths[name].map(w => ({ wch: w }));
      XLSX.utils.book_append_sheet(wb, ws, name);
    });
    const s = db.settings;
    const ws = XLSX.utils.aoa_to_sheet([['Setting', 'Value'], ['Clinic Name', s.clinicName], ['Address', s.address], ['Doctor', s.doctor], ['Default Fee (INR)', s.defaultFee], ['AI Summary Language', s.aiLang]]);
    ws['!cols'] = [{ wch: 22 }, { wch: 50 }];
    XLSX.utils.book_append_sheet(wb, ws, 'Settings');
    return wb;
  }

  function workbookBase64(XLSX, db, today) {
    return XLSX.write(dbToWorkbook(XLSX, db, today), { type: 'base64', bookType: 'xlsx' });
  }

  function workbookToDB(XLSX, wb, keepSettings) {
    const db = emptyDB();
    if (keepSettings) Object.assign(db.settings, keepSettings);
    const str = v => (v == null ? '' : String(v).trim());

    function rows(sheet, head) {
      const ws = wb.Sheets[sheet];
      if (!ws) return [];
      const arr = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
      if (!arr.length) return [];
      const hdr = arr[0].map(str);
      const idx = head.map((h, i) => { const k = hdr.indexOf(h); return k >= 0 ? k : i; });
      return arr.slice(1)
        .filter(r => r.some(c => str(c) !== ''))
        .map(r => idx.map(k => (r[k] === undefined ? '' : r[k])));
    }

    rows('Patients', HEAD.patients).forEach(r => {
      if (!str(r[0]) && !str(r[1])) return;
      db.patients.push({
        id: str(r[0]), name: str(r[1]), age: str(r[2]), gender: str(r[3]), phone: str(r[4]), address: str(r[5]),
        complaint: str(r[6]), referredBy: str(r[7]), registered: normDate(r[8]), notes: str(r[9]),
        aiSummary: str(r[10]), aiDate: normDate(r[11])
      });
    });
    // assign IDs to hand-typed rows that have none
    db.patients.forEach(p => { if (!p.id) p.id = nextPatientId(db); });

    rows('Appointments', HEAD.appointments).forEach(r => {
      db.appointments.push({ id: str(r[0]), pid: str(r[1]), date: normDate(r[3]), time: normTime(r[4]), purpose: str(r[5]), status: STATUSES.indexOf(str(r[6])) >= 0 ? str(r[6]) : 'Scheduled', notes: str(r[7]) });
    });
    db.appointments.forEach(a => { if (!a.id) a.id = nextApptId(db); });

    rows('Sessions', HEAD.sessions).forEach(r => {
      db.sessions.push({ id: str(r[0]), pid: str(r[1]), date: normDate(r[3]), treatment: str(r[4]), pain: str(r[5]), notes: str(r[6]), charge: str(r[7]) });
    });
    db.sessions.forEach(s => { if (!s.id) s.id = nextSessionId(db); });

    rows('Payments', HEAD.payments).forEach(r => {
      db.payments.push({ id: str(r[0]), pid: str(r[1]), date: normDate(r[3]), type: PAY_TYPES.indexOf(str(r[4])) >= 0 ? str(r[4]) : 'Payment', amount: str(r[5]), mode: str(r[6]), note: str(r[7]) });
    });
    db.payments.forEach(p => { if (!p.id) p.id = nextReceiptId(db, p.date); });

    const ws = wb.Sheets['Settings'];
    if (ws) {
      XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' }).slice(1).forEach(r => {
        const k = str(r[0]), v = str(r[1]);
        if (k === 'Clinic Name' && v) db.settings.clinicName = v;
        if (k === 'Address') db.settings.address = v;
        if (k === 'Doctor') db.settings.doctor = v;
        if (k === 'Default Fee (INR)') db.settings.defaultFee = v;
        if (k === 'AI Summary Language' && v) db.settings.aiLang = v;
      });
    }
    return db;
  }

  /* ---------- offline summary (works without internet / API key) ---------- */
  function localSummary(db, pid, today) {
    today = today || todayStr();
    const p = patient(db, pid);
    if (!p) return [];
    const ss = db.sessions.filter(s => s.pid === pid).sort(byDateTime);
    const ap = db.appointments.filter(a => a.pid === pid).sort(byDateTime);
    const fin = balanceOf(db, pid);
    const out = [];

    out.push((p.age ? p.age + ' yr' : '') + (p.age && p.gender ? ', ' : '') + (p.gender || '') +
      (p.age || p.gender ? '. ' : '') + 'Complaint: ' + (p.complaint || 'not recorded') + '.');

    if (ss.length) {
      out.push(ss.length + (ss.length === 1 ? ' session' : ' sessions') + ' from ' + ss[0].date + ' to ' + ss[ss.length - 1].date + '.');
      const pains = ss.filter(s => s.pain !== '' && s.pain != null && !isNaN(parseFloat(s.pain))).map(s => parseFloat(s.pain));
      if (pains.length >= 2) {
        const a = pains[0], b = pains[pains.length - 1];
        out.push(b < a ? 'Pain improved from ' + a + ' to ' + b + '.'
          : b > a ? 'Pain is higher now: ' + a + ' → ' + b + '. Worth reviewing the plan.'
            : 'Pain unchanged at ' + b + '.');
      } else if (pains.length === 1) out.push('Pain score recorded: ' + pains[0] + '.');
      const counts = {};
      ss.forEach(s => String(s.treatment || '').split(/[,;+\n]/).map(t => t.trim()).filter(Boolean).forEach(t => {
        const k = t.toLowerCase(); counts[k] = (counts[k] || 0) + 1;
      }));
      const top = Object.keys(counts).sort((a, b) => counts[b] - counts[a]).slice(0, 3);
      if (top.length) out.push('Most used: ' + top.map(k => k + ' (' + counts[k] + ')').join(', ') + '.');
      const last = ss[ss.length - 1];
      if (last.notes) out.push('Latest note (' + last.date + '): ' + (last.notes.length > 140 ? last.notes.slice(0, 140) + '…' : last.notes));
    } else {
      out.push('No treatment sessions recorded yet.');
    }

    const next = nextAppt(db, pid, today);
    out.push(next ? 'Next appointment: ' + next.date + (next.time ? ' at ' + next.time : '') + '.' : 'No upcoming appointment booked.');
    const missed = ap.filter(a => a.status === 'No-show' || a.status === 'Cancelled').length;
    if (missed) out.push('Missed or cancelled appointments: ' + missed + '.');

    out.push('Billed ' + inr(fin.charged) + ', received ' + inr(fin.paid) + (fin.due > 0 ? ' — due ' + inr(fin.due) + '.' : fin.advance > 0 ? ' — advance ' + inr(fin.advance) + ' in hand.' : ' — nothing pending.'));

    if (ss.length && !next) {
      const gap = diffDays(today, ss[ss.length - 1].date);
      if (gap > 14) out.push('Follow-up: not seen for ' + gap + ' days and nothing is booked. Consider calling the patient.');
    }
    return out;
  }

  /* ---------- prompt for the Claude API summary (no phone/address is sent) ---------- */
  function buildAIPrompt(db, pid, lang, today) {
    today = today || todayStr();
    const p = patient(db, pid);
    const fin = balanceOf(db, pid);
    const ss = db.sessions.filter(s => s.pid === pid).sort(byDateTime).slice(-30);
    const ap = db.appointments.filter(a => a.pid === pid);
    const payload = {
      today,
      patient: { name: p.name, age: p.age, gender: p.gender, complaint: p.complaint, registeredOn: p.registered, notes: p.notes },
      sessions: ss.map(s => ({ date: s.date, treatment: s.treatment, pain0to10: s.pain, notes: s.notes })),
      appointments: {
        upcoming: ap.filter(a => a.status === 'Scheduled' && a.date >= today).map(a => a.date + ' ' + a.time),
        completed: ap.filter(a => a.status === 'Completed').length,
        noShowOrCancelled: ap.filter(a => a.status === 'No-show' || a.status === 'Cancelled').length
      },
      billingINR: { charged: fin.charged, paid: fin.paid, due: fin.due, advance: fin.advance }
    };
    const system = 'You help a physiotherapist at a small clinic in India review a patient file. Use only the data provided; never invent findings, diagnoses or numbers. If data is thin, say so briefly. Be concise and practical. Plain text only, no markdown symbols.';
    const user = 'Write a summary of this patient in about 150 words with four short headed parts: Progress, Treatment so far, Suggested next steps (for the clinician to consider, not orders), Follow-up and billing. Write in ' + (lang || 'English') + '.\n\nPatient data (JSON):\n' + JSON.stringify(payload);
    return { system, user };
  }

  return {
    HEAD, STATUSES, PAY_TYPES, emptyDB, todayStr, addDays, diffDays, inr, round2, num,
    nextPatientId, nextApptId, nextSessionId, nextReceiptId,
    patient, balanceOf, totals, byDateTime, lastVisit, nextAppt,
    normDate, normTime, dbToWorkbook, workbookBase64, workbookToDB,
    localSummary, buildAIPrompt
  };
});
