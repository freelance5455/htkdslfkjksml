const assert = require('assert');
const path = require('path');
const { JSDOM } = require('jsdom');
const XLSX = require('xlsx');

const writes = [];
let failDocuments = false;
const files = {};

function mkCapacitor() {
  return {
    isNativePlatform: () => true,
    Plugins: {
      Filesystem: {
        requestPermissions: async () => ({ publicStorage: 'granted' }),
        writeFile: async o => {
          if (o.directory === 'DOCUMENTS' && failDocuments) throw new Error('EACCES (Permission denied)');
          writes.push(o); files[o.directory + ':' + o.path] = o.data; return { uri: 'file:///x' };
        },
        getUri: async o => ({ uri: 'file:///storage/emulated/0/' + (o.directory === 'DOCUMENTS' ? 'Documents/' : 'Android/data/in.virdiya.clinic/files/') + o.path }),
        readFile: async o => { const k = o.directory + ':' + o.path; if (!files[k]) throw new Error('not found'); return { data: files[k] }; }
      },
      Share: { share: async () => ({}) },
      App: { addListener() {}, exitApp() {} }
    }
  };
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
let n = 0;
const ok = m => { n++; console.log('ok -', m); };

async function boot() {
  const fs = require('fs'), www = path.join(__dirname, '../www');
  let html = fs.readFileSync(path.join(www, 'index.html'), 'utf8');
  html = html.replace(/<script src="([^"]+)"><\/script>/g, (m, src) => '<script>' + fs.readFileSync(path.join(www, src), 'utf8').replace(/<\/script>/g, '<\\/script>') + '</script>');
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://localhost/',
    beforeParse(w) { w.Capacitor = mkCapacitor(); w.confirm = () => true; w.scrollTo = () => {}; }
  });
  await new Promise(r => dom.window.addEventListener('load', r));
  await sleep(200);
  return dom;
}

function fill(w, vals) {
  const f = w.document.getElementById('mform');
  Object.keys(vals).forEach(k => { f.elements[k].value = vals[k]; });
  f.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
}
const click = (w, sel) => w.document.querySelector(sel).click();
const text = w => w.document.getElementById('view').textContent;

(async () => {
  const errors = [];
  let dom = await boot();
  let w = dom.window;
  w.addEventListener('error', e => errors.push(e.message));

  // first launch creates the Excel file straight away
  assert.ok(writes.length >= 1, 'workbook written at first launch');
  assert.strictEqual(writes[0].path, 'VirdiyaClinic/VirdiyaClinic_Data.xlsx');
  assert.strictEqual(writes[0].directory, 'DOCUMENTS');
  ok('first launch writes VirdiyaClinic/VirdiyaClinic_Data.xlsx to Documents');

  assert.ok(w.document.querySelector('svg.gauge'), 'gauge');
  assert.ok(/0 of 0/.test(text(w)));
  ok('home renders with goniometer gauge');

  // new patient
  click(w, '[data-act="new-patient"]');
  fill(w, { name: 'Ramesh Patel', age: '52', gender: 'Male', phone: '9876500000', complaint: 'Low back pain' });
  assert.ok(/VPC-0001/.test(w.document.getElementById('ttl').textContent), 'patient page open');
  assert.ok(/Ramesh Patel/.test(text(w)));
  ok('patient added with VPC-0001 and opened');

  // session with charge 500 and 300 paid now
  click(w, '[data-act="new-session"]');
  fill(w, { pid: 'VPC-0001', date: w.ClinicLogic.todayStr(), pain: '7', treatment: 'IFT, hot pack', notes: 'First visit', charge: '500', paidNow: '300', mode: 'UPI' });
  assert.ok(/Due\s*₹200/.test(text(w)), text(w));
  ok('session + part payment → Due ₹200');

  // take payment prefilled with due amount
  click(w, '[data-act="new-pay"]');
  assert.strictEqual(w.document.getElementById('mform').elements.amount.value, '200');
  fill(w, { pid: 'VPC-0001', date: w.ClinicLogic.todayStr(), type: 'Advance', amount: '1000', mode: 'Cash', note: 'package' });
  assert.ok(/Advance\s*₹800/.test(text(w)), text(w));
  ok('payment form prefilled with due; overpayment shows Advance ₹800');

  // appointment today then Done → opens session form
  click(w, '[data-act="new-appt"]');
  fill(w, { pid: 'VPC-0001', date: w.ClinicLogic.todayStr(), time: '11:30', purpose: 'Session 2', status: 'Scheduled', notes: '' });
  w.__clinic.A.tab({ tab: 'home' });
  assert.ok(/0 of 1/.test(text(w)));
  click(w, '[data-act="complete-appt"]');
  assert.ok(w.document.getElementById('mform'), 'session form opens after Done');
  fill(w, { pid: 'VPC-0001', date: w.ClinicLogic.todayStr(), pain: '4', treatment: 'IFT', notes: 'Better', charge: '500', paidNow: '', mode: 'Cash' });
  w.__clinic.A.tab({ tab: 'home' });
  assert.ok(/1 of 1/.test(text(w)));
  ok('appointment booked, completed, session logged, gauge 1 of 1');

  // edit appointment
  w.__clinic.A.tab({ tab: 'sched' });
  assert.ok(/Session 2/.test(text(w)));
  click(w, '.row[data-act="edit-appt"]');
  fill(w, { pid: 'VPC-0001', date: '2026-12-01', time: '09:00', purpose: 'Review', status: 'Scheduled', notes: '' });
  w.__clinic.A.mode({ mode: 'up' });
  assert.ok(/Review/.test(text(w)) && /Dec/.test(text(w)));
  ok('appointment edited and shown in Upcoming');

  // money + patients search + snapshot
  w.__clinic.A.tab({ tab: 'money' });
  assert.ok(/Advance in hand/.test(text(w)) && /INV-2026-0002/.test(text(w)));
  w.__clinic.A.tab({ tab: 'patients' });
  const q = w.document.getElementById('q'); q.value = '98765'; q.dispatchEvent(new w.Event('input', { bubbles: true }));
  assert.ok(/Ramesh/.test(w.document.getElementById('plist').textContent));
  q.value = 'zzz'; q.dispatchEvent(new w.Event('input', { bubbles: true }));
  assert.ok(/No patient matches/.test(w.document.getElementById('plist').textContent));
  q.value = ''; q.dispatchEvent(new w.Event('input', { bubbles: true }));
  w.__clinic.A['open-patient']({ id: 'VPC-0001' });
  assert.ok(/Pain improved from 7 to 4/.test(text(w)) && /History/.test(text(w)));
  ok('money tab, search, patient snapshot and history');

  // debounce writes Excel with everything in it
  await sleep(1000);
  const last = writes[writes.length - 1];
  const wb = XLSX.read(last.data, { type: 'base64' });
  const rows = XLSX.utils.sheet_to_json(wb.Sheets.Balances);
  assert.strictEqual(rows.length, 1);
  assert.strictEqual(rows[0]['Advance (INR)'], 300);
  assert.strictEqual(XLSX.utils.sheet_to_json(wb.Sheets.Sessions).length, 2);
  ok('Excel file on disk mirrors app data (2 sessions, billed 1000, paid 1300 → advance 300)');

  // AI without key gives a clear message
  w.__clinic.A.ai({ id: 'VPC-0001' });
  assert.ok(/API key/.test(w.document.getElementById('toast').textContent));
  ok('AI summary without key explains what is needed');

  // AI with mocked API
  w.__clinic.db.settings.aiKey = 'sk-ant-test';
  let sent;
  w.fetch = async (url, o) => { sent = { url, o }; return { ok: true, json: async () => ({ content: [{ type: 'text', text: 'Progress: improving.' }] }) }; };
  await w.__clinic.A.ai({ id: 'VPC-0001' });
  await sleep(50);
  assert.strictEqual(sent.url, 'https://api.anthropic.com/v1/messages');
  assert.ok(!/9876500000/.test(sent.o.body));
  assert.strictEqual(w.__clinic.db.patients[0].aiSummary, 'Progress: improving.');
  assert.ok(/Progress: improving/.test(text(w)));
  ok('AI summary stored on patient and shown; phone not sent');

  // data tab + settings
  w.__clinic.A.tab({ tab: 'data' });
  assert.ok(/Excel file is up to date/.test(text(w)) && /Documents\/VirdiyaClinic\/VirdiyaClinic_Data.xlsx/.test(text(w)));
  ok('Excel tab shows the folder path');

  // restore from Excel after app data is wiped
  await sleep(900);
  dom.window.close();
  dom = await boot(); w = dom.window;   // fresh WebView storage, Excel file still in the folder
  assert.strictEqual(w.__clinic.db.patients.length, 1);
  assert.strictEqual(w.__clinic.db.sessions.length, 2);
  assert.strictEqual(w.__clinic.db.patients[0].aiSummary, 'Progress: improving.');
  ok('after reinstall / cleared app data, everything is restored from the Excel file');

  // fallback folder when Documents is blocked
  writes.length = 0; failDocuments = true;
  w.__clinic.persist(); await sleep(1000);
  assert.strictEqual(writes[writes.length - 1].directory, 'EXTERNAL');
  assert.ok(/app’s own folder/.test(w.document.getElementById('view').textContent) || true);
  w.__clinic.A.tab({ tab: 'data' });
  assert.ok(/app’s own folder/.test(text(w)), text(w));
  ok('falls back to app folder when Documents is blocked and says so');

  assert.deepStrictEqual(errors, []);
  console.log('\n' + n + ' UI tests passed');
  process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
