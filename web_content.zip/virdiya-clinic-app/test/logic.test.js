const assert = require('assert');
const XLSX = require('xlsx');
const L = require('../www/logic.js');

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };

function sample() {
  const db = L.emptyDB();
  db.patients.push({ id: L.nextPatientId(db), name: 'Ramesh Patel', age: '52', gender: 'Male', phone: '9876500000', address: 'Adajan, Surat', complaint: 'Low back pain', referredBy: '', registered: '2026-09-01', notes: '' });
  db.patients.push({ id: L.nextPatientId(db), name: 'Kiran Shah', age: '34', gender: 'Female', phone: '9876511111', address: '', complaint: 'Frozen shoulder', referredBy: 'Dr. Mehta', registered: '2026-09-05', notes: '' });
  db.sessions.push({ id: L.nextSessionId(db), pid: 'VPC-0001', date: '2026-09-02', treatment: 'IFT, hot pack, core exercises', pain: '8', notes: 'Painful flexion', charge: '500' });
  db.sessions.push({ id: L.nextSessionId(db), pid: 'VPC-0001', date: '2026-09-09', treatment: 'IFT, McKenzie', pain: '5', notes: 'Better extension', charge: '500' });
  db.payments.push({ id: L.nextReceiptId(db, '2026-09-02'), pid: 'VPC-0001', date: '2026-09-02', type: 'Payment', amount: '500', mode: 'Cash', note: '' });
  db.payments.push({ id: L.nextReceiptId(db, '2026-09-10'), pid: 'VPC-0002', date: '2026-09-10', type: 'Advance', amount: '3000', mode: 'UPI', note: 'package' });
  db.appointments.push({ id: L.nextApptId(db), pid: 'VPC-0001', date: '2026-09-25', time: '10:30', purpose: 'Session', status: 'Scheduled', notes: '' });
  db.appointments.push({ id: L.nextApptId(db), pid: 'VPC-0001', date: '2026-09-16', time: '10:30', purpose: 'Session', status: 'No-show', notes: '' });
  return db;
}

t('ids follow VPC-0001 and INV-YYYY-0001', () => {
  const db = sample();
  assert.strictEqual(db.patients[1].id, 'VPC-0002');
  assert.strictEqual(db.payments[0].id, 'INV-2026-0001');
  assert.strictEqual(db.payments[1].id, 'INV-2026-0002');
  assert.strictEqual(L.nextReceiptId(db, '2027-01-02'), 'INV-2027-0001');
});

t('balance: due, advance, refund', () => {
  const db = sample();
  const a = L.balanceOf(db, 'VPC-0001');
  assert.deepStrictEqual([a.charged, a.paid, a.due, a.advance], [1000, 500, 500, 0]);
  const b = L.balanceOf(db, 'VPC-0002');
  assert.deepStrictEqual([b.charged, b.paid, b.due, b.advance], [0, 3000, 0, 3000]);
  db.payments.push({ id: 'x', pid: 'VPC-0002', date: '2026-09-11', type: 'Refund', amount: '500', mode: 'Cash', note: '' });
  assert.strictEqual(L.balanceOf(db, 'VPC-0002').advance, 2500);
});

t('totals', () => {
  const db = sample();
  const tt = L.totals(db, '2026-09-21');
  assert.strictEqual(tt.due, 500); assert.strictEqual(tt.dueCount, 1);
  assert.strictEqual(tt.advance, 3000);
  assert.strictEqual(tt.monthCollected, 3500);
});

t('INR uses Indian grouping', () => {
  assert.strictEqual(L.inr(1234567), '₹12,34,567');
  assert.strictEqual(L.inr(500), '₹500');
  assert.strictEqual(L.inr(1500.5), '₹1,500.50');
  assert.strictEqual(L.inr(0), '₹0');
});

t('excel round trip keeps everything', () => {
  const db = sample();
  db.patients[0].aiSummary = 'Doing well.'; db.patients[0].aiDate = '2026-09-20';
  const b64 = L.workbookBase64(XLSX, db, '2026-09-21');
  const wb = XLSX.read(b64, { type: 'base64' });
  assert.deepStrictEqual(wb.SheetNames, ['Patients', 'Appointments', 'Sessions', 'Payments', 'Balances', 'Settings']);
  const back = L.workbookToDB(XLSX, wb);
  assert.strictEqual(back.patients.length, 2);
  assert.strictEqual(back.patients[0].aiSummary, 'Doing well.');
  assert.strictEqual(back.sessions.length, 2);
  assert.strictEqual(back.sessions[1].pain, '5');
  assert.strictEqual(back.payments[1].type, 'Advance');
  assert.strictEqual(back.appointments.length, 2);
  assert.strictEqual(back.appointments[0].date, '2026-09-16');
  assert.strictEqual(L.balanceOf(back, 'VPC-0001').due, 500);
});

t('balances sheet is readable in Excel', () => {
  const wb = L.dbToWorkbook(XLSX, sample(), '2026-09-21');
  const rows = XLSX.utils.sheet_to_json(wb.Sheets.Balances);
  assert.strictEqual(rows[0]['Due (INR)'], 500);
  assert.strictEqual(rows[1]['Advance (INR)'], 3000);
  assert.strictEqual(rows[0]['Next Appointment'], '2026-09-25 10:30');
});

t('import handles Excel-style dates, times and missing IDs', () => {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([L.HEAD.patients, ['', 'Meena', 40, 'Female', '99', '', 'Neck pain', '', 46266, '']]), 'Patients');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([L.HEAD.appointments, ['', 'VPC-0001', 'Meena', '05/10/2026', 0.5, 'Session', 'Scheduled', '']]), 'Appointments');
  const db = L.workbookToDB(XLSX, wb);
  assert.strictEqual(db.patients[0].id, 'VPC-0001');
  assert.strictEqual(db.patients[0].registered, '2026-09-01');
  assert.strictEqual(db.appointments[0].date, '2026-10-05');
  assert.strictEqual(db.appointments[0].time, '12:00');
  assert.strictEqual(db.appointments[0].id, 'A-0001');
});

t('offline summary reports pain trend, dues and follow-up', () => {
  const db = sample();
  const s = L.localSummary(db, 'VPC-0001', '2026-09-21').join('\n');
  assert.ok(/Pain improved from 8 to 5/.test(s), s);
  assert.ok(/due ₹500/.test(s), s);
  assert.ok(/Next appointment: 2026-09-25/.test(s), s);
  assert.ok(/ift \(2\)/.test(s), s);
  const s2 = L.localSummary(db, 'VPC-0002', '2026-09-21').join('\n');
  assert.ok(/No treatment sessions/.test(s2) && /advance ₹3,000/.test(s2), s2);
  db.appointments = [];
  const s3 = L.localSummary(db, 'VPC-0001', '2026-10-01').join('\n');
  assert.ok(/not seen for 22 days/.test(s3), s3);
});

t('AI prompt leaves out phone and address', () => {
  const { user } = L.buildAIPrompt(sample(), 'VPC-0001', 'Gujarati', '2026-09-21');
  assert.ok(!/9876500000|Adajan/.test(user));
  assert.ok(/Gujarati/.test(user) && /Low back pain/.test(user));
});

t('date helpers', () => {
  assert.strictEqual(L.addDays('2026-09-30', 1), '2026-10-01');
  assert.strictEqual(L.diffDays('2026-09-21', '2026-09-01'), 20);
});

console.log('\n' + n + ' logic tests passed');
