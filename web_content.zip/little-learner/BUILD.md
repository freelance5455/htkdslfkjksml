# Little Learner – PWA और APK (अभी बना/टेस्ट नहीं हुआ)

## PWA (HTTPS या localhost चाहिए)
1. इसी फ़ोल्डर में: `python3 -m http.server 8080`
2. Chrome में http://localhost:8080 खोलें (फ़ोन पर: HTTPS होस्टिंग जैसे GitHub Pages)।
3. Chrome menu → Install app / Add to Home screen। एक बार लोड के बाद ऑफ़लाइन चलना चाहिए।
`file://` से खोलने पर Service Worker नहीं चलता; ऐप फिर भी सामान्य रूप से चलती है।

## APK (Capacitor) – कंप्यूटर, Node.js 18+, JDK 17 और Android Studio/SDK चाहिए (सब मुफ़्त)
```
npm install
npm run prepare-www
npx cap add android
npx cap sync
npx cap open android      # Android Studio: Build > Build APK(s)
```
Play Store के लिए: signed AAB और Google Developer अकाउंट (एक बार ~$25)।
