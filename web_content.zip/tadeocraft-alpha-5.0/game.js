'use strict';
const CS=16,H=64,$=i=>document.getElementById(i),Q=s=>document.querySelectorAll(s);
let L=0;try{L=+localStorage.getItem('tc_lang')||0}catch(e){}
const LN=['Español','English','Português','Français'];
const T={
spl:['¡Mundo infinito!','Infinite world!','Mundo infinito!','Monde infini !'],
play:['Jugar','Play','Jogar','Jouer'],ctl:['Controles','Controls','Controles','Commandes'],lang:['Idioma','Language','Idioma','Langue'],
cv:[['Auto','Táctil (joystick)','Teclado y ratón'],['Auto','Touch (joystick)','Keyboard & mouse'],['Auto','Toque (joystick)','Teclado e mouse'],['Auto','Tactile (joystick)','Clavier et souris']],
help:['WASD mover · Espacio saltar/volar · Shift bajar · Ctrl correr<br>Click izq. romper/atacar · Click der. colocar/usar · F portal · E comer · 1-9 0 - = bloque<br>Móvil: joystick y botones<br><b>Nether:</b> marco de obsidiana 4×5 + F · <b>End:</b> fortaleza bajo tierra · <b>Mesa de crafteo:</b> click der.','WASD move · Space jump/fly · Shift down · Ctrl sprint<br>Left click break/attack · Right click place/use · F portal · E eat · 1-9 0 - = block<br>Mobile: joystick and buttons<br><b>Nether:</b> 4×5 obsidian frame + F · <b>End:</b> underground stronghold · <b>Crafting table:</b> right click','WASD mover · Espaço pular/voar · Shift descer · Ctrl correr<br>Clique esq. quebrar/atacar · Clique dir. colocar/usar · F portal · E comer · 1-9 0 - = bloco<br>Celular: joystick e botões<br><b>Nether:</b> moldura de obsidiana 4×5 + F · <b>End:</b> fortaleza subterrânea · <b>Mesa de trabalho:</b> clique dir.','ZQSD/WASD bouger · Espace sauter/voler · Shift descendre · Ctrl courir<br>Clic gauche casser/attaquer · Clic droit poser/utiliser · F portail · E manger · 1-9 0 - = bloc<br>Mobile : joystick et boutons<br><b>Nether :</b> cadre d\'obsidienne 4×5 + F · <b>End :</b> forteresse souterraine · <b>Établi :</b> clic droit'],
newW:['Crear mundo nuevo','Create new world','Criar novo mundo','Créer un monde'],wname:['Nombre del mundo','World name','Nome do mundo','Nom du monde'],
wseed:['Semilla (vacío = aleatoria)','Seed (empty = random)','Semente (vazio = aleatória)','Graine (vide = aléatoire)'],
mode:['Modo de juego','Game mode','Modo de jogo','Mode de jeu'],diff:['Dificultad','Difficulty','Dificuldade','Difficulté'],gfx:['Gráficos','Graphics','Gráficos','Graphismes'],
create:['Crear','Create','Criar','Créer'],back:['Atrás','Back','Voltar','Retour'],loading:['Cargando mundo','Loading world','Carregando mundo','Chargement du monde'],
paused:['Juego en pausa','Game paused','Jogo pausado','Jeu en pause'],resume:['Continuar','Resume','Continuar','Reprendre'],exit:['Salir al menú','Quit to menu','Sair para o menu','Quitter au menu'],
modes:[['Supervivencia','Creativo','Aventura','Espectador'],['Survival','Creative','Adventure','Spectator'],['Sobrevivência','Criativo','Aventura','Espectador'],['Survie','Créatif','Aventure','Spectateur']],
diffs:[['Pacífico','Normal','Difícil'],['Peaceful','Normal','Hard'],['Pacífico','Normal','Difícil'],['Paisible','Normal','Difficile']],
dims:[['Superficie','Nether','El End'],['Overworld','Nether','The End'],['Superfície','Nether','O End'],['Surface','Nether','L\'End']],
ld:[['Preparando mundo','Generando terreno, cuevas y aldeas...','Aplicando texturas y gráficos','¡Listo!'],['Preparing world','Generating terrain, caves and villages...','Applying textures and graphics','Done!'],['Preparando mundo','Gerando terreno, cavernas e aldeias...','Aplicando texturas e gráficos','Pronto!'],['Préparation du monde','Génération du terrain, grottes et villages...','Application des textures et graphismes','Terminé !']],
craftT:['Mesa de crafteo','Crafting table','Mesa de trabalho','Établi'],close:['Cerrar','Close','Fechar','Fermer'],
mIgn:['¡Portal al Nether activado!','Nether portal lit!','Portal do Nether ativado!','Portail du Nether activé !'],
mAim:['Apunta a un marco de obsidiana','Aim at an obsidian frame','Mire em uma moldura de obsidiana','Visez un cadre d\'obsidienne'],
mFrame:['Necesitas un marco de obsidiana 4×5 completo y vacío por dentro','You need a full 4×5 obsidian frame, empty inside','Você precisa de uma moldura de obsidiana 4×5 completa e vazia','Il faut un cadre d\'obsidienne 4×5 complet et vide'],
mDie:['Has muerto','You died','Você morreu','Vous êtes mort'],mDrag:['¡Has derrotado al Ender Dragón!','You defeated the Ender Dragon!','Você derrotou o Ender Dragon!','Vous avez vaincu l\'Ender Dragon !'],
mWit:['¡Has derrotado al Wither!','You defeated the Wither!','Você derrotou o Wither!','Vous avez vaincu le Wither !'],
mWel:['Fortaleza del End bajo tierra cerca de X32 Z16 · Nether: marco de obsidiana + F','End stronghold underground near X32 Z16 · Nether: obsidian frame + F','Fortaleza do End subterrânea perto de X32 Z16 · Nether: moldura de obsidiana + F','Forteresse de l\'End sous terre près de X32 Z16 · Nether : cadre d\'obsidienne + F'],
n3:['Piedra','Stone','Pedra','Pierre'],n4:['Arena','Sand','Areia','Sable'],n5:['Tronco','Log','Tronco','Bûche'],n6:['Hojas','Leaves','Folhas','Feuilles'],n7:['Tablones','Planks','Tábuas','Planches'],
n12:['Obsidiana','Obsidian','Obsidiana','Obsidienne'],n16:['Mesa de crafteo','Crafting table','Mesa de trabalho','Établi'],n17:['Vidrio','Glass','Vidro','Verre'],n18:['Puerta','Door','Porta','Porte'],n20:['Manzana','Apple','Maçã','Pomme']};
const t=k=>T[k][L];
const J={x:0,y:0},P={x:0,y:0,z:0,vy:0,yaw:0,pit:0,on:false,fly:false},K={},S={mode:0,gfx:2,diff:1};
let TOUCH=false,paused=false,CTL=0,WN='',craftOpen=false,seed=0,worlds=[],W=null,dim=0,ents=[],inv={},sel=0,playing=false,hp=20,hg=20,stT=0,cdT=0,fogR=80,spT=0,lastSp=0,fr=0,orbit=0,clT=0;
const HEX=[0,0x59b340,0x80593a,0x808080,0xe6d98c,0x66472a,0x338026,0xb38c4d,0xf2f2ff,0x666669,0x73262a,0xe6e699,0x1a0d33,0x9933e6,0x1a4d33,0x1a1a1a,0x9a6b35,0xaad8f0,0x8a5a2a,0x8a5a2a,0xdd3322],HOT=[1,2,3,4,5,6,7,9,12,16,17,18],RD=[3,4,6,8];
const solid=i=>i>0&&i!=13&&i!=14&&i!=19;
const hs=(x,y,z)=>{const n=Math.sin(x*127.1+y*311.7+z*74.7+seed)*43758.5453;return n-Math.floor(n)},sm=q=>q*q*(3-2*q);
function vn(x,y,z){const X=Math.floor(x),Y=Math.floor(y),Z=Math.floor(z),a=sm(x-X),b=sm(y-Y),c=sm(z-Z);let r=0;for(let i=0;i<2;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++)r+=hs(X+i,Y+j,Z+k)*(i?a:1-a)*(j?b:1-b)*(k?c:1-c);return r}
class Wd{constructor(d){this.d=d;this.ch=new Map();this.lc=null}
get(cx,cz){return this.ch.get(cx+','+cz)}
cc(cx,cz){const l=this.lc;if(l&&l.cx==cx&&l.cz==cz)return l;const c=this.ch.get(cx+','+cz)||null;if(c)this.lc=c;return c}
g(x,y,z){if(y<0||y>=H)return 0;const cx=Math.floor(x/CS),cz=Math.floor(z/CS),c=this.cc(cx,cz);if(!c)return 3;return c.b[(y*CS+(z-cz*CS))*CS+(x-cx*CS)]}
s(x,y,z,v){if(y<0||y>=H)return;const cx=Math.floor(x/CS),cz=Math.floor(z/CS),c=this.cc(cx,cz);if(!c)return;const lx=x-cx*CS,lz=z-cz*CS;c.b[(y*CS+lz)*CS+lx]=v;c.dirty=1;if(y>c.top)c.top=y;
const d=(a,b)=>{const n=this.get(a,b);if(n)n.dirty=1};if(lx==0)d(cx-1,cz);if(lx==CS-1)d(cx+1,cz);if(lz==0)d(cx,cz-1);if(lz==CS-1)d(cx,cz+1)}}
const baseH=(x,z)=>Math.floor(14+vn(x/60,z/60,3)*16+vn(x/22,z/22,1)*8+vn(x/7,z/7,2)*3);
function vil(x,z){const rx=Math.floor(x/128),rz=Math.floor(z/128);if(!rx&&!rz)return{cx:46,cz:32,y:18};if(hs(rx,rz,77)>.5)return null;const cx=rx*128+40+Math.floor(hs(rx,rz,78)*48),cz=rz*128+40+Math.floor(hs(rx,rz,79)*48);return{cx,cz,y:Math.max(16,Math.min(30,baseH(cx,cz)))}}
function surf(x,z){let y=baseH(x,z),f=0;const b=vn(x/40,z/40,0);let tp=b<.35?0:b<.65?(vn(x/12,z/12,5)>.55?2:1):3;
if(Math.hypot(x-20,z-32)<8){y=18;tp=1;f=1}const v=vil(x,z);if(v&&Math.abs(x-v.cx)<15&&Math.abs(z-v.cz)<15){y=v.y;tp=1;f=1}return{y,t:tp,f}}
const cave=(x,y,z)=>(Math.abs(vn(x/20,y/12,z/20)-.5)<.05&&Math.abs(vn(x/20+50,y/12+30,z/20+50)-.5)<.06)||vn(x/28,y/14,z/28+90)>.77;
function genO(c,x0,z0,put){const N=CS+4,S2=[];for(let i=0;i<N;i++)for(let j=0;j<N;j++)S2.push(surf(x0+i-2,z0+j-2));
for(let lx=0;lx<CS;lx++)for(let lz=0;lz<CS;lz++){const gx=x0+lx,gz=z0+lz,s=S2[(lx+2)*N+lz+2],lim=s.f?-1:(vn(gx/9,gz/9,7)>.78?0:3);
for(let y=0;y<=s.y;y++){let id;if(y<3)id=(y==0||hs(gx,y,gz)<(y==1?.8:.4))?15:3;else{id=y<s.y-3?3:y<s.y?(s.t==0?4:2):(s.t==0?4:s.t==3?8:1);if(lim>=0&&y<=s.y-lim&&cave(gx,y,gz))id=0}c.b[(y*CS+lz)*CS+lx]=id}if(s.y>c.top)c.top=s.y}
for(let i=0;i<N;i++)for(let j=0;j<N;j++){const s=S2[i*N+j],gx=x0+i-2,gz=z0+j-2;if(!s.f&&s.t&&hs(gx,9,gz)<(s.t==2?.04:.012)){for(let k=1;k<=4;k++)put(gx,s.y+k,gz,5);
for(let a=-2;a<=2;a++)for(let b=-2;b<=2;b++)for(let k=3;k<=5;k++){const m=Math.abs(a)+Math.abs(b);if(m<4&&!(k==5&&m>1)&&!(a==0&&b==0&&k<5))put(gx+a,s.y+k,gz+b,6)}}}
const v=vil(x0,z0);if(v&&Math.abs(v.cx-x0)<40&&Math.abs(v.cz-z0)<40){c.vil=[];
[[-6,-6],[6,-6],[-6,6],[4,6]].forEach(([ox,oz])=>{const hx=v.cx+ox,hz=v.cz+oz;for(let a=0;a<5;a++)for(let b=0;b<5;b++)for(let k=1;k<=4;k++){const e=a%4==0||b%4==0;let id;
if(k==4)id=7;else if(!e)id=0;else if(a%4==0&&b%4==0)id=5;else if(a==2&&b==0&&k<3)id=18;else if(k==2&&((a==0&&b==2)||(a==4&&b==2)||(a==2&&b==4)))id=17;else id=7;put(hx+a,v.y+k,hz+b,id)}
const vx=hx+2,vz=hz+2;if(vx>=x0&&vx<x0+CS&&vz>=z0&&vz<z0+CS)c.vil.push(['vil',vx+.5,v.y+1,vz+.5])});
if(v.cx>=x0&&v.cx<x0+CS&&v.cz>=z0&&v.cz<z0+CS)c.vil.push(['gol',v.cx+.5,v.y+1,v.cz+.5])}
if(x0<=39&&x0+CS>25&&z0<=23&&z0+CS>9){for(let x=25;x<=39;x++)for(let z=9;z<=23;z++)for(let y=4;y<=11;y++)put(x,y,z,(x==25||x==39||z==9||z==23||y==4||y==11)?9:0);
for(let x=26;x<39;x+=4)for(let z=10;z<23;z+=4)for(let y=5;y<=10;y++)put(x,y,z,9);for(let i=0;i<3;i++)for(let j=0;j<3;j++)put(31+i,5,15+j,14)}}
function genN(c,x0,z0,put){c.top=H-1;for(let lx=0;lx<CS;lx++)for(let lz=0;lz<CS;lz++){const x=x0+lx,z=z0+lz,op=x>14&&x<28&&z>26&&z<40;
for(let y=0;y<H;y++){let id;if(y<3||y>=H-3)id=15;else if(op&&y>3&&y<14)id=0;else id=(y<4||y>56||vn(x/9,y/7,z/9)>.42)?10:0;c.b[(y*CS+lz)*CS+lx]=id}}
for(let i=0;i<4;i++)for(let j=0;j<5;j++)put(20+i,3+j,32,(i%3==0||j%4==0)?12:13)}
function genE(c,x0,z0,put){for(let lx=0;lx<CS;lx++)for(let lz=0;lz<CS;lz++){const d=Math.hypot(x0+lx-32,z0+lz-32);if(d<24)for(let y=Math.floor(18-(24-d)/3);y<=18;y++)put(x0+lx,y,z0+lz,11)}
for(let i=0;i<6;i++){const a=i*1.047,px=Math.round(32+17*Math.cos(a)),pz=Math.round(32+17*Math.sin(a));for(let y=19;y<28+i*2;y++)for(let p=0;p<2;p++)for(let q=0;q<2;q++)put(px+p,y,pz+q,12)}
for(let i=0;i<3;i++)for(let j=0;j<3;j++)put(31+i,19,31+j,14)}
function genChunk(w,cx,cz){const c={cx,cz,b:new Uint8Array(CS*H*CS),top:0,dirty:1,mesh:null,gm:null,sp:false,vil:null};w.ch.set(cx+','+cz,c);const x0=cx*CS,z0=cz*CS;
const put=(x,y,z,v)=>{if(x>=x0&&x<x0+CS&&z>=z0&&z<z0+CS&&y>=0&&y<H){c.b[(y*CS+z-z0)*CS+x-x0]=v;if(y>c.top)c.top=y}};[genO,genN,genE][w.d](c,x0,z0,put);
for(const[a,b]of[[1,0],[-1,0],[0,1],[0,-1]]){const n=w.get(cx+a,cz+b);if(n)n.dirty=1}}
const scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera(75,1,.1,400);cam.rotation.order='YXZ';
const ren=new THREE.WebGLRenderer({canvas:$('c'),antialias:false}),amb=new THREE.AmbientLight(0xffffff,.6),sun=new THREE.DirectionalLight(0xffffff,.9);
scene.add(amb,sun,sun.target);sun.shadow.mapSize.set(2048,2048);{const c=sun.shadow.camera;c.left=c.bottom=-45;c.right=c.top=45;c.near=1;c.far=220}ren.shadowMap.type=THREE.PCFSoftShadowMap;
const skyU={top:{value:new THREE.Color()},bot:{value:new THREE.Color()},sd:{value:new THREE.Vector3(.5,.7,.3)}};
const sky=new THREE.Mesh(new THREE.SphereGeometry(250,24,12),new THREE.ShaderMaterial({uniforms:skyU,side:THREE.BackSide,depthWrite:false,fog:false,
vertexShader:'varying vec3 v;void main(){v=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
fragmentShader:'uniform vec3 top,bot,sd;varying vec3 v;void main(){vec3 d=normalize(v);vec3 c=mix(bot,top,clamp(d.y*1.5,0.,1.));c+=vec3(1.,.85,.5)*pow(max(dot(d,sd),0.),64.)*.8;gl_FragColor=vec4(c,1.);}'}));sky.renderOrder=-1;scene.add(sky);
const TC=8,TR=3,TS=16,rr=(a,b,c)=>{const n=Math.sin(a*12.9898+b*78.233+c*37.719)*43758.5453;return n-Math.floor(n)};
const TEX=[
(x,y)=>{const v=.8+.4*rr(x,y,0);return rr(x,y,50)>.9?[60*v,130*v,45]:[89*v,170*v,64*v]},
(x,y)=>{if(y<3+Math.floor(rr(x,0,1)*3)){const v=.8+.4*rr(x,y,1);return[89*v,170*v,64*v]}const v=.8+.4*rr(x,y,2);return[128*v,89*v,58*v]},
(x,y)=>{const v=.8+.4*rr(x,y,2);return rr(x,y,52)>.9?[90,62,40]:[128*v,89*v,58*v]},
(x,y)=>{const v=.82+.3*rr(x,y,3),c=rr(x>>1,y>>1,53)>.86?.72:1;return[128*v*c,128*v*c,132*v*c]},
(x,y)=>{const v=.9+.2*rr(x,y,4);return[230*v,217*v,140*v]},
(x,y)=>{const v=.78+.22*Math.sin(x*2.3+rr(x,0,5)*3)+.1*rr(x,y,5);return[102*v,71*v,42*v]},
(x,y)=>{const d=Math.hypot(x-7.5,y-7.5);if(x<1||y<1||x>14||y>14)return[92,64,38];const v=.9+.1*rr(x,y,6);return Math.sin(d*2.2)>0?[185*v,145*v,88*v]:[150*v,112*v,64*v]},
(x,y)=>{const v=.6+.6*rr(x,y,7);return rr(x,y,57)>.78?[28,85,24]:[56*v,138*v,40*v]},
(x,y)=>{const v=.92+.14*rr(x,y,8),j=((y>>2)&1)?3:11;return y%4==3||x==j?[120,88,44]:[182*v,142*v,80*v]},
(x,y)=>{const v=.95+.05*rr(x,y,9);return[240*v,246*v,255*v]},
(x,y)=>{const o=((y>>2)&1)*4,id=rr(Math.floor((x+o)/8),y>>2,10),v=.65+.5*id+.1*rr(x,y,11);return y%4==3||(x+o)%8==7?[60,60,62]:[125*v,125*v,128*v]},
(x,y)=>{const v=.7+.6*rr(x,y,12);return rr(x,y,62)>.88?[170,75,62]:[120*v,42*v,46*v]},
(x,y)=>{const v=.9+.2*rr(x,y,13);return rr(x,y,63)>.9?[195,200,125]:[228*v,232*v,162*v]},
(x,y)=>{const v=.8+.4*rr(x,y,14);return rr(x,y,64)>.9?[100,45,150]:[26*v,13*v,44*v]},
(x,y)=>{const v=.65+.35*Math.sin((x+y)*.7+rr(x>>1,y>>1,15)*3);return[150*v,50*v,235*v]},
(x,y)=>{const v=.7+.5*rr(x,y,16);return rr(x,y,66)>.86?[80,215,160]:[10*v,42*v,36*v]},
(x,y)=>{const v=.5+.9*rr(x,y,17);return rr(x,y,67)>.85?[95,95,95]:[42*v,42*v,42*v]},
(x,y)=>{const v=.9+.1*rr(x,y,20);return(x%8==0||y%8==0||x==15||y==15)?[70,48,24]:[170*v,128*v,70*v]},
(x,y)=>{const v=.9+.1*rr(x,y,21);if(y<3)return[90,60,30];if(x>3&&x<12&&y>5&&y<11&&(x+y)%3==0)return[60,60,60];return[165*v,125*v,68*v]},
(x,y)=>{if(x==0||y==0||x==15||y==15)return[220,240,250,.9];return(x+y==9&&x>2&&x<8)?[255,255,255,.7]:[170,215,235,.22]},
(x,y)=>{const v=.9+.1*rr(x,y,22);if(x==0||x==15||y==0||y==15)return[85,55,25];if((x>2&&x<7||x>8&&x<13)&&(y>2&&y<7||y>8&&y<13))return[120*v,80*v,38*v];if(x==12&&y==7)return[220,200,60];return[150*v,100*v,50*v]},
(x,y)=>x<3?[110,72,35,1]:[0,0,0,0]];
const ATLAS=(()=>{const cv=document.createElement('canvas');cv.width=TS*TC;cv.height=TS*TR;const q=cv.getContext('2d');
TEX.forEach((f,i)=>{for(let y=0;y<TS;y++)for(let x=0;x<TS;x++){const c=f(x,y);q.fillStyle=`rgba(${Math.min(255,c[0])|0},${Math.min(255,c[1])|0},${Math.min(255,c[2])|0},${c[3]===undefined?1:c[3]})`;q.fillRect((i%TC)*TS+x,Math.floor(i/TC)*TS+y,1,1)}});
const tx=new THREE.CanvasTexture(cv);tx.magFilter=tx.minFilter=THREE.NearestFilter;return tx})();
const tileOf=(id,f)=>id==1?(f==2?0:f==3?2:1):id==2?2:id==3?3:id==4?4:id==5?(f>1&&f<4?6:5):id==6?7:id==7?8:id==8?9:id==9?10:id==10?11:id==11?12:id==12?13:id==13?14:id==14?15:id==15?16:id==16?(f==2?17:f==3?8:18):id==17?19:id==18?20:21;
const matL=new THREE.MeshLambertMaterial({vertexColors:true,map:ATLAS}),matU=new THREE.MeshStandardMaterial({vertexColors:true,map:ATLAS,roughness:.85}),matG=new THREE.MeshLambertMaterial({vertexColors:true,map:ATLAS,transparent:true,depthWrite:false,side:THREE.DoubleSide});
const curMat=()=>S.gfx==3?matU:matL;
const ENV=[[0x87ceeb,0x3a7bd5,0xbfe3ff,.6,.9],[0x3a0a0a,0x2a0505,0x6a1a0a,.85,.4],[0x0b0614,0x05020d,0x241040,.45,.5]];
function setEnv(){const e=ENV[dim],u=S.gfx==3;scene.background=u?null:new THREE.Color(e[0]);scene.fog=new THREE.Fog(u?e[2]:e[0],fogR*.4,fogR);skyU.top.value.set(e[1]);skyU.bot.value.set(e[2]);skyU.sd.value.set(.5,dim?-.5:.7,.3).normalize();amb.intensity=e[3]+(u?.1:0);sun.intensity=e[4]}
function applyGfx(){const g=S.gfx;ren.setPixelRatio([.5,.75,1,Math.min(devicePixelRatio,2)][g]);ren.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();
ren.shadowMap.enabled=g==3;sun.castShadow=g==3;ren.toneMapping=g==3?THREE.ACESFilmicToneMapping:THREE.NoToneMapping;fogR=RD[g]*16*.92;sky.visible=g==3;
matL.needsUpdate=matU.needsUpdate=true;if(W)W.ch.forEach(c=>{if(c.mesh)c.mesh.material=curMat()});setEnv()}
const FD=[[1,0,0,[1,0,1],[1,0,0],[1,1,0],[1,1,1]],[-1,0,0,[0,0,0],[0,0,1],[0,1,1],[0,1,0]],[0,1,0,[0,1,1],[1,1,1],[1,1,0],[0,1,0]],[0,-1,0,[0,0,0],[1,0,0],[1,0,1],[0,0,1]],[0,0,1,[0,0,1],[1,0,1],[1,1,1],[0,1,1]],[0,0,-1,[1,0,0],[0,0,0],[0,1,0],[1,1,0]]];
function rm(c){[c.mesh,c.gm].forEach(m=>{if(m){scene.remove(m);m.geometry.dispose()}});c.mesh=c.gm=null}
const unmesh=w=>w&&w.ch.forEach(rm);
function meshChunk(c){rm(c);c.dirty=0;const A=[0,1].map(()=>({P:[],N:[],C:[],U:[],I:[],n:0})),x0=c.cx*CS,z0=c.cz*CS,top=Math.min(H-1,c.top+1);
for(let y=0;y<=top;y++)for(let lz=0;lz<CS;lz++)for(let lx=0;lx<CS;lx++){const id=c.b[(y*CS+lz)*CS+lx];if(!id)continue;const x=x0+lx,z=z0+lz,v=.9+.1*hs(x,y,z),tr=id==17||id==19,B=A[tr?1:0];
for(let fi=0;fi<6;fi++){const f=FD[fi],q=W.g(x+f[0],y+f[1],z+f[2]);if(tr?!(q==0||q==13||q==14||((q==17||q==19)&&q!=id)):!(q==0||q==13||q==14||q==17||q==19))continue;
const tc=tileOf(id,fi),u0=(tc%TC)/TC+.001,u1=(tc%TC+1)/TC-.001,v1=1-Math.floor(tc/TC)/TR-.001,v0=1-(Math.floor(tc/TC)+1)/TR+.001,uv=[u0,v0,u1,v0,u1,v1,u0,v1];
for(let k=3;k<7;k++){const o=f[k];B.P.push(lx+o[0],y+o[1],lz+o[2]);B.N.push(f[0],f[1],f[2]);B.C.push(v,v,v);B.U.push(uv[(k-3)*2],uv[(k-3)*2+1])}B.I.push(B.n,B.n+1,B.n+2,B.n,B.n+2,B.n+3);B.n+=4}}
A.forEach((B,i)=>{if(!B.n)return;const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(B.P),3));g.setAttribute('normal',new THREE.BufferAttribute(new Float32Array(B.N),3));
g.setAttribute('color',new THREE.BufferAttribute(new Float32Array(B.C),3));g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(B.U),2));g.setIndex(new THREE.BufferAttribute(new Uint32Array(B.I),1));
const m=new THREE.Mesh(g,i?matG:curMat());m.position.set(x0,0,z0);if(!i)m.castShadow=m.receiveShadow=true;scene.add(m);if(i)c.gm=m;else c.mesh=m})}
const ORD=[];for(let a=-10;a<=10;a++)for(let b=-10;b<=10;b++)ORD.push([a,b,a*a+b*b]);ORD.sort((p,q)=>p[2]-q[2]);
function stream(gn,mn){if(!W)return;const pcx=Math.floor(P.x/CS),pcz=Math.floor(P.z/CS),rd=RD[S.gfx];let g=0,m=0;
for(const[a,b,d2]of ORD){if(d2>(rd+1)*(rd+1))break;const cx=pcx+a,cz=pcz+b,c=W.get(cx,cz);if(!c){if(g<gn){genChunk(W,cx,cz);g++}continue}
if(d2<=rd*rd){if(c.dirty&&m<mn&&W.get(cx+1,cz)&&W.get(cx-1,cz)&&W.get(cx,cz+1)&&W.get(cx,cz-1)){meshChunk(c);m++}
if(c.vil&&!c.sp&&dim==0){c.sp=true;c.vil.forEach(([tt,x,y,z])=>sp(tt,x,gyf(x,z,H),z))}}}}
function cleanup(){const pcx=Math.floor(P.x/CS),pcz=Math.floor(P.z/CS),rd=RD[S.gfx]+2;W.ch.forEach(c=>{if(((c.cx-pcx)**2+(c.cz-pcz)**2>rd*rd)&&(c.mesh||c.gm)){rm(c);c.dirty=1}});
const lim=RD[S.gfx]*16+48;ents=ents.filter(e=>{if(e.t=='zc'&&Math.hypot(e.x-P.x,e.z-P.z)>lim){scene.remove(e.g);return false}return true})}
const PM=700,pg=new THREE.BufferGeometry(),ppos=new Float32Array(PM*3),pcol=new Float32Array(PM*3);pg.setAttribute('position',new THREE.BufferAttribute(ppos,3));pg.setAttribute('color',new THREE.BufferAttribute(pcol,3));pg.setDrawRange(0,0);
const pts=new THREE.Points(pg,new THREE.PointsMaterial({size:.22,vertexColors:true,depthWrite:false}));pts.frustumCulled=false;scene.add(pts);let PA=[];
function burst(x,y,z,n,col,spd=3,up=2,life=.8){const c=new THREE.Color(col);for(let i=0;i<n&&PA.length<PM;i++){const s=(Math.random()+.3)*spd,k=.7+Math.random()*.4;PA.push({x:x+(Math.random()-.5)*.6,y:y+(Math.random()-.5)*.6,z:z+(Math.random()-.5)*.6,vx:(Math.random()-.5)*s,vy:Math.random()*s*.8+up*.3,vz:(Math.random()-.5)*s,l:life*(.5+Math.random()*.7),r:c.r*k,g:c.g*k,b:c.b*k})}}
function upPart(dt){const ox=Math.floor(P.x),oy=Math.floor(P.y),oz=Math.floor(P.z);pts.position.set(ox,oy,oz);let k=0;PA=PA.filter(p=>{p.l-=dt;if(p.l<=0)return false;p.vy-=9*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;
ppos[k*3]=p.x-ox;ppos[k*3+1]=p.y-oy;ppos[k*3+2]=p.z-oz;pcol[k*3]=p.r;pcol[k*3+1]=p.g;pcol[k*3+2]=p.b;k++;return true});pg.setDrawRange(0,k);pg.attributes.position.needsUpdate=pg.attributes.color.needsUpdate=true}
const bx=(c,a,b,d,x,y,z)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(a,b,d),new THREE.MeshLambertMaterial({color:c}));m.position.set(x,y,z);return m};
const MK={vil:()=>[bx(0x6b4a2b,.6,1.2,.4,0,.6,0),bx(0xd9a77a,.45,.5,.45,0,1.45,0),bx(0xb88a5a,.12,.25,.12,0,1.4,.28)],
gol:()=>[bx(0xd0d0d0,1.2,1.4,.7,0,1.9,0),bx(0xc4c4c4,.5,.5,.5,0,2.85,0),bx(0xc0c0c0,.4,1.6,.4,-.9,1.7,0),bx(0xc0c0c0,.4,1.6,.4,.9,1.7,0),bx(0xb0b0b0,.45,1.1,.45,-.35,.55,0),bx(0xb0b0b0,.45,1.1,.45,.35,.55,0)],
zc:()=>[bx(0x3f9a3f,.6,1,.4,0,.9,0),bx(0x4aa84a,.5,.5,.5,0,1.65,0),bx(0x2f7a2f,.2,.7,.2,-.15,.35,0),bx(0x2f7a2f,.2,.7,.2,.15,.35,0),bx(0x111111,.3,.1,.02,0,1.65,.26)],
dra:()=>[bx(0x111111,1.6,1.2,5,0,0,0),bx(0x1a1a1a,1,1,1.4,0,.3,3),bx(0x1a1a1a,6,.15,1.8,-3.6,.3,0),bx(0x1a1a1a,6,.15,1.8,3.6,.3,0),bx(0xcc66ff,.2,.2,.2,-.3,.5,3.7),bx(0xcc66ff,.2,.2,.2,.3,.5,3.7)],
wit:()=>[bx(0x262626,.6,1.6,.5,0,.8,0),bx(0x222222,.8,.5,.5,0,1.9,0),bx(0x222222,.5,.5,.5,-.8,1.7,0),bx(0x222222,.5,.5,.5,.8,1.7,0),bx(0xdddddd,.9,.12,.5,0,1.3,0)]};
function sp(tp,x,y,z){const g=new THREE.Group();MK[tp]().forEach(m=>{m.castShadow=true;g.add(m)});g.position.set(x,y,z);scene.add(g);ents.push({t:tp,g,hp:{vil:20,gol:100,zc:20,dra:150,wit:100}[tp],x,y,z,a:0,cd:0,fuse:0})}
const gyf=(x,z,y)=>{for(let k=Math.min(H-1,Math.floor(y)+3);k>0;k--)if(solid(W.g(Math.floor(x),k,Math.floor(z))))return k+1;return 0};
function msg(m){const e=$('m');e.textContent=m;clearTimeout(msg.t);msg.t=setTimeout(()=>e.textContent='',4500)}
function hurt(n){if(S.mode!=0||n<=0)return;hp-=n;$('f').style.opacity=.5;setTimeout(()=>$('f').style.opacity=0,200);if(hp<=0){hp=20;hg=20;msg(t('mDie'));go(0)}}
function boom(x,y,z,r){for(let a=-r;a<=r;a++)for(let b=-r;b<=r;b++)for(let c=-r;c<=r;c++)if(a*a+b*b+c*c<=r*r){const X=Math.floor(x+a),Y=Math.floor(y+b),Z=Math.floor(z+c);if(W.g(X,Y,Z)!=15)W.s(X,Y,Z,0)}burst(x,y,z,50,0xffaa33,7,3,.9);burst(x,y,z,40,0x555555,5,4,1.2)}
function spawnZc(){const a=Math.random()*6.28,r=20+Math.random()*10,x=P.x+Math.cos(a)*r,z=P.z+Math.sin(a)*r;if(!W.get(Math.floor(x/CS),Math.floor(z/CS)))return;sp('zc',x,gyf(x,z,H),z)}
function upE(e,dt){const tp=e.t,dx=P.x-e.x,dz=P.z-e.z,dy=P.y-e.y,d=Math.hypot(dx,dz),mu=[0,.7,1.3][S.diff],gr=tp=='vil'||tp=='zc'||tp=='gol';
if(e.dead!=null){e.dead-=dt;e.g.rotation.z=Math.min(1.57,(.7-e.dead)*3);if(e.dead<=0){scene.remove(e.g);ents.splice(ents.indexOf(e),1);if(tp=='dra')msg(t('mDrag'));if(tp=='wit')msg(t('mWit'))}return}
if(d>RD[S.gfx]*16-8&&tp!='dra'&&tp!='wit')return;let vx=0,vz=0;e.cd-=dt;
const go2=(a,b,s)=>{const l=Math.hypot(a,b)||1;vx=a/l*s;vz=b/l*s;e.r=Math.atan2(a,b)};
if(tp=='vil'){e.a-=dt;if(e.a<0){e.a=2+Math.random()*3;e.wx=Math.random()-.5;e.wz=Math.random()-.5}if(e.wx!=null)go2(e.wx,e.wz,.8)}
else if(tp=='zc'){if(d<28)go2(dx,dz,2.6);if(d<2.3&&Math.abs(dy)<2){e.fuse+=dt;if(e.fuse>1.2){boom(e.x,e.y+1,e.z,2.8);if(d<5)hurt(10*mu);e.hp=0;e.noanim=1}}else e.fuse=0}
else if(tp=='gol'){let b=null,bd=22;for(const o of ents)if((o.t=='zc'||o.t=='wit')&&o.dead==null){const q=Math.hypot(o.x-e.x,o.z-e.z);if(q<bd){bd=q;b=o}}
if(b){go2(b.x-e.x,b.z-e.z,3);if(bd<2.4&&e.cd<0){b.hp-=15;b.hit=.35;burst(b.x,b.y+1,b.z,8,0xcc2222,3,2,.5);e.cd=.8}}else if(d>6)go2(dx,dz,2.5)}
else if(tp=='dra'){e.a+=dt*.45;if((performance.now()/1000)%14>9){go2(dx,dz,9);e.y+=(P.y+1-e.y)*dt*1.2;if(Math.hypot(dx,dz,dy)<3.5&&e.cd<0){hurt(6*mu);e.cd=1.2}}
else{e.x+=(32+18*Math.cos(e.a)-e.x)*dt*2;e.z+=(32+18*Math.sin(e.a)-e.z)*dt*2;e.y+=(34-e.y)*dt;e.r=-e.a}}
else if(tp=='wit'){go2(dx,dz,d>3?3:0);e.y+=(P.y+3.5-e.y)*dt;if(Math.hypot(dx,dz,dy-3.5)<4.5&&e.cd<0){hurt(5*mu);e.cd=1}}
const nx=e.x+vx*dt,nz=e.z+vz*dt;
if(gr){const ny=gyf(nx,nz,e.y);if(ny-e.y<1.6){e.x=nx;e.z=nz;e.y+=(ny-e.y)*Math.min(1,dt*10)}else e.a=0}else{e.x=nx;e.z=nz}
e.g.position.set(e.x,e.y,e.z);e.g.rotation.y=e.r||0;
const red=e.hit>0;if(red)e.hit-=dt;if(red||e.rd){e.rd=red;e.g.children.forEach(m=>m.material.emissive.setHex(red?0xff2020:0))}
if(e.hp<=0&&e.dead==null){e.dead=e.noanim?0:.7;e.g.children.forEach(m=>m.material.emissive.setHex(0xff2020));burst(e.x,e.y+1,e.z,tp=='dra'?120:26,0xdddddd,tp=='dra'?9:4,2,1)}}
const SP=[[18.5,19,33.5],[21.5,4,35.5],[32.5,20,38.5]];
function go(d){unmesh(W);dim=d;W=worlds[d];ents.forEach(e=>scene.remove(e.g));ents=[];W.ch.forEach(c=>c.sp=false);[P.x,P.y,P.z]=SP[d];P.vy=0;cdT=3;
const pcx=Math.floor(P.x/CS),pcz=Math.floor(P.z/CS);for(let a=-2;a<=2;a++)for(let b=-2;b<=2;b++)if(!W.get(pcx+a,pcz+b))genChunk(W,pcx+a,pcz+b);
for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++)meshChunk(W.get(pcx+a,pcz+b));setEnv();
if(S.diff>0){if(d==0)for(let i=0;i<3;i++)spawnZc();if(d==1)sp('wit',40,15,40);if(d==2)sp('dra',32,34,32)}}
function atk(){const fx=-Math.sin(P.yaw)*Math.cos(P.pit),fy=Math.sin(P.pit),fz=-Math.cos(P.yaw)*Math.cos(P.pit);let b=null,bd=99;
for(const e of ents){if(e.dead!=null)continue;const sz=e.t=='dra'?3:1,cx=e.x-P.x,cy=e.y+(e.t=='dra'?0:1)-P.y-1.62,cz=e.z-P.z,d=Math.hypot(cx,cy,cz);if(d<4.5+sz&&(cx*fx+cy*fy+cz*fz)/d>.85&&d<bd){b=e;bd=d}}
if(b){const dmg=[5,30,5,0][S.mode];if(dmg){b.hp-=dmg;b.hit=.35;burst(b.x,b.y+1,b.z,12,0xcc2222,3,2,.6)}if(b.t!='dra'){b.x+=fx*.8;b.z+=fz*.8}return true}return false}
function ray(){const dx=-Math.sin(P.yaw)*Math.cos(P.pit),dy=Math.sin(P.pit),dz=-Math.cos(P.yaw)*Math.cos(P.pit);let l=null;
for(let s=0;s<6;s+=.05){const x=Math.floor(P.x+dx*s),y=Math.floor(P.y+1.62+dy*s),z=Math.floor(P.z+dz*s),id=W.g(x,y,z);if(id&&id!=13&&id!=14)return{b:[x,y,z],pl:l,id};l=[x,y,z]}return null}
function ignite(){if(!W||!playing)return;const r=ray();if(!r||r.id!=12){msg(t('mAim'));return}const[x,y,z]=r.b;
for(const ax of[0,1])for(let i=0;i<4;i++)for(let j=0;j<5;j++){const ox=ax?x:x-i,oz=ax?z-i:z,oy=y-j;let ok=true;
for(let a=0;a<4&&ok;a++)for(let b=0;b<5;b++){const e=a%3==0||b%4==0,id=W.g(ax?ox:ox+a,oy+b,ax?oz+a:oz);if(e?id!=12:id!=0){ok=false;break}}
if(ok){for(let a=1;a<3;a++)for(let b=1;b<4;b++)W.s(ax?ox:ox+a,oy+b,ax?oz+a:oz,13);msg(t('mIgn'));return}}msg(t('mFrame'))}
function door(x,y,z){const id=W.g(x,y,z),n=id==18?19:18,u=W.g(x,y+1,z),d=W.g(x,y-1,z);W.s(x,y,z,n);if(u==18||u==19)W.s(x,y+1,z,n);else if(d==18||d==19)W.s(x,y-1,z,n)}
function click(btn){if(!playing||paused||S.mode==3)return;
if(btn==0){if(atk()||S.mode==2)return;const r=ray();if(r&&r.id!=15){const[x,y,z]=r.b,id=r.id;W.s(x,y,z,0);burst(x+.5,y+.5,z+.5,14,HEX[id]);
if(id==18||id==19){const u=W.g(x,y+1,z),d=W.g(x,y-1,z);if(u==18||u==19)W.s(x,y+1,z,0);else if(d==18||d==19)W.s(x,y-1,z,0)}
if(S.mode==0){const g=id==19?18:id;inv[g]=(inv[g]||0)+1;if(id==6&&Math.random()<.25)inv[20]=(inv[20]||0)+1}hud()}}
else{const r=ray();if(!r)return;if(r.id==16){openCraft();return}if(r.id==18||r.id==19){door(...r.b);return}
if(S.mode>1||!r.pl)return;const id=HOT[sel];if(S.mode==0&&!inv[id])return;const[x,y,z]=r.pl,px=Math.floor(P.x),pz=Math.floor(P.z),py=Math.floor(P.y);
if(px==x&&pz==z&&(y==py||y==py+1||(id==18&&y+1==py+1)))return;if(id==18){if(W.g(x,y+1,z))return;W.s(x,y+1,z,18)}W.s(x,y,z,id);if(S.mode==0)inv[id]--;hud()}}
const hit=(x,y,z)=>{if(S.mode==3)return false;for(const a of[-.3,.3])for(const c of[-.3,.3])for(const k of[0,.9,1.79])if(solid(W.g(Math.floor(x+a),Math.floor(y+k),Math.floor(z+c))))return true;return false};
function upP(dt){const fl=S.mode==3||(S.mode==1&&P.fly),mx=(K.KeyD?1:0)-(K.KeyA?1:0)+J.x,mz=(K.KeyS?1:0)-(K.KeyW?1:0)+J.y,sp2=fl?(K.ControlLeft?14:9):(K.ControlLeft?6.5:4.5),l=Math.max(1,Math.hypot(mx,mz));
const vx=(mx*Math.cos(P.yaw)+mz*Math.sin(P.yaw))/l*sp2*dt,vz=(-mx*Math.sin(P.yaw)+mz*Math.cos(P.yaw))/l*sp2*dt;
if(fl)P.vy=((K.Space?1:0)-(K.ShiftLeft?1:0))*sp2*.8;else{P.vy-=26*dt;if(K.Space&&P.on)P.vy=8.6}
if(!hit(P.x+vx,P.y,P.z))P.x+=vx;if(!hit(P.x,P.y,P.z+vz))P.z+=vz;P.on=false;const ny=P.y+P.vy*dt;if(!hit(P.x,ny,P.z))P.y=ny;else{if(P.vy<0)P.on=true;P.vy=0}
if(S.mode==0){if(S.diff==0){hg=20;hp=Math.min(20,hp+dt*.8)}else{hg=Math.max(0,hg-dt*(.04+(K.ControlLeft&&(mx||mz)?.04:0)));if(hg<=0){stT+=dt;if(stT>4){stT=0;hurt(1)}}else if(hg>=18&&hp<20)hp=Math.min(20,hp+dt*.6)}}
if(P.y<-15){hurt(99);if(S.mode!=0)go(0)}cdT-=dt;const id=W.g(Math.floor(P.x),Math.floor(P.y+.2),Math.floor(P.z));
if(cdT<=0&&(id==13||id==14)){const d=id==13?(dim==1?0:1):(dim==2?0:2);msg(t('dims')[d]);go(d)}}
function eat(){if(S.mode!=0||!(inv[20]>0)||hg>=20)return;inv[20]--;hg=Math.min(20,hg+4);burst(P.x,P.y+1.2,P.z,10,0xcc3322,2,2,.5);hud()}
function hud(){const sv=S.mode==0;$('hp').textContent=sv?'♥'.repeat(Math.max(0,Math.ceil(hp/2))):'';$('hg').textContent=sv?'🍗'.repeat(Math.ceil(hg/2))+' 🍎'+(inv[20]||0):'';
$('hb').innerHTML=HOT.map((id,i)=>`<div class="${i==sel?'s':''}"><b style="background:#${HEX[id].toString(16).padStart(6,'0')}"></b><span>${sv?(inv[id]||0):S.mode==1?'∞':''}</span></div>`).join('')}
function upBoss(){const b=ents.find(e=>e.t=='dra'||e.t=='wit');$('bs').style.display=b?'block':'none';if(b)$('bs').firstChild.style.width=Math.max(0,b.hp/(b.t=='dra'?150:100)*100)+'%'}
const R=[[[[5,1]],[7,4]],[[[7,4]],[16,1]],[[[7,3]],[18,1]],[[[4,4]],[17,4]],[[[6,4]],[20,1]],[[[3,8]],[12,1]]],nm=id=>T['n'+id][L];
function craftUI(){const rl=$('rl');rl.innerHTML='';R.forEach(r=>{const b=document.createElement('button'),ok=S.mode==1||r[0].every(([id,n])=>(inv[id]||0)>=n);b.className=ok?'':'dis';
b.textContent=r[0].map(([id,n])=>n+'× '+nm(id)).join(' + ')+' → '+r[1][1]+'× '+nm(r[1][0]);b.onclick=()=>{if(!ok)return;if(S.mode!=1)r[0].forEach(([id,n])=>inv[id]-=n);inv[r[1][0]]=(inv[r[1][0]]||0)+r[1][1];hud();craftUI()};rl.appendChild(b)})}
function openCraft(){craftOpen=true;paused=true;craftUI();$('craft').style.display='flex';if(document.pointerLockElement)document.exitPointerLock()}
function closeCraft(){craftOpen=false;paused=false;$('craft').style.display='none';if(!TOUCH)try{$('c').requestPointerLock()}catch(e){}}
let last=performance.now();
function loop(tm){requestAnimationFrame(loop);const dt=Math.min((tm-last)/1000,.05);last=tm;
if(W){if(active()){upP(dt);ents.slice().forEach(e=>upE(e,dt));spT+=dt;if(spT>25){spT=0;if(dim==0&&S.diff>0&&ents.filter(e=>e.t=='zc').length<6)spawnZc()}
if(++fr%6==0){upBoss();hud();$('inf').textContent=`${WN} · ${t('dims')[dim]} · ${t('modes')[S.mode]} · ${GFX[S.gfx]} · ${Math.floor(P.x)},${Math.floor(P.y)},${Math.floor(P.z)}`}}
else if(!playing){orbit+=dt*.12;ents.slice().forEach(e=>e.t=='vil'&&upE(e,dt))}
stream(active()?1:2,2);if((clT+=dt)>2){clT=0;cleanup()}upPart(dt)}
if(playing||!W){cam.position.set(P.x,P.y+1.62,P.z);cam.rotation.set(P.pit,P.yaw,0,'YXZ')}else{cam.position.set(P.x,P.y+9,P.z);cam.rotation.set(-.3,orbit,0,'YXZ')}
sky.position.copy(cam.position);sun.position.set(cam.position.x+50,cam.position.y+80,cam.position.z+30);sun.target.position.copy(cam.position);ren.render(scene,cam)}
const GFX=['Low','Medium','High','Ultra'],SC=['title','create','load','pause'];
const active=()=>playing&&!paused&&(TOUCH||document.pointerLockElement);
function spDown(){const n=performance.now();if(n-lastSp<300&&S.mode==1)P.fly=!P.fly;lastSp=n}
function fs(){try{document.documentElement.requestFullscreen().then(()=>screen.orientation.lock('landscape')).catch(()=>{})}catch(e){}}
function setTouch(){TOUCH=CTL==1||(CTL==0&&('ontouchstart' in window||navigator.maxTouchPoints>0));document.body.classList.toggle('touch',TOUCH);Q('.ctlB').forEach(b=>b.textContent=t('ctl')+': '+t('cv')[CTL])}
Q('.ctlB').forEach(b=>b.onclick=()=>{CTL=(CTL+1)%3;setTouch()});
{const joy=$('joy'),kn=$('knob');let jid=null,jo=null;const RR=45;
const mvj=q=>{let dx=q.clientX-jo.x,dy=q.clientY-jo.y;const l=Math.hypot(dx,dy);if(l>RR){dx*=RR/l;dy*=RR/l}kn.style.transform=`translate(${dx}px,${dy}px)`;J.x=dx/RR;J.y=dy/RR;K.ControlLeft=l>RR*1.3};
joy.addEventListener('touchstart',e=>{e.preventDefault();const q=e.changedTouches[0],r=joy.getBoundingClientRect();jid=q.identifier;jo={x:r.left+r.width/2,y:r.top+r.height/2};mvj(q)},{passive:false});
joy.addEventListener('touchmove',e=>{e.preventDefault();for(const q of e.changedTouches)if(q.identifier==jid)mvj(q)},{passive:false});
const en=e=>{for(const q of e.changedTouches)if(q.identifier==jid){jid=null;J.x=J.y=0;K.ControlLeft=false;kn.style.transform=''}};joy.addEventListener('touchend',en);joy.addEventListener('touchcancel',en);
let lid=null,lx=0,ly=0;
document.addEventListener('touchstart',e=>{if(!TOUCH||!active())return;for(const q of e.changedTouches)if(lid==null&&q.clientX>innerWidth*.35&&!q.target.closest('#tb,#joy,#bMenu,#hb')){lid=q.identifier;lx=q.clientX;ly=q.clientY}},{passive:true});
document.addEventListener('touchmove',e=>{for(const q of e.changedTouches)if(q.identifier==lid){P.yaw-=(q.clientX-lx)*.006;P.pit=Math.max(-1.55,Math.min(1.55,P.pit-(q.clientY-ly)*.006));lx=q.clientX;ly=q.clientY}if(!e.target.closest('#craft,#menu'))e.preventDefault()},{passive:false});
const el=e=>{for(const q of e.changedTouches)if(q.identifier==lid)lid=null};document.addEventListener('touchend',el);document.addEventListener('touchcancel',el);
let rep=null;const hold=(id,on,off,loop)=>{const b=$(id);b.addEventListener('touchstart',e=>{e.preventDefault();on();if(loop){clearInterval(rep);rep=setInterval(on,250)}},{passive:false});const f=e=>{e.preventDefault();clearInterval(rep);off&&off()};b.addEventListener('touchend',f);b.addEventListener('touchcancel',f)};
hold('bBreak',()=>click(0),null,true);hold('bPlace',()=>click(2),null,true);hold('bJump',()=>{K.Space=true;spDown()},()=>K.Space=false);hold('bDown',()=>K.ShiftLeft=true,()=>K.ShiftLeft=false);hold('bFire',()=>ignite(),null);hold('bEat',()=>eat(),null);
$('bMenu').addEventListener('touchstart',e=>{e.preventDefault();pauseGame()});
$('hb').addEventListener('touchstart',e=>{const d=e.target.closest('#hb>div');if(d){sel=[...$('hb').children].indexOf(d);hud()}});}
function showScr(n){$('menu').style.display=n?'flex':'none';SC.forEach(s=>$(s).style.display=s==n?'block':'none');document.body.classList.toggle('ingame',!n&&playing)}
function lbl(){Q('.modeB').forEach(b=>b.textContent=t('mode')+': '+t('modes')[S.mode]);Q('.gfxB').forEach(b=>b.textContent=t('gfx')+': '+GFX[S.gfx]+(S.gfx==3?' (Shaders)':''));Q('.diffB').forEach(b=>b.textContent=t('diff')+': '+t('diffs')[S.diff]);Q('.langB').forEach(b=>b.textContent=t('lang')+': '+LN[L])}
function setLang(l){L=l;try{localStorage.setItem('tc_lang',L)}catch(e){}document.documentElement.lang=['es','en','pt','fr'][L];Q('[data-t]').forEach(e=>e.innerHTML=t(e.dataset.t));lbl();setTouch()}
Q('.langB').forEach(b=>b.onclick=()=>setLang((L+1)%4));
Q('.modeB').forEach(b=>b.onclick=()=>{S.mode=(S.mode+1)%4;lbl()});Q('.gfxB').forEach(b=>b.onclick=()=>{S.gfx=(S.gfx+1)%4;lbl();applyGfx()});Q('.diffB').forEach(b=>b.onclick=()=>{S.diff=(S.diff+1)%3;lbl()});
function pauseGame(){if(!playing||paused)return;paused=true;showScr('pause');if(document.pointerLockElement)document.exitPointerLock()}
function resumeGame(){paused=false;showScr(null);if(TOUCH)fs();else try{$('c').requestPointerLock()}catch(e){}}
function hashSeed(s){s=s.trim();if(!s)return Math.floor(Math.random()*99999);if(/^-?\d+$/.test(s))return Math.abs(+s)%99999;let h=7;for(const c of s)h=(h*31+c.charCodeAt(0))%99991;return h}
const nap=()=>new Promise(r=>setTimeout(r,60));
async function createWorld(){WN=$('wname').value.trim()||'Mi mundo';seed=hashSeed($('wseed').value);playing=false;paused=false;worlds.forEach(unmesh);worlds=[new Wd(0),new Wd(1),new Wd(2)];W=worlds[0];ents.forEach(e=>scene.remove(e.g));ents=[];PA=[];
if(TOUCH)fs();else try{$('c').requestPointerLock()}catch(e){}showScr('load');const ld=t('ld'),st=async(p,m)=>{$('lbar').style.width=p+'%';$('ltx').textContent=m;await nap()};
await st(5,ld[0]+' "'+WN+'" · seed '+seed);const pcx=Math.floor(SP[0][0]/CS),pcz=Math.floor(SP[0][2]/CS),n=[];for(let a=-3;a<=3;a++)for(let b=-3;b<=3;b++)n.push([a,b]);
await st(10,ld[1]);let i=0;for(const[a,b]of n){genChunk(W,pcx+a,pcz+b);if(++i%7==0)await st(10+65*i/n.length,ld[1])}
await st(80,ld[2]);applyGfx();inv={};HOT.forEach(q=>inv[q]=q>15?0:20);inv[20]=0;hp=20;hg=20;P.fly=false;P.yaw=0;P.pit=0;sel=0;go(0);await st(100,ld[3]);
playing=true;$('hud').style.display='block';showScr(null);hud();msg(t('mWel'))}
$('bPlayT').onclick=()=>showScr('create');$('bBack').onclick=()=>showScr('title');$('bCreate').onclick=createWorld;$('play').onclick=resumeGame;$('bCraftX').onclick=closeCraft;
$('bExit').onclick=()=>{playing=false;paused=false;$('hud').style.display='none';if(document.pointerLockElement)document.exitPointerLock();showScr('title')};
document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement&&playing&&!TOUCH&&!paused)pauseGame()});
$('c').addEventListener('click',()=>{if(playing&&!paused&&!TOUCH&&!document.pointerLockElement)try{$('c').requestPointerLock()}catch(e){}});
document.addEventListener('mousemove',e=>{if(document.pointerLockElement){P.yaw-=e.movementX*.0024;P.pit=Math.max(-1.55,Math.min(1.55,P.pit-e.movementY*.0024))}});
document.addEventListener('mousedown',e=>{if(document.pointerLockElement)click(e.button)});document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('wheel',e=>{if(!active())return;sel=(sel+(e.deltaY>0?1:HOT.length-1))%HOT.length;hud()});
addEventListener('keydown',e=>{K[e.code]=true;if(e.code=='Space')spDown();if(e.code=='KeyF'&&active())ignite();if(e.code=='KeyE'&&active())eat();if(e.code=='Escape'&&craftOpen)closeCraft();
const m=/^Digit([0-9])$/.exec(e.code);if(m)sel=m[1]==0?9:m[1]-1;if(e.code=='Minus')sel=10;if(e.code=='Equal')sel=11;if(playing)hud()});addEventListener('keyup',e=>K[e.code]=false);
addEventListener('resize',applyGfx);
setLang(L);applyGfx();seed=Math.floor(Math.random()*99999);worlds=[new Wd(0),new Wd(1),new Wd(2)];W=worlds[0];{const d=S.diff;S.diff=0;go(0);S.diff=d}showScr('title');requestAnimationFrame(loop);
