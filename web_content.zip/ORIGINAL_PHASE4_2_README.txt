DayFlow Mobile + 4-digit PIN local prototype

No OTP and no email. Users can create a local profile with a mobile number and 4-digit PIN, then log in and use routines, insights and health tracking.

LIMITATIONS:
- Accounts and data are stored only in this app/browser installation on this device.
- Account creation is open on-device; admin-created cloud accounts are not implemented yet.
- PIN is locally salted and hashed with Web Crypto SHA-256. This is a convenience lock, not production-grade authentication.
- Five wrong attempts trigger a five-minute local lockout; clearing app data can bypass it.
- No Firebase cloud sync, registered-device recovery, admin backend, or native Android alarms are included.
- Reinstalling or clearing app data may erase accounts and routines.

Upload as a zipped site in APKForge and preview before creating the app.

PHASE 3 ADDITIONS
- Change 4-digit PIN from Profile.
- Export account data to a JSON backup file.
- Restore a previously exported DayFlow JSON backup.
- Backup files contain personal data; keep them private.
- Backup import replaces the currently signed-in local account data after confirmation.
\nPHASE 3.1 FIX: Fixed navigation initialization (backup file input is created inside Profile) and ensured saves remain scoped to the signed-in local account.\n
PHASE 4.1 REMINDER FIX
- Profile now includes Enable reminders & sound and Test alarm sound.
- Tap Enable reminders & sound once to request notification permission and unlock audio.
- Test alarm opens an in-app alarm popup and plays a repeating tone.
- Scheduled task reminders are checked every 10 seconds while the app is open and visible.
- Exact alarms/notifications while app is closed, force-stopped, or Android kills the WebView are not supported by this HTML-only build.

PHASE 4.2 — REMINDER PREFERENCES
- Profile > Reminder preferences allows Sound + vibration, Vibration only, Sound only, Silent.
- Select one in-app tone: Gentle Bell, Soft Chime, Classic Alarm, Digital Beep.
- Save reminder preferences to apply them; Test alarm sound uses the selected mode/tone.
- Browser/WebView notification channel sound is controlled by Android/host and may not follow the in-app tone setting. The custom tone controls the in-app alarm popup while DayFlow is active.
- Vibration depends on WebView/browser vibration API support.
