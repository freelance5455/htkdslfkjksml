ISRAFill WIRE PRO — ANDROID PROJECT

यह Android Studio के लिए starter project है। इसमें Wiring/Plumbing booking, customer details, work description/photo preview, materials, expense estimates, profile, settings और device पर local save शामिल हैं।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में Open चुनें और इस ZIP को extract करके IsrafillWirePro फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें। जरूरत पड़ने पर Android SDK 35 डाउनलोड करने को कहे तो SDK Manager से install करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. सफल होने पर Android Studio में Locate पर क्लिक करें। आम तौर पर APK app/build/outputs/apk/debug/app-debug.apk में होगा।

ज़रूरी सीमाएँ:
- इस ZIP में तैयार APK नहीं है; यह source project है जिसे Android Studio से build करना होगा।
- बुकिंग अभी केवल इसी डिवाइस पर सेव होती है। WhatsApp/email पर अपने-आप भेजना, online/cloud sync, और Play Store publishing अभी configure नहीं हैं।
- फ़ोटो preview मौजूद है; फ़ोटो को booking में स्थायी रूप से सहेजने की सुविधा अभी पूरी तरह implement नहीं है।
- Google Play पर प्रकाशित करने के लिए अलग Play Console account, signing और Google Play की वर्तमान शर्तें लागू होंगी।
