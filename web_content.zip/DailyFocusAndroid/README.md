# My Daily Focus — Android Studio project

This is a lightweight Android WebView wrapper for the Daily Focus habit tracker. Habit and daily-record data use WebView `localStorage` on the device.

## Build an APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Extract this folder.
3. In Android Studio choose **Open** and select this folder (`DailyFocusAndroid`).
4. Let Gradle sync and install any prompted SDK components.
5. For a test APK choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Note
The execution environment used to prepare this project did not have Android SDK/Gradle installed, so a compiled APK could not be produced here. The bundled `index.html` is a self-contained mobile-friendly implementation of your tracker based on the supplied design. It uses browser storage; clearing the app's data can erase saved habits and records.
