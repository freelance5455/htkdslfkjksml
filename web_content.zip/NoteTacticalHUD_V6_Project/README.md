# Note Tactical HUD V6

Versi ini memperbaiki masalah Import TXT pada APK dengan menambahkan **native Android WebView file chooser**.

## Kenapa V5 bisa tidak bereaksi?
HTML hanya dapat meminta `<input type="file">`. Pada WebView Android, permintaan tersebut harus diteruskan oleh `WebChromeClient.onShowFileChooser()`. Jika APK builder tidak mengimplementasikan callback ini, tombol terlihat bisa diklik tetapi tidak membuka file picker.

## Solusi V6
`MainActivity.kt` mengimplementasikan `onShowFileChooser()` dan membuka Android Storage Access Framework (`ACTION_OPEN_DOCUMENT`) dengan tipe `text/plain`. URI hasilnya dikembalikan ke HTML, sehingga `FileReader` di aplikasi dapat membaca TXT seperti di browser.

## Build
Buka folder ini di Android Studio, tunggu Gradle sync, lalu Build > Build APK(s).

Jika Anda memakai APK builder/website tertentu dan bukan Android Studio, builder tersebut harus menyediakan WebChromeClient file chooser. HTML saja tidak dapat memaksa WebView yang tidak menyediakan callback tersebut.
