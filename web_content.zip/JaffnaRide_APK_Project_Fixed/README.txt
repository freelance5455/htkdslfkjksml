JaffnaRide APK Project V2 - fixed local asset loading.

Important: This build loads the bundled HTML using file:///android_asset/index.html, avoiding appassets.androidplatform.net/web/index.html path errors.
Location permissions: FINE + COARSE are declared and requested at runtime.
Rebuild and reinstall the APK after replacing the old APK.
