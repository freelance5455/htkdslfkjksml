# Loop Creator Studio update

This update replaces the upload-only sheet with an in-app creator studio UI.

Included in source:
- In-app camera preview using WebRTC `getUserMedia`, front/back camera switching, and microphone capture where supported by Android WebView/device.
- Start/stop recording with `MediaRecorder`, recording timer, optional 3/10-second countdown, playback preview, retake, and use-video flow.
- Gallery video selection remains available.
- Sound-file selection and preview; selected local audio is mixed into the recording where the browser's media APIs support it.
- Preview filters (Original, Vivid, Warm, Mono, Moody); the recording pipeline uses a filtered canvas when canvas capture is supported.
- Android camera and microphone manifest permissions and WebView permission handling.

Limitations to be aware of:
- This source ZIP has not been built into an APK in this environment because Gradle/Android SDK are not available here.
- Actual camera/microphone support depends on Android System WebView, Android runtime permissions, and device implementation. If `getUserMedia`, `MediaRecorder`, canvas capture, or audio mixing is unsupported, use the gallery option.
- The available filter/audio encoding and output container depend on the device. This is a native-feeling creator interface, not a claim of full TikTok parity.
- Posting is still local/session-only until Firebase or another backend/storage service is configured.
