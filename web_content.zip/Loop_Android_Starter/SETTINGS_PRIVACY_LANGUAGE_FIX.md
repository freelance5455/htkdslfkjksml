# Settings / Privacy / Language update

- Improved settings control persistence and synchronization between duplicate controls.
- Added an explicit “All languages / सभी भाषाएँ” content preference and expanded language dropdown population.
- Connected local accessibility preferences (larger text, reduced motion, contrast, dark appearance) to UI behavior.
- Kept the existing main feed layout and settings sheet layout.

Important: this HTML/WebView prototype stores most settings locally. Private-account visibility, messaging permissions, recommendation personalization, and moderation cannot be enforced for other users without backend/server rules. Language selection currently translates the supported labels (English, Hindi, Urdu, Arabic, Spanish, French, Bengali); other listed languages may still show much of the interface in English. Android device testing has not been performed.
