# Firebase Auth domain fix — Loop Original Promote v19

## What this source revision changes
- The app now shows the exact Android WebView hostname when Firebase returns `auth/unauthorized-domain`: `appassets.androidplatform.net`.
- The Firebase Web SDK configuration remains attached to project `loop-short`; no project IDs or app features were replaced.

## Required action in Firebase Console (not possible from a ZIP file)
A source ZIP cannot change the live Firebase project's Authorized domains. The project owner must do this in the Firebase Console:

1. Open project `loop-short`.
2. Go to **Authentication → Settings → Authorized domains**.
3. Click **Add domain** and enter exactly `appassets.androidplatform.net` (hostname only; no `https://` and no path).
4. Save, close and reopen Loop, then try Email/Password sign-up again.
5. If it still fails, verify the web app config in `app/src/main/assets/index.html` belongs to project `loop-short`, and check the exact error code.

The screenshot shows the app loaded at `https://appassets.androidplatform.net/assets/index.html`, so this is the hostname to check. Android documents this as the default domain used by `WebViewAssetLoader`. See https://developer.android.com/develop/ui/views/layout/webapps/load-local-content and https://firebase.google.com/docs/auth/faq-and-troubleshooting.

## Important limitations
- I cannot sign in to your Firebase Console or alter its live project settings from this ZIP. The domain is **not added to the cloud project by this file alone**.
- This source change improves the error message and documents the exact Console change; it does not prove authentication works. Rebuild/install the APK and test sign-up/login after adding the domain.
- Google/Facebook OAuth may require provider-specific redirect configuration and may behave differently in an embedded WebView.
