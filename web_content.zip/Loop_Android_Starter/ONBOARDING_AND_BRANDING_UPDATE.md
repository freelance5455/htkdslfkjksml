# Loop onboarding and branding update

- Added a native Loop launcher icon and changed the app label to Loop.
- The HTML startup splash now uses a Loop-specific interlocking mark and wordmark every app launch.
- First-run language selection and onboarding are persisted through Android SharedPreferences as well as browser storage, so completed onboarding is not shown again on later launches.
- Language selection remains available manually in Settings.

Validation in this delivery: inspected modified XML/HTML/Kotlin and JavaScript syntax. Android Gradle build and on-device visual verification have not been run in this environment.
