# Loop Cloud Feature Pass — 2026-10-13

## Code changes in this pass
- Cloud video Like action now routes to the Firestore per-user likes collection instead of always toggling a local-only state.
- Cloud video cards now expose Follow, using the existing per-user `users/{uid}/following/{targetUid}` collection.
- Following feed tab now filters loaded cloud video cards by the signed-in user's followed creator UIDs.
- Search now searches loaded local video cards when signed out, and queries recent published Firestore video documents for title/caption/hashtags/creator when signed in. Results navigate to matching feed cards.
- Successful sign-in now attempts to create/update the user's Firestore profile document.
- Profile edit status now distinguishes cloud sync from local-only profile edits.

## Important limitations (not claimed complete)
- This pass does not create backend infrastructure or enable Firebase services in the Firebase Console.
- Real operation requires the configured Firebase project, enabled Email/Password Authentication, a Firestore database, deployed security rules, and Storage rules.
- Following feed filters the currently loaded cloud feed; pagination and a dedicated scalable server query are not implemented.
- Search scans up to 100 newest published video documents client-side; it is not a scalable full-text search engine and does not search every user profile.
- No real chat, push notifications, LIVE, payments/coins, creator payouts, full editor, moderation console, or account deletion workflow was added in this pass.
- No successful Android/Gradle build or real-device test is asserted.

## Static validation
- Inline JavaScript extracted and passed `node --check` on 2026-10-13.
