# Loop Android Starter — Firebase-configured prototype

This is an Android Studio starter project wrapping the existing Loop HTML prototype in a WebView. The supplied `google-services.json` is placed in `app/` and matches application ID `com.loop.shortvideo`. Firebase Auth, Firestore and Storage client dependencies are declared.

## What is included
- Android/Kotlin WebView wrapper and HTML prototype
- Android video file chooser
- Firebase Android configuration and SDK dependencies
- Starter Firestore and Storage security rules (`firestore.rules`, `storage.rules`)
- Play Store blockers checklist and privacy-policy draft

## Important status
**Not Play Store release-ready.** The Gradle project has not been successfully built or run in this environment. The HTML's sign-in and publishing flows still use prototype/browser logic unless separately integrated with Firebase; adding SDK dependencies and `google-services.json` does not wire those flows automatically. Server-backed feed, comments, likes, follows, chat, push notifications, reporting/moderation, account deletion, billing, payouts and LIVE are not complete.

## Next steps
1. Open this folder in a current Android Studio and install the Android SDK required by `app/build.gradle.kts`.
2. In Firebase Console for project `loop-short`, enable Authentication > Email/Password, create a Firestore database and enable Storage.
3. Review `firestore.rules` and `storage.rules` before deploying. These are starter rules, not a complete production security review. Deploy them in the Firebase Console or with Firebase CLI after confirming paths and intended access.
4. Integrate the HTML login and publish actions with Firebase APIs, then add server-backed likes/comments/follows, reporting/blocking, account deletion and moderation.
5. Replace the privacy template with an accurate hosted policy and complete Google Play Data safety, content rating, account deletion, target SDK, app assets and testing requirements.
6. Build and test on real devices; fix all errors and generate a signed Android App Bundle (.aab) only after production readiness work is complete.

Do not place service-account credentials or server secrets in the app. The Firebase client configuration file is not a server credential, but access must be controlled with Authentication and security rules.


## Firebase configuration added in this revision
- `app/google-services.json` belongs to Firebase project `loop-short` and package `com.loop.shortvideo`.
- The web UI now uses the matching Firebase web config and Firebase compat Auth, Firestore, and Storage SDKs.
- Video publishing now requires a signed-in Firebase user, uploads the selected clip to `videos/<uid>/...`, and writes metadata to Firestore `videos`.

## Required Firebase Console actions before testing
1. Firebase Console → Authentication → Sign-in method → enable Email/Password.
2. Create the Firestore database.
3. Create the Storage bucket if it is not already active.
4. Publish `firestore.rules` and `storage.rules` from this folder in their respective Firebase consoles.
5. Confirm the Firebase project's authorized domains / WebView sign-in behavior. OAuth sign-in may not work from a `file://` WebView; use email/password for initial testing.
6. Test with a non-sensitive short clip. The Storage rule caps videos at 100 MB.

## Important limitations
This is still a starter/MVP, not a Play Store release candidate. The uploaded clip is stored in Firebase and its metadata is written to Firestore, but there is not yet a public feed query to load all users' videos, nor production-grade likes/comments/follows, account deletion flow, reporting dashboard, moderation pipeline, payments, creator payouts, messaging, or live streaming. The WebView loads Firebase SDKs from the internet. Build and test with Android Studio/Gradle, fix any SDK/target API issues, complete Play Console Data safety and privacy requirements, then create and verify a signed AAB. Do not claim the app is Play-ready until these checks pass.


## Latest code update (October 2026)
- Added a Firestore-backed cloud feed loader for published video documents.
- Added Firestore-backed like records under `videos/{videoId}/likes/{uid}` for cloud videos.
- Added Firestore-backed comments for cloud videos and a user-owned `users/{uid}/following/{targetUid}` path.
- The feed only loads for signed-in users and requires the provided Firestore and Storage rules to be deployed in Firebase Console.

## Important limitations (not Play Store ready)
This is still a starter/MVP, not a release-ready social video service. No successful Android Gradle build or device test has been performed in this environment. Firebase email/password sign-in must be enabled; the JavaScript config should be replaced with the Firebase **Web app** config from a registered Web app in the same project if the JS SDK rejects the Android app ID. Public video discovery requires Firestore and Storage rules to be deployed and tested. This package does not implement real chat, live streaming, payments/coin purchases, payouts, moderation operations, account deletion UI + public deletion web page, privacy-policy hosting, or Play Console release artifacts. Test security rules and abusive-content handling before production.


## Sign-in status (important)
A visible “Sign in / Sign up” button is available on the home feed; Profile, Friends, and Inbox also open the login sheet. Email/password and Google flows are wired to Firebase Auth code, but real authentication is NOT yet enabled in this package because the Firebase Web App `appId` is missing. Open Firebase Console → project `loop-short` → Project settings → Your apps → Web app (`</>`) and copy its `appId` into `app/src/main/assets/index.html` in `firebaseConfig`. The native Android `google-services.json` does not contain this Web App ID. APK has not been built or tested here.


## Cloudinary video upload update
- Video publishing now uploads to Cloudinary using cloud name `qesbwma2` and unsigned upload preset `loop_videos`.
- The client-side preset name is public by design; restrict allowed formats/size in Cloudinary and monitor usage.
- Firestore metadata writing still requires Firestore to be enabled and rules deployed. No Android APK was built or tested in this environment.
