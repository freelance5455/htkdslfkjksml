# Loop Android Starter — Firebase-configured prototype

This is an Android Studio starter project wrapping the existing Loop HTML prototype in a WebView. The supplied `google-services.json` is placed in `app/` and matches application ID `com.loop.shortvideo`. Firebase Auth, Firestore and Storage client dependencies are declared.

## What is included
- Android/Kotlin WebView wrapper and HTML prototype
- Android video file chooser
- Firebase Android configuration and SDK dependencies
- Starter Firestore and Storage security rules (`firestore.rules`, `storage.rules`)
- Play Store blockers checklist and privacy-policy draft

## Important status
**Not Play Store release-ready.** The Gradle project has not been successfully built or run in this environment. The HTML's sign-in and publishing flows still use prototype/browser logic unless separately integrated with Firebase; adding SDK dependencies and `google-services.json` does not wire those flows automatically. Server-backed feed, comments, likes, follows, chat, push notifications, reporting/moderation, account deletion, billing, payouts and LIVE are not complete.

## Next steps
1. Open this folder in a current Android Studio and install the Android SDK required by `app/build.gradle.kts`.
2. In Firebase Console for project `loop-short`, enable Authentication > Email/Password, create a Firestore database and enable Storage.
3. Review `firestore.rules` and `storage.rules` before deploying. These are starter rules, not a complete production security review. Deploy them in the Firebase Console or with Firebase CLI after confirming paths and intended access.
4. Integrate the HTML login and publish actions with Firebase APIs, then add server-backed likes/comments/follows, reporting/blocking, account deletion and moderation.
5. Replace the privacy template with an accurate hosted policy and complete Google Play Data safety, content rating, account deletion, target SDK, app assets and testing requirements.
6. Build and test on real devices; fix all errors and generate a signed Android App Bundle (.aab) only after production readiness work is complete.

Do not place service-account credentials or server secrets in the app. The Firebase client configuration file is not a server credential, but access must be controlled with Authentication and security rules.


## Firebase configuration added in this revision
- `app/google-services.json` belongs to Firebase project `loop-short` and package `com.loop.shortvideo`.
- The web UI now uses the matching Firebase web config and Firebase compat Auth, Firestore, and Storage SDKs.
- Video publishing now requires a signed-in Firebase user, uploads the selected clip to `videos/<uid>/...`, and writes metadata to Firestore `videos`.

## Required Firebase Console actions before testing
1. Firebase Console → Authentication → Sign-in method → enable Email/Password.
2. Create the Firestore database.
3. Create the Storage bucket if it is not already active.
4. Publish `firestore.rules` and `storage.rules` from this folder in their respective Firebase consoles.
5. Confirm the Firebase project's authorized domains / WebView sign-in behavior. OAuth sign-in may not work from a `file://` WebView; use email/password for initial testing.
6. Test with a non-sensitive short clip. The Storage rule caps videos at 100 MB.

## Important limitations
This is still a starter/MVP, not a Play Store release candidate. The uploaded clip is stored in Firebase and its metadata is written to Firestore, but there is not yet a public feed query to load all users' videos, nor production-grade likes/comments/follows, account deletion flow, reporting dashboard, moderation pipeline, payments, creator payouts, messaging, or live streaming. The WebView loads Firebase SDKs from the internet. Build and test with Android Studio/Gradle, fix any SDK/target API issues, complete Play Console Data safety and privacy requirements, then create and verify a signed AAB. Do not claim the app is Play-ready until these checks pass.


## Latest code update (October 2026)
- Added a Firestore-backed cloud feed loader for published video documents.
- Added Firestore-backed like records under `videos/{videoId}/likes/{uid}` for cloud videos.
- Added Firestore-backed comments for cloud videos and a user-owned `users/{uid}/following/{targetUid}` path.
- The feed only loads for signed-in users and requires the provided Firestore and Storage rules to be deployed in Firebase Console.

## Important limitations (not Play Store ready)
This is still a starter/MVP, not a release-ready social video service. No successful Android Gradle build or device test has been performed in this environment. Firebase email/password sign-in must be enabled; the JavaScript config should be replaced with the Firebase **Web app** config from a registered Web app in the same project if the JS SDK rejects the Android app ID. Public video discovery requires Firestore and Storage rules to be deployed and tested. This package does not implement real chat, live streaming, payments/coin purchases, payouts, moderation operations, account deletion UI + public deletion web page, privacy-policy hosting, or Play Console release artifacts. Test security rules and abusive-content handling before production.


## Sign-in status (important)
A visible “Sign in / Sign up” button is available on the home feed; Profile, Friends, and Inbox also open the login sheet. Email/password and Google flows are wired to Firebase Auth code, but real authentication is NOT yet enabled in this package because the Firebase Web App `appId` is missing. Open Firebase Console → project `loop-short` → Project settings → Your apps → Web app (`</>`) and copy its `appId` into `app/src/main/assets/index.html` in `firebaseConfig`. The native Android `google-services.json` does not contain this Web App ID. APK has not been built or tested here.


## Cloudinary video upload update
- Video publishing now uploads to Cloudinary using cloud name `qesbwma2` and unsigned upload preset `loop_videos`.
- The client-side preset name is public by design; restrict allowed formats/size in Cloudinary and monitor usage.
- Firestore metadata writing still requires Firestore to be enabled and rules deployed. No Android APK was built or tested in this environment.


## Fix pass (October 2026)
- Removed automatic restoration of the fake local demo username at startup, so the app no longer silently presents a previous demo session as a signed-in account.
- Startup now explicitly resets the UI to signed-out state and prevents the language sheet from being re-opened after language has already been chosen.
- Changed the Android launch theme to dark to reduce the white flash before the dark UI loads.
- These are source-level fixes only. This environment did not run an Android Gradle build or device test; Firebase sign-in and remote services still require configuration/testing.

## Front-end feature pass (October 2026)
The HTML prototype now includes a local Favorites screen, a local Liked Videos screen, creator/caption/sound search over the bundled demo feed, saved follow state on this device, restoration of local like/favorite/follow indicators, and automatic local watch-history recording while swiping through the feed. These features are intentionally device-local and are not synced across users/devices. The Android Gradle build and on-device behavior still need testing. Cloud-wide search, real user-generated public feed, durable server-side social graph, messaging, LIVE, moderation operations, payments, and account deletion remain backend/native integration work.


## Feature pass — October 13, 2026
- Improved WebView camera/microphone permission handling to request only the native permissions needed for the resources the page requested, deny unsupported WebView resource requests safely, and retry the creator camera after returning from Android app settings.
- Added a real torch/flash attempt using the camera track capabilities where the device/WebView supports it; unsupported devices show a clear message instead of pretending it worked.
- Added pause/resume controls for supported MediaRecorder implementations.
- Added IndexedDB storage for locally posted video blobs and restoration of local posts after the app/webview is restarted. This is device-local persistence, not public/cloud publishing.
- Changed the Android launcher display label to “Loop Short”.
- Validation performed: all 5 inline JavaScript blocks pass `node --check`. No Android Gradle build or physical-device test was possible in this environment.

## Still not completed
Online public feed and cross-user discovery, verified Firebase authentication/upload/playback end-to-end, production comments/likes/follows, chat/push, report/block/moderation backend, account deletion, LIVE, coins/billing/payouts, creator analytics, and signed Play Store AAB still require integration, configuration, security review, and real-device tests.


## Source changes in this feature pass
- Loaded Firebase Firestore and Storage compat SDKs alongside Firebase Auth.
- Video publishing now requires a signed-in Firebase user, uploads the selected/recorded video to `videos/<uid>/...` in Firebase Storage, then writes a `videos` metadata document in Firestore. It does not silently create a local-only post when cloud publishing fails.
- Added a signed-in cloud feed query and rendering for published video documents, plus cloud-backed likes, comments, follows, and report submissions for cloud video documents.
- Removed sample comments from the comments panel so it does not present invented activity as real.
- Source checks: inline JavaScript syntax was checked with Node.js. Android build/device testing and Firebase project deployment were not performed in this environment.

## Still not implemented / must not be represented as working
Real-time private chat and inbox, push notifications, moderation dashboard/workflow, user blocking enforcement, account deletion across Auth/Firestore/Storage, live streaming, verified gifts/payments/payouts, video transcoding/editing pipeline, and signed Play Store AAB. These require additional backend/native work and service configuration. Before cloud testing, enable Email/Password Auth, create Firestore and Storage, and deploy/review `firestore.rules` and `storage.rules`. Firebase rules must be tested before production; client-side code alone is not a security boundary.


## V36 cloud-core pass (source changes; not device-tested)
- Video publishing now fails closed unless a signed-in Firebase account, Firestore, and Firebase Storage are available. It no longer silently turns a failed cloud post into a device-only post.
- The app no longer restores device-local posts into the community feed on startup. The public feed is intended to contain cloud-published videos only.
- Added authenticated per-viewer records under `videos/{videoId}/views/{uid}` and a Firestore rule for them. View counts are deduplicated per signed-in account.
- Friends search now queries real user documents by username and Follow/Unfollow writes both users' follower/following records. User profile documents are readable by signed-in users for discovery; users can only write their own profile. Review privacy requirements before production.
- Removed fake LIVE viewer counts, simulated LIVE chat and gift behavior; LIVE now reports that the streaming backend is not connected instead of pretending to start a real stream.
- Removed invented trending-search counts.
- Validation: inline JavaScript syntax and ZIP integrity are checked. No Android Gradle build, Firebase rules deployment, cloud end-to-end test, or physical-device test was performed. This is a cloud-core development pass, not a complete TikTok-equivalent platform. Real messaging, push notifications, LIVE streaming, Duet/Stitch composition, sound licensing/catalog, verified payments and payouts remain unimplemented.
