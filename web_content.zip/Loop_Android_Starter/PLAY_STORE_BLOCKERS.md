# Loop — Play Store readiness blockers

This archive is an Android Studio starter wrapper around the current HTML prototype. It is **not a production-ready social-video app and is not yet suitable for public Google Play release**. A buildable wrapper does not turn local demo behavior into online services.

## Already included
- Android Studio project scaffold (Kotlin + WebView)
- Current Loop TikTok-style HTML prototype bundled as an offline asset
- Basic video-file chooser bridge for the prototype's upload picker
- Privacy policy draft template (must be completed and hosted)

## Required before public release
1. **Real backend and accounts:** configure Firebase or another backend, authentication, user profiles, database, authorization rules, server-side validation, account recovery and account deletion.
2. **Real video publishing:** secure cloud object storage, resumable upload, size/type limits, transcoding, thumbnail generation, CDN/playback URLs, upload progress, and per-user access controls. The current prototype only creates a local browser-session preview.
3. **Server-backed social features:** likes, comments, follows, feed ranking, views/watch time, favorites, messaging, notifications and creator analytics.
4. **Safety/moderation:** server-side report/block flows, moderation queue, response process, spam/abuse controls, content removal, appeals/contact process and published community standards. Local reports in this prototype are not sent anywhere.
5. **Payments/coins:** Google Play Billing integration where required, server-side purchase verification, entitlement ledger, refunds/chargebacks, fraud prevention and clear coin/gift terms. Do not enable real-money buttons until this works. User's specified coin price reference is 70 coins = PKR 270; any custom quantity must calculate price consistently and be reviewed against Play payment policy.
6. **Creator payouts/promotions/LIVE:** these require separate secure service designs, eligibility and identity/tax/payment workflows, fraud controls, and policy review. They are not activated by this wrapper.
7. **Privacy and legal:** publish accurate privacy policy and terms, implement in-app and web-based account deletion, complete Data safety and content-rating forms, provide support contact, and ensure all SDK disclosures match actual behavior.
8. **Production assets:** final icon, screenshots, store description, feature graphic, age/content rating, target audience, country availability and developer verification.
9. **Android production hardening:** test on real devices; handle Android lifecycle, media permissions, keyboard/back navigation, accessibility, network failures, performance, crash reporting and security. Review whether a WebView is appropriate long term versus native/Compose or a cross-platform app.
10. **Release artifact:** open the folder in Android Studio, sync Gradle, test, configure a unique final application ID and signing key, then generate a signed Android App Bundle (.aab). This starter has not been built or signed in this environment.
11. **Google Play testing:** personal developer accounts created after November 13, 2023 generally need a closed test with at least 12 testers opted in continuously for 14 days before applying for production access; check the current requirement in your Play Console.

## Configuration that cannot be invented
The developer must provide/own the Firebase or backend project, storage, domain/hosting for legal pages and account deletion, support email, Play Console account, signing key, and any payment/payout provider accounts. Never put private service-account keys or server secrets in the HTML or Android client.

## Suggested implementation order
A. Secure auth + database + cloud video upload/playback. B. Server-backed likes/comments/follows/watch metrics. C. moderation/report/block + account deletion + privacy pages. D. push and messaging. E. Billing/coins and creator monetization. F. LIVE, after load/security/moderation engineering. G. QA, signed AAB and Play Console review.

## Additional starter security files
- `firestore.rules`: restrictive starting rules for users, videos, comments, likes and reports.
- `storage.rules`: authenticated upload rules for per-user video and avatar paths with size/type limits.

These files are not active until deployed to the correct Firebase project. Review and test them before deployment; they do not replace server-side moderation, rate limiting, abuse prevention, or a production security audit.


## Update in this revision (not a release approval)
The HTML interface now has the actual Firebase project configuration and a real authenticated video upload path to Firebase Storage plus metadata writes to Firestore. This only works after the Firebase services are enabled and the included rules are deployed. The project has not been built with Android SDK/Gradle in this environment, so build success remains unverified. The public feed still does not fetch uploaded videos from Firestore, and the other production features listed above remain incomplete.


## Code update note
The latest starter includes initial Firestore-backed cloud-feed, likes, comments and following paths. These are not considered production-verified until Firebase rules are deployed, tested with separate user accounts, and the Android app builds and is exercised on real devices.
