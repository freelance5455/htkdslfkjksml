# Loop V37 core cloud-feed update

This update focuses on the real cross-user foundation, not on presenting unfinished controls as working:

- Published-video feed queries now filter `status == "published"` and can load while signed out.
- Public search queries published cloud videos.
- Cloud video cards read public like and view counts; signed-in viewers are recorded once per video per browser session.
- Like, follow, and comment actions no longer claim to save local-only interactions for non-cloud cards.
- Firestore rules allow public reads of published videos and their comments/likes/views, while writes still require authentication and ownership checks.
- Storage rules allow read access to public video media; upload remains owner-authenticated and capped at 100 MB.

## Required before online features work

1. Publish `firestore.rules` and `storage.rules` in the `loop-short` Firebase project.
2. Firebase Console → Authentication → Sign-in method: enable Email/Password.
3. Ensure the deployed app origin is authorized for Firebase Authentication. A `file://` WebView origin may not support Firebase Web Auth; hosted HTTPS or native Firebase Auth integration may be required.
4. Enable Firestore and Firebase Storage and confirm billing/quota/region settings.
5. Test with two separate accounts and two real devices/browsers: upload with account A, then view/like/comment/follow with account B.

## Honest scope

This is a core cloud-feed improvement, not a completed TikTok-equivalent platform. Real LIVE streaming, private/group messaging, production-grade search/recommendations, Duet/Stitch composition, licensed sound catalog, payment verification, creator payouts, moderation tooling, push notifications, private-video access controls, and production Android QA still require implementation. No APK was built or device-tested here. Do not describe this build as fully production-ready.
