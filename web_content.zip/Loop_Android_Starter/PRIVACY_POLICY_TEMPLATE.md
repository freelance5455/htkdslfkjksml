# Loop Privacy Policy — DRAFT TEMPLATE (DO NOT PUBLISH UNCHANGED)

**Effective date:** [DATE]
**Developer / legal entity:** [LEGAL NAME]
**Contact:** [PRIVACY CONTACT EMAIL]
**Public website:** [WEBSITE URL]

This draft is not a completed privacy policy. Before publishing, replace every bracketed field and describe the real deployed app, backend, analytics, advertising, crash reporting, and payment SDKs accurately.

## Information we collect
Describe the exact information collected, such as account identifiers, profile details, uploaded videos and captions, comments, messages, device/diagnostic data, and payment transaction identifiers. Remove any category that the final app does not collect and add any that it does.

## How we use information
Explain account operation, video hosting and delivery, safety/moderation, support, security, analytics, and any other real uses.

## Sharing and service providers
Name the actual hosting, authentication, media storage/CDN, analytics, crash reporting, moderation, and payment providers and explain what data each receives.

## Retention and deletion
State retention periods and explain how users can request account deletion and deletion of associated data, including the external web request route required by Google Play when accounts can be created in-app.

## Security
Describe real safeguards used in production. Do not claim controls that have not been implemented.

## Children
State the actual intended audience and age restrictions. Implement and disclose the required protections for the selected audience.

## Changes and contact
Explain how policy changes are announced and how privacy questions can be sent to [PRIVACY CONTACT EMAIL].
