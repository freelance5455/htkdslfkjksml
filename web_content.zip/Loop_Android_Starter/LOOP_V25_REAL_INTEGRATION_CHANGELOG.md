# Loop v25 — actual source changes

This archive is based on the original `Loop_Original_Promote_World_Languages_CoinShop_v19.zip`, preserving the existing WebView-based Loop experience in `LoopWebActivity` and adding the native feed as the launcher activity.

## Native feed files
- `app/src/main/res/layout/activity_main.xml`: full-screen ViewPager2, For You/Following tabs, empty/error state, and Loop bottom navigation.
- `app/src/main/res/layout/item_video.xml`: Media3 PlayerView and creator/action overlays.
- `app/src/main/java/com/loop/shortvideo/MainActivity.kt`: Firestore video query with `createdAt` then `timestamp` fallback, field-name fallbacks, vertical paging and feed selection.
- `app/src/main/java/com/loop/shortvideo/VideoAdapter.kt`: Media3 playback, player release on recycling, local likes/comments/follows persistence, comment dialog, share intent and creator follow toggle.
- `app/build.gradle.kts`: ViewPager2, Material, Firebase and AndroidX Media3 dependencies.

## Important limitations
- Likes, comments and follows in this native feed are saved only on this device; they are not written to Firestore and are not shared with other users.
- Following is a local creator-name filter, not an authenticated social graph.
- Firestore must have readable documents in `videos` with a playable `videoUrl` (or supported fallback field).
- The source was XML-parsed and archive/file-difference checked in this environment. An Android SDK/Gradle executable was not available here, so a full Android compile and device playback test could not be performed. Do not treat this as a verified APK.
