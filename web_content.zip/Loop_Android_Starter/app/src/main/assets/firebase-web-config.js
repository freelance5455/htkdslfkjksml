// Firebase Web SDK configuration supplied by the user.
// This is a web configuration, not native Android Firebase initialization.
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyDkaWvmtvoUF8RQbc2xyJFTu2rW6mT4qFg",
  authDomain: "loop-short.firebaseapp.com",
  projectId: "loop-short",
  storageBucket: "loop-short.firebasestorage.app",
  messagingSenderId: "751012869125",
  appId: "1:751012869125:web:baddffa357ec2de736586c",
  measurementId: "G-34BW8JFZYY"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export { app, analytics };
