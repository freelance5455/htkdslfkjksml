package com.loop.shortvideo

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import android.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.loop.shortvideo.databinding.ItemVideoBinding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** Native full-screen video pages for Loop. Players are released when pages are recycled. */
class VideoAdapter(
    private val context: Context,
    private val videoList: MutableList<VideoModel>,
    private val onFollowChanged: () -> Unit = {}
) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    private val preferences = context.getSharedPreferences("loop_feed_state", Context.MODE_PRIVATE)
    private val likedIds = preferences.getStringSet("liked_video_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
    private val savedComments = mutableMapOf<String, MutableList<String>>()
    private val followedCreators = preferences.getStringSet("followed_creators", emptySet())?.toMutableSet() ?: mutableSetOf()
    private var activePosition = RecyclerView.NO_POSITION

    inner class VideoViewHolder(val binding: ItemVideoBinding) : RecyclerView.ViewHolder(binding.root) {
        var player: ExoPlayer? = null
        private var boundVideo: VideoModel? = null

        fun bind(video: VideoModel, position: Int) {
            boundVideo = video
            binding.txtUsername.text = "@${video.username.ifBlank { "loop_creator" }}"
            binding.txtDescription.text = video.description
            binding.txtLikesCount.text = formatCount(video.likes + if (video.videoId in likedIds) 1 else 0)
            val existingComments = savedComments.getOrPut(video.videoId) {
                preferences.getStringSet("comments_${video.videoId}", emptySet())?.toMutableList() ?: mutableListOf()
            }
            binding.txtCommentsCount.text = formatCount(video.comments + existingComments.size)
            binding.txtMusicTrack.text = "♫ ${video.musicTrack.ifBlank { "Original sound" }}"
            binding.btnLike.setTextColor(if (video.videoId in likedIds) 0xFFFF4167.toInt() else 0xFFFFFFFF.toInt())
            binding.videoProgressBar.visibility = View.VISIBLE

            releasePlayer()
            val url = video.videoUrl.trim()
            if (url.isNotEmpty()) {
                player = ExoPlayer.Builder(context).build().also { exo ->
                    binding.playerView.player = exo
                    exo.repeatMode = Player.REPEAT_MODE_ONE
                    exo.volume = 1f
                    exo.addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(playbackState: Int) {
                            binding.videoProgressBar.visibility = if (playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE) View.VISIBLE else View.GONE
                        }
                        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                            binding.videoProgressBar.visibility = View.GONE
                            Toast.makeText(context, "This video could not be played", Toast.LENGTH_SHORT).show()
                        }
                    })
                    exo.setMediaItem(MediaItem.fromUri(url))
                    exo.prepare()
                    exo.playWhenReady = position == activePosition
                }
            } else {
                binding.playerView.player = null
                binding.videoProgressBar.visibility = View.GONE
            }

            binding.btnLike.setOnClickListener {
                val id = video.videoId
                if (id in likedIds) likedIds.remove(id) else likedIds.add(id)
                preferences.edit().putStringSet("liked_video_ids", likedIds.toSet()).apply()
                binding.btnLike.setTextColor(if (id in likedIds) 0xFFFF4167.toInt() else 0xFFFFFFFF.toInt())
                binding.txtLikesCount.text = formatCount(video.likes + if (id in likedIds) 1 else 0)
                // Likes are persisted locally; server-wide likes need authenticated Firestore writes.
            }
            binding.btnProfile.setOnClickListener {
                val creator = video.username.ifBlank { "loop_creator" }
                if (creator in followedCreators) {
                    followedCreators.remove(creator)
                    Toast.makeText(context, "Unfollowed @$creator", Toast.LENGTH_SHORT).show()
                } else {
                    followedCreators.add(creator)
                    Toast.makeText(context, "Following @$creator on this device", Toast.LENGTH_SHORT).show()
                }
                preferences.edit().putStringSet("followed_creators", followedCreators.toSet()).apply()
                onFollowChanged()
            }
            binding.btnComment.setOnClickListener { showCommentDialog(video) }
            binding.btnShare.setOnClickListener {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "${video.description}\n${video.videoUrl}")
                }
                context.startActivity(Intent.createChooser(share, "Share Loop video"))
            }
            binding.playerView.setOnClickListener {
                player?.let { exo -> if (exo.isPlaying) exo.pause() else exo.play() }
            }
        }

        fun play() { player?.playWhenReady = true }
        fun pause() { player?.playWhenReady = false; player?.pause() }
        fun releasePlayer() {
            binding.playerView.player = null
            player?.release()
            player = null
        }

        private fun showCommentDialog(video: VideoModel) {
            val input = EditText(context).apply { hint = "Write a comment…"; maxLines = 4 }
            AlertDialog.Builder(context)
                .setTitle("Comment on Loop")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Post") { _, _ ->
                    val text = input.text.toString().trim()
                    if (text.isNotEmpty()) {
                        val comments = savedComments.getOrPut(video.videoId) {
                            preferences.getStringSet("comments_${video.videoId}", emptySet())?.toMutableList() ?: mutableListOf()
                        }
                        comments.add(text)
                        preferences.edit().putStringSet("comments_${video.videoId}", comments.toSet()).apply()
                        binding.txtCommentsCount.text = formatCount(video.comments + comments.size)
                        Toast.makeText(context, "Comment saved on this device", Toast.LENGTH_SHORT).show()
                    }
                }.show()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val binding = ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VideoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) = holder.bind(videoList[position], position)
    override fun getItemCount(): Int = videoList.size

    override fun onViewRecycled(holder: VideoViewHolder) {
        holder.pause()
        holder.releasePlayer()
        super.onViewRecycled(holder)
    }

    fun setActivePosition(position: Int) {
        activePosition = position
    }

    fun pauseAll(recyclerView: RecyclerView) {
        for (i in 0 until recyclerView.childCount) {
            (recyclerView.getChildViewHolder(recyclerView.getChildAt(i)) as? VideoViewHolder)?.pause()
        }
    }

    fun playAt(recyclerView: RecyclerView, position: Int) {
        activePosition = position
        pauseAll(recyclerView)
        val holder = recyclerView.findViewHolderForAdapterPosition(position) as? VideoViewHolder
        holder?.play()
    }

    fun replaceVideos(newVideos: List<VideoModel>) {
        videoList.clear()
        videoList.addAll(newVideos)
        notifyDataSetChanged()
    }

    private fun formatCount(value: Long): String = when {
        value >= 1_000_000 -> String.format("%.1fM", value / 1_000_000.0)
        value >= 1_000 -> String.format("%.1fK", value / 1_000.0)
        else -> value.toString()
    }
}

data class VideoModel(
    val videoId: String = "",
    val videoUrl: String = "",
    val username: String = "",
    val description: String = "",
    val likes: Long = 0,
    val comments: Long = 0,
    val musicTrack: String = ""
)
