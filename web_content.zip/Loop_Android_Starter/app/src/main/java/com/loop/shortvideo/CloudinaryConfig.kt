package com.loop.shortvideo

/** Public upload configuration only. Never put Cloudinary API secrets in an Android app. */
object CloudinaryConfig {
    const val CLOUD_NAME = "qesbwma2"
    const val UNSIGNED_UPLOAD_PRESET = "loop_videos"
    const val UPLOAD_ENDPOINT = "https://api.cloudinary.com/v1_1/$CLOUD_NAME/video/upload"
}
