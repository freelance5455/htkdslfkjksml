package com.loop.shortvideo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.loop.shortvideo.databinding.ActivityMainBinding

/** Native Loop vertical feed. The original web experience remains available in LoopWebActivity. */
class MainActivity : Activity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var videoAdapter: VideoAdapter
    private val videoList = mutableListOf<VideoModel>()
    private var allVideos: List<VideoModel> = emptyList()
    private val db by lazy { FirebaseFirestore.getInstance() }
    private var showingFollowing = false
    private val preferences by lazy { getSharedPreferences("loop_feed_state", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        videoAdapter = VideoAdapter(this, videoList) { applyCurrentFeed() }
        binding.viewPagerVideos.orientation = ViewPager2.ORIENTATION_VERTICAL
        binding.viewPagerVideos.adapter = videoAdapter
        binding.viewPagerVideos.offscreenPageLimit = 1
        binding.viewPagerVideos.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                binding.viewPagerVideos.post { videoAdapter.playAt(binding.viewPagerVideos.getChildAt(0) as? RecyclerView ?: return@post, position) }
            }
        })

        binding.tabForYou.setOnClickListener { selectFeed(false) }
        binding.tabFollowing.setOnClickListener { selectFeed(true) }
        binding.bottomNavigation.selectedItemId = R.id.nav_home
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_discover, R.id.nav_add, R.id.nav_inbox, R.id.nav_me -> {
                    // Preserve the existing Loop creator/profile/discover experience rather than removing it.
                    startActivity(Intent(this, LoopWebActivity::class.java).putExtra("loop_section", item.title.toString()))
                    true
                }
                else -> false
            }
        }
        fetchVideosFromCloud()
    }

    private fun selectFeed(following: Boolean) {
        showingFollowing = following
        binding.tabFollowing.setTextColor(if (following) 0xFFFFFFFF.toInt() else 0x99FFFFFF.toInt())
        binding.tabFollowing.textSize = if (following) 17f else 16f
        binding.tabForYou.setTextColor(if (!following) 0xFFFFFFFF.toInt() else 0x99FFFFFF.toInt())
        binding.tabForYou.textSize = if (!following) 17f else 16f
        applyCurrentFeed()
        if (allVideos.isEmpty()) fetchVideosFromCloud()
    }

    private fun fetchVideosFromCloud() {
        binding.emptyFeedText.visibility = View.GONE
        // Current Loop content has used both createdAt and timestamp field names across revisions.
        db.collection("videos").orderBy("createdAt", Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener { snapshot -> applyVideoDocuments(snapshot.documents.map { doc ->
                VideoModel(
                    videoId = doc.id,
                    videoUrl = doc.getString("videoUrl") ?: doc.getString("url") ?: doc.getString("downloadURL") ?: "",
                    username = doc.getString("username") ?: doc.getString("displayName") ?: doc.getString("userName") ?: "loop_creator",
                    description = doc.getString("description") ?: doc.getString("caption") ?: "",
                    likes = doc.getLong("likes") ?: doc.getLong("likeCount") ?: 0L,
                    comments = doc.getLong("comments") ?: doc.getLong("commentCount") ?: 0L,
                    musicTrack = doc.getString("musicTrack") ?: doc.getString("soundName") ?: "Original sound"
                )
            }) }
            .addOnFailureListener {
                // Fallback for projects whose collection stores the older `timestamp` field.
                db.collection("videos").orderBy("timestamp", Query.Direction.DESCENDING).limit(100).get()
                    .addOnSuccessListener { snapshot -> applyVideoDocuments(snapshot.documents.map { doc ->
                        VideoModel(
                            videoId = doc.id,
                            videoUrl = doc.getString("videoUrl") ?: doc.getString("url") ?: doc.getString("downloadURL") ?: "",
                            username = doc.getString("username") ?: doc.getString("displayName") ?: doc.getString("userName") ?: "loop_creator",
                            description = doc.getString("description") ?: doc.getString("caption") ?: "",
                            likes = doc.getLong("likes") ?: doc.getLong("likeCount") ?: 0L,
                            comments = doc.getLong("comments") ?: doc.getLong("commentCount") ?: 0L,
                            musicTrack = doc.getString("musicTrack") ?: doc.getString("soundName") ?: "Original sound"
                        )
                    }) }
                    .addOnFailureListener { error ->
                        binding.emptyFeedText.visibility = View.VISIBLE
                        binding.emptyFeedText.text = "Couldn't load Loop videos. Check your connection and Firebase Firestore rules.\n\n${error.localizedMessage ?: "Unknown error"}"
                    }
            }
    }

    private fun applyVideoDocuments(videos: List<VideoModel>) {
        allVideos = videos.filter { it.videoUrl.isNotBlank() }
        applyCurrentFeed()
    }

    private fun applyCurrentFeed() {
        val followed = preferences.getStringSet("followed_creators", emptySet()) ?: emptySet()
        val playable = if (showingFollowing) allVideos.filter { it.username in followed } else allVideos
        videoAdapter.replaceVideos(playable)
        binding.emptyFeedText.visibility = if (playable.isEmpty()) View.VISIBLE else View.GONE
        if (playable.isEmpty()) {
            binding.emptyFeedText.text = if (showingFollowing) {
                "Your Following feed is empty. Tap a creator's profile icon to follow them on this device."
            } else {
                "No published videos yet.\n\nUpload a video from Loop's Create screen, then make sure it is published to the Firestore videos collection with a playable videoUrl."
            }
        } else {
            binding.viewPagerVideos.setCurrentItem(0, false)
            binding.viewPagerVideos.post {
                val recycler = binding.viewPagerVideos.getChildAt(0) as? RecyclerView
                if (recycler != null) videoAdapter.playAt(recycler, 0)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && ::videoAdapter.isInitialized) {
            binding.viewPagerVideos.post {
                val recycler = binding.viewPagerVideos.getChildAt(0) as? RecyclerView
                if (recycler != null) videoAdapter.playAt(recycler, binding.viewPagerVideos.currentItem)
            }
        }
    }

    override fun onPause() {
        if (::binding.isInitialized && ::videoAdapter.isInitialized) {
            val recycler = binding.viewPagerVideos.getChildAt(0) as? RecyclerView
            if (recycler != null) videoAdapter.pauseAll(recycler)
        }
        super.onPause()
    }
}
