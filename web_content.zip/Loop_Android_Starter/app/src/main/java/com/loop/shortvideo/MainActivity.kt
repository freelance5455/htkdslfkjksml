package com.loop.shortvideo

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.view.ViewGroup
import android.content.Intent
import android.net.Uri
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.ValueCallback
import android.webkit.PermissionRequest
import android.webkit.JavascriptInterface
import android.content.pm.PackageManager
import android.Manifest
import android.os.Build

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequest = 1001
    private var pendingWebPermission: PermissionRequest? = null
    private lateinit var assetLoader: WebViewAssetLoader
    @Volatile private var requestedCameraFacing: String = "environment"

    inner class LoopBridge {
        @JavascriptInterface
        fun isFirstRunComplete(): Boolean {
            return getSharedPreferences("loop_app_state", MODE_PRIVATE).getBoolean("first_run_complete", false)
        }
        @JavascriptInterface
        fun completeFirstRun() {
            getSharedPreferences("loop_app_state", MODE_PRIVATE).edit().putBoolean("first_run_complete", true).apply()
        }
        @JavascriptInterface
        fun setCameraFacing(facing: String) {
            requestedCameraFacing = if (facing == "user") "user" else "environment"
        }
        @JavascriptInterface
        fun requestMediaPermissions() {
            runOnUiThread {
                val missing = mutableListOf<String>()
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CAMERA)
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO)
                if (missing.isEmpty()) webView.evaluateJavascript("startCameraGranted()", null)
                else requestPermissions(missing.toTypedArray(), 1003)
            }
        }
        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:" + packageName)
                }
                startActivity(intent)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.addJavascriptInterface(LoopBridge(), "LoopAndroid")
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    // Only request Android permissions corresponding to resources requested by this origin.
                    val wanted = request.resources.filter { it == PermissionRequest.RESOURCE_VIDEO_CAPTURE || it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                    if (wanted.isEmpty()) { request.deny(); return@runOnUiThread }
                    val missing = mutableListOf<String>()
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in wanted && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CAMERA)
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in wanted && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO)
                    if (missing.isEmpty()) request.grant(wanted.toTypedArray())
                    else {
                        pendingWebPermission?.deny()
                        pendingWebPermission = request
                        requestPermissions(missing.toTypedArray(), 1002)
                    }
                }
            }
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                val acceptTypes = fileChooserParams?.acceptTypes
                    ?.filter { it.isNotBlank() && it != "*/*" }
                    ?.distinct().orEmpty()
                val mimeType = when {
                    acceptTypes.any { it.startsWith("audio/") } -> "audio/*"
                    acceptTypes.any { it.startsWith("image/") } -> "image/*"
                    else -> "video/*"
                }
                val picker = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = mimeType
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                val chooser = Intent.createChooser(picker, "Choose media")
                // Offer the native camera recorder alongside the gallery for video inputs.
                if (mimeType == "video/*") {
                    val camera = Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE).apply {
                        // Camera apps may honor these hints; the final camera switch UI is device-dependent.
                        val front = requestedCameraFacing == "user"
                        putExtra("android.intent.extras.CAMERA_FACING", if (front) 1 else 0)
                        putExtra("android.intent.extras.LENS_FACING", if (front) 0 else 1)
                        putExtra("android.intent.extra.USE_FRONT_CAMERA", front)
                    }
                    if (camera.resolveActivity(packageManager) != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
                    }
                }
                return try {
                    startActivityForResult(chooser, fileChooserRequest)
                    true
                } catch (_: Exception) {
                    this@MainActivity.fileChooserCallback = null
                    false
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Android API; retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequest) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1002) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                request.grant(request.resources.filter { it == PermissionRequest.RESOURCE_VIDEO_CAPTURE || it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }.toTypedArray())
            } else request?.deny()
        } else if (requestCode == 1003) {
            val granted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted) webView.evaluateJavascript("startCameraGranted()", null)
            else webView.evaluateJavascript("cameraPermissionDenied()", null)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.postDelayed({
                if (::webView.isInitialized) webView.evaluateJavascript("if(window.onLoopAppResume)window.onLoopAppResume()", null)
            }, 250)
        }
    }

    @Deprecated("Use platform back navigation handling in a production app")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
