package com.loop.shortvideo

import android.app.Activity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.auth.api.signin.GoogleSignInAccount

/** Firebase Authentication helpers. Provider activation and SHA fingerprints must be configured in Firebase Console. */
class FirebaseAuthConfig {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun signInWithEmail(email: String, password: String, done: (Boolean, String?) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task -> done(task.isSuccessful, task.exception?.localizedMessage) }
    }

    fun createEmailAccount(email: String, password: String, done: (Boolean, String?) -> Unit) {
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task -> done(task.isSuccessful, task.exception?.localizedMessage) }
    }

    fun signInWithPhoneCredential(credential: PhoneAuthCredential, done: (Boolean, String?) -> Unit) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task -> done(task.isSuccessful, task.exception?.localizedMessage) }
    }

    fun signInWithGoogleAccount(account: GoogleSignInAccount, done: (Boolean, String?) -> Unit) {
        val idToken = account.idToken
        if (idToken.isNullOrBlank()) {
            done(false, "Google ID token missing. Configure the Web client ID and Google provider in Firebase Console.")
            return
        }
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task -> done(task.isSuccessful, task.exception?.localizedMessage) }
    }

    fun signOut() = auth.signOut()
}
