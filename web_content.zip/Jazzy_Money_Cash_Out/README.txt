JAZZY MONEY — Cash Out demo prototype

Open index.html in a browser on your Android phone.

This is a front-end demo only. It does not transfer real money, accept deposits, connect to banks, or guarantee earnings. Balances are demo points only.

Before any real launch:
- Define the game and how rewards are earned.
- Reconcile reward targets: the supplied daily, weekly and monthly amounts may conflict depending on what they mean.
- Budget and fund every payout.
- Use a secure backend and verified payment provider.
- Get legal advice on Nigerian gaming, consumer-protection, privacy and payment requirements.
- Never ask users for PINs, passwords, or OTPs.
