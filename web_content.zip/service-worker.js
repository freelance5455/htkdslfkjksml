const CACHE_NAME = "yakada-bladi-v24"; // ⬆️ v23: مرشد الإنعاش + نوع الحادث + دمج النداءات + لوحة الاستجابة + مؤقت السلامة + تنبيهات رسمية + نقاط المجتمع. v22: عمل بلا إنترنت (مكتبات Firebase محفوظة + بلاط منطقتك) + اتصال ذكي + المتصلون. v21: خرائط بأسماء واضحة (Esri) + أسماء الولايات عربية. v20: حدود الولايات بمرايا متعددة + حالة الخريطة الوطنية. v19: محرك خرائط جديد + تخزين بلاط الخريطة والمكتبات للعمل بلا إنترنت. v18: وسم AdSense + صفحة الخصوصية. v17: خصوصية الموقع + وضع اقتصادي/طوارئ + SOS بلا إنترنت + أدلة الخطوات + تخزين صور الإسعاف للعمل بلا اتصال
const TILE_CACHE = "yakada-tiles-v1", TILE_MAX = 700; // بلاط الخريطة التي شاهدها المستخدم (≈ 20 ميغابايت كحد أقصى) تبقى متاحة بلا إنترنت
const LIB_CACHE = "yakada-libs-v1"; // مكتبات الخريطة (Leaflet/MapLibre) حتى تفتح الخريطة بلا إنترنت
const MEDIA_CACHE = "yakada-media-v1", MEDIA_MAX = 90; // صور ويكيميديا التي شاهدها المستخدم تبقى متاحة بلا إنترنت (حد أقصى 90)
const URLS_TO_CACHE = [
  "/",
  "/index.html",
  "/manifest.json",
  "/privacy.html",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/images/app-background.jpg",
  "/images/hero-banner.jpg",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(URLS_TO_CACHE))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME && !k.startsWith("yakada-geo-") && !k.startsWith("yakada-media-") && !k.startsWith("yakada-tiles-") && !k.startsWith("yakada-libs-")).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // 🖼️ صور ويكيميديا (إسعاف/أخطار): تخزين أول مشاهدة (cors فقط لتفادي حجم opaque الكبير) ثم تُخدَّم بلا إنترنت
  if (req.method === "GET" && req.destination === "image" && url.hostname === "upload.wikimedia.org") {
    event.respondWith(mediaImage(req));
    return;
  }

  // 🗺️ بلاط الخريطة: التخزين أولاً (يتجدد عند تغيّر العنوان)، أما ستايل الخريطة المتجهة فالشبكة أولاً
  if (req.method === "GET" && mapTileHost(url)) {
    event.respondWith(url.pathname.indexOf("/styles/") === 0 || url.pathname === "/planet" ? networkFirst(req, TILE_CACHE) : cacheFirst(req, TILE_CACHE, TILE_MAX));
    return;
  }
  if (req.method === "GET" && firebaseLibHost(url)) {
    // وحدات Firebase (gstatic) مُصدَّرة بإصدار ثابت في الرابط (10.12.0) ⇒ لا تتغير: التخزين أولاً، فيعمل التطبيق إن فُتح بلا إنترنت
    event.respondWith(cacheFirst(req, LIB_CACHE, 0));
    return;
  }
  if (req.method === "GET" && mapLibHost(url)) {
    event.respondWith(cacheFirst(req, LIB_CACHE, 0));
    return;
  }

  // ✅ تصحيح مهم: لا نتدخل إطلاقاً في طلبات ليست GET (مثل كتابات Firestore عبر POST) أو طلبات
  // خارجية (Firebase, Nominatim, خرائط, خطوط...) — محاولة تخزينها بـ cache.put() كانت تفشل بصمت
  // بخطأ في الطرفية مع كل بلاغ/نداء SOS/عملية بحث جغرافي، لأن الـ Cache API لا يقبل تخزين طلبات
  // POST أو استجابات opaque. الآن يُترك أي طلب من هذا النوع يمر مباشرة للشبكة دون أي تدخل.
  if (req.method !== "GET" || url.origin !== self.location.origin) {
    return; // مرور مباشر للشبكة — بدون respondWith، السلوك الافتراضي للمتصفح
  }

  // ✅ وسيط الأخبار (/news-proxy) بيانات حيّة: لا نخزّنها ولا نعيد نسخة قديمة منها أبداً — مرور مباشر للشبكة.
  if (url.pathname === "/news-proxy") return;

  // شبكة أولاً لملفات التطبيق نفسها (يجيب أحدث نسخة). إن لم تردّ الشبكة خلال 3.5 ثانية (إنترنت «متصل شكلاً» بلا بيانات فعلية)
  // نقدّم النسخة المحفوظة فوراً ويكمل التحديث بالخلفية — فلا يبقى التطبيق معلّقاً وقت الطوارئ.
  event.respondWith((async () => {
    const nav = req.mode === "navigate";
    const cached = await caches.match(req, { ignoreSearch: nav }); // رابط ?loc=TOKEN يفتح نفس الصفحة المحفوظة بلا إنترنت
    const net = fetch(req).then((response) => {
      // ✅ نخزّن الاستجابات الناجحة فقط (كان يُخزَّن حتى 404 وأخطاء الخادم فتُقدَّم لاحقاً بلا إنترنت)
      if (response.ok && !(nav && url.search)) { // لا نخزّن روابط تحمل رمز الموقع (خصوصية)
        const clone = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, clone)).catch(() => {});
      }
      return response;
    });
    if (!cached) return net;
    event.waitUntil(net.catch(() => {}));
    return Promise.race([net, new Promise((res) => setTimeout(() => res(cached), 3500))]).catch(() => cached);
  })());
});

async function mediaImage(req) {
  try {
    const cache = await caches.open(MEDIA_CACHE);
    const hit = await cache.match(req.url);
    if (hit) return hit;
    try {
      const res = await fetch(req.url, { mode: "cors", credentials: "omit" });
      if (res.ok) {
        cache.put(req.url, res.clone()).then(async () => {
          const keys = await cache.keys();
          if (keys.length > MEDIA_MAX) await Promise.all(keys.slice(0, keys.length - MEDIA_MAX).map((k) => cache.delete(k)));
        }).catch(() => {});
      }
      return res;
    } catch (e) {
      return fetch(req);
    }
  } catch (e) {
    return fetch(req);
  }
}

// ---------- 🗺️ تخزين بلاط الخريطة والمكتبات ----------
function mapTileHost(url) {
  const h = url.hostname;
  return /(^|\.)basemaps\.cartocdn\.com$/.test(h) || /^[abc]\.tile\.openstreetmap\.org$/.test(h) || h === "tile.openstreetmap.org" ||
    h === "server.arcgisonline.com" || /^[abc]\.tile\.opentopomap\.org$/.test(h) || h === "tiles.openfreemap.org";
}
function mapLibHost(url) {
  return (url.hostname === "cdnjs.cloudflare.com" && /\/ajax\/libs\/(leaflet|maplibre-gl)\//.test(url.pathname)) ||
    (url.hostname === "cdn.jsdelivr.net" && /^\/npm\/(maplibre-gl|@maplibre\/maplibre-gl-leaflet|@mapbox\/mapbox-gl-rtl-text)@/.test(url.pathname)) ||
    (url.hostname === "unpkg.com" && /^\/(maplibre-gl|@maplibre\/maplibre-gl-leaflet|@mapbox\/mapbox-gl-rtl-text)@/.test(url.pathname));
}
function firebaseLibHost(url) {
  return url.hostname === "www.gstatic.com" && /^\/firebasejs\/\d+\.\d+\.\d+\//.test(url.pathname);
}
// نطلب نسخة CORS (قابلة للتخزين بلا حجم opaque الضخم)؛ إن رفضها الخادم نمرّر الطلب كما هو بلا تخزين
async function fetchCors(req) {
  try {
    const res = await fetch(req.url, { mode: "cors", credentials: "omit" });
    return res;
  } catch (e) {
    return null;
  }
}
let tilePuts = 0;
async function cacheFirst(req, name, max) {
  try {
    const cache = await caches.open(name);
    const hit = await cache.match(req.url);
    if (hit) return hit;
    const res = await fetchCors(req);
    if (res && res.ok && res.type === "cors") {
      cache.put(req.url, res.clone()).then(async () => {
        if (!max || ++tilePuts % 25 !== 0) return;
        const keys = await cache.keys();
        if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map((k) => cache.delete(k)));
      }).catch(() => {});
    }
    return res || fetch(req);
  } catch (e) {
    return fetch(req);
  }
}
async function networkFirst(req, name) {
  const cache = await caches.open(name).catch(() => null);
  try {
    const res = await fetchCors(req);
    if (res && res.ok && res.type === "cors") { if (cache) cache.put(req.url, res.clone()).catch(() => {}); return res; }
    if (res) return res;
  } catch (e) {}
  const hit = cache && (await cache.match(req.url));
  return hit || fetch(req);
}
