const VERSION = "mushaf-royal-v1";
const SHELL = [ "./", "./index.html", "./manifest.webmanifest", "./icons/icon-192.png", "./icons/icon-512.png", "./icons/icon-maskable-512.png" ];
const API_HOSTS = ["api.alquran.cloud", "api.quran.com", "api.aladhan.com"];
self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    await cache.addAll(SHELL);
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== VERSION && k.startsWith("mushaf-royal-")).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin === self.location.origin) {
    // Navigation: network first, then cached app shell.
    if (req.mode === "navigate") {
      event.respondWith((async () => {
        try {
          const fresh = await fetch(req);
          const cache = await caches.open(VERSION);
          cache.put("./index.html", fresh.clone());
          return fresh;
        } catch {
          return (await caches.match(req)) || (await caches.match("./index.html")) || Response.error();
        }
      })());
      return;
    }
    // Same-origin static assets: cache first, then network.
    event.respondWith((async () => {
      const cached = await caches.match(req);
      if (cached) return cached;
      try {
        const response = await fetch(req);
        if (response && response.ok) (await caches.open(VERSION)).put(req, response.clone());
        return response;
      } catch { return cached || Response.error(); }
    })());
    return;
  }
  // Quran and prayer APIs: network first; retain successful responses for offline revisits.
  if (API_HOSTS.includes(url.hostname)) {
    event.respondWith((async () => {
      const cache = await caches.open(VERSION + "-data");
      try {
        const response = await fetch(req);
        if (response && (response.ok || response.type === "opaque")) cache.put(req, response.clone());
        return response;
      } catch {
        return (await cache.match(req)) || Response.error();
      }
    })());
    return;
  }
  // CDN scripts and fonts: cache first after the first successful download.
  if (["cdn.jsdelivr.net","unpkg.com","fonts.googleapis.com","fonts.gstatic.com"].includes(url.hostname)) {
    event.respondWith((async () => {
      const cache = await caches.open(VERSION + "-cdn");
      const cached = await cache.match(req);
      if (cached) return cached;
      try {
        const response = await fetch(req);
        if (response && (response.ok || response.type === "opaque")) cache.put(req, response.clone());
        return response;
      } catch { return Response.error(); }
    })());
  }
});
