const CACHE_NAME = 'carreira-craque-pwa-v1635-patches-lite';

// Catálogo completo de escudos externos (Brasil, Série C, Premier League e LaLiga).
// O cache offline é preenchido na primeira instalação/abertura com internet.
const EPL_CREST_URLS = [
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F359.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F362.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F349.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F337.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F331.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F363.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F384.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F368.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F370.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F357.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F364.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F382.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F360.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F361.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F393.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F366.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F367.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F342.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F306.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F14800.png'
];
const LALIGA_CREST_URLS = [
'https://d1jcea4y7xhp7l.cloudfront.net/2017/10/Real-Madrid-logo.jpg',
'https://i.pinimg.com/originals/ea/df/c8/eadfc88183c433489bda052041d34273.png',
'https://sportal.s3.amazonaws.com/media/2018/06/atletico-madrid-logo.png',
'https://colorcodehub.com/_next/image?url=%2Fbrand-logo%2Fathletic-bilbao-logo.png&w=384&q=75',
'https://upload.wikimedia.org/wikipedia/id/9/9f/Real_betis_logo.png',
'https://b.fssta.com/uploads/application/soccer/team-logos/real-sociedad.png',
'https://tickazilla.com///IMAGES_STANDARD/clubSVGLogos/sevilla_fc_team_logo.svg',
'https://www.footylogos.com/dls/logo/villarreal-cf.png',
'https://www.footylogos.com/dls/logo/valencia-cf.png',
'https://arcadia-sport.de/wp-content/plugins/euro-football/assets/images/leagues/es_laliga/teams/celta_vigo.png',
'https://images.seeklogo.com/logo-png/23/2/rayo-vallecano-madrid-logo-png_seeklogo-233856.png',
'https://logodownload.org/wp-content/uploads/2023/05/getafe-fc-logo-0.png',
'https://logolook.net/wp-content/uploads/2023/12/Logo-Espanyol-500x281.png',
'https://d26g3dcbaximvy.cloudfront.net/entity.soccer.club/a2326fc7-5503-4fcc-8dd7-1a74770b8e74/logo/source',
'https://www.footylogos.com/dls/logo/deportivo-la-coruna.png',
'https://matchday-shop.com/cdn/shop/files/levante_400x400_crop_center.png',
'https://assets.wphybrid.com/assets/goal-pl/wp-content/uploads/2021/02/elche_cf.png',
'https://victoryvoetbalreizen.nl/wp-content/uploads/2023/10/osasuna.png',
'https://www.footylogos.com/dls/logo/racing-santander.png',
'https://www.footylogos.com/dls/logo/malaga-cf.png'
];
const ALL_CREST_URLS = ["https://assets.footylogos.com/logos/athletico-paranaense/athletico-paranaense-logo-footylogos.svg","https://www.footylogos.com/dls/logo/rgba-v1/atletico-goianiense.png","https://assets.footylogos.com/logos/goias/goias-logo-footylogos.svg","https://images.seeklogo.com/logo-png/66/2/uberlandia-ec-logo-png_seeklogo-668426.png","https://images.seeklogo.com/logo-png/65/2/asa-de-arapiraca-agremiacao-sportiva-arapiraquens-logo-png_seeklogo-656345.png","https://images.seeklogo.com/logo-png/30/2/sociedade-esportiva-do-gama-logo-png_seeklogo-304728.png","https://escudosfc.com.br/images/atlpr.png","https://escudosfc.com.br/images/remo.png","https://www.footylogos.com/dls/logo/mirassol-fc.png","https://escudosfc.com.br/images/bragantino.png","https://escudosfc.com.br/images/atletico.png","https://escudosfc.com.br/images/sao_bernarndo_sp.png","https://escudosfc.com.br/images/atlego.png","https://escudosfc.com.br/images/aletico_del_rey_mg.png","https://escudosfc.com.br/images/operario_pr.png","https://www.footylogos.com/dls/logo/rgba-v1/fortaleza.png","https://escudosfc.com.br/images/juventude.png","https://www.footylogos.com/dls/logo/rgba-v1/gremio-novorizontino.png","https://escudosfc.com.br/images/cuiaba_mt.png","https://www.footylogos.com/dls/logo/rgba-v1/botafogo-sp.png","https://www.footylogos.com/dls/logo/rgba-v1/amazonas.png","https://www.footylogos.com/dls/logo/rgba-v1/anapolis.png","https://www.footylogos.com/dls/logo/rgba-v1/barra.png","https://www.footylogos.com/dls/logo/rgba-v1/botafogo-pb.png","https://www.footylogos.com/dls/logo/rgba-v1/brusque.png","https://www.footylogos.com/dls/logo/rgba-v1/caxias.png","https://www.footylogos.com/dls/logo/rgba-v1/confianca.png","https://www.footylogos.com/dls/logo/rgba-v1/ferroviaria.png","https://www.footylogos.com/dls/logo/rgba-v1/floresta.png","https://www.footylogos.com/dls/logo/rgba-v1/guarani.png","https://www.footylogos.com/dls/logo/rgba-v1/inter-de-limeira.png","https://www.footylogos.com/dls/logo/rgba-v1/itabaiana.png","https://www.footylogos.com/dls/logo/rgba-v1/ituano.png","https://www.footylogos.com/dls/logo/rgba-v1/maranhao.png","https://www.footylogos.com/dls/logo/rgba-v1/maringa.png","https://www.footylogos.com/dls/logo/rgba-v1/volta-redonda.png","https://www.footylogos.com/dls/logo/rgba-v1/ypiranga.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F359.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F362.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F349.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F337.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F331.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F363.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F384.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F368.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F370.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F357.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F364.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F382.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F360.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F361.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F393.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F366.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F367.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F342.png","https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F306.png","https://www.footylogos.com/dls/logo/rgba-v1/ipswich-town.png"];
const CREST_CACHE = 'carreira-craque-escudos-v4';

const APP_SHELL = ["./", "./index.html", "./manifest.webmanifest", "./data/jogadores_reais_2026.json", "./icons/icon-192.png", "./icons/icon-512.png", "./assets/escudos/aj-auxerre.webp", "./assets/escudos/angers-sco.webp", "./assets/escudos/estac-troyes.webp", "./assets/escudos/fc-lorient.webp", "./assets/escudos/le-havre-ac.webp", "./assets/escudos/le-mans-fc.webp", "./assets/escudos/losc-lille.webp", "./assets/escudos/paris-fc.webp", "./assets/escudos/olympique-de-marseille.webp", "./assets/escudos/olympique-lyonnais.webp", "./assets/escudos/paris-saint-germain.webp", "./assets/escudos/rc-lens.webp", "./assets/escudos/rc-strasbourg-alsace.webp", "./assets/escudos/stade-brestois-29.webp", "./assets/escudos/stade-rennais.webp", "./assets/escudos/toulouse-fc.webp", "./assets/escudos/as-monaco.webp", "./assets/escudos/ogc-nice.webp", "./assets/escudos/abc.svg", "./assets/escudos/abc.png", "./assets/escudos/america-mg.svg", "./assets/escudos/atletico-go.svg", "./assets/escudos/atletico-mg.svg", "./assets/escudos/atletico-pr.svg", "./assets/escudos/avai.svg", "./assets/escudos/bahia.svg", "./assets/escudos/boa-esporte.svg", "./assets/escudos/botafogo.svg", "./assets/escudos/bragantino.svg", "./assets/escudos/brasil-de-pelotas.svg", "./assets/escudos/ceara.svg", "./assets/escudos/chapecoense.svg", "./assets/escudos/corinthians.svg", "./assets/escudos/coritiba.svg", "./assets/escudos/crb.svg", "./assets/escudos/criciuma.svg", "./assets/escudos/cruzeiro.svg", "./assets/escudos/figueirense.svg", "./assets/escudos/flamengo.svg", "./assets/escudos/fluminense.svg", "./assets/escudos/goias.svg", "./assets/escudos/gremio.svg", "./assets/escudos/internacional.svg", "./assets/escudos/joinville.svg", "./assets/escudos/londrina.svg", "./assets/escudos/luverdense.svg", "./assets/escudos/macae.svg", "./assets/escudos/mogi-mirim.svg", "./assets/escudos/nautico.svg", "./assets/escudos/oeste.svg", "./assets/escudos/palmeiras.svg", "./assets/escudos/parana.svg", "./assets/escudos/paysandu.svg", "./assets/escudos/ponte-preta.svg", "./assets/escudos/sampaio-correa.svg", "./assets/escudos/santa-cruz.svg", "./assets/escudos/santos.svg", "./assets/escudos/sao-paulo.svg", "./assets/escudos/sport.svg", "./assets/escudos/tupi.svg", "./assets/escudos/vasco.svg", "./assets/escudos/vila-nova.svg", "./assets/escudos/vitoria.svg", "./assets/trofeus/trofeu-serie-b.png", "./assets/trofeus/trofeu-copa-do-brasil.png", "./assets/trofeus/trofeu-serie-a.png", "./assets/trofeus/trofeu-sub20.png", "./assets/trofeus/trofeu-premier-league.png", "./assets/trofeus/trofeu-serie-c.png", "./assets/trofeus/trofeu-laliga.png", "./assets/trophies/brasileirao-serie-a.png", "./assets/trophies/brasileirao-sub20.png", "./assets/trophies/brasileirao-serie-b.png", "./assets/trophies/premier-league.png", "./assets/uniformes-2026/catalogo_2026.json", "./assets/uniformes-2026/README.md", "./assets/kits/2026/serie-a/README.txt", "./assets/kits/2026/serie-b/README.txt", "./assets/escudos/italia/juventus.svg", "./assets/escudos/italia/roma.svg"];
self.addEventListener('install', event => {
  event.waitUntil(Promise.all([
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)),
    // Best effort: não bloqueia a instalação se algum servidor externo estiver indisponível.
    caches.open(CREST_CACHE).then(async cache => {
      await Promise.allSettled(ALL_CREST_URLS.map(async url => {
        if (await cache.match(url)) return;
        const response = await fetch(url, { mode: 'no-cors', cache: 'reload' });
        if (response && (response.type === 'opaque' || response.ok)) await cache.put(url, response);
      }));
    })
  ]).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('carreira-craque-pwa-') && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  // Cache remote crest/logo images after the first successful online load, so they remain available offline.
  if (req.destination === 'image' && new URL(req.url).origin !== self.location.origin) {
    event.respondWith(caches.open(CACHE_NAME).then(async cache => {
      const cached = await cache.match(req);
      if (cached) return cached;
      try {
        const response = await fetch(req);
        if (response && (response.ok || response.type === 'opaque')) await cache.put(req, response.clone());
        return response;
      } catch (error) {
        return (await cache.match(req)) || new Response('', {status: 504, statusText: 'Offline image unavailable'});
      }
    }));
    return;
  }

  if (req.method !== 'GET') return;
  if (ALL_CREST_URLS.includes(req.url)) {
    event.respondWith(caches.open(CREST_CACHE).then(async cache => {
      const cached = await cache.match(req.url);
      if (cached) return cached;
      try {
        const response = await fetch(req, { mode: 'no-cors' });
        if (response && (response.type === 'opaque' || response.ok)) await cache.put(req.url, response.clone());
        return response;
      } catch (e) {
        return new Response('', { status: 504, statusText: 'Escudo ainda não armazenado offline' });
      }
    }));
    return;
  }
  if (new URL(req.url).origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).then(response => { const copy=response.clone(); caches.open(CACHE_NAME).then(cache=>cache.put('./index.html',copy)); return response; }).catch(() => caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => { if(response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(cache=>cache.put(req,copy));} return response; })));
});
