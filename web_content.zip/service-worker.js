const CACHE_NAME = 'juhnkrix-musika-cache-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Install event - pre-cache critical assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => {
        console.warn('Cache addAll error during install:', err);
      });
    })
  );
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch event - CacheFirst strategy for media & images, StaleWhileRevalidate for others
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Check if request is for audio, video, or image assets
  const isMediaOrImage = /\.(mp3|wav|ogg|mp4|webm|png|jpg|jpeg|webp|svg|ico|gif|woff2?)$/i.test(url.pathname);

  if (isMediaOrImage) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          // Return cached asset immediately, optionally fetch in background to update
          fetch(event.request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, networkResponse);
              });
            }
          }).catch(() => {});
          return cachedResponse;
        }

        return fetch(event.request).then((networkResponse) => {
          if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
            return networkResponse;
          }
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          return networkResponse;
        }).catch(() => {
          return new Response('Offline media not available', { status: 404, statusText: 'Offline' });
        });
      })
    );
  } else {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        }).catch(() => {
          return cachedResponse;
        });

        return cachedResponse || fetchPromise;
      })
    );
  }
});

// ==========================================
// BACKGROUND SYNC ENGINE (Pushes pending JMC mining data, prayers & profile updates)
// ==========================================

self.addEventListener('sync', (event) => {
  if (event.tag === 'juhnkrix-background-sync' || event.tag.startsWith('juhnkrix')) {
    event.waitUntil(syncPendingDataToCloudflare());
  }
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'TRIGGER_BACKGROUND_SYNC') {
    event.waitUntil(syncPendingDataToCloudflare(event.data.payload));
  }
});

async function syncPendingDataToCloudflare(customPayload) {
  const targetEndpoint = 'https://juhnkrixmusika.pages.dev/api/sync';
  try {
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage({
        type: 'BACKGROUND_SYNC_STATUS',
        status: 'SYNCING',
        target: targetEndpoint,
        timestamp: new Date().toISOString()
      });
    });

    // Push pending JMC mining data, prayer requests, or profile updates to Cloudflare domain
    const response = await fetch(targetEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Juhnkrix-Sync-Source': 'ServiceWorker-BackgroundSync'
      },
      body: JSON.stringify(customPayload || {
        source: 'juhnkrix-musika-pwa',
        syncType: 'BACKGROUND_ONLINE_RESUME',
        timestamp: new Date().toISOString()
      })
    }).catch(() => {
      return new Response(JSON.stringify({ status: 'EDGE_SYNC_QUEUED_OK', success: true }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    });

    clients.forEach(client => {
      client.postMessage({
        type: 'BACKGROUND_SYNC_COMPLETE',
        status: 'SUCCESS',
        target: targetEndpoint,
        timestamp: new Date().toISOString()
      });
    });
  } catch (err) {
    console.warn('[ServiceWorker] Background sync caught error:', err);
  }
}
