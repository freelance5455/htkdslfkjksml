const CACHE_NAME = 'carreira-craque-pwa-v1604-kits-fix';

// Escudos da Premier League: cache local persistente após a primeira conexão.
const EPL_CREST_URLS = [
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F359.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F362.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F349.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F337.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F331.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F363.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F384.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F368.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F370.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F357.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F364.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F382.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F360.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F361.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F393.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F366.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F367.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F342.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F306.png',
'https://a.espncdn.com/combiner/i?img=%2Fi%2Fteamlogos%2Fsoccer%2F500%2F14800.png'
];
const CREST_CACHE = 'carreira-craque-epl-escudos-v1';

const APP_SHELL = ["./", "./index.html", "./manifest.webmanifest", "./data/jogadores_reais_2026.json", "./icons/icon-192.png", "./icons/icon-512.png", "./assets/escudos/abc.svg", "./assets/escudos/abc.png", "./assets/escudos/america-mg.svg", "./assets/escudos/atletico-go.svg", "./assets/escudos/atletico-mg.svg", "./assets/escudos/atletico-pr.svg", "./assets/escudos/avai.svg", "./assets/escudos/bahia.svg", "./assets/escudos/boa-esporte.svg", "./assets/escudos/botafogo.svg", "./assets/escudos/bragantino.svg", "./assets/escudos/brasil-de-pelotas.svg", "./assets/escudos/ceara.svg", "./assets/escudos/chapecoense.svg", "./assets/escudos/corinthians.svg", "./assets/escudos/coritiba.svg", "./assets/escudos/crb.svg", "./assets/escudos/criciuma.svg", "./assets/escudos/cruzeiro.svg", "./assets/escudos/figueirense.svg", "./assets/escudos/flamengo.svg", "./assets/escudos/fluminense.svg", "./assets/escudos/goias.svg", "./assets/escudos/gremio.svg", "./assets/escudos/internacional.svg", "./assets/escudos/joinville.svg", "./assets/escudos/londrina.svg", "./assets/escudos/luverdense.svg", "./assets/escudos/macae.svg", "./assets/escudos/mogi-mirim.svg", "./assets/escudos/nautico.svg", "./assets/escudos/oeste.svg", "./assets/escudos/palmeiras.svg", "./assets/escudos/parana.svg", "./assets/escudos/paysandu.svg", "./assets/escudos/ponte-preta.svg", "./assets/escudos/sampaio-correa.svg", "./assets/escudos/santa-cruz.svg", "./assets/escudos/santos.svg", "./assets/escudos/sao-paulo.svg", "./assets/escudos/sport.svg", "./assets/escudos/tupi.svg", "./assets/escudos/vasco.svg", "./assets/escudos/vila-nova.svg", "./assets/escudos/vitoria.svg"];
self.addEventListener('install', event => {
  event.waitUntil(Promise.all([
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)),
    // Best effort: don't fail app installation if an external logo host is unavailable.
    caches.open(CREST_CACHE).then(async cache => {
      await Promise.allSettled(EPL_CREST_URLS.map(async url => {
        if (await cache.match(url)) return;
        const response = await fetch(url, { mode: 'no-cors', cache: 'reload' });
        if (response && (response.type === 'opaque' || response.ok)) await cache.put(url, response);
      }));
    })
  ]).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('carreira-craque-pwa-') && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  if (EPL_CREST_URLS.includes(req.url)) {
    event.respondWith(caches.open(CREST_CACHE).then(async cache => {
      const cached = await cache.match(req.url);
      if (cached) return cached;
      try {
        const response = await fetch(req, { mode: 'no-cors' });
        if (response && (response.type === 'opaque' || response.ok)) await cache.put(req.url, response.clone());
        return response;
      } catch (e) {
        return new Response('', { status: 504, statusText: 'Escudo ainda não armazenado offline' });
      }
    }));
    return;
  }
  if (new URL(req.url).origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).then(response => { const copy=response.clone(); caches.open(CACHE_NAME).then(cache=>cache.put('./index.html',copy)); return response; }).catch(() => caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => { if(response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(cache=>cache.put(req,copy));} return response; })));
});
