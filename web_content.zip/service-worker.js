/* AsimAI PWA shell cache. Runtime/API requests are never cached. */
const CACHE_NAME = 'asimai-shell-v14';
const APP_SHELL = [
  './', './index.html', './AsimAI_index_jarvis_updated.html', './styles.css', './manifest.webmanifest',
  './utils.js', './storage.js', './aiEngine.js', './pdf.js', './share.js',
  './chat.js', './ide.js', './app.js', './asimai-enhancements.js', './asimai-enhancements.css', './jarvis-theme.css', './asimai-pro-upgrades.js', './asimai-pro-upgrades.css', './asimai-all-in-one.js',
  './icons/asimai-192.png', './icons/asimai-512.png', './icons/asimai-maskable-512.png',
  './asimai-premium.css', './asimai-ultimate.js', './asimai-ultimate.css', './asimai-pro-workspace.js', './asimai-pwa.js', './asimai-magica-ui.css', './assets/asimai-aurora-core.webp'
];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // One missing optional resource must not prevent the entire service worker installing.
    await Promise.all(APP_SHELL.map(async url => {
      try {
        const response = await fetch(url, { cache: 'reload' });
        if (response.ok && response.type === 'basic') await cache.put(url, response);
      } catch (error) { console.warn('[AsimAI SW] shell resource skipped:', url, error); }
    }));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('asimai-shell-') && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.includes('/api/') || url.pathname.endsWith('/chat/completions') || url.pathname.endsWith('/embed')) return;
  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response && response.ok && response.type === 'basic') {
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    } catch (error) {
      if (request.mode === 'navigate') {
        const fallback = await caches.match('./index.html');
        if (fallback) return fallback;
      }
      throw error;
    }
  })());
});
