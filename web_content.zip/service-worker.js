const CACHE = 'evolve-practice-v1';
const SHELL = [
  './', './index.html', './styles.css', './app.js', './questions.js',
  './manifest.webmanifest', './assets/app-icon.svg'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(SHELL);
    // Store the supplied question illustrations too, so the complete test works offline.
    const bank = await (await cache.match('./questions.js')).text();
    const images = [...new Set(bank.match(/(?:\.\/)?assets\/[A-Za-z0-9._/-]+/g) || [])]
      .map(path => path.startsWith('./') ? path : `./${path}`);
    await cache.addAll(images);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key !== CACHE) await caches.delete(key);
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    try {
      const response = await fetch(event.request);
      if (response.ok) (await caches.open(CACHE)).put(event.request, response.clone());
      return response;
    } catch (error) {
      if (event.request.mode === 'navigate') return (await caches.match('./index.html'));
      throw error;
    }
  })());
});
