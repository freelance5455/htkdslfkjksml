const C='lohaidan-v6';
const ASSETS=['./','./index.html','./quran-data.js','./manifest.json','./icons/icon-192.png','./icons/icon-512.png'];

self.addEventListener('install',event=>event.waitUntil(
  caches.open(C).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())
));

self.addEventListener('activate',event=>event.waitUntil(
  caches.keys()
    .then(keys=>Promise.all(keys.filter(key=>key!==C).map(key=>caches.delete(key))))
    .then(()=>self.clients.claim())
));

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const request=event.request;
  event.respondWith(
    caches.match(request).then(cached=>{
      if(cached)return cached;
      return fetch(request).then(response=>{
        if(response&&response.ok){
          caches.open(C).then(cache=>cache.put(request,response.clone())).catch(()=>{});
        }
        return response;
      });
    }).catch(()=>request.mode==='navigate'?caches.match('./index.html'):Response.error())
  );
});
