'use strict';
const SHELL_CACHE = 'william-rani-shell-v3-offline-media';
const MEDIA_CACHE = 'william-rani-media-v2';
const APP_URL = new URL('./index.html', self.registration.scope).href;
const APP_SHELL = [
  './', './index.html', './manifest.webmanifest', './icon.svg',
  './icon-192.png', './icon-512.png', './credits.html'
];
// Real animal photos and recorded sounds. Saved into Cache Storage on first online launch.
const MEDIA_URLS = [
  "./assets/media/photos/dog.jpg",
  "./assets/media/photos/cat.jpg",
  "./assets/media/photos/duck.jpg",
  "./assets/media/photos/pig.jpg",
  "./assets/media/photos/cow.jpg",
  "./assets/media/photos/sheep.jpg",
  "./assets/media/photos/lion.jpg",
  "./assets/media/photos/elephant.jpg",
  "./assets/media/audio/dog.mp3",
  "./assets/media/audio/dog.ogg",
  "./assets/media/audio/cat.mp3",
  "./assets/media/audio/cat.ogg",
  "./assets/media/audio/duck.mp3",
  "./assets/media/audio/duck.ogg",
  "./assets/media/audio/pig.mp3",
  "./assets/media/audio/pig.ogg",
  "./assets/media/audio/cow.mp3",
  "./assets/media/audio/cow.ogg",
  "./assets/media/audio/sheep.mp3",
  "./assets/media/audio/sheep.ogg",
  "./assets/media/audio/lion.mp3",
  "./assets/media/audio/lion.ogg",
  "./assets/media/audio/elephant.mp3",
  "./assets/media/audio/elephant.ogg"
].map(url => new URL(url, self.registration.scope).href);
const MEDIA_SET = new Set(MEDIA_URLS);
let mediaCachingPromise = null;

async function broadcastStatus(processed = 0, finished = false) {
  const cache = await caches.open(MEDIA_CACHE);
  let cached = 0;
  for (const url of MEDIA_URLS) {
    if (await cache.match(url)) cached++;
  }
  // A photo is required for each animal, and each animal needs at least one working sound format.
  let allPhotosReady = true;
  for (const url of MEDIA_URLS.slice(0, 8)) { if (!(await cache.match(url))) allPhotosReady = false; }
  const audioGroups = [];
  for (let i = 8; i < MEDIA_URLS.length; i += 2) audioGroups.push(MEDIA_URLS.slice(i, i + 2));
  let allSoundsReady = true;
  for (const group of audioGroups) {
    let found = false;
    for (const url of group) { if (await cache.match(url)) found = true; }
    if (!found) allSoundsReady = false;
  }
  const message = { type: 'OFFLINE_MEDIA_STATUS', total: MEDIA_URLS.length, cached, processed, finished, ready: allPhotosReady && allSoundsReady };
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  clients.forEach(client => client.postMessage(message));
  return message;
}

async function cacheOneMedia(url, cache) {
  if (await cache.match(url)) return true;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 18000);
  try {
    let response;
    try {
      // No-CORS responses can be cached as opaque media and are usable by img/audio elements.
      response = await fetch(new Request(url, { mode: 'no-cors', cache: 'reload', signal: controller.signal }));
    } catch (firstError) {
      response = await fetch(new Request(url, { mode: 'cors', cache: 'reload', signal: controller.signal }));
    }
    if (!response || (!response.ok && response.type !== 'opaque')) return false;
    await cache.put(url, response.clone());
    return true;
  } catch (error) {
    return false;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function cacheAllMedia() {
  if (mediaCachingPromise) return mediaCachingPromise;
  mediaCachingPromise = (async () => {
    const cache = await caches.open(MEDIA_CACHE);
    let processed = 0;
    await broadcastStatus(processed, false);
    await Promise.all(MEDIA_URLS.map(async (url) => {
      await cacheOneMedia(url, cache);
      processed++;
      if (processed === MEDIA_URLS.length || processed % 3 === 0) await broadcastStatus(processed, false);
    }));
    await broadcastStatus(processed, true);
  })();
  try { await mediaCachingPromise; } finally { mediaCachingPromise = null; }
}

self.addEventListener('install', event => {
  event.waitUntil(caches.open(SHELL_CACHE).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('william-rani-') && key !== SHELL_CACHE && key !== MEDIA_CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
    await cacheAllMedia();
  })());
});

self.addEventListener('message', event => {
  const type = event.data && event.data.type;
  if (type === 'CACHE_MEDIA') event.waitUntil(cacheAllMedia());
  if (type === 'GET_OFFLINE_STATUS') event.waitUntil(broadcastStatus(0, false));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const requestUrl = new URL(request.url);
  if (MEDIA_SET.has(requestUrl.href)) {
    event.respondWith((async () => {
      const cache = await caches.open(MEDIA_CACHE);
      const cached = await cache.match(requestUrl.href);
      if (cached) return cached;
      try {
        const response = await fetch(request);
        if (response && (response.ok || response.type === 'opaque')) cache.put(requestUrl.href, response.clone()).catch(() => {});
        return response;
      } catch (_) {
        return new Response('', { status: 503, statusText: 'Offline media has not been saved yet' });
      }
    })());
    return;
  }
  if (requestUrl.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) { const cache = await caches.open(SHELL_CACHE); await cache.put(APP_URL, response.clone()); }
        return response;
      } catch (_) { return (await caches.match(APP_URL)) || Response.error(); }
    })());
    return;
  }
  event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
    if (response.ok) caches.open(SHELL_CACHE).then(cache => cache.put(request, response.clone()));
    return response;
  })));
});
