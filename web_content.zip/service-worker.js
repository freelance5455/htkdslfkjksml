// v2: fixes two bugs that made already-installed APK/PWA instances get permanently
// stuck on old code:
//  1) FILES used to list './app.js', a file that doesn't exist in this single-file app.
//     caches.addAll() is atomic — one missing file failed the ENTIRE install step, so a
//     fresh service-worker install could never succeed once it had failed once.
//  2) The cache name never changed between app updates, and index.html was served
//     "cache-first" (cached copy returned immediately, network never checked). Once any
//     environment (typically a wrapped APK, which stays installed indefinitely unlike a
//     browser tab) had successfully cached an old index.html, no future update — including
//     bug fixes — could ever reach it.
// Fix: only precache files that actually exist, bump the cache name so old stuck caches
// are purged on next activation, and serve index.html "network-first" (always try to fetch
// the latest version; fall back to the cached copy only when offline).

const CACHE = 'masar-cache-v173';
const FILES = ['./index.html', './manifest.json'];
// Runtime-cached third-party assets (fonts, chart.js, PDF export libs): not precached at
// install (a network hiccup on first install would break caches.addAll for everything else),
// but once loaded successfully over the network the first time, cached here and served
// cache-first afterward — so PDF export / charts keep working offline on repeat use.
const RUNTIME_HOSTS = ['fonts.googleapis.com','fonts.gstatic.com','cdnjs.cloudflare.com'];

self.addEventListener('install', e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', e=>{
  e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', e=>{
  if(e.request.method!=='GET') return;

  const isHTML = e.request.mode === 'navigate' || e.request.url.endsWith('/index.html') || e.request.url.endsWith('/');

  if(isHTML){
    // Network-first for the app shell: always try to get the latest code first,
    // so a rebuilt/updated app is never stuck showing an old cached version again.
    e.respondWith(
      fetch(e.request).then(res=>{
        if(res && res.status===200){
          const clone = res.clone();
          caches.open(CACHE).then(c=>c.put(e.request, clone));
        }
        return res;
      }).catch(()=> caches.match(e.request))
    );
    return;
  }

  let reqHost = '';
  try{ reqHost = new URL(e.request.url).hostname; }catch(err){}
  if(RUNTIME_HOSTS.includes(reqHost)){
    // Cache-first for known third-party CDN assets (fonts, chart.js, html2canvas, jsPDF):
    // once fetched successfully one time (needs internet), reused offline from then on.
    e.respondWith(
      caches.match(e.request).then(cached=>{
        if(cached) return cached;
        return fetch(e.request).then(res=>{
          if(res && (res.status===200 || res.type==='opaque')){
            const clone = res.clone();
            caches.open(CACHE).then(c=>c.put(e.request, clone));
          }
          return res;
        }).catch(()=>cached);
      })
    );
    return;
  }

  // Cache-first for other static assets (icons, manifest) — fine to serve instantly,
  // and they still get refreshed in the background on every successful fetch.
  e.respondWith(
    caches.match(e.request).then(cached=>{
      return cached || fetch(e.request).then(res=>{
        if(res && res.status===200 && e.request.url.startsWith(self.location.origin)){
          const clone = res.clone();
          caches.open(CACHE).then(c=>c.put(e.request, clone));
        }
        return res;
      }).catch(()=>cached);
    })
  );
});
