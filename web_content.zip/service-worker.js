const DB_NAME='mi-organizador-master-completo-v2';
const DB_VERSION=4;
self.addEventListener('install',e=>e.waitUntil(self.skipWaiting()));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
function putShared(item){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=e=>{const d=e.target.result;if(!d.objectStoreNames.contains('blobs'))d.createObjectStore('blobs',{keyPath:'id'});if(!d.objectStoreNames.contains('meta'))d.createObjectStore('meta',{keyPath:'id'});if(!d.objectStoreNames.contains('sharedInbox'))d.createObjectStore('sharedInbox',{keyPath:'id'});};r.onsuccess=()=>{const d=r.result;const tx=d.transaction('sharedInbox','readwrite');tx.objectStore('sharedInbox').put(item);tx.oncomplete=()=>{d.close();resolve();};tx.onerror=()=>reject(tx.error);};r.onerror=()=>reject(r.error);});}
self.addEventListener('fetch',event=>{
  if(event.request.method==='POST'){
    event.respondWith((async()=>{try{const form=await event.request.formData();const files=form.getAll('files');for(const f of files){if(f instanceof File){await putShared({id:crypto.randomUUID(),name:f.name,type:f.type,size:f.size,lastModified:f.lastModified,blob:f});}}}catch(e){}return Response.redirect('./index.html?shared=1',303);})());
  }
});
