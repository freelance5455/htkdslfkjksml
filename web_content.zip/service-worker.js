const C='gabx-v1',S=['./','index.html','style.css','app.js','ai-engine.js','brain.js','memory.js','model-manager.js','manifest.json'];
self.oninstall=e=>e.waitUntil(caches.open(C).then(c=>c.addAll(S)));
self.onactivate=e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n.startsWith('gabx-')&&n!==C).map(n=>caches.delete(n)))));
self.onfetch=e=>{const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||!(u.origin===location.origin||u.host==='cdn.jsdelivr.net'))return;
 e.respondWith(caches.match(r).then(h=>h||fetch(r).then(x=>{if(x.status===200){const y=x.clone();caches.open(C).then(c=>c.put(r,y))}return x})))};
