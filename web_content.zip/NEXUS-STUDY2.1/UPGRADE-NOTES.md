# NEXUS STUDY — Academic Vault & Streak Upgrade

## Included
- First-launch student profile setup: student name, school, first academic workspace name, start date and end date.
- Academic Vault page linked from the bottom navigation.
- Academic-year records are separated for exams, homework and timetable entries.
- Manual academic-year creation with student-defined names and dates.
- Automatic archiving after the end date, checked on launch, app resume and while the app remains open.
- No automatic creation of the next academic year.
- Archive restore and confirmed archive deletion.
- Top-right flame streak control, with current streak, longest streak and total study days.
- Completed focus-timer sessions record one study day; multiple sessions on one day count once.
- Settings moved into the bottom navigation.
- Updated Guide tutorials for profile setup, Academic Vault and streaks.
- Backup export/import includes NEXUS-prefixed profile, academic-year, archive, streak and workspace data.

## Storage note
This build retains the existing browser `localStorage` approach used by the supplied project. Academic workspace data is separated using academic-year-specific storage keys. It does not yet use IndexedDB. This avoids an asynchronous storage rewrite across the existing pages, but `localStorage` is intended for relatively small structured data and can be cleared by browser/app site-data removal. Keep regular exported backups.

## Academic archive behavior
An archived year is preserved in local storage. Use **Restore** in Academic Vault to make that year active again and view/work with its records. Archive the active year before restoring a different one. Deleting an archive removes its year-specific exams, homework and timetable data after confirmation.

## Validation
All inline JavaScript and the shared `js/nexus-core.js` passed Node syntax checks. The project has not been tested on a physical Android device or in every browser/WebView. Test the first-launch setup, data entry, year transition, backup/restore and reset on the target device before relying on it for important school records.
