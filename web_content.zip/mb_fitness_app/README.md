# MB FITNESS BY MIHIR BHANUSHALI

A mobile-first Progressive Web App (PWA) fitness and nutrition tracker.

## Included
- Personalized calorie/protein targets using Mifflin-St Jeor + activity multiplier
- Food database and daily diary
- Calories, protein, carbs, fats
- Water and step tracking
- Workout logging
- Weight check-ins and 7-day overview
- Local browser persistence
- Installable PWA shell
- Food image upload UI prepared for secure AI integration

## Run
Serve this folder over HTTP (not file://), e.g. `python -m http.server 8080`, then open `http://localhost:8080`.

## AI food image analysis
The included UI accepts an image and explains how to connect a vision model. A real AI analysis service requires a secure backend/API key. Do not put an AI API key in `app.js` or other frontend files.
