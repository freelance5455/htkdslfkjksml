# Lettere revisione: app Android

## Opzione A: APK automatico con GitHub (nessun programma da installare)
1. Crea un repository su GitHub (anche privato) e carica tutto il contenuto di questa cartella, compresa `.github`.
2. Apri la scheda **Actions**, scegli **Build APK**, premi **Run workflow** (parte anche a ogni caricamento).
3. A fine lavoro (circa 5-8 minuti) apri l'esecuzione e scarica **lettere-revisione-apk**: dentro c'è `app-debug.apk`.
4. Sul telefono apri il file e consenti "Installa da fonti sconosciute". È un APK di prova (debug), adatto all'uso personale; per il Play Store serve un APK firmato.

## Opzione B: Android Studio
`npm install`, `npx cap add android`, `npx cap sync android`, `npx cap open android`, poi Build > Build APK.

## Opzione C: senza APK (PWA)
Pubblica la cartella `www` su un sito HTTPS (ad esempio GitHub Pages), aprila con Chrome su Android e scegli **Aggiungi a schermata Home**: si installa come app e funziona anche offline.

Nell'app la ricerca mappa online funziona; stampa ed esportazioni producono un PDF, un PNG o un HTML da condividere.
