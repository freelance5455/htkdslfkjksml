# Comissão – projeto Android (Kotlin + WebView)

Abrir a pasta no Android Studio (Koala ou mais novo) → Build > Build APK(s). minSdk 26, targetSdk 34.

- Tela principal: app/src/main/assets/index.html (lançar, relatório, ajustes)
- Dados: SharedPreferences (Store.kt), compartilhados por HTML, notificação e bolha
- Notificação fixa: campo de valor + botões "+ Venda" / "+ Entrega" (Notif.kt, QuickAddReceiver.kt)
- Bolha flutuante: Bubble.kt, ativa em Ajustes (pede "Exibir sobre outros apps")
- Atalhos ao segurar o ícone: res/xml/shortcuts.xml
- Relatório .xls (SpreadsheetML) ou .xml + mensagem, enviado ao WhatsApp/WhatsApp Business com o número escolhido (Bridge.send)

Xiaomi/Samsung/etc.: em Ajustes use "Liberar app da economia de bateria" para a notificação não ser encerrada.
