package com.comissao.app
import android.app.RemoteInput
import android.content.*
import android.widget.Toast

class QuickAddReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val txt = RemoteInput.getResultsFromIntent(i)?.getCharSequence("valor")?.toString()
        val v = Store.parse(txt)
        if (v != null && v > 0) {
            Store.add(c, i.getStringExtra("tipo") ?: "venda", v, "Notificação", null)
            Toast.makeText(c, "Salvo: R$ ${Report.br(v)}", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(c, "Valor inválido", Toast.LENGTH_SHORT).show()
        Notif.refresh(c)
    }
}
