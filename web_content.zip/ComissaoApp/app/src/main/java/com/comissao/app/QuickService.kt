package com.comissao.app
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.Settings

class QuickService : Service() {
    private var bubble: Bubble? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val n = Notif.build(this)
        if (Build.VERSION.SDK_INT >= 34) startForeground(Notif.ID, n, 1073741824) else startForeground(Notif.ID, n)
        val cfg = Store.config(this)
        if (cfg.optBoolean("bubble") && Settings.canDrawOverlays(this)) {
            if (bubble == null) bubble = Bubble(this); bubble?.show()
        } else { bubble?.hide(); bubble = null }
        return START_STICKY
    }
    override fun onDestroy() { bubble?.hide(); super.onDestroy() }
    companion object {
        fun sync(c: Context) {
            val i = Intent(c, QuickService::class.java)
            if (Store.config(c).optBoolean("notif", true)) c.startForegroundService(i) else c.stopService(i)
        }
    }
}
