package com.comissao.app
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.*
import kotlin.math.abs

class Bubble(private val c: Context) {
    private val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var btn: View? = null
    private var panel: View? = null
    private fun dp(v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private fun lp(f: Int) = LP(-2, -2, LP.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }

    fun show() {
        if (btn != null) return
        val p = lp(LP.FLAG_NOT_FOCUSABLE).apply { x = dp(8); y = dp(240) }
        val v = TextView(c).apply {
            text = "+"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; width = dp(56); height = dp(56)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF1B8F5A.toInt()) }
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> if (abs(e.rawX - sx) > 10 || abs(e.rawY - sy) > 10) {
                    moved = true; p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, p) }
                MotionEvent.ACTION_UP -> if (!moved) openPanel()
            }
            true
        }
        wm.addView(v, p); btn = v
    }

    private fun openPanel() {
        if (panel != null) return
        val et = EditText(c).apply {
            hint = "Valor (ex: 25,50)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
        }
        fun save(t: String) {
            val v = Store.parse(et.text.toString())
            if (v == null || v <= 0) { Toast.makeText(c, "Valor inválido", Toast.LENGTH_SHORT).show(); return }
            Store.add(c, t, v, "Bolha", null); Notif.refresh(c)
            Toast.makeText(c, "Salvo: R$ ${Report.br(v)}", Toast.LENGTH_SHORT).show(); closePanel()
        }
        fun b(t: String, f: () -> Unit) = Button(c).apply { text = t; setOnClickListener { f() } }
        val row = LinearLayout(c).apply { addView(b("+ Venda") { save("venda") }); addView(b("+ Entrega") { save("entrega") }) }
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(8))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat() }
            addView(TextView(c).apply { text = "Novo lançamento"; setTextColor(Color.BLACK); textSize = 16f })
            addView(et, LinearLayout.LayoutParams(dp(260), -2)); addView(row); addView(b("Fechar") { closePanel() })
        }
        val p = lp(LP.FLAG_NOT_TOUCH_MODAL).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(120)
            softInputMode = LP.SOFT_INPUT_STATE_VISIBLE or LP.SOFT_INPUT_ADJUST_PAN
        }
        wm.addView(box, p); panel = box; et.requestFocus()
    }
    private fun closePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }
    fun hide() {
        closePanel(); btn?.let { try { wm.removeView(it) } catch (_: Exception) {} }; btn = null
    }
}
