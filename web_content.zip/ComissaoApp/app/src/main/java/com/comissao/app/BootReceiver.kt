package com.comissao.app
import android.content.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { try { QuickService.sync(c) } catch (_: Exception) {} }
}
