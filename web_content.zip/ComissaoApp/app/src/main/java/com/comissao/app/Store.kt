package com.comissao.app
import android.content.Context
import org.json.*
import java.text.SimpleDateFormat
import java.util.*

object Store {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("comissao", 0)
    private fun fmt() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun today(): String = fmt().format(Date())
    fun month(): Pair<String, String> {
        val k = Calendar.getInstance(); k.set(Calendar.DAY_OF_MONTH, 1); val a = fmt().format(k.time)
        k.set(Calendar.DAY_OF_MONTH, k.getActualMaximum(Calendar.DAY_OF_MONTH)); return a to fmt().format(k.time)
    }
    @Synchronized fun entries(c: Context) = JSONArray(sp(c).getString("e", "[]"))
    @Synchronized fun add(c: Context, tipo: String, v: Double, desc: String, data: String?) {
        val a = entries(c)
        a.put(JSONObject().put("id", System.currentTimeMillis()).put("tipo", tipo).put("valor", v)
            .put("desc", desc).put("data", if (data.isNullOrBlank()) today() else data))
        sp(c).edit().putString("e", a.toString()).apply()
    }
    @Synchronized fun remove(c: Context, id: Long) {
        val a = entries(c); val n = JSONArray()
        for (i in 0 until a.length()) if (a.getJSONObject(i).getLong("id") != id) n.put(a.get(i))
        sp(c).edit().putString("e", n.toString()).apply()
    }
    fun config(c: Context) = JSONObject(sp(c).getString("cfg", null) ?: """{"percent":1,"phones":[],"bubble":false,"notif":true}""")
    fun saveConfig(c: Context, j: String) { JSONObject(j); sp(c).edit().putString("cfg", j).apply() }
    fun list(c: Context, s: String, e: String): List<JSONObject> {
        val a = entries(c)
        return (0 until a.length()).map { a.getJSONObject(it) }.filter { it.getString("data") in s..e }.sortedBy { it.getString("data") }
    }
    fun parse(s: String?): Double? {
        var t = s?.trim()?.replace("R$", "")?.replace(" ", "") ?: return null
        if (t.contains(',')) t = t.replace(".", "").replace(',', '.')
        return t.toDoubleOrNull()
    }
}
