package com.comissao.app
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build

object Notif {
    const val ID = 1
    fun build(c: Context): Notification {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("quick", "Lançamento rápido", NotificationManager.IMPORTANCE_LOW))
        val (s, e) = Store.month()
        val l = Store.list(c, s, e); val t = l.sumOf { it.getDouble("valor") }; val p = Store.config(c).optDouble("percent", 1.0)
        val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        fun act(tipo: String, label: String): Notification.Action {
            val ri = RemoteInput.Builder("valor").setLabel("Valor ($label)").build()
            val pi = PendingIntent.getBroadcast(c, tipo.hashCode(),
                Intent(c, QuickAddReceiver::class.java).putExtra("tipo", tipo), mut or PendingIntent.FLAG_UPDATE_CURRENT)
            return Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_add), label, pi).addRemoteInput(ri).build()
        }
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(c, "quick").setSmallIcon(R.drawable.ic_add)
            .setContentTitle("Comissão do mês: R$ ${Report.br(t * p / 100)}")
            .setContentText("Total R$ ${Report.br(t)} · ${l.size} lançamentos")
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .addAction(act("venda", "+ Venda")).addAction(act("entrega", "+ Entrega")).build()
    }
    fun refresh(c: Context) { c.getSystemService(NotificationManager::class.java).notify(ID, build(c)) }
}
