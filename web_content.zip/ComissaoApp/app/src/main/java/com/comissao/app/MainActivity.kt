package com.comissao.app
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: String? = null
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "AndroidAPI")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) { pending?.let { v.evaluateJavascript("openAdd('$it')", null); pending = null } }
        }
        pending = intent.getStringExtra("add")
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); i.getStringExtra("add")?.let { web.evaluateJavascript("openAdd('$it')", null) } }
    override fun onResume() { super.onResume(); web.evaluateJavascript("window.refresh&&refresh()", null); QuickService.sync(this) }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(r, p, g); QuickService.sync(this) }
    @Deprecated("") override fun onBackPressed() { if (web.canGoBack()) web.goBack() else moveTaskToBack(true) }
}
