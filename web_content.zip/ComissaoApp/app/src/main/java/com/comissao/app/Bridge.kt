package com.comissao.app
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import org.json.JSONObject

class Bridge(private val a: MainActivity) {
    @JavascriptInterface fun state(): String = JSONObject().put("config", Store.config(a)).put("entries", Store.entries(a)).toString()
    @JavascriptInterface fun add(tipo: String, valor: String, desc: String, data: String): String {
        val v = Store.parse(valor); if (v == null || v <= 0) return "erro"
        Store.add(a, tipo, v, desc, data); Notif.refresh(a); return "ok"
    }
    @JavascriptInterface fun remove(id: String) { Store.remove(a, id.toLong()); Notif.refresh(a) }
    @JavascriptInterface fun saveConfig(json: String) { Store.saveConfig(a, json); a.runOnUiThread { QuickService.sync(a); Notif.refresh(a) } }
    @JavascriptInterface fun message(s: String, e: String) = Report.message(a, s, e)
    @JavascriptInterface fun canOverlay() = Settings.canDrawOverlays(a)
    @JavascriptInterface fun requestOverlay() = a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))) }
    @JavascriptInterface fun batterySettings() = a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }

    /** phone vazio = WhatsApp abre a lista de contatos */
    @JavascriptInterface fun send(s: String, e: String, fmt: String, phone: String) = a.runOnUiThread {
        val f = Report.file(a, s, e, fmt)
        val uri = FileProvider.getUriForFile(a, "${a.packageName}.fp", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = if (fmt == "xml") "text/xml" else "application/vnd.ms-excel"
            putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_TEXT, Report.message(a, s, e))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val d = phone.filter { it.isDigit() }
            if (d.isNotEmpty()) putExtra("jid", (if (d.length <= 11) "55$d" else d) + "@s.whatsapp.net")
        }
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try { i.setPackage(pkg); a.startActivity(i); return@runOnUiThread } catch (_: ActivityNotFoundException) {}
        }
        i.setPackage(null); a.startActivity(Intent.createChooser(i, "Enviar relatório"))
    }
}
