package com.comissao.app
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.Locale

object Report {
    fun br(v: Double): String = String.format(Locale("pt", "BR"), "%,.2f", v)
    fun dm(iso: String) = "${iso.substring(8, 10)}/${iso.substring(5, 7)}/${iso.substring(0, 4)}"
    private fun x(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun pct(c: Context): Double = Store.config(c).optDouble("percent", 1.0)
    private fun pctTxt(p: Double) = if (p == Math.floor(p)) p.toInt().toString() else p.toString().replace('.', ',')
    private fun sum(l: List<JSONObject>, t: String) = l.filter { it.getString("tipo") == t }.sumOf { it.getDouble("valor") }

    fun message(c: Context, s: String, e: String): String {
        val l = Store.list(c, s, e); val v = sum(l, "venda"); val en = sum(l, "entrega"); val p = pct(c)
        return "*RELATÓRIO DE COMISSÃO*\nPeríodo: ${dm(s)} a ${dm(e)}\nLançamentos: ${l.size}\n\n" +
            "*Total: R$ ${br(v + en)}*\nVendas: R$ ${br(v)}\nEntregas: R$ ${br(en)}\n\n" +
            "*Comissão (${pctTxt(p)}%): R$ ${br((v + en) * p / 100)}*"
    }

    fun file(c: Context, s: String, e: String, fmt: String): File {
        val l = Store.list(c, s, e); val v = sum(l, "venda"); val en = sum(l, "entrega"); val p = pct(c)
        val com = (v + en) * p / 100
        val f = File(c.cacheDir, "comissao_${s}_a_${e}.$fmt")
        val sb = StringBuilder("""<?xml version="1.0" encoding="UTF-8"?>""" + "\n")
        if (fmt == "xml") {
            sb.append("<relatorio inicio=\"$s\" fim=\"$e\" lancamentos=\"${l.size}\">\n")
            l.forEach { sb.append("  <lancamento id=\"${it.getLong("id")}\" data=\"${it.getString("data")}\" tipo=\"${it.getString("tipo")}\" valor=\"${it.getDouble("valor")}\">${x(it.optString("desc"))}</lancamento>\n") }
            sb.append("  <totais vendas=\"$v\" entregas=\"$en\" total=\"${v + en}\" percentual=\"$p\" comissao=\"$com\"/>\n</relatorio>\n")
        } else {
            fun s(t: String) = "<Cell><Data ss:Type=\"String\">${x(t)}</Data></Cell>"
            fun n(d: Double) = "<Cell><Data ss:Type=\"Number\">$d</Data></Cell>"
            sb.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"><Worksheet ss:Name=\"Comissao\"><Table>\n")
            sb.append("<Row>${s("Período")}${s(dm(s0(s)) + " a " + dm(e))}</Row>\n<Row>${s("Data")}${s("Tipo")}${s("Descrição")}${s("Valor (R$)")}</Row>\n")
            l.forEach { sb.append("<Row>${s(dm(it.getString("data")))}${s(it.getString("tipo"))}${s(it.optString("desc"))}${n(it.getDouble("valor"))}</Row>\n") }
            sb.append("<Row>${s("Vendas")}<Cell/><Cell/>${n(v)}</Row>\n<Row>${s("Entregas")}<Cell/><Cell/>${n(en)}</Row>\n")
            sb.append("<Row>${s("Total")}<Cell/><Cell/>${n(v + en)}</Row>\n<Row>${s("Comissão (${pctTxt(p)}%)")}<Cell/><Cell/>${n(com)}</Row>\n</Table></Worksheet></Workbook>")
        }
        f.writeText(sb.toString()); return f
    }
    private fun s0(s: String) = s
}
