60 Seconds Escape

Main game file: index.html

To test: open index.html in a modern browser. If your app builder accepts ZIP website projects, upload this ZIP.

Note: This ZIP contains the existing single-file HTML game. It does not itself create an APK or publish a website. Some builders may require a public website URL instead of a ZIP file.
