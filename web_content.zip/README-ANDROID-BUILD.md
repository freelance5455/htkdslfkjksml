# Sewora Mobile App - Android APK Build & Export Guide

This repository contains the complete, production-ready source code, components, CSS, product data, and images for the **Sewora** e-commerce marketplace app (Daraz-inspired).

Follow any of the three methods below to convert this project into an Android APK (`.apk`) or Google Play Bundle (`.aab`).

---

## Method 1: Build Android APK via Capacitor (Recommended)

Capacitor wraps your React/Vite web application into a native Android Studio project with full hardware acceleration, camera access for visual search, offline caching, and native splash screens.

### Prerequisites:
- Node.js (v18+)
- [Android Studio](https://developer.android.com/studio) installed on your computer
- Java JDK 17+

### Step-by-Step Commands:

```bash
# 1. Unzip the project folder and navigate inside
cd sewora-ecommerce-app

# 2. Install all dependencies
npm install

# 3. Install Capacitor core and Android platform
npm install @capacitor/core @capacitor/cli @capacitor/android

# 4. Build the production web bundle
npm run build

# 5. Initialize Capacitor Android project (capacitor.config.json is already configured!)
npx cap add android

# 6. Sync your web build into the Android folder
npx cap sync android

# 7. Open the project directly in Android Studio
npx cap open android
```

### In Android Studio:
1. Wait for Gradle sync to complete (1–2 minutes).
2. Go to **Build** menu in top bar → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
3. Once completed, click **locate** to retrieve your compiled `app-debug.apk`!
4. Transfer the `.apk` file to any Android device or publish to Google Play Store!

---

## Method 2: Convert to APK via PWABuilder (100% No-Code, In Browser)

If you don't have Android Studio installed, you can generate a signed Android APK directly online:

1. Host or deploy this project to Vercel, Netlify, Cloud Run, or GitHub Pages.
2. Open [https://www.pwabuilder.com/](https://www.pwabuilder.com/) in your browser.
3. Paste your deployed app URL (or use the AI Studio preview URL).
4. PWABuilder automatically detects `manifest.json`, service workers, and icons.
5. Click **"Generate Android Package"**.
6. Download the generated `.apk` and `.aab` package immediately!

---

## Method 3: Convert via Bubblewrap / Google TWA CLI

For advanced developers using Google's official Trusted Web Activity (TWA) toolchain:

```bash
# Install Bubblewrap CLI globally
npm install -g @bubblewrap/cli

# Initialize Android project from manifest
bubblewrap init --manifest="https://your-domain.com/manifest.json"

# Build Android APK
bubblewrap build
```

---

## Project Structure Overview

```
sewora-ecommerce-app/
├── public/
│   ├── manifest.json            # PWA & Android app configuration
│   └── icon.svg                 # High-resolution vector launcher icon
├── src/
│   ├── assets/images/           # Generated hero banner & sneaker photography
│   ├── components/
│   │   ├── TopSearchBar.tsx     # Voice & Visual Lens search modals
│   │   ├── HomeScreen.tsx       # Carousel, Flash Sale timer, Just For You feed
│   │   ├── CategoryScreen.tsx   # Faceted filters, sorting & category rail
│   │   ├── ProductDetailScreen.tsx # Multi-image PDP, variants, reviews, delivery estimator
│   │   ├── CartScreen.tsx       # Multi-vendor grouped cart, voucher system
│   │   ├── CheckoutScreen.tsx   # Address selector, Cards, COD, Wallets, BNPL
│   │   ├── OrderSuccessScreen.tsx # 4-step live order tracking timeline
│   │   ├── AccountScreen.tsx    # Order status buckets (To Pay, To Ship, etc.)
│   │   ├── VendorStoreScreen.tsx # Dedicated seller storefront & store vouchers
│   │   ├── SellerChatDrawer.tsx # Real-time simulated seller instant chat
│   │   ├── MobileFrame.tsx      # Realistic smartphone preview frame
│   │   └── ExportApkModal.tsx   # In-app zip bundle exporter
│   ├── data/
│   │   └── mockData.ts          # Complete catalog items, vendors, addresses
│   ├── types/
│   │   └── ecommerce.ts         # TypeScript data contracts
│   ├── App.tsx                  # Main application orchestrator
│   ├── main.tsx                 # DOM entry point
│   └── index.css                # Tailwind CSS v4 design tokens
├── capacitor.config.json        # Pre-configured Capacitor Android package
├── index.html                   # HTML shell with mobile meta tags
├── package.json                 # Build dependencies & scripts
├── tsconfig.json                # TypeScript compilation config
└── vite.config.ts               # Vite bundler setup
```
