# ساخت رایگان APK معاون نمونه با GitHub Actions

1. یک Repository جدید در GitHub بساز.
2. تمام فایل‌های این پوشه را داخل Repository قرار بده.
3. اسم branch اصلی را `main` بگذار.
4. وارد تب **Actions** شو.
5. Workflow با نام **Build Android APK** را باز کن.
6. گزینه **Run workflow** را بزن.
7. بعد از پایان موفق، در صفحه اجرای Workflow بخش **Artifacts** فایل `edu-deputy-debug-apk` را دانلود کن.
8. فایل داخل آن `app-debug.apk` است و روی اندروید قابل نصب است.

این نسخه برای تست، APK دیباگ می‌سازد و نیازی به keystore انتشار ندارد.
