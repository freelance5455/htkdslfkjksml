package com.xblvortex.app

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.*
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.*

class FloatingMenuService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var iconView: ImageView
    private lateinit var menuView: View
    private lateinit var targetOverlayView: View
    private var isMenuOpen = false

    companion object {
        @Volatile var isAimHeadActive = false
        @Volatile var currentHeads: List<RectF> = emptyList()
        @Volatile var customTemplateUri: String? = null
        
        fun updateHeads(heads: List<RectF>) {
            currentHeads = heads
        }
    }

    // Terima sinyal dari MainActivity kalau foto berhasil di-crop
    private val previewReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "UPDATE_PREVIEW") {
                val uriString = intent.getStringExtra("image_uri")
                val imgPreview = menuView.findViewById<ImageView>(R.id.imgPreview)
                if (uriString != null) {
                    imgPreview.setImageURI(Uri.parse(uriString))
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        registerReceiver(previewReceiver, IntentFilter("UPDATE_PREVIEW")) // Daftarin sinyal
        showIcon()
        setupTargetOverlay() 
    }

    private fun showIcon() {
        iconView = ImageView(this)
        iconView.setImageResource(R.drawable.logo_xbl) 
        
        val params = WindowManager.LayoutParams(
            150, 150, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 200

        iconView.setOnClickListener {
            if (isMenuOpen) {
                windowManager.removeView(menuView)
                isMenuOpen = false
            } else {
                showMenu()
                isMenuOpen = true
            }
        }
        windowManager.addView(iconView, params)
    }

    // ====== FUNGSI GAMBAR CROSSHAIR ======
    private fun setupTargetOverlay() {
        val crosshairBitmap = BitmapFactory.decodeResource(resources, R.drawable.crosshair_pro8_circle)
        
        targetOverlayView = object : View(this) {
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                if (isAimHeadActive) {
                    for (rect in currentHeads) {
                        val centerX = rect.centerX()
                        val centerY = rect.centerY()
                        val matrix = Matrix()
                        val scale = 0.5f 
                        matrix.postScale(scale, scale)
                        matrix.postTranslate(
                            centerX - (crosshairBitmap.width * scale / 2), 
                            centerY - (crosshairBitmap.height * scale / 2)
                        )
                        canvas.drawBitmap(crosshairBitmap, matrix, null)
                    }
                }
                invalidate()
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(targetOverlayView, params)
    }

    private fun showMenu() {
        menuView = LayoutInflater.from(this).inflate(R.layout.layout_floating_menu, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER
        windowManager.addView(menuView, params)

        val switchAimHead = menuView.findViewById<Switch>(R.id.switchAimHead)
        val btnSS = menuView.findViewById<Button>(R.id.btnSS)
        val btnSSKarakter = menuView.findViewById<Button>(R.id.btnSSKarakter)
        val btnStartAI = menuView.findViewById<Button>(R.id.btnStartAI)
        val imgPreview = menuView.findViewById<ImageView>(R.id.imgPreview)

        // Tampilin foto kalau udah pernah di-crop
        if (customTemplateUri != null) {
            imgPreview.setImageURI(Uri.parse(customTemplateUri))
            btnStartAI.isEnabled = true
        }

        switchAimHead.setOnCheckedChangeListener { _, isChecked ->
            isAimHeadActive = isChecked
            if (!isChecked) currentHeads = emptyList()
        }

        btnSS.setOnClickListener {
            menuView.visibility = View.GONE
            iconView.visibility = View.GONE
            Handler(Looper.getMainLooper()).postDelayed({
                // (Simulasi SS, nanti diganti kode capture asli)
                menuView.visibility = View.VISIBLE
                iconView.visibility = View.VISIBLE
                Toast.makeText(this, "Screenshot Tersimpan!", Toast.LENGTH_SHORT).show()
            }, 500)
        }

        btnSSKarakter.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("OPEN_CROP_EDITOR", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }

        btnStartAI.setOnClickListener {
            if (customTemplateUri != null) {
                Toast.makeText(this, "AI Aktif! Crosshair Nempel di Kepala.", Toast.LENGTH_SHORT).show()
                btnStartAI.text = "▶ AI RUNNING"
                btnStartAI.setBackgroundColor(Color.parseColor("#00E0FF"))
            } else {
                Toast.makeText(this, "Pilih/Edit foto karakter dulu!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::iconView.isInitialized) windowManager.removeView(iconView)
        if (::targetOverlayView.isInitialized) windowManager.removeView(targetOverlayView)
        unregisterReceiver(previewReceiver)
    }
}