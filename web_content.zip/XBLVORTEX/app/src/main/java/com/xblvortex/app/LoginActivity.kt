package com.xblvortex.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class LoginActivity : AppCompatActivity() {

    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // ==========================================
        // 🛡️ LAPIS 1: ANTI-DEBUGGER (Cegah dibongkar pake PC)
        // ==========================================
        if (android.os.Debug.isDebuggerConnected()) {
            Toast.makeText(this, "Debugger terdeteksi!", Toast.LENGTH_SHORT).show()
            finishAffinity()
            return
        }

        // ==========================================
        // 🛡️ LAPIS 2: ANTI-USB DEBUGGING / COLOK PC
        // ==========================================
        if (isDeviceCompromised()) {
            Toast.makeText(this, "SECURITY: HP terhubung ke PC / USB Debugging aktif!", Toast.LENGTH_LONG).show()
            finishAffinity()
            return
        }

        // ==========================================
        // UI COMPONENTS
        // ==========================================
        val etKey = findViewById<EditText>(R.id.etKey)
        val btnEye = findViewById<ImageView>(R.id.btnToggleEye)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnBuy = findViewById<Button>(R.id.btnBuy)

        // LOGIKA IKON MATA
        etKey.setInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        btnEye.setImageResource(R.drawable.ic_eye_closed)

        btnEye.setOnClickListener {
            if (isPasswordVisible) {
                etKey.setInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
                btnEye.setImageResource(R.drawable.ic_eye_closed)
                isPasswordVisible = false
            } else {
                etKey.setInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
                btnEye.setImageResource(R.drawable.ic_eye_open)
                isPasswordVisible = true
            }
            etKey.setSelection(etKey.text.length)
        }

        // LOGIKA LOGIN & BIKIN TOKEN ANTI-BYPASS
        btnLogin.setOnClickListener {
            val inputKey = etKey.text.toString()
            
            if (inputKey.length == 6) {
                try {
                    val dateCodeStr = inputKey.substring(0, 3)
                    val dateCode = dateCodeStr.toInt()
                    val expireDayOfYear = dateCode - 500

                    val calendar = Calendar.getInstance()
                    val currentDayOfYear = calendar.get(Calendar.DAY_OF_YEAR)

                    if (currentDayOfYear > expireDayOfYear) {
                        Toast.makeText(this, "Key sudah Expired!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Login Berhasil!", Toast.LENGTH_SHORT).show()
                        
                        // 🛡️ BIKIN TOKEN UNTUK MAIN ACTIVITY
                        val prefs = getSharedPreferences("XBL_SECURE", MODE_PRIVATE)
                        prefs.edit().putString("AUTH_TOKEN", "XBL-VORTEX-VALID-2026").apply()
                        
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Format Key Error!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Key harus 6 digit!", Toast.LENGTH_SHORT).show()
            }
        }

        // TOMBOL WA
        btnBuy.setOnClickListener {
            val url = "https://wa.me/6283199568980?text=Halo%20Admin,%20saya%20mau%20beli%20key%20XBL%20VORTEX"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    // ==========================================
    // FUNGSI DETEKSI COLOKAN PC / USB DEBUGGING
    // ==========================================
    private fun isDeviceCompromised(): Boolean {
        // Cek apakah Developer Options (USB Debugging) nyala
        val adbEnabled = Settings.Global.getInt(
            contentResolver, 
            Settings.Global.ADB_ENABLED, 0
        ) == 1
        
        if (adbEnabled) return true 

        // Cek proses aneh (adb / emulator)
        try {
            val process = Runtime.getRuntime().exec("ps")
            val reader = java.io.BufferedReader(java.io.InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val text = line?.lowercase() ?: ""
                if (text.contains("adb") || text.contains("emulator")) {
                    return true 
                }
            }
        } catch (e: Exception) { }

        return false
    }
}