package com.xblvortex.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager

    private val cropLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val croppedUri = result.data?.data
            if (croppedUri != null) {
                FloatingMenuService.customTemplateUri = croppedUri.toString()
                
                // Kirim sinyal ke menu melayang biar preview-nya update
                val intent = Intent("UPDATE_PREVIEW")
                intent.putExtra("image_uri", croppedUri.toString())
                sendBroadcast(intent) 
                
                Toast.makeText(this, "Foto Kepala Siap!", Toast.LENGTH_SHORT).show()
                finish() 
            }
        }
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val svc = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("code", result.resultCode); putExtra("data", result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        // JIKA DIBUKA DARI TOMBOL "SS KARAKTER"
        if (intent.getBooleanExtra("OPEN_CROP_EDITOR", false)) {
            val tempFile = File(cacheDir, "latest_screenshot.png")
            
            if (tempFile.exists()) {
                try {
                    val cropIntent = Intent("com.android.camera.action.CROP").apply {
                        setDataAndType(Uri.fromFile(tempFile), "image/*")
                        putExtra("crop", "true")
                        putExtra("aspectX", 1)
                        putExtra("aspectY", 1)
                        putExtra("outputX", 300)
                        putExtra("outputY", 300)
                        putExtra("return-data", false)
                        val croppedFile = File(cacheDir, "cropped_head.png")
                        putExtra("output", Uri.fromFile(croppedFile))
                    }
                    
                    if (cropIntent.resolveActivity(packageManager) != null) {
                        cropLauncher.launch(cropIntent)
                    } else {
                        val galleryIntent = Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                        cropLauncher.launch(galleryIntent)
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Error buka editor", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } else {
                Toast.makeText(this, "Screenshot dulu sebelum ngedit!", Toast.LENGTH_SHORT).show()
                finish()
            }
            return
        }

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "Overlay sudah aktif!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<FrameLayout>(R.id.btnStartBig).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan Overlay dulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
        }
    }
}