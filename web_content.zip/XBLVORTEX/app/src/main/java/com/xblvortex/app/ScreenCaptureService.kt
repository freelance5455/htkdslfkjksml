package com.xblvortex.app

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    
    private var screenW = 0; private var screenH = 0; private var density = 0
    private var templates: List<Mat> = emptyList()
    private var lastDetectTime = 0L
    private val DETECT_INTERVAL = 150L // 150ms (~6 kali detik) biar hemat baterai

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())

        val code = intent?.getIntExtra("code", -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>("data")
        if (code == -1 || data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } else {
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
            screenW = metrics.widthPixels; screenH = metrics.heightPixels
        }
        density = resources.displayMetrics.densityDpi

        loadTemplates() // Load foto dari folder assets/karakter
        setupVirtualDisplay()
        
        // Mulai Service Menu Melayang
        startService(Intent(this, FloatingMenuService::class.java))

        return START_STICKY
    }

    // Baca gambar dari folder ASSETS
    private fun loadTemplates() {
        val list = mutableListOf<Mat>()
        try {
            val files = assets.list("karakter") ?: return
            for (file in files) {
                val input = assets.open("karakter/$file")
                val bmp = BitmapFactory.decodeStream(input)
                val mat = Mat()
                Utils.bitmapToMat(bmp, mat)
                // Ubah ke Grayscale (Hitam Putih) biar gak peduli warna/lighting
                Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGBA2GRAY) 
                list.add(mat)
            }
        } catch (e: Exception) { e.printStackTrace() }
        templates = list
    }

    private fun setupVirtualDisplay() {
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "XBL_AI", screenW, screenH, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastDetectTime < DETECT_INTERVAL) {
                reader.acquireLatestImage()?.close(); return@setOnImageAvailableListener
            }
            lastDetectTime = now
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            
            val bitmap = imageToBitmap(image)
            image.close()
            
            // Jalanin AI di background thread biar gak nge-lag HP
            Thread {
                val heads = detectHeads(bitmap)
                handler.post { FloatingMenuService.updateHeads(heads) }
            }.start()

        }, handler)
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenW
        
        val bmp = Bitmap.createBitmap(screenW + rowPadding / pixelStride, screenH, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(bmp, 0, 0, screenW, screenH)
    }

    // ====== LOGIKA AI OPENCV ======
    private fun detectHeads(screenBitmap: Bitmap): List<RectF> {
        if (templates.isEmpty() || !FloatingMenuService.isAimHeadActive) return emptyList()

        val foundHeads = mutableListOf<RectF>()
        val srcMat = Mat()
        Utils.bitmapToMat(screenBitmap, srcMat)
        Imgproc.cvtColor(srcMat, srcMat, Imgproc.COLOR_RGBA2GRAY)

        // BLIND SPOT: Cuma scan 75% area atas (Anti Nembak Diri Sendiri)
        val safeHeight = (screenH * 0.75).toInt()
        val safeMat = Mat(srcMat, Rect(0, 0, screenW, safeHeight))

        for (tmpl in templates) {
            // MULTI-SCALE: Cari dari ukuran gedek sampe kecil
            val scales = listOf(1.0, 0.8, 0.6, 0.4)
            for (scale in scales) {
                val resized = Mat()
                val w = (tmpl.cols() * scale).toInt()
                val h = (tmpl.rows() * scale).toInt()
                
                if (w > 0 && h > 0) {
                    Imgproc.resize(tmpl, resized, Size(w.toDouble(), h.toDouble()))
                    val result = Mat()
                    Imgproc.matchTemplate(safeMat, resized, result, Imgproc.TM_CCOEFF_NORMED)
                    
                    val threshold = 0.70 // Akurasi 70%
                    val mm = Core.minMaxLoc(result)
                    if (mm.maxVal >= threshold) {
                        foundHeads.add(RectF(mm.maxLoc.x.toFloat(), mm.maxLoc.y.toFloat(), (mm.maxLoc.x + w).toFloat(), (mm.maxLoc.y + h).toFloat()))
                    }
                    result.release()
                }
                resized.release()
            }
        }
        srcMat.release()
        return foundHeads
    }

    private fun buildNotification(): Notification {
        val ch = NotificationChannel("xbl", "XBL Service", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        return NotificationCompat.Builder(this, "xbl").setContentTitle("XBL VORTEX").setContentText("AI Detektor Aktif").setSmallIcon(android.R.drawable.ic_menu_view).build()
    }

    override fun onDestroy() {
        virtualDisplay?.release(); imageReader?.close(); projection?.stop()
        super.onDestroy()
    }
}