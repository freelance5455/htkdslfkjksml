const $ = selector => document.querySelector(selector);
const screens = ['start-screen', 'classroom', 'chase-screen', 'crush-screen', 'detention-screen'];
const problems = [
  { text: '3 × 3 =', answer: '9' },
  { text: '7 × 9 =', answer: '63' },
  { text: '125 + 387 =', answer: '512' },
  { text: '274927 × 193759 =', answer: '53269580593' }
];
let question = 0;
let entered = '';
let distance = 0;
let heat = 0;
let running = false;
let chaseTimer = null;

function showScreen(id) {
  for (const screen of screens) $('#' + screen).hidden = screen !== id;
}
function resetGame() {
  question = 0;
  entered = '';
  distance = 0;
  heat = 0;
  running = false;
  clearInterval(chaseTimer);
  chaseTimer = null;
  $('#run-button').classList.remove('is-running');
  $('#crush-reply').hidden = true;
  $('#crush-reply').textContent = '';
  $('#play-again').hidden = true;
  $('#crush-copy .crush-question').hidden = false;
  $('.crush-actions').hidden = false;
  showScreen('start-screen');
}
function renderQuiz() {
  const current = problems[question];
  $('#equation').firstChild.textContent = current.text + ' ';
  $('#answer-display').textContent = entered || '?';
  $('#question-count').textContent = String(question + 1).padStart(2, '0') + ' / ' + String(problems.length).padStart(2, '0');
  $('#quiz-feedback').textContent = 'Type your answer';
  $('#teacher-line').textContent = question < 3 ? 'You got this!' : 'Last one...';
  $('#problem-list').innerHTML = problems.map((problem, index) => {
    const state = index < question ? 'is-done' : index === question ? 'is-current' : '';
    return '<div class="side-problem ' + state + '"><span>' + (index < question ? '✓' : index === question ? 'NOW' : 'NEXT') + '</span>' + (index < question ? problem.text + ' ' + problem.answer : problem.text + ' ?') + '</div>';
  }).join('') + '<div class="side-brag">THAT’S ALL<br><b>BRAH!</b></div>';
}
function enterDigit(value) {
  if (entered.length >= 11) return;
  entered += value;
  $('#answer-display').textContent = entered;
}
function submitAnswer() {
  if (!entered) {
    $('#quiz-feedback').textContent = 'Put in an answer first!';
    return;
  }
  if (entered !== problems[question].answer) {
    $('#teacher-line').textContent = 'You’re done, son!';
    $('#quiz-feedback').textContent = 'That’s not quite right...';
    setTimeout(startChase, 550);
    return;
  }
  question += 1;
  if (question === problems.length) {
    $('#teacher-line').textContent = 'All correct! Goooo!';
    $('#quiz-feedback').textContent = 'Perfect score! Now get out of here!';
    setTimeout(startChase, 700);
    return;
  }
  entered = '';
  renderQuiz();
}
function handleKey(value) {
  if (value === 'back') entered = entered.slice(0, -1);
  else if (value === 'submit') return submitAnswer();
  else if (/^\d$/.test(value)) enterDigit(value);
  $('#answer-display').textContent = entered || '?';
}
function startChase() {
  if (!$('#classroom').hidden) {
    running = false;
    distance = 0;
    heat = 0;
    showScreen('chase-screen');
    drawMeters();
    clearInterval(chaseTimer);
    chaseTimer = setInterval(() => {
      if (running) {
        distance = Math.min(100, distance + 1.8);
        heat = Math.min(100, heat + 5.5);
      } else {
        distance = Math.min(100, distance + 0.18);
        heat = Math.max(0, heat - 4.5);
      }
      drawMeters();
      if (distance >= 100) finishChase(true);
      else if (heat >= 100) finishChase(false);
    }, 100);
  }
}
function drawMeters() {
  $('#distance-fill').style.width = distance + '%';
  $('#heat-fill').style.width = heat + '%';
  $('#distance-label').textContent = Math.floor(distance) + '%';
  $('#heat-label').textContent = Math.floor(heat) + '%';
}
function finishChase(escaped) {
  clearInterval(chaseTimer);
  chaseTimer = null;
  running = false;
  $('#run-button').classList.remove('is-running');
  if (escaped) showScreen('crush-screen');
  else showScreen('detention-screen');
}

$('#start-button').addEventListener('click', () => {
  question = 0;
  entered = '';
  renderQuiz();
  showScreen('classroom');
});
$('#keypad').addEventListener('click', event => {
  const key = event.target.closest('[data-key]');
  if (key) handleKey(key.dataset.key);
});
document.addEventListener('keydown', event => {
  if (!$('#classroom').hidden) {
    if (/^\d$/.test(event.key)) handleKey(event.key);
    else if (event.key === 'Backspace') { event.preventDefault(); handleKey('back'); }
    else if (event.key === 'Enter') handleKey('submit');
  }
  if (event.code === 'Space' && !$('#chase-screen').hidden) {
    event.preventDefault();
    running = true;
    $('#run-button').classList.add('is-running');
  }
});
document.addEventListener('keyup', event => {
  if (event.code === 'Space') {
    running = false;
    $('#run-button').classList.remove('is-running');
  }
});
$('#run-button').addEventListener('pointerdown', event => {
  event.preventDefault();
  running = true;
  $('#run-button').classList.add('is-running');
});
window.addEventListener('pointerup', () => {
  running = false;
  $('#run-button').classList.remove('is-running');
});
window.addEventListener('blur', () => {
  running = false;
  $('#run-button').classList.remove('is-running');
});
$('.crush-actions').addEventListener('click', event => {
  const answer = event.target.closest('[data-crush]')?.dataset.crush;
  if (!answer) return;
  $('.crush-actions').hidden = true;
  $('#crush-copy .crush-question').hidden = true;
  const reply = $('#crush-reply');
  reply.hidden = false;
  reply.textContent = answer === 'yes'
    ? '“I like you too!” The very best ending. 💛'
    : '“That’s okay. I’m glad we’re friends!” You made it out either way.';
  $('#play-again').hidden = false;
});
$('#play-again').addEventListener('click', resetGame);
$('#detention-again').addEventListener('click', resetGame);
