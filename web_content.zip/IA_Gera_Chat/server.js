import http from 'node:http';
import {readFile} from 'node:fs/promises';
const PORT=Number(process.env.PORT||3000);
const KEY=process.env.GEMINI_API_KEY;
const MODEL=process.env.GEMINI_MODEL||'gemini-2.5-flash';
const rules=`Você é IA Gera, assistente em português brasileiro especializado APENAS em Free Fire. Responda apenas perguntas relacionadas ao jogo; para outros assuntos, redirecione educadamente ao Free Fire. Ao sugerir sensibilidades, use valores de 0 a 200 para Geral, Ponto Vermelho, Mira 2x, Mira 4x, Mira AWM e Olhadinha. Adapte ao aparelho e às armas citadas, varie sugestões quando solicitado, sem alegar testes reais ou garantia de capa. Seja breve e útil.`;
const server=http.createServer(async(req,res)=>{
 const send=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
 if(req.method==='GET' && (req.url==='/'||req.url==='/index.html')){try{const html=await readFile(new URL('./public/index.html',import.meta.url));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html)}catch{send(500,{error:'Página indisponível'})}return}
 if(req.url!=='/api/chat'||req.method!=='POST'){send(404,{error:'Rota não encontrada'});return}
 if(!KEY){send(503,{error:'Configure GEMINI_API_KEY no servidor.'});return}
 let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>15000){send(413,{error:'Mensagem muito grande'});return}}
 try{const {message,phone,history=[]}=JSON.parse(raw);if(typeof message!=='string'||!message.trim()||message.length>800){send(400,{error:'Mensagem inválida'});return}
 const contents=[...history.slice(-12).filter(x=>['user','assistant'].includes(x.role)&&typeof x.content==='string').map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.content.slice(0,1200)}]})),{role:'user',parts:[{text:`Celular: ${String(phone||'não informado').slice(0,50)}. Pergunta: ${message}`}]}];
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),25000);
 let response;try{response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':KEY},body:JSON.stringify({systemInstruction:{parts:[{text:rules}]},contents,generationConfig:{temperature:0.9,maxOutputTokens:800}}),signal:controller.signal})}finally{clearTimeout(timeout)}
 const result=await response.json();if(!response.ok){console.error('Gemini API status:',response.status);send(502,{error:'Falha na IA. Verifique a chave, modelo e limites do serviço.'});return}
 const reply=result.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('').trim();send(200,{reply:reply||'Não consegui responder agora. Tente novamente.'});
 }catch(e){console.error(e?.message);send(500,{error:'Erro de conexão. Tente novamente.'})}
});server.listen(PORT,()=>console.log(`IA Gera disponível na porta ${PORT}`));
