SG Bill Scanner - Android Studio Project

এটি Android WebView wrapper-সহ প্রজেক্ট সোর্স; APK নয়।

APK বানাতে:
1. PC-তে Android Studio ইনস্টল করুন (Android SDK 35 সহ)।
2. ZIP extract করে Android Studio-তে এই ফোল্ডার Open করুন।
3. Gradle Sync শেষ হলে Build > Build APK(s) নির্বাচন করুন।
4. APK থাকবে app/build/outputs/apk/debug/app-debug.apk

প্রয়োজনীয়: Android Studio/Gradle এবং SDK; এই পরিবেশে Android SDK/Gradle নেই, তাই APK compile করা সম্ভব হয়নি।
