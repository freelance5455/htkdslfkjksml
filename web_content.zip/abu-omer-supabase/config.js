/* ضع بيانات مشروع Supabase هنا (Project Settings → API) */
window.APP_CONFIG = {
  SUPABASE_URL:      "https://wxmioxojugthhligswzz.supabase.co",
  SUPABASE_ANON_KEY:    "sb_publishable_5qy2dvPyOJLpf0utl5OmZg_8n_J0Tmd"
};
