/* ضع بيانات مشروع Supabase هنا (Project Settings → API) */
window.APP_CONFIG = {
  SUPABASE_URL: "",       // مثال: https://abcdxyz.supabase.co
  SUPABASE_ANON_KEY: ""   // مفتاح anon public (مش service_role!)
};
