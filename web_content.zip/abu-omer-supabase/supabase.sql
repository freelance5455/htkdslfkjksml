-- ============ مطعم أبو عمر الكندي — قاعدة بيانات Supabase ============
-- شغّل الملف كله مرة واحدة من: SQL Editor → New query → Run

create table if not exists public.app_state (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.orders (
  id text primary key, ts bigint not null,
  src text not null default 'app', name text, phone text, dt text, addr text,
  items jsonb not null default '[]', fee numeric default 0,
  status text not null default 'new', notes text, pay text, tid text,
  created_at timestamptz default now()
);
create table if not exists public.staff (
  email text primary key, name text,
  role text not null default 'staff' check (role in ('owner','manager','staff')),
  perms text[] not null default '{}'
);
alter table public.app_state enable row level security;
alter table public.orders    enable row level security;
alter table public.staff     enable row level security;

create or replace function public.has_perm(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.staff s
    where lower(s.email) = lower(coalesce(auth.jwt()->>'email',''))
      and (s.role in ('owner','manager') or p = any(s.perms)))
$$;

-- المنيو والإعدادات: الكل يقرا، الموظفين المصرّح لهم يعدّلوا
drop policy if exists st_read  on public.app_state;
drop policy if exists st_write on public.app_state;
create policy st_read  on public.app_state for select to anon, authenticated using (key = 'public');
create policy st_write on public.app_state for all to authenticated
  using (has_perm('menu') or has_perm('offers') or has_perm('settings'))
  with check (has_perm('menu') or has_perm('offers') or has_perm('settings'));

-- الطلبات: العميل يضيف بس، والموظف يقرا ويعدّل
drop policy if exists ord_ins_anon  on public.orders;
drop policy if exists ord_ins_staff on public.orders;
drop policy if exists ord_sel on public.orders;
drop policy if exists ord_upd on public.orders;
drop policy if exists ord_del on public.orders;
create policy ord_ins_anon  on public.orders for insert to anon, authenticated with check (status = 'new' and src = 'app');
create policy ord_ins_staff on public.orders for insert to authenticated with check (has_perm('orders'));
create policy ord_sel on public.orders for select to authenticated using (has_perm('orders') or has_perm('reports'));
create policy ord_upd on public.orders for update to authenticated using (has_perm('orders')) with check (has_perm('orders'));
create policy ord_del on public.orders for delete to authenticated using (has_perm('orders'));

-- الفريق
drop policy if exists stf_sel on public.staff;
drop policy if exists stf_all on public.staff;
create policy stf_sel on public.staff for select to authenticated
  using (lower(email) = lower(coalesce(auth.jwt()->>'email','')) or has_perm('team'));
create policy stf_all on public.staff for all to authenticated using (has_perm('team')) with check (has_perm('team'));

create or replace function public.set_my_name(n text) returns void
language sql security definer set search_path = public as $$
  update public.staff set name = n where lower(email) = lower(coalesce(auth.jwt()->>'email',''))
$$;
create or replace function public.leave_staff() returns void
language sql security definer set search_path = public as $$
  delete from public.staff where lower(email) = lower(coalesce(auth.jwt()->>'email',''))
$$;

-- مخزن الصور والموسيقى
insert into storage.buckets (id, name, public) values ('menu', 'menu', true) on conflict (id) do nothing;
drop policy if exists menu_ins on storage.objects;
drop policy if exists menu_upd on storage.objects;
drop policy if exists menu_del on storage.objects;
create policy menu_ins on storage.objects for insert to authenticated with check (bucket_id = 'menu' and (has_perm('menu') or has_perm('settings')));
create policy menu_upd on storage.objects for update to authenticated using (bucket_id = 'menu' and (has_perm('menu') or has_perm('settings')));
create policy menu_del on storage.objects for delete to authenticated using (bucket_id = 'menu' and (has_perm('menu') or has_perm('settings')));

-- التحديث اللحظي
do $$ begin
  alter publication supabase_realtime add table public.app_state;
exception when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.orders;
exception when others then null; end $$;

-- ★ أضف نفسك كمالك (غيّر البريد لبريدك) — بعدها اعمل حساب بنفس البريد من التطبيق
-- insert into public.staff (email, name, role) values ('YOUR@EMAIL.COM', 'أبو عمر', 'owner');
