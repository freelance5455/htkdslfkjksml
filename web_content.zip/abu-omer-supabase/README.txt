مطعم أبو عمر الكندي — تطبيق ويب + Supabase

الملفات: index.html · style.css · app.js · supabase-layer.js · config.js · supabase.sql · مجلد images
(لازم الملفات والمجلد يفضلوا جنب بعض)

خطوات الربط بـ Supabase (مرة واحدة):
1) اعمل مشروع مجاني على supabase.com.
2) SQL Editor ← New query ← الصق محتوى supabase.sql ← Run.
3) Authentication ← Providers ← Email: ممكن توقف "Confirm email" لو عايز الدخول فوري.
4) Project Settings ← API: انسخ Project URL و anon public key وحطهم في config.js.
5) في SQL Editor شغّل السطر الأخير (غيّر البريد لبريدك):
   insert into public.staff (email,name,role) values ('YOUR@EMAIL.COM','أبو عمر','owner');
6) افتح التطبيق ← أيقونة الدرع ← إنشاء حساب بنفس البريد ← ادخل.
7) من لوحة الإدارة ← الإعدادات ← "نشر التعديلات الآن" مرة واحدة عشان المنيو الحالي يتحفظ في القاعدة.

بعد كده:
- أي تعديل في الأصناف/الأقسام/العروض/الإعدادات بيتحفظ في Supabase ويتحدّث عند كل العملاء لحظياً.
- طلبات العملاء بتتسجل في جدول orders وبتظهر في لوحة الإدارة مع تنبيه لحظي.
- الموظفين: ضيف بريدهم من تبويب الفريق، وهما يعملوا حساب بنفس البريد.
- الصور والموسيقى المرفوعة بتتخزن في Supabase Storage (bucket اسمه menu).
- لو config.js فاضي التطبيق بيشتغل محلياً زي النسخة القديمة.
ملاحظة: مفتاح anon آمن يتحط في التطبيق، لكن ما تحطش service_role أبداً.
