/* مولّد باركود QR صغير (Byte mode, ECC M, إصدارات 1-10) — بدون مكتبات خارجية */
(function(w){
var EXP=[],LOG=[],x=1,i;
for(i=0;i<255;i++){EXP[i]=x;LOG[x]=i;x<<=1;if(x&256)x^=0x11d}
for(i=255;i<512;i++)EXP[i]=EXP[i-255];
function mul(a,b){return a&&b?EXP[LOG[a]+LOG[b]]:0}
function rsGen(n){var g=[1],j,k,ng;for(k=0;k<n;k++){ng=[];for(j=0;j<=g.length;j++)ng[j]=0;for(j=0;j<g.length;j++){ng[j]^=g[j];ng[j+1]^=mul(g[j],EXP[k])}g=ng}return g}
function rsEnc(d,n){var g=rsGen(n),r=[],i,j,f;for(i=0;i<n;i++)r[i]=0;
 for(i=0;i<d.length;i++){f=d[i]^r[0];r.shift();r.push(0);if(f)for(j=0;j<n;j++)r[j]^=mul(g[j+1],f)}return r}
/* لكل إصدار: [عدد كلمات التصحيح لكل بلوك, [[عدد البلوكات, كلمات البيانات],...]] */
var T=[0,[10,[[1,16]]],[16,[[1,28]]],[26,[[1,44]]],[18,[[2,32]]],[24,[[2,43]]],[16,[[4,27]]],[18,[[4,31]]],[22,[[2,38],[2,39]]],[22,[[3,36],[2,37]]],[26,[[4,43],[1,44]]]];
var AL=[0,[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50]];
function utf8(s){var o=[],i,c;s=unescape(encodeURIComponent(s));for(i=0;i<s.length;i++){c=s.charCodeAt(i);o.push(c)}return o}
function dataCw(v){var t=T[v],n=0;t[1].forEach(function(b){n+=b[0]*b[1]});return n}
function make(text){
 var bytes=utf8(text),v,len=bytes.length;
 for(v=1;v<=10;v++){if(4+(v<10?8:16)+8*len<=dataCw(v)*8)break}
 if(v>10)return null;
 var bits=[];function put(val,n){for(var i=n-1;i>=0;i--)bits.push((val>>i)&1)}
 put(4,4);put(len,v<10?8:16);bytes.forEach(function(b){put(b,8)});
 var cap=dataCw(v)*8;
 for(i=0;i<4&&bits.length<cap;i++)bits.push(0);
 while(bits.length%8)bits.push(0);
 for(i=0;bits.length<cap;i++)put(i%2?0x11:0xEC,8);
 var cw=[];for(i=0;i<bits.length;i+=8){var b=0;for(var j=0;j<8;j++)b=(b<<1)|bits[i+j];cw.push(b)}
 /* تقسيم لبلوكات + تصحيح الأخطاء */
 var ecn=T[v][0],blocks=[],pos=0;
 T[v][1].forEach(function(g){for(var k=0;k<g[0];k++){var d=cw.slice(pos,pos+g[1]);pos+=g[1];blocks.push({d:d,e:rsEnc(d,ecn)})}});
 var out=[],maxd=0;blocks.forEach(function(b){if(b.d.length>maxd)maxd=b.d.length});
 for(i=0;i<maxd;i++)blocks.forEach(function(b){if(i<b.d.length)out.push(b.d[i])});
 for(i=0;i<ecn;i++)blocks.forEach(function(b){out.push(b.e[i])});
 var fb=[];out.forEach(function(c){for(var k=7;k>=0;k--)fb.push((c>>k)&1)});
 var size=17+4*v,M=[],F=[],y,xx;
 for(y=0;y<size;y++){M[y]=[];F[y]=[];for(xx=0;xx<size;xx++){M[y][xx]=0;F[y][xx]=0}}
 function sf(x,y,d){if(x<0||y<0||x>=size||y>=size)return;M[y][x]=d?1:0;F[y][x]=1}
 for(i=0;i<size;i++){sf(6,i,i%2==0);sf(i,6,i%2==0)}
 [[3,3],[size-4,3],[3,size-4]].forEach(function(c){for(var dy=-4;dy<=4;dy++)for(var dx=-4;dx<=4;dx++){var d=Math.max(Math.abs(dx),Math.abs(dy));sf(c[0]+dx,c[1]+dy,d!=2&&d!=4)}});
 var al=AL[v],n=al.length;
 for(var a=0;a<n;a++)for(var b2=0;b2<n;b2++){
  if((a==0&&b2==0)||(a==0&&b2==n-1)||(a==n-1&&b2==0))continue;
  for(var dy=-2;dy<=2;dy++)for(var dx=-2;dx<=2;dx++)sf(al[a]+dx,al[b2]+dy,Math.max(Math.abs(dx),Math.abs(dy))!=1)}
 function fmt(mask){
  var d=mask,r=d,k;for(k=0;k<10;k++)r=(r<<1)^((r>>>9)*0x537);
  var bt=((d<<10)|r)^0x5412;
  function g(i){return (bt>>>i)&1}
  for(k=0;k<=5;k++)sf(8,k,g(k));sf(8,7,g(6));sf(8,8,g(7));sf(7,8,g(8));
  for(k=9;k<15;k++)sf(14-k,8,g(k));
  for(k=0;k<8;k++)sf(size-1-k,8,g(k));
  for(k=8;k<15;k++)sf(8,size-15+k,g(k));
  sf(8,size-8,1)}
 fmt(0);
 if(v>=7){var r2=v,k2;for(k2=0;k2<12;k2++)r2=(r2<<1)^((r2>>>11)*0x1F25);
  var vb=(v<<12)|r2;for(k2=0;k2<18;k2++){var bit=(vb>>>k2)&1,aa=size-11+k2%3,bb=Math.floor(k2/3);sf(aa,bb,bit);sf(bb,aa,bit)}}
 /* وضع البيانات بالزجزاج */
 var idx=0,right,vert,j2,upward,yy;
 for(right=size-1;right>=1;right-=2){if(right==6)right=5;
  for(vert=0;vert<size;vert++)for(j2=0;j2<2;j2++){
   xx=right-j2;upward=((right+1)&2)==0;yy=upward?size-1-vert:vert;
   if(!F[yy][xx]&&idx<fb.length){M[yy][xx]=fb[idx];idx++}}}
 var D=[];for(y=0;y<size;y++)D[y]=M[y].slice();
 var masks=[function(x,y){return (x+y)%2==0},function(x,y){return y%2==0},function(x,y){return x%3==0},function(x,y){return (x+y)%3==0},function(x,y){return (Math.floor(x/3)+Math.floor(y/2))%2==0},function(x,y){return x*y%2+x*y%3==0},function(x,y){return (x*y%2+x*y%3)%2==0},function(x,y){return ((x+y)%2+x*y%3)%2==0}];
 function penalty(G){
  var p=0,y,x,run,c,dark=0,rows=[],cols=[];
  for(y=0;y<size;y++){var rs="",cs="";for(x=0;x<size;x++){rs+=G[y][x];cs+=G[x][y];dark+=G[y][x]}rows.push(rs);cols.push(cs)}
  rows.concat(cols).forEach(function(s){run=1;for(var i=1;i<=s.length;i++){if(i<s.length&&s[i]==s[i-1])run++;else{if(run>=5)p+=3+run-5;run=1}}
   var a="10111010000",b="00001011101",i2;for(i2=0;i2+11<=s.length;i2++){var sub=s.substr(i2,11);if(sub==a||sub==b)p+=40}});
  for(y=0;y<size-1;y++)for(x=0;x<size-1;x++){c=G[y][x];if(c==G[y][x+1]&&c==G[y+1][x]&&c==G[y+1][x+1])p+=3}
  p+=(Math.ceil(Math.abs(dark*20-size*size*10)/(size*size))-1)*10;
  return p}
 var best=-1,bp=1e9,mk;
 for(mk=0;mk<8;mk++){
  var G=[];for(y=0;y<size;y++){G[y]=M[y].slice();for(xx=0;xx<size;xx++)if(!F[y][xx]&&masks[mk](xx,y))G[y][xx]^=1}
  var pn=penalty(G);if(pn<bp){bp=pn;best=mk}}
 for(y=0;y<size;y++)for(xx=0;xx<size;xx++){D[y][xx]=M[y][xx];if(!F[y][xx]&&masks[best](xx,y))D[y][xx]^=1}
 M=D;fmt(best);
 return {size:size,modules:M,version:v}}
/* يرسم الباركود على canvas */
w.drawQR=function(canvas,text,px){
 var q=make(text);if(!q)return false;
 var quiet=4,sc=Math.max(2,Math.floor((px||240)/(q.size+quiet*2))),tot=(q.size+quiet*2)*sc;
 canvas.width=canvas.height=tot;var c=canvas.getContext("2d");
 c.fillStyle="#fff";c.fillRect(0,0,tot,tot);c.fillStyle="#000";
 for(var y=0;y<q.size;y++)for(var x=0;x<q.size;x++)if(q.modules[y][x])c.fillRect((x+quiet)*sc,(y+quiet)*sc,sc,sc);
 return true};
w.makeQR=make;
})(typeof window!=="undefined"?window:globalThis);
