
const SRC0=(()=>{const x=document.documentElement.outerHTML,k=x.indexOf("<scr"+"ipt>");return"<!DOCTYPE html>\n"+x.slice(0,k).replace(/ data-frame-refused-watch=""/,"").replace(/ data-theme="[^"]*"/,"").replace(/(<html[^>]*?) style="color-scheme:[^"]*"/,"$1").replace(/<style><\/style>/g,"")+x.slice(k)})();
/* ===== الإعدادات والبيانات (عدّل هنا فقط / ويمكن ربطها بقاعدة بيانات لاحقاً) ===== */
const DATA={
 name:"أبو عمر الكندي",
 whatsapp:"201033919496",          // رقم الواتساب بالصيغة الدولية بدون + أو 0
 phone:"01033919496",
 address:"مساكن الكندى - صقر قريش - المعادي",
 deliveryFee:20,
 wallets:{vodafone:"01033919496",etisalat:"01033919496"},
 ownerCode:"AKINDI2026",   // رمز تفعيل حساب المالك (غيّره قبل التسليم)   // أرقام المحافظ الإلكترونية
 currency:"ج.م",
 logo:"",                          // ضع رابط أو base64 للشعار هنا أو ارفعه من أيقونة الدرع
 categories:[
 {id:"sand",name:"قسم السندوتشات",desc:"سندوتشات بلدي وفرنساوي"},
 {id:"crepe",name:"قسم الكريب",desc:"كريب طازج محشو على الطلب"},
 {id:"hawa",name:"قسم الحواوشي",desc:"حواوشي مشوي على الفحم"},
 {id:"grill",name:"قسم المشويات",desc:"مشويات على الفحم"},
 {id:"side",name:"الأطباق الجانبية",desc:"رز وخضار ومقبلات"},
 {id:"broast",name:"قسم البروستد",desc:"بروستد مقرمش"},
 {id:"burger",name:"قسم البرجر",desc:"١٠٠٪ لحم بقري طازج"},
 {id:"meal",name:"قسم الوجبات",desc:"أشهى الوجبات الكاملة"},
 {id:"tray",name:"قسم الصواني",desc:"صواني العيلة والمناسبات"}
 ],
 /* img: ضع رابط صورة الصنف (https://...) وستظهر بدل الأيقونة */
 items:[
  {c:"crepe",n:"كريب بطاطس",d:"كريب طازج محشو بطاطس محمرة وصوص المطعم",p:40,from:1},
  {c:"crepe",n:"كريب بانيه ناجتس بالبطاطس",d:"قطع بانيه ناجتس مقرمشة مع البطاطس والصوص",p:50,from:1},
  {c:"crepe",n:"كريب شاورما فراخ",d:"شاورما فراخ متبلة مع طحينة وصوص وخضار",p:80,from:1,best:1},
  {c:"crepe",n:"كريب شيش طاووق",d:"شيش طاووق مشوي مع الخضار والصوص",p:80,from:1},
  {c:"crepe",n:"كريب استربس فراخ",d:"استربس فراخ مقرمش مع جبنة وصوص",p:80,from:1},
  {c:"crepe",n:"كريب مكس فراخ",d:"شاورما وشيش واستربس مع جبنة وصوص خاص",p:100,from:1},
  {c:"crepe",n:"كريب برجر",d:"برجر لحم مع جبنة سايحة",p:90,from:1},
  {c:"crepe",n:"كريب لحمة مفرومة",d:"لحمة مفرومة متبلة مع جبنة سايحة",p:90,from:1},
  {c:"crepe",n:"كريب كفتة مشوية",d:"كفتة مشوية على الفحم مع طحينة وخضار",p:80,from:1},
  {c:"crepe",n:"كريب شيش طاووق مشوي",d:"شيش طاووق مشوي على الفحم مع صوص وطماطم",p:100,from:1},
  {c:"sand",n:"سندوتش كبدة",d:"كبدة إسكندراني بالبصل والفلفل",p:50,from:1},
  {c:"sand",n:"سندوتش سجق",d:"سجق بلدي مشوي بالطماطم والصوص",p:40,from:1},
  {c:"sand",n:"سندوتش بطاطس",d:"بطاطس محمرة بالصوص والطحينة",p:20,from:1},
  {c:"sand",n:"سندوتش كفتة داود",d:"كفتة داود المشوية على الفحم",p:25,from:1},
  {c:"sand",n:"سندوتش ناجتس",d:"ناجتس فراخ مقرمش مع الجبنة والصوص",p:30,from:1},
  {c:"sand",n:"سندوتش شاورما فراخ أو شيش طاووق أو فاهيتا أو استربس",d:"فرنساوي فقط — شاورما فراخ مع طحينة وخضار",p:60,best:1},
  {c:"hawa",n:"حواوشي مخصوص",d:"عجينة محشوة لحمة مفرومة متبلة ومشوية على الفحم",p:30,best:1},
  {c:"hawa",n:"حواوشي لحم بلدي",d:"لحمة بلدي مفرومة خشنة مع البهارات",p:50},
  {c:"hawa",n:"حواوشي جبنة",d:"خليط الجبنة السايحة مع البهارات",p:60},
  {c:"hawa",n:"حواوشي سجق",d:"سجق بلدي مشوي مع فلفل وطماطم",p:60},
  {c:"grill",n:"حص فرخة تكا",d:"نص فرخة تكا متبلة ومشوية على الفحم",p:150},
  {c:"grill",n:"حص فرخة شيش",d:"نص فرخة شيش مشوية على الفحم مع عيش وسلطة",p:150},
  {c:"grill",n:"حص كيلو شيش طاووق",d:"شيش طاووق مشوي على الفحم",p:220,best:1},
  {c:"grill",n:"حص كيلو سجق بلدي مشوي",d:"سجق بلدي مشوي على الفحم",p:220},
  {c:"grill",n:"حص كيلو كفتة كندوز",d:"كفتة كندوز مشوية على الفحم",p:200,best:1},
  {c:"grill",n:"حص كيلو كفتة ضاني",d:"كفتة ضاني بلدي مشوية على الفحم",p:300},
  {c:"grill",n:"حص كيلو كباب بلدي",d:"كباب بلدي مشوي على الفحم",p:400},
  {c:"grill",n:"حص كيلو طرب",d:"طرب مشوي على الفحم",p:300},
  {c:"grill",n:"حص كيلو ممبار",d:"ممبار بلدي محشي ومشوي",p:100},
  {c:"side",n:"طبق رز أبيض بالشعرية",d:"رز مصري بالشعرية",p:30},
  {c:"side",n:"طبق رز أبيض بالشعرية بالكبدة",d:"رز بالشعرية مع كبدة مشوية",p:50},
  {c:"side",n:"طبق رز بسمتي",d:"رز بسمتي مبهر",p:40},
  {c:"side",n:"طبق رز بسمتي بالكبدة",d:"رز بسمتي مع كبدة",p:50},
  {c:"side",n:"خضار اليوم",d:"خضار طازج مطبوخ حسب اليوم",p:30},
  {c:"side",n:"ملوخية",d:"ملوخية بلدي بالطشة",p:30},
  {c:"side",n:"طبق بطاطس بوم فريت",d:"بطاطس محمرة مقرمشة",p:30},
  {c:"side",n:"طبق ربع ممبار",d:"ربع ممبار محشي مشوي",p:50},
  {c:"broast",n:"وجبة ١ قطعة بروست",d:"قطعة بروستد مقرمشة مع عيش وصوص",p:60},
  {c:"broast",n:"وجبة ٢ قطعة بروست",d:"قطعتين بروستد مقرمش مع عيش وصوص",p:100},
  {c:"broast",n:"وجبة ٣ قطع بروست",d:"٣ قطع بروستد مقرمشة مع عيش وصوص",p:150,best:1},
  {c:"broast",n:"وجبة ٤ قطع بروست",d:"٤ قطع بروستد مع بطاطس وعيش وصوص",p:200},
  {c:"burger",n:"برجر لحم سادة",d:"قطعة لحم بقري طازج ١٠٠٪ على الجريل",p:50},
  {c:"burger",n:"برجر لحم بيض أو جبنة",d:"لحم بقري طازج مع بيض أو جبنة شيدر",p:60},
  {c:"burger",n:"برجر لحم دبل",d:"دبل قطعة لحم بقري مع جبنة وصوص",p:100,best:1},
  {c:"burger",n:"برجر فراخ وسط",d:"برجر فراخ مقرمش وسط",p:60},
  {c:"burger",n:"برجر كلاسيك",d:"برجر لحم مع بطاطس وصوص",p:70},
  {c:"meal",n:"وجبة ١ — وجبة فراخ",d:"ربع فرخة + رز + سلطة + طحينة + عيش",p:100,best:1},
  {c:"meal",n:"وجبة ٢ — وجبة كفتة",d:"ربع كفتة + رز + سلطة + طحينة + عيش",p:120},
  {c:"meal",n:"وجبة ٢ — وجبة ميكس",d:"ربع فرخة + ثمن كفتة + رز + سلطة + طحينة + عيش",p:160},
  {c:"meal",n:"وجبة فراخ متكاملة",d:"ربع فرخة + رز + ملوخية + خضار + سلطة + طحينة + عيش",p:150},
  {c:"meal",n:"وجبة كفتة متكاملة",d:"ربع كفتة + رز + ملوخية + خضار + سلطة + طحينة + عيش",p:160},
  {c:"meal",n:"وجبة لحمة متكاملة",d:"ربع كيلو لحم + رز + ملوخية + خضار + سلطة + طحينة + عيش",p:180},
  {c:"tray",n:"صينية الصحاب",d:"١ كجم كفتة + ٤ قطع حواوشي + ١ كجم شيش + أرز وسلطات",p:999,best:1},
  {c:"tray",n:"صينية المعلم",d:"فرخة مشوية كاملة + نصف كفتة + نصف طرب + نصف ممبار",p:999},
  {c:"tray",n:"صينية المشويات المشكلة — صغير",d:"نصف فرخة + ربع كفتة + ربع طرب + ربع ممبار — مع رز وسلطة",p:399},
  {c:"tray",n:"صينية العيلة",d:"١.٥ فرخة + ١ كجم كفتة + نصف ممبار — مع رز وسلطة",p:999},
  {c:"tray",n:"صينية المشويات المشكلة — وسط",d:"نصف فرخة + نصف كفتة + نصف سجق بلدي + نصف طرب — مع رز وسلطة",p:499},
  {c:"tray",n:"صينية المشويات المشكلة — كبير",d:"فرخة كاملة + ١ كجم كفتة + نصف ممبار — مع رز وسلطة",p:799},
  {c:"tray",n:"صينية القرمشة — صغير",d:"٣ قطع بروستد + ٣ قطع استربس + رز بسمتي + بطاطس + عيش وصوص",p:299},
  {c:"tray",n:"صينية القرمشة — وسط",d:"٥ قطع بروستد + ٥ قطع استربس + رز بسمتي + بطاطس + عيش وصوص",p:450},
  {c:"tray",n:"صينية القرمشة — كبير",d:"١٠ قطع بروستد + ١٠ قطع استربس + رز بسمتي + بطاطس + عيش وصوص",p:799}
 ],
 offers:[
  {t:"عرض البروست",d:"وجبة ٤ قطع بروستد مقرمشة بخصم ٣٠ جنيه",p:170,old:200,e:"🍗"},
  {t:"عرض الصواني",d:"صينية المشويات المشكلة وسط بـ ٤٤٩ جنيه بدل ٤٩٩",p:449,old:499,e:"🍢"},
  {t:"عرض الكريب",d:"كريب شاورما فراخ كبير بـ ٨٥ جنيه بدل ١٠٠",p:85,old:100,e:"🌯"}
 ]
};
/* ===== الكود ===== */
const $=s=>document.querySelector(s),money=n=>n+" "+DATA.currency;
const catMap=Object.fromEntries(DATA.categories.map(c=>[c.id,c]));
DATA.items.forEach((x,i)=>x.id="i"+i);
DATA.offers.forEach((x,i)=>{x.id="o"+i;x.n=x.t});
let cart={},cat="all";
try{cart=JSON.parse(localStorage.getItem("ao_cart")||"{}")}catch(e){}
const save=()=>{try{localStorage.setItem("ao_cart",JSON.stringify(cart))}catch(e){}};
const all=()=>[...DATA.items,...DATA.offers];
const find=id=>all().find(x=>x.id==id);
const PH=()=>`<div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:var(--mut);font-size:13px;background:linear-gradient(90deg,#0f0b0a 60%,#1a1411 60%)"><span style="color:#b8962e">${ic('flame',34)}</span>صورة قريباً</div>`;
const pic=(o,fb)=>o.img?`<img src="${o.img}" alt="" style="width:100%;height:100%;object-fit:cover">`:PH();
const SVG='<svg viewBox="0 0 64 64" width="38" height="38"><path d="M32 6c4 8 12 12 12 22a12 12 0 0 1-24 0c0-6 4-8 5-14 3 3 4 5 5 7 2-4 2-9 2-15z" fill="#d4af37"/><path d="M14 52h36M18 46h28" stroke="#d4af37" stroke-width="3" stroke-linecap="round"/></svg>';
function setLogo(){let l="";try{l=localStorage.getItem("ao_logo")||""}catch(e){}l=l||DATA.logo;$("#logoBox").innerHTML=l?`<img src="${l}" alt="logo">`:SVG}
$("#logoFile").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{localStorage.setItem("ao_logo",r.result)}catch(x){}setLogo()};r.readAsDataURL(f)};
function resetLogo(){try{localStorage.removeItem("ao_logo")}catch(e){}setLogo()}
$("#adminBtn").onclick=()=>$("#adminModal").classList.add("on");
const wa=t=>`https://wa.me/${DATA.whatsapp}${t?"?text="+encodeURIComponent(t):""}`;
function init(){
 setLogo();
 $("#phoneTxt").textContent=$("#phone2").textContent=DATA.phone;
 $("#addrTxt").textContent=$("#addr2").textContent=$("#addr3").textContent=DATA.address;
 ["#telCard","#telBtn","#tel2"].forEach(s=>$(s).href="tel:"+DATA.phone);
 ["#waHero","#waBtn","#wa3"].forEach(s=>$(s).href=wa("أهلاً، عايز أطلب من مطعم "+DATA.name));
 $("#homeCats").innerHTML=DATA.categories.map(c=>`<div class="cat" onclick="go('menu','${c.id}')"><div class="im" style="background:#120a06 url(${catPic(c.id)}) center/cover"></div><span>${c.name}</span></div>`).join("");
 $("#offers").innerHTML=DATA.offers.map(o=>`<div class="offer"><div class="img">${pic(o,o.e)}</div><div class="bd"><div class="off">☆ عرض خاص</div><h3 class="ar" style="margin:4px 0;font-size:22px">${o.t}</h3><div class="sub">${o.d}</div><div class="row"><div><span class="old">${money(o.old)}</span><span class="price">${money(o.p)}</span></div><button class="add" onclick="add('${o.id}')">${ic("plus",24)}</button></div></div></div>`).join("");
 $("#best").innerHTML=DATA.items.filter(x=>x.best&&DATA.categories.some(c=>c.id==x.c)).map(card).join("");
 $("#chips").innerHTML=`<button class="chip on" data-c="all" onclick="pick('all')">كل الأقسام</button>`+DATA.categories.map(c=>`<button class="chip" data-c="${c.id}" onclick="pick('${c.id}')">${c.name}</button>`).join("");
 renderMenu();renderCart();
}
function card(x){return `<div class="item" style="cursor:pointer" onclick="openItem('${x.id}')"><div class="img">${x.best?'<span class="badge">${ic("flame",14)} الأكثر مبيعاً</span>':''}${pic(x,x.e)}</div><div class="bd"><h3>${x.n}</h3><p>${x.d}</p><div class="row"><span class="price">${x.from?"من ":""}${money(x.p)}</span><button class="add" onclick="add('${x.id}')">${ic("plus",24)}</button></div></div></div>`}
function pick(c){cat=c;document.querySelectorAll(".chip").forEach(b=>b.classList.toggle("on",b.dataset.c==c));renderMenu();scrollTo({top:0})}
function renderMenu(){
 const q=$("#q").value.trim();let h="";
 DATA.categories.filter(c=>cat=="all"||c.id==cat).forEach(c=>{
  const its=DATA.items.filter(x=>x.c==c.id&&(!q||(x.n+x.d).includes(q)));
  if(its.length)h+=`<div style="margin-top:22px"><h2>${c.name}</h2><div class="sub" style="display:flex;justify-content:space-between"><span>${c.desc}</span><span>${its.length} صنف</span></div><div class="grid">${its.map(card).join("")}</div></div>`});
 $("#menuBody").innerHTML=h||'<div class="empty">مفيش نتائج</div>'}
function add(id){cart[id]=(cart[id]||0)+1;save();renderCart();const b=$("#cnt");b.parentElement.style.transform="scale(1.15)";setTimeout(()=>b.parentElement.style.transform="",150)}
function chg(id,d){cart[id]=(cart[id]||0)+d;if(cart[id]<=0)delete cart[id];save();renderCart()}
function totals(){const s=Object.entries(cart).reduce((a,[id,q])=>a+find(id).p*q,0);return{s,f:s?DATA.deliveryFee:0}}
function renderCart(){
 const n=Object.values(cart).reduce((a,b)=>a+b,0);$("#cnt").textContent=n;
 const ids=Object.keys(cart).filter(id=>find(id));
 if(!ids.length){$("#cartBody").innerHTML=`<div style="text-align:center;padding:70px 20px"><div style="width:160px;height:160px;margin:auto;border-radius:50%;border:1px solid #4a3d14;background:#17120a;color:var(--gold);display:grid;place-items:center">${ic('bag',56)}</div><h2 style="border:0;font-size:26px;margin-top:30px">السلة فاضية</h2><p class="sub" style="font-size:17px;line-height:1.9">اختار أكلتك المفضلة من المنيو وأضفها للسلة، وهنوصلها لحد باب البيت.</p><a class="btn gold" style="margin-top:20px" onclick="go('menu')">اتفرج على المنيو</a></div>`;return}
 const t=totals();
 $("#cartBody").innerHTML=ids.map(id=>{const x=find(id);return `<div class="ci"><div class="th">${x.img?`<img src="${x.img}" style="width:100%;height:100%;object-fit:cover">`:ic("flame",24)}</div><div class="nm"><div style="font-weight:700">${x.n}</div><small>${money(x.p*cart[id])}</small></div><div class="q"><button onclick="chg('${id}',1)">${ic("plus",24)}</button><b>${cart[id]}</b><button onclick="chg('${id}',-1)">−</button></div></div>`}).join("")+
 `<div class="sum"><div><span>المجموع</span><span>${money(t.s)}</span></div><div id="feeRow"><span>رسوم التوصيل</span><span id="fee">${money(t.f)}</span></div><div class="tot"><span>الإجمالي</span><span id="grand">${money(t.s+t.f)}</span></div></div>
 <form onsubmit="send(event)"><input name="name" placeholder="الاسم" required><input name="phone" type="tel" placeholder="رقم الهاتف" required>
 <div class="seg"><label><input type="radio" name="type" value="توصيل" checked onchange="upd()">🛵 توصيل</label><label><input type="radio" name="type" value="استلام من المطعم" onchange="upd()">🏪 استلام</label></div>
 <input name="addr" placeholder="العنوان بالتفصيل" required><textarea name="notes" rows="3" placeholder="ملاحظات الطلب"></textarea>
 <button class="btn wa" style="width:100%;justify-content:center;margin-top:14px"><span data-i="chat" data-s="20"></span> إرسال الطلب عبر واتساب</button></form>`}
function upd(){const f=document.forms[0],del=f.type.value=="توصيل",t=totals(),fee=del?t.f:0;$("#fee").textContent=money(fee);$("#grand").textContent=money(t.s+fee);f.addr.required=del;f.addr.style.display=del?"":"none"}
function send(e){e.preventDefault();const f=e.target,del=f.type.value=="توصيل",t=totals(),fee=del?t.f:0;
 let m=`*طلب جديد - ${DATA.name}*\n\n👤 الاسم: ${f.name.value}\n📞 الهاتف: ${f.phone.value}\n🛵 نوع الطلب: ${f.type.value}\n`;
 if(del)m+=`📍 العنوان: ${f.addr.value}\n`;
 m+=`\n*الأصناف:*\n`+Object.entries(cart).map(([id,q])=>{const x=find(id);return `• ${x.n} × ${q} = ${money(x.p*q)}`}).join("\n");
 m+=`\n\nالمجموع: ${money(t.s)}\nالتوصيل: ${money(fee)}\n*الإجمالي: ${money(t.s+fee)}*`;
 if(f.notes.value)m+=`\n\n📝 ملاحظات: ${f.notes.value}`;
 window.open(wa(m),"_blank")}
function cartBtn(){Object.keys(cart).length?go('cart'):go('menu')}
function go(v,c){document.querySelectorAll(".view").forEach(x=>x.classList.toggle("on",x.id==v));document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.v==v));if(c)pick(c);else scrollTo({top:0})}
const SH="اطلب من مطعم ابو عمر الكندي أونلاين";
async function share(){const u=ST.share||location.href;if(navigator.share){try{await navigator.share({title:SH,text:SH,url:u});return}catch(e){if(e&&e.name=="AbortError")return}}shareSheet()}
function shareSheet(){const u=ST.share||location.href,t=encodeURIComponent(SH),e=encodeURIComponent(u);$("#shUrl").textContent=u.replace(/^https?:\/\//,"");$("#shLogo").src=lg();$("#sh1").href="https://wa.me/?text="+t+"%0A"+e;$("#sh2").href="https://t.me/share/url?url="+e+"&text="+t;$("#sh3").href="sms:?&body="+t+"%20"+e;$("#sh4").href="mailto:?subject="+t+"&body="+e;$("#shSheet").classList.add("on")}
function cpy(){try{navigator.clipboard.writeText(ST.share||location.href)}catch(e){}$("#cpT").textContent="تم النسخ ✓"}
function more(){try{navigator.share({title:SH,text:SH,url:ST.share||location.href})}catch(e){}}
const PUB=null;/*PUBEND*/
const ICON={"bag": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z\"/><path d=\"M3 6h18\"/><path d=\"M16 10a4 4 0 0 1-8 0\"/></svg>", "shield": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z\"/><path d=\"m9 12 2 2 4-4\"/></svg>", "home": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8\"/><path d=\"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/></svg>", "menu": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8\"/><path d=\"M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7\"/><path d=\"m2.1 21.8 6.4-6.3\"/><path d=\"m19 5-7 7\"/></svg>", "phone": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M13 2a9 9 0 0 1 9 9\"/><path d=\"M13 6a5 5 0 0 1 5 5\"/><path d=\"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z\"/></svg>", "flame": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z\"/></svg>", "chat": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M7.9 20A9 9 0 1 0 4 16.1L2 22Z\"/></svg>", "pin": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z\"/><circle cx=\"12\" cy=\"10\" r=\"3\"/></svg>", "left": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"m12 19-7-7 7-7\"/><path d=\"M19 12H5\"/></svg>", "share": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"18\" cy=\"5\" r=\"3\"/><circle cx=\"6\" cy=\"12\" r=\"3\"/><circle cx=\"18\" cy=\"19\" r=\"3\"/><path d=\"m8.59 13.51 6.83 3.98M15.41 6.51l-6.82 3.98\"/></svg>", "search": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"11\" cy=\"11\" r=\"8\"/><path d=\"m21 21-4.3-4.3\"/></svg>", "plus": "<svg viewBox=\"0 0 24 24\" width=\"${s}\" height=\"${s}\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M5 12h14\"/><path d=\"M12 5v14\"/></svg>"};const ic=(n,s=22)=>ICON[n].replace(/\$\{s\}/g,s);
const IMG={"كريب بطاطس": "images/img01.jpg", "كريب بانيه ناجتس بالبطاطس": "images/img02.jpg", "كريب شاورما فراخ": "images/img03.jpg", "كريب شيش طاووق": "images/img04.jpg", "كريب برجر": "images/img05.jpg", "كريب لحمة مفرومة": "images/img06.jpg", "سندوتش كبدة": "images/img07.jpg", "سندوتش سجق": "images/img08.jpg", "سندوتش بطاطس": "images/img09.jpg", "سندوتش كفتة داود": "images/img10.jpg", "سندوتش ناجتس": "images/img11.jpg", "سندوتش شاورما فراخ أو شيش طاووق أو فاهيتا أو استربس": "images/img12.jpg", "حواوشي مخصوص": "images/img13.jpg", "حواوشي لحم بلدي": "images/img14.jpg", "حواوشي جبنة": "images/img15.jpg", "حواوشي سجق": "images/img16.jpg", "حص فرخة تكا": "images/img17.jpg", "حص فرخة شيش": "images/img18.jpg", "حص كيلو شيش طاووق": "images/img19.jpg", "حص كيلو سجق بلدي مشوي": "images/img20.jpg", "حص كيلو كفتة كندوز": "images/img21.jpg", "حص كيلو كفتة ضاني": "images/img22.jpg", "وجبة ٣ قطع بروست": "images/img23.jpg", "وجبة ١ — وجبة فراخ": "images/img24.jpg", "برجر لحم دبل": "images/img25.jpg", "صينية الصحاب": "images/img26.jpg", "صينية المشويات المشكلة": "images/img27.jpg", "عرض البروست": "images/img28.jpg", "عرض الصواني": "images/img27.jpg", "عرض الكريب": "images/img29.jpg", "cat:side": "images/img30.jpg", "hero": "images/img31.jpg", "logo": "images/img32.jpg", "وجبة ٤ قطع بروست": "images/img23.jpg", "برجر لحم": "images/img25.jpg"};
const EX={"clock": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 6v6l4 2\"/>", "send": "<path d=\"m22 2-7 20-4-9-9-4Z\"/><path d=\"M22 2 11 13\"/>", "mail": "<rect width=\"20\" height=\"16\" x=\"2\" y=\"4\" rx=\"2\"/><path d=\"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7\"/>", "copy": "<rect width=\"14\" height=\"14\" x=\"8\" y=\"8\" rx=\"2\"/><path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\"/>", "dots": "<circle cx=\"12\" cy=\"12\" r=\"1.5\"/><circle cx=\"19\" cy=\"12\" r=\"1.5\"/><circle cx=\"5\" cy=\"12\" r=\"1.5\"/>"};for(const k in EX)ICON[k]='<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">'+EX[k]+'</svg>';
Object.assign(IMG,{"حص كيلو ممبار": "images/img33.jpg", "طبق رز أبيض بالشعرية": "images/img34.jpg", "طبق رز أبيض بالشعرية بالكبدة": "images/img35.jpg", "طبق رز بسمتي": "images/img36.jpg", "طبق رز بسمتي بالكبدة": "images/img37.jpg", "خضار اليوم": "images/img38.jpg", "طبق بطاطس بوم فريت": "images/img39.jpg", "برجر لحم سادة": "images/img40.jpg", "برجر لحم بيض أو جبنة": "images/img41.jpg", "برجر فراخ وسط": "images/img42.jpg", "برجر كلاسيك": "images/img43.jpg", "وجبة ٢ — وجبة كفتة": "images/img44.jpg", "وجبة فراخ متكاملة": "images/img45.jpg", "وجبة ٢ — وجبة ميكس": "images/img46.jpg", "وجبة كفتة متكاملة": "images/img47.jpg", "وجبة لحمة متكاملة": "images/img48.jpg", "وجبة ١ قطعة بروست": "images/img49.jpg", "وجبة ٢ قطعة بروست": "images/img50.jpg", "صينية المعلم": "images/img51.jpg", "صينية المشويات المشكلة — صغير": "images/img52.jpg", "صينية العيلة": "images/img53.jpg", "صينية المشويات المشكلة — وسط": "images/img54.jpg", "صينية المشويات المشكلة — كبير": "images/img55.jpg", "صينية القرمشة — صغير": "images/img56.jpg", "صينية القرمشة — وسط": "images/img57.jpg"});delete IMG['وجبة ٤ قطع بروست'];delete IMG['برجر لحم'];delete IMG['صينية المشويات المشكلة'];
$('#wanum').textContent=DATA.whatsapp;
DATA.logo=IMG.logo;if(PUB&&PUB.logo)DATA.logo=PUB.logo;DATA.items.forEach(x=>{if(IMG[x.n])x.img=IMG[x.n]});DATA.offers.forEach(x=>{if(IMG[x.t])x.img=IMG[x.t]});
const CP={crepe:'كريب شاورما فراخ',sand:'سندوتش كبدة',hawa:'حواوشي مخصوص',grill:'حص كيلو شيش طاووق',broast:'وجبة ٣ قطع بروست',meal:'وجبة ١ — وجبة فراخ',burger:'برجر لحم دبل',tray:'صينية الصحاب'};const catPic=id=>id=='side'?IMG['cat:side']:IMG[CP[id]]||(DATA.items.find(x=>x.c==id&&x.img)||{}).img||'';
document.querySelector('.hero').style.background='linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.88) 88%),url('+IMG.hero+') center top/cover';
document.querySelectorAll('[data-i]').forEach(e=>e.innerHTML=ic(e.dataset.i,+e.dataset.s||22));
const EX2={"x": "<path d=\"M18 6 6 18\"/><path d=\"m6 6 12 12\"/>", "trash": "<path d=\"M3 6h18\"/><path d=\"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6\"/><path d=\"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2\"/>", "truck": "<path d=\"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2\"/><path d=\"M15 18H9\"/><path d=\"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14\"/><circle cx=\"17\" cy=\"18\" r=\"2\"/><circle cx=\"7\" cy=\"18\" r=\"2\"/>", "store": "<path d=\"m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7\"/><path d=\"M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8\"/><path d=\"M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4\"/><path d=\"M2 7h20\"/>", "cash": "<rect width=\"20\" height=\"12\" x=\"2\" y=\"6\" rx=\"2\"/><circle cx=\"12\" cy=\"12\" r=\"2\"/><path d=\"M6 12h.01M18 12h.01\"/>", "wallet": "<path d=\"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1\"/><path d=\"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4\"/>"};for(const k in EX2)ICON[k]=ICON.bag.replace(/<path.*<\/svg>/,EX2[k]+'</svg>');

DATA.items.forEach(x=>{if(x.from&&!x.v)x.v=x.c=='sand'?[["بلدي",x.p],["فرنساوي",x.p*2]]:[["عادي",x.p],["كبير",x.p+20]]});
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
cart=[];try{cart=JSON.parse(localStorage.getItem("ao_cart2")||"[]")}catch(e){}
if(!Array.isArray(cart))cart=[];cart=cart.filter(l=>find(l.id));
const sv=()=>{try{localStorage.setItem("ao_cart2",JSON.stringify(cart))}catch(e){}};
const price=(x,vi)=>x.v?x.v[vi||0][1]:x.p,lprice=l=>price(find(l.id),l.vi)*l.q,sub=()=>cart.reduce((a,l)=>a+lprice(l),0);
const lname=l=>{const x=find(l.id);return x.n+(x.v?" ("+x.v[l.vi][0]+")":"")};
const F={dt:"delivery",pay:"cash",name:"",phone:"",addr:"",notes:"",tid:"",paid:false};
let M=null;const cur=DATA.currency;
function toast(t){const e=$("#toast");e.textContent=t;e.style.display="block";setTimeout(()=>e.style.display="none",1800)}
function add(id){openItem(id)}
function openItem(id){M={id,vi:0,q:1,note:""};drawM();$("#itemModal").classList.add("on")}
function closeM(){$("#itemModal").classList.remove("on")}
function mq(d){M.q=Math.max(1,M.q+d);drawM()}
function drawM(){const x=find(M.id);
 $("#itemBox").innerHTML=`<div class="mimg"><button class="x" onclick="closeM()">${ic("x",24)}</button>${pic(x)}</div><div class="mbd"><h3 class="mt">${x.n}</h3><p class="sub" style="margin:0">${x.d}</p>`+
 (x.v?`<div class="mh">اختر الحجم / النوع</div><div class="chips" style="flex-wrap:wrap">${x.v.map((o,i)=>`<button class="chip ${i==M.vi?"on":""}" onclick="M.vi=${i};drawM()">${o[0]} · ${o[1]} ${cur}</button>`).join("")}</div>`:"")+
 `<div class="mh">ملاحظات على الصنف (اختياري)</div><input class="fi" placeholder="مثال: بدون بصل، صوص زيادة..." value="${esc(M.note)}" oninput="M.note=this.value">
 <div class="qrow"><div class="q"><button onclick="mq(-1)">−</button><b>${M.q}</b><button onclick="mq(1)">+</button></div><span class="price" style="font-size:22px">${price(x,M.vi)*M.q} ${cur}</span></div>
 <button class="btn gold" style="width:100%;justify-content:center" onclick="addM()">أضف إلى السلة</button></div>`}
function addM(){const n=M.note.trim(),l=cart.find(l=>l.id==M.id&&l.vi==M.vi&&l.note==n);if(l)l.q+=M.q;else cart.push({id:M.id,vi:M.vi,note:n,q:M.q});sv();renderCart();closeM();toast("تمت الإضافة للسلة ✓")}
function lq(i,d){cart[i].q+=d;if(cart[i].q<=0)cart.splice(i,1);sv();renderCart();if($("#checkout").classList.contains("on")){cart.length?renderCheckout():go("cart")}}
function clr(){cart=[];sv();renderCart()}
function cartBtn(){cart.length?go("cart"):go("menu")}
function renderCart(){
 const n=cart.reduce((a,l)=>a+l.q,0);$("#cnt").textContent=n;const nb=$("#nb");nb.textContent=n;nb.style.display=n?"grid":"none";
 if(!n){$("#cartBody").innerHTML=`<div style="text-align:center;padding:70px 20px"><div style="width:160px;height:160px;margin:auto;border-radius:50%;border:1px solid #4a3d14;background:#17120a;color:var(--gold);display:grid;place-items:center">${ic("bag",56)}</div><h2 style="border:0;font-size:26px;margin-top:30px">السلة فاضية</h2><p class="sub" style="font-size:17px;line-height:1.9">اختار أكلتك المفضلة من المنيو وأضفها للسلة، وهنوصلها لحد باب البيت.</p><a class="btn gold" style="margin-top:20px" onclick="go('menu')">اتفرج على المنيو</a></div>`;return}
 const s=sub(),f=DATA.deliveryFee;
 $("#cartBody").innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px"><h2 style="border:0;font-size:28px;padding:0">سلة الطلب</h2><a class="sub" style="cursor:pointer" onclick="clr()">تفريغ السلة</a></div>`+
 cart.map((l,i)=>{const x=find(l.id);return `<div class="ci2"><div class="th2">${pic(x)}</div><div class="nm"><b class="ar" style="font-size:21px">${x.n}</b>${x.v?`<span class="gt">${x.v[l.vi][0]}</span>`:""}${l.note?`<span class="sub" style="margin:0">${esc(l.note)}</span>`:""}<div class="row2"><div class="q"><button onclick="lq(${i},-1)">−</button><b>${l.q}</b><button onclick="lq(${i},1)">+</button></div><span class="price" style="font-size:20px">${lprice(l)} ${cur}</span></div></div><button class="tr" onclick="lq(${i},-99)">${ic("trash",22)}</button></div>`}).join("")+
 `<div class="card2" style="border-radius:28px"><h3>ملخص الطلب</h3><div class="sr"><span>إجمالي الأصناف</span><b>${s} ${cur}</b></div><div class="sr"><span>رسوم التوصيل</span><b>${f} ${cur}</b></div><div class="sr t"><span>الإجمالي المتوقع</span><b>${s+f} ${cur}</b></div>
 <a class="btn gold" style="width:100%;justify-content:center;margin-top:16px" onclick="go('checkout')">متابعة الطلب</a><a class="btn dark" style="width:100%;justify-content:center;margin-top:12px" onclick="go('menu')">أضف أصناف تانية</a>
 <p class="sub" style="line-height:1.9;margin-top:16px">رسوم التوصيل تُحسب على الأوردر داخل المطعم، والدفع كاش أو محفظة إلكترونية (حسب المتاح في صفحة الدفع).</p></div>`}
const payName={cash:"كاش عند الاستلام",vodafone:"فودافون كاش",etisalat:"اتصالات كاش"};
const total=()=>sub()+(F.dt=="delivery"?DATA.deliveryFee:0);
function msg(){const w=F.pay!="cash";
 if(F.name.trim().split(/\s+/).length<2)return "اكتب اسمك بالكامل من فضلك.";
 if(!/^01[0-9]{9}$/.test(F.phone.trim()))return "اكتب رقم موبايل صحيح (١١ رقم يبدأ بـ 01).";
 if(F.dt=="delivery"&&F.addr.trim().length<8)return "اكتب العنوان بالتفصيل من فضلك.";
 if(w&&!F.paid)return "علّم إنك حوّلت المبلغ الأول.";return ""}
function updErr(){const m=msg(),e=$("#err");if(e){e.style.display=m?"block":"none";e.textContent=m}}
function setDt(k){F.dt=k;renderCheckout()}function setPay(k){F.pay=k;F.paid=false;renderCheckout()}
function cpNum(b){try{navigator.clipboard.writeText(DATA.wallets[F.pay])}catch(e){}b.lastChild.textContent="تم النسخ"}
function renderCheckout(){
 if(!cart.length){$("#coBody").innerHTML="";return}
 if(F.pay!="cash"&&!DATA.walOn[F.pay])F.pay="cash";
 const s=sub(),del=F.dt=="delivery",f=del?DATA.deliveryFee:0,t=s+f,w=F.pay!="cash";
 const o=(k,i,tx,c,fn)=>`<button type="button" class="opt ${c==k?"on":""}" onclick="${fn}('${k}')">${tx}${ic(i,22)}</button>`;
 $("#coBody").innerHTML=`<h2 style="border:0;font-size:28px;margin-top:8px;padding:0">إتمام الطلب</h2><p class="sub" style="margin:4px 0 0">املأ بياناتك وهنحوّل الطلب على واتساب المطعم مباشرة.</p>
 <div class="card2"><h3>طريقة الاستلام</h3><div style="display:flex;gap:12px">${o("delivery","truck","توصيل للمنزل",F.dt,"setDt")}${o("pickup","store","استلام من المطعم",F.dt,"setDt")}</div></div>
 <div class="card2"><h3>بياناتك</h3><label class="mh" style="margin-top:0;display:block">الاسم بالكامل</label><input class="fi" placeholder="مثال: أحمد محمود" value="${esc(F.name)}" oninput="F.name=this.value;updErr()">
 <label class="mh" style="display:block">رقم الموبايل</label><input class="fi" type="tel" inputmode="tel" placeholder="01XXXXXXXXX" value="${esc(F.phone)}" oninput="F.phone=this.value;updErr()">
 ${del?`<label class="mh" style="display:block">العنوان بالتفصيل</label><textarea class="fi" rows="3" placeholder="الشارع، رقم العمارة، الدور، علامة مميزة" oninput="F.addr=this.value;updErr()">${esc(F.addr)}</textarea>`:""}</div>
 <div class="card2"><h3>طريقة الدفع</h3><div style="display:flex;flex-direction:column;gap:12px">${o("cash","cash",payName.cash,F.pay,"setPay")}${DATA.walOn.vodafone?o("vodafone","wallet",payName.vodafone,F.pay,"setPay"):""}${DATA.walOn.etisalat?o("etisalat","wallet",payName.etisalat,F.pay,"setPay"):""}</div>
 ${w?`<div class="wp"><div style="display:flex;justify-content:space-between;align-items:center"><b class="ar" style="font-size:22px;color:var(--gold);display:flex;gap:8px;align-items:center">${payName[F.pay]} ${ic("wallet",22)}</b><span class="chip on" style="padding:4px 14px;font-size:14px">تحويل فوري</span></div>
 <p style="color:var(--mut);margin:14px 0 0">حوّل المبلغ على رقم المطعم ده:</p><div class="numbox"><span>${DATA.wallets[F.pay]}</span><button type="button" class="cpb" onclick="cpNum(this)">${ic("copy",18)}<span>نسخ الرقم</span></button></div>
 <div class="amt"><span>المبلغ المطلوب تحويله</span><b class="price" style="font-size:24px">${t} ${cur}</b></div>
 <div class="steps"><p>1. افتح تطبيق ${payName[F.pay]} من موبايلك.</p><p>2. اختار «تحويل» واكتب رقم المطعم اللي فوق.</p><p>3. اكتب المبلغ ${t} ${cur} بالظبط وأكّد التحويل.</p><p>4. بعد التحويل اكتب رقم العملية (Transaction ID) تحت.</p><p>5. علّم إنك حوّلت واضغط تأكيد الطلب — المطعم هيراجع التحويل ويأكد الطلب.</p></div>
 <label class="mh" style="display:block;margin-top:0">رقم عملية التحويل (اختياري لكن يسرّع التأكيد)</label><input class="fi" dir="ltr" placeholder="Transaction ID" value="${esc(F.tid)}" oninput="F.tid=this.value">
 <label class="chk"><input type="checkbox" ${F.paid?"checked":""} onchange="F.paid=this.checked;updErr()"><div><b>تم تحويل المبلغ فعلاً</b><div class="sub" style="margin:0">علّمت على الخانة دي بعد ما حوّلت المبلغ.</div></div></label></div>`:`<p class="sub" style="margin:14px 0 0">هتدفع ${t} ${cur} كاش للمندوب وقت الاستلام.</p>`}</div>
 <div class="card2"><h3>ملاحظات على الطلب</h3><textarea class="fi" rows="3" placeholder="أي تفاصيل إضافية للمطبخ أو التوصيل" oninput="F.notes=this.value">${esc(F.notes)}</textarea></div>
 <div class="card2"><h3>مراجعة الطلب</h3>${cart.map(l=>`<div class="sr" style="color:var(--tx)"><span>${esc(lname(l))} × ${l.q}</span><b>${lprice(l)} ${cur}</b></div>`).join("")}<div style="border-top:1px solid var(--line);margin:8px 0"></div>
 <div class="sr"><span>إجمالي الأصناف</span><b>${s} ${cur}</b></div><div class="sr"><span>التوصيل</span><b>${del?f+" "+cur:"استلام"}</b></div><div class="sr t"><span>الإجمالي</span><b>${t} ${cur}</b></div>
 <div class="err" id="err" style="display:none"></div><button class="btn wa" style="width:100%;justify-content:center;margin-top:8px" onclick="send()">${ic("chat",22)} تأكيد الطلب على واتساب</button>
 <p class="sub" style="text-align:center;font-size:13px;margin-bottom:0">الطلب بيتبعت من رقمك على واتساب المطعم بعد ما تضغط إرسال.</p></div>`;updErr()}
function send(){const m=msg();if(m){updErr();$("#err").scrollIntoView({block:"center"});return}
 const del=F.dt=="delivery",L="--------------------";
 let t=`طلب جديد — مطعم ${DATA.name.replace("أبو","ابو")}\n${L}\nالاسم: ${F.name.trim()}\nالموبايل: ${F.phone.trim()}\nنوع الطلب: ${del?"توصيل للمنزل":"استلام من المطعم"}\n`;
 if(del)t+=`العنوان: ${F.addr.trim()}\n`;
 t+=`${L}\nالأصناف:\n`+cart.map(l=>`• ${lname(l)} × ${l.q} — ${lprice(l)} ${cur}${l.note?"\n   ملاحظة: "+l.note:""}`).join("\n");
 t+=`\n${L}\nإجمالي الأصناف: ${sub()} ${cur}\nالتوصيل: ${del?DATA.deliveryFee+" "+cur:"استلام"}\nالإجمالي: ${total()} ${cur}\nطريقة الدفع: ${payName[F.pay]}`;
 if(F.pay!="cash"){t+=`\nتم التحويل: نعم`;if(F.tid.trim())t+=`\nرقم العملية: ${F.tid.trim()}`}
 if(F.notes.trim())t+=`\n${L}\nملاحظات: ${F.notes.trim()}`;
 openWA(t)}
function go(v,c){document.querySelectorAll(".view").forEach(x=>x.classList.toggle("on",x.id==v));const nv=v=="checkout"?"cart":v;document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.v==nv));if(v=="checkout")renderCheckout();if(c)pick(c);else scrollTo({top:0})}
document.querySelectorAll("[data-i]").forEach(e=>e.innerHTML=ic(e.dataset.i,+e.dataset.s||22));
const EX3={"user": "<circle cx=\"12\" cy=\"8\" r=\"5\"/><path d=\"M20 21a8 8 0 0 0-16 0\"/>", "lock": "<rect width=\"18\" height=\"11\" x=\"3\" y=\"11\" rx=\"2\"/><path d=\"M7 11V7a5 5 0 0 1 10 0v4\"/>", "check": "<path d=\"M20 6 9 17l-5-5\"/>", "logout": "<path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"/><path d=\"m16 17 5-5-5-5\"/><path d=\"M21 12H9\"/>", "clip": "<rect width=\"8\" height=\"4\" x=\"8\" y=\"2\" rx=\"1\"/><path d=\"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2\"/><path d=\"M12 11h4M12 16h4M8 11h.01M8 16h.01\"/>", "trend": "<path d=\"m22 7-8.5 8.5-5-5L2 17\"/><path d=\"M16 7h6v6\"/>", "cal": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\"/><path d=\"M16 2v4M8 2v4M3 10h18\"/>", "refresh": "<path d=\"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8\"/><path d=\"M21 3v5h-5\"/><path d=\"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16\"/><path d=\"M8 16H3v5\"/>", "uc": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><circle cx=\"12\" cy=\"10\" r=\"3\"/><path d=\"M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662\"/>", "chev": "<path d=\"m15 18-6-6 6-6\"/>"};for(const k in EX3)ICON[k]=ICON.bag.replace(/<path.*<\/svg>/,EX3[k]+'</svg>');

/* ===== لوحة الإدارة (البيانات محفوظة في متصفح الجهاز — اربطها بقاعدة بيانات لاحقاً) ===== */
const LS=(k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}};
let DB=null,DBL=false;const QT={};
const SL=(k,v)=>{try{const s=JSON.stringify(v);localStorage.setItem(k,s);if(k=="ao_sess"){localStorage.setItem("ao_sess_t",Date.now());dbPush("ao_sess_t",String(Date.now()))}dbPush(k,s);if(PUBK.includes(k))schedulePub();return true}catch(e){toast("المساحة ممتلئة — صغّر الصور");return false}};
let ACC=LS("ao_acc",null),SESS=LS("ao_sess",false),ORD=LS("ao_ord",[]),ST=LS("ao_set",PUB&&PUB.set||{});
if(ST.fee!=null)DATA.deliveryFee=+ST.fee;if(ST.wa)DATA.whatsapp=ST.wa;
const si=LS("ao_items",PUB&&PUB.items||null);if(Array.isArray(si)&&si.length)DATA.items=si;
DATA.items.forEach(x=>{x.img=x.ci||IMG[x.n]});cart=cart.filter(l=>find(l.id));
const saveItems=()=>SL("ao_items",DATA.items.map(x=>{const r={...x};delete r.img;return r}));
async function H(p){try{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode("ao|"+p));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}catch(e){return btoa(unescape(encodeURIComponent("ao|"+p)))}}
const dk=t=>{const d=new Date(t);return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")};
const dl=k=>new Date(k+"T12:00:00").toLocaleDateString("ar-EG",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
const tmf=ts=>{const d=new Date(ts);return d.toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"})+" , "+(d.getMonth()+1)+"/"+d.getDate()};
const ST_L={new:"جديد",prep:"قيد التحضير",out:"خارج للتوصيل",done:"تم التسليم",cancel:"ملغي"},ST_C={new:"#e0b84a",prep:"#e8a23a",out:"#6cc4f0",done:"#4ade9a",cancel:"#f0899a"},SRC={app:"تطبيق",phone:"تليفون",wa:"واتساب"},SRCL={app:"تطبيق المطعم",phone:"طلبات تليفون",wa:"طلبات واتساب"},SRCC={app:"#d4af37",phone:"#6cc4f0",wa:"#4ade9a"};
const otot=o=>o.items.reduce((a,i)=>a+i.q*i.p,0)+(o.dt=="delivery"?+o.fee||0:0);
const stb=s=>`<span class="stb" style="color:${ST_C[s]};border-color:${ST_C[s]}66;background:${ST_C[s]}1a">${ST_L[s]}</span>`;
const A={tab:"orders",q:"",st:"all",day:dk(Date.now()),sf:"all",tf:"all",auth:"login",step:1,code:""};
const lg=()=>{let l="";try{l=localStorage.getItem("ao_logo")||""}catch(e){}return l||DATA.logo};
const fld=(lb,id,ph,i,t="text",ex="")=>`<label class="mh" style="display:block">${lb}</label><div class="fw"><input class="fi" id="${id}" type="${t}" placeholder="${ph}" ${ex}>${ic(i,22)}</div>`;
const gb=(t,fn,i)=>`<button class="btn gold" style="width:100%;justify-content:center;margin-top:16px" onclick="${fn}">${t} ${i?ic(i,22):""}</button>`;
const lnk=(t,fn)=>`<p style="text-align:center;margin:16px 0 0"><a style="cursor:pointer;color:var(--tx);font-weight:600" onclick="${fn}">${t}</a></p>`;
const aerr=t=>{const e=$("#aerr");e.textContent=t;e.style.display="block"};
function renderAdmin(){if(!ACC)authView("reg");else if(!SESS)authView(A.auth=="reg"?"login":A.auth);else dash()}
function authView(k){A.auth=k;const er='<div class="err" id="aerr" style="display:none;margin:12px 0 0"></div>';let b="";
 if(k=="reg")b=`<div class="wp" style="text-align:center;margin:0 0 8px"><b style="color:var(--gold)">حساب مالك جديد للمطعم</b><p class="sub" style="margin:6px 0 0;line-height:1.8">الحساب ده بيبقى صاحب المطعم بكل الصلاحيات.</p></div>`+fld("اسم المطعم","r1","مطعم أبو عمر الكندي","store")+fld("اسم صاحب المطعم","r2","أبو عمر","user")+fld("البريد الإلكتروني (للدخول)","r3","owner@restaurant.com","mail","email",'dir="ltr"')+fld("رمز تفعيل المالك","r4","رمز التفعيل من صاحب المطعم","shield")+fld("كلمة المرور","r5","••••••","lock","password")+fld("تأكيد كلمة المرور","r6","••••••","lock","password")+er+gb("إنشاء الحساب والدخول","doReg()","check")+(ACC?lnk("عندي حساب بالفعل — دخول ←","authView('login')"):"");
 else if(k=="login")b=fld("البريد الإلكتروني أو اسم الدخول","l1","owner@restaurant.com","user","text",'dir="ltr"')+fld("كلمة المرور","l2","••••••","key","password")+er+gb("تسجيل الدخول","doLogin()","logout")+lnk("<span style='color:var(--gold)'>نسيت كلمة المرور؟</span>","A.step=1;authView('forgot')")+`<button class="btn dark" style="width:100%;justify-content:center;margin-top:16px;color:var(--gold);border-color:#6b5a22" onclick="authView('reg')">${ic("store",22)} إنشاء حساب مالك جديد للمطعم</button><p class="sub" style="text-align:center;line-height:1.9;margin:14px 0 0">صاحب المطعم يدخل بإيميله، والموظف باسم الدخول اللي اتعمله.</p><div style="border-top:1px solid var(--line);margin:16px 0 0"></div>`+lnk("← رجوع للمطعم","go('home')");
 else b=`<h3 class="ar" style="text-align:center;font-size:24px;margin:0">استرجاع كلمة المرور</h3>`+(A.step==1?`<p class="sub" style="text-align:center">اكتب بريد الحساب، وهنبعتلك كود من 6 أرقام تتأكد بيه إن البريد بتاعك.</p>`+fld("البريد الإلكتروني","f1","owner@restaurant.com","mail","email",'dir="ltr"')+er+gb("إرسال كود الاسترجاع","doSend()","mail"):`<div class="wp" style="text-align:center">نسخة تجريبية بدون خدمة بريد — الكود: <b style="color:var(--gold);font-size:22px">${A.code}</b></div>`+fld("كود الاسترجاع","f2","6 أرقام","shield","text",'inputmode="numeric" dir="ltr"')+fld("كلمة المرور الجديدة","f3","••••••","lock","password")+er+gb("حفظ كلمة المرور","doReset()","check"))+lnk("← رجوع لتسجيل الدخول","authView('login')");
 $("#admBody").innerHTML=`<div class="card2" style="border-radius:36px;border-color:#3a2f12;margin-top:20px"><div class="logo" style="width:130px;height:130px;margin:4px auto 12px"><img src="${lg()}" alt=""></div><h2 class="nl" style="border:0;text-align:center;font-size:28px;padding:0">لوحة إدارة المطعم</h2><div style="text-align:center;color:var(--gold);margin:6px 0 16px">أبو عمر الكندي · مشويات على الفحم</div>${b}</div>`}
const gv=i=>$("#"+i).value.trim();
async function doReg(){const r=gv("r1"),o=gv("r2"),e=gv("r3").toLowerCase(),c=gv("r4"),p=$("#r5").value;
 if(r.length<2||o.length<2)return aerr("اكتب اسم المطعم واسم صاحبه.");if(!/^\S+@\S+\.\S+$/.test(e))return aerr("اكتب بريد إلكتروني صحيح.");
 if(c!==DATA.ownerCode)return aerr("رمز تفعيل المالك غلط.");if(p.length<6)return aerr("كلمة المرور لازم تكون ٦ حروف على الأقل.");if(p!==$("#r6").value)return aerr("كلمتا المرور مش متطابقتين.");
 ACC={rest:r,owner:o,email:e,h:await H(p)};SESS=true;SL("ao_acc",ACC);SL("ao_sess",true);dash()}
async function doLogin(){const e=gv("l1").toLowerCase();if(e!==ACC.email||await H($("#l2").value)!==ACC.h)return aerr("البريد أو كلمة المرور غلط.");SESS=true;SL("ao_sess",true);dash()}
function doSend(){if(gv("f1").toLowerCase()!==ACC.email)return aerr("البريد ده مش مسجل.");A.code=String(Math.floor(100000+Math.random()*900000));A.step=2;authView("forgot")}
async function doReset(){if(gv("f2")!==A.code)return aerr("الكود غلط.");const p=$("#f3").value;if(p.length<6)return aerr("كلمة المرور لازم تكون ٦ حروف على الأقل.");ACC.h=await H(p);SL("ao_acc",ACC);A.step=1;authView("login");toast("تم تغيير كلمة المرور ✓")}
function logout(){SESS=false;SL("ao_sess",false);authView("login")}
function setTab(t){A.tab=t;dash()}
function dash(){const T=A.tab,tb=(k,i,l)=>`<button class="tb ${T==k?"on":""}" onclick="setTab('${k}')">${l} ${ic(i,20)}</button>`;
 $("#admBody").innerHTML=`<h2 class="nl" style="border:0;font-size:28px;padding:0;margin-top:18px">لوحة إدارة ${esc(ACC.rest)}</h2><p class="sub" style="margin:6px 0 14px">${esc(ACC.owner)} · صاحب المطعم — كل تعديل بيتحفظ فوراً.</p>
 <div style="display:flex;gap:12px"><button class="tb" onclick="openAcc()">حسابي ${ic("uc",22)}</button><button class="tb" onclick="logout()">خروج ${ic("logout",20)}</button></div>
 <div class="tabs">${tb("orders","clip","الطلبات")}${tb("rep","trend","تقارير المبيعات")}${tb("items","menu","الأصناف")}</div>${T=="orders"?ordersTab():T=="rep"?repTab():itemsTab()}`}
function oList(){let L=ORD.filter(o=>(A.st=="all"||o.status==A.st)&&(!A.q||(o.name+o.phone).includes(A.q))).sort((a,b)=>b.ts-a.ts);return L.length?L.map(ocard).join(""):'<div class="empty">مفيش طلبات</div>'}
const ocard=o=>`<div class="oc" onclick="openOrder('${o.id}')"><div><b class="n">${esc(o.name)}</b><small>${esc(o.phone)}</small><small><span class="chip" style="padding:2px 12px;font-size:13px;color:var(--gold);border-color:#6b5a22">${SRC[o.src]}</span> ${tmf(o.ts)}</small></div><div style="display:flex;align-items:center;gap:10px">${stb(o.status)}<b class="price" style="font-size:20px">${otot(o)} ${cur}</b>${ic("chev",18)}</div></div>`;
function ordersTab(){const cn=s=>ORD.filter(o=>s=="all"||o.status==s).length;
 return `<div style="display:flex;gap:12px;margin-top:6px"><div class="fw" style="flex:1"><input class="fi" placeholder="بحث بالاسم أو الموبايل" value="${esc(A.q)}" oninput="A.q=this.value;$('#olist').innerHTML=oList()">${ic("search",22)}</div><button class="btn gold" style="padding:12px 18px" onclick="openManual()">طلب يدوي ${ic("plus",18)}</button></div>
 <div class="chips" style="margin:14px 0 0">${["all","new","prep","out","done","cancel"].map(s=>`<button class="chip ${A.st==s?"on":""}" onclick="A.st='${s}';dash()">${s=="all"?"الكل":ST_L[s]} (${cn(s)})</button>`).join("")}</div><div id="olist">${oList()}</div>`}
function openAdm(){$("#admModal").classList.add("on")}function closeAdm(){$("#admModal").classList.remove("on")}
const xb=`<button class="eb" style="width:46px;height:46px;border-radius:50%;background:#1f1a18" onclick="closeAdm()">${ic("x",22)}</button>`;
let DAO=null;
function openOrder(id){const o=ORD.find(x=>x.id==id);if(!o)return;
 $("#admBox").innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center">${xb}<h3 class="ar" style="font-size:26px;margin:0">${esc(o.name)}</h3></div>
 <p style="margin:12px 0 4px"><a href="tel:${esc(o.phone)}" style="color:var(--gold)">${esc(o.phone)}</a> · ${SRCL[o.src]} · ${tmf(o.ts)}</p><p class="sub" style="margin:0">${o.dt=="delivery"?"توصيل — "+esc(o.addr):"استلام من المطعم"}</p>
 <div class="card2" style="margin-top:14px">${o.items.map(i=>`<div class="sr" style="color:var(--tx)"><span>${esc(i.n)} × ${i.q}</span><b>${i.q*i.p} ${cur}</b></div>`).join("")}<div class="sr"><span>التوصيل</span><b>${o.dt=="delivery"?o.fee+" "+cur:"استلام"}</b></div><div class="sr t"><span>الإجمالي</span><b>${otot(o)} ${cur}</b></div>
 <div class="sr"><span>الدفع</span><b>${payName[o.pay]||"كاش عند الاستلام"}${o.tid?" · "+esc(o.tid):""}</b></div>${o.notes?`<p class="sub">ملاحظات: ${esc(o.notes)}</p>`:""}</div>
 <div class="mh">حالة الطلب</div><div class="chips" style="flex-wrap:wrap">${Object.keys(ST_L).map(s=>`<button class="chip ${o.status==s?"on":""}" onclick="setOS('${id}','${s}')">${ST_L[s]}</button>`).join("")}</div>
 <div style="display:flex;gap:10px;margin-top:16px"><a class="btn wa" style="flex:1;justify-content:center" target="_blank" href="https://wa.me/2${o.phone.replace(/^0/,"")}">${ic("chat",20)} واتساب العميل</a><button class="btn dark" style="color:${DAO==id?"#f0899a":"var(--tx)"}" onclick="delO('${id}')">${ic("trash",20)} ${DAO==id?"تأكيد الحذف؟":"حذف"}</button></div>`;openAdm()}
function setOS(id,s){ORD.find(o=>o.id==id).status=s;SL("ao_ord",ORD);openOrder(id);dash()}
function delO(id){if(DAO!=id){DAO=id;openOrder(id);return}DAO=null;ORD=ORD.filter(o=>o.id!=id);SL("ao_ord",ORD);closeAdm();dash()}
let MO=null;
function openManual(){MO={src:"phone",name:"",phone:"",dt:"delivery",addr:"",items:[{n:"",q:1,p:""}],fee:DATA.deliveryFee,st:"new",notes:""};drawMO();openAdm()}
function moSum(){const s=MO.items.reduce((a,i)=>a+(+i.q||0)*(+i.p||0),0),d=MO.dt=="delivery",f=d?+MO.fee||0:0;$("#mo1").textContent=s+" "+cur;$("#mo2").textContent=d?f+" "+cur:"استلام";$("#mo3").textContent=s+f+" "+cur}
function moN(k,v){const x=DATA.items.find(x=>x.n==v);MO.items[k].n=v;if(x&&!MO.items[k].p)MO.items[k].p=price(x,0);drawMO()}
function moDel(k){MO.items.splice(k,1);if(!MO.items.length)MO.items.push({n:"",q:1,p:""});drawMO()}
function drawMO(){const od=(k,l,fn,c)=>`<button type="button" class="opt ${c==k?"on":""}" onclick="${fn}">${l}</button>`;
 $("#admBox").innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center">${xb}<h3 class="ar" style="font-size:26px;margin:0">تسجيل طلب يدوي</h3></div>
 <div class="mh">مصدر الطلب</div><div style="display:flex;gap:10px">${Object.keys(SRC).reverse().map(k=>od(k,SRC[k],`MO.src='${k}';drawMO()`,MO.src)).join("")}</div>
 <div class="mh">اسم العميل</div><input class="fi" value="${esc(MO.name)}" oninput="MO.name=this.value"><div class="mh">رقم الموبايل</div><input class="fi" type="tel" value="${esc(MO.phone)}" oninput="MO.phone=this.value">
 <div style="display:flex;gap:10px;margin-top:16px">${od("delivery","توصيل","MO.dt='delivery';drawMO()",MO.dt)}${od("pickup","استلام من المطعم","MO.dt='pickup';drawMO()",MO.dt)}</div>
 ${MO.dt=="delivery"?`<div class="mh">العنوان</div><textarea class="fi" rows="3" oninput="MO.addr=this.value">${esc(MO.addr)}</textarea>`:""}
 <div style="display:flex;justify-content:space-between;align-items:center"><div class="mh">أصناف الطلب</div><button class="eb" onclick="MO.items.push({n:'',q:1,p:''});drawMO()">+ صنف</button></div>
 <datalist id="dl">${DATA.items.map(x=>`<option value="${esc(x.n)}">`).join("")}</datalist>
 ${MO.items.map((i,k)=>`<div class="mor"><input class="fi" list="dl" placeholder="الصنف" value="${esc(i.n)}" onchange="moN(${k},this.value)" oninput="MO.items[${k}].n=this.value"><input class="fi" type="number" min="1" value="${i.q}" oninput="MO.items[${k}].q=this.value;moSum()"><input class="fi" type="number" placeholder="سعر" value="${i.p}" oninput="MO.items[${k}].p=this.value;moSum()"><button class="eb" onclick="moDel(${k})">${ic("trash",20)}</button></div>`).join("")}
 <div style="display:flex;gap:10px"><div style="flex:1"><div class="mh">رسوم التوصيل</div><input class="fi" type="number" value="${MO.fee}" oninput="MO.fee=this.value;moSum()"></div><div style="flex:1"><div class="mh">حالة الطلب</div><select class="fi" onchange="MO.st=this.value">${Object.keys(ST_L).map(s=>`<option value="${s}" ${MO.st==s?"selected":""}>${ST_L[s]}</option>`).join("")}</select></div></div>
 <div class="mh">ملاحظات</div><input class="fi" value="${esc(MO.notes)}" oninput="MO.notes=this.value">
 <div class="card2" style="padding:14px"><div class="sr"><span>إجمالي الأصناف</span><b id="mo1"></b></div><div class="sr"><span>التوصيل</span><b id="mo2"></b></div><div class="sr t"><span>الإجمالي</span><b id="mo3"></b></div><p class="sub" style="margin:6px 0 0">هيتسجل على تاريخ اليوم (${dk(Date.now()).split("-").reverse().join("-")}) في تقارير المبيعات.</p></div>
 <div class="err" id="aerr" style="display:none"></div>${gb("حفظ الطلب","saveMO()")}`;moSum()}
function saveMO(){const it=MO.items.filter(i=>i.n.trim()&&+i.p>0).map(i=>({n:i.n.trim(),q:Math.max(1,+i.q||1),p:+i.p}));
 if(!MO.name.trim())return aerr("اكتب اسم العميل.");if(!it.length)return aerr("أضف صنف واحد على الأقل بسعره.");
 ORD.push({id:"o"+Date.now(),ts:Date.now(),src:MO.src,name:MO.name.trim(),phone:MO.phone.trim(),dt:MO.dt,addr:MO.dt=="delivery"?MO.addr.trim():"",items:it,fee:+MO.fee||0,status:MO.st,notes:MO.notes.trim(),pay:"cash"});SL("ao_ord",ORD);closeAdm();A.tab="orders";dash();toast("تم حفظ الطلب ✓")}
const wkOf=k=>{const t=new Date(k+"T12:00:00"),j=new Date(t.getFullYear(),0,1);return t.getFullYear()+"/"+Math.ceil(((t-j)/864e5+j.getDay()+1)/7)};
function setDay(k){A.day=k||dk(Date.now());A.sf="all";A.tf="all";dash()}
function repTab(){const D=A.day,td=dk(Date.now()),L=ORD.filter(o=>dk(o.ts)==D),act=o=>o.status!="cancel",sm=f=>L.filter(f).reduce((a,o)=>a+otot(o),0),ct=f=>L.filter(f).length;
 const rev=sm(act),days={};ORD.forEach(o=>{const k=dk(o.ts);(days[k]=days[k]||[]).push(o)});const dr=k=>days[k].filter(act).reduce((a,o)=>a+otot(o),0);
 const keys=Object.keys(days).sort().reverse(),top=keys.reduce((a,k)=>Math.max(a,dr(k)),0);
 const grp=f=>{const g=ORD.filter(o=>f(dk(o.ts)));return[g.length,g.filter(act).reduce((a,o)=>a+otot(o),0)]},[wn,wr]=grp(k=>wkOf(k)==wkOf(D)),[mn,mr]=grp(k=>k.slice(0,7)==D.slice(0,7));
 const flt=L.filter(o=>(A.sf=="all"||o.src==A.sf)&&(A.tf=="all"||o.status==A.tf)).sort((a,b)=>b.ts-a.ts);
 const sc=(l,v,c="",i="")=>`<div class="sc ${c}"><small>${l} ${i}</small><b>${v}</b></div>`;
 const chp=(k,l,f,c)=>`<button class="chip ${c==k?"on":""}" onclick="A.${f}='${k}';dash()">${l}</button>`;
 return `<div class="card2" style="margin-top:6px"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0;display:flex;gap:8px;align-items:center;color:var(--gold)">${ic("cal",24)}<span style="color:var(--tx)">تقارير المبيعات اليومية</span></h3><button class="tb" style="padding:8px 14px" onclick="dash()">تحديث ${ic("refresh",18)}</button></div>
 <input type="date" class="fi" style="margin-top:14px" value="${D}" max="${td}" onchange="setDay(this.value)"><div class="chips" style="margin-top:12px;flex-wrap:wrap"><button class="chip ${D==td?"on":""}" onclick="setDay()">اليوم</button><button class="chip ${D==dk(Date.now()-864e5)?"on":""}" onclick="setDay(dk(Date.now()-864e5))">أمس</button></div>
 <p class="sub" style="line-height:1.9">${dl(D)} · كل يوم ليه أرقامه المستقلة — مبيعات الأمس مش بتتضاف على النهاردة.</p></div>
 <div class="sg">${sc("إيراد "+(D==td?"اليوم":"اليوم المختار"),rev+" "+cur,"g",ic("trend",16))}${sc("عدد الطلبات",L.length)}${sc("طلبات مكتملة",sm(o=>o.status=="done")+" "+cur)}${sc("قيد التنفيذ",sm(o=>["new","prep","out"].includes(o.status))+" "+cur)}${sc("طلبات واتساب",ct(o=>o.src=="wa"))}${sc("ملغي / مرفوض",`<span style="color:#f0899a;font-size:20px">${ct(o=>o.status=="cancel")} ملغي</span>`)}</div>
 <div class="card2"><h3>تفصيل مصادر الطلبات</h3>${Object.keys(SRC).map(s=>{const n=ct(o=>o.src==s),v=sm(o=>o.src==s&&act(o));return `<div class="card2" style="margin-top:10px;padding:14px;background:#0f0b0a"><div style="display:flex;justify-content:space-between;align-items:center"><span class="stb" style="color:${SRCC[s]};border-color:${SRCC[s]}66">${SRCL[s]}</span><b>${n} طلب · ${v} ${cur}</b></div><div class="pg"><i style="width:${rev?Math.round(v/rev*100):0}%;background:${SRCC[s]}"></i></div></div>`}).join("")}
 <p class="sub" style="margin:12px 0 0">بانتظار تحقق دفع: ${ct(o=>o.pay&&o.pay!="cash"&&o.status=="new")} طلب</p></div>
 <div class="card2"><h3>حالات طلبات اليوم المختار</h3><div class="sg">${["new","prep","out","done","cancel"].map(s=>`<div class="sc" style="text-align:center;color:${ST_C[s]};border-color:${ST_C[s]}77;background:${ST_C[s]}14"><small style="justify-content:center;color:inherit">${ST_L[s]}</small><b>${ct(o=>o.status==s)}</b><small style="justify-content:center;color:inherit">${sm(o=>o.status==s)} ${cur}</small></div>`).join("")}</div></div>
 <div class="card2"><h3>سجل المبيعات السابق</h3><p class="sub" style="margin-top:-6px">اضغط أي يوم لعرض تقريره الكامل. السجلات محفوظة ولا تُحذف مع تغيير اليوم.</p>${keys.length?keys.slice(0,30).map(k=>`<div class="hist" style="margin-top:8px;padding:12px 14px;border-radius:18px" onclick="setDay('${k}')"><span>${k.slice(5).replace("-","/")}</span><span style="flex:1">${dl(k)}</span><small style="margin:0">${days[k].length} طلب</small><b>${dr(k)} ${cur}</b>${ic("chev",16)}</div>`).join(""):'<div class="empty" style="padding:20px">لسه مفيش مبيعات</div>'}
 <div class="mh">ملخص أسبوعي</div><div class="hist" style="cursor:default;padding:12px 14px;border-radius:18px"><span>أسبوع ${wkOf(D)}</span><span>${wn} طلب</span><b class="price">${wr} ${cur}</b></div><div class="mh">ملخص شهري</div><div class="hist" style="cursor:default;padding:12px 14px;border-radius:18px"><span>${D.slice(0,7)}</span><span>${mn} طلب</span><b class="price">${mr} ${cur}</b></div></div>
 <div class="card2"><h3>${D==td?"طلبات النهاردة":"طلبات اليوم المختار"}</h3><div class="chips" style="flex-wrap:wrap">${chp("all","كل المصادر","sf",A.sf)}${Object.keys(SRC).map(s=>chp(s,SRC[s],"sf",A.sf)).join("")}</div><div class="chips" style="flex-wrap:wrap;margin-top:8px">${chp("all","كل الحالات","tf",A.tf)}${Object.keys(ST_L).map(s=>chp(s,ST_L[s],"tf",A.tf)).join("")}</div>
 ${flt.length?flt.map(ocard).join(""):'<div class="card2" style="text-align:center;color:var(--mut);background:#0f0b0a">مفيش طلبات مطابقة في اليوم ده.</div>'}<p class="sub">أعلى إيراد مسجل في يوم: ${top} ${cur}</p></div>`}
let DA=null;
function itemsTab(){const row=x=>`<div class="ir"><div class="th3">${x.img?`<img src="${x.img}" alt="">`:ic("flame",22)}</div><div class="nm"><b>${esc(x.n)}</b><small>${x.v?x.v.map(o=>o[0]+": "+o[1]).join(" · "):x.p+" "+cur}</small></div><button class="av ${x.off?"off":""}" onclick="togItem('${x.id}')">${ic(x.off?"x":"check",20)}</button><button class="eb" onclick="editItem('${x.id}')">تعديل</button><button class="eb" style="${DA==x.id?"color:#f0899a;border-color:#f0899a":""}" onclick="delItem('${x.id}')">${DA==x.id?"تأكيد؟":ic("trash",20)}</button></div>`;
 return `<button class="btn gold" style="margin:6px 0" onclick="editItem()">صنف جديد ${ic("plus",18)}</button>`+CATS.map(c=>{const L=DATA.items.filter(x=>x.c==c.id);return L.length?`<div class="ch ar">${c.name}</div>`+L.map(row).join(""):""}).join("")}
function togItem(id){const x=DATA.items.find(x=>x.id==id);x.off=!x.off;saveItems();init();dash()}
function delItem(id){if(DA!=id){DA=id;dash();setTimeout(()=>{if(DA==id){DA=null;if(A.tab=="items"&&SESS)dash()}},3000);return}DA=null;DATA.items=DATA.items.filter(x=>x.id!=id);saveItems();cart=cart.filter(l=>find(l.id));sv();init();dash()}
function readImg(f,w,cb){const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement("canvas"),s=Math.min(1,w/im.width);c.width=im.width*s;c.height=im.height*s;c.getContext("2d").drawImage(im,0,0,c.width,c.height);cb(c.toDataURL("image/jpeg",.75))};im.src=r.result};r.readAsDataURL(f)}
let EI=null;
function editItem(id){const x=id?DATA.items.find(x=>x.id==id):null;EI=x?JSON.parse(JSON.stringify({...x,img:undefined})):{id:"n"+Date.now(),c:CATS[0].id,n:"",d:"",p:"",best:0,off:0,isNew:1};EI._img=x?x.img:"";EI._x=x;drawEI();openAdm()}
function drawEI(){const e=EI;$("#admBox").innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center">${xb}<h3 class="ar" style="font-size:26px;margin:0">${e.isNew?"صنف جديد":"تعديل الصنف"}</h3></div>
 <div style="display:flex;gap:14px;align-items:center;margin-top:14px"><div class="th3" style="width:90px;height:90px">${e._img?`<img src="${e._img}" alt="">`:ic("flame",30)}</div><label class="btn dark" style="cursor:pointer">تغيير الصورة<input type="file" accept="image/*" hidden onchange="readImg(this.files[0],600,d=>{EI._img=d;EI.ci=d;drawEI()})"></label></div>
 <div class="mh">اسم الصنف</div><input class="fi" value="${esc(e.n)}" oninput="EI.n=this.value"><div class="mh">الوصف</div><input class="fi" value="${esc(e.d)}" oninput="EI.d=this.value">
 <div class="mh">القسم</div><select class="fi" onchange="EI.c=this.value">${CATS.map(c=>`<option value="${c.id}" ${e.c==c.id?"selected":""}>${c.name}</option>`).join("")}</select>
 ${e.v?`<div class="mh">الأحجام والأسعار</div>`+e.v.map((o,i)=>`<div style="display:flex;gap:8px;margin-top:8px"><input class="fi" value="${esc(o[0])}" oninput="EI.v[${i}][0]=this.value"><input class="fi" type="number" value="${o[1]}" oninput="EI.v[${i}][1]=+this.value"></div>`).join(""):`<div class="mh">السعر (${cur})</div><input class="fi" type="number" value="${e.p}" oninput="EI.p=this.value">`}
 <label class="chk"><input type="checkbox" ${e.best?"checked":""} onchange="EI.best=this.checked?1:0"><b>الأكثر مبيعاً</b></label><label class="chk"><input type="checkbox" ${e.off?"":"checked"} onchange="EI.off=this.checked?0:1"><b>متاح للطلب</b></label>
 <div class="err" id="aerr" style="display:none"></div>${gb("حفظ","saveEI()")}`}
function saveEI(){const e=EI;if(!e.n.trim())return aerr("اكتب اسم الصنف.");if(e.v){e.p=e.v[0][1]}else if(!(+e.p>0))return aerr("اكتب السعر.");
 const o={id:e.id,c:e.c,n:e.n.trim(),d:e.d.trim(),p:+e.p,best:e.best,off:e.off};if(e.v){o.v=e.v;o.from=1}
 let x=e._x;if(x){if(!e.ci&&x.img&&x.n!=o.n)o.ci=x.img;else if(e.ci)o.ci=e.ci;else if(x.ci)o.ci=x.ci;Object.keys(x).forEach(k=>delete x[k]);Object.assign(x,o)}else{if(e.ci)o.ci=e.ci;DATA.items.push(o);x=o}
 x.img=x.ci||IMG[x.n];saveItems();init();closeAdm();dash();toast("تم الحفظ ✓")}
function openAcc(){$("#admBox").innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center">${xb}<h3 class="ar" style="font-size:26px;margin:0">حسابي</h3></div><p class="sub">${esc(ACC.owner)} · ${esc(ACC.email)}</p>
 <div style="display:flex;gap:14px;align-items:center"><div class="logo" style="width:80px;height:80px"><img id="lgp" src="${lg()}" alt=""></div><label class="btn dark" style="cursor:pointer">تغيير الشعار<input type="file" accept="image/*" hidden onchange="readImg(this.files[0],400,d=>{try{localStorage.setItem('ao_logo',d);dbPush('ao_logo',d);schedulePub()}catch(e){}setLogo();$('#lgp').src=d})"></label></div>
 <div class="mh">رسوم التوصيل (${cur})</div><input class="fi" id="a1" type="number" value="${DATA.deliveryFee}"><div class="mh">رقم واتساب المطعم (بالصيغة الدولية)</div><input class="fi" id="a2" dir="ltr" value="${DATA.whatsapp}"><div class="mh">كلمة مرور جديدة (اختياري)</div><input class="fi" id="a3" type="password">
 <div class="err" id="aerr" style="display:none"></div>${gb("حفظ","saveAcc()")}`;openAdm()}
async function saveAcc(){const p=$("#a3").value;if(p&&p.length<6)return aerr("كلمة المرور لازم تكون ٦ حروف على الأقل.");if(p){ACC.h=await H(p);SL("ao_acc",ACC)}
 ST={fee:+$("#a1").value||0,wa:$("#a2").value.replace(/\D/g,"")||DATA.whatsapp};SL("ao_set",ST);DATA.deliveryFee=ST.fee;DATA.whatsapp=ST.wa;init();closeAdm();toast("تم الحفظ ✓")}
/* ربط الواجهة */
$("#adminBtn").onclick=()=>go("admin");
const _go=go;go=function(v,c){_go(v,c);if(v=="admin"){renderAdmin();document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.v=="contact"))}};
const _oi=openItem;openItem=function(id){const x=find(id);if(x&&x.off){toast("الصنف غير متاح حالياً");return}_oi(id)};
card=function(x){return `<div class="item" style="cursor:pointer;${x.off?"opacity:.55":""}" onclick="openItem('${x.id}')"><div class="img">${x.off?'<span class="badge" style="background:#444">غير متاح</span>':x.best?`<span class="badge">${ic("flame",14)} الأكثر مبيعاً</span>`:""}${pic(x,x.e)}</div><div class="bd"><h3>${x.n}</h3><p>${x.d}</p><div class="row"><span class="price">${x.from?"من ":""}${money(x.p)}</span><button class="add">${ic("plus",24)}</button></div></div></div>`};
function saveOrder(){const del=F.dt=="delivery";ORD.push({id:"o"+Date.now(),ts:Date.now(),src:"app",name:F.name.trim(),phone:F.phone.trim(),dt:F.dt,addr:del?F.addr.trim():"",items:cart.map(l=>({n:lname(l)+(l.note?" — "+l.note:""),q:l.q,p:price(find(l.id),l.vi)})),fee:DATA.deliveryFee,status:"new",notes:F.notes.trim(),pay:F.pay,tid:F.tid.trim()});SL("ao_ord",ORD)}
const _snd=send;send=function(){if(msg())return _snd();saveOrder();_snd();cart=[];sv();F.paid=false;F.notes="";F.tid="";renderCart();go("home");toast("تم تحويل طلبك لواتساب المطعم ✓")};
const EX4={"layers": "<path d=\"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z\"/><path d=\"m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65\"/><path d=\"m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65\"/>", "offer": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m9 15 6-6\"/><circle cx=\"9.5\" cy=\"9.5\" r=\".5\"/><circle cx=\"14.5\" cy=\"14.5\" r=\".5\"/>", "music": "<path d=\"M9 18V5l12-2v13\"/><circle cx=\"6\" cy=\"18\" r=\"3\"/><circle cx=\"18\" cy=\"16\" r=\"3\"/>", "cog": "<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1\"/>", "users": "<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/><path d=\"M22 21v-2a4 4 0 0 0-3-3.87\"/><path d=\"M16 3.13a4 4 0 0 1 0 7.75\"/>", "userplus": "<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/><path d=\"M19 8v6M22 11h-6\"/>", "download": "<path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><path d=\"m7 10 5 5 5-5\"/><path d=\"M12 15V3\"/>", "play": "<path d=\"M6 3 20 12 6 21Z\"/>", "vol": "<path d=\"M11 5 6 9H2v6h4l5 4V5Z\"/><path d=\"M15.5 8.5a5 5 0 0 1 0 7\"/>", "eye": "<path d=\"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>", "key": "<circle cx=\"7.5\" cy=\"15.5\" r=\"5.5\"/><path d=\"m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3\"/>", "imgp": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\"/><circle cx=\"9\" cy=\"9\" r=\"2\"/><path d=\"m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21\"/>"};for(const k in EX4)ICON[k]=ICON.bag.replace(/<path.*<\/svg>/,EX4[k]+'</svg>');

/* ===== توسعة لوحة الإدارة ===== */
if(SESS===true)SESS="owner";
let CATS=LS("ao_cats",PUB&&PUB.cats||null)||DATA.categories.map(c=>({...c})),OFFS=LS("ao_offs",PUB&&PUB.offs||null)||DATA.offers.map(o=>{const r={...o};delete r.img;delete r.e;return r}),TEAM=LS("ao_team",[]);
let WAL=LS("ao_wal",PUB&&PUB.wal||null)||{vodafone:{num:DATA.wallets.vodafone,on:true},etisalat:{num:DATA.wallets.etisalat,on:true}},MUS=LS("ao_mus",PUB&&PUB.mus||{on:true,vol:100,name:"",data:""});
const okNum=n=>/^01[0-9]{9}$/.test(n),RL={owner:"صاحب المطعم",manager:"مدير",staff:"موظف"};
function applyCats(){DATA.categories=CATS.filter(c=>!c.hide)}
function applyOffs(){DATA.offers=OFFS.filter(o=>!o.hide).map(o=>({...o,n:o.t,img:o.ci||IMG[o.t]||((DATA.items.find(x=>x.id==o.link)||{}).img)}))}
function applyWal(){DATA.walOn={};for(const k in WAL){DATA.wallets[k]=WAL[k].num;DATA.walOn[k]=!!WAL[k].on&&okNum(WAL[k].num)}}
function applySet(){if(ST.fee!=null)DATA.deliveryFee=+ST.fee;if(ST.wa)DATA.whatsapp=ST.wa;if(ST.phone)DATA.phone=ST.phone;if(ST.addr)DATA.address=ST.addr;DATA.minOrder=ST.min!=null?+ST.min:100;
 const full=ST.name||"مطعم أبو عمر الكندي";DATA.name=full.replace(/^مطعم\s*/,"");$(".hero h1").textContent="أهلاً بيك في "+full;if(ST.tag)$(".hero p").textContent=ST.tag;$("#hrs").textContent=ST.hours||"11:00 - 02:00";$("#bn").textContent=DATA.name;document.title=full}
applyCats();applyOffs();applyWal();applySet();
const saveCats=()=>{SL("ao_cats",CATS);applyCats();init()},saveOffs=()=>{SL("ao_offs",OFFS);applyOffs();init()};
const _go2=go;go=function(v,c){if(v=="checkout"&&sub()<(DATA.minOrder||0)){toast("الحد الأدنى للطلب "+DATA.minOrder+" "+cur);v="cart"}_go2(v,c)};
function fl(t,ok=1){A.fl=[t,ok];dash()}
const ALLP=["orders","menu","offers","reports","settings","team"];
const CU=()=>{if(SESS&&SESS!="owner"){const m=TEAM.find(t=>t.id==SESS);if(m)return{...m,perms:m.role=="staff"?m.perms:ALLP}}return{name:ACC.owner,email:ACC.email,user:ACC.user||ACC.email.split("@")[0],role:"owner",perms:ALLP}};
const can=p=>!p||CU().perms.includes(p);
const tg=(t,on,fn)=>`<label class="tgl"><b>${t}</b><input type="checkbox" ${on?"checked":""} onchange="${fn}"><span class="sw2"></span></label>`;
const lb=t=>`<div class="mh">${t}</div>`,inp=(v,fn,t="text",ph="",x="")=>`<input class="fi" type="${t}" placeholder="${ph}" value="${esc(v==null?"":v)}" oninput="${fn}" ${x}>`;
const box=(h2,body)=>`<div class="card2" style="border-color:#3a2f12;margin-top:6px"><h3>${h2}</h3>${body}</div>`;
const mh=(t)=>`<div style="display:flex;justify-content:space-between;align-items:center">${xb}<h3 class="ar" style="font-size:26px;margin:0">${t}</h3></div>`;
/* دخول / تسجيل */
async function codeOk(c){return ST.codeH?await H(c)==ST.codeH:c==DATA.ownerCode}
async function doReg(){const r=gv("r1"),o=gv("r2"),e=gv("r3").toLowerCase(),c=gv("r4"),p=$("#r5").value;
 if(r.length<2||o.length<2)return aerr("اكتب اسم المطعم واسم صاحبه.");if(!/^\S+@\S+\.\S+$/.test(e))return aerr("اكتب بريد إلكتروني صحيح.");
 if(ST.codeOn!==false&&!await codeOk(c))return aerr("رمز تفعيل المالك غلط.");if(p.length<6)return aerr("كلمة المرور لازم تكون ٦ حروف على الأقل.");if(p!==$("#r6").value)return aerr("كلمتا المرور مش متطابقتين.");
 const u=e.split("@")[0].replace(/[^a-z0-9]/g,"")||"owner";
 if(ACC){if(e==ACC.email||TEAM.some(t=>(t.email||"").toLowerCase()==e))return aerr("البريد ده مسجل بالفعل — سجّل دخول.");let un=u,i=1;while(un==ACC.user||TEAM.some(t=>t.user.toLowerCase()==un))un=u+(++i);
  const m={id:"u"+Date.now(),name:o,email:e,phone:"",user:un,role:"owner",perms:ALLP,h:await H(p)};TEAM.push(m);SL("ao_team",TEAM);SESS=m.id}
 else{ACC={rest:r,owner:o,email:e,user:u,h:await H(p)};SESS="owner";SL("ao_acc",ACC)}
 SL("ao_sess",SESS);A.tab="orders";dash()}
async function doLogin(){const id=gv("l1").toLowerCase(),hh=await H($("#l2").value);
 if((id==ACC.email||id==(ACC.user||ACC.email.split("@")[0]).toLowerCase())&&hh==ACC.h)SESS="owner";else{const m=TEAM.find(t=>(t.user.toLowerCase()==id||(t.email||"").toLowerCase()==id)&&t.h==hh);if(!m)return aerr("بيانات الدخول غلط.");SESS=m.id}
 SL("ao_sess",SESS);dash()}
function renderAdmin(){if(SESS&&Date.now()-(+localStorage.getItem("ao_sess_t")||0)>432e5){SESS=false;SL("ao_sess",false)}if(DBL){$("#admBody").innerHTML='<div class="empty">جاري تحميل بيانات المطعم…</div>';return}if(!ACC)authView("reg");else if(SESS&&SESS!="owner"&&!TEAM.find(t=>t.id==SESS)){SESS=false;authView("login")}else if(!SESS)authView(A.auth=="reg"?"login":A.auth);else dash()}
/* اللوحة */
const TB=[["orders","clip","الطلبات","orders"],["rep","trend","تقارير المبيعات","reports"],["items","menu","الأصناف","menu"],["cats","layers","الأقسام","menu"],["offers","offer","العروض","offers"],["wal","wallet","المحافظ الإلكترونية","settings"],["mus","music","موسيقى الترحيب","settings"],["set","cog","الإعدادات","settings"],["team","users","الفريق","team"],["acct","uc","إعدادات الحساب",null]];
function dash(){const C=CU(),al=TB.filter(t=>can(t[3]));if(!al.find(t=>t[0]==A.tab))A.tab=al[0][0];
 const F2={orders:ordersTab,rep:repTab,items:itemsTab,cats:catsTab,offers:offersTab,wal:walTab,mus:musTab,set:settingsTab,team:teamTab,acct:acctTab},f=A.fl;A.fl=null;
 $("#admBody").innerHTML=`<h2 class="nl" style="border:0;font-size:28px;padding:0;margin-top:18px">لوحة إدارة ${esc(ACC.rest)}</h2><p class="sub" style="margin:6px 0 14px">${esc(C.name)} · ${RL[C.role]} — كل تعديل بيتحفظ فوراً.</p>
 <div style="display:flex;gap:12px"><button class="tb" onclick="setTab('acct')">حسابي ${ic("uc",22)}</button><button class="tb" onclick="logout()">خروج ${ic("logout",20)}</button></div>
 <div class="tabs">${al.map(t=>`<button class="tb ${A.tab==t[0]?"on":""}" onclick="setTab('${t[0]}')">${t[2]} ${ic(t[1],20)}</button>`).join("")}</div>${f?`<div class="err ${f[1]?"ok":""}">${f[0]}</div>`:""}${F2[A.tab]()}`}
/* الأقسام */
let DC=null,EC=null;
function catsTab(){return `<button class="btn gold" style="margin:6px 0" onclick="editCat()">قسم جديد ${ic("plus",18)}</button>`+CATS.map((c,i)=>`<div class="ir"><div class="nm"><b style="font-size:18px">${esc(c.name)}</b><small>ترتيب ${i+1} · ${c.hide?"مخفي":"ظاهر"}</small></div><button class="eb" onclick="mvCat(${i},-1)">↑</button><button class="eb" onclick="mvCat(${i},1)">↓</button><button class="eb" onclick="editCat('${c.id}')">تعديل</button><button class="eb" style="${DC==c.id?"color:#f0899a;border-color:#f0899a":""}" onclick="delCat('${c.id}')">${DC==c.id?"تأكيد؟":ic("trash",20)}</button></div>`).join("")}
function mvCat(i,d){const j=i+d;if(j<0||j>=CATS.length)return;[CATS[i],CATS[j]]=[CATS[j],CATS[i]];saveCats();dash()}
function delCat(id){if(DATA.items.some(x=>x.c==id)){toast("القسم فيه أصناف — انقلها أو احذفها الأول");return}if(DC!=id){DC=id;dash();setTimeout(()=>{if(DC==id){DC=null;if(A.tab=="cats"&&SESS)dash()}},3000);return}DC=null;CATS=CATS.filter(c=>c.id!=id);saveCats();dash()}
function editCat(id){const c=CATS.find(c=>c.id==id);EC=c?{...c,pos:CATS.indexOf(c)+1}:{id:"c"+Date.now(),name:"",desc:"",hide:false,isNew:1,pos:CATS.length+1};drawEC();openAdm()}
function drawEC(){$("#admBox").innerHTML=mh(EC.isNew?"قسم جديد":"تعديل القسم")+lb("اسم القسم")+inp(EC.name,"EC.name=this.value")+lb("وصف مختصر (اختياري)")+inp(EC.desc,"EC.desc=this.value")+lb("ترتيب الظهور")+`<div style="display:flex;gap:10px;align-items:center"><div style="flex:1">${inp(EC.pos,"EC.pos=this.value","number")}</div><div style="flex:1">${tg("ظاهر للعملاء",!EC.hide,"EC.hide=!this.checked")}</div></div><div class="err" id="aerr" style="display:none"></div>`+gb("حفظ القسم","saveEC()")}
function saveEC(){if(!EC.name.trim())return aerr("اكتب اسم القسم.");const arr=CATS.filter(c=>c.id!=EC.id);arr.splice(Math.min(Math.max(1,+EC.pos||1)-1,arr.length),0,{id:EC.id,name:EC.name.trim(),desc:EC.desc.trim(),hide:!!EC.hide});CATS=arr;saveCats();closeAdm();fl("تم حفظ القسم.")}
/* العروض */
let DO=null,EO=null;
function offersTab(){return `<button class="btn gold" style="margin:6px 0" onclick="editOff()">عرض جديد ${ic("plus",18)}</button>`+OFFS.map(o=>{const im=o.ci||IMG[o.t];return `<div class="ir"><div class="th3" style="width:56px;height:56px">${im?`<img src="${im}" alt="">`:""}</div><div class="nm"><b style="font-size:18px">${esc(o.t)}</b><small>${o.p} ${cur}${o.old?" — بدل "+o.old+" "+cur:""}${o.hide?" · مخفي":""}</small></div><button class="eb" onclick="editOff('${o.id}')">تعديل</button><button class="eb" style="${DO==o.id?"color:#f0899a;border-color:#f0899a":""}" onclick="delOff('${o.id}')">${DO==o.id?"تأكيد؟":ic("trash",20)}</button></div>`}).join("")}
function delOff(id){if(DO!=id){DO=id;dash();setTimeout(()=>{if(DO==id){DO=null;if(A.tab=="offers"&&SESS)dash()}},3000);return}DO=null;OFFS=OFFS.filter(o=>o.id!=id);cart=cart.filter(l=>find(l.id));saveOffs();sv();renderCart();dash()}
function editOff(id){const o=OFFS.find(o=>o.id==id);EO=o?{...o}:{id:"o"+Date.now(),t:"",d:"",p:"",old:"",link:"",hide:false,isNew:1};drawEO();openAdm()}
function drawEO(){const im=EO.ci||IMG[EO.t];$("#admBox").innerHTML=mh(EO.isNew?"عرض جديد":"تعديل العرض")+lb("عنوان العرض")+inp(EO.t,"EO.t=this.value")+lb("وصف العرض")+`<textarea class="fi" rows="3" oninput="EO.d=this.value">${esc(EO.d)}</textarea>`+`<div style="display:flex;gap:10px"><div style="flex:1">${lb("السعر قبل الخصم")+inp(EO.old,"EO.old=this.value","number")}</div><div style="flex:1">${lb("السعر بعد الخصم")+inp(EO.p,"EO.p=this.value","number")}</div></div>`+lb("مرتبط بصنف (اختياري)")+`<select class="fi" onchange="EO.link=this.value"><option value="">بدون ربط</option>${DATA.items.map(x=>`<option value="${x.id}" ${EO.link==x.id?"selected":""}>${esc(x.n)}</option>`).join("")}</select>`+lb("صورة العرض")+`<div class="card2" style="margin:0;padding:12px;display:flex;gap:12px;align-items:center"><div class="th3" style="width:80px;height:80px">${im?`<img src="${im}" alt="">`:ic("flame",26)}</div><label class="btn dark" style="cursor:pointer">${ic("imgp",20)} رفع صورة<input type="file" accept="image/*" hidden onchange="readImg(this.files[0],600,d=>{EO.ci=d;drawEO()})"></label></div>`+tg("ظاهر في الرئيسية",!EO.hide,"EO.hide=!this.checked")+`<div class="err" id="aerr" style="display:none"></div>`+gb("حفظ العرض","saveEO()")}
function saveEO(){if(!EO.t.trim())return aerr("اكتب عنوان العرض.");if(!(+EO.p>0))return aerr("اكتب السعر بعد الخصم.");const o={id:EO.id,t:EO.t.trim(),d:EO.d.trim(),p:+EO.p,old:+EO.old||0,link:EO.link,hide:!!EO.hide};if(EO.ci)o.ci=EO.ci;else{const x=OFFS.find(z=>z.id==EO.id);if(x&&x.ci)o.ci=x.ci}
 const i=OFFS.findIndex(z=>z.id==o.id);if(i<0)OFFS.push(o);else OFFS[i]=o;saveOffs();closeAdm();fl("تم حفظ العرض.")}
/* المحافظ */
function walTab(){const card=(k,t)=>{const w=WAL[k],on=w.on&&okNum(w.num);return `<div class="card2"><div style="display:flex;justify-content:space-between;align-items:center"><b class="ar" style="font-size:22px;color:var(--gold);display:flex;gap:8px;align-items:center">${t} ${ic("wallet",22)}</b><span class="stb" style="color:${on?"#4ade9a":"#f0899a"};border-color:${on?"#1f6b52":"#6b2a30"};background:${on?"#0e1f18":"#1c0d10"}">${on?"متاحة للعملاء":"مقفولة"}</span></div>${lb("رقم استلام التحويل")}<input class="fi" id="wn_${k}" type="tel" value="${esc(w.num)}" dir="ltr">${tg("تفعيل الدفع بالمحفظة",w.on,"WAL['"+k+"'].on=this.checked")}<p class="sub" style="margin:10px 0 0;direction:rtl">الرقم المحفوظ هيبقى: ${esc(w.num)}</p>${gb("حفظ إعدادات "+t,"saveWal('"+k+"','"+t+"')")}</div>`};
 return `<div class="card2" style="border-color:#3a2f12;margin-top:6px"><h3>إعدادات المحافظ الإلكترونية</h3><p class="sub" style="line-height:1.9;margin:0">المحفظة المقفولة أو اللي من غير رقم صحيح مش بتظهر للعملاء خالص. أي تعديل بيتطبق فوراً على صفحة الدفع.</p></div>`+card("vodafone","فودافون كاش")+card("etisalat","اتصالات كاش")}
function saveWal(k,t){const n=$("#wn_"+k).value.replace(/\D/g,"");if(n&&!okNum(n))return fl("اكتب رقم موبايل صحيح (١١ رقم يبدأ بـ 01).",0);WAL[k].num=n;SL("ao_wal",WAL);applyWal();fl("تم حفظ إعدادات "+t+".")}
/* الموسيقى */
let AC=null;
function synth(v){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const t0=AC.currentTime+.05,g=AC.createGain();g.gain.value=.3*v/100;g.connect(AC.destination);[293.66,311.13,369.99,392,440,392,369.99,311.13,293.66,261.63,293.66].forEach((f,i)=>{const o=AC.createOscillator(),e=AC.createGain();o.type="triangle";o.frequency.value=f;o.connect(e);e.connect(g);const s=t0+i*.55;e.gain.setValueAtTime(0,s);e.gain.linearRampToValueAtTime(1,s+.05);e.gain.exponentialRampToValueAtTime(.001,s+.9);o.start(s);o.stop(s+1)})}catch(e){}}
function playMus(){if(MUS.data){try{const a=new Audio(MUS.data);a.volume=MUS.vol/100;a.play().catch(()=>{})}catch(e){}}else synth(MUS.vol)}
document.addEventListener("pointerdown",()=>{let d=0;try{d=sessionStorage.getItem("ao_pl")}catch(e){}if(MUS.on&&!d){try{sessionStorage.setItem("ao_pl","1")}catch(e){}playMus()}},{once:true});
function musTab(){return `<div class="card2" style="border-color:#3a2f12;margin-top:6px"><h3>موسيقى الترحيب</h3><p class="sub" style="line-height:1.9;margin:0">لحن شرقي هادئ بدون أي كلام أو غناء، بيتشغل مرة واحدة أول ما العميل يفتح التطبيق.</p></div>
 <div class="card2">${tg("تشغيل الموسيقى عند فتح التطبيق",MUS.on,"MUS.on=this.checked")}<div style="display:flex;gap:10px;margin-top:12px"><label class="btn dark" style="flex:1;justify-content:center;cursor:pointer">${ic("imgp",20)} رفع ملف موسيقى<input type="file" accept="audio/*" hidden onchange="upMus(this.files[0])"></label><button class="btn dark" style="flex:1;justify-content:center" onclick="playMus()">${ic("play",18)} معاينة اللحن</button></div>
 <div class="mh" style="display:flex;gap:8px;align-items:center">${ic("vol",20)} مستوى الصوت — <span id="vl">${MUS.vol}</span>%</div><input type="range" min="0" max="100" value="${MUS.vol}" oninput="MUS.vol=+this.value;$('#vl').textContent=this.value">
 <p class="sub" style="margin-top:16px;word-break:break-all">الملف المستخدم دلوقتي: ${MUS.name?esc(MUS.name):"لحن شرقي هادئ (افتراضي)"}</p>${gb("حفظ إعدادات الموسيقى","saveMus()")}${MUS.data?`<p style="text-align:center;margin:12px 0 0"><a style="cursor:pointer;color:var(--mut)" onclick="MUS.data='';MUS.name='';saveMus()">رجوع للّحن الافتراضي</a></p>`:""}</div>`}
function upMus(f){if(!f)return;if(f.size>2e6)return fl("الملف كبير — الحد الأقصى ٢ ميجا.",0);const r=new FileReader();r.onload=()=>{MUS.data=r.result;MUS.name=f.name;saveMus()};r.readAsDataURL(f)}
function saveMus(){if(SL("ao_mus",MUS))fl("تم حفظ إعدادات موسيقى الترحيب.")}
/* الإعدادات */
function settingsTab(){const g=(k,d)=>ST[k]!=null?ST[k]:d,f=(l,k,d,t="text",x="")=>lb(l)+`<input class="fi" id="s_${k}" type="${t}" value="${esc(g(k,d))}" ${x}>`;
 return `<div class="card2" style="margin-top:6px">${f("اسم المطعم","name","مطعم أبو عمر الكندي")}${f("الجملة التعريفية","tag","مشويات على الفحم بطعم لا ينسى — اطلب أونلاين والتوصيل لحد باب البيت")}${f("رقم التليفون","phone",DATA.phone,"tel",'dir="ltr"')}${f("رقم واتساب المطعم (بصيغة دولية 20...)","wa",DATA.whatsapp,"tel",'dir="ltr"')}${f("العنوان","addr",DATA.address)}
 <div style="display:flex;gap:10px"><div style="flex:1">${f("رسوم التوصيل","fee",DATA.deliveryFee,"number")}</div><div style="flex:1">${f("الحد الأدنى للطلب","min",DATA.minOrder,"number")}</div></div>${f("مواعيد العمل","hours","11:00 - 02:00")}${f("رابط التطبيق للمشاركة","share",location.href,"url",'dir="ltr"')}
 ${lb("شعار المطعم")}<div style="display:flex;gap:14px;align-items:center"><div class="logo" style="width:70px;height:70px"><img id="lgp" src="${lg()}" alt=""></div><label class="btn dark" style="cursor:pointer">تغيير الشعار<input type="file" accept="image/*" hidden onchange="readImg(this.files[0],400,d=>{try{localStorage.setItem('ao_logo',d);dbPush('ao_logo',d);schedulePub()}catch(e){}setLogo();$('#lgp').src=d})"></label></div>${gb("حفظ الإعدادات","saveSet()")}</div><div class="card2"><h3>النشر للعملاء</h3><p class="sub" style="line-height:1.9;margin-top:0">أي تعديل في الأصناف أو الأقسام أو العروض أو الإعدادات بيتنشر تلقائياً للعملاء بعد ٤ ثواني، وبيتحدّث عندهم من غير ما يعملوا حاجة.</p>${gb("نشر التعديلات الآن","pubNow(1)","refresh")}</div>`}
function saveSet(){const v=k=>$("#s_"+k).value.trim();ST={...ST,name:v("name"),tag:v("tag"),phone:v("phone"),wa:v("wa").replace(/\D/g,"")||DATA.whatsapp,addr:v("addr"),fee:+v("fee")||0,min:+v("min")||0,hours:v("hours"),share:v("share")};SL("ao_set",ST);applySet();init();fl("تم حفظ إعدادات المطعم.")}
/* الفريق */
const PL=[["orders","الطلبات","عرض الطلبات وتحديث حالتها وتأكيد تحويلات المحافظ وإضافة طلب يدوي."],["menu","المنيو والأسعار","إضافة وتعديل وحذف الأصناف والأقسام وأسعارها وصورها."],["offers","العروض والخصومات","إنشاء وتعديل عروض أبو عمر على الصفحة الرئيسية."],["reports","تقارير المبيعات","أرقام اليوم والأيام السابقة والإيرادات حسب مصدر الطلب."],["settings","إعدادات المطعم والمحافظ","بيانات المطعم ورقم واتساب ورسوم التوصيل وأرقام المحافظ وموسيقى الترحيب."],["team","الفريق والصلاحيات","إضافة الموظفين وضبط صلاحياتهم وحذفهم."]];
let ET=null,DT=null;
function teamTab(){return `<div class="card2" style="border-color:#3a2f12;margin-top:6px"><h3>${ic("users",22)} إدارة الفريق والصلاحيات</h3><p class="sub" style="line-height:1.9;margin-top:0">كل موظف بياخد حساب دخول خاص بيه (اسم دخول + كلمة مرور) وبيشوف بس الأقسام اللي مسموح له بيها. كلمات المرور مشفّرة وما حدش بيقدر يفتح اللوحة من غير حساب.</p><button class="btn gold" style="width:100%;justify-content:center" onclick="editTeam()">${ic("userplus",20)} إضافة موظف</button><button class="btn dark" style="width:100%;justify-content:center;margin-top:12px" onclick="teamIO()">${ic("download",20)} استيراد ملف / إدارة الحسابات</button></div>`+TEAM.map(m=>`<div class="oc" style="cursor:default"><div><b class="n">${esc(m.user)}</b><small>الدخول: ${esc(m.name)} · ${RL[m.role]}</small></div><div style="display:flex;gap:8px;align-items:center"><span class="stb" style="color:#4ade9a;border-color:#1f6b52;background:#0e1f18">${m.role=="staff"?m.perms.length:ALLP.length} صلاحية</span><button class="eb" onclick="editTeam('${m.id}')">تعديل</button><button class="eb" style="${DT==m.id?"color:#f0899a;border-color:#f0899a":""}" onclick="delTeam('${m.id}')">${DT==m.id?"تأكيد؟":ic("trash",20)}</button></div></div>`).join("")}
function delTeam(id){if(DT!=id){DT=id;dash();setTimeout(()=>{if(DT==id){DT=null;if(A.tab=="team"&&SESS)dash()}},3000);return}DT=null;TEAM=TEAM.filter(m=>m.id!=id);SL("ao_team",TEAM);dash()}
function editTeam(id){const m=TEAM.find(t=>t.id==id);ET=m?{...m,perms:[...m.perms],pass:""}:{id:"u"+Date.now(),name:"",email:"",phone:"",user:"",pass:"",role:"staff",perms:["orders"],isNew:1};drawET();openAdm()}
function drawET(){const e=ET,full=e.role!="staff";$("#admBox").innerHTML=mh(e.isNew?"إضافة موظف جديد":"تعديل الموظف")+lb("الاسم")+inp(e.name,"ET.name=this.value")+lb("البريد الإلكتروني")+inp(e.email,"ET.email=this.value","email","",'dir="ltr"')+lb("رقم الموبايل")+inp(e.phone,"ET.phone=this.value","tel")+lb("اسم الدخول (حروف إنجليزي وأرقام)")+inp(e.user,"ET.user=this.value","text","",'dir="ltr"')+lb(e.isNew?"كلمة المرور الأولية":"كلمة مرور جديدة (اتركها فاضية لو مش هتغيّرها)")+inp(e.pass,"ET.pass=this.value","password")+`<p class="sub" style="margin:6px 0 0">6 حروف على الأقل — الموظف يقدر يغيّرها بعدين من إعدادات حسابه.</p>`+lb("الدور")+[["owner","صاحب المطعم","كل الصلاحيات بدون استثناء — حساب المطعم الأساسي."],["manager","مدير","إدارة الطلبات والمنيو والعروض والتقارير والفريق مع بعض."],["staff","موظف","يشوف ويشتغل في الأقسام اللي بتحددها بس."]].map(r=>`<div class="rc ${e.role==r[0]?"on":""}" onclick="ET.role='${r[0]}';drawET()"><b>${r[1]}</b><small>${r[2]}</small></div>`).join("")+`<div class="mh" style="display:flex;gap:8px;align-items:center">${ic("shield",20)} الصلاحيات المسموح بها</div>`+PL.map(p=>{const on=full||e.perms.includes(p[0]);return `<div class="rc pc ${on?"on":""}" onclick="${full?"":`togP('${p[0]}')`}"><div><b>${p[1]}</b><small>${p[2]}</small></div><span class="bx">${on?"✓":""}</span></div>`}).join("")+`<p class="sub" style="line-height:1.8">صلاحية «الفريق والصلاحيات» بتخلي الموظف مدير — يقدر يضيف ويشيل حسابات. سيبها معاك بس.</p><div class="err" id="aerr" style="display:none"></div>`+gb(e.isNew?"إنشاء الحساب":"حفظ التعديلات","saveET()")}
function togP(k){const i=ET.perms.indexOf(k);i<0?ET.perms.push(k):ET.perms.splice(i,1);drawET()}
async function saveET(){const e=ET,u=e.user.trim();if(!e.name.trim())return aerr("اكتب اسم الموظف.");if(!/^[A-Za-z0-9]{3,}$/.test(u))return aerr("اسم الدخول حروف إنجليزي وأرقام (٣ على الأقل).");
 if(TEAM.some(t=>t.id!=e.id&&t.user.toLowerCase()==u.toLowerCase())||u.toLowerCase()==(ACC.user||"").toLowerCase())return aerr("اسم الدخول ده مستخدم.");
 if(e.isNew&&e.pass.length<6||e.pass&&e.pass.length<6)return aerr("كلمة المرور لازم تكون ٦ حروف على الأقل.");if(e.role=="staff"&&!e.perms.length)return aerr("اختار صلاحية واحدة على الأقل.");
 const old=TEAM.find(t=>t.id==e.id),m={id:e.id,name:e.name.trim(),email:e.email.trim(),phone:e.phone.trim(),user:u,role:e.role,perms:e.perms,h:e.pass?await H(e.pass):old.h};
 const i=TEAM.findIndex(t=>t.id==m.id);if(i<0)TEAM.push(m);else TEAM[i]=m;SL("ao_team",TEAM);closeAdm();fl("تم حفظ حساب الموظف.")}
function teamIO(){$("#admBox").innerHTML=mh("إدارة الحسابات")+`<p class="sub">انسخ النص ده كنسخة احتياطية، أو الصق نسخة سابقة واضغط استيراد.</p><textarea class="fi" id="tio" rows="8" dir="ltr">${esc(JSON.stringify(TEAM))}</textarea><div class="err" id="aerr" style="display:none"></div><div style="display:flex;gap:10px">${gb("استيراد","impTeam()")}<button class="btn dark" style="margin-top:16px" onclick="try{navigator.clipboard.writeText($('#tio').value)}catch(e){};toast('تم النسخ ✓')">نسخ</button></div>`;openAdm()}
function impTeam(){try{const a=JSON.parse($("#tio").value);if(!Array.isArray(a))throw 0;a.forEach(m=>{if(m&&m.user&&m.h&&m.id&&!TEAM.some(t=>t.id==m.id||t.user==m.user))TEAM.push({id:m.id,name:m.name||m.user,email:m.email||"",phone:m.phone||"",user:m.user,h:m.h,role:["manager","staff"].includes(m.role)?m.role:"staff",perms:(m.perms||[]).filter(p=>ALLP.includes(p))})});SL("ao_team",TEAM);closeAdm();fl("تم الاستيراد.")}catch(e){aerr("النص مش صحيح.")}}
/* إعدادات الحساب */
function acctTab(){const C=CU(),own=C.role=="owner",on=ST.codeOn!==false;
 const sec=(t,i,b)=>`<div class="card2"><h3>${ic(i,22)} ${t}</h3>${b}</div>`,pf=(id,l)=>lb(l)+`<input class="fi" id="${id}" type="password">`;
 return `<div class="card2" style="border-color:#3a2f12;margin-top:6px"><div style="display:flex;gap:14px;align-items:center"><div class="th3" style="width:80px;height:80px;border-radius:50%;border:1px solid #6b5a22;background:#2a2210">${ic("uc",40)}</div><div><b style="font-size:24px">${esc(C.name)}</b><div class="sub" style="margin:0">${RL[C.role]}</div></div></div>
 <p style="margin:16px 0 4px;color:var(--mut)">بريد الحساب: <span dir="ltr">${esc(C.email||"—")}</span></p><p style="margin:0;color:var(--mut)">اسم الدخول: <span dir="ltr">${esc(C.user)}</span></p><div style="border-top:1px solid var(--line);margin:14px 0"></div>${lb("اسم الحساب")}<div style="display:flex;gap:10px"><input class="fi" id="ac_n" value="${esc(C.name)}"><button class="btn dark" style="color:var(--gold);padding:12px 18px" onclick="saveAcN()">حفظ الاسم</button></div><button class="btn dark" style="margin-top:14px" onclick="logout()">تسجيل خروج</button></div>`+
 (own?sec("رمز تفعيل حساب المالك","shield",`<p class="sub" style="line-height:1.9;margin-top:0">لما الحماية دي تتفعّل، مفيش حد يقدر يعمل حساب مالك جديد للمطعم من شاشة الدخول من غير الرمز ده. الرمز بيتحفظ مشفّر ومحدش يقدر يقراه تاني (ولا إنت)، فاحفظه بره التطبيق.</p><div class="card2" style="margin:0;padding:14px;background:#0f0b0a"><b><span style="color:${on?"#34d399":"#f0899a"}">●</span> ${on?"الحماية مفعّلة — التسجيل محتاج الرمز":"الحماية موقوفة"}</b></div>${lb("رمز جديد (استبدال)")}<div style="display:flex;gap:10px"><button class="eb" style="width:56px" onclick="const i=$('#ac_nc');i.type=i.type=='password'?'text':'password'">${ic("eye",22)}</button><input class="fi" id="ac_nc" type="password" style="flex:1"></div>${lb("الرمز الحالي (لو بيتبدّل)")}<input class="fi" id="ac_cc" type="password" placeholder="الرمز شغّال دلوقتي"><div style="display:flex;gap:10px;margin-top:14px"><button class="btn gold" style="padding:12px 22px" onclick="rotCode()">استبدال الرمز</button><button class="btn dark" style="color:#f0899a;border-color:#6b2a30;padding:12px 22px" onclick="stopCode()">إيقاف الحماية</button></div><p class="sub" style="line-height:1.9">نصيحة: فعّل الرمز بعد ما تعمل حساب المطعم بتاعك — وقتها التسجيل بيقفل على الغرباء.</p>`):"")+
 sec("تغيير كلمة المرور","key",pf("ac_p0","كلمة المرور الحالية")+pf("ac_p1","كلمة المرور الجديدة")+pf("ac_p2","تأكيد الجديدة")+gb("حفظ كلمة المرور الجديدة","savePw()"))+
 sec("البريد الإلكتروني للتواصل","mail",lb("البريد الإلكتروني")+`<div style="display:flex;gap:10px"><input class="fi" id="ac_e" dir="ltr" value="${esc(C.email||"")}"><button class="btn gold" style="padding:12px 20px" onclick="saveAcE()">حفظ</button></div><p class="sub" style="line-height:1.9;margin:10px 0 0">البريد ده للتواصل وتنبيهات المطعم. اسم الدخول بيفضل زي ما هو — لو عايز تغيّره، بيتغيّر من إدارة الحسابات.</p>`)+delCard()}
const memRef=()=>SESS=="owner"?ACC:TEAM.find(t=>t.id==SESS);
function saveAcN(){const n=$("#ac_n").value.trim();if(n.length<2)return fl("اكتب اسم صحيح.",0);const m=memRef();SESS=="owner"?m.owner=n:m.name=n;SL(SESS=="owner"?"ao_acc":"ao_team",SESS=="owner"?ACC:TEAM);fl("تم حفظ الاسم.")}
function saveAcE(){const e=$("#ac_e").value.trim().toLowerCase();if(!/^\S+@\S+\.\S+$/.test(e))return fl("اكتب بريد صحيح.",0);memRef().email=e;SL(SESS=="owner"?"ao_acc":"ao_team",SESS=="owner"?ACC:TEAM);fl("تم حفظ البريد.")}
async function savePw(){const m=memRef(),a=$("#ac_p0").value,b=$("#ac_p1").value;if(await H(a)!=m.h)return fl("كلمة المرور الحالية غلط.",0);if(b.length<6)return fl("كلمة المرور الجديدة لازم تكون ٦ حروف على الأقل.",0);if(b!=$("#ac_p2").value)return fl("التأكيد مش مطابق.",0);m.h=await H(b);SL(SESS=="owner"?"ao_acc":"ao_team",SESS=="owner"?ACC:TEAM);fl("تم تغيير كلمة المرور.")}
async function rotCode(){const n=$("#ac_nc").value.trim();if(n.length<4)return fl("الرمز الجديد ٤ حروف على الأقل.",0);if(ST.codeOn!==false&&!await codeOk($("#ac_cc").value.trim()))return fl("الرمز الحالي غلط.",0);ST.codeH=await H(n);ST.codeOn=true;SL("ao_set",ST);fl("تم استبدال الرمز وتفعيل الحماية.")}
async function stopCode(){if(ST.codeOn!==false&&!await codeOk($("#ac_cc").value.trim()))return fl("اكتب الرمز الحالي الأول.",0);ST.codeOn=false;SL("ao_set",ST);fl("تم إيقاف الحماية.")}

/* ===== مزامنة البيانات مع قاعدة بيانات الـ Artifact (تحفظ الحساب والمنيو والطلبات بشكل دائم) ===== */
const SYNC=["ao_sess","ao_sess_t","ao_acc","ao_ord","ao_set","ao_items","ao_cats","ao_offs","ao_wal","ao_team","ao_logo","ao_mus"];
function dbPush(k,s){if(!DB||!SYNC.includes(k)||s.length>800000)return;clearTimeout(QT[k]);QT[k]=setTimeout(async()=>{try{const ch=[];for(let i=0;i<Math.max(s.length,1);i+=180000)ch.push(s.slice(i,i+180000));await Promise.all(ch.map((c,i)=>DB.doc("kv/"+k+"__"+i).set({n:ch.length,v:c})))}catch(e){}},500)}
function reloadAll(){SESS=LS("ao_sess",false);ACC=LS("ao_acc",null);ORD=LS("ao_ord",[]);ST=LS("ao_set",{});const s2=LS("ao_items",null);if(Array.isArray(s2)&&s2.length)DATA.items=s2;DATA.items.forEach(x=>{x.img=x.ci||IMG[x.n]});CATS=LS("ao_cats",null)||CATS;OFFS=LS("ao_offs",null)||OFFS;TEAM=LS("ao_team",[]);WAL=LS("ao_wal",null)||WAL;MUS=LS("ao_mus",MUS);cart=cart.filter(l=>find(l.id));applyCats();applyOffs();applyWal();applySet();setLogo();init()}
(async()=>{let c=null;try{DBL=!!window.claude;if(!DBL)return;c=await window.claude.use("db");if(!c){DBL=false;return}
 const snap=await Promise.race([c.collection("kv").get(),new Promise((_,r)=>setTimeout(r,8000))]);DB=c;const g={};
 snap.docs.forEach(d=>{const x=d.data(),m=d.id.match(/^(.*)__(\d+)$/);if(m&&x)(g[m[1]]=g[m[1]]||[])[+m[2]]=x});let ch=0;
 for(const k of SYNC){const a=g[k];if(a&&a[0]){const n=a[0].n,p=a.slice(0,n);if(p.length==n&&p.every(Boolean)){const s=p.map(x=>x.v).join("");if(localStorage.getItem(k)!==s){try{localStorage.setItem(k,s);ch=1}catch(e){}}}}else{let s=null;try{s=localStorage.getItem(k)}catch(e){}if(s)dbPush(k,s)}}
 if(ch)reloadAll()}catch(e){}finally{DBL=false;if($("#admin").classList.contains("on"))renderAdmin();resume()}})();

ICON.alert=ICON.bag.replace(/<path.*<\/svg>/,'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>');
function delCard(){const ask=A.del;return `<div class="card2" style="border-color:#4a1c22"><h3 style="color:#f0899a;display:flex;gap:8px;align-items:center">${ic("alert",22)} حذف الحساب</h3><p class="sub" style="line-height:1.9;margin-top:0">حذف الحساب بيوقف الدخول للوحة نهائياً. الطلبات والمنيو وتقارير المبيعات مش بتتمسح.</p>`+
 (ask?`<label class="mh" style="display:block;margin-top:0">اكتب كلمة المرور للتأكيد</label><input class="fi" id="dl_p" type="password"><div style="display:flex;gap:10px;margin-top:12px"><button class="btn dark" style="color:#f0899a;border-color:#6b2a30;flex:1;justify-content:center" onclick="doDel()">${ic("trash",20)} تأكيد الحذف</button><button class="btn dark" style="flex:1;justify-content:center" onclick="A.del=false;dash()">إلغاء</button></div>`:`<button class="btn dark" style="color:#f0899a;border-color:#6b2a30" onclick="A.del=true;dash()">${ic("trash",20)} حذف حسابي</button>`)+`</div>
 <div class="card2" style="display:flex;gap:12px;align-items:center;padding:16px;color:var(--mut);line-height:1.9"><span>كلمات المرور محفوظة مشفّرة، والجلسة بتقفل لوحدها بعد ١٢ ساعة. التطبيق مش بيحفظ ولا بيطلب أي كلمة سر أو OTP خاصة بالمحافظ.</span><span style="color:var(--gold);flex:none">${ic("shield",22)}</span></div>`}
async function doDel(){const m=memRef();if(await H($("#dl_p").value)!=m.h)return fl("كلمة المرور غلط.",0);
 if(SESS=="owner"){const nx=TEAM.find(t=>t.role=="owner");if(nx){ACC={rest:ACC.rest,owner:nx.name,email:nx.email,user:nx.user,h:nx.h};TEAM=TEAM.filter(t=>t!=nx)}else ACC=null;SL("ao_acc",ACC);SL("ao_team",TEAM)}
 else{TEAM=TEAM.filter(t=>t.id!=SESS);SL("ao_team",TEAM)}
 A.del=false;SESS=false;SL("ao_sess",false);renderAdmin();toast("تم حذف الحساب")}

/* ===== النشر التلقائي للعملاء + واتساب ===== */
const PUBK=["ao_items","ao_cats","ao_offs","ao_wal","ao_set","ao_mus"];let PT=null,ART=null;
function pubState(){const s={...ST};delete s.codeH;delete s.codeOn;const m={...MUS};if((m.data||"").length>700000){m.data="";m.name=""}
 let lgo;try{lgo=localStorage.getItem("ao_logo")||undefined}catch(e){}
 return{items:DATA.items.map(x=>{const r={...x};delete r.img;return r}),cats:CATS,offs:OFFS,wal:WAL,set:s,mus:m,logo:lgo}}
function buildDoc(){return SRC0.replace(/const PUB=[\s\S]*?;\/\*PUBEND\*\//,()=>"const PUB="+JSON.stringify(pubState()).replace(/</g,"\\u003c")+";/*PUBEND*/")}
function schedulePub(){clearTimeout(PT);PT=setTimeout(()=>pubNow(0),4000)}
async function pubNow(f){clearTimeout(PT);try{if(!window.claude)return toast("النشر للعملاء غير متاح هنا");if(!ART)ART=await window.claude.use("artifact");if(!ART)return toast("النشر للعملاء غير متاح من هذا الحساب");
 if(!f&&JSON.stringify(pubState())===JSON.stringify(PUB||{}))return;toast("جاري نشر التعديلات للعملاء…");try{localStorage.setItem("ao_resume",A.tab||"orders")}catch(e){}await ART.publish(buildDoc())}catch(e){try{localStorage.removeItem("ao_resume")}catch(x){}toast("تعذّر النشر للعملاء")}}
function resume(){let t=null;try{t=localStorage.getItem("ao_resume")}catch(e){}if(t&&SESS){try{localStorage.removeItem("ao_resume")}catch(e){}A.tab=t;go("admin")}}
function openWA(t){const q=t?"?text="+encodeURIComponent(t):"",u="https://wa.me/"+DATA.whatsapp+q;let w=null;try{w=window.open(u,"_blank")}catch(e){}
 if(!w){try{window.top.location.href=u;return}catch(e){}location.href="whatsapp://send?phone="+DATA.whatsapp+(t?"&text="+encodeURIComponent(t):"")}}
document.addEventListener("click",e=>{const a=e.target.closest&&e.target.closest("#waHero,#waBtn,#wa3");if(a){e.preventDefault();openWA("أهلاً، عايز أطلب من مطعم "+DATA.name)}});
if(!DBL)resume();
init();
