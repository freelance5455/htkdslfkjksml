const BLOG_URL =
  "https://nebookread.blogspot.com";

const FEED_URL =
  BLOG_URL +
  "/feeds/posts/default?alt=json-in-script&max-results=50&callback=handleBloggerFeed";


let allPosts = [];

let currentCategory = "all";

let currentSearch = "";
let feedTimeoutId = null;


const postsContainer =
  document.getElementById("postsContainer");

const loading =
  document.getElementById("loading");

const errorBox =
  document.getElementById("errorBox");

const errorText =
  document.getElementById("errorText");

const noResults =
  document.getElementById("noResults");

const searchInput =
  document.getElementById("searchInput");

const refreshBtn =
  document.getElementById("refreshBtn");

const retryBtn =
  document.getElementById("retryBtn");


document.getElementById("year").textContent =
  new Date().getFullYear();


/* =========================
   START APP
========================= */

window.startApp = function () {

  loadBloggerPosts();

};


/* =========================
   LOAD BLOGGER POSTS
========================= */

function loadBloggerPosts() {

  showLoading();

  postsContainer.innerHTML = "";

  errorBox.classList.add("hidden");

  const oldScript =
    document.getElementById("bloggerFeedScript");

  if (oldScript) {
    oldScript.remove();
  }


  const script =
    document.createElement("script");

  script.id =
    "bloggerFeedScript";

  script.src =
    FEED_URL +
    "&t=" +
    Date.now();


  let settled = false;
  feedTimeoutId = window.setTimeout(function () {
    if (settled) return;
    settled = true;
    script.remove();
    hideLoading();
    showError("Blogger feed timed out. Check your internet connection and try again.");
  }, 15000);

  script.onerror = function () {
    if (settled) return;
    settled = true;
    window.clearTimeout(feedTimeoutId);
    script.remove();
    hideLoading();
    showError("Blogger posts could not be loaded. Check your internet connection and Blogger feed settings.");
  };

  document.body.appendChild(script);

}


/* =========================
   BLOGGER JSONP
========================= */

window.handleBloggerFeed =
function (data) {

  try {

    window.clearTimeout(feedTimeoutId);
    const feedScript = document.getElementById("bloggerFeedScript");
    if (feedScript) feedScript.remove();
    hideLoading();
    allPosts = [];

    const entries =
      data && data.feed && Array.isArray(data.feed.entry) ? data.feed.entry : [];


    entries.forEach(function (entry) {

      const title =
        entry.title?.$t || "Untitled";


      const url =
        getPostUrl(entry);


      const content =
        entry.content?.$t ||
        entry.summary?.$t ||
        "";


      const image =
        getImage(content);


      const excerpt =
        getExcerpt(content);


      const labels =
        (entry.category || [])
          .map(function (item) {
            return item.term;
          });


      const id =
        createPostId(entry, url);


      allPosts.push({

        id: id,

        title: title,

        url: url,

        content: content,

        image: image,

        excerpt: excerpt,

        labels: labels

      });

    });


    hideLoading();

    renderPosts();


  } catch (error) {

    console.error(error);

    hideLoading();

    showError(
      "Could not read Blogger data."
    );

  }

};


/* =========================
   POST URL
========================= */

function getPostUrl(entry) {

  const links =
    entry.link || [];


  const alternate =
    links.find(function (link) {

      return link.rel === "alternate";

    });


  return alternate
    ? alternate.href
    : BLOG_URL;

}


/* =========================
   POST ID
========================= */

function createPostId(entry, url) {

  if (entry.id?.$t) {

    return entry.id.$t
      .replace(/[^a-zA-Z0-9_-]/g, "_");

  }

  return btoa(url)
    .replace(/[^a-zA-Z0-9_-]/g, "_");

}


/* =========================
   IMAGE
========================= */

function getImage(html) {

  const temp =
    document.createElement("div");

  temp.innerHTML = html;

  const img =
    temp.querySelector("img");


  if (img && img.src) {

    return img.src;

  }


  return "https://via.placeholder.com/800x450?text=NE+Book+Read";

}


/* =========================
   EXCERPT
========================= */

function getExcerpt(html) {

  const temp =
    document.createElement("div");

  temp.innerHTML = html;


  const text =
    temp.textContent ||
    temp.innerText ||
    "";


  return text
    .replace(/\s+/g, " ")
    .trim()
    .substring(0, 150) +
    "...";

}


/* =========================
   RENDER POSTS
========================= */

function renderPosts() {

  postsContainer.innerHTML = "";


  const filtered =
    allPosts.filter(function (post) {

      const categoryMatch =
        currentCategory === "all" ||
        post.labels.some(function (label) {

          return label
            .toLowerCase()
            .includes(currentCategory);

        });


      const searchText =
        (
          post.title +
          " " +
          post.excerpt
        ).toLowerCase();


      const searchMatch =
        !currentSearch ||
        searchText.includes(currentSearch);


      return categoryMatch &&
             searchMatch;

    });


  if (filtered.length === 0) {

    noResults.classList.remove("hidden");

    return;

  }


  noResults.classList.add("hidden");


  filtered.forEach(function (post) {

    createPostCard(post);

  });

}


/* =========================
   CREATE CARD
========================= */

function createPostCard(post) {

  const card =
    document.createElement("article");

  card.className =
    "post-card";


  const labelsHTML =
    post.labels
      .map(function (label) {

        return `
          <span class="label">
            ${escapeHTML(label)}
          </span>
        `;

      })
      .join("");


  card.innerHTML = `

    <img
      class="post-image"
      src="${escapeAttribute(post.image)}"
      alt="${escapeAttribute(post.title)}"
      loading="lazy"
    >

    <div class="post-content">

      <h3 class="post-title">
        ${escapeHTML(post.title)}
      </h3>

      <div class="post-labels">
        ${labelsHTML}
      </div>

      <p class="post-excerpt">
        ${escapeHTML(post.excerpt)}
      </p>

      <div class="post-actions">

        <button
          class="action-btn like-btn"
          data-id="${post.id}">
          ❤️ <span>Like</span>
        </button>

        <button
          class="action-btn view-btn"
          data-id="${post.id}">
          👁 <span>View</span>
        </button>

        <button
          class="action-btn comment-btn"
          data-url="${escapeAttribute(post.url)}">
          💬 Comment
        </button>

        <a
          class="read-btn"
          href="${escapeAttribute(post.url)}"
          target="_blank"
          rel="noopener noreferrer">

          Read Story

        </a>

      </div>

    </div>

  `;


  postsContainer.appendChild(card);


  const likeButton =
    card.querySelector(".like-btn");


  likeButton.addEventListener(
    "click",
    function () {

      likePost(post.id);

    }
  );


  const viewButton =
    card.querySelector(".view-btn");


  viewButton.addEventListener(
    "click",
    function () {

      viewPost(post.id);

    }
  );


  const commentButton =
    card.querySelector(".comment-btn");


  commentButton.addEventListener(
    "click",
    function () {

      openComment(post);

    }
  );


  loadLikeCount(
    post.id,
    likeButton
  );


  loadViewCount(
    post.id,
    viewButton
  );

}


/* =========================
   FIREBASE LIKE
========================= */

async function likePost(postId) {

  if (!window.firebaseReady) {

    alert(
      "Firebase is still loading. Please try again."
    );

    return;

  }


  try {

    const {
      doc,
      getDoc,
      setDoc,
      deleteDoc,
      increment,
      updateDoc
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js"
      );


    const {
      getAuth
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js"
      );


    const auth =
      getAuth();


    const user =
      auth.currentUser;


    if (!user) {

      alert(
        "User authentication is not ready."
      );

      return;

    }


    const db =
      window.firebaseDB;


    const likeRef =
      doc(
        db,
        "posts",
        postId,
        "likes",
        user.uid
      );


    const postRef =
      doc(
        db,
        "posts",
        postId
      );


    const existing =
      await getDoc(likeRef);


    if (existing.exists()) {

      await deleteDoc(likeRef);

      await updateDoc(
        postRef,
        {
          likes: increment(-1)
        }
      );


    } else {

      await setDoc(
        likeRef,
        {
          uid: user.uid,
          createdAt: new Date()
        }
      );


      try {

        await updateDoc(
          postRef,
          {
            likes: increment(1)
          }
        );

      } catch {

        await setDoc(
          postRef,
          {
            likes: 1
          }
        );

      }

    }


    loadLikeCount(
      postId,
      document.querySelector(
        `.like-btn[data-id="${postId}"]`
      )
    );


  } catch (error) {

    console.error(
      "Like Error:",
      error
    );

    alert(
      "Like could not be saved."
    );

  }

}


/* =========================
   LOAD LIKE COUNT
========================= */

async function loadLikeCount(
  postId,
  button
) {

  try {

    const {
      doc,
      getDoc
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js"
      );


    const postRef =
      doc(
        window.firebaseDB,
        "posts",
        postId
      );


    const snapshot =
      await getDoc(postRef);


    const count =
      snapshot.exists()
        ? snapshot.data().likes || 0
        : 0;


    if (button) {

      button.querySelector("span")
        .textContent =
        count + " Like";

    }


  } catch (error) {

    console.log(
      "Like count:",
      error
    );

  }

}


/* =========================
   VIEW
========================= */

async function viewPost(postId) {

  if (!window.firebaseReady) {
    return;
  }


  try {

    const {
      doc,
      getDoc,
      setDoc,
      updateDoc,
      increment
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js"
      );


    const {
      getAuth
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js"
      );


    const auth =
      getAuth();


    const user =
      auth.currentUser;


    if (!user) {
      return;
    }


    const viewRef =
      doc(
        window.firebaseDB,
        "posts",
        postId,
        "views",
        user.uid
      );


    const existing =
      await getDoc(viewRef);


    if (!existing.exists()) {

      await setDoc(
        viewRef,
        {
          uid: user.uid,
          createdAt: new Date()
        }
      );


      const postRef =
        doc(
          window.firebaseDB,
          "posts",
          postId
        );


      try {

        await updateDoc(
          postRef,
          {
            views: increment(1)
          }
        );

      } catch {

        await setDoc(
          postRef,
          {
            views: 1
          }
        );

      }

    }


    loadViewCount(
      postId,
      document.querySelector(
        `.view-btn[data-id="${postId}"]`
      )
    );


  } catch (error) {

    console.error(
      "View Error:",
      error
    );

  }

}


/* =========================
   VIEW COUNT
========================= */

async function loadViewCount(
  postId,
  button
) {

  try {

    const {
      doc,
      getDoc
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js"
      );


    const postRef =
      doc(
        window.firebaseDB,
        "posts",
        postId
      );


    const snapshot =
      await getDoc(postRef);


    const count =
      snapshot.exists()
        ? snapshot.data().views || 0
        : 0;


    if (button) {

      button.querySelector("span")
        .textContent =
        count + " Views";

    }


  } catch (error) {

    console.log(
      "View count:",
      error
    );

  }

}


/* =========================
   COMMENT
========================= */

function openComment(post) {

  const comment =
    prompt(
      "Write your comment:"
    );


  if (!comment) {
    return;
  }


  saveComment(
    post.id,
    comment
  );

}


/* =========================
   SAVE COMMENT
========================= */

async function saveComment(
  postId,
  text
) {

  if (!window.firebaseReady) {

    alert(
      "Firebase is loading."
    );

    return;

  }


  try {

    const {
      collection,
      addDoc
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js"
      );


    const {
      getAuth
    } =
      await import(
        "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js"
      );


    const auth =
      getAuth();


    const user =
      auth.currentUser;


    if (!user) {

      alert(
        "Please wait for login."
      );

      return;

    }


    await addDoc(

      collection(
        window.firebaseDB,
        "posts",
        postId,
        "comments"
      ),

      {
        text: text,
        uid: user.uid,
        createdAt: new Date()
      }

    );


    alert(
      "✅ Comment added!"
    );


  } catch (error) {

    console.error(
      "Comment Error:",
      error
    );

    alert(
      "Comment could not be saved."
    );

  }

}


/* =========================
   SEARCH
========================= */

searchInput.addEventListener(
  "input",
  function () {

    currentSearch =
      this.value
        .toLowerCase()
        .trim();

    renderPosts();

  }
);


/* =========================
   CATEGORY
========================= */

document
  .querySelectorAll(".category")
  .forEach(function (button) {

    button.addEventListener(
      "click",
      function () {

        document
          .querySelectorAll(".category")
          .forEach(function (btn) {

            btn.classList.remove(
              "active"
            );

          });


        this.classList.add(
          "active"
        );


        currentCategory =
          this.dataset.label;


        renderPosts();

      }
    );

  });


/* =========================
   REFRESH
========================= */

refreshBtn.addEventListener(
  "click",
  function () {

    loadBloggerPosts();

  }
);


retryBtn.addEventListener(
  "click",
  function () {

    loadBloggerPosts();

  }
);


/* =========================
   HELPERS
========================= */

function showLoading() {

  loading.classList.remove(
    "hidden"
  );

}


function hideLoading() {

  loading.classList.add(
    "hidden"
  );

}


function showError(message) {

  errorText.textContent =
    message;

  errorBox.classList.remove(
    "hidden"
  );

}


function escapeHTML(text) {

  const div =
    document.createElement("div");

  div.textContent =
    text;

  return div.innerHTML;

}


function escapeAttribute(text) {

  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

}


/* Start if Firebase was already ready */

if (window.firebaseReady) {

  window.startApp();

}