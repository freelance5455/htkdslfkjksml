#!/system/bin/sh

MODDIR="${0%/*}"
case "$0" in
    */*) MODDIR="${0%/*}" ;;
    *) MODDIR="$(pwd 2>/dev/null || echo /data/adb/modules/Switchmat)" ;;
esac
export PATH="/system/xbin:/system/bin:/system/sbin:/sbin:/vendor/bin:/vendor/xbin:$PATH"
. "$MODDIR/lib/props.sh"

CONFIG="$MODDIR/config.conf"

diag_service_state() {
    local pid=""
    if [ -f "$MODDIR/monitor.pid" ]; then
        pid=$(cat "$MODDIR/monitor.pid" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            echo "activo (pid $pid)"
            return 0
        fi
    fi
    echo "inactivo"
}

monitor_on() {
    local pid=""
    if [ -f "$MODDIR/monitor.pid" ]; then
        pid=$(cat "$MODDIR/monitor.pid" 2>/dev/null)
        [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && { echo 1; return 0; }
    fi
    echo 0
}

read_auto_render() {
    AUTO_RENDER=1
    local line=""
    line=$(grep -E "^AUTO_RENDER=" "$CONFIG" 2>/dev/null | tail -n 1)
    [ -n "$line" ] && AUTO_RENDER="${line#*=}"
}

cmd_status() {
    read_auto_render
    echo "AUTO_RENDER=$AUTO_RENDER"
    echo "GAME_RENDERER=$(cfg_value GAME_RENDERER)"
    echo "NORMAL_RENDERER=$(cfg_value NORMAL_RENDERER)"
    echo "RENDERER=$(get_prop debug.hwui.renderer)"
    echo "VULKAN=$(get_prop ro.hwui.use_vulkan)"
    local cm="" f=""
    cm=$(cat "$MODDIR/current_mode" 2>/dev/null)
    f=$(cat "$MODDIR/last_focus" 2>/dev/null)
    if [ -z "$cm" ]; then
        case "$(get_prop debug.hwui.renderer)" in *vk*) cm=vulkan ;; *) cm=normal ;; esac
    fi
    echo "CURRENT_MODE=$cm"
    echo "FOCUS=$f"
    echo "MONITOR=$(monitor_on)"
    echo "DIAG_GP=${GP:-ninguno}"
    echo "DIAG_RESETPROP=${RESETPROP:-ninguno}"
    echo "DIAG_SERVICE=$(diag_service_state)"
    echo "PROPS"
    echo "$PROPS" | while IFS= read -r line; do
        [ -z "$line" ] && continue
        name="${line%%|*}"
        echo "  $name=$(cfg_value "$name")"
    done
    echo "GAMES"
    cat "$MODDIR/games.conf" 2>/dev/null
    echo ""
    echo "VALUES"
    echo "$PROPS" | while IFS= read -r line; do
        [ -z "$line" ] && continue
        name="${line%%|*}"
        echo "  $name|$(prop_state "$name")"
    done
}

cmd_setgames() {
    : > "$MODDIR/games.conf"
    for pkg in $*; do
        [ -z "$pkg" ] && continue
        case "$pkg" in
            *[!A-Za-z0-9_.]*)
                echo "FALLO: '$pkg' no es un paquete valido (se omite)"
                continue
                ;;
        esac
        echo "$pkg" >> "$MODDIR/games.conf"
    done
    echo "OK: $(wc -l < "$MODDIR/games.conf" 2>/dev/null) juegos guardados"
}

cmd_set() {
    local key="$1" value="$2" out="" valido=""
    if [ -z "$key" ]; then
        echo "uso: set <KEY> [valor|-]"
        return
    fi
    if ! is_config_key "$key"; then
        valido=$(echo "$PROPS" | grep -m1 "^$key|")
        if [ -z "$valido" ]; then
            echo "FALLO: '$key' no es una clave valida de este modulo"
            return 1
        fi
    fi
    out=$(set_key "$key" "$value")
    case "$out" in
        OK:*) echo "$out" ;;
        *)    echo "$out"; return 1 ;;
    esac
    apply_single "$key" "$value"
}

cmd_apply() {
    local force="$1" cm="" mode=""
    read_auto_render
    if [ "$force" = "vk" ]; then
        mode=vk
    elif [ "$force" = "gl" ]; then
        mode=gl
    elif [ "$AUTO_RENDER" = "1" ]; then
        cm=$(cat "$MODDIR/current_mode" 2>/dev/null)
        if [ -z "$cm" ]; then
            case "$(get_prop debug.hwui.renderer)" in *vk*) cm=vulkan ;; *) cm=normal ;; esac
        fi
        if [ "$cm" = "vulkan" ]; then
            mode=vk
        else
            mode=gl
        fi
    else
        mode=gl
    fi
    apply_all
    if [ "$mode" = "vk" ]; then
        apply_render_mode game
    else
        apply_render_mode normal
    fi
    echo "OK: $APPLIED_N props + modo $mode -> $(get_prop debug.hwui.renderer)"
}

cmd_restart() {
    if [ -f "$MODDIR/monitor.pid" ]; then
        kill "$(cat "$MODDIR/monitor.pid" 2>/dev/null)" 2>/dev/null
    fi
    pkill -f "$MODDIR/service.sh" 2>/dev/null
    rm -f "$MODDIR/monitor.pid" 2>/dev/null
    nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
    echo "OK: monitor reiniciado"
}

case "$1" in
    status)       cmd_status ;;
    set)          shift; cmd_set "$@" ;;
    setgames)     shift; cmd_setgames "$@" ;;
    apply)        cmd_apply "$2" ;;
    restart)      cmd_restart ;;
    *)            echo "uso: status|set <KEY> <valor|->|setgames <pkgs>|apply [vk|gl]|restart" ;;
esac
