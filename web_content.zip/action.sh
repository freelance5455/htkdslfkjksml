#!/system/bin/sh
MODDIR="${0%/*}"
printf '%s\n' '========================================'
printf '%s\n' '        TM Otimizações Beta v1.0'
printf '%s\n' '   Plugin oficial do canal TM Otimizações'
printf '%s\n' '   YouTube: @Tm.optimization'
printf '%s\n' '========================================'
echo ""
. "$MODDIR/lib/common.sh" 2>/dev/null || { printf '%s\n' 'ERRO: falha ao carregar lib/common.sh'; exit 1; }
sh "$MODDIR/functions/01_desempenho.sh" >/dev/null 2>&1 || true
sh "$MODDIR/functions/02_jogos.sh" >/dev/null 2>&1 || true
sh "$MODDIR/functions/08_cache.sh" >/dev/null 2>&1 || true
sh "$MODDIR/functions/11_overlays_debug.sh" >/dev/null 2>&1 || true
sh "$MODDIR/functions/12_log_leve.sh" >/dev/null 2>&1 || true
printf '%s\n' 'TM Otimizações: perfil aplicado'
printf '%s\n' 'Animações: 0.0x'
printf '%s\n' 'Cache: limpeza conservadora'
printf '%s\n' 'Overlays de depuração: desativados'
printf '%s\n' 'Logs: verbosidade reduzida'
printf '%s\n' 'Proteção térmica: mantida'
printf '%s\n' 'Processos: sem encerramento aleatório'
echo ""
sh "$MODDIR/functions/13_diagnostico_avancado.sh" 2>/dev/null || true
