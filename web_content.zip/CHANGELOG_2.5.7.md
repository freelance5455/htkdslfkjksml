# ANONYMOUX STUDIO 2.5.7

## Security and account provisioning
- Public registration now always creates standard member accounts; it can no longer grant the first registrant administrator privileges.
- Added a CLI-only, one-time administrator provisioning command with a minimum 12-character password and existing-admin guard.
- Updated registration copy and deployment instructions to explain the secure administrator setup.

## Tools & Tutorials
- Retained the database-backed Tools & Tutorials directory and admin manager, including tool CRUD, logo uploads, HTTPS provider links, category management, draft/publish, search, bulk operations, tutorials, media and related-resource links.
- Clarified the production deployment requirements and administrator workflow.

## Validation
- Full source syntax and bundled regression tests are run as part of this release build.
- Live SQLite/PDO, payment gateway and Fish Audio operations still require staging credentials and the production PHP extensions.
