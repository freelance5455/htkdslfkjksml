# CPLS V2 — Stage 1130
## Live Candle Integrity
- Continued from Stage 1129.
- Stabilized session candle metadata so each candle retains its timeframe bucket timestamp.
- Added a lightweight live-candle progress indicator through the chart connection status tooltip.
- Preserved live price updates, OHLC selection, zoom/pan, persistent Futures REST feed, and WebSocket diagnostics.
- No undocumented Futures WebSocket subscription payload was introduced.
