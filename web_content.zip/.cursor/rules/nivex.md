# NIVEX coding rules
- Keep UI, timeline, render, storage and security modules separate.
- Do not make external AI/editing services runtime dependencies.
- Prefer GPU paths with safe fallbacks.
- Validate imported media before persistence.
- Keep security silent: no verification notifications.
- New effects should have a definition, parameter metadata and a safe preview path.
