M&J'S RIVERSIDE — V3.1 LIVE ANNOUNCEMENT UPDATE

What's added:
- Animated announcement ticker at the top of the customer booking page.
- Admin-only announcement editor in the Admin Control Panel.
- Publish and Disable controls.
- Customer pages receive updates through Supabase Realtime.
- Announcement text is limited to 240 characters.
- Motion is reduced for visitors whose device requests reduced motion.

IMPORTANT — REQUIRED SUPABASE SETUP:
1. Back up the current site and database first.
2. Open Supabase Dashboard > SQL Editor.
3. Run SUPABASE_V3.1_ANNOUNCEMENT_SQL.txt once.
4. Confirm public.site_announcements exists and appears in the supabase_realtime publication.
5. Deploy this ZIP to a Netlify preview/staging site first.
6. Test customer view in a separate browser/device, then login as admin, publish a test announcement, verify it appears and updates, then Disable it.
7. Only after successful testing, deploy to production.

Security:
- Public visitors can only read rows where is_active = true.
- Only authenticated users for whom public.is_admin() returns true can insert/update.
- The announcement table has a single allowed row (id = 1).
- No service-role key is included in the HTML.

Notes:
- This update is based on the uploaded 3.0.zip.
- Existing booking flow, bookings table, rate (PHP 150/hour), booking search, CSV export, monthly summary, admin password change and booking Realtime logic are retained.
- Live behavior has not been tested against the owner's Supabase project from this build environment.
- Supabase Realtime must be enabled and SQL setup must succeed for instant cross-device updates.
