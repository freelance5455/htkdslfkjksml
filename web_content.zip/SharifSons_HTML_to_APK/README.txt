Sharif & Sons Labour Hisab - HTML to APK package

Upload the CONTENT of this folder (or ZIP) to your HTML-to-APK builder.
Main file: index.html
Logo: logo.png

The app is designed for phone use and stores labour/attendance/advance data locally in the browser/app WebView.
