VIRUS SIMULATOR X — Android Web App Project
================================================

This is a SAFE educational simulation. It does not access, scan, modify,
encrypt, delete, or transmit any real device files or data.

Files:
- index.html: complete mobile-friendly simulator (HTML/CSS/JavaScript)

How to use:
1. Upload this ZIP to an Android web-to-APK builder that accepts an HTML/ZIP project.
2. Set the app start page to index.html if the builder asks.
3. Choose an app name such as "Virus Simulator X".
4. Build the APK and review the builder's permissions. This project needs no
   dangerous permissions; it only runs a local webpage.

Note: APK creation is performed by the chosen builder, not by this ZIP itself.
