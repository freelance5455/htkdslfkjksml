document.querySelectorAll(".header__nav").forEach((nav) => {
    const items = [...nav.querySelectorAll("li > a")];
    if (!items.length) return;

    let active = items.findIndex((item) => item.getAttribute("aria-current") === "page");
    if (active < 0) active = 0;

    const center = (index) => {
        const navBounds = nav.getBoundingClientRect();
        const itemBounds = items[index].getBoundingClientRect();
        return itemBounds.left - navBounds.left + itemBounds.width / 2;
    };
    const nearest = (x) => items.reduce(
        (best, _, index) => Math.abs(center(index) - x) < Math.abs(center(best) - x) ? index : best,
        0
    );

    let hovered = null;
    let x = center(active);
    let velocity = 0;
    let target = x;
    let buttonIndex = -1;

    const setVisual = (index) => {
        items.forEach((item, itemIndex) => {
            item.classList.toggle("is-on", itemIndex === index);
            item.classList.toggle("is-under", itemIndex === index);
        });
        if (index !== buttonIndex) {
            floatingButton.innerHTML = items[index].querySelector("svg").outerHTML;
            buttonIndex = index;
        }
    };

    const glass = document.createElement("div");
    glass.className = "nav__glass";
    nav.prepend(glass);

    const shape = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    shape.setAttribute("class", "nav__shape");
    shape.setAttribute("aria-hidden", "true");
    shape.innerHTML = '<path class="nav__surface"/>';
    nav.prepend(shape);

    const floatingButton = document.createElement("div");
    floatingButton.className = "nav__fab";
    floatingButton.setAttribute("aria-hidden", "true");
    nav.appendChild(floatingButton);
    setVisual(active);

    const bump = (width, centerX, bumpWidth, bumpHeight) => {
        centerX = Math.max(bumpWidth / 2, Math.min(width - bumpWidth / 2, centerX));
        const start = centerX - bumpWidth / 2;
        const end = centerX + bumpWidth / 2;
        const curve = bumpWidth * 0.28;
        const bumpY = -bumpHeight;
        return "M" + start + ",0 C" + (start + curve) + ",0 " +
            (centerX - bumpWidth * 0.22) + "," + bumpY + " " + centerX + "," + bumpY +
            " C" + (centerX + bumpWidth * 0.22) + "," + bumpY + " " + (end - curve) +
            ",0 " + end + ",0";
    };

    const selectFromPointer = (event) => {
        const bounds = nav.getBoundingClientRect();
        hovered = nearest(event.clientX - bounds.left);
        target = center(hovered);
        setVisual(hovered);
    };

    nav.addEventListener("pointermove", selectFromPointer);
    nav.addEventListener("pointerleave", () => {
        hovered = null;
        target = center(active);
        setVisual(active);
    });
    nav.addEventListener("focusin", (event) => {
        const item = event.target.closest("a");
        const index = items.indexOf(item);
        if (index >= 0) {
            hovered = index;
            target = center(index);
            setVisual(index);
        }
    });
    nav.addEventListener("focusout", (event) => {
        if (!nav.contains(event.relatedTarget)) {
            hovered = null;
            target = center(active);
            setVisual(active);
        }
    });
    nav.addEventListener("click", (event) => {
        const index = items.indexOf(event.target.closest("a"));
        if (index >= 0) {
            active = index;
            if (hovered === null) target = center(index);
            setVisual(hovered === null ? active : hovered);
        }
    });

    const draw = () => {
        const width = nav.offsetWidth;
        const height = nav.offsetHeight;
        shape.setAttribute("viewBox", "-2 -40 " + (width + 4) + " " + (height + 42));
        shape.querySelector(".nav__surface").setAttribute("d", bump(width, x, 60, 30));

        const selected = hovered === null ? active : hovered;
        setVisual(selected);
        floatingButton.style.transform = "translate(" + (x - 30) + "px, -30px)";
    };

    const animate = () => {
        const spring = hovered === null ? 0.12 : 0.16;
        const damping = hovered === null ? 0.68 : 0.72;
        if (hovered === null) target = center(active);
        velocity = (velocity + (target - x) * spring) * damping;
        x += velocity;
        draw();
        requestAnimationFrame(animate);
    };
    animate();

    window.addEventListener("resize", () => {
        x = center(active);
        target = x;
    });
});
