const products = {
    veg: { name: "Veg Burger", price: 10, image: "veggi.jpg", imageAlt: "Veg burger" },
    chicken: { name: "Chicken Burger", price: 8, image: "MN-Burgers.jpg", imageAlt: "Chicken burger" }
};

const cart = new Map();
const cartElement = document.querySelector("#order-cart");
const totalElement = document.querySelector("#order-total");
const form = document.querySelector("#order-form");
const confirmation = document.querySelector("#order-confirmation");
const orderType = document.querySelector("#order-type");
const locationField = document.querySelector("#customer-location");

const updateLocationField = () => {
    const deliverySelected = orderType.value === "Delivery";
    locationField.closest(".order-location-field").hidden = !deliverySelected;
    locationField.required = deliverySelected;
};

orderType.addEventListener("change", updateLocationField);
updateLocationField();

const formatPrice = (amount) => "₹" + amount.toFixed(2).replace(/\.00$/, "");

const updateQuantityControls = (input) => {
    const quantity = Number(input.value);
    const stepper = input.closest(".quantity-stepper");
    stepper.querySelector('[data-step="-1"]').disabled = quantity <= Number(input.min);
    stepper.querySelector('[data-step="1"]').disabled = quantity >= Number(input.max);
};

document.querySelectorAll(".order-quantity").forEach((input) => {
    updateQuantityControls(input);
    input.addEventListener("input", () => updateQuantityControls(input));
});

document.querySelectorAll(".quantity-step").forEach((button) => {
    button.addEventListener("click", () => {
        const input = button.closest(".quantity-stepper").querySelector(".order-quantity");
        const nextQuantity = Number(input.value) + Number(button.dataset.step);
        input.value = String(Math.max(Number(input.min), Math.min(Number(input.max), nextQuantity)));
        input.dispatchEvent(new Event("input", { bubbles: true }));
    });
});

const renderCart = () => {
    cartElement.replaceChildren();

    if (cart.size === 0) {
        const emptyMessage = document.createElement("p");
        emptyMessage.className = "order-empty";
        emptyMessage.textContent = "Your order is empty. Add a burger to get started.";
        cartElement.append(emptyMessage);
        totalElement.textContent = "₹0";
        return;
    }

    let total = 0;
    for (const [id, quantity] of cart) {
        const product = products[id];
        const lineTotal = product.price * quantity;
        total += lineTotal;

        const row = document.createElement("div");
        row.className = "order-cart-row";

        const image = document.createElement("img");
        image.className = "order-cart-image";
        image.src = product.image;
        image.alt = product.imageAlt;

        const description = document.createElement("span");
        description.textContent = product.name + " × " + quantity;

        const price = document.createElement("strong");
        price.textContent = formatPrice(lineTotal);

        const remove = document.createElement("button");
        remove.className = "order-remove";
        remove.type = "button";
        remove.dataset.remove = id;
        remove.textContent = "Remove";
        remove.setAttribute("aria-label", "Remove " + product.name + " from your order");

        row.append(image, description, price, remove);
        cartElement.append(row);
    }
    totalElement.textContent = formatPrice(total);
};

document.querySelectorAll(".order-add").forEach((button) => {
    button.addEventListener("click", () => {
        const productId = button.dataset.product;
        const quantityInput = button.closest(".order-product").querySelector(".order-quantity");
        const quantity = Number(quantityInput.value);
        if (!products[productId] || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) {
            quantityInput.reportValidity();
            return;
        }

        cart.set(productId, Math.min(99, (cart.get(productId) || 0) + quantity));
        confirmation.hidden = true;
        renderCart();
    });
});

cartElement.addEventListener("click", (event) => {
    const removeButton = event.target.closest("[data-remove]");
    if (!removeButton) return;
    cart.delete(removeButton.dataset.remove);
    renderCart();
});

form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (cart.size === 0) {
        const errorMessage = document.createElement("p");
        errorMessage.className = "order-empty";
        errorMessage.setAttribute("role", "alert");
        errorMessage.textContent = "Add at least one burger before placing your order.";
        cartElement.append(errorMessage);
        cartElement.scrollIntoView({ behavior: "smooth", block: "center" });
        cartElement.classList.add("order-cart-error");
        window.setTimeout(() => cartElement.classList.remove("order-cart-error"), 1200);
        return;
    }

    const formData = new FormData(form);
    const name = formData.get("name").trim();
    const selectedOrderType = formData.get("orderType");
    const items = [...cart].map(([id, quantity]) => {
        const product = products[id];
        return quantity + " × " + product.name + " (" + formatPrice(product.price * quantity) + ")";
    });
    const total = [...cart].reduce((sum, [id, quantity]) => sum + products[id].price * quantity, 0);

    confirmation.replaceChildren();
    const heading = document.createElement("h2");
    heading.textContent = "Demo order prepared";

    const greeting = document.createElement("p");
    greeting.textContent = "Thank you, " + name + ". Your " + selectedOrderType.toLowerCase() + " order preview:";

    const itemList = document.createElement("ul");
    items.forEach((item) => {
        const listItem = document.createElement("li");
        listItem.textContent = item;
        itemList.append(listItem);
    });

    const totalLine = document.createElement("p");
    totalLine.className = "order-confirmation-total";
    totalLine.textContent = "Total: " + formatPrice(total);

    const location = formData.get("location").trim();
    const locationLine = document.createElement("p");
    locationLine.textContent = selectedOrderType === "Delivery" ? "Delivery address: " + location : "";

    const notice = document.createElement("p");
    notice.textContent = "This is a demo confirmation only. The restaurant has not received your order.";

    confirmation.append(heading, greeting, itemList, totalLine);
    if (selectedOrderType === "Delivery") confirmation.append(locationLine);
    confirmation.append(notice);
    confirmation.hidden = false;
    confirmation.scrollIntoView({ behavior: "smooth", block: "center" });
});

renderCart();
