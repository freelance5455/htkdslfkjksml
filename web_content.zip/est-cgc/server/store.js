const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, 'db', 'data.json');

const defaultData = {
  users: [],
  conversations: [],
  conversation_members: [],
  messages: [],
  message_receipts: [],
  media_attachments: [],
  call_logs: [],
  pulse_posts: []
};

function load() {
  try {
    if (fs.existsSync(DB_PATH)) {
      return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    }
  } catch (e) {}
  return structuredClone(defaultData);
}

function save(data) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

let data = load();

// Seed demo user
if (data.users.length === 0) {
  const bcrypt = require('bcryptjs');
  data.users.push({
    id: uuidv4(),
    username: 'demo',
    display_name: 'Demo User',
    password_hash: bcrypt.hashSync('demo1234', 8),
    avatar_url: null,
    created_at: new Date().toISOString(),
    last_seen: null
  });
  save(data);
  console.log('Seeded demo user: username=demo  password=demo1234');
}

module.exports = {
  get() { return data; },
  save() { save(data); },
  // helpers
  findUserByUsername(username) {
    return data.users.find(u => u.username === username);
  },
  findUserById(id) {
    return data.users.find(u => u.id === id);
  },
  addUser(user) {
    data.users.push(user);
    save(data);
    return user;
  },
  updateUser(id, patch) {
    const u = data.users.find(x => x.id === id);
    if (u) Object.assign(u, patch);
    save(data);
  },
  getConversationsForUser(userId) {
    const memberOf = data.conversation_members.filter(m => m.user_id === userId).map(m => m.conversation_id);
    return data.conversations
      .filter(c => memberOf.includes(c.id))
      .map(c => {
        const msgs = data.messages.filter(m => m.conversation_id === c.id && !m.deleted_at).sort((a,b) => a.created_at.localeCompare(b.created_at));
        const last = msgs[msgs.length - 1];
        return {
          ...c,
          last_message: last?.body || null,
          last_message_at: last?.created_at || null
        };
      })
      .sort((a, b) => (b.last_message_at || '').localeCompare(a.last_message_at || ''));
  },
  addConversation(conv, memberIds) {
    data.conversations.push(conv);
    memberIds.forEach((uid, i) => {
      data.conversation_members.push({
        conversation_id: conv.id,
        user_id: uid,
        role: i === 0 ? 'admin' : 'member',
        joined_at: new Date().toISOString()
      });
    });
    save(data);
    return conv;
  },
  getMessages(conversationId) {
    return data.messages
      .filter(m => m.conversation_id === conversationId && !m.deleted_at)
      .sort((a, b) => a.created_at.localeCompare(b.created_at))
      .map(m => {
        const sender = data.users.find(u => u.id === m.sender_id);
        return {
          ...m,
          sender_name: sender?.display_name,
          sender_avatar: sender?.avatar_url
        };
      });
  },
  addMessage(msg) {
    data.messages.push(msg);
    save(data);
    const sender = data.users.find(u => u.id === msg.sender_id);
    return { ...msg, sender_name: sender?.display_name, sender_avatar: sender?.avatar_url };
  },
  searchUsers(q, excludeId) {
    const lower = q.toLowerCase();
    return data.users
      .filter(u => u.id !== excludeId && (u.username.toLowerCase().includes(lower) || u.display_name.toLowerCase().includes(lower)))
      .slice(0, 20)
      .map(({ id, username, display_name, avatar_url }) => ({ id, username, display_name, avatar_url }));
  },
  getPulse() {
    return data.pulse_posts
      .map(p => {
        const u = data.users.find(x => x.id === p.user_id);
        return { ...p, display_name: u?.display_name, avatar_url: u?.avatar_url, username: u?.username };
      })
      .sort((a, b) => {
        if (a.is_pinned !== b.is_pinned) return b.is_pinned - a.is_pinned;
        return b.created_at.localeCompare(a.created_at);
      })
      .slice(0, 50);
  },
  addPulse(post) {
    data.pulse_posts.push(post);
    save(data);
    const u = data.users.find(x => x.id === post.user_id);
    return { ...post, display_name: u?.display_name, avatar_url: u?.avatar_url, username: u?.username };
  }
};
