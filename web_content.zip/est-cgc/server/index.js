const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const store = require('./store');

const JWT_SECRET = process.env.JWT_SECRET || 'est-cgc-super-secret-key-change-in-production-2026';
const PORT = process.env.PORT || 3001;

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use('/uploads', express.static(uploadsDir));

const clientDist = path.join(__dirname, '../client/dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
}

function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'No token' });
  try {
    const token = header.replace('Bearer ', '');
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// AUTH
app.post('/api/register', (req, res) => {
  const { username, password, display_name } = req.body;
  if (!username || !password || !display_name) {
    return res.status(400).json({ error: 'الحقول مطلوبة' });
  }
  if (store.findUserByUsername(username)) {
    return res.status(400).json({ error: 'اسم المستخدم مستخدم مسبقاً' });
  }
  const id = uuidv4();
  const user = {
    id,
    username,
    display_name,
    password_hash: bcrypt.hashSync(password, 8),
    avatar_url: null,
    created_at: new Date().toISOString(),
    last_seen: null
  };
  store.addUser(user);
  const token = jwt.sign({ id, username, display_name }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: { id, username, display_name } });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = store.findUserByUsername(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }
  store.updateUser(user.id, { last_seen: new Date().toISOString() });
  const token = jwt.sign({ id: user.id, username: user.username, display_name: user.display_name }, JWT_SECRET, { expiresIn: '30d' });
  res.json({
    token,
    user: { id: user.id, username: user.username, display_name: user.display_name, avatar_url: user.avatar_url }
  });
});

app.get('/api/me', auth, (req, res) => {
  const user = store.findUserById(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({
    id: user.id,
    username: user.username,
    display_name: user.display_name,
    avatar_url: user.avatar_url,
    created_at: user.created_at,
    last_seen: user.last_seen
  });
});

// CONVERSATIONS
app.get('/api/conversations', auth, (req, res) => {
  res.json(store.getConversationsForUser(req.user.id));
});

app.post('/api/conversations', auth, (req, res) => {
  const { type = 'direct', title, member_ids = [] } = req.body;
  const id = uuidv4();
  const conv = {
    id,
    type,
    title: title || null,
    avatar_url: null,
    created_by: req.user.id,
    created_at: new Date().toISOString()
  };
  const allMembers = [...new Set([req.user.id, ...member_ids])];
  store.addConversation(conv, allMembers);
  res.json(conv);
});

app.get('/api/conversations/:id/messages', auth, (req, res) => {
  res.json(store.getMessages(req.params.id));
});

// USERS
app.get('/api/users/search', auth, (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.json([]);
  res.json(store.searchUsers(q, req.user.id));
});

// UPLOAD
const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 25 * 1024 * 1024 } });

app.post('/api/upload', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  res.json({
    url: `/uploads/${req.file.filename}`,
    filename: req.file.filename,
    size: req.file.size,
    mimetype: req.file.mimetype
  });
});

// PULSE
app.get('/api/pulse', auth, (req, res) => {
  res.json(store.getPulse());
});

app.post('/api/pulse', auth, (req, res) => {
  const { content, is_pinned = false } = req.body;
  if (!content) return res.status(400).json({ error: 'المحتوى مطلوب' });
  const post = {
    id: uuidv4(),
    user_id: req.user.id,
    content,
    is_pinned: is_pinned ? 1 : 0,
    created_at: new Date().toISOString()
  };
  const full = store.addPulse(post);
  io.emit('pulse:new', full);
  res.json(full);
});

// AI (placeholder)
app.post('/api/ai/chat', auth, (req, res) => {
  const { prompt, messages } = req.body;
  const last = messages?.[messages.length - 1]?.content || prompt || '';
  const reply = `أنا مساعد EST-CGC الذكي (نسخة تجريبية).\n\nطلبتَ: "${String(last).slice(0, 150)}"\n\nلربط GPT الحقيقي ضع مفتاح OPENAI_API_KEY في متغيرات البيئة على السيرفر.`;
  res.json({ reply });
});

// SOCKET.IO
const onlineUsers = new Map();

io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Auth required'));
  try {
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const userId = socket.user.id;
  onlineUsers.set(userId, socket.id);
  store.updateUser(userId, { last_seen: new Date().toISOString() });
  socket.broadcast.emit('presence:update', { userId, status: 'online' });

  socket.on('join:conversation', (conversationId) => {
    socket.join(`conv:${conversationId}`);
  });

  socket.on('message:send', (payload) => {
    const { conversation_id, body, type = 'text', reply_to_id } = payload;
    if (!conversation_id || !body) return;
    const msg = {
      id: uuidv4(),
      conversation_id,
      sender_id: userId,
      type,
      body,
      reply_to_id: reply_to_id || null,
      reactions: '{}',
      is_pinned: 0,
      created_at: new Date().toISOString(),
      edited_at: null,
      deleted_at: null
    };
    const full = store.addMessage(msg);
    io.to(`conv:${conversation_id}`).emit('message:new', full);
  });

  socket.on('typing:start', ({ conversation_id }) => {
    socket.to(`conv:${conversation_id}`).emit('typing:start', {
      conversation_id,
      userId,
      display_name: socket.user.display_name
    });
  });

  socket.on('typing:stop', ({ conversation_id }) => {
    socket.to(`conv:${conversation_id}`).emit('typing:stop', { conversation_id, userId });
  });

  socket.on('disconnect', () => {
    onlineUsers.delete(userId);
    store.updateUser(userId, { last_seen: new Date().toISOString() });
    socket.broadcast.emit('presence:update', { userId, status: 'offline' });
  });
});

app.get('*', (req, res) => {
  const indexPath = path.join(clientDist, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>EST-CGC</title></head>
<body style="background:#0B0E14;color:#00F0FF;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center">
<div><h1>EST-CGC Server</h1><p style="color:#C0C5CE">Produced by EST</p><p style="color:#8A919C;font-size:14px">Frontend not built yet. Run client separately.</p></div>
</body></html>`);
  }
});

server.listen(PORT, () => {
  console.log(`\n🚀 EST-CGC Server running → http://localhost:${PORT}`);
  console.log(`   Produced by EST\n`);
});
