import Fastify from 'fastify';
import cors from '@fastify/cors';
import multipart from '@fastify/multipart';
import fastifyStatic from '@fastify/static';
import { Server } from 'socket.io';
import { createServer } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import Database from 'better-sqlite3';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'est-cgc-super-secret-change-in-production';
const UPLOAD_DIR = path.join(__dirname, '../uploads');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ---------- Database ----------
const db = new Database(path.join(__dirname, '../est-cgc.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_url TEXT,
    status TEXT DEFAULT 'Hey there! I am using EST-CGC',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL CHECK(type IN ('direct','group','broadcast')),
    title TEXT,
    avatar_url TEXT,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS conversation_members (
    conversation_id TEXT,
    user_id TEXT,
    role TEXT DEFAULT 'member',
    joined_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (conversation_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    type TEXT DEFAULT 'text',
    body TEXT,
    reply_to_id TEXT,
    reactions TEXT DEFAULT '{}',
    is_pinned INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    edited_at TEXT,
    deleted_at TEXT
  );

  CREATE TABLE IF NOT EXISTS message_receipts (
    message_id TEXT,
    user_id TEXT,
    status TEXT DEFAULT 'sent',
    updated_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (message_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS media (
    id TEXT PRIMARY KEY,
    message_id TEXT,
    type TEXT,
    filename TEXT,
    url TEXT,
    size_bytes INTEGER,
    duration_ms INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS call_logs (
    id TEXT PRIMARY KEY,
    conversation_id TEXT,
    initiator_id TEXT,
    participants TEXT,
    status TEXT,
    started_at TEXT,
    ended_at TEXT,
    duration_sec INTEGER
  );

  CREATE TABLE IF NOT EXISTS pulse_posts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    body TEXT NOT NULL,
    is_pinned INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Seed demo user if empty
const userCount = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
if (userCount === 0) {
  const id = uuidv4();
  const hash = bcrypt.hashSync('demo1234', 10);
  db.prepare(`INSERT INTO users (id, username, display_name, password_hash, status)
              VALUES (?, ?, ?, ?, ?)`).run(id, 'demo', 'EST Demo User', hash, 'Produced by EST');
  console.log('Seeded demo user → username: demo / password: demo1234');
}

// ---------- Fastify + HTTP + Socket.IO ----------
const fastify = Fastify({ logger: false });
const httpServer = createServer(fastify.server);
const io = new Server(httpServer, {
  cors: { origin: '*' }
});

await fastify.register(cors, { origin: true });
await fastify.register(multipart, { limits: { fileSize: 25 * 1024 * 1024 } });
await fastify.register(fastifyStatic, {
  root: UPLOAD_DIR,
  prefix: '/uploads/'
});

// Auth helper
function auth(req, reply, done) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return reply.code(401).send({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(header.slice(7), JWT_SECRET);
    done();
  } catch {
    reply.code(401).send({ error: 'Invalid token' });
  }
}

// ---------- REST API ----------
fastify.post('/api/auth/register', async (req, reply) => {
  const { username, password, displayName } = req.body;
  if (!username || !password) return reply.code(400).send({ error: 'Missing fields' });
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) return reply.code(409).send({ error: 'Username taken' });
  const id = uuidv4();
  const hash = await bcrypt.hash(password, 10);
  db.prepare('INSERT INTO users (id, username, display_name, password_hash) VALUES (?, ?, ?, ?)')
    .run(id, username, displayName || username, hash);
  const token = jwt.sign({ id, username }, JWT_SECRET, { expiresIn: '7d' });
  return { token, user: { id, username, displayName: displayName || username } };
});

fastify.post('/api/auth/login', async (req, reply) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return reply.code(401).send({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
  return {
    token,
    user: {
      id: user.id,
      username: user.username,
      displayName: user.display_name,
      avatarUrl: user.avatar_url,
      status: user.status
    }
  };
});

fastify.get('/api/me', { preHandler: auth }, (req) => {
  const user = db.prepare('SELECT id, username, display_name as displayName, avatar_url as avatarUrl, status FROM users WHERE id = ?').get(req.user.id);
  return user;
});

fastify.get('/api/conversations', { preHandler: auth }, (req) => {
  const rows = db.prepare(`
    SELECT c.*, 
      (SELECT body FROM messages m WHERE m.conversation_id = c.id AND m.deleted_at IS NULL ORDER BY m.created_at DESC LIMIT 1) as last_message,
      (SELECT created_at FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) as last_at
    FROM conversations c
    JOIN conversation_members cm ON cm.conversation_id = c.id
    WHERE cm.user_id = ?
    ORDER BY last_at DESC NULLS LAST
  `).all(req.user.id);
  return rows;
});

fastify.get('/api/conversations/:id/messages', { preHandler: auth }, (req) => {
  const messages = db.prepare(`
    SELECT m.*, u.display_name as sender_name, u.avatar_url as sender_avatar
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.conversation_id = ? AND m.deleted_at IS NULL
    ORDER BY m.created_at ASC
    LIMIT 200
  `).all(req.params.id);
  return messages;
});

fastify.post('/api/conversations', { preHandler: auth }, (req) => {
  const { type = 'direct', title, memberIds = [] } = req.body;
  const id = uuidv4();
  db.prepare('INSERT INTO conversations (id, type, title, created_by) VALUES (?, ?, ?, ?)')
    .run(id, type, title || null, req.user.id);
  const allMembers = [...new Set([req.user.id, ...memberIds])];
  const insert = db.prepare('INSERT INTO conversation_members (conversation_id, user_id, role) VALUES (?, ?, ?)');
  allMembers.forEach(uid => insert.run(id, uid, uid === req.user.id ? 'admin' : 'member'));
  return { id, type, title };
});

fastify.get('/api/pulse', { preHandler: auth }, () => {
  return db.prepare(`
    SELECT p.*, u.display_name, u.avatar_url
    FROM pulse_posts p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.is_pinned DESC, p.created_at DESC
    LIMIT 50
  `).all();
});

fastify.post('/api/pulse', { preHandler: auth }, (req) => {
  const id = uuidv4();
  db.prepare('INSERT INTO pulse_posts (id, user_id, body) VALUES (?, ?, ?)').run(id, req.user.id, req.body.body);
  return { id };
});

fastify.get('/api/vault', { preHandler: auth }, (req) => {
  return db.prepare(`
    SELECT m.*, msg.conversation_id, msg.created_at as shared_at
    FROM media m
    JOIN messages msg ON msg.id = m.message_id
    JOIN conversation_members cm ON cm.conversation_id = msg.conversation_id
    WHERE cm.user_id = ?
    ORDER BY m.created_at DESC
    LIMIT 100
  `).all(req.user.id);
});

fastify.get('/api/calls', { preHandler: auth }, (req) => {
  return db.prepare('SELECT * FROM call_logs ORDER BY started_at DESC LIMIT 50').all();
});

// Simple AI proxy (user must set OPENAI_API_KEY)
fastify.post('/api/ai/chat', { preHandler: auth }, async (req, reply) => {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return reply.code(503).send({ error: 'AI not configured. Set OPENAI_API_KEY on server.' });
  const { messages } = req.body;
  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are EST-CGC AI assistant, a concise helpful companion inside a secure messaging app produced by EST. Keep answers short and practical.' },
          ...messages
        ],
        max_tokens: 400
      })
    });
    const data = await res.json();
    return { reply: data.choices?.[0]?.message?.content || 'No response' };
  } catch (e) {
    return reply.code(500).send({ error: e.message });
  }
});

// File upload
fastify.post('/api/upload', { preHandler: auth }, async (req) => {
  const data = await req.file();
  const filename = `${uuidv4()}-${data.filename}`;
  const filepath = path.join(UPLOAD_DIR, filename);
  await fs.promises.writeFile(filepath, await data.toBuffer());
  return { url: `/uploads/${filename}`, filename, size: data.file.bytesRead };
});

// ---------- Socket.IO Real-time ----------
const onlineUsers = new Map(); // userId -> socketId

io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Auth required'));
  try {
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const userId = socket.user.id;
  onlineUsers.set(userId, socket.id);
  socket.join(`user:${userId}`);
  console.log(`User connected: ${socket.user.username}`);

  // Join all conversations
  const convs = db.prepare('SELECT conversation_id FROM conversation_members WHERE user_id = ?').all(userId);
  convs.forEach(c => socket.join(`conv:${c.conversation_id}`));

  socket.on('message:send', (payload) => {
    const { conversationId, body, type = 'text', replyToId } = payload;
    const id = uuidv4();
    db.prepare(`INSERT INTO messages (id, conversation_id, sender_id, type, body, reply_to_id)
                VALUES (?, ?, ?, ?, ?, ?)`).run(id, conversationId, userId, type, body, replyToId || null);

    // Receipts for other members
    const members = db.prepare('SELECT user_id FROM conversation_members WHERE conversation_id = ?').all(conversationId);
    const insertReceipt = db.prepare('INSERT INTO message_receipts (message_id, user_id, status) VALUES (?, ?, ?)');
    members.forEach(m => {
      insertReceipt.run(id, m.user_id, m.user_id === userId ? 'read' : 'sent');
    });

    const message = db.prepare(`
      SELECT m.*, u.display_name as sender_name, u.avatar_url as sender_avatar
      FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?
    `).get(id);

    io.to(`conv:${conversationId}`).emit('message:new', message);
  });

  socket.on('typing:start', ({ conversationId }) => {
    socket.to(`conv:${conversationId}`).emit('typing:start', { conversationId, userId, username: socket.user.username });
  });

  socket.on('typing:stop', ({ conversationId }) => {
    socket.to(`conv:${conversationId}`).emit('typing:stop', { conversationId, userId });
  });

  socket.on('receipt:update', ({ messageId, status }) => {
    db.prepare('UPDATE message_receipts SET status = ?, updated_at = datetime("now") WHERE message_id = ? AND user_id = ?')
      .run(status, messageId, userId);
    // Notify sender if needed
  });

  socket.on('disconnect', () => {
    onlineUsers.delete(userId);
    console.log(`User disconnected: ${socket.user.username}`);
  });
});

// ---------- Start ----------
httpServer.listen(PORT, () => {
  console.log(`\n🚀 EST-CGC Server running on http://localhost:${PORT}`);
  console.log(`   Produced by EST\n`);
});
