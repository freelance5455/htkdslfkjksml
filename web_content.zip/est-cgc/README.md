# EST-CGC
**Produced by EST** · Lightweight Instant Messaging Platform

## ما هو هذا المشروع؟

منصة مراسلة فورية خفيفة الوزن مبنية كـ Progressive Web App، تتضمن:

- رسائل فورية حقيقية عبر Socket.IO (إيصالات تسليم، مؤشر الكتابة)
- نظام تبويب خماسي: CGC Secure · Pulse Board · Vault · Comms Hub · Core
- تسجيل دخول / تسجيل حساب
- بحث عن مستخدمين وبدء محادثات مباشرة
- لوحة Pulse للتحديثات
- مساعد ذكاء اصطناعي (تجريبي)
- تصميم Dark Obsidian + Neon Cyan
- شعار "Produced by EST" / "Powered by EST" في كل الأماكن المطلوبة

## التشغيل المحلي (على جهازك)

### المتطلبات
- Node.js 18 أو أحدث
- npm

### الخطوات

```bash
# 1. انسخ المشروع إلى جهازك
cd est-cgc

# 2. تثبيت اعتماديات السيرفر
npm install

# 3. تثبيت اعتماديات الواجهة
cd client
npm install
cd ..

# 4. تشغيل السيرفر (نافذة أولى)
npm run server

# 5. تشغيل الواجهة (نافذة ثانية)
cd client
npm run dev
```

ثم افتح المتصفح على العنوان الذي يظهره Vite (عادة `http://localhost:5173`).

### حساب تجريبي جاهز
- اسم المستخدم: `demo`
- كلمة المرور: `demo1234`

يمكنك إنشاء حسابات جديدة من شاشة التسجيل ومشاركة المنصة مع أصدقائك على نفس الشبكة المحلية، أو رفعها على استضافة (Vercel + Railway / Render / VPS).

## ملاحظات مهمة

- هذه نسخة ويب كاملة الوظائف الأساسية، وليست تطبيق Native (Flutter/iOS/Android).
- المكالمات الصوتية (WebRTC) والـ Vault المتقدمة والـ AI الحقيقي تحتاج ربط مفاتيح وخدمات إضافية.
- البيانات تُحفظ محلياً في ملف JSON (`server/db/data.json`).

## Produced by EST
