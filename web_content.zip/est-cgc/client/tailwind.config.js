/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        obsidian: '#0B0E14',
        surface: '#12151C',
        border: '#1E232D',
        cyan: '#00F0FF',
        silver: '#C0C5CE',
        muted: '#8A919C',
        danger: '#FF4D6A'
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif']
      }
    }
  },
  plugins: []
}
