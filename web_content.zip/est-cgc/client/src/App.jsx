import React, { useState, useEffect, useRef, useCallback } from 'react'
import { io } from 'socket.io-client'
import {
  MessageCircle, Radio, Archive, Phone, Settings,
  Send, Plus, ArrowRight, Sparkles, Search, LogOut,
  User, Shield, Bell, Lock, Mic, Paperclip, X
} from 'lucide-react'

const API = import.meta.env.VITE_API_URL || ''
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || window.location.origin

function App() {
  const [phase, setPhase] = useState('splash') // splash | auth | app
  const [authMode, setAuthMode] = useState('login')
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(localStorage.getItem('est_token') || '')
  const [tab, setTab] = useState('cgc')
  const [conversations, setConversations] = useState([])
  const [activeConv, setActiveConv] = useState(null)
  const [messages, setMessages] = useState([])
  const [msgInput, setMsgInput] = useState('')
  const [pulse, setPulse] = useState([])
  const [folder, setFolder] = useState('all')
  const [showNewChat, setShowNewChat] = useState(false)
  const [searchQ, setSearchQ] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [typingUsers, setTypingUsers] = useState({})
  const [aiOpen, setAiOpen] = useState(false)
  const [aiInput, setAiInput] = useState('')
  const [aiReply, setAiReply] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const socketRef = useRef(null)
  const messagesEndRef = useRef(null)
  const typingTimeout = useRef(null)

  // Splash
  useEffect(() => {
    const t = setTimeout(() => {
      if (token) {
        fetchMe(token)
      } else {
        setPhase('auth')
      }
    }, 1800)
    return () => clearTimeout(t)
  }, [])

  const fetchMe = async (tok) => {
    try {
      const res = await fetch(`${API}/api/me`, {
        headers: { Authorization: `Bearer ${tok}` }
      })
      if (!res.ok) throw new Error('invalid')
      const data = await res.json()
      setUser(data)
      setToken(tok)
      localStorage.setItem('est_token', tok)
      setPhase('app')
      connectSocket(tok)
      loadConversations(tok)
      loadPulse(tok)
    } catch {
      localStorage.removeItem('est_token')
      setToken('')
      setPhase('auth')
    }
  }

  const connectSocket = (tok) => {
    if (socketRef.current) socketRef.current.disconnect()
    const s = io(SOCKET_URL, { auth: { token: tok }, transports: ['websocket', 'polling'] })
    socketRef.current = s

    s.on('connect', () => console.log('EST-CGC socket connected'))
    s.on('message:new', (msg) => {
      setMessages(prev => {
        if (prev.find(m => m.id === msg.id)) return prev
        return [...prev, msg]
      })
      loadConversations(tok)
    })
    s.on('typing:start', ({ conversation_id, userId, display_name }) => {
      setTypingUsers(prev => ({ ...prev, [conversation_id]: display_name }))
    })
    s.on('typing:stop', ({ conversation_id }) => {
      setTypingUsers(prev => {
        const n = { ...prev }
        delete n[conversation_id]
        return n
      })
    })
    s.on('pulse:new', (post) => {
      setPulse(prev => [post, ...prev])
    })
  }

  const loadConversations = async (tok = token) => {
    const res = await fetch(`${API}/api/conversations`, {
      headers: { Authorization: `Bearer ${tok}` }
    })
    if (res.ok) setConversations(await res.json())
  }

  const loadPulse = async (tok = token) => {
    const res = await fetch(`${API}/api/pulse`, {
      headers: { Authorization: `Bearer ${tok}` }
    })
    if (res.ok) setPulse(await res.json())
  }

  const openConversation = async (conv) => {
    setActiveConv(conv)
    socketRef.current?.emit('join:conversation', conv.id)
    const res = await fetch(`${API}/api/conversations/${conv.id}/messages`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    if (res.ok) {
      const msgs = await res.json()
      setMessages(msgs)
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
    }
  }

  const sendMessage = () => {
    if (!msgInput.trim() || !activeConv) return
    socketRef.current?.emit('message:send', {
      conversation_id: activeConv.id,
      body: msgInput.trim(),
      type: 'text'
    })
    setMsgInput('')
    socketRef.current?.emit('typing:stop', { conversation_id: activeConv.id })
  }

  const handleTyping = (val) => {
    setMsgInput(val)
    if (!activeConv) return
    socketRef.current?.emit('typing:start', { conversation_id: activeConv.id })
    clearTimeout(typingTimeout.current)
    typingTimeout.current = setTimeout(() => {
      socketRef.current?.emit('typing:stop', { conversation_id: activeConv.id })
    }, 1500)
  }

  const handleAuth = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    const form = new FormData(e.target)
    const body = Object.fromEntries(form)
    try {
      const endpoint = authMode === 'login' ? '/api/login' : '/api/register'
      const res = await fetch(`${API}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'فشل')
      localStorage.setItem('est_token', data.token)
      setToken(data.token)
      setUser(data.user)
      setPhase('app')
      connectSocket(data.token)
      loadConversations(data.token)
      loadPulse(data.token)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const searchUsers = async (q) => {
    setSearchQ(q)
    if (q.length < 2) return setSearchResults([])
    const res = await fetch(`${API}/api/users/search?q=${encodeURIComponent(q)}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    if (res.ok) setSearchResults(await res.json())
  }

  const startDirectChat = async (targetUser) => {
    const res = await fetch(`${API}/api/conversations`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: 'direct',
        title: targetUser.display_name,
        member_ids: [targetUser.id]
      })
    })
    if (res.ok) {
      const conv = await res.json()
      setShowNewChat(false)
      loadConversations()
      openConversation(conv)
    }
  }

  const postPulse = async () => {
    const content = prompt('اكتب تحديث الحالة:')
    if (!content) return
    await fetch(`${API}/api/pulse`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ content })
    })
    loadPulse()
  }

  const askAI = async () => {
    if (!aiInput.trim()) return
    setLoading(true)
    setAiReply('')
    try {
      const res = await fetch(`${API}/api/ai/chat`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prompt: aiInput })
      })
      const data = await res.json()
      setAiReply(data.reply || 'لا يوجد رد')
    } catch {
      setAiReply('خطأ في الاتصال بالمساعد')
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    localStorage.removeItem('est_token')
    socketRef.current?.disconnect()
    setToken('')
    setUser(null)
    setPhase('auth')
  }

  // ========== RENDER ==========
  if (phase === 'splash') {
    return (
      <div className="splash">
        <div className="splash-logo">EST-CGC</div>
        <div style={{ width: 60, height: 2, background: 'var(--cyan)', borderRadius: 2, boxShadow: '0 0 12px var(--cyan)' }} />
        <div className="splash-badge">Produced by EST</div>
      </div>
    )
  }

  if (phase === 'auth') {
    return (
      <div className="auth-screen">
        <div className="auth-card">
          <div className="auth-title">EST-CGC</div>
          <div className="auth-sub">Powered by EST</div>
          <form onSubmit={handleAuth}>
            {authMode === 'register' && (
              <div className="form-group">
                <label>الاسم الظاهر</label>
                <input name="display_name" required placeholder="اسمك" />
              </div>
            )}
            <div className="form-group">
              <label>اسم المستخدم</label>
              <input name="username" required placeholder="username" autoComplete="username" />
            </div>
            <div className="form-group">
              <label>كلمة المرور</label>
              <input name="password" type="password" required placeholder="••••••••" autoComplete="current-password" />
            </div>
            {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
            <button className="btn-primary" disabled={loading}>
              {loading ? 'جاري...' : authMode === 'login' ? 'دخول' : 'إنشاء حساب'}
            </button>
          </form>
          <div className="auth-switch">
            {authMode === 'login' ? (
              <>ليس لديك حساب؟ <span onClick={() => setAuthMode('register')}>سجّل الآن</span></>
            ) : (
              <>لديك حساب؟ <span onClick={() => setAuthMode('login')}>سجّل دخول</span></>
            )}
          </div>
        </div>
        <div className="auth-footer">Powered by EST</div>
      </div>
    )
  }

  // Main App
  return (
    <div className="app-shell">
      <div className="app-content">
        {/* ===== CGC SECURE ===== */}
        {tab === 'cgc' && !activeConv && (
          <div className="screen">
            <div className="screen-header">
              <div className="screen-title">CGC Secure</div>
              <Search size={20} color="var(--muted)" />
            </div>
            <div className="folder-chips">
              {['all', 'direct', 'group', 'broadcast'].map(f => (
                <button key={f} className={`chip ${folder === f ? 'active' : ''}`} onClick={() => setFolder(f)}>
                  {f === 'all' ? 'الكل' : f === 'direct' ? 'مباشر' : f === 'group' ? 'مجموعات' : 'بث'}
                </button>
              ))}
            </div>
            <div className="conv-list">
              {conversations.length === 0 ? (
                <div className="empty-state">
                  <MessageCircle size={40} strokeWidth={1.2} />
                  <div>لا توجد محادثات بعد</div>
                  <div style={{ fontSize: 12 }}>ابدأ محادثة جديدة مع أصدقائك</div>
                </div>
              ) : (
                conversations
                  .filter(c => folder === 'all' || c.type === folder)
                  .map(c => (
                    <div key={c.id} className="conv-item" onClick={() => openConversation(c)}>
                      <div className="avatar">{(c.title || '?')[0]}</div>
                      <div className="conv-info">
                        <div className="conv-name">{c.title || 'محادثة'}</div>
                        <div className="conv-preview">{c.last_message || 'ابدأ المحادثة'}</div>
                      </div>
                      <div className="conv-meta">
                        {c.last_message_at ? new Date(c.last_message_at).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' }) : ''}
                      </div>
                    </div>
                  ))
              )}
            </div>
            <button className="fab" onClick={() => setShowNewChat(true)}>
              <Plus size={26} />
            </button>
          </div>
        )}

        {/* Chat Thread */}
        {tab === 'cgc' && activeConv && (
          <div className="chat-view">
            <div className="chat-header">
              <button className="back-btn" onClick={() => setActiveConv(null)}>
                <ArrowRight size={22} />
              </button>
              <div className="avatar" style={{ width: 36, height: 36, fontSize: 13 }}>
                {(activeConv.title || '?')[0]}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 500, fontSize: 15 }}>{activeConv.title}</div>
                <div style={{ fontSize: 11, color: 'var(--muted)' }}>
                  {typingUsers[activeConv.id] ? `${typingUsers[activeConv.id]} يكتب...` : 'متصل'}
                </div>
              </div>
              <button onClick={() => setAiOpen(true)} style={{ color: 'var(--cyan)' }}>
                <Sparkles size={20} />
              </button>
            </div>
            <div className="messages-area">
              {messages.map(m => (
                <div key={m.id} className={`msg ${m.sender_id === user.id ? 'own' : 'other'}`}>
                  {m.sender_id !== user.id && (
                    <div style={{ fontSize: 11, color: 'var(--cyan)', marginBottom: 3 }}>{m.sender_name}</div>
                  )}
                  <div>{m.body}</div>
                  <div className="msg-meta">
                    {new Date(m.created_at).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <div className="input-bar">
              <button className="attach-btn"><Paperclip size={18} /></button>
              <input
                value={msgInput}
                onChange={e => handleTyping(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
                placeholder="اكتب رسالة..."
              />
              <button className="ai-btn" onClick={() => setAiOpen(true)}><Sparkles size={18} /></button>
              <button className="send-btn" onClick={sendMessage}><Send size={18} /></button>
            </div>
          </div>
        )}

        {/* ===== PULSE BOARD ===== */}
        {tab === 'pulse' && (
          <div className="screen">
            <div className="screen-header">
              <div className="screen-title">Pulse Board</div>
              <button onClick={postPulse} style={{ color: 'var(--cyan)', fontSize: 13, fontWeight: 500 }}>+ تحديث</button>
            </div>
            <div className="pulse-list">
              {pulse.length === 0 ? (
                <div className="empty-state">
                  <Radio size={40} strokeWidth={1.2} />
                  <div>لا توجد تحديثات بعد</div>
                </div>
              ) : pulse.map(p => (
                <div key={p.id} className="pulse-card">
                  <div className="pulse-author">{p.display_name}</div>
                  <div className="pulse-content">{p.content}</div>
                  <div className="pulse-time">{new Date(p.created_at).toLocaleString('ar')}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ===== VAULT ===== */}
        {tab === 'vault' && (
          <div className="screen">
            <div className="screen-header">
              <div className="screen-title">Vault</div>
            </div>
            <div className="empty-state">
              <Archive size={40} strokeWidth={1.2} />
              <div>مدير الوسائط</div>
              <div style={{ fontSize: 12 }}>جميع الصور والفيديوهات والمستندات والرسائل الصوتية ستظهر هنا</div>
            </div>
          </div>
        )}

        {/* ===== COMMS HUB ===== */}
        {tab === 'comms' && (
          <div className="screen">
            <div className="screen-header">
              <div className="screen-title">Comms Hub</div>
            </div>
            <div className="empty-state">
              <Phone size={40} strokeWidth={1.2} />
              <div>المكالمات الصوتية</div>
              <div style={{ fontSize: 12 }}>سجل المكالمات والمكالمات الواردة ستظهر هنا.<br />WebRTC جاهز للربط لاحقاً.</div>
            </div>
          </div>
        )}

        {/* ===== CORE ===== */}
        {tab === 'core' && (
          <div className="screen">
            <div className="screen-header">
              <div className="screen-title">Core</div>
            </div>
            <div className="core-content">
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px 8px 20px' }}>
                <div className="avatar" style={{ width: 64, height: 64, fontSize: 22 }}>
                  {(user?.display_name || 'U')[0]}
                </div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 600 }}>{user?.display_name}</div>
                  <div style={{ fontSize: 13, color: 'var(--muted)' }}>@{user?.username}</div>
                </div>
              </div>

              <div className="core-section">
                <div className="core-item"><span><User size={16} style={{ marginLeft: 8, verticalAlign: -3 }} /> الملف الشخصي</span></div>
                <div className="core-item"><span><Shield size={16} style={{ marginLeft: 8, verticalAlign: -3 }} /> الأمان والخصوصية</span></div>
                <div className="core-item"><span><Lock size={16} style={{ marginLeft: 8, verticalAlign: -3 }} /> قفل التطبيق (بصمة)</span></div>
                <div className="core-item"><span><Bell size={16} style={{ marginLeft: 8, verticalAlign: -3 }} /> الإشعارات</span></div>
              </div>

              <div className="core-section">
                <div className="core-item" onClick={logout} style={{ color: 'var(--danger)', cursor: 'pointer' }}>
                  <span><LogOut size={16} style={{ marginLeft: 8, verticalAlign: -3 }} /> تسجيل الخروج</span>
                </div>
              </div>

              <div className="core-footer">
                <strong>Produced by EST</strong><br />
                EST-CGC v1.0.0
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <nav className="bottom-nav">
        {[
          { id: 'cgc', icon: MessageCircle, label: 'CGC Secure' },
          { id: 'pulse', icon: Radio, label: 'Pulse' },
          { id: 'vault', icon: Archive, label: 'Vault' },
          { id: 'comms', icon: Phone, label: 'Comms' },
          { id: 'core', icon: Settings, label: 'Core' },
        ].map(item => (
          <button
            key={item.id}
            className={`nav-item ${tab === item.id ? 'active' : ''}`}
            onClick={() => { setTab(item.id); setActiveConv(null) }}
          >
            <item.icon size={22} strokeWidth={tab === item.id ? 2.2 : 1.6} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      {/* New Chat Modal */}
      {showNewChat && (
        <div className="modal-overlay" onClick={() => setShowNewChat(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3>محادثة جديدة</h3>
              <button onClick={() => setShowNewChat(false)}><X size={20} /></button>
            </div>
            <input
              placeholder="ابحث عن مستخدم..."
              value={searchQ}
              onChange={e => searchUsers(e.target.value)}
              style={{
                width: '100%', padding: '12px 14px', background: 'var(--bg)',
                border: '1px solid var(--border)', borderRadius: 10, color: 'var(--silver)', marginBottom: 12
              }}
            />
            {searchResults.map(u => (
              <div key={u.id} className="conv-item" onClick={() => startDirectChat(u)}>
                <div className="avatar">{u.display_name[0]}</div>
                <div className="conv-info">
                  <div className="conv-name">{u.display_name}</div>
                  <div className="conv-preview">@{u.username}</div>
                </div>
              </div>
            ))}
            {searchQ.length >= 2 && searchResults.length === 0 && (
              <div style={{ textAlign: 'center', color: 'var(--muted)', padding: 20 }}>لا توجد نتائج</div>
            )}
          </div>
        </div>
      )}

      {/* AI Modal */}
      {aiOpen && (
        <div className="modal-overlay" onClick={() => setAiOpen(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3><Sparkles size={18} style={{ verticalAlign: -3, marginLeft: 6 }} /> مساعد EST-CGC</h3>
              <button onClick={() => setAiOpen(false)}><X size={20} /></button>
            </div>
            <textarea
              value={aiInput}
              onChange={e => setAiInput(e.target.value)}
              placeholder="اسأل أي شيء... تلخيص محادثة، اقتراح رد، ترجمة..."
              rows={3}
              style={{
                width: '100%', padding: 12, background: 'var(--bg)', border: '1px solid var(--border)',
                borderRadius: 10, color: 'var(--silver)', resize: 'none', marginBottom: 12
              }}
            />
            <button className="btn-primary" onClick={askAI} disabled={loading}>
              {loading ? 'جاري التفكير...' : 'إرسال'}
            </button>
            {aiReply && (
              <div style={{
                marginTop: 16, padding: 14, background: 'var(--bg)', borderRadius: 10,
                border: '1px solid var(--border)', fontSize: 14, lineHeight: 1.6, whiteSpace: 'pre-wrap'
              }}>
                {aiReply}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default App
