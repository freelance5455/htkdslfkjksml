CHARSIH BATTLEGROUND — HTML PROTOTYPE

Open index.html in Chrome/Edge.

Functional preview:
- Lobby UI
- Bermuda / CS Mode / Lone Wolf / Training selection
- Friends / Chat / Vault / Settings modal panels
- Start Match opens local gameplay preview
- Touch-friendly mobile layout
- Keyboard: Enter starts match, F fires, Esc closes panels

This is a visual/gameplay prototype, not a finished online 3D game or a Play Store APK.
