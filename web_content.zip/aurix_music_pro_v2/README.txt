AURIX MUSIC PRO — Hybrid Player v2
===================================

Files: index.html, README.txt

How to use on Android:
1. Download and extract aurix_music_pro_v2.zip with your phone's file manager.
2. Open index.html in a browser.
3. Add local audio files from your device, or use Discover to try the public Jamendo catalog.
4. Some online catalog endpoints may require an API client ID or may block browser requests. If so, use the official Jamendo or Free Music Archive links shown in the app.

Limitations:
- This is a browser prototype, not an APK.
- It does not provide Spotify's commercial catalog, nor does it bypass subscriptions/DRM.
- Download links depend on each track's licensing and provider.
- Background playback and lock-screen controls are not guaranteed in a browser. A native Android app is required for reliable playback with the screen off.
- This project makes no guarantee that the public music API will work without credentials; it handles errors and provides official catalog links.
