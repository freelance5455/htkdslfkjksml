const Database = require("better-sqlite3");
const db = new Database(process.env.DB_FILE || "rhycord.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, avatar TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS servers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, icon TEXT DEFAULT 'R', description TEXT DEFAULT '', owner_id INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS members(server_id INTEGER NOT NULL, user_id INTEGER NOT NULL, role TEXT DEFAULT 'member', PRIMARY KEY(server_id,user_id));
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER NOT NULL, name TEXT NOT NULL, permissions TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS roles(id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER NOT NULL, name TEXT NOT NULL, color TEXT DEFAULT '#8b5cf6', permissions TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS member_roles(server_id INTEGER NOT NULL, user_id INTEGER NOT NULL, role_id INTEGER NOT NULL, PRIMARY KEY(server_id,user_id,role_id));
CREATE TABLE IF NOT EXISTS invites(code TEXT PRIMARY KEY, server_id INTEGER NOT NULL, created_by INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER NOT NULL, name TEXT NOT NULL, type TEXT DEFAULT 'text', category_id INTEGER, permissions TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id INTEGER, sender_id INTEGER NOT NULL, content TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS dms(id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, recipient_id INTEGER NOT NULL, content TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
// Migração segura para bancos criados em versões anteriores.
const channelCols = db.prepare("PRAGMA table_info(channels)").all().map(c=>c.name);
if (!channelCols.includes("category_id")) db.exec("ALTER TABLE channels ADD COLUMN category_id INTEGER");
if (!channelCols.includes("permissions")) db.exec("ALTER TABLE channels ADD COLUMN permissions TEXT DEFAULT '{}'");
module.exports = db;