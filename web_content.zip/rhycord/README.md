# RhyCord

Aplicativo de comunidades inspirado em chats de servidores. O projeto inclui interface web responsiva, API Node/Express, autenticação, banco SQLite, mensagens em tempo real via Socket.IO, conversas privadas, sinalização WebRTC e bases para empacotar em Android (Capacitor) e desktop (Electron).

## Requisitos
- Node.js 20 ou superior
- npm

## Executar localmente
```bash
npm install
cp .env.example .env
# Edite .env e defina JWT_SECRET
npm run dev
```
Abra http://localhost:5173. A API roda em http://localhost:3001. Para modo de produção:
```bash
npm run build
npm start
```
O servidor entrega a pasta `dist` automaticamente.

## Android
Instale Capacitor no projeto:
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init RhyCord com.rhycord.app --web-dir=dist
npx cap add android
npm run build
npx cap sync android
npx cap open android
```
Compile o APK pelo Android Studio. Para produção, configure a URL pública HTTPS da API e o domínio do app.

## Windows / PC
Em desenvolvimento, rode `npm run dev` e, em outro terminal, `npm run desktop`. Para distribuição, configure um empacotador Electron (electron-builder) e uma URL/API de produção. O desktop usa a mesma interface web.

## Recursos incluídos
- Cadastro e login com hash bcrypt e JWT
- Perfil básico (nome e avatar por URL)
- Criar servidores, entrar em servidores via endpoint, personalizar nome/ícone/descrição
- Canais de texto e voz (criação)
- Mensagens de canais em tempo real e histórico
- Busca de usuários e DMs em tempo real
- Início de chamada de áudio/vídeo WebRTC e solicitação de compartilhamento de tela
- Interface responsiva para celular e desktop

## Limitações importantes antes de publicar
Este é um MVP funcional/base de desenvolvimento, não um serviço pronto para milhões de usuários. A sinalização WebRTC atual é simplificada: para produção é necessário completar o fluxo de ICE candidates/SDP, aceitar chamadas com estado persistente, tratar chamadas simultâneas, adicionar TURN (STUN sozinho não atravessa todas as redes) e testar em HTTPS. O compartilhamento de tela depende de permissões e suporte do navegador; em Android o suporte varia e pode exigir plugin nativo. A UI de chamada deve ser testada em aparelhos reais.

Também faltam: convites com códigos/links e permissões granulares, upload seguro de arquivos/imagens, notificações push, recuperação/verificação de e-mail, moderação, bloqueio/denúncia, criptografia ponta a ponta, rate limits, logs, backup, testes automatizados e política de privacidade/termos. Não exponha o servidor publicamente sem configurar segredo JWT forte, HTTPS, limites de requisição e backups.

## Estrutura
- `src/` interface React
- `server/` API, Socket.IO e SQLite
- `desktop/` janela Electron
- `capacitor.config.json` configuração inicial Android


## Recursos adicionados nesta atualização
- Foto do servidor: em Personalizar servidor, cole uma URL de imagem no campo da foto (ou use emoji).
- Canais de voz: clique em um canal de voz para solicitar o microfone e entrar na sala; a sinalização WebRTC entre participantes usa Socket.IO.
- Categorias: crie categorias e edite nome/permissões. As permissões são armazenadas como JSON (ex.: `{"view":true,"send":false}`).
- Cargos: crie cargos com cor e permissões em JSON e edite a configuração clicando no cargo.
- Convites: gere um link pelo botão "Criar link de convite"; o link é copiado e novos membros podem entrar por ele.

Nota: esta é uma base em desenvolvimento. Para produção, configure HTTPS, TURN para WebRTC, URL pública, validações de permissões por ação e gerenciamento de cargos por membro. O acesso a categorias/cargos é atualmente restrito ao dono do servidor; as permissões ficam salvas, mas ainda não são aplicadas como sistema completo de autorização.

## Atualização: servidores, voz, categorias, cargos e convites
- A foto do servidor aceita URL de imagem no campo de personalização (ou emoji).
- Clique em um canal de voz para entrar na sala usando microfone e WebRTC entre participantes.
- Crie categorias e altere nome/permissões clicando nelas. As permissões ficam salvas como JSON.
- Crie cargos com nome, cor e permissões; clique em um cargo para editar sua configuração.
- Gere links de convite pela opção “Criar link de convite”. Quem abrir o link e estiver autenticado poderá entrar no servidor.

**Limitações desta versão:** as permissões de categorias e cargos são armazenadas/configuráveis, mas ainda não são aplicadas como um sistema completo de autorização; cargos ainda não podem ser atribuídos individualmente aos membros. Chamadas de voz precisam de HTTPS e servidor TURN para funcionar de forma confiável em redes restritas. A foto usa URL pública de imagem.
