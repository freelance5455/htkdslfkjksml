#!/usr/bin/env bash
# Instala as unidades systemd V14 sem iniciá-las; permite transição controlada.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ "$EUID" -ne 0 ]]; then
  echo "Execute: sudo $0" >&2
  exit 1
fi
APP_USER="${SUDO_USER:-}"
if [[ -z "$APP_USER" || "$APP_USER" == root ]]; then
  echo "Execute a partir da conta normal usando sudo; não instale o serviço como root." >&2
  exit 1
fi
id "$APP_USER" >/dev/null 2>&1 || { echo "Usuário inválido: $APP_USER" >&2; exit 1; }
[[ -f "$ROOT/server.py" && -f "$ROOT/nexus_gateway.py" && -f "$ROOT/dados/usuario.json" ]] || { echo "Pasta V14 incompleta ou usuário do portal ausente: $ROOT" >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo 'Python 3 não encontrado.' >&2; exit 1; }
command -v avahi-publish-address >/dev/null 2>&1 || { echo 'Instale Avahi: sudo apt install avahi-daemon libnss-mdns' >&2; exit 1; }
command -v avahi-daemon >/dev/null 2>&1 || { echo 'avahi-daemon não encontrado.' >&2; exit 1; }
command -v systemctl >/dev/null 2>&1 || { echo 'systemd não encontrado.' >&2; exit 1; }
APP_GROUP="$(id -gn "$APP_USER")"
ROOT_SYSTEMD="${ROOT//\\/\\\\}"
ROOT_SYSTEMD="${ROOT_SYSTEMD// /\\x20}"
ROOT_SYSTEMD="${ROOT_SYSTEMD//%/%%}"
PYTHON="$(command -v python3)"
# Backup e limpeza somente dos dois aliases NEXUS antigos; outras entradas Avahi são preservadas.
AVAHI_HOSTS=/etc/avahi/hosts
if [[ -f "$AVAHI_HOSTS" ]] && grep -qE '(^|[[:space:]])(nexus\.local|gfi\.nexus\.local)([[:space:]]|$)' "$AVAHI_HOSTS"; then
  BACKUP="$AVAHI_HOSTS.backup-v14-$(date +%Y%m%d-%H%M%S)"
  cp -a "$AVAHI_HOSTS" "$BACKUP"
  python3 - "$AVAHI_HOSTS" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1])
aliases = {"nexus.local", "gfi.nexus.local"}
kept = []
for line in p.read_text(errors="replace").splitlines(keepends=True):
    if line.lstrip().startswith("#") or not line.strip():
        kept.append(line)
        continue
    body, marker, comment = line.partition("#")
    fields = body.split()
    if len(fields) < 2:
        kept.append(line)
        continue
    names = [name for name in fields[1:] if name.lower() not in aliases]
    if names:
        ending = "\n" if line.endswith("\n") else ""
        kept.append(fields[0] + "\t" + " ".join(names) + ((" #" + comment.rstrip("\n")) if marker else "") + ending)
    elif marker:
        kept.append("#" + comment if comment.endswith("\n") else "#" + comment + "\n")
p.write_text("".join(kept))
PY
  echo "Backup Avahi: $BACKUP"
fi
# Remove somente aliases locais NEXUS acrescentados durante o diagnóstico; mantém backup integral.
HOSTS_FILE=/etc/hosts
if [[ -f "$HOSTS_FILE" ]] && grep -qE '(^|[[:space:]])(nexus\.local|gfi\.nexus\.local)([[:space:]]|$)' "$HOSTS_FILE"; then
  HOSTS_BACKUP="$HOSTS_FILE.backup-v14-$(date +%Y%m%d-%H%M%S)"
  cp -a "$HOSTS_FILE" "$HOSTS_BACKUP"
  python3 - "$HOSTS_FILE" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1])
aliases = {"nexus.local", "gfi.nexus.local"}
kept = []
for line in p.read_text(errors="replace").splitlines(keepends=True):
    if line.lstrip().startswith("#") or not line.strip():
        kept.append(line)
        continue
    body, marker, comment = line.partition("#")
    fields = body.split()
    if len(fields) < 2:
        kept.append(line)
        continue
    names = [name for name in fields[1:] if name.lower() not in aliases]
    if names:
        ending = "\n" if line.endswith("\n") else ""
        kept.append(fields[0] + "\t" + " ".join(names) + ((" #" + comment.rstrip("\n")) if marker else "") + ending)
    elif marker:
        kept.append("#" + comment if comment.endswith("\n") else "#" + comment + "\n")
p.write_text("".join(kept))
PY
  echo "Backup /etc/hosts: $HOSTS_BACKUP"
fi
# Systemd usa o usuário real; CAP_NET_BIND_SERVICE permite ao gateway abrir a porta 80 sem rodar como root.
cat > /etc/systemd/system/my-universe-v14.service <<EOF
[Unit]
Description=MY UNIVERSE V14 — Portal, GFI sob demanda e NEXUS Gateway
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_GROUP
WorkingDirectory=$ROOT_SYSTEMD
Environment=MY_UNIVERSE_HOST=127.0.0.1
Environment=MY_UNIVERSE_PORT=8765
Environment=GFI_PORTA=8780
Environment=NEXUS_GATEWAY_HOST=0.0.0.0
Environment=NEXUS_GATEWAY_PORT=80
Environment=PYTHONUNBUFFERED=1
ExecStart="$PYTHON" "$ROOT/nexus_v14_supervisor.py"
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
KillMode=control-group
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
UMask=0077

[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/nexus-mdns-v14.service <<EOF
[Unit]
Description=NEXUS V14 — Publicação persistente de nomes Avahi
Wants=network-online.target avahi-daemon.service
After=network-online.target avahi-daemon.service

[Service]
Type=simple
User=$APP_USER
Group=$APP_GROUP
WorkingDirectory=$ROOT_SYSTEMD
ExecStart="$PYTHON" "$ROOT/nexus_mdns_supervisor.py"
Restart=always
RestartSec=5
TimeoutStopSec=10
KillMode=control-group
NoNewPrivileges=true
UMask=0077

[Install]
WantedBy=multi-user.target
EOF
systemctl enable avahi-daemon >/dev/null 2>&1 || true
systemctl daemon-reload
systemctl enable my-universe-v14.service nexus-mdns-v14.service >/dev/null
printf '\nInstalação V14 concluída. Serviços habilitados para inicialização automática, mas NÃO iniciados agora.\n'
printf 'Diretório: %s\nUsuário do serviço: %s\n' "$ROOT" "$APP_USER"
printf 'Próximo passo: feche os publicadores Avahi e o gateway V13 abertos manualmente; depois execute: sudo ./nexus_v14.sh start\n'
