
## Estado observado no banco entregue para esta compilação
- O banco REAL original foi preservado byte a byte (SHA-256: `4944daa49db2490b4872647700d98684f25e43175fe8fff7e8b47e184ac35b7f`).
- No banco disponível durante a compilação há somente **1 instrumento REAL ativo (PETR4/BVMF)**, sem candles históricos, fundamentos ou pontuações. Existe 1 snapshot intradiário já armazenado.
- Portanto, a automação está implementada, mas a cobertura integral da B3/GFI depende de importar e validar o universo de ativos e as bases históricas reais. Não seria correto afirmar que a base inteira já está populada.

- Notícias RSS: atualização automática agendada a cada 15 minutos, com cache e origem/publicação preservados.
