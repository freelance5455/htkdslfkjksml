# MY UNIVERSE V15 — Relatório de construção

## Origem

- Base: `MY-UNIVERSE-V14-NEXUS-SYSTEMD.zip`.
- Estratégia: preservar a aplicação e o gerenciamento de serviços V14, ampliar a carteira B3 e melhorar o painel visual.

## Arquivos alterados

- `sites/laboratorio-ti/inteligencia-financeira/gfi/v9.py`: catálogo de ações brasileiras, rentabilidade aberta por posição, valor de compra calculado por quantidade × preço e limite de consultas externas.
- `sites/laboratorio-ti/inteligencia-financeira/gfi/api.py`: endpoint GET `carteira/ativos`.
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.js`: carteira com seleção de ações B3, histórico de preço unitário, resultados por ação, atualização do painel e saldo global a cada 5 segundos e importação COTAHIST manual.
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.css`: transparência e responsividade desktop/mobile.
- `VERSAO_V15.md`, `V15_BUILD_REPORT.md`, `testar_v15.sh` e `migrar_dados_v15.sh`.

## Testes executados

- Sintaxe Python (`py_compile`): aprovado.
- Sintaxe JavaScript (`node --check`): aprovado.
- Suíte GFI: 128 testes aprovados.
- Smoke test do livro financeiro isolado: aprovado (depósito, compra, preço médio, venda e P/L realizado).
- Endpoint de catálogo B3: testado contra a base incluída no pacote.
- Integridade do ZIP e SHA-256: validado após empacotamento.

## Limites de validação

- A base de exemplo incluída no ZIP possui cobertura B3 pequena; o catálogo completo depende da execução do importador COTAHIST na máquina do usuário.
- Não foi executada consulta de cotações externas em tempo real durante o build.
- Testes visuais em navegadores físicos Android/desktop e validação operacional no Linux Mint dependem da instalação local.
- Suíte `nexus.tests.test_nexus`: excedeu o limite de 300 segundos neste ambiente; não declarada como aprovada. A suíte GFI (128 testes) terminou normalmente.
