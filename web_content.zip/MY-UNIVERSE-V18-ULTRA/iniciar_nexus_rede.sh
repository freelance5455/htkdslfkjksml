#!/usr/bin/env bash
# Inicia portal e gateway NEXUS para acesso por nomes na rede local.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
PYTHON="${MY_UNIVERSE_PYTHON:-python3}"
command -v "$PYTHON" >/dev/null 2>&1 || { echo 'Python 3 não encontrado.' >&2; exit 127; }
[[ -f dados/usuario.json ]] || { echo 'Crie primeiro o usuário com: ./iniciar.sh'; exit 1; }
export MY_UNIVERSE_HOST=127.0.0.1
if [[ "$EUID" -eq 0 && -n "${SUDO_USER:-}" ]]; then
  sudo -u "$SUDO_USER" -- "$PYTHON" server.py & PORTAL_PID=$!
else
  "$PYTHON" server.py & PORTAL_PID=$!
fi
cleanup(){ kill "$PORTAL_PID" 2>/dev/null || true; [[ -n "${GATEWAY_PID:-}" ]] && kill "$GATEWAY_PID" 2>/dev/null || true; wait 2>/dev/null || true; }
trap cleanup EXIT INT TERM
sleep 1
if ! curl -fsS --max-time 2 http://127.0.0.1:${MY_UNIVERSE_PORT:-8765}/ >/dev/null; then echo 'Portal não iniciou; verifique o terminal.' >&2; exit 1; fi
if [[ "${NEXUS_GATEWAY_PORT:-80}" -lt 1024 && "$EUID" -ne 0 ]]; then
  echo 'A porta 80 exige permissão administrativa. Execute: sudo ./iniciar_nexus_rede.sh' >&2; exit 1
fi
"$PYTHON" nexus_gateway.py & GATEWAY_PID=$!
sleep 1
kill -0 "$GATEWAY_PID" 2>/dev/null || { echo 'Gateway não iniciou; a porta pode estar ocupada.' >&2; exit 1; }
echo 'NEXUS NETWORK ativo. Endereços: http://nexus.local e http://gfi.nexus.local'
echo 'Para resolver os nomes, configure Avahi/DNS local conforme NEXUS_NETWORK.md.'
wait "$PORTAL_PID"
