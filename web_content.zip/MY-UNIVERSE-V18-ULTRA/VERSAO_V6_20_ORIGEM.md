# MY UNIVERSE V6.20 — consolidação e operação imediata da IA GFI

## Objetivo
Consolidar a V6.11 sem remover funcionalidades existentes e tornar a Central IA GFI utilizável imediatamente pelo painel.

## Alterações desta versão
- Mantida a estrutura e os módulos da V6.11 como base.
- Adicionado chat direto na Central IA GFI: botão **Perguntar à IA GFI** envia a pergunta à API local.
- Quando um modelo compatível estiver disponível, a resposta vem do LLM detectado (NEXUS, Ollama, LM Studio, llama.cpp, vLLM ou endpoint HTTPS configurado).
- Quando não houver LLM, o mesmo botão executa diagnóstico local real e identifica explicitamente o modo como `local_diagnostico`; não simula IA generativa.
- Mantido o botão **Executar ciclo agora**, que gera relatório de diagnóstico e tenta pesquisa externa.
- Mantida a autonomia nível 3 supervisionada, com código isolado em laboratório e aprovação humana antes de alterações na produção.
- Recursos que dependem de modelo, Internet, dados externos ou ambiente operacional permanecem identificados como pendentes até confirmação.

## Segurança
- Nenhum código gerado é executado automaticamente.
- Nenhuma alteração automática no núcleo de produção.
- Endpoints remotos exigem HTTPS; endpoints HTTP só são aceitos em loopback.
- Instalação/baixar modelos exige ação explícita do operador pelo assistente de ativação.

## Validação
- Testes automatizados: 119 aprovados (inclui dois testes do chat imediato).
- Python compileall: aprovado.
- JavaScript `node --check ui/app.js`: aprovado.
- Shell `bash -n iniciar.sh ativar_ia.sh`: aprovado.
- Chat API exercitado no modo local de diagnóstico.
- Inferência LLM real e pesquisa externa continuam dependentes de servidor/modelo e conectividade na máquina operacional.
