#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
GFI="$ROOT/sites/laboratorio-ti/inteligencia-financeira"
echo '[1/6] Arquivos V14/V15'
for f in nexus_v14_supervisor.py nexus_mdns_supervisor.py nexus_v14.sh instalar_v14.sh migrar_dados_v14.sh migrar_dados_v15.sh VERSAO_V15.md V15_BUILD_REPORT.md; do test -s "$ROOT/$f"; done
echo '[2/6] Sintaxe Python e JavaScript'
python3 -m py_compile "$GFI/servidor.py" "$GFI/gfi/v9.py" "$GFI/gfi/api.py"
if command -v node >/dev/null 2>&1; then node --check "$GFI/ui/app.js"; else echo '[AVISO] Node.js ausente; pulando node --check'; fi
echo '[3/6] Sintaxe shell'
for f in "$ROOT"/nexus_v14.sh "$ROOT"/instalar_v14.sh "$ROOT"/migrar_dados_v14.sh "$ROOT"/migrar_dados_v15.sh "$ROOT"/testar_v14.sh; do bash -n "$f"; done
echo '[4/6] Catálogo B3 e smoke test financeiro'
PYTHONPATH="$GFI" python3 - <<'PY'
import tempfile
from pathlib import Path
from gfi import v9
old=v9.DB_V9
with tempfile.TemporaryDirectory() as d:
    v9.DB_V9=Path(d)/'wallet-test.db'
    a=v9.carteira_lancar({'kind':'deposito','amount':1000})
    assert a['saldo_caixa']==1000
    b=v9.carteira_lancar({'kind':'compra','amount':999,'ticker':'PETR4','quantity':10,'unit_price':20})
    assert b['saldo_caixa']==800 and b['posicoes']['PETR4']['preco_medio']==20
    c=v9.carteira_lancar({'kind':'venda','amount':1,'ticker':'PETR4','quantity':2,'unit_price':25})
    assert c['posicoes']['PETR4']['quantidade']==8
    assert c['lucro_prejuizo_realizado']==10
    assert c['movimentacoes'][-1]['amount']==50
v9.DB_V9=old
ativos=v9.carteira_ativos('')
assert isinstance(ativos['ativos'],list) and ativos['total']>=0
print('[OK] Depósito, compra, preço de aquisição, venda e P/L realizado')
print(f"[OK] Catálogo local: {ativos['total']} ações/units disponíveis no banco desta instalação")
PY
echo '[5/6] Suíte automatizada GFI'
(cd "$GFI" && PYTHONPATH=. python3 -m unittest discover -s testes -t .)
echo '[6/6] Preservação dos dados-base'
test -s "$GFI/dados/gfi.db"
test -s "$GFI/PLANO_COLETA_145.md"
echo '[OK] V15 validada'
