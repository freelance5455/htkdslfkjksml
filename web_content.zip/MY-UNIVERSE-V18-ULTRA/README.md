# MY UNIVERSE — V18 ULTRA

V18 ULTRA preserva o ambiente desktop da V17 e acrescenta um cliente Android nativo com interface mobile própria, conexão Wi-Fi e remota HTTPS, login integrado, dashboard e acesso ao NEXUS, Projetos e GFI. Consulte `VERSAO_V18_ULTRA.md` e `docs/ANDROID_V18_ULTRA.md`.

O app Android está em `android/`. Para compilar, use Android Studio, JDK 17, Android SDK 35 e Gradle 8.11.1. Esta entrega contém o projeto-fonte Android; não declara APK compilado neste ambiente.

Os scripts e notas de versões anteriores permanecem no pacote como histórico. Para migrar os dados da V17, use `./MIGRAR_DADOS_V18.sh /caminho/da/instalacao-V17`. Para validar esta entrega, execute `./testar_v18_ultra.sh`.

# MY UNIVERSE

Portal pessoal com login, 13 cartões de projetos e o **NEXUS**, uma IA local que evolui sozinha.
Só precisa de **Python 3.8+** — nada para instalar.

## Usar

```bash
bash iniciar.sh
```

Na primeira vez pede usuário e senha (mínimo 12 caracteres) e guarda só o *hash* em `dados/`.
Depois abra <http://127.0.0.1:8765>. O NEXUS fica em **NEXUS ↗** no topo do painel.

| Comando | Para quê |
|---|---|
| `bash iniciar.sh` | só neste computador |
| `bash iniciar.sh --rede` | celular/PC na mesma rede Wi-Fi |
| `bash iniciar.sh --online` | link HTTPS temporário pela Internet (requer `cloudflared`) |
| `bash iniciar.sh --senha` | trocar usuário/senha |

Não abra os `.html` direto: sem o `server.py` não há login.

## NEXUS — engenharia evolutiva do MY UNIVERSE (V6.08)

Além da evolução do classificador de intenções, o NEXUS inclui o Autonomous Evolution Engine (AEE). Na tela NEXUS, descreva uma melhoria; com o modelo local ligado, ele analisa um inventário limitado do portal e prepara uma proposta de alteração de HTML/CSS/JavaScript. A proposta fica em área isolada e só é aplicada após aprovação explícita. Antes da aplicação, os arquivos originais são guardados em ZIP e os hashes são conferidos para evitar aplicar propostas sobre uma base que mudou.

O AEE não altera `server.py`, o núcleo guardião `nexus/*.py`, configuração, credenciais ou dados. Também não modifica os pesos do modelo de IA: usa o modelo local para elaborar propostas de engenharia de software. A evolução automática antiga do classificador permanece separada.

Rotas: `GET /api/nexus/engenharia/estado`, `POST /api/nexus/engenharia/analisar`, `POST /api/nexus/engenharia/propor` e `POST /api/nexus/engenharia/aplicar`.

## NEXUS — IA que se auto-analisa e reescreve o próprio cérebro

Em segundo plano, a cada 15 minutos (e logo após você dar um 👍/👎):

1. **Auto-análise:** mede quanto acerta ao entender o que você pede (guardar, buscar, calcular, hora, conversar).
2. **Busca evolutiva:** gera uma população de candidatos a `aprendido.py` (aprendiz + mutação + cruzamento),
   avaliados **em paralelo**, um subprocesso isolado cada, por várias gerações.
3. **Promoção automática:** só entra o que melhora a nota **sem piorar** o holdout nem o conjunto de confirmação.
4. **Conferência e reversão:** depois de promover, testa o código real; se piorar, volta sozinha.

Se houver um modelo local (veja abaixo), ele também propõe reescritas completas do `cerebro.py`, que passam pelas mesmas travas.

**O que ela aprende:** cada correção sua (👎 + intenção certa) vira caso de treino. Quanto mais você corrige, melhor ela fica.

### Travas que ela não consegue alterar

- Só pode editar `nexus/nucleo/cerebro.py` e `aprendido.py`. Motor, avaliador, limites e interruptor ficam fora do alcance dela.
- O código novo passa por análise estática (sem `import os/sys/subprocess`, sem `open/eval/exec`, sem atributos `__x__`)
  e roda num subprocesso com limite de CPU, memória, arquivos e tempo.
- Três conjuntos de teste: **treino** (ela vê), **holdout** (seleciona), **confirmação** (só veta, nunca é usado na busca).
- Limite de promoções por dia, histórico completo, 30 versões guardadas e botão **Reverter**.
- **Pausar** a qualquer momento na tela (ou crie o arquivo `nexus/data/PARAR`).
- Tudo local: o modelo só é aceito em endereço local/privado.

### Escalar a evolução

Mais CPU = mais candidatos por ciclo. Ajuste por variáveis de ambiente antes do `./iniciar.sh`:

| Variável | Padrão | Efeito |
|---|---|---|
| `NEXUS_POPULACAO` | 16 | candidatos por geração |
| `NEXUS_GERACOES` | 6 | gerações por ciclo |
| `NEXUS_TRABALHADORES` | nº de CPUs − 1 | candidatos avaliados em paralelo |
| `NEXUS_ORCAMENTO` | 90 | segundos máximos de busca por ciclo |
| `NEXUS_INTERVALO` | 900 | segundos entre ciclos |
| `NEXUS_MAX_PROMOCOES_DIA` | 12 | teto de promoções automáticas por dia |
| `NEXUS_LIGADO` | 1 | `0` desliga o motor em segundo plano |

Se ela estagna, a população e a força da mutação crescem sozinhas (até 4×).

### Conversa livre (opcional)

Memória, contas e hora funcionam sem modelo. Para conversar livremente, rode um `llama-server` (llama.cpp)
com qualquer modelo `.gguf` em `127.0.0.1:8080`; o NEXUS o detecta sozinho. Modelos maiores respondem melhor.
Outro endereço: `NEXUS_LLM_URL=http://127.0.0.1:PORTA/v1/chat/completions`.

### Limites honestos

Ela evolui o que o teste mede (entender a intenção das frases) — não vira "mais esperta em tudo". A qualidade da
conversa depende do modelo local. O sandbox é forte, mas não é uma prisão perfeita; por isso o alcance dela é de apenas 2 arquivos.

## Estrutura

```
MY-universe/
├── iniciar.sh        # comando único de início
├── server.py         # login, sessão, arquivos protegidos e rotas /api/nexus
├── index.html        # login
├── painel.html       # os 13 cartões
├── nexus.html        # tela do NEXUS
├── assets/           # CSS/JS e imagem de fundo
├── sites/            # um diretório por cartão (conteúdo inalterado)
├── nexus/
│   ├── nucleo/       # ← ÚNICA parte que a IA reescreve (cerebro.py, aprendido.py)
│   ├── evoluir.py    # ciclo de evolução (guardião)
│   ├── avaliador.py  # validação, sandbox e notas (guardião)
│   ├── motor.py      # segundo plano + interruptor (guardião)
│   ├── api.py, llm.py, memoria.py, config.py, casos_base.json
│   └── tests/        # 29 testes
└── dados/, nexus/data/   # usuário, banco e versões (criados ao usar; fora do Git)
```

Testes: `python3 -m unittest discover -s nexus/tests -t .`

## Adicionar um cartão

1. Crie `sites/novo/index.html` (com `<a href="../../painel.html">` para voltar).
2. Copie um bloco `<a class="cartao ...">` em `painel.html` e ajuste `href`, número, título e texto.

## Segurança do portal

- Senha com PBKDF2 (310 mil iterações), sessão de 8 h, 8 tentativas por 5 min, cookie HttpOnly/SameSite.
- Só serve extensões de site; `server.py`, `nexus/`, `dados/` e arquivos ocultos nunca são entregues.
- Tudo exige login (inclusive a API do NEXUS), exceto a tela de entrada.


## V6.05 — ciclo de vida das conexões SQLite da NEXUS

- Corrigido `nexus/memoria.py`: cada conexão agora é encerrada explicitamente ao sair do contexto.
- Transações confirmam (`commit`) em caso de sucesso e executam `rollback` em caso de exceção.
- Adicionado teste de regressão que verifica que a conexão não pode ser reutilizada depois do fechamento.
- Preservada a lógica de memória, aprendizagem, evolução e API.
- Verificações nesta revisão: 55 arquivos Python compilados; 98 testes da GFI aprovados; 7 testes da API/memória da NEXUS aprovados; 3 testes direcionados da evolução aprovados.
- A suíte integral da NEXUS não terminou dentro do limite de execução desta revisão; não é declarada integralmente aprovada.


## V6.11 — Central de Inteligência Artificial da GFI

A V6.11 adiciona uma central independente para evolução autônoma supervisionada da GFI (nível 3). O agente faz inventário, pesquisa web pública, lê páginas HTTPS, gera relatórios e, com LLM configurada, prepara código em laboratório. Não altera nem executa código de produção, não instala dependências e não publica atualizações sem aprovação humana. Consulte `VERSAO_V6_11.md` e `sites/laboratorio-ti/inteligencia-financeira/README.md` para configuração, operação e limitações.


## V7 — integração V6 + V6.11

A V7 mantém o portal, o NEXUS/AEE e a Central IA GFI da V6.11 e recupera melhorias operacionais da V6: acesso remoto da GFI por token, LIVE em fio próprio com rodízio e proteção por recursos, agendamento persistente, coleta B3 incremental de três anos, fila de pesquisa mais precisa, baselines de backtest e tratamento conservador de saltos de preço. Consulte `VERSAO_V7.md` e `V7_MERGE_REPORT.md` para escopo, compatibilidade e pendências.

## V8 Alpha

A V8 Alpha usa a V7 como base e incorpora seletivamente a evolução do chat e da descoberta automática de provedores da Central IA GFI da V6.20. Consulte `VERSAO_V8_ALPHA.md`, `V8_MERGE_REPORT.md` e `TEST_REPORT.md` para escopo, decisões de integração, evidências e pendências.


## V10 — WebMobile + saldo global
A V10 adiciona layout mobile dedicado com wallpaper vertical MY UNIVERSE, navegação otimizada para toque e saldo de caixa global no topo, sincronizado com Minha Conta (painel 19), com ocultação/revelação persistente no navegador. Consulte `sites/laboratorio-ti/inteligencia-financeira/VERSAO_V10.md`.

## Operação persistente de rede (V14)

Para instalar os serviços gerenciados no Linux Mint/Ubuntu, execute `./migrar_dados_v14.sh /caminho/da/V13` (dados da V13 prevalecem; backup é criado), `./testar_v14.sh` e depois `sudo ./instalar_v14.sh`. Feche os processos V13 iniciados manualmente e ative com `sudo ./nexus_v14.sh start`. Consulte o estado com `sudo ./nexus_v14.sh status`; logs com `sudo ./nexus_v14.sh logs`. O instalador habilita os serviços para iniciar no boot, mas não os inicia durante a instalação.


## Versão 16

Consulte `VERSAO_V16.md` e execute `./testar_v16.sh` para validar a consolidação de candles e a integridade temporal da GFI.
