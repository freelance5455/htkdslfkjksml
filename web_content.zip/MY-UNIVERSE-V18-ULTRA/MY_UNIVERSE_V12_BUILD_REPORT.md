# Relatório de construção — MY UNIVERSE V12

Base: MY-UNIVERSE-V11-GFI-MOBILE.zip.

Implementação focada na carteira pessoal (aba Minha Conta) e no indicador de patrimônio global. Foi adicionada persistência de cotações da carteira, consulta pública por ticker B3, cálculo de P/L aberto e rentabilidade, atualização automática periódica e atualização manual.

A atualização automática consulta a fonte a cada 60 segundos enquanto a interface estiver aberta. Isso não representa cotação em tempo real garantida. Sem preço identificável para qualquer posição, o patrimônio total e a rentabilidade global ficam indisponíveis, evitando somar posições incompletas.

Verificações executadas nesta construção: sintaxe JavaScript (`node --check`) e compilação Python (`compileall`). Os testes de integração com fonte externa e operação real de mercado dependem de conectividade e devem ser executados no ambiente operacional.
