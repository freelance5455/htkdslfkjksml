#!/usr/bin/env bash
set -u
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
fail=0
ok(){ printf '[OK] %s\n' "$1"; }
bad(){ printf '[FALHA] %s\n' "$1"; fail=1; }
for f in server.py nexus_gateway.py nexus_v14_supervisor.py nexus_mdns_supervisor.py migrar_dados_v14.sh instalar_v14.sh nexus_v14.sh sites/laboratorio-ti/inteligencia-financeira/servidor.py; do
  [[ -s "$ROOT/$f" ]] && ok "Arquivo presente: $f" || bad "Arquivo ausente/vazio: $f"
done
python3 - "$ROOT" <<'PY'
import ast, pathlib, sys
root = pathlib.Path(sys.argv[1])
for name in ('nexus_v14_supervisor.py', 'nexus_mdns_supervisor.py'):
    ast.parse((root/name).read_text(encoding='utf-8'))
print('[OK] Sintaxe Python dos supervisores')
PY
[[ -x "$ROOT/nexus_v14.sh" && -x "$ROOT/instalar_v14.sh" && -x "$ROOT/migrar_dados_v14.sh" ]] && ok 'Scripts executáveis' || bad 'Scripts sem permissão de execução'
for script in "$ROOT/nexus_v14.sh" "$ROOT/instalar_v14.sh" "$ROOT/migrar_dados_v14.sh" "$ROOT/testar_v14.sh"; do bash -n "$script" || bad "Erro de sintaxe Bash: $script"; done
[[ "$fail" -eq 1 ]] || ok 'Sintaxe Bash'
[[ -f "$ROOT/sites/laboratorio-ti/inteligencia-financeira/dados/gfi.db" ]] && ok 'Banco GFI preservado' || bad 'Banco GFI ausente'
[[ -f "$ROOT/PLANO_COLETA_145.md" || -f "$ROOT/sites/laboratorio-ti/inteligencia-financeira/PLANO_COLETA_145.md" ]] && ok 'Plano de coleta 145 tarefas preservado' || bad 'Plano de coleta ausente'
exit "$fail"
