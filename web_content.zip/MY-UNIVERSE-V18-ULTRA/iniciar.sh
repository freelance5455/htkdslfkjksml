#!/usr/bin/env bash
# MY UNIVERSE — um único comando para iniciar.
#   ./iniciar.sh            só neste computador   (http://127.0.0.1:8765)
#   sudo ./iniciar_nexus_rede.sh  acesso por nomes NEXUS na rede local
#   ./iniciar.sh --rede     para celular/PC na mesma rede Wi-Fi
#   ./iniciar.sh --online   link HTTPS temporário pela Internet (precisa do cloudflared)
#   ./iniciar.sh --senha    troca usuário e senha
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

# Localiza o interpretador sem depender de alias, PATH do ambiente gráfico ou
# de um link simbólico chamado python3.
PYTHON="${MY_UNIVERSE_PYTHON:-}"
if [[ -n "$PYTHON" ]]; then
  command -v "$PYTHON" >/dev/null 2>&1 || { echo "Interpretador configurado não encontrado: $PYTHON" >&2; exit 127; }
elif command -v python3 >/dev/null 2>&1; then
  PYTHON="$(command -v python3)"
elif command -v python >/dev/null 2>&1; then
  PYTHON="$(command -v python)"
else
  echo "Python não encontrado. Instale Python 3 e tente novamente." >&2
  exit 127
fi
"$PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 8) else "MY UNIVERSE exige Python 3.8 ou superior.")'

if [[ "${1:-}" == "--senha" || ! -f dados/usuario.json ]]; then
  "$PYTHON" server.py --criar-usuario
  [[ "${1:-}" == "--senha" ]] && exit 0
fi

case "${1:-}" in
  --rede)
    export MY_UNIVERSE_HOST=rede ;;
  --online)
    CF="$(command -v cloudflared || true)"
    [[ -z "$CF" && -x "$HOME/.local/bin/cloudflared" ]] && CF="$HOME/.local/bin/cloudflared"
    if [[ -z "$CF" ]]; then
      echo "cloudflared não encontrado. Instale-o ou use ./iniciar.sh --rede." >&2
      exit 1
    fi
    export MY_UNIVERSE_COOKIE_SECURE=1 MY_UNIVERSE_TRUST_PROXY=1
    "$PYTHON" server.py &
    SERVER_PID=$!
    trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT
    sleep 1
    echo "Use no celular o endereço https://...trycloudflare.com mostrado abaixo."
    "$CF" tunnel --url "http://127.0.0.1:${MY_UNIVERSE_PORT:-8765}" --no-autoupdate
    exit 0 ;;
esac

exec "$PYTHON" server.py
