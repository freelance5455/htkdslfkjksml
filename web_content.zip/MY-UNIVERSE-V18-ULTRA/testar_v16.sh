#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
GFI="$ROOT/sites/laboratorio-ti/inteligencia-financeira"
echo '[1/5] Sintaxe Python'
python3 -m compileall -q "$GFI/gfi" "$GFI/servidor.py"
echo '[2/5] Sintaxe JavaScript'
if command -v node >/dev/null 2>&1; then node --check "$GFI/ui/app.js"; else echo '[AVISO] Node.js ausente'; fi
echo '[3/5] Sintaxe shell'
for f in "$ROOT"/*.sh; do bash -n "$f"; done
echo '[4/5] Regressão V15 + testes V16'
(cd "$GFI" && PYTHONPATH=. python3 -m unittest discover -s testes -t .)
echo '[5/5] Integridade dos arquivos-base'
test -s "$GFI/dados/gfi.db"
test -s "$GFI/gfi/plano_coleta.py"
test -s "$ROOT/VERSAO_V16.md"
test -s "$ROOT/migrar_dados_v16.sh"
echo '[OK] V16 validada localmente'
