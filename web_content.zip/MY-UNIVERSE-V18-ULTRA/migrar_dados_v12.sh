#!/usr/bin/env bash
# Copia dados locais de uma instalação anterior sem sobrescrever o destino.
set -euo pipefail
if [[ $# -ne 1 || ! -d "$1" ]]; then
  echo "Uso: $0 /caminho/da/instalacao/V12" >&2; exit 2
fi
ORIGEM="$(cd "$1" && pwd)"
DESTINO="$(cd "$(dirname "$0")" && pwd)"
for rel in dados nexus/data sites/laboratorio-ti/inteligencia-financeira/dados sites/laboratorio-ti/inteligencia-financeira/atualizacoes; do
  if [[ -d "$ORIGEM/$rel" ]]; then
    mkdir -p "$DESTINO/$(dirname "$rel")"
    if [[ ! -e "$DESTINO/$rel" ]]; then
      cp -a "$ORIGEM/$rel" "$DESTINO/$rel"
      echo "Preservado: $rel"
    else
      cp -an "$ORIGEM/$rel/." "$DESTINO/$rel/"
      echo "Mesclado sem sobrescrever: $rel"
    fi
  fi
done
echo 'Migração concluída. Confira permissões e faça backup da instalação antiga antes de removê-la.'
