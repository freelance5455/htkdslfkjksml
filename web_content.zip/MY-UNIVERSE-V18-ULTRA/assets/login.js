const form = document.getElementById("loginForm");
const feedback = document.getElementById("loginFeedback");

fetch("/auth/session", { credentials: "same-origin", cache: "no-store" })
    .then((response) => response.ok ? response.json() : null)
    .then((session) => {
        if (session?.authenticated) window.location.replace("/painel.html");
    })
    .catch(() => {});

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = form.querySelector("button[type='submit']");
    button.disabled = true;
    feedback.textContent = "Validando acesso…";

    try {
        const response = await fetch("/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin",
            body: JSON.stringify({
                username: document.getElementById("username").value,
                password: document.getElementById("password").value
            })
        });
        if (!response.ok) {
            let message = "Usuário ou senha inválidos.";
            try {
                const payload = await response.json();
                if (typeof payload.error === "string") message = payload.error;
            } catch {}
            throw new Error(message);
        }
        window.location.assign("/painel.html");
    } catch (error) {
        feedback.textContent = error.message || "Não foi possível validar o acesso.";
        document.getElementById("password").value = "";
        button.disabled = false;
    }
});
