(() => {
  "use strict";

  const search = document.getElementById("pesquisa");
  const counter = document.getElementById("contador");
  const emptyState = document.getElementById("semResultado");
  const main = document.querySelector("main.container");
  const logoutButton = document.getElementById("logout-button");

  logoutButton?.addEventListener("click", async () => {
    logoutButton.disabled = true;
    try {
      await fetch("/auth/logout", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
    } finally {
      window.location.replace("/");
    }
  });

  const normalize = (value) => String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR");

  function updateProjects() {
    if (!main) return;

    const query = normalize(search?.value).trim();
    const cards = [...main.querySelectorAll(".cartao")];
    let visible = 0;

    cards.forEach((card) => {
      const searchable = normalize([
        card.dataset.name,
        card.querySelector("h3")?.textContent,
        card.textContent,
      ].join(" "));
      const matches = !query || searchable.includes(query);
      card.hidden = !matches;
      if (matches) visible += 1;
    });

    main.querySelectorAll(".grupo").forEach((group) => {
      group.hidden = ![...group.querySelectorAll(".cartao")].some((card) => !card.hidden);
    });

    if (counter) {
      counter.textContent = query
        ? `${visible} de ${cards.length} projetos`
        : `${cards.length} ${cards.length === 1 ? "projeto" : "projetos"}`;
    }
    if (emptyState) emptyState.hidden = visible > 0;
  }

  search?.addEventListener("input", updateProjects);

  document.addEventListener("keydown", (event) => {
    const activeTag = document.activeElement?.tagName;
    if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(activeTag)) {
      event.preventDefault();
      search?.focus();
    }
    if (event.key === "Escape" && document.activeElement === search) {
      search.value = "";
      updateProjects();
      search.blur();
    }
  });

  updateProjects();
})();
