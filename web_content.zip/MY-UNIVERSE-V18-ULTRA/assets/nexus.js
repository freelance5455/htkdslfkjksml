(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const INTENCOES = { salvar: 'Guardar na memória', buscar: 'Buscar na memória', calcular: 'Calcular', hora: 'Data e hora', conversa: 'Conversar' };
  const TIPOS = { autoanalise: 'Auto-análise', busca: 'Busca evolutiva', promocao: 'Promoção', proposta: 'Proposta', reversao: 'Reversão', ciclo: 'Ciclo' };
  let estado = null;

  async function api(rota, dados) {
    const opcoes = dados === undefined ? { credentials: 'same-origin' }
      : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(dados) };
    const r = await fetch('/api/nexus/' + rota, opcoes);
    if (r.status === 401) { location.href = '/'; return null; }
    return r.json().catch(() => ({ error: 'Resposta inválida.' }));
  }
  const el = (tag, classe, texto) => { const e = document.createElement(tag); if (classe) e.className = classe; if (texto !== undefined) e.textContent = texto; return e; };

  // ---------- conversa ----------
  function rolar() { const m = $('mensagens'); m.scrollTop = m.scrollHeight; }
  function bolhaUsuario(texto) { $('mensagens').append(el('div', 'nx-msg nx-eu', texto)); rolar(); }
  function bolhaIA(r) {
    const b = el('div', 'nx-msg nx-ia');
    b.append(el('div', 'nx-tag', INTENCOES[r.intencao] || r.intencao), el('div', '', r.resposta));
    const fb = el('div', 'nx-fb');
    const certo = el('button', '', '👍 Certo'), errado = el('button', '', '👎 Errado');
    certo.type = errado.type = 'button';
    certo.onclick = async () => { await api('nota', { id: r.id, nota: 1 }); fb.replaceChildren(el('span', 'nx-pequeno', 'Anotado: ela vai aprender com isso.')); };
    errado.onclick = () => {
      const sel = el('select'); Object.entries(INTENCOES).forEach(([k, v]) => { const o = el('option', '', v); o.value = k; sel.append(o); });
      const ok = el('button', '', 'Enviar correção'); ok.type = 'button';
      ok.onclick = async () => { await api('nota', { id: r.id, nota: -1, correta: sel.value }); fb.replaceChildren(el('span', 'nx-pequeno', 'Correção registrada: vira caso de treino.')); };
      fb.replaceChildren(el('span', 'nx-pequeno', 'Era para:'), sel, ok);
    };
    fb.append(certo, errado); b.append(fb); $('mensagens').append(b); rolar();
  }
  $('form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const texto = $('texto').value.trim(); if (!texto) return;
    $('texto').value = ''; bolhaUsuario(texto);
    const r = await api('conversar', { texto });
    if (r && r.resposta) bolhaIA(r); else if (r) $('mensagens').append(el('div', 'nx-msg nx-ia', r.error || 'Erro.'));
  });

  // ---------- estado ----------
  const mmss = (s) => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  function pintarEstado() {
    if (!estado) return;
    $('e-situacao').textContent = estado.pausado ? 'Pausada' : estado.rodando ? 'Evoluindo agora…'
      : 'Ativa · próximo ciclo em ' + mmss(estado.proximo_ciclo - Date.now() / 1000);
    $('e-versao').textContent = 'v' + estado.versao;
    $('e-aptidao').textContent = estado.aptidao == null ? '—' : Math.round(estado.aptidao * 100) + '%';
    $('e-llm').textContent = estado.llm_online ? 'online (local)' : 'desligado';
    $('e-detalhe').textContent = estado.detalhe_analise || '';
    $('b-evoluir').disabled = estado.pausado || estado.rodando;
    $('b-pausar').textContent = estado.pausado ? 'Retomar' : 'Pausar';
    const sel = $('versao');
    if (document.activeElement !== sel && sel.options.length !== estado.versoes.length) {
      sel.replaceChildren(...estado.versoes.slice().reverse().map((v) => { const o = el('option', '', v); o.value = parseInt(v.slice(1), 10); return o; }));
    }
  }
  async function atualizarEstado() { const e = await api('estado'); if (e && !e.error) { estado = e; pintarEstado(); } }
  async function atualizarHistorico() {
    const h = await api('historico'); if (!h || !h.itens) return;
    $('historico').replaceChildren(...h.itens.map((i) => {
      const li = el('li');
      const quando = el('span', 'nx-hora', new Date(i.ts * 1000).toLocaleTimeString('pt-BR'));
      const tipo = el('span', '', TIPOS[i.tipo] || i.tipo);
      const bom = ['ok', 'aceitavel'].includes(i.resultado), mau = ['erro', 'rejeitada', 'revertida', 'falha'].includes(i.resultado);
      tipo.append(el('span', 'nx-badge ' + (bom ? 'nx-ok' : mau ? 'nx-ruim' : 'nx-neutro'), i.resultado));
      let det = i.detalhe || '';
      if (i.fitness_antes != null && i.fitness_depois != null && i.fitness_antes !== i.fitness_depois)
        det = Math.round(i.fitness_antes * 100) + '% → ' + Math.round(i.fitness_depois * 100) + '% · ' + det;
      li.append(quando, tipo, el('span', 'nx-det', det)); return li;
    }));
  }

  // ---------- Autonomous Evolution Engine ----------
  async function carregarAEE() {
    const r = await api('engenharia/estado');
    if (!r || r.error) { $('aee-status').textContent = r?.error || 'Falha ao carregar o AEE.'; return; }
    const inv = r.inventario || {};
    $('aee-resumo').textContent = `${inv.total_arquivos || 0} arquivos inspecionáveis · HTML: ${inv.por_tipo?.['.html'] || 0} · CSS: ${inv.por_tipo?.['.css'] || 0} · JS: ${inv.por_tipo?.['.js'] || 0} · Modelo local: ${r.llm_online ? 'online' : 'offline'}`;
    const host = $('aee-propostas'); host.replaceChildren();
    (r.propostas || []).forEach((p) => {
      const item = el('article', 'nx-item');
      item.append(el('strong', '', p.resumo || p.id), el('p', 'nx-pequeno', p.objetivo || ''),
        el('p', 'nx-pequeno', `${(p.arquivos || []).length} arquivo(s) · ${p.status}`));
      if (p.status === 'aguardando_aprovacao') {
        const b = el('button', 'nx-botao nx-primario', 'Aprovar e aplicar'); b.type = 'button';
        b.onclick = async () => {
          if (!window.confirm(`Aplicar a proposta ${p.id}? Uma cópia dos arquivos atuais será criada antes da alteração.`)) return;
          b.disabled = true; $('aee-status').textContent = 'Aplicando proposta…';
          const out = await api('engenharia/aplicar', { id: p.id });
          $('aee-status').textContent = out?.error || (out?.proposta ? 'Proposta aplicada. Backup criado.' : 'Não foi possível aplicar.');
          carregarAEE();
        };
        item.append(b);
      }
      host.append(item);
    });
  }
  $('aee-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const objetivo = $('aee-objetivo').value.trim(); if (!objetivo) return;
    $('aee-gerar').disabled = true; $('aee-status').textContent = 'Analisando o projeto e consultando o modelo local…';
    const r = await api('engenharia/propor', { objetivo });
    $('aee-status').textContent = r?.error || (r?.proposta ? `Proposta criada: ${r.proposta.resumo}. Revise antes de aplicar.` : 'Falha ao criar proposta.');
    $('aee-gerar').disabled = false;
    if (r?.proposta) { $('aee-objetivo').value = ''; carregarAEE(); }
  });
  carregarAEE();

  // ---------- ações ----------
  $('b-evoluir').onclick = async () => { await api('evoluir', {}); atualizarEstado(); };
  $('b-pausar').onclick = async () => { await api('interruptor', { pausar: !(estado && estado.pausado) }); atualizarEstado(); };
  $('b-reverter').onclick = async () => {
    const v = parseInt($('versao').value, 10); if (!v) return;
    if (!confirm('Voltar o cérebro para a versão v' + v + '?')) return;
    await api('reverter', { versao: v }); atualizarEstado(); atualizarHistorico();
  };
  $('codigo').addEventListener('toggle', async () => {
    if (!$('codigo').open) return;
    const c = await api('codigo'); if (c && c.cerebro) { $('c-cerebro').textContent = c.cerebro; $('c-aprendido').textContent = c.aprendido; }
  });
  $('sair').onclick = async () => { await fetch('/auth/logout', { method: 'POST', credentials: 'same-origin' }); location.href = '/'; };

  atualizarEstado(); atualizarHistorico();
  setInterval(atualizarEstado, 4000); setInterval(atualizarHistorico, 6000); setInterval(pintarEstado, 1000);
})();
