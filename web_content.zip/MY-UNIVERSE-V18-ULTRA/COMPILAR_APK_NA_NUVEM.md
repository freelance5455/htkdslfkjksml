# Gerar o APK da MY UNIVERSE V18 ULTRA pela nuvem

Este pacote inclui o projeto Android e um workflow do GitHub Actions que compila o APK debug em um runner com Android SDK.

## Passos

1. Crie um repositório privado no GitHub.
2. Envie todo o conteúdo desta pasta para a branch `main` (incluindo `.github/workflows/android-apk.yml`).
3. No repositório, abra **Actions**.
4. Selecione **Build MY UNIVERSE V18 ULTRA APK**.
5. Clique em **Run workflow** e aguarde o job `build-debug-apk` terminar com sucesso.
6. Na página da execução, em **Artifacts**, baixe `MY-UNIVERSE-V18-ULTRA-APK.zip`.
7. Extraia o ZIP. O arquivo `app-debug.apk` é o instalador Android.

O workflow usa a assinatura de depuração automática do Android Gradle Plugin. É apropriada para instalação e testes privados, não para publicação na Play Store. Para distribuir publicamente, será necessária uma chave de assinatura de release mantida em segredo.

## Importante

- O workflow não publica o aplicativo nem envia seus dados para o GitHub.
- Não envie bancos, tokens, senhas, backups ou dados pessoais da instalação para o repositório. O `.gitignore` deve continuar ativo.
- A V17 permanece como base desktop no pacote. Faça backup antes de migrar dados.
- O acesso remoto exige URL HTTPS funcional para o servidor e configuração separada da GFI.
