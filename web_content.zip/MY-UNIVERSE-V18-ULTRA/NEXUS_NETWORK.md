# NEXUS NETWORK — V13

A V13 acrescenta uma camada de entrada por nomes locais, sem reescrever os serviços internos:

- `http://nexus.local` → portal MY UNIVERSE (backend local na porta 8765)
- `http://gfi.nexus.local` → GFI (backend local na porta 8780)

O gateway escuta na porta HTTP 80 e encaminha pelo hostname. As portas internas e o loopback continuam existindo como detalhes de implementação; não são mais os endereços apresentados na navegação pelo NEXUS.

## Instalação (Linux Mint / Ubuntu)

1. Extraia a V13 em uma pasta nova, sem apagar a V12.
2. Migre os dados locais: `./migrar_dados_v12.sh /caminho/da/instalacao/V12`. O script copia `dados/`, `nexus/data/`, os dados do GFI e atualizações sem sobrescrever arquivos existentes.
3. Instale Avahi: `sudo apt install avahi-daemon`.
4. Publique os nomes na rede: `sudo ./configurar_nexus_rede.sh`.
5. Inicie o portal e o gateway: `sudo ./iniciar_nexus_rede.sh`.
6. No celular ou computador conectado à mesma rede Wi-Fi, abra `http://nexus.local`.

Execute `sudo ./iniciar_nexus_rede.sh` a partir da conta normal: o script inicia o portal como o usuário original e eleva apenas o gateway, necessário para a porta 80. O gateway não substitui autenticação. O portal continua exigindo o login existente. O GFI mantém o próprio token de acesso. O gateway só encaminha para os dois backends locais; não cria túnel público nem publica os serviços na internet.

## Limitações e compatibilidade

- `.local` depende de mDNS/Avahi e do suporte do dispositivo/rede. Algumas redes Wi-Fi isolam clientes ou filtram multicast; nesses casos, o nome pode não resolver. A configuração do roteador/DNS local pode ser necessária.
- A porta 80 normalmente exige privilégios administrativos no Linux. O script verifica isso antes de iniciar o gateway.
- A camada de gateway implementa HTTP/1.1 para GET, HEAD, POST, PUT, PATCH, DELETE e OPTIONS. Não implementa WebSocket nem proxy HTTPS.
- A resolução de nomes e o acesso por celular precisam ser validados na rede real do usuário; não são garantidos apenas pela geração do ZIP.
- Os endereços `127.0.0.1`, `8765` e `8780` continuam dentro da configuração dos backends. Não devem ser removidos: são conexões internas locais, não endereços públicos da interface.

## Segurança e credenciais

A V13 não gera, substitui nem inclui tokens ou chaves de API. Os diretórios de dados existentes (`dados/`, inclusive os dados do GFI) devem ser preservados ao atualizar. Faça backup antes de substituir a pasta do aplicativo. Nunca compartilhe o ZIP com arquivos de credenciais locais.

## Diagnóstico

- `http://nexus.local` com erro 503: portal não está ativo na porta configurada.
- `http://gfi.nexus.local` com erro 503: o GFI ainda não foi iniciado; entre no portal e use o botão de acesso ao GFI.
- Nome não resolve: verifique Avahi, isolamento de clientes Wi-Fi e resolução mDNS no dispositivo.
- Porta 80 ocupada: pare o serviço que a utiliza antes de iniciar o gateway.
