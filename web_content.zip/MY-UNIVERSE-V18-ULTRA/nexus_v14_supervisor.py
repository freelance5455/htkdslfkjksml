#!/usr/bin/env python3
"""Supervisor MY UNIVERSE V14: portal + gateway sob controle do systemd."""
from __future__ import annotations
import http.client
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable
PORTAL_HOST, PORTAL_PORT = "127.0.0.1", int(os.environ.get("MY_UNIVERSE_PORT", "8765"))
GFI_HOST, GFI_PORT = "127.0.0.1", int(os.environ.get("GFI_PORTA", "8780"))
GATEWAY_HOST, GATEWAY_PORT = os.environ.get("NEXUS_GATEWAY_HOST", "0.0.0.0"), int(os.environ.get("NEXUS_GATEWAY_PORT", "80"))
children: list[subprocess.Popen] = []
stop_requested = False


def log(message: str) -> None:
    print(f"[MY UNIVERSE V14] {message}", flush=True)


def port_is_free(host: str, port: int) -> bool:
    family = socket.AF_INET6 if ":" in host else socket.AF_INET
    with socket.socket(family, socket.SOCK_STREAM) as sock:
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((host, port))
            return True
        except OSError:
            return False


def preflight() -> None:
    if not (ROOT / "dados" / "usuario.json").is_file():
        raise RuntimeError("Usuário do portal não configurado. Execute ./iniciar.sh uma vez para criar a conta.")
    checks = [(PORTAL_HOST, PORTAL_PORT, "portal"), (GFI_HOST, GFI_PORT, "GFI"), (GATEWAY_HOST, GATEWAY_PORT, "gateway")]
    for host, port, label in checks:
        if not port_is_free(host, port):
            raise RuntimeError(f"Porta {port} ({label}) já está ocupada. Não encerrei o processo existente; identifique-o e pare-o de forma controlada.")


def wait_portal(timeout: float = 15.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if children and any(p.poll() is not None for p in children):
            raise RuntimeError("Um processo encerrou durante a inicialização.")
        try:
            conn = http.client.HTTPConnection(PORTAL_HOST, PORTAL_PORT, timeout=1)
            conn.request("GET", "/")
            response = conn.getresponse()
            response.read()
            conn.close()
            if response.status in (200, 301, 302, 401, 403):
                return
        except OSError:
            pass
        time.sleep(0.25)
    raise RuntimeError("Portal não respondeu na porta configurada dentro de 15 segundos.")


def request_stop(_signum, _frame) -> None:
    global stop_requested
    stop_requested = True


def stop_children() -> None:
    for proc in reversed(children):
        if proc.poll() is None:
            log(f"Encerrando processo gerenciado PID {proc.pid}.")
            proc.terminate()
    deadline = time.monotonic() + 8
    for proc in reversed(children):
        if proc.poll() is None:
            try:
                proc.wait(timeout=max(0.1, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                log(f"PID {proc.pid} não encerrou no prazo; enviando SIGKILL.")
                proc.kill()
    children.clear()


def main() -> int:
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    try:
        preflight()
        env = os.environ.copy()
        env.update({"MY_UNIVERSE_HOST": PORTAL_HOST, "MY_UNIVERSE_PORT": str(PORTAL_PORT), "GFI_PORTA": str(GFI_PORT), "PYTHONUNBUFFERED": "1"})
        log("Iniciando portal na interface loopback.")
        portal = subprocess.Popen([PYTHON, str(ROOT / "server.py")], cwd=ROOT, env=env)
        children.append(portal)
        wait_portal()
        log("Portal respondeu. Iniciando gateway HTTP na porta 80.")
        gateway_env = env.copy()
        gateway_env.update({"NEXUS_GATEWAY_HOST": GATEWAY_HOST, "NEXUS_GATEWAY_PORT": str(GATEWAY_PORT)})
        gateway = subprocess.Popen([PYTHON, str(ROOT / "nexus_gateway.py")], cwd=ROOT, env=gateway_env)
        children.append(gateway)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline and not stop_requested:
            if portal.poll() is not None:
                raise RuntimeError(f"Portal encerrou com código {portal.returncode}.")
            if gateway.poll() is not None:
                raise RuntimeError(f"Gateway encerrou com código {gateway.returncode}.")
            try:
                conn = http.client.HTTPConnection("127.0.0.1", GATEWAY_PORT, timeout=1)
                conn.request("GET", "/", headers={"Host": "nexus.local"})
                response = conn.getresponse()
                response.read()
                conn.close()
                if response.status == 200:
                    break
            except OSError:
                pass
            time.sleep(0.25)
        else:
            if not stop_requested:
                raise RuntimeError("Gateway não ficou pronto dentro de 10 segundos.")
        if not stop_requested:
            log("Serviços ativos: nexus.local -> portal; gfi.nexus.local -> GFI sob demanda. systemd controla o ciclo de vida.")
        while not stop_requested:
            for proc, label in ((portal, "portal"), (gateway, "gateway")):
                code = proc.poll()
                if code is not None:
                    raise RuntimeError(f"{label} encerrou inesperadamente (código {code}).")
            time.sleep(1)
        return 0
    except Exception as exc:
        log(f"FALHA: {exc}")
        return 1
    finally:
        stop_children()
        log("Supervisor encerrado.")


if __name__ == "__main__":
    raise SystemExit(main())
