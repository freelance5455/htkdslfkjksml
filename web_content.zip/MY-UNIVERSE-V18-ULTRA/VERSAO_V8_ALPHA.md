# MY UNIVERSE V8 Alpha

## Origem e estratégia

- Base principal: `MY-universe-V7.zip` (V7; 918.975 bytes; SHA-256 `e8b6e9d5dcc0ba0994ea9846d8b5991e75e7f2b67ad686fdab97023723133e2d`).
- Fonte complementar: `MY-universe-V6.20-internal.zip` (1.218.189 bytes; SHA-256 `c21cd422fe46321abd0c353237b990df4f63832de2e733b26757b25beb4601b0`).
- A V7 foi mantida como base para preservar os módulos e as melhorias operacionais que não existem no pacote V6.20.
- Da V6.20 foram portadas as alterações específicas da Central IA GFI, sem substituir em bloco os arquivos operacionais mais recentes da V7.

## Integração V6.20 → V7

- Chat direto na Central IA GFI, com botão `Perguntar à IA GFI`.
- Nova rota `gfi-ai/chat` na API.
- Descoberta automática de provedores locais: NEXUS/llama.cpp, LM Studio e Ollama; compatibilidade com endpoint OpenAI-compatible/vLLM configurado.
- Endpoints externos exigem HTTPS; HTTP é aceito somente em loopback.
- Se houver modelo conectado e disponível, a resposta é gerada pelo LLM.
- Sem LLM, o botão permanece funcional em modo `local_diagnostico`, apresentando diagnóstico local e informando que não houve inferência generativa.
- Pesquisa externa com alternativa Bing RSS quando a pesquisa primária falhar.
- Indicadores da interface mostram o estado e o provedor efetivamente detectados.
- Assistente opcional `ativar_ia.sh`; não instala nem baixa modelo sem confirmação explícita.
- Documentação de ativação e testes adicionais da IA GFI.

## Preservação da V7

Foram mantidos, sem substituição pela base V6.20:

- Portal MY UNIVERSE, projetos e identidade visual da V7.
- NEXUS e AEE.
- Segurança GFI V7, token de acesso remoto, cookie e validação de Host.
- LIVE isolado, controle de carga e agendador persistente.
- B3 COTAHIST incremental, limites de lote e integrações operacionais da V7.
- Conector CVM DFP/ITR, ledger e armazenamento intradiário da V7.
- Backtest, fila de pesquisa, alertas e validações da V7.

A V6.20 foi criada sobre a linha V6.11 e contém versões anteriores de vários módulos GFI. Por isso, seus arquivos de agendador, conectores, segurança e banco de dados não foram copiados por cima dos correspondentes da V7. A incorporação foi seletiva, centrada no subsistema IA GFI.

## Validação executada nesta construção

- ZIP das duas fontes validado antes da extração (`testzip() = None`).
- `python3 -m compileall -q .` — aprovado.
- `node --check assets/nexus.js` — aprovado.
- `node --check sites/laboratorio-ti/inteligencia-financeira/ui/app.js` — aprovado.
- `bash -n iniciar.sh sites/laboratorio-ti/inteligencia-financeira/ativar_ia.sh` — aprovado.
- Testes GFI: **124 aprovados**.
- Testes direcionados NEXUS/AEE (`TestApi`, `TestValidador`, `TestEngenhariaAEE`): **17 aprovados**.
- Incluído teste específico para confirmar o encaminhamento da rota `gfi-ai/chat`.

## Pendências operacionais — não declarar como concluídas

- Inferência com LLM real: depende de instalar/iniciar um provedor e modelo na máquina operacional.
- Pesquisa externa: depende de DNS, HTTPS e disponibilidade dos provedores.
- Downloads e ingestão reais B3, BCB e CVM: precisam ser validados no computador de operação.
- Feed intradiário contínuo: a camada de armazenamento existe, mas depende de provedor e operação real.
- Operação contínua por vários dias ainda não foi homologada.
- Vínculo automático ticker↔CNPJ via FCA segue pendente de adaptação ao ledger DFP/ITR.

## Classificação

V8 Alpha é uma integração de código validada por testes locais. Não é uma homologação operacional completa e não afirma que provedores externos, modelos de IA ou fontes de mercado estejam ativos.
