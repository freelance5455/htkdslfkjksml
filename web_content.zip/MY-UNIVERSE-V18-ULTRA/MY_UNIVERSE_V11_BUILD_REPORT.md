# MY UNIVERSE V11 — relatório de construção

Base: `MY-UNIVERSE-V10-GFI-WEBMOBILE.zip` fornecido pelo usuário. A V10 foi preservada como ponto de partida; a V11 concentra a atualização visual e responsiva.

## Entregas

### 1. Experiência mobile da GFI
- Navegação inferior fixa, dimensionada para uso com o polegar, com acesso direto a Visão, Mercados, Radar e Minha Conta.
- Destino “Mais” abre um painel compacto com os 19 painéis existentes; nenhum painel foi removido.
- Estado ativo acompanha a rota/hash atual; o menu fecha ao selecionar uma tela ou tocar fora.
- Respeito à área segura inferior do Android/iOS (`env(safe-area-inset-bottom)`).
- Cabeçalho e indicadores reorganizados para telas estreitas.
- KPIs em grade de duas colunas, cartões com hierarquia mais clara, formulários em grade adaptável e controles com alvos de toque maiores.
- Tabelas continuam acessíveis com rolagem horizontal, sem esmagar colunas financeiras.
- Painéis, gavetas e cartões com transparência moderada e desfoque para integrar o fundo sem sacrificar leitura.
- Redução de elementos densos e espaçamentos mais consistentes em larguras de 380 px ou menos.

### 2. Identidade visual e fotografia
- A fotografia MY UNIVERSE vertical enviada pelo usuário foi aplicada como fundo compartilhado da Central, login, NEXUS, GFI e páginas dos projetos.
- Camadas escuras graduais e superfícies semitransparentes mantêm contraste de texto, números e gráficos.
- A mesma identidade aparece em desktop e mobile; no mobile, o fundo passa a rolar com a página para evitar problemas de desempenho e viewport.
- Asset WebP otimizado adicionado para reduzir transferência: `assets/my-universe-portrait.webp` e cópia independente em `sites/laboratorio-ti/inteligencia-financeira/ui/assets/`.

### 3. Preservação funcional
- Nenhum módulo financeiro, endpoint, banco de dados, conector, cálculo, regra de carteira ou painel foi intencionalmente alterado.
- O saldo global, ocultação/revelação e sincronização existentes foram preservados.
- Os 19 painéis continuam disponíveis; o novo dock apenas reorganiza o acesso em telas pequenas.

## Validação executada
- `node --check sites/laboratorio-ti/inteligencia-financeira/ui/app.js`: aprovado.
- `python -m compileall -q .`: aprovado.
- `python -m pytest -q sites/laboratorio-ti/inteligencia-financeira/testes`: 128 testes aprovados e 8 subtestes aprovados.

## Observações
- A versão continua sendo uma aplicação web responsiva, não um aplicativo nativo Android/iOS.
- O fundo usa a fotografia como elemento de identidade; a camada escura é intencional para preservar contraste e leitura de dados.
- O menu “Mais” mantém acessíveis todos os painéis secundários sem sobrecarregar a barra inferior.
