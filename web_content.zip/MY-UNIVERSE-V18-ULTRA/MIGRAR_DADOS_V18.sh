#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Uso: $0 /caminho/da/instalacao-V17" >&2
  exit 2
fi
OLD="$(realpath "$1")"
HERE="$(cd "$(dirname "$0")" && pwd)"
[[ -f "$OLD/server.py" ]] || { echo "Origem não parece uma instalação MY UNIVERSE (server.py ausente)." >&2; exit 1; }
[[ -d "$OLD/sites/laboratorio-ti/inteligencia-financeira" ]] || { echo "Diretório GFI não encontrado na origem." >&2; exit 1; }
for rel in dados nexus/data sites/laboratorio-ti/inteligencia-financeira/dados sites/laboratorio-ti/inteligencia-financeira/backups; do
  if [[ -d "$OLD/$rel" ]]; then
    mkdir -p "$HERE/$rel"
    cp -a "$OLD/$rel/." "$HERE/$rel/"
    echo "Dados preservados: $rel"
  fi
done
echo "Migração concluída. Mantenha a instalação V17 original como backup até validar a V18."
