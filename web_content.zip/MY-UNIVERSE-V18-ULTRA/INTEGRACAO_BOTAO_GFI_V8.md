# Integração do botão de inicialização do GFI — V8 Alpha

## Fluxo
1. No Laboratório de TI, **ABRIR GFI** navega para a página da Inteligência Financeira.
2. Na página da GFI, **ATIVAR E INICIAR GFI** chama `POST /api/gfi/iniciar` no servidor local da MY UNIVERSE.
3. O servidor exige sessão autenticada e valida a origem da requisição.
4. O backend inicia somente o arquivo fixo `servidor.py` da GFI, sem aceitar comandos, caminhos ou argumentos enviados pelo navegador.
5. A inicialização é protegida por lock, evita iniciar uma segunda instância quando a GFI já responde e confirma que a porta responde com o servidor HTTP identificado como GFI.
6. Quando estiver pronta, o navegador abre o painel em `http://127.0.0.1:8780/` (ou na porta definida por `GFI_PORTA`).

## Operação
O portal MY UNIVERSE precisa estar iniciado normalmente por `./iniciar.sh`. Depois disso, não é necessário abrir outro terminal para executar o `./iniciar.sh` interno da GFI. A GFI continua sendo um serviço local independente.

## Arquivos alterados
- `server.py` — endpoint autenticado, validação same-origin e inicialização controlada.
- `sites/laboratorio-ti/index.html` — link **ABRIR GFI**.
- `sites/laboratorio-ti/inteligencia-financeira/index.html` — botão e mensagem de estado.
- `sites/laboratorio-ti/inteligencia-financeira/ativar-gfi.js` — chamada ao backend e abertura do painel.

## Verificações executadas nesta revisão
- `python3 -m py_compile server.py`: aprovado.
- `python3 -m compileall` no servidor e pacote GFI: aprovado.
- `node --check ativar-gfi.js`: aprovado quando Node.js está disponível no ambiente de validação.
- Suíte GFI: 124 testes aprovados.
- Integração HTTP real em portas isoladas: `POST /api/gfi/iniciar` autenticado iniciou a GFI e o painel respondeu HTTP 200 com servidor `GFI`.
- Suíte NEXUS: iniciou, mas não foi concluída dentro do limite de execução desta validação; não é declarada aprovada nesta revisão.

## Limite
O botão inicia o serviço no mesmo computador em que o navegador está usando o portal. O modo de rede do portal não transforma automaticamente o GFI local em serviço acessível por outros dispositivos.
