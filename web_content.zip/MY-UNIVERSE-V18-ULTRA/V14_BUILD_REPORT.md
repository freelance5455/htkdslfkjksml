# MY UNIVERSE V14 — Relatório de construção

## Origem

- Arquivo-base: `MY-UNIVERSE-V13-NEXUS-NETWORK.zip`.
- Tamanho do ZIP de origem: 4.226.039 bytes.
- Estratégia: adicionar gerenciamento de serviços e documentação, preservando os arquivos funcionais da V13. A comparação dos diretórios confirmou que os arquivos de aplicação da V13 permanecem idênticos; o README recebeu apenas a seção de operação V14.

## Alterações

- Adicionados supervisor systemd do portal/gateway e supervisor de publicação mDNS.
- Adicionados instalador, controlador operacional e script de testes.
- Adicionada documentação V14.
- Os serviços são instalados e habilitados, mas não iniciados pelo instalador; a ativação é explícita para evitar conflito com processos V13 que ainda possam estar rodando manualmente.

## Segurança operacional

- O portal, a GFI e o gateway rodam sob a conta normal do usuário.
- A unidade do gateway recebe apenas `CAP_NET_BIND_SERVICE` para abrir a porta 80.
- O instalador não mata processos desconhecidos. O supervisor falha se detectar uma porta ocupada.
- Backups são criados antes de remover apenas os aliases NEXUS dos arquivos `/etc/avahi/hosts` e `/etc/hosts`.
- A GFI continua sendo iniciada sob demanda pela lógica existente do portal.

## Testes previstos/executados

- `./migrar_dados_v14.sh`: teste isolado aprovado; dados da V13 prevaleceram, arquivos exclusivos da V14 foram mantidos e backup pré-migração foi criado.
- `./testar_v14.sh`: aprovado; arquivos, sintaxe Python/Bash, banco GFI e plano de coleta de 145 tarefas encontrados.
- `systemd-analyze verify`: aprovado para as duas unidades de serviço geradas, inclusive validação de caminhos com espaços (validação estrutural da configuração).
- Supervisor de serviços: smoke test aprovado; iniciou portal/gateway em portas isoladas, validou roteamento por Host e encerrou os processos gerenciados.
- Supervisor mDNS: smoke test com publicadores simulados aprovado; iniciou dois publicadores e os encerrou ao receber SIGTERM.
- Supervisor: teste de detecção de porta ocupada/livre aprovado; seleção de IPv4 testada.
- GFI: 128 testes automatizados aprovados (`unittest discover -s testes -t .`).
- NEXUS: 17 testes selecionados de validação, API e engenharia aprovados. A suíte NEXUS completa não terminou dentro do limite de execução de 300 segundos, interrompida durante um teste de evolução/modelo; não declaramos a suíte completa como aprovada.
- Testes de serviço real (systemd em boot, Avahi, DHCP, navegador Android) dependem da instalação na máquina Linux Mint do usuário e não são declarados como executados neste ambiente.
