#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/android"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle não encontrado. Abra android/ no Android Studio ou instale Gradle 8.11.1+." >&2
  exit 2
fi
gradle --no-daemon assembleDebug
printf '\nAPK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
