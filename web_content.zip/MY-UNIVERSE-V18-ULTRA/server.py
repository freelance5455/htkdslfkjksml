#!/usr/bin/env python3
"""MY UNIVERSE — servidor único: login por sessão + arquivos protegidos.

Só usa a biblioteca padrão do Python (3.8+). Veja o README.md.

  python3 server.py --criar-usuario   cria/troca o usuário e a senha
  python3 server.py                   inicia o portal
"""
import getpass
import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from nexus import api as nexus_api, motor as nexus_motor

ROOT = Path(__file__).resolve().parent
USER_FILE = ROOT / "dados" / "usuario.json"
MIN_SENHA = 12
SESSAO_SEGUNDOS = 8 * 3600
ITERACOES = 310_000

PORT = int(os.environ.get("MY_UNIVERSE_PORT", "8765"))
HOST = os.environ.get("MY_UNIVERSE_HOST", "127.0.0.1")
COOKIE_SECURE = os.environ.get("MY_UNIVERSE_COOKIE_SECURE") == "1"
TRUST_PROXY = os.environ.get("MY_UNIVERSE_TRUST_PROXY") == "1"

# Únicos arquivos acessíveis sem login (a tela de entrada).
PUBLICO = {"/", "/index.html", "/assets/login.css", "/assets/login.js", "/assets/fundo.webp"}
EXTENSOES = {".html", ".css", ".js", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif",
             ".svg", ".ico", ".woff", ".woff2", ".ttf", ".otf", ".mp3", ".mp4", ".webm",
             ".glb", ".gltf", ".pdf"}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; "
       "object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'")

SESSOES, FALHAS, LOCK = {}, {}, threading.Lock()

# Inicialização controlada do GFI: nenhum comando ou caminho vem do navegador.
GFI_DIR = ROOT / "sites" / "laboratorio-ti" / "inteligencia-financeira"
GFI_SCRIPT = GFI_DIR / "servidor.py"
GFI_HOST = "127.0.0.1"
GFI_PORT = int(os.environ.get("GFI_PORTA", "8780"))
GFI_PROCESS = None
GFI_LOCK = threading.Lock()


def gfi_respondendo():
    """Confirma que a porta pertence ao servidor HTTP da GFI, não a outro serviço."""
    try:
        with socket.create_connection((GFI_HOST, GFI_PORT), timeout=0.5) as conexao:
            conexao.settimeout(0.5)
            conexao.sendall(f"GET / HTTP/1.0\r\nHost: {GFI_HOST}:{GFI_PORT}\r\n\r\n".encode())
            resposta = conexao.recv(2048).decode("iso-8859-1", "replace")
            return resposta.startswith("HTTP/1.") and "\nServer: GFI" in resposta
    except OSError:
        return False


def gfi_access_url():
    """URL de entrada no GFI com token já existente ou criado em arquivo protegido."""
    arquivo = GFI_DIR / "dados" / "token.txt"
    try:
        token = arquivo.read_text(encoding="utf-8").strip()
    except OSError:
        arquivo.parent.mkdir(parents=True, exist_ok=True)
        token = secrets.token_urlsafe(24)
        arquivo.write_text(token, encoding="utf-8")
        try:
            arquivo.chmod(0o600)
        except OSError:
            pass
    return "http://gfi.nexus.local/?token=" + token


def iniciar_gfi_controlado():
    """Inicia somente o servidor GFI empacotado, sem aceitar comandos externos."""
    global GFI_PROCESS
    with GFI_LOCK:
        if gfi_respondendo():
            return True, "GFI já estava ativo."
        if GFI_PROCESS is not None and GFI_PROCESS.poll() is not None:
            GFI_PROCESS = None
        if GFI_PROCESS is None:
            if not GFI_SCRIPT.is_file():
                return False, "Arquivo servidor.py do GFI não foi encontrado."
            try:
                GFI_PROCESS = subprocess.Popen(
                    [sys.executable, str(GFI_SCRIPT)],
                    cwd=str(GFI_DIR),
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                    start_new_session=True,
                )
            except OSError as exc:
                GFI_PROCESS = None
                return False, f"Não foi possível iniciar o GFI: {exc.__class__.__name__}."
        limite = time.monotonic() + 12
        while time.monotonic() < limite:
            if gfi_respondendo():
                return True, "GFI iniciado e respondendo."
            if GFI_PROCESS is not None and GFI_PROCESS.poll() is not None:
                GFI_PROCESS = None
                return False, "O processo do GFI encerrou durante a inicialização."
            time.sleep(0.2)
        return False, "O GFI não respondeu em 12 segundos. Verifique a porta configurada e o ambiente Python."


def hash_senha(senha, sal):
    return hashlib.pbkdf2_hmac("sha256", senha.encode(), sal, ITERACOES)


def criar_usuario():
    usuario = input("Usuário: ").strip()
    senha = getpass.getpass(f"Senha (mínimo {MIN_SENHA} caracteres): ")
    if not usuario or len(senha) < MIN_SENHA:
        sys.exit(f"Usuário obrigatório e senha com pelo menos {MIN_SENHA} caracteres.")
    if senha != getpass.getpass("Repita a senha: "):
        sys.exit("As senhas não conferem.")
    sal = secrets.token_bytes(16)
    USER_FILE.parent.mkdir(exist_ok=True)
    USER_FILE.write_text(json.dumps({"usuario": usuario, "sal": sal.hex(),
                                     "hash": hash_senha(senha, sal).hex()}))
    USER_FILE.chmod(0o600)
    print("Usuário salvo.")


def carregar_usuario():
    try:
        d = json.loads(USER_FILE.read_text())
        return d["usuario"], bytes.fromhex(d["sal"]), bytes.fromhex(d["hash"])
    except (OSError, ValueError, KeyError):
        sys.exit("Nenhum usuário configurado. Rode: python3 server.py --criar-usuario")


class Handler(SimpleHTTPRequestHandler):
    server_version = "MyUniverse"
    sys_version = ""

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(ROOT), **kw)

    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    def end_headers(self):
        for k, v in (("X-Content-Type-Options", "nosniff"), ("X-Frame-Options", "SAMEORIGIN"),
                     ("Referrer-Policy", "no-referrer"), ("Cache-Control", "no-store"),
                     ("Permissions-Policy", "camera=(), microphone=(), geolocation=()"),
                     ("Content-Security-Policy", CSP)):
            self.send_header(k, v)
        super().end_headers()

    def log_message(self, fmt, *args):
        print(f"[MY UNIVERSE] {self.command} {urlsplit(self.path).path}")

    # ---------- utilidades ----------
    def _json(self, status, payload=None):
        raw = json.dumps(payload).encode() if payload is not None else b""
        self.send_response(status)
        if raw:
            self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _cookie(self, valor, max_age):
        seguro = "; Secure" if COOKIE_SECURE else ""
        self.send_header("Set-Cookie", f"mu_sessao={valor}; Path=/; HttpOnly; SameSite=Strict; Max-Age={max_age}{seguro}")

    def _sid(self):
        for parte in self.headers.get("Cookie", "").split(";"):
            nome, _, valor = parte.strip().partition("=")
            if nome == "mu_sessao":
                return valor
        return ""

    def _logado(self):
        agora = time.monotonic()
        with LOCK:
            for sid in [s for s, exp in SESSOES.items() if exp <= agora]:
                del SESSOES[sid]
            return self._sid() in SESSOES

    def _mesma_origem(self):
        if self.headers.get("Sec-Fetch-Site", "").lower() == "cross-site":
            return False
        origem = self.headers.get("Origin")
        return not origem or urlsplit(origem).netloc == self.headers.get("Host", "")

    def _ip(self):
        if TRUST_PROXY:
            try:
                return str(ipaddress.ip_address(self.headers.get("CF-Connecting-IP", "")))
            except ValueError:
                pass
        return self.client_address[0]

    # ---------- arquivos ----------
    def _alvo(self):
        """Devolve o arquivo a servir ou None (404). Nunca expõe código, dados ou ocultos."""
        caminho = urlsplit(self.path).path
        try:
            alvo = (ROOT / caminho.lstrip("/")).resolve()
            alvo.relative_to(ROOT)
            if alvo.is_dir():
                alvo = alvo / "index.html"
            partes = alvo.relative_to(ROOT).parts
        except (ValueError, OSError):
            return None, caminho
        if not alvo.is_file() or alvo.suffix.lower() not in EXTENSOES:
            return None, caminho
        if any(p.startswith(".") for p in partes) or partes[0] in {"dados", "nexus"}:
            return None, caminho
        return alvo, "/" + "/".join(alvo.relative_to(ROOT).parts)

    def _servir(self, metodo):
        caminho = urlsplit(self.path).path
        if caminho == "/auth/session":
            return self._json(200, {"authenticated": self._logado()})
        alvo, normal = self._alvo()
        if alvo is None:
            return self.send_error(404)
        if normal not in PUBLICO and not self._logado():
            self.send_response(303)
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            return self.end_headers()
        self.path = normal
        return metodo()

    def _nexus(self):
        """/api/nexus/*: exige login (e mesma origem nos POST); a lógica fica em nexus/api.py."""
        if not self._logado():
            return self._json(401, {"error": "Faça login."})
        corpo = {}
        if self.command == "POST":
            if not self._mesma_origem():
                return self._json(403, {"error": "Origem não permitida."})
            try:
                tamanho = int(self.headers.get("Content-Length", "0"))
                if tamanho > 20_000:
                    return self._json(413, {"error": "Corpo grande demais."})
                corpo = json.loads(self.rfile.read(tamanho) or b"{}")
                if not isinstance(corpo, dict):
                    raise ValueError
            except (ValueError, TypeError):
                return self._json(400, {"error": "Requisição inválida."})
        try:
            status, payload = nexus_api.tratar(self.command, urlsplit(self.path).path, corpo)
        except Exception as e:           # a API do NEXUS nunca derruba o portal
            print(f"[NEXUS] erro: {type(e).__name__}: {e}")
            status, payload = 500, {"error": "Erro interno do NEXUS."}
        self._json(status, payload)

    def do_GET(self):
        caminho = urlsplit(self.path).path
        if caminho.startswith("/api/nexus/"):
            return self._nexus()
        if caminho == "/api/gfi/status":
            if not self._logado():
                return self._json(401, {"error": "Faça login."})
            return self._json(200, {"running": gfi_respondendo(), "url": gfi_access_url()})
        self._servir(super().do_GET)

    def do_HEAD(self):
        self._servir(super().do_HEAD)

    # ---------- login / logout ----------
    def do_POST(self):
        caminho = urlsplit(self.path).path
        if caminho.startswith("/api/nexus/"):
            return self._nexus()
        if caminho == "/api/gfi/iniciar":
            if not self._logado():
                return self._json(401, {"error": "Faça login."})
            if not self._mesma_origem():
                return self._json(403, {"error": "Origem não permitida."})
            ok, mensagem = iniciar_gfi_controlado()
            return self._json(200 if ok else 503, {"running": ok, "message": mensagem,
                                                    "url": gfi_access_url()})
        if not self._mesma_origem():
            return self._json(403, {"error": "Origem não permitida."})
        if caminho == "/auth/logout":
            with LOCK:
                SESSOES.pop(self._sid(), None)
            self.send_response(204)
            self._cookie("", 0)
            self.send_header("Content-Length", "0")
            return self.end_headers()
        if caminho != "/auth/login":
            return self._json(404, {"error": "Não encontrado."})

        ip, agora = self._ip(), time.monotonic()
        with LOCK:
            recentes = [t for t in FALHAS.get(ip, []) if agora - t < 300]
            FALHAS[ip] = recentes
            if len(FALHAS) > 2000:
                FALHAS.pop(next(iter(FALHAS)))
            if len(recentes) >= 8:
                return self._json(429, {"error": "Muitas tentativas. Aguarde cinco minutos."})
        try:
            tamanho = int(self.headers.get("Content-Length", "0"))
            if not 1 <= tamanho <= 4096:
                raise ValueError
            dados = json.loads(self.rfile.read(tamanho))
            usuario, senha = str(dados["username"])[:200], str(dados["password"])[:1024]
        except (ValueError, TypeError, KeyError):
            return self._json(400, {"error": "Requisição inválida."})

        ok_usuario = hmac.compare_digest(usuario.encode(), USUARIO.encode())
        ok_senha = hmac.compare_digest(hash_senha(senha, SAL), HASH)
        if not (ok_usuario and ok_senha):
            with LOCK:
                FALHAS.setdefault(ip, []).append(agora)
            time.sleep(0.2)
            return self._json(401, {"error": "Usuário ou senha inválidos."})

        sid = secrets.token_urlsafe(32)
        with LOCK:
            SESSOES[sid] = agora + SESSAO_SEGUNDOS
            FALHAS.pop(ip, None)
        self.send_response(204)
        self._cookie(sid, SESSAO_SEGUNDOS)
        self.send_header("Content-Length", "0")
        self.end_headers()


def ip_da_rede():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.connect(("10.255.255.255", 1))  # não envia nada; só descobre a interface
        return s.getsockname()[0]


if __name__ == "__main__":
    if "--criar-usuario" in sys.argv:
        criar_usuario()
        sys.exit(0)
    if os.environ.get("MY_UNIVERSE_USERNAME") and os.environ.get("MY_UNIVERSE_PASSWORD"):
        USUARIO, SAL = os.environ["MY_UNIVERSE_USERNAME"], secrets.token_bytes(16)
        HASH = hash_senha(os.environ["MY_UNIVERSE_PASSWORD"], SAL)
    else:
        USUARIO, SAL, HASH = carregar_usuario()
    if HOST == "rede":
        HOST = ip_da_rede()
    try:
        endereco = ipaddress.ip_address(HOST)
        if not (endereco.is_loopback or endereco.is_private):
            sys.exit("Use apenas endereço local. Para acesso externo, use ./iniciar.sh --online.")
    except ValueError:
        sys.exit("MY_UNIVERSE_HOST deve ser um IP local (ou 'rede').")
    if os.environ.get("NEXUS_LIGADO", "1") != "0":
        nexus_motor.iniciar()            # auto-análise e evolução em segundo plano
    servidor = ThreadingHTTPServer((HOST, PORT), Handler)
    servidor.daemon_threads = True
    print(f"MY UNIVERSE em http://{HOST}:{PORT}  (Ctrl+C para sair)")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrado.")
