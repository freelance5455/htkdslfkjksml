# MY UNIVERSE — V7

## Base integrada

A V7 combina a linha MY UNIVERSE V6.11 (incluindo NEXUS AEE, Central IA GFI e fundação de armazenamento intradiário) com melhorias operacionais existentes no pacote V6.

A V6.11 foi mantida como base do portal e da experiência. Os recursos V6 foram integrados seletivamente, sem substituir os módulos exclusivos da V6.11.

## Integrações realizadas

### Portal e NEXUS
- Preservados o portal, os projetos existentes, o NEXUS e o Autonomous Evolution Engine (AEE).
- Mantidos os limites de segurança do AEE: propostas isoladas, revisão humana, validação de hash e backup antes da aplicação.
- Nenhuma alteração automática foi autorizada para o núcleo protegido.

### GFI — operação e proteção
- Recuperado o modo de acesso pela rede local com token persistente em `dados/token.txt`.
- O modo padrão permanece em `127.0.0.1`; para acesso por outros dispositivos, usar `./iniciar.sh --rede`.
- O token é entregue por cookie `HttpOnly`, `SameSite=Strict`; painel e API exigem autorização quando o cliente não é local.
- Validação do cabeçalho Host preservada para reduzir risco de DNS rebinding.
- LIVE executa em fio próprio, com rodízio de instrumentos, limite por ciclo, orçamento de tempo e adiamento sob pressão de CPU/RAM.
- Agendador persiste horários de execução, reduz mensagens repetidas de pressão de recursos e inclui coleta periódica CVM compatível com o contrato DFP/ITR da V6.11.
- B3 COTAHIST mantém validação e status da V6.11, com histórico padrão de três anos e opção para não baixar novamente anos encerrados já coletados.
- Modos de processamento ampliados: econômico 150, normal 600 e intensivo 5.000 ativos por lote.
- Recuperadas as melhorias de fila de pesquisa, baselines do backtest e tratamento de saltos de preço potencialmente causados por eventos corporativos não ajustados.

### Central IA GFI e intradiário
- Preservada a Central IA GFI da V6.11: diagnóstico, pesquisa pública, relatórios e propostas experimentais isoladas.
- Mantida a regra de que código gerado não é executado nem aplicado automaticamente.
- Preservada a camada de persistência intradiária da V6.11, separada das cotações diárias.
- Não foi adicionado provedor intradiário; sem feed configurado, a plataforma não fabrica cotações em tempo real.

## Compatibilidade e decisões de integração

- O conector CVM estruturado DFP/ITR da V6.11 foi mantido, pois utiliza o ledger rastreável por CNPJ e o contrato atual da API. O antigo conector FCA da V6 possui tabelas e formato de fundamentos diferentes; não foi copiado por cima do novo conector. O vínculo automático ticker↔CNPJ via FCA permanece uma evolução separada.
- O contrato atual da API B3 (`validar_anos`, `status`) foi preservado; a coleta incremental foi integrada sem remover essas funções.
- A suíte antiga `test_v6.py` não foi incorporada como suíte ativa porque pressupõe esquemas e contratos de CVM/LIVE anteriores à V6.11. Os comportamentos compatíveis foram integrados e a nova proteção por token recebeu testes próprios.
- Os arquivos de dados e bancos existentes não foram sobrescritos durante a construção. A migração deve ser testada em cópia do banco de operação antes de atualizar a instalação real.

## Verificações desta construção

- Compilação Python do projeto: aprovada.
- `node --check assets/nexus.js`: aprovado.
- `node --check ui/app.js` da GFI: aprovado.
- Suíte GFI: **114 testes aprovados**.
- Testes direcionados do NEXUS/AEE: **17 aprovados**. A suíte integral do NEXUS não foi declarada aprovada nesta construção.
- Downloads reais de B3, BCB e CVM, disponibilidade de LLM e feed intradiário dependem de homologação na máquina de operação.

## Operação

Portal:
```bash
./iniciar.sh
```

GFI apenas neste computador:
```bash
cd sites/laboratorio-ti/inteligencia-financeira
./iniciar.sh
```

GFI pela rede local (token obrigatório para clientes remotos):
```bash
cd sites/laboratorio-ti/inteligencia-financeira
./iniciar.sh --rede
```

Para ativar a Central IA GFI com análise generativa, configure `GFI_AI_LLM_URL` e `GFI_AI_LLM_MODEL`; `GFI_AI_LLM_API_KEY` é opcional. Sem LLM, o agente deve declarar explicitamente que a análise generativa não ocorreu.

## Critério de conclusão

A V7 é uma integração de software validada pela suíte local, não uma declaração de homologação operacional completa. A coleta real das fontes, o vínculo CVM, a qualidade dos dados, a operação prolongada e o feed intradiário continuam sujeitos a testes e evidências no computador de implantação.
