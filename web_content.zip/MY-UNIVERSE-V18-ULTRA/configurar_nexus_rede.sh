#!/usr/bin/env bash
# Publica os nomes NEXUS via Avahi no computador host (Debian/Ubuntu/Mint).
set -euo pipefail
command -v avahi-daemon >/dev/null 2>&1 || { echo 'Instale avahi-daemon: sudo apt install avahi-daemon'; exit 1; }
IP="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')"
[[ -n "$IP" ]] || { echo 'Não foi possível detectar o IP IPv4 da rede.' >&2; exit 1; }
FILE=/etc/avahi/hosts
sudo touch "$FILE"
sudo sed -i '/# NEXUS NETWORK BEGIN/,/# NEXUS NETWORK END/d' "$FILE"
printf '# NEXUS NETWORK BEGIN\n%s nexus.local gfi.nexus.local\n# NEXUS NETWORK END\n' "$IP" | sudo tee -a "$FILE" >/dev/null
sudo systemctl enable --now avahi-daemon
sudo systemctl restart avahi-daemon
echo "Nomes NEXUS publicados para $IP. Dispositivos devem estar na mesma rede local."
