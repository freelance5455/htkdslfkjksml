# MY UNIVERSE — V6.11

Base de desenvolvimento: MY UNIVERSE V6.08, preservando os projetos e módulos já existentes.

## Objetivo desta revisão

Adicionar à Global Financial Intelligence (GFI) uma Central de Inteligência Artificial com autonomia nível 3 — evolução autônoma supervisionada.

## Implementado nesta revisão

- Novo módulo `sites/laboratorio-ti/inteligencia-financeira/gfi/ia_evolucao.py`.
- Painel próprio **Central IA GFI** na navegação da GFI.
- Diagnóstico do inventário Python, documentação, cobertura, fila de pesquisa, propostas e falhas de coleta.
- Pesquisa web pública via DuckDuckGo HTML e leitura limitada de até seis páginas HTTPS públicas, com registro dos links encontrados.
- Compatibilidade com endpoint de chat no formato OpenAI (`GFI_AI_LLM_URL`, `GFI_AI_LLM_MODEL`, `GFI_AI_LLM_API_KEY`) ou reutilização do modelo local da NEXUS, quando disponível.
- Relatórios persistidos em `dados/gfi_ai/relatorios/`.
- Código gerado, quando fornecido pelo modelo, fica isolado em `laboratorio/gfi_ai/propostas/` e passa por verificação sintática (`ast.parse`) e sinalização estática de operações sensíveis; isso não substitui revisão humana.
- Agente periódico com intervalo configurável de 1 a 168 horas; padrão de 24 horas e ativo por padrão. Também é possível executar um ciclo manual ou pausar a rotina.
- Histórico de relatórios e apresentação do estado do modelo na interface.

## Autonomia e segurança

O agente pode pesquisar, diagnosticar, propor e preparar código. **Não** altera arquivos de produção, não executa código gerado, não instala dependências e não publica atualizações automaticamente. Código e recomendações exigem revisão humana. A produção financeira e os arquivos protegidos continuam fora do alcance de escrita do agente.

O acesso à Internet ocorre no servidor local durante os ciclos de pesquisa. A pesquisa atual consulta páginas de resultados públicas; não baixa nem executa os sites ou programas encontrados. Resultados externos são referências, não instruções confiáveis.

## Configuração de modelo de linguagem

Para habilitar análise generativa e criação de código, configure no ambiente que inicia o servidor:

```bash
export GFI_AI_LLM_URL="http://127.0.0.1:8080/v1/chat/completions"
export GFI_AI_LLM_MODEL="nome-do-modelo"
# Opcional para endpoints autenticados:
export GFI_AI_LLM_API_KEY="sua-chave"
./iniciar.sh
```

Alternativamente, o agente tenta reutilizar o cliente local da NEXUS, se o modelo estiver disponível. Sem LLM, o painel continua fazendo inventário e pesquisa e informa explicitamente que não houve análise generativa. Nenhuma chave é gravada no projeto.

## Rotas

- `GET /api/gfi-ai` — estado, autonomia, configuração e histórico.
- `POST /api/gfi-ai/ciclo` — executar um ciclo manual.
- `POST /api/gfi-ai/configurar` — ativar/pausar e ajustar intervalo.
- `GET /api/gfi-ai/relatorio/{id}` — ler relatório.

## Validação executada no ambiente de construção

- `python -m py_compile servidor.py gfi/*.py`: aprovado.
- `python -m unittest discover -s testes -t .`: 110 testes aprovados, incluindo testes específicos da Central IA GFI.
- `node --check ui/app.js`: aprovado.
- Importação das rotas e leitura do estado da Central IA: aprovado.

A disponibilidade de Internet e de um modelo LLM deve ser validada na máquina de operação; não é afirmado que o endpoint de IA esteja configurado nesta máquina.
