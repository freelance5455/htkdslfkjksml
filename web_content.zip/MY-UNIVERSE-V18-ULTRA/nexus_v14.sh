#!/usr/bin/env bash
# Controle operacional dos serviços systemd MY UNIVERSE V14.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ACTION="${1:-status}"
if [[ "$EUID" -ne 0 ]]; then exec sudo "$ROOT/nexus_v14.sh" "$ACTION"; fi
case "$ACTION" in
  start)
    systemctl restart avahi-daemon
    systemctl start nexus-mdns-v14.service
    systemctl start my-universe-v14.service
    echo 'MY UNIVERSE V14 iniciado.' ;;
  stop)
    systemctl stop my-universe-v14.service nexus-mdns-v14.service
    echo 'MY UNIVERSE V14 encerrado.' ;;
  restart)
    systemctl stop my-universe-v14.service nexus-mdns-v14.service
    systemctl restart avahi-daemon
    systemctl start nexus-mdns-v14.service
    systemctl start my-universe-v14.service
    echo 'MY UNIVERSE V14 reiniciado.' ;;
  status)
    systemctl --no-pager --full status my-universe-v14.service nexus-mdns-v14.service || true ;;
  logs)
    journalctl -fu my-universe-v14.service -u nexus-mdns-v14.service ;;
  enable)
    systemctl enable my-universe-v14.service nexus-mdns-v14.service
    echo 'Inicialização automática habilitada.' ;;
  disable)
    systemctl disable my-universe-v14.service nexus-mdns-v14.service
    echo 'Inicialização automática desabilitada.' ;;
  *) echo "Uso: $0 {start|stop|restart|status|logs|enable|disable}" >&2; exit 2 ;;
esac
