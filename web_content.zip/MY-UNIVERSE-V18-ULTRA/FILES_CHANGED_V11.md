# V11 — arquivos alterados

- `assets/my-universe-portrait.webp` — fotografia MY UNIVERSE otimizada para a identidade compartilhada.
- `assets/painel.css` — fundo fotográfico, transparência e contraste da Central.
- `assets/login.css` — fundo fotográfico e cartão de login semitransparente.
- `assets/nexus.css` — identidade visual e ajustes mobile do NEXUS.
- `sites/*/css/style.css` — fundo compartilhado em todos os projetos internos.
- `sites/laboratorio-ti/inteligencia-financeira/ui/assets/my-universe-portrait.webp` — asset local da GFI para implantação independente.
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.css` — revisão ampla do layout mobile e superfícies semitransparentes.
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.js` — dock mobile e menu de acesso aos 19 painéis.
- `MY_UNIVERSE_V11_BUILD_REPORT.md`, `VERSAO_V11.md` — documentação e validação.

Nenhum arquivo de dados financeiros, banco de dados, endpoint ou módulo de cálculo foi alterado intencionalmente.
