# Arquivos alterados — V7

## Base preservada
- Portal e projetos da V6.11.
- NEXUS/AEE e limites de aplicação supervisionada.
- Central IA GFI e rotas de diagnóstico/evolução.
- Ledger CVM DFP/ITR, fundação intradiária e correções de ciclo de vida SQLite.

## Integrações V6
- `sites/laboratorio-ti/inteligencia-financeira/gfi/acesso.py`
- `servidor.py`, `gfi/config.py`, `iniciar.sh`
- `gfi/live_auto.py`, `gfi/agendador.py`
- `gfi/conectores/base.py`, `gfi/conectores/b3_cotahist.py`
- `gfi/pesquisa.py`, `gfi/backtest.py`
- `gfi/validacao.py`, `gfi/motores/pontuacao.py`

## Testes e documentação
- `testes/test_acesso_v7.py`
- `VERSAO_V7.md`
- `V7_MERGE_REPORT.md`
- `TEST_REPORT.md`
- `README.md` e README da GFI
