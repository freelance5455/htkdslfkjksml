"""GUARDIÃO — memória SQLite (conversas, casos aprendidos, histórico de evolução)."""
import re
import sqlite3
import threading
from contextlib import contextmanager
import time
import unicodedata

from . import config

_LOCK = threading.RLock()
_SCHEMA = """
CREATE TABLE IF NOT EXISTS mensagens(id INTEGER PRIMARY KEY, ts REAL, texto TEXT, intencao TEXT, resposta TEXT);
CREATE TABLE IF NOT EXISTS casos(id INTEGER PRIMARY KEY, ts REAL, frase TEXT UNIQUE, intencao TEXT);
CREATE TABLE IF NOT EXISTS memorias(id INTEGER PRIMARY KEY, ts REAL, texto TEXT);
CREATE TABLE IF NOT EXISTS evolucoes(id INTEGER PRIMARY KEY, ts REAL, tipo TEXT, resultado TEXT,
    versao INTEGER, fitness_antes REAL, fitness_depois REAL, detalhe TEXT);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
"""
_PARADAS = {"o", "a", "os", "as", "de", "do", "da", "que", "e", "eu", "me", "meu", "minha", "um", "uma",
            "em", "no", "na", "para", "por", "com", "sobre", "foi", "sao", "qual", "quando", "voce"}


_PRONTOS = set()


@contextmanager
def _con():
    """Abre uma conexão SQLite por operação e sempre a fecha ao sair do contexto."""
    config.DATA.mkdir(parents=True, exist_ok=True)
    caminho = str(config.DATA / "nexus.db")
    con = sqlite3.connect(caminho, timeout=10)
    con.row_factory = sqlite3.Row
    try:
        if caminho not in _PRONTOS:      # cria as tabelas sozinho na primeira conexão
            con.executescript(_SCHEMA)
            _PRONTOS.add(caminho)
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def iniciar():
    with _LOCK, _con():
        pass


def executar(sql, args=()):
    with _LOCK, _con() as con:
        return con.execute(sql, args).lastrowid


def consultar(sql, args=()):
    with _LOCK, _con() as con:
        return [dict(r) for r in con.execute(sql, args).fetchall()]


def kv_get(chave, padrao=None):
    r = consultar("SELECT v FROM kv WHERE k=?", (chave,))
    return r[0]["v"] if r else padrao


def kv_set(chave, valor):
    executar("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (chave, str(valor)))


def tokens(texto):
    t = unicodedata.normalize("NFKD", str(texto).lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    return [w for w in re.findall(r"[a-z0-9]+", t) if w not in _PARADAS and len(w) > 1]


def guardar_memoria(texto):
    return executar("INSERT INTO memorias(ts,texto) VALUES(?,?)", (time.time(), texto))


def buscar_memorias(consulta, n=3):
    alvo = set(tokens(consulta))
    pontuadas = []
    for m in consultar("SELECT id,texto FROM memorias ORDER BY id DESC LIMIT 500"):
        pontos = len(alvo & set(tokens(m["texto"])))
        if pontos:
            pontuadas.append((pontos, m["id"], m["texto"]))
    pontuadas.sort(reverse=True)
    return [t for _, _, t in pontuadas[:n]]


def registrar_mensagem(texto, intencao, resposta):
    return executar("INSERT INTO mensagens(ts,texto,intencao,resposta) VALUES(?,?,?,?)",
                    (time.time(), texto, intencao, resposta))


def adicionar_caso(frase, intencao):
    executar("INSERT INTO casos(ts,frase,intencao) VALUES(?,?,?) "
             "ON CONFLICT(frase) DO UPDATE SET intencao=excluded.intencao,ts=excluded.ts",
             (time.time(), frase, intencao))


def casos_feedback():
    return consultar("SELECT frase,intencao FROM casos ORDER BY id")


def log_evolucao(tipo, resultado, versao=None, antes=None, depois=None, detalhe=""):
    executar("INSERT INTO evolucoes(ts,tipo,resultado,versao,fitness_antes,fitness_depois,detalhe) "
             "VALUES(?,?,?,?,?,?,?)", (time.time(), tipo, resultado, versao, antes, depois, str(detalhe)[:1500]))


def historico(n=25):
    return consultar("SELECT * FROM evolucoes ORDER BY id DESC LIMIT ?", (n,))
