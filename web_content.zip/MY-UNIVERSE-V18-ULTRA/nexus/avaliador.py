"""GUARDIÃO — decide se um código candidato é seguro e se é melhor que o atual.

A IA nunca edita este arquivo. Ele faz três coisas:
  1. validar_codigo: análise estática (AST) — recusa imports/chamadas perigosas;
  2. avaliar: roda o candidato num subprocesso isolado, com limites e tempo máximo;
  3. aptidao: nota única usada para ordenar candidatos (a confirmação só veta).

Três conjuntos de casos: treino (a IA vê), holdout (seleciona) e confirmação (só veta promoções).
"""
import ast
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from . import config, memoria

GRUPOS = ("train", "holdout", "confirmacao")
IMPORTS_PERMITIDOS = {"re", "math", "unicodedata", "collections", "functools", "itertools",
                      "string", "difflib", "statistics"}
NOMES_PROIBIDOS = {"exec", "eval", "compile", "open", "__import__", "input", "breakpoint", "globals",
                   "locals", "vars", "getattr", "setattr", "delattr", "exit", "quit", "print", "help"}
MAX_BYTES = 40_000
MAX_ATRIBUTOS = 6000

HARNESS = r'''
import io, json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
casos = json.load(open("casos.json"))
real = sys.stdout
sys.stdout = io.StringIO()
def sair(d):
    sys.stdout = real
    print("@@R@@" + json.dumps(d))
    sys.exit(0)
try:
    from nucleo import cerebro
except BaseException as e:
    sair({"erro": "import: " + type(e).__name__ + ": " + str(e)[:200]})
out = {"falhas": [], "ms": 0.0}
t0 = time.perf_counter()
for grupo in ("train", "holdout", "confirmacao"):
    out[grupo] = [0, 0]
    for c in casos.get(grupo, []):
        out[grupo][1] += 1
        try:
            r = cerebro.classificar(c["frase"])
        except BaseException:
            r = None
        if r == c["intencao"]:
            out[grupo][0] += 1
        elif grupo == "train":
            out["falhas"].append({"frase": c["frase"], "esperado": c["intencao"],
                                  "obtido": r if isinstance(r, str) else None})
out["ms"] = round((time.perf_counter() - t0) * 1000, 2)
sair(out)
'''

_SHELL = ('ulimit -t 10 2>/dev/null; ulimit -v 786432 2>/dev/null; ulimit -f 2048 2>/dev/null; '
          'ulimit -n 64 2>/dev/null; exec "$0" -I harness.py')


def _validar_aprendido(arvore):
    erros, nomes = [], {}
    for no in arvore.body:
        if isinstance(no, ast.Expr) and isinstance(no.value, ast.Constant):
            continue                                   # docstring
        if isinstance(no, ast.Assign) and len(no.targets) == 1 and isinstance(no.targets[0], ast.Name):
            try:
                nomes[no.targets[0].id] = ast.literal_eval(no.value)
                continue
            except (ValueError, SyntaxError):
                pass
        erros.append(f"aprendido.py aceita só dados literais (linha {no.lineno})")
    if erros:
        return erros
    pesos, limiar = nomes.get("PESOS"), nomes.get("LIMIAR")
    if not isinstance(pesos, dict) or not all(isinstance(k, str) and isinstance(d, dict) for k, d in pesos.items()):
        return ["PESOS deve ser {intenção: {atributo: peso}}"]
    total = 0
    for d in pesos.values():
        for a, w in d.items():
            total += 1
            if not isinstance(a, str) or isinstance(w, bool) or not isinstance(w, (int, float)) or abs(w) > 50:
                return ["peso inválido em PESOS"]
    if total > MAX_ATRIBUTOS:
        return ["PESOS grande demais"]
    if isinstance(limiar, bool) or not isinstance(limiar, (int, float)) or not 0 <= limiar <= 20:
        return ["LIMIAR deve ser número entre 0 e 20"]
    return []


def validar_codigo(nome, codigo):
    """Devolve a lista de problemas (vazia = código aceito)."""
    if nome not in config.EDITAVEIS:
        return [f"arquivo não editável: {nome}"]
    if len(codigo.encode()) > MAX_BYTES:
        return ["arquivo grande demais"]
    try:
        arvore = ast.parse(codigo)
    except (SyntaxError, ValueError) as e:
        return [f"sintaxe inválida: {getattr(e, 'lineno', '?')}"]
    if nome == "aprendido.py":
        return _validar_aprendido(arvore)
    erros = []
    for no in ast.walk(arvore):
        if isinstance(no, ast.Import):
            for a in no.names:
                if a.name.split(".")[0] not in IMPORTS_PERMITIDOS:
                    erros.append(f"import proibido: {a.name}")
        elif isinstance(no, ast.ImportFrom):
            if no.level == 1 and no.module is None and {a.name for a in no.names} <= {"aprendido"}:
                continue
            if no.level == 0 and (no.module or "").split(".")[0] in IMPORTS_PERMITIDOS:
                continue
            erros.append(f"import proibido: {no.module or '.'}")
        elif isinstance(no, ast.Name) and (no.id in NOMES_PROIBIDOS or (no.id.startswith("__") and no.id != "__name__")):
            erros.append(f"nome proibido: {no.id}")
        elif isinstance(no, ast.Attribute) and no.attr.startswith("__"):
            erros.append(f"atributo proibido: {no.attr}")
        elif isinstance(no, (ast.Global, ast.Nonlocal)):
            erros.append("global/nonlocal proibido")
    if not any(isinstance(n, ast.FunctionDef) and n.name == "classificar" for n in arvore.body):
        erros.append("falta a função classificar(frase) no nível do módulo")
    return erros


def avaliar(pasta_nucleo, casos, timeout=25):
    """Roda `nucleo` isolado e devolve acertos por grupo, falhas de treino e tempo — ou {'erro': ...}."""
    with tempfile.TemporaryDirectory() as t:
        raiz = Path(t)
        shutil.copytree(pasta_nucleo, raiz / "nucleo", ignore=shutil.ignore_patterns("__pycache__"))
        (raiz / "casos.json").write_text(json.dumps(casos))
        (raiz / "harness.py").write_text(HARNESS)
        try:
            p = subprocess.run(["/bin/sh", "-c", _SHELL, sys.executable], cwd=t, capture_output=True, text=True,
                               timeout=timeout, env={"PATH": "/usr/bin:/bin", "PYTHONHASHSEED": "0"})
        except subprocess.TimeoutExpired:
            return {"erro": "tempo esgotado"}
    linhas = [l for l in p.stdout.splitlines() if l.startswith("@@R@@")]
    if not linhas:
        return {"erro": "sem resultado: " + (p.stderr.strip().splitlines() or ["?"])[-1][:200]}
    res = json.loads(linhas[-1][5:])
    if "erro" not in res and res["ms"] > config.MAX_LENTO_MS:
        return {"erro": f"classificador lento ({res['ms']} ms)"}
    return res


def casos():
    """Base + feedback do usuário (só entra no treino; holdout e confirmação são fixos)."""
    base = json.loads(config.CASOS_BASE.read_text(encoding="utf-8"))
    fixos = {c["frase"] for g in GRUPOS for c in base.get(g, [])}
    extra = [c for c in memoria.casos_feedback() if c["frase"] not in fixos]
    return {"train": base["train"] + extra, "holdout": base["holdout"], "confirmacao": base.get("confirmacao", [])}


def acuracia(res, grupo):
    if "erro" in res or not res[grupo][1]:
        return 0.0
    return round(res[grupo][0] / res[grupo][1], 4)


def aptidao(res):
    """0,6 × holdout + 0,4 × treino (0 se houve erro). Serve para ordenar candidatos."""
    if "erro" in res:
        return 0.0
    return round(0.6 * acuracia(res, "holdout") + 0.4 * acuracia(res, "train"), 4)
