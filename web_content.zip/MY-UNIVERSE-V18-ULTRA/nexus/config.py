"""GUARDIÃO — caminhos e limites. A IA nunca edita este arquivo."""
import os
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
NUCLEO = RAIZ / "nucleo"            # única pasta que a IA pode reescrever
DATA = RAIZ / "data"                # banco, versões e interruptor
CASOS_BASE = RAIZ / "casos_base.json"
EDITAVEIS = ("cerebro.py", "aprendido.py")   # únicos arquivos editáveis pela IA

INTERVALO = int(os.environ.get("NEXUS_INTERVALO", "900"))          # s entre ciclos
PRIMEIRO_CICLO = int(os.environ.get("NEXUS_PRIMEIRO_CICLO", "30"))  # s após iniciar
MAX_PROMOCOES_DIA = int(os.environ.get("NEXUS_MAX_PROMOCOES_DIA", "12"))
MARGEM = 0.005                      # ganho mínimo de aptidão para promover
MANTER_VERSOES = 30

LLM_URL = os.environ.get("NEXUS_LLM_URL", "http://127.0.0.1:8080/v1/chat/completions")
LLM_MODELO = os.environ.get("NEXUS_LLM_MODELO", "qwen-local")
PERMITIR_LLM_EXTERNO = os.environ.get("NEXUS_LLM_PERMITIR_EXTERNO") == "1"

# Escala da evolução: aumente em máquinas maiores. A busca é limitada por tempo (ORCAMENTO).
TRABALHADORES = int(os.environ.get("NEXUS_TRABALHADORES", str(max(1, (os.cpu_count() or 2) - 1))))
POPULACAO = int(os.environ.get("NEXUS_POPULACAO", "16"))        # candidatos por geração
GERACOES = int(os.environ.get("NEXUS_GERACOES", "6"))           # gerações por ciclo
ORCAMENTO = int(os.environ.get("NEXUS_ORCAMENTO", "90"))        # segundos máximos de busca por ciclo
MAX_LENTO_MS = 1500                                             # classificador mais lento que isso é recusado
