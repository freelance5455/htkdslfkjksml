"""NEXUS — IA local que se auto-analisa e reescreve o próprio cérebro em segundo plano."""
