"""GUARDIÃO — roda a auto-análise e a evolução em segundo plano, com interruptor de segurança."""
import importlib
import shutil
import threading
import time

from . import config, evoluir, memoria

_estado = {"proximo": 0.0, "ultimo": None, "rodando": False}
_parar = threading.Event()
INTENCOES = ("salvar", "buscar", "calcular", "hora", "conversa")


def pausado():
    return (config.DATA / "PARAR").exists()


def pausar(sim):
    config.DATA.mkdir(parents=True, exist_ok=True)
    flag = config.DATA / "PARAR"
    if sim:
        flag.write_text("pausado")
    else:
        flag.unlink(missing_ok=True)


def recarregar():
    shutil.rmtree(config.NUCLEO / "__pycache__", ignore_errors=True)
    importlib.invalidate_caches()
    from .nucleo import aprendido, cerebro
    importlib.reload(aprendido)
    importlib.reload(cerebro)


def classificar(frase):
    try:
        from .nucleo import cerebro
        r = cerebro.classificar(frase)
        return r if r in INTENCOES else "conversa"
    except Exception:
        return "conversa"


def _executar(motivo):
    if _estado["rodando"]:
        return
    _estado["rodando"] = True
    try:
        _estado["ultimo"] = {"ts": time.time(), **evoluir.ciclo(recarregar, motivo)}
    except Exception as e:  # o motor nunca morre por erro de um ciclo
        memoria.log_evolucao("ciclo", "erro", detalhe=f"{type(e).__name__}: {e}")
        _estado["ultimo"] = {"ts": time.time(), "resultado": "erro", "detalhe": type(e).__name__}
    finally:
        _estado["rodando"] = False
        _estado["proximo"] = time.time() + config.INTERVALO


def _loop():
    _estado["proximo"] = time.time() + config.PRIMEIRO_CICLO
    while not _parar.wait(2):
        if not pausado() and time.time() >= _estado["proximo"]:
            _executar("agendado")
        elif pausado():
            _estado["proximo"] = time.time() + config.PRIMEIRO_CICLO


def iniciar():
    memoria.iniciar()
    evoluir.garantir_versao_inicial()
    threading.Thread(target=_loop, name="nexus-motor", daemon=True).start()


def antecipar(segundos=15):
    """Chamado quando chega feedback novo: aprende logo, sem esperar o intervalo inteiro."""
    if not _estado["rodando"]:
        _estado["proximo"] = min(_estado["proximo"] or 1e18, time.time() + segundos)


def disparar():
    if _estado["rodando"] or pausado():
        return False
    threading.Thread(target=_executar, args=("manual",), daemon=True).start()
    return True


def estado():
    ultima_analise = memoria.consultar("SELECT * FROM evolucoes WHERE tipo='autoanalise' ORDER BY id DESC LIMIT 1")
    nota = memoria.consultar("SELECT fitness_depois FROM evolucoes WHERE tipo IN ('autoanalise','promocao') "
                             "AND resultado='ok' AND fitness_depois IS NOT NULL ORDER BY id DESC LIMIT 1")
    return {"pausado": pausado(), "rodando": _estado["rodando"], "versao": evoluir.versao_atual(),
            "proximo_ciclo": None if pausado() else _estado["proximo"], "ultimo_ciclo": _estado["ultimo"],
            "aptidao": nota[0]["fitness_depois"] if nota else None,
            "detalhe_analise": ultima_analise[0]["detalhe"] if ultima_analise else None,
            "intervalo": config.INTERVALO}
