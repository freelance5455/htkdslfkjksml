"""CÉREBRO — a própria IA pode reescrever este arquivo e o aprendido.py.

Contrato obrigatório: classificar(frase) -> uma das INTENCOES.
Só é permitido importar: re, math, unicodedata, collections, functools, itertools, string, difflib, statistics.
"""
import re
import unicodedata

from . import aprendido

INTENCOES = ("salvar", "buscar", "calcular", "hora", "conversa")


def normalizar(texto):
    t = unicodedata.normalize("NFKD", str(texto).lower())
    return "".join(c for c in t if not unicodedata.combining(c))


def atributos(texto):
    palavras = re.findall(r"[a-z0-9]+", normalizar(texto))
    return palavras + [a + " " + b for a, b in zip(palavras, palavras[1:])]


def classificar(frase):
    if re.search(r"\d\s*[-+*/x^]\s*\d", normalizar(frase)):
        return "calcular"
    atrs = atributos(frase)
    melhor, melhor_pontos = "conversa", aprendido.LIMIAR
    for intencao in INTENCOES:
        pesos = aprendido.PESOS.get(intencao, {})
        pontos = sum(pesos.get(a, 0.0) for a in atrs)
        if pontos > melhor_pontos:
            melhor, melhor_pontos = intencao, pontos
    return melhor
