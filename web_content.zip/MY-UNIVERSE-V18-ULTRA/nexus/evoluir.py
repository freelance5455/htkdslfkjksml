"""GUARDIÃO — o ciclo de evolução: auto-análise → população → sandbox → promoção ou descarte.

Escala com o hardware: a cada ciclo uma POPULAÇÃO de candidatos é avaliada em paralelo (um subprocesso
isolado por candidato), por várias GERAÇÕES (seleção + mutação + cruzamento), até o ORÇAMENTO de tempo.
Quanto mais ela estagna, maior a população e a força da mutação.

A IA só altera os arquivos de config.EDITAVEIS dentro de nucleo/. Quem decide se vale a pena
(este arquivo, avaliador, config, memoria, llm, motor) fica fora do alcance dela.
"""
import ast
import json
import math
import os
import random
import re
import shutil
import tempfile
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import avaliador, config, llm, memoria

_CICLO = threading.Lock()


# ---------- versões (snapshots para reverter) ----------
def _pasta_versao(n):
    return config.DATA / "versoes" / f"v{n:04d}"


def versao_atual():
    return int(memoria.kv_get("versao", "0"))


def _snapshot():
    existentes = [int(p.name[1:]) for p in (config.DATA / "versoes").glob("v*")] if (config.DATA / "versoes").is_dir() else []
    n = max(existentes + [versao_atual()]) + 1
    destino = _pasta_versao(n)
    destino.mkdir(parents=True, exist_ok=True)
    for nome in config.EDITAVEIS:
        shutil.copy2(config.NUCLEO / nome, destino / nome)
    memoria.kv_set("versao", n)
    for p in sorted((config.DATA / "versoes").glob("v*"))[:-config.MANTER_VERSOES]:
        shutil.rmtree(p, ignore_errors=True)
    return n


def garantir_versao_inicial():
    if versao_atual() == 0:
        _snapshot()


def listar_versoes():
    return [p.name for p in sorted((config.DATA / "versoes").glob("v*"))]


def _escrever_atomico(destino, texto):
    fd, tmp = tempfile.mkstemp(dir=destino.parent, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(texto)
    os.replace(tmp, destino)


def _aplicar_arquivos(arquivos, recarregar):
    for nome, texto in arquivos.items():
        if nome not in config.EDITAVEIS:
            raise ValueError(f"arquivo não editável: {nome}")
        _escrever_atomico(config.NUCLEO / nome, texto)
    shutil.rmtree(config.NUCLEO / "__pycache__", ignore_errors=True)
    recarregar()


def restaurar(versao, recarregar):
    pasta = _pasta_versao(versao)
    if not pasta.is_dir():
        raise ValueError("versão inexistente")
    _aplicar_arquivos({n: (pasta / n).read_text(encoding="utf-8") for n in config.EDITAVEIS}, recarregar)
    memoria.kv_set("versao", versao)
    memoria.log_evolucao("reversao", "ok", versao, detalhe=f"restaurada v{versao}")


# ---------- genoma = conteúdo de aprendido.py ----------
def _texto_aprendido(g):
    corpo = "PESOS = {\n" + "".join(f"    {i!r}: {d!r},\n" for i, d in sorted(g["pesos"].items())) + "}\n"
    cab = f'"""Pesos aprendidos automaticamente pelo NEXUS ({time.strftime("%Y-%m-%d %H:%M")}). Não edite à mão."""\n'
    return cab + corpo + f"LIMIAR = {round(g['limiar'], 3)!r}\n"


def _genoma_de_texto(texto):
    try:
        nomes = {}
        for no in ast.parse(texto).body:
            if isinstance(no, ast.Assign) and isinstance(no.targets[0], ast.Name):
                nomes[no.targets[0].id] = ast.literal_eval(no.value)
        return {"pesos": {i: dict(d) for i, d in nomes["PESOS"].items()}, "limiar": float(nomes.get("LIMIAR", 0.0))}
    except Exception:
        return {"pesos": {}, "limiar": 0.0}


def _atributos(frase, bigramas=True):
    t = unicodedata.normalize("NFKD", frase.lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    p = re.findall(r"[a-z0-9]+", t)
    return p + ([a + " " + b for a, b in zip(p, p[1:])] if bigramas else [])


def _aprendiz(casos_treino, bigramas=True, topo=30):
    """Semente determinística: associa cada atributo à intenção em que mais aparece."""
    intencoes = sorted({c["intencao"] for c in casos_treino})
    k = max(1, len(intencoes))
    cont = {}
    for c in casos_treino:
        for a in set(_atributos(c["frase"], bigramas)):
            cont.setdefault(a, {}).setdefault(c["intencao"], 0)
            cont[a][c["intencao"]] += 1
    pesos = {i: {} for i in intencoes}
    for a, por in cont.items():
        total = sum(por.values())
        for i in intencoes:
            p = (por.get(i, 0) + 0.5) / (total + 0.5 * k)
            if p > 1 / k + 0.15:
                pesos[i][a] = round((p - 1 / k) * math.log(1 + total), 3)
    pesos = {i: dict(sorted(d.items(), key=lambda kv: -kv[1])[:topo]) for i, d in pesos.items()}
    return {"pesos": pesos, "limiar": 0.0}


def _mutar(g, rng, casos_treino, forca):
    novo = {"pesos": {i: dict(d) for i, d in g["pesos"].items()}, "limiar": g["limiar"]}
    for d in novo["pesos"].values():
        for a in list(d):
            r = rng.random()
            if r < forca * 0.15:
                del d[a]
            elif r < forca:
                d[a] = round(min(40.0, max(0.01, d[a] * rng.uniform(1 - forca, 1 + forca))), 3)
    for _ in range(rng.randint(1, 1 + int(forca * 10))):          # descobre atributos novos nos casos de treino
        if not casos_treino:
            break
        c = rng.choice(casos_treino)
        atrs = _atributos(c["frase"])
        if atrs:
            novo["pesos"].setdefault(c["intencao"], {})[rng.choice(atrs)] = round(rng.uniform(0.2, 1.5), 3)
    if rng.random() < 0.5:
        novo["limiar"] = round(min(20.0, max(0.0, novo["limiar"] + rng.uniform(-0.4, 0.4) * (1 + forca))), 3)
    return novo


def _cruzar(a, b, rng):
    filho = {"pesos": {}, "limiar": rng.choice((a["limiar"], b["limiar"]))}
    for i in set(a["pesos"]) | set(b["pesos"]):
        da, db = a["pesos"].get(i, {}), b["pesos"].get(i, {})
        d = {}
        for k in set(da) | set(db):
            if k in da and k in db:
                d[k] = rng.choice((da[k], db[k]))
            elif rng.random() < 0.7:
                d[k] = da.get(k, db.get(k))
        filho["pesos"][i] = d
    return filho


# ---------- avaliação paralela ----------
def _candidato(arquivos_novos):
    tmp = tempfile.TemporaryDirectory()
    pasta = Path(tmp.name) / "nucleo"
    shutil.copytree(config.NUCLEO, pasta, ignore=shutil.ignore_patterns("__pycache__"))
    for nome, texto in arquivos_novos.items():
        (pasta / nome).write_text(texto, encoding="utf-8")
    return tmp, pasta


def _avaliar_arquivos(arquivos, cs):
    """-> (res, erros). Valida estaticamente e depois roda no sandbox."""
    erros = [e for arq, txt in arquivos.items() for e in avaliador.validar_codigo(arq, txt)]
    if erros:
        return None, erros
    tmp, pasta = _candidato(arquivos)
    try:
        return avaliador.avaliar(pasta, cs), []
    finally:
        tmp.cleanup()


def _avaliar_lote(genomas, cs, prazo):
    def um(g):
        if time.time() > prazo:
            return g, None
        return g, _avaliar_arquivos({"aprendido.py": _texto_aprendido(g)}, cs)[0]
    with ThreadPoolExecutor(max_workers=config.TRABALHADORES) as ex:
        return [(g, r) for g, r in ex.map(um, genomas) if r is not None and "erro" not in r]


def _passa(res, atual, base):
    """Promoção exige ganho de aptidão E nenhuma regressão no holdout nem na confirmação."""
    return (avaliador.aptidao(res) > base + config.MARGEM
            and avaliador.acuracia(res, "holdout") >= avaliador.acuracia(atual, "holdout")
            and avaliador.acuracia(res, "confirmacao") >= avaliador.acuracia(atual, "confirmacao"))


def _promocoes_hoje():
    return memoria.consultar("SELECT COUNT(*) n FROM evolucoes WHERE tipo='promocao' AND resultado='ok' AND ts>?",
                             (time.time() - 86400,))[0]["n"]


# ---------- ciclo ----------
def ciclo(recarregar, motivo="agendado"):
    """Uma rodada completa. Só uma por vez; seguro para chamar de qualquer thread."""
    if not _CICLO.acquire(blocking=False):
        return {"resultado": "ocupado"}
    try:
        t0 = time.time()
        cs = avaliador.casos()
        atual = avaliador.avaliar(config.NUCLEO, cs)
        base, v = avaliador.aptidao(atual), versao_atual()
        memoria.log_evolucao(
            "autoanalise", "erro" if "erro" in atual else "ok", v, base, base,
            "erro: " + atual["erro"] if "erro" in atual else
            f"treino {avaliador.acuracia(atual, 'train')} · holdout {avaliador.acuracia(atual, 'holdout')} · "
            f"confirmação {avaliador.acuracia(atual, 'confirmacao')} · {len(cs['train'])} casos de treino ({motivo})")
        if "erro" in atual:
            return {"resultado": "erro", "detalhe": atual["erro"]}

        estag = int(memoria.kv_get("estagnacao", "0"))
        pop = min(config.POPULACAO * (1 + estag // 3), config.POPULACAO * 4)
        forca = min(0.15 + 0.05 * estag, 0.6)
        seed = random.randrange(1 << 30)
        rng = random.Random(seed)
        prazo = t0 + config.ORCAMENTO

        genoma_atual = _genoma_de_texto((config.NUCLEO / "aprendido.py").read_text(encoding="utf-8"))
        sementes = [genoma_atual] + [_aprendiz(cs["train"], b, t) for b in (False, True) for t in (15, 30)]
        populacao = list(sementes)
        while len(populacao) < pop:
            populacao.append(_mutar(rng.choice(sementes), rng, cs["train"], forca))
        melhor, avaliados, geracoes = None, 0, 0
        for _ in range(config.GERACOES):
            if time.time() > prazo:
                break
            geracoes += 1
            vistos, lote = set(), []
            for ind in populacao:
                chave = json.dumps(ind, sort_keys=True)
                if chave not in vistos:
                    vistos.add(chave)
                    lote.append(ind)
            resultados = _avaliar_lote(lote, cs, prazo)
            avaliados += len(resultados)
            resultados.sort(key=lambda gr: -avaliador.aptidao(gr[1]))
            for ind, res in resultados:                  # melhor indivíduo que passa nas travas
                if _passa(res, atual, base):
                    if melhor is None or avaliador.aptidao(res) > melhor[1]:
                        melhor = ("população (aprendiz + mutação + cruzamento)", avaliador.aptidao(res),
                                  {"aprendido.py": _texto_aprendido(ind)})
                    break
            if not resultados or avaliador.aptidao(resultados[0][1]) >= 0.999:
                break
            elite = [ind for ind, _ in resultados[:max(2, pop // 4)]]
            populacao = list(elite)
            while len(populacao) < pop:
                if rng.random() < 0.35 and len(elite) > 1:
                    populacao.append(_cruzar(*rng.sample(elite, 2), rng))
                else:
                    populacao.append(_mutar(rng.choice(elite), rng, cs["train"], forca))
        memoria.log_evolucao("busca", "ok", v, base, melhor[1] if melhor else base,
                             f"{avaliados} candidatos em {geracoes} gerações · população {pop} · {config.TRABALHADORES} "
                             f"trabalhadores · {time.time() - t0:.1f}s · estagnação {estag} · semente {seed}")

        if atual["falhas"] and llm.disponivel():       # candidato de código: o modelo local reescreve cerebro.py
            try:
                codigo = llm.reescrever_cerebro((config.NUCLEO / "cerebro.py").read_text(encoding="utf-8"), atual["falhas"])
                if codigo:
                    res, erros = _avaliar_arquivos({"cerebro.py": codigo}, cs)
                    if erros:
                        memoria.log_evolucao("proposta", "rejeitada", v, base, None, "modelo local: " + "; ".join(erros[:3]))
                    else:
                        apt, ok = avaliador.aptidao(res), "erro" not in res and _passa(res, atual, base)
                        memoria.log_evolucao("proposta", "aceitavel" if ok else "descartada", v, base, apt,
                                             "modelo local: " + (res.get("erro") or f"holdout {avaliador.acuracia(res, 'holdout')}"))
                        if ok and (melhor is None or apt > melhor[1]):
                            melhor = ("modelo local reescreve cerebro.py", apt, {"cerebro.py": codigo})
            except Exception as e:
                memoria.log_evolucao("proposta", "falha", v, detalhe=f"modelo local: {type(e).__name__}")

        if melhor is None:
            memoria.kv_set("estagnacao", estag + 1)
            return {"resultado": "sem_melhora", "aptidao": base}
        if _promocoes_hoje() >= config.MAX_PROMOCOES_DIA:
            memoria.log_evolucao("promocao", "limite_diario", v, base, melhor[1])
            return {"resultado": "limite_diario"}

        nome, apt, arquivos = melhor
        _aplicar_arquivos(arquivos, recarregar)                  # promove...
        depois = avaliador.avaliar(config.NUCLEO, cs)            # ...e confere o código REAL em produção
        if "erro" in depois or avaliador.aptidao(depois) + 1e-9 < apt:
            restaurar(v, recarregar)                             # auto-reversão
            memoria.log_evolucao("promocao", "revertida", v, base, avaliador.aptidao(depois), nome)
            return {"resultado": "revertida"}
        novo = _snapshot()
        memoria.kv_set("estagnacao", 0)
        memoria.log_evolucao("promocao", "ok", novo, base, apt, nome)
        return {"resultado": "promovida", "versao": novo, "aptidao": apt, "origem": nome}
    finally:
        _CICLO.release()
