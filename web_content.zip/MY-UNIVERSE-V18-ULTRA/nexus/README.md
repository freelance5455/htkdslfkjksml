# NEXUS — documentação de referência

## Documento Mestre recuperado — V9

Foram recuperadas as especificações originais das etapas 01 a 05 de 50 em `docs/`. Elas definem identidade, perfil/contexto, memória, Biblioteca Universal e motor de raciocínio. As etapas 06 a 50 não foram reconstruídas por suposição e permanecem pendentes de recuperação. A documentação descreve objetivos; não comprova que todas as capacidades estejam implementadas.

Os módulos Python atuais do NEXUS permanecem preservados. Consulte também `../nexus.html` para a interface existente.
