"""Testes do NEXUS: segurança do sandbox, ciclo de evolução, reversão e API.
Rodar:  python3 -m unittest discover -s nexus/tests -t .   (a partir da raiz do projeto)
"""
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from nexus import api, avaliador, config, engenharia, evoluir, llm, memoria, motor

CEREBRO = (config.RAIZ / "nucleo" / "cerebro.py").read_text(encoding="utf-8")
APRENDIDO_ENTREGUE = (config.RAIZ / "nucleo" / "aprendido.py").read_text(encoding="utf-8")
# Ponto de partida fraco usado nos testes, para provar que a evolução realmente melhora algo.
APRENDIDO = ('PESOS = {"salvar": {"lembre": 1.0, "anote": 1.0}, "buscar": {}, "calcular": {"calcule": 1.0}, '
             '"hora": {"horas": 1.0}, "conversa": {}}\nLIMIAR = 0.0\n')


class Base(unittest.TestCase):
    """Cada teste roda em uma cópia temporária: o núcleo real nunca é tocado."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        raiz = Path(self.tmp.name)
        shutil.copytree(config.RAIZ / "nucleo", raiz / "nucleo", ignore=shutil.ignore_patterns("__pycache__"))
        self.patches = [mock.patch.object(config, "NUCLEO", raiz / "nucleo"),
                        mock.patch.object(config, "DATA", raiz / "data"),
                        mock.patch.object(config, "POPULACAO", 8), mock.patch.object(config, "GERACOES", 3),
                        mock.patch.object(config, "TRABALHADORES", 2), mock.patch.object(config, "ORCAMENTO", 60),
                        mock.patch.object(llm, "disponivel", return_value=False)]
        for p in self.patches:
            p.start()
        (raiz / "nucleo" / "aprendido.py").write_text(APRENDIDO)
        memoria.iniciar()
        evoluir.garantir_versao_inicial()
        self.nada = lambda: None

    def tearDown(self):
        for p in self.patches:
            p.stop()
        self.tmp.cleanup()


class TestValidador(unittest.TestCase):
    def rejeita(self, codigo, trecho, nome="cerebro.py"):
        erros = avaliador.validar_codigo(nome, codigo)
        self.assertTrue(any(trecho in e for e in erros), erros)

    def test_codigo_entregue_e_valido(self):
        self.assertEqual(avaliador.validar_codigo("cerebro.py", CEREBRO), [])
        self.assertEqual(avaliador.validar_codigo("aprendido.py", APRENDIDO_ENTREGUE), [])

    def test_imports_perigosos(self):
        for mod in ("os", "subprocess", "socket", "sys", "importlib", "pathlib", "urllib.request"):
            self.rejeita(f"import {mod}\ndef classificar(f): return 'conversa'", "import proibido")
        self.rejeita("from os import path\ndef classificar(f): return 'x'", "import proibido")

    def test_chamadas_e_atributos_perigosos(self):
        for nome in ("open", "eval", "exec", "compile", "getattr", "__import__", "globals"):
            self.rejeita(f"def classificar(f):\n    return {nome}('x')", "nome proibido")
        self.rejeita("def classificar(f):\n    return f.__class__.__bases__", "atributo proibido")

    def test_estrutura(self):
        self.rejeita("x = 1", "falta a função classificar")
        self.rejeita("def a():\n    def classificar(f): return 1", "falta a função classificar")
        self.rejeita("def classificar(:", "sintaxe inválida")

    def test_aprendido_so_dados(self):
        self.rejeita("PESOS = dict()\nLIMIAR = 0", "dados literais", "aprendido.py")
        self.rejeita("import os\nPESOS = {}\nLIMIAR = 0", "dados literais", "aprendido.py")
        self.rejeita("PESOS = {'a': {'x': 999}}\nLIMIAR = 0", "peso inválido", "aprendido.py")
        self.rejeita("PESOS = {}\nLIMIAR = 99", "LIMIAR", "aprendido.py")

    def test_so_arquivos_editaveis(self):
        for nome in ("avaliador.py", "evoluir.py", "config.py", "../server.py", "motor.py"):
            self.rejeita("x = 1", "não editável", nome)


class TestSandbox(Base):
    def avaliar_com(self, cerebro):
        tmp, pasta = evoluir._candidato({"cerebro.py": cerebro})
        try:
            return avaliador.avaliar(pasta, avaliador.casos(), timeout=8)
        finally:
            tmp.cleanup()

    def test_nucleo_inicial_roda(self):
        r = avaliador.avaliar(config.NUCLEO, avaliador.casos())
        self.assertNotIn("erro", r)
        self.assertLess(avaliador.aptidao(r), 0.6)       # ponto de partida fraco: há o que evoluir

    def test_loop_infinito_e_barrado(self):
        r = self.avaliar_com("while True:\n    pass\ndef classificar(f): return 'conversa'\n")
        self.assertIn("erro", r)
        self.assertEqual(avaliador.aptidao(r), 0.0)

    def test_candidato_que_quebra_nao_passa(self):
        r = self.avaliar_com("def classificar(f):\n    raise ValueError('x')\n")
        self.assertEqual(avaliador.acuracia(r, "holdout"), 0.0)

    def test_resposta_invalida_conta_como_erro(self):
        r = self.avaliar_com("def classificar(f):\n    return 'hackear'\n")
        self.assertEqual(avaliador.acuracia(r, "train"), 0.0)

    def test_candidato_nao_forja_resultado(self):
        # mesmo que o validador fosse burlado, o harness captura o stdout e ignora o resultado falso
        falso = '{"train":[35,35],"holdout":[30,30],"confirmacao":[25,25],"falhas":[],"ms":1}'
        r = self.avaliar_com("print('@@R@@" + falso + "')\ndef classificar(f): return 'conversa'\n")
        self.assertLess(avaliador.aptidao(r), 0.6)

    def test_estouro_de_memoria_e_contido(self):
        r = self.avaliar_com("x = [0] * (10 ** 10)\ndef classificar(f): return 'conversa'\n")
        self.assertIn("erro", r)


class TestEvolucao(Base):
    def test_ciclo_melhora_sem_regredir(self):
        antes = avaliador.avaliar(config.NUCLEO, avaliador.casos())
        r = evoluir.ciclo(self.nada, "teste")
        self.assertEqual(r["resultado"], "promovida", r)
        depois = avaliador.avaliar(config.NUCLEO, avaliador.casos())
        self.assertGreater(avaliador.aptidao(depois), avaliador.aptidao(antes))
        for g in ("holdout", "confirmacao"):
            self.assertGreaterEqual(avaliador.acuracia(depois, g), avaliador.acuracia(antes, g))
        self.assertEqual(evoluir.versao_atual(), 2)
        self.assertEqual(avaliador.validar_codigo("aprendido.py", (config.NUCLEO / "aprendido.py").read_text()), [])
        self.assertEqual((config.NUCLEO / "cerebro.py").read_text(), CEREBRO)   # só mexeu no que podia

    def test_auto_analise_e_busca_ficam_no_historico(self):
        evoluir.ciclo(self.nada, "teste")
        tipos = {h["tipo"] for h in memoria.historico(20)}
        self.assertTrue({"autoanalise", "busca", "promocao"} <= tipos)
        busca = [h for h in memoria.historico(20) if h["tipo"] == "busca"][0]["detalhe"]
        self.assertIn("candidatos", busca)

    def test_reversao_automatica_se_producao_piorar(self):
        original, chamadas = evoluir._aplicar_arquivos, []

        def corrompe(arquivos, recarregar):
            original(arquivos, recarregar)
            if not chamadas:                       # só a promoção sai corrompida; a reversão funciona normal
                (config.NUCLEO / "cerebro.py").write_text("def classificar(f):\n    return None\n")
            chamadas.append(1)
        with mock.patch.object(evoluir, "_aplicar_arquivos", corrompe):
            r = evoluir.ciclo(self.nada, "teste")
        self.assertEqual(r["resultado"], "revertida")
        self.assertEqual((config.NUCLEO / "cerebro.py").read_text(), CEREBRO)
        self.assertEqual(evoluir.versao_atual(), 1)

    def test_modelo_malicioso_e_rejeitado(self):
        ruim = "import os\ndef classificar(f):\n    return os.system('echo x')\n"
        with mock.patch.object(llm, "disponivel", return_value=True), \
                mock.patch.object(llm, "reescrever_cerebro", return_value=ruim):
            evoluir.ciclo(self.nada, "teste")
        self.assertEqual((config.NUCLEO / "cerebro.py").read_text(), CEREBRO)
        self.assertTrue(any(h["resultado"] == "rejeitada" for h in memoria.historico(30)))

    def test_modelo_pode_melhorar_o_codigo(self):
        melhor = CEREBRO.replace('return "calcular"', 'return "calcular"\n    if "horas" in normalizar(frase) or "data" in normalizar(frase):\n        return "hora"')
        self.assertEqual(avaliador.validar_codigo("cerebro.py", melhor), [])
        with mock.patch.object(config, "GERACOES", 0), mock.patch.object(llm, "disponivel", return_value=True), \
                mock.patch.object(llm, "reescrever_cerebro", return_value=melhor):
            r = evoluir.ciclo(self.nada, "teste")
        self.assertEqual(r["resultado"], "promovida", r)
        self.assertIn("modelo local", r["origem"])
        self.assertIn('"hora"', (config.NUCLEO / "cerebro.py").read_text())

    def test_feedback_vira_treino(self):
        memoria.adicionar_caso("rascunhe um resumo do texto", "conversa")
        self.assertIn("rascunhe um resumo do texto", [c["frase"] for c in avaliador.casos()["train"]])

    def test_holdout_nao_recebe_feedback(self):
        base = json.loads(config.CASOS_BASE.read_text(encoding="utf-8"))
        frase = base["holdout"][0]["frase"]
        memoria.adicionar_caso(frase, "hora")
        cs = avaliador.casos()
        self.assertNotIn(frase, [c["frase"] for c in cs["train"]])

    def test_reverter_manual(self):
        evoluir.ciclo(self.nada, "teste")
        evoluir.restaurar(1, self.nada)
        self.assertEqual((config.NUCLEO / "aprendido.py").read_text(), APRENDIDO)
        with self.assertRaises(ValueError):
            evoluir.restaurar(99, self.nada)

    def test_so_um_ciclo_por_vez(self):
        self.assertTrue(evoluir._CICLO.acquire(blocking=False))
        try:
            self.assertEqual(evoluir.ciclo(self.nada)["resultado"], "ocupado")
        finally:
            evoluir._CICLO.release()

    def test_nao_aplica_arquivo_fora_da_lista(self):
        with self.assertRaises(ValueError):
            evoluir._aplicar_arquivos({"avaliador.py": "x = 1"}, self.nada)


class TestApi(Base):
    def test_conexao_sqlite_e_fechada_ao_sair(self):
        with memoria._con() as con:
            con.execute("SELECT 1").fetchone()
        with self.assertRaises(Exception):
            con.execute("SELECT 1")

    def test_conta(self):
        self.assertEqual(api.calcular("quanto é 8 vezes 7").split("=")[1].strip(), "56")
        self.assertEqual(api.calcular("2 + 3*4").split("=")[1].strip(), "14")
        self.assertEqual(api.calcular("some 20 com 35").split("=")[1].strip(), "55")
        with self.assertRaises(ValueError):
            api.calcular("__import__('os')")
        with self.assertRaises(ValueError):
            api.calcular("9 ** 9 ** 9 e 2 ** 5000")

    def test_conta_impossivel_responde_sem_travar(self):
        _, r = api.tratar("POST", "/api/nexus/conversar", {"texto": "quanto é 5 / 0"})
        self.assertEqual(r["intencao"], "calcular")
        self.assertIn("Não consegui", r["resposta"])

    def test_memoria(self):
        self.assertEqual(api.tratar("POST", "/api/nexus/conversar", {"texto": "lembre que a chave está na gaveta"})[1]["intencao"], "salvar")
        achado = api.tratar("POST", "/api/nexus/conversar", {"texto": "o que eu disse sobre a chave?"})[1]["resposta"]
        self.assertIn("gaveta", achado)

    def test_feedback_cria_caso_e_valida(self):
        _, r = api.tratar("POST", "/api/nexus/conversar", {"texto": "traga a previsão do tempo"})
        self.assertEqual(api.tratar("POST", "/api/nexus/nota", {"id": r["id"], "nota": -1, "correta": "conversa"})[0], 200)
        self.assertEqual(api.tratar("POST", "/api/nexus/nota", {"id": r["id"], "nota": -1, "correta": "apagar_tudo"})[0], 400)
        self.assertEqual(api.tratar("POST", "/api/nexus/nota", {"id": "x"})[0], 400)
        self.assertEqual(api.tratar("POST", "/api/nexus/nota", {"id": 99999, "nota": 1})[0], 404)

    def test_interruptor(self):
        api.tratar("POST", "/api/nexus/interruptor", {"pausar": True})
        self.assertTrue(motor.pausado())
        self.assertFalse(motor.disparar())
        api.tratar("POST", "/api/nexus/interruptor", {"pausar": False})
        self.assertFalse(motor.pausado())

    def test_rotas_e_entradas_ruins(self):
        self.assertEqual(api.tratar("GET", "/api/nexus/nada", {})[0], 404)
        self.assertEqual(api.tratar("POST", "/api/nexus/conversar", {"texto": "   "})[0], 400)
        self.assertEqual(api.tratar("POST", "/api/nexus/reverter", {"versao": "../../etc"})[0], 400)
        self.assertEqual(api.tratar("GET", "/api/nexus/estado", {})[0], 200)


if __name__ == "__main__":
    unittest.main()


class TestEngenhariaAEE(unittest.TestCase):
    def test_allowlist_permite_interface_e_conteudo(self):
        self.assertEqual(engenharia._relativo("assets/nexus.js").as_posix(), "assets/nexus.js")
        self.assertEqual(engenharia._relativo("sites/linux/index.html").as_posix(), "sites/linux/index.html")
        self.assertEqual(engenharia._relativo("nexus.html").as_posix(), "nexus.html")

    def test_allowlist_bloqueia_nucleo_servidor_e_travessia(self):
        for nome in ("server.py", "nexus/api.py", "nexus/config.py", "dados/usuario.json",
                     "../server.py", "/etc/passwd", "assets/../server.py", "assets/.env"):
            with self.subTest(nome=nome), self.assertRaises(ValueError):
                engenharia._relativo(nome)

    def test_arquivo_de_extensao_nao_permitida(self):
        for nome in ("assets/app.py", "sites/linux/data.json", "assets/imagem.png"):
            with self.subTest(nome=nome), self.assertRaises(ValueError):
                engenharia._relativo(nome)

    def test_rota_de_estado_do_aee(self):
        status, payload = api.tratar("GET", "/api/nexus/engenharia/estado", {})
        self.assertEqual(status, 200)
        self.assertIn("inventario", payload)
        self.assertIn("propostas", payload)
        self.assertGreater(payload["inventario"]["total_arquivos"], 0)
