"""GUARDIÃO — cliente do modelo local (llama.cpp). Por padrão só fala com a própria máquina/rede."""
import ipaddress
import json
import re
import urllib.request
from urllib.parse import urlsplit

from . import config


def _url_permitida(url):
    host = urlsplit(url).hostname or ""
    if config.PERMITIR_LLM_EXTERNO or host == "localhost":
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_loopback or ip.is_private
    except ValueError:
        return False


def disponivel():
    if not _url_permitida(config.LLM_URL):
        return False
    p = urlsplit(config.LLM_URL)
    try:
        with urllib.request.urlopen(f"{p.scheme}://{p.netloc}/health", timeout=1.5) as r:
            return r.status == 200
    except Exception:
        return False


def chat(mensagens, max_tokens=400, timeout=90):
    if not _url_permitida(config.LLM_URL):
        raise RuntimeError("Endereço do modelo não é local (veja NEXUS_LLM_PERMITIR_EXTERNO).")
    corpo = json.dumps({"model": config.LLM_MODELO, "messages": mensagens, "max_tokens": max_tokens,
                        "temperature": 0.3}).encode()
    req = urllib.request.Request(config.LLM_URL, corpo, {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read(2_000_000))["choices"][0]["message"]["content"]


def reescrever_cerebro(codigo_atual, falhas):
    """Pede ao modelo uma versão melhorada de cerebro.py. Devolve o código ou None."""
    lista = "\n".join(f'- "{f["frase"]}" deveria ser {f["esperado"]} (veio {f["obtido"]})' for f in falhas[:15])
    resposta = chat([
        {"role": "system", "content": "Você melhora um classificador de intenções em Python. Responda APENAS com o "
         "arquivo cerebro.py completo dentro de um bloco ```python. Mantenha classificar(frase), INTENCOES e "
         "'from . import aprendido'. Só importe re, math, unicodedata, collections, functools, itertools, string, "
         "difflib, statistics. Não use open, eval, exec nem atributos com __."},
        {"role": "user", "content": f"Código atual:\n```python\n{codigo_atual}\n```\nErros atuais:\n{lista}\n"
                                    "Devolva o cerebro.py melhorado."}], max_tokens=1500, timeout=config_timeout())
    m = re.search(r"```(?:python)?\n(.*?)```", resposta, re.S)
    return m.group(1) if m else None


def config_timeout():
    import os
    return min(int(os.environ.get("NEXUS_LLM_TIMEOUT", "300")), 600)
