"""GUARDIÃO — ações do NEXUS (conversar, memória, feedback) e rotas /api/nexus/*."""
import ast
import json
import operator
import re
import time

from . import config, engenharia, evoluir, llm, memoria, motor

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Mod: operator.mod, ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos}
_PALAVRAS_OP = [("elevado a", "**"), ("dividido por", "/"), ("dividido", "/"), ("vezes", "*"),
                ("multiplicado por", "*"), ("menos", "-"), ("mais", "+"), ("mod", "%")]
_DIAS = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo"]


def _avaliar_aritmetica(no):
    if isinstance(no, ast.Expression):
        return _avaliar_aritmetica(no.body)
    if isinstance(no, ast.Constant) and isinstance(no.value, (int, float)):
        return no.value
    if isinstance(no, ast.BinOp) and type(no.op) in _OPS:
        a, b = _avaliar_aritmetica(no.left), _avaliar_aritmetica(no.right)
        if isinstance(no.op, ast.Pow) and abs(b) > 100:
            raise ValueError("expoente grande demais")
        return _OPS[type(no.op)](a, b)
    if isinstance(no, ast.UnaryOp) and type(no.op) in _OPS:
        return _OPS[type(no.op)](_avaliar_aritmetica(no.operand))
    raise ValueError("expressão inválida")


def calcular(texto):
    t = texto.lower().replace(",", ".")
    for palavra, op in _PALAVRAS_OP:
        t = t.replace(palavra, f" {op} ")
    t = re.sub(r"(?<=\d)\s*x\s*(?=\d)", "*", t).replace("^", "**")
    nums = re.findall(r"\d+(?:\.\d+)?", t)
    if re.search(r"\d\s*(\*\*|[-+*/%])\s*\(?-?\d", t):
        expr = "".join(re.findall(r"[\d.+\-*/%() ]+", t)).strip()
    elif re.search(r"\bsom[ae]|\bsoma\b", t) and len(nums) >= 2:
        expr = f"{nums[0]} + {nums[1]}"
    else:
        raise ValueError("sem expressão")
    try:
        valor = _avaliar_aritmetica(ast.parse(expr, mode="eval"))
        return f"{' '.join(expr.split())} = {round(valor, 6):g}"
    except (SyntaxError, ZeroDivisionError, OverflowError, RecursionError, MemoryError, TypeError) as e:
        raise ValueError("conta inválida") from e


def responder(texto):
    intencao = motor.classificar(texto)
    try:
        if intencao == "salvar":
            conteudo = re.sub(r"^(?:\s*(?:por favor|me|lembre|lembra|anote|anota|guarde|guarda|salve|salva|registre|"
                              r"memorize|grave|tome nota|não esqueça|nao esqueça|de que|que|aí|ai|isso|na memória)\b[\s:,]*)+",
                              "", texto, flags=re.I).strip() or texto
            memoria.guardar_memoria(conteudo)
            resposta = f"Guardei: “{conteudo}”."
        elif intencao == "buscar":
            achados = memoria.buscar_memorias(texto)
            resposta = ("Encontrei:\n" + "\n".join(f"• {a}" for a in achados)) if achados else "Não encontrei nada guardado sobre isso."
        elif intencao == "calcular":
            resposta = calcular(texto)
        elif intencao == "hora":
            agora = time.localtime()
            resposta = f"{_DIAS[agora.tm_wday]}, {time.strftime('%d/%m/%Y, %H:%M', agora)}."
        else:
            resposta = conversar(texto)
    except ValueError:
        if intencao == "calcular":
            resposta = "Não consegui resolver essa conta. Confira os números e a operação."
        else:
            intencao, resposta = "conversa", conversar(texto)
    return intencao, resposta


def conversar(texto):
    if not llm.disponivel():
        return ("Entendi, mas o modelo de conversa local está desligado. Inicie o llama-server (veja o README) "
                "para eu conversar livremente. Memória, cálculos e horas já funcionam sem ele.")
    memorias = memoria.buscar_memorias(texto)
    sistema = "Você é o NEXUS, assistente local e privado. Responda em português, de forma curta e honesta."
    if memorias:
        sistema += " Notas do usuário: " + " | ".join(memorias)
    try:
        return llm.chat([{"role": "system", "content": sistema}, {"role": "user", "content": texto}], max_tokens=300).strip()
    except Exception:
        return "O modelo local não respondeu agora. Tente de novo em instantes."


def tratar(metodo, caminho, corpo):
    """Roteia /api/nexus/*. Devolve (status, json)."""
    rota = caminho[len("/api/nexus/"):].strip("/")
    if metodo == "GET":
        if rota == "estado":
            return 200, {**motor.estado(), "llm_online": llm.disponivel(), "versoes": evoluir.listar_versoes()[-8:]}
        if rota == "historico":
            return 200, {"itens": memoria.historico(30)}
        if rota == "codigo":
            return 200, {"cerebro": (config.NUCLEO / "cerebro.py").read_text(encoding="utf-8"),
                         "aprendido": (config.NUCLEO / "aprendido.py").read_text(encoding="utf-8")}
        if rota == "engenharia/estado":
            return 200, {"inventario": engenharia.analisar(), "propostas": engenharia.listar(),
                         "llm_online": llm.disponivel()}
        return 404, {"error": "Rota inexistente."}
    if rota == "engenharia/analisar":
        return 200, engenharia.analisar()
    if rota == "engenharia/propor":
        try:
            return 200, {"proposta": engenharia.propor(corpo.get("objetivo", ""))}
        except (ValueError, RuntimeError) as e:
            return 400, {"error": str(e)}
        except Exception as e:
            print(f"[AEE] erro ao gerar proposta: {type(e).__name__}: {e}")
            return 502, {"error": "Não foi possível gerar uma proposta. Consulte o estado do modelo local."}
    if rota == "engenharia/aplicar":
        try:
            return 200, {"proposta": engenharia.aplicar(corpo.get("id", ""))}
        except (ValueError, OSError, KeyError) as e:
            return 400, {"error": str(e)}
    if rota == "conversar":
        texto = str(corpo.get("texto", "")).strip()[:2000]
        if not texto:
            return 400, {"error": "Mensagem vazia."}
        intencao, resposta = responder(texto)
        return 200, {"id": memoria.registrar_mensagem(texto, intencao, resposta), "intencao": intencao, "resposta": resposta}
    if rota == "nota":
        try:
            msg_id, nota = int(corpo.get("id", 0)), int(corpo.get("nota", 0))
        except (TypeError, ValueError):
            return 400, {"error": "Requisição inválida."}
        m = memoria.consultar("SELECT texto,intencao FROM mensagens WHERE id=?", (msg_id,))
        if not m:
            return 404, {"error": "Mensagem não encontrada."}
        correta = m[0]["intencao"] if nota > 0 else str(corpo.get("correta", ""))
        if correta not in motor.INTENCOES:
            return 400, {"error": "Informe a intenção correta."}
        memoria.adicionar_caso(m[0]["texto"], correta)
        motor.antecipar()
        return 200, {"ok": True, "aprendido": correta}
    if rota == "evoluir":
        return 200, {"iniciado": motor.disparar()}
    if rota == "interruptor":
        motor.pausar(bool(corpo.get("pausar")))
        return 200, {"pausado": motor.pausado()}
    if rota == "reverter":
        try:
            evoluir.restaurar(int(corpo.get("versao", 0)), motor.recarregar)
        except (TypeError, ValueError, OSError):
            return 400, {"error": "Versão inválida."}
        return 200, {"versao": evoluir.versao_atual()}
    return 404, {"error": "Rota inexistente."}
