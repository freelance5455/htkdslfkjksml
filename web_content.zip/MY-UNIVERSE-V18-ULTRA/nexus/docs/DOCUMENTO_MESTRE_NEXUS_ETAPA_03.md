# NEXUS

## DOCUMENTO MESTRE — ETAPA 03/50

### ARQUITETURA AVANÇADA DE MEMÓRIA, ARMAZENAMENTO E RECUPERAÇÃO DE CONHECIMENTO

**Versão:** 1.0  
**Dependência:** Etapas 01/50 e 02/50.

---

## 1. MISSÃO

Construir um sistema de memória persistente capaz de armazenar, organizar, relacionar, pesquisar, atualizar e recuperar grandes volumes de informações.

A memória será uma das estruturas fundamentais do NEXUS.

O sistema não deverá depender exclusivamente do histórico recente de conversas ou da janela de contexto do modelo de inteligência artificial.

Deverá possuir armazenamento próprio, independente do modelo utilizado.

A substituição do modelo de IA não poderá provocar a perda da memória, dos documentos, dos projetos ou do conhecimento acumulado.

## 2. ARQUITETURA GERAL

A memória deverá ser organizada em camadas especializadas.

```text
MEMORY SYSTEM
├── 1. SHORT-TERM MEMORY
│   └── Contexto temporário
├── 2. CONVERSATIONAL MEMORY
│   └── Histórico de interações
├── 3. EPISODIC MEMORY
│   └── Eventos e experiências
├── 4. SEMANTIC MEMORY
│   └── Fatos e conceitos
├── 5. PROCEDURAL MEMORY
│   └── Processos e métodos
├── 6. PROJECT MEMORY
│   └── Projetos e decisões
├── 7. USER MEMORY
│   └── Preferências e objetivos
├── 8. DOCUMENT MEMORY
│   └── Arquivos e documentos
├── 9. RELATIONAL MEMORY
│   └── Relações entre informações
└── 10. ARCHIVE MEMORY
    └── Histórico preservado
```

Cada camada deverá possuir uma finalidade específica, mas todas deverão poder trabalhar em conjunto.

## 3. MEMÓRIA DE CURTO PRAZO

A memória de curto prazo deverá preservar o contexto necessário para a execução da tarefa atual.

Exemplo:

O usuário está configurando um serviço Linux.

O sistema deverá acompanhar:

- objetivo atual;
- comandos executados;
- resultados;
- erros;
- arquivos envolvidos;
- hipóteses;
- próximo passo.

Essa memória poderá ser temporária, mas deverá permitir que uma sessão seja retomada quando necessário.

O sistema deverá controlar o tamanho do contexto para evitar consumo excessivo de memória e tokens.

## 4. MEMÓRIA CONVERSACIONAL

O NEXUS deverá armazenar conversas de maneira organizada.

Cada conversa deverá conter:

- identificador;
- data;
- assunto;
- participantes ou origem;
- mensagens;
- projeto relacionado;
- anexos relacionados;
- resumo;
- palavras-chave;
- referências a decisões;
- estado da conversa.

O sistema deverá permitir pesquisar conversas por:

- palavra;
- assunto;
- data;
- projeto;
- tecnologia;
- pessoa ou organização;
- problema;
- decisão;
- arquivo relacionado.

O histórico original deverá ser preservado quando importado, mesmo que o sistema também crie resumos e registros derivados.

## 5. MEMÓRIA EPISÓDICA

A memória episódica deverá registrar acontecimentos e experiências.

Exemplos:

- Um servidor apresentou erro.
- Uma configuração foi alterada.
- Um ramal foi registrado.
- Um teste foi executado.
- Um projeto mudou de direção.
- Uma decisão foi tomada.
- Uma tentativa falhou.
- Uma solução foi encontrada.

Cada evento deverá registrar:

1. O que aconteceu.
2. Quando aconteceu.
3. Em qual projeto.
4. Qual era o objetivo.
5. Quais ações foram realizadas.
6. Qual foi o resultado.
7. Quais evidências existem.
8. O que deve acontecer depois.

O sistema deverá diferenciar acontecimentos confirmados de interpretações.

## 6. MEMÓRIA SEMÂNTICA

A memória semântica deverá armazenar conhecimento organizado.

Exemplo:

**Conceito:** DNS.  
**Área:** Redes de computadores.  
**Definição:** sistema de nomes de domínio que permite associar nomes a informações de rede, especialmente endereços IP.

**Pré-requisitos:**

- redes;
- endereçamento IP;
- conceitos de cliente e servidor.

**Relações:**

- TCP/IP;
- UDP;
- DNS recursivo;
- DNS autoritativo;
- registros A, AAAA, MX e CNAME.

**Aplicações:**

- navegação;
- resolução de nomes;
- infraestrutura de serviços;
- administração de redes.

O registro poderá conter explicações em diferentes níveis, exemplos, exercícios, fontes e histórico de atualização.

## 7. MEMÓRIA PROCEDIMENTAL

A memória procedimental deverá preservar métodos e sequências de execução.

Exemplos:

- Como investigar falhas de DNS.
- Como configurar um ramal PJSIP.
- Como verificar um serviço Linux.
- Como realizar backup com rsync.
- Como testar uma API.
- Como analisar logs com journalctl.

Cada procedimento deverá conter:

- objetivo;
- pré-requisitos;
- ferramentas;
- passos;
- comandos;
- resultados esperados;
- erros conhecidos;
- riscos;
- critérios de conclusão;
- data de validação.

Um procedimento antigo não deverá ser executado automaticamente sem verificar se continua adequado ao ambiente atual.

## 8. MEMÓRIA DE PROJETOS

Cada projeto deverá possuir uma memória independente e estruturada.

Exemplo:

**Projeto:** Operação VoIP na Linha.

Registros:

- arquitetura;
- equipamentos;
- servidores;
- endereços;
- configurações;
- ramais;
- serviços;
- testes;
- problemas;
- soluções;
- decisões;
- próximos passos.

Outro exemplo:

**Projeto:** AUREON.

Registros:

- visão;
- objetivos;
- princípios;
- decisões estratégicas;
- modelos de negócio;
- recursos;
- competências;
- riscos;
- planejamento.

Projetos diferentes poderão compartilhar conhecimentos, mas seus registros não deverão ser misturados.

## 9. MEMÓRIA DOCUMENTAL

O NEXUS deverá conseguir trabalhar com documentos fornecidos pelo usuário.

Formatos desejados:

- TXT;
- MD;
- PDF;
- DOCX;
- XLSX;
- CSV;
- PPTX;
- JSON;
- arquivos de código;
- outros formatos que possam ser suportados por ferramentas instaladas.

O processo de ingestão deverá:

1. Identificar o arquivo.
2. Verificar o formato.
3. Extrair o conteúdo.
4. Preservar o documento original.
5. Identificar páginas ou seções.
6. Dividir o conteúdo em partes recuperáveis.
7. Identificar conceitos.
8. Extrair metadados.
9. Detectar duplicatas.
10. Indexar o conteúdo.
11. Manter referência ao documento original.

Em PDFs com imagens, tabelas ou páginas digitalizadas, o sistema deverá prever OCR ou processamento visual quando necessário.

## 10. MEMÓRIA RELACIONAL

Uma das capacidades mais importantes será relacionar informações.

O NEXUS não deverá apenas encontrar documentos que contenham a mesma palavra.

Deverá identificar relações conceituais.

Exemplo:

Linux → processos → memória → serviços → monitoramento → troubleshooting.

Outro exemplo:

Programação → algoritmos → lógica → estruturas de dados → arquitetura de software → inteligência artificial.

Cada relação deverá poder registrar:

- conceito de origem;
- conceito relacionado;
- tipo de relação;
- justificativa;
- fonte;
- grau de confiança.

Tipos de relação possíveis:

- depende de;
- é parte de;
- é exemplo de;
- é semelhante a;
- contradiz;
- complementa;
- utiliza;
- produz;
- substitui;
- está relacionado a.

## 11. MEMÓRIA DE ARQUIVAMENTO

Registros antigos não deverão desaparecer automaticamente.

O sistema deverá permitir arquivamento e versionamento.

Exemplo:

Uma configuração de servidor foi substituída.

O NEXUS deverá preservar:

- configuração anterior;
- configuração nova;
- data da mudança;
- motivo;
- responsável;
- resultado do teste.

A memória atual deverá destacar a configuração vigente, mas manter o histórico disponível.

## 12. ESTRUTURA DE DADOS

A implementação deverá utilizar estruturas persistentes e documentadas.

Uma possibilidade inicial é SQLite, especialmente por ser leve e adequado ao hardware atual.

Tabelas conceituais sugeridas:

- users;
- conversations;
- messages;
- memories;
- memory_sources;
- projects;
- project_events;
- knowledge_items;
- knowledge_relations;
- documents;
- document_chunks;
- procedures;
- decisions;
- tags;
- embeddings;
- audit_logs.

Essas tabelas são uma proposta. O Codex deverá inspecionar a estrutura existente e decidir como evoluí-la sem duplicar ou destruir dados.

Cada registro deverá possuir identificador único.

## 13. INDEXAÇÃO E PESQUISA

A memória deverá oferecer mecanismos de recuperação progressivamente mais avançados.

**Primeira camada:**

- pesquisa textual;
- filtros;
- palavras-chave;
- categorias;
- datas;
- identificadores.

**Segunda camada:**

- indexação de texto;
- busca por relevância;
- recuperação de trechos;
- pesquisa em documentos.

**Terceira camada:**

- embeddings;
- busca semântica;
- similaridade conceitual;
- recuperação híbrida.

A implementação deverá considerar recursos de processamento e memória.

Não instalar bancos vetoriais pesados sem demonstrar necessidade.

Uma opção inicial é SQLite com FTS5, caso esteja disponível no ambiente.

## 14. RECUPERAÇÃO INTELIGENTE DE MEMÓRIA

Quando o usuário fizer uma pergunta, o NEXUS deverá identificar quais memórias são relevantes.

Fluxo proposto:

```text
PERGUNTA
  ↓
IDENTIFICAR INTENÇÃO
  ↓
IDENTIFICAR PROJETO
  ↓
PESQUISAR MEMÓRIA
  ↓
RECUPERAR DOCUMENTOS
  ↓
LOCALIZAR REGISTROS RELACIONADOS
  ↓
CLASSIFICAR RELEVÂNCIA
  ↓
MONTAR CONTEXTO
  ↓
ENVIAR AO MODELO
  ↓
GERAR RESPOSTA
  ↓
VERIFICAR RESULTADO
```

O sistema deverá evitar inserir informações irrelevantes no contexto do modelo.

Deverá selecionar os registros mais úteis para cada tarefa.

## 15. SISTEMA DE CONFIANÇA E PROCEDÊNCIA

Cada memória deverá possuir:

- fonte;
- data;
- tipo;
- confiança;
- status;
- histórico de alterações.

Exemplo:

**Informação:** o servidor utiliza determinado endereço IP.  
**Origem:** configuração observada em determinada data.  
**Status:** histórico.  
**Confiança:** alta para aquela data.  
**Validade atual:** não confirmada.

O sistema não deverá utilizar um endereço antigo como configuração atual sem nova verificação.

## 16. DEDUPLICAÇÃO

O NEXUS deverá identificar registros repetidos ou equivalentes.

Deverá comparar:

- conteúdo;
- assunto;
- origem;
- data;
- identificadores;
- relações.

Quando encontrar duplicatas, poderá sugerir consolidação.

Não deverá apagar automaticamente registros com diferenças relevantes.

A consolidação deverá preservar as fontes originais e o histórico.

## 17. CAPACIDADE DE ESCALA

A arquitetura deverá permitir crescimento da memória sem exigir a substituição completa do sistema.

A meta conceitual é suportar grandes bibliotecas de documentos, conversas e conhecimentos.

Entretanto, a capacidade real deverá ser medida conforme:

- espaço em disco;
- RAM;
- CPU;
- tamanho dos documentos;
- velocidade de indexação;
- tempo de recuperação;
- tamanho do contexto do modelo.

Não estabelecer promessas de milhões de registros sem testes de desempenho.

## 18. BACKUP E RECUPERAÇÃO

A memória será considerada um ativo crítico.

O sistema deverá implementar:

- backup automático configurável;
- cópias versionadas;
- exportação;
- validação de integridade;
- restauração;
- logs de backup;
- proteção contra sobrescrita acidental.

Antes de qualquer migração, deverá ser criado um backup verificável.

A recuperação deverá ser testada periodicamente.

## 19. PRIVACIDADE E CONTROLE

A memória deverá possuir controles para:

- consultar registros;
- editar;
- corrigir;
- arquivar;
- excluir mediante autorização;
- exportar;
- importar;
- restringir acesso;
- separar projetos privados.

Senhas, tokens e chaves não deverão ser armazenados como memória comum.

Informações sensíveis deverão receber tratamento especial e não deverão ser utilizadas indiscriminadamente.

## 20. TESTES OBRIGATÓRIOS

O sistema deverá ser testado para verificar:

1. Persistência após reiniciar a aplicação.
2. Recuperação de registros antigos.
3. Pesquisa por palavras-chave.
4. Pesquisa por projeto.
5. Recuperação por data.
6. Relações entre conceitos.
7. Identificação de duplicatas.
8. Atualização de registros.
9. Preservação de versões antigas.
10. Exportação e importação.
11. Integridade do banco.
12. Restauração de backup.
13. Desempenho em hardware limitado.
14. Isolamento de projetos.
15. Controle de permissões.

## 21. RESULTADO ESPERADO

Ao concluir esta etapa, o NEXUS deverá possuir uma arquitetura de memória capaz de:

- lembrar informações importantes;
- recuperar experiências;
- armazenar conhecimento;
- preservar documentos;
- organizar projetos;
- relacionar conceitos;
- recuperar procedimentos;
- identificar a origem dos dados;
- acompanhar mudanças;
- evitar perda de informações.

A memória deverá ser independente do modelo de IA e permanecer disponível mesmo que o modelo seja substituído.

**FIM DA ETAPA 03/50.**
