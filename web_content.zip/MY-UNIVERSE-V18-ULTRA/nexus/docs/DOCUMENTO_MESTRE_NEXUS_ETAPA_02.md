# NEXUS

## DOCUMENTO MESTRE — ETAPA 02/50

### PERFIL DO USUÁRIO, MEMÓRIA PESSOAL, TRAJETÓRIA E CONTEXTO PERMANENTE

**Versão:** 1.0  
**Dependência:** Etapa 01/50  
**Objetivo:** Fazer com que o NEXUS consiga compreender o contexto do usuário, preservar sua trajetória e utilizar informações anteriores para melhorar a continuidade das interações.

---

## 1. OBJETIVO DESTA ETAPA

O NEXUS deverá possuir um sistema capaz de conhecer o contexto de trabalho, aprendizagem, projetos, preferências e objetivos do usuário.

Não deverá tratar cada conversa como se fosse a primeira.

Deverá conseguir recuperar informações relevantes de interações anteriores, reconhecer projetos em andamento, identificar decisões já tomadas e compreender a evolução do usuário.

O sistema deverá funcionar como uma memória organizada de longo prazo.

Essa memória não deverá ser apenas um conjunto de mensagens armazenadas. Deverá transformar informações importantes em registros estruturados e recuperáveis.

## 2. PERFIL DE COMUNICAÇÃO E APRENDIZAGEM

O sistema deverá considerar as seguintes preferências já identificadas:

### 2.1 Idioma

- Português brasileiro como idioma principal.
- Inglês utilizado nas atividades de aprendizagem e nos projetos internacionais.
- Possibilidade futura de trabalhar com alemão e outros idiomas.

### 2.2 Estilo de comunicação

O usuário prefere:

- Respostas diretas.
- Explicações claras.
- Conteúdo prático.
- Linguagem natural.
- Precisão técnica.
- Exemplos concretos.
- Explicações sem excesso de elogios.
- Ausência de conteúdo desnecessário.
- Profundidade quando solicitada.

Evitar respostas excessivamente genéricas ou superficiais.

Não confundir resposta curta com resposta incompleta.

### 2.3 Preferências pedagógicas

O NEXUS deverá adaptar a explicação ao nível de compreensão demonstrado.

Quando o usuário não compreender um assunto, deverá:

1. Identificar o ponto exato da dificuldade.
2. Voltar ao fundamento necessário.
3. Explicar com linguagem simples.
4. Apresentar um exemplo concreto.
5. Mostrar como o mecanismo funciona.
6. Relacionar o assunto com algo conhecido.
7. Aplicar um exercício.
8. Verificar se houve compreensão.
9. Avançar somente quando apropriado.

Não repetir a mesma explicação com palavras diferentes sem identificar a origem da dificuldade.

### 2.4 Organização do aprendizado

O usuário prefere organizar o conhecimento em árvores, categorias, sequências e relações.

O NEXUS deverá permitir:

- Trilhas de aprendizagem.
- Sequências de aulas.
- Níveis de conhecimento.
- Grupos de assuntos.
- Simulados.
- Exercícios.
- Revisões.
- Progresso.
- Histórico de erros.
- Identificação de lacunas.

Marcadores conhecidos:

- `ppp`: avançar para o próximo tópico.
- `mmm`: aprofundar o assunto.
- `⚓️🔱`: estilo de professor de Linux Essentials/LPIC, com atenção a fundamentos e detalhes de prova.
- `⚓️🐎`: decisões e definições de projetos.
- `🚆`: âncora de contexto.
- `$duvida=segundoplano`: marcador de progresso de dúvida.

O NEXUS deverá permitir que o usuário configure novos marcadores e comandos pessoais.

## 3. OBJETIVO PROFISSIONAL E TRAJETÓRIA EM TI

O usuário possui como objetivo desenvolver competência elevada em tecnologia da informação.

Áreas centrais:

- Programação.
- Linux.
- Suporte técnico.
- Administração de sistemas.
- Redes.
- Telecomunicações.
- VoIP.
- Segurança da informação.
- Inteligência artificial.
- Automação.
- Arquitetura de sistemas.

O NEXUS deverá entender que essas áreas fazem parte de uma trajetória integrada.

Não deverá organizar o aprendizado como disciplinas completamente isoladas.

Exemplo de relação:

Linux → processos → serviços → redes → TCP/IP → SIP → RTP → VoIP → monitoramento → diagnóstico.

Outro exemplo:

Lógica → algoritmos → programação → arquitetura de software → APIs → automação → agentes de IA.

O sistema deverá ajudar a transformar o conhecimento teórico em capacidade prática.

## 4. FORMAÇÃO ACADÊMICA

Contexto acadêmico informado:

- Curso: Análise e Desenvolvimento de Sistemas.
- Instituição: Estácio.
- Período informado: janeiro de 2025 a junho de 2027.

Disciplinas mencionadas como concluídas:

- Engenharia de Software.
- Sistema Operacional.
- Raphython.
- Engenharia de Usabilidade.

Atividade de extensão mencionada como pendente:

- Sistemas de Informação e Sociedade.

Essas informações são históricas e devem ser atualizadas quando o usuário fornecer novos dados.

O NEXUS deverá poder armazenar:

- Instituição.
- Curso.
- Período.
- Disciplinas.
- Notas.
- Atividades.
- Trabalhos.
- Projetos acadêmicos.
- Certificados.
- Pendências.
- Datas importantes.

Não deverá inventar notas, aprovações ou conclusões acadêmicas.

## 5. TRILHA PROFISSIONAL LINUX

Existe interesse específico em desenvolver competências compatíveis com funções internacionais de suporte Linux.

O NEXUS deverá acompanhar especialmente:

- Administração de servidores Linux.
- Diagnóstico de serviços.
- Leitura de logs.
- `journalctl`.
- `syslog`.
- Monitoramento de processos.
- `top`.
- `htop`.
- `free`.
- Automação Bash.
- TCP/IP.
- DNS.
- Firewall.
- Bridging.
- Switching.
- MTU.
- KVM.
- VirtualBox.
- Cloud computing.
- Troubleshooting.

Há interesse em funções internacionais, incluindo a referência à posição Canonical Associate Linux Support Engineer.

O NEXUS deverá auxiliar na construção de competências profissionais, laboratórios, portfólio e preparação para entrevistas.

Antes de orientar candidaturas ou certificações, deverá consultar os requisitos atuais das fontes oficiais.

## 6. LABORATÓRIO DE REDES E VOIP

O usuário desenvolve um laboratório de aprendizagem de telecomunicações.

Nome do projeto:

**🚆 Operação VoIP na Linha**

Sequência de aprendizagem:

Linux → SSH → Redes → VoIP → SIP → RTP → Softswitches → Monitoramento.

Contexto técnico histórico:

- Asterisk 22.5.2.
- PJSIP.
- Ramais 100, 101 e 102 funcionando em uma etapa anterior.
- Contexto anteriormente alterado para `from-internal`.
- Ocorrências de erros 401 e 404.
- Problemas anteriores envolvendo AOR.
- Utilização de Linphone, MyPBXPhone e SipPulse.
- Utilização de Termux e PuTTY.

O NEXUS deverá preservar:

- Configurações.
- Diagramas.
- Endereçamento.
- Ramais.
- Arquivos de configuração.
- Erros encontrados.
- Soluções.
- Testes.
- Histórico de alterações.

Endereços IP e configurações antigas deverão ser tratados como registros históricos até que sejam confirmados novamente.

## 7. ESTUDOS DE INGLÊS

Objetivo: evoluir do nível A1 até C1/C2.

Histórico informado:

- Estudos na Wizard durante 2024–2026.
- Nível A1 Básico anteriormente informado.
- Estudos posteriores de tópicos A2 e B1.

Conteúdos já trabalhados ou mencionados:

- Present Simple.
- Present Perfect.
- Can e Could.
- Should.
- Comparatives.
- Superlatives.
- Adverbs.
- Some e Any.
- Countable e Uncountable Nouns.
- Gerund e Infinitive.
- Object Pronouns.
- Present Perfect com For e Since.

O sistema deverá acompanhar:

- Vocabulário.
- Gramática.
- Compreensão auditiva.
- Leitura.
- Escrita.
- Conversação.
- Pronúncia.
- Revisões.
- Erros recorrentes.
- Evolução por nível.

O usuário prefere explicações simples, exemplos curtos, tradução e exercícios.

## 8. ESTUDOS DE FINANÇAS E B3

O usuário desenvolveu um plano estruturado de aprendizagem financeira.

Estrutura desejada:

- Quatro níveis.
- Dezesseis matérias.
- Aulas sequenciais.
- Exercícios.
- Provas.
- Casos reais da B3.

Objetivos:

- Compreender o mercado financeiro.
- Entender investimentos.
- Analisar ativos.
- Compreender instituições financeiras.
- Conversar com profissionais do mercado.
- Administrar o próprio dinheiro com maior conhecimento.

Nível 1 — matérias:

1. Fundamentos da economia.
2. Sistema financeiro.
3. Bolsa de valores.
4. Negociações.

Conteúdos mencionados:

- Dinheiro.
- Circulação do dinheiro.
- Economia.
- Empresas e governos.
- Inflação.
- Juros.
- Oferta e demanda.
- Dólar e câmbio.
- Sistema Financeiro Nacional.
- Banco Central.
- CVM.
- CMN.
- Bancos e corretoras.
- ANBIMA.

O NEXUS deverá preservar a sequência de estudos e diferenciar dados históricos de informações financeiras atuais.

## 9. PROJETOS E EMPREENDIMENTOS DO USUÁRIO

O NEXUS deverá possuir uma memória individualizada para cada projeto.

Projetos conhecidos:

### 9.1 AUREON

Visão de uma empresa global de tecnologia.

Princípio estratégico:

**UNITE RESOURCES. FOCUS EFFORTS. DELIVER RESULTS.**

Ideia central: reunir recursos, competências, ferramentas e capacidades e concentrá-los em objetivos prioritários para produzir resultados concretos.

### 9.2 XCapitalizador

Projeto futuro relacionado a tecnologia, automação e inteligência artificial.

Os detalhes deverão ser recuperados de documentos e conversas fornecidos pelo usuário, sem inventar características.

### 9.3 Bullgy Brez / Legacy

Projeto de marca de vestuário.

Informações históricas:

- Público masculino.
- Faixa aproximada de 25 a 30 anos.
- Orçamento inicial mencionado de R$ 1.000.
- Primeira ideia de dez camisetas pretas.
- Logo pequeno no peito.
- Estratégia inicial de divulgação.

Slogan:

**BUILD SOMETHING THAT OUTLIVES YOU.**

### 9.4 Projeto Nexus LED

Conceito de painel visual de parede com estética de terminal tecnológico.

Ideias anteriores:

- Matriz LED.
- Fitas verticais.
- Raspberry Pi.
- Controle por Linux e SSH.
- Exibição de informações de mercado.
- Mensagens e indicadores.

As dimensões e configurações anteriores são rascunhos, não especificações definitivas.

### 9.5 Simulação Velho do Musk

Simulação de gestão de projetos na qual o usuário assume a posição de CEO e coordena especialistas.

Pontos de interesse:

- Contratação por especialidade.
- Desenvolvimento por etapas.
- Pagamento por marcos.
- Controle de qualidade.
- Proteção da ideia.
- Propriedade intelectual.
- Responsabilidades contratuais.
- Gestão de riscos.

O NEXUS deverá diferenciar simulações, planos e operações reais.

## 10. PROJETO LACUNAS

O sistema Lacunas deverá ser uma ferramenta transversal de aprendizagem.

Sua missão é identificar conhecimentos ausentes ou frágeis mesmo quando o usuário já concluiu determinado curso, nível ou disciplina.

O sistema deverá:

1. Mapear a área de conhecimento.
2. Decompor os assuntos em competências.
3. Identificar pré-requisitos.
4. Aplicar testes diagnósticos.
5. Identificar conhecimentos frágeis.
6. Classificar lacunas.
7. Priorizar o que precisa ser estudado.
8. Criar um plano de aprendizagem.
9. Aplicar exercícios.
10. Verificar a evolução.
11. Registrar evidências de domínio.

O projeto deverá funcionar em TI, inglês, finanças e qualquer outra área.

## 11. OBJETIVOS PESSOAIS DE LONGO PRAZO

Objetivos aspiracionais declarados:

- Dominar inglês em nível C2.
- Aprender alemão.
- Morar nos Estados Unidos.
- Viajar frequentemente de avião.
- Trabalhar com tecnologia da informação em um navio de cruzeiro.

O NEXUS poderá utilizar esses objetivos para organizar planos e acompanhar progresso, sem tratá-los como conquistas já realizadas.

## 12. MEMÓRIA DE CONTEXTO: COMO O NEXUS DEVERÁ FUNCIONAR

O sistema deverá possuir uma estrutura de memória que permita recuperar informações relevantes sem obrigar o usuário a repetir tudo.

Exemplo:

**Usuário:** \"Vamos continuar o laboratório VoIP.\"

O NEXUS deverá procurar:

- Estado conhecido do laboratório.
- Configurações anteriores.
- Ramais.
- Serviços.
- Últimos erros.
- Soluções já testadas.
- Próxima etapa planejada.

Outro exemplo:

**Usuário:** \"Continue meu inglês.\"

O NEXUS deverá recuperar:

- Nível.
- Grupo.
- Aula anterior.
- Conteúdos estudados.
- Dificuldades.
- Preferência de explicação.
- Próximo assunto.

Outro exemplo:

**Usuário:** \"Continue o NEXUS.\"

O sistema deverá recuperar:

- Arquitetura atual.
- Etapas do projeto.
- Arquivos existentes.
- Decisões anteriores.
- Funcionalidades implementadas.
- Problemas pendentes.

## 13. CLASSIFICAÇÃO E CONFIABILIDADE DAS MEMÓRIAS

Cada registro deverá receber uma classificação:

- **FATO CONFIRMADO:** informação explicitamente confirmada.
- **HISTÓRICO:** informação válida em determinado momento.
- **PREFERÊNCIA:** escolha ou padrão informado pelo usuário.
- **OBJETIVO:** resultado que o usuário pretende alcançar.
- **IDEIA:** possibilidade ainda não definida.
- **HIPÓTESE:** interpretação que precisa ser verificada.
- **PENDENTE:** informação que exige atualização.
- **OBSOLETO:** informação que deixou de representar a situação atual.

O sistema deverá armazenar a origem e a data de cada registro.

Não deverá transformar uma hipótese em fato apenas porque ela foi repetida várias vezes.

## 14. CONTROLE DO USUÁRIO SOBRE A MEMÓRIA

O usuário deverá conseguir:

- Consultar o que o NEXUS sabe.
- Corrigir informações.
- Atualizar registros.
- Remover registros.
- Exportar a memória.
- Importar novos conhecimentos.
- Consultar a origem de uma informação.
- Definir o que pode ou não ser utilizado.
- Separar informações pessoais de informações técnicas.
- Definir projetos privados.

Nenhuma memória deverá ser considerada absolutamente correta ou imutável.

## 15. DIRETRIZ DE IMPLEMENTAÇÃO

O Codex deverá transformar esta especificação em uma arquitetura real de memória.

A implementação deverá incluir:

- Banco de dados ou estrutura persistente apropriada.
- Identificação única de registros.
- Data de criação e atualização.
- Origem da informação.
- Classificação de confiabilidade.
- Relação entre registros.
- Pesquisa textual.
- Atualização segura.
- Exportação e importação.
- Backup.
- Testes de integridade.

Antes de implementar, inspecionar os dados existentes no NEXUS e preservar os registros já armazenados.

Não presumir que o sistema tenha acesso automático às conversas do ChatGPT. O histórico deverá ser importado por arquivos fornecidos pelo usuário ou por integrações autorizadas.

---

## RESULTADO ESPERADO

O NEXUS deverá compreender a trajetória do usuário como um conjunto conectado de estudos, objetivos e projetos.

Deverá preservar continuidade, reconhecer contexto e utilizar informações anteriores para tornar suas respostas e ações mais precisas.

A memória deverá servir ao desenvolvimento do usuário e dos projetos, e não apenas ao armazenamento passivo de mensagens.

**FIM DA ETAPA 02/50.**
