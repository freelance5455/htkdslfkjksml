# MY UNIVERSE V9 — auditoria de escopo e estado

## Base e preservação
- Base utilizada: `MY-universe-V8-Alpha-GFI-BOTAO.zip`.
- Os 156 arquivos regulares listados no ZIP-base estão presentes na árvore de trabalho; nenhum arquivo-base ausente foi identificado.
- SHA-256 do `dados/gfi.db` antes/depois da construção: idêntico (`4944daa49db2490b4872647700d98684f25e43175fe8fff7e8b47e184ac35b7f`).
- Fundo geral do portal `assets/fundo.webp` preservado.
- Fundo específico da GFI restaurado com `ui/assets/gfi-background.png`.

## Funcionalidades V9 implementadas
- Botão superior **Atualizar cotações**: consulta Yahoo Finance Chart para até 35 instrumentos ativos por execução, registra sucesso/falha e grava snapshots intradiários usando o conector existente. Estado `DELAYED`; nunca rotulado como tempo real.
- Botão superior **Buscar geral**: consulta notícias públicas, atualiza a fila de pesquisas de lacunas e devolve cobertura/erros. Não promete varrer toda a internet nem preencher automaticamente toda lacuna.
- Metadados no topo: data de referência histórica e data/hora/fonte da última coleta registrada na tabela de coletas.
- **07 — Notícias**: seção já existente na sétima posição do menu, agora ligada a RSS Google News; cache local, links, fonte, publicação e coleta.
- Cache inicial com quatro notícias recentes pesquisadas e referenciadas na construção da V9, para que a seção não abra vazia.
- **Minha Conta**: SQLite separado `dados/gfi_v9.db`; depósitos, retiradas, compras, vendas, validação de saldo/quantidade, caixa, posições, preço médio, P/L realizado e avaliação a mercado quando há cotação local.
- Logs de operações V9 em banco separado.
- Recuperadas as especificações do Documento Mestre NEXUS etapas 01–05/50 a partir do registro documental `ala.txt`; as etapas 06–50 não foram inventadas.

## Testes executados
- `compileall`: aprovado.
- `node --check ui/app.js`: aprovado.
- `bash -n` nos scripts de inicialização: aprovado.
- Suíte GFI original + testes V9: 128 testes aprovados.
- Testes NEXUS: execução excedeu o limite de tempo do ambiente; resultado inconclusivo, não declarado aprovado.
- Teste RSS em rede do ambiente de construção: DNS externo indisponível. A aplicação contém conector RSS para funcionar no computador do usuário quando houver internet; cache V9 foi preenchido com notícias pesquisadas externamente durante a construção.

## Limitações que permanecem
- A cotação intradiária depende de Yahoo Finance Chart, limite de provedor, conectividade e disponibilidade; o botão tenta 35 ativos por vez e pode retornar falhas parciais.
- Busca geral enfileira lacunas e coleta notícias; não executa automaticamente todos os 145 requisitos de ingestão nem substitui homologação B3/BCB/CVM.
- Notícias: o RSS foi implementado, mas não foi possível testar conexão direta a partir deste ambiente devido à falha de DNS.
- Carteira: cálculo de caixa, posição, custo médio, P/L realizado e P/L aberto quando existe cotação. Taxas, impostos, proventos, eventos corporativos, desdobramentos e reconciliação com extratos ainda não estão implementados/homologados.
- Patrimônio total é omitido quando alguma posição não possui cotação local verificável.
- GFI: o plano de 145 tarefas e as 16 etapas foram preservados; a conclusão real das fontes e de cada tarefa continua dependendo de evidências de coleta e homologação.
- NEXUS: documentação 01–05 recuperada; documentos 06–50 ainda não disponíveis nesta base. Teste completo excedeu o tempo.
- Os 13 ambientes e projetos da V8 foram preservados, mas a existência de suas páginas não equivale a homologação integral de cada projeto.
- Projeto NEXUS LED, Projeto Lacunas, cursos, carreira e projetos empresariais permanecem preservados como existentes na V8; suas funcionalidades não foram reimplementadas do zero nesta versão.

## Proteção e segurança
- Banco original GFI não foi alterado durante a construção.
- Dados V9 isolados em `dados/gfi_v9.db`.
- Sem alteração de tokens, credenciais ou arquivos pessoais existentes.
- Nenhuma ação de IA publica código ou modifica automaticamente arquivos protegidos.
