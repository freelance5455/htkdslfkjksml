# MY UNIVERSE V18 ULTRA

V18 ULTRA acrescenta um cliente Android nativo à instalação V17. O projeto desktop e os motores existentes permanecem na raiz, sem migração destrutiva de dados.

## Aplicativo Android

- Aplicativo próprio com identidade visual mobile, tela de acesso, dashboard, navegação inferior e tela de conexões.
- Dois perfis de conexão: Wi-Fi local e remoto HTTPS.
- Integração com autenticação atual (`POST /auth/login`), sessão (`GET /auth/session`), estado GFI (`GET /api/gfi/status`) e início da GFI (`POST /api/gfi/iniciar`, reservado para integração futura no app).
- NEXUS e catálogo de projetos abertos em WebView autenticada, preservando os motores e páginas atuais.
- GFI aberta pelo endereço com token devolvido pelo servidor; endereço remoto alternativo configurável.
- Não replica banco, NEXUS, GFI ou coleta de dados no telefone. O computador continua sendo o servidor de operação.

## Estrutura

- `android/`: projeto Android Gradle nativo (Java + Android Views; sem dependências externas de interface).
- `android/app/src/main/java/com/myuniverse/ultra/MainActivity.java`: fluxo de login, conexão, dashboard e navegação.
- `docs/ANDROID_V18_ULTRA.md`: construção, instalação e configuração de rede.

## Preservação de dados

O pacote-fonte não carrega credenciais, tokens nem bancos pessoais. Para migrar de uma instalação V17, execute `./MIGRAR_DADOS_V18.sh /caminho/da/instalacao-V17` antes do primeiro início. O script copia `dados/`, `nexus/data/`, dados da GFI e backups da GFI. Mantenha a V17 original como backup até validar a migração.

## Limites desta entrega

O projeto-fonte Android foi preparado, mas o ambiente de construção usado nesta revisão não contém Android SDK, Gradle ou ADB. Portanto, nenhum APK compilado é declarado nesta entrega. A compilação final requer Android Studio/Android SDK (API 35) e Gradle 8.11.1 ou compatível com Android Gradle Plugin 8.9.2.

A conexão remota depende de HTTPS e de publicação segura do portal e da GFI. O endereço `gfi.nexus.local` retornado pela V17 é um nome local; fora da rede Wi-Fi, configure o endereço remoto da GFI no app e o proxy/gateway para aceitar esse Host. Não exponha diretamente as portas do servidor à Internet.
