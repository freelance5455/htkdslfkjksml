# MY UNIVERSE V13 — NEXUS NETWORK

Base: MY-UNIVERSE-V12-HOTFIX-INICIALIZADOR.zip.

## Escopo implementado
- Gateway HTTP local baseado em hostname.
- `nexus.local` encaminha ao portal; `gfi.nexus.local` encaminha ao GFI.
- Configuração de nomes locais por Avahi em Linux Mint/Ubuntu.
- Script de migração dos dados V12 para a V13, sem sobrescrever arquivos existentes.
- Script de inicialização integrado e documentação de instalação, segurança e limitações.
- URLs devolvidas pela API do portal para o GFI passam a usar `gfi.nexus.local`.
- Serviços de aplicação continuam em loopback; gateway é a única entrada de rede.

## Preservação
A V13 foi construída sobre a V12 HOTFIX mais recente encontrada na Biblioteca. Não foram intencionalmente removidos módulos ou dependências. Tokens e chaves não são gerados nem incluídos no ZIP. Para manter credenciais/dados já existentes, executar `migrar_dados_v12.sh` apontando para a instalação anterior; o script preserva os diretórios `dados/` do portal e `sites/laboratorio-ti/inteligencia-financeira/dados/` do GFI.

## Limitações conhecidas
A resolução `.local` depende de mDNS e da rede/dispositivo. A porta 80 exige privilégio administrativo. O gateway não implementa WebSocket/HTTPS. Testes de rede real e compatibilidade de celular não podem ser concluídos no ambiente de empacotamento.
