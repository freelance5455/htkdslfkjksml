# V18 ULTRA — relatório de construção

## Entrega

- Base desktop V17 preservada no pacote, sem alterações nos motores do portal, NEXUS e GFI.
- Cliente Android nativo criado em `android/`, com identidade visual mobile própria.
- Login integrado ao contrato atual do portal e compartilhamento de cookie com WebView.
- Alternância Wi-Fi/remoto, endereço GFI alternativo, dashboard e dock inferior.
- Abertura de NEXUS e Projetos por rotas autenticadas; GFI por token e tentativa de inicialização pelo endpoint já existente.
- Script de migração para copiar credenciais, bancos, memória e backups da instalação V17.
- Dados privados, tokens e bancos locais não são distribuídos no ZIP-fonte.

## Verificações executadas

| Verificação | Resultado |
|---|---|
| Regressão da base portal/V16 | 133 testes aprovados |
| Regressão GFI V17 | 133 testes aprovados |
| XML do projeto Android | 4 arquivos XML válidos |
| Contratos de rota do app | presentes no código-fonte |
| Compilação Android | pendente: SDK/Gradle/ADB ausentes |
| Teste em emulador/dispositivo | pendente |
| Suíte integral independente do NEXUS | não declarada como aprovada nesta entrega |

Os testes Python emitiram `ResourceWarning` de conexão SQLite não fechada em um teste legado, mas as duas suítes concluíram com `OK`. Isso não foi tratado como falha de teste.

## Situação do APK

**Não há APK compilado nesta entrega.** O projeto Android-fonte está preparado, mas este ambiente não contém Android SDK, Gradle nem ADB. A compilação deve ser feita com Android Studio, JDK 17 e Android SDK Platform 35. Depois da compilação, o arquivo debug esperado é `android/app/build/outputs/apk/debug/app-debug.apk`.

## Observações de rede

O modo Wi-Fi depende do IP local do computador. O modo remoto exige HTTPS. A GFI V17 retorna por padrão `gfi.nexus.local`, que é um nome local; o acesso remoto exige publicação segura própria para a GFI, validação do Host no servidor/gateway e preenchimento do endereço GFI no app.
