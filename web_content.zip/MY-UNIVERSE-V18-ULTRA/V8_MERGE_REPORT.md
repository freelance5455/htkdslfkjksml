# Relatório de integração — MY UNIVERSE V8 Alpha

## Fontes efetivamente utilizadas

| Fonte | Arquivo | Tamanho | SHA-256 |
|---|---|---:|---|
| Base | `MY-universe-V7.zip` | 918.975 bytes | `e8b6e9d5dcc0ba0994ea9846d8b5991e75e7f2b67ad686fdab97023723133e2d` |
| Complemento | `MY-universe-V6.20-internal.zip` | 1.218.189 bytes | `c21cd422fe46321abd0c353237b990df4f63832de2e733b26757b25beb4601b0` |

Ambos os arquivos foram abertos e passaram na verificação de integridade ZIP antes da integração.

## Decisão de merge

A V7 foi escolhida como base porque já continha as melhorias operacionais de segurança, coleta, LIVE, agendamento e os contratos de dados atuais. A V6.20, por sua vez, trazia a consolidação mais recente do chat imediato e da descoberta de provedores da IA GFI, mas também carregava cópias anteriores de vários módulos da V7.

Para evitar regressões, não foi feita uma substituição integral da V7 pela V6.20. Foram portados o motor `gfi/ia_evolucao.py`, a rota de chat, a interface da Central IA, os testes correspondentes, o assistente opcional de ativação e a documentação de ativação. Os demais módulos operacionais permaneceram na versão V7.

## Arquivos centrais incorporados/adaptados

- `sites/laboratorio-ti/inteligencia-financeira/gfi/ia_evolucao.py`
- `sites/laboratorio-ti/inteligencia-financeira/gfi/api.py`
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.js`
- `sites/laboratorio-ti/inteligencia-financeira/testes/test_gfi_ai.py`
- `sites/laboratorio-ti/inteligencia-financeira/ativar_ia.sh`
- `sites/laboratorio-ti/inteligencia-financeira/IA_GFI_ATIVACAO.md`

## Resultados

- Chat API local e rota de encaminhamento cobertos por testes.
- Descoberta de provedor não declara conexão sem resposta válida do servidor.
- O modo sem LLM é identificado como diagnóstico local, sem simular geração de texto por IA.
- O script de ativação exige confirmação antes de instalar Ollama ou baixar pesos.
- A revisão humana e a separação entre laboratório e produção foram preservadas.

## Evidências e limites

Os números e comandos de teste estão em `TEST_REPORT.md` e `VERSAO_V8_ALPHA.md`. Testes unitários e validações sintáticas não provam que a máquina operacional tenha modelo LLM, Internet, credenciais, fontes B3/BCB/CVM ou provedor intradiário funcionando.
