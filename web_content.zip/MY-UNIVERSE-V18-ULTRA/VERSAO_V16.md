# MY UNIVERSE V16 — Integridade temporal e consolidação de candles

Base: MY UNIVERSE V15. Preserva NEXUS, portal, carteira, configurações e dados existentes.

## Objetivo

Corrigir a separação entre coleta intradiária e séries diárias utilizadas pelos indicadores da GFI, sem sobrescrever o histórico oficial B3.

## Implementações

- Nova tabela `cotacoes_provedor_diarias`, separada do COTAHIST e dos snapshots intradiários.
- Adaptador Yahoo Finance passa a preservar OHLCV quando solicitado com intervalo diário.
- Série consolidada da GFI combina COTAHIST e candles diários Yahoo; em datas coincidentes, o candle B3 oficial prevalece.
- O ciclo automático GFI coleta candles diários OHLC (`1d`, `1mo`) para análise. A carteira mantém seu coletor de snapshots intradiários independente.
- Referência temporal do pipeline passa a ser a data corrente; backtests continuam usando o corte `ate`. A última data antiga do banco não é mais tratada como data atual.
- Quando a série diária excede a janela de atualidade, indicadores técnicos, liquidez, volatilidade, risco e longo prazo ficam cinza e o índice geral é suspenso.
- Fonte efetiva dos candles passa a ser exibida no contexto da análise.

## Segurança e integridade

- Não mistura snapshots de 1 minuto com candles diários.
- Não substitui nem altera registros B3 existentes.
- Não classifica Yahoo como tempo real: permanece `DELAYED`, sem SLA.
- OHLC inválido é descartado antes da persistência.
- A migração do banco é aditiva: `CREATE TABLE IF NOT EXISTS`; dados anteriores permanecem intactos.

## Operação

1. Extrair V16 em diretório novo, sem apagar V15.
2. Se precisar trazer os dados da V15, executar `./migrar_dados_v16.sh /caminho/MY-UNIVERSE-V15`. O script faz backup dos dados que já existirem na pasta V16 antes de mesclar.
3. Executar `./testar_v16.sh` (133 testes automatizados aprovados neste build).
4. Iniciar a aplicação normalmente.
5. Confirmar a importação COTAHIST e ativar o ciclo automático GFI nas configurações.
6. Aguardar a coleta diária completar e conferir Saúde dos Serviços / proveniência dos candles.

## Limitações

- Yahoo Finance é fonte pública complementar, pode atrasar, limitar ou falhar; não é feed garantido.
- O ciclo de 60 segundos não significa que todos os ativos serão coletados em 60 segundos; a coleta é em rodízio e depende de latência/limites.
- COTAHIST permanece histórico diário oficial, não cotação intradiária.
- Fundamentos CVM, BCB, notícias e governança mantêm suas próprias periodicidades e dependências.
- Testes locais não substituem validação operacional com internet e fontes externas na máquina do usuário.
