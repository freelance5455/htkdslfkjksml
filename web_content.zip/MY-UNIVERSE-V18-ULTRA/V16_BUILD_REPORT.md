# MY UNIVERSE V16 — Relatório de construção

## Base

MY-UNIVERSE-V15-BACKUP.zip. Alterações aditivas e concentradas na camada de dados GFI.

## Correções principais

1. Candles diários Yahoo são preservados em tabela própria com OHLCV e proveniência.
2. `dados.candles()` consolida B3 + Yahoo por data, priorizando B3 em colisões.
3. Pipeline usa a data corrente como referência e deixa de inferir atualidade pela última data que por acaso existe no banco.
4. Séries antigas suspendem sinais de preço e o índice geral, evitando aparência de análise atual.
5. Ciclo automático GFI solicita candles diários adequados aos indicadores; snapshots intradiários da carteira continuam separados.

## Validação executada neste build

- `./testar_v16.sh`: aprovado.
- 133 testes automatizados aprovados (inclui regressões anteriores e testes V16).
- `compileall` Python: aprovado.
- `node --check` JavaScript: aprovado.
- `bash -n` nos scripts Shell: aprovado.
- Testes específicos V16: precedência B3 sobre Yahoo, complemento de datas, parser OHLCV, armazenamento diário separado e suspensão do índice quando a série está desatualizada.
- Nenhuma consulta externa em tempo real foi presumida; o adaptador Yahoo foi testado com respostas controladas.

Foi observado um `ResourceWarning` não fatal de conexão SQLite em teste legado; a suíte terminou com `OK`.
