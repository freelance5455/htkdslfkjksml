# MY UNIVERSE — V6.06

Base: V6.05. Esta versão adiciona à GFI o plano rastreável de finalização da coleta de dados (145 tarefas / 16 etapas), painel operacional, inventário de fontes, persistência de estados e exigência de evidência + validação para conclusão.

## Arquivos principais

- `sites/laboratorio-ti/inteligencia-financeira/gfi/plano_coleta.py`
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.js` e `ui/app.css`
- `sites/laboratorio-ti/inteligencia-financeira/gfi/api.py`
- `sites/laboratorio-ti/inteligencia-financeira/PLANO_COLETA_145.md`
- `sites/laboratorio-ti/inteligencia-financeira/INVENTARIO_FONTES.md`
- `sites/laboratorio-ti/inteligencia-financeira/VERSAO_V6_06.md`

## Verificações executadas nesta revisão

- 103 testes automatizados aprovados.
- `compileall` Python sem erros.
- `node --check ui/app.js` sem erros de sintaxe.
- Smoke test HTTP local: página da GFI HTTP 200; `GET /api/plano-coleta` HTTP 200.
- API retornou 145 tarefas, 16 etapas e 8 grupos de fontes.

## Limites

Não houve coleta externa nem homologação das fontes reais nesta revisão. A Tarefa 1 permanece em andamento. Nenhuma tarefa de coleta foi marcada como concluída.
