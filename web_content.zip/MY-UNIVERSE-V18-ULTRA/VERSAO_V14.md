# MY UNIVERSE V14 — Operação persistente NEXUS NETWORK

Base: `MY-UNIVERSE-V13-NEXUS-NETWORK.zip`.

## Objetivo

Eliminar a dependência de terminais manuais para manter o portal, o gateway e os nomes mDNS disponíveis na rede local, sem reescrever os módulos funcionais da V13.

## Implementações

- `nexus_v14_supervisor.py`: supervisor do portal e gateway; verifica portas antes de iniciar, não mata processos desconhecidos, aguarda o portal responder, monitora os dois processos e encerra os filhos de forma controlada.
- `nexus_mdns_supervisor.py`: mantém `nexus.local` e `gfi.nexus.local` publicados pelo Avahi; detecta alteração do IPv4 por DHCP e republica os nomes.
- `migrar_dados_v14.sh`: migra dados e credenciais da V13 com dados da V13 prevalecendo e backup pré-migração.
- `instalar_v14.sh`: instala unidades systemd usando a conta normal do proprietário, preserva backups de `/etc/avahi/hosts` e `/etc/hosts`, remove apenas aliases NEXUS legados e habilita os serviços sem iniciá-los durante a instalação.
- `nexus_v14.sh`: start, stop, restart, status, logs, enable e disable.
- `testar_v14.sh`: valida arquivos, sintaxe Python/Bash e presença dos dados-base.
- Unidades systemd: portal/gateway sob o usuário normal, com `CAP_NET_BIND_SERVICE` restrita para permitir a porta 80 sem executar a aplicação como root; mDNS em serviço separado.

## Operação

1. Extraia a V14 em uma pasta nova; não sobrescreva a instalação V13.
2. Migre os dados da instalação V13 em uso com `./migrar_dados_v14.sh /caminho/da/V13`; isso copia credenciais, token e dados locais mesclando os dados da V13 como fonte autoritativa e mantendo arquivos exclusivos da V14; o script cria backup dos dados que já existiam no destino. Preserve `dados/`, os bancos SQLite do GFI, o token local e as credenciais já existentes.
3. Se a conta do portal ainda não existir, execute `./iniciar.sh` uma vez para criá-la e encerre o servidor após a criação. Execute `./testar_v14.sh`.
4. Execute `sudo ./instalar_v14.sh` a partir da conta normal (o instalador usa `SUDO_USER`). Ele cria e habilita as unidades, mas não inicia serviços automaticamente naquele momento.
5. Feche os publicadores Avahi e o gateway V13 iniciados manualmente. Não mate processos de outros serviços.
6. Execute `sudo ./nexus_v14.sh start`.
7. Verifique `sudo ./nexus_v14.sh status` e teste `http://nexus.local/` e `http://gfi.nexus.local/` no computador e no celular conectado à mesma rede.

Após a instalação, os serviços são habilitados para iniciar automaticamente no boot. Use `sudo ./nexus_v14.sh stop` para encerrá-los e `sudo ./nexus_v14.sh logs` para acompanhar os registros.

## Portas e processos

- Gateway: `0.0.0.0:80`.
- Portal: `127.0.0.1:8765`.
- GFI: `127.0.0.1:8780`, iniciada sob demanda pelo portal conforme a lógica preexistente.
- O supervisor verifica as portas antes de iniciar. Se alguma estiver ocupada, falha com diagnóstico e não encerra o PID encontrado.
- O systemd acompanha o supervisor e todo o cgroup do serviço; no encerramento, também elimina processos descendentes pertencentes ao serviço.

## Preservação

A V14 deriva da V13 e mantém os módulos, interface, lógica financeira, banco de dados incluído no pacote, plano de coleta de 145 tarefas, scripts e documentação existentes. Nenhum coletor, regra financeira ou estrutura de banco foi intencionalmente alterado. Não inclui credenciais pessoais nem token de acesso gerado na instalação real.

## Limitações e requisitos

- Linux Mint/Ubuntu com systemd, Python 3, Avahi (`avahi-daemon` e `avahi-publish-address`) e `sudo`.
- Os dispositivos precisam estar na mesma rede e a rede Wi-Fi deve permitir multicast mDNS; redes com isolamento de clientes podem bloquear a descoberta.
- `.local` é resolvido via mDNS. O serviço republica os aliases quando o IPv4 muda, mas o roteador/firewall ainda precisa permitir UDP 5353 multicast.
- O gateway permanece HTTP, sem TLS e sem suporte a WebSocket. Não exponha a porta 80 diretamente à Internet.
- A GFI continua protegida pelo token existente; mantenha-o privado e rotacione-o caso tenha sido compartilhado.
- A instalação cria backups datados dos arquivos de resolução local antes de remover aliases NEXUS antigos. Não remove outras entradas desses arquivos.

## Validação de empacotamento

O relatório `V14_BUILD_REPORT.md` registra os testes executados durante a geração do pacote. Testes de boot, systemd, Avahi e Android precisam ser confirmados na máquina real após a instalação.
