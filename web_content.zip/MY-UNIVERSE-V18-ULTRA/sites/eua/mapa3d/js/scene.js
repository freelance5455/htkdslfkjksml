import * as THREE from "../../vendor/three.module.js";
import { OrbitControls } from "../../vendor/OrbitControls.js";

(() => {
"use strict";
const el=document.getElementById("viewport"), scene=new THREE.Scene();
scene.background=new THREE.Color(0x9bb0bb);scene.fog=new THREE.Fog(0x9bb0bb,9000,22000);
const camera=new THREE.PerspectiveCamera(42,el.clientWidth/el.clientHeight,1,50000);camera.position.set(-4700,3600,5200);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(el.clientWidth,el.clientHeight);renderer.domElement.setAttribute("role","img");renderer.domElement.setAttribute("aria-label","Modelo 3D do Aeroporto de Guarulhos. Arraste para orbitar; foque o modelo e use as setas para mover a câmera.");renderer.domElement.tabIndex=0;renderer.shadowMap.enabled=true;renderer.outputColorSpace=THREE.SRGBColorSpace;el.appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.listenToKeyEvents(renderer.domElement);controls.enableDamping=true;controls.target.set(0,0,0);controls.maxPolarAngle=Math.PI*.49;controls.minDistance=450;controls.maxDistance=14000;
scene.add(new THREE.HemisphereLight(0xdcecff,0x52604d,1.7));const sun=new THREE.DirectionalLight(0xffffff,2);sun.position.set(-3000,6000,2500);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);scene.add(sun);
const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.88});
const M={land:mat(0x718365),grass:mat(0x788b69),runway:mat(0x343a3d),taxi:mat(0x555c5e),concrete:mat(0x858b8d),white:mat(0xf1f0e8),yellow:mat(0xf2c94c),building:mat(0xabb5b8),roof:mat(0xcbd0cf),glass:mat(0x47758b),blue:mat(0x47728a),dark:mat(0x30383b),plane:mat(0xe7e9e8),red:mat(0x9d5a4b)};
const root=new THREE.Group();scene.add(root);const pick=[],labels=[];
function meshBox(name,x,y,z,sx,sy,sz,m){const o=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),m);o.position.set(x,y+sy/2,z);o.castShadow=true;o.receiveShadow=true;o.userData.name=name;root.add(o);pick.push(o);return o}
function line(pts,color=0xffffff){const g=new THREE.BufferGeometry().setFromPoints(pts.map(p=>new THREE.Vector3(...p)));root.add(new THREE.Line(g,new THREE.LineBasicMaterial({color})))}
function label(t,x,y,z){const c=document.createElement("canvas");c.width=512;c.height=96;const q=c.getContext("2d");q.fillStyle="rgba(9,23,32,.82)";q.fillRect(0,0,512,96);q.strokeStyle="#a4c1ce";q.strokeRect(2,2,508,92);q.fillStyle="#fff";q.font="bold 34px Arial";q.textAlign="center";q.fillText(t,256,62);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false}));s.position.set(x,y,z);s.scale.set(360,68,1);root.add(s);labels.push(s)}
function local(lat,lon){const lat0=-23.4356,lon0=-46.4730;return{x:(lon-lon0)*111320*Math.cos(lat0*Math.PI/180),z:-(lat-lat0)*111320}}
function runway(name,lat1,lon1,lat2,lon2,L){const a=local(lat1,lon1),b=local(lat2,lon2),x=(a.x+b.x)/2,z=(a.z+b.z)/2,ang=Math.atan2(b.x-a.x,-(b.z-a.z));const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=-ang;root.add(g);const r=new THREE.Mesh(new THREE.BoxGeometry(L,2,45),M.runway);r.position.y=1;r.userData.name=name;g.add(r);pick.push(r);for(const zz of [-20,20])line([[x-Math.cos(ang)*L/2,2,z-Math.sin(ang)*L/2+zz],[x+Math.cos(ang)*L/2,2,z+Math.sin(ang)*L/2+zz]],0xdfe2dc);for(let i=-L/2+100;i<L/2-80;i+=95){const s=new THREE.Mesh(new THREE.BoxGeometry(40,1,2),M.white);s.position.set(i,2,0);g.add(s)}label(name,x,85,z);return{x,z,ang,L}}
function taxi(name,pts,width=22){const sh=new THREE.Shape();sh.moveTo(-width/2,0);sh.lineTo(width/2,0);const g=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),M.taxi); // connected segments
 for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz),o=new THREE.Mesh(new THREE.BoxGeometry(len,1,width),M.taxi);o.position.set((a[0]+b[0])/2,.6,(a[1]+b[1])/2);o.rotation.y=-Math.atan2(dz,dx);o.userData.name=name;root.add(o);pick.push(o)}
 for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1];line([[a[0],1.3,a[1]],[b[0],1.3,b[1]]],0xf2c94c)}}
function terminal(name,x,z,L,W,angle=0){const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=angle;root.add(g);
 function b(n,xx,yy,zz,sx,sy,sz,m){const o=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),m);o.position.set(xx,yy+sy/2,zz);o.castShadow=true;o.receiveShadow=true;o.userData.name=name+" — "+n;g.add(o);pick.push(o);return o}
 b("corpo principal",0,0,0,L,18,W,M.building);b("cobertura",0,18,0,L+10,3,W+10,M.roof);b("fachada envidraçada",0,3,W/2+1,L-20,10,2,M.glass);
 // alas articuladas para fugir da forma de bloco único
 b("ala oeste",-L*.30,0,-W*.78,L*.42,12,W*.58,M.building);b("ala leste",L*.28,0,-W*.72,L*.36,12,W*.48,M.building);
 b("pier de embarque",L*.48,0,W*.15,L*.20,9,W*.36,M.blue);
 label(name,x,95,z);return g}
function plane(name,x,z,scale=1,rot=0){const g=new THREE.Group();g.position.set(x,3,z);g.rotation.y=rot;root.add(g);
 const fus=new THREE.Mesh(new THREE.CylinderGeometry(2.4*scale,2.4*scale,34*scale,12),M.plane);fus.rotation.x=Math.PI/2;g.add(fus);
 const wing=new THREE.Mesh(new THREE.BoxGeometry(9*scale,1*scale,42*scale),M.plane);g.add(wing);
 const tail=new THREE.Mesh(new THREE.BoxGeometry(5*scale,1*scale,12*scale),M.plane);tail.position.z=-14*scale;g.add(tail);
 const fin=new THREE.Mesh(new THREE.BoxGeometry(1*scale,6*scale,7*scale),M.blue);fin.position.y=3*scale;fin.position.z=-14*scale;g.add(fin);
 g.userData.name=name;pick.push(fus);return g}
function road(pts,w=12){for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],dx=b[0]-a[0],dz=b[1]-a[1],l=Math.hypot(dx,dz),o=new THREE.Mesh(new THREE.BoxGeometry(l,1,w),M.dark);o.position.set((a[0]+b[0])/2,.2,(a[1]+b[1])/2);o.rotation.y=-Math.atan2(dz,dx);root.add(o)}}
const ground=new THREE.Mesh(new THREE.PlaneGeometry(10500,8500),M.land);ground.rotation.x=-Math.PI/2;ground.position.y=-2;ground.receiveShadow=true;root.add(ground);
// AIP Brasil SBGR AD 2.12: cabeceiras 10L e 10R em coordenadas geográficas.
const r1=runway("RWY 10L / 28R — 3.700 × 45 m",-23.4340528,-46.4825167,-23.4248944,-46.4486194,3700);

// 10R threshold; opposite threshold from published AIP. End inferred along published runway axis/length.
const r2=runway("RWY 10R / 28L — 3.000 × 45 m",-23.4387972,-46.4870278,-23.43136,-46.4590,3000);
// Taxiway spines and connectors, arranged to match the official airport diagram's general topology.
const c1=local(-23.4305,-46.4790),c2=local(-23.4340,-46.4795),c3=local(-23.4380,-46.4790);
taxi("Taxiway paralela norte",[[c1.x-1700,c1.z],[c1.x+1700,c1.z]],24);
taxi("Taxiway paralela central",[[c2.x-1500,c2.z],[c2.x+1500,c2.z]],24);
taxi("Taxiway paralela sul",[[c3.x-1350,c3.z],[c3.x+1350,c3.z]],22);
for(let i=-1200;i<=1200;i+=300){taxi("Conector de pista",[[i,c1.z],[i,c2.z]],18)}
// Main terminal zone west/north of runway system; relative placement follows GRU official aerial-sector map.
const t3=local(-23.4310,-46.4770),t2=local(-23.4342,-46.4800),t1=local(-23.4380,-46.4820);
terminal("TERMINAL 3",t3.x,t3.z,780,210,-.08);
terminal("TERMINAL 2",t2.x,t2.z,1050,250,-.05);
terminal("TERMINAL 1",t1.x,t1.z,430,155,-.04);
const cargo=local(-23.4308,-46.4880);meshBox("Terminal de Cargas",cargo.x,0,cargo.z,430,22,210,M.roof);
const maint=local(-23.4268,-46.4860);meshBox("Área de manutenção",maint.x,0,maint.z,460,18,260,M.concrete);
const hang=local(-23.4270,-46.4610);meshBox("Hangares / aviação",hang.x,0,hang.z,520,22,260,M.roof);
const tower=local(-23.4350,-46.4760);meshBox("Torre de controle",tower.x,0,tower.z,24,72,24,M.blue);meshBox("Cabine da torre",tower.x-4,72,tower.z-4,42,12,42,M.glass);
label("TWR",tower.x,125,tower.z);
// Aprons around terminal frontages and stands.
const apron1=local(-23.4332,-46.4772),apron2=local(-23.4360,-46.4810);
meshBox("Pátio de aeronaves — Terminal 3",apron1.x,-.2,apron1.z,900,1,260,M.concrete);
meshBox("Pátio de aeronaves — Terminal 2",apron2.x,-.2,apron2.z,1150,1,280,M.concrete);
for(let i=0;i<8;i++){plane("Aeronave estacionada — T3",apron1.x-350+i*95,apron1.z+90,1.35,Math.PI/2)}
for(let i=0;i<9;i++){plane("Aeronave estacionada — T2",apron2.x-470+i*110,apron2.z+100,1.25,Math.PI/2)}
// Roads, service zones, parking fields and perimeter indication.
road([[t1.x-450,t1.z+280],[t2.x-500,t2.z+300],[t3.x-400,t3.z+260],[t3.x+500,t3.z+350]],28);
const park=local(-23.4400,-46.4800);meshBox("Estacionamento de passageiros",park.x,0,park.z,620,8,260,M.concrete);
for(let i=0;i<14;i++)line([[park.x-290+i*44,9,park.z-115],[park.x-290+i*44,9,park.z+115]],0xe7e7e7);
label("ESTACIONAMENTO",park.x,70,park.z);
const perimeter=[[-4200,-3300],[4200,-3300],[4200,3300],[-4200,3300],[-4200,-3300]];line(perimeter.map(p=>[p[0],8,p[1]]),0x8ab3c5);
label("AEROPORTO INTERNACIONAL DE SÃO PAULO / GUARULHOS",0,190,-3550);
const ray=new THREE.Raycaster(),mouse=new THREE.Vector2();let showLabels=true;
renderer.domElement.addEventListener("click",e=>{const r=renderer.domElement.getBoundingClientRect();mouse.x=((e.clientX-r.left)/r.width)*2-1;mouse.y=-((e.clientY-r.top)/r.height)*2+1;ray.setFromCamera(mouse,camera);const hits=ray.intersectObjects(pick,true);if(hits.length){let o=hits[0].object;while(o&&!o.userData.name)o=o.parent;document.querySelector("#info b").textContent=o?.userData.name||"Estrutura do aeroporto";document.querySelector("#info p").textContent="Elemento selecionado no modelo 3D."}});
function view(kind){if(kind==="runways"){camera.position.set(-4500,2100,1300);controls.target.set(0,0,0)}else if(kind==="terminals"){camera.position.set(-2300,1500,3400);controls.target.set(-900,0,300)}else{camera.position.set(-4700,3600,5200);controls.target.set(0,0,0)}}
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>view(b.dataset.view));
document.getElementById("home").onclick=()=>view("overview");
document.getElementById("labels").onclick=()=>{showLabels=!showLabels;labels.forEach(s=>s.visible=showLabels);document.getElementById("labels").textContent="RÓTULOS: "+(showLabels?"ON":"OFF")};
window.addEventListener("resize",()=>{
 const width=el.clientWidth,height=el.clientHeight;
 if(!width||!height)return;
 camera.aspect=width/height;camera.updateProjectionMatrix();renderer.setSize(width,height);
});
let frame=0;
function animate(){if(document.hidden)return;frame=requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)}
document.addEventListener("visibilitychange",()=>{if(document.hidden)cancelAnimationFrame(frame);else animate()});
animate();
})();