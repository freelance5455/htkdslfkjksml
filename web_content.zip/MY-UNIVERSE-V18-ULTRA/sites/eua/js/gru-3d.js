import * as THREE from '../vendor/three.module.js';
import { OrbitControls } from '../vendor/OrbitControls.js';

const container = document.getElementById('gru3d');
const info = document.getElementById('gruInfo');

if (container) {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x091522);

    const camera = new THREE.PerspectiveCamera(
        45, container.clientWidth / container.clientHeight, 0.1, 2000
    );
    camera.position.set(65, 65, 85);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.domElement.setAttribute('role', 'img');
    renderer.domElement.setAttribute('aria-label', 'Modelo 3D do Aeroporto de Guarulhos. Arraste para orbitar; foque o modelo e use as setas para mover a câmera.');
    renderer.domElement.tabIndex = 0;
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.listenToKeyEvents(renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.minDistance = 25;
    controls.maxDistance = 180;
    controls.target.set(0, 0, 0);

    scene.add(new THREE.HemisphereLight(0xb9d9ff, 0x263342, 2));

    const sun = new THREE.DirectionalLight(0xffffff, 2.5);
    sun.position.set(35, 80, 40);
    sun.castShadow = true;
    scene.add(sun);

    const airport = new THREE.Group();
    scene.add(airport);

    const clickable = [];
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    function material(color, roughness = 0.8) {
        return new THREE.MeshStandardMaterial({ color, roughness });
    }

    function box(name, x, y, z, sx, sy, sz, color, parent = airport) {
        const mesh = new THREE.Mesh(
            new THREE.BoxGeometry(sx, sy, sz),
            material(color)
        );
        mesh.position.set(x, y, z);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.name = name;
        parent.add(mesh);
        return mesh;
    }

    // Terreno e pistas
    box('Terreno', 0, -1.2, 0, 150, 1, 120, 0x34483c);
    box('Pista de pouso', 0, -0.55, -43, 125, 0.15, 9, 0x303943);
    box('Pista auxiliar', -42, -0.53, -25, 8, 0.15, 35, 0x303943);
    box('Área de taxiamento', 0, -0.52, -31, 110, 0.12, 3, 0x59636a);

    // Marcação simplificada da pista
    for (let i = -5; i <= 5; i++) {
        box('Marcação da pista', i * 9, -0.43, -43, 0.5, 0.04, 0.35, 0xffffff);
    }

    // Vias de acesso e estacionamento
    box('Via de acesso', 0, -0.48, 35, 145, 0.2, 7, 0x252d36);
    box('Estacionamento', -48, -0.45, 22, 25, 0.2, 24, 0x59636a);
    box('Estacionamento', 48, -0.45, 22, 25, 0.2, 24, 0x59636a);

    // Edifícios dos terminais
    box('Terminal 1', -43, 4, 0, 25, 8, 17, 0x91a8b8);
    box('Terminal 2', -5, 5, 5, 48, 10, 25, 0x9eafbb);
    box('Terminal 3', 42, 7, -4, 38, 14, 23, 0x829eae);

    // Fachadas envidraçadas
    box('Fachada T1', -43, 3.5, 8.7, 23, 5, 0.25, 0x55a8cb);
    box('Fachada T2', -5, 4, 17.7, 45, 6, 0.25, 0x55a8cb);
    box('Fachada T3', 42, 5.5, 7.7, 35, 8, 0.25, 0x55a8cb);

    // Coberturas
    box('Cobertura T1', -43, 8.2, 0, 27, 0.7, 19, 0x526b80);
    box('Cobertura T2', -5, 10.2, 5, 50, 0.7, 27, 0x526b80);
    box('Cobertura T3', 42, 14.2, -4, 40, 0.7, 25, 0x526b80);

    // Pátio de aeronaves e posições
    for (let i = -2; i <= 2; i++) {
        box('Posição de aeronave', i * 15, -0.35, -20, 8, 0.1, 5, 0x777f86);
    }

    // Aeronave ilustrativa
    const plane = new THREE.Group();
    airport.add(plane);
    const fuselage = new THREE.Mesh(
        new THREE.CylinderGeometry(0.7, 0.7, 13, 16),
        material(0xe7edf2)
    );
    fuselage.rotation.z = Math.PI / 2;
    plane.add(fuselage);

    const wing = box('Asa', 0, 0, 0, 5, 0.25, 15, 0xd4dde5, plane);
    const tail = box('Cauda', -5.5, 0.8, 0, 2, 0.2, 4, 0xd4dde5, plane);
    plane.position.set(8, 1.4, -27);
    plane.rotation.y = Math.PI / 2;

    // Pontos clicáveis com posição ilustrativa
    const points = [
        {name:'Terminal 1', x:-43, z:0, text:'Terminal 1. Consulte a companhia aérea para confirmar se seu voo opera neste terminal.'},
        {name:'Terminal 2', x:-5, z:5, text:'Terminal 2. Verifique o terminal e o setor de check-in indicados na sua passagem.'},
        {name:'Terminal 3', x:42, z:-4, text:'Terminal 3. Terminal utilizado por diversas operações internacionais. Confirme seu voo.'},
        {name:'Check-in', x:-5, z:18, text:'Área de check-in. Localize o balcão da companhia aérea, apresente os documentos e confirme o despacho de bagagem.'},
        {name:'Segurança', x:5, z:22, text:'Controle de segurança. Prepare os objetos e bagagens conforme as regras aeroportuárias.'},
        {name:'Imigração', x:25, z:18, text:'Controle migratório de saída, conforme o fluxo aplicável ao seu embarque.'},
        {name:'Portões de embarque', x:42, z:13, text:'Área de portões. Confira o número do portão e o horário de embarque nos painéis.'},
        {name:'Pista', x:0, z:-43, text:'Área operacional de pistas. Área restrita, sem acesso de passageiros.'},
        {name:'Estacionamento', x:-48, z:22, text:'Área de estacionamento e acesso terrestre.'}
    ];

    const sphereGeometry = new THREE.SphereGeometry(1.5, 24, 24);

    points.forEach((p, index) => {
        const pin = new THREE.Mesh(
            sphereGeometry,
            new THREE.MeshStandardMaterial({
                color: 0x55c9ff,
                emissive: 0x125080,
                emissiveIntensity: 0.7
            })
        );
        pin.position.set(p.x, 3, p.z);
        pin.userData = p;
        pin.name = p.name;
        airport.add(pin);
        clickable.push(pin);
    });

    function selectPoint(p) {
        info.innerHTML = '';
        const title = document.createElement('h3');
        title.textContent = p.name;
        const description = document.createElement('p');
        description.textContent = p.text;
        const note = document.createElement('p');
        note.textContent = 'Localização ilustrativa. Confirme os dados operacionais antes da viagem.';
        info.append(title, description, note);
        info.classList.add('active');
        controls.target.set(p.x, 2, p.z);
    }

    renderer.domElement.addEventListener('pointerdown', event => {
        const rect = renderer.domElement.getBoundingClientRect();
        mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(mouse, camera);
        const hits = raycaster.intersectObjects(clickable);
        if (hits.length) selectPoint(hits[0].object.userData);
    });

    document.getElementById('gruReset').addEventListener('click', () => {
        camera.position.set(65, 65, 85);
        controls.target.set(0, 0, 0);
        controls.update();
    });

    document.getElementById('gruTop').addEventListener('click', () => {
        camera.position.set(0, 115, 0.1);
        controls.target.set(0, 0, 0);
        controls.update();
    });

    document.getElementById('gruSide').addEventListener('click', () => {
        camera.position.set(120, 35, 0);
        controls.target.set(0, 0, 0);
        controls.update();
    });

    let animationFrame = 0;
    function animate() {
        if (document.hidden) return;
        animationFrame = requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) cancelAnimationFrame(animationFrame);
        else animate();
    });
    animate();

    new ResizeObserver(() => {
        const w = container.clientWidth;
        const h = container.clientHeight;
        if (!w || !h) return;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
    }).observe(container);
}
