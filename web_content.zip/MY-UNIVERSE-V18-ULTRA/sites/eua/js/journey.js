(() => {
  "use strict";

  const STORAGE_KEY = "myUniverseEUA_v1";
  const STATUS_OPTIONS = ["Pendente", "Em andamento", "Concluída"];
  const createId = () => globalThis.crypto?.randomUUID?.()
    || `eua-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
  const plainObject = (value) => value && typeof value === "object" && !Array.isArray(value);

  const stagesInitial = [
    ["Planejamento", "Definir objetivo, período e destino nos EUA."],
    ["Documentação", "Verificar passaporte e requisitos do visto adequado."],
    ["Visto", "Pesquisar procedimento oficial, formulários e entrevista."],
    ["Preparação financeira", "Planejar orçamento, câmbio e meios de pagamento."],
    ["Ônibus no Brasil", "Definir origem, rodoviária, passagem e horário."],
    ["Chegada a São Paulo", "Planejar deslocamento até o aeroporto de Guarulhos."],
    ["Aeroporto GRU", "Confirmar terminal, companhia aérea e balcão de check-in."],
    ["Check-in", "Confirmar documentação, assento e despacho de bagagem."],
    ["Segurança e embarque", "Conferir inspeção, imigração de saída quando aplicável e portão."],
    ["Voo internacional", "Registrar voo, duração, conexões e horários."],
    ["Imigração nos EUA", "Seguir as orientações oficiais e responder com informações verdadeiras."],
    ["Bagagem e alfândega", "Retirar bagagem e cumprir os procedimentos aduaneiros."],
    ["Transporte nos EUA", "Definir como sair do aeroporto."],
    ["Hotel", "Registrar endereço, reserva, check-in e check-out."],
    ["Instalação", "Organizar comunicação, transporte e próximos passos."]
  ].map(([title, notes]) => ({
    id: createId(), titulo: title, local: "", endereco: "", data: "", status: "Pendente", notas: notes
  }));
  const pointsInitial = [
    ["Entrada do terminal", "Acesso ao terminal correto."],
    ["Check-in", "Balcão da companhia aérea."],
    ["Despacho de bagagem", "Entrega das malas."],
    ["Inspeção de segurança", "Controle de segurança."],
    ["Imigração", "Controle migratório, conforme o fluxo aplicável."],
    ["Portão de embarque", "Confirmar número e horário."]
  ].map(([name, description]) => ({ id: createId(), nome: name, descricao: description }));

  const initialData = () => ({ campos: {}, etapas: stagesInitial, pontos: pointsInitial });

  function normalizeRecords(records, type) {
    const used = new Set();
    return records.filter(plainObject).map((record) => {
      let id = String(record.id ?? "").slice(0, 100);
      if (!id || used.has(id)) {
        do { id = createId(); } while (used.has(id));
      }
      used.add(id);
      const text = (key, limit) => String(record[key] ?? "").slice(0, limit);
      if (type === "stage") {
        const status = STATUS_OPTIONS.includes(record.status) ? record.status : "Pendente";
        return {
          id, titulo: text("titulo", 160), local: text("local", 240), endereco: text("endereco", 500),
          data: text("data", 120), status, notas: text("notas", 4000)
        };
      }
      return { id, nome: text("nome", 160), descricao: text("descricao", 2000) };
    });
  }

  function normalizeData(value) {
    const source = plainObject(value) ? value : {};
    const fields = plainObject(source.campos) ? source.campos : {};
    const safeFields = {};
    document.querySelectorAll("[data-field]").forEach((element) => {
      const key = element.dataset.field;
      safeFields[key] = String(fields[key] ?? "").slice(0, 8000);
    });
    return {
      campos: safeFields,
      etapas: normalizeRecords(Array.isArray(source.etapas) ? source.etapas : [], "stage"),
      pontos: normalizeRecords(Array.isArray(source.pontos) ? source.pontos : [], "point")
    };
  }

  let data = initialData();

  function setNotice(text, error = false) {
    const notice = document.getElementById("aviso");
    if (!notice) return;
    notice.textContent = text;
    notice.setAttribute("role", "status");
    notice.classList.toggle("error", error);
  }

  function load() {
    document.querySelectorAll("[data-field]").forEach((element) => {
      const id = `field-${element.dataset.field}`;
      element.id = id;
      const label = element.previousElementSibling;
      if (label?.tagName === "LABEL") label.htmlFor = id;
    });
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) data = normalizeData(JSON.parse(stored));
    } catch {
      setNotice("Os dados salvos não puderam ser lidos. O planejamento inicial foi carregado.", true);
    }
    document.querySelectorAll("[data-field]").forEach((element) => {
      element.value = data.campos[element.dataset.field] || "";
      element.addEventListener("input", () => {
        data.campos[element.dataset.field] = element.value;
        save();
      });
    });
    render();
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      setNotice("Salvo automaticamente neste navegador.");
      updateSummary();
      return true;
    } catch {
      setNotice("Não foi possível salvar neste navegador. Exporte um backup e libere espaço.", true);
      return false;
    }
  }

  function updateSummary() {
    const total = data.etapas.length;
    const complete = data.etapas.filter((stage) => stage.status === "Concluída").length;
    const percent = total ? Math.round(complete / total * 100) : 0;
    document.getElementById("totalEtapas").textContent = total;
    document.getElementById("concluidas").textContent = complete;
    document.getElementById("percentual").textContent = `${percent}%`;
    document.getElementById("barra").style.width = `${percent}%`;
    document.getElementById("progress-journey").setAttribute("aria-valuenow", String(percent));
  }

  function renderStages() {
    const list = document.getElementById("listaEtapas");
    list.replaceChildren();
    data.etapas.forEach((stage) => {
      const item = document.createElement("article");
      item.className = "item";
      const id = escapeHTML(stage.id);
      item.innerHTML = `
        <div class="item-top"><h3>ETAPA DA JORNADA</h3>
        <button type="button" class="remove" data-remove="${id}" aria-label="Excluir etapa ${escapeHTML(stage.titulo)}">Excluir</button></div>
        <label>Nome da etapa<input data-id="${id}" data-prop="titulo" maxlength="160"></label>
        <div class="field-grid">
          <label>Local<input data-id="${id}" data-prop="local" maxlength="240"></label>
          <label>Endereço<input data-id="${id}" data-prop="endereco" maxlength="500"></label>
          <label>Data / horário<input data-id="${id}" data-prop="data" maxlength="120"></label>
          <label>Status<select class="status" data-id="${id}" data-prop="status">
            ${STATUS_OPTIONS.map((option) => `<option>${option}</option>`).join("")}
          </select></label>
        </div>
        <label>Detalhes e instruções<textarea data-id="${id}" data-prop="notas" maxlength="4000"></textarea></label>`;
      list.appendChild(item);
      item.querySelectorAll("[data-prop]").forEach((element) => {
        const key = element.dataset.prop;
        element.value = stage[key] || "";
        const update = () => updateStage(stage.id, key, element.value);
        element.addEventListener("input", update);
        element.addEventListener("change", update);
      });
      item.querySelector("[data-remove]").addEventListener("click", () => {
        if (!confirm(`Excluir a etapa “${stage.titulo}”?`)) return;
        data.etapas = data.etapas.filter((entry) => entry.id !== stage.id);
        save();
        renderStages();
        updateSummary();
      });
    });
  }

  function updateStage(id, key, value) {
    const stage = data.etapas.find((entry) => entry.id === id);
    if (!stage) return;
    stage[key] = value;
    save();
  }

  function renderPoints() {
    const map = document.getElementById("mapaPontos");
    map.replaceChildren();
    data.pontos.forEach((point) => {
      const card = document.createElement("article");
      card.className = "map-point";
      const id = escapeHTML(point.id);
      card.innerHTML = `
        <b>PONTO DO AEROPORTO</b>
        <label>Nome<input aria-label="Nome do ponto" data-map="${id}" data-prop="nome" maxlength="160"></label>
        <label>Descrição<textarea aria-label="Descrição do ponto" data-map="${id}" data-prop="descricao" maxlength="2000"></textarea></label>
        <button type="button" class="remove" data-map-remove="${id}" aria-label="Excluir ponto ${escapeHTML(point.nome)}">Excluir ponto</button>`;
      map.appendChild(card);
      card.querySelectorAll("[data-prop]").forEach((element) => {
        const key = element.dataset.prop;
        element.value = point[key] || "";
        element.addEventListener("input", () => {
          point[key] = element.value;
          save();
        });
      });
      card.querySelector("[data-map-remove]").addEventListener("click", () => {
        if (!confirm(`Excluir o ponto “${point.nome}”?`)) return;
        data.pontos = data.pontos.filter((entry) => entry.id !== point.id);
        save();
        renderPoints();
      });
    });
  }

  function render() {
    renderStages();
    renderPoints();
    updateSummary();
  }

  function addStage() {
    data.etapas.push({ id: createId(), titulo: "Nova etapa", local: "", endereco: "", data: "", status: "Pendente", notas: "" });
    save();
    renderStages();
    document.querySelector("#listaEtapas .item:last-child input")?.focus();
  }

  function addPoint() {
    data.pontos.push({ id: createId(), nome: "Novo ponto", descricao: "" });
    save();
    renderPoints();
    document.querySelector("#mapaPontos .map-point:last-child input")?.focus();
  }

  function exportData() {
    const file = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(file);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "meu-planejamento-eua.json";
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function importData(file) {
    if (!file) return;
    try {
      if (file.size > 5 * 1024 * 1024) throw new Error("Arquivo maior que 5 MB.");
      const imported = normalizeData(JSON.parse(await file.text()));
      if (!confirm("Substituir o planejamento atual pelo backup?")) return;
      data = imported;
      document.querySelectorAll("[data-field]").forEach((element) => {
        element.value = data.campos[element.dataset.field] || "";
      });
      save();
      render();
    } catch {
      alert("Não foi possível importar esse arquivo. Verifique se é um backup JSON válido.");
    } finally {
      document.getElementById("importarArquivo").value = "";
    }
  }

  function clearData() {
    if (!confirm("Apagar permanentemente o planejamento e os pontos deste projeto salvos neste navegador?")) return;
    try { localStorage.removeItem(STORAGE_KEY); } catch {}
    window.location.reload();
  }

  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    switch (button.dataset.action) {
      case "start": document.getElementById("jornada").scrollIntoView({ behavior: "smooth" }); break;
      case "export": exportData(); break;
      case "import": document.getElementById("importarArquivo").click(); break;
      case "add-stage": addStage(); break;
      case "add-point": addPoint(); break;
      case "clear": clearData(); break;
    }
  });
  document.getElementById("importarArquivo").addEventListener("change", (event) => importData(event.target.files?.[0]));

  load();
})();
