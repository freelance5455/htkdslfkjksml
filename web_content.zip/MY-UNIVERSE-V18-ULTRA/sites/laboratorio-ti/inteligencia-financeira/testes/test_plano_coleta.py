import tempfile
import unittest
from pathlib import Path
from unittest import mock

from gfi import config, db, plano_coleta


class TestPlanoColeta(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = mock.patch.object(config, 'DADOS', Path(self.tmp.name) / 'dados')
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_plano_tem_145_tarefas_em_16_etapas(self):
        r = plano_coleta.status()
        self.assertEqual(r['total'], 145)
        self.assertEqual(len(r['etapas']), 16)
        self.assertEqual(sum(x['total'] for x in r['etapas']), 145)

    def test_tarefa_1_inicia_em_andamento(self):
        r = plano_coleta.status()
        t = next(x for x in r['tarefas'] if x['id'] == 1)
        self.assertEqual(t['status'], 'em_andamento')
        self.assertIn('13 grupos', t['evidencia'])

    def test_nao_permite_concluir_sem_evidencia_e_validacao(self):
        with self.assertRaisesRegex(ValueError, 'evidência objetiva'):
            plano_coleta.atualizar(2, 'concluida', 'curto', 'curto')

    def test_conclusao_persiste_com_evidencia_e_validacao(self):
        r = plano_coleta.atualizar(2, 'concluida', 'Arquivo oficial baixado e SHA256 registrado.', 'ZIP íntegro; parser leu registros e amostra conferida.')
        t = next(x for x in r['tarefas'] if x['id'] == 2)
        self.assertEqual(t['status'], 'concluida')
        self.assertEqual(r['totais']['concluida'], 1)

    def test_rejeita_id_fora_do_plano(self):
        with self.assertRaisesRegex(ValueError, 'identificador'):
            plano_coleta.atualizar(146, 'em_andamento')


if __name__ == '__main__':
    unittest.main()
