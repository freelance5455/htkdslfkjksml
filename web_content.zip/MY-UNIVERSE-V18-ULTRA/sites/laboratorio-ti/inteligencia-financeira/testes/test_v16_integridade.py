import tempfile
import unittest
from pathlib import Path
from unittest import mock

from gfi import config, db, dados, validacao, catalogo
from gfi.conectores import yahoo_chart
from gfi.motores import pontuacao


class TestV16Integridade(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = mock.patch.object(config, "DADOS", Path(self.tmp.name) / "dados")
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_b3_prevalece_yahoo_na_mesma_data_e_yahoo_completa_datas_novas(self):
        iid = catalogo.upsert("ABCD3", "BVMF", "REAL", moeda="BRL", pais="BR")
        db.executar("INSERT INTO cotacoes(instrumento_id,data,abertura,maximo,minimo,fechamento,volume_fin,qtd,origem) VALUES(?,?,?,?,?,?,?,?,?)",
                    (iid, "2026-11-19", 10, 12, 9, 11, 1000, 100, "B3-COTAHIST"))
        db.executar("INSERT INTO cotacoes_provedor_diarias(instrumento_id,provedor,data,abertura,maximo,minimo,fechamento,volume,estado,coletado_em) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (iid, "YAHOO_FINANCE_CHART", "2026-11-19", 20, 22, 19, 21, 2000, "DELAYED", 1795200000))
        db.executar("INSERT INTO cotacoes_provedor_diarias(instrumento_id,provedor,data,abertura,maximo,minimo,fechamento,volume,estado,coletado_em) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (iid, "YAHOO_FINANCE_CHART", "2026-11-20", 11, 13, 10, 12, 3000, "DELAYED", 1795286400))
        cs = dados.candles(iid)
        self.assertEqual([x[0] for x in cs], ["2026-11-19", "2026-11-20"])
        self.assertEqual(cs[0][4], 11)  # B3 oficial ganha no conflito
        self.assertEqual(cs[1][4], 12)  # Yahoo complementa dia ausente
        self.assertEqual(dados.fontes_candles(iid), ["B3-COTAHIST", "YAHOO_FINANCE_CHART"])

    def test_serie_antiga_fica_desatualizada_em_relacao_a_hoje(self):
        candles = [("2017-12-28", 10, 11, 9, 10, 100, 10)]
        r = validacao.validar_candles(candles, "2026-11-22")
        self.assertTrue(r["desatualizado"])
        self.assertGreater(r["dias_defasagem"], 7)

    def test_indice_geral_e_suspenso_quando_serie_esta_antiga(self):
        dims_originais = pontuacao._FUNCOES
        pontuacao._FUNCOES = {k: (lambda ctx: pontuacao._d(80, "teste")) for k in config.DIMENSOES}
        try:
            ctx = {"validacao": {"desatualizado": True, "qualidade": 0.9, "problemas": ["série antiga"], "saltos": []},
                   "inst": {"tipo": "acao"}, "eventos": [],
                   "risco": {"liquidez": None, "vol_anual": None, "max_drawdown": None},
                   "valuation": {"armadilha_valor": {"alerta": False}}, "candles": [],
                   "macro": {}, "fund": {}, "fonte_precos": "teste", "ultima_data": "2017-12-28"}
            r = pontuacao.calcular(ctx)
            self.assertIsNone(r["indice"])
            self.assertTrue(r["analise_suspensa"])
            for nome in ("tecnica", "liquidez", "volatilidade", "risco", "longo_prazo", "valuation"):
                self.assertIsNone(r["dimensoes"][nome]["score"])
        finally:
            pontuacao._FUNCOES = dims_originais

    def test_parser_diario_preserva_ohlcv_e_data_local(self):
        import json
        payload = {"chart": {"result": [{"meta": {"exchangeName": "SAO", "currency": "BRL"},
                    "timestamp": [1795200000], "indicators": {"quote": [{"open": [10.0], "high": [12.0],
                    "low": [9.0], "close": [11.0], "volume": [1234]}]}}], "error": None}}
        class Response:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self, n): return json.dumps(payload).encode()
        with mock.patch("urllib.request.urlopen", return_value=Response()):
            r = yahoo_chart.buscar("ABCD3.SA", "1d", "1mo")
        self.assertEqual(r["pontos"][0]["abertura"], 10.0)
        self.assertEqual(r["pontos"][0]["maximo"], 12.0)
        self.assertEqual(r["pontos"][0]["minimo"], 9.0)
        self.assertEqual(r["pontos"][0]["preco"], 11.0)
        self.assertEqual(r["pontos"][0]["volume"], 1234.0)

    def test_coletor_diario_grava_candle_separado_e_nao_intraday(self):
        iid = catalogo.upsert("ABCD3", "BVMF", "REAL", moeda="BRL", pais="BR")
        pacote = {"simbolo": "ABCD3.SA", "intervalo": "1d", "periodo": "1mo", "exchange": "SAO", "moeda": "BRL",
                  "pontos": [{"observado_em": "2026-11-20T17:00:00+00:00", "data": "2026-11-20",
                  "abertura": 10, "maximo": 12, "minimo": 9, "preco": 11, "volume": 1000}]}
        with mock.patch.object(yahoo_chart, "buscar", return_value=pacote):
            r = yahoo_chart.coletar(iid, "ABCD3.SA", "1d", "1mo")
        self.assertEqual(r["candles_diarios"], 1)
        self.assertEqual(live_count(iid), 0)
        self.assertEqual(dados.candles(iid)[0][4], 11)


def live_count(iid):
    return (db.um("SELECT COUNT(*) n FROM cotacoes_intradiarias WHERE instrumento_id=?", (iid,)) or {}).get("n", 0)


if __name__ == "__main__":
    unittest.main()
