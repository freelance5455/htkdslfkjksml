import tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from gfi import v9

class Resp:
    status=200
    def __enter__(self): return self
    def __exit__(self,*a): pass
    def read(self,n=-1):
        return b'''<?xml version="1.0"?><rss><channel><item><title>Mercado brasileiro avanca</title><link>https://example.com/noticia</link><pubDate>Sun, 22 Nov 2026 12:00:00 GMT</pubDate><description>Resumo publico</description><source>Fonte teste</source></item></channel></rss>'''

class TestV9(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.old=v9.DB_V9; v9.DB_V9=Path(self.tmp.name)/'v9.db'
    def tearDown(self):
        v9.DB_V9=self.old; self.tmp.cleanup()
    def test_wallet_deposit_and_trade_are_persisted(self):
        v9.carteira_lancar({'kind':'deposito','amount':1000})
        r=v9.carteira_lancar({'kind':'compra','amount':200,'ticker':'PETR4','quantity':10,'unit_price':20})
        self.assertEqual(r['saldo_caixa'],800)
        self.assertEqual(r['posicoes']['PETR4']['quantidade'],10)
        self.assertEqual(len(r['movimentacoes']),2)
    def test_realized_pnl_and_remaining_position(self):
        v9.carteira_lancar({'kind':'deposito','amount':1000})
        v9.carteira_lancar({'kind':'compra','amount':200,'ticker':'PETR4','quantity':10,'unit_price':20})
        r=v9.carteira_lancar({'kind':'venda','amount':150,'ticker':'PETR4','quantity':5,'unit_price':30})
        self.assertEqual(r['lucro_prejuizo_realizado'],50)
        self.assertEqual(r['posicoes']['PETR4']['quantidade'],5)

    def test_invalid_trade_is_rejected(self):
        with self.assertRaises(ValueError): v9.carteira_lancar({'kind':'compra','amount':20,'ticker':'','quantity':0,'unit_price':0})
    @patch('gfi.v9.urllib.request.urlopen',return_value=Resp())
    def test_news_rss_is_cached_and_attributed(self,_):
        r=v9.noticias(True)
        self.assertEqual(len(r['eventos']),1)
        self.assertEqual(r['eventos'][0]['fonte'],'Fonte teste')
        cached=v9.noticias(False)
        self.assertEqual(cached['eventos'][0]['url'],'https://example.com/noticia')

if __name__=='__main__': unittest.main()
