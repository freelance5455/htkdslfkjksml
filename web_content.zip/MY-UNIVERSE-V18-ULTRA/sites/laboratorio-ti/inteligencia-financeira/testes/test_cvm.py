import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from gfi.conectores import cvm
from gfi import config, db


class CVMTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old = config.DADOS
        config.DADOS = Path(self.tmp.name)
        db._PRONTOS.clear()
        db.conectar().close()

    def tearDown(self):
        config.DADOS = self.old
        db._PRONTOS.clear()
        self.tmp.cleanup()

    def csv(self):
        return ("CNPJ_CIA;DT_REFER;VERSAO;ORDEM_EXERC;CD_CONTA;DS_CONTA;VL_CONTA;MOEDA;ESCALA_MOEDA;GRUPO_DFP\\n"
                "12.345.678/0001-90;2024-12-31;1;2024;1.01;Caixa;1234.56;REAL;MIL;DF Consolidado\\n"
                "12.345.678/0001-90;2024-12-31;1;2024;1.02;Zero;0;REAL;MIL;DF Consolidado\\n"
                "invalido;2024-12-31;1;2024;1.03;Ruim;20;REAL;MIL;DF Consolidado\\n").replace("\\n", "\n").encode("latin-1")

    def zip(self):
        b = io.BytesIO()
        with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("dfp_cia_aberta_DRE_con_2024.csv", self.csv())
        return b.getvalue()

    def test_parser_normaliza_cnpj_e_preserva_zero(self):
        rows = cvm.parse_csv(self.csv(), "DRE_con.csv", "DFP", 2024)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["cnpj"], "12345678000190")
        self.assertEqual(rows[0]["valor"], 1234.56)
        self.assertEqual(rows[1]["valor"], 0)

    def test_importacao_zip_idempotente(self):
        a = cvm.importar_zip(self.zip(), "DFP", 2024)
        b = cvm.importar_zip(self.zip(), "DFP", 2024)
        self.assertEqual(a["registros_novos"], 2)
        self.assertEqual(b["registros_novos"], 0)
        self.assertEqual(cvm.status()["lancamentos"], 2)

    def test_zip_sem_dados_reconhecidos_rejeitado(self):
        b = io.BytesIO()
        with zipfile.ZipFile(b, "w") as z:
            z.writestr("leia-me.txt", "sem dados")
        with self.assertRaises(ValueError):
            cvm.importar_zip(b.getvalue(), "DFP", 2024)


    def test_parser_descarta_valor_invalido_conta_vazia_e_data_invalida(self):
        bruto = ("CNPJ_CIA;DT_REFER;VERSAO;ORDEM_EXERC;CD_CONTA;DS_CONTA;VL_CONTA\n"
                 "12345678000190;2024-12-31;1;2024;1.01;Ok;10\n"
                 "12345678000190;2024-12-31;1;2024;1.02;Ruim;NaN\n"
                 "12345678000190;2024-13-40;1;2024;1.03;Data;20\n"
                 "12345678000190;2024-12-31;1;2024;;Sem conta;30\n").encode()
        rows = cvm.parse_csv(bruto, "DRE_con.csv", "DFP", 2024)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["valor"], 10)

    def test_consulta_por_instrumento_exige_vinculo_confirmado(self):
        db.executar("INSERT INTO instrumentos(id,ticker,mic,origem) VALUES(1,'TEST3','BVMF','teste')")
        self.assertFalse(cvm.consultar_instrumento(1)["mapeado"])
        cvm.importar_zip(self.zip(), "DFP", 2024)
        cvm.mapear_emissor("12.345.678/0001-90", 1, "vínculo conferido")
        resposta = cvm.consultar_instrumento(1)
        self.assertTrue(resposta["mapeado"])
        self.assertEqual(len(resposta["lancamentos"]), 2)
        self.assertEqual(resposta["emissores"][0]["cnpj"], "12345678000190")

    def test_lancamentos_com_grupo_ausente_sao_idempotentes(self):
        bruto = ("CNPJ_CIA;DT_REFER;VERSAO;ORDEM_EXERC;CD_CONTA;DS_CONTA;VL_CONTA\n"
                 "12345678000190;2024-12-31;1;;1.01;Caixa;10\n").encode()
        b = io.BytesIO()
        with zipfile.ZipFile(b, "w") as z:
            z.writestr("dfp_cia_aberta_DRE_con_2024.csv", bruto)
        self.assertEqual(cvm.importar_zip(b.getvalue(), "DFP", 2024)["registros_novos"], 1)
        self.assertEqual(cvm.importar_zip(b.getvalue(), "DFP", 2024)["registros_novos"], 0)

    def test_documento_e_ano_validos(self):
        with self.assertRaises(ValueError):
            cvm.importar_zip(self.zip(), "FRE", 2024)
        with self.assertRaises(ValueError):
            cvm.importar_zip(self.zip(), "DFP", 1990)

    def test_dicionario_classifica_codigo_por_demonstracao(self):
        from gfi.conectores import contas
        ativo = contas.classificar({"arquivo_origem": "BPA_con_2024.csv", "codigo_conta": "1.01"})
        receita = contas.classificar({"arquivo_origem": "DRE_con_2024.csv", "codigo_conta": "3.01"})
        caixa = contas.classificar({"arquivo_origem": "DFC_MD_con_2024.csv", "codigo_conta": "6.01"})
        self.assertEqual(ativo["indicador"], "ativo_circulante")
        self.assertEqual(receita["indicador"], "receita_liquida_vendas")
        self.assertEqual(caixa["indicador"], "caixa_operacional")

    def test_dicionario_nao_infere_codigo_ou_familia_desconhecida(self):
        from gfi.conectores import contas
        self.assertIsNone(contas.classificar({"arquivo_origem": "DRE_con.csv", "codigo_conta": "3.01.99"}))
        self.assertIsNone(contas.classificar({"arquivo_origem": "arquivo_qualquer.csv", "codigo_conta": "3.01"}))
        self.assertIsNone(contas.classificar({"arquivo_origem": "BPA_con.csv", "codigo_conta": "3.01"}))

    def test_indicadores_cnpj_preservam_origem_e_nao_mapeiam_subconta(self):
        bruto = ("CNPJ_CIA;DT_REFER;VERSAO;ORDEM_EXERC;CD_CONTA;DS_CONTA;VL_CONTA;MOEDA;ESCALA_MOEDA\n"
                 "12345678000190;2024-12-31;1;2024;3.01;Receita;1000;REAL;MIL\n"
                 "12345678000190;2024-12-31;1;2024;3.01.01;Subconta;400;REAL;MIL\n").encode()
        b = io.BytesIO()
        with zipfile.ZipFile(b, "w") as z:
            z.writestr("dfp_cia_aberta_DRE_con_2024.csv", bruto)
        cvm.importar_zip(b.getvalue(), "DFP", 2024)
        resposta = cvm.indicadores_cnpj("12345678000190")
        self.assertEqual(resposta["total_classificados"], 1)
        self.assertEqual(resposta["total_nao_mapeados"], 1)
        self.assertEqual(resposta["indicadores"][0]["indicador"], "receita_liquida_vendas")
        self.assertEqual(resposta["indicadores"][0]["escala_moeda"], "MIL")
        self.assertEqual(resposta["indicadores"][0]["arquivo_origem"], "dfp_cia_aberta_DRE_con_2024.csv")

    def test_dicionario_tem_regras_e_politica_conservadora(self):
        d = cvm.dicionario_contabil()
        self.assertGreaterEqual(d["total_mapeado"], 15)
        self.assertIn("Correspondência exata", d["politica"])


if __name__ == "__main__":
    unittest.main()
