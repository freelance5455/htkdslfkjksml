"""Testes da IA financeira. Rodar (dentro de inteligencia-financeira/):  python3 -m unittest discover -s testes -t .
Cada classe usa um banco temporário: nunca toca nos seus dados."""
import io
import json
import math
import tempfile
from datetime import date
import threading
import unittest
import zipfile
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock

from gfi import (alertas, api, atualizacoes, autoavaliacao, backtest, catalogo, config, dados, db, evolucao, oportunidades, pesquisa,
                 pipeline, previsoes, recursos, validacao)
from gfi.conectores import b3_cotahist, bcb, simulado, base
from gfi.motores import macro, pontuacao, risco, tecnico, valuation


class Base(unittest.TestCase):
    demo = False

    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        cls._p = [mock.patch.object(config, "DADOS", Path(cls._tmp.name) / "d"), mock.patch.object(atualizacoes, "DIR", Path(cls._tmp.name) / "atu")]
        for p in cls._p:
            p.start()
        atualizacoes.DIR.mkdir()
        if cls.demo:
            simulado.gerar()
            db.cfg_set("modo_demo", True)
            pipeline.recalcular(todos=True)

    @classmethod
    def tearDownClass(cls):
        for p in cls._p:
            p.stop()
        cls._tmp.cleanup()


class TestConexaoBanco(unittest.TestCase):
    def test_contexto_da_conexao_fecha_recurso(self):
        con = db.sqlite3.connect(":memory:", factory=db._Conexao)
        with con:
            con.execute("CREATE TABLE teste (id INTEGER)")
        with self.assertRaises(db.sqlite3.ProgrammingError):
            con.execute("SELECT 1")


def datas(n, inicio="2022-01-03"):
    from datetime import date, timedelta
    d, out = date.fromisoformat(inicio), []
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d.isoformat())
        d += timedelta(days=1)
    return out


def serie(n, f=lambda i: 100 + i):
    return [(d, f(i), f(i) * 1.01, f(i) * 0.99, f(i), 1000.0, 10.0) for i, d in enumerate(datas(n))]


class TestIndicadores(unittest.TestCase):
    def test_rsi_extremos(self):
        self.assertEqual(tecnico.rsi(list(range(1, 40))), 100.0)
        self.assertEqual(tecnico.rsi(list(range(40, 1, -1))), 0.0)
        self.assertIsNone(tecnico.rsi([1, 2, 3]))

    def test_medias_e_macd(self):
        self.assertEqual(tecnico.sma([1, 2, 3, 4], 2), 3.5)
        self.assertIsNone(tecnico.sma([1], 5))
        m = tecnico.macd([100 + i for i in range(80)])
        self.assertGreater(m[0], 0)

    def test_bollinger_atr_adx_obv_vwap(self):
        c = [100 + math.sin(i / 3) * 5 for i in range(80)]
        h, l = [x + 1 for x in c], [x - 1 for x in c]
        b = tecnico.bollinger(c)
        self.assertTrue(b["inferior"] < b["media"] < b["superior"])
        self.assertGreater(tecnico.atr(h, l, c), 0)
        a, pdi, mdi = tecnico.adx(h, l, c)
        self.assertTrue(0 <= a <= 100)
        self.assertGreater(tecnico.obv_tendencia(list(range(1, 50)), [10] * 49), 0)
        self.assertAlmostEqual(tecnico.vwap([11] * 30, [9] * 30, [10] * 30, [5] * 30), 10.0)

    def test_dados_insuficientes_nao_inventam(self):
        r = tecnico.analisar(serie(10))
        self.assertIsNone(r["curto"])
        r = tecnico.analisar(serie(100))
        self.assertIsNone(r["longo"])

    def test_reamostragem_semanal(self):
        c = [("2024-01-0%d" % d, 1, 2, 0.5, 1, 1, 1) for d in range(1, 10)]
        self.assertLess(len(tecnico.reamostrar(c, "semana")), len(c))


class TestRisco(unittest.TestCase):
    def test_drawdown_e_var(self):
        self.assertAlmostEqual(risco.max_drawdown([100, 120, 60, 90]), -0.5)
        self.assertIsNone(risco.var_historico([0.01] * 10))
        self.assertLess(risco.var_historico([(-1) ** i * 0.02 for i in range(100)]), 0)

    def test_beta_do_proprio_indice_e_1(self):
        s = serie(300, lambda i: 100 * (1 + 0.001 * i + 0.02 * math.sin(i)))
        b, corr = risco.beta_correlacao(s, s)
        self.assertAlmostEqual(b, 1.0, places=6)

    def test_liquidez(self):
        s = serie(30)
        self.assertEqual(risco.liquidez(s)["dias_sem_negocio"], 0)


class TestValuation(unittest.TestCase):
    FUND = {"2022": {"receita": 100, "lucro_liquido": 10, "fcf": 8, "acoes": 10, "divida_liquida": 20, "ebitda": 20, "patrimonio": 50},
            "2023": {"receita": 110, "lucro_liquido": 11, "fcf": 9, "acoes": 10, "divida_liquida": 20, "ebitda": 22, "patrimonio": 55},
            "2024": {"receita": 121, "lucro_liquido": 12.1, "fcf": 10, "acoes": 10, "divida_liquida": 20, "ebitda": 24, "patrimonio": 60}}

    def test_cenarios_ordenados_e_veredito(self):
        a = valuation.avaliar(10.0, self.FUND)
        c = a["cenarios"]
        self.assertTrue(c["otimista"]["valor_justo"] > c["base"]["valor_justo"] > c["pessimista"]["valor_justo"])
        self.assertEqual(a["veredito"], "subavaliada")
        self.assertEqual(valuation.avaliar(100.0, self.FUND)["veredito"], "sobreavaliada")

    def test_sem_dados_e_impossivel(self):
        self.assertEqual(valuation.avaliar(10.0, {})["veredito"], "impossivel")
        self.assertIsNone(valuation.dcf(-5, 10, 0, 0.05, 0.1, 0.03))
        self.assertIsNone(valuation.dcf(5, 10, 0, 0.05, 0.03, 0.04))

    def test_armadilha_de_valor(self):
        f = {"2023": {"receita": 100, "lucro_liquido": 10, "fcf": 2, "acoes": 10, "divida_liquida": 20, "ebitda": 20},
             "2024": {"receita": 90, "lucro_liquido": 3, "fcf": -1, "acoes": 10, "divida_liquida": 90, "ebitda": 20}}
        a = valuation.avaliar(1.0, f)
        self.assertTrue(a["armadilha_valor"]["alerta"])
        self.assertTrue(a["armadilha_valor"]["motivos"])


class TestValidacao(unittest.TestCase):
    def test_candle_inconsistente_reduz_qualidade(self):
        ruim = serie(100)
        ruim[50] = ("2024-02-01", 100, 90, 110, 100, 1, 1)
        self.assertLess(validacao.validar_candles(ruim)["qualidade"], validacao.validar_candles(serie(100))["qualidade"])

    def test_desdobramento_detectado_e_ajustado(self):
        d = datas(120)
        s = [(d[i], 100.0, 101.0, 99.0, 100.0, 1.0, 1.0) for i in range(60)] + [(d[i], 50.0, 51.0, 49.0, 50.0, 1.0, 1.0) for i in range(60, 120)]
        v = validacao.validar_candles(s)
        self.assertTrue(any(x["provavel_evento"] == 2 for x in v["saltos"]))
        aj, ajustadas = validacao.ajustar_saltos(s)
        self.assertEqual(len(ajustadas), 1)
        self.assertAlmostEqual(aj[0][4], aj[-1][4], places=6)        # série contínua após o ajuste

    def test_desatualizado(self):
        v = validacao.validar_candles(serie(100), referencia="2030-01-01")
        self.assertTrue(any("desatualizados" in p for p in v["problemas"]))


def linha_cotahist(ticker="PETR4", data="20240102", bdi="02", mercado="010", preco=3250, vol=123456789, isin="BRPETRACNPR6"):
    f = lambda n, w: str(n).rjust(w, "0")
    l = ("01" + data + bdi + ticker.ljust(12) + mercado + "PETROBRAS".ljust(12) + "PN".ljust(10) + "   " + "R$  " + f(preco, 13) + f(preco + 50, 13) + f(preco - 50, 13)
         + f(preco, 13) + f(preco + 10, 13) + f(preco, 13) + f(preco, 13) + f(10, 5) + f(1000, 18) + f(vol, 18) + f(0, 13) + "0" + "00000000" + f(1, 7) + f(0, 13) + isin + "123")
    return l.ljust(245)


class TestCotahist(Base):
    def test_layout_posicoes(self):
        l = linha_cotahist()
        self.assertEqual(len(l), 245)
        r = b3_cotahist.parse_linha(l)
        self.assertEqual((r["data"], r["ticker"], r["tipo"], r["isin"]), ("2024-01-02", "PETR4", "acao_pref", "BRPETRACNPR6"))
        self.assertAlmostEqual(r["abertura"], 32.50)
        self.assertAlmostEqual(r["maximo"], 33.00)
        self.assertAlmostEqual(r["minimo"], 32.00)
        self.assertAlmostEqual(r["fechamento"], 32.60)          # PREULT (último preço), posições 109–121
        self.assertEqual(r["qtd"], 1000.0)
        self.assertAlmostEqual(r["volume_fin"], 1234567.89)

    def test_ignora_outros_registros_e_mercados(self):
        self.assertIsNone(b3_cotahist.parse_linha("00" + "x" * 243))
        self.assertIsNone(b3_cotahist.parse_linha(linha_cotahist(mercado="070")))   # opções
        self.assertIsNone(b3_cotahist.parse_linha(linha_cotahist(bdi="78")))
        self.assertIsNone(b3_cotahist.parse_linha(linha_cotahist(bdi="96")))  # fracionário não colide com lote padrão
        self.assertIsNone(b3_cotahist.parse_linha("curta"))

    def test_rejeita_data_impossivel_e_candle_inconsistente(self):
        self.assertIsNone(b3_cotahist.parse_linha(linha_cotahist(data="20240231")))
        linha = linha_cotahist(preco=3250)
        linha = linha[:69] + str(3000).rjust(13, "0") + linha[82:]
        self.assertIsNone(b3_cotahist.parse_linha(linha))

    def test_zip_sem_membro_cotahist_e_rejeitado(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("leia-me.txt", "arquivo sem cotações")
        with self.assertRaises(ValueError):
            list(b3_cotahist.ler_zip(buf.getvalue()))

    def test_zip_importacao_e_catalogo(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("COTAHIST_A2024.TXT", "00COTAHIST.2024\r\n" + linha_cotahist() + "\r\n" + linha_cotahist("VALE3", "20240102", isin="BRVALEACNOR0") + "\r\n99trailer\r\n")
        regs = list(b3_cotahist.ler_zip(buf.getvalue()))
        self.assertEqual(len(regs), 2)
        self.assertEqual(b3_cotahist.importar(regs), 2)
        self.assertEqual({i["ticker"] for i in catalogo.listar("REAL")}, {"PETR4", "VALE3"})
        self.assertEqual(dados.candles(catalogo.listar("REAL")[0]["id"])[0][0], "2024-01-02")

    def test_validacao_de_anos_da_coleta(self):
        self.assertEqual(b3_cotahist.validar_anos([2024, "2024", 2023]), [2024, 2023])
        for anos in ([], ["abc"], [date.today().year + 1], list(range(2000, 2011))):
            with self.subTest(anos=anos), self.assertRaises(ValueError):
                b3_cotahist.validar_anos(anos)

    def test_status_b3_distingue_dados_gravados_e_coleta_externa(self):
        self.assertEqual(b3_cotahist.status()["cotacoes"], 0)
        self.assertFalse(b3_cotahist.status()["download_real_comprovado"])
        b3_cotahist.importar([b3_cotahist.parse_linha(linha_cotahist())])
        st = api.GET["b3/status"]()
        self.assertEqual(st["cotacoes"], 1)
        self.assertEqual(st["instrumentos"], 1)
        self.assertEqual(st["primeira_data"], "2024-01-02")
        self.assertFalse(st["download_real_comprovado"])  # fixture não comprova download externo

    def test_acao_b3_nao_coleta_em_modo_demo(self):
        db.cfg_set("modo_demo", True)
        try:
            with self.assertRaises(PermissionError):
                api.acao("b3/coletar", {"anos": [2024]})
        finally:
            db.cfg_set("modo_demo", False)


class TestBaseConectores(unittest.TestCase):
    def test_download_rejeita_resposta_vazia(self):
        from unittest.mock import patch
        from io import BytesIO
        class Resposta(BytesIO):
            status = 200
            headers = {}
            def __enter__(self): return self
            def __exit__(self, *args): self.close()
        with patch("gfi.conectores.base.urllib.request.urlopen", return_value=Resposta(b"")):
            with self.assertRaises(ValueError):
                base.baixar("https://example.invalid/dados", intervalo=0)

    def test_download_rejeita_excesso_de_bytes(self):
        from unittest.mock import patch
        from io import BytesIO
        class Resposta(BytesIO):
            status = 200
            headers = {}
            def __enter__(self): return self
            def __exit__(self, *args): self.close()
        with patch("gfi.conectores.base.urllib.request.urlopen", return_value=Resposta(b"12345")):
            with self.assertRaises(ValueError):
                base.baixar("https://example.invalid/dados", limite_bytes=4, intervalo=0)


class TestBCB(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(bcb.parse_sgs('[{"data":"01/03/2024","valor":"10,75"},{"data":"x","valor":"1"},{"data":"02/03/2024","valor":"abc"}]'), [("2024-03-01", 10.75)])

    def test_parse_bytes_decimal_ptbr_e_datas_ordenadas(self):
        bruto = '[{"data":"02/03/2024","valor":"1.234,56"},{"data":"01/03/2024","valor":"10.5"},{"data":"02/03/2024","valor":"1234,56"}]'.encode()
        self.assertEqual(bcb.parse_sgs(bruto), [("2024-03-01", 10.5), ("2024-03-02", 1234.56)])

    def test_parse_rejeita_resposta_json_que_nao_seja_lista(self):
        with self.assertRaises(ValueError):
            bcb.parse_sgs('{"erro":"inválida"}')

    def test_parse_descarta_nan_e_data_impossivel(self):
        self.assertEqual(bcb.parse_sgs('[{"data":"31/02/2024","valor":"1"},{"data":"01/03/2024","valor":"NaN"}]'), [])


class TestCatalogo(Base):
    def test_mesmo_ticker_bolsas_diferentes(self):
        a, b = catalogo.upsert("ABC", "BVMF", "REAL"), catalogo.upsert("ABC", "XNYS", "REAL")
        self.assertNotEqual(a, b)

    def test_mudanca_de_ticker_por_isin(self):
        catalogo.upsert("OLD3", "BVMF", "REAL", isin="BRXXXXXXXX01")
        catalogo.upsert("NEW3", "BVMF", "REAL", isin="BRXXXXXXXX01")
        self.assertEqual(db.um("SELECT status FROM instrumentos WHERE ticker='OLD3'")["status"], "substituido")
        self.assertEqual(db.um("SELECT status FROM instrumentos WHERE ticker='NEW3'")["status"], "ativo")

    def test_status_e_cobertura(self):
        a, b = catalogo.upsert("VIVO3", "BVMF", "REAL"), catalogo.upsert("MORTO3", "BVMF", "REAL")
        db.muitos("INSERT OR REPLACE INTO cotacoes VALUES(?,?,?,?,?,?,?,?,?,?)", [(a, f"2024-06-{d:02d}", 1, 2, 1, 1, 1, 1, "t", 0) for d in range(1, 29)]
                  + [(b, "2023-01-02", 1, 2, 1, 1, 1, 1, "t", 0)])
        catalogo.atualizar_status("REAL")
        self.assertEqual(db.um("SELECT status FROM instrumentos WHERE ticker='MORTO3'")["status"], "deslistado")
        self.assertEqual(db.um("SELECT status FROM instrumentos WHERE ticker='VIVO3'")["status"], "ativo")
        self.assertGreaterEqual(catalogo.cobertura("REAL")["deslistados"], 1)


class TestSimulado(Base):
    demo = True

    def test_tudo_marcado_como_simulado_e_isolado(self):
        todos = db.consultar("SELECT * FROM instrumentos")
        self.assertTrue(all(i["origem"] == "SIMULADO" and i["mic"] == "SIMU" for i in todos))
        self.assertTrue(all(i["ticker"].startswith("DEMO") for i in todos))
        self.assertEqual(catalogo.listar("REAL"), [])

    def test_futuro_escondido_e_revelado_por_etapas(self):
        escondidos = db.um("SELECT COUNT(DISTINCT data) n FROM demo_futuro")["n"]
        ultima = db.um("SELECT MAX(data) d FROM cotacoes")["d"]
        self.assertGreater(escondidos, 0)
        self.assertGreater(db.um("SELECT MIN(data) d FROM demo_futuro")["d"], ultima)       # nada do futuro está visível
        novo = simulado.avancar(2)
        self.assertGreater(novo, ultima)


class TestPontuacao(Base):
    demo = True

    def test_invariantes_para_todos_os_ativos(self):
        rs = pipeline.ultimas()
        self.assertGreater(len(rs), 30)
        for r in rs:
            self.assertEqual(sum(r["contagem"].values()), 15)
            for k, d in r["dimensoes"].items():
                if d["score"] is None:
                    self.assertEqual(d["luz"], "cinza", k)          # ausência de dado NUNCA é verde
            if r["indice"] is not None:
                self.assertTrue(0 <= r["indice"] <= 100)
            if r["bloqueado"]:
                self.assertLessEqual(r["indice"] or 0, config.LIMITE_COM_BLOQUEIO)
                self.assertEqual(r["luz"], "vermelho")
            for k in ("1_por_que", "2_positivos", "3_negativos", "4_acontecimentos", "5_fontes", "6_atualizacao", "7_melhorar", "8_piorar", "9_riscos", "10_faltando", "separacao"):
                self.assertIn(k, r["respostas"])

    def test_fraude_bloqueia_apesar_de_sinais_verdes(self):
        r = next(x for x in pipeline.ultimas() if x["inst"]["ticker"] == "DEMO08")
        self.assertTrue(r["bloqueado"])
        self.assertTrue(any("fraude" in b for b in r["bloqueios"]))

    def test_composicao_soma_o_indice_antes_das_penalizacoes(self):
        livres = [x for x in pipeline.ultimas() if x["indice"] is not None and not x["bloqueado"] and not any("limitado" in p for p in x["penalizacoes"])]
        self.assertTrue(livres)
        for r in livres:
            soma = sum(c["contribuicao"] for c in r["composicao"] if c["contribuicao"] is not None)
            self.assertAlmostEqual(soma * (0.6 + 0.4 * r["cobertura"]), r["indice"], delta=0.2)      # índice = soma explicada × fator de cobertura

    def test_indicador_isolado_nao_vira_verde(self):
        ctx = {"analise": {"curto": 95, "medio": 40, "longo": None, "indicadores": {}}, "fonte_precos": "x", "ultima_data": "2024-01-01"}
        d = pontuacao.d_tecnica(ctx)
        self.assertLess(d["score"], config.LIMIARES["verde"])
        ctx["analise"].update(curto=80, medio=70, longo=65)
        self.assertEqual(pontuacao.d_tecnica(ctx)["luz"], "verde")

    def test_sem_dados_suficientes_nao_calcula_indice(self):
        ctx = {"inst": {"tipo": "acao_on"}, "eventos": [], "risco": {"liquidez": None, "vol_anual": None, "max_drawdown": None, "var95": None, "beta": None}, "validacao": {"qualidade": 1.0, "problemas": []},
               "analise": {"indicadores": {}}, "candles": [], "fund": {}, "macro": {}, "valuation": {"veredito": "impossivel", "armadilha_valor": {"alerta": False, "motivos": []}, "multiplos": {}},
               "fonte_precos": "x", "fonte_fund": "x", "ultima_data": "2024-01-01"}
        r = pontuacao.calcular(ctx)
        self.assertIsNone(r["indice"])
        self.assertEqual(r["luz"], "cinza")

    def test_pesos_por_tipo(self):
        self.assertEqual(pontuacao.pesos_efetivos("etf")["saude"], 0)
        self.assertGreater(pontuacao.pesos_efetivos("acao_on")["saude"], 0)

    def test_reconstrucao_em_data_passada_nao_usa_o_futuro(self):
        alvo = db.consultar("SELECT DISTINCT data FROM cotacoes ORDER BY data DESC LIMIT 1 OFFSET 30")[0]["data"]
        inst = next(i for i in catalogo.listar() if i["tipo"] != "indice")
        ctx = pipeline.contexto(inst, "SIMULADO", alvo, alvo, None, {}, {}, defasado=True)
        self.assertLessEqual(ctx["candles"][-1][0], alvo)
        self.assertTrue(all(p[:4] < alvo[:4] for p in ctx["fund"]))     # balanço do ano corrente ainda não existe


class TestPrevisoes(Base):
    demo = True

    def test_cadeia_integra_e_imutavel(self):
        ok, _ = previsoes.verificar_cadeia()
        self.assertTrue(ok)
        with self.assertRaises(Exception):
            db.executar("UPDATE previsoes SET direcao='alta' WHERE id=1")
        with self.assertRaises(Exception):
            db.executar("DELETE FROM previsoes")

    def test_nao_duplica_mesma_previsao(self):
        antes = db.um("SELECT COUNT(*) n FROM previsoes")["n"]
        pipeline.recalcular(todos=True)
        self.assertEqual(db.um("SELECT COUNT(*) n FROM previsoes")["n"], antes)

    def test_adulteracao_e_detectada(self):
        original = db.um("SELECT base_preco FROM previsoes WHERE id=3")["base_preco"]
        try:
            with db.conectar() as con:                       # só o dono do banco, fora da IA, conseguiria isto
                con.execute("DROP TRIGGER previsoes_sem_update")
                con.execute("UPDATE previsoes SET base_preco=base_preco*2 WHERE id=3")
            ok, quebrado = previsoes.verificar_cadeia()
            self.assertFalse(ok)
            self.assertEqual(quebrado, 3)
        finally:                                              # restaura para não contaminar os outros testes
            with db.conectar() as con:
                con.execute("DROP TRIGGER IF EXISTS previsoes_sem_update")
                con.execute("UPDATE previsoes SET base_preco=? WHERE id=3", (original,))
            with db.conectar() as con:
                con.executescript(db.SCHEMA)
        self.assertTrue(previsoes.verificar_cadeia()[0])

    def test_avaliacao_so_com_dados_posteriores(self):
        self.assertEqual(previsoes.avaliar_vencidas() >= 0, True)
        m = previsoes.metricas()
        self.assertIn("evidencia", m)


class TestAvaliacaoFutura(Base):
    demo = True

    def test_avancar_tempo_avalia_previsoes_sem_olhar_o_futuro(self):
        self.assertEqual(previsoes.metricas()["avaliadas"], 0)
        simulado.avancar(25)
        pipeline.recalcular(todos=True)
        m = previsoes.metricas()
        self.assertGreater(m["avaliadas"], 30)
        self.assertIn(m["evidencia"].split(" ")[0], ("SEM", "há", "insuficiente"))
        self.assertTrue(previsoes.verificar_cadeia()[0])


class TestBacktest(Base):
    demo = True

    def test_backtest_rodando_sem_gravar_previsoes(self):
        antes = db.um("SELECT COUNT(*) n FROM previsoes")["n"]
        r = backtest.executar(rebalanceamentos=6, sorteios=100)
        self.assertNotIn("erro", r)
        self.assertEqual(db.um("SELECT COUNT(*) n FROM previsoes")["n"], antes)       # nunca altera o registro imutável
        self.assertTrue(all("aleatorias" not in p for p in r["periodos"]))
        self.assertIn("DEMONSTRAÇÃO", " ".join(r["limitacoes"]))
        self.assertTrue(0 <= r["prob_ser_acaso"] <= 1)

    def test_historico_curto_e_recusado(self):
        with mock.patch.object(config, "MIN_CANDLES", 10_000):
            self.assertIn("erro", backtest.executar())


class TestAlertas(Base):
    def test_sem_repeticao_e_nivel_minimo(self):
        iid = catalogo.upsert("ALR3", "BVMF", "REAL")
        self.assertTrue(alertas.emitir(iid, "pontuacao", "critico", "caiu"))
        self.assertFalse(alertas.emitir(iid, "pontuacao", "critico", "caiu de novo"))       # cooldown
        self.assertFalse(alertas.emitir(iid, "outro", "info", "irrelevante"))               # abaixo do nível mínimo
        self.assertEqual(len(alertas.listar()), 1)


class TestOportunidades(Base):
    demo = True

    def test_nao_ordena_por_sinais_verdes_e_exclui_bloqueados(self):
        r = oportunidades.ranking("geral", 100)
        valores = [i["valor"] for i in r["itens"]]
        self.assertEqual(valores, sorted(valores, reverse=True))
        self.assertFalse({"DEMO08", "DEMO09"} & {i["ticker"] for i in r["itens"]})           # bloqueados fora
        self.assertTrue(all(i["por_que"] for i in r["itens"]))

    def test_todos_os_rankings_e_filtros(self):
        for k in oportunidades.RANKINGS:
            r = oportunidades.ranking(k, 20)
            self.assertLessEqual(len(r["itens"]), 20)
        r = oportunidades.ranking("geral", 100, {"setor": "Financeiro"})
        self.assertTrue(all(i["setor"] == "Financeiro" for i in r["itens"]))
        self.assertEqual(oportunidades.ranking("geral", 100, {"qualidade_min": 2})["itens"], [])


class TestEvolucao(Base):
    demo = True

    def test_arquivos_protegidos_e_fora_do_laboratorio_sao_rejeitados(self):
        for arq in ("gfi/db.py", "servidor.py", "gfi/evolucao.py", "../../etc/passwd", "/etc/passwd", "gfi/pontuacao_nova.py"):
            self.assertEqual(evolucao.obter(evolucao.criar("x", "x", "ia", arquivos=[arq]))["estado"], "rejeitada", arq)
        self.assertEqual(evolucao.obter(evolucao.criar("x", "x", "ia", mudanca={"config": {"a": 1}}))["estado"], "rejeitada")

    def test_ia_nao_publica_sozinha(self):
        pid = evolucao.criar("pesos", "d", "ia", mudanca={"pesos": {"tecnica": 6}})
        self.assertTrue(evolucao.testar(pid)["ok"])
        for _ in range(10):
            try:
                evolucao.avancar(pid)
            except PermissionError:
                break
        self.assertEqual(evolucao.obter(pid)["estado"], "aprovacao")
        for conf, quem in (("sim", "usuario"), ("APROVO", "ia")):
            with self.assertRaises(PermissionError):
                evolucao.aprovar(pid, conf, quem)
        self.assertEqual(db.cfg_get("pesos", {}), {})

    def test_aprovacao_aplica_e_reverte(self):
        pid = evolucao.criar("pesos", "d", "ia", mudanca={"pesos": {"tecnica": 6, "risco": 13}})
        evolucao.testar(pid)
        while evolucao.obter(pid)["estado"] != "aprovacao":
            evolucao.avancar(pid)
        evolucao.aprovar(pid, "APROVO", "usuario")
        self.assertEqual(db.cfg_get("pesos")["tecnica"], 6.0)
        evolucao.reverter(pid)
        self.assertEqual(db.cfg_get("pesos"), {})

    def test_pesos_concentrados_reprovam_nos_testes(self):
        pid = evolucao.criar("tudo no risco", "d", "ia", mudanca={"pesos": {"risco": 500}})
        self.assertFalse(evolucao.testar(pid)["ok"])
        with self.assertRaises(ValueError):
            evolucao.avancar(pid); evolucao.avancar(pid); evolucao.avancar(pid); evolucao.avancar(pid)

    def test_fila_de_pesquisa_sem_repeticao(self):
        self.assertTrue(pesquisa.enfileirar("k1", "t", "m", relev=1, urg=1, imp=1))
        self.assertFalse(pesquisa.enfileirar("k1", "t", "m"))
        self.assertGreater(pesquisa.prioridade(1, 1, 1, 1, 0), pesquisa.prioridade(0.2, 0.2, 0.2, 0.2, 1))

    def test_autoavaliacao_relatorio(self):
        self.assertTrue(autoavaliacao.relatorio()["cadeia_integra"])


def pacote(base, nome, manifesto=None, arquivos=None):
    p = Path(base) / nome
    p.mkdir(parents=True)
    (p / "atualizacao.json").write_text(json.dumps(manifesto if manifesto is not None else {"id": nome, "nome": nome, "versao": "1.0.0"}))
    for rel, txt in (arquivos or {}).items():
        (p / rel).parent.mkdir(parents=True, exist_ok=True)
        (p / rel).write_text(txt, encoding="utf-8")
    return p


CODIGO_OK = ("def f(candles):\n    return len(candles)\n\ndef v(r):\n    return r['indice']\n\ndef w(r):\n    return 'x'\n\n"
             "def registrar(api):\n    api.indicador('n', f)\n    api.ranking('r', 'Teste', v, w)\n")


class TestAtualizacoes(Base):
    def setUp(self):
        for p in atualizacoes.DIR.iterdir():
            import shutil
            shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink()
        db.cfg_set("atualizacoes", {})

    def tearDown(self):
        for pid in list(atualizacoes._REG):
            atualizacoes._descarregar(pid)

    def estado(self, pid):
        return next(p for p in atualizacoes.listar() if p["id"] == pid)

    def test_validacoes_de_pacote(self):
        pacote(atualizacoes.DIR, "vazio-ok")
        self.assertIn("pacote vazio", " ".join(self.estado("vazio-ok")["erros"]))
        pacote(atualizacoes.DIR, "id-ruim", {"id": "Maiúsculo!", "nome": "x", "versao": "1"}, {"codigo.py": CODIGO_OK})
        self.assertTrue(any("id inválido" in e for p in atualizacoes.listar() for e in p["erros"]))
        for trecho in ("import os", "import subprocess", "from sys import path", "x = open('a')", "eval('1')", "y = f.__class__", "while True:\n    pass"):
            pacote(atualizacoes.DIR, "mau-" + str(abs(hash(trecho)) % 9999), None, {"codigo.py": trecho + "\ndef registrar(api):\n    pass\n"})
        maus = [p for p in atualizacoes.listar() if p["id"].startswith("mau-")]
        self.assertEqual(len(maus), 7)
        self.assertTrue(all(p["erros"] for p in maus))

    def test_exige_confirmacao_e_modo_seguro(self):
        pacote(atualizacoes.DIR, "pkg-codigo", None, {"codigo.py": CODIGO_OK})
        with self.assertRaises(PermissionError):
            atualizacoes.ativar("pkg-codigo", False)
        (atualizacoes.DIR / "DESLIGADO").write_text("")
        with self.assertRaises(PermissionError):
            atualizacoes.ativar("pkg-codigo", True)
        self.assertTrue(atualizacoes.carregar_ativas()["modo_seguro"])

    def test_codigo_registra_e_desativa(self):
        pacote(atualizacoes.DIR, "pkg-codigo", None, {"codigo.py": CODIGO_OK})
        self.assertEqual(self.estado("pkg-codigo")["estado"], "nova")
        atualizacoes.ativar("pkg-codigo", True)
        self.assertEqual(self.estado("pkg-codigo")["estado"], "ativa")
        self.assertEqual(atualizacoes.executar_indicadores(serie(5)), {"n": 5.0})
        self.assertIn("x_pkg-codigo_r", oportunidades.RANKINGS)
        atualizacoes.desativar("pkg-codigo")
        self.assertEqual(atualizacoes.executar_indicadores(serie(5)), {})
        self.assertNotIn("x_pkg-codigo_r", oportunidades.RANKINGS)

    def test_alteracao_do_pacote_desativa_ate_reaprovar(self):
        p = pacote(atualizacoes.DIR, "pkg-codigo", None, {"codigo.py": CODIGO_OK})
        atualizacoes.ativar("pkg-codigo", True)
        (p / "codigo.py").write_text(CODIGO_OK + "\n# alterado\n")
        self.assertEqual(self.estado("pkg-codigo")["estado"], "alterada")
        atualizacoes._descarregar("pkg-codigo")
        self.assertEqual(atualizacoes.carregar_ativas()["carregadas"], [])         # não carrega versão não aprovada

    def test_plugin_com_erro_nao_derruba_a_ia(self):
        ruim = "def f(c):\n    return 1 / 0\n\ndef registrar(api):\n    api.indicador('boom', f)\n"
        pacote(atualizacoes.DIR, "pkg-ruim", None, {"codigo.py": ruim})
        atualizacoes.ativar("pkg-ruim", True)
        self.assertEqual(atualizacoes.executar_indicadores(serie(5)), {})

    def test_dados_csv_so_vao_para_o_universo_real(self):
        catalogo.upsert("PETR4", "BVMF", "REAL")
        pacote(atualizacoes.DIR, "pkg-dados", None, {"dados/setores.csv": 'ticker,setor\nPETR4,"Petróleo, Gás e Biocombustíveis"\nXXXX3,Financeiro\nPETR4,Setor Inventado\n',
                                                      "dados/fundamentos.csv": "ticker,periodo,campo,valor\nPETR4,2023,receita,100\nPETR4,2023,campo_falso,1\nNAOEXISTE3,2023,receita,5\n",
                                                      "dados/eventos.csv": "ticker,setor,pais,categoria,tipo,severidade,impacto,titulo,fonte,publicado_em,confiabilidade\n,Financeiro,BR,regulatorio,geral,3,-1,Teste,CVM,2024-05-01,alta\n,Financeiro,BR,categoria_x,geral,3,-1,Ruim,CVM,2024-05-01,alta\n"})
        r = atualizacoes.ativar("pkg-dados", True)["resumo"]["dados"]
        self.assertEqual(r["setores"]["aplicados"], 1)
        self.assertEqual(r["fundamentos"], {"aplicados": 1, "ignorados": 2})
        self.assertEqual(r["eventos"], {"aplicados": 1, "ignorados": 1})
        self.assertEqual(db.um("SELECT setor FROM instrumentos WHERE ticker='PETR4'")["setor"], "Petróleo, Gás e Biocombustíveis")
        atualizacoes.desativar("pkg-dados", remover_dados=True)
        self.assertEqual(db.um("SELECT COUNT(*) n FROM fundamentos WHERE origem='ATU:pkg-dados'")["n"], 0)
        self.assertEqual(db.um("SELECT COUNT(*) n FROM eventos WHERE pacote='pkg-dados'")["n"], 0)

    def test_config_de_pesos_e_reversivel(self):
        pacote(atualizacoes.DIR, "pkg-cfg", None, {"config.json": json.dumps({"pesos": {"tecnica": 3, "nao_existe": 9}})})
        atualizacoes.ativar("pkg-cfg", True)
        self.assertEqual(db.cfg_get("pesos"), {"tecnica": 3})
        atualizacoes.desativar("pkg-cfg")
        self.assertEqual(db.cfg_get("pesos"), {})

    def test_zip_com_caminho_perigoso_e_recusado_e_zip_valido_e_extraido(self):
        with zipfile.ZipFile(atualizacoes.DIR / "ruim.zip", "w") as z:
            z.writestr("../../fora.txt", "x")
        with zipfile.ZipFile(atualizacoes.DIR / "bom.zip", "w") as z:
            z.writestr("bom/atualizacao.json", json.dumps({"id": "zip-bom", "nome": "Zip", "versao": "1"}))
            z.writestr("bom/config.json", json.dumps({"pesos": {"risco": 5}}))
        ids = [p["id"] for p in atualizacoes.listar()]
        self.assertIn("zip-bom", ids)
        self.assertFalse((atualizacoes.DIR.parent / "fora.txt").exists())

    def test_conector_so_acessa_hosts_declarados(self):
        cod = "def c(api):\n    return api.baixar('https://evil.com/x')\n\ndef registrar(api):\n    api.conector('c', c)\n"
        pacote(atualizacoes.DIR, "pkg-con", {"id": "pkg-con", "nome": "c", "versao": "1", "rede": ["ok.example.com"]}, {"codigo.py": cod})
        atualizacoes.ativar("pkg-con", True)
        with self.assertRaises(PermissionError):
            atualizacoes.executar_conector("pkg-con:c")

    def test_modelos_entregues_sao_validos(self):
        modelos = Path(__file__).resolve().parent.parent / "atualizacoes" / "_modelos"
        for d in modelos.iterdir():
            self.assertEqual(atualizacoes._ler_pacote(d)["erros"], [], d.name)


class TestRecursos(Base):
    def test_modos_e_reducao_de_carga(self):
        self.assertEqual(recursos.modo_atual(), config.MODO_PADRAO)
        db.cfg_set("modo", "economico")
        normal = config.MODOS["economico"]["lote"]
        with mock.patch.object(recursos, "medir", return_value={"cpu": 99, "ram": 10, "disco": 1, "nucleos": 2, "ts": 0}):
            self.assertTrue(recursos.sob_pressao())
            self.assertLess(recursos.lote_efetivo(), normal)
        with mock.patch.object(recursos, "medir", return_value={"cpu": 5, "ram": 10, "disco": 1, "nucleos": 2, "ts": 0}):
            self.assertEqual(recursos.lote_efetivo(), normal)
        db.cfg_set("modo", "invalido")
        self.assertEqual(recursos.modo_atual(), config.MODO_PADRAO)


class TestServidor(Base):
    demo = True

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        import servidor
        cls.srv_mod = servidor
        porta = 18789
        cls._pp = mock.patch.object(servidor, "HOSTS", {f"127.0.0.1:{porta}"})
        cls._pp.start()
        cls.srv = ThreadingHTTPServer(("127.0.0.1", porta), servidor.Handler)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.porta = porta

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        cls._pp.stop()
        super().tearDownClass()

    def req(self, m, p, corpo=None, h=None):
        c = HTTPConnection("127.0.0.1", self.porta, timeout=60)
        hd = {"Host": f"127.0.0.1:{self.porta}", **(h or {})}
        c.request(m, p, body=corpo, headers=hd)
        r = c.getresponse()
        return r.status, r.read(), dict(r.getheaders())

    def test_seguranca_basica(self):
        self.assertEqual(self.req("GET", "/api/saude", h={"Host": "evil.com"})[0], 403)             # DNS rebinding
        self.assertEqual(self.req("POST", "/api/modo", "{}")[0], 403)                                # sem X-GFI
        self.assertEqual(self.req("POST", "/api/modo", "{}", {"X-GFI": "1", "Origin": "http://evil.com"})[0], 403)
        for p in ("/../servidor.py", "/%2e%2e/servidor.py", "/../gfi/db.py", "/app.py", "/../dados/gfi.db"):
            self.assertEqual(self.req("GET", p)[0], 404, p)
        _, _, h = self.req("GET", "/")
        self.assertIn("frame-ancestors 'none'", h["Content-Security-Policy"])

    def test_painel_e_todas_as_rotas(self):
        s, corpo, h = self.req("GET", "/")
        self.assertEqual(s, 200)
        self.assertIn(b"GLOBAL FINANCIAL INTELLIGENCE", corpo)
        for r in ("saude", "visao", "mercados", "radar", "ranking", "macro", "noticias", "riscos", "previsoes", "autoavaliacao", "evolucao", "atualizacoes", "alertas", "config", "backtest", "indicadores/2", "ativo/2"):
            s, c, _ = self.req("GET", "/api/" + r)
            self.assertEqual(s, 200, r)
            json.loads(c)
        self.assertEqual(self.req("GET", "/api/ranking?tipo_ranking=xx")[0], 400)
        self.assertEqual(self.req("GET", "/api/ativo/999999")[0], 404)
        self.assertEqual(self.req("GET", "/api/nao-existe")[0], 404)

    def test_aprovacao_exige_confirmacao_pela_api(self):
        pid = evolucao.criar("p", "d", "ia", mudanca={"pesos": {"tecnica": 6}})
        h = {"X-GFI": "1", "Content-Type": "application/json"}
        self.assertEqual(self.req("POST", "/api/evolucao/aprovar", json.dumps({"id": pid, "confirmacao": "sim"}), h)[0], 400 if False else 403)
        s, _, _ = self.req("POST", "/api/atualizacoes/ativar", json.dumps({"id": "inexistente", "confirmo": True}), h)
        self.assertEqual(s, 400)


if __name__ == "__main__":
    unittest.main()
