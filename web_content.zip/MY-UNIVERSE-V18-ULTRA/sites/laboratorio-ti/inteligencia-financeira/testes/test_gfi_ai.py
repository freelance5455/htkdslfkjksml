import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from gfi import ia_evolucao, api


class TestGFIAI(unittest.TestCase):
    def test_rota_api_chat_encaminha_mensagem(self):
        esperado = {"resposta": "ok", "modo": "local_diagnostico"}
        with patch.object(ia_evolucao, "conversar", return_value=esperado) as conversar:
            resultado = api.acao("gfi-ai/chat", {"mensagem": "teste de rota"})
        conversar.assert_called_once_with("teste de rota")
        self.assertEqual(resultado, esperado)

    def test_chat_local_responde_sem_fingir_llm(self):
        with patch.object(ia_evolucao, "_provedor_ativo", return_value=(None, {"detalhe": "modelo offline"})), \
             patch.object(ia_evolucao, "_diagnostico", return_value={"arquivos_python": 12, "testes": ["a.py"]}):
            r = ia_evolucao.conversar("Como está a GFI?")
        self.assertEqual(r["modo"], "local_diagnostico")
        self.assertIn("modelo generativo", r["resposta"])
        self.assertIn("12 arquivos Python", r["resposta"])

    def test_chat_usa_modelo_real_quando_conectado(self):
        prov = {"tipo": "openai", "origem": "modelo de teste"}
        with patch.object(ia_evolucao, "_provedor_ativo", return_value=(prov, {"status": "conectado"})), \
             patch.object(ia_evolucao, "_consultar_modelo", return_value="Resposta do modelo"):
            r = ia_evolucao.conversar("Explique a GFI")
        self.assertEqual(r["modo"], "llm")
        self.assertEqual(r["resposta"], "Resposta do modelo")

    def test_codigo_python_extraido(self):
        texto = "Sugestão:\n```python\ndef soma(a, b):\n    return a + b\n```"
        self.assertIn("def soma", ia_evolucao._codigo(texto))

    def test_url_publica_exige_https_e_host_publico(self):
        self.assertTrue(ia_evolucao._url_publica("https://example.org/docs"))
        self.assertFalse(ia_evolucao._url_publica("http://example.org/docs"))
        self.assertFalse(ia_evolucao._url_publica("https://127.0.0.1/admin"))
        self.assertFalse(ia_evolucao._url_publica("https://localhost/admin"))

    def test_codigo_ausente(self):
        self.assertEqual(ia_evolucao._codigo("Sem código."), "")

    def test_intervalo_invalido_rejeitado(self):
        with tempfile.TemporaryDirectory() as t:
            with patch.object(ia_evolucao, "BASE", Path(t)):
                with self.assertRaises(ValueError):
                    ia_evolucao.configurar(intervalo_horas=0)
                with self.assertRaises(ValueError):
                    ia_evolucao.configurar(intervalo_horas=169)

    def test_autonomia_nivel_tres_e_limites_explicitos(self):
        with tempfile.TemporaryDirectory() as t:
            with patch.object(ia_evolucao, "BASE", Path(t)):
                e = ia_evolucao.estado()
                self.assertEqual(e["autonomia"], 3)
                self.assertTrue(any("não executa código" in x for x in e["limites"]))
                self.assertTrue(any("não altera" in x for x in e["limites"]))

    def test_ciclo_gera_relatorio_e_codigo_no_laboratorio(self):
        with tempfile.TemporaryDirectory() as t:
            raiz = Path(t)
            resposta = "Análise\n```python\ndef melhoria():\n    return True\n```"
            with patch.object(ia_evolucao.config, "RAIZ", raiz), \
                 patch.object(ia_evolucao, "BASE", raiz / "dados"), \
                 patch.object(ia_evolucao, "RELATORIOS", raiz / "dados" / "relatorios"), \
                 patch.object(ia_evolucao, "PROPOSTAS", raiz / "laboratorio" / "propostas"), \
                 patch.object(ia_evolucao, "_pesquisar", return_value=[{"titulo": "Docs", "url": "https://example.org/docs"}]), \
                 patch.object(ia_evolucao, "_consultar_modelo", return_value=resposta), \
                 patch.object(ia_evolucao.db, "log"):
                item = ia_evolucao.executar_ciclo()
                self.assertEqual(item["validacao_sintaxe"], "válida")
                self.assertTrue((raiz / item["arquivo"]).is_file())
                self.assertTrue((raiz / item["codigo"]).is_file())


    def test_estado_nao_finge_modelo_ou_internet_disponiveis(self):
        with tempfile.TemporaryDirectory() as t:
            with patch.object(ia_evolucao, "BASE", Path(t)), \
                 patch.object(ia_evolucao, "_diagnostico_modelo", return_value={"modelo": "sem_modelo_configurado", "status": "nexus_local_indisponivel", "detalhe": "sem servidor"}):
                e = ia_evolucao.estado()
                self.assertEqual(e["modelo"], "sem_modelo_configurado")
                self.assertEqual(e["modelo_status"]["status"], "nexus_local_indisponivel")
                self.assertEqual(e["pesquisa_web"], "ainda_nao_testada")

    def test_descobre_ollama_local_sem_configuracao_manual(self):
        resposta = {"models": [{"name": "qwen2.5:7b"}]}
        with patch("nexus.llm.disponivel", return_value=False), \
             patch.object(ia_evolucao, "_get_json", return_value=resposta):
            prov, diag = ia_evolucao._detectar_provedor()
        self.assertEqual(prov["tipo"], "ollama")
        self.assertEqual(prov["modelo"], "qwen2.5:7b")
        self.assertEqual(diag["status"], "conectado")

    def test_nao_detecta_modelo_sem_resposta_real(self):
        with patch.object(ia_evolucao, "_get_json", side_effect=OSError("offline")), \
             patch("nexus.llm.disponivel", return_value=False):
            prov, diag = ia_evolucao._detectar_provedor()
        self.assertIsNone(prov)
        self.assertEqual(diag["status"], "nenhum_provedor_local")

    def test_endpoint_externo_exige_https(self):
        with patch.dict("os.environ", {"GFI_AI_LLM_URL": "http://modelo.example.com/v1/chat/completions"}, clear=True):
            d = ia_evolucao._diagnostico_modelo()
            self.assertEqual(d["status"], "url_insegura")

    def test_configuracao_pausa_agente(self):
        with tempfile.TemporaryDirectory() as t:
            with patch.object(ia_evolucao, "BASE", Path(t)):
                e = ia_evolucao.configurar(ativo=False, intervalo_horas=12)
                self.assertFalse(e["ativo"])
                self.assertEqual(e["intervalo_horas"], 12)

    def test_descoberta_local_inclui_ollama_lmstudio_e_llamacpp(self):
        candidatos = ia_evolucao._candidatos_modelo()
        urls = [x["url"] for x in candidatos]
        self.assertTrue(any(":8080/" in u for u in urls))
        self.assertTrue(any(":1234/" in u for u in urls))
        self.assertTrue(any(":11434/" in u and "/api/chat" in u for u in urls))

    def test_ollama_native_resposta(self):
        class FakeResponse:
            def __enter__(self): return self
            def __exit__(self, *a): pass
            def read(self, *_): return b'{"message":{"content":"Analise GFI"}}'
        candidato = {"tipo":"ollama", "url":"http://127.0.0.1:11434/api/chat", "modelo":"qwen2.5", "origem":"Ollama nativo"}
        with patch.object(ia_evolucao, "_provedor_ativo", return_value=(candidato, {"status":"conectado"})), \
             patch.object(ia_evolucao.urllib.request, "urlopen", return_value=FakeResponse()):
            self.assertEqual(ia_evolucao._consultar_modelo("analise"), "Analise GFI")

    def test_modelo_nao_conectado_nao_finge_disponibilidade(self):
        with patch.object(ia_evolucao, "_provedor_ativo", return_value=(None, {"modelo":"sem_modelo_configurado", "status":"nenhum_servidor_local", "detalhe":"offline"})):
            self.assertIsNone(ia_evolucao._consultar_modelo("teste"))


if __name__ == "__main__":
    unittest.main()
