"""Regressão V7: acesso local/rede protegido por token e validação de Host."""
import tempfile
import threading
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock

from gfi import acesso, config


class TestAcessoV7(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import servidor
        cls.servidor = servidor
        cls.tmp = tempfile.TemporaryDirectory()
        cls.p_dados = mock.patch.object(config, "DADOS", Path(cls.tmp.name) / "dados")
        cls.p_porta = mock.patch.object(config, "PORTA", 18790)
        cls.p_hosts = mock.patch.object(servidor, "HOSTS", {"127.0.0.1:18790", "localhost:18790"})
        cls.p_dados.start()
        cls.p_porta.start()
        cls.p_hosts.start()
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 18790), servidor.Handler)
        cls.thread = threading.Thread(target=cls.srv.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        cls.p_hosts.stop()
        cls.p_porta.stop()
        cls.p_dados.stop()
        cls.tmp.cleanup()

    def req(self, method, path, body=None, headers=None):
        c = HTTPConnection("127.0.0.1", 18790, timeout=10)
        h = {"Host": "127.0.0.1:18790", **(headers or {})}
        c.request(method, path, body=body, headers=h)
        r = c.getresponse()
        return r.status, r.read(), dict(r.getheaders())

    def test_token_persistente_e_comparacao_segura(self):
        t = acesso.token()
        self.assertGreaterEqual(len(t), 20)
        self.assertEqual(t, acesso.token())
        self.assertTrue(acesso.token_valido(t))
        self.assertFalse(acesso.token_valido("incorreto"))
        self.assertFalse(acesso.token_valido(""))

    def test_host_nao_permitido_e_bloqueado(self):
        status, _, _ = self.req("GET", "/api/saude", headers={"Host": "evil.example:18790"})
        self.assertEqual(status, 403)

    def test_cliente_de_rede_sem_token_e_bloqueado(self):
        with mock.patch.object(acesso, "cliente_local", return_value=False):
            self.assertEqual(self.req("GET", "/api/saude")[0], 401)
            self.assertEqual(self.req("POST", "/api/modo", "{}", {"X-GFI": "1"})[0], 401)

    def test_token_vira_cookie_e_libera_painel_e_api(self):
        with mock.patch.object(acesso, "cliente_local", return_value=False):
            status, _, headers = self.req("GET", "/?token=" + acesso.token())
            self.assertEqual(status, 303)
            cookie = headers["Set-Cookie"].split(";", 1)[0]
            self.assertIn("HttpOnly", headers["Set-Cookie"])
            self.assertEqual(self.req("GET", "/api/saude", headers={"Cookie": cookie})[0], 200)
            status, _, _ = self.req("POST", "/api/modo", '{"modo":"normal"}',
                                    {"X-GFI": "1", "Cookie": cookie})
            self.assertEqual(status, 200)


if __name__ == "__main__":
    unittest.main()
