"""Testes da V2: armazenamento intradiário sem provedor ou dados inventados."""
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from gfi import config, live


class TestLiveStorage(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = mock.patch.object(config, "DADOS", Path(self.tmp.name) / "dados")
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_registra_snapshot_com_proveniencia(self):
        r = live.registrar(1, "PROVEDOR-TESTE", "2026-11-20T14:30:00-03:00", 32.5,
                           volume=1000, estado="DELAYED", coletado_em=1795200000)
        self.assertEqual(r["preco"], 32.5)
        self.assertEqual(r["estado"], "DELAYED")
        self.assertEqual(r["observado_em"], "2026-11-20T17:30:00+00:00")
        self.assertEqual(r["provedor"], "PROVEDOR-TESTE")

    def test_snapshot_duplicado_nao_duplica_registro(self):
        args = (1, "P", "2026-11-20T17:30:00Z", 10)
        live.registrar(*args)
        live.registrar(*args)
        self.assertEqual(live.resumo(1)["registros"], 1)

    def test_rejeita_preco_invalido(self):
        for preco in (0, -1, float("nan"), float("inf")):
            with self.subTest(preco=preco), self.assertRaises(ValueError):
                live.registrar(1, "P", "2026-11-20T17:30:00Z", preco)

    def test_rejeita_horario_sem_fuso(self):
        with self.assertRaises(ValueError):
            live.registrar(1, "P", "2026-11-20T17:30:00", 10)

    def test_rejeita_estado_desconhecido(self):
        with self.assertRaises(ValueError):
            live.registrar(1, "P", "2026-11-20T17:30:00Z", 10, estado="LIVE_TALVEZ")

    def test_lista_e_resumo(self):
        live.registrar(1, "P", "2026-11-20T17:30:00Z", 10)
        live.registrar(1, "P", "2026-11-20T17:31:00Z", 11)
        self.assertEqual(len(live.ultimas(1)), 2)
        self.assertEqual(live.ultimas(1)[0]["preco"], 11)
        self.assertEqual(live.resumo(1)["registros"], 2)

    def test_resumo_vazio(self):
        self.assertEqual(live.resumo(999)["registros"], 0)


if __name__ == "__main__":
    unittest.main()

class TestYahooChartAdapter(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = mock.patch.object(config, "DADOS", Path(self.tmp.name) / "dados")
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_parseia_resposta_chart(self):
        import json
        from unittest import mock
        from gfi.conectores import yahoo_chart
        payload = {"chart": {"result": [{"meta": {"exchangeName": "SAO", "currency": "BRL"},
                    "timestamp": [1795200000, 1795200060],
                    "indicators": {"quote": [{"close": [32.1, None], "volume": [100, 0]}]}}], "error": None}}
        class Response:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self, n): return json.dumps(payload).encode()
        with mock.patch("urllib.request.urlopen", return_value=Response()):
            r = yahoo_chart.buscar("PETR4.SA")
        self.assertEqual(r["moeda"], "BRL")
        self.assertEqual(len(r["pontos"]), 1)
        self.assertEqual(r["pontos"][0]["preco"], 32.1)

    def test_rejeita_simbolo_invalido(self):
        from gfi.conectores import yahoo_chart
        with self.assertRaises(ValueError):
            yahoo_chart.buscar("PETR4.SA;DROP TABLE")

    def test_rejeita_intervalo_nao_permitido(self):
        from gfi.conectores import yahoo_chart
        with self.assertRaises(ValueError):
            yahoo_chart.buscar("PETR4.SA", intervalo="10s")

    def test_coleta_e_persiste_snapshot(self):
        from unittest import mock
        from gfi import catalogo
        from gfi.conectores import yahoo_chart
        iid = catalogo.upsert("PETR4", "BVMF", "REAL", moeda="BRL", pais="BR")
        pacote = {"simbolo": "PETR4.SA", "intervalo": "1m", "periodo": "1d", "exchange": "SAO", "moeda": "BRL",
                  "pontos": [{"observado_em": "2026-11-20T17:30:00+00:00", "preco": 32.5, "volume": 1000}]}
        with mock.patch.object(yahoo_chart, "buscar", return_value=pacote):
            r = yahoo_chart.coletar(iid, "PETR4.SA")
        self.assertEqual(r["novos_registros"], 1)
        self.assertEqual(r["estado"], "DELAYED")
        self.assertEqual(live.ultimas(iid)[0]["preco"], 32.5)

    def test_nao_permite_simbolo_de_outro_ativo(self):
        from gfi import catalogo
        from gfi.conectores import yahoo_chart
        iid = catalogo.upsert("PETR4", "BVMF", "REAL")
        with self.assertRaises(ValueError):
            yahoo_chart.coletar(iid, "VALE3.SA")

class TestLiveAutomatico(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = mock.patch.object(config, "DADOS", Path(self.tmp.name) / "dados")
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_auto_desligado_por_padrao(self):
        from gfi import live_auto
        self.assertFalse(live_auto.habilitado())

    def test_intervalo_minimo_de_um_minuto(self):
        from gfi import live_auto
        with self.assertRaises(ValueError):
            live_auto.configurar(True, 30)
        self.assertFalse(live_auto.habilitado())

    def test_configuracao_auto_e_estado_nao_promete_tempo_real(self):
        from gfi import live_auto
        estado = live_auto.configurar(True, 60)
        self.assertTrue(estado["habilitado"])
        self.assertEqual(estado["classificacao"], "DELAYED")
        self.assertFalse(estado["garantia_tempo_real"])

    def test_ciclo_usa_conector_existente(self):
        from gfi import catalogo, live_auto
        from gfi.conectores import yahoo_chart
        iid = catalogo.upsert("PETR4", "BVMF", "REAL", moeda="BRL", pais="BR")
        with mock.patch.object(yahoo_chart, "coletar", return_value={"novos_registros": 2}) as coletar:
            r = live_auto.executar_ciclo()
        coletar.assert_called_once_with(iid, "PETR4.SA", "1d", "1mo")
        self.assertEqual(r["sucessos"], 1)
        self.assertEqual(r["falhas"], 0)
