# MY UNIVERSE / GFI — V10

## Escopo
- Experiência WebMobile responsiva para smartphone, mantendo desktop.
- Wallpaper vertical MY UNIVERSE dedicado a telas móveis; desktop usa a imagem horizontal original MY UNIVERSE / GLOBAL FINANCIAL INTELLIGENCE enviada pelo usuário.
- Barra superior persistente com saldo de caixa da aba 19 — Minha Conta.
- Saldo consultado no endpoint existente `/api/carteira`, compartilhado entre painéis e atualizado a cada 15 segundos e após movimentações.
- Controle de ocultar/revelar saldo com preferência persistida no navegador.
- Navegação horizontal adaptada ao toque, painéis em uma coluna, tabelas com rolagem horizontal e campos/botões maiores.

## Precisão financeira
O número exibido no topo é o **saldo de caixa** calculado pelo livro de movimentações da carteira. Não é patrimônio total. O patrimônio total continua disponível na tela Minha Conta e depende de cotações válidas para todas as posições, conforme a regra já existente.

## Segurança e limites
A preferência de ocultação é local ao navegador/dispositivo; ela não protege os dados da carteira no servidor. O GFI continua sendo ferramenta de pesquisa e apoio à decisão e não opera no mercado.
