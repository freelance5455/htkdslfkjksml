"""Exemplo de atualização de código: um indicador novo e um ranking novo.

Regras: só é permitido importar math, statistics, datetime, json, csv, re, collections, itertools, functools, typing.
Não use open, eval, exec, while nem atributos com __. A IA chama registrar(api) uma vez, ao ativar.
"""
import statistics


def zscore20(candles):
    """candles = [(data, abertura, maxima, minima, fechamento, volume, qtd)]. Devolve um número ou None."""
    fechamentos = [c[4] for c in candles][-20:]
    if len(fechamentos) < 20:
        return None
    desvio = statistics.pstdev(fechamentos)
    return (fechamentos[-1] - statistics.mean(fechamentos)) / desvio if desvio else None


def valor(r):
    """r = resultado completo do ativo (r['metricas'], r['dimensoes'], r['indice']...). Maior valor = melhor posição."""
    v = r["metricas"].get("vol_anual")
    return None if v is None else 100 - v * 100


def por_que(r):
    return f"Volatilidade anualizada de {r['metricas']['vol_anual'] * 100:.1f}%"


def registrar(api):
    api.indicador("Z-score 20d", zscore20)
    api.ranking("baixa_volatilidade", "Menor volatilidade", valor, por_que)
