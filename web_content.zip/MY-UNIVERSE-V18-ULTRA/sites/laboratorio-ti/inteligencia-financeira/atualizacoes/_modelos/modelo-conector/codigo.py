"""Modelo de conector. Só pode acessar a internet por api.baixar() e só nos hosts declarados em "rede" no manifesto.
Respeite os termos de uso, o licenciamento e os limites de requisição do fornecedor."""
import csv


def coletar(api):
    bruto = api.baixar("https://exemplo.com/cotacoes_diarias.csv").decode("utf-8")
    linhas = []
    for r in csv.DictReader(bruto.splitlines()):
        linhas.append((r["ticker"].upper(), r["data"], float(r["abertura"]), float(r["maximo"]), float(r["minimo"]),
                       float(r["fechamento"]), float(r["volume"]), float(r["qtd"])))
    return {"cotacoes_gravadas": api.gravar_cotacoes(linhas)}


def registrar(api):
    api.conector("meu-fornecedor", coletar)
