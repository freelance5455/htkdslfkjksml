# Pasta de atualizações da IA (estilo CLEO)

A IA mora em `inteligencia-financeira/`. **Esta pasta (`atualizacoes/`) é onde você solta pacotes para ampliar ou
corrigir a IA sem mexer no núcleo.** Nada roda sozinho: cada pacote só vale depois que **você** clica em *Ativar*.

## Como adicionar uma atualização (3 passos)

1. **Solte** aqui uma pasta (ou um `.zip`) com um arquivo `atualizacao.json`. Dica: copie um modelo de `_modelos/`.
2. Abra o painel → **Atualizações** → clique em **Recarregar pasta** → confira o pacote → **Ativar**.
3. Para desfazer: **Desativar** (e, se quiser, marque *remover os dados importados*).

Pastas que começam com `_` ou `.` são ignoradas (é por isso que os modelos ficam em `_modelos/`).

## Estrutura de um pacote

```
minha-atualizacao/
├── atualizacao.json      ← obrigatório
├── dados/                ← opcional: CSVs (setores, fundamentos, eventos, cotações)
├── config.json           ← opcional: pesos e sensibilidade macro × setor
└── codigo.py             ← opcional: novos indicadores, rankings e conectores
```

`atualizacao.json`:
```json
{ "id": "minha-atualizacao", "nome": "Nome legível", "versao": "1.0.0",
  "descricao": "O que faz", "autor": "você", "rede": ["api.meufornecedor.com"] }
```
`id`: só `a-z 0-9 - _` (3 a 40). `rede` só é preciso se o código baixar dados da internet.

## Tipos de atualização

**1) Dados (CSV, UTF-8, cabeçalho na 1ª linha)** — entram só no universo REAL (nunca na demonstração):

| Arquivo | Colunas |
|---|---|
| `dados/setores.csv` | `ticker,setor` (setor da classificação B3, ex.: `Financeiro`) |
| `dados/fundamentos.csv` | `ticker,periodo,campo,valor` — periodo `2024`; campos: receita, lucro_liquido, ebitda, ebit, divida_liquida, fcf, patrimonio, acoes, dividendos_por_acao, governanca |
| `dados/eventos.csv` | `ticker,setor,pais,categoria,tipo,severidade,impacto,titulo,fonte,publicado_em,confiabilidade` — categoria: noticia/regulatorio/geopolitico; severidade 1–5; impacto −2…+2; confiabilidade alta/media/baixa |
| `dados/cotacoes.csv` | `ticker,mic,data,abertura,maximo,minimo,fechamento,volume,qtd` (+ opcionais `nome,tipo,moeda,pais`) |

Linhas inválidas são ignoradas e contadas no resumo. Aceita vírgula decimal.

**2) Configuração (`config.json`)** — reversível ao desativar:
```json
{ "pesos": { "tecnica": 8, "risco": 12 },
  "sensibilidade": { "juros": { "Financeiro": 2 } } }
```

**3) Código (`codigo.py`)** — define `registrar(api)`. A `api` oferece:

- `api.indicador(nome, funcao)` — `funcao(candles)` devolve um número (aparece na análise do ativo);
- `api.ranking(chave, titulo, valor, por_que)` — cria um ranking novo;
- `api.conector(nome, funcao)` — novo fornecedor de dados (`api.baixar(url)`, `api.gravar_cotacoes(...)`, `api.gravar_macro(...)`).

Regras do código: só pode importar `math, statistics, datetime, json, csv, re, collections, itertools, functools, typing`;
não pode usar `open, eval, exec, while` nem atributos `__x__`; a internet só pelos hosts declarados em `rede`.
Veja `_modelos/modelo-indicador-ranking` e `_modelos/modelo-conector`.

## Segurança (leia)

- **Nada executa sem o seu clique.** Se você editar qualquer arquivo de um pacote ativo, ele é desativado até você reativar.
- **Modo seguro:** crie um arquivo vazio chamado `DESLIGADO` nesta pasta (ou use `GFI_SEM_ATUALIZACOES=1`) e nenhuma atualização é carregada — use se algo der errado.
- A análise de código reduz riscos, mas **não é uma prisão perfeita**: só ative pacotes que você entende e confia.
- Atualizações não alteram as regras de segurança da IA nem o histórico imutável de previsões.

## Como a própria IA se atualiza

A IA pesquisa, propõe e testa melhorias **só na pasta `laboratorio/`**. Quando você aprova uma proposta (digitando `APROVO`
em *Evolução*), ela vira um pacote aqui em `atualizacoes/ia-proposta-N/`, **desativado**. Você revisa e ativa se quiser.
Propostas que mexem em regras de segurança são recusadas automaticamente. O processo é lento de propósito:
PESQUISA → PROPOSTA → EXPERIMENTAL → TESTES → COMPARAÇÃO → APROVAÇÃO → PUBLICAÇÃO.
