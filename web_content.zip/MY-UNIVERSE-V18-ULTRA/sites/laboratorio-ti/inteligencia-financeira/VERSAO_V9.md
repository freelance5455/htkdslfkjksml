# MY UNIVERSE V9 — implementação incremental

Base: V8 Alpha GFI-BOTAO. Recursos V8 preservados; complementos novos usam banco separado.

## Implementado nesta construção
- Fundo GFI restaurado com imagem pessoal financeira `ui/assets/gfi-background.png`; `assets/fundo.webp` do portal permanece intacto.
- Botões no topo: Atualizar cotações e Buscar geral.
- Metadados de data de referência e última execução no topo.
- Seção 07 — Notícias com RSS público, cache SQLite, fonte, publicação, coleta e link original.
- Minha Conta com depósitos, retiradas, compras, vendas, saldo e posições, em `dados/gfi_v9.db`.

## Limitações conhecidas
- Yahoo Finance Chart não tem SLA; snapshots são DELAYED. O botão tenta os primeiros 35 ativos por clique.
- Busca geral consulta RSS e atualiza a fila inteligente de lacunas; não é uma varredura universal da internet nem garante preencher automaticamente todos os fundamentos.
- Notícias depende de internet e Google News RSS.
- Carteira ainda não calcula patrimônio a mercado, custo médio, proventos, taxas ou IR.
- Demais recursos do plano mestre exigem homologação por módulo e integrações externas.

## Proteção
- `dados/gfi.db` não é recriado nem substituído. Dados V9 ficam em `dados/gfi_v9.db`. Credenciais, tokens e históricos existentes não são alterados.
