# MY UNIVERSE — V6.04

**Foco:** tornar a coleta B3 COTAHIST auditável e acionável pela API, preservando a arquitetura e os dados da V6.03.

## Entregas

- Validação dos anos solicitados: somente lista não vazia, anos entre 1990 e o ano corrente, sem booleanos ou valores não numéricos; máximo de 10 anos por chamada e remoção de duplicados.
- Novo diagnóstico `b3_cotahist.status()` com quantidade de cotações e instrumentos gravados pela fonte `B3-COTAHIST`, intervalo de datas, cobertura por ano e últimas tentativas registradas.
- Novo endpoint `GET /api/b3/status` para consultar a cobertura efetivamente armazenada.
- Nova ação protegida `POST /api/b3/coletar`, com corpo `{"anos":[2024,2025]}`. A resposta contém o resultado por exercício e o status atualizado.
- A coleta manual é bloqueada no modo demonstração para evitar misturar dados fictícios e reais.
- A ingestão continua idempotente pela chave diária existente (instrumento + data), usando `INSERT OR REPLACE`; o lote padrão não importa o BDI 96 fracionário.
- Três testes adicionais cobrem validação de anos, diagnóstico de status e bloqueio no modo demonstração.

## Como operar

1. Inicie a GFI e confirme que o modo demonstração está desligado.
2. Consulte `GET /api/b3/status` para registrar o estado inicial.
3. Faça uma chamada local `POST /api/b3/coletar` com o cabeçalho `X-GFI: 1` e JSON `{"anos":[2024,2025]}`.
4. Consulte novamente `GET /api/b3/status`; confira `ultimas_coletas`, `por_ano`, `primeira_data` e `ultima_data`.
5. Abra *Configurações → Testar conexões* para um diagnóstico rápido de alcance da fonte. Esse teste não baixa nem valida o ZIP completo.

Exemplo com curl (servidor local):

```bash
curl -s http://127.0.0.1:8780/api/b3/status
curl -s -X POST http://127.0.0.1:8780/api/b3/coletar \
  -H 'Content-Type: application/json' -H 'X-GFI: 1' \
  -d '{"anos":[2024,2025]}'
```

## Validação executada nesta construção

- `python -m compileall -q gfi servidor.py` — aprovado.
- `python -m unittest discover -s testes -t .` — **98 testes aprovados** (95 da V6.03 + 3 novos).
- Testes usam banco temporário e fixtures sintéticas; não alteram a base de dados distribuída.

## Limites e pendências externas

- **Não foi possível comprovar download real da B3 nesta construção.** A suíte comprova parser, validação, ZIP de fixture, gravação e API, não a disponibilidade do host oficial nem a ingestão do arquivo anual real.
- A conclusão operacional exige executar a coleta na máquina com internet, confirmar HTTP/ZIP, quantidade de registros, intervalo de datas e cobertura por ano. Guarde a resposta de `GET /api/b3/status` como evidência.
- COTAHIST é histórico diário, não cotação intradiária ou em tempo real.
- Cotações não são ajustadas por proventos.
- O conector B3 da V6.03 foi preservado; a V6.04 acrescenta validação de entrada, visibilidade e acionamento manual.
