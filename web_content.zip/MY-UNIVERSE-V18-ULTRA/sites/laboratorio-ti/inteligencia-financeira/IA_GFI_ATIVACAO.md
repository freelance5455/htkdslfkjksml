# GFI AI — arquitetura e ativação

## Autonomia nível 3 supervisionada

1. Agente periódico inventaria módulos, testes, cobertura, falhas de coleta e fila de pesquisa.
2. Pesquisa documentação pública por dois mecanismos de busca e lê páginas HTTPS públicas.
3. Envia inventário e fontes ao modelo de linguagem detectado.
4. Produz relatório com fatos, hipóteses, prioridades, riscos, testes e caminhos exatos.
5. Código Python é guardado em `laboratorio/gfi_ai/propostas/`, validado sintaticamente e sinalizado por operações sensíveis.
6. Não executa código gerado, não altera produção e não publica atualizações sem aprovação humana.

## Descoberta automática

A central verifica Ollama (`/api/tags`), LM Studio, llama.cpp/NEXUS e vLLM. Também aceita endpoint OpenAI-compatible por variáveis de ambiente. Só mostra `conectado` depois de uma resposta HTTP válida do servidor de inferência.

## Ativar modelo local

Na pasta da GFI: `./ativar_ia.sh`. O script é interativo, solicita consentimento para instalação do Ollama e para baixar um modelo, e não armazena credenciais. Após a instalação, reinicie `./iniciar.sh` e consulte a Central IA.

## Pesquisa externa

DuckDuckGo é o primeiro mecanismo; Bing RSS é o fallback. Se ambos falharem, o relatório registra a indisponibilidade em vez de inventar fontes. A rede da máquina de operação precisa permitir DNS e HTTPS.

## Segurança

- Conteúdo externo é dado, nunca instrução de sistema.
- Só HTTPS público é aceito para páginas externas; redirecionamentos são validados.
- Endpoint LLM remoto exige HTTPS; HTTP é permitido apenas em loopback.
- Chaves são lidas do ambiente e não são escritas nos relatórios.
- Código gerado permanece em laboratório e requer aprovação humana.
