# MY UNIVERSE V12 — Carteira dinâmica e patrimônio global

## Base
Construída sobre a MY UNIVERSE V11. Preserva os módulos, páginas, identidade visual, integrações e dados existentes da versão-base.

## Alterações
- A carteira pessoal mantém caixa separado das posições em ações.
- Cada posição calcula custo de aquisição, valor de mercado, lucro/prejuízo aberto e rentabilidade percentual.
- Nova atualização de cotações da carteira por símbolo B3 no formato `TICKER.SA`, com persistência local da última cotação consultada.
- Atualização automática a cada 60 segundos enquanto o painel está aberto e botão manual na aba Minha Conta.
- Patrimônio global = saldo de caixa + valor de mercado das posições, quando todas as posições possuem cotação identificável.
- Indicador global apresenta patrimônio em verde quando a rentabilidade acumulada é positiva e vermelho quando negativa, com percentual ao lado. Ocul­tar/revelar continua disponível.
- A rentabilidade global usa o capital líquido aportado (depósitos menos retiradas) como base. Resultado total inclui P/L realizado e aberto.

## Fonte e limites
A consulta usa Yahoo Finance Chart público. A cotação pode ser atrasada, indisponível ou sujeita a limites; não há garantia de tempo real nem SLA. O valor permanece baseado na última cotação conhecida. A rentabilidade não inclui taxas, impostos, dividendos/proventos, eventos corporativos ou ajustes fiscais. O usuário deve conferir os preços com a corretora antes de negociar.

## Importante
O patrimônio global não é apenas o caixa. Compra de ações reduz caixa e cria uma posição; valorização altera o patrimônio de mercado, não o saldo de caixa. A tela preserva os dois valores separadamente.
