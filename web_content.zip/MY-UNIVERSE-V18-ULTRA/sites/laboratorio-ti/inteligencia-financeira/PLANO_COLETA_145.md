# GFI — Plano de finalização da coleta de dados

Este plano contém 145 requisitos distribuídos em 16 etapas. O painel **Plano de coleta** registra o estado individual de cada requisito.

## Critério de conclusão

Uma tarefa só pode receber o estado **Concluída** quando houver evidência objetiva e resultado de validação registrados. Código presente, fixture aprovada ou teste isolado não comprovam download real, cobertura histórica ou homologação operacional. Estados possíveis: Pendente, Em andamento, Bloqueada e Concluída.

## Etapas e quantidades

| Etapa | Tarefas |
|---|---:|
| 1. Preparação e inventário | 5 |
| 2. B3 — COTAHIST | 9 |
| 3. Banco Central — BCB SGS | 8 |
| 4. CVM — Fundamentos financeiros | 12 |
| 5. Cotações complementares | 7 |
| 6. Cadastro de empresas e ativos | 8 |
| 7. Setores e classificação econômica | 5 |
| 8. Eventos corporativos e proventos | 7 |
| 9. Histórico ajustado de preços | 6 |
| 10. Qualidade e integridade dos dados | 11 |
| 11. Armazenamento e desempenho | 9 |
| 12. Automação das coletas | 10 |
| 13. Monitoramento e relatórios | 9 |
| 14. Testes finais | 15 |
| 15. Homologação e conclusão | 12 |
| 16. Painel de conclusão | 12 |
| **Total** | **145** |

## Fonte de verdade

A lista integral das 145 tarefas está em `gfi/plano_coleta.py`, exposta pela rota local `GET /api/plano-coleta` e pelo painel da GFI. O estado é persistido em `gfi_plano_tarefas` no SQLite.

A rota `POST /api/plano-coleta/atualizar` atualiza o estado. Para concluir, exige evidência e validação preenchidas. O registro é uma declaração operacional do responsável e ainda deve ser sustentado por logs, testes, arquivos oficiais e amostras reproduzíveis.

## Ordem de execução

Executar tarefa por tarefa: inspecionar o existente, identificar lacunas, implementar apenas o necessário, testar, registrar evidência e avançar. Dependências externas (internet, permissões, licenças e credenciais) devem aparecer como bloqueios, nunca como sucesso presumido.
