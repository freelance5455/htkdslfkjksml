# MY UNIVERSE — V6.02

**Foco:** robustez da ingestão CVM e consulta segura dos dados por instrumento. A versão parte da V6.01 e preserva seus módulos e dados.

## Entregas

- Parser CVM mais rigoroso: rejeita valores ausentes/não finitos, conta contábil vazia e datas inválidas; preserva zero como valor válido.
- Chave idempotente estabilizada quando o arquivo não informa grupo do exercício.
- Contagem exata de novos registros por transação SQLite, sem depender de `cursor.rowcount` de `executemany`.
- Proteções adicionais no ZIP: limite agregado de conteúdo descompactado e rejeição de arquivos criptografados, além dos limites já existentes.
- Status CVM agora informa cobertura temporal e volume por tipo documental (DFP/ITR).
- Consulta de lançamentos por instrumento em `GET /api/cvm/instrumento/{instrumento_id}`. A consulta só retorna dados depois de vínculo CNPJ/instrumento confirmado; sem vínculo, retorna explicitamente `mapeado: false`.
- Preservação de moeda, escala, grupo, versão, arquivo e fonte dos lançamentos. Os dados permanecem brutos: não são convertidos automaticamente em indicadores nem alimentam valuation sem um mapeamento contábil validado.
- Testes adicionais para NaN, data impossível, conta vazia, vínculo confirmado e idempotência com grupo ausente.

## Rotas CVM

- `GET /api/cvm/status` — cobertura e histórico de coletas.
- `GET /api/cvm/instrumento/{id}` — lançamentos associados a instrumento mapeado.
- `POST /api/cvm/coletar` — baixa DFP/ITR oficial.
- `POST /api/cvm/importar` — importa ZIP local em Base64.
- `POST /api/cvm/mapear` — confirma vínculo entre CNPJ e instrumento.

## Limitações

- A disponibilidade de download real depende da rede e do portal da CVM; não foi possível atestar acesso externo neste ambiente.
- Não há conversão automática de demonstrações em lucro, receita, dívida, EBITDA ou fluxo de caixa livre. Os códigos contábeis exigem mapeamento por demonstração, versão e contexto antes de qualquer cálculo.
- Nenhum CNPJ/ticker é inferido automaticamente.
- A consulta por instrumento é uma camada de leitura rastreável, não uma recomendação de investimento.

## Validação

- `python -m compileall -q gfi servidor.py` — aprovado.
- `python -m unittest discover -s testes -t .` — **91 testes aprovados**.
- Smoke test HTTP da página e das rotas CVM/LIVE — registrado no relatório de entrega.
- ZIP validado com `unzip -t`.
