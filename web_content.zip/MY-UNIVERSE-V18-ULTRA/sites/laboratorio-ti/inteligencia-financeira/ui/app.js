(() => {
'use strict';
// ---------------------------------------------------------------- utilidades
const $ = (s, r = document) => r.querySelector(s);
const h = (tag, props, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'style') e.style.cssText = v; else e.setAttribute(k, v === true ? '' : v);
  }
  const add = (c) => { if (c == null || c === false) return; if (Array.isArray(c)) c.forEach(add); else e.append(c.nodeType ? c : document.createTextNode(String(c))); };
  kids.forEach(add); return e;
};
const sv = (tag, props, ...kids) => {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(props || {})) e.setAttribute(k, v);
  kids.forEach((c) => c != null && e.append(c.nodeType ? c : document.createTextNode(String(c)))); return e;
};
async function api(rota, corpo) {
  const opt = corpo === undefined ? { credentials: 'same-origin' }
    : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-GFI': '1' }, body: JSON.stringify(corpo) };
  const r = await fetch('/api/' + rota, opt);
  const j = await r.json().catch(() => ({ erro: 'Resposta inválida.' }));
  if (!r.ok) throw new Error(j.erro || 'Erro ' + r.status);
  return j;
}
const qs = (o) => Object.entries(o).filter(([, v]) => v !== '' && v != null).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
const F = {
  pct: (x, d = 1) => x == null ? '—' : (x * 100).toFixed(d).replace('.', ',') + '%',
  pctS: (x) => x == null ? '—' : (x >= 0 ? '+' : '') + (x * 100).toFixed(2).replace('.', ',') + '%',
  n: (x, d = 2) => x == null ? '—' : Number(x).toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d }),
  vol: (x) => x == null ? '—' : x >= 1e9 ? (x / 1e9).toFixed(1).replace('.', ',') + ' bi' : x >= 1e6 ? (x / 1e6).toFixed(1).replace('.', ',') + ' mi' : x >= 1e3 ? (x / 1e3).toFixed(0) + ' mil' : x.toFixed(0),
  d: (ts) => new Date(ts * 1000).toLocaleString('pt-BR'),
};
const cls = (x) => x == null ? 'mu' : x >= 0 ? 'pos' : 'neg';
// V10: saldo global sincronizado com Minha Conta (carteira persistida no servidor).
const SALDO_OCULTO_KEY = 'gfi.saldo.oculto.v1';
let saldoGlobalOculto = localStorage.getItem(SALDO_OCULTO_KEY) === '1';
let ultimoSaldoGlobal = null; let variacaoSaldoGlobal = null; let carteiraLiveTimer = null;
function renderSaldoGlobal() {
  const valor = $('#saldo-global-valor'), botao = $('#saldo-global-ocultar');
  if (!valor || !botao) return;
  valor.textContent = saldoGlobalOculto ? '••••••••' : (ultimoSaldoGlobal == null ? 'R$ —' : 'R$ ' + F.n(ultimoSaldoGlobal));
  const variacao = $('#saldo-global-variacao');
  if (variacao) { variacao.textContent = saldoGlobalOculto ? '••' : (variacaoSaldoGlobal == null ? '—' : F.pctS(variacaoSaldoGlobal)); variacao.className = 'saldo-variacao ' + cls(variacaoSaldoGlobal); }
  valor.className = cls(variacaoSaldoGlobal);
  botao.textContent = saldoGlobalOculto ? '◎' : '◉';
  botao.setAttribute('aria-label', saldoGlobalOculto ? 'Revelar saldo' : 'Ocultar saldo');
  botao.title = saldoGlobalOculto ? 'Revelar saldo' : 'Ocultar saldo';
  $('#saldo-global')?.classList.toggle('saldo-oculto', saldoGlobalOculto);
}
async function atualizarSaldoGlobal() {
  try { const r = await api('carteira'); ultimoSaldoGlobal = r.patrimonio_total == null ? Number(r.saldo_caixa || 0) : Number(r.patrimonio_total); variacaoSaldoGlobal = r.rentabilidade_total == null ? null : Number(r.rentabilidade_total); renderSaldoGlobal(); }
  catch (_) { const v = $('#saldo-global-valor'); if (v && ultimoSaldoGlobal == null) v.textContent = 'R$ —'; }
}

const COR = { verde: '#1fbf75', amarelo: '#f2b53a', vermelho: '#ef4b5a', cinza: '#667386' };
const ROT = { economia: 'Economia', juros: 'Juros', inflacao: 'Inflação', saude: 'Saúde financeira', crescimento: 'Crescimento', valuation: 'Valuation', noticias: 'Notícias', regulacao: 'Regulação', governanca: 'Governança', tecnica: 'Análise técnica', liquidez: 'Liquidez', volatilidade: 'Volatilidade', geopolitica: 'Geopolítica', risco: 'Risco', longo_prazo: 'Longo prazo' };
const ORDEM = Object.keys(ROT);
const pt = (x) => x == null ? null : Math.floor(x + 1e-9);
const pill = (l, t) => h('span', { class: 'pill l-' + l }, t == null ? '—' : t);
const dots = (luzes) => h('span', { class: 'dots' }, ORDEM.map((k) => h('span', { class: 'dot d-' + (luzes[k] || 'cinza'), title: ROT[k] + ': ' + (luzes[k] || 'cinza') })));
const card = (titulo, ...k) => h('section', { class: 'card' }, titulo && h('h2', null, titulo), ...k);
const aviso = (t, tipo = 'aviso') => h('div', { class: tipo }, t);
const tabela = (cols, rows, onRow) => h('div', { class: 'tw' }, h('table', null,
  h('thead', null, h('tr', null, cols.map((c) => h('th', { class: c.n ? 'num' : '' }, c.t)))),
  h('tbody', null, rows.map((r) => h('tr', { class: onRow ? 'clic' : '', onclick: onRow ? () => onRow(r) : null },
    cols.map((c) => h('td', { class: (c.n ? 'num ' : '') + (c.q ? 'quebra ' : '') + (c.c ? c.c(r) : '') }, c.f(r))))))));
const kpi = (r, v, s) => h('div', { class: 'card kpi' }, h('div', { class: 'r' }, r), h('div', { class: 'v' }, v), s && h('div', { class: 's' }, s));
const btn = (t, f, c = '') => h('button', { class: 'btn ' + c, type: 'button', onclick: f }, t);
const sel = (opts, val, f, extra) => { const s = h('select', { class: 'campo', ...extra, onchange: (e) => f(e.target.value) }, opts.map(([v, t]) => { const o = h('option', { value: v }, t); if (String(v) === String(val ?? '')) o.selected = true; return o; })); return s; };

// ---------------------------------------------------------------- gráficos
function spark(vals, w = 84, hgt = 22) {
  if (!vals || vals.length < 2) return h('span', { class: 'mu' }, '—');
  const mn = Math.min(...vals), mx = Math.max(...vals), dx = w / (vals.length - 1), rg = mx - mn || 1;
  const pts = vals.map((v, i) => (i * dx).toFixed(1) + ',' + (hgt - 2 - ((v - mn) / rg) * (hgt - 4)).toFixed(1)).join(' ');
  return sv('svg', { width: w, height: hgt, viewBox: `0 0 ${w} ${hgt}` }, sv('polyline', { points: pts, fill: 'none', stroke: vals[vals.length - 1] >= vals[0] ? COR.verde : COR.verm, 'stroke-width': 1.5 }));
}
function linha(pontos, { w = 520, hgt = 150, cor = '#4aa3ff', fmt = (x) => F.n(x, 2) } = {}) {
  if (!pontos || pontos.length < 2) return h('div', { class: 'vazio' }, 'Dados insuficientes para o gráfico.');
  const ys = pontos.map((p) => p[1]), mn = Math.min(...ys), mx = Math.max(...ys), rg = mx - mn || 1, pad = 34, dx = (w - pad - 6) / (pontos.length - 1);
  const X = (i) => pad + i * dx, Y = (v) => hgt - 16 - ((v - mn) / rg) * (hgt - 28);
  return sv('svg', { viewBox: `0 0 ${w} ${hgt}`, width: '100%', role: 'img' },
    sv('polyline', { points: pontos.map((p, i) => X(i).toFixed(1) + ',' + Y(p[1]).toFixed(1)).join(' '), fill: 'none', stroke: cor, 'stroke-width': 1.6 }),
    sv('text', { x: 2, y: 12 }, fmt(mx)), sv('text', { x: 2, y: hgt - 18 }, fmt(mn)),
    sv('text', { x: pad, y: hgt - 3 }, pontos[0][0]), sv('text', { x: w - 66, y: hgt - 3 }, pontos[pontos.length - 1][0]));
}
function sma(c, n) { return c.map((_, i) => i + 1 < n ? null : c.slice(i + 1 - n, i + 1).reduce((a, b) => a + b, 0) / n); }
function velas(candles) {
  const W = 940, H = 380, PH = 270, pad = 56, n = candles.length;
  if (n < 5) return h('div', { class: 'vazio' }, 'Sem cotações suficientes.');
  const hi = Math.max(...candles.map((c) => c[2])), lo = Math.min(...candles.map((c) => c[3])), rg = hi - lo || 1;
  const vmax = Math.max(...candles.map((c) => c[5])) || 1, bw = (W - pad - 8) / n;
  const X = (i) => pad + i * bw + bw / 2, Y = (v) => 10 + (1 - (v - lo) / rg) * (PH - 20);
  const g = sv('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', role: 'img', 'aria-label': 'Gráfico de candles' });
  for (let k = 0; k <= 4; k++) { const v = lo + (rg * k) / 4; g.append(sv('line', { x1: pad, x2: W - 6, y1: Y(v), y2: Y(v), stroke: '#ffffff0d' }), sv('text', { x: 4, y: Y(v) + 3 }, F.n(v, 2))); }
  candles.forEach((c, i) => {
    const up = c[4] >= c[1], col = up ? COR.verde : COR.verm;
    g.append(sv('line', { x1: X(i), x2: X(i), y1: Y(c[2]), y2: Y(c[3]), stroke: col }),
      sv('rect', { x: X(i) - Math.max(1, bw * 0.35), y: Math.min(Y(c[1]), Y(c[4])), width: Math.max(1.5, bw * 0.7), height: Math.max(1, Math.abs(Y(c[1]) - Y(c[4]))), fill: col }),
      sv('rect', { x: X(i) - Math.max(1, bw * 0.35), y: H - 6 - (c[5] / vmax) * 80, width: Math.max(1.5, bw * 0.7), height: (c[5] / vmax) * 80, fill: col, opacity: 0.35 }));
  });
  const cl = candles.map((c) => c[4]);
  [[20, '#4aa3ff'], [50, '#f2b53a']].forEach(([p, cor]) => g.append(sv('polyline', { fill: 'none', stroke: cor, 'stroke-width': 1.2, points: sma(cl, p).map((v, i) => v == null ? null : X(i).toFixed(1) + ',' + Y(v).toFixed(1)).filter(Boolean).join(' ') })));
  g.append(sv('text', { x: pad, y: H - 90 }, 'volume'), sv('text', { x: W - 150, y: 12 }, 'azul: média 20 · amarelo: média 50'));
  const info = h('div', { class: 'mono mu', style: 'min-height:18px;margin-top:4px' }, 'passe o mouse sobre o gráfico');
  const cruz = sv('line', { y1: 0, y2: H, stroke: '#ffffff30', x1: -10, x2: -10 }); g.append(cruz);
  g.addEventListener('mousemove', (e) => {
    const r = g.getBoundingClientRect(), i = Math.max(0, Math.min(n - 1, Math.floor(((e.clientX - r.left) / r.width * W - pad) / bw)));
    const c = candles[i]; cruz.setAttribute('x1', X(i)); cruz.setAttribute('x2', X(i));
    info.textContent = `${c[0]}  A ${F.n(c[1])}  Máx ${F.n(c[2])}  Mín ${F.n(c[3])}  Fech ${F.n(c[4])}  Vol ${F.vol(c[5])}`;
  });
  return h('div', null, g, info);
}
function gauge(score, luz) {
  const s = score == null ? 0 : Math.max(0, Math.min(100, score)), a = Math.PI * (1 - s / 100), cx = 80, cy = 78, r = 62;
  const x = cx + r * Math.cos(a), y = cy - r * Math.sin(a);
  return sv('svg', { width: 160, height: 100, viewBox: '0 0 160 100', role: 'img', 'aria-label': 'Índice ' + (score ?? 'indisponível') },
    sv('path', { d: `M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`, fill: 'none', stroke: '#1f2b3b', 'stroke-width': 12, 'stroke-linecap': 'round' }),
    score != null && sv('path', { d: `M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${x.toFixed(1)} ${y.toFixed(1)}`, fill: 'none', stroke: COR[luz] || COR.cinza, 'stroke-width': 12, 'stroke-linecap': 'round' }),
    sv('text', { x: cx, y: cy - 6, 'text-anchor': 'middle', style: 'font-size:26px;fill:#e6ebf2;font-weight:700' }, score == null ? '—' : pt(score)),
    sv('text', { x: cx, y: cy + 12, 'text-anchor': 'middle' }, 'de 100'));
}
function squarify(items, x, y, w, hh) {
  const total = items.reduce((s, i) => s + i.v, 0), out = []; if (!total || w <= 0 || hh <= 0) return out;
  let rest = items.map((i) => ({ ...i, a: (i.v / total) * w * hh }));
  const pior = (row, lado) => { const s = row.reduce((a, i) => a + i.a, 0), mx = Math.max(...row.map((i) => i.a)), mn = Math.min(...row.map((i) => i.a)); return Math.max((lado * lado * mx) / (s * s), (s * s) / (lado * lado * mn)); };
  while (rest.length) {
    const lado = Math.min(w, hh); const row = [rest[0]]; let i = 1;
    while (i < rest.length && pior(row.concat(rest[i]), lado) <= pior(row, lado)) { row.push(rest[i]); i++; }
    const s = row.reduce((a, r) => a + r.a, 0);
    if (w >= hh) { const cw = s / hh; let cy = y; for (const r of row) { const rh = r.a / cw; out.push({ ...r, x, y: cy, w: cw, h: rh }); cy += rh; } x += cw; w -= cw; }
    else { const ch = s / w; let cx = x; for (const r of row) { const rw = r.a / ch; out.push({ ...r, x: cx, y, w: rw, h: ch }); cx += rw; } y += ch; hh -= ch; }
    rest = rest.slice(row.length);
  }
  return out;
}
const corVar = (r) => { if (r == null) return '#1d2634'; const t = Math.max(-1, Math.min(1, r / 0.03)); const m = (a, b, k) => Math.round(a + (b - a) * k);
  return t >= 0 ? `rgb(${m(29, 31, t)},${m(38, 169, t)},${m(52, 113, t)})` : `rgb(${m(29, 196, -t)},${m(38, 56, -t)},${m(52, 74, -t)})`; };
function mapaCalor(setores, modo, abrir) {
  const W = 1000, H = 520, g = sv('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', class: 'treemap', role: 'img', 'aria-label': 'Mapa de calor por setor' });
  const grupos = setores.map((s) => ({ ...s, v: s.itens.reduce((a, i) => a + Math.max(1, i.tamanho), 0) })).sort((a, b) => b.v - a.v);
  squarify(grupos, 0, 0, W, H).forEach((gr) => {
    g.append(sv('text', { x: gr.x + 4, y: gr.y + 11, class: 'setor-tit' }, gr.w > 70 ? gr.setor.slice(0, Math.floor(gr.w / 6.5)) : ''));
    const inner = squarify(gr.itens.map((i) => ({ ...i, v: Math.max(1, i.tamanho) })).sort((a, b) => b.v - a.v), gr.x + 1, gr.y + 15, gr.w - 2, gr.h - 16);
    inner.forEach((it) => {
      const fill = modo === 'luz' ? COR[it.luz] || COR.cinza : corVar(it.ret_1d);
      const e = sv('g', { class: 'it' }, sv('rect', { x: it.x, y: it.y, width: Math.max(0, it.w), height: Math.max(0, it.h), fill }),
        sv('title', {}, `${it.ticker} · índice ${it.indice == null ? '—' : pt(it.indice)} · ${F.pctS(it.ret_1d)}`));
      if (it.w > 44 && it.h > 28) { e.append(sv('text', { x: it.x + 5, y: it.y + 14 }, it.ticker), sv('text', { x: it.x + 5, y: it.y + 27, style: 'font-weight:400' }, modo === 'luz' ? (it.indice == null ? '—' : pt(it.indice)) : F.pctS(it.ret_1d))); }
      e.addEventListener('click', () => abrir(it.id)); g.append(e);
    });
  });
  return g;
}

// ---------------------------------------------------------------- estado e roteamento
const PAINEIS = [['visao', 'Visão global'], ['mercados', 'Mercados mundiais'], ['radar', 'Radar de ações'], ['ranking', 'Ranking de oportunidades'], ['ativo', 'Análise individual'],
  ['macro', 'Inteligência macro'], ['noticias', 'Notícias'], ['indicadores', 'Indicadores'], ['riscos', 'Riscos'], ['previsoes', 'Previsões'], ['historico', 'Histórico'],
  ['autoavaliacao', 'Autoavaliação'], ['gfi-ai', 'Central IA GFI'], ['evolucao', 'Evolução tecnológica'], ['atualizacoes', 'Atualizações'], ['config', 'Configurações'], ['coleta', 'Plano de coleta'], ['saude', 'Saúde dos serviços'], ['carteira', 'Minha Conta']];
const S = { ativo: null, radar: { ordem: 'indice' }, rk: { tipo_ranking: 'geral', n: 20 }, mapa: 'var', painel: 'visao' };
const ir = (nome, arg) => { location.hash = '#' + nome + (arg != null ? '/' + arg : ''); };
const abrirAtivo = (id) => { S.ativo = id; ir('ativo', id); };
const recarregar = () => rota();
async function agir(rota_, corpo, ok) { try { const r = await api(rota_, corpo); if (ok) ok(r); return r; } catch (e) { alert(e.message); } }

async function mostrar(nome, arg) {
  if (carteiraLiveTimer) { clearInterval(carteiraLiveTimer); carteiraLiveTimer = null; }
  S.painel = nome;
  document.querySelectorAll('#nav button').forEach((b) => b.classList.toggle('ativo', b.dataset.p === nome));
  document.querySelectorAll('.mobile-dock [data-p]').forEach((b) => b.classList.toggle('ativo', b.dataset.p === nome));
  document.body.classList.remove('nav-aberto');
  const mais = document.querySelector('.mobile-dock [data-more]'); if (mais) mais.setAttribute('aria-expanded','false');
  const m = $('#main'); m.replaceChildren(h('div', { class: 'carregando' }, 'Carregando…'));
  try { m.replaceChildren(await P[nome](arg)); } catch (e) { m.replaceChildren(aviso('Não foi possível carregar este painel: ' + e.message, 'erro')); }
  m.focus({ preventScroll: true });
}
function rota() { const [nome, arg] = location.hash.slice(1).split('/'); mostrar(PAINEIS.some((p) => p[0] === nome) ? nome : 'visao', arg && /^\d+$/.test(arg) ? Number(arg) : null); }

async function cabecalho() {
  try {
    const s = await api('saude');
    const st = await api('v9/status').catch(() => ({}));
    $('#faixa-demo').hidden = !s.demo;
    const ref = s.cobertura.data_referencia || 'sem referência';
    const coleta = st.ultima_coleta_dados;
    const momento = coleta?.inicio ? new Date(coleta.inicio * 1000).toLocaleString('pt-BR') : 'sem coleta externa registrada';
    const auto = st.atualizacao_automatica || {};
    const autoTxt = auto.habilitado ? ` · auto GFI: 60s (${auto.universo_real_ativo ?? 0} ativos REAL)` : ' · auto GFI: desligada';
    const ciclo = auto.ultima_execucao ? ` · último ciclo: ${new Date(auto.ultima_execucao * 1000).toLocaleTimeString('pt-BR')}` : '';
    $('#t-data').textContent = `referência: ${ref} · coleta: ${momento}${coleta?.fonte ? ' · '+coleta.fonte : ''}${autoTxt}${ciclo}`;
    $('#t-cob').textContent = `cobertura: ${s.cobertura.atualizados}/${s.cobertura.ativos} atualizados`;
    const m = $('#t-modo');
    if (!m.options.length) { s.modos.forEach((x) => m.append(h('option', { value: x }, x))); m.onchange = async () => { await agir('modo', { modo: m.value }, cabecalho); }; }
    m.value = s.modo;
    const n = s.filas.alertas_nao_lidos; $('#t-alertas-n').textContent = n; $('#t-alertas').classList.toggle('tem', n > 0);
  } catch (e) { $('#t-data').textContent = 'sem conexão com a IA'; }
}
$('#saldo-global-ocultar')?.addEventListener('click', () => { saldoGlobalOculto = !saldoGlobalOculto; localStorage.setItem(SALDO_OCULTO_KEY, saldoGlobalOculto ? '1' : '0'); renderSaldoGlobal(); });
async function fita() {
  try {
    const r = await api('radar?' + qs({ ordem: 'ret_1d', n: 400 })), v = r.itens.filter((x) => x.ret_1d != null);
    const pick = [...v.slice(0, 6), ...v.slice(-6)];
    $('#tape').replaceChildren(...pick.map((x) => h('span', { class: x.ret_1d >= 0 ? 'sobe' : 'desce', onclick: () => abrirAtivo(x.id) }, `${x.ticker} ${F.pctS(x.ret_1d)}`)));
  } catch (e) { /* sem dados ainda */ }
}
async function gaveta() {
  const g = $('#gaveta'); if (!g.hidden) { g.hidden = true; return; }
  const a = await api('alertas');
  g.replaceChildren(h('div', { style: 'display:flex;justify-content:space-between;align-items:center' }, h('h2', null, 'Alertas'), btn('Fechar', () => { g.hidden = true; })),
    a.itens.length ? a.itens.map((x) => h('div', { class: 'alerta ' + x.nivel }, h('div', null, x.mensagem), h('small', null, `${F.d(x.criado_em)} · ${x.nivel}`))) : h('div', { class: 'vazio' }, 'Nenhum alerta ainda. Eles só aparecem quando há mudança relevante.'),
    btn('Marcar todos como lidos', async () => { await agir('alertas/lidos', {}); g.hidden = true; cabecalho(); }, 'pri'));
  g.hidden = false;
}

// ---------------------------------------------------------------- painéis
const P = {};
function onboarding() {
  const log = h('div', { class: 'mu' });
  return h('div', { class: 'grade' }, h('h1', null, 'Bem-vindo'),
    h('p', { class: 'sub' }, 'Ainda não há dados. Escolha como começar. A IA só pesquisa e apoia a decisão: não envia ordens nem opera no mercado.'),
    h('div', { class: 'grade g2' },
      card('Dados reais (precisa de internet)', h('p', { class: 'sub' }, 'Baixa as cotações históricas oficiais da B3 e as séries do Banco Central. Pode levar alguns minutos e usa o modo atual para limitar CPU/RAM.'),
        btn('Coletar dados reais agora', async (e) => {
          e.target.disabled = true; log.textContent = 'Coletando cotações da B3…';
          const a = await agir('tarefa', { nome: 'coletar_precos' }); log.textContent = 'Coletando indicadores do Banco Central…';
          const b = await agir('tarefa', { nome: 'coletar_macro' }); log.textContent = 'Calculando pontuações…';
          await agir('recalcular', { todos: true }); log.textContent = 'Concluído: ' + JSON.stringify([a && a.resultado, b && b.resultado]).slice(0, 200); recarregar();
        }, 'pri'), log),
      card('Demonstração (offline)', h('p', { class: 'sub' }, 'Gera 40 empresas FICTÍCIAS (DEMO01…) para você explorar o painel. Tudo é marcado como simulado e nunca se mistura com dados reais.'),
        btn('Gerar demonstração', async () => { await agir('demo/gerar', {}); recarregar(); cabecalho(); fita(); }))));
}
P.visao = async () => {
  const v = await api('visao'), c = v.cobertura;
  if (!c.cadastrados) return onboarding();
  const tot = Object.values(v.distribuicao).reduce((a, b) => a + b, 0) || 1;
  const modo = h('div', { class: 'abas' }, [['var', 'Variação no dia'], ['luz', 'Índice / luz']].map(([k, t]) => h('button', { class: S.mapa === k ? 'ativo' : '', onclick: () => { S.mapa = k; recarregar(); } }, t)));
  return h('div', { class: 'grade' },
    h('div', null, h('h1', null, 'Visão global'), h('p', { class: 'sub' }, `Referência: ${v.data_referencia || '—'}. Índice 0–100 explicável por ativo; cada luz mostra uma dimensão independente.`)),
    h('div', { class: 'grade g4' }, kpi('Ativos monitorados', c.ativos, `${c.cadastrados} cadastrados · ${c.suspensos} suspensos · ${c.deslistados} deslistados`),
      kpi('Dados atualizados', F.n(c.pct_atualizados, 0) + '%', `${c.atualizados} ok · ${c.insuficientes} insuficientes`), kpi('Índice médio', v.indice_medio == null ? '—' : v.indice_medio, 'média dos ativos com cobertura mínima'),
      kpi('Bloqueados', v.bloqueados.length, v.bloqueados.slice(0, 4).join(', ') || 'nenhum evento/risco grave')),
    card('Distribuição das luzes (índice geral)', h('div', { class: 'barra' }, ['verde', 'amarelo', 'vermelho', 'cinza'].map((k) => h('span', { style: `width:${(100 * v.distribuicao[k]) / tot}%;background:${COR[k]}`, title: k + ': ' + v.distribuicao[k] }))),
      h('div', { class: 'mu', style: 'margin-top:6px' }, ['verde', 'amarelo', 'vermelho', 'cinza'].map((k) => `${k} ${v.distribuicao[k]}   `).join('  '))),
    h('div', { class: 'grade', style: 'grid-template-columns:minmax(0,2fr) minmax(280px,1fr)' },
      card('Mapa de calor por setor (tamanho = valor de mercado ou liquidez)', modo, mapaCalor(v.setores, S.mapa, abrirAtivo)),
      h('div', { class: 'grade' }, card('Melhores índices (com qualidade dos dados)', v.top5.length ? h('ol', { class: 'lista' }, v.top5.map((t) => h('li', null, h('a', { href: '#', onclick: (e) => { e.preventDefault(); abrirAtivo(t.id); } }, t.ticker), ' ', pill(t.luz, t.indice == null ? null : pt(t.indice))))) : h('div', { class: 'vazio' }, 'Sem ranking ainda.')),
        card('Macro (hipóteses de efeito por setor editáveis)', v.macro.length ? h('ul', { class: 'lista' }, v.macro.map((t) => h('li', null, t))) : h('div', { class: 'vazio' }, 'Sem séries macroeconômicas.')),
        card('Alertas recentes', v.alertas.length ? v.alertas.map((a) => h('div', { class: 'alerta ' + a.nivel }, a.mensagem)) : h('div', { class: 'vazio' }, 'Sem alertas.')))));
};
P.mercados = async () => {
  const m = await api('mercados');
  return h('div', { class: 'grade' }, h('h1', null, 'Mercados mundiais'), h('p', { class: 'sub' }, 'A cobertura global cresce por conectores independentes (um por fornecedor). Nenhum país é presumido disponível: o que não tem conector aparece como “planejado”.'),
    card('Situação da cobertura', tabela([{ t: 'País', f: (r) => r.pais }, { t: 'Situação', f: (r) => r.situacao, q: true }, { t: 'Ativos cadastrados', n: true, f: (r) => r.ativos }], m.meta_cobertura)),
    card('Universo monitorado agora', m.paises.length ? tabela([{ t: 'País', f: (r) => r.pais }, { t: 'Bolsas (MIC)', f: (r) => r.bolsas.join(', ') }, { t: 'Ativos', n: true, f: (r) => r.n }, { t: 'Índice médio', n: true, f: (r) => r.indice_medio ?? '—' },
      { t: 'Luzes', f: (r) => ['verde', 'amarelo', 'vermelho', 'cinza'].map((k) => (r.luzes[k] ? `${k[0].toUpperCase()}${r.luzes[k]} ` : '')).join('') }], m.paises) : h('div', { class: 'vazio' }, 'Sem ativos.')));
};
P.radar = async () => {
  const q = S.radar, r = await api('radar?' + qs({ ...q, n: 300 })), f = r.filtros;
  const set = (k) => (v) => { S.radar = { ...S.radar, [k]: v }; recarregar(); };
  const num = (k, ph) => h('input', { type: 'number', step: 'any', placeholder: ph, value: q[k] ?? '', style: 'width:130px', onchange: (e) => set(k)(e.target.value) });
  return h('div', { class: 'grade' }, h('h1', null, 'Radar de ações'), h('p', { class: 'sub' }, `${r.total} ativos após os filtros. Clique numa linha para ver a justificativa de cada sinal. As 15 bolinhas são as dimensões, na ordem: ${ORDEM.map((k) => ROT[k]).join(', ')}.`),
    h('div', { class: 'filtros' }, h('input', { type: 'search', placeholder: 'Buscar ticker ou nome', value: q.busca ?? '', onchange: (e) => set('busca')(e.target.value) }),
      sel([['', 'Todos os países'], ...f.paises.map((p) => [p, p])], q.pais, set('pais')), sel([['', 'Todos os setores'], ...f.setores.map((p) => [p, p])], q.setor, set('setor')), sel([['', 'Todos os tipos'], ...f.tipos.map((p) => [p, p])], q.tipo, set('tipo')),
      num('indice_min', 'Índice mín.'), num('risco_max', 'Vol. máx. (0,4 = 40%)'), num('liquidez_min', 'Liquidez mín.'), num('qualidade_min', 'Qualidade mín. (0–1)'), num('min_verdes', 'Mín. sinais verdes'),
      sel([['indice', 'Ordenar: índice'], ['ret_1d', 'variação 1d'], ['ret_1m', 'variação 1m'], ['ret_12m', 'variação 12m'], ['vol', 'volatilidade'], ['liquidez', 'liquidez'], ['qualidade', 'qualidade'], ['ticker', 'ticker']], q.ordem, set('ordem')),
      btn('Limpar', () => { S.radar = { ordem: 'indice' }; recarregar(); })),
    r.itens.length ? tabela([{ t: 'Ativo', f: (x) => h('span', null, h('b', null, x.ticker), ' ', h('span', { class: 'mu' }, (x.nome || '').slice(0, 26))) }, { t: 'País', f: (x) => x.pais }, { t: 'Setor', f: (x) => x.setor.slice(0, 22) },
      { t: 'Preço', n: true, f: (x) => F.n(x.preco) }, { t: '1d', n: true, f: (x) => F.pctS(x.ret_1d), c: (x) => cls(x.ret_1d) }, { t: '1m', n: true, f: (x) => F.pctS(x.ret_1m), c: (x) => cls(x.ret_1m) },
      { t: '12m', n: true, f: (x) => F.pctS(x.ret_12m), c: (x) => cls(x.ret_12m) }, { t: '60 d', f: (x) => spark(x.serie) }, { t: 'Índice', f: (x) => pill(x.luz, x.indice == null ? null : pt(x.indice)) },
      { t: 'Sinais', f: (x) => dots(x.luzes) }, { t: 'Vol.', n: true, f: (x) => F.pct(x.vol, 0) }, { t: 'Liquidez', n: true, f: (x) => F.vol(x.liquidez) }, { t: 'Qualid.', n: true, f: (x) => F.pct(x.qualidade, 0) }], r.itens, (x) => abrirAtivo(x.id))
      : h('div', { class: 'vazio' }, 'Nenhum ativo corresponde aos filtros.'));
};
P.ranking = async () => {
  const [r, base] = await Promise.all([api('ranking?' + qs({ ...S.rk, ...(S.rkf || {}) })), api('radar?n=1')]);
  const setf = (k) => (v) => { S.rkf = { ...(S.rkf || {}), [k]: v }; recarregar(); };
  return h('div', { class: 'grade' }, h('h1', null, 'Ranking de oportunidades'), h('p', { class: 'sub' }, 'Cada ranking usa um critério próprio, pondera a qualidade/atualidade dos dados e exclui ativos bloqueados. Quantidade de sinais verdes NÃO ordena nada. Rankings “[nome-do-pacote]” vêm de atualizações.'),
    h('div', { class: 'abas' }, Object.entries(r.disponiveis).map(([k, t]) => h('button', { class: S.rk.tipo_ranking === k ? 'ativo' : '', onclick: () => { S.rk = { ...S.rk, tipo_ranking: k }; recarregar(); } }, t))),
    h('div', { class: 'filtros' }, [20, 50, 100].map((n) => h('button', { class: 'btn' + (S.rk.n === n ? ' pri' : ''), onclick: () => { S.rk = { ...S.rk, n }; recarregar(); } }, 'TOP ' + n)),
      sel([['', 'Todos os países'], ...base.filtros.paises.map((p) => [p, p])], (S.rkf || {}).pais, setf('pais')), sel([['', 'Todos os setores'], ...base.filtros.setores.map((p) => [p, p])], (S.rkf || {}).setor, setf('setor'))),
    card(r.titulo + ` — ${r.itens.length} de ${r.total_elegiveis} elegíveis`, r.itens.length ? tabela([{ t: '#', n: true, f: (x) => x.posicao }, { t: 'Ativo', f: (x) => h('span', null, h('b', null, x.ticker), ' ', h('span', { class: 'mu' }, (x.nome || '').slice(0, 24))) },
      { t: 'Setor', f: (x) => x.setor || '—' }, { t: 'Índice', f: (x) => pill(x.luz, x.indice == null ? null : pt(x.indice)) }, { t: 'Nota', n: true, f: (x) => F.n(x.valor, 1) }, { t: 'Qualid.', n: true, f: (x) => F.pct(x.qualidade, 0) },
      { t: 'Por que está aqui', q: true, f: (x) => x.por_que }], r.itens, (x) => abrirAtivo(x.id)) : h('div', { class: 'vazio' }, 'Nenhum ativo elegível para este ranking com os filtros atuais.')));
};
const picker = async (titulo, destino) => {
  const busca = S.pick || '', r = await api('radar?' + qs({ busca, n: 40 }));
  return h('div', { class: 'grade' }, h('h1', null, titulo), h('p', { class: 'sub' }, 'Escolha um ativo.'),
    h('div', { class: 'filtros' }, h('input', { type: 'search', placeholder: 'Buscar ticker ou nome', value: busca, onchange: (e) => { S.pick = e.target.value; recarregar(); } })),
    r.itens.length ? tabela([{ t: 'Ativo', f: (x) => h('b', null, x.ticker) }, { t: 'Nome', f: (x) => x.nome }, { t: 'Setor', f: (x) => x.setor }, { t: 'Índice', f: (x) => pill(x.luz, x.indice == null ? null : pt(x.indice)) }], r.itens, (x) => { S.ativo = x.id; ir(destino, x.id); }) : h('div', { class: 'vazio' }, 'Nenhum ativo encontrado.'));
};
const tipoTag = (t) => h('span', { class: 'tag t-' + t }, { fato: 'fato', estimativa: 'estimativa', hipotese: 'hipótese', opiniao: 'opinião da IA' }[t] || t);
P.ativo = async (id) => {
  id = id || S.ativo; if (!id) return picker('Análise individual', 'ativo'); S.ativo = id;
  const a = await api('ativo/' + id), r = a.resultado, m = r.metricas, i = r.inst, R = r.respostas;
  const sinais = ORDEM.map((k) => { const d = r.dimensoes[k]; return h('div', { class: 'sinal l-' + d.luz }, h('div', { class: 'cab' }, h('b', null, ROT[k]), pill(d.luz, d.score == null ? null : pt(d.score))),
    d.score != null && h('div', { class: 'fita' }, h('span', { style: `width:${d.score}%;background:${COR[d.luz]}` })), h('div', { class: 'rz' }, d.razao),
    d.itens.length ? h('ul', null, d.itens.map((t) => h('li', null, tipoTag(t.tipo), t.texto))) : null, d.fonte && h('div', { class: 'mu', style: 'font-size:11px' }, `fonte: ${d.fonte}${d.atualizado_em ? ' · ref.: ' + d.atualizado_em : ''}`)); });
  const v = r.valuation;
  return h('div', { class: 'grade' },
    a.demo && aviso('Dados SIMULADOS (demonstração).'),
    card(null, h('div', { class: 'cab-ativo' }, h('div', null, h('div', { class: 'grande' }, i.ticker, ' ', pill(r.luz, r.indice == null ? null : pt(r.indice))), h('div', { class: 'sub', style: 'margin:2px 0' }, `${i.nome || ''} · ${i.setor || 'sem setor'} · ${i.pais} · ${i.mic} · ${i.tipo || ''}`),
      h('div', null, h('span', { class: 'grande', style: 'font-size:22px' }, F.n(m.preco)), ' ', h('span', { class: cls(m.ret_1d) }, F.pctS(m.ret_1d)), h('span', { class: 'mu' }, '  1m '), h('span', { class: cls(m.ret_1m) }, F.pctS(m.ret_1m)), h('span', { class: 'mu' }, '  12m '), h('span', { class: cls(m.ret_12m) }, F.pctS(m.ret_12m)))),
      gauge(r.indice, r.luz), h('div', { class: 'mu' }, h('div', null, 'Qualidade dos dados: ', h('b', null, F.pct(r.qualidade, 0))), h('div', null, 'Cobertura das dimensões: ', h('b', null, F.pct(r.cobertura, 0))),
        h('div', null, 'Sinais: ', h('b', { class: 'pos' }, r.contagem.verde + 'V '), h('b', { style: 'color:var(--amar)' }, r.contagem.amarelo + 'A '), h('b', { class: 'neg' }, r.contagem.vermelho + 'R '), h('b', null, r.contagem.cinza + 'C'))),
      h('div', null, btn('Indicadores', () => ir('indicadores', id)), ' ', btn('Histórico', () => ir('historico', id)))),
      r.bloqueado && aviso('BLOQUEIO: ' + r.bloqueios.join(' · '), 'erro'), r.penalizacoes.length ? aviso('Penalizações: ' + r.penalizacoes.join(' · ')) : null,
      r.problemas_dados.length ? aviso('Qualidade dos dados: ' + r.problemas_dados.join(' · ')) : null),
    card('Preço (candles diários)', velas(a.candles)),
    h('h2', { style: 'margin-top:6px' }, 'Os 15 sinais — cada um com a sua justificativa (cinza = dado insuficiente, nunca verde)'), h('div', { class: 'grade g3' }, sinais),
    h('div', { class: 'grade g2' },
      card('Composição do índice (explicável e configurável)', tabela([{ t: 'Dimensão', f: (x) => x.rotulo }, { t: 'Peso', n: true, f: (x) => x.peso }, { t: 'Nota', n: true, f: (x) => x.score == null ? '—' : pt(x.score) }, { t: 'Luz', f: (x) => pill(x.luz, '') },
        { t: 'Contribuição', n: true, f: (x) => x.contribuicao == null ? '—' : F.n(x.contribuicao, 1) }], r.composicao), h('p', { class: 'sub', style: 'margin-top:8px' }, R['1_por_que'])),
      card('Valuation (estimativa com premissas)', v && v.veredito !== 'impossivel' ? h('div', null, h('p', null, 'Veredito: ', h('b', null, v.veredito), v.armadilha_valor.alerta ? ' — ALERTA de armadilha de valor' : ''),
        tabela([{ t: 'Cenário', f: (x) => x[0] }, { t: 'Valor justo', n: true, f: (x) => F.n(x[1].valor_justo) }, { t: 'vs preço', n: true, f: (x) => F.pctS(x[1].margem), c: (x) => cls(x[1].margem) }, { t: 'Cresc.', n: true, f: (x) => F.pct(x[1].crescimento) }, { t: 'Desconto', n: true, f: (x) => F.pct(x[1].taxa_desconto) }], Object.entries(v.cenarios)),
        h('p', { class: 'mu' }, 'Múltiplos: ', ['p_l', 'p_vp', 'ev_ebitda', 'p_fcf', 'dy', 'peg'].filter((k) => v.multiplos[k] != null).map((k) => `${k.toUpperCase().replace('_', '/')} ${k === 'dy' ? F.pct(v.multiplos[k]) : F.n(v.multiplos[k], 1)}`).join(' · ')),
        v.armadilha_valor.motivos.length ? h('p', { class: 'neg' }, 'Motivos: ' + v.armadilha_valor.motivos.join('; ')) : null, h('p', { class: 'mu', style: 'font-size:11px' }, v.limitacoes.join(' '))) : h('div', { class: 'vazio' }, 'Sem fundamentos suficientes: não é possível avaliar (sinal cinza).'))),
    card('As 10 perguntas', h('div', { class: 'grade g2' }, [['2_positivos', '2. Quais indicadores foram positivos?'], ['3_negativos', '3. Quais foram negativos?'], ['4_acontecimentos', '4. Quais acontecimentos influenciaram?'], ['5_fontes', '5. Quais fontes foram consultadas?'],
      ['7_melhorar', '7. O que pode melhorar a classificação?'], ['8_piorar', '8. O que pode piorar?'], ['9_riscos', '9. Principais riscos'], ['10_faltando', '10. O que ainda está faltando?']].map(([k, t]) => h('div', null, h('h3', null, t), R[k].length ? h('ul', { class: 'lista' }, R[k].map((x) => h('li', null, x))) : h('span', { class: 'mu' }, 'nada a registrar')))),
      h('h3', null, '6. Quando os dados foram atualizados?'), h('div', { class: 'mu' }, Object.entries(R['6_atualizacao']).map(([k, d]) => `${ROT[k]}: ${d}`).join(' · ') || '—')),
    card('Separação: fatos × estimativas × hipóteses × opiniões da IA', h('div', { class: 'grade g4' }, [['fatos', 'fato'], ['estimativas', 'estimativa'], ['hipoteses', 'hipotese'], ['opinioes', 'opiniao']].map(([k, t]) => h('div', null, h('h3', null, tipoTag(t)), h('ul', { class: 'lista' }, R.separacao[k].length ? R.separacao[k].map((x) => h('li', { style: 'font-size:12px' }, x)) : [h('li', { class: 'mu' }, 'nenhum')]))))),
    a.previsoes.length ? card('Previsões registradas para este ativo (imutáveis)', tabela([{ t: 'Data-base', f: (x) => x.data_base }, { t: 'Horizonte', n: true, f: (x) => x.horizonte_dias + ' pregões' }, { t: 'Direção esperada', f: (x) => x.direcao },
      { t: 'Resultado', f: (x) => x.acertou == null ? 'aguardando' : x.acertou ? 'acertou' : 'errou', c: (x) => x.acertou == null ? 'mu' : x.acertou ? 'pos' : 'neg' }, { t: 'Retorno', n: true, f: (x) => F.pctS(x.retorno) }], a.previsoes)) : null);
};
P.macro = async () => {
  const m = await api('macro'), cel = (v) => v == null ? h('td', { class: 'c mu' }, '·') : h('td', { class: 'c', style: `background:${v > 0 ? '#1fbf7530' : v < 0 ? '#ef4b5a30' : 'transparent'};color:${v > 0 ? COR.verde : v < 0 ? COR.verm : '#8393a8'}` }, (v > 0 ? '+' : '') + v);
  return h('div', { class: 'grade' }, h('h1', null, 'Inteligência macroeconômica'), h('p', { class: 'sub' }, `Fonte: ${m.fonte}. O mesmo fato afeta setores de formas diferentes: a matriz abaixo são HIPÓTESES editáveis (−2 muito negativo … +2 muito positivo), não fatos.`),
    m.series.length ? h('div', { class: 'grade g2' }, m.series.map((s) => card(s.nome, h('div', { class: 'grande', style: 'font-size:20px' }, F.n(s.ultimo[1])), h('div', { class: 'mu' }, 'em ' + s.ultimo[0]), linha(s.pontos)))) : aviso('Sem séries macroeconômicas. Colete em Configurações → Dados.'),
    card('Fatores calculados', Object.keys(m.fatores).length ? h('ul', { class: 'lista' }, Object.entries(m.fatores).map(([k, f]) => h('li', null, h('b', null, k), ': ', f.texto, ` — direção ${f.direcao > 0 ? 'sobe' : f.direcao < 0 ? 'cai' : 'estável'}`))) : h('span', { class: 'mu' }, 'indisponíveis')),
    card('Sensibilidade fator × setor (efeito de a direção do fator ser “sobe”)', h('div', { class: 'tw' }, h('table', { class: 'sens' }, h('thead', null, h('tr', null, h('th', null, 'Setor'), Object.keys(m.sensibilidade).map((f) => h('th', { class: 'num' }, f)))),
      h('tbody', null, m.setores.map((s) => h('tr', null, h('td', null, s), Object.keys(m.sensibilidade).map((f) => cel(m.sensibilidade[f][s])))))))),
    m.faltando.length ? aviso('Séries ainda sem dados: ' + m.faltando.join(', ')) : null);
};
P.noticias = async () => {
  const n = await api('noticias'), lista = n.eventos || [];
  return h('div', { class: 'grade' }, h('h1', null, '07 — Notícias'), h('p', { class: 'sub' }, 'Notícias financeiras consultadas em fontes públicas. Consulte a publicação original; a GFI registra a coleta.'),
    h('div', { class: 'filtros' }, btn('Atualizar notícias agora', async () => { const r=await agir('noticias/atualizar', {}, () => mostrar('noticias')); if(r) alert(`Consulta concluída: ${r.eventos.length} notícias em cache. ${r.erros.length} falha(s).`); }, 'pri'), h('span',{class:'mu'}, 'Última coleta: '+(n.atualizado_em || 'ainda não consultada'))),
    n.erros?.length ? aviso('Falha parcial de fonte: '+n.erros.join(' · ')) : null,
    lista.length ? card('Feed de notícias', ...lista.slice(0,60).map(x=>h('article',{class:'news-item'},h('a',{href:x.url,target:'_blank',rel:'noopener noreferrer'},x.titulo || x.ticker || 'Notícia'),h('div',{class:'news-meta'},`${x.fonte || 'Fonte externa'} · publicado: ${x.publicado_em || 'horário não informado'} · coletado: ${x.coletado_em || 'registro anterior'}`), x.resumo ? h('div',{class:'news-summary'},String(x.resumo).replace(/<[^>]*>/g,' ').slice(0,500)) : null))) : h('div',{class:'vazio'},'Ainda não há notícias armazenadas. Use “Atualizar notícias agora” para consultar as fontes.'));
};

P.indicadores = async (id) => {
  id = id || S.ativo; if (!id) return picker('Indicadores', 'indicadores'); S.ativo = id;
  const d = await api('indicadores/' + id), t = d.tecnico || {}, ind = t.indicadores || {};
  const hz = [['curto', 'Curto prazo'], ['medio', 'Médio prazo'], ['longo', 'Longo prazo']];
  const lin = [['Fechamento', F.n(ind.fechamento)], ['RSI (14)', F.n(ind.rsi14, 1)], ['MACD / sinal / hist.', ind.macd ? ind.macd.map((x) => F.n(x, 3)).join(' / ') : '—'], ['Bollinger %B', ind.bollinger ? F.n(ind.bollinger.pct_b, 2) : '—'],
    ['ATR (14) % do preço', F.pct(ind.atr_pct, 2)], ['ADX / +DI / −DI', ind.adx14 ? ind.adx14.map((x) => F.n(x, 1)).join(' / ') : '—'], ['OBV (tendência 20 d)', F.n(ind.obv20, 2)], ['VWAP (20 d)', F.n(ind.vwap20)],
    ['Momentum 21 / 63 / 252 d', [ind.mom21, ind.mom63, ind.mom252].map((x) => F.pctS(x)).join(' / ')], ['Médias 20 / 50 / 200', [ind.sma20, ind.sma50, ind.sma200].map((x) => F.n(x)).join(' / ')], ['Volatilidade anualizada (63 d)', F.pct(ind.vol63)],
    ['Suporte / resistência (60 d)', F.n(ind.suporte) + ' / ' + F.n(ind.resistencia)]];
  return h('div', { class: 'grade' }, h('h1', null, 'Indicadores — ' + d.ticker), h('p', { class: 'sub' }, 'Sinais separados por horizonte. Nenhum indicador isolado vira recomendação: indicadores correlacionados são agrupados e contam uma vez.'),
    h('div', { class: 'grade g3' }, hz.map(([k, tt]) => card(tt, h('div', { class: 'grande' }, t[k] == null ? '—' : pt(t[k])), h('div', { class: 'fita' }, h('span', { style: `width:${t[k] || 0}%;background:${t[k] == null ? COR.cinza : t[k] >= 60 ? COR.verde : t[k] >= 40 ? COR.amarelo : COR.verm}` })), h('div', { class: 'mu' }, t[k] == null ? 'histórico insuficiente' : 'de 100')))),
    card('Valores', tabela([{ t: 'Indicador', f: (x) => x[0] }, { t: 'Valor', f: (x) => x[1], c: () => 'mono' }], lin)),
    card('Indicadores de atualizações', Object.keys(d.extras).length ? tabela([{ t: 'Indicador', f: (x) => x[0] }, { t: 'Valor', n: true, f: (x) => F.n(x[1], 4) }], Object.entries(d.extras)) : h('div', { class: 'vazio' }, 'Nenhum. Veja a pasta atualizacoes/_modelos/modelo-indicador-ranking.')),
    btn('← Voltar à análise', () => ir('ativo', id)));
};
P.riscos = async () => {
  const r = await api('riscos'), mx = Math.max(...r.exposicao_setorial.map((s) => s.vol_media), 0.01);
  return h('div', { class: 'grade' }, h('h1', null, 'Riscos'), h('p', { class: 'sub' }, 'Risco absoluto e relativo. VaR histórico e drawdown são ESTIMATIVAS do passado, não certezas. Os 30 ativos com pior nota de risco:'),
    r.alertas_criticos.length ? card('Alertas críticos', r.alertas_criticos.map((a) => h('div', { class: 'alerta critico' }, a.mensagem))) : null,
    card('Ativos de maior risco', tabela([{ t: 'Ativo', f: (x) => h('b', null, x.ticker) }, { t: 'Setor', f: (x) => x.setor }, { t: 'Nota de risco', n: true, f: (x) => x.risco_score == null ? '—' : pt(x.risco_score) }, { t: 'Vol. anual', n: true, f: (x) => F.pct(x.vol, 0) },
      { t: 'Drawdown 12m', n: true, f: (x) => F.pct(x.max_drawdown, 0), c: () => 'neg' }, { t: 'Beta', n: true, f: (x) => x.beta == null ? '—' : F.n(x.beta) }, { t: 'Liquidez', n: true, f: (x) => F.vol(x.liquidez) }, { t: 'Bloqueio / penalização', q: true, f: (x) => [...x.bloqueios, ...x.penalizacoes].join(' · ') || '—' }], r.ativos, (x) => abrirAtivo(x.id))),
    card('Exposição setorial (volatilidade média)', r.exposicao_setorial.sort((a, b) => b.vol_media - a.vol_media).map((s) => h('div', { style: 'display:grid;grid-template-columns:200px 1fr 90px;gap:10px;align-items:center;margin:4px 0' }, h('span', null, s.setor), h('div', { class: 'fita' }, h('span', { style: `width:${(100 * s.vol_media) / mx}%;background:${COR.amarelo}` })), h('span', { class: 'mono num' }, F.pct(s.vol_media, 0) + ` (${s.n})`)))));
};
P.previsoes = async () => {
  const p = await api('previsoes'), m = p.metricas;
  return h('div', { class: 'grade' }, h('h1', null, 'Previsões'), h('p', { class: 'sub' }, p.aviso), p.cadeia_integra ? h('div', { class: 'ok-box' }, 'Cadeia de hashes ÍNTEGRA: nenhuma previsão foi alterada ou apagada.') : aviso('ATENÇÃO: a cadeia foi quebrada a partir da previsão #' + p.primeiro_adulterado, 'erro'),
    h('div', { class: 'grade g4' }, kpi('Registradas', m.previsoes_registradas), kpi('Avaliadas', m.avaliadas), kpi('Taxa de acerto', m.taxa_acerto == null ? '—' : F.pct(m.taxa_acerto, 0), 'compare com a taxa-base'), kpi('Taxa-base de alta', m.taxa_base_alta == null ? '—' : F.pct(m.taxa_base_alta, 0), 'fração de ativos que subiram')),
    aviso('Evidência estatística: ' + m.evidencia + (m.vantagem == null ? '' : ` (acerto ${F.pct(m.taxa_acerto, 0)} vs estratégia ingênua ${F.pct(m.acerto_ingenuo, 0)}; z = ${m.z})`)),
    p.itens.length ? tabela([{ t: '#', n: true, f: (x) => x.id }, { t: 'Ativo', f: (x) => h('b', null, x.ticker) }, { t: 'Data-base', f: (x) => x.data_base }, { t: 'Horizonte', n: true, f: (x) => x.horizonte_dias + ' pregões' }, { t: 'Direção', f: (x) => x.direcao },
      { t: 'Resultado', f: (x) => x.acertou == null ? 'aguardando' : x.acertou ? 'acertou' : 'errou', c: (x) => x.acertou == null ? 'mu' : x.acertou ? 'pos' : 'neg' }, { t: 'Retorno', n: true, f: (x) => F.pctS(x.retorno) }, { t: 'Hash', f: (x) => x.hash.slice(0, 10), c: () => 'mono mu' }], p.itens) : h('div', { class: 'vazio' }, 'Nenhuma previsão registrada ainda.'));
};
P.historico = async (id) => {
  id = id || S.ativo; if (!id) return picker('Histórico', 'historico'); S.ativo = id;
  const a = await api('ativo/' + id), pts = a.historico_indice.filter((x) => x.indice != null).map((x) => [x.data, x.indice]);
  return h('div', { class: 'grade' }, h('h1', null, 'Histórico — ' + a.resultado.inst.ticker), h('p', { class: 'sub' }, 'O histórico do índice se forma a cada recálculo (a análise de cada data fica registrada). Quanto mais a IA roda, mais longa a linha.'),
    card('Índice geral ao longo do tempo', pts.length > 1 ? linha(pts, { cor: '#7cc4ff', fmt: (x) => F.n(x, 0) }) : h('div', { class: 'vazio' }, 'Só há um ponto por enquanto. Na demonstração use Configurações → “Avançar 5 dias” e recalcule.')),
    card('Preço', velas(a.candles)), btn('← Voltar à análise', () => ir('ativo', id)));
};
P.autoavaliacao = async () => {
  const bt = await api('backtest'), a = await api('autoavaliacao'), m = a.metricas, d = m.por_direcao || {};
  return h('div', { class: 'grade' }, h('h1', null, 'Autoavaliação'), h('p', { class: 'sub' }, 'A IA julga a própria qualidade comparando previsões antigas com o que realmente aconteceu. Nenhuma previsão é alterada depois do fato.'),
    a.cadeia_integra ? h('div', { class: 'ok-box' }, 'Histórico imutável íntegro.') : aviso('Histórico adulterado!', 'erro'),
    h('div', { class: 'grade g4' }, kpi('Avaliadas', m.avaliadas, `de ${m.previsoes_registradas} registradas`), kpi('Acerto geral', m.taxa_acerto == null ? '—' : F.pct(m.taxa_acerto, 0), 'alta/baixa/neutra'),
      kpi('Falsos positivos', m.falsos_positivos, 'previu alta, caiu'), kpi('Falsos negativos', m.falsos_negativos, 'não previu alta, subiu >5%'),
      kpi('Excesso de confiança', m.excesso_confianca == null ? '—' : F.n(m.excesso_confianca, 2), '>0: índices altos acertam menos'), kpi('Degradação recente', m.degradacao == null ? '—' : F.n(m.degradacao, 2), 'últimas vs histórico')),
    aviso('Evidência de habilidade: ' + m.evidencia + (m.vantagem == null ? '' : ` — vantagem sobre a estratégia ingênua: ${F.n(m.vantagem * 100, 1)} p.p. (z = ${m.z})`)),
    card('Acerto por direção', tabela([{ t: 'Direção', f: (x) => x[0] }, { t: 'Previsões', n: true, f: (x) => x[1].n }, { t: 'Acerto', n: true, f: (x) => x[1].acerto == null ? '—' : F.pct(x[1].acerto, 0) }], Object.entries(d))),
    card('Backtest fora da amostra (sem look-ahead, com custos, comparado ao acaso)', bt.vazio ? h('div', null, h('p', { class: 'sub' }, 'Ainda não executado. Em cada data a IA vê só o que existia até ali, monta a carteira dos maiores índices, segura 21 pregões e é comparada ao universo e a carteiras aleatórias.'),
      btn('Rodar backtest agora', async (e) => { e.target.disabled = true; e.target.textContent = 'Calculando… (pode levar 1 min)'; await agir('tarefa', { nome: 'backtest' }, recarregar); e.target.disabled = false; }, 'pri'))
      : bt.erro ? h('div', null, aviso(bt.erro), btn('Tentar de novo', () => agir('tarefa', { nome: 'backtest' }, recarregar)))
      : h('div', null, bt.demo && aviso('Dados de DEMONSTRAÇÃO: têm tendências embutidas de propósito. Este resultado NÃO prova nada sobre o mercado real.'),
        h('div', { class: bt.veredito.startsWith('SEM') || bt.veredito.startsWith('INCONC') ? 'aviso' : 'ok-box' }, 'Veredito: ' + bt.veredito),
        h('div', { class: 'grade g4', style: 'margin-top:10px' }, kpi('Carteira (média/período)', F.pctS(bt.retorno_medio_carteira)), kpi('Universo (média/período)', F.pctS(bt.retorno_medio_universo)), kpi('Excesso médio', F.pctS(bt.excesso_medio), `t = ${bt.t_estatistica} · ${bt.periodos_vencedores}/${bt.n_periodos} períodos`),
          kpi('Chance de ser sorte', F.pct(bt.prob_ser_acaso, 0), 'vs. 500 carteiras aleatórias'), kpi('Acumulado carteira', F.pctS(bt.acumulado_carteira)), kpi('Acumulado universo', F.pctS(bt.acumulado_universo)), kpi('Pior queda da carteira', F.pct(bt.max_drawdown_carteira, 0))),
        tabela([{ t: 'Início', f: (x) => x.inicio }, { t: 'Fim', f: (x) => x.fim }, { t: 'Ativos', n: true, f: (x) => x.n_carteira + '/' + x.n_universo }, { t: 'Carteira (líq.)', n: true, f: (x) => F.pctS(x.carteira), c: (x) => cls(x.carteira) }, { t: 'Universo', n: true, f: (x) => F.pctS(x.universo), c: (x) => cls(x.universo) }, { t: 'Excesso', n: true, f: (x) => F.pctS(x.excesso), c: (x) => cls(x.excesso) }], bt.periodos),
        h('ul', { class: 'lista mu' }, bt.limitacoes.map((x) => h('li', null, x))), btn('Rodar de novo', () => agir('tarefa', { nome: 'backtest' }, recarregar)))),
    card('Recomendações da própria IA', a.recomendacoes.length ? h('ul', { class: 'lista' }, a.recomendacoes.map((r) => h('li', null, h('b', null, r.tipo), ': ', r.texto))) : h('span', { class: 'mu' }, 'Sem recomendações.'), h('p', { class: 'mu' }, 'Recomendações viram propostas em “Evolução tecnológica”, que só valem depois da SUA aprovação.')));
};
P['gfi-ai'] = async () => {
  const e = await api('gfi-ai');
  const intervalo = h('input', { class: 'campo', type: 'number', min: '1', max: '168', value: e.intervalo_horas || 24, style: 'width:110px' });
  const relatorios = e.relatorios || [];
  const abrir = async (id) => {
    try {
      const r = await api('gfi-ai/relatorio/' + encodeURIComponent(id));
      const painel = card('Relatório completo · ' + id, h('pre', { class: 'ia-relatorio' }, r.conteudo));
      const m = $('#main'); m.append(painel); painel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) { alert(err.message); }
  };
  return h('div', { class: 'grade' },
    h('h1', null, 'Central de Inteligência Artificial · GFI'),
    h('p', { class: 'sub' }, 'Agente de evolução autônoma supervisionada (nível 3). Pesquisa oportunidades, diagnostica o projeto e prepara relatórios e código experimental. A produção permanece sob seu controle.'),
    h('div', { class: 'grade g4' },
      kpi('Autonomia', 'Nível 3', 'evolução supervisionada'),
      kpi('Modelo de linguagem', e.modelo === 'sem_modelo_configurado' ? 'Não conectado' : (e.provedor_detectado || 'Modelo conectado'), e.modelo_status?.detalhe || 'Estado verificado no servidor'),
      kpi('Agente periódico', e.ativo ? 'Ativo' : 'Pausado', 'intervalo: ' + (e.intervalo_horas || 24) + ' h'),
      kpi('Último ciclo', e.ultima_execucao ? F.d(e.ultima_execucao) : 'Ainda não executou', e.ultimo_status || '—')),
    e.modelo === 'sem_modelo_configurado' ? aviso((e.modelo_status?.detalhe || 'Nenhum modelo respondeu.') + ' A central procura automaticamente NEXUS/llama.cpp (8080), LM Studio (1234) e Ollama (11434). Para provedor remoto, configure GFI_AI_LLM_URL via ambiente seguro.', 'aviso') : aviso('Modelo de linguagem conectado: ' + (e.provedor_detectado || e.modelo) + '. A disponibilidade é verificada no servidor.'),
    card('Converse com a IA GFI', (() => {
      const pergunta = h('textarea', { class: 'campo', rows: '3', placeholder: 'Pergunte sobre a arquitetura, dados, indicadores, falhas ou evolução da GFI…', style: 'width:100%;resize:vertical' });
      const saida = h('div', { class: 'ia-relatorio', style: 'white-space:pre-wrap;min-height:70px' }, 'Aguardando sua pergunta.');
      const enviar = btn('Perguntar à IA GFI', async (ev) => {
        if (!pergunta.value.trim()) return alert('Digite uma pergunta.');
        ev.target.disabled = true; ev.target.textContent = 'Consultando…'; saida.textContent = 'A IA está processando sua solicitação…';
        try { const r = await api('gfi-ai/chat', { mensagem: pergunta.value }); saida.textContent = (r.modo === 'llm' ? 'IA GENERATIVA · ' + (r.provedor || 'modelo conectado') : 'MODO LOCAL · diagnóstico sem LLM') + '\n\n' + r.resposta; }
        catch (err) { saida.textContent = 'Falha na consulta: ' + err.message; }
        finally { ev.target.disabled = false; ev.target.textContent = 'Perguntar à IA GFI'; }
      }, 'pri');
      return h('div', { class: 'grade' }, h('p', { class: 'sub' }, 'Faça uma pergunta e veja a resposta imediatamente. Se houver um modelo conectado, a resposta será generativa; caso contrário, o painel executa diagnóstico local e informa a limitação.'), pergunta, enviar, saida);
    })()),
    card('Controle do agente', h('div', { class: 'filtros' },
      btn('Executar ciclo agora', async (ev) => { ev.target.disabled = true; ev.target.textContent = 'Analisando…'; await agir('gfi-ai/ciclo', {}, () => mostrar('gfi-ai')); ev.target.disabled = false; }, 'pri'),
      btn(e.ativo ? 'Pausar pesquisa automática' : 'Ativar pesquisa automática', () => agir('gfi-ai/configurar', { ativo: !e.ativo }, () => mostrar('gfi-ai'))),
      intervalo, btn('Salvar intervalo (horas)', () => agir('gfi-ai/configurar', { intervalo_horas: Number(intervalo.value) }, () => mostrar('gfi-ai')))),
      h('p', { class: 'mu' }, 'O ciclo automático roda no servidor local. A pesquisa usa fontes públicas; não baixa nem executa programas externos.')),
    card('O que a IA pode fazer', h('ul', { class: 'lista' },
      h('li', null, 'Examinar estrutura, documentação, cobertura de dados, filas e falhas de coleta.'),
      h('li', null, 'Pesquisar documentação e tecnologias na Internet, registrando links de referência.'),
      h('li', null, 'Gerar diagnóstico, prioridades, código proposto e caminho exato para revisão.'),
      h('li', null, 'Guardar código somente em laboratorio/gfi_ai/propostas/.'),
      h('li', null, 'Preparar melhorias para testes e avaliação humana.'))),
    card('Limites de segurança', h('ul', { class: 'lista' }, e.limites.map((x) => h('li', null, x))),
      aviso('O agente ainda não aplica alterações, não executa código gerado e não tem permissão para modificar arquivos protegidos. A aprovação humana é obrigatória.')),
    card('Histórico de análises', relatorios.length ? relatorios.map((r) => h('div', { class: 'tarefa-coleta' },
      h('div', { class: 'tarefa-info' }, h('b', null, r.id), h('small', null, F.d(r.criado_em) + ' · ' + r.status + ' · modelo: ' + r.modelo),
        r.codigo ? h('small', null, 'Código: ' + r.codigo + ' · sintaxe: ' + r.validacao_sintaxe + (r.riscos_codigo && r.riscos_codigo.length ? ' · alertas: ' + r.riscos_codigo.join(', ') : ' · sem alertas estáticos detectados')) : h('small', null, 'Nenhum arquivo de código foi gerado neste ciclo.')),
      btn('Ler relatório', () => abrir(r.id)))) : h('div', { class: 'vazio' }, 'Nenhum relatório foi gerado ainda. Execute o primeiro ciclo.'),
      h('p', { class: 'mu' }, 'Relatórios e arquivos ficam na pasta de dados/laboratório da GFI; nenhum pacote é ativado automaticamente.')));
};

P.evolucao = async () => {
  const e = await api('evolucao'), titulo = h('input', { class: 'campo', placeholder: 'Título da proposta', style: 'min-width:260px' }), pesos = h('input', { class: 'campo', placeholder: 'Pesos, ex.: tecnica=6, risco=13', style: 'min-width:260px' });
  const passos = (p) => h('div', { class: 'passos' }, e.estados.map((s, i) => h('span', { class: 'passo ' + (e.estados.indexOf(p.estado) > i ? 'feito' : p.estado === s ? 'atual' : '') }, s)));
  return h('div', { class: 'grade' }, h('h1', null, 'Evolução tecnológica'), h('p', { class: 'sub' }, 'PESQUISA → PROPOSTA → EXPERIMENTAL → TESTES → COMPARAÇÃO → APROVAÇÃO → PUBLICAÇÃO. A IA propõe e testa; só VOCÊ publica (digitando APROVO). Regras de segurança nunca podem ser alteradas por ela.'),
    card('Nova proposta de ajuste de pesos', h('div', { class: 'filtros' }, titulo, pesos, btn('Criar proposta', async () => {
      const mud = {}; pesos.value.split(',').forEach((x) => { const [k, v] = x.split('=').map((s) => s.trim()); if (k && !isNaN(Number(v))) mud[k] = Number(v); });
      if (!titulo.value.trim() || !Object.keys(mud).length) return alert('Informe um título e ao menos um peso (ex.: tecnica=6).');
      await agir('evolucao/criar', { titulo: titulo.value, descricao: 'Criada pelo usuário', mudanca: { pesos: mud } }, recarregar);
    }, 'pri'))),
    e.propostas.length ? e.propostas.map((p) => card(`#${p.id} · ${p.titulo}`, h('div', { class: 'mu' }, `${p.origem} · ${p.estado}`), passos(p), p.descricao ? h('p', null, p.descricao) : null,
      p.arquivos.mudanca ? h('p', { class: 'mono' }, 'Mudança: ' + JSON.stringify(p.arquivos.mudanca)) : null,
      p.resultado_testes ? h('div', { class: p.resultado_testes.ok ? 'ok-box' : 'erro' }, (p.resultado_testes.ok ? 'Testes aprovados. ' : 'Testes reprovados. ') + (p.resultado_testes.verificacoes || []).map((v) => `${v.ok ? '✔' : '✘'} ${v.teste}`).join('  ') + (p.resultado_testes.comparacao ? `  ·  TOP 20: ${p.resultado_testes.comparacao.mudancas_no_top20 ?? '—'} mudança(s)` : '')) : null,
      p.historico.length ? h('div', { class: 'mu', style: 'font-size:11px;margin-top:6px' }, p.historico.slice(-3).map((x) => F.d(x.ts) + ' — ' + x.evento).join(' | ')) : null,
      h('div', { class: 'filtros', style: 'margin-top:8px' }, !['rejeitada', 'publicada', 'revertida'].includes(p.estado) && [btn('Executar testes', () => agir('evolucao/testar', { id: p.id }, recarregar)), p.estado !== 'aprovacao' && btn('Avançar etapa', () => agir('evolucao/avancar', { id: p.id }, recarregar)),
        p.estado === 'aprovacao' && btn('Aprovar e publicar…', () => { const t = prompt('Para publicar esta alteração digite APROVO'); if (t) agir('evolucao/aprovar', { id: p.id, confirmacao: t }, recarregar); }, 'pri'), btn('Rejeitar', () => agir('evolucao/rejeitar', { id: p.id }, recarregar), 'perigo')],
        p.estado === 'publicada' && btn('Reverter', () => agir('evolucao/reverter', { id: p.id }, recarregar), 'perigo')))) : h('div', { class: 'vazio' }, 'Nenhuma proposta ainda. A autoavaliação cria propostas quando encontra problemas.'),
    card('Fila inteligente de pesquisas', e.fila_pesquisa.length ? tabela([{ t: 'Prioridade', n: true, f: (x) => x.prioridade }, { t: 'Pesquisa', q: true, f: (x) => x.titulo }, { t: 'Motivo', q: true, f: (x) => x.motivo }, { t: 'Estado', f: (x) => x.estado }], e.fila_pesquisa) : h('div', { class: 'vazio' }, 'Fila vazia: nenhuma lacuna conhecida agora.')),
    card('Protegido contra edição pela IA', h('div', { class: 'mono mu' }, e.protegidos.join('  ·  '))), aviso(e.relatorio_tecnologias));
};
P.atualizacoes = async () => {
  const a = await api('atualizacoes'), est = { ativa: ['ATIVA', 'ok-box'], nova: ['NOVA — aguardando sua ativação', 'aviso'], desativada: ['desativada', 'aviso'], alterada: ['ALTERADA — reative para aprovar a nova versão', 'aviso'], erro: ['COM ERROS', 'erro'] };
  return h('div', { class: 'grade' }, h('h1', null, 'Atualizações'), h('p', { class: 'sub' }, 'Solte uma pasta ou .zip em atualizacoes/ (veja LEIAME.md e os modelos em _modelos/), clique em Recarregar e ative. Nada executa sem o seu clique.'),
    a.modo_seguro ? aviso('MODO SEGURO ligado: nenhuma atualização é carregada (arquivo atualizacoes/DESLIGADO ou GFI_SEM_ATUALIZACOES=1).', 'erro') : null,
    h('div', { class: 'filtros' }, btn('Recarregar pasta', recarregar, 'pri'), h('span', { class: 'mu' }, 'Pasta: ' + a.pasta)),
    a.pacotes.length ? a.pacotes.map((p) => card(`${p.manifesto.nome || p.pasta}  ·  v${p.manifesto.versao || '?'}`, h('div', { class: est[p.estado][1] }, est[p.estado][0]), h('p', { class: 'sub', style: 'margin:8px 0' }, p.manifesto.descricao || ''),
      h('div', { class: 'mu' }, `id: ${p.id} · tipos: ${p.tipos.join(', ') || '—'} · autor: ${p.manifesto.autor || '—'}${(p.manifesto.rede || []).length ? ' · rede: ' + p.manifesto.rede.join(', ') : ''}`),
      p.erros.length ? h('ul', { class: 'lista neg' }, p.erros.map((x) => h('li', null, x))) : null,
      h('div', { class: 'filtros', style: 'margin-top:8px' }, !p.erros.length && p.estado !== 'ativa' && btn('Ativar', () => { if (confirm(`Ativar "${p.manifesto.nome}"?\n\nPacotes de código/dados só devem ser ativados se você confia neles.`)) agir('atualizacoes/ativar', { id: p.id, confirmo: true }, (r) => { alert('Ativada: ' + JSON.stringify(r.resumo)); recarregar(); }); }, 'pri'),
        (p.estado === 'ativa' || p.estado === 'alterada') && btn('Desativar', () => agir('atualizacoes/desativar', { id: p.id, remover_dados: confirm('Remover também os dados importados por este pacote?') }, recarregar), 'perigo')))) : h('div', { class: 'vazio' }, 'Nenhuma atualização na pasta. Copie um modelo de atualizacoes/_modelos/ para atualizacoes/ e clique em Recarregar.'),
    card('Ativo agora', h('ul', { class: 'lista' }, h('li', null, 'Indicadores: ' + (a.indicadores.join(', ') || 'nenhum')), h('li', null, 'Rankings: ' + (a.rankings.join(', ') || 'nenhum')),
      h('li', null, 'Conectores: ', a.conectores.length ? a.conectores.map((c) => btn('Rodar ' + c, () => agir('atualizacoes/conector', { chave: c }, (r) => alert(JSON.stringify(r))))) : 'nenhum'))));
};
P.config = async () => {
  const c = await api('config'), entradas = {};
  return h('div', { class: 'grade' }, h('h1', null, 'Configurações'),
    h('div', { class: 'grade g2' },
      card('Modo de funcionamento', h('p', { class: 'sub' }, 'econômico: baixo consumo · normal: monitoramento regular · intensivo: lotes grandes · experimental: testes isolados. Sob pressão de CPU/RAM a carga cai sozinha.'),
        sel(Object.keys(c.modos).map((m) => [m, `${m} (lote ${c.modos[m].lote}, CPU ≤ ${c.modos[m].cpu_max}%)`]), c.modo, (v) => agir('modo', { modo: v }, cabecalho)), ' ',
        btn(c.agendador_pausado ? 'Retomar agendador' : 'Pausar agendador', () => agir('agendador', { pausar: !c.agendador_pausado }, recarregar))),
      card('Dados', h('p', { class: 'sub' }, 'Conectores prontos: cotações da B3 (COTAHIST) e séries do Banco Central. Requerem internet; falhas ficam registradas, sem derrubar a IA.'),
        h('div', { class: 'filtros' }, btn('Coletar cotações B3', () => agir('tarefa', { nome: 'coletar_precos' }, (r) => alert(JSON.stringify(r.resultado || r)))), btn('Coletar Banco Central', () => agir('tarefa', { nome: 'coletar_macro' }, (r) => alert(JSON.stringify(r.resultado || r)))),
          btn('Recalcular tudo', () => agir('recalcular', { todos: true }, (r) => { alert(JSON.stringify(r)); cabecalho(); })), btn('Buscar lacunas', () => agir('tarefa', { nome: 'lacunas' }, (r) => alert(JSON.stringify(r.resultado || r)))),
          btn('Testar conexões (B3 e BCB)', () => api('diagnostico').then((r) => alert(r.fontes.map((f) => `${f.ok ? 'OK ' : 'FALHOU '}${f.fonte} (${f.ms} ms)${f.erro ? ' — ' + f.erro : ''}`).join('\n'))).catch((e) => alert(e.message))))),
      card('Demonstração (dados 100% simulados)', h('p', { class: 'sub' }, `Modo demonstração: ${c.demo ? 'LIGADO' : 'desligado'}. Os últimos pregões simulados ficam escondidos e são revelados aos poucos, para provar as previsões sem olhar o futuro.`),
        h('div', { class: 'filtros' }, btn('Gerar demonstração', () => agir('demo/gerar', {}, () => { cabecalho(); fita(); recarregar(); })), btn('Avançar 5 dias', () => agir('demo/avancar', { dias: 5 }, () => { cabecalho(); recarregar(); })), btn('Avançar 21 dias', () => agir('demo/avancar', { dias: 21 }, () => { cabecalho(); recarregar(); })),
          btn(c.demo ? 'Voltar aos dados reais' : 'Ver a demonstração', () => agir('demo/modo', { ativo: !c.demo }, () => { cabecalho(); fita(); recarregar(); })))),
      card('Alertas', h('div', { class: 'filtros' }, h('label', null, 'Nível mínimo ', sel([['info', 'info'], ['atencao', 'atenção'], ['critico', 'crítico']], c.alertas.nivel_min, (v) => agir('config', { alertas: { nivel_min: v } }))), h('label', null, ' Variação do índice ', h('input', { class: 'campo', type: 'number', style: 'width:80px', value: c.alertas.delta_indice, onchange: (e) => agir('config', { alertas: { delta_indice: Number(e.target.value) } }) })),
        h('label', null, ' Cooldown (dias) ', h('input', { class: 'campo', type: 'number', style: 'width:80px', value: c.alertas.cooldown_dias, onchange: (e) => agir('config', { alertas: { cooldown_dias: Number(e.target.value) } }) }))))),
    card('Pesos do índice (explicáveis e configuráveis; ETFs/índices ajustam automaticamente)', h('div', { class: 'grade g4' }, Object.entries(c.rotulos).map(([k, t]) => h('label', null, h('div', { class: 'mu' }, t), entradas[k] = h('input', { class: 'campo', type: 'number', min: 0, step: 0.5, value: c.pesos[k], style: 'width:100%' })))),
      h('div', { class: 'filtros', style: 'margin-top:10px' }, btn('Salvar pesos', async () => { const p = {}; for (const [k, i] of Object.entries(entradas)) p[k] = Number(i.value); await agir('config', { pesos: p }, () => { alert('Salvo. Recalcule para aplicar.'); recarregar(); }); }, 'pri'),
        btn('Restaurar padrão', () => agir('config', { pesos: c.pesos_padrao }, recarregar))),
      h('p', { class: 'mu' }, `Luz verde: ≥ ${c.limiares.verde} · amarela: ≥ ${c.limiares.amarelo} · vermelha: abaixo. Taxa de desconto do DCF: ${F.pct(c.taxa_desconto)}.`)));
};
P.coleta = async () => {
  const d = await api('plano-coleta'), p = d.plano;
  let etapa = 1;
  const raiz = h('div', { class: 'grade' });
  const render = () => {
    const etapaAtual = p.etapas.find((x) => x.numero === etapa);
    const tarefas = p.tarefas.filter((x) => x.etapa === etapa);
    const lista = tarefas.map((t) => {
      const estado = sel([['pendente','Pendente'],['em_andamento','Em andamento'],['bloqueada','Bloqueada'],['concluida','Concluída']], t.status, async (v) => {
        let evidencia = t.evidencia || '', validacao = t.validacao || '';
        if (v === 'concluida') {
          evidencia = prompt('Evidência objetiva (arquivo, log, registro ou resultado):', evidencia);
          if (evidencia == null) return;
          validacao = prompt('Como foi validado? Informe o teste e o resultado:', validacao);
          if (validacao == null) return;
        }
        const r = await agir('plano-coleta/atualizar', { tarefa_id: t.id, status: v, evidencia, validacao });
        if (r) { Object.assign(p, r); recarregar(); }
      });
      return h('div', { class: 'tarefa-coleta' },
        h('div', { class: 'tarefa-info' }, h('b', null, `#${String(t.id).padStart(3,'0')} · ${t.tarefa}`),
          (t.evidencia || t.validacao) ? h('small', null, `Evidência: ${t.evidencia || '—'} · Validação: ${t.validacao || '—'}`) : h('small', { class: 'mu' }, 'Sem evidência registrada.')),
        estado);
    });
    const progressoEtapas = p.etapas.map((e) => h('button', { class: 'btn ' + (e.numero === etapa ? 'pri' : ''), onclick: () => { etapa = e.numero; render(); } }, `${e.numero}. ${e.nome} (${e.concluidas}/${e.total})`));
    const conteudo = h('div', { class: 'grade' },
      h('div', { class: 'filtros' }, progressoEtapas),
      card(`Etapa ${etapa} — ${etapaAtual.nome}`, h('p', { class: 'sub' }, `${etapaAtual.concluidas} de ${etapaAtual.total} tarefas concluídas · ${etapaAtual.em_andamento} em andamento · ${etapaAtual.bloqueadas} bloqueadas`), ...lista));
    raiz.replaceChildren(
      h('div', null, h('h1', null, 'Plano de coleta de dados — GFI'), h('p', { class: 'sub' }, '145 tarefas em 16 etapas. O status é persistido no banco local. Conclusão exige evidência objetiva e validação registrada.')),
      h('div', { class: 'grade g4' }, kpi('Tarefas totais', p.total), kpi('Concluídas', p.totais.concluida), kpi('Em andamento', p.totais.em_andamento), kpi('Progresso validado', p.percentual + '%')),
      h('div', { class: 'card' }, h('div', { class: 'barra' }, h('span', { style: `width:${p.percentual}%;background:${COR.verde}` })), h('p', { class: 'mu' }, `${p.totais.pendente} pendentes · ${p.totais.bloqueada} bloqueadas · ${p.totais.concluida} concluídas`)),
      conteudo,
      card('Inventário inicial de fontes', h('p', { class: 'sub' }, 'Situação identificada na inspeção da V6.05. “Implementado” não significa coleta real homologada.'), tabela([{t:'Fonte',f:x=>x.nome},{t:'Estado na V6.05',q:true,f:x=>x.estado},{t:'Conector / referência',q:true,f:x=>x.conector},{t:'Risco / pendência',q:true,f:x=>x.risco}], d.fontes))
    );
  };
  render(); return raiz;
};

P.carteira = async () => {
  let r=await api('carteira'); let tipo='deposito';
  const ativos=await api('carteira/ativos').catch(()=>({ativos:[],total:0,aviso:'Catálogo B3 indisponível.'}));
  const kind=sel([['deposito','Depósito'],['retirada','Retirada'],['compra','Compra'],['venda','Venda']],'deposito',v=>{tipo=v;});
  const amount=h('input',{class:'campo',type:'number',min:'0.01',step:'0.01',placeholder:'Valor total em R$'}), ticker=h('input',{class:'campo',placeholder:'Ação B3 (ex.: PETR4)',list:'gfi-acoes-br'}), qty=h('input',{class:'campo',type:'number',min:'0',step:'any',placeholder:'Quantidade'}), price=h('input',{class:'campo',type:'number',min:'0',step:'0.01',placeholder:'Preço por ação'}), note=h('input',{class:'campo',placeholder:'Observação'});
  ticker.setAttribute('autocomplete','off');
  const lista=h('datalist',{id:'gfi-acoes-br'},(ativos.ativos||[]).map(a=>h('option',{value:a.ticker,label:(a.nome||a.ticker)+' · '+(a.tipo||'ação')})));
  const totalHint=h('small',{class:'mu'},'Informe quantidade e preço unitário; o valor total da compra/venda será calculado automaticamente.');
  const calcular=()=>{if(['compra','venda'].includes(tipo)&&Number(qty.value)>0&&Number(price.value)>0)amount.value=(Number(qty.value)*Number(price.value)).toFixed(2);};
  qty.addEventListener('input',calcular);price.addEventListener('input',calcular);const syncTipo=()=>{const acao=['compra','venda'].includes(tipo);ticker.disabled=!acao;qty.disabled=!acao;price.disabled=!acao;amount.placeholder=acao?'Total calculado em R$':'Valor em R$';calcular();};kind.addEventListener('change',syncTipo);syncTipo();
  const liveBox=h('div',{class:'grade',id:'carteira-live'});
  const desenharLive=(x)=>{
    const pos=Object.entries(x.posicoes||{});
    liveBox.replaceChildren(
      h('div',{class:'grade g4'},kpi('Saldo em caixa','R$ '+F.n(x.saldo_caixa),'Disponível'),kpi('Patrimônio total',x.patrimonio_total==null?'—':'R$ '+F.n(x.patrimonio_total),'Caixa + ações'),kpi('Resultado da carteira',x.resultado_total==null?'—':'R$ '+F.n(x.resultado_total),x.rentabilidade_total==null?'Cotação insuficiente':F.pctS(x.rentabilidade_total)),kpi('P/L realizado','R$ '+F.n(x.lucro_prejuizo_realizado),'Vendas concluídas')),
      h('div',{class:'card'},h('h2',null,'Desempenho por ação'),h('p',{class:'sub'},'Cada posição é comparada ao preço médio efetivamente pago nas compras. A variação é recalculada a cada 5 segundos usando a última cotação disponível; a fonte externa pode ter atraso.'),pos.length?tabela([{t:'Ação',f:z=>z[0]},{t:'Qtd.',n:true,f:z=>F.n(z[1].quantidade,6)},{t:'Preço de compra médio',n:true,f:z=>'R$ '+F.n(z[1].preco_medio)},{t:'Cotação atual',n:true,f:z=>z[1].cotacao==null?'—':'R$ '+F.n(z[1].cotacao)},{t:'Valor posição',n:true,f:z=>z[1].valor_mercado==null?'—':'R$ '+F.n(z[1].valor_mercado)},{t:'Resultado',n:true,f:z=>z[1].lucro_prejuizo_aberto==null?'—':'R$ '+F.n(z[1].lucro_prejuizo_aberto),c:z=>cls(z[1].lucro_prejuizo_aberto)},{t:'Variação',n:true,f:z=>F.pctS(z[1].rentabilidade_aberta),c:z=>cls(z[1].rentabilidade_aberta)},{t:'Cotação observada',q:true,f:z=>z[1].referencia_cotacao||'Sem cotação'}],pos):h('div',{class:'vazio'},'Nenhuma ação comprada.')),
      h('p',{class:'mu'},'Atualização da carteira: '+new Date().toLocaleTimeString('pt-BR')+' · cotações dependem da última observação do provedor.'));
  };
  desenharLive(r);
  const atualizar=async()=>{try{const x=await api('carteira/atualizar-cotacoes',{});r=x.carteira||x;desenharLive(r);await atualizarSaldoGlobal();alert('Consulta concluída. Confira o horário de observação e eventuais falhas.');}catch(e){alert(e.message);}};
  const formulario=card('Registrar movimentação',h('div',{class:'filtros'},kind,amount,ticker,qty,price,note,btn('Registrar',async()=>{const q=Number(qty.value),p=Number(price.value),v=await agir('carteira/lancar',{kind:tipo,amount:['compra','venda'].includes(tipo)?q*p:Number(amount.value),ticker:ticker.value,quantity:q,unit_price:p,note:note.value},()=>{});if(v){r=v;desenharLive(r);await atualizarSaldoGlobal();alert('Movimentação registrada. Preço de aquisição preservado no histórico.');}},'pri'),totalHint,lista));
  const quoteCard=card('Cotações e universo B3',h('p',{class:'sub'},'A carteira recalcula patrimônio e percentuais a cada 5 segundos com os preços em cache. A consulta ao provedor externo é limitada para evitar bloqueios; não é um feed em tempo real garantido.'),btn('Atualizar cotações agora',atualizar,'pri'),btn('Importar universo B3 — últimos 10 anos',async()=>{if(!confirm('Baixar e importar o COTAHIST oficial da B3 dos últimos 10 anos? Pode levar vários minutos e exige internet.'))return;const ano=new Date().getFullYear();const anos=Array.from({length:10},(_,i)=>ano-9+i);const b=await agir('b3/coletar',{anos},x=>alert('Importação B3 concluída. Recarregue Minha Conta para atualizar a lista de ações. '+JSON.stringify(x.resultado)));if(b){const a=await api('carteira/ativos');ticker.setAttribute('list','gfi-acoes-br');lista.replaceChildren(...a.ativos.map(z=>h('option',{value:z.ticker,label:(z.nome||z.ticker)+' · '+(z.tipo||'ação')})));}},'pri'),h('p',{class:'mu'},`${ativos.total||0} ações/units brasileiras cadastradas no catálogo local. ${ativos.aviso||''}`));
  const historico=()=>card('Histórico de operações',r.movimentacoes.length?tabela([{t:'Data',f:x=>x.occurred_at},{t:'Tipo',f:x=>x.kind},{t:'Ticker',f:x=>x.ticker||'—'},{t:'Quantidade',n:true,f:x=>x.quantity==null?'—':F.n(x.quantity,6)},{t:'Preço unitário',n:true,f:x=>x.unit_price==null?'—':'R$ '+F.n(x.unit_price)},{t:'Total',n:true,f:x=>'R$ '+F.n(x.amount)},{t:'Observação',q:true,f:x=>x.note}],r.movimentacoes.slice().reverse()):h('div',{class:'vazio'},'Nenhuma movimentação.'));
  carteiraLiveTimer=setInterval(async()=>{if(S.painel!=='carteira')return;try{r=await api('carteira');desenharLive(r);await atualizarSaldoGlobal();}catch(_){/* mantém último estado válido */}},5000);
  return h('div',{class:'grade'},h('h1',null,'Minha Conta — carteira brasileira'),h('p',{class:'sub'},'Livro financeiro pessoal. Cada compra mantém ticker, quantidade, preço unitário e valor investido; ganhos e perdas são calculados por ação e consolidados no patrimônio.'),liveBox,formulario,quoteCard,historico(),aviso(r.aviso));
};

P.saude = async () => {
  const s = await api('saude'), b = (rot, v) => h('div', { style: 'margin:6px 0' }, h('div', { style: 'display:flex;justify-content:space-between' }, h('span', null, rot), h('b', null, v == null ? 'n/d' : v + '%')), h('div', { class: 'fita' }, h('span', { style: `width:${v || 0}%;background:${v > 85 ? COR.verm : v > 65 ? COR.amarelo : COR.verde}` })));
  const ag = s.agendador, tar = Object.entries(ag.ultimas);
  return h('div', { class: 'grade' }, h('h1', null, 'Saúde dos serviços'), h('p', { class: 'sub' }, `${s.nome} v${s.versao} · modo ${s.modo}${s.sob_pressao ? ' · SOB PRESSÃO (carga reduzida)' : ''}`),
    h('div', { class: 'grade g4' }, kpi('Agendador', ag.pausado ? 'pausado' : ag.rodando ? 'rodando: ' + ag.rodando : 'ocioso', ag.ligado ? 'ligado' : 'desligado'), kpi('Banco de dados', s.banco_mb + ' MB'), kpi('Fila de pesquisa', s.filas.pesquisa, s.filas.propostas_abertas + ' proposta(s) aberta(s)'),
      kpi('Previsões imutáveis', s.cadeia_previsoes_integra ? 'íntegras' : 'ADULTERADAS')),
    h('div', { class: 'grade g2' }, card('Recursos do computador', b('CPU', s.recursos.cpu), b('RAM', s.recursos.ram), b('Disco', s.recursos.disco), h('div', { class: 'mu' }, s.recursos.nucleos + ' núcleo(s)')),
      card('Cobertura do universo', tabela([{ t: 'Indicador', f: (x) => x[0] }, { t: 'Valor', n: true, f: (x) => x[1] }], [['Cadastrados', s.cobertura.cadastrados], ['Ativos', s.cobertura.ativos], ['Com dados atualizados', s.cobertura.atualizados], ['Insuficientes/desatualizados', s.cobertura.insuficientes], ['Suspensos', s.cobertura.suspensos], ['Deslistados', s.cobertura.deslistados]]))),
    card('Tarefas do agendador', tar.length ? tabela([{ t: 'Tarefa', f: (x) => x[0] }, { t: 'Última execução', f: (x) => F.d(x[1].ts) }, { t: 'Duração', n: true, f: (x) => x[1].duracao ? x[1].duracao + ' s' : '—' }, { t: 'Resultado', q: true, f: (x) => x[1].ok ? JSON.stringify(x[1].resultado).slice(0, 140) : 'ERRO: ' + x[1].erro, c: (x) => x[1].ok ? '' : 'neg' }], tar) : h('div', { class: 'vazio' }, 'Nenhuma tarefa executada ainda.'),
      btn('Atualizar', recarregar)),
    card('Fontes de dados (últimas coletas)', s.coletas.length ? tabela([{ t: 'Fonte', f: (x) => x.fonte }, { t: 'Quando', f: (x) => F.d(x.inicio) }, { t: 'Status', f: (x) => x.status, c: (x) => x.status === 'ok' ? 'pos' : 'neg' }, { t: 'Registros', n: true, f: (x) => x.registros }, { t: 'Erro', q: true, f: (x) => x.erro || '' }], s.coletas) : h('div', { class: 'vazio' }, 'Nenhuma coleta externa ainda.')),
    card('Logs recentes', tabela([{ t: 'Quando', f: (x) => F.d(x.ts) }, { t: 'Nível', f: (x) => x.nivel, c: (x) => x.nivel === 'ERRO' ? 'neg' : '' }, { t: 'Módulo', f: (x) => x.modulo }, { t: 'Mensagem', q: true, f: (x) => x.msg }], s.logs)));
};

// ---------------------------------------------------------------- início
function iniciar() {
  $('#nav').replaceChildren(...PAINEIS.map(([k, t], i) => h('button', { 'data-p': k, onclick: () => ir(k) }, h('i', null, String(i + 1).padStart(2, '0')), t)));
  const atalhosMobile = [['visao','⌂','Visão'],['mercados','◎','Mercados'],['radar','⌁','Radar'],['carteira','▤','Conta']];
  const dock = h('nav',{class:'mobile-dock','aria-label':'Navegação principal'},
    ...atalhosMobile.map(([k,ico,t])=>h('button',{'data-p':k,type:'button',onclick:()=>ir(k)},h('span',{class:'dock-icon','aria-hidden':'true'},ico),h('span',null,t))),
    h('button',{'data-more':'1',type:'button','aria-expanded':'false','aria-controls':'nav',onclick:(e)=>{const abrir=!document.body.classList.contains('nav-aberto');document.body.classList.toggle('nav-aberto',abrir);e.currentTarget.setAttribute('aria-expanded',String(abrir));}},h('span',{class:'dock-icon','aria-hidden':'true'},'☷'),h('span',null,'Mais')));
  document.body.append(dock);
  $('#nav').addEventListener('click',(e)=>{if(e.target.closest('button'))document.body.classList.remove('nav-aberto')});
  document.addEventListener('click',(e)=>{if(document.body.classList.contains('nav-aberto')&&!e.target.closest('#nav')&&!e.target.closest('.mobile-dock')){document.body.classList.remove('nav-aberto');const m=document.querySelector('.mobile-dock [data-more]');if(m)m.setAttribute('aria-expanded','false')}});
  $('#t-alertas').addEventListener('click', gaveta);
  $('#t-cotacoes').addEventListener('click', async()=>{const b=$('#t-cotacoes');b.disabled=true;b.textContent='Atualizando…';try{const r=await api('cotacoes/atualizar',{limite:35});alert(`Cotações: ${r.atualizados} atualizados de ${r.tentados}; ${r.falhas} falhas. Snapshots não são garantidamente em tempo real.`);await cabecalho();await rota();}catch(e){alert(e.message)}finally{b.disabled=false;b.textContent='↻ Atualizar cotações';}});
  $('#t-busca').addEventListener('click', async()=>{const b=$('#t-busca');b.disabled=true;b.textContent='Buscando…';try{const r=await api('buscar-geral',{});alert(`Busca geral: ${r.noticias} notícias; ${r.lacunas_enfileiradas} novas pesquisas na fila; ${r.erros.length} falhas.`);await cabecalho();}catch(e){alert(e.message)}finally{b.disabled=false;b.textContent='⌕ Buscar geral';}});
  const relogio = () => { $('#t-relogio').textContent = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }; relogio(); setInterval(relogio, 30000);
  window.addEventListener('hashchange', rota); rota(); cabecalho(); fita(); atualizarSaldoGlobal(); renderSaldoGlobal();
  setInterval(cabecalho, 20000); setInterval(fita, 60000); setInterval(atualizarSaldoGlobal, 5000); (async()=>{try{await api('carteira/atualizar-cotacoes',{});await atualizarSaldoGlobal();}catch(_){/* mantém último valor conhecido e não mascara indisponibilidade */}})(); setInterval(async()=>{try{await api('carteira/atualizar-cotacoes',{});await atualizarSaldoGlobal();}catch(_){/* mantém último valor conhecido e não mascara indisponibilidade */}},60000);
}
iniciar();
})();
