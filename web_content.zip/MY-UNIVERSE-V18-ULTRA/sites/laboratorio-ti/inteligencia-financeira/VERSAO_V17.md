# GFI V17 — interface responsiva e análise por horizonte

## Escopo
Somente `sites/laboratorio-ti/inteligencia-financeira`. O restante da MY UNIVERSE permanece sem alterações funcionais.

## Alterações
- Fundo desktop usa `ui/assets/gfi-desktop-wallpaper.jpg`; fundo mobile usa `ui/assets/gfi-mobile-wallpaper.jpg`, com regras finais responsivas para impedir que o celular herde a imagem desktop.
- Reorganização mobile: cartões compactos, grade de duas colunas, controles menores, dock inferior, tabelas com rolagem horizontal e mapa treemap dimensionado para caber na tela.
- Retrato gerado para a identidade de login/perfil: `ui/assets/gfi-login-portrait.webp`. A imagem fica disponível como asset; a tela de autenticação só pode exibi-la se o fluxo de login existente usar esse componente.
- Novo ranking `medio_prazo`, combinando técnica (30%), crescimento (30%), saúde financeira (25%) e valuation (15%), ponderado pela qualidade dos dados.
- Mantidos os rankings e motores anteriores de curto e longo prazo.

## Integridade e limites
A V17 não inventa feed em tempo real. A atualização depende dos conectores e contratos de dados disponíveis. Yahoo Finance pode fornecer dados atrasados; B3 COTAHIST é histórico diário. A interface e o ranking devem respeitar o estado de atualidade/qualidade retornado pelo pipeline. Não houve validação de rede externa nesta compilação.
