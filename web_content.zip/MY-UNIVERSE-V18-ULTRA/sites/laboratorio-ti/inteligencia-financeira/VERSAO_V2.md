# MY UNIVERSE — V2

Data: 2026-11-20

## Entrega desta versão

Fundação de armazenamento intradiário do GFI, reaproveitando o banco SQLite existente e mantendo intacta a série diária.

### Arquivos alterados/adicionados

- `sites/laboratorio-ti/inteligencia-financeira/gfi/db.py`: tabela e índices `cotacoes_intradiarias` adicionados ao schema.
- `sites/laboratorio-ti/inteligencia-financeira/gfi/live.py`: registro, validação, consulta e resumo de snapshots intradiários.
- `sites/laboratorio-ti/inteligencia-financeira/testes/test_live.py`: sete testes da nova camada.
- `sites/laboratorio-ti/inteligencia-financeira/STATUS_FINALIZACAO.md`: status e limites da V2.

### Validação

- `python3 -m unittest discover -s testes -t .`: 68 testes aprovados.
- `python3 -m compileall -q gfi servidor.py`: executar novamente no ambiente de implantação.

### Limites

Esta versão não conecta a provedor, não gera cotações, não agenda coleta de minuto e não exibe dados no painel. O estado `REALTIME` só deve ser usado quando um provedor confiável efetivamente entregar dados em tempo real.
