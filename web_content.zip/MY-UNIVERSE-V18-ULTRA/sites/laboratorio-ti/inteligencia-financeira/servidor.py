#!/usr/bin/env python3
"""Servidor local da IA (127.0.0.1). Serve o painel (ui/) e a API (/api/*). Independente do portal."""
import json
import mimetypes
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

from gfi import acesso, agendador, api, atualizacoes, config, db, ia_evolucao

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; "
       "object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
HOSTS = {f"127.0.0.1:{config.PORTA}", f"localhost:{config.PORTA}"}
EXT = {".html", ".css", ".js", ".svg", ".png", ".jpg", ".jpeg", ".webp", ".ico", ".json"}


class Handler(BaseHTTPRequestHandler):
    server_version = "GFI"
    sys_version = ""

    def log_message(self, *a):
        pass

    def _enviar(self, status, corpo, tipo="application/json; charset=utf-8", extra=None):
        self.send_response(status)
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        for k, v in (("Content-Type", tipo), ("Content-Length", str(len(corpo))), ("Cache-Control", "no-store"), ("X-Content-Type-Options", "nosniff"),
                     ("X-Frame-Options", "DENY"), ("Referrer-Policy", "no-referrer"), ("Content-Security-Policy", CSP)):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(corpo)

    def _json(self, status, obj):
        self._enviar(status, json.dumps(obj, ensure_ascii=False, default=str).encode())

    def _host_ok(self):
        return self.headers.get("Host", "") in HOSTS or acesso.host_permitido(self.headers.get("Host", ""))  # bloqueia DNS rebinding

    def _ip_cliente(self):
        # Só confia no X-Forwarded-For quando a conexão veio do gateway local.
        peer = self.client_address[0]
        if peer in ("127.0.0.1", "::1"):
            encaminhado = self.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
            if encaminhado:
                return encaminhado
        return peer

    def _liberado(self):
        return acesso.autorizado(self._ip_cliente(), self.headers.get("Cookie"))

    def _negar(self, p):
        if p.path.startswith("/api/"):
            return self._json(401, {"erro": "acesso negado: abra o painel com ?token=… (veja o terminal onde a IA foi iniciada)"})
        corpo = ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
                 "<title>Entrar · GFI</title><body style='margin:0;min-height:100vh;display:grid;place-items:center;font:15px system-ui;background:radial-gradient(ellipse at 50% 20%,#102b49,#050a12 65%);color:#e6ebf2;padding:22px'>"
                 "<main style='width:min(420px,100%);text-align:center;padding:28px 22px;border:1px solid #24517a;border-radius:22px;background:#081321eF;box-shadow:0 20px 70px #0009'>"
                 "<img src='/gfi-login-portrait.webp' alt='Perfil do GFI' style='width:116px;height:116px;object-fit:cover;object-position:center 25%;border-radius:50%;border:2px solid #39a9ff;box-shadow:0 0 28px #168cff66'>"
                 "<h1 style='letter-spacing:.08em;margin:18px 0 4px'>GLOBAL FINANCIAL INTELLIGENCE</h1>"
                 "<p style='color:#9cb4ce;margin:0 0 20px'>Pesquisa e apoio à decisão</p>"
                 "<h2 style='font-size:17px'>Acesso protegido</h2><p>Abra o endereço completo exibido no terminal, que termina com <code>?token=…</code>.</p>"
                 "<p style='font-size:12px;color:#7f96ae'>O GFI utiliza autenticação por token; não existe senha web separada nesta instalação.</p></main></body>").encode()
        self._enviar(401, corpo, "text/html; charset=utf-8")

    def do_GET(self):
        if not self._host_ok():
            return self._json(403, {"erro": "host não permitido"})
        p = urlsplit(self.path)
        consulta = {k: v[0] for k, v in parse_qs(p.query).items()}
        if p.path == "/gfi-login-portrait.webp":
            alvo_img = (config.UI / "assets" / "gfi-login-portrait.webp").resolve()
            if alvo_img.is_file():
                return self._enviar(200, alvo_img.read_bytes(), "image/webp")
        if not self._liberado():
            if p.path in ("/", "") and acesso.token_valido(consulta.get("token")):
                return self._enviar(303, b"", "text/plain", {"Location": "/", "Set-Cookie": f"{acesso.COOKIE}={acesso.token()}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000"})
            return self._negar(p)
        if p.path.startswith("/api/"):
            return self._api("GET", p.path[5:].strip("/"), consulta)
        nome = "index.html" if p.path in ("/", "") else p.path.lstrip("/")
        alvo = (config.UI / nome).resolve()
        try:
            alvo.relative_to(config.UI.resolve())
        except ValueError:
            return self._json(404, {"erro": "não encontrado"})
        if not alvo.is_file() or alvo.suffix not in EXT:
            return self._json(404, {"erro": "não encontrado"})
        self._enviar(200, alvo.read_bytes(), (mimetypes.guess_type(alvo.name)[0] or "application/octet-stream") + ("; charset=utf-8" if alvo.suffix in (".html", ".css", ".js") else ""))

    def do_POST(self):
        if not self._host_ok():
            return self._json(403, {"erro": "host não permitido"})
        if not self._liberado():
            return self._negar(urlsplit(self.path))
        origem = self.headers.get("Origin")
        if self.headers.get("X-GFI") != "1" or (origem and urlsplit(origem).netloc != self.headers.get("Host")):
            return self._json(403, {"erro": "origem não permitida"})
        p = urlsplit(self.path)
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n > 100_000:
                return self._json(413, {"erro": "corpo grande demais"})
            corpo = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(corpo, dict):
                raise ValueError
        except ValueError:
            return self._json(400, {"erro": "requisição inválida"})
        self._api("POST", p.path[5:].strip("/") if p.path.startswith("/api/") else "", corpo)

    def _api(self, metodo, rota, dados):
        try:
            if metodo == "GET":
                partes = rota.split("/")
                if partes[0] in ("ativo", "indicadores") and len(partes) == 2:
                    return self._json(200, (api.ativo if partes[0] == "ativo" else api.indicadores)(int(partes[1])))
                if rota.startswith("gfi-ai/relatorio/"):
                    return self._json(200, ia_evolucao.ler_relatorio(partes[2] if len(partes) == 3 else ""))
                if rota in ("live/status", "b3/status", "cvm/status"):
                    return self._json(200, api.GET[rota](dados))
                if len(partes) == 3 and partes[:2] == ["cvm", "instrumento"]:
                    return self._json(200, api.cvm.consultar_instrumento(int(partes[2])))
                if len(partes) == 3 and partes[:2] == ["cvm", "indicadores"]:
                    return self._json(200, api.cvm.indicadores_cnpj(partes[2]))
                if partes[0] == "live" and len(partes) == 2:
                    return self._json(200, api.live_ultimas(int(partes[1])))
                if rota not in api.GET:
                    raise KeyError(rota)
                return self._json(200, api.GET[rota](dados))
            return self._json(200, api.acao(rota, dados))
        except KeyError:
            self._json(404, {"erro": "não encontrado"})
        except PermissionError as e:
            self._json(403, {"erro": str(e)})
        except (ValueError, TypeError) as e:
            self._json(400, {"erro": str(e) or "requisição inválida"})
        except Exception as e:
            db.log("ERRO", "servidor", f"{type(e).__name__}: {e}")
            self._json(500, {"erro": "erro interno (veja os logs em Saúde dos serviços)"})


def main():
    db.conectar().close()
    atualizacoes.carregar_ativas()
    # V9.1: habilita o ciclo de 60 s por padrão em instalação real; modo demo continua bloqueado.
    if db.cfg_get("live_auto_ativo", None) is None:
        db.cfg_set("live_auto_ativo", True)
        db.cfg_set("live_auto_intervalo", 60)
    agendador.iniciar()
    ia_evolucao.iniciar_agente()
    srv = ThreadingHTTPServer((config.HOST, config.PORTA), Handler)
    srv.daemon_threads = True
    print(config.NOME)
    if acesso.cliente_local(config.HOST):
        print(f"Painel: http://{config.HOST}:{config.PORTA}   (só este computador; Ctrl+C para sair)")
    else:
        print(f"MODO REDE ativo. Neste computador: http://127.0.0.1:{config.PORTA}")
        print(f"Em outros aparelhos da rede, abra UMA vez: http://<IP-deste-computador>:{config.PORTA}/?token={acesso.token()}")
        print("(o token fica em dados/token.txt; quem não o tem não consegue acessar a API nem o painel)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrado.")


if __name__ == "__main__":
    main()
