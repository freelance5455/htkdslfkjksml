(() => {
  const botao = document.getElementById("ativar-gfi");
  const status = document.getElementById("gfi-status");
  if (!botao || !status) return;
  botao.addEventListener("click", async () => {
    botao.disabled = true;
    botao.textContent = "INICIANDO GFI...";
    status.textContent = "Solicitando inicialização segura ao servidor MY UNIVERSE...";
    try {
      const resposta = await fetch("/api/gfi/iniciar", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" }, body: "{}"
      });
      const dados = await resposta.json();
      if (!resposta.ok || !dados.running) throw new Error(dados.message || dados.error || "Falha ao iniciar o GFI.");
      status.textContent = dados.message + " Abrindo painel...";
      window.location.assign(dados.url);
    } catch (erro) {
      status.textContent = "Não foi possível iniciar: " + erro.message;
      botao.disabled = false;
      botao.textContent = "TENTAR NOVAMENTE";
    }
  });
})();
