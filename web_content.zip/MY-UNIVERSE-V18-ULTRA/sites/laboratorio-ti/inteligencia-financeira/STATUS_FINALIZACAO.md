# MY UNIVERSE — Inteligência Financeira: status de finalização

Atualizado em 2026-11-20. Este documento separa implementação existente, validação técnica e dependências externas.

## Trabalho realizado nesta revisão

- Corrigido o ciclo de vida das conexões SQLite: as operações internas agora fazem commit/rollback e fecham a conexão ao terminar.
- O contexto `with db.conectar()` também fecha a conexão, evitando que consumidores deixem conexões abertas inadvertidamente.
- Adicionado teste de regressão para garantir que uma conexão não possa ser reutilizada após sair do contexto.
- Atualizada a documentação de execução e testes.

## Verificações executadas

- `python3 -m unittest discover -s testes -t .`: **61 testes passaram**.
- `python3 -m compileall -q gfi servidor.py`: compilação sem erros.
- Inicialização isolada do servidor: `/api/saude` respondeu HTTP 200.
- Página principal `/` respondeu HTTP 200.

Esses testes validam o comportamento coberto pela suíte e o smoke test local. Não comprovam a disponibilidade contínua das fontes externas, nem a qualidade de previsões no mercado real.

## Pendências reais para considerar o produto concluído

1. **Dados de mercado intradiários:** a estrutura atual `cotacoes` é diária (`PRIMARY KEY(instrumento_id, data)`). Não deve receber snapshots de minuto, pois sobrescreveria/colidiria com o candle diário. É necessário criar armazenamento intradiário separado, agregação de candles e política de retenção.
2. **Provedor de cotações:** COTAHIST é histórico diário, não feed de preço em tempo real. O intervalo de consulta de 60 segundos só poderá produzir atualização real se houver um provedor intradiário que entregue dados nesse ritmo e permita esse uso. Credenciais, limites, atraso e licença precisam ser configurados e exibidos no painel.
3. **Fontes reais:** testar B3 e BCB na máquina de implantação, registrar respostas, códigos HTTP, datas de referência e defasagem dos dados.
4. **Fundamentos:** implementar/importar DFP/ITR da CVM, mapear contas e períodos, validar republicações e manter proveniência por campo.
5. **Notícias e regulação:** integrar fontes permitidas/licenciadas, deduplicar eventos, guardar URL, publicação, coleta e confiabilidade; não transformar manchetes isoladas em sinal de compra.
6. **Modelos preditivos:** comparar modelos estatísticos/ML contra baselines no backtest walk-forward já existente, com custos, slippage, sobrevivência e prevenção de vazamento temporal. Publicar somente se superar o acaso e os baselines em amostra fora do treino.
7. **Operação:** executar por semanas com dados reais, acompanhar falhas, latência, cobertura, defasagem, previsões avaliadas e integridade da cadeia.

## Decisão de arquitetura para o módulo LIVE

O módulo LIVE deve ser uma extensão do GFI, reutilizando catálogo, validação, conectores, banco, alertas, pipeline e API existentes. Não deve criar um segundo motor de pontuação. O desenho correto é:

`provedor intradiário → normalização → validação temporal/preço → armazenamento intradiário → agregação → pipeline existente → API/painel/alertas`

Estados obrigatórios por cotação: `REALTIME`, `DELAYED`, `HISTORICAL`, `STALE` ou `UNAVAILABLE`. O painel deve mostrar provedor, horário da cotação, horário de coleta e atraso. Se não houver feed válido, manter o último dado com estado `STALE`/`UNAVAILABLE`; nunca fabricar atualização.

## Critério de conclusão

O projeto só deve ser declarado concluído depois que os itens externos e operacionais acima forem implementados e testados com dados reais. A base atual é preservada; esta revisão não declara ML, notícias automáticas, fundamentos automáticos ou cotações em tempo real como concluídos.

## V2 — armazenamento intradiário inicial (2026-11-20)

- Criada a tabela `cotacoes_intradiarias`, separada da tabela diária `cotacoes`, com índice por instrumento/horário e deduplicação por instrumento, provedor e horário observado.
- Criado `gfi/live.py` para registrar e consultar snapshots recebidos de um provedor, preservando horário observado, horário de coleta, preço, volume, provedor e estado (`REALTIME`, `DELAYED`, `HISTORICAL`, `STALE`, `UNAVAILABLE`).
- Valida preço/volume finitos, preço positivo, volume não negativo, fuso horário explícito, provedor e estado permitido.
- A camada não busca, inventa ou simula cotações. Não há provedor intradiário conectado nesta versão.
- Testes novos: 7. Suíte completa após a V2: **68 testes aprovados**.

### Escopo deliberadamente não incluído na V2

- Conector de feed em tempo real ou atrasado.
- Agendamento automático a cada 60 segundos.
- Agregação de snapshots em candles intradiários.
- Exibição dos snapshots na API ou no painel.

Esses itens permanecem como próximas etapas. A V2 conclui apenas a fundação de persistência e validação do armazenamento intradiário.


## V6.04 — operação B3 COTAHIST

- Incluídos `GET /api/b3/status` e `POST /api/b3/coletar`, validação de anos e bloqueio da coleta manual em modo demonstração.
- Cobertura B3 consultável por ano, instrumento e intervalo de datas, com histórico das últimas tentativas.
- Compilação aprovada e 98 testes automatizados aprovados.
- **Pendente de validação operacional:** baixar e importar ao menos um ZIP anual oficial B3 na máquina de implantação. Até essa evidência existir, a coleta externa permanece não confirmada.
