# MY UNIVERSE — V6.03

**Foco:** primeira camada explícita de interpretação dos lançamentos CVM, sem alterar os dados brutos nem alimentar automaticamente o valuation.

## Entregas

- Novo módulo `gfi/conectores/contas.py` com dicionário versionado de correspondências exatas entre família da demonstração + código CVM e conceito financeiro.
- Cobertura inicial de BPA (ativo), BPP (passivo e patrimônio líquido), DRE (receitas e resultados) e DFC (fluxos operacionais, investimento e financiamento; métodos direto e indireto).
- Classificação conservadora: não usa aproximação por descrição, não soma subcontas, não converte moeda/escala e não mistura DFP com ITR ou grupos individuais/consolidados.
- Lançamentos sem correspondência continuam disponíveis como dados brutos e entram na contagem de não mapeados.
- Nova consulta `cvm.indicadores_cnpj()` devolve valores classificados com CNPJ, período, exercício, versão, moeda, escala, grupo, arquivo e fonte preservados.
- Novas rotas:
  - `GET /api/cvm/dicionario` — regras de classificação publicadas pelo GFI.
  - `GET /api/cvm/indicadores/{cnpj}` — lançamentos classificados de um CNPJ; não calcula índices nem substitui análise contábil.
- Nenhuma alteração destrutiva nas tabelas CVM existentes.

## Limites deliberados

- A classificação é uma primeira cobertura dos códigos totalizadores conhecidos. DRA, DMPL, DVA e subcontas ainda não têm regras nesta versão.
- Os nomes/semântica dos códigos devem continuar sujeitos à validação contra os layouts e demonstrações oficiais de cada exercício.
- Não são calculados EBITDA, dívida líquida, margens, ROE, ROIC, fluxo de caixa livre ou múltiplos.
- Não há conversão de unidade/escala nem seleção automática de reapresentação vencedora.
- O valuation permanece inalterado; nenhum valor CVM é injetado nos motores de pontuação ou decisão.
- Download externo real da CVM continua dependendo de teste na máquina de operação.

## Validação

- `python -m compileall -q gfi servidor.py` — aprovado.
- `python -m unittest discover -s testes -t .` — **95 testes aprovados** (91 anteriores + 4 novos).
- Smoke test isolado: `/`, `/api/cvm/status`, `/api/cvm/dicionario` e `/api/cvm/indicadores/{cnpj}` responderam HTTP 200.
- Os testes usam fixtures locais; não comprovam disponibilidade da CVM na internet.
