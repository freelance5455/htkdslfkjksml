# Inteligência Financeira Global (em teste no Laboratório de TI)

Plataforma **local** de pesquisa e apoio à decisão para o mercado financeiro. Ela monitora ativos, calcula um índice
0–100 **explicável** com 15 sinais (verde / amarelo / vermelho / cinza), monta rankings, registra previsões de forma
**imutável** e mede a própria qualidade. **Não envia ordens, não opera no mercado e não é recomendação de investimento.**

> **Leia isto primeiro:** nenhum sistema prevê o futuro das ações nem garante que você não perca dinheiro. Esta IA foi feita
> para o oposto de prometer: ela diz quando **não** tem evidência (cinza, "sem evidência de vantagem") e testa a si mesma
> contra o acaso. Use o resultado como mais uma informação, nunca como garantia.

## Como usar

```bash
bash iniciar.sh              # dentro desta pasta; precisa só de Python 3.8+
```
Abra <http://127.0.0.1:8780>. Só aceita conexões deste computador. Na primeira vez escolha:

- **Gerar demonstração** — 40 empresas FICTÍCIAS (DEMO01…), 100 % simuladas e sempre marcadas como tal. Boa para conhecer o painel.
- **Coletar dados reais** — cotações oficiais da B3 (COTAHIST) e séries do Banco Central. Precisa de internet.
  Em *Configurações → Testar conexões* você confirma se as fontes respondem no seu PC.

Parar: `Ctrl+C`. Os dados ficam em `dados/` (apague para recomeçar).

## O que já está pronto

| Fase | Conteúdo | Situação |
|---|---|---|
| 1 Fundação | pasta independente, banco SQLite, catálogo (ticker + MIC + ISIN + moeda), logs, monitor de CPU/RAM/disco, 4 modos | **pronta** |
| 2 Coleta | B3 (COTAHIST), BCB (SGS), CVM (DFP/ITR inicial), validação e rastreabilidade | **em fortalecimento na V6.01** (download CVM real ainda depende de validação na máquina com internet) |
| 3 Inteligência financeira | RSI, MACD, médias, Bollinger, ATR, VWAP, OBV, ADX, momentum, volatilidade; valuation (múltiplos + DCF em 3 cenários + armadilha de valor); risco (VaR, drawdown, beta, liquidez); 15 sinais e índice 0–100 | **pronta** |
| 5 Ranking | 11 rankings independentes + TOP 20/50/100 + filtros, cada posição com "por que" | **pronta** |
| 6 Preditiva (parcial) | previsões imutáveis (cadeia de hashes), autoavaliação, **backtest fora da amostra com custos e teste contra o acaso** | **parcial** — falta Machine Learning (veja "Próximos passos") |
| 7 Autoevolução | fila de pesquisa, propostas com aprovação obrigatória, laboratório isolado, atualizações estilo CLEO | **pronta** (pesquisa tecnológica automática pendente) |
| 8 Interface | 16 painéis, alertas sem repetição, saúde dos serviços | **pronta** |
| 4 Global | notícias, reguladores e geopolítica por coleta automática | **pendente** (hoje entram por atualização CSV/conector) |

## Como a IA decide (e por que não engana)

- **Dado ausente, antigo ou inválido = CINZA**, nunca verde. Notícia positiva não vira verde sozinha.
- **Sem dupla contagem:** indicadores correlacionados são agrupados e contam uma vez; nenhum indicador isolado vira sinal.
- **Bloqueios:** fraude, falência, liquidez mínima, volatilidade extrema ou queda > 70 % derrubam o índice (≤ 35) mesmo com muitos verdes.
- **Todo índice traz a composição** (peso × nota), as 10 perguntas respondidas e a separação *fatos × estimativas × hipóteses × opiniões da IA*.
- **Previsões:** só direção esperada em 21 pregões, gravada **antes** do resultado, com hash encadeado e gatilhos no banco que proíbem UPDATE/DELETE.
- **Evidência de habilidade:** o painel compara o acerto com estratégias ingênuas e diz "SEM evidência" quando é o caso.
- **Backtest honesto:** em cada data só usa o que existia até ali (balanços com 1 ano de defasagem), paga custo e slippage, inclui ativos deslistados
  e compara com 500 carteiras **aleatórias**. Se o resultado é compatível com sorte, ele diz.

## Pasta de atualizações (estilo CLEO)

A IA mora aqui; **`atualizacoes/`** é onde você solta pacotes para ampliá-la sem mexer no núcleo (dados CSV, ajustes de pesos,
novos indicadores, rankings e conectores). Nada roda sem o seu clique em *Atualizações → Ativar*. Passo a passo em **`atualizacoes/LEIAME.md`**
e modelos prontos em `atualizacoes/_modelos/`. Modo seguro: crie `atualizacoes/DESLIGADO`.

## Como ela evolui sozinha (e devagar de propósito)

PESQUISA → PROPOSTA → EXPERIMENTAL → TESTES → COMPARAÇÃO → APROVAÇÃO → PUBLICAÇÃO. A autoavaliação e a busca de lacunas geram propostas e
pesquisas; a IA só escreve código em `laboratorio/` e **não pode publicar**: a aprovação exige você digitar `APROVO`. Propostas que toquem em
arquivos de segurança (`gfi/db.py`, `gfi/evolucao.py`, `gfi/config.py`, `gfi/previsoes.py`, `servidor.py`…) são recusadas automaticamente.
Aprovado um código, ele vira um pacote **desativado** em `atualizacoes/ia-proposta-N/` para você revisar e ativar.

## Estrutura

```
inteligencia-financeira/
├── iniciar.sh · servidor.py         # servidor local (127.0.0.1:8780)
├── ui/                              # painel (16 painéis, sem dependências externas)
├── gfi/                             # núcleo: db, catálogo, conectores/, motores/, pipeline, previsões, backtest, evolução…
├── atualizacoes/                    # ← solte pacotes aqui (LEIAME.md + _modelos/)
├── laboratorio/                     # única área onde a IA escreve código experimental
├── testes/                          # 60 testes automáticos
└── dados/                           # banco e logs (criado ao usar; fora do Git)
```

O acesso SQLite usa transações curtas e fecha as conexões ao terminar cada operação. O contexto `with db.conectar()` também fecha a conexão ao sair.
Testes: `python3 -m unittest discover -s testes -t .` (84 testes automatizados na V5 em desenvolvimento).

## Limites honestos

- **Fontes reais ainda não foram validadas nesta execução**: o ambiente de desenvolvimento está sem resolução DNS. Os parsers B3/BCB passam em testes automatizados com dados sintéticos; isso não comprova download externo. Use *Configurações → Testar conexões* no computador de operação. O endereço padrão anual B3 foi atualizado para `https://bvmf.bmfbovespa.com.br/InstDados/SerHist/COTAHIST_A{ano}.ZIP`; para sobrescrever, defina `GFI_URL_COTAHIST` (com `{ano}`).
- As cotações da B3 vêm **sem ajuste por proventos**; a IA detecta e ajusta por heurística apenas desdobramentos/grupamentos óbvios (e avisa).
- Fundamentos contábeis CVM DFP/ITR já podem ser ingeridos na V6.01 por CNPJ e conta; a ligação automática ao ticker e a alimentação do motor de valuation ainda não estão ativadas. Setores continuam dependendo de cadastro/importação.
  Sem eles, os sinais de saúde, crescimento e valuation ficam **cinza** — o índice usa só o que sabe.
- Na demonstração os preços têm tendências embutidas de propósito: o backtest "funcionar" ali **não prova nada** sobre o mercado real.
- Um backtest positivo no passado também não garante o futuro.

## Próximos passos sugeridos

1. Rodar com dados reais por algumas semanas e acompanhar *Autoavaliação* e *Previsões*: só com 100+ previsões avaliadas há conclusão séria.
2. Importar fundamentos da CVM (DFP/ITR) por pacote de atualização.
3. Fase 6 completa: modelos estatísticos/ML com validação fora da amostra, usando o backtest como juiz.
4. Fase 4: conectores de notícias e reguladores com fontes licenciadas.

## Versão V3 — provedor intradiário

A V3 adiciona um adaptador público Yahoo Finance Chart API e duas rotas locais: `POST /api/live/coletar` e `GET /api/live/{instrumento_id}`. Consulte `VERSAO_V3.md` para parâmetros, comandos de teste e limitações. A fonte não oferece garantia de tempo real ou SLA.


## Versão V4 — coleta LIVE automática

A V4 integra o conector Yahoo Finance da V3 ao agendador existente. A coleta automática fica **desligada por padrão** e só consulta instrumentos REAL ativos cadastrados na B3 (MIC BVMF/XBSP). Para ativar, envie `POST /api/live/auto` com `{"ativo": true, "intervalo_segundos": 60}` e cabeçalho `X-GFI: 1`. Para desligar, use `{"ativo": false}`. O intervalo permitido é de 60 a 3600 segundos. Consulte `GET /api/live/status` para estado, última execução e falhas. A classificação permanece `DELAYED`; não há garantia de cotação em tempo real. Em modo demonstração a coleta LIVE não executa.


## V5 — Fase 2: fortalecimento da coleta (em desenvolvimento)

A V5 começou pela revisão dos conectores existentes, sem criar uma segunda arquitetura:

- B3 COTAHIST: corrigido o caminho padrão de distribuição anual para `InstDados/SerHist`; validação de data civil, ticker, preços OHLC, quantidade e volume; rejeição de ZIP corrompido ou sem membro COTAHIST reconhecível.
- B3: o mercado fracionário (BDI 96) deixou de ser importado junto com o lote padrão, evitando que dois registros do mesmo ticker/pregão disputem a mesma chave histórica.
- BCB SGS: parser agora aceita bytes UTF-8, valida datas, descarta valores não finitos, normaliza decimal brasileiro e ordena/deduplica observações por data.
- Base HTTP: rejeita resposta vazia e mantém limite máximo de bytes e timeout.
- Testes: 84 testes automatizados aprovados no estado atual.

**Ainda pendente nesta fase:** testar downloads reais no computador de operação; auditar a cobertura histórica B3; validar periodicidade/unidades das séries SGS; melhorar ingestão incremental; implementar coleta CVM DFP/ITR. A rede deste ambiente não resolveu DNS durante os testes, portanto nenhum download real foi confirmado aqui.

Referências oficiais: [B3 — Cotações históricas](https://www.b3.com.br/pt_br/market-data-e-indices/servicos-de-dados/market-data/historico/mercado-a-vista/cotacoes-historicas/) e [layout COTAHIST](https://www.b3.com.br/data/files/33/67/B9/50/D84057102C784E47AC094EA8/SeriesHistoricas_Layout.pdf).

## V6.01 — CVM DFP/ITR

A V6.01 adiciona ingestão estruturada dos arquivos oficiais de demonstrações financeiras da CVM. Consulte `VERSAO_V6_01.md` para escopo, rotas, formato e limitações. A situação da base fica disponível em `GET /api/cvm/status`; a coleta por exercício é solicitada em `POST /api/cvm/coletar` com `documento` (`DFP` ou `ITR`) e `ano`. Os lançamentos permanecem associados ao CNPJ até que um operador confirme o vínculo com um instrumento.

**Importante:** o conector foi testado com arquivos ZIP/CSV de fixture e testes automatizados; download real da CVM ainda precisa ser confirmado no computador com internet.


## V6.02 — CVM

Consulte `VERSAO_V6_02.md` para robustez da ingestão CVM, cobertura e consulta por instrumento após vínculo confirmado.

## V6.03 — dicionário contábil CVM

A V6.03 acrescenta a primeira camada de classificação conservadora dos lançamentos CVM. Consulte `VERSAO_V6_03.md`. O dicionário associa códigos exatos às famílias BPA, BPP, DRE e DFC; não soma subcontas, não converte escala e não alimenta valuation. Rotas: `GET /api/cvm/dicionario` e `GET /api/cvm/indicadores/{cnpj}`. Códigos sem regra permanecem explicitamente não mapeados. A versão foi validada com 95 testes e smoke tests HTTP locais; os downloads externos ainda precisam de validação na máquina de operação.


## V6.04 — operação e auditoria B3 COTAHIST

A V6.04 acrescenta validação dos anos, coleta manual protegida e diagnóstico da cobertura B3. Consulte `VERSAO_V6_04.md`. Rotas: `GET /api/b3/status` e `POST /api/b3/coletar` (cabeçalho `X-GFI: 1`, corpo `{"anos":[2024,2025]}`). A coleta manual é bloqueada no modo demonstração. A versão passou em 98 testes locais; o download anual real ainda precisa ser executado e conferido na máquina com internet.

## Central de Inteligência Artificial da GFI — V6.11

A navegação inclui **Central IA GFI**, um agente de evolução autônoma supervisionada (nível 3). Ele pode executar ciclos periódicos de inventário, pesquisa web pública e diagnóstico; quando há um LLM acessível, também gera relatórios e código experimental. Os relatórios ficam em `dados/gfi_ai/relatorios/` e o código em `laboratorio/gfi_ai/propostas/`.

O agente não altera o núcleo de produção, não executa código gerado e não ativa atualizações. O ciclo periódico inicia ativo por padrão (24 horas), pode ser pausado no painel e também pode ser executado manualmente. Para configurar um endpoint compatível com OpenAI, defina `GFI_AI_LLM_URL`, `GFI_AI_LLM_MODEL` e opcionalmente `GFI_AI_LLM_API_KEY` antes de executar `./iniciar.sh`. Se não houver modelo acessível, o painel informa isso e ainda pode produzir inventário/pesquisa, sem fingir que uma LLM analisou o sistema. Consulte `../../../VERSAO_V6_11.md` para detalhes.


## V7 — integração operacional

A V7 mantém o ledger CVM DFP/ITR, a Central IA GFI e a fundação intradiária da V6.11, integrando melhorias operacionais da V6: acesso remoto protegido por token (`./iniciar.sh --rede`), LIVE em fio próprio com rodízio e controle de recursos, agenda persistente, coleta B3 incremental de três anos, fila de pesquisa com tolerância por periodicidade, baselines no backtest e tratamento de saltos sem explicação. O conector CVM DFP/ITR da V6.11 foi preservado; a integração FCA antiga continua pendente por incompatibilidade de esquema. Consulte `../../../VERSAO_V7.md`.


## V10 — WebMobile + saldo global
A V10 adiciona layout mobile dedicado com wallpaper vertical MY UNIVERSE, navegação otimizada para toque e saldo de caixa global no topo, sincronizado com Minha Conta (painel 19), com ocultação/revelação persistente no navegador. Consulte `sites/laboratorio-ti/inteligencia-financeira/VERSAO_V10.md`.
