#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python -m compileall -q gfi testes
node --check ui/app.js
bash -n iniciar.sh
python -m unittest discover -s testes -v
