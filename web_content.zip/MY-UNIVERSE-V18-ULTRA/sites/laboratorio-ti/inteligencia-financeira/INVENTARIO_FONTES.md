# GFI — Inventário inicial de fontes (base V6.05)

Data da inspeção do pacote: 21/11/2026. Este inventário descreve o que foi localizado no código e no banco incluídos no ZIP. Não representa teste de conectividade na máquina de operação nem homologação de dados externos.

| Grupo | Fonte / finalidade | Fonte preferencial identificada | Situação no código V6.06 | Classificação / pendência |
|---|---|---|---|---|
| Cotações e negócios | B3 COTAHIST — histórico diário de preços, quantidades e volumes | B3 — Séries Históricas COTAHIST | Conector e parser existentes | **Obrigatória** para histórico diário do universo B3; download e cobertura real ainda precisam homologação |
| Cadastro de instrumentos | Ticker, ISIN, tipo, mercado, situação e características dos ativos | B3 — Dados Públicos / Cadastro de Instrumentos (Listado) | Catálogo local existe; importação oficial completa não comprovada | **Obrigatória** para universo confiável; mapear layout, frequência e retenção histórica |
| Indicadores macroeconômicos | Selic, inflação, câmbio, atividade, emprego e dívida pública | Banco Central — SGS | Conector existente com sete códigos configurados | **Obrigatória** para camada macro; validar cada código, unidade, periodicidade e histórico |
| Demonstrações financeiras | Balanço, DRE, DFC, DVA e DMPL de companhias abertas | CVM — Dados Abertos DFP e ITR | Conector e parser existentes | **Obrigatória** para análise fundamentalista de companhias abertas; validar download e cobertura |
| Cadastro e informes de fundos | Dados cadastrais e informes de fundos, inclusive FIIs, conforme universo | CVM — Dados Abertos de Fundos de Investimento | Não foi localizado conector dedicado | **Condicional ao escopo** de FIIs/fundos; identificar datasets, layouts e histórico antes de implementar |
| Eventos corporativos e proventos | Dividendos, JCP, bonificações, desdobramentos, grupamentos, subscrições e datas | B3 — Eventos Corporativos / UP2DATA; comunicados e documentos oficiais dos emissores/CVM | Não foi localizado conector dedicado | **Obrigatória** para preços ajustados e análise de proventos; verificar acesso, formato, licença e cobertura histórica. Não automatizar raspagem de páginas cujo termo proíba coleta automatizada |
| Calendário de pregões | Pregões, feriados, sessões especiais e horários | B3 — Calendário do Mercado / ofícios circulares | Não foi localizado conector dedicado | **Obrigatória** para validar lacunas temporais; manter versão por ano e registrar alterações oficiais |
| Classificação econômica | Setor, subsetor e segmento de cada emissor | B3 — Classificação Setorial | Configuração estática e importação parcial | **Obrigatória** para análise setorial; importar classificação oficial versionada e manter histórico |
| Cotações complementares | Cotação auxiliar e histórico de curto prazo | Yahoo Finance Chart | Adaptador existente; grava como `DELAYED` | **Complementar**, nunca fonte oficial primária nem garantia de tempo real; verificar disponibilidade, termos e atraso |
| Renda fixa pública | Preços, taxas e histórico de títulos do Tesouro Direto | Tesouro Transparente — conjunto “Taxas dos Títulos Ofertados pelo Tesouro Direto” | Não foi localizado conector dedicado | **Condicional** se a GFI analisar renda fixa/Tesouro; conjunto público com arquivo diário, validar histórico e formato |
| Renda fixa privada e índices ANBIMA | Debêntures, títulos públicos, curvas e índices IMA/IDA | ANBIMA Feed / ANBIMA Data | Não foi localizado conector dedicado | **Condicional** ao módulo de renda fixa; confirmar autenticação, contrato, licença e custo antes de integrar |
| Indicadores oficiais complementares | Séries econômicas e validação cruzada de estatísticas | IBGE — SIDRA/API e publicações oficiais | Não foi localizado conector dedicado | **Complementar** para conferir PIB, inflação e mercado de trabalho; evitar duplicar séries já cobertas adequadamente pelo BCB |
| Notícias e fatos relevantes | Comunicados, fatos relevantes, avisos e notícias regulatórias | CVM, B3 e páginas oficiais de Relações com Investidores; provedor de notícias licenciado se necessário | Há estrutura interna de eventos/pesquisa, mas não foi comprovado coletor de notícias oficiais | **Necessária apenas** se a camada de notícias/regulação permanecer no escopo; definir fonte, direitos de uso, timestamp e deduplicação |

## Escopo preliminar identificado

O código e os motores existentes indicam foco inicial em instrumentos negociados na B3, indicadores macroeconômicos brasileiros e fundamentos de companhias abertas. O parser COTAHIST atual reconhece lotes do mercado à vista selecionados, incluindo ações, FIIs e ETFs; o catálogo também prevê BDRs e units, mas isso não comprova cobertura integral de todos esses segmentos. Derivativos, renda fixa privada, fundos não listados e universo internacional não devem ser presumidos como cobertos.

Para concluir a Tarefa 1 ainda é necessário confirmar formalmente: (1) se o universo inclui ações, FIIs, ETFs, BDRs e units; (2) se inclui renda fixa/Tesouro, debêntures e fundos; (3) se a cobertura será somente Brasil ou também exterior; (4) se notícias e fatos relevantes serão parte da coleta; e (5) qual profundidade histórica mínima será exigida por classe de dado.

## Regras de proveniência

- COTAHIST é histórico diário oficial; não deve ser apresentado como feed intradiário ou cotação em tempo real.
- Yahoo Chart é complementar; estado `DELAYED` não pode ser rotulado como `REALTIME`.
- Dados simulados devem permanecer isolados e identificados; nunca completar silenciosamente lacunas de dados reais com valores simulados.
- Dados CVM devem permanecer identificados por CNPJ, documento, exercício/período, conta, versão/reapresentação, moeda, escala e fonte.
- Evento corporativo sem fonte e datas verificáveis não pode gerar fator de ajuste de preço.
- Para cada coleta, preservar fonte, URL/identificador do arquivo, instante de coleta, período de referência, resultado, contagem e erro.

## Referências oficiais consultadas nesta revisão

- B3 — [Dados disponíveis / UP2DATA](https://www.b3.com.br/pt_br/market-data-e-indices/servicos-de-dados/up2data/dados-disponiveis/): cadastro de instrumentos listados e eventos corporativos; verificar condições específicas de cada canal.
- B3 — [Dados públicos](https://www.b3.com.br/pt_br/dados/hub-de-dados-publicos/): séries históricas, cotações e conjuntos de dados por mercado. A própria página informa restrições a coleta automatizada; não tratar a página como autorização de scraping.
- B3 — [Calendário do mercado 2026](https://www.b3.com.br/main.jsp?lumA=1&lumII=8A80CB81633FBF0B0163402956733E3A&lumPageId=8A6882694E91F2D4014E9248DBB001C9): calendário oficial e sessões especiais.
- CVM — [DFP](https://dados.cvm.gov.br/dataset/cia_aberta-doc-dfp): demonstrações padronizadas, histórico desde 2010 e atualizações semanais de reapresentações.
- CVM — [ITR](https://dados.cvm.gov.br/dataset/cia_aberta-doc-itr): demonstrações trimestrais, histórico desde 2011 e atualizações semanais.
- Tesouro Transparente — [Tesouro Direto](https://www.tesourotransparente.gov.br/temas/divida-publica-federal/tesouro-direto): preços e taxas com conjunto diário para download.
- ANBIMA — [Documentação Preços e Índices](https://developers.anbima.com.br/pt/documentacao/precos-indices/swagger-precos-indices/): APIs para títulos públicos, debêntures e índices; acesso deve ser verificado por pacote/credencial.

## Estado da Tarefa 1

**Em andamento — inventário ampliado, ainda não homologado.** Foram identificados 13 grupos de fontes e separadas fontes obrigatórias do núcleo atual, complementares e condicionais a módulos adicionais. A tarefa não será concluída até o responsável confirmar o universo de ativos, a abrangência geográfica, o histórico mínimo e a inclusão ou não de renda fixa e notícias. A existência de uma página pública não significa autorização para raspagem automatizada nem acesso gratuito a todos os produtos de dados.
