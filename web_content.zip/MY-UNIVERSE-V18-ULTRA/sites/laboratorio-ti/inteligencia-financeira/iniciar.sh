#!/usr/bin/env bash
# Inicia a IA financeira.
#   ./iniciar.sh          só neste computador -> http://127.0.0.1:8780
#   ./iniciar.sh --rede   acesso na rede local protegido por token
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ "${1:-}" == "--rede" ]]; then export GFI_HOST=0.0.0.0; fi
exec python3 servidor.py
