# MY UNIVERSE — V6.01

**Foco:** Fase 2 — expansão da coleta de dados com integração inicial da CVM DFP/ITR.

## Entregas

- Novo conector `gfi/conectores/cvm.py` para os arquivos estruturados oficiais de companhias abertas da CVM.
- Suporte a DFP e ITR por exercício, com leitura dos CSVs consolidados de BPA, BPP, DRE, DRA, DFC, DMPL e DVA.
- Normalização de CNPJ, data de referência, exercício, versão, código/descrição da conta, valor, moeda, escala, grupo e arquivo de origem.
- Persistência em `cvm_lancamentos`, separada dos fundamentos antigos, com chave idempotente para evitar duplicação em reimportações.
- Cadastro explícito `cvm_emissores` para mapear CNPJ a instrumento somente após confirmação humana. Nenhum ticker é inferido.
- Proteções contra ZIP corrompido, CSV sem colunas essenciais, arquivo individual excessivo, ZIP acima do limite e CSV acima do limite de linhas.
- Registro das coletas na tabela já existente `coletas`.
- Rotas: `GET /api/cvm/status`, `POST /api/cvm/coletar`, `POST /api/cvm/importar` (ZIP em Base64) e `POST /api/cvm/mapear`.
- Testes automatizados para parser, preservação de valores zero, idempotência, ZIP inválido e validação de parâmetros.

## Como utilizar

Consultar situação: `GET http://127.0.0.1:8780/api/cvm/status`.

Coletar DFP 2024 (exemplo):

```bash
curl -X POST http://127.0.0.1:8780/api/cvm/coletar \\
  -H 'Content-Type: application/json' -H 'X-GFI: 1' \\
  -d '{"documento":"DFP","ano":2024}'
```

Coletar ITR: altere `documento` para `ITR`. A coleta exige internet no computador que executa o GFI.

## Limitações explícitas

- A coleta externa depende de conectividade e disponibilidade do portal da CVM; não foi possível confirmar download real neste ambiente.
- Os dados são guardados por CNPJ e conta. A associação a ticker exige conferência e chamada explícita a `POST /api/cvm/mapear`.
- Esta entrega importa os arquivos consolidados selecionados; não substitui auditoria de todas as categorias, versões, reapresentações, companhias canceladas e mudanças de CNPJ.
- O motor de valuation ainda não foi ligado automaticamente aos novos lançamentos CVM. A V6.01 prepara a ingestão rastreável sem alterar resultados financeiros existentes.

## Compatibilidade e preservação

A V6.01 parte integralmente da V5, mantém o banco SQLite existente e cria tabelas adicionais sob demanda. Nenhuma tabela ou funcionalidade anterior foi removida. O pacote inclui o projeto completo.

## Resultado dos testes desta entrega

- `python -m compileall -q gfi servidor.py` — aprovado.
- `python -m unittest discover -s testes -t .` — **88 testes aprovados** (84 da V5 + 4 novos testes CVM).
- Os testes CVM usam fixture local controlada; não simulam uma confirmação de disponibilidade externa.
