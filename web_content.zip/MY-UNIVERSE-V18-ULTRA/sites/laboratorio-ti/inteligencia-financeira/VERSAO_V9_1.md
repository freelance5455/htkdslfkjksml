# MY UNIVERSE V9.1 — atualização automática e integridade

## Escopo
- Ciclo automático de 60 segundos ativado por padrão na inicialização de instalação real (sem sobrescrever a preferência já gravada).
- O modo demonstração bloqueia a coleta externa real.
- Coleta intradiária em rodízio sobre todos os instrumentos REAL ativos cadastrados; tickers B3 recebem sufixo `.SA`, demais símbolos usam o ticker cadastrado; cursor persistente para avançar pelo universo.
- Recálculo incremental do pipeline de pontuação/indicadores após ciclos com novas respostas.
- Estado da automação, universo ativo, horário do último ciclo, duração, sucessos/falhas, classificação da fonte e recálculo expostos em `/api/v9/status`.
- Cabeçalho do painel mostra a automação e a dimensão do universo REAL cadastrado.
- Preservação de proveniência: provedor, horário observado, horário de coleta e classificação DELAYED; duplicatas são ignoradas pelo armazenamento existente.

## Limites de frequência por fonte
O ciclo de 60 s é o orquestrador, não uma promessa de que cada fonte publique dados novos a cada minuto. Cotações são consultadas em rodízio, respeitando latência e limites do provedor. BCB/SGS, CVM/DFP/ITR, B3/COTAHIST e notícias continuam com periodicidade própria, adequada à publicação e ao custo de cada fonte. Dados não publicados ou não alterados não são artificialmente atualizados.

## Integridade
- Modo REAL separado de SIMULADO.
- Validações existentes de preço finito/positivo, volume, fuso horário, vínculo do ticker e origem REAL.
- Histórico intradiário não é sobrescrito; chave única evita duplicatas por instrumento/provedor/horário observado.
- Falhas individuais não interrompem o lote. Erros e status ficam registrados.
- Yahoo Finance Chart é fonte pública sem SLA; snapshots são classificados DELAYED, nunca REALTIME.

## Homologação
- `compileall`, `node --check` e suíte GFI executados.
- Teste real de conectividade/provedor depende da internet e do ambiente onde a MY UNIVERSE será executada; não foi declarado como aprovado no ambiente de build.
- Cobertura total por minuto não é garantida: o sistema percorre o universo em lotes. Para cumprir janela rígida de 60 s por ativo seria necessária fonte licenciada com API bulk/SLA e limites compatíveis.

- Notícias RSS: atualização automática agendada a cada 15 minutos, com cache e origem/publicação preservados.
