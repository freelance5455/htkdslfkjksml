# V6 — operação real, segurança e fundamentos da CVM

Base: V5 (o que você enviou). Validado em uma **cópia** do seu banco real (989 ativos ativos da B3, jan/2025–nov/2026). 120 testes da IA financeira + 28 do NEXUS passam.

## O que o V5 tinha e o V6 corrige

| Problema encontrado no V5 | Correção no V6 |
|---|---|
| A IA escutava em `0.0.0.0` **sem login**, com IP `192.168.0.12` fixo no código: qualquer aparelho da rede podia alterar configuração, ativar atualizações e disparar coletas | Padrão volta a `127.0.0.1`. Para usar na rede: `./iniciar.sh --rede` (ou `GFI_HOST=0.0.0.0`) **exige token** (mostrado no terminal, guardado em `dados/token.txt`, entregue por cookie). `Host` aceito só se for `localhost` ou IP literal local/privado na porta certa (sem IP fixo no código) |
| LIVE (Yahoo) rodava **dentro** do fio do agendador: 100 consultas seguidas travavam coletas e recálculos, sem limite de requisições | LIVE tem fio próprio, lote em rodízio (`GFI_LIVE_LIMITE`, padrão 30), ≤ ~40 consultas/min, tempo máximo por ciclo e adia sob pressão de CPU/RAM. Continua **desligado** até você ativar |
| Só 8 de 40 ativos tinham índice; modo econômico pontuava 40 ativos por hora | Lotes maiores (150/600/5000). Todos os 989 ativos são pontuados em ~13 s. Fundos imobiliários (`reit`) passaram a ter pesos próprios (sem balanço de empresa) |
| Fila de pesquisa com alertas obsoletos ("fonte indisponível" mesmo depois de a coleta funcionar; "desocupação desatualizada" com atraso normal de divulgação) | Só alerta se a **última** coleta da fonte falhou; tolerância por periodicidade (diária 10 d, mensal 75 d, trimestral/PNAD 130 d); itens resolvidos são concluídos sozinhos |
| Log inundado com "sob pressão de recursos" a cada minuto | Mensagem repetida no máximo a cada 10 min |
| Reiniciar o programa refazia coletas longas (B3 ≈ 5 min por ano) | Horários das tarefas persistem no banco; anos encerrados da B3 não são baixados de novo; padrão agora são **3 anos** de histórico (`GFI_ANOS_B3`) para o sinal de longo prazo |
| **Falsos bloqueios**: 65 dos 100 ativos bloqueados por "volatilidade extrema/queda > 70%" tinham desdobramento/grupamento não ajustado (ex.: MGLU3 com vol. de 205%) | Mais razões de grupamento reconhecidas (8, 15, 25, 30, 50, 100…). Salto **sem explicação** deixa de bloquear: o risco fica marcado como "incerto" e o índice é limitado a 55. Bloqueios caíram de 342 para 304 — o restante é iliquidez real (< R$ 100 mil/dia) |
| Imagem de fundo do painel dificultava a leitura | Camada escura sobre a imagem |

## Novidades

- **Conector da CVM** (`gfi/conectores/cvm.py`): cadastro (setor), FCA (liga ticker ↔ empresa e traz o segmento de listagem) e DFP (demonstrações anuais). Preenche receita, lucro, EBIT, EBITDA, dívida líquida, FCF aproximado, patrimônio e ações, mais governança (proxy pelo segmento) e setor (inferido). Tarefa `coletar_cvm` semanal e botão em Configurações. **Aproximações documentadas no topo do arquivo.**
- **Backtest com baselines**: a IA é comparada a *momentum* e *baixa volatilidade* nos mesmos ativos e custos; se tem "indício" mas não supera os baselines, o veredito diz isso.
- Painel: cards de **CVM** e **LIVE** em Configurações; tabela de baselines no backtest; teste de conexão inclui CVM; `GET /api/cvm/status`.

## Efeito medido no seu banco real (cópia)

| | V5 | V6 |
|---|---|---|
| Ativos pontuados | 40 | **989** (13 s) |
| Com índice | 8 | **535** (ETFs e FIIs) |
| Ações (ON/PN/units) com índice | 0 | 0 — ainda **cinza de propósito**: faltam fundamentos e setor (rode *Coletar CVM*) e histórico (3 anos de B3) |
| Bloqueados | — | 304 (294 por iliquidez real) |

## O que NÃO foi testado

- **O download real da CVM**: o ambiente onde o V6 foi construído não tem internet. Os parsers seguem o layout público da CVM (`dfp_cia_aberta_{ano}.zip`, `fca_cia_aberta_{ano}.zip`, `cad_cia_aberta.csv`) e passam em arquivos sintéticos, mas só o seu PC confirma. Use *Configurações → Testar conexões* e depois *Coletar CVM agora*; falhas ficam em *Saúde dos serviços* e na fila de pesquisa, sem derrubar nada.
- Setor inferido do texto da CVM e FCF aproximado podem errar: confira alguns tickers conhecidos antes de confiar nos rankings fundamentalistas.

## Como atualizar do V5

1. Copie a pasta `inteligencia-financeira/` do V6 **sobre** a do V5, mantendo a sua pasta `dados/` (o banco migra sozinho: só cria tabelas novas; a migração foi testada numa cópia do seu banco).
2. `./iniciar.sh` (só neste PC) ou `./iniciar.sh --rede` (com token).
3. Configurações → *Coletar B3* (puxa os 3 anos) → *Coletar CVM agora* → *Recalcular tudo*.

## Pendências (honestas)

- Relatório mestre de documentação para colar em outras IAs: **não concluído** (o gerador ficou de fora do pacote para não entregar um documento incompleto).
- Machine Learning (Fase 6) e coleta automática de notícias/reguladores (Fase 4) seguem pendentes; agregação/visualização intradiária idem.
- Dividend yield e dividendos por ação (ranking de dividendos) seguem sem fonte automática.
