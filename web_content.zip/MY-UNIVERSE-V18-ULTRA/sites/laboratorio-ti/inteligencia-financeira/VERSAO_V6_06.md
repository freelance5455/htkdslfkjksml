# MY UNIVERSE / GFI — V6.06

## Objetivo

Introduzir o plano operacional de finalização da coleta de dados com 145 tarefas rastreáveis em 16 etapas, sem substituir os conectores, motores ou estruturas preexistentes da GFI.

## Alterações

- Criado `gfi/plano_coleta.py` com as 145 tarefas, 16 etapas, inventário inicial de oito grupos de fontes e estados persistidos.
- Criada a tabela SQLite `gfi_plano_tarefas`, separada das tabelas de mercado e fundamentos.
- Criada a rota `GET /api/plano-coleta` para consultar plano, progresso e inventário.
- Criada a rota `POST /api/plano-coleta/atualizar` para registrar status, evidência, validação e responsável.
- A conclusão exige evidência e validação com conteúdo mínimo; as tarefas não são concluídas automaticamente por presença de código.
- Adicionado o painel **Plano de coleta** à interface da GFI, com progresso geral, progresso por etapa, lista de tarefas, atualização de estado e inventário de fontes.
- Tarefa 1 iniciada como **Em andamento**: grupos de fontes e conectores identificados; falta confirmar cobertura, origem, periodicidade e acesso.
- Criados `PLANO_COLETA_145.md` e `INVENTARIO_FONTES.md`.

## Limites desta versão

- Nenhuma coleta externa foi executada durante esta alteração.
- Não foram declaradas homologadas B3, BCB, CVM ou Yahoo Finance.
- Eventos corporativos e calendário de pregões permanecem como fontes não comprovadas no pacote-base.
- O inventário do banco incluído no ZIP não foi substituído por dados de produção.

## Testes

Resultados de compilação, testes automatizados e smoke tests desta versão devem ser registrados abaixo após execução no pacote final. A versão só deve ser considerada validada depois desses resultados.
