"""Configuração central. Nada aqui contém senhas ou chaves: chaves vêm de variáveis de ambiente."""
import os
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DADOS = Path(os.environ.get("GFI_DADOS", RAIZ / "dados"))
UI = RAIZ / "ui"
LAB = RAIZ / "laboratorio"                       # único local onde código experimental pode ser escrito
NOME = os.environ.get("GFI_NOME", "GLOBAL FINANCIAL INTELLIGENCE")
HOST = os.environ.get("GFI_HOST", "127.0.0.1")   # 127.0.0.1 = só este PC; 0.0.0.0 = rede (exige token)
HOSTS_EXTRAS = {h.strip() for h in os.environ.get("GFI_HOSTS_EXTRAS", "").split(",") if h.strip()}
ANOS_B3 = int(os.environ.get("GFI_ANOS_B3", "3"))
LIVE_LIMITE = int(os.environ.get("GFI_LIVE_LIMITE", "30"))
PORTA = int(os.environ.get("GFI_PORTA", "8780"))
VERSAO_MODELO = "1.0"

MODOS = {   # lote = ativos processados por rodada; pausa = segundos entre tarefas; cpu_max/ram_max = limites
    "economico":    {"lote": 150,  "pausa": 3600, "cpu_max": 50, "ram_max": 60},
    "normal":       {"lote": 600,  "pausa": 900,  "cpu_max": 75, "ram_max": 75},
    "intensivo":    {"lote": 5000, "pausa": 120,  "cpu_max": 90, "ram_max": 85},
    "experimental": {"lote": 250,  "pausa": 900,  "cpu_max": 75, "ram_max": 75},
}
MODO_PADRAO = "normal"

DIMENSOES = ["economia", "juros", "inflacao", "saude", "crescimento", "valuation", "noticias", "regulacao",
             "governanca", "tecnica", "liquidez", "volatilidade", "geopolitica", "risco", "longo_prazo"]
ROTULOS = {"economia": "Economia", "juros": "Juros", "inflacao": "Inflação", "saude": "Saúde financeira",
           "crescimento": "Crescimento", "valuation": "Valuation", "noticias": "Notícias", "regulacao": "Regulação",
           "governanca": "Governança", "tecnica": "Análise técnica", "liquidez": "Liquidez",
           "volatilidade": "Volatilidade", "geopolitica": "Geopolítica", "risco": "Risco",
           "longo_prazo": "Perspectiva de longo prazo"}
PESOS_PADRAO = {"economia": 4, "juros": 4, "inflacao": 3, "saude": 12, "crescimento": 8, "valuation": 10,
                "noticias": 5, "regulacao": 4, "governanca": 4, "tecnica": 10, "liquidez": 8, "volatilidade": 7,
                "geopolitica": 3, "risco": 10, "longo_prazo": 8}
# Ajustes por tipo de ativo (multiplicadores): ETFs/índices não têm balanço, por exemplo.
PESOS_POR_TIPO = {"etf": {"saude": 0, "crescimento": 0, "valuation": 0, "governanca": 0, "tecnica": 1.5, "risco": 1.3},
                  "reit": {"saude": 0, "crescimento": 0, "valuation": 0, "governanca": 0, "tecnica": 1.5, "risco": 1.3},
                  "indice": {"saude": 0, "crescimento": 0, "valuation": 0, "governanca": 0, "liquidez": 0}}

LIMIARES = {"verde": 60, "amarelo": 40}          # índice >= verde → verde; >= amarelo → amarelo; senão vermelho
JANELA_ATUALIZADO_DIAS = 7                       # cotação mais velha que isso = dado desatualizado
MIN_CANDLES = 60
LIQUIDEZ_VERDE = 5_000_000.0                     # volume financeiro médio diário (moeda local)
LIQUIDEZ_MINIMA = 100_000.0
TAXA_DESCONTO = 0.13
CRESCIMENTO_PERPETUO = 0.04
COBERTURA_MINIMA = 0.40                          # abaixo disso o índice geral não é calculado (cinza)
LIMITE_COM_BLOQUEIO = 35.0

SETORES_B3 = ["Financeiro", "Petróleo, Gás e Biocombustíveis", "Materiais Básicos", "Utilidade Pública",
              "Consumo Não Cíclico", "Consumo Cíclico", "Saúde", "Bens Industriais", "Comunicações",
              "Tecnologia da Informação", "Outros"]
# Hipóteses editáveis: efeito de cada fator macro sobre cada setor (-2 muito negativo … +2 muito positivo).
SENSIBILIDADE = {
    "juros":    {"Financeiro": 1, "Consumo Cíclico": -2, "Bens Industriais": -1, "Utilidade Pública": -1, "Saúde": -1,
                 "Tecnologia da Informação": -1, "Comunicações": -1, "Materiais Básicos": 0,
                 "Petróleo, Gás e Biocombustíveis": 0, "Consumo Não Cíclico": 0},
    "inflacao": {"Consumo Cíclico": -1, "Consumo Não Cíclico": -1, "Utilidade Pública": 1, "Materiais Básicos": 1,
                 "Petróleo, Gás e Biocombustíveis": 1, "Financeiro": 0, "Bens Industriais": -1, "Saúde": 0,
                 "Tecnologia da Informação": -1, "Comunicações": 0},
    "economia": {"Consumo Cíclico": 2, "Bens Industriais": 1, "Financeiro": 1, "Materiais Básicos": 1,
                 "Tecnologia da Informação": 1, "Comunicações": 0, "Utilidade Pública": 0, "Saúde": 0,
                 "Consumo Não Cíclico": 0, "Petróleo, Gás e Biocombustíveis": 1},
}
