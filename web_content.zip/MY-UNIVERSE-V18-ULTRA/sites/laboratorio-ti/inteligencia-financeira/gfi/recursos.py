"""Monitor de CPU, RAM e disco (sem dependências) e redução automática de carga."""
import os
import shutil
import time

from . import config, db


def _meminfo():
    try:
        d = {}
        with open("/proc/meminfo") as f:
            for linha in f:
                k, v = linha.split(":")
                d[k] = int(v.split()[0])
        return d
    except OSError:
        return {}


def medir():
    """CPU (carga de 1 min normalizada pelos núcleos) e RAM em %; None quando o sistema não informa."""
    n = os.cpu_count() or 1
    try:
        cpu = round(min(100.0, os.getloadavg()[0] / n * 100), 1)
    except (OSError, AttributeError):
        cpu = None
    m = _meminfo()
    ram = round(100 * (1 - m["MemAvailable"] / m["MemTotal"]), 1) if "MemAvailable" in m and m.get("MemTotal") else None
    try:
        du = shutil.disk_usage(config.DADOS if config.DADOS.exists() else config.RAIZ)
        disco = round(100 * du.used / du.total, 1)
    except OSError:
        disco = None
    return {"cpu": cpu, "ram": ram, "disco": disco, "nucleos": n, "ts": time.time()}


def modo_atual():
    m = db.cfg_get("modo", config.MODO_PADRAO)
    return m if m in config.MODOS else config.MODO_PADRAO


def sob_pressao(medidas=None):
    """True se CPU ou RAM passaram do limite do modo atual."""
    medidas = medidas or medir()
    lim = config.MODOS[modo_atual()]
    return bool((medidas["cpu"] is not None and medidas["cpu"] > lim["cpu_max"]) or
                (medidas["ram"] is not None and medidas["ram"] > lim["ram_max"]))


def lote_efetivo(medidas=None):
    """Tamanho do lote do modo atual; reduzido a 25% se o computador estiver sob pressão."""
    lote = config.MODOS[modo_atual()]["lote"]
    if sob_pressao(medidas):
        db.log("AVISO", "recursos", "computador sob pressão: carga reduzida")
        return max(10, lote // 4)
    return lote
