"""Dicionário conservador de contas CVM para classificação fundamentalista.

Somente códigos sintéticos/totalizadores conhecidos são classificados. Não há
inferência por palavras da descrição nem soma automática de subcontas.
"""

DICIONARIO = {
    "BPA_con": {
        "1": ("ativo_total", "Ativo total", "saldo"),
        "1.01": ("ativo_circulante", "Ativo circulante", "saldo"),
        "1.02": ("ativo_nao_circulante", "Ativo não circulante", "saldo"),
    },
    "BPP_con": {
        "2.01": ("passivo_circulante", "Passivo circulante", "saldo"),
        "2.02": ("passivo_nao_circulante", "Passivo não circulante", "saldo"),
        "2.03": ("patrimonio_liquido", "Patrimônio líquido", "saldo"),
    },
    "DRE_con": {
        "3.01": ("receita_liquida_vendas", "Receita de venda de bens e/ou serviços", "fluxo"),
        "3.02": ("custo_vendas_servicos", "Custo dos bens e/ou serviços vendidos", "fluxo"),
        "3.03": ("resultado_bruto", "Resultado bruto", "fluxo"),
        "3.05": ("resultado_operacional_antes_financeiro_tributos", "Resultado antes do resultado financeiro e dos tributos", "fluxo"),
        "3.06": ("resultado_financeiro", "Resultado financeiro", "fluxo"),
        "3.07": ("resultado_antes_tributos", "Resultado antes dos tributos sobre o lucro", "fluxo"),
        "3.09": ("resultado_liquido_operacoes_continuadas", "Resultado líquido das operações continuadas", "fluxo"),
        "3.11": ("lucro_prejuizo_periodo", "Lucro/prejuízo do período", "fluxo"),
    },
    "DFC_MD_con": {
        "6.01": ("caixa_operacional", "Caixa líquido das atividades operacionais", "fluxo_caixa"),
        "6.02": ("caixa_investimento", "Caixa líquido das atividades de investimento", "fluxo_caixa"),
        "6.03": ("caixa_financiamento", "Caixa líquido das atividades de financiamento", "fluxo_caixa"),
    },
    "DFC_MI_con": {
        "6.01": ("caixa_operacional", "Caixa líquido das atividades operacionais", "fluxo_caixa"),
        "6.02": ("caixa_investimento", "Caixa líquido das atividades de investimento", "fluxo_caixa"),
        "6.03": ("caixa_financiamento", "Caixa líquido das atividades de financiamento", "fluxo_caixa"),
    },
}


def familia_arquivo(nome):
    nome = str(nome or "").lower()
    for familia in DICIONARIO:
        if familia.lower() in nome:
            return familia
    return None


def classificar(lancamento):
    """Retorna classificação ou None; nunca adivinha família/código."""
    familia = familia_arquivo(lancamento.get("arquivo_origem"))
    if not familia:
        return None
    codigo = str(lancamento.get("codigo_conta") or "").strip()
    item = DICIONARIO[familia].get(codigo)
    if not item:
        return None
    indicador, rotulo, natureza = item
    return {
        "indicador": indicador,
        "rotulo": rotulo,
        "familia": familia,
        "codigo_conta": codigo,
        "natureza": natureza,
        "metodo": "correspondencia_exata_codigo_e_demonstracao",
    }


def listar():
    saida = []
    for familia, contas in DICIONARIO.items():
        for codigo, (indicador, rotulo, natureza) in contas.items():
            saida.append({"familia": familia, "codigo_conta": codigo,
                          "indicador": indicador, "rotulo": rotulo,
                          "natureza": natureza})
    return saida
