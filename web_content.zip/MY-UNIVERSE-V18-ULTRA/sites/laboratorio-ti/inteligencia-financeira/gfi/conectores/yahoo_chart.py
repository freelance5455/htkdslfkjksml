"""Adaptador público Yahoo Finance Chart API para snapshots intradiários.

Uso de pesquisa. Não garante cotação em tempo real nem disponibilidade/SLA.
A classificação DELAYED é conservadora; o atraso efetivo depende da fonte/mercado.
"""
import json
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from .. import db, live

BASE = "https://query1.finance.yahoo.com/v8/finance/chart/"
AGENTE = "Mozilla/5.0 (compatible; GFI/1.0; research)"


def buscar(simbolo, intervalo="1m", periodo="1d", timeout=20):
    simbolo = str(simbolo or "").strip().upper()
    if not simbolo or len(simbolo) > 32 or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789^.-=" for c in simbolo):
        raise ValueError("símbolo inválido")
    if intervalo not in {"1m", "2m", "5m", "15m", "30m", "60m", "1d"}:
        raise ValueError("intervalo não permitido")
    if periodo not in {"1d", "5d", "1mo"}:
        raise ValueError("período não permitido")
    query = urllib.parse.urlencode({"interval": intervalo, "range": periodo, "events": "div,splits"})
    url = BASE + urllib.parse.quote(simbolo, safe="^.-=") + "?" + query
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        if response.status != 200:
            raise RuntimeError("provedor retornou HTTP %s" % response.status)
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError("resposta do provedor excede 2 MB")
    payload = json.loads(raw.decode("utf-8"))
    result = ((payload.get("chart") or {}).get("result") or [None])[0]
    if not result:
        err = (payload.get("chart") or {}).get("error") or {}
        raise RuntimeError((err.get("description") or "provedor não retornou dados")[:200])
    timestamps = result.get("timestamp") or []
    quote = (((result.get("indicators") or {}).get("quote") or [{}])[0])
    opens, highs, lows = quote.get("open") or [], quote.get("high") or [], quote.get("low") or []
    closes, volumes = quote.get("close") or [], quote.get("volume") or []
    rows = []
    for i, stamp in enumerate(timestamps):
        if i >= len(closes) or closes[i] is None:
            continue
        close = float(closes[i])
        if close <= 0:
            continue
        volume = volumes[i] if i < len(volumes) else None
        observado = datetime.fromtimestamp(int(stamp), timezone.utc)
        row = {"observado_em": observado.isoformat(timespec="seconds"),
               "data": observado.astimezone(ZoneInfo("America/Sao_Paulo")).date().isoformat(),
               "preco": close, "volume": float(volume) if volume is not None else None}
        if i < len(opens) and i < len(highs) and i < len(lows) and all(x is not None for x in (opens[i], highs[i], lows[i])):
            row.update(abertura=float(opens[i]), maximo=float(highs[i]), minimo=float(lows[i]))
        rows.append(row)
    return {"simbolo": simbolo, "intervalo": intervalo, "periodo": periodo,
            "exchange": (result.get("meta") or {}).get("exchangeName"),
            "moeda": (result.get("meta") or {}).get("currency"), "pontos": rows}


def coletar(instrumento_id, simbolo, intervalo="1m", periodo="1d"):
    instrumento = db.um("SELECT id,ticker,mic,origem,status FROM instrumentos WHERE id=?", (int(instrumento_id),))
    if not instrumento or instrumento["origem"] != "REAL" or instrumento["status"] != "ativo":
        raise ValueError("instrumento inexistente, inativo ou não pertencente à base REAL")
    base = str(simbolo).upper().removesuffix(".SA")
    if base != instrumento["ticker"].upper():
        raise ValueError("símbolo externo não corresponde ao ticker cadastrado")
    inicio = time.time()
    try:
        pacote = buscar(simbolo, intervalo, periodo)
        antes = live.resumo(instrumento_id)["registros"]
        diarias = 0
        if intervalo == "1d":
            for ponto in pacote["pontos"]:
                if not all(k in ponto for k in ("abertura", "maximo", "minimo")):
                    continue
                o, h, l, c = (float(ponto[k]) for k in ("abertura", "maximo", "minimo", "preco"))
                if min(o, h, l, c) <= 0 or h < l or l > min(o, c) or h < max(o, c):
                    continue
                db.executar("INSERT INTO cotacoes_provedor_diarias "
                            "(instrumento_id,provedor,data,abertura,maximo,minimo,fechamento,volume,estado,coletado_em) "
                            "VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(instrumento_id,provedor,data) DO UPDATE SET "
                            "abertura=excluded.abertura,maximo=excluded.maximo,minimo=excluded.minimo,"
                            "fechamento=excluded.fechamento,volume=excluded.volume,estado=excluded.estado,coletado_em=excluded.coletado_em",
                            (int(instrumento_id), "YAHOO_FINANCE_CHART", ponto["data"], o, h, l, c,
                             ponto.get("volume"), "DELAYED", time.time()))
                diarias += 1
        else:
            for ponto in pacote["pontos"]:
                live.registrar(instrumento_id, "YAHOO_FINANCE_CHART", ponto["observado_em"], ponto["preco"],
                               volume=ponto["volume"], estado="DELAYED")
        depois = live.resumo(instrumento_id)["registros"]
        gravados = max(0, depois - antes) + diarias
        from . import base as conector_base
        conector_base.registrar("YAHOO_FINANCE_CHART", inicio, "ok" if pacote["pontos"] else "vazio", gravados)
        return {"instrumento_id": int(instrumento_id), "ticker": instrumento["ticker"],
                "provedor": "YAHOO_FINANCE_CHART", "estado": "DELAYED", "pontos_recebidos": len(pacote["pontos"]),
                "novos_registros": gravados, "candles_diarios": diarias, "ultimo_ponto": pacote["pontos"][-1] if pacote["pontos"] else None,
                "exchange": pacote["exchange"], "moeda": pacote["moeda"],
                "aviso": "Fonte pública sem SLA; atraso efetivo não garantido. Não classificar como tempo real."}
    except Exception as exc:
        from . import base as conector_base
        conector_base.registrar("YAHOO_FINANCE_CHART", inicio, "erro", 0, str(exc))
        raise
