"""Base dos conectores: respeita limite de requisição, identifica-se e registra cada coleta."""
import time
import urllib.request

from .. import db

AGENTE = "GFI/1.0 (pesquisa pessoal; uso respeitando os termos das fontes)"
_ULTIMA = {}


def limitar(host, intervalo=1.0):
    """Garante um intervalo mínimo entre requisições ao mesmo host (cortesia com a fonte e proteção contra bloqueio)."""
    espera = intervalo - (time.time() - _ULTIMA.get(host, 0))
    if espera > 0:
        time.sleep(espera)
    _ULTIMA[host] = time.time()


def baixar(url, timeout=40, limite_bytes=400_000_000, intervalo=1.0):
    """GET com intervalo mínimo por host. Trata o conteúdo como dado não confiável (nunca executa)."""
    host = url.split("/")[2]
    limitar(host, intervalo)
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE, "Accept": "application/json, application/zip, */*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        status = getattr(r, "status", 200)
        if not 200 <= status < 300:
            raise OSError(f"HTTP {status} ao consultar a fonte")
        dados = r.read(limite_bytes + 1)
    if len(dados) > limite_bytes:
        raise ValueError("resposta maior que o limite permitido")
    if not dados:
        raise ValueError("fonte retornou resposta vazia")
    return dados


def registrar(fonte, inicio, status, registros=0, erro=None):
    db.executar("INSERT INTO coletas(fonte,inicio,fim,status,registros,erro) VALUES(?,?,?,?,?,?)",
                (fonte, inicio, time.time(), status, registros, (erro or "")[:300]))


def testar_fontes():
    """Diagnóstico rápido: cada fonte real responde? (não grava nada). Use para validar a internet/URLs no seu computador."""
    import os
    import urllib.error
    alvos = [("BCB-SGS (Selic)", "https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json", "GET"),
             ("B3-COTAHIST", os.environ.get("GFI_URL_COTAHIST", "https://bvmf.bmfbovespa.com.br/InstDados/SerHist/COTAHIST_A{ano}.ZIP").format(ano=time.localtime().tm_year - 1), "GET"),
             ("CVM-Cadastro", os.environ.get("GFI_URL_CVM_CAD", "https://dados.cvm.gov.br/dados/CIA_ABERTA/CAD/DADOS/cad_cia_aberta.csv"), "GET"),
             ("CVM-DFP", os.environ.get("GFI_URL_CVM_DFP", "https://dados.cvm.gov.br/dados/CIA_ABERTA/DOC/DFP/DADOS/dfp_cia_aberta_{ano}.zip").format(ano=time.localtime().tm_year - 1), "GET")]
    out = []
    for nome, url, metodo in alvos:
        t0 = time.time()
        try:
            headers = {"User-Agent": AGENTE}
            if nome in ("B3-COTAHIST", "CVM-DFP"):
                headers["Range"] = "bytes=0-0"  # evita baixar o ZIP anual inteiro no diagnóstico
            req = urllib.request.Request(url, headers=headers, method=metodo)
            with urllib.request.urlopen(req, timeout=20) as r:
                if metodo == "GET":
                    amostra = r.read(1)
                    if not amostra:
                        raise ValueError("fonte respondeu sem conteúdo")
                out.append({"fonte": nome, "ok": 200 <= r.status < 300, "status": r.status, "ms": int((time.time() - t0) * 1000), "url": url})
        except Exception as e:
            out.append({"fonte": nome, "ok": False, "erro": f"{type(e).__name__}: {e}"[:160], "ms": int((time.time() - t0) * 1000), "url": url})
    return out
