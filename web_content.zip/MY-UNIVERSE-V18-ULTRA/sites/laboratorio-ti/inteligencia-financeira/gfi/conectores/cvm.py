"""Coletor CVM DFP/ITR: ingestão rastreável dos arquivos estruturados oficiais.

Os registros ficam por CNPJ e conta contábil. Não associa CNPJ a ticker sem
cadastro confirmado pelo operador.
"""
import csv
import io
import re
import time
import zipfile
from collections import Counter

from . import base, contas
from .. import db

BASE = "https://dados.cvm.gov.br/dados/CIA_ABERTA/DOC/{doc}/DADOS/{prefix}_{doc_lower}_{ano}.zip"
DOCS = {"DFP": "dfp", "ITR": "itr"}
ARQUIVOS = ("BPA_con", "BPP_con", "DRE_con", "DRA_con", "DFC_MD_con", "DFC_MI_con", "DMPL_con", "DVA_con")
MAX_ZIP = 400_000_000
MAX_ROWS = 5_000_000
MAX_TOTAL_UNCOMPRESSED = 1_500_000_000


def _schema():
    db.executar("""CREATE TABLE IF NOT EXISTS cvm_lancamentos (
      id INTEGER PRIMARY KEY AUTOINCREMENT, cnpj TEXT NOT NULL, tipo_documento TEXT NOT NULL,
      data_referencia TEXT NOT NULL, ano_exercicio INTEGER NOT NULL, versao INTEGER NOT NULL,
      codigo_conta TEXT NOT NULL, descricao_conta TEXT, valor REAL NOT NULL, moeda TEXT,
      escala_moeda TEXT, grupo_exercicio TEXT, arquivo_origem TEXT NOT NULL,
      fonte TEXT NOT NULL, coletado_em REAL NOT NULL,
      UNIQUE(cnpj,tipo_documento,data_referencia,versao,codigo_conta,grupo_exercicio,arquivo_origem));""")
    db.executar("CREATE INDEX IF NOT EXISTS ix_cvm_cnpj_data ON cvm_lancamentos(cnpj,data_referencia)")
    db.executar("""CREATE TABLE IF NOT EXISTS cvm_emissores (
      cnpj TEXT PRIMARY KEY, instrumento_id INTEGER, confirmado_em REAL, observacao TEXT,
      FOREIGN KEY(instrumento_id) REFERENCES instrumentos(id));""")


def _texto(v):
    return (v or "").strip()


def _cnpj(v):
    s = re.sub(r"\D", "", _texto(v))
    return s if len(s) == 14 else None


def _numero(v):
    s = _texto(v).replace(" ", "")
    if not s:
        return None
    # CSV CVM usa decimal com ponto; aceita também vírgula decimal em fixtures.
    if "," in s and "." not in s:
        s = s.replace(",", ".")
    try:
        n = float(s)
        return n if n == n and abs(n) != float("inf") else None
    except ValueError:
        return None


def parse_csv(conteudo, nome_arquivo, doc, ano, limite=MAX_ROWS):
    """Converte CSV estruturado CVM para lançamentos normalizados."""
    try:
        try:
            texto = conteudo.decode("utf-8-sig")
        except UnicodeDecodeError:
            texto = conteudo.decode("latin-1")
    except AttributeError:
        texto = str(conteudo).lstrip("\ufeff")
    leitor = csv.DictReader(io.StringIO(texto), delimiter=";")
    campos = set(leitor.fieldnames or [])
    obrigatorios = {"CNPJ_CIA", "DT_REFER", "CD_CONTA", "VL_CONTA"}
    if not obrigatorios.issubset(campos):
        raise ValueError("CSV CVM sem colunas obrigatórias: " + ", ".join(sorted(obrigatorios - campos)))
    saida = []
    for i, row in enumerate(leitor, 1):
        if i > limite:
            raise ValueError("CSV excedeu o limite de linhas")
        cnpj = _cnpj(row.get("CNPJ_CIA"))
        valor = _numero(row.get("VL_CONTA"))
        data = _texto(row.get("DT_REFER"))
        conta = _texto(row.get("CD_CONTA"))
        # Zero é um valor contábil válido; None representa valor ausente/inválido.
        if not cnpj or valor is None or not conta or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", data):
            continue
        try:
            time.strptime(data, "%Y-%m-%d")
        except ValueError:
            continue
        try:
            versao = int(_texto(row.get("VERSAO")) or 1)
            exercicio = int(_texto(row.get("ORDEM_EXERC")) or ano)
        except ValueError:
            continue
        saida.append({
            "cnpj": cnpj, "tipo_documento": doc, "data_referencia": data,
            "ano_exercicio": exercicio, "versao": max(1, versao),
            "codigo_conta": conta,
            "descricao_conta": _texto(row.get("DS_CONTA"))[:500], "valor": valor,
            "moeda": _texto(row.get("MOEDA")) or "BRL",
            "escala_moeda": _texto(row.get("ESCALA_MOEDA")),
            "grupo_exercicio": _texto(row.get("GRUPO_DFP")) or _texto(row.get("ORDEM_EXERC")) or "NAO_INFORMADO",
            "arquivo_origem": nome_arquivo,
        })
    return saida


def importar_zip(conteudo, doc, ano, fonte="CVM-ARQUIVO-LOCAL"):
    if doc not in DOCS:
        raise ValueError("documento deve ser DFP ou ITR")
    if not isinstance(ano, int) or not 2000 <= ano <= time.localtime().tm_year:
        raise ValueError("ano fora do intervalo permitido")
    if len(conteudo) > MAX_ZIP:
        raise ValueError("ZIP CVM excede o limite de tamanho")
    _schema()
    inicio = time.time()
    inseridos = 0
    arquivos_lidos = 0
    try:
        with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
            ruim = z.testzip()
            if ruim:
                raise ValueError("ZIP CVM corrompido: " + ruim)
            if sum(i.file_size for i in z.infolist()) > MAX_TOTAL_UNCOMPRESSED:
                raise ValueError("Conteúdo descompactado do ZIP CVM excede o limite")
            if any(i.flag_bits & 0x1 for i in z.infolist()):
                raise ValueError("ZIP CVM criptografado não é aceito")
            nomes = [n for n in z.namelist() if n.lower().endswith(".csv") and any(a.lower() in n.lower() for a in ARQUIVOS)]
            if not nomes:
                raise ValueError("ZIP CVM não contém demonstrações consolidadas reconhecidas")
            for nome in nomes:
                # Evita ZIP bomb e arquivos individuais excessivos.
                info = z.getinfo(nome)
                if info.file_size > 250_000_000:
                    raise ValueError("CSV CVM individual excede o limite")
                linhas = parse_csv(z.read(nome), nome, doc, ano)
                arquivos_lidos += 1
                if linhas:
                    with db._usar_conexao() as con:
                        antes = con.total_changes
                        con.executemany("""INSERT OR IGNORE INTO cvm_lancamentos
                        (cnpj,tipo_documento,data_referencia,ano_exercicio,versao,codigo_conta,descricao_conta,valor,moeda,escala_moeda,grupo_exercicio,arquivo_origem,fonte,coletado_em)
                        VALUES (:cnpj,:tipo_documento,:data_referencia,:ano_exercicio,:versao,:codigo_conta,:descricao_conta,:valor,:moeda,:escala_moeda,:grupo_exercicio,:arquivo_origem,:fonte,:coletado_em)""",
                        [dict(r, fonte=fonte, coletado_em=time.time()) for r in linhas])
                        inseridos += con.total_changes - antes
        base.registrar(f"CVM-{doc}", inicio, "ok", inseridos)
        return {"ok": True, "documento": doc, "ano": ano, "arquivos": arquivos_lidos,
                "registros_novos": inseridos, "idempotente": True,
                "nota": "Dados armazenados por CNPJ; nenhum ticker foi inferido."}
    except Exception as exc:
        base.registrar(f"CVM-{doc}", inicio, "erro", 0, str(exc))
        raise


def coletar(doc, ano):
    if doc not in DOCS:
        raise ValueError("documento deve ser DFP ou ITR")
    url = BASE.format(doc=doc, doc_lower=DOCS[doc], ano=ano)
    dados = base.baixar(url, timeout=90, limite_bytes=MAX_ZIP, intervalo=2.0)
    return importar_zip(dados, doc, ano, fonte=url)


def status():
    _schema()
    return {"fonte": "CVM Dados Abertos — CIA_ABERTA/DOC", "documentos": ["DFP", "ITR"],
            "lancamentos": db.um("SELECT COUNT(*) n FROM cvm_lancamentos")["n"],
            "emissores": db.um("SELECT COUNT(DISTINCT cnpj) n FROM cvm_lancamentos")["n"],
            "mapeamentos_confirmados": db.um("SELECT COUNT(*) n FROM cvm_emissores WHERE instrumento_id IS NOT NULL")["n"],
            "periodos": db.consultar("SELECT tipo_documento,MIN(data_referencia) inicio,MAX(data_referencia) fim,COUNT(*) registros,COUNT(DISTINCT cnpj) emissores FROM cvm_lancamentos GROUP BY tipo_documento ORDER BY tipo_documento"),
            "ultimas_coletas": db.consultar("SELECT fonte,inicio,fim,status,registros,erro FROM coletas WHERE fonte LIKE 'CVM-%' ORDER BY id DESC LIMIT 10"),
            "aviso": "Coleta oficial não implica associação automática entre CNPJ e ticker."}


def mapear_emissor(cnpj, instrumento_id, observacao=""):
    _schema()
    cnpj = _cnpj(cnpj)
    inst = db.um("SELECT id FROM instrumentos WHERE id=?", (int(instrumento_id),))
    if not cnpj or not inst:
        raise ValueError("CNPJ ou instrumento inválido")
    db.executar("INSERT INTO cvm_emissores(cnpj,instrumento_id,confirmado_em,observacao) VALUES(?,?,?,?) ON CONFLICT(cnpj) DO UPDATE SET instrumento_id=excluded.instrumento_id,confirmado_em=excluded.confirmado_em,observacao=excluded.observacao",
                (cnpj, int(instrumento_id), time.time(), str(observacao)[:300]))
    return {"ok": True, "cnpj": cnpj, "instrumento_id": int(instrumento_id), "confirmado": True}


def consultar_emissor(cnpj, limite=5000):
    _schema()
    cnpj = _cnpj(cnpj)
    if not cnpj:
        raise ValueError("CNPJ inválido")
    return db.consultar("SELECT * FROM cvm_lancamentos WHERE cnpj=? ORDER BY data_referencia DESC,codigo_conta LIMIT ?", (cnpj, max(1, min(int(limite), 20000))) )



def dicionario_contabil():
    """Lista o conjunto explícito de códigos CVM reconhecidos pelo GFI."""
    return {"versao": 1, "total_mapeado": len(contas.listar()),
            "regras": contas.listar(),
            "politica": "Correspondência exata por demonstração e código. Subcontas não são somadas automaticamente; códigos desconhecidos permanecem sem classificação."}


def indicadores_cnpj(cnpj, limite=20000):
    """Classifica lançamentos de um CNPJ sem converter moeda/escala ou somar contas."""
    linhas = consultar_emissor(cnpj, limite)
    mapeados, nao_mapeados = [], 0
    for linha in linhas:
        classificacao = contas.classificar(linha)
        if not classificacao:
            nao_mapeados += 1
            continue
        mapeados.append({**classificacao, "cnpj": linha["cnpj"],
                         "tipo_documento": linha["tipo_documento"],
                         "data_referencia": linha["data_referencia"],
                         "ano_exercicio": linha["ano_exercicio"],
                         "versao": linha["versao"], "valor": linha["valor"],
                         "moeda": linha.get("moeda"),
                         "escala_moeda": linha.get("escala_moeda"),
                         "grupo_exercicio": linha.get("grupo_exercicio"),
                         "arquivo_origem": linha["arquivo_origem"],
                         "fonte": linha["fonte"]})
    return {"cnpj": _cnpj(cnpj), "total_lancamentos": len(linhas),
            "total_classificados": len(mapeados), "total_nao_mapeados": nao_mapeados,
            "indicadores": mapeados,
            "aviso": "Classificação inicial, não cálculo de índices. Valores mantêm moeda, escala, período, grupo e versão originais; não some períodos nem misture demonstrações sem validação."}

def consultar_instrumento(instrumento_id, limite=20000):
    """Consulta lançamentos CVM somente após vínculo CNPJ/instrumento confirmado."""
    _schema()
    instrumento_id = int(instrumento_id)
    limite = max(1, min(int(limite), 20000))
    vinculos = db.consultar("SELECT cnpj,confirmado_em,observacao FROM cvm_emissores WHERE instrumento_id=? ORDER BY cnpj", (instrumento_id,))
    if not vinculos:
        return {"instrumento_id": instrumento_id, "mapeado": False, "emissores": [], "lancamentos": [],
                "aviso": "Nenhum CNPJ foi vinculado manualmente a este instrumento."}
    cnpjs = [v["cnpj"] for v in vinculos]
    marks = ",".join("?" for _ in cnpjs)
    rows = db.consultar(f"SELECT * FROM cvm_lancamentos WHERE cnpj IN ({marks}) ORDER BY data_referencia DESC,codigo_conta LIMIT ?", (*cnpjs, limite))
    return {"instrumento_id": instrumento_id, "mapeado": True, "emissores": vinculos,
            "total_retornado": len(rows), "lancamentos": rows,
            "aviso": "Dados contábeis brutos da CVM; valores preservam moeda e escala originais. Não são indicadores calculados nem recomendação."}
