"""Banco Central do Brasil — Sistema Gerenciador de Séries (SGS), fonte oficial e gratuita."""
import json
import math
import time
from datetime import datetime
from datetime import date, timedelta

from .. import db
from . import base

FONTE = "BCB-SGS"
# código SGS → (chave interna, descrição). Os códigos são validados na primeira coleta (falhas ficam no log).
SERIES = {432: ("selic_meta", "Meta Selic (% a.a.)"), 433: ("ipca_mensal", "IPCA (% a.m.)"),
          189: ("igpm_mensal", "IGP-M (% a.m.)"), 1: ("dolar_venda", "Dólar comercial venda (R$)"),
          24369: ("desemprego", "Taxa de desocupação PNAD (%)"),
          4380: ("pib_mensal", "PIB mensal (R$ milhões)"), 4513: ("divida_liquida_pib", "Dívida líquida do setor público (% PIB)")}
URL = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{cod}/dados?formato=json&dataInicial={ini}&dataFinal={fim}"


def parse_sgs(texto):
    """Converte a resposta JSON do SGS em [(data_iso, valor)], descartando linhas inválidas."""
    if isinstance(texto, bytes):
        texto = texto.decode("utf-8-sig")
    payload = json.loads(texto)
    if not isinstance(payload, list):
        raise ValueError("resposta SGS não é uma lista JSON")
    por_data = {}
    for item in payload:
        try:
            data_br = str(item["data"])
            data = datetime.strptime(data_br, "%d/%m/%Y").date().isoformat()
            bruto = str(item["valor"]).strip()
            # SGS pode serializar decimal com vírgula; normaliza também milhar pt-BR.
            if "," in bruto:
                bruto = bruto.replace(".", "").replace(",", ".")
            valor = float(bruto)
            if not math.isfinite(valor):
                continue
            por_data[data] = valor
        except (KeyError, TypeError, ValueError):
            continue
    return sorted(por_data.items())


def coletar(series=None, anos=8):
    """Coleta e grava as séries. Retorna {chave: n_registros | 'erro: ...'}. Nunca derruba quem chamou."""
    fim = date.today()
    ini = fim - timedelta(days=365 * anos)
    resultado = {}
    for cod, (chave, _) in SERIES.items():
        if series and chave not in series:
            continue
        t0 = time.time()
        try:
            pontos = parse_sgs(base.baixar(URL.format(cod=cod, ini=ini.strftime("%d/%m/%Y"), fim=fim.strftime("%d/%m/%Y"))))
            agora = time.time()
            db.muitos("INSERT OR REPLACE INTO macro(serie,data,valor,fonte,publicado_em,coletado_em,estado) "
                      "VALUES(?,?,?,?,?,?,'ok')", [(chave, d, v, FONTE, d, agora) for d, v in pontos])
            base.registrar(f"{FONTE}:{chave}", t0, "ok" if pontos else "vazio", len(pontos))
            resultado[chave] = len(pontos)
        except Exception as e:
            base.registrar(f"{FONTE}:{chave}", t0, "erro", 0, f"{type(e).__name__}: {e}")
            db.log("ERRO", "bcb", f"{chave}: {type(e).__name__}: {e}")
            resultado[chave] = f"erro: {type(e).__name__}"
    return resultado
