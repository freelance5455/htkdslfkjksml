"""DEMONSTRAÇÃO: gera dados 100% SIMULADOS (tickers DEMO01…, mic SIMU, origem 'SIMULADO').
Nunca se mistura com dados reais. Os últimos pregões ficam escondidos e são revelados por `avancar`,
para que as previsões sejam avaliadas só com dados que ainda não existiam quando foram registradas."""
import math
import random
import time
from datetime import date, timedelta

from .. import catalogo, config, db

ORIGEM = "SIMULADO"
CENARIOS = ["tendencia_positiva", "recuperacao", "deterioracao", "armadilha_valor", "normal", "normal", "normal",
            "fraude", "iliquido", "normal"]


def _uteis_ate(fim, n):
    out, d = [], fim
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d)
        d -= timedelta(days=1)
    return out[::-1]


def _uteis_apos(inicio, n):
    out, d = [], inicio
    while len(out) < n:
        d += timedelta(days=1)
        if d.weekday() < 5:
            out.append(d)
    return out


def limpar():
    ids = [r["id"] for r in db.consultar("SELECT id FROM instrumentos WHERE origem=?", (ORIGEM,))]
    for i in ids:
        for t in ("cotacoes", "demo_futuro", "fundamentos", "pontuacoes", "alertas"):
            db.executar(f"DELETE FROM {t} WHERE instrumento_id=?", (i,))
    db.executar("DELETE FROM eventos WHERE origem=?", (ORIGEM,))
    db.executar("DELETE FROM macro WHERE fonte=?", (ORIGEM,))
    db.executar("DELETE FROM instrumentos WHERE origem=?", (ORIGEM,))


def gerar(por_setor=4, historico=560, futuro=45, seed=42):
    rng = random.Random(seed)
    limpar()
    hoje = date.today()
    dias_h = _uteis_ate(hoje if hoje.weekday() < 5 else hoje - timedelta(days=hoje.weekday() - 4), historico)
    dias_f = _uteis_apos(dias_h[-1], futuro)
    dias = dias_h + dias_f
    n = len(dias)
    agora = time.time()
    # fator de mercado comum (com mudança de regime)
    mkt, nivel = [], 100.0
    for t in range(n):
        vol = 0.007 if (t // 120) % 2 == 0 else 0.013
        mkt.append(0.0003 + vol * rng.gauss(0, 1))
    idx_id = catalogo.upsert("DEMOIDX", "SIMU", ORIGEM, moeda="BRL", pais="BR", nome="Índice Simulado", tipo="indice")
    _gravar(idx_id, dias, _serie(rng, mkt, 0, 0.0, 1.0, 100.0, 5e8), len(dias_h))
    setores = [s for s in config.SETORES_B3 if s != "Outros"]
    k = 0
    eventos = []
    for si, setor in enumerate(setores):
        for j in range(por_setor):
            cen = CENARIOS[k % len(CENARIOS)]
            us = (k % 6 == 5)
            tk = f"DEMO{k + 1:02d}"
            iid = catalogo.upsert(tk, "SIMU", ORIGEM, isin=f"SIM{k + 1:09d}", moeda="USD" if us else "BRL", pais="US" if us else "BR",
                                  setor=setor, nome=f"Empresa Simulada {k + 1:02d} ({setor.split(',')[0][:14]})",
                                  tipo=rng.choice(["acao_on", "acao_on", "acao_pref", "unit"]) if not us else "acao_on")
            drift, beta, sig = {"tendencia_positiva": 0.0008, "recuperacao": 0.0, "deterioracao": -0.0009, "armadilha_valor": -0.0004}.get(cen, 0.0001), \
                rng.uniform(0.6, 1.5), rng.uniform(0.010, 0.022)
            serie = _serie(rng, mkt, drift, sig, beta, rng.uniform(8, 80), rng.uniform(2e5, 4e6), cen, len(dias_h))
            if cen == "iliquido":
                serie = [(o, h, l, c, q * 0.002, v * 0.002) for o, h, l, c, q, v in serie]
            _gravar(iid, dias, serie, len(dias_h))
            _fundamentos(rng, iid, cen, serie[len(dias_h) - 1][3], dias_h[-1].year)
            if cen == "fraude":
                eventos.append((iid, setor, "BR", "noticia", "fraude", 5, -2, "[SIMULADO] Investigação por fraude contábil", "SIMULADO",
                                dias_h[-4].isoformat(), "alta"))
            elif rng.random() < 0.35:
                cat = rng.choice(["noticia", "regulatorio", "geopolitico"])
                imp = rng.choice([-2, -1, 1, 1, 2])
                eventos.append((iid, setor, "US" if us else "BR", cat, "geral", rng.randint(2, 4), imp,
                                f"[SIMULADO] Evento {'positivo' if imp > 0 else 'negativo'} ({cat})", "SIMULADO",
                                dias_h[-rng.randint(3, 50)].isoformat(), rng.choice(["alta", "media"])))
            k += 1
    eventos.append((None, "Financeiro", "BR", "regulatorio", "geral", 3, -1, "[SIMULADO] Nova regra de capital para bancos", "SIMULADO",
                    dias_h[-20].isoformat(), "alta"))
    db.muitos("INSERT INTO eventos(instrumento_id,setor,pais,categoria,tipo,severidade,impacto,titulo,fonte,publicado_em,coletado_em,"
              "confiabilidade,origem) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'SIMULADO')",
              [(a, b, c, d, e, f, g, h, i, j, agora, l) for a, b, c, d, e, f, g, h, i, j, l in eventos])
    _macro_simulada(rng, dias_h[-1])
    catalogo.upsert  # (catálogo já preenchido)
    return {"instrumentos": k + 1, "ate": dias_h[-1].isoformat(), "pregoes_escondidos": futuro}


def _serie(rng, mkt, drift, sig, beta, p0, q0, cen="normal", n_rev=None):
    n, p, out = len(mkt), p0, []
    for t in range(n):
        d = drift
        if cen == "recuperacao":
            d = -0.0012 if t < n * 0.55 else 0.0020
        if cen == "fraude" and n_rev and n_rev - 4 <= t < n_rev - 1:
            d = -0.08
        r = beta * mkt[t] + d + sig * rng.gauss(0, 1)
        o = p * (1 + rng.gauss(0, 0.003))
        c = max(0.5, p * math.exp(r))
        h, l = max(o, c) * (1 + abs(rng.gauss(0, 0.005))), min(o, c) * (1 - abs(rng.gauss(0, 0.005)))
        q = q0 * math.exp(rng.gauss(0, 0.4)) * (2.5 if cen == "fraude" and n_rev and t >= n_rev - 4 else 1)
        out.append((o, h, l, c, q, q * c))
        p = c
    return out


def _gravar(iid, dias, serie, n_revelado):
    agora = time.time()
    rev = [(iid, dias[t].isoformat(), o, h, l, c, v, q, ORIGEM, agora) for t, (o, h, l, c, q, v) in enumerate(serie[:n_revelado])]
    fut = [(iid, dias[n_revelado + t].isoformat(), o, h, l, c, v, q) for t, (o, h, l, c, q, v) in enumerate(serie[n_revelado:])]
    db.muitos("INSERT OR REPLACE INTO cotacoes VALUES(?,?,?,?,?,?,?,?,?,?)", rev)
    db.muitos("INSERT OR REPLACE INTO demo_futuro VALUES(?,?,?,?,?,?,?,?)", fut)


def _fundamentos(rng, iid, cen, preco, ano):
    cresc = {"tendencia_positiva": 0.16, "recuperacao": 0.04, "deterioracao": -0.03, "armadilha_valor": -0.04}.get(cen, 0.06)
    mg = rng.uniform(0.06, 0.15)
    rec = rng.uniform(5e8, 6e9)
    linhas = []
    pl_alvo = 5.0 if cen == "armadilha_valor" else rng.uniform(7, 24)
    anos = [ano - 4 + i for i in range(4)]
    ult = None
    for i, a in enumerate(anos):
        if i:
            rec *= 1 + cresc + rng.uniform(-0.02, 0.02)
            mg += -0.025 if cen in ("deterioracao", "armadilha_valor") else rng.uniform(-0.01, 0.01)
        ll = rec * mg
        ebitda = rec * (mg + 0.12)
        div = ebitda * (4.6 if cen == "armadilha_valor" else rng.uniform(0.3, 2.4))
        fcf = ll * (-0.3 if cen == "armadilha_valor" and i == 3 else 0.8)
        ult = (rec, ll, ebitda, div, fcf, rec * rng.uniform(0.8, 1.5))
        campos = {"receita": rec, "lucro_liquido": ll, "ebitda": ebitda, "ebit": ebitda * 0.8, "divida_liquida": div, "fcf": fcf,
                  "patrimonio": ult[5], "governanca": rng.uniform(40, 90)}
        linhas += [(iid, str(a), c, v) for c, v in campos.items()]
    acoes = max(1.0, (ult[1] * pl_alvo) / preco) if ult[1] > 0 else 1e8
    for a in anos:
        linhas += [(iid, str(a), "acoes", acoes), (iid, str(a), "dividendos_por_acao", max(0.0, ult[1] * 0.35 / acoes))]
    agora = time.time()
    db.muitos("INSERT OR REPLACE INTO fundamentos VALUES(?,?,?,?,'SIMULADO','SIMULADO',?)", [(i, p, c, v, agora) for i, p, c, v in linhas])


def _macro_simulada(rng, fim):
    agora, linhas = time.time(), []
    selic, des, d = 6.5, 12.0, date(fim.year - 8, fim.month, 1)
    while d <= fim:
        selic = min(14.75, selic + 0.35) if d < date(fim.year - 3, 1, 1) else max(10.5, selic - 0.1) if rng.random() < 0.3 else selic
        des = max(6.5, des - 0.06 + rng.uniform(-0.15, 0.1))
        linhas += [("selic_meta", d.isoformat(), selic), ("ipca_mensal", d.isoformat(), max(-0.1, rng.gauss(0.4, 0.25))),
                   ("desemprego", d.isoformat(), des), ("dolar_venda", d.isoformat(), 4.8 + rng.uniform(-0.4, 0.8))]
        d = date(d.year + (d.month // 12), d.month % 12 + 1, 1)
    db.muitos("INSERT OR REPLACE INTO macro(serie,data,valor,fonte,publicado_em,coletado_em,estado) VALUES(?,?,?,'SIMULADO',?,?,'ok')",
              [(s, dt, v, dt, agora) for s, dt, v in linhas])


def avancar(dias=1):
    """Revela os próximos `dias` pregões simulados (como se o tempo passasse). Devolve a nova data."""
    datas = [r["data"] for r in db.consultar("SELECT DISTINCT data FROM demo_futuro ORDER BY data LIMIT ?", (dias,))]
    if not datas:
        return None
    agora = time.time()
    for d in datas:
        db.executar("INSERT OR REPLACE INTO cotacoes SELECT instrumento_id,data,abertura,maximo,minimo,fechamento,volume_fin,qtd,'SIMULADO',? "
                    "FROM demo_futuro WHERE data=?", (agora, d))
        db.executar("DELETE FROM demo_futuro WHERE data=?", (d,))
    return datas[-1]
