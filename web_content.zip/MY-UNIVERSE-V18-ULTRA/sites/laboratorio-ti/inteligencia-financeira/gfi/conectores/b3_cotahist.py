"""B3 — Séries Históricas de Cotações (COTAHIST), arquivo oficial de posições fixas (245 colunas).

Atenção: as cotações vêm SEM ajuste por proventos, desdobramentos ou grupamentos (isto é dito pela própria B3).
"""
import io
import os
import tempfile
import time
import zipfile
from datetime import date

from .. import catalogo, config, db
from . import base

FONTE = "B3-COTAHIST"
URL_ANUAL = os.environ.get("GFI_URL_COTAHIST", "https://bvmf.bmfbovespa.com.br/InstDados/SerHist/COTAHIST_A{ano}.ZIP")
BDI_ACEITOS = {"02": None, "12": "reit", "14": "etf"}      # lote padrão, fracionário, FII, ETF/fundos


def _tipo(especi, bdi):
    if BDI_ACEITOS.get(bdi):
        return BDI_ACEITOS[bdi]
    e = especi.strip().upper()
    if e.startswith("ON"):
        return "acao_on"
    if e.startswith("PN"):
        return "acao_pref"
    if e.startswith("UNT"):
        return "unit"
    if e.startswith("DR"):
        return "bdr"
    return "outro"


def parse_linha(linha):
    """Registro 01 do mercado à vista → dict, ou None para qualquer outro tipo de linha."""
    if len(linha) < 245 or linha[0:2] != "01" or linha[24:27] != "010" or linha[10:12] not in BDI_ACEITOS:
        return None
    try:
        from datetime import datetime
        p = lambda a, b: int(linha[a - 1:b]) / 100.0          # campos numéricos com 2 casas implícitas
        d = linha[2:10]
        datetime.strptime(d, "%Y%m%d")                       # não aceitar datas impossíveis
        ticker = linha[12:24].strip()
        if not ticker:
            return None
        registro = {"data": f"{d[:4]}-{d[4:6]}-{d[6:8]}", "ticker": ticker, "nome": linha[27:39].strip(),
                    "tipo": _tipo(linha[39:49], linha[10:12]), "abertura": p(57, 69), "maximo": p(70, 82), "minimo": p(83, 95),
                    "fechamento": p(109, 121), "qtd": float(int(linha[152:170])), "volume_fin": p(171, 188),
                    "isin": linha[230:242].strip() or None}
        o, h, low, c = (registro[k] for k in ("abertura", "maximo", "minimo", "fechamento"))
        if min(o, h, low, c) <= 0 or h < max(o, c, low) or low > min(o, c) or registro["qtd"] < 0 or registro["volume_fin"] < 0:
            return None
        return registro
    except (ValueError, OverflowError):
        return None


def ler_zip(origem):
    """Lê um ZIP (caminho ou bytes) e devolve os registros válidos."""
    alvo = io.BytesIO(origem) if isinstance(origem, (bytes, bytearray)) else origem
    with zipfile.ZipFile(alvo) as z:
        corrompido = z.testzip()
        if corrompido:
            raise ValueError(f"membro ZIP corrompido: {corrompido}")
        membros = [n for n in z.namelist() if not n.endswith("/") and
                   ("COTAHIST" in n.upper())]
        if not membros:
            raise ValueError("ZIP sem arquivo de cotações COTAHIST reconhecível")
        for nome in membros:
            with z.open(nome) as f:
                for bruta in io.TextIOWrapper(f, encoding="latin-1"):
                    r = parse_linha(bruta.rstrip("\r\n"))
                    if r:
                        yield r


def importar(registros):
    """Grava instrumentos (REAL) e cotações. Devolve o número de cotações gravadas."""
    ids, lote, agora, n = {}, [], time.time(), 0
    for r in registros:
        if r["ticker"] not in ids:
            ids[r["ticker"]] = catalogo.upsert(r["ticker"], "BVMF", "REAL", isin=r["isin"], moeda="BRL", pais="BR",
                                               nome=r["nome"], tipo=r["tipo"])
        lote.append((ids[r["ticker"]], r["data"], r["abertura"], r["maximo"], r["minimo"], r["fechamento"],
                     r["volume_fin"], r["qtd"], FONTE, agora))
        if len(lote) >= 5000:
            db.muitos("INSERT OR REPLACE INTO cotacoes VALUES(?,?,?,?,?,?,?,?,?,?)", lote)
            n, lote = n + len(lote), []
    if lote:
        db.muitos("INSERT OR REPLACE INTO cotacoes VALUES(?,?,?,?,?,?,?,?,?,?)", lote)
        n += len(lote)
    return n


def validar_anos(anos):
    """Normaliza anos solicitados e impede anos inválidos ou lotes excessivos."""
    if anos is None:
        return [date.today().year - 1, date.today().year]
    if not isinstance(anos, (list, tuple)) or not anos:
        raise ValueError("informe uma lista não vazia de anos")
    if len(anos) > 10:
        raise ValueError("solicite no máximo 10 exercícios por coleta")
    atual = date.today().year
    normalizados = []
    for ano in anos:
        if isinstance(ano, bool) or not str(ano).isdigit():
            raise ValueError(f"ano inválido: {ano!r}")
        n = int(ano)
        if n < 1990 or n > atual:
            raise ValueError(f"ano fora do intervalo permitido (1990–{atual}): {n}")
        if n not in normalizados:
            normalizados.append(n)
    return normalizados


def status():
    """Resumo verificável do que já está gravado; não confunde fixtures com download externo."""
    totais = db.um("SELECT COUNT(*) AS cotacoes, COUNT(DISTINCT instrumento_id) AS instrumentos, MIN(data) AS primeira_data, MAX(data) AS ultima_data FROM cotacoes WHERE origem=?", (FONTE,)) or {}
    por_ano = db.consultar("SELECT substr(data,1,4) AS ano, COUNT(*) AS cotacoes, COUNT(DISTINCT instrumento_id) AS instrumentos FROM cotacoes WHERE origem=? GROUP BY substr(data,1,4) ORDER BY ano", (FONTE,))
    coletas = db.consultar("SELECT fonte,inicio,fim,status,registros,erro FROM coletas WHERE fonte LIKE ? ORDER BY id DESC LIMIT 12", (FONTE + ":%",))
    return {"fonte": FONTE, "cotacoes": int(totais.get("cotacoes") or 0),
            "instrumentos": int(totais.get("instrumentos") or 0), "primeira_data": totais.get("primeira_data"),
            "ultima_data": totais.get("ultima_data"), "por_ano": por_ano, "ultimas_coletas": coletas,
            "download_real_comprovado": any(c["status"] == "ok" for c in coletas)}


def coletar(anos=None, forcar=False):
    """Baixa os últimos config.ANOS_B3 anos; anos encerrados e já coletados com sucesso são reaproveitados.
    `forcar=True` permite reprocessar um ano encerrado quando necessário."""
    if anos is None:
        atual = date.today().year
        anos = list(range(max(1990, atual - max(1, config.ANOS_B3) + 1), atual + 1))
    anos = validar_anos(anos)
    resultado = {}
    for ano in anos:
        if not forcar and ano < date.today().year and db.um("SELECT 1 x FROM coletas WHERE fonte=? AND status='ok'", (f"{FONTE}:{ano}",)):
            resultado[ano] = "já coletado (ano encerrado)"
            continue
        t0 = time.time()
        try:
            dados = base.baixar(URL_ANUAL.format(ano=ano), timeout=180, intervalo=2.0)
            n = importar(ler_zip(dados))
            base.registrar(f"{FONTE}:{ano}", t0, "ok" if n else "vazio", n)
            resultado[ano] = n
        except Exception as e:
            base.registrar(f"{FONTE}:{ano}", t0, "erro", 0, f"{type(e).__name__}: {e}")
            db.log("ERRO", "b3_cotahist", f"{ano}: {type(e).__name__}: {e}")
            resultado[ano] = f"erro: {type(e).__name__}"
    catalogo.atualizar_status("REAL")
    return resultado
