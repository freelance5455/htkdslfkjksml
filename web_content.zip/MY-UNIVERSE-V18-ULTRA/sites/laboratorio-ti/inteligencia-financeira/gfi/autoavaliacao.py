"""Autoavaliação: mede a própria qualidade com as previsões já avaliadas e recomenda mudanças (como propostas)."""
from . import db, evolucao, pesquisa, previsoes
from .motores import pontuacao


def relatorio():
    m = previsoes.metricas()
    ok, quebrado = previsoes.verificar_cadeia()
    recs = []
    if m["avaliadas"] < 30:
        recs.append({"tipo": "info", "texto": f"Apenas {m['avaliadas']} previsões avaliadas: ainda é cedo para conclusões estatísticas (mínimo ~30)."})
    if m["taxa_acerto"] is not None and m["avaliadas"] >= 30:
        alta = m["por_direcao"].get("alta", {})
        if alta.get("n", 0) >= 10 and m["taxa_base_alta"] is not None and alta["acerto"] <= m["taxa_base_alta"]:
            recs.append({"tipo": "ajuste_pesos", "texto": "Previsões de ALTA não superam a taxa-base: reduzir o peso da análise técnica e aumentar risco/saúde."})
        if m["excesso_confianca"] is not None and m["excesso_confianca"] > 0.05:
            recs.append({"tipo": "excesso_confianca", "texto": "Índices altos (≥70) acertam menos que a média: sinal de excesso de confiança."})
        if m["degradacao"] is not None and m["degradacao"] < -0.10:
            recs.append({"tipo": "degradacao", "texto": "Desempenho recente 10 p.p. abaixo do histórico: possível degradação do modelo."})
    return {"metricas": m, "cadeia_integra": ok, "primeiro_adulterado": quebrado, "recomendacoes": recs}


def propor():
    """Transforma recomendações em propostas/pesquisas (sem aplicar nada)."""
    criadas = 0
    for r in relatorio()["recomendacoes"]:
        if r["tipo"] == "ajuste_pesos" and not db.um("SELECT 1 x FROM propostas WHERE titulo LIKE 'Reduzir peso técnico%' AND estado NOT IN ('rejeitada','revertida')"):
            p = pontuacao.pesos_efetivos(None)
            evolucao.criar("Reduzir peso técnico e reforçar risco/saúde", r["texto"], "ia",
                           mudanca={"pesos": {"tecnica": round(p["tecnica"] * 0.7, 2), "risco": round(p["risco"] * 1.2, 2), "saude": round(p["saude"] * 1.15, 2)}})
            criadas += 1
        elif r["tipo"] in ("degradacao", "excesso_confianca"):
            criadas += pesquisa.enfileirar(f"modelo:{r['tipo']}", "Investigar " + r["tipo"].replace("_", " "), r["texto"], relev=0.9, urg=0.7, imp=0.9, conf=0.6, custo=0.5)
    return criadas
