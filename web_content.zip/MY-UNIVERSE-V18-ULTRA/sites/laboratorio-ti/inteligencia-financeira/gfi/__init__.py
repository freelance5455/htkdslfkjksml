"""Plataforma de inteligência financeira (pesquisa e apoio à decisão). Não opera no mercado."""
