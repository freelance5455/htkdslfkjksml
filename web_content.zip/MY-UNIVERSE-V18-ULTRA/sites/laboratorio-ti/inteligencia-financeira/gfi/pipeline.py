"""Pipeline: monta o contexto de cada ativo, calcula a pontuação, registra previsões e gera alertas."""
import json
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from . import alertas, atualizacoes, catalogo, config, dados, db, previsoes, recursos, validacao
from .motores import macro as macro_m, pontuacao, risco, tecnico, valuation


def _fonte(origem):
    return ("SIMULADO", "SIMULADO") if origem == "SIMULADO" else ("B3-COTAHIST", "BCB-SGS")


def _benchmark(origem):
    b = db.um("SELECT id FROM instrumentos WHERE origem=? AND tipo='indice' AND status='ativo' ORDER BY id LIMIT 1", (origem,))
    return dados.candles(b["id"]) if b else None


def _medianas(insts):
    pares = []
    for i in insts:
        f = dados.fundamentos(i["id"])
        c = dados.candles(i["id"], limite=1)
        ano, ult = valuation.ultimo_anual(f)
        if ano and c:
            pares.append((i["setor"], valuation.multiplos(c[-1][4], ult)))
    return valuation.medianas_por_setor(pares)


def contexto(inst, origem, ate, ref, bench, medianas, fatores_macro, defasado=False):
    fonte_precos, fonte_macro = _fonte(origem)
    cruas = dados.candles(inst["id"], ate)
    val = validacao.validar_candles(cruas, ref)
    ajust, datas = validacao.ajustar_saltos(cruas)
    if datas:
        val["problemas"].append(f"série ajustada por heurística (estimativa) em {len(datas)} data(s): {', '.join(datas[:3])}")
    fund = dados.fundamentos(inst["id"], ate, defasado)
    preco = ajust[-1][4] if ajust else None
    pares = medianas.get(inst["setor"], {})
    return {"inst": inst, "candles": ajust, "validacao": val, "analise": tecnico.analisar(ajust) if ajust else {"indicadores": {}},
            "risco": risco.resumo(ajust, bench) if len(ajust) > 20 else {"vol_anual": None, "max_drawdown": None, "var95": None, "liquidez": None,
                                                                          "retorno_risco": None, "beta": None, "correlacao": None},
            "fund": fund, "eventos": dados.eventos(inst["id"], inst["setor"], inst["pais"], ate or ref, origem=origem),
            "macro": fatores_macro, "valuation": valuation.avaliar(preco, fund, pares) if preco else valuation.avaliar(None, {}),
            "fonte_precos": ", ".join(dados.fontes_candles(inst["id"], ate)) or fonte_precos, "fonte_fund": origem if origem == "SIMULADO" else "importação manual/CVM",
            "ultima_data": ajust[-1][0] if ajust else (ate or ref)}


def _metricas(ctx, res):
    c = [x[4] for x in ctx["candles"]]
    n = len(c)
    ret = lambda k: (c[-1] / c[-1 - k] - 1) if n > k and c[-1 - k] > 0 else None
    v = ctx["valuation"]
    gr, _ = pontuacao._cagr_campo(ctx["fund"], "receita")
    return {"preco": c[-1] if c else None, "mcap": v["multiplos"].get("mcap") if v["multiplos"] else None, "ret_1d": ret(1), "ret_1m": ret(21), "ret_3m": ret(63), "ret_12m": ret(252),
            "vol_anual": ctx["risco"]["vol_anual"], "max_drawdown": ctx["risco"]["max_drawdown"], "beta": ctx["risco"]["beta"],
            "retorno_risco": ctx["risco"]["retorno_risco"], "liquidez": (ctx["risco"]["liquidez"] or {}).get("volume_medio"),
            "dy": v["multiplos"].get("dy") if v["multiplos"] else None, "p_l": v["multiplos"].get("p_l") if v["multiplos"] else None,
            "veredito": v["veredito"], "margem_dcf": v["cenarios"].get("base", {}).get("margem"), "armadilha": v["armadilha_valor"]["alerta"],
            "crescimento_receita": gr, "fcf_positivo": (valuation.ultimo_anual(ctx["fund"])[1].get("fcf") or 0) > 0 if ctx["fund"] else None,
            "dd_atual": (c[-1] / max(c[-252:]) - 1) if n >= 20 else None, "serie": c[-60:]}


def recalcular(origem=None, ate=None, lote=None, todos=False):
    """Recalcula pontuações. Em lotes (conforme o modo/recursos), a menos que `todos`."""
    origem = origem or catalogo.origem_ativa()
    insts = catalogo.listar(origem)
    if not insts:
        return {"processados": 0, "total": 0}
    # A referência atual é o calendário de hoje, nunca a última data encontrada no banco.
    # Em backtests, `ate` define explicitamente o corte temporal.
    ref = ate or datetime.now(ZoneInfo("America/Sao_Paulo")).date().isoformat()
    existe = db.um("SELECT 1 FROM cotacoes c JOIN instrumentos i ON i.id=c.instrumento_id WHERE i.origem=? "
                   "AND c.data<=? LIMIT 1", (origem, ref))
    if not existe and origem == "REAL":
        existe = db.um("SELECT 1 FROM cotacoes_provedor_diarias p JOIN instrumentos i ON i.id=p.instrumento_id "
                       "WHERE i.origem=? AND p.data<=? LIMIT 1", (origem, ref))
    if not existe:
        return {"processados": 0, "total": len(insts), "data": ref, "erro": "sem candles diários disponíveis"}
    lote = len(insts) if todos else (lote or recursos.lote_efetivo())
    cur = int(db.cfg_get(f"cursor_{origem}", 0)) % len(insts)
    fila = (insts[cur:] + insts[:cur])[:lote]
    db.cfg_set(f"cursor_{origem}", (cur + len(fila)) % len(insts))
    bench, medianas = _benchmark(origem), _medianas(insts)
    fm = macro_m.fatores(_fonte(origem)[1], ref)
    agora, feitos, anteriores = time.time(), 0, {}
    for inst in fila:
        ant = db.um("SELECT indice,bloqueado,detalhe,data FROM pontuacoes WHERE instrumento_id=? AND data<? ORDER BY data DESC LIMIT 1", (inst["id"], ref))
        ctx = contexto(inst, origem, ate, ref, bench, medianas, fm)
        if not ctx["candles"]:
            continue
        res = pontuacao.calcular(ctx)
        res["metricas"] = _metricas(ctx, res)
        a = ctx["analise"]
        res["tecnico"] = {"curto": a.get("curto"), "medio": a.get("medio"), "longo": a.get("longo"), "indicadores": a.get("indicadores", {})}
        res["extras"] = atualizacoes.executar_indicadores(ctx["candles"])
        res["valuation"] = ctx["valuation"]
        res["inst"] = {k: inst[k] for k in ("id", "ticker", "nome", "pais", "setor", "tipo", "moeda", "mic", "origem")}
        db.executar("INSERT OR REPLACE INTO pontuacoes VALUES(?,?,?,?,?,?,?)",
                    (inst["id"], ref, res["indice"], int(res["bloqueado"]), res["qualidade"], json.dumps(res), agora))
        if res["indice"] is not None and inst["tipo"] != "indice":
            previsoes.registrar(inst["id"], ctx["ultima_data"], ctx["candles"][-1][4], res)
        if ant:
            alertas.comparar(inst, ant, res, ref)
        feitos += 1
    previsoes.avaliar_vencidas()
    db.log("INFO", "pipeline", f"{feitos}/{len(insts)} ativos recalculados até {ref} ({origem})")
    return {"processados": feitos, "total": len(insts), "data": ref}


def ultimas(origem=None):
    """Última pontuação de cada ativo ativo (detalhe já em dict)."""
    origem = origem or catalogo.origem_ativa()
    linhas = db.consultar("SELECT p.instrumento_id, p.detalhe FROM pontuacoes p JOIN instrumentos i ON i.id=p.instrumento_id "
                          "WHERE i.origem=? AND i.status='ativo' AND p.data=(SELECT MAX(data) FROM pontuacoes WHERE instrumento_id=p.instrumento_id)",
                          (origem,))
    return [json.loads(r["detalhe"]) for r in linhas]
