"""Catálogo de instrumentos: ticker + MIC + ISIN + moeda. Nunca confunde tickers iguais em bolsas diferentes."""
import time
from datetime import date

from . import config, db


def origem_ativa():
    """'SIMULADO' no modo demonstração; 'REAL' caso contrário. Dados simulados nunca se misturam com reais."""
    return "SIMULADO" if db.cfg_get("modo_demo", False) else "REAL"


def upsert(ticker, mic, origem, isin=None, moeda=None, pais=None, setor=None, nome=None, tipo=None, status="ativo"):
    """Cadastra ou atualiza. Se o mesmo ISIN aparece na mesma bolsa com outro ticker, o antigo vira 'substituido'."""
    agora = time.time()
    ticker, mic = ticker.strip().upper(), mic.strip().upper()
    if isin:
        for velho in db.consultar("SELECT id,ticker FROM instrumentos WHERE isin=? AND mic=? AND ticker<>? "
                                  "AND status='ativo'", (isin, mic, ticker)):
            db.executar("UPDATE instrumentos SET status='substituido',atualizado_em=? WHERE id=?", (agora, velho["id"]))
            db.log("INFO", "catalogo", f"mudança de ticker {velho['ticker']} → {ticker} ({isin})")
    existente = db.um("SELECT id FROM instrumentos WHERE ticker=? AND mic=?", (ticker, mic))
    if existente:
        db.executar("UPDATE instrumentos SET isin=COALESCE(?,isin),moeda=COALESCE(?,moeda),pais=COALESCE(?,pais),"
                    "setor=COALESCE(?,setor),nome=COALESCE(?,nome),tipo=COALESCE(?,tipo),atualizado_em=? WHERE id=?",
                    (isin, moeda, pais, setor, nome, tipo, agora, existente["id"]))
        return existente["id"]
    return db.executar("INSERT INTO instrumentos(ticker,mic,isin,moeda,pais,setor,nome,tipo,status,origem,criado_em,"
                       "atualizado_em) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                       (ticker, mic, isin, moeda, pais, setor, nome, tipo, status, origem, agora, agora))


def listar(origem=None, apenas_ativos=True):
    origem = origem or origem_ativa()
    sql = "SELECT * FROM instrumentos WHERE origem=?" + (" AND status='ativo'" if apenas_ativos else "")
    return db.consultar(sql + " ORDER BY ticker", (origem,))


def obter(inst_id):
    return db.um("SELECT * FROM instrumentos WHERE id=?", (inst_id,))


def importar_setores(linhas):
    """linhas: [(ticker, setor)] — por exemplo exportado da classificação setorial da B3."""
    n = 0
    for ticker, setor in linhas:
        if setor in config.SETORES_B3:
            db.executar("UPDATE instrumentos SET setor=? WHERE ticker=? AND origem='REAL'", (setor, ticker.strip().upper()))
            n += 1
    return n


def atualizar_status(origem=None):
    """Marca como 'suspenso' (>30 d sem negociar) ou 'deslistado' (>180 d), relativo à última data do conjunto."""
    origem = origem or origem_ativa()
    ref = db.um("SELECT MAX(c.data) d FROM cotacoes c JOIN instrumentos i ON i.id=c.instrumento_id WHERE i.origem=?",
                (origem,))
    if not ref or not ref["d"]:
        return 0
    ref_d, mudou = date.fromisoformat(ref["d"]), 0
    for i in db.consultar("SELECT i.id, i.status, (SELECT MAX(data) FROM cotacoes WHERE instrumento_id=i.id) u "
                          "FROM instrumentos i WHERE i.origem=? AND i.status IN ('ativo','suspenso')", (origem,)):
        if not i["u"]:
            continue
        dias = (ref_d - date.fromisoformat(i["u"])).days
        novo = "deslistado" if dias > 180 else "suspenso" if dias > 30 else "ativo"
        if novo != i["status"]:
            db.executar("UPDATE instrumentos SET status=?,atualizado_em=? WHERE id=?", (novo, time.time(), i["id"]))
            mudou += 1
    return mudou


def cobertura(origem=None):
    """Quantos ativos existem, quantos têm dados atualizados e quantos estão insuficientes."""
    origem = origem or origem_ativa()
    ref = db.um("SELECT MAX(c.data) d FROM cotacoes c JOIN instrumentos i ON i.id=c.instrumento_id WHERE i.origem=?",
                (origem,))
    ref_d = date.fromisoformat(ref["d"]) if ref and ref["d"] else None
    linhas = db.consultar("SELECT i.id,i.pais,i.tipo,i.status, COUNT(c.data) n, MAX(c.data) u FROM instrumentos i "
                          "LEFT JOIN cotacoes c ON c.instrumento_id=i.id WHERE i.origem=? GROUP BY i.id", (origem,))
    r = {"cadastrados": len(linhas), "ativos": 0, "atualizados": 0, "insuficientes": 0, "suspensos": 0,
         "deslistados": 0, "por_pais": {}, "por_tipo": {}, "data_referencia": ref["d"] if ref else None}
    for i in linhas:
        if i["status"] == "ativo":
            r["ativos"] += 1
            atual = bool(ref_d and i["u"] and (ref_d - date.fromisoformat(i["u"])).days <= config.JANELA_ATUALIZADO_DIAS)
            if atual and i["n"] >= config.MIN_CANDLES:
                r["atualizados"] += 1
            else:
                r["insuficientes"] += 1
        elif i["status"] == "suspenso":
            r["suspensos"] += 1
        elif i["status"] == "deslistado":
            r["deslistados"] += 1
        r["por_pais"][i["pais"] or "?"] = r["por_pais"].get(i["pais"] or "?", 0) + 1
        r["por_tipo"][i["tipo"] or "?"] = r["por_tipo"].get(i["tipo"] or "?", 0) + 1
    r["pct_atualizados"] = round(100 * r["atualizados"] / r["ativos"], 1) if r["ativos"] else 0.0
    return r
