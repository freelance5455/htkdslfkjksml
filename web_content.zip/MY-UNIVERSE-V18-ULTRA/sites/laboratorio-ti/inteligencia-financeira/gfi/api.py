"""Rotas /api/*: leitura para o painel e ações controladas. Cada função devolve um dict JSON-serializável."""
import os
import statistics
import time

from . import live, live_auto, plano_coleta, v9
from .conectores import yahoo_chart, cvm, b3_cotahist
from . import agendador, alertas, atualizacoes, autoavaliacao, catalogo, config, dados, db, evolucao, ia_evolucao, oportunidades, pesquisa, pipeline, previsoes, recursos
from .conectores import base as conector_base, simulado
from .motores import macro as macro_m, pontuacao

ORDENS = {"indice": lambda x: x["indice"], "ret_1d": lambda x: x["ret_1d"], "ret_1m": lambda x: x["ret_1m"], "ret_12m": lambda x: x["ret_12m"],
          "vol": lambda x: x["vol"], "liquidez": lambda x: x["liquidez"], "qualidade": lambda x: x["qualidade"], "ticker": lambda x: x["ticker"]}


def _linha(r):
    m, i = r["metricas"], r["inst"]
    return {"id": i["id"], "ticker": i["ticker"], "nome": i["nome"], "pais": i["pais"], "setor": i["setor"] or "Sem setor", "tipo": i["tipo"],
            "mic": i["mic"], "preco": m["preco"], "ret_1d": m["ret_1d"], "ret_1m": m["ret_1m"], "ret_12m": m["ret_12m"], "indice": r["indice"],
            "luz": r["luz"], "bloqueado": r["bloqueado"], "luzes": {k: v["luz"] for k, v in r["dimensoes"].items()}, "vol": m["vol_anual"],
            "liquidez": m["liquidez"], "qualidade": r["qualidade"], "cobertura": r["cobertura"], "serie": m["serie"], "verdes": r["contagem"]["verde"],
            "mcap": m.get("mcap"), "moeda": i.get("moeda")}


def _todas():
    return [r for r in pipeline.ultimas() if r["inst"]["tipo"] != "indice"]


def _fonte_macro():
    return "SIMULADO" if catalogo.origem_ativa() == "SIMULADO" else "BCB-SGS"


# ------------------------------------------------------------------ leituras
def saude(_=None):
    med = recursos.medir()
    ult = {r["fonte"]: r for r in db.consultar("SELECT * FROM coletas ORDER BY id DESC LIMIT 60")[::-1]}
    ok, quebra = previsoes.verificar_cadeia()
    tam = (config.DADOS / "gfi.db").stat().st_size / 1e6 if (config.DADOS / "gfi.db").exists() else 0
    return {"nome": config.NOME, "versao": config.VERSAO_MODELO, "modo": recursos.modo_atual(), "modos": list(config.MODOS), "recursos": med,
            "sob_pressao": recursos.sob_pressao(med), "agendador": agendador.estado(), "coletas": list(ult.values())[-12:],
            "filas": {"pesquisa": len(pesquisa.proximas(500)), "propostas_abertas": db.um("SELECT COUNT(*) n FROM propostas WHERE estado NOT IN ('rejeitada','publicada','revertida')")["n"],
                      "alertas_nao_lidos": db.um("SELECT COUNT(*) n FROM alertas WHERE lido=0")["n"]},
            "banco_mb": round(tam, 2), "cadeia_previsoes_integra": ok, "demo": db.cfg_get("modo_demo", False),
            "logs": db.consultar("SELECT ts,nivel,modulo,msg FROM logs ORDER BY id DESC LIMIT 25"),
            "atualizacoes_modo_seguro": atualizacoes.modo_seguro(), "cobertura": catalogo.cobertura()}


def visao(_=None):
    rs = _todas()
    dist = {c: sum(1 for r in rs if r["luz"] == c) for c in ("verde", "amarelo", "vermelho", "cinza")}
    idx = [r["indice"] for r in rs if r["indice"] is not None]
    setores = {}
    for r in rs:
        s = r["inst"]["setor"] or "Sem setor"
        m = r["metricas"]
        setores.setdefault(s, []).append({"id": r["inst"]["id"], "ticker": r["inst"]["ticker"], "indice": r["indice"], "luz": r["luz"],
                                          "ret_1d": m["ret_1d"], "tamanho": m.get("mcap") or (m["liquidez"] or 0) * 40 or 1e6})
    top = oportunidades.ranking("geral", 5)["itens"]
    ref = catalogo.cobertura()["data_referencia"]
    return {"demo": db.cfg_get("modo_demo", False), "data_referencia": ref, "cobertura": catalogo.cobertura(), "distribuicao": dist,
            "indice_medio": round(statistics.mean(idx), 1) if idx else None, "setores": [{"setor": k, "itens": v} for k, v in setores.items()],
            "top5": top, "macro": [v["texto"] for v in macro_m.fatores(_fonte_macro(), ref).values()],
            "alertas": alertas.listar(6), "bloqueados": [r["inst"]["ticker"] for r in rs if r["bloqueado"]]}


def mercados(_=None):
    rs, por_pais = _todas(), {}
    cob = catalogo.cobertura()
    for r in rs:
        p = por_pais.setdefault(r["inst"]["pais"] or "?", {"pais": r["inst"]["pais"] or "?", "n": 0, "indices": [], "bolsas": set(), "luzes": {}})
        p["n"] += 1
        p["bolsas"].add(r["inst"]["mic"])
        if r["indice"] is not None:
            p["indices"].append(r["indice"])
        p["luzes"][r["luz"]] = p["luzes"].get(r["luz"], 0) + 1
    out = [{"pais": p["pais"], "n": p["n"], "indice_medio": round(statistics.mean(p["indices"]), 1) if p["indices"] else None,
            "bolsas": sorted(p["bolsas"]), "luzes": p["luzes"]} for p in por_pais.values()]
    metas = [("Brasil", "BR", "B3 (COTAHIST) + BCB/SGS: conectores prontos"), ("Estados Unidos", "US", "planejado (SEC/FRED)"), ("Canadá", "CA", "planejado"),
             ("Reino Unido", "GB", "planejado (FCA)"), ("Alemanha", "DE", "planejado"), ("França", "FR", "planejado"), ("Itália", "IT", "planejado"),
             ("Espanha", "ES", "planejado"), ("Portugal", "PT", "planejado"), ("Japão", "JP", "planejado"), ("China", "CN", "planejado"),
             ("Hong Kong", "HK", "planejado"), ("Índia", "IN", "planejado"), ("Austrália", "AU", "planejado"), ("Coreia do Sul", "KR", "planejado")]
    return {"paises": out, "meta_cobertura": [{"pais": n, "codigo": c, "situacao": s, "ativos": cob["por_pais"].get(c, 0)} for n, c, s in metas], "cobertura": cob}


def radar(q):
    rs = [_linha(r) for r in _todas()]
    f = lambda k, t=str: (t(q[k]) if q.get(k) not in (None, "") else None)
    pais, setor, tipo = f("pais"), f("setor"), f("tipo")
    imin, vmax, lmin, qmin, verdes = f("indice_min", float), f("risco_max", float), f("liquidez_min", float), f("qualidade_min", float), f("min_verdes", int)
    busca = (f("busca") or "").upper()
    out = [x for x in rs if (not pais or x["pais"] == pais) and (not setor or x["setor"] == setor) and (not tipo or x["tipo"] == tipo)
           and (imin is None or (x["indice"] or -1) >= imin) and (vmax is None or (x["vol"] is not None and x["vol"] <= vmax))
           and (lmin is None or (x["liquidez"] or 0) >= lmin) and (qmin is None or x["qualidade"] >= qmin) and (verdes is None or x["verdes"] >= verdes)
           and (not busca or busca in x["ticker"] or busca in (x["nome"] or "").upper())]
    chave = ORDENS.get(q.get("ordem") or "indice", ORDENS["indice"])
    out.sort(key=lambda x: (chave(x) is None, -(chave(x) or 0) if q.get("ordem") != "ticker" else 0, x["ticker"]) if q.get("ordem") != "ticker" else (x["ticker"],))
    n = int(q.get("n") or 200)
    return {"total": len(out), "itens": out[:n], "filtros": {"paises": sorted({x["pais"] for x in rs if x["pais"]}), "setores": sorted({x["setor"] for x in rs}),
                                                              "tipos": sorted({x["tipo"] for x in rs if x["tipo"]})}}


def ranking(q):
    filtros = {k: (float(q[k]) if k in ("indice_min", "risco_max", "liquidez_min", "qualidade_min") else int(q[k]) if k == "min_verdes" else q[k])
               for k in ("pais", "setor", "tipo", "indice_min", "risco_max", "liquidez_min", "qualidade_min", "min_verdes") if q.get(k) not in (None, "")}
    tipo = q.get("tipo_ranking") or "geral"
    if tipo not in oportunidades.RANKINGS:
        raise ValueError("ranking desconhecido")
    return {**oportunidades.ranking(tipo, int(q.get("n") or 20), filtros), "disponiveis": {k: v[0] for k, v in oportunidades.RANKINGS.items()}}


def ativo(inst_id):
    row = db.um("SELECT p.detalhe, p.data FROM pontuacoes p WHERE p.instrumento_id=? ORDER BY p.data DESC LIMIT 1", (inst_id,))
    if not row:
        raise KeyError("ativo sem pontuação")
    import json
    res = json.loads(row["detalhe"])
    hist = db.consultar("SELECT data,indice FROM pontuacoes WHERE instrumento_id=? ORDER BY data DESC LIMIT 180", (inst_id,))[::-1]
    prev = db.consultar("SELECT p.id,p.data_base,p.horizonte_dias,p.direcao,p.base_preco,a.retorno,a.acertou FROM previsoes p LEFT JOIN avaliacoes a ON a.previsao_id=p.id "
                        "WHERE p.instrumento_id=? ORDER BY p.id DESC LIMIT 20", (inst_id,))
    cand = dados.candles(inst_id, limite=320)
    return {"resultado": res, "candles": [list(c[:6]) for c in cand], "historico_indice": hist, "previsoes": prev, "demo": db.cfg_get("modo_demo", False)}


def macro(_=None):
    fonte, ref = _fonte_macro(), catalogo.cobertura()["data_referencia"]
    nomes = {"selic_meta": "Meta Selic (% a.a.)", "ipca_mensal": "IPCA (% a.m.)", "desemprego": "Desocupação (%)", "dolar_venda": "Dólar (R$)",
             "igpm_mensal": "IGP-M (% a.m.)", "pib_mensal": "PIB mensal (R$ mi)", "divida_liquida_pib": "Dívida líquida (% PIB)"}
    series = []
    for k, nome in nomes.items():
        pts = dados.serie_macro(k, fonte)
        if pts:
            series.append({"serie": k, "nome": nome, "ultimo": pts[-1], "pontos": pts[-96:], "fonte": fonte})
    return {"series": series, "fatores": macro_m.fatores(fonte, ref), "sensibilidade": config.SENSIBILIDADE, "setores": config.SETORES_B3, "fonte": fonte,
            "faltando": [n for k, n in nomes.items() if not any(s["serie"] == k for s in series)]}


def noticias(_=None):
    extras = v9.noticias(False)
    ev = db.consultar("SELECT e.*, i.ticker FROM eventos e LEFT JOIN instrumentos i ON i.id=e.instrumento_id WHERE e.origem=? ORDER BY e.publicado_em DESC LIMIT 80",
                      (catalogo.origem_ativa(),))
    legado = [{"id": str(x.get("id")), "titulo": x.get("titulo"), "fonte": x.get("fonte"), "publicado_em": x.get("publicado_em"), "url": None, "resumo": (x.get("categoria") or "") + (" · " + x.get("ticker") if x.get("ticker") else ""), "coletado_em": x.get("coletado_em")} for x in ev]
    return {"eventos": extras["eventos"] + legado, "atualizado_em": extras.get("atualizado_em"), "erros": extras.get("erros", []), "conector_noticias": "RSS público habilitado; use Atualizar notícias para consultar fontes externas.",
            "separacao": "Notícia positiva não vira sinal verde automaticamente: o impacto é ponderado por severidade, idade e confiabilidade."}


def indicadores(inst_id):
    r = ativo(inst_id)["resultado"]
    return {"tecnico": r.get("tecnico"), "extras": r.get("extras", {}), "ticker": r["inst"]["ticker"]}


def riscos(_=None):
    rs = _todas()
    por = {}
    for r in rs:
        s = r["inst"]["setor"] or "Sem setor"
        por.setdefault(s, []).append(r["metricas"]["vol_anual"] or 0)
    tops = sorted(rs, key=lambda r: -(100 - (r["dimensoes"]["risco"]["score"] if r["dimensoes"]["risco"]["score"] is not None else 50)))[:30]
    return {"ativos": [{**_linha(r), "max_drawdown": r["metricas"]["max_drawdown"], "beta": r["metricas"]["beta"], "bloqueios": r["bloqueios"],
                        "risco_score": r["dimensoes"]["risco"]["score"], "penalizacoes": r["penalizacoes"]} for r in tops],
            "exposicao_setorial": [{"setor": k, "n": len(v), "vol_media": round(statistics.mean(v), 3)} for k, v in por.items()],
            "alertas_criticos": [a for a in alertas.listar(100) if a["nivel"] == "critico"][:15]}


def previsoes_(_=None):
    ok, q = previsoes.verificar_cadeia()
    ult = db.consultar("SELECT p.id,p.criado_em,p.data_base,p.horizonte_dias,p.direcao,p.base_preco,p.versao_modelo,p.hash,i.ticker,a.retorno,a.acertou "
                       "FROM previsoes p JOIN instrumentos i ON i.id=p.instrumento_id LEFT JOIN avaliacoes a ON a.previsao_id=p.id ORDER BY p.id DESC LIMIT 120")
    return {"cadeia_integra": ok, "primeiro_adulterado": q, "itens": ult, "metricas": previsoes.metricas(), "horizonte": previsoes.HORIZONTE,
            "aviso": "Sem probabilidades: só direção esperada em 21 pregões, registrada ANTES do resultado e imutável."}


def autoaval(_=None):
    return autoavaliacao.relatorio()


def backtest_(_=None):
    return db.cfg_get("ultimo_backtest") or {"vazio": True}


def diagnostico(_=None):
    return {"fontes": conector_base.testar_fontes()}


def plano_coleta_status(_=None):
    return {"plano": plano_coleta.status(), "fontes": plano_coleta.inventario()}


def b3_status(_=None):
    return b3_cotahist.status()


def live_status(_=None):
    return live_auto.estado()


def cvm_status(_=None):
    return cvm.status()


def cvm_dicionario(_=None):
    return cvm.dicionario_contabil()


def live_ultimas(inst_id):
    instrumento = catalogo.obter(int(inst_id))
    if not instrumento:
        raise KeyError("instrumento não encontrado")
    return {"instrumento": instrumento, "resumo": live.resumo(int(inst_id)),
            "cotacoes": live.ultimas(int(inst_id), 300),
            "aviso": "Snapshots do provedor; estado e horário de observação são preservados."}


def evolucao_(_=None):
    return {"propostas": evolucao.listar(), "fila_pesquisa": pesquisa.proximas(15), "estados": evolucao.ESTADOS, "protegidos": list(evolucao.PROTEGIDOS),
            "relatorio_tecnologias": "Pesquisa tecnológica automática disponível na Central IA GFI."}

def gfi_ai_estado(_=None):
    return ia_evolucao.estado()


def atualizacoes_(_=None):
    return {"pacotes": atualizacoes.listar(), "modo_seguro": atualizacoes.modo_seguro(), "pasta": str(atualizacoes.DIR),
            "indicadores": [n for n, _ in atualizacoes.INDICADORES.values()], "conectores": list(atualizacoes.CONECTORES),
            "rankings": [k for k in oportunidades.RANKINGS if k.startswith("x_")]}


def alertas_(_=None):
    return {"itens": alertas.listar(100), "config": {"nivel_min": db.cfg_get("alerta_nivel_min", "atencao"), "cooldown_dias": db.cfg_get("alerta_cooldown_dias", 7),
                                                       "delta_indice": db.cfg_get("alerta_delta_indice", 10)}}


def config_(_=None):
    return {"modo": recursos.modo_atual(), "modos": config.MODOS, "pesos": pontuacao.pesos_efetivos(None), "pesos_padrao": config.PESOS_PADRAO,
            "rotulos": config.ROTULOS, "limiares": config.LIMIARES, "demo": db.cfg_get("modo_demo", False), "taxa_desconto": config.TAXA_DESCONTO,
            "alertas": alertas_()["config"], "agendador_pausado": db.cfg_get("agendador_pausado", False)}


# ------------------------------------------------------------------ ações (POST)
def acao(rota, c):
    if rota == "cotacoes/atualizar": return v9.cotacoes(c.get("limite", 35))
    if rota == "buscar-geral": return v9.buscar_geral()
    if rota == "noticias/atualizar": return v9.noticias(True)
    if rota == "carteira/lancar": return v9.carteira_lancar(c)
    if rota == "carteira/atualizar-cotacoes": return v9.carteira_atualizar_cotacoes()
    if rota == "plano-coleta/atualizar":
        return plano_coleta.atualizar(int(c.get("tarefa_id")), str(c.get("status", "")), c.get("evidencia", ""), c.get("validacao", ""), c.get("responsavel", "operador"))
    if rota == "b3/coletar":
        if db.cfg_get("modo_demo", False):
            raise PermissionError("desative o modo demonstração antes de coletar dados reais")
        anos = c.get("anos")
        return {"resultado": b3_cotahist.coletar(anos), "status": b3_cotahist.status()}
    if rota == "cvm/coletar":
        return cvm.coletar(str(c.get("documento", "DFP")).upper(), int(c.get("ano")))
    if rota == "cvm/importar":
        import base64
        bruto = base64.b64decode(str(c.get("zip_base64", "")), validate=True)
        return cvm.importar_zip(bruto, str(c.get("documento", "DFP")).upper(), int(c.get("ano")), "UPLOAD-LOCAL")
    if rota == "cvm/mapear":
        return cvm.mapear_emissor(c.get("cnpj"), c.get("instrumento_id"), c.get("observacao", ""))
    if rota == "live/auto":
        return live_auto.configurar(c.get("ativo", False), c.get("intervalo_segundos", 60))
    if rota == "live/coletar":
        return yahoo_chart.coletar(int(c.get("instrumento_id")), str(c.get("simbolo", "")),
                                   str(c.get("intervalo", "1m")), str(c.get("periodo", "1d")))
    if rota == "modo":
        if c.get("modo") not in config.MODOS:
            raise ValueError("modo inválido")
        db.cfg_set("modo", c["modo"])
        return {"modo": c["modo"]}
    if rota == "demo/gerar":
        r = simulado.gerar()
        db.cfg_set("modo_demo", True)
        pipeline.recalcular(todos=True)
        return r
    if rota == "demo/avancar":
        d = simulado.avancar(max(1, min(int(c.get("dias", 5)), 60)))
        if not d:
            raise ValueError("não há mais pregões simulados escondidos")
        return {"data": d, "recalculo": pipeline.recalcular(todos=True)}
    if rota == "demo/modo":
        db.cfg_set("modo_demo", bool(c.get("ativo")))
        return {"demo": db.cfg_get("modo_demo", False)}
    if rota == "recalcular":
        return agendador.executar("recalcular") if not c.get("todos") else pipeline.recalcular(todos=True)
    if rota == "tarefa":
        if c.get("nome") not in agendador.INTERVALOS:
            raise ValueError("tarefa desconhecida")
        return agendador.executar(c["nome"])
    if rota == "agendador":
        db.cfg_set("agendador_pausado", bool(c.get("pausar")))
        return {"pausado": bool(c.get("pausar"))}
    if rota == "config":
        if "pesos" in c:
            p = {k: float(v) for k, v in c["pesos"].items() if k in config.DIMENSOES and float(v) >= 0}
            db.cfg_set("pesos", p)
        for k, nome in (("nivel_min", "alerta_nivel_min"), ("cooldown_dias", "alerta_cooldown_dias"), ("delta_indice", "alerta_delta_indice")):
            if k in (c.get("alertas") or {}):
                db.cfg_set(nome, c["alertas"][k])
        return config_()
    if rota == "alertas/lidos":
        db.executar("UPDATE alertas SET lido=1")
        return {"ok": True}
    if rota == "gfi-ai/chat":
        return ia_evolucao.conversar(c.get("mensagem", ""))
    if rota == "gfi-ai/ciclo":
        return {"relatorio": ia_evolucao.executar_ciclo(), "estado": ia_evolucao.estado()}
    if rota == "gfi-ai/configurar":
        return ia_evolucao.configurar(c.get("ativo"), c.get("intervalo_horas"))
    if rota == "evolucao/criar":
        return {"id": evolucao.criar(str(c["titulo"])[:120], str(c.get("descricao", ""))[:800], "usuario", mudanca=c.get("mudanca"))}
    if rota == "evolucao/avancar":
        return evolucao.avancar(int(c["id"]))
    if rota == "evolucao/testar":
        return evolucao.testar(int(c["id"]))
    if rota == "evolucao/aprovar":
        return evolucao.aprovar(int(c["id"]), c.get("confirmacao"), "usuario")
    if rota == "evolucao/rejeitar":
        return evolucao.rejeitar(int(c["id"]))
    if rota == "evolucao/reverter":
        return evolucao.reverter(int(c["id"]))
    if rota == "atualizacoes/ativar":
        return atualizacoes.ativar(str(c["id"]), bool(c.get("confirmo")))
    if rota == "atualizacoes/desativar":
        return atualizacoes.desativar(str(c["id"]), bool(c.get("remover_dados")))
    if rota == "atualizacoes/conector":
        return atualizacoes.executar_conector(str(c["chave"]))
    raise KeyError(rota)


GET = {"backtest": backtest_, "diagnostico": diagnostico, "saude": saude, "visao": visao, "mercados": mercados, "radar": radar, "ranking": ranking, "macro": macro, "noticias": noticias, "riscos": riscos,
       "live/status": live_status, "plano-coleta": plano_coleta_status, "b3/status": b3_status, "cvm/status": cvm_status, "cvm/dicionario": cvm_dicionario, "previsoes": previsoes_, "autoavaliacao": autoaval, "evolucao": evolucao_, "gfi-ai": gfi_ai_estado, "alertas": alertas_, "config": config_, "atualizacoes": atualizacoes_, "carteira": lambda _: v9.carteira_resumo(), "carteira/ativos": lambda q: v9.carteira_ativos(q.get("q", "")), "v9/status": lambda _: v9.status()}
