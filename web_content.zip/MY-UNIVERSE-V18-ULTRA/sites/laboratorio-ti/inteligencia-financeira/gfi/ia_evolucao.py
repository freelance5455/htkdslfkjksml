"""Agente de evolução supervisionada da GFI.
Pesquisa fontes públicas, diagnostica o projeto e prepara relatórios/código em laboratório.
Nunca altera o núcleo de produção nem executa código gerado automaticamente.
"""
import ast
import html
import json
import os
import re
import ipaddress
from html.parser import HTMLParser
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
import sys
from pathlib import Path

# Permite reutilizar o agente LLM da NEXUS quando a GFI roda isoladamente.
_RAIZ_UNIVERSO = Path(__file__).resolve().parents[4]
if str(_RAIZ_UNIVERSO) not in sys.path:
    sys.path.insert(0, str(_RAIZ_UNIVERSO))

from . import config, db

BASE = config.DADOS / "gfi_ai"
RELATORIOS = BASE / "relatorios"
PROPOSTAS = config.LAB / "gfi_ai" / "propostas"
_LOCK = threading.RLock()
_STOP = threading.Event()
_THREAD = None


def _ler_estado():
    BASE.mkdir(parents=True, exist_ok=True)
    p = BASE / "estado.json"
    if not p.exists():
        return {"ativo": True, "intervalo_horas": 24, "ultima_execucao": None, "ultimo_status": "aguardando primeiro ciclo", "relatorios": []}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {"ativo": False, "intervalo_horas": 24, "ultima_execucao": None, "ultimo_status": "estado corrompido; agente pausado", "relatorios": []}


def _salvar_estado(e):
    BASE.mkdir(parents=True, exist_ok=True)
    tmp = BASE / "estado.tmp"
    tmp.write_text(json.dumps(e, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(BASE / "estado.json")


def _diagnostico():
    raiz = config.RAIZ
    arquivos = list(raiz.rglob("*.py"))
    arquivos = [p for p in arquivos if not any(x in p.parts for x in ("__pycache__", ".venv", "venv"))]
    testes = sorted(str(p.relative_to(raiz)) for p in (raiz / "testes").glob("test_*.py"))
    try:
        cobertura = __import__("gfi.catalogo", fromlist=["cobertura"]).cobertura()
    except Exception as exc:
        cobertura = {"erro": type(exc).__name__}
    try:
        fila = __import__("gfi.pesquisa", fromlist=["proximas"]).proximas(12)
    except Exception:
        fila = []
    try:
        propostas = db.consultar("SELECT id,titulo,estado,criado_em FROM propostas ORDER BY id DESC LIMIT 12")
    except Exception:
        propostas = []
    try:
        falhas = db.consultar("SELECT fonte,COUNT(*) n FROM coletas WHERE status='erro' AND inicio>? GROUP BY fonte", (time.time()-7*86400,))
    except Exception:
        falhas = []
    return {"arquivos_python": len(arquivos), "testes": testes, "cobertura": cobertura, "fila_pesquisa": fila,
            "propostas_existentes": propostas, "falhas_coleta_7d": falhas,
            "documentos": ["README.md", "PLANO_COLETA_145.md", "INVENTARIO_FONTES.md", "STATUS_FINALIZACAO.md"]}


class _TextoPagina(HTMLParser):
    """Extrai texto legível e ignora scripts, estilos e navegação."""
    def __init__(self):
        super().__init__(); self.partes = []; self.ignorar = 0
    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript", "svg", "nav", "footer", "header"):
            self.ignorar += 1
    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "svg", "nav", "footer", "header") and self.ignorar:
            self.ignorar -= 1
    def handle_data(self, data):
        if not self.ignorar:
            t = " ".join(data.split())
            if t: self.partes.append(t)


def _url_publica(url):
    p = urllib.parse.urlsplit(url)
    if p.scheme != "https" or not p.hostname or p.username or p.password or p.port not in (None, 443):
        return False
    host = p.hostname.lower().rstrip(".")
    if host in ("localhost", "localhost.localdomain") or host.endswith(".local"):
        return False
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_global
    except ValueError:
        return "." in host and not host.startswith("-")


class _RedirecionadorSeguro(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        destino = urllib.parse.urljoin(req.full_url, newurl)
        if not _url_publica(destino):
            return None
        return super().redirect_request(req, fp, code, msg, headers, destino)


def _ler_pagina(url):
    """Lê texto de uma página HTTPS pública; não executa conteúdo nem segue URL insegura."""
    if not _url_publica(url):
        return ""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; GFIResearch/1.0)", "Accept": "text/html"})
        with urllib.request.build_opener(_RedirecionadorSeguro()).open(req, timeout=10) as r:
            if r.geturl() != url and not _url_publica(r.geturl()):
                return ""
            if "text/html" not in r.headers.get("Content-Type", ""):
                return ""
            bruto = r.read(1_200_000).decode("utf-8", "replace")
        parser = _TextoPagina(); parser.feed(bruto)
        return " ".join(parser.partes)[:6500]
    except Exception:
        return ""


def _pesquisar(consulta, limite=5):
    """Pesquisa pública via DuckDuckGo HTML; somente domínio fixo e sem baixar executáveis."""
    q = urllib.parse.urlencode({"q": consulta})
    url = "https://html.duckduckgo.com/html/?" + q
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; GFIResearch/1.0)"})
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            bruto = r.read(1_500_000).decode("utf-8", "replace")
        links = []
        for href, titulo in re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', bruto, re.I | re.S):
            href = html.unescape(href)
            parsed = urllib.parse.urlsplit(href)
            if parsed.hostname and parsed.hostname.endswith("duckduckgo.com"):
                destino = urllib.parse.parse_qs(parsed.query).get("uddg", [""])[0]
            else:
                destino = href
            p = urllib.parse.urlsplit(destino)
            if p.scheme == "https" and p.hostname and not any(x in p.hostname for x in ("duckduckgo.com",)):
                nome = re.sub("<[^>]+>", "", html.unescape(titulo)).strip()
                if nome and destino not in [x["url"] for x in links]:
                    links.append({"titulo": nome[:240], "url": destino[:1000]})
            if len(links) >= limite:
                break
        return links
    except Exception as erro_ddg:
        # Provedor alternativo: Bing RSS. Não depende de chave e só retorna links HTTPS.
        try:
            import xml.etree.ElementTree as ET
            rss = "https://www.bing.com/search?format=rss&count=" + str(max(1, min(limite, 10))) + "&q=" + urllib.parse.quote(consulta)
            req = urllib.request.Request(rss, headers={"User-Agent": "GFIResearch/1.0", "Accept": "application/rss+xml, application/xml"})
            with urllib.request.urlopen(req, timeout=12) as r:
                raiz = ET.fromstring(r.read(1_500_000))
            links = []
            for item in raiz.findall(".//item"):
                titulo = (item.findtext("title") or "").strip()
                destino = (item.findtext("link") or "").strip()
                if titulo and _url_publica(destino):
                    links.append({"titulo": titulo[:240], "url": destino[:1000]})
                if len(links) >= limite: break
            if links: return links
        except Exception as erro_bing:
            return [{"erro": f"Pesquisa externa indisponível (DuckDuckGo: {type(erro_ddg).__name__}; Bing RSS: {type(erro_bing).__name__})."}]
        return [{"erro": f"Pesquisa externa sem resultados (DuckDuckGo: {type(erro_ddg).__name__})."}]


def _candidatos_modelo():
    """Descobre endpoints locais comuns e o provedor NEXUS sem expor segredos."""
    candidatos = []
    configurado = os.environ.get("GFI_AI_LLM_URL", "").strip()
    chave = os.environ.get("GFI_AI_LLM_API_KEY", "").strip()
    modelo = os.environ.get("GFI_AI_LLM_MODEL", "").strip()
    if configurado:
        candidatos.append({"tipo": "openai", "url": configurado, "modelo": modelo or "gpt-4o-mini", "chave": chave, "origem": "configurado"})
    # Ollama nativo primeiro para descobrir o nome real do modelo instalado.
    candidatos.append({"tipo": "ollama", "url": "http://127.0.0.1:11434/api/chat", "modelo": modelo, "chave": "", "origem": "Ollama nativo"})
    # Endpoints OpenAI-compatible: LM Studio, llama.cpp e Ollama.
    for url, nome in (("http://127.0.0.1:1234/v1/chat/completions", "LM Studio"),
                      ("http://127.0.0.1:8080/v1/chat/completions", "llama.cpp/NEXUS"),
                      ("http://127.0.0.1:11434/v1/chat/completions", "Ollama OpenAI-compatible"),
                      ("http://127.0.0.1:8000/v1/chat/completions", "vLLM")):
        candidatos.append({"tipo": "openai", "url": url, "modelo": modelo or "qwen-local", "chave": "", "origem": nome})
    return candidatos


def _get_json(url, headers=None, timeout=1.8, payload=None):
    """GET/POST JSON com limite de resposta, usado na descoberta e nos testes."""
    cab = {"User-Agent": "GFI-AI/1.0", **(headers or {})}
    dados = json.dumps(payload).encode() if payload is not None else None
    if dados is not None:
        cab.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=dados, headers=cab, method="POST" if dados is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read(3_000_000))


def _testar_candidato(c):
    url = c["url"]
    p = urllib.parse.urlsplit(url)
    if p.scheme != "https" and p.hostname not in ("127.0.0.1", "localhost", "::1"):
        return False, "url_insegura"
    headers = {}
    if c.get("chave"):
        headers["Authorization"] = "Bearer " + c["chave"]
    if c["tipo"] == "ollama":
        teste = "http://127.0.0.1:11434/api/tags"
    else:
        caminho = p.path
        if caminho.endswith("/chat/completions"):
            caminho = caminho[:-len("/chat/completions")] + "/models"
        teste = urllib.parse.urlunsplit((p.scheme, p.netloc, caminho or "/health", "", ""))
    try:
        obj = _get_json(teste, headers=headers)
        if c["tipo"] == "ollama":
            modelos = [x.get("name") for x in obj.get("models", []) if x.get("name")]
            if not modelos:
                return False, "sem_modelos_instalados"
            c["modelo"] = c.get("modelo") or modelos[0]
        return True, "conectado"
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            return False, "autenticacao_necessaria"
        return False, "http_" + str(exc.code)
    except Exception as exc:
        return False, type(exc).__name__


def _detectar_provedor():
    """API compatível com o painel: descobre servidores locais e valida URLs externas."""
    configurado = os.environ.get("GFI_AI_LLM_URL", "").strip()
    if configurado:
        p = urllib.parse.urlsplit(configurado)
        if p.scheme != "https" and p.hostname not in ("127.0.0.1", "localhost", "::1"):
            return None, {"modelo": "sem_modelo_configurado", "status": "url_insegura", "provedor": None,
                          "detalhe": "Endpoint externo recusado: use HTTPS."}
    for c in _candidatos_modelo():
        ok, status = _testar_candidato(c)
        if ok:
            return c, {"modelo": c.get("modelo") or "modelo_detectado", "status": "conectado",
                       "provedor": c["origem"], "detalhe": "Servidor de inferência respondeu ao teste de disponibilidade."}
    try:
        from nexus import llm
        if llm.disponivel():
            return {"tipo": "nexus", "origem": "NEXUS local"}, {"modelo": "nexus_local", "status": "conectado",
                    "provedor": "NEXUS local", "detalhe": "Modelo local da NEXUS respondeu ao health check."}
    except Exception:
        pass
    return None, {"modelo": "sem_modelo_configurado", "status": "nenhum_provedor_local",
                  "provedor": None, "detalhe": "Nenhum servidor de inferência respondeu. Detectados automaticamente llama.cpp/NEXUS (8080), LM Studio (1234) e Ollama (11434)."}


def _provedor_ativo():
    return _detectar_provedor()


def _diagnostico_modelo():
    return _detectar_provedor()[1]


def _modelo_disponivel():
    return _diagnostico_modelo()["modelo"]


def _consultar_modelo(prompt):
    prov, _ = _provedor_ativo()
    if not prov:
        return None
    mensagens = [
        {"role": "system", "content": "Você é o engenheiro-chefe de evolução da GFI. Responda em português, com rigor técnico. Diferencie fatos, hipóteses e recomendações. Cite fontes consultadas. Nunca alegue testes não executados. Se fornecer código, use um bloco Python e informe o caminho de destino. Código somente para laboratório, nunca para aplicação automática."},
        {"role": "user", "content": prompt}]
    if prov["tipo"] == "nexus":
        from nexus import llm
        return llm.chat(mensagens, max_tokens=3500, timeout=120)
    if prov["tipo"] == "ollama":
        corpo = {"model": prov["modelo"], "stream": False, "messages": mensagens,
                 "options": {"temperature": 0.2, "num_predict": 3500}}
        obj = _get_json(prov["url"], payload=corpo, timeout=180)
        return obj.get("message", {}).get("content")
    corpo = {"model": prov.get("modelo") or "qwen-local", "messages": mensagens,
             "temperature": 0.2, "max_tokens": 3500}
    cab = {"Content-Type": "application/json"}
    if prov.get("chave"):
        cab["Authorization"] = "Bearer " + prov["chave"]
    obj = _get_json(prov["url"], headers=cab, timeout=180, payload=corpo)
    return obj["choices"][0]["message"]["content"]


def conversar(mensagem):
    """Chat imediato: usa LLM real quando disponível; caso contrário, modo local transparente."""
    texto = str(mensagem or '').strip()[:6000]
    if not texto:
        raise ValueError("Digite uma pergunta para a IA GFI.")
    prov, diagnostico = _provedor_ativo()
    if prov:
        resposta = _consultar_modelo("""Responda à pergunta do usuário sobre a GFI. Use o inventário real quando possível; diferencie fatos e hipóteses. Não invente dados de mercado nem testes.

PERGUNTA:
""" + texto)
        if resposta:
            return {"resposta": resposta, "modo": "llm", "provedor": prov.get("origem"), "status": "resposta gerada pelo modelo conectado"}
    # Assistente local funcional sem fingir que existe inferência generativa.
    diag = _diagnostico()
    return {"resposta": ("**Modo local de diagnóstico (sem modelo generativo conectado).**\n\n"
        "Recebi sua pergunta: **" + texto.replace("<", "&lt;").replace(">", "&gt;") + "**\n\n"
        "Posso confirmar o estado técnico disponível neste ambiente: a GFI contém **" + str(diag.get("arquivos_python", 0)) + " arquivos Python** no inventário; "
        "há **" + str(len(diag.get("testes", []))) + " arquivos de teste** identificados; a detecção de modelo informa: **" + diagnostico.get("detalhe", "sem diagnóstico") + "**.\n\n"
        "Para respostas generativas, análise semântica e criação de código por IA, conecte um modelo local (Ollama/LM Studio/llama.cpp) ou endpoint HTTPS. "
        "O botão já funciona neste modo e não simula uma resposta de LLM."),
        "modo": "local_diagnostico", "provedor": None, "status": "LLM não conectado; diagnóstico local disponível"}

def _codigo(texto):
    blocos = re.findall(r"```(?:python|py)?\s*\n(.*?)```", texto or "", re.S | re.I)
    return blocos[0].strip() + "\n" if blocos else ""


def _riscos_codigo(codigo):
    """Sinaliza operações sensíveis para revisão; não executa nem tenta provar segurança."""
    try:
        arvore = ast.parse(codigo)
    except SyntaxError as exc:
        return [f"erro de sintaxe na linha {exc.lineno}: {exc.msg}"]
    riscos = []
    modulos = {"subprocess", "socket", "ctypes", "shutil", "pickle", "multiprocessing", "requests", "urllib"}
    chamadas = {"eval", "exec", "compile", "__import__", "system", "popen", "remove", "rmtree", "unlink"}
    for no in ast.walk(arvore):
        if isinstance(no, (ast.Import, ast.ImportFrom)):
            nomes = [x.name.split(".")[0] for x in no.names] if isinstance(no, ast.Import) else [(no.module or "").split(".")[0]]
            for nome in nomes:
                if nome in modulos: riscos.append(f"import sensível: {nome}")
        if isinstance(no, ast.Call):
            nome = no.func.id if isinstance(no.func, ast.Name) else no.func.attr if isinstance(no.func, ast.Attribute) else ""
            if nome in chamadas: riscos.append(f"chamada sensível: {nome}")
            if nome == "open": riscos.append("acesso direto a arquivos: open")
    return sorted(set(riscos))


def executar_ciclo():
    with _LOCK:
        RELATORIOS.mkdir(parents=True, exist_ok=True)
        PROPOSTAS.mkdir(parents=True, exist_ok=True)
        diag = _diagnostico()
        consultas = [
            "Python secure code generation sandbox AST validation best practices",
            "B3 COTAHIST official historical market data layout documentation",
            "CVM dados abertos DFP ITR API documentação",
            "SQLite WAL backup integrity Python unittest best practices",
        ]
        pesquisas = [{"consulta": q, "resultados": _pesquisar(q)} for q in consultas]
        paginas_lidas = []
        vistos = set()
        for grupo in pesquisas:
            for resultado in grupo["resultados"]:
                url = resultado.get("url")
                if url and url not in vistos and len(paginas_lidas) < 6:
                    vistos.add(url)
                    conteudo = _ler_pagina(url)
                    if conteudo:
                        paginas_lidas.append({"titulo": resultado.get("titulo"), "url": url, "conteudo": conteudo})
        prompt = ("Analise a GFI a partir dos dados reais do inventário abaixo. Gere relatório com: resumo executivo; "+
                  "diagnóstico comprovado; oportunidades priorizadas; pesquisa e fontes; proposta técnica; riscos; testes; "+
                  "arquivos/caminhos exatos; e código Python completo em um bloco, se houver melhoria pequena e segura. "+
                  "Não invente métricas nem alegue que testou algo que não executou. Não altere arquivos protegidos.\n\nINVENTÁRIO:\n"+
                  json.dumps(diag, ensure_ascii=False, default=str)[:18000]+"\n\nPESQUISA:\n"+
                  json.dumps(pesquisas, ensure_ascii=False)[:12000]+"\n\nPÁGINAS PÚBLICAS LIDAS:\n"+json.dumps(paginas_lidas, ensure_ascii=False)[:18000])
        resposta = _consultar_modelo(prompt)
        diagnostico_modelo = _diagnostico_modelo()
        modelo = diagnostico_modelo["modelo"]
        if resposta:
            relatorio = resposta
            codigo = _codigo(resposta)
        else:
            relatorio = ("# Relatório de diagnóstico da GFI\n\n"
                "**Estado da IA:** não há modelo de linguagem configurado ou acessível. Este ciclo executou diagnóstico local e tentou pesquisa externa; "
                "não é correto chamar esta saída de análise por LLM.\n\n"
                "## Inventário observado\n\n```json\n"+json.dumps(diag, ensure_ascii=False, indent=2, default=str)+"\n```\n\n"
                "## Pesquisa externa\n\n"+"\n".join("### "+x["consulta"]+"\n"+"\n".join("- ["+r.get("titulo", r.get("erro", "sem resultado"))+"]("+r.get("url", "")+")" for r in x["resultados"]) for x in pesquisas)+"\n\n"
                "## Próxima etapa\n\nConfigure `GFI_AI_LLM_URL`, `GFI_AI_LLM_MODEL` e, se necessário, `GFI_AI_LLM_API_KEY` no ambiente do servidor para ativar geração de análise e código por LLM.\n")
            codigo = ""
        rid = time.strftime("%Y%m%d-%H%M%S") + "-" + str(int(time.time()*1000)%100000)
        md = RELATORIOS / (rid + ".md")
        md.write_text("# GFI AI — ciclo " + rid + "\n\n" + relatorio + "\n\n---\n\n## Evidências do ciclo\n\n"+
                      "- Arquivos Python encontrados: " + str(diag["arquivos_python"]) + "\n"+
                      "- Modelo: " + modelo + "\n- Pesquisa externa: " + ("resultados obtidos" if any(x["resultados"] and "url" in x["resultados"][0] for x in pesquisas) else "sem resultados confirmados") + "\n",
                      encoding="utf-8")
        codigo_path = None
        riscos_codigo = []
        if codigo:
            pasta = PROPOSTAS / rid
            pasta.mkdir(parents=True, exist_ok=True)
            destino = pasta / "melhoria_proposta.py"
            destino.write_text(codigo, encoding="utf-8")
            try:
                ast.parse(codigo)
                sintaxe = "válida"
            except SyntaxError as exc:
                sintaxe = f"inválida: linha {exc.lineno}: {exc.msg}"
            riscos_codigo = _riscos_codigo(codigo)
            codigo_path = str(destino.relative_to(config.RAIZ))
        e = _ler_estado()
        item = {"id": rid, "arquivo": str(md.relative_to(config.RAIZ)), "criado_em": time.time(),
                "modelo": modelo, "provedor": diagnostico_modelo.get("provedor"), "codigo": codigo_path, "validacao_sintaxe": sintaxe if codigo else "não fornecido pelo modelo",
                "status": "aguardando revisão humana", "paginas_lidas": len(paginas_lidas), "riscos_codigo": riscos_codigo,
                "fontes": [r for x in pesquisas for r in x["resultados"] if "url" in r]}
        e["relatorios"] = [item] + e.get("relatorios", [])[:49]
        e["ultima_execucao"] = time.time()
        e["ultima_pesquisa_ok"] = bool(paginas_lidas)
        e["ultimo_status"] = "ciclo concluído; relatório pronto para revisão" if resposta else "diagnóstico local concluído; modelo LLM não conectado"
        _salvar_estado(e)
        db.log("INFO", "gfi_ai", f"ciclo {rid} concluído; modelo={modelo}; código={'sim' if codigo else 'não'}")
        return item


def estado():
    e = _ler_estado()
    diagnostico = _diagnostico_modelo()
    e["modelo"] = diagnostico["modelo"]
    e["modelo_status"] = diagnostico
    e["provedor_detectado"] = diagnostico.get("provedor")
    if e.get("ultima_execucao") is None:
        e["pesquisa_web"] = "ainda_nao_testada"
    else:
        e["pesquisa_web"] = "confirmada" if e.get("ultima_pesquisa_ok") else "indisponivel_na_ultima_execucao"
    e["autonomia"] = 3
    e["limites"] = ["não altera o núcleo de produção", "não executa código gerado", "não publica atualizações", "código fica em laboratorio/gfi_ai/propostas", "revisão humana obrigatória"]
    return e


def configurar(ativo=None, intervalo_horas=None):
    e = _ler_estado()
    if ativo is not None:
        e["ativo"] = bool(ativo)
    if intervalo_horas is not None:
        n = int(intervalo_horas)
        if n < 1 or n > 168:
            raise ValueError("intervalo deve ser entre 1 e 168 horas")
        e["intervalo_horas"] = n
    _salvar_estado(e)
    return estado()


def ler_relatorio(rid):
    if not re.fullmatch(r"[A-Za-z0-9-]{5,40}", str(rid)):
        raise ValueError("identificador inválido")
    p = RELATORIOS / (rid + ".md")
    if not p.is_file() or p.resolve().parent != RELATORIOS.resolve():
        raise KeyError(rid)
    return {"id": rid, "conteudo": p.read_text(encoding="utf-8")[:50000]}


def iniciar_agente():
    global _THREAD
    if _THREAD and _THREAD.is_alive():
        return
    _STOP.clear()
    def ciclo():
        while not _STOP.is_set():
            e = _ler_estado()
            if e.get("ativo") and (not e.get("ultima_execucao") or time.time()-e["ultima_execucao"] >= int(e.get("intervalo_horas",24))*3600):
                try:
                    executar_ciclo()
                except Exception as exc:
                    e = _ler_estado(); e["ultimo_status"] = "falha no ciclo: " + type(exc).__name__; _salvar_estado(e)
                    db.log("ERRO", "gfi_ai", f"{type(exc).__name__}: {exc}")
            _STOP.wait(60)
    _THREAD = threading.Thread(target=ciclo, name="GFI-AI-Evolucao", daemon=True)
    _THREAD.start()


def parar_agente():
    _STOP.set()
