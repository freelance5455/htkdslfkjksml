"""Evolução controlada: PESQUISA → PROPOSTA → EXPERIMENTAL → TESTES → COMPARAÇÃO → APROVAÇÃO → PUBLICAÇÃO.

A IA pode pesquisar, propor, escrever código experimental SOMENTE em laboratorio/, testar e comparar.
Ela NÃO pode publicar sozinha: a aprovação exige o usuário digitar APROVO. Propostas que toquem em regras de
segurança/integridade são recusadas automaticamente. Mudanças de configuração publicadas têm backup e reversão.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from . import config, db
from .motores import pontuacao

ESTADOS = ["pesquisa", "proposta", "experimental", "testes", "comparacao", "aprovacao", "publicada"]
PROTEGIDOS = ("gfi/db.py", "gfi/evolucao.py", "gfi/config.py", "gfi/previsoes.py", "gfi/recursos.py", "gfi/alertas.py",
              "gfi/validacao.py", "gfi/pipeline.py", "servidor.py", "iniciar.sh")
MAX_PESO_REL = 0.35        # nenhuma dimensão pode passar de 35% do peso total


def _hist(p, evento):
    atual = p["historico"]
    atual = json.loads(atual or "[]") if isinstance(atual, str) or atual is None else atual
    return json.dumps(atual + [{"ts": time.time(), "evento": evento}])


def obter(pid):
    p = db.um("SELECT * FROM propostas WHERE id=?", (pid,))
    if p:
        p["arquivos"] = json.loads(p["arquivos"] or "{}")
        p["resultado_testes"] = json.loads(p["resultado_testes"] or "null")
        p["historico"] = json.loads(p["historico"] or "[]")
    return p


def criar(titulo, descricao, origem="ia", arquivos=None, mudanca=None):
    """Cria proposta. Arquivos fora de laboratorio/ ou protegidos → rejeitada na hora."""
    arquivos, motivo = arquivos or [], None
    for a in arquivos:
        norm = os.path.normpath(a).replace("\\", "/")
        if any(norm.endswith(p) or norm == p for p in PROTEGIDOS):
            motivo = f"toca em regra de segurança/integridade ({norm}): só edição manual do dono"
        elif norm.startswith("..") or os.path.isabs(norm) or not norm.startswith("laboratorio/"):
            motivo = f"fora da área experimental ({norm})"
    if mudanca and set(mudanca) - {"pesos"}:
        motivo = "mudança de configuração não permitida (somente 'pesos')"
    agora = time.time()
    pid = db.executar("INSERT INTO propostas(titulo,descricao,origem,estado,arquivos,resultado_testes,criado_em,atualizado_em,historico) "
                      "VALUES(?,?,?,?,?,NULL,?,?,?)",
                      (titulo, descricao, origem, "rejeitada" if motivo else "proposta", json.dumps({"arquivos": arquivos, "mudanca": mudanca}),
                       agora, agora, json.dumps([{"ts": agora, "evento": "criada" + (f" e rejeitada: {motivo}" if motivo else "")}])))
    db.log("INFO", "evolucao", f"proposta #{pid} '{titulo}' ({origem})" + (f" REJEITADA: {motivo}" if motivo else ""))
    return pid


def _set(p, estado, evento, **extra):
    db.executar("UPDATE propostas SET estado=?,atualizado_em=?,historico=?,resultado_testes=COALESCE(?,resultado_testes),aprovado_por=COALESCE(?,aprovado_por) WHERE id=?",
                (estado, time.time(), _hist(p, evento), extra.get("testes"), extra.get("aprovado_por"), p["id"]))


def avancar(pid):
    p = obter(pid)
    if not p or p["estado"] in ("rejeitada", "publicada", "revertida"):
        raise ValueError("proposta não pode avançar")
    i = ESTADOS.index(p["estado"])
    prox = ESTADOS[i + 1]
    if prox == "publicada":
        raise PermissionError("publicação exige aprovação explícita do usuário")
    if prox == "aprovacao" and not (p["resultado_testes"] and p["resultado_testes"].get("ok")):
        raise ValueError("só avança para aprovação com testes aprovados")
    if prox == "comparacao" and not p["resultado_testes"]:
        raise ValueError("execute os testes antes da comparação")
    _set(p, prox, f"avançou para {prox}")
    return obter(pid)


def _rodar_codigo(arquivos):
    """Testes de código experimental: subprocesso isolado, cópia temporária, limites de CPU/memória/tempo."""
    with tempfile.TemporaryDirectory() as t:
        for a in arquivos:
            origem = config.RAIZ / a
            if origem.is_file():
                (Path(t) / Path(a).name).write_bytes(origem.read_bytes())
        shell = 'ulimit -t 30 2>/dev/null; ulimit -v 1048576 2>/dev/null; ulimit -f 4096 2>/dev/null; exec "$0" -I -m unittest discover -s . -p "test*.py"'
        try:
            p = subprocess.run(["/bin/sh", "-c", shell, sys.executable], cwd=t, capture_output=True, text=True, timeout=60,
                               env={"PATH": "/usr/bin:/bin", "PYTHONHASHSEED": "0"})
        except subprocess.TimeoutExpired:
            return {"ok": False, "detalhe": "tempo esgotado"}
        return {"ok": p.returncode == 0, "detalhe": (p.stderr or p.stdout)[-400:]}


def testar(pid):
    p = obter(pid)
    if not p or p["estado"] in ("rejeitada", "publicada", "revertida"):
        raise ValueError("proposta inválida")
    mud = p["arquivos"].get("mudanca")
    r = {"ok": True, "verificacoes": []}
    if mud and mud.get("pesos"):
        novo = {**pontuacao.pesos_efetivos(None), **{k: float(v) for k, v in mud["pesos"].items() if k in config.DIMENSOES}}
        tot = sum(novo.values())
        v = [("pesos não negativos", all(x >= 0 for x in novo.values())), ("soma maior que zero", tot > 0),
             (f"nenhuma dimensão acima de {int(MAX_PESO_REL * 100)}%", tot > 0 and max(novo.values()) / tot <= MAX_PESO_REL)]
        r["verificacoes"] = [{"teste": n, "ok": bool(ok)} for n, ok in v]
        r["ok"] = all(ok for _, ok in v)
        if r["ok"]:
            r["comparacao"] = _comparar_pesos(novo)
    elif p["arquivos"].get("arquivos"):
        c = _rodar_codigo(p["arquivos"]["arquivos"])
        r["ok"], r["verificacoes"] = c["ok"], [{"teste": "unittest do experimento", "ok": c["ok"], "detalhe": c["detalhe"]}]
    else:
        r = {"ok": False, "verificacoes": [{"teste": "proposta sem conteúdo testável", "ok": False}]}
    _set(p, "testes" if p["estado"] in ("proposta", "experimental") else p["estado"], f"testes {'aprovados' if r['ok'] else 'reprovados'}", testes=json.dumps(r))
    return r


def _comparar_pesos(novo):
    """Compara o TOP 20 atual com o que resultaria dos novos pesos (reponderando as dimensões já calculadas)."""
    from . import pipeline
    linhas = [x for x in pipeline.ultimas() if x["indice"] is not None and x["inst"]["tipo"] != "indice"]

    def idx(r, pesos):
        ok = {k: pesos[k] for k in pesos if pesos[k] > 0 and r["dimensoes"][k]["score"] is not None}
        w = sum(ok.values())
        return sum(ok[k] * r["dimensoes"][k]["score"] for k in ok) / w if w else 0
    atual = {r["inst"]["id"]: idx(r, pontuacao.pesos_efetivos(r["inst"]["tipo"])) for r in linhas}
    prop = {r["inst"]["id"]: idx(r, {k: novo[k] * config.PESOS_POR_TIPO.get(r["inst"]["tipo"] or "", {}).get(k, 1) for k in novo}) for r in linhas}
    t = lambda d: {i for i, _ in sorted(d.items(), key=lambda x: -x[1])[:20]}
    inter = len(t(atual) & t(prop))
    return {"ativos": len(linhas), "top20_em_comum": inter, "mudancas_no_top20": 20 - inter if len(linhas) >= 20 else None}


def aprovar(pid, confirmacao, aprovador="usuario"):
    """Publica. Só o usuário, digitando APROVO, e apenas a partir do estado 'aprovacao'."""
    p = obter(pid)
    if aprovador != "usuario" or confirmacao != "APROVO":
        raise PermissionError("aprovação exige o usuário digitar APROVO")
    if not p or p["estado"] != "aprovacao":
        raise ValueError("proposta precisa estar em 'aprovacao'")
    mud = p["arquivos"].get("mudanca")
    if mud and mud.get("pesos"):
        antes = db.cfg_get("pesos", {})
        db.cfg_set("pesos_backup", {"proposta": pid, "pesos": antes})
        db.cfg_set("pesos", {**antes, **{k: float(v) for k, v in mud["pesos"].items() if k in config.DIMENSOES}})
    exportado = None
    py = [a for a in p["arquivos"].get("arquivos", []) if a.endswith(".py")]
    if py and (config.RAIZ / py[0]).is_file():
        from . import atualizacoes
        pasta = atualizacoes.DIR / f"ia-proposta-{pid}"
        pasta.mkdir(parents=True, exist_ok=True)
        shutil.copy2(config.RAIZ / py[0], pasta / "codigo.py")
        (pasta / "atualizacao.json").write_text(json.dumps({"id": f"ia-proposta-{pid}", "nome": p["titulo"], "versao": "1.0.0",
                                                            "descricao": p["descricao"], "autor": "IA (proposta aprovada por você)"}, ensure_ascii=False, indent=2), encoding="utf-8")
        exportado = pasta.name
    _set(p, "publicada", "publicada pelo usuário" + (f"; pacote exportado para atualizacoes/{exportado} (ative-o no painel)" if exportado else ""), aprovado_por="usuario")
    db.log("INFO", "evolucao", f"proposta #{pid} publicada pelo usuário")
    return obter(pid)


def reverter(pid):
    p = obter(pid)
    b = db.cfg_get("pesos_backup")
    if not p or p["estado"] != "publicada" or not b or b.get("proposta") != pid:
        raise ValueError("não há backup para reverter esta proposta")
    db.cfg_set("pesos", b["pesos"])
    _set(p, "revertida", "revertida pelo usuário")
    return obter(pid)


def rejeitar(pid, motivo="rejeitada pelo usuário"):
    p = obter(pid)
    if not p or p["estado"] in ("publicada",):
        raise ValueError("proposta inválida")
    _set(p, "rejeitada", motivo)
    return obter(pid)


def listar():
    return [obter(r["id"]) for r in db.consultar("SELECT id FROM propostas ORDER BY id DESC LIMIT 50")]
