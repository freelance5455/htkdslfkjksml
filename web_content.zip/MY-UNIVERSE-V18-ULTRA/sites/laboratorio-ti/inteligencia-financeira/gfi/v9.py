"""Complementos V9: notícias públicas, busca geral, atualização de cotações e carteira pessoal isolada."""
import json, sqlite3, time, urllib.parse, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime
from . import config, db, catalogo, pesquisa
from .conectores import yahoo_chart
DB_V9=config.DADOS/'gfi_v9.db'; RSS='https://news.google.com/rss/search?'; UA='Mozilla/5.0 (compatible; MYUniverse-GFI/9.0; research)'
def _conn():
 DB_V9.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB_V9,timeout=15); c.row_factory=sqlite3.Row; c.execute('PRAGMA journal_mode=WAL')
 c.executescript("""CREATE TABLE IF NOT EXISTS wallet_tx(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,amount REAL NOT NULL CHECK(amount>0),ticker TEXT,quantity REAL,unit_price REAL,occurred_at TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL); CREATE TABLE IF NOT EXISTS news_cache(id TEXT PRIMARY KEY,title TEXT NOT NULL,source TEXT,published TEXT,url TEXT,summary TEXT,fetched_at TEXT NOT NULL); CREATE TABLE IF NOT EXISTS update_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,started_at TEXT,finished_at TEXT,ok INTEGER,detail TEXT); CREATE TABLE IF NOT EXISTS wallet_quotes(ticker TEXT PRIMARY KEY,price REAL NOT NULL,observed_at TEXT NOT NULL,provider TEXT NOT NULL DEFAULT 'YAHOO_FINANCE_CHART');"""); return c
def _now(): return datetime.now().astimezone().isoformat(timespec='seconds')
def _log(kind,ok,detail,start):
 with _conn() as c:c.execute('INSERT INTO update_runs(kind,started_at,finished_at,ok,detail) VALUES(?,?,?,?,?)',(kind,start,_now(),int(bool(ok)),json.dumps(detail,ensure_ascii=False,default=str)[:8000]))
def _rss(query,limit=30):
 req=urllib.request.Request(RSS+urllib.parse.urlencode({'q':query,'hl':'pt-BR','gl':'BR','ceid':'BR:pt-419'}),headers={'User-Agent':UA,'Accept':'application/rss+xml,application/xml'})
 with urllib.request.urlopen(req,timeout=12) as r: raw=r.read(2_000_000)
 root=ET.fromstring(raw); out=[]
 for item in root.findall('.//item')[:limit]:
  title=(item.findtext('title') or '').strip(); link=(item.findtext('link') or '').strip(); pub=(item.findtext('pubDate') or '').strip(); desc=(item.findtext('description') or '').strip(); source=item.find('source'); src=(source.text or '').strip() if source is not None else 'Google Notícias'
  if title and link:out.append({'id':link,'titulo':title,'fonte':src,'publicado_em':pub,'url':link,'resumo':desc[:1200]})
 return out
def noticias(atualizar=False):
 start=_now(); errors=[]; items=[]
 if atualizar:
  for q in ['bolsa de valores Brasil B3 ações economia','Banco Central Brasil Selic inflação câmbio','empresas brasileiras resultados trimestrais mercado financeiro']:
   try:items.extend(_rss(q,15))
   except Exception as e:errors.append(str(e)[:180])
  with _conn() as c:
   for n in items:c.execute('INSERT INTO news_cache(id,title,source,published,url,summary,fetched_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,source=excluded.source,published=excluded.published,summary=excluded.summary,fetched_at=excluded.fetched_at',(n['id'],n['titulo'],n['fonte'],n['publicado_em'],n['url'],n['resumo'],_now()))
  _log('noticias',bool(items),{'recebidas':len(items),'erros':errors},start)
 with _conn() as c:
  rows=c.execute('SELECT id,title,source,published,url,summary,fetched_at FROM news_cache ORDER BY fetched_at DESC LIMIT 60').fetchall()
  last=c.execute("SELECT detail FROM update_runs WHERE kind='noticias' ORDER BY id DESC LIMIT 1").fetchone()
 if not atualizar and last:
  try: errors=json.loads(last['detail']).get('erros',[])
  except Exception: pass
 return {'eventos':[{'id':r['id'],'titulo':r['title'],'fonte':r['source'],'publicado_em':r['published'],'url':r['url'],'resumo':r['summary'],'coletado_em':r['fetched_at']} for r in rows],'atualizado_em':rows[0]['fetched_at'] if rows else None,'erros':errors,'aviso':'RSS público; confirme a matéria na fonte original.'}
def cotacoes(limite=35):
 if db.cfg_get('modo_demo',False):raise PermissionError('Desative o modo demonstração antes de atualizar cotações reais.')
 start=_now(); rows=catalogo.listar('REAL',True)[:max(1,min(int(limite),100))]; ok=[]; fail=[]
 for inst in rows:
  symbol=inst['ticker']+'.SA' if inst.get('pais') in ('BR','BRA','Brasil') or inst.get('mic')=='XBSP' else inst['ticker']
  try:r=yahoo_chart.coletar(inst['id'],symbol,'1m','1d');ok.append({'ticker':inst['ticker'],'pontos':r.get('pontos_recebidos',0),'estado':r.get('estado')})
  except Exception as e:fail.append({'ticker':inst['ticker'],'erro':str(e)[:180]})
 detail={'tentados':len(rows),'atualizados':len(ok),'falhas':len(fail),'itens':ok,'erros':fail};_log('cotacoes',bool(ok),detail,start);return detail
def buscar_geral():
 start=_now(); out={'noticias':0,'lacunas_enfileiradas':0,'cobertura':None,'erros':[]}
 try:n=noticias(True);out['noticias']=len(n['eventos']);out['erros']+=n['erros']
 except Exception as e:out['erros'].append('notícias: '+str(e)[:180])
 try:out['lacunas_enfileiradas']=pesquisa.lacunas();out['cobertura']=catalogo.cobertura()
 except Exception as e:out['erros'].append('diagnóstico de lacunas: '+str(e)[:180])
 _log('busca_geral',not out['erros'],out,start);return out
def carteira_ativos(filtro=''):
 """Lista ações e units brasileiras já cadastradas no catálogo real B3/COTAHIST."""
 q=str(filtro or '').strip().upper()[:24]
 sql="SELECT ticker,nome,tipo,setor,status FROM instrumentos WHERE origem='REAL' AND status='ativo' AND (pais IN ('BR','BRA','Brasil') OR mic IN ('BVMF','XBSP')) AND (tipo IN ('acao_on','acao_pref','unit') OR (tipo IS NULL AND (ticker GLOB '*[345678]' OR ticker GLOB '*11')))"
 args=[]
 if q:
  sql += " AND (ticker LIKE ? OR nome LIKE ?)"; args=[f'%{q}%',f'%{q}%']
 sql += " ORDER BY ticker LIMIT 5000"
 rows=db.consultar(sql,tuple(args))
 return {'total':len(rows),'ativos':rows,'fonte':'Catálogo local de instrumentos B3, alimentado pela importação COTAHIST','aviso':'A lista contém todos os papéis brasileiros presentes no catálogo local; importe o histórico COTAHIST para completar a cobertura. Não inventa tickers nem cotações.'}


def carteira_resumo():
 with _conn() as c: rows=c.execute('SELECT * FROM wallet_tx ORDER BY occurred_at,id').fetchall()
 saldo=0.0; book={}; mov=[]; realizado=0.0; capital_liquido=0.0
 for r in rows:
  x=dict(r); k=x['kind']; amount=float(x['amount']); ticker=x.get('ticker')
  if k=='deposito': saldo+=amount; capital_liquido+=amount
  elif k=='retirada': saldo-=amount; capital_liquido-=amount
  elif k=='compra':
   saldo-=amount; q=float(x['quantity'] or 0); pos=book.setdefault(ticker,{'quantidade':0.0,'custo_total':0.0,'preco_medio':0.0})
   pos['custo_total']+=amount;pos['quantidade']+=q;pos['preco_medio']=pos['custo_total']/pos['quantidade'] if pos['quantidade'] else 0
  elif k=='venda':
   saldo+=amount; q=float(x['quantity'] or 0); pos=book.setdefault(ticker,{'quantidade':0.0,'custo_total':0.0,'preco_medio':0.0})
   custo=pos['preco_medio']*q; realizado+=amount-custo;pos['quantidade']-=q;pos['custo_total']=max(0.0,pos['preco_medio']*pos['quantidade'])
  mov.append(x)
 positions={}; market_total=0.0; all_priced=True
 for ticker,pos in book.items():
  q=pos['quantidade']
  if q<=1e-9: continue
  with _conn() as c:
   qr=c.execute('SELECT price AS preco,observed_at AS referencia,provider AS fonte FROM wallet_quotes WHERE ticker=?',(ticker,)).fetchone()
   quote=dict(qr) if qr else None
  if not quote:
   inst=db.um("SELECT id FROM instrumentos WHERE ticker=? AND origem='REAL' ORDER BY status='ativo' DESC LIMIT 1",(ticker,))
   quote=db.um('SELECT fechamento preco,data referencia,origem fonte FROM cotacoes WHERE instrumento_id=? ORDER BY data DESC LIMIT 1',(inst['id'],)) if inst else None
   if not quote and inst: quote=db.um('SELECT preco,observado_em referencia,provedor fonte FROM cotacoes_intradiarias WHERE instrumento_id=? ORDER BY observado_em DESC LIMIT 1',(inst['id'],))
  price=float(quote['preco']) if quote and quote.get('preco') is not None else None
  value=round(q*price,2) if price is not None else None
  if value is None: all_priced=False
  else: market_total+=value
  positions[ticker]={'quantidade':round(q,8),'preco_medio':round(pos['preco_medio'],6),'custo_total':round(pos['custo_total'],2),'cotacao':price,'valor_mercado':value,'lucro_prejuizo_aberto':round(value-pos['custo_total'],2) if value is not None else None,'rentabilidade_aberta':((value-pos['custo_total'])/pos['custo_total']) if value is not None and pos['custo_total']>0 else None,'referencia_cotacao':quote.get('referencia') if quote else None,'fonte_cotacao':quote.get('fonte') if quote else None}
 return {'saldo_caixa':round(saldo,2),'posicoes':positions,'lucro_prejuizo_realizado':round(realizado,2),'valor_mercado_posicoes':round(market_total,2) if all_priced else None,'patrimonio_total':round(saldo+market_total,2) if all_priced else None,'capital_liquido':round(capital_liquido,2),'resultado_total':round(realizado+sum((p.get('lucro_prejuizo_aberto') or 0) for p in positions.values()),2) if all_priced else None,'rentabilidade_total':((saldo+market_total-capital_liquido)/capital_liquido) if all_priced and capital_liquido>0 else None,'movimentacoes':mov[-200:],'aviso':'Patrimônio total só é exibido quando todas as posições têm cotação identificável. Lucro/prejuízo não inclui taxas, impostos ou proventos.'}

_WALLET_QUOTE_LAST=0.0
_WALLET_QUOTE_LOCK=__import__('threading').Lock()
def carteira_atualizar_cotacoes():
 """Atualiza as posições da carteira com cotações públicas; não é feed em tempo real garantido."""
 global _WALLET_QUOTE_LAST
 with _WALLET_QUOTE_LOCK:
  agora=time.monotonic()
  if agora-_WALLET_QUOTE_LAST < 45:
   return {'atualizadas':[],'falhas':[],'ignorada_por_limite':True,'proxima_consulta_em_segundos':int(45-(agora-_WALLET_QUOTE_LAST)),'carteira':carteira_resumo(),'aviso':'Cotação em cache; limite local de 45 segundos para evitar excesso de consultas ao provedor.'}
  _WALLET_QUOTE_LAST=agora
 resumo=carteira_resumo(); atualizadas=[]; falhas=[]
 for ticker, pos in resumo['posicoes'].items():
  try:
   pacote=yahoo_chart.buscar(ticker+'.SA','1m','1d')
   pontos=pacote.get('pontos') or []
   if not pontos: raise RuntimeError('provedor sem preço recente')
   ultimo=pontos[-1]
   with _conn() as c: c.execute('INSERT INTO wallet_quotes(ticker,price,observed_at,provider) VALUES(?,?,?,?) ON CONFLICT(ticker) DO UPDATE SET price=excluded.price,observed_at=excluded.observed_at,provider=excluded.provider',(ticker,float(ultimo['preco']),ultimo['observado_em'],'YAHOO_FINANCE_CHART'))
   atualizadas.append({'ticker':ticker,'preco':float(ultimo['preco']),'observado_em':ultimo['observado_em']})
  except Exception as exc: falhas.append({'ticker':ticker,'erro':str(exc)[:180]})
 return {'atualizadas':atualizadas,'falhas':falhas,'carteira':carteira_resumo(),'aviso':'Cotações públicas sujeitas a atraso, indisponibilidade e limites do provedor; não são tempo real garantido.'}

def carteira_lancar(d):
 kind=str(d.get('kind',''));amount=float(d.get('amount',0));qty=float(d.get('quantity') or 0);price=float(d.get('unit_price') or 0);ticker=str(d.get('ticker') or '').upper().strip()[:24]
 if kind not in {'deposito','retirada','compra','venda'}:raise ValueError('Tipo inválido.')
 if kind in ('compra','venda'):
  if not ticker or qty<=0 or price<=0:raise ValueError('Compra/venda exige ticker, quantidade e preço positivos.')
  amount=round(qty*price,2)
 if amount<=0 or amount>1e12:raise ValueError('Valor deve ser positivo e válido.')
 resumo=carteira_resumo()
 if kind in ('retirada','compra') and amount>float(resumo['saldo_caixa'])+1e-9: raise ValueError('Saldo de caixa insuficiente para esta movimentação.')
 if kind=='venda' and qty>float(resumo['posicoes'].get(ticker,{}).get('quantidade',0))+1e-9: raise ValueError('Venda excede a quantidade disponível na carteira.')
 with _conn() as c:c.execute('INSERT INTO wallet_tx(kind,amount,ticker,quantity,unit_price,occurred_at,note,created_at) VALUES(?,?,?,?,?,?,?,?)',(kind,amount,ticker or None,qty or None,price or None,str(d.get('occurred_at') or _now()),str(d.get('note') or '')[:500],_now()))
 return carteira_resumo()
def status():
 from . import live_auto, catalogo
 with _conn() as c:r=c.execute('SELECT kind,started_at,finished_at,ok,detail FROM update_runs ORDER BY id DESC LIMIT 1').fetchone()
 coleta=db.um('SELECT fonte,inicio,status,registros,erro FROM coletas ORDER BY id DESC LIMIT 1')
 return {'ultima_execucao':dict(r) if r else None,'ultima_coleta_dados':coleta,'hora_servidor':_now(),'atualizacao_automatica':live_auto.estado(),'cobertura':catalogo.cobertura('REAL')}
