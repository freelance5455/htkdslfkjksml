"""Agendador leve por modos (econômico/normal/intensivo/experimental). Uma tarefa por vez; reduz carga sob pressão."""
import threading
import time
from datetime import date

from . import autoavaliacao, backtest, catalogo, config, db, live_auto, pesquisa, pipeline, recursos, v9
from .conectores import b3_cotahist, bcb, cvm

_estado = {"rodando": None, "ultimas": {}, "ligado": False}
_parar = threading.Event()
_trava = threading.Lock()
INTERVALOS = {"recalcular": None, "lacunas": 6 * 3600, "propor": 24 * 3600, "coletar_macro": 24 * 3600, "coletar_precos": 24 * 3600, "coletar_cvm": 7 * 86400, "noticias": 15 * 60, "backtest": 7 * 86400}
_ULTIMO_LOG = {}


def _coletar_cvm():
    """Atualiza DFP do último exercício encerrado e ITR do ano corrente usando a API V6.11."""
    ano = date.today().year
    saidas = {}
    for doc, exercicio in (("DFP", ano - 1), ("ITR", ano)):
        try:
            saidas[f"{doc}:{exercicio}"] = cvm.coletar(doc, exercicio)
        except Exception as e:
            db.log("ERRO", "agendador", f"CVM {doc}/{exercicio}: {type(e).__name__}: {e}")
            saidas[f"{doc}:{exercicio}"] = f"erro: {type(e).__name__}"
    return saidas


def _tarefas():
    return {
        "recalcular": lambda: pipeline.recalcular(),
        "lacunas": lambda: {"novas": pesquisa.lacunas()},
        "propor": lambda: {"criadas": autoavaliacao.propor()},
        "backtest": lambda: {k: v for k, v in backtest.executar().items() if k != "periodos"},
        "coletar_macro": lambda: bcb.coletar() if not db.cfg_get("modo_demo", False) else {"pulado": "modo demonstração"},
        "coletar_precos": lambda: b3_cotahist.coletar() if not db.cfg_get("modo_demo", False) else {"pulado": "modo demonstração"},
        "coletar_cvm": lambda: _coletar_cvm() if not db.cfg_get("modo_demo", False) else {"pulado": "modo demonstração"},
        "noticias": lambda: v9.noticias(True) if not db.cfg_get("modo_demo", False) else {"pulado": "modo demonstração"},
    }


def executar(nome):
    """Executa uma tarefa agora (manual ou agendada). Nunca propaga exceções."""
    if not _trava.acquire(blocking=False):
        return {"erro": "outra tarefa em execução"}
    try:
        _estado["rodando"] = nome
        t0 = time.time()
        try:
            r = _tarefas()[nome]()
            _estado["ultimas"][nome] = {"ts": time.time(), "ok": True, "duracao": round(time.time() - t0, 2), "resultado": r}
            persistido = db.cfg_get("agendador_ultimas", {}) or {}
            persistido[nome] = time.time()
            db.cfg_set("agendador_ultimas", persistido)           # reiniciar o programa não repete coletas longas
        except Exception as e:
            db.log("ERRO", "agendador", f"{nome}: {type(e).__name__}: {e}")
            _estado["ultimas"][nome] = {"ts": time.time(), "ok": False, "erro": f"{type(e).__name__}: {e}"}
        return _estado["ultimas"][nome]
    finally:
        _estado["rodando"] = None
        _trava.release()


def _devida(nome):
    modo = recursos.modo_atual()
    pausa = INTERVALOS[nome] or config.MODOS[modo]["pausa"]
    if modo == "economico" and nome in ("coletar_precos", "lacunas"):
        pausa *= 4
    u = _estado["ultimas"].get(nome)
    ts = u["ts"] if u else (db.cfg_get("agendador_ultimas", {}) or {}).get(nome, 0)
    return time.time() - ts >= pausa


def _log_limitado(chave, msg, cada=600):
    """Evita inundar o log com a mesma mensagem (V5 registrava 'sob pressão' a cada minuto)."""
    if time.time() - _ULTIMO_LOG.get(chave, 0) >= cada:
        _ULTIMO_LOG[chave] = time.time()
        db.log("AVISO", "agendador", msg)


def _loop():
    time.sleep(3)
    while not _parar.wait(5):
        if db.cfg_get("agendador_pausado", False):
            continue
        if recursos.sob_pressao():
            _log_limitado("pressao", "sob pressão de recursos: tarefas adiadas (mensagem repetida só a cada 10 min)")
            _parar.wait(60)
            continue
        for nome in ("coletar_macro", "coletar_precos", "coletar_cvm", "noticias", "recalcular", "lacunas", "propor"):
            if _devida(nome):
                executar(nome)
                break


def iniciar():
    if _estado["ligado"]:
        return
    _estado["ligado"] = True
    live_auto.iniciar()                      # LIVE tem fio próprio e só coleta após ativação explícita
    threading.Thread(target=_loop, name="gfi-agendador", daemon=True).start()


def estado():
    return {"ligado": _estado["ligado"], "rodando": _estado["rodando"], "pausado": db.cfg_get("agendador_pausado", False),
            "ultimas": _estado["ultimas"], "modo": recursos.modo_atual()}
