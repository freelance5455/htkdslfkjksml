"""Fila inteligente de pesquisas: prioriza por relevância, urgência, impacto, confiabilidade e custo; evita repetição."""
import time
from datetime import date

from . import catalogo, db

REPETIR_APOS = 7 * 86400


def prioridade(relev=0.5, urg=0.5, imp=0.5, conf=0.5, custo=0.5):
    return round(100 * (0.30 * relev + 0.25 * urg + 0.25 * imp + 0.10 * conf + 0.10 * (1 - custo)), 1)


def enfileirar(chave, titulo, motivo, **pesos):
    ex = db.um("SELECT estado,criado_em FROM fila_pesquisa WHERE chave=?", (chave,))
    if ex and (ex["estado"] in ("pendente", "em_andamento") or time.time() - ex["criado_em"] < REPETIR_APOS):
        return False
    db.executar("INSERT INTO fila_pesquisa(chave,titulo,motivo,prioridade,estado,criado_em) VALUES(?,?,?,?, 'pendente',?) "
                "ON CONFLICT(chave) DO UPDATE SET titulo=excluded.titulo,motivo=excluded.motivo,prioridade=excluded.prioridade,"
                "estado='pendente',criado_em=excluded.criado_em", (chave, titulo, motivo, prioridade(**pesos), time.time()))
    return True


def proximas(n=15):
    return db.consultar("SELECT * FROM fila_pesquisa WHERE estado IN ('pendente','em_andamento') ORDER BY prioridade DESC LIMIT ?", (n,))


def concluir(chave):
    db.executar("UPDATE fila_pesquisa SET estado='concluida' WHERE chave=?", (chave,))


def lacunas(origem=None):
    """Descobre o que a plataforma ainda não sabe e enfileira as pesquisas necessárias."""
    origem, novas = origem or catalogo.origem_ativa(), 0
    cob = catalogo.cobertura(origem)
    if cob["insuficientes"]:
        novas += enfileirar("lacuna:historico", f"Completar histórico/atualização de {cob['insuficientes']} ativo(s)",
                            "ativos com dados insuficientes ou desatualizados reduzem a qualidade do ranking", relev=0.8, urg=0.6, imp=0.7, conf=0.9, custo=0.4)
    sem_setor = db.um("SELECT COUNT(*) n FROM instrumentos WHERE origem=? AND status='ativo' AND (setor IS NULL OR setor='') AND tipo<>'indice'", (origem,))["n"]
    if sem_setor:
        novas += enfileirar("lacuna:setor", f"Classificar setor de {sem_setor} ativo(s)", "sem setor, a relação macro × empresa fica indisponível (sinal cinza)",
                            relev=0.7, urg=0.5, imp=0.7, conf=0.9, custo=0.2)
    sem_fund = db.um("SELECT COUNT(*) n FROM instrumentos i WHERE origem=? AND status='ativo' AND tipo NOT IN ('indice','etf','reit') AND "
                     "NOT EXISTS(SELECT 1 FROM fundamentos f WHERE f.instrumento_id=i.id)", (origem,))["n"]
    if sem_fund:
        novas += enfileirar("lacuna:fundamentos", f"Importar demonstrações financeiras de {sem_fund} empresa(s)",
                            "sem fundamentos, saúde, crescimento e valuation ficam cinza", relev=0.9, urg=0.6, imp=0.9, conf=0.8, custo=0.6)
    fonte = "SIMULADO" if origem == "SIMULADO" else "BCB-SGS"
    ativas = set()
    if cob["insuficientes"]:
        ativas.add("lacuna:historico")
    if sem_setor:
        ativas.add("lacuna:setor")
    if sem_fund:
        ativas.add("lacuna:fundamentos")
    # defasagem aceitável por periodicidade: séries diárias ~10 dias; mensais ~75 dias (divulgação com atraso); trimestrais/PNAD ~130 dias
    tolerancia = {"selic_meta": 10, "dolar_venda": 10, "ipca_mensal": 75, "igpm_mensal": 75, "desemprego": 130, "pib_mensal": 130, "divida_liquida_pib": 130}
    for serie in ("selic_meta", "ipca_mensal", "desemprego"):
        u = db.um("SELECT MAX(data) d FROM macro WHERE serie=? AND fonte=?", (serie, fonte))
        if not u or not u["d"]:
            ativas.add(f"lacuna:macro:{serie}")
            novas += enfileirar(f"lacuna:macro:{serie}", f"Coletar série macroeconômica {serie}", "indicador ausente", relev=0.8, urg=0.7, imp=0.7, conf=0.9, custo=0.1)
        elif (date.today() - date.fromisoformat(u["d"])).days > tolerancia[serie] and origem != "SIMULADO":
            ativas.add(f"lacuna:macro:{serie}:velho")
            novas += enfileirar(f"lacuna:macro:{serie}:velho", f"Atualizar série {serie} (última: {u['d']})", "indicador desatualizado além do atraso normal de divulgação", relev=0.8, urg=0.8, imp=0.7, conf=0.9, custo=0.1)
    # fonte indisponível: só se a ÚLTIMA coleta dela falhou (falha antiga já superada por um sucesso não conta)
    for f in db.consultar("SELECT fonte, erro FROM coletas WHERE id IN (SELECT MAX(id) FROM coletas GROUP BY fonte) AND status='erro' AND inicio>?", (time.time() - 7 * 86400,)):
        ativas.add(f"lacuna:fonte:{f['fonte']}")
        novas += enfileirar(f"lacuna:fonte:{f['fonte']}", f"Fonte indisponível: {f['fonte']}", f"a última coleta falhou: {(f['erro'] or '')[:100]}",
                            relev=0.7, urg=0.8, imp=0.6, conf=0.7, custo=0.2)
    # fecha pesquisas de lacuna que deixaram de existir (ex.: dado coletado depois)
    for p in db.consultar("SELECT chave FROM fila_pesquisa WHERE chave LIKE 'lacuna:%' AND estado IN ('pendente','em_andamento')"):
        if p["chave"] not in ativas:
            concluir(p["chave"])
    return novas
