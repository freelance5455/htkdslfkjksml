"""Atualizações (estilo CLEO): solte uma pasta ou .zip em `atualizacoes/` e ative no painel.

Três tipos, combináveis num mesmo pacote:
  • dados   (CSV)   — setores, fundamentos, eventos e cotações importados para o universo REAL;
  • config  (JSON)  — ajustes de pesos e de sensibilidade macro × setor (reversível);
  • codigo  (Python) — novos indicadores, rankings e conectores de dados, em API restrita.

Segurança: nada roda sem você ativar; qualquer alteração no pacote o desativa até nova aprovação; código passa por
análise estática (sem os/sys/subprocess/open/eval/exec/while) e só acessa a internet pelos hosts declarados no manifesto.
Modo seguro: crie o arquivo `atualizacoes/DESLIGADO` (ou GFI_SEM_ATUALIZACOES=1) para não carregar nada.
"""
import ast
import csv
import hashlib
import importlib.util
import json
import os
import re
import shutil
import time
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

from . import catalogo, config, db

DIR = config.RAIZ / "atualizacoes"
MAX_ARQUIVO = 20_000_000
MAX_LINHAS = 200_000
IMPORTS_OK = {"math", "statistics", "datetime", "json", "csv", "re", "collections", "itertools", "functools", "typing"}
PROIBIDOS = {"exec", "eval", "compile", "open", "__import__", "input", "breakpoint", "globals", "locals", "vars",
             "getattr", "setattr", "delattr", "exit", "quit"}
CAMPOS_FUND = {"receita", "lucro_liquido", "ebitda", "ebit", "divida_liquida", "fcf", "patrimonio", "acoes", "dividendos_por_acao", "governanca"}
CATEGORIAS = {"noticia", "regulatorio", "geopolitico"}
_SLUG = re.compile(r"^[a-z0-9][a-z0-9_-]{2,39}$")

INDICADORES, CONECTORES, _REG = {}, {}, {}      # hooks registrados por pacotes ativos


def modo_seguro():
    return os.environ.get("GFI_SEM_ATUALIZACOES") == "1" or (DIR / "DESLIGADO").exists()


# ------------------------------------------------------------------ descoberta
def _extrair_zips():
    destino = DIR / "_extraidos"
    for z in sorted(DIR.glob("*.zip")):
        alvo = destino / z.stem
        if alvo.exists():
            continue
        try:
            with zipfile.ZipFile(z) as zf:
                total = 0
                for info in zf.infolist():
                    total += info.file_size
                    nome = os.path.normpath(info.filename)
                    if nome.startswith("..") or os.path.isabs(nome) or total > 5 * MAX_ARQUIVO:
                        raise ValueError("zip inseguro (caminho ou tamanho)")
                alvo.mkdir(parents=True)
                zf.extractall(alvo)
            filhos = [p for p in alvo.iterdir()]
            if len(filhos) == 1 and filhos[0].is_dir() and not (alvo / "atualizacao.json").exists():
                for item in filhos[0].iterdir():          # zip com pasta única: sobe um nível
                    shutil.move(str(item), alvo)
                filhos[0].rmdir()
        except Exception as e:
            shutil.rmtree(alvo, ignore_errors=True)
            db.log("ERRO", "atualizacoes", f"{z.name}: {type(e).__name__}: {e}")


def _hash(pasta):
    h = hashlib.sha256()
    for p in sorted(pasta.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts:
            h.update(str(p.relative_to(pasta)).encode())
            h.update(p.read_bytes())
    return h.hexdigest()


def validar_codigo(texto):
    erros = []
    try:
        arvore = ast.parse(texto)
    except SyntaxError as e:
        return [f"sintaxe inválida (linha {e.lineno})"]
    for no in ast.walk(arvore):
        if isinstance(no, ast.Import):
            erros += [f"import proibido: {a.name}" for a in no.names if a.name.split(".")[0] not in IMPORTS_OK]
        elif isinstance(no, ast.ImportFrom):
            if no.level or (no.module or "").split(".")[0] not in IMPORTS_OK:
                erros.append(f"import proibido: {no.module or '.'}")
        elif isinstance(no, ast.Name) and (no.id in PROIBIDOS or (no.id.startswith("__") and no.id != "__name__")):
            erros.append(f"nome proibido: {no.id}")
        elif isinstance(no, ast.Attribute) and no.attr.startswith("__"):
            erros.append(f"atributo proibido: {no.attr}")
        elif isinstance(no, (ast.While, ast.Global, ast.Nonlocal, ast.AsyncFunctionDef, ast.Await)):
            erros.append(f"construção proibida: {type(no).__name__} (linha {no.lineno})")
    if not any(isinstance(n, ast.FunctionDef) and n.name == "registrar" for n in arvore.body):
        erros.append("falta a função registrar(api)")
    return sorted(set(erros))


def _ler_pacote(pasta):
    pk = {"caminho": str(pasta), "pasta": pasta.name, "erros": [], "tipos": [], "manifesto": {}}
    try:
        m = json.loads((pasta / "atualizacao.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pk["erros"].append("atualizacao.json ausente ou inválido")
        pk["id"] = pasta.name
        return pk
    pk["manifesto"] = m
    pk["id"] = str(m.get("id", ""))
    if not _SLUG.match(pk["id"]):
        pk["erros"].append("id inválido (use a-z, 0-9, - ou _; 3 a 40 caracteres)")
    if not m.get("nome") or not m.get("versao"):
        pk["erros"].append("nome e versao são obrigatórios")
    for f in pasta.rglob("*"):
        if f.is_file() and f.stat().st_size > MAX_ARQUIVO:
            pk["erros"].append(f"arquivo grande demais: {f.name}")
    if (pasta / "dados").is_dir() and any((pasta / "dados").glob("*.csv")):
        pk["tipos"].append("dados")
    if (pasta / "config.json").is_file():
        pk["tipos"].append("config")
    if (pasta / "codigo.py").is_file():
        pk["tipos"].append("codigo")
        pk["erros"] += validar_codigo((pasta / "codigo.py").read_text(encoding="utf-8", errors="replace"))
    if not pk["tipos"]:
        pk["erros"].append("pacote vazio (precisa de dados/*.csv, config.json ou codigo.py)")
    pk["hash"] = _hash(pasta)
    return pk


def listar():
    DIR.mkdir(exist_ok=True)
    _extrair_zips()
    pastas = [p for p in sorted(DIR.iterdir()) if p.is_dir() and not p.name.startswith((".", "_"))]
    if (DIR / "_extraidos").is_dir():
        pastas += [p for p in sorted((DIR / "_extraidos").iterdir()) if p.is_dir()]
    est, out, vistos = db.cfg_get("atualizacoes", {}), [], set()
    for p in pastas:
        pk = _ler_pacote(p)
        if pk["id"] in vistos:
            pk["erros"].append("id duplicado em outra pasta")
        vistos.add(pk["id"])
        e = est.get(pk["id"], {})
        pk["estado"] = ("erro" if pk["erros"] else "nova" if not e else "ativa" if e.get("ativa") and e.get("hash") == pk.get("hash")
                        else "alterada" if e.get("ativa") else "desativada")
        pk["ativada_em"] = e.get("ativada_em")
        out.append(pk)
    return out


# ------------------------------------------------------------------ importação de dados
def _csv(pasta, nome):
    f = pasta / "dados" / nome
    if not f.is_file():
        return []
    with open(f, encoding="utf-8-sig", newline="") as fh:
        linhas = [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(fh)]
    if len(linhas) > MAX_LINHAS:
        raise ValueError(f"{nome}: mais de {MAX_LINHAS} linhas")
    return linhas


def _num(x):
    return float(str(x).replace(",", "."))


def _importar_dados(pk):
    pasta, pid, agora, r = Path(pk["caminho"]), pk["id"], time.time(), {}
    ids = {i["ticker"]: i["id"] for i in db.consultar("SELECT id,ticker FROM instrumentos WHERE origem='REAL'")}
    rows = _csv(pasta, "setores.csv")
    ok = [(x["setor"], x["ticker"].upper()) for x in rows if x.get("setor") in config.SETORES_B3 and x.get("ticker", "").upper() in ids]
    db.muitos("UPDATE instrumentos SET setor=? WHERE ticker=? AND origem='REAL'", ok)
    r["setores"] = {"aplicados": len(ok), "ignorados": len(rows) - len(ok)}
    lote, ign = [], 0
    for x in _csv(pasta, "fundamentos.csv"):
        try:
            if x["campo"] in CAMPOS_FUND and x["ticker"].upper() in ids:
                lote.append((ids[x["ticker"].upper()], x["periodo"], x["campo"], _num(x["valor"]), f"ATU:{pid}", f"ATU:{pid}", agora))
            else:
                ign += 1
        except (KeyError, ValueError):
            ign += 1
    db.muitos("INSERT OR REPLACE INTO fundamentos VALUES(?,?,?,?,?,?,?)", lote)
    r["fundamentos"] = {"aplicados": len(lote), "ignorados": ign}
    lote, ign = [], 0
    for x in _csv(pasta, "eventos.csv"):
        try:
            iid = ids.get(x.get("ticker", "").upper()) if x.get("ticker") else None
            sev, imp = int(x["severidade"]), int(x["impacto"])
            if x["categoria"] in CATEGORIAS and 1 <= sev <= 5 and -2 <= imp <= 2 and (iid or x.get("setor") or x.get("pais")):
                lote.append((iid, x.get("setor") or None, x.get("pais") or None, x["categoria"], x.get("tipo") or "geral", sev, imp, x["titulo"][:200],
                             x.get("fonte") or pid, x["publicado_em"][:10], agora, x.get("confiabilidade") or "media", "REAL", pid))
            else:
                ign += 1
        except (KeyError, ValueError):
            ign += 1
    db.muitos("INSERT INTO eventos(instrumento_id,setor,pais,categoria,tipo,severidade,impacto,titulo,fonte,publicado_em,coletado_em,"
              "confiabilidade,origem,pacote) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", lote)
    r["eventos"] = {"aplicados": len(lote), "ignorados": ign}
    lote, ign, novos = [], 0, 0
    for x in _csv(pasta, "cotacoes.csv"):
        try:
            tk, mic = x["ticker"].upper(), (x.get("mic") or "BVMF").upper()
            if tk not in ids:
                ids[tk] = catalogo.upsert(tk, mic, "REAL", moeda=x.get("moeda") or "BRL", pais=x.get("pais") or "BR", nome=x.get("nome") or tk, tipo=x.get("tipo") or None)
                novos += 1
            o, h, l, c = (_num(x[k]) for k in ("abertura", "maximo", "minimo", "fechamento"))
            if min(o, h, l, c) <= 0 or h < l:
                raise ValueError
            lote.append((ids[tk], x["data"][:10], o, h, l, c, _num(x.get("volume") or 0), _num(x.get("qtd") or 0), f"ATU:{pid}", agora))
        except (KeyError, ValueError):
            ign += 1
    db.muitos("INSERT OR REPLACE INTO cotacoes VALUES(?,?,?,?,?,?,?,?,?,?)", lote)
    r["cotacoes"] = {"aplicados": len(lote), "ignorados": ign, "novos_instrumentos": novos}
    return r


# ------------------------------------------------------------------ API restrita para código
class ApiAtualizacao:
    """Único objeto que o código de uma atualização recebe. Sem acesso ao banco, a arquivos ou ao sistema."""

    def __init__(self, pk):
        self._id, self._hosts = pk["id"], set(pk["manifesto"].get("rede", []))
        self._reg = _REG.setdefault(pk["id"], {"indicadores": [], "rankings": [], "conectores": []})

    def indicador(self, nome, funcao):
        """funcao(candles) -> número ou None. candles = [(data, abertura, maxima, minima, fechamento, volume, qtd)]."""
        chave = f"{self._id}:{nome}"
        INDICADORES[chave] = (nome, funcao)
        self._reg["indicadores"].append(chave)

    def ranking(self, chave, titulo, valor, por_que):
        """valor(resultado) -> número ou None (maior = melhor); por_que(resultado) -> texto."""
        from . import oportunidades
        k = f"x_{self._id}_{chave}"
        oportunidades.RANKINGS[k] = (f"[{self._id}] {titulo}", _seguro(valor), _seguro(por_que, ""))
        self._reg["rankings"].append(k)

    def conector(self, nome, funcao):
        """funcao(api) -> dict com o resumo da coleta; roda quando você pede (ou pelo agendador)."""
        chave = f"{self._id}:{nome}"
        CONECTORES[chave] = (self, funcao)
        self._reg["conectores"].append(chave)

    def baixar(self, url):
        p = urlsplit(url)
        if p.scheme != "https" or p.hostname not in self._hosts:
            raise PermissionError(f"host não declarado em 'rede' no manifesto: {p.hostname}")
        from .conectores import base
        return base.baixar(url)

    def gravar_cotacoes(self, linhas):
        """linhas: [(ticker, 'AAAA-MM-DD', abertura, maxima, minima, fechamento, volume_fin, qtd)] → universo REAL."""
        agora, n = time.time(), 0
        ids = {}
        lote = []
        for tk, d, o, h, l, c, v, q in linhas[:MAX_LINHAS]:
            if tk not in ids:
                ids[tk] = catalogo.upsert(tk, "BVMF", "REAL", moeda="BRL", pais="BR")
            if min(o, h, l, c) > 0 and h >= l:
                lote.append((ids[tk], d, o, h, l, c, v, q, f"ATU:{self._id}", agora))
        db.muitos("INSERT OR REPLACE INTO cotacoes VALUES(?,?,?,?,?,?,?,?,?,?)", lote)
        return len(lote)

    def gravar_macro(self, serie, pontos):
        agora = time.time()
        db.muitos("INSERT OR REPLACE INTO macro(serie,data,valor,fonte,publicado_em,coletado_em,estado) VALUES(?,?,?,?,?,?,'ok')",
                  [(serie, d, float(v), f"ATU:{self._id}", d, agora) for d, v in pontos[:MAX_LINHAS]])
        return len(pontos)

    def log(self, msg):
        db.log("INFO", f"atualizacao:{self._id}", msg)


def _seguro(fn, padrao=None):
    def f(*a):
        try:
            return fn(*a)
        except Exception:
            return padrao
    return f


def _carregar_codigo(pk):
    texto = (Path(pk["caminho"]) / "codigo.py").read_text(encoding="utf-8")
    if validar_codigo(texto):
        raise ValueError("código reprovado na análise estática")
    spec = importlib.util.spec_from_file_location(f"gfi_atu_{pk['id'].replace('-', '_')}", Path(pk["caminho"]) / "codigo.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.registrar(ApiAtualizacao(pk))


def _descarregar(pid):
    reg = _REG.pop(pid, {})
    for k in reg.get("indicadores", []):
        INDICADORES.pop(k, None)
    for k in reg.get("conectores", []):
        CONECTORES.pop(k, None)
    from . import oportunidades
    for k in reg.get("rankings", []):
        oportunidades.RANKINGS.pop(k, None)


# ------------------------------------------------------------------ ativar / desativar
def _pacote(pid):
    for pk in listar():
        if pk["id"] == pid:
            return pk
    raise ValueError("atualização não encontrada")


def ativar(pid, confirmo=False):
    if not confirmo:
        raise PermissionError("ativação exige confirmação explícita do usuário")
    if modo_seguro():
        raise PermissionError("modo seguro ligado (arquivo atualizacoes/DESLIGADO ou GFI_SEM_ATUALIZACOES=1)")
    pk = _pacote(pid)
    if pk["erros"]:
        raise ValueError("pacote com erros: " + "; ".join(pk["erros"][:3]))
    resumo = {}
    if "dados" in pk["tipos"]:
        resumo["dados"] = _importar_dados(pk)
    est = db.cfg_get("atualizacoes", {})
    anterior = est.get(pid, {})
    novo = {"ativa": True, "hash": pk["hash"], "ativada_em": time.time(), "backup_pesos": anterior.get("backup_pesos")}
    if "config" in pk["tipos"]:
        cfg = json.loads((Path(pk["caminho"]) / "config.json").read_text(encoding="utf-8"))
        extra = {k: v for k, v in (cfg.get("pesos") or {}).items() if k in config.DIMENSOES and isinstance(v, (int, float)) and v >= 0}
        if extra:
            novo["backup_pesos"] = db.cfg_get("pesos", {})
            db.cfg_set("pesos", {**db.cfg_get("pesos", {}), **extra})
            resumo["pesos"] = extra
        sens = {f: {s: int(v) for s, v in d.items() if s in config.SETORES_B3 and -2 <= int(v) <= 2}
                for f, d in (cfg.get("sensibilidade") or {}).items() if f in config.SENSIBILIDADE}
        if sens:
            for f, d in sens.items():
                config.SENSIBILIDADE[f].update(d)
            resumo["sensibilidade"] = sens
    if "codigo" in pk["tipos"]:
        _descarregar(pid)
        _carregar_codigo(pk)
        resumo["codigo"] = {k: len(v) for k, v in _REG.get(pid, {}).items()}
    est[pid] = novo
    db.cfg_set("atualizacoes", est)
    db.log("INFO", "atualizacoes", f"ativada: {pid} {resumo}")
    return {"id": pid, "resumo": resumo}


def desativar(pid, remover_dados=False):
    est = db.cfg_get("atualizacoes", {})
    if pid not in est:
        raise ValueError("atualização não está ativa")
    _descarregar(pid)
    e = est[pid]
    if e.get("backup_pesos") is not None:
        db.cfg_set("pesos", e["backup_pesos"])
    if remover_dados:
        db.executar("DELETE FROM fundamentos WHERE origem=?", (f"ATU:{pid}",))
        db.executar("DELETE FROM cotacoes WHERE origem=?", (f"ATU:{pid}",))
        db.executar("DELETE FROM eventos WHERE pacote=?", (pid,))
    est[pid] = {**e, "ativa": False}
    db.cfg_set("atualizacoes", est)
    db.log("INFO", "atualizacoes", f"desativada: {pid} (dados removidos: {remover_dados})")
    return {"id": pid, "dados_removidos": remover_dados}


def carregar_ativas():
    """Chamado ao iniciar: recarrega só pacotes ativos E inalterados. Falha de um pacote não afeta os demais."""
    if modo_seguro():
        db.log("AVISO", "atualizacoes", "modo seguro: nenhuma atualização carregada")
        return {"modo_seguro": True, "carregadas": []}
    ok = []
    for pk in listar():
        if pk["estado"] == "ativa" and "codigo" in pk["tipos"]:
            try:
                _carregar_codigo(pk)
                ok.append(pk["id"])
            except Exception as e:
                db.log("ERRO", "atualizacoes", f"{pk['id']}: {type(e).__name__}: {e}")
        elif pk["estado"] == "alterada":
            db.log("AVISO", "atualizacoes", f"{pk['id']} foi alterada: reative para aprovar a nova versão")
    return {"modo_seguro": False, "carregadas": ok}


def executar_indicadores(candles):
    out = {}
    for chave, (nome, fn) in list(INDICADORES.items()):
        try:
            v = fn(candles)
            if isinstance(v, (int, float)) and v == v:
                out[nome] = round(float(v), 6)
        except Exception:
            continue
    return out


def executar_conector(chave):
    if chave not in CONECTORES:
        raise ValueError("conector não encontrado ou atualização inativa")
    api, fn = CONECTORES[chave]
    t0 = time.time()
    try:
        r = fn(api)
        db.executar("INSERT INTO coletas(fonte,inicio,fim,status,registros,erro) VALUES(?,?,?,?,?,?)", (f"ATU:{chave}", t0, time.time(), "ok", 0, ""))
        return r if isinstance(r, dict) else {"resultado": str(r)[:200]}
    except Exception as e:
        db.executar("INSERT INTO coletas(fonte,inicio,fim,status,registros,erro) VALUES(?,?,?,?,?,?)", (f"ATU:{chave}", t0, time.time(), "erro", 0, f"{type(e).__name__}: {e}"[:300]))
        raise
