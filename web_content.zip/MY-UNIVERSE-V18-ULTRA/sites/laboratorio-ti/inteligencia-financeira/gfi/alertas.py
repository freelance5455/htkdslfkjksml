"""Alertas sem repetição: só disparam quando há mudança relevante e respeitam cooldown e nível mínimo."""
import json
import time

from . import config, db

NIVEIS = {"info": 0, "atencao": 1, "critico": 2}


def _cfg():
    return {"nivel_min": db.cfg_get("alerta_nivel_min", "atencao"), "cooldown_dias": db.cfg_get("alerta_cooldown_dias", 7),
            "delta_indice": db.cfg_get("alerta_delta_indice", 10)}


def emitir(inst_id, tipo, nivel, mensagem, chave_extra=""):
    c = _cfg()
    if NIVEIS[nivel] < NIVEIS.get(c["nivel_min"], 1):
        return False
    chave = f"{inst_id}:{tipo}:{chave_extra}"
    rec = db.um("SELECT criado_em FROM alertas WHERE chave=? ORDER BY id DESC LIMIT 1", (chave,))
    if rec and time.time() - rec["criado_em"] < c["cooldown_dias"] * 86400:
        return False
    db.executar("INSERT INTO alertas(instrumento_id,tipo,nivel,mensagem,criado_em,chave) VALUES(?,?,?,?,?,?)",
                (inst_id, tipo, nivel, mensagem, time.time(), chave))
    return True


def comparar(inst, ant, novo, ref):
    """Compara a pontuação anterior com a nova e emite alertas relevantes."""
    velho = json.loads(ant["detalhe"])
    t = inst["ticker"]
    if novo["bloqueado"] and not ant["bloqueado"]:
        emitir(inst["id"], "bloqueio", "critico", f"{t}: bloqueio por evento/risco grave — " + "; ".join(novo["bloqueios"][:2]))
    if novo["indice"] is not None and ant["indice"] is not None:
        d = novo["indice"] - ant["indice"]
        lim = _cfg()["delta_indice"]
        if abs(d) >= lim:
            emitir(inst["id"], "pontuacao", "critico" if abs(d) >= 2 * lim else "atencao",
                   f"{t}: índice {'subiu' if d > 0 else 'caiu'} {abs(d):.0f} pontos ({ant['indice']:.0f} → {novo['indice']:.0f})",
                   "alta" if d > 0 else "baixa")
    vo, vn = velho["dimensoes"]["tecnica"]["score"], novo["dimensoes"]["tecnica"]["score"]
    if vo is not None and vn is not None and (vo >= 50) != (vn >= 50):
        emitir(inst["id"], "tendencia", "atencao", f"{t}: mudança de tendência técnica ({vo:.0f} → {vn:.0f})", "pos" if vn >= 50 else "neg")
    v0, v1 = velho["metricas"].get("vol_anual"), novo["metricas"].get("vol_anual")
    if v0 and v1 and v1 > v0 * 1.5:
        emitir(inst["id"], "volatilidade", "atencao", f"{t}: volatilidade subiu {((v1 / v0) - 1) * 100:.0f}%")
    l1 = novo["dimensoes"]["liquidez"]["score"]
    if l1 is not None and l1 < 25 and (velho["dimensoes"]["liquidez"]["score"] or 100) >= 25:
        emitir(inst["id"], "liquidez", "critico", f"{t}: risco de liquidez")
    if velho["metricas"].get("veredito") != novo["metricas"].get("veredito") and "impossivel" not in (velho["metricas"].get("veredito"), novo["metricas"].get("veredito")):
        emitir(inst["id"], "valuation", "atencao", f"{t}: valuation mudou de {velho['metricas']['veredito']} para {novo['metricas']['veredito']}", novo["metricas"]["veredito"])
    if novo["dimensoes"]["saude"]["score"] is not None and velho["dimensoes"]["saude"]["score"] is not None and \
            novo["dimensoes"]["saude"]["score"] < 40 <= velho["dimensoes"]["saude"]["score"]:
        emitir(inst["id"], "deterioracao", "critico", f"{t}: deterioração financeira")


def listar(limite=60, so_nao_lidos=False):
    sql = ("SELECT a.*, i.ticker FROM alertas a LEFT JOIN instrumentos i ON i.id=a.instrumento_id"
           + (" WHERE a.lido=0" if so_nao_lidos else "") + " ORDER BY a.id DESC LIMIT ?")
    return db.consultar(sql, (limite,))
