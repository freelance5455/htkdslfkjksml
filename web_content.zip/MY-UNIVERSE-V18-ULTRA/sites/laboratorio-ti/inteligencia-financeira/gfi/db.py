"""Banco SQLite (WAL) com histórico imutável para previsões e avaliações."""
import json
import sqlite3
import threading
import time

from . import config

_LOCK = threading.RLock()
_PRONTOS = set()


class _Conexao(sqlite3.Connection):
    """Connection cujo context manager também libera o recurso ao terminar."""
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type, exc, tb)
        finally:
            self.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS instrumentos(
  id INTEGER PRIMARY KEY, ticker TEXT NOT NULL, mic TEXT NOT NULL, isin TEXT, moeda TEXT, pais TEXT,
  setor TEXT, nome TEXT, tipo TEXT, status TEXT DEFAULT 'ativo', origem TEXT NOT NULL,
  criado_em REAL, atualizado_em REAL, UNIQUE(ticker, mic));
CREATE INDEX IF NOT EXISTS ix_inst_isin ON instrumentos(isin);
CREATE INDEX IF NOT EXISTS ix_inst_origem ON instrumentos(origem, status);
CREATE TABLE IF NOT EXISTS cotacoes(
  instrumento_id INTEGER, data TEXT, abertura REAL, maximo REAL, minimo REAL, fechamento REAL,
  volume_fin REAL, qtd REAL, origem TEXT, coletado_em REAL, PRIMARY KEY(instrumento_id, data));
CREATE TABLE IF NOT EXISTS cotacoes_intradiarias(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instrumento_id INTEGER NOT NULL,
  provedor TEXT NOT NULL,
  observado_em TEXT NOT NULL,
  coletado_em REAL NOT NULL,
  preco REAL NOT NULL,
  volume REAL,
  estado TEXT NOT NULL CHECK(estado IN ('REALTIME','DELAYED','HISTORICAL','STALE','UNAVAILABLE')),
  UNIQUE(instrumento_id, provedor, observado_em));
CREATE INDEX IF NOT EXISTS ix_intraday_inst_time
  ON cotacoes_intradiarias(instrumento_id, observado_em DESC);
CREATE INDEX IF NOT EXISTS ix_intraday_collected
  ON cotacoes_intradiarias(coletado_em DESC);
CREATE TABLE IF NOT EXISTS cotacoes_provedor_diarias(
  instrumento_id INTEGER NOT NULL,
  provedor TEXT NOT NULL,
  data TEXT NOT NULL,
  abertura REAL NOT NULL,
  maximo REAL NOT NULL,
  minimo REAL NOT NULL,
  fechamento REAL NOT NULL,
  volume REAL,
  estado TEXT NOT NULL CHECK(estado IN ('DELAYED','HISTORICAL','STALE','UNAVAILABLE')),
  coletado_em REAL NOT NULL,
  PRIMARY KEY(instrumento_id, provedor, data)
);
CREATE INDEX IF NOT EXISTS ix_provedor_diario_inst_data
  ON cotacoes_provedor_diarias(instrumento_id, data DESC);
CREATE TABLE IF NOT EXISTS macro(
  serie TEXT, data TEXT, valor REAL, fonte TEXT, publicado_em TEXT, coletado_em REAL, estado TEXT DEFAULT 'ok',
  PRIMARY KEY(serie, data, fonte));
CREATE TABLE IF NOT EXISTS fundamentos(
  instrumento_id INTEGER, periodo TEXT, campo TEXT, valor REAL, fonte TEXT, origem TEXT, coletado_em REAL,
  PRIMARY KEY(instrumento_id, periodo, campo));
CREATE TABLE IF NOT EXISTS eventos(
  id INTEGER PRIMARY KEY, instrumento_id INTEGER, setor TEXT, pais TEXT, categoria TEXT, tipo TEXT,
  severidade INTEGER, impacto INTEGER, titulo TEXT, fonte TEXT, publicado_em TEXT, coletado_em REAL,
  confiabilidade TEXT, origem TEXT, pacote TEXT);
CREATE TABLE IF NOT EXISTS pontuacoes(
  instrumento_id INTEGER, data TEXT, indice REAL, bloqueado INTEGER, qualidade REAL, detalhe TEXT,
  calculado_em REAL, PRIMARY KEY(instrumento_id, data));
CREATE TABLE IF NOT EXISTS previsoes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, instrumento_id INTEGER, criado_em REAL, data_base TEXT,
  horizonte_dias INTEGER, direcao TEXT, base_preco REAL, versao_modelo TEXT, payload TEXT,
  hash_ant TEXT, hash TEXT);
CREATE TABLE IF NOT EXISTS avaliacoes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, previsao_id INTEGER UNIQUE, avaliado_em REAL, preco_final REAL,
  retorno REAL, acertou INTEGER, detalhe TEXT);
CREATE TABLE IF NOT EXISTS propostas(
  id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT, descricao TEXT, origem TEXT, estado TEXT,
  arquivos TEXT, resultado_testes TEXT, aprovado_por TEXT, criado_em REAL, atualizado_em REAL, historico TEXT);
CREATE TABLE IF NOT EXISTS fila_pesquisa(
  chave TEXT PRIMARY KEY, titulo TEXT, motivo TEXT, prioridade REAL, estado TEXT DEFAULT 'pendente', criado_em REAL);
CREATE TABLE IF NOT EXISTS alertas(
  id INTEGER PRIMARY KEY, instrumento_id INTEGER, tipo TEXT, nivel TEXT, mensagem TEXT, criado_em REAL,
  lido INTEGER DEFAULT 0, chave TEXT);
CREATE TABLE IF NOT EXISTS coletas(
  id INTEGER PRIMARY KEY, fonte TEXT, inicio REAL, fim REAL, status TEXT, registros INTEGER, erro TEXT);
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, ts REAL, nivel TEXT, modulo TEXT, msg TEXT);
CREATE TABLE IF NOT EXISTS demo_futuro(
  instrumento_id INTEGER, data TEXT, abertura REAL, maximo REAL, minimo REAL, fechamento REAL,
  volume_fin REAL, qtd REAL, PRIMARY KEY(instrumento_id, data));
CREATE TABLE IF NOT EXISTS config(chave TEXT PRIMARY KEY, valor TEXT);
CREATE TRIGGER IF NOT EXISTS previsoes_sem_update BEFORE UPDATE ON previsoes
  BEGIN SELECT RAISE(ABORT, 'previsoes são imutáveis'); END;
CREATE TRIGGER IF NOT EXISTS previsoes_sem_delete BEFORE DELETE ON previsoes
  BEGIN SELECT RAISE(ABORT, 'previsoes são imutáveis'); END;
CREATE TRIGGER IF NOT EXISTS avaliacoes_sem_update BEFORE UPDATE ON avaliacoes
  BEGIN SELECT RAISE(ABORT, 'avaliações são imutáveis'); END;
CREATE TRIGGER IF NOT EXISTS avaliacoes_sem_delete BEFORE DELETE ON avaliacoes
  BEGIN SELECT RAISE(ABORT, 'avaliações são imutáveis'); END;
"""


def conectar():
    config.DADOS.mkdir(parents=True, exist_ok=True)
    caminho = str(config.DADOS / "gfi.db")
    con = sqlite3.connect(caminho, timeout=15, factory=_Conexao)
    con.row_factory = sqlite3.Row
    if caminho not in _PRONTOS:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(SCHEMA)
        _PRONTOS.add(caminho)
    return con


def _usar_conexao():
    """Contexto transacional que também fecha a conexão SQLite ao sair.

    sqlite3.Connection.__exit__ faz commit/rollback, mas NÃO fecha a conexão.
    Sem este finally, cada consulta deixava um descritor/conexão aberto.
    """
    from contextlib import contextmanager

    @contextmanager
    def _contexto():
        con = conectar()
        try:
            with con:
                yield con
        finally:
            con.close()

    return _contexto()


def executar(sql, args=()):
    with _LOCK, _usar_conexao() as con:
        return con.execute(sql, args).lastrowid


def muitos(sql, linhas):
    with _LOCK, _usar_conexao() as con:
        con.executemany(sql, linhas)


def consultar(sql, args=()):
    with _LOCK, _usar_conexao() as con:
        return [dict(r) for r in con.execute(sql, args).fetchall()]


def um(sql, args=()):
    r = consultar(sql, args)
    return r[0] if r else None


def cfg_get(chave, padrao=None):
    r = um("SELECT valor FROM config WHERE chave=?", (chave,))
    return json.loads(r["valor"]) if r else padrao


def cfg_set(chave, valor):
    executar("INSERT INTO config(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",
             (chave, json.dumps(valor)))


def log(nivel, modulo, msg):
    executar("INSERT INTO logs(ts,nivel,modulo,msg) VALUES(?,?,?,?)", (time.time(), nivel, modulo, str(msg)[:800]))
