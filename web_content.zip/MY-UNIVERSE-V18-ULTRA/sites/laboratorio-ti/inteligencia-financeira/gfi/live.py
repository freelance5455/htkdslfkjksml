"""Camada inicial de armazenamento intradiário; não busca nem simula cotações.

Recebe snapshots já obtidos por um provedor externo e preserva horário de
observação, horário de coleta, provedor e classificação de atualidade.
"""
from datetime import datetime, timezone
import math
import time

from . import db

ESTADOS = {"REALTIME", "DELAYED", "HISTORICAL", "STALE", "UNAVAILABLE"}


def _iso_utc(valor):
    if isinstance(valor, datetime):
        dt = valor
    elif isinstance(valor, str):
        dt = datetime.fromisoformat(valor.replace("Z", "+00:00"))
    else:
        raise ValueError("observado_em deve ser datetime ou ISO-8601")
    if dt.tzinfo is None:
        raise ValueError("observado_em precisa conter fuso horário")
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def registrar(instrumento_id, provedor, observado_em, preco, volume=None,
              estado="HISTORICAL", coletado_em=None):
    """Persiste um snapshot real recebido; duplicatas idênticas são ignoradas."""
    if not isinstance(instrumento_id, int) or instrumento_id <= 0:
        raise ValueError("instrumento_id inválido")
    if not isinstance(provedor, str) or not provedor.strip():
        raise ValueError("provedor obrigatório")
    preco = float(preco)
    if not math.isfinite(preco) or preco <= 0:
        raise ValueError("preço precisa ser finito e maior que zero")
    if volume is not None:
        volume = float(volume)
        if not math.isfinite(volume) or volume < 0:
            raise ValueError("volume precisa ser finito e não negativo")
    estado = str(estado).upper()
    if estado not in ESTADOS:
        raise ValueError("estado de cotação inválido")
    observado = _iso_utc(observado_em)
    coletado = float(coletado_em if coletado_em is not None else time.time())
    if not math.isfinite(coletado) or coletado <= 0:
        raise ValueError("coletado_em inválido")
    db.executar(
        "INSERT OR IGNORE INTO cotacoes_intradiarias "
        "(instrumento_id,provedor,observado_em,coletado_em,preco,volume,estado) "
        "VALUES(?,?,?,?,?,?,?)",
        (instrumento_id, provedor.strip(), observado, coletado, preco, volume, estado),
    )
    return db.um(
        "SELECT * FROM cotacoes_intradiarias WHERE instrumento_id=? AND provedor=? AND observado_em=?",
        (instrumento_id, provedor.strip(), observado),
    )


def ultimas(instrumento_id, limite=100):
    """Retorna snapshots mais recentes por horário de observação."""
    limite = max(1, min(int(limite), 5000))
    return db.consultar(
        "SELECT * FROM cotacoes_intradiarias WHERE instrumento_id=? "
        "ORDER BY observado_em DESC, id DESC LIMIT ?", (instrumento_id, limite)
    )


def resumo(instrumento_id):
    """Metadados de cobertura e atualidade, sem inferir que o feed está ao vivo."""
    return db.um(
        "SELECT COUNT(*) AS registros, MAX(observado_em) AS ultima_observacao, "
        "MAX(coletado_em) AS ultima_coleta FROM cotacoes_intradiarias WHERE instrumento_id=?",
        (instrumento_id,),
    ) or {"registros": 0, "ultima_observacao": None, "ultima_coleta": None}
