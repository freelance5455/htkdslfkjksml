"""Controle de acesso do servidor.

Padrão: escuta só em 127.0.0.1 (este computador) e não pede login.
Modo rede (GFI_HOST=0.0.0.0 ou ./iniciar.sh --rede): qualquer cliente que NÃO seja o próprio computador precisa de um TOKEN
(gerado na primeira execução em dados/token.txt, ou definido em GFI_TOKEN). A API altera configuração, executa coletas e ativa
atualizações; por isso nunca deve ficar aberta na rede sem token.
"""
import hmac
import ipaddress
import os
import secrets
from http.cookies import SimpleCookie

from . import config

COOKIE = "gfi_token"


def token():
    t = os.environ.get("GFI_TOKEN", "").strip()
    if t:
        return t
    arq = config.DADOS / "token.txt"
    try:
        return arq.read_text().strip()
    except OSError:
        config.DADOS.mkdir(parents=True, exist_ok=True)
        t = secrets.token_urlsafe(24)
        arq.write_text(t)
        try:
            arq.chmod(0o600)
        except OSError:
            pass
        return t


def cliente_local(ip):
    try:
        return ipaddress.ip_address(ip.split("%")[0]).is_loopback
    except ValueError:
        return False


def host_permitido(cabecalho):
    """Aceita o cabeçalho Host se for localhost ou um IP literal local/privado, na porta do servidor.
    (Um domínio qualquer — técnica de DNS rebinding — nunca é aceito; IPs literais não permitem esse ataque.)"""
    cab = (cabecalho or "").strip().lower()
    if cab in {f"{h.lower()}:{config.PORTA}" for h in config.HOSTS_EXTRAS}:
        return True
    if cab.startswith("["):                                    # IPv6 literal: [::1]:8780
        host, _, porta = cab[1:].partition("]:")
    else:
        host, _, porta = cab.rpartition(":")
    if not host or porta != str(config.PORTA):
        return False
    if host == "localhost":
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_loopback or ip.is_private
    except ValueError:
        return False


def token_valido(candidato):
    return bool(candidato) and hmac.compare_digest(str(candidato), token())


def token_do_cookie(cabecalho_cookie):
    c = SimpleCookie()
    try:
        c.load(cabecalho_cookie or "")
    except Exception:
        return None
    return c[COOKIE].value if COOKIE in c else None


def autorizado(ip_cliente, cabecalho_cookie):
    """True para o próprio computador; para a rede, só com o cookie do token."""
    return cliente_local(ip_cliente) or token_valido(token_do_cookie(cabecalho_cookie))
