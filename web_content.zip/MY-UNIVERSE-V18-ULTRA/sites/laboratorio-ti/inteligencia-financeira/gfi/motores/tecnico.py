"""Motor de análise técnica (Python puro). Funções devolvem None quando faltam dados — nunca inventam valores."""
import math
from statistics import pstdev


def sma(v, n):
    return sum(v[-n:]) / n if len(v) >= n else None


def ema_serie(v, n):
    k, e, out = 2 / (n + 1), v[0], [v[0]]
    for x in v[1:]:
        e = x * k + e * (1 - k)
        out.append(e)
    return out


def rsi(c, n=14):
    if len(c) <= n:
        return None
    g = [max(c[i] - c[i - 1], 0) for i in range(1, len(c))]
    p = [max(c[i - 1] - c[i], 0) for i in range(1, len(c))]
    mg, mp = sum(g[:n]) / n, sum(p[:n]) / n
    for i in range(n, len(g)):
        mg, mp = (mg * (n - 1) + g[i]) / n, (mp * (n - 1) + p[i]) / n
    if mp == 0:
        return 100.0 if mg > 0 else 50.0
    return 100 - 100 / (1 + mg / mp)


def macd(c, curta=12, longa=26, sinal=9):
    if len(c) < longa + sinal:
        return None
    linha = [a - b for a, b in zip(ema_serie(c, curta), ema_serie(c, longa))]
    s = ema_serie(linha, sinal)
    return linha[-1], s[-1], linha[-1] - s[-1]


def bollinger(c, n=20, k=2.0):
    if len(c) < n:
        return None
    janela = c[-n:]
    m, dp = sum(janela) / n, pstdev(janela)
    sup, inf = m + k * dp, m - k * dp
    return {"media": m, "superior": sup, "inferior": inf, "pct_b": (c[-1] - inf) / (sup - inf) if sup > inf else 0.5}


def _tr(h, l, c):
    return [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(1, len(c))]


def atr(h, l, c, n=14):
    if len(c) <= n:
        return None
    tr = _tr(h, l, c)
    a = sum(tr[:n]) / n
    for x in tr[n:]:
        a = (a * (n - 1) + x) / n
    return a


def adx(h, l, c, n=14):
    """(ADX, +DI, -DI) de Wilder; precisa de ao menos 2n+1 candles."""
    if len(c) < 2 * n + 1:
        return None
    tr = _tr(h, l, c)
    pdm = [max(h[i] - h[i - 1], 0) if h[i] - h[i - 1] > l[i - 1] - l[i] else 0 for i in range(1, len(c))]
    mdm = [max(l[i - 1] - l[i], 0) if l[i - 1] - l[i] > h[i] - h[i - 1] else 0 for i in range(1, len(c))]
    s_tr, s_p, s_m = sum(tr[:n]), sum(pdm[:n]), sum(mdm[:n])
    dx = []
    for i in range(n, len(tr) + 1):
        if i > n:
            s_tr, s_p, s_m = s_tr - s_tr / n + tr[i - 1], s_p - s_p / n + pdm[i - 1], s_m - s_m / n + mdm[i - 1]
        pdi, mdi = (100 * s_p / s_tr, 100 * s_m / s_tr) if s_tr else (0, 0)
        dx.append((100 * abs(pdi - mdi) / (pdi + mdi) if pdi + mdi else 0, pdi, mdi))
    a = sum(d[0] for d in dx[:n]) / n if len(dx) >= n else sum(d[0] for d in dx) / len(dx)
    for d in dx[n:]:
        a = (a * (n - 1) + d[0]) / n
    return a, dx[-1][1], dx[-1][2]


def obv_tendencia(c, v, n=20):
    """Variação do OBV nos últimos n dias, normalizada pelo volume do período (−1…+1 aprox.)."""
    if len(c) <= n:
        return None
    obv, acc = [0.0], 0.0
    for i in range(1, len(c)):
        acc += v[i] if c[i] > c[i - 1] else -v[i] if c[i] < c[i - 1] else 0
        obv.append(acc)
    tot = sum(v[-n:])
    return (obv[-1] - obv[-1 - n]) / tot if tot else None


def vwap(h, l, c, v, n=20):
    if len(c) < n or sum(v[-n:]) == 0:
        return None
    return sum(((h[i] + l[i] + c[i]) / 3) * v[i] for i in range(-n, 0)) / sum(v[-n:])


def momentum(c, n):
    return c[-1] / c[-1 - n] - 1 if len(c) > n and c[-1 - n] > 0 else None


def retornos(c):
    return [c[i] / c[i - 1] - 1 for i in range(1, len(c)) if c[i - 1] > 0]


def vol_anual(c, n=63):
    if len(c) <= n:
        return None
    lr = [math.log(c[i] / c[i - 1]) for i in range(len(c) - n, len(c)) if c[i - 1] > 0 and c[i] > 0]
    return pstdev(lr) * math.sqrt(252) if len(lr) > 5 else None


def suporte_resistencia(h, l, n=60):
    return (min(l[-n:]), max(h[-n:])) if len(l) >= 10 else (None, None)


def reamostrar(candles, passo):
    """Agrega candles diários em semanais ('semana') ou mensais ('mes')."""
    from datetime import date
    grupos, ordem = {}, []
    for d, o, h, l, c, v, q in candles:
        dd = date.fromisoformat(d)
        chave = dd.isocalendar()[:2] if passo == "semana" else (dd.year, dd.month)
        if chave not in grupos:
            grupos[chave] = [d, o, h, l, c, v, q]
            ordem.append(chave)
        else:
            g = grupos[chave]
            g[2], g[3], g[4], g[5], g[6] = max(g[2], h), min(g[3], l), c, g[5] + v, g[6] + q
    return [tuple(grupos[k]) for k in ordem]


def _media(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def _faixa(x, cortes, valores):
    for corte, val in zip(cortes, valores):
        if x < corte:
            return val
    return valores[-1]


def analisar(candles):
    """Calcula indicadores e três sinais (curto/médio/longo prazo, 0–100). Indicadores correlacionados
    são agrupados e cada grupo conta UMA vez; nenhum indicador isolado decide sozinho."""
    n = len(candles)
    c = [x[4] for x in candles]; h = [x[2] for x in candles]; l = [x[3] for x in candles]; v = [x[5] for x in candles]
    r = {"n": n}
    if n < 20:
        return {**r, "curto": None, "medio": None, "longo": None, "indicadores": {}}
    ind = {"rsi14": rsi(c), "macd": macd(c), "bollinger": bollinger(c), "atr14": atr(h, l, c), "adx14": adx(h, l, c),
           "obv20": obv_tendencia(c, v), "vwap20": vwap(h, l, c, v), "mom21": momentum(c, 21), "mom63": momentum(c, 63),
           "mom252": momentum(c, 252), "sma20": sma(c, 20), "sma50": sma(c, 50), "sma200": sma(c, 200),
           "vol63": vol_anual(c, 63), "suporte": suporte_resistencia(h, l)[0], "resistencia": suporte_resistencia(h, l)[1],
           "fechamento": c[-1]}
    ind["atr_pct"] = ind["atr14"] / c[-1] if ind["atr14"] else None
    r["indicadores"] = ind

    curto = None
    if n >= 40:
        osc = _media([_faixa(ind["rsi14"], (30, 45, 65, 75), (45, 50, 70, 60, 40)) if ind["rsi14"] is not None else None,
                      _faixa(ind["mom21"], (-0.05, 0, 0.05), (30, 42, 58, 70)) if ind["mom21"] is not None else None])
        tend = None
        if ind["macd"]:
            m, s, hist = ind["macd"]
            tend = _media([75 if hist > 0 and m > 0 else 62 if hist > 0 else 30 if m < 0 else 42,
                           (62 if c[-1] > ind["vwap20"] else 40) if ind["vwap20"] else None])
        vola = None
        if ind["bollinger"]:
            pb = ind["bollinger"]["pct_b"]
            vola = 40 if pb < 0.2 else 50 if pb < 0.5 else 65 if pb < 0.9 else 50
        curto = _media([osc, tend, vola])
    medio = None
    if n >= 80:
        sw = sma([x[4] for x in reamostrar(candles, "semana")], 10)
        t1 = None
        if ind["sma20"] and ind["sma50"]:
            t1 = 75 if c[-1] > ind["sma20"] > ind["sma50"] else 60 if c[-1] > ind["sma50"] else 25 if c[-1] < ind["sma20"] < ind["sma50"] else 35
        trend = _media([t1, (60 if c[-1] > sw else 38) if sw else None])
        forca = None
        if ind["adx14"]:
            a, pdi, mdi = ind["adx14"]
            forca = 75 if a > 25 and pdi > mdi else 25 if a > 25 else 50
        vol_g = None if ind["obv20"] is None else 62 if ind["obv20"] > 0 else 40
        medio = _media([trend, forca, vol_g])
    longo = None
    if n >= 220:
        mens = sma([x[4] for x in reamostrar(candles, "mes")], 10)
        t = _media([(75 if c[-1] > ind["sma200"] and (ind["sma50"] or 0) > ind["sma200"] else 62 if c[-1] > ind["sma200"] else 32),
                    (60 if c[-1] > mens else 38) if mens else None])
        m = _faixa(ind["mom252"], (0, 0.15), (35, 58, 72)) if ind["mom252"] is not None else None
        dd = c[-1] / max(c[-252:]) - 1
        longo = _media([t, m, 70 if dd > -0.10 else 50 if dd > -0.25 else 30])
    r.update({"curto": curto, "medio": medio, "longo": longo})
    return r
