"""Motor de risco: volatilidade, drawdown, VaR histórico, beta e liquidez."""
import math
from statistics import mean, pstdev

from . import tecnico


def max_drawdown(c):
    pico, pior = c[0], 0.0
    for x in c:
        pico = max(pico, x)
        pior = min(pior, x / pico - 1)
    return pior


def var_historico(ret, nivel=0.05):
    """Perda diária que foi superada em `nivel` dos dias (valor negativo). É estimativa histórica, não garantia."""
    if len(ret) < 30:
        return None
    s = sorted(ret)
    return s[int(len(s) * nivel)]


def retornos_alinhados(candles_a, candles_b):
    b = {d: c for d, *_, c, _v, _q in candles_b}
    a_aligned, b_aligned, prev = [], [], None
    for d, o, h, l, c, v, q in candles_a:
        if d in b:
            if prev:
                a_aligned.append(c / prev[0] - 1)
                b_aligned.append(b[d] / prev[1] - 1)
            prev = (c, b[d])
    return a_aligned, b_aligned


def beta_correlacao(candles_ativo, candles_bench, n=252):
    ra, rb = retornos_alinhados(candles_ativo, candles_bench)
    ra, rb = ra[-n:], rb[-n:]
    if len(ra) < 60:
        return None, None
    ma, mb = mean(ra), mean(rb)
    cov = sum((x - ma) * (y - mb) for x, y in zip(ra, rb)) / len(ra)
    vb, va = pstdev(rb) ** 2, pstdev(ra) ** 2
    if vb == 0 or va == 0:
        return None, None
    return cov / vb, cov / math.sqrt(va * vb)


def liquidez(candles, n=21):
    ult = candles[-n:]
    if len(ult) < 5:
        return None
    return {"volume_medio": mean(x[5] for x in ult), "dias_sem_negocio": sum(1 for x in ult if x[5] <= 0 or x[6] <= 0),
            "janela": len(ult)}


def retorno_risco(c, n=252):
    """Retorno anualizado dividido pela volatilidade anualizada (sem taxa livre de risco)."""
    ret = tecnico.retornos(c[-(n + 1):])
    if len(ret) < 60 or pstdev(ret) == 0:
        return None
    return (mean(ret) * 252) / (pstdev(ret) * math.sqrt(252))


def resumo(candles, bench=None):
    c = [x[4] for x in candles]
    out = {"vol_anual": tecnico.vol_anual(c, 63), "max_drawdown": max_drawdown(c[-252:]) if len(c) > 20 else None,
           "var95": var_historico(tecnico.retornos(c[-252:])), "liquidez": liquidez(candles),
           "retorno_risco": retorno_risco(c), "beta": None, "correlacao": None}
    if bench:
        out["beta"], out["correlacao"] = beta_correlacao(candles, bench)
    return out
