"""Motor de valuation: múltiplos, comparação com pares, fluxo de caixa descontado e armadilhas de valor.
Toda estimativa devolve premissas e limitações. Sem dados suficientes, o veredito é 'impossível'."""
from statistics import median

from .. import config


def ultimo_anual(fund):
    anos = sorted(p for p in fund if len(p) == 4 and p.isdigit())
    return (anos[-1], fund[anos[-1]]) if anos else (None, {})


def cagr(valores):
    v = [x for x in valores if x is not None]
    if len(v) < 3 or v[0] <= 0 or v[-1] <= 0:
        return None
    return (v[-1] / v[0]) ** (1 / (len(v) - 1)) - 1


def multiplos(preco, f):
    a, ll, pl = f.get("acoes"), f.get("lucro_liquido"), f.get("patrimonio")
    if not a or a <= 0 or not preco:
        return {}
    mcap = preco * a
    ev = mcap + (f.get("divida_liquida") or 0)
    div = lambda x, y: (x / y) if x is not None and y not in (None, 0) else None
    return {"mcap": mcap, "ev": ev, "p_l": div(mcap, ll) if ll and ll > 0 else None,
            "p_vp": div(mcap, pl) if pl and pl > 0 else None,
            "ev_ebitda": div(ev, f.get("ebitda")) if (f.get("ebitda") or 0) > 0 else None,
            "ev_ebit": div(ev, f.get("ebit")) if (f.get("ebit") or 0) > 0 else None,
            "p_fcf": div(mcap, f.get("fcf")) if (f.get("fcf") or 0) > 0 else None,
            "dy": div((f.get("dividendos_por_acao") or 0), preco)}


def dcf(fcf0, acoes, divida_liq, g, r, g_perp, anos=5):
    """Valor justo por ação. Exige r > g_perp e FCF positivo."""
    if not fcf0 or fcf0 <= 0 or not acoes or r <= g_perp:
        return None
    fc, vp = fcf0, 0.0
    for t in range(1, anos + 1):
        fc *= 1 + g
        vp += fc / (1 + r) ** t
    vt = fc * (1 + g_perp) / (r - g_perp)
    ev = vp + vt / (1 + r) ** anos
    return (ev - (divida_liq or 0)) / acoes


def avaliar(preco, fund, pares=None, taxa=None, g_perp=None):
    taxa = taxa or config.TAXA_DESCONTO
    g_perp = g_perp if g_perp is not None else config.CRESCIMENTO_PERPETUO
    ano, f = ultimo_anual(fund)
    limitacoes = ["Estimativa baseada em dados históricos e premissas editáveis; não é recomendação de investimento.",
                  "Cenários dependem de crescimento e taxa de desconto que são incertos."]
    base = {"periodo": ano, "multiplos": {}, "cenarios": {}, "veredito": "impossivel", "armadilha_valor": {"alerta": False, "motivos": []},
            "premissas": {"taxa_desconto": taxa, "crescimento_perpetuo": g_perp}, "limitacoes": limitacoes, "vs_pares": {}}
    if not ano or not preco:
        base["limitacoes"].append("Sem fundamentos recentes: não é possível avaliar.")
        return base
    m = multiplos(preco, f)
    base["multiplos"] = m
    anos = sorted(p for p in fund if len(p) == 4 and p.isdigit())
    g_hist = cagr([fund[a].get("receita") for a in anos])
    g = min(max(g_hist if g_hist is not None else 0.05, 0.0), 0.15)
    base["premissas"]["crescimento_5a"] = round(g, 4)
    base["premissas"]["crescimento_historico_receita"] = round(g_hist, 4) if g_hist is not None else None
    if m.get("p_l") and g > 0:
        base["multiplos"]["peg"] = m["p_l"] / (g * 100)
    cen = {"otimista": (g + 0.03, taxa - 0.01), "base": (g, taxa), "pessimista": (max(g - 0.03, 0.0), taxa + 0.01)}
    for nome, (gg, rr) in cen.items():
        vj = dcf(f.get("fcf"), f.get("acoes"), f.get("divida_liquida"), gg, rr, g_perp)
        if vj is not None:
            base["cenarios"][nome] = {"valor_justo": round(vj, 2), "margem": round(vj / preco - 1, 4), "crescimento": round(gg, 4),
                                      "taxa_desconto": round(rr, 4)}
    if "base" in base["cenarios"]:
        mg = base["cenarios"]["base"]["margem"]
        base["veredito"] = "subavaliada" if mg > 0.20 else "sobreavaliada" if mg < -0.15 else "justa"
    else:
        base["limitacoes"].append("FCF não positivo ou dados faltando: DCF indisponível.")
    if pares:
        for k, med in pares.items():
            if m.get(k) and med:
                base["vs_pares"][k] = {"empresa": round(m[k], 2), "mediana_setor": round(med, 2), "relativo": round(m[k] / med - 1, 3)}
    # armadilha de valor: parece barata, mas os fundamentos pioram
    barata = (m.get("p_l") and m["p_l"] < 8) or (m.get("p_vp") and m["p_vp"] < 0.8)
    motivos = []
    if len(anos) >= 2:
        ant = fund[anos[-2]]
        mar = lambda d: (d.get("lucro_liquido") / d["receita"]) if d.get("receita") and d.get("lucro_liquido") is not None else None
        if mar(f) is not None and mar(ant) is not None and mar(f) < mar(ant) - 0.02:
            motivos.append("margem líquida em queda")
        if f.get("receita") and ant.get("receita") and f["receita"] < ant["receita"]:
            motivos.append("receita em queda")
    if f.get("ebitda") and f["ebitda"] > 0 and (f.get("divida_liquida") or 0) / f["ebitda"] > 3.5:
        motivos.append("dívida líquida/EBITDA acima de 3,5")
    if f.get("fcf") is not None and f["fcf"] < 0:
        motivos.append("fluxo de caixa livre negativo")
    base["armadilha_valor"] = {"alerta": bool(barata and motivos), "motivos": motivos if barata else [], "parece_barata": bool(barata)}
    return base


def medianas_por_setor(todos):
    """todos: [(setor, multiplos)] → {setor: {multiplo: mediana}} (mínimo de 3 empresas por setor)."""
    por = {}
    for setor, m in todos:
        for k in ("p_l", "p_vp", "ev_ebitda", "p_fcf"):
            if m.get(k):
                por.setdefault(setor, {}).setdefault(k, []).append(m[k])
    return {s: {k: median(v) for k, v in d.items() if len(v) >= 3} for s, d in por.items()}
