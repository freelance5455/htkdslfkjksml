"""Motor de pontuação: 15 sinais independentes (verde/amarelo/vermelho/cinza) + índice geral 0–100 explicável.

Regras de integridade (vindas do prompt mestre):
  • dado ausente, antigo ou inválido → CINZA, nunca verde;
  • indicadores correlacionados são agrupados e contam uma vez (sem dupla contagem);
  • eventos graves bloqueiam/limitam o índice mesmo com muitos sinais verdes;
  • toda pontuação traz a sua composição; fatos, estimativas, hipóteses e opiniões ficam separados.
"""
import math
from datetime import date
from statistics import mean, pstdev

from .. import config, db
from . import macro, risco, tecnico, valuation


def luz(score):
    if score is None:
        return "cinza"
    return "verde" if score >= config.LIMIARES["verde"] else "amarelo" if score >= config.LIMIARES["amarelo"] else "vermelho"


def _lim(x, a=5, b=95):
    return max(a, min(b, x))


def _linear(x, x0, y0, x1, y1):
    if x1 == x0:
        return y0
    return _lim(y0 + (y1 - y0) * (x - x0) / (x1 - x0), min(y0, y1), max(y0, y1))


def _d(score, razao, itens=None, fonte=None, atualizado=None):
    s = None if score is None else round(float(score), 1)
    return {"score": s, "luz": luz(s), "razao": razao, "itens": itens or [], "fonte": fonte, "atualizado_em": atualizado}


def _cinza(razao):
    return _d(None, razao)


def _it(tipo, texto):
    return {"tipo": tipo, "texto": texto}      # tipo: fato | estimativa | hipotese | opiniao


# ---------------------------------------------------------------- dimensões
def d_tecnica(ctx):
    a = ctx["analise"]
    hz = {k: a.get(k) for k in ("curto", "medio", "longo")}
    disp = {k: v for k, v in hz.items() if v is not None}
    if len(disp) < 2:
        return _cinza("histórico insuficiente para sinais em ao menos dois horizontes")
    s = mean(disp.values())
    nota = ""
    if s >= config.LIMIARES["verde"] and sum(1 for v in disp.values() if v >= 55) < 2:
        s, nota = config.LIMIARES["verde"] - 1, " Indicador isolado não vira sinal verde."
    ind, it = a["indicadores"], []
    if ind.get("rsi14") is not None:
        it.append(_it("fato", f"RSI(14) = {ind['rsi14']:.1f}"))
    if ind.get("macd"):
        it.append(_it("fato", f"MACD histograma = {ind['macd'][2]:+.3f}"))
    if ind.get("sma50") and ind.get("sma200"):
        it.append(_it("fato", f"Média 50 d {'acima' if ind['sma50'] > ind['sma200'] else 'abaixo'} da média 200 d"))
    nomes = {"curto": "curto prazo", "medio": "médio prazo", "longo": "longo prazo"}
    it.append(_it("opiniao", "Sinais: " + ", ".join(f"{nomes[k]} {v:.0f}" for k, v in disp.items()) + "." + nota))
    return _d(s, "convergência de sinais em vários horizontes (grupos de indicadores contados uma vez)", it, ctx["fonte_precos"], ctx["ultima_data"])


def d_liquidez(ctx):
    lq = ctx["risco"]["liquidez"]
    if not lq:
        return _cinza("sem dados de volume")
    vm = lq["volume_medio"]
    if vm >= config.LIQUIDEZ_VERDE:
        s = 80.0
    elif vm >= config.LIQUIDEZ_MINIMA:
        s = 40 + 40 * math.log10(vm / config.LIQUIDEZ_MINIMA) / math.log10(config.LIQUIDEZ_VERDE / config.LIQUIDEZ_MINIMA)
    else:
        s = 15.0
    s -= min(30, 3 * lq["dias_sem_negocio"])
    it = [_it("fato", f"Volume financeiro médio (21 d): {vm:,.0f}".replace(",", ".")),
          _it("fato", f"{lq['dias_sem_negocio']} dia(s) sem negociação nos últimos {lq['janela']}")]
    return _d(_lim(s), "volume negociado e regularidade de negociação", it, ctx["fonte_precos"], ctx["ultima_data"])


def d_volatilidade(ctx):
    v = ctx["risco"]["vol_anual"]
    if v is None:
        return _cinza("histórico insuficiente para volatilidade")
    return _d(_linear(v, 0.15, 90, 0.60, 20), "volatilidade anualizada dos últimos 63 pregões",
              [_it("fato", f"Volatilidade anualizada: {v * 100:.1f}%")], ctx["fonte_precos"], ctx["ultima_data"])


def d_risco(ctx):
    r, partes, it = ctx["risco"], [], []
    if r.get("max_drawdown") is not None:
        partes.append(_lim(100 + r["max_drawdown"] * 150))
        it.append(_it("fato", f"Drawdown máximo (12 m): {r['max_drawdown'] * 100:.1f}%"))
    if r.get("var95") is not None:
        partes.append(_lim(100 + r["var95"] * 1500))
        it.append(_it("estimativa", f"VaR histórico 95% (1 dia): {r['var95'] * 100:.2f}% — estimativa, não garantia"))
    if r.get("beta") is not None:
        b = r["beta"]
        partes.append(70 if 0.6 <= b <= 1.2 else 60 if b < 0.6 else 45 if b <= 1.5 else 35)
        it.append(_it("fato", f"Beta (12 m) vs benchmark: {b:.2f}"))
    if len(partes) < 2:
        return _cinza("dados insuficientes para avaliar risco")
    return _d(mean(partes), "drawdown, perda extrema histórica e beta (volatilidade fica em sinal próprio)", it,
              ctx["fonte_precos"], ctx["ultima_data"])


def d_valuation(ctx):
    v = ctx["valuation"]
    if v["veredito"] == "impossivel":
        return _cinza("sem fundamentos/FCF suficientes para avaliar")
    s = {"subavaliada": 78, "justa": 55, "sobreavaliada": 25}[v["veredito"]]
    it = [_it("estimativa", f"Valor justo (DCF, cenário base): {v['cenarios']['base']['valor_justo']:.2f} "
                            f"({v['cenarios']['base']['margem'] * 100:+.0f}% vs preço)"),
          _it("hipotese", f"Crescimento 5 a: {v['premissas'].get('crescimento_5a', 0) * 100:.1f}% · "
                          f"desconto: {v['premissas']['taxa_desconto'] * 100:.1f}%")]
    m = v["multiplos"]
    if m.get("p_l"):
        it.append(_it("fato", f"P/L {m['p_l']:.1f}" + (f" · P/VP {m['p_vp']:.2f}" if m.get("p_vp") else "")))
    if v["armadilha_valor"]["alerta"]:
        s = min(s, 35)
        it.append(_it("opiniao", "Possível armadilha de valor: " + "; ".join(v["armadilha_valor"]["motivos"])))
    return _d(s, "DCF com cenários + múltiplos (barato ≠ oportunidade)", it, ctx["fonte_fund"], v["periodo"])


def _ultimo(ctx):
    ano, f = valuation.ultimo_anual(ctx["fund"])
    return ano, f


def d_saude(ctx):
    ano, f = _ultimo(ctx)
    if not ano:
        return _cinza("sem demonstrações financeiras")
    grupos, it = [], []
    rent = []
    if f.get("receita") and f.get("lucro_liquido") is not None:
        mg = f["lucro_liquido"] / f["receita"]
        rent.append(85 if mg >= 0.15 else 65 if mg >= 0.08 else 45 if mg >= 0 else 15)
        it.append(_it("fato", f"Margem líquida {ano}: {mg * 100:.1f}%"))
    if f.get("patrimonio") and f.get("lucro_liquido") is not None and f["patrimonio"] > 0:
        roe = f["lucro_liquido"] / f["patrimonio"]
        rent.append(80 if roe >= 0.15 else 60 if roe >= 0.08 else 40 if roe >= 0 else 15)
        it.append(_it("fato", f"ROE {ano}: {roe * 100:.1f}%"))
    if rent:
        grupos.append(mean(rent))
    if f.get("ebitda") is not None and f.get("divida_liquida") is not None:
        al = 10 if f["ebitda"] <= 0 else None
        if al is None:
            x = f["divida_liquida"] / f["ebitda"]
            al = 85 if x <= 1 else 65 if x <= 2.5 else 45 if x <= 3.5 else 20
            it.append(_it("fato", f"Dívida líquida/EBITDA {ano}: {x:.1f}×"))
        grupos.append(al)
    if f.get("fcf") is not None:
        grupos.append(70 if f["fcf"] > 0 else 20)
        it.append(_it("fato", f"Fluxo de caixa livre {ano}: {'positivo' if f['fcf'] > 0 else 'negativo'}"))
    if len(grupos) < 2:
        return _cinza("fundamentos incompletos (rentabilidade, alavancagem e caixa)")
    return _d(mean(grupos), "rentabilidade, alavancagem e geração de caixa (três grupos, cada um conta uma vez)", it, ctx["fonte_fund"], ano)


def _cagr_campo(fund, campo):
    anos = sorted(p for p in fund if len(p) == 4 and p.isdigit())
    return valuation.cagr([fund[a].get(campo) for a in anos]), len(anos)


def d_crescimento(ctx):
    gr, n = _cagr_campo(ctx["fund"], "receita")
    if gr is None:
        return _cinza("menos de 3 exercícios de receita")
    s = 85 if gr >= 0.15 else 70 if gr >= 0.08 else 55 if gr >= 0.03 else 40 if gr >= 0 else 20
    it = [_it("fato", f"CAGR da receita ({n} exercícios): {gr * 100:.1f}%")]
    gl, _ = _cagr_campo(ctx["fund"], "lucro_liquido")
    if gl is not None:
        s = (s + (80 if gl >= 0.10 else 55 if gl >= 0 else 25)) / 2
        it.append(_it("fato", f"CAGR do lucro líquido: {gl * 100:.1f}%"))
    return _d(s, "crescimento composto de receita e lucro", it, ctx["fonte_fund"], max(ctx["fund"]))


def d_governanca(ctx):
    g = next((ctx["fund"][p]["governanca"] for p in sorted(ctx["fund"], reverse=True) if ctx["fund"][p].get("governanca") is not None), None)
    if g is None:
        return _cinza("sem dados de governança (ex.: segmento de listagem, conselho independente)")
    return _d(g, "indicador de governança informado nos fundamentos", [_it("fato", f"Score de governança: {g:.0f}/100")], ctx["fonte_fund"])


def d_longo_prazo(ctx):
    c = [x[4] for x in ctx["candles"]]
    partes, it = [], []
    if len(c) >= 500:
        anos = (len(c) - 1) / 252
        cg = (c[-1] / c[0]) ** (1 / anos) - 1 if c[0] > 0 else None
        if cg is not None:
            partes.append(80 if cg >= 0.15 else 65 if cg >= 0.05 else 50 if cg >= 0 else 30)
            it.append(_it("fato", f"Retorno anualizado do preço ({anos:.1f} anos): {cg * 100:.1f}%"))
        jan = [c[i] / c[i - 252] - 1 for i in range(252, len(c), 21)]
        if jan:
            pos = sum(1 for x in jan if x > 0) / len(jan)
            partes.append(75 if pos >= 0.7 else 55 if pos >= 0.5 else 35)
            it.append(_it("fato", f"{pos * 100:.0f}% das janelas de 12 meses tiveram retorno positivo"))
    anos_f = sorted(p for p in ctx["fund"] if len(p) == 4 and p.isdigit())
    mar = [ctx["fund"][a]["lucro_liquido"] / ctx["fund"][a]["receita"] for a in anos_f
           if ctx["fund"][a].get("receita") and ctx["fund"][a].get("lucro_liquido") is not None]
    if len(mar) >= 3:
        dp = pstdev(mar)
        partes.append(75 if dp < 0.02 else 55 if dp < 0.05 else 35)
        it.append(_it("fato", f"Estabilidade da margem líquida (desvio {dp * 100:.1f} p.p.)"))
    if len(partes) < 2:
        return _cinza("histórico de preços/fundamentos curto para perspectiva de longo prazo")
    return _d(mean(partes), "consistência histórica (entradas distintas das demais dimensões)", it, ctx["fonte_precos"], ctx["ultima_data"])


def _macro(fator):
    def f(ctx):
        inst = ctx["inst"]
        fa = ctx["macro"].get(fator)
        if inst.get("pais") != "BR":
            return _cinza("conectores macroeconômicos deste país ainda não estão ativos")
        if not fa:
            return _cinza(f"série macroeconômica de {fator} indisponível")
        ef = macro.efeito(fator, inst.get("setor"), fa["direcao"])
        if ef is None:
            return _cinza("setor não classificado: não é possível relacionar o indicador à empresa")
        s = _lim(50 + 18 * ef)
        return _d(s, f"efeito esperado do fator sobre o setor ({inst['setor']})",
                  [_it("fato", fa["texto"]),
                   _it("hipotese", f"Efeito esperado sobre o setor: {ef:+d} (hipótese editável em configurações)")], fa["fonte"], fa["data"])
    return f


_CAT = {"noticias": "noticia", "regulacao": "regulatorio", "geopolitica": "geopolitico"}
_CONF = {"alta": 1.0, "media": 0.7, "baixa": 0.4}


def _eventos(dim):
    def f(ctx):
        evs = [e for e in ctx["eventos"] if e["categoria"] == _CAT[dim]]
        if not evs:
            return _cinza("nenhum evento registrado (a ausência de dados não é sinal verde)")
        hoje = date.fromisoformat(ctx["ultima_data"])
        num = den = 0.0
        it, fortes = [], {1: False, -1: False}
        for e in evs:
            idade = max(0, (hoje - date.fromisoformat(e["publicado_em"][:10])).days)
            p = (e["severidade"] or 1) * 0.5 ** (idade / 45) * _CONF.get(e["confiabilidade"], 0.5)
            num += (e["impacto"] or 0) * p
            den += p
            if abs(e["impacto"] or 0) >= 2 and idade <= 14:
                fortes[1 if e["impacto"] > 0 else -1] = True
            if len(it) < 4:
                it.append(_it("fato", f"{e['publicado_em'][:10]} · {e['titulo']} ({e['fonte']})"))
        m = num / den if den else 0
        s = _lim(50 + 22 * m)
        if fortes[1] and fortes[-1]:
            s = 50 + (s - 50) / 2
            it.append(_it("opiniao", "Informações contraditórias recentes: sinal atenuado."))
        return _d(s, "eventos recentes ponderados por severidade, idade e confiabilidade da fonte", it,
                  ", ".join(sorted({e["fonte"] for e in evs})), max(e["publicado_em"][:10] for e in evs))
    return f


_FUNCOES = {"economia": _macro("economia"), "juros": _macro("juros"), "inflacao": _macro("inflacao"), "saude": d_saude,
            "crescimento": d_crescimento, "valuation": d_valuation, "noticias": _eventos("noticias"),
            "regulacao": _eventos("regulacao"), "governanca": d_governanca, "tecnica": d_tecnica, "liquidez": d_liquidez,
            "volatilidade": d_volatilidade, "geopolitica": _eventos("geopolitica"), "risco": d_risco, "longo_prazo": d_longo_prazo}

# ---------------------------------------------------------------- índice
def pesos_efetivos(tipo):
    base = {**config.PESOS_PADRAO, **(db.cfg_get("pesos", {}) or {})}
    mult = config.PESOS_POR_TIPO.get(tipo or "", {})
    return {k: base[k] * mult.get(k, 1) for k in config.DIMENSOES}


def saltos_sem_explicacao(ctx):
    """Saltos de preço que NÃO coincidem com razões comuns de desdobramento/grupamento: podem ser eventos corporativos não ajustados."""
    return [s for s in ctx["validacao"].get("saltos", []) if not s.get("provavel_evento")]


def bloqueios(ctx):
    b = []
    incerto = bool(saltos_sem_explicacao(ctx))
    for e in ctx["eventos"]:
        if (e["severidade"] or 0) >= 4 and (e["impacto"] or 0) < 0 and e["tipo"] in ("fraude", "falencia", "recuperacao_judicial", "suspensao", "investigacao_grave"):
            b.append(f"evento grave: {e['titulo']} ({e['publicado_em'][:10]})")
    lq = ctx["risco"]["liquidez"]
    if lq and lq["volume_medio"] < config.LIQUIDEZ_MINIMA:
        b.append("liquidez abaixo do mínimo operacional")
    if not incerto:        # com salto sem explicação a volatilidade/queda podem ser artefato de evento corporativo: não bloqueia (ver calcular)
        if (ctx["risco"]["vol_anual"] or 0) > 1.2:
            b.append("volatilidade extrema (>120% a.a.)")
        if (ctx["risco"]["max_drawdown"] or 0) < -0.70:
            b.append("drawdown superior a 70% em 12 meses")
    return b


def calcular(ctx):
    """ctx → resultado completo: sinais, composição, índice, bloqueios, qualidade e respostas explicadas."""
    dims = {k: _FUNCOES[k](ctx) for k in config.DIMENSOES}
    # Sem preço diário recente, nenhum sinal derivado de preço pode parecer atual.
    desatualizado = bool(ctx["validacao"].get("desatualizado"))
    if desatualizado:
        motivo = "cotação diária desatualizada; indicador bloqueado até sincronização"
        for k in ("tecnica", "liquidez", "volatilidade", "risco", "longo_prazo", "valuation"):
            dims[k] = _cinza(motivo)
    pesos = pesos_efetivos(ctx["inst"].get("tipo"))
    ativos = {k: w for k, w in pesos.items() if w > 0}
    w_tot = sum(ativos.values())
    w_ok = sum(w for k, w in ativos.items() if dims[k]["score"] is not None)
    cobertura = w_ok / w_tot if w_tot else 0.0
    penal, blq = [], bloqueios(ctx)
    indice = None
    if desatualizado:
        penal.append("índice geral suspenso: série diária ultrapassou a janela de atualidade")
    elif cobertura >= config.COBERTURA_MINIMA and w_ok:
        media = sum(ativos[k] * dims[k]["score"] for k in ativos if dims[k]["score"] is not None) / w_ok
        indice = media * (0.6 + 0.4 * cobertura)
        if cobertura < 1:
            penal.append(f"cobertura de dados {cobertura * 100:.0f}%: índice multiplicado por {0.6 + 0.4 * cobertura:.2f}")
        criticos = [k for k in ("risco", "liquidez", "volatilidade") if dims[k]["score"] is not None and dims[k]["score"] < 25]
        if criticos:
            indice = min(indice, 55.0)
            penal.append("risco crítico em " + ", ".join(config.ROTULOS[k] for k in criticos) + ": índice limitado a 55")
        if saltos_sem_explicacao(ctx) and ((ctx["risco"]["vol_anual"] or 0) > 1.2 or (ctx["risco"]["max_drawdown"] or 0) < -0.70):
            indice = min(indice, 55.0)
            penal.append("risco INCERTO: salto de preço sem explicação (possível evento corporativo não ajustado); índice limitado a 55 em vez de bloqueio")
        if ctx["validacao"]["qualidade"] < 0.5:
            indice = min(indice, 60.0)
            penal.append("qualidade dos dados baixa: índice limitado a 60")
        if blq:
            indice = min(indice, config.LIMITE_COM_BLOQUEIO)
    comp = [{"dimensao": k, "rotulo": config.ROTULOS[k], "peso": round(ativos[k], 2), "score": dims[k]["score"], "luz": dims[k]["luz"],
             "contribuicao": round(ativos[k] * dims[k]["score"] / w_ok, 2) if dims[k]["score"] is not None and w_ok else None}
            for k in ativos]
    cores = [d["luz"] for d in dims.values()]
    r = {"indice": None if indice is None else round(indice, 1), "luz": "cinza" if desatualizado else ("vermelho" if blq else luz(indice)),
         "bloqueado": bool(blq), "bloqueios": blq, "analise_suspensa": desatualizado, "penalizacoes": penal, "cobertura": round(cobertura, 3),
         "qualidade": ctx["validacao"]["qualidade"], "problemas_dados": ctx["validacao"]["problemas"], "dimensoes": dims,
         "composicao": comp, "contagem": {c: cores.count(c) for c in ("verde", "amarelo", "vermelho", "cinza")}}
    r["respostas"] = explicar(ctx, r)
    return r


def explicar(ctx, r):
    """As 10 perguntas do prompt mestre, respondidas a partir dos próprios cálculos."""
    d, rot = r["dimensoes"], config.ROTULOS
    pos = [k for k, v in d.items() if v["score"] is not None and v["score"] >= config.LIMIARES["verde"]]
    neg = [k for k, v in d.items() if v["score"] is not None and v["score"] < config.LIMIARES["amarelo"]]
    cinza = [k for k, v in d.items() if v["score"] is None]
    top = sorted((c for c in r["composicao"] if c["contribuicao"] is not None), key=lambda c: -c["contribuicao"])
    fontes = sorted({v["fonte"] for v in d.values() if v["fonte"]})
    datas = {k: v["atualizado_em"] for k, v in d.items() if v["atualizado_em"]}
    melhorar = [f"{rot[k]}: {d[k]['razao']}" for k in d if d[k]["score"] is not None and d[k]["score"] < config.LIMIARES["verde"]]
    piorar = [f"{rot[k]} está perto do limite ({d[k]['score']:.0f})" for k in pos if d[k]["score"] < config.LIMIARES["verde"] + 8]
    riscos = [f"{rot[k]}: {d[k]['razao']}" for k in ("risco", "volatilidade", "liquidez") if d[k]["score"] is not None and d[k]["score"] < config.LIMIARES["verde"]]
    riscos += r["bloqueios"] + (["armadilha de valor"] if ctx["valuation"]["armadilha_valor"]["alerta"] else [])
    por_tipo = {"fatos": [], "estimativas": [], "hipoteses": [], "opinioes": []}
    mapa = {"fato": "fatos", "estimativa": "estimativas", "hipotese": "hipoteses", "opiniao": "opinioes"}
    for k, v in d.items():
        for i in v["itens"]:
            por_tipo[mapa[i["tipo"]]].append(f"[{rot[k]}] {i['texto']}")
    if r["indice"] is None:
        porque = "Índice geral não calculado: dados insuficientes (cobertura abaixo do mínimo)."
    else:
        porque = (f"Índice {r['indice']:.0f}/100. Maiores contribuições: " + ", ".join(f"{c['rotulo']} ({c['contribuicao']:+.1f})" for c in top[:3])
                  + (". " + " ".join(r["penalizacoes"]) if r["penalizacoes"] else "."))
    return {"1_por_que": porque, "2_positivos": [f"{rot[k]}: {d[k]['razao']}" for k in pos], "3_negativos": [f"{rot[k]}: {d[k]['razao']}" for k in neg],
            "4_acontecimentos": [f"{e['publicado_em'][:10]} · {e['titulo']}" for e in ctx["eventos"][:5]], "5_fontes": fontes,
            "6_atualizacao": datas, "7_melhorar": melhorar[:6], "8_piorar": piorar + [f"{rot[k]}" for k in neg][:4],
            "9_riscos": riscos, "10_faltando": [f"{rot[k]}: {d[k]['razao']}" for k in cinza], "separacao": por_tipo}
