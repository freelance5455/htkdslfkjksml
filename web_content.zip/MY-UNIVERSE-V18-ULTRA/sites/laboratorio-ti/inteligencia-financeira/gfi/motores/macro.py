"""Motor macroeconômico: direção dos fatores (juros, inflação, atividade) e efeito por setor (hipóteses editáveis)."""
from .. import config, dados


def _dir(delta, limiar):
    return 1 if delta > limiar else -1 if delta < -limiar else 0


def fatores(fonte, ate=None):
    """{fator: {direcao, atual, referencia, data, fonte}} com os fatores que puderam ser calculados."""
    out = {}
    selic = dados.serie_macro("selic_meta", fonte, ate)
    if len(selic) >= 2:
        atual = selic[-1][1]
        ref = next((v for d, v in reversed(selic) if d <= _menos_dias(selic[-1][0], 180)), selic[0][1])
        out["juros"] = {"direcao": _dir(atual - ref, 0.5), "atual": atual, "referencia": ref, "data": selic[-1][0], "fonte": fonte,
                        "texto": f"Selic {atual:.2f}% (há ~6 meses: {ref:.2f}%)"}
    ipca = dados.serie_macro("ipca_mensal", fonte, ate)
    if len(ipca) >= 24:
        acum = lambda xs: _acumulado(xs)
        a12, a12_ant = acum([v for _, v in ipca[-12:]]), acum([v for _, v in ipca[-24:-12]])
        out["inflacao"] = {"direcao": _dir(a12 - a12_ant, 0.5), "atual": a12, "referencia": a12_ant, "data": ipca[-1][0], "fonte": fonte,
                           "texto": f"IPCA 12m {a12:.2f}% (12m anteriores: {a12_ant:.2f}%)"}
    des = dados.serie_macro("desemprego", fonte, ate)
    if len(des) >= 7:
        atual, ref = des[-1][1], des[-7][1]
        out["economia"] = {"direcao": -_dir(atual - ref, 0.3), "atual": atual, "referencia": ref, "data": des[-1][0], "fonte": fonte,
                           "texto": f"Desocupação {atual:.1f}% (há ~6 meses: {ref:.1f}%)"}
    return out


def _acumulado(mensais):
    x = 1.0
    for m in mensais:
        x *= 1 + m / 100
    return (x - 1) * 100


def _menos_dias(data_iso, dias):
    from datetime import date, timedelta
    return (date.fromisoformat(data_iso) - timedelta(days=dias)).isoformat()


def efeito(fator, setor, dir_fator):
    """Efeito esperado (−2…+2) do fator sobre o setor = sensibilidade × direção. None se não há hipótese para o setor."""
    s = config.SENSIBILIDADE.get(fator, {}).get(setor)
    return None if s is None else s * dir_fator
