"""Backtest walk-forward SEM look-ahead e SEM gravar nada em `previsoes`.

Em cada data de rebalanceamento a IA vê apenas o que existia até aquela data (cotações, eventos, macro e balanços do ano
anterior), monta uma carteira com o quantil de maior índice e a mantém por `horizonte` pregões, pagando custos e slippage.
Compara com o universo igual-ponderado e com carteiras ALEATÓRIAS (Monte Carlo) para separar habilidade de sorte.
Limitações honestas: universo e dados são os que você tem; sem impostos; liquidez só filtrada, não simulada ordem a ordem.
"""
import bisect
import math
import random
import statistics
import time

from . import catalogo, config, dados, db, pipeline
from .motores import macro as macro_m, pontuacao, tecnico


def _preco_em(candles, data):
    ult = None
    for c in candles:
        if c[0] > data:
            break
        ult = c
    return ult


def executar(origem=None, horizonte=21, passo=21, rebalanceamentos=12, quantil=0.2, custo=0.001, slippage=0.0005, max_ativos=300, sorteios=500, semente=7):
    origem = origem or catalogo.origem_ativa()
    t0 = time.time()
    insts = [i for i in catalogo.listar(origem, apenas_ativos=False) if i["tipo"] != "indice"][:max_ativos]   # inclui deslistados: sem viés de sobrevivência
    series = {i["id"]: dados.candles(i["id"], limite=3000) for i in insts}
    datas_de = {k: [c[0] for c in s] for k, s in series.items()}
    baseline_ex = {"momentum": [], "baixa_volatilidade": []}
    calendario = sorted({c[0] for s in series.values() for c in s})
    if len(calendario) < config.MIN_CANDLES + horizonte + passo:
        return {"erro": "histórico insuficiente para backtest", "n_periodos": 0}
    ultimo = len(calendario) - 1 - horizonte
    idxs = [ultimo - k * passo for k in range(rebalanceamentos) if ultimo - k * passo >= config.MIN_CANDLES][::-1]
    bench_inst = db.um("SELECT id FROM instrumentos WHERE origem=? AND tipo='indice' LIMIT 1", (origem,))
    bench = dados.candles(bench_inst["id"], limite=3000) if bench_inst else None
    fonte_macro = "SIMULADO" if origem == "SIMULADO" else "BCB-SGS"
    rng = random.Random(semente)
    periodos = []
    for ix in idxs:
        d0, d1 = calendario[ix], calendario[ix + horizonte]
        fm = macro_m.fatores(fonte_macro, d0)
        pontos, retornos = [], {}
        for i in insts:
            c0, c1 = _preco_em(series[i["id"]], d0), _preco_em(series[i["id"]], d1)
            if not c0 or not c1 or c1[0] <= d0:
                continue
            retornos[i["id"]] = c1[4] / c0[4] - 1
            if len([c for c in series[i["id"]] if c[0] <= d0]) < config.MIN_CANDLES:
                continue
            res = pontuacao.calcular(pipeline.contexto(i, origem, d0, d0, bench, {}, fm, defasado=True))
            liq = res["dimensoes"]["liquidez"]["score"]
            if res["indice"] is not None and not res["bloqueado"] and res["qualidade"] >= 0.5 and (liq or 0) >= 40:
                pontos.append((res["indice"], i["id"]))
        if len(pontos) < 8:
            continue
        pontos.sort(reverse=True)
        k = max(3, int(len(pontos) * quantil))
        escolhidos = [i for _, i in pontos[:k]]
        elegiveis = [i for _, i in pontos]
        bruto = statistics.mean(retornos[i] for i in escolhidos)
        liquido = bruto - 2 * (custo + slippage)
        univ = statistics.mean(retornos[i] for i in elegiveis)
        aleat = [statistics.mean(retornos[i] for i in rng.sample(elegiveis, k)) - 2 * (custo + slippage) for _ in range(sorteios)]
        # baselines simples, nos MESMOS elegíveis, com os mesmos custos: se a IA não os supera, o índice não agrega valor
        mom, vol = {}, {}
        for i in elegiveis:
            fech = [c[4] for c in series[i][:bisect.bisect_right(datas_de[i], d0)]]
            if len(fech) >= 148 and fech[-148] > 0:
                mom[i] = fech[-22] / fech[-148] - 1                         # momentum 6 meses pulando o último mês
            v = tecnico.vol_anual(fech, 63)
            if v is not None:
                vol[i] = v
        if len(mom) >= k:
            top = sorted(mom, key=mom.get, reverse=True)[:k]
            baseline_ex["momentum"].append(statistics.mean(retornos[i] for i in top) - 2 * (custo + slippage) - univ)
        if len(vol) >= k:
            low = sorted(vol, key=vol.get)[:k]
            baseline_ex["baixa_volatilidade"].append(statistics.mean(retornos[i] for i in low) - 2 * (custo + slippage) - univ)
        periodos.append({"inicio": d0, "fim": d1, "n_universo": len(pontos), "n_carteira": k, "carteira": round(liquido, 5), "universo": round(univ, 5),
                         "excesso": round(liquido - univ, 5), "aleatorias": aleat})
    if len(periodos) < 3:
        return {"erro": "poucos períodos avaliáveis (precisa de mais histórico)", "n_periodos": len(periodos)}
    ex = [p["excesso"] for p in periodos]
    media_ex = statistics.mean(ex)
    dp = statistics.pstdev(ex)
    t = media_ex / (dp / math.sqrt(len(ex))) if dp > 0 else 0.0
    medias_alea = [statistics.mean(p["aleatorias"][s] - p["universo"] for p in periodos) for s in range(sorteios)]
    p_acaso = sum(1 for m in medias_alea if m >= media_ex) / sorteios
    acum, pico, mdd = 1.0, 1.0, 0.0
    for p in periodos:
        acum *= 1 + p["carteira"]
        pico = max(pico, acum)
        mdd = min(mdd, acum / pico - 1)
    acum_u = 1.0
    for p in periodos:
        acum_u *= 1 + p["universo"]
    baselines = {}
    for nome, xs in baseline_ex.items():
        if len(xs) >= 3:
            d = statistics.pstdev(xs)
            baselines[nome] = {"excesso_medio": round(statistics.mean(xs), 5), "t_estatistica": round(statistics.mean(xs) / (d / math.sqrt(len(xs))), 2) if d > 0 else 0.0, "n_periodos": len(xs)}
    supera = all(media_ex > b["excesso_medio"] for b in baselines.values()) if baselines else None
    if len(periodos) < 12:
        veredito = "INCONCLUSIVO: poucos períodos (menos de 12)"
    elif t >= 2 and p_acaso <= 0.05 and media_ex > 0:
        veredito = "há indício estatístico de vantagem (ainda assim: o passado não garante o futuro)"
    else:
        veredito = "SEM evidência de vantagem: o resultado é compatível com sorte"
    if "há indício" in veredito and supera is False:
        veredito += " — porém NÃO supera os baselines simples (momentum/baixa volatilidade): o índice não agrega valor sobre eles"
    if origem == "SIMULADO":
        veredito = "DEMONSTRAÇÃO — não vale como evidência (os dados têm tendências embutidas): " + veredito
    for p in periodos:
        del p["aleatorias"]
    r = {"origem": origem, "demo": origem == "SIMULADO", "parametros": {"horizonte": horizonte, "passo": passo, "quantil": quantil, "custo_por_lado": custo + slippage},
         "n_periodos": len(periodos), "retorno_medio_carteira": round(statistics.mean(p["carteira"] for p in periodos), 5), "retorno_medio_universo": round(statistics.mean(p["universo"] for p in periodos), 5),
         "excesso_medio": round(media_ex, 5), "t_estatistica": round(t, 2), "prob_ser_acaso": round(p_acaso, 3), "acumulado_carteira": round(acum - 1, 4),
         "acumulado_universo": round(acum_u - 1, 4), "max_drawdown_carteira": round(mdd, 4), "periodos_vencedores": sum(1 for e in ex if e > 0), "periodos": periodos,
         "baselines": baselines, "supera_baselines": supera, "veredito": veredito, "segundos": round(time.time() - t0, 1), "gerado_em": time.time(),
         "limitacoes": ["Sem impostos; custo e slippage fixos assumidos; ordens não são simuladas uma a uma.", "Balanços usados com defasagem de um ano (sem look-ahead).",
                        "Resultado depende do universo disponível." + (" ATENÇÃO: os dados de DEMONSTRAÇÃO têm tendências embutidas de propósito; qualquer vantagem aqui NÃO prova nada sobre o mercado real." if origem == "SIMULADO" else ""),
                        "Passado não garante futuro. Isto é apoio à decisão, não recomendação de investimento."]}
    db.cfg_set("ultimo_backtest", r)
    return r
