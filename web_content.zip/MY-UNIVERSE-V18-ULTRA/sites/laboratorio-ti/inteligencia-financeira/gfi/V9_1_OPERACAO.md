# Operação V9.1 — atualização automática

Na primeira inicialização após instalar a V9.1, a automação é ativada em 60 segundos se ainda não houver preferência gravada. Uma preferência existente é respeitada. Para ativar/desativar manualmente, use a rota `POST /api/live/auto` com `{"ativo":true,"intervalo_segundos":60}` ou `{"ativo":false,"intervalo_segundos":60}`.

O servidor deve permanecer ligado, o computador sem suspensão e a conexão com a internet disponível. O modo demonstração bloqueia coleta real. O painel `/api/v9/status` informa estado, universo cadastrado e último ciclo.

O intervalo é de disparo do orquestrador. O Yahoo Finance pode devolver snapshots atrasados, repetir o último ponto ou falhar. A automação não pode criar dados que a fonte ainda não publicou. O universo é percorrido em rodízio, não há promessa de que todos os ativos recebam um ponto novo a cada minuto.
