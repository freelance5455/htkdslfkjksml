"""Orquestrador automático da GFI: coleta intradiária em rodízio + recálculo dos modelos.

O relógio do ciclo é de 60 s. A cobertura de todo o universo depende do tamanho
cadastrado, da latência e dos limites do provedor; não promete cotação em tempo real.
"""
import threading
import time
from datetime import datetime, timezone

from . import catalogo, config, db, recursos, pipeline
from .conectores import yahoo_chart

_lock = threading.Lock()
_estado = {"ultima_execucao": None, "ultimo_resultado": None, "proxima_execucao": None,
           "executando": False, "ciclos": 0}
_fio = {"ativo": False}


def habilitado():
    return bool(db.cfg_get("live_auto_ativo", False)) and not bool(db.cfg_get("modo_demo", False))


def intervalo():
    try:
        return max(60, min(3600, int(db.cfg_get("live_auto_intervalo", 60))))
    except (TypeError, ValueError):
        return 60


def _hora(ts=None):
    return datetime.fromtimestamp(ts or time.time(), timezone.utc).isoformat(timespec="seconds")


def executar_ciclo(limite=None):
    """Executa um lote real, valida o resultado, atualiza os motores e registra auditoria."""
    if not _lock.acquire(blocking=False):
        return {"ok": False, "erro": "ciclo GFI já está em execução"}
    _estado["executando"] = True
    inicio = time.time()
    resultados = []
    try:
        if db.cfg_get("modo_demo", False):
            return {"ok": False, "erro": "modo demonstração ativo; coleta real bloqueada"}
        if recursos.sob_pressao():
            _estado["ultima_execucao"] = time.time()
            return {"ok": False, "adiado": True, "erro": "computador sob pressão; ciclo adiado"}

        todos = catalogo.listar("REAL", apenas_ativos=True)
        total = len(todos)
        if not total:
            resumo = {"ok": False, "erro": "nenhum instrumento REAL ativo B3 cadastrado",
                      "universo_total": 0, "sucessos": 0, "falhas": 0}
            _estado.update(ultima_execucao=time.time(), ultimo_resultado=resumo)
            return resumo

        limite = max(1, min(int(limite or config.LIVE_LIMITE), 500))
        cur = int(db.cfg_get("live_cursor", 0)) % total
        instrumentos = (todos[cur:] + todos[:cur])[:limite]
        db.cfg_set("live_cursor", (cur + len(instrumentos)) % total)
        # Reserva 10 s para persistência e recálculo; não inicia requisições sem tempo.
        orcamento = max(10.0, intervalo() - 10.0)
        for inst in instrumentos:
            if time.time() - inicio >= orcamento:
                break
            ticker = str(inst["ticker"]).upper()
            simbolo = ticker + ".SA" if inst.get("mic") in ("BVMF", "XBSP") or inst.get("pais") in ("BR", "BRA", "Brasil") else ticker
            try:
                r = yahoo_chart.coletar(int(inst["id"]), simbolo, "1d", "1mo")
                ultimo = r.get("ultimo_ponto") or {}
                resultados.append({"ticker": ticker, "ok": True,
                    "novos_registros": int(r.get("novos_registros", 0)),
                    "pontos_recebidos": int(r.get("pontos_recebidos", 0)),
                    "candles_diarios": int(r.get("candles_diarios", 0)),
                    "ultima_observacao": ultimo.get("observado_em"),
                    "estado": r.get("estado", "DELAYED")})
            except Exception as exc:
                resultados.append({"ticker": ticker, "ok": False,
                                   "erro": f"{type(exc).__name__}: {str(exc)[:180]}"})

        sucessos = sum(1 for x in resultados if x["ok"])
        falhas = len(resultados) - sucessos
        recalc = None
        erro_recalc = None
        if sucessos:
            try:
                # O pipeline avança em rodízio pelo universo REAL, não apenas pelo lote de preços.
                recalc = pipeline.recalcular(origem="REAL", lote=max(1, min(config.LIVE_LIMITE, 100)))
            except Exception as exc:
                erro_recalc = f"{type(exc).__name__}: {str(exc)[:180]}"

        resumo = {"ok": sucessos > 0 and erro_recalc is None, "inicio_utc": _hora(inicio),
                  "fim_utc": _hora(), "intervalo_segundos": intervalo(),
                  "universo_total": total, "cursor_inicial": cur,
                  "instrumentos_considerados": len(resultados), "sucessos": sucessos,
                  "falhas": falhas, "duracao_segundos": round(time.time()-inicio, 2),
                  "recalculo": recalc, "erro_recalculo": erro_recalc,
                  "classificacao_fonte": "DELAYED", "garantia_tempo_real": False,
                  "resultados": resultados}
        _estado.update(ultima_execucao=time.time(), ultimo_resultado=resumo,
                       ciclos=int(_estado.get("ciclos", 0)) + 1)
        db.cfg_set("live_auto_ultimo_resultado", resumo)
        db.log("INFO" if resumo["ok"] else "AVISO", "live_auto",
               f"ciclo {sucessos}/{len(resultados)} cotações; universo REAL ativo={total}; recálculo={recalc}; erro={erro_recalc}")
        return resumo
    finally:
        _estado["executando"] = False
        _lock.release()


def estado():
    total = len(catalogo.listar("REAL", apenas_ativos=True))
    return {"habilitado": habilitado(), "intervalo_segundos": intervalo(),
            "universo_real_ativo": total, "ultimo_resultado": _estado.get("ultimo_resultado") or db.cfg_get("live_auto_ultimo_resultado"),
            "ultima_execucao": _estado["ultima_execucao"],
            "proxima_execucao": (_estado["ultima_execucao"] + intervalo()) if _estado["ultima_execucao"] else None,
            "executando": _estado["executando"], "ciclos": _estado["ciclos"],
            "provedor": "Yahoo Finance Chart", "classificacao": "DELAYED",
            "modo_coleta": "candles diários OHLC para análise; snapshots intradiários permanecem separados",
            "garantia_tempo_real": False,
            "escopo": "cotações de instrumentos REAL ativos em rodízio + recálculo incremental do pipeline GFI; BCB/CVM/notícias respeitam a periodicidade de publicação das fontes"}


def configurar(ativo, intervalo_segundos=60):
    try:
        segundos = int(intervalo_segundos)
    except (TypeError, ValueError):
        raise ValueError("intervalo inválido")
    if segundos != 60:
        raise ValueError("na V9.1 o ciclo automático está fixado em 60 segundos")
    db.cfg_set("live_auto_intervalo", 60)
    db.cfg_set("live_auto_ativo", bool(ativo))
    return estado()


def iniciar():
    """Fio separado do servidor HTTP; ciclo inicia após ativação explícita/persistida."""
    if _fio["ativo"]:
        return
    _fio["ativo"] = True

    def laco():
        while True:
            time.sleep(1)
            try:
                ciclo_se_devido()
            except Exception as exc:
                db.log("ERRO", "live_auto", f"{type(exc).__name__}: {exc}")
    threading.Thread(target=laco, name="gfi-live-auto-v91", daemon=True).start()


def ciclo_se_devido():
    if not habilitado() or _estado["executando"]:
        return None
    agora = time.time()
    ultima = _estado["ultima_execucao"] or 0
    if agora - ultima < intervalo():
        return None
    return executar_ciclo()
