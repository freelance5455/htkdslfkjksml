"""Acesso a dados com corte temporal (`ate`): permite reconstruir a análise em qualquer data passada."""
from . import db


def candles(inst_id, ate=None, limite=1300):
    """Candles diários consolidados. B3 oficial prevalece em datas coincidentes;
    Yahoo complementa datas ausentes. Não mistura snapshots intradiários com candles.
    Retorna [(data, abertura, maxima, minima, fechamento, volume_fin, qtd)]."""
    sql = "SELECT data,abertura,maximo,minimo,fechamento,volume_fin,qtd FROM cotacoes WHERE instrumento_id=?"
    args = [inst_id]
    if ate:
        sql += " AND data<=?"
        args.append(ate)
    oficiais = db.consultar(sql + " ORDER BY data DESC LIMIT ?", args + [limite])
    por_data = {r["data"]: (r["data"], r["abertura"], r["maximo"], r["minimo"],
                             r["fechamento"], r["volume_fin"] or 0.0, r["qtd"] or 0.0)
                for r in oficiais}
    # O complemento externo é permitido somente para instrumentos REAL.
    inst = db.um("SELECT origem FROM instrumentos WHERE id=?", (inst_id,))
    if inst and inst["origem"] == "REAL":
        q = "SELECT data,abertura,maximo,minimo,fechamento,volume FROM cotacoes_provedor_diarias WHERE instrumento_id=?"
        a = [inst_id]
        if ate:
            q += " AND data<=?"
            a.append(ate)
        q += " ORDER BY data DESC LIMIT ?"
        for r in reversed(db.consultar(q, a + [limite])):
            # Nunca sobrescreve o registro oficial B3 na mesma data.
            por_data.setdefault(r["data"], (r["data"], r["abertura"], r["maximo"], r["minimo"],
                                             r["fechamento"], r["volume"] or 0.0, r["volume"] or 0.0))
    return [por_data[d] for d in sorted(por_data)][-limite:]


def fontes_candles(inst_id, ate=None):
    """Fontes efetivamente presentes na série diária usada pelo motor."""
    fontes = set()
    q = "SELECT COUNT(*) n FROM cotacoes WHERE instrumento_id=?" + (" AND data<=?" if ate else "")
    if (db.um(q, (inst_id, ate) if ate else (inst_id,)) or {}).get("n", 0):
        fontes.add("B3-COTAHIST")
    inst = db.um("SELECT origem FROM instrumentos WHERE id=?", (inst_id,))
    if inst and inst["origem"] == "REAL":
        q = "SELECT COUNT(*) n FROM cotacoes_provedor_diarias WHERE instrumento_id=?" + (" AND data<=?" if ate else "")
        if (db.um(q, (inst_id, ate) if ate else (inst_id,)) or {}).get("n", 0):
            fontes.add("YAHOO_FINANCE_CHART")
    return sorted(fontes)


def serie_macro(serie, fonte, ate=None):
    """Série oficial da fonte; no universo REAL, pontos de atualizações ativas (ATU:*) completam datas ausentes."""
    cond = "(fonte=? OR fonte LIKE 'ATU:%')" if fonte != "SIMULADO" else "fonte=?"
    sql, args = f"SELECT data,valor,fonte FROM macro WHERE serie=? AND {cond} AND estado='ok'", [serie, fonte]
    if ate:
        sql += " AND data<=?"
        args.append(ate)
    por_data = {}
    for r in db.consultar(sql + " ORDER BY data", args):
        if r["data"] not in por_data or r["fonte"] == fonte:
            por_data[r["data"]] = r["valor"]
    return sorted(por_data.items())


def fundamentos(inst_id, ate=None, defasado=False):
    """{periodo: {campo: valor}} — periodos como '2024' ou '2024T3'.
    defasado=True (backtest): só exercícios de anos ANTERIORES à data, pois o balanço anual só é publicado meses depois."""
    out = {}
    for r in db.consultar("SELECT periodo,campo,valor FROM fundamentos WHERE instrumento_id=? ORDER BY periodo", (inst_id,)):
        if ate and (r["periodo"][:4] >= ate[:4] if defasado else r["periodo"][:4] > ate[:4]):
            continue
        out.setdefault(r["periodo"], {})[r["campo"]] = r["valor"]
    return out


def eventos(inst_id=None, setor=None, pais=None, ate=None, dias=120, origem=None):
    sql = ("SELECT * FROM eventos WHERE origem=? AND publicado_em<=COALESCE(?, '9999') AND "
           "publicado_em>=date(COALESCE(?, date('now')), ?) AND (instrumento_id=?"
           + (" OR (instrumento_id IS NULL AND setor=?)" if setor else "")
           + (" OR (instrumento_id IS NULL AND setor IS NULL AND pais=?)" if pais else "") + ") ORDER BY publicado_em DESC")
    args = [origem, ate, ate, f"-{dias} day", inst_id] + ([setor] if setor else []) + ([pais] if pais else [])
    return db.consultar(sql, args)
