"""Validação de dados: inconsistências, desatualização e saltos suspeitos (possíveis desdobramentos)."""
from datetime import date

from . import config

_RAZOES = (2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50, 100)       # desdobramentos/grupamentos comuns na B3


def validar_candles(candles, referencia=None):
    """Devolve {problemas, qualidade (0–1), dias_defasagem, saltos}. Não altera os dados."""
    problemas, saltos = [], []
    if not candles:
        return {"problemas": ["sem cotações"], "qualidade": 0.0, "dias_defasagem": None, "desatualizado": True, "saltos": []}
    ruins = 0
    for i, (d, o, h, l, c, v, q) in enumerate(candles):
        if min(o, h, l, c) <= 0 or h < l or not (l - 1e-9 <= min(o, c) and max(o, c) <= h + 1e-9):
            ruins += 1
        if i and candles[i - 1][4] > 0:
            r = c / candles[i - 1][4]
            if r > 1.6 or r < 0.62:
                saltos.append({"data": d, "razao": round(r, 4), "provavel_evento": _razao_comum(r)})
    if ruins:
        problemas.append(f"{ruins} candle(s) inconsistente(s)")
    if saltos:
        problemas.append(f"{len(saltos)} salto(s) de preço suspeito(s) (possível desdobramento/grupamento não ajustado)")
    defas = None
    ref = date.fromisoformat(referencia) if referencia else date.fromisoformat(candles[-1][0])
    defas = (ref - date.fromisoformat(candles[-1][0])).days
    if defas > config.JANELA_ATUALIZADO_DIAS:
        problemas.append(f"dados desatualizados há {defas} dias")
    if len(candles) < config.MIN_CANDLES:
        problemas.append(f"histórico curto ({len(candles)} candles)")
    q = 1.0
    q -= min(0.5, ruins / max(1, len(candles)) * 10)
    q -= 0.25 if defas > config.JANELA_ATUALIZADO_DIAS else 0
    q -= 0.35 if len(candles) < config.MIN_CANDLES else 0
    q -= min(0.2, 0.05 * len(saltos))
    return {"problemas": problemas, "qualidade": round(max(0.0, q), 3), "dias_defasagem": defas,
            "desatualizado": defas > config.JANELA_ATUALIZADO_DIAS, "saltos": saltos}


def _razao_comum(r):
    inv = 1 / r if r < 1 else r
    for k in _RAZOES:
        if abs(inv - k) / k < 0.04:
            return k if r < 1 else -k      # +k: preço caiu k× (desdobramento); -k: subiu k× (grupamento)
    return None


def ajustar_saltos(candles):
    """Ajuste HEURÍSTICO (estimativa) de saltos que coincidem com razões comuns de desdobramento/grupamento.
    Devolve (candles_ajustados, datas_ajustadas). Só altera o passado anterior ao salto."""
    saltos = {s["data"]: s["razao"] for s in validar_candles(candles)["saltos"] if s["provavel_evento"]}
    if not saltos:
        return list(candles), []
    out, fator, datas = [], 1.0, []
    for i in range(len(candles) - 1, -1, -1):
        d, o, h, l, c, v, q = candles[i]
        out.append((d, o * fator, h * fator, l * fator, c * fator, v, q))
        if d in saltos:
            fator *= saltos[d]
            datas.append(d)
    out.reverse()
    return out, sorted(datas)
