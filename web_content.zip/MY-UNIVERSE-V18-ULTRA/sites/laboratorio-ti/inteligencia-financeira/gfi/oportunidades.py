"""Descoberta de oportunidades: rankings independentes com explicação. Quantidade de sinais verdes NÃO ordena nada."""
from . import config, pipeline


def _ok(r):
    return not r["bloqueado"] and r["qualidade"] >= 0.5 and r["inst"]["tipo"] != "indice"


def _s(r, k):
    return r["dimensoes"][k]["score"]


def _q(r):
    return 0.5 + 0.5 * r["qualidade"]          # qualidade/atualidade dos dados pesam no ranking


def _por_que(r, k):
    d = r["dimensoes"][k]
    fatos = [i["texto"] for i in d["itens"] if i["tipo"] in ("fato", "estimativa")][:2]
    return f"{config.ROTULOS[k]} {d['score']:.0f}: {d['razao']}" + (" — " + "; ".join(fatos) if fatos else "")


RANKINGS = {
    "fundamentos": ("Melhores fundamentos", lambda r: _s(r, "saude") * _q(r) if _s(r, "saude") is not None else None, lambda r: _por_que(r, "saude")),
    "valuation": ("Melhores oportunidades de valuation",
                  lambda r: (_s(r, "valuation") + 20 * max(-0.5, min(0.5, r["metricas"]["margem_dcf"] or 0))) * _q(r)
                  if _s(r, "valuation") is not None and not r["metricas"]["armadilha"] else None, lambda r: _por_que(r, "valuation")),
    "crescimento": ("Maior crescimento", lambda r: _s(r, "crescimento") * _q(r) if _s(r, "crescimento") is not None else None, lambda r: _por_que(r, "crescimento")),
    "risco_retorno": ("Melhor relação risco-retorno histórica", lambda r: (r["metricas"]["retorno_risco"] or None) and r["metricas"]["retorno_risco"] * _q(r)
                      if (_s(r, "liquidez") or 0) >= 40 else None,
                      lambda r: f"Retorno/risco histórico {r['metricas']['retorno_risco']:.2f} (sem taxa livre de risco; passado não garante futuro)"),
    "recuperacao": ("Empresas em recuperação", lambda r: (r["metricas"]["dd_atual"] is not None and r["metricas"]["dd_atual"] < -0.2 and
                                                            (r["metricas"]["ret_3m"] or 0) > 0.08 and (_s(r, "tecnica") or 0) >= 50) and (r["metricas"]["ret_3m"] * 100) * _q(r) or None,
                    lambda r: f"Queda de {r['metricas']['dd_atual'] * 100:.0f}% desde a máxima 12 m e alta de {r['metricas']['ret_3m'] * 100:.0f}% em 3 meses"),
    "deterioracao": ("Empresas com deterioração", lambda r: (100 - min(_s(r, "saude") or 100, _s(r, "tecnica") or 100)) if
                     ((_s(r, "saude") is not None and _s(r, "saude") < 45) or r["metricas"]["armadilha"]) else None,
                     lambda r: "; ".join(r["respostas"]["3_negativos"][:2]) or "sinais fundamentais em queda"),
    "tendencia": ("Empresas com tendência positiva", lambda r: _s(r, "tecnica") * _q(r) if (_s(r, "tecnica") or 0) >= 60 else None, lambda r: _por_que(r, "tecnica")),
    "dividendos": ("Oportunidades de dividendos", lambda r: (r["metricas"]["dy"] or 0) * 1000 * _q(r) if (r["metricas"]["dy"] or 0) > 0 and
                   (_s(r, "saude") or 0) >= 50 and r["metricas"]["fcf_positivo"] else None,
                   lambda r: f"Dividend yield {r['metricas']['dy'] * 100:.1f}% com saúde financeira {_s(r, 'saude'):.0f} e FCF positivo"),
    "longo_prazo": ("Oportunidades de longo prazo", lambda r: ((_s(r, "longo_prazo") or 0) * 0.6 + (_s(r, "saude") or 0) * 0.4) * _q(r)
                    if _s(r, "longo_prazo") is not None else None, lambda r: _por_que(r, "longo_prazo")),
    "medio_prazo": ("Oportunidades de médio prazo",
                    lambda r: ((_s(r, "tecnica") or 0) * 0.30 + (_s(r, "crescimento") or 0) * 0.30 +
                               (_s(r, "saude") or 0) * 0.25 + (_s(r, "valuation") or 0) * 0.15) * _q(r)
                    if _s(r, "tecnica") is not None and _s(r, "saude") is not None else None,
                    lambda r: "Combina tendência técnica, crescimento, saúde financeira e valuation; " +
                              "; ".join([_por_que(r, k) for k in ("tecnica", "crescimento", "saude") if _s(r, k) is not None][:2])),
    "curto_prazo": ("Oportunidades de curto prazo", lambda r: (r["metricas"]["ret_1m"] is not None and (_s(r, "tecnica") or 0) >= 55 and
                                                               (_s(r, "liquidez") or 0) >= 60) and _s(r, "tecnica") * _q(r) or None, lambda r: _por_que(r, "tecnica")),
    "geral": ("Maior índice geral (com cobertura e qualidade)", lambda r: r["indice"] * _q(r) if r["indice"] is not None else None,
              lambda r: r["respostas"]["1_por_que"]),
}


def _filtros(r, f):
    m, i = r["metricas"], r["inst"]
    if f.get("pais") and i["pais"] != f["pais"]:
        return False
    if f.get("setor") and i["setor"] != f["setor"]:
        return False
    if f.get("tipo") and i["tipo"] != f["tipo"]:
        return False
    if f.get("indice_min") is not None and (r["indice"] is None or r["indice"] < f["indice_min"]):
        return False
    if f.get("risco_max") is not None and (m["vol_anual"] is None or m["vol_anual"] > f["risco_max"]):
        return False
    if f.get("liquidez_min") is not None and (m["liquidez"] or 0) < f["liquidez_min"]:
        return False
    if f.get("qualidade_min") is not None and r["qualidade"] < f["qualidade_min"]:
        return False
    if f.get("min_verdes") is not None and r["contagem"]["verde"] < f["min_verdes"]:
        return False
    return True


def ranking(tipo="geral", n=20, filtros=None, origem=None):
    nome, valor, porque = RANKINGS[tipo]
    linhas = []
    for r in pipeline.ultimas(origem):
        if not _ok(r) or not _filtros(r, filtros or {}):
            continue
        try:
            v = valor(r)
        except (TypeError, KeyError):
            v = None
        if v:
            linhas.append((v, r))
    linhas.sort(key=lambda x: -x[0])
    return {"ranking": tipo, "titulo": nome, "n": n, "total_elegiveis": len(linhas),
            "itens": [{"posicao": k + 1, "valor": round(v, 2), "id": r["inst"]["id"], "ticker": r["inst"]["ticker"], "nome": r["inst"]["nome"],
                       "setor": r["inst"]["setor"], "pais": r["inst"]["pais"], "indice": r["indice"], "luz": r["luz"], "qualidade": r["qualidade"],
                       "por_que": porque(r), "verdes": r["contagem"]["verde"]} for k, (v, r) in enumerate(linhas[:n])]}
