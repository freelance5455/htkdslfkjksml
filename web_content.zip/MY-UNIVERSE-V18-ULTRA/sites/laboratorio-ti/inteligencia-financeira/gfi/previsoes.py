"""Registro IMUTÁVEL de previsões (cadeia de hashes + gatilhos no banco) e avaliação posterior contra o resultado real.
Não há probabilidades: só direção esperada em um horizonte, produzida por regras documentadas."""
import hashlib
import json
import math
import time

from . import config, dados, db

HORIZONTE = 21          # pregões


def direcao(res):
    t = res["dimensoes"]["tecnica"]["score"]
    if res["bloqueado"] or (t is not None and t < 42):
        return "baixa"
    if t is not None and t >= 60 and (res["indice"] or 0) >= 55:
        return "alta"
    return "neutra"


def _hash(ant, campos):
    return hashlib.sha256((ant + json.dumps(campos, sort_keys=True, separators=(",", ":"))).encode()).hexdigest()


def registrar(inst_id, data_base, base_preco, res, horizonte=HORIZONTE):
    """Grava uma previsão por (instrumento, data_base, horizonte). Devolve o id ou None se já existir."""
    if db.um("SELECT 1 x FROM previsoes WHERE instrumento_id=? AND data_base=? AND horizonte_dias=?", (inst_id, data_base, horizonte)):
        return None
    payload = {"indice": res["indice"], "luz": res["luz"], "tecnica": res["dimensoes"]["tecnica"]["score"], "bloqueado": res["bloqueado"],
               "metodo": "regras determinísticas (sem probabilidade)"}
    ult = db.um("SELECT hash FROM previsoes ORDER BY id DESC LIMIT 1")
    ant = ult["hash"] if ult else "0" * 64
    campos = {"i": inst_id, "d": data_base, "h": horizonte, "dir": direcao(res), "p": base_preco, "v": config.VERSAO_MODELO, "pl": payload}
    return db.executar("INSERT INTO previsoes(instrumento_id,criado_em,data_base,horizonte_dias,direcao,base_preco,versao_modelo,payload,"
                       "hash_ant,hash) VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (inst_id, time.time(), data_base, horizonte, campos["dir"], base_preco, config.VERSAO_MODELO,
                        json.dumps(payload, sort_keys=True), ant, _hash(ant, campos)))


def verificar_cadeia():
    """Recalcula todos os hashes. Devolve (ok, id_do_primeiro_registro_adulterado)."""
    ant = "0" * 64
    for r in db.consultar("SELECT * FROM previsoes ORDER BY id"):
        campos = {"i": r["instrumento_id"], "d": r["data_base"], "h": r["horizonte_dias"], "dir": r["direcao"], "p": r["base_preco"],
                  "v": r["versao_modelo"], "pl": json.loads(r["payload"])}
        if r["hash_ant"] != ant or r["hash"] != _hash(ant, campos):
            return False, r["id"]
        ant = r["hash"]
    return True, None


def avaliar_vencidas():
    """Avalia previsões cujo horizonte já foi coberto por cotações. Cada avaliação é gravada uma única vez."""
    n = 0
    for p in db.consultar("SELECT p.* FROM previsoes p LEFT JOIN avaliacoes a ON a.previsao_id=p.id WHERE a.id IS NULL"):
        fut = [c for c in dados.candles(p["instrumento_id"], limite=2000) if c[0] > p["data_base"]]
        if len(fut) < p["horizonte_dias"]:
            continue
        pf = fut[p["horizonte_dias"] - 1][4]
        ret = pf / p["base_preco"] - 1
        ok = ret > 0 if p["direcao"] == "alta" else ret < 0 if p["direcao"] == "baixa" else abs(ret) <= 0.05
        db.executar("INSERT INTO avaliacoes(previsao_id,avaliado_em,preco_final,retorno,acertou,detalhe) VALUES(?,?,?,?,?,?)",
                    (p["id"], time.time(), pf, ret, int(ok), json.dumps({"data_final": fut[p["horizonte_dias"] - 1][0]})))
        n += 1
    return n


def metricas():
    linhas = db.consultar("SELECT p.direcao, a.retorno, a.acertou, p.payload FROM avaliacoes a JOIN previsoes p ON p.id=a.previsao_id ORDER BY a.id")
    tot = len(linhas)
    base = {"previsoes_registradas": db.um("SELECT COUNT(*) n FROM previsoes")["n"], "avaliadas": tot}
    if not tot:
        return {**base, "acerto_ingenuo": None, "vantagem": None, "z": None, "evidencia": "insuficiente (sem previsões avaliadas)", "taxa_acerto": None, "por_direcao": {}, "falsos_positivos": 0, "falsos_negativos": 0, "taxa_base_alta": None,
                "excesso_confianca": None, "degradacao": None}
    por = {}
    for d in ("alta", "baixa", "neutra"):
        sub = [x for x in linhas if x["direcao"] == d]
        por[d] = {"n": len(sub), "acerto": round(sum(x["acertou"] for x in sub) / len(sub), 3) if sub else None}
    fp = sum(1 for x in linhas if x["direcao"] == "alta" and x["retorno"] <= 0)
    fn = sum(1 for x in linhas if x["direcao"] != "alta" and x["retorno"] > 0.05)
    base_alta = sum(1 for x in linhas if x["retorno"] > 0) / tot
    altos = [x for x in linhas if (json.loads(x["payload"]).get("indice") or 0) >= 70]
    acerto = sum(x["acertou"] for x in linhas) / tot
    exc = None
    if len(altos) >= 10:
        exc = round(acerto - sum(x["acertou"] for x in altos) / len(altos), 3)       # >0: índices altos não acertam mais que a média
    ult = linhas[-max(10, tot // 4):]
    degr = round(sum(x["acertou"] for x in ult) / len(ult) - acerto, 3) if tot >= 40 else None
    # comparação com estratégias ingênuas: sempre "alta", sempre "baixa" ou sempre "neutra"
    ing = max(base_alta, sum(1 for x in linhas if x["retorno"] < 0) / tot, sum(1 for x in linhas if abs(x["retorno"]) <= 0.05) / tot)
    z = (acerto - ing) / math.sqrt(max(ing * (1 - ing), 1e-9) / tot)
    evid = ("insuficiente (menos de 30 previsões avaliadas)" if tot < 30 else
            "há indício de vantagem sobre a estratégia ingênua" if z >= 1.64 else "SEM evidência de vantagem sobre a estratégia ingênua")
    return {**base, "acerto_ingenuo": round(ing, 3), "vantagem": round(acerto - ing, 3), "z": round(z, 2), "evidencia": evid,
            "taxa_acerto": round(acerto, 3), "por_direcao": por, "falsos_positivos": fp, "falsos_negativos": fn,
            "taxa_base_alta": round(base_alta, 3), "excesso_confianca": exc, "degradacao": degr}
