# MY UNIVERSE — Inteligência Financeira — V4

## Escopo

Agendamento opcional de coleta intradiária, reutilizando o conector Yahoo Finance da V3, o armazenamento `gfi.live` da V2 e o agendador existente. Nenhum motor de análise, ranking, previsão ou banco diário foi substituído.

## Implementado

- `gfi/live_auto.py`: ciclo automático com trava contra execução concorrente, intervalo configurável de 60 a 3600 segundos, limite de ativos por ciclo e isolamento de falhas por ticker.
- Reutiliza `catalogo.listar("REAL")`, `yahoo_chart.coletar()` e `live.registrar()`; não cria fonte paralela nem gera preços fictícios.
- Integração com o loop do agendador existente.
- `GET /api/live/status`: estado do agendamento, intervalo, última execução e classificação do feed.
- `POST /api/live/auto`: ativar/desativar e configurar intervalo.
- Coleta automática desligada por padrão e bloqueada no modo demonstração.
- Apenas instrumentos ativos da B3 (MIC BVMF/XBSP) recebem sufixo `.SA`; outros mercados são ignorados.
- Falhas individuais são registradas e não interrompem o restante do lote.

## Ativação

```bash
curl -sS http://127.0.0.1:8780/api/live/status
curl -sS -X POST http://127.0.0.1:8780/api/live/auto \\
  -H 'Content-Type: application/json' -H 'X-GFI: 1' \\
  -d '{"ativo": true, "intervalo_segundos": 60}'
```

Desativar:

```bash
curl -sS -X POST http://127.0.0.1:8780/api/live/auto \\
  -H 'Content-Type: application/json' -H 'X-GFI: 1' \\
  -d '{"ativo": false}'
```

## Limitações

- O intervalo de 60 segundos é a frequência de tentativa de coleta, não uma promessa de que o provedor entregará um novo candle a cada minuto.
- Yahoo Finance é uma fonte pública sem SLA; o sistema classifica o feed como `DELAYED` e nunca como tempo real garantido.
- A coleta depende de internet e de tickers reais já cadastrados no catálogo.
- A validação automatizada usa respostas simuladas nos testes; a conexão externa real precisa ser validada no computador que executará o sistema.

## Compatibilidade e testes

- Mantidos os módulos e rotas das versões anteriores.
- Compilação Python: `python3 -m compileall -q gfi servidor.py`.
- Testes: `python3 -m unittest discover -s testes -t .` — 77 testes aprovados neste pacote.
