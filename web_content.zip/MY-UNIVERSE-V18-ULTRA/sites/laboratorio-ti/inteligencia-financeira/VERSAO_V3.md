# MY UNIVERSE — Inteligência Financeira — V3

## Escopo

A V3 adiciona um adaptador de coleta intradiária para Yahoo Finance Chart API e integra o fluxo ao armazenamento `cotacoes_intradiarias` criado na V2.

## O que foi implementado

- `gfi/conectores/yahoo_chart.py`: consulta Chart API pública, valida símbolo/intervalo/período, interpreta timestamps, preço de fechamento e volume.
- Persistência no módulo existente `gfi.live`, mantendo provedor, horário observado, horário coletado, preço, volume e estado.
- Restrição de coleta a instrumentos cadastrados como `REAL` e ativos; o símbolo externo precisa corresponder ao ticker cadastrado.
- Registro de sucesso/erro na tabela de coletas existente.
- `POST /api/live/coletar`: recebe `instrumento_id`, `simbolo` (ex.: `PETR4.SA`), `intervalo` (`1m`, `5m`, `15m`, `30m`, `60m` ou `1d`) e `periodo` (`1d`, `5d` ou `1mo`).
- `GET /api/live/{instrumento_id}`: consulta snapshots e resumo de cobertura.
- Testes automatizados para parsing, validação, persistência e proteção contra símbolo de outro ativo.

## Como testar no computador do usuário

1. Inicie o GFI normalmente.
2. Identifique o ID de um instrumento REAL ativo no banco `dados/gfi.db`.
3. Envie uma coleta local (substitua `ID` pelo ID real):

```bash
curl -sS -X POST http://127.0.0.1:8780/api/live/coletar \
  -H 'Content-Type: application/json' -H 'X-GFI: 1' \
  -d '{"instrumento_id": ID, "simbolo": "PETR4.SA", "intervalo": "1m", "periodo": "1d"}'
```

4. Consulte o histórico:

```bash
curl -sS http://127.0.0.1:8780/api/live/ID
```

## Limitações importantes

- O adaptador usa uma fonte pública sem contrato de disponibilidade, SLA ou garantia de atraso fixo.
- A coleta manual via API está implementada; agendamento automático por minuto e painel visual ficam para a V4.
- A API pública pode bloquear, limitar, alterar ou retirar acesso. Falhas são registradas; não são substituídas por dados simulados.
- O estado é marcado conservadoramente como `DELAYED`; isso não significa que o atraso real seja conhecido. A aplicação não deve apresentar esses dados como tempo real garantido.
- A consulta real à fonte externa precisa ser executada na máquina do usuário, pois o ambiente de teste desta entrega não tem acesso externo garantido.

## Testes desta versão

`python -m unittest discover -s testes -v` — 73 testes aprovados, incluindo os 5 novos testes do adaptador.
