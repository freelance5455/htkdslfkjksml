#!/usr/bin/env bash
# Assistente de ativação local da GFI AI. Não instala nem baixa nada sem confirmação.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

BASE_URL="http://127.0.0.1:11434"
MODELO="${GFI_AI_MODELO_LOCAL:-}"

mem_gb="$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo 2>/dev/null || echo 0)"
if [[ -z "$MODELO" ]]; then
  if (( mem_gb >= 12 )); then MODELO="qwen2.5:7b"; else MODELO="qwen2.5:3b"; fi
fi

if ! command -v ollama >/dev/null 2>&1; then
  echo "Ollama não está instalado. Ele fornece o motor local de IA para a GFI."
  echo "Instalação oficial: https://ollama.com/download"
  read -r -p "Deseja instalar agora? [s/N] " resposta
  [[ "$resposta" =~ ^[sS]$ ]] || { echo "Instalação cancelada; nenhum arquivo foi alterado."; exit 0; }
  command -v curl >/dev/null 2>&1 || { echo "Instale curl primeiro." >&2; exit 1; }
  curl -fsSL https://ollama.com/install.sh -o /tmp/gfi-ollama-install.sh
  bash /tmp/gfi-ollama-install.sh
  rm -f /tmp/gfi-ollama-install.sh
fi

if ! curl -fsS "$BASE_URL/api/tags" >/dev/null 2>&1; then
  echo "Iniciando o serviço Ollama..."
  nohup ollama serve >/tmp/gfi-ollama.log 2>&1 &
  for _ in $(seq 1 20); do
    sleep 1
    curl -fsS "$BASE_URL/api/tags" >/dev/null 2>&1 && break
  done
fi

if ! curl -fsS "$BASE_URL/api/tags" >/dev/null 2>&1; then
  echo "O serviço Ollama não respondeu. Consulte /tmp/gfi-ollama.log." >&2
  exit 1
fi

if ! ollama list | awk 'NR>1 {print $1}' | grep -Fxq "$MODELO"; then
  echo "A GFI precisa de um modelo de linguagem. Modelo selecionado: $MODELO"
  echo "O download pode ocupar alguns GB e depende da sua conexão."
  read -r -p "Deseja baixar esse modelo agora? [s/N] " resposta
  [[ "$resposta" =~ ^[sS]$ ]] || { echo "Modelo não baixado. A central continuará em modo de diagnóstico."; exit 0; }
  ollama pull "$MODELO"
fi

if ollama list | awk 'NR>1 {print $1}' | grep -Fxq "$MODELO"; then
  echo "Modelo instalado: $MODELO"
  echo "A GFI detectará o Ollama automaticamente em $BASE_URL."
  echo "Reinicie o servidor da GFI e abra Central IA GFI para confirmar o estado conectado."
else
  echo "Não foi possível confirmar a instalação do modelo." >&2
  exit 1
fi
