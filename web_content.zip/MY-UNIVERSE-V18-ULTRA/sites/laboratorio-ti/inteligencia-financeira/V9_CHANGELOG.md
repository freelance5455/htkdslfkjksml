# V9 changelog
- Mantida a V8 como base cumulativa.
- Criado `gfi/v9.py` para notícias, busca geral, atualização de cotações e carteira isolada.
- Adicionadas rotas API, controles de topo e metadados de atualização.
- Ligada a seção 07 — Notícias a RSS público.
- Restaurado o fundo próprio da GFI; fundo geral do portal preservado.
