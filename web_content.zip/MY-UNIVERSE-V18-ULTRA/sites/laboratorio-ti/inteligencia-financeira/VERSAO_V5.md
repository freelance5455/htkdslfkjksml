# V5 — Fase 2: fortalecimento da coleta de dados

Estado: **em desenvolvimento**. Esta entrega parcial mantém a arquitetura V1–V4 e revisa os conectores já existentes.

## Alterações realizadas

### B3 COTAHIST
- Corrigido o endereço padrão do arquivo anual para `https://bvmf.bmfbovespa.com.br/InstDados/SerHist/COTAHIST_A{ano}.ZIP`.
- Validação de data real do pregão, ticker não vazio, OHLC coerente e volume/quantidade não negativos.
- ZIP passa por verificação de integridade CRC.
- ZIP sem arquivo identificável como COTAHIST é rejeitado em vez de ser tratado como coleta vazia.
- BDI 96 (mercado fracionário) é excluído da importação junto ao lote padrão, pois a tabela histórica identifica o instrumento por ticker/data e não distingue BDI.

### Banco Central — SGS
- Parser aceita `bytes` e texto UTF-8.
- Exige lista JSON.
- Valida datas no formato `DD/MM/YYYY`.
- Normaliza números com vírgula decimal e separador de milhar brasileiro.
- Descarta NaN/Infinity e registros malformados.
- Ordena e elimina observações repetidas pela data.

### Transporte HTTP
- Mantidos timeout, intervalo por host e limite de tamanho.
- Resposta HTTP fora de 2xx, vazia ou maior que o limite é rejeitada.
- Diagnóstico da B3 atualizado para o mesmo endereço do conector.

## Testes executados

- `python -m compileall -q gfi servidor.py` — aprovado.
- `python -m unittest discover -s testes -t .` — **84 testes aprovados**.
- Cobertura adicional: dados SGS em bytes, decimal brasileiro, JSON inválido, NaN, datas inválidas, candle COTAHIST inconsistente e ZIP sem membro COTAHIST.

## Limitações e pendências

- A rede deste ambiente falhou com `Temporary failure in name resolution`; não foi possível confirmar downloads reais B3/BCB.
- O teste de conectividade deve ser executado no computador que hospedará o GFI.
- A validação de periodicidade, unidade e códigos de todas as séries SGS ainda precisa de auditoria específica.
- A ingestão incremental e o backfill B3 ainda precisam de revisão.
- A coleta automática de fundamentos CVM (DFP/ITR) ainda não foi implementada.

## Preservação

Esta é uma evolução do pacote V4 completo. Não foram removidos módulos nem reestruturado o projeto em paralelo. A versão anterior permanece disponível separadamente.

## Verificação HTTP local

Servidor iniciado com banco temporário e porta isolada (`8878`):
- `GET /` — HTTP 200.
- `GET /api/live/status` — HTTP 200 (compatibilidade V4 preservada).
- `GET /api/diagnostico` — HTTP 200 (rota de diagnóstico preservada).

O processo de teste foi encerrado após a verificação. O banco temporário não foi incorporado ao pacote.
