# MY UNIVERSE — V6.05

**Foco:** corrigir o ciclo de vida das conexões SQLite da memória da NEXUS, preservando o restante da V6.04.

## Alterações

- `nexus/memoria.py`: `_con()` passou a ser um gerenciador de contexto que sempre fecha a conexão.
- Em operações concluídas, a transação recebe `commit`; em exceções, recebe `rollback`; em ambos os casos, a conexão é fechada.
- `nexus/tests/test_nexus.py`: teste de regressão confirma que a conexão não pode ser reutilizada após sair do contexto.
- Nenhuma alteração na lógica de classificação, aprendizagem, mutação, promoção, memória semântica ou rotas da API.

## Verificações executadas

- Compilação sintática de 55 arquivos Python: aprovada.
- GFI: 98 testes aprovados.
- NEXUS API/memória: 7 testes aprovados.
- NEXUS evolução: 3 testes direcionados aprovados.
- Teste manual de fechamento da conexão SQLite: aprovado (`sqlite3.ProgrammingError` ao tentar reutilizar conexão fechada).

## Limitação conhecida

A suíte completa de testes da NEXUS foi iniciada, mas excedeu o limite de execução desta revisão. Portanto, esta versão não declara todos os testes da NEXUS aprovados. O teste de ponta a ponta com o modelo local `llama-server` também permanece pendente.

## Preservação

Esta versão parte integralmente do pacote V6.04. A única alteração funcional é o gerenciamento explícito do ciclo de vida das conexões SQLite da NEXUS, além do teste de regressão e desta documentação.
