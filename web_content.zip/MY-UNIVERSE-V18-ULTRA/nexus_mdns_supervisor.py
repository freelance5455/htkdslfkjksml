#!/usr/bin/env python3
"""Mantém nexus.local e gfi.nexus.local publicados pelo Avahi, inclusive após DHCP."""
from __future__ import annotations
import ipaddress
import os
import re
import signal
import socket
import subprocess
import time

NAMES = ("nexus.local", "gfi.nexus.local")
PUBLISHER = os.environ.get("AVAHI_PUBLISH_ADDRESS", "avahi-publish-address")
children: list[subprocess.Popen] = []
stop_requested = False


def log(message: str) -> None:
    print(f"[NEXUS mDNS V14] {message}", flush=True)


def local_ipv4() -> str | None:
    try:
        route = subprocess.run(["ip", "-4", "route", "get", "1.1.1.1"], capture_output=True, text=True, timeout=3, check=False)
        match = re.search(r"\bsrc\s+(\d{1,3}(?:\.\d{1,3}){3})\b", route.stdout)
        if match:
            address = ipaddress.ip_address(match.group(1))
            if not (address.is_loopback or address.is_link_local or address.is_unspecified or address.is_multicast):
                return str(address)
    except (OSError, subprocess.TimeoutExpired):
        pass
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("1.1.1.1", 80))
            address = ipaddress.ip_address(sock.getsockname()[0])
            return str(address) if not (address.is_loopback or address.is_link_local or address.is_unspecified or address.is_multicast) else None
    except OSError:
        return None


def stop_publishers() -> None:
    global children
    for proc in children:
        if proc.poll() is None:
            proc.terminate()
    for proc in children:
        if proc.poll() is None:
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
    children = []


def request_stop(_signum, _frame) -> None:
    global stop_requested
    stop_requested = True


def main() -> int:
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    current_ip = None
    try:
        while not stop_requested:
            ip = local_ipv4()
            if not ip:
                log("Aguardando endereço IPv4 da rede.")
                time.sleep(5)
                continue
            if ip != current_ip or any(p.poll() is not None for p in children):
                stop_publishers()
                current_ip = ip
                log(f"Publicando os aliases em {ip}.")
                for name in NAMES:
                    proc = subprocess.Popen([PUBLISHER, "-R", name, ip])
                    children.append(proc)
                time.sleep(2)
                failed = [(NAMES[i], p.returncode) for i, p in enumerate(children) if p.poll() is not None]
                if failed:
                    log(f"Falha ao publicar: {failed}. Nova tentativa em 5 segundos.")
                    stop_publishers()
                    current_ip = None
                    time.sleep(5)
                    continue
                log("Publicadores ativos; monitorando IP e processos.")
            time.sleep(5)
        return 0
    finally:
        stop_publishers()
        log("Publicadores encerrados.")


if __name__ == "__main__":
    raise SystemExit(main())
