#!/usr/bin/env bash
# Migra dados da instalação MY UNIVERSE anterior para V15. A instalação anterior é a origem autoritativa dos dados do usuário.
set -euo pipefail
if [[ $# -ne 1 || ! -d "$1" ]]; then
  echo "Uso: $0 /caminho/da/instalacao/V13" >&2
  exit 2
fi
ORIGEM="$(cd "$1" && pwd -P)"
DESTINO="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
[[ "$ORIGEM" != "$DESTINO" ]] || { echo 'Origem e destino são a mesma pasta.' >&2; exit 2; }
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$DESTINO/../MY-UNIVERSE-V15-BACKUP-MIGRACAO-$STAMP"
BACKUP_FEITO=0
for rel in dados nexus/data sites/laboratorio-ti/inteligencia-financeira/dados sites/laboratorio-ti/inteligencia-financeira/atualizacoes; do
  if [[ -d "$ORIGEM/$rel" ]]; then
    mkdir -p "$DESTINO/$(dirname -- "$rel")"
    if [[ -e "$DESTINO/$rel" ]]; then
      mkdir -p "$BACKUP/$(dirname -- "$rel")"
      cp -a "$DESTINO/$rel" "$BACKUP/$rel"
      BACKUP_FEITO=1
      cp -a "$ORIGEM/$rel/." "$DESTINO/$rel/"
      echo "Mesclado: $rel (dados da V13 prevalecem; arquivos exclusivos da V14 são mantidos)"
    else
      cp -a "$ORIGEM/$rel" "$DESTINO/$rel"
      echo "Preservado: $rel"
    fi
  fi
done
if [[ "$BACKUP_FEITO" -eq 1 ]]; then echo "Backup pré-migração: $BACKUP"; fi
[[ -f "$DESTINO/dados/usuario.json" ]] && echo 'Conta do portal migrada.' || echo 'AVISO: dados/usuario.json não foi encontrado; execute ./iniciar.sh para criar a conta do portal.'
echo 'Migração para V15 concluída. Mantenha a instalação anterior até validar a nova.'
