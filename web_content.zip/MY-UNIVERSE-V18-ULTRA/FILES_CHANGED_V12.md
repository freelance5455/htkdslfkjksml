# Arquivos alterados na V12
- `sites/laboratorio-ti/inteligencia-financeira/gfi/v9.py`: persistência e atualização de cotações da carteira; patrimônio e rentabilidade.
- `sites/laboratorio-ti/inteligencia-financeira/gfi/api.py`: ação POST para atualizar cotações da carteira.
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.js`: carteira, comparação de posições, indicador global e atualização automática.
- `sites/laboratorio-ti/inteligencia-financeira/ui/index.html`: indicador global com percentual.
- `sites/laboratorio-ti/inteligencia-financeira/ui/app.css`: cores de ganho/perda no patrimônio global.
- `sites/laboratorio-ti/inteligencia-financeira/VERSAO_V12.md`: documentação da versão.
- `MY_UNIVERSE_V12_BUILD_REPORT.md`: relatório de construção.
