# MY UNIVERSE — V6.08

Base: V6.06. Esta revisão amplia o NEXUS com o **Autonomous Evolution Engine (AEE)**, um fluxo de engenharia assistida por modelo local para analisar o portal, preparar propostas de melhoria, validar limites e aplicar alterações somente após aprovação humana.

## Novidades

- Inventário de HTML, CSS e JavaScript de `assets/` e `sites/`, com tamanho e SHA-256.
- Geração de propostas por modelo local compatível com a API do llama.cpp.
- Área isolada de candidatos em `nexus/data/aee/candidatos/`.
- Revisão de cada proposta na interface NEXUS.
- Aplicação explícita pelo usuário, com cópia ZIP dos arquivos originais em `nexus/data/aee/backups/`.
- Verificação de hash da versão-base para impedir aplicar uma proposta obsoleta.
- Allowlist impede o AEE de escrever em servidor, núcleo guardião, configuração, dados, credenciais ou arquivos ocultos.
- O mecanismo anterior de evolução do classificador continua separado e preservado.

## Limites e operação

- A geração de propostas exige um `llama-server` local acessível pela configuração atual do NEXUS.
- O AEE não altera pesos do modelo de IA; ele usa o modelo disponível para propor mudanças de código/conteúdo.
- O AEE desta versão modifica apenas arquivos existentes de interface/conteúdo (`assets/*.js`, `assets/*.css`, `sites/**` com HTML/JS/CSS e `nexus.html`).
- Cada proposta precisa de aprovação explícita. A aprovação cria backup antes de copiar os arquivos candidatos.
- O inventário não significa que todos os arquivos foram compreendidos em profundidade: o contexto enviado ao modelo é limitado para caber em modelos locais.

## Rotas adicionadas

- `GET /api/nexus/engenharia/estado`
- `POST /api/nexus/engenharia/analisar`
- `POST /api/nexus/engenharia/propor` — `{ "objetivo": "..." }`
- `POST /api/nexus/engenharia/aplicar` — `{ "id": "..." }`

## Verificações desta revisão

A registrar após execução da suíte integral e verificações estáticas na V6.08 final.
