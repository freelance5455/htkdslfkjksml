# MY UNIVERSE V18 ULTRA — Android

## O que o app faz

O app tem shell nativo Android, tela inicial própria e cinco destinos no dock: Início, NEXUS, Projetos, GFI e Ajustes. Login e sessão usam as rotas já existentes no `server.py`. As páginas de NEXUS e Projetos são exibidas em WebView dentro do app, mantendo o código e os dados no computador. O dashboard e a navegação principal são nativos.

## Requisitos de build

- Android Studio recente
- Android SDK Platform 35
- JDK 17
- Android Gradle Plugin 8.9.2 (Gradle 8.11.1)
- `minSdk 26` (Android 8.0)

Instale Gradle 8.11.1 e, na pasta `android/`, gere o wrapper local com `gradle wrapper --gradle-version 8.11.1`. Depois abra a pasta `android/` no Android Studio, aguarde a sincronização do Gradle, instale o SDK 35 se solicitado e execute `Build > Build Bundle(s) / APK(s) > Build APK(s)`. Também é possível compilar com `./gradlew assembleDebug` depois de gerar o wrapper. O APK debug normalmente fica em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para gerar release, configure assinatura própria em `android/app/build.gradle`/Android Studio e use `Build > Generate Signed Bundle / APK`. Não distribua APK debug como versão pública.

## Configuração do servidor

1. Se estiver migrando da V17 para esta pasta V18, preserve primeiro os dados executando `./MIGRAR_DADOS_V18.sh /caminho/da/MY-UNIVERSE-V17`. Faça isso antes do primeiro início; o pacote-fonte não inclui credenciais, tokens ou bancos pessoais.
2. No computador que contém a V18, inicie a instalação normalmente: `./iniciar.sh --rede`.
3. Descubra o IP local do computador e a porta 8765. Exemplo: `http://192.168.0.18:8765`.
4. No celular, conecte-se à mesma rede Wi-Fi, abra o app e em Ajustes informe o endereço Wi-Fi. Selecione WI-FI e salve.
5. Entre com o mesmo usuário e senha do portal MY UNIVERSE. O app não cria outra conta.
6. A GFI continua sendo um serviço separado, normalmente na porta 8780, com token próprio.

## Acesso remoto

O campo remoto aceita somente HTTPS. Use uma VPN com publicação HTTPS (por exemplo, Tailscale Serve) ou proxy reverso autenticado. Configure o endereço remoto do portal e selecione REMOTO. A autenticação continua sendo a do servidor MY UNIVERSE.

A instalação V17 retorna `http://gfi.nexus.local/?token=...` para a GFI. Esse domínio é local e não é automaticamente acessível pela Internet. Para GFI remota:

- publique o serviço GFI por um hostname HTTPS próprio ou rota segura;
- configure o servidor/proxy e a validação de Host da GFI para esse hostname;
- informe no campo ENDEREÇO GFI do app a base HTTPS publicada (sem token; o app acrescenta o token devolvido pelo portal).

Se o portal estiver atrás de proxy HTTPS, configure `MY_UNIVERSE_COOKIE_SECURE=1` no serviço do portal. Não encaminhe as portas 8765 e 8780 diretamente para a Internet sem VPN/proxy, TLS, autenticação e regras de firewall.

## Segurança e limitações

- HTTP é aceito apenas para o endereço local Wi-Fi; o campo remoto e o endereço GFI alternativo exigem HTTPS.
- O app armazena os endereços e o modo de conexão em SharedPreferences. A senha não é persistida pelo app.
- A sessão é o cookie `mu_sessao` do portal, compartilhado com a WebView por meio do CookieManager do Android.
- O app não contém as credenciais do servidor nem o token GFI em código-fonte.
- O endpoint remoto do GFI precisa ser preparado no gateway. A simples instalação do APK não cria conectividade remota.
- A GFI pode usar recursos/rotas próprias e deve ser validada no dispositivo Android real antes de distribuição.

## Testes desta entrega

O build Android não pôde ser executado neste ambiente por ausência do Android SDK/Gradle/ADB. Antes de publicar, sincronize e compile no Android Studio, teste login correto/incorreto, logout, sessão expirada, navegação NEXUS/Projetos, GFI via token, Wi-Fi com mudança de IP, remoto HTTPS e retorno pelo botão Voltar.
