package com.myuniverse.ultra;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,11,18), PANEL=Color.rgb(15,24,36), PANEL2=Color.rgb(19,32,46);
    private static final int TEXT=Color.rgb(235,243,250), MUTED=Color.rgb(135,157,177), TEAL=Color.rgb(74,218,194), BLUE=Color.rgb(67,157,255), LINE=Color.rgb(37,57,75);
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root, header, body, dock;
    private FrameLayout content;
    private String screen="home", gfiUrl="", currentWebUrl="";
    private boolean logged=false, gfiRunning=false;
    private EditText userField, passField;
    private TextView connectionLabel;
    private WebView webView;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); prefs=getSharedPreferences("mu_ultra",MODE_PRIVATE); CookieManager.getInstance().setAcceptCookie(true); buildShell(); if(prefs.getBoolean("logged",false)){ logged=true; validateSession(); } else showLogin(); }
    private String activeBase(){ String mode=prefs.getString("mode","wifi"); String value=prefs.getString(mode.equals("remote")?"remote_url":"wifi_url","").trim(); return trimSlash(value); }
    private String trimSlash(String s){ while(s.endsWith("/")) s=s.substring(0,s.length()-1); return s; }
    private void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(dp(18),dp(10),dp(18),dp(6)); setContentView(root);
        header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(0,dp(8),0,dp(12)); root.addView(header,new LinearLayout.LayoutParams(-1,dp(54)));
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        dock=new LinearLayout(this); dock.setGravity(Gravity.CENTER); dock.setPadding(dp(4),dp(8),dp(4),dp(4)); root.addView(dock,new LinearLayout.LayoutParams(-1,dp(66)));
    }
    private void chrome(String title, boolean showDock){
        header.removeAllViews(); TextView brand=txt("MY UNIVERSE",18,TEXT,true); header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView ver=txt("V18  /  ULTRA",10,TEAL,true); ver.setLetterSpacing(.12f); header.addView(ver);
        body.removeAllViews(); dock.setVisibility(showDock?View.VISIBLE:View.GONE); dock.removeAllViews();
        if(showDock){ addDock("⌂","Início","home"); addDock("◈","NEXUS","nexus"); addDock("▦","Projetos","projects"); addDock("◎","GFI","gfi"); addDock("⚙","Ajustes","settings"); }
    }
    private void addDock(String icon,String label,String target){
        LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); item.setPadding(dp(3),dp(4),dp(3),dp(3));
        TextView i=txt(icon,20,screen.equals(target)?TEAL:MUTED,true); TextView t=txt(label,9,screen.equals(target)?TEXT:MUTED,false); item.addView(i); item.addView(t);
        item.setOnClickListener(v->{ if(target.equals("home"))showHome(); else if(target.equals("settings"))showSettings(); else if(target.equals("nexus"))openPage("/nexus.html"); else if(target.equals("projects"))openPage("/painel.html"); else if(target.equals("gfi"))openGfi(); });
        dock.addView(item,new LinearLayout.LayoutParams(0,-1,1));
    }
    private TextView txt(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable bg(int color,int stroke){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(18)); if(stroke!=0)d.setStroke(dp(1),stroke); return d; }
    private int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private TextView button(String label, boolean primary){ TextView b=txt(label,14,primary?BG:TEXT,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(15),dp(14),dp(15),dp(14)); b.setBackground(bg(primary?TEAL:PANEL2,primary?0:LINE)); return b; }
    private void showLogin(){ screen="login"; chrome("Acesso",false); ScrollView sc=new ScrollView(this); LinearLayout form=column(); form.setPadding(0,dp(34),0,0);
        TextView orb=txt("◉",54,TEAL,true); orb.setGravity(Gravity.CENTER); form.addView(orb,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView title=txt("MY UNIVERSE",27,TEXT,true); title.setGravity(Gravity.CENTER); form.addView(title); TextView sub=txt("SEU UNIVERSO. EM QUALQUER LUGAR.",10,MUTED,true); sub.setGravity(Gravity.CENTER); sub.setLetterSpacing(.14f); form.addView(sub);
        form.addView(space(28)); form.addView(txt("Acessar seu ambiente",20,TEXT,true)); form.addView(txt("Entre com as credenciais da instalação V17.",13,MUTED,false));
        form.addView(space(18)); form.addView(fieldLabel("USUÁRIO")); userField=edit("Usuário",false); form.addView(userField); form.addView(space(12)); form.addView(fieldLabel("SENHA")); passField=edit("Senha",true); form.addView(passField); form.addView(space(20));
        TextView go=button("ENTRAR NO MEU UNIVERSO   →",true); form.addView(go); go.setOnClickListener(v->login());
        form.addView(space(18)); TextView settings=txt("Configurar conexão Wi-Fi / remoto",13,TEAL,true); settings.setGravity(Gravity.CENTER); form.addView(settings); settings.setOnClickListener(v->showSettings());
        sc.addView(form); body.addView(sc);
    }
    private View space(int h){ View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private TextView fieldLabel(String s){ TextView t=txt(s,10,MUTED,true); t.setPadding(dp(2),0,0,dp(6)); return t; }
    private EditText edit(String hint,boolean password){ EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setTextColor(TEXT); e.setHintTextColor(MUTED); e.setHint(hint); e.setPadding(dp(14),dp(11),dp(14),dp(11)); e.setBackground(bg(PANEL,LINE)); if(password)e.setInputType(129); else e.setInputType(1); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); e.setLayoutParams(p); return e; }
    private void login(){ String base=activeBase(); if(base.isEmpty()){ toast("Configure o endereço do servidor primeiro."); showSettings(); return; } String u=userField.getText().toString().trim(), p=passField.getText().toString(); if(u.isEmpty()||p.isEmpty()){toast("Informe usuário e senha.");return;} hideKeyboard();
        TextView wait=txt("Conectando e validando acesso…",13,TEAL,true); body.addView(wait,0);
        io.execute(()->{ try{ HttpURLConnection c=connection(base+"/auth/login","POST"); c.setRequestProperty("Content-Type","application/json"); JSONObject j=new JSONObject(); j.put("username",u); j.put("password",p); byte[] data=j.toString().getBytes(StandardCharsets.UTF_8); c.setDoOutput(true); c.setFixedLengthStreamingMode(data.length); try(OutputStream os=c.getOutputStream()){os.write(data);} int code=c.getResponseCode(); String cookie=c.getHeaderField("Set-Cookie"); c.disconnect(); if(code==204 && cookie!=null){ String pair=cookie.split(";",2)[0]; runOnUiThread(()->{ CookieManager.getInstance().setCookie(base,pair, ok->{ CookieManager.getInstance().flush(); prefs.edit().putBoolean("logged",true).apply(); logged=true; showHome(); }); }); } else { String msg=code==401?"Usuário ou senha inválidos.":code==429?"Muitas tentativas. Aguarde cinco minutos.":"Falha de conexão / HTTP "+code; runOnUiThread(()->toast(msg)); } }catch(Exception e){ runOnUiThread(()->toast("Não foi possível conectar: "+e.getMessage())); } });
    }
    private HttpURLConnection connection(String address,String method)throws Exception{ URL u=new URL(address); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod(method); c.setConnectTimeout(7000); c.setReadTimeout(10000); c.setUseCaches(false); c.setRequestProperty("Accept","application/json"); String cookie=CookieManager.getInstance().getCookie(activeBase()); if(cookie!=null)c.setRequestProperty("Cookie",cookie); return c; }
    private void showHome(){ screen="home"; chrome("Início",true); ScrollView sc=new ScrollView(this); LinearLayout page=column(); page.setPadding(0,dp(8),0,dp(16));
        TextView eyebrow=txt("PERSONAL OPERATING SYSTEM  /  018",10,TEAL,true); eyebrow.setLetterSpacing(.12f); page.addView(eyebrow);
        TextView heading=txt("Seu universo.\nSeu centro de comando.",29,TEXT,true); heading.setPadding(0,dp(9),0,dp(8)); page.addView(heading);
        TextView desc=txt("Acesse seus projetos, inteligência e infraestrutura em uma experiência feita para celular.",13,MUTED,false); page.addView(desc);
        page.addView(space(18)); LinearLayout status=row(); status.setPadding(dp(14),dp(12),dp(14),dp(12)); status.setBackground(bg(PANEL,LINE)); TextView dot=txt("●",12,TEAL,true); status.addView(dot); connectionLabel=txt("  Verificando conexão…",12,TEXT,true); status.addView(connectionLabel,new LinearLayout.LayoutParams(0,-2,1)); TextView cfg=txt("AJUSTAR",10,TEAL,true); status.addView(cfg); cfg.setOnClickListener(v->showSettings()); page.addView(status);
        page.addView(space(18)); page.addView(section("AMBIENTES PRINCIPAIS","01 / CORE"));
        page.addView(tile("GLOBAL FINANCIAL INTELLIGENCE","GFI","Inteligência financeira, dados e análises.","◈",()->openGfi(),true));
        page.addView(tile("NEXUS INTELLIGENCE","NEXUS","Central de IA, memória e evolução.","✧",()->openPage("/nexus.html"),false));
        page.addView(tile("PROJECT UNIVERSE","PROJETOS","Seus projetos, negócios e estudos.","▦",()->openPage("/painel.html"),false));
        page.addView(space(14)); page.addView(section("SISTEMA","02 / STATUS"));
        LinearLayout mini=row(); mini.addView(metric("APP","V18 ULTRA"),new LinearLayout.LayoutParams(0,dp(84),1)); mini.addView(metric("ACESSO","WIFI + REMOTO"),new LinearLayout.LayoutParams(0,dp(84),1)); page.addView(mini);
        TextView note=txt("O computador continua executando os motores e armazenando os dados. O app funciona como painel móvel autenticado.",11,MUTED,false); note.setPadding(dp(3),dp(16),dp(3),0); page.addView(note);
        sc.addView(page); body.addView(sc); checkStatus();
    }
    private View section(String a,String b){ LinearLayout r=row(); TextView l=txt(a,11,TEXT,true); r.addView(l,new LinearLayout.LayoutParams(0,-2,1)); r.addView(txt(b,9,MUTED,true)); r.setPadding(0,0,0,dp(10)); return r; }
    private View tile(String tag,String name,String sub,String symbol,Runnable action,boolean featured){ LinearLayout card=column(); card.setPadding(dp(16),dp(15),dp(16),dp(15)); card.setBackground(bg(featured?Color.rgb(13,39,48):PANEL,featured?Color.rgb(42,117,111):LINE)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(10); card.setLayoutParams(cp);
        LinearLayout top=row(); TextView ic=txt(symbol,24,featured?TEAL:BLUE,true); top.addView(ic,new LinearLayout.LayoutParams(dp(40),dp(38))); LinearLayout names=column(); names.addView(txt(tag,9,MUTED,true)); names.addView(txt(name,19,TEXT,true)); top.addView(names,new LinearLayout.LayoutParams(0,-2,1)); top.addView(txt("↗",20,TEAL,true)); card.addView(top); TextView d=txt(sub,12,MUTED,false); d.setPadding(dp(40),dp(5),0,0); card.addView(d); card.setOnClickListener(v->action.run()); return card; }
    private View metric(String label,String value){ LinearLayout c=column(); c.setPadding(dp(12),dp(12),dp(12),dp(10)); c.setBackground(bg(PANEL,LINE)); c.addView(txt(label,9,MUTED,true)); c.addView(txt(value,14,TEAL,true)); return c; }
    private void validateSession(){ String base=activeBase(); if(base.isEmpty()){logged=false;showLogin();return;} io.execute(()->{try{HttpURLConnection c=connection(base+"/auth/session","GET");int code=c.getResponseCode();String raw=code==200?read(c.getInputStream()):"{}";c.disconnect();JSONObject j=new JSONObject(raw);boolean ok=code==200&&j.optBoolean("authenticated",false);runOnUiThread(()->{if(ok)showHome();else{logged=false;prefs.edit().putBoolean("logged",false).apply();showLogin();}});}catch(Exception e){runOnUiThread(()->{showLogin();toast("Sessão não validada. Confira a conexão e entre novamente.");});}});}
    private void checkStatus(){ String base=activeBase(); if(base.isEmpty())return; io.execute(()->{ try{ HttpURLConnection c=connection(base+"/api/gfi/status","GET"); int code=c.getResponseCode(); if(code==401){c.disconnect();runOnUiThread(()->{logged=false;prefs.edit().putBoolean("logged",false).apply();CookieManager.getInstance().removeAllCookies(null);showLogin();toast("Sua sessão expirou. Entre novamente.");});return;} String raw=read(code>=400?c.getErrorStream():c.getInputStream()); c.disconnect(); JSONObject j=new JSONObject(raw); boolean running=j.optBoolean("running",false); String url=j.optString("url",""); runOnUiThread(()->{ if(connectionLabel!=null)connectionLabel.setText(code==200?"  Servidor conectado  ·  GFI "+(running?"online":"offline"):"  Sessão expirada / servidor indisponível"); gfiUrl=applyGfiOverride(url); gfiRunning=running; }); }catch(Exception e){runOnUiThread(()->{if(connectionLabel!=null)connectionLabel.setText("  Sem resposta do servidor · confira a conexão");});} }); }
    private String read(InputStream in)throws Exception{ BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String s; while((s=r.readLine())!=null)b.append(s); return b.toString(); }
    private String applyGfiOverride(String returned){ String override=prefs.getString("gfi_url","").trim(); if(override.isEmpty()||returned.isEmpty())return returned; Uri original=Uri.parse(returned), custom=Uri.parse(override); return custom.buildUpon().encodedQuery(original.getEncodedQuery()).build().toString(); }
    private void openGfi(){
        if(gfiUrl.isEmpty()){ checkStatus(); toast("Consultando endereço protegido da GFI… tente novamente em instantes."); return; }
        if(gfiRunning){ openUrl(gfiUrl,"GFI"); return; }
        toast("GFI offline. Solicitando inicialização no computador…"); String base=activeBase();
        io.execute(()->{try{HttpURLConnection c=connection(base+"/api/gfi/iniciar","POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");byte[] payload="{}".getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(payload.length);try(OutputStream o=c.getOutputStream()){o.write(payload);}int code=c.getResponseCode();String raw=read(code>=400?c.getErrorStream():c.getInputStream());c.disconnect();JSONObject j=new JSONObject(raw);boolean running=j.optBoolean("running",false);String url=applyGfiOverride(j.optString("url",gfiUrl));runOnUiThread(()->{gfiRunning=running;if(running&&!url.isEmpty()){gfiUrl=url;openUrl(url,"GFI");}else toast(j.optString("message","Não foi possível iniciar a GFI.")+" (HTTP "+code+")");});}catch(Exception e){runOnUiThread(()->toast("Falha ao iniciar GFI: "+e.getMessage()));}});
    }
    private void openPage(String path){ openUrl(activeBase()+path,path.contains("nexus")?"NEXUS":"Projetos"); }
    private void openUrl(String url,String label){ if(url==null||url.isEmpty()){toast("Endereço não configurado.");return;} screen="web"; chrome(label,false); TextView back=txt("←  VOLTAR AO MY UNIVERSE",11,TEAL,true); back.setPadding(0,dp(4),0,dp(10)); body.addView(back); back.setOnClickListener(v->showHome()); webView=new WebView(this); webView.setBackgroundColor(BG); webView.getSettings().setJavaScriptEnabled(true); webView.getSettings().setDomStorageEnabled(true); webView.getSettings().setLoadsImagesAutomatically(true); webView.getSettings().setAllowFileAccess(false); webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW); webView.setWebChromeClient(new WebChromeClient());  body.addView(webView,new LinearLayout.LayoutParams(-1,0,1)); currentWebUrl=url; final String allowedHost=Uri.parse(url).getHost(); final String secondaryHost=Uri.parse(gfiUrl).getHost(); webView.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){ String scheme=request.getUrl().getScheme(); String host=request.getUrl().getHost(); boolean validScheme="https".equals(scheme)||"http".equals(scheme); boolean validHost=host!=null&&(host.equalsIgnoreCase(allowedHost)||(secondaryHost!=null&&host.equalsIgnoreCase(secondaryHost))); return !(validScheme&&validHost); } @Override public void onReceivedError(WebView v,WebResourceRequest req,android.webkit.WebResourceError err){ if(req.isForMainFrame())toast("Falha ao abrir ambiente. Verifique rede, endereço e autenticação."); }}); webView.loadUrl(url); }
    private void showSettings(){ screen="settings"; chrome("Conexões",logged); ScrollView sc=new ScrollView(this); LinearLayout page=column(); page.setPadding(0,dp(8),0,dp(20)); page.addView(txt("CONEXÕES DO UNIVERSO",10,TEAL,true)); page.addView(txt("Escolha por onde o aplicativo alcança seu servidor.",13,MUTED,false)); page.addView(space(18));
        page.addView(fieldLabel("ENDEREÇO WI-FI LOCAL")); EditText wifi=edit("http://192.168.0.18:8765",false); wifi.setText(prefs.getString("wifi_url","")); page.addView(wifi); page.addView(space(12));
        page.addView(fieldLabel("ENDEREÇO REMOTO (HTTPS)")); EditText remote=edit("https://seu-servidor-ou-tailscale",false); remote.setText(prefs.getString("remote_url","")); page.addView(remote); page.addView(space(12));
        page.addView(fieldLabel("ENDEREÇO GFI (OPCIONAL)")); EditText gfi=edit("https://endereco-remoto-da-gfi",false); gfi.setText(prefs.getString("gfi_url","")); page.addView(gfi); page.addView(txt("Deixe vazio para usar o endereço entregue pelo servidor. Para acesso remoto, configure um domínio/rota HTTPS para a GFI e permita esse Host no gateway/servidor GFI.",11,MUTED,false)); page.addView(space(18));
        page.addView(fieldLabel("MODO DE CONEXÃO")); LinearLayout modes=row(); TextView wifiMode=button("WI-FI",prefs.getString("mode","wifi").equals("wifi")); TextView remoteMode=button("REMOTO",prefs.getString("mode","wifi").equals("remote")); modes.addView(wifiMode,new LinearLayout.LayoutParams(0,dp(48),1)); modes.addView(spaceW(8),new LinearLayout.LayoutParams(dp(8),1)); modes.addView(remoteMode,new LinearLayout.LayoutParams(0,dp(48),1)); page.addView(modes);
        final String[] mode={prefs.getString("mode","wifi")}; wifiMode.setOnClickListener(v->{mode[0]="wifi";wifiMode.setBackground(bg(TEAL,0));wifiMode.setTextColor(BG);remoteMode.setBackground(bg(PANEL2,LINE));remoteMode.setTextColor(TEXT);}); remoteMode.setOnClickListener(v->{mode[0]="remote";remoteMode.setBackground(bg(TEAL,0));remoteMode.setTextColor(BG);wifiMode.setBackground(bg(PANEL2,LINE));wifiMode.setTextColor(TEXT);});
        page.addView(space(20)); TextView save=button("SALVAR CONFIGURAÇÃO",true); page.addView(save); save.setOnClickListener(v->{String w=wifi.getText().toString().trim(),r=remote.getText().toString().trim(),g=gfi.getText().toString().trim(); if(!validUrl(w,false)||(!r.isEmpty()&&!validUrl(r,true))||(!g.isEmpty()&&!validUrl(g,true))||(mode[0].equals("remote")&&r.isEmpty())){toast("URL inválida. Wi-Fi aceita HTTP privado; remoto/GFI exigem HTTPS.");return;} String oldBase=activeBase(); String nextBase=trimSlash(mode[0].equals("remote")?r:w); boolean changed=!oldBase.equals(nextBase); prefs.edit().putString("wifi_url",trimSlash(w)).putString("remote_url",trimSlash(r)).putString("gfi_url",trimSlash(g)).putString("mode",mode[0]).apply(); if(changed){CookieManager.getInstance().removeAllCookies(null);logged=false;prefs.edit().putBoolean("logged",false).apply();} toast("Conexões salvas."); if(logged)showHome(); else showLogin(); });
        page.addView(space(14)); TextView help=txt("ACESSO REMOTO SEGURO\n\nUse HTTPS por meio de Tailscale Serve, VPN com HTTPS ou proxy reverso protegido. Não exponha diretamente as portas 8765/8780 à Internet. O endereço gfi.nexus.local é local e normalmente não resolve fora da rede doméstica.",12,MUTED,false); help.setPadding(dp(14),dp(14),dp(14),dp(14)); help.setBackground(bg(PANEL,LINE)); page.addView(help);
        if(logged){page.addView(space(16)); TextView logout=button("ENCERRAR SESSÃO",false); page.addView(logout); logout.setOnClickListener(v->logout());}
        sc.addView(page); body.addView(sc);
    }
    private View spaceW(int w){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1));return v;}
    private boolean validUrl(String s,boolean remote){ try{ Uri u=Uri.parse(s); if(u.getHost()==null||!("http".equals(u.getScheme())||"https".equals(u.getScheme())))return false; if(remote)return "https".equals(u.getScheme()); if("https".equals(u.getScheme()))return true; String h=u.getHost().toLowerCase(); return h.equals("localhost")||h.endsWith(".local")||h.startsWith("192.168.")||h.startsWith("10.")||(h.matches("172\\.(1[6-9]|2[0-9]|3[01])\\..*")); }catch(Exception e){return false;} }
    private void logout(){ String base=activeBase(); io.execute(()->{try{HttpURLConnection c=connection(base+"/auth/logout","POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setFixedLengthStreamingMode(2);try(OutputStream o=c.getOutputStream()){o.write("{}".getBytes(StandardCharsets.UTF_8));}c.getResponseCode();c.disconnect();}catch(Exception ignored){} runOnUiThread(()->{CookieManager.getInstance().removeAllCookies(null);prefs.edit().putBoolean("logged",false).apply();logged=false;showLogin();});}); }
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0);}catch(Exception ignored){}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){ if(screen.equals("web")){showHome();}else if(screen.equals("settings")&&logged){showHome();}else if(!screen.equals("login")){showHome();}else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(webView!=null){webView.destroy();webView=null;} io.shutdown(); super.onDestroy(); }
}
