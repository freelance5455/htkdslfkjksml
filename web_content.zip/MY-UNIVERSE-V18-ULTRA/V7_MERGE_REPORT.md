# Relatório de integração — V7

## Fontes
- Base: `MY-universe-V6.11.zip`.
- Integração: `V6.zip`.

## Estratégia
A V6.11 foi preservada como base para não perder o NEXUS AEE, a Central IA GFI, o painel GFI e o armazenamento intradiário. As melhorias operacionais V6 foram portadas seletivamente.

## Módulos V6 integrados ou adaptados
- `gfi/acesso.py` e proteção de painel/API por token em modo rede.
- `gfi/live_auto.py` e `gfi/agendador.py`: LIVE isolado, persistência de agenda, coleta CVM programada e controle de carga.
- `gfi/conectores/base.py`: limitação de frequência por host e diagnóstico de fontes.
- `gfi/conectores/b3_cotahist.py`: coleta padrão de três anos, reaproveitamento de anos encerrados e manutenção das rotas de status/validação da V6.11.
- `gfi/pesquisa.py`: tolerância de defasagem por periodicidade e fechamento de alertas superados.
- `gfi/backtest.py`: comparação com baselines.
- `gfi/validacao.py` e `gfi/motores/pontuacao.py`: razões adicionais de grupamento e risco incerto para saltos sem explicação.
- `gfi/config.py`: limites de lote ampliados e parâmetros operacionais.

## Módulos preservados da V6.11
- Portal, NEXUS, AEE e núcleo de segurança.
- Central IA GFI e suas rotas.
- Conector CVM DFP/ITR e ledger rastreável.
- Fundação de cotações intradiárias e validação SQLite da V6.11.
- Interface e módulos exclusivos da V6.11.

## Limitação conhecida
O conector FCA da V6 antiga dependia de tabelas e contratos de fundamentos incompatíveis com o ledger DFP/ITR da V6.11. Para evitar corromper ou duplicar o modelo de dados, ele não foi sobreposto. O vínculo automático ticker↔CNPJ via FCA permanece pendente de integração específica.

A suíte histórica `test_v6.py` também não foi mantida como suíte ativa, pois parte dos testes exige APIs e tabelas antigas. Foram criados testes V7 específicos de autenticação e a suíte GFI da base V6.11 foi executada após as integrações.

## Resultado
A V7 preserva as duas linhas de desenvolvimento onde são compatíveis, explicita as incompatibilidades e evita declarar como concluídas integrações que ainda exigem adaptação.
