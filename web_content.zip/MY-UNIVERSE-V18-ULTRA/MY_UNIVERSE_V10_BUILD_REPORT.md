# MY UNIVERSE V10 — relatório de construção

Base: `MY-universe-V9.1-internal.zip` (versão interna mais recente disponível no projeto).

## Entregas
- Saldo de caixa da carteira exibido no cabeçalho global, disponível em todos os painéis.
- O valor é obtido do endpoint existente da carteira; não cria uma segunda fonte de saldo.
- Atualização imediata após registrar movimentação e sincronização periódica a cada 15 segundos.
- Botão para ocultar/revelar e preferência persistida no navegador.
- Layout WebMobile para smartphones: topo reorganizado, navegação por rolagem horizontal, painéis em coluna única, tabelas com rolagem horizontal, campos adequados ao toque.
- Wallpaper vertical fornecido pelo usuário aplicado como fundo da versão mobile; fundo desktop original preservado.
- Documentação V10 adicionada.

## Validação executada
- `node --check ui/app.js`: aprovado.
- `python -m compileall`: aprovado.
- `pytest -q testes`: 128 testes aprovados e 8 subtestes aprovados.

## Observações
- O valor global exibido é saldo de caixa, não patrimônio total. O patrimônio depende de cotações para todas as posições e permanece detalhado na tela Minha Conta.
- A ocultação é uma preferência visual local ao navegador; não substitui autenticação nem criptografia.
- A interface é WebMobile responsiva, acessada pelo navegador do telefone. Não foi criada uma aplicação nativa Android/iOS.
