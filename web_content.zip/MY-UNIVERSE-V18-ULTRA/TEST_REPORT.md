# Relatório de testes — MY UNIVERSE V8 Alpha

## Validações executadas nesta construção

- `python3 -m compileall -q .` — aprovado.
- `node --check assets/nexus.js` — aprovado.
- `node --check sites/laboratorio-ti/inteligencia-financeira/ui/app.js` — aprovado.
- `bash -n iniciar.sh sites/laboratorio-ti/inteligencia-financeira/ativar_ia.sh` — aprovado.
- `PYTHONPATH=sites/laboratorio-ti/inteligencia-financeira python3 -m unittest discover -s sites/laboratorio-ti/inteligencia-financeira/testes -q` — **124 testes GFI aprovados**.
- `python3 -m unittest nexus.tests.test_nexus.TestApi nexus.tests.test_nexus.TestValidador nexus.tests.test_nexus.TestEngenhariaAEE -q` — **17 testes direcionados NEXUS/AEE aprovados**.
- Incluído teste para a rota `gfi-ai/chat` encaminhar a mensagem ao motor de conversa.

## O que estes testes demonstram

- Compilação dos módulos Python incluídos.
- Sintaxe dos dois principais arquivos JavaScript verificados.
- Sintaxe dos scripts Shell verificados.
- Comportamento coberto pelas 124 verificações automatizadas da GFI.
- Comportamento coberto pelos 17 testes direcionados do NEXUS/AEE.

## Não comprovado nesta construção

- Inferência com modelo generativo real na máquina de operação.
- Pesquisa externa funcionando na rede do usuário.
- Downloads reais B3, BCB e CVM e ingestão integral dos dados.
- Feed intradiário contínuo com provedor ativo.
- Operação contínua por vários dias.
- Vínculo automático ticker↔CNPJ via FCA.

A V8 Alpha está validada por testes locais, mas ainda requer homologação no ambiente de operação.
