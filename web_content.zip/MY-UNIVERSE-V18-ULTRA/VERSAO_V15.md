# MY UNIVERSE V15 — Universo de ações B3, carteira e atualização ágil

Base: `MY-UNIVERSE-V14-NEXUS-SYSTEMD.zip`.

## Objetivo

Ampliar a experiência de investimento em ações brasileiras, melhorar a contabilização da carteira pessoal, tornar o acompanhamento do patrimônio mais responsivo e aumentar a transparência visual no desktop e no mobile, preservando a estrutura operacional V14.

## Implementações

- Catálogo de ações brasileiras: endpoint `carteira/ativos` lista ações ON, PN e units REAL cadastradas no catálogo local B3, com busca por ticker/nome e preenchimento de ticker no formulário.
- Importação do universo B3: ação explícita para baixar/importar COTAHIST dos últimos dez anos, usando o conector oficial já existente. A importação alimenta o catálogo com os papéis que negociaram no período; não inventa símbolos. A lista efetiva depende da coleta concluída e dos dados oficiais disponíveis.
- Livro de operações: compra e venda calculam o valor bruto pelo produto quantidade × preço unitário; o backend também aplica essa regra para evitar divergência entre campos.
- Preço de aquisição: cada movimentação preserva quantidade, preço unitário, ticker e valor total. Posições exibem preço médio ponderado, cotação observada, valor de mercado, resultado em reais e rentabilidade percentual por ativo.
- Resultado consolidado: caixa, patrimônio, P/L realizado, P/L em aberto e rentabilidade global continuam derivados do livro de operações e das cotações disponíveis.
- Atualização visual a cada 5 segundos: saldo global e painel Minha Conta recalculam os indicadores com os preços em cache, atualizando cor verde/vermelha conforme rentabilidade positiva/negativa.
- Proteção do provedor: a consulta externa de cotações da carteira tem limite local mínimo de 45 segundos; o painel não faz uma chamada externa a cada 5 segundos. Cotações públicas podem atrasar e não constituem feed em tempo real.
- Mobile e desktop: tabela de desempenho por ação com rolagem horizontal controlada, controles maiores no toque, grade adaptável e cartões mais translúcidos para deixar o fundo visível sem comprometer a leitura.
- Atualização de carteira: timer de 5 segundos é encerrado ao sair do painel, evitando timers duplicados e trabalho desnecessário.

## Operação

1. Extrair a V15 em uma pasta nova, sem sobrescrever V13/V14.
2. Executar a migração da instalação anterior para V15 usando o script `migrar_dados_v15.sh` (a estrutura e o caminho de dados continuam compatíveis).
3. Executar `./testar_v15.sh`.
4. Instalar/ativar os serviços V14 incluídos no pacote, conforme `VERSAO_V14.md`; a V15 preserva o supervisor systemd e o publicador mDNS.
5. Abrir Minha Conta e usar “Importar universo B3 — últimos 10 anos” para ampliar o catálogo local. A operação requer internet e pode levar vários minutos.

## Limitações e transparência

- “Todas as ações” significa todas as ações ON, PN e units brasileiras presentes no catálogo local alimentado pelo COTAHIST importado. A cobertura só pode ser declarada completa após a importação e a conferência do número de instrumentos; o pacote não finge conter uma lista atualizada se a base local estiver incompleta.
- COTAHIST é histórico diário; não é cotação em tempo real. A consulta pública complementar pode ter atraso, limites ou falhas. A cada 5 segundos a interface recalcula os números usando a última cotação recebida, mas o preço externo não é garantido a cada ciclo de 5 segundos.
- Resultado de carteira não incorpora automaticamente corretagem, emolumentos, impostos, dividendos/JCP, eventos corporativos ou ajustes de preço médio. Esses componentes precisam ser registrados/conciliados para um resultado contábil completo.
- A aplicação é ferramenta de análise e controle pessoal; não envia ordens à B3 nem substitui extrato da corretora.

## Preservação

V15 deriva da V14. Mantém o portal NEXUS, gateway, unidades systemd, publicador mDNS, módulos GFI, bancos, plano de coleta de 145 tarefas, coletores B3/BCB/CVM, IA GFI e configurações existentes. As mudanças funcionais estão concentradas na carteira, catálogo de ativos e apresentação visual.
