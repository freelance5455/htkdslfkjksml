#!/usr/bin/env python3
"""NEXUS NETWORK: reverse proxy local por hostname; backends permanecem em loopback."""
import http.client, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

PORTAL_HOSTS = {x.strip().lower() for x in os.environ.get('NEXUS_PORTAL_HOSTS', 'nexus.local').split(',') if x.strip()}
GFI_HOSTS = {x.strip().lower() for x in os.environ.get('NEXUS_GFI_HOSTS', 'gfi.nexus.local').split(',') if x.strip()}
PORTAL_PORT = int(os.environ.get('MY_UNIVERSE_PORT', '8765'))
GFI_PORT = int(os.environ.get('GFI_PORTA', '8780'))

class Gateway(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'NEXUS-NETWORK'
    sys_version = ''
    def log_message(self, *_): pass
    def do_GET(self): self.forward()
    def do_HEAD(self): self.forward()
    def do_POST(self): self.forward()
    def do_PUT(self): self.forward()
    def do_PATCH(self): self.forward()
    def do_DELETE(self): self.forward()
    def do_OPTIONS(self): self.forward()
    def forward(self):
        host = self.headers.get('Host', '').split(':', 1)[0].lower().rstrip('.')
        if host in PORTAL_HOSTS: port = PORTAL_PORT
        elif host in GFI_HOSTS: port = GFI_PORT
        else:
            body = b'NEXUS NETWORK: hostname desconhecido. Use nexus.local ou gfi.nexus.local.'
            self.send_response(421); self.send_header('Content-Type','text/plain; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        try:
            length = int(self.headers.get('Content-Length', '0') or 0)
            if length > 32 * 1024 * 1024:
                self.send_error(413); return
            body = self.rfile.read(length) if length else None
            conn = http.client.HTTPConnection('127.0.0.1', port, timeout=90)
            headers = {k:v for k,v in self.headers.items() if k.lower() not in ('host','connection','content-length','transfer-encoding')}
            headers['Host'] = f'127.0.0.1:{port}'
            headers['X-Forwarded-For'] = self.client_address[0]
            if self.headers.get('Origin'):
                scheme = urlsplit(self.headers.get('Origin')).scheme or 'http'
                headers['Origin'] = f'{scheme}://127.0.0.1:{port}'
            conn.request(self.command, self.path, body=body, headers=headers)
            response = conn.getresponse(); data = response.read()
            self.send_response(response.status, response.reason)
            for k,v in response.getheaders():
                if k.lower() not in ('connection','transfer-encoding','content-length','server','date'):
                    self.send_header(k,v)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Connection', 'close'); self.end_headers()
            if self.command != 'HEAD': self.wfile.write(data)
            conn.close()
        except (OSError, TimeoutError, http.client.HTTPException):
            body = b'Servico indisponivel. Inicie MY UNIVERSE e tente novamente.'
            self.send_response(503); self.send_header('Content-Type','text/plain; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)

if __name__ == '__main__':
    bind = os.environ.get('NEXUS_GATEWAY_HOST', '0.0.0.0')
    port = int(os.environ.get('NEXUS_GATEWAY_PORT', '80'))
    srv = ThreadingHTTPServer((bind, port), Gateway); srv.daemon_threads = True
    print(f'NEXUS NETWORK em {bind}:{port}; portal={PORTAL_PORT}; GFI={GFI_PORT}')
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
