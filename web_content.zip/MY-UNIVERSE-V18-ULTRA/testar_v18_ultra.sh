#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
echo '[1/4] Regressão portal / NEXUS base'
./testar_v16.sh
echo '[2/4] Regressão GFI V17'
bash sites/laboratorio-ti/inteligencia-financeira/testar_gfi_v17.sh
echo '[3/4] Integridade XML Android e contratos de integração'
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
base=Path('android')
for p in base.rglob('*.xml'): ET.parse(p)
source=(base/'app/src/main/java/com/myuniverse/ultra/MainActivity.java').read_text()
for token in ['/auth/login','/auth/session','/api/gfi/status','/api/gfi/iniciar','/nexus.html','/painel.html','https']:
    assert token in source, f'Contrato ausente: {token}'
manifest=(base/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' in manifest
print('XML Android e rotas de integração: OK')
PY
echo '[4/4] Verificação de toolchain Android'
if command -v gradle >/dev/null 2>&1 && [[ -n "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  (cd android && gradle --no-daemon assembleDebug)
else
  echo 'PENDENTE: Android SDK/Gradle não instalados neste ambiente; APK não compilado.'
fi
echo 'V18 ULTRA: testes da base concluídos.'
