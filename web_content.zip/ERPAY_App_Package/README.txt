ERPAY Demo Website Package

Main file: index.html

How to use on Android:
1. Extract ERPAY_App.zip using your file manager.
2. Open the extracted folder.
3. Tap index.html and open it in Chrome or another browser.

This package is a standalone HTML demo website. It is not a compiled Android APK and does not include a native Android project or backend server. Demo balances/earnings are simulated display values, not real financial records.
