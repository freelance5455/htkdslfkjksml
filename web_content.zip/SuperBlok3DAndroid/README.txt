SUPER BLOK 3D — Android WebView project

HTML game source is included unchanged at:
app/src/main/assets/index.html

Build requirements:
- Android Studio (current stable)
- Android SDK Platform 35
- JDK 17 or newer compatible with Android Gradle Plugin 8.7.3

Build APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync and install missing SDK components if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output is under app/build/outputs/apk/debug/app-debug.apk

Note: the original HTML loads Three.js from cdnjs.cloudflare.com, so internet is required when the game starts unless that dependency is separately bundled. The HTML game source itself has not been edited.
