# Browser tests (V19)
`npm i -D playwright && npx playwright install chromium`, then:
`node tests/smoke.mjs  $PWD/web/index.html`   – opens every module/form in all 18 languages, reports JS errors and untranslated keys
`node tests/functional.mjs $PWD/web/index.html` – tax/retention/withholding maths, multi-currency, settings, persistence, legacy-data migration, PIN hashing
Server tests: `cd server && npm test`

`node tests/e2e.mjs <html> <server dir>` – browser <-> server: BTCPay checkout/webhook + AI tools
`node tests/e2e-direct-team-i18n.mjs <html> <server dir>` – Gantt, Team & Audit, direct-wallet payment (operator-confirmed), runtime translation (de/fa/ta/ur), RTL, alert translation, restore to English
`node tests/ui-coverage.mjs <html> <out.json> <lang>` – renders every module/modal in a language and dumps visible text (use it to spot untranslated strings)
