Contractor Pro V19.2 — Global Edition (built on V18.2 + your V18.2-FINAL additions, nothing removed). QA build — see "NOT verified" below before production.

NEW in V19.2 (this release)
- Translation completed: a runtime UI-translation layer + dictionary (322 strings x 17 languages) covers every hard-coded text in the Account, Cloud, License, Portal, AI Copilot, Documents, Security, Notifications and Smart-Assistant screens, alerts/confirm/prompt messages, placeholders and notices. Hard-coded Persian messages were converted to translatable English sources. Switching language also restores English. Remaining English on screen is limited to proper names (Contractor Pro, language names), sample data and international abbreviations (OTP, PIN, PDF).
- Merged from your FINAL: Gantt chart on the Schedule screen; Team & Audit screen (add members, change roles, tamper-evident audit log check), now localized.
- Direct wallet payments (your FINAL idea, security-fixed): customer gets a unique exact amount + your address; ONLY the operator (secret OPERATOR_TOKEN) can confirm, which activates the subscription through the same idempotent path as BTCPay/NOWPayments and writes the audit log. The old customer-side "I paid" button (anyone could grant themselves a plan) was removed; plan prices are validated; BTC rate fetch is injectable and fails closed.
- Per-customer cost cap (server-enforced): variable-cost budget = net collected revenue x 25% (all numbers are an operator-editable policy). Real AI token costs and backup sizes go into a usage ledger; requests that would exceed the cap are refused with HTTP 402 (viewing data, offline features, usage screen stay available); warnings at 70%/90% in the app; annual plans release the budget month by month; team plans share a budget with a per-user cap; extra credit and refunds supported; operator usage/margin overview. Needs OPERATOR_TOKEN. See DEPLOY-fa.md section 3b.
- docs/ELECTRON-security-fa.md: hardening snippet for a desktop (Electron) wrapper.
- Version label fixed (APP_VERSION and title now match: 19.2.0). DB migration 003 added.
- docs/DEPLOY-local-fa.md = your local/Termux guide (kept, crypto section superseded).

Earlier (V19 / V19.1): tax engine, multi-currency, 18 languages, 20 countries, salted PBKDF2 app-lock PIN, BTCPay + NOWPayments subscriptions, 6 server-side AI tasks (text/drawing BOQ, contract review, daily report, invoice reminders, cash-flow), Docker/Caddy deployment.

VERIFIED in the build environment
- Server tests 41/41 (billing, direct wallet, cost cap, AI, RBAC, audit chain). Browser smoke (all modules x 18 languages, 0 JS errors, 0 missing keys), functional 15/15, e2e browser<->server (BTCPay mock + AI) and e2e for Gantt/Team/direct-wallet/translation: all pass. SQL migrations 001-004 applied on real PostgreSQL 16, including the unique-amount index.

NOT verified (needs your accounts, keys, devices or people)
- Live calls: BTCPay/NOWPayments, Anthropic API, CoinGecko, real blockchain payments; the `pg` driver against a live DB (package install was blocked here; SQL itself was tested with psql).
- Cost cap: default model/storage prices in the policy are placeholders (verify with your provider's price list); the 25% share must be re-checked against real costs; no automatic credit purchase or web admin dashboard yet (API only).
- Translation quality: the 17 languages are AI-drafted and must be reviewed by native speakers (legal/financial wording especially). Tax rates per country must be confirmed with local accountants.
- Not built: government e-invoicing (ZATCA, India e-invoice, e-Fatura, Iran Moodian), SSO/SCIM, SOC 2/ISO 27001/GDPR processes, APK build and device QA, real email/push delivery, cloud file storage, critical-path scheduling/EVM/RFI.
