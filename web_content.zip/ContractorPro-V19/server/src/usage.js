// Per-customer cost cap. Rule (configurable policy, not scattered constants):
//   variable-cost budget for a period = NET collected revenue of that period x costShare (default 25%).
// Net revenue = amount - payment fee - tax - refunds. Annual plans release the budget month by month (30-day windows).
// Unused budget is NOT carried over (it stays as business reserve). Over the cap: costly requests are refused unless extra credit exists.
export const DEFAULT_POLICY = { costShare: 0.25, feePct: 1, taxPct: 0, freeMonthlyUsd: 0.1, perUserShare: 0.5, warn: [0.7, 0.9], aiUsdPerMTokIn: 3, aiUsdPerMTokOut: 15, syncUsdPerGb: 0.05 };
const DAY = 864e5, WIN = 30;
const num = (v, lo, hi, name) => { const n = Number(v); if (!Number.isFinite(n) || n < lo || n > hi) throw new Error(`${name} must be between ${lo} and ${hi}`); return n; };

export function sanitizePolicy(input, base = DEFAULT_POLICY) {
  const p = { ...base }, i = input || {};
  if (i.costShare !== undefined) p.costShare = num(i.costShare, 0, 1, 'costShare');
  if (i.feePct !== undefined) p.feePct = num(i.feePct, 0, 50, 'feePct');
  if (i.taxPct !== undefined) p.taxPct = num(i.taxPct, 0, 60, 'taxPct');
  if (i.freeMonthlyUsd !== undefined) p.freeMonthlyUsd = num(i.freeMonthlyUsd, 0, 100, 'freeMonthlyUsd');
  if (i.perUserShare !== undefined) p.perUserShare = num(i.perUserShare, 0.01, 1, 'perUserShare');
  if (i.aiUsdPerMTokIn !== undefined) p.aiUsdPerMTokIn = num(i.aiUsdPerMTokIn, 0, 1000, 'aiUsdPerMTokIn');
  if (i.aiUsdPerMTokOut !== undefined) p.aiUsdPerMTokOut = num(i.aiUsdPerMTokOut, 0, 1000, 'aiUsdPerMTokOut');
  if (i.syncUsdPerGb !== undefined) p.syncUsdPerGb = num(i.syncUsdPerGb, 0, 1000, 'syncUsdPerGb');
  if (i.warn !== undefined) { const w = i.warn; if (!Array.isArray(w) || w.length !== 2 || !(w[0] > 0 && w[0] < w[1] && w[1] < 1)) throw new Error('warn must be [a,b] with 0<a<b<1'); p.warn = [Number(w[0]), Number(w[1])]; }
  return p;
}

export const netRevenue = (pay, pol) => {
  const a = Number(pay.amountUsd) || 0;
  const fee = pay.feeUsd != null ? Number(pay.feeUsd) : a * pol.feePct / 100, tax = pay.taxUsd != null ? Number(pay.taxUsd) : a * pol.taxPct / 100;
  return Math.max(0, a - fee - tax - (Number(pay.refundedUsd) || 0));
};

// Coverage chain: paid payments in order; each covers `days` starting when the previous one ends (matches stacked renewals).
export function currentWindow(paidPayments, pol, now = Date.now()) {
  const sorted = [...paidPayments].sort((a, b) => new Date(a.paidAt) - new Date(b.paidAt));
  let cursor = 0;
  for (const p of sorted) {
    const start = Math.max(new Date(p.paidAt).getTime(), cursor), end = start + p.days * DAY; cursor = end;
    if (now >= start && now < end) {
      const k = Math.floor((now - start) / (WIN * DAY)), ws = start + k * WIN * DAY, we = Math.min(end, ws + WIN * DAY);
      const share = (we - ws) / DAY / p.days, net = netRevenue(p, pol);
      return { paid: true, orderId: p.orderId, start: new Date(ws).toISOString(), end: new Date(we).toISOString(), revenueUsd: net * share, budgetUsd: net * share * pol.costShare };
    }
  }
  const d = new Date(now), s = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1), e = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
  return { paid: false, orderId: null, start: new Date(s).toISOString(), end: new Date(e).toISOString(), revenueUsd: 0, budgetUsd: pol.freeMonthlyUsd };
}

export const aiCost = (inTok, outTok, pol) => (inTok * pol.aiUsdPerMTokIn + outTok * pol.aiUsdPerMTokOut) / 1e6;
export const syncCost = (bytes, pol) => bytes / 1e9 * pol.syncUsdPerGb;
export const approxTokens = (chars) => Math.ceil(chars / 3.5);

export function levelOf(pct, creditUsd, pol) {
  if (pct >= 1 && creditUsd <= 0) return 'blocked';
  if (pct >= pol.warn[1]) return 'warn90';
  if (pct >= pol.warn[0]) return 'warn70';
  return 'ok';
}
