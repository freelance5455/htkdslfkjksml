// PostgreSQL store. Same interface as MemoryStore. Requires `npm install` (pg) and sql/001_schema.sql applied (npm run migrate).
import pg from 'pg';
import { GENESIS, chainHash } from './audit.js';
import { resolveChange } from './sync.js';

const u = (r) => r && { id: r.id, email: r.email, passwordHash: r.password_hash, emailVerified: r.email_verified };

export class PgStore {
  kind = 'postgres';
  constructor(pool) { this.pool = pool; }
  static async connect(url) {
    const pool = new pg.Pool({ connectionString: url, max: 10 });
    await pool.query('SELECT 1');
    return new PgStore(pool);
  }
  q(text, params) { return this.pool.query(text, params); }
  async tx(fn) {
    const c = await this.pool.connect();
    try { await c.query('BEGIN'); const r = await fn(c); await c.query('COMMIT'); return r; }
    catch (e) { try { await c.query('ROLLBACK'); } catch {} throw e; }
    finally { c.release(); }
  }

  async createOrgWithOwner({ orgName, email, passwordHash, emailVerified = false }) {
    return this.tx(async (c) => {
      const org = (await c.query('INSERT INTO organizations(name) VALUES($1) RETURNING id,name', [orgName])).rows[0];
      const user = u((await c.query('INSERT INTO users(email,password_hash,email_verified) VALUES($1,$2,$3) RETURNING *', [email, passwordHash, emailVerified])).rows[0]);
      await c.query("INSERT INTO memberships(org_id,user_id,role) VALUES($1,$2,'owner')", [org.id, user.id]);
      await c.query("INSERT INTO subscriptions(org_id,license_id,plan,status) VALUES($1,'LIC-'||upper(substr(gen_random_uuid()::text,1,8)),'free','active')", [org.id]);
      return { org, user };
    });
  }
  async createUser({ email, passwordHash }) { return u((await this.q('INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING *', [email, passwordHash])).rows[0]); }
  async getUserByEmail(email) { return u((await this.q('SELECT * FROM users WHERE email=$1', [email])).rows[0]); }
  async getUserById(id) { return u((await this.q('SELECT * FROM users WHERE id=$1', [id])).rows[0]); }
  async setPassword(id, h) { await this.q('UPDATE users SET password_hash=$2 WHERE id=$1', [id, h]); }
  async markVerified(id) { await this.q('UPDATE users SET email_verified=true WHERE id=$1', [id]); }
  async getMembership(userId) { const r = (await this.q('SELECT org_id,user_id,role FROM memberships WHERE user_id=$1 LIMIT 1', [userId])).rows[0]; return r && { orgId: r.org_id, userId: r.user_id, role: r.role }; }
  async listMembers(orgId) { return (await this.q('SELECT u.id,u.email,m.role FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.org_id=$1 ORDER BY u.email', [orgId])).rows; }
  async addMember({ orgId, userId, role }) { await this.q('INSERT INTO memberships(org_id,user_id,role) VALUES($1,$2,$3) ON CONFLICT (org_id,user_id) DO UPDATE SET role=EXCLUDED.role', [orgId, userId, role]); }
  async setRole(orgId, userId, role) { return (await this.q('UPDATE memberships SET role=$3 WHERE org_id=$1 AND user_id=$2', [orgId, userId, role])).rowCount > 0; }

  async saveRefresh(hash, userId, expiresAt) { await this.q('INSERT INTO refresh_tokens(token_hash,user_id,expires_at) VALUES($1,$2,to_timestamp($3/1000.0))', [hash, userId, expiresAt]); }
  async takeRefresh(hash) { const r = (await this.q('DELETE FROM refresh_tokens WHERE token_hash=$1 RETURNING user_id, expires_at', [hash])).rows[0]; return r && new Date(r.expires_at).getTime() > Date.now() ? { userId: r.user_id, expiresAt: new Date(r.expires_at).getTime() } : null; }
  async revokeRefresh(userId) { await this.q('DELETE FROM refresh_tokens WHERE user_id=$1', [userId]); }

  async setOtp(email, codeHash, expiresAt) { await this.q('INSERT INTO otp_codes(email,code_hash,expires_at,attempts) VALUES($1,$2,to_timestamp($3/1000.0),0) ON CONFLICT (email) DO UPDATE SET code_hash=EXCLUDED.code_hash, expires_at=EXCLUDED.expires_at, attempts=0', [email, codeHash, expiresAt]); }
  async getOtp(email) { const r = (await this.q('SELECT * FROM otp_codes WHERE email=$1', [email])).rows[0]; return r && { codeHash: r.code_hash, expiresAt: new Date(r.expires_at).getTime(), attempts: r.attempts }; }
  async bumpOtp(email) { await this.q('UPDATE otp_codes SET attempts=attempts+1 WHERE email=$1', [email]); }
  async deleteOtp(email) { await this.q('DELETE FROM otp_codes WHERE email=$1', [email]); }

  async pushSnapshot(orgId, deviceId, data) { return Number((await this.q('INSERT INTO sync_snapshots(org_id,device_id,data) VALUES($1,$2,$3) RETURNING cursor', [orgId, deviceId, JSON.stringify(data)])).rows[0].cursor); }
  async latestSnapshot(orgId) { const r = (await this.q('SELECT cursor,data FROM sync_snapshots WHERE org_id=$1 ORDER BY cursor DESC LIMIT 1', [orgId])).rows[0]; return r && { cursor: Number(r.cursor), data: r.data }; }

  async applyChange(orgId, ch) {
    return this.tx(async (c) => {
      const row = (await c.query('SELECT * FROM records WHERE org_id=$1 AND module=$2 AND id=$3 FOR UPDATE', [orgId, ch.module, ch.id])).rows[0];
      const ex = row && { version: row.version, updatedAt: row.updated_at.toISOString(), deleted: row.deleted, data: row.data };
      const r = resolveChange(ex, ch);
      if (r.status === 'applied') {
        await c.query('INSERT INTO records(org_id,module,id,data,version,updated_at,deleted) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (org_id,module,id) DO UPDATE SET data=EXCLUDED.data, version=EXCLUDED.version, updated_at=EXCLUDED.updated_at, deleted=EXCLUDED.deleted',
          [orgId, ch.module, ch.id, JSON.stringify(ch.data ?? null), r.version, ch.updatedAt, !!ch.deleted]);
        return { ...r, server: { module: ch.module, id: ch.id, data: ch.data ?? null, version: r.version, updatedAt: ch.updatedAt, deleted: !!ch.deleted } };
      }
      return { ...r, server: ex && { module: ch.module, id: ch.id, ...ex } };
    });
  }
  async listRecords(orgId, modules) { return (await this.q('SELECT module,id,data,version,updated_at,deleted FROM records WHERE org_id=$1 AND module = ANY($2)', [orgId, modules])).rows.map(r => ({ module: r.module, id: r.id, data: r.data, version: r.version, updatedAt: r.updated_at.toISOString(), deleted: r.deleted })); }

  async getSubscription(orgId) { const r = (await this.q('SELECT * FROM subscriptions WHERE org_id=$1', [orgId])).rows[0]; return r && { orgId, licenseId: r.license_id, plan: r.plan, status: r.status, expiresAt: r.expires_at && r.expires_at.toISOString() }; }
  async findSubscriptionByLicense(id) { const r = (await this.q('SELECT org_id FROM subscriptions WHERE license_id=$1', [id])).rows[0]; return r && this.getSubscription(r.org_id); }

  // --- billing
  mapPayment(r) { return r && { orderId: r.order_id, orgId: r.org_id, planId: r.plan_id, tier: r.tier, days: r.days, amountUsd: Number(r.amount_usd), provider: r.provider, providerRef: r.provider_ref, feeUsd: r.fee_usd == null ? undefined : Number(r.fee_usd), taxUsd: r.tax_usd == null ? undefined : Number(r.tax_usd), refundedUsd: Number(r.refunded_usd || 0), currency: r.currency || undefined, amountCrypto: r.amount_crypto == null ? undefined : Number(r.amount_crypto), address: r.address || undefined, status: r.status, createdAt: r.created_at.toISOString(), paidAt: r.paid_at && r.paid_at.toISOString() }; }
  async createPayment(p) { return this.mapPayment((await this.q('INSERT INTO payments(order_id,org_id,plan_id,tier,days,amount_usd,provider,currency,amount_crypto,address) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *', [p.orderId, p.orgId, p.planId, p.tier, p.days, p.amountUsd, p.provider, p.currency || null, p.amountCrypto ?? null, p.address || null])).rows[0]); }
  async getPayment(orderId) { return this.mapPayment((await this.q('SELECT * FROM payments WHERE order_id=$1', [orderId])).rows[0]); }
  async setPaymentRef(orderId, ref) { await this.q('UPDATE payments SET provider_ref=$2 WHERE order_id=$1', [orderId, ref]); }
  async failPayment(orderId) { await this.q("UPDATE payments SET status='failed' WHERE order_id=$1 AND status='pending'", [orderId]); }
  async listPendingDirect() { return (await this.q("SELECT * FROM payments WHERE provider='direct' AND status='pending' ORDER BY created_at")).rows.map(r => this.mapPayment(r)); }
  // --- usage ledger / policy / adjustments
  async addUsage(orgId, row) { await this.q('INSERT INTO usage_ledger(org_id,user_id,kind,cost_usd,credit_usd,meta,at) VALUES($1,$2,$3,$4,$5,$6,COALESCE($7::timestamptz,now()))', [orgId, row.userId || '', row.kind, row.costUsd, row.creditUsd || 0, row.meta || '', row.at || null]); }
  async sumUsage(orgId, fromIso, toIso) {
    const rows = (await this.q("SELECT kind,user_id,SUM(cost_usd-credit_usd) v FROM usage_ledger WHERE org_id=$1 AND kind<>'credit' AND at>=$2 AND at<$3 GROUP BY kind,user_id", [orgId, fromIso, toIso])).rows;
    const out = { spentUsd: 0, byKind: {}, byUser: {} };
    for (const r of rows) { const v = Number(r.v); out.spentUsd += v; out.byKind[r.kind] = (out.byKind[r.kind] || 0) + v; out.byUser[r.user_id] = (out.byUser[r.user_id] || 0) + v; }
    return out;
  }
  async creditBalance(orgId) { const r = (await this.q("SELECT COALESCE(SUM(CASE WHEN kind='credit' THEN cost_usd ELSE -credit_usd END),0) b FROM usage_ledger WHERE org_id=$1", [orgId])).rows[0]; return Math.max(0, Number(r.b)); }
  async getSetting(key) { const r = (await this.q('SELECT value FROM settings WHERE key=$1', [key])).rows[0]; return r ? r.value : null; }
  async setSetting(key, value) { await this.q('INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value', [key, JSON.stringify(value)]); }
  async adjustPayment(orderId, a) { await this.q('UPDATE payments SET fee_usd=COALESCE($2,fee_usd), tax_usd=COALESCE($3,tax_usd), refunded_usd=COALESCE($4,refunded_usd) WHERE order_id=$1', [orderId, a.feeUsd ?? null, a.taxUsd ?? null, a.refundedUsd ?? null]); return this.getPayment(orderId); }
  async listOrgs() { return (await this.q('SELECT id,name FROM organizations ORDER BY created_at')).rows; }
  async listPayments(orgId) { return (await this.q('SELECT * FROM payments WHERE org_id=$1 ORDER BY created_at DESC LIMIT 100', [orgId])).rows.map(r => this.mapPayment(r)); }
  async completePayment(orderId, providerRef) {
    return this.tx(async (c) => {
      const p = (await c.query('SELECT * FROM payments WHERE order_id=$1 FOR UPDATE', [orderId])).rows[0];
      if (!p) return { applied: false };
      if (p.status === 'paid') return { applied: false };
      await c.query("UPDATE payments SET status='paid', paid_at=now(), provider_ref=COALESCE($2,provider_ref) WHERE order_id=$1", [orderId, providerRef || null]);
      // renew from the current expiry when the same tier is still running, otherwise from now
      await c.query("UPDATE subscriptions SET plan=$2, status='active', provider=$4, provider_ref=$5, expires_at = GREATEST(now(), CASE WHEN plan=$2 AND expires_at IS NOT NULL THEN expires_at ELSE now() END) + ($3 * interval '1 day') WHERE org_id=$1", [p.org_id, p.tier, p.days, p.provider, providerRef || p.provider_ref]);
      const s = (await c.query('SELECT * FROM subscriptions WHERE org_id=$1', [p.org_id])).rows[0];
      return { applied: true, subscription: { orgId: p.org_id, licenseId: s.license_id, plan: s.plan, status: s.status, expiresAt: s.expires_at.toISOString() } };
    });
  }
  async incAiUsage(orgId, day) { return (await this.q('INSERT INTO ai_usage(org_id,day,calls) VALUES($1,$2,1) ON CONFLICT (org_id,day) DO UPDATE SET calls=ai_usage.calls+1 RETURNING calls', [orgId, day])).rows[0].calls; }

  async appendAudit(orgId, e) {
    return this.tx(async (c) => {
      await c.query('SELECT id FROM organizations WHERE id=$1 FOR UPDATE', [orgId]);      // serialises the chain per organization
      const prev = (await c.query('SELECT hash FROM audit_log WHERE org_id=$1 ORDER BY seq DESC LIMIT 1', [orgId])).rows[0];
      const prevHash = prev ? prev.hash : GENESIS, hash = chainHash(prevHash, e);
      const r = (await c.query('INSERT INTO audit_log(org_id,at,user_id,role,action,module,record_id,details,ip,prev_hash,hash) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING seq', [orgId, e.at, e.userId, e.role, e.action, e.module, e.recordId, e.details, e.ip, prevHash, hash])).rows[0];
      return { seq: Number(r.seq), orgId, ...e, prevHash, hash };
    });
  }
  mapAudit(r) { return { seq: Number(r.seq), at: r.at.toISOString(), userId: r.user_id, role: r.role, action: r.action, module: r.module, recordId: r.record_id, details: r.details, ip: r.ip, prevHash: r.prev_hash, hash: r.hash }; }
  async listAudit(orgId, limit = 100) { return (await this.q('SELECT * FROM audit_log WHERE org_id=$1 ORDER BY seq DESC LIMIT $2', [orgId, limit])).rows.map(r => this.mapAudit(r)); }
  async allAudit(orgId) { return (await this.q('SELECT * FROM audit_log WHERE org_id=$1 ORDER BY seq ASC', [orgId])).rows.map(r => this.mapAudit(r)); }
}
