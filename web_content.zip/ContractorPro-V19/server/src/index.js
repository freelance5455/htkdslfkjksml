import http from 'node:http';
import { createApp } from './app.js';
import { MemoryStore } from './store-memory.js';
import { AnthropicProvider, LocalProvider } from './ai-gateway.js';
import { parseDirect } from './direct.js';
import { BtcPayProvider, NowPaymentsProvider, parsePlans } from './billing.js';

const env = process.env, prod = env.NODE_ENV === 'production';
const jwtSecret = env.JWT_SECRET || '';
if (prod && jwtSecret.length < 32) { console.error('JWT_SECRET (>=32 chars) is required in production'); process.exit(1); }
if (prod && !env.DATABASE_URL) { console.error('DATABASE_URL is required in production (in-memory storage would lose data)'); process.exit(1); }

let store;
if (env.DATABASE_URL) { const { PgStore } = await import('./store-pg.js'); store = await PgStore.connect(env.DATABASE_URL); }
else { console.warn('WARNING: no DATABASE_URL — using in-memory store (development only)'); store = new MemoryStore(); }

const aiProvider = env.ANTHROPIC_API_KEY ? new AnthropicProvider({ apiKey: env.ANTHROPIC_API_KEY, model: env.AI_MODEL || 'claude-sonnet-5-5' }) : new LocalProvider();
// Development mailer prints the OTP to the console. In production configure a real mailer (SMTP/provider) instead.
const mailer = prod ? null : { mode: 'console', async send(email, code) { console.log(`[dev OTP] ${email}: ${code}`); } };

const providers = {};
if (env.BTCPAY_URL && env.BTCPAY_STORE_ID && env.BTCPAY_API_KEY && env.BTCPAY_WEBHOOK_SECRET)
  providers.btcpay = new BtcPayProvider({ baseUrl: env.BTCPAY_URL, storeId: env.BTCPAY_STORE_ID, apiKey: env.BTCPAY_API_KEY, webhookSecret: env.BTCPAY_WEBHOOK_SECRET, redirectUrl: env.PAYMENT_SUCCESS_URL || '' });
if (env.NOWPAYMENTS_API_KEY && env.NOWPAYMENTS_IPN_SECRET)
  providers.nowpayments = new NowPaymentsProvider({ apiKey: env.NOWPAYMENTS_API_KEY, ipnSecret: env.NOWPAYMENTS_IPN_SECRET, publicUrl: env.PUBLIC_URL || '', successUrl: env.PAYMENT_SUCCESS_URL || '' });
if (prod && !Object.keys(providers).length) console.warn('WARNING: no crypto payment provider configured; checkout will return 501');
let plans; try { plans = parsePlans(env.PLANS_JSON); } catch (e) { console.error('PLANS_JSON invalid:', e.message); process.exit(1); }

if (env.OPERATOR_TOKEN && env.OPERATOR_TOKEN.length < 24) { console.error('OPERATOR_TOKEN must be at least 24 chars'); process.exit(1); }
let direct = null; try { direct = parseDirect(env); } catch (e) { console.error(e.message); process.exit(1); }
const handler = createApp({
  store, aiProvider, mailer, billing: { plans, providers, direct },
  config: { operatorToken: env.OPERATOR_TOKEN || '', jwtSecret: jwtSecret || 'dev-only-secret-change-me-dev-only-secret', corsOrigins: (env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean), aiDailyLimit: env.AI_DAILY_LIMIT_PER_ORG ? Number(env.AI_DAILY_LIMIT_PER_ORG) : undefined }
});
http.createServer(handler).listen(Number(env.PORT) || 8080, () => console.log('Contractor Pro server listening on', env.PORT || 8080));
