import { randomUUID } from 'node:crypto';
import { hashPassword, verifyPassword, signJwt, verifyJwt, randomToken, sha256 } from './crypto.js';
import { can, canAssignRole, canPushSnapshot, filterSnapshot, readableModules, DATA_MODULES, ROLES } from './rbac.js';
import { verifyChain } from './audit.js';
import { askAi, LocalProvider } from './ai-gateway.js';
import { runTask, TaskError } from './ai-tasks.js';
import { getBtcUsdRate } from './crypto-rates.js';
import { uniqueAmount, tokenOk } from './direct.js';
import { sanitizePolicy, currentWindow, netRevenue, aiCost, syncCost, approxTokens, levelOf } from './usage.js';
import { DEFAULT_PLANS, DEFAULT_AI_LIMITS, effectiveTier, near } from './billing.js';

export const VERSION = '1.2.0';
const ACCESS_TTL = 15 * 60, REFRESH_TTL = 30 * 24 * 3600, OTP_TTL = 10 * 60;
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m) => new HttpError(400, m), deny = (m = 'Forbidden') => new HttpError(403, m);

export function createApp({ store, config, aiProvider = new LocalProvider(), mailer = null, billing = {} }) {
  const secret = config.jwtSecret;
  const plans = billing.plans || DEFAULT_PLANS, providers = billing.providers || {}, aiLimits = { ...DEFAULT_AI_LIMITS, ...(billing.aiLimits || {}) };
  const direct = billing.direct || null, rateFn = billing.rate || (() => getBtcUsdRate());
  const hits = new Map();
  function limit(key, max, windowMs) {
    const now = Date.now(), arr = (hits.get(key) || []).filter(t => now - t < windowMs);
    if (arr.length >= max) throw new HttpError(429, 'Too many attempts, try again later');
    arr.push(now); hits.set(key, arr);
  }

  const json = (res, status, body, extra = {}) => {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extra });
    res.end(JSON.stringify(body));
  };
  function cors(req) {
    const o = req.headers.origin, list = config.corsOrigins || [];
    const h = { vary: 'Origin', 'access-control-allow-methods': 'GET,POST,PUT,PATCH,OPTIONS', 'access-control-allow-headers': 'authorization,content-type', 'access-control-max-age': '600' };
    if (!list.length) h['access-control-allow-origin'] = '*';
    else if (o && list.includes(o)) h['access-control-allow-origin'] = o;
    return h;
  }
  async function rawBody(req, max) {
    let size = 0; const chunks = [];
    for await (const c of req) { size += c.length; if (size > max) throw new HttpError(413, 'Payload too large'); chunks.push(c); }
    return Buffer.concat(chunks);
  }
  async function body(req, max = 10 * 1024 * 1024) {
    const raw = await rawBody(req, max);
    if (!raw.length) return {};
    try { const j = JSON.parse(raw.toString('utf8')); return j && typeof j === 'object' ? j : {}; } catch { throw bad('Invalid JSON'); }
  }
  const aiLimitFor = async (orgId) => config.aiDailyLimit ?? aiLimits[effectiveTier(await store.getSubscription(orgId))] ?? aiLimits.free;
  const systemCtx = (orgId, ip) => ({ user: { id: 'system' }, orgId, role: 'system', ip });


  // ---- per-customer cost cap (see usage.js). Enforced here on the server, never only in the app.
  const opToken = config.operatorToken || (direct && direct.operatorToken) || '';
  const USAGE_MSG = 'Usage limit reached. Costly features (AI, uploads) are paused until the next period or until extra credit is added. Your data and offline features are not affected.';
  const USER_MSG = 'Your personal share of the team usage budget is used up for this period. Ask the account owner for more.';
  function opAuth(req) {
    if (!opToken) throw new HttpError(404, 'Not found');
    limit('op|' + req.socket?.remoteAddress, 60, 60e3);
    if (!tokenOk(String(req.headers['x-operator-token'] || ''), opToken)) throw new HttpError(401, 'Bad operator token');
  }
  const getPolicy = async () => sanitizePolicy((await store.getSetting('policy')) || {});
  async function usageState(orgId, now = Date.now()) {
    const pol = await getPolicy(), paid = (await store.listPayments(orgId)).filter(p => p.status === 'paid' && p.paidAt);
    const w = currentWindow(paid, pol, now), sum = await store.sumUsage(orgId, w.start, w.end), credit = await store.creditBalance(orgId);
    const pct = w.budgetUsd > 0 ? Math.round(sum.spentUsd / w.budgetUsd * 1e9) / 1e9 : 1;
    return { pol, w, sum, credit, pct, level: levelOf(pct, credit, pol) };
  }
  async function guard(c, estimateUsd) {
    const st = await usageState(c.orgId), remaining = Math.max(0, st.w.budgetUsd - st.sum.spentUsd) + st.credit;
    if (estimateUsd > remaining) throw new HttpError(402, USAGE_MSG);
    if (c.role !== 'owner' && effectiveTier(await store.getSubscription(c.orgId)) === 'team' && (st.sum.byUser[c.user.id] || 0) + estimateUsd > st.w.budgetUsd * st.pol.perUserShare) throw new HttpError(402, USER_MSG);
    return st;
  }
  async function record(c, kind, costUsd, meta) {
    if (!(costUsd > 0)) return;
    const st = await usageState(c.orgId), free = Math.max(0, Math.min(costUsd, st.w.budgetUsd - st.sum.spentUsd));
    await store.addUsage(c.orgId, { userId: c.user.id, kind, costUsd, creditUsd: Math.min(costUsd - free, st.credit), meta });
  }
  const view = (st, role) => ({
    period: { start: st.w.start, end: st.w.end, paid: st.w.paid }, budgetUsd: round(st.w.budgetUsd), spentUsd: round(st.sum.spentUsd), creditUsd: round(st.credit),
    remainingUsd: round(Math.max(0, st.w.budgetUsd - st.sum.spentUsd) + st.credit), percent: Math.round(st.pct * 1000) / 10, level: st.level, byKind: Object.fromEntries(Object.entries(st.sum.byKind).map(([k, v]) => [k, round(v)])),
    ...(['owner', 'admin'].includes(role) ? { byUser: Object.fromEntries(Object.entries(st.sum.byUser).map(([k, v]) => [k, round(v)])) } : {})
  });
  const round = (n) => Math.round(n * 1e6) / 1e6;

  async function issue(user, member) {
    const refreshToken = randomToken(48);
    await store.saveRefresh(sha256(refreshToken), user.id, Date.now() + REFRESH_TTL * 1000);
    const accessToken = signJwt({ sub: user.id }, secret, ACCESS_TTL);
    return { accessToken, refreshToken, expiresIn: ACCESS_TTL, user: { id: user.id, email: user.email, emailVerified: !!user.emailVerified, workspaceId: member.orgId, role: member.role } };
  }
  async function auth(req) {
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    const claims = m && verifyJwt(m[1], secret);
    if (!claims) throw new HttpError(401, 'Authentication required');
    const user = await store.getUserById(claims.sub), member = user && await store.getMembership(user.id);
    if (!member) throw new HttpError(401, 'Authentication required');
    return { user, orgId: member.orgId, role: member.role, ip: req.socket?.remoteAddress || '' };
  }
  const log = (ctx, action, module = '', recordId = '', details = '') =>
    store.appendAudit(ctx.orgId, { at: new Date().toISOString(), userId: ctx.user.id, role: ctx.role, action, module, recordId, details: String(details).slice(0, 300), ip: ctx.ip });
  const need = (ctx, action, resource) => { if (!can(ctx.role, action, resource)) throw deny(); };
  const normEmail = (e) => String(e || '').trim().toLowerCase();
  const checkPassword = (p) => { if (typeof p !== 'string' || p.length < 10 || p.length > 200) throw bad('Password must be 10-200 characters'); };

  const routes = {
    'GET /health': async () => [200, { ok: true, version: VERSION, store: store.kind }],

    'POST /api/auth/register': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email);
      if (!EMAIL.test(email)) throw bad('Invalid email'); checkPassword(b.password);
      limit('reg|' + req.socket?.remoteAddress, 10, 3600e3);
      if (await store.getUserByEmail(email)) throw new HttpError(409, 'Account already exists');
      const { user, org } = await store.createOrgWithOwner({ orgName: String(b.orgName || email.split('@')[0]).slice(0, 120), email, passwordHash: await hashPassword(b.password) });
      const member = await store.getMembership(user.id);
      const ctx = { user, orgId: org.id, role: 'owner', ip: req.socket?.remoteAddress || '' }; await log(ctx, 'register', 'users', user.id);
      return [201, await issue(user, member)];
    },
    'POST /api/auth/login': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email);
      limit('login|' + email, 8, 15 * 60e3); limit('loginip|' + req.socket?.remoteAddress, 40, 15 * 60e3);
      const user = await store.getUserByEmail(email);
      // verify against a dummy hash when user is unknown so timing does not reveal accounts
      const ok = await verifyPassword(String(b.password || ''), user?.passwordHash || 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAA');
      if (!user || !ok) throw new HttpError(401, 'Invalid email or password');
      const member = await store.getMembership(user.id); if (!member) throw new HttpError(401, 'Invalid email or password');
      await log({ user, orgId: member.orgId, role: member.role, ip: req.socket?.remoteAddress || '' }, 'login', 'users', user.id);
      return [200, await issue(user, member)];
    },
    'POST /api/auth/request-otp': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email);
      if (!EMAIL.test(email)) throw bad('Invalid email');
      limit('otp|' + email, 5, 3600e3);
      if (!mailer) throw new HttpError(501, 'Email delivery is not configured on this server');
      const code = String(Math.floor(100000 + Math.random() * 900000));
      await store.setOtp(email, sha256(email + ':' + code), Date.now() + OTP_TTL * 1000);
      await mailer.send(email, code);
      return [200, { ok: true, deliveryMode: mailer.mode || 'provider' }];
    },
    'POST /api/auth/verify-otp': async (req) => {
      const b = await body(req, 1e5), email = normEmail(b.email), code = String(b.code || '').trim();
      limit('otpv|' + email, 10, 3600e3);
      const o = await store.getOtp(email);
      if (!o || o.expiresAt < Date.now() || o.attempts >= 5) throw new HttpError(401, 'Invalid or expired code');
      if (sha256(email + ':' + code) !== o.codeHash) { await store.bumpOtp(email); throw new HttpError(401, 'Invalid or expired code'); }
      await store.deleteOtp(email);
      let user = await store.getUserByEmail(email), member;
      if (!user) { ({ user } = await store.createOrgWithOwner({ orgName: email.split('@')[0], email, passwordHash: null, emailVerified: true })); }
      else await store.markVerified(user.id);
      user.emailVerified = true; member = await store.getMembership(user.id);
      await log({ user, orgId: member.orgId, role: member.role, ip: req.socket?.remoteAddress || '' }, 'login-otp', 'users', user.id);
      return [200, await issue(user, member)];
    },
    'POST /api/auth/refresh': async (req) => {
      const b = await body(req, 1e5), r = await store.takeRefresh(sha256(String(b.refreshToken || '')));   // single use (rotation)
      if (!r) throw new HttpError(401, 'Invalid refresh token');
      const user = await store.getUserById(r.userId), member = user && await store.getMembership(user.id);
      if (!member) throw new HttpError(401, 'Invalid refresh token');
      return [200, await issue(user, member)];
    },
    'POST /api/auth/logout': async (req) => { const c = await auth(req); await store.revokeRefresh(c.user.id); await log(c, 'logout', 'users', c.user.id); return [200, { ok: true }]; },
    'GET /api/auth/me': async (req) => { const c = await auth(req); return [200, { user: { id: c.user.id, email: c.user.email, emailVerified: !!c.user.emailVerified, workspaceId: c.orgId, role: c.role, permissions: { readable: readableModules(c.role) } } }]; },
    'POST /api/account/password': async (req) => {
      const c = await auth(req), b = await body(req, 1e5); checkPassword(b.password);
      await store.setPassword(c.user.id, await hashPassword(b.password)); await store.revokeRefresh(c.user.id);
      await log(c, 'password-change', 'users', c.user.id); return [200, { ok: true }];
    },

    'GET /api/users': async (req) => { const c = await auth(req); need(c, 'read', 'users'); return [200, { users: await store.listMembers(c.orgId) }]; },
    'POST /api/users': async (req) => {
      const c = await auth(req), b = await body(req, 1e5), email = normEmail(b.email);
      if (!EMAIL.test(email)) throw bad('Invalid email'); checkPassword(b.password);
      if (!canAssignRole(c.role, b.role)) throw deny('You cannot assign this role');
      if (await store.getUserByEmail(email)) throw new HttpError(409, 'Account already exists');
      const user = await store.createUser({ email, passwordHash: await hashPassword(b.password) });
      await store.addMember({ orgId: c.orgId, userId: user.id, role: b.role });
      await log(c, 'user-create', 'users', user.id, `role=${b.role}`); return [201, { user: { id: user.id, email, role: b.role } }];
    },
    'PATCH /api/users/:id': async (req, p) => {
      const c = await auth(req), b = await body(req, 1e5);
      if (p.id === c.user.id) throw deny('You cannot change your own role');
      const target = await store.getMembership(p.id);
      if (!target || target.orgId !== c.orgId) throw new HttpError(404, 'User not found');
      if (!canAssignRole(c.role, b.role) || !canAssignRole(c.role, target.role)) throw deny('You cannot assign this role');
      await store.setRole(c.orgId, p.id, b.role); await log(c, 'role-change', 'users', p.id, `${target.role}->${b.role}`); return [200, { ok: true }];
    },
    'GET /api/audit': async (req, _p, url) => {
      const c = await auth(req); need(c, 'read', 'audit');
      const n = Math.min(500, Math.max(1, Number(url.searchParams.get('limit')) || 100));
      return [200, { entries: await store.listAudit(c.orgId, n), chain: verifyChain(await store.allAudit(c.orgId)) }];
    },

    'POST /api/sync/push': async (req) => {
      const c = await auth(req), b = await body(req);
      if (b.workspaceId !== c.orgId) throw deny('Wrong workspace');
      if (!canPushSnapshot(c.role)) throw deny('Your role cannot upload a full backup');
      if (!b.snapshot || typeof b.snapshot !== 'object' || Array.isArray(b.snapshot)) throw bad('snapshot is required');
      const pol = await getPolicy(), bytes = Buffer.byteLength(JSON.stringify(b.snapshot));
      await guard(c, syncCost(bytes, pol));
      const cursor = await store.pushSnapshot(c.orgId, String(b.deviceId || ''), b.snapshot);
      await record(c, 'sync', syncCost(bytes, pol), 'push');
      await log(c, 'sync-push', 'sync', String(cursor)); return [200, { ok: true, cursor }];
    },
    'GET /api/sync/pull': async (req, _p, url) => {
      const c = await auth(req);
      if (url.searchParams.get('workspaceId') !== c.orgId) throw deny('Wrong workspace');
      const s = await store.latestSnapshot(c.orgId);
      return [200, { latest: s ? filterSnapshot(s.data, c.role) : null, cursor: s ? s.cursor : 0 }];
    },
    'POST /api/sync/changes': async (req) => {
      const c = await auth(req), b = await body(req);
      if (!Array.isArray(b.changes) || b.changes.length > 500) throw bad('changes must be an array of at most 500 items');
      const applied = [], conflicts = [], rejected = [];
      for (const ch of b.changes) {
        if (!ch || !DATA_MODULES.includes(ch.module) || typeof ch.id !== 'string' || !ch.id || ch.id.length > 120) { rejected.push({ id: ch?.id, reason: 'invalid' }); continue; }
        if (!can(c.role, ch.deleted ? 'delete' : 'write', ch.module)) { rejected.push({ module: ch.module, id: ch.id, reason: 'forbidden' }); continue; }
        const r = await store.applyChange(c.orgId, ch);
        if (r.status === 'invalid') rejected.push({ module: ch.module, id: ch.id, reason: 'invalid' });
        else if (r.status === 'conflict') conflicts.push({ module: ch.module, id: ch.id, resolved: r.resolved, server: r.server });
        else { applied.push({ module: ch.module, id: ch.id, version: r.version, resolved: r.resolved }); await log(c, ch.deleted ? 'delete' : 'sync-write', ch.module, ch.id); }
      }
      return [200, { applied, conflicts, rejected }];
    },
    'GET /api/sync/records': async (req) => { const c = await auth(req); return [200, { records: await store.listRecords(c.orgId, readableModules(c.role)) }]; },

    'POST /api/license/validate': async (req) => {
      const c = await auth(req), b = await body(req, 1e5);
      const sub = await store.getSubscription(c.orgId);
      const valid = !!sub && sub.licenseId === String(b.licenseId || '') && sub.status === 'active' && (!sub.expiresAt || new Date(sub.expiresAt) > new Date());
      return [200, { valid, plan: valid ? sub.plan : null, expiresAt: valid ? sub.expiresAt : null }];
    },
    'GET /api/billing/plans': async () => [200, {
      plans: Object.entries(plans).map(([id, p]) => ({ id, tier: p.tier, usd: p.usd, days: p.days })),
      providers: Object.keys(providers), direct: direct ? { currencies: Object.keys(direct.wallets), usdtNetwork: direct.usdtNetwork } : null, currencies: 'BTC, USDT and other coins offered by the payment provider at checkout'
    }],
    'GET /api/billing/status': async (req) => {
      const c = await auth(req); need(c, 'read', 'billing');
      const sub = await store.getSubscription(c.orgId);
      return [200, { subscription: sub && { licenseId: sub.licenseId, plan: effectiveTier(sub), expiresAt: sub.expiresAt }, payments: await store.listPayments(c.orgId) }];
    },
    'POST /api/billing/create-checkout': async (req) => {
      const c = await auth(req); need(c, 'write', 'billing');
      const b = await body(req, 1e4), plan = plans[String(b.plan || '')];
      if (!Object.keys(providers).length) throw new HttpError(501, 'No payment provider is configured on this server');
      if (!plan) throw bad('Unknown plan');
      const name = String(b.provider || Object.keys(providers)[0]), prov = providers[name];
      if (!prov) throw bad('Unknown payment provider');
      limit('checkout|' + c.orgId, 10, 3600e3);
      const orderId = 'ORD-' + randomUUID();
      await store.createPayment({ orderId, orgId: c.orgId, planId: b.plan, tier: plan.tier, days: plan.days, amountUsd: plan.usd, provider: name });
      let out;
      try { out = await prov.createCheckout({ orderId, amountUsd: plan.usd, description: `Contractor Pro ${b.plan}`, buyerEmail: c.user.email }); }
      catch { await store.failPayment(orderId); throw new HttpError(502, 'Payment provider is temporarily unavailable'); }
      await store.setPaymentRef(orderId, out.providerRef);
      await log(c, 'checkout-create', 'billing', orderId, `${b.plan} ${plan.usd}USD via ${name}`);
      return [201, { orderId, checkoutUrl: out.checkoutUrl, provider: name, amountUsd: plan.usd }];
    },
    // ---- direct wallet payments (customer -> operator's own address). Only the operator can confirm.
    'POST /api/billing/direct-invoice': async (req) => {
      const c = await auth(req); need(c, 'write', 'billing');
      if (!direct) throw new HttpError(501, 'Direct wallet payments are not configured on this server');
      const b = await body(req, 1e4), plan = plans[String(b.plan || '')], currency = String(b.currency || '').toLowerCase();
      if (!plan) throw bad('Unknown plan');
      const address = direct.wallets[currency]; if (!address) throw bad('currency is not available');
      limit('direct|' + c.orgId, 10, 3600e3);
      let base;
      if (currency === 'usdt') base = plan.usd;
      else { let rate; try { rate = await rateFn(); } catch { throw new HttpError(503, 'Live exchange rate is temporarily unavailable, try again shortly'); } if (!(rate > 0)) throw new HttpError(503, 'Live exchange rate is temporarily unavailable, try again shortly'); base = Math.round(plan.usd / rate * 1e8) / 1e8; }
      let inv, amountCrypto, orderId;
      for (let attempt = 0; attempt < 4 && !inv; attempt++) {   // a concurrent request may grab the same unique amount (DB unique index): pick again
        const open = (await store.listPendingDirect()).filter(p => p.currency === currency).map(p => p.amountCrypto);
        amountCrypto = uniqueAmount(currency, base, open); orderId = 'DIR-' + randomUUID();
        try { inv = await store.createPayment({ orderId, orgId: c.orgId, planId: b.plan, tier: plan.tier, days: plan.days, amountUsd: plan.usd, provider: 'direct', currency, amountCrypto, address }); }
        catch (e) { if (e && e.code === '23505' && attempt < 3) continue; throw e; }
      }
      await log(c, 'direct-invoice-create', 'billing', orderId, `${b.plan} ${amountCrypto} ${currency}`);
      return [201, { orderId, plan: b.plan, currency, amountCrypto, address, network: currency === 'usdt' ? direct.usdtNetwork : 'bitcoin', status: inv.status }];
    },
    'GET /api/billing/direct-invoices': async (req) => {
      const c = await auth(req); need(c, 'read', 'billing');
      return [200, { invoices: (await store.listPayments(c.orgId)).filter(p => p.provider === 'direct').map(p => ({ orderId: p.orderId, plan: p.planId, currency: p.currency, amountCrypto: p.amountCrypto, address: p.address, status: p.status, createdAt: p.createdAt, paidAt: p.paidAt })) }];
    },
    'GET /api/operator/direct-pending': async (req) => {
      if (!direct) throw new HttpError(404, 'Not found'); opAuth(req);
      return [200, { pending: (await store.listPendingDirect()).map(p => ({ orderId: p.orderId, orgId: p.orgId, plan: p.planId, currency: p.currency, amountCrypto: p.amountCrypto, address: p.address, createdAt: p.createdAt })) }];
    },
    'POST /api/operator/direct-confirm/:id': async (req, p) => {
      if (!direct) throw new HttpError(404, 'Not found'); opAuth(req);
      const b = await body(req, 1e4), pay = await store.getPayment(p.id);
      if (!pay || pay.provider !== 'direct') throw new HttpError(404, 'Unknown invoice');
      const txid = String(b.txid || '').trim().slice(0, 120);
      const r = await store.completePayment(pay.orderId, txid ? 'tx:' + txid : 'operator');
      if (r.applied) await log(systemCtx(pay.orgId, req.socket?.remoteAddress || ''), 'subscription-paid', 'billing', pay.orderId, `direct ${pay.planId} until ${r.subscription.expiresAt} tx=${txid || '-'}`);
      return [200, { ok: true, applied: r.applied }];
    },
    'POST /api/billing/webhook/:provider': async (req, p) => {
      const prov = providers[p.provider]; if (!prov) throw new HttpError(404, 'Not found');
      limit('wh|' + req.socket?.remoteAddress, 300, 60e3);
      const raw = await rawBody(req, 1e5), ev = prov.verifyWebhook(raw, req.headers);
      if (!ev) throw new HttpError(401, 'Bad signature');
      if (ev.status === 'ignore') return [200, { ok: true, ignored: true }];
      const pay = ev.orderId && await store.getPayment(ev.orderId);
      if (!pay || pay.provider !== p.provider) throw new HttpError(404, 'Unknown order');
      if (ev.status === 'failed') { await store.failPayment(pay.orderId); return [200, { ok: true }]; }
      let real; try { real = await prov.confirm(ev); } catch { throw new HttpError(502, 'Could not confirm payment with provider'); }   // provider retries the webhook later
      if (!real.paid) return [200, { ok: true, pending: true }];
      if (real.orderId !== pay.orderId || !near(real.amountUsd, pay.amountUsd)) { await store.appendAudit(pay.orgId, { at: new Date().toISOString(), userId: 'system', role: 'system', action: 'billing-mismatch', module: 'billing', recordId: pay.orderId, details: 'amount/order mismatch', ip: '' }); throw bad('Payment does not match the order'); }
      const r = await store.completePayment(pay.orderId, ev.providerRef);
      if (r.applied) await log(systemCtx(pay.orgId, ''), 'subscription-paid', 'billing', pay.orderId, `${pay.planId} until ${r.subscription.expiresAt}`);
      return [200, { ok: true, applied: r.applied }];
    },

    // ---- usage / cost cap
    'GET /api/usage': async (req) => { const c = await auth(req); return [200, view(await usageState(c.orgId), c.role)]; },
    'GET /api/operator/policy': async (req) => { opAuth(req); return [200, { policy: await getPolicy() }]; },
    'PUT /api/operator/policy': async (req) => {
      opAuth(req); const b = await body(req, 1e4); let pol;
      try { pol = sanitizePolicy(b, await getPolicy()); } catch (e) { throw bad(e.message); }
      await store.setSetting('policy', pol); return [200, { policy: pol }];
    },
    'POST /api/operator/credit': async (req) => {
      opAuth(req); const b = await body(req, 1e4), usd = Number(b.usd);
      if (!(usd > 0 && usd <= 1000)) throw bad('usd must be between 0 and 1000');
      const orgs = await store.listOrgs(); if (!orgs.some(o => o.id === b.orgId)) throw new HttpError(404, 'Unknown organization');
      await store.addUsage(b.orgId, { userId: 'operator', kind: 'credit', costUsd: usd, creditUsd: 0, meta: String(b.note || '').slice(0, 200) });
      await log(systemCtx(b.orgId, ''), 'credit-add', 'billing', '', `${usd} USD ${String(b.note || '').slice(0, 80)}`);
      return [200, { ok: true, creditUsd: round(await store.creditBalance(b.orgId)) }];
    },
    'POST /api/operator/payment-adjust/:id': async (req, p) => {
      opAuth(req); const b = await body(req, 1e4), a = {};
      for (const k of ['feeUsd', 'taxUsd', 'refundedUsd']) if (b[k] !== undefined) { const n = Number(b[k]); if (!(n >= 0 && n < 1e6)) throw bad(k + ' is invalid'); a[k] = n; }
      const pay = await store.adjustPayment(p.id, a); if (!pay) throw new HttpError(404, 'Unknown payment');
      await log(systemCtx(pay.orgId, ''), 'payment-adjust', 'billing', p.id, JSON.stringify(a)); return [200, { ok: true }];
    },
    'GET /api/operator/usage-overview': async (req) => {
      opAuth(req); const rows = [];
      for (const o of await store.listOrgs()) {
        const st = await usageState(o.id), sub = await store.getSubscription(o.id);
        rows.push({ orgId: o.id, name: o.name, tier: effectiveTier(sub), revenueUsd: round(st.w.revenueUsd), budgetUsd: round(st.w.budgetUsd), spentUsd: round(st.sum.spentUsd), creditUsd: round(st.credit), percent: Math.round(st.pct * 1000) / 10, level: st.level, marginUsd: round(st.w.revenueUsd - st.sum.spentUsd), periodEnd: st.w.end });
      }
      return [200, { orgs: rows, totals: { revenueUsd: round(rows.reduce((a, r) => a + r.revenueUsd, 0)), spentUsd: round(rows.reduce((a, r) => a + r.spentUsd, 0)), marginUsd: round(rows.reduce((a, r) => a + r.marginUsd, 0)) } }];
    },

    'POST /api/ai/copilot': async (req) => {
      const c = await auth(req); need(c, 'read', 'ai');
      const b = await body(req, 2e5), q = String(b.question || '').trim();
      if (!q) throw bad('question is required'); if (q.length > 2000) throw bad('question is too long');
      const day = new Date().toISOString().slice(0, 10);
      const calls = await store.incAiUsage(c.orgId, day);
      if (calls > await aiLimitFor(c.orgId)) throw new HttpError(429, 'Daily AI limit reached');
      const pol = await getPolicy(), estIn = 8000 + approxTokens(q.length);
      if (aiProvider.name !== 'local') await guard(c, aiCost(estIn, 1000, pol));
      const snap = await store.latestSnapshot(c.orgId);                   // data comes from the server, never from the client
      let out; const meter = {};
      try { out = await askAi({ provider: aiProvider, question: q, snapshot: snap ? snap.data : {}, role: c.role, onUsage: u => Object.assign(meter, u) }); }
      catch { throw new HttpError(502, 'AI service is temporarily unavailable'); }
      if (aiProvider.name !== 'local') await record(c, 'ai', aiCost(meter.inputTokens ?? estIn, meter.outputTokens ?? approxTokens(String(out.answer || '').length), pol), 'copilot');
      await log(c, 'ai-ask', 'ai', '', `provider=${out.provider} modules=${out.modules.length}`);
      return [200, out];
    },
    'POST /api/ai/task': async (req) => {
      const c = await auth(req); need(c, 'read', 'ai');
      const b = await body(req, 25 * 1024 * 1024);
      const day = new Date().toISOString().slice(0, 10);
      const calls = await store.incAiUsage(c.orgId, day);
      if (calls > await aiLimitFor(c.orgId)) throw new HttpError(429, 'Daily AI limit reached');
      const pol = await getPolicy(), hasFile = typeof b.data === 'string' ? b.data.length : 0;
      const estIn = 6000 + approxTokens(String(b.text || '').length) + Math.min(60000, Math.ceil(hasFile / 20)), estOut = b.task === 'drawing_to_boq' ? 4000 : b.task === 'contract_review' ? 3000 : 2000;
      if (aiProvider.name !== 'local') await guard(c, aiCost(estIn, estOut, pol));
      const snap = await store.latestSnapshot(c.orgId);
      let out; const meter = {};
      try { out = await runTask({ provider: aiProvider, task: String(b.task || ''), input: b, snapshot: snap ? snap.data : {}, role: c.role, onUsage: u => Object.assign(meter, u) }); }
      catch (e) { if (e instanceof TaskError) throw new HttpError(e.status, e.message); throw e; }
      if (aiProvider.name !== 'local') await record(c, 'ai', aiCost(meter.inputTokens ?? estIn, meter.outputTokens ?? approxTokens(JSON.stringify(out.result || {}).length), pol), 'task:' + out.task);
      await log(c, 'ai-task', 'ai', '', `task=${out.task} provider=${out.provider}`);
      return [200, out];
    }
  };

  const table = Object.entries(routes).map(([k, h]) => {
    const [method, path] = k.split(' ');
    return { method, h, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') };
  });

  return async function handle(req, res) {
    const ch = cors(req);
    try {
      if (req.method === 'OPTIONS') { res.writeHead(204, ch); return res.end(); }
      const url = new URL(req.url, 'http://x');
      for (const r of table) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(url.pathname); if (!m) continue;
        const [status, payload] = await r.h(req, m.groups || {}, url);
        return json(res, status, payload, ch);
      }
      json(res, 404, { error: 'Not found' }, ch);
    } catch (e) {
      if (e instanceof HttpError) return json(res, e.status, { error: e.message }, ch);
      console.error('Unhandled error:', e);
      json(res, 500, { error: 'Internal server error' }, ch);
    }
  };
}
