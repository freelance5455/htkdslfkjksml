# SafeHarbor 1.7.1

## Remoção do bloqueador e da camuflagem

Removidos o módulo Bloqueio de Apps, seu botão no cabeçalho, cadastro, horários, quarentena, barreira de desbloqueio e guia de configuração. Também removidos Modo Camuflagem, PIN, calculadora de disfarce e cadeado da Home. O aplicativo volta a abrir diretamente no SafeHarbor, mesmo quando um PIN e compromissos estavam ativos na versão 1.7.0.

A implementação anterior controlava somente compromissos dentro do SafeHarbor; não impedia abrir outros aplicativos. No APK gerado pelo Website 2 APK Builder, não há uma alternativa confiável de bloqueio real sem integração nativa e configuração/autorização do Android. Por isso, foi aplicada a remoção autorizada, em vez de manter uma chave com aparência de bloqueio do sistema.

Referências: [ativação de serviços de acessibilidade pelo usuário](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService) e [suspensão de pacotes em dispositivos/perfis gerenciados](https://developer.android.com/work/dpc/security).

## Preservação dos dados e das demais funções

- O IndexedDB permanece na versão **4**, compatível com quem instalou a 1.7.0. Não há downgrade, exclusão de banco ou limpeza de stores.
- As stores antigas do módulo ficam inertes, para preservar dados e compatibilidade com backups. Nenhum PIN, timer ou tentativa antiga é ativado ao abrir o app. Os verificadores de dados em `blocker-domain.js` continuam sendo usados somente para compatibilidade de restauração; não oferecem bloqueio nem interface.
- Histórico, áudios, conquistas e impulsos já registrados permanecem. Os backups antigos continuam aceitos e o PIN continua excluído da exportação.
- Mantida a regra da pausa guiada: perguntas somente após deslize/recaída; nos demais casos, nova reflexão e registro sem questionário.
- O tema, logo, check-in, calendário, relatórios, marcos, desafio, citações e biblioteca/player permanecem. O cabeçalho volta à organização anterior, com a engrenagem de ajustes.

## Atualizar seu APK

1. Extraia `SafeHarbor_Website2APK_1.7.1.zip` em uma nova pasta e use essa pasta como conteúdo HTML local do conversor. O `index.html` está na raiz. Assim, os módulos removidos não ficam misturados aos arquivos novos.
2. Mantenha identificador de pacote, chave de assinatura e configuração da origem/caminho local do APK instalado. Aumente o código de versão no conversor.
3. Instale como atualização, **sem desinstalar nem limpar os dados**. O PIN antigo não será solicitado.

O ZIP contém arquivos para gerar o APK, não um APK compilado. O pacote completo `SafeHarbor_1.7.1.zip` inclui fontes, documentação e testes. O container Java opcional usa versionName 1.7.1 e versionCode 16; a versão do APK feito no conversor deve ser ajustada nele.

## Validação

Teste em Edge real com perfil isolado, banco versão 4, PIN ativo, bloqueio em andamento e tentativa pendente: abertura direta, dados legados e áudio preservados, ausência dos controles removidos, reabertura e minimização sem disfarce. Verificadas seis seções em 320, 393, 768 e 1280 px, além de paisagem. Não são mais carregados `privacy.js` ou `blocker.js`.

Migrações 1→4 e 3→4 e compatibilidade de restauração verificadas em `tests/test_v171_data.py`. A pausa sem questionário foi verificada em `tests/test_risk_reflection.py`. Os resultados atuais estão em `tests/VALIDACAO.md`, `tests/v171-results.json` e `tests/v171-data-results.json`. Documentos e imagens da 1.7.0 são registros históricos da funcionalidade removida; os testes ativos dessa interface foram substituídos pelo teste de remoção.

Não houve compilação nem teste em celular Android nesta entrega.
