# Citações e referências técnicas

Os excertos são traduções próprias para pt-BR, a partir de obras antigas ou de originais em domínio público; não reproduzem traduções brasileiras modernas. Não são frases inventadas atribuídas aos autores. Trechos são identificados por obra e seção em `quotes.js`. A linguagem e as ideias refletem seu contexto histórico; não são prescrições clínicas ou regras de conduta do aplicativo.

Exceção deliberada ao pedido de citações sempre longas: Albert Camus aparece com uma única frase breve da conclusão de O mito de Sísifo, por direitos autorais. Os demais excertos são passagens de reflexão mais extensas. Não há carregamento dessas fontes durante o uso do app.

- Epicteto, Manual: texto de referência de Thomas Wentworth Higginson (século XIX): https://www.gutenberg.org/files/45109/45109-h/45109-h.htm (o prefácio editorial moderno não foi usado).
- Marco Aurélio, Meditações: https://www.gutenberg.org/ebooks/2680 . A numeração segue as divisões tradicionais; edições podem subdividir os parágrafos de modo diferente.
- Sêneca, Cartas a Lucílio, cartas 1, 2, 13 e 28: https://la.wikisource.org/wiki/Epistulae_morales_ad_Lucilium .
- Heráclito, fragmento B1 (Diels–Kranz): https://en.wikisource.org/wiki/Early_Greek_Philosophy/Herakleitos_of_Ephesos .
- Platão, Apologia: https://classics.mit.edu/Plato/apology.html ; Críton: https://classics.mit.edu/Plato/crito.html .
- Aristóteles, Ética a Nicômaco, livro II: https://classics.mit.edu/Aristotle/nicomachaen.2.ii.html .
- Dostoiévski, Os irmãos Karamázov, II.IV: https://www.gutenberg.org/ebooks/28054 .
- Franz Kafka, Diante da lei, original: https://de.wikisource.org/wiki/Vor_dem_Gesetz .
- Nietzsche, A gaia ciência, §341: https://www.gutenberg.org/ebooks/52881 .
- Albert Camus, Le Mythe de Sisyphe, Gallimard, 1942, conclusão.

Android, conteúdo local no WebView: https://developer.android.com/develop/ui/views/layout/webapps/load-local-content . O projeto usa interceptação de uma origem HTTPS interna e assets, sem AndroidX e sem acesso à rede.

Fontes são documentação editorial; não são dependências executáveis ou serviços usados pelo aplicativo.


## Ampliação para 150 reflexões

Foram acrescentados 100 excertos: 60 de Marco Aurélio (livros VII e VIII), 30 de Oscar Wilde (De profundis, edição pública de 1913) e 10 de Victor Hugo (Os miseráveis). Os IDs originais foram preservados para manter o histórico de não repetição. As traduções próprias dos novos excertos se baseiam nos textos de domínio público abaixo; não são traduções brasileiras modernas. As etiquetas depois do título são localizadores temáticos editoriais, não títulos de capítulos originais. Os excertos podem recortar uma passagem, sem substituir as obras integrais.

- Marco Aurélio, tradução inglesa de George Long: https://classics.mit.edu/Antoninus/meditations.7.seven.html e https://classics.mit.edu/Antoninus/meditations.8.eight.html
- Oscar Wilde, edição de 1913 de De profundis: https://www.gutenberg.org/cache/epub/921/pg921-images.html
- Victor Hugo, tradução de Isabel F. Hapgood, 1887: https://www.gutenberg.org/files/135/135-h/135-h.htm

Hugo e Wilde foram incluídos entre os novos autores sugeridos. Não foram acrescentadas citações atribuídas a outros autores sem confirmação de fonte, nem longos trechos de obras ainda protegidas. As afirmações sobre sofrimento e caráter pertencem ao contexto histórico dos autores; não são regras clínicas do aplicativo.
