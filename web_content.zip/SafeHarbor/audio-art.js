// Small local JPEG covers keep library rendering independent of audio file size.
const prepared=new WeakMap();
export const validCover=value=>typeof value==='string'&&value.length<=400000&&/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(value);
export async function prepareCover(file){
 if(!file)return null;
 if(!prepared.has(file))prepared.set(file,convert(file));
 return prepared.get(file);
}
async function convert(file){
 if(!/^image\/(jpeg|png|webp)$/.test(file.type))throw Error('Escolha uma imagem JPG, PNG ou WebP.');
 if(file.size>20*1024*1024)throw Error('Escolha uma imagem de até 20 MB.');
 const url=URL.createObjectURL(file),img=new Image();
 try{
  img.src=url;
  try{await img.decode();}catch{throw Error('Não foi possível abrir esta imagem. Escolha outra.');}
  const scale=Math.min(1,768/Math.max(img.naturalWidth,img.naturalHeight));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
  const ctx=canvas.getContext('2d');ctx.fillStyle='#171717';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
  for(const quality of [.82,.65,.45]){const data=canvas.toDataURL('image/jpeg',quality);if(validCover(data))return data;}
  throw Error('Não foi possível otimizar esta imagem. Escolha outra.');
 }finally{URL.revokeObjectURL(url);}
}
export function coverMarkup(value){return validCover(value)?`<div class="audio-cover"><img src="${value}" alt="" loading="lazy" decoding="async"></div>`:'';}
export function setPlayerCover(value){
 const container=document.querySelector('#playerArtwork');container.hidden=!validCover(value);container.replaceChildren();
 if(!container.hidden){const img=new Image();img.alt='';img.src=value;img.decoding='async';container.append(img);}
}
document.addEventListener('change',async e=>{
 if(e.target.name!=='coverFile')return;
 const input=e.target,form=input.closest('form'),file=input.files[0],preview=form.querySelector('[data-cover-preview]'),status=form.querySelector('[data-cover-status]');
 preview.replaceChildren();status.textContent=file?'Preparando imagem…':'';input.setCustomValidity('');
 try{const cover=await prepareCover(file);if(!input.isConnected||input.files[0]!==file)return;preview.innerHTML=coverMarkup(cover);status.textContent=cover?'Prévia da imagem.':'';}
 catch(error){if(!input.isConnected||input.files[0]!==file)return;status.textContent=error.message;input.setCustomValidity(error.message);}
});
document.addEventListener('click',e=>{
 const button=e.target.closest('[data-clear-cover]');if(!button)return;
 const form=button.closest('form'),input=form.elements.coverFile;input.value='';input.setCustomValidity('');form.querySelector('[data-cover-preview]').replaceChildren();form.querySelector('[data-cover-status]').textContent='Imagem removida da seleção.';
});
