import {validBlockedApp,validAttempt,lockState} from './blocker-domain.js';
import {validCover} from './audio-art.js';
import {usesDownload,downloadOutput} from './backup-download.js';
import * as db from './db.js';
import {protectedOutput,backupLines} from './backup-crypto.js';
import {validDate,statuses,periods,bestStreak} from './domain.js';
const BLOCK=262144,FORMAT='SafeHarbor/2';
const allowed=db.STORES.filter(n=>!['staging','audio','privacy'].includes(n));
const encode=bytes=>{let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);};
const decode=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
async function digest(bytes){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(b=>b.toString(16).padStart(2,'0')).join('');}
function destinationError(message){const error=Error(message);error.name='BackupDestinationError';return error;}
async function output(forceDownload=false){
 if(window.SafeHarborNative){await new Promise((resolve,reject)=>{const f=e=>{window.removeEventListener('backupDestination',f);e.detail?resolve():reject(new Error('Exportação cancelada.'));};window.addEventListener('backupDestination',f);window.SafeHarborNative.beginExport();});return {write:async s=>{const error=window.SafeHarborNative.writeExport(s);if(error)throw Error(error);},close:async()=>{const e=window.SafeHarborNative.finishExport();if(e)throw Error(e);},abort:()=>window.SafeHarborNative.abortExport()};}
 if(forceDownload||usesDownload())return downloadOutput();
 let handle;
 try{handle=await window.showSaveFilePicker({suggestedName:'SafeHarbor_backup.json',types:[{description:'Backup SafeHarbor',accept:{'application/json':['.json']}}]});}
 catch(error){throw destinationError(error.name==='AbortError'?'A escolha do destino foi cancelada ou bloqueada pelo sistema. Nenhum backup foi gravado.':'Não foi possível abrir a janela de destino. '+error.message);}
 let w;try{w=await handle.createWritable();}catch(error){throw destinationError('Não foi possível abrir o arquivo para gravação. Verifique a permissão da pasta. '+error.message);}
 return {write:s=>w.write(s),close:()=>w.close(),abort:()=>w.abort()};
}
export async function exportBackup(progress,{includeAudio=true,password='',beforeWrite=async()=>{},forceDownload=false}={}){
 const raw=await output(forceDownload);let out=raw,count=0,completed=0;
 try{
  await beforeWrite();
  if(password){progress('Protegendo o backup…');out=await protectedOutput(raw,password);}
  const line=async row=>{await out.write(JSON.stringify(row)+',\n');count++;};
  await out.write('{"format":"'+FORMAT+'","includeAudio":'+includeAudio+',"items":[\n');
  for(const store of allowed.filter(n=>includeAudio||n!=='audioMeta'))await db.each(store,async value=>{await line({kind:'row',store,value});progress(`Exportando ${++completed} registros…`);});
  if(includeAudio)await db.each('audio',async a=>{await line({kind:'audio',id:a.id,type:a.blob.type,size:a.blob.size});for(let p=0;p<a.blob.size;p+=BLOCK){const bytes=new Uint8Array(await a.blob.slice(p,p+BLOCK).arrayBuffer());await line({kind:'chunk',id:a.id,offset:p,data:encode(bytes),sha256:await digest(bytes)});progress(`Exportando áudio: ${Math.round((p+bytes.length)/a.blob.size*100)}%`);}});
  await out.write(JSON.stringify({kind:'end',count})+'\n]}');await out.close();return {delivery:raw.delivery??'file'};
 }catch(e){try{await raw.abort();}catch{}if(e.name==='AbortError')throw Error('A gravação do backup foi interrompida. Verifique o espaço e a permissão do destino.');throw e;}
}
function validateRow(store,v){if(store==='blockedApps'&&!validBlockedApp(v))throw Error('Compromisso inválido no backup.');if(store==='blockAttempts'&&!validAttempt(v))throw Error('Tentativa de desbloqueio inválida no backup.');if(store==='audioMeta'&&v?.cover!==undefined&&!validCover(v.cover))throw Error('Imagem de áudio inválida no backup.');if(!allowed.includes(store)||!v||typeof v.id!=='string'||v.id.length>160)throw Error('Registro inválido no backup.');if(store==='records'||store==='revisions'){if(v.dayNote!==undefined&&(typeof v.dayNote!=='string'||v.dayNote.length>10000))throw Error('Relato inválido.');if(v.period!==undefined&&!Object.hasOwn(periods,v.period))throw Error('Período inválido.');if(!validDate(v.date)||(store==='records'&&v.id!==v.date)||!Object.hasOwn(statuses,v.status))throw Error('Data ou status inválido.');for(const k of ['mood','energy','sleep','anxiety','urge'])if(v[k]!==undefined&&(!Number.isInteger(v[k])||v[k]<1||v[k]>5))throw Error('Avaliação fora da escala.');if(v.triggers!==undefined&&(!Array.isArray(v.triggers)||v.triggers.some(t=>typeof t!=='string')))throw Error('Gatilhos inválidos.');}if(store==='settings'&&v.id==='main'&&(!validDate(v.startDate)||typeof v.startDateLocked!=='boolean'))throw Error('Configuração inválida.');if(store==='favorites'&&(!Number.isFinite(v.at)||v.at<0))throw Error('Favorita inválida.');if(store==='audioMeta'&&v.bookmarks!==undefined&&(!Array.isArray(v.bookmarks)||v.bookmarks.some(b=>!b||typeof b.id!=='string'||b.id.length>160||!Number.isFinite(b.position)||b.position<0||typeof b.label!=='string'||b.label.length>120)))throw Error('Marcador inválido.');if(store==='audioMeta'&&(!Number.isFinite(v.position)||v.position<0||typeof v.title!=='string'))throw Error('Posição de áudio inválida.');}

export async function importBackup(file,progress,{password=''}={}){await db.clearStage();let count=0,header=false,footer=false,closed=false;let current=null;const ids=new Set();try{for await(let line of backupLines(file,password)){line=line.trim();if(!header){let info;try{info=JSON.parse(line+']}');}catch{throw Error('Cabeçalho inválido.');}if(!['SafeHarbor/1',FORMAT].includes(info.format)||!Array.isArray(info.items))throw Error('Formato desconhecido. Selecione um backup exportado pelo SafeHarbor.');header=true;continue;}if(line===']}'){if(!footer||closed)throw Error('Final inválido.');closed=true;continue;}if(footer||closed)throw Error('Conteúdo após o fim do backup.');const comma=line.endsWith(',');if(comma)line=line.slice(0,-1);const row=JSON.parse(line);if(row.kind==='end'){if(comma||row.count!==count||current&&current.received!==current.size)throw Error('Backup incompleto.');footer=true;continue;}if(!comma)throw Error('Separador ausente.');count++;
 if(row.kind==='row'){validateRow(row.store,row.value);const key=row.store+':'+row.value.id;if(ids.has(key))throw Error('Registro duplicado.');ids.add(key);await db.put('staging',{id:key,kind:'row',store:row.store,value:row.value});}
 else if(row.kind==='audio'){if(current&&current.received!==current.size)throw Error('Áudio incompleto.');if(typeof row.id!=='string'||row.id.length>160||!Number.isSafeInteger(row.size)||row.size<0||typeof row.type!=='string'||ids.has('audio:'+row.id))throw Error('Áudio inválido.');ids.add('audio:'+row.id);current={...row,received:0};await db.put('staging',{...row,id:'audio:'+row.id,audioId:row.id});}
 else if(row.kind==='chunk'){if(!current||row.id!==current.id||row.offset!==current.received||typeof row.data!=='string'||row.data.length>BLOCK*2)throw Error('Bloco fora de ordem.');const bytes=decode(row.data);if(!bytes.length||bytes.length>BLOCK||await digest(bytes)!==row.sha256||current.received+bytes.length>current.size)throw Error('Bloco de áudio corrompido.');await db.put('staging',{id:`chunk:${row.id}:${String(row.offset).padStart(16,'0')}`,kind:'chunk',audioId:row.id,blob:new Blob([bytes])});current.received+=bytes.length;}
 else throw Error('Tipo de registro desconhecido.');if(count%10===0)progress(`Verificando ${count} registros e blocos…`);
 }if(!closed||!footer)throw Error('Backup truncado.');
 const pending=[];await db.each('staging',async item=>{if(item.kind==='row')pending.push({store:item.store,value:item.value});if(item.kind==='audio'){const parts=[];await db.each('staging',async c=>{if(c.kind==='chunk'&&c.audioId===item.audioId)parts.push(c.blob);});const blob=new Blob(parts,{type:item.type});if(blob.size!==item.size)throw Error('Tamanho do áudio incorreto.');pending.push({store:'audio',value:{id:item.audioId,blob}});}});
 const old=await db.get('settings','main');const main=pending.find(x=>x.store==='settings'&&x.value.id==='main');if(main&&old){if(old.startDateLocked){main.value.startDate=old.startDate;main.value.startDateLocked=true;}}
 // Derived progress is based on the merged records, never on a stale backup maximum.
 const merged=new Map((await db.all('records')).map(r=>[r.id,r]));
 for(const item of pending)if(item.store==='records')merged.set(item.value.id,item.value);
 const settingsRow=main?.value??old;
 if(settingsRow){
  const corrected={...settingsRow,bestEver:bestStreak([...merged.values()],settingsRow.startDate)};
  if(!corrected.progressMigration)corrected.progressMigration={version:1,previousBestEver:settingsRow.bestEver??0,at:Date.now()};
  if(main)main.value=corrected;else pending.push({store:'settings',value:corrected});
 }
 for(const item of pending){if(item.store==='blockedApps'){const current=await db.get('blockedApps',item.value.id);if(current&&lockState(current).locked)item.value=current;}if(item.store==='blockAttempts'){const current=await db.get('blockAttempts',item.value.id);if(current)item.value=current;}}
 for(const item of pending)if(item.store==='reports'){const oldReport=await db.get('reports',item.value.id);if(oldReport?.readAt)item.value.readAt=oldReport.readAt;}else if(item.store==='quoteHistory'){const oldQuote=await db.get('quoteHistory',item.value.id);item.value.at=Math.max(oldQuote?.at??0,item.value.at??0);}
 await db.transaction([...allowed,'audio'],tx=>{for(const x of pending)tx.objectStore(x.store).put(x.value);});progress('Histórico restaurado.');
 }finally{await db.clearStage();}}
