# SafeHarbor 1.6.5

- Marcos com medalhões coloridos: esmalte em degradê, aros metálicos, pedras, louros, fitas e símbolos próprios. Os bloqueados continuam cinza e discretos. Conquistas atuais, anteriores e troféus têm borda dourada viva de 2 px com brilho suave. O troféu também ganhou detalhes e cores.
- A linha Selecionar todos / Excluir selecionados ganhou alinhamento próprio e espaço até o início da grade, inclusive quando os controles precisam quebrar de linha.
- Ao adicionar um áudio avulso, é possível escolher uma imagem opcional JPG, PNG ou WebP de até 20 MB, ver a prévia e removê-la antes de salvar. A imagem aparece na biblioteca e no reprodutor expandido com degradê e esmaecimento nas bordas. O enquadramento é centralizado.
- Imagens são otimizadas localmente, com lado máximo de 768 px e representação JPEG limitada a 400 mil caracteres. Ficam nos metadados do áudio, sem ler o arquivo de áudio inteiro para renderizar a capa. A exclusão do áudio remove também sua imagem. Backups que incluem áudios incluem suas imagens; backups sem áudios preservam a biblioteca existente ao restaurar. Não houve alteração da versão do banco.

## Verificação

`tests/test_v165.py` passou: estados das conquistas, borda dourada, seleção/prévia/remoção de imagem, arquivo inválido, otimização, persistência, imagem no player, áudio sem imagem, backup simples e protegido, rejeição de capa inválida e exclusão. Layout de 320 a 1280 px e player em paisagem, sem transbordamento horizontal. Distância entre o botão Excluir selecionados e a grade de pelo menos 17 px.

As regressões `tests/test_v16.py` e `tests/test_browser.py` passaram, incluindo reprodução, temporizador, marcadores, importação por pasta, backups e funcionamento offline.

`tests/test_large_audio.py` passou com imagem e arquivo WAV de 1.100.000.044 bytes, duração de 12.471,66 s. No Edge de teste: importação em 0,109 s, início de reprodução em 0,36 s, saltos em 0,062–0,078 s; maior intervalo observado no monitor de interface de 22,3 ms. Testou importação, reprodução e saltos, sem aguardar a duração inteira do áudio. Esses tempos são do ambiente local, não uma garantia para todo aparelho Android.

Capturas: `tests/v165-conquistas-mobile.png`, `tests/v165-biblioteca-mobile.png`, `tests/v165-player-mobile.png` e `tests/v165-adicionar-imagem.png`. A paisagem usada no teste da imagem é uma ilustração sintética de teste, não é adicionada à biblioteca real.

VersionCode 13, versão 1.6.5. Código-fonte e recursos offline atualizados. Nenhum APK compilado ou instalado nesta atualização.
