export const DURATIONS=[1,3,12,24,72];
export const validTime=s=>typeof s==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(s);
export function nightWindow(app,now=Date.now()){
 if(!app.nightEnabled||!validTime(app.nightStart)||!validTime(app.nightEnd)||app.nightStart===app.nightEnd)return null;
 const date=new Date(now),minute=date.getHours()*60+date.getMinutes(),toMinute=s=>Number(s.slice(0,2))*60+Number(s.slice(3));
 const start=toMinute(app.nightStart),end=toMinute(app.nightEnd);let startDay=0,endDay=0;
 if(start<end){if(minute<start||minute>=end)return null;}
 else if(minute>=start)endDay=1;else if(minute<end)startDay=-1;else return null;
 const at=(offset,time)=>{const d=new Date(now);d.setDate(d.getDate()+offset);d.setHours(Math.floor(time/60),time%60,0,0);return d.getTime();};
 return {start:at(startDay,start),end:at(endDay,end)};
}
export function lockState(app,now=Date.now()){
 const night=nightWindow(app,now),nightUntil=night&&(app.nightBypassUntil??0)<night.end?night.end:0;
 const until=Math.max(app.lockUntil??0,nightUntil);return {locked:until>now,until,night:Boolean(nightUntil>now),remaining:Math.max(0,Math.ceil((until-now)/1000))};
}
export function countdown(seconds){seconds=Math.max(0,Math.ceil(seconds));const d=Math.floor(seconds/86400),h=Math.floor(seconds%86400/3600),m=Math.floor(seconds%3600/60),s=seconds%60;return `${d?d+'d ':''}${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}
export function validBlockedApp(v){return v&&typeof v.id==='string'&&v.id.length<=160&&typeof v.name==='string'&&v.name.trim().length>0&&v.name.length<=60&&typeof v.nightEnabled==='boolean'&&validTime(v.nightStart)&&validTime(v.nightEnd)&&v.nightStart!==v.nightEnd&&Number.isFinite(v.lockUntil)&&v.lockUntil>=0&&Number.isFinite(v.nightBypassUntil)&&v.nightBypassUntil>=0;}
export function validAttempt(v){return v&&typeof v.id==='string'&&typeof v.appId==='string'&&Number.isFinite(v.readyAt)&&Number.isFinite(v.startedAt)&&v.readyAt>=v.startedAt+120000&&['pending','cancelled','unlocked','expired'].includes(v.status)&&(v.reason===undefined||typeof v.reason==='string'&&v.reason.length<=4000);}
