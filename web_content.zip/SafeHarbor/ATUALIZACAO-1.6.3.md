# SafeHarbor 1.6.3

- O escudo permanece no cabeçalho de todas as seções. Apenas o nome SafeHarbor é substituído pelo título da seção; o nome continua no Início. O escudo permite retornar ao Início.
- Cada um dos 15 marcos tem uma arte vetorial minimalista, incluída no pacote offline. Marcos bloqueados mostram a arte em cinza, com 25% de opacidade. Marcos atuais e conquistados anteriormente mostram a arte integralmente, mantendo as cores dos cartões existentes.
- O botão Escolher Arquivo do backup usa o mesmo estilo dos seletores de áudio: cores, fonte, bordas e espaçamento.

Os indicadores bom/ok/crítico antes das barras ainda aguardam confirmação dos critérios pelo usuário e não foram implementados nesta versão. As barras horizontais e seus valores permanecem.

Verificação real no Edge: cabeçalhos, navegação pelo escudo, artes em três estados, seleção de arquivo e comparação do estilo dos botões; responsividade de 320 a 1280 px e cabeçalhos em paisagem. Relatórios e relatos também foram verificados. Evidências em `tests/v163-results.json` e `tests/v163-art-results.json`; testes em `tests/test_v161.py` e `tests/test_v163.py`.

VersionCode 11, versão 1.6.3. Pacote de código-fonte; nenhum APK compilado ou instalado nesta atualização.
