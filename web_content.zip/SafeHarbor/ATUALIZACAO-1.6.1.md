# SafeHarbor 1.6.1

- Ao abrir um dia finalizado em Progresso, Humor, Energia, Nível de ansiedade, Intensidade do impulso e Qualidade do sono têm barras verticais proporcionais, na mesma escala de 1 a 5. Os números continuam visíveis, e o relatório permanece somente para leitura. O texto explica que barras mais altas em ansiedade e impulso significam maior intensidade.
- Em telas de até 480 px, as avaliações ficam em três colunas para manter os nomes legíveis; em telas maiores, ficam lado a lado. O relatório abre no início do conteúdo, com o foco no título, em vez de rolar até o botão Fechar.
- Relatos aparecem do mais recente ao mais antigo, tanto no relatório diário quanto no histórico do check-in. A alteração afeta apenas a apresentação; não regrava nem remove relatos.
- A marca SafeHarbor aparece apenas no Início. Nas demais seções, o título grande ocupa o cabeçalho e o restante do conteúdo sobe. O botão de Ajustes continua acessível, e não há título duplicado dentro do conteúdo.

## Validação

`tests/test_v161.py` verificou barras com valores de 1 a 5, ordem dos relatos, preservação dos registros, abertura do relatório no topo, marca exclusiva do Início e títulos sem sobreposição em 320, 393, 768 e 1280 px, além de celular em paisagem. Resultados em `tests/v161-results.json`. A regressão de navegador em `tests/test_browser.py` também passou, sem erros JavaScript nem solicitações externas.

Capturas: `tests/v161-relatorio-mobile.png`, `tests/v161-checkin-mobile.png` e `tests/v161-progresso-mobile.png`. Os dados das capturas são fictícios.

O banco permanece na versão 3. O pacote usa versionCode 9 / versão 1.6.1 e preserva as funções da versão 1.6.0. A proposta anterior de reorganizar os cartões da Home continua apenas como prévia, sem aplicação. Nenhum APK foi compilado ou instalado nesta atualização.
