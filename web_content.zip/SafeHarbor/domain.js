export const DAY=86400000;
export const months=['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
export const weekdays=['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
export const triggers=['tédio','solidão','estresse','madrugada','redes sociais','ficar sozinho','discussão','ansiedade','telas','angústia'];
export const statuses={managed:'Dia bem gerido',resisted:'Resistiu a impulso',lapse:'Deslize (Lapso)',relapse:'Recaída (Colapso)'};
export const periods={manha:'Manhã',tarde:'Tarde',noite:'Noite',madrugada:'Madrugada'};
export const periodRanges={manha:'6h às 11h59',tarde:'12h às 17h59',noite:'18h às 23h59',madrugada:'0h às 5h59'};
export function periodFromHour(hour){const h=Number(hour);return h>=0&&h<6?'madrugada':h>=6&&h<12?'manha':h>=18&&h<24?'noite':'tarde';}
export function periodOf(r){return Object.hasOwn(periods,r.period)?r.period:periodFromHour(r.hour??12);}
export const milestones=[1,3,7,14,20,30,40,50,60,70,80,90,100,180,365];
export const ranks=[[0,'Soldado','🛡️'],[3,'Guerreiro','⚔️'],[7,'General','🎖️'],[14,'Barão','🏰'],[30,'Conde','⚜️'],[60,'Duque','💠'],[90,'Rei','👑'],[180,'Imperador','🦅']];
export function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export function dayNumber(s){const [y,m,d]=s.split('-').map(Number);return Date.UTC(y,m-1,d)/DAY;}
export function dateAt(n){return new Date(n*DAY).toISOString().slice(0,10);}
export function addDays(s,n){return dateAt(dayNumber(s)+n);}
export function validDate(s){return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(dayNumber(s))&&dateAt(dayNumber(s))===s;}
export function pretty(s){return new Date(s+'T12:00:00').toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'});}
export function monthName(m){return `${months[Number(m.slice(5))-1]} de ${m.slice(0,4)}`;}
export function normalize(r){return {...r,status:r.status??'managed',mood:r.mood??3,energy:r.energy??3,anxiety:r.anxiety??3,urge:r.urge??3,sleep:r.sleep??3,triggers:Array.isArray(r.triggers)?r.triggers:[],hour:r.hour??12,period:periodOf(r),dayNote:r.dayNote??'',review:r.review??{}};}
// The calendar counter and confirmed achievements are distinct. Only a saved
// closing can confirm a milestone; recalculation uses the latest row per day.
export function sequenceStats(records,start,end=today()) {
 if(!validDate(start)||!validDate(end)||start>end)return {elapsed:0,confirmed:0,best:0};
 let anchor=start,confirmed=0,best=0;
 const rows=records.filter(r=>validDate(r.date)&&r.date>=start&&r.date<=end&&Object.hasOwn(statuses,r.status)).sort((a,b)=>a.date.localeCompare(b.date));
 for(const r of rows){
  if(r.status==='relapse'){anchor=r.date;confirmed=0;}
  else {confirmed=dayNumber(r.date)-dayNumber(anchor);best=Math.max(best,confirmed);}
 }
 return {elapsed:Math.max(0,dayNumber(end)-dayNumber(anchor)),confirmed,best};
}
export const streak=(records,start,end=today())=>sequenceStats(records,start,end).elapsed;
export const confirmedStreak=(records,start,end=today())=>sequenceStats(records,start,end).confirmed;
export const bestStreak=(records,start,end=today())=>sequenceStats(records,start,end).best;
export function challengeStatus(challenge,records,end=today()) {
 if(!['accepted','won','expired'].includes(challenge.status)||!validDate(challenge.target))return challenge.status;
 if(challenge.target>end)return 'accepted';
 const closing=records.find(r=>r.date===challenge.target);
 if(closing&&['managed','resisted'].includes(closing.status))return 'won';
 return challenge.target<end?'expired':'accepted';
}
export function shouldOfferChallenge(records,start,date=today()) {
 const r=records.find(r=>r.date===date);
 // Offering support uses the calendar counter; it does not award a milestone.
 if(r?.status==='relapse'&&streak(records.filter(r=>r.date!==date),start,date)>3)return true;
 return Array.from({length:4},(_,i)=>records.find(r=>r.date===addDays(date,-i))).every(r=>r&&difficult(r));
}
export function difficult(r){return ['lapse','relapse'].includes(r.status)||r.urge>=4;}
export function summary(records){const rows=records.map(normalize),mean=k=>rows.length?rows.reduce((n,r)=>n+r[k],0)/rows.length:0;const counts={};rows.forEach(r=>r.triggers.forEach(t=>counts[t]=(counts[t]??0)+1));return {n:rows.length,mean,top:Object.entries(counts).sort((a,b)=>b[1]-a[1]),relapses:rows.filter(r=>r.status==='relapse').length,lapses:rows.filter(r=>r.status==='lapse').length};}
export function windowStats(records,n,end=today()){const rows=records.filter(r=>r.date>=addDays(end,1-n)&&r.date<=end);const hard=rows.filter(difficult).length;return {hard,good:rows.length-hard,missing:n-rows.length,rate:rows.length?Math.round((rows.length-hard)/rows.length*100):null};}
export function impulseTotal(records,events){return records.filter(r=>r.status==='resisted').length+events.filter(e=>e.kind==='impulse').length;}
export function highRisk(r){return r.urge>=4&&(r.anxiety>=4||r.triggers.includes('estresse'))&&r.sleep<=2;}
export function reportText(month,records,trophies=[]){const s=summary(records);const f=x=>x?x.toFixed(1).replace('.',','):'sem registros';return `Seu mês de ${monthName(month)}\n\nVocê registrou ${s.n} dias: ${records.filter(r=>r.status==='managed').length} bem geridos, ${records.filter(r=>r.status==='resisted').length} com impulso superado, ${s.lapses} com deslize e ${s.relapses} com recaída. Dias sem registro não são contados como vitórias.\n\nMédias de 1 a 5: humor ${f(s.mean('mood'))}; energia ${f(s.mean('energy'))}; sono ${f(s.mean('sleep'))}; ansiedade ${f(s.mean('anxiety'))}. Gatilhos mais registrados: ${s.top.slice(0,3).map(([t,n])=>`${t} (${n})`).join(', ')||'nenhum informado'}.\n\nPróximos passos: ${s.relapses?`buscar reduzir as recaídas de ${s.relapses} para no máximo ${Math.max(0,s.relapses-1)}, sem transformar essa meta em cobrança`:'preservar uma rotina pequena de cuidado e registrar os dias difíceis também'}. ${s.mean('sleep')&&s.mean('sleep')<3?'Experimente reservar dez minutos sem telas antes de dormir em duas noites da semana.':'Escolha um horário possível para um check-in diário.'} ${s.mean('anxiety')>=3?'Em dois dias da semana, anote um pensamento ansioso e uma resposta alternativa.':''} ${s.top.length?`Prepare uma mudança simples no ambiente para lidar com ${s.top[0][0]}.`:''}\n\nVocê conquistou ${trophies.length} troféu(s) Eu consigo neste mês. Cada registro ajuda a enxergar o que precisa mudar, inclusive quando houve dificuldade. O próximo mês oferece novas oportunidades; seu histórico não define seu valor.`;}
