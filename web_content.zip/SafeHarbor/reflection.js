import {today} from './domain.js';
let active=false,day=null,timer=null;
export const readingSeconds=()=>60;
export function needsIntroduction(){const now=today();if(day!==now){day=now;active=localStorage.getItem('safeharbor.reflectionVisit')!==now;if(active)localStorage.setItem('safeharbor.reflectionVisit',now);}return active;}
export function finishIntroduction(){active=false;if(timer)clearTimeout(timer);timer=null;}
export function attachIntroduction(text,onDone){if(!active||timer)return;timer=setTimeout(()=>{finishIntroduction();onDone();},60000);}
