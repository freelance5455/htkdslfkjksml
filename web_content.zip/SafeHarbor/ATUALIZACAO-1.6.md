# SafeHarbor 1.6.0

## Alterações incluídas

- Legibilidade ajustada principalmente por espaçamento e distribuição. O corpo continua em 15 px; títulos principais e reflexões mantêm a escala anterior. No celular, rótulos da navegação passaram de 10 para 11 px e títulos das estatísticas de 12 para 13 px. Os cartões de estatísticas usam linhas mais largas em telas estreitas.
- Cinco destinos na barra inferior. Ajustes fica na engrenagem do cabeçalho.
- Bordas, cantos, espaçamentos e tons de grafite consistentes, preservando preto e vermelho.
- Biblioteca com os formulários recolhidos em “Adicionar áudio ou livro”.
- Player compacto com título, reproduzir/pausar e progresso. Velocidades, marcadores e temporizador ficam no modo expandido.
- Rascunho por data, incluindo texto e avaliações. Fica salvo neste aparelho enquanto você preenche. Ao salvar o check-in, o rascunho é removido. “Descartar rascunho” não exclui um check-in já salvo. Rascunhos não são registros finalizados e não entram no backup.
- Reflexões favoritas acessíveis pela Home. Favoritar também funciona nas reflexões de recaída e de entrada na pausa. A releitura voluntária não altera a regra de 45 dias do sorteio.
- Marcadores por áudio, com nome opcional e retorno ao instante salvo. Entram no backup quando os áudios são incluídos.
- Temporizador de 1 a 720 minutos ou até o fim do áudio atual. No modo “fim do áudio”, o próximo capítulo não começa automaticamente. O temporizador usa tempo decorrido, inclusive se o áudio estiver pausado; fechar o player cancela o temporizador. Não é retomado após reiniciar o aplicativo.
- Backup com ou sem áudios e proteção opcional por senha. Sem áudios, não exporta os arquivos nem seus metadados/marcadores; restaurá-lo preserva a biblioteca existente.

## Escopo preservado

A organização da Home (sequência → check-in → pausa) continua igual. O item 1 está somente em `previews/item1-comparacao.html` e `previews/item1-comparacao.png`, para decisão do usuário. A reflexão inicial do dia mantém seu comportamento. O plano pessoal para momentos difíceis (item 8) não foi implementado.

## Áudios longos e grandes

O player usa um URL de Blob e a reprodução nativa do navegador/WebView. Não converte o áudio inteiro em ArrayBuffer, base64 ou amostras JavaScript. Durante o arraste da barra, a interface mostra uma prévia do tempo; o reposicionamento é feito ao concluir o gesto. Marcadores armazenam apenas metadados. A posição é gravada separadamente do Blob.

O ensaio automatizado usou um WAV PCM silencioso de 1.100.000.044 bytes, com duração de 3h27min51s. Foram exercitados importação, início da reprodução, buscas em 25%, 75% e 95%, marcador após três horas e retomada após recarregar. Não foi uma escuta contínua de toda a duração. Veja os tempos medidos em `tests/large-audio-results.json`.

Esse ensaio foi realizado no Edge do computador. Não é garantia de desempenho para qualquer codec, aparelho ou WebView. Não houve teste em aparelho Android nesta atualização. Espaço disponível, desempenho do armazenamento e suporte ao formato continuam sendo limites reais.

## Backup protegido

O formato de dados é `SafeHarbor/2`; backups anteriores `SafeHarbor/1` continuam aceitos. Com senha, o arquivo JSON externo usa `SafeHarbor/Encrypted/1` e contém blocos cifrados. A senha não é armazenada. Não existe recuperação de senha pelo aplicativo.

A proteção usa Web Crypto: PBKDF2-HMAC-SHA-256 (600.000 iterações, salt aleatório de 16 bytes), AES-256-GCM e tag de 128 bits. Cada exportação usa novo salt e prefixo aleatório de IV. Os IVs de 96 bits incluem um contador, e os dados autenticados vinculam cada bloco ao cabeçalho, à posição e ao marcador final. O processamento trabalha com blocos de até 256 KiB, incluindo na proteção dos áudios, em vez de montar o backup inteiro na memória. A validação do envelope completo termina antes da transação que altera o histórico.

Backups com senha incorreta, blocos alterados/reordenados ou final truncado foram rejeitados sem restaurar parcialmente o histórico. A senha protege o arquivo exportado; não cifra retroativamente o banco local do aplicativo. O backup com áudio ocupa mais espaço devido à representação base64; a camada protegida também tem overhead.

Referências técnicas: [Web Crypto deriveKey](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/deriveKey) e [AES-GCM](https://developer.mozilla.org/en-US/docs/Web/API/AesGcmParams).

## Migração e validação

IndexedDB versão 3 acrescenta a store `favorites`, sem excluir stores anteriores. Os marcadores são campos de `audioMeta`; rascunhos usam chaves locais por data. O APK usa versionCode 8 e versão 1.6.0; preserve a chave de assinatura para instalar por cima de uma versão anterior.

As seguintes verificações foram executadas com perfis isolados e dados fictícios:

- `tests/domain.test.js`: regras de domínio.
- `tests/test_browser.py`: regressão de registros, reflexões, biblioteca, backup e migrações.
- `tests/test_risk_reflection.py`: reflexão antes da pausa e proteção contra repetição.
- `tests/test_v16.py`: novas funcionalidades, integridade dos backups e layouts em 320, 393, 768 e 1280 px, além de paisagem.
- `tests/test_large_audio.py`: arquivo de mais de 1 GB, buscas e marcadores.

Nenhum APK foi compilado ou instalado. O script Android inclui os módulos e o CSS novos. O ZIP é um pacote de código-fonte para compilação, não um instalador Android.
