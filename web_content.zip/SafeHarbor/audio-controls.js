import * as DB from './db.js';

export function attachAudioControls({audio,getCurrent,applyMeta,formatTime,esc,toast}){
 const $=s=>document.querySelector(s);
 let deadline=0,endOfChapter=false,timerExpired=false;
 async function mutate(id,change){
  let result;
  await DB.transaction(['audioMeta'],tx=>{const store=tx.objectStore('audioMeta'),request=store.get(id);request.onsuccess=()=>{if(request.result){result=change(request.result);store.put(result);}};});
  if(result)applyMeta(result);
  refreshBookmarks();
 }
 function refreshBookmarks(){
  const current=getCurrent(),rows=current?.bookmarks??[];
  $('#bookmarkList').innerHTML=rows.length?rows.slice().sort((a,b)=>a.position-b.position).map(b=>`<div class="bookmark-row"><button type="button" class="secondary" data-bookmark-jump="${esc(b.id)}"><span>${formatTime(b.position)}</span> ${esc(b.label)}</button><button type="button" class="ghost small" data-bookmark-remove="${esc(b.id)}" aria-label="Excluir marcador ${esc(b.label)}">Excluir</button></div>`).join(''):'<p class="muted">Marque um trecho para voltar a ele depois.</p>';
  $('#bookmarkForm button').disabled=!current;
 }
 $('#bookmarkForm').addEventListener('submit',async e=>{
  e.preventDefault();e.stopPropagation();
  const current=getCurrent(),field=$('#bookmarkLabel'),button=e.currentTarget.querySelector('button');
  if(!current||button.disabled)return;
  const position=audio.currentTime;if(!Number.isFinite(position))return;
  button.disabled=true;
  try{await mutate(current.id,meta=>({...meta,bookmarks:[...(meta.bookmarks??[]),{id:crypto.randomUUID(),position,label:field.value.trim()||'Trecho em '+formatTime(position),createdAt:Date.now()}]}));field.value='';toast('Marcador salvo.');}
  catch(e){toast(e.message);}finally{button.disabled=false;}
 });
 $('#bookmarkList').addEventListener('click',async e=>{
  const b=e.target.closest('button'),current=getCurrent();if(!b||!current)return;
  try{
   if(b.dataset.bookmarkJump){const item=current.bookmarks?.find(x=>x.id===b.dataset.bookmarkJump);if(item&&Number.isFinite(audio.duration))audio.currentTime=Math.min(item.position,audio.duration);}
   else if(b.dataset.bookmarkRemove){b.disabled=true;await mutate(current.id,meta=>({...meta,bookmarks:(meta.bookmarks??[]).filter(x=>x.id!==b.dataset.bookmarkRemove)}));}
  }catch(err){toast(err.message);b.disabled=false;}
 });
 function refreshTimer(){
  $('#sleepStatus').textContent=deadline?'Pausa em '+formatTime(Math.max(0,(deadline-Date.now())/1000)):endOfChapter?'Pausa ao terminar este áudio.':'Temporizador desligado.';
  $('#timerBadge').hidden=!deadline&&!endOfChapter;
  $('#timerBadge').textContent=deadline?'Pausa em '+formatTime(Math.max(0,(deadline-Date.now())/1000)):'Pausa no fim';
  $('#sleepCancel').hidden=!deadline&&!endOfChapter;
  $('#sleepEnd').setAttribute('aria-pressed',String(endOfChapter));
 }
 function cancelTimer(){deadline=0;endOfChapter=false;timerExpired=false;refreshTimer();}
 function checkTimer(){
  if(deadline&&Date.now()>=deadline){deadline=0;endOfChapter=false;timerExpired=true;audio.pause();refreshTimer();toast('Temporizador concluído. Áudio pausado.');return true;}
  return false;
 }
 $('#sleepForm').addEventListener('submit',e=>{
  e.preventDefault();e.stopPropagation();const minutes=Number($('#sleepMinutes').value);
  if(!Number.isFinite(minutes)||minutes<1||minutes>720)return;
  deadline=Date.now()+minutes*60000;endOfChapter=false;timerExpired=false;refreshTimer();
 });
 $('#sleepEnd').onclick=()=>{deadline=0;endOfChapter=true;timerExpired=false;refreshTimer();};
 $('#sleepCancel').onclick=cancelTimer;
 setInterval(()=>{checkTimer();if(deadline)refreshTimer();},1000);
 document.addEventListener('visibilitychange',checkTimer);
 refreshBookmarks();refreshTimer();
 return {
  refresh:refreshBookmarks,cancelTimer,checkTimer,
  stopAtEnd(){checkTimer();const stop=endOfChapter||timerExpired;if(stop)cancelTimer();return stop;}
 };
}
