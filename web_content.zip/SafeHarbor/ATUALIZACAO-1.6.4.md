# SafeHarbor 1.6.4

O relatório de dias finalizados mostra um ícone antes de cada barra horizontal: círculo verde com confirmação para Bom, círculo amarelo com traço para OK e triângulo vermelho com exclamação para Crítico. Uma legenda identifica as três categorias; os ícones também têm nomes acessíveis.

Critérios confirmados pelo usuário:

| Avaliações | Bom | OK | Crítico |
|---|---|---|---|
| Humor, energia e sono | 4–5 | 3 | 1–2 |
| Ansiedade e impulso | 1–2 | 3 | 4–5 |

As barras continuam representando o valor registrado, de 1 a 5. A classificação é calculada na exibição, sem modificar os registros. Tamanhos dos textos preservados.

Validação no Edge com `tests/test_v161.py`: 25 combinações de avaliação e valor, proporções das barras, posição dos ícones e ausência de sobreposição em 320, 393, 768 e 1280 px. A regressão de relatos e cabeçalhos também passou. Resultado em `tests/v164-results.json`; captura em `tests/v164-relatorio-mobile.png`. Sintaxe de `app.js` verificada com Node.

VersionCode 12, versão 1.6.4. Pacote de código-fonte, sem APK compilado nesta atualização.
