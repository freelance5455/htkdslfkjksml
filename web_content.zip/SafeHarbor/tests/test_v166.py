from pathlib import Path
from urllib.parse import urlparse
import json, sys, base64, tempfile, wave
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'; URL='http://127.0.0.1:18776'
results=[]; errors=[]
def passed(message):
 results.append(message); print('OK:',message,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:
   route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else: route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page(); page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  page.goto(URL);page.locator('[data-action=finishReflection]').click()
  page.evaluate("""async()=>{const db=await import('./db.js'),D=await import('./domain.js'),date=D.today();await db.put('records',{id:date,date,status:'managed',mood:4,energy:4,sleep:4,anxiety:2,urge:2,period:'tarde',triggers:[],dayNote:'Registro de teste da exportação',updatedAt:123});await db.put('audioMeta',{id:'export-audio',title:'Áudio de teste',position:12,speed:1,bookmarks:[{id:'b1',position:8,label:'Trecho'}]});await db.put('audio',{id:'export-audio',blob:new Blob([new Uint8Array(800000)],{type:'audio/wav'})});}""")
  page.reload();page.locator('#settingsButton').click()
  # Actual anchor downloads; only the wrapper identity is simulated.
  page.evaluate("window.Website2APK={};window.pickerCalls=0;window.showSaveFilePicker=async()=>{pickerCalls++;throw new DOMException('No picker available in WebView','AbortError')};void 0")
  downloads=[]
  for protected in [False,True]:
   page.locator('[name=encryptBackup]').set_checked(protected)
   if protected:
    page.locator('[name=exportPassword]').fill('senha de teste 123')
    page.locator('[name=confirmPassword]').fill('senha de teste 123')
   with page.expect_download() as event:
    page.locator('[data-action=export]').click()
   download=event.value
   assert download.suggested_filename.startswith('SafeHarbor_backup_') and download.suggested_filename.endswith('.json')
   data=Path(download.path()).read_text(encoding='utf-8');downloads.append(data)
   expect(page.locator('#backupProgress')).to_contain_text('Download do backup solicitado.')
   expect(page.locator('#backupDownload a')).to_be_visible()
   assert page.evaluate('pickerCalls')==0
   assert json.loads(data)['format']==('SafeHarbor/Encrypted/1' if protected else 'SafeHarbor/2')
   if protected:assert 'Registro de teste da exportação' not in data
   result=page.evaluate("""async({data,password})=>{const b=await import('./backup.js'),db=await import('./db.js');await db.transaction(['records','audio','audioMeta'],tx=>{for(const store of ['records','audio','audioMeta'])tx.objectStore(store).clear()});await b.importBackup(new File([data],'download.json'),()=>{},{password});return {note:(await db.all('records'))[0].dayNote,bytes:(await db.get('audio','export-audio')).blob.size,bookmark:(await db.get('audioMeta','export-audio')).bookmarks[0].position}}""",{'data':data,'password':'senha de teste 123' if protected else ''})
   assert result=={'note':'Registro de teste da exportação','bytes':800000,'bookmark':8},result
  # The wrapper may fetch blob URLs asynchronously; ensure CSP allows it.
  fetched=page.evaluate("async()=>JSON.parse(await (await fetch(document.querySelector('#backupDownload a').href)).text()).format")
  assert fetched=='SafeHarbor/Encrypted/1'
  with page.expect_download() as event:page.locator('#backupDownload a').click()
  assert Path(event.value.path()).read_text(encoding='utf-8')==downloads[1]
  page.screenshot(path=str(OUT/'v166-backup-download.png'))
  passed('Website2APK simulado: dois downloads reais, com e sem senha, sem chamar o seletor incompatível. Arquivos baixados restauram registro, áudio e marcador; link permite repetir e ler o Blob sob a CSP.')
  # No bridge exposed: the Android WebView user agent must also bypass picker.
  page.evaluate("delete window.Website2APK;Object.defineProperty(navigator,'userAgent',{configurable:true,value:'Mozilla/5.0 (Linux; Android 13; Device Build/ABC; wv) Chrome/120 Mobile Safari/537.36'})")
  page.locator('[name=encryptBackup]').uncheck()
  with page.expect_download():page.locator('[data-action=export]').click()
  assert page.evaluate('pickerCalls')==0
  # Browsers without a save picker use the same download path.
  page.evaluate("delete navigator.userAgent;window.showSaveFilePicker=undefined")
  with page.expect_download():page.locator('[data-action=export]').click()
  passed('WebView sem API Website2APK e navegador sem seletor usam download compatível.')
  # Desktop picker must be opened inside the click, before async preparation.
  page.evaluate("""()=>{window.handlerReturned=false;document.addEventListener('click',()=>window.handlerReturned=false,true);document.addEventListener('click',()=>window.handlerReturned=true); window.showSaveFilePicker=async()=>{window.openedInClick=!window.handlerReturned;window.savedBackup='';return {createWritable:async()=>({write:async s=>window.savedBackup+=s,close:async()=>{},abort:async()=>{}})}}} """)
  page.locator('[data-action=export]').click()
  expect(page.locator('#backupProgress')).to_have_text('Backup salvo no local escolhido.')
  assert page.evaluate('openedInClick') is True
  assert json.loads(page.evaluate('savedBackup'))['format']=='SafeHarbor/2'
  page.evaluate("window.showSaveFilePicker=async()=>{throw new DOMException('dismissed','AbortError')};void 0")
  page.locator('[data-action=export]').click()
  expect(page.locator('#backupProgress')).to_contain_text('A escolha do destino foi cancelada ou bloqueada')
  expect(page.locator('#backupAlternative')).to_be_visible()
  with page.expect_download():page.locator('[data-action=exportDownload]').click()
  expect(page.locator('#backupProgress')).to_contain_text('Download do backup solicitado.')
  page.evaluate("window.showSaveFilePicker=async()=>({createWritable:async()=>{throw new DOMException('no permission','NotAllowedError')}});void 0")
  page.locator('[data-action=export]').click()
  expect(page.locator('#backupProgress')).to_contain_text('Não foi possível abrir o arquivo para gravação')
  # A failed export must not download a truncated JSON or claim success.
  failed=page.evaluate("""async()=>{window.Website2APK={};try{await (await import('./backup.js')).exportBackup(()=>{},{beforeWrite:async()=>{throw Error('Falha de preparação')}})}catch(e){return e.message}}""")
  assert failed=='Falha de preparação'
  passed('Seletor desktop chamado diretamente no clique; cancelamento e permissão têm mensagens distintas; falha antes da escrita não produz arquivo parcial.')
  assert not errors,errors
 except Exception:
  page.screenshot(path=str(OUT/'v166-falha.png'),full_page=True)
  raise
 finally:
  browser.close()
  (OUT/'v166-results.json').write_text(json.dumps({'passed':results,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
