from pathlib import Path
from urllib.parse import urlparse
import json, sys
from playwright.sync_api import sync_playwright, expect
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests';URL='http://127.0.0.1:18770'
results=[];errors=[]
def passed(message):results.append(message);print('OK:',message,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else:route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  page.goto(URL);page.locator('[data-action=finishReflection]').click()
  date=page.evaluate("""async()=>{const d=await import('./db.js'),D=await import('./domain.js'),date=D.today(),s=await d.get('settings','main');s.startDate=D.addDays(date,-5);await d.put('settings',s);const base={id:date,date,status:'managed',period:'tarde',mood:1,energy:2,anxiety:3,urge:4,sleep:5,triggers:[],dayNote:'Relato mais recente',updatedAt:3000};await d.put('records',base);for(const [id,at,note] of [['old',1000,'Relato mais antigo'],['middle',2000,'Relato intermediário'],['new',3000,'Relato mais recente']])await d.put('revisions',{...base,id,recordId:date,updatedAt:at,dayNote:note});return date;}""")
  page.reload();page.get_by_role('button',name='Progresso',exact=True).click()
  page.locator(f'[data-action=day][data-date="{date}"]').click()
  expect(page.get_by_text('Dia finalizado · somente leitura')).to_be_visible()
  assert page.locator('#modal').evaluate('(m)=>m.scrollTop')==0
  assert page.locator('.daily-metric').count()==5
  values=page.locator('.daily-metric strong').all_text_contents()
  assert values==['1 / 5','2 / 5','3 / 5','4 / 5','5 / 5'],values
  widths=page.locator('.metric-fill').evaluate_all('(nodes)=>nodes.map(n=>Number(n.getAttribute("width")))')
  assert widths==[20,40,60,80,100],widths
  assert page.locator('.metric-bar').evaluate_all('(nodes)=>nodes.every(n=>n.getBoundingClientRect().width>n.getBoundingClientRect().height)')
  assert page.locator('#modal input,#modal textarea,#modal select').count()==0
  assert page.locator('#modal .daily-note').all_text_contents()==['Relato mais recente','Relato intermediário','Relato mais antigo']
  page.screenshot(path=str(OUT/'v164-relatorio-mobile.png'))
  passed('Dia finalizado mostra cinco barras horizontais proporcionais, valores 1–5 e relatos do mais recente ao mais antigo, somente leitura.')
  for width in [320,393,768,1280]:
   page.set_viewport_size({'width':width,'height':852})
   assert page.locator('#modal').evaluate('(m)=>m.scrollWidth<=m.clientWidth'),width
   assert page.locator('.daily-metrics').evaluate('(m)=>m.scrollWidth<=m.clientWidth'),width
   assert page.locator('.daily-metric').evaluate_all("nodes=>nodes.every(n=>{const label=n.querySelector('dt').getBoundingClientRect(),icon=n.querySelector('.metric-status').getBoundingClientRect(),bar=n.querySelector('.metric-bar').getBoundingClientRect(),value=n.querySelector('strong').getBoundingClientRect();return label.right<=icon.left&&icon.right<=bar.left&&bar.right<=value.left&&bar.width>bar.height;})"),width
  original=page.evaluate("async()=> (await import('./db.js')).all('records')")[0]
  for value in range(1,6):
   page.evaluate("""async({date,value})=>{const db=await import('./db.js'),r=await db.get('records',date);for(const key of ['mood','energy','anxiety','urge','sleep'])r[key]=value;await db.put('records',r)}""",{'date':date,'value':value})
   page.reload()
   page.locator(f'[data-action=day][data-date="{date}"]').click()
   positive={1:'Crítico',2:'Crítico',3:'OK',4:'Bom',5:'Bom'}[value]
   inverse={1:'Bom',2:'Bom',3:'OK',4:'Crítico',5:'Crítico'}[value]
   states=page.locator('.daily-metric .metric-status').evaluate_all('(nodes)=>nodes.map(n=>n.getAttribute("aria-label"))')
   assert states==[positive,positive,inverse,inverse,positive],(value,states)
   assert page.locator('.metric-fill').evaluate_all('(nodes)=>nodes.map(n=>Number(n.getAttribute("width")))')==[value*20]*5
  page.evaluate("async r=>(await import('./db.js')).put('records',r)",original)
  passed('25 combinações verificadas: 1–2 crítico / 3 OK / 4–5 bom para humor, energia e sono; ordem inversa para ansiedade e impulso. Ícones antes das barras, sem sobreposição.')
  page.locator('#modal [data-action=closeModal]').click()
  page.get_by_role('button',name='Check-in',exact=True).click()
  page.locator('.revision-history summary').click()
  assert page.locator('.revision-history .daily-note').all_text_contents()==['Relato mais recente','Relato intermediário','Relato mais antigo']
  records=page.evaluate("async()=> (await import('./db.js')).all('records')")
  assert records[0]['dayNote']=='Relato mais recente' and records[0]['updatedAt']==3000
  assert len(page.evaluate("async()=> (await import('./db.js')).all('revisions')"))==3
  passed('Mesma ordem recente primeiro no check-in; registros e revisões permanecem intactos.')
  titles={'registro':'Como foi o seu dia?','progresso':'Seu progresso','conquistas':'Marcos e troféus','audios':'Um tempo para ouvir','ajustes':'Configurações'}
  for width,height in [(320,740),(393,852),(768,1024),(1280,800),(852,393)]:
   page.set_viewport_size({'width':width,'height':height})
   for route,title in titles.items():
    page.goto(URL+'/#'+route)
    expect(page.locator('#sectionHeading h1')).to_have_text(title)
    expect(page.locator('header > a svg')).to_be_visible()
    expect(page.locator('header > a strong')).not_to_be_visible()
    assert page.locator('h1').count()==1 and page.locator('#app h1').count()==0
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,route)
    dimensions=page.evaluate("""()=>{const t=document.querySelector('#sectionHeading h1').getBoundingClientRect(),b=document.querySelector('#settingsButton').getBoundingClientRect(),header=document.querySelector('header').getBoundingClientRect();return {titleRight:t.right,buttonLeft:b.left,top:t.top,headerBottom:header.bottom};}""")
    assert dimensions['titleRight']<=dimensions['buttonLeft'] and dimensions['top']<=25,(route,width,dimensions)
    assert page.locator('header > a').bounding_box()['x']+page.locator('header > a').bounding_box()['width']<=page.locator('#sectionHeading').bounding_box()['x']
    assert dimensions['headerBottom']<=160,(route,width,dimensions)
   page.get_by_role('button',name='Início',exact=True).click()
   expect(page.locator('header > a svg')).to_be_visible()
   expect(page.locator('header > a strong')).to_be_visible()
   expect(page.locator('#sectionHeading')).not_to_be_visible()
   expect(page.locator('#app h1')).to_have_text('Um dia de cada vez.')
  page.set_viewport_size({'width':393,'height':852})
  page.get_by_role('button',name='Check-in',exact=True).click()
  page.screenshot(path=str(OUT/'v164-checkin-mobile.png'))
  page.get_by_role('button',name='Progresso',exact=True).click()
  page.screenshot(path=str(OUT/'v164-progresso-mobile.png'))
  passed('Escudo em todas as seções e nome apenas no Início; um título no cabeçalho das outras cinco seções, sem sobreposição, em celular, tablet, desktop e paisagem.')
  assert not errors,errors
 except Exception:
  page.screenshot(path=str(OUT/'v164-falha.png'),full_page=True)
  raise
 finally:
  browser.close()
  (OUT/'v164-results.json').write_text(json.dumps({'passed':results,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
