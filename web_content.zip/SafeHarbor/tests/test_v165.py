from pathlib import Path
from urllib.parse import urlparse
import json, sys, base64, tempfile, wave
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'; URL='http://127.0.0.1:18775'
results=[]; errors=[]
def passed(message):
 results.append(message); print('OK:',message,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:
   route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else: route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page(); page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  page.goto(URL);page.locator('[data-action=finishReflection]').click()
  page.evaluate("""async()=>{const db=await import('./db.js'),D=await import('./domain.js'),s=await db.get('settings','main');s.startDate=D.addDays(D.today(),-36);await db.put('settings',s);for(const [offset,status] of [[-6,'managed'],[-5,'relapse'],[0,'managed']]){const date=D.addDays(D.today(),offset);await db.put('records',{id:date,date,status});}await db.put('trophies',{id:'art-test',date:D.today()});}""")
  page.reload();page.get_by_role('button',name='Conquistas',exact=True).click()
  assert page.locator('.milestone-art').count()==15
  assert page.locator('.milestone.current,.milestone.past').count()==6
  assert page.locator('.milestone.current,.milestone.past,.trophy-card').evaluate_all("nodes=>nodes.every(n=>getComputedStyle(n).borderTopColor==='rgb(255, 210, 63)'&&getComputedStyle(n).borderTopWidth==='2px')")
  assert page.locator('.milestone:not(.current):not(.past) .milestone-art').evaluate_all("nodes=>nodes.every(n=>getComputedStyle(n).filter==='grayscale(1)'&&getComputedStyle(n).opacity==='0.25')")
  page.screenshot(path=str(OUT/'v165-conquistas-mobile.png'),full_page=True)
  for width in [320,393,768,1280]:
   page.set_viewport_size({'width':width,'height':852})
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  passed('Artes coloridas, bloqueadas discretas e borda dourada de 2 px nos seis marcos conquistados e no troféu; responsivas.')
  page.set_viewport_size({'width':393,'height':852})
  page.get_by_role('button',name='Áudios',exact=True).click()
  with tempfile.TemporaryDirectory(prefix='safeharbor-cover-') as temp:
   audio=Path(temp)/'Horizonte.wav'
   with wave.open(str(audio),'wb') as w:
    w.setnchannels(1);w.setsampwidth(2);w.setframerate(8000);w.writeframes(b'\0\0'*8000*60)
   png=page.evaluate("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=1000;const x=c.getContext('2d'),g=x.createLinearGradient(0,0,1600,1000);g.addColorStop(0,'#203474');g.addColorStop(.5,'#ba688b');g.addColorStop(1,'#f4c180');x.fillStyle=g;x.fillRect(0,0,1600,1000);x.fillStyle='#ffdca4';x.beginPath();x.arc(1050,350,140,0,7);x.fill();x.fillStyle='#26365a';x.beginPath();x.moveTo(0,1000);x.lineTo(0,750);x.lineTo(450,350);x.lineTo(900,850);x.lineTo(1400,500);x.lineTo(1600,1000);x.fill();return c.toDataURL('image/png').split(',')[1]}""")
   cover={'name':'paisagem.png','mimeType':'image/png','buffer':base64.b64decode(png)}
   page.locator('.library-add > summary').click()
   page.locator('[name=audioFile]').set_input_files(str(audio))
   page.locator('[name=coverFile]').set_input_files(cover)
   expect(page.locator('[data-cover-preview] img')).to_be_visible()
   page.locator('[data-clear-cover]').click()
   assert page.locator('[data-cover-preview] img').count()==0
   page.locator('[name=coverFile]').set_input_files({'name':'invalida.png','mimeType':'image/png','buffer':b'invalid'})
   expect(page.locator('[data-cover-status]')).to_contain_text('Não foi possível abrir')
   assert page.locator('[name=coverFile]').evaluate('(e)=>!e.checkValidity()')
   page.locator('[name=coverFile]').set_input_files(cover)
   expect(page.locator('[data-cover-preview] img')).to_be_visible()
   page.screenshot(path=str(OUT/'v165-adicionar-imagem.png'),full_page=True)
   page.get_by_role('button',name='Salvar na biblioteca').click()
   expect(page.locator('.chapter .audio-cover img')).to_be_visible()
   row=page.evaluate("async()=> (await (await import('./db.js')).all('audioMeta'))[0]")
   assert row['cover'].startswith('data:image/jpeg;base64,') and len(row['cover'])<400000
   size=page.locator('.chapter .audio-cover img').evaluate('img=>({w:img.naturalWidth,h:img.naturalHeight})')
   assert size=={'w':768,'h':480},size
   page.reload();expect(page.locator('.chapter .audio-cover img')).to_be_visible()
   page.screenshot(path=str(OUT/'v165-biblioteca-mobile.png'),full_page=True)
   for width in [320,393,768,1280]:
    page.set_viewport_size({'width':width,'height':852})
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    button=page.locator('[data-action=deleteSelected]').bounding_box()
    chapter=page.locator('.chapter').bounding_box()
    assert chapter['y']-(button['y']+button['height'])>=17,(width,button,chapter)
   page.set_viewport_size({'width':393,'height':852})
   page.get_by_role('button',name='Ouvir',exact=True).click()
   expect(page.locator('#playerArtwork')).not_to_be_visible()
   page.locator('#expandPlayer').click()
   expect(page.locator('#playerArtwork img')).to_be_visible()
   assert page.locator('#playerArtwork img').get_attribute('src')==row['cover']
   for width,height in [(320,740),(393,852),(852,393),(1280,800)]:
    page.set_viewport_size({'width':width,'height':height})
    assert page.locator('#player').evaluate('(e)=>e.scrollWidth<=e.clientWidth')
    page.locator('#togglePlayback').scroll_into_view_if_needed()
    expect(page.locator('#togglePlayback')).to_be_in_viewport()
   page.set_viewport_size({'width':393,'height':852})
   page.locator('#player').evaluate('(e)=>e.scrollTop=0')
   page.screenshot(path=str(OUT/'v165-player-mobile.png'))
   page.locator('#closePlayer').click()
   passed('Imagem opcional com prévia/remover/erro, otimização 1600×1000 → 768×480, persistência após recarregar e player responsivo. Botão de exclusão separado da grade por pelo menos 17 px.')
   page.locator('.library-add > summary').click()
   page.locator('[name=audioFile]').set_input_files(str(audio))
   page.locator('[name=sameName]').uncheck();page.locator('#audioForm [name=title]').fill('Sem imagem')
   page.get_by_role('button',name='Salvar na biblioteca').click()
   expect(page.locator('.chapter')).to_have_count(2)
   page.locator('.chapter').filter(has=page.get_by_role('heading',name='1. Sem imagem',exact=True)).get_by_role('button',name='Ouvir',exact=True).click()
   page.locator('#expandPlayer').click()
   expect(page.locator('#playerArtwork')).not_to_be_visible()
   assert page.locator('#playerArtwork img').count()==0
   page.locator('#closePlayer').click()
   page.evaluate("window.showSaveFilePicker=async()=>({createWritable:async()=>({write:async s=>{window.savedBackup=(window.savedBackup??'')+s},close:async()=>{},abort:async()=>{}})})")
   for password in ['', 'senha de teste 123']:
    result=page.evaluate("""async password=>{const d=await import('./db.js'),b=await import('./backup.js');window.savedBackup='';await b.exportBackup(()=>{},{password});const text=window.savedBackup;await d.transaction(['audio','audioMeta'],tx=>{tx.objectStore('audio').clear();tx.objectStore('audioMeta').clear()});await b.importBackup(new File([text],'backup.json'),()=>{},{password});return {rows:await d.all('audioMeta'),audio:(await d.all('audio')).length,stage:(await d.all('staging')).length}}""",password)
    assert len(result['rows'])==2 and result['audio']==2 and result['stage']==0
    assert next(x for x in result['rows'] if x['id']==row['id'])['cover']==row['cover']
   invalid=page.evaluate("""async()=>{const d=await import('./db.js'),b=await import('./backup.js'),r=(await d.all('audioMeta'))[0],before=JSON.stringify(await d.all('audioMeta'));const text=JSON.stringify({format:'SafeHarbor/2',items:[]}).replace('[]','[\\n'+JSON.stringify({kind:'row',store:'audioMeta',value:{...r,cover:'https://external.test/image.png'}})+',\\n'+JSON.stringify({kind:'end',count:1})+'\\n]');let rejected=false;try{await b.importBackup(new File([text],'bad.json'),()=>{})}catch{rejected=true}return rejected&&before===JSON.stringify(await d.all('audioMeta'))} """)
   assert invalid
   page.reload();expect(page.locator('.chapter .audio-cover img')).to_be_visible()
   page.locator('.chapter').filter(has=page.get_by_role('heading',name='2. Horizonte',exact=True)).get_by_role('button',name='Excluir arquivo').click()
   page.get_by_role('button',name='Excluir áudio',exact=True).click()
   expect(page.locator('.chapter')).to_have_count(1)
   assert page.evaluate("async id=>(await (await import('./db.js')).get('audioMeta',id))??null",row['id']) is None
   passed('Áudio sem imagem não reutiliza capa anterior; backup simples e protegido restauram imagem e áudio; capa inválida rejeitada; exclusão remove a imagem junto ao áudio.')
  assert not errors,errors
 except Exception:
  page.screenshot(path=str(OUT/'v165-falha.png'),full_page=True)
  raise
 finally:
  browser.close()
  (OUT/'v165-results.json').write_text(json.dumps({'passed':results,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
