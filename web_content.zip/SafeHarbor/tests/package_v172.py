"""Validate local release inputs and create both 1.7.2 delivery archives."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, zipfile
import xml.etree.ElementTree as ET

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
NODE=os.environ.get('SAFEHARBOR_NODE') or shutil.which('node') or str(ROOT.parent/'SafeHarbor_tools/python/Lib/site-packages/playwright/driver/node.exe')
VERSION='1.7.2'
assert json.loads((ROOT/'package.json').read_text(encoding='utf-8'))['version']==VERSION
manifest=ET.parse(ROOT/'android/AndroidManifest.xml').getroot()
assert manifest.attrib['{http://schemas.android.com/apk/res/android}versionName']==VERSION
assert manifest.attrib['{http://schemas.android.com/apk/res/android}versionCode']=='17'
assert not manifest.findall('uses-permission')

js=list(ROOT.glob('*.js'))
for path in js:
    subprocess.run([NODE,'--check',str(path)],check=True,capture_output=True)
result=subprocess.run([NODE,'--test','tests/domain.test.js','tests/progress.test.js','tests/blocker-domain.test.js'],cwd=ROOT,check=True,capture_output=True,text=True,encoding='utf-8')
(ROOT/'tests/v172-node-tests.txt').write_text(result.stdout,encoding='utf-8')

suites=[('Regras e correções 1.7.2','v172-results.json',10),
        ('Regressão geral de interface','browser-results.json',20),
        ('Compatibilidade da 1.7.1 e seis seções','v171-results.json',3),
        ('Migração e restauração legadas','v171-data-results.json',2),
        ('Artes de marcos e seletor de backup','v163-art-results.json',3),
        ('Capas, áudio e backup protegido','v165-results.json',3)]
summary=[]
for label,name,count in suites:
    data=json.loads((ROOT/'tests'/name).read_text(encoding='utf-8'))
    assert not data['errors'],name
    assert not data.get('external_requests',[]),name
    assert len(data['passed'])==count,(name,len(data['passed']))
    summary.append(f'| {label} | {count} cenários aprovados | [{name}]({name}) |')

report='''# Validação do SafeHarbor 1.7.2

Executada em 9 de novembro de 2026, no Windows, usando Node 24 e Edge real via Playwright. Todos os testes de interface utilizaram perfis isolados, dados fictícios e assets locais. Nenhum perfil pessoal ou dado do aplicativo instalado no celular foi acessado.

## Resultado

O teste de regressão reproduziu o defeito antes da mudança (`3 !== 2` ao confirmar a melhor sequência antes do check-in). Depois da correção, a execução Node concluiu 24 testes sem falhas, incluindo os 15 marcos, datas civis e resultados de desafios. A saída integral está em [v172-node-tests.txt](v172-node-tests.txt).

Todos os módulos JavaScript passaram por verificação sintática. Manifestos JSON e XML válidos; container Android continua sem permissões de rede.

| Suíte executada nesta atualização | Resultado | Evidência |
| --- | --- | --- |
'''+ '\n'.join(summary)+'''

## Verificações principais

- Terceiro dia sem check-in: contador 3, melhor sequência confirmada 2, patente Soldado e marco 3 bloqueado.
- Recaída no terceiro dia: contador zero, marco 3 bloqueado inclusive após reabrir. Histórico de revisões, registros anteriores, áudio, posição e impulsos preservados.
- Alterações no mesmo dia: bem gerido → recaída → resistido → deslize; marcos, patentes e troféus acompanham o fechamento vigente, sem duplicações.
- Marco legítimo de sequência anterior preservado, mesmo com recaída atual; máximo antigo inflado descartado como fonte de conquistas.
- Edição retroativa atualiza relatório, resultado do desafio e troféu, mantendo data de criação e estado lido do relatório.
- Restauração pela interface, duas vezes, corrige máximo e troféu inconsistentes, preservando dados e data inicial bloqueada.
- Erro de cota simulado durante a transação não salva parcialmente registro, revisão ou conquista; tentativa posterior com clique duplo salva uma única revisão.
- Avanço do relógio até sete dias aumenta o contador, mas aguarda um novo check-in para confirmar marco 7 e patente General.
- Status inválido no backup é rejeitado sem alterar dados; área temporária limpa.
- Correção de registro cancela oferta ainda não aceita; nova condição elegível reapresenta a mesma oferta, sem duplicá-la. Aceite define o dia seguinte.
- Regresões de reflexão, calendário, gráficos, áudio, capítulos, exclusão, backup simples e protegido, migrações v1/v3 para v4 e atualização futura v4 para v5 passaram.
- Conquistas inspecionadas visualmente, com marco 3 bloqueado após recaída. As seis seções foram verificadas em larguras de 320 a 1280 px e paisagem.

Os testes antigos de arte agora usam registros reais para sustentar os marcos esperados, em vez de injetar apenas um máximo sem histórico. O teste geral também deixou de exigir a preservação do marco do próprio dia corrigido para recaída.

## Limites e entrega

Validação de aplicação web offline e armazenamento IndexedDB. Não houve compilação, assinatura, instalação ou teste do APK em Android. Nenhum novo ensaio com áudio de 1 GB foi necessário nesta correção. A atualização instalada deve manter pacote, assinatura e origem local; os ZIPs fornecem os arquivos para gerar essa atualização.

Os pacotes são verificados por integridade ZIP e comparação byte a byte com os arquivos locais. O pacote completo contém `SHA256SUMS.json`; o pacote web também inclui seu próprio manifesto SHA-256. As somas das entregas estão em `entrega/SHA256SUMS-1.7.2.json`.
'''
(ROOT/'tests/VALIDACAO-1.7.2.md').write_text(report,encoding='utf-8')

out=ROOT/'entrega';out.mkdir(exist_ok=True)
assets=sorted(p for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.js','.css','.html','.png'} and p.name!='package.json')
assets.append(ROOT/'manifest.json')
asset_names={p.name for p in assets}
for path in js:
    for dep in re.findall(r"(?:from\s*|import\s*)['\"]\./([^'\"]+)['\"]",path.read_text(encoding='utf-8')):
        assert dep in asset_names,(path.name,dep)
assets.append(ROOT/'ATUALIZACAO-1.7.2.md')
web_files={p.name:p for p in assets}
web_hashes={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in web_files.items()}
web=out/f'SafeHarbor_Website2APK_{VERSION}.zip'
with zipfile.ZipFile(web,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in web_files.items():z.write(path,name)
    z.writestr('SHA256SUMS.json',json.dumps(web_hashes,indent=2))

excluded={'teste-audio.wav','teste-backup.json','teste-corrompido.json','falha.png','SHA256SUMS.json'}
files=[p for p in ROOT.iterdir() if p.is_file() and p.name not in excluded]
for folder in ['android','tests','previews']:
    files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'build' not in p.parts and p.name not in excluded and p.suffix not in {'.keystore','.wav','.zip'})
hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(ROOT/'SHA256SUMS.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf-8')
files.append(ROOT/'SHA256SUMS.json')
full=out/f'SafeHarbor_{VERSION}.zip'
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(files):z.write(path,'SafeHarbor/'+path.relative_to(ROOT).as_posix())

for archive,prefix,entries in [(web,'',web_files),(full,'SafeHarbor/',{p.relative_to(ROOT).as_posix():p for p in files})]:
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert prefix+'index.html' in z.namelist()
        for name,path in entries.items():assert z.read(prefix+name)==path.read_bytes(),name
        for name,digest in json.loads(z.read(prefix+'SHA256SUMS.json')).items():
            assert hashlib.sha256(z.read(prefix+name)).hexdigest()==digest,name

deliveries={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [web,full]}
(out/f'SHA256SUMS-{VERSION}.json').write_text(json.dumps(deliveries,indent=2),encoding='utf-8')
print(json.dumps(dict(version=VERSION,syntax_modules=len(js),browser_scenarios=sum(c for _,_,c in suites),archives=deliveries),ensure_ascii=False,indent=2))
