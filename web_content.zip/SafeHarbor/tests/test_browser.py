from pathlib import Path
import functools, http.server, threading, tempfile, json, traceback, datetime, wave, struct, sys, time, os
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
if not (ROOT/'index.html').exists(): ROOT=ROOT/'SafeHarbor'
OUT=ROOT/'tests'
OUT.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}'
results=[]
errors=[]
external=[]
def passed(s):
    results.append(s)
    print('OK:',s,flush=True)

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('SAFEHARBOR_BROWSER',r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'),headless=True)
    context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
    page=context.new_page()
    def local_asset(route):
        from urllib.parse import urlparse
        name=urlparse(route.request.url).path.lstrip('/') or 'index.html'
        f=ROOT/name
        if f.is_file() and f.parent==ROOT:
            kind='text/javascript' if f.suffix=='.js' else 'text/css' if f.suffix=='.css' else 'image/png' if f.suffix=='.png' else 'application/json' if f.suffix=='.json' else 'text/html'
            route.fulfill(body=f.read_bytes(),content_type=kind)
        else: route.abort()
    context.route(url+'/**',local_asset)
    def wait_js(expr):
        for _ in range(100):
            if page.evaluate('() => '+expr): return
            time.sleep(.05)
        raise AssertionError('Condição não atendida: '+expr)
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:external.append(r.url) if not r.url.startswith((url,'blob:','data:')) else None)
    page.add_init_script('Math.random = () => 0.1;')
    try:
        page.clock.install()
        page.goto(url)
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        assert page.locator('html').get_attribute('lang')=='pt-BR'
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        page.get_by_role('heading',name='Sua reflexão').wait_for()
        home_quote=page.locator('.home-quote blockquote').inner_text()
        assert len(home_quote)>10
        assert page.locator('main > :first-child').evaluate("e=>e.classList.contains('reflection-intro')")
        catalog=page.evaluate("async()=> (await import('./quotes.js')).quotes")
        assert len(catalog)==150 and len({q['text'] for q in catalog})==150
        page.screenshot(path=str(OUT/'reflexao-abertura-mobile.png'),full_page=True)
        assert page.locator('[data-reading-time]').count()==0
        assert page.locator('header .local').count()==0
        page.clock.run_for(50000)
        assert page.locator('.reflection-intro').count()==1
        page.clock.run_for(11000)
        assert page.locator('.reflection-intro').count()==0
        assert page.locator('.home-quote').count()==1
        page.clock.resume()
        page.reload()
        page.get_by_role('heading',name='Sua reflexão').wait_for()
        assert page.locator('.reflection-intro').count()==0
        page.evaluate("localStorage.setItem('safeharbor.reflectionVisit','2000-01-01')")
        page.reload()
        page.get_by_role('button',name='Já li, continuar').click()
        assert page.locator('.reflection-intro').count()==0
        passed('150 reflexões distintas; abertura no topo, deslocamento automático após leitura e botão para continuar')
        passed('Inicialização em pt-BR, armazenamento e layout móvel sem rolagem horizontal')
        today=page.evaluate("(await import('./domain.js')).today()") if False else page.evaluate("async()=> (await import('./domain.js')).today()")
        start=(datetime.date.fromisoformat(today)-datetime.timedelta(days=100)).isoformat()
        page.get_by_role('button',name='Ajustes',exact=True).click()
        page.locator('[name=startDate]').fill(start)
        page.get_by_role('button',name='Definir data permanentemente').click()
        page.get_by_text('Data definida e bloqueada permanentemente neste histórico.').wait_for()
        assert page.locator('[name=startDate]').input_value()==start
        page.reload()
        page.get_by_text('Data definida e bloqueada permanentemente neste histórico.').wait_for()
        assert page.locator('[name=startDate]').is_disabled()
        assert page.locator('[name=startDate]').input_value()==start
        passed('Data inicial salva uma vez e bloqueio preservado após recarregar')

        page.get_by_role('button',name='Check-in',exact=True).click()
        assert page.locator('select[name=status]').count()==0
        assert page.locator('[name=hour]').count()==0
        assert page.locator('[name=period]').count()==4
        page.locator('[name=status][value=resisted]').check()
        page.locator('[name=period][value=manha]').check()
        assert page.locator('[name=dayNote]').input_value()==''
        page.screenshot(path=str(OUT/'checkin-mobile.png'),full_page=True)
        page.get_by_role('button',name='Salvar fechamento do dia').click()
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        assert not page.locator('#modal').is_visible()
        page.get_by_role('button',name='Rever check-in de hoje').click()
        page.locator('[name=dayNote]').fill('Hoje reconheci a ansiedade.\nVou cuidar do descanso.')
        page.locator('[name=period][value=noite]').check()
        page.get_by_role('button',name='Salvar fechamento do dia').click()
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        assert not page.locator('#modal').is_visible()
        total=page.evaluate("async()=>{const d=await import('./db.js'),D=await import('./domain.js');return D.impulseTotal(await d.all('records'),await d.all('events'));}")
        assert total==1,total
        history=page.evaluate("async()=> (await import('./db.js')).all('quoteHistory')")
        assert len(history)==1
        versions=page.evaluate("async()=> (await import('./db.js')).all('revisions')")
        assert len(versions)==2
        latest=page.evaluate("async()=> (await (await import('./db.js')).all('records'))[0]")
        assert latest['period']=='noite'
        assert latest['dayNote']=='Hoje reconheci a ansiedade.\nVou cuidar do descanso.'
        assert page.locator('.home-quote blockquote').inner_text()==home_quote
        passed('Reflexão visível na Home; opções locais sem menu nativo; relato opcional, versões salvas e somente último registro vigente')
        passed('Edição do check-in não duplica impulsos; citações distintas e bloqueio de Esc')

        page.get_by_role('button',name='Rever check-in de hoje').click()
        assert page.locator('[name=dayNote]').input_value()==''
        page.locator('.revision-history summary').click()
        assert page.locator('.revision-entry').count()==1
        assert 'Humor:' not in page.locator('.revision-history').inner_text()
        assert page.locator('.revision-entry').first.locator('.daily-note').inner_text()==latest['dayNote']
        page.locator('[name=status][value=relapse]').check()
        page.locator('[name=period][value=madrugada]').check()
        for name in ['before','during','after','mainTrigger','feeling','environment','adjustment']:
            assert page.locator(f'[name={name}]').count()==0
        assert page.locator('#checkForm textarea').count()==1
        assert not page.locator('[name=dayNote]').evaluate('(e)=>e.required')
        page.locator('[name=dayNote]').fill('')
        for name,value in [('urge','5'),('anxiety','5'),('sleep','1')]:
            page.locator(f'[name={name}]').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event("input",{bubbles:true}));}',value)
        page.get_by_role('button',name='Salvar fechamento do dia').click()
        page.get_by_role('button',name='Continuar',exact=True).wait_for()
        assert page.locator('#modal blockquote').inner_text().strip('“”')!=home_quote
        page.keyboard.press('Escape')
        assert page.locator('#modal').is_visible()
        page.get_by_role('button',name='Continuar',exact=True).click()
        page.get_by_role('heading',name='O que você está pensando?').wait_for()
        assert not page.locator('#nav').is_visible()
        assert not page.locator('[name=answer]').evaluate('(e)=>e.required')
        page.get_by_role('button',name='Continuar',exact=True).click()
        assert page.locator('[name=answer]').input_value()==''
        page.get_by_role('button',name='Venci este impulso').click()
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        page.get_by_role('heading',name='Eu consigo',exact=True).wait_for()
        total=page.evaluate("async()=>{const d=await import('./db.js'),D=await import('./domain.js');return D.impulseTotal(await d.all('records'),await d.all('events'));}")
        assert total==1,total
        page.get_by_role('button',name='Aceitar',exact=True).click()
        page.get_by_text('Desafio aceito:',exact=False).wait_for()
        passed('Recaída salva sem revisão obrigatória; apenas Sobre seu dia não obrigatório; alto risco e TCC funcionam')
        page.get_by_role('button',name='Conquistas',exact=True).click()
        # The only confirmed day was corrected to relapse: it cannot remain an award.
        assert page.locator('.milestone.past').count()==0
        assert page.locator('.milestone.current').count()==0
        assert page.locator('.milestone').count()==15
        assert page.locator('.milestone').first.locator('strong').inner_text()=='1'
        passed('Recaída zera marcos ativos e remove conquista do mesmo dia corrigido; não preserva máximo indevido')

        page.get_by_role('button',name='Início',exact=True).click()
        report_id=page.locator('[data-action=report]').first.get_attribute('data-id')
        page.locator('[data-action=report]').first.click()
        page.get_by_role('button',name='Fechar',exact=True).click()
        assert page.locator(f'[data-action=report][data-id="{report_id}"]').count()==0
        page.reload()
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        assert page.locator(f'[data-action=report][data-id="{report_id}"]').count()==0
        page.get_by_role('button',name='Progresso',exact=True).click()
        page.locator(f'[data-action=day][data-date="{today}"]').click()
        page.get_by_text('Dia finalizado · somente leitura',exact=True).wait_for()
        assert page.locator('#modal input, #modal textarea, #modal select, #modal form, #modal summary').count()==0
        assert page.locator('#modal .daily-note').count()==1
        assert page.locator('#modal .daily-report dd').count()==7
        assert page.locator('#modal button').count()==1
        page.screenshot(path=str(OUT/'relatorio-dia-mobile.png'),full_page=True)
        page.get_by_role('button',name='Fechar',exact=True).click()
        page.get_by_role('button',name='Mês anterior').click()
        page.get_by_role('heading',name='Relatório arquivado').wait_for()
        assert page.locator('canvas').count()==4
        assert page.locator('canvas').first.get_attribute('aria-label')
        assert page.locator('.chart').first.evaluate('(e)=>getComputedStyle(e).backgroundColor')=='rgb(23, 23, 23)'
        assert page.locator('canvas').first.evaluate('(c)=>Array.from(c.getContext("2d").getImageData(0,0,1,1).data)')==[23,23,23,255]
        assert 'Manhã' in page.locator('#hourChart').get_attribute('aria-label')
        page.screenshot(path=str(OUT/'progresso-mobile.png'),full_page=True)
        passed('Relatório lido sai definitivamente da Home e fica no calendário; quatro gráficos acessíveis')

        audio_file=OUT/'teste-audio.wav'
        with wave.open(str(audio_file),'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000)
            w.writeframes(b'\0\0'*16000*20)
        page.get_by_role('button',name='Áudios',exact=True).click()
        page.locator('.library-add > summary').click()
        page.locator('[name=audioFile]').set_input_files(str(audio_file))
        assert page.locator('[name=title]').input_value()=='teste-audio'
        page.get_by_role('button',name='Salvar na biblioteca').click()
        page.get_by_role('button',name='Ouvir',exact=True).click()
        page.locator('#audio').evaluate('(a)=>{a.currentTime=7.25;a.pause();}')
        wait_js("document.querySelector('#audioPosition').textContent.includes('0:00:07')")
        page.get_by_role('button',name='Expandir reprodutor',exact=True).click()
        page.get_by_role('button',name='1,5x',exact=True).click()
        page.get_by_role('button',name='Reduzir reprodutor',exact=True).click()
        page.get_by_role('button',name='Início',exact=True).click()
        assert page.locator('#player').is_visible()
        page.reload()
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        page.get_by_role('button',name='Áudios',exact=True).click()
        page.get_by_role('button',name='Ouvir',exact=True).click()
        wait_js('document.querySelector("#audio").currentTime>=7')
        assert page.locator('#audio').evaluate('(a)=>a.playbackRate')==1.5
        page.locator('#audio').evaluate('(a)=>a.pause()')
        assert not page.locator('#audio').evaluate('(a)=>a.controls')
        assert not page.locator('#audio').is_visible()
        assert page.locator('#player input[type=range]').count()==1
        page.get_by_role('button',name='Reproduzir',exact=True).click()
        wait_js('!document.querySelector("#audio").paused')
        page.get_by_role('button',name='Pausar',exact=True).click()
        wait_js('document.querySelector("#audio").paused')
        page.get_by_role('button',name='Expandir reprodutor',exact=True).click()
        assert page.locator('#player').evaluate('(e)=>e.classList.contains("expanded")')
        assert page.locator('#app').evaluate('(e)=>e.inert')
        assert page.locator('#player').evaluate('(e)=>{const r=e.getBoundingClientRect();return r.x===0&&r.y===0&&Math.abs(r.height-innerHeight)<2&&Math.abs(r.width-innerWidth)<2}')
        assert page.locator('#playingTitle').evaluate('(e)=>getComputedStyle(e).textAlign')=='center'
        assert page.locator('#expandPlayer').inner_text()==''
        assert page.locator('#closePlayer').inner_text()==''
        assert page.locator('.player-corners').evaluate('(e)=>e.getBoundingClientRect().top<60')
        page.locator('#audioSeek').fill('10')
        wait_js('document.querySelector("#audio").currentTime>=10')
        page.locator('#audioSeek').blur()
        page.screenshot(path=str(OUT/'player-expandido-mobile.png'),full_page=False)
        page.get_by_role('button',name='Reduzir reprodutor',exact=True).click()
        assert not page.locator('#player').evaluate('(e)=>e.classList.contains("expanded")')
        wait_js('Number(document.querySelector(".track-progress").value)>=10')
        passed('Arquivo de áudio em Blob, título automático, player entre abas, posição e velocidade após reabrir')

        page.evaluate('''window.showSaveFilePicker=async()=>({createWritable:async()=>({write:async s=>{window.backupText=(window.backupText??'')+s},close:async()=>{},abort:async()=>{}})});''')
        page.get_by_role('button',name='Ajustes',exact=True).click()
        page.get_by_role('button',name='Exportar backup').click()
        page.get_by_text('Backup salvo no local escolhido.').wait_for()
        backup=page.evaluate('window.backupText')
        parsed=json.loads(backup)
        assert parsed['format']=='SafeHarbor/2'
        assert len([x for x in parsed['items'] if x.get('store')=='revisions'])==3
        assert len([x for x in parsed['items'] if x['kind']=='chunk'])>=3
        backup_file=OUT/'teste-backup.json'
        backup_file.write_text(backup,encoding='utf-8')
        audio_id=next(x['id'] for x in parsed['items'] if x['kind']=='audio')
        page.evaluate('''async(id)=>{const d=await import('./db.js');await d.remove('records',(await import('./domain.js')).today());await d.remove('audio',id);await d.remove('audioMeta',id);}''',audio_id)
        page.locator('[name=backup]').set_input_files(str(backup_file))
        page.locator('[name=agree]').check()
        page.get_by_role('button',name='Verificar e restaurar backup').click()
        page.get_by_text('Backup validado e restaurado.').wait_for()
        restored=page.evaluate('''async(id)=>{const d=await import('./db.js');return {audio:(await d.get('audio',id)).blob.size,records:(await d.all('records')).length,locked:(await d.get('settings','main')).startDateLocked,stage:(await d.all('staging')).length};}''',audio_id)
        assert restored=={'audio':audio_file.stat().st_size,'records':1,'locked':True,'stage':0},restored
        assert len(page.evaluate("async()=> (await import('./db.js')).all('revisions')"))==3
        passed('Exportação JSON válida com áudio em múltiplos blocos; restauração completa e limpeza da área temporária')

        corrupt=OUT/'teste-corrompido.json'
        corrupt.write_text(backup[:-50],encoding='utf-8')
        page.locator('[name=backup]').set_input_files(str(corrupt))
        page.locator('[name=agree]').check()
        page.get_by_role('button',name='Verificar e restaurar backup').click()
        wait_js('document.querySelector("#toast").classList.contains("visible")')
        page.wait_for_timeout(300)
        assert page.evaluate("async()=> (await (await import('./db.js')).all('records')).length")==1
        assert page.evaluate("async()=> (await (await import('./db.js')).all('staging')).length")==0
        passed('Backup truncado é rejeitado sem modificar o histórico existente')

        # A challenge accepted yesterday should award exactly one trophy today.
        page.evaluate('''async()=>{const d=await import('./db.js'),D=await import('./domain.js');const date=D.today();await d.put('challenges',{id:'test-win',status:'accepted',target:date});await d.put('records',{id:date,date,status:'managed',mood:4,energy:4,sleep:4,anxiety:2,urge:2,triggers:[],hour:12});}''')
        page.reload()
        page.get_by_role('heading',name='Configurações',exact=True).wait_for()
        page.get_by_role('button',name='Conquistas',exact=True).click()
        assert page.locator('svg.trophy').count()==1
        page.reload()
        page.get_by_role('heading',name='Marcos e troféus').wait_for()
        assert page.locator('svg.trophy').count()==1
        passed('Desafio vencido concede um único troféu persistente, sem duplicar ao reiniciar')

        # Actual browser offline mode: route fulfills the APK-like assets directly from disk.
        context.set_offline(True)
        page.goto(url+'/#inicio')
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        assert not external,external
        page.screenshot(path=str(OUT/'inicio-mobile.png'),full_page=True)
        passed('Modo offline do navegador com assets locais: inicialização completa e zero solicitações externas')

        # Simulated future app version 3 adds one store; all old stores survive.
        context.unroute(url+'/**',local_asset)
        def v2(route):
            if '/db.js' in route.request.url:
                text=(ROOT/'db.js').read_text(encoding='utf-8').replace('DB_VERSION=4','DB_VERSION=5').replace("'audioMeta','staging'","'audioMeta','staging','futureModule'")
                route.fulfill(body=text,content_type='text/javascript')
            else: local_asset(route)
        context.route(url+'/**',v2)
        page.reload()
        page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        migrated=page.evaluate('''async()=>{const d=await import('./db.js');return {records:(await d.all('records')).length,trophies:(await d.all('trophies')).length,audio:(await d.all('audioMeta')).length,future:(await d.all('futureModule')).length};}''')
        assert migrated=={'records':1,'trophies':1,'audio':1,'future':0},migrated
        passed('Migração futura IndexedDB v4 → v5 adiciona store sem perder registros, áudio ou troféus')

        # Existing version-1 database, with an old numeric hour and no optional note.
        legacy=context.browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
        legacy.route(url+'/**',local_asset)
        old=legacy.new_page()
        old.on('pageerror',lambda e:errors.append(str(e)))
        old.route(url+'/bootstrap',lambda r:r.fulfill(body='<html lang="pt-BR"><title>Preparação</title></html>',content_type='text/html'))
        old.goto(url+'/bootstrap')
        old.evaluate('''async(data)=>{await new Promise((resolve,reject)=>{const q=indexedDB.open('SafeHarbor',1);q.onupgradeneeded=()=>{for(const s of ['settings','records','reports','quoteHistory','events','trophies','challenges','audio','audioMeta','staging'])q.result.createObjectStore(s,{keyPath:'id'});};q.onerror=()=>reject(q.error);q.onsuccess=()=>{const d=q.result,t=d.transaction(['settings','records'],'readwrite');t.objectStore('settings').put({id:'main',startDate:data.start,startDateLocked:true,bestEver:0,createdAt:Date.now()});t.objectStore('records').put({id:data.today,date:data.today,status:'managed',hour:2,mood:3,energy:3,sleep:3,anxiety:3,urge:3,triggers:[],updatedAt:100});t.oncomplete=()=>{d.close();resolve();};};});}''',{'start':start,'today':today})
        old.goto(url+'/#registro')
        old.get_by_role('heading',name='Como foi o seu dia?').wait_for()
        assert old.locator('[name=period][value=madrugada]').is_checked()
        assert old.locator('[name=dayNote]').input_value()==''
        old.locator('[name=dayNote]').fill('Relato adicionado após a atualização.')
        old.locator('[name=period][value=tarde]').check()
        old.get_by_role('button',name='Salvar fechamento do dia').click()
        old.get_by_role('heading',name='Um dia de cada vez.').wait_for()
        migrated_old=old.evaluate("async()=>{const d=await import('./db.js');return {version:d.DB_VERSION,records:await d.all('records'),versions:await d.all('revisions')};}")
        assert migrated_old['version']==4
        assert len(migrated_old['records'])==1 and len(migrated_old['versions'])==2
        assert migrated_old['records'][0]['period']=='tarde'
        assert any(r.get('hour')==2 for r in migrated_old['versions'])
        assert migrated_old['records'][0]['dayNote']=='Relato adicionado após a atualização.'
        legacy.close()
        passed('Atualização real v1 → v4 preserva registro legado, converte horário em período e arquiva a versão anterior ao editar')

        context.set_offline(False)
        page.get_by_role('button',name='Áudios',exact=True).click()
        with tempfile.TemporaryDirectory(prefix='Livro-') as folder:
            folder=Path(folder)
            for name in ['04-final.wav','02-meio.wav','01-inicio.wav','03-continuacao.wav']:
                (folder/name).write_bytes(audio_file.read_bytes())
            (folder/'notas.txt').write_text('Ignorado',encoding='utf-8')
            page.locator('.library-add > summary').click()
            page.locator('[name=bookTitle]').fill('Livro de teste')
            page.locator('[name=audioFolder]').set_input_files(str(folder))
            page.get_by_role('button',name='Adicionar livro',exact=True).click()
            book=page.locator('.audio-book').filter(has=page.get_by_role('heading',name='Livro de teste',exact=True))
            book.wait_for()
            assert book.locator('h3').all_text_contents()==['1. 01-inicio','2. 02-meio','3. 03-continuacao','4. 04-final']
            assert book.locator('.chapter').count()==4
            book.get_by_role('button',name='Marcar concluído',exact=True).nth(2).click()
            expect(book.locator('.chapter.completed')).to_have_count(1)
            page.reload()
            book.wait_for()
            expect(book.locator('.chapter.completed')).to_have_count(1)
            book.get_by_role('button',name='Ouvir',exact=True).first.click()
            wait_js("document.querySelector('#playingTitle').textContent==='01-inicio' && document.querySelector('#audio').readyState>=2 && !document.querySelector('#audio').paused")
            page.locator('#audio').evaluate('(a)=>{a.currentTime=19.8;a.play();}')
            wait_js("document.querySelectorAll('.audio-book .chapter.completed').length===2")
            wait_js("document.querySelector('#player').textContent.includes('02-meio')")
            page.locator('#audio').evaluate('(a)=>a.pause()')
            page.screenshot(path=str(OUT/'biblioteca-mobile.png'),full_page=True)
            passed('Pasta importa apenas áudios em ordem alfabética; conclusão visual persiste e reprodução avança ao próximo capítulo')
            book.get_by_role('button',name='Excluir arquivo',exact=True).last.click()
            page.get_by_role('button',name='Excluir áudio',exact=True).click()
            expect(book.locator('.chapter')).to_have_count(3)
            book.locator('[name=selectedTrack]').nth(0).check()
            book.locator('[name=selectedTrack]').nth(1).check()
            book.get_by_role('button',name='Excluir selecionados',exact=True).click()
            page.get_by_role('button',name='Confirmar exclusão',exact=True).click()
            expect(book.locator('.chapter')).to_have_count(1)
            book.get_by_role('button',name='Excluir livro',exact=True).click()
            page.get_by_role('button',name='Confirmar exclusão',exact=True).click()
            wait_js("document.querySelectorAll('.audio-book').length===1")
            remaining=page.evaluate("async()=>{const d=await import('./db.js');return [(await d.all('audio')).length,(await d.all('audioMeta')).length,(await d.all('staging')).length]}")
            assert remaining==[1,1,0],remaining
            assert len(list(folder.glob('*.wav')))==4
            passed('Exclusão individual, de selecionados e do livro remove cópias e metadados; originais preservados')

        page.get_by_role('button',name='Áudios',exact=True).click()
        for title in ['A primeiro avulso','Z último avulso']:
            page.locator('.library-add > summary').click()
            page.locator('[name=audioFile]').set_input_files(str(audio_file))
            page.locator('[name=title]').fill(title)
            page.get_by_role('button',name='Salvar na biblioteca').click()
            page.get_by_role('heading',name=title,exact=False).wait_for()
        page.reload()
        page.get_by_role('heading',name='Audiobooks',exact=True).wait_for()
        titles=page.locator('[data-book=avulsos] h3').all_text_contents()
        assert titles==['1. Z último avulso','2. A primeiro avulso','3. teste-audio'],titles
        assert 'ordem alfabética' not in page.locator('#app').inner_text()
        page.locator('[data-book=avulsos]').get_by_role('button',name='Ouvir',exact=True).first.click()
        wait_js('!document.querySelector("#audio").paused')
        page.get_by_role('button',name='Fechar reprodutor',exact=True).click()
        assert not page.locator('#player').is_visible()
        assert page.locator('#audio').evaluate('(a)=>a.paused')
        passed('Player sem controles nativos duplicados, ícones acessíveis e título centralizado; avulsos recentes primeiro após reabrir')
        assert page.locator('[name=audioFile]').evaluate('(e)=>getComputedStyle(e,"::file-selector-button").backgroundColor')=='rgb(252, 165, 165)'
        assert page.locator('[name=audioFolder]').evaluate('(e)=>getComputedStyle(e,"::file-selector-button").borderRadius')=='16px'
        for status in ['managed','resisted','lapse']:
            page.get_by_role('button',name='Check-in',exact=True).click()
            page.locator(f'[name=status][value={status}]').check()
            for field,value in [('urge','5'),('sleep','5'),('anxiety','1')]:
                page.locator(f'[name={field}]').fill(value)
            page.get_by_role('button',name='Salvar fechamento do dia').click()
            if status=='lapse':
                page.get_by_role('heading',name='O que você está pensando?').wait_for()
                page.locator('[data-action=riskExit]').click()
            page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
            assert not page.locator('#modal').is_visible()
        passed('Reflexão apenas na recaída e diferente da Home; calendário somente leitura; marco de 1 dia e seletores vermelhos arredondados')
        assert not errors,errors
        passed('Nenhum erro JavaScript não tratado em todos os fluxos exercitados')
    except Exception:
        page.screenshot(path=str(OUT/'falha.png'),full_page=True)
        traceback.print_exc()
        print('PAGE ERRORS',errors,flush=True)
        print('BODY',page.locator('body').inner_text()[:6000],flush=True)
        raise
    finally:
        browser.close()
        server.shutdown()
        (OUT/'browser-results.json').write_text(json.dumps({'passed':results,'errors':errors,'external_requests':external},ensure_ascii=False,indent=2),encoding='utf-8')

print('TESTES DE NAVEGADOR CONCLUÍDOS',flush=True)
