from pathlib import Path
from urllib.parse import urlparse
import json, sys
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'; URL='http://127.0.0.1:18782'
results=[]; errors=[]; requested=[]
def passed(message):
 results.append(message); print('OK:',message,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  path=urlparse(route.request.url).path
  requested.append(path)
  if path=='/seed':
   route.fulfill(body='<html><title>Preparar atualização</title></html>',content_type='text/html');return
  f=ROOT/(path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:
   route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else: route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  page.goto(URL+'/seed')
  before=page.evaluate("""async()=>{
   const db=await import('./db.js');await db.openDB();const D=await import('./domain.js'),date=D.today(),now=Date.now();
   const rows={
    privacy:{id:'main',enabled:true,salt:'b'.repeat(32),hash:'a'.repeat(64),failures:4,retryAt:now+30000},
    blockedApps:{id:'instagram',name:'Instagram',custom:false,nightStart:'23:00',nightEnd:'06:00',nightEnabled:true,lockUntil:now+86400000,nightBypassUntil:0},
    blockAttempts:{id:'pending',appId:'instagram',status:'pending',startedAt:now,readyAt:now+120000},
    records:{id:date,date,status:'managed',period:'night',dayNote:'Meu histórico deve continuar intacto.',mood:4,energy:4,sleep:3,anxiety:2,urge:2,triggers:[],review:{},updatedAt:now},
    events:{id:'block-resisted:previous',kind:'impulse',source:'app-blocker',date,at:now},
    audioMeta:{id:'legacy-audio',title:'Áudio anterior',size:14,position:8,speed:1,completed:false,createdAt:now}
   };
   await db.put('settings',{id:'main',startDate:date,startDateLocked:true,bestEver:0});
   for(const [store,row] of Object.entries(rows))await db.put(store,row);
   await db.put('audio',{id:'legacy-audio',blob:new Blob(['áudio original'])});
   return rows;
  }""")
  page.goto(URL+'/#bloqueio')
  expect(page.locator('[data-action=risk]')).to_be_visible()
  assert page.title()=='SafeHarbor'
  assert page.locator('#camouflage,#camouflageButton,#blockerButton,#privacyForm,#blockBarrier').count()==0
  assert page.locator('#nav button').count()==5
  after=page.evaluate("""async rows=>{
   const db=await import('./db.js'),result={};for(const [store,row] of Object.entries(rows))result[store]=await db.get(store,row.id);
   return {rows:result,audio:await (await db.get('audio','legacy-audio')).blob.text(),version:db.DB_VERSION};
  }""",before)
  assert after=={'rows':before,'audio':'áudio original','version':4},after
  passed('Atualização com PIN ativo, quarentena e tentativa pendente abre diretamente o SafeHarbor; histórico, áudio e todas as linhas legadas preservados.')
  for _ in range(2):
   page.evaluate("document.dispatchEvent(new Event('safeharborPause'))")
   expect(page.locator('[data-action=risk]')).to_be_visible()
   page.reload();expect(page.locator('[data-action=risk]')).to_be_visible()
  page.locator('#settingsButton').click()
  expect(page.locator('#importForm')).to_be_visible()
  assert 'Modo Camuflagem' not in page.locator('#app').inner_text()
  assert 'PIN' not in page.locator('#app').inner_text()
  assert page.locator('#privacyForm').count()==0
  page.screenshot(path=str(OUT/'v171-ajustes.png'),full_page=True)
  assert not {'/privacy.js','/blocker.js'}.intersection(requested)
  passed('Reabertura e minimização não ativam disfarce, PIN ou barreiras; configurações e cabeçalho sem os controles removidos e sem carregar seus módulos.')
  for width,height in [(320,740),(393,852),(768,1024),(1280,800),(852,393)]:
   page.set_viewport_size({'width':width,'height':height})
   for route in ['inicio','registro','progresso','conquistas','audios','ajustes']:
    page.goto(URL+'/#'+route)
    expect(page.locator('#app')).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,route)
  page.set_viewport_size({'width':393,'height':852})
  page.goto(URL);expect(page.locator('[data-action=risk]')).to_be_visible()
  page.screenshot(path=str(OUT/'v171-inicio.png'),full_page=True)
  passed('Seis seções preservadas, sem rolagem horizontal em 320–1280 px e paisagem; logo e engrenagem mantidos.')
  assert not errors,errors
 finally:
  browser.close()
  (OUT/'v171-results.json').write_text(json.dumps({'passed':results,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
