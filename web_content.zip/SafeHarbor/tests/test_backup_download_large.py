from pathlib import Path
from urllib.parse import urlparse
import json, sys, base64, tempfile, wave, time
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'; URL='http://127.0.0.1:18777'
results=[]; errors=[]
def passed(message):
 results.append(message); print('OK:',message,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:
   route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else: route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page(); page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  page.goto(URL);page.locator('[data-action=finishReflection]').click()
  page.evaluate("""async()=>{const db=await import('./db.js'),part=new Blob([new Uint8Array(262144)]);await db.put('audio',{id:'large-export',blob:new Blob(Array(512).fill(part),{type:'audio/wav'})});await db.put('audioMeta',{id:'large-export',title:'Ensaio 128 MiB',position:0});window.Website2APK={};window.showSaveFilePicker=async()=>{throw Error('Seletor não deve ser usado')}}""")
  page.locator('#settingsButton').click()
  metrics=[]
  with tempfile.TemporaryDirectory(prefix='safeharbor-download-test-') as temp:
   for protected in [False,True]:
    page.locator('[name=encryptBackup]').set_checked(protected)
    if protected:
     page.locator('[name=exportPassword]').fill('senha longa de teste')
     page.locator('[name=confirmPassword]').fill('senha longa de teste')
    page.evaluate('window.gap=0;window.last=performance.now();window.monitor=setInterval(()=>{const t=performance.now();window.gap=Math.max(window.gap,t-window.last);window.last=t},20)')
    start=time.monotonic()
    with page.expect_download(timeout=180000) as event:page.locator('[data-action=export]').click()
    download=event.value;destination=Path(temp)/('protegido.json' if protected else 'simples.json');download.save_as(destination)
    elapsed=round(time.monotonic()-start,2)
    gap=page.evaluate('clearInterval(window.monitor);window.gap')
    assert gap<1000,(protected,gap)
    assert destination.stat().st_size>128*1024*1024
    page.evaluate("async()=>{const db=await import('./db.js');await db.transaction(['audio','audioMeta'],tx=>{tx.objectStore('audio').clear();tx.objectStore('audioMeta').clear()})}")
    page.locator('[name=backup]').set_input_files(str(destination))
    page.locator('[name=backupPassword]').fill('senha longa de teste' if protected else '')
    page.locator('[name=agree]').check()
    page.get_by_role('button',name='Verificar e restaurar backup').click()
    page.get_by_text('Backup validado e restaurado.',exact=True).wait_for(timeout=180000)
    assert page.evaluate("async()=> (await (await import('./db.js')).get('audio','large-export')).blob.size")==128*1024*1024
    metrics.append({'protected':protected,'download_bytes':destination.stat().st_size,'export_seconds':elapsed,'max_ui_gap_ms':round(gap,2)})
    print(json.dumps(metrics[-1]),flush=True)
  passed('Download e restauração reais de áudio de 128 MiB, com e sem senha; interface com intervalos menores que um segundo.')
  assert not errors,errors
 finally:
  browser.close()
  (OUT/'v166-download-large-results.json').write_text(json.dumps({'passed':results,'metrics':metrics,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
