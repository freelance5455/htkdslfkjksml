import assert from 'node:assert/strict';
import test from 'node:test';
import * as D from '../domain.js';

const start='2026-11-06', end='2026-11-09';
const rec=(date,status='managed')=>({id:date,date,status});
const previous=[rec('2026-11-07'),rec('2026-11-08')];

// Opening on day three must not turn the unclosed day into a permanent award.
assert.equal(D.bestStreak(previous,start,end),2);
assert.equal(D.bestStreak([...previous,rec(end,'relapse')],start,end),2);
assert.equal(D.bestStreak([],start,end),0);
assert.equal(D.bestStreak([...previous,rec(end)],start,end),3);
console.log('Regressões: marco de 3 dias requer fechamento e recaída não o concede.');

test('Contador corrido separado de marcos e melhor sequência confirmados',()=>{
 assert.deepEqual(D.sequenceStats(previous,start,end),{elapsed:3,confirmed:2,best:2});
 assert.deepEqual(D.sequenceStats([],start,end),{elapsed:3,confirmed:0,best:0});
 assert.deepEqual(D.sequenceStats([...previous,rec(end,'relapse')],start,end),{elapsed:0,confirmed:0,best:2});
});
for(const n of D.milestones){
 test(`Marco de ${n} dias: pendente, confirmado, corrigido e preservado em outra sequência`,()=>{
  const target=D.addDays(start,n),yesterday=D.addDays(target,-1);
  const rows=[rec(yesterday)];
  assert.equal(D.bestStreak(rows,start,target),n-1);
  assert.equal(D.confirmedStreak([...rows,rec(target)],start,target),n);
  assert.equal(D.bestStreak([...rows,rec(target,'relapse')],start,target),n-1);
  const later=[...rows,rec(target),rec(D.addDays(target,1),'relapse')];
  assert.equal(D.bestStreak(later,start,D.addDays(target,1)),n);
  assert.equal(D.confirmedStreak(later,start,D.addDays(target,1)),0);
 });
}
test('Correção retroativa divide a sequência; reversão restaura o cálculo',()=>{
 const rows=[...previous,rec(end),rec('2026-11-10'),rec('2026-11-11')];
 assert.equal(D.bestStreak(rows,start,'2026-11-11'),5);
 const changed=rows.map(r=>r.date===end?rec(end,'relapse'):r);
 assert.deepEqual(D.sequenceStats(changed,start,'2026-11-11'),{elapsed:2,confirmed:2,best:2});
 assert.equal(D.bestStreak(rows,start,'2026-11-11'),5);
});
test('Deslize mantém sequência, recaída reinicia em zero e dia inicial é zero',()=>{
 assert.deepEqual(D.sequenceStats([rec(start)],start,start),{elapsed:0,confirmed:0,best:0});
 assert.equal(D.confirmedStreak([...previous,rec(end,'lapse')],start,end),3);
 const rows=[rec(end,'relapse'),rec('2026-11-10')];
 assert.deepEqual(D.sequenceStats(rows,start,'2026-11-10'),{elapsed:1,confirmed:1,best:1});
});
test('Fora do intervalo não conta; ordem não muda resultado nem altera entradas',()=>{
 const rows=[rec('2026-11-10'),rec(end),rec('2026-11-05','relapse'),...previous].reverse();
 const copy=structuredClone(rows);
 assert.deepEqual(D.sequenceStats(rows,start,end),{elapsed:3,confirmed:3,best:3});
 assert.deepEqual(rows,copy);
 assert.deepEqual(D.sequenceStats(rows,'2026-11-10',end),{elapsed:0,confirmed:0,best:0});
});
test('Datas civis atravessam mês, ano e fevereiro bissexto',()=>{
 for(const [a,b] of [['2024-02-28','2024-03-02'],['2026-12-30','2027-01-02']]){
  assert.deepEqual(D.sequenceStats([rec(b)],a,b),{elapsed:3,confirmed:3,best:3});
 }
});
test('Desafios reavaliam vitórias, recaídas, deslizes, expiração e correções tardias',()=>{
 for(const status of ['accepted','won','expired']){
  const c={id:'challenge',status,target:end};
  assert.equal(D.challengeStatus(c,[rec(end)],end),'won');
  assert.equal(D.challengeStatus(c,[rec(end,'resisted')],end),'won');
  for(const outcome of ['relapse','lapse']){
   assert.equal(D.challengeStatus(c,[rec(end,outcome)],end),'accepted');
   assert.equal(D.challengeStatus(c,[rec(end,outcome)],'2026-11-10'),'expired');
  }
  assert.equal(D.challengeStatus(c,[],end),'accepted');
  assert.equal(D.challengeStatus(c,[],'2026-11-10'),'expired');
  assert.equal(D.challengeStatus(c,[rec(end)],'2026-11-08'),'accepted');
 }
 for(const status of ['offered','dismissed','cancelled']){
  assert.equal(D.challengeStatus({status,target:end},[rec(end)],end),status);
 }
});
test('Oferta de apoio mantém regra de mais de três dias corridos ou quatro dias difíceis seguidos',()=>{
 const target='2026-11-11';
 assert.equal(D.shouldOfferChallenge([rec(target,'relapse')],start,target),true);
 assert.equal(D.shouldOfferChallenge([rec('2026-11-09','relapse')],start,'2026-11-09'),false);
 assert.equal(D.shouldOfferChallenge([rec('2026-11-09'),rec('2026-11-10','relapse')],start,'2026-11-10'),true);
 assert.equal(D.shouldOfferChallenge([rec('2026-11-10'),rec(target,'relapse')],start,target),true);
 const hard=[0,1,2,3].map(n=>rec(D.addDays(target,-n),'lapse'));
 assert.equal(D.shouldOfferChallenge(hard,start,target),true);
 assert.equal(D.shouldOfferChallenge(hard.slice(0,3),start,target),false);
 assert.equal(D.shouldOfferChallenge(hard.map((r,i)=>i===2?{...r,status:'managed',urge:5}:r),start,target),true);
 assert.equal(D.shouldOfferChallenge(hard.map((r,i)=>i===2?rec(r.date):r),start,target),false);
});
