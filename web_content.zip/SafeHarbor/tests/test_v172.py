"""Real Edge UI regression tests, isolated synthetic data and local assets only."""
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime, timezone
import json, re, sys
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'
URL='http://127.0.0.1:18783'
TODAY='2026-11-09'
results=[]; errors=[]; external=[]

def passed(message):
    results.append(message); print('OK:',message,flush=True)

def rec(date,status='managed'):
    return dict(id=date,date=date,status=status,period='manha',mood=3,energy=3,
                sleep=3,anxiety=2,urge=2,triggers=[],dayNote='Relato preservado '+date)

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
    def asset(route):
        path=urlparse(route.request.url).path
        if path=='/seed':
            route.fulfill(body='<html><title>Teste isolado</title></html>',content_type='text/html');return
        f=ROOT/(path.lstrip('/') or 'index.html')
        if f.is_file() and f.parent==ROOT:
            route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
        else:route.abort()

    def scenario(start,records,best=0,challenges=None,trophies=None,reports=None):
        context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
        context.route(URL+'/**',asset)
        page=context.new_page()
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('request',lambda r:external.append(r.url) if not r.url.startswith((URL,'blob:','data:')) else None)
        page.clock.install(time=datetime(2026,11,9,15,tzinfo=timezone.utc))
        page.goto(URL+'/seed')
        page.evaluate('''async data=>{
            const db=await import('./db.js');await db.openDB();
            await db.put('settings',{id:'main',startDate:data.start,startDateLocked:true,bestEver:data.best,createdAt:123});
            for(const name of ['records','challenges','trophies','reports'])for(const row of data[name])await db.put(name,row);
            await db.put('revisions',{...data.records[0],id:'old-revision',recordId:data.records[0]?.id,dayNote:'Versão antiga preservada'});
            await db.put('audioMeta',{id:'audio-original',title:'Meu áudio',position:8,size:16});
            await db.put('audio',{id:'audio-original',blob:new Blob(['audio preservado'])});
            await db.put('events',{id:'impulse-original',kind:'impulse',date:'2026-11-07'});
            localStorage.setItem('safeharbor.reflectionVisit','2026-11-09');
        }''',dict(start=start,best=best,records=records,challenges=challenges or [],trophies=trophies or [],reports=reports or []))
        page.goto(URL)
        expect(page.locator('.hero .number')).to_be_visible()
        return context,page

    def nav(page,name):
        page.get_by_role('button',name=name,exact=True).click()

    def snapshot(page):
        return page.evaluate('''async()=>{const db=await import('./db.js');return {
            settings:await db.get('settings','main'),records:await db.all('records'),
            revisions:await db.all('revisions'),trophies:await db.all('trophies'),
            challenges:await db.all('challenges'),reports:await db.all('reports'),
            audio:await (await db.get('audio','audio-original')).blob.text(),
            audioMeta:await db.get('audioMeta','audio-original'),events:await db.all('events')
        }}''')

    def milestone(page,n):
        return page.locator(f'.milestone:has(strong:text-is("{n}"))')

    def close_effects(page,status):
        if status=='relapse':
            expect(page.locator('#modal')).to_be_visible()
            page.locator('#modal [data-action=closeModal]').click()
        if status in ['relapse','lapse']:
            expect(page.locator('#riskForm')).to_be_visible()
            page.locator('[data-action=riskExit]').click()
        expect(page.locator('.hero .number')).to_be_visible()

    def save(page,status,date=TODAY,note='Novo relato de teste'):
        nav(page,'Check-in')
        page.locator('[name=date]').fill(date)
        page.locator(f'[name=status][value={status}]').check()
        page.locator('[name=period][value=manha]').check()
        page.locator('[name=dayNote]').fill(note)
        page.get_by_role('button',name='Salvar fechamento do dia',exact=True).click()
        close_effects(page,status)

    try:
        previous=[rec('2026-11-07'),rec('2026-11-08')]
        context,page=scenario('2026-11-06',previous,best=3)
        expect(page.locator('.hero .number')).to_have_text('3dias')
        expect(page.locator('.hero .badge')).to_contain_text('Soldado')
        before=snapshot(page)
        assert before['settings']['bestEver']==2
        assert before['settings']['progressMigration']['previousBestEver']==3
        nav(page,'Conquistas')
        expect(milestone(page,3)).not_to_have_class(re.compile('current|past'))
        save(page,'relapse')
        expect(page.locator('.hero .number')).to_have_text('0dias')
        after=snapshot(page)
        assert after['settings']['bestEver']==2
        assert after['audio']==before['audio'] and after['audioMeta']==before['audioMeta']
        assert after['events']==before['events']
        assert all(r in after['records'] for r in previous)
        assert before['revisions'][0] in after['revisions']
        nav(page,'Conquistas')
        expect(milestone(page,3)).not_to_have_class(re.compile('current|past'))
        expect(milestone(page,1)).to_have_class(re.compile('past'))
        page.screenshot(path=str(OUT/'v172-recaida-marcos.png'),full_page=True)
        page.reload();expect(milestone(page,3)).not_to_have_class(re.compile('current|past'))
        assert snapshot(page)['settings']['bestEver']==2
        passed('Caso relatado reproduzido na interface: recaída no terceiro dia mantém marco 3 bloqueado, sequência zero e melhor confirmação 2; correção persiste ao reabrir e preserva histórico/áudio.')
        context.close()

        context,page=scenario('2026-11-06',previous,challenges=[dict(id='today-challenge',status='accepted',target=TODAY)])
        save(page,'managed')
        expect(page.locator('.hero .badge')).to_contain_text('Guerreiro')
        assert len(snapshot(page)['trophies'])==1
        nav(page,'Conquistas');expect(milestone(page,3)).to_have_class(re.compile('current'))
        save(page,'relapse')
        assert len(snapshot(page)['trophies'])==0 and snapshot(page)['settings']['bestEver']==2
        nav(page,'Conquistas');expect(milestone(page,3)).not_to_have_class(re.compile('current|past'))
        save(page,'resisted')
        assert len(snapshot(page)['trophies'])==1 and snapshot(page)['settings']['bestEver']==3
        page.reload();expect(page.locator('.hero .number')).to_be_visible()
        assert len(snapshot(page)['trophies'])==1
        save(page,'lapse')
        state=snapshot(page)
        assert state['settings']['bestEver']==3 and state['trophies']==[]
        assert len([r for r in state['records'] if r['date']==TODAY])==1
        assert len([r for r in state['revisions'] if r['date']==TODAY])==4
        passed('Edições bem gerido → recaída → resistido → deslize: marcos, patente e troféu acompanham o último fechamento, sem duplicar troféu, check-in ou impulsos; revisões preservadas.')
        context.close()

        historical=[rec('2026-11-05'),rec('2026-11-06','relapse'),*previous,rec(TODAY,'relapse')]
        context,page=scenario('2026-11-02',historical,best=365)
        assert snapshot(page)['settings']['bestEver']==3
        nav(page,'Conquistas');expect(milestone(page,3)).to_have_class(re.compile('past'))
        expect(milestone(page,7)).not_to_have_class(re.compile('current|past'))
        for width in [320,393,768,1280]:
            page.set_viewport_size({'width':width,'height':852})
            assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
        passed('Revalidação remove máximo legado inflado, preserva marco 3 comprovado em sequência anterior e mantém layout sem transbordamento de 320 a 1280 px.')
        context.close()

        context,page=scenario('2026-10-20',[rec('2026-10-29')],best=9,
            challenges=[dict(id='october-challenge',status='accepted',target='2026-10-29')],
            reports=[dict(id='2026-10',text='Texto antigo desatualizado',readAt=42,createdAt=10)])
        state=snapshot(page)
        assert len(state['trophies'])==1
        report=state['reports'][0]
        assert '1 troféu(s)' in report['text'] and '1 bem geridos' in report['text']
        assert report['readAt']==42 and report['createdAt']==10
        save(page,'relapse','2026-10-29')
        state=snapshot(page);report=state['reports'][0]
        assert not state['trophies'] and state['challenges'][0]['status']=='expired'
        assert '0 troféu(s)' in report['text'] and '1 com recaída' in report['text']
        assert report['readAt']==42 and report['createdAt']==10
        save(page,'resisted','2026-10-29')
        state=snapshot(page)
        assert len(state['trophies'])==1 and state['challenges'][0]['status']=='won'
        assert '1 troféu(s)' in state['reports'][0]['text']
        nav(page,'Início');assert page.locator('[data-action=report][data-id="2026-10"]').count()==0
        passed('Relatório mensal atualiza após check-in retroativo e reavalia troféu antes de contar; desafios expirados aceitam correção tardia; estado lido e data de criação preservados.')
        context.close()

        context,page=scenario('2026-11-06',previous+[rec(TODAY)],best=3,
            challenges=[dict(id='backup-challenge',status='won',target=TODAY)],
            trophies=[dict(id='backup-challenge',challengeId='backup-challenge',date=TODAY,title='Eu consigo')])
        backup=page.evaluate('''async()=>{
            const db=await import('./db.js'),b=await import('./backup.js');
            const s=await db.get('settings','main');s.bestEver=365;delete s.progressMigration;await db.put('settings',s);
            const r=await db.get('records','2026-11-09');r.status='relapse';await db.put('records',r);
            let text='';window.showSaveFilePicker=async()=>({createWritable:async()=>({write:async v=>text+=v,close:async()=>{},abort:async()=>{}})});
            await b.exportBackup(()=>{});return text;
        }''')
        for _ in range(2):
            page.locator('#settingsButton').click()
            page.locator('[name=backup]').set_input_files(dict(name='legacy-backup.json',mimeType='application/json',buffer=backup.encode('utf-8')))
            page.locator('[name=agree]').check()
            page.get_by_role('button',name='Verificar e restaurar backup',exact=True).click()
            expect(page.locator('#toast')).to_have_text('Backup validado e restaurado.')
            state=snapshot(page)
            assert state['settings']['bestEver']==2 and state['trophies']==[]
            assert state['settings']['startDate']=='2026-11-06' and state['settings']['startDateLocked']
            assert state['audio']=='audio preservado' and state['audioMeta']['position']==8
            assert len(state['records'])==3 and len(state['events'])==1
            nav(page,'Início')
        nav(page,'Conquistas');expect(milestone(page,3)).not_to_have_class(re.compile('current|past'))
        passed('Restauração real pela interface, repetida duas vezes: máximo 365 e troféu indevido não retornam; data bloqueada, relatos, revisão, áudio, posição e impulso preservados.')
        context.set_offline(True)
        page.reload();expect(milestone(page,3)).not_to_have_class(re.compile('current|past'))
        passed('Aplicação continua funcionando offline com assets locais e nenhuma solicitação externa.')
        context.close()

        context,page=scenario('2026-11-06',previous,best=2)
        original=snapshot(page)
        nav(page,'Check-in')
        page.locator('[name=period][value=manha]').check()
        page.evaluate('''()=>{
            const original=IDBObjectStore.prototype.put;
            IDBObjectStore.prototype.put=function(...args){
                if(this.name==='records'){
                    IDBObjectStore.prototype.put=original;
                    throw new DOMException('Falha de espaço simulada','QuotaExceededError');
                }
                return original.apply(this,args);
            };
        }''')
        page.get_by_role('button',name='Salvar fechamento do dia',exact=True).click()
        expect(page.locator('#toast')).to_contain_text('Espaço ou cota insuficiente')
        state=snapshot(page)
        assert state['records']==original['records'] and state['revisions']==original['revisions']
        assert state['settings']['bestEver']==2
        # A retry and two immediate clicks must commit just one version.
        page.get_by_role('button',name='Salvar fechamento do dia',exact=True).evaluate('(b)=>{b.click();b.click();}')
        expect(page.locator('.hero .number')).to_be_visible()
        state=snapshot(page)
        assert state['settings']['bestEver']==3
        assert len([r for r in state['revisions'] if r['date']==TODAY])==1
        passed('Falha de gravação simulada aborta registro, revisão e melhor sequência juntos; nova tentativa com clique duplo salva apenas uma revisão.')

        nav(page,'Conquistas');expect(milestone(page,3)).to_have_class(re.compile('current'))
        page.clock.set_fixed_time(datetime(2026,11,13,15,tzinfo=timezone.utc))
        page.reload();expect(milestone(page,7)).not_to_have_class(re.compile('current|past'))
        nav(page,'Início');expect(page.locator('.hero .number')).to_have_text('7dias')
        expect(page.locator('.hero .badge')).to_contain_text('Guerreiro')
        assert snapshot(page)['settings']['bestEver']==3
        save(page,'managed','2026-11-13')
        expect(page.locator('.hero .badge')).to_contain_text('General')
        nav(page,'Conquistas');expect(milestone(page,7)).to_have_class(re.compile('current'))
        passed('Avanço de data sem check-in aumenta somente contador corrido; marco 7 e patente General aguardam fechamento real.')

        invalid=backup.replace('"status":"managed"','"status":"toString"',1)
        assert invalid!=backup
        before=snapshot(page)
        page.locator('#settingsButton').click()
        page.locator('[name=backup]').set_input_files(dict(name='invalid-status.json',mimeType='application/json',buffer=invalid.encode('utf-8')))
        page.locator('[name=agree]').check()
        page.get_by_role('button',name='Verificar e restaurar backup',exact=True).click()
        expect(page.locator('#toast')).to_have_text('Data ou status inválido.')
        assert snapshot(page)==before
        assert page.evaluate("async()=> (await (await import('./db.js')).all('staging')).length")==0
        passed('Backup com status inválido antes aceito por herança de objeto é rejeitado antes de alterar dados e limpa a área temporária.')
        context.close()

        context,page=scenario('2026-11-04',[rec('2026-11-08'),rec(TODAY,'relapse')],
            challenges=[dict(id='desafio:'+TODAY,status='offered',created=TODAY)])
        expect(page.locator('[data-action=accept]')).to_be_visible()
        save(page,'managed')
        assert snapshot(page)['challenges'][0]['status']=='cancelled'
        assert page.locator('[data-action=accept]').count()==0
        save(page,'relapse')
        expect(page.locator('[data-action=accept]')).to_be_visible()
        state=snapshot(page)
        assert len(state['challenges'])==1 and state['challenges'][0]['status']=='offered'
        assert state['trophies']==[]
        page.locator('[data-action=accept]').click()
        expect(page.get_by_text('Desafio aceito:',exact=False)).to_be_visible()
        assert snapshot(page)['challenges'][0]['target']=='2026-11-10'
        passed('Correção cancela oferta de apoio sem fundamento; nova recaída restabelece a mesma oferta sem duplicar ou premiar; aceitar mantém amanhã como alvo.')
        context.close()
        assert not errors,errors
        assert not external,external
    finally:
        browser.close()
        (OUT/'v172-results.json').write_text(json.dumps(dict(passed=results,errors=errors,external_requests=external),ensure_ascii=False,indent=2),encoding='utf-8')
