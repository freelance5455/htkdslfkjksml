from pathlib import Path
from urllib.parse import urlparse
import json, sys
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'; URL='http://127.0.0.1:18773'
results=[]; errors=[]
def passed(message):
 results.append(message); print('OK:',message,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:
   route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else: route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page(); page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  page.goto(URL);page.locator('[data-action=finishReflection]').click()
  page.evaluate("""async()=>{const db=await import('./db.js'),D=await import('./domain.js'),s=await db.get('settings','main');s.startDate=D.addDays(D.today(),-36);await db.put('settings',s);for(const [offset,status] of [[-6,'managed'],[-5,'relapse'],[0,'managed']]){const date=D.addDays(D.today(),offset);await db.put('records',{id:date,date,status});}} """)
  page.reload();page.get_by_role('button',name='Conquistas',exact=True).click()
  assert page.locator('.milestone-art').count()==15
  names=page.locator('.milestone-art').evaluate_all('(nodes)=>nodes.map(n=>n.getAttribute("aria-label"))')
  assert len(set(names))==15
  assert page.locator('.milestone.current').count()==2
  assert page.locator('.milestone.past').count()==4
  assert page.locator('.milestone:not(.current):not(.past)').count()==9
  for selector,opacity,filter_value in [('.milestone.current',1,'none'),('.milestone.past',1,'none'),('.milestone:not(.current):not(.past)',.25,'grayscale(1)')]:
   for art in page.locator(selector+' .milestone-art').all():
    state=art.evaluate('(e)=>({opacity:Number(getComputedStyle(e).opacity),filter:getComputedStyle(e).filter})')
    assert state=={'opacity':opacity,'filter':filter_value},state
  page.screenshot(path=str(OUT/'v163-conquistas-mobile.png'),full_page=True)
  for width in [320,393,768,1280]:
   page.set_viewport_size({'width':width,'height':852})
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
   assert page.locator('.milestone-art').evaluate_all('(nodes)=>nodes.every(n=>{const a=n.getBoundingClientRect(),p=n.parentElement.getBoundingClientRect();return a.left>=p.left&&a.right<=p.right})'),width
  passed('Quinze artes distintas; marcos bloqueados cinza a 25%, atuais e anteriores integralmente visíveis, sem transbordamento de 320 a 1280 px.')
  page.set_viewport_size({'width':393,'height':852})
  page.get_by_role('button',name='Áudios',exact=True).click()
  page.locator('.library-add > summary').click()
  button_style="""e=>{const s=getComputedStyle(e,'::file-selector-button');return Object.fromEntries(['backgroundColor','color','borderRadius','borderColor','padding','fontSize','fontWeight'].map(k=>[k,s[k]]))}"""
  audio_style=page.locator('#audioForm [name=audioFile]').evaluate(button_style)
  page.locator('#settingsButton').click()
  backup=page.locator('#importForm input[type=file]')
  backup.scroll_into_view_if_needed()
  assert backup.evaluate(button_style)==audio_style,(backup.evaluate(button_style),audio_style)
  backup.set_input_files({'name':'exemplo.json','mimeType':'application/json','buffer':b'{}'})
  assert backup.evaluate('(e)=>e.files[0].name')=='exemplo.json'
  assert page.locator('#importForm [name=agree]').is_checked()==False
  page.screenshot(path=str(OUT/'v163-backup-mobile.png'))
  for width in [320,393,768,1280]:
   page.set_viewport_size({'width':width,'height':852})
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
  passed('Seletor de backup com as mesmas cores, bordas, espaçamento e fonte do áudio; seleção de arquivo funciona e não importa sem envio.')
  page.locator('header > a').click()
  expect(page.locator('#app h1')).to_have_text('Um dia de cada vez.')
  expect(page.locator('header > a strong')).to_be_visible()
  passed('Escudo continua sendo um atalho funcional para o Início.')
  assert not errors,errors
 except Exception:
  page.screenshot(path=str(OUT/'v163-falha.png'),full_page=True)
  raise
 finally:
  browser.close()
  (OUT/'v163-art-results.json').write_text(json.dumps({'passed':results,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
