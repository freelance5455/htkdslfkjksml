"""Real >1 GB local-file import, playback, seeking and bookmarks in isolated Edge."""
from pathlib import Path
from urllib.parse import urlparse
import json, tempfile, struct, time, os, sys, shutil
from playwright.sync_api import sync_playwright, expect
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'
URL='http://127.0.0.1:18768'
DATA_SIZE=1_100_000_000
result={'bytes':DATA_SIZE+44,'duration_seconds':DATA_SIZE/88200,'errors':[]}
def wait_js(expression,seconds=45):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if page.evaluate('() => '+expression):return
  time.sleep(.05)
 raise AssertionError(expression)
with tempfile.TemporaryDirectory(prefix='safeharbor-large-') as tmp,sync_playwright() as p:
 file=Path(tmp)/'Audiolivro longo - teste de 1.1 GB.wav'
 assert shutil.disk_usage(tmp).free>DATA_SIZE*3,'Sem espaço para o ensaio isolado.'
 with file.open('wb') as f:
  f.write(struct.pack('<4sI4s4sIHHIIHH4sI',b'RIFF',DATA_SIZE+36,b'WAVE',b'fmt ',16,1,1,44100,88200,2,16,b'data',DATA_SIZE))
  f.seek(DATA_SIZE+43);f.write(b'\0')
 print('Arquivo preparado:',file.stat().st_size,'bytes; duração',round(DATA_SIZE/88200/3600,2),'horas.',flush=True)
 browser=p.chromium.launch(executable_path=os.environ.get('SAFEHARBOR_BROWSER',r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'),headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else:route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page()
 page.on('pageerror',lambda e:result['errors'].append(str(e)))
 try:
  page.goto(URL+'/#audios');page.get_by_role('heading',name='Um tempo para ouvir').wait_for()
  page.evaluate("window.uiGaps=[];window.lastUI=performance.now();window.uiMonitor=setInterval(()=>{let now=performance.now();uiGaps.push(now-lastUI);lastUI=now;},20)")
  page.locator('.library-add > summary').click()
  page.locator('[name=audioFile]').set_input_files(str(file))
  page.locator('[name=coverFile]').set_input_files(str(ROOT/'icon.png'))
  expect(page.locator('[data-cover-preview] img')).to_be_visible()
  started=time.monotonic();page.get_by_role('button',name='Salvar na biblioteca').click()
  page.get_by_role('button',name='Ouvir',exact=True).wait_for(timeout=120000)
  result['import_seconds']=round(time.monotonic()-started,3)
  print('Importação concluída em',result['import_seconds'],'s.',flush=True)
  page.evaluate('window.uiGaps=[];window.lastUI=performance.now()')
  started=time.monotonic();page.get_by_role('button',name='Ouvir',exact=True).click()
  wait_js('document.querySelector("#audio").readyState>=2&&!document.querySelector("#audio").paused')
  result['play_seconds']=round(time.monotonic()-started,3)
  duration=page.locator('#audio').evaluate('(a)=>{a.pause();return a.duration}')
  assert abs(duration-DATA_SIZE/88200)<.1,duration
  page.locator('#expandPlayer').click()
  expect(page.locator('#playerArtwork img')).to_be_visible()
  result['with_cover']=True
  before=page.locator('#audio').evaluate('(a)=>a.currentTime')
  page.locator('#audioSeek').evaluate('(s)=>{for(let i=0;i<100;i++){s.value=Number(s.max)*i/100;s.dispatchEvent(new Event("input",{bubbles:true}));}}')
  assert abs(page.locator('#audio').evaluate('(a)=>a.currentTime')-before)<.05
  seek_times=[]
  for fraction in [.75,.25,.95]:
   target=duration*fraction;started=time.monotonic()
   page.locator('#audioSeek').fill(str(round(target,1)))
   wait_js('!document.querySelector("#audio").seeking && Math.abs(document.querySelector("#audio").currentTime-'+str(target)+')<1')
   seek_times.append(round(time.monotonic()-started,3))
  result['seek_seconds']=seek_times
  page.locator('#bookmarkPanel > summary').click()
  page.locator('#bookmarkLabel').fill('Trecho após três horas')
  page.locator('#bookmarkForm button').click()
  expect(page.locator('[data-bookmark-jump]')).to_have_count(1)
  bookmark_time=page.locator('#audio').evaluate('(a)=>a.currentTime')
  assert bookmark_time>3*3600
  page.locator('#audio').evaluate('(a)=>a.currentTime=60')
  started=time.monotonic();page.locator('[data-bookmark-jump]').click()
  wait_js('!document.querySelector("#audio").seeking && document.querySelector("#audio").currentTime>10800')
  result['bookmark_jump_seconds']=round(time.monotonic()-started,3)
  page.screenshot(path=str(OUT/'v16-audio-grande-mobile.png'))
  result['max_ui_gap_ms']=round(page.evaluate('Math.max(...window.uiGaps)'),2)
  result['js_heap_mb']=round(page.evaluate('performance.memory?.usedJSHeapSize??0')/1048576,2)
  assert result['max_ui_gap_ms']<1000,result
  assert max(seek_times)<10,result
  page.reload();page.get_by_role('button',name='Ouvir',exact=True).click()
  wait_js('document.querySelector("#audio").currentTime>10800')
  page.locator('#audio').evaluate('(a)=>a.pause()')
  page.locator('#expandPlayer').click();page.locator('#bookmarkPanel > summary').click()
  expect(page.locator('[data-bookmark-jump]')).to_have_count(1)
  page.locator('#closePlayer').click()
  page.get_by_role('button',name='Check-in',exact=True).click()
  page.locator('[name=dayNote]').fill('A interface continua respondendo após o áudio longo.')
  expect(page.locator('[data-draft-status]')).to_have_text('Rascunho salvo neste aparelho.')
  assert not result['errors'],result['errors']
  result['passed']=True
 finally:
  browser.close()
  (OUT/'large-audio-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(result,ensure_ascii=False),flush=True)
