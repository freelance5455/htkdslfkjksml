"""Render proposal 1 only in an isolated browser; never modify application assets."""
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
import base64, json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'previews';OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:18767'
CSS='''
.hero{padding:20px}.hero-summary{display:flex;align-items:center;gap:20px;margin:12px 0}
.hero .number{font-size:64px;letter-spacing:-3px;margin:0;flex-shrink:0}
.hero .unit{font-size:18px;margin-left:6px}.hero .lead{font-size:15px;line-height:1.55;margin:0;max-width:175px}
.hero progress{margin:4px 0 8px}.hero .border-top{margin-top:12px;padding-top:12px}
.preview-risk{padding:18px 20px}.preview-risk h2{margin-bottom:4px}.preview-risk p{margin:0 0 8px}
.preview-risk .risk-button{margin:0}.heading{margin-bottom:20px}
'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  name=urlparse(route.request.url).path.lstrip('/') or 'index.html'
  if name=='item1-proposal.css':route.fulfill(body=CSS,content_type='text/css');return
  f=ROOT/name
  if f.is_file() and f.parent==ROOT:route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else:route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page();page.goto(URL)
 page.locator('[data-action=finishReflection]').click()
 page.evaluate("""async()=>{const db=await import('./db.js'),D=await import('./domain.js'),s=await db.get('settings','main');s.startDate=D.addDays(D.today(),-21);s.bestEver=21;await db.put('settings',s);}""")
 page.reload();page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
 page.screenshot(path=str(OUT/'home-atual.png'))
 page.evaluate("""()=>{const hero=document.querySelector('.hero'),summary=document.createElement('div');summary.className='hero-summary';hero.querySelector('.number').before(summary);summary.append(hero.querySelector('.number'),hero.querySelector('.lead'));const risk=document.querySelector('[data-action=risk]').closest('.card');risk.classList.add('preview-risk');risk.parentElement.prepend(risk);const link=document.createElement('link');link.rel='stylesheet';link.href='/item1-proposal.css';document.head.append(link);}""")
 page.locator('.hero-summary').wait_for();page.wait_for_timeout(200)
 page.screenshot(path=str(OUT/'home-proposta-1.png'))
 html='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SafeHarbor — proposta 1</title><style>*{box-sizing:border-box}body{margin:0;background:#111;color:#eee;font-family:system-ui,sans-serif;padding:28px}h1{font-size:24px;margin:0 0 8px}p{color:#aaa;margin:0 0 22px;line-height:1.6}main{display:flex;gap:24px;justify-content:center;align-items:flex-start}.option{max-width:393px;min-width:0;flex:1}h2{font-size:16px;margin:0 0 8px}.option small{display:block;color:#bbb;margin-bottom:12px}img{width:100%;border:1px solid #383838;border-radius:18px}.proposed h2{color:#fca5a5}@media(max-width:600px){body{padding:16px}main{flex-direction:column;align-items:center}.option{width:100%}}</style><h1>Mesma identidade, acesso à pausa mais acima</h1><p>Prévia do item 1 · não aplicada ao app.<br>Dados demonstrativos, após a leitura da reflexão inicial do dia.</p><main><section class="option"><h2>Atual · com os ajustes aprovados</h2><small>Sequência → check-in → pausa</small><img src="home-atual.png" alt="Home atual: cartão de sequência alto seguido do check-in"></section><section class="option proposed"><h2>Proposta 1 · para você decidir</h2><small>Sequência compacta → pausa → check-in</small><img src="home-proposta-1.png" alt="Proposta: sequência compacta e acesso à pausa visível antes do check-in"></section></main></html>'''
 (OUT/'item1-comparacao.html').write_text(html,encoding='utf-8')
 for name in ['home-atual.png','home-proposta-1.png']:
  html=html.replace('src="'+name+'"','src="data:image/png;base64,'+base64.b64encode((OUT/name).read_bytes()).decode()+'"')
 comparison=browser.new_page(viewport={'width':900,'height':1060},device_scale_factor=1)
 comparison.set_content(html);comparison.screenshot(path=str(OUT/'item1-comparacao.png'),full_page=True)
 browser.close()
print(OUT/'item1-comparacao.png')
