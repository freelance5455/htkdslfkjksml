from pathlib import Path
from urllib.parse import urlparse
import json, sys, base64, tempfile, wave
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'; URL='http://127.0.0.1:18781'
results=[]; errors=[]
def passed(message):
 results.append(message); print('OK:',message,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:
   route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else: route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page(); page.on('pageerror',lambda e:errors.append(str(e)))
 try:
  for version in [1,3]:
   ctx=browser.new_context();ctx.route(URL+'/**',asset)
   old=ctx.new_page();old.route(URL+'/seed',lambda r:r.fulfill(body='<html><title>Teste</title></html>',content_type='text/html'));old.goto(URL+'/seed')
   result=old.evaluate("""async version=>{
    const stores=['settings','records','reports','quoteHistory','events','trophies','challenges','audio','audioMeta','staging',...(version===3?['revisions','favorites']:[])];
    await new Promise((resolve,reject)=>{const q=indexedDB.open('SafeHarbor',version);q.onupgradeneeded=()=>{for(const name of stores)q.result.createObjectStore(name,{keyPath:'id'})};q.onsuccess=()=>{const d=q.result,t=d.transaction(stores,'readwrite');for(const name of stores)t.objectStore(name).put(name==='audio'?{id:'legacy',blob:new Blob(['original audio']),custom:'preservar'}:{id:'legacy',value:name,custom:{text:'histórico original',n:42}});t.oncomplete=()=>{d.close();resolve()};t.onerror=()=>reject(t.error)}});
    const db=await import('./db.js');await db.openDB();const rows={};for(const name of stores){const row=await db.get(name,'legacy');rows[name]=name==='audio'?{text:await row.blob.text(),custom:row.custom}:row;}
    return {version:db.DB_VERSION,stores:db.STORES,rows,newCounts:await Promise.all(['blockedApps','blockAttempts','privacy'].map(async n=>(await db.all(n)).length))};
   }""",version)
   assert result['version']==4 and result['newCounts']==[0,0,0]
   for store,row in result['rows'].items():
    assert row==({'text':'original audio','custom':'preservar'} if store=='audio' else {'id':'legacy','value':store,'custom':{'text':'histórico original','n':42}}),(version,store,row)
   ctx.close()
  passed('Migrações reais v1→v4 e v3→v4: todos os objetos e campos legados preservados, inclusive Blob de áudio; apenas três stores novas e vazias.')
  page.goto(URL);page.locator('[data-action=finishReflection]').click()
  result=page.evaluate("""async()=>{
   const db=await import('./db.js'),b=await import('./backup.js'),D=await import('./domain.js');
   const credential={id:'main',enabled:true,hash:'a'.repeat(64),salt:'b'.repeat(32)};await db.put('privacy',credential);
   const app={id:'backup-app',name:'Aplicativo de teste',custom:true,nightEnabled:false,nightStart:'23:00',nightEnd:'06:00',lockUntil:0,nightBypassUntil:0};await db.put('blockedApps',app);
   const stamp=Date.now();await db.put('blockAttempts',{id:'old-attempt',appId:app.id,status:'cancelled',startedAt:stamp-200000,readyAt:stamp-80000});
   await db.put('events',{id:'block-resisted:old-attempt',kind:'impulse',date:D.today(),source:'app-blocker'});
   window.text='';window.showSaveFilePicker=async()=>({createWritable:async()=>({write:async s=>window.text+=s,close:async()=>{},abort:async()=>{}})});
   await b.exportBackup(()=>{});const backup=window.text,parsed=JSON.parse(backup);
   if(parsed.items.some(r=>r.store==='privacy'))throw Error('Credencial exportada');
   const until=Date.now()+3600000;await db.put('blockedApps',{...app,lockUntil:until});
   await b.importBackup(new File([backup],'plain.json'),()=>{});
   await b.importBackup(new File([backup],'plain.json'),()=>{});
   return {pin:await db.get('privacy','main'),until:(await db.get('blockedApps',app.id)).lockUntil,expected:until,eventCount:(await db.all('events')).filter(e=>e.id==='block-resisted:old-attempt').length,attempt:await db.get('blockAttempts','old-attempt'),containsApps:parsed.items.some(r=>r.store==='blockedApps')};
  }""")
  assert result['pin']=={'id':'main','enabled':True,'hash':'a'*64,'salt':'b'*32}
  assert result['until']==result['expected'] and result['eventCount']==1 and result['containsApps']
  assert result['attempt']['status']=='cancelled'
  passed('Backup inclui compromissos e tentativas, exclui o PIN, não desativa compromisso ativo e não duplica vitória ao restaurar duas vezes.')
  assert not errors,errors
 finally:
  browser.close()
  (OUT/'v171-data-results.json').write_text(json.dumps({'passed':results,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8')
