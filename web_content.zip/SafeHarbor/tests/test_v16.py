from pathlib import Path
from urllib.parse import urlparse
import json, os, tempfile, wave, sys, time
from playwright.sync_api import sync_playwright, expect

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests'
URL='http://127.0.0.1:18766'
results=[];errors=[];external=[]
def passed(text):results.append(text);print('OK:',text,flush=True)
def wait_js(expr):
 for _ in range(200):
  if page.evaluate('() => '+expr):return
  time.sleep(.05)
 raise AssertionError(expr)

with sync_playwright() as p, tempfile.TemporaryDirectory(prefix='safeharbor-v16-') as temp:
 browser=p.chromium.launch(executable_path=os.environ.get('SAFEHARBOR_BROWSER',r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'),headless=True)
 context=browser.new_context(viewport={'width':393,'height':852},locale='pt-BR',timezone_id='America/Fortaleza')
 def asset(route):
  f=ROOT/(urlparse(route.request.url).path.lstrip('/') or 'index.html')
  if f.is_file() and f.parent==ROOT:route.fulfill(body=f.read_bytes(),content_type={'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(f.suffix,'text/html'))
  else:route.abort()
 context.route(URL+'/**',asset)
 page=context.new_page()
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:external.append(r.url) if not r.url.startswith((URL,'blob:','data:')) else None)
 try:
  page.goto(URL)
  page.locator('[data-action=finishReflection]').click()
  assert page.locator('#nav button').count()==5
  expect(page.locator('header [data-route=ajustes]')).to_be_visible()
  home=page.locator('.home-quote blockquote').inner_text()
  page.locator('.home-quote [data-action=favorite]').click()
  expect(page.locator('.home-quote [data-action=favorite]')).to_have_attribute('aria-pressed','true')
  history=page.evaluate("async()=> (await import('./db.js')).all('quoteHistory')")
  page.locator('[data-action=favorites]').click()
  expect(page.locator('#modal blockquote')).to_have_text(home)
  page.locator('#modal [data-action=closeModal]').click()
  assert page.evaluate("async()=> (await import('./db.js')).all('quoteHistory')")==history
  page.reload()
  expect(page.locator('.home-quote [data-action=favorite]')).to_have_attribute('aria-pressed','true')
  page.locator('[data-action=risk]').click()
  page.locator('#modal [data-action=favorite]').click()
  expect(page.locator('#modal [data-action=favorite]')).to_have_attribute('aria-pressed','true')
  page.locator('#modal [data-action=closeModal]').click()
  page.get_by_text('Pausa registrada. +1 impulso superado.',exact=True).wait_for()
  passed('Cinco abas, Ajustes no cabeçalho e favoritas persistentes sem alterar o sorteio; favoritar funciona na reflexão da pausa.')

  page.get_by_role('button',name='Check-in',exact=True).click()
  page.locator('[name=dayNote]').fill('Rascunho — primeira ideia antes de sair.')
  page.locator('[name=mood]').fill('4')
  page.get_by_role('button',name='Áudios',exact=True).click()
  page.get_by_role('button',name='Check-in',exact=True).click()
  expect(page.locator('[name=dayNote]')).to_have_value('Rascunho — primeira ideia antes de sair.')
  expect(page.locator('[name=mood]')).to_have_value('4')
  page.reload()
  expect(page.locator('[name=dayNote]')).to_have_value('Rascunho — primeira ideia antes de sair.')
  page.get_by_role('button',name='Salvar fechamento do dia').click()
  page.get_by_role('heading',name='Um dia de cada vez.').wait_for()
  page.get_by_role('button',name='Check-in',exact=True).click()
  expect(page.locator('[name=dayNote]')).to_have_value('')
  page.locator('[name=dayNote]').fill('Descartar só este texto')
  page.locator('[data-action=discardDraft]').click()
  expect(page.locator('[name=dayNote]')).to_have_value('')
  assert page.evaluate("async()=> (await (await import('./db.js')).all('records'))[0].dayNote")=='Rascunho — primeira ideia antes de sair.'
  passed('Rascunho recupera texto e avaliações após navegação/reabertura; salvar limpa o rascunho; descartar preserva registros.')

  audio_file=Path(temp)/'audio.wav'
  with wave.open(str(audio_file),'wb') as w:
   w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(b'\0\0'*16000*30)
  page.get_by_role('button',name='Áudios',exact=True).click()
  assert not page.locator('.library-add').evaluate('(e)=>e.open')
  page.locator('.library-add > summary').click()
  page.locator('[name=audioFile]').set_input_files(str(audio_file))
  page.get_by_role('button',name='Salvar na biblioteca').click()
  page.get_by_role('button',name='Ouvir',exact=True).click()
  wait_js('document.querySelector("#audio").readyState>=2')
  expect(page.locator('#speeds')).not_to_be_visible()
  assert page.locator('#player').bounding_box()['height']<180
  page.locator('#expandPlayer').click()
  expect(page.locator('#speeds')).to_be_visible()
  page.locator('#audio').evaluate('(a)=>{a.pause();a.currentTime=8;}')
  page.locator('#bookmarkPanel > summary').click()
  page.locator('#bookmarkLabel').fill('Uma ideia importante')
  page.locator('#bookmarkForm button').click()
  expect(page.locator('[data-bookmark-jump]')).to_have_count(1)
  page.locator('#audio').evaluate('(a)=>a.currentTime=1')
  page.locator('[data-bookmark-jump]').click()
  wait_js('document.querySelector("#audio").currentTime>=8')
  page.screenshot(path=str(OUT/'v16-player-mobile.png'))
  page.reload()
  page.get_by_role('button',name='Ouvir',exact=True).click()
  page.locator('#expandPlayer').click()
  page.locator('#bookmarkPanel > summary').click()
  expect(page.locator('[data-bookmark-jump]')).to_have_count(1)
  page.get_by_text('Temporizador',exact=True).click()
  page.clock.install()
  page.locator('#sleepMinutes').fill('1')
  page.locator('#sleepForm button').click()
  page.clock.fast_forward(61000)
  expect(page.locator('#sleepStatus')).to_have_text('Temporizador desligado.')
  assert page.locator('#audio').evaluate('(a)=>a.paused')
  page.clock.resume()
  page.locator('#sleepEnd').click()
  page.locator('#audio').evaluate('(a)=>{a.currentTime=29.9;a.play();}')
  wait_js('document.querySelector("#audio").ended')
  expect(page.locator('#sleepStatus')).to_have_text('Temporizador desligado.')
  page.locator('#closePlayer').click()
  page.evaluate(r"""async()=>{const d=await import('./db.js'),first=(await d.all('audioMeta'))[0],blob=(await d.get('audio',first.id)).blob;await d.put('audioMeta',{...first,bookId:'timer-book',bookTitle:'Teste do temporizador',relativePath:'01.wav'});await d.put('audioMeta',{id:'timer-next',title:'Próximo capítulo',fileName:'02.wav',relativePath:'02.wav',bookId:'timer-book',bookTitle:'Teste do temporizador',position:0,speed:1,completed:false,createdAt:Date.now()});await d.put('audio',{id:'timer-next',blob});}""")
  page.reload()
  page.get_by_role('button',name='Ouvir novamente',exact=True).click()
  page.locator('#expandPlayer').click()
  page.get_by_text('Temporizador',exact=True).click()
  page.locator('#sleepEnd').click()
  page.locator('#audio').evaluate('(a)=>{a.currentTime=29.9;a.play();}')
  wait_js('document.querySelector("#audio").ended')
  expect(page.locator('#sleepStatus')).to_have_text('Temporizador desligado.')
  assert page.locator('#playingTitle').inner_text()=='audio'
  assert page.evaluate("async()=> (await (await import('./db.js')).get('audioMeta','timer-next')).position")==0
  page.locator('#closePlayer').click()
  page.evaluate(r"""async()=>{const d=await import('./db.js');await d.remove('audioMeta','timer-next');await d.remove('audio','timer-next');const first=(await d.all('audioMeta'))[0];delete first.bookId;delete first.bookTitle;delete first.relativePath;await d.put('audioMeta',first);}""")
  page.reload()
  passed('Player compacto, marcadores persistentes e salto ao trecho; temporizador por minutos e fim do áudio pausam a reprodução.')

  page.get_by_role('button',name='Ajustes',exact=True).click()
  page.evaluate("window.showSaveFilePicker=async()=>({createWritable:async()=>({write:async s=>{window.savedBackup=(window.savedBackup??'')+s},close:async()=>{},abort:async()=>{window.aborted=true}})})")
  page.locator('[name=includeAudio]').uncheck()
  page.locator('[name=encryptBackup]').check()
  page.locator('[name=exportPassword]').fill('senha de teste 123')
  page.locator('[name=confirmPassword]').fill('senha de teste 123')
  page.locator('[data-action=export]').click()
  page.get_by_text('Backup salvo no local escolhido.',exact=True).wait_for()
  protected=page.evaluate('window.savedBackup')
  assert 'Rascunho' not in protected and 'primeira ideia' not in protected
  assert json.loads(protected)['format']=='SafeHarbor/Encrypted/1'
  expect(page.locator('[name=exportPassword]')).to_have_value('')
  encrypted_file=Path(temp)/'protected.json';encrypted_file.write_text(protected,encoding='utf-8')
  audio_count=page.evaluate("async()=> (await (await import('./db.js')).all('audioMeta')).length")
  page.evaluate("async()=>{const d=await import('./db.js');await d.transaction(['records','favorites'],tx=>{tx.objectStore('records').clear();tx.objectStore('favorites').clear();});}")
  page.locator('[name=backup]').set_input_files(str(encrypted_file))
  page.locator('[name=backupPassword]').fill('senha errada')
  page.locator('[name=agree]').check()
  page.get_by_role('button',name='Verificar e restaurar backup').click()
  page.get_by_text('Senha incorreta ou backup protegido alterado. Nenhum dado foi restaurado.',exact=True).wait_for()
  assert page.evaluate("async()=> (await (await import('./db.js')).all('records')).length")==0
  page.locator('[name=backupPassword]').fill('senha de teste 123')
  page.get_by_role('button',name='Verificar e restaurar backup').click()
  page.get_by_text('Backup validado e restaurado.',exact=True).wait_for()
  state=page.evaluate("async()=>{const d=await import('./db.js');return {records:(await d.all('records')).length,favorites:(await d.all('favorites')).length,audio:(await d.all('audioMeta')).length,stage:(await d.all('staging')).length};}")
  assert state=={'records':1,'favorites':2,'audio':audio_count,'stage':0},state
  passed('Backup com senha sem áudios restaura histórico/favoritas e preserva biblioteca existente; senha errada não altera dados.')

  integrity=page.evaluate(r"""async text=>{
   const b=await import('./backup.js'),d=await import('./db.js'),password='senha de teste 123',source=JSON.parse(text);
   const variants=[text.slice(0,-15)];
   const rows=text.split('\n');[rows[1],rows[2]]=[rows[2],rows[1]];variants.push(rows.join('\n'));
   const altered=text.split('\n'),row=JSON.parse(altered[1].slice(0,-1));row.data=(row.data[0]==='A'?'B':'A')+row.data.slice(1);altered[1]=JSON.stringify(row)+',';variants.push(altered.join('\n'));
   let rejected=0;for(const text of variants){try{await b.importBackup(new File([text],'invalid.json'),()=>{},{password});}catch{rejected++;}if((await d.all('staging')).length)throw Error('Staging não limpa');}
   return {rejected,records:(await d.all('records')).length};
  }""",protected)
  assert integrity=={'rejected':3,'records':1},integrity
  passed('Backups protegidos truncados, alterados ou com blocos reordenados são rejeitados antes da restauração.')

  full=page.evaluate(r"""async()=>{window.savedBackup='';await (await import('./backup.js')).exportBackup(()=>{},{password:'senha de teste 123'});return window.savedBackup;}""")
  page.evaluate(r"""async text=>{const d=await import('./db.js'),b=await import('./backup.js');await d.transaction(['audio','audioMeta'],tx=>{tx.objectStore('audio').clear();tx.objectStore('audioMeta').clear();});await b.importBackup(new File([text],'full.json'),()=>{},{password:'senha de teste 123'});} """,full)
  restored=page.evaluate("async()=>{const d=await import('./db.js');return {size:(await d.all('audio'))[0].blob.size,marks:(await d.all('audioMeta'))[0].bookmarks.length};}")
  assert restored=={'size':audio_file.stat().st_size,'marks':1},restored
  legacy=page.evaluate(r"""async()=>{window.savedBackup='';await (await import('./backup.js')).exportBackup(()=>{},{includeAudio:false});const lines=window.savedBackup.split('\n').filter(s=>!s.includes('"store":"favorites"'));lines[0]='{"format":"SafeHarbor/1","items":[';const end=JSON.parse(lines.at(-2));end.count=lines.length-3;lines[lines.length-2]=JSON.stringify(end);await (await import('./backup.js')).importBackup(new File([lines.join('\n')],'legacy.json'),()=>{});return true;}""")
  assert legacy
  passed('Backup protegido completo restaura o Blob e marcadores; backups antigos SafeHarbor/1 continuam aceitos.')

  for width,height in [(320,740),(393,852),(768,1024),(1280,800),(852,393)]:
   page.set_viewport_size({'width':width,'height':height})
   for route in ['inicio','registro','progresso','conquistas','audios','ajustes']:
    page.goto(URL+'/#'+route)
    page.locator('#nav button').first.wait_for()
    wait_js("document.querySelector('h1')!==null")
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,height,route)
   page.goto(URL+'/#audios')
   page.get_by_role('button',name='Ouvir novamente',exact=True).click()
   page.locator('#expandPlayer').click()
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),('player',width,height)
   assert page.locator('#player').evaluate('(e)=>e.scrollWidth<=e.clientWidth'),('player overflow',width,height)
   page.locator('#closePlayer').click()
  page.set_viewport_size({'width':393,'height':852})
  page.goto(URL+'/#audios')
  page.get_by_role('heading',name='Um tempo para ouvir').wait_for()
  page.screenshot(path=str(OUT/'v16-biblioteca-mobile.png'),full_page=True)
  page.goto(URL+'/#ajustes')
  page.get_by_role('heading',name='Configurações').wait_for()
  page.locator('[name=encryptBackup]').check()
  page.screenshot(path=str(OUT/'v16-ajustes-mobile.png'),full_page=True)
  passed('Todas as telas e player sem rolagem horizontal em 320, 393, 768, 1280 px e celular em paisagem.')
  assert not errors,errors
  assert not external,external
 except Exception:
  page.screenshot(path=str(OUT/'v16-falha.png'),full_page=True)
  print('PAGE ERRORS',errors,'LAST TOAST',page.locator('#toast').text_content(),flush=True)
  raise
 finally:
  browser.close()
  (OUT/'v16-results.json').write_text(json.dumps({'passed':results,'errors':errors,'external_requests':external},ensure_ascii=False,indent=2),encoding='utf-8')
