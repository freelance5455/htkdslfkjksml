# Validação do SafeHarbor 1.7.2

Executada em 9 de novembro de 2026, no Windows, usando Node 24 e Edge real via Playwright. Todos os testes de interface utilizaram perfis isolados, dados fictícios e assets locais. Nenhum perfil pessoal ou dado do aplicativo instalado no celular foi acessado.

## Resultado

O teste de regressão reproduziu o defeito antes da mudança (`3 !== 2` ao confirmar a melhor sequência antes do check-in). Depois da correção, a execução Node concluiu 24 testes sem falhas, incluindo os 15 marcos, datas civis e resultados de desafios. A saída integral está em [v172-node-tests.txt](v172-node-tests.txt).

Todos os módulos JavaScript passaram por verificação sintática. Manifestos JSON e XML válidos; container Android continua sem permissões de rede.

| Suíte executada nesta atualização | Resultado | Evidência |
| --- | --- | --- |
| Regras e correções 1.7.2 | 10 cenários aprovados | [v172-results.json](v172-results.json) |
| Regressão geral de interface | 20 cenários aprovados | [browser-results.json](browser-results.json) |
| Compatibilidade da 1.7.1 e seis seções | 3 cenários aprovados | [v171-results.json](v171-results.json) |
| Migração e restauração legadas | 2 cenários aprovados | [v171-data-results.json](v171-data-results.json) |
| Artes de marcos e seletor de backup | 3 cenários aprovados | [v163-art-results.json](v163-art-results.json) |
| Capas, áudio e backup protegido | 3 cenários aprovados | [v165-results.json](v165-results.json) |

## Verificações principais

- Terceiro dia sem check-in: contador 3, melhor sequência confirmada 2, patente Soldado e marco 3 bloqueado.
- Recaída no terceiro dia: contador zero, marco 3 bloqueado inclusive após reabrir. Histórico de revisões, registros anteriores, áudio, posição e impulsos preservados.
- Alterações no mesmo dia: bem gerido → recaída → resistido → deslize; marcos, patentes e troféus acompanham o fechamento vigente, sem duplicações.
- Marco legítimo de sequência anterior preservado, mesmo com recaída atual; máximo antigo inflado descartado como fonte de conquistas.
- Edição retroativa atualiza relatório, resultado do desafio e troféu, mantendo data de criação e estado lido do relatório.
- Restauração pela interface, duas vezes, corrige máximo e troféu inconsistentes, preservando dados e data inicial bloqueada.
- Erro de cota simulado durante a transação não salva parcialmente registro, revisão ou conquista; tentativa posterior com clique duplo salva uma única revisão.
- Avanço do relógio até sete dias aumenta o contador, mas aguarda um novo check-in para confirmar marco 7 e patente General.
- Status inválido no backup é rejeitado sem alterar dados; área temporária limpa.
- Correção de registro cancela oferta ainda não aceita; nova condição elegível reapresenta a mesma oferta, sem duplicá-la. Aceite define o dia seguinte.
- Regresões de reflexão, calendário, gráficos, áudio, capítulos, exclusão, backup simples e protegido, migrações v1/v3 para v4 e atualização futura v4 para v5 passaram.
- Conquistas inspecionadas visualmente, com marco 3 bloqueado após recaída. As seis seções foram verificadas em larguras de 320 a 1280 px e paisagem.

Os testes antigos de arte agora usam registros reais para sustentar os marcos esperados, em vez de injetar apenas um máximo sem histórico. O teste geral também deixou de exigir a preservação do marco do próprio dia corrigido para recaída.

## Limites e entrega

Validação de aplicação web offline e armazenamento IndexedDB. Não houve compilação, assinatura, instalação ou teste do APK em Android. Nenhum novo ensaio com áudio de 1 GB foi necessário nesta correção. A atualização instalada deve manter pacote, assinatura e origem local; os ZIPs fornecem os arquivos para gerar essa atualização.

Os pacotes são verificados por integridade ZIP e comparação byte a byte com os arquivos locais. O pacote completo contém `SHA256SUMS.json`; o pacote web também inclui seu próprio manifesto SHA-256. As somas das entregas estão em `entrega/SHA256SUMS-1.7.2.json`.
