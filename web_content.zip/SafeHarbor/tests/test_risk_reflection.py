"""Exercise the risk-button reflection using isolated, synthetic browser data."""
from pathlib import Path
from urllib.parse import urlparse
import json
import os
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'tests'
URL = 'http://127.0.0.1:18765'
errors = []
external = []
passed = []

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get(
        'SAFEHARBOR_BROWSER', r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'), headless=True)
    context = browser.new_context(viewport={'width':393,'height':852}, locale='pt-BR', timezone_id='America/Fortaleza')
    def asset(route):
        file = ROOT / (urlparse(route.request.url).path.lstrip('/') or 'index.html')
        if file.is_file() and file.parent == ROOT:
            kind = {'.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'}.get(file.suffix,'text/html')
            route.fulfill(body=file.read_bytes(),content_type=kind)
        else:
            route.abort()
    context.route(URL+'/**',asset)
    page = context.new_page()
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:external.append(r.url) if not r.url.startswith((URL,'blob:','data:')) else None)
    page.goto(URL)
    expect(page.locator('.home-quote blockquote')).to_be_visible()
    page.locator('[data-action=finishReflection]').click()
    home_quote = page.locator('.home-quote blockquote').inner_text()
    modal = page.locator('#modal')
    risk_button = page.locator('[data-action=risk]')
    def history():
        return page.evaluate("async()=> (await import('./db.js')).all('quoteHistory')")
    def proceed():
        modal.locator('[data-action=closeModal]').click()
        expect(page.get_by_text('Pausa registrada. +1 impulso superado.',exact=True)).to_be_visible()
        expect(modal).not_to_be_visible()

    risk_button.click()
    expect(modal).to_be_visible()
    first_quote = modal.locator('blockquote').inner_text().strip('“”')
    assert first_quote != home_quote
    assert page.locator('#riskForm').count() == 0
    assert len(history()) == 2
    page.keyboard.press('Escape')
    expect(modal).to_be_visible()
    page.screenshot(path=str(OUT/'risco-reflexao-mobile.png'))
    proceed()
    assert page.locator('.home-quote blockquote').inner_text() == home_quote
    passed.append('Reflexão antes da pausa; Continuar registra sem perguntas; Home preservada; Esc não pula a leitura.')

    # Two immediate events must consume just one new reflection.
    risk_button.evaluate('(b)=>{b.click();b.click();}')
    expect(modal).to_be_visible()
    assert len(history()) == 3
    second_quote = modal.locator('blockquote').inner_text().strip('“”')
    assert second_quote not in (home_quote,first_quote)
    proceed()
    assert len(page.evaluate("async()=> (await import('./db.js')).all('events')")) == 2
    passed.append('Nova entrada não repete frases; clique duplo consome só uma; conclusão registra um impulso.')

    page.reload()
    expect(page.locator('.home-quote blockquote')).to_be_visible()
    risk_button.click()
    expect(modal).to_be_visible()
    assert modal.locator('blockquote').inner_text().strip('“”') not in (home_quote,first_quote,second_quote)
    assert len(history()) == 4
    proceed()
    passed.append('Histórico sem repetição persiste após recarregar o app.')

    page.evaluate("""async()=>{const db=await import('./db.js'),{quotes}=await import('./quotes.js');await db.transaction(['quoteHistory'],tx=>{for(const q of quotes)tx.objectStore('quoteHistory').put({id:q.id,at:Date.now()});});}""")
    risk_button.click()
    expect(page.get_by_text('Pausa registrada. +1 impulso superado.',exact=True)).to_be_visible()
    expect(modal).not_to_be_visible()
    passed.append('Catálogo esgotado abre a registro diretamente, sem repetir frases nem bloquear o acesso.')

    eligible = page.evaluate("""async()=>{const db=await import('./db.js'),{quotes}=await import('./quotes.js'),s=await db.get('settings','main'),q=quotes.find(q=>q.id!==s.homeQuote.id);await db.put('quoteHistory',{id:q.id,at:Date.now()-46*86400000});return q;}""")
    risk_button.click()
    expect(modal).to_be_visible()
    assert modal.locator('blockquote').inner_text().strip('“”') == eligible['text']
    proceed()
    passed.append('Reflexão volta a ficar elegível após 45 dias.')
    browser.close()

assert not errors, errors
assert not external, external
(OUT/'risk-reflection-results.json').write_text(json.dumps({'passed':passed,'errors':errors,'external_requests':external},ensure_ascii=False,indent=2),encoding='utf-8')
for message in passed:
    print('OK:',message)
