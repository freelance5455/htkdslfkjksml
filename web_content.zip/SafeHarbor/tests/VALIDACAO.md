# Validação do SafeHarbor

**Validação atual da versão 1.7.2:** consulte [VALIDACAO-1.7.2.md](VALIDACAO-1.7.2.md). As seções abaixo documentam as versões anteriores; regras de permanência de conquistas foram substituídas pela revalidação do último fechamento.

Executada em 7 de novembro de 2026, em Windows, com Python portátil, Pillow, Node fornecido pelo Playwright e Microsoft Edge em perfil temporário, sem dados pessoais.

## Resultados concluídos

- Todos os módulos JavaScript passaram por `node --check`.
- 14 verificações de regras de negócio passaram em `domain.test.js`.
- Manifestos JSON e XML válidos; ícone PNG confirmado em 512 × 512 pixels.
- Manifesto Android sem permissões de rede; arquivos de execução sem CDN ou importação remota.
- Inspeção visual das capturas móveis incluídas. As capturas mostram dados artificiais do teste, não dados pré-carregados no app.

- 150 reflexões distintas; abertura no topo, deslocamento automático após leitura e botão para continuar.
- Inicialização em pt-BR, armazenamento e layout móvel sem rolagem horizontal.
- Data inicial salva uma vez e bloqueio preservado após recarregar.
- Reflexão visível na Home; opções locais sem menu nativo; relato opcional, versões salvas e somente último registro vigente.
- Edição do check-in não duplica impulsos; citações distintas e bloqueio de Esc.
- Recaída salva sem revisão obrigatória; apenas Sobre seu dia não obrigatório; alto risco e TCC funcionam.
- Recaída zera marcos ativos, preservando conquistas anteriores.
- Relatório lido sai definitivamente da Home e fica no calendário; quatro gráficos acessíveis.
- Arquivo de áudio em Blob, título automático, player entre abas, posição e velocidade após reabrir.
- Exportação JSON válida com áudio em múltiplos blocos; restauração completa e limpeza da área temporária.
- Backup truncado é rejeitado sem modificar o histórico existente.
- Desafio vencido concede um único troféu persistente, sem duplicar ao reiniciar.
- Modo offline do navegador com assets locais: inicialização completa e zero solicitações externas.
- Migração futura IndexedDB v2 → v3 adiciona store sem perder registros, áudio ou troféus.
- Atualização real v1 → v2 preserva registro legado, converte horário em período e arquiva a versão anterior ao editar.
- Pasta importa apenas áudios em ordem alfabética; conclusão visual persiste e reprodução avança ao próximo capítulo.
- Exclusão individual, de selecionados e do livro remove cópias e metadados; originais preservados.
- Player sem controles nativos duplicados, ícones acessíveis e título centralizado; avulsos recentes primeiro após reabrir.
- Reflexão apenas na recaída e diferente da Home; calendário somente leitura; marco de 1 dia e seletores vermelhos arredondados.
- Nenhum erro JavaScript não tratado em todos os fluxos exercitados.

## Escopo e limites da validação

O navegador recebeu os assets diretamente do disco por interceptação de requisições, inclusive com `offline=True`; nenhum pedido externo foi observado. Isso verifica a aplicação web offline, mas não substitui o teste da WebView em um Android real. A importação por pasta foi exercitada no navegador; a ponte Android ACTION_OPEN_DOCUMENT_TREE ainda não foi compilada ou testada em aparelho. O temporizador de reflexão foi exercitado com o relógio controlado do Playwright.

A interface de gravação de arquivos foi simulada no teste de navegador; o JSON gerado foi analisado e restaurado de verdade. O áudio de teste tinha 640.044 bytes e gerou três blocos. Não foi realizado ensaio com áudio de 1 GB, cota esgotada, falta de energia ou processo encerrado abruptamente. O seletor SAF e a ponte Java de exportação ainda precisam de teste em dispositivo.

Não havia SDK Android/JDK preparados neste ambiente: **o APK não foi compilado, assinado ou instalado nesta sessão**. O pacote contém todo o código do container e script de compilação offline, sem trechos pendentes. Antes de usar com dados importantes, compile e teste no aparelho: modo avião, reinício, seleção de áudio grande, exportação, restauração, botão Voltar e atualização sobre a versão anterior preservando assinatura/origem.

Durante os testes, foi corrigida uma renderização duplicada por `hashchange` que podia substituir um formulário durante a digitação. Também foi evitada a reconstrução dos formulários ao retornar do seletor de arquivos. O teste final passou após essas correções. Um teste anterior sofreu injeção do antivírus do computador na página HTTP; a execução final usou assets interceptados diretamente do disco, sem alterar o antivírus ou reduzir a CSP do app.

## Repetir os testes de navegador

Instale Python, Pillow e Playwright em um ambiente de desenvolvimento. `test_browser.py` usa Edge no caminho padrão do Windows ou o executável indicado pela variável `SAFEHARBOR_BROWSER`. Execute `python tests/test_browser.py`. Os testes usam um perfil isolado e dados fictícios; não acessam o perfil habitual do navegador. Nenhuma dessas ferramentas é dependência do APK.

O gerador `tests/gerar_projeto.py` recria os arquivos do projeto usando Python/Pillow. Executá-lo sobre uma cópia modificada substituirá os arquivos gerados; mantenha suas alterações em outra cópia antes de regenerar.


## Atualização 1.5.1 — reflexão antes da pausa

O teste `test_risk_reflection.py` verifica reflexão antes da pausa, histórico compartilhado de 45 dias, clique duplo, persistência após recarregar, catálogo esgotado e retorno de elegibilidade. Resultados em `risk-reflection-results.json`.

## Atualização 1.6.0

As alterações e os limites atuais estão em `ATUALIZACAO-1.6.md`. A regressão completa foi reexecutada com sucesso. `v16-results.json` registra favoritos, rascunhos, player, marcadores, temporizador, backup protegido, compatibilidade com backups antigos e responsividade. `large-audio-results.json` registra o ensaio com WAV de 1.100.000.044 bytes e cerca de 3h28, incluindo buscas e retomada. Essas validações foram feitas no Edge com perfis isolados e dados fictícios; não substituem um ensaio em aparelho Android. Nenhum APK foi compilado ou instalado.

## Atualização 1.6.1

Barras verticais do relatório diário, relatos em ordem decrescente e títulos no cabeçalho validados em `test_v161.py`; resultados em `v161-results.json`. Regressão de navegador reexecutada com sucesso, sem erros JavaScript ou pedidos externos. Detalhes em `ATUALIZACAO-1.6.1.md`.

## Atualização 1.6.2

Corrigidas as barras para a orientação horizontal, posicionadas entre o nome e o valor de cada avaliação. Teste de interface passou em 320, 393, 768 e 1280 px, preservando relatos e cabeçalhos. Resultados em `v162-results.json`; captura em `v162-relatorio-mobile.png`.


## Atualização 1.6.3

Escudo preservado em todas as seções, título substituindo apenas o nome. Quinze artes locais dos marcos verificadas em estados atual, anterior e bloqueado. Estilo do seletor de backup comparado ao seletor de áudio e seleção de arquivo exercitada. Layout verificado de 320 a 1280 px; cabeçalhos também em paisagem. Barras horizontais, valores e ordem dos relatos passaram na regressão. Resultados: `v163-results.json`, `v163-art-results.json`. Os ícones de classificação das métricas aguardam confirmação dos critérios. Nenhum APK compilado.


## Atualização 1.6.4

Ícones Bom/OK/Crítico antes das barras, com legenda e nomes acessíveis. Critérios confirmados pelo usuário, invertidos para ansiedade e impulso. Testadas 25 combinações e posições em 320, 393, 768 e 1280 px, sem sobreposição. Regressão de relatos e cabeçalhos passou. Resultado: `v164-results.json`; imagem: `v164-relatorio-mobile.png`. Sintaxe de app.js validada. Nenhum APK compilado.


## Atualização 1.6.5

Artes detalhadas e coloridas com borda dourada nas conquistas. Linha de seleção da biblioteca com afastamento de pelo menos 17 px da grade. Imagem opcional: prévia, remover, erro de arquivo inválido, otimização, persistência, biblioteca e player, áudio sem imagem, backup simples e protegido e exclusão verificados. Testes `test_v165.py`, `test_v16.py`, `test_browser.py` e `test_large_audio.py` passaram. Áudio de 1,1 GB com capa: importação 0,109 s; reprodução 0,36 s; saltos 0,062–0,078 s; maior intervalo do monitor da interface 22,3 ms no Edge local. Layout de 320 a 1280 px e player em paisagem. Ver `v165-results.json`, `large-audio-results.json` e `ATUALIZACAO-1.6.5.md`. Nenhum APK compilado.


## Atualização 1.6.6

Compatibilidade de exportação para Website 2 APK Builder: identificação da ponte simulada e downloads reais no Edge, com e sem senha. Arquivos baixados restaurados e conferidos. Testados WebView sem ponte, navegador sem seletor, alternativa manual após falha, abertura do seletor antes do trabalho assíncrono e mensagem de permissão. `test_v166.py` e regressão `test_v16.py` passaram. `test_backup_download_large.py`: áudio de 128 MiB baixado/restaurado em ambos os modos; 16,38 s simples / 26,8 s protegido na exportação, intervalos máximos da interface 41,4 ms / 62 ms. Lista de 19 recursos do container próprio conferida contra o script de build. Sintaxe JavaScript validada. Testes não executam o conversor nem o APK do usuário. Nenhum APK compilado.


## Atualização 1.7.0 — 08/11/2026

`test_v170.py` passou: cadastro e persistência, prazo selecionado de 3h, alteração/remoção bloqueadas durante compromisso, 120 segundos completos com relógio de teste, paste/drop impedidos, mínimo de 150 caracteres, uma vitória por desistência, noite 23h–06h, vencimento natural durante a barreira sem vitória artificial, calculadora, PIN com hash/sal, recarga, cadeado e minimizações repetidas, diálogos ocultos e desativação com PIN atual. Sete seções sem rolagem horizontal em 320/393/768/1280 px e paisagem. Resultados: `v170-results.json`; imagens: `v170-bloqueio.png` e `v170-calculadora.png`.

`test_v170_data.py` passou: migrações 1→4 e 3→4 preservam todas as stores anteriores e Blob de áudio; backup inclui compromissos/tentativas e exclui PIN; restauração mantém compromisso ativo e não duplica vitórias; calculadora respeita precedência e rejeita código executável. Resultado: `v170-data-results.json`. `blocker-domain.test.js` passou para janelas noturnas, virada de dia, sobreposição com compromisso manual, exceção temporária e vencimento.

Regressões reexecutadas com sucesso: `domain.test.js`, `test_browser.py`, `test_v16.py`, `test_risk_reflection.py`, `test_v161.py`, `test_v165.py`, `test_v166.py` e `test_large_audio.py`. Expectativas antigas do questionário foram ajustadas à regra solicitada; a versão futura de teste da migração foi elevada para 5. O WAV de 1.100.000.044 bytes, com capa, levou 0,094 s para importar e 0,375 s para iniciar reprodução; buscas de 0,015–0,078 s; maior intervalo do monitor de interface 40,5 ms; heap JavaScript de cerca de 4,16 MB. Os números são do Edge neste computador, sem garantia equivalente para todo WebView.

O bloqueio é interno e comportamental; não exerce controle de outros apps no Android. A camuflagem foi exercitada no navegador e com o evento do container próprio simulado. Website 2 APK Builder e o APK no celular não foram executados. Não houve compilação Android.

Sintaxe de todos os módulos JavaScript validada com Node; listas do script de compilação e do container Java conferidas, com os mesmos 22 recursos locais.


## Atualização 1.7.1 — remoção do bloqueador e da camuflagem

A versão 1.7.0 introduziu um bloqueio apenas interno ao SafeHarbor, incapaz de impedir a abertura de outros aplicativos no APK do Website 2 APK Builder. A 1.7.1 remove os controles, módulos ativos, PIN, calculadora e cadeado, e restaura o HTML/CSS do cabeçalho anterior. As stores de dados permanecem no IndexedDB v4 para que atualizar não rebaixe/apague o banco; os dados antigos não reativam nenhum fluxo. `blocker-domain.js` segue apenas como compatibilidade para validar dados de backups antigos.

Validações já registradas nesta revisão: `tests/test_v171.py` abriu uma cópia v4 com PIN ativo, compromisso e tentativa pendente sem solicitar PIN, preservando registros, áudio e contadores; verificou que a interface não carrega os módulos removidos e manteve seis abas responsivas de 320 px a paisagem. `tests/test_v171_data.py` verificou compatibilidade de migração e backup. `tests/test_risk_reflection.py`, `tests/test_browser.py` e `tests/test_v16.py` passaram após remover a interface; áudio local, backup e fluxos anteriores continuaram operando no navegador de teste. Sintaxe dos módulos JavaScript e 20 assets do container próprio foram conferidos. O APK não foi recompilado nem instalado no celular.

A seção 1.7.0 acima documenta a implementação removida, não funções presentes na versão atual.
