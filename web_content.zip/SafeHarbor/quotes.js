export const quotes = [
  {
    "id": "q001",
    "author": "Epicteto",
    "source": "Manual, 1",
    "text": "Há coisas que dependem de nós e coisas que não dependem de nós. Dependem de nós o juízo, o impulso, o desejo, a aversão e, em uma palavra, tudo o que é ação nossa. Não dependem de nós o corpo, os bens, a reputação, os cargos e, em uma palavra, tudo o que não é ação nossa.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q002",
    "author": "Epicteto",
    "source": "Manual, 2",
    "text": "Lembra-te de que o desejo promete alcançar aquilo que deseja, e a aversão promete evitar aquilo a que tem aversão. Quem não alcança o que deseja fica frustrado, e quem encontra o que procura evitar se sente infeliz. Se evitares somente o que é contrário à natureza entre as coisas que dependem de ti, não cairás naquilo que evitas.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q003",
    "author": "Epicteto",
    "source": "Manual, 4",
    "text": "Quando fores realizar uma ação, lembra-te de que natureza ela é. Se fores tomar banho, representa para ti o que acontece no banho: pessoas que espirram água, empurram, insultam e furtam. Assim empreenderás a ação com mais segurança, se disseres desde o início: quero tomar banho e também conservar minha escolha em conformidade com a natureza.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q004",
    "author": "Epicteto",
    "source": "Manual, 5",
    "text": "Não são as coisas que perturbam as pessoas, mas os juízos que elas fazem sobre as coisas. A morte, por exemplo, nada tem de terrível, ou teria parecido terrível também a Sócrates; é o juízo de que a morte é terrível que é terrível. Quando estivermos impedidos, perturbados ou aflitos, não acusemos outra coisa senão nossos próprios juízos.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q005",
    "author": "Epicteto",
    "source": "Manual, 6",
    "text": "Não te orgulhes de uma excelência que não é tua. Se um cavalo dissesse com orgulho: sou belo, isso seria tolerável. Mas, quando dizes com orgulho: tenho um belo cavalo, fica sabendo que te orgulhas de uma qualidade do cavalo. O que é, então, teu? O uso das representações. Quando fizeres esse uso segundo a natureza, poderás orgulhar-te de um bem que é teu.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q006",
    "author": "Epicteto",
    "source": "Manual, 10",
    "text": "Diante de cada acontecimento, volta-te para ti mesmo e procura a faculdade que tens para fazer uso dele. Se vires uma pessoa bela, encontrarás a continência; diante do sofrimento, encontrarás a resistência; diante da injúria, encontrarás a paciência. E, habituando-te dessa maneira, as representações não te arrastarão consigo.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q007",
    "author": "Epicteto",
    "source": "Manual, 12",
    "text": "Se quiseres progredir, abandona pensamentos como estes: se eu negligenciar meus assuntos, não terei de que viver; se não castigar meu servo, ele será mau. É melhor morrer de fome, livre da tristeza e do medo, do que viver na abundância, perturbado. Começa, portanto, pelas pequenas coisas: um pouco de azeite derramado, um pouco de vinho furtado.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q008",
    "author": "Epicteto",
    "source": "Manual, 13",
    "text": "Se quiseres progredir, aceita parecer insensato e ignorante em relação às coisas exteriores. Não desejes parecer alguém que sabe; e, mesmo que pareças importante a alguns, desconfia de ti mesmo. Pois não é fácil conservar tua escolha em conformidade com a natureza e, ao mesmo tempo, conservar as coisas exteriores: cuidando de uma, necessariamente negligenciarás a outra.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q009",
    "author": "Epicteto",
    "source": "Manual, 14",
    "text": "O senhor de cada pessoa é aquele que tem o poder de conceder ou retirar aquilo que ela deseja ou aquilo que ela quer evitar. Portanto, quem quiser ser livre não queira nem evite coisa alguma que dependa de outros; caso contrário, necessariamente será escravo.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q010",
    "author": "Epicteto",
    "source": "Manual, 15",
    "text": "Lembra-te de que deves te comportar na vida como em um banquete. Algo é levado ao redor e chega até ti: estende a mão e toma uma porção com moderação. Passa adiante: não o detenhas. Ainda não chegou: não lances teu desejo para longe, mas espera até que esteja diante de ti. Age assim com os filhos, com o casamento, com os cargos e com a riqueza.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q011",
    "author": "Epicteto",
    "source": "Manual, 17",
    "text": "Lembra-te de que és ator de uma peça tal como o autor a quiser: curta, se ele a quiser curta; longa, se a quiser longa. Se ele quiser que representes um pobre, representa-o bem; faze o mesmo se for uma pessoa com deficiência, um governante ou um cidadão comum. Pois tua tarefa é representar bem o papel que te foi dado; escolhê-lo pertence a outro.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q012",
    "author": "Epicteto",
    "source": "Manual, 18",
    "text": "Quando um corvo crocitar de maneira desfavorável, não deixes que a representação te arraste. Distingue imediatamente e diz: nada disso anuncia algo para mim, mas talvez para meu pequeno corpo, meus bens, minha reputação, meus filhos ou minha mulher. Para mim, porém, todos os sinais são favoráveis, se eu quiser; pois, aconteça o que acontecer, depende de mim tirar proveito disso.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q013",
    "author": "Epicteto",
    "source": "Manual, 19",
    "text": "Podes ser invencível se não entrares em nenhuma disputa cuja vitória não dependa de ti. Quando vires alguém honrado acima de outros, poderoso ou estimado por qualquer razão, cuida para não o julgares feliz, levado pela impressão. Se a essência do bem está nas coisas que dependem de nós, não haverá lugar para inveja nem ciúme.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q014",
    "author": "Epicteto",
    "source": "Manual, 20",
    "text": "Lembra-te de que não é quem te insulta ou te bate que te ultraja, mas o teu juízo de que essas coisas são ultrajantes. Portanto, quando alguém te irritar, sabe que é tua própria avaliação que te irritou. Procura, antes de tudo, não ser arrastado pela representação; pois, se conseguires uma pausa e um adiamento, dominarás a ti mesmo mais facilmente.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q015",
    "author": "Epicteto",
    "source": "Manual, 26",
    "text": "Podemos aprender a vontade da natureza pelas coisas em que não divergimos uns dos outros. Quando o criado de outra pessoa quebra uma taça, estamos prontos a dizer: essas coisas acontecem. Sabe, portanto, que, quando a tua taça se quebrar, deves ter a mesma disposição que tinhas quando a taça de outra pessoa se quebrou.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q016",
    "author": "Epicteto",
    "source": "Manual, 29",
    "text": "Em toda ação, considera o que a precede e o que a acompanha, e então começa. Caso contrário, entrarás nela com entusiasmo, por não teres pensado nas consequências; depois, quando surgirem dificuldades, desistirás de modo vergonhoso. Queres vencer nos Jogos Olímpicos? Eu também, pois isso é belo. Mas considera o que vem antes e o que vem depois, e então empreende a tarefa.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q017",
    "author": "Epicteto",
    "source": "Manual, 30",
    "text": "Os deveres são, em geral, medidos pelas relações. Ele é teu pai: cabe-te cuidar dele, ceder, suportar sua censura e seus golpes. Mas é um mau pai. Acaso estás naturalmente ligado a um bom pai? Não, estás ligado a um pai. Teu irmão age injustamente? Conserva, então, tua posição em relação a ele; não consideres o que ele faz, mas o que deves fazer para manter tua escolha segundo a natureza.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q018",
    "author": "Epicteto",
    "source": "Manual, 33",
    "text": "Estabelece desde já um caráter e um modo de viver que conservarás tanto quando estiveres sozinho quanto no encontro com outras pessoas. Guarda silêncio na maior parte do tempo, ou diz somente o necessário, em poucas palavras. Quando a ocasião exigir que fales, fala; mas não sobre qualquer assunto ao acaso.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q019",
    "author": "Epicteto",
    "source": "Manual, 34",
    "text": "Quando fores tomado pela representação de algum prazer, cuida, como nos demais casos, para não seres arrastado por ela. Que a coisa espere por ti: concede a ti mesmo algum adiamento. Depois, põe diante dos olhos os dois momentos: aquele em que desfrutarás o prazer e aquele em que, depois de desfrutá-lo, te arrependerás e censurarás a ti mesmo.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q020",
    "author": "Epicteto",
    "source": "Manual, 35",
    "text": "Quando fizeres algo depois de julgar que deve ser feito, não evites ser visto fazendo-o, mesmo que a maioria das pessoas o desaprove. Pois, se não é correto fazê-lo, evita a própria ação; mas, se é correto, por que temer aqueles que vão te censurar injustamente por aquilo que fazes?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q021",
    "author": "Epicteto",
    "source": "Manual, 37–38",
    "text": "Se assumires um papel acima de tuas forças, não apenas te mostrarás inadequado nele: também terás deixado de lado aquele que poderias cumprir. Assim como, ao caminhar, cuidas para não pisar num prego ou torcer o pé, cuida também para não ferir a faculdade que dirige tua vida.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q022",
    "author": "Epicteto",
    "source": "Manual, 42",
    "text": "Quando alguém agir mal contigo ou falar mal de ti, lembra-te de que ele faz ou diz isso porque lhe parece correto. Não é possível que siga o que parece correto a ti, mas aquilo que parece correto a ele. Portanto, se julga mal, é ele quem sofre o dano, pois é ele quem se engana.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q023",
    "author": "Epicteto",
    "source": "Manual, 43",
    "text": "Toda coisa tem duas alças: uma pela qual pode ser carregada, e outra pela qual não pode. Se teu irmão agir injustamente, não tomes a coisa pela alça de que ele agiu injustamente, pois por essa alça não a carregarás. Toma-a antes pela outra: ele é teu irmão, foi criado contigo. Assim a tomarás pela alça pela qual ela pode ser carregada.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q024",
    "author": "Epicteto",
    "source": "Manual, 44",
    "text": "Estes raciocínios não são coerentes: sou mais rico que tu, portanto sou superior a ti; sou mais eloquente que tu, portanto sou superior a ti. São mais coerentes estes: sou mais rico que tu, portanto meus bens são superiores aos teus; sou mais eloquente que tu, portanto minha expressão é superior à tua. Mas tu não és teus bens nem tua expressão.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q025",
    "author": "Epicteto",
    "source": "Manual, 45",
    "text": "Alguém se banha depressa: não digas que se banha mal, mas que se banha depressa. Alguém bebe muito vinho: não digas que faz mal, mas que bebe muito. Pois, antes de conheceres o juízo que o orienta, como sabes que age mal? Assim não te acontecerá receber a representação de uma coisa e dar assentimento a outra.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q026",
    "author": "Epicteto",
    "source": "Manual, 46",
    "text": "Nunca te declares filósofo, nem fales muito entre os que não o são sobre os princípios, mas age de acordo com eles. Em um banquete, por exemplo, não discorras sobre como se deve comer: come como se deve. Lembra-te de que Sócrates afastava tão completamente a ostentação que pessoas vinham pedir-lhe que as apresentasse a filósofos, e ele as conduzia.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q027",
    "author": "Epicteto",
    "source": "Manual, 48",
    "text": "Sinais daquele que progride: não censura ninguém, não elogia ninguém, não acusa ninguém, não faz queixas; nada diz de si mesmo como se fosse alguém ou soubesse alguma coisa. Quando encontra impedimento ou obstáculo, acusa a si mesmo. Se alguém o elogia, ri, por dentro, de quem o elogia; se alguém o censura, não se defende.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q028",
    "author": "Epicteto",
    "source": "Manual, 50–51",
    "text": "Quaisquer regras que tenhas proposto a ti mesmo, conserva-as como leis, como se transgredi-las fosse uma impiedade. Quanto ao que os outros disserem a teu respeito, não lhe dês atenção, pois isso já não é assunto teu. Por quanto tempo ainda adiarás julgar-te digno das melhores coisas e deixarás de transgredir as distinções da razão?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q029",
    "author": "Epicteto",
    "source": "Manual, 51",
    "text": "Já não és uma criança, mas um homem feito. Se agora fores negligente e indolente, se sempre acrescentares adiamentos aos adiamentos e fixares um dia após outro para começar a cuidar de ti mesmo, não perceberás que não progrides e continuarás vivendo e morrendo como alguém que não estuda filosofia.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q030",
    "author": "Epicteto",
    "source": "Manual, 52",
    "text": "A primeira e mais necessária parte da filosofia é a aplicação dos princípios, como não mentir. A segunda é a demonstração, como provar por que não se deve mentir. A terceira confirma e distingue essas demonstrações: por que isto é uma demonstração? O que é uma demonstração, uma consequência, uma contradição, o verdadeiro e o falso?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q031",
    "author": "Marco Aurélio",
    "source": "Meditações, II, 1",
    "text": "Ao amanhecer, diz a ti mesmo: encontrarei pessoas intrometidas, ingratas, arrogantes, falsas, invejosas e insociáveis. Tudo isso lhes acontece por ignorarem o bem e o mal. Mas eu, que vi a natureza do bem, que é belo, e a do mal, que é vergonhoso, e que sei que aquele que erra é meu parente, não posso ser prejudicado por nenhum deles.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q032",
    "author": "Marco Aurélio",
    "source": "Meditações, II, 5",
    "text": "A cada momento, ocupa-te com firmeza, como romano e como homem, de fazer o que tens em mãos com dignidade precisa e sincera, com afeto, liberdade e justiça; e dá a ti mesmo descanso de todas as outras imaginações. Conseguirás isso se executares cada ação como se fosse a última de tua vida.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q033",
    "author": "Marco Aurélio",
    "source": "Meditações, IV, 3",
    "text": "As pessoas procuram retiros no campo, à beira-mar e nas montanhas, e tu também costumas desejar essas coisas. Mas isso é próprio de quem não compreende, pois podes, a qualquer hora que quiseres, retirar-te para dentro de ti mesmo. Em nenhum lugar uma pessoa encontra um retiro mais tranquilo e menos agitado do que em sua própria alma.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q034",
    "author": "Marco Aurélio",
    "source": "Meditações, IV, 49",
    "text": "Sê como o promontório contra o qual as ondas se quebram continuamente: ele permanece firme, e à sua volta a água revolta acaba por se aquietar. Infeliz de mim, porque isso me aconteceu! Não: feliz de mim, porque, embora isso tenha acontecido, continuo livre da tristeza, sem ser esmagado pelo presente nem temer o futuro.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q035",
    "author": "Marco Aurélio",
    "source": "Meditações, V, 1",
    "text": "Ao amanhecer, quando te custar levantar, tem à mão este pensamento: levanto-me para realizar o trabalho de um ser humano. Por que me queixaria, então, se vou fazer aquilo para o qual nasci e para o qual fui trazido ao mundo? Ou fui feito para permanecer sob as cobertas, aquecendo a mim mesmo?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q036",
    "author": "Marco Aurélio",
    "source": "Meditações, VI, 30",
    "text": "Cuida para não te tornares um César, para não te tingires dessa cor, pois isso acontece. Conserva-te simples, bom, puro, sério, sem afetação, amigo da justiça, reverente, bondoso, afetuoso e firme no cumprimento de teus deveres. Esforça-te para permanecer tal como a filosofia quis fazer de ti. Respeita os deuses e ajuda os seres humanos.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q037",
    "author": "Marco Aurélio",
    "source": "Meditações, VIII, 47",
    "text": "Se te afliges por alguma coisa exterior, não é ela que te perturba, mas teu juízo sobre ela; e está em teu poder apagar esse juízo agora. Mas, se algo em tua própria disposição te aflige, quem te impede de corrigir teu entendimento? E, se estás aflito por não fazeres algo que te parece correto, por que não o fazes, em vez de te afligires?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q038",
    "author": "Sêneca",
    "source": "Cartas a Lucílio, 1, 1–2",
    "text": "Faze assim, meu Lucílio: reivindica a ti mesmo para ti, e o tempo que até agora te era tomado, roubado ou escapava, reúne-o e conserva-o. Convence-te de que é como escrevo: alguns momentos nos são arrancados, alguns nos são subtraídos, outros se perdem. Mas a perda mais vergonhosa é aquela que acontece por negligência.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q039",
    "author": "Sêneca",
    "source": "Cartas a Lucílio, 2, 2–3",
    "text": "Estar em toda parte é não estar em parte alguma. Aos que passam a vida viajando acontece terem muitas hospedagens e nenhuma amizade. O mesmo necessariamente acontece aos que não se ligam intimamente a nenhum autor, mas percorrem tudo com pressa e de passagem. O alimento não aproveita nem se incorpora ao corpo quando é expelido logo depois de ingerido.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q040",
    "author": "Sêneca",
    "source": "Cartas a Lucílio, 13, 4–5",
    "text": "Há mais coisas, Lucílio, que nos assustam do que coisas que nos oprimem; sofremos mais frequentemente na imaginação do que na realidade. Não te falo aqui na linguagem dos estoicos, mas de maneira mais simples: aconselho-te a não seres infeliz antes do tempo, pois aquilo que temes como se já estivesse próximo talvez nunca chegue, e certamente ainda não chegou.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q041",
    "author": "Sêneca",
    "source": "Cartas a Lucílio, 28, 1–2",
    "text": "Julgas que só contigo aconteceu, e te admiras como de uma novidade, que, depois de tão longa viagem e tantas mudanças de lugar, não tenhas afastado a tristeza e o peso de teu espírito? É a alma que deves mudar, não o céu. Ainda que atravessemos o vasto mar, nossos vícios nos seguirão para onde quer que formos.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q042",
    "author": "Heráclito",
    "source": "Fragmento B1, numeração Diels–Kranz",
    "text": "Embora este logos seja sempre, os homens não o compreendem, tanto antes de o ouvirem quanto depois de o terem ouvido pela primeira vez. Pois, embora todas as coisas aconteçam segundo este logos, parecem inexperientes quando experimentam palavras e ações como aquelas que exponho, distinguindo cada coisa segundo sua natureza e mostrando como ela é.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q043",
    "author": "Platão",
    "source": "Apologia de Sócrates, 29d–30a",
    "text": "Ó melhor dos homens, sendo ateniense, cidadão da maior cidade e da mais famosa por sua sabedoria e poder, não te envergonhas de cuidar de adquirir o máximo de riquezas, reputação e honras, enquanto não cuidas nem te preocupas com a sabedoria, com a verdade e com tornar tua alma tão boa quanto possível?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q044",
    "author": "Platão",
    "source": "Críton, 49b–c",
    "text": "Portanto, nunca se deve cometer injustiça. Nem, quando se sofre uma injustiça, se deve retribuí-la, como pensa a maioria, já que de modo algum se deve cometer injustiça. E quanto a fazer mal? Deve-se fazê-lo ou não? Não se deve, certamente. Assim, nem retribuir uma injustiça nem fazer mal a qualquer pessoa, seja o que for que se tenha sofrido dela, é correto.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q045",
    "author": "Aristóteles",
    "source": "Ética a Nicômaco, II, 1",
    "text": "As coisas que precisamos aprender antes de fazer, nós as aprendemos fazendo: as pessoas se tornam construtoras construindo e tocadoras de lira tocando lira. Do mesmo modo, tornamo-nos justos praticando ações justas, moderados praticando ações moderadas e corajosos praticando ações corajosas. Isso também é confirmado pelo que acontece nas cidades, pois os legisladores tornam bons os cidadãos por meio dos hábitos.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q046",
    "author": "Aristóteles",
    "source": "Ética a Nicômaco, II, 6",
    "text": "Ter medo, sentir confiança, desejar, irritar-se, compadecer-se e, em geral, sentir prazer e dor pode acontecer em excesso ou em falta, e nenhum dos dois é bom. Mas sentir essas coisas no momento certo, a respeito dos objetos certos, em relação às pessoas certas, pelo motivo certo e da maneira certa é o meio-termo e o melhor, e isso pertence à virtude.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q047",
    "author": "Dostoiévski",
    "source": "Os irmãos Karamázov, livro II, capítulo IV",
    "text": "O amor em ação é uma coisa dura e terrível em comparação com o amor nos sonhos. O amor nos sonhos tem sede de uma realização imediata, rápida e diante dos olhos de todos. Chega-se até a dar a própria vida, contanto que isso não dure muito e termine depressa, como num palco, sob os olhares e os elogios. Mas o amor em ação é trabalho e perseverança.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q048",
    "author": "Franz Kafka",
    "source": "Diante da lei, abertura",
    "text": "Diante da lei está um porteiro. Um homem do campo chega até esse porteiro e pede para entrar na lei. Mas o porteiro diz que agora não pode permitir sua entrada. O homem reflete e pergunta se poderá entrar mais tarde. É possível, diz o porteiro, mas agora não. Como o portão da lei continua aberto, como sempre, o homem se inclina para olhar para dentro.",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q049",
    "author": "Nietzsche",
    "source": "A gaia ciência, §341",
    "text": "E se um dia ou uma noite um demônio se esgueirasse até tua mais solitária solidão e te dissesse: esta vida, tal como agora a vives e a viveste, terás de viver mais uma vez e inúmeras vezes; e nada haverá nela de novo, mas cada dor, cada prazer, cada pensamento e cada suspiro, e tudo o que é indizivelmente pequeno e grande em tua vida, deverá retornar a ti, tudo na mesma sequência e ordem?",
    "note": "Excerto em tradução própria"
  },
  {
    "id": "q050",
    "author": "Albert Camus",
    "source": "O mito de Sísifo, conclusão",
    "text": "É preciso imaginar Sísifo feliz.",
    "note": "Trecho breve, tradução própria"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o que se repete",
    "text": "O que é a maldade? Aquilo que já viste muitas vezes. Diante de cada acontecimento, lembra-te de que é algo que já viste. Por toda parte encontrarás as mesmas coisas, das quais estão cheias as histórias antigas, as intermediárias e as de nosso tempo. Nada é novo: tudo é familiar e de curta duração.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q051"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — reacender os princípios",
    "text": "Como poderiam morrer nossos princípios, a não ser que se extinguissem os pensamentos que lhes correspondem? Mas está em teu poder reacender continuamente esses pensamentos. Posso formar sobre cada coisa o juízo que devo formar. Se posso, por que me perturbo? Recuperar tua vida está em teu poder: volta a olhar as coisas como costumavas olhar.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q052"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — ocupações e valor",
    "text": "A agitação vazia dos espetáculos, as representações no palco, os rebanhos, os exercícios com lanças, um osso lançado aos cães, migalhas nos tanques de peixes, as formigas carregando suas cargas, os ratos assustados, as marionetes movidas por fios: tudo se parece. Em meio a isso, conserva o bom humor, sem arrogância, compreendendo o valor das coisas com que te ocupas.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q053"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — atenção à conversa",
    "text": "Na conversa, é preciso prestar atenção ao que se diz; em cada movimento, observar o que se faz. Em um caso, deves perceber imediatamente a finalidade a que a ação se refere; no outro, deves acompanhar cuidadosamente o sentido daquilo que está sendo expresso.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q054"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — saber pedir auxílio",
    "text": "Minha compreensão é suficiente para esta tarefa? Se for, uso-a como um instrumento dado pela natureza universal. Se não for, retiro-me e cedo lugar a quem possa realizá-la melhor, a menos que haja uma razão para permanecer; ou faço o melhor que posso, buscando a ajuda de alguém capaz de contribuir para o bem comum.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q055"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — receber ajuda",
    "text": "Não te envergonhes de receber ajuda. Tua tarefa é cumprir teu dever, como um soldado no assalto a uma cidade. Que fazer, então, se, por estar ferido, não consegues subir sozinho às muralhas, mas com o auxílio de outra pessoa isso se torna possível?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q056"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o vínculo entre as coisas",
    "text": "Todas as coisas estão entrelaçadas umas com as outras, e o vínculo é sagrado; quase nada existe sem relação com outra coisa. As coisas foram coordenadas e, juntas, compõem o mesmo universo. Há um universo feito de todas as coisas, uma substância, uma lei e uma razão comum aos seres inteligentes.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q057"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — ser membro do conjunto",
    "text": "Assim como os membros dos corpos unidos em um só organismo, os seres racionais, embora separados, foram constituídos para uma cooperação. Perceberás isso mais claramente se disseres muitas vezes a ti mesmo: sou um membro do sistema dos seres racionais. Se te consideras apenas uma parte isolada, ainda não amas os outros de coração.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q058"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o acontecimento e o juízo",
    "text": "Que aconteça externamente o que tiver de acontecer às partes capazes de sentir seus efeitos. As partes atingidas poderão queixar-se, se quiserem. Mas eu, a menos que considere um mal aquilo que aconteceu, não sou prejudicado; e está em meu poder não formar esse juízo.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q059"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — conservar a própria cor",
    "text": "Faça ou diga alguém o que quiser, devo continuar bom. É como se o ouro, a esmeralda ou a púrpura repetissem sempre a mesma coisa: faça ou diga alguém o que quiser, preciso continuar sendo esmeralda e conservar a minha própria cor.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q060"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — não acrescentar perturbação",
    "text": "A faculdade que governa não perturba a si mesma: quero dizer que não se amedronta nem produz sofrimento para si. Se outra coisa puder amedrontá-la ou fazê-la sofrer, que o faça. Ela mesma, porém, não se desviará por seu próprio juízo para esses caminhos.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q061"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — a necessidade da mudança",
    "text": "Alguém tem medo da mudança? Mas o que pode acontecer sem mudança? Poderias tomar banho se a lenha não se transformasse? Poderias alimentar-te se o alimento não se transformasse? E alguma coisa útil poderia ser realizada sem mudança? Não percebes que, para ti, mudar é igualmente necessário à natureza universal?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q062"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — a corrente do tempo",
    "text": "Pela substância universal, como por uma torrente impetuosa, todos os corpos são levados; por sua natureza estão unidos e cooperam com o conjunto, assim como as partes de nosso corpo cooperam entre si. Quantos Crisipo, Sócrates e Epicteto o tempo já engoliu! Deixa que o mesmo pensamento te ocorra a respeito de cada pessoa e de cada coisa.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q063"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — compreender quem erra",
    "text": "É próprio do ser humano amar até aqueles que agem mal. Isso se torna possível quando te ocorre que são teus parentes, que erram por ignorância e sem intenção, que em breve ambos morrerão e, sobretudo, que quem errou não tornou pior a faculdade que governa tua vida.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q064"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — a matéria que se transforma",
    "text": "A natureza universal molda a substância comum como se fosse cera: agora um cavalo; depois de desfazê-lo, emprega o material numa árvore, depois num homem, depois em outra coisa. Cada uma dessas formas subsiste por um tempo muito curto. Para o recipiente, ser desfeito não é mais penoso do que ter sido formado.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q065"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o rosto e a disposição",
    "text": "Uma expressão carrancuda é inteiramente contrária à natureza. Quando assumida muitas vezes, faz desaparecer toda a beleza do rosto e, por fim, a extingue a ponto de não poder ser reacendida. Procura concluir, a partir disso, que tal disposição é contrária à razão.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q066"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — examinar a ofensa",
    "text": "Quando alguém te fizer algum mal, considera imediatamente com que opinião sobre o bem e o mal ele agiu. Ao perceberes isso, sentirás compaixão e não espanto ou cólera. Talvez tu mesmo consideres boas as mesmas coisas, ou coisas da mesma espécie. Nesse caso, cabe-te compreender seu erro.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q067"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o que já está presente",
    "text": "Não penses tanto no que não tens quanto no que tens. Entre as coisas que possuis, escolhe as melhores e reflete em como as buscarias ardentemente se não as possuísses. Ao mesmo tempo, evita valorizá-las tanto, por apreciares sua presença, que venhas a perturbar-te caso um dia deixem de estar contigo.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q068"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — circunscrever o presente",
    "text": "Apaga a imaginação. Interrompe os puxões dos fios. Limita-te ao presente. Compreende bem o que acontece contigo ou com outra pessoa. Distingue em cada objeto a causa e a matéria. Pensa em tua última hora. Deixa o erro cometido por alguém no lugar em que ele foi cometido.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q069"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — simplicidade e humanidade",
    "text": "Adorna-te com simplicidade e modéstia, e com indiferença diante das coisas que ficam entre a virtude e o vício. Ama a humanidade. Segue a divindade. O poeta diz que a lei governa todas as coisas; basta lembrar que há uma lei que governa o conjunto.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q070"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — a fama e a areia",
    "text": "Quanto à fama, observa a mente daqueles que a procuram: vê como são, que coisas evitam e que coisas perseguem. Considera também que, assim como montes de areia sobrepostos escondem a areia anterior, os acontecimentos que chegam depois logo cobrem, na vida, os que vieram antes.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q071"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — olhar as estrelas",
    "text": "Acompanha os cursos dos astros como se viajasses junto com eles, e considera continuamente as transformações dos elementos uns nos outros. Pensamentos como esses afastam a impureza da vida terrestre. Observa também as coisas humanas de um lugar mais alto, em sua mistura e em sua combinação de contrários.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q072"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o passado e o futuro",
    "text": "Considera o passado, com suas grandes mudanças de poder político. Assim poderás antever o que virá, pois terá certamente forma semelhante e não poderá afastar-se da ordem do que acontece agora. Contemplar a vida humana durante quarenta anos é, por isso, como contemplá-la durante dez mil. Que mais haverás de ver?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q073"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — habilidades e caráter",
    "text": "Outra pessoa pode ser mais hábil em derrubar um adversário; não é, por isso, mais sociável, mais modesta, mais preparada para enfrentar tudo o que acontece, nem mais compreensiva diante das faltas dos que a cercam. Onde uma ação pode ser feita de acordo com a razão comum, nada temos a temer.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q074"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o cuidado com o pensamento",
    "text": "Em toda parte e a todo momento está em teu poder aceitar com reverência tua condição presente, comportar-te com justiça com aqueles que estão perto de ti e aplicar tua atenção aos pensamentos atuais, para que nada penetre neles sem antes ter sido bem examinado.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q075"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — trabalhar com o que acontece",
    "text": "Por que não te aplicas inteiramente à maneira correta de usar aquilo que te acontece? Então o usarás bem, e isso se tornará material para teu trabalho. Presta atenção a ti mesmo e decide ser uma boa pessoa em cada ação que realizares.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q076"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — a aprovação que buscamos",
    "text": "Observa continuamente quem são aqueles cuja aprovação desejas e que princípios os governam. Assim, não censurarás os que ofendem involuntariamente nem precisarás de sua aprovação, se olhares para as fontes de onde procedem as opiniões e os desejos dessas pessoas.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q077"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — gentileza diante do erro",
    "text": "Toda alma, diz o filósofo, é privada da verdade contra sua vontade; da mesma maneira, é privada da justiça, da moderação, da benevolência e de tudo o que pertence a essa espécie. É muito necessário ter isso constantemente em mente, pois assim serás mais gentil com todos.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q078"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — o pouco necessário",
    "text": "Lembra-te sempre de que muito pouco é necessário para uma vida feliz. E, por teres perdido a esperança de tornar-te um dialético ou conhecedor da natureza, não abandones também a esperança de ser livre, modesto, sociável e obediente à divindade.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q079"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VII — não procurar uma terceira recompensa",
    "text": "Quando realizaste uma boa ação e outra pessoa a recebeu, por que ainda procuras uma terceira coisa além dessas duas, como fazem os insensatos: a reputação de ter praticado o bem ou a obtenção de uma recompensa em troca do que fizeste?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.7.seven.html",
    "id": "q080"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a vida que resta",
    "text": "Se viste verdadeiramente onde está a questão, abandona o pensamento de como parecerás aos outros e contenta-te em viver o restante de tua vida como tua natureza pede. Observa o que ela pede e não deixes que outra coisa te distraia: já experimentaste muitas andanças sem encontrar felicidade na riqueza, na reputação ou no prazer.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q081"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — antes de cada ação",
    "text": "Em cada ação, pergunta a ti mesmo: como isso se relaciona comigo? Irei me arrepender? Em pouco tempo estarei morto, e tudo terá passado. O que mais procuro, se o que faço agora é o trabalho de um ser inteligente e social, submetido à mesma lei que governa o todo?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q082"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — os poderosos e os filósofos",
    "text": "O que são Alexandre, Caio e Pompeu em comparação com Diógenes, Heráclito e Sócrates? Estes conheciam as coisas, suas causas e sua matéria, e os princípios que os governavam eram os mesmos. Quanto aos outros, de quantas coisas precisavam cuidar e de quantas coisas eram escravos!",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q083"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — atenção ao próprio trabalho",
    "text": "Fixa os olhos em teu trabalho e observa-o, lembrando ao mesmo tempo que é teu dever ser uma boa pessoa. Faz aquilo que a natureza humana exige, sem te desviares. Fala como te parecer mais justo, mas com boa disposição, com modéstia e sem hipocrisia.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q084"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — mudanças familiares",
    "text": "O trabalho da natureza universal é levar para outro lugar as coisas que estão aqui, transformá-las, retirá-las daqui e transportá-las para lá. Todas as coisas são mudança; no entanto, não precisamos temer algo novo. Tudo nos é familiar, embora a distribuição das coisas continue a se alterar.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q085"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a natureza racional",
    "text": "Uma natureza racional segue bem seu caminho quando, em seus pensamentos, não dá assentimento ao falso nem ao incerto; quando dirige seus movimentos para ações sociais; quando limita desejos e aversões ao que está em seu poder; e quando aceita o que lhe é atribuído pela natureza comum.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q086"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a folha e a planta",
    "text": "Cada natureza particular é parte da natureza comum, assim como a natureza da folha é parte da natureza da planta. Mas não examines uma coisa isolada para descobrir se é igual a outra em todos os aspectos: considera conjuntamente todas as partes de uma e compara-as com todas as partes da outra.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q087"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — o que ainda podes praticar",
    "text": "Não tens tempo ou capacidade para ler. Mas tens tempo para conter a arrogância, para te colocares acima do prazer e da dor, para te colocares acima do amor à fama e para não te irritares com pessoas insensatas e ingratas; tens tempo, até mesmo, para cuidar delas.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q088"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — levantar e cooperar",
    "text": "Quando te levantares do sono com relutância, lembra-te de que realizar ações sociais está de acordo com tua constituição e com a natureza humana; dormir, porém, é comum também aos animais irracionais. O que está de acordo com a natureza de cada ser lhe pertence mais propriamente e é mais adequado a ele.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q089"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — os juízos dos outros",
    "text": "Qualquer pessoa que encontrares, pergunta imediatamente a ti mesmo: que opiniões ela tem sobre o bem e o mal? Se suas opiniões sobre prazer e dor, fama e desonra, morte e vida são de determinada espécie, não me parecerá surpreendente ou estranho que ela aja dessa maneira.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q090"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a figueira e os figos",
    "text": "Lembra-te de que, assim como é absurdo surpreender-se quando uma figueira produz figos, também o é surpreender-se quando o mundo produz as coisas que lhe são próprias. Para o médico e para o piloto, é igualmente absurdo espantar-se quando alguém tem febre ou quando o vento é desfavorável.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q091"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a liberdade de mudar de ideia",
    "text": "Lembra-te de que mudar de opinião e seguir aquele que corrige teu erro é tão compatível com a liberdade quanto persistir em tua opinião. Pois é tua a atividade exercida de acordo com teu próprio movimento e juízo, e também de acordo com teu próprio entendimento.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q092"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — corrigir em vez de culpar",
    "text": "Se puderes, corrige aquilo que é a causa; se não puderes, corrige ao menos a própria coisa. Mas, se nem isso puderes fazer, de que te serve procurar culpados? Não se deve fazer nada sem uma finalidade. Culpar o acaso ou os deuses seria igualmente insensato.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q093"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — permanecer no universo",
    "text": "Aquilo que morreu não cai para fora do universo. Se permanece aqui, transforma-se aqui e se dissolve nas partes que lhe são próprias, elementos do universo e também de ti mesmo. E esses elementos, por sua vez, também se transformam, sem murmurar.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q094"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a finalidade das coisas",
    "text": "Tudo existe para alguma finalidade: um cavalo, uma videira. Por que te admiras? Até o sol dirá que existe para algum propósito, e o mesmo dirão os demais deuses. Para qual finalidade existes tu, então? Para desfrutar prazeres? Examina se o bom senso permite essa resposta.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q095"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a bola e a bolha",
    "text": "A natureza considera em tudo tanto o fim quanto o começo e a duração, como quem lança uma bola para o alto. Que bem há para a bola em subir, ou que mal em descer ou já ter caído? E que bem há para uma bolha enquanto permanece inteira, ou que mal quando se desfaz?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q096"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — quem elogia e quem é elogiado",
    "text": "De curta duração são tanto aquele que elogia quanto aquele que é elogiado, aquele que recorda quanto aquele que é recordado. Tudo isso acontece num pequeno canto desta parte do mundo; e nem sequer aí todos concordam, nem cada um concorda sempre consigo mesmo. A própria Terra é apenas um ponto.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q097"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — o trabalho propriamente humano",
    "text": "É satisfação para um ser humano realizar os trabalhos próprios de um ser humano. E é trabalho humano ser benevolente com os da própria espécie, julgar com justiça as aparências plausíveis e contemplar a natureza do universo e das coisas que nele acontecem.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q098"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — três relações",
    "text": "Há três relações entre ti e as outras coisas: a primeira, com o corpo que te envolve; a segunda, com a causa divina da qual todas as coisas chegam a todos; a terceira, com aqueles que vivem contigo.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q099"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — usar cada coisa segundo seu valor",
    "text": "Apaga tuas imaginações dizendo muitas vezes a ti mesmo: agora está em meu poder não deixar que haja maldade nesta alma, nem desejo ou perturbação; olhando para todas as coisas, vejo sua natureza e uso cada uma segundo seu valor. Lembra-te desse poder que recebeste da natureza.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q100"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — uma ação de cada vez",
    "text": "É teu dever ordenar bem a vida em cada ação. Se cada ação cumprir seu papel, tanto quanto for possível, contenta-te. Algo exterior poderá se opor; nada, porém, impedirá que ajas com justiça, moderação e consideração. Aceitando o impedimento, transfere teu esforço para aquilo que é permitido.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q101"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a possibilidade de voltar",
    "text": "Suponha que te tenhas separado da união natural: foste constituído pela natureza como uma parte, mas agora te separaste. Ainda assim, há esta bela possibilidade: está em teu poder unir-te novamente. Depois da separação, foi permitido ao ser humano voltar, reunir-se ao conjunto e retomar seu lugar como parte.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q102"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — o obstáculo como material",
    "text": "Assim como a natureza universal transforma aquilo que se põe em seu caminho e lhe faz oposição, colocando-o em seu lugar e tornando-o parte de si, também o ser racional é capaz de fazer de cada impedimento seu próprio material e de usá-lo para as finalidades que concebeu.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q103"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — não carregar a vida inteira",
    "text": "Não te perturbes pensando em tua vida inteira. Não deixes que teus pensamentos abracem de uma só vez todas as dificuldades que imaginas que poderão acontecer. Em cada ocasião, pergunta: o que há nisto que é intolerável? Lembra-te depois de que não é o futuro nem o passado que te aflige, mas somente o presente.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q104"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — as preferências de cada pessoa",
    "text": "Coisas diferentes alegram pessoas diferentes. Minha alegria, porém, é conservar íntegra a faculdade que governa, sem me afastar de qualquer pessoa nem de qualquer coisa que aconteça aos seres humanos, olhando para tudo com acolhimento e usando cada coisa de acordo com seu valor.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q105"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — assegurar o tempo presente",
    "text": "Assegura para ti este tempo presente. Aqueles que perseguem a fama depois da morte não consideram que os homens do futuro serão exatamente como os que agora não conseguem suportar, e que ambos são mortais. O que te importa, afinal, que os homens de depois emitam este ou aquele som a teu respeito?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q106"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a mudança de lugar",
    "text": "Toma-me e lança-me onde quiseres: ali conservarei tranquila minha parte divina, satisfeita se puder sentir e agir conforme sua constituição. Será a mudança de lugar uma razão suficiente para que minha alma seja infeliz e pior do que antes, abatida, contraída ou amedrontada?",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q107"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — a cidadela interior",
    "text": "Lembra-te de que a faculdade que governa é invencível quando, recolhida em si mesma, se contenta em não fazer o que não escolhe fazer, mesmo que resista por mera obstinação. O que será, então, quando formar seus juízos com razão e deliberação? A mente livre das paixões é uma cidadela.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q108"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — os fatos e os acréscimos",
    "text": "Não digas a ti mesmo nada além do que as primeiras aparências informam. Foi relatado que certa pessoa fala mal de ti: isso foi relatado, mas não foi relatado que foste prejudicado. Vejo que meu filho está doente: vejo isso, mas não vejo que ele esteja em perigo. Permanece nos primeiros fatos, sem acrescentar coisas de dentro de ti.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q109"
  },
  {
    "author": "Marco Aurélio",
    "source": "Meditações, livro VIII — o pepino e os espinhos",
    "text": "O pepino é amargo? Põe-no de lado. Há espinhos no caminho? Desvia-te deles. Isso basta. Não acrescentes: por que existem coisas assim no mundo? Quem conhece a natureza riria de ti, como o carpinteiro ou o sapateiro riria se censurasses as aparas e os restos que encontras em sua oficina.",
    "note": "Excerto em tradução própria",
    "reference": "https://classics.mit.edu/Antoninus/meditations.8.eight.html",
    "id": "q110"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — o tempo do sofrimento",
    "text": "O sofrimento é um momento muito longo. Não podemos dividi-lo em estações. Podemos apenas registrar seus estados e narrar seu retorno. Para nós, o próprio tempo não avança: gira. Parece circular ao redor de um único centro de dor. A imobilidade de uma vida regulada por um padrão imutável parece comunicar-se às forças exteriores cuja essência é a mudança.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q111"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a delicadeza da dor",
    "text": "A prosperidade, o prazer e o sucesso podem ter uma textura grosseira e uma fibra comum, mas a tristeza é a mais sensível de todas as coisas criadas. Nada se move no mundo do pensamento sem que ela vibre. É uma ferida que sangra quando qualquer mão, exceto a do amor, a toca.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q112"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — um gesto silencioso",
    "text": "Nunca lhe disse uma única palavra sobre o que fez. Até hoje não sei se percebeu que eu tinha consciência de seu gesto. Não é algo pelo qual se possa agradecer formalmente, em palavras formais. Guardo-o no tesouro de meu coração, como uma dívida secreta que me alegra pensar que jamais poderei pagar.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q113"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a sabedoria da compaixão",
    "text": "Os pobres são mais sábios, mais caridosos, mais bondosos e mais sensíveis do que nós. Aos seus olhos, a prisão é uma tragédia na vida de uma pessoa, uma desgraça, um acidente, algo que pede a simpatia dos outros. Falam de quem está preso simplesmente como alguém que está passando por dificuldades.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q114"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — os pequenos atos",
    "text": "Esqueci que cada pequena ação de um dia comum faz ou desfaz o caráter, e que, por isso, aquilo que alguém fez no aposento secreto terá um dia de proclamar em voz alta sobre os telhados. Deixei de ser senhor de mim mesmo. Já não era o capitão de minha alma, e não sabia disso.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q115"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a busca de sentido",
    "text": "Embora houvesse momentos em que eu me alegrasse com a ideia de que meus sofrimentos seriam intermináveis, não suportava que não tivessem sentido. Agora encontro, escondido em algum lugar de minha natureza, algo que me diz que nada no mundo é sem sentido, e menos ainda o sofrimento. Esse algo, como um tesouro num campo, é a humildade.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q116"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — o ponto de partida",
    "text": "É a última coisa que me resta, e a melhor: a descoberta final à qual cheguei, o ponto de partida de um novo desenvolvimento. Veio de dentro de mim, e por isso sei que chegou no momento certo. Não poderia ter vindo antes nem depois. Se alguém me tivesse falado dela, eu a teria rejeitado.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q117"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — libertar-se da amargura",
    "text": "Agora que percebi que isso está em mim, vejo com clareza o que devo fazer. Minha natureza procura uma nova forma de realizar-se. É somente com isso que me preocupo. E a primeira coisa que preciso fazer é libertar-me de todo sentimento possível de amargura contra o mundo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q118"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — o que se leva no coração",
    "text": "Estou completamente sem dinheiro e sem casa. Ainda assim, há coisas piores no mundo. Digo com sinceridade que, em vez de sair desta prisão com amargura no coração contra o mundo, eu preferiria pedir meu pão de porta em porta. Aqueles que têm muito são frequentemente gananciosos; os que têm pouco sempre compartilham.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q119"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a alegria de ler",
    "text": "Acredito que terei o suficiente para viver por cerca de dezoito meses, ao menos. Assim, se eu não puder escrever belos livros, poderei ao menos ler belos livros; e que alegria poderia ser maior? Depois disso, espero conseguir recriar minha capacidade criadora.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q120"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a calma sem ressentimento",
    "text": "Mesmo que eu não tivesse um amigo no mundo, mesmo que nenhuma casa se abrisse para mim por compaixão, enquanto estivesse livre de ressentimento, dureza e desprezo, poderia enfrentar a vida com muito mais calma e confiança do que se meu corpo estivesse coberto de púrpura e linho fino, mas minha alma doente de ódio.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q121"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — o caminho que ainda falta",
    "text": "Minha tarefa não termina aí. Seria relativamente fácil se terminasse. Há muito mais diante de mim. Tenho montanhas muito mais íngremes para subir e vales muito mais escuros para atravessar. E preciso extrair tudo isso de dentro de mim mesmo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q122"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a forma espiritual",
    "text": "Seja fé ou agnosticismo, nada disso deve ser exterior a mim. Seus símbolos precisam ser de minha própria criação. Só é espiritual aquilo que produz sua própria forma. Se eu não puder encontrar seu segredo dentro de mim, jamais o encontrarei; se já não o possuo, ele nunca virá a mim.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q123"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — transformar a experiência",
    "text": "Tenho de tornar bom para mim tudo o que me aconteceu. A cama de tábuas, a comida repugnante, as cordas ásperas desfiadas até que as pontas dos dedos percam a sensibilidade de dor, as tarefas servis, as ordens duras, o silêncio, a solidão, a vergonha: cada uma dessas coisas precisa ser transformada numa experiência espiritual.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q124"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — pontos de mudança",
    "text": "Quero chegar ao ponto em que possa dizer, com simplicidade e sem afetação, que os dois grandes momentos decisivos de minha vida foram quando meu pai me enviou a Oxford e quando a sociedade me enviou à prisão. Não direi que a prisão foi a melhor coisa que poderia ter me acontecido: isso teria amargura demais contra mim mesmo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q125"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — integrar o vivido",
    "text": "O que eu ou os outros dissermos importa pouco. O importante, aquilo que está diante de mim, é absorver em minha natureza tudo o que me foi feito, torná-lo parte de mim, aceitá-lo sem queixa, medo ou relutância, para que o breve restante de meus dias não fique mutilado e incompleto.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q126"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — lembrar quem se é",
    "text": "Quando fui preso pela primeira vez, algumas pessoas me aconselharam a tentar esquecer quem eu era. Era um conselho desastroso. Somente ao compreender quem sou encontrei alguma espécie de consolo. Agora outros me aconselham a tentar esquecer, quando sair, que um dia estive numa prisão. Sei que isso seria igualmente fatal.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q127"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — não negar a própria experiência",
    "text": "Arrepender-se de suas próprias experiências é deter seu desenvolvimento. Negar suas próprias experiências é colocar uma mentira nos lábios da própria vida. Não é nada menos que negar a alma.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q128"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a nutrição da alma",
    "text": "Assim como o corpo absorve coisas de todas as espécies e as converte em rapidez, força e músculos, a alma também tem suas funções nutritivas. Pode transformar em nobres estados de pensamento aquilo que, em si mesmo, é vil, cruel e degradante, e revelar-se mais perfeitamente por meio do que pretendia destruí-la.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q129"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — depois da punição",
    "text": "Quando termina a punição de uma pessoa, a sociedade a deixa entregue a si mesma; isto é, abandona-a no exato momento em que começa seu mais alto dever para com ela. Envergonha-se de seus próprios atos e evita aqueles que puniu, como se evita um credor cuja dívida não se pode pagar.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q130"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — voltar a criar",
    "text": "No próprio fato de que as pessoas me reconhecerão onde quer que eu vá e conhecerão minha vida, ao menos suas loucuras, consigo discernir algo bom para mim. Isso me obrigará a afirmar-me novamente como artista, e tão logo quanto eu puder. Se eu produzir uma única obra de arte bela, poderei retirar da malícia seu veneno.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q131"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a atitude diante da vida",
    "text": "Se a vida é, como certamente é, um problema para mim, eu não sou menos um problema para a vida. As pessoas precisam adotar alguma atitude a meu respeito e, assim, julgar tanto a si mesmas quanto a mim. Em tudo isso, preocupo-me apenas com minha própria atitude mental diante da vida como um todo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q132"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — aprender a felicidade",
    "text": "Depois preciso aprender a ser feliz. Um dia eu sabia, ou pensava saber, por instinto. Houve um tempo em que era sempre primavera em meu coração. Meu temperamento era próximo da alegria. Enchi minha vida até a borda de prazer, como se enche uma taça de vinho. Agora me aproximo da vida de um ponto de vista inteiramente novo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q133"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — o instante e a duração",
    "text": "Pode-se compreender uma coisa num único instante e perdê-la nas longas horas seguintes, que passam com pés de chumbo. É tão difícil conservar as alturas que a alma é capaz de alcançar. Pensamos na eternidade, mas nos movemos lentamente através do tempo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q134"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — continuar apesar das quedas",
    "text": "Preciso aprender essas lições aqui, se é que vou aprendê-las em algum lugar, e encher-me de alegria se meus pés estiverem no caminho certo e meu rosto voltado para a porta chamada bela, ainda que eu caia muitas vezes na lama e me perca frequentemente na névoa.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q135"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a continuidade de uma nova vida",
    "text": "Essa nova vida, como às vezes gosto de chamá-la por meu amor a Dante, evidentemente não é uma vida nova, mas simplesmente a continuação, por meio do desenvolvimento e da evolução, de minha vida anterior. Quando estava em Oxford, eu dizia que queria comer dos frutos de todas as árvores do jardim do mundo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q136"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — o outro lado do jardim",
    "text": "Meu único erro foi limitar-me tão exclusivamente às árvores do lado do jardim que parecia banhado pelo sol, evitando o outro lado por suas sombras e escuridão. O fracasso, a pobreza, a tristeza, as lágrimas, o remorso e a consciência que condena eram coisas das quais eu tinha medo.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q137"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a vida artística",
    "text": "A vida artística é simplesmente desenvolvimento de si mesmo. A humildade no artista é sua aceitação franca de todas as experiências, assim como o amor no artista é o senso de beleza que revela ao mundo seu corpo e sua alma.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q138"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — a imaginação e a compaixão",
    "text": "Ele compreendia a lepra do leproso, a escuridão do cego, a terrível miséria daqueles que vivem para o prazer e a estranha pobreza dos ricos. Compreendia, em toda a esfera das relações humanas, aquela simpatia imaginativa que, na esfera da arte, é o único segredo da criação.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q139"
  },
  {
    "author": "Oscar Wilde",
    "source": "De profundis, edição de 1913 — encontrar uma amizade interior",
    "text": "Era a minha alma, em sua essência última, que eu havia alcançado. De muitas maneiras eu tinha sido seu inimigo, mas a encontrei esperando por mim como uma amiga. Quando alguém entra em contato com a alma, isso o torna simples como uma criança.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/cache/epub/921/pg921-images.html",
    "id": "q140"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — prefácio de 1862",
    "text": "Enquanto existir, por efeito das leis e dos costumes, uma condenação social que, em plena civilização, crie artificialmente infernos e complique com uma fatalidade humana o destino que é divino; enquanto a ignorância e a miséria existirem sobre a Terra, livros da natureza deste poderão não ser inúteis.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q141"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — a centelha que não se extingue",
    "text": "Não existe em toda alma humana, e não existia na alma de Jean Valjean em particular, uma primeira centelha, um elemento divino, incorruptível neste mundo e imortal no outro, que o bem pode desenvolver, avivar, acender e fazer brilhar, e que o mal jamais pode extinguir inteiramente?",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q142"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — a certeza de ser amado",
    "text": "A suprema felicidade da vida consiste na convicção de que se é amado; amado por si mesmo ou, melhor dizendo, amado apesar de si mesmo. Ser cuidado na aflição é ser acariciado. A alma procura outra alma às apalpadelas, e a encontra.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q143"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — as profundezas da consciência",
    "text": "Não há nada mais terrível do que essa espécie de contemplação. Em nenhum lugar o olhar do espírito encontra mais luz deslumbrante e mais sombra do que no ser humano; não pode fixar-se em nenhuma outra coisa mais formidável, mais complicada, mais misteriosa e mais infinita.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q144"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — o campo de batalha interior",
    "text": "Fazer o poema da consciência humana, mesmo que se tratasse de uma única pessoa, mesmo da mais humilde, seria fundir todas as epopeias numa epopeia superior e definitiva. A consciência é o caos das quimeras, dos desejos e das tentações; a fornalha dos sonhos; o esconderijo de ideias de que temos vergonha; o campo de batalha das paixões.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q145"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — o tumulto silencioso",
    "text": "A palavra nunca é um mistério mais magnífico do que quando vai do pensamento à consciência dentro de uma pessoa e retorna da consciência ao pensamento. Fala-se consigo mesmo, conversa-se consigo mesmo, exclama-se consigo mesmo sem romper o silêncio exterior: há um grande tumulto; tudo fala em nós, exceto a boca.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q146"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — respeitar outra crença",
    "text": "Diante de uma alma assim, só sentimos respeito. A consciência do justo deve ser aceita por sua palavra. Além disso, dadas certas naturezas, admitimos o desenvolvimento possível de todas as belezas da virtude humana dentro de uma crença diferente da nossa.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q147"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — a benevolência que transborda",
    "text": "O que era esse excesso de amor? Era uma benevolência serena que transbordava sobre as pessoas e, por vezes, estendia-se até às coisas. Ele vivia sem desdém. Era indulgente para com a criação. Toda pessoa, mesmo a melhor, guarda uma dureza irrefletida para os animais; o bispo não possuía essa dureza.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q148"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — a proteção entre as folhas",
    "text": "À noite, um vapor sonhador se desprendia do jardim e o envolvia. Ouvia-se o último chamado dos pássaros que adormeciam entre os ramos; sentia-se a intimidade sagrada das aves e das árvores. Durante o dia, as asas alegram as folhas; durante a noite, as folhas protegem as asas.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q149"
  },
  {
    "author": "Victor Hugo",
    "source": "Os miseráveis — o despertar da consciência",
    "text": "Qualquer que fosse Jean Valjean, ele era, sem dúvida, uma consciência que despertava. Havia começado alguma reabilitação misteriosa e, segundo todas as aparências, escrúpulos já governavam aquele homem havia muito tempo. Tais impulsos de justiça e bondade não são próprios de naturezas vulgares. Um despertar da consciência é grandeza de alma.",
    "note": "Excerto em tradução própria",
    "reference": "https://www.gutenberg.org/files/135/135-h/135-h.htm",
    "id": "q150"
  }
];
