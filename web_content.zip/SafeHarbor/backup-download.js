// Website 2 APK handles blob downloads, but not the desktop save-file picker.
// Keep chunks as Blobs: never join the complete backup into a JS string/base64.
let activeDownload=null;
export function usesDownload(){
 return Boolean(window.Website2APK)||/;\s*wv\)/i.test(navigator.userAgent)||typeof window.showSaveFilePicker!=='function';
}
export function downloadOutput(){
 const parts=[];let writes=0,closed=false;
 const name='SafeHarbor_backup_'+new Date().toISOString().replace(/[:.]/g,'-')+'.json';
 return {
  delivery:'download',
  async write(text){
   if(closed)throw Error('O arquivo de backup já foi finalizado.');
   parts.push(new Blob([text],{type:'application/json'}));
   if(++writes%16===0)await new Promise(resolve=>setTimeout(resolve,0));
  },
  async close(){
   if(closed)throw Error('O arquivo de backup já foi finalizado.');
   const file=new File(parts,name,{type:'application/json'});parts.length=0;closed=true;
   const url=URL.createObjectURL(file),link=document.createElement('a');
   link.href=url;link.download=name;link.textContent='Baixar backup novamente';link.className='backup-download';
   link.addEventListener('click',()=>{const status=document.querySelector('#backupProgress');if(status)status.textContent='Download solicitado. Aguarde a confirmação do Android e confira a pasta Downloads.';});
   // Keep the URL alive for asynchronous WebView download handlers and retries.
   // Older downloads remain valid until this page is closed; do not revoke on click.
   if(activeDownload)activeDownload.remove();activeDownload=link;
   const container=document.querySelector('#backupDownload');
   if(container){container.replaceChildren(link);container.hidden=false;}else document.body.append(link);
   link.click();
  },
  async abort(){parts.length=0;closed=true;}
 };
}
