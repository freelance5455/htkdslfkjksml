# SafeHarbor 1.6.6

## Exportação em APKs do Website 2 APK Builder

O fluxo anterior tentava usar o seletor de gravação do navegador quando o APK não oferecia a ponte nativa SafeHarbor. Em WebViews de conversores, a presença desse seletor não garante seu funcionamento: ele pode retornar AbortError sem abrir uma janela. A mensagem genérica mostrava apenas “Operação cancelada”.

Agora, quando o app identifica Website2APK ou um WebView Android, Exportar backup gera um arquivo local para download, com ou sem senha. Navegadores sem seletor também usam esse caminho. Se a identificação estiver oculta e o seletor falhar, aparece a alternativa Salvar por download. Cancelar a seleção no computador não dispara um download automático.

O formato do backup e a criptografia permanecem os mesmos. O arquivo é formado por Blobs em blocos, sem juntar todo o áudio em uma string JavaScript ou Base64 única. A URL do download permanece válida durante a sessão, para permitir o processamento assíncrono pelo APK e a opção Baixar backup novamente. A mensagem informa que o download foi solicitado; não declara que o Android concluiu a gravação sem receber essa confirmação.

A política de conteúdo permite ler URLs blob locais para o manipulador de download do conversor. Nenhum domínio externo foi liberado. No navegador do computador, o seletor agora abre antes da gravação assíncrona da posição do áudio. Falhas de seleção, abertura e gravação têm mensagens próprias.

Também foi sincronizada a lista de recursos permitidos pelo container Android próprio do projeto com os módulos atuais. Esse container é diferente do utilizado pelo Website 2 APK Builder; sua alteração não é utilizada pelo conversor.

## Como aplicar no seu APK

1. Extraia `SafeHarbor_Website2APK_1.6.6.zip` e use a pasta que contém `index.html` como a pasta HTML local do Website 2 APK Builder.
2. Gere uma atualização mantendo o mesmo nome de pacote e a mesma chave de assinatura do APK instalado; aumente o código da versão no conversor.
3. Instale como atualização, sem desinstalar nem limpar os dados do app, para manter o histórico existente.
4. Em Ajustes, exporte e aguarde a confirmação de download do Android. Confira o arquivo na pasta Downloads. Repita com senha para verificar ambas as opções no aparelho.

Se o instalador pedir para remover a versão anterior por incompatibilidade de assinatura, não remova: use a configuração/chave com que o APK atual foi gerado. O ZIP contém arquivos do app, não um APK já compilado.

## Verificação e limites

`tests/test_v166.py` usa Edge real com identificação Website2APK simulada e seletor propositalmente indisponível. Downloads reais, simples e protegidos, foram lidos do disco e restaurados; registro, áudio e marcador conferidos. Também passaram a repetição do download, leitura do Blob sob a CSP, WebView sem ponte, navegador sem seletor, alternativa manual após falha e erros de permissão. A regressão `tests/test_v16.py` passou.

`tests/test_backup_download_large.py` também passou: um áudio de 128 MiB foi exportado, baixado e restaurado nos dois modos. Backup simples: 179.031.655 bytes, exportação em 16,38 s e maior intervalo do monitor de interface de 41,4 ms. Backup protegido: 238.772.383 bytes, exportação em 26,8 s e maior intervalo de 62 ms. Esses tempos foram medidos no Edge local. Resultados em `tests/v166-download-large-results.json`.

O teste não executa o Website 2 APK Builder nem o APK do usuário: o download final e as permissões precisam ser conferidos no aparelho após gerar a atualização. O processamento que o conversor realiza internamente com Blobs grandes está fora do controle deste código; os resultados de desempenho do navegador não garantem o mesmo comportamento em todo aparelho.

Referências oficiais: [suporte/correções para Blob downloads](https://websitetoapk.com/download.html), [identificação e APIs Website2APK](https://websitetoapk.com/docs/javascript-apis.html) e [abertura do seletor durante o gesto do usuário](https://developer.chrome.com/docs/capabilities/web-apis/file-system-access).

VersionCode 14, versão 1.6.6. Nenhum APK compilado ou instalado nesta atualização.
