const PREFIX='safeharbor.draft.';
export function readDraft(date){try{const draft=JSON.parse(localStorage.getItem(PREFIX+date));return draft?.date===date?draft:null;}catch{return null;}}
export function saveDraft(form){
 if(!form)return;
 const date=form.dataset.draftDate,f=new FormData(form);
 const draft={date,dayNote:String(f.get('dayNote')??''),status:f.get('status'),period:f.get('period'),triggers:f.getAll('triggers'),updatedAt:Date.now()};
 for(const k of ['mood','energy','anxiety','urge','sleep'])draft[k]=Number(f.get(k));
 try{localStorage.setItem(PREFIX+date,JSON.stringify(draft));form.querySelector('[data-draft-status]').textContent='Rascunho salvo neste aparelho.';}
 catch{form.querySelector('[data-draft-status]').textContent='Não foi possível guardar o rascunho. Salve o check-in antes de sair.';}
}
export function removeDraft(date){localStorage.removeItem(PREFIX+date);}
