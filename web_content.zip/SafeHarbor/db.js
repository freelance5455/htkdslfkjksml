// Pedido iniciado antes da abertura do banco. O sistema pode recusá-lo.
export const persistence = navigator.storage?.persist ? navigator.storage.persist().catch(()=>false) : Promise.resolve(false);
// Versions 1–3 already exist in released APKs. Only add missing stores on upgrade.
// v1.7.1 retires blocking/camouflage, retaining v4 stores for existing data and backups.
export const DB_VERSION=4;
export const STORES=['settings','records','reports','quoteHistory','events','trophies','challenges','audio','audioMeta','staging','revisions','favorites','blockedApps','blockAttempts','privacy'];
let db;
export async function openDB(){db=await new Promise((resolve,reject)=>{const req=indexedDB.open('SafeHarbor',DB_VERSION);req.onupgradeneeded=()=>{const d=req.result;for(const name of STORES)if(!d.objectStoreNames.contains(name))d.createObjectStore(name,{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);req.onblocked=()=>reject(new Error('Feche outras janelas do SafeHarbor para atualizar o banco.'));});db.onversionchange=()=>{db.close();alert('Uma atualização está disponível. Feche e reabra o SafeHarbor.');};return db;}
export function transaction(names,fn){return new Promise((resolve,reject)=>{const tx=db.transaction(names,'readwrite');tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error??new Error('Operação cancelada.'));try{fn(tx);}catch(e){tx.abort();reject(e);}});}
export function get(name,id){return new Promise((resolve,reject)=>{const q=db.transaction(name).objectStore(name).get(id);q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});}
export function all(name){return new Promise((resolve,reject)=>{const q=db.transaction(name).objectStore(name).getAll();q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});}
export const put=(name,value)=>transaction([name],tx=>tx.objectStore(name).put(value));
export const remove=(name,id)=>transaction([name],tx=>tx.objectStore(name).delete(id));
export const clearStage=()=>transaction(['staging'],tx=>tx.objectStore('staging').clear());
export async function each(name,fn){let key;while(true){const row=await new Promise((resolve,reject)=>{const q=db.transaction(name).objectStore(name).openCursor(key===undefined?null:IDBKeyRange.lowerBound(key,true));q.onsuccess=()=>resolve(q.result?{key:q.result.key,value:q.result.value}:null);q.onerror=()=>reject(q.error);});if(!row)break;key=row.key;await fn(row.value);}}
export function mirror(value){try{localStorage.setItem('safeharbor.vitals',JSON.stringify({...value,updatedAt:Date.now()}));return true;}catch{return false;}}
