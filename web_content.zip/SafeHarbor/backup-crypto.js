// Streaming envelope: each piece and the final count are authenticated.
// Every export gets a new salt and IV prefix; the last 32 IV bits are a counter.
const FORMAT='SafeHarbor/Encrypted/1',ITERATIONS=600000,BLOCK=262144,MAX_LINE=2*1024*1024;
const encoder=new TextEncoder();
export const encode=bytes=>{let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);};
export const decode=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
async function keyFrom(password,salt){
 if(!password)throw Error('Informe a senha deste backup.');
 if(password.length>1024)throw Error('Senha longa demais.');
 const material=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveKey']);
 return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt,iterations:ITERATIONS},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
function params(prefix,index,header,final){
 if(!Number.isSafeInteger(index)||index<0||index>=0xffffffff)throw Error('Backup excedeu o limite de blocos.');
 const iv=new Uint8Array(12);iv.set(prefix);new DataView(iv.buffer).setUint32(8,index);
 return {name:'AES-GCM',iv,tagLength:128,additionalData:encoder.encode(header+'\n'+(final?'end:':'data:')+index)};
}
export async function protectedOutput(out,password){
 const salt=crypto.getRandomValues(new Uint8Array(16)),prefix=crypto.getRandomValues(new Uint8Array(8));
 const header=JSON.stringify({format:FORMAT,kdf:'PBKDF2-SHA256',iterations:ITERATIONS,salt:encode(salt),prefix:encode(prefix)});
 const key=await keyFrom(password,salt);let index=0;
 await out.write(header.slice(0,-1)+',"items":[\n');
 async function piece(bytes,final=false){
  const encrypted=await crypto.subtle.encrypt(params(prefix,index,header,final),key,bytes);
  await out.write(JSON.stringify({index:index++,final,data:encode(new Uint8Array(encrypted))})+(final?'\n]}':',\n'));
 }
 return {
  async write(text){const bytes=encoder.encode(text);for(let p=0;p<bytes.length;p+=BLOCK)await piece(bytes.subarray(p,p+BLOCK));},
  async close(){await piece(new Uint8Array(),true);await out.close();},
  abort:()=>out.abort()
 };
}
async function* rawLines(file){
 let rest='';const decoder=new TextDecoder('utf-8',{fatal:true});
 for(let p=0;p<file.size;p+=BLOCK){
  rest+=decoder.decode(await file.slice(p,p+BLOCK).arrayBuffer(),{stream:true});
  let i;while((i=rest.indexOf('\n'))>=0){if(i>MAX_LINE)throw Error('Linha de backup grande demais.');yield rest.slice(0,i);rest=rest.slice(i+1);}
  if(rest.length>MAX_LINE)throw Error('Linha de backup grande demais.');
 }
 rest+=decoder.decode();if(rest)yield rest;
}
export async function* backupLines(file,password=''){
 const source=rawLines(file),first=await source.next();if(first.done)throw Error('Backup vazio.');
 if(!first.value.startsWith('{"format":"'+FORMAT+'"')){yield first.value;yield* source;return;}
 let meta;try{meta=JSON.parse(first.value+']}');}catch{throw Error('Cabeçalho protegido inválido.');}
 if(meta.format!==FORMAT||meta.kdf!=='PBKDF2-SHA256'||meta.iterations!==ITERATIONS||typeof meta.salt!=='string'||typeof meta.prefix!=='string')throw Error('Proteção de backup desconhecida.');
 const salt=decode(meta.salt),prefix=decode(meta.prefix);if(salt.length!==16||prefix.length!==8)throw Error('Cabeçalho protegido inválido.');
 const header=JSON.stringify({format:FORMAT,kdf:meta.kdf,iterations:meta.iterations,salt:meta.salt,prefix:meta.prefix});
 const key=await keyFrom(password,salt),decoder=new TextDecoder('utf-8',{fatal:true});
 let index=0,finished=false,closed=false,rest='';
 for await(let line of source){
  line=line.trim();
  if(line===']}'){if(!finished||closed)throw Error('Backup protegido incompleto.');closed=true;continue;}
  if(closed||finished)throw Error('Conteúdo após o fim do backup.');
  const comma=line.endsWith(',');if(comma)line=line.slice(0,-1);
  const row=JSON.parse(line);
  if(row.index!==index||typeof row.final!=='boolean'||typeof row.data!=='string'||row.data.length>BLOCK*2||comma===row.final)throw Error('Bloco protegido fora de ordem.');
  let plain;try{plain=await crypto.subtle.decrypt(params(prefix,index++,header,row.final),key,decode(row.data));}catch{throw Error('Senha incorreta ou backup protegido alterado. Nenhum dado foi restaurado.');}
  if(row.final){if(plain.byteLength)throw Error('Final protegido inválido.');finished=true;rest+=decoder.decode();continue;}
  if(plain.byteLength>BLOCK)throw Error('Bloco protegido grande demais.');
  rest+=decoder.decode(plain,{stream:true});let i;
  while((i=rest.indexOf('\n'))>=0){if(i>MAX_LINE)throw Error('Linha de backup grande demais.');yield rest.slice(0,i);rest=rest.slice(i+1);}
  if(rest.length>MAX_LINE)throw Error('Linha de backup grande demais.');
 }
 if(!finished||!closed)throw Error('Backup protegido truncado. Nenhum dado foi restaurado.');
 if(rest)yield rest;
}
