# SafeHarbor 1.7.2 — correções de sequência e conquistas

## Correção do marco de 3 dias

Antes, abrir o app no terceiro dia gravava `bestEver = 3` antes do check-in. Registrar uma recaída zerava o contador atual, mas o máximo salvo nunca diminuía. O marco continuava aparecendo como conquistado anteriormente.

Agora o contador continua seguindo os dias civis desde o início ou a última recaída, começando em zero. Marcos, patentes e melhor sequência são confirmados somente quando existe um fechamento sem recaída que sustente aquela duração. O deslize continua sem reiniciar a sequência. Dias sem registro não são classificados automaticamente como vitórias nas taxas.

Exemplo: início dia 6; fechamentos sem recaída nos dias 7 e 8; dia 9 ainda sem fechamento → contador 3, melhor sequência confirmada 2, marco 3 bloqueado. Recaída no dia 9 → contador 0 e marco 3 continua bloqueado. Fechamento sem recaída no dia 9 → marco 3 confirmado. Alterar esse fechamento para recaída recalcula a conquista.

## Outros problemas corrigidos

- Troféus do desafio Eu consigo são reavaliados pelo fechamento da data-alvo. Trocar vitória por recaída ou deslize retira o prêmio correspondente; corrigir novamente permite recuperá-lo, sem duplicação. Corrigir um dia de desafio expirado também atualiza o resultado.
- Uma oferta de desafio ainda não aceita é cancelada quando uma correção elimina a condição que a originou. O critério para oferecer apoio continua sendo mais de três dias corridos antes da recaída, ou quatro dias difíceis consecutivos.
- Relatórios mensais são atualizados depois de recalcular os troféus e quando registros antigos mudam. A leitura e a data original de criação são preservadas.
- Restaurar um backup não conserva o maior número entre contadores antigos. O máximo é recalculado a partir dos registros mesclados; marcos e troféus indevidos não voltam após a restauração.
- O novo fechamento, a revisão e a melhor sequência são gravados na mesma transação, usando o estado posterior à edição. Uma falha de armazenamento não confirma a conquista.
- A validação de backup aceita somente os quatro status próprios do aplicativo, impedindo que nomes herdados de objetos JavaScript passem pela validação como status.

## Dados existentes e critérios

O banco continua na versão 4. Relatos, revisões, áudios, posições, eventos e demais dados pessoais não são apagados. A primeira abertura revalida as conquistas pelo último fechamento salvo de cada data. Marcos comprovados em sequências anteriores permanecem; valores antigos sem suporte no histórico podem voltar a ficar bloqueados. O máximo antigo fica registrado em `settings.progressMigration.previousBestEver` para rastreabilidade, sem conceder marcos.

A confirmação é por dias corridos, sem exigir check-in em todos os dias intermediários. Recaídas são consideradas pelo fechamento vigente de cada data, como já ocorria no aplicativo. Troféus legados sem um desafio correspondente são preservados, pois não existe informação suficiente para revalidá-los.

## Atualizar pelo Website 2 APK Builder

1. Extraia `SafeHarbor_Website2APK_1.7.2.zip` em uma nova pasta e selecione o `index.html` da raiz no conversor.
2. Mantenha o identificador do pacote, a assinatura e a origem/caminho local do APK já instalado. Aumente o código da versão no conversor.
3. Instale como atualização, sem desinstalar nem limpar os dados. As correções do histórico serão aplicadas ao abrir o app atualizado.

O ZIP contém o conteúdo web para gerar o APK. O pacote completo `SafeHarbor_1.7.2.zip` inclui fontes, container Android, documentação e testes. O container opcional tem `versionName=1.7.2` e `versionCode=17`. Não foi gerado um APK nesta entrega.

## Validação

O erro original foi reproduzido por um teste que falhou antes da correção. A nova suíte cobre os 15 marcos, recaída no dia do marco, correção no mesmo dia e retroativa, datas civis, sequência anterior válida, ausência de check-in e regras dos desafios.

Testes com Edge real, perfil isolado e dados fictícios exercitam os formulários, IndexedDB, restauração, relatórios, clique duplo, falha transacional de espaço, mudança de data e operação offline. Também foi executada a regressão geral de check-in, reflexões, gráficos, áudios, backups e migração de dados. Detalhes em `tests/VALIDACAO-1.7.2.md` e `tests/v172-results.json`.

Os testes web não substituem a verificação da WebView no aparelho. Nenhum APK foi compilado ou instalado em Android nesta atualização.
