# SafeHarbor 1.7.0 — Bloqueio de Apps e Modo Camuflagem

## O que mudou

- Botão de Bloqueio de Apps ao lado dos ajustes, com Instagram, TikTok, X/Twitter, Telegram e cadastro personalizado. Cada app tem horário crítico, chave de compromisso e ícone SVG local.
- Compromissos de 1h, 3h, 12h, 24h ou 3 dias; programação noturna, inicialmente 23h–06h. O estado e o prazo persistem ao fechar/reabrir. A programação é recalculada pelo horário local ao voltar ao app; não há serviço Android em segundo plano.
- Quarentena visual e contagem regressiva. Alterar horários ou remover um app em compromisso exige passar primeiro pelo desbloqueio.
- Desbloqueio antecipado com 120 segundos de resfriamento e guia de respiração, seguidos de justificativa de pelo menos 150 caracteres, sem colar ou arrastar texto. Desistir mantém o compromisso e registra uma única vitória por tentativa em Impulsos Superados. A tentativa pendente é retomada ao reabrir. O vencimento natural não exige justificativa nem gera vitória artificial.
- Guia local de Espaço Privado do Android 15 e Pasta segura/Moto Secure.
- Camuflagem configurável por PIN numérico de quatro dígitos, cadeado rápido na Home e calculadora funcional com operações básicas. Ao reabrir ou receber o evento de minimização, a interface interna, diálogos e avisos ficam ocultos e o áudio é pausado. Digite o PIN e toque em `=` para revelar o app.
- PIN armazenado como verificador PBKDF2 com sal aleatório, sem guardar o número em texto puro. Cinco códigos incorretos provocam espera de 30 segundos para nova tentativa de revelação. Alterar/desativar exige o PIN atual. Não há recuperação do PIN pelo aplicativo.
- A pausa guiada só faz perguntas após deslize ou recaída. Nos demais casos, “Estou em risco agora” mantém a nova reflexão e registra a pausa ao continuar, sem questionário. A reflexão pós-check-in continua exclusiva de recaída.

O tema preto/vermelho/branco, check-in unificado, calendário pt-BR, relatos, barras de métricas, marcos coloridos, desafio Eu consigo, relatórios, citações, biblioteca com imagens e player foram mantidos. Os cinco botões inferiores permanecem; os acessos novos ficam no cabeçalho.

## Migração e backups

O código encontrado já usava IndexedDB **versão 3**. Por isso, esta atualização usa **DB_VERSION = 4**: reduzir para 2 impediria abrir bancos já atualizados. O `onupgradeneeded` cria somente stores ausentes, acrescentando `blockedApps`, `blockAttempts` e `privacy`. Não apaga nem recria stores antigas. Migrações de versões 1 e 3 foram verificadas com registros e Blob de áudio, preservados após a abertura da versão 4.

Cadastros, compromissos, tentativas e vitórias entram no backup existente. Uma restauração preserva compromissos ativos e tentativas que já existem no aparelho. Os backups antigos continuam aceitos. O PIN e sua configuração ficam somente no aparelho e **não entram no backup**; restaurar um backup não desativa uma camuflagem já configurada. Em outro aparelho, configure o PIN novamente.

## Usar no Website 2 APK Builder

1. Extraia **SafeHarbor_Website2APK_1.7.0.zip** e selecione a pasta que contém `index.html` como conteúdo HTML local no conversor. Todos os 22 recursos necessários estão na raiz desse pacote.
2. Mantenha o mesmo identificador de pacote, chave de assinatura e configuração de origem/caminho do conteúdo local do APK instalado. Aumente o código de versão no conversor.
3. Instale a atualização sobre o aplicativo existente, sem desinstalar e sem limpar seus dados. Se houver conflito de assinatura, use a chave original; remover o app apagaria seu armazenamento local.
4. Confira histórico e biblioteca no aparelho. Teste exportação com e sem senha, configure o PIN e confira a calculadora ao minimizar e reabrir. A entrega contém os arquivos web e o código-fonte; **não é um APK compilado**.

O pacote **SafeHarbor_1.7.0.zip** contém o projeto completo, documentação, testes e o container Java opcional. Esse container tem versionCode 15/versionName 1.7.0 e inclui os novos módulos na lista de assets. Quem usa Website 2 APK Builder deve usar o pacote web e a assinatura do próprio APK atual.

## Limites importantes para esta implementação

O bloqueador é **comportamental dentro do SafeHarbor**. JavaScript dentro do APK do conversor não impede abrir outros aplicativos nem muda seus ícones ou notificações. A mensagem de quarentena descreve o estado interno; o bloqueio/ocultação real depende da configuração manual do Android indicada no guia. Cópias de um aplicativo fora do Espaço Privado continuam acessíveis. Prazos usam o relógio do aparelho e não são proteção contra alteração deliberada do sistema ou dos dados locais.

A camuflagem cobre a interface interna, sem trocar nome/ícone do APK no launcher nem criptografar o histórico. A miniatura na tela de aplicativos recentes, tela de abertura e entrega dos eventos de minimização dependem do container do conversor e precisam ser verificadas no celular. O PIN de quatro dígitos é uma barreira de acesso à interface, não uma garantia contra inspeção do armazenamento.

Fontes do guia: [Espaço Privado — Ajuda do Android](https://support.google.com/android/answer/15341885?hl=en-GB), [Moto Secure — Motorola](https://en-us.support.motorola.com/app/answers/detail/a_id/177888/~/moto-secure) e [Pasta segura — Motorola em português](https://help.motorola.com/hc/3555/14/global/pt-br/CG1542955260.html). O guia está incorporado ao app e funciona offline.

## Validação

Testes em Edge real, com perfis isolados e dados fictícios: cadastros, prazos persistentes, bloqueio noturno, resfriamento com relógio de teste, 149/150 caracteres, paste/drop, cancelamento único, vencimento natural, PIN, calculadora, recarga, minimizações repetidas, diálogos ocultos e layout nas sete seções em 320, 393, 768 e 1280 px, além de paisagem.

Também passaram migrações 1→4 e 3→4, restauração sem duplicar vitórias, backups simples/protegidos, regressão dos check-ins/relatórios/conquistas/reflexões, capas e player. Um WAV de **1.100.000.044 bytes** foi importado, reproduzido e percorrido com marcadores; maior intervalo observado no monitor da interface: **40,5 ms** no computador. Não foi um ensaio de reprodução contínua de toda a duração nem uma medição no Android.

Registros detalhados em `tests/VALIDACAO.md`, `tests/v170-results.json`, `tests/v170-data-results.json` e `tests/large-audio-results.json`. Nenhum APK foi compilado ou testado no aparelho nesta entrega.
