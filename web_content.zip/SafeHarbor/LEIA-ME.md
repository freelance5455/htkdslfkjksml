# SafeHarbor · projeto local para APK

**Versão atual: 1.7.2.** Veja [as correções de lógica desta versão](ATUALIZACAO-1.7.2.md) e [as funcionalidades, validação e limites da versão 1.6](ATUALIZACAO-1.6.md). Marcos e patentes exigem confirmação por check-in; correções e backups recalculam conquistas e relatórios. Bloqueio de Apps e Modo Camuflagem continuam removidos.

Interface integralmente em português do Brasil. HTML, CSS, JavaScript, ícone e container Android incluídos. Não há bibliotecas de execução, fontes remotas, CDN, login, telemetria, servidor de aplicação, conta na nuvem ou dependência de GitHub.

## Atualização 1.1

Fechamento e período usam opções desenhadas em CSS local, sem menus nativos. Os gráficos têm fundo grafite, texto cinza-claro e séries vermelhas/prateadas. O relato do dia é opcional. A página inicial mantém uma reflexão visível, com autor e referência; a seleção respeita o mesmo histórico de 45 dias dos diálogos. A leitura selecionada permanece disponível ao voltar à Home. Quando o catálogo estiver indisponível, a última reflexão permanece até haver uma nova elegível.

Cada salvamento guarda uma versão na store `revisions`, mas a store `records` mantém somente o último fechamento de cada data. As métricas leem apenas `records`. As versões estão em “Registros deste dia”, abaixo do formulário, e entram no backup. Registros legados passam a ter uma cópia histórica na primeira edição. Horários antigos são convertidos na leitura: madrugada 0–5h59; manhã 6–11h59; tarde 12–17h59; noite 18–23h59. O banco migra sem apagar dados. Desde a versão 1.7.2, o conteúdo dos relatórios e as conquistas são revalidados quando um fechamento muda; relatos e revisões anteriores permanecem guardados.

## O que está neste pacote

- `index.html`, `styles.css`, `app.js`: interface e fluxos.
- `domain.js`: datas civis, sequências, métricas e relatórios.
- `db.js`: IndexedDB versão 4, histórico de revisões, pedido de persistência e espelho leve.
- `blocker-domain.js`: compatibilidade com dados legados de backups da 1.7.0; sem módulo de bloqueio ativo.
- `backup.js`: JSON completo com áudios em blocos, SHA-256 por bloco, área temporária de validação e importação transacional.
- `quotes.js`: 150 excertos identificados por obra/seção, em tradução própria. Camus aparece somente em trecho breve; veja FONTES.md.
- `charts.js`: gráficos Canvas sem bibliotecas.
- `manifest.json`, `icon.png`: identidade local, ícone de 512 × 512 criado em Python/Pillow.
- `android/`: container Java sem AndroidX e sem permissão de internet; compilador PowerShell sem Gradle/Maven.
- `tests/`: testes e registro de validação, quando disponível.

## Gerar o APK sem acesso à rede

O projeto está pronto para compilação; o ZIP não substitui um APK compilado e assinado. A máquina de compilação precisa ter previamente JDK 17, Android SDK Platform 35 e Build Tools 35.0.0. Essas são ferramentas de compilação, não dependências de rede do aplicativo. Se já estiverem instaladas, o script não baixa nada. Não inclui SDK ou JDK no ZIP.

No aparelho: Android 8 ou superior e Android System WebView compatível com Chromium 105 ou superior, já instalado antes de ficar offline. O app não instala nem atualiza componentes do sistema.

No PowerShell, a partir de `android/`:

```powershell
.\build_offline.ps1 -SdkRoot 'C:\Android\Sdk' -JavaHome 'C:\Java\jdk-17'
```

O script imprime o caminho de `SafeHarbor.apk`. Instale-o pelo gerenciador de arquivos do Android ou, com depuração USB autorizada, use `adb install -r CAMINHO_DO_APK`.

**Atualizações:** preserve `br.local.safeharbor`, a origem interna `https://safeharbor.invalid/` e a chave `android/safeharbor-local.keystore`. A origem é sintética, interceptada pela WebView e atendida exclusivamente pelos assets do APK: não existe servidor nesse endereço. Aumente `android:versionCode` a cada versão distribuída. Instale sobre o app existente; não o desinstale. A chave criada pelo script tem senha local conhecida `safeharbor-local`, apropriada para uso pessoal; armazene a chave em local protegido. Para distribuição, adote sua própria chave e política de assinatura.

## Regras e limites reais

- Sequência: dias civis desde a data inicial ou última recaída, começando em zero. Deslize não zera a sequência. O contador pode avançar sem registro, mas marcos, patentes e melhor sequência só são confirmados por um fechamento sem recaída. Não é necessário preencher todos os dias intermediários para confirmar os dias corridos. Dias ausentes continuam separados nas taxas. O último fechamento de cada data prevalece; uma correção pode retirar o marco que dependia daquele dia, preservando os comprovados em outras sequências.
- A data inicial é provisoriamente o primeiro dia de uso; pode ser definida uma vez. Depois de salva, a flag bloqueia a edição e uma restauração não contorna esse bloqueio. Limpar/desinstalar o app elimina também a flag: nenhum dado local é permanente contra destruição do armazenamento.
- O evento “Venci este impulso” é uma sessão independente. “Resistiu a impulso” no check-in representa outro fechamento declarado. Editar um mesmo check-in não duplica seu contador.
- O desafio é oferecido após recaída com mais de três dias corridos de sequência ou quatro dias civis consecutivos difíceis. Aceitar define o dia seguinte como alvo. Fechamento bem gerido ou impulso superado no alvo concede um único troféu; sem registro ou com lapso/recaída, não há prêmio. Corrigir o fechamento reavalia o troféu, inclusive em desafio expirado. Uma oferta ainda não aceita é cancelada se a correção retirar sua condição de origem. A oferta de apoio não concede marcos.
- Relatórios são gerados na próxima abertura do app depois da virada do mês, sem serviço em segundo plano. Abrir um relatório marca a leitura e o arquiva no calendário. Correções retroativas e restaurações atualizam o conteúdo, incluindo troféus, preservando a data de criação e o estado de leitura.
- Reflexões pós-check-in aparecem somente em recaída. “Estou em risco agora” também apresenta uma nova reflexão, diferente da atual na Home. Cada excerto fica indisponível por 45 × 24 horas após a exibição. Se o catálogo se esgotar, o fluxo continua sem repetir frases. O botão Continuar é obrigatório; Esc/Voltar não fecham a citação. Na versão 1.7.0, perguntas da pausa guiada aparecem somente quando há deslize ou recaída; nos demais casos, a pausa é apenas registrada após a reflexão.
- Áudios são `Blob/File` no IndexedDB, sem conversão base64 no armazenamento principal e sem limite artificial de tamanho. O limite efetivo é o espaço/cota do Android e do WebView. Arquivos maiores que 1 GB não têm garantia universal: exigem validação no aparelho real. Codecs dependem do WebView. O player persiste a posição a cada segundo, ao pausar e ao buscar. Encerramento abrupto pode perder o último intervalo de gravação. A reprodução em segundo plano não é um serviço nativo; ao sair do APK, o áudio é pausado.
- `navigator.storage.persist()` é solicitado no início; a concessão depende da plataforma. Não protege contra limpeza manual, desinstalação, falha física ou perda do aparelho. O espelho em localStorage tem somente métricas e não recria todo o histórico.
- Backup JSON em texto claro inclui dados sensíveis e os próprios áudios, codificados em blocos base64 de 256 KiB. Reserve aproximadamente 1,34× o tamanho dos áudios para exportar. A importação necessita espaço temporário adicional para validar e montar os blobs antes da transação final. Os hashes detectam corrupção dos blocos, não autenticam o autor do arquivo.
- A restauração mescla identificações: substitui registros correspondentes, preserva os demais. Leitura de relatórios, datas de citações mais recentes e bloqueio inicial existentes são preservados. Backups de versões futuras desconhecidas são rejeitados. Exportação streaming funciona no APK e em navegadores de computador com File System Access API. Não há fallback que monte um JSON gigante inteiro na memória.
- Privacidade local não significa criptografia própria. O APK bloqueia rede e capturas de tela, e desativa backup automático do Android; os dados dependem da proteção do sistema e do bloqueio do aparelho. Provedores e políticas de fabricantes devem ser verificados no dispositivo de uso.

## Evolução do banco

Para adicionar uma store: acrescente seu nome em `STORES`, incremente `DB_VERSION` e mantenha o laço que cria apenas stores ausentes. Nunca apague/recrie o banco para migrar. Campos novos devem ter valores padrão de leitura, como em `normalize()`. Migrações que transformem registros devem ser incrementais, dentro da transação de upgrade, e testadas contra um backup real. Uma versão antiga do aplicativo não deve ser reinstalada sobre um banco com versão superior.

O contrato de backup também é versionado (`SafeHarbor/1`). Ao mudar formato ou tipos de registros, adicione leitores para formatos antigos e migre sem perda. A store `staging` é temporária e não é exportada.

## Prévia e testes

Para desenvolvimento no computador, sirva esta pasta por HTTP local (por exemplo, `python -m http.server 8765 --bind 127.0.0.1`) e abra `http://127.0.0.1:8765`. Isso é apenas uma ferramenta de prévia: o APK não usa servidor. Não use duplo clique em `index.html`, pois módulos e IndexedDB em `file://` variam entre navegadores. O navegador de prévia mantém dados separados dos dados do APK.

`node tests/domain.test.js` verifica regras de negócio. Testes de navegador usam dados artificiais e perfil temporário. Consulte `tests/VALIDACAO.md` para resultados e lacunas; não considere uma compilação Android ou teste de 1 GB realizado sem esse registro.


## Atualização 1.2

O formulário diário tem apenas um campo narrativo, Sobre seu dia, que pode ficar vazio em qualquer fechamento. Revisões antigas permanecem no histórico e no backup, sem reaparecer como campos obrigatórios.

A cada abertura da página/aplicativo, a reflexão aparece primeiro na Home. Seu tempo de leitura é estimado em 2,4 palavras por segundo, entre 15 e 60 segundos. O contador só avança com a página visível e a reflexão na área de leitura; sair da aba ou abrir um diálogo pausa a contagem. Ao terminar, a reflexão volta à posição inferior e a sequência ganha destaque. “Já li, continuar” antecipa essa mudança sem bloquear outras funções.

A biblioteca permite importar uma pasta inteira como livro, incluindo subpastas, mantendo o caminho dos capítulos. A ordem é alfabética em pt-BR (não numérica natural); prefixos 01, 02, 03 ajudam a ordenar capítulos. O fim da reprodução marca Concluído e inicia o próximo capítulo do mesmo livro. É possível marcar ou desmarcar manualmente, ver o progresso e excluir um capítulo, vários selecionados ou todo o livro. Exclusão afeta somente as cópias no app; a pasta original não é modificada. Marcadores e agrupamento também entram no backup. A importação prepara todos os capítulos antes da transação final; se falhar, não publica um livro parcial.

No APK, a seleção da pasta usa o Storage Access Framework do Android e leitura em fluxo dos URIs escolhidos. Não solicita acesso geral ao armazenamento. A interface de navegador usa webkitdirectory. O Android pode impedir a escolha da raiz, Downloads ou Android/data: escolha uma subpasta acessível, como Documentos/MeuLivro. Arquivos grandes dependem da cota e do espaço disponível, inclusive espaço temporário na importação. A ponte nativa nova ainda requer ensaio em aparelho; os testes de navegador não substituem esse ensaio.

## Versão 1.3
A reflexão abre no topo apenas na primeira visita à Home por data local. Essa visita é marcada imediatamente no armazenamento local, inclusive se o app fechar antes de um minuto. Nas demais visitas, aparece abaixo. O tempo é fixo de 60 segundos, sem contador. A pausa guiada tem duas perguntas não obrigatórias. Os relatos são acumulados e a caixa de novo relato sempre abre vazia; só as métricas mais recentes aparecem no formulário. Versões históricas antigas continuam no backup para evitar perda de dados, mas não poluem a interface. O player possui linha de progresso e modo expandido dentro do app, com controles de reduzir e Voltar/Escape. A duração de cada arquivo fica disponível após a primeira reprodução.

## Versão 1.4
O player usa somente a barra de progresso do aplicativo, com botão próprio para reproduzir/pausar. No modo expandido, o título é centralizado e reduzir/fechar são ícones no canto superior. Áudios avulsos são exibidos por data de adição, com os mais recentes primeiro; pastas mantêm capítulos em ordem alfabética. A ordenação não é anunciada na interface.

## Versão 1.5.1
Ao tocar em “Estou em risco agora”, uma nova reflexão aparece antes da pausa guiada. O botão “Continuar” inicia a primeira etapa. A seleção exclui a reflexão atual da Home e compartilha o histórico de 45 dias das demais reflexões. Se não houver texto elegível, a pausa começa diretamente, sem repetir frases. O áudio é pausado ao entrar nesse fluxo. A reflexão após recaída mantém seu comportamento anterior. Nenhuma alteração visual ou funcional adicional foi incluída.

## Versão 1.5
Reflexões pós-check-in aparecem somente em recaída e excluem explicitamente a reflexão atual da Home, respeitando 45 dias sem repetição. Se o catálogo elegível se esgotar, nenhuma frase repetida é exibida. O calendário abre dias finalizados em relatório somente para leitura, com últimas métricas e todos os relatos. Novos check-ins continuam disponíveis na aba Check-in. Adicionado marco de 1 dia; seletores de áudio em vermelho claro e biblioteca avulsa denominada Audiobooks. A conclusão automática ao terminar cada áudio permanece ativa.
