param(
 [string]$SdkRoot=$env:ANDROID_SDK_ROOT,
 [string]$JavaHome=$env:JAVA_HOME,
 [string]$Platform='android-35',
 [string]$BuildTools='35.0.0'
)
$ErrorActionPreference='Stop'
if(-not $SdkRoot -or -not $JavaHome){throw 'Informe -SdkRoot e -JavaHome. Veja LEIA-ME.md.'}
$root=Split-Path -Parent $PSScriptRoot
$sdk=(Resolve-Path -LiteralPath $SdkRoot).Path
$jdk=(Resolve-Path -LiteralPath $JavaHome).Path
$bt=Join-Path $sdk "build-tools/$BuildTools"
$jar=Join-Path $sdk "platforms/$Platform/android.jar"
foreach($f in @($jar,"$bt/aapt2.exe","$bt/d8.bat","$bt/zipalign.exe","$bt/apksigner.bat","$jdk/bin/javac.exe","$jdk/bin/keytool.exe","$jdk/bin/jar.exe")){if(-not(Test-Path -LiteralPath $f)){throw "Ferramenta ausente: $f"}}
$out=Join-Path $PSScriptRoot ('build/'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Force $out,"$out/gen","$out/classes","$out/dex","$out/assets" | Out-Null
foreach($name in @('index.html','styles.css','refinements.css','app.js','db.js','domain.js','backup.js','quotes.js','charts.js','manifest.json','icon.png','reflection.js','audio-library.js','drafts.js','audio-controls.js','backup-crypto.js','milestone-art.js','audio-art.js','backup-download.js','blocker-domain.js')){Copy-Item -LiteralPath (Join-Path $root $name) -Destination "$out/assets/$name"}
function Run-Tool([string]$Executable,[string[]]$Arguments){& $Executable @Arguments;if($LASTEXITCODE -ne 0){throw "Falha ao executar $Executable (código $LASTEXITCODE)"}}
$env:JAVA_HOME=$jdk
Run-Tool "$bt/aapt2.exe" @('compile','--dir',"$PSScriptRoot/res",'-o',"$out/resources.zip")
Run-Tool "$bt/aapt2.exe" @('link','-o',"$out/base.apk",'-I',$jar,'--manifest',"$PSScriptRoot/AndroidManifest.xml",'--java',"$out/gen",'-A',"$out/assets",'--min-sdk-version','26','--target-sdk-version','34',"$out/resources.zip")
$sources=@(Get-ChildItem -LiteralPath "$PSScriptRoot/src","$out/gen" -Recurse -Filter '*.java' | ForEach-Object {$_.FullName})
Run-Tool "$jdk/bin/javac.exe" (@('-encoding','UTF-8','-source','8','-target','8','-classpath',$jar,'-d',"$out/classes")+$sources)
Run-Tool "$jdk/bin/jar.exe" @('cf',"$out/classes.jar",'-C',"$out/classes",'.')
Run-Tool "$bt/d8.bat" @('--lib',$jar,'--min-api','26','--output',"$out/dex","$out/classes.jar")
Copy-Item -LiteralPath "$out/base.apk" -Destination "$out/unsigned.apk"
Run-Tool "$jdk/bin/jar.exe" @('uf',"$out/unsigned.apk",'-C',"$out/dex",'classes.dex')
Run-Tool "$bt/zipalign.exe" @('-f','4',"$out/unsigned.apk","$out/aligned.apk")
$key=Join-Path $PSScriptRoot 'safeharbor-local.keystore'
if(-not(Test-Path -LiteralPath $key)){Run-Tool "$jdk/bin/keytool.exe" @('-genkeypair','-keystore',$key,'-storepass','safeharbor-local','-keypass','safeharbor-local','-alias','safeharbor','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=SafeHarbor Local','-noprompt')}
Run-Tool "$bt/apksigner.bat" @('sign','--ks',$key,'--ks-key-alias','safeharbor','--ks-pass','pass:safeharbor-local','--key-pass','pass:safeharbor-local','--out',"$out/SafeHarbor.apk","$out/aligned.apk")
Run-Tool "$bt/apksigner.bat" @('verify','--verbose',"$out/SafeHarbor.apk")
Write-Output "APK gerado: $out/SafeHarbor.apk"
Write-Output 'Guarde a chave safeharbor-local.keystore: atualizações precisam da mesma assinatura.'
