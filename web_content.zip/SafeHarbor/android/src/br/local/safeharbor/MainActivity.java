package br.local.safeharbor;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.view.WindowManager;
import android.provider.DocumentsContract;
import android.database.Cursor;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ConcurrentHashMap;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class MainActivity extends Activity {
    private static final String ORIGIN="https://safeharbor.invalid/";
    private static final int CHOOSE_FILE=101, SAVE_BACKUP=102, CHOOSE_AUDIO_FOLDER=103;
    private WebView web;
    private ValueCallback<Uri[]> files;
    private final Bridge bridge=new Bridge();
    private static final Set<String> ASSETS=new HashSet<>(Arrays.asList("index.html","styles.css","app.js","db.js","domain.js","backup.js","quotes.js","charts.js","manifest.json","icon.png","reflection.js","audio-library.js","refinements.css","drafts.js","audio-controls.js","backup-crypto.js","milestone-art.js","audio-art.js","backup-download.js","blocker-domain.js"));

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(0xff0a0a0a);
        getWindow().setNavigationBarColor(0xff101010);
        web=new WebView(this);
        web.setBackgroundColor(0xff0a0a0a);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setBlockNetworkLoads(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        WebView.setWebContentsDebuggingEnabled(false);
        web.addJavascriptInterface(bridge,"SafeHarborNative");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith(ORIGIN);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if(!"https".equals(uri.getScheme())||!"safeharbor.invalid".equals(uri.getHost())) return denied();
                String path=uri.getPath();
                String file=(path==null||path.equals("/"))?"index.html":path.substring(1);
                if(file.startsWith("import-audio/")){String token=file.substring("import-audio/".length());Uri source=bridge.folderFiles.get(token);if(source==null)return denied();try{InputStream input=getContentResolver().openInputStream(source);if(input==null)return denied();return new WebResourceResponse("application/octet-stream",null,input);}catch(Exception e){return denied();}}
                if(!ASSETS.contains(file)) return denied();
                String mime=file.endsWith(".js")?"text/javascript":file.endsWith(".css")?"text/css":file.endsWith(".png")?"image/png":file.endsWith(".json")?"application/json":"text/html";
                try {return new WebResourceResponse(mime,"UTF-8",getAssets().open(file));}catch(IOException e){return denied();}
            }
            private WebResourceResponse denied(){return new WebResourceResponse("text/plain","UTF-8",403,"Bloqueado",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(files!=null)files.onReceiveValue(null);
                files=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
                String[] types=params.getAcceptTypes();
                if(types!=null&&types.length>0&&!types[0].isEmpty())intent.putExtra(Intent.EXTRA_MIME_TYPES,types);
                try {startActivityForResult(Intent.createChooser(intent,"Escolha um arquivo local"),CHOOSE_FILE);}catch(Exception e){files.onReceiveValue(null);files=null;}
                return true;
            }
        });
        setContentView(web);
        web.loadUrl(ORIGIN+"index.html");
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==CHOOSE_FILE&&files!=null){files.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);files=null;}
        if(request==CHOOSE_AUDIO_FOLDER){if(result!=RESULT_OK||data==null||data.getData()==null){folderEvent("{\"cancelled\":true}");}else{final Uri tree=data.getData();new Thread(()->{try{bridge.clearAudioFolder();JSONArray entries=new JSONArray();String rootId=DocumentsContract.getTreeDocumentId(tree);collectAudio(tree,rootId,"",entries,new HashSet<String>());JSONObject payload=new JSONObject();payload.put("files",entries);String name="Audiolivro";Uri root=DocumentsContract.buildDocumentUriUsingTree(tree,rootId);try(Cursor c=getContentResolver().query(root,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}payload.put("folderName",name);folderEvent(payload.toString());}catch(Exception e){bridge.clearAudioFolder();folderEvent("{\"error\":\"Não foi possível ler a pasta. Escolha uma pasta local com arquivos de áudio.\"}");}},"SafeHarborPasta").start();}}
        if(request==SAVE_BACKUP){boolean ok=false;if(result==RESULT_OK&&data!=null){try{bridge.open(data.getData());ok=true;}catch(Exception ignored){bridge.abortExport();}}final boolean ready=ok;web.evaluateJavascript("window.dispatchEvent(new CustomEvent('backupDestination',{detail:"+ready+"}))",null);}
    }
    @Override public void onBackPressed(){web.evaluateJavascript("window.safeHarborBack ? window.safeHarborBack() : false",value->{if("false".equals(value))moveTaskToBack(true);});}
    @Override protected void onPause(){web.evaluateJavascript("document.dispatchEvent(new Event('safeharborPause'))",null);super.onPause();}
    @Override protected void onDestroy(){bridge.abortExport();if(files!=null){files.onReceiveValue(null);files=null;}web.removeJavascriptInterface("SafeHarborNative");web.destroy();super.onDestroy();}


    private void folderEvent(String json){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())web.evaluateJavascript("window.dispatchEvent(new CustomEvent('audioFolderChosen',{detail:"+json+"}))",null);});}
    private void collectAudio(Uri tree,String parent,String prefix,JSONArray entries,Set<String> visited)throws Exception{
        if(!visited.add(parent))return;
        if(visited.size()>2000)throw new IOException("Muitas pastas");
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
        try(Cursor c=getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
            if(c==null)throw new IOException("Pasta indisponível");
            while(c.moveToNext()){String id=c.getString(0),name=c.getString(1),mime=c.getString(2);String path=prefix+name;
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){collectAudio(tree,id,path+"/",entries,visited);}
                else if(name.toLowerCase(Locale.ROOT).matches(".*\\.(mp3|m4a|m4b|aac|ogg|opus|wav|flac|weba|webm)$")){
                    if(entries.length()>=10000)throw new IOException("Muitos arquivos");
                    String token=UUID.randomUUID().toString();bridge.folderFiles.put(token,DocumentsContract.buildDocumentUriUsingTree(tree,id));JSONObject row=new JSONObject();row.put("nativeToken",token);row.put("relativePath",path);row.put("name",name);entries.put(row);
                }
            }
        }
    }
    public final class Bridge {
        private final Map<String,Uri> folderFiles=new ConcurrentHashMap<>();
        @JavascriptInterface public void clearAudioFolder(){folderFiles.clear();}
        @JavascriptInterface public void chooseAudioFolder(){runOnUiThread(()->{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.putExtra(Intent.EXTRA_LOCAL_ONLY,true);try{startActivityForResult(intent,CHOOSE_AUDIO_FOLDER);}catch(Exception e){folderEvent("{\"error\":\"O seletor de pastas não está disponível neste aparelho.\"}");}});}

        private OutputStream output;
        private Uri destination;
        @JavascriptInterface public void beginExport(){runOnUiThread(()->{Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,"SafeHarbor_backup.json");intent.putExtra(Intent.EXTRA_LOCAL_ONLY,true);try{startActivityForResult(intent,SAVE_BACKUP);}catch(Exception e){web.evaluateJavascript("window.dispatchEvent(new CustomEvent('backupDestination',{detail:false}))",null);}});}
        synchronized void open(Uri uri)throws IOException{abortExport();destination=uri;output=getContentResolver().openOutputStream(uri,"wt");if(output==null)throw new IOException("Arquivo indisponível");}
        @JavascriptInterface public synchronized String writeExport(String text){try{if(output==null)throw new IOException();if(text.length()>1048576)throw new IOException();output.write(text.getBytes(StandardCharsets.UTF_8));return "";}catch(Exception e){return "Não foi possível gravar o backup. Verifique o espaço disponível.";}}
        @JavascriptInterface public synchronized String finishExport(){try{if(output==null)throw new IOException();output.flush();output.close();output=null;destination=null;return "";}catch(Exception e){return "Não foi possível finalizar o backup.";}}
        @JavascriptInterface public synchronized void abortExport(){try{if(output!=null)output.close();}catch(Exception ignored){}output=null;if(destination!=null){try{DocumentsContract.deleteDocument(getContentResolver(),destination);}catch(Exception ignored){}destination=null;}}
    }
}
