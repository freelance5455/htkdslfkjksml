/**
 * Mizo_q TikTok Toolkit — Unfollow Manager V6.0 Content Script (content.js)
 *
 * Key V6.0 Enhancements:
 * 1. Event-Driven CAPTCHA & Verification Resolution Watcher:
 *    Uses a lightweight MutationObserver (with fallback timer) to detect when the user
 *    completes manual verification without wasteful continuous DOM polling on Android.
 *    Never attempts to solve or bypass CAPTCHAs.
 * 2. Android / Quetta Browser Lifecycle & App-Switching Detection:
 *    Listens to visibilitychange to notify background.js when the user switches to another
 *    Android app or returns to the browser.
 * 3. Mobile DOM CSV Download Fallback (TRIGGER_DOM_CSV_DOWNLOAD):
 *    Provides a direct Blob <a download> save flow when mobile browsers restrict
 *    background service worker chrome.downloads calls.
 * 4. Preserves V4 DOM change fingerprinting, virtualized scrolling, and 6-step mutual verification.
 */

'use strict';

(function () {
  if (window.__TIKTOK_UNFOLLOWER_V5_CONTENT_LOADED__) return;
  window.__TIKTOK_UNFOLLOWER_V5_CONTENT_LOADED__ = true;

  let cachedListContainer = null;
  let lastDomFingerprint = '';
  let lastVisibleAccountsSnapshot = [];
  let captchaWatcherTimer = null;
  let captchaMutationObserver = null;

  const discoveredAccountsMap = new Map();

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function isElementVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.isConnected === false) return false;
    if (el.hidden || el.getAttribute('aria-hidden') === 'true') return false;
    const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
    if (style && (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0')) {
      return false;
    }
    return true;
  }

  /**
   * Detect CAPTCHA puzzles, verification dialogs, or rate-limit notifications.
   * Distinguishes 'verification_required' vs 'rate_limited'.
   */
  function detectSecurityChallenge() {
    const captchaSelectors = [
      '#captcha-verify-image',
      '.captcha_verify_container',
      '[id*="captcha-verify"]',
      '[class*="captcha-verify"]',
      '.secsdk-captcha-wrapper',
      '[data-e2e="captcha-modal"]',
      'iframe[src*="captcha"]'
    ];

    for (const sel of captchaSelectors) {
      const el = document.querySelector(sel);
      if (el && isElementVisible(el)) {
        return {
          detected: true,
          type: 'verification_required',
          message: 'TikTok verification challenge (CAPTCHA) detected. Processing paused immediately — please complete verification manually in the browser.'
        };
      }
    }

    const toastSelectors = [
      '[data-e2e="toast-message"]',
      '[role="alert"]',
      '[class*="DivToast"]',
      '[class*="ToastContainer"]',
      '.tiktok-toast'
    ];

    const rateLimitPatterns = [
      /following\s+too\s+fast/i,
      /unfollowing\s+too\s+fast/i,
      /operating\s+too\s+frequently/i,
      /try\s+again\s+later/i,
      /too\s+many\s+requests/i,
      /rate\s+limit/i,
      /action\s+blocked/i
    ];

    const verificationPatterns = [
      /verify\s+to\s+continue/i,
      /drag\s+the\s+puzzle/i,
      /security\s+verification/i,
      /log\s+in\s+to\s+continue/i
    ];

    for (const sel of toastSelectors) {
      const nodes = document.querySelectorAll(sel);
      for (const node of nodes) {
        if (!isElementVisible(node)) continue;
        const text = (node.textContent || '').trim();
        for (const pat of rateLimitPatterns) {
          if (pat.test(text)) {
            return {
              detected: true,
              type: 'rate_limited',
              message: `TikTok rate limit detected: "${text.slice(0, 120)}". Processing paused immediately.`
            };
          }
        }
        for (const pat of verificationPatterns) {
          if (pat.test(text)) {
            return {
              detected: true,
              type: 'verification_required',
              message: `TikTok verification required: "${text.slice(0, 120)}". Processing paused immediately.`
            };
          }
        }
      }
    }

    return { detected: false, type: null, message: null };
  }

  /**
   * Event-driven + fallback passive watcher that checks when a CAPTCHA / verification challenge
   * is manually resolved by the user and revalidates the TikTok page before notifying background.js.
   * Never attempts to solve or interact with the CAPTCHA itself.
   */
  function startCaptchaResolutionWatcher(listType = 'following') {
    stopCaptchaResolutionWatcher();

    const notifyIfResolved = () => {
      const check = checkChallengeClearedAndRevalidate(listType);
      if (check.resolvedAndValid) {
        stopCaptchaResolutionWatcher();
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          try {
            chrome.runtime.sendMessage({
              type: 'CAPTCHA_RESOLVED_REVALIDATED',
              listType,
              hasOpenList: check.hasOpenList
            });
          } catch (_e) {
            // Ignore messaging error if runtime is reloading
          }
        }
      }
    };

    if (typeof MutationObserver === 'function' && document && document.body) {
      try {
        captchaMutationObserver = new MutationObserver(() => {
          notifyIfResolved();
        });
        captchaMutationObserver.observe(document.body, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['style', 'class', 'hidden', 'aria-hidden']
        });
      } catch (_e) {
        captchaMutationObserver = null;
      }
    }

    captchaWatcherTimer = setInterval(notifyIfResolved, 1200);
  }

  function stopCaptchaResolutionWatcher() {
    if (captchaMutationObserver) {
      try {
        captchaMutationObserver.disconnect();
      } catch (_e) {
        // Ignore disconnect error
      }
      captchaMutationObserver = null;
    }
    if (captchaWatcherTimer) {
      clearInterval(captchaWatcherTimer);
      captchaWatcherTimer = null;
    }
  }

  function checkChallengeClearedAndRevalidate(_listType = 'following') {
    const security = detectSecurityChallenge();
    if (security.detected) {
      return { resolvedAndValid: false, reason: 'challenge_still_visible' };
    }
    if (detectLoggedOutState()) {
      return { resolvedAndValid: false, reason: 'logged_out' };
    }
    const isTikTok = /(^|\.)tiktok\.com$/i.test((window.location && window.location.hostname) || '');
    if (!isTikTok) {
      return { resolvedAndValid: false, reason: 'not_on_tiktok' };
    }
    const container = findUserListContainer(true);
    const profileCtx = detectProfileContext();
    if (container || profileCtx.isProfilePage) {
      return {
        resolvedAndValid: true,
        hasOpenList: Boolean(container),
        profileUsername: profileCtx.profileUsername
      };
    }
    return { resolvedAndValid: false, reason: 'page_not_revalidated' };
  }

  /**
   * Trigger a browser CSV file download from the content script DOM (fallback for Quetta / Android).
   */
  function triggerDomCsvDownload(filename, csvContent) {
    try {
      if (typeof Blob === 'undefined' || typeof URL === 'undefined' || !URL.createObjectURL) {
        return { ok: false, downloadedViaDom: false, error: 'Blob URL API unavailable.' };
      }
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename || 'tiktok-unfollower-session.csv');
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      return { ok: true, downloadedViaDom: true, filename };
    } catch (err) {
      return {
        ok: false,
        downloadedViaDom: false,
        error: err && err.message ? err.message : 'DOM CSV download trigger failed.'
      };
    }
  }

  function detectLoggedOutState() {
    const loginButtonSelectors = [
      '#header-login-button',
      '[data-e2e="top-login-button"]',
      '[data-e2e="nav-login-button"]',
      '[data-e2e="login-modal"]'
    ];
    for (const sel of loginButtonSelectors) {
      const el = document.querySelector(sel);
      if (el && isElementVisible(el)) {
        return true;
      }
    }
    return false;
  }

  function detectUnavailableProfile() {
    const errorSelectors = [
      '[data-e2e="error-page"]',
      '[data-e2e="user-error"]',
      '[class*="DivErrorContainer"]',
      'main'
    ];
    const unavailablePatterns = [
      /couldn't\s+find\s+this\s+account/i,
      /account\s+was\s+banned/i,
      /this\s+account\s+is\s+private/i,
      /page\s+not\s+available/i
    ];

    for (const sel of errorSelectors) {
      const el = document.querySelector(sel);
      if (!el || !isElementVisible(el)) continue;
      const txt = (el.textContent || '').trim();
      for (const pat of unavailablePatterns) {
        if (pat.test(txt)) {
          return {
            unavailable: true,
            reason: `TikTok profile is unavailable or private ("${txt.slice(0, 90)}").`
          };
        }
      }
    }
    return { unavailable: false, reason: null };
  }

  function detectProfileContext() {
    const hostname = (window.location && window.location.hostname) || '';
    const pathname = (window.location && window.location.pathname) || '';
    const isTikTokDomain = /(^|\.)tiktok\.com$/i.test(hostname);

    let profileUsername = null;
    const pathMatch = pathname.match(/^\/@([^/?#]+)/);
    if (pathMatch && pathMatch[1]) {
      profileUsername = decodeURIComponent(pathMatch[1]).trim();
    } else {
      const titleEl = document.querySelector('[data-e2e="user-title"], [data-e2e="user-subtitle"]');
      if (titleEl && titleEl.textContent) {
        profileUsername = titleEl.textContent.trim().replace(/^@/, '');
      }
    }

    const followingTrigger = findProfileListTrigger('following');
    const followersTrigger = findProfileListTrigger('followers');
    const unavailableCheck = detectUnavailableProfile();

    return {
      isTikTokDomain,
      isProfilePage: Boolean(isTikTokDomain && (profileUsername || followingTrigger || followersTrigger)),
      profileUsername,
      hasFollowingTrigger: Boolean(followingTrigger),
      hasFollowersTrigger: Boolean(followersTrigger),
      unavailable: unavailableCheck.unavailable,
      unavailableReason: unavailableCheck.reason
    };
  }

  function findProfileListTrigger(listType = 'following') {
    const isFollowers = listType === 'followers';
    const specificSelectors = isFollowers
      ? [
          '[data-e2e="followers-count"]',
          '[data-e2e="followers"]',
          '[title="Followers"]',
          'a[href*="/followers"]',
          '[data-testid="followers-trigger"]'
        ]
      : [
          '[data-e2e="following-count"]',
          '[data-e2e="following"]',
          '[title="Following"]',
          'a[href*="/following"]',
          '[data-testid="following-trigger"]'
        ];

    for (const sel of specificSelectors) {
      const el = document.querySelector(sel);
      if (el && isElementVisible(el)) {
        return el;
      }
    }

    const candidateBlocks = document.querySelectorAll(
      '[data-e2e="user-page"] h2 span, [data-e2e="user-page"] div, header span, header a, header button'
    );
    const targetPattern = isFollowers ? /\bfollowers\b/i : /\bfollowing\b/i;

    for (const node of candidateBlocks) {
      if (!isElementVisible(node)) continue;
      const txt = (node.textContent || '').trim();
      if (txt.length <= 32 && targetPattern.test(txt)) {
        return node;
      }
    }

    return null;
  }

  function findUserListContainer(forceRescan = false) {
    if (!forceRescan && cachedListContainer && cachedListContainer.isConnected && isElementVisible(cachedListContainer)) {
      return cachedListContainer;
    }

    const containerSelectors = [
      '[data-e2e="follow-info-popup"]',
      '[role="dialog"][aria-modal="true"]',
      '[role="dialog"]',
      '[class*="DivUserListContainer"]',
      '[class*="UserListContainer"]',
      '[data-testid="follow-list-modal"]',
      '#tiktok-follow-list-container'
    ];

    for (const sel of containerSelectors) {
      const candidates = document.querySelectorAll(sel);
      for (const candidate of candidates) {
        if (!isElementVisible(candidate)) continue;
        if (
          candidate.querySelector('a[href^="/@"]') ||
          candidate.querySelector('[data-e2e="user-item"]') ||
          /following|followers/i.test(candidate.textContent || '')
        ) {
          cachedListContainer = candidate;
          return candidate;
        }
      }
    }

    const mainList = document.querySelector('[data-e2e="user-page"] [class*="UserList"], main [data-e2e="user-list"]');
    if (mainList && isElementVisible(mainList)) {
      cachedListContainer = mainList;
      return mainList;
    }

    cachedListContainer = null;
    return null;
  }

  function detectActiveListTab(container) {
    if (!container) return 'unknown';
    const activeTabSelectors = [
      '[role="tab"][aria-selected="true"]',
      '[data-e2e="following-tab"][aria-selected="true"]',
      '[data-e2e="followers-tab"][aria-selected="true"]',
      '[class*="Tab"][class*="Active"]',
      '[class*="active"]'
    ];

    for (const sel of activeTabSelectors) {
      const el = container.querySelector(sel);
      if (el) {
        const txt = (el.textContent || '').trim().toLowerCase();
        if (txt.includes('following')) return 'following';
        if (txt.includes('follower')) return 'followers';
      }
    }
    return 'unknown';
  }

  async function openProfileList(listType = 'following') {
    const security = detectSecurityChallenge();
    if (security.detected) {
      return {
        ok: false,
        securityHalt: true,
        challengeType: security.type,
        securityWarning: security.message
      };
    }

    if (detectLoggedOutState()) {
      return {
        ok: false,
        verificationRequired: true,
        error: 'You appear to be logged out of TikTok. Please log in to continue.'
      };
    }

    const unavailable = detectUnavailableProfile();
    if (unavailable.unavailable) {
      return {
        ok: false,
        unavailableProfile: true,
        error: unavailable.reason
      };
    }

    let container = findUserListContainer(true);
    if (container) {
      const currentTab = detectActiveListTab(container);
      if (currentTab === listType || currentTab === 'unknown') {
        return {
          ok: true,
          alreadyOpen: true,
          activeModalTab: currentTab === 'unknown' ? listType : currentTab
        };
      }

      const targetTabSelector = listType === 'followers'
        ? '[data-e2e="followers-tab"], [role="tab"]'
        : '[data-e2e="following-tab"], [role="tab"]';
      const tabCandidates = container.querySelectorAll(targetTabSelector);
      const pattern = listType === 'followers' ? /follower/i : /following/i;

      for (const tabEl of tabCandidates) {
        if (pattern.test(tabEl.textContent || '')) {
          tabEl.click();
          await sleep(400);
          lastDomFingerprint = '';
          return {
            ok: true,
            switchedModalTab: true,
            activeModalTab: listType
          };
        }
      }
    }

    const trigger = findProfileListTrigger(listType);
    if (!trigger) {
      return {
        ok: false,
        listNotFound: true,
        error: `Could not find the "${listType === 'followers' ? 'Followers' : 'Following'}" button on this page. Navigate to your TikTok profile page (https://www.tiktok.com/@username) first.`
      };
    }

    trigger.click();
    if (trigger.parentElement && typeof trigger.parentElement.click === 'function') {
      trigger.parentElement.click();
    }

    const maxAttempts = 12;
    for (let i = 0; i < maxAttempts; i++) {
      await sleep(250);
      container = findUserListContainer(true);
      if (container) {
        const rows = getUserRowElements(container);
        if (rows.length > 0 || detectActiveListTab(container) !== 'unknown') {
          lastDomFingerprint = '';
          return {
            ok: true,
            openedModal: true,
            activeModalTab: detectActiveListTab(container) || listType
          };
        }
      }
    }

    return {
      ok: false,
      listNotFound: true,
      error: `Clicked "${listType === 'followers' ? 'Followers' : 'Following'}", but the account list modal did not open. Please tap "${listType === 'followers' ? 'Followers' : 'Following'}" on your TikTok profile manually.`
    };
  }

  function getUserRowElements(container) {
    const root = container || findUserListContainer() || document;
    const rowSelectors = [
      '[data-e2e="user-item"]',
      'li[data-e2e*="user"]',
      '[class*="DivUserItemContainer"]',
      '[class*="UserItemContainer"]',
      '[class*="DivUserContainer"]',
      '[data-testid="user-row"]',
      '.tt-user-item',
      'li'
    ];

    for (const sel of rowSelectors) {
      const elements = Array.from(root.querySelectorAll(sel)).filter((el) => {
        if (!isElementVisible(el)) return false;
        const hasProfileLink = Boolean(el.querySelector('a[href^="/@"]'));
        const hasActionBtn = Boolean(el.querySelector('button'));
        return hasProfileLink && hasActionBtn;
      });
      if (elements.length > 0) {
        return elements;
      }
    }

    return [];
  }

  function parseUserRow(rowEl, listType = 'following') {
    if (!rowEl || !isElementVisible(rowEl)) return null;

    let username = '';
    const uniqueIdEl = rowEl.querySelector(
      '[data-e2e*="unique-id"], [data-e2e*="user-uniqueId"], [class*="SpanUniqueId"], .tt-username'
    );
    if (uniqueIdEl && uniqueIdEl.textContent) {
      username = uniqueIdEl.textContent.trim().replace(/^@/, '');
    }

    if (!username) {
      const links = rowEl.querySelectorAll('a[href^="/@"]');
      for (const link of links) {
        const href = link.getAttribute('href') || '';
        const match = href.match(/^\/@([^/?#]+)/);
        if (match && match[1]) {
          username = decodeURIComponent(match[1]).trim();
          break;
        }
      }
    }

    if (!username) return null;

    let displayName = '';
    const nicknameEl = rowEl.querySelector(
      '[data-e2e*="nickname"], [data-e2e*="user-title"], [class*="SpanNickname"], .tt-nickname'
    );
    if (nicknameEl && nicknameEl.textContent) {
      displayName = nicknameEl.textContent.trim();
    } else {
      const links = rowEl.querySelectorAll('a[href^="/@"]');
      for (const link of links) {
        const txt = (link.textContent || '').trim();
        if (txt && txt.replace(/^@/, '').toLowerCase() !== username.toLowerCase()) {
          displayName = txt;
          break;
        }
      }
    }

    const buttons = Array.from(rowEl.querySelectorAll('button'));
    let primaryButton = rowEl.querySelector('button[data-e2e="follow-button"], button[data-testid="follow-btn"]');
    if (!primaryButton && buttons.length > 0) {
      primaryButton = buttons.find((btn) => {
        const txt = (btn.textContent || '').trim();
        return txt.length > 0 && txt !== '...' && txt !== '⋯';
      }) || buttons[0];
    }

    const moreButton = rowEl.querySelector(
      'button[data-e2e*="more"], button[aria-label*="More" i], button[data-testid="more-action"], .tt-more-btn'
    ) || buttons.find((btn) => {
      const txt = (btn.textContent || '').trim();
      const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
      return txt === '...' || txt === '⋯' || aria.includes('more') || aria.includes('action');
    }) || null;

    const btnTextRaw = primaryButton ? (primaryButton.textContent || '').trim() : '';
    const btnText = btnTextRaw.toLowerCase();
    const btnAria = primaryButton ? (primaryButton.getAttribute('aria-label') || '').toLowerCase() : '';

    const mutualBadgeEl = rowEl.querySelector(
      '[data-e2e*="mutual"], [class*="SpanMutual"], [data-testid="mutual-badge"], .tt-mutual-badge'
    );
    const badgeText = mutualBadgeEl ? (mutualBadgeEl.textContent || '').trim().toLowerCase() : '';

    let mutualStatus = 'unknown';
    let relationshipState = 'unknown';

    const hasExplicitMutualSignal =
      btnText === 'friends' ||
      btnText === 'mutual' ||
      btnText === 'each other' ||
      btnAria.includes('friends') ||
      btnAria.includes('mutual') ||
      badgeText.includes('friends') ||
      badgeText.includes('mutual') ||
      badgeText.includes('follows you');

    if (listType === 'following') {
      if (hasExplicitMutualSignal) {
        mutualStatus = 'mutual';
        relationshipState = 'friends';
      } else if (btnText === 'following' || btnText === 'requested' || btnAria.includes('following')) {
        mutualStatus = 'non_mutual';
        relationshipState = 'following';
      } else if (btnText === 'follow' || btnText === 'follow back') {
        mutualStatus = 'non_mutual';
        relationshipState = 'not_following';
      } else {
        mutualStatus = 'unknown';
        relationshipState = 'unknown';
      }
    } else {
      if (hasExplicitMutualSignal || btnText === 'following') {
        mutualStatus = 'mutual';
        relationshipState = 'friends';
      } else if (btnText === 'follow back' || btnText === 'follow') {
        mutualStatus = 'non_mutual';
        relationshipState = 'follower_only';
      } else if (btnText === 'removed' || btnText === 'unblock') {
        mutualStatus = 'non_mutual';
        relationshipState = 'removed';
      } else {
        mutualStatus = 'unknown';
        relationshipState = 'unknown';
      }
    }

    if (rowEl.dataset) {
      rowEl.dataset.ttScannedUser = username.toLowerCase();
    }

    return {
      username,
      displayName: displayName || username,
      mutualStatus,
      followsYouIndicator: Boolean(hasExplicitMutualSignal || listType === 'followers'),
      relationshipState,
      buttonText: btnTextRaw || 'Unknown',
      hasMoreMenu: Boolean(moreButton),
      rowElement: rowEl,
      primaryButton,
      moreButton
    };
  }

  function computeRowsFingerprint(rows, listType) {
    if (!rows || rows.length === 0) return `${listType}:0`;
    const first = rows[0];
    const last = rows[rows.length - 1];
    const firstKey = (first.dataset && first.dataset.ttScannedUser) || (first.textContent || '').slice(0, 24);
    const lastKey = (last.dataset && last.dataset.ttScannedUser) || (last.textContent || '').slice(0, 24);
    return `${listType}:${rows.length}:${firstKey}:${lastKey}`;
  }

  function scanVisibleAccounts(listType = 'following', options = {}) {
    if (options && options.resetDiscoveryCache) {
      discoveredAccountsMap.clear();
      lastDomFingerprint = '';
      lastVisibleAccountsSnapshot = [];
    }

    const security = detectSecurityChallenge();
    if (security.detected) {
      startCaptchaResolutionWatcher(listType);
      return {
        ok: false,
        securityHalt: true,
        challengeType: security.type,
        securityWarning: security.message,
        accounts: [],
        newlyDiscovered: []
      };
    }

    const isTikTokDomain = /(^|\.)tiktok\.com$/i.test(window.location.hostname || '');
    if (!isTikTokDomain) {
      return {
        ok: false,
        unsupportedUrl: true,
        error: 'Current tab is not on tiktok.com. Open https://www.tiktok.com and navigate to your profile.',
        accounts: [],
        newlyDiscovered: []
      };
    }

    if (detectLoggedOutState()) {
      return {
        ok: false,
        loggedOut: true,
        verificationRequired: true,
        error: 'You appear to be logged out of TikTok. Please log in to view your Following or Followers list.',
        accounts: [],
        newlyDiscovered: []
      };
    }

    const container = findUserListContainer();
    const rows = getUserRowElements(container);

    if (!container && rows.length === 0) {
      return {
        ok: false,
        listNotFound: true,
        error: `No open ${listType === 'followers' ? 'Followers' : 'Following'} list detected on this TikTok page.`,
        accounts: [],
        newlyDiscovered: []
      };
    }

    const currentFingerprint = computeRowsFingerprint(rows, listType);
    if (
      !options.forceFullScan &&
      currentFingerprint === lastDomFingerprint &&
      lastVisibleAccountsSnapshot.length > 0 &&
      discoveredAccountsMap.size > 0
    ) {
      const allCached = Array.from(discoveredAccountsMap.values());
      return {
        ok: true,
        unchangedDomSkipped: true,
        activeModalTab: detectActiveListTab(container),
        totalDetected: allCached.length,
        visibleCount: lastVisibleAccountsSnapshot.length,
        newlyDiscoveredCount: 0,
        mutualCount: allCached.filter((a) => a.mutualStatus === 'mutual').length,
        unknownCount: allCached.filter((a) => a.mutualStatus === 'unknown').length,
        eligibleNonMutualCount: allCached.filter((a) => a.mutualStatus === 'non_mutual').length,
        accounts: allCached,
        visibleAccounts: lastVisibleAccountsSnapshot,
        newlyDiscovered: []
      };
    }

    const visibleSeen = new Set();
    const visibleAccounts = [];
    const newlyDiscovered = [];

    for (const row of rows) {
      const parsed = parseUserRow(row, listType);
      if (!parsed) continue;
      const key = parsed.username.toLowerCase();
      if (visibleSeen.has(key)) continue;
      visibleSeen.add(key);

      const cleanRecord = {
        username: parsed.username,
        displayName: parsed.displayName,
        mutualStatus: parsed.mutualStatus,
        followsYouIndicator: parsed.followsYouIndicator,
        relationshipState: parsed.relationshipState,
        buttonText: parsed.buttonText,
        hasMoreMenu: parsed.hasMoreMenu
      };

      visibleAccounts.push(cleanRecord);

      if (!discoveredAccountsMap.has(key)) {
        discoveredAccountsMap.set(key, cleanRecord);
        newlyDiscovered.push(cleanRecord);
      } else {
        discoveredAccountsMap.set(key, cleanRecord);
      }
    }

    lastDomFingerprint = computeRowsFingerprint(rows, listType);
    lastVisibleAccountsSnapshot = visibleAccounts;

    const allDiscovered = Array.from(discoveredAccountsMap.values());

    return {
      ok: true,
      activeModalTab: detectActiveListTab(container),
      totalDetected: allDiscovered.length,
      visibleCount: visibleAccounts.length,
      newlyDiscoveredCount: newlyDiscovered.length,
      mutualCount: allDiscovered.filter((a) => a.mutualStatus === 'mutual').length,
      unknownCount: allDiscovered.filter((a) => a.mutualStatus === 'unknown').length,
      eligibleNonMutualCount: allDiscovered.filter((a) => a.mutualStatus === 'non_mutual').length,
      accounts: allDiscovered,
      visibleAccounts,
      newlyDiscovered
    };
  }

  function findScrollableListElement(container) {
    if (!container) return null;
    const candidates = [container, ...Array.from(container.querySelectorAll('div, ul'))];
    const scrollable = candidates.find((el) => el.scrollHeight > el.clientHeight + 10);
    return scrollable || container;
  }

  function isListLoading(container) {
    if (!container) return false;
    const loadingSelectors = [
      '[data-e2e*="loading"]',
      '[class*="Loading"]',
      '[class*="Spinner"]',
      '[role="progressbar"]',
      '.tt-loading-spinner'
    ];
    for (const sel of loadingSelectors) {
      const el = container.querySelector(sel);
      if (el && isElementVisible(el)) return true;
    }
    return false;
  }

  async function scrollAndScanList(listType = 'following', options = {}) {
    const maxRetries = Number(options.maxRetries ?? 3);
    const retryDelayMs = Number(options.retryDelayMs ?? 320);

    const container = findUserListContainer(true);
    if (!container) {
      return {
        ok: false,
        listNotFound: true,
        scrollStatus: 'modal_closed',
        error: 'Account list modal closed or became unavailable during scrolling.',
        accounts: Array.from(discoveredAccountsMap.values()),
        newlyDiscovered: []
      };
    }

    scanVisibleAccounts(listType);
    const beforeDiscoveredCount = discoveredAccountsMap.size;

    const scrollable = findScrollableListElement(container);
    const beforeScrollTop = scrollable ? scrollable.scrollTop : 0;
    const beforeScrollHeight = scrollable ? scrollable.scrollHeight : 0;

    if (scrollable) {
      const delta = Math.max(360, Math.round((scrollable.clientHeight || 400) * 0.85));
      if (typeof scrollable.scrollBy === 'function') {
        scrollable.scrollBy({ top: delta, behavior: 'smooth' });
      }
      scrollable.scrollTop = Math.min(scrollable.scrollHeight || (beforeScrollTop + delta), beforeScrollTop + delta);
      if (typeof scrollable.dispatchEvent === 'function' && typeof Event === 'function') {
        try {
          scrollable.dispatchEvent(new Event('scroll', { bubbles: true }));
        } catch (_e) {
          // Ignore synthetic event errors in test mocks
        }
      }
    }

    const aggregatedNewlyDiscovered = [];
    let latestScan = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      await sleep(retryDelayMs * attempt);

      const currentContainer = findUserListContainer(true);
      if (!currentContainer) {
        return {
          ok: false,
          listNotFound: true,
          scrollStatus: 'modal_closed',
          error: 'Account list closed unexpectedly while waiting for lazy-loaded accounts.',
          accounts: Array.from(discoveredAccountsMap.values()),
          newlyDiscovered: aggregatedNewlyDiscovered
        };
      }

      latestScan = scanVisibleAccounts(listType, { forceFullScan: true });
      if (!latestScan.ok) {
        return {
          ...latestScan,
          scrollStatus: 'error'
        };
      }

      if (latestScan.newlyDiscovered && latestScan.newlyDiscovered.length > 0) {
        aggregatedNewlyDiscovered.push(...latestScan.newlyDiscovered);
        break;
      }

      const loadingNow = isListLoading(currentContainer);
      const curScrollable = findScrollableListElement(currentContainer);
      const atBottom = curScrollable
        ? (curScrollable.scrollTop + curScrollable.clientHeight >= curScrollable.scrollHeight - 10)
        : true;

      if (!loadingNow && atBottom && attempt >= 2) {
        break;
      }
    }

    const afterDiscoveredCount = discoveredAccountsMap.size;
    const netNewCount = afterDiscoveredCount - beforeDiscoveredCount;
    const finalContainer = findUserListContainer();
    const finalScrollable = findScrollableListElement(finalContainer);
    const stillLoading = isListLoading(finalContainer);
    const atBottom = finalScrollable
      ? (finalScrollable.scrollTop + finalScrollable.clientHeight >= finalScrollable.scrollHeight - 10)
      : true;
    const heightGrew = finalScrollable ? finalScrollable.scrollHeight > beforeScrollHeight : false;

    let scrollStatus = 'loaded_more';
    if (netNewCount === 0 && aggregatedNewlyDiscovered.length === 0) {
      if (stillLoading || (!atBottom && !heightGrew)) {
        scrollStatus = 'stalled';
      } else {
        scrollStatus = 'exhausted';
      }
    }

    return {
      ...(latestScan || scanVisibleAccounts(listType)),
      scrollStatus,
      newlyDiscovered: aggregatedNewlyDiscovered,
      newlyDiscoveredCount: aggregatedNewlyDiscovered.length
    };
  }

  async function reacquireAndVerifyAccount(username, listType = 'following', skipMutuals = true) {
    const targetKey = String(username || '').replace(/^@/, '').trim().toLowerCase();
    if (!targetKey) {
      return { ok: false, status: 'failed', reason: 'invalid_username', errorDetails: 'Empty username.' };
    }

    const container = findUserListContainer(true);
    if (!container) {
      return {
        ok: false,
        status: 'failed',
        reason: 'list_closed',
        errorDetails: 'TikTok account list container is no longer open.'
      };
    }

    let matchedRowInfo = null;
    const findInCurrentDom = () => {
      const rows = getUserRowElements(container);
      for (const row of rows) {
        const parsed = parseUserRow(row, listType);
        if (parsed && parsed.username.toLowerCase() === targetKey) {
          return parsed;
        }
      }
      return null;
    };

    matchedRowInfo = findInCurrentDom();

    if (!matchedRowInfo) {
      const scrollable = findScrollableListElement(container);
      if (scrollable && scrollable.scrollHeight > scrollable.clientHeight) {
        scrollable.scrollTop = Math.max(0, scrollable.scrollTop - 220);
        await sleep(140);
        matchedRowInfo = findInCurrentDom();
        if (!matchedRowInfo) {
          scrollable.scrollTop = Math.min(scrollable.scrollHeight, scrollable.scrollTop + 440);
          await sleep(140);
          matchedRowInfo = findInCurrentDom();
        }
      }
    }

    if (!matchedRowInfo || !matchedRowInfo.rowElement || !matchedRowInfo.rowElement.isConnected) {
      return {
        ok: true,
        status: 'skipped',
        skipReason: 'account_not_confidently_reacquired',
        errorDetails: `Could not reacquire connected DOM entry for @${username}. Skipped for safety.`
      };
    }

    if (matchedRowInfo.username.toLowerCase() !== targetKey) {
      return {
        ok: true,
        status: 'skipped',
        skipReason: 'username_mismatch',
        errorDetails: `Reacquired row username (@${matchedRowInfo.username}) did not match @${username}.`
      };
    }

    if (skipMutuals) {
      if (matchedRowInfo.mutualStatus === 'mutual') {
        return {
          ok: true,
          status: 'skipped',
          skipReason: 'mutual_protected',
          displayName: matchedRowInfo.displayName
        };
      }
      if (matchedRowInfo.mutualStatus === 'unknown') {
        return {
          ok: true,
          status: 'skipped',
          skipReason: 'mutual_status_uncertain',
          displayName: matchedRowInfo.displayName
        };
      }
    }

    const intendedButton = listType === 'followers'
      ? (matchedRowInfo.moreButton || matchedRowInfo.primaryButton)
      : matchedRowInfo.primaryButton;

    const ownsButton = Boolean(
      intendedButton &&
      typeof matchedRowInfo.rowElement.contains === 'function'
        ? matchedRowInfo.rowElement.contains(intendedButton)
        : Boolean(intendedButton)
    );

    if (!ownsButton) {
      return {
        ok: true,
        status: 'skipped',
        skipReason: 'action_button_ownership_unverified',
        errorDetails: `Could not confirm that the action button belongs to @${username}.`
      };
    }

    return {
      ok: true,
      status: 'verified',
      matchedRowInfo
    };
  }

  function verifyAccountState(username, listType = 'following') {
    const targetKey = String(username || '').replace(/^@/, '').trim().toLowerCase();
    const container = findUserListContainer(true);
    const rows = getUserRowElements(container);

    for (const row of rows) {
      const parsed = parseUserRow(row, listType);
      if (parsed && parsed.username.toLowerCase() === targetKey) {
        const alreadyDone =
          (listType === 'following' && parsed.relationshipState === 'not_following') ||
          (listType === 'followers' && parsed.relationshipState === 'removed');
        return {
          ok: true,
          foundInDom: true,
          actionCompleted: alreadyDone,
          relationshipState: parsed.relationshipState,
          mutualStatus: parsed.mutualStatus
        };
      }
    }

    return {
      ok: true,
      foundInDom: false,
      actionCompleted: false,
      relationshipState: 'unknown'
    };
  }

  function showGuidedOverlay(targetEl, instructionText) {
    removeGuidedOverlay();
    if (targetEl && targetEl.style) {
      targetEl.dataset.ttUnfollowerHighlighted = 'true';
      targetEl.style.outline = '3px solid #22D3EE';
      targetEl.style.outlineOffset = '3px';
      targetEl.style.borderRadius = '8px';
      targetEl.style.boxShadow = '0 0 0 6px rgba(34, 211, 238, 0.25)';
    }

    const banner = document.createElement('div');
    banner.id = 'tt-unfollower-guided-banner';
    banner.setAttribute('role', 'status');
    banner.style.cssText = [
      'position: fixed',
      'bottom: 16px',
      'left: 16px',
      'right: 16px',
      'z-index: 2147483647',
      'max-width: 380px',
      'margin: 0 auto',
      'background: linear-gradient(135deg, #0B1021 0%, #1E1B4B 100%)',
      'color: #F8FAFC',
      'border: 1.5px solid #22D3EE',
      'border-radius: 14px',
      'padding: 12px 16px',
      'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      'font-size: 13px',
      'line-height: 1.45',
      'box-shadow: 0 12px 32px rgba(11, 16, 33, 0.65)'
    ].join(';');
    banner.textContent = `Mizo_q • ${instructionText}`;
    document.body.appendChild(banner);
  }

  function removeGuidedOverlay() {
    const existing = document.getElementById('tt-unfollower-guided-banner');
    if (existing) existing.remove();
    const highlighted = document.querySelectorAll('[data-tt-unfollower-highlighted="true"]');
    for (const el of highlighted) {
      el.style.outline = '';
      el.style.outlineOffset = '';
      el.style.boxShadow = '';
      delete el.dataset.ttUnfollowerHighlighted;
    }
  }

  function findConfirmationDialogButton(pattern) {
    const dialogs = document.querySelectorAll('[role="dialog"], [data-e2e*="confirm"], [class*="Modal"], .tt-confirm-modal');
    for (const dlg of dialogs) {
      if (!isElementVisible(dlg)) continue;
      const buttons = dlg.querySelectorAll('button');
      for (const btn of buttons) {
        const txt = (btn.textContent || '').trim();
        if (pattern.test(txt)) {
          return btn;
        }
      }
    }
    return null;
  }

  function findPopoverMenuItem(pattern) {
    const selectors = [
      '[role="menuitem"]',
      '[data-e2e="remove-follower"]',
      '[data-e2e*="popover"] li',
      '[data-e2e*="popover"] button',
      '[class*="Popup"] li',
      '[class*="Menu"] li',
      '[class*="MenuItem"]',
      '.tt-menu-item'
    ];
    for (const sel of selectors) {
      const items = document.querySelectorAll(sel);
      for (const item of items) {
        if (!isElementVisible(item)) continue;
        const txt = (item.textContent || '').trim();
        if (pattern.test(txt)) {
          return item;
        }
      }
    }
    return null;
  }

  async function executeAccountAction(options) {
    const {
      username,
      actionType = 'unfollow',
      skipMutuals = true,
      executionMode = 'auto',
      followerRemovalMethod = 'native_remove',
      confirmedDestructive = false
    } = options || {};

    if (!username || typeof username !== 'string') {
      return {
        ok: false,
        result: 'failed',
        errorDetails: 'Missing or invalid username parameter.'
      };
    }

    const listType = actionType === 'remove_follower' ? 'followers' : 'following';

    const preSecurity = detectSecurityChallenge();
    if (preSecurity.detected) {
      removeGuidedOverlay();
      startCaptchaResolutionWatcher(listType);
      return {
        ok: false,
        securityHalt: true,
        challengeType: preSecurity.type,
        result: 'failed',
        errorDetails: preSecurity.message
      };
    }

    const reacquired = await reacquireAndVerifyAccount(username, listType, skipMutuals);
    if (!reacquired.ok) {
      return {
        ok: false,
        result: 'failed',
        errorDetails: reacquired.errorDetails || `Failed to reacquire @${username}.`
      };
    }

    if (reacquired.status === 'skipped') {
      return {
        ok: true,
        result: 'skipped',
        skipReason: reacquired.skipReason,
        displayName: reacquired.displayName || username
      };
    }

    const matchedRowInfo = reacquired.matchedRowInfo;

    if (matchedRowInfo.rowElement && typeof matchedRowInfo.rowElement.scrollIntoView === 'function') {
      matchedRowInfo.rowElement.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }

    if (actionType === 'unfollow') {
      if (matchedRowInfo.relationshipState === 'not_following') {
        return {
          ok: true,
          result: 'skipped',
          skipReason: 'already_unfollowed',
          displayName: matchedRowInfo.displayName
        };
      }

      const btn = matchedRowInfo.primaryButton;
      if (!btn) {
        return {
          ok: false,
          result: 'failed',
          errorDetails: `Follow/Unfollow button not found for @${username}.`
        };
      }

      if (executionMode === 'guided') {
        showGuidedOverlay(
          btn,
          `Guided Step: Tap the highlighted "${matchedRowInfo.buttonText}" button next to @${username} to unfollow.`
        );
        const maxWait = 8000;
        const interval = 200;
        let elapsed = 0;
        while (elapsed < maxWait) {
          await sleep(interval);
          elapsed += interval;
          const recheck = parseUserRow(matchedRowInfo.rowElement, 'following');
          if (!recheck || recheck.relationshipState === 'not_following') {
            removeGuidedOverlay();
            lastDomFingerprint = '';
            return {
              ok: true,
              result: 'success',
              displayName: matchedRowInfo.displayName
            };
          }
        }
        removeGuidedOverlay();
        return {
          ok: false,
          result: 'failed',
          errorDetails: `Guided unfollow timed out waiting for manual confirmation on @${username}.`
        };
      }

      btn.click();
      await sleep(90);

      const confirmBtn = findConfirmationDialogButton(/^(unfollow|confirm)$/i);
      if (confirmBtn) {
        confirmBtn.click();
      }

      const verifyAttempts = 12;
      for (let i = 0; i < verifyAttempts; i++) {
        await sleep(130);

        const postSecurity = detectSecurityChallenge();
        if (postSecurity.detected) {
          startCaptchaResolutionWatcher(listType);
          return {
            ok: false,
            securityHalt: true,
            challengeType: postSecurity.type,
            result: 'failed',
            errorDetails: postSecurity.message
          };
        }

        const stillInDom = document.body.contains(matchedRowInfo.rowElement);
        if (!stillInDom) {
          const containerStillOpen = Boolean(findUserListContainer(true));
          if (!containerStillOpen) {
            return {
              ok: false,
              result: 'uncertain',
              errorDetails: `List closed while verifying unfollow for @${username}; outcome is uncertain.`
            };
          }
          lastDomFingerprint = '';
          return {
            ok: true,
            result: 'success',
            displayName: matchedRowInfo.displayName
          };
        }

        const updatedInfo = parseUserRow(matchedRowInfo.rowElement, 'following');
        if (updatedInfo && updatedInfo.relationshipState === 'not_following') {
          const cached = discoveredAccountsMap.get(username.toLowerCase());
          if (cached) cached.relationshipState = 'not_following';
          lastDomFingerprint = '';
          return {
            ok: true,
            result: 'success',
            displayName: matchedRowInfo.displayName
          };
        }
      }

      return {
        ok: false,
        result: 'failed',
        canUseGuided: true,
        errorDetails: `Unfollow state did not change for @${username} after tapping. Switch to Guided Mode in Settings if TikTok blocks automatic clicks.`
      };
    }

    if (actionType === 'remove_follower') {
      if (!confirmedDestructive) {
        return {
          ok: false,
          result: 'failed',
          errorDetails: 'Explicit user confirmation is required before removing or blocking a follower.'
        };
      }

      if (matchedRowInfo.relationshipState === 'removed') {
        return {
          ok: true,
          result: 'skipped',
          skipReason: 'already_removed',
          displayName: matchedRowInfo.displayName
        };
      }

      if (followerRemovalMethod === 'native_remove' && executionMode === 'auto') {
        if (!matchedRowInfo.moreButton) {
          return {
            ok: false,
            result: 'failed',
            canUseGuided: true,
            errorDetails: `No "..." follower options menu found on @${username}'s row. Use Guided Mode or verify TikTok's layout.`
          };
        }

        matchedRowInfo.moreButton.click();
        await sleep(150);

        const removeMenuItem = findPopoverMenuItem(/remove\s+(this\s+)?follower/i);
        if (!removeMenuItem) {
          return {
            ok: false,
            result: 'failed',
            canUseGuided: true,
            errorDetails: `"Remove this follower" option was not found in the menu for @${username}.`
          };
        }

        removeMenuItem.click();
        await sleep(140);

        const confirmRemoveBtn = findConfirmationDialogButton(/^(remove|confirm)$/i);
        if (confirmRemoveBtn) {
          confirmRemoveBtn.click();
        }

        for (let i = 0; i < 12; i++) {
          await sleep(130);

          const postSecurity = detectSecurityChallenge();
          if (postSecurity.detected) {
            startCaptchaResolutionWatcher(listType);
            return {
              ok: false,
              securityHalt: true,
              challengeType: postSecurity.type,
              result: 'failed',
              errorDetails: postSecurity.message
            };
          }

          const stillInDom = document.body.contains(matchedRowInfo.rowElement);
          if (!stillInDom || !isElementVisible(matchedRowInfo.rowElement)) {
            lastDomFingerprint = '';
            return {
              ok: true,
              result: 'success',
              displayName: matchedRowInfo.displayName
            };
          }

          const updated = parseUserRow(matchedRowInfo.rowElement, 'followers');
          if (!updated || updated.relationshipState === 'removed') {
            lastDomFingerprint = '';
            return {
              ok: true,
              result: 'success',
              displayName: matchedRowInfo.displayName
            };
          }
        }

        return {
          ok: false,
          result: 'failed',
          canUseGuided: true,
          errorDetails: `Follower removal could not be verified for @${username} (row remained unchanged).`
        };
      }

      const highlightTarget = matchedRowInfo.moreButton || matchedRowInfo.rowElement;
      const guidedPrompt = followerRemovalMethod === 'guided_block_unblock'
        ? `Guided Block & Unblock: Tap "..." next to @${username} to remove or block-and-unblock this follower.`
        : `Guided Remove Follower: Tap the highlighted "..." menu next to @${username} and select "Remove this follower".`;

      showGuidedOverlay(highlightTarget, guidedPrompt);

      const maxWait = 10000;
      const interval = 250;
      let elapsed = 0;
      while (elapsed < maxWait) {
        await sleep(interval);
        elapsed += interval;
        const stillVisible = document.body.contains(matchedRowInfo.rowElement) && isElementVisible(matchedRowInfo.rowElement);
        const recheck = stillVisible ? parseUserRow(matchedRowInfo.rowElement, 'followers') : null;
        if (!stillVisible || !recheck || recheck.relationshipState === 'removed') {
          removeGuidedOverlay();
          lastDomFingerprint = '';
          return {
            ok: true,
            result: 'success',
            displayName: matchedRowInfo.displayName
          };
        }
      }

      removeGuidedOverlay();
      return {
        ok: false,
        result: 'failed',
        errorDetails: `Guided follower removal timed out waiting for confirmation on @${username}.`
      };
    }

    return {
      ok: false,
      result: 'failed',
      errorDetails: `Unsupported action type: ${actionType}`
    };
  }

  // Android / Quetta Browser visibility & app-switching listeners
  if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
    document.addEventListener('visibilitychange', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        try {
          chrome.runtime.sendMessage({
            type: 'LIFECYCLE_VISIBILITY_CHANGE',
            hidden: Boolean(document.hidden || document.visibilityState === 'hidden')
          });
        } catch (_e) {
          // Ignore runtime errors
        }
      }
    });
  }

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!message || typeof message.type !== 'string') {
        sendResponse({ ok: false, error: 'Invalid message format.' });
        return false;
      }

      (async () => {
        try {
          switch (message.type) {
            case 'PING_CONTENT':
            case 'INSPECT_PAGE_STATE': {
              const security = detectSecurityChallenge();
              const container = findUserListContainer(true);
              const profileContext = detectProfileContext();
              sendResponse({
                ok: true,
                url: window.location.href,
                hostname: window.location.hostname,
                loggedOut: detectLoggedOutState(),
                hasOpenList: Boolean(container),
                activeModalTab: detectActiveListTab(container),
                securityChallenge: security,
                profileContext
              });
              break;
            }

            case 'OPEN_PROFILE_LIST': {
              const result = await openProfileList(message.listType || 'following');
              sendResponse(result);
              break;
            }

            case 'SCAN_ACCOUNTS': {
              const result = scanVisibleAccounts(message.listType || 'following', message.options || {});
              sendResponse(result);
              break;
            }

            case 'SCROLL_AND_SCAN': {
              const result = await scrollAndScanList(message.listType || 'following', message.options || {});
              sendResponse(result);
              break;
            }

            case 'EXECUTE_ACTION': {
              const result = await executeAccountAction(message.payload || {});
              sendResponse(result);
              break;
            }

            case 'VERIFY_ACCOUNT_STATE': {
              const result = verifyAccountState(message.username, message.listType || 'following');
              sendResponse(result);
              break;
            }

            case 'START_CAPTCHA_WATCHER': {
              startCaptchaResolutionWatcher(message.listType || 'following');
              sendResponse({ ok: true, watching: true });
              break;
            }

            case 'CHECK_CAPTCHA_RESOLVED': {
              const check = checkChallengeClearedAndRevalidate(message.listType || 'following');
              sendResponse({ ok: true, ...check });
              break;
            }

            case 'TRIGGER_DOM_CSV_DOWNLOAD': {
              const dl = triggerDomCsvDownload(message.filename, message.csvContent);
              sendResponse(dl);
              break;
            }

            case 'CLEAR_GUIDED_OVERLAY': {
              removeGuidedOverlay();
              sendResponse({ ok: true });
              break;
            }

            default:
              sendResponse({ ok: false, error: `Unknown content script command: ${message.type}` });
          }
        } catch (err) {
          sendResponse({
            ok: false,
            error: err && err.message ? err.message : 'Unexpected content script error.'
          });
        }
      })();

      return true;
    });
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      detectSecurityChallenge,
      startCaptchaResolutionWatcher,
      stopCaptchaResolutionWatcher,
      checkChallengeClearedAndRevalidate,
      triggerDomCsvDownload,
      detectLoggedOutState,
      detectUnavailableProfile,
      detectProfileContext,
      findProfileListTrigger,
      findUserListContainer,
      openProfileList,
      parseUserRow,
      scanVisibleAccounts,
      scrollAndScanList,
      reacquireAndVerifyAccount,
      verifyAccountState,
      executeAccountAction,
      removeGuidedOverlay,
      discoveredAccountsMap
    };
  }
})();
