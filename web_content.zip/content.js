// ==========================================
// 🔔 NOTIFICATION BAR
// ==========================================
function createNotificationBar() {
    if (document.getElementById("hbx-auto-notif")) return;
    const bar = document.createElement("div");
    bar.id = "hbx-auto-notif";
    bar.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:999999;" +
        "background:linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);" +
        "color:#fff;padding:12px 16px;font-family:Arial,sans-serif;font-size:13px;" +
        "font-weight:700;text-align:center;box-shadow:0 4px 20px rgba(220,39,67,0.5);";
    bar.innerHTML = '<span id="hbx-auto-notif-text">HBX INSTA AUTO • Starting...</span>';
    document.body.appendChild(bar);
}

function notify(msg, type) {
    createNotificationBar();
    const textEl = document.getElementById("hbx-auto-notif-text");
    const bar = document.getElementById("hbx-auto-notif");
    if (textEl) textEl.textContent = "HBX INSTA AUTO • " + msg;
    console.log("🔔 " + msg);
    if (bar) {
        if (type === "success") bar.style.background = "linear-gradient(135deg,#11998e,#38ef7d)";
        else if (type === "error") bar.style.background = "linear-gradient(135deg,#eb3349,#f45c43)";
        else if (type === "info") bar.style.background = "linear-gradient(135deg,#2193b0,#6dd5ed)";
        else bar.style.background = "linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)";
    }
}

const delay = (ms) => new Promise(r => setTimeout(r, ms));

// ==========================================
// ⚡ BASIC HELPERS
// ==========================================
async function getElement(selector, timeout = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el && el.offsetParent !== null) return el;
        await delay(20);
    }
    return null;
}

async function getButtonByText(text, timeout = 8000) {
    const start = Date.now();
    const target = text.toLowerCase().trim();
    while (Date.now() - start < timeout) {
        const els = document.querySelectorAll('button, div[role="button"], a[role="button"], span[role="button"]');
        for (let el of els) {
            const t = (el.innerText || "").trim().toLowerCase();
            if (t === target && el.offsetParent !== null && !el.disabled) return el;
        }
        for (let el of els) {
            const t = (el.innerText || "").trim().toLowerCase();
            if (t.includes(target) && t.length < 60 && el.offsetParent !== null && !el.disabled) return el;
        }
        await delay(30);
    }
    return null;
}

async function smartWait(checkFn, maxMs = 8000, interval = 40) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
        if (checkFn()) return true;
        await delay(interval);
    }
    return false;
}

async function realTimeType(el, text) {
    if (!el) return false;
    el.focus(); el.click();
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    setter.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return el.value === text;
}

async function clearInput(el) {
    if (!el) return;
    try {
        el.focus(); el.click();
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
        setter.call(el, '');
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {}
}

// ==========================================
// 🔨 forceClickButton (8 layers)
// ==========================================
async function forceClickButton(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;

    try { el.focus(); el.click(); } catch (e) {}
    try {
        const p = document.elementFromPoint(x, y);
        if (p) {
            const o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
            p.dispatchEvent(new MouseEvent('mousedown', o));
            p.dispatchEvent(new MouseEvent('mouseup', o));
            p.dispatchEvent(new MouseEvent('click', o));
            try { p.click(); } catch (e) {}
        }
    } catch (e) {}
    try {
        const t = new Touch({ identifier: Date.now(), target: el, clientX: x, clientY: y, radiusX: 2, radiusY: 2, force: 0.5 });
        el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [t] }));
        el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], changedTouches: [t] }));
    } catch (e) {}
    try {
        let p = el.parentElement;
        for (let i = 0; i < 3 && p; i++) {
            try { p.click(); } catch (e) {}
            p = p.parentElement;
        }
    } catch (e) {}
    el.focus();
    return true;
}

async function clickNext() {
    for (let attempt = 1; attempt <= 4; attempt++) {
        const btns = document.querySelectorAll('button, div[role="button"]');
        let nextBtn = null;
        for (let b of btns) {
            const t = (b.innerText || "").trim().toLowerCase();
            if (t === "next" && b.offsetParent !== null && !b.disabled) {
                nextBtn = b; break;
            }
        }
        if (!nextBtn) {
            for (let b of btns) {
                const t = (b.innerText || "").trim().toLowerCase();
                if (t.includes("next") && b.offsetParent !== null && !b.disabled) {
                    nextBtn = b; break;
                }
            }
        }
        if (nextBtn) {
            console.log("🎯 Next click attempt " + attempt);
            await forceClickButton(nextBtn);
            await delay(800);
            const p = detectPage();
            if (p !== "USERNAME" && p !== "FULLNAME" && p !== "UNKNOWN") {
                return true;
            }
        } else {
            await delay(300);
        }
    }
    return false;
}

// ⚡⚡⚡ ULTRA AGGRESSIVE Next click — 6 layers
async function clickNextOnce() {
    let nextBtn = null;
    const btns = document.querySelectorAll('button, div[role="button"], [role="button"]');

    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t === "next" && b.offsetParent !== null) {
            nextBtn = b; break;
        }
    }
    if (!nextBtn) {
        for (let b of btns) {
            const t = (b.innerText || "").trim().toLowerCase();
            if (t.includes("next") && t.length < 30 && b.offsetParent !== null) {
                nextBtn = b; break;
            }
        }
    }
    if (!nextBtn) return false;

    try { nextBtn.removeAttribute('disabled'); } catch (e) {}

    const r = nextBtn.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;

    try { nextBtn.click(); } catch (e) {}
    try { nextBtn.focus(); } catch (e) {}
    try { nextBtn.click(); } catch (e) {}

    try {
        const o = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
        nextBtn.dispatchEvent(new MouseEvent('mousedown', o));
        nextBtn.dispatchEvent(new MouseEvent('mouseup', o));
        nextBtn.dispatchEvent(new MouseEvent('click', o));
    } catch (e) {}

    try {
        ['pointerdown', 'pointerup', 'click'].forEach(type => {
            nextBtn.dispatchEvent(new PointerEvent(type, {
                bubbles: true, cancelable: true, view: window,
                clientX: x, clientY: y, button: 0, pointerId: 1, isPrimary: true
            }));
        });
    } catch (e) {}

    try {
        const el = document.elementFromPoint(x, y);
        if (el) {
            el.dispatchEvent(new PointerEvent('pointerdown', {
                bubbles: true, cancelable: true, view: window,
                clientX: x, clientY: y, button: 0, pointerId: 1
            }));
            el.dispatchEvent(new PointerEvent('pointerup', {
                bubbles: true, cancelable: true, view: window,
                clientX: x, clientY: y, button: 0, pointerId: 1
            }));
            el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, clientX: x, clientY: y }));
            el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, clientX: x, clientY: y }));
            el.dispatchEvent(new MouseEvent('click', { bubbles: true, clientX: x, clientY: y }));
            try { el.click(); } catch (e) {}
        }
    } catch (e) {}

    try {
        const uInput = document.querySelector('input[name="username"]');
        if (uInput) {
            ['keydown', 'keypress', 'keyup'].forEach(type => {
                uInput.dispatchEvent(new KeyboardEvent(type, {
                    bubbles: true, cancelable: true,
                    key: 'Enter', code: 'Enter', keyCode: 13, which: 13
                }));
            });
        }
    } catch (e) {}

    return true;
}

async function closeAllPopups() {
    const popupsToClose = ["Not Now", "Not now", "Cancel", "Close", "Dismiss", "Later", "No Thanks", "No thanks", "Maybe Later"];
    for (let popupText of popupsToClose) {
        const els = document.querySelectorAll('button, div[role="button"], a[role="button"]');
        for (let el of els) {
            const t = (el.innerText || "").trim();
            if (t === popupText && el.offsetParent !== null) {
                try { el.click(); } catch (e) {}
            }
        }
    }
}

function startPopupWatcher() {
    setInterval(closeAllPopups, 2000);
}

// ══════════════════════════════════════════════════════════
// 🧭 PAGE DETECT — with CONNECT_FB + CANNOT_FIND
// ══════════════════════════════════════════════════════════
function detectPage() {
    const url = window.location.href;
    const bodyText = (document.body ? document.body.innerText : "").toLowerCase();

    // ⭐ "Can't find account" popup — থাকলে fail state
    if (bodyText.includes("can't find account") ||
        bodyText.includes("cant find account") ||
        bodyText.includes("we can't find an account with")) {
        console.log("📍 PAGE: CANNOT_FIND");
        return "CANNOT_FIND";
    }

    // ⭐ CONNECT_FB — Account created! Cookie save করার সময়
    if (bodyText.includes("connect to facebook") ||
        bodyText.includes("find friends to follow")) {
        const btns = document.querySelectorAll('button, div[role="button"], a[role="button"], span[role="button"]');
        for (let b of btns) {
            const t = (b.innerText || "").trim().toLowerCase();
            if (t === "connect to facebook" && b.offsetParent !== null) {
                console.log("📍 PAGE: CONNECT_FB (button found)");
                return "CONNECT_FB";
            }
        }
        console.log("📍 PAGE: CONNECT_FB (text hint)");
        return "CONNECT_FB";
    }

    if (bodyText.includes("suggested for you") ||
        bodyText.includes("suggestions for you")) {
        console.log("📍 PAGE: HOME (suggested for you text)");
        return "HOME";
    }

    let followBtnCount = 0;
    const allBtns = document.querySelectorAll('button, div[role="button"]');
    for (let b of allBtns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t === "follow" && b.offsetParent !== null) {
            followBtnCount++;
            if (followBtnCount >= 3) break;
        }
    }
    if (followBtnCount >= 3) {
        console.log("📍 PAGE: HOME (" + followBtnCount + " follow buttons)");
        return "HOME";
    }

    const homeNavIcon = document.querySelector('svg[aria-label="Home"]') ||
                        document.querySelector('[aria-label="Home"]') ||
                        document.querySelector('a[href="/"]');
    if (homeNavIcon && url.includes("instagram.com") &&
        !url.includes("/accounts/login") &&
        !url.includes("/accounts/emailsignup") &&
        !url.includes("/accounts/signup")) {
        console.log("📍 PAGE: HOME (bottom nav)");
        return "HOME";
    }

    if (bodyText.includes("no instagram account found") ||
        bodyText.includes("matched an existing meta account") ||
        bodyText.includes("find your instagram account")) {
        console.log("📍 PAGE: NO_ACCOUNT_FOUND");
        return "NO_ACCOUNT_FOUND";
    }

    if (url.includes("/accounts/login") ||
        url.includes("/accounts/emailsignup") ||
        url.includes("/accounts/signup")) {
        const hasUser = document.querySelector('input[name="username"]');
        const hasPass = document.querySelector('input[name="password"]');
        if (hasUser && hasPass) {
            console.log("📍 PAGE: LOGIN");
            return "LOGIN";
        }
    }

    if (bodyText.includes("what's your name") ||
        bodyText.includes("add your name so that friends") ||
        bodyText.includes("add your name")) {
        console.log("📍 PAGE: FULLNAME (text hint)");
        return "FULLNAME";
    }

    if (bodyText.includes("create a username for instagram") ||
        bodyText.includes("create a username") ||
        bodyText.includes("use our suggestion") ||
        bodyText.includes("add a username")) {
        console.log("📍 PAGE: USERNAME (text hint)");
        return "USERNAME";
    }

    const fnInput = document.querySelector('input[name="full_name"]') ||
                    document.querySelector('input[aria-label="Full name"]');
    if (fnInput && fnInput.offsetParent !== null) {
        console.log("📍 PAGE: FULLNAME (dom)");
        return "FULLNAME";
    }

    {
        const userField = document.querySelector('input[name="username"]') ||
                          document.querySelector('input[aria-label="Username"]');
        const userVisible = userField && userField.offsetParent !== null;
        const passField = document.querySelector('input[type="password"]');
        const passVisible = passField && passField.offsetParent !== null;

        if (userVisible && !passVisible && !url.includes("/accounts/login")) {
            let hasNext = false;
            const bs = document.querySelectorAll('button, div[role="button"]');
            for (let b of bs) {
                const t = (b.innerText || "").trim().toLowerCase();
                if ((t === "next" || t.includes("next")) &&
                    b.offsetParent !== null && !b.disabled) {
                    hasNext = true; break;
                }
            }
            const hasSuggested = bodyText.includes("suggested") ||
                                 bodyText.includes("use our suggestion") ||
                                 bodyText.includes("pick a username");
            if (hasNext || hasSuggested) {
                console.log("📍 PAGE: USERNAME (field+next/suggested)");
                return "USERNAME";
            }
            console.log("📍 PAGE: USERNAME (field only)");
            return "USERNAME";
        }
    }

    {
        const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
        for (let b of btns) {
            const t = (b.innerText || "").trim().toLowerCase();
            if ((t === "allow and continue" || t === "allow") &&
                b.offsetParent !== null && !b.disabled) {
                console.log("📍 PAGE: ALLOW");
                return "ALLOW";
            }
        }
    }

    {
        const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
        for (let b of btns) {
            const t = (b.innerText || "").trim().toLowerCase();
            if ((t === "i agree" || (t.includes("agree") && t.length < 40)) &&
                b.offsetParent !== null && !b.disabled) {
                console.log("📍 PAGE: AGREE");
                return "AGREE";
            }
        }
    }

    if (bodyText.includes("skip") &&
        (bodyText.includes("phone") || bodyText.includes("add phone"))) {
        console.log("📍 PAGE: SKIP");
        return "SKIP";
    }

    if (bodyText.includes("hbx bhai") || bodyText.includes("hbxbhai")) {
        let hbxInInput = false;
        const inputs = document.querySelectorAll('input, textarea');
        for (let inp of inputs) {
            const v = (inp.value || '').toLowerCase();
            if (v.includes('hbx bhai') || v.includes('hbxbhai')) {
                hbxInInput = true; break;
            }
        }
        if (!hbxInInput) {
            const divBtns = document.querySelectorAll('div[role="button"]');
            for (let b of divBtns) {
                if (b.querySelector('img') && b.offsetParent !== null) {
                    console.log("📍 PAGE: HBX_CARD (card with img)");
                    return "HBX_CARD";
                }
            }
            if (!document.querySelector('input[type="text"]') &&
                !document.querySelector('input:not([type])')) {
                console.log("📍 PAGE: HBX_CARD (text only)");
                return "HBX_CARD";
            }
        }
        console.log("⚠️ 'hbx bhai' in input — NOT hbx card");
    }

    if (url.includes("/accounts/registered")) {
        console.log("📍 PAGE: HOME (registered)");
        return "HOME";
    }

    console.log("📍 PAGE: UNKNOWN (url=" + url.substring(0, 80) + ")");
    return "UNKNOWN";
}

function hbxBhaiExists() {
    const bodyText = (document.body ? document.body.innerText : "").toLowerCase();
    return bodyText.includes("hbx bhai") || bodyText.includes("hbxbhai");
}

// ==========================================
// 🧹 JS CLEAR
// ==========================================
async function jsClearAllStorage() {
    for (let pass = 0; pass < 2; pass++) {
        try {
            const cookies = document.cookie.split(";");
            for (let cookie of cookies) {
                const eqPos = cookie.indexOf("=");
                const name = eqPos > -1 ? cookie.substr(0, eqPos).trim() : cookie.trim();
                if (name) {
                    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
                    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.instagram.com";
                    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=www.instagram.com";
                    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.facebook.com";
                    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.meta.com";
                }
            }
        } catch (e) {}
        await delay(30);
    }
    try { localStorage.clear(); } catch (e) {}
    try { sessionStorage.clear(); } catch (e) {}
    try {
        if (indexedDB.databases) {
            const dbs = await indexedDB.databases();
            for (let db of dbs) if (db.name) indexedDB.deleteDatabase(db.name);
        }
    } catch (e) {}
    try {
        if (typeof caches !== 'undefined') {
            const names = await caches.keys();
            for (let name of names) await caches.delete(name);
        }
    } catch (e) {}
    try {
        if (navigator.serviceWorker) {
            const regs = await navigator.serviceWorker.getRegistrations();
            for (let reg of regs) await reg.unregister();
        }
    } catch (e) {}
}

// ==========================================
// FIND INPUTS
// ==========================================
async function findFullNameInput() {
    let el = document.querySelector('input[name="full_name"]');
    if (el && el.offsetParent !== null) return el;
    el = document.querySelector('input[aria-label="Full name"]');
    if (el && el.offsetParent !== null) return el;
    const inputs = document.querySelectorAll('input[type="text"], input:not([type])');
    for (let i of inputs) {
        if (i.offsetParent !== null) return i;
    }
    return null;
}

async function findUsernameInput() {
    let el = document.querySelector('input[name="username"]');
    if (el && el.offsetParent !== null) return el;
    el = document.querySelector('input[aria-label="Username"]');
    if (el && el.offsetParent !== null) return el;
    return null;
}

async function findUsernameLoginInput() {
    let el = document.querySelector('input[name="username"]');
    if (el && el.offsetParent !== null) return el;
    el = document.querySelector('input[aria-label*="username" i]');
    if (el && el.offsetParent !== null) return el;
    el = document.querySelector('input[aria-label*="email" i]');
    if (el && el.offsetParent !== null) return el;
    return null;
}

async function findPasswordInput() {
    let el = document.querySelector('input[name="password"]');
    if (el && el.offsetParent !== null) return el;
    el = document.querySelector('input[type="password"]');
    if (el && el.offsetParent !== null) return el;
    return null;
}

// ==========================================
// 💡 CAPTURE SUGGESTED USERNAME
// ==========================================
function captureSuggestedUsername() {
    try {
        const input = document.querySelector('input[name="username"]') ||
                      document.querySelector('input[aria-label="Username"]');
        if (input && input.value && input.value.length > 2) {
            return input.value;
        }

        const all = document.querySelectorAll('span, div, p, label');
        for (const el of all) {
            if (el.children.length > 0) continue;
            if (el.offsetParent === null) continue;
            const t = (el.textContent || '').trim().toLowerCase();
            if (t === 'suggested' || t === 'suggested for you' ||
                t.includes('use our suggestion')) {
                let sib = el.parentElement;
                for (let i = 0; i < 3 && sib; i++) {
                    const texts = sib.querySelectorAll('span, div, p');
                    for (const tx of texts) {
                        const v = (tx.textContent || '').trim();
                        if (/^[a-z0-9._]{5,30}$/i.test(v)) {
                            console.log("💡 Suggested username: " + v);
                            return v;
                        }
                    }
                    sib = sib.parentElement;
                }
            }
        }
    } catch (e) {}
    return null;
}

// ==========================================
// 🎲 RANDOM NAME POOL
// ==========================================
const FIRST_NAMES_POOL = [
    "james", "john", "robert", "michael", "william", "david", "richard",
    "joseph", "thomas", "charles", "christopher", "daniel", "matthew",
    "anthony", "mark", "donald", "steven", "paul", "andrew", "joshua",
    "kenneth", "kevin", "brian", "george", "edward", "ronald", "timothy",
    "jason", "jeffrey", "ryan", "jacob", "gary", "nicholas", "eric",
    "jonathan", "stephen", "larry", "justin", "scott", "brandon",
    "benjamin", "samuel", "gregory", "frank", "alexander", "raymond",
    "patrick", "jack", "dennis", "jerry", "tyler", "aaron", "jose",
    "adam", "nathan", "henry", "zachary", "douglas", "peter", "kyle",
    "noah", "ethan", "jeremy", "walter", "christian", "keith", "roger",
    "terry", "gerald", "harold", "sean", "austin", "carl", "arthur",
    "lawrence", "dylan", "jesse", "jordan", "bryan", "billy", "bruce",
    "gabriel", "joe", "logan", "albert", "willie", "alan", "eugene",
    "russell", "vincent", "philip", "bobby", "johnny", "bradley",
    "mary", "patricia", "jennifer", "linda", "elizabeth", "barbara",
    "susan", "jessica", "sarah", "karen", "nancy", "lisa", "margaret",
    "betty", "sandra", "ashley", "dorothy", "kimberly", "emily",
    "donna", "michelle", "carol", "amanda", "melissa", "deborah",
    "stephanie", "rebecca", "laura", "sharon", "cynthia", "kathleen",
    "amy", "shirley", "angela", "helen", "anna", "brenda", "pamela",
    "nicole", "samantha", "katherine", "christine", "debra", "rachel",
    "carolyn", "janet", "catherine", "maria", "heather", "diane",
    "ruth", "julie", "olivia", "joyce", "virginia", "victoria",
    "kelly", "lauren", "christina", "joan", "evelyn", "judith",
    "megan", "cheryl", "andrea", "hannah", "martha", "jacqueline",
    "frances", "gloria", "ann", "teresa", "kathryn", "sara",
    "janice", "jean", "alice", "madison", "doris", "abigail",
    "julia", "judy", "grace", "denise", "amber", "marilyn",
    "beverly", "danielle", "theresa", "sophia", "marie", "diana",
    "brittany", "natalie", "isabella", "charlotte", "rose", "alexis",
    "kayla", "taylor", "brianna", "savannah", "destiny", "morgan",
    "sierra", "mackenzie", "brooklyn", "aaliyah", "zoe", "layla",
    "riley", "aria", "lily", "chloe", "ella", "scarlett", "grace"
];

// ==========================================
// 🔒 PERSISTENT USERNAME TRACKER
// ==========================================
if (!window.__hbxUsedUsernames) {
    window.__hbxUsedUsernames = new Set();
}

(async () => {
    try {
        const s = await chrome.storage.local.get(['usedUsernames']);
        if (s.usedUsernames && Array.isArray(s.usedUsernames)) {
            s.usedUsernames.forEach(u => window.__hbxUsedUsernames.add(u));
            console.log("📚 Loaded " + s.usedUsernames.length + " previously used usernames");
        }
    } catch (e) {}
})();

async function persistUsedUsername(username) {
    try {
        const s = await chrome.storage.local.get(['usedUsernames']);
        const list = s.usedUsernames || [];
        if (!list.includes(username)) {
            list.push(username);
            const trimmed = list.slice(-5000);
            await chrome.storage.local.set({ usedUsernames: trimmed });
        }
    } catch (e) {}
}

// ==========================================
// 🎲 RANDOM USERNAME GENERATOR
// ==========================================
function generateRandomUsername() {
    const MAX_TRIES = 100;
    for (let i = 0; i < MAX_TRIES; i++) {
        const first = FIRST_NAMES_POOL[Math.floor(Math.random() * FIRST_NAMES_POOL.length)];
        const digits = Math.floor(Math.random() * 90000) + 10000;
        const username = first + digits + "hbx";
        if (!window.__hbxUsedUsernames.has(username)) {
            window.__hbxUsedUsernames.add(username);
            console.log("🎲 Generated username: " + username +
                        " (total used: " + window.__hbxUsedUsernames.size + ")");
            return username;
        }
    }
    const fallback = "user" + Date.now().toString().slice(-8) + "hbx";
    window.__hbxUsedUsernames.add(fallback);
    return fallback;
}

// ==========================================
// 🎲 RANDOM FULL NAME
// ==========================================
const LAST_NAMES_POOL = [
    "smith", "johnson", "williams", "brown", "jones", "garcia", "miller",
    "davis", "rodriguez", "martinez", "hernandez", "lopez", "gonzalez",
    "wilson", "anderson", "thomas", "taylor", "moore", "jackson", "martin",
    "lee", "perez", "thompson", "white", "harris", "sanchez", "clark",
    "ramirez", "lewis", "robinson", "walker", "young", "allen", "king",
    "wright", "scott", "torres", "nguyen", "hill", "flores", "green",
    "adams", "nelson", "baker", "hall", "rivera", "campbell", "mitchell",
    "carter", "roberts", "gomez", "phillips", "evans", "turner", "diaz",
    "parker", "cruz", "edwards", "collins", "reyes", "stewart", "morris",
    "morales", "murphy", "cook", "rogers", "gutierrez", "ortiz", "morgan",
    "cooper", "peterson", "bailey", "reed", "kelly", "howard", "ramos",
    "kim", "cox", "ward", "richardson", "watson", "brooks", "chavez",
    "wood", "james", "bennett", "gray", "mendoza", "ruiz", "hughes",
    "price", "alvarez", "castillo", "sanders", "patel", "myers", "long",
    "ross", "foster", "jimenez"
];

function generateRandomFullName() {
    const first = FIRST_NAMES_POOL[Math.floor(Math.random() * FIRST_NAMES_POOL.length)];
    const last = LAST_NAMES_POOL[Math.floor(Math.random() * LAST_NAMES_POOL.length)];
    const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
    return cap(first) + " " + cap(last);
}

// ==========================================
// 📸 COOKIE FROM BACKGROUND
// ==========================================
async function getFullCookieFromBackground() {
    notify("📸 Getting full cookie...");
    try {
        const response = await new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: "getFullCookie" }, (resp) => {
                if (chrome.runtime.lastError) resolve(null);
                else resolve(resp);
            });
        });
        if (response && response.success) {
            notify("✅ Cookie: " + response.count + " items", "success");
            return response;
        }
        return null;
    } catch (e) { return null; }
}

// ==========================================
// 🚨 FAIL → NEXT ID
// ==========================================
async function failToNextId(reason) {
    console.log("❌ FAIL: " + reason);
    notify("❌ " + reason + " — next ID", "error");

    const data = await chrome.storage.local.get(['currentIndex', 'totalAccounts', 'accounts']);
    const nextIdx = (data.currentIndex || 0) + 1;
    const total2 = data.totalAccounts || (data.accounts || []).length;

    await chrome.storage.local.set({ currentIndex: nextIdx });
    await chrome.storage.local.set({ currentUsername: "" });

    try { await jsClearAllStorage(); } catch (e) {}
    try { chrome.runtime.sendMessage({ action: "clearData" }, () => {}); } catch (e) {}
    await delay(2000);

    if (nextIdx >= total2) {
        await chrome.storage.local.set({ isRunning: false });
        notify("🎉 All done (with fails)", "success");
        return;
    }

    notify("🔄 New ID → reload (" + (nextIdx + 1) + "/" + total2 + ")");
    const newUrl = "https://www.instagram.com/accounts/login/?mtn&t=" + Date.now();
    try { window.location.replace(newUrl); }
    catch (e) { window.location.href = newUrl; }
}

// ==========================================
// 🔄 REFRESH SAME ID
// ==========================================
async function refreshSameId(reason) {
    console.log("🔄 Refresh: " + reason);
    notify("🔄 Refresh → retry same ID");
    await delay(300);
    const newUrl = "https://www.instagram.com/accounts/login/?mtn&t=" + Date.now();
    try { window.location.replace(newUrl); }
    catch (e) { window.location.href = newUrl; }
}

// ==========================================
// 🔐 LOGIN STEP — fail → next ID
// ==========================================
async function doLoginStep(email, password) {
    notify("🔐 Login: " + email.substring(0, 22));

    let emailInput = null;
    for (let a = 0; a < 30; a++) {
        emailInput = await findUsernameLoginInput();
        if (emailInput) break;
        await delay(80);
    }
    if (!emailInput) { notify("⚠️ Email field missing", "error"); return false; }
    await clearInput(emailInput);
    await delay(50);
    await realTimeType(emailInput, email);

    let passInput = null;
    for (let a = 0; a < 30; a++) {
        passInput = await findPasswordInput();
        if (passInput) break;
        await delay(80);
    }
    if (!passInput) { notify("⚠️ Password field missing", "error"); return false; }
    await clearInput(passInput);
    await delay(50);
    await realTimeType(passInput, password);

    let loginBtn = await getElement('button[type="submit"]', 2000)
                || await getButtonByText("Log in", 2000);
    if (!loginBtn) { notify("⚠️ Login btn missing", "error"); return false; }

    notify("🖱️ Clicking Log in...");
    await forceClickButton(loginBtn);

    // ⭐ Wait up to 8s — detect popup or page change
    notify("⏳ Wait 8s...");
    const waitStart = Date.now();
    while (Date.now() - waitStart < 8000) {
        await delay(300);

        const bt = (document.body ? document.body.innerText : "").toLowerCase();

        // ❌ "Can't find account" popup
        if (bt.includes("can't find account") ||
            bt.includes("cant find account") ||
            bt.includes("we can't find an account with") ||
            bt.includes("try another mobile number") ||
            bt.includes("if you don't have an account")) {
            console.log("❌ 'Can't find account' popup detected");
            notify("❌ Account not found — next ID", "error");
            return "NO_ACCOUNT";
        }

        // ❌ Wrong password
        if (bt.includes("your password was incorrect") ||
            bt.includes("sorry, your password") ||
            bt.includes("the password you entered is incorrect") ||
            bt.includes("password is incorrect")) {
            console.log("❌ Wrong password popup");
            notify("❌ Wrong password — next ID", "error");
            return "NO_ACCOUNT";
        }

        // ✅ Page moved past login
        const p = detectPage();
        if (p === "HBX_CARD" || p === "NO_ACCOUNT_FOUND") {
            notify("✅ hbx Bhai page!", "success");
            return "HBX";
        }
        if (p === "FULLNAME" || p === "USERNAME") {
            notify("✅ Moved to " + p, "success");
            return "PROGRESSED";
        }
        if (p === "HOME" || p === "CONNECT_FB") {
            notify("✅ " + p, "success");
            return "HOME";
        }
        if (p === "ALLOW" || p === "AGREE" || p === "SKIP") {
            notify("✅ Moved to " + p, "success");
            return "PROGRESSED";
        }
    }

    // Timeout — fail
    console.log("❌ Login timeout — next ID");
    notify("❌ Login timeout — next ID", "error");
    return "NO_ACCOUNT";
}

async function clickHbxCard() {
    notify("🎯 Clicking hbx Bhai card...");

    const MAX_HBX_RETRIES = 3;
    for (let hbxTry = 1; hbxTry <= MAX_HBX_RETRIES; hbxTry++) {
        console.log("🎯 HBX attempt " + hbxTry + "/" + MAX_HBX_RETRIES);
        notify("🎯 HBX try " + hbxTry + "/" + MAX_HBX_RETRIES, "info");

        for (let round = 1; round <= 6; round++) {
            console.log("🎯 HBX round " + round);

            const preCheck = detectPage();
            if (preCheck === "FULLNAME" || preCheck === "USERNAME" ||
                preCheck === "ALLOW" || preCheck === "AGREE" ||
                preCheck === "HOME" || preCheck === "CONNECT_FB") {
                notify("✅ Already on " + preCheck, "success");
                return true;
            }

            const divBtns = document.querySelectorAll('div[role="button"]');
            for (let b of divBtns) {
                if (b.offsetParent === null) continue;
                const img = b.querySelector('img');
                const txt = (b.innerText || "").toLowerCase();
                if ((img && (img.alt || "").toLowerCase().includes("hbx")) ||
                    txt.includes("hbx bhai")) {
                    console.log("👉 Clicking hbx card (strategy 1)");
                    await forceClickButton(b);
                    await delay(500);
                }
            }

            const all = document.querySelectorAll('div, span, p, h3');
            for (let el of all) {
                if (el.offsetParent === null) continue;
                if (el.children.length > 0) continue;
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') continue;
                const t = (el.textContent || "").trim().toLowerCase();
                if (t === "hbx bhai") {
                    let p = el;
                    for (let i = 0; i < 6 && p; i++) {
                        if (p.getAttribute && (p.getAttribute('role') === 'button' ||
                            p.tagName === 'BUTTON' || p.tagName === 'A')) {
                            console.log("👉 Clicking hbx ancestor " + i);
                            await forceClickButton(p);
                            await delay(350);
                            break;
                        }
                        p = p.parentElement;
                    }
                    try {
                        const r = el.getBoundingClientRect();
                        if (r.width > 0 && r.height > 0) {
                            const x = r.left + r.width / 2;
                            const y = r.top + r.height / 2;
                            const topEl = document.elementFromPoint(x, y);
                            if (topEl && topEl.tagName !== 'INPUT') await forceClickButton(topEl);
                            await delay(250);
                        }
                    } catch (e) {}
                }
            }

            for (let el of all) {
                if (el.offsetParent === null) continue;
                if (el.children.length > 0) continue;
                const t = (el.textContent || "").trim().toLowerCase();
                if (t === "meta horizon") {
                    let p = el;
                    for (let i = 0; i < 6 && p; i++) {
                        const r = p.getBoundingClientRect();
                        if (r.width > 200 && r.height > 50) {
                            try {
                                const x = r.left + r.width - 25;
                                const y = r.top + r.height / 2;
                                const arrowEl = document.elementFromPoint(x, y);
                                if (arrowEl) await forceClickButton(arrowEl);
                                await delay(250);
                            } catch (e) {}
                            await forceClickButton(p);
                            await delay(250);
                            break;
                        }
                        p = p.parentElement;
                    }
                }
            }

            await delay(500);
            const after = detectPage();
            console.log("📍 After hbx click round " + round + ": " + after);
            if (after === "FULLNAME" || after === "USERNAME" ||
                after === "ALLOW" || after === "AGREE" ||
                after === "HOME" || after === "SKIP" ||
                after === "CONNECT_FB") {
                notify("✅ Moved to " + after, "success");
                return true;
            }
        }

        if (hbxTry < MAX_HBX_RETRIES) {
            notify("⏳ HBX try " + hbxTry + " failed — retry", "info");
            console.log("⚠️ HBX try " + hbxTry + " failed, waiting 1.5s...");
            await delay(1500);
        }
    }

    notify("❌ HBX card not found", "error");
    console.log("❌ HBX card failed after 3 retries");
    return false;
}

// ==========================================
// 📝 FULL NAME
// ==========================================
async function doFullNameStep() {
    notify("📝 Full Name...");
    await smartWait(() =>
        document.querySelector('input[name="full_name"]') ||
        document.querySelector('input[aria-label="Full name"]'), 4000, 40);

    const nameInput = await findFullNameInput();
    if (nameInput) {
        await clearInput(nameInput);
        await delay(80);

        const randomName = generateRandomFullName();
        notify("Name: " + randomName);
        await realTimeType(nameInput, randomName);
        await delay(200);
        await clickNext();
        await delay(800);
        return true;
    }
    return false;
}

// ══════════════════════════════════════════════════════════
// 👤 USERNAME
// ══════════════════════════════════════════════════════════
function hasUsernameGreenTick() {
    const userInput = document.querySelector('input[name="username"]') ||
                      document.querySelector('input[aria-label="Username"]');
    if (!userInput) return false;

    let scope = userInput.parentElement;
    for (let i = 0; i < 4 && scope && scope.parentElement; i++) {
        scope = scope.parentElement;
    }
    if (!scope) scope = document.body;

    const svgs = scope.querySelectorAll('svg');
    for (const svg of svgs) {
        if (svg.offsetParent === null) continue;
        const rect = svg.getBoundingClientRect();
        if (rect.width < 8 || rect.width > 60) continue;

        const cs = getComputedStyle(svg);
        const allColors = (
            cs.fill + ' ' + cs.color + ' ' + cs.stroke + ' ' +
            (svg.getAttribute('fill') || '') + ' ' +
            (svg.getAttribute('stroke') || '') + ' ' +
            (svg.getAttribute('style') || '')
        ).toLowerCase();

        let isGreen = false;

        const rgbMatch = allColors.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
        if (rgbMatch) {
            const r = parseInt(rgbMatch[1]);
            const g = parseInt(rgbMatch[2]);
            const b = parseInt(rgbMatch[3]);
            if (g > 130 && g > r + 40 && g > b + 30) isGreen = true;
        }

        if (!isGreen) {
            if (/green|#00ba7c|#00c04b|#22c55e|#16a34a|#0fb948|#34d399|#10b981|#059669/i.test(allColors)) {
                isGreen = true;
            }
        }

        const path = svg.querySelector('path');
        const circle = svg.querySelector('circle');
        const hasShape = path || circle;

        if (isGreen && hasShape) {
            console.log("✅ Green tick (SVG green shape)");
            return true;
        }

        if (hasShape) {
            const stroke = (cs.stroke || '').toLowerCase();
            const strokeRgb = stroke.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
            if (strokeRgb) {
                const r = parseInt(strokeRgb[1]);
                const g = parseInt(strokeRgb[2]);
                const b = parseInt(strokeRgb[3]);
                if (g > 130 && g > r + 40 && g > b + 20) {
                    console.log("✅ Green tick (stroke green)");
                    return true;
                }
            }
        }
    }

    const labeled = scope.querySelectorAll('[aria-label]');
    for (const el of labeled) {
        if (el.offsetParent === null) continue;
        const l = (el.getAttribute('aria-label') || '').toLowerCase();
        if (l.includes('check') || l.includes('success') ||
            l.includes('available') || l.includes('valid')) {
            console.log("✅ Green tick (aria)");
            return true;
        }
    }

    const globalGreen = document.querySelectorAll(
        'svg[aria-label*="check" i], svg[aria-label*="success" i]'
    );
    for (const s of globalGreen) {
        if (s.offsetParent !== null) return true;
    }

    const imgs = scope.querySelectorAll('img');
    for (const img of imgs) {
        if (img.offsetParent === null) continue;
        const src = (img.src || '').toLowerCase();
        const alt = (img.alt || '').toLowerCase();
        if (src.includes('check') || src.includes('success') || src.includes('green') ||
            alt.includes('check') || alt.includes('success')) {
            console.log("✅ Green tick (img)");
            return true;
        }
    }

    return false;
}

function isUsernameCheckLoading() {
    const spinners = document.querySelectorAll(
        'svg[aria-label*="loading" i], ' +
        'div[role="progressbar"], ' +
        '[class*="spinner" i]:not([class*="tick" i]), ' +
        '[class*="loading" i]:not([class*="loaded" i])'
    );
    for (const sp of spinners) {
        if (sp.offsetParent !== null) return true;
    }
    return false;
}

async function doUsernameStep() {
    notify("👤 Username step...");
    await delay(150);

    const MAX_ATTEMPTS = 5;
    let finalUsername = "";

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        console.log("👤 Username attempt " + attempt + "/" + MAX_ATTEMPTS);

        const userInput = await findUsernameInput();
        if (!userInput) {
            console.log("⚠️ Username input missing");
            await delay(500);
            const p = detectPage();
            if (p !== "USERNAME" && p !== "UNKNOWN") {
                notify("✅ Already left username → " + p, "success");
                return finalUsername;
            }
            continue;
        }

        if (!userInput.value || userInput.value.length < 2) {
            captureSuggestedUsername();
        }

        const thisUsername = generateRandomUsername();
        await persistUsedUsername(thisUsername);
        finalUsername = thisUsername;

        await clearInput(userInput);
        await delay(30);
        userInput.focus();
        userInput.click();

        const setter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value'
        ).set;

        for (let i = 0; i < thisUsername.length; i++) {
            const ch = thisUsername[i];
            setter.call(userInput, userInput.value + ch);
            userInput.dispatchEvent(new Event('input', { bubbles: true }));
            await delay(8 + Math.random() * 12);
        }
        userInput.dispatchEvent(new Event('change', { bubbles: true }));
        userInput.dispatchEvent(new Event('blur', { bubbles: true }));
        userInput.focus();

        notify("Try " + attempt + ": " + thisUsername);
        await chrome.storage.local.set({ currentUsername: thisUsername });

        notify("⏳ Checking...", "info");
        const checkStart = Date.now();
        const MAX_CHECK_WAIT = 4000;
        let tickDetected = false;
        let rejected = false;

        while (Date.now() - checkStart < MAX_CHECK_WAIT) {
            await delay(80);

            if (hasUsernameGreenTick()) {
                tickDetected = true;
                console.log("✅ GREEN TICK in " +
                    Math.floor(Date.now() - checkStart) + "ms");
                break;
            }

            const bt = (document.body ? document.body.innerText : "").toLowerCase();
            if (bt.includes("not available") ||
                bt.includes("try another") ||
                bt.includes("isn't available") ||
                bt.includes("is not available") ||
                bt.includes("choose a username") ||
                bt.includes("username is taken")) {
                rejected = true;
                console.log("❌ Username rejected");
                break;
            }

            const p = detectPage();
            if (p !== "USERNAME" && p !== "UNKNOWN") {
                console.log("✅ Page already moved to " + p);
                return finalUsername;
            }
        }

        if (tickDetected) {
            notify("✅ Tick → Next!", "success");
            console.log("⚡ GREEN → clicking Next IMMEDIATELY");

            const checkInput = document.querySelector('input[name="username"]');
            if (checkInput && checkInput.value !== thisUsername) {
                console.log("⚠️ Username changed! Re-typing...");
                await clearInput(checkInput);
                await delay(20);
                const s2 = Object.getOwnPropertyDescriptor(
                    window.HTMLInputElement.prototype, 'value'
                ).set;
                s2.call(checkInput, thisUsername);
                checkInput.dispatchEvent(new Event('input', { bubbles: true }));
                await delay(150);
            }

            let moved = false;
            const clickStart = Date.now();
            let clickCount = 0;

            while (Date.now() - clickStart < 4000) {
                clickCount++;
                console.log("🖱️ Next click attempt #" + clickCount);

                await clickNextOnce();
                await delay(350);

                const currentPage = detectPage();
                console.log("📍 After click #" + clickCount + " = " + currentPage);

                if (currentPage !== "USERNAME" && currentPage !== "UNKNOWN") {
                    notify("✅ Accepted → " + currentPage, "success");
                    moved = true;
                    break;
                }

                const stillHasInput = document.querySelector('input[name="username"]');
                const stillHasNext = (() => {
                    const bs = document.querySelectorAll('button, div[role="button"]');
                    for (let b of bs) {
                        const t = (b.innerText || '').trim().toLowerCase();
                        if (t === 'next' && b.offsetParent !== null) return true;
                    }
                    return false;
                })();

                if (!stillHasInput || !stillHasNext) {
                    console.log("✅ Input/Next gone → assumed moved");
                    notify("✅ Accepted (assumed)", "success");
                    moved = true;
                    break;
                }

                if (!hasUsernameGreenTick()) {
                    console.log("⚠️ Green gone — waiting");
                    await delay(200);
                }
            }

            if (moved) return finalUsername;

            console.log("⚠️ Next click loop failed — new username");
            notify("⚠️ Stuck — new username", "error");
            await delay(300);
            continue;
        }

        if (rejected) notify("⚠️ Rejected — new name", "error");
        else notify("⚠️ No tick — retry", "error");
        await delay(300);
    }

    notify("❌ Username failed", "error");
    return finalUsername;
}

// ══════════════════════════════════════════════════════════
// ✅ ALLOW — max 20s wait
// ══════════════════════════════════════════════════════════
async function tryClickAllowOnce() {
    const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t === "allow and continue" && b.offsetParent !== null && !b.disabled) {
            await forceClickButton(b); return true;
        }
    }
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t === "allow" && b.offsetParent !== null && !b.disabled) {
            await forceClickButton(b); return true;
        }
    }
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t.includes("allow") && t.length < 60 && b.offsetParent !== null && !b.disabled) {
            await forceClickButton(b); return true;
        }
    }
    return false;
}

function allowButtonStillExists() {
    const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if ((t === "allow and continue" || t === "allow" || (t.includes("allow") && t.length < 60)) &&
            b.offsetParent !== null && !b.disabled) {
            return true;
        }
    }
    return false;
}

async function doAllowWithRetry() {
    notify("✅ Allow & Continue...");

    const clicked = await tryClickAllowOnce();
    if (!clicked) {
        console.log("⚠️ No allow button found");
        await delay(800);
        const p = detectPage();
        if (p !== "ALLOW") {
            notify("✅ Already moved to " + p, "success");
            return true;
        }
        console.log("❌ Allow button missing → fail");
        return false;
    }

    notify("⏳ Wait 20s (max)...");
    const waitStart = Date.now();
    const MAX_WAIT = 20000;
    let lastLogSec = -1;

    while (Date.now() - waitStart < MAX_WAIT) {
        await delay(400);

        const elapsed = Math.floor((Date.now() - waitStart) / 1000);
        if (elapsed !== lastLogSec && elapsed % 3 === 0) {
            lastLogSec = elapsed;
            console.log("⏳ Allow wait: " + elapsed + "s / 20s");
            notify("⏳ Allow " + elapsed + "s / 20s...", "info");
        }

        const currentPage = detectPage();
        const stillAllow = allowButtonStillExists();

        if (currentPage !== "ALLOW" && !stillAllow) {
            notify("✅ Allow passed → " + currentPage, "success");
            console.log("✅ Allow passed after " + elapsed + "s");
            return true;
        }

        if (!stillAllow && currentPage === "UNKNOWN") {
            console.log("✅ Allow button gone — proceeding");
            notify("✅ Allow done", "success");
            return true;
        }
    }

    console.log("❌ Allow stuck after 20s → next ID");
    notify("❌ Allow stuck 20s — next ID", "error");
    return false;
}

// ==========================================
// ✅ AGREE RETRY
// ==========================================
async function tryClickAgreeOnce() {
    const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t === "i agree" && b.offsetParent !== null && !b.disabled) {
            await forceClickButton(b); return true;
        }
    }
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t.includes("agree") && t.length < 40 && b.offsetParent !== null && !b.disabled) {
            await forceClickButton(b); return true;
        }
    }
    return false;
}

function agreeButtonExists() {
    const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if ((t === "i agree" || t.includes("agree")) && t.length < 40 &&
            b.offsetParent !== null && !b.disabled) return true;
    }
    return false;
}

async function doAgreeWithRetry() {
    for (let i = 1; i <= 4; i++) {
        notify("✅ Agree try " + i + "/4");
        const clicked = await tryClickAgreeOnce();
        if (!clicked) { await delay(600); continue; }
        await delay(1500);
        if (!agreeButtonExists()) {
            notify("✅ Agree passed!", "success");
            return true;
        }
    }
    return false;
}

// ==========================================
// ⏭️ SKIP
// ==========================================
async function doSkipStep() {
    notify("⏭️ Skip phone...");
    const btns = document.querySelectorAll('button, div[role="button"], a[role="button"]');
    for (let b of btns) {
        const t = (b.innerText || "").trim().toLowerCase();
        if (t === "skip" && b.offsetParent !== null && !b.disabled) {
            await forceClickButton(b);
            await delay(600);
            return true;
        }
    }
    return false;
}

// ══════════════════════════════════════════════════════════
// ✅ FINISH ACCOUNT — Cookie save
// ══════════════════════════════════════════════════════════
async function finishAccount(username, password, email, fromHome) {
    console.log("🏁 finishAccount() for " + email);
    console.log("  👤 Username: " + username);

    const data = await chrome.storage.local.get(['accounts', 'currentIndex', 'successEmails', 'savedResults']);
    const idx = data.currentIndex || 0;
    const savedResults = data.savedResults || [];
    const successEmails = data.successEmails || [];

    notify("⏳ Wait 2s for cookies...");
    await delay(2000);

    let response = await getFullCookieFromBackground();
    if (!response || !response.hasSessionId) {
        notify("⏳ Retry cookie...");
        await delay(2500);
        response = await getFullCookieFromBackground();
    }

    let fullCookie = "";
    if (response && response.success) {
        fullCookie = response.fullCookie || "";
    } else {
        try { fullCookie = document.cookie || ""; } catch (e) {}
    }

    const resultEntry = {
        username: username || "?",
        password: password || "?",
        fullcookie: fullCookie || "?",
        email: email || "?",
        timestamp: Date.now()
    };

    const updatedResults = [...savedResults, resultEntry];
    const newSuccessList = [...successEmails, email];

    await chrome.storage.local.set({
        savedResults: updatedResults,
        successEmails: newSuccessList
    });

    await chrome.storage.local.set({ currentUsername: "" });

    const nextIdx = idx + 1;
    const d = await chrome.storage.local.get(['totalAccounts', 'accounts']);
    const total2 = d.totalAccounts || (d.accounts || []).length;
    await chrome.storage.local.set({ currentIndex: nextIdx });

    notify("✅ Saved: " + email + " (" + nextIdx + "/" + total2 + ")", "success");

    try { await jsClearAllStorage(); } catch (e) {}
    try { chrome.runtime.sendMessage({ action: "clearData" }, () => {}); } catch (e) {}
    await delay(2000);

    if (nextIdx >= total2) {
        await chrome.storage.local.set({ isRunning: false });
        notify("🎉 All " + total2 + " done!", "success");
        return;
    }

    notify("🔄 Next (" + (nextIdx + 1) + "/" + total2 + ")...");
    const newUrl = "https://www.instagram.com/accounts/login/?mtn&t=" + Date.now();
    try { window.location.replace(newUrl); }
    catch (e) { window.location.href = newUrl; }
}

// ══════════════════════════════════════════════════════════
// 🚀 MAIN FLOW
// ══════════════════════════════════════════════════════════
async function runAutomation() {
    console.log("🚀 runAutomation() START");

    const data = await chrome.storage.local.get(['accounts', 'currentIndex', 'isRunning']);
    if (!data.isRunning || !data.accounts || data.accounts.length === 0) {
        console.log("⏹️ Not running");
        return;
    }

    const idx = data.currentIndex || 0;
    const total = data.accounts.length;

    if (idx >= total) {
        chrome.storage.local.set({ isRunning: false });
        notify("🎉 All " + total + " done!", "success");
        return;
    }

    const parts = data.accounts[idx].split(':');
    const email = parts[0];
    const password = parts.slice(1).join(':');

    console.log("=== " + email + " (" + (idx + 1) + "/" + total + ") ===");

    createNotificationBar();
    startPopupWatcher();

    let finalUsername = "";

    const session = {
        loginAttempts: 0,
        hbxRefreshCount: 0,
        maxLoginAttempts: 3,
        maxHbxRefresh: 2
    };

    for (let loopGuard = 0; loopGuard < 25; loopGuard++) {
        const page = detectPage();
        console.log("🔁 Loop[" + loopGuard + "] page = " + page);
        notify("📍 " + page, "info");

        // ⭐ CANNOT_FIND popup — সরাসরি next ID
        if (page === "CANNOT_FIND") {
            notify("❌ Can't find account — next ID", "error");
            await failToNextId("account not found");
            return;
        }

        if (page === "LOGIN") {
            session.loginAttempts++;
            const result = await doLoginStep(email, password);

            // ✅ Success — এগিয়ে যাও
            if (result === "HBX" || result === "PROGRESSED" || result === "HOME") {
                await delay(400);
                continue;
            }

            // ❌ "Can't find account" / wrong password / timeout — সরাসরি NEXT ID
            if (result === "NO_ACCOUNT") {
                await failToNextId("account not found");
                return;
            }

            // অন্য fail — max attempts check
            if (session.loginAttempts >= session.maxLoginAttempts) {
                await failToNextId("Login failed " + session.loginAttempts + "x");
                return;
            }
            // Same ID retry শুধু unknown fail এ
            await refreshSameId("login retry");
            return;
        }

        if (page === "HBX_CARD" || page === "NO_ACCOUNT_FOUND") {
            notify("🎯 HBX Bhai page...");
            const clicked = await clickHbxCard();

            if (!clicked) {
                session.hbxRefreshCount++;
                if (session.hbxRefreshCount >= session.maxHbxRefresh) {
                    await failToNextId("hbx click failed");
                    return;
                }
                await refreshSameId("hbx click failed");
                return;
            }
            await delay(400);
            continue;
        }

        if (page === "FULLNAME") {
            const ok = await doFullNameStep();
            if (!ok) {
                await refreshSameId("fullname fail");
                return;
            }
            await delay(600);
            continue;
        }

        if (page === "USERNAME") {
            finalUsername = await doUsernameStep();
            await delay(600);
            continue;
        }

        if (page === "ALLOW") {
            const ok = await doAllowWithRetry();
            if (!ok) {
                await failToNextId("allow stuck");
                return;
            }
            await delay(400);
            continue;
        }

        if (page === "AGREE") {
            const ok = await doAgreeWithRetry();
            if (!ok) {
                await refreshSameId("agree fail");
                return;
            }
            await delay(400);
            continue;
        }

        if (page === "SKIP") {
            await doSkipStep();
            await delay(400);
            continue;
        }

        // ⭐ CONNECT_FB — Account created! Save cookie + next ID
        if (page === "CONNECT_FB") {
            notify("🎉 Account created! Saving cookie...", "success");
            console.log("🎉 CONNECT_FB page reached — account done");

            const s = await chrome.storage.local.get(['currentUsername']);
            const savedUsername = s.currentUsername || finalUsername || ("user_" + Date.now());
            console.log("🎉 Saving with username: " + savedUsername);

            await finishAccount(savedUsername, password, email, true);
            return;
        }

        if (page === "HOME") {
            notify("🏠 Home reached!", "success");
            const s = await chrome.storage.local.get(['currentUsername']);
            const savedUsername = s.currentUsername || finalUsername || ("user_" + Date.now());
            console.log("🏠 Using username: " + savedUsername);
            await finishAccount(savedUsername, password, email, true);
            return;
        }

        if (page === "UNKNOWN") {
            notify("⏳ Waiting...");
            await delay(1500);
            continue;
        }
    }

    await failToNextId("state machine loop exhausted");
}

// ==========================================
// START
// ==========================================
window.addEventListener('load', () => {
    setTimeout(runAutomation, 200);
});