let panel;
function post(m){window.postMessage({source:"DJ_SHAKIL",...m},"*")}
function makePanel(){
 if(panel)return;
 panel=document.createElement("div");panel.id="dj-shakil-panel";
 panel.innerHTML=`<div class="vd-head"><b>◉ DJ SHAKIL</b><span>MIC PRO MAX</span></div><button id="vd-on">MIC ON</button><div id="vd-sent" class="vd-sent">● AUDIO SENT: WAITING</div><div class="vd-info">Real-time browser audio processor</div>`;
 document.documentElement.appendChild(panel);
 panel.querySelector("#vd-on").onclick=()=>post({type:"VD_TOGGLE"});
}
chrome.runtime.onMessage.addListener(m=>{
 if(m.type==="VD_ENABLE")post(m);
 if(m.type==="VD_SET")post(m);
 if(m.type==="VD_TEST")post(m);
});
window.addEventListener("message",e=>{
 if(e.source===window&&e.data?.source==="DJ_SHAKIL"&&e.data.type==="VD_SENT_STATUS"){
   const status=String(e.data.status||"CALL TRACK STATUS UNKNOWN");
   const el=document.querySelector("#vd-sent");
   if(el){el.textContent="● "+status;el.classList.add("active")}
   chrome.storage.local.set({callOutputStatus:status,callOutputTime:Date.now()});
 }
});
makePanel();
chrome.storage.local.get({enabled:false,boost:48,drive:0,echo:0,delay:110,feedback:0,bass:0,presence:100,treble:0,reverb:0,echoFx:0,chorus:0,distortion:0,tremolo:0,compressor:50,flanger:0},c=>post({type:"VD_CONFIG",config:c}));
