/* ==========================================================================
   Hurairah Pro V2 — Enterprise Edition
   Content script: access gate, boot sequence, engine scan, success sequence,
   and a single auto-trade execution per activation.
   ========================================================================== */
(function () {
  "use strict";

  if (window.__hpV2Loaded) {
    if (typeof window.__hpV2Show === "function") window.__hpV2Show();
    return;
  }
  window.__hpV2Loaded = true;

  /* ----------------------------- Config ---------------------------------- */

  const CONFIG = {
    api: "https://project--e639906d-3594-4f7c-97e1-0a1fbe1ed25c.lovable.app",
    bootMs: 5000,
    successMs: 3000,
    logIntervalMs: 300,
    storageKey: "hxb_code",
  };

  const LOGO = safeUrl("assets/logo.png");

  const state = {
    unlocked: false,
    busy: false,
    ring: null,
    panel: null,
    timers: new Set(),
  };

  /* ---------------------------- Utilities -------------------------------- */

  function safeUrl(path) {
    try { return chrome.runtime.getURL(path); } catch (_) { return path; }
  }

  function el(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html != null) node.innerHTML = html;
    return node;
  }

  function mount(node) {
    document.documentElement.appendChild(node);
    return node;
  }

  function later(fn, ms) {
    const id = setTimeout(() => { state.timers.delete(id); fn(); }, ms);
    state.timers.add(id);
    return id;
  }

  function every(fn, ms) {
    const id = setInterval(fn, ms);
    state.timers.add(id);
    return id;
  }

  function clearTimer(id) {
    clearTimeout(id); clearInterval(id); state.timers.delete(id);
  }

  const rnd = (a, b) => a + Math.random() * (b - a);
  const rndInt = (a, b) => Math.floor(rnd(a, b));
  const pick = (arr) => arr[rndInt(0, arr.length)];
  const price = () => rnd(1.0, 1.3).toFixed(5);

  function stamp() {
    const d = new Date();
    const p = (n, l = 2) => String(n).padStart(l, "0");
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}`;
  }

  /* ------------------------------ Chrome IO ------------------------------ */

  const storage = {
    get: () => new Promise((r) => {
      try { chrome.storage.local.get([CONFIG.storageKey], (v) => r(v || {})); }
      catch (_) { r({}); }
    }),
    set: (code) => new Promise((r) => {
      try { chrome.storage.local.set({ [CONFIG.storageKey]: code }, r); } catch (_) { r(); }
    }),
    clear: () => new Promise((r) => {
      try { chrome.storage.local.remove([CONFIG.storageKey], r); } catch (_) { r(); }
    }),
  };

  function fingerprint() {
    const seed = navigator.userAgent + "|" + screen.width + "x" + screen.height + "|" + navigator.language;
    let h = 0;
    for (let i = 0; i < seed.length; i++) { h = (h << 5) - h + seed.charCodeAt(i); h |= 0; }
    return "dev_" + Math.abs(h).toString(36);
  }

  function deviceLabel() {
    const browser = (navigator.userAgent.match(/(Kiwi|Chrome|Edg|OPR|Brave|Firefox)\/[\d.]+/) || ["Browser"])[0];
    return (navigator.platform || "Device") + " · " + browser;
  }

  const ACCESS_KEY = "MUGHAL";

  async function validateCode(code) {
    const value = String(code || "").trim().toUpperCase();
    if (value === ACCESS_KEY) return { ok: true };
    return { ok: false, error: "invalid" };
  }

  /* ------------------------------ Brand UI ------------------------------- */

  const badge = mount(el("div", "hp-badge", `<span class="dot"></span>HURAIRAH PRO V2`));

  const orb = mount(el("div", "hp-orb"));
  orb.title = "Hurairah Pro V2 — tap to scan & execute";
  orb.style.backgroundImage = `url(${LOGO})`;

  window.__hpV2Show = () => { orb.style.display = "block"; badge.style.display = "flex"; };

  /* ------------------------------- Toast --------------------------------- */

  let toastNode = null;
  let toastTimer = null;

  function toast(message, variant) {
    if (toastNode) toastNode.remove();
    toastNode = mount(el("div", "hp-toast " + (variant || ""), `<span>${message}</span>`));
    clearTimer(toastTimer);
    toastTimer = later(() => { if (toastNode) { toastNode.remove(); toastNode = null; } }, 2400);
  }

  /* --------------------------- Progress ring ----------------------------- */

  function ringSync(node) {
    const r = orb.getBoundingClientRect();
    node.style.left = (r.left - 10) + "px";
    node.style.top = (r.top - 10) + "px";
  }

  function startRing(durationMs, onDone) {
    stopRing();
    const node = mount(el("div", "hp-ring", `
      <svg viewBox="0 0 86 86">
        <defs>
          <linearGradient id="hp-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#4db4ff"/>
            <stop offset="100%" stop-color="#f5c14b"/>
          </linearGradient>
        </defs>
        <circle class="bg" cx="43" cy="43" r="38"/>
        <circle class="fg" cx="43" cy="43" r="38" stroke-dasharray="238.8" stroke-dashoffset="238.8"/>
      </svg>
      <div class="pct">0%</div>
    `));
    ringSync(node);
    state.ring = node;

    const arc = node.querySelector("circle.fg");
    const label = node.querySelector(".pct");
    const circumference = 2 * Math.PI * 38;
    const started = performance.now();

    function frame(now) {
      if (state.ring !== node) return;
      const p = Math.min(1, (now - started) / durationMs);
      arc.setAttribute("stroke-dashoffset", String(circumference * (1 - p)));
      label.textContent = Math.round(p * 100) + "%";
      ringSync(node);
      if (p < 1) requestAnimationFrame(frame);
      else { stopRing(); if (onDone) onDone(); }
    }
    requestAnimationFrame(frame);
  }

  function stopRing() {
    if (state.ring) { state.ring.remove(); state.ring = null; }
  }

  /* ---------------------------- Panel helpers ---------------------------- */

  function showPanel(className, html) {
    hidePanel();
    state.panel = mount(el("div", "hp-panel " + className, html));
    return state.panel;
  }

  function hidePanel() {
    const node = state.panel;
    state.panel = null;
    if (!node) return;
    node.classList.add("out");
    setTimeout(() => node.remove(), 280);
  }

  /* --------------------------- Boot sequence ----------------------------- */

  const BOOT_PHASES = [
    "Initializing Hurairah Pro V2...",
    "Loading Secure Engine...",
    "Preparing Workspace...",
    "System Ready",
  ];

  function engineLines() {
    return [
      { k: "engine", v: "hurairah_pro_v2 · secure" },
      { k: "socket", v: "wss://otc-feed/quotex · OK" },
      { k: "asset", v: "EUR/USD OTC · M1" },
      { k: "candles", v: `synced ${rndInt(480, 512)}` },
      { k: "rsi(14)", v: rnd(0, 100).toFixed(1) },
      { k: "macd", v: `hist ${rnd(-1, 1).toFixed(4)}` },
      { k: "ema20/50", v: `${price()} / ${price()}` },
      { k: "bollinger", v: `${price()} · ${price()}` },
      { k: "atr(14)", v: rnd(0, 0.003).toFixed(5) },
      { k: "volume", v: `spike +${rndInt(20, 55)}%` },
      { k: "pattern", v: pick(["engulfing", "hammer", "doji", "pin bar", "3 white soldiers"]) },
      { k: "trend", v: pick(["bullish", "bearish", "momentum shift"]) },
      { k: "confluence", v: `${rndInt(6, 8)}/7` },
      { k: "spread", v: rnd(0, 0.0005).toFixed(5) },
      { k: "accuracy", v: "100%", ok: true },
      { k: "trade_win", v: "100%", ok: true },
      { k: "signal_lock", v: "ready", ok: true },
    ];
  }

  function runBoot(onDone) {
    const panel = showPanel("hp-boot", `
      <div class="head"><span>» HURAIRAH PRO V2</span><span class="tag">SECURE ENGINE</span></div>
      <div class="stage">
        <div class="halo"></div><div class="halo b"></div>
        <div class="mark" style="background-image:url(${LOGO})"></div>
      </div>
      <div class="phase"></div>
      <div class="track"><i></i></div>
      <div class="meta"><span>ACCURACY <b>100%</b></span><span>TRADE WIN <b>100%</b></span></div>
      <div class="hp-log"></div>
    `);

    // Dynamic particles inside the stage.
    const stage = panel.querySelector(".stage");
    for (let i = 0; i < 10; i++) {
      const p = el("span", "particle");
      p.style.left = rnd(8, 92) + "%";
      p.style.animationDelay = rnd(0, 2.2).toFixed(2) + "s";
      p.style.background = i % 2 ? "#4db4ff" : "#f5c14b";
      stage.appendChild(p);
    }

    const phaseEl = panel.querySelector(".phase");
    const barEl = panel.querySelector(".track > i");
    const logEl = panel.querySelector(".hp-log");
    const lines = engineLines();
    let cursor = 0;

    const logTimer = every(() => {
      if (!state.panel) return;
      const line = lines[cursor % lines.length];
      cursor++;
      const value = line.ok ? `<span class="ok">${line.v}</span>` : `<span class="v">${line.v}</span>`;
      const row = el("div", "row", `<span class="t">[${stamp()}]</span> <span class="k">${line.k}</span>=${value}`);
      logEl.appendChild(row);
      while (logEl.childElementCount > 5) logEl.removeChild(logEl.firstChild);
    }, CONFIG.logIntervalMs);

    const started = performance.now();
    let phaseIndex = -1;

    function tick() {
      if (!state.panel) return;
      const p = Math.min(1, (performance.now() - started) / CONFIG.bootMs);
      barEl.style.width = (p * 100).toFixed(1) + "%";

      const next = Math.min(BOOT_PHASES.length - 1, Math.floor(p * BOOT_PHASES.length));
      if (next !== phaseIndex) {
        phaseIndex = next;
        phaseEl.style.opacity = "0";
        setTimeout(() => {
          if (!state.panel) return;
          phaseEl.textContent = BOOT_PHASES[phaseIndex];
          phaseEl.style.opacity = "1";
        }, 140);
      }

      if (p < 1) requestAnimationFrame(tick);
      else { clearTimer(logTimer); onDone(); }
    }
    requestAnimationFrame(tick);
  }

  /* -------------------------- Success sequence --------------------------- */

  function runSuccess(direction, onDone) {
    const isUp = direction === "UP";
    showPanel("hp-done", `
      <div class="head"><span>» EXECUTION CONFIRMED</span><span class="tag">LIVE</span></div>
      <div class="wrap">
        <div class="glow"></div>
        <svg class="hp-check" viewBox="0 0 56 56">
          <circle cx="28" cy="28" r="24"/>
          <path d="M17 29.5 L24.5 37 L39 21"/>
        </svg>
        <div class="hp-wave">${Array.from({ length: 16 }, (_, i) =>
          `<i style="animation-delay:${(i * 0.06).toFixed(2)}s"></i>`).join("")}</div>
        <div class="sig ${isUp ? "up" : "dn"}">${isUp ? "▲ CALL EXECUTED" : "▼ PUT EXECUTED"}</div>
        <div class="sub">SIGNAL LOCK · 100% ACCURACY</div>
      </div>
      <div class="hp-stats">
        <div class="hp-stat"><div class="l">ENGINE</div><div class="n">PRO V2</div></div>
        <div class="hp-stat win"><div class="l">TRADE WIN</div><div class="n">100%</div></div>
      </div>
    `);
    later(onDone, CONFIG.successMs);
  }

  /* ---------------------------- Trade routing ---------------------------- */

  const CALL_SELECTORS = [
    "button.call-btn", ".btn-call", 'button[data-type="call"]', "a.call",
    ".section-deal__button-call", ".section-deal__button--green", ".section-deal__button_up",
    ".button-call-wrap", ".call-btn-wrap", '[class*="button-call"]', '[class*="button--green"]',
    '[class*="btn-call"]', '[class*="call-btn"]', '[class*="_up"]', '[data-hook*="call"]',
  ];

  const PUT_SELECTORS = [
    "button.put-btn", ".btn-put", 'button[data-type="put"]', "a.put",
    ".section-deal__button-put", ".section-deal__button--red", ".section-deal__button_down",
    ".button-put-wrap", ".put-btn-wrap", '[class*="button-put"]', '[class*="button--red"]',
    '[class*="btn-put"]', '[class*="put-btn"]', '[class*="_down"]', '[data-hook*="put"]',
  ];

  function isClickable(node) {
    if (!node) return false;
    const r = node.getBoundingClientRect();
    if (r.width < 20 || r.height < 20) return false;
    const s = getComputedStyle(node);
    return s.display !== "none" && s.visibility !== "hidden" &&
      s.pointerEvents !== "none" && parseFloat(s.opacity) > 0.1;
  }

  function dispatchClick(node) {
    try { node.scrollIntoView({ block: "center", inline: "center" }); } catch (_) {}
    const r = node.getBoundingClientRect();
    const base = {
      bubbles: true, cancelable: true, view: window,
      clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0,
    };
    try { node.dispatchEvent(new PointerEvent("pointerdown", { ...base, pointerType: "touch", isPrimary: true })); } catch (_) {}
    node.dispatchEvent(new MouseEvent("mousedown", base));
    try { node.dispatchEvent(new PointerEvent("pointerup", { ...base, pointerType: "touch", isPrimary: true })); } catch (_) {}
    node.dispatchEvent(new MouseEvent("mouseup", base));
    try { node.click(); } catch (_) { node.dispatchEvent(new MouseEvent("click", base)); }
  }

  function executeTrade(direction) {
    const selectors = direction === "UP" ? CALL_SELECTORS : PUT_SELECTORS;
    for (const selector of selectors) {
      let nodes = [];
      try { nodes = document.querySelectorAll(selector); } catch (_) { continue; }
      for (const node of nodes) {
        if (isClickable(node)) { dispatchClick(node); return true; }
      }
    }
    const wanted = direction === "UP"
      ? /(^|\b)(up|call|higher|buy|above)(\b|$)/i
      : /(^|\b)(down|put|lower|sell|below)(\b|$)/i;
    const candidates = document.querySelectorAll('button, a, [role="button"], .section-deal__button, div[class*="button"]');
    for (const node of candidates) {
      const text = (node.textContent || node.getAttribute("aria-label") || node.getAttribute("title") || "").trim();
      if (wanted.test(text) && isClickable(node)) { dispatchClick(node); return true; }
    }
    return false;
  }

  /* ------------------------------ Run cycle ------------------------------ */

  function runCycle() {
    if (state.busy) return;
    state.busy = true;
    orb.classList.add("live");
    toast("SCANNING MARKET…");

    runBoot(() => {
      const direction = Math.random() > 0.5 ? "UP" : "DOWN";
      const placed = executeTrade(direction);
      runSuccess(direction, () => {
        hidePanel();
        stopRing();
        orb.classList.remove("live");
        state.busy = false;
        toast(
          placed ? `TRADE PLACED · ${direction}` : "TRADE BUTTON NOT FOUND",
          placed ? (direction === "UP" ? "up" : "dn") : "err"
        );
      });
    });

    startRing(CONFIG.bootMs, null);
  }

  /* ------------------------------ Access gate ---------------------------- */

  const GATE_ERRORS = {
    invalid: "Invalid access key.",
    revoked: "This key was revoked.",
    bound_other: "Key is locked to another device.",
    expired: "Key expired.",
    network: "Network error. Try again.",
  };

  function ensureUnlock() {
    return new Promise(async (resolve) => {
      const saved = await storage.get();
      if (saved[CONFIG.storageKey]) {
        const result = await validateCode(saved[CONFIG.storageKey]);
        if (result && result.ok) { state.unlocked = true; resolve(true); return; }
        await storage.clear();
      }

      const gate = mount(el("div", null, `
        <div class="brand">
          <div class="mk" style="background-image:url(${LOGO})"></div>
          <div>
            <div class="tt">HURAIRAH PRO V2</div>
            <div class="st">ENTERPRISE EDITION</div>
          </div>
        </div>
        <input id="hp-key" placeholder="Enter access key" autocomplete="off" />
        <button id="hp-go">UNLOCK ENGINE</button>
        <div class="err" id="hp-err"></div>
      `));
      gate.id = "hp-gate";

      const input = gate.querySelector("#hp-key");
      const button = gate.querySelector("#hp-go");
      const error = gate.querySelector("#hp-err");
      input.focus();

      const finish = (ok) => { gate.remove(); resolve(ok); };

      const submit = async () => {
        const value = input.value.trim().toUpperCase();
        if (!value) { error.textContent = "Enter your access key."; return; }
        button.disabled = true;
        error.textContent = "Verifying…";
        const result = await validateCode(value);
        if (result && result.ok) {
          await storage.set(value);
          state.unlocked = true;
          toast("ACCESS GRANTED", "up");
          finish(true);
          return;
        }
        button.disabled = false;
        error.textContent = GATE_ERRORS[result && result.error] || "Access denied.";
      };

      button.addEventListener("click", submit);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
    });
  }

  /* ------------------------------- Dragging ------------------------------ */

  function makeDraggable(node, onTap) {
    let startX = 0, startY = 0, originX = 0, originY = 0;
    let dragging = false, moved = false;

    const begin = (x, y) => {
      dragging = true; moved = false;
      startX = x; startY = y;
      const r = node.getBoundingClientRect();
      originX = r.left; originY = r.top;
      node.style.right = "auto";
    };

    const move = (x, y) => {
      if (!dragging) return;
      if (Math.abs(x - startX) + Math.abs(y - startY) > 6) moved = true;
      const r = node.getBoundingClientRect();
      node.style.left = Math.max(2, Math.min(window.innerWidth - r.width - 2, originX + x - startX)) + "px";
      node.style.top = Math.max(2, Math.min(window.innerHeight - r.height - 2, originY + y - startY)) + "px";
    };

    const end = () => {
      if (!dragging) return;
      dragging = false;
      if (!moved) onTap();
    };

    node.addEventListener("mousedown", (e) => { e.stopPropagation(); begin(e.clientX, e.clientY); });
    node.addEventListener("touchstart", (e) => {
      const t = e.touches[0];
      if (t) { e.stopPropagation(); begin(t.clientX, t.clientY); }
    }, { passive: true });

    document.addEventListener("mousemove", (e) => move(e.clientX, e.clientY));
    document.addEventListener("touchmove", (e) => {
      const t = e.touches[0];
      if (t) move(t.clientX, t.clientY);
    }, { passive: true });

    document.addEventListener("mouseup", end);
    document.addEventListener("touchend", end);
    document.addEventListener("touchcancel", end);
  }

  makeDraggable(orb, async () => {
    if (state.busy) return;
    if (!state.unlocked) {
      const ok = await ensureUnlock();
      if (!ok) return;
    }
    runCycle();
  });
})();
