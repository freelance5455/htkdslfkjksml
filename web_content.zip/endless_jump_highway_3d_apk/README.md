# Endless Jump Highway 3D - Sunny Coast (Android APK Project)

This package contains both:
1. **`app/src/main/assets/index.html`**: A 100% offline, zero-dependency HTML5 game file (no external Tailwind CDN required) so it runs inside any Android WebView or HTML-to-APK converter without network or layout errors.
2. **Complete Android Studio Project**: Ready to compile into a native `.apk`.

## Option 1: Build APK in Android Studio
1. Extract this ZIP archive and open the folder in **Android Studio**.
2. Wait for Gradle Sync to finish.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your installable APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Option 2: Instant HTML-to-APK Converter (No Android Studio needed)
If you are using an app/tool like **WebIntoApp**, **Website 2 APK Builder**, or **HTML2APK**:
- Select `app/src/main/assets/index.html` (or the standalone `endless_jump_highway_3d.html` file) as your main HTML file.
- Because all CSS and Web Audio synthesizer logic are now 100% inline with zero external CDN scripts, the generated APK will launch and run offline without any errors.
