KARANLIK YANKI — Android için oyun başlangıç projesi
===================================================

Bu, Deltarune'dan ilham alan ama özgün karakter, dünya ve hikâyeye sahip
oynanabilir bir HTML5 RPG prototipidir.

Hemen denemek:
1. ZIP dosyasını çıkar.
2. www/index.html dosyasını Android telefonunda Chrome ile aç.
   (Dosya yöneticisinden açma desteklenmezse bir HTML görüntüleyici veya
   yerel web sunucusu uygulaması kullan.)
3. YENİ OYUN'a bas. Ekrandaki yön tuşlarıyla hareket et; Etkileşim'e bas.

Kontroller:
- Android: ekrandaki yön düğmeleri, Etkileşim ve savaş seçenekleri.
- Bilgisayar: ok tuşları veya WASD; Enter ile etkileşim.
- Savaş: Saldır, Konuş, İksir, Bağışla, Kaç.

İçerik:
- Keşif alanları, diyaloglar, seçimler, sıra tabanlı savaş ve iki farklı son.
- İksir, HP, yankı puanı ve dostluk sistemi.
- Basit yerel kayıt (tarayıcı localStorage).

Gerçek APK'ya dönüştürme:
Bu ZIP tek başına APK değildir. Android APK için Android Studio + WebView
kabı veya Capacitor projesi oluşturup www/index.html dosyasını içine eklemek
gerekir. Bu ilk sürüm oynanabilir bir prototiptir; tam ölçekli ticari oyun
değildir ve Deltarune'un özgün varlıklarını/kodunu içermez.
