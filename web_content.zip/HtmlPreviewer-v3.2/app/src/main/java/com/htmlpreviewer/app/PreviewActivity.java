package com.htmlpreviewer.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;

/** Full local preview workspace with viewport controls, console, sharing and project tools. */
public class PreviewActivity extends AppCompatActivity {
    public static final String EXTRA_ID = "id";
    private static final int MODE_FULL=0, MODE_MOBILE=1, MODE_TABLET=2;
    private WebView web; private FrameLayout stage, holder; private View consolePanel;
    private TextView consoleText; private ScrollView consoleScroll; private ProgressBar loadBar;
    private Project project; private LocalEngine engine; private int mode=MODE_FULL; private int consoleLines=0;
    private ValueCallback<Uri[]> filePathCallback;
    private final ActivityResultLauncher<Intent> fileChooser = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), r -> {
                if (filePathCallback != null) { filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData())); filePathCallback=null; }
            });

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_preview);
        project=ProjectStore.find(this,getIntent().getStringExtra(EXTRA_ID));
        if(project==null){Toast.makeText(this,"Project not found",Toast.LENGTH_SHORT).show();finish();return;}
        web=findViewById(R.id.web); stage=findViewById(R.id.stage); holder=findViewById(R.id.holder); consolePanel=findViewById(R.id.consolePanel);
        consoleText=findViewById(R.id.consoleText); consoleScroll=findViewById(R.id.consoleScroll); loadBar=findViewById(R.id.loadBar);
        ((TextView)findViewById(R.id.title)).setText(project.name);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        findViewById(R.id.btnBack).setContentDescription("Back"); findViewById(R.id.btnRefresh).setOnClickListener(v->reload());
        findViewById(R.id.btnDevice).setOnClickListener(this::showDeviceMenu); findViewById(R.id.btnConsole).setOnClickListener(v->toggleConsole());
        findViewById(R.id.btnMore).setOnClickListener(this::showToolsMenu); findViewById(R.id.btnCloseConsole).setOnClickListener(v->toggleConsole());
        findViewById(R.id.btnClear).setOnClickListener(v->clearConsole());
        EditText input=findViewById(R.id.consoleInput);
        Runnable run=()->{String code=input.getText().toString().trim();if(code.isEmpty())return;log(ConsoleMessage.MessageLevel.TIP,"› "+code);web.evaluateJavascript(code,res->log(ConsoleMessage.MessageLevel.LOG,"← "+res));input.setText("");};
        findViewById(R.id.btnRun).setOnClickListener(v->run.run()); input.setOnEditorActionListener((tv,a,e)->{run.run();return true;});
        stage.addOnLayoutChangeListener((v,l,t,r,bot,ol,ot,or,ob)->{if(mode!=MODE_FULL&&(r-l!=or-ol||bot-t!=ob-ot))applyMode();});
        engine=new LocalEngine(project.id,ProjectStore.projectDir(this,project.id),new File(project.entry),(level,msg)->runOnUiThread(()->log(level,msg)));
        setupWebView(); web.loadUrl(engine.entryUrl());
        getOnBackPressedDispatcher().addCallback(this,new OnBackPressedCallback(true){@Override public void handleOnBackPressed(){if(consolePanel.getVisibility()==View.VISIBLE)toggleConsole();else if(web.canGoBack())web.goBack();else finish();}});
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView(){
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(SettingsStore.javascript(this)); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setMediaPlaybackRequiresUserGesture(!SettingsStore.mediaWithoutGesture(this));
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); s.setCacheMode(WebSettings.LOAD_NO_CACHE); s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(SettingsStore.zoom(this)); s.setDisplayZoomControls(false); s.setSupportZoom(SettingsStore.zoom(this)); s.setLoadWithOverviewMode(true); s.setDefaultTextEncodingName("UTF-8"); WebView.setWebContentsDebuggingEnabled(true);
        web.setFocusable(true); web.setFocusableInTouchMode(true); web.requestFocus(View.FOCUS_DOWN);
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){return engine.intercept(req);}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){Uri u=req.getUrl();String h=u.getHost();if(h!=null&&h.equalsIgnoreCase("p"+project.id.toLowerCase()+LocalEngine.HOST_SUFFIX))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){log(ConsoleMessage.MessageLevel.WARNING,"Cannot open link: "+u);}return true;}
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError err){log(ConsoleMessage.MessageLevel.ERROR,"Failed to load "+req.getUrl()+" — "+err.getDescription());}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView v,int p){loadBar.setProgress(p);loadBar.setVisibility(p>=100?View.GONE:View.VISIBLE);}
            @Override public boolean onConsoleMessage(ConsoleMessage m){String src=m.sourceId()==null?"":m.sourceId();src=src.substring(src.lastIndexOf('/')+1);log(m.messageLevel(),m.message()+(src.isEmpty()?"":"  ("+src+":"+m.lineNumber()+")"));return true;}
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=cb;try{fileChooser.launch(params.createIntent());}catch(Exception e){filePathCallback=null;return false;}return true;}
            @Override public boolean onJsAlert(WebView v,String url,String msg,JsResult r){new AlertDialog.Builder(PreviewActivity.this).setMessage(msg).setPositiveButton("OK",(d,w)->r.confirm()).setOnCancelListener(d->r.cancel()).show();return true;}
            @Override public boolean onJsConfirm(WebView v,String url,String msg,JsResult r){new AlertDialog.Builder(PreviewActivity.this).setMessage(msg).setPositiveButton("OK",(d,w)->r.confirm()).setNegativeButton("Cancel",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}
        });
    }

    private void showDeviceMenu(View anchor){PopupMenu pm=new PopupMenu(this,anchor);pm.getMenu().add(0,MODE_FULL,0,"Responsive / Full width");pm.getMenu().add(0,MODE_MOBILE,1,"Mobile · 390 × 844");pm.getMenu().add(0,MODE_TABLET,2,"Tablet · 768 × 1024");pm.setOnMenuItemClickListener(i->{mode=i.getItemId();applyMode();return true;});pm.show();}
    private void applyMode(){
        if(mode==MODE_FULL){holder.getLayoutParams().width=ViewGroup.LayoutParams.MATCH_PARENT;holder.getLayoutParams().height=ViewGroup.LayoutParams.MATCH_PARENT;holder.setBackgroundColor(0xFFFFFFFF);}
        else {int d=(int)(getResources().getDisplayMetrics().density);int w=(mode==MODE_MOBILE?390:768)*d;int h=(mode==MODE_MOBILE?844:1024)*d;ViewGroup.LayoutParams lp=holder.getLayoutParams();lp.width=Math.min(w,stage.getWidth());lp.height=Math.min(h,stage.getHeight());holder.setLayoutParams(lp);holder.setBackgroundColor(0xFFFFFFFF);}
        holder.requestLayout();
    }

    private void showToolsMenu(View anchor){
        PopupMenu pm=new PopupMenu(this,anchor);
        pm.getMenu().add("Project info"); pm.getMenu().add("Share / export ZIP"); pm.getMenu().add("Clear WebView data"); pm.getMenu().add("Preview settings");
        pm.setOnMenuItemClickListener(item->{String x=item.getTitle().toString();if(x.equals("Project info"))showInfo();else if(x.equals("Share / export ZIP"))shareProject();else if(x.equals("Clear WebView data"))clearWebData();else showSettings();return true;});pm.show();
    }
    private void showInfo(){new AlertDialog.Builder(this).setTitle(project.name).setMessage("Type: "+project.type+"\nEntry: "+new File(project.entry).getName()+"\n\nLocal project storage: app-private\nNetwork permission: not required").setPositiveButton("OK",null).show();}

    private void shareProject(){
        try{
            File dir=ProjectStore.projectDir(this,project.id);File out=new File(getCacheDir(),project.id+"-"+project.name.replaceAll("[^A-Za-z0-9._-]","_")+".zip");
            ZipHelper.zipDirectory(dir,out);Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",out);
            Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/zip");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Share project ZIP"));
        }catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void reload(){clearConsole();web.clearCache(true);web.reload();}
    private void toggleConsole(){consolePanel.setVisibility(consolePanel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);}
    private void clearConsole(){consoleText.setText("");consoleLines=0;}
    private void log(ConsoleMessage.MessageLevel level,String msg){if(consoleLines>=500){consoleText.setText("");consoleLines=0;}String p=level==ConsoleMessage.MessageLevel.ERROR?"ERROR":level==ConsoleMessage.MessageLevel.WARNING?"WARN":level==ConsoleMessage.MessageLevel.LOG?"LOG":"INFO";consoleText.append("["+p+"] "+msg+"\n");consoleLines++;consoleScroll.post(()->consoleScroll.fullScroll(View.FOCUS_DOWN));}
}
