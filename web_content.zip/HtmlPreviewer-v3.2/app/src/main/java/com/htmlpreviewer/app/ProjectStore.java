package com.htmlpreviewer.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Recent-projects history persisted as JSON in SharedPreferences. */
public class ProjectStore {
    private static final String PREFS = "recent_projects";
    private static final String KEY = "list";
    private static final int MAX_RECENTS = 30;

    public static File projectDir(Context c, String id) {
        return new File(c.getFilesDir(), "projects/" + id);
    }

    public static List<Project> load(Context c) {
        List<Project> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Project p = new Project(o.getString("id"), o.getString("name"), o.getString("type"),
                        o.getString("entry"), o.getLong("time"));
                if (new File(p.entry).exists()) out.add(p); // skip projects whose files vanished
            }
        } catch (JSONException ignored) { }
        return out;
    }

    private static void save(Context c, List<Project> list) {
        JSONArray a = new JSONArray();
        try {
            for (Project p : list) {
                JSONObject o = new JSONObject();
                o.put("id", p.id); o.put("name", p.name); o.put("type", p.type);
                o.put("entry", p.entry); o.put("time", p.time);
                a.put(o);
            }
        } catch (JSONException ignored) { }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }

    /** Adds (or moves to top) a project. Oldest entries beyond the limit are deleted from disk. */
    public static void upsert(Context c, Project p) {
        List<Project> list = load(c);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).id.equals(p.id)) list.remove(i);
        list.add(0, p);
        while (list.size() > MAX_RECENTS) {
            Project old = list.remove(list.size() - 1);
            ZipHelper.deleteRecursive(projectDir(c, old.id));
        }
        save(c, list);
    }

    public static void delete(Context c, Project p) {
        List<Project> list = load(c);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).id.equals(p.id)) list.remove(i);
        save(c, list);
        ZipHelper.deleteRecursive(projectDir(c, p.id));
    }

    public static Project find(Context c, String id) {
        for (Project p : load(c)) if (p.id.equals(id)) return p;
        return null;
    }
}
