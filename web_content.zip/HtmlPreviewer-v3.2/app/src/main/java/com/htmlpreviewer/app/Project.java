package com.htmlpreviewer.app;

/** A saved project: a copied HTML file or an extracted ZIP, stored in app-private storage. */
public class Project {
    public final String id;
    public String name;
    public final String type;   // "HTML" or "ZIP"
    public final String entry;  // absolute path of the HTML file to load
    public long time;           // last opened (epoch ms)

    public Project(String id, String name, String type, String entry, long time) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.entry = entry;
        this.time = time;
    }
}
