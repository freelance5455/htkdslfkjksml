package com.htmlpreviewer.app;

import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Offline ZIP extraction/creation + entry-page detection. */
public class ZipHelper {
    private static final int BUF = 64 * 1024;
    private static final long MAX_EXTRACTED_BYTES = 256L * 1024L * 1024L;
    private static final int MAX_FILES = 10000;

    /** Extracts a ZIP stream into destDir. Protects against zip-slip and oversized archives. */
    public static void unzip(InputStream in, File destDir) throws IOException {
        if (!destDir.exists() && !destDir.mkdirs()) throw new IOException("Cannot create " + destDir);
        String rootPath = destDir.getCanonicalPath() + File.separator;
        byte[] buf = new byte[BUF];
        int count = 0;
        long total = 0;
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(in, BUF))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                if (++count > MAX_FILES) throw new IOException("ZIP contains too many files");
                String name = e.getName().replace('\\', '/');
                if (name.startsWith("__MACOSX/") || name.endsWith(".DS_Store")) continue;
                File out = new File(destDir, name);
                if (!out.getCanonicalPath().startsWith(rootPath)) {
                    throw new IOException("Blocked unsafe ZIP entry: " + name);
                }
                if (e.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("Cannot create directory");
                } else {
                    File parent = out.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Cannot create directory");
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), BUF)) {
                        int n;
                        while ((n = zis.read(buf)) > 0) {
                            total += n;
                            if (total > MAX_EXTRACTED_BYTES) throw new IOException("ZIP is larger than 256 MB after extraction");
                            os.write(buf, 0, n);
                        }
                    }
                }
                zis.closeEntry();
            }
        }
        if (count == 0) throw new IOException("The ZIP file is empty or invalid");
    }

    /** Creates a shareable ZIP of a project directory. */
    public static void zipDirectory(File source, File output) throws IOException {
        File parent = output.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Cannot create export directory");
        String base = source.getCanonicalPath();
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output), BUF))) {
            addDirectory(source, base, zos);
        }
    }

    private static void addDirectory(File file, String base, ZipOutputStream zos) throws IOException {
        if (file.isDirectory()) {
            File[] kids = file.listFiles();
            if (kids == null) return;
            for (File child : kids) addDirectory(child, base, zos);
            return;
        }
        String name = file.getCanonicalPath().substring(base.length()).replace(File.separatorChar, '/');
        if (name.isEmpty()) return;
        zos.putNextEntry(new ZipEntry(name));
        try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUF)) {
            byte[] buf = new byte[BUF];
            int n;
            while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        }
        zos.closeEntry();
    }

    public static File resolveEntry(File root) throws IOException {
        File best = findIndexHtml(root);
        if (best == null) return null;
        String n = best.getName().toLowerCase(Locale.ROOT);
        if (n.equals("index.html") || n.equals("index.htm")) return best;

        List<String> pages = new ArrayList<>();
        collectHtml(root, root, pages);
        if (pages.size() < 2) return best;
        Collections.sort(pages);
        StringBuilder sb = new StringBuilder(
            "<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
          + "<title>Project index</title><style>body{font-family:sans-serif;background:#121212;color:#eee;padding:20px}"
          + "a{display:block;background:#1E1E1E;color:#B39DFF;padding:14px;margin:8px 0;border-radius:12px;text-decoration:none}"
          + "</style></head><body><h2>Project pages</h2><p style='color:#999'>No index.html found — pick a page:</p>");
        for (String p : pages) {
            String esc = p.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
            sb.append("<a href=\"").append(Uri.encode(p, "/")).append("\">").append(esc).append("</a>");
        }
        sb.append("</body></html>");
        File idx = new File(root, "_project_index.html");
        try (OutputStream os = new FileOutputStream(idx)) { os.write(sb.toString().getBytes(StandardCharsets.UTF_8)); }
        return idx;
    }

    private static void collectHtml(File root, File dir, List<String> out) throws IOException {
        File[] files = dir.listFiles();
        if (files == null) return;
        String base = root.getCanonicalPath() + File.separator;
        for (File f : files) {
            if (f.isDirectory()) { collectHtml(root, f, out); continue; }
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (n.endsWith(".html") || n.endsWith(".htm"))
                out.add(f.getCanonicalPath().substring(base.length()).replace(File.separatorChar, '/'));
        }
    }

    public static File findIndexHtml(File root) {
        File bestIndex = null, bestAny = null;
        int bestIndexDepth = Integer.MAX_VALUE, bestAnyDepth = Integer.MAX_VALUE;
        ArrayDeque<Object[]> queue = new ArrayDeque<>();
        queue.add(new Object[]{root, 0});
        while (!queue.isEmpty()) {
            Object[] item = queue.poll();
            File dir = (File) item[0];
            int depth = (Integer) item[1];
            File[] files = dir.listFiles();
            if (files == null) continue;
            for (File f : files) {
                if (f.isDirectory()) { queue.add(new Object[]{f, depth + 1}); continue; }
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (n.equals("index.html") || n.equals("index.htm")) {
                    if (depth < bestIndexDepth) { bestIndex = f; bestIndexDepth = depth; }
                } else if (n.endsWith(".html") || n.endsWith(".htm")) {
                    if (depth < bestAnyDepth) { bestAny = f; bestAnyDepth = depth; }
                }
            }
        }
        return bestIndex != null ? bestIndex : bestAny;
    }

    public static void copy(InputStream in, File dest) throws IOException {
        File parent = dest.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Cannot create destination directory");
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(dest), BUF)) {
            byte[] buf = new byte[BUF];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
    }

    public static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
