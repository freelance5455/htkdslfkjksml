package com.htmlpreviewer.app;

import android.net.Uri;
import android.webkit.ConsoleMessage;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * v3.2 preview engine. Instead of file:// URLs, every project is served from a virtual
 * secure origin (https://p<id>.preview.local/) by intercepting WebView requests and streaming
 * files straight from disk. No sockets, no INTERNET permission, no libraries.
 *
 * Benefits: correct MIME types, ES modules, fetch()/XHR of local files, per-project
 * localStorage, audio/video seeking (HTTP Range), CORS-safe, and 404 reporting in the console.
 */
public class LocalEngine {
    public static final String HOST_SUFFIX = ".preview.local";

    public interface Logger { void log(ConsoleMessage.MessageLevel level, String message); }

    private static final Map<String, String> MIME = new HashMap<>();
    static {
        String[][] m = {
            {"html","text/html"},{"htm","text/html"},{"xhtml","application/xhtml+xml"},
            {"css","text/css"},{"js","text/javascript"},{"mjs","text/javascript"},
            {"json","application/json"},{"map","application/json"},{"webmanifest","application/manifest+json"},
            {"xml","application/xml"},{"txt","text/plain"},{"csv","text/csv"},{"md","text/markdown"},
            {"svg","image/svg+xml"},{"png","image/png"},{"jpg","image/jpeg"},{"jpeg","image/jpeg"},
            {"gif","image/gif"},{"webp","image/webp"},{"avif","image/avif"},{"ico","image/x-icon"},{"bmp","image/bmp"},
            {"woff","font/woff"},{"woff2","font/woff2"},{"ttf","font/ttf"},{"otf","font/otf"},{"eot","application/vnd.ms-fontobject"},
            {"mp3","audio/mpeg"},{"wav","audio/wav"},{"ogg","audio/ogg"},{"m4a","audio/mp4"},{"aac","audio/aac"},
            {"mp4","video/mp4"},{"webm","video/webm"},{"mov","video/quicktime"},
            {"wasm","application/wasm"},{"pdf","application/pdf"}
        };
        for (String[] e : m) MIME.put(e[0], e[1]);
    }

    private final String host;
    private final File projectDir, rootDir;
    private final File entry;
    private final Logger logger;

    public LocalEngine(String id, File projectDir, File entry, Logger logger) {
        this.host = "p" + id.toLowerCase(Locale.ROOT) + HOST_SUFFIX;
        this.projectDir = projectDir;
        this.entry = entry;
        this.rootDir = entry.getParentFile() != null ? entry.getParentFile() : projectDir; // site root
        this.logger = logger;
    }

    /** URL of the entry page, e.g. https://pa1b2c3d4.preview.local/index.html */
    public String entryUrl() {
        return "https://" + host + "/" + Uri.encode(entry.getName());
    }

    /** Returns a response for our virtual host, or null so WebView handles other URLs itself. */
    public WebResourceResponse intercept(WebResourceRequest req) {
        Uri u = req.getUrl();
        if (u.getHost() == null || !u.getHost().equalsIgnoreCase(host)) return null;
        String path = u.getPath() == null ? "/" : u.getPath();
        File f = resolve(path);
        if (f == null) {
            if (!path.equals("/favicon.ico")) logger.log(ConsoleMessage.MessageLevel.WARNING, "404 Not found: " + path);
            return plain(404, "Not Found", "Not found: " + path);
        }
        try {
            String mime = mimeOf(f.getName());
            String enc = (mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") || mime.contains("javascript"))
                    ? "utf-8" : null;
            long len = f.length(), start = 0, end = len - 1;
            boolean partial = false;

            String range = null;
            for (Map.Entry<String, String> h : req.getRequestHeaders().entrySet())
                if (h.getKey().equalsIgnoreCase("Range")) range = h.getValue();
            if (range != null && range.startsWith("bytes=") && len > 0) {
                try {
                    String[] p = range.substring(6).split("-", 2);
                    if (p[0].isEmpty()) start = Math.max(0, len - Long.parseLong(p[1]));
                    else {
                        start = Long.parseLong(p[0]);
                        if (p.length > 1 && !p[1].isEmpty()) end = Math.min(len - 1, Long.parseLong(p[1]));
                    }
                    partial = start <= end && start < len;
                } catch (NumberFormatException ignored) { partial = false; }
                if (!partial) { start = 0; end = len - 1; }
            }

            FileInputStream fis = new FileInputStream(f);
            long skipped = 0;
            while (skipped < start) {
                long s = fis.skip(start - skipped);
                if (s <= 0) break;
                skipped += s;
            }
            long count = end - start + 1;
            InputStream body = new Bounded(fis, Math.max(0, count));

            Map<String, String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            headers.put("Accept-Ranges", "bytes");
            headers.put("Cache-Control", "no-cache");
            headers.put("Content-Length", String.valueOf(count));
            if (partial) headers.put("Content-Range", "bytes " + start + "-" + end + "/" + len);

            return new WebResourceResponse(mime, enc, partial ? 206 : 200,
                    partial ? "Partial Content" : "OK", headers, body);
        } catch (IOException e) {
            logger.log(ConsoleMessage.MessageLevel.ERROR, "Read error: " + path + " — " + e.getMessage());
            return plain(500, "Error", "Read error");
        }
    }

    // ---- helpers ----
    private File resolve(String urlPath) {
        String rel = urlPath.startsWith("/") ? urlPath.substring(1) : urlPath;
        File f = tryFile(rootDir, rel);
        if (f == null && !projectDir.equals(rootDir)) f = tryFile(projectDir, rel); // fallback: ZIP top level
        return f;
    }

    private File tryFile(File base, String rel) {
        try {
            File f = new File(base, rel);
            String basePath = base.getCanonicalPath() + File.separator;
            File c = f.getCanonicalFile();
            if (!(c.getPath() + File.separator).startsWith(basePath)) return null; // block ../ escapes
            if (c.isDirectory()) {
                File idx = new File(c, "index.html");
                if (!idx.isFile()) idx = new File(c, "index.htm");
                return idx.isFile() ? idx : null;
            }
            return c.isFile() ? c : null;
        } catch (IOException e) { return null; }
    }

    private static String mimeOf(String name) {
        int i = name.lastIndexOf('.');
        String ext = i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
        String m = MIME.get(ext);
        if (m == null) m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m != null ? m : "application/octet-stream";
    }

    private static WebResourceResponse plain(int code, String reason, String msg) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "utf-8", code, reason, h,
                new ByteArrayInputStream(msg.getBytes()));
    }

    /** InputStream limited to N bytes (for Range responses). */
    private static class Bounded extends InputStream {
        private final InputStream in; private long left;
        Bounded(InputStream in, long n) { this.in = in; this.left = n; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read(); if (b >= 0) left--; return b;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }
        @Override public void close() throws IOException { in.close(); }
    }
}
