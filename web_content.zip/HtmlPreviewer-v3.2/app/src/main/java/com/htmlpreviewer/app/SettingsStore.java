package com.htmlpreviewer.app;

import android.content.Context;

/** Small persistent settings store for preview behavior. */
public final class SettingsStore {
    private static final String PREFS = "preview_settings";
    private SettingsStore() {}

    public static boolean javascript(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("javascript", true);
    }
    public static boolean mediaWithoutGesture(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("media", false);
    }
    public static boolean zoom(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("zoom", true);
    }
    public static void setJavascript(Context c, boolean v) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("javascript", v).apply();
    }
    public static void setMediaWithoutGesture(Context c, boolean v) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("media", v).apply();
    }
    public static void setZoom(Context c, boolean v) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("zoom", v).apply();
    }
}
