package com.htmlpreviewer.app;

import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Production dashboard: import, search, sort, rename, delete and launch local projects. */
public class MainActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ProjectAdapter adapter = new ProjectAdapter();
    private View progress, empty;
    private EditText search;
    private int sortMode = 0; // 0 recent, 1 name A-Z, 2 type

    private final ActivityResultLauncher<String[]> htmlPicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), uri -> { if (uri != null) importUri(uri, false); });
    private final ActivityResultLauncher<String[]> zipPicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), uri -> { if (uri != null) importUri(uri, true); });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progress = findViewById(R.id.progress);
        empty = findViewById(R.id.empty);
        search = findViewById(R.id.search);

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        findViewById(R.id.btnHtml).setOnClickListener(v -> htmlPicker.launch(new String[]{"text/html", "application/xhtml+xml", "application/octet-stream"}));
        findViewById(R.id.btnZip).setOnClickListener(v -> zipPicker.launch(new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"}));
        findViewById(R.id.btnDemo).setOnClickListener(v -> openDemo());
        findViewById(R.id.btnSort).setOnClickListener(this::showSortMenu);
        findViewById(R.id.btnAbout).setOnClickListener(v -> showAbout());
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { refresh(); }
            public void afterTextChanged(android.text.Editable e) {}
        });
    }

    private void openDemo() {
        try (InputStream in = getAssets().open("index.html")) {
            File dir = ProjectStore.projectDir(this, "demo");
            ZipHelper.deleteRecursive(dir);
            File f = new File(dir, "index.html");
            ZipHelper.copy(in, f);
            openProject(new Project("demo", "Built-in Demo", "HTML", f.getAbsolutePath(), System.currentTimeMillis()));
        } catch (IOException e) { Toast.makeText(this, "Demo unavailable: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onResume() { super.onResume(); refresh(); }
    @Override protected void onDestroy() { io.shutdownNow(); super.onDestroy(); }

    private void refresh() {
        List<Project> list = ProjectStore.load(this);
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase();
        if (!q.isEmpty()) {
            List<Project> filtered = new ArrayList<>();
            for (Project p : list) if (p.name.toLowerCase().contains(q) || p.type.toLowerCase().contains(q)) filtered.add(p);
            list = filtered;
        }
        if (sortMode == 1) Collections.sort(list, Comparator.comparing((Project p) -> p.name.toLowerCase()));
        else if (sortMode == 2) Collections.sort(list, Comparator.comparing((Project p) -> p.type));
        adapter.set(list);
        empty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        TextView count = findViewById(R.id.projectCount);
        count.setText(list.size() + (list.size() == 1 ? " project" : " projects"));
    }

    private void showSortMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 0, 0, "Recently opened");
        pm.getMenu().add(0, 1, 1, "Name A–Z");
        pm.getMenu().add(0, 2, 2, "Type");
        pm.setOnMenuItemClickListener(item -> { sortMode = item.getItemId(); refresh(); return true; });
        pm.show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("HTML Previewer Pro")
                .setMessage("Version 3.3 Pro\n\nOffline-first HTML/ZIP previewer with local project storage, device viewport controls, JavaScript console, file inputs, export/share, search and project management.\n\nNo account and no network permission are required for local projects.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void openProject(Project p) {
        p.time = System.currentTimeMillis();
        ProjectStore.upsert(this, p);
        startActivity(new Intent(this, PreviewActivity.class).putExtra(PreviewActivity.EXTRA_ID, p.id));
    }

    private void importUri(Uri uri, boolean zip) {
        progress.setVisibility(View.VISIBLE);
        io.execute(() -> {
            Project project = null; String error = null;
            try {
                String name = queryName(uri);
                if (name == null) name = zip ? "project.zip" : "page.html";
                String id = UUID.randomUUID().toString().replace("-", "").substring(0, 10);
                File dir = ProjectStore.projectDir(this, id);
                File entry;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("Cannot open the selected file");
                    if (zip) {
                        ZipHelper.unzip(in, dir);
                        entry = ZipHelper.resolveEntry(dir);
                        if (entry == null) { ZipHelper.deleteRecursive(dir); throw new IOException("No HTML file found inside the ZIP"); }
                    } else {
                        entry = new File(dir, "index.html");
                        ZipHelper.copy(in, entry);
                    }
                }
                project = new Project(id, stripExt(name), zip ? "ZIP" : "HTML", entry.getAbsolutePath(), System.currentTimeMillis());
                ProjectStore.upsert(this, project);
            } catch (Exception e) { error = e.getMessage() == null ? e.toString() : e.getMessage(); }
            Project fp = project; String fe = error;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                if (fp != null) { refresh(); openProject(fp); }
                else Toast.makeText(this, "Import failed: " + fe, Toast.LENGTH_LONG).show();
            });
        });
    }

    private String queryName(Uri uri) {
        ContentResolver cr = getContentResolver();
        try (Cursor c = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        String seg = uri.getLastPathSegment();
        return seg == null ? null : seg.substring(seg.lastIndexOf('/') + 1);
    }
    private static String stripExt(String n) { int i = n.lastIndexOf('.'); return i > 0 ? n.substring(0, i) : n; }

    private void rename(Project p) {
        EditText input = new EditText(this);
        input.setSingleLine(true); input.setText(p.name); input.setSelectAllOnFocus(true);
        int pad = (int)(20 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, 8, pad, 8);
        new AlertDialog.Builder(this).setTitle("Rename project").setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    String n = input.getText().toString().trim();
                    if (!n.isEmpty()) { p.name = n; ProjectStore.upsert(this, p); refresh(); }
                }).show();
    }

    private void confirmDelete(Project p) {
        new AlertDialog.Builder(this).setTitle("Delete project?")
                .setMessage("This removes the project copy from this app. Your original file is not deleted.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> { ProjectStore.delete(this, p); refresh(); }).show();
    }

    private class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.VH> {
        private List<Project> items = new ArrayList<>();
        private final DateFormat fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        void set(List<Project> l) { items = l; notifyDataSetChanged(); }
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_project, parent, false));
        }
        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            Project p = items.get(pos);
            h.name.setText(p.name); h.time.setText(fmt.format(new Date(p.time))); h.badge.setText(p.type);
            h.badge.setBackgroundResource(p.type.equals("ZIP") ? R.drawable.bg_badge_zip : R.drawable.bg_badge_html);
            h.itemView.setOnClickListener(v -> openProject(p));
            h.itemView.setOnLongClickListener(v -> { rename(p); return true; });
            h.delete.setOnClickListener(v -> confirmDelete(p));
            h.more.setOnClickListener(v -> {
                PopupMenu pm = new PopupMenu(MainActivity.this, h.more);
                pm.getMenu().add("Open"); pm.getMenu().add("Rename"); pm.getMenu().add("Delete");
                pm.setOnMenuItemClickListener(m -> { String x = m.getTitle().toString(); if (x.equals("Open")) openProject(p); else if (x.equals("Rename")) rename(p); else confirmDelete(p); return true; });
                pm.show();
            });
        }
        @Override public int getItemCount() { return items.size(); }
        class VH extends RecyclerView.ViewHolder {
            final TextView name, time, badge; final ImageButton delete, more;
            VH(View v) { super(v); name=v.findViewById(R.id.name); time=v.findViewById(R.id.time); badge=v.findViewById(R.id.badge); delete=v.findViewById(R.id.delete); more=v.findViewById(R.id.more); }
        }
    }
}
