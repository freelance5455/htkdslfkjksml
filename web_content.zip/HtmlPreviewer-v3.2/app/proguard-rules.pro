# HTML Previewer Pro intentionally keeps WebView bridge-free; no custom rules required.
