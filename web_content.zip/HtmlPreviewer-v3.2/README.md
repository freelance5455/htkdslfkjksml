# HTML Previewer Pro v3.4

Offline-first Android HTML/ZIP preview workspace.

## Production features
- Import standalone HTML or complete ZIP projects with the Android document picker.
- Safe ZIP extraction with path traversal and extraction-size protection.
- Virtual HTTPS project origin for relative assets, ES modules, fetch/XHR and localStorage.
- Responsive, mobile and tablet preview modes.
- JavaScript console with live JavaScript runner.
- HTML file input support.
- Project search, sorting, rename, delete and recent history.
- Share/export any imported project as a ZIP.
- Preview settings for JavaScript, media autoplay and zoom.
- External links open through the system browser.
- No INTERNET permission and no account required for local preview.

## Build
Open the `HtmlPreviewer-v3.2` directory in Android Studio with an Android SDK installed. Build the `release` variant to generate an unsigned release APK. Configure your own release keystore/signing config before publishing to Google Play.

## Package
Application ID: `com.htmlpreviewer.app`
Version: `3.3` / versionCode `33`
Minimum Android: 7.0 (API 24)
Target Android: API 34


## Interactive demo
The built-in demo buttons are real JavaScript actions. Each action updates a visible result area and writes to the native WebView console. The file picker reports the selected file name and size.
