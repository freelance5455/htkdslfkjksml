# SMART JONES SECURITY — Deployment & Airtel Money Tanzania Integration Guide

## 1. Architecture Overview
- **Android Client (`app/`)**: Kotlin + Jetpack Compose + Material 3, Firebase Auth (Google Sign-In via Credential Manager), Cloud Firestore (`ai-studio-android-smartjon-8b9ef853-c814-4da7-91b7-dee39d33a52d`), DataStore Preferences (Swahili/English localization), and Retrofit/Moshi payment client.
- **Database & Security (`firestore.rules`, `firebase-blueprint.json`)**: Zero-trust Firestore security rules isolating customer PII, locking provider verification badges to admin approval, enforcing the 10-stage order lifecycle, and protecting payment receipts.
- **Payment Webhook Server (`backend/server.js`)**: Express + Firebase Admin SDK service handling Airtel Money Tanzania OAuth2 USSD Push initiation and HMAC-verified payment callbacks to `0788016987`.

## 2. Missing External Credentials (Required for Live Airtel Money Transfers)
Currently, live **Airtel Money Tanzania OpenAPI** credentials are not present in the environment, so the app runs in a clearly labelled **SANDBOX VERIFICATION MODE** (no real money is transferred). To enable live Airtel Money collections to **0788016987**:
1. Register a merchant developer app on the **Airtel Africa Developer Portal** (`openapi.airtel.africa` / Tanzania `X-Country: TZ`, `X-Currency: TZS`).
2. Obtain:
   - `AIRTEL_CLIENT_ID`
   - `AIRTEL_CLIENT_SECRET`
   - `AIRTEL_WEBHOOK_SECRET`
   - `service-account.json` (Firebase Admin SDK credentials for project `gen-lang-client-0881241015`)
3. Deploy `/backend` to Cloud Run or a Node.js host with HTTPS, set the environment variables in `/backend/.env` (NEVER inside the Android app), and register your public `/api/payments/airtel/webhook` URL in Airtel's portal.
4. Set `PAYMENT_BACKEND_URL=https://<your-cloud-run-url>/` in AI Studio **Secrets** (mapped via `.env` / `BuildConfig.PAYMENT_BACKEND_URL`) and rebuild the APK.

## 3. Building a Release Signed APK
The project includes release signing configuration in `app/build.gradle.kts` using environment variables (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`) or debug signing via `debug.keystore`.
- Debug APK: `gradle :app:assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
- Release APK: `gradle :app:assembleRelease` -> `app/build/outputs/apk/release/app-release.apk`
