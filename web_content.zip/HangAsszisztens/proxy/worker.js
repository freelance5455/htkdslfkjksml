// Cloudflare Worker: az Anthropic API-kulcs itt marad, nem az appban.
// Titkok: wrangler secret put ANTHROPIC_API_KEY ; wrangler secret put APP_TOKEN
export default {
  async fetch(req, env) {
    if (req.method !== "POST" || req.headers.get("x-app-token") !== env.APP_TOKEN)
      return new Response("forbidden", { status: 403 });
    const body = await req.json();
    body.model = env.MODEL || "claude-sonnet-5-5";
    body.max_tokens = Math.min(body.max_tokens || 1024, 1500);
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify(body),
    });
    return new Response(r.body, { status: r.status, headers: { "content-type": "application/json" } });
  },
};
