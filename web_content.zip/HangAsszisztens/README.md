# Hangasszisztens – magyar AI hangasszisztens Androidra

Kotlin + Jetpack Compose. Hangvezérlés (hu-HU), névjegyek (telefon), Outlook email és naptár (Microsoft Graph), AI: Claude tool use proxy-n át.

## Beüzemelés (4 lépés)
1. **Proxy**: `proxy/worker.js` -> Cloudflare Worker. Titkok: `ANTHROPIC_API_KEY`, `APP_TOKEN`. Az URL-t és a tokent írd az `app/build.gradle.kts`-be (`PROXY_URL`, `APP_TOKEN`).
2. **Azure/Entra app**: portal.azure.com -> App registrations -> New. Fiókok: "személyes és munkahelyi". Platform: Android, csomagnév `hu.asszisztens.hang`, add meg az aláírás-hash-t (debug: `keytool -exportcert -alias androiddebugkey -keystore ~/.android/debug.keystore | openssl sha1 -binary | openssl base64`). Delegated jogosultságok: Mail.ReadWrite, Mail.Send, Calendars.ReadWrite.
3. **Cseréld le** a `SIGNATURE_HASH` (AndroidManifest.xml: URL-kódolva; res/raw/msal_config.json: nyersen) és `AZURE_CLIENT_ID` értékeket.
4. Nyisd meg Android Studióban (Giraffe vagy újabb), Sync, Run. Magyar hanghoz telepítsd a magyar nyelvcsomagot (Google beszédszolgáltatások).

## Szerkezet
`VoiceManager` hang · `AiClient` Claude-ciklus · `Tools` eszközök + megerősítés · `ContactsRepo` névjegyek · `Graph` email/naptár · `Auth` MSAL · `AssistantViewModel` + `MainActivity` UI.

Megjegyzés: a naptár az Outlook-naptár (Graph). A MSAL verzió (build.gradle.kts) frissíthető.
