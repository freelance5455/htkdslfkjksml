package hu.asszisztens.hang

import org.json.JSONArray
import org.json.JSONObject

/** Az AI által hívható eszközök. Írási műveletek előtt megerősítést kér. */
class Tools(private val contacts: ContactsRepo, private val graph: Graph) {
    val defs = JSONArray("""[
      {"name":"keres_nevjegy","description":"Névjegy keresése a telefon névjegyzékében név alapján (telefonszám, email).",
       "input_schema":{"type":"object","properties":{"nev":{"type":"string"}},"required":["nev"]}},
      {"name":"esemenyek_listazasa","description":"Az Outlook-naptár eseményei egy időszakban.",
       "input_schema":{"type":"object","properties":{"kezdet":{"type":"string","description":"ISO 8601, pl. 2026-10-16T00:00:00"},"veg":{"type":"string"}},"required":["kezdet","veg"]}},
      {"name":"esemeny_letrehozasa","description":"Új esemény felvétele az Outlook-naptárba (budapesti idő).",
       "input_schema":{"type":"object","properties":{"targy":{"type":"string"},"kezdet":{"type":"string"},"veg":{"type":"string"}},"required":["targy","kezdet","veg"]}},
      {"name":"levelek_olvasasa","description":"A legutóbbi bejövő levelek (feladó, tárgy, előnézet).",
       "input_schema":{"type":"object","properties":{"db":{"type":"integer"}}}},
      {"name":"level_kuldese","description":"Email küldése Outlookból.",
       "input_schema":{"type":"object","properties":{"cimzett":{"type":"string"},"targy":{"type":"string"},"szoveg":{"type":"string"}},"required":["cimzett","targy","szoveg"]}}
    ]""")

    suspend fun run(name: String, i: JSONObject, confirm: suspend (String) -> Boolean): String = when (name) {
        "keres_nevjegy" -> contacts.search(i.getString("nev"))
        "esemenyek_listazasa" -> graph.events(i.getString("kezdet"), i.getString("veg"))
        "levelek_olvasasa" -> graph.mails(i.optInt("db", 5))
        "esemeny_letrehozasa" ->
            if (confirm("Felvegyem a naptárba: ${i.getString("targy")}, ${i.getString("kezdet")}?"))
                graph.createEvent(i.getString("targy"), i.getString("kezdet"), i.getString("veg"))
            else "A felhasználó elutasította."
        "level_kuldese" ->
            if (confirm("Elküldjem a levelet ${i.getString("cimzett")} címre, tárgy: ${i.getString("targy")}?"))
                graph.sendMail(i.getString("cimzett"), i.getString("targy"), i.getString("szoveg"))
            else "A felhasználó elutasította."
        else -> "Ismeretlen eszköz."
    }
}
