package hu.asszisztens.hang

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: AssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        var text by remember { mutableStateOf("") }
        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (it[Manifest.permission.RECORD_AUDIO] == true) vm.voice.listen()
        }
        val list = androidx.compose.foundation.lazy.rememberLazyListState()
        LaunchedEffect(vm.msgs.size) { if (vm.msgs.isNotEmpty()) list.animateScrollToItem(vm.msgs.size - 1) }

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Hangasszisztens", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                if (!vm.signedIn) TextButton(onClick = { vm.auth.signIn(this@MainActivity) }) { Text("Belépés Microsofttal") }
                else Text("Outlook ✓", style = MaterialTheme.typography.labelLarge)
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.msgs.isEmpty()) item { Text("Nyomd meg a mikrofont, és mondd például: „Mi van ma a naptáramban?”") }
                items(vm.msgs) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        ) { Text(m.text, Modifier.padding(12.dp).widthIn(max = 300.dp)) }
                    }
                }
                if (vm.busy) item { Text("Gondolkodom…") }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Vagy írd be…") }, singleLine = true)
                IconButton(onClick = { vm.send(text); text = "" }) { Icon(Icons.Default.Send, "Küldés") }
                FilledIconButton(onClick = {
                    perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS))
                }) { Icon(Icons.Default.Mic, if (vm.listening) "Hallgatom" else "Beszéd") }
            }
            if (vm.listening) Text("Hallgatlak…", Modifier.padding(top = 4.dp))
        }

        vm.confirmText?.let { q ->
            AlertDialog(
                onDismissRequest = { vm.answer(false) },
                title = { Text("Megerősítés") }, text = { Text(q) },
                confirmButton = { TextButton({ vm.answer(true) }) { Text("Igen") } },
                dismissButton = { TextButton({ vm.answer(false) }) { Text("Nem") } },
            )
        }
    }
}
