package hu.asszisztens.hang

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Magyar hangfelismerés (hu-HU) és felolvasás. Főszálról használd. */
class VoiceManager(
    ctx: Context,
    private val onText: (String) -> Unit,
    private val onListening: (Boolean) -> Unit,
    private val onError: (String) -> Unit,
) {
    private val recognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
    private val tts = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hu", "HU") }

    init {
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) = onListening(true)
            override fun onEndOfSpeech() = onListening(false)
            override fun onError(e: Int) { onListening(false); onError("Nem értettem, próbáld újra. (kód: $e)") }
            override fun onResults(r: Bundle?) {
                onListening(false)
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
    }

    fun listen() {
        tts.stop()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hu-HU")
        }
        recognizer.startListening(i)
    }

    fun speak(text: String) { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "asszisztens") }

    fun destroy() { recognizer.destroy(); tts.shutdown() }
}
