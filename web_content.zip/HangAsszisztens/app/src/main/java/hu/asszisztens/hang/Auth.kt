package hu.asszisztens.hang

import android.app.Activity
import android.content.Context
import com.microsoft.identity.client.*
import com.microsoft.identity.client.exception.MsalException

/** Microsoft-bejelentkezés (MSAL). */
class Auth(ctx: Context, private val onSignedIn: (Boolean) -> Unit) {
    private var app: ISingleAccountPublicClientApplication? = null
    private val scopes = arrayOf("Mail.ReadWrite", "Mail.Send", "Calendars.ReadWrite")

    init {
        PublicClientApplication.createSingleAccountPublicClientApplication(
            ctx, R.raw.msal_config,
            object : IPublicClientApplication.ISingleAccountApplicationCreatedListener {
                override fun onCreated(a: ISingleAccountPublicClientApplication) {
                    app = a
                    onSignedIn(a.currentAccount?.currentAccount != null)
                }
                override fun onError(e: MsalException) { onSignedIn(false) }
            })
    }

    fun signIn(activity: Activity) {
        app?.signIn(activity, null, scopes, object : AuthenticationCallback {
            override fun onSuccess(r: IAuthenticationResult) = onSignedIn(true)
            override fun onError(e: MsalException) = onSignedIn(false)
            override fun onCancel() = onSignedIn(false)
        })
    }

    /** Háttérszálról hívd. */
    fun token(): String? = try {
        val a = app ?: return null
        a.acquireTokenSilent(scopes, a.currentAccount.currentAccount.authority).accessToken
    } catch (e: Exception) { null }
}
