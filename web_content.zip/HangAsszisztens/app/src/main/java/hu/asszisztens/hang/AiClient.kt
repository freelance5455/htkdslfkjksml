package hu.asszisztens.hang

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/** Beszélgetés a Claude-dal a proxyn át, tool use ciklussal. */
class AiClient(private val proxyUrl: String, private val appToken: String, private val tools: Tools) {
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val history = JSONArray()

    private fun system() = "Magyar nyelvű hangasszisztens vagy. Röviden, természetesen válaszolj, mert a válaszod fel lesz olvasva: " +
        "ne használj markdownt vagy felsorolásjeleket. Ma ${LocalDate.now()} van, az időzóna Europe/Budapest. " +
        "Névjegyet, naptárat és leveleket az eszközeiddel érsz el. Levelet küldeni és eseményt felvenni csak a felhasználó kérésére szabad."

    suspend fun ask(userText: String, confirm: suspend (String) -> Boolean): String = withContext(Dispatchers.IO) {
        history.put(JSONObject().put("role", "user").put("content", userText))
        repeat(6) {
            val resp = call()
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            if (resp.optString("stop_reason") != "tool_use") {
                return@withContext (0 until content.length()).map { content.getJSONObject(it) }
                    .filter { it.getString("type") == "text" }.joinToString(" ") { it.getString("text") }
            }
            val results = JSONArray()
            for (n in 0 until content.length()) {
                val b = content.getJSONObject(n)
                if (b.getString("type") != "tool_use") continue
                val out = try { tools.run(b.getString("name"), b.getJSONObject("input"), confirm) } catch (e: Exception) { "HIBA: ${e.message}" }
                results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
            }
            history.put(JSONObject().put("role", "user").put("content", results))
        }
        "Ezt most nem sikerült befejeznem."
    }

    private fun call(): JSONObject {
        val body = JSONObject().put("system", system()).put("tools", tools.defs)
            .put("messages", history).put("max_tokens", 1024)
        val req = Request.Builder().url(proxyUrl).header("x-app-token", appToken)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Szerverhiba (${r.code})")
            return JSONObject(s)
        }
    }
}
