package hu.asszisztens.hang

import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/** Outlook email és naptár a Microsoft Graph API-n át. */
class Graph(private val auth: Auth) {
    private val http = OkHttpClient()
    private val tz = "Europe/Budapest"

    private fun call(path: String, body: JSONObject? = null): String {
        val token = auth.token() ?: return "HIBA: nincs bejelentkezve Microsoft-fiókba."
        val b = Request.Builder().url("https://graph.microsoft.com/v1.0$path")
            .header("Authorization", "Bearer $token")
            .header("Prefer", "outlook.timezone=\"$tz\"")
        if (body != null) b.post(body.toString().toRequestBody("application/json".toMediaType()))
        http.newCall(b.build()).execute().use { r ->
            val s = r.body?.string().orEmpty()
            return if (r.isSuccessful) s.ifEmpty { "OK" } else "HIBA ${r.code}: ${s.take(200)}"
        }
    }

    fun events(start: String, end: String): String = call(
        "/me/calendarView?startDateTime=${Uri.encode(start)}&endDateTime=${Uri.encode(end)}" +
            "&\$select=subject,start,end,location&\$orderby=start/dateTime&\$top=20"
    )

    fun createEvent(subject: String, start: String, end: String): String = call(
        "/me/events", JSONObject()
            .put("subject", subject)
            .put("start", JSONObject().put("dateTime", start).put("timeZone", tz))
            .put("end", JSONObject().put("dateTime", end).put("timeZone", tz))
    )

    fun mails(count: Int): String = call(
        "/me/messages?\$top=${count.coerceIn(1, 10)}&\$select=subject,from,receivedDateTime,bodyPreview" +
            "&\$orderby=receivedDateTime%20desc"
    )

    fun sendMail(to: String, subject: String, text: String): String = call(
        "/me/sendMail", JSONObject().put("saveToSentItems", true).put("message", JSONObject()
            .put("subject", subject)
            .put("body", JSONObject().put("contentType", "Text").put("content", text))
            .put("toRecipients", org.json.JSONArray().put(
                JSONObject().put("emailAddress", JSONObject().put("address", to)))))
    )
}
