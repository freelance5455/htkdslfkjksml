package hu.asszisztens.hang

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import org.json.JSONArray
import org.json.JSONObject

/** A telefon névjegyzékében keres név alapján. */
class ContactsRepo(private val ctx: Context) {
    fun search(name: String): String {
        val out = JSONArray()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
            )?.use { c ->
                while (c.moveToNext() && out.length() < 10)
                    out.put(JSONObject().put("nev", c.getString(0)).put("telefon", c.getString(1)))
            }
            ctx.contentResolver.query(
                Email.CONTENT_URI, arrayOf(Email.DISPLAY_NAME, Email.ADDRESS),
                "${Email.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
            )?.use { c ->
                while (c.moveToNext() && out.length() < 15)
                    out.put(JSONObject().put("nev", c.getString(0)).put("email", c.getString(1)))
            }
        } catch (e: SecurityException) {
            return "HIBA: nincs engedély a névjegyek olvasásához."
        }
        return if (out.length() == 0) "Nincs találat." else out.toString()
    }
}
