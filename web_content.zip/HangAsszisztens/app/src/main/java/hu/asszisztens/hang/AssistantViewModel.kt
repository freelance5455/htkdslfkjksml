package hu.asszisztens.hang

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Msg(val fromUser: Boolean, val text: String)

class AssistantViewModel(app: Application) : AndroidViewModel(app) {
    val msgs = mutableStateListOf<Msg>()
    var listening by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var signedIn by mutableStateOf(false)
    var confirmText by mutableStateOf<String?>(null)
    private var pending: CompletableDeferred<Boolean>? = null

    val auth = Auth(app) { signedIn = it }
    private val ai = AiClient(BuildConfig.PROXY_URL, BuildConfig.APP_TOKEN,
        Tools(ContactsRepo(app), Graph(auth)))
    val voice = VoiceManager(app, { send(it) }, { listening = it }, { msgs += Msg(false, it) })

    fun send(text: String) {
        if (text.isBlank() || busy) return
        msgs += Msg(true, text); busy = true
        viewModelScope.launch {
            val answer = try { ai.ask(text) { q -> confirm(q) } } catch (e: Exception) { "Hiba: ${e.message}" }
            msgs += Msg(false, answer); busy = false
            voice.speak(answer)
        }
    }

    private suspend fun confirm(q: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        pending = d
        withContext(Dispatchers.Main) { confirmText = q; voice.speak(q) }
        val r = d.await()
        confirmText = null
        return r
    }

    fun answer(yes: Boolean) { pending?.complete(yes) }

    override fun onCleared() { voice.destroy() }
}
