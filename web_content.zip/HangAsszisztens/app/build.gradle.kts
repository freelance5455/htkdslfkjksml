plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "hu.asszisztens.hang"
    compileSdk = 35
    defaultConfig {
        applicationId = "hu.asszisztens.hang"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // ÁLLÍTSD BE: a proxy (proxy/worker.js) címe és a közös app-token
        buildConfigField("String", "PROXY_URL", "\"https://HANGASSZISZTENS.pelda.workers.dev\"")
        buildConfigField("String", "APP_TOKEN", "\"CSERELD-LE-EGY-HOSSZU-TITKOS-ERTEKRE\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.microsoft.identity.client:msal:5.4.0")
}
