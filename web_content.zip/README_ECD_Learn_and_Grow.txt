ECD LEARN & GROW — ANDROID QUICK GUIDE

1. Download ECD_Learn_and_Grow.html to your phone.
2. Open the phone's Files / File Manager app and locate the file in Downloads.
3. Tap it and choose Chrome or another browser if prompted. If the phone shows source code rather than the app, try opening it with another browser or test on a computer.
4. Use Learner Mode to generate an activity. Use Teacher Mode to save learner profiles and create tailored activities.
5. In Teacher Mode, use Export backup JSON to download the classroom records. This backup is separate from the HTML app.
6. Keep a copy of both files. Copy them to a flash drive with an OTG adapter when ready.

ABOUT THIS PROTOTYPE
- This is a functional offline HTML prototype with rule-based activity personalisation, not a live connected generative AI model.
- The six learning areas are Mathematics, English, Shona, Science and Technology, Social Science, and Physical Education and Arts.
- Activities are adapted for under-6 and 7–8 age groups, learning level, interests and support choices.
- Profiles and activities are stored in the browser's local storage on this device. Export a JSON backup before clearing browser data or moving to another device.
- To create an Android APK, the HTML file must be packaged using an Android wrapper/build service or Android development tool. The HTML file itself is not an APK.
- Protect children's privacy; use learner codes and avoid unnecessary sensitive information. Teachers must review activities for curriculum fit and safety.
