LIFEOS ULTIMATE - ZIP TO APK
============================
Use with the user's HTML to APK app:
ZIP to APK -> Choose ZIP File -> select this ZIP -> Preview -> Build APK.

Pages:
1. TODAY: today's total activity, person-wise lena/dena, recharge/bill expiry, total spend/received, today's tasks and schedule.
2. AI LIVE: local rule-based LifeOS AI that continuously analyses saved tasks, schedules, bills and money, then shows pending, missed, urgent and next-up items.
3. ADD: money, tasks, schedules, bills/recharges, people and memories, with daily/weekly/monthly recurring plans.
4. CALCULATOR: quick calculator.
5. BUDGET: professional budget chart based on income, saving target and spending categories.
6. MORE: universal search + backup/restore.

The AI is local/offline analysis, not a cloud AI service. It cannot automatically know external bank/UPI activity or phone notification events from plain HTML.
For truly automatic payment notification tracking, a native Android build with Notification Listener permission is required.
Never enter OTP, UPI PIN, bank password or other secrets.
