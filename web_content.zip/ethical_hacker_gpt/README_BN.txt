ETHICAL HACKER GPT — বাংলা সংস্করণ

ফোল্ডার:
- website/index.html : ব্রাউজারে চালানোর ওয়েবসাইট
- android_app/       : Android Studio project; WebView দিয়ে একই অফলাইন কনটেন্ট চালায়

ওয়েবসাইট চালানো:
1. website/index.html ফোন বা কম্পিউটারের ব্রাউজারে খুলুন।

Android অ্যাপ বানানো:
1. Android Studio-তে android_app ফোল্ডারটি Open করুন।
2. Gradle Sync শেষ হতে দিন।
3. Run চাপুন, অথবা Build > Build APK(s) নির্বাচন করুন।
4. APK তৈরি হলে Android Studio-র দেখানো output path থেকে নিন।

নোট:
- এখানে কোনো live website scanner, password cracker, exploit বা অননুমোদিত অ্যাক্সেস ফিচার নেই।
- অ্যাপটি ইন্টারনেট permission চায় না; কনটেন্ট অফলাইনে চলে।
- এটি Android Studio project/source, তৈরি করা APK নয়।
