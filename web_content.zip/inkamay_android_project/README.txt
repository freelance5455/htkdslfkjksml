CAMINOS DEL INKAMAY - proyecto Android inicial

Qué incluye
- Tu archivo HTML original copiado en app/src/main/assets/index.html
- Una Activity Android con WebView en pantalla completa y orientación horizontal
- Permiso de Internet para cargar Tailwind CSS y las fuentes web que el HTML referencia

IMPORTANTE
1. Este ZIP es el proyecto fuente; todavía NO es un APK ni un AAB firmado.
2. El HTML carga Tailwind CSS y Google Fonts desde Internet. Para que el diseño se vea exactamente igual, el teléfono necesita conexión. Si quieres que funcione completamente sin Internet, hay que incorporar esas dependencias localmente.
3. Antes de publicar, prueba el juego en varios tamaños de pantalla y revisa que los controles táctiles y el audio funcionen.
4. Para Google Play necesitarás una clave de firma propia, completar Play Console y cumplir los requisitos vigentes. No compartas tu clave privada.

Abrir en AndroidIDE
1. Extrae el ZIP en el almacenamiento del teléfono.
2. Abre AndroidIDE y abre/importa la carpeta CaminosDelInkamay.
3. Instala/configura el JDK y SDK que AndroidIDE solicite. Este proyecto usa Java 17, compileSdk 36 y Android Gradle Plugin 8.9.1; si tu entorno no admite esas versiones, ajusta las versiones compatibles con la versión instalada.
4. Sincroniza Gradle y compila primero una versión de depuración para probarla.
5. Para publicar, crea una compilación de release firmada como Android App Bundle (.aab) desde las opciones de compilación/firma de tu IDE.

Si AndroidIDE no puede resolver Gradle o descargar el SDK, usa una herramienta de compilación Android compatible con esas versiones; no es un problema del archivo HTML en sí.
