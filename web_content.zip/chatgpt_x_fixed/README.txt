CHATGPT X — WEB-SEARCH-ENABLED APKFORGE STARTER

Includes:
- Chat interface with local chat history.
- OpenAI Responses API text answers with the web_search tool.
- Gemini text answers with Google Search grounding.
- OpenAI image generation and Gemini image generation (if the selected model/account has access).
- A separate Google button to open a Google Search page.
- No ad UI and no subscription screen in this starter.

SETUP
1. Upload this ZIP to APKForge and rebuild the APK. This is source code, NOT a ready-built APK.
2. Open the rebuilt app, tap Settings, choose OpenAI or Google Gemini, enter your API key, and save.
3. Ask a question. The app requests web search/grounding from the selected provider when supported.
4. To generate an image, type an image description and tap Generate image.

IMPORTANT LIMITS
- No AI app can guarantee it can answer absolutely every question or always answer instantly. Response speed depends on network, provider, model, and search/image generation time.
- OpenAI API usage is billed separately from a ChatGPT app subscription. Gemini API limits/pricing depend on your account and model.
- Web search grounding/tool access depends on model/API support, account, region, and quota. The separate Google button opens Google Search in a browser.
- This demo stores the API key in local app/browser storage, which is not secure for a public app. Do not distribute an APK containing your personal key. A production app should use a secure backend to protect API keys.
- If APKForge's WebView blocks network requests, enable Internet/network access in its app settings.
- This is an independent app, not the official ChatGPT app. It does not use your ChatGPT login automatically.
