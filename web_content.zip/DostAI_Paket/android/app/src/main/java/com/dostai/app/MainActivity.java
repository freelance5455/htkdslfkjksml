package com.dostai.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 4310;
    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private String pendingLanguage = "az-AZ";
    private boolean wantsListenAfterPermission = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,18,26));
        getWindow().setNavigationBarColor(Color.rgb(16,18,26));
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16,18,26));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean audioRequested = false;
                    for (String resource : request.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) audioRequested = true;
                    if (audioRequested && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    else request.deny();
                });
            }
        });
        webView.addJavascriptInterface(new NativeSpeechBridge(), "AndroidSpeech");
        setContentView(webView);
        textToSpeech = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) textToSpeech.setSpeechRate(1.0f);
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startNativeRecognition(String languageTag) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            notifyJsError("Bu cihazda nitq tanıma xidməti mövcud deyil.");
            return;
        }
        try {
            if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int error) { notifyJsError("Səs tanınmadı. Yenidən cəhd et."); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String transcript = matches != null && !matches.isEmpty() ? matches.get(0) : "";
                    webView.post(() -> webView.evaluateJavascript("window.onNativeSpeechResult && window.onNativeSpeechResult(" + JSONObject.quote(transcript) + ")", null));
                }
                @Override public void onPartialResults(Bundle partialResults) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            speechRecognizer.startListening(intent);
        } catch (Exception e) { notifyJsError("Mikrofonu başlatmaq mümkün olmadı."); }
    }

    private void notifyJsError(String message) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript("window.onNativeSpeechError && window.onNativeSpeechError(" + JSONObject.quote(message) + ")", null));
    }

    private class NativeSpeechBridge {
        @JavascriptInterface public void startListening(String languageTag) {
            pendingLanguage = (languageTag == null || languageTag.trim().isEmpty()) ? "az-AZ" : languageTag;
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    wantsListenAfterPermission = true;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                    return;
                }
                startNativeRecognition(pendingLanguage);
            });
        }
        @JavascriptInterface public void speak(String text, String languageTag) {
            if (text == null || text.trim().isEmpty()) return;
            String safeLang = (languageTag == null || languageTag.trim().isEmpty()) ? "az-AZ" : languageTag;
            runOnUiThread(() -> {
                if (!ttsReady || textToSpeech == null) { notifyJsError("Telefonun mətn-səs xidməti hazır deyil."); return; }
                try {
                    Locale locale = Locale.forLanguageTag(safeLang);
                    int languageResult = textToSpeech.setLanguage(locale);
                    if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        notifyJsError("Bu dil üçün telefonda səs paketi yoxdur."); return;
                    }
                    if (Build.VERSION.SDK_INT >= 21) textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dostai-tts");
                    else textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                } catch (Exception e) { notifyJsError("Səsləndirmək mümkün olmadı."); }
            });
        }
        @JavascriptInterface public void stopSpeaking() { runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); }); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            wantsListenAfterPermission = false;
            if (granted) startNativeRecognition(pendingLanguage);
            else notifyJsError("Səsli yazı üçün mikrofona icazə lazımdır.");
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("document.getElementById('sidebar')?.classList.remove('open')", null);
            webView.evaluateJavascript("if(document.querySelector('.page-video.active')){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById('page-chat').classList.add('active');document.getElementById('currentTitle').textContent='AI ilə söhbət';}", null);
        }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); speechRecognizer = null; }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        if (webView != null) { webView.removeJavascriptInterface("AndroidSpeech"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
