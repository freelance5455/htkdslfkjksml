# DostAI — mobil AI köməkçisi

DostAI Azərbaycan dili, türk dili, ingilis dili, rus dili, ərəb dili və fars dili üçün hazırlanmış mobil interfeys nümunəsidir. Paketdə mobil veb tətbiqi, Android Studio mənbə layihəsi və ayrıca API serveri var.

## Vacib qeyd

Bu ZIP-in içində **hazır, imzalanmış APK faylı yoxdur**. Mövcud mühitdə Android SDK/Gradle olmadığı üçün APK-ni burada tərtib etmək mümkün olmadı. `android/` qovluğunda Android tətbiqinin mənbə layihəsi var; onu Android Studio olan kompüterdə APK-yə çevirmək olar. Telefonla quraşdırma üçün APK tərtib edilməlidir. Bu paket hazır APK kimi təqdim edilmir.

Tətbiqin interfeysi və nümayiş rejimi API açarı olmadan da açılır. Həqiqi AI cavabları və real video yaratmaq üçün internetə çıxışı olan server, uyğun provayder hesabı və API açarı lazımdır. Video generasiyası ödənişli ola bilər; provayderin hesabındakı limitləri əvvəlcədən yoxla.

## ZIP-in içindəkilər

- `web/` — mobil tətbiq, altı dil, AI söhbəti, səsli daxiletmə/cavabı səsləndirmə, şəkil yaratma, video yaratma interfeysi və PWA faylları.
- `server/` — Gemini API ilə söhbət, Nano Banana şəkil generasiyası və Veo video generasiyası üçün Node.js backend.
- `android/` — WebView əsaslı Android mənbə layihəsi; mikrofonla nitq tanıma və Android-in mətn-səs xidməti ilə bağlantı.

## Real AI funksiyalarını qoşmaq

1. Kompüterdə Node.js 20 və ya daha yeni versiya qurulmalıdır.
2. `server` qovluğuna daxil ol və `.env.example` faylının surətini `.env` adı ilə yarat.
3. Google AI Studio-dan öz Gemini API açarını al: https://aistudio.google.com/app/apikey
4. `.env` faylında `GEMINI_API_KEY` sətrinə açarını daxil et. Söhbət modeli `GEMINI_CHAT_MODEL=gemini-3.8-flash`, şəkil modeli `GEMINI_IMAGE_MODEL=gemini-3.1-flash-image`, video modeli `GEMINI_VIDEO_MODEL=veo-3.1-generate-preview` kimi saxlanır; hesabın bu modellərə girişini yoxla. Bu açarı heç vaxt tətbiqin HTML/JavaScript fayllarına, APK-yə və ya ictimai repozitoriyaya yazma.
5. `DOSTAI_ACCESS_TOKEN` üçün uzun, özünə məxsus gizli kod yarat. Eyni kodu sonra tətbiqin **Ayarlar** səhifəsinə daxil et. Əgər server ictimai internetə açıq olacaqsa, bu kodu dəyişmək və serveri girişlə qorumaq vacibdir.
6. `CORS_ORIGINS` dəyərini istifadə edəcəyin sayt domeninə uyğunlaşdır. Android-in paketlənmiş lokal interfeysi üçün `null` dəyəri saxlanmalıdır. Məsələn: `CORS_ORIGINS=null,https://sənin-domenin.example`.
7. Terminalda `npm install`, sonra `npm start` əmrlərini icra et. Server standart olaraq 3000 portunda başlayır.
8. Brauzerdə `http://localhost:3000` açaraq interfeysi sına. Tətbiqin Ayarlar bölməsində server URL-ni daxil et (məsələn, eyni cihazdakı brauzer üçün `http://localhost:3000`), şəxsi qoşulma kodunu yaz və **Bağlantını yoxla** düyməsinə bas.

Telefonun özündə işlətmək üçün API serverinə telefonun çata bildiyi HTTPS ünvanı verilməlidir. Android tətbiqi təhlükəsizlik üçün adi HTTP bağlantılarını bloklayır; tətbiqin **Ayarlar** səhifəsində HTTPS ünvanını yaz. Təkcə `.env` yaratmaq və ya ZIP-i açmaq buludda server yaratmır.

## Android APK hazırlamaq

Bu addım üçün Windows/macOS/Linux kompüteri, Android Studio, Android SDK Platform 35 və internet lazımdır.

1. ZIP-i kompüterdə aç.
2. Android Studio-da **Open** seçərək içindəki `android` qovluğunu aç.
3. Gradle sinxronlaşdırmasını tamamla. Layihədə Gradle Wrapper daxil edilməyib; Android Studio/Gradle qurulumuna uyğun olaraq Wrapper yaratmaq və ya lokal Gradle ilə layihəni açmaq lazım gələ bilər.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. Android Studio `app-debug.apk` yaratdıqda onu telefona köçür, Android-də həmin fayl üçün quraşdırmaya icazə ver və quraşdır.

APK yaradılmadan bu ZIP-i birbaşa Android tətbiqi kimi quraşdırmaq mümkün deyil. Kompüterin yoxdursa, `web/` qovluğunu HTTPS hostinqə yerləşdirib Chrome-dan **Ana ekrana əlavə et** ilə PWA kimi istifadə etmək olar; bu, APK ilə eyni şey deyil.

## Şəkil və səsli funksiya

Şəkil yaratma üçün `/api/image` endpoint-i `gemini-3.1-flash-image` modelini çağırır. Model/API girişi, kvota və billing olmadan şəkil yarana bilməz. Səs düyməsi nitqi tanıyıb sorğunu göndərir və cavabı telefonun TTS xidməti ilə səsləndirməyə çalışır; Azərbaycan dili üçün cihazda uyğun nitq xidməti olmalıdır.

## Səsli funksiya

Android mənbə layihəsində səs tanıma Android-in cihaz xidmətlərindən, cavabların səsləndirilməsi isə telefonun Text-to-Speech xidmətindən istifadə edir. Azərbaycan, türk, ingilis, rus, ərəb və fars dillərinin səs paketi telefonda quraşdırılmayıbsa, həmin dildə tanıma və ya səsləndirmə işləməyə bilər. Bu, telefonun dil paketlərindən və istehsalçısından asılıdır.

## Təhlükəsizlik

- API açarını yalnız serverin `.env` faylında saxla.
- `.env` faylını başqaları ilə bölüşmə.
- Serveri internetə çıxarırsansa, öz `DOSTAI_ACCESS_TOKEN` kodunu qur, domeni `CORS_ORIGINS`-ə əlavə et və server loglarını/kvotanı izlə.
- AI cavabları və yaradılan videoların keyfiyyəti, sürəti və əlçatanlığı seçilmiş provayder, hesab, limitlər və internetdən asılıdır. Heç bir proqram üçün “qüsursuz” nəticəyə zəmanət yoxdur.
