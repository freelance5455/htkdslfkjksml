# DostAI 1.1 — xəta düzəltmə təlimatı (Azərbaycan dili)

## Niyə əvvəlki APK-də heç nə işləmirdi?
APK daxilində interfeys var, amma API serveri avtomatik yaranmır. Server ünvanı yazılmayıbsa söhbətə, şəkil və videoya real AI cavabı gəlməyəcək. Həmçinin Google Gemini API açarı və uyğun model/kvota lazımdır.

## Vacib: yalnız APK-ni yenidən quraşdırmaq kifayət deyil
1. Bu ZIP-i kompüterdə aç.
2. `server/.env.example` faylını `.env` adı ilə kopyala.
3. Google AI Studio-da API açarı yarat: https://aistudio.google.com/app/apikey
4. Açarı `.env` faylındakı `GEMINI_API_KEY=` sətrinə yaz. Açarı APK-yə və ya HTML/JS-ə yazma.
5. `DOSTAI_ACCESS_TOKEN` üçün öz gizli kodunu təyin et; həmin kodu sonradan tətbiqin Ayarlar bölməsinə yaz.
6. Serveri HTTPS ünvanı olan hostingdə işə sal. Kompüterdə Node.js 20+ ilə `npm install` və `npm start` işlətmək olar, amma telefon internetdən serverə çatması üçün onu ictimai HTTPS hostinqə yerləşdirmək lazımdır.
7. Yeni APK-ni Android Studio-da `android/` qovluğundan tərtib et: Build → Build APK(s). Köhnə APK-ni silib yeni APK-ni quraşdır.
8. Tətbiqdə Ayarlar → Server ünvanı bölməsinə serverin HTTPS URL-sini (sonunda `/api` olmadan) daxil et. Qoşulma kodunu da yaz, Yadda saxla və Bağlantını yoxla seç.
9. Bağlantı testi serverin işlədiyini və API açarının mövcudluğunu göstərməlidir. Model girişi və kvota ayrıca yoxlanır.

## Bölmələr
- Söhbət: `POST /api/chat`
- Şəkil: `POST /api/image` (Gemini image model)
- Video: `POST /api/video/start`, status və fayl endpoint-ləri (Veo)
- Səs: Android SpeechRecognizer + TextToSpeech. Mikrofona icazə ver; telefonda uyğun dil paketi yoxdursa Azərbaycan dilində nitq tanıma/səsləndirmə işləməyə bilər.

## Hələ də xəta varsa
Ayarlar səhifəsində “Bağlantını yoxla” nəticəsinin tam mətnini və ya ekrandakı xəta mesajının şəklini göndər. API açarını və qoşulma kodunu heç kimə göndərmə.
