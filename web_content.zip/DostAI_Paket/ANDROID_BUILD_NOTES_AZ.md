# DostAI Android 1.1 — quraşdırma

Bu paket APK deyil, Android Studio layihə mənbəyidir. APK-ni tərtib etmək üçün kompüterdə Android Studio, Android SDK Platform 35 və uyğun Gradle qurulumu lazımdır. Android Studio-da `android/` qovluğunu aç, Gradle sync tamamla, sonra Build > Build APK(s) seç.

Tətbiqə canlı AI qoşmaq üçün əvvəlcə `server/` qovluğunu Node.js 20+ mühitində HTTPS ünvanla yerləşdir. `server/.env.example` faylını `.env` et, Gemini API açarını yalnız serverdə saxla, `npm install` və `npm start` işlət. Sonra APK-də Ayarlar bölməsinə serverin HTTPS URL-ni və `DOSTAI_ACCESS_TOKEN` qurmusansa eyni kodu yaz; Yadda saxla və Bağlantını yoxla.

Vacib: API açarı olmadan AI cavabı/şəkil/video yaranmayacaq. Video generasiyası provayder hesabının model icazəsi və kvotasından asılıdır. Səs tanıma və TTS cihazdakı dil paketlərindən asılıdır.
