# Android layihəsi barədə

`android/` Android Studio üçün WebView tətbiqi mənbəyidir. `MainActivity.java` mikrofon icazəsi, nitq tanıma və telefonun Text-to-Speech xidmətini idarə edir. Tətbiqin interfeysi `app/src/main/assets/` qovluğundadır.

**Bu qovluq hazır APK deyil.** Android SDK və Gradle quraşdırılmış kompüterdə layihəni sinxronlaşdırıb `Build > Build APK(s)` əmri ilə APK yaratmaq lazımdır.

APK yaradıldıqdan sonra AI funksiyalarını işlətmək üçün Ayarlara HTTPS backend ünvanını və serverdə təyin etdiyin qoşulma kodunu daxil et. API açarını APK-yə əlavə etmə.
