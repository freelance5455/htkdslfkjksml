/*
 * room-client.js
 *
 * Gives the game its multiplayer "room" using this project's own server
 * (WebSocket at /ws). The game calls:
 *
 *     const room = await window.claude.use('room');
 *     const match = await room.join('vc-ab12');
 *
 * If a built-in window.claude already exists (for example when the page is
 * hosted inside Claude), this file does nothing and the built-in one is used.
 */
(function (root) {
  'use strict';

  if (root.claude && typeof root.claude.use === 'function') return;
  if (typeof root.WebSocket !== 'function') return; // game falls back to single player

  var loc = root.location;
  var WS_URL = (loc.protocol === 'https:' ? 'wss://' : 'ws://') + loc.host + '/ws';
  var PRESENCE_MAX_BYTES = 4096;
  var EMIT_MAX_BYTES = 4096;
  var NAME_RE = /^[a-z][a-z0-9_.-]{0,47}$/;
  var JOIN_TIMEOUT_MS = 10000;

  /* ---------------- small helpers ---------------- */

  function isBadKey(k) {
    return k === '__proto__' || k === 'constructor' || k === 'prototype';
  }

  function utf8len(s) {
    var n = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 128) n += 1;
      else if (c < 2048) n += 2;
      else if (c >= 0xd800 && c < 0xdc00) {
        n += 4;
        i++;
      } else n += 3;
    }
    return n;
  }

  function makeId() {
    var a = new Uint8Array(12);
    if (root.crypto && root.crypto.getRandomValues) root.crypto.getRandomValues(a);
    else for (var i = 0; i < a.length; i++) a[i] = Math.floor(Math.random() * 256);
    var s = 'p';
    for (var j = 0; j < a.length; j++) s += (a[j] % 36).toString(36);
    return s;
  }

  function later(fn) {
    if (typeof root.requestAnimationFrame === 'function' && !(root.document && root.document.hidden)) {
      root.requestAnimationFrame(fn);
    } else {
      setTimeout(fn, 33);
    }
  }

  function err(code, message) {
    return { code: code, message: message };
  }

  /* ---------------- connection state ---------------- */

  var peerId = makeId();
  var ws = null;
  var ready = false; // socket open and server said hello
  var retries = 0;
  var retryTimer = null;
  var started = false;
  var stopped = false; // page is closing: do not reconnect
  var rooms = new Map(); // name -> room state

  function sendRaw(obj) {
    if (ws && ws.readyState === 1) {
      ws.send(JSON.stringify(obj));
      return true;
    }
    return false;
  }

  function connect() {
    clearTimeout(retryTimer);
    retryTimer = null;
    var sock;
    try {
      sock = new root.WebSocket(WS_URL);
    } catch (e) {
      scheduleRetry();
      return;
    }
    ws = sock;
    sock.onopen = function () {
      if (ws !== sock) return;
      sock.send(JSON.stringify({ t: 'hello', peer: peerId }));
    };
    sock.onmessage = function (ev) {
      if (ws !== sock) return;
      var m;
      try {
        m = JSON.parse(ev.data);
      } catch (e) {
        return;
      }
      if (m && typeof m === 'object') onServerMessage(m);
    };
    sock.onclose = function () {
      if (ws !== sock) return;
      ws = null;
      ready = false;
      rooms.forEach(function (r) {
        r.joined = false;
      });
      scheduleRetry();
    };
    sock.onerror = function () {};
  }

  function scheduleRetry() {
    if (stopped || retryTimer) return;
    var delay = Math.min(10000, 400 * Math.pow(2, retries++)) + Math.random() * 300;
    retryTimer = setTimeout(connect, delay);
  }

  function start() {
    if (started) return;
    started = true;
    connect();
    if (root.addEventListener) {
      root.addEventListener('pagehide', function () {
        stopped = true;
        clearTimeout(retryTimer);
        if (ws) ws.close();
      });
    }
  }

  /* ---------------- rooms ---------------- */

  function newRoom(name) {
    return {
      name: name,
      others: new Map(), // peer -> { peer, presence, updatedAt, obj }
      mine: {},
      myUpdated: Date.now(),
      meObj: null,
      snap: null,
      listeners: [],
      handlers: {},
      waiters: [],
      joined: false,
      closed: false,
      flushScheduled: false,
      sendTimer: null,
    };
  }

  function buildPeerObj(peer, presence, updatedAt, isMe) {
    return Object.freeze({
      peer: peer,
      by: null,
      isMe: isMe,
      sameTab: isMe,
      kind: 'viewer',
      guest: false,
      presence: Object.freeze(presence),
      updatedAt: updatedAt,
    });
  }

  function me(r) {
    if (!r.meObj || r.meObj.peer !== peerId) {
      r.meObj = buildPeerObj(peerId, JSON.parse(JSON.stringify(r.mine)), r.myUpdated, true);
      r.snap = null;
    }
    return r.meObj;
  }

  function snapshot(r) {
    if (!r.snap) {
      var list = [me(r)];
      r.others.forEach(function (e) {
        list.push(e.obj);
      });
      r.snap = Object.freeze(list);
    }
    return r.snap;
  }

  // kind: 'joined' | 'updated' | 'left'
  function mark(r, kind, obj) {
    r.snap = null;
    for (var i = 0; i < r.listeners.length; i++) {
      var ch = r.listeners[i].ch;
      var p = obj.peer;
      if (kind === 'joined') {
        if (ch.left.has(p)) {
          ch.left.delete(p);
          ch.updated.set(p, obj);
        } else ch.joined.set(p, obj);
      } else if (kind === 'updated') {
        if (ch.joined.has(p)) ch.joined.set(p, obj);
        else ch.updated.set(p, obj);
      } else {
        if (ch.joined.has(p)) ch.joined.delete(p);
        else ch.left.set(p, obj);
        ch.updated.delete(p);
      }
    }
    scheduleFlush(r);
  }

  function scheduleFlush(r) {
    if (r.flushScheduled) return;
    r.flushScheduled = true;
    later(function () {
      r.flushScheduled = false;
      flush(r);
    });
  }

  function values(map) {
    var out = [];
    map.forEach(function (v) {
      out.push(v);
    });
    return out;
  }

  function flush(r) {
    var ls = r.listeners.slice();
    for (var i = 0; i < ls.length; i++) {
      var l = ls[i];
      if (!l.active || !l.primed) continue;
      var ch = l.ch;
      if (!ch.joined.size && !ch.left.size && !ch.updated.size) continue;
      var change = {
        peers: snapshot(r),
        joined: Object.freeze(values(ch.joined)),
        left: Object.freeze(values(ch.left)),
        updated: Object.freeze(values(ch.updated)),
      };
      ch.joined.clear();
      ch.left.clear();
      ch.updated.clear();
      try {
        l.fn(change);
      } catch (e) {
        if (root.console) console.error(e);
      }
    }
  }

  function applyOther(r, peer, presence) {
    var prev = r.others.get(peer);
    var now = Date.now();
    var entry = { peer: peer, presence: presence, updatedAt: now };
    entry.obj = buildPeerObj(peer, presence, now, false);
    r.others.set(peer, entry);
    mark(r, prev ? 'updated' : 'joined', entry.obj);
  }

  function removeOther(r, peer) {
    var prev = r.others.get(peer);
    if (!prev) return;
    r.others.delete(peer);
    mark(r, 'left', prev.obj);
  }

  function reconcile(r, list) {
    var seen = {};
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      if (!item || typeof item.peer !== 'string' || item.peer === peerId) continue;
      seen[item.peer] = true;
      var prev = r.others.get(item.peer);
      var presence = item.presence && typeof item.presence === 'object' ? item.presence : {};
      if (!prev || JSON.stringify(prev.presence) !== JSON.stringify(presence)) {
        applyOther(r, item.peer, presence);
      }
    }
    var gone = [];
    r.others.forEach(function (_, p) {
      if (!seen[p]) gone.push(p);
    });
    gone.forEach(function (p) {
      removeOther(r, p);
    });
  }

  function sendJoin(r) {
    sendRaw({ t: 'join', room: r.name, presence: r.mine });
  }

  function sendPresence(r) {
    if (ready && r.joined && !r.closed) sendRaw({ t: 'presence', room: r.name, presence: r.mine });
  }

  function onServerMessage(m) {
    switch (m.t) {
      case 'hello':
        if (typeof m.peer === 'string' && m.peer !== peerId) {
          peerId = m.peer; // server picked a different id
          rooms.forEach(function (r) {
            r.meObj = null;
            r.snap = null;
          });
        }
        ready = true;
        retries = 0;
        rooms.forEach(function (r) {
          if (!r.closed) sendJoin(r);
        });
        return;

      case 'joined': {
        var r = rooms.get(m.room);
        if (!r || r.closed) return;
        reconcile(r, Array.isArray(m.peers) ? m.peers : []);
        r.joined = true;
        sendPresence(r); // anything set while the join was in flight
        var w = r.waiters;
        r.waiters = [];
        w.forEach(function (x) {
          clearTimeout(x.timer);
          x.resolve();
        });
        return;
      }

      case 'presence': {
        var r2 = rooms.get(m.room);
        if (!r2 || r2.closed || typeof m.peer !== 'string' || m.peer === peerId) return;
        if (!m.presence || typeof m.presence !== 'object' || Array.isArray(m.presence)) return;
        applyOther(r2, m.peer, m.presence);
        return;
      }

      case 'left': {
        var r3 = rooms.get(m.room);
        if (r3 && !r3.closed) removeOther(r3, m.peer);
        return;
      }

      case 'emit': {
        var r4 = rooms.get(m.room);
        if (!r4 || r4.closed) return;
        var hs = r4.handlers[m.topic];
        if (!hs) return;
        var isMe = m.peer === peerId;
        var msg = {
          topic: m.topic,
          data: m.data,
          peer: m.peer,
          by: null,
          isMe: isMe,
          sameTab: isMe,
          kind: 'viewer',
          guest: false,
        };
        hs.slice().forEach(function (h) {
          if (!h.active) return;
          try {
            h.fn(msg);
          } catch (e) {
            if (root.console) console.error(e);
          }
        });
        return;
      }

      case 'err': {
        var r5 = rooms.get(m.room);
        if (!r5) return;
        var waiters = r5.waiters;
        r5.waiters = [];
        if (waiters.length) {
          rooms.delete(r5.name);
          r5.closed = true;
        }
        waiters.forEach(function (x) {
          clearTimeout(x.timer);
          x.reject(err(m.code || 'error', m.message || 'request failed'));
        });
        return;
      }
    }
  }

  /* ---------------- the API handed to the game ---------------- */

  function api(r) {
    return Object.freeze({
      peers: function () {
        return snapshot(r);
      },

      onPeers: function (fn, onError) {
        if (typeof fn !== 'function') throw new TypeError('handler must be a function');
        var l = {
          fn: fn,
          active: true,
          primed: false,
          ch: { joined: new Map(), left: new Map(), updated: new Map() },
        };
        r.listeners.push(l);
        // First delivery: the room so far, everyone as "joined".
        Promise.resolve().then(function () {
          if (!l.active) return;
          l.primed = true;
          l.ch.joined.clear();
          l.ch.left.clear();
          l.ch.updated.clear();
          var snap = snapshot(r);
          try {
            fn({ peers: snap, joined: snap, left: Object.freeze([]), updated: Object.freeze([]) });
          } catch (e) {
            if (root.console) console.error(e);
          }
        });
        return function () {
          l.active = false;
          var i = r.listeners.indexOf(l);
          if (i >= 0) r.listeners.splice(i, 1);
        };
      },

      presence: function (patch) {
        if (r.closed) return Promise.reject(err('closed', 'room was left'));
        if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
          return Promise.reject(err('invalid_argument', 'presence patch must be an object'));
        }
        var next = {};
        var k;
        for (k in r.mine) if (Object.prototype.hasOwnProperty.call(r.mine, k)) next[k] = r.mine[k];
        for (k in patch) {
          if (!Object.prototype.hasOwnProperty.call(patch, k) || isBadKey(k)) continue;
          if (patch[k] === null) delete next[k];
          else next[k] = patch[k];
        }
        var json;
        try {
          json = JSON.stringify(next);
        } catch (e) {
          return Promise.reject(err('invalid_argument', 'presence must be plain JSON'));
        }
        if (utf8len(json) > PRESENCE_MAX_BYTES) {
          return Promise.reject(err('invalid_argument', 'presence is over ' + PRESENCE_MAX_BYTES + ' bytes'));
        }
        r.mine = JSON.parse(json);
        r.myUpdated = Date.now();
        r.meObj = null;
        r.snap = null;
        mark(r, 'updated', me(r));
        if (!r.sendTimer) {
          r.sendTimer = setTimeout(function () {
            r.sendTimer = null;
            sendPresence(r);
          }, 33);
        }
        return Promise.resolve();
      },

      emit: function (topic, data) {
        if (r.closed) return Promise.reject(err('closed', 'room was left'));
        if (typeof topic !== 'string' || !NAME_RE.test(topic)) {
          return Promise.reject(err('invalid_argument', 'bad topic'));
        }
        if (data !== undefined) {
          var json;
          try {
            json = JSON.stringify(data);
          } catch (e) {
            return Promise.reject(err('invalid_argument', 'data must be plain JSON'));
          }
          if (json !== undefined && utf8len(json) > EMIT_MAX_BYTES) {
            return Promise.reject(err('invalid_argument', 'data is over ' + EMIT_MAX_BYTES + ' bytes'));
          }
        }
        if (ready && r.joined) sendRaw({ t: 'emit', room: r.name, topic: topic, data: data });
        return Promise.resolve();
      },

      on: function (topic, fn) {
        if (typeof fn !== 'function') throw new TypeError('handler must be a function');
        var h = { fn: fn, active: true };
        (r.handlers[topic] = r.handlers[topic] || []).push(h);
        return function () {
          h.active = false;
          var arr = r.handlers[topic] || [];
          var i = arr.indexOf(h);
          if (i >= 0) arr.splice(i, 1);
        };
      },

      connected: function () {
        return ready && r.joined && !r.closed;
      },

      leave: function () {
        if (r.closed) return Promise.resolve();
        r.closed = true;
        clearTimeout(r.sendTimer);
        r.sendTimer = null;
        if (rooms.get(r.name) === r) rooms.delete(r.name);
        sendRaw({ t: 'leave', room: r.name });
        r.listeners.forEach(function (l) {
          l.active = false;
        });
        r.listeners = [];
        r.handlers = {};
        return Promise.resolve();
      },
    });
  }

  /* ---------------- the lobby: the room everyone shares ---------------- */

  var lobby = newRoom('lobby');
  rooms.set('lobby', lobby);
  var lobbyApi = api(lobby);

  var roomNamespace = Object.freeze({
    peers: lobbyApi.peers,
    onPeers: lobbyApi.onPeers,
    presence: lobbyApi.presence,
    emit: lobbyApi.emit,
    on: lobbyApi.on,
    connected: lobbyApi.connected,

    // A named room (a match): heard only by the pages that joined that name.
    join: function (name) {
      if (typeof name !== 'string' || !NAME_RE.test(name)) {
        return Promise.reject(err('invalid_argument', 'bad room name'));
      }
      var existing = rooms.get(name);
      if (existing && !existing.closed && existing.joined) return Promise.resolve(api(existing));
      var r = existing && !existing.closed ? existing : newRoom(name);
      rooms.set(name, r);
      return new Promise(function (resolve, reject) {
        var w = { resolve: null, reject: null, timer: null };
        w.resolve = function () {
          resolve(api(r));
        };
        w.reject = reject;
        w.timer = setTimeout(function () {
          var i = r.waiters.indexOf(w);
          if (i >= 0) r.waiters.splice(i, 1);
          if (!r.joined) {
            r.closed = true;
            if (rooms.get(name) === r) rooms.delete(name);
            sendRaw({ t: 'leave', room: name });
          }
          reject(err('timeout', 'could not reach the game server'));
        }, JOIN_TIMEOUT_MS);
        r.waiters.push(w);
        if (ready) sendJoin(r);
        else start();
      });
    },
  });

  root.claude = Object.freeze({
    use: function (name) {
      if (name === 'room') {
        start();
        return Promise.resolve(roomNamespace);
      }
      return Promise.resolve(null);
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
