'use strict';
/**
 * End-to-end test. Starts the real server on a free port and drives it with
 * several simulated browsers that run the real public/room-client.js.
 *
 *   npm install && npm test
 */
const assert = require('assert');
const fs = require('fs');
const http = require('http');
const path = require('path');
const vm = require('vm');
const { WebSocket: WsClient } = require('ws');
const { createApp } = require('./server');

const CLIENT_SRC = fs.readFileSync(path.join(__dirname, 'public', 'room-client.js'), 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function until(fn, ms = 3000, label = 'condition') {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (fn()) return;
    await sleep(20);
  }
  throw new Error('timed out waiting for ' + label);
}

/** A fake browser tab that runs the real client file. */
function browser(port) {
  const win = {
    location: { protocol: 'http:', host: '127.0.0.1:' + port },
    WebSocket: globalThis.WebSocket,
    crypto: globalThis.crypto,
    console,
    setTimeout,
    clearTimeout,
    document: { hidden: true },
    addEventListener() {},
  };
  win.window = win;
  vm.runInNewContext(CLIENT_SRC, win);
  return win;
}

function get(port, urlPath, headers = {}, method = 'GET') {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: urlPath, method, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    req.end();
  });
}

function rawClient(port, headers) {
  return new Promise((resolve, reject) => {
    const ws = new WsClient('ws://127.0.0.1:' + port + '/ws', { headers });
    const c = { ws, inbox: [], peer: null };
    ws.on('message', (d) => {
      const m = JSON.parse(d.toString());
      c.inbox.push(m);
      if (m.t === 'hello') c.peer = m.peer;
    });
    ws.on('open', () => resolve(c));
    ws.on('error', reject);
    ws.on('unexpected-response', (req, res) => reject(Object.assign(new Error('http ' + res.statusCode), { status: res.statusCode })));
  });
}
const rsend = (c, o) => c.ws.send(JSON.stringify(o));

let passed = 0;
const failures = [];
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log('  PASS  ' + name);
  } catch (e) {
    failures.push(name);
    console.log('  FAIL  ' + name + '\n        ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n        ') : e));
  }
}

(async () => {
  const app = createApp({ allowedOrigins: '', trustProxy: false });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const port = app.server.address().port;
  console.log('server on port ' + port + '\n');

  /* ---------- lobby ---------- */
  const A = browser(port);
  const B = browser(port);
  const lobbyA = await A.claude.use('room');
  const lobbyB = await B.claude.use('room');
  const seenB = [];
  lobbyB.onPeers((ch) => seenB.push(ch));

  await test('lobby: everyone connects and sees each other', async () => {
    await until(() => lobbyA.connected() === false || true);
    await lobbyA.presence({ n: 'Alice', x: 1 });
    await until(() => lobbyB.peers().length === 2, 3000, 'B to see 2 peers');
    const a = lobbyB.peers().find((p) => !p.isMe);
    assert.strictEqual(a.presence.n, 'Alice');
    assert.strictEqual(a.kind, 'viewer');
    const me = lobbyA.peers().find((p) => p.isMe && p.sameTab);
    assert.ok(me && me.peer, 'A has its own entry');
    assert.notStrictEqual(me.peer, a.peer + 'x');
    assert.strictEqual(me.peer, a.peer, 'both pages agree on the peer id');
  });

  await test('lobby: first onPeers delivery lists everyone as joined', async () => {
    assert.ok(seenB.length >= 1);
    assert.ok(seenB[0].joined.length >= 1, 'first change presents the room as joined');
  });

  await test('presence merges and null removes a field', async () => {
    await lobbyA.presence({ y: 2 });
    await lobbyA.presence({ x: null });
    await until(() => {
      const a = lobbyB.peers().find((p) => !p.isMe);
      return a && a.presence.y === 2 && !('x' in a.presence) && a.presence.n === 'Alice';
    }, 3000, 'merged presence');
  });

  await test('peers and presence are frozen', async () => {
    const p = lobbyB.peers()[0];
    assert.ok(Object.isFrozen(p) && Object.isFrozen(p.presence) && Object.isFrozen(lobbyB.peers()));
  });

  /* ---------- named rooms ---------- */
  const C = browser(port);
  const lobbyC = await C.claude.use('room');
  const mA = await lobbyA.join('vc-test1');
  const mB = await lobbyB.join('vc-test1');
  const mC = await lobbyC.join('vc-other');

  await test('named room: only people who joined that name see each other', async () => {
    await mA.presence({ hp: 10 });
    await until(() => mB.peers().length === 2, 3000, 'B sees A in match');
    await until(() => mB.peers().some((p) => !p.isMe && p.presence.hp === 10), 3000, 'A presence in match');
    assert.strictEqual(mC.peers().length, 1, 'C is alone in its own room');
    assert.ok(mA.connected());
  });

  await test('named room updates arrive through onPeers as "updated"', async () => {
    const got = [];
    const stop = mB.onPeers((ch) => got.push(ch));
    await sleep(80);
    await mA.presence({ hp: 7 });
    await until(() => got.some((ch) => ch.updated.some((p) => p.presence.hp === 7)), 3000, 'updated hp=7');
    stop();
  });

  await test('leaving a room tells the others', async () => {
    const got = [];
    mA.onPeers((ch) => got.push(ch));
    await sleep(80);
    await mB.leave();
    await until(() => got.some((ch) => ch.left.length === 1), 3000, 'left event');
    assert.strictEqual(mA.peers().length, 1);
    await assert.rejects(() => mB.presence({ a: 1 }));
  });

  await test('bad room names are rejected', async () => {
    await assert.rejects(() => lobbyA.join('Bad Name'), (e) => e.code === 'invalid_argument');
    await assert.rejects(() => lobbyA.join('x'.repeat(60)), (e) => e.code === 'invalid_argument');
  });

  await test('oversized presence is rejected by the client', async () => {
    await assert.rejects(() => lobbyA.presence({ big: 'x'.repeat(5000) }), (e) => e.code === 'invalid_argument');
  });

  await test('events: emit reaches everyone in the room, sender included', async () => {
    const mB2 = await lobbyB.join('vc-test1');
    const gotA = [];
    const gotB = [];
    mA.on('chat', (m) => gotA.push(m));
    mB2.on('chat', (m) => gotB.push(m));
    await until(() => mA.peers().length === 2, 3000, 'rejoin');
    await mA.emit('chat', { text: 'hello' });
    await until(() => gotA.length === 1 && gotB.length === 1, 3000, 'chat delivered');
    assert.strictEqual(gotB[0].data.text, 'hello');
    assert.strictEqual(gotA[0].isMe, true);
    assert.strictEqual(gotB[0].isMe, false);
    await mB2.leave();
  });

  /* ---------- security ---------- */
  await test('a client cannot pretend to be another peer', async () => {
    const X = await rawClient(port);
    rsend(X, { t: 'hello' });
    await until(() => X.peer, 2000, 'hello');
    rsend(X, { t: 'join', room: 'lobby', presence: {} });
    await until(() => X.inbox.some((m) => m.t === 'joined'), 2000, 'joined');
    const victim = lobbyA.peers().find((p) => p.isMe).peer;
    rsend(X, { t: 'presence', room: 'lobby', peer: victim, presence: { evil: 1 } });
    await until(() => lobbyB.peers().some((p) => p.peer === X.peer && p.presence.evil === 1), 3000, 'X visible');
    const asVictim = lobbyB.peers().find((p) => p.peer === victim);
    assert.ok(asVictim && !('evil' in asVictim.presence), 'victim presence untouched');
    X.ws.close();
  });

  await test('prototype-pollution keys are dropped', async () => {
    const X = await rawClient(port);
    rsend(X, { t: 'hello' });
    await until(() => X.peer, 2000, 'hello');
    X.ws.send('{"t":"join","room":"lobby","presence":{"__proto__":{"polluted":1},"constructor":1,"ok":1}}');
    await until(() => lobbyB.peers().some((p) => p.peer === X.peer), 3000, 'X visible');
    const p = lobbyB.peers().find((q) => q.peer === X.peer);
    assert.strictEqual(p.presence.ok, 1);
    assert.ok(!Object.prototype.hasOwnProperty.call(p.presence, 'constructor'));
    assert.strictEqual({}.polluted, undefined);
    X.ws.close();
  });

  await test('server rejects oversized presence', async () => {
    const X = await rawClient(port);
    rsend(X, { t: 'hello' });
    await until(() => X.peer, 2000, 'hello');
    rsend(X, { t: 'join', room: 'lobby', presence: {} });
    await until(() => X.inbox.some((m) => m.t === 'joined'), 2000, 'joined');
    rsend(X, { t: 'presence', room: 'lobby', presence: { big: 'y'.repeat(5000) } });
    await until(() => X.inbox.some((m) => m.t === 'err' && m.code === 'invalid_argument'), 2000, 'error reply');
    X.ws.close();
  });

  await test('same peer id cannot be taken over by a second socket', async () => {
    const victim = lobbyA.peers().find((p) => p.isMe).peer;
    const X = await rawClient(port);
    rsend(X, { t: 'hello', peer: victim });
    await until(() => X.peer, 2000, 'hello');
    assert.notStrictEqual(X.peer, victim);
    X.ws.close();
  });

  await test('garbage and binary messages do not crash the server', async () => {
    const X = await rawClient(port);
    X.ws.send('not json');
    X.ws.send('[1,2,3]');
    X.ws.send('{"t":42}');
    X.ws.send(Buffer.from([1, 2, 3]));
    rsend(X, { t: 'join', room: 'lobby' }); // before hello: ignored
    rsend(X, { t: 'hello' });
    await until(() => X.peer, 2000, 'still answers');
    X.ws.close();
  });

  await test('flooding is rate limited and the server stays healthy', async () => {
    const X = await rawClient(port);
    rsend(X, { t: 'hello' });
    await until(() => X.peer, 2000, 'hello');
    rsend(X, { t: 'join', room: 'vc-flood', presence: {} });
    const Y = await rawClient(port);
    rsend(Y, { t: 'hello' });
    await until(() => Y.peer, 2000, 'hello Y');
    rsend(Y, { t: 'join', room: 'vc-flood', presence: {} });
    await until(() => Y.inbox.some((m) => m.t === 'joined'), 2000, 'Y joined');
    for (let i = 0; i < 2000; i++) rsend(X, { t: 'presence', room: 'vc-flood', presence: { i } });
    await sleep(500);
    const relayed = Y.inbox.filter((m) => m.t === 'presence' && m.peer === X.peer).length;
    assert.ok(relayed < 1000, 'only ' + relayed + ' of 2000 relayed');
    const h = await get(port, '/health');
    assert.strictEqual(h.status, 200);
    X.ws.close();
    Y.ws.close();
  });

  await test('origin check: other websites cannot open the socket', async () => {
    await assert.rejects(() => rawClient(port, { Origin: 'http://evil.example' }), (e) => e.status === 403);
    const ok = await rawClient(port, { Origin: 'http://127.0.0.1:' + port });
    ok.ws.close();
  });

  /* ---------- reconnect ---------- */
  await test('a dropped connection comes back and the room recovers', async () => {
    await lobbyA.presence({ alive: 1 });
    await until(() => lobbyB.peers().some((p) => !p.isMe && p.presence.alive === 1), 3000, 'alive seen');
    const myPeer = lobbyA.peers().find((p) => p.isMe).peer;
    // cut A's socket from the server side
    for (const ws of app.wss.clients) if (ws.client && ws.client.peer === myPeer) ws.terminate();
    await until(() => !lobbyA.connected(), 2000, 'A notices the drop');
    await until(() => lobbyA.connected(), 6000, 'A reconnects');
    await until(() => lobbyB.peers().some((p) => p.peer === myPeer && p.presence.alive === 1), 4000, 'B sees A again with presence');
    assert.strictEqual(lobbyA.peers().find((p) => p.isMe).peer, myPeer, 'same peer id after reconnect');
  });

  /* ---------- static hosting ---------- */
  await test('serves the game page and client script', async () => {
    const r = await get(port, '/');
    assert.strictEqual(r.status, 200);
    assert.ok(/text\/html/.test(r.headers['content-type']));
    assert.ok(r.body.toString().includes('VICE CITY: BLAZING STREETS'));
    assert.ok(r.body.toString().includes('room-client.js'));
    const j = await get(port, '/room-client.js');
    assert.strictEqual(j.status, 200);
    assert.ok(/javascript/.test(j.headers['content-type']));
  });

  await test('gzip and ETag/304 work', async () => {
    const r = await get(port, '/', { 'Accept-Encoding': 'gzip' });
    assert.strictEqual(r.headers['content-encoding'], 'gzip');
    assert.ok(r.body.length < 100000);
    const r2 = await get(port, '/', { 'If-None-Match': r.headers.etag });
    assert.strictEqual(r2.status, 304);
  });

  await test('path traversal and other methods are refused', async () => {
    for (const p of ['/../server.js', '/%2e%2e/server.js', '/..%2fserver.js', '/public/../../server.js', '/%00', '/nope.txt']) {
      const r = await get(port, p);
      assert.ok(r.status === 404 || r.status === 400, p + ' -> ' + r.status);
      assert.ok(!r.body.toString().includes('createApp'), p + ' leaked source');
    }
    const post = await get(port, '/', {}, 'POST');
    assert.strictEqual(post.status, 405);
  });

  await test('/health reports players and rooms', async () => {
    const r = JSON.parse((await get(port, '/health')).body.toString());
    assert.strictEqual(r.ok, true);
    assert.ok(r.players >= 3);
  });

  await test('rooms are cleaned up when everyone leaves', async () => {
    await mA.leave();
    await mC.leave();
    await until(() => !app.rooms.has('vc-test1') && !app.rooms.has('vc-other'), 3000, 'empty rooms removed');
  });

  console.log('\n' + passed + ' passed, ' + failures.length + ' failed');
  app.wss.clients.forEach((ws) => ws.terminate());
  app.server.close();
  process.exit(failures.length ? 1 : 0);
})().catch((e) => {
  console.error('test runner crashed:', e);
  process.exit(2);
});
