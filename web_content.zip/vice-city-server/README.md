# VICE CITY: BLAZING STREETS - game server

Your own server for the game. It does two jobs:

1. Hosts the game page (`public/index.html`).
2. Connects players for multiplayer (WebSocket at `/ws`): lobby, rooms, quick match.

## Run it

```bash
npm install
npm start
```

Open http://localhost:3000. Open it in two tabs to try multiplayer.

To play with friends on the same Wi-Fi, they open `http://YOUR-COMPUTER-IP:3000`.

## Put it online

You need a host that runs Node.js and allows WebSockets, for example Render,
Railway, Fly.io, or any VPS. (Vercel and Netlify do not work: they cannot keep
WebSocket connections open.)

- Build command: `npm install`
- Start command: `npm start`
- Environment variable `TRUST_PROXY=1` (hosts put a proxy in front of your server)
- The host gives you an `https://` address. The game switches to secure
  WebSockets (`wss://`) automatically.

## Files

| File | What it is |
| --- | --- |
| `server.js` | The server (static hosting + multiplayer rooms) |
| `public/index.html` | The game |
| `public/room-client.js` | Connects the game to the server |
| `test.js` | Automated tests (`npm test`) |

## Settings (environment variables)

| Name | Default | Meaning |
| --- | --- | --- |
| `PORT` | 3000 | Port to listen on |
| `HOST` | 0.0.0.0 | Address to bind |
| `ALLOWED_ORIGINS` | same site only | Websites allowed to connect, comma separated |
| `TRUST_PROXY` | off | Set to `1` behind a proxy so per-IP limits use the real IP |

## Built-in protection

- Messages are rate limited, and oversized or malformed ones are ignored.
- A player's identity is set by the server, so nobody can pose as another player.
- Limits: 256 players per room, 4 rooms per player, 30 connections per IP.
- Other websites cannot open a connection to your server (origin check).
- Dead connections are removed automatically.

## Good to know

- The server is a relay: it passes each player's state to the others but does
  not judge it. Fine for friends, but a determined cheater could send fake
  data. Moving game rules to the server is a bigger project.
- Nothing is stored. Rooms exist only while players are connected.
- Three.js still loads from the cdnjs website. For fully offline play, download
  `three.min.js` (r128) into `public/` and change the `<script>` tag in
  `public/index.html`.
- One Node process handles hundreds of players. For more, run several
  servers and split players across them.
