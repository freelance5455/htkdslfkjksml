'use strict';
/**
 * VICE CITY: BLAZING STREETS - multiplayer server
 *
 *  - Serves the game from ./public
 *  - Relays multiplayer "rooms" over a WebSocket at /ws
 *
 * Run:  npm install && npm start      (then open http://localhost:3000)
 *
 * Environment variables
 *   PORT             port to listen on (default 3000)
 *   HOST             address to bind (default 0.0.0.0)
 *   ALLOWED_ORIGINS  comma-separated list of origins allowed to open the
 *                    WebSocket, e.g. https://mygame.example.com
 *                    (default: only the same host that served the page)
 *   TRUST_PROXY=1    read the client IP from X-Forwarded-For (set this when
 *                    running behind a proxy such as Render, Railway or nginx)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PUBLIC_DIR = path.join(__dirname, 'public');

const LIMITS = {
  maxClients: 5000,
  maxPerIp: 30,
  maxRooms: 5000,
  maxPerRoom: 256,
  maxRoomsPerClient: 4,
  presenceBytes: 4096,
  emitBytes: 4096,
  payloadBytes: 16 * 1024,
  msgPerSecond: 80,
  burst: 160,
  maxBuffered: 1024 * 1024,
  maxDepth: 8,
};

const ROOM_RE = /^[a-z][a-z0-9_.-]{0,47}$/;
const TOPIC_RE = ROOM_RE;
const PEER_RE = /^[a-z0-9]{12,24}$/;
const BAD_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function newPeerId() {
  const bytes = crypto.randomBytes(12);
  let s = 'p';
  for (const b of bytes) s += (b % 36).toString(36);
  return s;
}

/** Deep-copies plain JSON, dropping dangerous keys. Throws if too deep. */
function cleanJson(value, depth = 0) {
  if (depth > LIMITS.maxDepth) throw new Error('too deep');
  if (Array.isArray(value)) return value.map((v) => cleanJson(v, depth + 1));
  if (value && typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value)) {
      if (BAD_KEYS.has(key)) continue;
      out[key] = cleanJson(value[key], depth + 1);
    }
    return out;
  }
  return value;
}

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/* ------------------------------------------------------------------ */
/* app                                                                 */
/* ------------------------------------------------------------------ */

function createApp(opts = {}) {
  const allowedOrigins = String(opts.allowedOrigins ?? process.env.ALLOWED_ORIGINS ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const trustProxy = (opts.trustProxy ?? process.env.TRUST_PROXY) == '1';

  const rooms = new Map(); // roomName -> Map(peerId -> { client, presence })
  const peers = new Map(); // peerId -> client
  const perIp = new Map(); // ip -> open connections

  /* ---------------- static files ---------------- */

  const fileCache = new Map(); // abs path -> { mtimeMs, size, buf, gz, etag, type }

  function serveFile(req, res, absPath) {
    fs.stat(absPath, (err, st) => {
      if (err || !st.isFile()) return notFound(res);
      let entry = fileCache.get(absPath);
      if (!entry || entry.mtimeMs !== st.mtimeMs || entry.size !== st.size) {
        let buf;
        try {
          buf = fs.readFileSync(absPath);
        } catch (e) {
          return notFound(res);
        }
        const type = MIME[path.extname(absPath).toLowerCase()] || 'application/octet-stream';
        const textual = /^(text|application\/json|image\/svg)/.test(type);
        entry = {
          mtimeMs: st.mtimeMs,
          size: st.size,
          buf,
          gz: textual && buf.length > 1024 ? zlib.gzipSync(buf) : null,
          etag: '"' + crypto.createHash('sha1').update(buf).digest('hex').slice(0, 20) + '"',
          type,
        };
        fileCache.set(absPath, entry);
      }
      const headers = {
        'Content-Type': entry.type,
        ETag: entry.etag,
        'Cache-Control': 'no-cache',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'no-referrer',
        Vary: 'Accept-Encoding',
      };
      if (req.headers['if-none-match'] === entry.etag) {
        res.writeHead(304, headers);
        return res.end();
      }
      let body = entry.buf;
      if (entry.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
        body = entry.gz;
        headers['Content-Encoding'] = 'gzip';
      }
      headers['Content-Length'] = body.length;
      res.writeHead(200, headers);
      res.end(req.method === 'HEAD' ? undefined : body);
    });
  }

  function notFound(res) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }

  function handleHttp(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD' });
      return res.end();
    }
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch (e) {
      res.writeHead(400);
      return res.end();
    }
    if (pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ ok: true, players: peers.size, rooms: rooms.size }));
    }
    if (pathname.includes('\0')) return notFound(res);
    if (pathname === '/') pathname = '/index.html';
    const abs = path.join(PUBLIC_DIR, path.normalize(pathname));
    if (abs !== PUBLIC_DIR && !abs.startsWith(PUBLIC_DIR + path.sep)) return notFound(res);
    serveFile(req, res, abs);
  }

  const server = http.createServer(handleHttp);

  /* ---------------- websocket ---------------- */

  const wss = new WebSocketServer({
    noServer: true,
    maxPayload: LIMITS.payloadBytes,
    perMessageDeflate: false,
  });

  function clientIp(req) {
    if (trustProxy) {
      const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
      if (xff) return xff;
    }
    return req.socket.remoteAddress || 'unknown';
  }

  function originOk(req) {
    const origin = req.headers.origin;
    if (!origin) return true; // not a browser
    if (allowedOrigins.length) return allowedOrigins.includes(origin);
    try {
      return new URL(origin).host === req.headers.host;
    } catch (e) {
      return false;
    }
  }

  function reject(socket, code, text) {
    socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\n\r\n`);
    socket.destroy();
  }

  server.on('upgrade', (req, socket, head) => {
    let pathname = '';
    try {
      pathname = new URL(req.url, 'http://localhost').pathname;
    } catch (e) {
      return reject(socket, 400, 'Bad Request');
    }
    if (pathname !== '/ws') return reject(socket, 404, 'Not Found');
    if (!originOk(req)) return reject(socket, 403, 'Forbidden');
    const ip = clientIp(req);
    if (wss.clients.size >= LIMITS.maxClients || (perIp.get(ip) || 0) >= LIMITS.maxPerIp) {
      return reject(socket, 503, 'Service Unavailable');
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      ws.ip = ip;
      wss.emit('connection', ws, req);
    });
  });

  function send(ws, obj) {
    if (ws.readyState !== 1) return;
    if (ws.bufferedAmount > LIMITS.maxBuffered) {
      ws.terminate(); // too slow to keep up
      return;
    }
    ws.send(JSON.stringify(obj));
  }

  function broadcast(roomName, obj, exceptPeer) {
    const members = rooms.get(roomName);
    if (!members) return;
    const text = JSON.stringify(obj);
    for (const [peer, m] of members) {
      if (peer === exceptPeer) continue;
      const ws = m.client.ws;
      if (ws.readyState !== 1) continue;
      if (ws.bufferedAmount > LIMITS.maxBuffered) {
        ws.terminate();
        continue;
      }
      ws.send(text);
    }
  }

  function takeToken(client) {
    const now = Date.now();
    client.tokens = Math.min(
      LIMITS.burst,
      client.tokens + ((now - client.lastRefill) / 1000) * LIMITS.msgPerSecond
    );
    client.lastRefill = now;
    if (client.tokens < 1) return false;
    client.tokens -= 1;
    return true;
  }

  function leaveRoom(client, roomName) {
    if (!client.rooms.has(roomName)) return;
    client.rooms.delete(roomName);
    const members = rooms.get(roomName);
    if (!members) return;
    members.delete(client.peer);
    if (members.size === 0) rooms.delete(roomName);
    else broadcast(roomName, { t: 'left', room: roomName, peer: client.peer });
  }

  function dropClient(client) {
    for (const roomName of Array.from(client.rooms)) leaveRoom(client, roomName);
    if (client.peer && peers.get(client.peer) === client) peers.delete(client.peer);
    const n = (perIp.get(client.ws.ip) || 1) - 1;
    if (n <= 0) perIp.delete(client.ws.ip);
    else perIp.set(client.ws.ip, n);
  }

  function fail(client, room, code, message) {
    send(client.ws, { t: 'err', room, code, message });
  }

  function handleMessage(client, m) {
    switch (m.t) {
      case 'hello': {
        if (client.peer) return;
        let id = typeof m.peer === 'string' && PEER_RE.test(m.peer) ? m.peer : null;
        // Never let a second socket take over a peer id that is in use.
        if (!id || peers.has(id)) id = newPeerId();
        client.peer = id;
        peers.set(id, client);
        send(client.ws, { t: 'hello', peer: id });
        return;
      }

      case 'join': {
        if (!client.peer) return;
        const name = m.room;
        if (typeof name !== 'string' || !ROOM_RE.test(name)) {
          return fail(client, name, 'invalid_argument', 'bad room name');
        }
        let presence = {};
        if (m.presence !== undefined) {
          if (!isPlainObject(m.presence)) return fail(client, name, 'invalid_argument', 'bad presence');
          try {
            presence = cleanJson(m.presence);
          } catch (e) {
            return fail(client, name, 'invalid_argument', 'presence too deep');
          }
          if (Buffer.byteLength(JSON.stringify(presence)) > LIMITS.presenceBytes) {
            return fail(client, name, 'invalid_argument', 'presence too large');
          }
        }
        let members = rooms.get(name);
        const already = client.rooms.has(name);
        if (!already) {
          if (client.rooms.size >= LIMITS.maxRoomsPerClient) {
            return fail(client, name, 'limit', 'too many rooms');
          }
          if (!members && rooms.size >= LIMITS.maxRooms) {
            return fail(client, name, 'limit', 'server is full');
          }
          if (members && members.size >= LIMITS.maxPerRoom) {
            return fail(client, name, 'room_full', 'room is full');
          }
        }
        if (!members) {
          members = new Map();
          rooms.set(name, members);
        }
        members.set(client.peer, { client, presence });
        client.rooms.add(name);
        const others = [];
        for (const [peer, mem] of members) {
          if (peer !== client.peer) others.push({ peer, presence: mem.presence });
        }
        send(client.ws, { t: 'joined', room: name, peers: others });
        broadcast(name, { t: 'presence', room: name, peer: client.peer, presence }, client.peer);
        return;
      }

      case 'presence': {
        if (!client.peer || !client.rooms.has(m.room)) return;
        if (!isPlainObject(m.presence)) return;
        let presence;
        try {
          presence = cleanJson(m.presence);
        } catch (e) {
          return fail(client, m.room, 'invalid_argument', 'presence too deep');
        }
        if (Buffer.byteLength(JSON.stringify(presence)) > LIMITS.presenceBytes) {
          return fail(client, m.room, 'invalid_argument', 'presence too large');
        }
        const mem = rooms.get(m.room).get(client.peer);
        mem.presence = presence;
        broadcast(m.room, { t: 'presence', room: m.room, peer: client.peer, presence }, client.peer);
        return;
      }

      case 'emit': {
        if (!client.peer || !client.rooms.has(m.room)) return;
        if (typeof m.topic !== 'string' || !TOPIC_RE.test(m.topic)) return;
        let data;
        try {
          data = m.data === undefined ? undefined : cleanJson(m.data);
        } catch (e) {
          return;
        }
        if (data !== undefined && Buffer.byteLength(JSON.stringify(data)) > LIMITS.emitBytes) return;
        // Delivered to everyone in the room, the sender included.
        broadcast(m.room, { t: 'emit', room: m.room, topic: m.topic, data, peer: client.peer });
        return;
      }

      case 'leave': {
        if (!client.peer) return;
        leaveRoom(client, m.room);
        return;
      }

      default:
        return;
    }
  }

  wss.on('connection', (ws) => {
    const client = {
      ws,
      peer: null,
      rooms: new Set(),
      tokens: LIMITS.burst,
      lastRefill: Date.now(),
      alive: true,
    };
    ws.client = client;
    perIp.set(ws.ip, (perIp.get(ws.ip) || 0) + 1);

    // A connection that never says hello is not a game client.
    const helloTimer = setTimeout(() => {
      if (!client.peer) ws.terminate();
    }, 10000);
    helloTimer.unref();

    ws.on('pong', () => {
      client.alive = true;
    });
    ws.on('message', (data, isBinary) => {
      if (isBinary) return;
      if (!takeToken(client)) return; // rate limited: drop
      let m;
      try {
        m = JSON.parse(data.toString());
      } catch (e) {
        return;
      }
      if (!isPlainObject(m) || typeof m.t !== 'string') return;
      try {
        handleMessage(client, m);
      } catch (e) {
        console.error('message error:', e);
      }
    });
    ws.on('close', () => {
      clearTimeout(helloTimer);
      dropClient(client);
    });
    ws.on('error', () => {});
  });

  // Drop connections that stopped answering (closed laptop, lost signal ...).
  const pinger = setInterval(() => {
    for (const ws of wss.clients) {
      const client = ws.client;
      if (!client) continue;
      if (!client.alive) {
        ws.terminate();
        continue;
      }
      client.alive = false;
      try {
        ws.ping();
      } catch (e) {
        /* ignore */
      }
    }
  }, 25000);
  pinger.unref();

  server.on('close', () => {
    clearInterval(pinger);
  });

  return { server, wss, rooms, peers };
}

/* ------------------------------------------------------------------ */
/* start                                                               */
/* ------------------------------------------------------------------ */

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  const HOST = process.env.HOST || '0.0.0.0';
  const app = createApp();
  app.server.listen(PORT, HOST, () => {
    console.log(`VICE CITY server running on http://localhost:${PORT}`);
  });
  const stop = () => {
    for (const ws of app.wss.clients) ws.close(1001, 'server restarting');
    app.server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

module.exports = { createApp, LIMITS };
