PERFORMANCE TRACKER — Android

1. Installer Android Studio sur Windows.
2. Ouvrir le dossier PerformanceTracker (File > Open).
3. Attendre la synchronisation Gradle (connexion Internet nécessaire la première fois).
4. Menu Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. APK généré : app/build/outputs/apk/debug/app-debug.apk

Fonctionne hors connexion. Les données sont conservées dans le stockage local de l'application.
Attention : désinstaller l'application peut effacer les données.
