# Carreira de Craque v1.56.2 — Recuperação de Conquistas Profissionais

- Corrige a validação de títulos de ligas profissionais quando o histórico contém uma tabela final completa, mas o snapshot de partidas não possui todos os metadados introduzidos em versões recentes.
- A tabela final só é aceita como prova quando contém 20 clubes únicos e cada clube disputou 38 partidas; a posição e o campeão são recalculados com os mesmos critérios de classificação.
- A estante de Conquistas reconcilia títulos profissionais ausentes a partir do histórico finalizado em toda abertura, sem depender de uma migração executada apenas uma vez.
- Não altera resultados, calendários, elencos ou saves de carreira; apenas acrescenta registros de títulos comprovados.
