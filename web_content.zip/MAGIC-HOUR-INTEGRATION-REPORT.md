# ANONYMOUX STUDIOS 2.3.3 — MAGIC HOUR LIP SYNC INTEGRATION REPORT

## Build summary

The supplied `ANONYMOUX_STUDIO_2.3.2_ADMIN_PANEL_ROUTE_FIXED.zip` was used as the baseline. This build adds Magic Hour Lip Sync inside the existing Video Edit Studio while retaining the Decart transformation form and the platform's existing account, SQLite/PDO, credit ledger, media delivery and shared history systems.

## Implemented changes

| Severity | File | Change / evidence | Verification |
|---|---|---|---|
| HIGH | `app/magichour.php` (new) | Magic Hour API client, encrypted-key lookup, signed upload forwarding, MIME/extension validation, PHP upload-limit checks, account credit debit/refund, idempotency table, job polling and MP4 output persistence. | PHP syntax PASS; live provider NOT TESTED. |
| HIGH | `api/magichour.php` (new) | Authenticated, CSRF-protected generation and status endpoints; validates source video/audio; returns local job status and protected media route. | PHP syntax PASS; HTTP/provider NOT TESTED. |
| HIGH | `video-studio.php` | Adds Video Transform / AI Lip Sync mode tabs, video/audio upload previews, mode and clip settings, credit estimate, result player and consent reminder. Existing Decart transform form remains in place. | PHP syntax PASS; browser layout NOT TESTED. |
| HIGH | `app/admin.php` | Adds administrator actions for encrypted Magic Hour key storage, feature enablement, mode configuration, per-generation user-credit price and API account test. | PHP syntax PASS; authenticated admin CRUD NOT TESTED. |
| HIGH | `admin_magichour_view.php` (new) | Adds Magic Hour configuration panel, connection test, configured modes, account tier/credit snapshot and job/credit metrics. | PHP syntax PASS; live admin render NOT TESTED. |
| MEDIUM | `admin.php` | Adds Magic Hour administration tab. | PHP syntax PASS; browser route NOT TESTED. |
| MEDIUM | `assets/workspaces.js` | Adds mode switching, audio/video previews, Lip Sync submission, idempotency-token rotation and status polling. | Node syntax PASS; browser behavior NOT TESTED. |
| MEDIUM | `assets/workspaces.css` | Adds responsive mode tabs and Lip Sync form/result styling with red accent. | Static review; device/browser NOT TESTED. |
| MEDIUM | `history.php` | Labels Magic Hour jobs in the existing history and exposes the protected output link for completed jobs. | PHP syntax PASS; live database NOT TESTED. |
| LOW | `app/bootstrap.php` | Adds optional Magic Hour environment-key fallback and default audio upload cap. No existing Decart settings removed. | PHP syntax PASS. |
| LOW | `config.local.example.php` | Documents optional Magic Hour key fallback and audio upload limit. | PHP syntax PASS. |

## Integration behavior

1. The browser posts video and audio to Anonymoux PHP.
2. PHP validates uploaded files and host size limits.
3. PHP requests signed URLs from `POST /v1/files/upload-urls`.
4. PHP streams both files to the signed HTTPS upload URLs.
5. PHP submits `POST /v1/lip-sync` using the returned `file_path` values and `style.generation_mode`.
6. The provider project ID is recorded in the existing `platform_jobs` table with `workspace='video'` and `model='magic-hour-lip-sync'`.
7. The browser polls the authenticated PHP endpoint. PHP reads `GET /v1/video-projects/{id}`.
8. On provider completion, PHP downloads the MP4 into protected platform storage and records it in `platform_assets`.
9. Completed output is available through the existing ownership-checked `api/media.php` route and shared history.

## Credits and idempotency

- User credits are debited through the existing `user_wallets` / `credit_transactions` ledger.
- Magic Hour provider credits are tracked separately from Anonymoux credits.
- The Anonymoux charge is configurable in Admin → Magic Hour. The initial default is 20 Anonymoux credits; administrators should set their intended price before enabling the feature.
- Failed/rejected submissions are refunded through an idempotent refund transaction.
- Confirmed provider failures are refunded.
- A transport failure during project creation is treated as uncertain: the request is not automatically refunded or resubmitted, and a local review record is created to avoid a duplicate provider charge.
- A unique `magichour_idempotency` request key prevents accidental repeat submissions from charging twice.

## Generation modes

The current official Lip Sync API example documents `style.generation_mode: "lite"`. The public reference does not provide a dedicated endpoint that enumerates every mode enabled on an individual account. Therefore:
- `lite` is the initial configured option.
- Admins can enter additional mode identifiers only after confirming those identifiers with Magic Hour for their account.
- The application does not claim that an unverified mode is supported.

## Hosting safeguards

- PHP 8.x, cURL, fileinfo, OpenSSL, PDO and the existing database driver are required.
- PHP-mediated uploads remain subject to `upload_max_filesize`, `post_max_size`, execution time, memory, storage and outbound HTTPS restrictions imposed by the host.
- The endpoint reports an oversized combined POST rather than silently switching to browser-direct uploads.
- No Node runtime, Composer, cron, daemon or persistent worker is introduced.
- Signed upload and output URLs are restricted to HTTPS Magic Hour hosts before PHP follows them.

## Verification results

| Check | Result |
|---|---|
| ZIP source extraction | PASS |
| PHP syntax — 55 PHP files | PASS (0 syntax failures) |
| JavaScript syntax — 8 JS files | PASS (0 syntax failures) |
| Existing SQLite resource migration test | PASS (repeatable migration and test writes) |
| Existing PHP persistence smoke test | NOT TESTED — skipped because this build environment has no `pdo_sqlite` driver |
| Magic Hour API authentication | NOT TESTED — no Magic Hour API key supplied |
| Magic Hour upload and generation | NOT TESTED — requires configured live provider account and credits |
| Magic Hour status/output download | NOT TESTED — requires a real provider project |
| Decart live generation | NOT TESTED — existing provider credentials are not available in this offline audit |
| Browser/mobile visual checks | NOT TESTED — requires deployment/browser session |
| InfinityFree live request/timeout behavior | NOT TESTED — requires deployment to the hosting account |

The existing resource migration test emitted a non-fatal spreadsheet-runtime warmup warning after reporting its SQLite migration checks as PASS. It exited successfully.

## Deployment

1. Back up the current website files and database.
2. Upload and extract this ZIP into the intended web root. This archive is flat at its root; do not place the files inside an additional `adminfix/` directory.
3. Preserve the server-only `config.local.php`, database, storage contents and encryption secret. Do not overwrite these with the example config.
4. Confirm the existing `admin_api_encryption_key` / `ANONYMOUX_KEY_ENCRYPTION_SECRET` is set to a stable secret of at least 32 characters. Do not rotate it after encrypted provider keys are stored.
5. Sign in as an administrator and open `admin.php?tab=magichour`.
6. Add the Magic Hour API key, save the settings, test the connection, configure the generation modes confirmed for the account, set the Anonymoux credit price, then enable Lip Sync.
7. Test a short video/audio pair first. Confirm provider status, output playback, download, shared history and credit refund behavior before wider use.

## Official API references

- Lip Sync: https://docs.magichour.ai/api-reference/video-projects/lip-sync
- Generate Asset Upload URLs: https://docs.magichour.ai/api-reference/files/generate-asset-upload-urls
- Get Video Details: https://docs.magichour.ai/api-reference/video-projects/get-video-details
- Get Account Details: https://docs.magichour.ai/api-reference/account/get-account-details
