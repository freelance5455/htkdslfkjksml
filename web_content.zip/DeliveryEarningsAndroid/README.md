# Delivery Earnings — Android project

An offline-first Android WebView app for tracking eFood/Wolt delivery earnings.

## Features
- Daily entries for eFood, Wolt, tips, hours and fuel.
- Monthly dashboard with net after fuel, estimated take-home, net €/hour, estimated take-home €/hour, total hours and fuel costs.
- Monthly business expenses recorded separately by month: EFKA, accountant, scooter maintenance and other business costs.
- Monthly navigation, daily comparison chart, edit/delete entries and CSV export to the Android Downloads folder.
- Dark mobile interface and local browser storage; no server or account required.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `DeliveryEarningsAndroid` directory as a project.
3. Allow Gradle to sync and install the Android SDK/platform required by the project (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create a debug APK under `app/build/outputs/apk/debug/`.

## Data and calculations
- Net after fuel = eFood + Wolt + tips − fuel.
- Estimated take-home = net after fuel − monthly EFKA − accountant − scooter maintenance − other recorded business costs.
- The estimate only subtracts expenses entered by the user; it is not tax/accounting advice and does not automatically calculate income tax or VAT.
- Workday records and monthly expenses are stored locally on the device. Export CSV regularly as a backup.

## Technical notes
- Android application ID: `com.example.deliveryearnings`
- Minimum Android version: Android 10 (API 29)
- JavaScript is used only inside the bundled local HTML UI. The app does not require internet access.
