const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const APP_PASSWORD = process.env.APP_PASSWORD || "YOUSAF726";
const ROOT = __dirname, PUBLIC = path.join(ROOT,"public"), UPLOADS = path.join(ROOT,"uploads"), DB = path.join(ROOT,"data.json");
if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS,{recursive:true});
if (!fs.existsSync(DB)) fs.writeFileSync(DB,JSON.stringify({links:[],photos:[]},null,2));
const readDB=()=>JSON.parse(fs.readFileSync(DB,"utf8"));
const writeDB=d=>fs.writeFileSync(DB,JSON.stringify(d,null,2));
function send(res,status,data,type="application/json"){res.writeHead(status,{"Content-Type":type,"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});res.end(data);}
const json=(res,status,obj)=>send(res,status,JSON.stringify(obj));
function readBody(req){return new Promise((resolve,reject)=>{let s="";req.on("data",c=>{s+=c;if(s.length>18*1024*1024)reject(Error("too large"));});req.on("end",()=>{try{resolve(JSON.parse(s||"{}"));}catch(e){reject(e);}});req.on("error",reject);});}
const authed=req=>req.headers["x-app-password"]===APP_PASSWORD;
const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,`http://${req.headers.host||"localhost"}`);
 try{
  if(req.method==="GET"&&u.pathname==="/")return send(res,200,fs.readFileSync(path.join(PUBLIC,"home.html")),"text/html; charset=utf-8");
  if(req.method==="GET"&&u.pathname==="/app.js")return send(res,200,fs.readFileSync(path.join(PUBLIC,"app.js")),"text/javascript; charset=utf-8");
  if(req.method==="POST"&&u.pathname==="/api/login"){const b=await readBody(req);return json(res,200,{ok:b.password===APP_PASSWORD});}
  if(req.method==="GET"&&u.pathname==="/api/link-valid"){const t=u.searchParams.get("token"),d=readDB();return json(res,200,{valid:!!d.links.find(x=>x.token===t&&x.active)});}
  if(req.method==="POST"&&u.pathname==="/api/create-link"){
   if(!authed(req))return json(res,401,{error:"Password required"});
   const d=readDB(),token=crypto.randomBytes(16).toString("hex");
   d.links.unshift({token,createdAt:new Date().toISOString(),active:true});writeDB(d);return json(res,200,{token});
  }
  if(req.method==="GET"&&u.pathname==="/api/photos"){
   if(!authed(req))return json(res,401,{error:"Password required"});
   const d=readDB();return json(res,200,{photos:d.photos});
  }
  if(req.method==="POST"&&u.pathname==="/api/upload"){
   const b=await readBody(req),d=readDB(),link=d.links.find(x=>x.token===b.token&&x.active);
   if(!link)return json(res,403,{error:"Invalid or inactive link"});
   if(typeof b.image!=="string"||!b.image.startsWith("data:image/jpeg;base64,"))return json(res,400,{error:"Invalid image"});
   const raw=Buffer.from(b.image.split(",")[1],"base64");if(raw.length>2*1024*1024)return json(res,413,{error:"Image too large"});
   const id=crypto.randomBytes(10).toString("hex"),filename=id+".jpg";fs.writeFileSync(path.join(UPLOADS,filename),raw);
   d.photos.unshift({id,token:b.token,filename,createdAt:new Date().toISOString()});writeDB(d);return json(res,200,{ok:true});
  }
  if(req.method==="GET"&&u.pathname.startsWith("/uploads/")){
   const name=path.basename(u.pathname);if(!/^[a-f0-9]+\.jpg$/.test(name))return json(res,404,{error:"Not found"});
   const f=path.join(UPLOADS,name);if(!fs.existsSync(f))return json(res,404,{error:"Not found"});return send(res,200,fs.readFileSync(f),"image/jpeg");
  }
  return json(res,404,{error:"Not found"});
 }catch(e){return json(res,400,{error:"Request failed"});}
});
server.listen(PORT,()=>console.log("Yousaf Professor running on port "+PORT));