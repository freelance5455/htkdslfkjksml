# Yousaf Professor — password-protected mobile web app

The Admin Panel page has been removed. The app opens to a password screen. After unlocking, the owner can generate/share consent links and view/download uploaded photos in the app gallery.

## App password
Default password: `YOUSAF726`

For deployment, set environment variable `APP_PASSWORD` to a private password of your choice. If you do not set it, the default above is used. Do not share the password publicly.

## Run
Requires Node.js 18+:
`APP_PASSWORD='YOUSAF726' node server.js`
Open `http://localhost:3000`.

## Online use
Deploy this folder to a Node.js host with persistent disk and HTTPS. Set `APP_PASSWORD` in the host's environment variables. Keep `data.json` and `uploads/` persistent. Camera access on Android Chrome requires HTTPS (or localhost for local testing).

## Important limitations
This is a starter project, not a compiled APK and not already hosted. The password gate protects app API actions on the server, but use HTTPS and a strong private password. The visitor camera page clearly explains the 10-photo upload and requires the visitor to press Agree & Start and grant browser permission. Add rate limiting, user accounts, data deletion/retention controls, and encrypted storage before production use.
