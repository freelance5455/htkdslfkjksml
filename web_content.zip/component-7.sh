npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Mobile Code Studio" com.example.codestudio --web-dir=dist
npm run build
npx cap add android
npx cap sync
npx cap open android