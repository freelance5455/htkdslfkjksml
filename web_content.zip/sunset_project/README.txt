SUNSET BEACH GESTAO - PROJETO OFFLINE

Arquitetura: HTML/CSS/JavaScript local, sem servidor para a operacao principal.

Arquivo principal: www/index.html
Icone: www/assets/icon.png

Recursos implementados:
- 25 mesas, com nome editavel
- abertura da comanda tocando na mesa
- adicionar, editar quantidade e remover itens
- cadastro de produtos com categoria, preco e foto opcional
- pedidos para entrega
- pagamentos parciais: dinheiro, debito, credito, Pix e transferencia
- transferencia de mesa
- impressao da conta
- backup/restauracao JSON
- dados persistidos em localStorage
- funcionamento sem internet depois de empacotado com os arquivos locais

IMPORTANTE: o APK 1.0 enviado era um WebView que dependia do carregamento de /web/ e por isso apresentou ERR_HTTP_RESPONSE_CODE_FAILURE. Este projeto nao deve apontar para URL externa no carregamento inicial.
