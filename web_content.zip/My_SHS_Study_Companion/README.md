# My SHS Study Companion

A free, offline-friendly Progressive Web App (PWA) for Android and desktop.

## Features
- Weekly timetable with your online class times and light Sunday revision
- Daily checklist and six-hour independent study target
- SHS quizzes for Mathematics, Additional Mathematics, Physics, Chemistry and Biology
- Five-clue NSMQ riddles with your 5 / 4 / 3-point scoring system
- Study-time logging, difficult-topic list and subject performance
- Local progress storage and JSON backup export/import
- App icon, PWA manifest and service worker for offline use after the first online load

## Quick preview
Open `index.html` in a browser. Some install/offline features require HTTPS or localhost.

## Install on Android
1. Put the extracted folder on an HTTPS static host.
2. Open the hosted website in Chrome on your Android phone.
3. Open Chrome's menu (⋮) and choose **Install app** or **Add to Home screen**, if available.
4. Open the installed app while online once so it can cache files for offline use.

## Progress and reminders
- Progress is saved in the current browser on this device; it does not automatically sync between devices.
- Use **Progress → Export progress** to save a JSON backup regularly.
- Daily background notifications are not guaranteed. Set a daily 7:45 AM alarm in your phone's Clock app.

## Packaging note
This is a Progressive Web App package, not a signed APK. Creating an APK requires an additional Android packaging/build step.
