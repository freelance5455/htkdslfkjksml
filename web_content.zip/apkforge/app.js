import { extractZip, openZip, makeZip, safePath, memoryLimit } from './lib/zip.js';
import { parseAxml, manifestInfo, toXml } from './lib/axml.js';

const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const dec = new TextDecoder(), enc = new TextEncoder();
const fmt = n => n > 2 ** 20 ? (n / 2 ** 20).toFixed(2) + ' MB' : (n / 1024).toFixed(1) + ' KB';
const toast = m => { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 3000); };
const TEXT = /\.(html?|css|js|mjs|json|svg|xml|txt|md|webmanifest|csv)$/i;
const MIME = { html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', json: 'application/json', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', mp4: 'video/mp4', mp3: 'audio/mpeg', webm: 'video/webm' };
const mime = p => MIME[p.split('.').pop().toLowerCase()] || 'application/octet-stream';
const download = (blob, name) => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); };

/* ---------- storage (IndexedDB) ---------- */
const idb = new Promise((res, rej) => { const r = indexedDB.open('apkforge', 1); r.onupgradeneeded = () => r.result.createObjectStore('projects', { keyPath: 'id' }); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const tx = async (m, f) => { const d = await idb; return new Promise((res, rej) => { const t = d.transaction('projects', m), r = f(t.objectStore('projects')); t.oncomplete = () => res(r.result); t.onerror = () => rej(t.error); }); };
const saveProject = p => tx('readwrite', s => s.put({ id: p.id, name: p.name, updated: Date.now(), files: [...p.files].map(([k, v]) => [k, v]), orig: [...p.orig].map(([k, v]) => [k, v]), entry: p.entry }));
const listProjects = () => tx('readonly', s => s.getAll());
const delProject = id => tx('readwrite', s => s.delete(id));

/* ---------- state ---------- */
let P = null; // current project {id,name,files:Map,orig:Map,entry}
const history = JSON.parse(localStorage.getItem('af_hist') || '[]');
const logHist = (type, msg) => { history.unshift({ t: Date.now(), type, msg }); localStorage.setItem('af_hist', JSON.stringify(history.slice(0, 200))); };
const newProject = (name, files, entry) => { P = { id: crypto.randomUUID(), name, files: new Map(files), orig: new Map([...files].map(([k, v]) => [k, v.slice()])), entry }; saveProject(P).catch(e => toast('Save failed: ' + e.message)); };
const text = p => dec.decode(P.files.get(p));
const dirty = () => [...P.files].filter(([k, v]) => !P.orig.has(k) || P.orig.get(k).length !== v.length || P.orig.get(k).some((b, i) => b !== v[i])).map(x => x[0]);
const entries = () => [...P.files.keys()].filter(k => /\.html?$/i.test(k));
function detectEntry() {
  const h = entries(); if (!h.length) return { list: [] };
  const root = h.filter(k => /(^|\/)index\.html?$/i.test(k)).sort((a, b) => a.split('/').length - b.split('/').length);
  if (root.length === 1 || (root.length > 1 && root[0].split('/').length < root[1].split('/').length)) return { entry: root[0], list: h };
  return { list: root.length ? root : h };
}

/* ---------- routing ---------- */
const VIEWS = {};
const CARDS = [['zip', 'ZIP to APK', 'Upload & extract website ZIP'], ['html', 'HTML to APK', 'Paste/upload a single HTML'], ['preview', 'Live App Preview', 'Real sandboxed preview'], ['bugs', 'AI Bug Fixer', 'Scanner + optional AI'], ['editor', 'Code Editor', 'Edit project files'], ['api', 'API Manager', 'Gemini/OpenAI/Claude/…'], ['apk', 'Reverse Engineering', 'APK info, manifest, resources'], ['apk', 'APK Analyzer', 'Package, SDK, ABIs'], ['apk', 'APK Security Scanner', 'Static checks'], ['apk', 'Resource Explorer', 'Browse APK files'], ['projects', 'My Projects', 'Saved on this device'], ['build', 'Build APK', 'Generate Android project'], ['build', 'Downloads', 'Export project/ZIP'], ['history', 'Build History', 'Local activity log'], ['settings', 'Settings', 'Storage & environment'], ['admin', 'Admin Dashboard', 'Local stats (no server)']];
function go(v) { location.hash = v; }
function render() {
  const v = location.hash.slice(1) || 'dash'; const fn = VIEWS[v] || VIEWS.dash;
  $('#back').hidden = v === 'dash'; $('#title').textContent = v === 'dash' ? 'APKForge' : (CARDS.find(c => c[0] === v)?.[1] || v);
  $('#proj').textContent = P ? P.name : '';
  const m = $('#view'); m.innerHTML = ''; fn(m);
}
$('#back').onclick = () => go('dash'); addEventListener('hashchange', render);
const needProject = m => { if (P) return false; m.innerHTML = '<p>No project open. <button class="p" onclick="location.hash=\'zip\'">Upload ZIP</button> or <button onclick="location.hash=\'projects\'">Open saved project</button></p>'; return true; };

VIEWS.dash = m => {
  m.innerHTML = '<div class="grid">' + CARDS.map(c => `<button class="card" data-v="${c[0]}"><b>${c[1]}</b><small>${c[2]}</small></button>`).join('') + '</div><p class="muted">Local-first PWA. Nothing is uploaded anywhere unless you use an AI provider or your own build server.</p>';
  m.onclick = e => { const b = e.target.closest('[data-v]'); if (b) go(b.dataset.v); };
};

/* ---------- ZIP upload ---------- */
VIEWS.zip = m => {
  m.innerHTML = `<div class="drop" id="dz"><p>Drop a website ZIP here (or choose it)</p><input type="file" id="f" accept=".zip,application/zip,application/x-zip-compressed"><div class="muted">Limit is resource-based: ~${(memoryLimit() / 2 ** 20) | 0} MB extracted on this device. No fixed upload cap.</div></div><div id="st"></div>`;
  const run = async file => {
    const st = $('#st'); st.innerHTML = `<h2>${esc(file.name)}</h2><div class="muted">${fmt(file.size)}</div><progress id="pg" value="0" max="1"></progress><div id="msg"></div>`;
    try {
      const buf = await file.arrayBuffer(); $('#pg').value = .3;
      const r = await extractZip(buf, { onProgress: (d, t) => $('#pg').value = .3 + .7 * d / t });
      if (!r.files.size) throw new Error('ZIP contains no files');
      let size = 0; r.files.forEach(v => size += v.length);
      newProject(file.name.replace(/\.zip$/i, ''), r.files, null);
      const d = detectEntry(); let entry = d.entry;
      if (!entry && d.list.length > 1) { entry = d.list[0]; P.needPick = d.list; }
      P.entry = entry || null; saveProject(P);
      logHist('zip', `Extracted ${file.name}: ${r.files.size} files`);
      $('#msg').innerHTML = `<p class="ok">Extracted ${r.files.size} files, ${fmt(size)}.</p>` +
        (r.warnings.length ? `<p class="warn">${r.warnings.map(esc).join('<br>')}</p>` : '') +
        (P.entry ? `<p>Entry file: <code>${esc(P.entry)}</code></p>` : '<p class="err">No HTML entry file found. You can still edit files.</p>') +
        (d.list.length > 1 ? `<p>Multiple entry files — choose: <select id="ent">${d.list.map(x => `<option ${x === P.entry ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></p>` : '') +
        `<div class="row"><button class="p" data-g="preview">LIVE PREVIEW</button><button data-g="editor">EDIT PROJECT</button><button data-g="bugs">FIX BUGS</button><button data-g="build">BUILD APK</button><button data-g="projects">OPEN PROJECT</button></div>`;
      const sel = $('#ent'); if (sel) sel.onchange = () => { P.entry = sel.value; saveProject(P); };
      st.onclick = e => e.target.dataset.g && go(e.target.dataset.g);
    } catch (e) { $('#msg').innerHTML = `<p class="err">Failed: ${esc(e.message)}</p><button id="rt">Retry</button>`; $('#rt').onclick = () => run(file); logHist('zip-fail', e.message); }
  };
  $('#f').onchange = e => e.target.files[0] && run(e.target.files[0]);
  const dz = $('#dz'); dz.ondragover = e => { e.preventDefault(); dz.classList.add('on'); }; dz.ondragleave = () => dz.classList.remove('on');
  dz.ondrop = e => { e.preventDefault(); dz.classList.remove('on'); e.dataTransfer.files[0] && run(e.dataTransfer.files[0]); };
};
VIEWS.html = m => {
  m.innerHTML = `<p>Import one HTML file or paste code.</p><input type="file" id="f" accept=".html,.htm,text/html"><textarea class="code" id="t" placeholder="<!doctype html>..."></textarea><div class="row"><button class="p" id="ok">Create project</button></div>`;
  $('#f').onchange = async e => { if (e.target.files[0]) $('#t').value = await e.target.files[0].text(); };
  $('#ok').onclick = () => { const v = $('#t').value.trim(); if (!v) return toast('Empty'); newProject('html-project', [['index.html', enc.encode(v)]], 'index.html'); go('preview'); };
};

/* ---------- preview ---------- */
const resolve = (base, rel) => {
  if (!rel || /^(data:|blob:|https?:|\/\/|#|mailto:|tel:|javascript:)/i.test(rel)) return null;
  rel = decodeURIComponent(rel.split(/[?#]/)[0]); const parts = rel.startsWith('/') ? [] : base.split('/').slice(0, -1);
  for (const s of rel.split('/')) { if (s === '..') parts.pop(); else if (s && s !== '.') parts.push(s); } return parts.join('/');
};
function buildPreview(entry) {
  const urls = new Map(), missing = new Set();
  const url = p => { if (!urls.has(p)) urls.set(p, URL.createObjectURL(new Blob([P.files.get(p)], { type: mime(p) }))); return urls.get(p); };
  const cssFix = (css, base) => css.replace(/url\(\s*(['"]?)([^)'"]+)\1\s*\)/g, (m0, q, r) => { const p = resolve(base, r); if (p === null) return m0; if (!P.files.has(p)) { missing.add(p + ' (from ' + base + ')'); return m0; } return `url("${url(p)}")`; });
  const doc = new DOMParser().parseFromString(text(entry), 'text/html');
  doc.querySelectorAll('[src],[href],[poster]').forEach(el => {
    for (const a of ['src', 'href', 'poster']) {
      if (!el.hasAttribute(a) || (a === 'href' && el.tagName === 'A')) continue;
      const p = resolve(entry, el.getAttribute(a)); if (p === null) continue;
      if (!P.files.has(p)) { missing.add(p + ' (from ' + entry + ')'); continue; }
      if (el.tagName === 'LINK' && /stylesheet/i.test(el.rel)) el.setAttribute(a, URL.createObjectURL(new Blob([cssFix(text(p), p)], { type: 'text/css' })));
      else el.setAttribute(a, url(p));
    }
  });
  doc.querySelectorAll('style').forEach(s => s.textContent = cssFix(s.textContent, entry));
  doc.querySelectorAll('[style]').forEach(s => s.setAttribute('style', cssFix(s.getAttribute('style'), entry)));
  const tf = {}; for (const [k, v] of P.files) if (/\.(json|txt|csv|xml|svg)$/i.test(k) && v.length < 2e6) tf[k] = dec.decode(v);
  const shim = doc.createElement('script');
  shim.textContent = `(()=>{const F=${JSON.stringify(tf).replace(/</g, '\\u003c')},B=${JSON.stringify(entry)};const r=u=>{u=String(u).split(/[?#]/)[0];const p=u.startsWith('/')?[]:B.split('/').slice(0,-1);for(const s of u.split('/')){if(s==='..')p.pop();else if(s&&s!=='.')p.push(s)}return p.join('/')};const of=window.fetch;window.fetch=(u,o)=>{const k=r(u);return k in F?Promise.resolve(new Response(F[k])):of.call(window,u,o)};window.addEventListener('error',e=>parent.postMessage({af:'err',m:e.message,l:e.lineno},'*'))})();`;
  (doc.head || doc.documentElement).prepend(shim);
  return { html: '<!doctype html>' + doc.documentElement.outerHTML, missing: [...missing] };
}
const DEV = { 'Android Phone': [393, 800], 'Small Phone': [320, 568], 'Large Phone': [430, 932], Tablet: [800, 1100], Desktop: [1200, 750], 'WebView (360×640)': [360, 640] };
VIEWS.preview = m => {
  if (needProject(m)) return;
  m.innerHTML = `<div class="row"><select id="dv">${Object.keys(DEV).map(d => `<option>${d}</option>`).join('')}</select><select id="en">${entries().map(e => `<option ${e === P.entry ? 'selected' : ''}>${esc(e)}</option>`).join('')}</select><button id="ro">⟳ Rotate</button><button id="zo">−</button><button id="zi">+</button><button id="rf">Refresh</button><button id="fs">Fullscreen</button></div><div id="rep" class="muted"></div><div class="stage"><div class="dev" id="d"><div class="bar"><span id="clk"></span><span>◉ 5G ▮▮▮▮</span></div><iframe id="fr" sandbox="allow-scripts allow-forms allow-modals"></iframe><div class="nav">◁ ○ □</div></div></div><div id="jserr" class="err"></div>`;
  let land = false, zoom = 1; const errs = [];
  const apply = () => { const [w, h] = DEV[$('#dv').value], W = land ? h : w, H = land ? w : h, fr = $('#fr'); fr.style.height = H + 'px'; $('#d').style.width = W + 16 + 'px'; $('#d').style.transform = `scale(${zoom})`; $('#d').style.marginBottom = (zoom - 1) * H + 'px'; };
  const load = () => { const e = $('#en').value; if (!e) return $('#rep').innerHTML = '<span class="err">No HTML file.</span>'; P.entry = e; const r = buildPreview(e); $('#fr').srcdoc = r.html; errs.length = 0; $('#jserr').textContent = ''; $('#rep').innerHTML = r.missing.length ? `<span class="warn">Missing assets (${r.missing.length}):<br>${r.missing.map(esc).join('<br>')}</span>` : '<span class="ok">All referenced local assets found.</span>'; };
  const onmsg = e => { if (e.data?.af === 'err') { errs.push(e.data.m); $('#jserr') && ($('#jserr').textContent = 'JS errors: ' + errs.join(' | ')); } }; addEventListener('message', onmsg);
  $('#dv').onchange = apply; $('#en').onchange = load; $('#rf').onclick = load; $('#ro').onclick = () => { land = !land; apply(); };
  $('#zi').onclick = () => { zoom = Math.min(2, zoom + .1); apply(); }; $('#zo').onclick = () => { zoom = Math.max(.3, zoom - .1); apply(); };
  $('#fs').onclick = () => $('#d').requestFullscreen?.();
  $('#clk').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); apply(); load();
};

/* ---------- editor ---------- */
let edFile = null;
VIEWS.editor = m => {
  if (needProject(m)) return;
  const files = [...P.files.keys()].filter(k => TEXT.test(k)).sort(); if (!edFile || !P.files.has(edFile)) edFile = files[0];
  m.innerHTML = `<div class="row"><input id="q" placeholder="Search files…" style="flex:1"><input id="sr" placeholder="Search in file"><input id="rp" placeholder="Replace"><button id="rpl">Replace all</button></div><div class="list" id="fl"></div><div class="row"><b id="cur"></b><span id="dirty" class="warn"></span></div><textarea class="code" id="ta" spellcheck="false"></textarea><div class="row"><button class="p" id="sv">Save</button><button id="ud">Undo</button><button id="rd">Redo</button><button id="rs" class="d">Restore original</button><button id="nf">New file</button><button id="rn">Rename</button><button id="dl" class="d">Delete</button><button id="pv">Preview</button></div>`;
  const ta = $('#ta'); let hist = [], hi = -1;
  const list = () => { const q = $('#q').value.toLowerCase(), d = new Set(dirty()); $('#fl').innerHTML = [...P.files.keys()].filter(k => TEXT.test(k) && k.toLowerCase().includes(q)).sort().map(k => `<div data-k="${esc(k)}" class="${k === edFile ? 'sel' : ''}">${esc(k)}${d.has(k) ? ' •' : ''}</div>`).join(''); };
  const open = k => { edFile = k; ta.value = text(k); hist = [ta.value]; hi = 0; $('#cur').textContent = k; $('#dirty').textContent = ''; list(); };
  const push = () => { if (ta.value !== hist[hi]) { hist = hist.slice(0, hi + 1); hist.push(ta.value); hi = hist.length - 1; } };
  $('#fl').onclick = e => e.target.dataset.k && open(e.target.dataset.k); $('#q').oninput = list;
  ta.oninput = () => { $('#dirty').textContent = 'unsaved'; clearTimeout(ta.t); ta.t = setTimeout(push, 500); };
  ta.onkeydown = e => { if (e.key === 'Tab') { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText('  ', s, ta.selectionEnd, 'end'); } else if (e.key === 'Enter') { const s = ta.selectionStart, ln = ta.value.slice(0, s).split('\n').pop(), ind = ln.match(/^\s*/)[0] + (/[{(\[>]$/.test(ln.trim()) && !/<\//.test(ln) ? '  ' : ''); e.preventDefault(); ta.setRangeText('\n' + ind, s, ta.selectionEnd, 'end'); } };
  const save = () => { P.files.set(edFile, enc.encode(ta.value)); saveProject(P); $('#dirty').textContent = ''; list(); toast('Saved'); };
  $('#sv').onclick = save;
  $('#ud').onclick = () => { push(); if (hi > 0) ta.value = hist[--hi]; }; $('#rd').onclick = () => { if (hi < hist.length - 1) ta.value = hist[++hi]; };
  $('#rs').onclick = () => { if (P.orig.has(edFile) && confirm('Restore original version of this file?')) { P.files.set(edFile, P.orig.get(edFile).slice()); open(edFile); saveProject(P); } };
  $('#rpl').onclick = () => { const s = $('#sr').value; if (!s) return; const n = ta.value.split(s).length - 1; push(); ta.value = ta.value.split(s).join($('#rp').value); push(); toast(n + ' replaced (not saved yet)'); };
  $('#nf').onclick = () => { const n = prompt('New file path'); const p = n && safePath(n); if (!p) return; if (P.files.has(p)) return toast('Exists'); P.files.set(p, new Uint8Array()); saveProject(P); open(p); };
  $('#rn').onclick = () => { const n = prompt('New path', edFile), p = n && safePath(n); if (!p || p === edFile || P.files.has(p)) return; P.files.set(p, P.files.get(edFile)); P.files.delete(edFile); if (P.entry === edFile) P.entry = p; saveProject(P); open(p); };
  $('#dl').onclick = () => { if (confirm('Delete ' + edFile + '? (original ZIP data stays in backup)')) { P.files.delete(edFile); saveProject(P); render(); } };
  $('#pv').onclick = () => { save(); go('preview'); };
  if (edFile) open(edFile);
};

/* ---------- bug scanner ---------- */
function scan() {
  const out = [], add = (file, sev, msg, fix) => out.push({ file, sev, msg, fix });
  for (const [k, v] of P.files) {
    if (!TEXT.test(k)) continue; const t = dec.decode(v);
    if (/\.html?$/i.test(k)) {
      const d = new DOMParser().parseFromString(t, 'text/html');
      if (!/<!doctype html/i.test(t)) add(k, 'warn', 'Missing <!DOCTYPE html> (quirks mode)', { type: 'doctype' });
      if (!d.querySelector('meta[name=viewport]')) add(k, 'warn', 'No viewport meta tag — layout will not be mobile-friendly in WebView', { type: 'viewport' });
      d.querySelectorAll('img:not([alt])').length && add(k, 'info', d.querySelectorAll('img:not([alt])').length + ' <img> without alt');
      d.querySelectorAll('[src],[href],[poster]').forEach(el => { for (const a of ['src', 'href', 'poster']) { const p = el.hasAttribute(a) && resolve(k, el.getAttribute(a)); if (p !== null && p !== false && p !== '' && !P.files.has(p) && !(el.tagName === 'A')) add(k, 'error', `Missing file: ${el.getAttribute(a)}`); } });
      if (/http:\/\//i.test(t)) add(k, 'warn', 'Uses http:// URLs — Android blocks cleartext traffic by default on API 28+');
      d.querySelectorAll('script:not([src])').forEach(s => jsCheck(k, s.textContent, add));
    } else if (/\.m?js$/i.test(k)) jsCheck(k, t, add);
    else if (/\.json$/i.test(k)) { try { JSON.parse(t); } catch (e) { add(k, 'error', 'Invalid JSON: ' + e.message); } }
    else if (/\.css$/i.test(k)) { let b = 0; for (const c of t.replace(/\/\*[\s\S]*?\*\//g, '')) { if (c === '{') b++; if (c === '}') b--; } if (b) add(k, 'error', 'Unbalanced braces in CSS (' + b + ')'); }
  }
  return out;
}
function jsCheck(k, code, add) { if (!code.trim() || /^\s*import |export /m.test(code)) return; try { new Function(code); } catch (e) { add(k, 'error', 'JavaScript syntax error: ' + e.message); } } // parse only, never executed
const applyFix = (f) => { const t = text(f.file); let n = t; if (f.fix.type === 'doctype') n = '<!DOCTYPE html>\n' + t; if (f.fix.type === 'viewport') n = /<head[^>]*>/i.test(t) ? t.replace(/<head[^>]*>/i, m => m + '\n<meta name="viewport" content="width=device-width,initial-scale=1">') : t; if (n === t) return false; P.files.set(f.file, enc.encode(n)); return true; };
const apis = () => JSON.parse(localStorage.getItem('af_apis') || '[]');
VIEWS.bugs = m => {
  if (needProject(m)) return;
  const r = scan(); window.__scan = r;
  m.innerHTML = `<p>${r.length ? r.length + ' findings' : '<span class="ok">No issues found by the local scanner.</span>'} <span class="muted">(static checks only; JS is parsed, never run)</span></p><div id="fl">${r.map((f, i) => `<div class="card" style="margin:6px 0"><span class="tag ${f.sev === 'error' ? 'err' : f.sev === 'warn' ? 'warn' : ''}">${f.sev}</span> <code>${esc(f.file)}</code><br>${esc(f.msg)}<div class="row">${f.fix ? `<button data-fix="${i}">Review &amp; apply fix</button>` : ''}<button data-ai="${i}">Ask AI</button></div></div>`).join('')}</div><div class="row"><button id="rs" class="d">Restore all originals</button></div><div id="ai"></div>`;
  m.onclick = async e => {
    const fx = e.target.dataset.fix, ai = e.target.dataset.ai;
    if (fx != null) { const f = r[fx]; if (confirm(`Apply fix to ${f.file}?\n${f.msg}\n\nOriginal is kept; use "Restore originals" to undo.`)) { toast(applyFix(f) ? 'Fixed — backup in originals' : 'Could not apply'); saveProject(P); render(); } }
    if (ai != null) askAI(r[ai]);
    if (e.target.id === 'rs' && confirm('Restore ALL files to their originally uploaded state?')) { P.files = new Map([...P.orig].map(([k, v]) => [k, v.slice()])); saveProject(P); render(); }
  };
};
async function askAI(f) {
  const a = apis().find(x => x.active); const box = $('#ai');
  if (!a) return box.innerHTML = '<p class="warn">No active AI API. Add one under API Manager. The scanner above works without AI.</p>';
  if (!confirm(`This sends the content of ${f.file} and the finding to ${a.url || a.provider}. Continue?`)) return;
  box.innerHTML = '<p>Asking…</p>';
  const prompt = `Fix this issue in ${f.file}: ${f.msg}\nReturn the full corrected file in one fenced code block, then a one-line explanation.\n\n${text(f.file).slice(0, 30000)}`;
  try { const ans = await callAI(a, prompt); box.innerHTML = `<h2>AI suggestion</h2><pre>${esc(ans)}</pre><div class="row"><button id="ap" class="p">Apply code block to ${esc(f.file)}</button></div>`;
    $('#ap').onclick = () => { const mm = ans.match(/```[a-z]*\n([\s\S]*?)```/); if (!mm) return toast('No code block'); if (confirm('Overwrite ' + f.file + ' with the AI code? (Original is backed up.)')) { P.files.set(f.file, enc.encode(mm[1])); saveProject(P); toast('Applied'); render(); } };
  } catch (e) { box.innerHTML = `<p class="err">API error: ${esc(e.message)}</p>`; }
}
async function callAI(a, prompt) {
  let r, j;
  if (a.provider === 'gemini') { r = await fetch(`${a.url || 'https://generativelanguage.googleapis.com/v1beta'}/models/${a.model}:generateContent`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': a.key }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }) }); j = await r.json(); if (!r.ok) throw new Error(j.error?.message || r.status); return j.candidates[0].content.parts.map(p => p.text).join(''); }
  if (a.provider === 'anthropic') { r = await fetch((a.url || 'https://api.anthropic.com') + '/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': a.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: JSON.stringify({ model: a.model, max_tokens: 4096, messages: [{ role: 'user', content: prompt }] }) }); j = await r.json(); if (!r.ok) throw new Error(j.error?.message || r.status); return j.content.map(c => c.text || '').join(''); }
  const base = a.url || { openai: 'https://api.openai.com/v1', deepseek: 'https://api.deepseek.com/v1' }[a.provider]; r = await fetch(base + '/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + a.key }, body: JSON.stringify({ model: a.model, messages: [{ role: 'user', content: prompt }] }) }); j = await r.json(); if (!r.ok) throw new Error(j.error?.message || r.status); return j.choices[0].message.content;
}
VIEWS.api = m => {
  const L = apis(); const save = () => localStorage.setItem('af_apis', JSON.stringify(L));
  m.innerHTML = `<p class="muted">Keys are stored only in this browser's localStorage (not encrypted — the browser has no secure vault). They are never put in generated APKs or logs. Remove them any time. The app works without any API.</p>
  ${L.map((a, i) => `<div class="card" style="margin:6px 0"><b>${esc(a.name)}</b> <span class="tag">${a.provider}</span> <span class="tag">${esc(a.model)}</span> ${a.active ? '<span class="ok">active</span>' : ''}<div class="row"><button data-t="${i}">Test</button><button data-a="${i}">${a.active ? 'Deactivate' : 'Activate'}</button><button data-d="${i}" class="d">Delete</button></div></div>`).join('')}
  <h2>Add API</h2><div class="row"><input id="n" placeholder="Name"><select id="pv"><option value="gemini">Google Gemini</option><option value="openai">OpenAI</option><option value="anthropic">Anthropic Claude</option><option value="deepseek">DeepSeek</option><option value="custom">OpenAI-compatible / custom URL</option></select><input id="md" placeholder="Model (e.g. gemini-2.0-flash)"><input id="u" placeholder="Custom base URL (optional)"><input id="k" type="password" placeholder="API key"><button class="p" id="ad">Add</button></div><div id="r"></div>`;
  m.onclick = async e => { const d = e.target.dataset;
    if (d.d != null && confirm('Delete this API and its key?')) { L.splice(d.d, 1); save(); render(); }
    if (d.a != null) { const on = !L[d.a].active; L.forEach(x => x.active = false); L[d.a].active = on; save(); render(); }
    if (d.t != null) { $('#r').textContent = 'Testing…'; try { $('#r').innerHTML = '<span class="ok">OK: ' + esc((await callAI(L[d.t], 'Reply with the single word: ok')).slice(0, 60)) + '</span>'; } catch (x) { $('#r').innerHTML = '<span class="err">Failed: ' + esc(x.message) + '</span>'; } }
    if (e.target.id === 'ad') { if (!$('#k').value || !$('#md').value) return toast('Model and key required'); L.push({ name: $('#n').value || $('#pv').value, provider: $('#pv').value, model: $('#md').value, url: $('#u').value.replace(/\/$/, ''), key: $('#k').value, active: !L.some(x => x.active) }); save(); render(); } };
};

/* ---------- APK analyzer ---------- */
const DANGER = { 'READ_SMS': 'SMS', 'SEND_SMS': 'SMS', 'RECEIVE_SMS': 'SMS', 'CAMERA': 'Camera', 'RECORD_AUDIO': 'Microphone', 'ACCESS_FINE_LOCATION': 'Location', 'ACCESS_COARSE_LOCATION': 'Location', 'ACCESS_BACKGROUND_LOCATION': 'Location', 'READ_CONTACTS': 'Contacts', 'WRITE_CONTACTS': 'Contacts', 'READ_PHONE_STATE': 'Phone', 'CALL_PHONE': 'Phone', 'READ_CALL_LOG': 'Phone', 'READ_EXTERNAL_STORAGE': 'Storage', 'WRITE_EXTERNAL_STORAGE': 'Storage', 'MANAGE_EXTERNAL_STORAGE': 'Storage', 'POST_NOTIFICATIONS': 'Notifications', 'BLUETOOTH_CONNECT': 'Bluetooth', 'BLUETOOTH_SCAN': 'Bluetooth', 'INTERNET': 'Internet', 'FOREGROUND_SERVICE': 'Background', 'SYSTEM_ALERT_WINDOW': 'Other', 'REQUEST_INSTALL_PACKAGES': 'Other' };
const HIGH = new Set(['READ_SMS', 'SEND_SMS', 'RECEIVE_SMS', 'READ_CALL_LOG', 'MANAGE_EXTERNAL_STORAGE', 'SYSTEM_ALERT_WINDOW', 'REQUEST_INSTALL_PACKAGES', 'ACCESS_BACKGROUND_LOCATION']);
const SECRETS = [[/AIza[0-9A-Za-z_\-]{35}/g, 'Google API key'], [/AKIA[0-9A-Z]{16}/g, 'AWS access key id'], [/-----BEGIN [A-Z ]*PRIVATE KEY-----/g, 'Private key'], [/\b(?:sk|pk)_(?:live|test)_[0-9a-zA-Z]{16,}/g, 'Payment API key']];
async function analyzeApk(buf, name) {
  const z = await openZip(buf), R = { name, size: buf.byteLength, entries: z.entries.filter(e => !e.dir), warnings: [], z };
  const mf = z.entries.find(e => e.name === 'AndroidManifest.xml');
  if (mf) { try { R.manifestEl = parseAxml(await z.read(mf)); R.info = manifestInfo(R.manifestEl); } catch (e) { R.warnings.push('Manifest parse failed: ' + e.message); } } else R.warnings.push('No AndroidManifest.xml at archive root (this may be a split/bundle container — see nested files).');
  R.dex = []; for (const e of R.entries.filter(e => /^classes\d*\.dex$/.test(e.name))) { const d = await z.read(e), dv = new DataView(d.buffer); R.dex.push({ name: e.name, size: e.usize, classes: dv.getUint32(0x60, true), methods: dv.getUint32(0x58, true) }); }
  R.libs = []; for (const e of R.entries.filter(e => /^lib\/[^/]+\/.+\.so$/.test(e.name))) { const d = await z.read(e), dv = new DataView(d.buffer); const mach = dv.getUint16(18, true); R.libs.push({ path: e.name, abi: e.name.split('/')[1], size: e.usize, elf: d[0] === 0x7f && d[1] === 0x45 ? ({ 3: 'x86', 40: 'ARM', 62: 'x86-64', 183: 'AArch64' }[mach] || 'machine ' + mach) : 'not ELF' }); }
  R.sig = R.entries.filter(e => /^META-INF\/.+\.(RSA|DSA|EC|SF)$/i.test(e.name)).map(e => e.name);
  R.secrets = []; for (const e of R.entries) if (/\.(json|xml|txt|js|html|properties|cfg|ini)$/i.test(e.name) && e.usize < 3e6 && !/^AndroidManifest/.test(e.name)) { try { const t = dec.decode(await z.read(e)); for (const [re, label] of SECRETS) for (const mm of t.matchAll(re)) R.secrets.push({ file: e.name, label, redacted: mm[0].slice(0, 4) + '…[REDACTED]' }); } catch { } }
  R.findings = []; const f = (sev, msg) => R.findings.push({ sev, msg });
  if (R.info) { const a = R.info.app; if (a.debuggable === true) f('high', 'android:debuggable=true'); if (a.usesCleartextTraffic === true) f('medium', 'usesCleartextTraffic=true'); if (a.allowBackup !== false) f('low', 'allowBackup is not disabled'); [...R.info.activities, ...R.info.services, ...R.info.receivers, ...R.info.providers].filter(c => c.exported === true).forEach(c => f('info', 'Exported component: ' + c.name)); R.info.permissions.filter(p => HIGH.has(p.split('.').pop())).forEach(p => f('medium', 'Sensitive permission requested: ' + p)); if (+R.info.targetSdk < 29) f('medium', 'targetSdk ' + R.info.targetSdk + ' is old'); }
  if (!R.sig.length) f('medium', 'No v1 (META-INF) signature found. v2/v3 scheme blocks are not parsed by this tool — use apksigner verify.');
  R.secrets.forEach(s => f('medium', `Possible ${s.label} in ${s.file}: ${s.redacted}`));
  R.warnings.push('Static findings are indicators, not proof of a vulnerability. Decompiled code (JADX), Smali (Apktool) and Ghidra require desktop tools — see docs/SETUP.md.');
  return R;
}
let APKS = [], apkTab = 'Info';
VIEWS.apk = m => {
  const TABS = ['Upload', 'Info', 'Manifest', 'Permissions', 'Resources', 'Code', 'Native', 'Strings', 'Security', 'Compare', 'History'];
  const R = APKS[0];
  m.innerHTML = `<div class="tabs">${TABS.map(t => `<button class="${t === apkTab ? 'on' : ''}" data-tab="${t}">${t}</button>`).join('')}</div><div id="tb"></div><p class="muted">For apps you own or are authorized to analyze. Uploaded files are only read as data, never run.</p>`;
  m.onclick = e => { if (e.target.dataset.tab) { apkTab = e.target.dataset.tab; render(); } };
  const tb = $('#tb'), need = () => { if (R) return false; tb.innerHTML = '<p>Upload an APK first.</p>'; return true; };
  const tbl = rows => '<table>' + rows.map(r => `<tr><th>${esc(r[0])}</th><td>${esc(r[1])}</td></tr>`).join('') + '</table>';
  if (apkTab === 'Upload') {
    tb.innerHTML = '<input type="file" id="f" accept=".apk,.apks,.xapk,.aab,.zip"><div id="s"></div>';
    $('#f').onchange = async e => { const file = e.target.files[0]; if (!file) return; $('#s').textContent = 'Analyzing…'; try { const R2 = await analyzeApk(await file.arrayBuffer(), file.name); APKS.unshift(R2); APKS = APKS.slice(0, 2); logHist('apk', file.name); apkTab = 'Info'; render(); } catch (x) { $('#s').innerHTML = `<span class="err">${esc(x.message)}</span>`; } };
    return;
  }
  if (apkTab === 'Compare') {
    if (APKS.length < 2) return tb.innerHTML = '<p>Upload two APKs (the second upload becomes "new", previous becomes "old") to compare.</p>';
    const [n, o] = APKS, setd = (a, b) => ({ add: a.filter(x => !b.includes(x)), rem: b.filter(x => !a.includes(x)) });
    const pp = setd(n.info?.permissions || [], o.info?.permissions || []), ff = setd(n.entries.map(e => e.name), o.entries.map(e => e.name));
    tb.innerHTML = tbl([['Old', `${o.name} v${o.info?.versionName} (${o.info?.versionCode})`], ['New', `${n.name} v${n.info?.versionName} (${n.info?.versionCode})`], ['Package same', String(n.info?.package === o.info?.package)], ['Permissions added', pp.add.join(', ') || '—'], ['Permissions removed', pp.rem.join(', ') || '—'], ['Files added', ff.add.length + (ff.add.length ? ': ' + ff.add.slice(0, 40).join(', ') : '')], ['Files removed', ff.rem.length + (ff.rem.length ? ': ' + ff.rem.slice(0, 40).join(', ') : '')], ['DEX classes', `${o.dex.map(d => d.classes).join('+')} → ${n.dex.map(d => d.classes).join('+')}`]]) + '<div class="row"><button id="ex">Export JSON</button></div>';
    $('#ex').onclick = () => download(new Blob([JSON.stringify({ old: o.name, new: n.name, permissions: pp, files: ff }, null, 1)]), 'comparison.json'); return;
  }
  if (apkTab === 'History') return tb.innerHTML = history.filter(h => h.type === 'apk').map(h => `<div>${new Date(h.t).toLocaleString()} — ${esc(h.msg)}</div>`).join('') || '<p>No analyses yet.</p>';
  if (need()) return; const I = R.info;
  if (apkTab === 'Info') tb.innerHTML = tbl([['File', `${R.name} (${fmt(R.size)})`], ['Package', I?.package], ['Version', `${I?.versionName} (${I?.versionCode})`], ['Min / Target / Compile SDK', `${I?.minSdk} / ${I?.targetSdk} / ${I?.compileSdk ?? 'n/a'}`], ['Label', I?.app.label], ['Theme', I?.app.theme], ['ABIs', [...new Set(R.libs.map(l => l.abi))].join(', ') || 'none (no native libs)'], ['DEX files', R.dex.map(d => `${d.name}: ${d.classes} classes`).join('; ') || '—'], ['Signature files', R.sig.join(', ') || 'none (v1)'], ['Entries', R.entries.length]]) + R.warnings.map(w => `<p class="warn">${esc(w)}</p>`).join('') + '<div class="row"><button id="ex">Export JSON report</button></div>';
  if (apkTab === 'Info') $('#ex').onclick = () => { const { z, manifestEl, entries, ...rest } = R; download(new Blob([JSON.stringify(rest, null, 1)]), R.name + '-report.json'); };
  if (apkTab === 'Manifest') { tb.innerHTML = R.manifestEl ? `<div class="row"><button id="ex">Export XML</button></div><pre>${esc(toXml(R.manifestEl))}</pre><h2>Components</h2>` + ['activities', 'services', 'receivers', 'providers'].map(k => `<b>${k} (${I[k].length})</b><pre>${esc(I[k].map(c => c.name + '  exported=' + c.exported).join('\n'))}</pre>`).join('') + `<b>Deep links</b><pre>${esc(I.deepLinks.join('\n') || '—')}</pre>` : '<p>No manifest.</p>'; $('#ex')?.addEventListener('click', () => download(new Blob([toXml(R.manifestEl)]), 'AndroidManifest.xml')); }
  if (apkTab === 'Permissions') tb.innerHTML = '<table><tr><th>Permission</th><th>Category</th><th>Risk</th></tr>' + (I?.permissions || []).map(p => { const s = p.split('.').pop(); return `<tr><td>${esc(p)}</td><td>${DANGER[s] || 'Other'}</td><td class="${HIGH.has(s) ? 'err' : ''}">${HIGH.has(s) ? 'High-sensitivity' : DANGER[s] ? 'Normal/dangerous' : 'Low/unknown'}</td></tr>`; }).join('') + '</table><p class="muted">A permission being requested does not prove the app misuses it.</p>';
  if (apkTab === 'Resources') {
    tb.innerHTML = '<input id="q" placeholder="Search files" style="width:100%"><div class="list" id="l"></div><div id="pv"></div>';
    const l = () => { const q = $('#q').value.toLowerCase(); $('#l').innerHTML = R.entries.filter(e => e.name.toLowerCase().includes(q)).slice(0, 500).map(e => `<div data-n="${esc(e.name)}">${esc(e.name)} <span class="muted">${fmt(e.usize)}</span></div>`).join(''); }; l(); $('#q').oninput = l;
    $('#l').onclick = async e => { const n = e.target.closest('[data-n]')?.dataset.n; if (!n) return; const en = R.entries.find(x => x.name === n), d = await R.z.read(en); const pv = $('#pv'); if (/\.(png|jpe?g|gif|webp|svg)$/i.test(n)) pv.innerHTML = `<img style="max-width:100%;background:#fff" src="${URL.createObjectURL(new Blob([d], { type: mime(n) }))}">`; else if (TEXT.test(n)) pv.innerHTML = `<pre>${esc(dec.decode(d).slice(0, 200000))}</pre>`; else pv.innerHTML = `<p class="muted">Binary (${fmt(d.length)}). Binary XML resources (res/*.xml, resources.arsc) need Apktool to decode.</p>`; pv.innerHTML += `<div class="row"><button id="xp">Export file</button></div>`; $('#xp').onclick = () => download(new Blob([d]), n.split('/').pop()); };
  }
  if (apkTab === 'Code') tb.innerHTML = `<p class="warn">Decompiling (JADX) and Smali (Apktool) can't run inside a browser. Not supported here.</p><p>DEX summary:</p>${tbl(R.dex.map(d => [d.name, `${d.classes} classes, ${d.methods} method refs, ${fmt(d.size)}`]))}<p>Run locally:</p><pre>jadx -d out_java app.apk\napktool d app.apk -o out_smali</pre><p class="muted">Decompiled output is an approximation; obfuscation prevents exact recovery.</p>`;
  if (apkTab === 'Native') tb.innerHTML = R.libs.length ? '<table><tr><th>Library</th><th>ABI</th><th>ELF</th><th>Size</th></tr>' + R.libs.map(l => `<tr><td>${esc(l.path)}</td><td>${l.abi}</td><td>${l.elf}</td><td>${fmt(l.size)}</td></tr>`).join('') + '</table><p class="muted">Symbol/Ghidra analysis is not available in-browser.</p>' : '<p>No native libraries.</p>';
  if (apkTab === 'Strings') tb.innerHTML = `<p>Credential-like strings (values redacted, never sent anywhere):</p><pre>${esc(R.secrets.map(s => `${s.label}  ${s.file}  ${s.redacted}`).join('\n') || 'none found in text resources')}</pre><p>Public URLs in manifest/deep links:</p><pre>${esc((I?.deepLinks || []).join('\n') || '—')}</pre><p class="muted">String resources inside resources.arsc need Apktool.</p>`;
  if (apkTab === 'Security') tb.innerHTML = (R.findings.length ? '<table><tr><th>Severity</th><th>Finding</th></tr>' + R.findings.map(x => `<tr><td class="${x.sev === 'high' ? 'err' : x.sev === 'medium' ? 'warn' : ''}">${x.sev}</td><td>${esc(x.msg)}</td></tr>`).join('') + '</table>' : '<p class="ok">No indicators found.</p>') + '<p class="muted">Static indicators only; not proof of exploitability. MobSF (self-hosted) gives deeper analysis.</p>';
};

/* ---------- build: Android WebView project ---------- */
VIEWS.build = m => {
  if (needProject(m)) return;
  const pk = 'com.example.' + P.name.toLowerCase().replace(/[^a-z0-9]/g, '').replace(/^\d+/, 'app') || 'app';
  m.innerHTML = `<p>Generates a real Android Studio/Gradle project that loads your site from <code>assets/www</code> in a WebView. Compiling needs JDK 17 + Android SDK (see docs/SETUP.md); this browser cannot run Gradle.</p><div class="row"><input id="an" value="${esc(P.name)}" placeholder="App name"><input id="pk" value="${pk}" placeholder="Package"><input id="vn" value="1.0" style="width:80px"><input id="vc" type="number" value="1" style="width:80px"></div><div class="row"><label><input type="checkbox" id="fsc"> Fullscreen</label><select id="or"><option value="unspecified">Auto</option><option>portrait</option><option>landscape</option></select><label>Status bar <input type="color" id="sb" value="#0f1419"></label><label><input type="checkbox" id="net" checked> Internet permission</label></div><div class="row"><button class="p" id="g">Download Android project ZIP</button><button id="ez">Export website ZIP</button><button id="env">Check this device</button></div><pre id="o"></pre><h2>Self-hosted build server</h2><p class="muted">Not implemented in this release (interface only: POST project ZIP → job id → poll → download APK). Documented in docs/SETUP.md.</p>`;
  $('#g').onclick = () => { const v = id => $(id).value, pkg = v('#pk'); if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg)) return toast('Invalid package name'); const F = []; const pp = pkg.replace(/\./g, '/');
    F.push({ path: 'settings.gradle', data: `rootProject.name='${v('#an').replace(/'/g, '')}'\ninclude ':app'\n` }, { path: 'build.gradle', data: `plugins { id 'com.android.application' version '8.5.2' apply false }\n` }, { path: 'gradle.properties', data: 'android.useAndroidX=true\norg.gradle.jvmargs=-Xmx1536m\n' },
      { path: 'app/build.gradle', data: `plugins { id 'com.android.application' }\nandroid {\n  namespace '${pkg}'\n  compileSdk 34\n  defaultConfig { applicationId '${pkg}'; minSdk 24; targetSdk 34; versionCode ${+v('#vc') || 1}; versionName '${v('#vn')}' }\n  buildTypes { release { minifyEnabled false } }\n  compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }\n}\ndependencies { implementation 'androidx.webkit:webkit:1.11.0' }\n` },
      { path: 'app/src/main/AndroidManifest.xml', data: `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n${$('#net').checked ? '  <uses-permission android:name="android.permission.INTERNET"/>\n' : ''}  <application android:label="${esc(v('#an'))}" android:icon="@mipmap/ic_launcher" android:usesCleartextTraffic="false">\n    <activity android:name=".MainActivity" android:exported="true" android:screenOrientation="${v('#or')}" android:configChanges="orientation|screenSize|keyboardHidden">\n      <intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>\n    </activity>\n  </application>\n</manifest>\n` },
      { path: `app/src/main/java/${pp}/MainActivity.java`, data: `package ${pkg};\nimport android.app.Activity;import android.graphics.Color;import android.os.Bundle;import android.view.*;import android.webkit.*;\npublic class MainActivity extends Activity {\n  WebView w;\n  @Override protected void onCreate(Bundle b){ super.onCreate(b);\n    ${$('#fsc').checked ? 'getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);' : ''}\n    getWindow().setStatusBarColor(Color.parseColor("${v('#sb')}"));\n    w = new WebView(this); setContentView(w);\n    WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(false);\n    w.setWebViewClient(new WebViewClient());\n    w.loadUrl("https://appassets.androidplatform.net/assets/www/${P.entry || 'index.html'}"); }\n  @Override public void onBackPressed(){ if (w.canGoBack()) w.goBack(); else super.onBackPressed(); }\n}\n` });
    // NOTE: appassets URL requires WebViewAssetLoader; wire it up:
    F[4].data = F[4].data.replace('w.setWebViewClient(new WebViewClient());', 'final androidx.webkit.WebViewAssetLoader L = new androidx.webkit.WebViewAssetLoader.Builder().addPathHandler("/assets/", new androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this)).build();\n    w.setWebViewClient(new WebViewClient(){ @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return L.shouldInterceptRequest(r.getUrl()); } });');
    for (const [k, d] of P.files) F.push({ path: 'app/src/main/assets/www/' + k, data: d });
    F.push({ path: 'README.txt', data: 'Build:\n  gradle wrapper --gradle-version 8.7\n  ./gradlew assembleDebug\nAPK: app/build/outputs/apk/debug/app-debug.apk\nAdd your launcher icons under app/src/main/res/mipmap-*/ic_launcher.png before building (or remove the android:icon attribute).\nRelease signing: use your own keystore with apksigner; keep it safe — losing it blocks future updates.\n' });
    download(makeZip(F), v('#an') + '-android-project.zip'); logHist('build', 'Project generated: ' + pkg); toast('Project ZIP created');
  };
  $('#ez').onclick = () => download(makeZip([...P.files].map(([path, data]) => ({ path, data }))), P.name + '.zip');
  $('#env').onclick = async () => { const e = await navigator.storage?.estimate?.(); $('#o').textContent = `Browser mode.\nDevice memory: ${navigator.deviceMemory ?? 'unknown'} GB\nStorage: ${e ? fmt(e.usage) + ' used of ~' + fmt(e.quota) : 'unknown'}\nJava/Gradle/Android SDK: cannot be detected from a browser. On Termux run: java -version; gradle -v; echo $ANDROID_HOME`; };
};

/* ---------- projects / history / settings / admin ---------- */
VIEWS.projects = async m => {
  const L = await listProjects(); m.innerHTML = (L.length ? '' : '<p>No saved projects.</p>') + L.map(p => `<div class="card" style="margin:6px 0"><b>${esc(p.name)}</b> <span class="muted">${p.files.length} files · ${new Date(p.updated).toLocaleString()}</span><div class="row"><button data-o="${p.id}" class="p">Open</button><button data-dup="${p.id}">Duplicate</button><button data-rn="${p.id}">Rename</button><button data-ex="${p.id}">Export ZIP</button><button data-del="${p.id}" class="d">Delete</button></div></div>`).join('');
  m.onclick = async e => { const d = e.target.dataset, p = L.find(x => x.id === (d.o || d.dup || d.rn || d.ex || d.del)); if (!p) return;
    if (d.o) { P = { id: p.id, name: p.name, files: new Map(p.files), orig: new Map(p.orig), entry: p.entry }; go('editor'); }
    if (d.dup) { await saveProject({ ...p, id: crypto.randomUUID(), name: p.name + ' copy', files: new Map(p.files), orig: new Map(p.orig) }); render(); }
    if (d.rn) { const n = prompt('Name', p.name); if (n) { p.name = n; await tx('readwrite', s => s.put(p)); if (P?.id === p.id) P.name = n; render(); } }
    if (d.ex) download(makeZip(p.files.map(([path, data]) => ({ path, data }))), p.name + '.zip');
    if (d.del && confirm('Delete project "' + p.name + '" from this device?')) { await delProject(p.id); if (P?.id === p.id) P = null; render(); } };
};
VIEWS.history = m => { m.innerHTML = history.map(h => `<div>${new Date(h.t).toLocaleString()} · <span class="tag">${h.type}</span> ${esc(h.msg)}</div>`).join('') || '<p>No activity yet.</p>'; };
VIEWS.settings = async m => { const e = await navigator.storage?.estimate?.(); m.innerHTML = `<p>Storage: ${e ? fmt(e.usage) + ' / ~' + fmt(e.quota) : 'unknown'}</p><p>Extraction safety limit: ${(memoryLimit() / 2 ** 20) | 0} MB (from device memory)</p><div class="row"><button id="pst">Request persistent storage</button><button id="cl" class="d">Clear activity log</button></div><p class="muted">Native builds/decompilation need desktop tools — see docs/SETUP.md. Features that can't run in a browser say so instead of faking results.</p>`; $('#pst').onclick = async () => toast(await navigator.storage?.persist?.() ? 'Persistent' : 'Not granted'); $('#cl').onclick = () => { localStorage.removeItem('af_hist'); history.length = 0; render(); }; };
VIEWS.admin = async m => { const L = await listProjects(); m.innerHTML = `<p class="warn">Local-only stats. There is no multi-user server in this release, so no user management or admin authentication exists (nothing fake is shown).</p>${'<table>' + [['Projects', L.length], ['Builds generated', history.filter(h => h.type === 'build').length], ['APK analyses', history.filter(h => h.type === 'apk').length], ['ZIP failures', history.filter(h => h.type === 'zip-fail').length], ['AI APIs configured', apis().length]].map(r => `<tr><th>${r[0]}</th><td>${r[1]}</td></tr>`).join('') + '</table>'}`; };

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => { });
render();
