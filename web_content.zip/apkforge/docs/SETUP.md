# Setup
## Build the generated project (desktop or Termux)
1. JDK 17, Android SDK (platform 34, build-tools), Gradle 8.7.
2. Unzip the downloaded `*-android-project.zip`, add launcher icons, run `gradle wrapper && ./gradlew assembleDebug`.
3. Sign release builds with your own keystore: `apksigner sign --ks my.jks app-release.apk`. Never lose the key; updates require the same key. Rebuilding changes an APK's signature.
## Reverse engineering (authorized apps only)
`jadx -d out app.apk` · `apktool d app.apk` · `bundletool` for AAB/APKS · MobSF via Docker · Ghidra for .so files.
## Planned build-server API (not implemented)
POST /jobs (project ZIP) -> {id}; GET /jobs/{id} -> status+log; DELETE /jobs/{id}; GET /jobs/{id}/apk. Use HTTPS + token auth.
## AI keys
Stored in browser localStorage only (unencrypted). Remove under API Manager. Never embedded in APKs.
