# APKForge (compact edition)
Dependency-free, local-first PWA. Open `index.html` through any static server (e.g. `python3 -m http.server`) — needed for the service worker/IndexedDB — then add to Home screen on Android.

## What works (implemented)
ZIP upload/validation/secure extraction (Zip Slip, bomb check, duplicates, unicode, password/corrupt detection), entry detection + picker, live sandboxed preview (device frames, rotate, zoom, missing-asset report), code editor (search/replace/undo/restore), local bug scanner + optional AI fixer (user approval, originals kept), AI API manager, Android WebView Gradle project generator, project manager (IndexedDB), APK analyzer (manifest, permissions, resources, DEX/native summary, static security indicators with secret redaction, two-APK compare, JSON export).

## Not supported in-browser (honest limits)
Compiling/signing APKs (needs JDK+Android SDK), JADX/Smali/Ghidra/MobSF, dynamic analysis, self-hosted build server, multi-user admin. See docs/SETUP.md.

## Test status (spec §18)
Tested in Node only: ZIP read/extract, Zip Slip block, duplicate rename, corrupt + fake ZIP detection, ZIP writer round-trip -> PASS.
NOT yet tested on a real device/browser: preview, editor, AI APIs, project generation, APK analysis (AXML parser untested against a real APK) -> UNTESTED (not PASS).
APK build/signing/install, decompile, smali, Ghidra -> NOT SUPPORTED here.
