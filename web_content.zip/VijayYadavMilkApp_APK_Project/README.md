# Vijay Dairy Android App

Android Studio project for the Vijay Dairy milk-record app.

- App name: Vijay Dairy
- Package: com.vijay.dairy
- Portrait layout
- WebView wrapper around the included daily milk-record app
- LocalStorage enabled so member/date records can persist on the device
- Custom Vijay Dairy cow/milk app icon included

## Build APK
Open this folder in Android Studio, let Gradle sync, then use:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The generated debug APK will normally be under app/build/outputs/apk/debug/.
