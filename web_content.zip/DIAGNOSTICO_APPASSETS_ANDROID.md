RUNNER SHOT GUN — v1.31.02 — DELTA

HTML validado diretamente no Chromium antes da atualização do pacote-fonte.
A versão do jogo foi atualizada para 1.31.02; a etapa continua Delta.

CORREÇÃO DO appassets.androidplatform.net
- O HTML principal está em app/src/main/assets/index.html.
- MainActivity usa androidx.webkit.WebViewAssetLoader com o handler /assets/.
- A URL https://appassets.androidplatform.net/assets/index.html é uma URL virtual servida localmente pelo WebViewAssetLoader; não deve ser carregada com um WebViewClient padrão sem interceptação.
- A dependência androidx.webkit:webkit:1.14.0 foi adicionada.
- DOM Storage e JavaScript permanecem habilitados para o jogo e a conta online.
- Acesso genérico file:// foi desabilitado, pois o jogo usa a origem HTTPS virtual do asset loader.
- O Manifest mantém orientação horizontal e versionCode 3102 / versionName 1.31.02.

ARQUIVOS HTML
- app/src/main/assets/index.html: asset usado pelo APK nativo.
- index.html, web/index.html e assets/web/index.html: cópias para importação/compatibilidade com ferramentas que esperam esses caminhos.
- Todos são cópias idênticas do HTML testado.

TESTES HTML EXECUTADOS
- 5 scripts JavaScript passaram em node --check.
- Sem IDs HTML duplicados.
- Menu, seleção de fase, início da fase 1, movimento, tiro, menus de Habilidades/Armas/Amigos/Platina/Conta passaram no teste automatizado do Chromium.
- Fase de Platina 10 abriu sem erro de JavaScript.
- Canhão de Plasma e disparo enquanto o botão fica pressionado foram exercitados sem erro de JavaScript.
- Layout paisagem 800×360 passou sem erro de JavaScript.
- Não houve requisições externas falhadas durante esses testes locais; o login real e as chamadas Supabase dependem de rede/conta.

LIMITAÇÃO
Este ZIP é projeto-fonte, não APK compilado. O ambiente de trabalho não tem Gradle nem Android SDK configurados; portanto não foi possível compilar, instalar ou validar o WebViewAssetLoader em aparelho Android real nesta etapa. A correção do caminho/interceptação foi aplicada ao projeto-fonte, mas a confirmação final exige build e teste no dispositivo.
