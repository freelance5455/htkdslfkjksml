# SMART MONEY — versão corrigida 0.3

## Abrir a versão web no telemóvel
1. Extraia o ZIP.
2. Entre na pasta `SmartMoney`.
3. Abra o ficheiro `index.html` com Chrome ou outro navegador.
4. Os registos ficam guardados no armazenamento local do navegador (localStorage).

Se o gestor de ficheiros não permitir abrir o HTML diretamente, extraia primeiro o ZIP e escolha Chrome em «Abrir com».

## Projeto Android nativo
A pasta contém também o projeto Android Studio original. Abra a pasta `SmartMoney` no Android Studio, com JDK 17 e Android SDK 35.

## O que foi corrigido/acrescentado
- Incluído `index.html` funcional e adaptado a telemóveis.
- Dashboard, receitas, despesas, histórico, poupanças, negócios e relatórios.
- Dados da versão web guardados localmente no navegador.

## Limitações importantes
É um protótipo de gestão pessoal. Não movimenta dinheiro real, não está ligado a bancos e os dados do navegador podem ser apagados se os dados do site forem limpos. Faça cópias de segurança dos seus registos.
