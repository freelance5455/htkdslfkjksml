package ao.smartmoney.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var db: DatabaseHelper
    private lateinit var page: LinearLayout
    private val navy = 0xFF101C32.toInt()
    private val gold = 0xFFD6AD55.toInt()
    private val pale = 0xFFF3F5F8.toInt()
    private val ink = 0xFF17243A.toInt()
    private val muted = 0xFF657187.toInt()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db = DatabaseHelper(this); showIndex() }

    private fun base(title: String, subtitle: String? = null) {
        val scroll = ScrollView(this).apply { setBackgroundColor(pale) }
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,26) }
        scroll.addView(page); setContentView(scroll)
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,20,20,20); setBackgroundColor(navy) }
        header.addView(label(title,23f,gold,true))
        if (subtitle != null) header.addView(label(subtitle,12f,-1))
        page.addView(header, match())
        if (title != "SMART MONEY") page.addView(Button(this).apply {
            text = "← INDEX PRINCIPAL"; setTextColor(navy); setOnClickListener { showIndex() }
        }, match())
    }

    private fun showIndex() {
        base("SMART MONEY","O teu dinheiro. As tuas decisões. O teu futuro.")
        val all = db.totals(); val personal = db.totals("PESSOAL"); val business = db.totals("NEGOCIO")
        val card = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18); setBackgroundColor(navy) }
        card.addView(label("SALDO TOTAL REGISTADO",12f,0xFFD5DCE7.toInt()))
        card.addView(label(formatMoney(all.first-all.second),29f,gold,true))
        card.addView(label("Receitas ${formatMoney(all.first)}  •  Despesas ${formatMoney(all.second)}",12f,-1))
        page.addView(card,match().apply { topMargin=14 })
        section("RESUMO")
        val summary = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        summary.addView(metric("PESSOAL",personal.first-personal.second),weight())
        summary.addView(metric("NEGÓCIOS",business.first-business.second),weight())
        page.addView(summary)
        section("INDEX PRINCIPAL")
        val menu = listOf(
            "Dashboard" to { showDashboard() }, "Minhas contas" to { showAccounts() },
            "Receitas" to { showMovements("RECEITA") }, "Despesas" to { showMovements("DESPESA") },
            "Poupanças" to { showSavings() }, "Negócios" to { showBusinesses() },
            "Investimentos" to { showPlaceholder("Investimentos","Área para registar e acompanhar investimentos. Isto não constitui recomendação financeira.") },
            "Património" to { showPlaceholder("Património","Área para registar bens e ativos e calcular o património líquido.") },
            "Relatórios" to { showReports() },
            "Educação financeira" to { showPlaceholder("Educação financeira","Conteúdos sobre orçamento, poupança, juros, risco e gestão de pequenos negócios.") },
            "Definições" to { showPlaceholder("Definições","Preferências, moeda Kwanza (Kz), exportação e cópias de segurança.") },
            "Segurança" to { showPlaceholder("Segurança","PIN, proteção de dados e cópias de segurança serão desenvolvidos numa próxima versão.") }
        )
        for (start in menu.indices step 2) {
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            for (i in start until minOf(start+2,menu.size)) {
                val item=menu[i]
                row.addView(Button(this).apply {
                    text="◆  ${item.first}"; textSize=12f; isAllCaps=false
                    setTextColor(navy); setBackgroundColor(-1); setOnClickListener { item.second() }
                },weight().apply { marginEnd=5; bottomMargin=5 })
            }
            page.addView(row)
        }
        page.addView(label("SMART MONEY • Versão 0.2.0",11f,muted).apply { gravity=Gravity.CENTER; setPadding(0,20,0,0) })
    }

    private fun showDashboard() {
        base("Dashboard","Visão geral das tuas finanças")
        val t=db.totals(); val p=db.totals("PESSOAL"); val b=db.totals("NEGOCIO")
        section("TODAS AS FINANÇAS")
        addInfo("Saldo registado",formatMoney(t.first-t.second))
        addInfo("Total de receitas",formatMoney(t.first)); addInfo("Total de despesas",formatMoney(t.second))
        section("SEPARAÇÃO FINANCEIRA")
        addInfo("Saldo pessoal",formatMoney(p.first-p.second)); addInfo("Saldo dos negócios",formatMoney(b.first-b.second))
        section("MOVIMENTOS RECENTES"); showRecent()
    }

    private fun showMovements(type:String) {
        base(if(type=="RECEITA") "Receitas" else "Despesas","Regista e consulta os teus movimentos")
        page.addView(Button(this).apply {
            text=if(type=="RECEITA") "+ REGISTAR RECEITA" else "+ REGISTAR DESPESA"
            setOnClickListener { transactionDialog(type) }
        },match())
        section("HISTÓRICO")
        val items=db.recent().filter { it.type==type }
        if(items.isEmpty()) page.addView(label("Ainda não existem registos.",14f,muted))
        items.forEach { movementCard(it) }
    }

    private fun transactionDialog(type:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4) }
        val amount=EditText(this).apply { hint="Valor em Kz"; inputType=8194 }
        val category=EditText(this).apply { hint="Categoria (ex.: salário, transporte)" }
        val note=EditText(this).apply { hint="Descrição opcional" }
        val scope=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Pessoal","Negócio")) }
        box.addView(amount); box.addView(category); box.addView(note); box.addView(label("Associar a:",13f,ink)); box.addView(scope)
        AlertDialog.Builder(this).setTitle(if(type=="RECEITA") "Nova receita" else "Nova despesa").setView(box)
            .setNegativeButton("Cancelar",null).setPositiveButton("Guardar") { _,_ ->
                val value=amount.text.toString().trim().replace(",",".").toDoubleOrNull()
                val cat=category.text.toString().trim()
                if(value==null || value<=0 || cat.isBlank()) toast("Introduz um valor positivo e uma categoria.")
                else { db.addMovement(type,value,cat,note.text.toString(),if(scope.selectedItemPosition==0) "PESSOAL" else "NEGOCIO"); toast("Movimento guardado neste dispositivo."); showMovements(type) }
            }.show()
    }

    private fun showSavings() {
        base("Poupanças","Define objetivos e acompanha o progresso")
        page.addView(Button(this).apply { text="+ CRIAR OBJETIVO"; setOnClickListener { goalDialog() } },match())
        section("OS MEUS OBJETIVOS")
        val goals=db.goals()
        if(goals.isEmpty()) page.addView(label("Ainda não criaste objetivos.",14f,muted))
        goals.forEach { addInfo("Objetivo",it) }
    }

    private fun goalDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4) }
        val name=EditText(this).apply { hint="Nome do objetivo" }
        val target=EditText(this).apply { hint="Valor da meta em Kz"; inputType=8194 }
        box.addView(name); box.addView(target)
        AlertDialog.Builder(this).setTitle("Criar poupança").setView(box).setNegativeButton("Cancelar",null)
            .setPositiveButton("Guardar") { _,_ ->
                val value=target.text.toString().trim().replace(",",".").toDoubleOrNull()
                if(name.text.isNullOrBlank() || value==null || value<=0) toast("Preenche o nome e uma meta válida.")
                else { db.addGoal(name.text.toString().trim(),value); showSavings() }
            }.show()
    }

    private fun showBusinesses() {
        base("Negócios","Mantém os projetos separados das finanças pessoais")
        page.addView(Button(this).apply { text="+ ADICIONAR NEGÓCIO"; setOnClickListener { businessDialog() } },match())
        section("OS MEUS NEGÓCIOS")
        val list=db.businesses()
        if(list.isEmpty()) page.addView(label("Ainda não adicionaste negócios.",14f,muted))
        list.forEach { addInfo("Negócio",it) }
        section("RESULTADOS DOS NEGÓCIOS")
        val t=db.totals("NEGOCIO")
        addInfo("Receitas",formatMoney(t.first)); addInfo("Despesas",formatMoney(t.second)); addInfo("Resultado",formatMoney(t.first-t.second))
    }

    private fun businessDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4) }
        val name=EditText(this).apply { hint="Nome do negócio" }; val desc=EditText(this).apply { hint="Descrição" }
        box.addView(name); box.addView(desc)
        AlertDialog.Builder(this).setTitle("Adicionar negócio").setView(box).setNegativeButton("Cancelar",null)
            .setPositiveButton("Guardar") { _,_ ->
                if(name.text.isNullOrBlank()) toast("Indica o nome do negócio.")
                else { db.addBusiness(name.text.toString().trim(),desc.text.toString().trim()); showBusinesses() }
            }.show()
    }

    private fun showAccounts() {
        base("Minhas contas","Separação entre dinheiro pessoal e de negócios")
        addInfo("Conta pessoal","Movimentos marcados como PESSOAL")
        addInfo("Conta de negócio","Movimentos marcados como NEGOCIO")
        addInfo("Importante","Nesta versão, são categorias de registo local. Não estão ligadas a bancos.")
    }

    private fun showReports() {
        base("Relatórios","Resumo dos movimentos registados")
        val t=db.totals(); addInfo("Receitas",formatMoney(t.first)); addInfo("Despesas",formatMoney(t.second))
        addInfo("Resultado",formatMoney(t.first-t.second))
        section("POR ÁREA")
        val p=db.totals("PESSOAL"); val b=db.totals("NEGOCIO")
        addInfo("Pessoal","Receitas ${formatMoney(p.first)} | Despesas ${formatMoney(p.second)}")
        addInfo("Negócios","Receitas ${formatMoney(b.first)} | Despesas ${formatMoney(b.second)}")
        section("MOVIMENTAÇÕES RECENTES"); showRecent()
    }

    private fun showPlaceholder(title:String,description:String) {
        base(title,"Módulo SMART MONEY")
        addInfo("Em desenvolvimento",description)
        addInfo("Próxima etapa","Vamos acrescentar formulários, cálculos e armazenamento específico.")
    }

    private fun showRecent() {
        val items=db.recent(10)
        if(items.isEmpty()) page.addView(label("Sem movimentos registados.",14f,muted))
        items.forEach { movementCard(it) }
    }

    private fun movementCard(m:Movement) {
        val sign=if(m.type=="RECEITA") "+" else "−"
        addInfo("$sign ${formatMoney(m.amount)}","${m.category} • ${m.scope}${if(m.note.isBlank()) "" else "\n${m.note}"}")
    }

    private fun metric(title:String,amount:Double):LinearLayout {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,12,8,12); setBackgroundColor(-1) }
        box.addView(label(title,11f,muted,true)); box.addView(label(formatMoney(amount),15f,ink,true))
        return box
    }

    private fun section(text:String) { page.addView(label(text,13f,ink,true).apply { setPadding(2,20,2,9) }) }

    private fun addInfo(title:String,description:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,13,14,13); setBackgroundColor(-1) }
        box.addView(label(title,14f,ink,true)); box.addView(label(description,12f,muted))
        page.addView(box,match().apply { bottomMargin=7 })
    }

    private fun label(text:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply {
        this.text=text; textSize=size; setTextColor(color); if(bold) setTypeface(null,android.graphics.Typeface.BOLD)
    }
    private fun match()=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun weight()=LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f)
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
}
