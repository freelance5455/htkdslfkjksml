package ao.smartmoney.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Movement(val id: Long, val type: String, val amount: Double,
    val category: String, val note: String, val scope: String, val createdAt: String)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "smart_money.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, amount REAL NOT NULL CHECK(amount > 0), category TEXT NOT NULL, note TEXT, scope TEXT NOT NULL DEFAULT 'PESSOAL', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE savings_goals (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, target_amount REAL NOT NULL, saved_amount REAL NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE businesses (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT)")
        db.execSQL("CREATE TABLE assets (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, estimated_value REAL NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, balance REAL NOT NULL DEFAULT 0, scope TEXT NOT NULL DEFAULT 'PESSOAL')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, balance REAL NOT NULL DEFAULT 0, scope TEXT NOT NULL DEFAULT 'PESSOAL')")
        }
    }

    fun addMovement(type: String, amount: Double, category: String, note: String, scope: String): Long {
        val v = ContentValues().apply {
            put("type", type); put("amount", amount); put("category", category)
            put("note", note); put("scope", scope)
        }
        return writableDatabase.insert("transactions", null, v)
    }

    fun totals(scope: String? = null): Pair<Double, Double> {
        val where = if (scope == null) "" else " WHERE scope=?"
        val args = if (scope == null) null else arrayOf(scope)
        var income = 0.0
        var expense = 0.0
        readableDatabase.rawQuery("SELECT type, COALESCE(SUM(amount),0) FROM transactions$where GROUP BY type", args).use {
            while (it.moveToNext()) {
                if (it.getString(0) == "RECEITA") income = it.getDouble(1)
                if (it.getString(0) == "DESPESA") expense = it.getDouble(1)
            }
        }
        return income to expense
    }

    fun recent(limit: Int = 20): List<Movement> {
        val result = mutableListOf<Movement>()
        readableDatabase.rawQuery("SELECT id,type,amount,category,COALESCE(note,''),scope,created_at FROM transactions ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) result.add(Movement(c.getLong(0), c.getString(1), c.getDouble(2),
                c.getString(3), c.getString(4), c.getString(5), c.getString(6)))
        }
        return result
    }

    fun addGoal(name: String, target: Double) {
        val v = ContentValues().apply { put("name", name); put("target_amount", target) }
        writableDatabase.insert("savings_goals", null, v)
    }

    fun goals(): List<String> {
        val result = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name,target_amount,saved_amount FROM savings_goals ORDER BY id DESC", null).use {
            while (it.moveToNext()) result.add("${it.getString(0)} — ${formatMoney(it.getDouble(2))} / ${formatMoney(it.getDouble(1))}")
        }
        return result
    }

    fun addBusiness(name: String, description: String) {
        val v = ContentValues().apply { put("name", name); put("description", description) }
        writableDatabase.insert("businesses", null, v)
    }

    fun businesses(): List<String> {
        val result = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name,COALESCE(description,'') FROM businesses ORDER BY id DESC", null).use {
            while (it.moveToNext()) result.add("${it.getString(0)} — ${it.getString(1)}")
        }
        return result
    }
}

fun formatMoney(value: Double) = String.format("%,.2f Kz", value)
