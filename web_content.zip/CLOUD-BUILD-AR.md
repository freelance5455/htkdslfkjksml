# بناء Fideo بدون Android Studio

المشروع مجهز ليُبنى على GitHub Actions في السحابة.

1. أنشئ مستودع GitHub جديد باسم Fideo.
2. ارفع محتويات مجلد project بالكامل.
3. افتح تبويب Actions.
4. اختر Build Fideo APK.
5. اضغط Run workflow.
6. بعد انتهاء البناء افتح نتيجة التشغيل ونزّل Artifact باسم Fideo-debug-apk.
7. فك الضغط عن الـArtifact وستجد app-debug.apk.

لا تحتاج Android Studio على جهازك.
