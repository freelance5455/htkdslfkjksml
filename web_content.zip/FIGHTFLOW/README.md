# FIGHTFLOW – erweiterter Smartphone-Web-App-Prototyp

## Neu enthalten
- Dashboard mit Wochenübersicht und gespeicherten Einheiten
- Wochenplanung mit frei auswählbaren Trainingstagen
- Bearbeitbarer Trainingsplan mit Checkliste und eigenen Aufgaben
- Übungsbibliothek mit Suche, Kategorien, Details und „Zum Plan hinzufügen“
- Einstellbarer Intervalltimer mit Arbeitsphasen, Pausen, Runden und Vibrationssignal (falls vom Gerät unterstützt)
- Trainingstagebuch mit Einheiten und persönlichen Notizen
- Profil bearbeiten, Daten als JSON exportieren und lokal löschen
- Lokale Speicherung, PWA-Manifest und aktualisierter Offline-Cache
- Übernahme eines vorhandenen FIGHTFLOW-Profils aus der ersten Version

## Lokal testen
`index.html` im Browser öffnen. Service Worker und Installations-/Offline-Funktionen benötigen HTTPS oder localhost.

## Auf dem Smartphone installieren
1. Den Inhalt dieses Ordners auf einem HTTPS-Webhost veröffentlichen (z. B. GitHub Pages oder Netlify).
2. Android: Website in Chrome öffnen → Menü → „App installieren“ / „Zum Startbildschirm hinzufügen“.
3. iPhone: Website in Safari öffnen → Teilen → „Zum Home-Bildschirm“.

## Datenschutz & Grenzen
Alle Profile, Einheiten und Notizen werden lokal im Browser gespeichert. Es gibt kein echtes Benutzerkonto, keine Cloud-Synchronisierung, keinen Online-Coach und keine Push-Mitteilungen. Der Export erstellt eine JSON-Sicherungsdatei.

Die Übungsbibliothek enthält allgemeine Fitness- und Bewegungsbeispiele. Sie ersetzt keine qualifizierte Trainingsbetreuung. Partnerübungen, neue Kampfsporttechniken und Sparring nur unter Aufsicht qualifizierter Trainerinnen und Trainer und mit geeigneter Schutzausrüstung durchführen. Bei Schmerzen, Schwindel oder Unwohlsein pausieren.
