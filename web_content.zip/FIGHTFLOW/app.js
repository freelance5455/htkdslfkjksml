/* FIGHTFLOW – erweiterter, lokal speichernder PWA-Prototyp */
const STORE_KEY = 'fightflow-app-v2';
const LEGACY_KEY = 'fightflow-profile-v1';
const DAYS = ['Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag','Sonntag'];
const $ = (selector, root=document) => root.querySelector(selector);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const formatDate = value => { if(!value) return '—'; const d=new Date(`${value}T12:00:00`); return d.toLocaleDateString('de-DE',{day:'2-digit',month:'short',year:'numeric'}); };
const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;

const defaults = {
  profile:{sport:'MMA',goal:'Technik verbessern',level:'Anfänger',frequency:'3–4 Mal',day:'Samstag',intensity:'Mittel'},
  schedule:['Montag','Mittwoch','Samstag'],
  logs:[],
  notes:[],
  customTasks:[],
  timerConfig:{roundSeconds:180,restSeconds:60,rounds:3}
};
function readStore(){
  try {
    const saved=JSON.parse(localStorage.getItem(STORE_KEY)||'null');
    if(saved) return {...defaults,...saved,profile:{...defaults.profile,...(saved.profile||{})},timerConfig:{...defaults.timerConfig,...(saved.timerConfig||{})},schedule:Array.isArray(saved.schedule)?saved.schedule:defaults.schedule};
  } catch(e){ console.warn('FIGHTFLOW Speicher konnte nicht gelesen werden.',e); }
  try {
    const legacy=JSON.parse(localStorage.getItem(LEGACY_KEY)||'null');
    if(legacy) return {...defaults,profile:{...defaults.profile,...legacy},schedule:[legacy.day||'Samstag']};
  } catch(e){ console.warn('Altes Profil konnte nicht gelesen werden.',e); }
  return null;
}
let state=readStore();
let tab='home';
let exerciseFilter='Alle';
let exerciseSearch='';
let selectedExercise=null;
let timerInterval=null;
let timer={running:false,phase:'work',round:1,remaining:180,completed:false};
let workout=null;

const exerciseLibrary=[
 {id:'warmup',name:'Ganzkörper-Warm-up',category:'Aufwärmen',duration:6,level:'Alle',desc:'Beginne mit lockerem Gehen oder leichtem Traben auf der Stelle. Bewege anschließend Schultern, Hüften, Knie und Sprunggelenke sanft durch den verfügbaren Bewegungsradius.',tip:'Starte ruhig und steigere das Tempo nur, wenn es sich gut anfühlt.'},
 {id:'mobility',name:'Mobilität & Gelenke',category:'Aufwärmen',duration:5,level:'Alle',desc:'Führe kontrollierte, schmerzfreie Bewegungen für Schultern, Brustwirbelsäule und Hüften aus. Arbeite ohne Schwung und ohne in eine Dehnung hineinzudrücken.',tip:'Beweglichkeit soll sich angenehm anfühlen. Bei Schmerzen abbrechen.'},
 {id:'stance',name:'Grundstellung & Balance',category:'Technik',duration:6,level:'Alle',desc:'Übe deine sportartspezifische Grundstellung zunächst langsam und stabil. Verlagere dein Gewicht kontrolliert und finde immer wieder eine bequeme, ausgeglichene Position.',tip:'Lass dir die passende Haltung von deiner Trainerin oder deinem Trainer zeigen.'},
 {id:'footwork',name:'Beinarbeit & Schritte',category:'Technik',duration:6,level:'Alle',desc:'Übe kleine Schritte vor, zurück und seitlich auf einer freien Fläche. Halte den Oberkörper entspannt und achte darauf, nicht die Balance zu verlieren.',tip:'Arbeite langsam und sauber. Nutze ausreichend Platz und rutschfesten Boden.'},
 {id:'shadow',name:'Schattenboxen – Bewegungsfluss',category:'Technik',duration:5,level:'Alle',desc:'Bewege dich locker durch den Raum und verbinde Fußarbeit mit kontrollierten Armbewegungen. Konzentriere dich auf Rhythmus, Koordination und eine entspannte Atmung.',tip:'Technikaufgaben und Schlagbewegungen nur so ausführen, wie sie im Training angeleitet wurden.'},
 {id:'defense',name:'Reaktion & Ausweichen (ohne Kontakt)',category:'Technik',duration:4,level:'Fortgeschritten',desc:'Trainiere auf Zuruf deiner Trainerin oder deines Trainers einfache Richtungswechsel und kontrollierte Ausweichbewegungen ohne Partnerkontakt.',tip:'Kein ruckartiges Abknicken. Bei Unsicherheit zuerst die Bewegung erklären lassen.'},
 {id:'pads',name:'Pratzen- oder Sandsackrunde',category:'Technik',duration:3,level:'Alle',desc:'Eine kurze, technisch saubere Runde an Pratzen oder am Sandsack – ausschließlich mit passender Ausrüstung und nach Anleitung deiner Trainerin oder deines Trainers.',tip:'Nicht allein neue Schlagtechniken ausprobieren. Qualität und Sicherheit gehen vor Kraft.'},
 {id:'squat',name:'Kniebeugen ohne Zusatzgewicht',category:'Kraft',duration:3,level:'Alle',desc:'Stelle die Füße bequem auf, beuge Hüfte und Knie kontrolliert und richte dich ruhig wieder auf. Wähle eine Tiefe, die sich stabil und schmerzfrei anfühlt.',tip:'Lieber wenige kontrollierte Wiederholungen als hastige Bewegungen.'},
 {id:'push',name:'Liegestütz-Variante',category:'Kraft',duration:3,level:'Alle',desc:'Wähle eine passende Variante an der Wand, erhöhten Fläche oder am Boden. Halte den Körper stabil und bewege dich langsam und kontrolliert.',tip:'Die Variante darf fordern, soll aber keine Schmerzen verursachen.'},
 {id:'bridge',name:'Beckenheben',category:'Kraft',duration:3,level:'Alle',desc:'Lege dich auf den Rücken, stelle die Füße auf und hebe das Becken kontrolliert an. Kurz halten und langsam absenken.',tip:'Atme gleichmäßig und vermeide ein Hohlkreuz.'},
 {id:'plank',name:'Stabilität – Unterarmstütz',category:'Kraft',duration:2,level:'Alle',desc:'Halte eine leichte, gut kontrollierbare Stützposition. Beginne bei Bedarf an einer erhöhten Fläche oder mit kurzen Haltezeiten.',tip:'Beende den Satz, wenn die Körperposition nicht mehr sauber bleibt.'},
 {id:'rope',name:'Seilspringen oder Step-Taps',category:'Ausdauer',duration:4,level:'Alle',desc:'Wähle lockeres Seilspringen oder gelenkschonende Step-Taps ohne Seil. Bleibe in einem Tempo, bei dem du dich noch gut kontrollieren kannst.',tip:'Fester, rutschfester Untergrund und passende Schuhe sind wichtig.'},
 {id:'interval',name:'Lockere Bewegungsintervalle',category:'Ausdauer',duration:5,level:'Alle',desc:'Wechsle kurze Abschnitte lockerer Bewegung mit Gehpausen ab. Passe Tempo und Dauer deiner Tagesform an.',tip:'Du solltest dich jederzeit sicher fühlen und noch sprechen können.'},
 {id:'single',name:'Einbeinige Balance',category:'Kraft',duration:3,level:'Alle',desc:'Stehe in der Nähe einer stabilen Stütze auf einem Bein. Halte die Position kurz und wechsle dann die Seite.',tip:'Nutze bei Bedarf eine Hand zur Unterstützung.'},
 {id:'stretch',name:'Sanftes Cool-down',category:'Regeneration',duration:5,level:'Alle',desc:'Lass das Tempo langsam ausklingen. Atme ruhig und bewege Schultern, Beine und Rücken sanft. Vermeide aggressive Dehnungen.',tip:'Regeneration ist Teil des Trainings – du musst nichts erzwingen.'},
 {id:'breathing',name:'Atemruhe',category:'Regeneration',duration:3,level:'Alle',desc:'Setze oder stelle dich bequem hin. Atme ruhig ein und etwas länger aus. Lass Puls und Bewegungsdrang langsam zur Ruhe kommen.',tip:'Atme natürlich. Nicht die Luft anhalten oder forcieren.'},
 {id:'stretchhips',name:'Hüft- und Beinmobilität',category:'Regeneration',duration:4,level:'Alle',desc:'Nutze einfache, sanfte Bewegungen für Hüfte und Beine. Bleibe in einem angenehmen Bereich und wechsle regelmäßig die Seite.',tip:'Keine Dehnung in den Schmerz hinein.'}
];
const categories=['Alle','Aufwärmen','Technik','Kraft','Ausdauer','Regeneration'];

function persist(){ if(state){state.currentWorkout=workout;localStorage.setItem(STORE_KEY,JSON.stringify(state));} }
function templateTasks(){
 const sport=state.profile.sport;
 return [
  {id:uid(),name:'Locker aufwärmen & mobilisieren',category:'Aufwärmen',done:false},
  {id:uid(),name:'Grundtechnik und Bewegungsabläufe üben',category:'Technik',done:false},
  {id:uid(),name:sport==='BJJ'?'Beweglichkeit und Bodenbewegung':'Beinarbeit & Koordination',category:'Technik',done:false},
  {id:uid(),name:'Allgemeine Kraft und Stabilität',category:'Kraft',done:false},
  {id:uid(),name:'Cool-down & Regeneration',category:'Regeneration',done:false}
 ];
}
function ensureWorkout(){
 if(!workout) workout=state.currentWorkout||{date:todayISO(),title:`${state.profile.sport}-Training`,focus:state.profile.goal,duration:45,tasks:templateTasks()};
 state.currentWorkout=workout;
 return workout;
}
function initTimer(){timer={running:false,phase:'work',round:1,remaining:state.timerConfig.roundSeconds,completed:false};}
function fmtTime(seconds){const safe=Math.max(0,seconds|0);return `${String(Math.floor(safe/60)).padStart(2,'0')}:${String(safe%60).padStart(2,'0')}`;}
function weekLogs(){const now=new Date();const monday=new Date(now);const offset=(now.getDay()+6)%7;monday.setDate(now.getDate()-offset);monday.setHours(0,0,0,0);return state.logs.filter(log=>{const d=new Date(`${log.date}T12:00:00`);return d>=monday;});}
function render(){
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 if(!state){$('#app').innerHTML=setup();return;}
 const pages={home,plan,exercises,timerPage,journal};
 $('#app').innerHTML=(pages[tab]||home)();
 if(tab==='timer') updateTimerUI();
}
function setup(){
 return `<section class="hero"><div class="eyebrow">FIGHTFLOW · DEIN TRAININGSBEGLEITER</div><h1>Train smarter.<br>Move stronger.</h1><p class="muted">Plane dein Training, nutze den Intervalltimer und halte deine Entwicklung fest – alles direkt auf deinem Gerät.</p><span class="pill">TRAININGSPLAN</span><span class="pill">TIMER</span><span class="pill">TAGEBUCH</span></section>
 <form id="setup" class="card"><h2>Dein Profil einrichten</h2>
 <label>Kampfsport</label><select name="sport">${['MMA','Boxen','Kickboxen','Muay Thai','BJJ','Mehrere Sportarten'].map(x=>`<option>${x}</option>`).join('')}</select>
 <label>Dein Ziel</label><select name="goal">${['Technik verbessern','Mehr Kraft aufbauen','Ausdauer verbessern','Wettkampfvorbereitung','Allgemein fitter werden'].map(x=>`<option>${x}</option>`).join('')}</select>
 <label>Erfahrung</label><select name="level">${['Anfänger','Fortgeschritten','Erfahren'].map(x=>`<option>${x}</option>`).join('')}</select>
 <label>Training pro Woche</label><select name="frequency"><option>1–2 Mal</option><option selected>3–4 Mal</option><option>5–6 Mal</option></select>
 <label>Bevorzugter Trainingstag</label><select name="day">${DAYS.map(x=>`<option ${x==='Samstag'?'selected':''}>${x}</option>`).join('')}</select>
 <label>Gewünschte Intensität</label><select name="intensity">${['Leicht','Mittel','Anspruchsvoll'].map(x=>`<option>${x}</option>`).join('')}</select>
 <p class="note">Du musst keine Körper- oder Gewichtsdaten angeben. Passe Training an deine Tagesform an und stimme neue Übungen mit deinem Coach ab.</p><button>FIGHTFLOW STARTEN →</button></form>`;
}
function home(){
 const logs=weekLogs(), total=state.logs.length, mins=logs.reduce((s,l)=>s+(Number(l.duration)||0),0);
 const next=state.schedule.length?state.schedule.join(' · '):'Noch keine Trainingstage gewählt';
 const recent=state.logs.slice().sort((a,b)=>(b.completedAt||'').localeCompare(a.completedAt||'')).slice(0,2);
 return `<div class="eyebrow">DEIN DASHBOARD · ${new Date().toLocaleDateString('de-DE',{weekday:'long',day:'numeric',month:'long'})}</div><h1>Hi, Fighter! ⚡</h1><p class="muted">Dein Trainingsbereich auf einen Blick. Bleib neugierig, trainiere kontrolliert und plane genug Erholung ein.</p>
 <section class="hero"><div class="eyebrow">DEIN FOKUS</div><h2>${esc(state.profile.goal)}</h2><p class="muted">${esc(state.profile.sport)} · ${esc(state.profile.level)} · ${esc(state.profile.intensity)} Intensität</p><div class="hero-actions"><button data-go="plan">Training öffnen →</button><button class="secondary" data-go="timer">Intervalltimer starten</button></div></section>
 <div class="grid">
  <div class="stat"><small>DIESE WOCHE</small><strong>${logs.length} <span class="unit">Einheiten</span></strong><small>abgeschlossene Trainings</small></div>
  <div class="stat"><small>TRAININGSZEIT</small><strong>${mins} <span class="unit">Min.</span></strong><small>in dieser Woche</small></div>
  <div class="stat"><small>GESAMT</small><strong>${total}</strong><small>gespeicherte Einheiten</small></div>
  <div class="stat"><small>TRAININGSTAGE</small><strong>${state.schedule.length}/7</strong><small>pro Woche geplant</small></div>
 </div>
 <section class="card"><div class="section-heading"><h3>Deine Trainingswoche</h3><button class="text-button" data-go="plan">Bearbeiten</button></div><p class="muted">${esc(next)}</p><div class="week-dots">${DAYS.map(d=>`<span class="${state.schedule.includes(d)?'scheduled':''}" title="${d}">${d.slice(0,2)}</span>`).join('')}</div></section>
 <section class="card"><div class="section-heading"><h3>Zuletzt trainiert</h3><button class="text-button" data-go="journal">Alle ansehen</button></div>${recent.length?recent.map(log=>`<div class="list-row"><span class="list-icon">🥊</span><div class="grow"><strong>${esc(log.title)}</strong><small>${formatDate(log.date)} · ${Number(log.duration)||0} Min.</small></div><span class="done-mark">✓</span></div>`).join(''):`<div class="empty"><div class="empty-icon">📘</div><strong>Noch kein Training gespeichert</strong><p class="muted">Schließe deine erste Einheit ab und sie erscheint hier.</p><button class="secondary" data-go="plan">Erste Einheit planen</button></div>`}</section>
 <section class="card tip-card"><h3>💡 Fightflow-Tipp</h3><p class="muted">Gute Technik entsteht durch konzentriertes Üben. Pausen, Schlaf und regelmäßige Mahlzeiten gehören genauso dazu wie Bewegung.</p></section>`;
}
function plan(){
 const w=ensureWorkout(), completed=w.tasks.filter(t=>t.done).length, pct=w.tasks.length?Math.round(completed/w.tasks.length*100):0;
 return `<div class="eyebrow">PLANUNG & TRAINING</div><h1>Dein Trainingsplan</h1><p class="muted">Passe deine Woche an und hake die Schritte deiner aktuellen Einheit ab.</p>
 <section class="card"><div class="section-heading"><h3>Meine Trainingstage</h3><span class="pill">${state.schedule.length} ausgewählt</span></div><p class="note">Tippe die Tage an, an denen du normalerweise trainieren möchtest.</p><div class="day-picker">${DAYS.map(d=>`<button class="${state.schedule.includes(d)?'selected':''}" data-schedule="${d}" aria-pressed="${state.schedule.includes(d)}">${d.slice(0,2)}<small>${d}</small></button>`).join('')}</div></section>
 <section class="card"><div class="section-heading"><div><div class="eyebrow">AKTUELLE EINHEIT</div><h2>${esc(w.title)}</h2></div><span class="pill">${formatDate(w.date)}</span></div>
 <label for="workoutTitle">Name der Einheit</label><input id="workoutTitle" maxlength="48" value="${esc(w.title)}">
 <label for="workoutFocus">Trainingsfokus</label><input id="workoutFocus" maxlength="70" value="${esc(w.focus)}">
 <label for="workoutDuration">Dauer der Einheit (Minuten)</label><input id="workoutDuration" type="number" min="5" max="240" step="5" value="${Number(w.duration)||45}">
 <div class="progress-head"><span>${completed} von ${w.tasks.length} Aufgaben erledigt</span><strong>${pct}%</strong></div><div class="progress"><i style="width:${pct}%"></i></div>
 <div class="task-list">${w.tasks.map(t=>`<label class="task ${t.done?'done':''}"><input type="checkbox" data-task="${t.id}" ${t.done?'checked':''}><span class="task-copy"><strong>${esc(t.name)}</strong><small>${esc(t.category||'Eigene Aufgabe')}</small></span><button class="remove-task" type="button" data-remove-task="${t.id}" aria-label="${esc(t.name)} entfernen">×</button></label>`).join('')}</div>
 <form id="addTaskForm" class="inline-form"><input id="newTask" maxlength="60" placeholder="Eigene Aufgabe hinzufügen" required><button class="small-button">＋</button></form>
 <div class="two-buttons"><button class="secondary" data-go="exercises">Übungen hinzufügen</button><button data-action="save-workout">Einheit speichern ✓</button></div>
 <p class="note">Du kannst eine Einheit auch mit nicht abgehakten Aufgaben speichern. Gespeicherte Einheiten findest du im Tagebuch.</p></section>
 <section class="card"><h3>Trainingshinweis</h3><p class="muted">Wähle eine Belastung, die zu deiner Tagesform passt. Neue Technik, Partnerübungen und Sparring gehören in die Betreuung durch qualifizierte Trainerinnen und Trainer.</p></section>`;
}
function exerciseCards(){
 const filtered=exerciseLibrary.filter(x=>(exerciseFilter==='Alle'||x.category===exerciseFilter)&&(`${x.name} ${x.category} ${x.desc}`).toLowerCase().includes(exerciseSearch.toLowerCase()));
 if(!filtered.length) return `<div class="empty"><div class="empty-icon">🔎</div><strong>Keine Übung gefunden</strong><p class="muted">Versuche einen anderen Suchbegriff.</p></div>`;
 return filtered.map(x=>`<article class="exercise-card"><div class="exercise-meta"><span class="pill">${esc(x.category)}</span><span>${x.duration} Min. · ${esc(x.level)}</span></div><h3>${esc(x.name)}</h3><p class="muted">${esc(x.desc)}</p><div class="exercise-actions"><button class="secondary" data-exercise="${x.id}">Details</button><button data-add-exercise="${x.id}">＋ Zum Plan</button></div></article>`).join('');
}
function exercises(){
 const detail=selectedExercise?exerciseLibrary.find(x=>x.id===selectedExercise):null;
 return `<div class="eyebrow">ÜBUNGSBIBLIOTHEK</div><h1>Übungen entdecken</h1><p class="muted">Finde passende Ideen für Warm-up, Technik, Kraft, Ausdauer und Regeneration.</p>
 <section class="card"><label class="search-label" for="exerciseSearch">Übungen durchsuchen</label><input id="exerciseSearch" type="search" value="${esc(exerciseSearch)}" placeholder="z. B. Mobilität, Balance …"><div class="filter-chips">${categories.map(c=>`<button class="${exerciseFilter===c?'selected':''}" data-filter="${c}">${c}</button>`).join('')}</div></section>
 ${detail?`<section class="card detail-card"><button class="text-button back-link" data-action="close-exercise">← Zur Übersicht</button><span class="pill">${esc(detail.category)}</span><h2>${esc(detail.name)}</h2><p class="muted">${esc(detail.desc)}</p><div class="stat-line"><span>Empfohlene Orientierung</span><strong>${detail.duration} Min.</strong></div><div class="coach-tip"><strong>Darauf achten</strong><p class="muted">${esc(detail.tip)}</p></div><button data-add-exercise="${detail.id}">＋ Zu meiner Einheit hinzufügen</button></section>`:''}
 <div id="exerciseResults">${exerciseCards()}</div>
 <p class="note safety-note">Übungsbeschreibungen sind allgemeine Ideen und kein Ersatz für Training unter qualifizierter Anleitung. Bei Schmerzen, Schwindel oder Unwohlsein pausieren.</p>`;
}
function timerPage(){
 const cfg=state.timerConfig;
 return `<div class="eyebrow">FIGHTFLOW INTERVALLTIMER</div><h1>Runden-Timer</h1><p class="muted">Für zeitlich strukturierte Trainingsabschnitte mit automatischen Pausen.</p>
 <section class="card timer-card"><div class="timer-state" id="timerPhase">TRAINING</div><div class="timer-ring" id="timerRing"><div class="timer-inner"><strong id="timerTime">${fmtTime(timer.remaining)}</strong><span id="timerRound">RUNDE ${timer.round} / ${cfg.rounds}</span></div></div><p class="timer-caption" id="timerCaption">Bereit, wenn du es bist.</p><div class="timer-controls"><button id="timerStart">${timer.running?'Pause':'Start'}</button><button class="secondary" id="timerReset">Zurücksetzen</button></div><div class="progress"><i id="timerBar" style="width:0%"></i></div><div class="timer-legend"><span><i class="work-dot"></i>Arbeitsphase ${Math.round(cfg.roundSeconds/60*10)/10} Min.</span><span><i class="rest-dot"></i>Pause ${Math.round(cfg.restSeconds/60*10)/10} Min.</span></div></section>
 <section class="card"><h3>Timer einstellen</h3><form id="timerSettings"><div class="settings-grid"><div><label for="roundMinutes">Rundenzeit (Min.)</label><input id="roundMinutes" type="number" min="1" max="15" step="1" value="${Math.round(cfg.roundSeconds/60)}"></div><div><label for="restSeconds">Pause (Sek.)</label><input id="restSeconds" type="number" min="0" max="300" step="15" value="${cfg.restSeconds}"></div><div><label for="roundCount">Runden</label><input id="roundCount" type="number" min="1" max="12" step="1" value="${cfg.rounds}"></div></div><button class="secondary">Einstellungen übernehmen</button></form></section>
 <p class="note">Der Timer läuft auch weiter, wenn du zu einem anderen App-Bereich wechselst, solange diese Seite geöffnet bleibt. Die Vibration hängt von deinem Gerät und Browser ab.</p>`;
}
function journal(){
 const logs=state.logs.slice().sort((a,b)=>(b.completedAt||'').localeCompare(a.completedAt||''));
 const notes=state.notes.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
 const week=weekLogs();
 return `<div class="eyebrow">TAGEBUCH & ENTWICKLUNG</div><h1>Dein Fortschritt</h1><p class="muted">Halte fest, was du trainiert hast und was du beim nächsten Mal beachten möchtest.</p>
 <div class="grid"><div class="stat"><small>GESAMTE EINHEITEN</small><strong>${state.logs.length}</strong><small>im Tagebuch</small></div><div class="stat"><small>DIESE WOCHE</small><strong>${week.length}</strong><small>gespeicherte Einheiten</small></div></div>
 <section class="card"><h3>Neue Trainingsnotiz</h3><form id="noteForm"><label for="noteTitle">Überschrift</label><input id="noteTitle" maxlength="50" placeholder="z. B. Das lief heute gut" required><label for="noteText">Deine Notiz</label><textarea id="noteText" maxlength="1200" placeholder="Was hast du gelernt? Was möchtest du beim nächsten Training üben?" required></textarea><button>Notiz speichern</button></form></section>
 <section class="card"><div class="section-heading"><h3>Trainingshistorie</h3><span class="pill">${logs.length} Einheiten</span></div>${logs.length?logs.map(log=>`<div class="history-item"><div class="history-date"><strong>${new Date(`${log.date}T12:00:00`).toLocaleDateString('de-DE',{day:'2-digit'})}</strong><small>${new Date(`${log.date}T12:00:00`).toLocaleDateString('de-DE',{month:'short'})}</small></div><div class="grow"><strong>${esc(log.title)}</strong><small>${esc(log.focus)} · ${Number(log.duration)||0} Min.</small><small>${Number(log.doneCount)||0}/${Number(log.taskCount)||0} Aufgaben abgehakt</small></div><button class="remove-task" data-delete-log="${log.id}" aria-label="Einheit löschen">×</button></div>`).join(''):`<div class="empty"><div class="empty-icon">📅</div><strong>Dein Trainingstagebuch ist noch leer</strong><p class="muted">Speichere eine Einheit im Trainingsplan, um sie hier zu sehen.</p><button class="secondary" data-go="plan">Zum Trainingsplan</button></div>`}</section>
 <section class="card"><div class="section-heading"><h3>Deine Notizen</h3><span class="pill">${notes.length}</span></div>${notes.length?notes.map(n=>`<div class="saved-note"><div class="section-heading"><strong>${esc(n.title)}</strong><button class="remove-task" data-delete-note="${n.id}" aria-label="Notiz löschen">×</button></div><small>${formatDate(n.date)}</small><p class="muted note-body">${esc(n.text)}</p></div>`).join(''):`<p class="muted">Noch keine Notizen gespeichert.</p>`}</section>
 <section class="card"><div class="section-heading"><h3>Fighter-Profil</h3><button class="text-button" data-action="edit-profile">Bearbeiten</button></div>${Object.entries({'Sport':state.profile.sport,'Ziel':state.profile.goal,'Level':state.profile.level,'Häufigkeit':state.profile.frequency,'Intensität':state.profile.intensity}).map(([k,v])=>`<div class="profile-row"><span>${k}</span><strong>${esc(v)}</strong></div>`).join('')}</section>
 <section class="card"><h3>Daten & Einstellungen</h3><p class="muted">Deine Daten bleiben in diesem Browser auf diesem Gerät. Es gibt kein Online-Konto und keine automatische Cloud-Synchronisierung.</p><button class="secondary" data-action="export">Daten exportieren (JSON) ↓</button><button class="danger-button" data-action="reset">Alle App-Daten löschen</button></section>`;
}

function showToast(message){
 let el=$('#toast'); if(!el){el=document.createElement('div');el.id='toast';el.className='toast';el.setAttribute('role','status');document.body.append(el);}
 el.textContent=message;el.classList.add('show');clearTimeout(showToast.timeout);showToast.timeout=setTimeout(()=>el.classList.remove('show'),2400);
}
function startTimer(){
 if(timer.completed) initTimer();
 if(!timer.running){timer.running=true;timerInterval=setInterval(timerTick,1000);}
 updateTimerUI();
}
function pauseTimer(){timer.running=false;clearInterval(timerInterval);timerInterval=null;updateTimerUI();}
function resetTimer(){pauseTimer();initTimer();updateTimerUI();}
function timerTick(){
 if(!timer.running)return;
 if(timer.remaining>0)timer.remaining--;
 if(timer.remaining<=0){
  if(navigator.vibrate) navigator.vibrate([120,70,120]);
  if(timer.phase==='work' && timer.round<state.timerConfig.rounds && state.timerConfig.restSeconds>0){timer.phase='rest';timer.remaining=state.timerConfig.restSeconds;}
  else if(timer.phase==='rest'){timer.round++;timer.phase='work';timer.remaining=state.timerConfig.roundSeconds;}
  else if(timer.phase==='work' && timer.round<state.timerConfig.rounds){timer.round++;timer.remaining=state.timerConfig.roundSeconds;}
  else {timer.running=false;timer.completed=true;clearInterval(timerInterval);timerInterval=null;showToast('Timer abgeschlossen – gut gemacht!');}
 }
 updateTimerUI();
}
function updateTimerUI(){
 const time=$('#timerTime'); if(!time)return;
 const cfg=state.timerConfig;
 $('#timerPhase').textContent=timer.completed?'FERTIG':timer.phase==='work'?'TRAINING':'PAUSE';
 $('#timerPhase').classList.toggle('rest',timer.phase==='rest'&&!timer.completed);
 time.textContent=timer.completed?'00:00':fmtTime(timer.remaining);
 $('#timerRound').textContent=`RUNDE ${Math.min(timer.round,cfg.rounds)} / ${cfg.rounds}`;
 $('#timerCaption').textContent=timer.completed?'Alle Intervalle sind abgeschlossen.':timer.running?(timer.phase==='work'?'Konzentriert und kontrolliert bewegen.':'Zeit zum Durchatmen.'):'Bereit, wenn du es bist.';
 $('#timerStart').textContent=timer.running?'Pause':timer.completed?'Nochmal starten':'Start';
 const total=timer.phase==='work'?cfg.roundSeconds:Math.max(1,cfg.restSeconds);
 const pct=timer.completed?100:Math.max(0,Math.min(100,((total-timer.remaining)/total)*100));
 $('#timerBar').style.width=`${pct}%`;
 $('#timerRing').style.setProperty('--timer-progress',`${pct*3.6}deg`);
}
function saveWorkout(){
 const w=ensureWorkout();
 const title=$('#workoutTitle')?.value.trim()||w.title;
 const focus=$('#workoutFocus')?.value.trim()||w.focus;
 const duration=Math.max(5,Math.min(240,Number($('#workoutDuration')?.value)||Number(w.duration)||45));
 const record={id:uid(),date:w.date,title,focus,duration,doneCount:w.tasks.filter(t=>t.done).length,taskCount:w.tasks.length,completedAt:new Date().toISOString()};
 state.logs.push(record);state.profile.goal=focus;workout=null;state.currentWorkout=null;persist();showToast('Einheit im Tagebuch gespeichert.');tab='journal';render();
}
function exportData(){
 const data={app:'FIGHTFLOW',exportedAt:new Date().toISOString(),...state};
 const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`fightflow-backup-${todayISO()}.json`;a.click();URL.revokeObjectURL(url);showToast('Export wurde erstellt.');
}
function editProfile(){
 const p=state.profile;
 $('#app').innerHTML=`<div class="eyebrow">FIGHTER-PROFIL</div><h1>Profil bearbeiten</h1><form id="editProfileForm" class="card">
 <label>Kampfsport</label><select name="sport">${['MMA','Boxen','Kickboxen','Muay Thai','BJJ','Mehrere Sportarten'].map(x=>`<option ${p.sport===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Dein Ziel</label><select name="goal">${['Technik verbessern','Mehr Kraft aufbauen','Ausdauer verbessern','Wettkampfvorbereitung','Allgemein fitter werden'].map(x=>`<option ${p.goal===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Erfahrung</label><select name="level">${['Anfänger','Fortgeschritten','Erfahren'].map(x=>`<option ${p.level===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Training pro Woche</label><select name="frequency">${['1–2 Mal','3–4 Mal','5–6 Mal'].map(x=>`<option ${p.frequency===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Bevorzugter Trainingstag</label><select name="day">${DAYS.map(x=>`<option ${p.day===x?'selected':''}>${x}</option>`).join('')}</select>
 <label>Gewünschte Intensität</label><select name="intensity">${['Leicht','Mittel','Anspruchsvoll'].map(x=>`<option ${p.intensity===x?'selected':''}>${x}</option>`).join('')}</select>
 <button>Änderungen speichern</button><button class="secondary" type="button" data-action="cancel-profile">Abbrechen</button></form>`;
}

document.addEventListener('click',e=>{
 const nav=e.target.closest('[data-tab]');if(nav){tab=nav.dataset.tab;selectedExercise=null;render();return;}
 const go=e.target.closest('[data-go]');if(go){tab=go.dataset.go;render();return;}
 const sched=e.target.closest('[data-schedule]');if(sched){const day=sched.dataset.schedule;state.schedule=state.schedule.includes(day)?state.schedule.filter(x=>x!==day):[...state.schedule,day];persist();render();return;}
 const filter=e.target.closest('[data-filter]');if(filter){exerciseFilter=filter.dataset.filter;render();return;}
 const detail=e.target.closest('[data-exercise]');if(detail){selectedExercise=detail.dataset.exercise;render();return;}
 const add=e.target.closest('[data-add-exercise]');if(add){const ex=exerciseLibrary.find(x=>x.id===add.dataset.addExercise);if(ex){ensureWorkout().tasks.push({id:uid(),name:ex.name,category:ex.category,done:false});persist();selectedExercise=null;tab='plan';render();showToast('Übung zum Trainingsplan hinzugefügt.');}return;}
 const action=e.target.closest('[data-action]')?.dataset.action;
 if(action==='close-exercise'){selectedExercise=null;render();}
 if(action==='save-workout')saveWorkout();
 if(action==='edit-profile')editProfile();
 if(action==='cancel-profile'){tab='journal';render();}
 if(action==='export')exportData();
 if(action==='reset'){if(confirm('Wirklich alle FIGHTFLOW-Daten auf diesem Gerät löschen?')){localStorage.removeItem(STORE_KEY);localStorage.removeItem(LEGACY_KEY);state=null;workout=null;pauseTimer();render();}}
 const remove=e.target.closest('[data-remove-task]');if(remove){const id=remove.dataset.removeTask;ensureWorkout().tasks=workout.tasks.filter(t=>t.id!==id);persist();render();}
 const delLog=e.target.closest('[data-delete-log]');if(delLog){state.logs=state.logs.filter(l=>l.id!==delLog.dataset.deleteLog);persist();render();}
 const delNote=e.target.closest('[data-delete-note]');if(delNote){state.notes=state.notes.filter(n=>n.id!==delNote.dataset.deleteNote);persist();render();}
 if(e.target.id==='timerStart'){timer.running?pauseTimer():startTimer();}
 if(e.target.id==='timerReset')resetTimer();
});
document.addEventListener('input',e=>{
 if(e.target.id==='exerciseSearch'){exerciseSearch=e.target.value;const box=$('#exerciseResults');if(box)box.innerHTML=exerciseCards();}
 if(e.target.id==='workoutTitle'){ensureWorkout().title=e.target.value;persist();}
 if(e.target.id==='workoutFocus'){ensureWorkout().focus=e.target.value;persist();}
 if(e.target.id==='workoutDuration'){ensureWorkout().duration=Math.max(5,Math.min(240,Number(e.target.value)||45));persist();}
});
document.addEventListener('change',e=>{
 if(e.target.matches('[data-task]')){const task=ensureWorkout().tasks.find(t=>t.id===e.target.dataset.task);if(task)task.done=e.target.checked;persist();render();}
});
document.addEventListener('submit',e=>{
 if(e.target.id==='setup'||e.target.id==='editProfileForm'){
  e.preventDefault();const next=Object.fromEntries(new FormData(e.target));const wasNew=!state;state=state||JSON.parse(JSON.stringify(defaults));state.profile={...state.profile,...next};
  if(wasNew)state.schedule=[next.day];else if(!state.schedule.length)state.schedule=[next.day];persist();tab='home';render();showToast('Profil gespeichert.');
 }
 if(e.target.id==='addTaskForm'){
  e.preventDefault();const input=$('#newTask');const name=input.value.trim();if(name){ensureWorkout().tasks.push({id:uid(),name,category:'Eigene Aufgabe',done:false});persist();render();}
 }
 if(e.target.id==='timerSettings'){
  e.preventDefault();pauseTimer();const mins=Math.max(1,Math.min(15,Number($('#roundMinutes').value)||3));const rest=Math.max(0,Math.min(300,Number($('#restSeconds').value)||0));const rounds=Math.max(1,Math.min(12,Number($('#roundCount').value)||1));
  state.timerConfig={roundSeconds:mins*60,restSeconds:rest,rounds};persist();resetTimer();render();showToast('Timer-Einstellungen gespeichert.');
 }
 if(e.target.id==='noteForm'){
  e.preventDefault();state.notes.push({id:uid(),title:$('#noteTitle').value.trim(),text:$('#noteText').value.trim(),date:todayISO(),createdAt:new Date().toISOString()});persist();render();showToast('Notiz gespeichert.');
 }
});
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
if(state)initTimer();
render();
