import { useEffect } from 'react';

interface SpatialNavOptions {
  enabled: boolean;
  onBack?: () => void;
  onPlayPause?: () => void;
}

export function useTvRemote({ enabled, onBack, onPlayPause }: SpatialNavOptions) {
  useEffect(() => {
    if (!enabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in a text input unless it's Escape/Back
      const activeEl = document.activeElement as HTMLElement | null;
      const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');

      if (e.key === 'Escape' || e.key === 'Backspace' || e.key === 'GoBack' || e.keyCode === 10009 || e.keyCode === 4) {
        if (isInput && e.key === 'Backspace') {
          // let normal backspace work in input
          return;
        }
        e.preventDefault();
        if (isInput) {
          activeEl.blur();
        }
        if (onBack) {
          onBack();
        }
        return;
      }

      if (isInput && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
        // Allow blurring out of input
        activeEl.blur();
      } else if (isInput) {
        return;
      }

      if (e.key === ' ' || e.key === 'MediaPlayPause') {
        if (onPlayPause) {
          e.preventDefault();
          onPlayPause();
          return;
        }
      }

      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
        navigateSpatial(e.key as 'ArrowUp' | 'ArrowDown' | 'ArrowLeft' | 'ArrowRight');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [enabled, onBack, onPlayPause]);
}

export function navigateSpatial(direction: 'ArrowUp' | 'ArrowDown' | 'ArrowLeft' | 'ArrowRight') {
  const focusables = Array.from(
    document.querySelectorAll<HTMLElement>(
      'button:not([disabled]), a[href]:not([disabled]), input:not([disabled]), [tabindex="0"]:not([disabled])'
    )
  ).filter((el) => {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== 'hidden';
  });

  if (focusables.length === 0) return;

  const current = (document.activeElement as HTMLElement) || focusables[0];
  const currentIndex = focusables.indexOf(current);

  if (currentIndex === -1) {
    focusables[0].focus();
    focusables[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  const currentRect = current.getBoundingClientRect();
  const currentCenter = {
    x: currentRect.left + currentRect.width / 2,
    y: currentRect.top + currentRect.height / 2,
  };

  let bestCandidate: HTMLElement | null = null;
  let bestDistance = Infinity;

  for (const candidate of focusables) {
    if (candidate === current) continue;

    const candRect = candidate.getBoundingClientRect();
    const candCenter = {
      x: candRect.left + candRect.width / 2,
      y: candRect.top + candRect.height / 2,
    };

    const dx = candCenter.x - currentCenter.x;
    const dy = candCenter.y - currentCenter.y;

    let isValidDirection = false;
    let primaryDistance = 0;
    let secondaryDistance = 0;

    switch (direction) {
      case 'ArrowUp':
        isValidDirection = dy < -10;
        primaryDistance = Math.abs(dy);
        secondaryDistance = Math.abs(dx);
        break;
      case 'ArrowDown':
        isValidDirection = dy > 10;
        primaryDistance = Math.abs(dy);
        secondaryDistance = Math.abs(dx);
        break;
      case 'ArrowLeft':
        isValidDirection = dx < -10;
        primaryDistance = Math.abs(dx);
        secondaryDistance = Math.abs(dy);
        break;
      case 'ArrowRight':
        isValidDirection = dx > 10;
        primaryDistance = Math.abs(dx);
        secondaryDistance = Math.abs(dy);
        break;
    }

    if (isValidDirection) {
      // Prioritize primary direction with lower weight on orthogonal deviation
      const totalScore = primaryDistance + secondaryDistance * 2.2;
      if (totalScore < bestDistance) {
        bestDistance = totalScore;
        bestCandidate = candidate;
      }
    }
  }

  if (bestCandidate) {
    bestCandidate.focus();
    bestCandidate.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
  } else {
    // Linear fallback if no spatial candidate in strict direction
    if (direction === 'ArrowRight' || direction === 'ArrowDown') {
      const next = focusables[(currentIndex + 1) % focusables.length];
      next.focus();
      next.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else if (direction === 'ArrowLeft' || direction === 'ArrowUp') {
      const prev = focusables[(currentIndex - 1 + focusables.length) % focusables.length];
      prev.focus();
      prev.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }
}
