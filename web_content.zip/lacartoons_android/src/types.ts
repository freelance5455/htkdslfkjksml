export interface SeriesItem {
  id: string;
  title: string;
  poster: string;
  network: string;
  year: string;
  rating: string;
}

export interface EpisodeItem {
  id: string;
  number: string;
  title: string;
  href: string;
}

export interface Season {
  seasonId: string;
  seasonName: string;
  episodes: EpisodeItem[];
}

export interface SeriesDetail {
  id: string;
  title: string;
  network: string;
  poster: string;
  backdrop: string;
  episodesCount: string;
  language: string;
  year: string;
  rating: string;
  synopsis: string;
  seasons: Season[];
}

export interface EpisodeDetail {
  id: string;
  season: string;
  seriesTitle: string;
  network: string;
  episodeTitle: string;
  iframeSrc: string;
  directVideos?: Array<{ label: string; url: string; quality: string }>;
  hlsUrl?: string | null;
  prevHref: string | null;
  nextHref: string | null;
  prevId: string | null;
  nextId: string | null;
}

export interface WatchProgress {
  serieId: string;
  serieTitle: string;
  poster: string;
  episodeId: string;
  episodeNumber: string;
  episodeTitle: string;
  season: string;
  updatedAt: number;
}

export interface Category {
  id: string;
  name: string;
  color: string;
  bgBadge: string;
  accent: string;
  iconName: string;
}

export type ViewTab = 'home' | 'categories' | 'search' | 'favorites' | 'history';
export type DeviceMode = 'tv' | 'mobile';
