import React, { useState } from 'react';
import { Play, Star, Heart, Tv } from 'lucide-react';
import { SeriesItem } from '../types';

interface SeriesCardProps {
  series: SeriesItem;
  isFavorite: boolean;
  onToggleFavorite: (e: React.MouseEvent, series: SeriesItem) => void;
  onClick: (series: SeriesItem) => void;
}

export const SeriesCard: React.FC<SeriesCardProps> = ({
  series,
  isFavorite,
  onToggleFavorite,
  onClick,
}) => {
  const [imgError, setImgError] = useState(false);

  // Pick accent badge color based on network
  const getNetworkBadge = (net: string) => {
    const lower = (net || '').toLowerCase();
    if (lower.includes('cartoon')) return 'bg-zinc-800 text-amber-300 border-zinc-700';
    if (lower.includes('hanna')) return 'bg-yellow-950/80 text-yellow-300 border-yellow-700/50';
    if (lower.includes('nickelodeon')) return 'bg-orange-950/80 text-orange-400 border-orange-700/50';
    if (lower.includes('fox')) return 'bg-red-950/80 text-red-400 border-red-700/50';
    if (lower.includes('disney')) return 'bg-blue-950/80 text-blue-300 border-blue-700/50';
    if (lower.includes('marvel')) return 'bg-rose-950/80 text-rose-300 border-rose-700/50';
    return 'bg-slate-800 text-slate-300 border-slate-700';
  };

  const posterSrc = imgError || !series.poster
    ? 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&auto=format&fit=crop&q=80'
    : series.poster;

  return (
    <div
      tabIndex={0}
      role="button"
      onClick={() => onClick(series)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick(series);
        }
      }}
      className="group relative flex flex-col bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800/80 hover:border-amber-500/60 focus:outline-none focus:ring-4 focus:ring-amber-400 focus:scale-[1.03] focus:shadow-2xl focus:shadow-amber-500/25 transition-all duration-200 cursor-pointer select-none text-left"
    >
      {/* Poster Image Container */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-slate-950">
        <img
          src={posterSrc}
          alt={series.title}
          loading="lazy"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover group-hover:scale-105 group-focus:scale-105 transition-transform duration-300"
        />

        {/* Gradient dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

        {/* Favorite heart button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(e, series);
          }}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full backdrop-blur-md transition-all ${
            isFavorite
              ? 'bg-rose-500/80 text-white shadow-lg shadow-rose-500/30 scale-105'
              : 'bg-black/50 hover:bg-black/80 text-slate-300 hover:text-white'
          }`}
          title={isFavorite ? 'Eliminar de favoritos' : 'Agregar a favoritos'}
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
        </button>

        {/* Play Button Overlay (Visible on hover and focus) */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity">
          <div className="w-12 h-12 rounded-full bg-amber-500/90 text-slate-950 flex items-center justify-center shadow-xl shadow-amber-500/40 transform group-hover:scale-110 group-focus:scale-110 transition-transform">
            <Play className="w-5 h-5 fill-slate-950 ml-0.5" />
          </div>
        </div>

        {/* Top left rating pill */}
        {series.rating && (
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded-lg border border-slate-700/60 text-[11px] font-bold text-amber-300">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>{series.rating}</span>
          </div>
        )}
      </div>

      {/* Series Metadata */}
      <div className="p-3 flex flex-col flex-1 justify-between bg-slate-900/90">
        <div>
          <h3 className="font-bold text-sm text-slate-100 line-clamp-2 group-hover:text-amber-400 group-focus:text-amber-400 transition-colors">
            {series.title}
          </h3>
        </div>

        <div className="flex items-center justify-between gap-1 mt-2.5 text-[11px] text-slate-400">
          <span className={`px-2 py-0.5 rounded-md border text-[10px] font-semibold truncate max-w-[130px] ${getNetworkBadge(series.network)}`}>
            {series.network || 'Retro'}
          </span>
          {series.year && (
            <span className="font-mono text-slate-400 text-[11px]">
              {series.year}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
