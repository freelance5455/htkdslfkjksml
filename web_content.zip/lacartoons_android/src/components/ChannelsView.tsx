import React from 'react';
import { Tv, Sparkles, Film } from 'lucide-react';
import { CATEGORIES } from '../services/api';

interface ChannelsViewProps {
  onSelectChannel: (categoryId: string) => void;
}

const CHANNELS_INFO = [
  {
    id: '2',
    name: 'Cartoon Network',
    era: 'Años 90 & 2000s',
    desc: 'El Laboratorio de Dexter, Coraje el Perro Cobarde, Las Chicas Superpoderosas, Ed Edd y Eddy, Billy y Mandy.',
    banner: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-zinc-800 text-white border-zinc-600',
  },
  {
    id: '4',
    name: 'Hanna Barbera',
    era: 'Clásicos de Oro 1960-1980',
    desc: 'Los Picapiedra, Scooby-Doo, Don Gato y su Pandilla, Los Supersónicos, Tom y Jerry, El Oso Yogui.',
    banner: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
  },
  {
    id: '1',
    name: 'Nickelodeon Retro',
    era: 'Años 90 & 2000s',
    desc: 'Rugrats, Hey Arnold!, Los Padrinos Mágicos, Bob Esponja, Rocket Power, La Vida Moderna de Rocko.',
    banner: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
  },
  {
    id: '3',
    name: 'Fox Kids',
    era: 'Generación Inolvidable',
    desc: 'Spider-Man 1994, X-Men Serie Animada, Power Rangers, El Mundo de Bobby, Digimon.',
    banner: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-red-500/20 text-red-300 border-red-500/40',
  },
  {
    id: '5',
    name: 'Disney Retro',
    era: 'Clásicos de la Televisión',
    desc: 'Patoaventuras, Chip y Dale al Rescate, Recreo, Las Nuevas Locuras del Emperador, Kim Possible.',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  },
  {
    id: '6',
    name: 'Warner Channel',
    era: 'Animación Clásica',
    desc: 'Batman La Serie Animada, Animaniacs, Pinky y Cerebro, Tiny Toons, Freakazoid.',
    banner: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
  },
  {
    id: '7',
    name: 'Marvel Clásicos',
    era: 'Superhéroes 80s y 90s',
    desc: 'Iron Man, Cuatro Fantásticos, Silver Surfer, El Increíble Hulk, Spider-Man Unlimited.',
    banner: 'https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
  },
  {
    id: '8',
    name: 'Otros Canales & Anime',
    era: 'Joyas Retro Internacionales',
    desc: 'Caballeros del Zodiaco, Ranma 1/2, Cazafantasmas, Transformers Clásicos y mucho más.',
    banner: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&auto=format&fit=crop&q=80',
    tagColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
  },
];

export const ChannelsView: React.FC<ChannelsViewProps> = ({ onSelectChannel }) => {
  return (
    <div className="py-6 px-4 lg:px-8 max-w-7xl mx-auto">
      <div className="mb-6 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
            <Tv className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black text-white">Canales & Creadores de Contenido</h1>
            <p className="text-xs text-slate-400">Selecciona tu canal favorito para explorar todas sus series retro</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {CHANNELS_INFO.map((chan) => (
          <div
            key={chan.id}
            tabIndex={0}
            role="button"
            onClick={() => onSelectChannel(chan.id)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelectChannel(chan.id);
              }
            }}
            className="group relative flex flex-col bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800 hover:border-amber-400 focus:outline-none focus:ring-4 focus:ring-amber-400 focus:scale-[1.03] transition-all cursor-pointer text-left"
          >
            <div className="relative h-32 w-full bg-slate-950 overflow-hidden">
              <img
                src={chan.banner}
                alt={chan.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent" />
              <div className="absolute top-3 left-3">
                <span className={`px-2 py-0.5 rounded-md border text-[10px] font-bold ${chan.tagColor}`}>
                  {chan.era}
                </span>
              </div>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-black text-base text-white group-hover:text-amber-400 transition-colors">
                  {chan.name}
                </h3>
                <p className="text-xs text-slate-300 mt-1 line-clamp-2">
                  {chan.desc}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-amber-400 font-semibold flex items-center gap-1 group-hover:underline">
                  Ver todas las series &rarr;
                </span>
                <Film className="w-4 h-4 text-slate-400 group-hover:text-amber-400 transition-colors" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
