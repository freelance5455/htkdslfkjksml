import React from 'react';
import { Heart, Trash2, Play } from 'lucide-react';
import { SeriesItem } from '../types';
import { SeriesCard } from './SeriesCard';

interface FavoritesViewProps {
  favorites: SeriesItem[];
  onSelectSeries: (series: SeriesItem) => void;
  onRemoveFavorite: (e: React.MouseEvent, series: SeriesItem) => void;
  onBrowseCatalog: () => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  favorites,
  onSelectSeries,
  onRemoveFavorite,
  onBrowseCatalog,
}) => {
  return (
    <div className="py-6 px-4 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center">
            <Heart className="w-5 h-5 text-rose-400 fill-rose-400" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black text-white">Mis Series Favoritas</h1>
            <p className="text-xs text-slate-400">Tus caricaturas retro guardadas para ver siempre</p>
          </div>
        </div>
        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300">
          {favorites.length} {favorites.length === 1 ? 'serie' : 'series'}
        </span>
      </div>

      {favorites.length === 0 ? (
        <div className="text-center py-20 px-4 bg-slate-900/40 rounded-3xl border border-dashed border-slate-800 max-w-lg mx-auto">
          <Heart className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">Aún no tienes favoritos</h3>
          <p className="text-xs text-slate-400 mb-6">
            Haz clic en el corazón en cualquier serie para guardarla en esta lista y verla más tarde.
          </p>
          <button
            onClick={onBrowseCatalog}
            className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/20"
          >
            Explorar Caricaturas
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {favorites.map((series) => (
            <SeriesCard
              key={series.id}
              series={series}
              isFavorite={true}
              onToggleFavorite={onRemoveFavorite}
              onClick={onSelectSeries}
            />
          ))}
        </div>
      )}
    </div>
  );
};
