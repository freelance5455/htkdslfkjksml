import React, { useState, useEffect } from 'react';
import { X, Play, Star, Heart, Calendar, Film, CheckCircle2, Tv, Sparkles, Loader2, ArrowLeft } from 'lucide-react';
import { SeriesDetail, EpisodeItem } from '../types';
import { fetchSeriesDetail } from '../services/api';

interface SeriesDetailModalProps {
  serieId: string | null;
  onClose: () => void;
  onPlayEpisode: (serie: SeriesDetail, episode: EpisodeItem, seasonId: string) => void;
  isFavorite: boolean;
  onToggleFavorite: (serie: { id: string; title: string; poster: string; network: string; year: string; rating: string }) => void;
  watchedEpisodeIds: Set<string>;
}

export const SeriesDetailModal: React.FC<SeriesDetailModalProps> = ({
  serieId,
  onClose,
  onPlayEpisode,
  isFavorite,
  onToggleFavorite,
  watchedEpisodeIds,
}) => {
  const [detail, setDetail] = useState<SeriesDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedSeasonIdx, setSelectedSeasonIdx] = useState(0);

  useEffect(() => {
    if (!serieId) {
      setDetail(null);
      return;
    }

    let isMounted = true;
    setLoading(true);
    setError(null);
    setSelectedSeasonIdx(0);

    fetchSeriesDetail(serieId)
      .then((data) => {
        if (isMounted) {
          setDetail(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Error al cargar serie');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [serieId]);

  if (!serieId) return null;

  const currentSeason = detail?.seasons?.[selectedSeasonIdx];
  const firstEpisode = detail?.seasons?.[0]?.episodes?.[0];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-0 md:p-4 animate-in fade-in">
      <div className="relative w-full max-w-5xl bg-slate-950 md:rounded-3xl border-0 md:border border-slate-800 shadow-2xl overflow-hidden min-h-screen md:min-h-0 md:max-h-[92vh] flex flex-col">
        {/* Close Button / Back */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 md:left-auto md:right-4 z-30 p-2.5 rounded-full bg-black/70 hover:bg-black text-white hover:text-amber-400 border border-slate-700/80 backdrop-blur-md transition-all focus:outline-none focus:ring-4 focus:ring-amber-400"
          title="Cerrar (o presiona Atrás en el mando)"
        >
          <X className="w-5 h-5 hidden md:block" />
          <div className="flex items-center gap-1.5 md:hidden text-xs font-semibold">
            <ArrowLeft className="w-4 h-4" />
            <span>Volver</span>
          </div>
        </button>

        {loading ? (
          <div className="flex flex-col items-center justify-center p-24 text-center flex-1">
            <Loader2 className="w-12 h-12 text-amber-400 animate-spin mb-4" />
            <p className="text-slate-300 font-medium">Cargando serie desde LACartoons...</p>
            <p className="text-xs text-slate-400 mt-1">Conectando sin publicidad</p>
          </div>
        ) : error || !detail ? (
          <div className="p-12 text-center flex-1 flex flex-col items-center justify-center">
            <p className="text-rose-400 text-lg font-semibold mb-2">No se pudo cargar la serie</p>
            <p className="text-sm text-slate-400 mb-6">{error}</p>
            <button
              onClick={onClose}
              className="px-6 py-2 rounded-xl bg-slate-800 text-white font-medium hover:bg-slate-700"
            >
              Volver al catálogo
            </button>
          </div>
        ) : (
          <div className="overflow-y-auto flex-1 custom-scrollbar">
            {/* Hero Backdrop Banner */}
            <div className="relative h-64 md:h-80 w-full overflow-hidden bg-slate-900">
              <img
                src={detail.backdrop || detail.poster}
                alt={detail.title}
                className="w-full h-full object-cover object-top opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent" />

              {/* Header inside Hero */}
              <div className="absolute bottom-4 left-4 right-4 md:left-8 md:right-8 flex flex-col md:flex-row items-start md:items-end gap-4">
                {/* Poster on desktop */}
                <div className="hidden md:block w-32 h-44 rounded-xl overflow-hidden border-2 border-slate-700 shadow-xl flex-shrink-0 bg-slate-900">
                  <img src={detail.poster} alt={detail.title} className="w-full h-full object-cover" />
                </div>

                {/* Title & Badges */}
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500 text-slate-950">
                      {detail.network || 'Retro'}
                    </span>
                    <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-900/90 text-amber-300 border border-slate-700">
                      {detail.language}
                    </span>
                    {detail.year && (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-900/80 text-slate-300 border border-slate-800">
                        <Calendar className="w-3 h-3" />
                        {detail.year}
                      </span>
                    )}
                    {detail.rating && (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-900/80 text-amber-300 border border-slate-800">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        {detail.rating}/10
                      </span>
                    )}
                  </div>

                  <h1 className="text-2xl md:text-4xl font-black text-white tracking-wide">
                    {detail.title}
                  </h1>

                  <p className="text-xs md:text-sm text-slate-300 mt-2 line-clamp-3 max-w-3xl">
                    {detail.synopsis || 'Disfruta de esta caricatura clásica en excelente calidad con doblaje latino original.'}
                  </p>
                </div>

                {/* Primary Actions */}
                <div className="flex items-center gap-2 w-full md:w-auto">
                  {firstEpisode && (
                    <button
                      onClick={() => onPlayEpisode(detail, firstEpisode, detail.seasons[0]?.seasonId || '1')}
                      className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/30 transition-all focus:outline-none focus:ring-4 focus:ring-amber-300 focus:scale-105 active:scale-95"
                    >
                      <Play className="w-5 h-5 fill-slate-950" />
                      <span>Ver Capítulo 1</span>
                    </button>
                  )}

                  <button
                    onClick={() =>
                      onToggleFavorite({
                        id: detail.id,
                        title: detail.title,
                        poster: detail.poster,
                        network: detail.network,
                        year: detail.year,
                        rating: detail.rating,
                      })
                    }
                    className={`p-3 rounded-xl border transition-all focus:outline-none focus:ring-4 focus:ring-amber-400 ${
                      isFavorite
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                        : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:text-white'
                    }`}
                    title={isFavorite ? 'En tus favoritos' : 'Añadir a favoritos'}
                  >
                    <Heart className={`w-5 h-5 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>
                </div>
              </div>
            </div>

            {/* Episodes List Section */}
            <div className="p-4 md:p-8">
              {/* Seasons Selector (if > 1 season) */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-6">
                <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
                  {detail.seasons.map((season, idx) => (
                    <button
                      key={season.seasonId}
                      onClick={() => setSelectedSeasonIdx(idx)}
                      className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold tracking-wide transition-all border focus:outline-none focus:ring-4 focus:ring-amber-400 ${
                        selectedSeasonIdx === idx
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
                          : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {season.seasonName}
                      <span className="ml-1.5 opacity-80 text-[11px]">
                        ({season.episodes.length} caps)
                      </span>
                    </button>
                  ))}
                </div>

                <div className="text-xs text-slate-400 hidden sm:block">
                  Total episodios: <span className="text-amber-400 font-bold">{detail.episodesCount || detail.seasons.reduce((a, s) => a + s.episodes.length, 0)}</span>
                </div>
              </div>

              {/* Episodes Grid */}
              {currentSeason?.episodes && currentSeason.episodes.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {currentSeason.episodes.map((ep, idx) => {
                    const isWatched = watchedEpisodeIds.has(ep.id);
                    return (
                      <button
                        key={ep.id}
                        onClick={() => onPlayEpisode(detail, ep, currentSeason.seasonId)}
                        className="group relative flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800/90 hover:border-amber-400/80 focus:outline-none focus:ring-4 focus:ring-amber-400 focus:scale-[1.02] focus:shadow-xl focus:shadow-amber-500/20 text-left transition-all duration-150"
                      >
                        <div className="flex items-center gap-3 min-w-0 pr-2">
                          <div className="w-9 h-9 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center flex-shrink-0 text-xs font-bold text-slate-300 group-hover:text-amber-400 group-hover:border-amber-500/50 transition-colors">
                            {idx + 1}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-200 group-hover:text-amber-300 line-clamp-2 transition-colors">
                              {ep.title}
                            </p>
                            <span className="text-[10px] text-slate-400 mt-0.5 block">
                              {ep.number || `Capítulo ${idx + 1}`}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          {isWatched && (
                            <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-1.5 py-0.5 rounded-md" title="Episodio visto">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              <span className="hidden sm:inline">Visto</span>
                            </span>
                          )}
                          <div className="w-8 h-8 rounded-lg bg-amber-500/10 group-hover:bg-amber-500 text-amber-400 group-hover:text-slate-950 flex items-center justify-center transition-colors">
                            <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center text-slate-400 bg-slate-900/40 rounded-2xl">
                  No se encontraron episodios listados para esta temporada.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
