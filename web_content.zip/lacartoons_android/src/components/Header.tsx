import React from 'react';
import { Tv, Smartphone, Search, Heart, Clock, Radio, Sparkles, SlidersHorizontal } from 'lucide-react';
import { DeviceMode, ViewTab } from '../types';

interface HeaderProps {
  deviceMode: DeviceMode;
  onToggleDeviceMode: () => void;
  activeTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSearchSubmit: (e: React.FormEvent) => void;
  onOpenRemote: () => void;
  isRemoteOpen: boolean;
  favoritesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  deviceMode,
  onToggleDeviceMode,
  activeTab,
  onSelectTab,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  onOpenRemote,
  isRemoteOpen,
  favoritesCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Logo and Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2.5 text-left group focus:outline-none focus:ring-2 focus:ring-amber-400 rounded-lg p-1 transition-transform"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 p-0.5 shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Tv className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-300 to-amber-200">
                  LACARTOONS
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  LATINO
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Series & Caricaturas Retro de la TV
              </p>
            </div>
          </button>
        </div>

        {/* Center: Search input */}
        <div className="flex-1 max-w-md mx-2">
          <form onSubmit={onSearchSubmit} className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Buscar serie (ej. Scooby, Caballeros, Coraje)..."
              className="w-full bg-slate-900/90 border border-slate-700/80 rounded-full pl-10 pr-4 py-2 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white px-1.5 py-0.5 rounded bg-slate-800"
              >
                Limpiar
              </button>
            )}
          </form>
        </div>

        {/* Navigation Tabs (Desktop & TV) */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => onSelectTab('home')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'home'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            Inicio
          </button>
          <button
            onClick={() => onSelectTab('categories')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'categories'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            Canales
          </button>
          <button
            onClick={() => onSelectTab('favorites')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-all ${
              activeTab === 'favorites'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-rose-400" />
            <span>Favoritos</span>
            {favoritesCount > 0 && (
              <span className="text-[10px] bg-rose-500/30 text-rose-300 px-1.5 py-0.2 rounded-full">
                {favoritesCount}
              </span>
            )}
          </button>
          <button
            onClick={() => onSelectTab('history')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-all ${
              activeTab === 'history'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            <span>Historial</span>
          </button>
        </nav>

        {/* Right Action buttons: Creator Badge, TV Mode & Virtual Remote */}
        <div className="flex items-center gap-2">
          {/* Creator Badge: by Josué flores with Bubu and Dudu */}
          <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-pink-500/10 to-amber-500/15 border border-amber-500/30 shadow-md select-none">
            <div className="relative w-8 h-8 rounded-full overflow-hidden border-2 border-amber-400 shadow-sm flex-shrink-0 bg-white">
              <img src="/bubu-dudu.jpg" alt="Bubu y Dudu" className="w-full h-full object-cover scale-105" />
            </div>
            <div className="flex flex-col text-left pr-1">
              <span className="text-[9px] text-amber-300 font-bold uppercase tracking-wider leading-none">by</span>
              <span className="text-xs font-black text-white tracking-wide leading-tight">Josué flores</span>
            </div>
          </div>

          {/* Virtual Remote button */}
          <button
            onClick={onOpenRemote}
            className={`p-2 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition-all ${
              isRemoteOpen
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-lg shadow-amber-500/20'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border-slate-700'
            }`}
            title="Abrir mando a distancia virtual para pruebas"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span className="hidden xl:inline">Mando TV</span>
          </button>

          {/* Toggle Device Mode */}
          <button
            onClick={onToggleDeviceMode}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
              deviceMode === 'tv'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/20 ring-1 ring-amber-400'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700'
            }`}
            title={deviceMode === 'tv' ? 'Cambiado a Modo Android TV (D-Pad activado)' : 'Cambiado a Modo Móvil/Táctil'}
          >
            {deviceMode === 'tv' ? (
              <>
                <Tv className="w-4 h-4 text-amber-400 animate-pulse" />
                <span className="hidden sm:inline">Modo Android TV</span>
              </>
            ) : (
              <>
                <Smartphone className="w-4 h-4 text-sky-400" />
                <span className="hidden sm:inline">Modo Móvil</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
