import React from 'react';
import { Play, Clock, Trash2 } from 'lucide-react';
import { WatchProgress } from '../types';

interface ContinueWatchingRowProps {
  items: WatchProgress[];
  onPlayEpisode: (item: WatchProgress) => void;
  onClearItem: (e: React.MouseEvent, serieId: string) => void;
}

export const ContinueWatchingRow: React.FC<ContinueWatchingRowProps> = ({
  items,
  onPlayEpisode,
  onClearItem,
}) => {
  if (items.length === 0) return null;

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-3 px-4 lg:px-0">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-bold text-white tracking-wide">
            Continuar Viendo
          </h2>
          <span className="text-xs bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded-full font-medium">
            {items.length} en progreso
          </span>
        </div>
      </div>

      <div className="flex gap-3 overflow-x-auto no-scrollbar pb-3 px-4 lg:px-0">
        {items.map((item) => (
          <div
            key={item.serieId}
            tabIndex={0}
            role="button"
            onClick={() => onPlayEpisode(item)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onPlayEpisode(item);
              }
            }}
            className="group relative flex-shrink-0 w-64 bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 hover:border-amber-400 focus:outline-none focus:ring-4 focus:ring-amber-400 focus:scale-105 transition-all text-left cursor-pointer"
          >
            {/* Banner/Thumbnail */}
            <div className="relative h-32 w-full bg-slate-950 overflow-hidden">
              <img
                src={item.poster || 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&auto=format&fit=crop&q=80'}
                alt={item.serieTitle}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

              {/* Play overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-10 h-10 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-4 h-4 fill-slate-950 ml-0.5" />
                </div>
              </div>

              {/* Remove button */}
              <button
                type="button"
                onClick={(e) => onClearItem(e, item.serieId)}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-black/60 hover:bg-rose-900/80 text-slate-300 hover:text-white transition-colors"
                title="Quitar de continuar viendo"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Episode info */}
            <div className="p-3">
              <h3 className="font-bold text-xs text-white truncate">
                {item.serieTitle}
              </h3>
              <p className="text-[11px] text-amber-400 font-medium truncate mt-0.5">
                {item.episodeNumber ? `${item.episodeNumber} ` : ''} {item.episodeTitle}
              </p>
              <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2.5 overflow-hidden">
                <div className="bg-amber-400 h-full w-2/3 rounded-full" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
