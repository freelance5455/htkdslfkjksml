import React from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, CornerDownLeft, Play, X, ArrowLeft, Tv } from 'lucide-react';
import { navigateSpatial } from '../hooks/useTvRemote';

interface VirtualTvRemoteProps {
  isOpen: boolean;
  onClose: () => void;
  onBack: () => void;
  onPlayPause: () => void;
}

export const VirtualTvRemote: React.FC<VirtualTvRemoteProps> = ({
  isOpen,
  onClose,
  onBack,
  onPlayPause,
}) => {
  if (!isOpen) return null;

  const triggerKey = (key: string, keyCode: number) => {
    const event = new KeyboardEvent('keydown', {
      key,
      keyCode,
      which: keyCode,
      bubbles: true,
      cancelable: true,
    });
    window.dispatchEvent(event);
  };

  const handleOk = () => {
    const active = document.activeElement as HTMLElement | null;
    if (active) {
      active.click();
    } else {
      triggerKey('Enter', 13);
    }
  };

  return (
    <div className="fixed bottom-20 right-4 z-50 flex flex-col items-center bg-slate-900/95 border-2 border-amber-500/60 rounded-3xl p-4 shadow-2xl shadow-black/80 backdrop-blur-md w-60 select-none animate-in fade-in zoom-in-95">
      {/* Remote header */}
      <div className="flex items-center justify-between w-full pb-2 mb-2 border-b border-slate-800">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400">
          <Tv className="w-3.5 h-3.5 text-amber-400" />
          <span>Control Android TV</span>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors"
          title="Cerrar control virtual"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <p className="text-[10px] text-slate-400 mb-3 text-center">
        Navega con flechas y OK como en tu televisor
      </p>

      {/* D-Pad */}
      <div className="relative w-40 h-40 bg-slate-950 rounded-full border border-slate-700/80 shadow-inner flex items-center justify-center p-2 mb-4">
        {/* Up */}
        <button
          onClick={() => navigateSpatial('ArrowUp')}
          className="absolute top-2 left-1/2 -translate-x-1/2 w-11 h-11 flex items-center justify-center text-slate-300 hover:text-amber-400 active:scale-90 transition-all rounded-full hover:bg-slate-800"
          aria-label="Arriba"
        >
          <ChevronUp className="w-6 h-6" />
        </button>

        {/* Down */}
        <button
          onClick={() => navigateSpatial('ArrowDown')}
          className="absolute bottom-2 left-1/2 -translate-x-1/2 w-11 h-11 flex items-center justify-center text-slate-300 hover:text-amber-400 active:scale-90 transition-all rounded-full hover:bg-slate-800"
          aria-label="Abajo"
        >
          <ChevronDown className="w-6 h-6" />
        </button>

        {/* Left */}
        <button
          onClick={() => navigateSpatial('ArrowLeft')}
          className="absolute left-2 top-1/2 -translate-y-1/2 w-11 h-11 flex items-center justify-center text-slate-300 hover:text-amber-400 active:scale-90 transition-all rounded-full hover:bg-slate-800"
          aria-label="Izquierda"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* Right */}
        <button
          onClick={() => navigateSpatial('ArrowRight')}
          className="absolute right-2 top-1/2 -translate-y-1/2 w-11 h-11 flex items-center justify-center text-slate-300 hover:text-amber-400 active:scale-90 transition-all rounded-full hover:bg-slate-800"
          aria-label="Derecha"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        {/* OK Center Button */}
        <button
          onClick={handleOk}
          className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 font-black text-sm flex items-center justify-center shadow-lg shadow-amber-500/30 hover:brightness-110 active:scale-95 transition-all"
        >
          OK
        </button>
      </div>

      {/* Action buttons (Back, Play, Home) */}
      <div className="grid grid-cols-2 gap-2 w-full">
        <button
          onClick={onBack}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium active:scale-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4 text-rose-400" />
          <span>Atrás</span>
        </button>

        <button
          onClick={onPlayPause}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium active:scale-95 transition-all"
        >
          <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
          <span>Play/Pausa</span>
        </button>
      </div>
    </div>
  );
};
