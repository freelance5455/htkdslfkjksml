import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  SkipBack,
  SkipForward,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  List,
  Moon,
  ExternalLink,
  Loader2,
  Tv,
  Sparkles,
  Settings,
  RefreshCw,
  Radio,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import { SeriesDetail, EpisodeItem, EpisodeDetail } from '../types';
import { fetchEpisodeDetail } from '../services/api';

interface VideoPlayerModalProps {
  serie: SeriesDetail;
  episode: EpisodeItem;
  seasonId: string;
  onClose: () => void;
  onSelectEpisode: (ep: EpisodeItem, seasonId: string) => void;
  onMarkWatched: (episodeId: string) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  serie,
  episode,
  seasonId,
  onClose,
  onSelectEpisode,
  onMarkWatched,
}) => {
  const [episodeDetail, setEpisodeDetail] = useState<EpisodeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Engine: 'native' (HTML5 video using direct MP4 stream) or 'iframe' (embedded player)
  const [playerEngine, setPlayerEngine] = useState<'native' | 'iframe'>('native');
  const [selectedQualityIdx, setSelectedQualityIdx] = useState(0);

  // Native player states
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isBuffering, setIsBuffering] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showControls, setShowControls] = useState(true);

  // UI features
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showEpisodeDrawer, setShowEpisodeDrawer] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepRemaining, setSleepRemaining] = useState<number | null>(null);
  const [autoNext, setAutoNext] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Load episode details and direct streams
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);
    setCurrentTime(0);
    setDuration(0);

    fetchEpisodeDetail(episode.id, seasonId)
      .then((data) => {
        if (!isMounted) return;
        setEpisodeDetail(data);
        setLoading(false);
        onMarkWatched(episode.id);

        // Decide player engine: if direct videos exist, use native; otherwise iframe
        if (data.directVideos && data.directVideos.length > 0) {
          setPlayerEngine('native');
          // Pick best quality (SD or first)
          const sdIdx = data.directVideos.findIndex((v) => v.quality === 'sd');
          setSelectedQualityIdx(sdIdx >= 0 ? sdIdx : 0);
        } else {
          setPlayerEngine('iframe');
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        setError(err.message || 'Error al conectar el reproductor');
        setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [episode.id, seasonId]);

  // Current season and navigation
  const currentSeason = serie.seasons.find((s) => s.seasonId === seasonId) || serie.seasons[0];
  const episodesList = currentSeason?.episodes || [];
  const currentEpIdx = episodesList.findIndex((ep) => ep.id === episode.id);

  const prevEpisode = currentEpIdx > 0 ? episodesList[currentEpIdx - 1] : null;
  const nextEpisode = currentEpIdx < episodesList.length - 1 ? episodesList[currentEpIdx + 1] : null;

  // Handle auto-hide controls
  const resetControlsTimeout = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying && !showEpisodeDrawer && !showSettingsMenu) {
        setShowControls(false);
      }
    }, 4000);
  };

  useEffect(() => {
    const handleMouseMove = () => resetControlsTimeout();
    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    };
  }, [isPlaying, showEpisodeDrawer, showSettingsMenu]);

  // Handle keyboard remote navigation inside video player
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      resetControlsTimeout();

      if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 10009 || e.keyCode === 4) {
        if (showEpisodeDrawer) {
          setShowEpisodeDrawer(false);
          e.preventDefault();
          return;
        }
        if (showSettingsMenu) {
          setShowSettingsMenu(false);
          e.preventDefault();
          return;
        }
        e.preventDefault();
        onClose();
        return;
      }

      if (playerEngine === 'native' && videoRef.current) {
        if (e.key === ' ' || e.key === 'MediaPlayPause') {
          e.preventDefault();
          togglePlay();
        } else if (e.key === 'ArrowLeft') {
          e.preventDefault();
          seekDelta(-10);
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          seekDelta(10);
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          changeVolume(0.1);
        } else if (e.key === 'ArrowDown') {
          e.preventDefault();
          changeVolume(-0.1);
        } else if (e.key === 'f' || e.key === 'F') {
          e.preventDefault();
          toggleFullscreen();
        } else if (e.key === 'm' || e.key === 'M') {
          e.preventDefault();
          toggleMute();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playerEngine, isPlaying, showEpisodeDrawer, showSettingsMenu, onClose]);

  // Handle sleep timer countdown
  useEffect(() => {
    if (sleepTimerMinutes === null) {
      setSleepRemaining(null);
      return;
    }

    setSleepRemaining(sleepTimerMinutes * 60);
    const interval = setInterval(() => {
      setSleepRemaining((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          onClose();
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerMinutes, onClose]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().catch((err) => {
        console.warn('Fullscreen request failed:', err);
      });
    } else {
      document.exitFullscreen?.().catch((err) => {
        console.warn('Exit fullscreen failed:', err);
      });
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch((e) => console.warn('Play error:', e));
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const seekDelta = (seconds: number) => {
    if (!videoRef.current) return;
    const target = Math.min(Math.max(0, videoRef.current.currentTime + seconds), duration || 10000);
    videoRef.current.currentTime = target;
    setCurrentTime(target);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
    setCurrentTime(time);
  };

  const changeVolume = (delta: number) => {
    if (!videoRef.current) return;
    const newVol = Math.min(Math.max(0, videoRef.current.volume + delta), 1);
    videoRef.current.volume = newVol;
    setVolume(newVol);
    setIsMuted(newVol === 0);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleRateChange = (rate: number) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
    setPlaybackRate(rate);
    setShowSettingsMenu(false);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handlePrev = () => {
    if (prevEpisode) onSelectEpisode(prevEpisode, seasonId);
  };

  const handleNext = () => {
    if (nextEpisode) onSelectEpisode(nextEpisode, seasonId);
  };

  const cycleSleepTimer = () => {
    if (sleepTimerMinutes === null) setSleepTimerMinutes(15);
    else if (sleepTimerMinutes === 15) setSleepTimerMinutes(30);
    else if (sleepTimerMinutes === 30) setSleepTimerMinutes(45);
    else if (sleepTimerMinutes === 45) setSleepTimerMinutes(60);
    else setSleepTimerMinutes(null);
  };

  const activeDirectVideo = episodeDetail?.directVideos?.[selectedQualityIdx];

  return (
    <div
      ref={containerRef}
      onMouseMove={resetControlsTimeout}
      onClick={resetControlsTimeout}
      className={`fixed inset-0 z-50 bg-black flex flex-col select-none overflow-hidden ${
        isFullscreen ? 'w-screen h-screen' : ''
      }`}
    >
      {/* Top Header Bar */}
      <header
        className={`transition-opacity duration-300 z-30 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/90 via-black/60 to-transparent ${
          showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 focus:outline-none focus:ring-4 focus:ring-amber-400 transition-all"
            title="Volver a la serie (Esc o Atrás)"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white truncate max-w-xs md:max-w-md">
                {serie.title}
              </span>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-bold uppercase">
                {serie.network}
              </span>
            </div>
            <p className="text-xs text-slate-300 truncate mt-0.5">
              {episode.number ? `${episode.number} ` : ''}
              <span className="text-amber-300 font-semibold">{episode.title}</span>
            </p>
          </div>
        </div>

        {/* Top Right Actions */}
        <div className="flex items-center gap-2">
          {/* Player Engine Switcher Pills */}
          <div className="flex items-center bg-slate-900/90 border border-slate-800 p-1 rounded-xl">
            {episodeDetail?.directVideos && episodeDetail.directVideos.length > 0 && (
              <button
                onClick={() => setPlayerEngine('native')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  playerEngine === 'native'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Reproductor nativo HTML5 (Sin publicidad ni bloqueos)"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Nativo MP4</span>
              </button>
            )}

            <button
              onClick={() => setPlayerEngine('iframe')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                playerEngine === 'iframe'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Reproductor web embebido oficial"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Web Iframe</span>
            </button>
          </div>

          {/* Sleep Timer */}
          <button
            onClick={cycleSleepTimer}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              sleepTimerMinutes !== null
                ? 'bg-purple-950 text-purple-300 border-purple-500'
                : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title="Temporizador de apagado"
          >
            <Moon className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">
              {sleepRemaining !== null ? `Apagar: ${formatTime(sleepRemaining)}` : 'Apagado'}
            </span>
          </button>

          {/* Episodes Drawer Toggle */}
          <button
            onClick={() => setShowEpisodeDrawer(!showEpisodeDrawer)}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
              showEpisodeDrawer
                ? 'bg-amber-500 text-slate-950 border-amber-400'
                : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:text-white'
            }`}
            title="Lista de episodios"
          >
            <List className="w-4 h-4" />
            <span className="hidden md:inline">Capítulos</span>
          </button>

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 focus:outline-none focus:ring-4 focus:ring-amber-400"
            title="Pantalla completa"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Video Presentation Arena */}
      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        {loading ? (
          <div className="flex flex-col items-center justify-center text-center p-8">
            <Loader2 className="w-12 h-12 text-amber-400 animate-spin mb-4" />
            <p className="text-white font-bold text-base">Cargando video de LACartoons...</p>
            <p className="text-xs text-slate-400 mt-1">Conectando a {serie.title} en español latino</p>
          </div>
        ) : error ? (
          <div className="p-8 text-center max-w-md bg-slate-900/80 rounded-3xl border border-slate-800">
            <p className="text-rose-400 font-bold text-lg mb-2">No se pudo cargar el video</p>
            <p className="text-xs text-slate-400 mb-6">{error}</p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-medium"
              >
                Volver
              </button>
              {nextEpisode && (
                <button
                  onClick={handleNext}
                  className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold"
                >
                  Siguiente capítulo
                </button>
              )}
            </div>
          </div>
        ) : playerEngine === 'native' && activeDirectVideo ? (
          /* ENGINE 1: NATIVE HTML5 VIDEO PLAYER (MP4 RANGE STREAMING) */
          <div className="relative w-full h-full flex items-center justify-center group">
            <video
              ref={videoRef}
              src={activeDirectVideo.url}
              playsInline
              autoPlay
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onTimeUpdate={() => {
                if (videoRef.current) {
                  setCurrentTime(videoRef.current.currentTime);
                }
              }}
              onLoadedMetadata={() => {
                if (videoRef.current) {
                  setDuration(videoRef.current.duration);
                }
              }}
              onWaiting={() => setIsBuffering(true)}
              onPlaying={() => setIsBuffering(false)}
              onEnded={() => {
                setIsPlaying(false);
                if (autoNext && nextEpisode) {
                  handleNext();
                }
              }}
              onError={(e) => {
                console.warn('Native video error, switching to iframe fallback:', e);
                setPlayerEngine('iframe');
              }}
              onClick={togglePlay}
              className="w-full h-full object-contain cursor-pointer"
            />

            {/* Buffering Spinner */}
            {isBuffering && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none">
                <Loader2 className="w-14 h-14 text-amber-400 animate-spin" />
              </div>
            )}

            {/* Center Big Play/Pause Splash on Click */}
            {!isPlaying && !isBuffering && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 m-auto w-20 h-20 rounded-full bg-amber-500/90 text-slate-950 flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all z-20"
              >
                <Play className="w-10 h-10 fill-slate-950 ml-1" />
              </button>
            )}

            {/* Bottom Controls Bar for Native Player */}
            <div
              className={`absolute bottom-0 left-0 right-0 z-30 bg-gradient-to-t from-black/95 via-black/80 to-transparent p-4 transition-opacity duration-300 ${
                showControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
              }`}
            >
              {/* Progress Bar Scrubber */}
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-mono text-slate-300 min-w-[45px] text-right">
                  {formatTime(currentTime)}
                </span>
                <div className="relative flex-1 flex items-center group/scrub">
                  <input
                    type="range"
                    min={0}
                    max={duration || 100}
                    step={0.5}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400"
                  />
                </div>
                <span className="text-xs font-mono text-slate-400 min-w-[45px]">
                  {formatTime(duration)}
                </span>
              </div>

              {/* Bottom Control Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {/* Prev Episode */}
                  <button
                    onClick={handlePrev}
                    disabled={!prevEpisode}
                    className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white disabled:opacity-30 disabled:pointer-events-none transition-all focus:outline-none focus:ring-2 focus:ring-amber-400"
                    title="Capítulo anterior"
                  >
                    <SkipBack className="w-5 h-5" />
                  </button>

                  {/* Rewind 10s */}
                  <button
                    onClick={() => seekDelta(-10)}
                    className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white transition-all flex items-center gap-1 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-amber-400"
                    title="Retroceder 10 segundos"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>10s</span>
                  </button>

                  {/* Play / Pause */}
                  <button
                    onClick={togglePlay}
                    className="p-3 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all shadow-lg shadow-amber-500/30 focus:outline-none focus:ring-4 focus:ring-amber-300"
                    title={isPlaying ? 'Pausa (Espacio o OK)' : 'Reproducir (Espacio o OK)'}
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5 fill-slate-950" />
                    ) : (
                      <Play className="w-5 h-5 fill-slate-950 ml-0.5" />
                    )}
                  </button>

                  {/* Fast Forward 10s */}
                  <button
                    onClick={() => seekDelta(10)}
                    className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white transition-all flex items-center gap-1 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-amber-400"
                    title="Adelantar 10 segundos"
                  >
                    <span>10s</span>
                    <RotateCw className="w-4 h-4" />
                  </button>

                  {/* Next Episode */}
                  <button
                    onClick={handleNext}
                    disabled={!nextEpisode}
                    className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white disabled:opacity-30 disabled:pointer-events-none transition-all focus:outline-none focus:ring-2 focus:ring-amber-400"
                    title="Siguiente capítulo"
                  >
                    <SkipForward className="w-5 h-5" />
                  </button>

                  {/* Volume Control */}
                  <div className="flex items-center gap-1.5 ml-2">
                    <button
                      onClick={toggleMute}
                      className="p-2 text-slate-300 hover:text-white"
                      title={isMuted ? 'Activar sonido (M)' : 'Silenciar (M)'}
                    >
                      {isMuted || volume === 0 ? (
                        <VolumeX className="w-4 h-4 text-rose-400" />
                      ) : (
                        <Volume2 className="w-4 h-4" />
                      )}
                    </button>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={isMuted ? 0 : volume}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setVolume(val);
                        setIsMuted(val === 0);
                        if (videoRef.current) {
                          videoRef.current.volume = val;
                          videoRef.current.muted = false;
                        }
                      }}
                      className="w-16 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400 hidden sm:block"
                    />
                  </div>
                </div>

                {/* Right controls: Quality, Speed, AutoNext */}
                <div className="flex items-center gap-2">
                  {/* Quality selector dropdown */}
                  {episodeDetail?.directVideos && episodeDetail.directVideos.length > 1 && (
                    <div className="relative">
                      <select
                        value={selectedQualityIdx}
                        onChange={(e) => {
                          const idx = parseInt(e.target.value, 10);
                          const curTime = videoRef.current?.currentTime || 0;
                          setSelectedQualityIdx(idx);
                          setTimeout(() => {
                            if (videoRef.current) {
                              videoRef.current.currentTime = curTime;
                              videoRef.current.play();
                            }
                          }, 150);
                        }}
                        className="bg-slate-900 border border-slate-700 text-slate-200 text-xs font-semibold rounded-xl px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400"
                      >
                        {episodeDetail.directVideos.map((v, idx) => (
                          <option key={v.quality} value={idx}>
                            {v.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Speed button */}
                  <div className="relative">
                    <button
                      onClick={() => setShowSettingsMenu(!showSettingsMenu)}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-bold text-slate-300"
                    >
                      {playbackRate}x
                    </button>
                    {showSettingsMenu && (
                      <div className="absolute bottom-10 right-0 bg-slate-900 border border-slate-700 rounded-2xl p-2 shadow-2xl z-40 min-w-[100px] flex flex-col gap-1">
                        <span className="text-[10px] text-slate-400 px-2 py-1 font-bold">Velocidad</span>
                        {[0.75, 1, 1.25, 1.5, 2].map((r) => (
                          <button
                            key={r}
                            onClick={() => handleRateChange(r)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold text-left ${
                              playbackRate === r ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-200 hover:bg-slate-800'
                            }`}
                          >
                            {r}x
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Auto-Next toggle */}
                  <button
                    onClick={() => setAutoNext(!autoNext)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border hidden sm:flex items-center gap-1.5 transition-all ${
                      autoNext
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-600/60'
                        : 'bg-slate-900 text-slate-400 border-slate-800'
                    }`}
                    title="Reproducir siguiente capítulo automáticamente al terminar"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>Auto-Sig</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* ENGINE 2: UN-RESTRICTED CLEAN IFRAME PLAYER */
          <div className="relative w-full h-full flex items-center justify-center">
            {episodeDetail?.iframeSrc ? (
              <iframe
                src={episodeDetail.iframeSrc}
                title={`${serie.title} - ${episode.title}`}
                className="w-full h-full border-0"
                allowFullScreen
                allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
              />
            ) : (
              <div className="text-center p-8">
                <p className="text-slate-300 font-semibold mb-2">No hay fuente de video disponible</p>
                <button onClick={onClose} className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold">
                  Volver al catálogo
                </button>
              </div>
            )}

            {/* Quick Next/Prev floating bar for iframe mode */}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none">
              <div className="pointer-events-auto flex items-center gap-2 bg-slate-950/90 backdrop-blur-md px-3 py-2 rounded-2xl border border-slate-800">
                <button
                  onClick={handlePrev}
                  disabled={!prevEpisode}
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white disabled:opacity-30 disabled:pointer-events-none"
                  title="Capítulo anterior"
                >
                  <SkipBack className="w-4 h-4" />
                </button>
                <span className="text-xs font-bold text-slate-200 px-2">
                  {currentEpIdx + 1} / {episodesList.length}
                </span>
                <button
                  onClick={handleNext}
                  disabled={!nextEpisode}
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white disabled:opacity-30 disabled:pointer-events-none"
                  title="Siguiente capítulo"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>

              {episodeDetail?.iframeSrc && (
                <div className="pointer-events-auto flex items-center gap-2">
                  <a
                    href={episodeDetail.iframeSrc}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950/90 hover:bg-slate-900 text-slate-200 border border-slate-800 text-xs font-bold backdrop-blur-md"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                    <span>Abrir Directo</span>
                  </a>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Side Episode Drawer */}
        {showEpisodeDrawer && (
          <aside className="absolute top-0 right-0 bottom-0 w-80 bg-slate-950/98 border-l border-slate-800 backdrop-blur-2xl z-40 flex flex-col p-4 shadow-2xl animate-in slide-in-from-right duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div>
                <h4 className="font-bold text-sm text-white">Todos los Capítulos</h4>
                <p className="text-[11px] text-slate-400">
                  {currentSeason.seasonName} ({episodesList.length} episodios)
                </p>
              </div>
              <button
                onClick={() => setShowEpisodeDrawer(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto flex-1 space-y-1.5 custom-scrollbar pr-1">
              {episodesList.map((ep, idx) => {
                const isCurrent = ep.id === episode.id;
                return (
                  <button
                    key={ep.id}
                    onClick={() => {
                      onSelectEpisode(ep, seasonId);
                      setShowEpisodeDrawer(false);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all ${
                      isCurrent
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20'
                        : 'bg-slate-900/70 hover:bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className={`text-xs font-bold w-6 text-center ${isCurrent ? 'text-slate-950' : 'text-slate-400'}`}>
                        {idx + 1}
                      </span>
                      <p className="text-xs truncate">{ep.title}</p>
                    </div>

                    {isCurrent && <Play className="w-3.5 h-3.5 fill-current flex-shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>
          </aside>
        )}
      </div>

      {/* TV Remote Helper Hint Bar */}
      <footer className="bg-slate-950 border-t border-slate-900 px-4 py-2 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2">
          <Tv className="w-3.5 h-3.5 text-amber-400" />
          <span>
            {playerEngine === 'native'
              ? 'Control Android TV: OK / Espacio = Play/Pausa · Flechas = ±10s · F = Pantalla Completa · Esc = Salir'
              : 'Modo Web Embebido Activo · Esc = Salir'}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-amber-300 font-semibold">
            {playerEngine === 'native' ? 'Motor: HTML5 Directo MP4 (HD)' : 'Motor: Web Embebido'}
          </span>
        </div>
      </footer>
    </div>
  );
};
