import React from 'react';
import { Clock, Play, Trash2, Calendar } from 'lucide-react';
import { WatchProgress } from '../types';

interface HistoryViewProps {
  history: WatchProgress[];
  onPlayEpisode: (item: WatchProgress) => void;
  onClearHistory: () => void;
  onRemoveItem: (e: React.MouseEvent, serieId: string) => void;
  onBrowseCatalog: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  onPlayEpisode,
  onClearHistory,
  onRemoveItem,
  onBrowseCatalog,
}) => {
  return (
    <div className="py-6 px-4 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center">
            <Clock className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black text-white">Historial de Reproducción</h1>
            <p className="text-xs text-slate-400">Capítulos que has comenzado a ver en LACartoons</p>
          </div>
        </div>

        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-800 text-xs font-semibold transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Borrar Historial</span>
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="text-center py-20 px-4 bg-slate-900/40 rounded-3xl border border-dashed border-slate-800 max-w-lg mx-auto">
          <Clock className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">Tu historial está vacío</h3>
          <p className="text-xs text-slate-400 mb-6">
            Cuando comiences a ver cualquier capítulo, se guardará aquí automáticamente para que puedas continuar donde te quedaste.
          </p>
          <button
            onClick={onBrowseCatalog}
            className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/20"
          >
            Comenzar a Ver
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {history.map((item) => (
            <div
              key={item.serieId}
              tabIndex={0}
              role="button"
              onClick={() => onPlayEpisode(item)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onPlayEpisode(item);
                }
              }}
              className="group relative flex items-center p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-amber-400/80 focus:outline-none focus:ring-4 focus:ring-amber-400 transition-all text-left cursor-pointer"
            >
              {/* Thumbnail */}
              <div className="relative w-20 h-28 rounded-xl overflow-hidden bg-slate-950 flex-shrink-0">
                <img
                  src={item.poster || 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&auto=format&fit=crop&q=80'}
                  alt={item.serieTitle}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="w-8 h-8 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-md">
                    <Play className="w-3.5 h-3.5 fill-slate-950 ml-0.5" />
                  </div>
                </div>
              </div>

              {/* Info */}
              <div className="ml-3 flex-1 min-w-0 pr-8">
                <h3 className="font-bold text-sm text-white truncate group-hover:text-amber-400 transition-colors">
                  {item.serieTitle}
                </h3>
                <p className="text-xs text-amber-300 font-semibold truncate mt-1">
                  {item.episodeNumber ? `${item.episodeNumber} ` : ''}
                  {item.episodeTitle}
                </p>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-2">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>{new Date(item.updatedAt).toLocaleDateString()}</span>
                </div>
              </div>

              {/* Remove button */}
              <button
                type="button"
                onClick={(e) => onRemoveItem(e, item.serieId)}
                className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                title="Eliminar de historial"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
