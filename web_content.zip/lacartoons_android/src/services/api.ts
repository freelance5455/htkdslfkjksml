import { SeriesItem, SeriesDetail, EpisodeDetail } from '../types';

export const CATEGORIES = [
  { id: '0', name: 'Todos los Clásicos', color: 'from-amber-500 to-orange-600', bgBadge: 'bg-amber-500/10 text-amber-300 border-amber-500/30' },
  { id: '2', name: 'Cartoon Network', color: 'from-white to-slate-900', bgBadge: 'bg-zinc-800 text-white border-zinc-600' },
  { id: '4', name: 'Hanna Barbera', color: 'from-yellow-400 to-amber-600', bgBadge: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/30' },
  { id: '1', name: 'Nickelodeon', color: 'from-orange-500 to-amber-500', bgBadge: 'bg-orange-500/10 text-orange-400 border-orange-500/30' },
  { id: '3', name: 'Fox Kids', color: 'from-red-600 to-blue-600', bgBadge: 'bg-red-500/10 text-red-400 border-red-500/30' },
  { id: '5', name: 'Disney Retro', color: 'from-blue-500 to-indigo-600', bgBadge: 'bg-blue-500/10 text-blue-300 border-blue-500/30' },
  { id: '6', name: 'Warner Channel', color: 'from-blue-600 to-cyan-500', bgBadge: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30' },
  { id: '7', name: 'Marvel Clásicos', color: 'from-red-600 to-red-800', bgBadge: 'bg-red-500/10 text-red-300 border-red-500/30' },
  { id: '8', name: 'Otros Canales', color: 'from-purple-500 to-pink-600', bgBadge: 'bg-purple-500/10 text-purple-300 border-purple-500/30' },
];

export interface FetchSeriesResponse {
  series: SeriesItem[];
  pagination: {
    current: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
  category?: string;
  search?: string;
}

export async function fetchSeries(page = 1, category = '', search = ''): Promise<FetchSeriesResponse> {
  const params = new URLSearchParams();
  if (page > 1) params.append('page', String(page));
  if (category && category !== '0') params.append('category', category);
  if (search) params.append('search', search);

  const res = await fetch(`/api/lacartoons/series?${params.toString()}`);
  if (!res.ok) {
    throw new Error(`Error en servidor: ${res.statusText}`);
  }
  return await res.json();
}

export async function fetchSeriesDetail(serieId: string): Promise<SeriesDetail> {
  const res = await fetch(`/api/lacartoons/serie/${serieId}`);
  if (!res.ok) {
    throw new Error(`Error al cargar serie #${serieId}`);
  }
  return await res.json();
}

export async function fetchEpisodeDetail(episodeId: string, season = '1'): Promise<EpisodeDetail> {
  const res = await fetch(`/api/lacartoons/episode/${episodeId}?t=${season}`);
  if (!res.ok) {
    throw new Error(`Error al cargar capítulo #${episodeId}`);
  }
  return await res.json();
}

export function getSafeImageUrl(url: string): string {
  if (!url) return 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&auto=format&fit=crop&q=80';
  return url;
}
