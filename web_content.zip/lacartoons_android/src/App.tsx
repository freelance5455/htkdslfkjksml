import React, { useState, useEffect, useCallback } from 'react';
import {
  Tv,
  Smartphone,
  Search,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Flame,
  Film,
  Download,
  AlertCircle,
  Loader2,
  CheckCircle,
  ArrowRight,
  Radio,
  SlidersHorizontal
} from 'lucide-react';
import {
  SeriesItem,
  SeriesDetail,
  EpisodeItem,
  WatchProgress,
  DeviceMode,
  ViewTab,
} from './types';
import { fetchSeries, fetchSeriesDetail } from './services/api';
import { useTvRemote } from './hooks/useTvRemote';
import { Header } from './components/Header';
import { CategoryChips } from './components/CategoryChips';
import { SeriesCard } from './components/SeriesCard';
import { ContinueWatchingRow } from './components/ContinueWatchingRow';
import { SeriesDetailModal } from './components/SeriesDetailModal';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { VirtualTvRemote } from './components/VirtualTvRemote';
import { MobileBottomNav } from './components/MobileBottomNav';
import { FavoritesView } from './components/FavoritesView';
import { HistoryView } from './components/HistoryView';
import { ChannelsView } from './components/ChannelsView';

export default function App() {
  // Device mode & state
  const [deviceMode, setDeviceMode] = useState<DeviceMode>(() => {
    const saved = localStorage.getItem('lacartoons_device_mode');
    if (saved === 'tv' || saved === 'mobile') return saved;
    // Auto-detect TV user-agent or widescreen
    const isTv = /Android.*TV|SmartTV|GoogleTV|AFTB|BRAVIA|HbbTV|CrKey/i.test(navigator.userAgent);
    return isTv ? 'tv' : 'tv'; // Default to TV mode for rich 10-foot experience
  });

  const [activeTab, setActiveTab] = useState<ViewTab>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('0');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [submittedSearch, setSubmittedSearch] = useState<string>('');

  // Series catalog state
  const [seriesList, setSeriesList] = useState<SeriesItem[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Modals & Player state
  const [selectedSerieId, setSelectedSerieId] = useState<string | null>(null);
  const [activePlayer, setActivePlayer] = useState<{
    serie: SeriesDetail;
    episode: EpisodeItem;
    seasonId: string;
  } | null>(null);

  // Virtual Remote state
  const [isRemoteOpen, setIsRemoteOpen] = useState<boolean>(false);

  // Local storage: Continue Watching
  const [continueWatching, setContinueWatching] = useState<WatchProgress[]>(() => {
    try {
      const data = localStorage.getItem('lacartoons_history');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });

  // Local storage: Favorites
  const [favorites, setFavorites] = useState<SeriesItem[]>(() => {
    try {
      const data = localStorage.getItem('lacartoons_favorites');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });

  // Local storage: Watched episode IDs
  const [watchedEpisodeIds, setWatchedEpisodeIds] = useState<Set<string>>(() => {
    try {
      const data = localStorage.getItem('lacartoons_watched_episodes');
      return data ? new Set(JSON.parse(data)) : new Set();
    } catch {
      return new Set();
    }
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('lacartoons_device_mode', deviceMode);
  }, [deviceMode]);

  useEffect(() => {
    localStorage.setItem('lacartoons_history', JSON.stringify(continueWatching));
  }, [continueWatching]);

  useEffect(() => {
    localStorage.setItem('lacartoons_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('lacartoons_watched_episodes', JSON.stringify(Array.from(watchedEpisodeIds)));
  }, [watchedEpisodeIds]);

  // Load series from API
  const loadSeries = useCallback(async (page: number, cat: string, search: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchSeries(page, cat, search);
      setSeriesList(data.series);
      setCurrentPage(data.pagination.current);
      setTotalPages(data.pagination.totalPages);
    } catch (err: any) {
      setError(err.message || 'No se pudieron cargar las series');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSeries(currentPage, selectedCategory, submittedSearch);
  }, [currentPage, selectedCategory, submittedSearch, loadSeries]);

  // TV Remote Back handler
  const handleTvBack = useCallback(() => {
    if (activePlayer) {
      setActivePlayer(null);
      return;
    }
    if (selectedSerieId) {
      setSelectedSerieId(null);
      return;
    }
    if (activeTab !== 'home') {
      setActiveTab('home');
      return;
    }
  }, [activePlayer, selectedSerieId, activeTab]);

  useTvRemote({
    enabled: deviceMode === 'tv',
    onBack: handleTvBack,
    onPlayPause: () => {
      // Toggle play or trigger active element
      const activeEl = document.activeElement as HTMLElement | null;
      if (activeEl) activeEl.click();
    },
  });

  // Switch category
  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
    setSubmittedSearch('');
    setSearchQuery('');
    setCurrentPage(1);
    if (activeTab !== 'home') {
      setActiveTab('home');
    }
  };

  // Search submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSubmittedSearch(searchQuery.trim());
    setSelectedCategory('0');
    setCurrentPage(1);
    setActiveTab('home');
  };

  // Clear search
  const handleClearSearch = () => {
    setSearchQuery('');
    setSubmittedSearch('');
    setCurrentPage(1);
  };

  // Toggle Favorite
  const handleToggleFavorite = (series: SeriesItem) => {
    setFavorites((prev) => {
      const exists = prev.some((f) => f.id === series.id);
      if (exists) {
        return prev.filter((f) => f.id !== series.id);
      } else {
        return [series, ...prev];
      }
    });
  };

  // Play Episode from Series Modal or Continue Watching
  const handlePlayEpisode = (serie: SeriesDetail, episode: EpisodeItem, seasonId: string) => {
    setActivePlayer({
      serie,
      episode,
      seasonId,
    });

    // Update watch history
    setContinueWatching((prev) => {
      const filtered = prev.filter((item) => item.serieId !== serie.id);
      const newEntry: WatchProgress = {
        serieId: serie.id,
        serieTitle: serie.title,
        poster: serie.poster,
        episodeId: episode.id,
        episodeNumber: episode.number,
        episodeTitle: episode.title,
        season: seasonId,
        updatedAt: Date.now(),
      };
      return [newEntry, ...filtered.slice(0, 19)];
    });
  };

  // Resume Episode from Continue Watching row
  const handleResumeWatching = async (item: WatchProgress) => {
    try {
      const detail = await fetchSeriesDetail(item.serieId);
      const episode: EpisodeItem = {
        id: item.episodeId,
        number: item.episodeNumber,
        title: item.episodeTitle,
        href: `/serie/capitulo/${item.episodeId}?t=${item.season}`,
      };
      setActivePlayer({
        serie: detail,
        episode,
        seasonId: item.season,
      });
    } catch (e) {
      // Fallback: open series detail
      setSelectedSerieId(item.serieId);
    }
  };

  // Mark episode as watched
  const handleMarkWatched = (episodeId: string) => {
    setWatchedEpisodeIds((prev) => new Set(prev).add(episodeId));
  };

  // Clear single item from continue watching
  const handleClearContinueItem = (e: React.MouseEvent, serieId: string) => {
    e.stopPropagation();
    setContinueWatching((prev) => prev.filter((item) => item.serieId !== serieId));
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans ${deviceMode === 'tv' ? 'tv-experience' : ''}`}>
      {/* Top Header */}
      <Header
        deviceMode={deviceMode}
        onToggleDeviceMode={() => setDeviceMode((m) => (m === 'tv' ? 'mobile' : 'tv'))}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        onOpenRemote={() => setIsRemoteOpen((o) => !o)}
        isRemoteOpen={isRemoteOpen}
        favoritesCount={favorites.length}
      />

      {/* Android TV Mode Notice Banner (Visible in TV mode) */}
      {deviceMode === 'tv' && (
        <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border-b border-amber-500/20 px-4 py-2 text-xs text-amber-200/90 flex items-center justify-between">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <Tv className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-amber-300">Modo Android TV activo:</span>
              <span className="hidden md:inline text-slate-300">
                Usa las teclas de flechas (D-Pad), Enter y Esc de tu control remoto para navegar fluidamente.
              </span>
            </div>
            <button
              onClick={() => setIsRemoteOpen(true)}
              className="text-[11px] font-bold text-amber-400 hover:text-white underline ml-2 flex items-center gap-1"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Ver Mando Virtual</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 pb-20 md:pb-12">
        {activeTab === 'categories' && (
          <ChannelsView
            onSelectChannel={(catId) => {
              handleSelectCategory(catId);
            }}
          />
        )}

        {activeTab === 'favorites' && (
          <FavoritesView
            favorites={favorites}
            onSelectSeries={(s) => setSelectedSerieId(s.id)}
            onRemoveFavorite={(e, s) => {
              e.stopPropagation();
              handleToggleFavorite(s);
            }}
            onBrowseCatalog={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            history={continueWatching}
            onPlayEpisode={handleResumeWatching}
            onClearHistory={() => setContinueWatching([])}
            onRemoveItem={(e, id) => handleClearContinueItem(e, id)}
            onBrowseCatalog={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'search' && (
          <div className="py-6 px-4 lg:px-8 max-w-7xl mx-auto">
            <h1 className="text-xl font-black text-white mb-4">Buscador de Caricaturas Retro</h1>
            <form onSubmit={handleSearchSubmit} className="relative mb-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Escribe el nombre de la serie (ej. Scooby Doo, Picapiedra, Dragon Ball, Caballeros, Thundercats)..."
                className="w-full bg-slate-900 border border-slate-700 rounded-2xl pl-12 pr-4 py-3.5 text-base text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20"
                autoFocus
              />
            </form>
          </div>
        )}

        {activeTab === 'home' && (
          <div className="max-w-7xl mx-auto px-4 lg:px-8 py-4">
            {/* Continue Watching Row (if user has watch history) */}
            <ContinueWatchingRow
              items={continueWatching}
              onPlayEpisode={handleResumeWatching}
              onClearItem={handleClearContinueItem}
            />

            {/* Channels & Categories Filter Chips */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-500" />
                  Canales & Categorías
                </span>
              </div>
              <CategoryChips
                selectedCategory={selectedCategory}
                onSelectCategory={handleSelectCategory}
              />
            </div>

            {/* Search feedback indicator */}
            {submittedSearch && (
              <div className="mb-4 flex items-center justify-between bg-slate-900 border border-amber-500/30 px-4 py-2.5 rounded-2xl">
                <p className="text-xs text-slate-300">
                  Resultados para la búsqueda: <strong className="text-amber-400">"{submittedSearch}"</strong>
                </p>
                <button
                  onClick={handleClearSearch}
                  className="text-xs text-amber-400 hover:text-white font-semibold underline"
                >
                  Restablecer
                </button>
              </div>
            )}

            {/* Catalog Grid Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Film className="w-5 h-5 text-amber-400" />
                <h2 className="text-lg md:text-xl font-black text-white tracking-wide">
                  {submittedSearch
                    ? 'Resultados Encontrados'
                    : selectedCategory === '0'
                    ? 'Catálogo Completo de Series'
                    : 'Series del Canal'}
                </h2>
              </div>
              <div className="text-xs text-slate-400">
                Página <span className="font-bold text-white">{currentPage}</span> de <span className="font-bold text-white">{totalPages}</span>
              </div>
            </div>

            {/* Loading State */}
            {loading ? (
              <div className="py-24 flex flex-col items-center justify-center text-center">
                <Loader2 className="w-12 h-12 text-amber-400 animate-spin mb-4" />
                <p className="text-white font-bold text-base">Cargando caricaturas de LACartoons...</p>
                <p className="text-xs text-slate-400 mt-1">Optimizando para Android y Android TV</p>
              </div>
            ) : error ? (
              <div className="py-16 px-4 bg-slate-900/60 rounded-3xl border border-slate-800 text-center max-w-md mx-auto">
                <AlertCircle className="w-10 h-10 text-rose-400 mx-auto mb-3" />
                <p className="text-white font-bold mb-1">Hubo un problema al conectar</p>
                <p className="text-xs text-slate-400 mb-6">{error}</p>
                <button
                  onClick={() => loadSeries(currentPage, selectedCategory, submittedSearch)}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
                >
                  Reintentar Conexión
                </button>
              </div>
            ) : seriesList.length === 0 ? (
              <div className="py-20 text-center bg-slate-900/40 rounded-3xl border border-slate-800 max-w-md mx-auto">
                <p className="text-slate-300 font-bold text-base mb-1">No se encontraron series</p>
                <p className="text-xs text-slate-400 mb-6">Prueba con otra palabra clave o selecciona otro canal retro.</p>
                <button
                  onClick={handleClearSearch}
                  className="px-6 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold hover:bg-slate-700"
                >
                  Ver todas las series
                </button>
              </div>
            ) : (
              <>
                {/* Series Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4">
                  {seriesList.map((series) => {
                    const isFav = favorites.some((f) => f.id === series.id);
                    return (
                      <SeriesCard
                        key={series.id}
                        series={series}
                        isFavorite={isFav}
                        onToggleFavorite={(e, s) => {
                          e.stopPropagation();
                          handleToggleFavorite(s);
                        }}
                        onClick={(s) => setSelectedSerieId(s.id)}
                      />
                    );
                  })}
                </div>

                {/* Pagination Controls */}
                <div className="mt-8 flex items-center justify-center gap-3">
                  <button
                    disabled={currentPage <= 1}
                    onClick={() => {
                      setCurrentPage((p) => Math.max(1, p - 1));
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none text-slate-200 border border-slate-800 text-xs font-bold transition-all focus:outline-none focus:ring-4 focus:ring-amber-400"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Anterior</span>
                  </button>

                  <div className="flex items-center gap-1 px-3 py-2 bg-slate-900/90 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
                    <span className="text-amber-400 font-bold">{currentPage}</span>
                    <span className="text-slate-400">/</span>
                    <span>{totalPages}</span>
                  </div>

                  <button
                    disabled={currentPage >= totalPages}
                    onClick={() => {
                      setCurrentPage((p) => p + 1);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none text-slate-200 border border-slate-800 text-xs font-bold transition-all focus:outline-none focus:ring-4 focus:ring-amber-400"
                  >
                    <span>Siguiente</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        )}
        {/* Footer with Bubu and Dudu - by Josué flores */}
        <footer className="mt-16 pt-8 pb-4 border-t border-slate-900 text-center flex flex-col items-center justify-center gap-3">
          <div className="flex items-center gap-3 bg-gradient-to-r from-amber-500/10 via-pink-500/10 to-amber-500/10 border border-amber-500/30 px-5 py-2.5 rounded-full shadow-lg">
            <div className="w-11 h-11 rounded-full overflow-hidden border-2 border-amber-400 shadow-md flex-shrink-0 bg-white">
              <img src="/bubu-dudu.jpg" alt="Bubu y Dudu" className="w-full h-full object-cover scale-105" />
            </div>
            <div className="text-left">
              <p className="text-[10px] text-amber-300 font-bold uppercase tracking-wider">Creado con cariño</p>
              <p className="text-sm font-black text-white">by Josué flores</p>
            </div>
          </div>
          <p className="text-xs text-slate-400">
            LACartoons · Series clásicas y caricaturas retro en español latino
          </p>
        </footer>
      </main>

      {/* Series Detail Modal */}
      {selectedSerieId && (
        <SeriesDetailModal
          serieId={selectedSerieId}
          onClose={() => setSelectedSerieId(null)}
          onPlayEpisode={handlePlayEpisode}
          isFavorite={favorites.some((f) => f.id === selectedSerieId)}
          onToggleFavorite={(serie) => handleToggleFavorite(serie)}
          watchedEpisodeIds={watchedEpisodeIds}
        />
      )}

      {/* Cinema Video Player Modal */}
      {activePlayer && (
        <VideoPlayerModal
          serie={activePlayer.serie}
          episode={activePlayer.episode}
          seasonId={activePlayer.seasonId}
          onClose={() => setActivePlayer(null)}
          onSelectEpisode={(ep, seasonId) => {
            handlePlayEpisode(activePlayer.serie, ep, seasonId);
          }}
          onMarkWatched={handleMarkWatched}
        />
      )}

      {/* Virtual Android TV Remote floating widget */}
      <VirtualTvRemote
        isOpen={isRemoteOpen}
        onClose={() => setIsRemoteOpen(false)}
        onBack={handleTvBack}
        onPlayPause={() => {
          const activeEl = document.activeElement as HTMLElement | null;
          if (activeEl) activeEl.click();
        }}
      />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        favoritesCount={favorites.length}
      />
    </div>
  );
}
