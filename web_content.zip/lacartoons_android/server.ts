import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import * as cheerio from 'cheerio';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const LACARTOONS_BASE = 'https://www.lacartoons.com';

app.use(express.json());

// In-memory cache with TTL
interface CacheEntry<T> {
  data: T;
  expiry: number;
}
const cache = new Map<string, CacheEntry<any>>();

function getCached<T>(key: string): T | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiry) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function setCached<T>(key: string, data: T, ttlSeconds = 600) {
  cache.set(key, {
    data,
    expiry: Date.now() + ttlSeconds * 1000,
  });
}

// Helper to fetch from lacartoons with fallback headers
async function fetchLacartoonsHtml(urlPath: string): Promise<string> {
  const targetUrl = urlPath.startsWith('http') ? urlPath : `${LACARTOONS_BASE}${urlPath}`;
  const response = await fetch(targetUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      'Referer': LACARTOONS_BASE,
    },
  });

  if (!response.ok) {
    throw new Error(`Lacartoons HTTP error: ${response.status} ${response.statusText}`);
  }
  return await response.text();
}

function normalizeImageUrl(src?: string): string {
  if (!src) return '';
  if (src.startsWith('http')) return src;
  if (src.startsWith('/')) return `${LACARTOONS_BASE}${src}`;
  return `${LACARTOONS_BASE}/${src}`;
}

export interface SeriesCard {
  id: string;
  title: string;
  poster: string;
  network: string;
  year: string;
  rating: string;
}

// Fallback series for instant loading or offline/network tolerance
const FALLBACK_POPULAR_SERIES: SeriesCard[] = [
  {
    id: '30',
    title: 'Scooby Doo Misterios S.A',
    poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600&auto=format&fit=crop&q=80',
    network: 'Cartoon Network',
    year: '2009',
    rating: '8'
  },
  {
    id: '2',
    title: 'Caballeros del Zodiaco',
    poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    network: 'Cartoon Network',
    year: '1986',
    rating: '8'
  },
  {
    id: '1',
    title: '2 Perros Tontos',
    poster: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&auto=format&fit=crop&q=80',
    network: 'Cartoon Network',
    year: '1993',
    rating: '7'
  },
  {
    id: '6',
    title: 'Duck Dodgers',
    poster: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=600&auto=format&fit=crop&q=80',
    network: 'Cartoon Network',
    year: '2003',
    rating: '7'
  }
];

// 1. Get Series Catalog (search, category, page)
app.get('/api/lacartoons/series', async (req, res) => {
  const page = req.query.page ? String(req.query.page) : '1';
  const category = req.query.category ? String(req.query.category) : '';
  const search = req.query.search ? String(req.query.search).trim() : '';

  const cacheKey = `catalog_${page}_${category}_${search}`;
  const cached = getCached(cacheKey);
  if (cached) {
    return res.json(cached);
  }

  try {
    let url = '/';
    const params = new URLSearchParams();

    if (search) {
      params.append('Titulo', search);
      if (page !== '1') params.append('page', page);
      url = `/?${params.toString()}`;
    } else if (category && category !== '0') {
      params.append('Categoria_id', category);
      if (page !== '1') params.append('page', page);
      url = `/?${params.toString()}`;
    } else {
      if (page !== '1') params.append('page', page);
      url = params.toString() ? `/?${params.toString()}` : '/';
    }

    const html = await fetchLacartoonsHtml(url);
    const $ = cheerio.load(html);

    const seriesList: SeriesCard[] = [];
    $('.conjuntos-series a').each((_, el) => {
      const href = $(el).attr('href');
      if (href && href.includes('/serie/')) {
        const idMatch = href.match(/\/serie\/([0-9]+)/);
        if (idMatch) {
          const id = idMatch[1];
          const title = $(el).find('.nombre-serie').text().trim() || 'Sin título';
          const posterRaw = $(el).find('img').attr('src') || '';
          const poster = normalizeImageUrl(posterRaw);
          const rawNetwork = $(el).find('.marcadorSeries, .marcador').text().trim();
          // Network might have year trailing
          const network = rawNetwork.split('\n')[0].trim() || 'Retro';
          const year = $(el).find('.marcador-ano, .marcador-año').text().trim() || '';
          const rating = $(el).find('.valoracion').text().replace(/[^0-9]/g, '').trim() || '8';

          seriesList.push({
            id,
            title,
            poster,
            network,
            year,
            rating,
          });
        }
      }
    });

    // Detect pagination
    let totalPages = 1;
    $('.pagination a, .paginacion a').each((_, a) => {
      const pageNum = parseInt($(a).text().trim(), 10);
      if (!isNaN(pageNum) && pageNum > totalPages) {
        totalPages = pageNum;
      }
      const href = $(a).attr('href') || '';
      const match = href.match(/page=([0-9]+)/);
      if (match) {
        const p = parseInt(match[1], 10);
        if (p > totalPages) totalPages = p;
      }
    });

    const currentPageNum = parseInt(page, 10) || 1;
    const result = {
      series: seriesList.length > 0 ? seriesList : (search ? [] : FALLBACK_POPULAR_SERIES),
      pagination: {
        current: currentPageNum,
        totalPages: Math.max(totalPages, currentPageNum),
        hasNext: totalPages > currentPageNum,
        hasPrev: currentPageNum > 1,
      },
      category,
      search,
    };

    setCached(cacheKey, result, 600); // 10 minutes cache
    res.json(result);
  } catch (error: any) {
    console.error('Error fetching series from lacartoons:', error.message);
    res.status(200).json({
      series: FALLBACK_POPULAR_SERIES,
      pagination: { current: 1, totalPages: 1, hasNext: false, hasPrev: false },
      error: 'Usando catálogo offline temporal',
    });
  }
});

// 2. Get Series Detail & Episodes
app.get('/api/lacartoons/serie/:id', async (req, res) => {
  const { id } = req.params;
  const cacheKey = `serie_${id}`;
  const cached = getCached(cacheKey);
  if (cached) {
    return res.json(cached);
  }

  try {
    const html = await fetchLacartoonsHtml(`/serie/${id}`);
    const $ = cheerio.load(html);

    const title = $('.subtitulo-serie-seccion').clone().children().remove().end().text().trim() ||
                  $('.subtitulo-serie-seccion').text().trim() || 'Serie Animada';
    const network = $('.subtitulo-serie-seccion .marcador').text().trim() || 'Retro';
    const poster = normalizeImageUrl($('.imagen-serie img').attr('src'));
    const backdrop = normalizeImageUrl($('.fondo-serie-seccion').attr('src')) || poster;

    let episodesCount = '';
    let language = 'Español Latino';
    let year = '';
    let rating = '8';
    let synopsis = '';

    $('.informacion-serie-seccion p').each((_, p) => {
      const text = $(p).text();
      if (text.includes('Episodios:')) episodesCount = $(p).find('span').text().trim();
      if (text.includes('Idioma:')) language = $(p).find('span').text().trim() || language;
      if (text.includes('Año:')) year = $(p).find('span').text().trim();
      if (text.includes('Valoración:')) rating = $(p).find('.valoracion1').text().replace(/[^0-9]/g, '').trim() || rating;
      if (text.includes('Reseña:')) synopsis = $(p).find('span').text().trim();
    });

    const seasons: Array<{
      seasonId: string;
      seasonName: string;
      episodes: Array<{
        id: string;
        number: string;
        title: string;
        href: string;
      }>;
    }> = [];

    $('.contenedor-episondios .estilo-temporada').each((idx, seasonEl) => {
      const rawName = $(seasonEl).text().trim() || `Temporada ${idx + 1}`;
      const seasonName = rawName.replace(/\s+/g, ' ');
      const seasonId = $(seasonEl).attr('data-temporada-id') || String(idx + 1);
      const episodes: Array<{ id: string; number: string; title: string; href: string }> = [];

      const panel = $(seasonEl).next('.episodio-panel');
      panel.find('li a').each((_, epLink) => {
        const href = $(epLink).attr('href') || '';
        const epNum = $(epLink).find('span').text().trim();
        const epTitle = $(epLink).clone().children().remove().end().text().trim();
        const epIdMatch = href.match(/\/serie\/capitulo\/([0-9]+)/);
        const epId = epIdMatch ? epIdMatch[1] : '';

        if (epId) {
          episodes.push({
            id: epId,
            number: epNum,
            title: epTitle || `Capítulo ${episodes.length + 1}`,
            href,
          });
        }
      });

      seasons.push({ seasonId, seasonName, episodes });
    });

    // If no seasons parsed with .estilo-temporada, check generic lists
    if (seasons.length === 0) {
      const directEpisodes: Array<{ id: string; number: string; title: string; href: string }> = [];
      $('.listas-de-episodion li a').each((_, epLink) => {
        const href = $(epLink).attr('href') || '';
        const epNum = $(epLink).find('span').text().trim();
        const epTitle = $(epLink).clone().children().remove().end().text().trim();
        const epIdMatch = href.match(/\/serie\/capitulo\/([0-9]+)/);
        const epId = epIdMatch ? epIdMatch[1] : '';

        if (epId) {
          directEpisodes.push({
            id: epId,
            number: epNum,
            title: epTitle || `Capítulo ${directEpisodes.length + 1}`,
            href,
          });
        }
      });

      if (directEpisodes.length > 0) {
        seasons.push({
          seasonId: '1',
          seasonName: 'Temporada 1',
          episodes: directEpisodes,
        });
      }
    }

    const result = {
      id,
      title,
      network,
      poster,
      backdrop,
      episodesCount: episodesCount || String(seasons.reduce((acc, s) => acc + s.episodes.length, 0)),
      language,
      year,
      rating,
      synopsis,
      seasons,
    };

    setCached(cacheKey, result, 1800); // 30 min cache
    res.json(result);
  } catch (error: any) {
    console.error(`Error fetching serie ${id}:`, error.message);
    res.status(500).json({ error: 'No se pudo cargar la serie de LACartoons' });
  }
});

// 3. Get Episode Details and Video Stream
app.get('/api/lacartoons/episode/:id', async (req, res) => {
  const { id } = req.params;
  const season = req.query.t ? String(req.query.t) : '1';
  const cacheKey = `episode_${id}_${season}`;
  const cached = getCached(cacheKey);
  if (cached) {
    return res.json(cached);
  }

  try {
    const html = await fetchLacartoonsHtml(`/serie/capitulo/${id}?t=${season}`);
    const $ = cheerio.load(html);

    const seriesTitle = $('.serie-video-informacion h2').clone().children().remove().end().text().trim();
    const network = $('.serie-video-informacion .marcador').text().trim();
    const episodeTitleRaw = $('.serie-video-informacion h3').text().trim();
    const episodeTitle = episodeTitleRaw.replace(/Episodios$/i, '').trim();

    let iframeSrc = $('iframe').attr('src') || '';
    if (iframeSrc.startsWith('//')) {
      iframeSrc = `https:${iframeSrc}`;
    }

    let prevHref: string | null = null;
    let nextHref: string | null = null;
    let prevId: string | null = null;
    let nextId: string | null = null;

    $('.controles-episodios a').each((_, a) => {
      const text = $(a).text().trim().toLowerCase();
      const href = $(a).attr('href') || '';
      const match = href.match(/\/serie\/capitulo\/([0-9]+)/);
      if (text.includes('anterior') && href) {
        prevHref = href;
        if (match) prevId = match[1];
      }
      if (text.includes('siguiente') && href) {
        nextHref = href;
        if (match) nextId = match[1];
      }
    });

    let directVideos: Array<{ label: string; url: string; quality: string }> = [];
    let hlsUrl: string | null = null;

    // If iframe is from ok.ru, extract direct MP4 videos and HLS manifest
    if (iframeSrc && iframeSrc.includes('ok.ru')) {
      try {
        const okRes = await fetch(iframeSrc, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
          },
        });
        const okHtml = await okRes.text();
        const dataOptionsMatch = okHtml.match(/data-options="([^"]+)"/);
        if (dataOptionsMatch) {
          const decoded = dataOptionsMatch[1].replace(/&quot;/g, '"');
          const okData = JSON.parse(decoded);
          const rawVideos: Array<{ name: string; url: string }> = okData.flashvars?.metadata?.videos || [];

          const qualityLabels: Record<string, string> = {
            sd: 'Calidad SD (480p - Recomendado)',
            low: 'Calidad Media (360p)',
            mobile: 'Calidad Móvil (240p)',
            lowest: 'Bajo Consumo (144p)',
          };

          directVideos = rawVideos.map((v) => ({
            label: qualityLabels[v.name] || `Calidad ${v.name.toUpperCase()}`,
            url: `/api/lacartoons/video-stream?url=${encodeURIComponent(v.url)}`,
            quality: v.name,
          }));

          hlsUrl = okData.flashvars?.metadata?.hlsManifestUrl || null;
        }
      } catch (err: any) {
        console.warn('No se pudo extraer video directo de ok.ru:', err.message);
      }
    }

    const result = {
      id,
      season,
      seriesTitle,
      network,
      episodeTitle,
      iframeSrc,
      directVideos,
      hlsUrl,
      prevHref,
      nextHref,
      prevId,
      nextId,
    };

    setCached(cacheKey, result, 1800);
    res.json(result);
  } catch (error: any) {
    console.error(`Error fetching episode ${id}:`, error.message);
    res.status(500).json({ error: 'No se pudo cargar el capítulo de LACartoons' });
  }
});

// 4. Video Streaming Proxy with Range Request support for smooth HTML5 playback
app.get('/api/lacartoons/video-stream', async (req, res) => {
  const targetUrl = req.query.url as string;
  if (!targetUrl) {
    return res.status(400).send('URL de video requerida');
  }

  try {
    const rangeHeader = req.headers.range;
    const fetchHeaders: Record<string, string> = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer': 'https://ok.ru/',
    };

    if (rangeHeader) {
      fetchHeaders['Range'] = rangeHeader;
    }

    const videoRes = await fetch(targetUrl, { headers: fetchHeaders });

    res.status(videoRes.status);

    const forwardHeaders = ['content-type', 'content-length', 'content-range', 'accept-ranges'];
    forwardHeaders.forEach((h) => {
      const val = videoRes.headers.get(h);
      if (val) res.setHeader(h, val);
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=7200');

    if (videoRes.body) {
      const reader = videoRes.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(value);
      }
      res.end();
    } else {
      res.end();
    }
  } catch (err: any) {
    console.error('Error in video streaming proxy:', err.message);
    if (!res.headersSent) {
      res.status(502).send('Error al transmitir video');
    }
  }
});

// 4. Proxy images to avoid CORS or hotlink drops
app.get('/api/lacartoons/proxy-image', async (req, res) => {
  const imageUrl = req.query.url as string;
  if (!imageUrl) {
    return res.status(400).send('Image URL required');
  }

  try {
    const fullUrl = imageUrl.startsWith('http') ? imageUrl : `${LACARTOONS_BASE}${imageUrl}`;
    const imgRes = await fetch(fullUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Referer': LACARTOONS_BASE,
      },
    });

    if (!imgRes.ok) {
      return res.redirect(imageUrl);
    }

    const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=86400'); // 1 day cache
    const arrayBuffer = await imgRes.arrayBuffer();
    res.send(Buffer.from(arrayBuffer));
  } catch (e) {
    res.redirect(imageUrl);
  }
});

// Setup Vite in Dev or Static files in Production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LACartoons App running on http://0.0.0.0:${PORT} (${isProduction ? 'production' : 'development'})`);
  });
}

startServer();
