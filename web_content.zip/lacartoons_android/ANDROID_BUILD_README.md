# LACartoons — preparación Android

Se conserva el código y el diseño web original. Este proyecto añade la configuración para empaquetarlo con Capacitor en Android.

## Importante sobre el funcionamiento

La aplicación consulta rutas relativas `/api/lacartoons/...`. Esas rutas las sirve `server.ts`; no quedan disponibles solo por empaquetar React/Vite dentro del APK. Antes de distribuirlo, el servidor debe estar desplegado en una URL HTTPS y la aplicación debe configurarse para usar esa API. Sin ese ajuste, la interfaz podría abrir pero el catálogo/detalles no cargarían. No se ha inventado ni configurado un servidor remoto.

La descarga de capítulos para verlos sin conexión tampoco queda habilitada automáticamente por convertir a APK; requiere implementar y probar esa función de descarga en el reproductor y que las fuentes permitan descargar.

## Requisitos para compilar

- Node.js 22 o superior
- Android Studio y Android SDK instalados
- JDK compatible (Android Studio instala el recomendado)

## Crear el proyecto Android

Desde esta carpeta, en una computadora con conexión a Internet:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

En Android Studio, deja que termine la sincronización de Gradle. Para generar un APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio mostrará la ubicación del archivo generado.

También se puede compilar por consola una vez creado el directorio `android/`:

```bash
npm run android:build
```

El APK de depuración suele quedar en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Android TV

Capacitor crea una aplicación Android basada en WebView. Para distribuirla en Android TV hay que verificar en un televisor real la navegación con control remoto y la compatibilidad del reproductor; no se garantiza automáticamente la publicación como app de Android TV.
