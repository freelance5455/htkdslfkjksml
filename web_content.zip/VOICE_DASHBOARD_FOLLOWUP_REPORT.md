# ANONYMOUX STUDIO 2.5.1 — Voice Studio & Dashboard Header Repair

**Base release:** `ANONYMOUX_STUDIO_2.5.0_FULLY_REPAIRED.zip`  
**New release:** `ANONYMOUX_STUDIO_2.5.1_VOICE_DASHBOARD_FIX.zip`  
**Date:** 2026-11-12

## 1. User-requested dashboard header change

- Removed the ANONYMOUX logo from the shared signed-in top bar.
- Removed the top-bar Sign out button.
- Replaced the removed controls with a live wallet balance chip showing the authenticated user's current credit balance and linking to `credits.php`.
- Kept the theme toggle and mobile navigation button.
- Preserved sign-out functionality by moving the CSRF-protected POST logout form into the sidebar account footer.
- Wallet balance is read through the existing `voice_wallet_balance()` service, preserving the platform's lazy wallet initialization and existing credit ledger.
- Bumped the navigation stylesheet version to avoid stale mobile browser caching.

## 2. Voice Studio repair

- Improved Fish Audio failure classification for HTTP 401, 402, 403, 404, 422, 429, and 5xx responses.
- Added actionable, sanitized messages for rejected API keys, provider account permissions/quota, invalid voice references, invalid requests, rate limiting, temporary provider outages, and missing PHP cURL/outbound HTTPS capability.
- Preserved the existing Fish Audio REST endpoint, `s2.1-pro-free` model header, server-side key vault, and audio generation pipeline. Current official Fish Audio developer examples confirm `POST https://api.fish.audio/v1/tts`, Bearer authentication, JSON request bodies, and the `s2.1-pro-free` model header.
- TTS endpoint now returns safe provider/runtime diagnostics instead of collapsing every provider failure into a generic message. Unexpected internal exceptions remain generic and are logged server-side.
- Updated client retry behavior so HTTP 5xx responses do not discard the pending idempotency key. This avoids generating a fresh charge reference after an uncertain server/provider failure.
- Preserved existing per-user charge/refund idempotency, audio storage, and history behavior.

## 3. Files modified in this follow-up

- `app/platform_header.php`
- `assets/navigation.css`
- `app/voice.php`
- `api/voice/tts.php`
- `assets/voice-studio.js`
- `voice-studio.php`
- `tests/voice_dashboard_followup_check.py`

## 4. Tests executed

| Check | Result |
|---|---|
| PHP syntax check — 80 PHP files | PASS |
| JavaScript syntax check — 12 files | PASS |
| Existing branding/voice integration regression | PASS |
| Existing Tools & Tutorials admin regression | PASS |
| Existing resource migration regression (Python SQLite) | PASS |
| Existing voice flow regression | PASS |
| Existing voice idempotency migration regression | PASS |
| New dashboard header + voice diagnostics regression | PASS |
| ZIP archive integrity | PASS |

## 5. Important live-testing limitation

This environment has no PHP PDO database drivers and no PHP cURL extension. Therefore it cannot execute the PHP persistence layer against the production database or make a live Fish Audio request. The screenshot's actual provider-side failure cannot be conclusively diagnosed from the screenshot alone. The new Voice Studio error messages will identify the specific provider response or hosting dependency when the user retries on the live host.

A live generation still requires:

1. A valid, active Fish Audio API key saved in Admin → Voice AI (with the existing encryption secret configured).
2. PHP cURL enabled by the hosting provider.
3. Outbound HTTPS access from the hosting account to `api.fish.audio`.
4. A valid Fish Audio voice reference and provider account entitlement/quota.
5. Writable private `storage/voice-audio` storage and a working database connection.

No provider key, user record, wallet balance, payment record, or production database was changed. No live generation or successful payment is claimed.

## 6. Deployment

1. Back up the live database and `storage/` directory.
2. Upload the contents of this ZIP over the existing application. Preserve `config.local.php`, environment variables, the database, and user storage.
3. Do not reset the database or wallets; this follow-up adds no database migration.
4. Sign in and confirm the top bar shows the correct current credit balance. Confirm Sign out is available at the bottom of the navigation drawer.
5. Open Admin → Voice AI. Confirm an active Fish Audio key exists and the encryption secret matches the secret used when that key was saved.
6. Confirm PHP cURL is enabled, then generate a short test script. If it fails, read the new exact error shown in Voice Studio and the corresponding admin key failure record; do not repeatedly submit an uncertain request.
7. Verify audio playback, download, history, credit debit, and any failure refund using a controlled test account.

**Release status:** source changes and available automated checks completed. Live Fish Audio and production-host acceptance remain pending because the required external credentials and hosting runtime are not available in this environment.
