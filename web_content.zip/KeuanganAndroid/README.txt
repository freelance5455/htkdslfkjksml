KEUANGAN - ANDROID APP

Ini adalah proyek Android Studio untuk menjadikan aplikasi Keuangan menjadi APK yang bisa dipasang langsung di HP, tanpa Play Store.

CARA MEMBUAT APK:
1. Install Android Studio di komputer.
2. Buka folder "KeuanganAndroid" dengan Android Studio.
3. Tunggu Gradle selesai melakukan Sync (internet diperlukan pertama kali).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. File APK biasanya ada di:
   app/build/outputs/apk/debug/app-debug.apk
6. Kirim file app-debug.apk ke HP Android, buka file tersebut, lalu tekan Install.

CATATAN:
- Aplikasi menggunakan index.html yang sudah ada di folder assets.
- Data aplikasi tetap disimpan secara lokal oleh aplikasi.
- Tidak perlu Play Store.
- Untuk distribusi pribadi, APK debug cukup untuk pemasangan manual.
