-- Mimopy: satu akun terikat ke satu device ID browser.
-- Jalankan di Supabase SQL Editor. Ini perlu dipasang sebelum HTML baru dipakai.
create table if not exists public.mimopy_device_bindings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  device_id text not null,
  bound_at timestamptz not null default now()
);

alter table public.mimopy_device_bindings enable row level security;
revoke all on public.mimopy_device_bindings from anon, authenticated;
grant select, insert, update, delete on public.mimopy_device_bindings to service_role;

create or replace function public.claim_mimopy_device(p_device_id text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_existing text;
begin
  if v_user_id is null then
    return jsonb_build_object('ok', false, 'code', 'not_authenticated');
  end if;
  if p_device_id is null or length(p_device_id) < 20 or length(p_device_id) > 200 then
    return jsonb_build_object('ok', false, 'code', 'invalid_device');
  end if;

  insert into public.mimopy_device_bindings(user_id, device_id)
  values (v_user_id, p_device_id)
  on conflict (user_id) do nothing;

  select b.device_id into v_existing
  from public.mimopy_device_bindings b
  where b.user_id = v_user_id;

  if v_existing = p_device_id then
    return jsonb_build_object('ok', true, 'code', 'device_allowed');
  end if;
  return jsonb_build_object('ok', false, 'code', 'device_already_bound');
end;
$$;

revoke all on function public.claim_mimopy_device(text) from public;
grant execute on function public.claim_mimopy_device(text) to authenticated;

-- Reset device manual oleh admin database bila pengguna sah berganti HP:
-- delete from public.mimopy_device_bindings where user_id = 'UUID_USER';
