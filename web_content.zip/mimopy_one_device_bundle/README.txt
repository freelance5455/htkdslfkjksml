MIMOPY — BUILD EKSPERIMEN BATAS 1 PERANGKAT

Isi:
- mimopy-one-device.html : build Mimopy dengan pemeriksaan device saat sesi user dipulihkan/login.
- one-device-lock.sql    : tabel binding + RPC untuk mengikat satu akun ke satu device ID browser.

CARA PASANG:
1. Backup versi Mimopy yang sekarang.
2. Buka Supabase Dashboard > SQL Editor.
3. Jalankan seluruh isi one-device-lock.sql.
4. Upload/pakai mimopy-one-device.html sebagai frontend baru.
5. Tes dengan akun uji: login di HP A, lalu login akun yang sama di browser/HP B. HP B harus ditolak.

RESET SAAT USER GANTI HP:
Jalankan di SQL Editor dengan UUID user yang sudah diverifikasi:
DELETE FROM public.mimopy_device_bindings WHERE user_id = 'UUID_USER';
Lalu user login lagi dari perangkat baru.

BATASAN KEAMANAN PENTING:
Ini adalah pembatasan berbasis device ID browser (localStorage), bukan identitas perangkat keras yang tidak bisa dipalsukan. Pengguna yang menghapus data browser atau memanipulasi JavaScript bisa mengubah ID. Untuk produk berbayar dengan perlindungan lebih kuat, semua data/API berbayar juga harus divalidasi terhadap binding aktif di backend/RLS. Jangan menganggap ini proteksi anti-bypass mutlak.

Admin tidak dibatasi oleh mekanisme ini. SQL perlu dijalankan sebelum frontend baru dipakai; tanpa itu, pemeriksaan perangkat akan gagal tertutup dan user tidak bisa lanjut login.
