# Litch 2 — APK Builder Package

## Upload this folder
For an HTML-to-APK builder, upload the CONTENTS of the `www` folder (or the `www` folder itself if the builder accepts folders).

## App settings
Name: Litch 2
Full name: Litch 2 — Scam Check Ethiopia
Package ID: com.yeabsira.litch2
Version: 1.0.0
Orientation: Portrait
Theme/background: #08090d
Display: Standalone

## Entry file
index.html

## Included
- index.html
- manifest.webmanifest
- sw.js
- icon.svg

The app is backend-free and works offline after loading. Reports stay on the device.
