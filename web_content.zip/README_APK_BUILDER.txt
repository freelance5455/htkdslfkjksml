NEXUS AI v1.8 — APK Builder package

This ZIP is a web-front-end package intended for a website/HTML-to-APK builder.
Included: index.html (chat UI).

IMPORTANT LIMITATION:
This is not a complete standalone AI APK. The NEXUS AI backend is a separate Node.js server.
For AI chat, file upload/analyze, and APK diagnostics, deploy the backend separately over HTTPS
and configure its URL using the "Backend URL" button in the app. Do not put provider API keys
in this frontend or APK.

APK Builder instructions:
1. Upload this ZIP to your chosen HTML/web-to-APK builder.
2. If it asks for the start page, use index.html.
3. Generate/build APK.
4. After installing, tap Backend URL and enter your deployed HTTPS backend URL.
5. Backend deployment and API connectivity are not included or verified by this ZIP.
