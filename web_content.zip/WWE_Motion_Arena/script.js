(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const video = $("cameraVideo");
  const handCanvas = $("handCanvas");
  const handCtx = handCanvas.getContext("2d");
  const arena = $("arena");

  const DIFFICULTY = {
    easy:   { rivalMax: 80,  punchDamage: 10, attackDamage: 3, cooldown: 10000 },
    normal: { rivalMax: 100, punchDamage: 8, attackDamage: 5, cooldown: 7200 },
    hard:   { rivalMax: 120, punchDamage: 6, attackDamage: 8, cooldown: 4600 }
  };

  let level = "easy";
  let playerHealth = 100;
  let rivalHealth = DIFFICULTY[level].rivalMax;
  let lastAttack = 0;
  let running = false;
  let handsModel = null;
  let cameraStream = null;
  let previousWrist = new Map();
  let lastPunch = 0;
  let matchOver = false;
  let opponentGroup, torso, head, leftArm, rightArm, leftLeg, rightLeg;
  let scene, camera, renderer, clock;
  let opponentHitUntil = 0;
  let opponentAttackUntil = 0;

  function resizeHandCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    handCanvas.width = Math.round(window.innerWidth * dpr);
    handCanvas.height = Math.round(window.innerHeight * dpr);
    handCanvas.style.width = window.innerWidth + "px";
    handCanvas.style.height = window.innerHeight + "px";
    handCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function makeArena() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x101a2a);
    scene.fog = new THREE.Fog(0x101a2a, 13, 34);
    camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 2.25, 8.2);
    camera.lookAt(0, 1.65, -2.5);
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    arena.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xa9dfff, 0x182030, 2.1));
    const key = new THREE.DirectionalLight(0xffffff, 2.7);
    key.position.set(-4, 8, 5); key.castShadow = true; scene.add(key);
    const rim = new THREE.PointLight(0x2ddcff, 30, 18); rim.position.set(4, 5, -3); scene.add(rim);
    const red = new THREE.PointLight(0xff3155, 18, 14); red.position.set(-5, 4, -4); scene.add(red);

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshStandardMaterial({ color: 0x121b2a, roughness: .88 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -.08; floor.receiveShadow = true; scene.add(floor);

    // Ring ropes and posts.
    const ring = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color: 0x29384b, metalness: .35, roughness: .55 });
    const ropeMat = new THREE.MeshStandardMaterial({ color: 0x57dff5, emissive: 0x103744, roughness: .4 });
    const postGeo = new THREE.CylinderGeometry(.07, .09, 2.6, 10);
    [[-4, -3.2], [4, -3.2], [-4, 1.3], [4, 1.3]].forEach(([x,z]) => {
      const p = new THREE.Mesh(postGeo, mat); p.position.set(x, 1.25, z); p.castShadow = true; ring.add(p);
    });
    [0.65, 1.25, 1.85].forEach(y => {
      const geo = new THREE.CylinderGeometry(.025, .025, 8, 8);
      [[y,-3.2],[y,1.3]].forEach(([yy,z]) => { const r = new THREE.Mesh(geo, ropeMat); r.rotation.z = Math.PI/2; r.position.set(0,yy,z); ring.add(r); });
      [[y,-4],[y,4]].forEach(([yy,x]) => { const r = new THREE.Mesh(geo, ropeMat); r.rotation.x = Math.PI/2; r.position.set(x,yy,-.95); ring.add(r); });
    });
    const matFloor = new THREE.Mesh(new THREE.BoxGeometry(8.1,.22,4.7), new THREE.MeshStandardMaterial({ color: 0x26364a, roughness: .8 }));
    matFloor.position.set(0,.05,-.95); matFloor.receiveShadow = true; ring.add(matFloor);
    scene.add(ring);

    // Crowd silhouettes with varied scale and color behind the ring.
    const crowd = new THREE.Group();
    const colors = [0x34485d,0x5a3e4d,0x3d5860,0x554d3a,0x34435d];
    for (let row=0; row<3; row++) {
      for (let i=0; i<34; i++) {
        const x = (i-16.5)*.43 + (row%2)*.16;
        const z = -5.0 - row*.65;
        const h = .42 + Math.random()*.3;
        const color = colors[(i+row)%colors.length];
        const body = new THREE.Mesh(new THREE.CapsuleGeometry(.105,h*.55,3,6), new THREE.MeshStandardMaterial({color, roughness: .9}));
        body.position.set(x,.55+h*.45,z); body.scale.x = .8 + Math.random()*.5; crowd.add(body);
        const skin = new THREE.Mesh(new THREE.SphereGeometry(.105,8,8), new THREE.MeshStandardMaterial({color:0x98745f, roughness:.9}));
        skin.position.set(x, .95+h*.5, z); crowd.add(skin);
      }
    }
    scene.add(crowd);
    createOpponent();
    clock = new THREE.Clock();
    window.addEventListener("resize", onResize);
    animate();
  }

  function createOpponent() {
    opponentGroup = new THREE.Group();
    opponentGroup.position.set(0, 0, -2.1);
    const skin = new THREE.MeshStandardMaterial({ color: 0x9d705b, roughness: .68 });
    const skinLight = new THREE.MeshStandardMaterial({ color: 0xb9876e, roughness: .62 });
    const trunks = new THREE.MeshStandardMaterial({ color: 0x172b49, roughness: .7 });
    const boots = new THREE.MeshStandardMaterial({ color: 0x11151d, roughness: .6 });
    const hair = new THREE.MeshStandardMaterial({ color: 0x17191e, roughness: .9 });
    const add = (geo, mat, pos, scale) => {
      const m = new THREE.Mesh(geo, mat); m.position.set(...pos); if (scale) m.scale.set(...scale); m.castShadow = true; m.receiveShadow = true; opponentGroup.add(m); return m;
    };
    torso = add(new THREE.CapsuleGeometry(.48,.72,8,16), skin, [0,1.52,0], [1.18,1.12,.7]);
    add(new THREE.SphereGeometry(.47,18,14), skinLight, [-.35,1.88,.03], [.72,.38,.63]);
    add(new THREE.SphereGeometry(.47,18,14), skinLight, [.35,1.88,.03], [.72,.38,.63]);
    add(new THREE.BoxGeometry(.45,.42,.42), trunks, [0,.85,0], [1.6,.75,1]);
    head = add(new THREE.SphereGeometry(.31,24,20), skin, [0,2.55,.02], [1,.98,.9]);
    add(new THREE.SphereGeometry(.32,18,12), hair, [0,2.72,-.02], [1.02,.5,.98]);
    add(new THREE.SphereGeometry(.12,12,10), skin, [-.32,2.55,0], [.6,1, .7]);
    add(new THREE.SphereGeometry(.12,12,10), skin, [.32,2.55,0], [.6,1, .7]);
    // Face details are intentionally stylized and non-graphic.
    const eyeMat = new THREE.MeshStandardMaterial({color:0xf3eee2, roughness:.4});
    const pupilMat = new THREE.MeshStandardMaterial({color:0x17191c});
    [-.115,.115].forEach(x => {
      add(new THREE.SphereGeometry(.045,10,8), eyeMat, [x,2.59,.292], [1,.7,.35]);
      add(new THREE.SphereGeometry(.018,8,8), pupilMat, [x,2.59,.31]);
    });
    add(new THREE.BoxGeometry(.16,.025,.025), hair, [0,2.68,.29]);
    add(new THREE.SphereGeometry(.055,10,8), skinLight, [0,2.48,.29], [.7,.6,.6]);

    leftArm = new THREE.Group(); leftArm.position.set(-.57,1.98,0); opponentGroup.add(leftArm);
    rightArm = new THREE.Group(); rightArm.position.set(.57,1.98,0); opponentGroup.add(rightArm);
    function buildArm(group, side) {
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(.17,.48,6,12), skinLight); upper.position.set(side*.06,-.34,0); upper.rotation.z = side*-.12; group.add(upper);
      const fore = new THREE.Mesh(new THREE.CapsuleGeometry(.145,.42,6,12), skin); fore.position.set(side*.1,-.82,.02); fore.rotation.z = side*-.08; group.add(fore);
      const fist = new THREE.Mesh(new THREE.SphereGeometry(.17,12,10), skinLight); fist.position.set(side*.12,-1.1,.04); fist.scale.set(1,.9,.8); group.add(fist);
    }
    buildArm(leftArm,-1); buildArm(rightArm,1);
    leftLeg = new THREE.Group(); leftLeg.position.set(-.25,.77,0); opponentGroup.add(leftLeg);
    rightLeg = new THREE.Group(); rightLeg.position.set(.25,.77,0); opponentGroup.add(rightLeg);
    function buildLeg(group) {
      const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(.22,.48,7,12), skin); thigh.position.y=-.35; group.add(thigh);
      const shin = new THREE.Mesh(new THREE.CapsuleGeometry(.15,.45,7,12), skinLight); shin.position.set(0,-.82,.02); group.add(shin);
      const boot = new THREE.Mesh(new THREE.BoxGeometry(.32,.2,.52), boots); boot.position.set(0,-1.13,.12); group.add(boot);
    }
    buildLeg(leftLeg); buildLeg(rightLeg);
    scene.add(opponentGroup);
  }

  function onResize() {
    if (!renderer) return;
    camera.aspect = window.innerWidth/window.innerHeight; camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth,window.innerHeight); resizeHandCanvas();
  }

  function animate() {
    requestAnimationFrame(animate);
    if (!renderer) return;
    const t = clock.getElapsedTime();
    if (opponentGroup && !matchOver) {
      const hit = performance.now() < opponentHitUntil;
      const attack = performance.now() < opponentAttackUntil;
      torso.scale.y = 1.12 + Math.sin(t*2.3)*.018;
      opponentGroup.position.y = Math.sin(t*1.5)*.018;
      opponentGroup.rotation.y = Math.sin(t*.65)*.045;
      leftArm.rotation.x = Math.sin(t*1.7)*.09 + (attack ? -.45 : 0);
      rightArm.rotation.x = Math.sin(t*1.5+1)*.08 + (hit ? -.25 : 0);
      leftArm.rotation.z = -.08 + Math.sin(t*1.1)*.04;
      rightArm.rotation.z = .08 - Math.sin(t*1.1)*.04;
      leftLeg.rotation.x = Math.sin(t*1.4)*.025;
      rightLeg.rotation.x = -Math.sin(t*1.4)*.025;
      head.rotation.y = Math.sin(t*.8)*.035;
      if (hit) opponentGroup.rotation.x = -.12;
      else if (!attack) opponentGroup.rotation.x = 0;
    }
    renderer.render(scene,camera);
  }

  function updateHud() {
    const cfg = DIFFICULTY[level];
    $("playerHealth").style.width = Math.max(0,playerHealth) + "%";
    $("rivalHealth").style.width = Math.max(0,rivalHealth/cfg.rivalMax*100) + "%";
    $("playerHealthText").textContent = `${Math.max(0,playerHealth)} / 100`;
    $("rivalHealthText").textContent = `${Math.max(0,rivalHealth)} / ${cfg.rivalMax}`;
  }

  function showPunch() {
    const flash = $("punchFlash");
    flash.classList.remove("show"); void flash.offsetWidth; flash.classList.add("show");
    opponentHitUntil = performance.now()+360;
    opponentGroup.position.z = -2.02;
    setTimeout(()=> { if (opponentGroup) opponentGroup.position.z = -2.1; },130);
  }

  function playerPunch() {
    if (matchOver || performance.now()-lastPunch<550) return;
    lastPunch = performance.now();
    rivalHealth = Math.max(0,rivalHealth-DIFFICULTY[level].punchDamage);
    showPunch(); updateHud();
    if (rivalHealth<=0) finishMatch(true);
  }

  function rivalAttack() {
    if (matchOver || !running) return;
    playerHealth = Math.max(0,playerHealth-DIFFICULTY[level].attackDamage);
    opponentAttackUntil = performance.now()+450;
    const crack = $("crackOverlay");
    crack.classList.remove("show"); void crack.offsetWidth; crack.classList.add("show");
    updateHud();
    if (playerHealth<=0) finishMatch(false);
  }

  function finishMatch(won) {
    matchOver = true;
    $("resultTitle").textContent = won ? "YOU WIN" : "MATCH OVER";
    $("resultTitle").style.color = won ? "var(--cyan)" : "var(--red)";
    $("resultPanel").classList.remove("hidden");
  }

  function resetMatch() {
    playerHealth = 100; rivalHealth = DIFFICULTY[level].rivalMax;
    lastAttack = performance.now(); matchOver = false;
    $("resultPanel").classList.add("hidden");
    $("crackOverlay").classList.remove("show");
    updateHud();
    if (opponentGroup) { opponentGroup.rotation.set(0,0,0); opponentGroup.position.set(0,0,-2.1); }
  }

  document.querySelectorAll(".level").forEach(btn => {
    btn.addEventListener("click", () => {
      level = btn.dataset.level;
      document.querySelectorAll(".level").forEach(b=>b.classList.toggle("active",b===btn));
      resetMatch();
    });
  });
  $("resetButton").addEventListener("click",resetMatch);
  $("playAgain").addEventListener("click",resetMatch);

  function drawHands(results) {
    const w = window.innerWidth, h = window.innerHeight;
    handCtx.clearRect(0,0,w,h);
    if (!results.multiHandLandmarks) return;
    const connections = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]];
    results.multiHandLandmarks.forEach((landmarks,index) => {
      const pts = landmarks.map(p=>({x:(1-p.x)*w,y:p.y*h}));
      handCtx.lineWidth=4; handCtx.strokeStyle=index===0?"#63edff":"#ff6380";
      handCtx.shadowColor=handCtx.strokeStyle; handCtx.shadowBlur=9;
      connections.forEach(([a,b])=>{handCtx.beginPath();handCtx.moveTo(pts[a].x,pts[a].y);handCtx.lineTo(pts[b].x,pts[b].y);handCtx.stroke();});
      handCtx.shadowBlur=5; handCtx.fillStyle="#ffffff";
      pts.forEach((p,i)=>{handCtx.beginPath();handCtx.arc(p.x,p.y,i===0?5:3,0,Math.PI*2);handCtx.fill();});
    });
    handCtx.shadowBlur=0;
  }

  function detectPunch(results) {
    if (!results.multiHandLandmarks) { previousWrist.clear(); return; }
    results.multiHandLandmarks.forEach((lm,index) => {
      const wrist=lm[0];
      const key=String(index);
      const prev=previousWrist.get(key);
      if (prev) {
        const dx=wrist.x-prev.x, dy=wrist.y-prev.y;
        const speed=Math.hypot(dx,dy);
        if (speed>.105 && performance.now()-lastPunch>550) playerPunch();
      }
      previousWrist.set(key,{x:wrist.x,y:wrist.y});
    });
    for (const key of [...previousWrist.keys()]) if (Number(key)>=results.multiHandLandmarks.length) previousWrist.delete(key);
  }

  async function startCamera() {
    $("startButton").disabled=true;
    $("startButton").textContent="STARTING CAMERA…";
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera access requires HTTPS and a supported browser.");
      cameraStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:{ideal:1280},height:{ideal:720}},audio:false});
      video.srcObject=cameraStream; await video.play();
      if (!window.Hands) throw new Error("Hand tracking library did not load. Check your internet connection.");
      handsModel = new Hands({locateFile:(file)=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`});
      handsModel.setOptions({maxNumHands:2,modelComplexity:1,minDetectionConfidence:.62,minTrackingConfidence:.58});
      handsModel.onResults((results)=>{drawHands(results);detectPunch(results);});
      const processFrame = async () => {
        if (!running) return;
        if (video.readyState>=2) await handsModel.send({image:video});
        requestAnimationFrame(processFrame);
      };
      running=true; processFrame();
      $("centerMessage").classList.add("hidden");
      $("cameraStatus").textContent="HAND TRACKING ON";
      $("cameraDot").classList.add("on");
      lastAttack=performance.now();
      attackLoop();
    } catch (err) {
      console.error(err);
      $("startButton").disabled=false;
      $("startButton").textContent="TRY CAMERA AGAIN";
      $("centerMessage").querySelector("p").textContent=err.message || "Could not start the camera. Allow camera permission and try again.";
    }
  }

  function attackLoop() {
    if (!running) return;
    const now=performance.now();
    if (!matchOver && now-lastAttack>=DIFFICULTY[level].cooldown) {
      lastAttack=now; rivalAttack();
    }
    setTimeout(attackLoop,250);
  }

  $("startButton").addEventListener("click",startCamera);
  window.addEventListener("beforeunload",()=>{
    running=false;
    if(cameraStream) cameraStream.getTracks().forEach(track=>track.stop());
  });

  resizeHandCanvas();
  makeArena();
  updateHud();
})();