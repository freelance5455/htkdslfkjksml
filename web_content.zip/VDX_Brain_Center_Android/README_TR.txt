VDX BRAIN CENTER - ANDROID PROJESİ v1.0

Bu paket, mevcut VDX Brain Center HTML uygulamasını Android WebView içinde açan
bir Android Studio projesidir. Uygulama içeriği assets/index.html dosyasındadır.

APK DERLEME:
1. Bilgisayarda Android Studio kurulu olmalı.
2. ZIP'i çıkar ve Android Studio'da VDX_Brain_Center_Android klasörünü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. APK, app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

GEREKSİNİMLER:
- Android Studio
- JDK 17 veya Android Studio'nun önerdiği JDK
- Android SDK Platform 35
- İnternet (ilk Gradle senkronizasyonu için)

NOTLAR:
- HTML uygulaması app/src/main/assets/index.html içindedir.
- JavaScript ve DOM Storage (localStorage) WebView içinde etkinleştirilmiştir.
- Uygulama çevrimdışı kullanılacak şekilde tasarlanmıştır.
- Tarayıcı depolaması uygulama verilerinin temizlenmesi/kaldırılması halinde silinebilir.
- Düzenli olarak uygulama içindeki JSON yedekleme özelliğini kullan.
- Bu paket APK dosyası değil, APK üretmek için Android Studio kaynak projesidir.
