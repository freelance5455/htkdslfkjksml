FireMax Sensitivity Android project

This is an Android Studio project wrapper for the supplied HTML app. It is NOT a built APK.
To build an APK:
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync; ensure Android SDK Platform 35 and a compatible JDK are installed.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually app/build/outputs/apk/debug/app-debug.apk.

The app loads app/src/main/assets/index.html in an Android WebView. It does not connect to or modify Free Fire.
