Gym Progress - Web App

This is a lightweight mobile web app prototype designed to be packaged as an Android APK by a web-to-APK service.
Open index.html in a browser to preview it.
