/* =====================================================================
   TIME STRIKE 5 — WORLD / ENVIRONMENT / LIFE SYSTEMS
   (loaded before main script; all globals referenced lazily)
   ===================================================================== */
"use strict";

/* seeded rng for a stable city */
function mulberry32(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
let srand = mulberry32(20260927);
const sr = (a,b)=> a + srand()*(b-a);
const sri = (a,b)=> Math.floor(sr(a,b+1));
const spick = arr => arr[sri(0,arr.length-1)];

/* -------------------------------------------------------------- */
/* Global V5 state                                                  */
/* -------------------------------------------------------------- */
const V5 = {
  version: '5.0',
  tod: 0.30,             // time of day 0..1 (0=midnight) — START IN DAYLIGHT
  todLen: 480,            // seconds per full cycle
  weather: 0,             // 0 clear 1 cloudy 2 rain 3 storm
  weatherT: 60,
  warMix: 0, warTarget: 0,
  rain: null, rainGeo: null,
  lamps: [], lampMat: null, windowMat: null,
  traffic: [], civilians: [], vehicles: [], usableCars: [],
  cullables: [], cullT: 0,
  questMarkers: [], beacons: [],
  water: [],
  fps: 60, fpsAcc: 0, fpsN: 0, fpsLowT: 0, autoQualityDone: false,
  lightningT: 0, flashI: 0,
  radioQ: [], radioActive: null,
  sirenT: 20, hornT: 9,
  mission: null, missionState: 'idle',   // idle|spawning|active|done
  spawnQ: [], spawnT: 0,
  choiceCb: null,
  plane: null, planeState: null,
  boss: null,
  xp: 0, level: 1, rep: 0,
  questsDone: {}, questActive: null, questOffered: 0,
  civiliansSaved: 0, intelFound: 0,
  chaseCar: null, escortCar: null, target: null, snipersLeft: 0,
  defendT: 0, checkpointIdx: 0, checkpoints: [], carryItem: null,
  chapterSeen: {}, started: false
};
const XP_NEED = l => Math.floor(300 * Math.pow(l, 1.35));

/* quality presets (Tecno Spark 10 Pro = Medium default) */
const QUALITY = {
  low:  { pr:1.0, shadow:0,    rain:300, cull:110, fogF:160, particles:0.6 },
  med:  { pr:1.5, shadow:1024, rain:650, cull:150, fogF:220, particles:1 },
  high: { pr:2.0, shadow:2048, rain:1000, cull:190, fogF:280, particles:1 }
};
function quality(){ return QUALITY[SET.quality] || QUALITY.med; }

/* -------------------------------------------------------------- */
/* DISTRICTS                                                        */
/* -------------------------------------------------------------- */
const DISTRICTS = {
  downtown:   { cx:0,    cz:-10,  r:70,  ar:'وسط المدينة',  en:'Downtown' },
  market:     { cx:0,    cz:-140, r:55,  ar:'السوق القديم', en:'Old Market' },
  industrial: { cx:140,  cz:10,   r:70,  ar:'الحي الصناعي', en:'Industrial' },
  residential:{ cx:-140, cz:10,   r:65,  ar:'الحي السكني', en:'Residential' },
  hospital:   { cx:-38,  cz:-70,  r:40,  ar:'المستشفى',     en:'Hospital' },
  airport:    { cx:0,    cz:160,  r:80,  ar:'المطار',       en:'Airport' },
  docks:      { cx:150,  cz:140,  r:60,  ar:'الميناء',      en:'The Port' },
  ruins:      { cx:-140, cz:-140, r:60,  ar:'الأنقاض',      en:'The Ruins' },
  bridge:     { cx:0,    cz:67,   r:30,  ar:'جسر النهر',    en:'River Bridge' },
  highway:    { cx:120,  cz:70,   r:60,  ar:'الطريق السريع',en:'Highway' },
  base1:      { cx:92,   cz:-92,  r:35,  ar:'القاعدة الشمالية الشرقية', en:'NE Base' },
  base2:      { cx:-86,  cz:96,   r:35,  ar:'القاعدة الغربية', en:'Western Base' },
  base3:      { cx:70,   cz:120,  r:35,  ar:'قاعدة المطار', en:'Airport Base' },
  tower:      { cx:64,   cz:-64,  r:35,  ar:'البرج',        en:'The Tower' },
  undercity:  { cx:0,    cz:6,    r:30,  ar:'تحت المدينة',  en:'Undercity' }
};

/* -------------------------------------------------------------- */
/* WALKABLE HEIGHT + height-aware collision (patched in by build)  */
/* -------------------------------------------------------------- */
function groundHeightAt(pos, radius){
  let h = 0;
  for(const c of colliders){
    if(!c.walkable) continue;
    if(pos.x > c.minX + 0.1 && pos.x < c.maxX - 0.1 && pos.z > c.minZ + 0.1 && pos.z < c.maxZ - 0.1){
      if(c.h <= pos.y + 0.55 && c.h > h) h = c.h; // only surfaces at/below feet+step
    }
  }
  return h;
}

/* -------------------------------------------------------------- */
/* WORLD BUILDER v5                                                 */
/* -------------------------------------------------------------- */
function buildWorldV5(){
  ARENA = 210;
  srand = mulberry32(20260927);
  const W = worldRoot;

  /* ---- ground ---- */
  const ground = new THREE.Mesh(new THREE.BoxGeometry(440, 1, 440), M.ground);
  ground.position.y = -0.5; ground.receiveShadow = SET.shadows; W.add(ground);

  const roadMat = new THREE.MeshStandardMaterial({ color:0x35383e, roughness:0.95 });
  const lineMat = new THREE.MeshBasicMaterial({ color:0xb9b9a8 });
  const addRoad = (x, z, w, l, rotY) => {
    const r = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, l), roadMat);
    r.position.set(x, 0.02, z); if(rotY) r.rotation.y = rotY;
    r.receiveShadow = SET.shadows; W.add(r);
  };
  const addLine = (x, z, w, l, rotY) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.021, l), lineMat);
    m.position.set(x, 0.045, z); if(rotY) m.rotation.y = rotY; W.add(m);
  };

  /* ---- road network: ring + avenues + bridges ---- */
  // ring square ±186
  for(const s of [-186, 186]){ addRoad(s, 0, 15, 378); }
  for(const s of [-186, 186]){ addRoad(0, s, 378, 15); }
  // N-S avenue & E-W avenue
  addRoad(0, 0, 13, 372);
  addRoad(0, 10, 372, 13);
  // ring centre dashes
  for(let i=-180; i<180; i+=14){
    addLine(i+7, -186, 5, 0.7); addLine(i+7, 186, 5, 0.7);
    addLine(-186, i+7, 0.7, 5); addLine(186, i+7, 0.7, 5);
    addLine(0, i+7, 0.5, 6);   // avenue dashes
    addLine(i+7, 10, 6, 0.5);
  }

  /* ---- river + bridges ---- */
  const waterMat = new THREE.MeshStandardMaterial({ color:0x1b4f72, roughness:0.15, metalness:0.4, transparent:true, opacity:0.92 });
  const river = new THREE.Mesh(new THREE.BoxGeometry(358, 0.1, 18), waterMat);
  river.position.set(0, -0.06, 67); W.add(river); V5.water.push(river);
  // quay water SE corner
  const quay = new THREE.Mesh(new THREE.BoxGeometry(60, 0.1, 60), waterMat);
  quay.position.set(180, -0.06, 180); W.add(quay); V5.water.push(quay);
  const quay2 = new THREE.Mesh(new THREE.BoxGeometry(26, 0.1, 78), waterMat);
  quay2.position.set(197, -0.06, 121); W.add(quay2); V5.water.push(quay2);
  // river banks (concrete, walkable) with 3 bridge gaps
  const bankMat = new THREE.MeshStandardMaterial({ color:0x7d8288, roughness:0.9 });
  const bankSeg = (x1, x2, z) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(x2-x1, 0.9, 1.6), bankMat);
    b.position.set((x1+x2)/2, 0.45, z); b.receiveShadow = SET.shadows; W.add(b);
    colliders.push({ minX:x1, maxX:x2, minZ:z-0.8, maxZ:z+0.8, h:0.55, walkable:true });
  };
  for(const zz of [58.2, 75.8]){
    bankSeg(-179, -124, zz); bankSeg(-116, -4, zz); bankSeg(4, 116, zz); bankSeg(124, 179, zz);
  }
  // bridges (decks)
  const bridgeDeck = (x, w) => {
    const d = new THREE.Mesh(new THREE.BoxGeometry(w, 0.35, 20), bankMat);
    d.position.set(x, 0.32, 67); d.receiveShadow = SET.shadows; W.add(d);
    colliders.push({ minX:x-w/2, maxX:x+w/2, minZ:57, maxZ:77, h:0.5, walkable:true });
    for(const sx of [-1,1]){
      const rail = new THREE.Mesh(new THREE.BoxGeometry(w, 1.0, 0.3), M.barrier);
      rail.position.set(x, 1.0, 67 + sx*9.4); W.add(rail);
    }
  };
  bridgeDeck(0, 18); bridgeDeck(-120, 9); bridgeDeck(120, 9);

  /* ---- generic prop placer ---- */
  const prop = (name, fit, x, z, ry, cull) => {
    const p = fitAndGround(models[name].scene.clone(true), fit);
    p.position.set(x, 0, z); p.rotation.y = ry;
    enableShadows(p); W.add(p);
    if(cull !== false) V5.cullables.push({ o:p, x, z });
    return p;
  };
  const box = (x,y,z,w,h,d,mat,opts) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), mat);
    b.position.set(x,y,z);
    if(opts && opts.ry) b.rotation.y = opts.ry;
    b.castShadow = SET.shadows; b.receiveShadow = SET.shadows; W.add(b);
    const h2 = y + h/2;
    if(!opts || opts.solid !== false)
      colliders.push({ minX:x-w/2, maxX:x+w/2, minZ:z-d/2, maxZ:z+d/2, h:h2, walkable:!!(opts&&opts.walkable) });
    if(!opts || opts.cull !== false) V5.cullables.push({ o:b, x, z });
    return b;
  };
  const lampMat = new THREE.MeshStandardMaterial({ color:0x777777, emissive:0x000000 });
  const lampHeadMat = new THREE.MeshStandardMaterial({ color:0xfff2c0, emissive:0xffe9a8, emissiveIntensity:0 });
  V5.lampHeadMat = lampHeadMat;
  const streetlamp = (x, z, ry) => {
    prop('streetlight', { height:7 }, x, z, ry);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 6), lampHeadMat);
    head.position.set(x + Math.sin(ry)*0.9, 6.7, z + Math.cos(ry)*0.9);
    W.add(head); V5.lamps.push(head);
  };
  const carProp = (x, z, ry, type, usable) => {
    const t = type || spick(['car_sedan','car_hatchback','car_taxi','car_stationwagon','car_police']);
    const p = prop(t, { length:4.6 }, x, z, ry);
    const b = new THREE.Box3().setFromObject(p);
    colliders.push({ minX:b.min.x, maxX:b.max.x, minZ:b.min.z, maxZ:b.max.z, h:1.35, walkable:true });
    if(usable !== false) V5.usableCars.push({ mesh:p, x, z, type:t, hp:220, yaw:ry });
    return p;
  };

  /* ================= DOWNTOWN ================= */
  const bldgTypes = ['building_A','building_B','building_C','building_D','building_E','building_F','building_G','building_H'];
  {
    const plaza = fitAndGround(models.pavement.scene.clone(true), { width:16 });
    plaza.position.set(0, 0.02, -18); enableShadows(plaza); W.add(plaza);
    const fountain = fitAndGround(models.fountain.scene.clone(true), { width:12 });
    fountain.position.set(0, 0.02, -18); enableShadows(fountain); W.add(fountain);
    colliders.push({ minX:-3.6, maxX:3.6, minZ:-21.6, maxZ:-14.4, h:1.8, walkable:true });
    // mission board (quest board)
    const board = box(8.5, 1.5, -18, 3.2, 3.0, 0.4, new THREE.MeshStandardMaterial({ color:0x5d4024, roughness:0.85 }), { walkable:false });
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 2.2),
      new THREE.MeshStandardMaterial({ color:0x111a2e, emissive:0x2a4a8a, emissiveIntensity:0.7 }));
    screen.position.set(8.5, 1.8, -17.75); W.add(screen);
    V5.board = board;
    // buildings ring
    const slots = [
      [0,-64],[-34,-58],[34,-58],[58,-34],[58,20],[34,52],[-30,54],[-58,26],[-58,-28],
      [-20,-42],[22,-42],[44,-6],[-44,-6],[18,44],[-16,40],[-80,-58],[80,-58],
      [-88,60],[92,52],[110,-20],[-110,-16],[46,-86],[-46,-86]
    ];
    slots.forEach((p, i) => {
      const useKen = (i % 4 === 2);
      const pool = useKen ? ['ken_a','ken_b','ken_c','ken_d'] : bldgTypes;
      const t = spick(pool);
      const h = useKen ? sr(9, 15) : sr(22, 46);
      const b = fitAndGround(models[t].scene.clone(true), { height:h });
      b.position.set(p[0], 0, p[1]); b.rotation.y = Math.atan2(-p[0], -p[1]) + sr(-0.3,0.3);
      enableShadows(b); W.add(b);
      addColliderFromObject(b);
      if(h < 30) V5.cullables.push({ o:b, x:p[0], z:p[1] });
    });
    // the TOWER (mission 12 landmark) — tall spire NE
    const tower = fitAndGround(models.building_A.scene.clone(true), { height:64 });
    tower.position.set(64, 0, -64); tower.rotation.y = 0.7; enableShadows(tower); W.add(tower);
    addColliderFromObject(tower);
    box(58, 4.2, -52, 7, 8.4, 7, new THREE.MeshStandardMaterial({ color:0x33383f, roughness:0.8 }), { walkable:true }); // tower podium steps
    // overpass across E-W avenue (stairs + deck = also a tunnel below)
    const stairMat = new THREE.MeshStandardMaterial({ color:0x6a6f76, roughness:0.85 });
    for(let i=0;i<8;i++){ box(-30, 0.3+i*0.3, 22 - i*1.1, 5, 0.32, 1.15, stairMat, { walkable:true, cull:false }); }
    for(let i=0;i<8;i++){ box(-30, 0.3+i*0.3, -2 + i*1.1, 5, 0.32, 1.15, stairMat, { walkable:true, cull:false }); }
    const deck = box(-30, 2.85, 10, 5, 0.5, 22, stairMat, { walkable:true, cull:false });
    V5.cullables.push({ o:deck, x:-30, z:10 });
    for(const sx of [-1,1]) box(-30, 3.6, 10 + sx*2.2, 5, 0.9, 0.25, M.barrier, { cull:false }); // deck rails
    // city props
    prop('watertower', { height:15 }, -44, -44, 0);
    const dt = [ ['bench',-6,-2,0.4],['bench',6,-2,-0.4],['bench',-10,-26,2.6],['bench',10,-26,1.2],
      ['dumpster',-30,-18,0.3],['dumpster',32,-30,-0.5],['dumpster',16,30,1.1],
      ['firehydrant',-16,-6,0],['firehydrant',16,-14,1.6],['firehydrant',4,10,0],['firehydrant',-4,-32,1.6],
      ['trash',-5,-8,0],['trash',7,-12,1.4],['trash',-22,4,2.4],['trash',24,-8,0.5],
      ['bush',-13,12,0],['bush',13,12,1],['bush',-36,-2,2],['bush',36,-2,3.5],['bush',-6,-36,0.4],['bush',6,-36,2.2] ];
    for(const [t,x,z,ry] of dt){ prop(t, {bench:{length:2.2},dumpster:{length:2.4},firehydrant:{height:0.9},trash:{height:1.0},bush:{height:1.3}}[t], x, z, ry); }
    streetlamp(-12,-26,Math.PI); streetlamp(12,-26,0); streetlamp(-12,2,Math.PI); streetlamp(12,2,0);
    streetlamp(-26,-14,Math.PI/2); streetlamp(26,-14,-Math.PI/2); streetlamp(-26,26,Math.PI/2); streetlamp(26,26,-Math.PI/2);
    carProp(-24,-34,0.1); carProp(22,-38,-0.1); carProp(30,26,1.5); carProp(-30,24,-1.5);
  }

  /* ================= OLD MARKET ================= */
  {
    const mkMat = [0xa3524a, 0x4a7a52, 0xb08a3e, 0x5a6a9a].map(c => new THREE.MeshStandardMaterial({ color:c, roughness:0.85 }));
    for(let gx=0; gx<5; gx++) for(let gz=0; gz<4; gz++){
      const x = -44 + gx*22, z = -168 + gz*20;
      if(Math.abs(x) < 9 && Math.abs(z+140) < 14) continue;
      const t = spick(['ken_a','ken_b','ken_c','ken_d']);
      const b = fitAndGround(models[t].scene.clone(true), { height:sr(8,13) });
      b.position.set(x + sr(-2,2), 0, z + sr(-2,2)); b.rotation.y = sr(0, Math.PI);
      enableShadows(b); W.add(b); addColliderFromObject(b);
      V5.cullables.push({ o:b, x, z });
    }
    // market stalls (awnings)
    for(let i=0;i<10;i++){
      const x = sr(-40, 40), z = -150 + sr(0, 38);
      const st = box(x, 0.5, z, 2.2, 1.0, 1.4, new THREE.MeshStandardMaterial({ color:0x6b5537, roughness:0.9 }), { walkable:true });
      const aw = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.12, 2.0), spick(mkMat));
      aw.position.set(x, 2.1, z); aw.castShadow = SET.shadows; W.add(aw);
      const pole = box(x, 1.5, z, 0.1, 3.0, 0.1, M.gun, { solid:false });
      pole.position.set(x, 1.55, z);
    }
    streetlamp(-8,-124,Math.PI); streetlamp(8,-124,0); streetlamp(-8,-158,Math.PI); streetlamp(8,-158,0);
    prop('dumpster', { length:2.4 }, -34, -126, 0.3); prop('dumpster', { length:2.4 }, 36, -156, -0.6);
    carProp(-20,-118,1.57); carProp(18,-160,1.57);
  }

  /* ================= INDUSTRIAL ================= */
  {
    const whMat = new THREE.MeshStandardMaterial({ color:0x5d6470, roughness:0.9 });
    for(const [x,z,w,d,h] of [[100,10,26,18,10],[140,10,26,18,10],[180,-16,22,16,9],[120,52,24,20,11],[168,44,22,16,9]]){
      box(x, h/2, z, w, h, d, whMat, { walkable:false });
      const roof = new THREE.Mesh(new THREE.BoxGeometry(w+1, 0.5, d+1), new THREE.MeshStandardMaterial({ color:0x3c424c }));
      roof.position.set(x, h+0.25, z); roof.castShadow = SET.shadows; W.add(roof);
      const door = new THREE.Mesh(new THREE.BoxGeometry(w*0.4, 5, 0.4), new THREE.MeshStandardMaterial({ color:0x8a5a2a }));
      door.position.set(x, 2.5, z + d/2 + 0.1); W.add(door);
    }
    // container stacks (climbable parkour)
    const contMat = [0xa63c3c,0x2f6e4f,0x3a5a8a,0xb0862e].map(c=>new THREE.MeshStandardMaterial({ color:c, roughness:0.8 }));
    for(let i=0;i<14;i++){
      const x = sr(96, 186), z = sr(-40, 8);
      const stack = sri(1,3);
      for(let s=0;s<stack;s++)
        box(x, 1.3 + s*2.6, z + sr(-1,1), 2.5, 2.6, 6.5, spick(contMat), { walkable:true, ry:sr(-0.1,0.1) });
    }
    prop('watertower', { height:17 }, 100, -30, 0.4);
    prop('watertower', { height:15 }, 160, 24, 1.1);
    // smokestacks
    for(const [x,z] of [[112,-24],[118,-26]]){
      const c = new THREE.Mesh(new THREE.CylinderGeometry(1.6,2.2,26,10), new THREE.MeshStandardMaterial({ color:0x4a3f3a, roughness:0.95 }));
      c.position.set(x, 13, z); c.castShadow = SET.shadows; W.add(c);
      colliders.push({ minX:x-2, maxX:x+2, minZ:z-2, maxZ:z+2, h:26, walkable:false });
    }
    // barrels
    const barrelMat = new THREE.MeshStandardMaterial({ color:0x8a6a1f, roughness:0.7, metalness:0.3 });
    for(let i=0;i<16;i++){ const x=sr(100,180), z=sr(-36,60); box(x, 0.55, z, 0.9, 1.1, 0.9, barrelMat, { walkable:true }); }
    carProp(126, 36, 0.2, 'car_hatchback'); carProp(150, -4, -0.15, 'car_stationwagon');
    streetlamp(108, 2, Math.PI); streetlamp(152, 18, 0);
  }

  /* ================= RESIDENTIAL ================= */
  {
    for(let gx=0; gx<4; gx++) for(let gz=0; gz<4; gz++){
      const x = -166 + gx*24, z = -14 + gz*24;
      const t = spick(['ken_a','ken_b','ken_c','ken_d','ken_garage']);
      const b = fitAndGround(models[t].scene.clone(true), { height:sr(7,11) });
      b.position.set(x + sr(-2,2), 0, z + sr(-2,2)); b.rotation.y = sr(0, Math.PI*2);
      enableShadows(b); W.add(b); addColliderFromObject(b);
      V5.cullables.push({ o:b, x, z });
    }
    // fences + gardens
    const fenceMat = new THREE.MeshStandardMaterial({ color:0x7a6a4a, roughness:0.9 });
    for(let i=0;i<18;i++){
      const x = sr(-180,-100), z = sr(-28, 60);
      box(x, 0.4, z, sr(3,6), 0.8, 0.2, fenceMat, { walkable:true, ry:sr(0,Math.PI) });
    }
    for(let i=0;i<16;i++){ const x=sr(-184,-96), z=sr(-30,64); prop(spick(['bush','bush','trash']), {bush:{height:1.3},trash:{height:1.0}}[i%3?'bush':'trash'] || {height:1.2}, x, z, sr(0,3)); }
    streetlamp(-120,-8,Math.PI/2); streetlamp(-160,24,Math.PI/2); streetlamp(-136,48,-Math.PI/2);
    prop('bench', {length:2.2}, -128, 10, 0.5); prop('bench', {length:2.2}, -152, 36, 2.1);
    carProp(-122, 4, 1.57); carProp(-158, 28, 1.57); carProp(-140, -24, 0.05, 'car_taxi');
  }

  /* ================= HOSPITAL ================= */
  {
    const hb = fitAndGround(models.building_D.scene.clone(true), { height:26 });
    hb.position.set(-38, 0, -70); hb.rotation.y = 0.2; enableShadows(hb); W.add(hb);
    addColliderFromObject(hb);
    for(const [x,z] of [[-56,-58],[-20,-58]]){
      const w = fitAndGround(models[spick(['ken_b','ken_c'])].scene.clone(true), { height:11 });
      w.position.set(x, 0, z); enableShadows(w); W.add(w); addColliderFromObject(w);
      V5.cullables.push({ o:w, x, z });
    }
    const cross = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.4, 0.3),
      new THREE.MeshStandardMaterial({ color:0xffffff, emissive:0xff2d3a, emissiveIntensity:1.6 }));
    cross.position.set(-38, 22, -57.2); W.add(cross);
    V5.hospitalCross = cross;
    const amb = carProp(-46, -56, 0.1, 'car_police', false);
    const ambLight = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.25, 0.5),
      new THREE.MeshStandardMaterial({ color:0xff3040, emissive:0xff2030, emissiveIntensity:2 }));
    ambLight.position.set(-46, 1.9, -56); W.add(ambLight);
    streetlamp(-30, -64, 0); streetlamp(-46, -78, Math.PI);
    V5.ambulance = amb;
  }

  /* ================= AIRPORT ================= */
  {
    const rw = new THREE.Mesh(new THREE.BoxGeometry(200, 0.05, 24), new THREE.MeshStandardMaterial({ color:0x24262a, roughness:0.98 }));
    rw.position.set(0, 0.03, 162); rw.receiveShadow = SET.shadows; W.add(rw);
    for(let i=-95; i<95; i+=12){ addLine(i+6, 162, 5.5, 0.8); }
    addLine(0, 150, 1.2, 20); addLine(0, 174, 1.2, 20);
    // terminal
    const term = fitAndGround(models.ken_b.scene.clone(true), { height:12 });
    term.position.set(-30, 0, 134); enableShadows(term); W.add(term); addColliderFromObject(term);
    const term2 = fitAndGround(models.ken_c.scene.clone(true), { height:10 });
    term2.position.set(6, 0, 134); enableShadows(term2); W.add(term2); addColliderFromObject(term2);
    // control tower
    const ct = new THREE.Mesh(new THREE.CylinderGeometry(2.2,2.8,22,10), new THREE.MeshStandardMaterial({ color:0x8b939e, roughness:0.8 }));
    ct.position.set(28, 11, 134); ct.castShadow = SET.shadows; W.add(ct);
    const cab = new THREE.Mesh(new THREE.CylinderGeometry(3.4,3.0,3.4,10), new THREE.MeshStandardMaterial({ color:0x2c3a50, emissive:0x18324a, emissiveIntensity:0.5 }));
    cab.position.set(28, 23.5, 134); W.add(cab);
    colliders.push({ minX:25, maxX:31, minZ:131, maxZ:137, h:25, walkable:false });
    // hangars
    for(const x of [-58, 60]){
      const hg = fitAndGround(models.ken_garage.scene.clone(true), { height:9, length:24 });
      hg.position.set(x, 0, 186); enableShadows(hg); W.add(hg); addColliderFromObject(hg);
    }
    // parked plane (same builder as cinematic plane, parked)
    makePlane(-70, 168, 0.6);
    streetlamp(-20, 150, Math.PI); streetlamp(24, 150, Math.PI); streetlamp(64, 152, Math.PI);
    carProp(-14, 140, 0.1); carProp(40, 142, -0.1);
  }

  /* ================= DOCKS / PORT ================= */
  {
    const quayMat = new THREE.MeshStandardMaterial({ color:0x6a6f76, roughness:0.9 });
    box(148, 1.2, 150, 6, 2.4, 62, quayMat, { walkable:true });  // west quay wall along x=148 for z>150
    box(184, 1.2, 122, 42, 2.4, 6, quayMat, { walkable:true });  // north quay wall for x>150
    // container yard
    const contMat2 = [0x8a3030,0x2f6e4f,0x3a5a8a,0xb0862e].map(c=>new THREE.MeshStandardMaterial({ color:c, roughness:0.85 }));
    for(let i=0;i<12;i++){
      const x = sr(158, 196), z = sr(112, 142);
      const stack = sri(1,3);
      for(let s=0;s<stack;s++) box(x, 1.3+s*2.6, z, 2.5, 2.6, 6.5, spick(contMat2), { walkable:true });
    }
    // cranes
    for(const [x,z] of [[168,155],[186,168]]){
      box(x, 7, z, 1.4, 14, 1.4, new THREE.MeshStandardMaterial({ color:0xc0392b, roughness:0.7 }), { walkable:false });
      const beam = new THREE.Mesh(new THREE.BoxGeometry(16, 1.2, 1.2), new THREE.MeshStandardMaterial({ color:0xc0392b }));
      beam.position.set(x - 6, 14, z); beam.castShadow = SET.shadows; W.add(beam);
    }
    // pier over water
    for(let i=0;i<8;i++) box(154 + i*3, 0.5, 168, 3, 0.3, 8, quayMat, { walkable:true, cull:false });
    // boats
    for(const [x,z,ry] of [[176,176,0.4],[192,182,-0.8],[186,158,1.9]]){
      const hull = new THREE.Mesh(new THREE.BoxGeometry(5, 1.2, 2.2), new THREE.MeshStandardMaterial({ color:spick([0x5a6a7a,0x7a5a4a,0x4a6a5a]), roughness:0.85 }));
      hull.position.set(x, -0.2, z); hull.rotation.y = ry; W.add(hull);
      const cab2 = new THREE.Mesh(new THREE.BoxGeometry(2, 1.4, 1.6), new THREE.MeshStandardMaterial({ color:0xd8dde2 }));
      cab2.position.set(x, 0.9, z); W.add(cab2);
    }
    streetlamp(158, 148, 0); streetlamp(178, 132, Math.PI/2);
    carProp(140, 132, 0.1, 'car_hatchback');
  }

  /* ================= RUINS ================= */
  {
    const dark = new THREE.Mesh(new THREE.PlaneGeometry(70, 70), new THREE.MeshBasicMaterial({ color:0x0c0d10, transparent:true, opacity:0.5 }));
    dark.rotation.x = -Math.PI/2; dark.position.set(-140, 0.015, -140); W.add(dark);
    const rubMat = new THREE.MeshStandardMaterial({ color:0x55504a, roughness:1 });
    const rubMat2 = new THREE.MeshStandardMaterial({ color:0x3a3733, roughness:1 });
    for(let i=0;i<40;i++){
      const x = sr(-172, -108), z = sr(-172, -108);
      box(x, sr(0.4,1.2), z, sr(1.2,4), sr(0.8,2.4), sr(1.2,4), spick([rubMat,rubMat2]), { walkable:true, ry:sr(0,Math.PI) });
    }
    // broken walls
    for(let i=0;i<12;i++){
      const x = sr(-170, -110), z = sr(-170, -110);
      box(x, sr(1,2), z, sr(4,9), sr(2,4), 0.6, rubMat2, { walkable:false, ry:sr(0,Math.PI) });
    }
    // burnt buildings
    for(const [x,z] of [[-160,-162],[-118,-160],[-160,-118]]){
      const t = spick(['ken_b','ken_c','ken_d']);
      const b = fitAndGround(models[t].scene.clone(true), { height:sr(6,9) });
      b.position.set(x, 0, z); b.rotation.y = sr(0, 3); enableShadows(b); W.add(b);
      b.traverse(o=>{ if(o.isMesh && o.material){ o.material = o.material.clone(); o.material.color = new THREE.Color(0x4a423c); } });
      addColliderFromObject(b); V5.cullables.push({ o:b, x, z });
    }
    // Samer's locker
    const locker = box(-140, 0.8, -140, 1.6, 1.6, 0.9, new THREE.MeshStandardMaterial({ color:0x3a5a7a, roughness:0.5, metalness:0.6 }), { walkable:true });
    const lk = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.3, 0.1), new THREE.MeshStandardMaterial({ color:0xffffff, emissive:0x4a8aff, emissiveIntensity:0.8 }));
    lk.position.set(-140, 1.1, -139.5); W.add(lk);
    V5.locker = locker;
    prop('watertower', { height:12 }, -124, -124, 0.8);
  }

  /* ================= ENEMY BASES ================= */
  {
    const baseMat = new THREE.MeshStandardMaterial({ color:0x3f434a, roughness:0.9 });
    const flagMat = new THREE.MeshStandardMaterial({ color:0xa3181f, emissive:0x5a0a0e, emissiveIntensity:0.6, side:THREE.DoubleSide });
    const buildBase = (cx, cz) => {
      // perimeter barriers
      for(let i=-1;i<=1;i++){
        box(cx + i*10, 0.6, cz - 14, 3.4, 1.2, 0.6, M.barrier, { walkable:false });
        box(cx + i*10, 0.6, cz + 14, 3.4, 1.2, 0.6, M.barrier, { walkable:false });
        box(cx - 14, 0.6, cz + i*10, 0.6, 1.2, 3.4, M.barrier, { walkable:false });
        box(cx + 14, 0.6, cz + i*10, 0.6, 1.2, 3.4, M.barrier, { walkable:false });
      }
      // watchtower (climbable crates to top)
      box(cx + 8, 2.1, cz + 8, 2.2, 4.2, 2.2, baseMat, { walkable:false });
      box(cx + 8, 0.55, cz + 5, 2.2, 1.1, 2.2, baseMat, { walkable:true });
      box(cx + 8, 1.65, cz + 6.6, 2.2, 1.1, 2.2, baseMat, { walkable:true });
      // crates + tents
      for(let i=0;i<6;i++) box(cx + sr(-10,10), 0.55, cz + sr(-10,10), 1.7, 1.1, 1.7, baseMat, { walkable:true, ry:sr(-0.4,0.4) });
      // banner
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 8, 8), M.gun);
      pole.position.set(cx, 4, cz - 10); W.add(pole);
      const flag = new THREE.Mesh(new THREE.PlaneGeometry(3, 1.8), flagMat);
      flag.position.set(cx + 1.6, 6.8, cz - 10); W.add(flag);
      streetlamp(cx - 10, cz, Math.PI/2); streetlamp(cx + 10, cz - 6, -Math.PI/2);
    };
    buildBase(92, -92); buildBase(-86, 96); buildBase(70, 120);
  }

  /* ================= scattered parked cars / lamps on avenues ================= */
  carProp(-96, 24, 1.57); carProp(96, -20, 1.57); carProp(0, 96, 0.05, 'car_taxi');
  carProp(-64, 96, -0.05); carProp(64, 96, 0.05);
  carProp(-186, -120, 0); carProp(186, 60, Math.PI); carProp(-60, -186, Math.PI/2); carProp(70, 186, -Math.PI/2);
  for(const [x,z] of [[-186,-60],[-186,120],[186,-120],[186,100],[-120,186],[130,186],[120,-186],[-130,-186]]){
    streetlamp(x, z, Math.atan2(-x, -z));
  }

  /* ================= BOMB SITE PADS (all campaign sites) ================= */
  const siteMat = new THREE.MeshStandardMaterial({ color:0x8a2020, roughness:0.9, emissive:0x400808, emissiveIntensity:0.5 });
  for(const m of CAMPAIGN){
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.6, 0.12, 20), siteMat);
    pad.position.set(m.site[0], 0.06, m.site[1]); W.add(pad);
  }

  /* ================= TRAFFIC ================= */
  initTraffic();
  /* ================= CIVILIANS ================= */
  initCivilians();
  /* ================= RAIN ================= */
  initRain();
}

/* -------------------------------------------------------------- */
/* AIRPLANE builder (used by airport prop + cinematics)            */
/* -------------------------------------------------------------- */
function makePlane(x, z, rotY){
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color:0xd7dde3, roughness:0.4, metalness:0.3 });
  const mat2 = new THREE.MeshStandardMaterial({ color:0xa3181f, roughness:0.5 });
  const fus = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.2, 12, 12), mat);
  fus.rotation.z = Math.PI/2; fus.position.y = 2.2; g.add(fus);
  const nose = new THREE.Mesh(new THREE.ConeGeometry(1.5, 2.4, 12), mat2);
  nose.rotation.z = -Math.PI/2; nose.position.set(7.2, 2.2, 0); g.add(nose);
  const wing = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.25, 17), mat);
  wing.position.set(0.5, 2.2, 0); g.add(wing);
  const tailV = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.0, 0.2), mat2);
  tailV.position.set(-5.6, 3.3, 0); g.add(tailV);
  const tailH = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.2, 5), mat);
  tailH.position.set(-5.6, 2.6, 0); g.add(tailH);
  const props = [];
  for(const dz of [-6.5, 6.5]){
    const eng = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 3.4, 8), mat);
    eng.rotation.z = Math.PI/2; eng.position.set(2.2, 2.2, dz); g.add(eng);
    const spin = new THREE.Mesh(new THREE.BoxGeometry(0.12, 3.2, 0.4), new THREE.MeshStandardMaterial({ color:0x22262c }));
    spin.position.set(4.0, 2.2, dz); g.add(spin); props.push(spin);
  }
  const gearL = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 1.6, 8), M.gun);
  gearL.position.set(1.4, 0.9, 1.8); g.add(gearL);
  const gearR = gearL.clone(); gearR.position.z = -1.8; g.add(gearR);
  g.traverse(o=>{ if(o.isMesh){ o.castShadow = SET.shadows; } });
  g.position.set(x, 0, z); g.rotation.y = rotY;
  worldRoot.add(g);
  colliders.push({ minX:x-3, maxX:x+3, minZ:z-6, maxZ:z+6, h:2.5, walkable:false });
  g.userData.props = props;
  V5.cullables.push({ o:g, x, z });
  return g;
}

/* -------------------------------------------------------------- */
/* TRAFFIC                                                          */
/* -------------------------------------------------------------- */
const RING_R = 186;
function ringPoint(s){ // s: 0..8 around square perimeter, returns {x,z,ry}
  const L = RING_R*2;
  s = ((s % 8) + 8) % 8;
  let t = s;
  if(t < 2) return { x:-RING_R + t/2*L, z:-RING_R, ry:0 };
  t -= 2;
  if(t < 2) return { x:RING_R, z:-RING_R + t/2*L, ry:-Math.PI/2 };
  t -= 2;
  if(t < 2) return { x:RING_R - t/2*L, z:RING_R, ry:Math.PI };
  t -= 2;
  return { x:-RING_R, z:RING_R - t/2*L, ry:Math.PI/2 };
}
function initTraffic(){
  const types = ['car_sedan','car_hatchback','car_taxi','car_stationwagon','car_police'];
  for(let i=0;i<9;i++){
    const t = spick(types);
    const m = fitAndGround(models[t].scene.clone(true), { length:4.6 });
    enableShadows(m); worldRoot.add(m);
    V5.traffic.push({ mesh:m, s: sr(0,8), dir: Math.random()<0.85 ? 1 : -1, speed: sr(9,14), lane: 0 });
    V5.cullables.push({ o:m, x:0, z:0, follow:true });
  }
}
function updateTraffic(dt){
  for(const c of V5.traffic){
    c.s += c.dir * (c.speed/ (RING_R*2)) * dt * 0.25;
    const p = ringPoint(c.s + (c.dir>0 ? 0 : 0));
    const ahead = ringPoint(c.s + c.dir*0.02);
    const off = 3.4;
    // lane offset perpendicular (right side of travel)
    let dx = ahead.x - p.x, dz = ahead.z - p.z;
    const dl = Math.hypot(dx, dz) || 1; dx/=dl; dz/=dl;
    const nx = -dz*off, nz = dx*off;
    c.mesh.position.set(p.x + nx, 0, p.z + nz);
    c.mesh.rotation.y = Math.atan2(dx, dz);
    for(const cu of V5.cullables){ if(cu.follow === c.mesh){ cu.x = c.mesh.position.x; cu.z = c.mesh.position.z; } }
    // hit player on foot
    if(!V5.driving && !player.dead && G.state === 'playing'){
      const d = c.mesh.position.distanceTo(player.pos);
      if(d < 2.2 && player.speedNow < 99){
        damagePlayer(12);
        const push = player.pos.clone().sub(c.mesh.position).setY(0).normalize().multiplyScalar(4);
        player.pos.add(push); player.moveVel.add(push.multiplyScalar(2));
        G.shake = Math.min(G.shake+0.5, 1);
      }
    }
  }
}

/* -------------------------------------------------------------- */
/* CIVILIANS                                                       */
/* -------------------------------------------------------------- */
const CIV_TINTS = [0xc9a37a, 0x8a9a5a, 0x7a8ac9, 0xc97a9a, 0xa97ac9, 0x7ac9b8];
function initCivilians(){
  const homes = [
    ['downtown',5],['market',4],['residential',4],['airport',1]
  ];
  for(const [dk, n] of homes){
    const d = DISTRICTS[dk];
    for(let i=0;i<n;i++){
      const bot = window.SkeletonUtils.clone(models.enemy.scene);
      bot.traverse(o=>{ if(o.isMesh && o.material && o.material.map){ o.material = o.material.clone(); o.material.color = new THREE.Color(spick(CIV_TINTS)); } });
      const wrap = new THREE.Group(); wrap.add(bot); wrap.scale.setScalar(0.95);
      wrap.position.set(d.cx + sr(-d.r*0.5, d.r*0.5), 0, d.cz + sr(-d.r*0.5, d.r*0.5));
      worldRoot.add(wrap);
      const mixer = new THREE.AnimationMixer(wrap);
      const actions = {}; for(const c of models.enemy.animations) actions[c.name] = mixer.clipAction(c);
      V5.civilians.push({ mesh:wrap, mixer, actions, current:'', home:{x:wrap.position.x, z:wrap.position.z},
        tgt:null, waitT: sr(0,4), state:'idle', panicT:0, rescue:false });
      V5.cullables.push({ o:wrap, x:wrap.position.x, z:wrap.position.z, followCiv:true });
    }
  }
}
function civAnim(c, name){
  if(!c.actions[name] || c.current === name) return;
  const a = c.actions[name]; a.reset().fadeIn(0.25).play();
  if(c.actions[c.current]) c.actions[c.current].fadeOut(0.25);
  c.current = name;
}
function updateCivilians(dt){
  const combat = G.state === 'playing' && (G.enemiesAlive > 0 || V5.questActive);
  for(const c of V5.civilians){
    c.mixer.update(dt);
    if(c.rescue){ updateRescueCiv(c, dt); continue; }
    if(combat){
      // flee from nearest enemy
      let near = null, nd = 30;
      for(const e of enemies){ if(e.dead) continue; const d = e.mesh.position.distanceTo(c.mesh.position); if(d < nd){ nd = d; near = e; } }
      if(near){
        const away = c.mesh.position.clone().sub(near.mesh.position).setY(0).normalize();
        const np = c.mesh.position.clone().addScaledVector(away, 4.4*dt);
        collide(np, 0.4);
        c.mesh.position.x = np.x; c.mesh.position.z = np.z;
        c.mesh.rotation.y = Math.atan2(away.x, away.z);
        civAnim(c, 'Running_A');
        continue;
      }
    }
    // wander
    if(!c.tgt){
      c.waitT -= dt;
      if(c.waitT <= 0){
        c.tgt = { x: c.home.x + sr(-24,24), z: c.home.z + sr(-24,24) };
        civAnim(c, 'Walking_A');
      } else civAnim(c, 'Idle');
    } else {
      const dx = c.tgt.x - c.mesh.position.x, dz = c.tgt.z - c.mesh.position.z;
      const d = Math.hypot(dx, dz);
      if(d < 0.6){ c.tgt = null; c.waitT = sr(2, 7); civAnim(c, 'Idle'); }
      else {
        const np = c.mesh.position.clone();
        np.x += dx/d * 1.5 * dt; np.z += dz/d * 1.5 * dt;
        collide(np, 0.4);
        c.mesh.position.x = np.x; c.mesh.position.z = np.z;
        c.mesh.rotation.y = Math.atan2(dx, dz);
      }
    }
  }
}
/* rescue quest civilians are managed by the quest engine */
function spawnRescueCivs(x, z, n){
  const out = [];
  for(let i=0;i<n;i++){
    const bot = window.SkeletonUtils.clone(models.enemy.scene);
    bot.traverse(o=>{ if(o.isMesh && o.material && o.material.map){ o.material = o.material.clone(); o.material.color = new THREE.Color(spick(CIV_TINTS)); } });
    const wrap = new THREE.Group(); wrap.add(bot); wrap.scale.setScalar(0.95);
    wrap.position.set(x + sr(-3,3), 0, z + sr(-3,3));
    worldRoot.add(wrap);
    const mixer = new THREE.AnimationMixer(wrap);
    const actions = {}; for(const c of models.enemy.animations) actions[c.name] = mixer.clipAction(c);
    const civ = { mesh:wrap, mixer, actions, current:'', state:'caged', home:{x,z}, tgt:null, waitT:0, panicT:0, rescue:true };
    V5.civilians.push(civ);
    out.push(civ);
  }
  return out;
}
function updateRescueCiv(c, dt){
  c.mixer.update(dt);
  if(c.state === 'caged'){ civAnim(c, 'Idle'); return; }
  if(c.state === 'flee'){
    // run to plaza safe zone
    const tgt = new THREE.Vector3(0, 0, -26);
    const dx = tgt.x - c.mesh.position.x, dz = tgt.z - c.mesh.position.z;
    const d = Math.hypot(dx, dz);
    if(d < 4){ c.state = 'safe'; civAnim(c, 'Idle'); return; }
    const np = c.mesh.position.clone();
    np.x += dx/d * 4.2*dt; np.z += dz/d * 4.2*dt;
    collide(np, 0.4);
    c.mesh.position.x = np.x; c.mesh.position.z = np.z;
    c.mesh.rotation.y = Math.atan2(dx, dz);
    civAnim(c, 'Running_A');
  }
}

/* -------------------------------------------------------------- */
/* RAIN                                                            */
/* -------------------------------------------------------------- */
function initRain(){
  const N = quality().rain;
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(N * 6);
  for(let i=0;i<N;i++){
    const x = sr(-30,30), y = sr(0,25), z = sr(-30,30);
    pos[i*6] = x; pos[i*6+1] = y; pos[i*6+2] = z;
    pos[i*6+3] = x + 0.1; pos[i*6+4] = y - 1.1; pos[i*6+5] = z;
  }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.LineBasicMaterial({ color:0x9fb4cc, transparent:true, opacity:0.5 });
  const rain = new THREE.LineSegments(geo, mat);
  rain.visible = false; rain.frustumCulled = false;
  scene.add(rain);
  V5.rain = rain; V5.rainGeo = geo;
}
function updateRain(dt){
  if(!V5.rain) return;
  V5.rain.visible = V5.weather >= 2;
  if(!V5.rain.visible) return;
  V5.rain.position.set(camera.position.x, camera.position.y - 10, camera.position.z);
  const p = V5.rainGeo.attributes.position.array;
  const fall = 34 * dt;
  for(let i=0;i<p.length;i+=6){
    p[i+1] -= fall; p[i+4] -= fall;
    if(p[i+1] < -10){
      const y = sr(14, 25);
      p[i+1] = y; p[i+4] = y - 1.1;
      const x = camera.position.x + sr(-30,30), z = camera.position.z + sr(-30,30);
      p[i] = x; p[i+3] = x + 0.1; p[i+2] = z; p[i+5] = z;
    }
  }
  V5.rainGeo.attributes.position.needsUpdate = true;
}

/* -------------------------------------------------------------- */
/* ENVIRONMENT — day/night, weather, war mix                       */
/* -------------------------------------------------------------- */
const ENV = {
  dayHemi:   { c:new THREE.Color(0xbfd7f2), g:new THREE.Color(0x8b8474) },
  nightHemi:{ c:new THREE.Color(0x5b78ab), g:new THREE.Color(0x38404c) },
  daySun:   { c:new THREE.Color(0xfff0d8) },
  duskSun:   { c:new THREE.Color(0xff8a4a) },
  nightSun:  { c:new THREE.Color(0xa9c2ea) },
  dayFog:    new THREE.Color(0xc4d3e2),  nightFog:    new THREE.Color(0x243450),
  daySkyT:   new THREE.Color(0x5b93d6), daySkyB: new THREE.Color(0xd6e3ee),  nightSkyT:   new THREE.Color(0x131e33), nightSkyB: new THREE.Color(0x28395c),
  tmp1: new THREE.Color(), tmp2: new THREE.Color(), tmp3: new THREE.Color()
};
function envUpdate(dt){
  // day-night
  V5.tod = (V5.tod + dt / V5.todLen) % 1;
  const el = -Math.cos(V5.tod * Math.PI * 2);           // -1 midnight .. 1 noon
  const daylight = clamp(el * 1.6 + 0.32, 0, 1);
  const duskK = clamp(1 - Math.abs(el) * 2.4, 0, 1);    // near horizon
  // war mix tween
  V5.warMix += clamp(V5.warTarget - V5.warMix, -dt/3.2, dt/3.2);

  // weather machine
  V5.weatherT -= dt;
  if(V5.weatherT <= 0){
    V5.weatherT = sr(70, 140);
    const r = Math.random();
    V5.weather = r < 0.42 ? 0 : r < 0.68 ? 1 : r < 0.9 ? 2 : 3;
    if(V5.weather === 3) V5.lightningT = sr(2, 6);
  }
  const cloudK = V5.weather === 0 ? 0 : V5.weather === 1 ? 0.5 : 0.8;

  // compose
  const w = V5.warMix;
  const dl = daylight * (1 - cloudK*0.55) * (1 - w*0.55);
  hemi.color.copy(ENV.dayHemi.c).lerp(ENV.nightHemi.c, 1 - clamp(daylight*1.4,0,1));
  hemi.groundColor.copy(ENV.dayHemi.g).lerp(ENV.nightHemi.g, 1 - clamp(daylight*1.4,0,1));
  hemi.intensity = lerp(2.6, 2.8, dl) * (1 - w*0.45) + w*1.5;
  sun.color.copy(ENV.daySun.c).lerp(ENV.duskSun.c, duskK).lerp(ENV.nightSun.c, 1 - clamp(daylight*2,0,1));
  if(w > 0.01){ sun.color.lerp(new THREE.Color(0xff8a4a), w); }
  sun.intensity = lerp(1.45, 3.8, Math.max(dl, 0.02)) * (1 - w*0.5) + w*1.8;
  const az = V5.tod * Math.PI * 2;
  sun.position.set(Math.cos(az) * 90, Math.max(40, el * 110), Math.sin(az) * 60);
  if(w > 0.01){ sun.position.set(-60, 18, 40); }

  // night exposure compensation: keep the night playable without washing out the day
  if(typeof renderer !== 'undefined' && renderer.toneMappingExposure !== null){
    renderer.toneMappingExposure = 1.18 + (1 - clamp(dl, 0, 1)) * 0.55;
  }

  // lightning
  if(V5.weather === 3){
    V5.lightningT -= dt;
    if(V5.lightningT <= 0){
      V5.lightningT = sr(4, 11); V5.flashI = 1;
      setTimeout(()=>{ if(SET.sound) S.boom(); }, sr(300, 900));
    }
    if(V5.flashI > 0){
      V5.flashI = Math.max(0, V5.flashI - dt*4);
      hemi.intensity += V5.flashI * 5;
    }
  }

  // fog + sky
  const q = quality();
  const fogDay = ENV.dayFog.clone().lerp(new THREE.Color(0x8a919c), cloudK*0.6);
  const fogNight = ENV.nightFog;
  const fogC = fogDay.lerp(fogNight, 1 - clamp(daylight*1.35,0,1));
  if(w > 0.01) fogC.lerp(new THREE.Color(0x3a2620), w);
  scene.fog.color.copy(fogC);
  scene.fog.near = lerp(34, 55, dl) + (V5.weather>=2 ? 14 : 0) + w*-8;
  scene.fog.far = lerp(185, q.fogF, dl) * (V5.weather>=2 ? 0.62 : 1) * (1 - w*0.3);

  skyMat.uniforms.topC.value.copy(ENV.daySkyT).lerp(ENV.nightSkyT, 1 - clamp(daylight*1.3,0,1));
  skyMat.uniforms.botC.value.copy(ENV.daySkyB).lerp(ENV.nightSkyB, 1 - clamp(daylight*1.3,0,1));
  if(V5.flashI > 0){ skyMat.uniforms.topC.value.lerp(new THREE.Color(0xcdd8ff), V5.flashI*0.8); }

  // lamps at night
  const lampOn = dl < 0.5;
  V5.lampHeadMat.emissiveIntensity = lampOn ? 3.4 : 0;
  if(V5.hospitalCross) V5.hospitalCross.material.emissiveIntensity = lampOn ? 3.0 : 1.2;

  // city life sounds
  if(SET.sound && G.state === 'playing'){
    V5.sirenT -= dt;
    if(V5.sirenT <= 0){ V5.sirenT = sr(22, 46); sirenDistant(); }
    V5.hornT -= dt;
    if(V5.hornT <= 0){ V5.hornT = sr(9, 25); hornDistant(); }
  }
}
function sirenDistant(){
  try{
    sfx(c=>{
      const t = c.currentTime;
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(660, t);
      o.frequency.linearRampToValueAtTime(880, t+0.5);
      o.frequency.linearRampToValueAtTime(660, t+1.0);
      o.frequency.linearRampToValueAtTime(880, t+1.5);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.03, t+0.2);
      g.gain.linearRampToValueAtTime(0.0001, t+1.8);
      o.connect(g); g.connect(master); o.start(t); o.stop(t+1.9);
    });
  }catch(e){}
}
function hornDistant(){
  try{
    sfx(c=>{
      const t = c.currentTime;
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'square'; o.frequency.value = sr(300, 420);
      g.gain.setValueAtTime(0.015, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      o.connect(g); g.connect(master); o.start(t); o.stop(t+0.4);
    });
  }catch(e){}
}

/* -------------------------------------------------------------- */
/* DISTANCE CULLING (perf for mid-range phones)                    */
/* -------------------------------------------------------------- */
function updateCulling(dt){
  V5.cullT -= dt;
  if(V5.cullT > 0) return;
  V5.cullT = 0.3;
  const q = quality();
  const px = player.pos.x, pz = player.pos.z;
  for(const c of V5.cullables){
    if(c.follow || c.followCiv) continue;
    const dx = c.x - px, dz = c.z - pz;
    c.o.visible = (dx*dx + dz*dz) < q.cull * q.cull;
  }
}

/* -------------------------------------------------------------- */
/* AUTO QUALITY GUARD                                              */
/* -------------------------------------------------------------- */
function updateAutoQuality(dt){
  V5.fpsAcc += dt; V5.fpsN++;
  if(V5.fpsAcc >= 1){
    V5.fps = V5.fpsN / V5.fpsAcc;
    V5.fpsAcc = 0; V5.fpsN = 0;
    if(V5.fps < 24){ V5.fpsLowT++; } else V5.fpsLowT = 0;
    if(V5.fpsLowT >= 5 && !V5.autoQualityDone){
      V5.autoQualityDone = true;
      if(SET.quality !== 'low'){
        SET.quality = 'low';
        localStorage.setItem('ts5_quality', 'low');
        applyQuality();
        banner('PERFORMANCE MODE', 'تم تفعيل وضع الأداء تلقائياً');
      }
    }
  }
}
function applyQuality(){
  const q = quality();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q.pr));
  renderer.shadowMap.enabled = SET.shadows && q.shadow > 0;
  if(q.shadow > 0){ sun.shadow.mapSize.set(q.shadow, q.shadow); if(sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map = null; } }
  sun.castShadow = SET.shadows && q.shadow > 0;
  scene.traverse(o=>{ if(o.isMesh && o.material){ /* keep */ } });
}

/* init on load (called by boot after buildWorld) */
function v5WorldInit(){
  applyQuality();
  // night ambience toggles handled per-frame
}
