/* =====================================================================
   TIME STRIKE 5 — GLUE (kill XP, UI wiring, settings, continue)
   ===================================================================== */
"use strict";

function v5KillXP(e){
  const T = ETYPES[e.type];
  addXP(T.boss ? 600 : 22 + Math.floor(T.score / 9));
}
function bannerMini(t){ hint(t, 1700); }

/* ---------------- language ---------------- */
function applyLang(){
  const ar = SET.lang === 'ar', both = SET.lang === 'both';
  const BTNS = {
    btnFire:    ['إطلاق', 'FIRE', 'إطلاق'],
    btnJump:    ['قفز', 'JUMP', 'قفز'],
    btnReload:  ['تعبئة', 'RLD', 'تعبئة'],
    btnNade:    ['💣', '💣', 'رمي'],
    btnDefuse:  ['نزع', 'DEFUSE', 'نزع الفتيل'],
    btnCam:     ['📷', 'CAM', 'الكاميرا'],
    btnSprint:  ['جري', 'SPRINT', 'جري'],
    btnCrouch:  ['انخفاض', 'CRCH', 'انخفاض'],
    btnAct:     ['فعل', 'ACT', 'فعل/ركوب']
  };
  for(const id in BTNS){
    const b = $(id); if(!b) continue;
    const [arTxt, enTxt, subTxt] = BTNS[id];
    if(ar)        b.innerHTML = arTxt;
    else if(both) b.innerHTML = enTxt + '<small>' + subTxt + '</small>';
    else          b.innerHTML = enTxt;
  }
  // static HUD labels (game overwrites them each frame, this covers the pre-game state)
  if($('hptext'))  $('hptext').textContent = ar ? 'الصحة 100' : 'HP 100';
  if($('wave'))    $('wave').textContent = ar ? 'المهمة 1' : 'MISSION 1';
  if($('enemies')) $('enemies').textContent = ar ? 'الأعداء: 0' : 'Enemies: 0';
  if($('nades'))   $('nades').textContent = ar ? 'قنابل: 3' : 'GRENADES: 3';
  if($('lvltext')) $('lvltext').textContent = ar ? 'المستوى 1' : 'LV 1';
  if($('defusetext')) $('defusetext').textContent = ar ? 'جاري نزع الفتيل...' : 'DEFUSING...';
  const cont = $('btnContinue');
  if(cont && cont.style.display !== 'none' && cont.dataset.wave){
    const w = cont.dataset.wave;
    cont.innerHTML = ar
      ? 'استكمال — المهمة ' + w
      : 'CONTINUE — MISSION ' + w + (both ? '<small>استكمال — المهمة ' + w + '</small>' : '');
  }
  if(ar){
    const a = $('btnSqAccept'), d = $('btnSqDecline');
    if(a) a.innerHTML = 'قبول';
    if(d) d.innerHTML = 'رفض';
  } else if(!both){
    const a = $('btnSqAccept'), d = $('btnSqDecline');
    if(a) a.innerHTML = 'ACCEPT';
    if(d) d.innerHTML = 'DECLINE';
  }
}

/* ---------------- UI wiring ---------------- */
function v5BindUI(){
  $('choiceA').addEventListener('click', ()=>{ if(V5.choiceCb) V5.choiceCb(true); });
  $('choiceB').addEventListener('click', ()=>{ if(V5.choiceCb) V5.choiceCb(false); });
  $('btnSqAccept').addEventListener('click', ()=>{
    const q = SIDE_QUESTS.find(x=>x.id === V5.questOffered);
    hide('sqoffer');
    if(q) acceptQuest(q);
  });
  $('btnSqDecline').addEventListener('click', ()=> declineQuest());
  $('btnQuestsBack').addEventListener('click', ()=>{ hide('quests'); G.state = 'playing'; });

  // settings: quality + voice
  const sq = $('setQuality');
  if(sq){
    sq.value = SET.quality;
    sq.addEventListener('change', e=>{
      SET.quality = e.target.value;
      localStorage.setItem('ts5_quality', SET.quality);
      applyQuality();
      S.click();
    });
  }
  const sv = $('setVoice');
  if(sv){
    sv.checked = SET.voice;
    sv.addEventListener('change', e=>{
      SET.voice = e.target.checked;
      localStorage.setItem('ts5_voice', SET.voice ? '1' : '0');
      if(!SET.voice) TTS.stop();
    });
  }
  const sl = $('setLang');
  if(sl){
    sl.value = SET.lang;
    sl.addEventListener('change', e=>{
      SET.lang = e.target.value;
      localStorage.setItem('ts5_lang', SET.lang);
      applyLang();
      S.click();
    });
  }
  applyLang();

  // continue button
  const sv2 = loadProgress();
  if(sv2 && sv2.wave > 1 && sv2.wave <= 15){
    const btn = $('btnContinue');
    btn.style.display = 'block';
    btn.dataset.wave = sv2.wave;
    btn.innerHTML = 'CONTINUE — MISSION ' + sv2.wave + '<small>استكمال — المهمة ' + sv2.wave + '</small>';
    if(SET.lang === 'ar') btn.innerHTML = 'استكمال — المهمة ' + sv2.wave;
    else if(SET.lang === 'en') btn.innerHTML = 'CONTINUE — MISSION ' + sv2.wave;
    btn.addEventListener('click', ()=> continueCampaign(sv2));
  }
}

function continueCampaign(save){
  hide('menu'); hide('over'); hide('victory'); hide('pause');
  resetWorld();
  G.score = 0; G.endless = false;
  V5.xp = save.xp || 0; V5.level = save.level || 1;
  V5.rep = save.rep || 0;
  V5.questsDone = {};
  for(const id of (save.quests || [])) V5.questsDone[id] = true;
  V5.civiliansSaved = save.saved || 0;
  V5.curCh = (missionByWave(save.wave).ch || 1) - 1;
  G.wave = save.wave - 1;
  G.nextWaveT = 0.01;
  V5.mission = null;
  G.mode = 'game';
  $('hud').style.display = 'block';
  if(IS_TOUCH) $('touchui').style.display = 'block';
  ac(); startAmbient();
  G.state = 'playing';
  requestView();
  banner('CAMPAIGN CONTINUED', 'استكمال الحملة — المهمة ' + save.wave);
}
