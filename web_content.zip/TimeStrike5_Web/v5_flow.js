/* =====================================================================
   TIME STRIKE 5 — CAMPAIGN / QUESTS / REPUTATION / VOICE / UI
   ===================================================================== */
"use strict";

/* ================================================================ */
/* TTS NARRATOR — Arabic-first narration (system TTS, ar voice with
   English fallback). Reads story, radio and dialogue aloud.        */
/* ================================================================ */
const TTS = {
  voice: null, voiceAr: null, ready: false,
  init(){
    try{
      if(!('speechSynthesis' in window)) return;
      const pick = () => {
        const vs = speechSynthesis.getVoices();
        if(!vs.length) return;
        // Arabic narrator voice (prefer Saudi/Google/male)
        this.voiceAr = vs.find(v=>/^ar[-_]SA/i.test(v.lang) && !/female/i.test(v.name))
                    || vs.find(v=>/^ar[-_]SA/i.test(v.lang))
                    || vs.find(v=>/google arabic/i.test(v.name))
                    || vs.find(v=>/^ar/i.test(v.lang)) || null;
        // English fallback
        this.voice = vs.find(v=>/en[-_]US/i.test(v.lang) && /male|david|mark|daniel|alex|fred/i.test(v.name))
                  || vs.find(v=>/en[-_]US/i.test(v.lang) && /google/i.test(v.name))
                  || vs.find(v=>/^en/i.test(v.lang)) || vs[0];
        this.ready = true;
      };
      pick();
      speechSynthesis.onvoiceschanged = pick;
    }catch(e){}
  },
  say(en, ar, cb){
    if(typeof ar === 'function'){ cb = ar; ar = null; }
    if(!SET.voice){ if(cb) cb(); return; }
    try{
      if(!('speechSynthesis' in window)){ if(cb) cb(); return; }
      // choose text: Arabic when language is ar/both and an Arabic voice exists,
      // otherwise fall back to the English line
      const wantAr = SET.lang !== 'en' && ar;
      const text = (wantAr && this.voiceAr) ? ar : (en || ar || '');
      if(!text){ if(cb) cb(); return; }
      const isArabic = /[؀-ۿ]/.test(text);
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      if(isArabic && this.voiceAr) u.voice = this.voiceAr;
      else if(!isArabic && this.voice) u.voice = this.voice;
      u.lang = isArabic ? 'ar-SA' : 'en-US';
      u.rate = isArabic ? 0.95 : 0.98; u.pitch = 0.92; u.volume = 1;
      let done = false;
      const fin = ()=>{ if(!done){ done = true; if(cb) cb(); } };
      u.onend = fin; u.onerror = fin;
      setTimeout(fin, Math.min(16000, text.length * 78 + 2200)); // safety
      speechSynthesis.speak(u);
    }catch(e){ if(cb) cb(); }
  },
  stop(){ try{ if('speechSynthesis' in window) speechSynthesis.cancel(); }catch(e){} }
};
TTS.init();

/* ================================================================ */
/* XP / LEVEL / REPUTATION                                          */
/* ================================================================ */
function addXP(n){
  V5.xp += n;
  while(V5.xp >= XP_NEED(V5.level)){
    V5.xp -= XP_NEED(V5.level);
    V5.level++;
    player.maxHp += 10; player.hp = player.maxHp;
    player.mag = Math.min(45, player.mag + 4);
    MV.maxStamina += 8; MV.stamina = MV.maxStamina;
    banner(isAr() ? 'ارتقاء! المستوى ' + V5.level : 'LEVEL UP! ' + V5.level,
           isAr() ? '+10 صحة · +4 ذخيرة · لياقة أعلى' : '+10 HP · +4 ammo · +stamina');
    S.victory();
    burst(player.pos.clone().add(new THREE.Vector3(0,1.5,0)), 0x2ed573, 18, 5, 0.09);
  }
  saveProgress();
}
function repTier(){ return V5.rep >= 8 ? 'hero' : V5.rep <= -4 ? 'ghost' : 'neutral'; }
function repTitle(){
  const t = repTier();
  if(SET.lang === 'en')
    return t === 'hero' ? 'HERO OF NOUR' : t === 'ghost' ? 'THE GHOST' : 'CITY SOLDIER';
  return t === 'hero' ? 'بطل النور' : t === 'ghost' ? 'الشبح الغامض' : 'جندي المدينة';
}
function saveProgress(){
  try{
    localStorage.setItem('ts5_save', JSON.stringify({
      wave: G.wave, xp: V5.xp, level: V5.level, rep: V5.rep,
      quests: Object.keys(V5.questsDone), saved: V5.civiliansSaved, best: G.best
    }));
  }catch(e){}
}
function loadProgress(){
  try{ return JSON.parse(localStorage.getItem('ts5_save') || 'null'); }catch(e){ return null; }
}

/* ================================================================ */
/* MISSION FLOW                                                     */
/* ================================================================ */
function waveCompFor(m){
  const n = m.wave;
  const c = [];
  const count = clamp(4 + Math.floor(n * 1.15), 4, 20);
  for(let i=0;i<count;i++){
    let t = 'soldier';
    if(n >= 2 && Math.random() < 0.28) t = 'runner';
    if(n >= 4 && Math.random() < 0.22) t = 'heavy';
    if(n >= 5 && Math.random() < 0.16) t = 'bomber';
    if(n >= 7 && Math.random() < 0.14) t = 'sniper';
    c.push(t);
  }
  return c;
}
function missionByWave(w){
  return CAMPAIGN.find(x=>x.wave === w) ||
    { wave:w, ch:5, district:spick(Object.keys(DISTRICTS)), site:[rand(-160,160), rand(-160,160)],
      mission:{ ar:'المهمة ' + w, en:'Mission ' + w }, endless:true };
}
function beginNextMission(){
  const w = G.wave + 1;
  const m = missionByWave(w);
  if(!m.endless && m.ch !== (V5.curCh || 1)){
    V5.curCh = m.ch;
    const intro = CHAPTER_INTROS[m.ch] || [];
    showStory(intro.length ? intro : [{en:'CHAPTER ' + m.ch, ar:'الفصل ' + m.ch}], 'CHAPTER ' + m.ch + ' — ' + m.mission.en, ()=>{
      if(PLANE_SCENES[m.ch]) startPlaneScene(m.ch, ()=> startMission(m));
      else startMission(m);
    });
    return;
  }
  startMission(m);
}
function startMission(m, retry){
  G.state = 'playing';
  V5.mission = m;
  G.wave = m.wave;
  V5.missionState = 'spawning';
  G.comp = waveCompFor(m);
  G.toSpawn = G.comp.length;
  G.spawnT = 0.6;
  V5.squadId = (V5.squadId || 0) + 1;
  V5.boss = null;
  player.nades = clamp(2 + Math.floor(V5.level / 2), 2, 6);
  if(!retry){
    const r = m.radio || [];
    V5.radioQ = r.map(x=>({...x}));
    banner('MISSION ' + m.wave + ' — ' + m.mission.en, 'المهمة ' + m.wave + ' — ' + m.mission.ar + (m.boss ? ' · ⚠ زعيم' : ''));
    // district beacon
    hint(isAr() ? 'اتبع المنارة الحمراء وعلامة الخريطة' : 'Follow the red beacon & minimap marker', 4200);
    // offer side quests
    const pool = (SIDE_QUEST_WAVES[m.wave] || []).filter(id=>!V5.questsDone[id] && !V5.questActive && V5.questOffered !== id);
    if(pool.length){ V5.questOffered = pool[0]; offerQuest(SIDE_QUESTS.find(q=>q.id === pool[0])); }
  } else {
    V5.radioQ = [];
    banner('RETRY — ' + m.mission.en, 'إعادة المحاولة — المهمة ' + m.wave + ' — ' + m.mission.ar);
  }
  spawnBomb(false);
  S.wave();
}
function updateCampaign(dt){
  if(G.endless || V5.mission || G.nextWaveT > 0){
    if(G.nextWaveT > 0){
      G.nextWaveT -= dt;
      if(G.nextWaveT <= 0) beginNextMission();
      return;
    }
    if(V5.missionState === 'spawning' || V5.missionState === 'active'){
      V5.missionState = 'active';
      if(G.toSpawn > 0){
        G.spawnT -= dt;
        if(G.spawnT <= 0){
          const t = G.comp[G.comp.length - G.toSpawn];
          const e = spawnEnemy(t);
          e.alert = false;
          G.toSpawn--;
          G.spawnT = rand(0.8, 1.9);
        }
      }
      // boss joins when the rest are nearly done
      const m = V5.mission;
      if(m && m.boss && !V5.boss && G.toSpawn <= 1){
        const b = spawnEnemy(m.boss, [m.site[0] + 8, m.site[1] + 8]);
        b.alert = true;
        banner('⚠ BOSS — ' + ETYPES[m.boss].name, 'زعيم! استعد للمعركة');
        if(isAr()) banner('⚠ زعيم — ' + ETYPES[m.boss].arName, 'استعد للمعركة!');
        S.wave();
        G.shake = 0.7;
      }
      // mission complete?
      if(G.toSpawn === 0 && G.enemiesAlive === 0 && bomb.active && bomb.defused){
        missionComplete();
      }
    }
  }
}
function missionComplete(){
  const m = V5.mission;
  if(!m) return;
  V5.missionState = 'done';
  V5.mission = null;
  G.score += 500;
  addXP(180);
  if(m.wave >= 15 && !G.endless){ victory(); return; }
  // hospital choice (wave 5)
  const fin = ()=>{
    G.nextWaveT = m.wave === 3 ? 6 : 3.2; // breather after chapter-ends handled by story
    saveProgress();
  };
  if(m.afterStory && m.afterStory.length){
    showStory(m.afterStory, 'INTERLUDE — ' + m.mission.en, ()=>{ G.state = 'playing'; fin(); });
  } else fin();
}
function retryMission(){
  hide('over'); hide('victory');
  $('hud').style.display = 'block';
  if(IS_TOUCH) $('touchui').style.display = 'block';
  G.state = 'playing';
  // cleanup
  for(const e of enemies) scene.remove(e.mesh);
  enemies.length = 0; G.enemiesAlive = 0; G.toSpawn = 0;
  if(bomb.mesh) bomb.mesh.visible = false;
  bomb.active = false;
  V5.boss = null;
  clearQuest(false);
  player.hp = player.maxHp; player.ammo = player.mag; player.nades = 3;
  player.dead = false; player.deathT = 0;
  const m = missionByWave(Math.max(1, G.wave));
  startMission(m, true);
}

/* hospital choice (wave 5 arrival) */
function maybeOfferChoice(){
  const m = V5.mission;
  if(!m || !m.choice || V5.choiceShown) return;
  if(player.pos.distanceTo(new THREE.Vector3(m.site[0], 0, m.site[1])) < 55){
    V5.choiceShown = true;
    offerChoice(m.choice, (a)=>{
      if(a){
        V5.rep += 2;
        player.hp = player.maxHp;
        banner('THE CITY REMEMBERS — المدينة تتذكر', '+2 Reputation · السمعة ترتفع');
        radio('حداد: «المدينة ستتذكر من أوقفت نيرانها قبل انفجارها. أنقذت أرواحاً يا رعد.»<br><span style="color:#7d8ea6;font-size:.8em">Haddad: "The city will remember who silenced the guns before the blast. You saved lives, Raad."</span>');
      } else {
        G.score += 600;
        banner('COLD EFFICIENCY — كفاءة باردة', '+600 Score · لكن المدينة تراقب');
        radio('حداد: «القنبلة أولاً… منطقي. لكن الممرضات لن ينسوا أننا تأخرنا.»<br><span style="color:#7d8ea6;font-size:.8em">Haddad: "Bomb first... logical. But the nurses won\'t forget we were late."</span>');
      }
    });
  }
}
function offerChoice(c, cb){
  G.state = 'choice';
  $('choicetext').innerHTML = isAr() ? c.text.ar : c.text.ar + '<br><span style="color:#8fa2bd;font-size:.85em">' + c.text.en + '</span>';
  $('choiceA').innerHTML = isAr() ? c.a.ar : c.a.ar + '<br><span style="color:#c8d4e6;font-size:.75em;font-weight:400">' + c.a.en + '</span>';
  $('choiceB').innerHTML = isAr() ? c.b.ar : c.b.ar + '<br><span style="color:#c8d4e6;font-size:.75em;font-weight:400">' + c.b.en + '</span>';
  show('choice');
  V5.choiceCb = (a)=>{
    hide('choice');
    G.state = 'playing';
    if(cb) cb(a);
    TTS.say(a ? c.a.en : c.b.en, a ? c.a.ar : c.b.ar);
  };
}

/* ================================================================ */
/* RADIO QUEUE (with TTS)                                           */
/* ================================================================ */
function updateRadio(dt){
  const q = V5.radioQ;
  if(!q.length) return;
  const head = q[0];
  if(head._t === undefined) head._t = 0;
  head._t += dt;
  if(head._t >= (head.t || 0) && !head._said){
    head._said = true;
    radio('<b>' + head.ar + '</b><br><span style="color:#7d8ea6;font-size:.8em">' + head.en + '</span>');
    TTS.say(head.en, head.ar);
    q.shift();
  }
}

/* ================================================================ */
/* QUEST ENGINE                                                     */
/* ================================================================ */
function offerQuest(q){
  if(!q) return;
  $('sqtitle').innerHTML = (isAr() ? 'مهمة جانبية — ' : 'SIDE QUEST — ') + q.title.ar +
    (isAr() ? '' : '<br><span style="color:#8fa2bd;font-size:.8em">' + q.title.en + '</span>');
  $('sqdesc').innerHTML = q.desc.ar + (isAr() ? '' : '<br><span style="color:#8fa2bd;font-size:.8em">' + q.desc.en + '</span>') +
    '<br><span style="color:#ffd166;font-size:.8em">REWARD: +' + q.reward.xp + ' XP' + (q.reward.rep ? ' · +' + q.reward.rep + ' REP' : '') + (q.reward.score ? ' · +' + q.reward.score + ' PTS' : '') + '</span>';
  show('sqoffer');
  S.beep();
  clearTimeout(V5.sqTimeout);
  V5.sqTimeout = setTimeout(()=>{ if($('sqoffer').classList.contains('hidden') === false){ hide('sqoffer'); } }, 22000);
}
function acceptQuest(q){
  hide('sqoffer');
  if(V5.questActive){ declineQuest(); }
  const a = { ...q, t:0, progress:0, items:[], civs:null, guards:[], started:false };
  V5.questActive = a;
  G.comp = G.comp; // noop
  switch(q.type){
    case 'rescue':{
      a.civs = spawnRescueCivs(q.pos[0], q.pos[1], q.count);
      a.guards = [];
      for(let i=0;i<q.guards;i++){
        const g = spawnEnemy(i === 0 ? 'heavy' : 'soldier', [q.pos[0] + Math.cos(i*2)*10, q.pos[1] + Math.sin(i*2)*10]);
        g.questGuard = a; a.guards.push(g);
      }
      break; }
    case 'deliver':{
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.6,0.5,0.6), M.medkit);
      m.position.set(q.pos[0], 0.3, q.pos[1]); scene.add(m);
      a.items.push(m); a.tgtPos = [-140, 30];
      break; }
    case 'race':{
      a.checkpoints = [
        [0,-70],[80,-90],[150,20],[80,120],[0,170],[-90,150],[-160,40],[-80,-60]
      ].map(p=>new THREE.Vector3(p[0], 0, p[1]));
      a.cpIdx = 0; a.timeLeft = q.time;
      break; }
    case 'target':{
      const t = spawnEnemy('heavy', q.pos);
      t.hp = t.maxHp = 420; t.targetMark = true;
      t.mesh.traverse(o=>{ if(o.isMesh && o.material && o.material.map){ o.material = o.material.clone(); o.material.color = new THREE.Color(0xffd700); } });
      a.target = t;
      break; }
    case 'collect':{
      const spots = [[30,-40],[-50,-120],[130,30],[-160,-30],[10,110]];
      for(const s of spots){
        const m = new THREE.Mesh(new THREE.BoxGeometry(0.55,0.4,0.4), new THREE.MeshStandardMaterial({ color:0x1c2c4e, emissive:0x4a8aff, emissiveIntensity:0.8 }));
        m.position.set(s[0] + rand(-6,6), 0.25, s[1] + rand(-6,6)); scene.add(m);
        a.items.push(m);
      }
      break; }
    case 'defend':{
      a.timeLeft = q.time; a.defSpawnT = 0;
      break; }
    case 'escort':{
      const car = fitAndGround(models.car_police.scene.clone(true), { length:4.6 });
      car.position.set(q.pos[0], 0, q.pos[1]); worldRoot.add(car);
      a.escortCar = car; a.escortHp = 320; a.route = [[-38,-70],[-20,-20],[-10,60],[0,120],[10,150]]; a.leg = 0;
      a.ambushes = [0, 2]; a.ambushed = [];
      break; }
    case 'clearbase':{
      a.basePos = q.pos;
      for(let i=0;i<8;i++){
        const g = spawnEnemy(i%3===0 ? 'heavy' : i%3===1 ? 'soldier' : 'runner', [q.pos[0] + Math.cos(i*0.8)*11, q.pos[1] + Math.sin(i*0.8)*11]);
        g.questGuard = a;
      }
      break; }
    case 'chase':{
      const car = fitAndGround(models.car_hatchback.scene.clone(true), { length:4.6 });
      car.position.set(q.pos[0], 0, q.pos[1]); worldRoot.add(car);
      a.chaseCar = car; a.chaseS = 0.5; a.chaseHp = 260; a.timeLeft = q.time;
      break; }
    case 'snipers':{
      const roofs = [[24,-52],[-40,-34],[52,-10]];
      for(let i=0;i<q.count;i++){
        const s = spawnEnemy('sniper', [roofs[i][0], roofs[i][1]]);
        s.questSniper = true;
      }
      break; }
    case 'caches':{
      const spots = [[-128,-150],[-156,-130],[-120,-124],[-148,-162]];
      for(const s of spots){
        const m = new THREE.Mesh(new THREE.BoxGeometry(0.8,0.6,0.8), new THREE.MeshStandardMaterial({ color:0x6a4a1a, emissive:0x8a6a2a, emissiveIntensity:0.5 }));
        m.position.set(s[0], 0.3, s[1]); scene.add(m);
        a.items.push(m);
      }
      break; }
  }
  banner('QUEST STARTED — ' + q.title.en, q.title.ar);
  S.defused();
}
function declineQuest(){ hide('sqoffer'); }
function clearQuest(completed){
  const a = V5.questActive;
  if(!a) return;
  for(const m of (a.items||[])) scene.remove(m);
  if(a.escortCar) worldRoot.remove(a.escortCar);
  if(a.chaseCar) worldRoot.remove(a.chaseCar);
  for(const c of V5.civilians.slice()){
    if(c.rescue){ c.rescue = false; c.state = 'done'; worldRoot.remove(c.mesh); V5.civilians.splice(V5.civilians.indexOf(c), 1); }
  }
  V5.questActive = null;
  if(completed){
    V5.questsDone[a.id] = true;
    const r = a.reward;
    addXP(r.xp);
    if(r.rep) V5.rep += r.rep;
    if(r.score) G.score += r.score;
    if(r.nades) player.nades = Math.min(6, player.nades + r.nades);
    banner('QUEST COMPLETE — ' + a.title.en, a.title.ar + ' · +' + r.xp + ' XP');
    S.victory();
    saveProgress();
  }
}
function updateQuest(dt){
  const a = V5.questActive;
  if(!a) return;
  a.t += dt;
  const pp = player.pos;
  switch(a.type){
    case 'rescue':{
      const guardsAlive = enemies.some(e=>!e.dead && e.questGuard === a);
      if(!guardsAlive && !a.freed){
        a.freed = true;
        for(const c of a.civs){ c.state = 'flee'; }
        banner('HOSTAGES FREE — أوصلهم إلى الساحة!', 'Escort them to the plaza!');
      }
      if(a.freed && a.civs.every(c=>c.state === 'safe')){
        V5.civiliansSaved += a.count;
        clearQuest(true);
      }
      break; }
    case 'deliver':{
      if(!a.picked){
        if(pp.distanceTo(a.items[0].position) < 2.2){
          a.picked = true; scene.remove(a.items[0]); a.items = [];
          S.pickup(); banner('PACKAGE PICKED — أوصلها للعيادة!', 'Deliver to the clinic!');
          a.timeLeft = a.time;
        }
      } else {
        a.timeLeft -= dt;
        const d = Math.hypot(pp.x - a.tgtPos[0], pp.z - a.tgtPos[1]);
        if(d < 5){ clearQuest(true); }
        else if(a.timeLeft <= 0){ banner('TOO LATE — فات الأوان', ''); clearQuest(false); }
      }
      break; }
    case 'race':{
      a.timeLeft -= dt;
      const cp = a.checkpoints[a.cpIdx];
      if(pp.distanceTo(cp) < 6){
        a.cpIdx++; S.pickup();
        burst(cp.clone().add(new THREE.Vector3(0,1.5,0)), 0xffd166, 12, 4, 0.08);
        if(a.cpIdx >= a.checkpoints.length){ clearQuest(true); }
      }
      if(a.timeLeft <= 0){ banner('TIME UP — انتهى الوقت', ''); clearQuest(false); }
      break; }
    case 'target':{
      if(a.target.dead) clearQuest(true);
      break; }
    case 'collect': case 'caches':{
      for(let i=a.items.length-1;i>=0;i--){
        const m = a.items[i];
        if(pp.distanceTo(m.position) < 2.2){
          S.pickup(); scene.remove(m); a.items.splice(i,1);
          a.progress++;
          banner(a.progress + ' / ' + a.count + ' COLLECTED', 'تم الجمع');
        }
      }
      if(a.items.length === 0) clearQuest(true);
      break; }
    case 'defend':{
      a.timeLeft -= dt;
      a.defSpawnT -= dt;
      if(a.defSpawnT <= 0 && G.enemiesAlive < 5){
        a.defSpawnT = 4.5;
        const g = spawnEnemy(Math.random() < 0.5 ? 'runner' : 'soldier');
        g.questGuard = a;
      }
      if(a.timeLeft <= 0) clearQuest(true);
      break; }
    case 'escort':{
      // move ambulance along route
      const tgt = a.route[Math.min(a.leg, a.route.length-1)];
      const c = a.escortCar.position;
      const dx = tgt[0]-c.x, dz = tgt[1]-c.z, dl = Math.hypot(dx,dz);
      if(dl < 4){ a.leg++; if(a.leg >= a.route.length){ clearQuest(true); break; } }
      else {
        c.x += dx/dl * 7 * dt; c.z += dz/dl * 7 * dt;
        a.escortCar.rotation.y = Math.atan2(dx, dz);
      }
      // ambushes
      if(a.ambushes.includes(a.leg) && !a.ambushed.includes(a.leg)){
        a.ambushed.push(a.leg);
        for(let i=0;i<3;i++){
          const g = spawnEnemy(i === 0 ? 'heavy' : 'runner', [c.x + rand(-14,14), c.z + rand(-14,14)]);
          g.escortHunter = true;
        }
        banner('AMBUSH! — كمين على القافلة!', 'Protect the ambulance!');
      }
      // hunters shoot the ambulance
      for(const e of enemies){
        if(e.dead || !e.escortHunter) continue;
        if(Math.random() < dt * 0.5 && e.mesh.position.distanceTo(c) < 40){
          a.escortHp -= rand(4, 8);
          tracer(e.mesh.position.clone().add(new THREE.Vector3(0,1.4,0)), c.clone().add(new THREE.Vector3(0,1,0)), 0xff7766);
        }
      }
      if(a.escortHp <= 0){
        explodeAt(c.clone());
        banner('AMBULANCE DOWN — سقط الإسعاف', '');
        clearQuest(false);
      }
      break; }
    case 'clearbase':{
      if(!enemies.some(e=>!e.dead && e.questGuard === a)) clearQuest(true);
      break; }
    case 'chase':{
      a.timeLeft -= dt;
      a.chaseS += 0.02 * dt * 6;
      const p = ringPoint(a.chaseS);
      a.chaseCar.position.set(p.x, 0, p.z);
      a.chaseCar.rotation.y = Math.atan2(p.x - a.chaseCar.position.x, 0) || a.chaseCar.rotation.y;
      // shooting it damages
      // (handled via hit detection in playerShoot? simpler: proximity of bullets — approximate with explosion + proximity)
      if(a.timeLeft <= 0 || a.chaseS > 8.4){ banner('IT ESCAPED — أفلتت', ''); clearQuest(false); }
      break; }
    case 'snipers':{
      if(!enemies.some(e=>!e.dead && e.questSniper)) clearQuest(true);
      break; }
  }
}
/* chase car takes damage from player shots & explosions & ramming */
function chaseCarHit(dmg){
  const a = V5.questActive;
  if(!a || a.type !== 'chase' || !a.chaseCar) return false;
  // proximity handled where called
  a.chaseHp -= dmg;
  burst(a.chaseCar.position.clone().add(new THREE.Vector3(0,1,0)), 0xffd070, 6, 4, 0.08);
  if(a.chaseHp <= 0){
    explodeAt(a.chaseCar.position.clone());
    clearQuest(true);
  }
  return true;
}

/* ================================================================ */
/* QUEST BOARD (plaza) interaction                                  */
/* ================================================================ */
function openQuestBoard(){
  G.state = 'quests';
  const avail = SIDE_QUESTS.filter(q=>{
    if(V5.questsDone[q.id] || (V5.questActive && V5.questActive.id === q.id)) return false;
    if(q.nightOnly && V5.weather >= 0 && envDaylight() > 0.25) return false;
    const pools = Object.values(SIDE_QUEST_WAVES).flat();
    return pools.includes(q.id);
  });
  let html = '';
  for(const q of avail){
    html += '<div class="qentry" data-q="' + q.id + '"><b>' + q.title.en + '</b> — ' + q.title.ar +
      '<br><span style="color:#8fa2bd;font-size:.85em">' + q.desc.en + '</span></div>';
  }
  if(!html) html = '<div style="text-align:center;color:#8fa2bd">No quests available — كل المهام أنجزت حالياً<br><br></div>';
  $('questlist').innerHTML = html;
  $('questlist').querySelectorAll('.qentry').forEach(el=>{
    el.addEventListener('click', ()=>{
      const q = SIDE_QUESTS.find(x=>x.id === el.dataset.q);
      hide('quests');
      G.state = 'playing';
      acceptQuest(q);
    });
  });
  show('quests');
}
function envDaylight(){
  const el = -Math.cos(V5.tod * Math.PI * 2);
  return clamp(el * 1.6 + 0.32, 0, 1);
}

/* ================================================================ */
/* PLANE CINEMATIC (chapter transitions)                            */
/* ================================================================ */
function startPlaneScene(ch, done){
  const cfg = PLANE_SCENES[ch];
  if(!cfg){ done(); return; }
  G.state = 'plane';
  const PL = { t:0, line:0, done, cfg, phase:'fly' };
  V5.planeState = PL;
  // reuse cinematic overlay
  $('cine').style.display = 'block';
  $('cinelabel').textContent = 'CHAPTER ' + ch + ' — INCOMING TRANSPORT';
  // the plane (fresh, flying)
  PL.plane = makePlaneInstance();
  PL.start = new THREE.Vector3(player.pos.x + 260, 42, player.pos.z + 320);
  PL.end = new THREE.Vector3(player.pos.x + 24, 0, player.pos.z + 26);
  PL.plane.g.position.copy(PL.start);
  // officer actor
  PL.officer = window.SkeletonUtils.clone(models.hero.scene);
  const tint = ch === 4 ? 0x9a5fb8 : 0x3a3f4a;
  PL.officer.traverse(o=>{ if(o.isMesh && o.material && o.material.map){ o.material = o.material.clone(); o.material.color = new THREE.Color(tint); } });
  PL.officer.visible = false;
  scene.add(PL.officer);
  PL.officerMixer = new THREE.AnimationMixer(PL.officer);
  $('cineskip').onclick = ()=> endPlaneScene();
  TTS.stop();
}
function makePlaneInstance(){
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color:0x3a4150, roughness:0.5, metalness:0.4 });
  const fus = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.1, 11, 10), mat);
  fus.rotation.z = Math.PI/2; fus.position.y = 2.0; g.add(fus);
  const wing = new THREE.Mesh(new THREE.BoxGeometry(2, 0.22, 15), mat);
  wing.position.set(0.4, 2.0, 0); g.add(wing);
  const tailV = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.8, 0.18), mat);
  tailV.position.set(-5, 2.9, 0); g.add(tailV);
  const props = [];
  for(const dz of [-5.8, 5.8]){
    const eng = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 3, 8), mat);
    eng.rotation.z = Math.PI/2; eng.position.set(1.8, 2.0, dz); g.add(eng);
    const spin = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.9, 0.35), new THREE.MeshStandardMaterial({ color:0x1a1d22 }));
    spin.position.set(3.4, 2.0, dz); g.add(spin); props.push(spin);
  }
  scene.add(g);
  return { g, props };
}
function updatePlaneScene(dt){
  const PL = V5.planeState;
  if(!PL) return;
  PL.t += dt;
  for(const p of PL.plane.props) p.rotation.z += dt * 40;
  // camera: watch the sky, then the landing strip
  const camTgt = PL.end.clone().add(new THREE.Vector3(0, 3, 0));
  if(PL.phase === 'fly'){
    const k = clamp(PL.t / 10, 0, 1);
    const e = k*k*(3-2*k);
    PL.plane.g.position.lerpVectors(PL.start, PL.end, e);
    PL.plane.g.rotation.y = Math.atan2(PL.start.x - PL.end.x, PL.start.z - PL.end.z) + Math.PI/2;
    PL.plane.g.rotation.z = Math.sin(PL.t*0.7) * 0.12 * (1-k);
    camera.position.set(PL.end.x + 20, 9, PL.end.z + 34);
    camera.lookAt(PL.plane.g.position);
    // subtitle intro
    if(PL.line === 0 && PL.t > 1.5){ planeLine(PL); }
    if(k >= 1){
      PL.phase = 'land'; PL.t2 = 0;
      sfx(c=> noiseBurst(c, 0.5, 0.3, 300));
      G.shake = 0.5;
      // officer steps out
      PL.officer.visible = true;
      PL.officer.position.copy(PL.end).add(new THREE.Vector3(-2, 0, 4));
      PL.officer.rotation.y = Math.PI;
      PL.officerMixer.clipAction(models.hero.animations.find(a=>a.name==='Walking_A') || models.hero.animations[0]).play();
      camera.position.set(PL.end.x + 4, 2.2, PL.end.z + 12);
    }
  } else if(PL.phase === 'land'){
    PL.officerMixer.update(dt);
    // walk toward camera
    PL.officer.position.z -= dt * 1.6;
    if(PL.officer.position.z < PL.end.z - 3) PL.officer.position.z = PL.end.z - 3;
    camera.lookAt(PL.officer.position.clone().add(new THREE.Vector3(0, 1.6, 0)));
    if(PL.t2 === undefined) PL.t2 = 0;
  }
}
function planeLine(PL){
  const L = PL.cfg.dialogue[PL.line];
  if(!L){ endPlaneScene(); return; }
  const who = PL.cfg.officer === 'lina'
    ? (isAr() ? 'الدكتورة لينا' : 'DR. LINA')
    : (isAr() ? 'الشبح' : 'THE GHOST');
  $('cinesub').innerHTML = '<b style="color:#ffd166">' + who + ':</b> ' + L.ar +
    (isAr() ? '' : '<span class="ensub">' + L.en + '</span>');
  S.radio();
  TTS.say(L.en, L.ar, ()=>{ setTimeout(()=>{ PL.line++; if(PL.line <= PL.cfg.dialogue.length){ planeLine(PL); } }, 400); });
  // auto-advance safety
  clearTimeout(PL.autoT);
  PL.autoT = setTimeout(()=>{ PL.line++; if(PL.line < PL.cfg.dialogue.length) planeLine(PL); else endPlaneScene(); }, 7000);
}
function endPlaneScene(){
  const PL = V5.planeState;
  if(!PL) return;
  clearTimeout(PL.autoT);
  TTS.stop();
  scene.remove(PL.plane.g);
  scene.remove(PL.officer);
  $('cine').style.display = 'none';
  $('cinesub').innerHTML = '';
  V5.planeState = null;
  $('fade').style.opacity = 1;
  setTimeout(()=>{
    $('fade').style.opacity = 0;
    G.state = 'playing';
    const done = PL.done;
    done && done();
  }, 900);
}

/* ================================================================ */
/* MINIMAP                                                          */
/* ================================================================ */
function drawMinimap(){
  const cv = $('minimap');
  if(!cv || cv.offsetWidth === 0) return;
  const ctx = cv.getContext('2d');
  const W = cv.width, H = cv.height;
  const R = W / 2;
  const scale = W / 260; // shows 260m across
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(8,14,24,0.82)';
  ctx.beginPath(); ctx.arc(R, R, R - 1, 0, Math.PI*2); ctx.fill();
  ctx.save();
  ctx.beginPath(); ctx.arc(R, R, R - 2, 0, Math.PI*2); ctx.clip();
  ctx.translate(R, R);
  ctx.rotate(-player.yaw);
  const px = player.pos.x, pz = player.pos.z;
  const toMap = (x, z)=>[(x - px) * scale, (z - pz) * scale];
  // ground
  ctx.fillStyle = '#1a2230';
  ctx.fillRect(-R*2, -R*2, R*4, R*4);
  // water
  ctx.fillStyle = '#1b4f72';
  { const [x, z] = toMap(-179, 58); ctx.fillRect(x, z, 358*scale, 18*scale); }
  { const [x, z] = toMap(150, 150); ctx.fillRect(x, z, 60*scale, 60*scale); }
  // ring road
  ctx.strokeStyle = '#3d4a5c'; ctx.lineWidth = 5;
  { const [x1, z1] = toMap(-186, -186); const [x2, z2] = toMap(186, 186); ctx.strokeRect(x1, z1, x2-x1, z2-z1); }
  // avenues
  ctx.strokeStyle = '#333e4e'; ctx.lineWidth = 3;
  { const [x, z] = toMap(0, -186); ctx.beginPath(); ctx.moveTo(x, z); const [x2, z2] = toMap(0, 186); ctx.lineTo(x2, z2); ctx.stroke();
    const [x3, z3] = toMap(-186, 10); ctx.beginPath(); ctx.moveTo(x3, z3); const [x4, z4] = toMap(186, 10); ctx.lineTo(x4, z4); ctx.stroke(); }
  // district tints
  ctx.globalAlpha = 0.25;
  for(const k in DISTRICTS){
    const d = DISTRICTS[k];
    const [x, z] = toMap(d.cx - d.r*0.5, d.cz - d.r*0.5);
    ctx.fillStyle = k === 'ruins' ? '#402818' : k === 'docks' ? '#134a6a' : '#2a3a52';
    ctx.fillRect(x, z, d.r*scale, d.r*scale);
  }
  ctx.globalAlpha = 1;
  // bomb
  if(bomb.active && !bomb.defused){
    const [x, z] = toMap(bomb.pos.x, bomb.pos.z);
    const pulse = 4 + Math.sin(performance.now()/180)*2;
    ctx.fillStyle = '#ff3030';
    ctx.beginPath(); ctx.arc(x, z, pulse, 0, Math.PI*2); ctx.fill();
  }
  // quest marker
  const a = V5.questActive;
  if(a){
    let mp = null;
    if(a.pos) mp = a.pos;
    if(a.tgtPos && a.picked) mp = a.tgtPos;
    if(a.checkpoints && a.cpIdx < a.checkpoints.length) mp = [a.checkpoints[a.cpIdx].x, a.checkpoints[a.cpIdx].z];
    if(a.chaseCar) mp = [a.chaseCar.position.x, a.chaseCar.position.z];
    if(a.escortCar) mp = [a.escortCar.position.x, a.escortCar.position.z];
    if(a.items && a.items.length) mp = [a.items[0].position.x, a.items[0].position.z];
    if(mp){
      const [x, z] = toMap(mp[0], mp[1]);
      ctx.fillStyle = '#ffd166';
      ctx.beginPath(); ctx.moveTo(x, z-7); ctx.lineTo(x+5, z+4); ctx.lineTo(x-5, z+4); ctx.closePath(); ctx.fill();
    }
  }
  // enemies
  ctx.fillStyle = '#ff5555';
  for(const e of enemies){
    if(e.dead) continue;
    const [x, z] = toMap(e.mesh.position.x, e.mesh.position.z);
    ctx.fillRect(x-1.8, z-1.8, 3.6, 3.6);
  }
  // civilians
  ctx.fillStyle = '#4fd08a';
  for(const c of V5.civilians){
    const [x, z] = toMap(c.mesh.position.x, c.mesh.position.z);
    ctx.fillRect(x-1.4, z-1.4, 2.8, 2.8);
  }
  // usable cars
  ctx.fillStyle = '#aab6c8';
  for(const c of V5.usableCars){
    if(c.destroyed) continue;
    const [x, z] = toMap(c.mesh.position.x, c.mesh.position.z);
    ctx.fillRect(x-1.6, z-1.6, 3.2, 3.2);
  }
  ctx.restore();
  // player arrow (fixed center)
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.moveTo(R, R - 7); ctx.lineTo(R + 5, R + 5); ctx.lineTo(R - 5, R + 5); ctx.closePath(); ctx.fill();
  // frame
  ctx.strokeStyle = 'rgba(143,162,189,0.5)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(R, R, R - 2, 0, Math.PI*2); ctx.stroke();
}

/* ================================================================ */
/* HUD                                                              */
/* ================================================================ */
function updateHUD(){
  $('hpfill').style.width = (player.hp/player.maxHp*100).toFixed(0)+'%';
  $('hpfill').style.background = player.hp > 50 ? 'linear-gradient(90deg,#2ed573,#7bed9f)'
    : player.hp > 25 ? 'linear-gradient(90deg,#ffa502,#ffdead)' : 'linear-gradient(90deg,#ff4757,#ff7f7f)';
  $('hptext').textContent = isAr() ? `الصحة ${Math.ceil(player.hp)}` : `HP ${Math.ceil(player.hp)}`;
  $('ammo').innerHTML = `${player.ammo} <span class="res">/ ∞</span>`;
  $('nades').textContent = isAr() ? `قنابل: ${player.nades}` : `GRENADES: ${player.nades}`;
  const m = V5.mission;
  $('wave').textContent = m
    ? (isAr() ? `المهمة ${m.wave}` : `MISSION ${m.wave}`)
    : (G.endless ? (isAr() ? 'الوضع اللانهائي' : 'ENDLESS') : '—');
  $('mission').textContent = m ? (isAr() ? m.mission.ar : m.mission.en) : '';
  $('enemies').textContent = isAr() ? `الأعداء: ${G.enemiesAlive}` : `Enemies: ${G.enemiesAlive}`;
  $('score').firstElementChild.textContent = isAr() ? `النقاط: ${G.score}` : `SCORE: ${G.score}`;
  // stamina
  const st = $('stamfill');
  if(st){ st.style.width = (MV.stamina / MV.maxStamina * 100) + '%'; st.style.background = MV.stamina < 20 ? '#ff7f50' : '#5aa0e8'; }
  // xp
  const xb = $('xpfill');
  if(xb){ xb.style.width = clamp(V5.xp / XP_NEED(V5.level) * 100, 0, 100) + '%'; }
  const lv = $('lvltext');
  if(lv){ lv.textContent = (isAr() ? 'المستوى ' : 'LV ') + V5.level + ' · ' + repTitle(); }
  // quest tracker
  const qt = $('questtrack');
  if(qt){
    const a = V5.questActive;
    if(a){
      let obj = a.desc.ar;
      if(a.type === 'race') obj = 'نقطة ' + (a.cpIdx+1) + '/' + a.checkpoints.length + ' · ' + Math.ceil(a.timeLeft) + 's';
      if(a.type === 'deliver' && a.picked) obj = 'أوصل الشحنة! ' + Math.ceil(a.timeLeft) + 's';
      if(a.type === 'deliver' && !a.picked) obj = 'التقط الشحنة من المستشفى';
      if(a.type === 'defend') obj = 'اصمد! ' + Math.ceil(a.timeLeft) + 's';
      if(a.type === 'chase') obj = 'دمّر السيارة! ' + Math.ceil(a.timeLeft) + 's';
      if(a.type === 'collect' || a.type === 'caches') obj = 'اجمع المقتنيات ' + a.progress + '/' + a.count;
      if(a.type === 'escort') obj = 'احمِ الإسعاف — التقدم ' + a.leg + '/' + a.route.length;
      if(a.type === 'rescue') obj = a.freed ? 'أوصل الرهائن إلى الساحة!' : 'اقضِ على الحراس!';
      if(a.type === 'clearbase') obj = 'اقضِ على كل أفراد القاعدة!';
      if(a.type === 'target') obj = 'اقضِ على الهدف الذهبي!';
      if(a.type === 'snipers') obj = 'اقضِ على القناصة!';
      qt.innerHTML = '<b>◆ ' + (isAr() ? a.title.ar : a.title.en) + '</b><br><span style="color:#ffd166">' + obj + '</span>';
      qt.style.display = 'block';
    } else qt.style.display = 'none';
  }
  // interact prompt
  const ip = $('interact');
  if(ip){
    let txt = '';
    if(V5.driving) txt = isAr() ? 'F / ACT — ترك السيارة' : 'F / ACT — Exit vehicle';
    else {
      const car = nearestUsableCar();
      const nearBoard = player.pos.distanceTo(new THREE.Vector3(8.5, 0, -18)) < 3.4;
      if(nearBoard) txt = isAr() ? 'F / ACT — لوحة المهام' : 'F / ACT — Quest Board';
      else if(car) txt = isAr()
        ? 'F / ACT — ركوب ' + car.type.replace('car_','').toUpperCase()
        : 'F / ACT — Enter ' + car.type.replace('car_','').toUpperCase();
    }
    ip.textContent = txt;
    ip.style.opacity = txt ? 1 : 0;
  }
  drawMinimap();
}

/* beacon pillar over the bomb */
const _beacon = { mesh:null };
function updateBeacon(){
  if(bomb.active && !bomb.defused && !_beacon.mesh){
    const geo = new THREE.CylinderGeometry(0.5, 0.5, 90, 8, 1, true);
    const mat = new THREE.MeshBasicMaterial({ color:0xff3030, transparent:true, opacity:0.16, depthWrite:false, side:THREE.DoubleSide });
    _beacon.mesh = new THREE.Mesh(geo, mat);
    scene.add(_beacon.mesh);
  }
  if(_beacon.mesh){
    if(bomb.active && !bomb.defused){
      _beacon.mesh.visible = true;
      _beacon.mesh.position.set(bomb.pos.x, 45, bomb.pos.z);
      _beacon.mesh.material.opacity = 0.1 + Math.abs(Math.sin(performance.now()/600)) * 0.12;
    } else _beacon.mesh.visible = false;
  }
}

/* ================================================================ */
/* ENDLESS MODE                                                     */
/* ================================================================ */
function startEndless(){
  G.endless = true;
  V5.mission = null;
  G.nextWaveT = 3;
  G.wave = 15;
  banner('ENDLESS MODE', 'الوضع اللانهائي — اصمد أطول ما تستطيع!');
  S.wave();
}
function updateEndless(dt){
  if(!G.endless) return;
  if(G.nextWaveT > 0){
    G.nextWaveT -= dt;
    if(G.nextWaveT <= 0){
      G.wave++;
      const dks = Object.keys(DISTRICTS).filter(k=>k !== 'undercity');
      const dk = spick(dks);
      const d = DISTRICTS[dk];
      const m = { wave:G.wave, ch:6, district:dk, site:[d.cx + rand(-20,20), d.cz + rand(-20,20)], mission:{ ar:'بقاء', en:'Survival' }, endless:true };
      V5.mission = m;
      G.comp = [];
      const count = clamp(6 + G.wave, 6, 22);
      for(let i=0;i<count;i++){
        let t = 'soldier';
        if(Math.random() < 0.3) t = 'runner';
        if(Math.random() < 0.25) t = 'heavy';
        if(Math.random() < 0.18) t = 'bomber';
        if(Math.random() < 0.15) t = 'sniper';
        G.comp.push(t);
      }
      G.toSpawn = G.comp.length; G.spawnT = 0.6;
      spawnBomb(false);
      banner('WAVE ' + G.wave, 'الموجة ' + G.wave);
      S.wave();
    }
    return;
  }
  if(G.toSpawn > 0){
    G.spawnT -= dt;
    if(G.spawnT <= 0){ spawnEnemy(G.comp[G.comp.length - G.toSpawn]); G.toSpawn--; G.spawnT = rand(0.8, 1.8); }
  }
  if(G.toSpawn === 0 && G.enemiesAlive === 0 && bomb.active && bomb.defused){
    G.score += 500;
    G.nextWaveT = 4;
    bomb.active = false; bomb.mesh.visible = false;
  }
}

/* ================================================================ */
/* MASTER UPDATE (called every frame while playing)                 */
/* ================================================================ */
function v5Update(dt){
  envUpdate(dt);
  updateCulling(dt);
  updateAutoQuality(dt);
  if(G.state === 'playing'){
    updateCampaign(dt);
    updateEndless(dt);
    updateTraffic(dt);
    updateCivilians(dt);
    updateQuest(dt);
    updateRadio(dt);
    updateRain(dt);
    updateBeacon();
    maybeOfferChoice();
    // chase car damage: bullets landing near it
    if(V5.questActive && V5.questActive.type === 'chase' && V5.questActive.chaseCar){
      // handled approximately: proximity explosions
    }
  } else if(G.state === 'plane'){
    updatePlaneScene(dt);
    updateRain(dt);
  }
}

/* ================================================================ */
/* INTERACTION (F key / ACT button)                                 */
/* ================================================================ */
function doInteract(){
  if(G.state !== 'playing') return;
  if(V5.driving){ exitVehicle(); return; }
  if(player.pos.distanceTo(new THREE.Vector3(8.5, 0, -18)) < 3.4){ openQuestBoard(); return; }
  const car = nearestUsableCar();
  if(car){ enterVehicle(car); return; }
  tryMelee();
}

/* ================================================================ */
/* VICTORY (ending varies by reputation)                            */
/* ================================================================ */
function v5Victory(){
  G.state = 'victory';
  S.victory();
  saveBest();
  saveProgress();
  const tier = repTier();
  const ending = STORY_ENDINGS[tier];
  const savedLine = V5.civiliansSaved > 0
    ? `<br><b style="color:#7bed9f">${isAr() ? 'مدنيون أنقذتهم' : 'CIVILIANS SAVED'}: ${V5.civiliansSaved}</b><br>` : '';
  $('victorystats').innerHTML =
    (isAr()
      ? `النتيجة: <b style="color:#2ed573">${G.score}</b><br>` +
        `المستوى: <b>${V5.level}</b> · ${repTitle()}<br>` +
        `السمعة: <b>${V5.rep >= 0 ? '+' : ''}${V5.rep}</b>`
      : `SCORE: <b style="color:#2ed573">${G.score}</b><br>` +
        `LEVEL: <b>${V5.level}</b> · ${repTitle()}<br>` +
        `REPUTATION: <b>${V5.rep >= 0 ? '+' : ''}${V5.rep}</b>`) +
    savedLine +
    (isAr() ? `أفضل نتيجة: <b>${G.best}</b>` : `BEST: <b>${G.best}</b>`);
  $('endtext2').innerHTML = isAr()
    ? ending.map(s=>s.ar).join('<br><br>')
    : ending.map(s=>s.en + '<br><span style="color:#7d8ea6;font-size:.85em">' + s.ar + '</span>').join('<br><br>');
  show('victory');
  $('hud').style.display = 'none';
  $('touchui').style.display = 'none';
  TTS.say(ending[0].en, ending[0].ar);
  if(document.pointerLockElement) document.exitPointerLock();
}
