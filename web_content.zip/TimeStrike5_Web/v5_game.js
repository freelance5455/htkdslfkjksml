/* =====================================================================
   TIME STRIKE 5 — GAMEPLAY SYSTEMS
   Movement overhaul / Camera / Combat / Enemy AI / Bosses / Vehicles
   ===================================================================== */
"use strict";

/* ================================================================ */
/* MOVEMENT STATE MACHINE — complete rebuild                       */
/* ================================================================ */
const MV = {
  sprint:false, crouch:false, slideT:0, slideDX:0, slideDZ:0,
  stamina:100, maxStamina:100,
  coyote:0, jumpBuf:0, vault:null,          // vault:{from,to,t,dur}
  landDip:0, prevVy:0, bobT:0, meleeT:0, vaultCD:0
};
function playerRadius(){ return MV.crouch ? 0.42 : 0.55; }

function startSlide(){
  const sp = Math.hypot(player.moveVel.x, player.moveVel.z);
  if(sp < 4.5) return;
  MV.slideT = 0.62;
  const l = sp || 1;
  MV.slideDX = player.moveVel.x / l;
  MV.slideDZ = player.moveVel.z / l;
  sfx(c=>{ noiseBurst(c, 0.5, 0.16, 900, 0, 600); });
  G.shake = Math.min(G.shake + 0.12, 0.5);
}
function tryMelee(){
  if(MV.meleeT > 0 || player.dead || G.state !== 'playing') return;
  MV.meleeT = 0.7;
  setPlayerAnim('Use_Item', 0.1);
  sfx(c=>{ noiseBurst(c, 0.08, 0.3, 1400); tone(c, 180, 90, 0.09, 'sawtooth', 0.2); });
  const sy = Math.sin(player.yaw), cy = Math.cos(player.yaw);
  const fx = -sy, fz = -cy;
  let hitAny = false;
  for(const e of enemies){
    if(e.dead) continue;
    const dx = e.mesh.position.x - player.pos.x, dz = e.mesh.position.z - player.pos.z;
    const d = Math.hypot(dx, dz);
    if(d < 2.5){
      const dot = (dx*fx + dz*fz) / (d || 1);
      if(dot > 0.55){
        const dmg = 60 + V5.level * 4;
        e.hp -= dmg; e.hitT = 0.3; hitAny = true;
        burst(e.mesh.position.clone().add(new THREE.Vector3(0, 1.2*e.scale, 0)), 0xd8d0b8, 8, 4, 0.07);
        const kb = new THREE.Vector3(dx/d*5, 0, dz/d*5);
        const np = e.mesh.position.clone().add(kb);
        collide(np, 0.5);
        e.mesh.position.x = np.x; e.mesh.position.z = np.z;
        if(e.hp <= 0) killEnemy(e, false);
      }
    }
  }
  if(hitAny){ S.hit(); const hm = $('hitmark'); hm.classList.remove('show'); void hm.offsetWidth; hm.classList.add('show'); }
}

function updatePlayer(dt){
  const driving = !!V5.driving;
  const lookAccum = Math.abs(input.lookDX) + Math.abs(input.lookDY);
  player.yaw   -= input.lookDX;
  player.pitch -= input.lookDY;
  player.pitch = clamp(player.pitch, -1.15, 1.2);
  input.lookDX = input.lookDY = 0;

  if(!driving){
    /* ---- input direction ---- */
    let ix = 0, iz = 0;
    if(keys['KeyW']||keys['ArrowUp']) iz -= 1;
    if(keys['KeyS']||keys['ArrowDown']) iz += 1;
    if(keys['KeyA']||keys['ArrowLeft']) ix -= 1;
    if(keys['KeyD']||keys['ArrowRight']) ix += 1;
    let joyMag = 0;
    if(joy.active){ ix = joy.x; iz = joy.y; joyMag = Math.hypot(joy.x, joy.y); }
    const iLen = Math.hypot(ix, iz);
    if(iLen > 1){ ix /= iLen; iz /= iLen; }

    const movingFwd = iz < -0.25 || (joy.active && joy.y < -0.4);

    /* ---- crouch ---- */
    if(input.crouchToggle){ MV.crouch = !MV.crouch; input.crouchToggle = false; if(MV.crouch) sfx(c=>noiseBurst(c,0.06,0.08,700)); }
    if(keys['ControlLeft'] || keys['ControlRight']) MV.crouch = true;
    else if(!input.crouchHeld && MV.crouch && !MV.slideT && !input.crouchLatch) MV.crouch = false;
    if(input.crouchHeld) MV.crouch = true;

    /* ---- sprint ---- */
    const wantSprint = (keys['ShiftLeft']||keys['ShiftRight']||input.sprintHeld||input.sprintLatch) && !MV.crouch;
    const sprinting = wantSprint && movingFwd && MV.stamina > 1 && !player.reloading && player.onGround !== false;

    /* ---- slide trigger ---- */
    if(sprinting && MV.crouch === false && input.slideRequest){ input.slideRequest = false; startSlide(); }
    input.slideRequest = false;
    if(MV.slideT > 0 && player.onGround) MV.crouch = true;

    /* ---- stamina ---- */
    if(sprinting) MV.stamina = Math.max(0, MV.stamina - 16*dt);
    else MV.stamina = Math.min(MV.maxStamina, MV.stamina + 13*dt);

    /* ---- speed ---- */
    const moveAmt = clamp(Math.max(joyMag, iLen > 0.1 ? 1 : 0), 0, 1);
    let speed;
    if(MV.slideT > 0){
      speed = 10.8 * (0.45 + 0.55 * (MV.slideT / 0.62));
      MV.slideT -= dt;
      if(MV.slideT <= 0 && !input.crouchHeld && !input.crouchLatch) MV.crouch = false;
    }
    else if(MV.crouch) speed = 1.8;
    else if(sprinting) speed = 8.8;
    else speed = (moveAmt < 0.55 ? 2.5 : 6.4) * Math.max(moveAmt, iLen > 0.1 ? 0.55 : 0);

    const sy = Math.sin(player.yaw), cy = Math.cos(player.yaw);
    let wishX, wishZ;
    if(MV.slideT > 0){
      wishX = MV.slideDX * speed; wishZ = MV.slideDZ * speed;
      // slight steering while sliding
      wishX += cy * ix * 1.6; wishZ += -sy * ix * 1.6;
    } else {
      wishX = (-sy*(-iz) + cy*ix) * speed;
      wishZ = (-cy*(-iz) - sy*ix) * speed;
    }
    const accel = player.onGround ? 30 : 11;
    player.moveVel.x += clamp(wishX - player.moveVel.x, -accel*dt, accel*dt);
    player.moveVel.z += clamp(wishZ - player.moveVel.z, -accel*dt, accel*dt);
    if(iLen < 0.05 && MV.slideT <= 0 && player.onGround){
      const fr = Math.max(1 - 11*dt, 0);
      player.moveVel.x *= fr; player.moveVel.z *= fr;
    }

    const prevX = player.pos.x, prevZ = player.pos.z;
    player.pos.x += player.moveVel.x * dt;
    player.pos.z += player.moveVel.z * dt;
    collide(player.pos, playerRadius());

    /* ---- vault / step-up / mantle ---- */
    if(MV.vaultCD > 0) MV.vaultCD -= dt;
    const blocked = (Math.abs(player.pos.x - prevX - player.moveVel.x*dt) > 0.004 ||
                     Math.abs(player.pos.z - prevZ - player.moveVel.z*dt) > 0.004);
    if(blocked && iLen > 0.3 && !MV.vault && MV.vaultCD <= 0){
      const intendX = prevX + player.moveVel.x*dt, intendZ = prevZ + player.moveVel.z*dt;
      for(const c of colliders){
        if(c.h <= player.pos.y + 0.05) continue; // already above
        const r2 = playerRadius() * 0.8;
        if(intendX > c.minX - r2 && intendX < c.maxX + r2 && intendZ > c.minZ - r2 && intendZ < c.maxZ + r2){
          const lift = c.h - player.pos.y;
          const wantClimb = (input.jumpHeld || keys['Space']) ? 2.7 : 1.32;
          if(lift > 0 && lift <= wantClimb && c.h < 30 && c.walkable !== false){
            MV.vault = { from:player.pos.y, to:c.h + 0.02, t:0, dur: clamp(lift*0.16 + 0.1, 0.14, 0.3) };
            MV.vaultCD = 0.25;
            sfx(c=>{ noiseBurst(c, 0.12, 0.14, 800); });
            // resume intended horizontal motion
            player.pos.x = intendX; player.pos.z = intendZ;
            collide(player.pos, playerRadius());
            break;
          }
        }
      }
    }
    if(MV.vault){
      MV.vault.t += dt;
      const k = clamp(MV.vault.t / MV.vault.dur, 0, 1);
      player.pos.y = lerp(MV.vault.from, MV.vault.to, k*k*(3-2*k));
      player.vel.y = 0;
      player.onGround = false;
      if(k >= 1){ MV.vault = null; player.onGround = true; }
    }

    /* ---- jumping: coyote + buffer ---- */
    if(input.jump || keys['Space']){ MV.jumpBuf = 0.14; input.jump = false; }
    MV.jumpBuf -= dt; MV.coyote -= dt;
    if(player.onGround) MV.coyote = 0.12;
    if(!MV.vault && MV.jumpBuf > 0 && MV.coyote > 0){
      MV.jumpBuf = 0; MV.coyote = 0;
      player.vel.y = 7.6; player.onGround = false;
      if(MV.slideT > 0){ // slide-jump keeps momentum
        MV.slideT = 0;
        player.moveVel.x *= 1.1; player.moveVel.z *= 1.1;
      }
      const a = player.actions['Jump_Start'];
      if(a){ a.reset(); a.setLoop(THREE.LoopOnce,1); a.clampWhenFinished = true; a.fadeIn(0.08).play(); player.current='Jump_Start'; }
    }
    input.jumpHeld = keys['Space'];

    /* ---- gravity + ground (walkable heights) ---- */
    MV.prevVy = player.vel.y;
    if(!MV.vault){
      player.vel.y -= 22 * dt;
      player.pos.y += player.vel.y * dt;
    }
    const g = groundHeightAt(player.pos, playerRadius());
    if(player.pos.y <= g + 0.02 && player.vel.y <= 0){
      if(!player.onGround){
        if(MV.prevVy < -11){ MV.landDip = 0.3; G.shake = Math.min(G.shake + 0.25, 0.9); sfx(c=>{ noiseBurst(c, 0.1, 0.24, 320); }); }
        const a = player.actions['Jump_Land'];
        if(a && MV.prevVy < -4){ a.reset(); a.setLoop(THREE.LoopOnce,1); a.clampWhenFinished = true; a.fadeIn(0.05).play(); player.current='Jump_Land'; }
      }
      player.pos.y = g; player.vel.y = 0; player.onGround = true;
    } else if(player.pos.y > g + 0.05){
      player.onGround = false;
    }
    // stepped off a ledge?
    if(player.onGround && !MV.vault && player.pos.y > g + 0.05) player.onGround = false;

    player.speedNow = Math.hypot(player.moveVel.x, player.moveVel.z);

    /* ---- animation state ---- */
    player.mesh.position.copy(player.pos);
    player.mesh.rotation.y = player.yaw + HERO_YAW;
    player.mesh.visible = !player.fpv;
    fpvGun.visible = player.fpv && !player.dead;
    // crouch squash (no crouch clip in rig — visual scale)
    const targetSquash = MV.crouch ? 0.78 : 1;
    player.mesh.scale.y = lerp(player.mesh.scale.y || 1, targetSquash, 1 - Math.pow(0.001, dt));
    player.mesh.rotation.x = lerp(player.mesh.rotation.x, MV.slideT > 0 ? -0.35 : 0, 1 - Math.pow(0.0001, dt));

    if(!player.dead){
      const defusing = (input.defuseHold || keys['KeyE']) && bomb.active && !bomb.defused &&
                       player.pos.distanceTo(bomb.pos) < 3.2;
      if(player.current === '2H_Ranged_Reload' && player.reloading){ /* keep */ }
      else if(player.shootAnimT > 0){ setPlayerAnim('2H_Ranged_Shooting', 0.12); }
      else if(MV.meleeT > 0.5){ setPlayerAnim('Use_Item', 0.1); }
      else if(MV.vault || !player.onGround){ setPlayerAnim('Jump_Full_Short', 0.15); }
      else if(defusing){ setPlayerAnim('Interact', 0.25); }
      else if(MV.slideT > 0){ setPlayerAnim('Running_A', 0.1); }
      else if(player.speedNow > 7.6){ setPlayerAnim('Running_B', 0.12); }
      else if(player.speedNow > 4.2){
        const fwdX = -sy, fwdZ = -cy;
        const dot = (player.moveVel.x*fwdX + player.moveVel.z*fwdZ) / Math.max(player.speedNow, 0.01);
        if(dot < -0.4) setPlayerAnim('Walking_Backwards');
        else if(dot < 0.35) setPlayerAnim(player.moveVel.x*(-cy) + player.moveVel.z*(sy) > 0 ? 'Running_Strafe_Right' : 'Running_Strafe_Left');
        else setPlayerAnim('Running_A');
      }
      else if(player.speedNow > 0.4){ setPlayerAnim('Walking_A'); }
      else { setPlayerAnim('Idle'); }
    }

    /* ---- footsteps ---- */
    if(player.speedNow > 1.2 && player.onGround && !player.dead){
      player.stepT -= dt * (player.speedNow > 6 ? 1.9 : player.speedNow > 4 ? 1.5 : 1);
      if(player.stepT <= 0){ S.step(); player.stepT = MV.crouch ? 0.62 : 0.42; }
      MV.bobT += dt * player.speedNow * 1.4;
    }
    if(MV.meleeT > 0) MV.meleeT -= dt;
    if(MV.landDip > 0) MV.landDip = Math.max(0, MV.landDip - dt*1.4);

    // water slowdown (river band + docks)
    const inWater = (player.pos.z > 58 && player.pos.z < 76 && Math.abs(player.pos.x) < 179 && player.pos.y < 0.6 && !onBridge(player.pos)) ||
                    (player.pos.x > 150 && player.pos.z > 150 && player.pos.y < 0.3);
    if(inWater && player.speedNow > 2.4){ player.moveVel.x *= 0.9; player.moveVel.z *= 0.9; }
  } else {
    updateVehicle(dt);
  }

  player.mesh.position.copy(player.pos);
  if(driving){ player.mesh.visible = false; }

  if(player.reloading){
    player.reloadT -= dt;
    $('reloadtip').textContent = 'RELOADING... تعبئة...';
    if(player.reloadT <= 0){
      player.reloading = false; player.ammo = player.mag;
      if(player.current === '2H_Ranged_Reload') player.current = '';
    }
  } else {
    $('reloadtip').textContent = (player.ammo <= 8) ? 'PRESS R / زر RLD للتعبئة' : '';
  }

  if(!driving) playerShoot(dt);

  if(player.gun && player.gun.userData.muzzle){
    player.gun.userData.muzzle.visible = muzzleT > 0;
  }

  if(TUT.active && TUT.step === 1){
    if(lookAccum > 0.02){ TUT.data.look += lookAccum; if(TUT.data.look > 1.1) tutNext(); }
  }

  for(let i = medkits.length-1; i >= 0; i--){
    const mk = medkits[i];
    mk.t += dt;
    mk.m.rotation.y += dt*2;
    mk.m.position.y = 0.18 + Math.sin(mk.t*3)*0.06;
    if(player.pos.distanceTo(mk.m.position) < 1.6 && player.hp < player.maxHp){
      player.hp = Math.min(player.maxHp, player.hp + 30);
      S.pickup();
      hint(isAr() ? '+٣٠ صحة' : '+30 HP', 1200);
      scene.remove(mk.m); medkits.splice(i,1);
    } else if(mk.t > 25){ scene.remove(mk.m); medkits.splice(i,1); }
  }
}
function onBridge(p){
  if(Math.abs(p.x) < 9 && p.z > 57 && p.z < 77) return true;
  if(Math.abs(Math.abs(p.x) - 120) < 4.5 && p.z > 57 && p.z < 77) return true;
  return false;
}

/* ================================================================ */
/* CAMERA — cinematic rebuild                                      */
/* ================================================================ */
let camFov = 70, camRoll = 0;
const camPos = new THREE.Vector3(0, 3, 12);
const camTarget = new THREE.Vector3();
function camBlocked(x, y, z){
  for(const c of colliders){
    if(c.h < y - 0.3) continue;
    if(x > c.minX - 0.3 && x < c.maxX + 0.3 && z > c.minZ - 0.3 && z < c.maxZ + 0.3) return true;
  }
  return false;
}
function updateCamera(dt){
  if(V5.driving){ updateDriveCamera(dt); return; }
  const cp = Math.cos(player.pitch), sp = Math.sin(player.pitch);
  const sy = Math.sin(player.yaw), cy = Math.cos(player.yaw);
  const lookDir = new THREE.Vector3(-sy*cp, sp, -cy*cp);
  const aiming = input.fire && !player.dead;
  const sprinting = Math.hypot(player.moveVel.x, player.moveVel.z) > 7.4 && player.onGround;
  const sliding = MV.slideT > 0;

  const targetFov = aiming ? 55 : sprinting ? 79 : sliding ? 84 : MV.crouch ? 66 : 70;
  camFov = lerp(camFov, targetFov, 1 - Math.pow(0.004, dt));
  camera.fov = camFov; camera.updateProjectionMatrix();

  const headH = MV.crouch ? 1.05 : 1.62;

  if(player.fpv){
    const bob = Math.sin(MV.bobT) * 0.03 * clamp(player.speedNow/6, 0, 1);
    camera.position.set(player.pos.x, player.pos.y + headH + bob - MV.landDip*0.5, player.pos.z);
    fpvGun.position.set(0.3, -0.26 + MV.landDip*0.3, -0.55);
    if(sliding) fpvGun.position.y -= 0.1;
  } else {
    const dist = aiming ? 2.9 : sprinting ? 5.1 : sliding ? 5.3 : MV.crouch ? 3.8 : 4.6;
    const shoulder = aiming ? 1.05 : 0.85;
    const right = new THREE.Vector3(cy, 0, -sy);
    // look-ahead by velocity
    const la = clamp(player.speedNow * 0.16, 0, 1.1);
    camTarget.set(
      player.pos.x + player.moveVel.x/Math.max(player.speedNow,0.1) * la * 0.4,
      player.pos.y + (MV.crouch ? 1.15 : 1.75) - MV.landDip,
      player.pos.z + player.moveVel.z/Math.max(player.speedNow,0.1) * la * 0.4
    );
    const desired = camTarget.clone()
      .addScaledVector(lookDir, -dist)
      .addScaledVector(right, shoulder)
      .add(new THREE.Vector3(0, 0.35, 0));
    if(desired.y < 0.4) desired.y = 0.4;
    // anti-clip: march from head to desired
    const head = new THREE.Vector3(player.pos.x, player.pos.y + (MV.crouch?1.1:1.6), player.pos.z);
    const dirToDesired = desired.clone().sub(head);
    const len = dirToDesired.length();
    dirToDesired.normalize();
    let safe = len;
    for(let s = 0.5; s <= len; s += 0.5){
      const p = head.clone().addScaledVector(dirToDesired, s);
      if(camBlocked(p.x, p.y, p.z)){ safe = Math.max(1.0, s - 0.45); break; }
    }
    const finalPos = head.clone().addScaledVector(dirToDesired, safe);
    const k = 1 - Math.pow(0.00008, dt);
    camera.position.lerp(finalPos, k);
  }
  // recoil
  if(G.recoil > 0.001){
    G.recoil *= Math.pow(0.0001, dt);
    player.pitch = clamp(player.pitch + G.recoil * dt * 0.55, -1.15, 1.2);
  }
  // shake (trauma)
  if(G.shake > 0.001){
    G.shake *= Math.pow(0.001, dt);
    camera.position.x += rand(-1,1)*G.shake*0.25;
    camera.position.y += rand(-1,1)*G.shake*0.25;
    camRoll = lerp(camRoll, rand(-1,1)*G.shake*0.03, 0.5);
  } else camRoll = lerp(camRoll, 0, 1 - Math.pow(0.001, dt));
  // slide roll
  const wantRoll = sliding ? 0.09 : (sprinting ? -((player.moveVel.x*(-cy) + player.moveVel.z*(sy)) / 30) : 0);
  camRoll = lerp(camRoll, wantRoll, 1 - Math.pow(0.0005, dt));
  camera.lookAt(camera.position.clone().add(lookDir));
  camera.rotateZ(camRoll); // local-axis roll (safe post-lookAt)
}

/* ================================================================ */
/* ENEMY TYPES + BOSSES                                             */
/* ================================================================ */
function makeBossBar(){
  const bar = $('bossbar');
  return bar;
}
function updateBossBar(){
  const bar = $('bossbar');
  const b = V5.boss;
  if(!b || b.dead){ bar.style.display = 'none'; return; }
  bar.style.display = 'block';
  const t = ETYPES[b.type];
  $('bossname').textContent = t.name + ' — ' + (t.arName || t.name);
  $('bossfill').style.width = clamp(b.hp / b.maxHp * 100, 0, 100) + '%';
}

/* spawn position near mission site */
function getSpawnPos(){
  if(V5.questActive && V5.questActive.pos){
    const qp = V5.questActive.pos;
    const a = rand(0, Math.PI*2), r = rand(18, 34);
    return [qp[0] + Math.cos(a)*r, qp[1] + Math.sin(a)*r];
  }
  const m = V5.mission;
  if(!m) return null;
  const d = DISTRICTS[m.district] || DISTRICTS.downtown;
  for(let tries = 0; tries < 14; tries++){
    const a = sr(0, Math.PI*2), r = sr(24, Math.min(d.r, 55));
    const x = clamp(m.site[0] + Math.cos(a)*r, -205, 205);
    const z = clamp(m.site[1] + Math.sin(a)*r, -205, 205);
    const distP = Math.hypot(x - player.pos.x, z - player.pos.z);
    if(distP < 18) continue;
    let inside = false;
    for(const c of colliders){ if(x > c.minX-1 && x < c.maxX+1 && z > c.minZ-1 && z < c.maxZ+1 && c.h > 1){ inside = true; break; } }
    if(inside) continue;
    return [x, z];
  }
  return [m.site[0] + 30, m.site[1] + 10];
}

function spawnEnemy(type, fixedPos){
  const t = ETYPES[type];
  let x, z;
  if(fixedPos){ x = fixedPos[0]; z = fixedPos[1]; }
  else if(V5.mission){ const p = getSpawnPos(); x = p[0]; z = p[1]; }
  else {
    const side = (Math.random()*4)|0;
    if(side===0){ x = rand(-46,46); z = -46; }
    else if(side===1){ x = rand(-46,46); z = 46; }
    else if(side===2){ x = -46; z = rand(-46,46); }
    else { x = 46; z = rand(-46,46); }
  }
  const built = makeEnemy(type);
  built.wrap.position.set(x, 0, z);
  scene.add(built.wrap);
  const mixer = new THREE.AnimationMixer(built.wrap);
  const actions = {};
  for(const clip of models.enemy.animations){
    actions[clip.name] = mixer.clipAction(clip);
  }
  const e = {
    type, mesh: built.wrap, gun: built.gun, scale: t.scale,
    mixer, actions, current: '',
    hp: t.hp, maxHp: t.hp, dead: false, deadT: 0, hitT: 0,
    speed: rand(t.speed[0], t.speed[1]) + G.wave*0.08,
    shootCd: rand(t.cd[0], t.cd[1]),
    strafeDir: Math.random()<0.5 ? 1 : -1, strafeT: rand(1,3),
    dummy: false, muzzleT: 0,
    alert: false, squad: V5.squadId || 0,
    coverT: 0, state: 'combat', throwCd: 5,
    boss: !!t.boss, phase: 1, summonT: 12, chargeT: 0
  };
  if(t.boss){ V5.boss = e; }
  setAnim(e, 'Idle');
  enemies.push(e);
  G.enemiesAlive++;
  return e;
}

function alertSquad(pos){
  for(const e of enemies){
    if(e.dead || e.alert) continue;
    if(e.mesh.position.distanceTo(pos) < 42) e.alert = true;
  }
}

/* grenade of bomber enemies */
const eBombs = [];
function enemyThrowBomb(e){
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), M.bombLight);
  const from = e.mesh.position.clone().add(new THREE.Vector3(0, 1.5, 0));
  m.position.copy(from); scene.add(m);
  const to = player.pos.clone().add(new THREE.Vector3(rand(-2,2), 0, rand(-2,2)));
  const flight = 1.4;
  const vel = to.clone().sub(from).multiplyScalar(1/flight);
  vel.y += 0.5 * 22 * flight * 0.5;
  eBombs.push({ m, vel, fuse: flight });
  sfx(c=> tone(c, 300, 640, 0.2, 'sine', 0.14));
}
function updateEnemyBombs(dt){
  for(let i = eBombs.length-1; i >= 0; i--){
    const b = eBombs[i];
    b.vel.y -= 18*dt;
    b.m.position.addScaledVector(b.vel, dt);
    b.fuse -= dt;
    if(b.fuse <= 0 || b.m.position.y < 0.1){
      explodeAt(b.m.position.clone().setY(Math.max(0.1, b.m.position.y)));
      scene.remove(b.m);
      eBombs.splice(i,1);
    }
  }
}

function updateEnemies(dt){
  updateEnemyBombs(dt);
  for(let i = enemies.length-1; i >= 0; i--){
    const e = enemies[i];
    if(e.mixer) e.mixer.update(dt);
    if(e.dead){
      e.deadT += dt;
      if(e.deadT > 3.8){ scene.remove(e.mesh); enemies.splice(i,1); }
      continue;
    }
    if(e.hitT > 0){
      e.hitT -= dt;
      if(e.hitT > 0 && e.current !== 'Hit_A' && e.actions['Hit_A']){
        setAnim(e, 'Hit_A', 0.08);
        setTimeout(()=>{ if(!e.dead && e.hitT <= 0) e.current = ''; }, 320);
      }
      if(e.hitT <= 0 && e.current === 'Hit_A') e.current = '';
    }
    if(e.dummy){
      setAnim(e, 'Idle');
      e.mesh.rotation.y += dt*0.6;
      continue;
    }
    const T = ETYPES[e.type];
    const toP = player.pos.clone().sub(e.mesh.position);
    const dist = toP.length();
    toP.normalize();
    e.mesh.rotation.y = Math.atan2(toP.x, toP.z) + HERO_YAW;

    /* ---------- BOSS LOGIC ---------- */
    if(e.boss){
      updateBoss(e, dt, dist, toP, T);
      continue;
    }

    /* ---------- SNIPER ---------- */
    if(e.type === 'sniper'){
      let mvx = 0, mvz = 0;
      if(dist < 24){ mvx = -toP.x * e.speed; mvz = -toP.z * e.speed; setAnim(e, 'Running_A'); }
      else if(dist > 64){ mvx = toP.x * e.speed; mvz = toP.z * e.speed; setAnim(e, 'Running_A'); }
      else setAnim(e, 'Idle');
      const np = e.mesh.position.clone();
      np.x += mvx*dt; np.z += mvz*dt;
      collide(np, 0.5);
      e.mesh.position.x = np.x; e.mesh.position.z = np.z;
      e.shootCd -= dt;
      if(e.shootCd <= 0 && dist < 80 && !player.dead){
        e.shootCd = rand(2.6, 3.8);
        const eHead = e.mesh.position.clone().add(new THREE.Vector3(0,1.5*e.scale,0));
        const pHead = player.pos.clone().add(new THREE.Vector3(0,1.2,0));
        if(!segBlocked(eHead, pHead)){
          e.muzzleT = 0.08;
          setAnim(e, '2H_Ranged_Shooting', 0.12);
          sfx(c=> layeredShot(c, true));
          tracer(eHead, pHead, 0xff3030);
          if(Math.random() < 0.55) damagePlayer(rand(15, 21));
          else { const miss = pHead.clone().add(new THREE.Vector3(rand(-1,1), rand(-0.5,1), rand(-1,1))); tracer(eHead, miss, 0xff3030); }
          setTimeout(()=>{ if(!e.dead) e.current = ''; }, 600);
        }
      }
      if(e.gun && e.gun.userData.muzzle){ e.gun.userData.muzzle.visible = e.muzzleT > 0; e.muzzleT -= dt; }
      continue;
    }

    /* ---------- BOMBER ---------- */
    if(e.type === 'bomber'){
      let mvx = 0, mvz = 0;
      if(dist > 26){ mvx = toP.x * e.speed; mvz = toP.z * e.speed; setAnim(e, 'Running_A'); }
      else if(dist < 14){ mvx = -toP.x * e.speed*0.7; mvz = -toP.z * e.speed*0.7; setAnim(e, 'Walking_Backwards'); }
      else setAnim(e, 'Idle');
      const np = e.mesh.position.clone();
      np.x += mvx*dt; np.z += mvz*dt;
      collide(np, 0.5);
      e.mesh.position.x = np.x; e.mesh.position.z = np.z;
      e.throwCd -= dt;
      if(e.throwCd <= 0 && dist < 46 && !player.dead){
        e.throwCd = rand(5.5, 7.5);
        setAnim(e, '2H_Ranged_Shooting', 0.12);
        enemyThrowBomb(e);
      }
      if(e.gun && e.gun.userData.muzzle){ e.gun.userData.muzzle.visible = e.muzzleT > 0; e.muzzleT -= dt; }
      continue;
    }

    /* ---------- STANDARD (soldier/runner/heavy) ---------- */
    // squad alert
    if(!e.alert && dist < 26) e.alert = true;

    let mvx = 0, mvz = 0;
    const wantsCover = (e.hp < e.maxHp * 0.32 || (e.reloadingE && false));
    if(wantsCover && e.coverT <= 0){
      // find cover point: far side of nearest collider
      let bestC = null, bestD = 15;
      for(const c of colliders){
        if(c.h < 1.2) continue;
        const cx2 = (c.minX + c.maxX)/2, cz2 = (c.minZ + c.maxZ)/2;
        const d = Math.hypot(cx2 - e.mesh.position.x, cz2 - e.mesh.position.z);
        if(d < bestD){ bestD = d; bestC = c; }
      }
      if(bestC){
        const cx2 = (bestC.minX + bestC.maxX)/2, cz2 = (bestC.minZ + bestC.maxZ)/2;
        const dir = new THREE.Vector3(cx2 - player.pos.x, 0, cz2 - player.pos.z).normalize();
        e.coverTo = { x: cx2 + dir.x * ((bestC.maxX-bestC.minX)/2 + 1.4), z: cz2 + dir.z * ((bestC.maxZ-bestC.minZ)/2 + 1.4) };
        e.coverT = rand(2.5, 4);
      } else e.coverT = 1.5;
    }
    if(e.coverT > 0 && e.coverTo){
      e.coverT -= dt;
      const dx = e.coverTo.x - e.mesh.position.x, dz = e.coverTo.z - e.mesh.position.z;
      const d = Math.hypot(dx, dz);
      if(d > 0.8){
        mvx = dx/d * e.speed; mvz = dz/d * e.speed;
        setAnim(e, 'Running_A');
      } else setAnim(e, 'Idle');
    }
    else if(dist > (e.alert ? 14 : 20)){
      mvx = toP.x * e.speed; mvz = toP.z * e.speed;
      setAnim(e, 'Running_A');
    } else {
      e.strafeT -= dt;
      if(e.strafeT <= 0){ e.strafeDir *= -1; e.strafeT = rand(1.2, 2.8); }
      const px = -toP.z * e.strafeDir, pz = toP.x * e.strafeDir;
      mvx = px * e.speed * 0.55; mvz = pz * e.speed * 0.55;
      if(dist < 6){ mvx -= toP.x * e.speed * 0.5; mvz -= toP.z * e.speed * 0.5; }
      setAnim(e, dist > 9 ? 'Walking_A' : 'Idle');
    }
    const np = e.mesh.position.clone();
    np.x += mvx * dt; np.z += mvz * dt;
    collide(np, 0.5);
    e.mesh.position.x = np.x; e.mesh.position.z = np.z;

    e.shootCd -= dt;
    if(e.shootCd <= 0 && dist < 42 && !player.dead && e.alert){
      e.shootCd = rand(T.cd[0], T.cd[1]) - Math.min(G.wave*0.04, 0.45);
      const eHead = e.mesh.position.clone().add(new THREE.Vector3(0,1.5*e.scale,0));
      const pHead = V5.driving ? V5.driving.mesh.position.clone().add(new THREE.Vector3(0,1,0)) : player.pos.clone().add(new THREE.Vector3(0,1.2,0));
      if(!segBlocked(eHead, pHead)){
        S.eshot();
        e.muzzleT = 0.06;
        setAnim(e, '2H_Ranged_Shooting', 0.12);
        setTimeout(()=>{ if(!e.dead) e.current = ''; }, 600);
        const from = e.mesh.position.clone().add(new THREE.Vector3(0,1.4*e.scale,0));
        const hitChance = clamp(T.acc - dist*0.006 + G.wave*0.012, 0.12, 0.8);
        if(V5.driving && Math.random() < 0.45){
          // hit the car
          tracer(from, V5.driving.mesh.position.clone().add(new THREE.Vector3(0,1,0)), 0xff7766);
          damageVehicle(rand(T.dmg[0], T.dmg[1]) * 0.7);
        }
        else if(Math.random() < hitChance){
          tracer(from, pHead, 0xff7766);
          damagePlayer(rand(T.dmg[0], T.dmg[1]));
        } else {
          const miss = pHead.clone().add(new THREE.Vector3(rand(-2,2), rand(-1,1.5), rand(-2,2)));
          tracer(from, miss, 0xff7766);
        }
      }
    }
    if(e.gun && e.gun.userData.muzzle){
      const mz = e.gun.userData.muzzle;
      mz.visible = e.muzzleT > 0;
      e.muzzleT -= dt;
    }
  }
  updateBossBar();
}

/* ---------- boss brain ---------- */
function updateBoss(e, dt, dist, toP, T){
  const pHead = player.pos.clone().add(new THREE.Vector3(0,1.2,0));
  const frac = e.hp / e.maxHp;
  // phases
  if(e.type === 'althil'){
    if(frac < 0.3 && e.phase === 2) e.phase = 3;
    if(frac < 0.65 && e.phase === 1) e.phase = 2;
  } else {
    if(frac < 0.3 && e.phase === 1) e.phase = 2;
  }
  // summons
  e.summonT -= dt;
  if(e.summonT <= 0){
    e.summonT = e.phase >= 2 ? 9 : 13;
    const n = e.phase >= 2 ? 2 : 1;
    for(let i=0;i<n;i++){
      const a = rand(0, Math.PI*2);
      const s = spawnEnemy(e.phase >= 2 ? 'runner' : 'soldier',
        [e.mesh.position.x + Math.cos(a)*12, e.mesh.position.z + Math.sin(a)*12]);
      s.alert = true;
      bannerMini(isAr() ? 'الظل يستدعي الدعم!' : 'THE SHADOW CALLS REINFORCEMENTS!');
    }
    S.wave();
  }
  // movement
  let mvx = 0, mvz = 0;
  if(e.phase >= 3 && e.chargeT <= 0 && dist > 8){
    // charge at player
    mvx = toP.x * e.speed * 1.6; mvz = toP.z * e.speed * 1.6;
    setAnim(e, 'Running_B', 0.15);
  } else if(dist > (e.phase >= 2 ? 10 : 16)){
    mvx = toP.x * e.speed; mvz = toP.z * e.speed;
    setAnim(e, 'Running_A');
  } else {
    e.strafeT -= dt;
    if(e.strafeT <= 0){ e.strafeDir *= -1; e.strafeT = rand(1, 2.2); }
    mvx = -toP.z * e.strafeDir * e.speed * 0.6; mvz = toP.x * e.strafeDir * e.speed * 0.6;
    setAnim(e, 'Idle');
  }
  const np = e.mesh.position.clone();
  np.x += mvx * dt; np.z += mvz * dt;
  collide(np, 0.9);
  e.mesh.position.x = np.x; e.mesh.position.z = np.z;

  // fire — burst pattern
  e.shootCd -= dt;
  if(e.shootCd <= 0 && dist < 55 && !player.dead){
    const burst = e.phase >= 2 ? 4 : 3;
    e.shootCd = (e.phase >= 2 ? rand(1.6, 2.2) : rand(2.2, 3.0));
    for(let b=0; b<burst; b++){
      setTimeout(()=>{
        if(e.dead || G.state !== 'playing') return;
        const from = e.mesh.position.clone().add(new THREE.Vector3(0,1.6*e.scale,0));
        const pNow = player.pos.clone().add(new THREE.Vector3(0,1.2,0));
        if(!segBlocked(from, pNow)){
          sfx(c=> layeredShot(c, true));
          tracer(from, pNow.clone().add(new THREE.Vector3(rand(-1.2,1.2), rand(-0.5,0.8), rand(-1.2,1.2))), 0xffaa30);
          if(Math.random() < (e.phase >= 2 ? 0.5 : 0.4)) damagePlayer(rand(T.dmg[0], T.dmg[1]));
        }
      }, b * 160);
    }
    setAnim(e, '2H_Ranged_Shooting', 0.12);
    setTimeout(()=>{ if(!e.dead) e.current = ''; }, 700);
  }
  if(e.gun && e.gun.userData.muzzle){ e.gun.userData.muzzle.visible = e.muzzleT > 0; e.muzzleT -= dt; }
}

/* ================================================================ */
/* VEHICLES — drivable                                              */
/* ================================================================ */
function nearestUsableCar(){
  let best = null, bd = 4.2;
  for(const c of V5.usableCars){
    if(c.destroyed) continue;
    const d = c.mesh.position.distanceTo(player.pos);
    if(d < bd){ bd = d; best = c; }
  }
  return best;
}
function enterVehicle(car){
  if(V5.driving || player.dead || G.state !== 'playing') return;
  V5.driving = car;
  car.speed = 0;
  player.mesh.visible = false;
  fpvGun.visible = false;
  S.pickup();
  bannerMini((isAr() ? 'ركوب ' : 'DRIVING ') + car.type.toUpperCase() + (isAr() ? ' — W / S للتسريع، A / D للتوجيه' : ' — W/S throttle, A/D steer'));
  hint(isAr() ? 'W/S للتسريع · A/D للتوجيه · الخروج بزر F' : 'W/S accelerate · A/D steer · exit with F/ACT', 3800);
}
function exitVehicle(){
  const car = V5.driving;
  if(!car) return;
  V5.driving = null;
  const side = new THREE.Vector3(Math.cos(car.yaw), 0, -Math.sin(car.yaw));
  const np = car.mesh.position.clone().addScaledVector(side, 2.6);
  player.pos.set(np.x, groundHeightAt(np, 0.55) + 0.1, np.z);
  collide(player.pos, 0.55);
  player.moveVel.set(0,0,0);
  player.mesh.visible = true;
  $('speedo').style.display = 'none';
  S.click();
}
function damageVehicle(dmg){
  const car = V5.driving || V5.chaseCar || V5.escortCar;
  if(V5.driving){
    V5.driving.hp -= dmg;
    G.shake = Math.min(G.shake + 0.2, 0.8);
    if(V5.driving.hp <= 0){
      const p = V5.driving.mesh.position.clone();
      exitVehicle();
      explodeAt(p);
      damagePlayer(35);
    }
  }
}
function updateVehicle(dt){
  const car = V5.driving;
  if(!car) return;
  let thr = 0, steer = 0;
  if(keys['KeyW']) thr += 1;
  if(keys['KeyS']) thr -= 1;
  if(keys['KeyA']) steer += 1;
  if(keys['KeyD']) steer -= 1;
  if(joy.active){ thr = -joy.y; steer = joy.x; }
  const maxSpd = 26;
  if(thr > 0.1) car.speed += 13 * thr * dt;
  else if(thr < -0.1) car.speed += 11 * thr * dt;
  else car.speed *= Math.max(1 - 0.7*dt, 0);
  car.speed = clamp(car.speed, -9, maxSpd);
  const sf = clamp(Math.abs(car.speed) / 9, 0, 1);
  car.yaw += steer * 1.9 * sf * dt * (car.speed >= 0 ? 1 : -1);
  const fx = Math.sin(car.yaw), fz = Math.cos(car.yaw);
  const prevX = car.mesh.position.x, prevZ = car.mesh.position.z;
  car.mesh.position.x += fx * car.speed * dt;
  car.mesh.position.z += fz * car.speed * dt;
  car.mesh.rotation.y = car.yaw;
  // wall collision
  const cp = car.mesh.position.clone();
  collide(cp, 1.7);
  if(Math.abs(cp.x - car.mesh.position.x) > 0.01 || Math.abs(cp.z - car.mesh.position.z) > 0.01){
    if(Math.abs(car.speed) > 10){ damageVehicle(14); G.shake = Math.min(G.shake + 0.5, 1); sfx(c=> noiseBurst(c, 0.2, 0.4, 500)); }
    car.speed *= -0.25;
  }
  car.mesh.position.x = cp.x; car.mesh.position.z = cp.z;
  // roadkill
  if(Math.abs(car.speed) > 5.5){
    for(const e of enemies){
      if(e.dead) continue;
      if(e.mesh.position.distanceTo(car.mesh.position) < 2.4){
        e.hp = 0; killEnemy(e, false);
        G.score += 40;
        G.shake = Math.min(G.shake + 0.3, 1);
        bannerMini(isAr() ? 'دهس!' : 'ROADKILL!');
      }
    }
  }
  // carry player along
  player.pos.set(car.mesh.position.x, 0.4, car.mesh.position.z);
  player.moveVel.set(0,0,0);
  // speedo
  $('speedo').style.display = 'block';
  $('speedo').innerHTML = Math.abs(Math.round(car.speed * 3.6 * 1.6)) + ' <small>km/h</small>';
  // engine sound
  V5.engineT = (V5.engineT || 0) - dt;
  if(V5.engineT <= 0 && Math.abs(car.speed) > 1){
    V5.engineT = Math.max(0.09, 0.5 - Math.abs(car.speed)/30);
    sfx(c=> tone(c, 70 + Math.abs(car.speed)*4, 60 + Math.abs(car.speed)*4, 0.12, 'sawtooth', 0.05));
  }
}
function updateDriveCamera(dt){
  const car = V5.driving;
  const sy = Math.sin(car.yaw), cy = Math.cos(car.yaw);
  const back = new THREE.Vector3(-sy, 0, -cy);
  const desired = car.mesh.position.clone().addScaledVector(back, 8.5).add(new THREE.Vector3(0, 4.2, 0));
  if(desired.y < 1) desired.y = 1;
  const k = 1 - Math.pow(0.001, dt);
  camera.position.lerp(desired, k);
  camera.fov = lerp(camera.fov, clamp(70 + Math.abs(car.speed)*0.5, 70, 85), 1 - Math.pow(0.01, dt));
  camera.updateProjectionMatrix();
  const lookP = car.mesh.position.clone().add(new THREE.Vector3(0, 1.5, 0)).addScaledVector(new THREE.Vector3(sy,0,cy), 6);
  camera.lookAt(lookP);
  if(G.shake > 0.001){ G.shake *= Math.pow(0.001, dt); camera.position.y += rand(-1,1)*G.shake*0.2; }
}

/* ================================================================ */
/* PLAYER DAMAGE / DEATH (vehicle-aware)                            */
/* ================================================================ */
function damagePlayer(dmg){
  if(player.dead) return;
  if(V5.driving){ damageVehicle(dmg * 0.6); return; }
  player.hp -= dmg;
  S.hurt();
  G.shake = Math.min(G.shake + 0.25, 0.9);
  const v = $('vignette');
  v.style.opacity = 0.9;
  clearTimeout(G.vt);
  G.vt = setTimeout(()=>{ v.style.opacity = 0; }, 240);
  if(player.hp <= 0){ player.hp = 0; player.dead = true; playerDeath(); gameOver('death'); }
}
function playerDeath(){
  const a = player.actions['Death_A'];
  if(a){
    a.reset(); a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true;
    a.fadeIn(0.12).play();
    if(player.actions[player.current] && player.current !== 'Death_A') player.actions[player.current].fadeOut(0.12);
    player.current = 'Death_A';
  }
  if(V5.driving) exitVehicle();
}
