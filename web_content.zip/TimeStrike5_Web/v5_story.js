/* =====================================================================
   TIME STRIKE 5 — RAAD: OPEN CITY
   Story, campaign, side quests, dialogue — full rewrite (AR/EN)
   ===================================================================== */
"use strict";

/* ------------------------------------------------------------------ */
/* OPENING FILM — played on first launch (or from menu)              */
/* ------------------------------------------------------------------ */
const STORY_OPENING = [
  { en:"NOUR CITY. Population four million. Built on a river, powered by a dream.",
    ar:"مدينة النور. أربعة ملايين نسمة. بُنيت على نهر، وتغذّيها أحلام أهلها." },
  { en:"Three years ago, the Liberation War ended here — on one terrible night. The sergeant who saved the plaza survived. His brother did not.",
    ar:"قبل ثلاث سنوات، انتهت حرب التحرير هنا — في ليلة رهيبة واحدة. الرقيب الذي أنقذ الساحة نجا. أخوه لم ينجُ." },
  { en:"Tonight the dream burns again. At 3:47 AM every district goes dark at once. It is not a blackout. It is a message.",
    ar:"الليلة يشتعل الحلم من جديد. في الثالثة وسبعٍ وأربعين دقيقة فجراً، تنطفئ كل الأحياء دفعة واحدة. ليست انقطاع كهرباء… بل رسالة." },
  { en:"They call themselves the CRIMSON SHADOW. They have planted bombs across the city — and they are waiting for an answer before sunrise.",
    ar:"يسمّون أنفسهم «الظل الأحمر». زرعوا قنابل في أنحاء المدينة — وينتظرون رداً قبل شروق الشمس." },
  { en:"The police withdraw. The army is six hours away. One man turns off his radio, picks up his rifle, and walks into the dark.",
    ar:"الشرطة تنسحب. الجيش على بعد ست ساعات. رجل واحد يطفئ اللاسلكي، يرفع بندقيته، ويمشي نحو الظلام." },
  { en:"SERGEANT RAAD. Bomb technician. Survivor. This time, he is not defusing to save a district. He is coming for ALL of them.",
    ar:"الرقيب رعد. خبير متفجرات. ناجٍ. هذه المرة لا ينزع فتيلاً لينقذ حيّاً… بل قادمٌ ليأخذهم جميعاً." }
];

/* ------------------------------------------------------------------ */
/* CHAPTERS — 15 main missions across 5 chapters                      */
/* Each mission: district, site coords, enemy mix, radio, subtitles.  */
/* ------------------------------------------------------------------ */
const CAMPAIGN = [
  /* ===== CHAPTER 1 — THE LONG NIGHT | الليلة الطويلة ===== */
  { wave:1, ch:1, district:'downtown', site:[0,-26],
    mission:{ ar:'الساحة المركزية — القنبلة الأولى', en:'Civic Plaza — The First Bomb' },
    radio:[
      { t:0,  ar:'رعد، انتبه. كل الأحياء انطفأت. التقاطع الأول عند الساحة المركزية — الإشارة مشتعلة.', en:'Raad, listen carefully. Every district just went dark. First ping is at Civic Plaza — the signal is live.' },
      { t:12, ar:'الظل الأحمر يبثّ على تردداتنا. يقولون إن لديهم أكثر من عشرين قنبلة. أثبت العكس.', en:'The Crimson Shadow is broadcasting on our frequencies. They claim twenty-plus devices. Prove them wrong.' }
    ] },
  { wave:2, ch:1, district:'market', site:[0,-138],
    mission:{ ar:'السوق القديم — اقتصاص المدينة', en:'The Old Market — Cutting the City' },
    radio:[
      { t:0, ar:'السوق القديم. هنا كان مقرّهم قبل سنتين — يعرفون كل زاوية. وأنت كذلك.', en:'The Old Market. Their HQ two years ago — they know every corner. So do you.' },
      { t:14, ar:'احترس من أسطح المحلات. أفرادهم يحبون الارتفاعات.', en:'Watch the shop rooftops. Their people love the high ground.' }
    ] },
  { wave:3, ch:1, district:'industrial', site:[138,14],
    mission:{ ar:'الحي الصناعي — مصنع الموت', en:'Industrial District — The Death Factory' },
    radio:[
      { t:0, ar:'الحي الصناعي. المصدر نفسه: صناديق متفجرات تحمل شعار الجيش. شيء لا يعجبني هنا يا رعد.', en:'Industrial district. The source itself: crates of military-grade explosive, army stamps on them. Something about this smells wrong, Raad.' },
      { t:16, ar:'قواتي تقول إن قنبلة هناك تُبنى بأسلوب هندسي عسكري دقيق. هذه ليست عصابة عادية.', en:'My analysts say the device is built to military engineering spec. This is no ordinary gang.' }
    ],
    afterStory:[
      { en:'That night, Raad learns three things: the detonators are army-issue, the builder is a professional, and someone on the inside signed them out of the depot.',
       ar:'في تلك الليلة يتعلم رعد ثلاث حقائق: الصواعق عسكرية الصنع، صانعها محترف، وأحدهم من الداخل وقّع على إخراجها من المستودع.' }
    ] },

  /* ===== CHAPTER 2 — GHOSTS | الأشباح ===== */
  { wave:4, ch:2, district:'residential', site:[-138,26],
    mission:{ ar:'الحي السكني — حيّ تحت النار', en:'Residential District — A Neighborhood Under Fire' },
    radio:[
      { t:0, ar:'الحي السكني ما زال فيه مدنيون. القصف مستمر. أخرج الناس ثم عالج القنبلة.', en:'Civilians are still trapped in the residential blocks. Shelling continues. Get the people out, then deal with the device.' },
      { t:15, ar:'إن سمعت صراخاً، اتبعه. بعضهم لا يملك إلا صوته.', en:'If you hear screaming, follow it. Some of them have nothing left but their voice.' }
    ] },
  { wave:5, ch:2, district:'hospital', site:[-38,-70],
    mission:{ ar:'المستشفى المركزي — الدكتورة لينا', en:'Central Hospital — Dr. Lina' },
    choice:{ // offered on arrival
      text:{ ar:'المستشفى يتعرض لهجوم بينما القنبلة تدنو من الانفجار. بأيهما تبدأ؟',
             en:'The hospital is under attack while the bomb ticks down. Which do you take first?' },
      a:{ ar:'أنقذ الكوادر الطبية أولاً (+سمعة)', en:'Save the medical staff first (+Reputation)' },
      b:{ ar:'انزع القنبلة فوراً (+نقاط)', en:'Defuse the bomb immediately (+Score)' } },
    radio:[
      { t:0, ar:'الدكتورة لينا ملوح، رئيسة الطوارئ، تحتجز مع فريقها في الجناح الشرقي. إن سقطت… سقطت المدينة معها.', en:'Dr. Lina Malouf, chief of emergency medicine, is pinned down with her team in the east wing. If she falls, the city falls with her.' },
      { t:16, ar:'لينا قالت لي شيئاً غريباً قبل قليل: «من يصنع هذه القنابل يعرف تشريح المدينة كطبيبها».', en:'Lina told me something strange: "Whoever builds these bombs knows this city\'s anatomy like a surgeon."' }
    ] },
  { wave:6, ch:2, district:'bridge', site:[0,66],
    mission:{ ar:'جسر النهر — ذكرى سامر', en:'The River Bridge — Samer\'s Memory' },
    radio:[
      { t:0, ar:'جسر النهر. هنا استشهد سامر وهو يحمي مئتي مدني. القنبلة مزروعة عند قاعدة الجسر.', en:'The river bridge. This is where Samer fell protecting two hundred civilians. The device is planted at the bridge footing.' },
      { t:14, ar:'رعد… خذ نفساً. أنت لست مضطراً لتكون حجراً كل ليلة.', en:'Raad... breathe. You don\'t have to be stone every single night.' }
    ],
    beforeStory:[
      { en:'Raad stops at the foot of the bridge. Three years, and he has never come back here. The wind carries the river\'s smell, exactly like that night. «I\'m here, brother. Almost done.»',
        ar:'يتوقف رعد عند قاعدة الجسر. ثلاث سنوات ولم يعد إلى هنا. الريح تحمل رائحة النهر، تماماً كتلك الليلة. «وصلتُ يا سامر. أوشكت على النهاية.»' }
    ],
    afterStory:[
      { en:'On the bridge railing, someone has left a folded note weighted with a shell casing: "YOU ARE CLOSE TO THE TRUTH. SO ARE THEY. — G." A ghost is watching over Raad.',
        ar:'على درابزين الجسر، ترك أحدهم ورقة مطوية مقيّدة بظرف رصاصة: «أنت قريب من الحقيقة. وهم قريبون منك. — ش». شبحٌ يراقب رعد.' }
    ] },

  /* ===== CHAPTER 3 — WINGS | الأجنحة ===== */
  { wave:7, ch:3, district:'ruins', site:[-140,-140],
    mission:{ ar:'الأنقاض الشمالية — ما دفنته الحرب', en:'The Northern Ruins — What the War Buried' },
    radio:[
      { t:0, ar:'الأنقاض. لا كهرباء، لا شرطة، لا شهود. مكان مثالي لإخفاء شيء.', en:'The ruins. No power, no police, no witnesses. A perfect place to hide something.' },
      { t:15, ar:'الكشّاف يقول إن ثمة خزانة معدنية قديمة تحت الأنقاض تحمل اسم «س. سامر». غريبة جداً.', en:'Scouts report an old metal locker under the rubble marked "S. SAMER". Very strange.' }
    ],
    afterStory:[
      { en:'Inside Samer\'s locker: his old notebook, coded, and a photograph of his unit. On its back, circled in red — the face of the man who ordered the strike that killed him. The photo is scorched. The name is torn away. But Raad remembers that face. It trained him.',
        ar:'داخل خزانة سامر: دفتره القديم مشفّراً، وصورة لوحدته العسكرية. على ظهرها، بدائرة حمراء، وجه الرجل الذي أمر بالضربة التي قتلته. الصورة محترقة الحواف والاسم ممزق… لكن رعد يتذكر ذلك الوجه. ذلك الوجه درّبه.' }
    ] },
  { wave:8, ch:3, district:'airport', site:[10,150],
    mission:{ ar:'المطار — أرض الحظر بلا حَرَس', en:'The Airport — No-Fly Zone, No Guards' },
    radio:[
      { t:0, ar:'المطار مغلق منذ الحرب، لكن الرادار رصد طائرة هبطت هناك فجراً. اذهب واعرف لمن.', en:'The airport has been closed since the war, but radar caught a plane landing before dawn. Go find out whose.' },
      { t:16, ar:'لو وجدت شحنات… لا تلمسها. صوّر كل شيء. أريد أسماء.', en:'If you find cargo, don\'t touch it. Photograph everything. I want names.' }
    ] },
  { wave:9, ch:3, district:'docks', site:[130,140],
    mission:{ ar:'الميناء — الحاويات الحمراء', en:'The Port — The Red Containers' },
    radio:[
      { t:0, ar:'الميناء. ثلاث حاويات حمراء نزلت من تلك الطائرة. الضريبة: نصف مدينة.', en:'The port. Three red containers came off that plane. The toll: half a city.' },
      { t:14, ar:'مصادر «الشبح» تقول إن قائد الحماية هناك يُلقّب بـ«العقيد». لا يُخطئ.', en:'The Ghost\'s sources say the security chief there goes by "The Colonel". He does not miss.' }
    ],
    afterStory:[
      { en:'The container manifest is a list of the city\'s own police frequencies, patrol routes, and — a name circled again and again. Before Raad can read it, the page is burned by a tracer round. Someone knows exactly how close he is.',
        ar:'قائمة الشحن تتضمن ترددات الشرطة نفسها ومسارات الدوريات، واسماً محاطاً بالدوائر مراراً. قبل أن يقرأه رعد، تحرق رصاصة الورقة. أحدهم يعرف تماماً كم أصبح قريباً.' }
    ] },

  /* ===== CHAPTER 4 — THE TRAITOR | الخائن ===== */
  { wave:10, ch:4, district:'highway', site:[120,70],
    mission:{ ar:'الطريق السريع — قافلة الظل', en:'The Highway — Shadow Convoy' },
    radio:[
      { t:0, ar:'قافلة من ست سيارات تغادر الميناء نحو الشرق. اعترضها قبل نهاية الحلقة!', en:'A convoy of six vehicles is leaving the port heading east. Intercept them before the ring closes!' },
      { t:15, ar:'خذ أي سيارة تصلها واطرقهم من الخلف. لا تدعهم يخرجون من المدينة.', en:'Grab any car you can find and hit them from behind. Do not let them leave the city.' }
    ] },
  { wave:11, ch:4, district:'base2', site:[-86,96],
    mission:{ ar:'القاعدة الغربية — مخالب الظل', en:'Western Base — Claws of the Shadow' },
    radio:[
      { t:0, ar:'حدّدنا قاعدة لوجستية غربية. مولدات، أسلحة، أسرى من رجالنا. نظّفها.', en:'We\'ve located a logistics base to the west. Generators, weapons, and some of our people held there. Clear it.' },
      { t:16, ar:'وأياً تكن الأوامر التي تصلك بعد الآن… تفقّد هوية مرسلها.', en:'And whatever orders reach you from now on... verify who sent them.' }
    ] },
  { wave:12, ch:4, district:'tower', site:[64,-64],
    mission:{ ar:'البرج الرئيسي — قائد الظل', en:'The Main Tower — The Shadow Commander' },
    boss:'commander',
    radio:[
      { t:0, ar:'البرج. عقل الظل الأحمر بالكامل. كل الخيوط تنتهي في قمة تلك السلالم.', en:'The tower. The entire mind of the Crimson Shadow. Every thread ends at the top of those stairs.' },
      { t:14, ar:'قائدهم هناك شخصياً. مدرّع، مسلّح، وسبق أن قتل رجالاً أفضل منا. لا تتهاون.', en:'Their commander is there in person. Armored, armed, and he has killed better men than us. Do not hold back.' }
    ],
    beforeStory:[
      { en:'Haddad\'s voice is almost a whisper: "Raad — if you take him alive, we learn everything. If you take him dead... we learn it from his files. Either way — end this."',
        ar:'صوت حداد يكاد يكون همساً: «رعد — إن أمسكته حياً عرفنا كل شيء، وإن أمسكته ميتاً عرفناها من ملفاته. على أي حال… أنهِ الأمر.»' }
    ],
    afterStory:[
      { en:'Bleeding out against his own war table, the Commander laughs. "You still think this is a gang? Ask your teacher who taught the Shadow to build a fuse." Raad\'s blood runs cold. He knows exactly one man who taught demolitions. Major Karim.',
        ar:'وهو ينزف أمام طاولته العسكرية، يضحك القائد: «ما زلت تظنها عصابة؟ اسأل أستاذك من علّم الظل صناعة الفتيل.» يتجمّد دم رعد. يعرف رجلاً واحداً فقط كان يعلّم الهندسة المتفجرة: الرائد كريم.' }
    ] },

  /* ===== CHAPTER 5 — DAWN | الفجر ===== */
  { wave:13, ch:5, district:'market', site:[20,-150],
    mission:{ ar:'السوق مجدداً — حصار كريم', en:'The Market Again — Karim\'s Siege' },
    radio:[
      { t:0, ar:'كريم أعلن نفسه «الوصي على المدينة». أتباعه يحتلون السوق ويعدمون من يعترض.', en:'Karim declared himself "the city\'s custodian". His followers occupy the market and execute anyone who resists.' },
      { t:15, ar:'رعد… لا تذهب بحثاً عن انتقام. اذهب بحثاً عن الجواب. الجواب عند كريم.', en:'Raad... do not go looking for revenge. Go looking for the answer. The answer is with Karim.' }
    ] },
  { wave:14, ch:5, district:'downtown', site:[-30,20],
    mission:{ ar:'المدينة المحررة — الاصطدام الأخير', en:'The Liberated City — Last Collision' },
    radio:[
      { t:0, ar:'الناس خرجوا للشوارع، يا رعد. يحملون السلالم والصحون… يقاتلون معك. الكل ينتظر النهاية.', en:'The people are out in the streets, Raad. Ladders, pans... they are fighting with you. Everyone is waiting for the end.' },
      { t:16, ar:'كريم نفسه شوهد وسط الحشد. لا تطلق النار بين المدنيين. خذه عن قرب.', en:'Karim himself was spotted in the crowd. No gunfire near civilians. Take him up close.' }
    ],
    afterStory:[
      { en:'Karim does not deny it. "The Liberation War made corpses of us and medals for the men who sold it. Samer died for their ledger. The Mother Bomb balances the books." Raad\'s hands shake — not from fear. From choice.',
        ar:'كريم لا ينكر: «حرب التحرير جعلتنا جثثاً ووسامات لمن باعوها. سامر مات من أجل دفتر حساباتهم. القنبلة الأم تسوّي الحساب.» ترتجف يد رعد — ليس خوفاً… بل حيرةً بين خيارين.' }
    ] },
  { wave:15, ch:5, district:'undercity', site:[0,6],
    mission:{ ar:'تحت المدينة — القنبلة الأم', en:'Under the City — The Mother Bomb' },
    boss:'althil',
    radio:[
      { t:0, ar:'وجدناها. نفق الصيانة تحت الساحة المركزية. القنبلة الأم وخالد الظل كلاهما هناك.', en:'We found it. The maintenance tunnel under Civic Plaza. The Mother Bomb — and Khalid Al-Thil — are both down there.' },
      { t:14, ar:'لا توجد خطة، رعد. أنت الخطة. أنهِ ما بدأته تلك الليلة قبل ثلاث سنوات.', en:'There is no plan, Raad. You are the plan. Finish what that night, three years ago, started.' }
    ] }
];

/* Interlude story between chapters (shown after wave X completes) */
const CHAPTER_INTROS = {
  2:[
    { en:'CHAPTER 2 — GHOSTS. The city\'s last lights. A hospital under siege. A river that remembers. And a plane on the horizon that answers to no flag.',
      ar:'الفصل الثاني — الأشباح. آخر أنوار المدينة. مستشفى تحت الحصار. نهرٌ يتذكّر. وطائرة في الأفق لا تتبع علماً.' }
  ],
  3:[
    { en:'CHAPTER 3 — WINGS. Dr. Lina\'s evidence points to an army traitor. The trail now runs through ruins, runways and red containers.',
      ar:'الفصل الثالث — الأجنحة. أدلة الدكتورة لينا تشير إلى خائن داخل الجيش. الدرب يمرّ الآن عبر الأنقاض والمدرّج والحاويات الحمراء.' }
  ],
  4:[
    { en:'CHAPTER 4 — THE TRAITOR. The Shadow is not a gang; it is a mutiny. And its quartermaster wears an army uniform.',
      ar:'الفصل الرابع — الخائن. الظل ليس عصابة؛ إنه تمرد. ومديرُ لوازمه يرتدي بزّة عسكرية.' }
  ],
  5:[
    { en:'CHAPTER 5 — DAWN. Two hours to sunrise. The Mother Bomb is armed under the city\'s heart. Everything Raad has left — he spends tonight.',
      ar:'الفصل الخامس — الفجر. ساعتان على الشروق. القنبلة الأم مُسلّحة تحت قلب المدينة. كل ما تبقّى لرعد… سينفقه الليلة.' }
  ]
};

/* Plane cinematic — the plane arrives between chapters */
const PLANE_SCENES = {
  2:{ officer:'ghost', dialogue:[
      { ar:'أرض المدينة سيئة الليلة، أيها الرقيب. اسمي لا يهم — نادني «الشبح».', en:'Ugly ground tonight, sergeant. My name doesn\'t matter — call me "the Ghost".' },
      { ar:'أنت تلاحق قنابل. أنا ألاحق من يبيعها. أظن أننا سنعمل معاً.', en:'You hunt bombs. I hunt the men who sell them. I think we\'ll be working together.' },
      { ar:'مستودع الأسلحة في الحي الصناعي… خرجت منه شحنات بلا حسيب. ابدأ من هناك.', en:'The weapons depot in the industrial district... shipments left it with no record. Start there.' },
      { ar:'أنا لا أهبط في مدن تحتضر عادةً. لكن لهذه المدينة ديناً عندي.', en:'I don\'t usually land in dying cities. But I owe this one a debt.' }
    ], dest:{ ar:'إلى الحي الصناعي', en:'To the Industrial District' } },
  3:{ officer:'ghost', dialogue:[
      { ar:'صباح الخير يا رعد. نمتَ جيداً؟ المدينة لم تنم قط.', en:'Good morning, Raad. Sleep well? The city didn\'t.' },
      { ar:'ملف المستشفى حقيقي: الصواعق عسكرية، والتصميم… تصميم مدرّب واحد بعينه.', en:'The hospital file is real: military detonators, and the design... the signature of one specific instructor.' },
      { ar:'قبل أن تظن بي الظنون: نعم، عملت معهم سابقاً. ولهذا أعرف طريقهم إلى المطار.', en:'Before you judge me: yes, I worked for them once. That is exactly why I know their road to the airport.' },
      { ar:'الطائرة التي هبطت فجراً حملت أكثر من متفجرات. حملت اسم خائنك.', en:'The plane that landed at dawn carried more than explosives. It carried the name of your traitor.' }
    ], dest:{ ar:'إلى الأنقاض الشمالية', en:'To the Northern Ruins' } },
  4:{ officer:'lina', dialogue:[
      { ar:'أنا الدكتورة لينا. قبل أن تسأل: نعم، أنا التي أرسلت الملف الطبي لقيادتك.', en:'I\'m Dr. Lina. Before you ask: yes, I am the one who leaked the medical file to your command.' },
      { ar:'القائد الذي أسقطته الليلة الماضية… مذكراته تشير إلى «الوصي». رجل من داخل المؤسسة.', en:'The commander you brought down last night... his journals mention "the Custodian". A man from inside the institution.' },
      { ar:'رعد… كنتَ تلميذاً له، أليس كذلك؟ لهذا لن يراك قادماً.', en:'Raad... you were his student once, weren\'t you? That\'s why he will never see you coming.' },
      { ar:'المدينة تنزف لكنها تتنفس. لا تتأخر.', en:'The city is bleeding, but it is breathing. Don\'t be late.' }
    ], dest:{ ar:'إلى الطريق السريع', en:'To the Highway' } },
  5:{ officer:'ghost', dialogue:[
      { ar:'ساعة واحدة يا رعد. أنا سأحلق فوق المدينة حتى تشرق الشمس أو تسقط.', en:'One hour, Raad. I\'ll circle over the city until the sun rises — or falls.' },
      { ar:'كل من بقي منهم تحت الأرض. بذور الظل كلها في سلة واحدة أخيرة.', en:'Everyone they had left is underground now. All the Shadow\'s seeds in one final basket.' },
      { ar:'إن سمعت انفجاراً قبل أن تنزع الفتيل… فاعلم أنني حاولت إسقاطهم بنفسي. حظاً موفقاً أيها الرقيب.', en:'If you hear an explosion before you cut that wire, know that I tried to take them down myself. Good luck, sergeant.' }
    ], dest:{ ar:'إلى تحت المدينة', en:'To Under the City' } }
};

/* ------------------------------------------------------------------ */
/* ENDINGS                                                             */
/* ------------------------------------------------------------------ */
const STORY_ENDINGS = {
  hero:[
    { en:'4.1 seconds. The Mother Bomb dies silent. Above ground, dawn breaks — and street by street, Nour City comes back to life.',
      ar:'٤.١ ثانية. تموت القنبلة الأم صامتة. فوق الأرض، يبزغ الفجر — وشارعاً شارعاً، تعود مدينة النور إلى الحياة.' },
    { en:'They come out of their homes by the thousands. Someone starts clapping, then the whole street, then the whole city. "RAAD! RAAD!" Children run beside him. A woman puts a flower in his rifle\'s barrel.',
      ar:'يخرجون من بيوتهم بالآلاف. أحدهم يصفّق، ثم الشارع كله، ثم المدينة كلها. «رعد! رعد!» أطفال يركضون بجانبه، وامرأة تضع زهرة في ماسورة بندقيته.' },
    { en:'The Ghost\'s plane banks over the plaza, wings dipping in salute, and disappears into the sunrise. Samer\'s notebook burns clean in a soldier\'s fire. The debt is paid.',
      ar:'طائرة الشبح تميل فوق الساحة تحيةً، وتختفي في قرص الشمس. دفتر سامر يحترق نظيفاً في نار الجنود. الدين سُدّد.' }
  ],
  neutral:[
    { en:'4.1 seconds. The Mother Bomb dies silent. Dawn finds Raad sitting alone on the plaza steps, rifle across his knees, too tired to feel anything.',
      ar:'٤.١ ثانية. تموت القنبلة الأم صامتة. يجد الفجر رعد جالساً وحيداً على درجات الساحة، بندقيته على ركبتيه، أشدّ تعباً من أن يشعر بأي شيء.' },
    { en:'The lights come back on across the city, district by district. Somewhere, people cheer. Raad checks his magazine, out of habit, and finally allows himself to close his eyes.',
      ar:'تعود الأنوار في أنحاء المدينة حيّاً حيّاً. في مكانٍ ما، يهتف الناس. يتفقد رعد مخزنه بدافع العادة، ثم يسمح لنفسه أخيراً بأن يغمض عينيه.' }
  ],
  ghost:[
    { en:'4.1 seconds. The Mother Bomb dies silent. Raad walks out of the tunnel before the sun fully rises, past the crowds, ignoring every hand offered to him.',
      ar:'٤.١ ثانية. تموت القنبلة الأم صامتة. يخرج رعد من النفق قبل اكتمال الشروق، متجاوزاً الحشود، متجاهلاً كل يدٍ ممدودة إليه.' },
    { en:'The city calls him a hero anyway. It needs one. He lets it. But every year, on this night, a flame appears at the river bridge — and no one ever sees who lights it.',
      ar:'المدينة تسمّيه بطلاً رغم ذلك. هي تحتاج بطلاً. وهو يتركها تفعل. لكن كل عام، في مثل هذه الليلة، تظهر نارٌ صغيرة عند جسر النهر — ولم يرَ أحدٌ قط من يوقدُها.' }
  ]
};
const STORY_DEFEAT = {
  ar:'انتهى الوقت… دويٌ واحد، وفقدت مدينة النور قلبها. لكن ما دام في رعد نفسٌ متبقٍ، فهناك محاولة أخرى. حاول من جديد.',
  en:'Time ran out... one blast, and Nour City lost its heart. But while Raad still breathes, there is another attempt. Try again.'
};

/* ------------------------------------------------------------------ */
/* SIDE QUESTS                                                         */
/* ------------------------------------------------------------------ */
const SIDE_QUESTS = [
  { id:'sq1', type:'rescue', district:'market', pos:[-6,-146], count:3, guards:4,
    title:{ ar:'إنقاذ أسرى السوق', en:'Market Hostages' },
    desc:{ ar:'الظل الأحمر يحتجز ثلاثة مدنيين في السوق القديم. اقتل الحراس وأوصلهم إلى بر الأمان.',
           en:'The Crimson Shadow holds three civilians in the Old Market. Eliminate the guards and get them to safety.' },
    reward:{ xp:160, rep:2, score:400 } },
  { id:'sq2', type:'rescue', district:'ruins', pos:[-128,-152], count:4, guards:5, nightBonus:true,
    title:{ ar:'عائلة تحت الأنقاض', en:'A Family in the Ruins' },
    desc:{ ar:'عائلة كاملة مختبئة في الأنقاض الشمالية تحرسها فرقة إعدام. أنقذهم قبل فوات الأوان.',
           en:'An entire family hides in the northern ruins guarded by an execution squad. Save them before it is too late.' },
    reward:{ xp:200, rep:2, score:500 } },
  { id:'sq3', type:'deliver', district:'hospital', pos:[-38,-70], time:100,
    title:{ ar:'شحنة دواء عاجلة', en:'Urgent Medical Run' },
    desc:{ ar:'خذ صندوق الدواء من المستشفى وأوصله إلى العيادة في الحي السكني خلال الوقت المحدد. سيارة؟ فكرة ممتازة.',
           en:'Pick up the medical crate at the hospital and deliver it to the clinic in the residential district in time. A car? Excellent idea.' },
    reward:{ xp:130, rep:1, score:300 } },
  { id:'sq4', type:'race', district:'downtown', pos:[8,-6], time:110, checkpoints:8,
    title:{ ar:'سباق النور الليلي', en:'The Nour Night Race' },
    desc:{ ar:'ثمانية نقاط تفتيش عبر المدينة. جاهز؟ العدّ يبدأ فور الموافقة.',
           en:'Eight checkpoints across the city. Ready? The clock starts the moment you accept.' },
    reward:{ xp:220, score:800 } },
  { id:'sq5', type:'target', district:'industrial', pos:[130,6],
    title:{ ar:'تصفية «العقيد»', en:'Eliminate "The Colonel"' },
    desc:{ ar:'قناصٌ يلقّب بالعقيد يوجّه نيران الظل من الحي الصناعي. أنهِ مسيرته.',
           en:'A marksman known as "The Colonel" directs the Shadow\'s fire from the industrial district. End his career.' },
    reward:{ xp:180, rep:1, score:500 } },
  { id:'sq6', type:'collect', district:'city', count:5,
    title:{ ar:'ملفات الاستخبارات', en:'Intel Files' },
    desc:{ ar:'خمسة حقائب ملفات متناثرة في أنحاء المدينة. اجمعها كلها لتكشف خيوط المؤامرة.',
           en:'Five intel cases are scattered across the city. Collect them all to unravel the plot.' },
    reward:{ xp:200, rep:1, score:600 } },
  { id:'sq7', type:'defend', district:'downtown', pos:[0,-18], time:60,
    title:{ ar:'الدفاع عن لوحة المهام', en:'Defend the Board' },
    desc:{ ar:'المدنيون يتطوعون عند لوحة المهام في الساحة. امنحهم دقيقة واحدة تحت الحماية.',
           en:'Civilians are volunteering at the plaza mission board. Give them one minute under your protection.' },
    reward:{ xp:150, rep:2, score:400 } },
  { id:'sq8', type:'escort', district:'hospital', pos:[-38,-70],
    title:{ ar:'مرافقة إسعاف لينا', en:'Escort Lina\'s Ambulance' },
    desc:{ ar:'إسعاف الدكتورة لينا يقلّ معدات حساسة إلى المطار. الحراسة من هجومين محتملين.',
           en:'Dr. Lina\'s ambulance carries sensitive equipment to the airport. Guard it through two ambush zones.' },
    reward:{ xp:260, rep:2, score:700 } },
  { id:'sq9', type:'clearbase', district:'base1', pos:[92,-92],
    title:{ ar:'تطهير القاعدة الشمالية الشرقية', en:'Clear the Northeast Base' },
    desc:{ ar:'قاعدة إمداد كاملة للظل الأحمر. لا تترك فيها حجراً على حجر.',
           en:'A full Crimson Shadow supply base. Leave no stone upon stone.' },
    reward:{ xp:240, rep:1, score:600 } },
  { id:'sq10', type:'clearbase', district:'base3', pos:[70,120], nightOnly:true,
    title:{ ar:'غارة منتصف الليل', en:'Midnight Raid' },
    desc:{ ar:'قاعدة قرب المطار لا تُرى إلا في الظلام — حرفياً. متاحة ليلاً فقط.',
           en:'A base near the airport only visible in the dark — literally. Night only.' },
    reward:{ xp:300, rep:1, score:800 } },
  { id:'sq11', type:'chase', district:'docks', pos:[110,130], time:95,
    title:{ ar:'مطاردة سيارة الظل', en:'Chase the Shadow Car' },
    desc:{ ar:'سيارة تحمل أدلة حاسمة تفرّ نحو حلقة الطريق السريع. دمّرها قبل أن تفلت.',
           en:'A car carrying decisive evidence is fleeing toward the ring road. Destroy it before it escapes.' },
    reward:{ xp:240, score:700 } },
  { id:'sq12', type:'snipers', district:'downtown', count:2,
    title:{ ar:'صيّادوا الأسطح', en:'The Rooftop Hunters' },
    desc:{ ar:'قنّاصان يستهدفان المدنيين في وسط المدينة. تتبّع الوميض واقضِ عليهما.',
           en:'Two snipers are hunting civilians downtown. Follow the flash and end them.' },
    reward:{ xp:220, rep:2, score:600 } },
  { id:'sq13', type:'caches', district:'ruins', pos:[-140,-140], count:4,
    title:{ ar:'كنوز الحرب المدفونة', en:'Buried War Caches' },
    desc:{ ar:'أربع مخابئ أسلحة حربية في الأنقاض. اجمعها — ستحتاج كل قنبلة.',
           en:'Four wartime weapon caches hidden in the ruins. Collect them — you will need every grenade.' },
    reward:{ xp:200, score:500, nades:3 } },
  { id:'sq14', type:'rescue', district:'residential', pos:[-150,40], count:2, guards:3,
    title:{ ar:'جيران تحت الحصار', en:'Neighbors Under Siege' },
    desc:{ ar:'عائلتان محاصرتان في الحي السكني. الحراس قليلون لكن الشوارع ضيقة.',
           en:'Two families are pinned down in the residential district. Few guards, but the streets are tight.' },
    reward:{ xp:140, rep:2, score:350 } }
];

/* quest availability by campaign wave */
const SIDE_QUEST_WAVES = { 1:['sq6'], 2:['sq1','sq7'], 3:['sq3'], 4:['sq4','sq14'], 5:['sq8'], 6:['sq2'], 7:['sq13'], 8:['sq5'], 9:['sq11'], 10:['sq12'], 11:['sq9','sq10'], 12:[], 13:[], 14:[], 15:[] };

/* ------------------------------------------------------------------ */
/* MISC RADIO / FLAVOR                                                 */
/* ------------------------------------------------------------------ */
const REP_RADIO = {
  hero:{ ar:'المدينة كلها تتحدث عنك يا رعد. اسمك يُحفر على الجدران بجانب سامر.', en:'The whole city is talking about you, Raad. Your name is carved on walls next to Samer\'s.' },
  neutral:{ ar:'الناس يعرفون أن هناك أحداً يقاتل عنهم. هذا يكفي… حالياً.', en:'People know someone out there is fighting for them. That\'s enough... for now.' },
  ghost:{ ar:'رعد… المدينة تخافك كما تخافهم. لا تجعل بطولتك سجناً.', en:'Raad... the city fears you like it fears them. Don\'t let your heroism become a cage.' }
};

/* character names for TTS voices / labels */
const CAST = {
  raad:  { ar:'رعد', en:'RAAD' },
  haddad:{ ar:'الرائد حداد', en:'MAJOR HADDAD' },
  lina:  { ar:'الدكتورة لينا', en:'DR. LINA' },
  ghost: { ar:'الشبح', en:'THE GHOST' },
  karim: { ar:'الرائد كريم', en:'MAJOR KARIM' },
  samer: { ar:'سامر', en:'SAMER' }
};
