MINDMATE AI COMPANION — PROTOTYPE

Open index.html in a modern browser (Chrome recommended). It includes a responsive chat interface, level progression, topic-aware demo replies, speech-to-text where supported, and text-to-speech.

IMPORTANT LIMITATION:
This is a front-end prototype. It does NOT yet connect to a live AI model; some replies are scripted. For real open-ended, accurate answers, you must connect a model through a secure backend server. Never place an API secret in index.html. Therapy support is not a replacement for a licensed clinician or emergency services. Sexual-health questions are treated as factual education, not blocked by level.

Suggested next step: build a backend (Node/Python) that stores the AI API key in environment variables, sends user messages to the model, and applies privacy safeguards. Add clear consent and data deletion controls before collecting personal or health information.
