"use strict";

const levels = ["Adaptatif", "Découverte", "Application", "Contrôle", "Bac", "Approfondissement"];
const shuffle = a => {
  let b = a.slice();
  for (let i = b.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [b[i], b[j]] = [b[j], b[i]];
  }
  return b;
};
const norm = s => String(s).trim().toLocaleLowerCase("fr").replace(/\s+/g, " ");
function readCourse(id) {
  page = "Révisions";
  courseId = id;
  quiz = null;
  render();
  window.scrollTo(0, 0);
}
function listCards() {
  let list = activeCourses().filter(c => (!filterSub || c.sub === filterSub) && norm(c.title + " " + c.part + " " + c.defs).includes(norm(query)));
  return list.length ? list.map(c => '<button onclick="readCourse(\'' + c.id + '\')"><span>' + esc(nameOf(c.sub)) + ' · ' + esc(c.part.split(" · ").pop()) + '</span><strong>' + esc(c.title) + '</strong><b>' + (mastered(c) ? "Maîtrisé" : stats(c.id).n ? "Reprendre" : "Ouvrir le cours") + ' →</b></button>').join("") : '<p>Aucun cours pour cette recherche.</p>';
}
function revision() {
  if (quiz) return quizHtml();
  let c = COURSES.find(c => c.id === courseId);
  if (c) return btn("← Bibliothèque", "courseId='';render()", "link") + heading(esc(c.part), esc(c.title)) + '<article class="card lesson"><p>' + esc(c.intro) + '</p>' + [["Définitions", c.defs], ["Méthode", c.method], ["Exemple corrigé", c.example], ["Erreur fréquente", c.trap], ["À retenir", c.recap]].map(([h, v], i) => '<section class="' + (i === 2 ? "example" : "") + '"><h3>' + h + '</h3><p>' + esc(v) + '</p></section>').join("") + btn("S’entraîner · 5 questions", "startQuiz('" + c.id + "')", "primary") + '</article>';
  return heading("Cours et exercices", "Mes révisions") + '<div class="filter"><label>Matière<select id="filter" onchange="filterSub=this.value;render()">' + option("", "Toutes les matières", filterSub) + D.subjects.filter(s => s.show && OUTLINE[s.id]).map(s => option(s.id, s.name, filterSub)).join("") + '</select></label><label>Rechercher<input type="search" value="' + esc(query) + '" placeholder="Un chapitre, une notion…" oninput="query=this.value;document.getElementById(\'library\').innerHTML=listCards()"></label></div><div class="library" id="library">' + listCards() + '</div><details class="card spaced"><summary>Repères du programme et contenus à développer</summary><p>Les cartes ci-dessus ouvrent des cours et exercices intégrés. Voici les autres repères et les thèmes dont la couverture reste partielle.</p>' + Object.keys(OUTLINE).filter(k => !filterSub || filterSub === k).map(k => '<h3>' + esc(nameOf(k)) + '</h3><p>' + esc(OUTLINE[k]) + '</p>').join("") + '<p>EPS : suivi du bulletin et objectif personnel dans Profil. Français : résultats anticipés dans Bac.</p></details>';
}
function startQuiz(id, isMock = false) {
  let c = (isMock ? MOCKS : COURSES).find(x => x.id === id);
  if (!c) return;
  quiz = {
    c,
    mock: isMock,
    used: [],
    responses: [],
    feedback: null,
    done: false,
    deadline: isMock ? Date.now() + 600000 : 0,
    weak: stats(id).n > 0 && stats(id).rate < .7
  };
  page = "Révisions";
  courseId = isMock ? "" : id;
  nextQ();
  window.scrollTo(0, 0);
}
function nextQ() {
  if (!quiz || quiz.done) return;
  let z = quiz,
    c = z.c,
    i;
  if (z.mock) i = z.used.length;else {
    let desired = D.settings.level || Math.min(5, Math.max(1, 1 + Math.floor(stats(c.id).rate * 3) + (z.responses.slice(-2).filter(Boolean).length === 2 ? 1 : 0)));
    let candidates = c.qs.map((q, i) => {
      let prev = D.answers.filter(a => a.q === c.id + "-" + i),
        last = prev[prev.length - 1],
        due = !last || shift(last.date, last.ok ? Math.min(14, 2 * prev.length) : 1) <= day();
      return {
        i,
        score: (last && !last.ok ? 12 : 0) + (due ? 8 : 0) + (last ? 0 : 3) - Math.abs(q.lvl - desired) * 1.4 + Math.random()
      };
    }).filter(v => !z.used.includes(v.i)).sort((a, b) => b.score - a.score);
    i = candidates[0].i;
  }
  z.used.push(i);
  z.q = z.mock ? {
    p: c.qs[i][0],
    type: "nombre",
    key: +c.qs[i][1],
    tol: i === 3 && c.id === "heat" ? .051 : .001,
    ex: c.qs[i][2],
    lvl: 4
  } : c.qs[i];
  z.options = z.q.options ? shuffle(z.q.options) : [];
  z.match = z.q.pairs ? shuffle(z.q.pairs.map(x => x[0])) : [];
  z.feedback = null;
  z.elapsed = 0;
  z.activeSince = document.hidden ? 0 : Date.now();
  render();
}
function accrue() {
  if (quiz && quiz.activeSince) {
    quiz.elapsed += Math.max(0, Date.now() - quiz.activeSince);
    quiz.activeSince = 0;
  }
}
document.addEventListener("visibilitychange", () => {
  if (!quiz || quiz.feedback || quiz.done) return;
  if (document.hidden) accrue();else quiz.activeSince = Date.now();
});
function tick() {
  let z = quiz;
  if (!z || !z.mock || z.done) return;
  function update() {
    if (!quiz || quiz !== z) return;
    let left = Math.max(0, Math.ceil((z.deadline - Date.now()) / 1000)),
      el = $("#time");
    if (el) el.textContent = Math.floor(left / 60) + " min " + String(left % 60).padStart(2, "0") + " s";
    if (!left) {
      finishQuiz(true);
      render();
    }
  }
  update();
  if (!z.done) timer = setInterval(update, 500);
}
function quizHtml() {
  let z = quiz,
    c = z.c,
    q = z.q;
  if (z.done) {
    let n = z.responses.length;
    return heading(z.mock ? "Entraînement original" : "Révisions", z.expired ? "Temps écoulé" : "Séance terminée") + '<div class="card success"><h2>' + z.responses.filter(Boolean).length + ' / ' + (z.mock ? 5 : n) + ' réponses justes</h2><p>' + esc(c.title) + '</p>' + (z.mock ? '<p>Barème · 4 points par réponse juste. Note : ' + 4 * z.responses.filter(Boolean).length + '/20.</p>' : '') + '<p>' + esc(z.summary || "") + '</p>' + (z.feedback ? '<div class="feedback">' + esc(z.feedback) + '</div>' : '') + btn("Retour " + (z.mock ? "au bac" : "aux cours"), "endQuiz()", "primary") + '</div>';
  }
  let body = '';
  if (!z.feedback) {
    if (q.type === "choix") body = '<div class="opts">' + z.options.map((v, i) => btn(esc(v), "answerQuiz(" + i + ")")).join("") + '</div>';else if (q.type === "assoc") body = '<form onsubmit="event.preventDefault();answerQuiz()">' + q.pairs.map((pair, i) => choose(esc(pair[1]), "a" + i, option("", "Choisir…", "") + z.match.map(v => option(v, v, "")).join(""))).join("") + '<button class="primary">Vérifier les associations</button></form>';else body = '<form onsubmit="event.preventDefault();answerQuiz()"><label>Ta réponse' + (q.type === "nombre" ? ' · unité indiquée dans la question' : '') + '<input id="response" ' + (q.type === "nombre" ? 'inputmode="decimal"' : '') + ' autocomplete="off" required></label><button class="primary">Valider ma réponse</button></form>';
  } else body = '<div class="feedback ' + (z.responses[z.responses.length - 1] ? "" : "miss") + '" role="status">' + esc(z.feedback) + '</div>' + btn("Question suivante →", "nextQ()", "primary");
  return heading(z.mock ? "Sujet blanc original · format court" : "Séance de révision", esc(c.title)) + '<div class="card lesson"><div class="row"><span class="tag">Question ' + z.used.length + ' / 5</span><small>' + levels[q.lvl] + (z.mock ? ' · <b id="time"></b>' : '') + '</small></div>' + bar(20 * z.responses.length) + (z.mock ? '<p class="soft">' + esc(c.intro) + '</p>' : '') + '<h2>' + esc(q.p) + '</h2>' + body + '</div>';
}
function answerQuiz(i) {
  let z = quiz;
  if (!z || z.feedback || z.done) return;
  if (z.mock && Date.now() >= z.deadline) {
    finishQuiz(true);
    render();
    return;
  }
  let q = z.q,
    ok = false;
  if (q.type === "choix") ok = z.options[i] === q.key;else if (q.type === "assoc") {
    let vals = q.pairs.map((p, i) => document.querySelector('[name="a' + i + '"]').value);
    if (vals.some(v => !v)) {
      notice("Associe chaque définition.");
      return;
    }
    ok = vals.every((v, i) => v === q.pairs[i][0]);
  } else {
    let v = $("#response").value.trim();
    if (!v) {
      notice("Saisis ta réponse.");
      return;
    }
    if (q.type === "nombre") {
      if (!/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)$/.test(v)) {
        notice("Saisis un nombre, sans l’unité.");
        return;
      }
      ok = Math.abs(Number(v.replace(",", ".")) - q.key) <= q.tol + 1e-10;
    } else ok = norm(v) === norm(q.key);
  }
  accrue();
  let idx = z.used[z.used.length - 1];
  D.answers.push({
    ch: z.c.id,
    q: z.c.id + "-" + idx,
    date: day(),
    ok,
    xp: ok ? 10 + (q.lvl >= 4 ? 5 : 0) : 0,
    sec: Math.min(86400, Math.round(z.elapsed / 1000))
  });
  z.responses.push(ok);
  z.feedback = (ok ? "Bonne réponse. " : "À reprendre. ") + q.ex;
  if (z.responses.length === 5) {
    finishQuiz(false, true);
  }
  if (!save()) {
    z.responses.pop();
    z.feedback = null;
    z.done = false;
    z.activeSince = Date.now();
  }
  render();
}
function finishQuiz(expired, pending = false) {
  let z = quiz;
  if (z.done) return;
  let n = z.responses.length,
    before = streak(D.sessions),
    d = day(),
    daily = n >= 5 && !before.days.includes(d);
  z.done = true;
  z.expired = expired;
  let bonus = (n >= 5 ? 20 : 0) + (n >= 5 && z.weak ? 5 : 0) + (daily ? 10 : 0);
  let session = {
    title: z.c.title,
    date: d,
    n,
    right: z.responses.filter(Boolean).length,
    xp: bonus,
    mock: z.mock
  };
  if (n) D.sessions.push(session);
  let run = streak(D.sessions).current;
  if (daily && [3, 30].includes(run)) session.xp += run === 3 ? 30 : 100;
  z.summary = (daily ? "Flamme du jour validée ! " : "") + (n >= 5 ? "Bonus de séance et de progression : " + session.xp + " XP." : "Questions traitées : " + n + "/5.");
  if (!pending && n && !save()) z.summary = "La séance n’a pas pu être enregistrée.";
}
function endQuiz() {
  let mock = quiz.mock;
  quiz = null;
  courseId = "";
  page = mock ? "Bac" : "Révisions";
  render();
  window.scrollTo(0, 0);
}
