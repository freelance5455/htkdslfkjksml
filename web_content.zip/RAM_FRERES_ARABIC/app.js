const $=id=>document.getElementById(id);
const KEY='ram_freres_store_v2';
let db=loadDB(), cart=[], lastInvoice=null;
function fresh(){return {account:null,products:[],customers:[],sales:[],expenses:[]}}
function loadDB(){try{return JSON.parse(localStorage.getItem(KEY))||fresh()}catch(e){return fresh()}}
function save(){localStorage.setItem(KEY,JSON.stringify(db));renderAll()}
function money(n){return (Number(n)||0).toLocaleString('fr-FR',{maximumFractionDigits:2})+' دج'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function dateText(d=new Date()){return d.toLocaleString('fr-DZ')}
function showAuth(){ $('auth').hidden=false;$('main').hidden=true; const exists=!!db.account;
 $('authTitle').textContent=exists?'تسجيل الدخول':'إنشاء حساب المدير';
 $('authHint').textContent=exists?'أدخل معلومات حسابك لفتح المحل.':'أول استعمال: أنشئ حسابك وكلمة المرور.';
 $('confirmLabel').hidden=exists;$('confirmPassword').hidden=exists;
 $('authBtn').textContent=exists?'دخول':'إنشاء الحساب';$('username').value='';$('password').value='';$('confirmPassword').value='';$('authError').textContent='';
}
function enter(){
 $('password').value='';$('confirmPassword').value='';
 $('authError').textContent='';
 $('auth').classList.add('auth-leaving');
 setTimeout(()=>{ $('auth').hidden=true;$('auth').classList.remove('auth-leaving');$('main').hidden=false;$('welcome').textContent='مرحباً، '+db.account.username;renderAll(); },140);
}
$('authBtn').onclick=()=>{
 const u=$('username').value.trim(),p=$('password').value;
 if(!u||p.length<4){$('authError').textContent='اكتب اسم المستخدم وكلمة مرور من 4 أحرف على الأقل.';return}
 if(!db.account){if(p!==$('confirmPassword').value){$('authError').textContent='كلمتا المرور غير متطابقتين.';return}db.account={username:u,password:p};save();enter()}
 else if(u===db.account.username&&p===db.account.password)enter();else $('authError').textContent='اسم المستخدم أو كلمة المرور غير صحيحة.';
};
$('password').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('authBtn').click()}});
$('confirmPassword').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('authBtn').click()}});
$('lockBtn').onclick=showAuth;
$('tabs').addEventListener('click',e=>{const b=e.target.closest('button[data-page]');if(!b)return;document.querySelectorAll('.tabs button').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.page').forEach(x=>x.hidden=x.id!=='page-'+b.dataset.page);});
function renderAll(){renderHome();renderProducts();renderSelect();renderCart();renderCustomers();renderExpenses();renderReports()}
function renderHome(){
 $('statProducts').textContent=db.products.length;
 const today=new Date().toDateString(),todaySales=db.sales.filter(s=>new Date(s.date).toDateString()===today).reduce((a,s)=>a+s.total,0);
 $('statSales').textContent=money(todaySales);
 $('statDebt').textContent=money(db.sales.reduce((a,s)=>a+s.debt,0));
 const low=db.products.filter(p=>p.qty<=p.min);
 $('statLow').textContent=low.length;
 $('lowStock').innerHTML=low.length?low.map(p=>`<div class="item"><div><strong>${esc(p.name)}</strong><small>المتوفر: ${p.qty} — حد التنبيه: ${p.min}</small></div><b>${p.qty<=0?'نفدت':'كمية قليلة'}</b></div>`).join(''):'لا توجد سلع ناقصة حالياً.';
 $('recentSales').innerHTML=db.sales.length?db.sales.slice(-4).reverse().map(s=>`<div class="item"><div><strong>فاتورة ${esc(s.number)}</strong><small>${esc(s.customer||'زبون نقدي')} • ${esc(s.date)}</small></div><b>${money(s.total)}</b></div>`).join(''):'لا توجد مبيعات بعد.';
}
function resetProductForm(){ $('productForm').reset();$('productId').value='';$('pQty').value=0;$('pMin').value=2;$('pBuy').value=0;$('pSell').value=0;$('productFormTitle').textContent='إضافة سلعة جديدة';$('cancelEdit').hidden=true}
$('productForm').onsubmit=e=>{e.preventDefault();const pid=$('productId').value;const p={id:pid||id(),name:$('pName').value.trim(),qty:+$('pQty').value,min:+$('pMin').value,buy:+$('pBuy').value,sell:+$('pSell').value};if(!p.name)return;if(pid){const i=db.products.findIndex(x=>x.id===pid);if(i>=0)db.products[i]=p}else db.products.push(p);resetProductForm();save()};
$('cancelEdit').onclick=resetProductForm;
function renderProducts(){const q=$('productSearch').value?.toLowerCase()||'';const arr=db.products.filter(p=>p.name.toLowerCase().includes(q));$('productsList').className='list'+(arr.length?'':' empty');$('productsList').innerHTML=arr.length?arr.map(p=>`<div class="item"><div><strong>${esc(p.name)}</strong><small>الكمية: ${p.qty} • شراء: ${money(p.buy)} • بيع: ${money(p.sell)}</small></div><div class="item-actions"><button class="ghost" data-edit="${p.id}">تعديل</button><button class="danger" data-del="${p.id}">حذف</button></div></div>`).join(''):'المخزن فارغ. أضف أول سلعة.'}
$('productSearch').oninput=renderProducts;
$('productsList').onclick=e=>{const edit=e.target.dataset.edit,del=e.target.dataset.del;if(edit){const p=db.products.find(x=>x.id===edit);if(!p)return;$('productId').value=p.id;$('pName').value=p.name;$('pQty').value=p.qty;$('pMin').value=p.min;$('pBuy').value=p.buy;$('pSell').value=p.sell;$('productFormTitle').textContent='تعديل السلعة';$('cancelEdit').hidden=false;window.scrollTo({top:0,behavior:'smooth'})}if(del&&confirm('هل تريد حذف هذه السلعة؟')){db.products=db.products.filter(p=>p.id!==del);save()}}
function renderSelect(){const old=$('saleProduct').value;$('saleProduct').innerHTML='<option value="">اختر سلعة من المخزن</option>'+db.products.map(p=>`<option value="${p.id}">${esc(p.name)} — ${p.qty} متوفر</option>`).join('');if(db.products.some(p=>p.id===old))$('saleProduct').value=old}
$('saleProduct').onchange=()=>{const p=db.products.find(x=>x.id===$('saleProduct').value);$('salePrice').value=p?p.sell:''}
$('addToCart').onclick=()=>{const p=db.products.find(x=>x.id===$('saleProduct').value),q=+$('saleQty').value,price=+$('salePrice').value;if(!p){alert('اختر سلعة أولاً.');return}if(q<=0||q>p.qty){alert('الكمية غير صحيحة أو غير متوفرة في المخزن.');return}if(price<0){alert('السعر غير صحيح.');return}const existing=cart.find(x=>x.productId===p.id&&x.price===price);if(existing){if(existing.qty+q>p.qty){alert('الكمية المطلوبة أكبر من المتوفر.');return}existing.qty+=q}else cart.push({productId:p.id,name:p.name,qty:q,price});renderCart()}
function totalCart(){return cart.reduce((a,x)=>a+x.qty*x.price,0)}
function renderCart(){$('cartList').innerHTML=cart.length?cart.map((x,i)=>`<div class="cart-row"><span>${esc(x.name)} × ${x.qty}</span><span>${money(x.qty*x.price)} <button class="ghost" data-cartdel="${i}" style="padding:4px 8px">×</button></span></div>`).join(''):'الفاتورة فارغة.';$('cartTotal').textContent=money(totalCart());$('cartDebt').textContent=money(Math.max(0,totalCart()-(+$('paidAmount').value||0)))}
$('cartList').onclick=e=>{if(e.target.dataset.cartdel!==undefined){cart.splice(+e.target.dataset.cartdel,1);renderCart()}}
$('paidAmount').oninput=renderCart;
$('clearCart').onclick=()=>{cart=[];renderCart();$('invoiceArea').innerHTML=''}
$('completeSale').onclick=()=>{
 if(!cart.length){alert('أضف سلعة إلى الفاتورة.');return}
 for(const line of cart){const p=db.products.find(x=>x.id===line.productId);if(!p||p.qty<line.qty){alert('المخزون تغيّر. راجع الكميات.');return}}
 const total=totalCart(),paid=+$('paidAmount').value||0;if(paid<0){alert('المبلغ المدفوع غير صحيح.');return}
 const sale={id:id(),number:String(db.sales.length+1).padStart(5,'0'),date:new Date().toISOString(),customer:$('saleCustomer').value.trim(),items:cart.map(x=>({...x})),total,paid:Math.min(paid,total),debt:Math.max(0,total-paid)};
 sale.items.forEach(x=>{const p=db.products.find(p=>p.id===x.productId);p.qty-=x.qty});
 db.sales.push(sale);if(sale.customer&&!db.customers.some(c=>c.name.toLowerCase()===sale.customer.toLowerCase()))db.customers.push({id:id(),name:sale.customer,phone:''});
 lastInvoice=sale;cart=[];$('paidAmount').value=0;$('saleCustomer').value='';save();renderInvoice(sale);
};
function renderInvoice(s){$('invoiceArea').innerHTML=`<div class="invoice" id="printInvoice"><div class="inv-head"><h3>RAM FRÈRES OUTILLAGE</h3><div>فاتورة بيع</div><small>رقم: ${esc(s.number)} | التاريخ: ${esc(dateText(new Date(s.date)))}</small><div>الزبون: ${esc(s.customer||'زبون نقدي')}</div></div><table><thead><tr><th>السلعة</th><th>الكمية</th><th>السعر</th><th>المجموع</th></tr></thead><tbody>${s.items.map(x=>`<tr><td>${esc(x.name)}</td><td>${x.qty}</td><td>${money(x.price)}</td><td>${money(x.qty*x.price)}</td></tr>`).join('')}</tbody></table><p>المجموع: <b>${money(s.total)}</b></p><p>المدفوع: <b>${money(s.paid)}</b></p><p>الباقي: <b>${money(s.debt)}</b></p><p style="text-align:center">شكراً على ثقتكم</p></div><button class="primary full" onclick="window.print()">طباعة / حفظ PDF</button>`}
$('customerForm').onsubmit=e=>{e.preventDefault();db.customers.push({id:id(),name:$('cName').value.trim(),phone:$('cPhone').value.trim()});$('customerForm').reset();save()}
function renderCustomers(){$('customersList').innerHTML=db.customers.length?db.customers.map(c=>{const debt=db.sales.filter(s=>s.customer===c.name).reduce((a,s)=>a+s.debt,0);return `<div class="item"><div><strong>${esc(c.name)}</strong><small>${esc(c.phone||'بدون هاتف')} • الدين الحالي: ${money(debt)}</small></div><div class="item-actions">${debt>0?`<button class="secondary" data-pay="${c.id}">تسجيل تسديد</button>`:''}<button class="danger" data-cdel="${c.id}">حذف</button></div></div>`}).join(''):'لا يوجد زبائن مسجلون.'}
$('customersList').onclick=e=>{const pid=e.target.dataset.pay,cid=e.target.dataset.cdel;if(pid){const c=db.customers.find(x=>x.id===pid);const outstanding=db.sales.filter(s=>s.customer===c.name).reduce((a,s)=>a+s.debt,0);const amount=+(prompt('كم دفع الزبون؟ الدين الحالي: '+money(outstanding))||0);if(amount<=0)return;let left=amount;for(const s of db.sales.filter(s=>s.customer===c.name&&s.debt>0)){const take=Math.min(left,s.debt);s.debt-=take;s.paid+=take;left-=take;if(left<=0)break}save()}if(cid&&confirm('حذف الزبون من القائمة؟ لن تُحذف فواتيره.')){db.customers=db.customers.filter(c=>c.id!==cid);save()}}
$('expenseForm').onsubmit=e=>{e.preventDefault();db.expenses.push({id:id(),name:$('eName').value.trim(),amount:+$('eAmount').value,date:new Date().toISOString()});$('expenseForm').reset();save()}
function renderExpenses(){$('expensesList').innerHTML=db.expenses.length?db.expenses.slice().reverse().map(x=>`<div class="item"><div><strong>${esc(x.name)}</strong><small>${dateText(new Date(x.date))}</small></div><b>${money(x.amount)}</b></div>`).join(''):'لا توجد مصاريف مسجلة.'}
function renderReports(){const total=db.sales.reduce((a,s)=>a+s.total,0),paid=db.sales.reduce((a,s)=>a+s.paid,0),debt=db.sales.reduce((a,s)=>a+s.debt,0),exp=db.expenses.reduce((a,x)=>a+x.amount,0);$('rSales').textContent=money(total);$('rPaid').textContent=money(paid);$('rDebt').textContent=money(debt);$('rExpenses').textContent=money(exp);$('salesHistory').innerHTML=db.sales.length?db.sales.slice().reverse().map(s=>`<div class="item"><div><strong>فاتورة ${esc(s.number)} — ${esc(s.customer||'زبون نقدي')}</strong><small>${dateText(new Date(s.date))} • مدفوع: ${money(s.paid)} • دين: ${money(s.debt)}</small></div><b>${money(s.total)}</b></div>`).join(''):'لا توجد فواتير بعد.'}
$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='RAM-FRERES-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();URL.revokeObjectURL(url)}
$('importFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(!data.account||!Array.isArray(data.products)||!Array.isArray(data.sales))throw Error();if(confirm('استرجاع النسخة سيعوض البيانات الحالية. هل تواصل؟')){db=data;save();alert('تم استرجاع النسخة.')}}catch(err){alert('الملف غير صالح أو ليس نسخة من هذا التطبيق.')}e.target.value=''}
$('logoutReset').onclick=()=>{if(confirm('تحذير: سيتم حذف الحساب وجميع البيانات من هذا المتصفح. هل أنت متأكد؟')&&confirm('تأكيد أخير: هل صدّرت نسخة احتياطية؟')){localStorage.removeItem(KEY);db=fresh();showAuth()}}
if(db.account)showAuth();else showAuth();
