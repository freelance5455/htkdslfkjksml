ChatOnline — V Chrome-like Permissions

هذه النسخة مبنية على ChatOnline_AndroidStudio_Permissions_Follow_FIXED.zip.
التعديل مخصص لطبقة Android فقط:
- Runtime permission للميكروفون والكاميرا.
- WebView onPermissionRequest.
- Android file chooser للصور والملفات.
- الحفاظ على واجهة وملفات ChatOnline الأصلية.
ملاحظة: يجب اختبار المشروع في Android Studio قبل اعتبار كل وظيفة ناجحة.
