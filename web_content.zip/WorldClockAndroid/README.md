# World Clock Android app

This is an Android Studio project based on `WorldClockImport.txt`.

## Features
- Imports the configured city list, flags, labels, and priority order.
- Live local times and dates for all configured widget cities.
- Search by city or country.
- Uses IANA time-zone IDs and the device's time-zone database, so daylight-saving changes are handled by the runtime.
- Offline after installation.

## Build an APK
1. Open this folder in Android Studio (a recent version).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

The APK has not been compiled in this environment because an Android SDK/Gradle installation is not available here. This download is the complete source project, not an APK.
