DevNen 2 Friends — playable browser horror prototype
===================================================

This ZIP contains an original, playable 2D top-down horror prototype. It is a separate project from DevNen Chapter 1.
It is NOT a native Android APK and it is NOT a full 3D game yet.

How to play:
1. Extract the ZIP.
2. Open www/index.html in a modern browser.
3. Use WASD / arrow keys, or the on-screen directional pad on a phone.
4. Explore the school, mall, and house. Find friends and interact with them to rescue them.
5. Avoid the Nun, Teacher, and Evil Slender.
6. Press E / INTERACT near friends. Press F / FLASHLIGHT to toggle the light.
7. Reach the exit after rescuing all friends. Press R to restart.

How to package as an Android app:
- This is a web game. To make an APK, use a trusted HTML-to-Android wrapper/build service or package it with a WebView Android project.
- A simple ZIP-to-APK converter may not support this format; the app must specifically support HTML games or WebView projects.
- No APK is included because no Android build has been run.

All visuals are original simple canvas drawings. No external assets or libraries are required.
