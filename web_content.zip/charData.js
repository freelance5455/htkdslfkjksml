/* ==========================================================
   抽屉② 内容层：人物卡 / 五阶段台词 / 偶遇池 / 上课池
   ========================================================== */
const NPC = {
  shen:{name:'沈逸舟',color:'#5b8dd4',emoji:'📘',bonus:'study',tag:'高岭之花 · 学生会长',
    likes:'学习 / 书籍 / 规则',places:'图书馆 · 学生会室 · 天台',secretName:'退会申请书',
    desc:'冷淡理性、完美主义。父亲是大学教授，母亲是钢琴家，从小被安排一切。抽屉里那封誊写三次的退会申请书。'},
  lu:{name:'陆鸣',color:'#e08c3c',emoji:'🏀',bonus:'sport',tag:'阳光篮球部王牌',
    likes:'篮球 / 运动 / 励志',places:'小卖部 · 体育馆 · 操场',secretName:'磨破边的旧护腕',
    desc:'热血直率。初中被队友陈放撞伤手腕，一度放弃篮球。左手腕那块磨白的旧护腕是全部心事。'},
  su:{name:'苏念秋',color:'#9b7dd4',emoji:'📖',bonus:'charm',tag:'温柔文学社学姐',
    likes:'文学 / 诗歌 / 电影',places:'文学社 · 音乐教室 · 书店',secretName:'边缘烧焦的手稿',
    desc:'温柔知性。高三面临升学，父母要她考医学部。写了两年的《樱花落尽之前》扉页被烧过一次。'},
  lin:{name:'林小满',color:'#e8618f',emoji:'💄',bonus:'charm',tag:'傲娇时尚辣妹',
    likes:'时尚 / 美妆 / 美食',places:'咖啡店 · 商场 · 天台',secretName:'穿搭博客后台',
    desc:'傲娇毒舌。父母离婚跟妈妈。手机里的穿搭博客粉丝数比想象中多得多。'}
};

const STAT_NAME  = {charm:'魅力',study:'学习',sport:'运动',social:'社交',courage:'勇气'};
const STAT_EMOJI = {charm:'💄',study:'📚',sport:'🏃',social:'💬',courage:'🔥'};

/* ===== 文档 v3.0 角色表（表2-2）里的配角：只用于对白渲染，不进攻略池 ===== */
const CAST = {
  zhang :{id:'CH_ZHANG', name:'张晓棠', color:'#c78ba1', emoji:'💬', role:'好感记录者'},
  father:{id:'CH_FATHER',name:'沈父',   color:'#4a4a5a', emoji:'🕴️', role:'父权压力来源'},
  bai   :{id:'CH_BAI',   name:'白若曦', color:'#b06f8f', emoji:'🌷', role:'压力具象化'},
  wang  :{id:'CH_WANG',  name:'王老师', color:'#7a8a6a', emoji:'📋', role:'规则执行者'}
};
/* 生成一行带立绘色块的对白，供 C 线与配角事件复用 */
function castLine(key, text, note){
  const c = CAST[key];
  if(!c) return `<p class="nar">${text}</p>`;
  return `<p class="npcLine"><span class="npcAvatar" style="background:${c.color}">${c.emoji}</span>` +
         `<span class="npcText"><b style="color:${c.color}">${c.name}</b>${note?'（'+note+'）':''}「${text}」</span></p>`;
}

/* 五阶段开场白 */
const OPENING = {
  shen:[
    {eventId:'shen_01',text:'图书馆靠窗，沈逸舟抄一份表格。抄到一半，把纸揉成团塞进书里。',
     choices:[
       {label:'装作没看见，在旁边坐下',fav:4,stat:{study:2},memo:'你看见他把一张纸揉成团藏进书里。',res:'他重新拿了一张纸，一笔一划地写。'},
       {label:'「写错了可以换一张。」',fav:6,stat:{study:2},tense:{shen:-3},memo:'你对他说：写错了可以换一张。',res:'他抬头看你，很久才说：「……换一张，也是同一份东西。」'}
     ]},
    {eventId:'shen_02',text:'学生会室灯还亮着，沈逸舟的手腕上有一道被纸划的浅红痕。',
     choices:[
       {label:'把创可贴放在他手边',fav:6,stat:{social:1},tense:{shen:-4},memo:'你在他手腕边放过一张创可贴。',res:'他愣了一下，没道谢，也没推回来。'},
       {label:'「你每天都这样？」',fav:3,tense:{shen:4},res:'「习惯了。」他说得很轻。'}
     ]},
    {eventId:'shen_03',text:'走廊尽头，沈逸舟站在公告栏前。手里那张纸被他捏得起了折痕，看了很久，最后还是折起来塞回口袋。',
     choices:[
       {label:'路过时，轻轻碰了一下他的袖子',fav:5,tense:{shen:-3},stat:{courage:1},
        memo:'你碰了碰他的袖子。他没有躲开。',
        res:'他侧头看你，没说话。但那张纸，他重新拿出来，展开，又折了一次——这次折得很慢。'},
       {label:'「公告栏上有什么？」',fav:3,tense:{shen:2},res:'「没什么。」他挡在公告栏前，动作很快。'},
       {label:'装作没看见，走开',fav:1,res:'他回头看你走掉的方向。'}
     ]},
    {eventId:'shen_04',text:'午休的楼梯拐角，沈逸舟一个人坐在台阶上，膝盖上摊着书。听到你的脚步，他没抬头，只是往旁边挪了挪，空出一个位置。',
     choices:[
       {label:'在他旁边坐下',fav:6,tense:{shen:-4},stat:{courage:1},
        memo:'你在楼梯拐角坐在他旁边过。',
        res:'他翻了一页书。你看见那页书的页脚，被他反复折过又展开，快破了。'},
       {label:'站着看他',fav:2,res:'他把书合上了。'},
       {label:'「你在这里吃午饭？」',fav:5,stat:{social:1},res:'「……这里安静。」他顿了一下，「你可以坐。」'}
     ]},
    {eventId:'shen_05',text:'放学后的走廊，沈逸舟抱着文件从学生会室出来。看见你，脚步顿了一下，然后继续往前走。走远了大概三步，他忽然停下。',
     choices:[
       {label:'叫住他：「沈会长。」',fav:5,tense:{shen:-2},memo:'你叫住了走廊上停下的他。',
        res:'他转过身。你看见他手里的文件，最上面那页是空白的。'},
       {label:'追上去',fav:6,tense:{shen:-4},stat:{courage:1},memo:'你追上了他。',
        res:'他站在那里等你。等你的脚步近了，他才继续走——这次走得慢了。'},
       {label:'装作没看见',fav:1,res:'他站了很久，最后自己走了。'}
     ]}
  ],
  lu:['「啊？哦，你好。」（说完就走）','「哟，今天也来啊？」','「走走走，陪我练两球！」','「喂，你今天怎么没来看我训练？」','「我不想练球了，就想坐这儿陪你。」'],
  su:['（微笑点头，不说话）','「你来了呀。」','「我刚写了一段，你要不要先看？」','「你昨天那条朋友圈，是和谁一起？」','「最后一章我想写两个人，你愿意做那个一起走的人吗？」'],
  lin:['（上下打量一眼）「有事吗？」','「坐那边，别坐我对面。」','「今天我请客，别点太贵的。」','「我妈又没回来。……你别瞎想，我就是随口说。」','「我搞不懂，为什么要对你这么认真。」']
};

/* 吃醋台词 */
const JEALOUS = {
  shen:'沈逸舟看了你们一眼，没说话。',
  lu:'陆鸣脸上的笑僵了一下，然后扭头走了。',
  su:'苏念秋安静地合上书，「……她说得也没错。」',
  lin:'林小满阴阳怪气：「哦，挺好啊。」'
};

/* 上课随机文本池 */
const CLASSROOM_LINES = [
  {t:'王老师点名：「转校生，你来回答。」你居然答上来了。', s:{study:1}},
  {t:'张晓棠从桌下递来一张纸条：「中午一起吃饭？」',       s:{social:1}},
  {t:'窗外的樱花被风吹得沙沙响。',                          s:{}},
  {t:'后排的李想用笔戳你后背：「作业借我抄抄！」沈逸舟从前排回头。', s:{social:1}, fav:{shen:-1}}
];

/* 偶遇池（C 类事件 / 定向拜访） */
const NPC_SCENES = {
  shen:[
    {eventId:'shen_01',text:'图书馆靠窗，沈逸舟抄一份表格。抄到一半，把纸揉成团塞进书里。',
     choices:[
       {label:'装作没看见，在旁边坐下',fav:4,stat:{study:2},memo:'你看见他把一张纸揉成团藏进书里。',res:'他重新拿了一张纸，一笔一划地写。'},
       {label:'「写错了可以换一张。」',fav:6,stat:{study:2},tense:{shen:-3},memo:'你对他说：写错了可以换一张。',res:'他抬头看你，很久才说：「……换一张，也是同一份东西。」'}
     ]},
    {eventId:'shen_02',text:'学生会室灯还亮着，沈逸舟的手腕上有一道被纸划的浅红痕。',
     choices:[
       {label:'把创可贴放在他手边',fav:6,stat:{social:1},tense:{shen:-4},memo:'你在他手腕边放过一张创可贴。',res:'他愣了一下，没道谢，也没推回来。'},
       {label:'「你每天都这样？」',fav:3,tense:{shen:4},res:'「习惯了。」他说得很轻。'}
     ]}
  ],
  lu:[
    {eventId:'lu_01',text:'体育馆里篮球撞地，陆鸣上篮落地，左手腕上磨得发白的旧护腕晃了一下。',
     choices:[
       {label:'「这护腕有点年头了吧？」',fav:5,stat:{social:1},memo:'你问过他那条磨白的护腕。',res:'他下意识把袖子往下扯了扯：「老东西了。」'},
       {label:'上场陪他打半场',fav:6,stat:{sport:2},tense:{lu:-3},memo:'你陪他打过半场球。',res:'他递来一瓶运动饮料：「下次再来啊！」'}
     ]},
    {eventId:'lu_02',text:'操场边，陆鸣跑完在拉伸。他按了一下手腕，很快松开。',
     choices:[
       {label:'「手腕还疼？」',fav:6,stat:{social:1},tense:{lu:-6},memo:'你问过他：手腕还疼吗。',res:'他愣了一下，然后笑：「你怎么看出来的。」'},
       {label:'给他递一瓶水',fav:5,stat:{sport:1},res:'他仰头灌了半瓶：「还是你懂我！」'}
     ]}
  ],
  su:[
    {eventId:'su_01',text:'文学社教室，苏念秋在稿纸边缘写了一行字，又重重划掉。',
     choices:[
       {label:'「这纸……被烧过？」',fav:6,stat:{study:1},tense:{su:-5},memo:'你发现她的手稿边缘是焦的。',res:'她下意识把稿子往怀里收：「……不小心。」'},
       {label:'请她读一段',fav:5,stat:{charm:1},res:'她读到一半停住：「……是不是太矫情了？」'}
     ]},
    {eventId:'su_02',text:'音乐教室传来断断续续的钢琴声。',
     choices:[
       {label:'安静听她弹完',fav:6,stat:{charm:2},tense:{su:-3},res:'她回过头：「还以为没人听。」眼睛亮亮的。'},
       {label:'「你在想什么？」',fav:5,stat:{social:1},memo:'她说过：如果不弹琴，会不会更轻松。',res:'「在想，如果不弹琴，我会不会更轻松。」'}
     ]}
  ],
  lin:[
    {eventId:'lin_01',text:'咖啡店角落，林小满敲手机。屏幕是一个排版到一半的页面。',
     choices:[
       {label:'「这块蛋糕是给我的吗？」',fav:5,stat:{charm:1},res:'她头也不抬：「想得美。……吃不完，浪费。」'},
       {label:'「你在写什么？」',fav:6,stat:{social:1},memo:'你撞见过她在排版一个页面。',res:'她慌忙锁屏：「别、别偷看！」'}
     ]},
    {eventId:'lin_02',text:'天台门被推开，林小满对着小镜子补妆。眼眶有点红。',
     choices:[
       {label:'「我什么都没看见。」',fav:4,stat:{social:1},tense:{lin:-5},memo:'她在天台上补过妆，你什么都没问。',res:'她松了口气：「……喂，转校生。」'},
       {label:'「你还好吗？」',fav:6,tense:{lin:-2},memo:'你问过她：你还好吗。',res:'「关你什么事。」——声音软了。'}
     ]}
  ]
};
function getUnusedNpcEvent(npcId){
  const avail = NPC_SCENES[npcId].filter(e=>!G.flags[e.eventId]);
  return avail.length ? pick(avail) : null;
}
//（注：内容由AI生成）