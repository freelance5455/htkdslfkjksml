<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(404);exit("Not found\n");}
require_once __DIR__.'/app/auth.php';
$email=strtolower(trim((string)($argv[1]??'')));
if(!filter_var($email,FILTER_VALIDATE_EMAIL)){fwrite(STDERR,"Usage: php tools-recover-admin.php admin@example.com\n");exit(2);}
auth_schema();$s=db()->prepare('SELECT id,email FROM users WHERE email=?');$s->execute([$email]);$u=$s->fetch();
if(!$u){fwrite(STDERR,"No account found for that email.\n");exit(1);}
db()->prepare("UPDATE users SET role='admin',status='active',updated_at=? WHERE id=?")->execute([now_sql(),(int)$u['id']]);
try{require_once __DIR__.'/app/admin.php';admin_audit('admin_access_recovered','user',(string)$u['id'],['method'=>'hosting_cli']);}catch(Throwable $ignored){}
fwrite(STDOUT,"Administrator access restored for ".$u['email'].". Delete this script after use if your deployment policy requires it.\n");
