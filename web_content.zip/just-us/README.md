# Just Us - interactive prototype

Open `index.html` in a browser. It provides editable nicknames, local reminder creation, recurring reminders, surprise notes, emoji reactions, Done/Snooze, and an alarm demonstration while the page remains open.

**Not yet implemented:** pairing two phones, cloud synchronization, native Android alarms when the app is closed, persistent push notifications, authentication, and media voice notes. Data is saved only in this browser's localStorage. Do not use for safety-critical reminders.

To make it a real two-person Android app, build native Android scheduling with AlarmManager (including Android 12+ exact-alarm permissions where applicable), Firebase Authentication/Firestore sync, device registration and push notifications, and test background restrictions across devices.
