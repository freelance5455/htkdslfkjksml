STUDYVERSE WEBSITE PACKAGE

Included files:
- index.html: your Studyverse page
- manifest.webmanifest: app-like install metadata
- icon.svg: sparkle logo

MAKE IT LIVE (simple method):
1. On your tablet, open https://app.netlify.com/drop in a browser.
2. Sign in or create a Netlify account if prompted.
3. Upload/extract this ZIP first if the page asks for a folder; the folder to upload is the extracted `studyverse_site` folder (it must contain index.html at its top level).
4. Wait for Netlify to publish and copy the website URL it gives you.
5. Open the URL once to test Studyverse.

NOTES:
- This package prepares the site but does not publish it automatically; a hosting account is needed to create a public URL.
- Your HTML loads some libraries/fonts from CDNs, so internet access is needed for those parts.
- Local data is stored by the browser origin. If you use a different URL later, browser storage may not carry over.
- The manifest can help supported browsers offer an app-like install experience, but it is not an Android APK.
