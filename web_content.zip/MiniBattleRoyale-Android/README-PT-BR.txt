MINI BATTLE ROYALE 3D — PACOTE ANDROID

Este pacote contém o jogo HTML e a configuração para gerar um aplicativo Android usando Capacitor.
Ele AINDA NÃO É um APK compilado/assinado. Para gerar o APK, é necessário Android Studio + Android SDK.

REQUISITOS
- Node.js LTS e npm
- Android Studio instalado com Android SDK
- JDK compatível com a versão do Android Gradle Plugin instalada pelo Capacitor

PASSOS (Windows, macOS ou Linux)
1. Extraia esta pasta.
2. Abra um terminal dentro da pasta MiniBattleRoyale-Android.
3. Execute: npm install
4. Execute: npx cap add android
5. Execute: npx cap sync android
6. Execute: npx cap open android
7. No Android Studio, aguarde a sincronização do Gradle.
8. Para testar, conecte o celular com depuração USB e use Run.
9. Para gerar APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

OBSERVAÇÕES IMPORTANTES
- O jogo importa Three.js pelo CDN HTTPS (jsdelivr). Portanto, precisa de internet para carregar essa biblioteca na primeira execução/execução do jogo.
- O projeto Android gerado pelo Capacitor deve manter a permissão INTERNET padrão.
- Para distribuir publicamente, gere uma versão release assinada no Android Studio.
- Teste em aparelhos reais: desempenho 3D, rotação/tela cheia e controles podem variar entre dispositivos.
