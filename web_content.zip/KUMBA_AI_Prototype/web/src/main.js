import './style.css';

const LANGS = [
  ['fr','Français'],['ln','Lingala'],['kg','Kikongo ya Leta (Kituba)'],['lua','Tshiluba'],['sw','Swahili (RDC)']
];
const phrases = {
  fr: {hello:'Bonjour ! Je suis KUMBA AI. Comment puis-je vous aider ?', help:'Je peux vous aider à comprendre, rédiger, traduire et apprendre.'},
  ln: {hello:'Mbote ! Nazali KUMBA AI. Nakoki kosalisa yo na nini ?', help:'Nakoki kosalisa yo mpo na koyeba, kokoma mpe kobongola maloba.'},
  kg: {hello:'Mbote! Mono kele KUMBA AI. Inki mono lenda sadisa nge na yo?', help:'Mono lenda sadisa nge na kubakisa, kusonika mpi kubalula ndinga.'},
  lua: {hello:'Moyo! Ndi KUMBA AI. Ndi mukolesha mu tshinyi?', help:'Ndi mukolesha mu kuakula, kusanka ne kutshintulula ndinga.'},
  sw: {hello:'Habari! Mimi ni KUMBA AI. Nikusaidie nini?', help:'Naweza kusaidia kuelewa, kuandika na kutafsiri.'}
};
const app = document.querySelector('#app');
let language = 'fr';
let busy = false;

function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function addMessage(role, text){
  const list=document.querySelector('#messages');
  const el=document.createElement('article');
  el.className=`message ${role}`;
  el.innerHTML=`<div class="avatar">${role==='assistant'?'K':'Vous'}</div><div class="bubble">${escapeHtml(text).replace(/\n/g,'<br>')}</div>`;
  list.appendChild(el); list.scrollTop=list.scrollHeight;
}
function render(){
  app.innerHTML=`
  <div class="shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark">K</div><div><b>KUMBA AI</b><small>by KUMBA TECH</small></div></div>
      <button class="new-chat" id="newChat">＋ Nouvelle conversation</button>
      <div class="side-label">ESPACE DE DÉMONSTRATION</div>
      <div class="side-note"><span class="dot"></span> Prototype opérationnel</div>
      <div class="side-note">🌐 5 langues proposées</div>
      <div class="side-note">📱 PWA & Android</div>
      <div class="side-note">⚡ Mode démo hors connexion</div>
      <div class="sidebar-bottom"><b>KUMBA TECH</b><small>Innovation • RDC • Afrique</small><small>Swikidisa Makaya<br>CEO & Fondateur</small></div>
    </aside>
    <main class="main">
      <header class="topbar"><div><span class="eyebrow">ASSISTANT INTELLIGENT</span><h1>Que voulez-vous faire aujourd'hui ?</h1></div><div class="status"><span class="dot"></span> Démonstration</div></header>
      <section class="intro"><div class="intro-copy"><span class="pill">KUMBA AI · MULTILINGUE</span><h2>La connaissance, <em>dans nos langues.</em></h2><p>Un assistant numérique conçu pour rapprocher l'intelligence artificielle des citoyens, entreprises et institutions de la RDC.</p></div><div class="orb"><div class="orb-core">K</div><span class="orbit o1"></span><span class="orbit o2"></span></div></section>
      <section class="language-row"><label for="language">LANGUE DE CONVERSATION</label><select id="language">${LANGS.map(([id,n])=>`<option value="${id}" ${id===language?'selected':''}>${n}</option>`).join('')}</select><span class="offline" id="connection">● Vérification...</span></section>
      <section class="suggestions">
        <button class="suggestion" data-prompt="Présente KUMBA TECH et ses domaines d'activité."><b>🏢 Présenter KUMBA TECH</b><small>Entreprise et innovation</small></button>
        <button class="suggestion" data-prompt="Traduis « Bonjour, comment allez-vous ? » dans les cinq langues proposées."><b>🌍 Traduction multilingue</b><small>Comparer les cinq langues</small></button>
        <button class="suggestion" data-prompt="Explique simplement comment fonctionne l'énergie solaire."><b>☀️ Apprendre un sujet</b><small>Explication accessible</small></button>
        <button class="suggestion" data-prompt="Aide-moi à rédiger une lettre professionnelle."><b>✍️ Rédaction</b><small>Courrier et documents</small></button>
      </section>
      <section class="chat-panel"><div class="chat-heading"><div><b>Conversation</b><small>Posez votre question à KUMBA AI</small></div><button class="clear" id="clearChat">Effacer</button></div><div id="messages" class="messages"></div>
        <form id="chatForm" class="composer"><textarea id="prompt" rows="1" placeholder="Écrivez votre message..." aria-label="Votre message"></textarea><div class="composer-actions"><div><button type="button" class="tool" id="voice" title="Dicter">🎙️ <span>Parler</span></button><button type="button" class="tool" id="speak" title="Lire la dernière réponse">🔊 <span>Écouter</span></button></div><button class="send" id="send" type="submit">Envoyer <span>➤</span></button></div></form>
        <p class="disclaimer">Les réponses de démonstration ne remplacent pas un avis professionnel. Vérifiez les informations importantes.</p>
      </section>
      <footer>© 2026 KUMBA TECH · Prototype de présentation · <a href="mailto:Contact@kumbatech.com">Contact</a></footer>
    </main>
  </div>`;
  document.querySelector('#messages').innerHTML='';
  addMessage('assistant',phrases[language].hello+' '+phrases[language].help);
  document.querySelector('#language').addEventListener('change',e=>{language=e.target.value;render();});
  document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>{document.querySelector('#prompt').value=b.dataset.prompt;document.querySelector('#prompt').focus();}));
  document.querySelector('#newChat').addEventListener('click',()=>{render();});
  document.querySelector('#clearChat').addEventListener('click',()=>{document.querySelector('#messages').innerHTML='';addMessage('assistant',phrases[language].hello);});
  document.querySelector('#chatForm').addEventListener('submit',sendMessage);
  document.querySelector('#voice').addEventListener('click',listen);
  document.querySelector('#speak').addEventListener('click',speakLast);
  updateConnection();
}
function updateConnection(){const el=document.querySelector('#connection');el.textContent=navigator.onLine?'● Connecté / API selon configuration':'● Hors connexion — mode local';el.classList.toggle('offline',!navigator.onLine);}
window.addEventListener('online',updateConnection);window.addEventListener('offline',updateConnection);

function demoReply(prompt){
  const p=prompt.toLowerCase();
  if(p.includes('kumba tech')) return 'KUMBA TECH est une entreprise technologique orientée vers le génie logiciel, la mécatronique, la domotique, les énergies renouvelables, l’électronique automobile, les systèmes de sécurité et les infrastructures. KUMBA AI est son projet d’assistant intelligent multilingue.';
  if(p.includes('traduis')||p.includes('traduction')) return 'Exemple de salutation :\\nFrançais : Bonjour, comment allez-vous ?\\nLingala : Mbote, ozali malamu ?\\nKituba : Mbote, nge kele mbote ?\\nTshiluba : Moyo, udi bimpe ?\\nSwahili (RDC) : Habari, uko salama ?\\n\\nCes formulations sont des exemples de démonstration et doivent être validées par des locuteurs natifs.';
  if(p.includes('solaire')) return 'L’énergie solaire transforme la lumière du soleil en électricité grâce à des panneaux photovoltaïques. Un régulateur protège la batterie, qui stocke l’énergie pour alimenter des appareils, même lorsque le soleil ne brille plus.';
  if(p.includes('lettre')) return 'Bien sûr. Indiquez le destinataire, l’objet de la lettre et les idées essentielles. Je pourrai ensuite proposer une version professionnelle à relire.';
  return `Merci pour votre question. Je suis KUMBA AI, prototype de démonstration de KUMBA TECH.\\n\\nVotre message : « ${prompt} »\\n\\nDans la version connectée, cette demande sera transmise au modèle d’intelligence artificielle configuré sur le serveur. En mode hors connexion, seules les fonctions locales de démonstration sont disponibles.`;
}
async function sendMessage(e){
  e.preventDefault();if(busy)return;
  const input=document.querySelector('#prompt');const prompt=input.value.trim();if(!prompt)return;
  input.value='';addMessage('user',prompt);busy=true;document.querySelector('#send').disabled=true;
  let answer='';
  try{
    const base=import.meta.env.VITE_API_BASE_URL||'';
    const res=await fetch(`${base}/api/chat`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:prompt,language})});
    if(!res.ok) throw new Error('API indisponible');
    const data=await res.json();answer=data.reply||demoReply(prompt);
  }catch(_){answer=demoReply(prompt);}
  addMessage('assistant',answer);busy=false;document.querySelector('#send').disabled=false;
}
function listen(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){addMessage('assistant','La dictée vocale n’est pas prise en charge par ce navigateur. Essayez Chrome ou utilisez le clavier.');return;}
  const rec=new SR();rec.lang=({fr:'fr-FR',ln:'ln-CD',kg:'fr-CD',lua:'fr-CD',sw:'sw-CD'})[language]||'fr-FR';rec.interimResults=false;
  rec.onresult=e=>{document.querySelector('#prompt').value=e.results[0][0].transcript;};
  rec.onerror=()=>addMessage('assistant','La reconnaissance vocale n’a pas pu démarrer. Vérifiez les autorisations du microphone et la connexion.');
  rec.start();
}
function speakLast(){
  const msgs=[...document.querySelectorAll('.message.assistant .bubble')];if(!msgs.length)return;
  if(!('speechSynthesis'in window)){addMessage('assistant','La lecture vocale n’est pas disponible sur cet appareil.');return;}
  const u=new SpeechSynthesisUtterance(msgs[msgs.length-1].innerText);
  u.lang=({fr:'fr-FR',ln:'ln-CD',kg:'fr-CD',lua:'fr-CD',sw:'sw-CD'})[language]||'fr-FR';speechSynthesis.speak(u);
}
render();
if('serviceWorker'in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
