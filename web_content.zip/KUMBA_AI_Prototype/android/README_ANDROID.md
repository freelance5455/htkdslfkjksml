Le dossier Android natif est généré sur la machine de déploiement après installation des dépendances :
`cd ../web && npm install && npm run build && npx cap add android && npx cap sync android && npx cap open android`.
Il faut Android Studio et le SDK Android. Le projet Capacitor est configuré dans `web/capacitor.config.json`.
