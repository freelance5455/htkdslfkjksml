
# KUMBA AI — prototype fonctionnel

Prototype PWA installable et wrapper Android via Capacitor, avec API FastAPI optionnelle.

## Ce qui fonctionne dans cette version
- Interface responsive KUMBA AI (mobile, tablette, ordinateur).
- Chat de démonstration utilisable immédiatement, sans clé API.
- Choix des 5 langues : français, Lingala, Kikongo ya Leta (Kituba), Tshiluba et Swahili de RDC.
- Réponses de démonstration et mini-phrases multilingues.
- Synthèse vocale et reconnaissance vocale du navigateur/appareil lorsque disponibles.
- PWA installable et shell mis en cache pour ouvrir l'application hors connexion.
- API backend FastAPI prête à connecter à un fournisseur de modèle compatible OpenAI.
- Projet Android générable avec Capacitor.

## Limite importante du mode hors connexion
Le mode hors connexion de ce prototype conserve l'interface et permet les fonctions de démonstration/phrases locales. Il ne contient pas encore un grand modèle IA ni un modèle vocal complet embarqué. Pour une IA générative réellement hors ligne, il faudra intégrer un modèle compact quantifié, ses poids et un moteur local Android (par exemple llama.cpp), puis mesurer la mémoire, la vitesse et la qualité sur les téléphones ciblés.

## 1. Pré-requis
- Node.js 20+
- npm
- Python 3.10+ (pour l'API)
- Android Studio + Android SDK (pour compiler l'APK)

## 2. Démarrer le frontend
```bash
cd web
npm install
npm run dev
```
Ouvrir l'adresse locale indiquée par Vite.

## 3. Démarrer l'API (facultatif)
Dans un autre terminal :
```bash
cd backend
python -m venv .venv
# Windows : .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Renseigner OPENAI_API_KEY et éventuellement OPENAI_BASE_URL / OPENAI_MODEL
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Le frontend appelle `/api/chat`. En développement, Vite relaie `/api` vers `http://localhost:8000`.

Ne jamais mettre une clé API dans le code frontend ou dans l'application Android. La clé reste côté serveur.

## 4. Déployer sur Internet
- Déployer `web/` sur Vercel, Netlify ou un hébergeur statique après `npm run build`.
- Déployer `backend/` sur un serveur Python/Container avec HTTPS.
- Configurer `VITE_API_BASE_URL` avec l'URL HTTPS du backend avant le build, par exemple :
  `VITE_API_BASE_URL=https://api.votre-domaine.com`
- Configurer CORS dans `backend/.env` avec le domaine frontend.
- Pour la production, ajouter authentification, quotas, journalisation protégée, modération, sauvegardes et politique de confidentialité.

## 5. Générer l'application Android
Depuis `web/` :
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Dans Android Studio : Build > Generate Signed Bundle / APK.
Pour les mises à jour :
```bash
npm run build
npx cap sync android
```
Le dossier `android/` est créé par Capacitor sur la machine de compilation. Il n'est pas pré-généré ici afin d'éviter d'inclure des fichiers SDK spécifiques à votre ordinateur.

## 6. Configuration
Créer `web/.env` :
```env
VITE_API_BASE_URL=
```
Vide = appel relatif `/api` (proxy Vite en développement). En production, indiquer l'URL publique de l'API.

## 7. Langues et qualité
Les cinq langues sont proposées dans l'interface. Les réponses linguistiques du mode démo sont des exemples, pas une validation linguistique. Avant lancement public, faire évaluer les traductions, la reconnaissance vocale et la synthèse par des locuteurs natifs de chaque variété régionale, notamment le Kituba et le Swahili de RDC.

## Identité
KUMBA AI — un produit de KUMBA TECH.
Contact projet : Swikidisa Makaya — CEO & Fondateur, KUMBA TECH.
