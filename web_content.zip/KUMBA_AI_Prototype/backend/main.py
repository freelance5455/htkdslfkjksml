import os
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="KUMBA AI API", version="0.1.0")
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",")]
app.add_middleware(
    CORSMiddleware, allow_origins=origins if origins != ["*"] else ["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    language: str = "fr"

LANGUAGE_NAMES = {
    "fr": "français", "ln": "lingala", "kg": "kikongo ya leta (kituba)",
    "lua": "tshiluba", "sw": "swahili de RDC"
}

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "KUMBA AI API"}

@app.post("/api/chat")
async def chat(payload: ChatRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Fournisseur IA non configuré")
    base = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    lang = LANGUAGE_NAMES.get(payload.language, "français")
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": (
                "Tu es KUMBA AI, assistant de KUMBA TECH. Réponds dans la langue demandée "
                f"({lang}) si tu la maîtrises. Pour les langues congolaises, indique clairement "
                "une incertitude plutôt que d'inventer. Sois utile, respectueux et prudent. "
                "Ne prétends pas remplacer un médecin, avocat ou professionnel certifié."
            )},
            {"role": "user", "content": payload.message}
        ],
        "temperature": 0.4
    }
    async with httpx.AsyncClient(timeout=60) as client:
        try:
            response = await client.post(
                f"{base}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}"},
                json=body
            )
            response.raise_for_status()
            data = response.json()
            return {"reply": data["choices"][0]["message"]["content"]}
        except httpx.HTTPStatusError as exc:
            raise HTTPException(status_code=502, detail=f"Erreur fournisseur IA: {exc.response.status_code}")
        except (httpx.HTTPError, KeyError, IndexError):
            raise HTTPException(status_code=502, detail="Impossible de joindre le fournisseur IA")
