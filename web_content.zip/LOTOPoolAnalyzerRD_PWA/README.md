# LOTOPool Analyzer RD — PWA

Aplicación web progresiva instalable desde Chrome, pensada para Loto Pool LEIDSA (5 números distintos del 01 al 31).

## Funciones
- Registrar, editar y eliminar resultados por fecha.
- Validar cinco números únicos entre 01 y 31 y evitar fechas duplicadas.
- Guardar datos localmente en el navegador (localStorage).
- Consultar frecuencias de números y parejas.
- Generar 5, 10 o 20 combinaciones aleatorias sin duplicados dentro de cada combinación.
- Exportar CSV y respaldo JSON; importar respaldo JSON.
- Service worker para cargar sin conexión después de la primera visita.

## Publicar gratis con GitHub Pages
1. Crea un repositorio público en GitHub, por ejemplo `lotopool-analyzer-rd`.
2. Sube **el contenido** de esta carpeta a la raíz del repositorio (index.html debe quedar en la raíz).
3. En GitHub abre Settings → Pages → Build and deployment y elige `Deploy from a branch`, rama `main`, carpeta `/ (root)`. Guarda.
4. Espera a que GitHub Pages publique la dirección `https://TU-USUARIO.github.io/lotopool-analyzer-rd/`.
5. Abre esa dirección en Chrome Android. Usa el menú ⋮ → `Instalar aplicación` o `Añadir a pantalla de inicio`.

La instalación PWA y el service worker requieren HTTPS (GitHub Pages lo proporciona). Para probar localmente, usa un servidor web local; abrir `index.html` como archivo no activa el modo offline/PWA.

## Privacidad y advertencia
Los datos de sorteos se guardan solo en el almacenamiento del navegador del dispositivo. Exporta respaldos periódicos. Las estadísticas son descriptivas y no predicen sorteos futuros ni cambian las probabilidades de una combinación.
