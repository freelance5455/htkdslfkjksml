# Saif Ullah — Loan & Committee Manager

Complete offline-capable Personal Financial Management & Dynamic App Builder built with React, TypeScript, Tailwind CSS, IndexedDB, and Vite PWA.

## Features
- **Loan Management**: Person-wise opening balances, multiple loan receipts, separate repayment entry, overpayment protection, partial payments, and date/person filters.
- **Committee Management**: Multiple committees, separate installment (outgoing) and payout (incoming) tracking, person-wise and committee-wise ledgers, completely isolated from Loan Payable.
- **Dynamic App Builder (Settings)**:
  - Module & Submodule Builder (create, rename, icon, color, reorder, hide/show, archive, delete).
  - Dynamic Field Builder (12 field types including Text, Number, Currency, Date, Time, Dropdown, Multi-Select, Checkbox, Yes/No, Percentage, Formula, Notes).
  - Visual Formula & Calculation Builder (safe recursive-descent parser without `eval()`, circular reference detection, division-by-zero protection).
  - Field / Cell Mapping across modules & submodules.
  - Dashboard Card Builder & Dynamic Reports Builder (CSV export + Print/PDF).
  - Dropdown & Master Lists Manager.
  - Theme & Colours Customizer with presets.
  - Preview & Test Sandbox (test drafts before publishing without altering live records).
- **Offline PWA & Local Storage**: IndexedDB permanent storage, Service Worker precaching, Web App Manifest, Full JSON/ZIP Backup & Validated Restore, Recycle Bin, and Audit Log.

## Installation & Running Locally
```bash
npm install
npm run dev
```
Open `http://localhost:3000` in Chrome/Edge/Safari.

## Production Build & Offline Packaging
```bash
npm run build
npm run preview
```
To install as a desktop or mobile app (PWA), click the **Install App** button in the top header (or **Share → Add to Home Screen** on iOS Safari).

## Running Unit Tests
```bash
npx --yes tsx --test src/engine/engine.test.ts
```
