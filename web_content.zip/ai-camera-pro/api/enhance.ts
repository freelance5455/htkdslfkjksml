// Серверная функция Vercel: проксирует запрос в Replicate, ключ остаётся на сервере
export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).end();
  const { image, scale = 2, faces = false } = req.body ?? {};
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return res.status(503).json({ error: 'REPLICATE_API_TOKEN не задан' });

  // nightmareai/real-esrgan: апскейл; face_enhance включает восстановление лиц (GFPGAN)
  const r = await fetch('https://api.replicate.com/v1/models/nightmareai/real-esrgan/predictions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Prefer: 'wait=60' },
    body: JSON.stringify({ input: { image, scale, face_enhance: faces } }),
  });
  const data = await r.json();
  // Если модель не успела за 60 сек, output будет пустым: тогда клиент откатится на локальный режим
  if (!r.ok || !data.output) return res.status(502).json({ error: data.detail ?? 'Replicate не вернул результат' });
  res.status(200).json({ url: data.output });
}
