// Конфигурация Vite: React-плагин и доступ с телефона по сети (--host)
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({ plugins: [react()], server: { host: true } });
