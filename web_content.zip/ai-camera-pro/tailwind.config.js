/** @type {import('tailwindcss').Config} */
// Tailwind сканирует HTML и исходники React-компонентов
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {} },
  plugins: [],
};
