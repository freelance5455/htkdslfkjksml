# AI Camera Pro

PWA-камера с многоэтапной AI-обработкой: шумоподавление → AI-увеличение → восстановление лиц → HDR и цвет → портретный боке.

## Запуск

```bash
npm install
npm run dev
```

Откройте http://localhost:5173. Доступ к камере работает только на `localhost` или по HTTPS. Для теста с телефона используйте `npm run dev -- --host` с HTTPS-туннелем либо деплой на Vercel.

## Облачный AI (Replicate)

1. Получите токен на https://replicate.com/account/api-tokens.
2. Создайте `.env.local` по образцу `.env.example`.
3. Запускайте через `npx vercel dev`: он поднимает серверную функцию `/api/enhance`.

Без токена или сети приложение работает в локальном режиме на Canvas.

## Деплой на Vercel

1. Загрузите проект на GitHub и импортируйте его в Vercel (Framework Preset: Vite).
2. В Settings → Environment Variables добавьте `REPLICATE_API_TOKEN`.
3. Нажмите Deploy. Для `api/enhance.ts` в `vercel.json` задан `maxDuration: 60`. На бесплатном плане лимит может быть меньше, проверьте документацию Vercel.

## Ограничения текущей версии

ONNX-модели через onnxruntime-web, отдельные модели MODNet/RVM и SCUNet, Web Worker, ручные ISO и выдержка, HDR-брекетинг пока не реализованы. На iOS Safari `ImageCapture` недоступен, поэтому снимок берётся из кадра видео.
