// Камера: выбор объектива, нативный + цифровой зум, фокус и экспозиция, захват полного кадра
import { useCallback, useEffect, useRef, useState } from 'react';

export type Facing = 'environment' | 'user';

export function useCamera() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facing, setFacing] = useState<Facing>('environment');
  const [zoom, setZoom] = useState(1);                                  // общий зум 1x…10x
  const [optics, setOptics] = useState({ min: 1, max: 1, ok: false });  // возможности нативной оптики
  const [light, setLight] = useState(1);                                // средняя яркость кадра 0…1
  const [error, setError] = useState<string | null>(null);

  const track = () => streamRef.current?.getVideoTracks()[0];

  // Запуск камеры в максимальном разрешении; при смене объектива перезапускаем
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const s = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing, width: { ideal: 3840 }, height: { ideal: 2160 } },
          audio: false,
        });
        if (cancelled) { s.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = s;
        if (videoRef.current) { videoRef.current.srcObject = s; await videoRef.current.play(); }
        // Есть ли у устройства оптический зум (поддерживается applyConstraints)
        const caps: any = s.getVideoTracks()[0].getCapabilities?.() ?? {};
        setOptics(caps.zoom ? { min: caps.zoom.min, max: caps.zoom.max, ok: true } : { min: 1, max: 1, ok: false });
        setError(null);
      } catch (e) {
        setError('Камера недоступна: ' + (e as Error).message);
      }
    })();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    };
  }, [facing]);

  // Нативный зум — в пределах оптики; остаток до 10x — цифровой (масштаб видео и кроп при съёмке)
  const nativeZoom = optics.ok ? Math.min(Math.max(zoom, optics.min), Math.min(optics.max, 10)) : 1;
  const digital = zoom / nativeZoom;

  useEffect(() => {
    if (optics.ok) track()?.applyConstraints({ advanced: [{ zoom: nativeZoom } as any] }).catch(() => {});
  }, [nativeZoom, optics.ok]);

  // Замер яркости: раз в 600 мс по маленькой копии кадра (32×24)
  useEffect(() => {
    const c = document.createElement('canvas');
    c.width = 32; c.height = 24;
    const g = c.getContext('2d')!;
    const id = setInterval(() => {
      const v = videoRef.current;
      if (!v || !v.videoWidth) return;
      g.drawImage(v, 0, 0, 32, 24);
      const d = g.getImageData(0, 0, 32, 24).data;
      let sum = 0;
      for (let i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      setLight(sum / (d.length / 4) / 255);
    }, 600);
    return () => clearInterval(id);
  }, []);

  const flip = useCallback(() => setFacing(f => (f === 'environment' ? 'user' : 'environment')), []);

  // Тап-фокус и экспозиция. x, y — доли 0…1 от области видео
  const focusAt = useCallback((x: number, y: number) => {
    // При цифровом зуме переводим точку в координаты исходного кадра
    const px = 0.5 + (x - 0.5) / digital, py = 0.5 + (y - 0.5) / digital;
    track()?.applyConstraints({
      advanced: [{ pointsOfInterest: [{ x: px, y: py }], focusMode: 'single-shot', exposureMode: 'single-shot' } as any],
    }).catch(() => {});
  }, [digital]);

  // Захват: ImageCapture.takePhoto даёт максимальное разрешение сенсора, иначе берём кадр видео
  const capture = useCallback(async (): Promise<HTMLCanvasElement> => {
    let src: CanvasImageSource = videoRef.current!;
    const t = track();
    const IC = (window as any).ImageCapture;
    if (IC && t) {
      try { src = await createImageBitmap(await new IC(t).takePhoto()); } catch { /* откат к кадру видео */ }
    }
    const W = (src as any).videoWidth ?? (src as any).width;
    const H = (src as any).videoHeight ?? (src as any).height;
    // Цифровой зум: вырезаем центр кадра (полное разрешение сохраняется)
    const sw = W / digital, sh = H / digital, sx = (W - sw) / 2, sy = (H - sh) / 2;
    const c = document.createElement('canvas');
    c.width = Math.round(sw); c.height = Math.round(sh);
    c.getContext('2d')!.drawImage(src, sx, sy, sw, sh, 0, 0, c.width, c.height);
    return c;
  }, [digital]);

  return { videoRef, facing, flip, zoom, setZoom, digital, optics, light, error, focusAt, capture };
}
