// Многоэтапная обработка: шум → апскейл → лица → HDR/цвет → боке.
// Облако (Replicate через /api/enhance) — если доступно, иначе локальный Canvas.
export type Mode = 'auto' | 'night' | 'portrait' | 'pro';
export type Power = 'fast' | 'balanced' | 'ultra';
export interface Opts { mode: Mode; power: Power; strength: number; useAI: boolean; faces: boolean }
export interface StageEvent { index: number; status: 'run' | 'done' | 'skip'; note?: string }

export const STAGES = [
  { id: 'denoise', name: 'Шумоподавление', icon: '🌙' },
  { id: 'upscale', name: 'AI-увеличение', icon: '🔍' },
  { id: 'face', name: 'Восстановление лиц', icon: '🙂' },
  { id: 'hdr', name: 'HDR и цвет', icon: '🎨' },
  { id: 'portrait', name: 'Портретный боке', icon: '👤' },
];

const MAX_PIXELS = 16_000_000;                                           // лимит площади canvas (iOS Safari)
const pause = () => new Promise(r => setTimeout(r, 0));                 // отдаём управление UI между этапами
const make = (w: number, h: number) => {
  const c = document.createElement('canvas');
  c.width = Math.round(w); c.height = Math.round(h);
  return c;
};
const ctx = (c: HTMLCanvasElement) => c.getContext('2d')!;

// Размытие даунскейлом и апскейлом: работает во всех браузерах, включая iOS
function blur(src: HTMLCanvasElement, f: number) {
  const s = make(src.width / f, src.height / f);
  ctx(s).drawImage(src, 0, 0, s.width, s.height);
  const out = make(src.width, src.height);
  ctx(out).drawImage(s, 0, 0, out.width, out.height);
  return out;
}

// Этап 1: шумоподавление — смешиваем кадр с размытой копией (k — сила)
function denoise(src: HTMLCanvasElement, k: number) {
  const out = make(src.width, src.height), g = ctx(out);
  g.drawImage(blur(src, 2), 0, 0);
  g.globalAlpha = 1 - k;
  g.drawImage(src, 0, 0);
  return out;
}

// Этап 2 (локально): интерполяция, не выше лимита пикселей canvas
function localUpscale(src: HTMLCanvasElement, s: number) {
  const m = Math.min(s, Math.sqrt(MAX_PIXELS / (src.width * src.height)));
  if (m <= 1.05) return src;
  const out = make(src.width * m, src.height * m), g = ctx(out);
  g.imageSmoothingQuality = 'high';
  g.drawImage(src, 0, 0, out.width, out.height);
  return out;
}

// Облачный апскейл: Real-ESRGAN (+ GFPGAN для лиц) через прокси; при ошибке вернём null
async function cloudEnhance(src: HTMLCanvasElement, scale: number, max: number, faces: boolean) {
  try {
    // Вход уменьшаем: ограничение размера запроса на Vercel (~4.5 МБ)
    const k = Math.min(1, max / Math.max(src.width, src.height));
    const small = make(src.width * k, src.height * k);
    ctx(small).drawImage(src, 0, 0, small.width, small.height);
    const r = await fetch('/api/enhance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: small.toDataURL('image/jpeg', 0.92), scale, faces }),
    });
    if (!r.ok) return null;
    const { url } = await r.json();
    // Результат грузим напрямую с CDN Replicate (если CORS закрыт — перенесите скачивание в функцию)
    const bmp = await createImageBitmap(await (await fetch(url)).blob());
    const out = make(bmp.width, bmp.height);
    ctx(out).drawImage(bmp, 0, 0);
    return out;
  } catch {
    return null; // нет сети или ключа: откат на локальную обработку
  }
}

// Этап 4: баланс белого (gray-world), подъём теней, S-кривая для микроконтраста, сатурация
function tone(src: HTMLCanvasElement, lift: number, sat: number) {
  const out = make(src.width, src.height), g = ctx(out);
  g.drawImage(src, 0, 0);
  const im = g.getImageData(0, 0, out.width, out.height), d = im.data;
  let R = 0, G = 0, B = 0;
  for (let i = 0; i < d.length; i += 4) { R += d[i]; G += d[i + 1]; B += d[i + 2]; }
  const n = d.length / 4, avg = (R + G + B) / (3 * n);
  // Таблица преобразования для каждого канала (LUT) — быстро даже на 12 МП
  const curve = (gain: number) => {
    const t = new Uint8ClampedArray(256);
    for (let v = 0; v < 256; v++) {
      const x = Math.min(1, (v * gain) / 255);
      const y = Math.pow(x, 1 - lift);
      t[v] = (y * 0.7 + y * y * (3 - 2 * y) * 0.3) * 255;
    }
    return t;
  };
  const cr = curve(avg / ((R / n) || 1)), cg = curve(avg / ((G / n) || 1)), cb = curve(avg / ((B / n) || 1));
  for (let i = 0; i < d.length; i += 4) {
    const r = cr[d[i]], gg = cg[d[i + 1]], b = cb[d[i + 2]];
    const l = 0.299 * r + 0.587 * gg + 0.114 * b;      // яркость для сатурации
    d[i] = l + (r - l) * sat;
    d[i + 1] = l + (gg - l) * sat;
    d[i + 2] = l + (b - l) * sat;
  }
  g.putImageData(im, 0, 0);
  return out;
}

// Этап 5: портретный боке — резкий центр (маска — радиальный градиент), размытый фон
function bokeh(src: HTMLCanvasElement) {
  const w = src.width, h = src.height;
  const mask = make(w, h), mg = ctx(mask);
  const grad = mg.createRadialGradient(w / 2, h * 0.42, 0, w / 2, h * 0.42, Math.max(w, h) * 0.42);
  grad.addColorStop(0, '#fff');
  grad.addColorStop(0.6, '#fff');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  mg.fillStyle = grad;
  mg.fillRect(0, 0, w, h);
  const sharp = make(w, h), sg = ctx(sharp);
  sg.drawImage(src, 0, 0);
  sg.globalCompositeOperation = 'destination-in';   // оставляем резкость только в маске
  sg.drawImage(mask, 0, 0);
  const out = make(w, h), og = ctx(out);
  og.drawImage(blur(src, 8), 0, 0);
  og.drawImage(sharp, 0, 0);
  return out;
}

// Запуск всех этапов по очереди; on() передаёт прогресс в UI
export async function runPipeline(input: HTMLCanvasElement, o: Opts, on: (e: StageEvent) => void) {
  const ev = (index: number, status: StageEvent['status'], note?: string) => on({ index, status, note });
  const k = o.mode === 'pro' ? o.strength : o.mode === 'night' ? 0.6 : 0.25; // сила шумоподавления
  const lift = o.mode === 'night' ? 0.25 : 0.12;                             // подъём теней

  // 1. Шум
  ev(0, 'run'); await pause();
  let cur = denoise(input, k);
  ev(0, 'done', `${Math.round(k * 100)}%`);

  // 2. Апскейл: облако → иначе локально
  ev(1, 'run'); await pause();
  let cloud: HTMLCanvasElement | null = null;
  if (o.useAI && o.power !== 'fast' && navigator.onLine)
    cloud = o.power === 'ultra' ? await cloudEnhance(cur, 4, 1024, o.faces) : await cloudEnhance(cur, 2, 2048, o.faces);
  const before = cur;
  cur = cloud ?? localUpscale(cur, o.power === 'fast' ? 1 : 2);
  ev(1, cur === before ? 'skip' : 'done', cloud ? 'Real-ESRGAN' : 'локально');

  // 3. Лица: GFPGAN выполняется внутри облачного апскейла
  ev(2, 'run'); await pause();
  ev(2, cloud && o.faces ? 'done' : 'skip', cloud && o.faces ? 'GFPGAN' : o.faces ? 'нет облака' : 'выкл.');

  // 4. HDR и цвет
  ev(3, 'run'); await pause();
  cur = tone(cur, lift, o.mode === 'portrait' ? 1.05 : 1.12);
  ev(3, 'done');

  // 5. Боке: только в режиме «Портрет»
  ev(4, 'run'); await pause();
  if (o.mode === 'portrait') { cur = bokeh(cur); ev(4, 'done'); }
  else ev(4, 'skip', 'не портрет');

  return { canvas: cur, cloud: !!cloud };
}
