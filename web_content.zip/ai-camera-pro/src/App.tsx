// App.tsx — главный экран: камера, режимы, AI-обработка, результат, галерея, настройки
import { useEffect, useRef, useState, type MouseEvent, type PointerEvent, type TouchEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useCamera } from './useCamera';
import { runPipeline, STAGES, type Mode, type Power, type StageEvent } from './pipeline';
import { savePhoto, listPhotos, deletePhoto, type Photo } from './db';

type Cfg = { format: 'jpeg' | 'png' | 'webp'; quality: number; power: Power; strength: number; useAI: boolean; faces: boolean };
type Item = Photo & { url: string };                              // элемент галереи с URL миниатюры
type Result = { before: string; after: string; canvas: HTMLCanvasElement; meta: Photo['meta'] };
type View = 'camera' | 'result' | 'gallery' | 'detail';

const DEF: Cfg = { format: 'jpeg', quality: 92, power: 'balanced', strength: 0.4, useAI: true, faces: true };
const MODES: { id: Mode; label: string }[] = [
  { id: 'auto', label: 'Фото' }, { id: 'portrait', label: 'Портрет' }, { id: 'night', label: 'Ночь' }, { id: 'pro', label: 'Pro' },
];
const PAGE = 'absolute inset-0 z-10 flex flex-col gap-3 bg-black p-4 pt-[max(1rem,env(safe-area-inset-top))] pb-[max(1rem,env(safe-area-inset-bottom))]';

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const toBlob = (c: HTMLCanvasElement, type: string, q: number) => new Promise<Blob>(r => c.toBlob(b => r(b!), type, q));
const toUrl = async (c: HTMLCanvasElement) => URL.createObjectURL(await toBlob(c, 'image/jpeg', 0.9));
const ext = (b: Blob) => b.type.split('/')[1] || 'jpg';

// Скачивание файла
function download(b: Blob, name: string) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
// Web Share API с откатом на скачивание
async function share(b: Blob, name: string) {
  const file = new File([b], name, { type: b.type });
  if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], title: 'AI Camera Pro' });
  else download(b, name);
}

// Сравнение «до/после» свайпом
function Compare({ before, after }: { before: string; after: string }) {
  const [p, setP] = useState(50);
  const move = (e: PointerEvent<HTMLDivElement>) => {
    if (!e.buttons) return;
    const r = e.currentTarget.getBoundingClientRect();
    setP(clamp(((e.clientX - r.left) / r.width) * 100, 0, 100));
  };
  return (
    <div className="relative mx-auto aspect-[3/4] w-full max-w-md touch-none overflow-hidden rounded-2xl"
      onPointerDown={move} onPointerMove={move}>
      <img src={after} alt="После" className="absolute inset-0 h-full w-full object-cover" />
      <img src={before} alt="До" className="absolute inset-0 h-full w-full object-cover"
        style={{ clipPath: `inset(0 ${100 - p}% 0 0)` }} />
      <div className="absolute inset-y-0 w-0.5 bg-white" style={{ left: `${p}%` }} />
      <span className="glass absolute left-3 top-3 rounded-full px-3 py-1 text-xs">До</span>
      <span className="glass absolute right-3 top-3 rounded-full px-3 py-1 text-xs">После AI</span>
    </div>
  );
}

export default function App() {
  const cam = useCamera();
  const [view, setView] = useState<View>('camera');
  const [mode, setMode] = useState<Mode>('auto');
  const [cfg, setCfg] = useState<Cfg>(() => {
    try { return { ...DEF, ...JSON.parse(localStorage.getItem('aicam') || '{}') }; } catch { return DEF; }
  });
  const [showCfg, setShowCfg] = useState(false);
  const [busy, setBusy] = useState(false);
  const [stages, setStages] = useState<Record<number, StageEvent>>({});
  const [result, setResult] = useState<Result | null>(null);
  const [gallery, setGallery] = useState<Item[]>([]);
  const [detail, setDetail] = useState<Item | null>(null);
  const [ring, setRing] = useState<{ x: number; y: number; k: number } | null>(null);
  const [roll, setRoll] = useState(0);
  const pinch = useRef<number | null>(null);
  const done = Object.values(stages).filter(s => s.status !== 'run').length;

  const set = <K extends keyof Cfg>(k: K, v: Cfg[K]) => setCfg(c => ({ ...c, [k]: v }));
  const encode = (c: HTMLCanvasElement) => toBlob(c, `image/${cfg.format}`, cfg.quality / 100);

  // Настройки сохраняем в localStorage
  useEffect(() => { localStorage.setItem('aicam', JSON.stringify(cfg)); }, [cfg]);
  // Горизонт: наклон устройства (на iOS нужно разрешение, см. README)
  useEffect(() => {
    const h = (e: DeviceOrientationEvent) => setRoll(e.gamma ?? 0);
    window.addEventListener('deviceorientation', h);
    return () => window.removeEventListener('deviceorientation', h);
  }, []);

  const refresh = async () => {
    const list = await listPhotos();
    setGallery(list.map(p => ({ ...p, url: URL.createObjectURL(p.thumb) })).sort((a, b) => b.meta.date - a.meta.date));
  };
  useEffect(() => { refresh(); }, []);

  // Съёмка → многоэтапная обработка → результат → автосохранение в галерею
  const shoot = async () => {
    if (busy) return;
    setBusy(true); setStages({});
    try {
      const raw = await cam.capture();
      const { canvas, cloud } = await runPipeline(raw,
        { mode, power: cfg.power, strength: cfg.strength, useAI: cfg.useAI, faces: cfg.faces },
        e => setStages(s => ({ ...s, [e.index]: e })));
      const meta: Photo['meta'] = {
        mode, zoom: +cam.zoom.toFixed(1),
        model: cloud ? 'Real-ESRGAN (Replicate)' : 'Local (Canvas)', date: Date.now(),
      };
      setResult({ before: await toUrl(raw), after: await toUrl(canvas), canvas, meta });
      setView('result');
      // Миниатюра 360 px и запись в IndexedDB
      const k = 360 / Math.max(canvas.width, canvas.height);
      const thumb = Object.assign(document.createElement('canvas'), { width: canvas.width * k, height: canvas.height * k });
      ctx2d(thumb).drawImage(canvas, 0, 0, thumb.width, thumb.height);
      await savePhoto({ id: crypto.randomUUID(), blob: await encode(canvas), thumb: await toBlob(thumb, 'image/jpeg', 0.8), meta });
      refresh();
    } catch (e) {
      alert('Ошибка обработки: ' + (e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const ctx2d = (c: HTMLCanvasElement) => c.getContext('2d')!;

  // Pinch-to-zoom двумя пальцами
  const onTouchMove = (e: TouchEvent) => {
    if (e.touches.length !== 2) return;
    const [a, b] = [e.touches[0], e.touches[1]];
    const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
    if (pinch.current) cam.setZoom(z => clamp(z * (d / pinch.current!), 1, 10));
    pinch.current = d;
  };

  // Тап-фокус: показываем рамку на месте касания
  const tap = (e: MouseEvent<HTMLVideoElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    cam.focusAt(x, y);
    setRing({ x, y, k: Date.now() });
    setTimeout(() => setRing(null), 900);
  };

  const cameraView = (
    <div className="h-full w-full touch-none overflow-hidden bg-black" onTouchMove={onTouchMove} onTouchEnd={() => { pinch.current = null; }}>
      <video ref={cam.videoRef} playsInline muted autoPlay onClick={tap}
        className="absolute inset-0 h-full w-full object-cover"
        style={{ transform: `scale(${cam.digital})`, touchAction: 'none' }} />

      {/* Сетка третей и горизонт */}
      <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3">
        {Array.from({ length: 9 }, (_, i) => <div key={i} className="border border-white/15" />)}
      </div>
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-px w-[150%]"
        style={{
          background: Math.abs(roll) < 1.5 ? '#facc15' : 'rgba(255,255,255,0.5)',
          transform: `translate(-50%,-50%) rotate(${-roll}deg)`,
        }} />

      {/* Рамка фокуса */}
      <AnimatePresence>
        {ring && (
          <motion.div key={ring.k} initial={{ scale: 1.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ opacity: 0 }}
            className="pointer-events-none absolute h-16 w-16 rounded-md border-2 border-yellow-300"
            style={{ left: `${ring.x * 100}%`, top: `${ring.y * 100}%`, marginLeft: -32, marginTop: -32 }} />
        )}
      </AnimatePresence>

      {/* Верхняя панель */}
      <div className="absolute inset-x-0 top-0 flex items-center justify-between p-4 pt-[max(1rem,env(safe-area-inset-top))]">
        <button className="glass rounded-full px-3 py-2 text-sm" onClick={() => setView('gallery')}>🖼 Галерея</button>
        <span className="glass rounded-full px-3 py-2 text-xs">💡 {Math.round(cam.light * 100)}%</span>
        <button className="glass rounded-full px-3 py-2 text-sm" onClick={() => setShowCfg(true)}>⚙️</button>
      </div>
      {cam.light < 0.18 && (
        <div className="glass absolute left-1/2 top-20 -translate-x-1/2 whitespace-nowrap rounded-full px-4 py-2 text-xs">
          🌙 Мало света — попробуйте режим «Ночь»
        </div>
      )}
      {cam.error && <div className="absolute inset-0 flex items-center justify-center p-8 text-center text-red-300">{cam.error}</div>}

      {/* Зум: метка фокусного расстояния, пресеты и слайдер */}
      <div className="absolute inset-x-0 bottom-52 flex flex-col items-center gap-2">
        <div className="glass rounded-full px-3 py-1 text-xs">
          {cam.zoom.toFixed(1)}× · ≈{Math.round(24 * cam.zoom)} мм · {cam.digital > 1.01 ? 'цифровой' : 'оптический'}
        </div>
        <div className="flex gap-2">
          {[1, 2, 5, 10].map(z => (
            <button key={z} onClick={() => cam.setZoom(z)}
              className={`glass rounded-full px-3 py-1 text-xs ${Math.abs(cam.zoom - z) < 0.05 ? 'text-yellow-300' : ''}`}>{z}×</button>
          ))}
        </div>
        <input type="range" min={1} max={10} step={0.1} value={cam.zoom}
          onChange={e => cam.setZoom(+e.target.value)} className="w-2/3 accent-yellow-300" />
      </div>

      {/* Режимы и спуск затвора */}
      <div className="absolute inset-x-0 bottom-0 flex flex-col items-center gap-4 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-4">
        <div className="glass flex gap-1 rounded-full p-1">
          {MODES.map(m => (
            <button key={m.id} onClick={() => setMode(m.id)}
              className={`rounded-full px-4 py-1.5 text-sm ${mode === m.id ? 'bg-white text-black' : 'text-white/80'}`}>{m.label}</button>
          ))}
        </div>
        <div className="flex w-full items-center justify-around">
          <button onClick={cam.flip} className="glass h-12 w-12 rounded-full text-lg">🔄</button>
          <motion.button whileTap={{ scale: 0.9 }} onClick={shoot} disabled={busy}
            className="flex h-20 w-20 items-center justify-center rounded-full border-4 border-white">
            <span className="h-14 w-14 rounded-full bg-white" />
          </motion.button>
          <div className="w-12" />
        </div>
      </div>
    </div>
  );

  const resultView = result && (
    <div className={PAGE}>
      <div className="flex items-center justify-between text-sm">
        <button onClick={() => setView('camera')}>← Камера</button>
        <span className="text-white/60">{result.meta.model} · {result.meta.zoom}×</span>
      </div>
      <Compare before={result.before} after={result.after} />
      <div className="mt-auto grid grid-cols-2 gap-3">
        <button className="glass rounded-2xl py-3" onClick={async () => download(await encode(result.canvas), `aicam-${Date.now()}.${cfg.format}`)}>💾 Экспорт</button>
        <button className="glass rounded-2xl py-3" onClick={async () => share(await encode(result.canvas), `aicam-${Date.now()}.${cfg.format}`)}>↗️ Поделиться</button>
      </div>
    </div>
  );

  const galleryView = (
    <div className={PAGE}>
      <div className="flex justify-between text-sm">
        <button onClick={() => setView('camera')}>← Камера</button>
        <span className="text-white/60">{gallery.length} фото</span>
      </div>
      <div className="grid flex-1 grid-cols-3 content-start gap-1 overflow-y-auto">
        {gallery.map(p => (
          <button key={p.id} onClick={() => { setDetail(p); setView('detail'); }}>
            <img src={p.url} alt="" className="aspect-square w-full rounded-lg object-cover" />
          </button>
        ))}
        {gallery.length === 0 && <p className="col-span-3 py-10 text-center text-white/50">Пока пусто — сделайте первый снимок</p>}
      </div>
    </div>
  );

  const detailView = detail && (
    <div className={PAGE}>
      <button className="self-start text-sm" onClick={() => setView('gallery')}>← Галерея</button>
      <img src={URL.createObjectURL(detail.blob)} alt="" className="min-h-0 flex-1 w-full rounded-2xl object-contain" />
      <p className="text-center text-xs text-white/60">
        {detail.meta.model} · {detail.meta.zoom}× · {new Date(detail.meta.date).toLocaleString('ru')}
      </p>
      <div className="grid grid-cols-3 gap-3">
        <button className="glass rounded-2xl py-3" onClick={() => download(detail.blob, `aicam-${detail.id}.${ext(detail.blob)}`)}>💾</button>
        <button className="glass rounded-2xl py-3" onClick={() => share(detail.blob, `aicam-${detail.id}.${ext(detail.blob)}`)}>↗️</button>
        <button className="glass rounded-2xl py-3 text-red-300" onClick={async () => { await deletePhoto(detail.id); await refresh(); setView('gallery'); }}>🗑</button>
      </div>
    </div>
  );

  // Настройки обработки и экспорта (нижняя шторка)
  const settingsView = showCfg && (
    <div className="absolute inset-0 z-40 flex items-end bg-black/60" onClick={() => setShowCfg(false)}>
      <div className="glass w-full space-y-4 rounded-t-3xl p-6 pb-[max(1.5rem,env(safe-area-inset-bottom))]" onClick={e => e.stopPropagation()}>
        <h2 className="text-lg font-semibold">Настройки</h2>
        <label className="flex justify-between text-sm">AI-обработка
          <input type="checkbox" checked={cfg.useAI} onChange={e => set('useAI', e.target.checked)} /></label>
        <label className="flex justify-between text-sm">Восстановление лиц (GFPGAN)
          <input type="checkbox" checked={cfg.faces} onChange={e => set('faces', e.target.checked)} /></label>
        <label className="block text-sm">Мощность AI: {cfg.power}
          <select className="mt-1 w-full rounded-xl bg-black/40 p-2" value={cfg.power} onChange={e => set('power', e.target.value as Power)}>
            <option value="fast">Fast (локально)</option>
            <option value="balanced">Balanced (2×)</option>
            <option value="ultra">Ultra (3×, ниже вход)</option>
          </select></label>
        <label className="block text-sm">Сила шумоподавления (режим Pro): {Math.round(cfg.strength * 100)}%
          <input type="range" min={0} max={1} step={0.05} value={cfg.strength} onChange={e => set('strength', +e.target.value)} className="w-full accent-yellow-300" /></label>
        <label className="block text-sm">Формат экспорта
          <select className="mt-1 w-full rounded-xl bg-black/40 p-2" value={cfg.format} onChange={e => set('format', e.target.value as Cfg['format'])}>
            <option value="jpeg">JPEG</option><option value="png">PNG</option><option value="webp">WebP</option>
          </select></label>
        <label className="block text-sm">Качество (JPEG/WebP): {cfg.quality}%
          <input type="range" min={60} max={100} value={cfg.quality} onChange={e => set('quality', +e.target.value)} className="w-full accent-yellow-300" /></label>
      </div>
    </div>
  );

  // Оверлей прогресса: пять этапов с иконками и статусом
  const processing = (
    <motion.div key="proc" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-5 bg-black/80 p-6 backdrop-blur-xl">
      <div className="text-lg font-semibold">AI-обработка</div>
      <div className="h-2 w-full max-w-sm overflow-hidden rounded-full bg-white/10">
        <motion.div className="h-full bg-gradient-to-r from-cyan-400 to-violet-500"
          animate={{ width: `${(done / STAGES.length) * 100}%` }} />
      </div>
      <ul className="w-full max-w-sm space-y-2">
        {STAGES.map((s, i) => {
          const st = stages[i];
          return (
            <li key={s.id} className={`glass flex justify-between rounded-xl px-4 py-2 text-sm ${st?.status === 'run' ? 'animate-pulse' : ''}`}>
              <span>{s.icon} {s.name}</span>
              <span className="text-white/60">{st?.status === 'run' ? '…' : st?.note ?? (st ? '✓' : '')}</span>
            </li>
          );
        })}
      </ul>
    </motion.div>
  );

  return (
    <div className="relative h-full w-full overflow-hidden bg-black text-white">
      <div className={view === 'camera' ? 'absolute inset-0' : 'hidden'}>{cameraView}</div>
      {view === 'result' && resultView}
      {view === 'gallery' && galleryView}
      {view === 'detail' && detailView}
      {settingsView}
      <AnimatePresence>{busy && processing}</AnimatePresence>
    </div>
  );
}
