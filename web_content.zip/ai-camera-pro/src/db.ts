// Галерея: IndexedDB (оригинал, миниатюра и метаданные: режим, зум, модель AI, дата)
export interface Photo {
  id: string;
  blob: Blob;
  thumb: Blob;
  meta: { mode: string; zoom: number; model: string; date: number };
}

const NAME = 'aicamera', STORE = 'photos';

function open(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const req = indexedDB.open(NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'id' });
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

// Выполняем запрос в транзакции и возвращаем его результат
async function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise((res, rej) => {
    const t = db.transaction(STORE, mode);
    const r = fn(t.objectStore(STORE));
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}

export const savePhoto = (p: Photo) => run('readwrite', s => s.put(p));
export const listPhotos = () => run<Photo[]>('readonly', s => s.getAll());
export const deletePhoto = (id: string) => run('readwrite', s => s.delete(id));
