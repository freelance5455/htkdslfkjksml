// PostCSS: Tailwind + автопрефиксы для старых WebKit/iOS
export default { plugins: { tailwindcss: {}, autoprefixer: {} } };
