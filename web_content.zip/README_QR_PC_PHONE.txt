NEXUS TAEKWONDO QR PC + PHONE APP
Staff login: owner / 1234
Added: Staff QR camera scanner + Customer ID fallback.
PC: open index.html in Chrome/Edge and allow camera.
Phone: ZIP-to-APK/WebView converter; camera QR requires a modern WebView.
If phone converter does not support BarcodeDetector, use Customer ID fallback.
