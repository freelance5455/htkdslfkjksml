"""VideoGenie local app. Run:  python app.py   then open http://127.0.0.1:5000"""
import json, os, threading, time, uuid, traceback
from flask import Flask, jsonify, request, send_from_directory, Response
import pipeline

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output")
CFG = os.path.join(HERE, "config.json")
app = Flask(__name__)
JOBS = {}
SAVED = "********"


def _num(v, default, typ):
    try:
        return typ(v)
    except (TypeError, ValueError):
        return default


def load_cfg():
    try:
        return json.load(open(CFG, encoding="utf-8"))
    except Exception:
        return {}


def worker(jid, cfg):
    job = JOBS[jid]

    def log(msg, pct=None):
        job["log"].append(msg)
        if pct is not None:
            job["pct"] = round(pct)

    try:
        out, files = pipeline.run(cfg, log, lambda: job["cancel"])
        job.update(done=True, folder=os.path.basename(out), files=files)
    except pipeline.Cancelled:
        job.update(done=True, error="Stopped. Start again with 'Resume' ticked to continue.")
    except Exception as e:
        traceback.print_exc()
        job.update(done=True, error=str(e))


@app.get("/")
def index():
    return Response(PAGE, mimetype="text/html")


@app.get("/config")
def config():
    c = load_cfg()
    return jsonify({"gemini_key": SAVED if c.get("gemini_key") else "", "pexels_key": SAVED if c.get("pexels_key") else "",
                    "model": c.get("model", "")})


@app.post("/start")
def start():
    d = request.get_json(force=True)
    cfg = {
        "topic": d.get("topic", ""), "script": d.get("script", ""),
        "minutes": max(1, min(60, _num(d.get("minutes"), 5, int))),
        "lang": d.get("lang", "en-IN"), "ratio": d.get("ratio", "16:9"), "quality": d.get("quality", "720"),
        "provider": d.get("provider", "pollinations"), "style": d.get("style") or "cinematic, high quality, detailed",
        "speed": max(0.5, min(1.5, _num(d.get("speed"), 1.0, float))), "gemini_key": d.get("gemini_key", "").strip(),
        "pexels_key": d.get("pexels_key", "").strip(), "model": (d.get("model") or "gemini-2.0-flash").strip(),
        "resume": bool(d.get("resume")), "output_dir": OUT,
    }
    old = load_cfg()
    for k in ("gemini_key", "pexels_key"):
        if cfg[k] == SAVED:
            cfg[k] = old.get(k, "")
    json.dump({k: cfg[k] for k in ("gemini_key", "pexels_key", "model")}, open(CFG, "w"))
    if any(j["done"] is False for j in JOBS.values()):
        return jsonify(error="A video is already being made. Wait or press Stop."), 409
    jid = uuid.uuid4().hex[:8]
    JOBS[jid] = {"log": [], "pct": 0, "done": False, "cancel": False}
    threading.Thread(target=worker, args=(jid, cfg), daemon=True).start()
    return jsonify(id=jid)


@app.get("/status/<jid>")
def status(jid):
    j = JOBS.get(jid)
    if not j:
        return jsonify(error="unknown job"), 404
    return jsonify(log=j["log"][-40:], pct=j["pct"], done=j["done"], error=j.get("error"),
                   folder=j.get("folder"), files=j.get("files", []))


@app.post("/stop/<jid>")
def stop(jid):
    if jid in JOBS:
        JOBS[jid]["cancel"] = True
    return jsonify(ok=True)


@app.get("/file/<folder>/<name>")
def get_file(folder, name):
    return send_from_directory(os.path.join(OUT, folder), name, as_attachment=request.args.get("dl") == "1")


PAGE = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>VideoGenie</title><style>
:root{--bg:#F6F5FB;--card:#fff;--ink:#16152B;--mute:#6B6A85;--line:#E0DEF0;--brand:#5B5BD6}
@media(prefers-color-scheme:dark){:root{--bg:#12111F;--card:#1C1B30;--ink:#F1F0FA;--mute:#A09FBD;--line:#34325A;--brand:#7C7CF0}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,sans-serif;line-height:1.5}
main{max-width:760px;margin:0 auto;padding:16px 14px 60px}h1{margin:6px 0 2px}.sub{color:var(--mute);margin:0 0 14px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;margin-bottom:14px}
label{display:block;font-weight:600;margin:10px 0 4px}label.c{font-weight:400;display:flex;gap:8px;align-items:center}
.h{font-weight:400;color:var(--mute);font-size:.82rem}
input,select,textarea{width:100%;font:inherit;color:var(--ink);background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:10px}
input[type=checkbox]{width:auto}textarea{min-height:120px}.r{display:grid;grid-template-columns:1fr 1fr;gap:10px}
button,a.b{display:block;width:100%;margin-top:12px;padding:13px;border:0;border-radius:12px;background:var(--brand);color:#fff;font:700 1rem system-ui;text-align:center;text-decoration:none;cursor:pointer}
button.a{background:none;color:var(--brand);border:1px solid var(--brand)}button:disabled{opacity:.5}
.bar{height:8px;background:var(--line);border-radius:4px;overflow:hidden;margin-top:10px}.bar i{display:block;height:100%;width:0;background:var(--brand)}
pre{background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:10px;max-height:220px;overflow:auto;white-space:pre-wrap;font-size:.82rem;margin:10px 0 0}
.err{color:#d33;font-weight:600}video,img{max-width:100%;border-radius:10px;margin-top:10px}[hidden]{display:none!important}
</style></head><body><main>
<h1>VideoGenie</h1><p class="sub">Topic or script in. Video with scene images, voice-over, thumbnail and SEO out.</p>
<div class="card">
<label for="topic">Video topic</label><input id="topic" value="How to save money every month">
<div class="r"><div><label for="minutes">Video length (minutes)</label><input id="minutes" type="number" min="1" max="60" value="5"></div>
<div><label for="lang">Language and voice</label><select id="lang"><option value="en-IN">English (India, female)</option><option value="en-US">English (US, female)</option><option value="hi">Hindi (female)</option><option value="hi-m">Hindi (male)</option></select></div></div>
<div class="r"><div><label for="ratio">Format</label><select id="ratio"><option>16:9</option><option>9:16</option><option>1:1</option></select></div>
<div><label for="quality">Quality</label><select id="quality"><option value="720">720p (better)</option><option value="480">480p (faster)</option></select></div></div>
<div class="r"><div><label for="provider">Images</label><select id="provider"><option value="pollinations">AI images (free, no key)</option><option value="pexels">Stock photos (Pexels key)</option><option value="placeholder">Simple (offline test)</option></select></div>
<div><label for="speed">Voice speed</label><select id="speed"><option value="0.9">Slow</option><option value="1" selected>Normal</option><option value="1.15">Fast</option></select></div></div>
<label for="style">Image style <span class="h">for AI images</span></label><input id="style" value="cinematic, high quality, detailed">
<label for="script">Your own script <span class="h">Optional. Leave empty to let Gemini write it.</span></label><textarea id="script"></textarea>
<label for="gk">Gemini API key <span class="h">free at aistudio.google.com. Needed to auto-write script, image ideas and SEO.</span></label><input id="gk" type="password" autocomplete="off">
<label for="pk">Pexels API key <span class="h">only for stock photos (pexels.com/api)</span></label><input id="pk" type="password" autocomplete="off">
<label for="model">Gemini model</label><input id="model" value="gemini-2.0-flash">
<label class="c"><input type="checkbox" id="resume"> Resume the previous run of this topic</label>
<button id="go">Create video</button><button class="a" id="stop" hidden>Stop</button>
</div>
<div class="card" id="prog" hidden><b id="pt">Starting…</b><div class="bar"><i id="pb"></i></div><pre id="lg"></pre></div>
<div class="card" id="res" hidden><video id="vid" controls></video><img id="th" alt="Thumbnail">
<a class="b" id="dv" download>Download video</a><a class="b" id="dt" download>Download thumbnail</a><a class="b" id="ds" target="_blank">Open SEO and tags</a><a class="b" id="dc" target="_blank">Open script</a></div>
</main><script>
var $=function(i){return document.getElementById(i)},jid=null,tm=null;
fetch('/config').then(function(r){return r.json()}).then(function(c){$('gk').value=c.gemini_key||'';$('pk').value=c.pexels_key||'';if(c.model)$('model').value=c.model});
$('go').onclick=function(){
 var d={};['topic','minutes','lang','ratio','quality','provider','speed','style','script','model'].forEach(function(k){d[k]=$(k).value});
 d.gemini_key=$('gk').value;d.pexels_key=$('pk').value;d.resume=$('resume').checked;
 $('go').disabled=true;$('res').hidden=true;$('prog').hidden=false;$('lg').textContent='';$('pb').style.width='0';$('pt').className='';$('pt').textContent='Starting…';
 fetch('/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(r){return r.json()}).then(function(j){
  if(j.error){$('pt').textContent=j.error;$('pt').className='err';$('go').disabled=false;return}
  jid=j.id;$('stop').hidden=false;tm=setInterval(poll,2000);poll()});
};
$('stop').onclick=function(){fetch('/stop/'+jid,{method:'POST'});$('pt').textContent='Stopping…'};
function poll(){fetch('/status/'+jid).then(function(r){return r.json()}).then(function(s){
 $('pb').style.width=s.pct+'%';$('lg').textContent=s.log.join('\\n');$('lg').scrollTop=1e9;
 if(!s.done){$('pt').textContent='Working… '+s.pct+'%';return}
 clearInterval(tm);$('go').disabled=false;$('stop').hidden=true;
 if(s.error){$('pt').textContent=s.error;$('pt').className='err';return}
 $('pt').textContent='Finished';var b='/file/'+s.folder+'/';
 $('vid').src=b+'video.mp4';$('th').src=b+'thumbnail.jpg';
 $('dv').href=b+'video.mp4?dl=1';$('dt').href=b+'thumbnail.jpg?dl=1';$('ds').href=b+'seo.txt';$('dc').href=b+'script.txt';$('res').hidden=false;});}
</script></body></html>"""

if __name__ == "__main__":
    import socket, sys
    os.makedirs(OUT, exist_ok=True)
    lan = "--lan" in sys.argv
    if lan:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except Exception:
            ip = "YOUR-PC-IP"
        print(f"\nVideoGenie is running for your phone app.\nIn the app, enter:  http://{ip}:5000\n"
              "(Phone and computer must be on the same Wi-Fi. Anyone on that Wi-Fi can open it.)\n")
    else:
        print("\nVideoGenie is running. Open  http://127.0.0.1:5000  in your browser.\n")
    app.run(host="0.0.0.0" if lan else "127.0.0.1", port=5000, threaded=True)
