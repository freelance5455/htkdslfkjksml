# VideoGenie Pro

> `index.html` aur `lite.html` APK builder ke liye hain (app ki screen). Baaki files (`app.py`, `pipeline.py`) computer par chalne wala asli video maker hain.

Topic ya script do -> ye banata hai: har scene ki image, awaaz (voice-over) ke saath video, thumbnail, SEO, tags aur script.
Lambi video (30 minute tak, 60 tak allowed) bhi ban sakti hai.

## Ye kahan chalta hai
Ye APK ke andar nahi chalta. Ye ek programme hai jo **computer (Windows/Mac/Linux)** par chalta hai,
ya **Android phone par Termux** me. Chalane ke baad aap browser me `http://127.0.0.1:5000` kholte ho.

## Windows
1. Python 3.10+ install karo (python.org, "Add to PATH" tick karo).
2. ffmpeg install karo (ffmpeg.org ya `winget install ffmpeg`).
3. Is folder me `start.bat` par double-click karo.
4. Browser me http://127.0.0.1:5000 kholo.

## Mac / Linux
```
chmod +x start.sh && ./start.sh
```
(ffmpeg pehle install karo: `brew install ffmpeg` ya `sudo apt install ffmpeg`)

## Android (Termux)
Termux F-Droid se install karo, phir:
```
pkg update
pkg install python ffmpeg python-pillow
pip install flask requests edge-tts
cd <is folder ka path>
python app.py
```
Phir Chrome me http://127.0.0.1:5000 kholo. Phone me render slow hota hai, 480p chuno.

## Keys (dono free)
- **Gemini API key** (aistudio.google.com): script, image ideas aur SEO likhne ke liye. Bina key ke aap apni script paste kar sakte ho.
- **Pexels key** (pexels.com/api): sirf tab, jab asli stock photos chahiye. Default "AI images" me key nahi chahiye.

Keys sirf aapke computer ki `config.json` me save hoti hain.

## Output
`output/<topic>/` me: `video.mp4`, `thumbnail.jpg`, `seo.txt` (titles, description, chapters, tags, hashtags), `script.txt`.

## Dhyan rakhne wali baatein
- **Awaaz ke liye internet chahiye** (edge-tts, free Microsoft voices, Hindi bhi). Internet na ho to scenes silent ban sakte hain, aur log me WARNING dikhegi.
- **Time lagta hai.** 30 minute ki video me lagbhag 120 images aur awaazen banti hain. PC par aam taur par 30-90 minute, phone par zyada. Screen on rakho.
- Beech me ruk jaye to "Resume the previous run" tick karke dobara chalao. Bani hui images/awaaz dobara nahi banti.
- AI images free service (Pollinations) se aati hain. Kabhi slow ya fail ho sakti hain. Fail hone par simple placeholder lagta hai (log me likha aata hai).
- AI-generated content (script, images, awaaz) YouTube par upload karte waqt platform ke AI-disclosure rules dekh lena.

## Phone app (APK) se jodna
`start-for-phone-app.bat` (ya `.sh`) chalao. Wo ek address dikhayega, jaise `http://192.168.1.5:5000`.
APK ke andar wo address daalo (APK ka ZIP `VideoGenie-APK.zip` me hai). Phone aur computer ek hi Wi-Fi par hone chahiye.
Agar app "http" address nahi kholta, to ngrok ya cloudflared se https link banao aur wo daalo.

## Hindi thumbnail
Thumbnail me Hindi text ke liye computer me Hindi font chahiye (Windows me Nirmala, Android me Noto hota hai).
Font na mile to thumbnail English text se banta hai aur log me Note dikhta hai.
