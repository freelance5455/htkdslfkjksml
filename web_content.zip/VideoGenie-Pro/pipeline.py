"""VideoGenie pipeline: script -> scene images -> voice-over -> video + thumbnail + SEO."""
import asyncio, hashlib, json, math, os, random, re, shutil, subprocess, time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
import requests
from PIL import Image, ImageDraw, ImageFont

SEC_PER_SCENE = 15          # one scene is roughly 15 seconds of narration
WORDS_PER_SCENE = 38
FPS = 25
LANGS = {
    "en-IN": {"label": "English", "voice": "en-IN-NeerjaNeural"},
    "en-US": {"label": "English", "voice": "en-US-AriaNeural"},
    "hi":    {"label": "Hindi (Devanagari script)", "voice": "hi-IN-SwaraNeural"},
    "hi-m":  {"label": "Hindi (Devanagari script)", "voice": "hi-IN-MadhurNeural"},
}
SIZES = {  # (ratio, quality) -> (w, h)
    ("16:9", "720"): (1280, 720), ("16:9", "480"): (854, 480),
    ("9:16", "720"): (720, 1280), ("9:16", "480"): (480, 854),
    ("1:1", "720"): (1080, 1080), ("1:1", "480"): (720, 720),
}
STOP = set("the a an and or but if of to in on at for with from by is are was were be been it this that these those you your we our they their i he she as so not no can will just about into than then there what when which who how why do does did have has had more most very also".split())


class Cancelled(Exception):
    pass


def need_ffmpeg():
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        raise RuntimeError("ffmpeg is not installed. Install it first (see README), then try again.")


def sh(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise RuntimeError("ffmpeg error: " + (r.stderr or "")[-600:])
    return r.stdout


def duration(path):
    return float(sh(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).strip())


def slug(s):
    s = re.sub(r"[^\w]+", "-", s.lower(), flags=re.U).strip("-")
    return (s[:40] or "video")


def clean_tts(t):
    t = re.sub(r"[*_#`~>\[\]]", "", t)
    return re.sub(r"\s+", " ", t).strip()


def fmt_time(sec):
    sec = int(sec)
    h, m, s = sec // 3600, (sec % 3600) // 60, sec % 60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ---------------------------------------------------------------- Gemini
def gemini(key, model, prompt, as_json=False):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if as_json:
        body["generationConfig"] = {"responseMimeType": "application/json"}
    last = None
    for attempt in range(4):
        try:
            r = requests.post(url, params={"key": key}, json=body, timeout=120)
            j = r.json()
            if r.status_code == 429 or r.status_code >= 500:
                last = RuntimeError(j.get("error", {}).get("message", f"HTTP {r.status_code}"))
                time.sleep(5 * (attempt + 1))
                continue
            if r.status_code != 200:
                raise RuntimeError(j.get("error", {}).get("message", f"HTTP {r.status_code}"))
            text = j["candidates"][0]["content"]["parts"][0]["text"]
            if as_json:
                return json.loads(re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip())
            return text
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            last = e
            time.sleep(2)
        except requests.RequestException as e:
            last = e
            time.sleep(3 * (attempt + 1))
    raise RuntimeError(f"Gemini failed: {last}")


def keywords_from(text, topic):
    words = [w for w in re.findall(r"[A-Za-z]{4,}", text.lower()) if w not in STOP]
    if len(words) < 2:
        words = re.findall(r"[A-Za-z]{3,}", topic.lower()) or ["abstract"]
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    top = sorted(freq, key=lambda w: (-freq[w], -len(w)))[:3]
    return " ".join(top)


def gen_script(cfg, log, cancelled):
    key, model, topic, minutes = cfg["gemini_key"], cfg["model"], cfg["topic"], cfg["minutes"]
    lang = LANGS[cfg["lang"]]["label"]
    n = max(3, round(minutes * 60 / SEC_PER_SCENE))
    ns = max(3, min(12, round(n / 10)))
    log("Planning the video outline with Gemini…", 2)
    outline = gemini(key, model,
        f'Plan a YouTube video about "{topic}" lasting about {minutes} minutes. Return JSON: '
        f'{{"title": string, "sections": [{{"heading": string, "summary": string}}]}} with exactly {ns} sections. '
        f'Write in {lang}.', True)
    secs = [x for x in outline.get("sections", []) if isinstance(x, dict)][:ns]
    if not secs:
        raise RuntimeError("Gemini returned no outline. Try again or paste your own script.")
    ns = len(secs)
    base, extra = divmod(n, ns)
    scenes, headings, done_heads = [], [], []
    for i, sec in enumerate(secs):
        if cancelled():
            raise Cancelled()
        k = base + (1 if i < extra else 0)
        sec.setdefault("heading", f"Part {i+1}")
        log(f"Writing section {i+1}/{ns}: {sec['heading']}", 2 + 8 * (i / ns))
        flow = ("This is the opening: start with a strong hook. " if i == 0 else "") + \
               ("This is the final section: finish with a short conclusion and ask viewers to like and subscribe. "
                if i == ns - 1 else "Do not conclude the video here. ")
        p = (f'You write narration for a YouTube video titled "{outline.get("title", topic)}". '
             f'Now write section {i+1} of {ns}: "{sec["heading"]}" ({sec.get("summary","")}). '
             f'Earlier sections already covered: {", ".join(done_heads) or "nothing yet"}. {flow}'
             f'Write exactly {k} scenes. Each scene has "narration" (spoken text, about {WORDS_PER_SCENE} words, '
             f'natural spoken {lang}, no stage directions, no markdown) and "image_prompt" (English, 12-25 words, '
             f'one concrete visual, no text, no logos, no real people) and "keywords" (English, 2-3 words for stock photo search). '
             f'Return a JSON array of {k} objects.')
        arr = None
        for attempt in range(3):
            try:
                arr = gemini(key, model, p, True)
                if isinstance(arr, dict):
                    arr = next(iter(arr.values()), None)
                if isinstance(arr, list) and arr:
                    break
                arr = None
            except RuntimeError:
                if attempt == 2:
                    raise
        if not arr:
            raise RuntimeError(f'Gemini gave no usable text for section "{sec.get("heading", i + 1)}". Try again.')
        for a in arr:
            if isinstance(a, dict) and a.get("narration"):
                scenes.append({"text": clean_tts(a["narration"]), "prompt": a.get("image_prompt") or topic,
                               "keywords": a.get("keywords") or keywords_from(a["narration"], topic), "section": i})
        headings.append(sec["heading"])
        done_heads.append(sec["heading"])
    return outline.get("title", topic), scenes, headings


def split_script(raw, topic):
    chunks = []
    for para in [p.strip() for p in re.split(r"\n+", raw) if p.strip()]:
        sents = re.split(r"(?<=[.!?।])\s+", para)
        cur = ""
        for s in sents:
            if cur and len((cur + " " + s).split()) > WORDS_PER_SCENE * 1.6:
                chunks.append(cur)
                cur = s
            else:
                cur = (cur + " " + s).strip()
        if cur:
            chunks.append(cur)
    return [{"text": clean_tts(c), "prompt": "", "keywords": keywords_from(c, topic), "section": None}
            for c in chunks if clean_tts(c)]


def add_prompts(cfg, scenes, log):
    key = cfg.get("gemini_key")
    todo = [s for s in scenes if not s["prompt"]]
    if key and todo:
        for b in range(0, len(todo), 25):
            batch = todo[b:b + 25]
            log(f"Creating image ideas ({b+1}-{b+len(batch)} of {len(todo)})…", 8)
            try:
                arr = gemini(key, cfg["model"],
                    'For each narration below, return JSON array (same order, same length) of objects '
                    '{"image_prompt": English 12-25 words describing one concrete visual, no text/logos/real people, '
                    '"keywords": English 2-3 words for stock photo search}.\n' +
                    "\n".join(f"{i+1}. {s['text']}" for i, s in enumerate(batch)), True)
                for s, a in zip(batch, arr):
                    s["prompt"], s["keywords"] = a.get("image_prompt", ""), a.get("keywords") or s["keywords"]
            except RuntimeError as e:
                log(f"Image ideas by AI failed ({e}); using keywords instead.", 8)
    for s in scenes:
        if not s["prompt"]:
            s["prompt"] = f'{s["keywords"]}, {cfg["topic"]}'


# ---------------------------------------------------------------- images
def placeholder(text, w, h, out):
    seed = int(hashlib.md5(text.encode()).hexdigest()[:6], 16)
    r = random.Random(seed)
    c1 = tuple(r.randint(30, 160) for _ in range(3))
    c2 = tuple(r.randint(80, 230) for _ in range(3))
    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        d.line([(0, y), (w, y)], fill=tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3)))
    f = font(int(min(w, h) * 0.08), True, False)
    lines = wrap(d, text.upper(), f, w * 0.8)
    y = h / 2 - len(lines) * f.size * 0.6
    for l in lines:
        d.text((w / 2, y), l, font=f, fill="white", anchor="ma")
        y += f.size * 1.2
    img.save(out, quality=90)


def cover(img, w, h):
    r = max(w / img.width, h / img.height)
    img = img.resize((max(w, round(img.width * r)), max(h, round(img.height * r))), Image.LANCZOS)
    x, y = (img.width - w) // 2, (img.height - h) // 2
    return img.crop((x, y, x + w, y + h))


def fetch_image(sc, idx, cfg, size, out):
    w, h = size
    prov = cfg["provider"]
    tried = []
    chain = [prov] + [p for p in ("pexels",) if p != prov and cfg.get("pexels_key")]
    for p in chain:
        if p == "placeholder":
            break
        for attempt in range(3):
            try:
                if p == "pollinations":
                    url = (f"https://image.pollinations.ai/prompt/{quote(sc['prompt'] + ', ' + cfg['style'])}"
                           f"?width={w}&height={h}&nologo=true&seed={idx + 7}")
                    r = requests.get(url, timeout=120)
                    ok = r.status_code == 200 and r.headers.get("content-type", "").startswith("image") and len(r.content) > 5000
                    data = r.content
                elif p == "pexels":
                    o = {"16:9": "landscape", "9:16": "portrait", "1:1": "square"}[cfg["ratio"]]
                    r = requests.get("https://api.pexels.com/v1/search", headers={"Authorization": cfg["pexels_key"]},
                                     params={"query": sc["keywords"], "per_page": 8, "orientation": o}, timeout=30)
                    ph = r.json().get("photos", [])
                    if not ph:
                        break
                    pick = ph[idx % len(ph)]["src"]["large2x"]
                    data = requests.get(pick, timeout=60).content
                    ok = len(data) > 5000
                else:
                    break
                if ok:
                    tmp = out + ".dl"
                    with open(tmp, "wb") as f:
                        f.write(data)
                    cover(Image.open(tmp).convert("RGB"), w, h).save(out, quality=92)
                    os.remove(tmp)
                    return p
            except Exception:
                pass
            time.sleep(2 + attempt * 3)
        tried.append(p)
    placeholder(sc["keywords"], w, h, out)
    return "placeholder"


# ---------------------------------------------------------------- voice
def tts(text, voice, speed, out):
    pct = int(round((speed - 1) * 100))
    try:
        import edge_tts

        async def go():
            await edge_tts.Communicate(text, voice, rate=f"{pct:+d}%").save(out)
        for attempt in range(3):
            try:
                asyncio.run(go())
                if os.path.getsize(out) > 1000:
                    return "edge-tts"
            except Exception:
                time.sleep(2 + attempt * 2)
    except ImportError:
        pass
    if shutil.which("espeak-ng"):
        wav = out + ".wav"
        subprocess.run(["espeak-ng", "-w", wav, text], capture_output=True)
        if os.path.exists(wav) and os.path.getsize(wav) > 1000:
            sh(["ffmpeg", "-y", "-i", wav, out])
            os.remove(wav)
            return "espeak"
    secs = max(2.0, len(text.split()) / 2.6 / speed)
    sh(["ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", f"{secs:.2f}", "-q:a", "9", out])
    return "silent"


# ---------------------------------------------------------------- video
def render_scene(img, audio, size, idx, out):
    w, h = size
    d = duration(audio) + 0.35
    n = max(1, math.ceil(d * FPS))
    kind = idx % 4
    if kind == 0:
        z, x, y = f"1+0.14*on/{n}", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
    elif kind == 1:
        z, x, y = f"1.14-0.14*on/{n}", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
    elif kind == 2:
        z, x, y = "1.12", f"(iw-iw/zoom)*on/{n}", "ih/2-(ih/zoom/2)"
    else:
        z, x, y = "1.12", f"(iw-iw/zoom)*(1-on/{n})", "ih/2-(ih/zoom/2)"
    vf = f"scale={w*3//2}:{h*3//2},zoompan=z='{z}':x='{x}':y='{y}':d={n}:s={w}x{h}:fps={FPS},format=yuv420p"
    sh(["ffmpeg", "-y", "-i", img, "-i", audio, "-vf", vf, "-af", "apad=pad_dur=0.35", "-t", f"{d:.3f}",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
        "-ac", "2", "-movflags", "+faststart", out])
    return d


# ---------------------------------------------------------------- thumbnail + SEO
DEV_FONTS = ["/system/fonts/NotoSansDevanagari-Bold.ttf", "/system/fonts/NotoSansDevanagari-Regular.ttf",
             "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf", "C:/Windows/Fonts/NirmalaB.ttf",
             "C:/Windows/Fonts/Nirmala.ttf", "/System/Library/Fonts/Supplemental/Devanagari Sangam MN.ttc",
             "/Library/Fonts/Arial Unicode.ttf"]


def has_dev_font():
    return any(os.path.exists(p) for p in DEV_FONTS)


def font(size, bold=True, dev=False):
    paths = list(DEV_FONTS) if dev else []
    paths += ["C:/Windows/Fonts/impact.ttf", "C:/Windows/Fonts/arialbd.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/system/fonts/Roboto-Black.ttf", "/system/fonts/Roboto-Bold.ttf", "/system/fonts/DroidSans-Bold.ttf",
              "/Library/Fonts/Arial Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf"]
    for p in paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def wrap(d, text, f, maxw):
    lines, cur = [], ""
    for w in text.split():
        q = (cur + " " + w).strip()
        if d.textlength(q, font=f) > maxw and cur:
            lines.append(cur)
            cur = w
        else:
            cur = q
    return lines + ([cur] if cur else [])


def make_thumbnail(img_path, text, out, dev):
    W, H = 1280, 720
    img = cover(Image.open(img_path).convert("RGB"), W, H)
    ov = Image.new("RGBA", (W, H))
    od = ImageDraw.Draw(ov)
    for x in range(W):
        od.line([(x, 0), (x, H)], fill=(0, 0, 0, int(190 * max(0, 1 - x / (W * 0.85)))))
    img = Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")
    d = ImageDraw.Draw(img)
    size = 130
    while True:
        f = font(size, True, dev)
        lines = wrap(d, text, f, W * 0.62)
        if (len(lines) <= 4 and len(lines) * size * 1.15 < H * 0.8) or size <= 54:
            break
        size -= 8
    y = H / 2 - len(lines) * size * 1.15 / 2
    for l in lines:
        d.text((60, y), l, font=f, fill="white", stroke_width=max(4, size // 14), stroke_fill="black")
        y += size * 1.15
    img.save(out, quality=92)


def make_seo(cfg, title, scenes, headings, total):
    topic, key, y = cfg["topic"], cfg.get("gemini_key"), time.localtime().tm_year
    chapters = ""
    if headings:
        starts, seen = [], set()
        for s in scenes:
            if s["section"] is not None and s["section"] not in seen:
                seen.add(s["section"])
                starts.append((s["start"], headings[s["section"]]))
        if len(starts) >= 3:
            chapters = "\n".join(f"{fmt_time(t)} {h}" for t, h in starts)
    if key:
        try:
            j = gemini(key, cfg["model"],
                f'Create YouTube SEO for a video titled "{title}" about "{topic}". Language of titles/description: '
                f'{LANGS[cfg["lang"]]["label"]}. Return JSON {{"titles": [5 titles under 70 characters], '
                f'"description": "150-250 words, no hashtags", "tags": [15 tags], "hashtags": [5 strings starting with #], '
                f'"thumbnail_text": "max 5 words, punchy, in the same language"}}.', True)
            if isinstance(j, dict) and j.get("titles"):
                j["description"] = j.get("description") or topic
                j["tags"] = [str(x) for x in (j.get("tags") or [topic])]
                j["hashtags"] = [str(x) for x in (j.get("hashtags") or [])]
                j["titles"] = [str(x) for x in j["titles"]]
                return j, chapters
        except RuntimeError:
            pass
    ws = [w for w in re.findall(r"\w{3,}", topic.lower()) if w not in STOP]
    t = topic.strip()
    core = re.sub(r"^how to ", "", t, flags=re.I)
    tags = [t, f"how to {core}", f"{core} {y}", f"{t} tutorial", f"{t} for beginners", f"{t} tips", f"{t} explained"] + ws
    uniq = list(dict.fromkeys(x.lower() for x in tags))[:15]
    first = scenes[0]["text"] if scenes else t
    return {"titles": [f"{t}: Everything You Need to Know ({y})", f"How to {core} (Step by Step)",
                       f"5 Mistakes to Avoid With {t}", f"{t} Explained Simply", f"The Truth About {t}"],
            "description": f"{first}\n\nIn this video you will learn {t} step by step. Watch till the end.\n\nLike, share and subscribe for more.",
            "tags": uniq, "hashtags": [f"#{w}" for w in ws[:4]] + ["#youtube"],
            "thumbnail_text": t.upper()[:40]}, chapters


# ---------------------------------------------------------------- main
def run(cfg, log, cancelled=lambda: False):
    need_ffmpeg()
    topic = cfg["topic"].strip()
    if not topic:
        raise ValueError("Please enter a topic.")
    size = SIZES[(cfg["ratio"], cfg["quality"])]
    base = os.path.join(cfg["output_dir"], slug(topic))
    out = base if cfg.get("resume") else (base if not os.path.exists(base) else f"{base}-{time.strftime('%H%M%S')}")
    for sub in ("images", "audio", "clips"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)
    sp = os.path.join(out, "scenes.json")

    if cfg.get("resume") and os.path.exists(sp):
        data = json.load(open(sp, encoding="utf-8"))
        title, scenes, headings = data["title"], data["scenes"], data["headings"]
        log(f"Resuming with saved script ({len(scenes)} scenes).", 10)
    else:
        if cfg.get("script", "").strip():
            title, headings = topic, []
            scenes = split_script(cfg["script"], topic)
            if not scenes:
                raise ValueError("Your script is empty.")
            log(f"Using your script: {len(scenes)} scenes.", 3)
            add_prompts(cfg, scenes, log)
        else:
            if not cfg.get("gemini_key"):
                raise ValueError("Add a free Gemini API key to auto-write the script, or paste your own script.")
            title, scenes, headings = gen_script(cfg, log, cancelled)
        json.dump({"title": title, "scenes": scenes, "headings": headings}, open(sp, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
    N = len(scenes)

    # images
    log(f"Creating {N} scene images…", 10)
    done = [0]
    kinds = {}

    def img_job(i):
        if cancelled():
            raise Cancelled()
        p = os.path.join(out, "images", f"{i:03d}.jpg")
        if not os.path.exists(p):
            kinds[i] = fetch_image(scenes[i], i, cfg, size, p)
        done[0] += 1
        log(f"Image {done[0]}/{N}", 10 + 35 * done[0] / N)
    with ThreadPoolExecutor(max_workers=2 if cfg["provider"] == "pexels" else 1) as ex:
        list(ex.map(img_job, range(N)))
    ph = sum(1 for v in kinds.values() if v == "placeholder")
    if ph:
        log(f"Note: {ph} image(s) could not be downloaded and use simple placeholders.", 45)

    # voice
    voice = LANGS[cfg["lang"]]["voice"]
    log("Recording voice-over…", 45)
    modes = set()
    for i, s in enumerate(scenes):
        if cancelled():
            raise Cancelled()
        p = os.path.join(out, "audio", f"{i:03d}.mp3")
        if not os.path.exists(p):
            modes.add(tts(s["text"], voice, cfg["speed"], p))
        if i % 3 == 0 or i == N - 1:
            log(f"Voice {i+1}/{N}", 45 + 15 * (i + 1) / N)
    if "silent" in modes:
        log("WARNING: no speech engine worked, so some scenes are SILENT. Install edge-tts and check your internet.", 60)
    elif "espeak" in modes:
        log("Note: used the basic offline voice for some scenes (edge-tts unavailable).", 60)

    # clips
    t = 0.0
    clips = []
    for i, s in enumerate(scenes):
        if cancelled():
            raise Cancelled()
        c = os.path.join(out, "clips", f"{i:03d}.mp4")
        a = os.path.join(out, "audio", f"{i:03d}.mp3")
        if not os.path.exists(c):
            render_scene(os.path.join(out, "images", f"{i:03d}.jpg"), a, size, i, c)
        s["start"] = t
        t += duration(c)
        clips.append(c)
        log(f"Video scene {i+1}/{N}", 60 + 32 * (i + 1) / N)
    lst = os.path.join(out, "clips", "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for c in clips:
            f.write("file '" + os.path.abspath(c).replace("\\", "/").replace("'", "'\\''") + "'\n")
    log("Joining scenes into the final video…", 93)
    vid = os.path.join(out, "video.mp4")
    sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-movflags", "+faststart", vid])

    # thumbnail + seo
    log("Making thumbnail and SEO…", 96)
    seo, chapters = make_seo(cfg, title, scenes, headings, t)
    ttext = seo.get("thumbnail_text") or topic.upper()
    dev = bool(re.search(r"[\u0900-\u097F]", ttext))
    if dev and not has_dev_font():
        ttext = topic.upper() if topic.isascii() else "NEW VIDEO"
        dev = False
        log("Note: no Hindi font found on this device, so the thumbnail uses English text.", 96)
    best = os.path.join(out, "images", f"{min(1, N-1):03d}.jpg")
    make_thumbnail(best, ttext, os.path.join(out, "thumbnail.jpg"), dev)
    with open(os.path.join(out, "seo.txt"), "w", encoding="utf-8") as f:
        f.write("TITLE IDEAS\n" + "\n".join(f"- {x}" for x in seo["titles"]))
        f.write("\n\nDESCRIPTION\n" + seo["description"])
        if chapters:
            f.write("\n\nCHAPTERS\n" + chapters)
        f.write("\n\nHASHTAGS\n" + " ".join(seo["hashtags"]))
        f.write("\n\nTAGS (comma separated)\n" + ", ".join(seo["tags"]) + "\n")
    with open(os.path.join(out, "script.txt"), "w", encoding="utf-8") as f:
        f.write(title + "\n\n" + "\n\n".join(s["text"] for s in scenes) + "\n")
    shutil.rmtree(os.path.join(out, "clips"), ignore_errors=True)
    log(f"Done. Video length {fmt_time(t)}.", 100)
    return out, ["video.mp4", "thumbnail.jpg", "seo.txt", "script.txt"]
