V41 Excel Import Android UI-thread fix

- Android JavaScript bridge now opens file/save dialogs on the Android UI thread.
- Web and Android use a visible file input for Choose File; Android also receives the picked file through the native bridge.
- Bundled XLSX template remains available.
- No Supabase changes required.
