# RecallCurve - Spaced Repetition App (Android APK Guide)

This package contains the full source code for RecallCurve, configured for on-device storage (Room DB / IndexedDB & SharedPreferences) with zero cloud dependencies.

---

## Method 1: Convert to APK using Capacitor (Recommended, Fast & Free)

Capacitor is the official cross-platform runtime from Ionic that wraps modern React/Vite apps into a native Android Studio project.

### Prerequisites:
- Node.js 18+ installed on your computer ([nodejs.org](https://nodejs.org))
- Android Studio installed ([developer.android.com/studio](https://developer.android.com/studio))

### Steps:
1. **Unzip the folder and open terminal in the project directory**:
   ```bash
   cd recallcurve-source
   npm install
   ```

2. **Build the production web bundle**:
   ```bash
   npm run build
   ```

3. **Install Capacitor and add the Android platform**:
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init RecallCurve com.recallcurve.app --web-dir dist
   npx cap add android
   ```

4. **Sync the built assets to Android**:
   ```bash
   npx cap sync android
   ```

5. **Open in Android Studio**:
   ```bash
   npx cap open android
   ```

6. **Generate your APK in Android Studio**:
   - In Android Studio, go to the top menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Once compilation finishes, click **"locate"** in the notification popup.
   - Your `.apk` file (usually `app-debug.apk`) is ready to install on your Android device!

---

## Method 2: Instant No-Code APK with PWABuilder

Because this app works 100% offline with zero cloud backends, you can generate an Android APK without installing Android Studio:

1. Deploy or host the build folder on Vercel, Netlify, or GitHub Pages.
2. Visit [pwabuilder.com](https://www.pwabuilder.com).
3. Paste your URL, click **Start**, and click **Package for Android**.
4. PWABuilder will generate an `.apk` / `.aab` package for you to download directly.

---

## Method 3: Native Android Studio WebView Wrapper

If you prefer building a purely native Android project with a WebView:

1. In Android Studio, create a new project: **Empty Views Activity**.
2. Run `npm run build` in this project.
3. Copy the contents of the `dist/` directory into:
   `app/src/main/assets/www/`
4. In `MainActivity.kt`:
   ```kotlin
   package com.recallcurve.app

   import android.annotation.SuppressLint
   import android.os.Bundle
   import android.webkit.WebSettings
   import android.webkit.WebView
   import android.webkit.WebViewClient
   import androidx.appcompat.app.AppCompatActivity

   class MainActivity : AppCompatActivity() {
       @SuppressLint("SetJavaScriptEnabled")
       override fun onCreate(savedInstanceState: Bundle?) {
           super.onCreate(savedInstanceState)
           val webView = WebView(this)
           webView.settings.apply {
               javaScriptEnabled = true
               domStorageEnabled = true // Required for on-device Room/SharedPreferences data
               databaseEnabled = true
               allowFileAccess = true
               cacheMode = WebSettings.LOAD_DEFAULT
           }
           webView.webViewClient = WebViewClient()
           webView.loadUrl("file:///android_asset/www/index.html")
           setContentView(webView)
       }
   }
   ```
5. In `AndroidManifest.xml`, make sure `INTERNET` and `ACCESS_NETWORK_STATE` permissions are optional since all data is local.
6. Click **Build > Build APK(s)** to generate your APK.
