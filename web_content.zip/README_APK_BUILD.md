# MTX Android project — APK build

This ZIP contains the Android source plus Gradle project configuration.

## Build with an Android IDE app
1. Extract this ZIP into a folder.
2. Open/import the extracted **project folder** (the folder containing `settings.gradle.kts`) in an Android IDE that supports Gradle Kotlin DSL projects.
3. Allow Gradle sync and install the Android SDK Platform 35 and Build Tools when prompted.
4. Choose **Build > Build APK(s)** or run the `assembleDebug` Gradle task.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build in a cloud CI service
Import the extracted project into a Git repository and configure a Gradle Android build using JDK 17 and `:app:assembleDebug`. Download the generated artifact at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- The app ID is `com.example.mtx`; debug builds use `com.example.mtx.debug` so they can be installed alongside a release build.
- This project was prepared with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35.
- An APK has not been compiled or tested in this environment. If the builder reports an error, share the complete build log.
- The PHP/Node backend files are included in the ZIP as source assets; they are not part of the Android APK build. Deploy the backend separately to your server.


## index.html added

- `index.html` at the project root is a simple local MTX website homepage.
- `app/src/main/assets/index.html` packages the same page as an Android asset, ready
  for a WebView to load using `file:///android_asset/index.html`.
- The existing Android application remains its original native Jetpack Compose app;
  this asset addition alone does not replace the native launcher screen with WebView.
- A live website URL was not supplied, so this is an offline local landing page.
