const SUBJECTS=[
{id:"math",hi:"गणित",en:"Math",descHi:"संख्या, गणना और तर्क",descEn:"Numbers, calculations and logic",img:"math.jpg"},
{id:"english",hi:"अंग्रेज़ी",en:"English",descHi:"शब्द, व्याकरण और वाक्य",descEn:"Words, grammar and sentences",img:"english.jpg"},
{id:"science",hi:"विज्ञान",en:"Science",descHi:"भौतिकी, रसायन और जीव विज्ञान",descEn:"Physics, chemistry and biology",img:"science.jpg"},
{id:"computer",hi:"कंप्यूटर",en:"Computer",descHi:"कंप्यूटर और तकनीक",descEn:"Computers and technology",img:"computer.jpg"},
{id:"gk",hi:"सामान्य ज्ञान",en:"General Knowledge",descHi:"भारत और दुनिया",descEn:"India and the world",img:"gk.jpg"},
{id:"mix",hi:"मिक्स क्विज़",en:"Mixed Quiz",descHi:"सभी विषयों के मिले-जुले प्रश्न",descEn:"Questions from every subject",img:"mix.jpg"}
];
const I18N={
hi:{tag:"खेलो • सीखो • आगे बढ़ो",heading:"विषय चुनें",sub:"अपना पसंदीदा विषय चुनें और नए स्तर खोलें।",search:"विषय खोजें...",ruleTitle:"🏆 स्तर खोलने का नियम",rule:"हर स्तर में 10 प्रश्न हैं। 8 या उससे अधिक सही उत्तर देने पर अगला स्तर खुलेगा।",backHome:"← विषयों पर वापस",backLevels:"← स्तरों पर वापस",choose:"अपना स्तर चुनें",levels:"स्तर",easy:"आसान",normal:"सामान्य",hard:"कठिन",locked:"बंद",done:"पूरा",lockHint:"🔒 बंद स्तर खेलने के लिए पहले पिछला स्तर पास करें।",question:"प्रश्न",correct:"सही जवाब!",wrong:"गलत जवाब।",answer:"सही उत्तर",next:"अगला प्रश्न →",result:"परिणाम देखें →",passed:"आपने 8 या उससे अधिक सही किए। अगला स्तर खुल गया है।",failed:"अगला स्तर खोलने के लिए कम-से-कम 8 सही उत्तर चाहिए। फिर से प्रयास करें।",passTitle:"शानदार! 🎉",failTitle:"कोशिश जारी रखें",nextLevel:"अगला स्तर →",retry:"इसी स्तर को फिर खेलें",home:"मुख्य पेज पर जाएँ",correctStat:"सही उत्तर",wrongStat:"गलत उत्तर",total:"कुल प्रश्न",finished:"सभी स्तर पूरे!",creator:"Creation by <b>Padmnabham</b>",resetConfirm:"क्या आप सभी विषयों की प्रगति रीसेट करना चाहते हैं?"},
en:{tag:"PLAY • LEARN • GROW",heading:"Choose a subject",sub:"Pick a subject and unlock new levels.",search:"Search subjects...",ruleTitle:"🏆 Level unlock rule",rule:"Each level has 10 questions. Get 8 or more correct answers to unlock the next level.",backHome:"← Back to subjects",backLevels:"← Back to levels",choose:"Choose your level",levels:"Levels",easy:"Easy",normal:"Normal",hard:"Hard",locked:"Locked",done:"Done",lockHint:"🔒 Pass the previous level to unlock this one.",question:"Question",correct:"Correct answer!",wrong:"Incorrect answer.",answer:"Correct answer",next:"Next question →",result:"View result →",passed:"You got at least 8 correct. The next level is unlocked.",failed:"You need at least 8 correct answers to unlock the next level. Try again.",passTitle:"Excellent! 🎉",failTitle:"Keep trying",nextLevel:"Next level →",retry:"Play this level again",home:"Go to main page",correctStat:"Correct",wrongStat:"Incorrect",total:"Total",finished:"All levels completed!",creator:"Creation by <b>Padmnabham</b>",resetConfirm:"Reset progress for all subjects?"}
};
let lang=localStorage.getItem("bp_lang")||"hi",progress=JSON.parse(localStorage.getItem("bp_progress")||"{}");
let subject="math",level=1,questions=[],index=0,score=0,answered=false;
const $=id=>document.getElementById(id),t=k=>I18N[lang][k]||I18N.hi[k]||k,subjectName=s=>lang==="hi"?s.hi:s.en;
const letters=["A","B","C","D"];
function save(){localStorage.setItem("bp_progress",JSON.stringify(progress))}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.add("hidden"));$(id).classList.remove("hidden");window.scrollTo(0,0)}
function isPassed(id,l){return !!(progress[id]&&progress[id][l])}
function difficulty(l){return l<=20?t("easy"):l<=35?t("normal"):t("hard")}
function renderHome(){
 $("tagline").textContent=t("tag");$("homeHeading").textContent=t("heading");$("homeSubheading").textContent=t("sub");$("subjectSearch").placeholder=t("search");$("ruleTitle").textContent=t("ruleTitle");$("ruleText").textContent=t("rule");$("footerText").textContent="Creation by Padmnabham";
 $("subjectGrid").innerHTML=SUBJECTS.map(s=>`<button class="subject-card" data-sub="${s.id}"><img class="subject-thumb" src="images/${s.img}" alt="${s.en}"><span class="subject-copy"><b>${subjectName(s)}</b><small>${lang==="hi"?s.descHi:s.descEn} · 50 ${lang==="hi"?"स्तर":"levels"}</small></span><span class="chevron">›</span></button>`).join("");
 document.querySelectorAll("[data-sub]").forEach(b=>b.onclick=()=>openLevels(b.dataset.sub));
}
$("subjectSearch").addEventListener("input",e=>{let q=e.target.value.toLocaleLowerCase();document.querySelectorAll("[data-sub]").forEach(b=>b.classList.toggle("hidden",!b.innerText.toLocaleLowerCase().includes(q)))});
function openLevels(id){
 subject=id;let s=SUBJECTS.find(x=>x.id===id);$("levelsTitle").textContent=subjectName(s);$("levelEyebrow").textContent=t("choose");$("levelCount").textContent=`50 ${t("levels")}`;
 $("levelLegend").innerHTML=`<span>🟢 ${t("easy")} 1–20</span><span>🔵 ${t("normal")} 21–35</span><span>🟣 ${t("hard")} 36–50</span>`;$("lockHint").textContent=t("lockHint");
 $("levelGrid").innerHTML=Array.from({length:50},(_,i)=>{let n=i+1,unlocked=n===1||isPassed(id,n-1),done=isPassed(id,n),cls=n<=20?"easy":n<=35?"normal":"hard";return `<button class="level-btn ${unlocked?"unlocked":"locked"} ${cls}" data-level="${n}" ${unlocked?"":"disabled"}><b>${done?"✓":n}</b><small>${done?t("done"):unlocked?difficulty(n):"🔒 "+t("locked")}</small></button>`}).join("");
 document.querySelectorAll("[data-level]").forEach(b=>b.onclick=()=>startLevel(+b.dataset.level));show("levelsScreen");
}
function makeQ(text,correct,wrong,explain="",image=""){let opts=[String(correct),...wrong.map(String)].sort(()=>Math.random()-.5);return{text,opts,answer:opts.indexOf(String(correct)),explain,image}}
const banks={
english:[
["'सुंदर' का अंग्रेज़ी शब्द क्या है?","Beautiful",["Quickly","School","Run"],"Beautiful का अर्थ सुंदर है।"],
["'विद्यालय' का अंग्रेज़ी शब्द क्या है?","School",["River","Book","Chair"],"School का अर्थ विद्यालय है।"],
["'मैं एक विद्यार्थी हूँ' का सही वाक्य चुनें।","I am a student.",["I is a student.","I are student.","Me am student."],"I के साथ am आता है।"],
["'वे खेल रहे हैं' का सही अनुवाद चुनें।","They are playing.",["They is playing.","They am play.","Them playing."],"They के साथ are आता है।"],
["Noun किसे कहते हैं?","नाम बताने वाला शब्द",["काम बताने वाला शब्द","गुण बताने वाला शब्द","जोड़ने वाला शब्द"],"Noun नाम बताता है।"],
["'He' किस प्रकार का शब्द है?","Pronoun",["Noun","Adjective","Preposition"],"He एक सर्वनाम है।"],
["'Quickly' किसका उदाहरण है?","Adverb",["Noun","Pronoun","Article"],"Quickly क्रिया की विशेषता बताता है।"],
["सही Article चुनें: ___ apple","An",["A","The","No article"],"Apple की शुरुआत vowel sound से होती है।"],
["'Children' का एकवचन क्या है?","Child",["Childs","Childes","Childrens"],"Child इसका एकवचन है।"],
["'Go' का Past form क्या है?","Went",["Goed","Gone","Going"],"Go का Past form Went है।"],
["'किताब मेज़ पर है' का सही वाक्य चुनें।","The book is on the table.",["Book are in table.","The book am on table.","A book is at table."],"On का अर्थ यहाँ पर है।"],
["'हम' का अंग्रेज़ी सर्वनाम क्या है?","We",["Us","They","Our"],"We कर्ता रूप है।"],
["'बड़ा' का विलोम क्या है?","Small",["Tall","Long","Wide"],"Small का अर्थ छोटा है।"],
["'She sings well' में Verb कौन-सा है?","Sings",["She","Well","कोई नहीं"],"Sings क्रिया है।"],
["'I have finished my work' कौन-सा Tense है?","Present Perfect",["Simple Present","Past Continuous","Future Simple"],"Have + V3 Present Perfect बनाता है।"]
],
science:[
["पानी का रासायनिक सूत्र क्या है?","H₂O",["CO₂","O₂","NaCl"],"पानी में हाइड्रोजन और ऑक्सीजन होते हैं।","images/q-science-lab.jpg"],
["पौधे भोजन किस प्रक्रिया से बनाते हैं?","प्रकाश संश्लेषण",["श्वसन","वाष्पीकरण","पाचन"],"प्रकाश संश्लेषण में पौधे प्रकाश की मदद से भोजन बनाते हैं।"],
["मानव शरीर का सबसे बड़ा अंग कौन-सा है?","त्वचा",["हृदय","फेफड़ा","गुर्दा"],"त्वचा शरीर का सबसे बड़ा अंग है।"],
["बल की SI इकाई क्या है?","न्यूटन",["जूल","वाट","पास्कल"],"बल की SI इकाई न्यूटन है।"],
["पृथ्वी के सबसे निकट तारा कौन-सा है?","सूर्य",["ध्रुव तारा","सिरियस","चंद्रमा"],"सूर्य पृथ्वी का निकटतम तारा है।"],
["रक्त का लाल रंग किसके कारण होता है?","हीमोग्लोबिन",["क्लोरोफिल","प्लाज्मा","इंसुलिन"],"हीमोग्लोबिन में लौह तत्व होता है।"],
["ध्वनि किसमें यात्रा नहीं कर सकती?","निर्वात",["जल","वायु","ठोस"],"ध्वनि को माध्यम चाहिए।"],
["परमाणु के केंद्र को क्या कहते हैं?","नाभिक",["इलेक्ट्रॉन","कक्षा","अणु"],"नाभिक में प्रोटॉन और न्यूट्रॉन होते हैं।"],
["सामान्य वायुदाब पर पानी कितने °C पर उबलता है?","100°C",["0°C","50°C","80°C"],"समुद्र तल पर पानी लगभग 100°C पर उबलता है।"],
["विटामिन C का अच्छा स्रोत क्या है?","आँवला",["चावल","मक्खन","नमक"],"आँवला विटामिन C से भरपूर है।"],
["विद्युत धारा की SI इकाई क्या है?","एम्पियर",["वोल्ट","ओम","वाट"],"विद्युत धारा की इकाई एम्पियर है।"],
["पृथ्वी का प्राकृतिक उपग्रह कौन है?","चंद्रमा",["मंगल","सूर्य","शुक्र"],"चंद्रमा पृथ्वी का प्राकृतिक उपग्रह है।"],
["अम्ल का pH सामान्यतः कितना होता है?","7 से कम",["7 के बराबर","7 से अधिक","हमेशा 14"],"अम्लीय पदार्थों का pH 7 से कम होता है।"],
["मानव हृदय में कितने कक्ष होते हैं?","4",["2","3","5"],"हृदय में चार कक्ष होते हैं।"],
["प्रकाश की गति सबसे अधिक किसमें होती है?","निर्वात",["पानी","काँच","हीरा"],"प्रकाश की गति निर्वात में सर्वाधिक होती है।"]
],
computer:[
["CPU का पूरा नाम क्या है?","Central Processing Unit",["Computer Power Unit","Central Program Utility","Control Processing User"],"CPU मुख्य प्रोसेसिंग भाग है।"],
["कंप्यूटर का मस्तिष्क किसे कहते हैं?","CPU",["माउस","कीबोर्ड","मॉनिटर"],"CPU निर्देशों को संसाधित करता है।"],
["इनमें से इनपुट डिवाइस कौन-सी है?","कीबोर्ड",["मॉनिटर","प्रिंटर","स्पीकर"],"कीबोर्ड से डेटा दिया जाता है।"],
["RAM किस प्रकार की मेमोरी है?","अस्थायी",["स्थायी","केवल पढ़ने योग्य","ऑप्टिकल"],"बिजली बंद होने पर RAM का डेटा मिट जाता है।"],
["HTML का उपयोग किसलिए होता है?","वेब पेज की संरचना बनाने के लिए",["वीडियो एडिटिंग","ऑपरेटिंग सिस्टम","डेटाबेस बैकअप"],"HTML वेब पेज का ढाँचा बनाता है।"],
["CSS का मुख्य काम क्या है?","वेब पेज को सजाना",["डेटा गणना","सर्वर चलाना","फाइल मिटाना"],"CSS रंग, आकार और लेआउट नियंत्रित करता है।"],
["JavaScript का उपयोग किसलिए होता है?","वेब पेज में व्यवहार जोड़ने के लिए",["केवल चित्र बनाने","केवल प्रिंट करने","हार्ड डिस्क बनाने"],"JavaScript पेज को इंटरैक्टिव बनाती है।"],
["इनमें से ऑपरेटिंग सिस्टम कौन-सा है?","Linux",["HTML","Python","SQL"],"Linux एक ऑपरेटिंग सिस्टम है।","images/q-computer.jpg"],
["1 Byte में कितने Bits होते हैं?","8",["4","16","32"],"एक Byte में 8 Bits होते हैं।"],
["URL का संबंध किससे है?","वेब पते से",["प्रोसेसर की गति","बैटरी क्षमता","स्क्रीन आकार"],"URL किसी वेब संसाधन का पता है।"],
["डेटाबेस में डेटा की पंक्ति को क्या कहते हैं?","Record",["Field","Folder","Pixel"],"Record संबंधित fields का समूह होता है।"],
["कंप्यूटर वायरस क्या है?","हानिकारक प्रोग्राम",["इनपुट डिवाइस","मेमोरी चिप","नेटवर्क केबल"],"वायरस सिस्टम या डेटा को नुकसान पहुँचा सकता है।"],
["कौन-सा प्रोटोकॉल सुरक्षित वेबसाइट कनेक्शन में मदद करता है?","HTTPS",["FTP","SMTP","POP3"],"HTTPS वेब संचार को एन्क्रिप्ट करता है।"],
["Git का मुख्य उपयोग क्या है?","Version Control",["चित्र बनाना","ईमेल भेजना","वीडियो चलाना"],"Git कोड में बदलाव का इतिहास रखता है।"],
["क्लाउड कंप्यूटिंग का अर्थ क्या है?","इंटरनेट पर कंप्यूटिंग सेवाएँ",["केवल मौसम देखना","केवल लोकल प्रिंटिंग","बिना बिजली कंप्यूटर"],"क्लाउड में सर्वर, स्टोरेज और सेवाएँ इंटरनेट से मिलती हैं।"]
],
gk:[
["भारत की राजधानी क्या है?","नई दिल्ली",["मुंबई","कोलकाता","चेन्नई"],"भारत की राजधानी नई दिल्ली है।","images/q-world-map.jpg"],
["भारत का राष्ट्रीय पशु कौन है?","बाघ",["शेर","हाथी","तेंदुआ"],"बाघ भारत का राष्ट्रीय पशु है।"],
["भारत का संविधान कब लागू हुआ?","26 जनवरी 1950",["15 अगस्त 1947","2 अक्टूबर 1950","26 नवंबर 1949"],"संविधान 26 जनवरी 1950 को लागू हुआ।"],
["ताजमहल कहाँ स्थित है?","आगरा",["जयपुर","दिल्ली","लखनऊ"],"ताजमहल उत्तर प्रदेश के आगरा में है।"],
["भारत का राष्ट्रीय गान किसने लिखा?","रवीन्द्रनाथ टैगोर",["बंकिमचंद्र चट्टोपाध्याय","महात्मा गांधी","सरोजिनी नायडू"],"जन गण मन रवीन्द्रनाथ टैगोर ने लिखा।"],
["विश्व का सबसे बड़ा महासागर कौन-सा है?","प्रशांत महासागर",["अटलांटिक","हिंद महासागर","आर्कटिक"],"प्रशांत महासागर क्षेत्रफल में सबसे बड़ा है।"],
["भारत में कितने राज्य हैं?","28",["27","29","30"],"भारत में 28 राज्य हैं।"],
["जापान की मुद्रा क्या है?","येन",["डॉलर","यूरो","रुपया"],"जापान की मुद्रा येन है।"],
["संयुक्त राष्ट्र की स्थापना किस वर्ष हुई?","1945",["1919","1939","1950"],"संयुक्त राष्ट्र की स्थापना 1945 में हुई।"],
["भारत का अंतरिक्ष संगठन कौन-सा है?","इसरो",["नासा","ईसा","डीआरडीओ"],"इसरो भारत की अंतरिक्ष एजेंसी है।"],
["सौरमंडल का सबसे बड़ा ग्रह कौन-सा है?","बृहस्पति",["पृथ्वी","मंगल","शुक्र"],"बृहस्पति सबसे बड़ा ग्रह है।"],
["भारत का राष्ट्रीय फूल कौन-सा है?","कमल",["गुलाब","गेंदा","चमेली"],"कमल भारत का राष्ट्रीय फूल है।"],
["कंप्यूटर के जनक किसे कहा जाता है?","चार्ल्स बैबेज",["आइज़ैक न्यूटन","अल्बर्ट आइंस्टीन","टिम बर्नर्स-ली"],"चार्ल्स बैबेज को कंप्यूटर का जनक कहा जाता है।"],
["विश्व पर्यावरण दिवस कब मनाया जाता है?","5 जून",["22 अप्रैल","1 मई","16 सितंबर"],"विश्व पर्यावरण दिवस 5 जून को मनाया जाता है।"],
["भारत का राष्ट्रीय पक्षी कौन-सा है?","मोर",["तोता","हंस","कबूतर"],"मोर भारत का राष्ट्रीय पक्षी है।"]
]};
function mathQ(l,i){let a,b,ans,text;if(i%5===0){a=12+l*3+i;b=7+l+i;ans=a+b;text=`${a} + ${b} का मान कितना है?`}else if(i%5===1){a=l+4;b=3+(l%7);ans=a*b;text=`${a} × ${b} = ?`}else if(i%5===2){b=2+(l%8);ans=10+l*4+i*2;a=ans*b;text=`${a} ÷ ${b} = ?`}else if(i%5===3){a=l+5;ans=a*a;text=`${a} का वर्ग कितना है?`}else{a=100+l*10;let p=10+(l%4)*5;ans=a*p/100;text=`${a} का ${p}% कितना है?`}return makeQ(text,ans,[ans+3,ans-2,ans+8],`हल करने पर उत्तर ${ans} आता है।`)}
function makeQuestionSet(id,l){let out=[];for(let i=0;i<10;i++){let key=id;if(id==="mix")key=["math","english","science","computer","gk"][(i+l)%5];if(key==="math"){out.push(mathQ(l,i));continue}let pool=banks[key],item=pool[(i*3+(l-1)*7)%pool.length];out.push(makeQ(...item))}return out}
function startLevel(n){level=n;index=0;score=0;questions=makeQuestionSet(subject,n);let s=SUBJECTS.find(x=>x.id===subject);$("quizSubject").textContent=subjectName(s);$("quizLevel").textContent=(lang==="hi"?"स्तर ":"Level ")+n;$("quizDifficulty").textContent=difficulty(n);show("quizScreen");renderQuestion()}
function renderQuestion(){answered=false;let q=questions[index];$("questionCount").textContent=`${t("question")} ${index+1} / 10`;$("progressPercent").textContent=`${(index+1)*10}%`;$("progressFill").style.width=`${(index+1)*10}%`;$("questionText").textContent=q.text;let im=$("questionImage");if(q.image){im.src=q.image;im.classList.remove("hidden")}else{im.removeAttribute("src");im.classList.add("hidden")}$("feedback").className="feedback hidden";$("feedback").textContent="";$("nextBtn").classList.add("hidden");$("options").innerHTML=q.opts.map((o,i)=>`<button class="option-btn" data-opt="${i}"><span class="option-letter">${letters[i]}</span><span>${o}</span></button>`).join("");document.querySelectorAll("[data-opt]").forEach(b=>b.onclick=()=>choose(+b.dataset.opt))}
function choose(n){if(answered)return;answered=true;let q=questions[index],ok=n===q.answer;if(ok)score++;document.querySelectorAll("[data-opt]").forEach((b,i)=>{b.disabled=true;if(i===q.answer)b.classList.add("correct");else if(i===n)b.classList.add("wrong")});let f=$("feedback");f.classList.remove("hidden");f.classList.toggle("bad",!ok);f.innerHTML=ok?`<b>✓ ${t("correct")}</b><br>${q.explain}`:`<b>✕ ${t("wrong")}</b><br>${t("answer")}: <b>${letters[q.answer]}. ${q.opts[q.answer]}</b><br>${q.explain}`;$("nextBtn").classList.remove("hidden");$("nextBtn").textContent=index===9?t("result"):t("next")}
function showResult(){let ok=score>=8;if(ok){progress[subject]=progress[subject]||{};progress[subject][level]=true;save()}$("scoreText").textContent=`${score} / 10`;$("correctStat").textContent=score;$("wrongStat").textContent=10-score;$("resultTitle").textContent=ok?t("passTitle"):t("failTitle");$("resultMessage").textContent=ok?t("passed"):t("failed");$("continueBtn").classList.toggle("hidden",!ok);$("continueBtn").textContent=level===50?t("finished"):t("nextLevel");$("retryBtn").textContent=t("retry");$("homeBtn").textContent=t("home");show("resultScreen")}
$("nextBtn").onclick=()=>{if(index<9){index++;renderQuestion()}else showResult()};
$("continueBtn").onclick=()=>{if(level<50)startLevel(level+1);else openLevels(subject)};
$("retryBtn").onclick=()=>startLevel(level);$("homeBtn").onclick=()=>show("homeScreen");
$("backHome").onclick=()=>show("homeScreen");$("backLevels").onclick=()=>openLevels(subject);
$("resetBtn").onclick=()=>{if(confirm(t("resetConfirm"))){progress={};save();renderHome();show("homeScreen")}};
$("languageSelect").value=lang;$("languageSelect").onchange=e=>{lang=e.target.value;localStorage.setItem("bp_lang",lang);renderHome();if(!$("levelsScreen").classList.contains("hidden"))openLevels(subject);};
renderHome();show("homeScreen");
