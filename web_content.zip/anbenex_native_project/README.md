# Anbenex Deck — proyecto Android nativo

Este proyecto integra la interfaz web Anbenex Deck en una aplicación Android real (WebView local) con un puente nativo Kotlin.

## Funciones nativas añadidas
- Abrir enlaces externos desde el navegador del sistema.
- Abrir Google Play mediante `market://` y usar la web como alternativa.
- Consultar aplicaciones que tienen acceso directo de inicio y lanzarlas.
- Abrir Ajustes de Android y la sección de descargas/selector de archivos.
- Elegir orientación automática, horizontal forzada o vertical forzada desde Ajustes dentro del launcher.
- Modo inmersivo/pantalla completa configurable desde el launcher.
- Mostrar información básica del dispositivo dentro de Ajustes.
- Buscar aplicaciones instaladas y añadir accesos nativos a la biblioteca personal.
- Permitir elegir Anbenex Deck como aplicación de inicio desde la configuración del sistema (intent HOME).
- Mantener la biblioteca y ajustes web en almacenamiento local del WebView; exportación/importación JSON desde la interfaz.

## Compilar el APK
1. En un ordenador, instala Android Studio estable con Android SDK Platform 35 y JDK 17.
2. Descomprime este ZIP y abre la carpeta `anbenex_native_project` como proyecto en Android Studio.
3. Espera a que Gradle sincronice y pulsa **Build > Build APK(s)**.
4. El APK de depuración aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.
5. Copia el APK al teléfono e instálalo. Si Android lo solicita, permite instalar aplicaciones desde esa fuente.
6. Para usarlo como launcher del sistema, pulsa Inicio y elige Anbenex Deck, o entra en Ajustes > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio.

## Notas importantes
- Este ZIP contiene el proyecto fuente Android, no un APK compilado. El entorno actual no dispone de Android SDK/Gradle para compilar y probar un APK aquí.
- La visibilidad de aplicaciones instaladas se declara mediante `QUERY_ALL_PACKAGES`, porque descubrir y lanzar apps es una función central de este launcher. Google Play restringe ese permiso y puede exigir una declaración/aprobación si se publica allí.
- Android puede limitar la selección de launcher, el acceso a archivos o la apertura de algunas aplicaciones según la versión y el fabricante.
- Los juegos añadidos manualmente siguen siendo entradas de biblioteca/enlaces. Para ejecutar un juego Android, detecta la aplicación instalada y pulsa **Mi biblioteca**; la tarjeta guardada podrá lanzarla como aplicación nativa.
- No se conceden permisos de root ni se puede cambiar el sistema operativo, forzar compatibilidad de juegos de PC o controlar otras apps sin las APIs/permisos que Android permita. Los ajustes de sistema protegidos y la instalación de apps pueden salir del launcher por diseño de Android; el resto de personalización del launcher permanece dentro de su interfaz.
