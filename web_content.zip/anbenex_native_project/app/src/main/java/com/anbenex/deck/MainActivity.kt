package com.anbenex.deck

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.view.View
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anbenex_deck_native", MODE_PRIVATE)
        applyOrientation(prefs.getString("orientation", "auto") ?: "auto")
        applyImmersive(prefs.getBoolean("immersive", false))
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(8, 9, 12))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.loadsImagesAutomatically = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("file:///android_asset/")) return false
                openUrl(url)
                return true
            }
        }
        web.addJavascriptInterface(NativeBridge(), "AnbenexNative")
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html")
        else web.restoreState(savedInstanceState)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && getSharedPreferences("anbenex_deck_native", MODE_PRIVATE).getBoolean("immersive", false)) applyImmersive(true)
    }

    private fun applyOrientation(value: String) {
        requestedOrientation = when (value) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun applyImmersive(enabled: Boolean) {
        if (enabled) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun openUrl(raw: String) {
        try {
            val uri = Uri.parse(raw.trim())
            val scheme = uri.scheme?.lowercase() ?: ""
            if (scheme !in listOf("https", "http", "market")) {
                Toast.makeText(this, "Solo se permiten enlaces web y de Google Play", Toast.LENGTH_SHORT).show()
                return
            }
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir ese enlace", Toast.LENGTH_SHORT).show()
        }
    }

    inner class NativeBridge {
        @JavascriptInterface fun isAvailable(): Boolean = true

        @JavascriptInterface fun setOrientation(value: String) {
            runOnUiThread {
                val safe = if (value in listOf("auto", "landscape", "portrait")) value else "auto"
                getSharedPreferences("anbenex_deck_native", MODE_PRIVATE).edit().putString("orientation", safe).apply()
                applyOrientation(safe)
            }
        }

        @JavascriptInterface fun setImmersive(enabled: Boolean) {
            runOnUiThread {
                getSharedPreferences("anbenex_deck_native", MODE_PRIVATE).edit().putBoolean("immersive", enabled).apply()
                applyImmersive(enabled)
            }
        }

        @JavascriptInterface fun getDeviceInfo(): String {
            val info = JSONObject()
            info.put("model", Build.MANUFACTURER + " " + Build.MODEL)
            info.put("android", Build.VERSION.RELEASE ?: "desconocido")
            info.put("orientation", when (requestedOrientation) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE -> "Horizontal forzada"
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT -> "Vertical forzada"
                else -> "Automática"
            })
            info.put("size", web.width.toString() + " × " + web.height)
            return info.toString()
        }

        @JavascriptInterface fun openUrl(url: String) { runOnUiThread { this@MainActivity.openUrl(url) } }

        @JavascriptInterface fun openPlayStore() {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=games&c=apps"))) }
                catch (_: ActivityNotFoundException) { openUrl("https://play.google.com/store/search?q=games&c=apps") }
            }
        }

        @JavascriptInterface fun openSystemSettings() { runOnUiThread { startActivity(Intent(Settings.ACTION_SETTINGS)) } }

        @JavascriptInterface fun openDownloads() {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://com.android.providers.downloads.documents/root/downloads"), "vnd.android.document/root").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                catch (_: Exception) { try { startActivity(Intent(Intent.ACTION_GET_CONTENT).setType("*/*")) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Abre la app Archivos del móvil", Toast.LENGTH_SHORT).show() } }
            }
        }

        @JavascriptInterface fun getInstalledApps(): String {
            val arr = JSONArray()
            try {
                val pm = packageManager
                val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
                @Suppress("DEPRECATION")
                val activities = pm.queryIntentActivities(intent, 0)
                val seen = HashSet<String>()
                for (info in activities) {
                    val packageName = info.activityInfo.packageName ?: continue
                    if (packageName == this@MainActivity.packageName || !seen.add(packageName)) continue
                    val item = JSONObject()
                    item.put("name", info.loadLabel(pm).toString())
                    item.put("packageName", packageName)
                    item.put("emoji", "🎮")
                    arr.put(item)
                }
            } catch (_: Exception) {}
            return arr.toString()
        }

        @JavascriptInterface fun launchPackage(packageName: String): Boolean {
            return try {
                runOnUiThread {
                    val launch = packageManager.getLaunchIntentForPackage(packageName)
                    if (launch != null) startActivity(launch)
                    else Toast.makeText(this@MainActivity, "Esta aplicación no tiene acceso directo", Toast.LENGTH_SHORT).show()
                }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun openAppInfo(packageName: String) {
            runOnUiThread {
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "No se pudo abrir la información de la app", Toast.LENGTH_SHORT).show() }
            }
        }
    }
}
