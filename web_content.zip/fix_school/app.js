const app=document.querySelector('#app');
const buttons=[...document.querySelectorAll('nav button')];
const sidebar=document.querySelector('#sidebar');

const defaults={
 students:[['ST001','Ahmed Ali','Grade 9','Active'],['ST002','Salra Mohamed','Grade 8','Active'],['ST003','Yusuf Hassan','Grade 7','Active'],['ST004','Ayaan Farah','Grade 6','Active'],['ST005','Fatima Noor','Grade 5','Active']],
 teachers:[['T001','Said Mohamed','Mathematics','Active'],['T002','Amina Yusuf','English','Active'],['T003','Ali Hassan','Science','Active']],
 classes:[['Grade 9','A','32','Active'],['Grade 8','A','30','Active'],['Grade 7','A','28','Active']],
 subjects:[['Mathematics','Grade 9–12','Active'],['English','Grade 1–12','Active'],['Science','Grade 6–12','Active']],
 exams:[['Mid Term Exam','Mathematics','Grade 9','2026-09-10','Active'],['Final Exam','Science','Grade 7','2026-12-05','Active']],
 parents:[['Mohamed Ali','0612345678','2','Active'],['Amina Hassan','0623456789','1','Active']],
 fees:[['Ahmed Ali','Grade 9','$500','$350','$150','Pending'],['Salra Mohamed','Grade 8','$500','$500','$0','Paid'],['Yusuf Hassan','Grade 7','$500','$300','$200','Pending']],
 attendance:[['Ahmed Ali','Grade 9','Present'],['Salra Mohamed','Grade 8','Present'],['Yusuf Hassan','Grade 7','Absent'],['Ayaan Farah','Grade 6','Present'],['Fatima Noor','Grade 5','Present']]
};

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function load(key){try{const x=JSON.parse(localStorage.getItem('school_'+key));return Array.isArray(x)?x:defaults[key].map(r=>[...r]);}catch(e){return defaults[key].map(r=>[...r]);}}
function save(key,data){localStorage.setItem('school_'+key,JSON.stringify(data));}
function head(t,d,b='',cls=''){return `<div class="head"><div><h2>${esc(t)}</h2><p>${esc(d)}</p></div>${b?`<button class="primary ${cls}" id="pageAction">${b}</button>`:''}</div>`}
function badge(v){const low=String(v).toLowerCase();let c=low==='active'||low==='paid'||low==='present'?'badge':low==='pending'?'badge pending':'badge danger';return `<span class="${c}">${esc(v)}</span>`}
function table(data,headers,opts={}){
 const action=opts.actions!==false;
 return `<div class="card tablebox"><table class="table"><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${data.length?data.map((r,i)=>`<tr>${r.map((x,j)=>`<td>${(opts.badgeLast&&j===r.length-1)||(['Status','Attendance'].includes(headers[j]))?badge(x):esc(x)}</td>`).join('')}${action?`<td><button class="row-btn edit-btn" data-index="${i}" title="Edit">✏️</button><button class="row-btn delete-btn" data-index="${i}" title="Delete">🗑️</button></td>`:''}</tr>`).join(''):`<tr><td colspan="${headers.length+1}" class="empty">No records found.</td></tr>`}</tbody></table></div>`;
}
function list(key,title,desc,headers,button,opts={}){return `<div class="page">${head(title,desc,button)}${table(load(key),headers,opts)}</div>`}

function modal(title,desc,form,saveText='Save'){return `<div class="modal-backdrop" id="modal"><div class="modal"><button class="close" id="closeModal">×</button><h2>${esc(title)}</h2><p>${esc(desc)}</p><form id="dataForm">${form}<div class="modal-actions"><button type="button" class="secondary" id="cancelModal">Cancel</button><button type="submit" class="primary">${esc(saveText)}</button></div></form></div></div>`}
function field(label,id,value='',type='text',required=true){return `<div class="field"><label>${esc(label)}</label><input id="${id}" type="${type}" value="${esc(value)}" ${required?'required':''}></div>`}
function selectField(label,id,options,value){return `<div class="field"><label>${esc(label)}</label><select id="${id}">${options.map(x=>`<option ${String(x)===String(value)?'selected':''}>${esc(x)}</option>`).join('')}</select></div>`}
function openModal(html,onSubmit){document.body.insertAdjacentHTML('beforeend',html);const m=document.querySelector('#modal');const close=()=>m?.remove();document.querySelector('#closeModal').onclick=close;document.querySelector('#cancelModal').onclick=close;document.querySelector('#dataForm').onsubmit=e=>{e.preventDefault();onSubmit(close)};}
function showToast(msg){const t=document.createElement('div');t.className='toast';t.textContent='✓  '+msg;document.body.appendChild(t);setTimeout(()=>t.remove(),2500)}

function studentForm(i=null){const a=load('students'),r=i===null?['','','Grade 1','Active']:a[i];return modal(i===null?'Add Student':'Edit Student','Enter the student information below.',`<div class="form">${field('Student ID','sid',r[0])}${field('Student Name','sname',r[1])}${selectField('Class','sclass',[...Array(12)].map((_,n)=>'Grade '+(n+1)),r[2])}${selectField('Status','sstatus',['Active','Inactive'],r[3])}</div>`,i===null?'Add Student':'Save Changes')}
function teacherForm(i=null){const a=load('teachers'),r=i===null?['','','','Active']:a[i];return modal(i===null?'Add Teacher':'Edit Teacher','Enter the teacher information below.',`<div class="form">${field('Teacher ID','tid',r[0])}${field('Teacher Name','tname',r[1])}${field('Subject','tsubject',r[2])}${selectField('Status','tstatus',['Active','Inactive'],r[3])}</div>`,i===null?'Add Teacher':'Save Changes')}
function classForm(i=null){const a=load('classes'),r=i===null?['Grade 1','','0','Active']:a[i];return modal(i===null?'Add Class':'Edit Class','Enter the class information below.',`<div class="form">${selectField('Class Name','cname',[...Array(12)].map((_,n)=>'Grade '+(n+1)),r[0])}${field('Section','csection',r[1])}${field('Number of Students','cstudents',r[2],'number')}${selectField('Status','cstatus',['Active','Inactive'],r[3])}</div>`,i===null?'Add Class':'Save Changes')}
function subjectForm(i=null){const a=load('subjects'),r=i===null?['','','Active']:a[i];return modal(i===null?'Add Subject':'Edit Subject','Enter the subject information below.',`<div class="form">${field('Subject Name','subname',r[0])}${field('Classes','subclasses',r[1],'text')}${selectField('Status','substatus',['Active','Inactive'],r[2])}</div>`,i===null?'Add Subject':'Save Changes')}
function examForm(i=null){const a=load('exams'),r=i===null?['','','Grade 1',new Date().toISOString().slice(0,10),'Active']:a[i];return modal(i===null?'Add Examination':'Edit Examination','Enter the examination details below.',`<div class="form">${field('Exam Name','ename',r[0])}${field('Subject','esubject',r[1])}${selectField('Class','eclass',[...Array(12)].map((_,n)=>'Grade '+(n+1)),r[2])}${field('Date','edate',r[3],'date')}${selectField('Status','estatus',['Active','Completed','Pending'],r[4])}</div>`,i===null?'Add Exam':'Save Changes')}
function parentForm(i=null){const a=load('parents'),r=i===null?['','','1','Active']:a[i];return modal(i===null?'Add Parent':'Edit Parent','Enter the parent or guardian information below.',`<div class="form">${field('Parent Name','pname',r[0])}${field('Phone','pphone',r[1])}${field('Number of Children','pchildren',r[2],'number')}${selectField('Status','pstatus',['Active','Inactive'],r[3])}</div>`,i===null?'Add Parent':'Save Changes')}
function feeForm(i=null){const a=load('fees'),r=i===null?['','','500','0','500','Pending']:a[i];return modal(i===null?'Record Payment':'Edit Fee Record','Enter fee and payment information.',`<div class="form">${field('Student Name','fname',r[0])}${field('Class','fclass',r[1])}${field('Total Fee','ftotal',String(r[2]).replace('$',''),'number')}${field('Paid Amount','fpaid',String(r[3]).replace('$',''),'number')}</div>`,i===null?'Record Payment':'Save Changes')}

function bindCrud(key,formFn,uniqueIndex=null){
 document.querySelector('#pageAction')?.addEventListener('click',()=>openCrud(key,formFn,null,uniqueIndex));
 document.querySelectorAll('.edit-btn').forEach(b=>b.addEventListener('click',()=>openCrud(key,formFn,+b.dataset.index,uniqueIndex)));
 document.querySelectorAll('.delete-btn').forEach(b=>b.addEventListener('click',()=>{const a=load(key),i=+b.dataset.index;if(confirm(`Delete ${a[i]?.[0]||'this record'}?`)){a.splice(i,1);save(key,a);go(key);showToast('Record deleted successfully!')}}));
}
function openCrud(key,formFn,i,uniqueIndex){openModal(formFn(i),close=>{const a=load(key);let row;if(key==='students')row=[sid.value.trim(),sname.value.trim(),sclass.value,sstatus.value];
else if(key==='teachers')row=[tid.value.trim(),tname.value.trim(),tsubject.value.trim(),tstatus.value];
else if(key==='classes')row=[cname.value,csection.value.trim(),cstudents.value,cstatus.value];
else if(key==='subjects')row=[subname.value.trim(),subclasses.value.trim(),substatus.value];
else if(key==='exams')row=[ename.value.trim(),esubject.value.trim(),eclass.value,edate.value,estatus.value];
else if(key==='parents')row=[pname.value.trim(),pphone.value.trim(),pchildren.value,pstatus.value];
else if(key==='fees'){const total=Number(ftotal.value||0),paid=Number(fpaid.value||0),balance=Math.max(total-paid,0);row=[fname.value.trim(),fclass.value.trim(),'$'+total.toFixed(0),'$'+paid.toFixed(0),'$'+balance.toFixed(0),balance===0?'Paid':'Pending'];}
if(row.some(x=>String(x).trim()===''))return alert('Please complete all required fields.');
if(uniqueIndex!==null){const val=String(row[uniqueIndex]).toLowerCase();if(a.some((x,idx)=>idx!==i&&String(x[uniqueIndex]).toLowerCase()===val))return alert('This ID already exists.');}
if(key==='classes'){const k=(row[0]+'|'+row[1]).toLowerCase();if(a.some((x,idx)=>idx!==i&&(x[0]+'|'+x[1]).toLowerCase()===k))return alert('This class and section already exists.');}
i===null?a.push(row):a[i]=row;save(key,a);close();go(key);showToast(i===null?`${key==='fees'?'Payment recorded':key.slice(0,-1).replace(/^teachers$/,'Teacher')} added successfully!`:'Record updated successfully!')});}

function attendancePage(){const a=load('attendance');return `<div class="page">${head('Attendance','Mark and manage daily student attendance.','Save Attendance')}<div class="card tablebox"><table class="table"><thead><tr><th>Student</th><th>Class</th><th>Attendance</th><th>Action</th></tr></thead><tbody>${a.map((r,i)=>`<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${badge(r[2])}</td><td><button class="attendance-toggle row-btn" data-index="${i}">${r[2]==='Present'?'🔴 Mark Absent':'🟢 Mark Present'}</button></td></tr>`).join('')}</tbody></table></div></div>`}
function bindAttendance(){document.querySelector('#pageAction').onclick=()=>{save('attendance',load('attendance'));showToast('Attendance saved successfully!')};document.querySelectorAll('.attendance-toggle').forEach(b=>b.onclick=()=>{const a=load('attendance'),i=+b.dataset.index;a[i][2]=a[i][2]==='Present'?'Absent':'Present';save('attendance',a);go('attendance')})}

function dashboard(){const s=load('students'),t=load('teachers'),c=load('classes'),f=load('fees');const collected=f.reduce((n,r)=>n+Number(String(r[3]).replace('$','')) ,0);return `<div class="page">${head('Dashboard',"Welcome back, Admin! Here's what's happening at Al-Taqwa Institute.",'2026–2027')}<div class="cards"><div class="card stat"><div><h3>${s.length}</h3><p>Total Students</p><span class="trend">↗ Live data</span></div><div class="icon">👨‍🎓</div></div><div class="card stat"><div><h3>${t.length}</h3><p>Total Teachers</p><span class="trend">↗ Live data</span></div><div class="icon">👨‍🏫</div></div><div class="card stat"><div><h3>${c.length}</h3><p>Total Classes</p><span class="trend">↗ Live data</span></div><div class="icon">🏫</div></div><div class="card stat"><div><h3>$${collected.toFixed(0)}</h3><p>Fees Collected</p><span class="trend">↗ Live data</span></div><div class="icon">💰</div></div></div><div class="grid"><div class="card"><div class="title">Student Enrollment <span>Current</span></div><div class="chart">${[45,65,58,92,75,120,105,140,130].map(n=>`<div class="bar" style="height:${n}px"></div>`).join('')}</div></div><div class="card"><div class="title">Fees Collection</div><div class="donutbox"><div class="donut"></div><div>🟢 Paid<br><br>🟠 Pending<br><br>🔴 Overdue</div></div></div></div><div class="grid"><div>${head('Recent Students','Latest registered students')}${table(s.slice(-4).reverse(),['Student ID','Name','Class','Status','Action'])}</div><div class="card"><div class="title">Recent Activity</div>👤 Student records updated<br><br>💵 Fee payment recorded<br><br>👨‍🏫 Teacher records updated<br><br>📝 Attendance updated</div></div></div>`}

const pages={
 dashboard,
 students:()=>list('students','Students','Manage and view all students.',['Student ID','Name','Class','Status','Action'],'+ Add Student'),
 teachers:()=>list('teachers','Teachers','Manage teacher information.',['Teacher ID','Name','Subject','Status','Action'],'+ Add Teacher'),
 classes:()=>list('classes','Classes','Manage classes and sections.',['Class','Section','Students','Status','Action'],'+ Add Class'),
 subjects:()=>list('subjects','Subjects','Manage academic subjects.',['Subject','Classes','Status','Action'],'+ Add Subject'),
 attendance:attendancePage,
 exams:()=>list('exams','Examinations','Manage exams and examination records.',['Exam','Subject','Class','Date','Status','Action'],'+ Add Exam'),
 fees:()=>list('fees','Fees & Finance','Manage student fees, payments and balances.',['Student','Class','Total Fee','Paid','Balance','Status','Action'],'+ Record Payment'),
 parents:()=>list('parents','Parents','Manage parent and guardian information.',['Parent','Phone','Children','Status','Action'],'+ Add Parent'),
 communication:()=>list('communication','Communication','Send announcements and notifications.',[['School Reopening','All Students','2026-09-01','Published'],['Exam Reminder','Students','2026-08-29','Published']],['Title','Audience','Date','Status','Action'],'+ New Announcement'),
 reports:()=>`<div class="page">${head('Reports','View and generate school reports.')}<div class="cards">${['👨‍🎓 Student Report','📝 Attendance Report','📋 Examination Report','💰 Financial Report'].map(x=>`<div class="card setting"><div class="icon">${x[0]}</div><div><h3>${esc(x.slice(2))}</h3><p>Generate detailed report</p></div></div>`).join('')}</div></div>`,
 settings:()=>{const a=[['🏫','School Information','Name, logo, address and contact'],['👥','Users & Accounts','Manage system users'],['🔐','Roles & Permissions','Access rights for every role'],['📚','Academic Settings','Classes, subjects and grades'],['💰','Finance Settings','Fees, payments and currency'],['📝','Examination Settings','Exam types and grade system'],['📢','Notification Settings','Announcements and notifications'],['🎨','Appearance','Theme, language and branding'],['🔒','Security','Password and login security'],['🛠️','System Management','Backup, restore and activity logs']];return `<div class="page">${head('Settings','Manage and configure the entire school management system.')}<div class="settings">${a.map(x=>`<div class="card setting" onclick="setting('${esc(x[1])}')"><div class="icon">${x[0]}</div><div><h3>${esc(x[1])}</h3><p>${esc(x[2])}</p></div>→</div>`).join('')}</div></div>`}
};

window.setting=t=>app.innerHTML=`<div class="page">${head(t,'Configure this section of the system.','Save Changes')}<div class="card form">${['Name','Phone','Email','Address'].map(x=>`<div class="field"><label>${x}</label><input placeholder="Enter ${x.toLowerCase()}"></div>`).join('')}</div></div>`;

function go(p){buttons.forEach(b=>b.classList.toggle('active',b.dataset.page===p));app.innerHTML=pages[p]?pages[p]():dashboard();sidebar.classList.remove('open');
 if(['students','teachers','classes','subjects','exams','fees','parents'].includes(p)){
  const forms={students:studentForm,teachers:teacherForm,classes:classForm,subjects:subjectForm,exams:examForm,fees:feeForm,parents:parentForm};
  const unique={students:0,teachers:0}[p]??null;bindCrud(p,forms[p],unique);
 }
 if(p==='attendance')bindAttendance();
}
buttons.forEach(b=>b.onclick=()=>go(b.dataset.page));
document.querySelector('#menu').onclick=()=>sidebar.classList.toggle('open');
go('dashboard');
