AL-TAQWA INSTITUTE — NEW SCHOOL MANAGEMENT SYSTEM
FIXED v4

Working CRUD sections:
- Students: Add / Edit / Delete / localStorage
- Teachers: Add / Edit / Delete / localStorage
- Classes: Add / Edit / Delete / localStorage
- Subjects: Add / Edit / Delete / localStorage
- Attendance: Mark Present/Absent + Save
- Examinations: Add / Edit / Delete / localStorage
- Fees & Finance: Record Payment / Edit / Delete / automatic balance
- Parents: Add / Edit / Delete / localStorage

The design remains responsive for mobile and desktop.
This version is still frontend/localStorage; it is not yet connected to a shared online database or real authentication.
