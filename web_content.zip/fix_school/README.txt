AL-TAQWA INSTITUTE — School Management System
New Project • Phase 1 frontend foundation

NEW IN THIS VERSION (v6):
- Working School Profile in the top-right profile area.
- Change school logo from the phone/device.
- Change school name.
- Save school phone, email, address, principal/head teacher and academic year.
- Add editable school information/about text.
- Saved profile data automatically updates the sidebar branding and top profile.
- Settings → School Information opens the same profile editor.
- Communication page localStorage data issue fixed.

CURRENT MODULES:
Dashboard, Students, Teachers, Classes, Subjects, Attendance, Examinations,
Fees, Parents, Communication, Reports, Settings.

STORAGE:
Data is saved locally in browser localStorage on the device. This is still a
frontend/local-storage project; it is not yet a shared online database or real
multi-user authentication system.

USE:
Open index.html in a modern browser. On mobile, use the menu button to open
navigation. Tap/click the top-right school profile area to edit school branding
and information.
