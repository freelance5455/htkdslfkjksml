// MINHO AI - Multi-provider backend
// Node.js 18+. Keep all API keys in server environment variables.
require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN ? process.env.ALLOWED_ORIGIN.split(",") : true }));
app.use(express.json({ limit: "3mb" }));
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const MAX_HISTORY = 16;

function requireValue(name) {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is not configured on the server.`);
  return value;
}
function cleanHistory(history) {
  if (!Array.isArray(history)) return [];
  return history.slice(-MAX_HISTORY).filter(m =>
    m && ["user", "assistant"].includes(m.role) && typeof m.content === "string"
  ).map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));
}
async function readJson(response, service) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data?.error?.message || data?.error || data?.message || `${service} request failed (${response.status})`;
    throw new Error(typeof message === "string" ? message : JSON.stringify(message));
  }
  return data;
}

// Google Programmable Search Engine / Custom Search JSON API.
async function googleSearch(query) {
  const key = process.env.GOOGLE_CSE_KEY;
  const cx = process.env.GOOGLE_CSE_CX;
  if (!key || !cx) throw new Error("Google Search is not configured. Set GOOGLE_CSE_KEY and GOOGLE_CSE_CX.");
  const url = new URL("https://www.googleapis.com/customsearch/v1");
  url.searchParams.set("key", key);
  url.searchParams.set("cx", cx);
  url.searchParams.set("q", query.slice(0, 500));
  url.searchParams.set("num", "5");
  const response = await fetch(url);
  const data = await readJson(response, "Google Search");
  return (data.items || []).map(item => ({
    title: item.title || item.link,
    link: item.link,
    snippet: item.snippet || ""
  }));
}
function searchContext(sources) {
  if (!sources.length) return "";
  return "\n\nWEB SEARCH RESULTS (use these as sources, distinguish source facts from your own explanation):\n" +
    sources.map((s, i) => `[${i+1}] ${s.title}\n${s.snippet}\nURL: ${s.link}`).join("\n\n");
}

async function callGemini(message, history, sources) {
  const key = requireValue("GEMINI_API_KEY");
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const contents = history.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }]
  }));
  contents.push({ role: "user", parts: [{ text: message + searchContext(sources) }] });
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents,
      generationConfig: { temperature: 0.6, maxOutputTokens: 1800 }
    })
  });
  const data = await readJson(response, "Gemini");
  return data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "Gemini returned no text.";
}

async function callGrok(message, history, sources) {
  const key = requireValue("XAI_API_KEY");
  const model = process.env.GROK_MODEL || "grok-3-mini";
  const messages = [
    { role: "system", content: "You are Minho AI, a helpful and careful assistant. Answer clearly. Be honest about uncertainty. When web sources are supplied, use them and cite their URLs." },
    ...history,
    { role: "user", content: message + searchContext(sources) }
  ];
  const response = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
    body: JSON.stringify({ model, messages, temperature: 0.6 })
  });
  const data = await readJson(response, "Grok");
  return data.choices?.[0]?.message?.content || "Grok returned no text.";
}

async function callClaude(message, history, sources) {
  const key = requireValue("ANTHROPIC_API_KEY");
  const model = process.env.CLAUDE_MODEL || "claude-3-5-haiku-latest";
  const messages = [
    ...history.map(m => ({ role: m.role, content: m.content })),
    { role: "user", content: message + searchContext(sources) }
  ];
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({ model, max_tokens: 1800, messages })
  });
  const data = await readJson(response, "Claude");
  return data.content?.filter(c => c.type === "text").map(c => c.text).join("\n") || "Claude returned no text.";
}

app.get("/api/health", (_req, res) => {
  res.json({
    app: "Minho AI",
    status: "online",
    configured: {
      gemini: Boolean(process.env.GEMINI_API_KEY),
      grok: Boolean(process.env.XAI_API_KEY),
      claude: Boolean(process.env.ANTHROPIC_API_KEY),
      googleSearch: Boolean(process.env.GOOGLE_CSE_KEY && process.env.GOOGLE_CSE_CX),
      image: Boolean(process.env.OPENAI_API_KEY)
    }
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Please enter a message." });
    if (message.length > 12000) return res.status(413).json({ error: "Message is too long." });

    const provider = String(req.body.provider || "gemini").toLowerCase();
    const mode = req.body.mode === "research" ? "research" : "chat";
    const history = cleanHistory(req.body.history);
    const sources = mode === "research" ? await googleSearch(message) : [];

    const providers = { gemini: callGemini, grok: callGrok, xai: callGrok, claude: callClaude, anthropic: callClaude };
    const handler = providers[provider];
    if (!handler) return res.status(400).json({ error: "Unknown provider. Choose gemini, grok, or claude." });

    const reply = await handler(message, history, sources);
    res.json({ reply, sources, provider: provider === "xai" ? "grok" : provider });
  } catch (error) {
    console.error("Chat error:", error.message);
    res.status(502).json({ error: error.message || "The AI service could not complete the request." });
  }
});

// Optional image generation endpoint using OpenAI Images API.
// This is independent image generation, not Meta AI's private model.
app.post("/api/image", async (req, res) => {
  try {
    const key = requireValue("OPENAI_API_KEY");
    const prompt = typeof req.body.prompt === "string" ? req.body.prompt.trim().slice(0, 1800) : "";
    if (!prompt) return res.status(400).json({ error: "Please describe the image." });
    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
      body: JSON.stringify({ model: process.env.IMAGE_MODEL || "gpt-image-1", prompt, size: "1024x1024" })
    });
    const data = await readJson(response, "Image generation");
    const image = data.data?.[0]?.b64_json;
    if (!image) throw new Error("The image provider did not return image data.");
    res.json({ imageUrl: `data:image/png;base64,${image}` });
  } catch (error) {
    console.error("Image error:", error.message);
    res.status(502).json({ error: error.message || "Image generation failed." });
  }
});

app.listen(PORT, () => console.log(`MINHO AI backend listening on port ${PORT}`));
