# MINHO AI connected backend

This package contains the Node.js backend configured for Gemini, Grok (xAI), Claude, Google Programmable Search Engine, and optional image generation.

## Deploy
1. Put `server.js`, `package.json`, and `.env.example` in your backend project/repository.
2. Deploy as a Node web service with build command `npm install` and start command `npm start`.
3. In the hosting dashboard, add the environment variables listed in `.env.example`.
4. Set the frontend's Connections > Backend URL to the deployed HTTPS URL.
5. Test `https://YOUR-SERVER/api/health`.

## Provider IDs accepted by POST /api/chat
- `gemini`
- `grok` (also accepts `xai`)
- `claude` (also accepts `anthropic`)

Request body:
`{"provider":"gemini","message":"Hello","history":[],"mode":"chat"}`

Use `"mode":"research"` to run Google Custom Search first and pass the results to the selected model. Google Search requires both `GOOGLE_CSE_KEY` and `GOOGLE_CSE_CX`.

## Image generation
POST `/api/image` with `{"prompt":"..."}`. Requires `OPENAI_API_KEY`. This uses the OpenAI Images API; it is not Meta AI.

## Important
The code is integrated but will not make live provider calls until you supply valid API credentials. Provider APIs may have costs, quotas, regional/account restrictions, and model availability changes. Check the providers' current documentation and pricing. If you are under 18, involve a parent/guardian for account creation and billing.

Never expose API keys in browser JavaScript, APK files, screenshots, chat messages, or public repositories. Store them only as private environment variables on the server. Add authentication, rate limits, request logging controls, and abuse prevention before allowing public users.
