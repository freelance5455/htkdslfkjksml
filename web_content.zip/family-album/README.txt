FAMILY ALBUM APP
================
Files:
  index.html  - the page (open this file)
  style.css   - the design
  app.js      - the app logic

How to use:
  1. Unzip the folder.
  2. Double-click index.html to open it in a browser (works on phone and computer).
  3. To put it online for the family, upload the whole folder to any web host
     (Netlify Drop, GitHub Pages, Firebase Hosting).

Important:
  Outside Claude this version saves data only in the browser of each device
  (localStorage). It is not yet one shared database for all family members.
  To share one tree with 500+ relatives you need a backend (e.g. Firebase) with
  phone login and an admin. Use "Download family list (CSV)" to back up, and
  "Import family list (CSV)" to load data into the next version.
