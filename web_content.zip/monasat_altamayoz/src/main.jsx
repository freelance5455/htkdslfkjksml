import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  BookOpen, GraduationCap, Search, Moon, Sun, Menu, X, ClipboardCheck,
  CalendarDays, FileText, Trophy, Clock3, ChevronLeft, ChevronDown,
  CheckCircle2, CircleHelp, Upload, LogIn, LogOut, UserRound, LayoutDashboard,
  Plus, Trash2, Download, LoaderCircle, AlertCircle, ShieldCheck, Sparkles,
  BookMarked, ChartNoAxesColumnIncreasing, ExternalLink
} from "lucide-react";
import {
  auth, db, storage, firebaseConfigured
} from "./firebase";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut,
  onAuthStateChanged
} from "firebase/auth";
import {
  addDoc, collection, doc, getDoc, getDocs, onSnapshot, orderBy, query,
  serverTimestamp, setDoc, where
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import "./styles.css";

const grades = [
  { id:"p1", name:"الأول الابتدائي", stage:"ابتدائية" }, { id:"p2", name:"الثاني الابتدائي", stage:"ابتدائية" },
  { id:"p3", name:"الثالث الابتدائي", stage:"ابتدائية" }, { id:"p4", name:"الرابع الابتدائي", stage:"ابتدائية" },
  { id:"p5", name:"الخامس الابتدائي", stage:"ابتدائية" }, { id:"p6", name:"السادس الابتدائي", stage:"ابتدائية" },
  { id:"m1", name:"الأول الإعدادي", stage:"إعدادية" }, { id:"m2", name:"الثاني الإعدادي", stage:"إعدادية" },
  { id:"m3", name:"الثالث الإعدادي", stage:"إعدادية" }, { id:"s1", name:"الأول الثانوي", stage:"ثانوية" },
  { id:"s2", name:"الثاني الثانوي", stage:"ثانوية" }, { id:"s3_sci", name:"الثالث الثانوي - علمي علوم", stage:"ثانوية" },
  { id:"s3_math", name:"الثالث الثانوي - علمي رياضة", stage:"ثانوية" }, { id:"s3_lit", name:"الثالث الثانوي - أدبي", stage:"ثانوية" }
];
const starterMaterials = [
  { id:"demo-ar", title:"مراجعة اللغة العربية", subject:"اللغة العربية", grade:"s2", type:"ملخص", description:"مراجعة تجريبية لتجربة المنصة.", url:"", demo:true },
  { id:"demo-en", title:"أساسيات اللغة الإنجليزية", subject:"اللغة الإنجليزية", grade:"s2", type:"ملخص", description:"نموذج مادة تجريبي قابل للاستبدال بمحتواك.", url:"", demo:true },
  { id:"demo-chem", title:"مدخل إلى الكيمياء", subject:"الكيمياء", grade:"s2", type:"ملخص", description:"محتوى تجريبي، وليس ملفًا رسميًا من المنهج.", url:"", demo:true },
  { id:"demo-math", title:"تدريبات الرياضيات", subject:"الرياضيات", grade:"s2", type:"تدريبات", description:"تدريبات بسيطة لتجربة واجهة الطالب.", url:"", demo:true }
];
const quizBank = [
  { id:1, subject:"الكيمياء", grade:"s2", q:"ما الرمز الكيميائي للماء؟", options:["CO₂","H₂O","O₂","NaCl"], answer:1, explanation:"يتكون جزيء الماء من ذرتي هيدروجين وذرة أكسجين." },
  { id:2, subject:"الرياضيات", grade:"s2", q:"إذا كان 3x = 18، فما قيمة x؟", options:["3","6","9","15"], answer:1, explanation:"نقسم الطرفين على 3، فنحصل على x = 6." },
  { id:3, subject:"الأحياء", grade:"s2", q:"ما العضية المسؤولة أساسًا عن إنتاج ATP في الخلية؟", options:["النواة","جهاز جولجي","الميتوكوندريا","الريبوسوم"], answer:2, explanation:"الميتوكوندريا موقع رئيسي للتنفس الخلوي وإنتاج ATP." },
  { id:4, subject:"اللغة العربية", grade:"s2", q:"أي الكلمات الآتية فعل مضارع؟", options:["كتبَ","اكتبْ","يكتبُ","كتاب"], answer:2, explanation:"الفعل المضارع يدل على حدث يقع في الحاضر أو المستقبل." },
  { id:5, subject:"اللغة الإنجليزية", grade:"s2", q:"Choose the correct sentence.", options:["She go to school.","She goes to school.","She going school.","She gone school."], answer:1, explanation:"مع She في المضارع البسيط نضيف s إلى الفعل غالبًا." },
  { id:6, subject:"الفيزياء", grade:"s2", q:"ما وحدة قياس شدة التيار الكهربائي؟", options:["الفولت","الأوم","الأمبير","الواط"], answer:2, explanation:"تقاس شدة التيار الكهربائي بالأمبير." }
];
const stages = [
  { title:"المرحلة الابتدائية", desc:"خطوات تأسيسية ومهارات أساسية", icon:"🌱", items:grades.filter(g=>g.stage==="ابتدائية") },
  { title:"المرحلة الإعدادية", desc:"تعميق الفهم والاستعداد للمرحلة التالية", icon:"📘", items:grades.filter(g=>g.stage==="إعدادية") },
  { title:"المرحلة الثانوية", desc:"مواد التخصص والمراجعة والامتحانات", icon:"🎓", items:grades.filter(g=>g.stage==="ثانوية") }
];
const subjectColors = ["mint","violet","amber","blue","rose","teal"];

function App() {
  const [user,setUser] = useState(null);
  const [profile,setProfile] = useState(null);
  const [materials,setMaterials] = useState(starterMaterials);
  const [results,setResults] = useState([]);
  const [plans,setPlans] = useState([]);
  const [dark,setDark] = useState(() => localStorage.getItem("tamayoz-dark")==="true");
  const [mobileOpen,setMobileOpen] = useState(false);
  const [search,setSearch] = useState("");
  const [grade,setGrade] = useState("s2");
  const [activeTab,setActiveTab] = useState("home");
  const [modal,setModal] = useState("");
  const [authMode,setAuthMode] = useState("login");
  const [authBusy,setAuthBusy] = useState(false);
  const [notice,setNotice] = useState("");
  const [quizSubject,setQuizSubject] = useState("الكيمياء");
  const [quizAnswers,setQuizAnswers] = useState({});
  const [quizSubmitted,setQuizSubmitted] = useState(false);
  const [planForm,setPlanForm] = useState({subject:"الكيمياء",date:new Date().toISOString().slice(0,10),start:"17:00",minutes:"45",task:"مراجعة الدرس وحل التدريبات"});
  const [uploadBusy,setUploadBusy] = useState(false);
  const [adminForm,setAdminForm] = useState({title:"",subject:"",grade:"s2",description:""});
  const [pdfFile,setPdfFile] = useState(null);
  const [showAdmin,setShowAdmin] = useState(false);

  useEffect(()=>{ document.documentElement.classList.toggle("dark",dark); localStorage.setItem("tamayoz-dark",String(dark)); },[dark]);
  useEffect(()=>{
    if(!auth) return;
    return onAuthStateChanged(auth,async current=>{
    setUser(current);
    if(current && db) {
      try { const snap=await getDoc(doc(db,"users",current.uid)); setProfile(snap.exists()?snap.data():{displayName:current.displayName||current.email?.split("@")[0],grade:"s2",role:"student"}); }
      catch { setProfile({displayName:current.displayName||current.email?.split("@")[0],grade:"s2",role:"student"}); }
    } else { setProfile(null); }
  });
  },[]);
  useEffect(()=>{
    if(!db) return;
    const unsub=onSnapshot(collection(db,"materials"),snap=>{
      const remote=snap.docs.map(d=>({id:d.id,...d.data()}));
      setMaterials(remote.length?remote:starterMaterials);
    },()=>{});
    return unsub;
  },[]);
  useEffect(()=>{
    if(!user||!db) { setResults([]); setPlans([]); return; }
    const u1=onSnapshot(query(collection(db,"quizResults"),where("uid","==",user.uid)),s=>setResults(s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0))),()=>{});
    const u2=onSnapshot(query(collection(db,"studyPlans"),where("uid","==",user.uid)),s=>setPlans(s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(a.date||"").localeCompare(b.date||""))),()=>{});
    return ()=>{u1();u2();};
  },[user]);
  const isAdmin = Boolean(profile?.role==="admin");
  const filteredMaterials = useMemo(()=>materials.filter(m=>
    (m.title+" "+m.subject+" "+m.description+" "+(grades.find(g=>g.id===m.grade)?.name||"")).toLowerCase().includes(search.toLowerCase()) &&
    (!grade || m.grade===grade || m.grade==="all")
  ),[materials,search,grade]);
  const quizQuestions = useMemo(()=>quizBank.filter(q=>q.subject===quizSubject && (!grade||q.grade===grade)).length ? quizBank.filter(q=>q.subject===quizSubject && (!grade||q.grade===grade)) : quizBank.filter(q=>q.subject===quizSubject),[quizSubject,grade]);
  const score = quizQuestions.reduce((n,q)=>n+(quizAnswers[q.id]===q.answer?1:0),0);
  const average = results.length ? Math.round(results.reduce((n,r)=>n+(r.score||0),0)/results.length) : 0;

  function toast(msg){ setNotice(msg); window.setTimeout(()=>setNotice(""),3500); }
  function go(tab){setActiveTab(tab);setMobileOpen(false);document.getElementById(tab==="home"?"home":tab)?.scrollIntoView({behavior:"smooth",block:"start"});}
  async function handleAuth(e){
    e.preventDefault(); setAuthBusy(true);
    const fd=new FormData(e.currentTarget),email=String(fd.get("email")||"").trim(),password=String(fd.get("password")||""),name=String(fd.get("name")||"").trim(),g=String(fd.get("grade")||"s2");
    try {
      if(!firebaseConfigured) { toast("أضف إعدادات Firebase في ملف .env.local أولًا."); return; }
      let cred;
      if(authMode==="signup") {
        cred=await createUserWithEmailAndPassword(auth,email,password);
        await setDoc(doc(db,"users",cred.user.uid),{displayName:name,grade:g,role:"student",createdAt:serverTimestamp()});
        setProfile({displayName:name,grade:g,role:"student"}); setGrade(g);
      } else { cred=await signInWithEmailAndPassword(auth,email,password); const s=await getDoc(doc(db,"users",cred.user.uid)); if(s.exists()){setProfile(s.data());setGrade(s.data().grade||"s2");} }
      setModal(""); toast(authMode==="signup"?"تم إنشاء الحساب.":"تم تسجيل الدخول.");
    } catch(err){ toast(friendlyError(err.code)); }
    finally {setAuthBusy(false);}
  }
  async function submitQuiz(){
    if(quizQuestions.some(q=>quizAnswers[q.id]===undefined)){toast("أجب عن جميع الأسئلة أولًا.");return;}
    setQuizSubmitted(true);
    if(user&&db){try{await addDoc(collection(db,"quizResults"),{uid:user.uid,subject:quizSubject,grade,score:Math.round(score/quizQuestions.length*100),correct:score,total:quizQuestions.length,createdAt:serverTimestamp()});}catch{toast("ظهر التصحيح، لكن تعذر حفظ النتيجة على Firebase.");}}
  }
  function resetQuiz(){setQuizAnswers({});setQuizSubmitted(false);}
  async function savePlan(e){
    e.preventDefault();
    const p={uid:user?.uid||"local",...planForm,minutes:Number(planForm.minutes),completed:false};
    if(user&&db){try{await addDoc(collection(db,"studyPlans"),{...p,createdAt:serverTimestamp()});toast("تم حفظ جلسة المذاكرة.");}catch{toast("تعذر الحفظ على Firebase. سجّل الدخول وتأكد من القواعد.");}}
    else {const local=JSON.parse(localStorage.getItem("tamayoz-plans")||"[]");local.push({...p,id:crypto.randomUUID()});localStorage.setItem("tamayoz-plans",JSON.stringify(local));toast("حُفظ الجدول على هذا الجهاز فقط. سجّل الدخول لمزامنته.");}
    setPlanForm(v=>({...v,task:""}));
  }
  async function togglePlan(p){
    const next=!p.completed;
    if(user&&db){try{const {id,...data}=p;await setDoc(doc(db,"studyPlans",id),{...data,completed:next},{merge:true});}catch{toast("تعذر تحديث الجلسة.");}}
    else {const local=JSON.parse(localStorage.getItem("tamayoz-plans")||"[]").map(x=>x.id===p.id?{...x,completed:next}:x);localStorage.setItem("tamayoz-plans",JSON.stringify(local));}
  }
  async function uploadMaterial(e){
    e.preventDefault();
    if(!isAdmin){toast("رفع الملفات متاح للمشرف فقط.");return;}
    if(!pdfFile){toast("اختر ملف PDF أولًا.");return;}
    if(!storage||!db){toast("إعداد Firebase غير مكتمل.");return;}
    if(pdfFile.type!=="application/pdf"||pdfFile.size>15*1024*1024){toast("يسمح بملفات PDF فقط، بحد أقصى 15 ميجابايت.");return;}
    setUploadBusy(true);
    try {
      const safeName=pdfFile.name.replace(/[^a-zA-Z0-9._-]/g,"_");
      const fileRef=ref(storage,`materials/${Date.now()}-${safeName}`);
      await uploadBytes(fileRef,pdfFile,{contentType:"application/pdf"});
      const url=await getDownloadURL(fileRef);
      await addDoc(collection(db,"materials"),{...adminForm,url,type:"PDF",fileName:pdfFile.name,createdAt:serverTimestamp()});
      setPdfFile(null);setAdminForm({title:"",subject:"",grade:"s2",description:""});toast("تم رفع الملخص وإضافته للمكتبة.");
    }catch(err){toast("فشل الرفع: "+friendlyError(err.code));}
    finally{setUploadBusy(false);}
  }
  async function addDemoMaterial(){
    if(!isAdmin||!db){toast("يلزم حساب مشرف متصل بـ Firebase.");return;}
    if(!adminForm.title.trim()||!adminForm.subject.trim()){toast("اكتب اسم الملخص والمادة.");return;}
    try{await addDoc(collection(db,"materials"),{...adminForm,type:"رابط خارجي",url:"",createdAt:serverTimestamp()});setAdminForm({title:"",subject:"",grade:"s2",description:""});toast("تمت إضافة المادة.");}
    catch{toast("تعذر الإضافة. تحقق من صلاحيات المشرف.");}
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="container nav-inner">
        <button className="brand" onClick={()=>go("home")} aria-label="الرئيسية"><span className="brand-mark"><GraduationCap size={28}/></span><span><b>منصة التميز</b><small>بوابتك للتفوق التعليمي</small></span></button>
        <nav className={`nav-links ${mobileOpen?"open":""}`}>
          {[["home","الرئيسية"],["stages","المراحل الدراسية"],["subjects","المواد والملخصات"],["quiz-section","الاختبارات"],["planner","جدول المذاكرة"]].map(([id,label])=><button key={id} onClick={()=>go(id)} className={activeTab===id?"active":""}>{label}</button>)}
        </nav>
        <div className="nav-actions">
          <label className="searchbox"><Search size={16}/><input value={search} onChange={e=>{setSearch(e.target.value);if(e.target.value)setActiveTab("subjects");}} placeholder="ابحث عن مادة أو صف"/></label>
          <button className="icon-btn" onClick={()=>setDark(v=>!v)} aria-label="تغيير المظهر">{dark?<Sun size={18}/>:<Moon size={18}/>}</button>
          {user?<button className="profile-btn" onClick={()=>go("dashboard")}><UserRound size={17}/><span>{profile?.displayName||user.email?.split("@")[0]||"حسابي"}</span></button>:<button className="btn btn-primary btn-small" onClick={()=>{setAuthMode("login");setModal("auth");}}><LogIn size={16}/> دخول</button>}
          <button className="icon-btn mobile-trigger" onClick={()=>setMobileOpen(v=>!v)} aria-label="القائمة">{mobileOpen?<X size={20}/>:<Menu size={20}/>}</button>
        </div>
      </div>
    </header>

    {!firebaseConfigured&&<div className="setup-banner"><AlertCircle size={18}/><span>وضع التجربة: أضف إعدادات Firebase لتفعيل الحسابات والمزامنة والرفع السحابي. الاختبارات والجدول المحلي يعملان الآن.</span></div>}

    <main>
      <section id="home" className="hero section-anchor">
        <div className="hero-glow glow-one"></div><div className="hero-glow glow-two"></div>
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="eyebrow"><Sparkles size={15}/> تعلّم بذكاء • تقدّم بثقة</span>
            <h1>رحلتك نحو <span>التفوق والأوائل</span><br/>تبدأ من هنا</h1>
            <p>منصة تعليمية منظمة تساعدك على الوصول إلى المواد والملخصات، والتدرب على أسئلة تفاعلية، وبناء جدول مذاكرة يناسب يومك.</p>
            <div className="hero-actions"><button className="btn btn-primary" onClick={()=>go("quiz-section")}><ClipboardCheck size={18}/> اختبر نفسك</button><button className="btn btn-outline" onClick={()=>go("planner")}><CalendarDays size={18}/> أنشئ جدولك</button></div>
            <div className="stats-row"><div><b>14</b><span>اختيارًا للصف</span></div><div><b>6+</b><span>نماذج أسئلة تجريبية</span></div><div><b>24/7</b><span>تعلّم في أي وقت</span></div></div>
          </div>
          <div className="hero-panel">
            <div className="panel-top"><div className="panel-icon"><Trophy size={22}/></div><div><b>مساحتك التعليمية</b><small>اختر صفك وابدأ رحلتك</small></div><span className="live-dot"></span></div>
            <label className="field-label" htmlFor="grade-select">الصف الدراسي</label>
            <select id="grade-select" value={grade} onChange={e=>{setGrade(e.target.value);setQuizAnswers({});setQuizSubmitted(false);}} className="field">
              {grades.map(g=><option value={g.id} key={g.id}>{g.name}</option>)}
            </select>
            <div className="quick-cards"><button onClick={()=>go("subjects")}><span className="quick-icon mint"><FileText/></span><span><b>ملخصات ومواد</b><small>استعرض المحتوى</small></span><ChevronLeft size={17}/></button><button onClick={()=>go("quiz-section")}><span className="quick-icon violet"><ClipboardCheck/></span><span><b>اختبارات قصيرة</b><small>تصحيح فوري</small></span><ChevronLeft size={17}/></button><button onClick={()=>go("planner")}><span className="quick-icon amber"><CalendarDays/></span><span><b>خطة المذاكرة</b><small>نظّم وقتك</small></span><ChevronLeft size={17}/></button></div>
            <p className="panel-note"><ShieldCheck size={15}/> تقدمك يُحفظ في حسابك عند تفعيل Firebase.</p>
          </div>
        </div>
      </section>

      <section id="stages" className="section container section-anchor">
        <div className="section-heading"><div><span className="eyebrow">خطوتك الأولى</span><h2>اختر مرحلتك الدراسية</h2><p>انتقل إلى صفك لتصفية المواد والملخصات المتاحة.</p></div></div>
        <div className="stage-grid">{stages.map((s,i)=><article className={`stage-card stage-${i}`} key={s.title}><div className="stage-emoji">{s.icon}</div><h3>{s.title}</h3><p>{s.desc}</p><div className="grade-chips">{s.items.map(g=><button key={g.id} className={grade===g.id?"selected":""} onClick={()=>{setGrade(g.id);go("subjects");}}>{g.name.replace("الصف ","")}</button>)}</div><button className="text-link" onClick={()=>{setGrade(s.items[0].id);go("subjects");}}>استكشف المرحلة <ChevronLeft size={16}/></button></article>)}</div>
      </section>

      <section id="subjects" className="section section-muted section-anchor"><div className="container">
        <div className="section-heading heading-inline"><div><span className="eyebrow">مكتبة المعرفة</span><h2>المواد والملخصات</h2><p>المعروض هنا محتوى تجريبي حتى تضيف موادك الفعلية.</p></div><div className="filter-wrap"><BookOpen size={17}/><select value={grade} onChange={e=>setGrade(e.target.value)} aria-label="تصفية حسب الصف">{grades.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}</select></div></div>
        {filteredMaterials.length?<div className="material-grid">{filteredMaterials.map((m,i)=><article className="material-card" key={m.id}><div className={`material-art ${subjectColors[i%subjectColors.length]}`}><BookMarked size={30}/><span>{m.type||"ملخص"}</span></div><div className="material-body"><span className="subject-label">{m.subject}</span><h3>{m.title}</h3><p>{m.description||"مادة تعليمية لدعم المراجعة والفهم."}</p><div className="material-footer"><small>{grades.find(g=>g.id===m.grade)?.name||"كل الصفوف"}</small>{m.url?<a className="download-link" href={m.url} target="_blank" rel="noreferrer"><Download size={15}/> فتح الملف</a>:<span className="demo-tag">محتوى تجريبي</span>}</div></div></article>)}</div>:<div className="empty-state"><BookOpen size={30}/><h3>لا توجد مواد مطابقة</h3><p>جرّب تغيير الصف أو كلمة البحث، أو أضف مواد من لوحة المشرف.</p></div>}
      </div></section>

      <section id="quiz-section" className="section container section-anchor">
        <div className="section-heading"><div><span className="eyebrow">تدرّب واكتشف مستواك</span><h2>الاختبارات التفاعلية</h2><p>اختر مادة، أجب عن الأسئلة، ثم اعرف نتيجتك مع شرح الإجابات.</p></div></div>
        <div className="quiz-layout"><aside className="quiz-sidebar"><div className="quiz-side-icon"><ClipboardCheck size={28}/></div><h3>اختبار سريع</h3><p>نماذج قصيرة للتجربة. أضف أسئلتك المعتمدة قبل إتاحتها للطلاب.</p><label className="field-label" htmlFor="quiz-subject">المادة</label><select id="quiz-subject" className="field" value={quizSubject} onChange={e=>{setQuizSubject(e.target.value);resetQuiz();}}>{[...new Set(quizBank.map(q=>q.subject))].map(s=><option key={s}>{s}</option>)}</select><div className="quiz-meta"><span><CircleHelp size={16}/>{quizQuestions.length} أسئلة</span><span><Clock3 size={16}/>قصير</span></div></aside>
          <div className="quiz-main">{quizSubmitted?<div className="result-panel"><div className="score-ring"><b>{Math.round(score/quizQuestions.length*100)}%</b><small>نتيجتك</small></div><h3>{score===quizQuestions.length?"أحسنت! إجابات ممتازة":score>=quizQuestions.length/2?"عمل جيد، واصل التدريب":"لا بأس، راجع الشرح وحاول مرة أخرى"}</h3><p>أجبت إجابة صحيحة عن {score} من {quizQuestions.length}.</p><div className="answer-review">{quizQuestions.map((q,i)=><div className="review-item" key={q.id}><div className="review-title"><span className={quizAnswers[q.id]===q.answer?"correct-mark":"wrong-mark"}>{quizAnswers[q.id]===q.answer?<CheckCircle2 size={18}/>:<AlertCircle size={18}/>}</span><b>{i+1}. {q.q}</b></div><p>الإجابة الصحيحة: <strong>{q.options[q.answer]}</strong></p><small>{q.explanation}</small></div>)}</div><button className="btn btn-primary" onClick={resetQuiz}>أعد الاختبار</button></div>:<><div className="quiz-progress"><span>أسئلة التدريب</span><b>{Object.keys(quizAnswers).length} / {quizQuestions.length}</b></div>{quizQuestions.map((q,i)=><div className="question-card" key={q.id}><h3><span>{String(i+1).padStart(2,"0")}</span>{q.q}</h3><div className="options-list">{q.options.map((op,j)=><button key={j} className={`option ${quizAnswers[q.id]===j?"chosen":""}`} onClick={()=>setQuizAnswers(v=>({...v,[q.id]:j}))}><span className="option-letter">{["أ","ب","ج","د"][j]}</span>{op}{quizAnswers[q.id]===j&&<CheckCircle2 size={17} className="option-check"/>}</button>)}</div></div>)}<div className="quiz-submit-row"><small>تظهر النتيجة والشرح بعد الإرسال.</small><button className="btn btn-primary" onClick={submitQuiz}>تصحيح الاختبار <ChevronLeft size={17}/></button></div></>}</div>
        </div>
      </section>

      <section id="planner" className="section section-muted section-anchor"><div className="container">
        <div className="section-heading"><div><span className="eyebrow">وقتك يستحق التنظيم</span><h2>جدول المذاكرة الذكي</h2><p>قسّم المذاكرة إلى جلسات واقعية، وحدّد وقتًا ومهمة لكل جلسة.</p></div></div>
        <div className="planner-layout"><form className="planner-form" onSubmit={savePlan}><div className="planner-form-head"><span className="quick-icon violet"><CalendarDays/></span><div><h3>أضف جلسة مذاكرة</h3><p>ابدأ بخطوة صغيرة وواضحة.</p></div></div><label className="field-label">المادة</label><select className="field" value={planForm.subject} onChange={e=>setPlanForm(v=>({...v,subject:e.target.value}))}>{[...new Set([...quizBank.map(q=>q.subject),"مراجعة عامة"])].map(s=><option key={s}>{s}</option>)}</select><div className="form-two"><div><label className="field-label">التاريخ</label><input required className="field" type="date" value={planForm.date} onChange={e=>setPlanForm(v=>({...v,date:e.target.value}))}/></div><div><label className="field-label">وقت البداية</label><input required className="field" type="time" value={planForm.start} onChange={e=>setPlanForm(v=>({...v,start:e.target.value}))}/></div></div><label className="field-label">المدة</label><select className="field" value={planForm.minutes} onChange={e=>setPlanForm(v=>({...v,minutes:e.target.value}))}><option value="25">25 دقيقة</option><option value="45">45 دقيقة</option><option value="60">ساعة</option><option value="90">90 دقيقة</option></select><label className="field-label">المهمة</label><textarea required className="field" rows="3" placeholder="مثال: مراجعة درس وحل 10 أسئلة" value={planForm.task} onChange={e=>setPlanForm(v=>({...v,task:e.target.value}))}/><button className="btn btn-primary btn-full" type="submit"><Plus size={18}/> أضف إلى الجدول</button>{!user&&<small className="helper-text">بدون تسجيل دخول، تُحفظ الجلسات محليًا على هذا الجهاز.</small>}</form>
          <div className="planner-list"><div className="planner-list-head"><div><h3>جلساتك القادمة</h3><p>{plans.length} جلسة مسجلة في هذه الجلسة</p></div><span className="calendar-badge"><CalendarDays/></span></div>{(user?plans:JSON.parse(localStorage.getItem("tamayoz-plans")||"[]")).length? (user?plans:JSON.parse(localStorage.getItem("tamayoz-plans")||"[]")).map(p=><div className={`plan-item ${p.completed?"is-done":""}`} key={p.id}><button className="plan-check" onClick={()=>togglePlan(p)} aria-label="تغيير حالة الجلسة">{p.completed?<CheckCircle2/>:<span/>}</button><div className="plan-details"><b>{p.subject}</b><p>{p.task}</p><small><CalendarDays size={13}/>{p.date} <Clock3 size={13}/>{p.start} • {p.minutes} دقيقة</small></div><span className="plan-status">{p.completed?"مكتملة":"مجدولة"}</span></div>):<div className="empty-state compact"><CalendarDays size={28}/><h3>جدولك يبدأ من هنا</h3><p>أضف جلسة مذاكرة لتظهر في هذه القائمة.</p></div>}<div className="planner-tip"><Sparkles size={18}/><p><b>نصيحة:</b> جرّب جلسة من 25 دقيقة ثم خذ استراحة قصيرة، ووزّع المواد على أيام الأسبوع.</p></div></div>
        </div>
      </div></section>

      <section id="dashboard" className="section container section-anchor"><div className="section-heading heading-inline"><div><span className="eyebrow">مساحتك الشخصية</span><h2>لوحة الطالب</h2><p>تابع نتائج الاختبارات وإجمالي تقدمك.</p></div>{user&&<button className="btn btn-outline" onClick={async()=>{await signOut(auth);toast("تم تسجيل الخروج.");}}><LogOut size={16}/> خروج</button>}</div>
        {user?<div className="dashboard-grid"><article className="dash-card"><span className="dash-icon mint"><ClipboardCheck/></span><small>اختبارات مكتملة</small><b>{results.length}</b><p>محاولات محفوظة في حسابك</p></article><article className="dash-card"><span className="dash-icon violet"><ChartNoAxesColumnIncreasing/></span><small>متوسط النتائج</small><b>{average}%</b><p>متوسط نتائج الاختبارات المحفوظة</p></article><article className="dash-card"><span className="dash-icon amber"><CalendarDays/></span><small>جلسات المذاكرة</small><b>{plans.length}</b><p>جلسات مسجلة في جدولك</p></article></div>:<div className="login-callout"><div className="callout-icon"><UserRound size={26}/></div><div><h3>سجّل الدخول لحفظ تقدمك</h3><p>أنشئ حسابًا لتزامن نتائج الاختبارات وجدول المذاكرة عبر أجهزتك عند تفعيل Firebase.</p></div><button className="btn btn-primary" onClick={()=>{setAuthMode("signup");setModal("auth");}}>إنشاء حساب <ChevronLeft size={16}/></button></div>}
      </section>

      {isAdmin&&<section className="section section-muted"><div className="container"><div className="section-heading heading-inline"><div><span className="eyebrow">إدارة المحتوى</span><h2>لوحة المشرف</h2><p>رفع ملفات PDF وإضافة روابط مواد إلى المكتبة.</p></div><span className="admin-badge"><ShieldCheck size={16}/> مشرف</span></div><div className="admin-layout"><form className="planner-form" onSubmit={uploadMaterial}><h3><Upload size={19}/> رفع ملخص PDF</h3><label className="field-label">عنوان الملخص</label><input required className="field" value={adminForm.title} onChange={e=>setAdminForm(v=>({...v,title:e.target.value}))} placeholder="مثال: مراجعة الوحدة الأولى"/><label className="field-label">المادة</label><input required className="field" value={adminForm.subject} onChange={e=>setAdminForm(v=>({...v,subject:e.target.value}))} placeholder="اسم المادة"/><label className="field-label">الصف</label><select className="field" value={adminForm.grade} onChange={e=>setAdminForm(v=>({...v,grade:e.target.value}))}>{grades.map(g=><option value={g.id} key={g.id}>{g.name}</option>)}<option value="all">كل الصفوف</option></select><label className="field-label">وصف مختصر</label><textarea className="field" rows="2" value={adminForm.description} onChange={e=>setAdminForm(v=>({...v,description:e.target.value}))} placeholder="ماذا يتضمن الملف؟"/><label className="file-drop"><Upload size={20}/><b>{pdfFile?.name||"اختر ملف PDF"}</b><small>15 ميجابايت كحد أقصى</small><input type="file" accept="application/pdf,.pdf" onChange={e=>setPdfFile(e.target.files?.[0]||null)}/></label><button disabled={uploadBusy} className="btn btn-primary btn-full">{uploadBusy?<LoaderCircle className="spin"/>:<Upload size={17}/>} رفع وإضافة الملخص</button></form><form className="planner-form" onSubmit={e=>{e.preventDefault();addDemoMaterial();}}><h3><Plus size={19}/> إضافة مادة برابط</h3><p className="helper-text">يمكنك إضافة مادة مع رابط PDF أو رابط تعليمي خارجي من خلال حقل الوصف والرابط في بيانات Firestore. هذا النموذج يضيف سجلًا أوليًا.</p><label className="field-label">عنوان المادة</label><input className="field" value={adminForm.title} onChange={e=>setAdminForm(v=>({...v,title:e.target.value}))} placeholder="عنوان المادة"/><label className="field-label">اسم المادة</label><input className="field" value={adminForm.subject} onChange={e=>setAdminForm(v=>({...v,subject:e.target.value}))} placeholder="المادة"/><label className="field-label">الصف</label><select className="field" value={adminForm.grade} onChange={e=>setAdminForm(v=>({...v,grade:e.target.value}))}>{grades.map(g=><option value={g.id} key={g.id}>{g.name}</option>)}<option value="all">كل الصفوف</option></select><label className="field-label">الوصف</label><textarea className="field" rows="2" value={adminForm.description} onChange={e=>setAdminForm(v=>({...v,description:e.target.value}))}/><button className="btn btn-outline btn-full"><Plus size={17}/> إضافة سجل</button></form></div><div className="admin-warning"><AlertCircle size={17}/> حساب المشرف لا يُمنح من الواجهة؛ يجب تعيين custom claim admin=true من بيئة إدارية موثوقة قبل استخدام صلاحيات الرفع.</div></div></section>}

      <section className="closing-cta"><div className="container closing-inner"><div><span className="eyebrow">كل يوم فرصة جديدة</span><h2>خطوة صغيرة اليوم، إنجاز أكبر غدًا.</h2><p>ابدأ بدرس، اختبر فهمك، واحتفل بتقدمك.</p></div><button className="btn btn-light" onClick={()=>go("planner")}>ابدأ تنظيم وقتك <ChevronLeft size={17}/></button></div></section>
    </main>
    <footer className="footer"><div className="container footer-inner"><button className="brand footer-brand" onClick={()=>go("home")}><span className="brand-mark"><GraduationCap size={23}/></span><span><b>منصة التميز</b><small>التعلّم طريقك للتميز</small></span></button><p>© {new Date().getFullYear()} منصة التميز التعليمية. محتوى الأسئلة والمواد المعروضة تجريبي إلى أن تضيف المحتوى المعتمد.</p><span className="footer-status"><span className={`status-dot ${firebaseConfigured?"online":""}`}></span>{firebaseConfigured?"Firebase مهيأ":"وضع تجريبي"}</span></div></footer>

    {modal==="auth"&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal("");}}><div className="modal-card"><button className="modal-close icon-btn" onClick={()=>setModal("")}><X/></button><div className="modal-symbol"><GraduationCap size={28}/></div><h2>{authMode==="signup"?"أنشئ حسابك":"أهلًا بعودتك"}</h2><p>{authMode==="signup"?"احفظ تقدمك ونظّم مذاكرتك في مكان واحد.":"سجّل الدخول لمتابعة نتائجك وجدولك."}</p><form onSubmit={handleAuth}>{authMode==="signup"&&<><label className="field-label">الاسم</label><input name="name" required className="field" placeholder="اسم الطالب"/><label className="field-label">الصف الدراسي</label><select name="grade" className="field" defaultValue={grade}>{grades.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}</select></>}<label className="field-label">البريد الإلكتروني</label><input name="email" type="email" required className="field" placeholder="name@example.com" autoComplete="email"/><label className="field-label">كلمة المرور (6 أحرف على الأقل)</label><input name="password" type="password" required minLength="6" className="field" placeholder="••••••••" autoComplete={authMode==="signup"?"new-password":"current-password"}/><button disabled={authBusy} className="btn btn-primary btn-full">{authBusy?<LoaderCircle className="spin"/>:authMode==="signup"?"إنشاء حساب":"تسجيل الدخول"}</button></form><p className="auth-switch">{authMode==="signup"?"لديك حساب بالفعل؟":"ليس لديك حساب؟"} <button onClick={()=>setAuthMode(authMode==="signup"?"login":"signup")}>{authMode==="signup"?"تسجيل الدخول":"إنشاء حساب"}</button></p>{!firebaseConfigured&&<div className="inline-warning">تسجيل الدخول يحتاج إعداد Firebase أولًا.</div>}</div></div>}
    {notice&&<div className="toast"><CheckCircle2 size={18}/>{notice}</div>}
  </div>;
}
function friendlyError(code=""){const map={"auth/email-already-in-use":"هذا البريد مسجل بالفعل.","auth/invalid-email":"صيغة البريد الإلكتروني غير صحيحة.","auth/weak-password":"اختر كلمة مرور أقوى من 6 أحرف.","auth/invalid-credential":"البريد أو كلمة المرور غير صحيحة.","auth/network-request-failed":"تحقق من اتصال الإنترنت.","permission-denied":"ليس لديك صلاحية لتنفيذ هذه العملية."};return map[code]||"تعذر إكمال العملية. تحقق من الإعدادات وحاول مجددًا.";}
createRoot(document.getElementById("root")).render(<App/>);
