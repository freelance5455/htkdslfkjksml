/* =====================================================
   story_ch08.js —— 第八章「龙脊」（龙族的沉睡、祖母烬眠、火之碎片）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch07_end 之后（ch07 以 fadeOut 结尾，本章以 fadeIn 开场）。
   依赖：第七章的 samuel 角色，以及 flag：method / cutknown / samuel / bl_ember。
   本章以 fadeOut 黑屏结尾，第九章（山之低语）以 fadeIn 开场。
   ===================================================== */
window.STORY_CH08 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {
      grandma: { name: "烬眠", title: "沉睡的龙", color: "#d8805a" }
    },
    addBackgrounds: {
      ridge_foot: { src: "assets/bg/ridge_foot.jpg",
                    color: "linear-gradient(180deg,#5a6a7a 0%,#a8b4a0 55%,#7a8a5a 100%)" },
      ice_stair:  { src: "assets/bg/ice_stair.jpg",
                    color: "linear-gradient(180deg,#0a1018 0%,#2a3a50 55%,#8a9ab0 100%)" },
      ridge_gate: { src: "assets/bg/ridge_gate.jpg",
                    color: "linear-gradient(180deg,#1a1410 0%,#5a3a24 55%,#c87a3a 100%)" },
      dragon_hall: { src: "assets/bg/dragon_hall.jpg",
                    color: "linear-gradient(180deg,#0e0a08 0%,#3a2418 55%,#a0642a 100%)" },
      inner_room: { src: "assets/bg/inner_room.jpg",
                    color: "linear-gradient(180deg,#050303 0%,#2a1008 55%,#e0803a 100%)" },
      ridge_top:  { src: "assets/bg/ridge_top.jpg",
                    color: "linear-gradient(180deg,#2a3a5a 0%,#c89a78 60%,#e8d0b0 100%)" }
    },
    addCgs: {
      cg_dragon_flight:   { src: "assets/cg/dragon_flight.jpg",
                            color: "linear-gradient(180deg,#8ab0d8 0%,#e8f0f8 50%,#6a7a98 100%)" },
      cg_sleeping_dragon: { src: "assets/cg/sleeping_dragon.jpg",
                            color: "linear-gradient(180deg,#0a0504 0%,#4a1a0a 50%,#f0a050 100%)" }
    },
    addAudio: {
      bgm: { ch08_ridge: "assets/audio/ch08_ridge.mp3", ch08_stair: "assets/audio/ch08_stair.mp3",
             ch08_flight: "assets/audio/ch08_flight.mp3", ch08_hall: "assets/audio/ch08_hall.mp3",
             ch08_dream: "assets/audio/ch08_dream.mp3", ch08_shard: "assets/audio/ch08_shard.mp3" },
      sfx: { wing: "assets/audio/wing.mp3", ember: "assets/audio/ember.mp3" }
    },

    /* flag（本章新增）：
       climb:  "fly" / "walk"                 —— 白泷载人飞上去 / 走古道
       grandma: "woke" / "watch" / "sang"     —— 对沉睡的祖母：唤醒 / 守夜 / 请溟月唱歌
       shard:  "taken" / "left" / "claude"    —— 火之碎片：白泷带走 / 留下 / 克劳德接下（仅 grandma=woke 时出现）
       bl_ember: true                         —— 白泷体内留着一点火（hoard 线，或 shard=taken）
       claude_ember: true                     —— 克劳德接下了火（shard=claude）
    */

    script: [

      { label: "ch08_start" },
      { chapter: { no: "CHAPTER 08", title: "龙　脊", sub: "THE DRAGON'S SPINE · 沉睡的山" } },

      /* ---------- 一、山脚 ---------- */
      { hide: "all", cgHide: true, bg: "ridge_foot", transition: "black", bgm: "ch08_ridge", effect: "fadeIn",
        text: "北岸没有村庄，也没有路。只有一片缓缓抬升的荒坡，和一座沉默得像在屏息的山。" },
      { show: LINE, who: "mingyue", expr: MY("surprised"),
        text: "……奇怪。雪，怎么越来越薄了？" },
      { text: "她说得没错。河边的雪，还厚得能没过脚踝。可是越往上走，积雪就越稀，最后薄得像一层撒在石头上的盐。" },
      { text: "再往上，竟然，露出了青草。草尖上，挂着晨露，在冬天的前夜里，绿得，近乎不合时宜。" },
      { who: "mingyue", expr: MY("happy"), text: "暖和！终于暖和了！这座山，是不是，对我有意思？" },
      { who: "claude", text: "我倒觉得，是山里有什么东西，在慢慢地，漏热。" },
      { text: "她抬头，望向山顶那一线细细的白色光柱。光柱的底部，隐隐透着橙红，像一块被反复烘烤、始终不肯冷下去的炭。" },
      { who: "bailong", text: "……" },
      { text: "白泷一路上，一句话也没有说。她走得很慢，像一个在期末前夜，不敢回家的孩子。" },
      { who: "claude", text: "你在怕。" },
      { who: "bailong", text: "……嗯。" },
      { who: "claude", text: "怕什么？" },
      { who: "bailong", text: "怕她们，生气。……也怕她们，不生气。" },
      { text: "克劳德没有回答。她只是，把自己的手，伸过去，很轻地，扣住了白泷的袖口。像一个人，在雾里，牵住另一个人。" },

      /* ---------- 二、上山：抉择 ---------- */
      { text: "山路，在这里，彻底断了。前方是一道几乎垂直的断崖，崖壁上，有一条依稀可辨的、被冰封住的古道。",
        choices: [
          { text: "请白泷现出龙身，载大家飞上去", jump: "ch08_fly",  set: { climb: "fly" } },
          { text: "走古道，一步一步爬上去",         jump: "ch08_walk", set: { climb: "walk" } }
        ] },

      /* ----- 飞 ----- */
      { label: "ch08_fly" },
      { who: "bailong", text: "……变回去，会很大。像把，一整座房子，塞进杯子里，再倒出来。" },
      { who: "mingyue", expr: MY("surprised"), text: "你上次，是怎么把自己，塞进去的？！" },
      { who: "bailong", text: "……用力。" },
      { text: "白泷向后退了几步，闭上眼睛。她的白发，无风自动，一寸一寸地，向上扬起。" },
      { sfx: "wing", hide: "all", text: "空气，忽然变重了。像整座山，在屏住的呼吸里，被人轻轻地，推了一下。" },
      { cg: "cg_dragon_flight", bgm: "ch08_flight",
        text: "那是一条白色的龙。比任何一座教堂的穹顶，都要高；比任何一面旗帜，都要白。鳞片在晨光里，像一场缓慢下落的、静止的雪。" },
      { text: "它低下头。金色的竖瞳，在晨光里，温柔得，几乎有些不合比例。" },
      { speaker: "白龙", text: "上来。抓紧，鳞。" },
      { text: "声音，像远处的雷，隔着几重云层，传下来。却依旧，是白泷那种，短短的，笨拙的语气。" },
      { text: "克劳德爬上龙背的时候，才意识到，自己的双脚，已经很久，没有离开过大地。" },
      { text: "圣女的鞋底，从来只踩过大理石。那些光滑的、冰冷的、被无数人跪过的石板。而此刻，她脚下的是风。" },
      { speaker: "溟月", text: "啊啊啊啊啊——————！！！" },
      { speaker: "溟月", text: "……啊啊啊啊！……诶，好像，还不错？哈哈哈哈！" },
      { text: "山，在她们脚下，缓缓地，展开了自己的脊梁。每一道山脊，每一道雪线，每一片沉默的岩石，都在清晨的光里，被镀成了一种近似于金的颜色。" },
      { text: "克劳德把手，按在龙的鳞上。鳞片是温热的，微微起伏，像一座在呼吸的小山。" },
      { speaker: "克劳德", text: "……白泷。你一直，是这样，看世界的吗？" },
      { speaker: "白龙", text: "嗯。比较，高。……但是，没有金子，好看。" },
      { speaker: "克劳德", text: "……我会，把这句话，当作，一句玩笑。" },
      { sfx: "wing", text: "云被撕开了一道口子。山腰上，一座巨大的、像张开的嘴一样的洞口，出现在她们的眼前。" },
      { jump: "ch08_gate" },

      /* ----- 走 ----- */
      { label: "ch08_walk" },
      { hide: "all", bg: "ice_stair", transition: "fade", bgm: "ch08_stair",
        text: "古道，是在悬崖上，一级一级凿出来的。" },
      { show: LINE, text: "石阶很窄，窄得只容一人通过。每一级石阶的边缘，都被无数脚步，磨得圆润光滑，像一枚枚被摩挲了很多年的旧硬币。" },
      { who: "mingyue", expr: MY("worried"), text: "……不要往下看。不要往下看。我，是鲸，不是山羊。" },
      { who: "claude", text: "那你，往上看。" },
      { who: "mingyue", text: "往上看，更可怕！" },
      { text: "天黑的时候，她们在一块突出的岩台上扎了营。岩台背后的石壁上，刻满了东西。" },
      { text: "克劳德举起火把。火光爬上石壁，一幅一幅的浮雕，缓缓地，从黑暗里，浮了出来。" },
      { text: "最中间，是那个熟悉的圆。被一道一道刻痕切成许多片。而在圆的两边，跪着两列影子。一边是人，一边，是龙。" },
      { text: "他们的手，都伸向圆中央，托着同样的东西。像是，在一起，捧着一只，快要碎的杯子。" },
      { who: "claude", text: "……龙族，也在壁画里。" },
      { who: "bailong", text: "嗯。我们，是，守的。" },
      { who: "claude", text: "守什么？" },
      { who: "bailong", text: "……掉下来的东西。" },
      { text: "白泷靠着石壁坐下，把手，慢慢伸进了怀里，摸出了那枚红线贝壳。她把它，放在火光下，看了很久。" },
      { who: "bailong", text: "人们，都说，龙，贪。喜欢亮的，喜欢金的，喜欢，别人的东西。" },
      { who: "bailong", text: "奶奶说，不是的。我们，不是，爱。我们，是，替别人，收着。" },
      { who: "bailong", text: "收的，是，掉下来的。因为，掉下来的，都有，主人。主人，总会，回来找。" },
      { who: "mingyue", expr: MY("normal"), text: "……所以，你偷我的发簪，是在，替我，收着？" },
      { who: "bailong", text: "……是。" },
      { who: "mingyue", text: "那你什么时候，还我！" },
      { who: "bailong", text: "……等你，回来找。" },
      { who: "mingyue", expr: MY("surprised"), text: "我现在，就站在这里！" },
      { who: "bailong", text: "……好。（慢慢地，从怀里，摸出了一根发簪）" },
      { text: "火光很暖。克劳德看着她们，有那么一瞬间，觉得，自己，也是什么人，路过时，掉下来的东西。被很多双手，笨拙地，收着。" },
      { text: "天亮的时候，古道的尽头，出现了。" },
      { jump: "ch08_gate" },

      /* ---------- 三、龙巢 ---------- */
      { label: "ch08_gate" },
      { hide: "all", cgHide: true, bg: "ridge_gate", transition: "black", bgm: "ch08_hall",
        text: "洞口，像一张半张的嘴。" },
      { show: LINE, text: "热风从里面，缓缓地，吹出来。不是火的热，是一种，很久没有被打开的屋子里，有人在睡觉的，那种温热。" },
      { who: "bailong", text: "……我，回来了。" },
      { text: "她对着洞口，用一种几乎听不见的声音，说了这么一句。没有回答。只有风。" },
      { hide: "all", bg: "dragon_hall", transition: "cut",
        text: "洞里面，是一座，大得，没有尽头的厅。" },
      { show: LINE, text: "穹顶极高，隐没在昏暗里。厅的四壁，一圈又一圈，盘着一座座沉默的、巨大的影子。克劳德一开始，以为那是山岩。" },
      { text: "直到她看见，其中一座，在极缓极缓地，起伏。一次呼吸，要用上，一整支烛火燃尽的时间。" },
      { who: "mingyue", expr: MY("surprised"), text: "……这些，全是，龙？" },
      { who: "bailong", text: "嗯。二叔。三姑。小黑。（停了一下）小黑，还是，爱流口水。" },
      { text: "她一个一个，认了过去。每认一个，就停一下。像一个人，在一间，被时间搁置了的屋子里，轻轻地，点名。" },
      { text: "满厅的地上，堆着东西。不是金子，至少，不全是。" },
      { text: "碎了一半的镜子。熄灭的灯盏。孩子的木剑。生了锈的婚戒。断了线的风筝。一只绣着名字的靴子……" },
      { text: "它们被一层，一层，整整齐齐地，码放在龙的脚边，像一座座，没有墓碑的小小的坟。" },
      { who: "claude", text: "……这些，都是，别人的东西。" },
      { who: "bailong", text: "是。掉下来的。奶奶说，总有一天，会有人，来认。" },
      { who: "mingyue", expr: MY("worried"), text: "那……她们，为什么，都在睡？" },
      { text: "白泷站住了。她站在一条巨大的、青灰色的龙尾旁边，仰着头，看着这座厅里，每一个沉睡的影子。" },
      { who: "bailong", text: "我走的，那天，她们，还醒着。" },
      { who: "bailong", text: "……所以，是，我走了以后，才，睡的。" },
      { text: "她的声音，一点一点，低了下去，像一支渐渐燃尽的蜡烛。" },
      { who: "bailong", text: "光，开始醒的时候，她们，就用，睡着，哄它。一个，睡了，就带着，下一个，睡。" },
      { who: "bailong", text: "只有我，不在。我，在外面，玩。在偷，金子。在，吃，糕点。" },
      { who: "bailong", text: "她们，一直，在撑。……我，一直，不知道。" },
      { who: "claude", expr: CL("worried"), text: "……白泷。" },
      { who: "bailong", text: "（摇头）我，没事。" },
      { text: "这是她们认识白泷以来，第一次，听见她说「没事」。克劳德很清楚，那是，最不该被相信的一句话。" },
      { who: "claude", text: "你，不是，一个人，在外面玩。" },
      { who: "claude", text: "你是，替她们，出去，看了一圈。看看，这个世界，值不值得，被守着。" },
      { who: "bailong", text: "……（抬头）值得吗？" },
      { who: "claude", text: "有人，在集市上，会因为一枚金币，吵架。也有人，在海边，替别人的孩子，缝了一件，百家的衣裳。" },
      { who: "claude", expr: CL("smile"), text: "我觉得，值得。" },
      { text: "白泷看了她很久。然后，很慢，很慢地，把一只手，放进了，克劳德的掌心里。" },

      /* ---------- 四、最深的那间屋子 ---------- */
      { hide: "all", bg: "inner_room", transition: "black", bgm: "ch08_dream", show: LINE,
        text: "最深处的那间屋子，在大厅尽头，一道低矮的石门之后。" },
      { text: "门是虚掩着的。从缝里，漏出一线，橙红色的光。像一颗，在黑夜里，不肯熄灭的、很大很大的心脏。" },
      { cg: "cg_sleeping_dragon",
        text: "那是一条，比大厅里任何一条，都要大的龙。" },
      { text: "她蜷在屋子正中，身躯环绕着，像一座用熔岩冷却成的小山。鳞片的颜色，是暗红、是灰、是一种，很多很多年以前的炭。" },
      { text: "她很瘦。肋骨的轮廓，在鳞片下，隐隐可见。她的头，枕在自己的前爪上，爪心里，托着一片，掌心大小的光。" },
      { text: "那光，一刻不停地变换着颜色。赤，金，白，又回到赤。像一枚被剖开的太阳。像一颗，很用力，才没有哭出来的，眼泪。" },
      { text: "龙的脊背上，有一道细细的、裂开的纹路。光，正从那里，丝丝缕缕地，向上漏。穿过石顶上的缝隙，一直升到，天上去。" },
      { who: "mingyue", expr: MY("surprised"), text: "……北边的光，是从这里，漏出去的。" },
      { who: "claude", text: "她在，撑着它。" },
      { text: "白泷一步一步，走到了那只前爪的旁边。她没有哭，也没有笑，只是仰着头，用一种很轻很轻的声音，说：" },
      { who: "bailong", text: "奶奶。我回来了。我，带了，朋友。" },
      { text: "很久，没有回答。屋里只有，那一团光，极缓极缓的、像心跳一样的，明灭。" },
      { speaker: "烬眠", text: "……是，小白么。" },
      { text: "声音，不是从龙的口中发出的。它像是，从整座山的，深处，一点一点，浮上来的。像梦里的人，用一种，很远很远的语气，在说话。" },
      { speaker: "烬眠", text: "……你的身上，有，海的味道。……还有，人的。……还有，别人的，火。" },
      { if: { bl_ember: true },
        who: "bailong", text: "……在霜渡，我，收了，一个孩子的。她，在哭。" },
      { if: { bl_ember: true },
        speaker: "烬眠", text: "……嗯。……是个，好孩子。……不抢，睡着的。……也不，放着，哭的。" },
      { speaker: "烬眠", text: "……别碰它。……它，快醒了。……我，快，撑不住了。" },
      { who: "bailong", text: "……（把拳头，攥得很紧）" },

      { text: "龙的呼吸，一次比一次，更轻。克劳德知道，她们，必须，做点什么。",
        choices: [
          { text: "让白泷，把祖母叫醒",            jump: "ch08_woke",  set: { grandma: "woke" } },
          { text: "不叫醒她。留下来，守夜",        jump: "ch08_watch", set: { grandma: "watch" } },
          { text: "请溟月，对着祖母，唱那半首歌",  jump: "ch08_sang",  set: { grandma: "sang" } }
        ] },

      /* ----- 叫醒 ----- */
      { label: "ch08_woke" },
      { who: "bailong", text: "奶奶。……奶奶！醒一醒！" },
      { text: "她第一次，用这么大的声音，说话。声音在石屋里，撞来撞去，把顶上的细碎的灰，震得簌簌地落。" },
      { sfx: "ember", text: "龙的眼睑，抖了一下。然后，极慢极慢地，睁开了。一轮金红色的月，在她们面前，缓缓亮起。" },
      { speaker: "烬眠", text: "……小白。你，吵。" },
      { who: "bailong", text: "对不起。……但是，你，要醒一下。" },
      { speaker: "烬眠", text: "……我知道。……我，只有，一小会儿，是清楚的。我，说，快一点。" },
      { text: "那个声音，一下子，变得，很稳。像把一个，一直在水底的人，突然，拉出了水面。" },
      { speaker: "烬眠", text: "我们，是替『圆』，守碎片的。一万年前，圆被分开，火的那一块，落在了，我们的山里。" },
      { speaker: "烬眠", text: "祂，不想醒。……是我们，用沉睡，哄着祂。一代，一代。" },
      { speaker: "烬眠", text: "可是，我的睡意，快要，用完了。……它，要交给，一个，握得住的人。" },
      { text: "金红色的眼睛，慢慢地，转了过来。落在克劳德身上，停留了，很久。" },
      { speaker: "烬眠", text: "……你的血里，有一点，第五块的味道。" },
      { who: "claude", expr: CL("surprised"), text: "……第五块。" },
      { speaker: "烬眠", text: "那一块，最小。最轻。也最，难守。……你，自己，大概，还不知道。" },
      { who: "claude", text: "……您说的，是什么意思？" },
      { speaker: "烬眠", text: "给小白，也好。给你，也好。……只是，不要，让它，落进，姓教会的手里。" },
      { speaker: "烬眠", text: "……那些人，会把它，剪断。……会把，一团，会哭的火，剪成，一盏，不会哭的灯。" },
      { who: "bailong", text: "……奶奶。" },
      { speaker: "烬眠", text: "我，要睡了。……这一次，睡得，深一点。……小白。别哭。龙，不哭。" },
      { who: "bailong", text: "……我，没哭。（声音，抖得，不像话）" },
      { speaker: "烬眠", text: "……乖。" },
      { text: "那一轮金红色的月，缓缓地，合上了。石屋里，只剩下那一团光，和一个，一直没有放开手的少女。" },
      { jump: "ch08_shard" },

      /* ----- 守夜 ----- */
      { label: "ch08_watch" },
      { who: "claude", text: "不叫醒她。……我们，陪着她。" },
      { who: "bailong", text: "……陪着？" },
      { who: "claude", text: "她撑了这么久。我们，至少，可以，让她知道，她不是一个人。" },
      { text: "她们在龙的身旁，坐了下来。没有人说话。屋子里的光，缓缓地，明，缓缓地，暗。像一个，巨大的、很慢的呼吸。" },
      { who: "mingyue", expr: MY("normal"), text: "……我，靠一下。就一下。" },
      { text: "溟月说完这句，就倚着白泷的肩膀，睡着了。白泷一动不动，像怕，惊走了，一只，落在肩上的蝶。" },
      { text: "克劳德没有睡。她看着那团光。看着看着，光，忽然，向她，涌了过来。" },
      { bgm: "ch08_dream", text: "……她看见了。一圈，又一圈，跪着的人。" },
      { text: "他们围成一个很大的圆，圆中央，是一轮同样很大的、微微颤抖的光。有人在说话，声音，一层叠着一层，听不清是谁。" },
      { speaker: "声音", text: "……分吧。" },
      { speaker: "声音", text: "……是你们，逼的。" },
      { speaker: "声音", text: "……我们，没有逼。" },
      { speaker: "声音", text: "……那，是谁？" },
      { text: "没有人回答。光，在颤抖。一圈一圈的人，把头，埋得更低了。" },
      { text: "最后，一个看不清面目的、很小的人影，从圈里，走了出来。他把最后一块光，轻轻地，放进了，自己的胸口。" },
      { text: "然后，一切都，熄灭了。克劳德猛地，睁开眼。" },
      { who: "claude", expr: CL("worried"), text: "……（呼吸，很急）" },
      { who: "bailong", text: "……你，看见了？" },
      { who: "claude", text: "……看见了一点。不是，答案。只是，一个，更大的问题。" },
      { who: "bailong", text: "……我，也，看过。小时候。……奶奶，说，别问。" },
      { who: "claude", text: "……为什么？" },
      { who: "bailong", text: "她说，答案，会，伤人。" },
      { jump: "ch08_shard" },

      /* ----- 歌 ----- */
      { label: "ch08_sang" },
      { who: "mingyue", expr: MY("worried"), text: "……对着龙，唱？我，唱不好的。" },
      { who: "claude", text: "你不需要，唱好。你只需要，唱出来。" },
      { text: "溟月深吸了一口气。她走到龙的头旁边，蹲下来，闭上眼，对着那片，沉睡的，温热的鳞，轻轻地，哼出了第一句。" },
      { text: "那个声音，像一条，很长很长的、在水里游了很远的路的鱼。它游进了石屋，游进了龙的鳞缝，游进了，那团光的最深处。" },
      { who: "mingyue", expr: MY("surprised"), text: "……！" },
      { text: "她忽然，停住了。眼睛，睁得很大。像一个人，走到门口，才发现，门后，还有一间屋子。" },
      { who: "mingyue", text: "……第二句。我，知道，第二句了。" },
      { text: "她唱了出来。很轻，很轻，每一个音，都带着，不太确定的颤。" },
      { speaker: "溟月", text: "……你是，谁家的孩子。……你是，所有人，家的孩子。" },
      { sfx: "ember", text: "那团光，亮了一下。不是被惊动的亮，而是，被人叫了名字之后，回应的那一种。" },
      { speaker: "烬眠", text: "……鲸的，孩子。……这么多年了。……你，长这么大了。" },
      { who: "mingyue", expr: MY("surprised"), text: "……您，认识，我？" },
      { speaker: "烬眠", text: "……不认识。……认识，你母亲的，母亲的，母亲。……海与火，从前，是邻居。" },
      { text: "龙的呼吸，忽然稳了一些。那一团光的明灭，也变得，不那么焦躁。像一个，一直不肯睡的孩子，终于，靠在了谁的肩上。" },
      { text: "石屋顶上，那道细细的裂缝里，有一线光，向南方，远远地，射了出去。一条赤金色的、极细的线，穿过夜，穿过千山万水。" },
      { text: "而在很远很远的南方，另一条，蓝色的线，亮了起来。两条线，在大陆的上空，轻轻地，碰了一下。像握手。" },
      { who: "mingyue", expr: MY("shy"), text: "……我，是不是，闯祸了？" },
      { who: "claude", text: "不。我觉得，你是，把一封，等了很久的信，送到了。" },
      { jump: "ch08_shard" },

      /* ---------- 五、碎片 ---------- */
      { label: "ch08_shard" },
      { bgm: "ch08_shard", text: "屋子，忽然，轻轻地，震了一下。" },
      { text: "龙的前爪，松开了一寸。那片掌心大小的光，从爪心里，缓缓地，滑了出来，悬在半空，微微地，颤抖。" },
      { who: "bailong", text: "……要，掉了。" },
      { text: "石屋顶上的细灰，簌簌地落下。龙的鳞缝里，漏出来的光，一下子，亮了好几倍。热浪，从她们身边，一波一波地推过去。" },
      { who: "mingyue", expr: MY("worried"), text: "不拿住的话，会怎么样？！" },
      { who: "claude", text: "……山，会烧起来。" },
      { text: "白泷站在那片光的面前。她的手，已经，抬到了一半。又停住了。" },
      { who: "bailong", text: "……龙，不抢，睡着的东西。" },
      { who: "bailong", text: "它，是，睡着的。……可是，它，也在，哭。" },
      { who: "bailong", text: "……克劳德。我，不知道，怎么办。" },
      { text: "所有人的目光，都落在克劳德身上。她看着那片光，也看着那个，攥着拳头、嘴唇咬出了白印的少女。",
        choices: [
          { text: "对她说：「带上它。我们和你一起扛。」",   jump: "ch08_taken", set: { shard: "taken" } },
          { text: "对她说：「别碰。我们另想别的办法。」",   jump: "ch08_left",  set: { shard: "left" } },
          { text: "「让我来。」克劳德向那团光伸出手",       jump: "ch08_claude", set: { shard: "claude" }, if: { grandma: "woke" } },
          { text: "什么也不说。等白泷，自己决定",           jump: "ch08_self" }
        ] },

      { label: "ch08_self" },
      { text: "克劳德没有说话。她只是，站在白泷的旁边，站得很近，让她，知道，自己，在这里。" },
      { text: "很久，很久。白泷，终于，深深地，吸了一口气。" },
      { if: { bl_ember: true }, jump: "ch08_taken" },
      { jump: "ch08_left" },

      /* ----- 带走 ----- */
      { label: "ch08_taken" },
      { set: { shard: "taken", bl_ember: true }, who: "bailong", text: "……我，拿。" },
      { text: "她伸出双手，把那片光，轻轻地，捧在掌心里。像捧着一只，很小的、会发抖的鸟。" },
      { sfx: "ember", text: "光，一点一点地，沉了下去。从她的掌心，顺着手腕，顺着脉搏，缓缓地，沉进了胸口。像把一盏灯，放进一只，一直在等灯的灯笼里。" },
      { text: "她的白发，一缕一缕地，染上了赤金色。眼瞳，缩成了细细的竖线，在昏暗里，像两枚，很小的、很稳的太阳。" },
      { who: "bailong", text: "……烫。" },
      { who: "claude", expr: CL("worried"), text: "能，忍吗？" },
      { who: "bailong", text: "能。……奶奶，扛了，一万年。我，扛，一会儿，而已。" },
      { text: "屋子里的光，终于，不再向上漏了。那一根，通向天际的白色的柱子，从顶上的缝隙里，一点一点地，细了下去。" },
      { text: "然后，整座大厅里，所有的龙，几乎，同时，轻轻地，吐出了一口气。像整座山，终于，可以，翻一个身。" },
      { who: "bailong", text: "……她们，可以，睡得，轻一点了。" },
      { text: "白泷哭了。一滴，两滴，没有声音。滴在地上，竟然，发出了，很轻的、金属一样的响。" },
      { jump: "ch08_after_shard" },

      /* ----- 留下 ----- */
      { label: "ch08_left" },
      { set: { shard: "left" }, who: "bailong", text: "……不拿。" },
      { text: "她把手，慢慢地，放了下来。像是，把一件，特别想要的东西，亲手，放回了架子上。" },
      { who: "bailong", text: "龙，不抢，睡着的东西。……我，不能，因为它在哭，就，把它，当成是我的。" },
      { who: "mingyue", expr: MY("surprised"), text: "那……山，会烧起来的！" },
      { who: "bailong", text: "……我，把它，放回去。" },
      { text: "她走上去，用两只手，托着那片光，轻轻地，放回了，祖母的爪心。然后，把那根，已经松开的爪，一点一点地，重新合拢。" },
      { if: { grandma: "woke" }, speaker: "烬眠", text: "……也好。……你，自己，选的。" },
      { sfx: "ember", text: "龙的鳞，震了一下。那团光，又被重新，压了回去。不再亮得，那么焦躁，却也，没有，暗下去。" },
      { who: "bailong", text: "……我，会，留下来，陪奶奶。三天。" },
      { who: "claude", text: "好。" },
      { text: "山顶上，那根白色的光柱，仍然，没有熄灭。它还会，在夜里，继续，招来远处的人，也招来，远处的病。" },
      { text: "这是，选择，不动它的，代价。克劳德没有说出口，只是，把这件事，默默地，记了下来。" },
      { jump: "ch08_after_shard" },

      /* ----- 克劳德接下 ----- */
      { label: "ch08_claude" },
      { set: { shard: "claude", claude_ember: true }, who: "claude", text: "……让我来。" },
      { who: "bailong", text: "……克劳德？" },
      { who: "claude", text: "她说，我的血里，有第五块的味道。……那么，我，大概，握得住。" },
      { who: "mingyue", expr: MY("angry"), text: "什么叫，大概！你是想，把自己烧成灰吗！" },
      { who: "claude", text: "……我不知道。但是，我想，试一次。" },
      { text: "她伸出右手。指尖碰到那团光的一瞬间，整条手臂，像被扔进了熔炉。" },
      { sfx: "ember", text: "那不是疼。那是，被另一个人的记忆，一下子，灌满了身体。一万年的炉火，一万年的沉睡，一万年里，一个个被哄睡了的名字。" },
      { who: "claude", expr: CL("worried"), text: "……呃。" },
      { text: "光，沉了下去。它没有像在白泷的手里那样，温顺。而是像一头，认了主人的野兽，在她的胸口里，来回，踱了几圈，才，勉强，卧下。" },
      { if: { touched: true },
        text: "她右手背上，那枚来自海底的旧印记，忽然亮了起来。两种温度，在同一寸皮肤下，碰了一下。" },
      { who: "bailong", text: "……克劳德，你的，眼睛，在，发红。" },
      { who: "claude", text: "……没事。……暂时，没事。" },
      { who: "mingyue", expr: MY("worried"), text: "你每次说『没事』，我都想，揍你。" },
      { text: "屋顶那根白色的光柱，缓缓地，细了下去。大厅里，沉睡的龙，一条一条，吐出了很长很长的一口气。" },
      { jump: "ch08_after_shard" },

      /* ---------- 六、山顶 ---------- */
      { label: "ch08_after_shard" },
      { hide: "all", cgHide: true, bg: "ridge_top", transition: "black", bgm: "ch08_ridge",
        text: "天亮的时候，她们爬上了，龙脊的最高处。" },
      { show: LINE, text: "整个北境，在她们脚下，缓缓地，铺展开去。远处的河，像一条灰色的线。更远的地方，是雪，是云，是看不清边际的、沉默的大地。" },
      { if: { shard: "taken" },
        text: "山顶的那根光柱，已经，几乎，看不见了。只剩一道，极淡极淡的痕，像一杯，喝干了的茶，杯壁上留下的颜色。" },
      { if: { shard: "left" },
        text: "山顶的那根光柱，仍然，亮着。像一盏，没有人能关掉的灯。远远的山下，已经能看见，一队队的灯火，向这里，聚拢。" },
      { if: { shard: "claude" },
        text: "山顶的光柱，淡成了一道，几乎看不见的痕。克劳德的右手，一直，藏在袖子里。袖口下面，隐隐有一点，暖红色，一明，一灭。" },

      { if: { samuel: "ignored" },
        text: "山下的河岸上，有一队灰色的骑士，正在渡河。旗帜上的日轮，缺着一道光。他们没有试图，上山。他们，只是，在看。" },
      { if: { samuel: "ignored" },
        who: "bailong", text: "进不来。……奶奶的火，会，烧。" },
      { if: { samuel: "ignored" },
        who: "claude", text: "但他们，已经，知道了，我们，在哪里。" },
      { if: { samuel: "alone" },
        text: "山下的河岸上，有一盏很小的灯，亮了一下，又熄了。像有人，在远处，确认了什么，然后，转身离开。" },
      { if: { samuel: "alone" },
        who: "claude", text: "……他在，等冬至。" },
      { if: { samuel: "together" },
        text: "山下的河岸上，有一盏很小的灯，亮了一下，又熄了。像有人，在远处，确认了什么，然后，转身离开。" },
      { if: { samuel: "together" },
        who: "mingyue", text: "……那个，喝茶的人。他，说话算话吗？" },
      { if: { samuel: "together" },
        who: "claude", text: "他说，等到冬至。我想，他会。" },

      { who: "mingyue", expr: MY("surprised"), text: "……你们看，那边！" },
      { text: "她指向东南方。很远很远的地方，一片灰黑色的山脉，在晨雾的尽头，隐隐地，亮了一下。不是火的红，也不是海的蓝。是一种，沉沉的、像大地本身在咳嗽的，黄褐色。" },
      { who: "claude", expr: CL("surprised"), text: "……山。" },
      { who: "claude", text: "『一块沉海，一块上山。』……山，也在醒了。" },
      { who: "bailong", text: "……下一个，是，它。" },
      { if: { shard: "taken" },
        text: "白泷把手，按在胸口。那里面，有一团，温热的、很小的东西，在轻轻地，跳。" },
      { if: { shard: "left" },
        text: "白泷回头，望了一眼，那道通向山腹的、低矮的石门。很久，才收回目光。" },
      { who: "bailong", text: "……奶奶，会，等我。" },
      { who: "claude", text: "我们，会回来。" },
      { text: "说这话的时候，克劳德没有考虑，自己是不是，有资格，许下这个承诺。她只是，在那一刻，非常，非常地，想让它成真。" },

      { effect: "fadeOut", text: "风，从山脊上，吹了过去。" },

      /* ===== 章末：直接衔接第九章「山之低语」 ===== */
      { label: "ch08_end" }
    ]
  };
})();
