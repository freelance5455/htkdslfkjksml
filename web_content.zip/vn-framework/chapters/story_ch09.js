/* =====================================================
   story_ch09.js —— 第九章「山之低语」（深岩城、缄石、山之碎片）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch08_end 之后（ch08 以 fadeOut 结尾，本章以 fadeIn 开场）。
   依赖：第七、八章的 flag：cutknown / samuel / bl_ember / shard / grandma（只用于对话回响，缺失时走默认分支）。
   本章以 fadeOut 黑屏结尾，第十章（云海）以 fadeIn 开场。
   ===================================================== */
window.STORY_CH09 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {
      greta:  { name: "格丽塔", title: "矿区工头", color: "#c8a878" },
      harold: { name: "哈罗德", title: "矿誓会长", color: "#a89888" }
    },
    addBackgrounds: {
      ash_road:       { src: "assets/bg/ash_road.jpg",
                        color: "linear-gradient(180deg,#6a6a60 0%,#a89a78 55%,#4a4438 100%)" },
      deeprock_gate:  { src: "assets/bg/deeprock_gate.jpg",
                        color: "linear-gradient(180deg,#3a3630 0%,#7a6a50 55%,#2a2620 100%)" },
      deeprock_street:{ src: "assets/bg/deeprock_street.jpg",
                        color: "linear-gradient(180deg,#1a1814 0%,#4a3a28 55%,#a07a3a 100%)" },
      guild_hall:     { src: "assets/bg/guild_hall.jpg",
                        color: "linear-gradient(180deg,#14100c 0%,#3a2c1e 55%,#7a5a34 100%)" },
      mine_shaft:     { src: "assets/bg/mine_shaft.jpg",
                        color: "linear-gradient(180deg,#050403 0%,#1e1810 55%,#5a4020 100%)" },
      heart_well:     { src: "assets/bg/heart_well.jpg",
                        color: "linear-gradient(180deg,#020202 0%,#2a2010 55%,#c8a040 100%)" },
      collapse:       { src: "assets/bg/collapse.jpg",
                        color: "linear-gradient(180deg,#0a0806 0%,#3a2a1a 55%,#6a5a48 100%)" },
      rock_dawn:      { src: "assets/bg/rock_dawn.jpg",
                        color: "linear-gradient(180deg,#4a5068 0%,#c8a888 60%,#8a7a68 100%)" }
    },
    addCgs: {
      cg_deeprock: { src: "assets/cg/deeprock.jpg",
                     color: "linear-gradient(180deg,#14100c 0%,#5a4020 50%,#e0a850 100%)" },
      cg_heart_well: { src: "assets/cg/heart_well.jpg",
                     color: "linear-gradient(180deg,#020202 0%,#3a2a0a 50%,#f0c050 100%)" }
    },
    addAudio: {
      bgm: { ch09_road: "assets/audio/ch09_road.mp3", ch09_city: "assets/audio/ch09_city.mp3",
             ch09_guild: "assets/audio/ch09_guild.mp3", ch09_mine: "assets/audio/ch09_mine.mp3",
             ch09_well: "assets/audio/ch09_well.mp3", ch09_rescue: "assets/audio/ch09_rescue.mp3",
             ch09_dawn: "assets/audio/ch09_dawn.mp3" },
      sfx: { drum: "assets/audio/drum.mp3", rumble: "assets/audio/rumble.mp3", rock: "assets/audio/rock.mp3" }
    },

    /* flag（本章新增）：
       entry:    "sneak" / "saint" / "dragon"      —— 怎么进深岩城
       mountain: "listen" / "seal" / "sample"      —— 在心井：倾听 / 封井 / 取走一块缄石
       rescue:   "bailong" / "mingyue" / "claude"  —— 塌方救援由谁主导
       kanshi: true                                 —— 手里有缄石（sample 线；以后可用于「断线」类结局）
       earplug: true                                —— 格丽塔送的石耳塞（所有线都会拿到）
    */

    script: [

      { label: "ch09_start" },
      { chapter: { no: "CHAPTER 09", title: "山之低语", sub: "THE WHISPERING MOUNTAIN · 深岩城" } },

      /* ---------- 一、下山，往东南 ---------- */
      { hide: "all", cgHide: true, bg: "ash_road", transition: "black", bgm: "ch09_road", effect: "fadeIn",
        text: "下了龙脊，路，就换了颜色。" },
      { text: "北境的雪，被她们一天一天地，留在了身后。脚下的土，变成了铁锈色，再变成灰，最后，成了一种细得像面粉的、带着腥味的黄褐色粉尘。" },
      { show: LINE, who: "mingyue", expr: MY("worried"),
        text: "……不对。我的耳朵，一直，在嗡嗡响。" },
      { who: "claude", text: "是风吗？" },
      { who: "mingyue", text: "不是风。是，更低的。低到，不像声音。像，有人，在地底下，很慢很慢地，叹气。" },
      { who: "bailong", text: "（吸了吸鼻子）……铁。还有，很老很老的，石头。" },
      { text: "那粉尘，落在袖口上，用手一捻，就捻出一道黄色的痕。人们叫它「山咳」。据说，那是山里的东西，在睡梦里，咳出来的。" },

      { if: { shard: "taken" },
        text: "白泷胸口的那团火，在这片土地上，隐隐发着热。每走一步，脚下的石头，就像认出了什么，轻轻地，回应一下。" },
      { if: { shard: "claude" },
        text: "克劳德袖口里的那点暖红，在靠近山脉之后，一直亮着。她把手藏得更紧了些。" },
      { if: { shard: "left" },
        text: "白泷走几步，就回头，望一眼龙脊的方向。那根淡淡的光柱，还立在天边，像一根不肯拔掉的、很细的针。" },

      { text: "走到第六天的傍晚，那座城，出现在她们面前。" },

      /* ---------- 二、深岩城 ---------- */
      { hide: "all", bg: "deeprock_gate", transition: "cut", bgm: "ch09_city",
        text: "它不是建在山上的。它是，从山里，掏出来的。" },
      { cg: "cg_deeprock",
        text: "整座山的南坡，被一层一层地，凿成了阶梯。每一层，是一条街；每一道街，嵌着一排窗；每一扇窗里，有一盏昏黄的灯。灯火，沿着山势，一直爬到云里。" },
      { text: "城门，是一道巨大的、几乎和山体融为一体的石拱。门楣上刻着三个字：「深岩城」。字下面，是一个熟悉的纹样。一把交叉的镐，和一枚缺了一道光的日轮。" },
      { cgHide: true, show: LINE, who: "claude", text: "……教会，在这里，也有标记。" },
      { text: "城门口，站着两个守卫。他们没有说话，也没有盘问。只是看见了溟月，就同时，抬起了手，做了一个，手背贴着耳朵的动作。" },
      { sfx: "drum", text: "咚——咚咚。咚。门楼上的鼓，敲了一串很短的节奏。城门里，同样的鼓声，一层一层地，应了下去。" },
      { who: "mingyue", expr: MY("surprised"), text: "……他们，在干什么？" },
      { speaker: "城里的孩子", text: "（比着手势，又指了指耳朵，递来一团蜡）" },
      { who: "mingyue", text: "……让我，塞耳朵？！" },
      { who: "claude", text: "这座城里，没有人说话。他们都戴着耳塞，用手势和鼓声交谈。" },
      { who: "claude", text: "……为了，不听见，山。" },

      { text: "守卫拦住了她们。一块写着「矿誓会」的木牌，横在了门前。他伸出一只手，指向她们，又指指牌子，意思再明白不过：要入城，请出示通行凭证。",
        choices: [
          { text: "套上旧斗篷，假扮成运货的杂役混进去",   jump: "ch09_sneak",  set: { entry: "sneak" } },
          { text: "亮出圣典，以教会的名义要求入城",       jump: "ch09_saint",  set: { entry: "saint" } },
          { text: "请白泷「友好地」看一眼守卫",           jump: "ch09_dragon", set: { entry: "dragon" } }
        ] },

      /* ----- 假扮杂役 ----- */
      { label: "ch09_sneak" },
      { text: "克劳德把斗篷的兜帽，拉得更低，又在溟月的怀里，塞了一只不知从哪儿摸来的空货筐。" },
      { who: "mingyue", text: "……这筐，装的是什么？" },
      { who: "claude", text: "空气。在这座城里，这大概，是最没有人会查的东西。" },
      { text: "守卫用鼓槌，敲了敲货筐。又敲了敲溟月的脑袋。然后，非常熟练地，指了指城门里的方向：「后门，卸货。」" },
      { who: "mingyue", expr: MY("angry"), text: "……为什么，敲我的头？！" },
      { jump: "ch09_inside" },

      /* ----- 亮圣典 ----- */
      { label: "ch09_saint" },
      { text: "克劳德把圣典，举到胸前。烫金的封面，在暮色里，闪了一下。" },
      { text: "守卫的手，僵住了。他看了看那本书，又看了看她的脸。然后，很缓慢地，放下了木牌，退到了一边，敲了一串，更长的鼓点。" },
      { text: "城门里，鼓声，一层一层地，传了下去。比她们的脚步，更快。" },
      { if: { cutknown: true },
        who: "claude", text: "……我，不喜欢这个效果。" },
      { who: "mingyue", expr: MY("worried"), text: "什么效果？" },
      { who: "claude", text: "每一次，我亮出这本书，所有人，都会，让开。……而我现在，已经，不确定，他们让开的，是敬意，还是别的。" },
      { jump: "ch09_inside" },

      /* ----- 白泷看一眼 ----- */
      { label: "ch09_dragon" },
      { who: "bailong", text: "……我，看。" },
      { text: "白泷往前走了一步，抬起眼睛，对着守卫，认认真真地，看了一眼。她的瞳孔，缩成了一条，非常窄的竖线。" },
      { text: "守卫的鼓槌，掉在了地上。另一个，直接，向后坐了下去。两个人同时，把双手，高高举起，比出了一个，全城通用的手势：「请，请进。」" },
      { who: "mingyue", expr: MY("surprised"), text: "……你，这算，友好吗？" },
      { who: "bailong", text: "我，笑了。" },
      { who: "claude", text: "……下次，请先，用嘴角。" },
      { text: "身后的城门楼上，鼓声，疯了一样，敲成了一团。" },
      { jump: "ch09_inside" },

      { label: "ch09_inside" },

      /* ---------- 三、街与矿誓会 ---------- */
      { hide: "all", bg: "deeprock_street", transition: "fade", bgm: "ch09_city",
        text: "城里，安静得，像一座巨大的、点着灯的坟。" },
      { show: LINE, text: "街上到处是人。矿工，商贩，抱着孩子的妇人。他们彼此擦肩，彼此点头，用手指，在空气里，快速地比划着什么。没有一个人开口。" },
      { text: "所有人的耳朵里，都塞着一小团灰白色的蜡。像一座城，集体，选择了，不去听某一件事。" },
      { who: "mingyue", expr: MY("normal"), text: "……好奇怪。明明，这么多人。我却觉得，像走在，一间，没有人的屋子里。" },
      { who: "greta", text: "是吧？我也这么觉得。" },
      { text: "说话的，是一个个子矮得只到克劳德肩膀的女人。皮肤是灰褐色的，像打磨过的石面。她背着一把比她半个人还长的镐，耳朵里，什么也没有塞。" },
      { who: "mingyue", expr: MY("surprised"), text: "你，会说话？！" },
      { who: "greta", text: "会。我叫格丽塔。矿区工头。大家，都叫我，疯子。" },
      { who: "greta", text: "因为，我是，全城，唯一，不戴那个的人。" },
      { who: "claude", text: "……为什么，不戴？" },
      { who: "greta", text: "因为，我想听。" },
      { text: "她说这话的时候，没有笑。她的眼睛，是一种很深的、像矿道最里面的颜色。" },
      { who: "greta", text: "这城里，每个人，一入矿，就被发一块耳塞。会长说，山咳，会让人，发疯。" },
      { who: "greta", text: "我二十年，没戴。我没疯。我只是，听见了，一些，不该听见的。" },
      { who: "claude", text: "……比如？" },
      { who: "greta", text: "不在这里说。会长，在盯着。晚上，来井口。" },
      { text: "她转身要走，又停住，回头看了一眼白泷的头发。" },
      { who: "greta", text: "……那孩子，身上，有火。山，会喜欢的。" },

      /* 矿誓会 */
      { hide: "all", bg: "guild_hall", transition: "cut", bgm: "ch09_guild",
        text: "矿誓会的大厅，在城的最高处。" },
      { show: LINE, text: "一个须发花白、背脊笔直的男人，坐在一张用整块黑岩削成的长桌后。他耳朵里，塞着一对精工雕琢的石耳塞，上面镶着一枚，缺了光的日轮。" },
      { who: "harold", text: "（用手势，比了一个「请坐」，随后，取下一只耳塞）诸位，远道而来。" },
      { who: "harold", text: "我是哈罗德，矿誓会长。深岩城，欢迎一切，带着钱，或者，带着理由的人。" },
      { who: "claude", text: "……我们，只是，路过。" },
      { who: "harold", text: "路过。（笑）这座城，在山的肚子里，没有人，是路过的。要么是来挖的，要么，是来买的。" },
      { who: "harold", text: "您，是教会的人。我从您的圣典上，认出来了。" },
      { who: "harold", text: "教会，是我们的，第一大主顾。我们挖出来的东西，百分之八十，都送往了，王都。" },
      { who: "claude", text: "……什么东西？" },
      { who: "harold", text: "（轻描淡写）缄石。" },
      { who: "claude", text: "……缄石。" },
      { text: "这个词，像一小粒冰，落进了她的胸口。克劳德想起，每一次安魂礼的时候，香炉里，那一层，灰黄色的、细腻的粉末。" },
      { who: "harold", text: "教会管它，叫『镇魂盐』。我们，管它，叫『山的嘴』。" },
      { who: "harold", text: "山，在咳。我们，把咳出来的东西，卖给，需要安静的人。双赢。" },
      { who: "mingyue", expr: MY("angry"), text: "……听起来，一点都不双赢！" },
      { who: "harold", text: "（摊开手）这位小姐，请问，您吃过饭吗？" },
      { who: "mingyue", text: "……吃过！" },
      { who: "harold", text: "那，您就，已经，是我们的，主顾了。" },
      { text: "哈罗德没有再说话。他重新，塞好了那只耳塞，对她们，微微颔首。会谈，在他的手里，像一把被擦得很亮的刀，轻轻地，收了回去。" },

      /* ---------- 四、夜里的井口 ---------- */
      { hide: "all", bg: "mine_shaft", transition: "black", bgm: "ch09_mine",
        text: "夜里，她们，在矿道的入口，找到了格丽塔。" },
      { show: LINE, who: "greta", text: "来了。……跟紧我。别乱碰墙。墙，是活的。" },
      { who: "mingyue", expr: MY("surprised"), text: "……活的？" },
      { who: "greta", text: "你摸一摸。" },
      { text: "溟月试探着，把指尖，贴在了岩壁上。那一刻，她整个人，抖了一下。" },
      { who: "mingyue", text: "……温的。而且，在，动。很慢很慢地，像，在，呼吸。" },
      { who: "greta", text: "对。每七个钟头，一次。我数过。二十年，没有错过。" },
      { text: "矿道，一层一层地，向下。越向下，越安静。到了最深处，连脚步声，也被那种厚重的黑，咽了下去。" },
      { text: "最后，格丽塔，在一道低矮的石门前，停住了。她推开门。" },
      { bg: "heart_well", cg: "cg_heart_well", transition: "cut", bgm: "ch09_well",
        text: "那是一口，无底的井。" },
      { text: "井，是圆的。井壁上，一圈一圈，嵌着无数细小的、黄褐色的晶体。像一只巨大的、睁开了一半的眼睛。" },
      { text: "最深处，有一点光。像一颗，在泥土里，埋了一万年的种子，在极缓极缓地，向上，顶。" },
      { who: "greta", text: "这是，心井。城里，所有人，都不许，到这里来。会长，每年，只下来一次。" },
      { who: "greta", text: "他挖。……他们，挖了三十年。每挖一寸，山，就，疼一寸。" },
      { who: "claude", text: "……你怎么知道，它在疼？" },
      { who: "greta", text: "因为，我听得见。" },
      { text: "她仰起头，把耳朵，对着井口。过了很久，才慢慢地说。" },
      { who: "greta", text: "它说话，很慢。慢到，一个字，要一个钟头。我听了二十年，才，拼出来，半句。" },
      { who: "greta", text: "「……疼……」" },
      { if: { cutknown: true },
        who: "claude", text: "……缄石，是，从它身上，挖下来的。又被，磨成了粉，用来，剪线。" },
      { if: { cutknown: true },
        who: "mingyue", expr: MY("angry"), text: "……所以，教会，是在，割它的肉，来堵，别人的嘴？！" },
      { if: { cutknown: true },
        who: "claude", text: "……是。" },

      { text: "克劳德站在井边，低头，看着那一点，缓缓顶向上来的光。",
        choices: [
          { text: "取下耳塞，让溟月和所有人，一起「倾听」",     jump: "ch09_listen", set: { mountain: "listen" } },
          { text: "请格丽塔，帮忙封住心井，停止开采",           jump: "ch09_seal",   set: { mountain: "seal" } },
          { text: "从井壁上，取下一小块缄石，带走研究",         jump: "ch09_sample", set: { mountain: "sample", kanshi: true } }
        ] },

      /* ----- 倾听 ----- */
      { label: "ch09_listen" },
      { who: "claude", text: "……溟月。你，听得见吗？" },
      { who: "mingyue", expr: MY("worried"), text: "我？我听，是听得见一点……可是，我不是，格丽塔……" },
      { who: "claude", text: "你，是鲸。鲸，听得见，别人听不见的、很低的东西。" },
      { text: "溟月沉默了一会儿。然后，很慢地，摘下了耳朵里，那一团，早就塞进去的蜡。" },
      { text: "她在井边，坐了下来。闭上眼睛，把尾巴，轻轻地，贴在石面上。像一个，把耳朵，贴在，恋人胸口上的人。" },
      { text: "一个钟头过去了。又一个。井里，什么也没有发生。只有那一点光，在缓缓地，一明，一灭。" },
      { who: "mingyue", text: "……来了。" },
      { who: "mingyue", text: "……它，在，说。" },
      { text: "溟月睁开眼睛，嘴唇，一点一点地，复述。每一个字，间隔，很长很长。像一块，被时间拉长了好几百倍的、很沉的钟声。" },
      { who: "mingyue", text: "……还……" },
      { who: "mingyue", text: "……在……" },
      { who: "mingyue", text: "……疼……" },
      { text: "又过了很久很久。天，大概已经亮了。矿道里，听不见。只有那一点光，亮了一下。" },
      { who: "mingyue", expr: MY("surprised"), text: "……别……" },
      { who: "mingyue", text: "……剪……" },
      { who: "claude", text: "……别剪。" },
      { who: "mingyue", text: "（点头，眼泪，一滴一滴，落在石面上，很快渗了进去）……它，一直，在说，这一句。" },
      { if: { shard: "taken" },
        text: "白泷胸口的火，在这一刻，隔着衣服，亮了起来。井里的光，像认出了什么，向她，轻轻地，闪了一下。" },
      { if: { shard: "taken" },
        who: "bailong", text: "……它，认得我。……是，邻居。" },
      { who: "greta", text: "……二十年。我，终于，听完了，一整句。" },
      { text: "这个矮小的女人，慢慢地，蹲了下去。背对着所有人，用那只满是老茧的手，捂住了脸。" },
      { jump: "ch09_aftermount" },

      /* ----- 封井 ----- */
      { label: "ch09_seal" },
      { who: "claude", text: "格丽塔。……能不能，停下来？" },
      { who: "greta", text: "停？" },
      { who: "claude", text: "停止开采。封住心井。至少，不要，再往下挖了。" },
      { who: "greta", text: "（沉默了很久）……深岩城，三万人，吃饭，靠它。" },
      { who: "claude", text: "……我知道。" },
      { who: "greta", text: "你，是教会的人。教会，是买主。你，现在，在叫我，砸买主的饭碗，也砸，三万人的饭碗。" },
      { who: "claude", text: "……我现在，已经不太确定，我是不是，教会的人。" },
      { text: "格丽塔看了她很久。像在用目光，称量一块，从未见过的矿石。" },
      { who: "greta", text: "……封井，不难。井口的三根承重柱，是我带人，立的。拔掉一根，山，自己，就会合上。" },
      { who: "greta", text: "难的是，之后。会长，会来找我。……他会，找你们。" },
      { who: "mingyue", expr: MY("normal"), text: "那我们，就让他来找！" },
      { who: "bailong", text: "我，在。" },
      { text: "格丽塔笑了。那是她们第一次，看见她，笑。笑得像一块被敲裂的石头，露出了，里面一点点，湿润的颜色。" },
      { who: "greta", text: "……好。二十年了。我等的，大概，就是这句话。" },
      { sfx: "rock", text: "她走到井口，用那把比她还长的镐，对准其中一根，已经被磨得发亮的石柱，狠狠地，砸了下去。" },
      { jump: "ch09_aftermount" },

      /* ----- 取样 ----- */
      { label: "ch09_sample" },
      { text: "克劳德走到井壁边，伸出手，指尖，碰到了一块，黄褐色的晶体。很凉，像一小块，冬天的玻璃。" },
      { who: "mingyue", expr: MY("surprised"), text: "你，要拿它？" },
      { who: "claude", text: "我想，知道，它到底，是什么。" },
      { who: "claude", text: "……如果，我不知道，它是怎么，剪线的，我就不知道，怎么，把线，接回来。" },
      { who: "greta", text: "……拿吧。别让它，碰到，你自己的皮肤。" },
      { who: "claude", text: "为什么？" },
      { who: "greta", text: "碰到的人，会安静。……安静得，什么都不想要。我见过，有人，碰了一整年。" },
      { text: "克劳德用圣典的封皮，包住那块晶体，把它，小心地，放进了怀里。隔着布，那一小块东西，沉得像一粒，冷却了的叹息。" },
      { who: "bailong", text: "……它，不好闻。像，被擦掉的，味道。" },
      { who: "claude", text: "我知道。……所以，我才，要带着它。" },
      { jump: "ch09_aftermount" },

      /* ---------- 五、山咳 ---------- */
      { label: "ch09_aftermount" },
      { hide: "all", cgHide: true, bg: "collapse", transition: "black", bgm: "ch09_rescue",
        text: "就在这时，整座山，咳了一声。" },
      { sfx: "rumble", text: "那不是比喻。那是一声，从地底最深处，传上来的、沉闷的、几乎让人想要跪下的、巨大的咳嗽。" },
      { text: "矿道的顶部，簌簌地落下碎石。远处，传来了，木头，断裂的巨响。紧接着，是人们，在地下，用鼓，用手，拼命敲击的声音。" },
      { show: LINE, who: "greta", text: "……塌了！七号道！下面，有人！" },
      { who: "mingyue", expr: MY("surprised"), text: "有多少？！" },
      { who: "greta", text: "夜班，四十个。……他们，全塞着耳塞。他们，听不见，自己的叫声。" },
      { text: "矿道，被一座塌下来的岩壁，堵死了。碎石之间，隐约有微弱的光，和一些，更微弱的敲击声。" },
      { text: "一个念头，在克劳德的脑子里，亮了一下：这座城，用耳塞，保护自己，不被山，吓疯。而现在，被困的人，恰恰，听不见，来救他们的人。" },

      { text: "时间，只有一两个钟头。必须有人，带头。",
        choices: [
          { text: "让白泷，用龙的力气，从正面推开岩壁",       jump: "ch09_r_bl", set: { rescue: "bailong" } },
          { text: "让溟月，用鲸的耳朵，找出被困者的位置",     jump: "ch09_r_my", set: { rescue: "mingyue" } },
          { text: "克劳德亲自，去叫醒全城，让所有人，摘下耳塞", jump: "ch09_r_cl", set: { rescue: "claude" } }
        ] },

      /* ----- 白泷 ----- */
      { label: "ch09_r_bl" },
      { who: "bailong", text: "我，来。" },
      { text: "她走到那一面塌下来的岩壁前，把双手，按在了上面。深吸了一口气。" },
      { if: { bl_ember: true },
        text: "她的发梢，一点一点，亮了起来。赤金色，像炉膛里，刚刚被风吹开的炭。热浪，从她的掌心，一圈一圈，向外推开。" },
      { if: "!bl_ember",
        text: "她的瞳孔，缩成了一条细线。指尖，隐隐伸出了，白色的、弯曲的爪。那是，她在人的形态里，所能做到的，最大程度的、龙。" },
      { sfx: "rock", text: "岩壁，裂开了。一道，两道，细细的纹路，从她的掌心，一直，爬到顶上。" },
      { who: "bailong", text: "……重。" },
      { who: "claude", text: "能撑吗？" },
      { who: "bailong", text: "能。……比奶奶，轻。" },
      { text: "最后一声巨响，岩壁，向两边，滚开了。灰尘里，露出了一张张，满脸煤黑的、茫然的脸。" },
      { text: "白泷，踉跄了一步，被克劳德扶住。她的手心里，全是血。她低头看了看，咧开嘴，很难看地，笑了一下。" },
      { who: "bailong", text: "……我，今天，没有，抢东西。我，推开了，一座山。" },
      { jump: "ch09_afterrescue" },

      /* ----- 溟月 ----- */
      { label: "ch09_r_my" },
      { who: "mingyue", text: "……我？可是，这里，太吵了！" },
      { who: "claude", text: "所以，你更要，听。" },
      { text: "溟月把双耳，高高地竖了起来。她闭上眼睛，把整个人，贴在了岩壁上。碎石，在她的身边，一粒一粒地，往下掉。" },
      { who: "mingyue", text: "……左边，十二步。有，四个。" },
      { who: "mingyue", text: "……下面，三层。有，一个，在，咳嗽。" },
      { who: "mingyue", text: "……后面，那条，细缝里，有，一个孩子。……他的，心跳，太快了。" },
      { text: "她的声音，一开始，还有一点发抖。可是，一个一个位置报出来之后，越来越稳，像一个，在海上，对着一整支船队，指着航向的，老舵手。" },
      { if: { sang: true },
        text: "说到最后，她忽然，哼了一小段，那半首，无词的歌。岩壁里面，立刻，传来了，一阵，细细的、有节奏的敲击声。那是被困者，在回应。" },
      { text: "不到半个钟头，被困的四十个人，一个也没有少，从不同的缝隙里，被一个一个地，拉了出来。" },
      { who: "mingyue", expr: MY("shy"), text: "……我，好像，真的，有点用。" },
      { who: "claude", text: "你，从来，都，有用。" },
      { who: "mingyue", text: "……你，不要，突然这样说话！" },
      { jump: "ch09_afterrescue" },

      /* ----- 克劳德 ----- */
      { label: "ch09_r_cl" },
      { who: "claude", text: "……我，去。" },
      { who: "mingyue", text: "去哪儿？！" },
      { who: "claude", text: "去，把全城，都，叫醒。" },
      { text: "克劳德冲上了矿道。她抓住一个，又一个，擦肩而过的矿工，扯下了他们耳朵里的蜡团。然后，用她十年里，练得最稳的那种声音，喊了出来。" },
      { who: "claude", text: "七号道，塌了！下面，有四十个人！需要，所有人，都来！" },
      { text: "那个声音，在这座，沉默了很多年的城里，炸开了。" },
      { text: "起初，没有人动。他们站在那里，睁大了眼睛，像一群，第一次，听见雷声的孩子。" },
      { text: "然后，有一个人，扔掉了，手里的灯笼。第二个，扔掉了，镐。第三个，扯下了耳塞，扔进了黑暗里，转身，冲向了矿道。" },
      { text: "一个，两个，十个，一百个。一座沉默的城，在同一个夜里，同时，摘下了，自己的耳朵。" },
      { text: "人们的喊声，叫声，鼓声，混成了一片，震得整座山壁，都在颤。" },
      { who: "greta", text: "……（站在矿道口，听着这一整座城的、第一次的声音，眼睛，红了）" },
      { who: "greta", text: "……二十年。我，终于，不是，一个人，在听了。" },
      { if: { entry: "saint" },
        text: "那些曾经因为圣典，而让开道路的人，这一次，是因为一个，真的，在喊的人，才跟着跑。克劳德没有说什么，只是，用袖子，狠狠擦了一下脸。" },
      { jump: "ch09_afterrescue" },

      /* ---------- 六、黎明 ---------- */
      { label: "ch09_afterrescue" },
      { hide: "all", bg: "rock_dawn", transition: "black", bgm: "ch09_dawn",
        text: "天亮的时候，矿道口，躺满了活着的人。" },
      { show: LINE, text: "没有一个人，死去。四十个夜班矿工，裹着毯子，靠着石壁，一个挨着一个，喝着不知是谁递来的热汤。有人在哭，有人在笑，有人，什么也不说，只是，一遍一遍地，摸着自己的耳朵。" },
      { text: "他们的耳塞，散落了一地。蜡团，被踩进泥里，像一堆被遗忘的小小的月亮。" },
      { who: "harold", text: "……您们，做了，一件，非常昂贵的事。" },
      { text: "哈罗德，不知何时，站在了她们的身后。他的耳塞，也被取下了。手里，攥着它，指节发白。" },
      { who: "harold", text: "您们知道，一座城，戴了三十年耳塞，是什么意思吗？" },
      { who: "claude", text: "……知道。" },
      { who: "harold", text: "是意味着，每一个人，都愿意，装作，没有听见，一件，他们早就听见的事。" },
      { who: "harold", text: "……您们，把这个，打碎了。" },

      { if: { mountain: "seal" },
        who: "harold", text: "封了心井。……教会的订单，下个月，就会断。他们，会派人来。不是我这样的人。" },
      { if: { mountain: "listen" },
        who: "harold", text: "……我听说，山，说话了。……三十年。……我也，一直，怕，听见，这一句。" },
      { if: { mountain: "sample" },
        who: "harold", text: "您，带走了，一块缄石。……那，是我们，用来，让人安静的东西。请您，不要，用错地方。" },

      { who: "claude", text: "会长。……我不是，来砸您的饭碗的。" },
      { who: "harold", text: "我知道。……您，是来，找，另一件，更大的东西的。" },
      { who: "harold", text: "（沉默，很久）……山，在东边。再往东，是云海。风，在那里。" },
      { who: "harold", text: "三十年前，教会的人，也问过我，同样的问题。我告诉了他们。……他们，回去，就开始，要缄石。" },
      { who: "claude", text: "……所以，您，其实，什么都知道。" },
      { who: "harold", text: "我只是，一个，会算账的人。" },
      { text: "他转过身，朝城里走去，背脊依旧笔直。走出几步，他忽然，没有回头地，抬了抬手。像是，告别，又像是，放行。" },

      { who: "greta", text: "……喂。你们。" },
      { text: "矮小的工头，把一个小布包，塞进了克劳德怀里。里面，是三对，灰褐色的、雕成了小水滴形状的石耳塞。" },
      { who: "greta", text: "山上的人，不爱，听见，风。……可是，你们，往风里去。会，用得上。" },
      { set: { earplug: true }, who: "greta", text: "别塞。只在，你们，听不下去的时候，才塞。" },
      { who: "mingyue", expr: MY("normal"), text: "……你，不跟我们走吗？" },
      { who: "greta", text: "我？我要留下。这一城的人，刚刚，学会了，怎么听。总得有人，教他们，怎么，不被吓疯。" },
      { who: "greta", text: "……而且，我答应了，山。听完，它，剩下的半句。" },

      { text: "她们离开深岩城的时候，已是黄昏。山路上，有人，正顺着，她们走过的方向，向她们，挥手。" },
      { text: "他们的耳朵，是空的。风，从那里，穿过去，带着一些，他们从来，没有听过的、陌生的声音。" },
      { who: "mingyue", text: "……真吵。" },
      { who: "claude", text: "嗯。" },
      { who: "mingyue", text: "……可是，比安静，好听。" },
      { text: "身后的山，在她们走远之后，极缓极缓地，呼出了一口气。山脊上的积雪，簌簌地，落了下来。像一个，很久很久，没有被人听见的巨人，终于，被谁，轻轻地，应了一声。" },
      { text: "而在更东的天边，一片白得发亮的云海，正缓缓地，翻涌过来。" },

      { effect: "fadeOut", text: "风，从云的那一边，吹了过来。" },

      /* ===== 章末：直接衔接第十章「云海」 ===== */
      { label: "ch09_end" }
    ]
  };
})();
