# 章节整合说明（给整合者 / GPT）

**原则：不改游戏本体**（index.html / style.css / script.js 一律不动），只改 `story.js`。

## 每个章节文件的结构
`chapters/story_chXX.js` 定义 `window.STORY_CHXX = { addCharacters, addBackgrounds, addCgs, addAudio, script }`：

| 字段 | 合并到 story.js 的位置 |
|---|---|
| `addCharacters` | 并入 `characters` |
| `addBackgrounds` | 并入 `backgrounds` |
| `addCgs` | 并入 `cgs` |
| `addAudio.bgm / .sfx` | 并入 `audio.bgm / audio.sfx` |
| `script`（数组） | 按章节顺序，放在 `story.js` 的 `script` 数组**最前面**（第六章之前） |

章节文件自带 CL / MY / BL 小工具（在函数内部），不依赖 story.js，所以整合时可以直接把 `script` 数组里的内容复制过去；如果复制后出现 `CL(...)` 等未定义，请改用 story.js 顶部已有的同名工具。

## 衔接约定
- 每章第一步是 `{ label: "chXX_start" }`，最后一步是 `{ label: "chXX_end" }`，章节之间**不放 end 步**，自然顺序进入下一章。
- 所有 label 带章节前缀，不会和第六章（A_start、B1、CAMP …）重名。
- 一章结尾若用了 `effect: "fadeOut"`（黑屏），下一章第一个内容步会用 `effect: "fadeIn"` 或 `bg` 转场接上；若结尾有 CG，下一章会 `cgHide`。
- 第六章开头有 5 步「前情提要」（第一个 `chapter` 步之前）。**前五章齐全后可以删掉**，那是为了第六章单独成篇才写的。

## 可选：自动合并工具
```
cd chapters
node merge_chapters.js ch01 ch02        # 按顺序合并，输出 ../story.merged.js
node merge_chapters.js ch01 ch02 ch03 ch04 ch05 --drop-recap
```
注意：输出是 JSON 风格，会丢失 story.js 的注释和 CL/MY/BL 小工具。需要保留注释就手动合并。合并后把 `story.merged.js` 改名为 `story.js` 即可，`index.html` 不用动。

## flag 总表（持续更新）
| flag | 来源 | 含义 |
|---|---|---|
| `sweet` = `"kept"` / `"refused"` | ch01 | 是否收下溟月的海盐焦糖 |
| `obeyed` / `ducked` | ch01 | 龙袭时听从大主教 / 跟溟月钻桌子 |
| `sneak` / `bold` | ch02 | 洞口选择潜伏观察 / 直接现身 |
| `coin` = `"kept"` / `"refused"` | ch02 | 是否收下白泷赔礼的金币（第三章集市可当盘缠） |
| `haggle` = `"hard"` / `"fair"` | ch03 | 集市砍价方式 |
| `poster` = `"torn"` / `"left"` | ch03 | 是否撕下悬赏告示（土豆画像） |
| `guide` = `"mingyue"` / `"bailong"` | ch04 | 雾中听谁的指引 |
| `mural` = `"order"` / `"scar"` | ch04 | 先按顺序读壁画 / 先看被凿去的一段（scar 线发现凿痕残留半枚日轮纹样） |
| `answer` = `"truth"` / `"silent"` | ch05 | 七嫂问话时克劳德说实话 / 沉默 |
| `night` = `"nets"` / `"pier"` | ch05 | 夜里陪老舵补网（听身世） / 去海边找溟月（听她亲口讲） |
| `route` = A/B/C，`touched`、`sang`、`exposed`、`trusted`、`decoy`、`saved` | ch06 | 见 NOTES.md |

## 素材 id（新增，素材可以之后再补，缺失时自动占位）
- ch01 背景：royal_hall、service_corridor；CG：cg_dragon_raid、cg_night_flight
- ch01 BGM：ch01_banquet、ch01_ceremony、ch01_raid、ch01_flight；SFX：glass、roar（另外用到第六章已有的 stone）
- ch01 新人物（无立绘）：archbishop 佩尔图斯、king 奥古斯特、gren 格伦
- ch02 背景：north_valley、dragon_cave；CG：cg_hoard；BGM：ch02_wild、ch02_cave、ch02_walk；SFX：coin
- 衔接：ch02 以 `fadeOut` 黑屏结尾，ch03 第一个内容步需 `effect:"fadeIn"`
- ch03 背景：border_gate、market_square、inn_room；CG：cg_market；BGM：ch03_market、ch03_inn；SFX：bite
- ch03 依赖 story.js 里的 raymond / oli（第六章已定义）；ch03 以 `fadeOut` 结尾，ch04 以 `fadeIn` 开场
- ch04 背景：mist_valley、ruin_hall；CG：cg_mural；BGM：ch04_mist、ch04_mural；SFX：whisper
- ch04 以 `fadeOut` 结尾，ch05 以 `fadeIn` 开场
- ch05 新人物（无立绘）：qisao 七嫂、laoduo 老舵；背景：harbor_dusk、pier_night、cairn_shore；CG：cg_long_table；BGM：ch05_harbor、ch05_table、ch05_night；SFX：gull
- ch05 以 `fadeOut` 结尾，直接衔接第六章（离港告别，`bg: harbor_dawn` 转场）；前五章齐全后，第六章开头 5 步「前情提要」可删除

---
## 第七、八章追加说明
- **⚠ 第六章末尾**那 7 个带 `end` 的步骤（"CHAPTER 06 · 完 … 未完待续"）整合第七章时必须删掉，换成 `{ effect: "fadeOut", text: "……" }`，让剧本自然流入 `ch07_start`。
- 第七章依赖：`raymond` / `oli`（story.js 已有）；第六章 flag：`saved`、`exposed`、`touched`、`sang`、`trusted`、`decoy`。
- 第八章依赖：第七章的 `samuel` 角色；flag：`method`、`samuel`、`bl_ember`。
- 两章都以 `fadeOut` 黑屏结尾，下一章以 `fadeIn` 开场；第七章以 `fadeIn` 接第六章，第八章以 `fadeIn` 接第七章。
- 已用"把第七、八章接在第六章之后"的方式做过静态校验：1486 步、无错误无警告、所有步骤可达。
- 总纲与结局表见 `OUTLINE_CH07_14.md`。

### 新增 flag
| flag | 来源 | 含义 |
|---|---|---|
| `method` = `rite` / `song` / `hoard` | ch07 | 霜渡疗法：安魂礼 / 鲸歌 / 白泷「收走」 |
| `cutknown` = true | ch07 | 知道安魂礼＝剪线（rite 线，或赴约见过塞缪尔） |
| `samuel` = `alone` / `together` / `ignored` | ch07 | 对塞缪尔邀约的回应 |
| `bl_ember` = true | ch07 / ch08 | 白泷体内留着一点火（hoard，或 shard=taken） |
| `climb` = `fly` / `walk` | ch08 | 白泷载人飞上龙脊 / 走古道 |
| `grandma` = `woke` / `watch` / `sang` | ch08 | 唤醒祖母 / 守夜 / 溟月唱歌 |
| `shard` = `taken` / `left` / `claude` | ch08 | 白泷带走 / 留下 / 克劳德接下（仅 grandma=woke 时有此选项） |
| `claude_ember` = true | ch08 | 克劳德接下了火 |

### 新增素材 id（缺失时自动占位）
- ch07 角色（无立绘）：samuel 塞缪尔、mira 米拉、hodd 霍德
- ch07 背景：north_road、frostford、sickroom、inn_hall、old_chapel、ferry_dawn；CG：cg_lanterns
- ch07 BGM：ch07_road / ch07_lanterns / ch07_town / ch07_sick / ch07_chapel / ch07_ferry；SFX：ice、bell
- ch08 角色（无立绘）：grandma 烬眠
- ch08 背景：ridge_foot、ice_stair、ridge_gate、dragon_hall、inner_room、ridge_top；CG：cg_dragon_flight、cg_sleeping_dragon
- ch08 BGM：ch08_ridge / ch08_stair / ch08_flight / ch08_hall / ch08_dream / ch08_shard；SFX：wing、ember

---
## 第九章追加说明
- 衔接：接在 ch08_end 之后；ch08 以 fadeOut 结尾，ch09 以 fadeIn 开场；ch09 以 fadeOut 结尾，第十章（云海）以 fadeIn 开场。
- 依赖：ch07/ch08 的 flag（`cutknown`、`shard`、`bl_ember`）只用于对话回响，缺失时走默认。
- 静态校验（ch06→ch07→ch08→ch09 连接）：1736 步、无错误无警告、所有步骤可达。
- 新增 flag：`entry`（sneak/saint/dragon）、`mountain`（listen/seal/sample）、`rescue`（bailong/mingyue/claude）、`kanshi`（sample 线，有缄石）、`earplug`（所有线都有：格丽塔送的石耳塞）。
- 新增角色（无立绘）：greta 格丽塔、harold 哈罗德。
- 新增背景：ash_road、deeprock_gate、deeprock_street、guild_hall、mine_shaft、heart_well、collapse、rock_dawn；CG：cg_deeprock、cg_heart_well。
- 新增 BGM：ch09_road / ch09_city / ch09_guild / ch09_mine / ch09_well / ch09_rescue / ch09_dawn；SFX：drum、rumble、rock。

---
## 第十章追加说明
- 衔接：接在 ch09_end 之后；ch09 以 fadeOut 结尾，ch10 以 fadeIn 开场；ch10 以 fadeOut 结尾，第十一章（王都的雪）以 fadeIn 开场。
- 依赖：samuel 角色（ch07）；flag `samuel` / `earplug` / `shard` / `method` 只用于对话回响，缺失时走默认。
- 静态校验（ch06→ch10 连接）：1991 步、无错误无警告、所有步骤可达。
- 新增 flag：`toll`（truth/shell/plug）、`threads`（reconnect/release/samuel）、`ask`（why/fifth/wake）、`sam_dream`（塞缪尔重新有了梦）、`shell_back`（红线贝壳被风还回）。
- 新增角色（无立绘）：selene 赛琳。
- 新增背景：cloud_cliff、wind_lift、tower_hall、tower_top；CG：cg_threads。
- 新增 BGM：ch10_cliff / ch10_ascend / ch10_hall / ch10_samuel / ch10_wind / ch10_leave；SFX：wind、chime。
- 本章埋的伏笔（第十一章要接）：
  1. 风给了克劳德一封没署名的信，**要到王都才能拆**。
  2. 赛琳托她们给王都的某个人带一句话：「风，一直，在听。」
  3. 塞缪尔透露：大主教改了礼台规格，「站在礼台中央」在图纸上已不是「站着」。
  4. 第五块 = 被人亲手放进自己胸口的碎片；此前有 37 位圣女（`ask: fifth` 线才明确听到，其他线只是旁敲侧击，第十一章需分支回应）。

---
## 第十一章追加说明
- 衔接：接在 ch10_end 之后；ch10 以 fadeOut 结尾，ch11 以 fadeIn 开场；ch11 以 fadeOut 结尾，第十二章（大教堂之夜）以 fadeIn 开场。
- 依赖：archbishop / king / gren（story.js 已有）、raymond / oli、samuel；flag `ask` / `cutknown` / `saved` / `decoy` 只用于对话回响，缺失走默认。
- 静态校验（ch06→ch11 连接）：2261 步、无错误无警告、所有步骤可达。
- 新增 flag：`gift`（flower/pin/coin）、`letter`（读过伊芙琳的信）、`entry2`（sneak/front/king）、`knowsplan`（所有线都会知道礼台真相）、`plan`（expose/feign/flee）。
- 新增角色（无立绘）：valen 瓦伦、evelyn 伊芙琳（仅信件旁白用）。
- 新增背景：capital_gate、snow_street、inn_night、canal_under、cathedral_nave、throne_room、archive、snow_dawn；CG：cg_snow_capital、cg_cradle。
- 新增 BGM：ch11_snow / ch11_festival / ch11_letter / ch11_canal / ch11_cathedral / ch11_king / ch11_archive / ch11_dawn；SFX：bellbig、step_snow、stamp（bellbig、step_snow 本章暂未使用，可忽略）。
- 第十二章要接的伏笔：
  1. 礼台真相：收束礼＝把海/山/火/风四块碎片放进第三十八个「座」（克劳德的胸口），克劳德成为「圆心」，一个人替所有人做梦；大主教叫它「一个人，替所有人，疼」。
  2. `plan`：expose（公开揭发）/ feign（假意配合混进礼台）/ flee（想逃，被封城挡下，自愿回来）——第十二章开头按 `plan` 分流，之后汇合。
  3. 塞缪尔因质疑礼台规格，被派去看守地牢（可在第十二章救出/对话）。
  4. 大主教的条件：同伴不得入内（`entry2: front` 线）；国王给了王室书库钥匙（`entry2: king` 线），格伦听令于国王。
  5. 赛琳托的话「风，一直，在听」已交给瓦伦。
  6. 三块碎片在谁身上由前面的 flag 决定：`shard`（taken＝白泷 / claude＝克劳德 / left＝仍在祖母处）、山之碎片仍在心井、风之碎片在风塔、海之碎片在海里——第十二章需要说明「碎片是怎么被召到礼台的」。

---
## 第十二章追加说明
- 衔接：接在 ch11_end 之后；ch11 以 fadeOut 结尾，ch12 以 fadeIn 开场；ch12 以 fadeOut 结尾，第十三章（圆）以 fadeIn 开场。**终局抉择在第十三章**，本章结束在「第十三下钟响，四道光落在克劳德面前」。
- 依赖：archbishop / king / gren / samuel 已有；flag `plan` / `entry2` / `shard` / `threads` / `sam_dream` / `method` 只用于分流与回响，缺失走默认。
- 静态校验（ch06→ch12 连接）：2456 步、无错误无警告、所有步骤可达。
- 新增 flag：`jail`（freed/skipped）、`stand`（refuse/accept/bargain）、`public`（expose 线已当众念册子）。
- 新增背景：cathedral_square、dungeon、platform；CG：cg_four_lights。无新增角色。
- 新增 BGM：ch12_square / ch12_dungeon / ch12_vigil / ch12_platform / ch12_arrival；SFX：chain、bell13、surge。
- **埋给结局的伏笔**：
  1. 「真结局」回忆：碎片之蓝光掠过时，克劳德闪回——一条沿海的路，白袍的游行队伍簇拥着八岁的她，队伍外的麻绳外，有个头发深蓝、笑声像海浪的小女孩，手里攥着一包用油纸包着的东西。克劳德与溟月都隐约觉得「很久以前跑过/见过」，白泷说她们「闻起来很像」。（ch01 的 `sweet` 海盐焦糖可在真结局里回收。）
  2. 「搞笑结局」：溟月在礼台上说：「如果我现在变成一条几十丈长的大鲸鱼，一口把你叼起来就跑，你说他们追得上吗？」「会飞的那种？」「对！会飞的那种！」白泷抢着说自己也能载。
  3. `jail: freed` → 塞缪尔和 23 名异议者在场，塞缪尔答应帮「剪礼台底座的缄石」（终局「断线」/「永缺」的手段）；`jail: skipped` → 他们仍被关着。
  4. `stand`：refuse / accept / bargain 影响第十三章开头克劳德站的位置与大主教的态度，但三者都汇合到同一个终局抉择。

---
## 第十三章追加说明（终局抉择）
- 衔接：接在 ch12_end 之后；ch12 以 fadeOut 结尾，ch13 以 fadeIn 开场；ch13 在 `ch13_end` 前以 fadeOut 结尾，**第十四章（尾声）开头按 flag `ending` 分流**：
  `{ if: { ending: "E1" }, jump: "ch14_E1" }` … `{ if: { ending: "E8" }, jump: "ch14_E8" }`。
- 依赖：flag `stand / jail / shard / method / grandma / threads / kanshi / cutknown / samuel / sweet / toll` 只用于分流、回响、选项解锁，缺失走默认。
- 静态校验（ch06→ch13 连接，结尾临时接 8 个 `if: { ending }` 的 end）：2702 步、无错误无警告，**8 个结局都能走到**。
- 引擎的 `if` 只支持「且」，所以「或」条件在选项前被折叠成 `can_E1 / can_E2 / can_E3 / can_E4 / can_E6 / can_E8` 标记（见 ch13 选项前的一串 `set` 步），选项用 `if: "can_E1"` 之类引用。
- 新增 flag：`ending`（E1…E8）、`can_E1…can_E8`（内部用）。
- 新增角色（无立绘）：god_sea 海、god_mountain 山、god_fire 火、god_wind 风（「碎片之声」）。
- 新增背景：circle_void、memory_coast；CG：cg_circle、cg_whale_flight。
- 新增 BGM：ch13_void / ch13_voices / ch13_choice / ch13_memory / ch13_comic；SFX：heartbeat、shatter（暂未使用）、splash。
- 终局选项结构：
  - 第一层：为世界做决定 / 为自己做决定（伊芙琳的信）/ （笑）「溟月，你刚才说的办法，还作数吗？」（E7，无条件）
  - 为世界：重圆 E1、永缺 E2、断线 E3、圆心 E4、龙火 E6（各自按条件出现，且任何路线至少有一项；另有「先回去再想想」可回到第一层）
  - 为自己：回海边 E5（无条件）、「让我把被雪盖住的事想起来」E8（真结局，需 `sweet=kept` 或 `toll=truth`）
- 本章已完整写出 E8 的回忆（十年前海边，溟月追风筝，把海盐焦糖扔给八岁的克劳德）与 E7 的开头（溟月变鲸鱼飞走、白龙追赶、大主教「我需要坐下」）。各结局的**后续尾声**都留给第十四章。
- 第十三章里的神之真相保持留白：每一块碎片记得的不是同一个夜晚；「自愿 / 被请求」两种说法并存；「莫信『自愿』二字」是否为真没有定论。

---
## 第十四章追加说明（全剧终）
- 衔接：接在 ch13_end 之后；ch13 以 fadeOut 结尾，ch14 以 fadeIn（各结局自己的 chapter 卡 + 转场）开场。
- 本章第一步起按 flag `ending`（E1…E8）分流；每个尾声以 `end` 步收尾（共 8 个 `end`）。末尾保底：没有 `ending` 时跳到 E5。
- 静态校验（ch06→ch14 全部连接）：2962 步、无错误无警告，**8 个结局的 `end` 全部可达**（唯一"未走到"的是 `ending` 缺失时的保底 jump，属正常）。
- 无新增 flag，无新增角色。
- 新增背景：cathedral_hall、spring_harbor、dragon_sky；CG：cg_true_end（E8 终幕）。复用：cg_long_table（ch05）、cg_whale_flight / cg_circle（ch13）、snow_dawn（ch11）、circle_void（ch13）。
- 新增 BGM：ch14_e1 … ch14_e8（每个结局一首）。
- 各结局概要：
  - E1 重圆：神在冬至的日出里说「早安」，线不断也不拽，像呼吸；教会自己解散，大主教念出 37 个名字；她们回港口。
  - E2 永缺：礼台搬空、穹顶不补，每年冬至点灯；塞缪尔的倾听所；她们沿路探望各个碎片。
  - E3 断线：魔法消失、共鸣热消失、也听不见神；溟月的歌是她自己的，没有断；克劳德在海边给伊芙琳放信。
  - E4 圆心：克劳德成为圆心，不再醒来；溟月每天来讲话，白泷带回别人丢的东西，大厅里摆起「一万家」的长桌。
  - E5 归海：她们回到港口的普通日子，后来的事都是行商嘴里听来的；克劳德学补网、做咸鱼饭，笑得不标准但好看。
  - E6 龙火：龙族醒来，把一代代收着的失物送还主人，白泷做「龙族邮差」。
  - E7 鲸飞（搞笑）：报纸头条、雷蒙奥利的出差、鲸与龙抢着载克劳德、四块碎片被带去「玩」，在鲸背上睡着。
  - E8 真结局「百家饭」：座位变大，三个人一起坐；大陆上被她们帮过的人都把自己的线递出来织成网接住神；码头上，克劳德吃下溟月十年前扔给她的那颗海盐焦糖；伊芙琳的回信「我看见了海」。
- 全剧共 14 章、8 个结局。整合说明、flag 表与素材清单均已在本文件按章追加。
