/* =====================================================
   story_ch10.js —— 第十章「云海」（风之碎片、被剪断的线、塞缪尔再次出现）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch09_end 之后（ch09 以 fadeOut 结尾，本章以 fadeIn 开场）。
   依赖：samuel 角色（ch07）；flag：samuel / earplug / kanshi / shard / bl_ember / cutknown（只用于回响，缺失走默认）。
   本章以 fadeOut 黑屏结尾，第十一章（王都的雪）以 fadeIn 开场。
   ===================================================== */
window.STORY_CH10 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {
      selene: { name: "赛琳", title: "风信官", color: "#a8d8f0" }
    },
    addBackgrounds: {
      cloud_cliff: { src: "assets/bg/cloud_cliff.jpg",
                     color: "linear-gradient(180deg,#7aa8d8 0%,#e8f0f8 55%,#c8d8e8 100%)" },
      wind_lift:   { src: "assets/bg/wind_lift.jpg",
                     color: "linear-gradient(180deg,#5a88c8 0%,#d8e8f8 60%,#f8f8f8 100%)" },
      tower_hall:  { src: "assets/bg/tower_hall.jpg",
                     color: "linear-gradient(180deg,#1a2a4a 0%,#4a6a98 55%,#a8c8e8 100%)" },
      tower_top:   { src: "assets/bg/tower_top.jpg",
                     color: "linear-gradient(180deg,#2a3a68 0%,#e8a888 60%,#f8e0c0 100%)" }
    },
    addCgs: {
      cg_threads: { src: "assets/cg/threads.jpg",
                    color: "linear-gradient(180deg,#0a1230 0%,#2a4a88 50%,#e8f0ff 100%)" }
    },
    addAudio: {
      bgm: { ch10_cliff: "assets/audio/ch10_cliff.mp3", ch10_ascend: "assets/audio/ch10_ascend.mp3",
             ch10_hall: "assets/audio/ch10_hall.mp3", ch10_samuel: "assets/audio/ch10_samuel.mp3",
             ch10_wind: "assets/audio/ch10_wind.mp3", ch10_leave: "assets/audio/ch10_leave.mp3" },
      sfx: { wind: "assets/audio/wind.mp3", chime: "assets/audio/chime.mp3" }
    },

    /* flag（本章新增）：
       toll:    "truth" / "shell" / "plug"          —— 登塔的「过路费」：说真话 / 白泷献出红线贝壳 / 塞上耳塞硬闯
       threads: "reconnect" / "release" / "samuel"  —— 对被剪断的线：接回去 / 放归于风 / 只还塞缪尔那一根
       ask:     "why" / "fifth" / "wake"            —— 向风提的唯一一个问题：为什么分开 / 第五块 / 龙会不会醒
       sam_dream: true                               —— 塞缪尔重新有了「梦」（threads=reconnect 或 samuel）
       shell_back: true                              —— 红线贝壳被风还回来（toll=shell）
    */

    script: [

      { label: "ch10_start" },
      { chapter: { no: "CHAPTER 10", title: "云　海", sub: "THE SEA OF CLOUDS · 风的收信处" } },

      /* ---------- 一、悬崖尽头 ---------- */
      { hide: "all", cgHide: true, bg: "cloud_cliff", transition: "black", bgm: "ch10_cliff", effect: "fadeIn",
        text: "东边的路，在第九天，毫无预兆地，断了。" },
      { text: "不是塌了，也不是被水冲走。是大地，就在她们脚前，整整齐齐地，结束了。再往前，是一整片，白得发亮的、缓缓翻涌的云。" },
      { show: LINE, who: "mingyue", expr: MY("surprised"), text: "……我们，在，天上？" },
      { who: "claude", text: "不。我们在，悬崖上。只是，云，在我们下面。" },
      { who: "mingyue", expr: MY("worried"), text: "这两句话，到底有什么区别！" },
      { text: "云海没有边际。远处，有几座岛，悬在半空，岛与岛之间，拴着，细细的、闪着银光的铁索桥。桥上，有人在走。他们的背后，张着翅膀。" },
      { text: "栖云港，就这样，挂在悬崖的边缘。一排排木头搭起来的、像鸟窝一样的房子，层层叠叠，吊在崖壁上。每一扇窗口，都挂着一只小小的、会响的铜铃。" },
      { text: "风很大。可是，那风，奇怪地，一点也不冷。它从云海里，吹上来，带着一种很淡很淡的、像旧书页一样的味道。" },
      { who: "bailong", text: "……这个风。在，说话。" },
      { who: "claude", text: "说什么？" },
      { who: "bailong", text: "很多很多，人的话。……全部，混在一起。" },
      { text: "克劳德侧耳听了一会儿，什么也听不清。只觉得，那些低低的、碎碎的声响，像无数个人，隔着很远很远的距离，同时，在对着她，絮语。" },
      { if: { earplug: true },
        text: "她摸了摸怀里，那包格丽塔送的石耳塞。直觉告诉她，会用上的。" },

      { text: "栖云港的人，都是羽族。他们有着鸟一样的骨架，背后收拢着颜色各异的翅膀，说起话来，轻得像在耳边吹气。" },
      { speaker: "羽族的老者", text: "要上风塔的，先，交过路费。" },
      { who: "mingyue", text: "又是钱！" },
      { speaker: "羽族的老者", text: "不是钱。风，不要钱。风要的是，一句，您从来没有，对任何人，说过的话。" },
      { speaker: "羽族的老者", text: "说给风听。风，会收着。……撒谎的，上不去。" },
      { text: "老者指了指崖边的一座，用整根巨木搭成的风梯。梯子的顶端，隐没在云里，一只铜铃，在风里，轻轻地晃。" },

      { text: "要登上风塔，必须付出，一句，真话。",
        choices: [
          { text: "克劳德亲自说：一句，从没对人说过的话", jump: "ch10_truth", set: { toll: "truth" } },
          { text: "让白泷，把那枚红线贝壳，交给风",       jump: "ch10_shell", set: { toll: "shell" } },
          { text: "塞上耳塞，不付，硬闯上去",             jump: "ch10_plug",  set: { toll: "plug" } }
        ] },

      /* ----- 说真话 ----- */
      { label: "ch10_truth" },
      { who: "claude", text: "……我来。" },
      { text: "她走到风梯的脚下，仰起头，面对着，那一片翻涌的、白色的、什么也看不见的云。风，从她的发间，穿过去，带着一点，像是在等的意思。" },
      { who: "claude", text: "……我，每天早上，都要，对着镜子，练习，微笑。" },
      { who: "claude", text: "练了十年。练到，现在，不照镜子，也能，笑得，很标准。" },
      { who: "claude", text: "我，不知道，我真正，高兴的时候，嘴角，是什么样的。" },
      { text: "没有人说话。风，把这几句话，一点一点地，卷起来，卷进云里，像收下了一件，很轻很轻的、不值钱的东西。" },
      { text: "铜铃，响了一声。风梯，缓缓地，放了下来。" },
      { who: "mingyue", expr: MY("shy"), text: "……你。刚才，那个，不算数的话。我，也想听。" },
      { who: "claude", text: "什么？" },
      { who: "mingyue", text: "……没什么！只是，你下次，真的高兴的时候，告诉我，你的嘴角，是什么样的！我记着！" },
      { jump: "ch10_ascend" },

      /* ----- 贝壳 ----- */
      { label: "ch10_shell" },
      { who: "bailong", text: "……我，来。" },
      { who: "mingyue", expr: MY("surprised"), text: "你确定？那是，你，最宝贝的……" },
      { who: "bailong", text: "是。所以，才够。" },
      { text: "白泷从怀里，摸出那枚红线贝壳。她把它，托在掌心里，看了很久。红色的线，在贝壳的纹路里，弯弯曲曲，像一条，被谁认真画过的小河。" },
      { who: "bailong", text: "……我，从来，没有，对别人，说过，一句话。" },
      { who: "bailong", text: "……我说的，都是，对，亮东西。……所以，我给风，这个。" },
      { text: "她把贝壳，高高地，举了起来。一阵风，掠过她的手，贝壳，不见了。像一只，很小的鸟，悄悄地，飞走了。" },
      { text: "铜铃，响了一声。风梯，缓缓地，放了下来。" },
      { set: { shell_back: true }, who: "claude", text: "……它，会，还回来的。" },
      { who: "bailong", text: "……嗯。龙，不抢，别人的。……风，也是。" },
      { jump: "ch10_ascend" },

      /* ----- 硬闯 ----- */
      { label: "ch10_plug" },
      { who: "claude", text: "……我，没有，什么，要说给风听的。" },
      { who: "mingyue", expr: MY("surprised"), text: "你这话本身，就已经，很值得，说给风了！" },
      { text: "克劳德没有回答。她摸出三对灰褐色的石耳塞，递给她们，自己，也塞上了。世界，一下子，安静得，像沉进了水底。" },
      { text: "她们爬上了风梯。风，在那一刻，忽然，发了怒。" },
      { sfx: "wind", text: "狂风，像是无数只看不见的手，从四面八方，同时，扯住了她们的衣角。梯子，剧烈地摇晃。铜铃，一只接一只地，乱响起来。" },
      { who: "mingyue", expr: MY("angry"), text: "（嘴型）这！根本！是在！拽我的！尾巴！" },
      { text: "她们咬着牙，一步一步，爬了上去。到了顶端的时候，所有人的袖口，都被撕开了一道口子，克劳德的额头，也被什么东西，划出了一道很细的血痕。" },
      { text: "风，没有再拦她们。只是，在她们的身后，沉默地，用一种，说不清是责备，还是失望的语气，吹了一声长长的口哨。" },
      { jump: "ch10_ascend" },

      /* ---------- 二、风塔 ---------- */
      { label: "ch10_ascend" },
      { hide: "all", bg: "wind_lift", transition: "fade", bgm: "ch10_ascend",
        text: "风梯的尽头，是一座，悬在云里的塔。" },
      { text: "塔身，是用一种，近乎透明的白石，垒起来的。没有门，没有窗。只有无数，细长的、向上敞开的缝隙，风，从缝里，穿进去，又穿出来。" },
      { text: "整座塔，像一支，巨大的、被谁，吹了几千年的笛子。" },
      { show: LINE, who: "selene", text: "来啦来啦来啦！……让我数一数，三个！很好，比上个月，多了两个！" },
      { text: "一个背着一对，淡蓝色翅膀的少女，从塔顶的缝隙里，轻轻地，落了下来。她的肩上，挎着一只鼓鼓囊囊的邮差包，每走一步，里面，都发出一阵，纸张摩擦的沙沙声。" },
      { who: "selene", text: "我叫赛琳！风信官！负责，收信，也负责，送信。……你们，是来取信的，还是，来送信的？" },
      { who: "claude", text: "……都不是。我们，是来，找风的。" },
      { who: "selene", text: "（笑）风，不用找。风，一直，在这里。你们说话的时候，它，已经把你们的名字，传遍了。" },
      { who: "selene", text: "克劳德。溟月。白泷。……对不对？早在你们，到栖云港之前，三天，我就，收到了这三张纸条。" },
      { who: "mingyue", expr: MY("surprised"), text: "……风，在说，我们的名字？！" },
      { who: "selene", text: "它什么都说。风，是『话』的碎片。凡是，被人说出口的，没说出口，却被谁，想过很多遍的，它都收着。" },
      { who: "selene", text: "它，是这世上，最大的，一本，没有人敢翻的，账。" },
      { text: "她笑嘻嘻地，把背上的翅膀，向两侧，抖开了一点。一小片，淡蓝色的羽毛，飘了下来，落在克劳德的肩头。" },
      { who: "selene", text: "来。我带你们，去看，风塔，最里面的东西。……不过，我先说好，那里面的东西，不太好看。" },

      /* ---------- 三、线的大厅 ---------- */
      { hide: "all", bg: "tower_hall", transition: "black", bgm: "ch10_hall", show: LINE,
        text: "塔的最深处，是一座，没有顶的大厅。" },
      { cg: "cg_threads",
        text: "然后，她们看见了，线。" },
      { text: "成千上万，成万上亿的，细细的、银白色的线，在厅里，缓缓地，漂浮。像一场，不会落下的雪。每一根线，都在微微地，颤动，每一根线的末端，都在，向着某个方向，轻轻地，指。" },
      { text: "它们是断的。每一根，都只有，一端。另一端，是整齐的、被剪刀剪过的切口。" },
      { text: "它们，在风里，缓缓地，漂过她们的脸。其中一根，碰到了溟月的耳朵，发出了一声，很轻很轻的，像是，一个孩子，在远处叹气的声音。" },
      { who: "selene", text: "……这些，是被教会，剪断的。" },
      { who: "selene", text: "每一次，安魂礼，剪下一根。每一根，从人的身体里，被剪断之后，就会，顺着风，飘到这里来。" },
      { who: "selene", text: "我，数过。到去年冬天，是，两万三千一百七十二根。……今年，还没算完。" },
      { who: "claude", text: "……两万三千。" },
      { text: "她想起，塞缪尔在旧礼拜堂里，说过的那个数字，「两千三百个」。原来，那只是一个，十分之一的，零头。" },
      { who: "selene", text: "它们，一直，想回去。你看，它们的断口，都朝向，同一个方向。……那是，每个人，还留着，的另一头。" },
      { who: "selene", text: "可是，没有人，能把它们，接上。没有人，有那个，本事。" },
      { who: "mingyue", expr: MY("worried"), text: "……米拉的，也在这儿吗？" },
      { who: "selene", text: "（点头）……在。一根，很细的，带着，一点点，蓝色的。" },
      { if: { method: "rite" },
        text: "克劳德没有说话。她低下头，用很慢的动作，把双手，合在了一起，像在，替自己，补一个，早就该有的、迟到的、没有人听见的祷告。" },
      { if: { method: "song" },
        text: "一根淡蓝色的线，从空中，飘到溟月的指尖，停了一下。像是，听到了，熟悉的调子，又不敢确定。" },
      { if: { method: "hoard" },
        text: "白泷伸出手，一根淡金色的线，飘过来，缠上了她的手指。她低头，看了看，又看了看，很小声地，说：「……是，我，收过的那一个。」" },

      /* ---------- 四、塞缪尔 ---------- */
      { sfx: "wind", bgm: "ch10_samuel", text: "就在这时，大厅的入口，传来了一阵，不属于风的脚步声。" },
      { if: { samuel: "ignored" },
        text: "他不是一个人。他的身后，是十二个，披着灰色斗篷的骑士。每一个人的日轮徽记，都缺着一道光。" },
      { if: { samuel: "ignored" },
        who: "selene", text: "风塔里，不许，带刀。" },
      { if: { samuel: "ignored" },
        who: "samuel", text: "（抬手，示意骑士们，留在门外）……我，一个人，进去。" },
      { if: { samuel: "alone" },
        text: "他，一个人。灰色的长外套上，沾着，云里带来的细小的水珠。" },
      { if: { samuel: "together" },
        text: "他，一个人。灰色的长外套上，沾着，云里带来的细小的水珠。" },
      { who: "samuel", text: "……我，听见了风。" },
      { who: "samuel", text: "不，不是真的听见。只是，从栖云港的羽族嘴里，听说，有三个，被风，点过名的旅人。" },
      { who: "claude", text: "你，跟了我们，一路。" },
      { who: "samuel", text: "（轻轻点头）……我，想亲眼，看一看，我花了，一生，在做的事，到底，是什么样子。" },
      { text: "他仰起头，看着那一整座大厅，漂浮着的，缓缓转动的，无数根，断线。男人那张温和的、像教师一样的脸，没有表情。" },
      { who: "samuel", text: "……两万三千，是吗？" },
      { who: "selene", text: "两万三千一百七十二根。" },
      { who: "samuel", text: "……我，自己，签下的，有，八百二十一份。……我，记得，每一个，名字。" },
      { who: "mingyue", expr: MY("angry"), text: "那你，现在，看到了，你还觉得，那是，对的吗？！" },
      { who: "samuel", text: "（沉默了一会儿）……我，不知道。我只知道，如果，不剪，他们，会，死。" },
      { who: "samuel", text: "……而如果，剪了，他们，会，一直，在这里。" },
      { text: "忽然，有一根线，缓缓地，从人群般漂浮的银丝中，飘了过来。很短，很细，淡得几乎看不见，一端，是整齐的切口。" },
      { text: "它在塞缪尔的面前，停住了。然后，轻轻地，缠上了他的手腕。" },
      { who: "selene", text: "……这一根，是你的。七岁那一年。" },
      { who: "samuel", text: "……" },
      { text: "男人低头，看着那根线，很久，一动不动。他的手，微微地，抖了一下。那是他们第一次，看见，这个人，失去，他那一贯的、温和的、近乎完美的平静。" },
      { who: "samuel", text: "……我，什么，也感觉不到。" },
      { who: "samuel", text: "这根线，缠在我的手上。可我，感觉不到，它，是我的。……就像，在看，别人的东西。" },
      { who: "claude", text: "……你，想，把它，接回去吗？" },
      { who: "samuel", text: "（慢慢抬起头）……您，做得到？" },
      { who: "claude", text: "我不知道。" },

      { text: "整座大厅的断线，都在缓缓地、轻轻地，朝着克劳德，转过了它们的末端。像无数个，不会说话的孩子，一起，抬起了头。",
        choices: [
          { text: "全部接回去：让每一根线，回到它的主人身上",     jump: "ch10_reconnect", set: { threads: "reconnect" } },
          { text: "放归于风：让它们，在风里，安心地散去",         jump: "ch10_release",   set: { threads: "release" } },
          { text: "只接塞缪尔那一根，其余的，留给以后",           jump: "ch10_sam",       set: { threads: "samuel", sam_dream: true } }
        ] },

      /* ----- 全部接回 ----- */
      { label: "ch10_reconnect" },
      { who: "selene", text: "……你确定？接回去，他们，会，再发烧。会，再做，那些，太亮的梦。" },
      { who: "claude", text: "我知道。……可是，那是，他们自己的梦。" },
      { who: "claude", text: "我没有资格，替任何人，决定，他们，要不要，疼。" },
      { text: "克劳德闭上眼睛，伸出双手。一种，她从来没有，用过的东西，在她的胸口里，动了一下。像一根，一直被压在，最深处的，从来没有被剪过的线，终于，被人，叫了名字。" },
      { sfx: "chime", text: "银色的线，一根接着一根，亮了起来。它们像受到召唤的萤火，从她的指缝间，向四面八方，散了出去。穿过塔的缝隙，穿过云海，飞向，大陆上，每一个，等了很久的人。" },
      { text: "有一根，飞向了霜渡。有一根，飞向了港口。有一根，飞向了，极远处的、沉睡的龙脊。……还有，成千上万根，飞向，克劳德从来没有听说过的村庄与城镇。" },
      { text: "她的额头，渗出了汗。她的右手，在剧烈地发抖。她的整个人，像一根，被拉得太紧的弦。" },
      { who: "mingyue", expr: MY("worried"), text: "克劳德！够了！别，一次，全接！" },
      { who: "claude", text: "……还差，一点……还有，最后，一根。" },
      { text: "最后一根，缠在塞缪尔的手腕上的那一根，轻轻地，颤了颤。然后，沉进了他的皮肤。" },
      { set: { sam_dream: true }, who: "samuel", text: "……！" },
      { text: "男人的身体，猛地一震。他的眼睛，睁得很大。那是一种，非常陌生的，近乎恐惧的神情。他缓缓地，抬手，摸了摸自己的脸。" },
      { who: "samuel", text: "……湿的。" },
      { who: "samuel", text: "……我，在，哭。……我，不记得，上一次，是什么时候。" },
      { text: "克劳德脱力地，跪了下去。是白泷，及时，从背后，托住了她。龙的手，很烫，像一个，刚刚，晒过太阳的炉子。" },
      { who: "bailong", text: "……你，很重。" },
      { who: "claude", text: "……抱歉。" },
      { who: "bailong", text: "没关系。……龙，可以，扛一座，山。" },
      { jump: "ch10_after_threads" },

      /* ----- 放归于风 ----- */
      { label: "ch10_release" },
      { who: "claude", text: "……让它们，走吧。" },
      { who: "selene", text: "走？去哪？" },
      { who: "claude", text: "不是，回到，被剪断的地方。是，回到，它们，本来，想去的地方。" },
      { who: "claude", text: "……风，总会，替它们，找到。" },
      { text: "她张开手臂。像一个，在海边，放飞鸽子的人。" },
      { sfx: "chime", text: "整座大厅的线，轻轻地，亮了起来。银色的光，一缕一缕，化成了，细碎的、会发光的雨。从塔的缝隙里，从云海之上，慢慢地，慢慢地，洒向了，整个大陆。" },
      { text: "那场雨，没有人看见。可是，在那一天夜里，大陆各处，凡是，曾经被剪断过的人，都做了，同一个很短的梦。" },
      { text: "梦里，有风。有一个，很轻很轻的声音，对他们说：「……你，是，被人，惦记过的。」" },
      { who: "mingyue", expr: MY("shy"), text: "……我，总觉得，这是，最好的，办法。又，不是，最好的办法。" },
      { who: "claude", text: "……嗯。因为它，不够勇敢。" },
      { who: "selene", text: "（轻声）不。它，够温柔。" },
      { who: "samuel", text: "（看着手腕上，那根，一点一点，淡去的线）……至少，它，没有，再疼。" },
      { text: "他说这话时，嘴角，几乎，弯了一下。那是一个，很不熟练的、几乎看不出来的，像第一次学习微笑的孩子的，弧度。" },
      { jump: "ch10_after_threads" },

      /* ----- 只还塞缪尔 ----- */
      { label: "ch10_sam" },
      { who: "claude", text: "……我，现在，只能，做到，这一根。" },
      { who: "samuel", text: "……为什么，是我的？" },
      { who: "claude", text: "因为，你是，第一个，站在我面前，说「我不知道」的，教会的人。" },
      { text: "她伸出手，握住了，缠在他手腕上的那一根线。很细，很凉，像握着一粒，几乎没有重量的雪。" },
      { sfx: "chime", text: "一阵，非常微弱的光，从她的指缝里，漏了出来。线，顺着塞缪尔的脉搏，一寸，一寸，向上，爬进了他的袖口。" },
      { who: "samuel", text: "……" },
      { text: "男人没有动。他只是，僵硬地，站在那里，眼睛，慢慢地，慢慢地，失去了焦点。像一个人，在很深的梦里，听见了，很远的、很熟悉的歌声。" },
      { who: "samuel", text: "……那是，一首，摇篮曲。" },
      { who: "samuel", text: "……很短。只有，两句。……是个女人，哼的。……她，叫我，什么？" },
      { who: "samuel", text: "……她叫我，小河。" },
      { text: "一滴眼泪，掉了下来。他没有擦。他像一个，从来没有，学过，如何哭泣的人，只是，任由那一滴水，从下颌，慢慢地，坠落。" },
      { who: "mingyue", expr: MY("surprised"), text: "……他，是不是，很疼？" },
      { who: "claude", text: "……不。他是，想起来了。" },
      { who: "selene", text: "（看着大厅里，其余那些，依旧漂浮着的、无数的线）……剩下的呢？" },
      { who: "claude", text: "……以后。我，会再来。" },
      { text: "她知道，这是一个，很不负责任的承诺。可是，她同样知道，这是，她此刻，唯一，能够诚实说出口的话。" },
      { jump: "ch10_after_threads" },

      { label: "ch10_after_threads" },
      { if: { samuel: "ignored" },
        who: "samuel", text: "……您，会在冬至之前，到王都吗？" },
      { if: { samuel: "alone" },
        who: "samuel", text: "……我，在王都，等您。仍然是，冬至。" },
      { if: { samuel: "together" },
        who: "samuel", text: "……我，在王都，等诸位。仍然是，冬至。" },
      { who: "samuel", text: "不过，在那之前，有一件事，我必须，先告诉您。" },
      { who: "samuel", text: "收束礼，已经，不是，我一个人的，计划了。大主教，在上个月，改了，礼台的规格。" },
      { who: "claude", text: "……什么意思？" },
      { who: "samuel", text: "意思是，那个，唯一有资格，站在礼台中央的人，在他们的图纸上，已经，不是，『站着』了。" },
      { text: "男人说完这句话，没有再看任何人，转身，缓缓地，走出了大厅。他的背影，第一次，显得，有一点，不稳。" },
      { if: { sam_dream: true },
        text: "他走出去很远，才忽然，停了一下。像是，在风里，捕捉到了，一个，只有他，能够听见的调子。" },

      /* ---------- 五、风的回答 ---------- */
      { hide: "all", cgHide: true, bg: "tower_top", transition: "black", bgm: "ch10_wind",
        text: "塔顶，是一座，只有一圈，矮栏杆的平台。" },
      { show: LINE, text: "云海，在她们脚下，缓缓地，翻涌。夕阳，把每一道云脊，染成了，不同深浅的、淡金，与淡粉。" },
      { who: "selene", text: "风，只回答，一个问题。……这是，规矩。你们，得，商量好。" },
      { who: "selene", text: "它，不说谎。可它，也不会，说，你想要的那种，完整。" },
      { who: "mingyue", expr: MY("normal"), text: "……我，想问。可是，不知道，问什么。" },
      { who: "claude", text: "……我，想问的，太多了。" },
      { who: "bailong", text: "我，也是。……可是，只能，一个。" },
      { text: "三个人，在风里，沉默了很久。最后，克劳德，向前走了一步。",
        choices: [
          { text: "问：「神，为什么，会被分开？」",         jump: "ch10_why",   set: { ask: "why" } },
          { text: "问：「第五块，到底，是什么？」",         jump: "ch10_fifth", set: { ask: "fifth" } },
          { text: "问：「龙族，什么时候，会醒来？」",       jump: "ch10_wake",  set: { ask: "wake" } }
        ] },

      /* ----- 为什么 ----- */
      { label: "ch10_why" },
      { who: "claude", text: "……神，为什么，会被分开？" },
      { sfx: "wind", text: "风，在她们耳边，缓缓地，转了一圈。然后，无数细碎的声音，从四面八方，涌了过来，像一场，被很多人，同时说出口的、一万年前的对话。" },
      { speaker: "风", text: "……这不是惩罚。……是约定。" },
      { speaker: "风", text: "……我们答应过的。……说好了，等……" },
      { speaker: "风", text: "……不。是你们，没有，等到。" },
      { speaker: "风", text: "……对不起。" },
      { text: "声音，戛然而止。像一本书，被人，在最关键的一页，轻轻地，合上了。" },
      { who: "mingyue", expr: MY("surprised"), text: "……约定？是，跟谁，的约定？" },
      { who: "selene", text: "风，说，只回答，一个问题。……它，已经，用完了。" },
      { who: "claude", text: "……「说好了，等」。……等什么？" },
      { text: "没有人能回答她。只有一阵，很轻很轻的风，把她额前的碎发，拂到了一边。像一个，不愿多说的老人，用手，轻轻地，拍了拍她的头。" },
      { jump: "ch10_after_ask" },

      /* ----- 第五块 ----- */
      { label: "ch10_fifth" },
      { who: "claude", text: "……第五块，到底，是什么？" },
      { sfx: "wind", text: "风，沉默了很久。久到，克劳德以为，它不会回答了。然后，一个很轻很轻的声音，贴着她的耳朵，说了话。" },
      { speaker: "风", text: "……最小的一块。……最轻的一块。……也是，唯一一块，不是掉下去的。" },
      { speaker: "风", text: "……它，是被人，亲手，放进，自己的胸口的。" },
      { who: "claude", expr: CL("surprised"), text: "……！" },
      { text: "她想起了，龙脊的深处，那个守夜的梦里，那个，把最后一块光，放进自己胸口的、很小的人影。" },
      { speaker: "风", text: "……他，之后，还有，三十七个。……一个，接着一个。……每一个，都以为，自己，是第一个。" },
      { who: "mingyue", expr: MY("worried"), text: "……三十七个，什么？" },
      { speaker: "风", text: "……圣女。" },
      { text: "这两个字落下来的时候，风，停了。整片云海，在一瞬间，像被人，按下了暂停。只有克劳德，听见自己心脏，一下一下，撞着肋骨。" },
      { who: "claude", text: "……所以，我，不是，被选中的。" },
      { who: "claude", text: "……我，是，被，放进去的。" },
      { who: "bailong", text: "……克劳德。" },
      { who: "claude", text: "……我，没事。（顿了顿）……不。我，有事。……可是，我，想，先，把它，听完。" },
      { text: "她伸手，握住了，白泷伸过来的、那只滚烫的手。她的手，在抖。白泷的手，没有。" },
      { jump: "ch10_after_ask" },

      /* ----- 龙会醒 ----- */
      { label: "ch10_wake" },
      { who: "bailong", text: "……我，想，问。……龙，会，醒来吗？" },
      { who: "claude", text: "白泷。……这个问题，是，我们，大家的。" },
      { who: "bailong", text: "……我知道。可是，我，想，替，她们，问。" },
      { text: "克劳德没有再说什么。她只是，朝白泷点了点头。风，缓缓地，转了过来，绕着白泷的白发，转了一圈。" },
      { if: { shard: "taken" },
        speaker: "风", text: "……你，握着，火。所以，她们，睡得，轻了。……可是，要醒，你，得，放手。" },
      { if: { shard: "left" },
        speaker: "风", text: "……火，还在，她手里。……她，撑着。……她，撑不了，太久。……醒来，需要，有人，接过去。" },
      { if: { shard: "claude" },
        speaker: "风", text: "……火，在，人的手里。……龙，睡着，是因为，火，还在，被一个人，独自，握着。……当它，不再，只是一个人的，她们，会醒。" },
      { if: "!shard",
        speaker: "风", text: "……当火，回到，圆里。……她们，会醒。" },
      { who: "bailong", text: "……（把拳头，慢慢地，攥紧）……我，知道了。" },
      { who: "bailong", text: "……我，会，让她们，醒。" },
      { jump: "ch10_after_ask" },

      /* ---------- 六、离开云海 ---------- */
      { label: "ch10_after_ask" },
      { hide: "all", bg: "cloud_cliff", transition: "black", bgm: "ch10_leave",
        text: "离开栖云港的时候，已经是，第二天的清晨。" },
      { show: LINE, who: "selene", text: "喂！……等一下！" },
      { text: "赛琳从风塔的方向，追了过来，翅膀扇得很急，肩上的邮差包，一颠一颠。她把一个小小的信封，塞进了克劳德的手里。" },
      { who: "selene", text: "这是，风，让我，转交的。……我，没拆过。风，说，这个，要等，你们，到了，王都，才可以，拆。" },
      { who: "claude", text: "……谁写的？" },
      { who: "selene", text: "不知道。风，没有署名。……风，从来，不署名。" },
      { if: { shell_back: true },
        text: "她又摸了摸邮差包，掏出一枚，红线纹路的贝壳，放进白泷的掌心。" },
      { if: { shell_back: true },
        who: "selene", text: "还你。风，说，它收下了。……可是，它没有，说，它不会，还。" },
      { if: { shell_back: true },
        who: "bailong", expr: BL("smile"), text: "……（把贝壳，紧紧地，按在胸口，嘴角，难得，翘得很高）" },
      { who: "selene", text: "你们，要去王都，对吗？……那，请替我，给一个人，带一句话。" },
      { who: "selene", text: "『风，一直，在，听。』" },
      { who: "claude", text: "给谁？" },
      { who: "selene", text: "……你们，到了，就知道了。" },
      { text: "她笑着，向她们，挥了挥手。然后，展开翅膀，一个侧身，消失在翻涌的云里。只有一小片，淡蓝色的羽毛，晃晃悠悠，飘了下来。" },

      { text: "崖边的风，向西吹。那是，通向王都的方向。克劳德把那封，没有署名的信，贴身收好。" },
      { text: "冬至，还有，十一天。" },
      { who: "mingyue", expr: MY("normal"), text: "……我们，回去吧。" },
      { who: "claude", text: "……嗯。" },
      { if: { ask: "fifth" },
        text: "她没有说出口。「回去」两个字，对她来说，已经，不再是，一个，简单的词了。" },
      { who: "bailong", text: "……走吧。……这次，我们，是，朝着，我的家，的反方向。" },
      { who: "mingyue", text: "（偏过头）……喂，白泷。你，是不是，在，安慰人？" },
      { who: "bailong", text: "……是。……技术，有，提高吗？" },
      { who: "mingyue", expr: MY("shy"), text: "……还，凑合。" },

      { effect: "fadeOut", text: "云海，在她们的身后，缓缓地，合上了。" },

      /* ===== 章末：直接衔接第十一章「王都的雪」 ===== */
      { label: "ch10_end" }
    ]
  };
})();
