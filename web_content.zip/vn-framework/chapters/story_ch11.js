/* =====================================================
   story_ch11.js —— 第十一章「王都的雪」（回到王都、伊芙琳的信、地下档案馆、礼台的真相）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch10_end 之后（ch10 以 fadeOut 结尾，本章以 fadeIn 开场）。
   依赖：archbishop / king / gren / raymond / oli / samuel（story.js、第七章已定义）；
        flag：ask / sam_dream / shard / saved / decoy 等只用于对话回响，缺失走默认。
   本章以 fadeOut 黑屏结尾，第十二章（大教堂之夜）以 fadeIn 开场。
   ===================================================== */
window.STORY_CH11 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {
      valen:  { name: "瓦伦",   title: "大教堂老馆长",   color: "#c8b898" },
      evelyn: { name: "伊芙琳", title: "第三十七位圣女", color: "#e8d8c8" }
    },
    addBackgrounds: {
      capital_gate:   { src: "assets/bg/capital_gate.jpg",
                        color: "linear-gradient(180deg,#8a98a8 0%,#d8dce0 55%,#a8b0b8 100%)" },
      snow_street:    { src: "assets/bg/snow_street.jpg",
                        color: "linear-gradient(180deg,#14182a 0%,#3a3a50 55%,#d8a868 100%)" },
      inn_night:      { src: "assets/bg/inn_night.jpg",
                        color: "linear-gradient(180deg,#0e0c10 0%,#2a2220 55%,#6a4a30 100%)" },
      canal_under:    { src: "assets/bg/canal_under.jpg",
                        color: "linear-gradient(180deg,#04060a 0%,#142030 55%,#4a6a80 100%)" },
      cathedral_nave: { src: "assets/bg/cathedral_nave.jpg",
                        color: "linear-gradient(180deg,#14100c 0%,#4a3a28 55%,#d8c898 100%)" },
      throne_room:    { src: "assets/bg/throne_room.jpg",
                        color: "linear-gradient(180deg,#1a1410 0%,#4a3a20 55%,#c8a040 100%)" },
      archive:        { src: "assets/bg/archive.jpg",
                        color: "linear-gradient(180deg,#06060a 0%,#1e1c2a 55%,#5a4a38 100%)" },
      snow_dawn:      { src: "assets/bg/snow_dawn.jpg",
                        color: "linear-gradient(180deg,#4a5878 0%,#d8c8c0 60%,#f0ece8 100%)" }
    },
    addCgs: {
      cg_snow_capital: { src: "assets/cg/snow_capital.jpg",
                         color: "linear-gradient(180deg,#8a98b0 0%,#e8eef4 55%,#c8d0d8 100%)" },
      cg_cradle:       { src: "assets/cg/cradle.jpg",
                         color: "linear-gradient(180deg,#06060e 0%,#2a2a50 50%,#d8c070 100%)" }
    },
    addAudio: {
      bgm: { ch11_snow: "assets/audio/ch11_snow.mp3", ch11_festival: "assets/audio/ch11_festival.mp3",
             ch11_letter: "assets/audio/ch11_letter.mp3", ch11_canal: "assets/audio/ch11_canal.mp3",
             ch11_cathedral: "assets/audio/ch11_cathedral.mp3", ch11_king: "assets/audio/ch11_king.mp3",
             ch11_archive: "assets/audio/ch11_archive.mp3", ch11_dawn: "assets/audio/ch11_dawn.mp3" },
      sfx: { bellbig: "assets/audio/bellbig.mp3", step_snow: "assets/audio/step_snow.mp3", stamp: "assets/audio/stamp.mp3" }
    },

    /* flag（本章新增）：
       gift:   "flower" / "pin" / "coin"        —— 王都雪夜市集，用盘缠买给谁/买什么（只影响情感回响与结局尾声）
       entry2: "sneak" / "front" / "king"       —— 怎么见到老馆长：走地下水道 / 堂堂正正回大教堂 / 先去见国王
       knowsplan: true                          —— 知道了「收束礼＝把四块碎片装进第三十八个座位（圣女）」（所有线都会知道）
       plan:   "expose" / "feign" / "flee"      —— 对策：公开揭发 / 假意配合混进礼台 / 想逃（但封城，逃不掉）
       letter: true                             —— 读过伊芙琳的信
    */

    script: [

      { label: "ch11_start" },
      { chapter: { no: "CHAPTER 11", title: "王都的雪", sub: "THE SNOW OF THE CAPITAL · 冬至前三日" } },

      /* ---------- 一、城门 ---------- */
      { hide: "all", cgHide: true, bg: "capital_gate", transition: "black", bgm: "ch11_snow", effect: "fadeIn",
        text: "王都，在下雪。" },
      { cg: "cg_snow_capital",
        text: "那座城，在雪里，白得几乎，不像一座城。穹顶，尖塔，钟楼，镜厅，层层叠叠的金色屋脊，都被一层薄薄的雪，盖成了同一种，安静的颜色。" },
      { text: "克劳德在八岁的时候，被一辆封闭的马车，从这座城的东门，送进了大教堂。她在这座城里，住了十年。可是，她一次，也没有，从外面，看过它的全貌。" },
      { cgHide: true, show: LINE, who: "mingyue", expr: MY("surprised"), text: "……好大。比我见过的，所有港口，加起来，还要大。" },
      { who: "bailong", text: "……金色的，很多。" },
      { who: "claude", text: "（低声）……不要，一个一个，数。" },
      { text: "城门口，贴着新告示。「冬至日，大教堂，举行收束礼。凡我子民，皆可前往观礼。」下面，另有一行小字：「自本日起，王都封城，只进，不出。」" },
      { who: "mingyue", text: "……只进，不出？" },
      { who: "claude", text: "他们，不想让任何人，在冬至之前，离开。" },

      { text: "守城的队列，排出去半里。人群里，大多是风尘仆仆的朝圣者，手里提着灯。检查站的长桌后，坐着两个，十分眼熟的人。" },
      { who: "raymond", sfx: "stamp", text: "姓名？" },
      { who: "oli", text: "执事大人，这个，是我们，今天的第九百四十一个。" },
      { who: "raymond", text: "所以，要，更加仔细。姓名？" },
      { who: "claude", text: "……（低头）旅人。甲。" },
      { who: "raymond", text: "旅人甲。旁边这位？" },
      { who: "mingyue", text: "旅人乙！" },
      { who: "bailong", text: "旅人，丙。" },
      { who: "oli", text: "……执事大人，这个，白头发的，我觉得……" },
      { who: "raymond", text: "（盖章）北境人老得早。下一位。" },
      { if: { saved: true },
        text: "他盖章的时候，没有抬头。可是，印章落下的位置，是通行证的正中央。端端正正，一点也不歪。" },
      { who: "oli", text: "……执事大人。您的眼神，到底，是怎么好起来的？" },
      { who: "raymond", text: "是怎么，坏下去的，更值得研究。……下一位！" },

      /* ---------- 二、雪夜市集 ---------- */
      { hide: "all", bg: "snow_street", transition: "fade", bgm: "ch11_festival",
        text: "天黑之后，整座城，亮了起来。" },
      { show: LINE, text: "雪夜里的市集，沿着大街，一路摆开。烤栗子的香气，热苹果酒的白雾，铜匠敲着小锤叮叮当当，孩子们追着一只会吐泡泡的木鸟，满街乱跑。" },
      { text: "这是冬至前，王都最热闹的三天。所有人都在忙着，欢庆一个，他们以为会带来，一整年好运的仪式。" },
      { who: "mingyue", expr: MY("happy"), text: "好香！……克劳德，克劳德！那边，有人，在卖糖栗子！" },
      { who: "claude", text: "……你，已经吃了，四串了。" },
      { who: "mingyue", text: "第五串，是，替你，吃的！" },
      { text: "克劳德没有再争辩。她只是，从怀里，摸出了，一直省着没有动过的、最后那一小袋盘缠。那是，一路上，她们讨价还价、洗碗、搬货、凑出来的，全部家当。" },
      { who: "claude", text: "……最后一个，自由的晚上。我们，花掉它。" },
      { who: "mingyue", expr: MY("surprised"), text: "……！你，是认真的？！" },
      { who: "claude", text: "我这辈子，还没有，自己，花过钱。" },

      { text: "她站在三个摊位之间，一时，竟然，不知道，该走向哪一个。",
        choices: [
          { text: "买一朵橙色的发饰，补上丢掉的那一朵", jump: "ch11_g_flower", set: { gift: "flower" } },
          { text: "给溟月，买一支，新的发簪",           jump: "ch11_g_pin",    set: { gift: "pin" } },
          { text: "给白泷，换一串，真的金币",           jump: "ch11_g_coin",   set: { gift: "coin" } }
        ] },

      { label: "ch11_g_flower" },
      { text: "那是一个卖旧饰品的老太太。她的摊位上，摆着一朵，用橙色丝绢，一片一片，缝成的、小小的花。" },
      { who: "claude", text: "……这个，多少钱？" },
      { who: "mingyue", expr: MY("angry"), text: "太贵！这个，值，三个铜板！我来砍！" },
      { text: "溟月撸起袖子，挤到摊位前面。三分钟之后，老太太，笑着，把花，用最低的价钱，递给了她。" },
      { who: "mingyue", expr: MY("shy"), text: "……低头。" },
      { who: "claude", text: "……什么？" },
      { who: "mingyue", text: "我说，低头！我，帮你，别上！" },
      { if: { decoy: true },
        text: "克劳德低下头。一根细细的发夹，从她的耳后，别住了那朵橙色的花。丢掉的那一朵，现在，有了，替身。" },
      { if: "!decoy",
        text: "克劳德低下头。一根细细的发夹，从她的耳后，别住了那朵橙色的花。像，她第一次，被谁，别上了一枚，不属于任何仪式的徽章。" },
      { who: "mingyue", text: "……好看。……不许，告诉别人，是我，挑的。" },
      { jump: "ch11_gift_end" },

      { label: "ch11_g_pin" },
      { text: "是一个，卖发簪的小摊。木盘里，躺着许多，银的，铜的，缀着小颗玻璃珠的，细细的簪子。" },
      { who: "claude", text: "……溟月。选一支。" },
      { who: "mingyue", expr: MY("surprised"), text: "……我？！我，为什么？" },
      { who: "claude", text: "因为，你，一路上，替我，付了，太多，你自己，都没有，数过的东西。" },
      { text: "溟月的耳廓，红得，快要滴出血来。她站在摊前，半天不敢伸手，最后，拿起一支，素素的、什么花样也没有的，银色的簪子。" },
      { who: "mingyue", expr: MY("shy"), text: "……这支。……够了。……不要，太亮的。" },
      { who: "bailong", text: "……我，帮你，收着。" },
      { who: "mingyue", expr: MY("angry"), text: "你，才不许，收！这支，是，我自己的！" },
      { jump: "ch11_gift_end" },

      { label: "ch11_g_coin" },
      { text: "那是一家，兑换行。橱窗里，挂着一串，用红线穿起来的、新铸的金币。在雪夜里，亮得，像一串，凝固的小太阳。" },
      { who: "bailong", text: "……（一动不动）" },
      { who: "claude", text: "白泷。……那个，你想要吗？" },
      { who: "bailong", text: "……（点头，点得，很慢）" },
      { who: "claude", text: "我，买。……但，这一次，不是，你，拿。是，我，给你。" },
      { who: "bailong", text: "……给？" },
      { who: "claude", text: "对。……给你的，才是，你的。" },
      { text: "金币，一枚一枚，落进白泷的掌心。她低着头，看了很久。然后，用一种，非常笨拙的，近乎郑重的动作，把它们，慢慢地，贴在了胸口。" },
      { who: "bailong", expr: BL("smile"), text: "……谢谢。……这是，我，第一个，被，给的，金子。" },
      { who: "mingyue", expr: MY("normal"), text: "……你，眼睛，红了。" },
      { who: "bailong", text: "是，雪。" },
      { jump: "ch11_gift_end" },

      { label: "ch11_gift_end" },
      { text: "她们在雪里，慢慢地，走了很久。街上，有人在唱歌，有人在跳舞。有一个卖糖人的老头，把一只，龙形的糖，塞给了白泷。" },
      { who: "bailong", text: "……（盯着糖龙，看了半天）……不吃。……这是，亲戚。" },
      { who: "mingyue", text: "吃！我帮你，吃！" },
      { text: "这是她们，一路走来，最安静，也最明亮的一个夜晚。后来，在很多个，没有雪的夜里，克劳德，都会想起这条街。" },

      /* ---------- 三、风的信 ---------- */
      { hide: "all", bg: "inn_night", transition: "black", bgm: "ch11_letter",
        text: "旅店的房间，在顶楼。窗外，雪，一刻不停地，落着。" },
      { show: LINE, text: "克劳德把那封，没有署名的信，从怀里，取了出来。赛琳说过，要到了王都，才可以拆。" },
      { text: "信封，是很旧的。边角，被风，吹得发毛。封口，只有一小滴，已经变成淡灰色的蜡。" },
      { who: "claude", text: "……我，拆了。" },
      { text: "信纸展开的那一瞬，她闻到了一种味道。很淡，像旧书页，像，十年前，礼拜堂里，被擦得发亮的地板。" },
      { set: { letter: true }, who: "evelyn", text: "给，第三十八位。" },
      { who: "evelyn", text: "如果，这封信，到了你的手里，说明风，替我，把它送到了。" },
      { who: "evelyn", text: "我是第三十七位，他们叫我，伊芙琳。我不知道，你是几岁，被带进去的。我是九岁。" },
      { who: "evelyn", text: "他们对我说，这是，荣耀。对你，大概，也这么说。" },
      { who: "evelyn", text: "我想告诉你一件事。……礼台下面，不是地基。是一张，摇篮。" },
      { who: "evelyn", text: "他们在准备，一场，比任何一次，都大的仪式。我没有等到。我猜，你，会等到。" },
      { who: "evelyn", text: "我逃过一次。我逃到了，云海的边上，把这封信，交给了风。然后，我，又回去了。" },
      { who: "evelyn", text: "因为我不回去，他们，就会，带走，下一个孩子。" },
      { who: "evelyn", text: "……我现在，最想对你说的，只有一句。" },
      { who: "evelyn", text: "不要，因为责任，回去。如果你回去，请，为你自己，回去。" },
      { who: "evelyn", text: "大教堂的地下，有一座，不在图纸上的档案馆。馆长，叫瓦伦。你，对他说：『风，一直，在听。』他，就会，替我，把剩下的话，说完。" },
      { who: "evelyn", text: "——你的，伊芙琳。" },
      { text: "信，到这里，就结束了。纸的最下面，有一小块，被水渍晕开的痕迹。像是，写信的人，在落款之后，又等了很久，才，放下笔。" },
      { who: "mingyue", expr: MY("worried"), text: "……第三十七位。" },
      { who: "claude", text: "……嗯。" },
      { if: { ask: "fifth" },
        who: "claude", text: "风，对我说过的，是真的。我不是，第一个。……她，也不是。" },
      { if: "!ask",
        who: "claude", text: "我一直，以为，圣女，是教会，从许多孩子里，选出来的。……原来，不是。" },
      { who: "bailong", text: "……她，等了很久，才，放下笔。" },
      { who: "claude", text: "……你，怎么知道？" },
      { who: "bailong", text: "水渍。……是，眼泪。……很咸，很旧的，眼泪。" },
      { text: "窗外的雪，下得很静。克劳德把信，对折起来，贴着胸口，放进了圣典的最后一页。那一页，已经没有，任何字了。" },

      /* ---------- 四、怎么见到瓦伦 ---------- */
      { text: "大教堂的地下，有一座，不在图纸上的档案馆。如何，进去，需要，选一条路。",
        choices: [
          { text: "夜里，走地下水道，悄悄潜入",              jump: "ch11_sneak", set: { entry2: "sneak" } },
          { text: "穿上圣女的白袍，堂堂正正，走进大教堂",    jump: "ch11_front", set: { entry2: "front" } },
          { text: "先去见国王奥古斯特，借他的手进去",         jump: "ch11_king",  set: { entry2: "king" } }
        ] },

      /* ----- A. 水道 ----- */
      { label: "ch11_sneak" },
      { hide: "all", bg: "canal_under", transition: "black", bgm: "ch11_canal",
        text: "王都的地下，有一整座，被人遗忘的城。" },
      { show: LINE, text: "那是一条条，结了冰的旧水道。头顶，是石拱。脚下，是薄薄的冰壳。冰壳下面，水，缓缓地流，发出一种，很细很细的、像在翻书的声音。" },
      { who: "mingyue", expr: MY("normal"), text: "……往左。" },
      { who: "claude", text: "你确定？" },
      { who: "mingyue", text: "水，是，朝左边，流的。……而大教堂，在，所有水的，下游。" },
      { text: "溟月走在最前面。她的尾尖，一路，轻轻地，点着冰面。每一次点下去，她，就知道，前面，有没有路。" },
      { who: "mingyue", text: "……我，在海边长大，我知道，所有的水，都想回家。……只要顺着它，就不会迷路。" },
      { who: "bailong", text: "……有人。" },
      { text: "前方，一盏提灯，在拐角处，摇晃。两名披着灰披风的巡逻者，沿着水道，走了过来。他们的日轮，缺着一道光。" },
      { who: "claude", text: "（压低声音）……躲进，那边的，拱门。" },
      { text: "三个人，贴着潮湿的石壁，一动不动。巡逻者的灯光，从她们的鼻尖前，扫了过去。其中一个，打了个哈欠，嘟囔了一句：「冬至一过，我就，回家，种白菜。」" },
      { who: "mingyue", expr: MY("shy"), text: "（用口型）……他，还怪，可爱的。" },
      { who: "claude", text: "（用口型）……别，同情，敌人。" },
      { text: "穿过一道，半塌的栅栏，水道的尽头，是一扇，被苔藓封住的、小小的铁门。门楣上，刻着一个，已经几乎看不见的符号：一只，竖着耳朵的，鸟。" },
      { who: "claude", text: "（深吸一口气，轻声）……风，一直，在听。" },
      { text: "铁门，没有任何声音，向里，缓缓地，开了。" },
      { jump: "ch11_archive" },

      /* ----- B. 正门 ----- */
      { label: "ch11_front" },
      { hide: "all", bg: "cathedral_nave", transition: "black", bgm: "ch11_cathedral",
        text: "她穿着，那件被收在包袱底的、洗得发白的圣女白袍，一个人，走上了大教堂的台阶。" },
      { text: "守门的执事，看见她的瞬间，手里的钥匙，掉在了石板上。然后，整座大教堂，在她身后，一扇一扇的门，开了。" },
      { text: "钟，响了。不是报时的钟。是只在「圣女归来」，才会敲的钟。十三响。每一声，都像，一个人，在用力，攥着一个，很大的拳头。" },
      { show: { id: "claude", pos: 50, expr: "normal" }, text: "大殿的尽头，有一个人，在等她。白色的长袍，苍白的须发，背脊，笔直得，像一根，插进大地的权杖。" },
      { who: "archbishop", text: "……你，回来了。" },
      { who: "claude", text: "……是的，大人。" },
      { who: "archbishop", text: "你瘦了。……头发，也乱了。……有人，没有照顾你。" },
      { who: "claude", text: "……不。有人，照顾得，很好。只是，方式，不太一样。" },
      { text: "大主教没有说话。他慢慢地，走下台阶，在她的面前，站住了。这个，在她的整个童年里，高得像一座山的老人，此刻，比她，只高了，半个头。" },
      { who: "archbishop", text: "你，读了，圣典的，下面一层。" },
      { who: "claude", text: "……您，知道？" },
      { who: "archbishop", text: "那一层字，是我，亲手，用药水，盖上去的。……三十年前。" },
      { who: "archbishop", text: "我，一直在等，哪一位圣女，会，先看见它。……我，以为，会是，第三十七位。……她，没有。" },
      { who: "archbishop", text: "……是你。" },
      { who: "claude", text: "（沉默）……您，为什么，不骂我？" },
      { who: "archbishop", text: "（极轻地，笑了一下）我，为什么，要骂，一个，终于，学会，读书的孩子？" },
      { text: "这是她十年里，第一次，在这位老人的脸上，看见，类似于，温和的东西。她忽然意识到，这，比任何一次，严厉的斥责，都更，可怕。" },
      { who: "archbishop", text: "去吧。……我，不拦你。……地下，有一座，你想看的房间。……看完，再来，告诉我，你的答案。" },
      { who: "archbishop", text: "只是，你的，同伴，要留在，外面。……这是，我，唯一的条件。" },
      { who: "claude", text: "……我，会，转告她们。" },
      { text: "大主教转身，向大殿深处，走了回去。他的白袍，拖在地上，没有一点，声音。像一个人，在雪里，走了很多年，早已忘记了，怎么，留下脚印。" },
      { who: "claude", text: "（低声）……他，为什么，肯，让我，去看？" },
      { who: "claude", text: "……因为，他，认为，我，看完，也不会，改变。" },
      { jump: "ch11_archive" },

      /* ----- C. 国王 ----- */
      { label: "ch11_king" },
      { hide: "all", bg: "throne_room", transition: "black", bgm: "ch11_king",
        text: "王座厅里，只点着，一盏灯。" },
      { show: LINE, text: "那座，在盟约之夜，被三千盏烛火，照得，金碧辉煌的大厅，此刻，只剩下一片，被雪光，映得发白的空旷。" },
      { text: "王座上，坐着一个，头发，花白了一半的男人。他没有戴冠。手里，握着一只，已经凉透了的酒杯。" },
      { who: "gren", text: "……（单膝跪地）圣女大人。臣，在盟约之夜，没有，保护好您。" },
      { who: "claude", text: "格伦团长。……请起来。那一晚，不是，任何人的错。" },
      { who: "gren", text: "……陛下，在等您。他，已经，等了，七天。" },
      { who: "king", text: "（没有抬头）……是克劳德吗？……过来。我，看不太清了。" },
      { text: "她走上前去。国王终于抬起头。那是一张，疲惫得，几乎有些，陌生的脸。在盟约之夜，高喊着「为了复兴」的男人，此刻，只是，一个很累的，中年人。" },
      { who: "king", text: "……那天晚上。我，喊了，那句话。" },
      { who: "king", text: "我，一直，在想，如果，我没有喊，会不会，你，就，不会，被龙，带走。" },
      { who: "claude", text: "……陛下。那条龙，不是，来抓我的。" },
      { who: "king", text: "（苦笑）……我知道。我，听说了。……一条，把你，当成，金子的，龙。" },
      { who: "king", text: "（顿了顿）……我，有一件事，要告诉你。……《复兴盟约》，不是，我的主意。" },
      { who: "king", text: "是大主教，带来的。……他说，这是，王国，唯一，能活下去的办法。我，没有，问，代价。" },
      { who: "king", text: "……后来，我，问了。他，说，是，圣女。" },
      { who: "claude", text: "……您，知道，那个『代价』，是我。" },
      { who: "king", text: "……我，不敢，知道。" },
      { text: "男人把手里的酒杯，缓缓放下，在扶手上，磕出一声，很轻的响。他伸手，从怀里，取出了，一枚，用旧了的、刻着王室纹章的小铜钥匙。" },
      { who: "king", text: "……这是，王室书库的，钥匙。书库的地下，通向，大教堂的，档案馆。我父亲，给过我。他说，只有，国家，快要，被毁掉的时候，才能用。" },
      { who: "king", text: "……我想，今天，就是，那一天。" },
      { who: "gren", text: "……陛下。" },
      { who: "king", text: "格伦。……你，送圣女，下去。……然后，不要，回头。" },
      { who: "gren", text: "……（深深一鞠躬）臣，遵命。" },
      { text: "钥匙，落进克劳德的掌心。冰凉，沉重，像一块，被人攥了二十年，才终于，松开的石头。" },
      { who: "king", text: "……（轻声）对不起，克劳德。……我，是，一个，非常糟糕的，国王。" },
      { who: "claude", text: "……陛下。您，今晚，做对了，一件事。" },
      { jump: "ch11_archive" },

      /* ---------- 五、档案馆 ---------- */
      { label: "ch11_archive" },
      { hide: "all", bg: "archive", transition: "black", bgm: "ch11_archive",
        text: "地下，有一座，比大教堂，还要古老的房间。" },
      { show: LINE, text: "没有窗，没有风。只有，一排一排，高得看不到顶的书架，在昏黄的灯光里，沉默地，立着。每一格书架，都挂着一只，小小的、写着名字的铜牌。" },
      { text: "一个，满头白发的老人，坐在最深处的长桌前。他的面前，摊着一本，边缘已经磨得，发白的册子。他没有抬头。" },
      { if: { entry2: "front" },
        text: "大主教的条件，克劳德只转告了一半。她们没有留在外面。只是，没有一个执事，敢拦住，一个，刚刚，被十三响钟声，迎进来的人，和她身后，那两个，眼神，不太友善的同伴。" },
      { who: "valen", text: "……风，一直，在，听。" },
      { text: "克劳德怔了一下。她还没有开口，老人，就，已经说出了那句，她准备好，要说的话。" },
      { who: "valen", text: "……我，等了，十年。……伊芙琳，说，会有人，来。" },
      { who: "valen", text: "她说，会是，一个，不太会笑的孩子。……坐吧，克劳德。……你，比我想象的，更像她。" },
      { who: "claude", text: "……您，认识，她？" },
      { who: "valen", text: "我，教她，识字。……从她，九岁，进来的那一天。" },
      { text: "他把那本，磨得发白的册子，缓缓地，推了过来。册页的第一行，写着一个，名字：「第一位」。后面，是一页一页的，各自不同的笔迹。" },
      { who: "valen", text: "三十七位。每一位，一页。出生，入教，何时，开始，听见，神的声音。……何时，『归于圆心』。" },
      { who: "claude", text: "……『归于圆心』。" },
      { who: "valen", text: "教会的说法。……其实，是，死。" },
      { text: "她翻开册子。第一页，是一个，用古老字体写的名字。最后一页，是，伊芙琳。她的名字下面，用很细的笔，写着一句，不是官方措辞的、很小的话：" },
      { text: "「想看海。」" },
      { who: "mingyue", expr: MY("worried"), text: "……（别过头去，用袖子，擦了一下眼睛）" },

      { who: "valen", text: "……现在，我要给你，看，另外一样东西。" },
      { cg: "cg_cradle", text: "老人拉开了，长桌后面的，一道，厚重的帷幕。墙上，钉着一张，巨大的、边缘已经发黄的图纸。" },
      { text: "最外圈，是四个同心的圆，每一个圆里，写着一个字：海，山，火，风。最中央，是一个，小小的、没有任何字的圆。旁边，用另一种，新鲜得多的墨水，写着两个字。「座」，和「待放」。" },
      { who: "valen", text: "这是，『收束礼』，真正的图纸。" },
      { who: "valen", text: "四块碎片，已经，醒了。教会，用缄石，剪断了，各地的线，把四块碎片，一块一块，『安静』下来。" },
      { who: "valen", text: "冬至那天，四块，同时，被召到礼台。……放进，中间，那个座位里。" },
      { who: "claude", text: "……座位，是，什么？" },
      { text: "老人没有回答。他只是，看着她。看了很久，很久。像一个，在看一个，自己亲手，养大的孩子，即将被推向，一个，没有回头路的，台阶的人。" },
      { who: "valen", text: "……是你。" },
      { who: "claude", text: "…………" },
      { who: "valen", text: "第五块，在你的胸口。四块，放进你的胸口。……『圆』，就，重新，圆了。" },
      { who: "valen", text: "只是，那个『圆心』，会是，一个，人。……一个，替所有人，做梦的人。" },
      { who: "valen", text: "大主教，管它，叫，『一个人，替所有人，疼』。……他认为，这是，最慈悲的，办法。" },
      { set: { knowsplan: true }, text: "烛火，在风里，晃了一下。克劳德觉得，整座档案馆，都在远离她。像一个人，站在悬崖边上，看着自己的影子，被慢慢地，推下去。" },
      { if: { ask: "fifth" },
        who: "claude", text: "……所以，风说的，三十七个，是，这个。" },
      { if: { cutknown: true },
        who: "claude", text: "……所以，教会，剪线，不是，为了，让人们，平安。……是，为了，把所有的神，都，收拢到，一个人身上。" },
      { who: "valen", text: "不全是。……塞缪尔，那个孩子，一直，真心，相信，剪线，是，为了救人。他，是，被蒙在，鼓里的，最后一个。" },
      { who: "valen", text: "他，在三周前，当面，质疑过，礼台的规格。现在，他，被派去，看守，地牢。" },
      { who: "mingyue", expr: MY("angry"), text: "……所以，你们，要，把，克劳德，当，一把，锁！" },
      { who: "valen", text: "（缓缓点头）……是的，小姐。……对不起。" },
      { text: "没有人说话。烛火，一点一点地，缩短。克劳德把手，按在那张，写着「座」字的图纸上，指尖，一点一点地，发冷。" },

      { text: "还有，三天。她必须，决定，要怎么办。",
        choices: [
          { text: "公开揭发：冬至那天，当着所有人，讲出来",       jump: "ch11_expose", set: { plan: "expose" } },
          { text: "假意配合：混进礼台，从内部，破坏它",           jump: "ch11_feign",  set: { plan: "feign" } },
          { text: "带着她们，逃出王都",                           jump: "ch11_flee",   set: { plan: "flee" } }
        ] },

      { label: "ch11_expose" },
      { who: "claude", text: "……我，要，让所有人，都知道。" },
      { who: "valen", text: "……您，确定？冬至那一天，会有三万人，在广场上。他们，不一定，会，信您。" },
      { who: "claude", text: "我知道。……可是，如果，没有人，说，他们，永远，没有，机会，选择，信不信。" },
      { who: "valen", text: "（缓缓站起）……我，会，替您，把册子，抄一份。……您，带着。" },
      { who: "mingyue", expr: MY("normal"), text: "我，去，找，港口，那些，会喊的人！" },
      { who: "bailong", text: "……我，会，让他们，抬头。" },
      { jump: "ch11_after_plan" },

      { label: "ch11_feign" },
      { who: "claude", text: "……我，要，回去。" },
      { who: "mingyue", expr: MY("surprised"), text: "什么？！" },
      { who: "claude", text: "……假装，我，认命了。……站到，礼台，上去。" },
      { who: "claude", text: "只有，站在，那个位置上，我，才，有机会，把，那个，『座』，从里面，拆掉。" },
      { who: "valen", text: "……这是，极其，危险的，办法。伊芙琳，也想过。……她，没有，来得及。" },
      { who: "bailong", text: "……我，在，台下。……你，一回头，就能看见。" },
      { jump: "ch11_after_plan" },

      { label: "ch11_flee" },
      { who: "claude", text: "……我们，走吧。……现在，就走。" },
      { who: "mingyue", expr: MY("surprised"), text: "……走？" },
      { who: "claude", text: "回海边。……回龙脊。……去哪儿，都行。……只要，不是，这里。" },
      { text: "老人没有劝她。他只是，缓缓地，点了点头，把一张，已经，画好的城防草图，递了过来。" },
      { who: "valen", text: "……北门，今晚，守卫，最少。……去吧。" },
      { hide: "all", bg: "capital_gate", transition: "black", bgm: "ch11_snow",
        text: "凌晨，她们到了，北门。" },
      { show: LINE, text: "雪，很大。城门，紧闭着。门前，立着一队，披着铠甲的骑士，整整齐齐，像一排，沉默的石像。为首的那个，是格伦。" },
      { who: "gren", text: "……圣女大人。" },
      { who: "claude", text: "……团长。请，让开。" },
      { who: "gren", text: "……封城令，是，国王陛下，亲手签的。……臣，不能，违抗。" },
      { who: "claude", text: "……国王，在三天前，还，给了我，一把，钥匙。" },
      { who: "gren", text: "（低声）……所以，陛下，才，签了，这道令。……他，想让您，留在，王都。" },
      { who: "claude", text: "……为什么？" },
      { who: "gren", text: "……因为，他，终于，想起来，自己是，一个，国王。……国王，不能，眼睁睁看着，自己的，子民，在冬至那天，被，欺骗。" },
      { who: "gren", text: "……所以，请您，回去。……这座城，需要，一个，能站出来，说话的人。" },
      { text: "克劳德站在雪里，很久。她看着那扇，紧闭的城门，忽然，笑了一下。那是一个，很轻很轻的、真正的笑。" },
      { who: "claude", text: "……好。……我回去。" },
      { who: "mingyue", expr: MY("surprised"), text: "……你，不逃了？" },
      { who: "claude", text: "……跑不掉，也好。……我本来，也，不想，跑。……我只是，想，听，你们，说，一句：『好』。" },
      { who: "mingyue", expr: MY("shy"), text: "……好！好好好！……你，真是，一个，麻烦的，人！" },
      { who: "bailong", text: "……好。" },
      { jump: "ch11_after_plan" },

      /* ---------- 六、黎明前 ---------- */
      { label: "ch11_after_plan" },
      { hide: "all", cgHide: true, bg: "snow_dawn", transition: "black", bgm: "ch11_dawn",
        text: "雪，在天亮之前，停了。" },
      { show: LINE, text: "整座王都，像一座，被大雪盖住了所有声响的巨大的钟。只有，大教堂顶上的那口钟，隔着很远，被风，一下一下，推着，发出一声很低的、迟缓的回响。" },
      { who: "mingyue", expr: MY("normal"), text: "……还有，两天。" },
      { who: "claude", text: "嗯。" },
      { who: "mingyue", text: "……克劳德。……你，怕吗？" },
      { text: "克劳德想了一会儿。她没有立刻回答。只是，把手，伸进怀里，摸了摸，那封被她，对折得，很整齐的信。" },
      { who: "claude", text: "……怕。" },
      { who: "claude", text: "可是，这一次，我，不是，一个人。" },

      { if: { gift: "flower" },
        text: "她发间的那朵，橙色的小花，在雪后的第一缕光里，亮了一下。像一枚，很小很小的、不属于任何仪式的徽章。" },
      { if: { gift: "pin" },
        text: "溟月的发间，那支，素素的银簪，在晨光里，静静地，亮着。她，时不时，抬手，摸一下。每一次，都假装，是在整理头发。" },
      { if: { gift: "coin" },
        text: "白泷的怀里，那一串，用红线穿起来的金币，在她走动的时候，叮叮当当，响得很轻。她把它们，捂得，很紧，像捂着，一小团，不肯熄灭的火。" },

      { who: "bailong", text: "……我，不数。……可是，这座城，有，很多，亮的东西。……我，一个，也不拿。" },
      { who: "claude", text: "……为什么？" },
      { who: "bailong", text: "……因为，它们，都，有主人。……我，要，等，他们，自己，来认。" },
      { text: "远处的钟楼，又响了一声。冬至，已经，不远了。" },

      { effect: "fadeOut", text: "雪后的王都，沉默地，等着，那个，所有人，都以为是，节日的日子。" },

      /* ===== 章末：直接衔接第十二章「大教堂之夜」 ===== */
      { label: "ch11_end" }
    ]
  };
})();
