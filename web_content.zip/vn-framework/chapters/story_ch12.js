/* =====================================================
   story_ch12.js —— 第十二章「大教堂之夜」（冬至前夜、四块碎片被召来、大主教的最后一次邀请）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch11_end 之后（ch11 以 fadeOut 结尾，本章以 fadeIn 开场）。
   依赖：archbishop / king / gren / samuel 角色；flag：plan / entry2 / shard / threads / sam_dream / samuel / method / kanshi /
        mountain / ask（只用于分流与回响，缺失走默认）。
   本章以 fadeOut 黑屏结尾，第十三章（圆）以 fadeIn 开场——终局抉择在第十三章。
   ===================================================== */
window.STORY_CH12 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {},
    addBackgrounds: {
      cathedral_square: { src: "assets/bg/cathedral_square.jpg",
                          color: "linear-gradient(180deg,#0c1020 0%,#2a3050 55%,#d8c898 100%)" },
      dungeon:          { src: "assets/bg/dungeon.jpg",
                          color: "linear-gradient(180deg,#040406 0%,#1a1a22 55%,#3a3a40 100%)" },
      platform:         { src: "assets/bg/platform.jpg",
                          color: "linear-gradient(180deg,#06060e 0%,#1a1a38 55%,#e8d898 100%)" }
    },
    addCgs: {
      cg_four_lights: { src: "assets/cg/four_lights.jpg",
                        color: "linear-gradient(180deg,#05060f 0%,#14183a 50%,#f0e0a0 100%)" }
    },
    addAudio: {
      bgm: { ch12_square: "assets/audio/ch12_square.mp3", ch12_dungeon: "assets/audio/ch12_dungeon.mp3",
             ch12_vigil: "assets/audio/ch12_vigil.mp3", ch12_platform: "assets/audio/ch12_platform.mp3",
             ch12_arrival: "assets/audio/ch12_arrival.mp3" },
      sfx: { chain: "assets/audio/chain.mp3", bell13: "assets/audio/bell13.mp3", surge: "assets/audio/surge.mp3" }
    },

    /* flag（本章新增）：
       jail:  "freed" / "skipped"            —— 是否先去地牢放出塞缪尔和异议者
       stand: "refuse" / "accept" / "bargain" —— 面对大主教最后的邀请：拒绝 / 上台 / 要他先放走同伴
       public: true                           —— plan=expose 线：已经当众念出了册子（三万人里有一部分人信了）
       Ch13 将在礼台上给出终局抉择。
    */

    script: [

      { label: "ch12_start" },
      { chapter: { no: "CHAPTER 12", title: "大教堂之夜", sub: "THE NIGHT OF THE CATHEDRAL · 冬至前夜" } },

      /* ---------- 一、冬至前夜 ---------- */
      { hide: "all", cgHide: true, bg: "cathedral_square", transition: "black", bgm: "ch12_square", effect: "fadeIn",
        text: "冬至前夜，王都，没有人，睡觉。" },
      { text: "大教堂前的广场上，挤满了人。三万人，或许更多。手里都举着灯，从教堂的台阶，一直排到，王都最远的那条街。" },
      { text: "钟声，每隔一刻，响一次。每一次，都比上一次，更低，也更长。像一头巨大的牲口，在雪地里，缓缓地，呼出一口白气。" },
      { show: LINE, who: "mingyue", expr: MY("normal"), text: "……好多人。比港口，赶集那天，还多。" },
      { who: "claude", text: "他们，都以为，明天，是一个，节日。" },
      { who: "bailong", text: "……（盯着人群里，每一盏灯）……他们的灯，是，一样的。" },

      /* 按对策分流 */
      { if: { plan: "expose" }, jump: "ch12_expose" },
      { if: { plan: "feign" },  jump: "ch12_feign" },
      { jump: "ch12_flee" },

      /* ----- 公开揭发 ----- */
      { label: "ch12_expose" },
      { who: "claude", text: "……就是现在。" },
      { text: "她爬上了广场东侧，一座废弃的钟架。风，把她的斗篷，吹得鼓了起来。她取出瓦伦替她抄好的册子，用尽全身力气，喊出了第一句话。" },
      { who: "claude", text: "我是，克劳德！第三十八位，圣女！" },
      { text: "声音，在人群里，炸开了一圈涟漪。最近的几百个人，同时，回过头。然后，更远处的几千个人，也回过头。" },
      { who: "claude", text: "明天的收束礼，不是，赐福！是，把四块神的碎片，放进，一个人的，身体里！" },
      { who: "claude", text: "那个人，是我！……在我之前，还有，三十七个！这是，她们的名字！" },
      { text: "她一页一页，念了下去。念到第十九位，有人，开始骚动。念到第三十位，人群里，传来了，压抑的哭声。念到第三十七位，她停住了。" },
      { who: "claude", text: "……第三十七位，伊芙琳。九岁，入教。……她的名字下面，写着，一句，不是官方的话。" },
      { who: "claude", text: "「想看海。」" },
      { set: { public: true }, text: "没有人说话。三万盏灯，在雪夜里，静静地，亮着。有人把灯，慢慢地，放低了。有人，把灯，举得，更高了。" },
      { text: "人群，裂开了。一半的人，向她，涌过来。另一半，向教堂的台阶，退去。大教堂的门，缓缓地，打开了。穿白袍的执事们，成列地，走了出来。" },
      { who: "mingyue", expr: MY("surprised"), text: "……有人，信了！有很多人，信了！" },
      { who: "claude", text: "也有，很多人，没有。" },
      { who: "bailong", text: "……（慢慢地，往前走了一步，挡在了克劳德的身前）……他们，来了。" },
      { if: { threads: "reconnect" },
        text: "人群里，忽然，有一个声音，哼起了一段，没有歌词的调子。第二个人，也哼了起来。那些，被剪断了线、又被接回来的人，在这个夜晚，无师自通地，开始应和。" },
      { jump: "ch12_vigil" },

      /* ----- 假意配合 ----- */
      { label: "ch12_feign" },
      { who: "claude", text: "……我，走进去。" },
      { who: "mingyue", expr: MY("worried"), text: "你，真的，要一个人，去？" },
      { who: "claude", text: "只有，圣女，才能，从正门，走上礼台。" },
      { who: "bailong", text: "……我们，在，人群里。……你，一回头，就，能看见。" },
      { who: "mingyue", text: "……要是，有一点，不对劲，我就，把整个广场，淹了！" },
      { who: "claude", text: "……这座城，没有海。" },
      { who: "mingyue", text: "那我，就在，地上，挖一个！" },
      { text: "克劳德深吸了一口气，把那件洗得发白的白袍，重新，穿在了身上。袍角，拖在雪地里，像一条，已经，被谁，默默地，走过了很多遍的路。" },
      { text: "她独自，走向了大教堂。人群，在她的面前，一层一层地，让开。十三盏灯，从台阶上，亮了起来，在她的头顶，排成了一道，门。" },
      { jump: "ch12_vigil" },

      /* ----- 逃不掉（回来了） ----- */
      { label: "ch12_flee" },
      { who: "claude", text: "……我，决定了。我，要，去见，他。" },
      { who: "mingyue", expr: MY("normal"), text: "……大主教？" },
      { who: "claude", text: "嗯。……我，想，当面，问他，一句话。" },
      { who: "bailong", text: "……我，们，陪你，去。" },
      { text: "城北的骑士们，不知何时，已经，列成了，两排。格伦团长，站在最前面，单膝，点地。他没有说话，只是，向她们，微微，低下了头。" },
      { text: "骑士的队列，一直，延伸到大教堂的台阶。她们，从那条，沉默的、披着铠甲的路上，一步，一步地，走了过去。" },
      { who: "gren", text: "……圣女大人。陛下的旨意是：任何人，不得，伤害您。" },
      { who: "gren", text: "……包括，教会的人。" },
      { jump: "ch12_vigil" },

      /* ---------- 二、守夜 ---------- */
      { label: "ch12_vigil" },
      { hide: "all", bg: "cathedral_square", transition: "fade", bgm: "ch12_vigil",
        text: "夜，越来越深。雪，又下了起来。" },
      { show: LINE, text: "距离午夜，还有，一个时辰。大教堂里，传出了，另一种，更古老的钟声。不是报时，不是礼拜。是一种，像一个人，在很深很深的水底，敲打，什么东西的声音。" },
      { who: "bailong", expr: BL("surprised"), text: "……！" },
      { text: "白泷忽然，捂住了胸口。她的发梢，一寸一寸，亮了起来。像有人，在她身体的某一处，点燃了一小簇，不肯熄灭的火。" },
      { if: { shard: "taken" },
        text: "那团火，在拽她。不是，一点，而是，整个。像一根，看不见的绳，系在她的胸口，另一头，被谁，一寸一寸，往大教堂里，收。" },
      { if: { shard: "taken" },
        who: "bailong", text: "……不。……龙，不被，召。……我，是，我自己的。" },
      { if: { shard: "left" },
        text: "远处的北方，一颗，赤红色的星，忽然，从天际，滑了下来。它拖着很长很长的尾焰，一路向南。越来越近，越来越近。" },
      { if: { shard: "left" },
        who: "bailong", text: "……奶奶！……奶奶的火，被，拉走了！" },
      { if: { shard: "claude" },
        text: "克劳德的右手，忽然，烫了起来。袖口下面的那点暖红，在她的皮肤下，一下，一下，跳得，几乎，要冲出来。" },
      { if: { shard: "claude" },
        who: "claude", text: "……它，也，在，被，叫。" },

      { sfx: "surge", cg: "cg_four_lights", bgm: "ch12_arrival",
        text: "然后，四道光，同时，从夜空的四个方向，升了起来。" },
      { text: "南边，是深蓝。那是，海。东边，是黄褐。那是，山。北边，是赤红。那是，火。西边，是白，是一种，几乎，没有颜色的、轻得像一阵叹息的白。那是，风。" },
      { text: "四道光，划破冬夜，从大陆的四个方向，向着同一个中心，缓缓地，汇聚。广场上的三万人，都，抬起了头。没有人，说话。" },
      { if: { plan: "expose" },
        text: "连刚才，还在争吵的两派人，此刻，也都，闭上了嘴。像一群，同时，被雷，劈中了喉咙的孩子。" },
      { who: "mingyue", expr: MY("surprised"), text: "……那个，蓝色的……是，海！……它，是，从，港口，过来的！" },
      { text: "蓝光，掠过她们头顶的一瞬间，克劳德的胸口，忽然，一紧。不是疼，是一种，非常陌生的、仿佛什么东西，被轻轻地，叫了一下的感觉。" },

      { text: "……她看见了。一条，很长很长的、沿着海岸的路。路上，是，白色的队伍。" },
      { text: "香炉，白袍，一排一排，举着灯的人。他们簇拥着，一个，被披上了，太大的白袍的、八岁的孩子，向前走。" },
      { text: "那个孩子，不敢，抬头。可是，在队伍的外面，在那道拦着人群的、粗粗的麻绳外面，有一个，小小的、跑得飞快的影子。" },
      { text: "是一个，女孩。她的头发，是被海风，吹得乱糟糟的深蓝色。她，一边跑，一边，笑。笑声，很响，响得，像一串，撞碎在石头上的海浪。" },
      { text: "……她手里，好像，攥着一样，用油纸，包着的东西。" },
      { text: "然后，一切，被雪，盖住了。" },
      { cgHide: true, who: "claude", expr: CL("surprised"), text: "……（捂住了额头）……" },
      { who: "mingyue", expr: MY("worried"), text: "克劳德？你，怎么了？" },
      { who: "claude", text: "……没什么。……只是，刚才，好像，想起了，一件，很小很小的事。……我，抓不住它。" },
      { who: "mingyue", text: "……（皱眉）……我，也，有一点，奇怪的，感觉。……就，像是，很久以前，在哪里，跑过。" },
      { who: "bailong", text: "……你们，两个。……闻起来，很，像。" },
      { who: "mingyue", expr: MY("angry"), text: "什么叫，很像！我们，才，认识，没几个月！" },
      { who: "bailong", text: "……也许，更久。" },
      { text: "克劳德没有再说什么。可是，在她的胸口深处，那个被人，轻轻，叫了一下的地方，一直，没有，平静下来。" },

      /* ---------- 三、地牢 ---------- */
      { text: "距离午夜，还剩，半个时辰。克劳德知道，她必须，先去，一个地方。",
        choices: [
          { text: "先去地牢，放出塞缪尔和那些异议者",   jump: "ch12_dungeon", set: { jail: "freed" } },
          { text: "时间不够了，直接去礼台",             jump: "ch12_skipjail", set: { jail: "skipped" } }
        ] },

      { label: "ch12_dungeon" },
      { hide: "all", bg: "dungeon", transition: "black", bgm: "ch12_dungeon",
        text: "大教堂的地牢，在最低的一层。" },
      { show: LINE, text: "潮湿的石壁，生了锈的铁栅，一排排，空荡荡的牢房。只有最里面的那一间，亮着一盏，小小的烛火。" },
      { who: "samuel", text: "……我，听见了，脚步声。是您，对吗？" },
      { text: "他坐在牢房的地上，背靠着墙。灰色的外套，皱了。他身边的栅栏外，躺着，二十几个，同样穿着灰袍的人。有的，在昏睡。有的，在静静地，数着，自己的呼吸。" },
      { who: "claude", text: "……他们，是谁？" },
      { who: "samuel", text: "和我一样，质疑过，礼台的人。……我们，被叫作，『异议者』。……大主教，没有，伤害我们。他，只是，把我们，放在了，最安静的地方。" },
      { who: "samuel", text: "他说，等明天，一切结束，我们，会明白，他的苦心。" },
      { if: { sam_dream: true },
        text: "他的眼睛，红红的。手腕上，那根曾被剪断又被接回的线，在烛火下，隐隐发亮。他的睡眠，大概，从那一天起，就，没有，真正安稳过。" },
      { if: { sam_dream: true },
        who: "samuel", text: "……我，现在，每天晚上，都，做梦。……是同一个。……一个女人，叫我，小河。" },
      { if: "!sam_dream",
        who: "samuel", text: "……我，什么都，没有梦见。……可是，我，一直，在想，您在云海里，说的那句话。" },
      { who: "claude", text: "我，需要你，帮我，一件事。" },
      { who: "samuel", text: "……请说。" },
      { who: "claude", text: "礼台的底座，是，缄石。……缄石，能剪线。……你，是，这座教堂里，最懂得，怎么剪线的人。" },
      { who: "claude", text: "我想知道，如果，不是剪，人。……而是，剪，它，会，怎么样。" },
      { text: "男人，沉默了很久。他缓缓地，抬起了，自己的手，看着，手腕上，那一圈，浅浅的、被线，缠过的痕迹。" },
      { who: "samuel", text: "……我，花了，二十年，剪别人。……从没有，想过，可以，剪，礼台。" },
      { who: "samuel", text: "（慢慢地，站起来）……好。……我，帮您。" },
      { who: "mingyue", expr: MY("normal"), text: "……你，不怕，大主教？" },
      { who: "samuel", text: "怕。……可是，我更怕，明天，还剩，二十三个，没有被问过，愿不愿意的，人。" },
      { sfx: "chain", text: "白泷伸出手，轻轻，一拧，那把，已经生了锈的牢锁，像一根，被捏断的细枝，掉在了地上。" },
      { text: "二十多个，灰袍的人，陆陆续续，站了起来。他们，彼此，看着，没有说话。那是一种，很奇怪的沉默。像一群，终于，被人，允许，睁开眼睛的人。" },
      { jump: "ch12_platform_go" },

      { label: "ch12_skipjail" },
      { who: "claude", text: "……没有时间了。……我们，直接，去礼台。" },
      { who: "mingyue", expr: MY("worried"), text: "……地牢里，不是，还有，人？" },
      { who: "claude", text: "……我知道。……对不起。……我，会，记着。" },
      { text: "这个决定，让她，在往后的很多个夜里，都，没有，真正，睡着。可是，在那一刻，她只有，这一个，选择。" },
      { jump: "ch12_platform_go" },

      /* ---------- 四、礼台 ---------- */
      { label: "ch12_platform_go" },
      { hide: "all", bg: "platform", transition: "black", bgm: "ch12_platform",
        text: "礼台，在大教堂最深处的，圆顶之下。" },
      { show: LINE, text: "那是一座，用白色大理石，砌成的、圆形的高台。台面上，刻着，一圈一圈的同心圆。最外圈，写着海，山，火，风。最中央，是一个，小小的、空着的凹陷。" },
      { text: "凹陷的大小，刚好，容得下，一个人，坐下去。" },
      { text: "台下，是缄石，砌成的、一圈漆黑的基座。每一块石头，都在，往空气里，缓缓，渗着一种，不属于任何声音的，沉沉的静。" },
      { who: "archbishop", text: "……你，来了。" },
      { text: "老人，站在礼台，边缘。白色的长袍，苍白的须发，背脊，笔直。他的身后，是三十位，列队的执事，每一个人，都低着头。" },
      { if: { entry2: "king" },
        text: "礼台的另一侧，站着一个，没有戴冠的男人。他的身后，是格伦，和一队，铠甲沉默的近卫。他没有走近，只是，用目光，对克劳德，轻轻，点了一下头。" },
      { who: "archbishop", text: "……我，一直，在等，这个时刻。……从你，八岁，那一天起。" },
      { who: "claude", text: "……八岁。" },
      { who: "archbishop", text: "你知道吗，那一天，我，在城门口，等你。……你，穿着一件，太大的袍子，一路上，不肯，抬头。" },
      { who: "archbishop", text: "……我，那时候，就，想，这孩子，会，非常，痛苦。" },
      { who: "archbishop", text: "（缓缓地）……所以，我，想，用我，剩下的，所有的时间，让这份痛苦，变得，有意义。" },
      { text: "这是克劳德，第一次，在这位老人的声音里，听到了，一种，近乎于，真诚的疲惫。她忽然明白，对他来说，这一切，既不是，谎言，也不是，罪行。是，一种，信仰。" },
      { who: "archbishop", text: "孩子。……我，给你，最后一次，选择。" },
      { who: "archbishop", text: "如果，你，自愿，站上来。……我保证，你，不会，疼。我，会，替你，承担，其中，一部分。" },
      { who: "archbishop", text: "我老了。……我的线，早就被剪断了。……可是，我，依然，愿意，把，我剩下的，一切，放在，你的身边。" },
      { who: "mingyue", expr: MY("angry"), text: "……你！你说得，好像，是，一件，很好的事！" },
      { who: "archbishop", text: "（平静地）是。……对三万人，是。对一个，大陆，是。……对她，是，一个，代价。" },

      { text: "钟，开始，敲第十三下之前的，最后一段，长长的静默。",
        choices: [
          { text: "拒绝：「我不会，站上去。」",                         jump: "ch12_refuse",  set: { stand: "refuse" } },
          { text: "上台：「……我，自己，走上去。」",                   jump: "ch12_accept",  set: { stand: "accept" } },
          { text: "交换：「先，让我的同伴，离开。然后，我再决定。」", jump: "ch12_bargain", set: { stand: "bargain" } }
        ] },

      /* ----- 拒绝 ----- */
      { label: "ch12_refuse" },
      { who: "claude", text: "……不。" },
      { who: "archbishop", text: "……你，想好了？" },
      { who: "claude", text: "我，不是，因为，我不愿意，疼。……我，是，因为，我不愿意，让任何人，替别人，疼。" },
      { who: "claude", text: "三万人，可以，学会，自己，疼。……一个大陆，也可以。……他们，不是，需要，一个，替他们做梦的人。" },
      { who: "claude", text: "他们，需要的，只是，被告知，真相，的权利。" },
      { text: "大主教，没有动。他那，一直笔直的，背脊，第一次，微微地，弯了一下。像一棵，被风吹了很多年的树，终于，向其中一个方向，让步。" },
      { who: "archbishop", text: "……伊芙琳，也说过，类似的话。" },
      { who: "archbishop", text: "……她，后来，还是，回来了。" },
      { who: "claude", text: "……我，不是，伊芙琳。……我，有，她没有的，东西。" },
      { who: "archbishop", text: "……什么？" },
      { who: "claude", text: "（回头，看了一眼，身后的两个人）……同伴。" },
      { jump: "ch12_midnight" },

      /* ----- 上台 ----- */
      { label: "ch12_accept" },
      { who: "claude", text: "……我，自己，走上去。" },
      { who: "mingyue", expr: MY("surprised"), text: "什么？！克劳德！" },
      { who: "claude", text: "……不是，认命。……我，想，亲眼，看看，那个，座位，到底，是什么。" },
      { who: "bailong", text: "……我，在，台下。……我，不动。" },
      { who: "claude", text: "……谢谢。" },
      { text: "她一步，一步，走上了，那座白色的礼台。大理石，在她的脚底，凉得，像一整个冬天。她站到了，那圈，最内侧的凹陷旁边，低下头，看着它。" },
      { text: "那个，凹陷，比她想象的，要小。小得，像一张，为一个孩子，准备的摇篮。" },
      { who: "claude", text: "……（轻声）……原来，是这样的。" },
      { who: "archbishop", text: "……（微微颔首）……我，会，陪着你，直到，最后一刻。" },
      { who: "claude", text: "……我，不是，要，躺进去。……我，只是，站着。" },
      { jump: "ch12_midnight" },

      /* ----- 交换 ----- */
      { label: "ch12_bargain" },
      { who: "claude", text: "……我，会，考虑。……但，请先，让她们，离开。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "……什么？！我，不走！" },
      { who: "claude", text: "溟月。……这是，我，唯一，能，做的，事。" },
      { who: "mingyue", text: "……你，才，不要，替我，决定！" },
      { who: "bailong", text: "……龙，不，被，赶走。" },
      { who: "mingyue", text: "（把包袱，往地上，一扔）……我，就，在这儿！你，有本事，叫人，把我，拖走！" },
      { text: "溟月把那只，用百家布缝起来的包袱，在脚边，放得端端正正。那是，她，从港口，一路，抱到这里的、她所有的，家当。" },
      { who: "mingyue", text: "……我，是，被，一百家人，养大的。……我，不是，会，一个人，走开的，那种孩子。" },
      { text: "克劳德，看着她，看了很久。然后，慢慢地，笑了。很轻，很轻。像，一个，输了，一场，自己，最想输的，辩论。" },
      { who: "claude", text: "……（对大主教）……您，看到了。……这，就是，您，计划里，没有算进去的，东西。" },
      { who: "archbishop", text: "……（沉默）……" },
      { jump: "ch12_midnight" },

      /* ---------- 五、午夜 ---------- */
      { label: "ch12_midnight" },
      { sfx: "bell13", text: "钟，响了。第一下。" },
      { text: "穹顶的缝隙里，四道光，同时，落了下来。蓝，黄，红，白。它们，没有，直接落在礼台上。而是，在半空中，缓缓地，盘旋，像四个，在等人叫它们名字的，沉默的孩子。" },
      { who: "mingyue", expr: MY("surprised"), text: "……它们，在，看，克劳德。" },
      { text: "第二下。四道光，像是，同时，被什么，吸引。向礼台的中心，缓缓地，坠了下来。" },
      { text: "第三下。克劳德胸口的那一根，从来没有，被剪断过的线，在这一刻，亮了起来。银白色，像一根，从她心口，笔直拉出去的、很长很长的、细细的光。" },
      { if: { shard: "claude" },
        text: "她右手的那一点暖红，忽然，一下，炸开，把整只袖子，烧成了，细碎的光。" },
      { if: { shard: "taken" },
        text: "白泷的胸口，那团火，一下，冲破了衣襟，像一朵，在冬夜里，突然，开了的赤金色的花。" },
      { who: "bailong", text: "……（咬牙）……我，不给。……可是，我，也，不拦。……你，自己，选。" },
      { who: "mingyue", expr: MY("worried"), text: "……克劳德！你的，线，在，发光！" },
      { who: "claude", text: "……我知道。" },
      { text: "第四下，第五下。四道光，一寸一寸，向她逼近。台下的执事们，开始，齐声，念诵。声音，一层，叠着一层，像一场，被谁，安排好了的、缓缓降临的潮。" },
      { who: "mingyue", text: "……喂，克劳德。" },
      { who: "claude", text: "……嗯？" },
      { who: "mingyue", text: "……如果，我，现在，变成，一条，几十丈长的，大鲸鱼，一口，把你，叼起来，就跑。……你，说，他们，追得上吗？" },
      { who: "claude", text: "……（愣了一下）……会飞的，那种？" },
      { who: "mingyue", text: "对！会飞的，那种！" },
      { who: "bailong", text: "……我，也，可以，载。……我，比，鲸鱼，快。" },
      { who: "mingyue", expr: MY("angry"), text: "……不许，抢！这，是，我先说的！" },
      { text: "在这个，几乎要，窒息的夜里，三个人，居然，同时，笑了。笑得，很短，很轻，却，真的。大主教，在她们，身后，没有说话。他，只是，静静地，看着。" },
      { who: "claude", text: "……谢谢。……我，需要，一个，玩笑。" },
      { who: "mingyue", expr: MY("shy"), text: "……我，才，没有，开玩笑！……我，是，认真的！" },

      { text: "第十二下。钟声，停了。整座，大教堂，在一瞬间，陷入了，彻底的，静。" },
      { text: "然后，第十三下。" },
      { sfx: "surge", effect: "flash",
        text: "四道光，同时，落在了，克劳德的，面前。" },

      { effect: "fadeOut", text: "整座礼台，在她的脚下，亮了起来。" },

      /* ===== 章末：直接衔接第十三章「圆」（终局抉择在第十三章） ===== */
      { label: "ch12_end" }
    ]
  };
})();
