/* =====================================================
   story_ch13.js —— 第十三章「圆」（圆之内、四个声音、空位、终局抉择）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在 ch12_end 之后（ch12 以 fadeOut 结尾，本章以 fadeIn 开场）。
   依赖：flag stand / jail / shard / method / grandma / threads / kanshi / cutknown / samuel / sam_dream /
        sweet(ch01) / toll(ch10) / letter(ch11) / gift(ch11) 只用于分流、回响与选项解锁，缺失时走默认。
   终局：玩家在本章做最后的选择，选择会写入 flag `ending`（E1…E8），
        本章在 ch13_end 以 fadeOut 结尾，第十四章（尾声）开头按 `ending` 分流。
   ===================================================== */
window.STORY_CH13 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {
      god_sea:      { name: "海", title: "碎片之声", color: "#6ab0e8" },
      god_mountain: { name: "山", title: "碎片之声", color: "#c8a860" },
      god_fire:     { name: "火", title: "碎片之声", color: "#e86a3a" },
      god_wind:     { name: "风", title: "碎片之声", color: "#e8f0f8" }
    },
    addBackgrounds: {
      circle_void:  { src: "assets/bg/circle_void.jpg",
                      color: "linear-gradient(180deg,#f4f0e8 0%,#d8d4cc 55%,#a8a8b0 100%)" },
      memory_coast: { src: "assets/bg/memory_coast.jpg",
                      color: "linear-gradient(180deg,#a8c8e0 0%,#e8e0d0 60%,#8a9a88 100%)" }
    },
    addCgs: {
      cg_circle:       { src: "assets/cg/circle.jpg",
                         color: "linear-gradient(180deg,#08080f 0%,#2a2a58 50%,#f8f0c8 100%)" },
      cg_whale_flight: { src: "assets/cg/whale_flight.jpg",
                         color: "linear-gradient(180deg,#14284a 0%,#6aa8d8 50%,#f8f4e8 100%)" }
    },
    addAudio: {
      bgm: { ch13_void: "assets/audio/ch13_void.mp3", ch13_voices: "assets/audio/ch13_voices.mp3",
             ch13_choice: "assets/audio/ch13_choice.mp3", ch13_memory: "assets/audio/ch13_memory.mp3",
             ch13_comic: "assets/audio/ch13_comic.mp3" },
      sfx: { heartbeat: "assets/audio/heartbeat.mp3", shatter: "assets/audio/shatter.mp3", splash: "assets/audio/splash.mp3" }
    },

    /* flag（本章新增）：
       ending: "E1"…"E8"   —— 终局结果，第十四章按它分流
         E1 重圆　E2 永缺　E3 断线　E4 圆心　E5 归海　E6 龙火　E7 鲸飞（搞笑）　E8 真结局
       选项解锁（与总纲一致）：
         重圆 E1：grandma=sang 或 method=song 或 threads=reconnect
         永缺 E2：shard=left 或 samuel=ignored 或 jail=freed
         断线 E3：cutknown 或 kanshi
         圆心 E4：samuel=alone 或 grandma=woke 或 shard=claude 或 stand=accept
         龙火 E6：shard=taken
         归海 E5：无条件
         真结局 E8：sweet=kept 或 toll=truth（前者呼应第一章的海盐焦糖，后者呼应云海里说过的真心话）
         鲸飞 E7：无条件（玩笑选项）
    */

    script: [

      { label: "ch13_start" },
      { chapter: { no: "CHAPTER 13", title: "圆", sub: "THE CIRCLE · 空着的座位" } },

      /* ---------- 一、四道光 ---------- */
      { hide: "all", cgHide: true, bg: "platform", transition: "black", bgm: "ch13_void", effect: "fadeIn",
        text: "光，落下来的时候，没有声音。" },
      { cg: "cg_circle",
        text: "蓝，黄，红，白。四道光，像四条，等了很久很久的鱼，终于，游回了，它们出生的那片水。它们没有撞向她，只是，轻轻地，贴在了她的胸口。" },
      { if: { stand: "accept" },
        text: "她站在礼台的中央，那个比摇篮还要小的凹陷旁边。四道光，围着她，缓缓，转了一圈。像一场，等了一万年的、很客气的拜访。" },
      { if: { stand: "refuse" },
        text: "她站在礼台的边缘，没有往前走一步。四道光，却，一路，追了过来。不是，被召唤。是，认得她。" },
      { if: { stand: "bargain" },
        text: "她站在礼台的边缘。她的同伴，没有离开。四道光，在她们三个人的头顶，缓缓地，绕了一圈，像在，数人头。" },
      { text: "胸口，那一根，从来没有被剪断过的线，亮得，几乎要透过袍子。台下的执事们，诵念的声音，戛然而止。三万人，同时，屏住了呼吸。" },
      { cgHide: true, show: LINE, who: "mingyue", expr: MY("surprised"), text: "……克劳德。你的，手。" },
      { text: "她低头。她的指尖，正在，一点一点地，变得透明。像，一杯被灯光穿过的水。" },
      { who: "claude", text: "……没事。……不疼。" },
      { who: "bailong", text: "……（死死地，攥住了她的袖子）……它们，不是，要，伤害你。……它们，是，想，说话。" },
      { sfx: "heartbeat", effect: "flash", text: "然后，整个世界，白了。" },

      /* ---------- 二、圆之内 ---------- */
      { hide: "all", bg: "circle_void", transition: "cut", bgm: "ch13_voices",
        text: "那是一个，没有地面，没有天空，也没有墙的地方。" },
      { show: LINE, text: "只有，白。一种，很柔软的、像刚刚晾干的棉布一样的白。三个人，站在这片白里，像三枚，被轻轻，放在纸上的、墨色的点。" },
      { who: "mingyue", expr: MY("worried"), text: "……我们，死了吗？" },
      { who: "claude", text: "……不像。" },
      { who: "bailong", text: "……是，圆的，里面。" },
      { text: "四个声音，从四个方向，缓缓地，升了起来。它们不是，从嘴里发出的。更像是，从很久很久以前的某一天，被人，一直，攥着，终于，松开了手的声音。" },
      { who: "god_sea", text: "……孩子。……你们，长这么大了。" },
      { who: "god_mountain", text: "……我们。……说话。……很慢。……请，等一等。" },
      { who: "god_fire", text: "……（一个，很暖的，像在炉边打盹的声音）……小白，你，也来了。" },
      { who: "bailong", text: "……（眼睛，一下子，红了）……奶奶的，声音。" },
      { who: "god_fire", text: "……不是。……是，奶奶，替我，守了，一万年。……所以，我，学会了，她的口气。" },
      { who: "god_wind", text: "……我，替大家，说。……因为，我，说话，最快。" },

      { text: "风的声音，在她们的耳边，绕了一圈，像在，整理，一叠，写满了字的纸。" },
      { who: "god_wind", text: "……很久很久以前。……我们，是，一个，完整的，圆。" },
      { who: "god_wind", text: "……太大了。……我们的梦，会烧掉，你们的，世界。……我们，自己，知道。" },
      { who: "god_fire", text: "……所以，我们，答应了，分开。" },
      { who: "god_sea", text: "……一块，沉海。……一块，上山。……一块，给火。……一块，给风。" },
      { who: "god_mountain", text: "……最后一块。……留给，你们。" },
      { who: "claude", expr: CL("surprised"), text: "……留给，我们？" },
      { who: "god_wind", text: "……一个，空位。……让你们，在那里，坐着。……替我们，等。" },
      { who: "god_wind", text: "……等，你们，想好，要，怎么，对待，我们。" },
      { text: "声音停了很久。然后，是一种，不太确定的、近乎，羞怯的语气。" },
      { who: "god_wind", text: "……可是，你们的，先祖，害怕。" },
      { who: "god_wind", text: "……他们，把，最后一块，放进了，自己的，胸口。……又派人，把我们，一线，一线，剪断。" },
      { who: "god_wind", text: "……他们，说，这是，自愿。" },
      { who: "god_fire", text: "……是，自愿。……是，我，自己，答应的。" },
      { who: "god_mountain", text: "……是，被，请求的。……那一夜，他们，跪着，求。" },
      { who: "god_sea", text: "……我，不记得。……我，只记得，有一首，摇篮曲。" },
      { who: "god_wind", text: "……每一块，记得的，都不一样。……因为，每一块，记得的，不是，同一个，夜晚。" },
      { who: "claude", text: "……所以。……「莫信『自愿』二字」，是……" },
      { who: "god_wind", text: "……我们，不知道。……写下它的人，也许，比我们，更清楚。……也许，不是。" },
      { text: "克劳德没有再问。她忽然明白，这是一个，没有，答案的故事。至少，在这一刻，没有任何一个，活着的声音，能把它，完整地，讲出来。" },

      { who: "god_sea", text: "……孩子。……我们，不能，替你，选。……这个，空位，是，你们的。" },
      { who: "god_fire", text: "……要怎么，处置，它。……要，怎么，处置，我们。" },
      { who: "god_mountain", text: "……我们，都会，接受。" },
      { who: "god_wind", text: "……只是，请你。……不要，因为，害怕，而选。" },
      { text: "白，开始，缓缓地，向四周，退去。一个，小小的、圆形的光，在她们的面前，慢慢，浮了出来。" },

      /* ---------- 三、同伴 ---------- */
      { who: "mingyue", expr: MY("normal"), text: "……克劳德。" },
      { who: "claude", text: "……嗯。" },
      { who: "mingyue", text: "不管，你，选什么，我，都，在。" },
      { who: "mingyue", text: "……我，不会，替你，选。……可是，你，选完了，我，会，骂你。……骂，你选得，太笨。" },
      { who: "claude", expr: CL("smile"), text: "……好。" },
      { who: "bailong", text: "……我，也，在。" },
      { who: "bailong", text: "……龙，不抢，睡着的东西。……所以，不管，你，选什么，我，都，不会，替你，拿。" },
      { who: "bailong", text: "……可是，如果，你，需要，一个，人，扛。……我，是，那个，人。" },
      { text: "克劳德看着，她们。两个，在这个，没有天空的白色里，依旧，那么，真实的，轮廓。" },
      { text: "她想起了，很多事。八岁，那辆，封闭的马车。十年，每天早上，对着镜子，练习的微笑。盟约之夜的，那一块，她没有，吃的点心。" },
      { text: "……还有，一朵，从港口，海芙蓉，夹在圣典里，早已，干枯的、淡粉色的花。" },

      /* ---------- 四、选择 ---------- */
      /* ---------- 选项解锁：把「或」条件折叠成单个 can_* 标记（引擎的 if 只支持「且」） ---------- */
      { if: { grandma: "sang" },     set: { can_E1: true } },
      { if: { method: "song" },      set: { can_E1: true } },
      { if: { threads: "reconnect" }, set: { can_E1: true } },
      { if: { shard: "left" },       set: { can_E2: true } },
      { if: { samuel: "ignored" },   set: { can_E2: true } },
      { if: { jail: "freed" },       set: { can_E2: true } },
      { if: { cutknown: true },      set: { can_E3: true } },
      { if: { kanshi: true },        set: { can_E3: true } },
      { if: { stand: "accept" },     set: { can_E4: true } },
      { if: { samuel: "alone" },     set: { can_E4: true } },
      { if: { grandma: "woke" },     set: { can_E4: true } },
      { if: { shard: "claude" },     set: { can_E4: true } },
      { if: { shard: "taken" },      set: { can_E6: true } },
      { if: { sweet: "kept" },       set: { can_E8: true } },
      { if: { toll: "truth" },       set: { can_E8: true } },

      { bgm: "ch13_choice", text: "圆，在她面前，等着。",
        choices: [
          { text: "为这个世界，做出决定",                       jump: "ch13_world" },
          { text: "为我自己，做出决定（伊芙琳的信）",           jump: "ch13_self" },
          { text: "（笑）「溟月，你刚才说的办法，还作数吗？」", jump: "ch13_joke" }
        ] },

      /* ----- 为世界 ----- */
      { label: "ch13_world" },
      { text: "这个空位，应该，怎么，处置？",
        choices: [
          { text: "重圆：让四块碎片，与第五块，合而为一", jump: "ch13_E1", set: { ending: "E1" }, if: "can_E1" },
          { text: "永缺：让它们各自安睡，空位，永远，空着", jump: "ch13_E2", set: { ending: "E2" }, if: "can_E2" },
          { text: "断线：剪断所有的线，让人与神，各自安静", jump: "ch13_E3", set: { ending: "E3" }, if: "can_E3" },
          { text: "圆心：我，自己，坐进，这个空位", jump: "ch13_E4", set: { ending: "E4" }, if: "can_E4" },
          { text: "龙火：把火，交给，白泷，让龙族，醒来", jump: "ch13_E6", set: { ending: "E6" }, if: "can_E6" },
          { text: "……（先，回去，再想想）",                      jump: "ch13_choice_back" }
        ] },

      { label: "ch13_choice_back" },
      { text: "她深吸一口气，向后，退了一步。圆，没有催她。它，等了一万年，不差这一刻。",
        choices: [
          { text: "为这个世界，做出决定",                       jump: "ch13_world" },
          { text: "为我自己，做出决定（伊芙琳的信）",           jump: "ch13_self" },
          { text: "（笑）「溟月，你刚才说的办法，还作数吗？」", jump: "ch13_joke" }
        ] },

      /* ----- 为自己 ----- */
      { label: "ch13_self" },
      { who: "claude", text: "……伊芙琳，说，『不要因为责任，回去。如果你回去，请为你自己，回去』。" },
      { who: "claude", text: "……我，想，为我自己，选一次。" },
      { text: "她要为自己，选什么？",
        choices: [
          { text: "回海边：不再管这个圆，去过普通的日子",       jump: "ch13_E5", set: { ending: "E5" } },
          { text: "「让我，把那件，被雪盖住的事，想起来。」", jump: "ch13_E8", set: { ending: "E8" }, if: "can_E8" },
          { text: "……（先，回去，再想想）",                      jump: "ch13_choice_back" }
        ] },

      /* ===================== 各结局的「决断一刻」 ===================== */

      /* ----- E1 重圆 ----- */
      { label: "ch13_E1" },
      { who: "claude", text: "……我，想，让你们，回来。" },
      { who: "god_sea", text: "……你，确定？……这样，你，会，不再，是，你。" },
      { who: "claude", text: "……不。……我，想，我，还是，我。……我只是，想，替这个，空位，找到，它，真正的，意思。" },
      { text: "她张开双手。四道光，一道，一道地，亮了起来，像四条，终于，被人，叫了乳名的鱼。" },
      { if: { threads: "reconnect" },
        text: "在遥远的、整个大陆的每一个角落，那些，被接回线的人，在睡梦里，同时，睁开了眼睛。他们，听见了，一首，很久没有，被唱完的歌。" },
      { if: { method: "song" },
        text: "溟月，在她的身边，轻轻，哼了起来。那是，她在霜渡，唱过的，那半首歌。这一次，她，唱完了。" },
      { text: "海，山，火，风，缓缓，向圆心，靠拢。当它们，终于，碰到了彼此的那一瞬，整个白色的世界，发出了，一声，像一千口钟，同时，被敲响的、温柔的巨响。" },
      { who: "god_wind", text: "……谢谢。……我们，等了，很久。" },
      { effect: "fadeOut", text: "光，吞没了，一切。" },
      { jump: "ch13_end" },

      /* ----- E2 永缺 ----- */
      { label: "ch13_E2" },
      { who: "claude", text: "……请，不要，被，叫醒。……也不要，被，剪断。" },
      { who: "claude", text: "……就，让这个空位，一直，空着。……让它，成为，我们，对你们，的一个，承诺。" },
      { who: "god_mountain", text: "……什么，承诺？" },
      { who: "claude", text: "……我们，不会，再，抢。……不会，再，替你们，决定。……也不会，再，因为，怕，而把你们，剪成，一盏，不会哭的灯。" },
      { text: "四道光，缓缓地，安静了下来。像四个孩子，终于，听见了，一个，可以相信的，晚安。" },
      { if: { jail: "freed" },
        text: "礼台的边缘，塞缪尔，已经，抬起了手。他手里，是一把，用缄石磨成的、小小的刀。他没有，剪向任何人。他只是，轻轻地，割断了，礼台的，基座。" },
      { if: { jail: "freed" },
        who: "samuel", text: "……这是，我，这一生，剪过的，唯一一件，对的东西。" },
      { text: "礼台下面，那一圈漆黑的缄石，一块一块，裂开。像一个，被憋了很久很久的人，终于，吐出了一口，很长很长的气。" },
      { effect: "fadeOut", text: "四道光，各自，向四个方向，飞了回去。" },
      { jump: "ch13_end" },

      /* ----- E3 断线 ----- */
      { label: "ch13_E3" },
      { who: "claude", text: "……我，想，剪断，它们。" },
      { who: "mingyue", expr: MY("surprised"), text: "……你说，什么？" },
      { who: "claude", text: "……所有的线。……我，自己的，也是。" },
      { who: "claude", text: "……这样，就，不会，再，有，孩子，因为，神的梦，而，烧起来。……也不会，再，有，人，因为，神的梦，而，被，选中。" },
      { who: "god_sea", text: "……代价，是，你们，不再，听得见，我们。" },
      { who: "claude", text: "……我知道。……对不起。" },
      { if: { kanshi: true },
        text: "她从怀里，取出了，那一小块，用圣典的封皮，包了很久的缄石。灰黄色的晶体，在白色的光里，沉默，像一粒，冷却了的叹息。" },
      { if: { jail: "freed" },
        text: "塞缪尔，站在她的身侧。他的手，在抖，却，很稳。他是，这世上，最懂得，如何，剪的人。" },
      { text: "刀落下的那一瞬，没有声音。只有，一根，从她的胸口，一直，延伸到，世界尽头的，银白色的线，缓缓地，松开了。" },
      { who: "mingyue", expr: MY("worried"), text: "……克劳德！你，还在吗？！" },
      { who: "claude", text: "……在。……只是，好安静。" },
      { effect: "fadeOut", text: "光，一盏，一盏，熄灭了。" },
      { jump: "ch13_end" },

      /* ----- E4 圆心 ----- */
      { label: "ch13_E4" },
      { who: "claude", text: "……我，坐进去。" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "……不行！克劳德！你说好的！" },
      { who: "claude", text: "……我，没有，说好。……我，只是，说，我，会，选。" },
      { who: "claude", text: "……这个空位，是，人类，留的。……总要，有人，坐。" },
      { who: "claude", text: "……三十七个，人，被迫，坐过。……我，想，做，第一个，自己，选的。" },
      { who: "bailong", text: "……（低着头，拳头，攥得，指节发白）……龙，不抢。……可是，我，想，拦。" },
      { who: "claude", text: "……白泷。……请，不要，拦。" },
      { who: "bailong", text: "……（一动不动）" },
      { who: "claude", text: "……溟月。……你，不是，说，要，骂我吗？……骂吧。……我，在听。" },
      { who: "mingyue", text: "……笨蛋。……笨蛋。……笨蛋！" },
      { text: "溟月，哭了。她不再，喊了。只是，伸出手，紧紧地，攥住了，克劳德即将，变得透明的手。" },
      { who: "mingyue", text: "……我，不放。……你，要，走，就，带着，我，一起。" },
      { text: "克劳德，没有，再说话。她，轻轻，坐进了，那个，圆形的凹陷。四道光，围绕着，她，缓缓地，旋转，像，一场，等了一万年的、很温柔的拥抱。" },
      { effect: "fadeOut", text: "圆，合上了。" },
      { jump: "ch13_end" },

      /* ----- E6 龙火 ----- */
      { label: "ch13_E6" },
      { who: "claude", text: "……白泷。" },
      { who: "bailong", text: "……嗯。" },
      { who: "claude", text: "……火，在你那里。……我，不想，替你，决定。……可是，我，想，问你。" },
      { who: "claude", text: "……你，愿意，一直，守着，它吗？" },
      { who: "bailong", text: "……（想了很久，很久）……龙，不抢，睡着的东西。" },
      { who: "bailong", text: "……可是，它，不是，睡着的。……它，是，我家。" },
      { who: "bailong", text: "……我，守。……我，替奶奶，守。……替，所有，睡着的，龙，守。" },
      { who: "god_fire", text: "……小白。……长大了。" },
      { text: "白泷的头发，缓缓地，全部，亮成了，赤金色。她的瞳孔，缩成了，两道，细细的竖线。她转过身，对着，另外三道光，认真地，鞠了一躬。" },
      { who: "bailong", text: "……海，山，风。……你们，回去，睡吧。……火，我，守。" },
      { text: "三道光，温和地，向她，闪了一下。然后，分别，向三个方向，缓缓，退了回去。只有，红色的那一道，留在了，她的身边。像一团，终于，找到了，灯笼的火。" },
      { effect: "fadeOut", text: "……龙脊上，沉睡的龙，一条一条，睁开了眼睛。" },
      { jump: "ch13_end" },

      /* ----- E5 归海 ----- */
      { label: "ch13_E5" },
      { who: "claude", text: "……我，不选。" },
      { who: "god_wind", text: "……你，确定？……这个，空位，不会，一直，等。" },
      { who: "claude", text: "……我，不知道，它，等不等。……可是，我，想，先，回去，看看，我的，朋友。" },
      { who: "claude", text: "……我，想，吃，一顿，饭。……是，很多家人，凑出来的，那种。" },
      { who: "claude", text: "……我，想，在，海边，坐一个，下午。……什么，也不想。" },
      { who: "god_sea", text: "……好。" },
      { who: "god_fire", text: "……（轻轻地，笑）……这，也是，一个，答案。" },
      { text: "四道光，没有，挽留。它们，只是，静静地，看着她，转过身。像一群，看着，自己的孩子，第一次，决定，要，去哪里的，长辈。" },
      { who: "mingyue", expr: MY("surprised"), text: "……克劳德？……这样，可以吗？" },
      { who: "claude", expr: CL("smile"), text: "……不知道。……但是，我，想，试一试。" },
      { who: "bailong", text: "……我，也，回去。……奶奶，说，要，常，回家。" },
      { effect: "fadeOut", text: "她们，转身，向，白色的，尽头，走去。" },
      { jump: "ch13_end" },

      /* ----- E8 真结局 ----- */
      { label: "ch13_E8" },
      { who: "claude", text: "……我，想，把，那件，被雪，盖住的事，想起来。" },
      { who: "god_sea", text: "……（很轻地）……我，替你，翻开。" },
      { hide: "all", bg: "memory_coast", transition: "fade", bgm: "ch13_memory",
        text: "……海，风。……沿着海岸，一直，向北的，白色的石子路。" },
      { text: "香炉的烟，向后，飘去。一队，白袍的人，簇拥着，一个，被披上，太大的长袍的孩子，缓缓，向前走。孩子，低着头，看着，自己的脚尖。" },
      { text: "沿路，所有的人，都，跪下了。他们，把额头，抵在石子路上。没有人，敢，抬头，看这个，被叫作，『圣女』的孩子。" },
      { text: "只有一个人，没有。" },
      { text: "在，拦着人群的，那道，粗粗的麻绳外面，一个，小小的、头发，是被，海风，吹乱的，深蓝色的女孩，正，沿着，队伍，没命地，跑。" },
      { text: "她，一边跑，一边，笑。笑声，很响，响得，像一串，撞碎在石头上的，海浪。她，根本，没有，在看，什么圣女。她，是在，追，一只，掉了的、红色的，风筝。" },
      { text: "风筝，被风，卷了起来，一个，转弯，从麻绳上，飞了过去。落在了，那个，低着头的、八岁的孩子，脚边。" },
      { text: "孩子，抬起头。……那是，她，第一次，在这条，路上，抬头。" },
      { text: "她看见了，那个，女孩。女孩，隔着麻绳，伸出手，对她，用力地，挥了挥。然后，从，口袋里，摸出，一样，用油纸，包着的东西，用尽全力，扔了过来。" },
      { text: "……那是一颗，海盐焦糖。……它，落在，她的，长袍上，滚了两圈，停在了，她的，袖口里。" },
      { text: "身旁的，白袍执事，立刻，把它，拨走了。可是，已经，晚了。孩子，用手，把它，攥在了，掌心里。攥了，一整个，白天。" },
      { text: "那天夜里，她，躺在，马车里，一个，没有人，看见的，黑暗里。把那颗，已经，被体温，焐得，有点化的糖，轻轻地，放进了，嘴里。" },
      { text: "……很咸。……后来，是，很甜。……那是，她，十年里，吃过的，唯一一颗，不是，教会，给她的，东西。" },
      { hide: "all", bg: "circle_void", transition: "fade", bgm: "ch13_choice", show: LINE,
        text: "……白色，又回来了。" },
      { who: "claude", expr: CL("surprised"), text: "……是，你。" },
      { who: "mingyue", expr: MY("surprised"), text: "……什、什么？" },
      { who: "claude", text: "……十年前。……海边。……你，在，追，一只，红色的，风筝。" },
      { who: "mingyue", text: "……！" },
      { text: "溟月，愣了很久。然后，她的眼睛，一点，一点，睁大了。像一个人，在一个，很旧的，抽屉里，忽然，摸到了，一件，自己，早就，忘记，放在哪里的，东西。" },
      { who: "mingyue", text: "……那，不是，我，做梦。……那天，有，白袍子，的人。很多。……一个，小小的，穿着，大袍子的，孩子，一直，低着头。" },
      { who: "mingyue", text: "……我，那时候，想，那个人，一定，很难过。……所以，我，把，我，最宝贝的，糖，扔给了她。" },
      { who: "mingyue", text: "……我，还，想，她，会不会，吃。……后来，我，就，忘了。……我，一直，忘了。" },
      { if: { sweet: "kept" },
        who: "claude", text: "……盟约之夜，你，又，递给我，一块。……我，没有，吃。……可是，后来，我，收下了。" },
      { if: { sweet: "refused" },
        who: "claude", text: "……盟约之夜，你，又，递给我，一块。……我，说，圣女，不接受，来路不明的食物。……对不起。" },
      { who: "claude", text: "……它，不是，来路不明。……它，是，我，等了，十年的，一块。" },
      { text: "溟月，哭了。她，一边哭，一边，用袖子，狠狠，擦脸。擦得，鼻尖，都红了。" },
      { who: "mingyue", expr: MY("angry"), text: "……笨蛋！……你，为什么，不早点，想起来！" },
      { who: "claude", text: "……因为，我，一直，在，练习，微笑。……没有，时间，想。" },
      { who: "bailong", text: "……我，说，过。……你们，闻起来，很，像。" },
      { text: "四个声音，在她们的周围，轻轻地，亮着。没有人，催她们。像一群，等了很久的老人，终于，等到了，孩子们，把一件，小事，讲完。" },
      { who: "god_sea", text: "……那一首，摇篮曲。……是，你们，两个，当时，都，听过的。……在，那个，下午。" },
      { who: "god_sea", text: "……我，只是，不太，会，说。……我想让，你们，再，见一次。" },
      { text: "克劳德，低下头，看着自己，那只，已经，几乎，透明的手。她忽然，明白了，空位，的另一个意思。" },
      { who: "claude", text: "……座位，不一定，只能，坐一个人。" },
      { who: "claude", text: "……三十七个，人，被迫，一个人，坐。……是因为，没有人，愿意，陪她们。" },
      { who: "claude", text: "……（对溟月，伸出手）……这个，空位。……我们，一起，坐。" },
      { who: "mingyue", expr: MY("shy"), text: "……我，不是，说，了吗。……你，要，走，就，带着，我。" },
      { who: "bailong", text: "……我，也。" },
      { effect: "fadeOut", text: "……三只手，同时，伸向了，那个，小小的圆。" },
      { jump: "ch13_end" },

      /* ----- E7 搞笑：鲸飞 ----- */
      { label: "ch13_joke" },
      { who: "claude", expr: CL("smile"), text: "……溟月。……你，刚才，在礼台上，说的，那个办法。……还，作数吗？" },
      { who: "mingyue", expr: MY("surprised"), text: "……啊？" },
      { who: "claude", text: "……就是，几十丈长，会飞的，大鲸鱼，一口，把我，叼起来，就跑。" },
      { who: "mingyue", text: "……你，是，认真的？！" },
      { who: "claude", text: "……我，一直，很，认真。……只是，今天，想，认真地，开一次，玩笑。" },
      { who: "god_wind", text: "……（听上去，有点，不知所措）……这个，选项，我们，没有，预料到。" },
      { who: "god_mountain", text: "……我，想，……很有，意思。" },
      { who: "god_fire", text: "……（忍着笑）……小白，你，也，想，载吗？" },
      { who: "bailong", text: "……我，比，鲸鱼，快。" },
      { who: "mingyue", expr: MY("angry"), text: "……不许，抢！这是，我，的，台词！" },
      { who: "mingyue", expr: MY("surprised", "jump"), text: "……可，可是！我，从来，没有，变过！我，怎么，知道，怎么，变！" },
      { who: "god_sea", text: "……我，教你。……很简单。……你，只要，想象，你，是，整片海。" },
      { who: "mingyue", text: "……整片，海。……（闭上眼）……好大。……好，冷。……好，咸。" },
      { who: "mingyue", text: "……好，想，吃，糖栗子！" },
      { who: "god_sea", text: "……（叹气）……也，行吧。" },
      { sfx: "splash", effect: "flash", hide: "all", cg: "cg_whale_flight", bgm: "ch13_comic",
        text: "……然后，整个，大教堂的，穹顶，裂开了。" },
      { text: "一条，几十丈长的，深蓝色的，巨大的，鲸，从，白光里，一个，翻身，破开了，圆顶，鳍上，还，挂着，一串，三十个，人的，惊恐的，眼神。" },
      { speaker: "三万人", text: "……（全体，仰头，沉默）" },
      { speaker: "鲸", text: "（嘴里，叼着，克劳德的，衣领）……呜，呜，呜！（意思是：坐稳了！）" },
      { speaker: "克劳德", text: "……溟月。……你，咬到，我的，头发了。" },
      { speaker: "鲸", text: "……呜！（意思是：对不起！）" },
      { text: "鲸，一个，摆尾，带着，一团，被它，搅得，七零八落的，四色光，扶摇直上，向着，大教堂外，那片，没有边际的、深蓝色的夜空，游去。" },
      { speaker: "白龙", text: "……不许，抢！我，先，到！" },
      { text: "一头，白色的龙，从，教堂的，另一侧，破窗而出，紧紧，追了上去。它的爪子上，还，勾着，一个，大主教，刚刚，扔掉的，权杖。" },
      { speaker: "大主教", text: "…………（站在，崩塌的，礼台上，看着，天上，那一鲸，一龙，沉默了很久）……我，想，我，需要，坐下。" },
      { speaker: "国王", text: "……我，去，给您，搬把椅子。" },
      { set: { ending: "E7" }, effect: "fadeOut", text: "……整座王都，在，那一夜，同时，失去了，言语。" },
      { jump: "ch13_end" },

      /* ===== 章末：第十四章（尾声）按 flag `ending` 分流 ===== */
      { label: "ch13_end" }
    ]
  };
})();
