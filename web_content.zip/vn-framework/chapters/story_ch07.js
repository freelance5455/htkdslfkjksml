/* =====================================================
   story_ch07.js —— 第七章「霜渡」（北行、共鸣热、裁决官的邀约）
   独立章节文件：不修改游戏本体。整合方式见 INTEGRATION.md。
   衔接：接在第六章之后。
     ★ 第六章末尾那 7 步带 end 的收尾（"CHAPTER 06 · 完 …… 未完待续"）必须删掉，
       换成一步 { effect: "fadeOut", text: "……" } 或直接让剧本自然流入 ch07_start。
   本章以 fadeOut 黑屏结尾，第八章以 fadeIn 开场。
   依赖：story.js 里已有的 raymond / oli；以及第六章的 saved / exposed / touched / sang / trusted / decoy。
   ===================================================== */
window.STORY_CH07 = (() => {

  const CL = (expr, anim) => ({ id: "claude",  expr, anim });
  const MY = (expr, anim) => ({ id: "mingyue", expr, anim });
  const BL = (expr, anim) => ({ id: "bailong", expr, anim });
  const LINE = [
    { id: "mingyue", pos: 22, expr: "normal" },
    { id: "claude",  pos: 50, expr: "normal" },
    { id: "bailong", pos: 78, expr: "normal" }
  ];

  return {

    addCharacters: {
      samuel: { name: "塞缪尔", title: "圣堂裁决官", color: "#b8c4d8" },
      mira:   { name: "米拉",   title: "渡口的孩子", color: "#a8d8e8" },
      hodd:   { name: "霍德",   title: "渡口老爹",   color: "#b09878" }
    },
    addBackgrounds: {
      north_road:    { src: "assets/bg/north_road.jpg",
                       color: "linear-gradient(180deg,#8a9aaa 0%,#c8d0d4 55%,#e8ecee 100%)" },
      frostford:     { src: "assets/bg/frostford.jpg",
                       color: "linear-gradient(180deg,#0a1220 0%,#1c2c44 55%,#3a4a5c 100%)" },
      sickroom:      { src: "assets/bg/sickroom.jpg",
                       color: "linear-gradient(180deg,#1a2230 0%,#3a3a44 55%,#5a4a40 100%)" },
      inn_hall:      { src: "assets/bg/inn_hall.jpg",
                       color: "linear-gradient(180deg,#2a1e14 0%,#5a3a22 55%,#8a5a30 100%)" },
      old_chapel:    { src: "assets/bg/old_chapel.jpg",
                       color: "linear-gradient(180deg,#06080e 0%,#1a2030 55%,#3a4458 100%)" },
      ferry_dawn:    { src: "assets/bg/ferry_dawn.jpg",
                       color: "linear-gradient(180deg,#3a4a6a 0%,#c8a8a0 60%,#e8d8c0 100%)" }
    },
    addCgs: {
      cg_lanterns: { src: "assets/cg/lanterns.jpg",
                     color: "linear-gradient(180deg,#05070d 0%,#14203a 55%,#e8b860 100%)" }
    },
    addAudio: {
      bgm: { ch07_road: "assets/audio/ch07_road.mp3", ch07_lanterns: "assets/audio/ch07_lanterns.mp3",
             ch07_town: "assets/audio/ch07_town.mp3", ch07_sick: "assets/audio/ch07_sick.mp3",
             ch07_chapel: "assets/audio/ch07_chapel.mp3", ch07_ferry: "assets/audio/ch07_ferry.mp3" },
      sfx: { ice: "assets/audio/ice.mp3", bell: "assets/audio/bell.mp3" }
    },

    /* flag（本章新增）：
       method:  "rite" / "song" / "hoard"        —— 给发烧的米拉用哪种办法
       cutknown: true                            —— 知道了「安魂礼＝剪线」（rite 线，或见过裁决官）
       samuel:  "alone" / "together" / "ignored" —— 对塞缪尔邀约的回应
       bl_ember: true                            —— 白泷体内留下一点火（method: hoard）
    */

    script: [

      { label: "ch07_start" },
      { chapter: { no: "CHAPTER 07", title: "霜　渡", sub: "THE FROSTFORD · 北行" } },

      /* ---------- 一、北方的路 ---------- */
      { hide: "all", cgHide: true, bg: "north_road", transition: "black", bgm: "ch07_road", effect: "fadeIn",
        text: "离开海岸的第十一天，天气先于地图，换了季节。" },
      { text: "风从背后追上来，带着一股铁一样的凉意。路边的草叶在清晨裹着薄霜，踩上去，会发出很轻的、像在咬碎糖块的声音。" },
      { show: LINE, who: "mingyue", expr: MY("angry"),
        text: "冷！冷冷冷！这根本不是秋天，是谁把冬天提前寄过来了！" },
      { who: "claude", text: "你已经穿了三层。" },
      { who: "mingyue", text: "三层里有两层是你的！还是不够！" },
      { text: "克劳德把自己的灰斗篷又分出一半，搭在她肩上。剩下的那一半，勉强够遮住自己的肩膀。" },
      { who: "bailong", text: "我，不冷。" },
      { who: "mingyue", text: "你是龙！龙不算！" },
      { who: "bailong", text: "龙，也有冷的时候。是在，手里，没有金子的时候。" },
      { who: "claude", text: "……这句话，我会当作是一种修辞。" },

      /* 路线回响 */
      { if: { touched: true },
        text: "克劳德右手背上的印记，在冷风里隐隐发烫。她把手缩进袖子里，没有对任何人说。" },
      { if: { sang: true },
        text: "溟月偶尔会哼起一小段没有名字的调子，哼到一半，自己先停住。她还不知道，另外半句在哪里。" },
      { if: { exposed: true },
        text: "一路上，克劳德都戴着兜帽。港口那一夜之后，「圣女在海边现身」的消息，大概走得比她们更快。" },
      { if: { trusted: true },
        text: "溟月的包袱里还剩半块老舵硬塞的鱼干。她每天啃一小口，说是省着，万一以后没饭吃。谁都看得出，她只是舍不得吃完。" },
      { if: { decoy: true },
        text: "克劳德还是会不时抬手去摸发间。空的。溟月说，到了北边就给她买一朵新的，前提是，她肯认真地砍价。" },

      /* ---------- 二、朝圣的人 ---------- */
      { hide: "all", text: "第三天，她们开始遇见人。" },
      { text: "起初只是三三两两：背着行囊的农夫，推着独轮车的小贩，披着旧披风、走得很慢的老妇人。他们都朝着同一个方向。北。" },
      { text: "到了第五天，路上已经看不见空隙。有人牵着骡子，有人背着老人，有人把孩子扛在肩上。一条细细的、沉默的河，沿着驿道，朝北方流去。" },
      { show: LINE, speaker: "朝圣的农妇", text: "姑娘们也是去看光的吧？" },
      { who: "mingyue", expr: MY("surprised"), text: "不、不是！我们只是，顺路！" },
      { speaker: "朝圣的农妇", text: "顺路的人，都是去看光的。我家那口子，也这么说。" },
      { text: "她笑了笑，把背上的孩子颠了颠，汇进了人流里。" },
      { who: "claude", text: "……没有人，召集他们。" },
      { who: "mingyue", expr: MY("normal"), text: "没人召集，他们就不能去吗？" },
      { who: "claude", text: "我只是在想。过去十年里，每一次朝圣，每一次礼拜，前面都有教会的钟声在领路。" },
      { who: "claude", text: "这一次，没有钟。他们只是，自己，上了路。" },
      { text: "这个念头让她觉得陌生。就像第一次看见一条没有堤岸的河。" },

      /* ---------- 三、灯与童谣 ---------- */
      { hide: "all", bg: "north_road", transition: "fade", bgm: "ch07_lanterns",
        text: "天黑之后，所有人都点起了灯。" },
      { cg: "cg_lanterns",
        text: "那是一幅，克劳德此生都难以忘记的景象。成百上千盏灯，沿着蜿蜒的驿道，一直排到天与地的接缝处。" },
      { text: "有油灯，有提灯，有孩子手里歪歪扭扭的纸灯笼。灯火连成一条细长的、微微摇晃的金线，缓缓流向北方那一线孤独的光。" },
      { text: "人群里，有孩子在唱歌。起初只有一两个，后来，越来越多。调子很简单，简单到像是从谁的摇篮边，一代代漏出来的。" },
      { speaker: "孩子们", text: "圆饼切成许多块，一块沉海，一块上山。一块给火，一块给风，最后一块，谁也找不见。" },
      { cgHide: true, show: LINE, who: "mingyue", expr: MY("surprised"), text: "……这首歌。" },
      { who: "claude", text: "你听过？" },
      { who: "mingyue", text: "听过。阿梅妈妈哄我睡觉的时候，也唱。只是，我一直以为，那是首讲点心的歌。" },
      { who: "claude", text: "圣典里，没有这首歌。" },
      { text: "她说得很慢。一首连教会都没有收录的歌，在无数个不识字的人的嘴里，传了不知多少代。" },
      { text: "克劳德忽然意识到，那面壁画上的五个方向，原来一直，被人用最朴素的方式，唱着。" },
      { who: "bailong", text: "龙，也会唱。唱得，不一样。" },
      { who: "claude", text: "哪里不一样？" },
      { who: "bailong", text: "最后一句。我们唱的是，『最后一块，大家都知道，但是不说』。" },
      { who: "mingyue", expr: MY("worried"), text: "……什么意思？" },
      { who: "bailong", text: "不知道。奶奶，教我的时候，就是这么，唱的。" },
      { text: "灯火沿着河流一般的路，缓缓向前。没有人再说话。只有孩子们的歌声，被风一小段一小段地，送向很远的地方。" },

      /* ---------- 四、霜渡 ---------- */
      { hide: "all", bg: "frostford", transition: "black", bgm: "ch07_town",
        text: "霜渡，是北境最后一个有渡口的镇子。" },
      { text: "一条宽阔的、泛着青灰色的河，横在镇子北面。河那边，就是被称为龙脊的山脉。再往前，没有路了，只有山。" },
      { text: "她们赶到的时候，天色已经全黑。渡口的灯火亮着，船却全部拴在岸边，缆绳绷得紧紧的，像一排被摁住的牲口。" },
      { show: LINE, speaker: "渡口老汉", text: "今夜不渡。" },
      { text: "说话的人，是一位身形粗壮、胡子上结着冰碴的老汉。他蹲在栈桥上，背对着她们，声音哑得像被河水泡过。" },
      { who: "mingyue", text: "为什么？河又没有冻上！" },
      { speaker: "渡口老汉", text: "夜里，冰层会裂。裂的时候，有声音。不是冰的声音。" },
      { text: "他终于转过身。那是一张被风霜刻满了皱纹的脸，眼眶是红的。他的目光，落在克劳德怀中那本圣典的烫金封面上，停了很久。" },
      { speaker: "渡口老汉", text: "……你们，是教会的人吗？" },
      { who: "claude", text: "……曾经是。" },
      { speaker: "渡口老汉", text: "那也行。" },
      { text: "他一下子站了起来，膝盖在石板上磕出一声闷响。那个高大的男人，竟然，对着一个比他小了三十岁的姑娘，弯下了腰。" },
      { speaker: "渡口老汉", text: "我叫霍德。我女儿病了。上个月，教会把镇上所有的执事都调走了，说是为了『避免恐慌』。" },
      { speaker: "霍德", text: "恐慌……我的米拉，在烧。" },

      /* ---------- 五、米拉 ---------- */
      { hide: "all", bg: "sickroom", transition: "black", bgm: "ch07_sick",
        text: "那是一间小小的、窗上结满冰花的屋子。" },
      { text: "冰花是从里面长出来的。从窗框，从床沿，从那个女孩露在被子外的手指尖，一路向外爬，像一场缓慢的、安静的野火。" },
      { sfx: "ice", text: "九岁的米拉躺在床上，脸烧得通红，额头滚烫。呼出的白雾落在被角上，凝成了一小片一小片的霜。" },
      { text: "热的是身体，冷的是魔法。这就是人们口中的『共鸣热』。" },
      { speaker: "霍德", text: "镇上，已经有十七个了。都是旧血的人家。孩子最多。" },
      { show: LINE },
      { who: "mingyue", expr: MY("worried"), text: "……她在说什么？" },
      { text: "米拉的嘴唇一张一合，声音很轻。克劳德俯下身，才听清那是一句，反反复复的话。" },
      { speaker: "米拉", text: "……不要走……不要走……好亮……不要走……" },
      { who: "claude", text: "她在，叫谁？" },
      { speaker: "霍德", text: "不知道。她娘走得早。她这些天，一直这么喊，不是在叫我。" },
      { text: "克劳德直起身。圣典在她怀里，沉甸甸的，像一块被体温焐热的石头。" },
      { text: "她知道该怎么做。十年里，她为不知多少个人做过。那是教会交给每一位圣女的第一课：「安魂礼」。" },
      { text: "只是，在圣典褪色的墨迹之下，她读到过另一层字迹。从那之后，她每一次翻开那一页，手指都会，停一下。" },

      { text: "「怎么办」的答案，有三个。",
        choices: [
          { text: "依圣典，诵读「安魂礼」", jump: "ch07_rite", set: { method: "rite" } },
          { text: "请溟月，唱那半首歌", jump: "ch07_song", set: { method: "song" } },
          { text: "让白泷，把那团光「收走」", jump: "ch07_hoard", set: { method: "hoard" } }
        ] },

      /* ----- A. 安魂礼 ----- */
      { label: "ch07_rite" },
      { who: "claude", text: "……我来。" },
      { text: "克劳德在床边跪下，翻开圣典。她的声音，是十年里被磨得最稳的东西，稳得像刻在石碑上的字。" },
      { who: "claude", text: "「以日轮之名，使灼者安，使涌者息。使一切越过边界的，各归其位。」" },
      { sfx: "ice", text: "窗上的冰花，一朵一朵地，向后退去。像潮水，慢慢地，缩回了自己的海。" },
      { text: "米拉的呼吸平稳了下来。额头的红潮褪去，指尖不再凝霜。她睁开了眼睛。" },
      { speaker: "米拉", text: "……爸爸。我不冷了。" },
      { speaker: "霍德", text: "米拉！米拉……" },
      { text: "那个高大的男人，一下子，把脸埋进了女儿的被子里，肩膀一下一下地抖。" },
      { text: "克劳德低头看着圣典。在这一刻，她看见了。一缕极细极细、几乎看不见的光，从米拉的胸口升起，向着窗外，向着北方，伸展出去。" },
      { text: "然后，在『各归其位』那四个字落下的瞬间，那缕光，像一根被剪刀剪断的发丝，轻轻地，落了下来。" },
      { set: { cutknown: true }, text: "页角的墨迹，在她眼前，一寸一寸褪去。露出了下面那层更旧的字，只有一个字，写在这一页的页眉。" },
      { text: "「断」。" },
      { who: "mingyue", expr: MY("worried"), text: "……她不哭了。" },
      { who: "claude", text: "因为，她不疼了。" },
      { who: "mingyue", text: "小孩子，发了这么久的烧，好了，应该哭一场的。她为什么，一点声音都没有？" },
      { text: "克劳德没有回答。她看着米拉安静地向父亲伸出手，又安静地缩回去，像一个被擦拭得很干净的杯子。" },
      { text: "不疼，和不再需要被谁听见，是两件事。她在心里，第一次，把这两件事，分开了。" },
      { jump: "ch07_after_cure" },

      /* ----- B. 鲸歌 ----- */
      { label: "ch07_song" },
      { who: "claude", text: "溟月。" },
      { who: "mingyue", expr: MY("worried"), text: "……我只会半首。而且，我不知道唱出来，会招来什么。" },
      { who: "claude", text: "比她现在的样子更糟的，不多。" },
      { who: "mingyue", text: "……你这个人，讲话真的很讨厌。" },
      { text: "溟月在床边坐下，把那条鱼尾般的尾尖，轻轻搭在了床沿。她闭上眼睛，张开嘴。" },
      { text: "那不是任何一首渔歌。没有词，只有一条很长很长的、在水里慢慢游的调子。像远处有一头巨大的什么，在深海里翻了个身。" },
      { sfx: "ice", text: "窗上的冰花开始融化。一滴，两滴，顺着玻璃，慢慢地滑下来，像在哭。" },
      { text: "米拉的嘴唇，也跟着动了起来。她在睡梦里，哼出了同一个调子。她哼得，比溟月更完整。" },
      { speaker: "米拉", text: "……是谁家的，孩子……" },
      { who: "mingyue", expr: MY("surprised"), text: "……！" },
      { text: "那一瞬间，窗外，北方的天际，远远地亮了一下。很短，像一次眨眼。可是整座霜渡，都看见了。" },
      { text: "米拉的呼吸，终于平稳了。她还在哼着，一边哼，一边睡熟了。" },
      { who: "mingyue", expr: MY("shy"), text: "……耳朵，嗡嗡的。头，也晕。" },
      { who: "claude", text: "辛苦了。" },
      { who: "mingyue", text: "……你、你不用，突然这么客气！很奇怪！" },
      { text: "霍德跪在床前，没有说谢，只是，把额头，抵在了溟月的鞋尖上。溟月吓得，差点跳起来。" },
      { speaker: "霍德", text: "……您们，是光的使者吗？" },
      { who: "mingyue", expr: MY("angry", "shake"), text: "才不是！我是来蹭饭的！" },
      { jump: "ch07_after_cure" },

      /* ----- C. 白泷「收走」 ----- */
      { label: "ch07_hoard" },
      { who: "claude", text: "白泷。……这个，你能不能，拿走？" },
      { who: "bailong", text: "……" },
      { text: "白泷走到床边，低头看了很久。那一小团从米拉胸口渗出来的、淡金色的光，在她的瞳孔里，映出一个一个细小的、跳动的点。" },
      { who: "mingyue", expr: MY("surprised"), text: "你不是，从来，不拿别人的东西吗？" },
      { who: "bailong", text: "龙，不抢睡着的东西。" },
      { who: "bailong", text: "这个，不是睡着的。是在，哭。" },
      { text: "她伸出手，覆在米拉滚烫的额头上。动作很轻，轻得像在替一朵花，挡风。" },
      { who: "bailong", text: "太亮了。放我这里。" },
      { sfx: "ice", text: "金色的光点，一粒一粒，从米拉的眉心升起，流进了白泷的掌心。窗上的冰花，在同一时刻，碎成了无数闪亮的粉末。" },
      { set: { bl_ember: true }, text: "米拉的脸色，一点点淡了下来。白泷的发梢，却一点点，染上了淡淡的金色。" },
      { who: "bailong", text: "……烫。" },
      { who: "claude", expr: CL("worried"), text: "白泷？" },
      { who: "bailong", text: "没事。就是，饱了。" },
      { text: "她说完这句话，整个人一软，就这样，在床边的地板上，坐着睡着了。呼吸平稳，睫毛上，还沾着一点碎金。" },
      { who: "mingyue", expr: MY("surprised"), text: "她、她吃了什么？！你们这些人为什么都不跟我商量！" },
      { text: "克劳德把白泷抱起来的时候，发现她比想象的，还要轻。像抱着一个，刚刚晒过太阳的、很大的枕头。" },
      { jump: "ch07_after_cure" },

      { label: "ch07_after_cure" },
      { text: "霍德把她们安排在镇上唯一的旅店里。夜深了，镇上的灯火，一盏一盏地熄灭，只有河面，偶尔传来一声闷闷的、像从很远的地方传来的冰裂声。" },

      /* ---------- 六、旅店里的两位老熟人 ---------- */
      { hide: "all", bg: "inn_hall", transition: "fade", bgm: "ch07_town",
        text: "旅店的大厅里，只剩下一张桌子还亮着灯。" },
      { text: "桌边坐着两个人。一个正在专心致志地数着铜币，一个正在专心致志地吃着炖肉。" },
      { show: LINE, who: "raymond", text: "……奥利。这碗炖肉，三个铜币。" },
      { who: "oli", text: "执事大人，这是第四碗了。" },
      { who: "raymond", text: "所以，这是『第四碗炖肉的三个铜币』。报销单上，要分开写。" },
      { who: "claude", expr: CL("surprised"), text: "……。" },
      { text: "克劳德下意识地，把兜帽往下拉了一寸。溟月已经本能地，一把按住了身后白泷的肩膀。" },
      { who: "oli", text: "……执事大人。" },
      { who: "raymond", text: "怎么？" },
      { who: "oli", text: "那边，进来了三个人。其中一个，白头发。" },
      { who: "raymond", text: "北境人老得早。" },
      { who: "oli", text: "另一个，戴着兜帽，抱着一本烫金的圣典。" },
      { who: "raymond", text: "也许是，巡游的修女。" },
      { who: "oli", text: "第三个，头上，长着鳍。" },
      { who: "raymond", text: "（放下勺子）奥利。你听好了。教会的执事，最重要的一项素质，是什么？" },
      { who: "oli", text: "……坚定？" },
      { who: "raymond", text: "不。是『眼神不好』。" },
      { text: "他说完，端起碗，非常专注地，把脸埋了进去。" },

      { if: { saved: true },
        text: "克劳德在原地站了一会儿。她想起了山坡上的那条鱼，想起了雷蒙梦里那句嘟囔的「龙不咬人」。" },
      { if: { saved: true },
        who: "raymond", text: "（头也不抬）今晚，什么人也没有见到。请自便。" },
      { if: { exposed: true },
        who: "oli", text: "……执事大人，总部那边，昨天来信了。说，有人在海边见过『圣女』。" },
      { if: { exposed: true },
        who: "raymond", text: "传闻，不是证据。证据，需要证人。证人，需要出差。出差……我现在，很累。" },
      { who: "oli", text: "……我觉得，这样，下去，我们会被开除的。" },
      { who: "raymond", text: "那就等被开除了，再说。" },

      /* ---------- 七、信 ---------- */
      { hide: "all", bg: "inn_hall", transition: "cut",
        text: "她们刚刚在楼上安顿下来，就有人敲了门。" },
      { text: "是一个穿着灰色长外套的陌生人。不带武器，不报姓名，只是递上一封信，说了一句「请务必亲手交给克劳德小姐」，转身就走，像一滴水，融进了走廊的黑暗里。" },
      { show: LINE, text: "信封很普通，封蜡上压着一枚日轮。克劳德只看了一眼，就知道，那不是普通的日轮。它的光芒，缺了一道。" },
      { who: "mingyue", text: "写的什么？" },
      { text: "「明夜钟响之前，旧礼拜堂。我不带剑，也不带人。」" },
      { text: "「关于圣典下面的那一层字，我可以，给您另外一半。　——塞缪尔·维恩，圣堂裁决官」" },
      { who: "mingyue", expr: MY("angry"), text: "什么『另外一半』！他怎么知道你读到了——" },
      { who: "claude", text: "他知道。" },
      { who: "claude", text: "知道，就说明，这个人，比雷蒙那种人，要危险得多。" },
      { who: "bailong", text: "我，不喜欢，这个信。" },
      { who: "claude", text: "为什么？" },
      { who: "bailong", text: "闻起来，像，空的。" },

      { hide: "all", bg: "inn_hall", transition: "cut",
        text: "第二天，霜渡的人们，说的全是同一件事。" },
      { if: { method: "rite" },
        text: "「圣女显灵了。」米拉已经能下床，规规矩矩地喝汤，不再哼歌。镇上的人都在夸她乖，只有克劳德，听不得这个字。" },
      { if: { method: "song" },
        text: "米拉哼着那首只有半句的歌，把半个镇子都吵醒了。霍德抱着她，一边笑，一边偷偷用袖子擦脸。夜里，守光会的人，开始朝霜渡聚拢。" },
      { if: { method: "hoard" },
        text: "白泷是半个时辰之后，自己醒的。她睁开眼，第一句话是：「饿。」第二句话是：「我，是不是，亮了？」溟月说：「你现在，像一盏会走路的灯。」" },
      { if: { method: "hoard" },
        text: "白发的发梢上，那一点淡金色，一整天都没有褪。她很喜欢。每走过一面窗，都要停下来，认真地看一会儿自己的倒影。" },
      { show: LINE, text: "傍晚，米拉睡熟了。霜渡的钟，快要响了。",
        choices: [
          { text: "一个人去赴约", jump: "ch07_alone", set: { samuel: "alone" } },
          { text: "叫上溟月和白泷一起去", jump: "ch07_together", set: { samuel: "together" } },
          { text: "不去。把信丢进炉子里", jump: "ch07_ignored", set: { samuel: "ignored" } }
        ] },

      /* ----- 一个人去 ----- */
      { label: "ch07_alone" },
      { hide: "all", bg: "old_chapel", transition: "black", bgm: "ch07_chapel",
        text: "旧礼拜堂，在霜渡的最北端。" },
      { text: "屋顶塌了一半，月光和雪，一同从缺口里落下来，落在满地的长椅残骸上，安静得像一场葬礼的前夜。" },
      { sfx: "bell", text: "钟，响了一声。" },
      { text: "祭坛前，坐着一个男人。三十出头，眉目温和，像一位乡村学校里最受孩子喜欢的教师。他的面前，摆着一张小桌，桌上，有一壶茶，和两只杯子。" },
      { who: "samuel", text: "您来了。茶，还热着。" },
      { who: "claude", text: "……你只摆了两只杯子。" },
      { who: "samuel", text: "我相信，您会一个人来。" },
      { who: "claude", text: "这是一个，相当冒险的判断。" },
      { who: "samuel", text: "不。这是我读过您的履历之后，得出的结论。" },
      { text: "克劳德在他对面坐下，没有碰茶杯。那个男人的日轮徽记，在月光下，缺着一道光。" },
      { who: "samuel", text: "您读到了圣典下面的那一层，对吗？" },
      { who: "claude", text: "「莫信『自愿』二字。」" },
      { who: "samuel", text: "是的。写下它的人，和烧掉它的人，是同一批人。" },
      { who: "samuel", text: "您一定在想，教会，是个骗子。" },
      { who: "claude", text: "……我在想的，比这个，更具体。" },
      { who: "samuel", text: "那么，请允许我说。是的，我们撒谎。并且，我仍然认为，对十七个发烧的孩子来说，谎言，比真相，更合适。" },
      { text: "他把茶，缓缓斟满，没有看她。" },
      { who: "samuel", text: "线，连着的时候，神的梦，会顺着线，流下来。流进一个九岁孩子的身体。" },
      { who: "samuel", text: "她会先发热。然后，开始说不属于她的话。再然后，有一天，她会因为太亮，而熄灭。" },
      { who: "samuel", text: "我，见过两千三百个。" },
      { who: "claude", text: "所以，教会，剪线。" },
      { set: { cutknown: true }, who: "samuel", text: "是的。安魂礼的另一个名字，叫『断』。代价是，他们不再做梦。" },
      { who: "claude", text: "……米拉，也是。" },
      { who: "samuel", text: "她活着。这是我能保证的全部。" },
      { text: "沉默了一会儿。风穿过破碎的屋顶，把烛火吹得，一下，一下，向同一边倒。" },
      { who: "claude", text: "你呢？" },
      { who: "samuel", text: "我？我七岁那年，被剪的。我已经不记得，做梦，是什么感觉了。" },
      { who: "samuel", text: "所以，您不必担心，我会因为同情，而心软。" },
      { who: "claude", text: "……你说这句话的时候，是在，替我担心吗？" },
      { who: "samuel", text: "（微笑）您比传闻里，更敏锐。" },
      { who: "samuel", text: "冬至那一天，教会会在王都，举行『收束礼』。比安魂礼，大得多。足以让每一块碎片，重新安静。" },
      { who: "samuel", text: "唯一有资格站在礼台中央的人，是您。" },
      { who: "claude", text: "如果，我不去？" },
      { who: "samuel", text: "那么，到冬至那一天，所有还连着线的人，会比现在，烧得更厉害。" },
      { who: "samuel", text: "请不要把这句话，当作威胁。我只是，在报告气象。" },
      { text: "克劳德终于，端起了那只杯子。茶，已经凉了。她没有喝，只是，用指尖，感受那一点残留的温度。" },
      { who: "claude", text: "龙脊之后。我给你答案。" },
      { who: "samuel", text: "……龙脊。" },
      { text: "他停顿了一下。很短，短得像一个人，在黑暗里，数了一次心跳。" },
      { who: "samuel", text: "好。我等您，到冬至。" },
      { jump: "ch07_ferry" },

      /* ----- 一起去 ----- */
      { label: "ch07_together" },
      { hide: "all", bg: "old_chapel", transition: "black", bgm: "ch07_chapel",
        text: "旧礼拜堂，在霜渡的最北端。三个人，一同走进去的时候，钟，刚好响了一声。" },
      { sfx: "bell", text: "祭坛前的小桌上，摆着一壶茶，四只杯子。" },
      { show: LINE, who: "samuel", text: "诸位，晚上好。我准备了四份。" },
      { who: "mingyue", expr: MY("angry"), text: "你！你怎么知道，我们会一起来？！" },
      { who: "samuel", text: "因为，如果是我，也不会让一个人，去见一个自称不带剑的陌生人。" },
      { who: "bailong", text: "（已经拿起了一块茶点）……好吃。" },
      { who: "samuel", text: "（有点意外）……多谢夸奖。" },
      { text: "男人的目光，在白泷身上停了一息。很短，像在认一个很久没有见过的字。" },
      { who: "samuel", text: "龙族的后裔，竟然，肯与人同行。这很难得。" },
      { who: "bailong", text: "你。没有，味道。" },
      { who: "samuel", text: "什么味道？" },
      { who: "bailong", text: "做梦的。" },
      { who: "samuel", text: "……是的。很多人，都这么说。" },
      { text: "他把话，说得很慢，也很干净。线，神的梦，发热的孩子，两千三百个。以及，他自己，七岁那年，被剪断的那一天。" },
      { who: "mingyue", expr: MY("angry"), text: "那你们问过，他们愿不愿意，被剪吗？！" },
      { who: "samuel", text: "米拉的父亲，在我门口，跪了一夜。我问过。" },
      { who: "mingyue", expr: MY("worried"), text: "……。" },
      { set: { cutknown: true }, text: "溟月没有再说话。她把嘴唇抿得很紧，像要把一句没有想好的话，咬住。" },
      { who: "samuel", text: "冬至那一天，教会会在王都举行『收束礼』。比安魂礼，大得多。足以让每一块碎片，重新安静。" },
      { who: "claude", text: "你想让我，站在礼台的中央。" },
      { who: "samuel", text: "是。这是我今晚，唯一的请求。" },
      { who: "claude", text: "龙脊之后。我给你答案。" },
      { who: "samuel", text: "……龙脊。" },
      { who: "samuel", text: "好。我等你们，到冬至。" },
      { who: "bailong", text: "（含着茶点）还有，吗？" },
      { who: "samuel", text: "……我让人，给您包起来。" },
      { jump: "ch07_ferry" },

      /* ----- 不去 ----- */
      { label: "ch07_ignored" },
      { hide: "all", bg: "inn_hall", transition: "black", bgm: "ch07_town",
        text: "信，被丢进了炉子里。火苗舔了一下封蜡上的日轮，那缺了一道光的纹样，在火里，慢慢地蜷了起来。" },
      { show: LINE, who: "mingyue", expr: MY("normal"), text: "……真的不去？" },
      { who: "claude", text: "他想让我，听他讲一个故事。而我今晚，不想听任何人的故事。" },
      { who: "claude", text: "我想听的，是我自己，在想什么。" },
      { who: "bailong", text: "（点头）嗯。信，不好吃。" },
      { text: "炉火噼啪，响了一夜。钟声在远处响起，又在某个没有人去赴的约定里，慢慢散去。" },
      { jump: "ch07_ferry" },

      /* ---------- 八、渡河 ---------- */
      { label: "ch07_ferry" },
      { hide: "all", bg: "ferry_dawn", transition: "black", bgm: "ch07_ferry",
        text: "天亮的时候，河上的冰裂声，终于停了。" },
      { show: LINE, speaker: "霍德", text: "走吧。这一趟，不收钱。" },
      { who: "mingyue", text: "不行！该收的要收！" },
      { speaker: "霍德", text: "那就，收一包鱼干。" },
      { who: "mingyue", expr: MY("normal"), text: "……成交。" },
      { text: "渡船缓缓离开了岸。河水是深灰色的，在晨光里一寸一寸，泛出细碎的银。" },

      { if: { method: "rite" },
        text: "岸上，米拉站在父亲身边，规规矩矩地看着船离开。她没有挥手。她只是，站着。" },
      { if: { method: "song" },
        text: "岸上，米拉被父亲抱在怀里，把手举得高高的，一边挥，一边哼。那首只有半句的歌，被晨风吹散，又被她一遍一遍，捡回来。" },
      { if: { method: "song" },
        who: "mingyue", expr: MY("shy"), text: "……哼错了。第二个音，应该，往下一点。" },
      { if: { method: "hoard" },
        text: "岸上，米拉站在父亲身边，把手举得高高的。她的掌心，有一小片没有融化的冰花，在朝阳里，泛着很淡很淡的金色。" },
      { if: { method: "hoard" },
        who: "bailong", text: "……那是，我的。" },
      { if: { method: "hoard" },
        who: "mingyue", text: "你不是说，不抢吗！" },
      { if: { method: "hoard" },
        who: "bailong", text: "是，她送我的。" },

      { text: "船行到河心的时候，雾，忽然散开了一线。" },
      { text: "对岸的天际线上，山脉的轮廓，一节一节地隆起。山脊，起伏，缓慢，沉默，像一头俯卧在大地上的巨兽的脊骨。" },
      { text: "山的最高处，那一线孤独的光，已经不再孤独。它从云里升起来，像一根被谁立在天与地之间的、很细的白色的柱子。" },
      { who: "claude", expr: CL("surprised"), text: "……那就是，龙脊。" },
      { who: "bailong", text: "……是奶奶的背。" },
      { who: "mingyue", expr: MY("surprised"), text: "诶？那、那是山吧？" },
      { who: "bailong", text: "是山。也是奶奶。她睡着的时候，会变成，山。" },
      { text: "白泷第一次，没有笑。她把双手，慢慢地，揣进了袖子里，像在握住什么，很重的东西。" },
      { who: "bailong", text: "我，出来很久了。……不知道，她们，有没有，想我。" },
      { text: "船桨划开河水，发出很轻的声音。克劳德没有说话，只是，往她身边，靠近了一点点。" },

      { effect: "fadeOut", text: "船，缓缓靠近了北岸。" },

      /* ===== 章末：直接衔接第八章「龙脊」 ===== */
      { label: "ch07_end" }
    ]
  };
})();
