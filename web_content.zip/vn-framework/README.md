# 静默档案 · Web 视觉小说框架

纯前端（HTML + CSS + JavaScript），无任何依赖。剧本与素材配置全部在 `story.js`，引擎在 `script.js`，样式在 `style.css`。

> 当前 `story.js` 是第六章「潮退」。素材清单见 `ASSETS.md`，剧情与设定备忘见 `NOTES.md`。

## 本地运行

**方式 A（最简单）**：直接双击 `index.html`，用 Chrome / Edge / Firefox 打开即可。剧本是 `.js` 文件而不是 `.json`，所以 `file://` 下也能正常工作。

**方式 B（推荐，素材多时更稳）**：在本目录起一个本地服务器，然后访问 http://localhost:8000

```bash
python3 -m http.server 8000      # 或：npx serve .
```

VS Code 用户也可以安装 Live Server 插件，右键 `index.html` → Open with Live Server，改文件后自动刷新。

> 浏览器要求用户先点击一次页面才允许播放声音，所以引擎设计了标题页，点「新的档案」即完成这次授权。

## 目录结构

```
index.html      页面结构
style.css       档案室 / 冷峻科技风样式（设计分辨率 1280×720，自动等比缩放）
script.js       引擎（一般不用改）
story.js        ★ 剧本 + 角色 + 背景 + CG + 视频 + 音频配置，你主要改这里
assets/
  chars/<角色>/  立绘（PNG，透明背景）
  bg/            背景图（1280×720 或 1920×1080）
  cg/            全屏 CG
  video/         视频（mp4 / H.264 兼容性最好）
  audio/         bgm 与音效（mp3 / ogg）
```

**素材缺失时不会报错**：立绘显示线框占位人像（嘴型 / 眉形会随表情名变化，方便调试），背景与 CG 显示渐变底色，视频提示 `VIDEO NOT FOUND` 后自动继续，音频静默。放入真实文件后刷新即可。

## 剧本指令速查

`script` 是一个数组，每个元素是一"步"。一步里可同时写多个字段，执行顺序固定：

`set → chapter → bgm → hide → bg → show → expr → cg / cgHide → sfx → effect → video → wait → jump / end / choices / text`

含 `text` 的步会等待点击，其余步执行完自动进入下一步。

| 字段 | 示例 | 说明 |
|---|---|---|
| `text` | `text: "你好。\n第二行"` | 对话文本，打字机显示，`\n` 换行（对话框约容纳 3 行） |
| `who` | `who: "vera"` | 说话角色 id：显示其名字与头衔，并高亮其立绘、压暗其他人 |
| `speaker` | `speaker: "我"` | 直接指定显示名（没有立绘的人，如主角）；不写 `who` 与 `speaker` 即为旁白 |
| `bg` | `bg: "corridor"` | 切换背景 |
| `transition` | `"fade"`（默认）/ `"black"` / `"cut"` | 背景切换方式，与 `bg` 配合 |
| `show` | `show: {id:"vera", pos:"left", expr:"smile"}` 或数组 | 角色登场 / 移动；`pos`：`far-left` `left` `center` `right` `far-right`，或 `50`、`"35%"` |
| `expr` | `expr: {id:"vera", expr:"serious", anim:"nod"}` | **微表情切换**；`anim` 可选 `nod` `jump` `shake` |
| `hide` | `hide: "vera"` / `["a","b"]` / `"all"` | 角色退场 |
| `cg` | `cg: "cg_file"` | 显示全屏 CG（盖住背景与立绘，对话框仍在） |
| `cgHide` | `cgHide: true` | 关闭 CG，回到正常场景 |
| `video` | `video: "memory"` | 播放全屏视频，播完或点击跳过后自动继续 |
| `effect` | `effect: "shake"` 或数组 | `shake` 震屏 · `flash` 闪白 · `fadeOut` 渐黑 · `fadeIn` 恢复 |
| `chapter` | `chapter: {no:"CASE 01", title:"…", sub:"…"}` | 章节标题卡，同时更新左上角状态栏 |
| `bgm` / `sfx` | `bgm: "calm"` / `bgm: null` / `sfx: "door"` | 音乐（`null` 停止）/ 音效，id 对应 `story.js` 的 `audio` |
| `wait` | `wait: 800` | 等待毫秒数 |
| `label` / `jump` | `{label:"open"}` / `{jump:"open"}` | 标签与跳转 |
| `choices` | `choices: [{text:"…", jump:"a", set:{k:true}}]` | 选项；可同时写 `text`/`who` 作为提问句；选项内也可写 `if` |
| `set` / `if` | `set:{brave:true}` / `if:"brave"` / `if:"!brave"` | 剧情标记；`if` 不满足则跳过该步 |
| `end` | `end: {title:"TO BE CONTINUED", sub:"…"}` | 结束页 |

## 立绘与差分表情

在 `story.js` 的 `characters` 里任选一种：

**A. 整图替换**（最简单）：每个表情一张完整立绘

```js
vera: { name:"薇拉", title:"档案管理员", color:"#62d3e6", height:660,
        sprites: { normal:"assets/chars/vera/normal.png", smile:"assets/chars/vera/smile.png" } }
```

**B. 脸部差分叠加**（省资源，适合标准差分素材）：一张身体底图 + 若干张脸部小图，切表情时只换脸

```js
kai: { name:"凯", color:"#e0b64a", height:680,
       base: "assets/chars/kai/body.png",
       faces: { normal:{src:"assets/chars/kai/face_normal.png", x:"36%", y:"8%", w:"28%"},
                smirk: {src:"assets/chars/kai/face_smirk.png",  x:"36%", y:"8%", w:"28%"} } }
```

`x / y / w` 是脸部图相对身体底图的左 / 上 / 宽度（百分比）。两种方式都带 0.22 秒交叉淡入淡出。

## 操作

| 操作 | 效果 |
|---|---|
| 点击画面 / `空格` / `Enter` | 推进；打字中则先补全当前句 |
| 按住 `Ctrl` | 临时快进 |
| `A` / `S` | 自动播放 / 快进开关 |
| `H` 或滚轮上滚 | 历史记录 |
| `V` 或鼠标右键 | 隐藏 / 恢复界面 |
| `1`~`9` | 选择对应选项 |
| `Esc` | 关闭面板 |

存档共 6 个槽位，存在浏览器 `localStorage`（以 `meta.id` 区分不同作品，换剧本时请改 `meta.id`）。设置里可调文字速度、自动等待、字号、对话框透明度和音量。

## 调试

浏览器控制台：`VN.state()` 查看当前状态；`VN.jump("label名")` 直接跳到某个标签。引擎遇到未定义的角色 / 背景 / label 时会在控制台给出 `[VN]` 开头的警告。

## 小提示

- 立绘 PNG 建议高度 1400~1800px，引擎会按 `height` 缩放显示。
- 视频若不能自动带声音播放，引擎会自动退回静音播放。
- 想用 JSON 管理剧本：把 `story.js` 的内容另存为 `story.json`，再用 `fetch` 读取（需用方式 B 起本地服务器）。
- 手机竖屏下画面会整体缩小，建议横屏游玩。
