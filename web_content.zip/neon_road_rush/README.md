# Neon Road Rush — Endless Drive

A responsive browser-based arcade driving game built with plain HTML, CSS and JavaScript Canvas. No framework, build step, account, or API key is required.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser (Chrome or Edge recommended).
3. Press **Start Engine**. Audio begins only after you interact, because browsers restrict autoplay.
4. For the best desktop experience, open the folder in VS Code and use the Live Server extension, or run a local server from this folder:
   - Python installed: `python -m http.server 8000`
   - Visit `http://localhost:8000`

## Controls
- **W / ↑** accelerate
- **S / ↓** brake
- **A / ←** steer left
- **D / →** steer right
- **Esc** pause
- Touch controls are displayed on smaller screens.

## Features
- Endless pseudo-3D road, traffic, glowing collectible energy orbs and crash detection
- Six selectable cars with different handling/top-speed stats
- Four driver profiles
- Distance, speed, best-run tracking (saved locally in the browser)
- Built-in synthesized music generated with Web Audio API
- Play audio from your device using the file picker (the browser asks the user to select files; it cannot silently browse the device)
- Responsive layout and mobile controls
- 500 m challenge mission

## Notes / next upgrades
This is a playable prototype, not a full 3D game. For a more realistic 3D version, use Three.js or Babylon.js, add original 3D vehicle/road assets, and consider packaging as a PWA or Android app. Device music selection uses the browser's normal file-picker permission model.
