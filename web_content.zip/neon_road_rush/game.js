(() => {
const canvas = document.getElementById('game'), ctx = canvas.getContext('2d');
const $ = id => document.getElementById(id);
const W=900,H=600;
let state='menu', last=0, distance=0, speed=0, best=Number(localStorage.getItem('nrr-best')||0), coins=0, roadOffset=0, spawnTimer=0, coinTimer=0, traffic=[], orbs=[], particles=[];
let player={x:450,y:465,w:52,h:90, lane:1, steer:0};
let held={left:false,right:false,gas:false,brake:false}, selectedCar='red', selectedDriver='ace', soundOn=true, synthOn=false, audioCtx=null, master=null, musicNodes=[], musicTimer=null;
const carColors={red:'#ef365a',blue:'#21b9f4',green:'#73df58',gold:'#f5b942',purple:'#b16cff',white:'#d9e6f5'};
const carStats={red:[72,68],blue:[65,92],green:[92,74],gold:[70,100],purple:[85,83],white:[76,72]};
const carNames={red:'Crimson GT',blue:'Electric Vortex',green:'Toxic Runner',gold:'Solar Bullet',purple:'Night Phantom',white:'Arctic Drift'};
$('best').innerHTML=`${best} <em>m</em>`;
function rand(a,b){return Math.random()*(b-a)+a}
function drawRoad(dt){
  const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#17243b');g.addColorStop(.45,'#1a2435');g.addColorStop(1,'#0b101b');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  // distant skyline and horizon glow
  ctx.fillStyle='#111a2a';for(let i=0;i<28;i++){let x=i*38-((roadOffset*.15)%38),h=35+(i*47%95);ctx.fillRect(x,165-h,26,h)}
  const horizon=145, topL=335,topR=565,botL=40,botR=860;
  let rg=ctx.createLinearGradient(0,horizon,0,H);rg.addColorStop(0,'#333d4d');rg.addColorStop(1,'#1b202a');
  ctx.fillStyle=rg;ctx.beginPath();ctx.moveTo(topL,horizon);ctx.lineTo(topR,horizon);ctx.lineTo(botR,H);ctx.lineTo(botL,H);ctx.closePath();ctx.fill();
  // shoulders
  ctx.strokeStyle='#4de8f4';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(topL,horizon);ctx.lineTo(botL,H);ctx.moveTo(topR,horizon);ctx.lineTo(botR,H);ctx.stroke();
  // road edges and lane markers
  const perspective=t=>horizon+(H-horizon)*t;
  const roadLeft=t=>topL+(botL-topL)*t, roadRight=t=>topR+(botR-topR)*t;
  for(let lane=1;lane<=2;lane++){
    let xt=topL+(topR-topL)*lane/3, xb=botL+(botR-botL)*lane/3;
    for(let y=0;y<4;y++){
      let phase=((roadOffset*.75+y*.28)%1);let t=phase;
      const t2=Math.min(1,t+.11), yy=perspective(t), yy2=perspective(t2);
      const x1=xt+(xb-xt)*t, x2=xt+(xb-xt)*t2, width=1+t*5;
      ctx.strokeStyle='#e8f1ff';ctx.globalAlpha=.18+t*.65;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,yy);ctx.lineTo(x2,yy2);ctx.stroke();ctx.globalAlpha=1;
    }
  }
  // road speed streaks
  for(let i=0;i<18;i++){let y=(i*39+(roadOffset*3)%39)+170;let t=(y-145)/455;if(t>0&&t<1){let x=rand(0,1)<.5?roadLeft(t)-rand(8,60):roadRight(t)+rand(8,60);ctx.globalAlpha=.1;ctx.strokeStyle='#4de8f4';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+rand(-2,2),y+rand(8,26));ctx.stroke();ctx.globalAlpha=1}}
  // overhead glow
  let glow=ctx.createRadialGradient(450,150,5,450,150,350);glow.addColorStop(0,'#3aa7ff22');glow.addColorStop(1,'#3aa7ff00');ctx.fillStyle=glow;ctx.fillRect(0,0,W,H);
}
function roadX(lane,y){let t=Math.max(0,Math.min(1,(y-145)/455));let left=335+(40-335)*t,right=565+(860-565)*t;return left+(right-left)*(lane+.5)/3}
function drawCar(x,y,w,h,color,isPlayer=false){
  ctx.save();ctx.translate(x,y);
  if(isPlayer){ctx.shadowColor=color;ctx.shadowBlur=24}
  // shadow
  ctx.fillStyle='#0009';ctx.beginPath();ctx.ellipse(0,h*.43,w*.65,h*.17,0,0,Math.PI*2);ctx.fill();
  ctx.shadowBlur=isPlayer?20:4;ctx.shadowColor=color;
  ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(-w*.44,h*.42);ctx.lineTo(-w*.5,h*.05);ctx.lineTo(-w*.34,-h*.32);ctx.quadraticCurveTo(-w*.25,-h*.48,0,-h*.48);ctx.quadraticCurveTo(w*.25,-h*.48,w*.34,-h*.32);ctx.lineTo(w*.5,h*.05);ctx.lineTo(w*.44,h*.42);ctx.quadraticCurveTo(0,h*.52,-w*.44,h*.42);ctx.fill();
  ctx.shadowBlur=0;
  // windshield
  ctx.fillStyle='#142b43';ctx.beginPath();ctx.moveTo(-w*.29,-h*.23);ctx.quadraticCurveTo(0,-h*.38,w*.29,-h*.23);ctx.lineTo(w*.35,-h*.01);ctx.lineTo(-w*.35,-h*.01);ctx.closePath();ctx.fill();
  ctx.fillStyle='#80d9ed88';ctx.fillRect(-w*.29,-h*.19,w*.58,2);
  // hood accent
  ctx.fillStyle='#ffffff44';ctx.fillRect(-w*.035,h*.02,w*.07,h*.22);
  // lights
  ctx.fillStyle=isPlayer?'#d8ffff':'#fff2c2';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=10;ctx.fillRect(-w*.39,h*.28,w*.2,5);ctx.fillRect(w*.19,h*.28,w*.2,5);
  ctx.shadowBlur=0;ctx.fillStyle='#10131c';ctx.fillRect(-w*.53,-h*.12,w*.09,h*.25);ctx.fillRect(w*.44,-h*.12,w*.09,h*.25);
  if(isPlayer){ctx.fillStyle='#4de8f4';ctx.fillRect(-w*.31,h*.4,w*.62,3)}
  ctx.restore();
}
function drawOrb(o){ctx.save();ctx.shadowColor='#4de8f4';ctx.shadowBlur=22;ctx.fillStyle='#b9ffff';ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#4de8f4';ctx.lineWidth=3;ctx.beginPath();ctx.arc(o.x,o.y,o.r+5,0,Math.PI*2);ctx.stroke();ctx.restore()}
function draw(){
  drawRoad(0);
  traffic.sort((a,b)=>a.y-b.y).forEach(c=>drawCar(c.x,c.y,c.w,c.h,c.color));
  orbs.forEach(drawOrb);
  particles.forEach(p=>{ctx.globalAlpha=Math.max(0,p.life/35);ctx.fillStyle=p.color;ctx.fillRect(p.x,p.y,3,3);ctx.globalAlpha=1});
  drawCar(player.x,player.y,player.w,player.h,carColors[selectedCar],true);
  if(state==='running'){
    ctx.fillStyle='#ffffff88';ctx.font='700 12px Inter';ctx.fillText(selectedDriver.toUpperCase()+' / '+carNames[selectedCar].toUpperCase(),22,32);
    if(coins>0){ctx.fillStyle='#b8ffff';ctx.fillText('✦ '+coins,22,52)}
  }
}
function spawnTraffic(){
  const lane=Math.floor(rand(0,3)), colors=['#ffb84e','#9c7cff','#f35d75','#52c9c4','#d7e0ed'];
  traffic.push({lane,x:roadX(lane,175),y:170,w:rand(38,48),h:rand(65,83),color:colors[Math.floor(rand(0,colors.length))],passed:false});
}
function spawnOrb(){let lane=Math.floor(rand(0,3));orbs.push({lane,x:roadX(lane,175),y:175,r:8})}
function update(dt){
 if(state!=='running')return;
 const factor=dt/16.67, maxSpeed=carStats[selectedCar][1]*1.4+110;
 if(held.gas)speed=Math.min(maxSpeed,speed+1.2*factor);else speed=Math.max(155,speed-.28*factor);
 if(held.brake)speed=Math.max(0,speed-2.3*factor);
 const steering= (held.left?-1:0)+(held.right?1:0);
 player.x+=steering*(4.2+speed*.013)*factor;
 player.x=Math.max(80,Math.min(820,player.x));player.steer=steering;
 roadOffset+=speed*.00045*factor;
 distance+=speed*factor/500;
 $('distance').innerHTML=`${Math.floor(distance)} <em>m</em>`;$('speed').innerHTML=`${Math.round(speed)} <em>km/h</em>`;
 $('missionProgress').textContent=`${Math.min(500,Math.floor(distance))} / 500 m`;
 $('missionPercent').textContent=`${Math.min(100,Math.floor(distance/5))}%`;$('missionBar').style.width=`${Math.min(100,distance/5)}%`;
 if(distance>=500 && !$('missionText').dataset.done){$('missionText').dataset.done='1';$('missionText').textContent='Mission complete! You earned +250 XP.';toast('MISSION COMPLETE  +250 XP')}
 spawnTimer-=dt;coinTimer-=dt;
 if(spawnTimer<=0){spawnTraffic();spawnTimer=rand(700,1250)*Math.max(.5,1-speed/650)}
 if(coinTimer<=0){spawnOrb();coinTimer=rand(1400,2300)}
 const move=speed*.0035*factor;
 traffic.forEach(c=>{c.y+=move*1.1;c.x=roadX(c.lane,c.y);if(!c.passed&&c.y>player.y+40){c.passed=true;distance+=3}});
 traffic=traffic.filter(c=>c.y<H+100);
 orbs.forEach(o=>{o.y+=move*1.1;o.x=roadX(o.lane,o.y)});
 orbs=orbs.filter(o=>o.y<H+40);
 for(const c of traffic){if(Math.abs(c.x-player.x)<(c.w+player.w)*.42&&Math.abs(c.y-player.y)<(c.h+player.h)*.42){crash();break}}
 for(let i=orbs.length-1;i>=0;i--){const o=orbs[i];if(Math.abs(o.x-player.x)<38&&Math.abs(o.y-player.y)<55){coins++;distance+=15;toast('+15 m  •  ENERGY ORB');for(let j=0;j<12;j++)particles.push({x:o.x,y:o.y,vx:rand(-3,3),vy:rand(-3,3),life:35,color:'#4de8f4'});orbs.splice(i,1)}}
 particles.forEach(p=>{p.x+=p.vx*factor;p.y+=p.vy*factor;p.life-=factor});particles=particles.filter(p=>p.life>0);
}
function loop(t){const dt=Math.min(40,t-(last||t));last=t;update(dt);draw();requestAnimationFrame(loop)}
requestAnimationFrame(loop);
function start(){state='running';distance=0;speed=160;coins=0;traffic=[];orbs=[];particles=[];spawnTimer=200;coinTimer=800;player.x=450;$('overlay').classList.add('hidden');$('pauseBtn').textContent='Ⅱ Pause';$('statusText').textContent='ENGINE RUNNING';$('overlayTitle').innerHTML='OWN THE<br><span>OPEN ROAD.</span>';$('overlayText').textContent='Dodge traffic, collect energy coins and see how far you can go.'}
function crash(){if(state!=='running')return;state='over';best=Math.max(best,Math.floor(distance));localStorage.setItem('nrr-best',best);$('best').innerHTML=`${best} <em>m</em>`;$('overlay').classList.remove('hidden');$('overlayTitle').innerHTML='RUN<br><span>OVER.</span>';$('overlayText').textContent=`You drove ${Math.floor(distance)} m and collected ${coins} energy orbs. Best run: ${best} m.`;$('startBtn').innerHTML='DRIVE AGAIN <span>→</span>';$('statusText').textContent='RUN ENDED';}
function toast(s){const t=$('toast');t.textContent=s;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),1250)}
$('startBtn').addEventListener('click',()=>{if(state==='paused'){state='running';$('overlay').classList.add('hidden');$('pauseBtn').textContent='Ⅱ Pause';$('statusText').textContent='ENGINE RUNNING';return}start()});
$('pauseBtn').addEventListener('click',()=>{if(state==='running'){state='paused';$('pauseBtn').textContent='▶ Resume';$('statusText').textContent='PAUSED';$('overlay').classList.remove('hidden');$('overlayTitle').innerHTML='TAKE A<br><span>BREATHER.</span>';$('overlayText').textContent='Your run is paused. Ready to get back on the road?';$('startBtn').textContent='RESUME DRIVE →'}else if(state==='paused'){state='running';$('overlay').classList.add('hidden');$('pauseBtn').textContent='Ⅱ Pause';$('statusText').textContent='ENGINE RUNNING'}});
function setKey(k,v){if(k==='ArrowLeft'||k==='a'||k==='A')held.left=v;if(k==='ArrowRight'||k==='d'||k==='D')held.right=v;if(k==='ArrowUp'||k==='w'||k==='W')held.gas=v;if(k==='ArrowDown'||k==='s'||k==='S')held.brake=v}
addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();setKey(e.key,true);if(e.key==='Escape'&&state==='running')$('pauseBtn').click()});
addEventListener('keyup',e=>setKey(e.key,false));
document.querySelectorAll('[data-control]').forEach(b=>{const k=b.dataset.control;const down=e=>{e.preventDefault();held[k]=true};const up=e=>{e.preventDefault();held[k]=false};b.addEventListener('pointerdown',down);['pointerup','pointercancel','pointerleave'].forEach(ev=>b.addEventListener(ev,up))});
$('carSelect').addEventListener('change',e=>{selectedCar=e.target.value;$('previewCar').className='preview-car '+(selectedCar==='red'?'red-car':selectedCar+'-car');$('handlingMeter').style.width=carStats[selectedCar][0]+'%';$('speedMeter').style.width=carStats[selectedCar][1]+'%';toast(carNames[selectedCar]+' selected')});
$('driverSelect').addEventListener('change',e=>{selectedDriver=e.target.value;toast(selectedDriver.toUpperCase()+' profile selected')});
function ensureAudio(){if(!audioCtx){audioCtx=new (window.AudioContext||window.webkitAudioContext)();master=audioCtx.createGain();master.gain.value=soundOn?.18:0;master.connect(audioCtx.destination)}if(audioCtx.state==='suspended')audioCtx.resume()}
function stopSynth(){synthOn=false;if(musicTimer)clearInterval(musicTimer);musicTimer=null;musicNodes.forEach(n=>{try{n.stop()}catch(e){}});musicNodes=[];$('musicBtn').textContent='▶ Play music';$('equalizer').classList.remove('playing')}
function startSynth(){ensureAudio();stopSynth();synthOn=true;$('trackName').textContent='Neon Pulse';$('trackStatus').textContent='Built-in synth loop';$('musicBtn').textContent='Ⅱ Stop music';$('equalizer').classList.add('playing');let step=0;const notes=[110,164.81,220,164.81,130.81,196,261.63,196];musicTimer=setInterval(()=>{if(!synthOn)return;ensureAudio();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type=step%4===0?'triangle':'sine';osc.frequency.value=notes[step%notes.length];gain.gain.setValueAtTime(.0001,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.13,audioCtx.currentTime+.03);gain.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+.36);osc.connect(gain);gain.connect(master);osc.start();osc.stop(audioCtx.currentTime+.4);musicNodes.push(osc);step++},300)}
$('musicBtn').addEventListener('click',()=>{const audio=$('deviceAudio');if(audio.src&&!audio.paused){audio.pause();$('musicBtn').textContent='▶ Play music';$('equalizer').classList.remove('playing');return}if(synthOn){stopSynth();return}if(audio.src){audio.play().then(()=>{$('musicBtn').textContent='Ⅱ Stop music';$('equalizer').classList.add('playing')}).catch(()=>toast('Tap again to allow audio'));return}startSynth()});
$('musicFile').addEventListener('change',e=>{const files=e.target.files;if(!files||!files.length)return;const file=files[0];$('deviceAudio').src=URL.createObjectURL(file);$('trackName').textContent=file.name.replace(/\.[^/.]+$/,'');$('trackStatus').textContent=files.length>1?`${files.length} tracks • playing first`:'From your device';stopSynth();$('deviceAudio').play().then(()=>{$('musicBtn').textContent='Ⅱ Stop music';$('equalizer').classList.add('playing')}).catch(()=>toast('Tap Play music to start your track'));});
$('soundBtn').addEventListener('click',()=>{soundOn=!soundOn;if(master)master.gain.value=soundOn?.18:0;$('soundBtn').textContent=soundOn?'♫ Sound':'♫ Muted';if(!soundOn){$('deviceAudio').volume=0}else{$('deviceAudio').volume=1}});
$('deviceAudio').volume=1;
function resize(){const rect=canvas.getBoundingClientRect();const dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
// Keep the logical game world at 900 x 600 while rendering sharply on high-DPI screens.
window.addEventListener('resize',resize);resize();
})();