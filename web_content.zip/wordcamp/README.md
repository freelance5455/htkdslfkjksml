# Word Camp

Offline vocabulary flashcard app. One file (`www/index.html`), no libraries.
All data is stored in IndexedDB on the device (database name: `wordcamp`).

## Run in a browser
Open `www/index.html`, or serve the `www` folder with any static server.

## Build an Android APK (Capacitor)
Requires Node.js and Android Studio.

    npm init -y
    npm install @capacitor/core @capacitor/cli @capacitor/android
    npx cap add android
    npx cap sync
    npx cap open android      # then Build > Build APK(s) in Android Studio

Notes:
- Keep `"androidScheme": "https"` in capacitor.config.json. It gives the app a
  stable origin, so IndexedDB data survives app restarts and updates.
- Do not load the app from file:// in a plain WebView.
- Clearing app storage or uninstalling deletes the data. Use Account > Backup first.
- Backup: if "Download file" does nothing on your device, use Copy and save the text.
  For file saving, add @capacitor/filesystem and @capacitor/share.
