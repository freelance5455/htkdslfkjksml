import { AlertItem, AlertPriorityInfo, AlertPriorityLevel } from '../types';

export const ALERT_PRIORITIES: Record<AlertPriorityLevel, AlertPriorityInfo> = {
  1: {
    level: 1,
    name: 'Level 1: Official Emergency / Warning',
    badge: 'Official Emergency',
    description: 'Confirmed official emergency warning from national civil defense or GDACS Red Alert.',
    color: '#ef4444',
    textColor: 'text-red-400',
    borderColor: 'border-red-500',
    bgColor: 'bg-red-950/70'
  },
  2: {
    level: 2,
    name: 'Level 2: Official Advisory',
    badge: 'Official Advisory',
    description: 'Active advisory for developing weather or regional hazard (GDACS Orange Alert).',
    color: '#f97316',
    textColor: 'text-orange-400',
    borderColor: 'border-orange-500',
    bgColor: 'bg-orange-950/70'
  },
  3: {
    level: 3,
    name: 'Level 3: Verified Disaster Event',
    badge: 'Verified Event',
    description: 'Instrumentally verified seismic or geological event from official USGS/GDACS networks.',
    color: '#eab308',
    textColor: 'text-amber-400',
    borderColor: 'border-amber-500',
    bgColor: 'bg-amber-950/70'
  },
  4: {
    level: 4,
    name: 'Level 4: Satellite Observation',
    badge: 'Satellite Observation',
    description: 'Satellite thermal detection. Important: Satellite observation — not a confirmed emergency.',
    color: '#ca8a04',
    textColor: 'text-yellow-400',
    borderColor: 'border-yellow-600',
    bgColor: 'bg-yellow-950/70'
  },
  5: {
    level: 5,
    name: 'Level 5: Informational / Cached Data',
    badge: 'Cached Telemetry',
    description: 'Previously synchronized telemetry stored in device cache for offline availability.',
    color: '#94a3b8',
    textColor: 'text-slate-400',
    borderColor: 'border-slate-700',
    bgColor: 'bg-slate-850'
  }
};

export function getAlertPriority(alert: AlertItem, isOfflineMode: boolean = false): AlertPriorityInfo {
  // If the alert is an offline cached item and the app is offline or the item was loaded from storage:
  if (alert.isCached || isOfflineMode) {
    return ALERT_PRIORITIES[5];
  }

  if (alert.source === 'nasa_firms') {
    return ALERT_PRIORITIES[4];
  }

  if (alert.severity === 'critical' || alert.source === 'pmd_ndma') {
    return ALERT_PRIORITIES[1];
  }

  if (alert.severity === 'warning') {
    return ALERT_PRIORITIES[2];
  }

  return ALERT_PRIORITIES[3];
}
