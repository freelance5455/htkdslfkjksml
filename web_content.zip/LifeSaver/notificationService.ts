import { AlertItem } from '../types';
import { getAlertPriority } from '../utils/priorityUtils';

// Track already notified alert IDs in this session
const notifiedAlertIds = new Set<string>();

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.requestPermission();
}

export function getNotificationPermission(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

export function checkAndNotifyNewAlerts(
  incomingAlerts: AlertItem[],
  minSeverityForNotification: 'critical' | 'warning' | 'all' = 'warning'
) {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return;
  }

  if (Notification.permission !== 'granted') {
    return;
  }

  // Filter alerts that haven't been notified yet
  for (const alert of incomingAlerts) {
    if (notifiedAlertIds.has(alert.id)) {
      continue;
    }

    // Check severity threshold
    const isCritical = alert.severity === 'critical';
    const isWarning = alert.severity === 'warning';

    if (minSeverityForNotification === 'critical' && !isCritical) {
      continue;
    }
    if (minSeverityForNotification === 'warning' && !isCritical && !isWarning) {
      continue;
    }

    const priorityInfo = getAlertPriority(alert, false);

    // Classification text
    let classification = 'Verified Disaster Event';
    if (alert.source === 'nasa_firms') {
      classification = 'Satellite Observation (Not Confirmed Emergency)';
    } else if (alert.severity === 'critical') {
      classification = 'Official Emergency / Warning';
    } else if (alert.severity === 'warning') {
      classification = 'Official Advisory';
    }

    const formattedTime = new Date(alert.timestamp).toLocaleTimeString();
    const title = `🚨 [${priorityInfo.badge}] ${alert.title}`;
    const body = `${classification}\n📍 Location: ${alert.locationName}\n⏱ Time: ${formattedTime}\n📡 Source: ${alert.sourceName}\n\nDisclaimer: Telemetry update — not an advance prediction. Follow local civil defense.`;

    try {
      new Notification(title, {
        body,
        icon: '/pwa-192x192.png',
        badge: '/favicon.ico',
        tag: alert.id,
        requireInteraction: isCritical
      });
      notifiedAlertIds.add(alert.id);
    } catch (e) {
      console.warn('Browser notification failed:', e);
    }
  }
}
