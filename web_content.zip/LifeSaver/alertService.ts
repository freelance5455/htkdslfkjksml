import { AlertItem, AlertSeverity, DisasterType, UserLocation, FeedStatus, SourceHealth, AlertSourceType } from '../types';

export const OFFICIAL_PAKISTAN_FEED_STATUS = {
  connected: false,
  message: "Official Pakistan feed not connected yet.",
  reason: "National Disaster Management Authority (NDMA) & Pakistan Meteorological Department (PMD) do not currently provide a public machine-readable RSS/GeoJSON feed API. LifeSaver never invents or simulates official national alerts.",
  helpline: "1129",
  helplineName: "NDMA Disaster Helpline (UAN 1129)"
};

// Calculate great circle distance in kilometers (Haversine)
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Radius of the earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Preset cities for manual location selection
export const PRESET_CITIES: UserLocation[] = [
  { name: 'Islamabad, Pakistan', lat: 33.6844, lng: 73.0479, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Karachi, Pakistan', lat: 24.8607, lng: 67.0011, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Lahore, Pakistan', lat: 31.5204, lng: 74.3587, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Peshawar, Pakistan', lat: 34.0151, lng: 71.5249, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Quetta, Pakistan', lat: 30.1798, lng: 66.9750, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Rawalpindi, Pakistan', lat: 33.5651, lng: 73.0169, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Gilgit, Pakistan', lat: 35.9221, lng: 74.3087, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Multan, Pakistan', lat: 30.1575, lng: 71.5249, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Muzaffarabad, AJK', lat: 34.3700, lng: 73.4711, countryCode: 'PK', countryName: 'Pakistan', isGPS: false },
  { name: 'Tokyo, Japan', lat: 35.6762, lng: 139.6503, countryCode: 'JP', countryName: 'Japan', isGPS: false },
  { name: 'Istanbul, Turkey', lat: 41.0082, lng: 28.9784, countryCode: 'TR', countryName: 'Turkey', isGPS: false },
  { name: 'Jakarta, Indonesia', lat: -6.2088, lng: 106.8456, countryCode: 'ID', countryName: 'Indonesia', isGPS: false },
  { name: 'Manila, Philippines', lat: 14.5995, lng: 120.9842, countryCode: 'PH', countryName: 'Philippines', isGPS: false },
  { name: 'New Delhi, India', lat: 28.6139, lng: 77.2090, countryCode: 'IN', countryName: 'India', isGPS: false },
  { name: 'Dhaka, Bangladesh', lat: 23.8103, lng: 90.4125, countryCode: 'BD', countryName: 'Bangladesh', isGPS: false },
  { name: 'Riyadh, Saudi Arabia', lat: 24.7136, lng: 46.6753, countryCode: 'SA', countryName: 'Saudi Arabia', isGPS: false },
  { name: 'Dubai, UAE', lat: 25.2048, lng: 55.2708, countryCode: 'AE', countryName: 'United Arab Emirates', isGPS: false },
  { name: 'London, UK', lat: 51.5074, lng: -0.1278, countryCode: 'GB', countryName: 'United Kingdom', isGPS: false },
  { name: 'Paris, France', lat: 48.8566, lng: 2.3522, countryCode: 'FR', countryName: 'France', isGPS: false },
  { name: 'Berlin, Germany', lat: 52.5200, lng: 13.4050, countryCode: 'DE', countryName: 'Germany', isGPS: false },
  { name: 'Rome, Italy', lat: 41.9028, lng: 12.4964, countryCode: 'IT', countryName: 'Italy', isGPS: false },
  { name: 'San Francisco, USA', lat: 37.7749, lng: -122.4194, countryCode: 'US', countryName: 'United States', isGPS: false },
  { name: 'New York, USA', lat: 40.7128, lng: -74.0060, countryCode: 'US', countryName: 'United States', isGPS: false },
  { name: 'Sydney, Australia', lat: -33.8688, lng: 151.2093, countryCode: 'AU', countryName: 'Australia', isGPS: false },
  { name: 'Auckland, New Zealand', lat: -36.8485, lng: 174.7633, countryCode: 'NZ', countryName: 'New Zealand', isGPS: false },
  { name: 'São Paulo, Brazil', lat: -23.5505, lng: -46.6333, countryCode: 'BR', countryName: 'Brazil', isGPS: false },
  { name: 'Cairo, Egypt', lat: 30.0444, lng: 31.2357, countryCode: 'EG', countryName: 'Egypt', isGPS: false },
  { name: 'Nairobi, Kenya', lat: -1.2921, lng: 36.8219, countryCode: 'KE', countryName: 'Kenya', isGPS: false },
];

export interface LiveAlertsResponse {
  alerts: AlertItem[];
  isUnavailable: boolean;
  statusMessage?: string;
  feedStatus: FeedStatus;
  lastSyncTimestamp?: string | null;
  isFromCache?: boolean;
}

export function getLastAlertsSyncTimestamp(): string | null {
  try {
    return localStorage.getItem('lifesaver_cached_alerts_timestamp');
  } catch (_) {}
  return null;
}

// Initial source health statuses
export function createInitialFeedStatus(): FeedStatus {
  return {
    usgsConnected: false,
    gdacsConnected: false,
    firmsConnected: false,
    pakistanConnected: false,
    lastUpdated: null,
    sources: {
      usgs: {
        id: 'usgs',
        name: 'USGS Earthquake Hazards Program',
        category: 'Earthquakes / Seismic',
        status: 'testing',
        statusLabel: 'Connecting...',
        endpointUrl: 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson',
        details: 'Testing connection to official USGS global seismographic network feed...',
        lastTested: new Date().toISOString(),
        eventsCount: 0
      },
      gdacs: {
        id: 'gdacs',
        name: 'GDACS (UN / European Commission JRC)',
        category: 'Floods, Cyclones & Earthquakes',
        status: 'testing',
        statusLabel: 'Connecting...',
        endpointUrl: 'https://www.gdacs.org/xml/rss.xml',
        details: 'Connecting to official GDACS feed via backend proxy...',
        lastTested: new Date().toISOString(),
        eventsCount: 0
      },
      nasa_firms: {
        id: 'nasa_firms',
        name: 'NASA FIRMS Satellite Thermal Observation',
        category: 'Satellite Fire Hotspots',
        status: 'testing',
        statusLabel: 'Connecting...',
        endpointUrl: 'https://firms.modaps.eosdis.nasa.gov/api/country/',
        details: 'Testing connection to NASA FIRMS satellite telemetry...',
        lastTested: new Date().toISOString(),
        eventsCount: 0
      },
      pmd_ndma: {
        id: 'pmd_ndma',
        name: 'Pakistan NDMA & PMD Official Civil Warnings',
        category: 'National Civil Defense Alerts',
        status: 'unavailable',
        statusLabel: 'Official Pakistan feed not connected yet.',
        details: 'No official public machine-readable RSS/GeoJSON feed API is currently published by NDMA or PMD. LifeSaver does not invent or simulate national emergency alerts. Contact NDMA helpline at 1129 for official civil advisories.',
        lastTested: new Date().toISOString(),
        eventsCount: 0
      }
    }
  };
}

let latestFeedStatus: FeedStatus = createInitialFeedStatus();

export function getLatestFeedStatus(): FeedStatus {
  return latestFeedStatus;
}

// Fetch official GDACS data via secure backend proxy to bypass client browser CORS limitations
async function fetchGdacsViaProxy(): Promise<{ alerts: AlertItem[]; health: SourceHealth }> {
  const t0 = performance.now();
  const proxyEndpoint = '/api/gdacs';
  const officialEndpoint = 'https://www.gdacs.org/xml/rss.xml';

  try {
    const res = await fetch(proxyEndpoint, {
      signal: AbortSignal.timeout(9000),
      headers: {
        'Accept': 'application/json'
      }
    });
    const latency = Math.round(performance.now() - t0);

    if (res.ok) {
      const data = await res.json();
      const rawAlerts: AlertItem[] = Array.isArray(data?.alerts) ? data.alerts : [];

      const isConnected = data.status === 'connected';
      const health: SourceHealth = {
        id: 'gdacs',
        name: 'GDACS (UN / European Commission JRC)',
        category: 'Floods, Cyclones & Earthquakes',
        status: isConnected ? 'connected' : 'unavailable',
        statusLabel: isConnected ? 'Connected (Live)' : (data.statusLabel || 'GDACS unavailable'),
        endpointUrl: officialEndpoint,
        details: isConnected
          ? `Official GDACS RSS feed connected via backend proxy. ${rawAlerts.length} verified events received.`
          : 'GDACS unavailable: remote server could not be reached.',
        latencyMs: latency,
        lastTested: new Date().toISOString(),
        eventsCount: rawAlerts.length
      };

      return { alerts: rawAlerts, health };
    } else {
      const errJson = await res.json().catch(() => ({}));
      const health: SourceHealth = {
        id: 'gdacs',
        name: 'GDACS (UN / European Commission JRC)',
        category: 'Floods, Cyclones & Earthquakes',
        status: 'unavailable',
        statusLabel: errJson.statusLabel || 'GDACS unavailable',
        endpointUrl: officialEndpoint,
        details: errJson.error || 'GDACS unavailable: backend proxy could not reach official GDACS server.',
        latencyMs: latency,
        lastTested: new Date().toISOString(),
        eventsCount: 0
      };
      return { alerts: [], health };
    }
  } catch (err: any) {
    const latency = Math.round(performance.now() - t0);
    const health: SourceHealth = {
      id: 'gdacs',
      name: 'GDACS (UN / European Commission JRC)',
      category: 'Floods, Cyclones & Earthquakes',
      status: 'unavailable',
      statusLabel: 'GDACS unavailable',
      endpointUrl: officialEndpoint,
      details: 'GDACS unavailable: connection to backend proxy failed or timed out. LifeSaver does not invent fake data.',
      latencyMs: latency,
      lastTested: new Date().toISOString(),
      eventsCount: 0
    };
    return { alerts: [], health };
  }
}

// Test NASA FIRMS feed connection honestly without inventing fake endpoints or keys
async function testNasaFirmsConnection(): Promise<SourceHealth> {
  const t0 = performance.now();
  const endpoint = 'https://firms.modaps.eosdis.nasa.gov/api/country/';
  try {
    const res = await fetch(endpoint, {
      signal: AbortSignal.timeout(4000),
      mode: 'cors'
    });
    const latency = Math.round(performance.now() - t0);
    if (res.ok) {
      return {
        id: 'nasa_firms',
        name: 'NASA FIRMS Satellite Thermal Observation',
        category: 'Satellite Fire Hotspots',
        status: 'connected',
        statusLabel: 'Connected (Live)',
        endpointUrl: endpoint,
        details: 'Active connection to NASA FIRMS satellite observation telemetry.',
        latencyMs: latency,
        lastTested: new Date().toISOString(),
        eventsCount: 0
      };
    } else {
      return {
        id: 'nasa_firms',
        name: 'NASA FIRMS Satellite Thermal Observation',
        category: 'Satellite Fire Hotspots',
        status: 'unavailable',
        statusLabel: 'Unavailable',
        endpointUrl: endpoint,
        details: `Unavailable (API key authentication MAP_KEY required for machine-readable queries). Satellite observation — not a confirmed emergency.`,
        latencyMs: latency,
        lastTested: new Date().toISOString(),
        eventsCount: 0
      };
    }
  } catch (err: any) {
    const latency = Math.round(performance.now() - t0);
    return {
      id: 'nasa_firms',
      name: 'NASA FIRMS Satellite Thermal Observation',
      category: 'Satellite Fire Hotspots',
      status: 'unavailable',
      statusLabel: 'Unavailable',
      endpointUrl: endpoint,
      details: 'Unavailable (API MAP_KEY required / CORS restricted for client browser). Satellite observation — not a confirmed emergency.',
      latencyMs: latency,
      lastTested: new Date().toISOString(),
      eventsCount: 0
    };
  }
}

export async function fetchLiveDisasterAlerts(userLocation: UserLocation): Promise<LiveAlertsResponse> {
  const alerts: AlertItem[] = [];
  const t0 = performance.now();
  let usgsHealth: SourceHealth;

  // 1. Fetch Live USGS Official Earthquake GeoJSON Feed
  const usgsEndpoint = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson';
  try {
    const usgsResponse = await fetch(usgsEndpoint, {
      signal: AbortSignal.timeout(8000),
      mode: 'cors'
    });
    const latency = Math.round(performance.now() - t0);

    if (usgsResponse.ok) {
      const data = await usgsResponse.json();
      if (data && Array.isArray(data.features)) {
        for (const feature of data.features) {
          const props = feature.properties || {};
          const geom = feature.geometry || {};
          const coords = geom.coordinates || [0, 0, 0];
          const lng = coords[0];
          const lat = coords[1];
          const depth = coords[2];
          const mag = props.mag ?? 0;

          // Keep earthquakes magnitude >= 2.5 or significance >= 80 to avoid sensor noise
          if (mag < 2.5 && (!props.significance || props.significance < 80)) {
            continue;
          }

          let severity: AlertSeverity = 'advisory';
          let priorityLevel: 1 | 2 | 3 = 3;
          if (mag >= 6.0) {
            severity = 'critical';
            priorityLevel = 1;
          } else if (mag >= 4.5) {
            severity = 'warning';
            priorityLevel = 2;
          } else {
            severity = 'advisory';
            priorityLevel = 3;
          }

          const actions: string[] = [];
          if (mag >= 5.0) {
            actions.push('Drop, Cover, and Hold On beneath sturdy furniture.');
            actions.push('Stay away from glass windows, exterior walls, and overhead lighting.');
            actions.push('Be alert for possible aftershocks in the coming hours.');
          } else {
            actions.push('Minor tremor recorded. Check surroundings for falling objects.');
            actions.push('Check gas lines and electrical appliances if strong shaking was felt.');
          }

          const place = props.place || 'Seismic Zone';
          const placeParts = place.split(',');
          const countryOrRegion = placeParts.length > 1 ? placeParts[placeParts.length - 1].trim() : place;

          const feltRadius = mag >= 7.0 ? 300 : mag >= 6.0 ? 150 : mag >= 5.0 ? 75 : 35;
          const affectedArea = mag >= 3.0 ? {
            type: 'radius_polygon' as const,
            radiusKm: feltRadius,
            description: `Estimated felt shaking impact zone based on USGS seismic attenuation (~${feltRadius} km radius)`,
            isOfficialBoundary: false
          } : undefined;

          alerts.push({
            id: `usgs-${feature.id || Math.random().toString()}`,
            title: `M ${mag.toFixed(1)} Earthquake - ${place}`,
            description: `Seismic event registered at depth of ${depth ? Math.round(depth) : 'N/A'} km. Verified by USGS Global Seismographic Network.`,
            type: 'earthquake',
            severity,
            priorityLevel,
            source: 'usgs',
            sourceName: 'USGS Earthquake Hazards Program',
            sourceUrl: props.url || 'https://earthquake.usgs.gov',
            isOfficialEmergency: true,
            status: 'Active Seismic Event',
            countryName: countryOrRegion,
            regionName: place,
            coordinates: { lat, lng },
            locationName: place,
            timestamp: new Date(props.time || Date.now()).toISOString(),
            magnitude: mag,
            depthKm: depth ? Math.round(depth) : undefined,
            affectedArea,
            safetyActions: actions
          });
        }

        usgsHealth = {
          id: 'usgs',
          name: 'USGS Earthquake Hazards Program',
          category: 'Earthquakes / Seismic',
          status: 'connected',
          statusLabel: 'Connected (Live)',
          endpointUrl: usgsEndpoint,
          details: `Live GeoJSON feed connected. ${alerts.length} verified real-time seismic events received.`,
          latencyMs: latency,
          lastTested: new Date().toISOString(),
          eventsCount: alerts.length
        };
      } else {
        throw new Error('Invalid GeoJSON structure received');
      }
    } else {
      usgsHealth = {
        id: 'usgs',
        name: 'USGS Earthquake Hazards Program',
        category: 'Earthquakes / Seismic',
        status: 'unavailable',
        statusLabel: 'Unavailable',
        endpointUrl: usgsEndpoint,
        details: `HTTP ${usgsResponse.status} error from USGS official feed.`,
        latencyMs: latency,
        lastTested: new Date().toISOString(),
        eventsCount: 0
      };
    }
  } catch (error: any) {
    const latency = Math.round(performance.now() - t0);
    usgsHealth = {
      id: 'usgs',
      name: 'USGS Earthquake Hazards Program',
      category: 'Earthquakes / Seismic',
      status: 'unavailable',
      statusLabel: 'Unavailable',
      endpointUrl: usgsEndpoint,
      details: 'Unable to reach USGS servers (network timeout or offline). LifeSaver does not invent disaster data.',
      latencyMs: latency,
      lastTested: new Date().toISOString(),
      eventsCount: 0
    };
  }

  // 2. Fetch Verified GDACS Multi-Hazard Events via Secure Backend Proxy
  const { alerts: gdacsAlerts, health: gdacsHealth } = await fetchGdacsViaProxy();

  // Merge GDACS events (Floods, Cyclones, Earthquakes not already in USGS list)
  for (const gdacsItem of gdacsAlerts) {
    if (gdacsItem.type === 'earthquake') {
      // Check if duplicate of an existing USGS quake
      const isDuplicate = alerts.some((existing) => {
        if (existing.type !== 'earthquake') return false;
        const d = calculateDistanceKm(
          existing.coordinates.lat,
          existing.coordinates.lng,
          gdacsItem.coordinates.lat,
          gdacsItem.coordinates.lng
        );
        return d < 120; // Within 120km
      });
      if (!isDuplicate) {
        alerts.push(gdacsItem);
      }
    } else {
      // Floods and Tropical Cyclones
      alerts.push(gdacsItem);
    }
  }

  // 3. Test NASA FIRMS Live Feed Status
  const firmsHealth = await testNasaFirmsConnection();

  // 4. Pakistan Official NDMA/PMD Status
  const pakistanHealth: SourceHealth = {
    id: 'pmd_ndma',
    name: 'Pakistan NDMA & PMD Official Civil Warnings',
    category: 'National Civil Defense Alerts',
    status: 'unavailable',
    statusLabel: 'Official Pakistan feed not connected yet.',
    details: 'National Disaster Management Authority (NDMA) & Pakistan Meteorological Department (PMD) do not currently provide a public machine-readable RSS/GeoJSON feed API. LifeSaver does not invent or simulate official national alerts. Call NDMA 1129 for civil advisories.',
    lastTested: new Date().toISOString(),
    eventsCount: 0
  };

  // Compute distances from user location
  alerts.forEach((alert) => {
    alert.distanceKm = calculateDistanceKm(
      userLocation.lat,
      userLocation.lng,
      alert.coordinates.lat,
      alert.coordinates.lng
    );
  });

  // Sort by proximity and severity
  const severityRank: Record<AlertSeverity, number> = {
    critical: 4,
    warning: 3,
    advisory: 2,
    info: 1
  };

  alerts.sort((a, b) => {
    const distA = a.distanceKm ?? 99999;
    const distB = b.distanceKm ?? 99999;
    if (distA <= 1500 && distB <= 1500) {
      return distA - distB;
    }
    if (distA <= 1500) return -1;
    if (distB <= 1500) return 1;

    const rankDiff = severityRank[b.severity] - severityRank[a.severity];
    if (rankDiff !== 0) return rankDiff;
    return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
  });

  const feedStatus: FeedStatus = {
    usgsConnected: usgsHealth.status === 'connected',
    gdacsConnected: gdacsHealth.status === 'connected',
    firmsConnected: firmsHealth.status === 'connected',
    pakistanConnected: false,
    lastUpdated: new Date().toISOString(),
    sources: {
      usgs: usgsHealth,
      gdacs: gdacsHealth,
      nasa_firms: firmsHealth,
      pmd_ndma: pakistanHealth
    }
  };

  latestFeedStatus = feedStatus;

  const isUnavailable = alerts.length === 0;

  if (alerts.length > 0) {
    const syncTime = new Date().toISOString();
    try {
      localStorage.setItem('lifesaver_cached_alerts', JSON.stringify(alerts));
      localStorage.setItem('lifesaver_cached_feed_status', JSON.stringify(feedStatus));
      localStorage.setItem('lifesaver_cached_alerts_timestamp', syncTime);
    } catch (_) {}

    return {
      alerts,
      isUnavailable: false,
      feedStatus,
      lastSyncTimestamp: syncTime,
      isFromCache: false
    };
  }

  // If live feeds failed (e.g. offline, blackout), retrieve verified cached alerts
  const cached = getCachedDisasterAlerts();
  const cachedSyncTime = getLastAlertsSyncTimestamp();

  if (cached.length > 0) {
    // Explicitly flag cached records as offline telemetry (Level 5: Cached Telemetry)
    const markedCached: AlertItem[] = cached.map((alert) => ({
      ...alert,
      isCached: true,
      cachedTimestamp: cachedSyncTime || undefined,
      priorityLevel: 5 as const,
      distanceKm: calculateDistanceKm(
        userLocation.lat,
        userLocation.lng,
        alert.coordinates.lat,
        alert.coordinates.lng
      )
    }));

    return {
      alerts: markedCached,
      isUnavailable: true,
      statusMessage: 'Offline Mode: Displaying verified telemetry cached from last sync. Telemetry is timestamped and never presented as live.',
      feedStatus,
      lastSyncTimestamp: cachedSyncTime,
      isFromCache: true
    };
  }

  return {
    alerts: [],
    isUnavailable: true,
    statusMessage: 'Live disaster data is currently unavailable. LifeSaver does not invent disaster data.',
    feedStatus,
    lastSyncTimestamp: null,
    isFromCache: false
  };
}

export function getCachedDisasterAlerts(): AlertItem[] {
  try {
    const raw = localStorage.getItem('lifesaver_cached_alerts');
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (_) {}
  return [];
}

