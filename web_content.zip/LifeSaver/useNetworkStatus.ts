import { useState, useEffect } from 'react';
import { NetworkState } from '../types';

interface NetworkConnectionInfo {
  isOnline: boolean;
  networkState: NetworkState;
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
  saveData?: boolean;
}

export function useNetworkStatus(): NetworkConnectionInfo {
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  const [networkInfo, setNetworkInfo] = useState<{
    effectiveType?: string;
    downlink?: number;
    rtt?: number;
    saveData?: boolean;
  }>(() => {
    if (typeof navigator !== 'undefined' && 'connection' in navigator) {
      const conn = (navigator as any).connection;
      return {
        effectiveType: conn?.effectiveType,
        downlink: conn?.downlink,
        rtt: conn?.rtt,
        saveData: conn?.saveData
      };
    }
    return {};
  });

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    let connectionListener: (() => void) | null = null;
    if (typeof navigator !== 'undefined' && 'connection' in navigator) {
      const conn = (navigator as any).connection;
      connectionListener = () => {
        setNetworkInfo({
          effectiveType: conn?.effectiveType,
          downlink: conn?.downlink,
          rtt: conn?.rtt,
          saveData: conn?.saveData
        });
      };
      conn.addEventListener?.('change', connectionListener);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (connectionListener && 'connection' in navigator) {
        const conn = (navigator as any).connection;
        conn.removeEventListener?.('change', connectionListener);
      }
    };
  }, []);

  // Determine network state: offline, weak, or online
  let networkState: NetworkState = 'online';
  if (!isOnline) {
    networkState = 'offline';
  } else if (
    networkInfo.effectiveType === '2g' ||
    networkInfo.effectiveType === 'slow-2g' ||
    (networkInfo.rtt && networkInfo.rtt > 1200) ||
    (networkInfo.downlink && networkInfo.downlink < 0.3)
  ) {
    networkState = 'weak';
  }

  return {
    isOnline,
    networkState,
    ...networkInfo
  };
}
