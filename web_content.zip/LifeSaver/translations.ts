import { Language } from '../types';

export interface Translations {
  appName: string;
  tagline: string;
  
  // Navigation
  navHome: string;
  navAlerts: string;
  navMap: string;
  navEmergency: string;
  navSettings: string;
  
  // Header & Status
  safetyStatusNormal: string;
  safetyStatusAlert: string;
  yourLocation: string;
  useGPS: string;
  gpsActive: string;
  locationPermissionDenied: string;
  changeLocation: string;
  searchCity: string;
  refreshingFeeds: string;
  liveFeedConnected: string;
  
  // Official Pakistan Feed Requirement
  pakistanFeedStatusTitle: string;
  pakistanFeedNotConnectedNotice: string;
  pakistanFeedNoticeSubtext: string;
  pakistanNdmaHelpline: string;
  
  // Feed Health & Testing
  feedsStatusTitle: string;
  testFeedsNow: string;
  testingFeeds: string;
  statusConnected: string;
  statusUnavailable: string;
  statusTesting: string;
  activeSources: string;
  
  // Satellite Observation Notice
  satelliteNoticeText: string;
  satelliteNoticeSubtext: string;
  
  // Home Screen
  quickSOS: string;
  instantHelp: string;
  activeDisastersNearby: string;
  noDisastersNearby: string;
  noDisastersSubtext: string;
  viewAllAlerts: string;
  openMap: string;
  startSafetyCheck: string;
  emergencyHelplines: string;
  sirenAlarm: string;
  sirenPlaying: string;
  stopSiren: string;
  flashlight: string;
  broadcastLocation: string;
  
  // Alerts Screen
  alertsTitle: string;
  filterAll: string;
  filterEarthquakes: string;
  filterFloods: string;
  filterCyclones: string;
  filterFires: string;
  filterCritical: string;
  filterWarning: string;
  filterAdvisory: string;
  searchAlertsPlaceholder: string;
  radiusAll: string;
  radius500km: string;
  radius1000km: string;
  distanceKm: string;
  sourceLabel: string;
  magnitudeLabel: string;
  depthLabel: string;
  timeAgo: string;
  viewDetails: string;
  shareAlert: string;
  copiedToClipboard: string;
  
  // Map Screen
  mapTitle: string;
  centerMyLocation: string;
  toggleLayers: string;
  disasterLegend: string;
  tapPinDetails: string;
  
  // Emergency Action Screen
  emergencyTitle: string;
  emergencyActionFlowTitle: string;
  emergencyActionStep1: string;
  emergencyActionStep1Desc: string;
  emergencyActionStep2: string;
  emergencyActionStep2Desc: string;
  emergencyActionStep3: string;
  emergencyActionStep3Desc: string;
  callNow: string;
  sosCountdownTitle: string;
  cancelSOS: string;
  sendSMSCoords: string;
  smsCopied: string;
  offlineSurvivalGuides: string;
  earthquakeGuide: string;
  floodGuide: string;
  fireGuide: string;
  cycloneGuide: string;
  firstAidGuide: string;
  medicalIdTitle: string;
  emergencyContactsTitle: string;
  addContact: string;
  name: string;
  phone: string;
  relationship: string;
  save: string;
  delete: string;
  
  // Settings Screen
  settingsTitle: string;
  languageSelect: string;
  locationSettings: string;
  locationPermissionStatus: string;
  allowGPSPrompt: string;
  alertSourcesTransparency: string;
  sourcesDescription: string;
  disclaimerTitle: string;
  disclaimerBody: string;
  unverifiedDataDisclaimer: string;
  version: string;
  offlineModeReady: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: "LifeSaver",
    tagline: "Emergency Alerts & Disaster Safety",
    
    navHome: "Home",
    navAlerts: "Alerts",
    navMap: "Map",
    navEmergency: "Emergency",
    navSettings: "Settings",
    
    safetyStatusNormal: "Normal - No Immediate Severe Threat Nearby",
    safetyStatusAlert: "Attention - Active Disaster In Region",
    yourLocation: "Your Location",
    useGPS: "Detect GPS Location",
    gpsActive: "GPS Location Active",
    locationPermissionDenied: "Location permission denied. Using selected city.",
    changeLocation: "Change Location",
    searchCity: "Search City / Region",
    refreshingFeeds: "Updating verified disaster feeds...",
    liveFeedConnected: "Live feeds synchronized",
    
    pakistanFeedStatusTitle: "National Warning Feed",
    pakistanFeedNotConnectedNotice: "Official Pakistan feed not connected yet.",
    pakistanFeedNoticeSubtext: "Machine-readable alert feeds from NDMA & PMD are not yet public. We do not invent official alerts. Call NDMA 1129 for official civil advisories.",
    pakistanNdmaHelpline: "NDMA Disaster Helpline: 1129",
    
    feedsStatusTitle: "Data Feeds Connection Status",
    testFeedsNow: "Test All Feeds",
    testingFeeds: "Testing Feeds...",
    statusConnected: "Connected (Live)",
    statusUnavailable: "Unavailable",
    statusTesting: "Testing...",
    activeSources: "Active Feeds",
    
    satelliteNoticeText: "Satellite observation — not a confirmed emergency.",
    satelliteNoticeSubtext: "Thermal infrared satellite hotspot detection from NASA FIRMS. Requires on-ground verification by local authorities.",
    
    quickSOS: "Emergency Action",
    instantHelp: "One-tap rescue hotlines & safety beacons",
    activeDisastersNearby: "Disasters Within 1,000 km",
    noDisastersNearby: "No major disaster detected within 1,000 km",
    noDisastersSubtext: "Monitoring USGS seismic feeds, GDACS alerts, and thermal satellite tracking.",
    viewAllAlerts: "View All Alerts",
    openMap: "Open Interactive Map",
    startSafetyCheck: "Safety Readiness Check",
    emergencyHelplines: "Emergency Helplines",
    sirenAlarm: "Loud SOS Siren",
    sirenPlaying: "Siren Sounding (Loud)",
    stopSiren: "Stop Siren",
    flashlight: "Strobe SOS Light",
    broadcastLocation: "Share GPS Coordinates",
    
    alertsTitle: "Disaster Alerts",
    filterAll: "All Disasters",
    filterEarthquakes: "Earthquakes",
    filterFloods: "Floods & Rain",
    filterCyclones: "Cyclones & Storms",
    filterFires: "Satellite Fire",
    filterCritical: "Critical",
    filterWarning: "Warning",
    filterAdvisory: "Advisory",
    searchAlertsPlaceholder: "Search by place name or magnitude...",
    radiusAll: "Global",
    radius500km: "Within 500 km",
    radius1000km: "Within 1,000 km",
    distanceKm: "km away",
    sourceLabel: "Verified Source",
    magnitudeLabel: "Magnitude",
    depthLabel: "Depth",
    timeAgo: "ago",
    viewDetails: "View Safety Protocol",
    shareAlert: "Share Alert",
    copiedToClipboard: "Copied emergency details to clipboard",
    
    mapTitle: "Live Disaster Map",
    centerMyLocation: "Center on Me",
    toggleLayers: "Filter Layers",
    disasterLegend: "Map Legend",
    tapPinDetails: "Tap any disaster marker to view magnitude & safety guide.",
    
    emergencyTitle: "Emergency Flow & Helplines",
    emergencyActionFlowTitle: "Standard Emergency Action Protocol",
    emergencyActionStep1: "1. Ensure Immediate Safety",
    emergencyActionStep1Desc: "Drop & cover during quakes; move to higher ground in floods; stay low under smoke.",
    emergencyActionStep2: "2. Call First Responders",
    emergencyActionStep2Desc: "Dial 1122 (Rescue) or 15 (Police). Stay calm and clearly state your address or landmark.",
    emergencyActionStep3: "3. Sound SOS & Signal Rescuers",
    emergencyActionStep3Desc: "Use the audio beacon below to guide rescue teams in low visibility or trapped rubble.",
    callNow: "Call",
    sosCountdownTitle: "SOS Location Message",
    cancelSOS: "Cancel",
    sendSMSCoords: "Send SMS with Location",
    smsCopied: "Emergency text with GPS coordinates copied!",
    offlineSurvivalGuides: "Offline Survival Checklists",
    earthquakeGuide: "Earthquake: Drop, Cover, Hold",
    floodGuide: "Flood: High Ground Evacuation",
    fireGuide: "Fire: Stay Low & Evacuate",
    cycloneGuide: "Cyclone: Shelter & Window Safety",
    firstAidGuide: "Emergency First Aid Essentials",
    medicalIdTitle: "Offline Medical ID & ICE",
    emergencyContactsTitle: "Personal Emergency Contacts",
    addContact: "Add Emergency Contact",
    name: "Full Name",
    phone: "Phone Number",
    relationship: "Relationship (e.g. Spouse, Parent)",
    save: "Save",
    delete: "Delete",
    
    settingsTitle: "Settings & Transparency",
    languageSelect: "App Language / زبان / ژبه",
    locationSettings: "Location & Proximity",
    locationPermissionStatus: "Location Permission",
    allowGPSPrompt: "Enable precise GPS to calculate distance to disasters and share coordinates during an emergency.",
    alertSourcesTransparency: "Data Sources & Transparency",
    sourcesDescription: "LifeSaver strictly ingests verified open feeds. We never fabricate data or present unverified information as confirmed emergencies.",
    disclaimerTitle: "Safety & Legal Disclaimers",
    disclaimerBody: "LifeSaver is an early alert aggregator and safety tool. It does not replace official civil defense evacuation orders, municipal alarms, or emergency dispatch directives. In an emergency, always follow directives from local authorities.",
    unverifiedDataDisclaimer: "Satellite thermal detections are raw thermal anomalies and explicitly not confirmed structure or wildland emergencies until verified on the ground.",
    version: "LifeSaver Mobile v1.2.0 • Offline Ready",
    offlineModeReady: "Offline storage enabled. Checklists and emergency hotlines are accessible without internet."
  },
  
  ur: {
    appName: "لائف سیور",
    tagline: "ہنگامی انتباہات اور قدرتی آفات سے تحفظ",
    
    navHome: "ہوم",
    navAlerts: "انتباہات",
    navMap: "نقشہ",
    navEmergency: "ہنگامی مدد",
    navSettings: "ترتیبات",
    
    safetyStatusNormal: "معمول - قریبی علاقے میں کوئی فوری شدید خطرہ نہیں",
    safetyStatusAlert: "توجہ فرمائیں - علاقے میں فعال آفت کی اطلاع",
    yourLocation: "آپ کا مقام",
    useGPS: "جی پی ایس (GPS) مقام حاصل کریں",
    gpsActive: "جی پی ایس مقام فعال ہے",
    locationPermissionDenied: "مقام کی اجازت نہیں مل سکی۔ منتخب شدہ شہر استعمال ہو رہا ہے۔",
    changeLocation: "مقام تبدیل کریں",
    searchCity: "شہر یا علاقہ تلاش کریں",
    refreshingFeeds: "تصدیق شدہ فیڈز اپ ڈیٹ ہو رہی ہیں...",
    liveFeedConnected: "لائیو ڈیٹا ہم آہنگ ہو چکا ہے",
    
    pakistanFeedStatusTitle: "قومی ڈیزاسٹر انتباہی فیڈ",
    pakistanFeedNotConnectedNotice: "Official Pakistan feed not connected yet.",
    pakistanFeedNoticeSubtext: "این ڈی ایم اے (NDMA) اور محکمہ موسمیات کی باقاعدہ مشین ریڈ ایبل لائیو فیڈ ابھی عوامی طور پر دستیاب نہیں ہے۔ ہم جعلی انتباہ نہیں بناتے۔ سرکاری اعلانات کے لیے 1129 پر رابطہ کریں۔",
    pakistanNdmaHelpline: "این ڈی ایم اے ڈیزاسٹر ہیلپ لائن: 1129",
    
    feedsStatusTitle: "ڈیٹا فیڈز کی کنکشن کیفیت",
    testFeedsNow: "تمام فیڈز ٹیسٹ کریں",
    testingFeeds: "فیڈز کی جانچ ہو رہی ہے...",
    statusConnected: "منسلک (لائیو)",
    statusUnavailable: "دستیاب نہیں",
    statusTesting: "جانچ جاری...",
    activeSources: "فعال فیڈز",
    
    satelliteNoticeText: "Satellite observation — not a confirmed emergency.",
    satelliteNoticeSubtext: "ناسا FIRMS سیٹلائٹ کے ذریعے تھرمل مشاہدہ۔ یہ زمینی تصدیق کے بغیر حتمی ایمرجنسی نہیں ہے۔",
    
    quickSOS: "ہنگامی کارروائی",
    instantHelp: "ایک کلک پر ریسکیو ہیلپ لائنز اور سائرن",
    activeDisastersNearby: "1,000 کلومیٹر کے اندر آفات",
    noDisastersNearby: "1,000 کلومیٹر کے اندر کوئی بڑی آفت رپورٹ نہیں ہوئی",
    noDisastersSubtext: "یو ایس جی ایس زلزلہ مانیٹرنگ، جی ڈی اے سی ایس اور ناسا سیٹلائٹ ڈیٹا کی نگرانی جاری ہے۔",
    viewAllAlerts: "تمام انتباہات دیکھیں",
    openMap: "انٹرایکٹو نقشہ کھولیں",
    startSafetyCheck: "حفاظتی تیاری چیک لسٹ",
    emergencyHelplines: "ہنگامی ہیلپ لائنز",
    sirenAlarm: "تیز آواز کا ایس او ایس سائرن",
    sirenPlaying: "سائرن بج رہا ہے (تیز آواز)",
    stopSiren: "سائرن بند کریں",
    flashlight: "ایمرجنسی فلیش لائٹ",
    broadcastLocation: "اپنا GPS مقام شیئر کریں",
    
    alertsTitle: "آفات کے انتباہات",
    filterAll: "تمام آفات",
    filterEarthquakes: "زلزلے",
    filterFloods: "سیلاب اور بارش",
    filterCyclones: "سمندری طوفان",
    filterFires: "سیٹلائٹ آگ کے مشاہدات",
    filterCritical: "انتہائی شدید",
    filterWarning: "انتباہ",
    filterAdvisory: "اطلاع",
    searchAlertsPlaceholder: "مقام یا شدت کے لحاظ سے تلاش کریں...",
    radiusAll: "عالمی",
    radius500km: "500 کلومیٹر کے اندر",
    radius1000km: "1,000 کلومیٹر کے اندر",
    distanceKm: "کلومیٹر دور",
    sourceLabel: "تصدیق شدہ ذریعہ",
    magnitudeLabel: "شدت (Magnitude)",
    depthLabel: "گہرائی",
    timeAgo: "پہلے",
    viewDetails: "حفاظتی ہدایات دیکھیں",
    shareAlert: "انتباہ شیئر کریں",
    copiedToClipboard: "ہنگامی تفصیلات کاپی ہو گئیں",
    
    mapTitle: "لائیو ڈیزاسٹر میپ",
    centerMyLocation: "میرے مقام پر مرکوز کریں",
    toggleLayers: "فلٹرز تبدیل کریں",
    disasterLegend: "نقشے کی علامات",
    tapPinDetails: "تفصیلات اور رہنمائی دیکھنے کے لیے کسی بھی مارکر پر کلک کریں۔",
    
    emergencyTitle: "ہنگامی ایکشن اور ہیلپ لائنز",
    emergencyActionFlowTitle: "معیاری ہنگامی ایکشن پروٹوکول",
    emergencyActionStep1: "1. فوری ذاتی حفاظت یقینی بنائیں",
    emergencyActionStep1Desc: "زلزلے میں جھکیں، ڈھانپیں اور تھامیں؛ سیلاب میں اونچی جگہ جائیں؛ دھوئیں میں نیچے رہیں۔",
    emergencyActionStep2: "2. فوراً ریسکیو کو کال کریں",
    emergencyActionStep2Desc: "ریسکیو 1122 یا پولیس 15 پر رابطہ کریں۔ پرسکون رہ کر اپنا پتہ اور نشان بتائیں۔",
    emergencyActionStep3: "3. سگنل یا سائرن کے ذریعے رہنمائی کریں",
    emergencyActionStep3Desc: "اندھیرے یا ملبے کے حالات میں ریسکیو ٹیم کی رہنمائی کے لیے نیچے دیا گیا لاؤڈ سائرن چلائیں۔",
    callNow: "کال کریں",
    sosCountdownTitle: "ایس او ایس میسج",
    cancelSOS: "منسوخ",
    sendSMSCoords: "مقام کے ساتھ ایس ایم ایس بھیجیں",
    smsCopied: "جی پی ایس لوکیشن کا میسج کاپی ہو گیا!",
    offlineSurvivalGuides: "آف لائن ہنگامی گائیڈز",
    earthquakeGuide: "زلزلہ: جھکیں، ڈھانپیں اور تھامیں",
    floodGuide: "سیلاب: محفوظ اونچی جگہ انخلاء",
    fireGuide: "آگ: نیچے رہیں اور فوراً باہر نکلیں",
    cycloneGuide: "طوفان: اندرونی پناہ گاہ اور کھڑکیوں سے دوری",
    firstAidGuide: "ابتدائی طبی امداد کے بنیادی اصول",
    medicalIdTitle: "آف لائن میڈیکل آئی ڈی (ICE)",
    emergencyContactsTitle: "ذاتی ہنگامی رابطے",
    addContact: "ہنگامی رابطہ شامل کریں",
    name: "مکمل نام",
    phone: "فون نمبر",
    relationship: "رشتہ (مثلاً والدین، شریک حیات)",
    save: "محفوظ کریں",
    delete: "حذف کریں",
    
    settingsTitle: "ترتیبات اور شفافیت",
    languageSelect: "ایپ کی زبان (Language)",
    locationSettings: "مقام اور قربت",
    locationPermissionStatus: "مقام کی اجازت کی کیفیت",
    allowGPSPrompt: "آفات سے فاصلہ ناپنے اور ہنگامی صورتحال میں اپنا مقام شیئر کرنے کے لیے GPS آن کریں۔",
    alertSourcesTransparency: "ڈیٹا ذرائع کی مکمل شفافیت",
    sourcesDescription: "لائف سیور صرف مستند اور کھلے سائنسی ذرائع سے ڈیٹا لیتا ہے۔ ہم کبھی غیر تصدیق شدہ ڈیٹا کو سرکاری ایمرجنسی بنا کر پیش نہیں کرتے۔",
    disclaimerTitle: "حفاظتی و قانونی دستبرداری",
    disclaimerBody: "لائف سیور ایک امدادی ٹول ہے۔ یہ سرکاری سول ڈیفنس، ریسکیو اداروں یا سائرن سسٹم کا متبادل نہیں ہے۔ ہنگامی صورتحال میں ہمیشہ مقامی انتظامیہ کے احکامات پر عمل کریں۔",
    unverifiedDataDisclaimer: "سیٹلائٹ تھرمل ڈیٹا خلائی مشاہدہ ہوتا ہے، جب تک زمینی ریسکیو ٹیمیں تصدیق نہ کریں اسے مصدقہ آگ نہیں مانا جاتا۔",
    version: "لائف سیور ورژن 1.2.0 • آف لائن تیار",
    offlineModeReady: "آف لائن سہولت فعال ہے۔ انٹرنیٹ نہ ہونے پر بھی ہنگامی نمبر اور گائیڈز دستیاب ہیں۔"
  },
  
  ps: {
    appName: "د ژوند ژغورونکی (LifeSaver)",
    tagline: "بېړني خبرتیاوې او د طبیعي پېښو خوندیتوب",
    
    navHome: "کورپاڼه",
    navAlerts: "خبرتیاوې",
    navMap: "نقشه",
    navEmergency: "بېړنۍ مرسته",
    navSettings: "ترتیبات",
    
    safetyStatusNormal: "نورمال - شاوخوا سیمه کې سمدستي خطر نشته",
    safetyStatusAlert: "پام وکړئ - په سیمه کې فعاله پېښه",
    yourLocation: "ستاسو موقعیت",
    useGPS: "د GPS موقعیت وټاکئ",
    gpsActive: "GPS موقعیت فعال دی",
    locationPermissionDenied: "د موقعیت اجازه ورنه کړل شوه. ټاکل شوی ښار کارول کیږي.",
    changeLocation: "موقعیت بدل کړئ",
    searchCity: "ښار یا سیمه وپلټئ",
    refreshingFeeds: "باوري مالومات تازه کیږي...",
    liveFeedConnected: "ژوندی ډیټا وصل دی",
    
    pakistanFeedStatusTitle: "د پاکستان رسمي ملي خبرتیاوې",
    pakistanFeedNotConnectedNotice: "Official Pakistan feed not connected yet.",
    pakistanFeedNoticeSubtext: "د NDMA او موسمیاتو ادارې رسمي ډیټا فیډ تر اوسه په عام ډول شتون نلري. موږ جعلي خبرتیاوې نه جوړوو. د رسمي خبرتیاو لپاره 1129 ته زنګ ووهئ.",
    pakistanNdmaHelpline: "د NDMA بېړنۍ اړیکه: 1129",
    
    feedsStatusTitle: "د ډیټا سرچینو د پیوستون حالت",
    testFeedsNow: "ټولې سرچینې وازموئ",
    testingFeeds: "سرچینې ازمویل کیږي...",
    statusConnected: "وصل دی (ژوندی)",
    statusUnavailable: "شتون نلري",
    statusTesting: "ازمویل کیږي...",
    activeSources: "فعالې سرچینې",
    
    satelliteNoticeText: "Satellite observation — not a confirmed emergency.",
    satelliteNoticeSubtext: "د ناسا د سپوږمکۍ تودوخې کتنه ده. د ځمکني تصدیق پرته حتمي بېړنی حالت نه ګڼل کیږي.",
    
    quickSOS: "بېړنی اقدام",
    instantHelp: "په یوه کلیک د ژغورنې شمېرې او سایرن",
    activeDisastersNearby: "په 1000 کیلومترۍ کې پېښې",
    noDisastersNearby: "په 1000 کیلومترۍ کې لویه پېښه نه ده ثبت شوې",
    noDisastersSubtext: "د USGS زلزلې او ناسا سپوږمکۍ معلومات کتل کیږي.",
    viewAllAlerts: "ټولې خبرتیاوې وګورئ",
    openMap: "نقشه پرانیزئ",
    startSafetyCheck: "د خوندیتوب چک لست",
    emergencyHelplines: "بېړنۍ اړیکې",
    sirenAlarm: "د بېړني حالت زنګ (سایرن)",
    sirenPlaying: "سایرن غږیږي (لوړ غږ)",
    stopSiren: "سایرن بند کړئ",
    flashlight: "بېړنی څراغ (Flashlight)",
    broadcastLocation: "خپل GPS موقعیت واستوئ",
    
    alertsTitle: "د پېښو خبرتیاوې",
    filterAll: "ټولې پېښې",
    filterEarthquakes: "زلزلې",
    filterFloods: "سیلابونه او باران",
    filterCyclones: "توپانونو خبرتیا",
    filterFires: "د سپوږمکۍ د اور مشاهدات",
    filterCritical: "خورا خطرناک",
    filterWarning: "خبرداری",
    filterAdvisory: "لارښوونه",
    searchAlertsPlaceholder: "د ځای یا شدت له مخې وپلټئ...",
    radiusAll: "نړیوال",
    radius500km: "تر 500 کیلومتره پورې",
    radius1000km: "تر 1,000 کیلومتره پورې",
    distanceKm: "کیلومتره لرې",
    sourceLabel: "باوري سرچینه",
    magnitudeLabel: "شدت (Magnitude)",
    depthLabel: "ژوروالی",
    timeAgo: "مخکې",
    viewDetails: "د خوندیتوب لارښوونه وګورئ",
    shareAlert: "خبرتیا شریکه کړئ",
    copiedToClipboard: "معلومات کاپي شول",
    
    mapTitle: "ژوندۍ نقشه",
    centerMyLocation: "زما موقعیت ته لاړ شه",
    toggleLayers: "فلټرونه بدل کړئ",
    disasterLegend: "د نقشې نښې",
    tapPinDetails: "د جزئیاتو لیدلو لپاره پر نښه کلیک وکړئ.",
    
    emergencyTitle: "بېړنی اقدام او اړیکې",
    emergencyActionFlowTitle: "د بېړني حالت کړنلاره",
    emergencyActionStep1: "۱. خپل سمدستي خوندیتوب وساتئ",
    emergencyActionStep1Desc: "په زلزله کې پناه واخلئ؛ سیلاب کې لوړو ځایونو ته لاړ شئ؛ لوګي کې ټیټ پاتې شئ.",
    emergencyActionStep2: "۲. ژغورونکو سره اړیکه ونیسئ",
    emergencyActionStep2Desc: "1122 یا 15 ته زنګ ووهئ او په ارامه خپل کره ادرس ووایاست.",
    emergencyActionStep3: "۳. خپل موقعیت او سایرن څرګند کړئ",
    emergencyActionStep3Desc: "د ژغورنې ډلې لارښوونې لپاره لاندې لوړ غږ لرونکی سایرن ولګوئ.",
    callNow: "زنګ ووهئ",
    sosCountdownTitle: "د SOS پیغام",
    cancelSOS: "لغوه",
    sendSMSCoords: "د موقعیت سره SMS واستوئ",
    smsCopied: "د GPS موقعیت متن کاپي شو!",
    offlineSurvivalGuides: "د ژغورنې افلاین لارښود",
    earthquakeGuide: "زلزله: ښکته شئ، پټ شئ او ټینګ ونیسئ",
    floodGuide: "سیلاب: لوړو سیمو ته وتل",
    fireGuide: "اور: ټیټ شئ او وتښتئ",
    cycloneGuide: "توپاني باد: خوندي کوټه کې پاتې کیدل",
    firstAidGuide: "د لومړنیو روغتیايي مرستو لارښود",
    medicalIdTitle: "افلاین طبي معلومات (ICE)",
    emergencyContactsTitle: "شخصي بېړنۍ اړیکې",
    addContact: "اړیکه اضافه کړئ",
    name: "بشپړ نوم",
    phone: "د ټلیفون شمېره",
    relationship: "اړیکه (پلار، ورور، ملګری)",
    save: "ساتل",
    delete: "ړنګول",
    
    settingsTitle: "ترتیبات او روڼتیا",
    languageSelect: "د پروګرام ژبه (Language)",
    locationSettings: "موقعیت او واټن",
    locationPermissionStatus: "د موقعیت اجازه",
    allowGPSPrompt: "تر پېښو پورې د واټن معلومولو لپاره خپل GPS موقعیت فعال کړئ.",
    alertSourcesTransparency: "د سرچینو روڼتیا",
    sourcesDescription: "د ژوند ژغورونکی یوازې له مستندو ساینسي سرچینو معلومات اخلي. موږ جعلي یا نا تایید شوي معلومات نه خپروو.",
    disclaimerTitle: "قانوني او خوندیتوب یادښت",
    disclaimerBody: "دا اپلیکیشن د مدني خوندیتوب او ژغورنې رسمي ادارو بدیل نه دی. په بېړني حالت کې تل د رسمي ژغورونکو لارښوونې عملي کړئ.",
    unverifiedDataDisclaimer: "د سپوږمکۍ تودوخه مشاهده ده، تر څو چې په ځمکه ثابته نشي حتمي اور نه ګڼل کیږي.",
    version: "د ژوند ژغورونکی نسخه 1.2.0 • افلاین کارول",
    offlineModeReady: "د افلاین کارولو وړتیا فعاله ده. انټرنیټ پرته هم لارښود او شمېرې شتون لري."
  }
};
