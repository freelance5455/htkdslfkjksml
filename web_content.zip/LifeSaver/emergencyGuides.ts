import { DisasterGuide } from '../types';

export const EMERGENCY_GUIDES: DisasterGuide[] = [
  {
    id: 'guide-earthquake',
    type: 'earthquake',
    title: 'Earthquake Action Guide',
    before: [
      'Secure heavy wall art, mirrors, cupboards, and water heaters to wall studs.',
      'Locate emergency shutoffs for gas, electricity, and main water valve.',
      'Prepare a 72-hour grab-and-go emergency go-bag (documents, water, medicine, torch).'
    ],
    during: [
      'DROP down onto hands and knees immediately to prevent being knocked over.',
      'COVER your head and neck under a sturdy table, desk, or interior doorframe.',
      'HOLD ON to your shelter until shaking completely stops. If no shelter, cover head against interior wall.',
      'If in bed, stay there and curl face-down, protecting your head with a pillow.',
      'If outdoors, move into an open area away from electrical poles, power cables, and tall buildings.',
      'DO NOT use elevators or rush toward stairwells while shaking continues.'
    ],
    after: [
      'Check yourself and family for injuries before moving.',
      'Smell for gas: if detected, shut off main valve and evacuate immediately. DO NOT flip light switches.',
      'Be prepared for sudden aftershocks which can collapse weakened structures.',
      'Monitor LifeSaver and radio for official civil defense updates.'
    ]
  },
  {
    id: 'guide-flood',
    type: 'flood',
    title: 'Floods & Flash Flood Survival',
    before: [
      'Elevate essential appliances, electrical panels, and documents to upper floors.',
      'Identify the nearest high ground evacuation route.',
      'Store at least 5 liters of clean bottled water per person for 3 days.'
    ],
    during: [
      'NEVER walk through moving water. Just 15 cm (6 inches) of rapid water can knock an adult down.',
      'NEVER drive through flooded roads or causeways ("Turn Around, Don\'t Drown"). 30 cm can float a car.',
      'If trapped in a building, move to the highest level or roof. Avoid enclosed attics with no roof hatch.',
      'Disconnect electrical appliances before water reaches outlets if safe to do so.'
    ],
    after: [
      'Avoid floodwaters — they are frequently contaminated with sewage, chemicals, and live electricity.',
      'Boil all tap water or well water vigorously for 3 minutes before drinking or cooking.',
      'Inspect foundation and walls for structural cracks before re-entering home.'
    ]
  },
  {
    id: 'guide-fire',
    type: 'fire',
    title: 'Structure Fire & Smoke Evacuation',
    before: [
      'Test smoke detectors monthly; keep a multi-class (ABC) fire extinguisher on each floor.',
      'Plan two distinct exit routes out of every sleeping room.',
      'Teach family members: STOP, DROP, and ROLL if clothing catches fire.'
    ],
    during: [
      'Get low and CRAWL beneath smoke. Toxic gases and heat rise to the ceiling.',
      'Feel closed doors with the back of your hand before opening. If hot, DO NOT open — use secondary exit.',
      'Close doors behind you as you escape to slow fire and smoke propagation.',
      'Once outside, STAY OUT. Never re-enter a burning structure for pets or possessions.',
      'Call Fire Brigade (16 / 1122) immediately from safety.'
    ],
    after: [
      'Do not enter until fire authorities declare the structure structurally safe.',
      'Discard food, medicine, and beverages that were exposed to heat or smoke fumes.'
    ]
  },
  {
    id: 'guide-cyclone',
    type: 'cyclone',
    title: 'Cyclone & Extreme Wind Protection',
    before: [
      'Trim overhanging tree branches; secure solar panels, loose tin sheets, and outdoor furniture.',
      'Board up or tape large glass windows; charge phones and emergency lamps.',
      'If in a low-lying coastal zone, follow pre-emptive evacuation advisories immediately.'
    ],
    during: [
      'Shelter in a small windowless interior room (bathroom, hallway, closet) on the ground floor.',
      'Stay away from glass windows and doors that could shatter from wind pressure or airborne debris.',
      'Beware the "Eye of the Storm": a temporary calm is followed by intense winds from the opposite direction.'
    ],
    after: [
      'Beware fallen high-voltage power lines and standing water.',
      'Do not touch exposed electrical wiring or damp breaker panels.'
    ]
  },
  {
    id: 'guide-first-aid',
    type: 'severe_weather',
    title: 'Critical First Aid Essentials',
    before: [
      'Keep a sterile first aid kit with compression bandages, antiseptic, splints, and gloves.'
    ],
    during: [
      'Severe Bleeding: Apply firm, continuous direct pressure with clean cloth. Elevate if possible.',
      'Choking: Administer 5 back blows followed by 5 abdominal thrusts (Heimlich maneuver).',
      'Unresponsive / Not Breathing: Begin hands-only CPR at 100-120 compressions per minute in chest center.',
      'Burns: Cool under running tap water for at least 10 minutes. Never apply ice, butter, or paste.',
      'Shock: Keep patient warm, calm, and lay them flat with feet slightly elevated.'
    ],
    after: [
      'Seek professional medical care at nearest trauma center or call Rescue 1122.'
    ]
  }
];

export const PAKISTAN_EMERGENCY_NUMBERS = [
  { name: 'Rescue & Ambulance (Punjab, KPK, Islamabad)', number: '1122', icon: 'Ambulance', badge: 'Fastest Response' },
  { name: 'Police Emergency Helpline', number: '15', icon: 'Shield', badge: 'Law & Order' },
  { name: 'Fire Brigade / Fire Fighting', number: '16', icon: 'Flame', badge: 'Fire & Rescue' },
  { name: 'NDMA National Disaster Management', number: '1129', icon: 'AlertTriangle', badge: 'Civil Defense' },
  { name: 'Edhi Emergency Ambulance Service', number: '130', icon: 'HeartHandshake', badge: 'Nationwide' },
  { name: 'Pakistan Red Crescent Society (PRCS)', number: '1020', icon: 'Activity', badge: 'Disaster Relief' },
  { name: 'Chhipa Ambulance Service (Sindh)', number: '1020', icon: 'Truck', badge: 'Karachi & Sindh' },
];
