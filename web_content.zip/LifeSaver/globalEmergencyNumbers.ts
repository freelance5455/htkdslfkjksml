import { CountryEmergencyData } from '../types';

export const VERIFIED_GLOBAL_EMERGENCY_DATA: Record<string, CountryEmergencyData> = {
  PK: {
    countryCode: 'PK',
    countryName: 'Pakistan',
    isVerified: true,
    verificationSource: 'National Disaster Management Authority (NDMA) & Punjab Emergency Service (Rescue 1122)',
    services: [
      {
        id: 'pk-rescue',
        category: 'ambulance',
        name: 'Rescue 1122 (Ambulance & Disaster Rescue)',
        number: '1122',
        agencyName: 'Emergency Services Academy & District Services',
        badge: 'Priority 1',
        description: 'First responder ambulance, trauma response, urban search and flood rescue'
      },
      {
        id: 'pk-police',
        category: 'police',
        name: 'Police Emergency',
        number: '15',
        agencyName: 'National Police Bureau',
        badge: 'Law & Order',
        description: 'Civil protection, rapid security response, and highway safety'
      },
      {
        id: 'pk-fire',
        category: 'fire',
        name: 'Fire Brigade Rescue',
        number: '16',
        agencyName: 'Municipal Fire Services',
        badge: 'Hazard',
        description: 'Structural fires, hazardous chemical leaks, and collapse extraction'
      },
      {
        id: 'pk-ndma',
        category: 'disaster',
        name: 'NDMA Disaster Management Helpline',
        number: '1129',
        agencyName: 'National Disaster Management Authority',
        badge: 'Disaster HQ',
        description: 'Federal disaster reporting, riverine flood bulletins, and civil defense'
      },
      {
        id: 'pk-edhi',
        category: 'ambulance',
        name: 'Edhi Foundation Emergency Service',
        number: '115',
        agencyName: 'Edhi Foundation Trust',
        badge: 'Relief',
        description: 'Nationwide volunteer ambulance network and humanitarian evacuation'
      },
      {
        id: 'pk-red-crescent',
        category: 'ambulance',
        name: 'Pakistan Red Crescent Society (PRCS)',
        number: '1030',
        agencyName: 'International Red Cross & Red Crescent Movement',
        badge: 'Medical Aid',
        description: 'Emergency first aid, blood donation dispatch, and field clinics'
      },
      {
        id: 'pk-coast-guard',
        category: 'coast_guard',
        name: 'Maritime Security & Coast Guard',
        number: '1102',
        agencyName: 'Pakistan Coast Guards & PMSA',
        badge: 'Marine Rescue',
        description: 'Coastal distress, cyclone sea search, and offshore rescue'
      }
    ]
  },
  US: {
    countryCode: 'US',
    countryName: 'United States',
    isVerified: true,
    verificationSource: 'Federal Communications Commission (FCC 911 Service) & FEMA',
    services: [
      {
        id: 'us-911',
        category: 'national',
        name: 'Unified Emergency (Police, Fire, Medical)',
        number: '911',
        agencyName: 'Universal Emergency Public Safety Answering Point (PSAP)',
        badge: 'Unified 911',
        description: 'Centralized emergency response for all life-safety and criminal emergencies'
      },
      {
        id: 'us-fema',
        category: 'disaster',
        name: 'FEMA Disaster Assistance & Information',
        number: '1-800-621-3362',
        agencyName: 'Federal Emergency Management Agency',
        badge: 'Disaster HQ',
        description: 'Federal disaster relief, shelter assistance, and declaration guidance'
      },
      {
        id: 'us-coast-guard',
        category: 'coast_guard',
        name: 'U.S. Coast Guard Search & Rescue',
        number: '1-800-323-7233',
        agencyName: 'United States Coast Guard (USCG)',
        badge: 'Maritime',
        description: 'Marine distress, offshore storm evacuation, and maritime environmental events'
      }
    ]
  },
  GB: {
    countryCode: 'GB',
    countryName: 'United Kingdom',
    isVerified: true,
    verificationSource: 'Ofcom Emergency Services Directory & Cabinet Office Civil Contingencies',
    services: [
      {
        id: 'gb-999',
        category: 'national',
        name: 'Main Emergency (Police, Ambulance, Fire, Coastguard)',
        number: '999',
        agencyName: 'UK Emergency Services Joint Protocol',
        badge: 'Universal 999',
        description: 'Immediate emergency dispatch for life-threatening crisis'
      },
      {
        id: 'gb-112',
        category: 'national',
        name: 'European Single Emergency Number',
        number: '112',
        agencyName: 'UK & European Telecom Standards',
        badge: 'Unified 112',
        description: 'Universal mobile emergency service'
      },
      {
        id: 'gb-coastguard',
        category: 'coast_guard',
        name: 'HM Coastguard Maritime Rescue',
        number: '999',
        agencyName: 'Maritime and Coastguard Agency',
        badge: 'Coastal Rescue',
        description: 'Sea search and rescue, cliff extraction, and coastal flood evacuation'
      }
    ]
  },
  CA: {
    countryCode: 'CA',
    countryName: 'Canada',
    isVerified: true,
    verificationSource: 'Canadian Radio-television and Telecommunications Commission (CRTC 9-1-1)',
    services: [
      {
        id: 'ca-911',
        category: 'national',
        name: 'Emergency Services (Police, Fire, Paramedics)',
        number: '911',
        agencyName: 'Public Safety Canada Joint Dispatch',
        badge: 'Universal 911',
        description: 'All-hazard immediate dispatch for medical, fire, and police crisis'
      },
      {
        id: 'ca-ccg',
        category: 'coast_guard',
        name: 'Canadian Coast Guard Joint Rescue',
        number: '1-800-567-5111',
        agencyName: 'Canadian Coast Guard (CCG/GCC)',
        badge: 'Marine SAR',
        description: 'Maritime search and rescue in coastal and Great Lakes waters'
      }
    ]
  },
  AU: {
    countryCode: 'AU',
    countryName: 'Australia',
    isVerified: true,
    verificationSource: 'Australian Communications and Media Authority (ACMA Triple Zero)',
    services: [
      {
        id: 'au-000',
        category: 'national',
        name: 'Triple Zero (Police, Fire, Ambulance)',
        number: '000',
        agencyName: 'Emergency Management Australia',
        badge: 'Universal 000',
        description: 'Primary national emergency service for all life-threatening emergencies'
      },
      {
        id: 'au-112',
        category: 'national',
        name: 'GSM Mobile Emergency Number',
        number: '112',
        agencyName: 'ACMA Telecom Standard',
        badge: 'Mobile 112',
        description: 'Works on all mobile phones even with no carrier SIM'
      },
      {
        id: 'au-ses',
        category: 'disaster',
        name: 'State Emergency Service (SES Flood & Storm)',
        number: '132 500',
        agencyName: 'State Emergency Service (SES)',
        badge: 'Flood & Storm',
        description: 'Emergency assistance for severe storm damage, fallen trees, and flash floods'
      }
    ]
  },
  IN: {
    countryCode: 'IN',
    countryName: 'India',
    isVerified: true,
    verificationSource: 'National Disaster Management Authority (NDMA India) & ERSS 112',
    services: [
      {
        id: 'in-112',
        category: 'national',
        name: 'National Emergency Response Support System (ERSS)',
        number: '112',
        agencyName: 'Ministry of Home Affairs ERSS',
        badge: 'Unified 112',
        description: 'Single unified emergency helpline across all Indian states'
      },
      {
        id: 'in-ambulance',
        category: 'ambulance',
        name: 'Ambulance & Medical Emergency',
        number: '108',
        agencyName: 'National Health Mission',
        badge: 'Medical 108',
        description: 'Emergency medical services and trauma ambulance dispatch'
      },
      {
        id: 'in-police',
        category: 'police',
        name: 'Police Control Room',
        number: '100',
        agencyName: 'State Police Services',
        badge: 'Police 100',
        description: 'Direct police assistance and public safety'
      },
      {
        id: 'in-fire',
        category: 'fire',
        name: 'Fire & Rescue Service',
        number: '101',
        agencyName: 'State Fire & Emergency Services',
        badge: 'Fire 101',
        description: 'Fire suppression, building collapse, and rescue'
      },
      {
        id: 'in-ndrf',
        category: 'disaster',
        name: 'National Disaster Response Force (NDRF)',
        number: '1078',
        agencyName: 'NDRF Control Room',
        badge: 'NDRF Disaster',
        description: 'Specialized disaster response for floods, cyclones, and earthquakes'
      }
    ]
  },
  BD: {
    countryCode: 'BD',
    countryName: 'Bangladesh',
    isVerified: true,
    verificationSource: 'Department of Disaster Management & National Emergency Service 999',
    services: [
      {
        id: 'bd-999',
        category: 'national',
        name: 'National Emergency Service (Police, Ambulance, Fire)',
        number: '999',
        agencyName: 'Bangladesh Police & ICT Division',
        badge: 'National 999',
        description: 'Toll-free 24/7 emergency hotline for police, fire service, and ambulance'
      },
      {
        id: 'bd-disaster',
        category: 'disaster',
        name: 'Disaster Early Warning & Cyclone Preparedness',
        number: '1090',
        agencyName: 'Ministry of Disaster Management and Relief',
        badge: 'Disaster Info',
        description: 'Toll-free Interactive Voice Response for riverine flood and cyclone warnings'
      }
    ]
  },
  AF: {
    countryCode: 'AF',
    countryName: 'Afghanistan',
    isVerified: true,
    verificationSource: 'Afghan Red Crescent Society & International Telecom Registry',
    services: [
      {
        id: 'af-ambulance',
        category: 'ambulance',
        name: 'Kabul Ambulance & Regional EMS',
        number: '112',
        agencyName: 'Ministry of Public Health',
        badge: 'Medical',
        description: 'Emergency ambulance dispatch'
      },
      {
        id: 'af-police',
        category: 'police',
        name: 'Police Emergency',
        number: '119',
        agencyName: 'Ministry of Interior',
        badge: 'Police',
        description: 'Security emergency and civil defense'
      },
      {
        id: 'af-red-crescent',
        category: 'disaster',
        name: 'Afghan Red Crescent Society',
        number: '0202500130',
        agencyName: 'ARCS Disaster Management Unit',
        badge: 'Disaster Relief',
        description: 'Earthquake relief, flash flood response, and family assistance'
      }
    ]
  },
  SA: {
    countryCode: 'SA',
    countryName: 'Saudi Arabia',
    isVerified: true,
    verificationSource: 'General Directorate of Civil Defense (GDCD) & National 911 Center',
    services: [
      {
        id: 'sa-911',
        category: 'national',
        name: 'Unified Security Operations Center (National 911)',
        number: '911',
        agencyName: 'Ministry of Interior 911 Unified Operations',
        badge: 'Unified 911',
        description: 'Single consolidated emergency number across major provinces'
      },
      {
        id: 'sa-civil-defense',
        category: 'disaster',
        name: 'Civil Defense (Disaster, Fire, Flood Rescue)',
        number: '998',
        agencyName: 'General Directorate of Civil Defense',
        badge: 'Civil Defense',
        description: 'Flash flood rescues, valley inundation, structural fire, and building collapse'
      },
      {
        id: 'sa-red-crescent',
        category: 'ambulance',
        name: 'Saudi Red Crescent Authority (Ambulance)',
        number: '997',
        agencyName: 'Saudi Red Crescent Authority',
        badge: 'Medical EMS',
        description: 'Medical emergencies, paramedic trauma response, and air ambulance'
      },
      {
        id: 'sa-police',
        category: 'police',
        name: 'Public Security Police',
        number: '999',
        agencyName: 'Public Security Directorate',
        badge: 'Police',
        description: 'Law enforcement and public emergency response'
      }
    ]
  },
  AE: {
    countryCode: 'AE',
    countryName: 'United Arab Emirates',
    isVerified: true,
    verificationSource: 'National Emergency Crisis and Disaster Management Authority (NCEMA UAE)',
    services: [
      {
        id: 'ae-police',
        category: 'police',
        name: 'Police Emergency',
        number: '999',
        agencyName: 'Ministry of Interior',
        badge: 'Police 999',
        description: 'Urgent security and general emergency response'
      },
      {
        id: 'ae-ambulance',
        category: 'ambulance',
        name: 'National Ambulance',
        number: '998',
        agencyName: 'National Ambulance UAE',
        badge: 'Medical 998',
        description: 'Emergency medical care and paramedic evacuation'
      },
      {
        id: 'ae-fire',
        category: 'fire',
        name: 'Civil Defence (Fire & Disaster Rescue)',
        number: '997',
        agencyName: 'General Directorate of Civil Defence',
        badge: 'Civil Defence',
        description: 'Fire suppression, flash flood intervention, and industrial incident containment'
      },
      {
        id: 'ae-coastguard',
        category: 'coast_guard',
        name: 'Coast Guard (Marine Rescue)',
        number: '996',
        agencyName: 'Critical Infrastructure and Coastal Protection Authority',
        badge: 'Coast Guard',
        description: 'Marine emergencies, maritime distress, and vessel rescue'
      }
    ]
  },
  TR: {
    countryCode: 'TR',
    countryName: 'Turkey',
    isVerified: true,
    verificationSource: 'AFAD (Disaster and Emergency Management Authority) & 112 Unified Service',
    services: [
      {
        id: 'tr-112',
        category: 'national',
        name: '112 Unified Emergency Call Center',
        number: '112',
        agencyName: 'Ministry of Interior 112 Command',
        badge: 'Unified 112',
        description: 'Centralized emergency dispatch for police, gendarmerie, ambulance, and fire'
      },
      {
        id: 'tr-afad',
        category: 'disaster',
        name: 'AFAD Disaster & Emergency Management',
        number: '122',
        agencyName: 'Disaster and Emergency Management Authority (AFAD)',
        badge: 'AFAD Disaster',
        description: 'National earthquake response, debris rescue, flood evacuation, and relief logistics'
      },
      {
        id: 'tr-coastguard',
        category: 'coast_guard',
        name: 'Turkish Coast Guard',
        number: '158',
        agencyName: 'Coast Guard Command',
        badge: 'Maritime',
        description: 'Sea search and rescue in Aegean, Black, and Mediterranean seas'
      }
    ]
  },
  JP: {
    countryCode: 'JP',
    countryName: 'Japan',
    isVerified: true,
    verificationSource: 'Fire and Disaster Management Agency (FDMA) & National Police Agency',
    services: [
      {
        id: 'jp-police',
        category: 'police',
        name: 'Police Emergency',
        number: '110',
        agencyName: 'National Police Agency (NPA)',
        badge: 'Police 110',
        description: 'Direct police and crime emergency dispatch'
      },
      {
        id: 'jp-fire-ambulance',
        category: 'fire',
        name: 'Fire & Ambulance Emergency Dispatch',
        number: '119',
        agencyName: 'Fire and Disaster Management Agency (FDMA)',
        badge: 'Fire / EMS 119',
        description: 'Fire suppression, medical paramedics, and structural collapse rescue'
      },
      {
        id: 'jp-coast-guard',
        category: 'coast_guard',
        name: 'Japan Coast Guard (Maritime Accidents)',
        number: '118',
        agencyName: 'Japan Coast Guard (JCG)',
        badge: 'Coast Guard 118',
        description: 'Tsunami coastal alarms, marine distress, and offshore search and rescue'
      }
    ]
  },
  DE: {
    countryCode: 'DE',
    countryName: 'Germany',
    isVerified: true,
    verificationSource: 'Federal Office of Civil Protection and Disaster Assistance (BBK Germany)',
    services: [
      {
        id: 'de-112',
        category: 'national',
        name: 'Fire Brigade & Medical Rescue (Feuerwehr & Rettungsdienst)',
        number: '112',
        agencyName: 'Joint Municipal Integrated Dispatch Centers',
        badge: 'Emergency 112',
        description: 'Standard emergency number for fire, medical, and disaster rescue'
      },
      {
        id: 'de-110',
        category: 'police',
        name: 'Police Emergency (Polizei)',
        number: '110',
        agencyName: 'Federal & State Police Forces',
        badge: 'Polizei 110',
        description: 'Immediate police and public safety response'
      }
    ]
  },
  FR: {
    countryCode: 'FR',
    countryName: 'France',
    isVerified: true,
    verificationSource: 'Ministry of the Interior & Directorate General for Civil Protection (DGSCGC)',
    services: [
      {
        id: 'fr-112',
        category: 'national',
        name: 'European Emergency Number',
        number: '112',
        agencyName: 'Civil Protection European Standard',
        badge: 'Unified 112',
        description: 'Centralized emergency access throughout French territories'
      },
      {
        id: 'fr-samu',
        category: 'ambulance',
        name: 'SAMU Urgent Medical Aid (Service d\'Aide Médicale Urgente)',
        number: '15',
        agencyName: 'SAMU Hospital Dispatch',
        badge: 'SAMU 15',
        description: 'Physician-directed emergency medical and intensive care dispatch'
      },
      {
        id: 'fr-police',
        category: 'police',
        name: 'Police / Gendarmerie',
        number: '17',
        agencyName: 'National Police and Gendarmerie',
        badge: 'Police 17',
        description: 'Law enforcement and security protection'
      },
      {
        id: 'fr-fire',
        category: 'fire',
        name: 'Sapeurs-Pompiers (Fire and Rescue)',
        number: '18',
        agencyName: 'National Fire Services',
        badge: 'Pompiers 18',
        description: 'Firefighting, chemical accidents, and flood rescue operations'
      }
    ]
  },
  ID: {
    countryCode: 'ID',
    countryName: 'Indonesia',
    isVerified: true,
    verificationSource: 'National Disaster Management Authority (BNPB) & BASARNAS',
    services: [
      {
        id: 'id-112',
        category: 'national',
        name: 'Single Emergency Call 112',
        number: '112',
        agencyName: 'Ministry of Communication and Informatics',
        badge: 'Unified 112',
        description: 'National centralized emergency assistance'
      },
      {
        id: 'id-police',
        category: 'police',
        name: 'Police (Polri)',
        number: '110',
        agencyName: 'Indonesian National Police',
        badge: 'Polri 110',
        description: 'Police emergency and civil protection'
      },
      {
        id: 'id-ambulance',
        category: 'ambulance',
        name: 'Ambulance Emergency',
        number: '118',
        agencyName: 'Ministry of Health EMS',
        badge: 'Ambulance 118',
        description: 'Hospital ambulance and paramedic response'
      },
      {
        id: 'id-fire',
        category: 'fire',
        name: 'Fire Department (Damkar)',
        number: '113',
        agencyName: 'Dinas Pemadam Kebakaran',
        badge: 'Damkar 113',
        description: 'Structural fires, wildfire response, and flood drainage assistance'
      },
      {
        id: 'id-basarnas',
        category: 'disaster',
        name: 'BASARNAS (National Search and Rescue)',
        number: '115',
        agencyName: 'Badan SAR Nasional (BASARNAS)',
        badge: 'Search & Rescue',
        description: 'Earthquake rubble extraction, volcanic evacuation, and maritime disaster search'
      }
    ]
  },
  PH: {
    countryCode: 'PH',
    countryName: 'Philippines',
    isVerified: true,
    verificationSource: 'National Disaster Risk Reduction and Management Council (NDRRMC) & 911 Commission',
    services: [
      {
        id: 'ph-911',
        category: 'national',
        name: 'Emergency 911 National Call Center',
        number: '911',
        agencyName: 'Department of the Interior and Local Government (DILG)',
        badge: 'National 911',
        description: 'Nationwide dispatch for police, fire, medical, and search & rescue'
      },
      {
        id: 'ph-ndrrmc',
        category: 'disaster',
        name: 'NDRRMC Disaster Operations Center',
        number: '(02) 8911-5061',
        agencyName: 'National Disaster Risk Reduction and Management Council',
        badge: 'Typhoon / Disaster',
        description: 'Typhoon tracking, flood monitoring, volcanic eruption and earthquake coordination'
      },
      {
        id: 'ph-red-cross',
        category: 'ambulance',
        name: 'Philippine Red Cross Emergency Operations',
        number: '143',
        agencyName: 'Philippine Red Cross',
        badge: 'Red Cross 143',
        description: 'Ambulance dispatch, disaster relief aid, and emergency blood services'
      },
      {
        id: 'ph-coast-guard',
        category: 'coast_guard',
        name: 'Philippine Coast Guard Command',
        number: '(02) 8527-8481',
        agencyName: 'Philippine Coast Guard (PCG)',
        badge: 'Coast Guard',
        description: 'Maritime rescue, typhoon storm surge alerts, and boat passenger safety'
      }
    ]
  },
  IT: {
    countryCode: 'IT',
    countryName: 'Italy',
    isVerified: true,
    verificationSource: 'Dipartimento della Protezione Civile & NUE 112 Standard',
    services: [
      {
        id: 'it-112',
        category: 'national',
        name: 'Single Emergency Number (NUE 112)',
        number: '112',
        agencyName: 'Ministero dell\'Interno',
        badge: 'Unified 112',
        description: 'Centralized emergency access covering Carabinieri, Police, Medical, and Fire'
      },
      {
        id: 'it-118',
        category: 'ambulance',
        name: 'Emergency Medical Service (Emergenza Sanitaria)',
        number: '118',
        agencyName: 'Servizio Sanitario Nazionale (SSN)',
        badge: 'Health 118',
        description: 'Direct medical dispatch, trauma resuscitation, and air ambulance'
      },
      {
        id: 'it-115',
        category: 'fire',
        name: 'Fire & Rescue (Vigili del Fuoco)',
        number: '115',
        agencyName: 'Corpo Nazionale dei Vigili del Fuoco',
        badge: 'Fire 115',
        description: 'Earthquake extraction, wildfire fighting, and flood intervention'
      }
    ]
  },
  ES: {
    countryCode: 'ES',
    countryName: 'Spain',
    isVerified: true,
    verificationSource: 'Dirección General de Protección Civil y Emergencias & 112 Center',
    services: [
      {
        id: 'es-112',
        category: 'national',
        name: '112 Emergency Operations Center',
        number: '112',
        agencyName: 'Centros de Atención de Urgencias y Emergencias 112',
        badge: 'Unified 112',
        description: 'Multilingual unified emergency service covering all autonomous communities'
      },
      {
        id: 'es-police',
        category: 'police',
        name: 'National Police (Policía Nacional)',
        number: '091',
        agencyName: 'Cuerpo Nacional de Policía',
        badge: 'Policía 091',
        description: 'Direct urban security emergency and citizen assistance'
      },
      {
        id: 'es-civil-guard',
        category: 'police',
        name: 'Guardia Civil',
        number: '062',
        agencyName: 'Dirección General de la Guardia Civil',
        badge: 'Guardia 062',
        description: 'Rural security, mountain rescue (GREIM), and coastal surveillance'
      }
    ]
  },
  BR: {
    countryCode: 'BR',
    countryName: 'Brazil',
    isVerified: true,
    verificationSource: 'Secretaria Nacional de Proteção e Defesa Civil (SEDEC) & Ministério da Saúde',
    services: [
      {
        id: 'br-190',
        category: 'police',
        name: 'Military Police (Polícia Militar)',
        number: '190',
        agencyName: 'Polícia Militar dos Estados',
        badge: 'Polícia 190',
        description: 'Primary public safety and crime emergency dispatch'
      },
      {
        id: 'br-192',
        category: 'ambulance',
        name: 'SAMU Mobile Emergency Attendance',
        number: '192',
        agencyName: 'Serviço de Atendimento Móvel de Urgência (SAMU 192)',
        badge: 'SAMU 192',
        description: 'Rapid medical response and advanced trauma life support'
      },
      {
        id: 'br-193',
        category: 'fire',
        name: 'Firefighters & Rescue (Corpo de Bombeiros)',
        number: '193',
        agencyName: 'Corpo de Bombeiros Militar',
        badge: 'Bombeiros 193',
        description: 'Fire suppression, building collapse, flood rescues, and hazardous materials'
      },
      {
        id: 'br-199',
        category: 'disaster',
        name: 'Civil Defense (Defesa Civil)',
        number: '199',
        agencyName: 'Defesa Civil Nacional',
        badge: 'Defesa Civil',
        description: 'Landslide warnings, flood evacuation, and severe weather disaster coordination'
      }
    ]
  },
  ZA: {
    countryCode: 'ZA',
    countryName: 'South Africa',
    isVerified: true,
    verificationSource: 'National Disaster Management Centre (NDMC) & SAPS',
    services: [
      {
        id: 'za-112',
        category: 'national',
        name: 'National Cellular Emergency Number',
        number: '112',
        agencyName: 'Universal Emergency Access Standard',
        badge: 'Mobile 112',
        description: 'Routed to relevant emergency dispatch from any mobile device'
      },
      {
        id: 'za-police',
        category: 'police',
        name: 'South African Police Service (SAPS)',
        number: '10111',
        agencyName: 'SAPS Flying Squad and Emergency Dispatch',
        badge: 'Police 10111',
        description: 'Immediate crime and public safety emergency line'
      },
      {
        id: 'za-ambulance',
        category: 'ambulance',
        name: 'Public Emergency Medical Services',
        number: '10177',
        agencyName: 'Provincial Department of Health EMS',
        badge: 'Medical 10177',
        description: 'Ambulance and paramedical assistance'
      }
    ]
  },
  EG: {
    countryCode: 'EG',
    countryName: 'Egypt',
    isVerified: true,
    verificationSource: 'Ministry of Interior & Ministry of Health and Population',
    services: [
      {
        id: 'eg-police',
        category: 'police',
        name: 'Police Emergency',
        number: '122',
        agencyName: 'Ministry of Interior Emergency Police',
        badge: 'Police 122',
        description: 'General emergency and security intervention'
      },
      {
        id: 'eg-ambulance',
        category: 'ambulance',
        name: 'Egyptian Ambulance Authority',
        number: '123',
        agencyName: 'Ministry of Health Ambulance Authority',
        badge: 'Ambulance 123',
        description: 'Trauma ambulance dispatch and medical emergency services'
      },
      {
        id: 'eg-fire',
        category: 'fire',
        name: 'Civil Protection & Firefighting',
        number: '180',
        agencyName: 'Civil Protection Administration',
        badge: 'Fire 180',
        description: 'Fire suppression, building collapse, and hazardous incident rescue'
      }
    ]
  },
  NZ: {
    countryCode: 'NZ',
    countryName: 'New Zealand',
    isVerified: true,
    verificationSource: 'National Emergency Management Agency (NEMA) & Emergency 111',
    services: [
      {
        id: 'nz-111',
        category: 'national',
        name: 'Emergency Services 111 (Police, Fire, Ambulance)',
        number: '111',
        agencyName: 'New Zealand Police, Fire and Emergency NZ, St John Ambulance',
        badge: 'Unified 111',
        description: 'Single national number for life-threatening emergencies'
      },
      {
        id: 'nz-civil-defence',
        category: 'disaster',
        name: 'National Emergency Management Agency (Civil Defence)',
        number: '0800 22 22 00',
        agencyName: 'National Emergency Management Agency (NEMA)',
        badge: 'Civil Defence',
        description: 'Tsunami warning updates, major earthquake response, and regional civil defence'
      }
    ]
  },
  MX: {
    countryCode: 'MX',
    countryName: 'Mexico',
    isVerified: true,
    verificationSource: 'Coordinación Nacional de Protección Civil (CNPC) & 911 México',
    services: [
      {
        id: 'mx-911',
        category: 'national',
        name: 'Unified Emergency 911 (Policía, Cruz Roja, Bomberos)',
        number: '911',
        agencyName: 'Secretariado Ejecutivo del Sistema Nacional de Seguridad Pública',
        badge: 'Unified 911',
        description: 'Centralized emergency response across all 32 Mexican states'
      },
      {
        id: 'mx-proteccion-civil',
        category: 'disaster',
        name: 'Protección Civil Nacional',
        number: '088',
        agencyName: 'Centro Nacional de Prevención de Desastres (CENAPRED)',
        badge: 'Civil Defense',
        description: 'Volcanic monitoring (Popocatépetl), seismic alerts (SASMEX), and hurricane response'
      }
    ]
  },
  NG: {
    countryCode: 'NG',
    countryName: 'Nigeria',
    isVerified: true,
    verificationSource: 'National Emergency Management Agency (NEMA Nigeria) & NCC 112',
    services: [
      {
        id: 'ng-112',
        category: 'national',
        name: 'National Emergency Communications Center',
        number: '112',
        agencyName: 'Nigerian Communications Commission (NCC)',
        badge: 'Unified 112',
        description: 'Toll-free national emergency response linking police, fire, and health'
      },
      {
        id: 'ng-nema',
        category: 'disaster',
        name: 'NEMA Disaster Operations Helpline',
        number: '0800 2255 6362',
        agencyName: 'National Emergency Management Agency (NEMA)',
        badge: 'NEMA Disaster',
        description: 'National flood response, displaced person relief, and crisis coordination'
      }
    ]
  },
  KE: {
    countryCode: 'KE',
    countryName: 'Kenya',
    isVerified: true,
    verificationSource: 'National Disaster Operations Centre (NDOC) & National Police Service',
    services: [
      {
        id: 'ke-999',
        category: 'national',
        name: 'National Emergency Hotline',
        number: '999',
        agencyName: 'National Police Service & Emergency Operations',
        badge: 'Emergency 999',
        description: 'Main emergency dispatch for police, fire, and ambulance'
      },
      {
        id: 'ke-112',
        category: 'national',
        name: 'Unified Mobile Emergency Number',
        number: '112',
        agencyName: 'Communications Authority of Kenya',
        badge: 'Mobile 112',
        description: 'Universal emergency service accessible from all mobile networks'
      },
      {
        id: 'ke-red-cross',
        category: 'ambulance',
        name: 'Kenya Red Cross Emergency Hotline',
        number: '1199',
        agencyName: 'Kenya Red Cross Society (KRCS)',
        badge: 'Red Cross 1199',
        description: 'Emergency ambulance, disaster rescue, and drought/flood relief'
      }
    ]
  }
};

// Full list of countries for the global country selector
export interface CountryOption {
  code: string;
  name: string;
  hasVerifiedData: boolean;
}

export const GLOBAL_COUNTRIES_LIST: CountryOption[] = [
  { code: 'AF', name: 'Afghanistan', hasVerifiedData: true },
  { code: 'AL', name: 'Albania', hasVerifiedData: false },
  { code: 'DZ', name: 'Algeria', hasVerifiedData: false },
  { code: 'AR', name: 'Argentina', hasVerifiedData: false },
  { code: 'AU', name: 'Australia', hasVerifiedData: true },
  { code: 'AT', name: 'Austria', hasVerifiedData: false },
  { code: 'BD', name: 'Bangladesh', hasVerifiedData: true },
  { code: 'BE', name: 'Belgium', hasVerifiedData: false },
  { code: 'BR', name: 'Brazil', hasVerifiedData: true },
  { code: 'CA', name: 'Canada', hasVerifiedData: true },
  { code: 'CL', name: 'Chile', hasVerifiedData: false },
  { code: 'CN', name: 'China', hasVerifiedData: false },
  { code: 'CO', name: 'Colombia', hasVerifiedData: false },
  { code: 'EG', name: 'Egypt', hasVerifiedData: true },
  { code: 'FR', name: 'France', hasVerifiedData: true },
  { code: 'DE', name: 'Germany', hasVerifiedData: true },
  { code: 'GR', name: 'Greece', hasVerifiedData: false },
  { code: 'IN', name: 'India', hasVerifiedData: true },
  { code: 'ID', name: 'Indonesia', hasVerifiedData: true },
  { code: 'IR', name: 'Iran', hasVerifiedData: false },
  { code: 'IQ', name: 'Iraq', hasVerifiedData: false },
  { code: 'IE', name: 'Ireland', hasVerifiedData: false },
  { code: 'IT', name: 'Italy', hasVerifiedData: true },
  { code: 'JP', name: 'Japan', hasVerifiedData: true },
  { code: 'JO', name: 'Jordan', hasVerifiedData: false },
  { code: 'KZ', name: 'Kazakhstan', hasVerifiedData: false },
  { code: 'KE', name: 'Kenya', hasVerifiedData: true },
  { code: 'KW', name: 'Kuwait', hasVerifiedData: false },
  { code: 'MY', name: 'Malaysia', hasVerifiedData: false },
  { code: 'MX', name: 'Mexico', hasVerifiedData: true },
  { code: 'MA', name: 'Morocco', hasVerifiedData: false },
  { code: 'NP', name: 'Nepal', hasVerifiedData: false },
  { code: 'NL', name: 'Netherlands', hasVerifiedData: false },
  { code: 'NZ', name: 'New Zealand', hasVerifiedData: true },
  { code: 'NG', name: 'Nigeria', hasVerifiedData: true },
  { code: 'NO', name: 'Norway', hasVerifiedData: false },
  { code: 'OM', name: 'Oman', hasVerifiedData: false },
  { code: 'PK', name: 'Pakistan', hasVerifiedData: true },
  { code: 'PH', name: 'Philippines', hasVerifiedData: true },
  { code: 'PL', name: 'Poland', hasVerifiedData: false },
  { code: 'PT', name: 'Portugal', hasVerifiedData: false },
  { code: 'QA', name: 'Qatar', hasVerifiedData: false },
  { code: 'SA', name: 'Saudi Arabia', hasVerifiedData: true },
  { code: 'SG', name: 'Singapore', hasVerifiedData: false },
  { code: 'ZA', name: 'South Africa', hasVerifiedData: true },
  { code: 'KR', name: 'South Korea', hasVerifiedData: false },
  { code: 'ES', name: 'Spain', hasVerifiedData: true },
  { code: 'LK', name: 'Sri Lanka', hasVerifiedData: false },
  { code: 'SE', name: 'Sweden', hasVerifiedData: false },
  { code: 'CH', name: 'Switzerland', hasVerifiedData: false },
  { code: 'TH', name: 'Thailand', hasVerifiedData: false },
  { code: 'TR', name: 'Turkey', hasVerifiedData: true },
  { code: 'AE', name: 'United Arab Emirates', hasVerifiedData: true },
  { code: 'GB', name: 'United Kingdom', hasVerifiedData: true },
  { code: 'US', name: 'United States', hasVerifiedData: true },
  { code: 'VN', name: 'Vietnam', hasVerifiedData: false }
];

// Helper to determine the country from location name or coordinates
export function getCountryCodeFromLocation(locationName: string): string {
  const normalized = locationName.toLowerCase();

  if (normalized.includes('pakistan') || normalized.includes('islamabad') || normalized.includes('karachi') || normalized.includes('lahore') || normalized.includes('peshawar') || normalized.includes('quetta')) {
    return 'PK';
  }
  if (normalized.includes('united states') || normalized.includes('usa') || normalized.includes('san francisco') || normalized.includes('california') || normalized.includes('new york')) {
    return 'US';
  }
  if (normalized.includes('united kingdom') || normalized.includes('uk') || normalized.includes('london') || normalized.includes('england') || normalized.includes('scotland')) {
    return 'GB';
  }
  if (normalized.includes('australia') || normalized.includes('sydney') || normalized.includes('melbourne')) {
    return 'AU';
  }
  if (normalized.includes('canada') || normalized.includes('toronto') || normalized.includes('vancouver')) {
    return 'CA';
  }
  if (normalized.includes('india') || normalized.includes('delhi') || normalized.includes('mumbai')) {
    return 'IN';
  }
  if (normalized.includes('japan') || normalized.includes('tokyo') || normalized.includes('osaka')) {
    return 'JP';
  }
  if (normalized.includes('bangladesh') || normalized.includes('dhaka')) {
    return 'BD';
  }
  if (normalized.includes('afghanistan') || normalized.includes('kabul')) {
    return 'AF';
  }
  if (normalized.includes('saudi arabia') || normalized.includes('riyadh') || normalized.includes('jeddah')) {
    return 'SA';
  }
  if (normalized.includes('united arab emirates') || normalized.includes('uae') || normalized.includes('dubai') || normalized.includes('abu dhabi')) {
    return 'AE';
  }
  if (normalized.includes('turkey') || normalized.includes('türkiye') || normalized.includes('istanbul') || normalized.includes('ankara')) {
    return 'TR';
  }
  if (normalized.includes('germany') || normalized.includes('berlin') || normalized.includes('munich')) {
    return 'DE';
  }
  if (normalized.includes('france') || normalized.includes('paris')) {
    return 'FR';
  }
  if (normalized.includes('italy') || normalized.includes('rome') || normalized.includes('milan')) {
    return 'IT';
  }
  if (normalized.includes('spain') || normalized.includes('madrid') || normalized.includes('barcelona')) {
    return 'ES';
  }
  if (normalized.includes('brazil') || normalized.includes('brasil') || normalized.includes('são paulo') || normalized.includes('rio')) {
    return 'BR';
  }
  if (normalized.includes('south africa') || normalized.includes('johannesburg') || normalized.includes('cape town')) {
    return 'ZA';
  }
  if (normalized.includes('indonesia') || normalized.includes('jakarta')) {
    return 'ID';
  }
  if (normalized.includes('philippines') || normalized.includes('manila')) {
    return 'PH';
  }
  if (normalized.includes('egypt') || normalized.includes('cairo')) {
    return 'EG';
  }
  if (normalized.includes('new zealand') || normalized.includes('auckland') || normalized.includes('wellington')) {
    return 'NZ';
  }
  if (normalized.includes('mexico') || normalized.includes('mexico city')) {
    return 'MX';
  }
  if (normalized.includes('nigeria') || normalized.includes('lagos') || normalized.includes('abuja')) {
    return 'NG';
  }
  if (normalized.includes('kenya') || normalized.includes('nairobi')) {
    return 'KE';
  }

  return 'PK'; // Default fallback
}

// Function to get emergency data for a country code
export function getCountryEmergencyData(countryCode: string, countryNameFallback?: string): CountryEmergencyData {
  const code = countryCode.toUpperCase();
  if (VERIFIED_GLOBAL_EMERGENCY_DATA[code]) {
    return VERIFIED_GLOBAL_EMERGENCY_DATA[code];
  }

  // If verified data is not present in our verified official register, explicitly mark as unverified
  const matchedCountry = GLOBAL_COUNTRIES_LIST.find((c) => c.code === code);
  const name = matchedCountry ? matchedCountry.name : (countryNameFallback || 'Selected Region');

  return {
    countryCode: code,
    countryName: name,
    isVerified: false,
    verificationSource: 'Unverified / International Registry Lookup',
    unverifiedNotice: `Verified national emergency dispatch numbers for ${name} are currently not registered in our verified directory. In an emergency, contact your nearest municipal police station, general hospital, or local civil defense headquarters. Always follow local authorities.`,
    services: []
  };
}
