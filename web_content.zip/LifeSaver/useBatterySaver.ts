import { useState, useEffect, useCallback } from 'react';

export function useBatterySaver() {
  const [batterySaverActive, setBatterySaverActiveState] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('lifesaver_battery_saver');
      if (saved !== null) return saved === 'true';
    } catch (_) {}
    return false;
  });

  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean | null>(null);
  const [isSupported, setIsSupported] = useState<boolean>(false);

  useEffect(() => {
    let batteryObj: any = null;

    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        batteryObj = battery;
        setIsSupported(true);
        setBatteryLevel(Math.round(battery.level * 100));
        setIsCharging(battery.charging);

        // Auto-enable battery saver if critically low battery (<= 15%) and not charging, unless user explicitly turned it off
        if (battery.level <= 0.15 && !battery.charging) {
          const userSaved = localStorage.getItem('lifesaver_battery_saver');
          if (userSaved === null) {
            setBatterySaverActiveState(true);
            try {
              localStorage.setItem('lifesaver_battery_saver', 'true');
            } catch (_) {}
          }
        }

        const handleLevelChange = () => {
          setBatteryLevel(Math.round(battery.level * 100));
          if (battery.level <= 0.15 && !battery.charging) {
            const userSaved = localStorage.getItem('lifesaver_battery_saver');
            if (userSaved === null) {
              setBatterySaverActiveState(true);
            }
          }
        };

        const handleChargingChange = () => {
          setIsCharging(battery.charging);
        };

        battery.addEventListener('levelchange', handleLevelChange);
        battery.addEventListener('chargingchange', handleChargingChange);
      }).catch(() => {
        setIsSupported(false);
      });
    }

    return () => {
      // cleanup is handled automatically when component unmounts
    };
  }, []);

  const setBatterySaverActive = useCallback((active: boolean) => {
    setBatterySaverActiveState(active);
    try {
      localStorage.setItem('lifesaver_battery_saver', active ? 'true' : 'false');
    } catch (_) {}
  }, []);

  const toggleBatterySaver = useCallback(() => {
    setBatterySaverActive(!batterySaverActive);
  }, [batterySaverActive, setBatterySaverActive]);

  // Synchronisation intervals:
  // In Battery Saver mode: 20 minutes (1,200,000 ms) or manual
  // In Normal mode: 3 minutes (180,000 ms)
  const syncIntervalMs = batterySaverActive ? 1200000 : 180000;

  return {
    batterySaverActive,
    setBatterySaverActive,
    toggleBatterySaver,
    batteryLevel,
    isCharging,
    isSupported,
    syncIntervalMs
  };
}
