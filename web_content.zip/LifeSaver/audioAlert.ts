// Web Audio API emergency alarm generator (100% offline capable)
let audioCtx: AudioContext | null = null;
let oscillator: OscillatorNode | null = null;
let gainNode: GainNode | null = null;
let sirenInterval: any = null;

function getAudioContext(): AudioContext {
  if (!audioCtx || audioCtx.state === 'closed') {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export const playEmergencySiren = () => {
  stopEmergencySiren();
  try {
    const ctx = getAudioContext();
    oscillator = ctx.createOscillator();
    gainNode = ctx.createGain();

    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(650, ctx.currentTime);

    gainNode.gain.setValueAtTime(0.25, ctx.currentTime);

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    oscillator.start();

    let high = false;
    sirenInterval = setInterval(() => {
      if (!oscillator || !ctx) return;
      const targetFreq = high ? 650 : 1100;
      oscillator.frequency.exponentialRampToValueAtTime(targetFreq, ctx.currentTime + 0.35);
      high = !high;
    }, 450);

    return true;
  } catch (err) {
    console.warn('Web Audio could not start:', err);
    return false;
  }
};

export const playMorseSOS = () => {
  stopEmergencySiren();
  try {
    const ctx = getAudioContext();
    // SOS in Morse: ... --- ...
    // dot: 100ms, dash: 300ms, element space: 100ms, letter space: 300ms
    const timings: { on: number; off: number }[] = [
      { on: 100, off: 100 }, // S
      { on: 100, off: 100 },
      { on: 100, off: 300 },
      { on: 300, off: 100 }, // O
      { on: 300, off: 100 },
      { on: 300, off: 300 },
      { on: 100, off: 100 }, // S
      { on: 100, off: 100 },
      { on: 100, off: 600 },
    ];

    let currentStep = 0;
    const playNext = () => {
      const step = timings[currentStep % timings.length];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 tone
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();

      setTimeout(() => {
        try {
          osc.stop();
          osc.disconnect();
        } catch (_) {}

        currentStep++;
        sirenInterval = setTimeout(playNext, step.off);
      }, step.on);
    };

    playNext();
    return true;
  } catch (err) {
    console.warn('Morse SOS failed:', err);
    return false;
  }
};

export const stopEmergencySiren = () => {
  if (sirenInterval) {
    clearInterval(sirenInterval);
    clearTimeout(sirenInterval);
    sirenInterval = null;
  }
  if (oscillator) {
    try {
      oscillator.stop();
      oscillator.disconnect();
    } catch (_) {}
    oscillator = null;
  }
  if (gainNode) {
    try {
      gainNode.disconnect();
    } catch (_) {}
    gainNode = null;
  }
};
