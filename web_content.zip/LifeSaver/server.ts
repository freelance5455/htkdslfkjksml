import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface GDACSRawItem {
  id: string;
  title: string;
  description: string;
  type: 'earthquake' | 'flood' | 'cyclone' | 'volcano' | 'drought';
  severity: 'critical' | 'warning' | 'advisory';
  priorityLevel: 1 | 2 | 3;
  source: 'gdacs';
  sourceName: string;
  sourceUrl: string;
  isOfficialEmergency: boolean;
  status: string;
  countryName: string;
  regionName: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  locationName: string;
  timestamp: string;
  affectedPopulationEstimate?: string;
  affectedArea?: {
    type: 'bbox' | 'radius_polygon' | 'satellite_swath';
    bounds?: [[number, number], [number, number]]; // [[south, west], [north, east]]
    radiusKm?: number;
    description?: string;
    isOfficialBoundary: boolean;
  };
  safetyActions: string[];
}

// In-memory cache for official GDACS feed
let cachedAlerts: GDACSRawItem[] = [];
let cacheTimestamp = 0;
const CACHE_TTL_MS = 150000; // 2.5 minutes cache to prevent hammering GDACS servers

function decodeXmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

function parseGdacsXml(xmlText: string): GDACSRawItem[] {
  const alerts: GDACSRawItem[] = [];
  const itemChunks = xmlText.split('<item>');

  // Skip the first chunk which is channel metadata
  for (let i = 1; i < itemChunks.length; i++) {
    const chunk = itemChunks[i];
    
    // Extract Event Type (EQ: Earthquake, FL: Flood, TC: Tropical Cyclone, VO: Volcano, DR: Drought)
    const rawType = chunk.match(/<gdacs:eventtype>(.*?)<\/gdacs:eventtype>/i)?.[1]?.trim()?.toUpperCase();
    if (!rawType) continue;

    let disasterType: 'earthquake' | 'flood' | 'cyclone' | 'volcano' | 'drought';
    if (rawType === 'EQ') disasterType = 'earthquake';
    else if (rawType === 'FL') disasterType = 'flood';
    else if (rawType === 'TC') disasterType = 'cyclone';
    else if (rawType === 'VO') disasterType = 'volcano';
    else if (rawType === 'DR') disasterType = 'drought';
    else continue;

    // Coordinates (geo:lat, geo:long or georss:point)
    let lat: number | null = null;
    let lon: number | null = null;

    const latMatch = chunk.match(/<geo:lat>(.*?)<\/geo:lat>/i)?.[1];
    const lonMatch = chunk.match(/<geo:long>(.*?)<\/geo:long>/i)?.[1];
    if (latMatch && lonMatch) {
      lat = parseFloat(latMatch);
      lon = parseFloat(lonMatch);
    } else {
      const georss = chunk.match(/<georss:point>(.*?)<\/georss:point>/i)?.[1]?.trim();
      if (georss) {
        const parts = georss.split(/\s+/);
        if (parts.length >= 2) {
          lat = parseFloat(parts[0]);
          lon = parseFloat(parts[1]);
        }
      }
    }

    if (lat === null || lon === null || isNaN(lat) || isNaN(lon)) {
      continue;
    }

    // Title & Description
    const rawTitle = chunk.match(/<title>(.*?)<\/title>/i)?.[1] || `${disasterType.toUpperCase()} Alert`;
    const title = decodeXmlEntities(rawTitle.replace(/<!\[CDATA\[(.*?)\]\]>/g, '$1')).trim();

    const rawDesc = chunk.match(/<description>(.*?)<\/description>/i)?.[1] || '';
    const description = decodeXmlEntities(rawDesc.replace(/<!\[CDATA\[(.*?)\]\]>/g, '$1')).trim();

    // Link / URL for verification
    const rawLink = chunk.match(/<link>(.*?)<\/link>/i)?.[1] || 'https://www.gdacs.org';
    const link = decodeXmlEntities(rawLink).trim();

    // ID / Guid
    const guidMatch = chunk.match(/<guid.*?>(.*?)<\/guid>/i)?.[1];
    const id = guidMatch ? `gdacs-${guidMatch.trim()}` : `gdacs-${disasterType}-${i}`;

    // Timestamp
    const pubDate = chunk.match(/<pubDate>(.*?)<\/pubDate>/i)?.[1];
    const timestamp = pubDate ? new Date(pubDate).toISOString() : new Date().toISOString();

    // Alert Level & Severity
    const alertLevel = chunk.match(/<gdacs:alertlevel>(.*?)<\/gdacs:alertlevel>/i)?.[1]?.toLowerCase() || '';
    let severity: 'critical' | 'warning' | 'advisory' = 'advisory';
    if (alertLevel === 'red') severity = 'critical';
    else if (alertLevel === 'orange') severity = 'warning';
    else severity = 'advisory';

    // Status: Check iscurrent tag
    const isCurrent = chunk.match(/<gdacs:iscurrent>(.*?)<\/gdacs:iscurrent>/i)?.[1]?.toLowerCase() === 'true';
    const status = isCurrent ? 'Active Event' : 'Monitoring Advisory';

    // Location / Country
    const country = chunk.match(/<gdacs:country>(.*?)<\/gdacs:country>/i)?.[1]?.trim() || '';
    let locationName = country || 'Affected Region';
    if (!country) {
      const inMatch = title.match(/in\s+([A-Za-z\s,-]+)/i);
      if (inMatch) {
        locationName = inMatch[1].trim();
      }
    }

    // Affected Population estimate
    const populationMatch = chunk.match(/<gdacs:population.*?>(.*?)<\/gdacs:population>/i)?.[1]?.trim();
    const affectedPopulationEstimate = populationMatch ? `${populationMatch} people in zone` : undefined;

    // Geographic Affected Area (extract official <gdacs:bbox>lonmin lonmax latmin latmax</gdacs:bbox>)
    let affectedArea: GDACSRawItem['affectedArea'];
    const bboxText = chunk.match(/<gdacs:bbox>(.*?)<\/gdacs:bbox>/i)?.[1]?.trim();
    if (bboxText) {
      const parts = bboxText.split(/\s+/).map((n) => parseFloat(n));
      if (parts.length === 4 && parts.every((n) => !isNaN(n))) {
        const [lonmin, lonmax, latmin, latmax] = parts;
        // Ensure valid latitude (-90 to 90) and longitude (-180 to 180)
        if (latmin >= -90 && latmax <= 90 && lonmin >= -180 && lonmax <= 180 && latmax > latmin && lonmax > lonmin) {
          affectedArea = {
            type: 'bbox',
            bounds: [[latmin, lonmin], [latmax, lonmax]],
            description: `Official GDACS impact bounding boundary (${Math.round((latmax - latmin) * 111)}km × ${Math.round((lonmax - lonmin) * 111)}km)`,
            isOfficialBoundary: true
          };
        }
      }
    }

    // If bbox was not available, derive appropriate radius for event types based on official GDACS alert score / severity
    if (!affectedArea) {
      if (disasterType === 'cyclone') {
        const radius = severity === 'critical' ? 250 : severity === 'warning' ? 180 : 120;
        affectedArea = {
          type: 'radius_polygon',
          radiusKm: radius,
          description: `Estimated tropical cyclone gale wind impact zone (${radius} km radius)`,
          isOfficialBoundary: false
        };
      } else if (disasterType === 'flood') {
        const radius = severity === 'critical' ? 100 : severity === 'warning' ? 60 : 40;
        affectedArea = {
          type: 'radius_polygon',
          radiusKm: radius,
          description: `River catchment & localized flood impact zone (~${radius} km)`,
          isOfficialBoundary: false
        };
      }
    }

    // Safety Actions tailored to verified event type
    const safetyActions: string[] = [];
    if (disasterType === 'flood') {
      safetyActions.push('Avoid crossing moving waterways, causeways, or low-lying underpasses.');
      safetyActions.push('Move to higher ground immediately if water levels begin rising.');
      safetyActions.push('Shut off gas and main electricity supply if water enters residential areas.');
    } else if (disasterType === 'cyclone') {
      safetyActions.push('Stay indoors away from external windows, glass doors, and flying debris.');
      safetyActions.push('Charge emergency radios, power banks, and secure outdoor loose items.');
      safetyActions.push('Follow official civil defense pre-emptive coastal evacuation notices.');
    } else if (disasterType === 'earthquake') {
      safetyActions.push('Drop, Cover, and Hold On beneath sturdy tables or interior frames.');
      safetyActions.push('Stay clear of glass facades, overhead brickwork, and power cables.');
      safetyActions.push('Inspect surroundings for gas leaks or electrical hazards before moving.');
    } else if (disasterType === 'volcano') {
      safetyActions.push('Wear N95 masks or damp cloth to protect respiratory tract from abrasive ash.');
      safetyActions.push('Evacuate designated exclusion zones immediately as instructed by civil authorities.');
      safetyActions.push('Stay indoors with doors and windows sealed against heavy ashfall.');
    } else {
      safetyActions.push('Monitor official national disaster agency broadcasts and community alerts.');
      safetyActions.push('Maintain an emergency grab bag with food, water, flashlights, and vital medicine.');
    }

    const priorityLevel: 1 | 2 | 3 = severity === 'critical' ? 1 : severity === 'warning' ? 2 : 3;

    alerts.push({
      id,
      title,
      description,
      type: disasterType,
      severity,
      priorityLevel,
      source: 'gdacs',
      sourceName: 'GDACS (Global Disaster Alert & Coordination System)',
      sourceUrl: link,
      isOfficialEmergency: true,
      status,
      countryName: country,
      regionName: locationName,
      coordinates: { lat, lng: lon },
      locationName,
      timestamp,
      affectedPopulationEstimate,
      affectedArea,
      safetyActions
    });
  }

  return alerts;
}

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // Backend Proxy Route for Official GDACS Data
  app.get('/api/gdacs', async (req: Request, res: Response) => {
    const now = Date.now();
    
    // Return cached response if valid
    if (cachedAlerts.length > 0 && now - cacheTimestamp < CACHE_TTL_MS) {
      return res.json({
        status: 'connected',
        statusLabel: 'Connected (Live)',
        source: 'https://www.gdacs.org/xml/rss.xml',
        count: cachedAlerts.length,
        cached: true,
        alerts: cachedAlerts
      });
    }

    // Fetch official GDACS endpoint with timeout and error handling
    const officialEndpoint = 'https://www.gdacs.org/xml/rss.xml';
    try {
      const response = await fetch(officialEndpoint, {
        signal: AbortSignal.timeout(8000),
        headers: {
          'User-Agent': 'LifeSaver-Emergency-App/1.2 (Disaster Response Telemetry)'
        }
      });

      if (!response.ok) {
        return res.status(502).json({
          status: 'unavailable',
          statusLabel: 'GDACS unavailable',
          error: `GDACS server responded with status HTTP ${response.status}`,
          alerts: []
        });
      }

      const xmlText = await response.text();
      const parsedAlerts = parseGdacsXml(xmlText);

      cachedAlerts = parsedAlerts;
      cacheTimestamp = now;

      return res.json({
        status: 'connected',
        statusLabel: 'Connected (Live)',
        source: officialEndpoint,
        count: parsedAlerts.length,
        cached: false,
        alerts: parsedAlerts
      });
    } catch (error: any) {
      console.warn('GDACS backend fetch error:', error?.message || error);
      if (cachedAlerts.length > 0) {
        return res.json({
          status: 'connected',
          statusLabel: 'Connected (Cached)',
          source: officialEndpoint,
          count: cachedAlerts.length,
          cached: true,
          alerts: cachedAlerts
        });
      }

      // Do NOT invent fake data
      return res.status(503).json({
        status: 'unavailable',
        statusLabel: 'GDACS unavailable',
        error: 'Unable to reach official GDACS servers (network timeout or offline).',
        alerts: []
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', app: 'LifeSaver', timestamp: new Date().toISOString() });
  });

  // Vite middleware in dev mode / static serve in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`LifeSaver server listening on port ${PORT}`);
  });
}

startServer();
