export type DisasterType = 
  | 'earthquake' 
  | 'flood' 
  | 'cyclone' 
  | 'fire' 
  | 'volcano'
  | 'drought'
  | 'severe_weather' 
  | 'official_warning';

export type AlertSeverity = 'critical' | 'warning' | 'advisory' | 'info';

export type AlertPriorityLevel = 1 | 2 | 3 | 4 | 5;

export interface AlertPriorityInfo {
  level: AlertPriorityLevel;
  name: string;
  badge: string;
  description: string;
  color: string;
  textColor: string;
  borderColor: string;
  bgColor: string;
}

export type AlertSourceType = 'usgs' | 'gdacs' | 'nasa_firms' | 'pmd_ndma';

export interface AffectedArea {
  type: 'bbox' | 'radius_polygon' | 'satellite_swath';
  bounds?: [[number, number], [number, number]]; // [[south, west], [north, east]]
  radiusKm?: number;
  description?: string;
  isOfficialBoundary: boolean;
}

export interface AlertItem {
  id: string;
  title: string;
  description: string;
  type: DisasterType;
  severity: AlertSeverity;
  priorityLevel: AlertPriorityLevel;
  source: AlertSourceType;
  sourceName: string;
  sourceUrl?: string;
  isOfficialEmergency: boolean;
  observationNotice?: string; // Required for satellite detections
  coordinates: {
    lat: number;
    lng: number;
  };
  locationName: string;
  countryName?: string;
  regionName?: string;
  status?: string; // e.g. 'Active', 'Monitoring', 'Satellite Observation'
  timestamp: string; // ISO string
  magnitude?: number;
  depthKm?: number;
  radiusKm?: number;
  distanceKm?: number;
  affectedPopulationEstimate?: string;
  affectedArea?: AffectedArea;
  safetyActions: string[];
  isCached?: boolean;
  cachedTimestamp?: string;
}

export type Language = 'en' | 'ur' | 'ps';

export interface UserLocation {
  lat: number;
  lng: number;
  name: string;
  countryCode?: string;
  countryName?: string;
  isGPS: boolean;
  accuracyMeters?: number;
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

export interface EmergencyServiceItem {
  id: string;
  category: 'national' | 'ambulance' | 'police' | 'fire' | 'disaster' | 'coast_guard' | 'hotline';
  name: string;
  number: string;
  description?: string;
  agencyName?: string;
  badge?: string;
}

export interface CountryEmergencyData {
  countryCode: string;
  countryName: string;
  isVerified: boolean;
  verificationSource: string;
  unverifiedNotice?: string;
  services: EmergencyServiceItem[];
}

export interface MedicalProfile {
  fullName: string;
  bloodType: string;
  allergies: string;
  medications: string;
  emergencyNotes: string;
}

export interface SafetyChecklistStep {
  id: string;
  title: string;
  description: string;
  critical: boolean;
}

export interface DisasterGuide {
  id: string;
  type: DisasterType;
  title: string;
  before: string[];
  during: string[];
  after: string[];
}

export type SourceStatusType = 'connected' | 'unavailable' | 'testing';

export interface SourceHealth {
  id: AlertSourceType;
  name: string;
  category: string;
  status: SourceStatusType;
  statusLabel: string;
  endpointUrl?: string;
  details: string;
  latencyMs?: number;
  lastTested: string;
  eventsCount: number;
}

export interface FeedStatus {
  usgsConnected: boolean;
  gdacsConnected: boolean;
  firmsConnected: boolean;
  pakistanConnected: boolean;
  lastUpdated: string | null;
  errorMessage?: string;
  sources: Record<AlertSourceType, SourceHealth>;
}

export type NetworkState = 'online' | 'weak' | 'offline';

export interface BatteryStatus {
  isSupported: boolean;
  level: number; // 0.0 to 1.0
  isCharging: boolean;
  batterySaverActive: boolean;
}

export interface SmsEmergencyPayload {
  recipientNumber: string;
  recipientName: string;
  senderName: string;
  emergencyType: string;
  coordinates: { lat: number; lng: number };
  locationName: string;
  accuracyMeters?: number;
  timestamp: string;
  medicalNotes?: string;
  batteryPercent?: number;
}

