Smart ID Studio Pro - مشروع أندرويد

هذا مشروع Android Studio لتغليف ملف Smart ID Studio داخل تطبيق أندرويد يعمل محلياً دون الحاجة إلى الإنترنت.

المتطلبات:
- Android Studio حديث
- JDK 17
- Android SDK Platform 35

طريقة إنشاء APK:
1) فك ضغط الملف ZIP.
2) افتح مجلد SmartIDStudioPro من Android Studio عبر Open.
3) انتظر اكتمال Gradle Sync وتنزيل مكونات Android المطلوبة إن طلبها البرنامج.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) بعد نجاح البناء اختر locate للوصول إلى ملف APK.

معلومات التطبيق:
- الاسم: Smart ID Studio Pro
- الحزمة: com.smartid.studio
- أقل إصدار: Android 6.0 (API 23)
- صفحة HTML مضمنة داخل التطبيق، لذلك لا يحتاج التشغيل إلى اتصال إنترنت.
- التخزين المحلي يعتمد على LocalStorage الخاص بـ WebView.

ملاحظة مهمة:
هذا أرشيف مشروع Android Studio وليس ملف APK جاهزاً. بيئة العمل الحالية لا تحتوي على Android SDK أو Gradle، لذلك لم أتمكن من بناء APK والتحقق منه هنا.
