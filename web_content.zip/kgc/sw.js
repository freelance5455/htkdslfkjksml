const V='kgc-v5';
const CORE=['./','index.html','style.css','app.js','lists.js','extras.js','config.js','club.js','boot.js','manifest.webmanifest','assets/bg.webp','assets/icon-192.png','assets/icon-512.png',
 ...Array.from({length:9},(_,i)=>'assets/av/'+i+'.webp'),
 ...['spy','out','cha','wyr','maf','spi'].map(k=>'assets/tiles/'+k+'.webp')];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const r=e.request;if(r.method!=='GET')return;
 // never intercept API calls to other origins (online mode); only same-origin files and Google Fonts go through the cache
 if(new URL(r.url).origin!==location.origin&&!/fonts\.(googleapis|gstatic)\.com/.test(r.url))return;
 if(/\/config\.js$/.test(r.url)){e.respondWith(fetch(r).catch(()=>caches.match(r)));return} // settings file: always fresh when online
 e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{
  // cache Google Fonts at runtime so they work offline after the first visit
  if(res.ok&&/fonts\.(googleapis|gstatic)\.com/.test(r.url)){const cp=res.clone();caches.open(V).then(c=>c.put(r,cp))}
  return res}).catch(()=>caches.match('index.html'))));
});
