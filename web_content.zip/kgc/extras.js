/* ===== Klûba Lîstikan · extras: tournaments, daily/weekly challenges, game maker & packs ===== */
const XD={daily:null,weekly:null,packs:[]};
const x=k=>XT[k][st.lang];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const S1=s=>{s=esc(s);return S(s,s,s,s)};
const clean=s=>String(s==null?'':s).replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim();

const XT={
 tour:S('بطولة','Tournament','Tûrnûva','پاڵەوانێتی'),
 daily:S('التحديات','Challenges','Dijwarî','ئەرکەکان'),
 maker:S('صانع الألعاب','Game maker','Çêkerê lîstikan','دروستکەری یاری'),
 back:S('رجوع','Back','Vegere','گەڕانەوە'),
 /* tournament */
 tTitle:S('بطولة المعرفة','Quiz Tournament','Tûrnûvaya Zanînê','پاڵەوانێتیی زانیاری'),
 tDesc:S('مواجهات فردية بالأسئلة: كل مباراة 5 أسئلة، والفائز يتأهل حتى النهائي. الكل يجيب عن نفس السؤال.','Head-to-head quiz duels: 5 questions per match, winners advance to the final. Both players get the same question.','Pêşbaziyên du bi du: her maç 5 pirs e, serkeftî diçe fînalê. Her du lîstikvan heman pirsê dibînin.','ململانێی دوو بە دوو: هەر یارییەک ٥ پرسیارە و براوە دەچێتە کۆتایی. هەردوو یاریزان هەمان پرسیار وەڵام دەدەنەوە.'),
 tSize:S('عدد المشاركين','Participants','Beşdar','بەشداربووان'),
 tStart:S('ابدأ البطولة','Start tournament','Tûrnûvayê dest pê bike','پاڵەوانێتی دەست پێبکە'),
 rQ:S('ربع النهائي','Quarter-final','Çaryek fînal','چارەکە کۆتایی'),
 rS:S('نصف النهائي','Semi-final','Nîv fînal','نیوە کۆتایی'),
 rF:S('النهائي','Final','Fînal','کۆتایی'),
 tPlay:S('العب المباراة','Play match','Maçê bilîze','یاریەکە بکە'),
 qn:S('سؤال','Question','Pirs','پرسیار'),
 sudden:S('حسم المباراة!','Sudden death!','Mirina nişkêva!','مردنی لەناکاو!'),
 corr:S('الإجابة الصحيحة','Correct answer','Bersiva rast','وەڵامی دروست'),
 adv:S('يتأهل','advances','diçe pêş','دەچێتە پێشەوە'),
 coin:S('حُسمت بالقرعة 🪙','Decided by coin toss 🪙','Bi tirê hat diyarkirin 🪙','بە پارە فڕێدان یەکلاکرایەوە 🪙'),
 champ:S('بطل البطولة','Tournament champion','Şampiyonê tûrnûvayê','پاڵەوانی پاڵەوانێتی'),
 second:S('الوصيف','Runner-up','Duyem','دووەم'),
 nextM:S('المباراة التالية','Next match','Maça din','یاریی دواتر'),
 /* challenges */
 dTitle:S('تحديات اليوم','Daily challenges','Dijwariyên rojane','ئەرکە ڕۆژانەکان'),
 wTitle:S('تحديات الأسبوع','Weekly challenges','Dijwariyên hefteyî','ئەرکە هەفتانەکان'),
 c_play2:S('العب مباراتين','Play 2 games','Du lîstikan bilîze','دوو یاری بکە'),
 c_win1:S('اربح لعبة واحدة','Win 1 game','Yek lîstikê bibe','یەک یاری ببەرەوە'),
 c_quiz:S('أجب 3 من 5 أسئلة اليوم بشكل صحيح','Answer 3 of 5 daily questions correctly','Ji 5 pirsên rojê 3 rast bersiv bide','لە ٥ پرسیاری ئەمڕۆ ٣ ڕاست وەڵام بدەرەوە'),
 w_play10:S('العب 10 مباريات هذا الأسبوع','Play 10 games this week','Vê hefteyê 10 lîstikan bilîze','ئەم هەفتەیە ١٠ یاری بکە'),
 w_dq3:S('أكمل سؤال اليوم في 3 أيام مختلفة','Finish the daily quiz on 3 different days','Di 3 rojên cuda de pirsa rojê biqedîne','لە ٣ ڕۆژی جیاواز پرسیاری ڕۆژ تەواو بکە'),
 claim:S('استلم','Claim','Bistîne','وەربگرە'),
 dq:S('سؤال اليوم','Daily quiz','Pirsa rojê','پرسیاری ڕۆژ'),
 dqDone:S('أنجزته اليوم','Done today','Îro qediya','ئەمڕۆ تەواو بوو'),
 rewardTo:S('المكافآت تذهب إلى','Rewards go to','Xelat diçe ba','خەڵاتەکان دەچن بۆ'),
 /* maker */
 mTitle:S('صانع الألعاب والحزم','Game maker & packs','Çêkerê lîstik û pakêtan','دروستکەری یاری و پاکێت'),
 mDesc:S('اصنع حزمة أسئلة تلعبها كمسابقة، أو حزمة كلمات تُضاف تلقائيًا إلى «برا السالفة» و«بدون كلام».','Make a question pack to play as a quiz, or a word pack that is added automatically to Outsider and Silent Charades.','Pakêta pirsan çêke da wekî pêşbaziyê bilîzî, an pakêta peyvan ku bixweber li Derveyî Mijarê û Bê Peyv tê zêdekirin.','پاکێتی پرسیار دروست بکە بۆ یاریکردن وەک پێشبڕکێ، یان پاکێتی وشە کە خۆکارانە دەخرێتە دەرەوەی بابەت و بێ وشە.'),
 newQ:S('حزمة أسئلة جديدة','New question pack','Pakêta pirsan a nû','پاکێتی پرسیاری نوێ'),
 newW:S('حزمة كلمات جديدة','New word pack','Pakêta peyvan a nû','پاکێتی وشەی نوێ'),
 pName:S('اسم الحزمة','Pack name','Navê pakêtê','ناوی پاکێت'),
 fmtQ:S('سطر لكل سؤال: السؤال | الجواب الصحيح | خطأ 1 | خطأ 2','One line per question: question | correct | wrong 1 | wrong 2','Rêzek ji bo her pirsê: pirs | rast | şaş 1 | şaş 2','هێڵێک بۆ هەر پرسیارێک: پرسیار | ڕاست | هەڵە ١ | هەڵە ٢'),
 fmtW:S('كلمة واحدة في كل سطر (4 كلمات على الأقل)','One word per line (at least 4)','Peyvek di her rêzê de (herî kêm 4)','یەک وشە لە هەر هێڵێک (کەمتر نەبێت لە ٤)'),
 save:S('حفظ','Save','Tomar bike','پاشەکەوت'),
 del:S('حذف','Delete','Jê bibe','سڕینەوە'),
 play:S('العب','Play','Bilîze','یاری بکە'),
 exp:S('تصدير','Export','Derxe','هەناردە'),
 imp:S('استيراد','Import','Têxe','هێنان'),
 words:S('كلمات','words','peyv','وشە'),
 qs:S('أسئلة','questions','pirs','پرسیار'),
 autoW:S('تُستخدم تلقائيًا في «برا السالفة» و«بدون كلام»','Used automatically in Outsider and Silent Charades','Bixweber di Derveyî Mijarê û Bê Peyv de tê bikaranîn','خۆکارانە لە دەرەوەی بابەت و بێ وشە بەکاردێت'),
 noPacks:S('لا توجد حزم بعد','No packs yet','Hê pakêt tune ne','هێشتا پاکێت نییە'),
 needName:S('اكتب اسمًا للحزمة','Give the pack a name','Navekî bide pakêtê','ناوێک بنووسە بۆ پاکێت'),
 needItems:S('لا توجد عناصر صالحة','No valid items','Tu tişt derbasdar nînin','هیچ بڕگەیەکی دروست نییە'),
 badLines:S('أسطر غير صالحة:','Invalid lines:','Rêzên nederbasdar:','هێڵی نادروست:'),
 saved:S('تم الحفظ','Saved','Hat tomarkirin','پاشەکەوت کرا'),
 imported:S('تم استيراد','Imported','Hat têxistin','هێنرا'),
 importFail:S('ملف غير صالح','Invalid file','Pelê nederbasdar e','فایلی نادروست'),
 confDel:S('حذف هذه الحزمة؟','Delete this pack?','Ev pakêt jê bibe?','ئەم پاکێتە بسڕدرێتەوە؟')
};

/* ---------- extra built-in questions (verified, general Kurdistan knowledge) ---------- */
const Xq=(q,ol,a=0)=>({t:'x',a,q,ol});
QZ.push(
 Xq(S('في أي تاريخ يُحتفل بعيد نوروز؟','On which date is Newroz celebrated?','Newroz di kîjan dîrokê de tê pîrozkirin?','نەورۆز لە چ ڕێکەوتێکدا ئاهەنگی بۆ دەگێڕدرێت؟'),
  [S('21 آذار/مارس','21 March','21ê Adarê','21ی ئازار'),S('1 كانون الثاني/يناير','1 January','1ê Çileyê','1ی کانوونی دووەم'),S('21 حزيران/يونيو','21 June','21ê Hezîranê','21ی حوزەیران')]),
 Xq(S('كم شعاعًا للشمس في علم كردستان؟','How many rays does the sun on the Kurdistan flag have?','Roja li ser alaya Kurdistanê çend tîrêj hene?','خۆر لەسەر ئاڵای کوردستان چەند تیشکی هەیە؟'),
  [S('21','21','21','21'),S('17','17','17','17'),S('24','24','24','24')]),
 Xq(S('من كتب الملحمة الشعرية «مم وزين»؟','Who wrote the epic poem “Mem û Zîn”?','Destana “Mem û Zîn” kê nivîsandiye?','داستانی «مەم و زین» کێ نووسیویەتی؟'),
  [S('أحمدي خاني','Ahmad Khani','Ehmedê Xanî','ئەحمەدی خانی'),S('جكرخوين','Cegerxwîn','Cegerxwîn','جگەرخوین'),S('نالي','Nali','Nalî','نالی')]),
 Xq(S('في أي محافظة يقع سدّ دوكان؟','In which governorate is the Dukan Dam?','Bendava Dûkanê di kîjan parêzgehê de ye?','بەنداوی دووکان لە کام پارێزگایە؟'),
  [S('السليمانية','Sulaymaniyah','Silêmanî','سلێمانی'),S('دهوك','Duhok','Dihok','دهۆک'),S('أربيل','Erbil','Hewlêr','هەولێر')]),
 {t:'c',a:'hewler',q:S('أي مدينة فيها قلعة تُعد من أقدم المواقع المأهولة باستمرار في العالم؟','Which city has a citadel counted among the oldest continuously inhabited places in the world?','Kîjan bajar xwedî keleheke e ku di nav cihên herî kevn de ye ku bênavber lê jiyane?','کام شار قەڵایەکی هەیە کە لە کۆنترین شوێنە نیشتەجێبووەکانی جیهانە بەبەردەوامی؟')},
 {t:'c',a:'zaxo',q:S('أي مدينة تشتهر بجسر دلال التاريخي؟','Which city is known for the historic Delal Bridge?','Kîjan bajar bi Pira Dêlal a dîrokî tê nasîn?','کام شار بە پردی دەلالی مێژوویی ناسراوە؟')},
 {t:'c',a:'mahabad',q:S('أي مدينة كانت مركز جمهورية كردستان عام 1946؟','Which city was the centre of the Republic of Kurdistan in 1946?','Kîjan bajar navenda Komara Kurdistanê ya sala 1946an bû?','کام شار ناوەندی کۆماری کوردستان بوو لە ساڵی 1946؟')},
 {t:'c',a:'sine',q:S('ما مركز محافظة كردستان في إيران؟','What is the capital of Kurdistan Province in Iran?','Navenda parêzgeha Kurdistanê li Îranê kîjan bajar e?','ناوەندی پارێزگای کوردستان لە ئێران کام شارە؟')},
 Xq(S('بأي أبجدية يُكتب الكردي السوراني عادةً؟','Which script is Sorani Kurdish usually written in?','Kurdiya Soranî bi gelemperî bi kîjan alfabeyê tê nivîsandin?','کوردیی سۆرانی بە شێوەی باو بە کام ئەلفوبێ دەنووسرێت؟'),
  [S('العربية المعدّلة','Modified Arabic script','Alfabeya erebî ya guhertî','ئەلفوبێی عەرەبیی گۆڕاو'),S('اللاتينية','Latin','Latînî','لاتینی'),S('السيريلية','Cyrillic','Kirîlî','سیریلی')])
);
/* ---------- date helpers + daily/weekly state ---------- */
const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const weekKey=()=>{const d=new Date();d.setDate(d.getDate()-((d.getDay()+6)%7));return ymd(d)};
function xdRoll(){
 const td=ymd(new Date());
 if(!XD.daily||XD.daily.d!==td)XD.daily={d:td,plays:0,wins:0,quiz:null,claimed:{}};
 const wk=weekKey();
 if(!XD.weekly||XD.weekly.w!==wk)XD.weekly={w:wk,plays:0,dq:0,claimed:{}}}
function xdPlay(winners){xdRoll();XD.daily.plays++;XD.weekly.plays++;if(winners&&winners.length)XD.daily.wins++}
const CH=[
 {s:'daily',id:'d1',k:'c_play2',rw:2,done:()=>XD.daily.plays>=2,prog:()=>Math.min(2,XD.daily.plays)+'/2'},
 {s:'daily',id:'d2',k:'c_win1',rw:2,done:()=>XD.daily.wins>=1,prog:()=>Math.min(1,XD.daily.wins)+'/1'},
 {s:'daily',id:'d3',k:'c_quiz',rw:3,done:()=>XD.daily.quiz!==null&&XD.daily.quiz>=3,prog:()=>XD.daily.quiz===null?'—':XD.daily.quiz+'/5'},
 {s:'weekly',id:'w1',k:'w_play10',rw:5,done:()=>XD.weekly.plays>=10,prog:()=>Math.min(10,XD.weekly.plays)+'/10'},
 {s:'weekly',id:'w2',k:'w_dq3',rw:5,done:()=>XD.weekly.dq>=3,prog:()=>Math.min(3,XD.weekly.dq)+'/3'}];
const claimable=()=>CH.filter(c=>c.done()&&!XD[c.s].claimed[c.id]).length;
function xClaim(id){const c=CH.find(k=>k.id===id);if(!c||!c.done()||XD[c.s].claimed[c.id])return;
 XD[c.s].claimed[c.id]=1;addPts(0,c.rw);sfx('ok');toast('🎁 +'+c.rw+' ⭐');save();partial()}
function XDload(d){
 const num=v=>Number.isFinite(v)&&v>=0?v:0,cl=o=>o&&typeof o==='object'?Object.fromEntries(Object.keys(o).filter(k=>/^[dw]\d$/.test(k)).map(k=>[k,1])):{};
 const D=d.daily,W=d.weekly;
 XD.daily=D&&typeof D.d==='string'?{d:D.d,plays:num(D.plays),wins:num(D.wins),quiz:Number.isInteger(D.quiz)?Math.min(5,Math.max(0,D.quiz)):null,claimed:cl(D.claimed)}:null;
 XD.weekly=W&&typeof W.w==='string'?{w:W.w,plays:num(W.plays),dq:num(W.dq),claimed:cl(W.claimed)}:null;
 XD.packs=(Array.isArray(d.packs)?d.packs:[]).map(cleanPack).filter(Boolean).slice(0,50);
 rebuildPacks()}

/* seeded random so the daily quiz is the same for everyone on the same day */
function hash(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function mulberry32(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}

/* ---------- packs (game maker) ---------- */
const newId=()=>'p'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
function cleanPack(p){
 if(!p||typeof p!=='object')return null;
 const type=p.type==='words'?'words':p.type==='quiz'?'quiz':null,name=clean(p.name).slice(0,30);
 if(!type||!name||!Array.isArray(p.items))return null;
 let items;
 if(type==='quiz'){
  items=p.items.slice(0,500).map(it=>{if(!it||typeof it!=='object')return null;
   const q=clean(it.q).slice(0,160),a=clean(it.a).slice(0,80),w=(Array.isArray(it.w)?it.w:[]).map(s=>clean(s).slice(0,80)).filter(Boolean).slice(0,3);
   return q&&a&&w.length?{q,a,w}:null}).filter(Boolean);
  if(!items.length)return null}
 else{items=[...new Set(p.items.slice(0,500).map(s=>clean(s).replace(/\|/g,' ').slice(0,40)).filter(Boolean))];if(items.length<4)return null}
 return{id:/^p[a-z0-9]{3,20}$/.test(p.id)?p.id:newId(),name,type,items}}
function rebuildPacks(){
 for(let i=CATS.length-1;i>=0;i--)if(CATS[i].custom)CATS.splice(i,1);
 XD.packs.filter(p=>p.type==='words').forEach(p=>CATS.push({custom:true,n:S1(p.name),w:p.items.map(S1)}));
 ALLWORDS=CATS.flatMap(c=>c.w)}
const packQs=p=>p.items.map(it=>({t:'x',a:0,q:S1(it.q),ol:[it.a,...it.w].map(S1)}));
const allCustomQs=()=>XD.packs.filter(p=>p.type==='quiz').flatMap(packQs);
function qPool(){const p=st.customPack&&XD.packs.find(k=>k.id===st.customPack&&k.type==='quiz');
 return p?shuffle(packQs(p)).slice(0,10):shuffle(QZ).slice(0,8)}
function xTitle(G){const p=st.customPack&&XD.packs.find(k=>k.id===st.customPack);return p?'🛠️ '+esc(p.name):tr(G.n)}
function parseQuiz(text){const items=[],bad=[];
 text.split('\n').forEach((ln,i)=>{ln=ln.trim();if(!ln)return;
  const p=ln.split('|').map(clean).filter(Boolean);
  if(p.length<3||p.length>5){bad.push(i+1);return}
  items.push({q:p[0],a:p[1],w:p.slice(2)})});return{items,bad}}
const parseWords=text=>({items:text.split(/[\n,،]/).map(s=>clean(s).replace(/\|/g,' ')).filter(Boolean),bad:[]});
const serialize=p=>p.type==='quiz'?p.items.map(i=>[i.q,i.a,...i.w].join(' | ')).join('\n'):p.items.join('\n');
function xSavePack(){
 const e=st.xe,nm=document.querySelector('[data-x="name"]'),tx=document.querySelector('[data-x="text"]');
 if(!nm||!tx)return;
 e.name=nm.value;e.text=tx.value;
 const name=clean(e.name);if(!name){toast(x('needName'));return}
 const r=e.type==='quiz'?parseQuiz(e.text):parseWords(e.text);
 if(r.bad.length){toast(x('badLines')+' '+r.bad.slice(0,8).join(', '));return}
 const p=cleanPack({id:e.id,name,type:e.type,items:r.items});
 if(!p){toast(x('needItems'));return}
 const i=XD.packs.findIndex(k=>k.id===p.id);
 if(i>=0)XD.packs[i]=p;else{if(XD.packs.length>=50)return;XD.packs.push(p)}
 rebuildPacks();save();toast('✅ '+x('saved'));st.screen='packs';render()}
function xExport(){
 const blob=new Blob([JSON.stringify({v:1,packs:XD.packs},null,1)],{type:'application/json'}),a=document.createElement('a');
 a.href=URL.createObjectURL(blob);a.download='kgc-packs.json';document.body.appendChild(a);a.click();
 setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},600)}
function xImportText(txt){
 try{const d=JSON.parse(txt);const list=Array.isArray(d)?d:d&&Array.isArray(d.packs)?d.packs:null;
  if(!list)throw 0;
  const ok=list.map(p=>cleanPack({...p,id:null})).filter(Boolean).slice(0,50);
  if(!ok.length)throw 0;
  XD.packs=[...XD.packs,...ok].slice(0,50);rebuildPacks();save();toast('✅ '+x('imported')+' '+ok.length);render(false)}
 catch(e){toast('⚠️ '+x('importFail'))}}
$('app').addEventListener('change',e=>{
 const f=e.target;if(!f||!f.matches||!f.matches('[data-xfile]')||!f.files||!f.files[0])return;
 const file=f.files[0];if(file.size>2e6){toast('⚠️ '+x('importFail'));return}
 const r=new FileReader();r.onload=()=>xImportText(String(r.result));r.readAsText(file);f.value=''});

/* ---------- tournament ---------- */
const rName=r=>{const d=st.tour.rounds.length-1-r;return d===0?x('rF'):d===1?x('rS'):x('rQ')};
function tQ(){const T_=st.tour;
 if(T_.pi>=T_.pool.length){T_.pool=shuffle([...QZ,...allCustomQs()]);T_.pi=0}
 const q=T_.pool[T_.pi++];return{...q,o:qOpts(q)}}
function tStart(){
 const size=st.tsize||4,pl=shuffle([...Array(size).keys()]),r0=[];
 for(let i=0;i<size;i+=2)r0.push({a:pl[i],b:pl[i+1],w:null,sa:0,sb:0});
 const rounds=[r0];
 for(let c=size/4;c>=1;c/=2)rounds.push(Array.from({length:c},()=>({a:null,b:null,w:null,sa:0,sb:0})));
 st.tour={size,rounds,r:0,m:0,pool:[],pi:0,match:null,champ:null,second:null};
 st.skinBack=null;st.screen='tBracket';render()}
function tPlay(){const T_=st.tour,m=T_.rounds[T_.r][T_.m];
 T_.match={a:m.a,b:m.b,k:0,total:5,who:0,phase:'pass',q:tQ(),pick:[null,null],sa:0,sb:0,coin:false};
 st.screen='tDuel';render()}
function tAns(v){const mt=st.tour.match;if(mt.phase!=='ask')return;
 mt.pick[mt.who]=v;sfx('tick');
 if(mt.who===0){mt.who=1;mt.phase='pass'}
 else{const c=String(mt.q.a);if(mt.pick[0]===c)mt.sa++;if(mt.pick[1]===c)mt.sb++;mt.phase='reveal';
  if(mt.pick[0]===c||mt.pick[1]===c)sfx('ok');else sfx('bad')}
 render(false)}
function tNextQ(){const mt=st.tour.match;mt.k++;
 if(mt.k>=mt.total&&mt.sa!==mt.sb)return tMatchEnd();
 if(mt.k>=mt.total+5){mt.coin=true;if(Math.random()<.5)mt.sa++;else mt.sb++;return tMatchEnd()}
 mt.q=tQ();mt.who=0;mt.phase='pass';mt.pick=[null,null];render()}
function tMatchEnd(){const T_=st.tour,mt=T_.match,m=T_.rounds[T_.r][T_.m];
 m.sa=mt.sa;m.sb=mt.sb;m.w=mt.sa>mt.sb?m.a:m.b;
 if(T_.r+1<T_.rounds.length){const nx=T_.rounds[T_.r+1][Math.floor(T_.m/2)];if(T_.m%2===0)nx.a=m.w;else nx.b=m.w}
 st.screen='tMatchRes';render()}
function tCont(){const T_=st.tour;T_.m++;if(T_.m>=T_.rounds[T_.r].length){T_.r++;T_.m=0}
 if(T_.r>=T_.rounds.length){const f=T_.rounds[T_.rounds.length-1][0];
  T_.champ=f.w;T_.second=f.w===f.a?f.b:f.a;addPts(T_.champ,5);addPts(T_.second,2);
  recordGame('tour',[T_.champ]);st.screen='tEnd';render()}
 else{T_.match=null;st.screen='tBracket';render()}}

function vTSetup(){
 const size=st.tsize||4;
 const rows=[...Array(size).keys()].map(i=>`<div class="prow"><button class="pav" data-act="skins" data-v="${i}" aria-label="${t('chooseSkin')}">${faceP(i,64)}</button><input class="pin" data-i="${i}" value="${esc(st.names[i]||'')}" placeholder="${tr(NAMES[i])}" maxlength="14"><span class="pts">⭐ ${st.pts[i]}</span></div>`).join('');
 return `<section class="card center"><div class="big">🏆</div><h1>${x('tTitle')}</h1><p>${x('tDesc')}</p></section>
 <section class="card center"><h2>${x('tSize')}</h2><div class="stepper"><button class="step ${size===4?'':'off'}" data-act="tSize" data-v="4">4</button><button class="step ${size===8?'':'off'}" data-act="tSize" data-v="8">8</button></div>
 <h2 style="margin-top:12px">${t('roster')}</h2>${rows}<button class="btn" data-act="tStart">${x('tStart')}</button></section>`}
function matchRow(m,cur){
 const pc=(i,s)=>i===null?`<span class="bp">❔</span>`:`<span class="bp${m.w===i?' win':''}">${faceP(i,34)}<span>${esc(pname(i))}</span>${m.w!==null?`<b>${s}</b>`:''}</span>`;
 return `<div class="bm${cur?' cur':''}">${pc(m.a,m.sa)}<span class="bv">VS</span>${pc(m.b,m.sb)}</div>`}
function vTBracket(){const T_=st.tour,m=T_.rounds[T_.r][T_.m];
 const cols=T_.rounds.map((rd,ri)=>`<section class="card"><h2>${rName(ri)}</h2>${rd.map((mm,mi)=>matchRow(mm,ri===T_.r&&mi===T_.m)).join('')}</section>`).join('');
 return `${cols}<section class="card center"><h2>${rName(T_.r)}</h2><div class="faces" style="justify-content:center;margin:8px 0">${faceP(m.a,90)}<span style="font-size:2rem;margin:0 14px">VS</span>${faceP(m.b,90)}</div><p><b>${esc(pname(m.a))}</b> · <b>${esc(pname(m.b))}</b></p><button class="btn green" data-act="tPlay">▶ ${x('tPlay')}</button></section>`}
function vTDuel(){const T_=st.tour,mt=T_.match,q=mt.q,sd=mt.k>=mt.total;
 const head=`<p class="pick4">${rName(T_.r)} · ${sd?x('sudden'):x('qn')+' '+(mt.k+1)+'/'+mt.total}</p>`;
 if(mt.phase==='pass'){const p=mt.who?mt.b:mt.a;
  return `<section class="card center">${head}<p>${t('passTo')}</p><div class="who float">${faceP(p,110)}<b style="font-size:2.2rem">${esc(pname(p))}</b></div><button class="btn green" data-act="tReady">${t('ready')}</button></section>`}
 if(mt.phase==='ask'){const p=mt.who?mt.b:mt.a;
  const opts=q.o.map(o=>`<button class="loc" data-act="tAns" data-v="${o}" style="font-size:1.15rem;padding:12px">${qLabel(q,o)}</button>`).join('');
  return `<section class="card center">${head}<div class="starter">${faceP(p,64)}<b>${esc(pname(p))}</b></div><h2>${tr(q.q)}</h2><div class="opts3">${opts}</div></section>`}
 const c=String(q.a),line=(i,k)=>{const ok=mt.pick[k]===c;return `<div class="lrow"><span class="la">${faceP(i,34)}</span><span class="ln">${esc(pname(i))}</span><b>${ok?'✅':'❌'} ${qLabel(q,mt.pick[k])}</b></div>`};
 const done=mt.k+1>=mt.total&&mt.sa!==mt.sb;
 return `<section class="card center">${head}<h2>${tr(q.q)}</h2><p class="gain"><b>${x('corr')}: ${qLabel(q,c)}</b></p><div style="text-align:start">${line(mt.a,0)}${line(mt.b,1)}</div>
 <div class="score"><div class="A">${esc(pname(mt.a))}<b>${mt.sa}</b></div><div class="B">${esc(pname(mt.b))}<b>${mt.sb}</b></div></div>
 <button class="btn" data-act="tNextQ">${done?t('score'):t('next')}</button></section>`}
function vTMatchRes(){const T_=st.tour,mt=T_.match,w=mt.sa>mt.sb?mt.a:mt.b,last=T_.r===T_.rounds.length-1;
 return `<section class="card center"><div class="big">🏅</div><div class="who">${faceP(w,120)}<b style="font-size:2.2rem">${esc(pname(w))}</b></div><h2>${last?x('champ'):x('adv')}</h2>
 <div class="score"><div class="A">${esc(pname(mt.a))}<b>${mt.sa}</b></div><div class="B">${esc(pname(mt.b))}<b>${mt.sb}</b></div></div>${mt.coin?`<p>${x('coin')}</p>`:''}
 <button class="btn" data-act="tCont">${last?t('score'):x('nextM')}</button></section>`}
function vTEnd(){const T_=st.tour;
 return `<section class="card center"><div class="big">🏆</div><h1>${x('champ')}</h1><div class="who float">${faceP(T_.champ,130)}<b style="font-size:2.4rem">${esc(pname(T_.champ))}</b></div><p class="gain">+5 ⭐</p>
 <h2>🥈 ${x('second')}</h2><div class="who">${faceP(T_.second,72)}<b>${esc(pname(T_.second))}</b></div><p class="gain">+2 ⭐</p>
 <button class="btn" data-act="tBack">${x('tour')}</button><button class="btn alt" data-act="hub">${t('toHub')}</button></section>`}

/* ---------- challenges + daily quiz ---------- */
function dqStart(){xdRoll();if(XD.daily.quiz!==null)return;
 const rng=mulberry32(hash(XD.daily.d)),a=QZ.filter(q=>!q.custom);
 for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]]}
 st.dq={qs:a.slice(0,5).map(q=>({...q,o:qOpts(q)})),k:0,score:0,ans:null};st.screen='dq';render()}
function dqPick(v){const d=st.dq;if(d.ans!==null)return;d.ans=v;
 if(v===String(d.qs[d.k].a)){d.score++;sfx('ok')}else sfx('bad');render(false)}
function dqNext(){const d=st.dq;
 if(d.k>=d.qs.length-1){xdRoll();if(XD.daily.quiz===null){XD.daily.quiz=d.score;XD.weekly.dq++}st.screen='dqEnd';render()}
 else{d.k++;d.ans=null;render()}}
function vDaily(){xdRoll();
 const row=c=>{const dn=c.done(),cl=XD[c.s].claimed[c.id];
  return `<div class="setrow"><span>${x(c.k)} <small>(${c.prog()})</small></span>${cl?'<b>✓</b>':dn?`<button class="mini on" data-act="xClaim" data-v="${c.id}">${x('claim')} +${c.rw} ⭐</button>`:`<b>+${c.rw} ⭐</b>`}</div>`};
 const q=XD.daily.quiz===null?`<button class="btn" data-act="dqStart">▶ ${x('dq')}</button>`:`<p class="gain">✅ ${x('dqDone')} · ${XD.daily.quiz}/5</p>`;
 return `<section class="card center"><div class="big">📅</div><h1>${x('dTitle')}</h1><div class="starter">${x('rewardTo')}: ${faceP(0,40)}<b>${esc(pname(0))}</b></div>${q}${CH.filter(c=>c.s==='daily').map(row).join('')}</section>
 <section class="card center"><h2>🗓️ ${x('wTitle')}</h2>${CH.filter(c=>c.s==='weekly').map(row).join('')}</section>`}
function vDQ(){const d=st.dq,q=d.qs[d.k],done=d.ans!==null,ok=done&&d.ans===String(q.a);
 const opts=q.o.map(o=>{let c='loc';if(done){if(o===String(q.a))c+=' good';else if(o===d.ans)c+=' bad'}return `<button class="${c}" data-act="dqPick" data-v="${o}" ${done?'disabled':''} style="font-size:1.15rem;padding:12px">${qLabel(q,o)}</button>`}).join('');
 return `<section class="card center ${done&&!ok?'shake':''}"><p class="pick4">📅 ${x('dq')} · ${d.k+1}/${d.qs.length}</p><h2>${tr(q.q)}</h2><div class="opts3">${opts}</div>${done?`<h2 style="color:${ok?'#6dffa8':'#ff8a8a'}">${ok?t('qRight'):t('qWrong')}</h2><button class="btn" data-act="dqNext">${d.k>=d.qs.length-1?t('score'):t('next')}</button>`:''}</section>`}
function vDQEnd(){const d=st.dq;
 return `<section class="card center"><div class="big">${d.score>=3?'🏆':'📅'}</div><h1>${d.score} / ${d.qs.length}</h1><button class="btn" data-act="xDaily">${x('daily')}</button><button class="btn alt" data-act="hub">${t('toHub')}</button></section>`}

/* ---------- maker screens ---------- */
function vPacks(){
 const list=XD.packs.length?XD.packs.map(p=>`<div class="setrow"><span>${p.type==='quiz'?'❓':'🔤'} <b>${esc(p.name)}</b> <small>(${p.items.length} ${p.type==='quiz'?x('qs'):x('words')})</small></span><span>${p.type==='quiz'?`<button class="mini on" data-act="xPlayPack" data-v="${p.id}">▶</button> `:''}<button class="mini" data-act="xEditPack" data-v="${p.id}">✏️</button> <button class="mini" data-act="xDelPack" data-v="${p.id}">🗑️</button></span></div>`).join(''):`<p class="pick4">${x('noPacks')}</p>`;
 return `<section class="card center"><div class="big">🛠️</div><h1>${x('mTitle')}</h1><p>${x('mDesc')}</p>
 <button class="btn" data-act="xNewPack" data-v="quiz">➕ ${x('newQ')}</button><button class="btn alt" data-act="xNewPack" data-v="words">➕ ${x('newW')}</button></section>
 <section class="card">${list}<div class="center" style="margin-top:10px"><button class="btn alt" data-act="xExport" ${XD.packs.length?'':'disabled'}>⬇ ${x('exp')}</button><label class="btn alt" style="display:inline-block">⬆ ${x('imp')}<input type="file" accept=".json,application/json" data-xfile hidden></label></div></section>`}
function vPackEdit(){const e=st.xe;
 return `<section class="card"><h2>${e.type==='quiz'?'❓':'🔤'} ${x('pName')}</h2><input class="pin" data-x="name" value="${esc(e.name)}" maxlength="30">
 <p class="pick4">${e.type==='quiz'?x('fmtQ'):x('fmtW')}</p>${e.type==='words'?`<p class="pick4">${x('autoW')}</p>`:''}
 <textarea class="xta" data-x="text" rows="12" dir="auto" spellcheck="false">${esc(e.text)}</textarea>
 <div class="center"><button class="btn" data-act="xSavePack">💾 ${x('save')}</button><button class="btn alt" data-act="xPacks">${x('back')}</button></div></section>`}

const XV={tSetup:vTSetup,tBracket:vTBracket,tDuel:vTDuel,tMatchRes:vTMatchRes,tEnd:vTEnd,daily:vDaily,dq:vDQ,dqEnd:vDQEnd,packs:vPacks,packEdit:vPackEdit};

function xHubRow(){xdRoll();const n=claimable();
 return `<div class="xrow"><button class="xbtn" data-act="xTour"><span class="xi">🏆</span><span>${x('tour')}</span></button><button class="xbtn" data-act="xDaily"><span class="xi">📅</span><span>${x('daily')}</span>${n?`<i class="xbadge">${n}</i>`:''}</button><button class="xbtn" data-act="xPacks"><span class="xi">🛠️</span><span>${x('maker')}</span></button><button class="xbtn" data-act="online"><span class="xi">🌐</span><span>${t('online')}</span></button></div>`}

function xClick(a,sv,v,g){
 switch(a){
 case 'xTour':st.game=null;st.customPack=null;st.skinBack='tSetup';st.tsize=st.tsize||4;st.screen='tSetup';render();break;
 case 'tBack':st.skinBack='tSetup';st.screen='tSetup';render();break;
 case 'tSize':st.tsize=+sv===8?8:4;partial();break;
 case 'tStart':tStart();break;
 case 'tPlay':tPlay();break;
 case 'tReady':st.tour.match.phase='ask';render(false);break;
 case 'tAns':tAns(sv);break;
 case 'tNextQ':tNextQ();break;
 case 'tCont':tCont();break;
 case 'xDaily':st.game=null;xdRoll();st.screen='daily';render();break;
 case 'xClaim':xClaim(sv);break;
 case 'dqStart':dqStart();break;
 case 'dqPick':dqPick(sv);break;
 case 'dqNext':dqNext();break;
 case 'xPacks':st.game=null;st.screen='packs';render();break;
 case 'xNewPack':st.xe={id:null,name:'',type:sv==='words'?'words':'quiz',text:''};st.screen='packEdit';render();break;
 case 'xEditPack':{const p=XD.packs.find(k=>k.id===sv);if(p){st.xe={id:p.id,name:p.name,type:p.type,text:serialize(p)};st.screen='packEdit';render()}}break;
 case 'xSavePack':xSavePack();break;
 case 'xDelPack':if(confirm(x('confDel'))){XD.packs=XD.packs.filter(k=>k.id!==sv);rebuildPacks();save();partial()}break;
 case 'xPlayPack':{const p=XD.packs.find(k=>k.id===sv);if(p&&p.type==='quiz'){st.customPack=p.id;st.game='spi';st.n=Math.max(st.n,GAMES.find(g=>g.id==='spi').min);st.screen='setup';render()}}break;
 case 'xExport':xExport();break;
  default:clubClick(a,sv,v,g)
 }}
