/* ===== Klûba Lîstikan · club: Spy categories, per-player voting, profile, online friends ranking ===== */

/* ---------- texts ---------- */
Object.assign(T,{
 change:S('تغيير','Change','Biguhere','گۆڕین'),
 spyCatTitle:S('اختر فئة اللعبة','Choose a category','Kategoriyekê hilbijêre','پۆلێک هەڵبژێرە'),
 spyCatSub:S('اختر واحدة من القوائم التسع قبل بدء اللعبة','Pick one of the nine lists before the game starts','Beriya destpêkirinê yek ji nehan lîsteyan hilbijêre','پێش دەستپێکردن یەکێک لە نۆ لیستەکە هەڵبژێرە'),
 wordsList:S('الكلمات المحتملة (اضغط لشطب كلمة)','Possible words (tap to cross out)','Peyvên gengaz (bitikîne da ku xet bikişînî)','وشە ئەگەرەکان (دەست لێبدە بۆ هێڵ کێشان)'),
 voteEach:S('كل لاعب يصوّت بنفسه','Every player votes for himself','Her lîstikvan bi xwe deng dide','هەر یاریزانێک خۆی دەنگ دەدات'),
 voteOne:S('اختر شخصاً واحداً','Pick one person','Yek kes hilbijêre','یەک کەس هەڵبژێرە'),
 tieVote:S('تعادلت الأصوات فلم يُكشف أحد.','The votes were tied, so nobody was caught.','Deng wekhev bûn û kes nehat girtin.','دەنگەکان یەکسان بوون و کەس نەگیرا.'),
 votesTitle:S('الأصوات','Votes','Deng','دەنگەکان'),
 profile:S('حسابي','My profile','Profîla min','پرۆفایلەکەم'),
 profSaved:S('يُحفظ اسمك وصورتك ونقاطك تلقائياً على هذا الجهاز.','Your name, photo and points are saved on this device automatically.','Nav, wêne û xalên te bixweber li ser vê amûrê tên tomarkirin.','ناو و وێنە و خاڵەکانت خۆکارانە لەسەر ئەم ئامێرە پاشەکەوت دەکرێن.'),
 yourName:S('اسمك','Your name','Navê te','ناوەکەت'),
 photo:S('اختر صورتك','Choose your photo','Wêneyê xwe hilbijêre','وێنەکەت هەڵبژێرە'),
 useChar:S('شخصية','Character','Karakter','کارەکتەر'),
 usePhoto:S('صورتي','My photo','Wêneyê min','وێنەکەم'),
 chooseChar:S('اختر شخصيتك','Choose your character','Karakterê xwe hilbijêre','کارەکتەرەکەت هەڵبژێرە'),
 birthday:S('تاريخ ميلادك','Your birthday','Rojbûna te','ڕۆژی لەدایکبوونت'),
 happyBd:S('عيد ميلاد سعيد','Happy birthday','Rojbûna te pîroz be','ڕۆژی لەدایکبوونت پیرۆز بێت'),
 age:S('العمر','Age','Temen','تەمەن'),
 photoFail:S('تعذّر تحميل الصورة','Could not load the photo','Wêne nehat barkirin','نەتوانرا وێنەکە باربکرێت'),
 online:S('أونلاين','Online','Serhêl','ئۆنلاین'),
 onTitle:S('العب مع أصدقائك','Play with friends','Bi hevalan re bilîze','لەگەڵ هاوڕێکانت یاری بکە'),
 onDesc:S('أرسل رمزك لصديقك. عندما تضيفان بعضكما تظهر نقاطكما في تصنيف واحد، وكل ما تربحه يظهر عند صديقك تلقائياً.','Send your code to a friend. Once you add each other, your points appear in one ranking, and whatever you win shows up on your friend\'s side automatically.','Koda xwe ji hevalê xwe re bişîne. Gava hûn hev zêde bikin, xalên we di yek tabloyê de xuya dibin û ya tu bi dest bixî bixweber li ba hevalê te xuya dibe.','کۆدەکەت بنێرە بۆ هاوڕێکەت. کاتێک یەکتر زیاد دەکەن، خاڵەکانتان لە یەک ڕیزبەندیدا دەردەکەون و هەرچی ببەیتەوە خۆکارانە لای هاوڕێکەت دەردەکەوێت.'),
 onNotReady:S('وضع الأونلاين غير مفعّل بعد: يلزم ربط قاعدة بيانات مجانية في ملف config.js (الخطوات في ملف README-online).','Online mode is not switched on yet: a free database must be linked in config.js (steps are in README-online).','Moda serhêl hê nehatiye çalakkirin: divê databeyseke belaş di config.js de were girêdan (gav di README-online de ne).','دۆخی ئۆنلاین هێشتا چالاک نەکراوە: پێویستە داتابەیسێکی بێبەرامبەر لە config.js ببەسترێتەوە (هەنگاوەکان لە README-online ن).'),
 yourCode:S('رمزك','Your code','Koda te','کۆدەکەت'),
 share:S('أرسل الرمز','Send code','Kodê bişîne','کۆد بنێرە'),
 copy:S('نسخ','Copy','Kopî bike','لەبەرگرتنەوە'),
 copied:S('تم النسخ','Copied','Hat kopîkirin','لەبەرگیرایەوە'),
 shareTxt:S('انضم إليّ في نادي الألعاب! أضف رمزي:','Join me in the game club! Add my code:','Were bi min re li klûba lîstikan! Koda min zêde bike:','وەرە لەگەڵم لە کڵوبی یاری! کۆدەکەم زیاد بکە:'),
 addFriend:S('أضف صديقاً برمزه','Add a friend by code','Hevalekî bi kodê zêde bike','هاوڕێیەک بە کۆد زیاد بکە'),
 friendCode:S('رمز صديقك','Friend\'s code','Koda hevalê te','کۆدی هاوڕێکەت'),
 add:S('إضافة','Add','Zêde bike','زیاد بکە'),
 rank:S('تصنيف النقاط','Points ranking','Tabloya xalan','ڕیزبەندی خاڵ'),
 refresh:S('تحديث','Refresh','Nû bike','نوێکردنەوە'),
 you:S('أنت','You','Tu','تۆ'),
 badCode:S('الرمز غير صحيح (6 أحرف أو أرقام)','Invalid code (6 letters or digits)','Kod şaş e (6 tîp an jimar)','کۆدەکە هەڵەیە (٦ پیت یان ژمارە)'),
 ownCode:S('هذا رمزك أنت','That is your own code','Ev koda te ye','ئەمە کۆدی خۆتە'),
 alreadyF:S('هو صديقك بالفعل','Already your friend','Ew jixwe heval e','پێشتر هاوڕێتە'),
 noSuchCode:S('لا يوجد لاعب بهذا الرمز','No player has this code','Lîstikvanek bi vê kodê tune','هیچ یاریزانێک بەم کۆدە نییە'),
 netErr:S('تعذّر الاتصال بالإنترنت','Could not connect','Girêdan pêk nehat','نەتوانرا پەیوەندی بکرێت'),
 friendAdded:S('أصبحتما صديقين','You are now friends','Hûn bûn heval','بوونە هاوڕێ'),
 noFriends:S('لا أصدقاء بعد. شارك رمزك أو أضف رمز صديقك.','No friends yet. Share your code or add a friend\'s code.','Hê heval tune ne. Koda xwe parve bike an koda hevalekî zêde bike.','هێشتا هاوڕێ نییە. کۆدەکەت هاوبەش بکە یان کۆدی هاوڕێیەک زیاد بکە.'),
 offlineNote:S('غير متصل — آخر نتائج محفوظة','Offline — showing last saved ranking','Negirêdayî — tabloya dawî tê nîşandan','پەیوەندی نییە — دوایین ڕیزبەندی پیشان دەدرێت')
});

/* ---------- Spy categories (the nine lists) ---------- */
const CATICON={'Mobile & world games':'🎮','World cities':'🌍','Anime':'🎌','Cartoon movies':'🎬','History':'📜','Artists':'🎤','Actors':'🎭','Football: past & future':'⚽','Kurdish cities':'🏔️'};
const spyLists=()=>CATS.filter(c=>c.lists);
const spyList=()=>spyLists()[st.spyCat]||null;

function vSpyCat(){
 const L=spyLists();
 return `<section class="card center" style="background:linear-gradient(165deg,#1b4fd1,#0a1030 140%)"><div class="big">🕵️</div><h1>${t('spyCatTitle')}</h1><p>${t('spyCatSub')}</p></section>
 <div class="catgrid">${L.map((c,k)=>`<button class="catbtn ${st.spyCat===k?'sel':''}" data-act="pickCat" data-v="${k}"><span class="ci">${CATICON[c.n.en]||'📂'}</span><b>${tr(c.n)}</b><small>${c.w.length} ${x('words')}</small></button>`).join('')}</div>`}

/* ---------- per-player voting ---------- */
function startVote(){const g=st.g;g.vi=0;g.votes=Array(st.n).fill(null);g.vsel=null;g.vcnt=null;st.screen='vtPass';render()}
function vVtPass(){const g=st.g,i=g.vi,spy=g.kind==='spy';
 return `<section class="card center">${g.timeup&&i===0?`<h2 style="color:var(--red)">${t('timeUp')}</h2>`:''}<h2>🗳️ ${spy?t('voteSpy'):t('voteOut')}</h2>
  <p class="pick4">${t('voteEach')} · ${i+1} / ${st.n}</p><p>${t('passTo')}</p>
  <div class="who float">${faceP(i,110)}<b style="font-size:2.2rem">${esc(pname(i))}</b></div>
  <button class="btn green" data-act="vtReady">${t('ready')}</button></section>`}
function vVtPick(){const g=st.g,i=g.vi,spy=g.kind==='spy',others=ids().filter(k=>k!==i);
 return `<section class="card center"><div class="starter">${faceP(i,64)}<b>${esc(pname(i))}</b></div><h2>${spy?t('voteSpy'):t('voteOut')}</h2><p>${t('voteOne')}</p>
  ${grid(others,g.vsel===null?[]:[g.vsel],'vtSel')}
  <button class="btn" data-act="vtConfirm" ${g.vsel===null?'disabled':''}>${t('confirm')}</button></section>`}
function tallyVotes(){const g=st.g,cnt=Array(st.n).fill(0);
 g.votes.forEach(v=>{if(v!==null&&v>=0&&v<st.n)cnt[v]++});g.vcnt=cnt;
 const N=g.spies.length,order=ids().sort((a,b)=>cnt[b]-cnt[a]||a-b),top=order.slice(0,N);
 const tie=cnt[order[N-1]]===cnt[order[N]],ok=!tie&&top.every(i=>g.spies.includes(i));
 const why=tie?'tieVote':ok?'caught':'wrongVote';
 suspense(()=>{if(g.kind==='out'&&ok){g.gsel=null;g.last=true;st.screen='guess';render()}else finishSO(ok,why)})}
function votesBlock(g){
 const order=ids().sort((a,b)=>g.vcnt[b]-g.vcnt[a]||a-b);
 return `<h2>🗳️ ${t('votesTitle')}</h2><div style="text-align:start">${order.map(i=>{
  const by=ids().filter(k=>g.votes[k]===i).map(pname).join('، ');
  return `<div class="lrow"><span class="la">${faceP(i,34)}</span><span class="ln">${esc(pname(i))}${g.spies.includes(i)?' 🕵️':''}${by?`<small class="vby">${esc(by)}</small>`:''}</span><b>${g.vcnt[i]} 🗳️</b></div>`}).join('')}</div>`}

/* ---------- profile (account) ---------- */
function meLoad(d){const me=st.me;
 me.photo=typeof d.photo==='string'&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(d.photo)&&d.photo.length<200000?d.photo:null;
 me.usePhoto=!!(me.photo&&d.usePhoto);
 me.bd=/^\d{4}-\d{2}-\d{2}$/.test(d.bd||'')?d.bd:'';
 me.code=/^[A-Z0-9]{6}$/.test(d.code||'')?d.code:'';
 me.registered=!!(me.code&&d.registered);
 me.friends=(Array.isArray(d.friends)?d.friends:[]).filter(c=>/^[A-Z0-9]{6}$/.test(c)).slice(0,50);
 me.cache=(Array.isArray(d.cache)?d.cache:[]).map(cleanRow).filter(Boolean).slice(0,50);
 me.cacheAt=Number.isFinite(d.cacheAt)?d.cacheAt:0}
function calcAge(bd){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(bd);if(!m)return null;
 const n=new Date(),y=+m[1],mo=+m[2],da=+m[3];let a=n.getFullYear()-y;
 if(n.getMonth()+1<mo||(n.getMonth()+1===mo&&n.getDate()<da))a--;return a>=0&&a<130?a:null}
const bdToday=()=>{const m=/^\d{4}-(\d{2})-(\d{2})$/.exec(st.me.bd);if(!m)return false;const n=new Date();return n.getMonth()+1===+m[1]&&n.getDate()===+m[2]};
function vProfile(){const me=st.me,tot=st.pts[0],lv=lvl(tot),age=calcAge(me.bd);
 const played=Object.values(stats.games).reduce((a,g)=>a+g.played,0),wins=stats.wins[0]||0;
 const today=ymd(new Date());
 return `<section class="card center"><div class="who float">${faceP(0,128)}</div><h1>${esc(pname(0))} 👑</h1>
  <p class="pick4">Lv. ${lv} · ⭐ ${tot} · 🎮 ${played} · 🏆 ${wins}${age!==null?` · 🎂 ${age}`:''}</p>
  ${me.photo?`<div class="seg"><button class="mini ${me.usePhoto?'':'on'}" data-act="pfUse" data-v="0">${t('useChar')}</button><button class="mini ${me.usePhoto?'on':''}" data-act="pfUse" data-v="1">${t('usePhoto')}</button></div>`:''}
 </section>
 <section class="card">
  <h2>${t('yourName')}</h2><div class="prow"><input class="pin" data-i="0" value="${esc(st.names[0]||'')}" placeholder="${esc(tr(NAMES[0]))}" maxlength="14" autocomplete="off"></div>
  <h2 style="margin-top:14px">${t('chooseChar')}</h2><div class="center"><button class="btn" data-act="pfSkin">🎭 ${t('change')}</button></div>
  <h2 style="margin-top:14px">${t('photo')}</h2><div class="center"><label class="btn alt" style="display:inline-block">📷 ${me.photo?t('change'):t('photo')}<input type="file" accept="image/*" data-photofile hidden></label>${me.photo?`<button class="btn alt" data-act="pfPhotoDel" aria-label="delete">🗑️</button>`:''}</div>
  <h2 style="margin-top:14px">${t('birthday')}</h2><div class="prow"><input class="pin" type="date" data-me="bd" value="${esc(me.bd)}" max="${today}" min="1900-01-01" dir="ltr"></div>
  <p class="pick4" style="margin-top:12px">${t('profSaved')}</p>
  <div class="center"><button class="btn green" data-act="hub">${t('done')}</button></div>
 </section>`}
function readPhoto(file){
 if(!file||!/^image\//.test(file.type)||file.size>12e6){toast('⚠️ '+t('photoFail'));return}
 const url=URL.createObjectURL(file),img=new Image();
 img.onload=()=>{try{
   const S_=192,c=document.createElement('canvas');c.width=c.height=S_;const ctx=c.getContext('2d');
   const m=Math.min(img.width,img.height),sx=(img.width-m)/2,sy=(img.height-m)/2;
   ctx.drawImage(img,sx,sy,m,m,0,0,S_,S_);
   st.me.photo=c.toDataURL('image/jpeg',.82);st.me.usePhoto=true;save();render(false)}
  catch(e){toast('⚠️ '+t('photoFail'))}URL.revokeObjectURL(url)};
 img.onerror=()=>{URL.revokeObjectURL(url);toast('⚠️ '+t('photoFail'))};
 img.src=url}
$('app').addEventListener('change',e=>{const f=e.target;if(!f||!f.matches)return;
 if(f.matches('[data-photofile]')&&f.files&&f.files[0]){readPhoto(f.files[0]);f.value=''}
 if(f.matches('[data-me="bd"]')){st.me.bd=/^\d{4}-\d{2}-\d{2}$/.test(f.value)?f.value:'';save();partial()}
 if(f.matches('.pin[data-i="0"]')){save();if(window.olSchedule)olSchedule()}});
$('app').addEventListener('input',e=>{const f=e.target;if(f&&f.matches&&f.matches('[data-code]')){const v=f.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);if(v!==f.value)f.value=v;OL.input=v}});
addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target&&e.target.matches&&e.target.matches('[role="button"][data-act]')){e.preventDefault();e.target.click()}});

/* ---------- online friends ranking (Firebase Realtime Database over REST) ---------- */
const OL={busy:false,err:false,input:'',poll:null,fp:'',t:null};
const dbu=()=>String((window.KGC_CONFIG&&window.KGC_CONFIG.dbUrl)||'').trim().replace(/\/+$/,'');
const olOn=()=>/^https:\/\/[A-Za-z0-9.-]+$/.test(dbu());
async function dbReq(path,opt){const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),9000);
 try{const r=await fetch(dbu()+path+'.json',{cache:'no-store',signal:ac.signal,...opt});if(!r.ok)throw new Error('http '+r.status);return await r.json()}
 finally{clearTimeout(tm)}}
const dbGet=p=>dbReq(p);
const dbPut=(p,v)=>dbReq(p,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(v)});
const ALPHA='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const genCode=()=>{const b=new Uint8Array(6);crypto.getRandomValues(b);return Array.from(b,x=>ALPHA[x%32]).join('')};
const normCode=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
function cleanRow(r){if(!r||typeof r!=='object')return null;const d=r.d||r,c=r.c;
 if(!/^[A-Z0-9]{6}$/.test(c||''))return null;
 const num=v=>Number.isFinite(v)&&v>=0?Math.floor(v):0;
 return{c,d:{n:clean(d.n).slice(0,14)||'?',a:Number.isInteger(d.a)&&d.a>=0&&d.a<SK.length?d.a:0,p:num(d.p),g:num(d.g),w:num(d.w)}}}
function olPayload(){const g=Object.values(stats.games).reduce((a,x)=>a+x.played,0);
 return{n:clean(pname(0)).slice(0,14)||'?',a:st.skin[0],p:st.pts[0],g,w:stats.wins[0]||0,u:Date.now()}}
const olFp=p=>[p.n,p.a,p.p,p.g,p.w].join('|');
async function olPush(force){const me=st.me;if(!olOn()||!me.registered)return;
 const p=olPayload(),fp=olFp(p);if(!force&&fp===OL.fp)return;
 try{await dbPut('/kgc/players/'+me.code,p);OL.fp=fp}catch(e){}}
function olSchedule(){if(!olOn()||!st.me||!st.me.registered)return;
 if(olFp(olPayload())===OL.fp)return;clearTimeout(OL.t);OL.t=setTimeout(()=>olPush(),2500)}
async function olRegister(){const me=st.me;if(me.registered)return;
 let code=me.code||genCode();
 for(let i=0;i<6;i++){const ex=await dbGet('/kgc/players/'+code);if(ex===null)break;code=genCode();if(i===5)throw new Error('no free code')}
 await dbPut('/kgc/players/'+code,olPayload());me.code=code;me.registered=true;OL.fp=olFp(olPayload());save()}
async function olRefresh(){if(!olOn()||OL.busy)return;OL.busy=true;olPaint();const me=st.me;
 try{await olRegister();await olPush(true);
  const fr=(await dbGet('/kgc/friends/'+me.code))||{};
  const codes=[...new Set([...me.friends,...Object.keys(fr)])].filter(c=>/^[A-Z0-9]{6}$/.test(c)&&c!==me.code).slice(0,50);
  me.friends=codes;
  const all=await Promise.all(codes.map(c=>dbGet('/kgc/players/'+c).catch(()=>null)));
  me.cache=codes.map((c,i)=>cleanRow({c,d:all[i]})).filter(Boolean);me.cacheAt=Date.now();OL.err=false;save()}
 catch(e){OL.err=true}
 OL.busy=false;olPaint()}
async function olAdd(){const me=st.me,c=normCode(OL.input);
 if(!me.registered){toast(t('netErr'));return}
 if(c.length!==6){toast('⚠️ '+t('badCode'));return}
 if(c===me.code){toast('⚠️ '+t('ownCode'));return}
 if(me.friends.includes(c)){toast('ℹ️ '+t('alreadyF'));return}
 try{const f=await dbGet('/kgc/players/'+c);if(!f){toast('⚠️ '+t('noSuchCode'));return}
  await dbPut('/kgc/friends/'+me.code+'/'+c,true);await dbPut('/kgc/friends/'+c+'/'+me.code,true);
  me.friends.push(c);OL.input='';save();toast('🤝 '+t('friendAdded'));
  const inp=document.querySelector('[data-code]');if(inp)inp.value='';
  olRefresh()}
 catch(e){toast('⚠️ '+t('netErr'))}}
function olRows(){const me=st.me;
 const mine={c:me.code||'······',me:1,d:{n:pname(0),a:st.skin[0],p:st.pts[0],w:stats.wins[0]||0}};
 return[mine,...(me.cache||[])].sort((a,b)=>b.d.p-a.d.p||(b.me?1:0)-(a.me?1:0))}
function olBoard(){const rows=olRows();
 const list=rows.map((r,k)=>`<div class="lrow ${r.me?'me':''}"><span class="rk r${k}">${k+1}</span><span class="la">${r.me?faceP(0,34):face(r.d.a,34)}</span><span class="ln">${esc(r.d.n)}${r.me?` <small>(${t('you')})</small>`:''}</span><b>Lv.${lvl(r.d.p)} · ⭐ ${r.d.p}</b></div>`).join('');
 return `${list}${rows.length<2?`<p class="pick4">${t('noFriends')}</p>`:''}${OL.err?`<p class="pick4">⚠️ ${t('offlineNote')}</p>`:''}${OL.busy?'<p class="pick4">⏳</p>':''}`}
function vOnline(){
 if(!olOn())return `<section class="card center"><div class="big">🌐</div><h1>${t('onTitle')}</h1><p>${t('onNotReady')}</p></section>`;
 const me=st.me;
 return `<section class="card center"><div class="big">🌐</div><h1>${t('onTitle')}</h1><p>${t('onDesc')}</p></section>
 <section class="card center"><h2>${t('yourCode')}</h2><div class="codebox" id="olCode" dir="ltr">${me.registered?esc(me.code):'······'}</div>
  <button class="btn" data-act="olShare">📤 ${t('share')}</button><button class="btn alt" data-act="olCopy">📋 ${t('copy')}</button></section>
 <section class="card center"><h2>${t('addFriend')}</h2>
  <div class="prow"><input class="pin codein" data-code dir="ltr" maxlength="6" value="${esc(OL.input)}" placeholder="${t('friendCode')}" autocapitalize="characters" autocomplete="off" spellcheck="false"><button class="btn" data-act="olAdd" style="margin:0">${t('add')}</button></div></section>
 <section class="card"><div class="lrowhead"><h2 style="margin:0">👑 ${t('rank')}</h2><button class="mini" data-act="olRefresh">🔄 ${t('refresh')}</button></div><div id="olBoard">${olBoard()}</div></section>`}
function olPaint(){if(st.screen!=='online')return;
 const b=document.getElementById('olBoard'),c=document.getElementById('olCode');
 if(b)b.innerHTML=olBoard();if(c)c.textContent=st.me.registered?st.me.code:'······'}
function olCopy(){const code=st.me.code;if(!st.me.registered)return;
 const done=()=>toast('✅ '+t('copied'));
 if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(code).then(done,()=>{});
 else{const ta=document.createElement('textarea');ta.value=code;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');done()}catch(e){}ta.remove()}}
function olShare(){const me=st.me;if(!me.registered)return;
 const text=t('shareTxt')+' '+me.code;
 if(navigator.share)navigator.share({title:t('app'),text,url:location.href.split('#')[0]}).catch(()=>{});else olCopy()}
function kgcAfterRender(){
 if(st.screen==='online'&&olOn()){if(!OL.poll)OL.poll=setInterval(()=>{if(st.screen==='online'&&!document.hidden)olRefresh()},12000)}
 else if(OL.poll){clearInterval(OL.poll);OL.poll=null}
 if(st.screen==='hub'&&bdToday()&&st.bdSeen!==ymd(new Date())){st.bdSeen=ymd(new Date());toast('🎂 '+t('happyBd')+' '+pname(0)+'!')}}

/* ---------- register views + clicks ---------- */
Object.assign(XV,{spyCat:vSpyCat,vtPass:vVtPass,vtPick:vVtPick,profile:vProfile,online:vOnline});
function clubClick(a,sv,v,g){
 switch(a){
 case 'spyCat':st.screen='spyCat';render();break;
 case 'pickCat':st.spyCat=v;st.screen='setup';render();break;
 case 'vtReady':g.vsel=null;st.screen='vtPick';render();break;
 case 'vtSel':g.vsel=v;partial();break;
 case 'vtConfirm':if(g.vsel===null)break;g.votes[g.vi]=g.vsel;g.vsel=null;g.vi++;
  if(g.vi>=st.n)tallyVotes();else{st.screen='vtPass';render()}break;
 case 'profile':st.skinBack=null;st.screen='profile';render();break;
 case 'pfSkin':st.skinBack='profile';st.slot=0;st.screen='skins';render();break;
 case 'pfUse':st.me.usePhoto=!!(v&&st.me.photo);save();partial();break;
 case 'pfPhotoDel':st.me.photo=null;st.me.usePhoto=false;save();partial();break;
 case 'online':st.skinBack=null;st.game=null;st.screen='online';render();olRefresh();break;
 case 'olRefresh':olRefresh();break;
 case 'olAdd':olAdd();break;
 case 'olShare':olShare();break;
 case 'olCopy':olCopy();break;
 }}
