/* Online mode (friends + points ranking).
   Paste your Firebase Realtime Database URL below (see README-online.md).
   Leave it empty to keep the app 100% offline. */
window.KGC_CONFIG={
  dbUrl:''   // example: 'https://my-game-club-default-rtdb.europe-west1.firebasedatabase.app'
};
