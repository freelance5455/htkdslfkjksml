
const S=(ar,en,kmr,ckb)=>({ar,en,kmr,ckb});
const META={ar:{dir:'rtl',code:'ar'},en:{dir:'ltr',code:'en'},kmr:{dir:'ltr',code:'ku-Latn'},ckb:{dir:'rtl',code:'ckb'}};
const $=id=>document.getElementById(id);
const rnd=n=>Math.floor(Math.random()*n);
const shuffle=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=rnd(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};

/* ================= TEXT ================= */
const T={
app:S('نادي ألعاب جماعية','Group Game Club','Klûba Lîstikên Komî','کڵوبی یاریی کۆمەڵایەتی'),
tag:S('اختر لعبة وابدأ السهرة','Pick a game and start the party','Lîstikekê hilbijêre û şev dest pê bike','یارییەک هەڵبژێرە و شەونشینی دەست پێبکە'),
secret:S('سري للغاية','TOP SECRET','PIR VEŞARTÎ','زۆر نهێنی'),
minP:S('من','from','ji','لە'),
pl:S('لاعبين','players','lîstikvan','یاریزان'),
players:S('عدد اللاعبين','Players','Hejmara lîstikvanan','ژمارەی یاریزانان'),
spies:S('عدد الجواسيس','Spies','Hejmara sîxuran','ژمارەی سیخوڕەکان'),
mins:S('الوقت (دقائق)','Time (minutes)','Dem (xulek)','کات (خولەک)'),
secs:S('وقت الدور (ثوانٍ)','Turn time (seconds)','Demê gerê (çirk)','کاتی نۆرە (چرکە)'),
roster:S('أسماء اللاعبين وشخصياتهم','Player names and avatars','Navê lîstikvan û karakter','ناوی یاریزان و کارەکتەر'),
howto:S('طريقة اللعب','How to play','Çawa dilîzin','چۆن یاری دەکرێت'),
start:S('ابدأ اللعبة','Start the game','Lîstikê dest pê bike','یاریەکە دەست پێبکە'),
toHub:S('القائمة الرئيسية','Main menu','Menuya sereke','لیستی سەرەکی'),
lang:S('اللغة','Language','Ziman','زمان'),
free:S('مجاني','Free','Belaş','بێبەرامبەر'),
owned:S('مفتوح','Unlocked','Vekirî','کراوەتەوە'),
chooseSkin:S('اختر شخصيتك','Choose your avatar','Karakterê xwe hilbijêre','کارەکتەرەکەت هەڵبژێرە'),
pts:S('النقاط','Points','Xal','خاڵ'),
unlockHint:S('اربح الجولات لتجمع نقاطاً وتفتح الشخصيات المميزة.','Win rounds to earn points and unlock special avatars.','Bi serkeftinê xalan bi dest bixe û karakterên taybet veke.','بە بردنەوە خاڵ کۆبکەرەوە و کارەکتەری تایبەت بکەرەوە.'),
done:S('تم','Done','Temam','تەواو'),
passTo:S('مرّر الجهاز إلى','Pass the device to','Amûrê bide','ئامێرەکە بدە بە'),
tap:S('اضغط لإظهار بطاقتك','Tap to reveal your card','Ji bo nîşandana karta xwe bitikîne','بۆ نیشاندانی کارتەکەت دەست لێبدە'),
hide:S('أخفِ البطاقة ومرّر','Hide the card and pass on','Kartê veşêre û derbas bike','کارتەکە بشارەوە و بیدە بەدوایی'),
startPlay:S('ابدأ الجولة','Start the round','Gerê dest pê bike','خولەکە دەست پێبکە'),
starts:S('يبدأ بالسؤال','Asks first','Yê yekem dipirse','یەکەم پرسیار دەکات'),
askRule:S('من أجاب يسأل التالي، ولا يجوز سؤال من سألك للتو.','Whoever answers asks next. You cannot ask the person who just asked you.','Yê bersiv dide, yê din dipirse. Ji yê ku nû ji te pirsî nepirse.','ئەوەی وەڵام دەداتەوە پرسیاری دواتر دەکات. لەو کەسە مەپرسە کە تازە لێی پرسیت.'),
confirm:S('تأكيد','Confirm','Piştrast bike','پشتڕاستکردنەوە'),
pick:S('اختر','Pick','Hilbijêre','هەڵبژێرە'),
timeUp:S('انتهى الوقت! صوّتوا الآن.','Time is up! Vote now.','Dem qediya! Niha deng bidin.','کات تەواو بوو! ئێستا دەنگ بدەن.'),
timeUp2:S('انتهى الوقت!','Time is up!','Dem qediya!','کات تەواو بوو!'),
again:S('جولة جديدة','New round','Gera nû','خولێکی نوێ'),
next:S('التالي','Next','Ya din','دواتر'),
was:S('كان','It was','Ev bû','ئەمە بوو'),
citWin:S('فاز المواطنون!','Citizens win!','Welatî bi ser ketin!','هاوواڵاتییەکان بردیانەوە!'),
/* spy */
locs:S('قائمة الأماكن (اضغط لشطب مكان)','Places (tap to cross out)','Cih (bitikîne da ku xet bikişînî)','شوێنەکان (دەست لێبدە بۆ هێڵ کێشان)'),
voteSpy:S('تصويت: من الجاسوس؟','Vote: who is the spy?','Deng: sîxur kî ye?','دەنگدان: سیخوڕ کێیە؟'),
guessSpy:S('أنا الجاسوس وسأخمّن المكان','I am the spy and I will guess the place','Ez sîxur im û ê cih texmîn bikim','من سیخوڕم و شوێنەکە دەخمێنم'),
guessTitle:S('ما هو المكان؟','What is the place?','Cih çi ye?','شوێنەکە چییە؟'),
youSpy:S('أنت الجاسوس!','You are the SPY!','Tu sîxur î!','تۆ سیخوڕیت!'),
spyHint:S('لا تعرف المكان. تظاهر بأنك تعرفه!','You do not know the place. Pretend you do!','Tu cihê nizanî. Wisa nîşan bide ku tu dizanî!','شوێنەکە نازانیت. وا دەربخە کە دەیزانیت!'),
place:S('المكان','The place','Cih','شوێن'),
spyWin:S('فاز الجاسوس!','The spy wins!','Sîxur bi ser ket!','سیخوڕ بردییەوە!'),
caught:S('كُشف الجاسوس.','The spy was caught.','Sîxur hat girtin.','سیخوڕ گیرا.'),
wrongVote:S('اتهمتم شخصاً بريئاً.','You accused an innocent player.','We lîstikvanekî bêsûc tawanbar kir.','یاریزانێکی بێتاوانتان تۆمەتبار کرد.'),
gRight:S('الجاسوس خمّن المكان بشكل صحيح.','The spy guessed the place correctly.','Sîxur cih rast texmîn kir.','سیخوڕ شوێنەکەی بە ڕاست خەمڵاند.'),
gWrong:S('الجاسوس أخطأ في التخمين.','The spy guessed wrong.','Sîxur şaş texmîn kir.','سیخوڕ هەڵە خەمڵاندی.'),
spyList:S('الجواسيس','The spies','Sîxur','سیخوڕەکان'),
/* outsider */
category:S('الفئة','Category','Kategorî','پۆل'),
theWord:S('الكلمة','The word','Peyv','وشە'),
youOut:S('أنت برا السالفة!','You are the OUTSIDER!','Tu derveyî mijarê yî!','تۆ دەرەوەی بابەتیت!'),
outHint:S('لا تعرف الكلمة. تظاهر بأنك تعرفها!','You do not know the word. Pretend you do!','Tu peyvê nizanî. Wisa nîşan bide ku tu dizanî!','وشەکە نازانیت. وا دەربخە کە دەیزانیت!'),
voteOut:S('تصويت: من برا السالفة؟','Vote: who is the outsider?','Deng: kî derveyî mijarê ye?','دەنگدان: کێ دەرەوەی بابەتە؟'),
guessOut:S('أنا برا السالفة وسأخمّن الكلمة','I am the outsider and I will guess the word','Ez derveyî mijarê me û ê peyvê texmîn bikim','من دەرەوەی بابەتم و وشەکە دەخمێنم'),
guessWord:S('ما هي الكلمة؟','What is the word?','Peyv çi ye?','وشەکە چییە؟'),
lastChance:S('كُشف الغريب! لديه فرصة أخيرة لتخمين الكلمة.','The outsider was caught! One last chance to guess the word.','Yê derveyî mijarê hat girtin! Şansek dawî ji bo texmînkirina peyvê.','دەرەوەی بابەت گیرا! یەک دەرفەتی کۆتایی بۆ خەمڵاندنی وشەکە.'),
outWin:S('فاز الغريب!','The outsider wins!','Yê derveyî mijarê bi ser ket!','دەرەوەی بابەت بردییەوە!'),
oRight:S('الغريب خمّن الكلمة.','The outsider guessed the word.','Derveyî mijarê peyv texmîn kir.','دەرەوەی بابەت وشەکەی خەمڵاند.'),
oWrong:S('الغريب أخطأ في التخمين.','The outsider guessed wrong.','Derveyî mijarê şaş texmîn kir.','دەرەوەی بابەت هەڵە خەمڵاندی.'),
outList:S('الغريب','The outsider','Derveyî mijarê','دەرەوەی بابەت'),
/* charades */
teamA:S('الفريق أ','Team A','Tîma A','تیپی A'),
teamB:S('الفريق ب','Team B','Tîma B','تیپی B'),
ready:S('جاهز!','Ready!','Amade!','ئامادەم!'),
correct:S('صحيح ✓','Correct ✓','Rast ✓','ڕاست ✓'),
skip:S('تخطَّ','Skip','Derbas bike','بازبدە'),
actNow:S('مثّل الكلمة بدون كلام!','Act it out. No talking!','Bêdeng nîşan bide!','بێ دەنگ نیشانی بدە!'),
gotN:S('الكلمات الصحيحة','Correct words','Peyvên rast','وشە ڕاستەکان'),
score:S('النتيجة','Score','Encam','ئەنجام'),
wins:S('فاز!','wins!','bi ser ket!','بردییەوە!'),
draw:S('تعادل!','It is a draw!','Wekhev e!','یەکسانە!'),
/* wyr */
wyrQ:S('لو خيروك، ماذا تختار؟','Would you rather…','Tu kîjanê hildibijêrî?','کامیان هەڵدەبژێریت؟'),
/* mafia */
night:S('حلّ الليل','Night falls','Şev tê','شەو داهات'),
nightSub:S('الجميع يغمض عينيه. مرّروا الجهاز بهدوء.','Everyone close your eyes. Pass the device quietly.','Hemû çavên xwe bigirin. Amûrê bêdeng derbas bikin.','هەمووان چاوتان دابخەن. ئامێرەکە بێدەنگ بدەن.'),
begin:S('ابدأ الليل','Begin the night','Şevê dest pê bike','شەو دەست پێبکە'),
chVic:S('اختر ضحية','Choose a victim','Qurbanî hilbijêre','قوربانییەک هەڵبژێرە'),
chSave:S('من تنقذ؟','Who do you save?','Tu kê xilas dikî?','کێ ڕزگار دەکەیت؟'),
chCheck:S('من تفحص؟','Who do you check?','Tu kê kontrol dikî?','کێ دەپشکنیت؟'),
isMaf:S('هذا من المافيا!','This player is Mafia!','Ev lîstikvan Mafya ye!','ئەم یاریزانە مافیایە!'),
notMaf:S('ليس من المافيا.','Not Mafia.','Mafya nîne.','مافیا نییە.'),
morning:S('طلع الصباح','Morning comes','Sibeh hat','بەیانی هات'),
died:S('قُتل هذه الليلة','Killed tonight','Vê şevê hate kuştin','ئەم شەوە کوژرا'),
noDeath:S('لم يمت أحد الليلة!','Nobody died tonight!','Vê şevê tu kes nemir!','ئەم شەوە کەس نەمرد!'),
dayVote:S('النهار: من تتهمون؟','Day: who do you accuse?','Roj: hûn kê tawanbar dikin?','ڕۆژ: کێ تۆمەتبار دەکەن؟'),
nobody:S('لا أحد','Nobody','Tu kes','هیچ کەس'),
outed:S('أُقصي من اللعبة','was voted out','ji lîstikê hate derxistin','لە یاری دەرکرا'),
nextNight:S('الليلة التالية','Next night','Şeva din','شەوی داهاتوو'),
mafWin:S('فازت المافيا!','The Mafia wins!','Mafya bi ser ket!','مافیا بردییەوە!'),
partners:S('شركاؤك في المافيا','Your Mafia partners','Hevalbendên te yên Mafya','هاوبەشەکانت لە مافیا'),
needMaf:S('المافيا تحتاج 5 لاعبين على الأقل.','Mafia needs at least 5 players.','Mafya herî kêm 5 lîstikvan dixwaze.','مافیا لانی کەم ٥ یاریزانی دەوێت.'),
roles:S('الأدوار','Roles','Rol','ڕۆڵەکان'),
op:S('عملية','Operation','Operasyona','ئۆپەراسیۆنی'),
board:S('لوحة الصدارة','Leaderboard','Tabloya pêşengan','تابلۆی پێشەنگان'),
tagline:S('العب .. شارك .. استمتع','Play · Share · Enjoy','Bilîze · Parve bike · Kêf bike','یاری بکە · هاوبەش بکە · چێژ وەربگرە'),
incent:S('التحفيز','Rewards','Xelat','خەڵات'),
multi1:S('لعب جماعي','Group play','Lîstika komî','یاریی کۆمەڵایەتی'),
multi2:S('على جهاز واحد','On one device','Li ser yek amûrê','لەسەر یەک ئامێر'),
pass1:S('تمرّر الجهاز','Pass the device','Amûrê derbas bike','ئامێرەکە بدە بەدوایی'),
pass2:S('بين أصدقائك','between friends','di nav hevalan de','لەنێو هاوڕێکان'),
qRight:S('إجابة صحيحة!','Correct!','Rast e!','ڕاست بوو!'),
qWrong:S('إجابة خاطئة!','Wrong answer!','Bersiva şaş!','وەڵامی هەڵە!'),
qTurn:S('دور','Turn of','Rêza','نۆرەی'),
counting:S('جاري فرز الأصوات...','Counting the votes…','Deng tên jimartin…','دەنگەکان دەژمێردرێن…'),
streak:S('🔥 سلسلة إجابات صحيحة! +1 نقطة','🔥 Streak bonus! +1 point','🔥 Bonusa rêzê! +1 xal','🔥 خەڵاتی زنجیرە! +1 خاڵ'),
lvUp:S('ارتقى إلى المستوى','reached level','gihîşt asta','گەیشتە ئاستی'),
skinReady:S('شخصية جديدة متاحة!','new avatar available!','karakterekî nû heye!','کارەکتەرێکی نوێ بەردەستە!'),
surprise:S('فاجئني بلعبة','Surprise me','Min şaş bike','سەرسامم بکە'),
pause:S('إيقاف مؤقت','Pause','Rawestîne','ڕاوەستان'),
resume:S('متابعة','Resume','Bidomîne','بەردەوامبە'),
honor:S('كل عملية تحمل اسم قائد كردي من التاريخ، تكريماً له.','Each operation is named in honor of a historical Kurdish leader.','Her operasyon ji bo rêzgirtinê bi navê rêberekî dîrokî yê Kurd hatiye binavkirin.','هەر ئۆپەراسیۆنێک بە ناوی ڕێبەرێکی مێژوویی کورد ناونراوە، وەک ڕێزلێنان.')
};
const LEADERS=[S('صلاح الدين الأيوبي','Saladin','Selahedînê Eyubî','سەلاحەدینی ئەییووبی'),S('الشيخ محمود الحفيد','Sheikh Mahmud Barzanji','Şêx Mehmûdê Hefîd','شێخ مەحموودی حەفید'),S('مصطفى البارزاني','Mustafa Barzani','Mistefa Barzanî','مستەفا بارزانی'),S('بدرخان بك','Bedir Khan Beg','Bedirxan Beg','بەدرخان بەگ'),S('جلادت بدرخان','Celadet Bedirxan','Celadet Bedirxan','جەلادەت بەدرخان'),S('قاضي محمد','Qazi Muhammad','Qazî Mihemed','قازی محەمەد')];
T.resume=S('استئناف آخر لعبة','Resume last game','Lîstika dawî berdewam bike','کۆتا یاری بەردەوام بکە');
T.stats=S('إحصائياتك','Your stats','Statîstîkên te','ئامارەکانت');
T.played=S('مباريات','games','lîstik','یاری');
T.wonN=S('فوز','wins','serkeftin','بردنەوە');
T.resetAll=S('مسح كل البيانات','Erase all data','Hemû daneyan jê bibe','سڕینەوەی هەموو زانیارییەکان');
T.resetSure=S('سيتم مسح الأسماء والنقاط والإحصائيات نهائيًا. هل أنت متأكد؟','Names, points and stats will be erased for good. Are you sure?','Nav, xal û statîstîk dê bi tevahî werin jêbirin. Tu piştrast î?','ناو و خاڵ و ئامار بۆ هەمیشە دەسڕدرێنەوە. دڵنیایت؟');
const t=k=>T[k][st.lang], tr=o=>o[st.lang];

const GAMES=[
{id:'spy',tg:S('المكان السري','Secret place','Cihê veşartî','شوێنی نهێنی'),min:3,c:'#1b4fd1',fg:'#fff',ic:'🕵️',n:S('الجاسوس','Spy','Sîxur','سیخوڕ'),d:S('الكل يعرف المكان إلا الجاسوس','Everyone knows the place except the spy','Hemû cihê dizanin ji bilî sîxur','هەموو شوێنەکە دەزانن جگە لە سیخوڕ'),
 h:S('الجميع يعرفون المكان إلا الجاسوس. اسألوا بعضكم بذكاء دون كشف المكان. يفوز المواطنون إذا صوّتوا على الجاسوس قبل انتهاء الوقت، ويفوز الجاسوس إذا لم يُكشف أو صوّتوا على بريء أو خمّن المكان.','Everyone knows the place except the spy. Ask each other clever questions without giving the place away. Citizens win by voting out the spy in time. The spy wins if not caught, if an innocent is accused, or if he guesses the place.','Hemû cihê dizanin ji bilî sîxur. Bi jîrekî ji hev bipirsin bêyî ku cih eşkere bikin. Welatî bi ser dikevin eger sîxur di dem de bigirin. Sîxur bi ser dikeve eger neyê girtin, bêsûcek were tawanbarkirin, an cih rast texmîn bike.','هەموو شوێنەکە دەزانن جگە لە سیخوڕ. بە ژیرانە لە یەکتر بپرسن بێ ئاشکراکردنی شوێنەکە. هاوواڵاتییەکان دەبەنەوە ئەگەر لە کاتدا سیخوڕ هەڵبژێرن. سیخوڕ دەبات ئەگەر نەگیرێت، بێتاوانێک تۆمەتبار بکرێت، یان شوێنەکە بخەمڵێنێت.')},
{id:'out',tg:S('الكلمة السرية','Secret word','Peyva veşartî','وشەی نهێنی'),min:3,c:'#7a3bd1',fg:'#fff',ic:'🙊',n:S('برا السالفة','Outsider','Derveyî Mijarê','دەرەوەی بابەت'),d:S('الكل يعرف الكلمة إلا واحد','Everyone knows the word except one','Hemû peyvê dizanin ji bilî yekî','هەموو وشەکە دەزانن جگە لە یەک کەس'),
 h:S('الجميع يرون الكلمة السرية إلا شخص واحد «برا السالفة» يعرف الفئة فقط. تحدثوا عن الكلمة دون ذكرها ثم صوّتوا. إن كُشف الغريب فله فرصة أخيرة لتخمين الكلمة.','Everyone sees the secret word except one outsider who only knows the category. Talk about it without saying it, then vote. If the outsider is caught, he gets one last guess.','Hemû peyva veşartî dibînin ji bilî yekî ku tenê kategoriyê dizane. Bêyî gotina wê behsa wê bikin, paşê deng bidin. Eger were girtin, şansek dawî heye.','هەموو وشە نهێنییەکە دەبینن جگە لە یەک کەس کە تەنها پۆلەکە دەزانێت. بێ ووتنی وشەکە باسی بکەن، پاشان دەنگ بدەن. ئەگەر بگیرێت دەرفەتێکی کۆتایی هەیە.')},
{id:'cha',tg:S('تمثيل صامت','Charades','Bê gotin','بێ وشە'),min:4,c:'#e8870e',fg:'#fff',ic:'🎭',n:S('بدون كلام','Silent Charades','Bê Peyv','بێ وشە'),d:S('مثّل الكلمة بدون كلام','Act out the word, no talking','Peyvê bêyî gotin nîşan bide','وشەکە بێ قسە نیشان بدە'),
 h:S('ينقسم اللاعبون إلى فريقين ويتناوبون. الممثل يرى الكلمة ويمثلها بدون أي صوت، وفريقه يخمّن قبل انتهاء الوقت. كل كلمة صحيحة بنقطة.','Players split into two teams and take turns. The actor sees the word and acts it out with no sound while the team guesses before time runs out. Each correct word is one point.','Lîstikvan dibin du tîm û bi rêz dilîzin. Lîstikvan peyvê dibîne û bêdeng nîşan dide, tîm berî dawiya demê texmîn dike. Her peyva rast xalek e.','یاریزانەکان دەبن بە دوو تیپ و بە نۆرە یاری دەکەن. ئەکتەرەکە وشەکە دەبینێت و بێ دەنگ نیشانی دەدات، تیپەکەی پێش کۆتایی کات دەیخەمڵێنێت. هەر وشەیەکی ڕاست خاڵێکە.')},
{id:'wyr',tg:S('اختر الأصعب','Would you rather','Hilbijêre','هەڵبژێرە'),min:2,c:'#0f9d8a',fg:'#fff',ic:'⚖️',n:S('لو خيروك','Would You Rather','Tu Kîjanê Hildibijêrî?','کامیان هەڵدەبژێریت؟'),d:S('اختر بين خيارين صعبين','Choose between two tough options','Di navbera du bijartinên zor de hilbijêre','لە نێوان دوو هەڵبژاردەی قورس هەڵبژێرە'),
 h:S('يظهر خياران. كل لاعب يختار ويشرح لماذا. اضغط على الخيار لتسجيل كل صوت.','Two options appear. Everyone picks one and explains why. Tap an option to count each vote.','Du bijartin xuya dibin. Her kes yekê hildibijêre û sedemê dibêje. Ji bo hejmartina dengan li bijartinê bitikîne.','دوو هەڵبژاردە دەردەکەون. هەموو یەکێک هەڵدەبژێرێت و هۆکارەکەی دەڵێت. دەست لە هەڵبژاردەکە بدە بۆ ژماردنی دەنگەکان.')},
{id:'maf',tg:S('قتل وتحقيق','Kill & investigate','Kuştin û lêkolîn','کوشتن و لێکۆڵینەوە'),min:5,c:'#b01c1c',fg:'#fff',ic:'🌙',n:S('المافيا','Mafia','Mafya','مافیا'),d:S('المافيا تقتل ليلاً وأنتم تحاكمون نهاراً','Mafia kills at night, you judge by day','Mafya şevê dikuje, hûn rojê dadbar in','مافیا شەو دەکوژێت و ئێوە ڕۆژ دادوەرن'),
 h:S('في الليل تختار المافيا ضحية، ينقذ الطبيب شخصاً، ويفحص المحقق شخصاً. في النهار تصوّتون لإقصاء مشتبه به. تفوز المافيا إذا تساوى عددها مع الباقين، ويفوز المواطنون إذا أُقصيت المافيا كلها.','At night the Mafia picks a victim, the doctor saves someone, the detective checks someone. By day you vote out a suspect. The Mafia wins when it equals everyone else, citizens win when all Mafia are out.','Şevê Mafya qurbanek hildibijêre, doktor kesekî xilas dike, lêkolîner kesekî kontrol dike. Rojê gumanbarekî derdixin. Mafya bi ser dikeve gava hejmara wê bibe wekî yên din, welatî gava hemû Mafya derkevin.','شەو مافیا قوربانییەک هەڵدەبژێرێت، پزیشک کەسێک ڕزگار دەکات، لێکۆڵەر کەسێک دەپشکنێت. ڕۆژ دەنگ دەدەن بۆ دەرکردنی گومانلێکراو. مافیا دەبات کاتێک ژمارەی وەک ئەوانی تر بێت، هاوواڵاتییەکان کاتێک هەموو مافیا دەربکرێن.')},
{id:'spi',tg:S('مدن وقادة','Cities & leaders','Bajar û rêber','شار و ڕێبەر'),min:2,c:'#c9961a',fg:'#fff',ic:'☀️',n:S('الروح الكردية','Kurdish Spirit','Ruhê Kurdî','ڕۆحی کوردی'),d:S('اختبر معرفتك بمدن وقادة كردستان','Test your knowledge of Kurdish cities and leaders','Zanîna xwe ya li ser bajar û rêberên Kurdan biceribîne','زانیاریت دەربارەی شار و ڕێبەرانی کورد تاقی بکەرەوە'),
 h:S('يجيب كل لاعب بدوره عن سؤال عن مدن وقادة كردستان ويمرّر الجهاز. كل إجابة صحيحة بنقطة، والأعلى نقاطاً يفوز.','Each player answers a question about Kurdish cities and leaders in turn, then passes the device. Each correct answer is one point, and the highest score wins.','Her lîstikvan bi rêz pirsek derbarê bajar û rêberên Kurdan bersiv dide û amûrê derbas dike. Her bersiva rast xalek e, yê herî zêde xal bi dest bixe bi ser dikeve.','هەر یاریزانێک بە نۆرە وەڵامی پرسیارێک دەداتەوە دەربارەی شار و ڕێبەرانی کورد و ئامێرەکە دەدات بەدوایی. هەر وەڵامێکی ڕاست خاڵێکە و بەرزترین خاڵ دەبات.')}];
const ROLES={
maf:{ic:'🔪',n:S('المافيا','Mafia','Mafya','مافیا'),h:S('اقتل مواطناً كل ليلة دون أن تنكشف.','Eliminate a citizen every night without being caught.','Her şev welatiyekî ji holê rake bêyî ku were girtin.','هەموو شەوێک هاوواڵاتییەک لاببە بەبێ ئەوەی بگیرێیت.')},
doc:{ic:'💉',n:S('الطبيب','Doctor','Doktor','پزیشک'),h:S('أنقذ شخصاً كل ليلة.','Save one person each night.','Her şev kesekî xilas bike.','هەموو شەوێک کەسێک ڕزگار بکە.')},
det:{ic:'🔎',n:S('المحقق','Detective','Lêkolîner','لێکۆڵەر'),h:S('اكشف إن كان شخص ما من المافيا.','Find out whether someone is Mafia.','Bibîne gelo kesek Mafya ye an na.','بزانە ئایا کەسێک مافیایە یان نا.')},
cit:{ic:'🧑',n:S('مواطن','Citizen','Welatî','هاوواڵاتی'),h:S('ابحث عن المافيا وصوّت ضدها.','Find the Mafia and vote them out.','Mafyayê bibîne û deng bide dijî.','مافیا بدۆزەوە و دەنگی لێ بدە.')}};

/* ================= CONTENT ================= */
const NAMES=[S('شيركو','Şêrko','Şêrko','شێرکۆ'),S('دلان','Dilan','Dilan','دیلان'),S('باران','Baran','Baran','باران'),S('زوزان','Zozan','Zozan','زۆزان'),S('كاوه','Kawe','Kawe','کاوە'),S('هيفي','Hêvî','Hêvî','هیوا'),S('آوات','Awat','Awat','ئاوات'),S('نالين','Nalîn','Nalîn','نالین'),S('ريباز','Rêbaz','Rêbaz','ڕێباز'),S('روجين','Rojîn','Rojîn','ڕۆژین'),S('شورش','Şoreş','Şoreş','شۆڕش'),S('بيريڤان','Bêrîvan','Bêrîvan','بێریڤان')];
const CITY={hewler:S('أربيل','Erbil','Hewlêr','هەولێر'),sile:S('السليمانية','Sulaymaniyah','Silêmanî','سلێمانی'),duhok:S('دهوك','Duhok','Dihok','دهۆک'),amed:S('ديار بكر','Diyarbakır','Amed','ئامەد'),qamis:S('القامشلي','Qamishli','Qamişlo','قامیشلۆ'),kobani:S('كوباني','Kobani','Kobanî','کۆبانێ'),kerkuk:S('كركوك','Kirkuk','Kerkûk','کەرکووک'),mahabad:S('مهاباد','Mahabad','Mehabad','مەهاباد'),sine:S('سنندج','Sanandaj','Sine','سنە'),zaxo:S('زاخو','Zakho','Zaxo','زاخۆ')};
const LOCS=[
{c:'hewler',n:S('الملعب الرئيسي','Main stadium','Stadyûma sereke','یاریگای سەرەکی')},
{c:'sile',n:S('ملعب التدريب','Training pitch','Qada rahênanê','یاریگای ڕاهێنان')},
{c:'duhok',n:S('غرفة الملابس','Locker room','Odeya cilan','ژووری جلگۆڕین')},
{c:'amed',n:S('غرفة الـVAR','VAR room','Odeya VAR','ژووری VAR')},
{c:'qamis',n:S('أكاديمية الناشئين','Youth academy','Akademiya ciwanan','ئەکادیمیای گەنجان')},
{c:'kobani',n:S('مدرج الجماهير','Fan terrace','Tribûna alîgiran','سەکۆی لایەنگران')},
{c:'kerkuk',n:S('مكتب الانتقالات','Transfer office','Ofîsa veguhastinê','نووسینگەی گواستنەوە')},
{c:'mahabad',n:S('عيادة الإصابات','Injury clinic','Klînîka birînan','کلینیکی برینی یاریزانان')},
{c:'sine',n:S('قاعة المؤتمر الصحفي','Press conference room','Salona konferansa çapemeniyê','هۆڵی کۆنفرانسی ڕۆژنامەوانی')},
{c:'zaxo',n:S('كشك الوجبات في الملعب','Stadium snack kiosk','Kiyoska xwarinê ya stadyûmê','کیۆسکی خواردنی یاریگا')},
{c:'hewler',n:S('متحف الكؤوس','Trophy museum','Muzexaneya kupayan','مۆزەخانەی کاپەکان')},
{c:'amed',n:S('ملعب الحارة','Street pitch','Qada kolanê','یاریگای کۆڵان')},
{c:'sile',n:S('متجر القمصان','Jersey shop','Dikana fanîleyan','دووکانی فانیلە')},
{c:'duhok',n:S('حافلة الفريق','Team bus','Otobusa tîmê','پاسی تیپ')},
{c:'kerkuk',n:S('صالة اللياقة','Fitness gym','Salona fitnesê','هۆڵی وەرزش')},
{c:'qamis',n:S('نفق اللاعبين','Players’ tunnel','Tûnela lîstikvanan','تونێلی یاریزانان')}];
const CATS=[
{n:S('الأطعمة','Foods','Xwarin','خواردن'),w:[S('كباب','Kebab','Kebab','کەباب'),S('دولمة','Dolma','Dolme','دۆڵمە'),S('بقلاوة','Baklava','Baqlawa','باقڵاوە'),S('أرز','Rice','Birinc','برنج'),S('لبن','Yogurt','Mast','ماست'),S('خبز','Bread','Nan','نان')]},
{n:S('الحيوانات','Animals','Ajal','ئاژەڵ'),w:[S('أسد','Lion','Şêr','شێر'),S('حصان','Horse','Hesp','ئەسپ'),S('ذئب','Wolf','Gur','گورگ'),S('قطة','Cat','Pisîk','پشیلە'),S('جمل','Camel','Deve','وشتر'),S('أرنب','Rabbit','Kêvroşk','کەروێشک')]},
{n:S('كرة القدم','Football','Futbol','تۆپی پێ'),w:[S('هدف','Goal','Gol','گۆڵ'),S('حكم','Referee','Dadwer','ڕیفەری'),S('ركلة جزاء','Penalty','Pênaltî','پێنالتی'),S('حارس المرمى','Goalkeeper','Golvan','دەروازەوان'),S('كأس','Trophy','Kup','کاپ'),S('بطاقة حمراء','Red card','Karta sor','کارتی سوور')]},
{n:S('أماكن','Places','Cih','شوێن'),w:[S('مدرسة','School','Dibistan','قوتابخانە'),S('مستشفى','Hospital','Nexweşxane','نەخۆشخانە'),S('سوق','Market','Bazar','بازاڕ'),S('مطار','Airport','Balafirgeh','فڕۆکەخانە'),S('حديقة','Park','Park','پارک'),S('فرن','Bakery','Firin','نانەواخانە')]},
{n:S('الطبيعة والنوروز','Nature & Newroz','Xwezayî û Newroz','سرووشت و نەورۆز'),w:[S('جبل','Mountain','Çiya','شاخ'),S('نهر','River','Çem','ڕووبار'),S('ثلج','Snow','Berf','بەفر'),S('نار','Fire','Agir','ئاگر'),S('شمس','Sun','Roj','خۆر'),S('نوروز','Newroz','Newroz','نەورۆز')]}];
CATS.push({n:S('مدن كردية','Kurdish cities','Bajarên Kurdan','شارە کوردییەکان'),w:[CITY.hewler,CITY.sile,CITY.duhok,CITY.amed,CITY.qamis,CITY.kobani]});
let ALLWORDS=CATS.flatMap(c=>c.w);
const WYR=[
[S('تسجّل هدف الفوز في النهائي لكن لا أحد يراه','Score the winning goal in the final, but nobody sees it','Golê serkeftinê di fînalê de bikî, lê kes nebîne','گۆڵی بردنەوە لە کۆتاییدا بکەیت، بەڵام کەس نەیبینێت'),S('تخسر النهائي لكن الجميع يهتف باسمك','Lose the final, but everyone chants your name','Fînalê winda bikî, lê hemû navê te bibêjin','کۆتاییەکە دۆڕێنیت، بەڵام هەموو بە ناوی تۆ هاوار بکەن')],
[S('أن تكون أفضل لاعب في فريق خاسر دائماً','Always be the best player on a losing team','Her tim di tîmeke têkçûyî de lîstikvanê herî baş bî','هەمیشە باشترین یاریزان بیت لە تیپێکی دۆڕاو'),S('أن تكون لاعباً عادياً في فريق فائز دائماً','Always be an average player on a winning team','Her tim di tîmeke serkeftî de lîstikvanekî asayî bî','هەمیشە یاریزانێکی ئاسایی بیت لە تیپێکی براوە')],
[S('تأكل الكباب فقط لمدة سنة','Eat only kebab for a year','Salekê tenê kebab bixwî','ساڵێک تەنها کەباب بخۆیت'),S('تأكل الدولمة فقط لمدة سنة','Eat only dolma for a year','Salekê tenê dolme bixwî','ساڵێک تەنها دۆڵمە بخۆیت')],
[S('تلعب حافياً على الثلج','Play barefoot on snow','Li ser berfê lingsivik bilîzî','بە پێخاوسی لەسەر بەفر یاری بکەیت'),S('تلعب بحذاء ثقيل على رمل ساخن','Play in heavy boots on hot sand','Bi pêlavên giran li ser qûmê germ bilîzî','بە پێڵاوی قورس لەسەر لمی گەرم یاری بکەیت')],
[S('حكم يلاحقك أينما ذهبت','Have a referee follow you everywhere','Dadwerek li her derê li pey te be','ڕیفەرییەک بە هەموو شوێنێک شوێنت بکەوێت'),S('معلق رياضي يروي حياتك بصوت عالٍ','Have a commentator narrate your life out loud','Şîrovekarek jiyana te bi dengê bilind vebêje','شیکەرەوەیەک ژیانت بە دەنگی بەرز ڕابگێڕێت')],
[S('لا تخطئ أي ركلة جزاء أبداً','Never miss a penalty','Tu carî pênaltiyekê winda nekî','هەرگیز پێنالتییەک بەفیڕۆ نەدەیت'),S('لا تخطئ أي تمريرة أبداً','Never miss a pass','Tu carî pasek winda nekî','هەرگیز پاسێک بەفیڕۆ نەدەیت')],
[S('تتكلم بالهمس فقط','Only speak in whispers','Tenê bi pistepistê biaxivî','تەنها بە چرپە قسە بکەیت'),S('تتكلم بالصراخ فقط','Only speak in shouts','Tenê bi qêrînê biaxivî','تەنها بە هاوار قسە بکەیت')],
[S('تقابل لاعبك المفضل','Meet your favorite player','Bi lîstikvanê xwe yê hezkirî re hevdîtinê bikî','لەگەڵ یاریزانە دڵخوازەکەت بگەیت'),S('تلعب مباراة واحدة إلى جانبه','Play one match alongside him','Maçek li kêleka wî bilîzî','یەک یاری لەتەنیشتی یاری بکەیت')],
[S('تفوز بكل مباراة 1-0','Win every match 1-0','Her maçê bi 1-0 bibî','هەموو یاریەک بە 1-0 ببەیتەوە'),S('تخسر كل مباراة 5-4 بأهداف رائعة','Lose every match 5-4 with amazing goals','Her maçê bi 5-4 winda bikî, lê bi golên bêhempa','هەموو یاریەک بە 5-4 بدۆڕێنیت بەڵام بە گۆڵی نایاب')],
[S('تعيش سنة في جبال كردستان','Live a year in the mountains of Kurdistan','Salekê li çiyayên Kurdistanê bijî','ساڵێک لە شاخەکانی کوردستان بژیت'),S('تعيش سنة على شاطئ البحر','Live a year by the sea','Salekê li peravê deryayê bijî','ساڵێک لە کەناراوی دەریا بژیت')],
[S('تصل دائماً قبل الموعد بساعة','Always arrive an hour early','Her tim saetek zû bigihîjî','هەمیشە کاتژمێرێک زووتر بگەیت'),S('تصل دائماً متأخراً عشر دقائق','Always arrive ten minutes late','Her tim deh xulekan dereng bigihîjî','هەمیشە دە خولەک درەنگ بگەیت')],
[S('تتكلم كل لغات العالم','Speak every language in the world','Bi hemû zimanên cîhanê biaxivî','بە هەموو زمانەکانی جیهان قسە بکەیت'),S('تتحدث مع الحيوانات','Talk to animals','Bi ajalan re biaxivî','لەگەڵ ئاژەڵەکان قسە بکەیت')],
[S('تأكل الحلويات فقط للأبد','Eat only sweets forever','Her û her tenê şirînî bixwî','بۆ هەمیشە تەنها شیرینی بخۆیت'),S('تأكل المالح فقط للأبد','Eat only salty food forever','Her û her tenê xwarinên şor bixwî','بۆ هەمیشە تەنها خواردنی شور بخۆیت')],
[S('يكون عندك أسد أليف','Have a pet lion','Şêrekî dahûrandî hebe','شێرێکی ڕامت هەبێت'),S('يكون عندك حصانك الخاص','Have your own horse','Hespê te yê taybet hebe','ئەسپی تایبەت بە خۆت هەبێت')]];

const QZ=[
{t:'c',a:'amed',q:S('أي مدينة تشتهر بأسوارها البازلتية السوداء؟','Which city is famous for its black basalt walls?','Kîjan bajar bi dîwarên xwe yên bazaltê yên reş navdar e?','کام شار بە شووراکانی بەزاڵتی ڕەش ناودارە؟')},
{t:'c',a:'hewler',q:S('ما عاصمة إقليم كردستان؟','Which city is the capital of the Kurdistan Region?','Paytexta Herêma Kurdistanê kîjan bajar e?','پایتەختی هەرێمی کوردستان کام شارە؟')},
{t:'c',a:'sile',q:S('أي مدينة أسسها إبراهيم باشا بابان عام 1784؟','Which city was founded by Ibrahim Pasha Baban in 1784?','Kîjan bajar di sala 1784an de ji aliyê Îbrahîm Paşayê Babanî ve hat avakirin?','کام شار لە ساڵی 1784 لەلایەن ئیبراهیم پاشای بابان دامەزرا؟')},
{t:'c',a:'kerkuk',q:S('أي مدينة تشتهر بحقول النفط الكبيرة؟','Which city is known for its large oil fields?','Kîjan bajar bi zeviyên xwe yên mezin ên petrolê tê nasîn?','کام شار بە کێڵگە گەورەکانی نەوت ناسراوە؟')},
{t:'l',a:0,q:S('من القائد الكردي الذي حرّر القدس عام 1187؟','Which Kurdish leader liberated Jerusalem in 1187?','Kîjan rêberê Kurd di sala 1187an de Quds rizgar kir?','کام ڕێبەری کورد لە ساڵی 1187 قودسی ڕزگار کرد؟')},
{t:'l',a:4,q:S('من أصدر مجلة «هاوار» ووضع الأبجدية الكردية اللاتينية؟','Who published the Hawar magazine and created the Kurdish Latin alphabet?','Kê kovara Hawarê weşand û alfabeya Latînî ya Kurdî çêkir?','کێ گۆڤاری هاواری بڵاوکردەوە و ئەلفوبێی لاتینیی کوردی دانا؟')},
{t:'l',a:5,q:S('من كان رئيس جمهورية مهاباد عام 1946؟','Who was president of the Republic of Mahabad in 1946?','Di sala 1946an de serokê Komara Mehabadê kî bû?','لە ساڵی 1946 سەرۆکی کۆماری مەهاباد کێ بوو؟')},
{t:'l',a:1,q:S('من أعلن مملكة كردستان في السليمانية عام 1922؟','Who declared the Kingdom of Kurdistan in Sulaymaniyah in 1922?','Kê di sala 1922an de li Silêmaniyê Padîşahiya Kurdistanê ragihand?','کێ لە ساڵی 1922 لە سلێمانی شانشینی کوردستانی ڕاگەیاند؟')},
{t:'l',a:3,q:S('من كان أمير إمارة بوتان الكردية في القرن التاسع عشر؟','Who was the emir of the Kurdish Emirate of Botan in the 19th century?','Di sedsala nozdehan de mîrê Mîrnişîna Botanê kî bû?','لە سەدەی نۆزدەدا میری میرنشینی بۆتان کێ بوو؟')},
{t:'l',a:2,q:S('من القائد الكردي المولود في بارزان عام 1903؟','Which Kurdish leader was born in Barzan in 1903?','Kîjan rêberê Kurd di sala 1903an de li Barzanê ji dayik bû?','کام ڕێبەری کورد لە ساڵی 1903 لە بارزان لەدایک بوو؟')}];
const qOpts=q=>{if(q.t==='x')return shuffle(q.ol.map((_,i)=>String(i)));const pool=q.t==='c'?Object.keys(CITY):LEADERS.map((_,i)=>String(i));const a=String(q.a);return shuffle([a,...shuffle(pool.filter(x=>x!==a)).slice(0,2)])};
const qLabel=(q,x)=>q.t==='x'?tr(q.ol[+x]):q.t==='c'?tr(CITY[x]):tr(LEADERS[+x]);

/* ================= ART ================= */
function sun(s){let r='';for(let i=0;i<21;i++)r+=`<polygon points="50,3 44,30 56,30" transform="rotate(${i*360/21} 50 50)" fill="#ffc72c" stroke="#0b2b1c" stroke-width="2" stroke-linejoin="round"/>`;
return `<svg viewBox="0 0 100 100" width="${s}" height="${s}" aria-hidden="true">${r}<circle cx="50" cy="50" r="22" fill="#ffc72c" stroke="#0b2b1c" stroke-width="3"/></svg>`}
const AV=Array.from({length:9},(_,i)=>'assets/av/'+i+'.webp');
const SK=[
{n:S('المهاجم الأحمر','Red Striker','Lêdera Sor','هێرشبەری سوور'),cost:0},
{n:S('الجناح الأصفر','Yellow Winger','Baskê Zer','باڵی زەرد'),cost:0},
{n:S('نجمة الفريق','Team Star','Stêrka Tîmê','ئەستێرەی تیپ'),cost:0},
{n:S('القائدة','The Captain','Kaptan','کاپتن'),cost:0},
{n:S('الشاب الرياضي','Sporty Guy','Xortê Werzişvan','لاوی وەرزشی'),cost:0},
{n:S('العميلة السرية','Secret Agent','Ajanta Veşartî','ئاژانتی نهێنی'),cost:2},
{n:S('الجاسوس','The Spy','Sîxur','سیخوڕ'),cost:3},
{n:S('الزي الكردي - نسائي','Kurdish Dress · Women','Cilê Kurdî · Jin','جلی کوردی · ژنان'),cost:5},
{n:S('الزي الكردي - رجالي','Kurdish Dress · Men','Cilê Kurdî · Mêr','جلی کوردی · پیاوان'),cost:5}];
const TILEIMG={spy:'assets/tiles/spy.webp',out:'assets/tiles/out.webp',cha:'assets/tiles/cha.webp',wyr:'assets/tiles/wyr.webp',maf:'assets/tiles/maf.webp',spi:'assets/tiles/spi.webp'};
(function(){const e=document.createElement('style');e.textContent=Object.keys(TILEIMG).map(k=>'.tg-'+k+'{background-image:url('+TILEIMG[k]+')}').join('\n');document.head.appendChild(e)})();
(function(){const e=document.createElement('style');e.textContent=AV.map((u,i)=>'.av'+i+'{background-image:url('+u+')}').join('\n');document.head.appendChild(e)})();
function face(id,s,dark){return `<span class="fa av${id}${dark?' dk':''}" style="width:${s}px;height:${s}px" role="img"></span>`}
function faceP(i,s,dark){if(i===0&&st.me&&st.me.photo&&st.me.usePhoto)return `<span class="fa ph${dark?' dk':''}" style="width:${s}px;height:${s}px;background-image:url(${st.me.photo})" role="img"></span>`;return face(st.skin[i],s,dark)}

function art(id){
 const G=(a,b)=>`<defs><linearGradient id="g${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="200" height="150" fill="url(#g${id})"/>`;
 let b='';
 if(id==='spy')b=G('#2b6bff','#08144a')+`<rect x="130" y="14" width="56" height="34" rx="4" fill="#0a1c5a" stroke="#6fb1ff" stroke-width="2"/><text x="158" y="38" font-size="20" text-anchor="middle" fill="#fff" font-family="Bangers,sans-serif">VAR</text><text x="18" y="46" font-size="34" fill="#8fc2ff" opacity=".55">?</text><path d="M52 150 L54 100 Q88 86 122 100 L124 150Z" fill="#0a0f26"/><ellipse cx="88" cy="64" rx="54" ry="9" fill="#0a0f26"/><path d="M54 64 Q58 22 88 22 Q118 22 122 64Z" fill="#0a0f26"/><rect x="56" y="52" width="64" height="7" fill="#2b3a7a"/><circle cx="88" cy="82" r="20" fill="#1a1f3d"/><rect x="66" y="74" width="44" height="12" rx="6" fill="#02040f"/><path d="M72 77 L84 77" stroke="#6fb1ff" stroke-width="2"/>`;
 if(id==='out')b=G('#a24dff','#2b0f66')+`<circle cx="100" cy="78" r="30" fill="#17093a"/><path d="M40 150 Q44 112 100 108 Q156 112 160 150Z" fill="#17093a"/><text x="100" y="92" font-size="46" text-anchor="middle" fill="#fff" font-family="Bangers,sans-serif">?</text><rect x="18" y="22" width="48" height="30" rx="9" fill="#e07bff"/><path d="M28 34 H56 M28 42 H48" stroke="#fff" stroke-width="3" stroke-linecap="round"/><rect x="136" y="70" width="42" height="26" rx="9" fill="#e07bff"/><circle cx="160" cy="28" r="12" fill="#ffd54a"/><path d="M160 10 V4 M178 28 H186 M142 28 H134" stroke="#ffd54a" stroke-width="3" stroke-linecap="round"/>`;
 if(id==='cha')b=G('#ffb040','#a33b00')+`<circle cx="82" cy="82" r="34" fill="#f2a96e"/><path d="M46 70 Q82 20 118 70Z" fill="#a8261c"/><rect x="42" y="66" width="82" height="9" rx="4" fill="#7e1b13"/><ellipse cx="82" cy="100" rx="11" ry="9" fill="#5a1a10"/><circle cx="70" cy="82" r="4" fill="#2b140a"/><circle cx="96" cy="82" r="4" fill="#2b140a"/><path d="M40 150 Q44 118 82 116 Q120 118 124 150Z" fill="#7e1b13"/><rect x="132" y="96" width="56" height="42" rx="3" fill="#1b1b1b"/><path d="M132 96 L188 82 L188 94 L132 108Z" fill="#fff"/><path d="M146 92 L150 86 M164 88 L168 82" stroke="#1b1b1b" stroke-width="5"/><path d="M142 14 L132 28 M158 8 L156 26 M178 18 L166 30" stroke="#ffd54a" stroke-width="4" stroke-linecap="round"/>`;
 if(id==='wyr')b=G('#19d6a3','#06403a')+`<g transform="rotate(-12 55 62)"><rect x="28" y="36" width="54" height="54" rx="6" fill="#06404a" stroke="#7dffe6" stroke-width="4"/><text x="55" y="76" font-size="38" text-anchor="middle" fill="#fff" font-family="Bangers,sans-serif">A</text></g><g transform="rotate(12 146 62)"><rect x="118" y="36" width="54" height="54" rx="6" fill="#06404a" stroke="#7dffe6" stroke-width="4"/><text x="146" y="76" font-size="38" text-anchor="middle" fill="#fff" font-family="Bangers,sans-serif">B</text></g><text x="100" y="52" font-size="52" text-anchor="middle" fill="#fff" font-family="Bangers,sans-serif">?</text><circle cx="100" cy="112" r="20" fill="#032a2c"/><path d="M52 150 Q56 130 100 128 Q144 130 148 150Z" fill="#032a2c"/>`;
 if(id==='maf')b=G('#d8252b','#3a0408')+`<circle cx="100" cy="52" r="46" fill="#ff3b3b" opacity=".85"/><path d="M60 150 L66 98 Q100 84 134 98 L140 150Z" fill="#12060a"/><ellipse cx="100" cy="62" rx="48" ry="8" fill="#12060a"/><path d="M68 62 Q72 24 100 24 Q128 24 132 62Z" fill="#12060a"/><circle cx="100" cy="84" r="16" fill="#12060a"/><path d="M14 150 L18 112 L40 112 L44 150Z" fill="#12060a"/><circle cx="29" cy="104" r="9" fill="#12060a"/><rect x="150" y="104" width="34" height="34" rx="6" fill="#fff"/><path d="M167 110 V132 M156 121 H178" stroke="#d8252b" stroke-width="7"/>`;
 if(id==='spi')b=G('#f4d26a','#6a4a08')+`<circle cx="150" cy="40" r="22" fill="#fff3b0" opacity=".9"/><path d="M0 110 L34 62 L58 92 L92 48 L130 96 L160 70 L200 112 V150 H0Z" fill="#7a5a14"/><path d="M0 128 L40 92 L70 118 L110 84 L150 116 L200 90 V150 H0Z" fill="#4a3408"/><rect x="62" y="84" width="76" height="46" fill="#2a1d04"/><rect x="62" y="74" width="12" height="14" fill="#2a1d04"/><rect x="80" y="74" width="12" height="14" fill="#2a1d04"/><rect x="108" y="74" width="12" height="14" fill="#2a1d04"/><rect x="126" y="74" width="12" height="14" fill="#2a1d04"/><rect x="92" y="46" width="16" height="42" fill="#2a1d04"/><path d="M90 46 L100 32 L110 46Z" fill="#2a1d04"/><rect x="94" y="102" width="12" height="28" rx="6" fill="#f4d26a"/>`;
 return `<svg viewBox="0 0 200 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${b}</svg>`}
const LANGS=[
 {k:'ar',n:'العربية',s:'Arabic',lang:'ar',dir:'rtl'},
 {k:'ckb',n:'کوردی',s:'سۆرانی · Sorani',lang:'ckb',dir:'rtl',kd:1},
 {k:'kmr',n:'Kurdî',s:'Kurmancî',lang:'ku-Latn',dir:'ltr',kd:1},
 {k:'en',n:'English',s:'English',lang:'en',dir:'ltr'}];
const curLang=()=>LANGS.find(x=>x.k===st.lang)||LANGS[0];
const langRow=(L,cls)=>`<button class="lopt ${cls||''} ${st.lang===L.k?'on':''}" data-act="setlang" data-v="${L.k}" lang="${L.lang}" aria-pressed="${st.lang===L.k}"><span class="lflag">${flag(L.k)}</span><span class="ltxt" dir="${L.dir}"><strong>${L.n}</strong><small>${L.s}</small></span><i class="chk" aria-hidden="true">${st.lang===L.k?'✓':''}</i></button>`;
function flag(k){
 if(k==='ar')return `<svg viewBox="0 0 38 26" width="38" height="26"><rect width="38" height="26" rx="3" fill="#fff"/><rect width="38" height="9" fill="#ce1126"/><rect y="17" width="38" height="9" fill="#111"/><rect x="12" y="10" width="14" height="6" fill="#007a3d"/></svg>`;
 if(k==='en')return `<svg viewBox="0 0 38 26" width="38" height="26"><rect width="38" height="26" rx="3" fill="#1f3a8a"/><path d="M0 0 L38 26 M38 0 L0 26" stroke="#fff" stroke-width="5"/><path d="M0 0 L38 26 M38 0 L0 26" stroke="#c8102e" stroke-width="2"/><path d="M19 0 V26 M0 13 H38" stroke="#fff" stroke-width="8"/><path d="M19 0 V26 M0 13 H38" stroke="#c8102e" stroke-width="4.5"/></svg>`;
 return `<svg viewBox="0 0 38 26" width="38" height="26"><rect width="38" height="26" rx="3" fill="#fff"/><rect width="38" height="9" fill="#ed2024"/><rect y="17" width="38" height="9" fill="#278e43"/><circle cx="19" cy="13" r="5.5" fill="#fbd116"/></svg>`}

/* ================= STATE ================= */
let st={lang:null,screen:'lang',back:null,game:null,n:5,g:null,slot:0,
 names:Array(12).fill(''),skin:[0,1,2,3,4,0,1,2,3,4,0,1],pts:Array(12).fill(0),own:Array.from({length:12},()=>({})),
 set:{sp:null,mn:null,cs:60},sound:true,music:true,spyCat:null,
 me:{photo:null,usePhoto:false,bd:'',code:'',registered:false,friends:[],cache:[],cacheAt:0}};
let timerId=null;

/* ================= STORAGE (local save, stats, resume) ================= */
const KEY='kgc.v1',mem={};
const store={
 get(){try{return JSON.parse(localStorage.getItem(KEY)||'null')}catch(e){return mem.d||null}},
 set(o){mem.d=o;try{localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}}};
const RESUMABLE=['reveal','play','vtPass','vtPick','guess','cIntro','cPlay','cRes','wyr','mNight','mAct','mMorn','mDay','mDayRes','qPlay'];
let stats={games:{},wins:Array(12).fill(0)};
function snapshot(){
 const o={v:1,x:XD,lang:st.lang,n:st.n,names:st.names,skin:st.skin,pts:st.pts,own:st.own,set:st.set,sound:st.sound,music:st.music,spyCat:st.spyCat,me:st.me,stats};
 if(st.g&&st.game&&RESUMABLE.includes(st.screen)&&!(st.screen==='qPlay'&&st.g.ans!==null))o.resume={game:st.game,screen:st.screen,g:st.g};
 if(!o.resume&&st.saved)o.resume=st.saved;
 return o}
function save(){try{store.set(snapshot())}catch(e){}if(window.olSchedule)olSchedule()}
function loadSaved(){
 const d=store.get();if(!d||d.v!==1)return;
 const arr=(a,len,def)=>Array.isArray(a)?Array.from({length:len},(_,i)=>a[i]??def(i)):Array.from({length:len},(_,i)=>def(i));
 if(META[d.lang])st.lang=d.lang;
 if(Number.isInteger(d.n))st.n=Math.min(12,Math.max(2,d.n));
 st.names=arr(d.names,12,()=>'').map(x=>String(x).slice(0,24));
 st.skin=arr(d.skin,12,i=>[0,1,2,3,4,0,1,2,3,4,0,1][i]).map(x=>Number.isInteger(x)&&x>=0&&x<SK.length?x:0);
 st.pts=arr(d.pts,12,()=>0).map(x=>Number.isFinite(x)&&x>=0?x:0);
 st.own=arr(d.own,12,()=>({})).map(o=>o&&typeof o==='object'?o:{});
 if(d.set&&typeof d.set==='object')st.set={...st.set,...d.set};
 if(typeof d.sound==='boolean')st.sound=d.sound;
 if(typeof d.music==='boolean')st.music=d.music;
 if(Number.isInteger(d.spyCat)&&d.spyCat>=0&&d.spyCat<9)st.spyCat=d.spyCat;
  if(d.me&&typeof d.me==='object')meLoad(d.me);
  if(d.x&&typeof d.x==='object')XDload(d.x);
 if(d.stats&&d.stats.games)stats={games:d.stats.games,wins:arr(d.stats.wins,12,()=>0)};
 if(d.lang&&META[d.lang])st.screen='hub';
 if(d.resume&&GAMES.some(x=>x.id===d.resume.game)&&d.resume.g&&d.resume.screen!=='vote'&&!(d.resume.game==='spy'&&d.resume.g.cat===undefined))st.saved=d.resume}
function recordGame(game,winners){
 const s=stats.games[game]||(stats.games[game]={played:0,wins:0});s.played++;
 (winners||[]).forEach(i=>{if(i>=0&&i<12){stats.wins[i]=(stats.wins[i]||0)+1;s.wins++}});xdPlay(winners);save()}
function resumeGame(){
 const r=st.saved;if(!r)return;st.saved=null;
 st.game=r.game;st.g=r.g;st.screen=r.screen;render();
 if(timerEnd[r.screen]&&st.g.left>0)startTimer(st.g.left,timerEnd[r.screen],true)}
window.addEventListener('pagehide',save);
document.addEventListener('visibilitychange',()=>{if(document.hidden)save()});
const pname=i=>(st.names[i]||'').trim()||tr(NAMES[i]);
const gameOf=()=>GAMES.find(x=>x.id===st.game);
const maxSp=()=>Math.max(1,Math.floor((st.n-1)/2));
const effSp=()=>Math.min(maxSp(),Math.max(1,st.set.sp??(st.n<=8?1:2)));
const effMin=()=>Math.min(15,Math.max(1,st.set.mn??(st.n<=4?4:st.n<=8?7:9)));
const fmt=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
const ids=()=>[...Array(st.n).keys()];


/* ================= MUSIC + SFX (original, synthesized) ================= */
const MOODS={
 hub:{bpm:112,root:57,sc:[0,2,4,7,9],bass:[0,0,4,4,2,2,4,4],wave:'triangle',lead:.62},
 spy:{bpm:98,root:52,sc:[0,2,3,5,7,8,11],bass:[0,0,0,4,0,0,3,2],wave:'sawtooth',lead:.45},
 fun:{bpm:126,root:60,sc:[0,2,4,5,7,9,11],bass:[0,4,0,4,2,5,2,5],wave:'square',lead:.7},
 night:{bpm:84,root:48,sc:[0,2,3,5,7,8,10],bass:[0,0,3,3,0,0,5,2],wave:'sawtooth',lead:.35}};
const MU={ctx:null,mus:null,out:null,timer:null,mood:null,step:0,next:0,deg:2};
function actx(){if(!MU.ctx){MU.ctx=new(window.AudioContext||window.webkitAudioContext)();MU.out=MU.ctx.createGain();MU.out.connect(MU.ctx.destination);MU.mus=MU.ctx.createGain();MU.mus.connect(MU.ctx.destination)}
 if(MU.ctx.state==='suspended')MU.ctx.resume();return MU.ctx}
const moodFor=()=>{const g=st.game;if(['hub','setup','skins','lang','spyCat','profile','online'].includes(st.screen)||!g)return 'hub';return g==='spy'||g==='out'?'spy':g==='maf'?'night':'fun'};
function mNote(freq,t0,dur,type,vol){const c=MU.ctx,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.value=freq;
 g.gain.setValueAtTime(0.0001,t0);g.gain.linearRampToValueAtTime(vol,t0+.015);g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
 o.connect(g);g.connect(MU.mus);o.start(t0);o.stop(t0+dur+.05)}
const mf=m=>440*Math.pow(2,(m-69)/12);
function mSched(){const M=MOODS[MU.mood],c=MU.ctx,sp=60/M.bpm/2;
 while(MU.next<c.currentTime+.35){const i=MU.step%8,t0=MU.next;
  const bd=M.bass[i];mNote(mf(M.root-12+M.sc[bd%M.sc.length]),t0,sp*.9,'triangle',.11);
  if(i%2===0)mNote(mf(M.root-12+M.sc[bd%M.sc.length]+7),t0,sp*.5,M.wave==='square'?'triangle':M.wave,.02);
  if(Math.random()<M.lead){MU.deg=Math.max(0,Math.min(M.sc.length*2-1,MU.deg+[-2,-1,-1,0,1,1,2][rnd(7)]));
   const d=MU.deg,oct=d>=M.sc.length?12:0;mNote(mf(M.root+12+oct+M.sc[d%M.sc.length]),t0,sp*(Math.random()<.3?1.8:.8),M.wave,.045)}
  if(i%4===2)mNote(8000,t0,.03,'square',.004);
  MU.step++;MU.next+=sp}}
function stopMusic(){if(MU.timer){clearInterval(MU.timer);MU.timer=null}MU.mood=null;if(MU.mus)try{MU.mus.gain.value=0}catch(e){}}
function startMusic(m){try{actx();if(MU.mood===m&&MU.timer)return;if(MU.timer)clearInterval(MU.timer);
 MU.mood=m;MU.mus.gain.value=.9;MU.step=0;MU.next=MU.ctx.currentTime+.1;MU.deg=2;MU.timer=setInterval(mSched,120);mSched()}catch(e){}}
function syncMusic(){if(st.music)startMusic(moodFor());else stopMusic()}
function tone(f,t0,d,type,v,to){const c=actx(),o=c.createOscillator(),g=c.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f,t0);if(to)o.frequency.exponentialRampToValueAtTime(to,t0+d);
 g.gain.setValueAtTime(.0001,t0);g.gain.linearRampToValueAtTime(v||.12,t0+.01);g.gain.exponentialRampToValueAtTime(.0001,t0+d);o.connect(g);g.connect(MU.out);o.start(t0);o.stop(t0+d+.05)}
function sfx(n){if(!st.sound)return;try{const c=actx(),t=c.currentTime;
 if(n==='flip')tone(220,t,.28,'sine',.12,900);
 if(n==='ok'){tone(660,t,.12,'triangle',.14);tone(990,t+.1,.2,'triangle',.14)}
 if(n==='bad')tone(260,t,.4,'sawtooth',.1,90);
 if(n==='tick')tone(1100,t,.05,'square',.05);
 if(n==='drum'){tone(120,t,.18,'sine',.3,45);tone(120,t+.28,.18,'sine',.3,45);tone(110,t+.56,.18,'sine',.3,40);tone(110,t+.9,.3,'sine',.35,38)}
 if(n==='win')[523,659,784,1047,1319].forEach((f,i)=>tone(f,t+i*.11,.3,'triangle',.14));
 }catch(e){}
 try{navigator.vibrate&&navigator.vibrate(n==='bad'?[80,40,80]:35)}catch(e){}}

/* ================= FX ================= */
function confetti(){const c=['#d62828','#ffc72c','#1f9d55','#1d8fd6','#fff','#ff7ad9'];for(let i=0;i<90;i++){const e=document.createElement('span');e.className='cf';const w=6+rnd(9);
 e.style.left=rnd(100)+'vw';e.style.width=w+'px';e.style.height=(w+rnd(8))+'px';e.style.background=c[i%6];e.style.borderRadius=i%3?'2px':'50%';e.style.animationDelay=(Math.random()*.9)+'s';e.style.animationDuration=(2.4+Math.random()*1.8)+'s';document.body.appendChild(e);setTimeout(()=>e.remove(),5200)}}
function stopTimer(){clearInterval(timerId);timerId=null}
const timerEnd={play:()=>endPlay(),cPlay:()=>cTimeUp(),qPlay:()=>qAnswer('__')};
function ring(g){const tot=g.total||g.left||1,off=339.3*(1-Math.max(g.left,0)/tot);
 return `<div class="ring ${g.left<=10?'hot':''}" id="ring"><svg viewBox="0 0 120 120"><circle class="rb" cx="60" cy="60" r="54"/><circle class="rf" id="rf" cx="60" cy="60" r="54" stroke-dasharray="339.3" stroke-dashoffset="${off.toFixed(1)}"/></svg><div class="timer" id="tm">${fmt(g.left)}</div></div>`}
function tickUI(){const g=st.g,el=$('tm');if(el)el.textContent=fmt(Math.max(g.left,0));const rf=$('rf');
 if(rf&&rf.setAttribute)rf.setAttribute('stroke-dashoffset',(339.3*(1-Math.max(g.left,0)/(g.total||1))).toFixed(1));
 const hot=g.left<=10&&g.left>0,r=$('ring');if(r&&r.classList)r.classList.toggle('hot',hot);if(document.body.classList)document.body.classList.toggle('hot',hot)}
function startTimer(sec,cb,keep){stopTimer();st.g.left=sec;if(!keep)st.g.total=sec;
 timerId=setInterval(()=>{const g=st.g;g.left--;tickUI();if(g.left<=5&&g.left>0)sfx('tick');if(g.left<=0){stopTimer();sfx('bad');cb()}},1000)}

/* ================= VIEWS ================= */
function hdr(){return `<header><div class="brand">${sun(34)}<span>${t('app')}</span></div><div class="hbtns">${st.screen!=='hub'?`<button class="mini" data-act="hub" aria-label="${t('toHub')}">🏠</button>`:''}<button class="mini" data-act="mus" aria-label="music">${st.music?'🎵':'🔕'}</button><button class="mini" data-act="snd" aria-label="sound">${st.sound?'🔊':'🔇'}</button><button class="mini minilang" data-act="lang" aria-label="${t('lang')}">${flag(curLang().k)}<span>${curLang().n}</span></button></div></header>`}

function vLang(){return `<section class="card center langcard"><div class="logo-pop float">${sun(84)}</div>
 <h1 class="ltitle" lang="ar" dir="rtl">نادي ألعاب جماعية</h1>
 <p class="pick4" dir="ltr">Group Game Club</p><p class="pick4" dir="ltr">Klûba Lîstikên Komî</p>
 <p class="pick4" lang="ckb" dir="rtl">کڵوبی یاریی کۆمەڵایەتی</p>
 <p class="lask" dir="ltr"><span lang="ar" dir="rtl">اختر اللغة</span> · <span lang="ckb" dir="rtl">زمانەکەت هەڵبژێرە</span><br>Choose your language<br>Zimanê xwe hilbijêre</p>
 <div class="langlist" dir="ltr">${langRow(LANGS[0])}<div class="kgroup"><span class="kl" lang="ckb" dir="rtl">کوردی · Kurdî</span>${langRow(LANGS[1])}${langRow(LANGS[2])}</div>${langRow(LANGS[3])}</div></section>`}

function statsBox(){
 const tot=Object.values(stats.games).reduce((a,g)=>a+g.played,0);if(!tot)return '';
 const rows=GAMES.filter(g=>stats.games[g.id]).map(g=>{const s=stats.games[g.id];return `<div class="lrow"><span class="la">${g.ic}</span><span class="ln">${tr(g.n)}</span><b>${s.played} ${t('played')} · ${s.wins} ${t('wonN')}</b></div>`}).join('');
 return `<section class="glass" style="margin-top:14px"><h3>📊 ${t('stats')}</h3>${rows}</section>`}
function vHub(){
 const tiles=GAMES.map((g,gi)=>`<button class="tile" data-act="game" data-v="${g.id}" style="--c:${g.c};animation-delay:${gi*70}ms"><div class="art ${TILEIMG[g.id]?'img tg-'+g.id:''}">${TILEIMG[g.id]?'':art(g.id)}</div><div class="tbar"><span class="badge">${g.id==='spi'?sun(30):g.ic}</span><span class="tn">${tr(g.n)}</span></div><div class="tsub">${tr(g.tg)}</div></button>`).join('');
 const tot=st.pts[0],lv=lvl(tot),xp=(tot%10)*10;
 const langs=`<div class="langpick"><button class="langcur" data-act="langtoggle" aria-haspopup="true" aria-expanded="${!!st.langOpen}" aria-label="${t('lang')}">${flag(curLang().k)}<span>${curLang().n}</span><i aria-hidden="true">▾</i></button>${st.langOpen?`<div class="langmenu" dir="ltr" role="menu">${LANGS.map(L=>langRow(L,L.kd?'kd':'')).join('')}</div>`:''}</div>${st.langOpen?'<button class="langscrim" data-act="langclose" aria-label="close"></button>':''}`;
 const bar=`<div class="topbar"><div class="prof" data-act="profile" role="button" tabindex="0" style="cursor:pointer"><div class="av">${faceP(0,56)}</div><div style="flex:1;min-width:0"><div class="pn"><b>${pname(0)}</b> 👑</div><div class="pl2"><span>Lv. ${lv}</span><span dir="ltr">${tot%10} / 10</span></div><div class="xp"><i style="width:${xp}%"></i></div></div></div><div class="rt">${langs}<button class="gear" data-act="mus" aria-label="music">${st.music?'🎵':'🔕'}</button><button class="gear" data-act="snd" aria-label="sound">${st.sound?'🔊':'🔇'}</button></div></div>`;
 const words=t('app').split(' ');const logo=`<div class="logo logo-pop"><div class="gp float">🎮</div><h1><span class="y">${words[0]}</span> <span class="w">${words.slice(1).join(' ')}</span></h1><div class="tagl">${t('tagline')}</div><div><button class="btn" data-act="rand">🎲 ${t('surprise')}</button>${st.saved?`<button class="btn green" data-act="resume">▶️ ${t('resume')}: ${tr(GAMES.find(x=>x.id===st.saved.game).n)}</button>`:''}</div></div>`;
 const order=[...Array(st.n).keys()].sort((x,y)=>st.pts[y]-st.pts[x]||x-y).slice(0,4);
 const board=`<section class="glass"><h3>👑 ${t('board')}</h3>${order.map((i,r)=>`<div class="lrow"><span class="rk r${r}">${r+1}</span><span class="la">${faceP(i,34)}</span><span class="ln">${pname(i)}</span><b>${st.pts[i]}</b></div>`).join('')}</section>`;
 const promo=`<section class="glass promo"><div class="tro">🏆</div><div class="pt"><h3>${t('incent')}</h3><p>${t('unlockHint')}</p></div><div class="faces">${[7,5,6,2,8,3].map(k=>`<span>${face(k,74)}</span>`).join('')}</div></section>`;
 const foot=`<section class="glass foot"><div><span class="fi">👥</span><div><b>${t('multi1')}</b><small>${t('multi2')}</small></div></div><div><span class="fi">📱</span><div><b>${t('pass1')}</b><small>${t('pass2')}</small></div></div></section>`;
 return `${bar}${logo}<div class="tiles">${tiles}</div>${xHubRow()}<div class="row2">${promo}${board}</div>${foot}${statsBox()}<p class="pick4 center" style="margin-top:16px">${t('honor')}</p><p class="center"><button class="mini" data-act="resetAll">🗑️ ${t('resetAll')}</button></p>`}

function stepMini(k,v){return `<div class="mstep"><button class="step sm" data-act="${k}Dec" aria-label="-">−</button><b>${v}</b><button class="step sm" data-act="${k}Inc" aria-label="+">+</button></div>`}

function vSetup(){
 const G=gameOf();let sets='';
 if(G.id==='spy'){const L=spyList();sets=`<div class="setrow"><span>${L?CATICON[L.n.en]||'📂':'📂'} ${t('category')}: <b>${L?tr(L.n):'—'}</b></span><button class="mini on" data-act="spyCat">${t('change')}</button></div>`}
 if(G.id==='spy'||G.id==='out')sets+=`<div class="setrow"><span>🕵️ ${t('spies')}</span>${stepMini('sp',effSp())}</div><div class="setrow"><span>⏱️ ${t('mins')}</span>${stepMini('mn',effMin())}</div>`;
 if(G.id==='cha')sets=`<div class="setrow"><span>⏱️ ${t('secs')}</span>${stepMini('cs',st.set.cs)}</div>`;
 const rows=ids().map(i=>`<div class="prow"><button class="pav" data-act="skins" data-v="${i}" aria-label="${t('chooseSkin')}">${faceP(i,64)}</button><input class="pin" data-i="${i}" value="${(st.names[i]||'').replace(/"/g,'&quot;')}" placeholder="${tr(NAMES[i])}" maxlength="14"><span class="pts">⭐ ${st.pts[i]}</span></div>`).join('');
 return `<section class="card center" style="background:linear-gradient(165deg,${G.c},#0a1030 140%);color:${G.fg}">${TILEIMG[G.id]?`<div class="hero-art tg-${G.id}"></div>`:`<div class="big">${G.ic}</div>`}<h1>${xTitle(G)}</h1></section>
 <section class="card"><h2>${t('howto')}</h2><p>${tr(G.h)}</p>${G.id==='maf'?`<p><b>${t('needMaf')}</b></p>`:''}</section>
 <section class="card center"><h2>${t('players')}</h2>
  <div class="stepper"><button class="step" data-act="dec" aria-label="-">−</button><span class="num">${st.n}</span><button class="step" data-act="inc" aria-label="+">+</button></div>
  ${sets}<h2 style="margin-top:16px">${t('roster')}</h2>${rows}<p class="pick4">${t('unlockHint')}</p>
  <button class="btn" data-act="start">${t('start')}</button></section>`}

function vSkins(){const p=st.slot;
 const cards=SK.map((k,id)=>{const own=k.cost===0||st.own[p][id],sel=st.skin[p]===id,can=own||st.pts[p]>=k.cost;
  const status=sel?'✓':own?(k.cost===0?t('free'):t('owned')):'🔒 '+k.cost+' ⭐';
  return `<button class="sk ${sel?'sel':''} ${own?'':'lock'}" data-act="pickskin" data-v="${id}" ${can?'':'disabled'}>${face(id,76)}<span>${tr(k.n)}</span><small>${status}</small></button>`}).join('');
 return `<section class="card center"><h2>${t('chooseSkin')}</h2><div class="who">${faceP(p,90)}<b>${pname(p)}</b></div><p><b>${t('pts')}: ⭐ ${st.pts[p]}</b></p><div class="skins">${cards}</div><p class="pick4">${t('unlockHint')}</p><button class="btn" data-act="setup">${t('done')}</button></section>`}

/* --- shared reveal --- */
function revealBody(g,i){
 if(g.kind==='spy'){const c=CATS[g.cat];return g.spies.includes(i)?`<div class="big">🕵️</div><h1 style="color:var(--red)">${t('youSpy')}</h1><p>${t('outHint')}</p><p>${t('category')}: <b>${tr(c.n)}</b></p>`
   :`<p>${t('category')}: <b>${tr(c.n)}</b></p><p>${t('theWord')}</p><div class="name">${tr(c.w[g.w])}</div>`}
 if(g.kind==='out'){const c=CATS[g.cat];return g.spies.includes(i)?`<div class="big">🙊</div><h1 style="color:var(--red)">${t('youOut')}</h1><p>${t('outHint')}</p><p>${t('category')}: <b>${tr(c.n)}</b></p>`
  :`<p>${t('category')}: <b>${tr(c.n)}</b></p><p>${t('theWord')}</p><div class="name">${tr(c.w[g.w])}</div>`}
 const r=g.roles[i];let x=`<div class="big">${ROLES[r].ic}</div><h1>${tr(ROLES[r].n)}</h1><p>${tr(ROLES[r].h)}</p>`;
 if(r==='maf'){const o=ids().filter(k=>g.roles[k]==='maf'&&k!==i);if(o.length)x+=`<p><b>${t('partners')}: ${o.map(pname).join('، ')}</b></p>`}
 return x}
const isDark=(g,i)=>g.kind==='maf'?g.roles[i]==='maf':g.spies.includes(i);
function vReveal(){const g=st.g,i=g.i;
 return `<section class="card center"><p>${t('passTo')}</p><div class="who float">${faceP(i,110,g.shown&&isDark(g,i))}<b style="font-size:2.2rem">${pname(i)}</b></div>
 <div class="flip ${g.shown?'on':''}" id="flip"><div class="fin"><button class="ff" data-act="show"><span class="q">?</span><span>${t('tap')}</span></button><div class="fb">${revealBody(g,i)}</div></div></div>
 <button class="btn" id="hp" data-act="hidepass" ${g.shown?'':'hidden'}>${i===st.n-1?t('startPlay'):t('hide')}</button></section>`}
function vSus(){return `<section class="card center"><div class="sus">🥁</div><h2>${t('counting')}</h2></section>`}
function suspense(next){st.screen='sus';render();sfx('drum');setTimeout(()=>{if(st.screen==='sus')next()},1900)}

/* --- spy/outsider play --- */
function vPlay(){const g=st.g,spy=g.kind==='spy',C=CATS[g.cat];
 const list=spy?`<section class="card"><h2>${t('wordsList')}</h2><div class="locs">${C.w.map((w,k)=>`<button class="loc ${g.crossed[k]?'x':''}" data-act="cross" data-v="${k}">${tr(w)}</button>`).join('')}</div></section>`
  :`<section class="card center"><p>${t('category')}</p><div class="word" style="font-size:2.4rem">${tr(C.n)}</div></section>`;
 return `<section class="card center"><span class="stamp">${t('op')} ${tr(LEADERS[g.op])}</span>${spy?`<p class="pick4" style="margin-top:10px">${CATICON[C.n.en]||'📂'} ${t('category')}: <b>${tr(C.n)}</b></p>`:''}${ring(g)}
  <button class="mini" data-act="pause">${timerId?'⏸ '+t('pause'):'▶ '+t('resume')}</button>
  <div class="starter">${faceP(g.starter,64)}<span>${t('starts')}: <b>${pname(g.starter)}</b></span></div><p class="pick4">${t('askRule')}</p>
  <button class="btn red" data-act="vote">${spy?t('voteSpy'):t('voteOut')}</button><br><button class="btn alt" data-act="guess">${spy?t('guessSpy'):t('guessOut')}</button></section>${list}`}

function grid(list,sel,act,extra){return `<div class="players">${list.map(i=>`<button class="pl ${sel.includes(i)?'sel':''}" data-act="${act}" data-v="${i}">${faceP(i,72)}${pname(i)}${extra?extra(i):''}</button>`).join('')}</div>`}
function vGuess(){const g=st.g,spy=g.kind==='spy';
 const items=CATS[g.cat].w.map((w,k)=>`<button class="loc ${g.gsel===k?'sel':''}" data-act="pickloc" data-v="${k}">${tr(w)}</button>`);
 return `<section class="card center"><span class="big">${spy?'🕵️':'🙊'}</span>${g.last?`<p><b>${t('lastChance')}</b></p>`:''}<p class="pick4">${t('category')}: <b>${tr(CATS[g.cat].n)}</b></p><h2>${t('guessWord')}</h2><div class="locs">${items.join('')}</div><button class="btn" data-act="confirmGuess" ${g.gsel===null?'disabled':''} style="margin-top:14px">${t('confirm')}</button></section>`}

/* --- charades --- */
const teamName=k=>t('team'+k);
function vCIntro(){const g=st.g,a=g.order[g.turn];
 return `<section class="card center"><span class="tag ${a.t}">${teamName(a.t)}</span><p>${t('passTo')}</p><div class="who">${faceP(a.p,120)}<b style="font-size:2.3rem">${pname(a.p)}</b></div>
 <div class="score"><div class="A">${teamName('A')}<b>${g.score.A}</b></div><div class="B">${teamName('B')}<b>${g.score.B}</b></div></div>
 <button class="btn green" data-act="cReady">${t('ready')}</button></section>`}
function vCPlay(){const g=st.g,a=g.order[g.turn];
 return `<section class="card center"><span class="tag ${a.t}">${teamName(a.t)}</span>${ring(g)}<button class="mini" data-act="pause">${timerId?'⏸ '+t('pause'):'▶ '+t('resume')}</button><p>${t('actNow')}</p>
 <div class="word">${tr(ALLWORDS[g.pool[g.wi%g.pool.length]])}</div><p>${t('gotN')}: <b>${g.got}</b></p>
 <button class="btn green" data-act="cOk">${t('correct')}</button><button class="btn alt" data-act="cSkip">${t('skip')}</button></section>`}
function vCRes(){const g=st.g,a=g.order[g.turn],last=g.turn>=g.order.length-1;
 return `<section class="card center"><h2>${t('timeUp2')}</h2><span class="tag ${a.t}">${teamName(a.t)}</span><p>${t('gotN')}: <b>${g.got}</b></p>
 <div class="score"><div class="A">${teamName('A')}<b>${g.score.A}</b></div><div class="B">${teamName('B')}<b>${g.score.B}</b></div></div>
 <button class="btn" data-act="cNext">${last?t('score'):t('next')}</button></section>`}
function vCEnd(){const g=st.g,w=g.score.A===g.score.B?null:(g.score.A>g.score.B?'A':'B');
 const gains=ids().filter(i=>g.gain[i]).map(i=>`<div class="pl">${faceP(i,56)}${pname(i)}<span class="gain">+${g.gain[i]} ⭐</span></div>`).join('');
 return `<section class="card center"><div class="big">${w?'🏆':'🤝'}</div><h1>${w?teamName(w)+' '+t('wins'):t('draw')}</h1>
 <div class="score"><div class="A">${teamName('A')}<b>${g.score.A}</b></div><div class="B">${teamName('B')}<b>${g.score.B}</b></div></div>
 ${gains?`<h2>${t('pts')}</h2><div class="players">${gains}</div>`:''}
 <button class="btn" data-act="again">${t('again')}</button><button class="btn alt" data-act="hub">${t('toHub')}</button></section>`}

/* --- would you rather --- */
function vWyr(){const g=st.g,q=WYR[g.order[g.k%WYR.length]],tot=g.tally[0]+g.tally[1],pc=i=>tot?Math.round(g.tally[i]*100/tot):0;
 const opt=(i,c)=>`<button class="big-opt ${c}" data-act="wv" data-v="${i}"><i class="bar" style="width:${pc(i)}%"></i><span class="cnt">${g.tally[i]}</span><span class="t">${tr(q[i])}</span>${tot?`<span class="pct">${pc(i)}%</span>`:''}</button>`;
 return `<section class="card center"><p class="pick4">${(g.k%WYR.length)+1} / ${WYR.length}</p><h2>${t('wyrQ')}</h2><div class="big-opts">${opt(0,'A')}${opt(1,'B')}</div><button class="btn" data-act="wNext">${t('next')}</button></section><section class="card"><h2>${t('howto')}</h2><p>${tr(gameOf().h)}</p></section>`}

/* --- mafia --- */
function vMNight(){const g=st.g;return `<section class="card center" style="background:linear-gradient(165deg,#7a1010,#0a1030 140%);color:#fff"><div class="big float" style="font-size:5rem;filter:drop-shadow(0 0 24px #ffe9a8)">🌙</div><span class="stamp" style="color:#ffc72c;border-color:#ffc72c">${t('op')} ${tr(LEADERS[g.op])}</span><h1>${t('night')} ${g.night}</h1><p>${t('nightSub')}</p><button class="btn" data-act="mBegin">${t('begin')}</button></section>`}
function vMAct(){const g=st.g,a=g.queue[g.qi],role=g.roles[a];
 if(g.stage==='pass')return `<section class="card center"><p>${t('passTo')}</p><div class="who">${faceP(a,120)}<b style="font-size:2.3rem">${pname(a)}</b></div><button class="tap" data-act="mOpen" style="margin-top:14px">${t('tap')}</button></section>`;
 if(g.stage==='res'){const bad=g.roles[g.pick]==='maf';return `<section class="card center"><div class="who">${faceP(g.pick,100)}<b>${pname(g.pick)}</b></div><h1 style="color:${bad?'var(--red)':'var(--leaf)'}">${bad?t('isMaf'):t('notMaf')}</h1><button class="btn" data-act="mNextActor">${t('hide')}</button></section>`}
 const alive=g.alive;let opts,title;
 if(role==='maf'){opts=alive.filter(i=>g.roles[i]!=='maf');title=t('chVic')}
 else if(role==='doc'){opts=alive;title=t('chSave')}
 else{opts=alive.filter(i=>i!==a);title=t('chCheck')}
 return `<section class="card center"><div class="who">${faceP(a,72,role==='maf')}<b>${ROLES[role].ic} ${tr(ROLES[role].n)}</b></div><h2>${title}</h2>${grid(opts,g.pick===null?[]:[g.pick],'mPick')}<button class="btn" data-act="mConfirm" ${g.pick===null?'disabled':''}>${t('confirm')}</button></section>`}
function vMMorn(){const g=st.g;return `<section class="card center"><div class="big float" style="font-size:5rem">☀️</div><h1>${t('morning')}</h1>${g.dead===null?`<h2>${t('noDeath')}</h2>`:`<h2>${t('died')}</h2><div class="who">${faceP(g.dead,100)}<b>${pname(g.dead)}</b></div>`}<button class="btn" data-act="mToDay">${t('next')}</button></section>`}
function vMDay(){const g=st.g;return `<section class="card center"><h2>${t('dayVote')}</h2>${grid(g.alive,g.pick===null||g.pick===-1?[]:[g.pick],'mPick')}<button class="btn alt" data-act="mNobody">${t('nobody')}</button><button class="btn" data-act="mDayOk" ${g.pick===null?'disabled':''}>${t('confirm')}</button></section>`}
function vMDayRes(){const g=st.g;if(g.out===null)return `<section class="card center"><h2>${t('nobody')}</h2><button class="btn" data-act="mAfterDay">${t('next')}</button></section>`;
 const r=g.roles[g.out];return `<section class="card center"><div class="who">${faceP(g.out,110,r==='maf')}<b>${pname(g.out)}</b></div><p>${t('outed')}</p><div class="secret"><p>${t('was')}</p><div class="name">${ROLES[r].ic} ${tr(ROLES[r].n)}</div></div><button class="btn" data-act="mAfterDay">${t('next')}</button></section>`}

/* --- end (spy/outsider/mafia) --- */
function vEnd(){const g=st.g,win=g.result.cit;
 let reveal='';
 if(g.kind==='spy')reveal=`<div class="secret"><p>${tr(CATS[g.cat].n)}</p><div class="name">${tr(CATS[g.cat].w[g.w])}</div></div><h2>${t('spyList')}</h2><div class="players" style="max-width:260px;margin-inline:auto">${g.spies.map(i=>`<div class="pl spy">${faceP(i,72,true)}${pname(i)}</div>`).join('')}</div>`;
 if(g.kind==='out')reveal=`<div class="secret"><p>${tr(CATS[g.cat].n)}</p><div class="name">${tr(CATS[g.cat].w[g.w])}</div></div><h2>${t('outList')}</h2><div class="players" style="max-width:260px;margin-inline:auto">${g.spies.map(i=>`<div class="pl spy">${faceP(i,72,true)}${pname(i)}</div>`).join('')}</div>`;
 if((g.kind==='spy'||g.kind==='out')&&g.vcnt)reveal+=votesBlock(g);
  if(g.kind==='maf')reveal=`<h2>${t('roles')}</h2><div class="players">${ids().map(i=>`<div class="pl ${g.roles[i]==='maf'?'spy':''}">${faceP(i,64,g.roles[i]==='maf')}${pname(i)}<small>${ROLES[g.roles[i]].ic} ${tr(ROLES[g.roles[i]].n)}</small></div>`).join('')}</div>`;
 const title=win?t('citWin'):g.kind==='out'?t('outWin'):g.kind==='maf'?t('mafWin'):t('spyWin');
 const gains=ids().filter(i=>g.gain[i]).map(i=>`<div class="pl">${faceP(i,56)}${pname(i)}<span class="gain">+${g.gain[i]} ⭐</span></div>`).join('');
 return `<section class="card center"><span class="stamp">${t('secret')}</span><div class="big" style="margin-top:12px">${win?'🏆':g.kind==='maf'?'🔪':g.kind==='out'?'🙊':'🕵️'}</div><h1>${title}</h1>${g.result.why?`<p>${t(g.result.why)}</p>`:''}${reveal}
 ${gains?`<h2>${t('pts')}</h2><div class="players">${gains}</div>`:''}<button class="btn" data-act="again">${t('again')}</button><button class="btn alt" data-act="hub">${t('toHub')}</button></section>`}


/* --- Kurdish Spirit quiz --- */
function podium(order,get){return `<div class="pod">${[1,0,2].filter(k=>order[k]!==undefined).map(k=>{const i=order[k];return `<div class="p${k+1}">${faceP(i,72)}<b>${pname(i)}</b><div class="col">${get(i)}</div></div>`}).join('')}</div>`}
function vQPlay(){const g=st.g,q=g.qs[g.k],p=g.k%st.n,done=g.ans!==null;
 const opts=q.o.map(x=>{let c='loc';if(done){if(x===String(q.a))c+=' good';else if(x===g.ans)c+=' bad'}return `<button class="${c}" data-act="qPick" data-v="${x}" ${done?'disabled':''} style="font-size:1.15rem;padding:12px">${qLabel(q,x)}</button>`}).join('');
 const ok=done&&g.ans===String(q.a);
 return `<section class="card center ${done&&!ok?'shake':''}"><p class="pick4">${g.k+1} / ${g.qs.length}</p><div class="starter">${faceP(p,72)}<span>${t('qTurn')}: <b>${pname(p)}</b> · ⭐ ${g.score[p]}${g.streak[p]>1?' · 🔥'+g.streak[p]:''}</span></div>
 ${done?'':ring(g)}<h2 style="margin-top:10px">${tr(q.q)}</h2><div class="opts3">${opts}</div>
 ${done?`<h2 style="color:${ok?'#6dffa8':'#ff8a8a'}">${ok?t('qRight'):t('qWrong')}</h2>${g.bonus?`<p><b>${t('streak')}</b></p>`:''}<button class="btn" data-act="qNext">${g.k>=g.qs.length-1?t('score'):t('next')}</button>`:''}</section>`}
function vQEnd(){const g=st.g,order=ids().sort((x,y)=>g.score[y]-g.score[x]||x-y);
 return `<section class="card center"><div class="big">🏆</div><h1>${pname(order[0])} ${t('wins')}</h1>${podium(order.slice(0,3),i=>g.score[i])}
 <div class="players">${order.slice(3).map(i=>`<div class="pl">${faceP(i,56)}${pname(i)}<b>⭐ ${g.score[i]}</b></div>`).join('')}</div>
 ${order.some(i=>g.gain[i])?`<p class="gain">${order.filter(i=>g.gain[i]).map(i=>pname(i)+' +'+g.gain[i]+' ⭐').join(' · ')}</p>`:''}
 <button class="btn" data-act="again">${t('again')}</button><button class="btn alt" data-act="hub">${t('toHub')}</button></section>`}
function qAnswer(sv){const g=st.g;if(g.ans!==null)return;stopTimer();const q=g.qs[g.k],p=g.k%st.n;g.ans=sv;g.bonus=false;
 if(sv===String(q.a)){g.score[p]++;g.streak[p]++;if(g.streak[p]%3===0){g.score[p]++;g.bonus=true}sfx('ok')}else{g.streak[p]=0;sfx('bad')}
 if(document.body.classList)document.body.classList.remove('hot');render(false)}
function qStart(){const g=st.g;g.ans=null;g.bonus=false;g.left=15;g.total=15;render();startTimer(15,()=>qAnswer('__'),true)}
function newSpi(){st.g={kind:'spi',qs:qPool().map(q=>({...q,o:qOpts(q)})),k:0,ans:null,score:Array(st.n).fill(0),streak:Array(st.n).fill(0),gain:{},bonus:false,left:15,total:15};st.screen='qPlay';render();startTimer(15,()=>qAnswer('__'),true)}
function qFinish(){const g=st.g,mx=Math.max(...g.score);g.gain={};if(mx>0)ids().forEach(i=>{if(g.score[i]===mx){g.gain[i]=2;addPts(i,2)}});recordGame('spi',Object.keys(g.gain).map(Number));st.screen='qEnd';render()}

/* ================= FLOW ================= */
function render(anim=true){
 document.documentElement.dir=st.lang?META[st.lang].dir:'ltr';
 document.documentElement.lang=st.lang?META[st.lang].code:'en';
 document.body.dataset.lang=st.lang||'';
 if(!['play','cPlay','qPlay'].includes(st.screen))stopTimer();
 {const b=document.body;if(b.classList){b.classList.toggle('nightmode',['mNight','mAct'].includes(st.screen));b.classList.toggle('dawn',st.screen==='mMorn');if(!['play','cPlay','qPlay'].includes(st.screen))b.classList.remove('hot')}}
 const V={hub:vHub,setup:vSetup,skins:vSkins,reveal:vReveal,play:vPlay,guess:vGuess,end:vEnd,cIntro:vCIntro,cPlay:vCPlay,cRes:vCRes,cEnd:vCEnd,wyr:vWyr,mNight:vMNight,mAct:vMAct,mMorn:vMMorn,mDay:vMDay,mDayRes:vMDayRes,qPlay:vQPlay,qEnd:vQEnd,sus:vSus,...XV};
 $('app').innerHTML=`<div class="screen ${anim?'anim':''}">${st.screen==='hub'?vHub():`<div class="narrow">${st.screen==='lang'?vLang():hdr()+V[st.screen]()}</div>`}</div>`;
 if(anim)window.scrollTo(0,0);
 if(anim&&['end','cEnd','qEnd','tEnd','dqEnd'].includes(st.screen)){confetti();sfx('win')}
 syncMusic();save();
 if(window.kgcAfterRender)kgcAfterRender();
}
const partial=()=>{const y=window.scrollY;render(false);window.scrollTo(0,y)};

const lvl=p=>1+Math.floor(p/10);
function toast(m){try{const e=document.createElement('div');e.className='toast';e.textContent=m;document.body.appendChild(e);setTimeout(()=>e.remove(),3300)}catch(x){}}
function addPts(i,n){const a=st.pts[i];st.pts[i]+=n;const b=st.pts[i];
 if(lvl(b)>lvl(a))toast('🎉 '+pname(i)+' · '+t('lvUp')+' '+lvl(b));
 else if(SK.some((k,id)=>k.cost>0&&!st.own[i][id]&&a<k.cost&&b>=k.cost))toast('🔓 '+pname(i)+' · '+t('skinReady'))}
function award(fn,amt){const g=st.g;g.gain={};ids().forEach(i=>{const a=fn(i);if(a){g.gain[i]=a;addPts(i,a)}})}
function newSpyRound(){const k=st.game,sp=effSp(),o=shuffle(ids());
 const g={kind:k,spies:o.slice(0,sp),starter:rnd(st.n),i:0,shown:false,crossed:{},left:effMin()*60,total:effMin()*60,sel:[],gsel:null,result:null,timeup:false,last:false,gain:{},op:rnd(LEADERS.length)};
 if(k==='spy'){const L=spyList();g.cat=CATS.indexOf(L);g.w=rnd(L.w.length)}else{g.cat=rnd(CATS.length);g.w=rnd(CATS[g.cat].w.length)}
 st.g=g;st.screen='reveal';render()}
function endPlay(){st.g.timeup=true;startVote()}
function finishSO(cit,why){const g=st.g;g.result={cit,why};award(i=>{const s=g.spies.includes(i);return cit?(s?0:1):(s?3:0)});recordGame(g.kind,Object.keys(g.gain).map(Number));st.screen='end';render()}

function newCha(){const o=shuffle(ids()),A=[],B=[];o.forEach((p,k)=>(k%2?B:A).push(p));
 const order=[];for(let k=0;k<Math.max(A.length,B.length);k++){if(A[k]!==undefined)order.push({p:A[k],t:'A'});if(B[k]!==undefined)order.push({p:B[k],t:'B'})}
 st.g={kind:'cha',A,B,order,turn:0,score:{A:0,B:0},pool:shuffle(ALLWORDS.map((_,i)=>i)),wi:0,left:st.set.cs,got:0,gain:{}};st.screen='cIntro';render()}
function cTimeUp(){st.screen='cRes';render()}
function cFinish(){const g=st.g,w=g.score.A===g.score.B?null:(g.score.A>g.score.B?'A':'B');
 g.gain={};if(w)(w==='A'?g.A:g.B).forEach(p=>{g.gain[p]=1;addPts(p,1)});recordGame('cha',Object.keys(g.gain).map(Number));st.screen='cEnd';render()}

function newWyr(){st.saved=null;recordGame('wyr',[]);st.g={kind:'wyr',order:shuffle(WYR.map((_,i)=>i)),k:0,tally:[0,0]};st.screen='wyr';render()}

function newMaf(){const n=st.n,m=n<=6?1:n<=9?2:3,o=shuffle(ids()),roles=Array(n).fill('cit');
 o.slice(0,m).forEach(i=>roles[i]='maf');roles[o[m]]='doc';roles[o[m+1]]='det';
 st.g={kind:'maf',op:rnd(LEADERS.length),roles,alive:ids(),night:1,i:0,shown:false,gain:{},result:null,starter:0};st.screen='reveal';render()}
function mWin(){const g=st.g,m=g.alive.filter(i=>g.roles[i]==='maf').length,o=g.alive.length-m;return m===0?'cit':m>=o?'maf':null}
function mFinish(w){const g=st.g;g.result={cit:w==='cit',why:null};award(i=>{const isM=g.roles[i]==='maf';return (w==='maf')===isM?2:0});recordGame('maf',Object.keys(g.gain).map(Number));st.screen='end';render()}
function mResolve(){const g=st.g;let v=null;
 if(g.votes.length){const c={};g.votes.forEach(x=>c[x]=(c[x]||0)+1);const mx=Math.max(...Object.values(c));v=+shuffle(Object.keys(c).filter(k=>c[k]===mx))[0]}
 g.dead=(v!==null&&v!==g.save)?v:null;if(g.dead!==null)g.alive=g.alive.filter(x=>x!==g.dead);
 st.screen='mMorn';render()}

function startGame(){st.saved=null;if(st.game==='spy'&&!spyList()){st.screen='spyCat';render();return}({spy:newSpyRound,out:newSpyRound,cha:newCha,wyr:newWyr,maf:newMaf,spi:newSpi})[st.game]()}

addEventListener('keydown',e=>{if(e.key==='Escape'&&st.langOpen){st.langOpen=false;partial()}});
$('app').addEventListener('click',e=>{
 const b=e.target.closest('[data-act]');if(!b||b.disabled)return;
 const a=b.dataset.act,sv=b.dataset.v,v=+sv,g=st.g;
 switch(a){
 case 'setlang':st.lang=sv;st.langOpen=false;{const to=st.back||'hub';st.back=null;st.screen=to;render();if(timerEnd[to]&&st.g&&!(to==='qPlay'&&st.g.ans!==null))startTimer(st.g.left,timerEnd[to],true)}break;
 case 'langtoggle':st.langOpen=!st.langOpen;partial();break;
  case 'langclose':st.langOpen=false;partial();break;
  case 'lang':st.langOpen=false;st.back=st.screen;st.screen='lang';render();break;
 case 'hub':st.screen='hub';st.customPack=null;st.skinBack=null;render();break;
 case 'resume':resumeGame();break;
 case 'resetAll':if(confirm(t('resetSure'))){try{localStorage.removeItem(KEY)}catch(e){}location.reload()}break;
 case 'qPick':qAnswer(sv);break;
 case 'qNext':if(g.k>=g.qs.length-1)qFinish();else{g.k++;qStart()}break;
 case 'mus':st.music=!st.music;partial();break;
 case 'snd':st.sound=!st.sound;partial();break;
 case 'pause':if(timerId){stopTimer()}else{startTimer(g.left,timerEnd[st.screen],true)}partial();break;
 case 'game':st.customPack=null;st.skinBack=null;if(sv==='wyr'){st.game='wyr';newWyr()}else{st.game=sv;st.n=Math.max(st.n,gameOf().min);st.screen=sv==='spy'?'spyCat':'setup';render()}break;
 case 'rand':{st.customPack=null;const gm=GAMES[rnd(GAMES.length)];st.skinBack=null;if(gm.id==='wyr'){st.game='wyr';newWyr()}else{st.game=gm.id;st.n=Math.max(st.n,gameOf().min);st.screen=gm.id==='spy'?'spyCat':'setup';render()}}break;
 case 'setup':st.screen=st.skinBack||'setup';render();break;
 case 'inc':st.n=Math.min(12,st.n+1);partial();break;
 case 'dec':st.n=Math.max(gameOf().min,st.n-1);partial();break;
 case 'spInc':st.set.sp=Math.min(maxSp(),effSp()+1);partial();break;
 case 'spDec':st.set.sp=Math.max(1,effSp()-1);partial();break;
 case 'mnInc':st.set.mn=Math.min(15,effMin()+1);partial();break;
 case 'mnDec':st.set.mn=Math.max(1,effMin()-1);partial();break;
 case 'csInc':st.set.cs=Math.min(120,st.set.cs+15);partial();break;
 case 'csDec':st.set.cs=Math.max(15,st.set.cs-15);partial();break;
 case 'skins':st.slot=v;st.screen='skins';render();break;
 case 'pickskin':{const p=st.slot,k=SK[v];if(k.cost>0&&!st.own[p][v]){st.pts[p]-=k.cost;st.own[p][v]=true}st.skin[p]=v;if(p===0&&st.me)st.me.usePhoto=false;partial()}break;
 case 'start':case 'again':startGame();break;
 case 'show':g.shown=true;sfx('flip');{const f=$('flip');if(f&&f.classList)f.classList.add('on');const h=$('hp');if(h)h.hidden=false}break;
 case 'hidepass':g.shown=false;if(g.i>=st.n-1){if(g.kind==='maf'){st.screen='mNight';render()}else{st.screen='play';render();startTimer(g.left,timerEnd.play)}}else{g.i++;render()}break;
 case 'cross':g.crossed[v]=!g.crossed[v];partial();break;
 case 'vote':stopTimer();startVote();break;
 case 'guess':stopTimer();g.gsel=null;g.last=false;st.screen='guess';render();break;
 case 'pickloc':g.gsel=v;partial();break;
 case 'confirmGuess':{const ok=g.gsel===g.w;
  suspense(()=>{if(g.kind==='spy')finishSO(!ok,ok?'gRight':'gWrong');else finishSO(!ok,ok?'oRight':'oWrong')})}break;
 /* charades */
 case 'cReady':g.got=0;g.left=st.set.cs;g.total=st.set.cs;st.screen='cPlay';render();startTimer(st.set.cs,timerEnd.cPlay);break;
 case 'cOk':g.score[g.order[g.turn].t]++;g.got++;g.wi++;sfx('ok');render(false);break;
 case 'cSkip':g.wi++;render(false);break;
 case 'cNext':if(g.turn>=g.order.length-1)cFinish();else{g.turn++;st.screen='cIntro';render()}break;
 /* wyr */
 case 'wv':g.tally[v]++;sfx('tick');partial();break;
 case 'wNext':g.k++;g.tally=[0,0];if(g.k%WYR.length===0)g.order=shuffle(g.order);render();break;
 /* mafia */
 case 'mBegin':g.queue=[...g.alive.filter(i=>g.roles[i]==='maf'),...g.alive.filter(i=>g.roles[i]==='doc'),...g.alive.filter(i=>g.roles[i]==='det')];
  g.qi=0;g.stage='pass';g.pick=null;g.votes=[];g.save=null;g.dead=null;if(!g.queue.length)mResolve();else{st.screen='mAct';render()}break;
 case 'mOpen':g.stage='act';g.pick=null;render(false);break;
 case 'mPick':g.pick=v;partial();break;
 case 'mConfirm':{const role=g.roles[g.queue[g.qi]];
  if(role==='maf'){g.votes.push(g.pick);mNext()}else if(role==='doc'){g.save=g.pick;mNext()}else{g.stage='res';render(false)}}break;
 case 'mNextActor':mNext();break;
 case 'mToDay':{const w=mWin();if(w)mFinish(w);else{g.pick=null;st.screen='mDay';render()}}break;
 case 'mNobody':g.pick=-1;partial();break;
 case 'mDayOk':{const pk=g.pick;suspense(()=>{g.out=pk===-1?null:pk;if(g.out!==null)g.alive=g.alive.filter(x=>x!==g.out);st.screen='mDayRes';render()})}break;
 case 'mAfterDay':{const w=mWin();if(w)mFinish(w);else{g.night++;st.screen='mNight';render()}}break;
 default:xClick(a,sv,v,g)
}
});
function mNext(){const g=st.g;g.qi++;if(g.qi>=g.queue.length)mResolve();else{g.stage='pass';g.pick=null;render()}}
(function(){const f=document.createElement('div');f.id='fx';document.body.appendChild(f);
 for(let i=0;i<20;i++){const e=document.createElement('span');e.className='ember';const z=4+rnd(9);e.style.cssText='left:'+rnd(100)+'vw;width:'+z+'px;height:'+z+'px;animation-duration:'+(9+rnd(12))+'s;animation-delay:-'+rnd(18)+'s';document.body.appendChild(e)}})();
$('app').addEventListener('pointermove',e=>{const t=e.target.closest&&e.target.closest('.tile');if(!t)return;const r=t.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
 t.style.transform='perspective(700px) rotateY('+(x*14)+'deg) rotateX('+(-y*14)+'deg) translateY(-4px)'});
$('app').addEventListener('pointerout',e=>{const t=e.target.closest&&e.target.closest('.tile');if(t&&!t.contains(e.relatedTarget))t.style.transform=''});
$('app').addEventListener('input',e=>{const i=e.target.dataset&&e.target.dataset.i;if(i!==undefined&&e.target.classList.contains('pin'))st.names[+i]=e.target.value});

