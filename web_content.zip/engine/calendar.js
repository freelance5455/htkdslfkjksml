/* ============================================================
   PENGGILAS

   RESPONSIBILITY
   ------------------------------------------------------------
   04.1 Calendar Convention
   04.2 Calendar System
   04.3 Solar Calendar Date
   04.4 Lunar Calendar Date
   04.5 Calendar Conversion Status

   EXTERNAL LOCAL LIBRARY
   ------------------------------------------------------------
   lunar-javascript / lunar.js

   USE
   ------------------------------------------------------------
   Solar Date
        ↓
   lunar-javascript
        ↓
   Chinese Lunar Date

   IMPORTANT
   ------------------------------------------------------------
   This engine does NOT calculate:

   - Solar Time
   - Meridian Correction
   - Equation of Time
   - True Solar Time
   - Jie Qi
   - Solar Month
   - Four Pillars
   - Interpretation

   ============================================================ */


window.PenggilasCalendar = {

    VERSION: "V2.0",

    STATUS: "READY",

    METHODOLOGY:
        "Classical Zi Ping",


    /* ========================================================
       MAIN ENGINE
       ======================================================== */

    calculate(input) {

        validateCalendarInput(
            input
        );


        /* ====================================================
           04.1 CALENDAR CONVENTION
           ==================================================== */

        const calendarConvention =
            "Classical Zi Ping";


        /* ====================================================
           04.2 CALENDAR SYSTEM
           ==================================================== */

        const calendarSystem = {

            solar:
                "Gregorian Solar Calendar",

            lunar:
                "Chinese Lunar Calendar"

        };


        /* ====================================================
           04.3 SOLAR CALENDAR DATE
           ==================================================== */

        const solarDate =
            buildSolarDate(
                input
            );


        /* ====================================================
           04.4 LUNAR CALENDAR DATE
           ==================================================== */

        const lunarResult =
            convertSolarToLunar(
                input
            );


        /* ====================================================
           04.5 CONVERSION STATUS
           ==================================================== */

        let conversionStatus =
            "UNRESOLVED";


        if (
            lunarResult.status ===
            "RESOLVED"
        ) {

            conversionStatus =
                "VERIFIED";

        }


        /* ====================================================
           ENGINE STATUS
           ==================================================== */

        const engineStatus =
            conversionStatus ===
            "VERIFIED"

                ? "COMPLETE"

                : "PARTIAL";


        /* ====================================================
           FINAL RESULT
           ==================================================== */

        return {

            engine: {

                name:
                    "PENGGILAS CALENDAR ENGINE",

                version:
                    this.VERSION,

                status:
                    engineStatus,

                calculationMode:
                    "LOCAL / OFFLINE"

            },


            configuration: {

                calendarConvention:
                    calendarConvention,

                methodology:
                    this.METHODOLOGY

            },


            calendarSystem:
                calendarSystem,


            solarCalendar: {

                date:
                    solarDate,

                epistemicStatus:
                    "DERIVED"

            },


            lunarCalendar: {

                date:
                    lunarResult.date,

                epistemicStatus:
                    lunarResult.status ===
                    "RESOLVED"

                        ? "DERIVED"

                        : "UNRESOLVED"

            },


            conversion: {

                direction:
                    "SOLAR_TO_LUNAR",

                status:
                    conversionStatus,

                method:
                    lunarResult.method,

                note:
                    lunarResult.note

            }

        };

    }

};


/* ============================================================
   INPUT VALIDATION
   ============================================================ */

function validateCalendarInput(
    input
) {

    if (
        !input ||
        typeof input !== "object"
    ) {

        throw new Error(
            "Calendar Engine input is required."
        );

    }


    const requiredFields = [

        "year",
        "month",
        "day"

    ];


    for (
        const field of requiredFields
    ) {

        if (
            input[field] ===
            null ||

            input[field] ===
            undefined ||

            input[field] === ""
        ) {

            throw new Error(
                `Calendar Engine input missing: ${field}`
            );

        }


        if (
            !Number.isFinite(
                Number(input[field])
            )
        ) {

            throw new Error(
                `Calendar Engine input invalid: ${field}`
            );

        }

    }

}


/* ============================================================
   SOLAR DATE
   ============================================================ */

function buildSolarDate(
    input
) {

    const year =
        Number(input.year);

    const month =
        Number(input.month);

    const day =
        Number(input.day);


    return {

        year:
            year,

        month:
            month,

        day:
            day,

        isoDate:
            [
                String(year)
                    .padStart(4, "0"),

                String(month)
                    .padStart(2, "0"),

                String(day)
                    .padStart(2, "0")

            ].join("-")

    };

}


/* ============================================================
   SOLAR → CHINESE LUNAR

   Uses local lunar-javascript library.

   Official API:
       Solar.fromYmd(...)
       solar.getLunar()
   ============================================================ */

function convertSolarToLunar(
    input
) {

    try {


        /* ====================================================
           CHECK LIBRARY
           ==================================================== */

        if (
            typeof Solar ===
            "undefined"
        ) {

            return {

                status:
                    "UNRESOLVED",

                date:
                    null,

                method:
                    "lunar-javascript / lunar.js",

                note:
                    "Solar library is not loaded."

            };

        }


        /* ====================================================
           CREATE SOLAR OBJECT
           ==================================================== */

        const solar =
            Solar.fromYmd(

                Number(
                    input.year
                ),

                Number(
                    input.month
                ),

                Number(
                    input.day
                )

            );


        /* ====================================================
           SOLAR → LUNAR
           ==================================================== */

        const lunar =
            solar.getLunar();


        if (!lunar) {

            return {

                status:
                    "UNRESOLVED",

                date:
                    null,

                method:
                    "lunar-javascript / lunar.js",

                note:
                    "Library returned no lunar object."

            };

        }


        /* ====================================================
           READ LUNAR DATA
           ==================================================== */

        const lunarYear =
            lunar.getYear();


        const lunarMonth =
            lunar.getMonth();


        const lunarDay =
            lunar.getDay();


        /*
         * Lunar month in the library is normally represented
         * numerically. Leap-month state is obtained separately.
         */

        let isLeapMonth =
            false;


        if (
            typeof lunar.isLeap ===
            "function"
        ) {

            isLeapMonth =
                lunar.isLeap();

        }


        /* ====================================================
           BASIC VALIDATION
           ==================================================== */

        if (
            !Number.isFinite(
                Number(lunarYear)
            ) ||

            !Number.isFinite(
                Number(lunarMonth)
            ) ||

            !Number.isFinite(
                Number(lunarDay)
            )
        ) {

            return {

                status:
                    "UNRESOLVED",

                date:
                    null,

                method:
                    "lunar-javascript / lunar.js",

                note:
                    "Lunar conversion returned incomplete data."

            };

        }


        /* ====================================================
           RESULT
           ==================================================== */

        return {

            status:
                "RESOLVED",

            date: {

                lunarYear:
                    Number(
                        lunarYear
                    ),

                lunarMonth:
                    Number(
                        lunarMonth
                    ),

                lunarDay:
                    Number(
                        lunarDay
                    ),

                isLeapMonth:
                    Boolean(
                        isLeapMonth
                    )

            },

            method:
                "lunar-javascript / lunar.js",

            note:
                "Solar-to-Chinese-lunar conversion performed locally."

        };

    }

    catch (error) {

        console.error(
            "PENGGILAS CALENDAR ERROR:",
            error
        );


        return {

            status:
                "UNRESOLVED",

            date:
                null,

            method:
                "lunar-javascript / lunar.js",

            note:
                error.message

        };

    }

}