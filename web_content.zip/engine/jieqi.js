/*
============================================================
PENGGILAS
LAYER 1 — ENGINE 05
JIE QI ENGINE
============================================================

RESPONSIBILITY
------------------------------------------------------------
05.1 Previous Jie Qi
05.2 Current Zhong Qi
05.3 Next Jie Qi
05.4 Solar Month
05.5 Solar Month Boundary

ENGINE 05 DOES NOT CALCULATE:
------------------------------------------------------------
- Four Pillars
- Year Pillar
- Month Gan
- Month Zhi
- Month Gan-Zhi
- Day Master
- Ten Gods
- Da Yun
- Interpretation

SOURCE
------------------------------------------------------------
LOCAL lunar-javascript / lunar.js

PRIMARY API
------------------------------------------------------------
Solar.fromYmdHms()
Solar.getLunar()
Lunar.getJieQiTable()
Lunar.getJieQiList()

IMPORTANT
------------------------------------------------------------
Jie Qi sequence is explicitly defined here.

JIE:
立春  惊蛰  清明  立夏  芒种  小暑
立秋  白露  寒露  立冬  大雪  小寒

ZHONG_QI:
雨水  春分  谷雨  小满  夏至  大暑
处暑  秋分  霜降  小雪  冬至  大寒

Solar Month is bounded by JIE events.
============================================================
*/

(function (root) {

    "use strict";

    /*
    ========================================================
    ENGINE METADATA
    ========================================================
    */

    const VERSION = "V2.0";

    const METHODOLOGY = "Classical Zi Ping";

    const ENGINE_NAME = "PENGGILAS JIE QI ENGINE";


    /*
    ========================================================
    01 — JIE QI MASTER SEQUENCE
    ========================================================
    */

    const JIE_QI_SEQUENCE = [

        {
            name: "立春",
            pinyin: "Li Chun",
            type: "JIE",
            solarMonthIndex: 0,
            solarMonthNumber: 1
        },

        {
            name: "雨水",
            pinyin: "Yu Shui",
            type: "ZHONG_QI"
        },

        {
            name: "惊蛰",
            pinyin: "Jing Zhe",
            type: "JIE",
            solarMonthIndex: 1,
            solarMonthNumber: 2
        },

        {
            name: "春分",
            pinyin: "Chun Fen",
            type: "ZHONG_QI"
        },

        {
            name: "清明",
            pinyin: "Qing Ming",
            type: "JIE",
            solarMonthIndex: 2,
            solarMonthNumber: 3
        },

        {
            name: "谷雨",
            pinyin: "Gu Yu",
            type: "ZHONG_QI"
        },

        {
            name: "立夏",
            pinyin: "Li Xia",
            type: "JIE",
            solarMonthIndex: 3,
            solarMonthNumber: 4
        },

        {
            name: "小满",
            pinyin: "Xiao Man",
            type: "ZHONG_QI"
        },

        {
            name: "芒种",
            pinyin: "Mang Zhong",
            type: "JIE",
            solarMonthIndex: 4,
            solarMonthNumber: 5
        },

        {
            name: "夏至",
            pinyin: "Xia Zhi",
            type: "ZHONG_QI"
        },

        {
            name: "小暑",
            pinyin: "Xiao Shu",
            type: "JIE",
            solarMonthIndex: 5,
            solarMonthNumber: 6
        },

        {
            name: "大暑",
            pinyin: "Da Shu",
            type: "ZHONG_QI"
        },

        {
            name: "立秋",
            pinyin: "Li Qiu",
            type: "JIE",
            solarMonthIndex: 6,
            solarMonthNumber: 7
        },

        {
            name: "处暑",
            pinyin: "Chu Shu",
            type: "ZHONG_QI"
        },

        {
            name: "白露",
            pinyin: "Bai Lu",
            type: "JIE",
            solarMonthIndex: 7,
            solarMonthNumber: 8
        },

        {
            name: "秋分",
            pinyin: "Qiu Fen",
            type: "ZHONG_QI"
        },

        {
            name: "寒露",
            pinyin: "Han Lu",
            type: "JIE",
            solarMonthIndex: 8,
            solarMonthNumber: 9
        },

        {
            name: "霜降",
            pinyin: "Shuang Jiang",
            type: "ZHONG_QI"
        },

        {
            name: "立冬",
            pinyin: "Li Dong",
            type: "JIE",
            solarMonthIndex: 9,
            solarMonthNumber: 10
        },

        {
            name: "小雪",
            pinyin: "Xiao Xue",
            type: "ZHONG_QI"
        },

        {
            name: "大雪",
            pinyin: "Da Xue",
            type: "JIE",
            solarMonthIndex: 10,
            solarMonthNumber: 11
        },

        {
            name: "冬至",
            pinyin: "Dong Zhi",
            type: "ZHONG_QI"
        },

        {
            name: "小寒",
            pinyin: "Xiao Han",
            type: "JIE",
            solarMonthIndex: 11,
            solarMonthNumber: 12
        },

        {
            name: "大寒",
            pinyin: "Da Han",
            type: "ZHONG_QI"
        }

    ];


    /*
    ========================================================
    02 — FAST LOOKUP MAP
    ========================================================
    */

    const JIE_QI_META = {};

    JIE_QI_SEQUENCE.forEach(function (item) {

        JIE_QI_META[item.name] = item;

    });


    /*
    ========================================================
    03 — VALIDATION
    ========================================================
    */

function validateInput(input) {

    if (!input) {

        throw new Error(
            "Jie Qi Engine: input is required."
        );

    }


    const year =
        Number(input.year);

    const month =
        Number(input.month);

    const day =
        Number(input.day);

    const hour =
        Number(input.hour);

    const minute =
        Number(input.minute);

    const second =
        input.second !== undefined ? Number(input.second) : 0;


    if (
        !Number.isInteger(year) ||
        !Number.isInteger(month) ||
        !Number.isInteger(day) ||
        !Number.isInteger(hour) ||
        !Number.isInteger(minute) ||
        !Number.isInteger(second)
    ) {

        throw new Error(
            "Jie Qi Engine: invalid date/time input."
        );

    }


    if (
        month < 1 ||
        month > 12 ||
        day < 1 ||
        day > 31 ||
        hour < 0 ||
        hour > 23 ||
        minute < 0 ||
        minute > 59 ||
        second < 0 ||
        second > 59
    ) {

        throw new Error(
            "Jie Qi Engine: date/time value out of range."
        );

    }


    return {

        year: year,

        month: month,

        day: day,

        hour: hour,

        minute: minute,

        second:
            input.second !== undefined
                ? Number(input.second)
                : 0

    };

}


    /*
    ========================================================
    04 — LOCAL LIBRARY CHECK
    ========================================================
    */

    function resolveSolarClass() {

        if (
            typeof root.Solar !== "undefined"
        ) {

            return root.Solar;

        }


        if (
            typeof Solar !== "undefined"
        ) {

            return Solar;

        }


        throw new Error(
            "Jie Qi Engine: lunar.js Solar class is not available."
        );

    }


    /*
    ========================================================
    05 — CREATE SOLAR OBJECT
    ========================================================
    */

    function createSolar(input) {

        const SolarClass =
            resolveSolarClass();


        return SolarClass.fromYmdHms(

            input.year,
            input.month,
            input.day,
            input.hour,
            input.minute,
            0

        );

    }


    /*
    ========================================================
    06 — CONVERT LIBRARY SOLAR OBJECT
        INTO INTERNAL DATETIME RECORD
    ========================================================
    */

    function normalizeSolar(
        solar,
        name,
        type,
        meta
    ) {

        if (!solar) {

            return null;

        }


        const year =
            Number(solar.getYear());

        const month =
            Number(solar.getMonth());

        const day =
            Number(solar.getDay());

        const hour =
            Number(solar.getHour());

        const minute =
            Number(solar.getMinute());

        const second =
            Number(solar.getSecond());


        const dateValue =
            new Date(
                Date.UTC(
                    year,
                    month - 1,
                    day,
                    hour,
                    minute,
                    second
                )
            );


        return {

            name: name,

            pinyin:
                meta
                    ? meta.pinyin
                    : null,

            type: type,

            dateTime: {

                year: year,

                month: month,

                day: day,

                hour: hour,

                minute: minute,

                second: second

            },

            iso:
                pad(year, 4) +
                "-" +
                pad(month, 2) +
                "-" +
                pad(day, 2) +
                "T" +
                pad(hour, 2) +
                ":" +
                pad(minute, 2) +
                ":" +
                pad(second, 2),

            timestamp:
                dateValue.getTime(),

            solarMonthIndex:
                meta &&
                meta.solarMonthIndex !== undefined
                    ? meta.solarMonthIndex
                    : null,

            solarMonthNumber:
                meta &&
                meta.solarMonthNumber !== undefined
                    ? meta.solarMonthNumber
                    : null

        };

    }


    /*
    ========================================================
    07 — NORMALIZE ALL JIE QI EVENTS
    ========================================================
    */

    function normalizeJieQiTable(
        jieQiTable,
        jieQiList
    ) {

        const events = [];


        if (!jieQiTable) {

            return events;

        }


        let names = [];


        if (
            Array.isArray(jieQiList) &&
            jieQiList.length > 0
        ) {

            names =
                jieQiList.slice();

        } else {

            names =
                Object.keys(jieQiTable);

        }


        names.forEach(function (name) {

            const meta =
                JIE_QI_META[name];


            if (!meta) {

                return;

            }


            const solar =
                jieQiTable[name];


            if (!solar) {

                return;

            }


            const event =
                normalizeSolar(

                    solar,
                    name,
                    meta.type,
                    meta

                );


            if (event) {

                events.push(event);

            }

        });


        /*
        ----------------------------------------------------
        REMOVE DUPLICATES
        ----------------------------------------------------
        */

        const unique = [];

        const seen = {};


        events.forEach(function (event) {

            const key =
                event.name +
                "|" +
                event.iso;


            if (!seen[key]) {

                seen[key] = true;

                unique.push(event);

            }

        });


        /*
        ----------------------------------------------------
        CHRONOLOGICAL SORT
        ----------------------------------------------------
        */

        unique.sort(function (a, b) {

            return (
                a.timestamp -
                b.timestamp
            );

        });


        return unique;

    }


    /*
    ========================================================
    08 — FIND PREVIOUS JIE
    ========================================================
    */

    function findPreviousJie(
        events,
        targetTimestamp
    ) {

        let result = null;


        events.forEach(function (event) {

            if (
                event.type !== "JIE"
            ) {

                return;

            }


            if (
                event.timestamp <=
                targetTimestamp
            ) {

                if (
                    result === null ||
                    event.timestamp >
                    result.timestamp
                ) {

                    result = event;

                }

            }

        });


        return result;

    }


    /*
    ========================================================
    09 — FIND NEXT JIE
    ========================================================
    */

    function findNextJie(
        events,
        targetTimestamp
    ) {

        let result = null;


        events.forEach(function (event) {

            if (
                event.type !== "JIE"
            ) {

                return;

            }


            if (
                event.timestamp >
                targetTimestamp
            ) {

                if (
                    result === null ||
                    event.timestamp <
                    result.timestamp
                ) {

                    result = event;

                }

            }

        });


        return result;

    }


    /*
    ========================================================
    10 — FIND CURRENT ZHONG QI
    ========================================================

    IMPORTANT:

    For the current solar-month interval:

        Previous JIE
             ↓
        Current ZHONG QI
             ↓
        Next JIE

    Therefore the Current Zhong Qi is the Zhong Qi
    immediately AFTER Previous Jie and BEFORE Next Jie.
    ========================================================
    */

    function findCurrentZhongQi(
        events,
        previousJie,
        nextJie
    ) {

        if (
            !previousJie ||
            !nextJie
        ) {

            return null;

        }


        let result = null;


        events.forEach(function (event) {

            if (
                event.type !== "ZHONG_QI"
            ) {

                return;

            }


            if (
                event.timestamp >
                previousJie.timestamp &&
                event.timestamp <
                nextJie.timestamp
            ) {

                if (
                    result === null ||
                    event.timestamp <
                    result.timestamp
                ) {

                    result = event;

                }

            }

        });


        return result;

    }


    /*
    ========================================================
    11 — SOLAR MONTH
    ========================================================

    Zi Ping month boundary is based on JIE.

    Example:

        芒种 → 小暑

    means:

        Solar Month = 芒种 month

    We return the INDEX only.
    Month Gan-Zhi is NOT calculated here.
    ========================================================
    */

    function determineSolarMonth(
        previousJie
    ) {

        if (!previousJie) {

            return null;

        }


        const meta =
            JIE_QI_META[
                previousJie.name
            ];


        if (!meta) {

            return null;

        }


        return {

            index:
                meta.solarMonthIndex,

            number:
                meta.solarMonthNumber,

            name:
                previousJie.name,

            pinyin:
                meta.pinyin,

            basis:
                "PREVIOUS_JIE_QI",

            status:
                "RESOLVED"

        };

    }


    /*
    ========================================================
    12 — SOLAR MONTH BOUNDARY
    ========================================================
    */

    function determineSolarMonthBoundary(
        previousJie,
        nextJie
    ) {

        if (
            !previousJie ||
            !nextJie
        ) {

            return {

                start: null,

                end: null,

                rule:
                    "SOLAR MONTH IS BOUNDED BY JIE QI EVENTS",

                status:
                    "UNRESOLVED"

            };

        }


        return {

            start: {

                name:
                    previousJie.name,

                type:
                    previousJie.type,

                dateTime:
                    previousJie.dateTime,

                iso:
                    previousJie.iso

            },

            end: {

                name:
                    nextJie.name,

                type:
                    nextJie.type,

                dateTime:
                    nextJie.dateTime,

                iso:
                    nextJie.iso

            },

            rule:
                "SOLAR MONTH IS BOUNDED BY JIE QI EVENTS",

            status:
                "RESOLVED"

        };

    }


    /*
    ========================================================
    13 — DATE FORMATTER
    ========================================================
    */

    function pad(
        value,
        length
    ) {

        return String(value)
            .padStart(length, "0");

    }


    /*
    ========================================================
    14 — BUILD RESULT
    ========================================================
    */

    function calculate(input) {

        const normalized =
            validateInput(input);


        /*
        ----------------------------------------------------
        CREATE SOLAR
        ----------------------------------------------------
        */

        const solar =
            createSolar(normalized);


        /*
        ----------------------------------------------------
        GET LUNAR OBJECT
        ----------------------------------------------------
        */

        if (
            !solar ||
            typeof solar.getLunar !== "function"
        ) {

            throw new Error(
                "Jie Qi Engine: unable to create Lunar object."
            );

        }


        const lunar =
            solar.getLunar();


        /*
        ----------------------------------------------------
        GET JIE QI TABLE
        ----------------------------------------------------
        */

        if (
            !lunar ||
            typeof lunar.getJieQiTable !==
            "function"
        ) {

            throw new Error(
                "Jie Qi Engine: lunar.js getJieQiTable() is unavailable."
            );

        }


        const jieQiTable =
            lunar.getJieQiTable();


        let jieQiList = [];


        if (
            typeof lunar.getJieQiList ===
            "function"
        ) {

            jieQiList =
                lunar.getJieQiList();

        }


        /*
        ----------------------------------------------------
        NORMALIZE
        ----------------------------------------------------
        */

        const events =
            normalizeJieQiTable(

                jieQiTable,
                jieQiList

            );


        if (
            events.length === 0
        ) {

            throw new Error(
                "Jie Qi Engine: no Jie Qi data available."
            );

        }


        /*
        ----------------------------------------------------
        TARGET TIMESTAMP
        ----------------------------------------------------
        */

        const targetDate =
            new Date(
                Date.UTC(

                    normalized.year,
                    normalized.month - 1,
                    normalized.day,
                    normalized.hour,
                    normalized.minute,
                    normalized.second

                )
            );


        const targetTimestamp =
            targetDate.getTime();


        /*
        ----------------------------------------------------
        PREVIOUS JIE
        ----------------------------------------------------
        */

        const previousJie =
            findPreviousJie(

                events,
                targetTimestamp

            );


        /*
        ----------------------------------------------------
        NEXT JIE
        ----------------------------------------------------
        */

        const nextJie =
            findNextJie(

                events,
                targetTimestamp

            );


        /*
        ----------------------------------------------------
        CURRENT ZHONG QI
        ----------------------------------------------------
        */

        const currentZhongQi =
            findCurrentZhongQi(

                events,
                previousJie,
                nextJie

            );


        /*
        ----------------------------------------------------
        SOLAR MONTH
        ----------------------------------------------------
        */

        const solarMonth =
            determineSolarMonth(

                previousJie

            );


        /*
        ----------------------------------------------------
        SOLAR MONTH BOUNDARY
        ----------------------------------------------------
        */

        const solarMonthBoundary =
            determineSolarMonthBoundary(

                previousJie,
                nextJie

            );


        /*
        ----------------------------------------------------
        FINAL STATUS
        ----------------------------------------------------
        */

        const resolved =
            !!(
                previousJie &&
                currentZhongQi &&
                nextJie &&
                solarMonth &&
                solarMonthBoundary.status ===
                "RESOLVED"
            );


        /*
        ----------------------------------------------------
        RETURN
        ----------------------------------------------------
        */

        return {

            engine: {

                name:
                    ENGINE_NAME,

                version:
                    VERSION,

                status:
                    resolved
                        ? "COMPLETE"
                        : "PARTIAL",

                calculationMode:
                    "LOCAL / OFFLINE"

            },


            configuration: {

                calendarConvention:
                    "Classical Zi Ping",

                methodology:
                    METHODOLOGY

            },


            input: {

                dateTime: {

                    year:
                        normalized.year,

                    month:
                        normalized.month,

                    day:
                        normalized.day,

                    hour:
                        normalized.hour,

                    minute:
                        normalized.minute,

                    second:
                        0

                }

            },


            source: {

                provider:
                    "lunar-javascript",

                api:
                    "Solar.fromYmdHms() + getLunar() + getJieQiTable() + getJieQiList()",

                mode:
                    "LOCAL / OFFLINE"

            },


            previousJieQi:
                previousJie
                    ? {

                        name:
                            previousJie.name,

                        pinyin:
                            previousJie.pinyin,

                        type:
                            previousJie.type,

                        dateTime:
                            previousJie.dateTime,

                        iso:
                            previousJie.iso

                    }
                    : null,


            currentZhongQi:
                currentZhongQi
                    ? {

                        name:
                            currentZhongQi.name,

                        pinyin:
                            currentZhongQi.pinyin,

                        type:
                            currentZhongQi.type,

                        dateTime:
                            currentZhongQi.dateTime,

                        iso:
                            currentZhongQi.iso

                    }
                    : null,


            nextJieQi:
                nextJie
                    ? {

                        name:
                            nextJie.name,

                        pinyin:
                            nextJie.pinyin,

                        type:
                            nextJie.type,

                        dateTime:
                            nextJie.dateTime,

                        iso:
                            nextJie.iso

                    }
                    : null,


            solarMonth:
                solarMonth,


            solarMonthBoundary:
                solarMonthBoundary,


            calculation: {

                status:
                    resolved
                        ? "VERIFIED"
                        : "UNRESOLVED",

                eventCount:
                    events.length

            }

        };

    }


    /*
    ========================================================
    15 — PUBLIC ENGINE
    ========================================================
    */

    const PenggilasJieQi = {

        VERSION:
            VERSION,

        STATUS:
            "READY",

        METHODOLOGY:
            METHODOLOGY,

        ENGINE:
            ENGINE_NAME,

        calculate:
            calculate

    };


    /*
    ========================================================
    16 — GLOBAL EXPORT
    ========================================================
    */

    root.PenggilasJieQi =
        PenggilasJieQi;


})(window);