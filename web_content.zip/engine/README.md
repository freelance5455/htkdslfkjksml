# ENGINE — Calendar, Time, Location & Calculation Support

## 1. Fungsi
Folder `engine/` berisi calculation-support modules yang menyediakan fondasi teknis untuk Core, terutama terkait waktu, kalender, lokasi, Jie Qi, dan konversi lunar.

Engine support bukan presentation layer.

## 2. Isi folder

| File | Fungsi |
|---|---|
| `location.js` | Resolusi lokasi, koordinat, timezone/IANA timezone, dan reference meridian yang diperlukan untuk calculation pipeline. |
| `solar.js` | Perhitungan True Solar Time dan date-boundary support yang digunakan Core A. |
| `lunar.js` | Local lunar calculation library/support yang digunakan dalam perhitungan EightChar/lunar data. |
| `calendar.js` | Calendar conversion/support, termasuk hubungan solar/lunar yang dibutuhkan Core. |
| `jieqi.js` | Jie Qi / solar-term calculation support dan solar-month boundary information. |

## 3. Dokumentasi dan peta dependency

README ini adalah dokumentasi utama untuk `engine/`. Tidak ada `.md` khusus lain di folder ini; fungsi setiap module production diringkas pada tabel di bawah.

Kontrak lintas-layer:
- `../PRODUCTION_ARCHITECTURE.md` — wiring dan authority produksi.
- `../core/MASTER_RESULT_ARCHITECTURE.md` — boundary engine-support → Core → MasterResult.

## 4. Siapa yang memanggil

Dependency utama berasal dari Core, terutama Core A:

```text
Input
 ↓
Core A
 ├── engine/location.js
 ├── engine/solar.js
 ├── engine/jieqi.js
 ├── engine/calendar.js
 └── engine/lunar.js
 ↓
A1–A17
 ↓
MasterResult
```

File engine dapat juga dipakai oleh tahap engine lain apabila dependency tersebut memang didefinisikan di kode production.

## 5. Output

Engine mengembalikan calculation-support result, misalnya:

- resolved location/timezone;
- true solar time;
- calendar conversion;
- lunar date information;
- Jie Qi dan solar-month boundary;
- calculation metadata/provenance yang diperlukan Core.

Engine tidak menentukan struktur A/B/C sebagai presentation result.

## 6. Batas kewenangan

### Boleh
- melakukan calculation-support yang menjadi dependency engine;
- mengembalikan data teknis yang dibutuhkan Core;
- mempertahankan method/provenance information.

### Tidak boleh
- merender HTML/UI;
- membuat AI JSON;
- membuat competing MasterResult;
- melakukan patch terhadap template;
- mengambil alih determination B/C yang menjadi tanggung jawab Core/Determination.

## 7. Boundary

Engine adalah **calculation-support layer**. Core adalah **analytical result layer**.

```text
engine/*
   ↓ calculation support
core/coreA.js
   ↓
MasterResult
```

Dengan boundary ini, perubahan UI tidak perlu masuk ke `engine/`, dan perubahan template tidak perlu mengubah calculation-support.
