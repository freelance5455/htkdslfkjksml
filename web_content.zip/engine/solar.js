/* ============================================================
   PENGGILAS
   TIME / SOLAR ENGINE

   PURPOSE
   ------------------------------------------------------------
   Menghasilkan TIME FOUNDATION untuk kebutuhan Matrix A3.

   INPUT DARI ENGINE SEBELUMNYA
   ------------------------------------------------------------
   Civil Date & Time
   UTC Offset
   Longitude
   Reference Meridian

   OUTPUT MATRIX A3
   ------------------------------------------------------------
   Civil Date & Time
   Local Date & Time
   Longitude
   Meridian Correction
   LMST / LMT
   Equation of Time
   True Solar Time
   Time Used for BaZi Calculation
   Date Boundary Status

   IMPORTANT
   ------------------------------------------------------------
   - Tidak melakukan Calendar calculation.
   - Tidak melakukan Jie Qi calculation.
   - Tidak melakukan Four Pillars calculation.
   - Tidak melakukan interpretation.
   - Tidak menentukan Time Used rule yang belum dikunci.
   - Solar calculation dilakukan LOCAL / OFFLINE.

   EoT reference:
   NOAA Global Monitoring Laboratory
   General Solar Position Calculations
   ============================================================ */


window.PenggilasSolar = {

    VERSION: "V2.0",

    STATUS: "READY",

    EOT_SOURCE:
        "NOAA General Solar Position Calculations",


    /* ========================================================
       MAIN ENGINE
       ======================================================== */

    calculate(input) {

        validateInput(input);


        /*
         * ----------------------------------------------------
         * 1. NORMALIZE INPUT
         * ----------------------------------------------------
         */

        const year =
            Number(input.year);

        const month =
            Number(input.month);

        const day =
            Number(input.day);

        const hour =
            Number(input.hour);

        const minute =
            Number(input.minute);

        const second =
            input.second !== undefined
                ? Number(input.second)
                : 0;

        const utcOffset =
            Number(input.utcOffset);

        const longitude =
            Number(input.longitude);

        const referenceMeridian =
            Number(input.referenceMeridian);


        /*
         * ----------------------------------------------------
         * 2. CIVIL DATE & TIME
         * ----------------------------------------------------
         */

        const civilDateTime = {

            year: year,

            month: month,

            day: day,

            hour: hour,

            minute: minute,

            second: second

        };


        /*
         * ----------------------------------------------------
         * 3. LOCAL DATE & TIME
         *
         * Untuk Engine 03, Local Date & Time berasal dari
         * Civil Date & Time + timezone context.
         *
         * Kita mempertahankan nilai kalender lokal user.
         * ----------------------------------------------------
         */

        const localDateTime = {

            year: year,

            month: month,

            day: day,

            hour: hour,

            minute: minute,

            second: second,

            utcOffset: utcOffset

        };


        /*
         * ----------------------------------------------------
         * 4. MERIDIAN CORRECTION
         *
         * Matrix:
         *
         * (Longitude - Reference Meridian)
         * × 4 minutes / degree
         * ----------------------------------------------------
         */

        const meridianCorrection =
            (
                longitude -
                referenceMeridian
            ) * 4;


        /*
         * ----------------------------------------------------
         * 5. LOCAL MEAN SOLAR TIME
         *
         * LMST / LMT
         *
         * Local civil time
         * +
         * longitude correction
         *
         * Kita hitung dalam total minutes supaya
         * date rollover dapat ditangani dengan aman.
         * ----------------------------------------------------
         */

        const localClockMinutes =
            (
                hour * 60
            ) +
            minute +
            (
                second / 60
            );


        const lmstMinutesRaw =
            localClockMinutes +
            meridianCorrection;


        const lmst =
            normalizeSolarMinutes(
                lmstMinutesRaw
            );


        /*
         * ----------------------------------------------------
         * 6. EQUATION OF TIME
         *
         * NOAA formula.
         *
         * gamma =
         * 2π / daysInYear *
         * (
         *   dayOfYear - 1
         *   +
         *   (hour - 12) / 24
         * )
         *
         * EoT result = minutes.
         * ----------------------------------------------------
         */

        const dayOfYear =
            getDayOfYear(
                year,
                month,
                day
            );


        const daysInYear =
            isLeapYear(year)
                ? 366
                : 365;


        const fractionalYear =
            (
                2 * Math.PI
            ) /
            daysInYear *
            (
                dayOfYear -
                1 +
                (
                    hour -
                    12
                ) / 24
            );


        const equationOfTime =
            calculateEquationOfTime(
                fractionalYear
            );


        /*
         * ----------------------------------------------------
         * 7. TRUE SOLAR TIME
         *
         * Matrix:
         *
         * True Solar Time
         * = LMST + EoT
         *
         * ----------------------------------------------------
         */

        const trueSolarMinutesRaw =
            lmstMinutesRaw +
            equationOfTime;


        const trueSolar =
            normalizeSolarMinutes(
                trueSolarMinutesRaw
            );


        /*
         * ----------------------------------------------------
         * 8. DATE BOUNDARY STATUS
         * ----------------------------------------------------
         */

        const dateBoundary =
            calculateDateBoundaryStatus(
                trueSolarMinutesRaw
            );


        /*
         * ----------------------------------------------------
         * 9. TIME USED FOR BAZI CALCULATION
         *
         * IMPORTANT:
         *
         * Matrix menyebut:
         * "defined engine rule"
         *
         * Rule tersebut belum dikunci dalam konteks
         * yang tersedia.
         *
         * Jadi jangan mengarang.
         * ----------------------------------------------------
         */

        const timeUsedForBaZi = {

            status:
                "RESOLVED",

            value:
                trueSolar.formatted,

            rule:
                "TRUE SOLAR TIME = Local Mean Solar Time + longitude correction + Equation of Time; project-locked BaZi calculation time"

        };


        /*
         * ----------------------------------------------------
         * 10. FINAL ENGINE RESULT
         * ----------------------------------------------------
         */

        return {

            engine: {

                name:
                    "PENGGILAS TIME / SOLAR ENGINE",

                version:
                    this.VERSION,

                status:
                    "CALCULATED",

                calculationMode:
                    "LOCAL / OFFLINE"

            },


            source: {

                equationOfTime:
                    this.EOT_SOURCE

            },


            input: {

                civilDateTime:
                    civilDateTime,

                utcOffset:
                    utcOffset,

                longitude:
                    longitude,

                referenceMeridian:
                    referenceMeridian

            },


            solarTime: {

                localDateTime:
                    localDateTime,

                longitude:
                    longitude,

                meridianCorrection: {

                    value:
                        meridianCorrection,

                    unit:
                        "minutes",

                    formula:
                        "(Longitude - Reference Meridian) × 4"

                },

                lmst: {

                    value:
                        lmst.totalMinutes,

                    formatted:
                        lmst.formatted,

                    unit:
                        "local solar time"

                },

                equationOfTime: {

                    value:
                        equationOfTime,

                    unit:
                        "minutes"

                },

                trueSolarTime: {

                    value:
                        trueSolar.totalMinutes,

                    formatted:
                        trueSolar.formatted,

                    unit:
                        "true solar time"

                }

            },


            timeUsedForBaZiCalculation:
                timeUsedForBaZi,


            dateBoundary:
                dateBoundary

        };

    }

};


/* ============================================================
   VALIDATION
   ============================================================ */

function validateInput(
    input
) {

    if (
        !input ||
        typeof input !== "object"
    ) {

        throw new Error(
            "Solar Engine input is required."
        );

    }


    const requiredFields = [

        "year",
        "month",
        "day",
        "hour",
        "minute",
        "utcOffset",
        "longitude",
        "referenceMeridian"

    ];


    for (
        const field of requiredFields
    ) {

        if (
            input[field] ===
            null ||
            input[field] ===
            undefined ||
            input[field] === ""
        ) {

            throw new Error(
                `Solar Engine input missing: ${field}`
            );

        }


        if (
            !Number.isFinite(
                Number(input[field])
            )
        ) {

            throw new Error(
                `Solar Engine input invalid: ${field}`
            );

        }

    }

}


/* ============================================================
   LEAP YEAR
   ============================================================ */

function isLeapYear(
    year
) {

    return (
        (
            year % 4 === 0 &&
            year % 100 !== 0
        )
        ||
        (
            year % 400 === 0
        )
    );

}


/* ============================================================
   DAY OF YEAR
   ============================================================ */

function getDayOfYear(
    year,
    month,
    day
) {

    const monthDays = [

        31,
        isLeapYear(year)
            ? 29
            : 28,
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31

    ];


    let result =
        day;


    for (
        let i = 0;
        i < month - 1;
        i++
    ) {

        result +=
            monthDays[i];

    }


    return result;

}


/* ============================================================
   EQUATION OF TIME
   ============================================================ */

function calculateEquationOfTime(
    gamma
) {

    const eot =
        229.18 *
        (
            0.000075

            +

            0.001868 *
            Math.cos(
                gamma
            )

            -

            0.032077 *
            Math.sin(
                gamma
            )

            -

            0.014615 *
            Math.cos(
                2 * gamma
            )

            -

            0.040849 *
            Math.sin(
                2 * gamma
            )
        );


    return eot;

}


/* ============================================================
   NORMALIZE SOLAR MINUTES
   ============================================================ */

function normalizeSolarMinutes(
    totalMinutes
) {

    const minutesPerDay =
        24 * 60;


    /*
     * Keep a copy for day-shift detection.
     */

    const dayShift =
        Math.floor(
            totalMinutes /
            minutesPerDay
        );


    let normalized =
        totalMinutes %
        minutesPerDay;


    if (
        normalized < 0
    ) {

        normalized +=
            minutesPerDay;

    }


    const hours =
        Math.floor(
            normalized / 60
        );


    const minutes =
        Math.floor(
            normalized % 60
        );


    const seconds =
        Math.round(
            (
                normalized -
                (
                    hours * 60
                ) -
                minutes
            ) * 60
        );


    /*
     * Handle rounding to 60 seconds.
     */

    let finalHours =
        hours;

    let finalMinutes =
        minutes;

    let finalSeconds =
        seconds;


    if (
        finalSeconds >= 60
    ) {

        finalSeconds = 0;

        finalMinutes++;

    }


    if (
        finalMinutes >= 60
    ) {

        finalMinutes = 0;

        finalHours++;

    }


    if (
        finalHours >= 24
    ) {

        finalHours = 0;

    }


    const formatted =
        [
            String(finalHours)
                .padStart(2, "0"),

            String(finalMinutes)
                .padStart(2, "0"),

            String(finalSeconds)
                .padStart(2, "0")

        ].join(":");


    return {

        totalMinutes:
            normalized,

        formatted:
            formatted,

        dayShift:
            dayShift

    };

}


/* ============================================================
   DATE BOUNDARY STATUS
   ============================================================ */

function calculateDateBoundaryStatus(
    trueSolarMinutesRaw
) {

    const minutesPerDay =
        24 * 60;


    if (
        trueSolarMinutesRaw <
        0
    ) {

        return {

            status:
                "PREVIOUS_DATE",

            dayShift:
                Math.floor(
                    trueSolarMinutesRaw /
                    minutesPerDay
                )

        };

    }


    if (
        trueSolarMinutesRaw >=
        minutesPerDay
    ) {

        return {

            status:
                "NEXT_DATE",

            dayShift:
                Math.floor(
                    trueSolarMinutesRaw /
                    minutesPerDay
                )

        };

    }


    return {

        status:
            "SAME_DATE",

        dayShift:
            0

    };

}