// ============================================================
// trafficLights.js — أعمدة إشارات المرور عند التقاطعات
// ============================================================
const TrafficLights = (function () {

  let poles = [];      // { axis:'NS'|'EW', red, yellow, green }
  let timer = 0;
  let phase = "NS_GREEN"; // NS_GREEN -> NS_YELLOW -> EW_GREEN -> EW_YELLOW -> loop

  const G = CONFIG.LIGHT_GREEN_TIME;
  const Y = CONFIG.LIGHT_YELLOW_TIME;

  function makePoleMesh(scene, x, z, facingRotY, axis) {
    const group = new THREE.Group();
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x24262a, roughness: 0.5, metalness: 0.6 });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 3.1, 8), poleMat);
    pole.position.y = 1.55;
    pole.castShadow = true;
    group.add(pole);

    const boxMat = new THREE.MeshStandardMaterial({ color: 0x1a1c1f, roughness: 0.5 });
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.9, 0.28), boxMat);
    box.position.set(0, 2.95, 0);
    group.add(box);

    function makeLamp(y, offColor) {
      const mat = new THREE.MeshStandardMaterial({
        color: offColor, emissive: 0x000000, emissiveIntensity: 0,
      });
      const m = new THREE.Mesh(new THREE.CircleGeometry(0.11, 12), mat);
      m.position.set(0, y, 0.15);
      group.add(m);
      return m;
    }
    const red = makeLamp(3.24, 0x3a0f0f);
    const yellow = makeLamp(2.95, 0x3a330f);
    const green = makeLamp(2.66, 0x0f3a18);

    group.position.set(x, 0, z);
    group.rotation.y = facingRotY;
    scene.add(group);

    poles.push({ axis, red, yellow, green });
  }

  function init(scene, network) {
    poles = [];
    const off = CONFIG.ROAD_WIDTH / 2 + 0.5;
    for (const { x, z } of network.intersections) {
      // عمود يتحكم في الحركة على المحور الرأسي (NS) - واقف على جنب يواجه القادم من الجنوب
      makePoleMesh(scene, x - off, z - off, Math.PI * 0.75, "NS");
      // عمود يتحكم في الحركة على المحور الأفقي (EW)
      makePoleMesh(scene, x + off, z - off, -Math.PI * 0.25, "EW");
    }
    timer = 0;
    phase = "NS_GREEN";
  }

  function applyPhase() {
    for (const p of poles) {
      let state;
      if (p.axis === "NS") {
        state = (phase === "NS_GREEN") ? "green" : (phase === "NS_YELLOW") ? "yellow" : "red";
      } else {
        state = (phase === "EW_GREEN") ? "green" : (phase === "EW_YELLOW") ? "yellow" : "red";
      }
      p.red.material.emissiveIntensity = state === "red" ? 2.2 : 0;
      p.yellow.material.emissiveIntensity = state === "yellow" ? 2.2 : 0;
      p.green.material.emissiveIntensity = state === "green" ? 2.2 : 0;
      p.red.material.emissive.set(state === "red" ? 0xff3a2f : 0x000000);
      p.yellow.material.emissive.set(state === "yellow" ? 0xffd23a : 0x000000);
      p.green.material.emissive.set(state === "green" ? 0x35ff6a : 0x000000);
    }
  }

  function update(dt) {
    timer += dt;
    if (phase === "NS_GREEN" && timer >= G) { phase = "NS_YELLOW"; timer = 0; }
    else if (phase === "NS_YELLOW" && timer >= Y) { phase = "EW_GREEN"; timer = 0; }
    else if (phase === "EW_GREEN" && timer >= G) { phase = "EW_YELLOW"; timer = 0; }
    else if (phase === "EW_YELLOW" && timer >= Y) { phase = "NS_GREEN"; timer = 0; }
    applyPhase();
  }

  // بيرجع 'green'|'yellow'|'red' لمحور معين - تستخدمه الـ AI عشان تعرف توقف ولا لأ
  function getState(axis) {
    if (axis === "NS") {
      if (phase === "NS_GREEN") return "green";
      if (phase === "NS_YELLOW") return "yellow";
      return "red";
    } else {
      if (phase === "EW_GREEN") return "green";
      if (phase === "EW_YELLOW") return "yellow";
      return "red";
    }
  }

  return { init, update, getState };
})();
