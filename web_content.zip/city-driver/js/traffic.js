// ============================================================
// traffic.js — عربيات الشارع (AI) بتلف حوالين البلوكات وتقف عند الإشارة الحمرا
// ============================================================
const Traffic = (function () {

  let cars = [];
  const CAR_COLORS = [0xd1483f, 0x3f6dd1, 0xe8d84a, 0x3fae5c, 0xf2f2f2, 0x2b2b2e, 0xd88a3f, 0x7a4fd1];

  function buildToyCar(color) {
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.45, metalness: 0.35 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.62, 4.0), bodyMat);
    body.position.y = 0.5;
    body.castShadow = true;
    g.add(body);

    const cabinMat = new THREE.MeshStandardMaterial({ color: 0x1c2733, roughness: 0.2, metalness: 0.5 });
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.5, 2.1), cabinMat);
    cabin.position.set(0, 0.98, -0.15);
    cabin.castShadow = true;
    g.add(cabin);

    const lightMatF = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2c0, emissiveIntensity: 1.2 });
    const lightMatR = new THREE.MeshStandardMaterial({ color: 0x660000, emissive: 0xff2a2a, emissiveIntensity: 1.1 });
    const flL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.14, 0.06), lightMatF);
    flL.position.set(0.68, 0.55, 2.0);
    g.add(flL);
    const flR = flL.clone(); flR.position.x = -0.68; g.add(flR);
    const rlL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.14, 0.06), lightMatR);
    rlL.position.set(0.68, 0.55, -2.0);
    g.add(rlL);
    const rlR = rlL.clone(); rlR.position.x = -0.68; g.add(rlR);

    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.8 });
    const wheels = [];
    const wGeo = new THREE.CylinderGeometry(0.34, 0.34, 0.26, 14);
    for (const [x, z] of [[0.95, 1.25], [-0.95, 1.25], [0.95, -1.25], [-0.95, -1.25]]) {
      const w = new THREE.Mesh(wGeo, wheelMat);
      w.rotation.z = Math.PI / 2;
      w.position.set(x, 0.36, z);
      w.castShadow = true;
      g.add(w);
      wheels.push(w);
    }
    g.userData.wheels = wheels;
    return g;
  }

  function segAxis(i) { return (i === 0 || i === 2) ? "EW" : "NS"; }

  function makeLoop(network, bi, bj) {
    const off = CONFIG.ROAD_WIDTH * 0.24;
    const x1 = network.verticalXs[bi] + off, x2 = network.verticalXs[bi + 1] - off;
    const z1 = network.horizontalZs[bj] + off, z2 = network.horizontalZs[bj + 1] - off;
    return [
      { x: x1, z: z1 }, { x: x2, z: z1 }, { x: x2, z: z2 }, { x: x1, z: z2 },
    ];
  }

  function init(scene, network) {
    cars = [];
    const n = CONFIG.TRAFFIC_CAR_COUNT;
    for (let i = 0; i < n; i++) {
      const bi = Math.floor(Math.random() * CONFIG.BLOCKS_X);
      const bj = Math.floor(Math.random() * CONFIG.BLOCKS_Z);
      const loop = makeLoop(network, bi, bj);
      const color = CAR_COLORS[i % CAR_COLORS.length];
      const mesh = buildToyCar(color);
      scene.add(mesh);
      cars.push({
        mesh,
        loop,
        seg: Math.floor(Math.random() * 4),
        t: Math.random(),
        speed: CONFIG.TRAFFIC_SPEED * (0.85 + Math.random() * 0.3),
        curSpeed: CONFIG.TRAFFIC_SPEED,
      });
    }
  }

  function segLength(loop, seg) {
    const a = loop[seg], b = loop[(seg + 1) % 4];
    return Math.hypot(b.x - a.x, b.z - a.z);
  }

  function update(dt) {
    for (const car of cars) {
      const { loop } = car;
      const len = segLength(loop, car.seg);
      const axis = segAxis(car.seg);
      const remaining = (1 - car.t) * len;

      // شوف الإشارة قدامنا لو قربنا من التقاطع
      let targetSpeed = car.speed;
      const light = TrafficLights.getState(axis);
      if (remaining < 9 && remaining > 1.2 && (light === "red" || light === "yellow")) {
        targetSpeed = 0;
      }

      // منع التصادم مع عربية قدامنا في نفس اللوب
      for (const other of cars) {
        if (other === car) continue;
        if (other.loop !== car.loop) continue;
        if (other.seg !== car.seg) continue;
        if (other.t > car.t && other.t - car.t < 0.12) { targetSpeed = 0; break; }
      }

      car.curSpeed = damp(car.curSpeed, targetSpeed, 3, dt);
      car.t += (car.curSpeed * dt) / Math.max(len, 0.001);
      if (car.t >= 1) {
        car.t -= 1;
        car.seg = (car.seg + 1) % 4;
      }

      const na = loop[car.seg], nb = loop[(car.seg + 1) % 4];
      const px = lerp(na.x, nb.x, car.t);
      const pz = lerp(na.z, nb.z, car.t);
      const heading = Math.atan2(nb.x - na.x, nb.z - na.z);
      car.mesh.position.set(px, 0, pz);
      car.mesh.rotation.y = heading;

      const wheelSpin = car.curSpeed * dt * 2.4;
      for (const w of car.mesh.userData.wheels) w.rotation.x += wheelSpin;
    }
  }

  function getCars() { return cars; }

  return { init, update, getCars };
})();
