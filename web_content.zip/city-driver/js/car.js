// ============================================================
// car.js — عربية اللاعب: تحميل الموديل + فيزياء الجير المانيوال
// ============================================================
const PlayerCar = (function () {

  const TARGET_LENGTH = 4.3; // متر - طول واقعي تقريبي للعربية بعد الـ scale

  let carGroup, root;
  let wheels = {}; // { FR:{pivot,node,rollAxis}, FL:{...}, RL:{node,rollAxis}, RR:{...} }
  let interiorWheel = null, interiorAxis = "z";
  let wheelRadius = CONFIG.WHEEL_RADIUS_FALLBACK;

  // حالة الفيزياء
  const state = {
    x: 0, z: 0, heading: 0,
    speed: 0,        // م/ث (بالسالب = رجوع)
    rpm: CONFIG.IDLE_RPM,
    gear: "N",
    stalled: false,
    steerAngle: 0,    // راديان - زاوية عجل القيادة الحالية (مخملة)
  };

  function setupWheelPivot(node) {
    const { size } = getBoundingInfo(node);
    const rollAxis = getThinAxis(size);
    const parent = node.parent;
    const pivot = new THREE.Group();
    pivot.position.copy(node.position);
    parent.add(pivot);
    node.position.set(0, 0, 0);
    pivot.add(node);
    return { pivot, node, rollAxis };
  }

  function setupWheelSimple(node) {
    const { size } = getBoundingInfo(node);
    const rollAxis = getThinAxis(size);
    return { node, rollAxis };
  }

  function load(scene, path, onDone, onError) {
    const loader = new THREE.GLTFLoader();
    loader.load(path, (gltf) => {
      root = gltf.scene;

      const wheelFR = root.getObjectByName("WheelFR");
      const wheelFL = root.getObjectByName("WheelFL");
      const wheelRL = root.getObjectByName("WheelRL");
      const wheelRR = root.getObjectByName("WheelRR");
      const steeringWheel = root.getObjectByName("SteeringWheel");

      if (wheelFR) wheels.FR = setupWheelPivot(wheelFR);
      if (wheelFL) wheels.FL = setupWheelPivot(wheelFL);
      if (wheelRL) wheels.RL = setupWheelSimple(wheelRL);
      if (wheelRR) wheels.RR = setupWheelSimple(wheelRR);

      if (wheelFR) {
        const info = getBoundingInfo(wheelFR);
        const vals = [info.size.x, info.size.y, info.size.z].sort((a, b) => b - a);
        wheelRadius = vals[0] / 2 || CONFIG.WHEEL_RADIUS_FALLBACK;
      }

      if (steeringWheel) {
        const { size } = getBoundingInfo(steeringWheel);
        interiorAxis = getThinAxis(size);
        interiorWheel = steeringWheel;
      }

      // -------- سكيل تلقائي + تثبيت العربية على الأرض --------
      const before = getBoundingInfo(root);
      const horiz = Math.max(before.size.x, before.size.z) || 1;
      const scale = TARGET_LENGTH / horiz;
      root.scale.setScalar(scale);
      wheelRadius *= scale;

      const after = getBoundingInfo(root);
      root.position.y -= after.box.min.y;

      root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });

      carGroup = new THREE.Group();
      carGroup.add(root);
      scene.add(carGroup);

      onDone({ carGroup, root, wheelRadius });
    }, undefined, (err) => { if (onError) onError(err); });
  }

  // ---------------- الفيزياء ----------------
  function setGear(g) { state.gear = g; }
  function getGear() { return state.gear; }
  function getState() { return state; }

  function tryStartEngine() {
    if (state.stalled) { state.stalled = false; state.rpm = CONFIG.IDLE_RPM; }
  }

  function update(dt, input, collidables) {
    const clutchEngage = 1 - input.clutch; // 0=مفصول، 1=متعشق تمام
    const ratio = CONFIG.GEAR_RATIOS[state.gear] || 0;
    const inGear = ratio !== 0;

    // ---- دورة الموتور RPM ----
    if (state.stalled) {
      state.rpm = damp(state.rpm, 0, 6, dt);
    } else if (inGear && clutchEngage > 0.55) {
      const wheelAngSpeed = state.speed / Math.max(wheelRadius, 0.05);
      const targetRpm = clamp(
        Math.abs(wheelAngSpeed * ratio * CONFIG.FINAL_DRIVE) * (60 / (2 * Math.PI)) + input.throttle * 250,
        0, CONFIG.MAX_RPM
      );
      state.rpm = damp(state.rpm, targetRpm, 8, dt);
      // ستول لو المحرك واقف وطالع فيه وتضغط دبرياج شوية بس مش سرعة
      if (state.rpm < CONFIG.STALL_RPM && Math.abs(state.speed) < 0.6 && input.throttle < 0.15) {
        state.stalled = true;
      }
    } else {
      const targetRpm = CONFIG.IDLE_RPM + input.throttle * (CONFIG.REDLINE_RPM - CONFIG.IDLE_RPM) * 0.85;
      state.rpm = damp(state.rpm, targetRpm, 5, dt);
    }

    // ---- قوة الدفع ----
    let driveForce = 0;
    if (!state.stalled && inGear) {
      const torque = torqueCurve(state.rpm) * input.throttle;
      driveForce = (torque * ratio * CONFIG.FINAL_DRIVE * clutchEngage) / Math.max(wheelRadius, 0.05);
    }

    const speed = state.speed;
    const brakeForce = input.brake * CONFIG.MAX_BRAKE_FORCE * Math.sign(speed || 1);
    const dragForce = CONFIG.AIR_DRAG * speed * Math.abs(speed);
    const rollForce = CONFIG.ROLL_RESIST * speed;

    let net = driveForce - brakeForce - dragForce - rollForce;
    // لو واقفة وفرامل مضغوطة منع الاهتزاز حوالين الصفر
    if (Math.abs(speed) < 0.05 && input.throttle < 0.05) {
      net = driveForce; // من غير فرامل/رول وهي واقفة
      if (input.brake > 0.1) net = 0;
    }

    const accel = net / CONFIG.MASS;
    state.speed += accel * dt;
    state.speed = clamp(state.speed, -14, 46);

    // ---- التوجيه (نموذج bicycle) ----
    const steerMax = degToRad(CONFIG.STEER_MAX_DEG);
    const targetSteer = input.steer * steerMax;
    state.steerAngle = damp(state.steerAngle, targetSteer, 9, dt);
    if (Math.abs(state.speed) > 0.02) {
      state.heading += (state.speed / CONFIG.WHEELBASE) * Math.tan(state.steerAngle) * dt;
    }

    const newX = state.x + Math.sin(state.heading) * state.speed * dt;
    const newZ = state.z + Math.cos(state.heading) * state.speed * dt;

    // ---- تصادم بسيط ----
    const halfW = 1.05, halfL = 2.2;
    const testBox = new THREE.Box3(
      new THREE.Vector3(newX - halfW, 0, newZ - halfL),
      new THREE.Vector3(newX + halfW, 2, newZ + halfL)
    );
    let collided = false;
    if (collidables) {
      for (const b of collidables) {
        if (testBox.intersectsBox(b)) { collided = true; break; }
      }
    }
    if (collided) {
      state.speed *= -0.15;
    } else {
      state.x = newX; state.z = newZ;
    }

    // ---- تطبيق الترانسفورم على الموديل ----
    if (carGroup) {
      carGroup.position.set(state.x, 0, state.z);
      carGroup.rotation.y = state.heading + CONFIG.CAR_MODEL_YAW_OFFSET;
    }

    // ---- تدوير العجل ----
    const rollDelta = (state.speed / Math.max(wheelRadius, 0.05)) * dt;
    for (const key of ["FR", "FL", "RL", "RR"]) {
      const w = wheels[key];
      if (!w) continue;
      w.node.rotation[w.rollAxis] += rollDelta;
      if (w.pivot) w.pivot.rotation.y = state.steerAngle;
    }
    if (interiorWheel) {
      interiorWheel.rotation[interiorAxis] = state.steerAngle * 3.2;
    }

    return { collided };
  }

  return { load, update, setGear, getGear, getState, tryStartEngine };
})();
