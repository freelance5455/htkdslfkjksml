// ============================================================
// utils.js — دوال مساعدة عامة
// ============================================================

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function damp(current, target, lambda, dt) {
  return lerp(current, target, 1 - Math.exp(-lambda * dt));
}
function degToRad(d) { return d * Math.PI / 180; }

// منحنى عزم بسيط للموتور: بيرتفع لحد الذروة حوالي نص الريف رينج وبعدين بينزل شوية
function torqueCurve(rpm) {
  const idle = CONFIG.IDLE_RPM, redline = CONFIG.REDLINE_RPM;
  const peak = idle + (redline - idle) * 0.55;
  let t;
  if (rpm <= peak) {
    t = (rpm - idle) / (peak - idle);
    t = clamp(t, 0, 1);
    return CONFIG.MAX_ENGINE_TORQUE * (0.35 + 0.65 * t);
  } else {
    t = (rpm - peak) / (redline - peak);
    t = clamp(t, 0, 1);
    return CONFIG.MAX_ENGINE_TORQUE * (1 - 0.5 * t);
  }
}

// بيحسب الصندوق المحيط بأي أوبجكت three.js ويرجع center/size
function getBoundingInfo(object3d) {
  const box = new THREE.Box3().setFromObject(object3d);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  return { box, size, center };
}

// بيحدد المحور "الرفيع" (أقل امتداد) في صندوق معين - مفيد عشان نلاقي
// محور دوران عجلة أو دركسيون تلقائيًا من غير ما نعرف اتجاه الموديل الأصلي
function getThinAxis(size) {
  const arr = [
    { axis: "x", val: size.x },
    { axis: "y", val: size.y },
    { axis: "z", val: size.z },
  ];
  arr.sort((a, b) => a.val - b.val);
  return arr[0].axis;
}

// عداد عربية بسيط (canvas texture) عشان نولّد لوحة أرقام / نقوش شبابيك المباني
// من غير ما نحتاج نحمّل أي صور خارجية (يفضل الشغل أوف لاين تمامًا)
function makeWindowTexture(baseColor, litColor, cols, rows) {
  const c = document.createElement("canvas");
  c.width = 128; c.height = 128;
  const ctx = c.getContext("2d");
  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, 128, 128);
  const cw = 128 / cols, rh = 128 / rows;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (Math.random() > 0.35) {
        ctx.fillStyle = litColor;
        ctx.fillRect(x * cw + cw * 0.18, y * rh + rh * 0.18, cw * 0.64, rh * 0.64);
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

// نسيج إسفلت بسيط فيه خطوط منتصف الطريق
function makeRoadTexture(lengthRepeat) {
  const c = document.createElement("canvas");
  c.width = 64; c.height = 256;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#3a3d42";
  ctx.fillRect(0, 0, 64, 256);
  ctx.fillStyle = "#e8c94a";
  ctx.fillRect(28, 0, 8, 60);
  ctx.fillRect(28, 100, 8, 60);
  ctx.fillRect(28, 200, 8, 56);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, lengthRepeat);
  return tex;
}

function makeSidewalkTexture() {
  const c = document.createElement("canvas");
  c.width = 64; c.height = 64;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#9a978f";
  ctx.fillRect(0, 0, 64, 64);
  ctx.strokeStyle = "#7d7a73";
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, 62, 62);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}
