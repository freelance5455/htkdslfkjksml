// ============================================================
// controls.js — عجلة القيادة والدواسات الحقيقية (3D) كأدوات تحكم على الشاشة
// ============================================================
const Controls = (function () {

  const WHEEL_VISUAL_MAX_DEG = 210; // أقصى دوران بصري للدركسيون في اتجاه واحد

  let wheelScene, wheelCamera, wheelRoot, wheelViewport = {};
  let pedalScene, pedalCamera, pedalViewport = {};
  let padNodes = { clutch: null, brake: null, gas: null };
  let padBasePos = {};
  let logicalW = window.innerWidth, logicalH = window.innerHeight;

  let wheelRotation = 0; // راديان
  let dragging = false, dragCenter = { x: 0, y: 0 }, lastAngle = 0;

  const input = { throttle: 0, brake: 0, clutch: 0, steer: 0 };
  let gasTouchId = null, brakeTouchId = null, clutchTouchId = null;

  let gear = "N";
  const GEAR_ORDER = ["R", "N", "1", "2", "3", "4", "5"];
  let onGearChange = null;

  function frameObjectFromThinAxis(scene, camera, object, paddingMult) {
    const { size, center } = getBoundingInfo(object);
    const axis = getThinAxis(size);
    const maxSide = Math.max(size.x, size.y, size.z);
    const dist = maxSide * paddingMult;
    const dir = new THREE.Vector3(
      axis === "x" ? 1 : 0.15,
      axis === "y" ? 1 : 0.35,
      axis === "z" ? 1 : 0.15
    ).normalize();
    camera.position.copy(center.clone().add(dir.multiplyScalar(dist)));
    camera.lookAt(center);
    camera.near = 0.01;
    camera.far = dist * 4 + maxSide * 2;
    camera.updateProjectionMatrix();
  }

  function loadWheelModel(path, onDone) {
    wheelScene = new THREE.Scene();
    wheelScene.background = null;
    const amb = new THREE.AmbientLight(0xffffff, 0.9);
    wheelScene.add(amb);
    const dir = new THREE.DirectionalLight(0xffffff, 1.1);
    dir.position.set(2, 4, 3);
    wheelScene.add(dir);

    wheelCamera = new THREE.PerspectiveCamera(32, 1, 0.01, 50);

    const loader = new THREE.GLTFLoader();
    loader.load(path, (gltf) => {
      wheelRoot = new THREE.Group();
      wheelRoot.add(gltf.scene);
      wheelScene.add(wheelRoot);
      frameObjectFromThinAxis(wheelScene, wheelCamera, gltf.scene, 2.35);
      if (onDone) onDone();
    });
  }

  function loadPedalModel(path, onDone) {
    pedalScene = new THREE.Scene();
    pedalScene.background = null;
    const amb = new THREE.AmbientLight(0xffffff, 0.95);
    pedalScene.add(amb);
    const dir = new THREE.DirectionalLight(0xffffff, 1.2);
    dir.position.set(1, 5, 3);
    pedalScene.add(dir);

    pedalCamera = new THREE.PerspectiveCamera(38, 1, 0.01, 200);

    const loader = new THREE.GLTFLoader();
    loader.load(path, (gltf) => {
      pedalScene.add(gltf.scene);
      padNodes.clutch = gltf.scene.getObjectByName("Object_15");
      padNodes.brake = gltf.scene.getObjectByName("Object_6");
      padNodes.gas = gltf.scene.getObjectByName("Object_7");
      for (const k in padNodes) {
        if (padNodes[k]) padBasePos[k] = padNodes[k].position.clone();
      }
      // كاميرا بزاوية علوية 3/4 زي منظر قدم السواق للدواسات
      const { size, center } = getBoundingInfo(gltf.scene);
      const maxSide = Math.max(size.x, size.y, size.z);
      pedalCamera.position.set(
        center.x, center.y + maxSide * 1.15, center.z + maxSide * 1.05
      );
      pedalCamera.lookAt(center);
      pedalCamera.updateProjectionMatrix();
      if (onDone) onDone();
    });
  }

  // ---------------- تحديث الفيوبورتس عند تغيير حجم الشاشة ----------------
  function layout(width, height) {
    logicalW = width; logicalH = height;
    const wheelSize = Math.min(width, height) * 0.34;
    wheelViewport = { x: 10, y: 10, w: wheelSize, h: wheelSize };

    const pedalW = width * 0.30;
    const pedalH = height * 0.30;
    pedalViewport = { x: width - pedalW - 10, y: 10, w: pedalW, h: pedalH };
  }

  // ---------------- إدخال الدركسيون باللمس/الماوس ----------------
  function angleFromCenter(px, py, vp) {
    const cx = vp.x + vp.w / 2;
    const cyTop = logicalH - (vp.y + vp.h / 2); // vp.y بيتحسب من تحت زي WebGL
    return Math.atan2(px - cx, py - cyTop);
  }

  function pointInViewport(px, py, vp) {
    const screenY = logicalH - py;
    return px >= vp.x && px <= vp.x + vp.w && screenY >= vp.y && screenY <= vp.y + vp.h;
  }

  function onPointerDown(px, py, id) {
    if (pointInViewport(px, py, wheelViewport)) {
      dragging = id;
      lastAngle = angleFromCenter(px, py, wheelViewport);
      return true;
    }
    if (pointInViewport(px, py, pedalViewport)) {
      const localX = (px - pedalViewport.x) / pedalViewport.w;
      if (localX < 0.34) clutchTouchId = id;
      else if (localX < 0.67) brakeTouchId = id;
      else gasTouchId = id;
      return true;
    }
    return false;
  }

  function onPointerMove(px, py, id) {
    if (dragging === id) {
      const a = angleFromCenter(px, py, wheelViewport);
      let delta = a - lastAngle;
      if (delta > Math.PI) delta -= Math.PI * 2;
      if (delta < -Math.PI) delta += Math.PI * 2;
      wheelRotation = clamp(wheelRotation + delta, -degToRad(WHEEL_VISUAL_MAX_DEG), degToRad(WHEEL_VISUAL_MAX_DEG));
      lastAngle = a;
    }
  }

  function onPointerUp(id) {
    if (dragging === id) dragging = false;
    if (gasTouchId === id) gasTouchId = null;
    if (brakeTouchId === id) brakeTouchId = null;
    if (clutchTouchId === id) clutchTouchId = null;
  }

  function bindPointerEvents(canvas) {
    canvas.style.touchAction = "none";
    canvas.addEventListener("pointerdown", (e) => {
      if (onPointerDown(e.clientX, e.clientY, e.pointerId)) {
        canvas.setPointerCapture(e.pointerId);
        e.preventDefault();
      }
    });
    canvas.addEventListener("pointermove", (e) => {
      onPointerMove(e.clientX, e.clientY, e.pointerId);
    });
    canvas.addEventListener("pointerup", (e) => onPointerUp(e.pointerId));
    canvas.addEventListener("pointercancel", (e) => onPointerUp(e.pointerId));
  }

  // ---------------- الجير ----------------
  function shiftGear(dir) {
    const idx = GEAR_ORDER.indexOf(gear);
    const next = clamp(idx + dir, 0, GEAR_ORDER.length - 1);
    gear = GEAR_ORDER[next];
    if (onGearChange) onGearChange(gear);
  }
  function setGearDirect(g) {
    gear = g;
    if (onGearChange) onGearChange(gear);
  }
  function getGear() { return gear; }

  // ---------------- تحديث كل فريم ----------------
  function update(dt) {
    // ذبذبة الرجوع التلقائي للدركسيون لو مفيش سحب حالياً
    if (!dragging) {
      wheelRotation = damp(wheelRotation, 0, 2.2, dt);
    }
    input.steer = clamp(wheelRotation / degToRad(WHEEL_VISUAL_MAX_DEG), -1, 1);

    const targetGas = gasTouchId !== null ? 1 : 0;
    const targetBrake = brakeTouchId !== null ? 1 : 0;
    const targetClutch = clutchTouchId !== null ? 1 : 0;
    input.throttle = damp(input.throttle, targetGas, 10, dt);
    input.brake = damp(input.brake, targetBrake, 14, dt);
    input.clutch = damp(input.clutch, targetClutch, 9, dt);

    if (wheelRoot) wheelRoot.rotation.z = -wheelRotation;

    if (padNodes.gas) {
      const p = padBasePos.gas;
      padNodes.gas.position.set(p.x, p.y - input.throttle * 0.9, p.z - input.throttle * 0.4);
    }
    if (padNodes.brake) {
      const p = padBasePos.brake;
      padNodes.brake.position.set(p.x, p.y - input.brake * 0.9, p.z - input.brake * 0.4);
    }
    if (padNodes.clutch) {
      const p = padBasePos.clutch;
      padNodes.clutch.position.set(p.x, p.y - input.clutch * 0.9, p.z - input.clutch * 0.4);
    }
  }

  function renderOverlays(renderer) {
    renderer.setScissorTest(true);

    if (wheelScene) {
      renderer.setViewport(wheelViewport.x, wheelViewport.y, wheelViewport.w, wheelViewport.h);
      renderer.setScissor(wheelViewport.x, wheelViewport.y, wheelViewport.w, wheelViewport.h);
      renderer.clearDepth();
      wheelCamera.aspect = wheelViewport.w / wheelViewport.h;
      wheelCamera.updateProjectionMatrix();
      renderer.render(wheelScene, wheelCamera);
    }

    if (pedalScene) {
      renderer.setViewport(pedalViewport.x, pedalViewport.y, pedalViewport.w, pedalViewport.h);
      renderer.setScissor(pedalViewport.x, pedalViewport.y, pedalViewport.w, pedalViewport.h);
      renderer.clearDepth();
      pedalCamera.aspect = pedalViewport.w / pedalViewport.h;
      pedalCamera.updateProjectionMatrix();
      renderer.render(pedalScene, pedalCamera);
    }

    renderer.setScissorTest(false);
  }

  function getInput() { return input; }

  return {
    loadWheelModel, loadPedalModel, layout, bindPointerEvents,
    update, renderOverlays, getInput,
    shiftGear, setGearDirect, getGear,
    set onGearChange(fn) { onGearChange = fn; },
  };
})();
