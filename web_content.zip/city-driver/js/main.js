// ============================================================
// main.js — نقطة انطلاق اللعبة: تجميع كل الأنظمة وحلقة اللعب
// ============================================================
(function () {

  const canvas = document.getElementById("game-canvas");
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.autoClear = false;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(CONFIG.CAM_FOV, 1, 0.1, 600);

  let network = null;
  let carReady = false, wheelReady = false, pedalReady = false;
  let camYaw = 0, camPitch = 0;

  const loadingEl = document.getElementById("loading-screen");
  const loadingText = document.getElementById("loading-text");
  const rotateEl = document.getElementById("rotate-screen");
  const hudEl = document.getElementById("hud");
  const stalledEl = document.getElementById("stalled-banner");

  function setLoadingProgress(msg) { loadingText.textContent = msg; }

  function checkAllReady() {
    if (carReady && wheelReady && pedalReady) {
      loadingEl.style.display = "none";
      hudEl.style.display = "flex";
      lastTime = performance.now();
      requestAnimationFrame(loop);
    }
  }

  // ---------------- تجهيز العالم ----------------
  network = World.init(scene);
  TrafficLights.init(scene, network);
  Traffic.init(scene, network);

  // نقطة بداية العربية - على أول شارع أفقي
  const startX = network.verticalXs[1] + CONFIG.ROAD_WIDTH * 0.25;
  const startZ = network.horizontalZs[1];

  setLoadingProgress("بنحمّل العربية...");
  PlayerCar.load(scene, "assets/compact_sedan.glb", () => {
    const st = PlayerCar.getState();
    st.x = startX; st.z = startZ; st.heading = 0;
    carReady = true;
    setLoadingProgress("بنحمّل عجلة القيادة...");
    checkAllReady();
  }, (err) => {
    setLoadingProgress("في مشكلة في تحميل موديل العربية.");
    console.error(err);
  });

  Controls.loadWheelModel("assets/steering_wheel_classic.glb", () => {
    wheelReady = true;
    setLoadingProgress("بنحمّل الدواسات...");
    checkAllReady();
  }, (err) => {
    setLoadingProgress("في مشكلة في تحميل موديل الدركسيون.");
    console.error(err);
  });
  Controls.loadPedalModel([
    "assets/pedals_part1.glb",
    "assets/pedals_part2.glb",
    "assets/pedals_part3.glb"
  ], () => {
    pedalReady = true;
    checkAllReady();
  }, (err) => {
    setLoadingProgress("في مشكلة في تحميل موديل الدواسات.");
    console.error(err);
  });

  // ---------------- الجير - أزرار الواجهة ----------------
  const gearButtonsEl = document.getElementById("gear-buttons");
  const gearLabelEl = document.getElementById("gear-label");
  ["R", "N", "1", "2", "3", "4", "5"].forEach((g) => {
    const btn = document.createElement("button");
    btn.className = "gear-btn";
    btn.textContent = g;
    btn.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      const input = Controls.getInput();
      if (input.clutch > 0.45 || g === "N") {
        Controls.setGearDirect(g);
        PlayerCar.setGear(g);
      } else {
        flashClutchWarning();
      }
    });
    gearButtonsEl.appendChild(btn);
  });

  let clutchWarnTimeout = null;
  function flashClutchWarning() {
    gearLabelEl.classList.add("warn");
    clearTimeout(clutchWarnTimeout);
    clutchWarnTimeout = setTimeout(() => gearLabelEl.classList.remove("warn"), 350);
  }

  stalledEl.addEventListener("pointerdown", () => {
    PlayerCar.tryStartEngine();
  });

  // ---------------- الأحجام / الاتجاه ----------------
  let logicalW = window.innerWidth, logicalH = window.innerHeight;
  function resize() {
    const portrait = window.innerHeight > window.innerWidth;
    // فيه تحويلة CSS بتقلب الشاشة بصريًا للاندسكيب حتى لو الموبايل قافل الدوران،
    // فالأبعاد "المنطقية" اللي بيشتغل بيها كل حاجة هي المقلوبة مش الخام
    logicalW = portrait ? window.innerHeight : window.innerWidth;
    logicalH = portrait ? window.innerWidth : window.innerHeight;

    renderer.setSize(logicalW, logicalH, false);
    camera.aspect = logicalW / logicalH;
    camera.updateProjectionMatrix();
    Controls.layout(logicalW, logicalH);

    rotateEl.style.display = "none";
  }
  window.addEventListener("resize", resize);
  window.addEventListener("orientationchange", resize);
  resize();

  Controls.bindPointerEvents(canvas);

  // ---------------- كاميرا سينمائية خلف العربية ----------------
  const camPos = new THREE.Vector3(startX, CONFIG.CAM_HEIGHT, startZ - CONFIG.CAM_DISTANCE);
  const camLook = new THREE.Vector3(startX, 1, startZ);

  function updateCamera(dt) {
    const st = PlayerCar.getState();
    const behindX = st.x - Math.sin(st.heading) * CONFIG.CAM_DISTANCE;
    const behindZ = st.z - Math.cos(st.heading) * CONFIG.CAM_DISTANCE;
    const desired = new THREE.Vector3(behindX, CONFIG.CAM_HEIGHT, behindZ);
    camPos.x = damp(camPos.x, desired.x, 5, dt);
    camPos.y = damp(camPos.y, desired.y, 5, dt);
    camPos.z = damp(camPos.z, desired.z, 5, dt);

    const lookX = st.x + Math.sin(st.heading) * CONFIG.CAM_LOOK_AHEAD;
    const lookZ = st.z + Math.cos(st.heading) * CONFIG.CAM_LOOK_AHEAD;
    camLook.x = damp(camLook.x, lookX, 6, dt);
    camLook.y = damp(camLook.y, 1.1, 6, dt);
    camLook.z = damp(camLook.z, lookZ, 6, dt);

    camera.position.copy(camPos);
    camera.lookAt(camLook);
  }

  // ---------------- HUD ----------------
  const speedEl = document.getElementById("speed-value");
  const rpmFillEl = document.getElementById("rpm-fill");
  function updateHUD() {
    const st = PlayerCar.getState();
    const kmh = Math.abs(st.speed) * 3.6;
    speedEl.textContent = Math.round(kmh);
    gearLabelEl.textContent = st.gear;
    const rpmPct = clamp(st.rpm / CONFIG.REDLINE_RPM, 0, 1);
    rpmFillEl.style.width = (rpmPct * 100).toFixed(1) + "%";
    rpmFillEl.style.background = rpmPct > 0.88 ? "#ff4a3f" : "#ffcf4a";
    stalledEl.style.display = st.stalled ? "flex" : "none";

    Array.from(gearButtonsEl.children).forEach((btn) => {
      btn.classList.toggle("active", btn.textContent === st.gear);
    });
  }

  // ---------------- حلقة اللعب ----------------
  let lastTime = performance.now();
  function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min((now - lastTime) / 1000, 0.05);
    lastTime = now;

    Controls.update(dt);
    const input = Controls.getInput();
    PlayerCar.update(dt, input, World.buildingBoxes);
    Traffic.update(dt);
    TrafficLights.update(dt);
    updateCamera(dt);
    updateHUD();

    renderer.clear();
    renderer.setScissorTest(false);
    renderer.setViewport(0, 0, logicalW, logicalH);
    renderer.render(scene, camera);
    Controls.renderOverlays(renderer);
  }
})();
