// ============================================================
// world.js — بناء المدينة: شوارع، مباني، أرصفة، أعمدة نور، إضاءة السماء
// ============================================================
const World = (function () {

  let pitch = CONFIG.BLOCK_SIZE + CONFIG.ROAD_WIDTH;
  let nRoadsX, nRoadsZ, totalExtent;
  let verticalXs = [], horizontalZs = [];
  let intersections = [];       // [{x, z}]
  let buildingBoxes = [];       // THREE.Box3[] عشان التصادم
  let streetlightPositions = [];

  function computeLayout() {
    nRoadsX = CONFIG.BLOCKS_X + 1; // خطوط طولية (على المحور Z)
    nRoadsZ = CONFIG.BLOCKS_Z + 1; // خطوط عرضية (على المحور X)
    totalExtent = pitch * Math.max(CONFIG.BLOCKS_X, CONFIG.BLOCKS_Z);
    verticalXs = [];
    for (let i = 0; i < nRoadsX; i++) verticalXs.push(i * pitch);
    horizontalZs = [];
    for (let j = 0; j < nRoadsZ; j++) horizontalZs.push(j * pitch);
    intersections = [];
    for (const x of verticalXs) for (const z of horizontalZs) intersections.push({ x, z });
  }

  function createGround(scene) {
    const margin = pitch * 1.5;
    const size = (Math.max(CONFIG.BLOCKS_X, CONFIG.BLOCKS_Z)) * pitch + margin * 2;
    const tex = makeSidewalkTexture();
    tex.repeat.set(size / 4, size / 4);
    const geo = new THREE.PlaneGeometry(size, size);
    const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 1, metalness: 0 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(totalExtent * 0.5 - pitch * 0.5, -0.02, totalExtent * 0.5 - pitch * 0.5);
    mesh.receiveShadow = true;
    scene.add(mesh);
  }

  function createRoads(scene) {
    const span = (nRoadsZ - 1) * pitch + 4;
    const spanX = (nRoadsX - 1) * pitch + 4;

    const matH = new THREE.MeshStandardMaterial({ map: makeRoadTexture(spanX / 6), roughness: 0.9 });
    for (const z of horizontalZs) {
      const geo = new THREE.PlaneGeometry(spanX, CONFIG.ROAD_WIDTH);
      const mesh = new THREE.Mesh(geo, matH);
      mesh.rotation.x = -Math.PI / 2;
      mesh.position.set(spanX / 2 - 2, 0, z);
      mesh.receiveShadow = true;
      scene.add(mesh);
    }

    const matV = new THREE.MeshStandardMaterial({ map: makeRoadTexture(span / 6), roughness: 0.9 });
    for (const x of verticalXs) {
      const geo = new THREE.PlaneGeometry(CONFIG.ROAD_WIDTH, span);
      const mesh = new THREE.Mesh(geo, matV);
      mesh.rotation.x = -Math.PI / 2;
      mesh.rotation.z = Math.PI / 2;
      mesh.position.set(x, 0.005, span / 2 - 2);
      mesh.receiveShadow = true;
      scene.add(mesh);
    }
  }

  const BUILDING_COLORS = [0xb8c4cc, 0xcdbfa5, 0x9fb0b8, 0xc9a37a, 0xaeb8c2, 0xb0a08f, 0x8fa3ad];

  function createBuildings(scene) {
    const boxGeo = new THREE.BoxGeometry(1, 1, 1);
    buildingBoxes = [];
    for (let bi = 0; bi < CONFIG.BLOCKS_X; bi++) {
      for (let bj = 0; bj < CONFIG.BLOCKS_Z; bj++) {
        const cx = verticalXs[bi] + pitch / 2;
        const cz = horizontalZs[bj] + pitch / 2;
        const usable = CONFIG.BLOCK_SIZE - 6;
        const count = 1 + Math.floor(Math.random() * 3);
        const cols = count > 1 ? 2 : 1;
        const cellW = usable / cols;
        for (let k = 0; k < count; k++) {
          const w = cellW * (0.62 + Math.random() * 0.3);
          const d = cellW * (0.62 + Math.random() * 0.3);
          const h = 6 + Math.random() * 26;
          const offX = (k % cols) * cellW - usable / 2 + cellW / 2;
          const offZ = Math.floor(k / cols) * cellW - usable / 2 + cellW / 2;
          const px = cx + offX + (Math.random() - 0.5) * 2;
          const pz = cz + offZ + (Math.random() - 0.5) * 2;

          const color = BUILDING_COLORS[Math.floor(Math.random() * BUILDING_COLORS.length)];
          const winTex = makeWindowTexture(
            "#" + new THREE.Color(color).getHexString(),
            Math.random() > 0.5 ? "#ffe9a8" : "#bfe4ff",
            4, Math.max(3, Math.round(h / 3))
          );
          winTex.repeat.set(1, 1);
          const mat = new THREE.MeshStandardMaterial({ map: winTex, roughness: 0.75, metalness: 0.15 });
          const mesh = new THREE.Mesh(boxGeo, mat);
          mesh.scale.set(w, h, d);
          mesh.position.set(px, h / 2, pz);
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          scene.add(mesh);

          const box = new THREE.Box3().setFromObject(mesh);
          buildingBoxes.push(box);
        }
      }
    }
  }

  function createStreetlight(scene, x, z, rotY) {
    const group = new THREE.Group();
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.5, metalness: 0.6 });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 4.6, 8), poleMat);
    pole.position.y = 2.3;
    pole.castShadow = true;
    group.add(pole);

    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.1, 6), poleMat);
    arm.rotation.z = Math.PI / 2.3;
    arm.position.set(0.45, 4.5, 0);
    group.add(arm);

    const headMat = new THREE.MeshStandardMaterial({ color: 0x1c1e21, roughness: 0.4 });
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.16, 0.22), headMat);
    head.position.set(0.95, 4.85, 0);
    group.add(head);

    const lampMat = new THREE.MeshStandardMaterial({
      color: 0xfff3c9, emissive: 0xffdf8a, emissiveIntensity: 1.4,
    });
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), lampMat);
    lamp.position.set(0.95, 4.76, 0);
    group.add(lamp);

    const pl = new THREE.PointLight(0xffdf9a, 1.1, 11, 2);
    pl.position.set(0.95, 4.7, 0);
    group.add(pl);

    group.position.set(x, 0, z);
    group.rotation.y = rotY;
    scene.add(group);
    streetlightPositions.push({ x, z });
  }

  function createStreetlights(scene) {
    const offset = CONFIG.ROAD_WIDTH / 2 + 0.6;
    for (const z of horizontalZs) {
      const spanX = (nRoadsX - 1) * pitch;
      for (let x = 4; x < spanX; x += CONFIG.STREETLIGHT_SPACING) {
        createStreetlight(scene, x, z + offset, Math.PI);
        createStreetlight(scene, x + CONFIG.STREETLIGHT_SPACING / 2, z - offset, 0);
      }
    }
  }

  function setupSkyAndLight(scene) {
    // إضاءة غروب دافية - شكل سينمائي
    scene.background = new THREE.Color(0xf3c98a);
    scene.fog = new THREE.Fog(0xf0b979, 60, 260);

    const hemi = new THREE.HemisphereLight(0xffd9a0, 0x2b2f36, 0.65);
    scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xffe0b0, 1.35);
    sun.position.set(-80, 60, -40);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -120;
    sun.shadow.camera.right = 120;
    sun.shadow.camera.top = 120;
    sun.shadow.camera.bottom = -120;
    sun.shadow.camera.far = 300;
    sun.shadow.bias = -0.0008;
    scene.add(sun);

    const fill = new THREE.DirectionalLight(0x8fb0ff, 0.35);
    fill.position.set(60, 40, 80);
    scene.add(fill);
  }

  function init(scene) {
    computeLayout();
    setupSkyAndLight(scene);
    createGround(scene);
    createRoads(scene);
    createBuildings(scene);
    createStreetlights(scene);
    return {
      pitch, verticalXs, horizontalZs, intersections, totalExtent,
      buildingBoxes,
    };
  }

  return { init, get buildingBoxes() { return buildingBoxes; } };
})();
