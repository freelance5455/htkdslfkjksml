LA CASA DE LAS 3 AM — PAQUETE LISTO PARA EMPAQUETAR EN ANDROID

Contenido:
- www/index.html: versión actual del juego V4 3D.
- manifest.json: nombre, pantalla completa y orientación horizontal.
- ICON_NOTE.txt: nota sobre el icono.

IMPORTANTE PARA EL EMPAQUETADO:
- La app necesita Internet para cargar Three.js y PeerJS desde sus CDN.
- La función de micrófono necesita permiso de micrófono y un WebView/origen seguro que permita getUserMedia.
- El multijugador usa PeerJS y necesita Internet.
- Para Google Play se debe generar AAB y configurar el permiso RECORD_AUDIO y acceso a Internet en el envoltorio Android.
- Este paquete NO es todavía un APK/AAB; es el contenido web preparado para convertirlo sin reconstruir el juego.
