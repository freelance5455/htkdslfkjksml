const DEFAULT_SHORTCUTS = [
  {name:"Google",url:"https://www.google.com",icon:"G"},
  {name:"YouTube",url:"https://m.youtube.com",icon:"▶"},
  {name:"WhatsApp",url:"https://web.whatsapp.com",icon:"◉"},
  {name:"Wikipedia",url:"https://www.wikipedia.org",icon:"W"},
  {name:"Gmail",url:"https://mail.google.com",icon:"✉"},
  {name:"ChatGPT",url:"https://chatgpt.com",icon:"✳"},
  {name:"GitHub",url:"https://github.com",icon:"⌘"},
  {name:"Maps",url:"https://maps.google.com",icon:"⌖"}
];
const $ = id => document.getElementById(id);
let shortcuts = loadShortcuts();
let toastTimer;

function loadShortcuts(){
  try {
    const saved = JSON.parse(localStorage.getItem("lafene-shortcuts"));
    return Array.isArray(saved) ? saved : DEFAULT_SHORTCUTS;
  } catch { return DEFAULT_SHORTCUTS; }
}
function saveShortcuts(){ localStorage.setItem("lafene-shortcuts", JSON.stringify(shortcuts)); }
function updateClock(){
  const now = new Date();
  $("clock").textContent = now.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",hour12:true});
  $("date").textContent = now.toLocaleDateString([], {weekday:"long",month:"long",day:"numeric",year:"numeric"});
  const hour = now.getHours();
  $("greeting").textContent = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
}
function renderShortcuts(filter=""){
  const grid = $("shortcutGrid");
  grid.innerHTML = "";
  const list = shortcuts.filter(item => item.name.toLowerCase().includes(filter.toLowerCase()));
  $("shortcutCount").textContent = `${shortcuts.length} shortcut${shortcuts.length===1?"":"s"}`;
  if(!list.length){
    grid.innerHTML = `<div class="empty-state">No shortcuts found. Add a website or change your search.</div>`;
    return;
  }
  list.forEach((item,index)=>{
    const button=document.createElement("button");
    button.className="shortcut";
    button.type="button";
    button.innerHTML=`<span class="shortcut-icon"></span><span class="shortcut-name"></span>`;
    button.querySelector(".shortcut-icon").textContent=item.icon || item.name.slice(0,1).toUpperCase();
    button.querySelector(".shortcut-name").textContent=item.name;
    button.addEventListener("click",()=>openShortcut(item));
    button.addEventListener("contextmenu",event=>{
      event.preventDefault();
      if(confirm(`Remove ${item.name} from your shortcuts?`)){
        shortcuts=shortcuts.filter((_,i)=>i!==index); saveShortcuts(); renderShortcuts($("searchInput").value);
        showToast(`${item.name} removed`);
      }
    });
    grid.appendChild(button);
  });
}
function openShortcut(item){
  try { window.open(item.url,"_blank","noopener"); }
  catch { location.href=item.url; }
}
function showToast(message){
  $("toast").textContent=message; $("toast").classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2400);
}
function openModal(title,html){
  $("modalTitle").textContent=title; $("modalContent").innerHTML=html; $("modalBackdrop").hidden=false;
}
function closeModal(){ $("modalBackdrop").hidden=true; }
function showAddForm(){
  openModal("Add a shortcut",`
    <form id="addForm">
      <div class="field"><label for="shortcutName">Website name</label><input id="shortcutName" maxlength="24" placeholder="Example: My School Portal" required></div>
      <div class="field"><label for="shortcutUrl">Website address</label><input id="shortcutUrl" type="url" placeholder="https://example.com" required></div>
      <div class="field"><label for="shortcutIcon">Icon letter or symbol</label><input id="shortcutIcon" maxlength="2" placeholder="A"></div>
      <div class="form-actions"><button class="primary" type="submit">Save shortcut</button><button class="secondary" type="button" id="cancelAdd">Cancel</button></div>
    </form>`);
  $("cancelAdd").onclick=closeModal;
  $("addForm").onsubmit=e=>{
    e.preventDefault();
    const name=$("shortcutName").value.trim();
    let url=$("shortcutUrl").value.trim();
    if(!/^https?:\/\//i.test(url)) url="https://"+url;
    try { new URL(url); } catch { showToast("Please enter a valid website address"); return; }
    shortcuts.push({name,url,icon:$("shortcutIcon").value.trim() || name.slice(0,1).toUpperCase()});
    saveShortcuts(); renderShortcuts(); closeModal(); showToast("Shortcut added");
  };
}
function applyCustomization(){
  const prefs = JSON.parse(localStorage.getItem("lafene-customization") || "{}");
  const grid = $("shortcutGrid");
  grid.classList.remove("decorated","plain","round","squircle","square","no-labels");
  grid.classList.add(prefs.decoration || "decorated");
  grid.classList.add(prefs.shape || "squircle");
  if(prefs.labels===false) grid.classList.add("no-labels");
  document.documentElement.style.setProperty("--launcher-icon-size", `${prefs.iconSize || 58}px`);
  document.documentElement.style.setProperty("--launcher-icon-radius", `${prefs.shape==="round" ? 50 : prefs.shape==="square" ? 9 : 25}%`);
  if(prefs.wallpaper){
    document.body.style.backgroundImage=`linear-gradient(rgba(243,246,252,.88),rgba(243,246,252,.88)),url("${prefs.wallpaper}")`;
    document.body.style.backgroundSize="cover";
    document.body.style.backgroundAttachment="fixed";
  } else {
    document.body.style.backgroundImage="";
  }
}
function showSettings(){
  const prefs=JSON.parse(localStorage.getItem("lafene-customization")||"{}");
  openModal("Launcher settings",`
    <div class="settings-row"><span>Appearance</span><select id="themeChoice"><option value="light">Light</option><option value="dark">Dark</option></select></div>
    <div class="settings-row"><span>Icon decoration</span><select id="iconDecoration"><option value="decorated">Decorated</option><option value="plain">Minimal</option></select></div>
    <div class="settings-row"><span>Icon shape</span><select id="iconShape"><option value="squircle">Rounded square</option><option value="round">Circle</option><option value="square">Soft square</option></select></div>
    <div class="field"><label for="iconSize">Icon size: <strong id="iconSizeValue">${prefs.iconSize||58}px</strong></label><div class="range-line"><input id="iconSize" type="range" min="42" max="82" value="${prefs.iconSize||58}"></div></div>
    <div class="settings-row"><span>Show shortcut names</span><input id="showLabels" type="checkbox" ${prefs.labels===false?"":"checked"}></div>
    <div class="field"><label for="wallpaperFile">Choose a wallpaper image</label><input id="wallpaperFile" type="file" accept="image/*"></div>
    <div class="form-actions"><button class="secondary" id="removeWallpaper" type="button">Remove wallpaper</button></div>
    <div class="settings-row"><span>Search provider</span><select id="searchProvider"><option value="google">Google</option><option value="bing">Bing</option></select></div>
    <div class="settings-row"><span>Set as default launcher</span><button class="secondary" id="defaultLauncherInfo" type="button">Learn how</button></div>
    <p class="setting-note">Important: this web edition runs inside a browser or WebView. It cannot request Android's default Home-app role by itself. That requires a native Android wrapper with the HOME intent filter and Android's system default-app selection flow.</p>
    <div class="settings-row"><span>App version</span><strong style="font-size:11px;color:var(--muted)">1.1.0</strong></div>
    <div class="form-actions"><button class="secondary" id="resetShortcuts" type="button">Restore default shortcuts</button><button class="secondary" id="resetDesign" type="button">Reset design</button></div>
    <div style="margin-top:20px;padding-top:15px;border-top:1px solid var(--line)">
      <p class="eyebrow">DEVELOPER INFORMATION</p>
      <h3 style="margin:4px 0 10px;color:var(--navy);font-size:16px">Abdul Kareem Muhammad Lafene</h3>
      <p style="font-size:12px;color:var(--muted);line-height:1.7;margin:0 0 9px">Founder and developer at Lafene Tech Hub. Interested in web and mobile development, programming, UI/UX design, graphic design, logo and flyer design, video editing and production, animation, visual effects (VFX), computer technology, and software development.</p>
      <p style="font-size:12px;margin:0 0 6px"><strong style="color:var(--navy)">Email:</strong> <a href="mailto:Lafenetechhub@gmail.com">Lafenetechhub@gmail.com</a></p>
      <p style="font-size:12px;margin:0;color:var(--muted)">LAFENE TECH HUB · Kagara, Niger State, Nigeria</p>
    </div>`);
  $("themeChoice").value=document.body.classList.contains("dark")?"dark":"light";
  $("themeChoice").onchange=e=>setTheme(e.target.value);
  $("searchProvider").value=localStorage.getItem("lafene-search")||"google";
  $("searchProvider").onchange=e=>localStorage.setItem("lafene-search",e.target.value);
  $("iconDecoration").value=prefs.decoration||"decorated";
  $("iconShape").value=prefs.shape||"squircle";
  $("showLabels").onchange=e=>saveCustomization({labels:e.target.checked});
  $("iconDecoration").onchange=e=>saveCustomization({decoration:e.target.value});
  $("iconShape").onchange=e=>saveCustomization({shape:e.target.value});
  $("iconSize").oninput=e=>{$("iconSizeValue").textContent=e.target.value+"px";saveCustomization({iconSize:Number(e.target.value)});};
  $("wallpaperFile").onchange=e=>{
    const file=e.target.files[0]; if(!file)return;
    if(file.size>2*1024*1024){showToast("Choose an image under 2 MB to save phone storage");return;}
    const reader=new FileReader();
    reader.onload=()=>{saveCustomization({wallpaper:reader.result});showToast("Wallpaper saved on this device");};
    reader.readAsDataURL(file);
  };
  $("removeWallpaper").onclick=()=>{saveCustomization({wallpaper:""});showToast("Wallpaper removed");};
  $("defaultLauncherInfo").onclick=()=>alert("A browser-based WebView app cannot become Android's Home app by itself. The APK package must include native Android HOME and DEFAULT intent filters and request the system Home role. We can add this only if APKForge supports the required native launcher configuration.");
  $("resetShortcuts").onclick=()=>{
    if(confirm("Restore the original shortcuts?")){shortcuts=[...DEFAULT_SHORTCUTS];saveShortcuts();renderShortcuts();showToast("Default shortcuts restored");}
  };
  $("resetDesign").onclick=()=>{
    if(confirm("Reset appearance and customization?")){
      localStorage.removeItem("lafene-customization");localStorage.removeItem("lafene-theme");
      setTheme("light");applyCustomization();showToast("Design reset");showSettings();
    }
  };
}
function saveCustomization(changes){
  const prefs=JSON.parse(localStorage.getItem("lafene-customization")||"{}");
  Object.assign(prefs,changes);localStorage.setItem("lafene-customization",JSON.stringify(prefs));applyCustomization();
}
$("searchForm").addEventListener("submit",e=>{
  e.preventDefault();
  const query=$("searchInput").value.trim();
  if(!query){showToast("Type something to search");return;}
  const match=shortcuts.find(item=>item.name.toLowerCase()===query.toLowerCase());
  if(match){openShortcut(match);return;}
  const provider=localStorage.getItem("lafene-search")||"google";
  const base=provider==="bing"?"https://www.bing.com/search?q=":"https://www.google.com/search?q=";
  window.open(base+encodeURIComponent(query),"_blank","noopener");
});
$("searchInput").addEventListener("input",e=>renderShortcuts(e.target.value));
$("addShortcutOpen").onclick=showAddForm;
$("settingsOpen").onclick=showSettings;
$("customizeOpen").onclick=showSettings;
$("modalClose").onclick=closeModal;
$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))closeModal();});
setTheme(localStorage.getItem("lafene-theme")||"light");
updateClock(); setInterval(updateClock,1000); renderShortcuts(); applyCustomization();
if("serviceWorker" in navigator && location.protocol.startsWith("http")){
  window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));
}
