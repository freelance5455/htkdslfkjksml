LAFENE SMART LAUNCHER — WEB EDITION
Developer: Lafene Tech Hub
Founder: Abdul Kareem Muhammad Lafene
Version: 1.1.0
Contact: Lafenetechhub@gmail.com

FEATURES
- Digital clock, date and greeting
- Search using Google or Bing
- Add and remove website shortcuts
- Light and dark appearance
- Icon decoration styles: decorated or minimal
- Icon shapes: rounded square, circle and soft square
- Adjustable shortcut icon size
- Show/hide shortcut labels
- User-selected wallpaper (image up to 2 MB)
- Local storage for settings and shortcuts
- Developer profile and contact email
- PWA manifest and offline service-worker cache

FILES
- index.html: page structure
- style.css: responsive interface and appearance
- script.js: functionality and personalization
- manifest.json: PWA metadata
- service-worker.js: offline caching
- icons/: app icons

TESTING
1. Extract this ZIP.
2. Open the folder in Acode or SPCK Editor.
3. Preview index.html in a browser for basic interface testing.
4. For PWA installation and service-worker testing, publish to an HTTPS host.
5. Test on your phone before packaging with APKForge.

IMPORTANT ANDROID LIMITATIONS
This is a web-based launcher interface, not a native Android HOME launcher.
Website shortcuts open web addresses; the website cannot automatically enumerate
or launch every installed Android app.
The "Set as default launcher" setting explains that native Android HOME and
DEFAULT intent filters plus the Android system Home-role selection flow are
required. A WebView wrapper alone does not provide these capabilities.
APKForge's current supported configuration must be checked before promising
native HOME launcher support.
