
/* ==============================
   HELPERS
============================== */

function $(id){
  return document.getElementById(id);
}

function showToast(text){
  const toast=$("toast");
  toast.textContent=text;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer=setTimeout(function(){
    toast.classList.remove("show");
  },1800);
}


/* ==============================
   AUTH DATA
============================== */

function getUsers(){
  try{
    return JSON.parse(localStorage.getItem("instanovaUsers") || "[]");
  }catch(e){
    return [];
  }
}

function saveUsers(users){
  localStorage.setItem("instanovaUsers",JSON.stringify(users));
}


/* ==============================
   AUTH SWITCH
============================== */

$("showRegister").onclick=function(){
  $("loginBox").classList.add("hidden");
  $("registerBox").classList.remove("hidden");
};

$("showLogin").onclick=function(){
  $("registerBox").classList.add("hidden");
  $("loginBox").classList.remove("hidden");
};


/* ==============================
   REGISTER
============================== */

$("registerBtn").onclick=function(){

  const username=$("registerUsername").value.trim();
  const email=$("registerEmail").value.trim();
  const password=$("registerPassword").value;
  const confirm=$("registerConfirm").value;
  const error=$("registerError");

  error.textContent="";

  if(username.length<3){
    error.textContent="Username kamida 3 ta belgi bo'lsin.";
    return;
  }
  if(!email.includes("@")){
    error.textContent="Email/Gmail noto'g'ri.";
    return;
  }
  if(password.length<4){
    error.textContent="Password kamida 4 ta belgi bo'lsin.";
    return;
  }
  if(password!==confirm){
    error.textContent="Passwordlar bir xil emas.";
    return;
  }

  const users=getUsers();

  const exists=users.some(function(user){
    return user.email.toLowerCase()===email.toLowerCase();
  });
  if(exists){
    error.textContent="Bu email bilan akkaunt mavjud.";
    return;
  }

  const userExists=users.some(function(user){
    return user.username.toLowerCase()===username.toLowerCase();
  });
  if(userExists){
    error.textContent="Bu username band.";
    return;
  }

  users.push({username:username,email:email,password:password,name:username});
  saveUsers(users);

  localStorage.setItem("instanovaCurrentUser",email);
  startApp();
  showToast("Akkaunt yaratildi! 🎉");

};


/* ==============================
   LOGIN
============================== */

$("loginBtn").onclick=function(){

  const email=$("loginEmail").value.trim();
  const password=$("loginPassword").value;
  const error=$("loginError");

  error.textContent="";

  const users=getUsers();

  const user=users.find(function(item){
    return item.email.toLowerCase()===email.toLowerCase() && item.password===password;
  });

  if(!user){
    error.textContent="Email yoki password noto'g'ri.";
    return;
  }

  localStorage.setItem("instanovaCurrentUser",user.email);
  startApp();
  showToast("Welcome back! 👋");

};


/* ==============================
   USER / PROFILE EXTRAS
============================== */

function currentUser(){
  const email=localStorage.getItem("instanovaCurrentUser");
  if(!email) return null;
  const users=getUsers();
  return users.find(function(u){ return u.email===email; }) || null;
}

function getProfileExtra(email){
  try{
    return JSON.parse(localStorage.getItem("instanovaProfile_"+email)||"{}");
  }catch(e){
    return {};
  }
}
function saveProfileExtra(email,data){
  localStorage.setItem("instanovaProfile_"+email,JSON.stringify(data));
}

function avatarUrl(username){
  if(username==="ai_bot"){
    return "https://api.dicebear.com/7.x/bottts/svg?seed=instanova-ai";
  }
  return "https://i.pravatar.cc/150?u="+encodeURIComponent(username);
}

function displayName(username){
  return username==="ai_bot" ? "AI Yordamchi 🤖" : username;
}

function getFollowing(email){
  try{
    return JSON.parse(localStorage.getItem("instanovaFollowing_"+email)||"[]");
  }catch(e){
    return [];
  }
}
function saveFollowing(email,list){
  localStorage.setItem("instanovaFollowing_"+email,JSON.stringify(list));
}


/* ==============================
   DEMO USERS
============================== */

const DEMO_USERS=[
  {username:"sara_art",name:"Sara Art",bio:"Digital artist 🎨"},
  {username:"mike_travel",name:"Mike Travel",bio:"Exploring the world 🌍"},
  {username:"techguru",name:"Tech Guru",bio:"Coding & Gadgets 💻"},
  {username:"naturelover",name:"Nature Lover",bio:"Mountains & rivers 🏞️"},
  {username:"foodie_life",name:"Foodie Life",bio:"Tasty adventures 🍜"}
];


/* ==============================
   POSTS
============================== */

let posts=[];
let pendingPostImage=null;
let pendingEditAvatar=null;
let activeCommentPostId=null;
let storyTimer=null;

function seedPosts(){

  const captions=[
    "Bugungi kayfiyat ✨",
    "Yangi loyiha ustida ishlayapman 💻",
    "Tabiat go'zalligi 🌄",
    "Do'stlar bilan ajoyib kun 🎉",
    "Yangi retsept sinovdan o'tdi 🍲"
  ];

  const seeded=DEMO_USERS.map(function(u,i){
    return {
      id:"seed"+i,
      username:u.username,
      avatar:avatarUrl(u.username),
      image:"https://picsum.photos/seed/"+u.username+"/600/600",
      caption:captions[i]||"Salom InstaNova! 👋",
      time:(i+1)+" soat oldin",
      likes:[],
      comments:[]
    };
  });

  savePosts(seeded);
  return seeded;
}

function getPosts(){
  try{
    const stored=JSON.parse(localStorage.getItem("instanovaPosts")||"null");
    return stored || seedPosts();
  }catch(e){
    return seedPosts();
  }
}
function savePosts(list){
  localStorage.setItem("instanovaPosts",JSON.stringify(list));
}

function getSaved(email){
  try{
    return JSON.parse(localStorage.getItem("instanovaSaved_"+email)||"[]");
  }catch(e){
    return [];
  }
}
function saveSaved(email,list){
  localStorage.setItem("instanovaSaved_"+email,JSON.stringify(list));
}


/* ==============================
   START APP
============================== */

function startApp(){

  const user=currentUser();
  if(!user) return;

  $("authPage").style.display="none";
  $("app").style.display="block";

  posts=getPosts();

  applyProfileToHeader(user);

  renderStories();
  renderFeed();
  renderExplore();
  renderReels();
  renderMessages();
  renderNotifications();
  renderProfile();
  renderSearch("");

  applyTheme();

}

function applyProfileToHeader(user){
  const extra=getProfileExtra(user.email);
  const avatar=extra.avatar||avatarUrl(user.username);
  const name=extra.name||user.name||user.username;
  const bio=extra.bio||"Coding • Design • Technology 💻";

  $("sideAvatar").src=avatar;
  $("mobileAvatar").src=avatar;
  $("profileAvatar").src=avatar;
  $("profileUsername").textContent=user.username;
  $("profileBio").innerHTML="<b>"+name+"</b><br>"+bio;
}


/* ==============================
   NAVIGATION
============================== */

document.querySelectorAll(".navBtn").forEach(function(btn){
  btn.addEventListener("click",function(){
    goToPage(btn.getAttribute("data-page"));
  });
});

function goToPage(page){
  document.querySelectorAll(".page").forEach(function(p){
    p.classList.toggle("active",p.id===page);
  });
  document.querySelectorAll(".navBtn").forEach(function(b){
    b.classList.toggle("active",b.getAttribute("data-page")===page);
  });
  window.scrollTo(0,0);
}


/* ==============================
   CREATE POST
============================== */

$("createBtn").addEventListener("click",openPostModal);
$("mobileCreate").addEventListener("click",openPostModal);
$("closePost").addEventListener("click",closePostModal);

function openPostModal(){
  $("postText").value="";
  pendingPostImage=null;
  $("postImageInput").value="";
  $("postImagePreview").classList.add("hidden");
  $("postImagePreview").src="";
  $("postModal").classList.add("show");
}
function closePostModal(){
  $("postModal").classList.remove("show");
}

$("postImageInput").addEventListener("change",function(e){
  const file=e.target.files[0];
  if(!file) return;
  const reader=new FileReader();
  reader.onload=function(ev){
    pendingPostImage=ev.target.result;
    $("postImagePreview").src=pendingPostImage;
    $("postImagePreview").classList.remove("hidden");
  };
  reader.readAsDataURL(file);
});

$("publishPost").addEventListener("click",function(){

  const text=$("postText").value.trim();

  if(!text && !pendingPostImage){
    showToast("Matn yoki rasm qo'shing ✍️");
    return;
  }

  const user=currentUser();
  const extra=getProfileExtra(user.email);
  const avatar=extra.avatar||avatarUrl(user.username);

  posts.unshift({
    id:"p"+Date.now(),
    username:user.username,
    avatar:avatar,
    image:pendingPostImage,
    caption:text,
    time:"hozir",
    likes:[],
    comments:[]
  });

  savePosts(posts);

  closePostModal();
  renderFeed();
  renderProfile();

  showToast("Post joylandi! 🎉");

});


/* ==============================
   FEED
============================== */

function renderFeed(){

  const user=currentUser();
  const feed=$("feed");
  feed.innerHTML="";

  posts.forEach(function(post){

    const liked=user && post.likes.indexOf(user.username)>-1;
    const saved=user && getSaved(user.email).indexOf(post.id)>-1;
    const isMine=user && post.username===user.username;
    const following=user && getFollowing(user.email).indexOf(post.username)>-1;

    const div=document.createElement("div");
    div.className="post";
    div.setAttribute("data-id",post.id);

    div.innerHTML=
      '<div class="postHeader">'+
        '<img src="'+post.avatar+'">'+
        '<div>'+
          '<div class="postUser">'+post.username+'</div>'+
          '<div class="postTime">'+post.time+'</div>'+
        '</div>'+
        (isMine ? '' : '<button class="followBtn '+(following?'following':'')+'" data-user="'+post.username+'">'+(following?'Following':'Follow')+'</button>')+
        '<button class="postMore" data-id="'+post.id+'">⋯</button>'+
      '</div>'+
      (post.image ? ('<img class="postImage" src="'+post.image+'">') : '')+
      '<div class="actions">'+
        '<button class="like '+(liked?'active':'')+'" data-id="'+post.id+'">'+(liked?'❤️':'🤍')+'</button>'+
        '<button class="comment" data-id="'+post.id+'">💬</button>'+
        '<button class="save '+(saved?'active':'')+'" data-id="'+post.id+'">'+(saved?'🔖':'📑')+'</button>'+
      '</div>'+
      '<div class="likes">'+post.likes.length+' likes</div>'+
      (post.caption ? ('<div class="caption"><b>'+post.username+'</b>'+post.caption+'</div>') : '')+
      '<div class="commentsInfo" data-id="'+post.id+'">'+
        (post.comments.length ? ("View all "+post.comments.length+" comments") : "No comments yet")+
      '</div>'+
      '<div class="commentBox">'+
        '<input placeholder="Add a comment..." data-id="'+post.id+'">'+
        '<button class="sendInlineComment" data-id="'+post.id+'">Post</button>'+
      '</div>';

    feed.appendChild(div);

  });

}

$("feed").addEventListener("click",function(e){

  const user=currentUser();
  if(!user) return;

  const likeBtn=e.target.closest(".like");
  if(likeBtn){
    toggleLike(likeBtn.getAttribute("data-id"),user);
    return;
  }

  const saveBtn=e.target.closest(".save");
  if(saveBtn){
    toggleSave(saveBtn.getAttribute("data-id"),user);
    return;
  }

  const followBtn=e.target.closest(".followBtn");
  if(followBtn){
    toggleFollow(followBtn.getAttribute("data-user"),user);
    return;
  }

  const moreBtn=e.target.closest(".postMore");
  if(moreBtn){
    handlePostMore(moreBtn.getAttribute("data-id"),user);
    return;
  }

  const commentInfo=e.target.closest(".commentsInfo");
  if(commentInfo){
    openCommentModal(commentInfo.getAttribute("data-id"));
    return;
  }

  const commentBtn=e.target.closest(".comment");
  if(commentBtn){
    openCommentModal(commentBtn.getAttribute("data-id"));
    return;
  }

  const sendInline=e.target.closest(".sendInlineComment");
  if(sendInline){
    const id=sendInline.getAttribute("data-id");
    const input=document.querySelector('.commentBox input[data-id="'+id+'"]');
    addComment(id,input.value.trim(),user);
    return;
  }

});

$("feed").addEventListener("dblclick",function(e){

  const img=e.target.closest(".postImage");
  if(!img) return;

  const user=currentUser();
  if(!user) return;

  const postDiv=img.closest(".post");
  const id=postDiv.getAttribute("data-id");
  const post=posts.find(function(p){ return p.id===id; });
  if(!post) return;

  if(post.likes.indexOf(user.username)===-1){
    post.likes.push(user.username);
    savePosts(posts);

    const likeBtn=postDiv.querySelector(".like");
    likeBtn.classList.add("active");
    likeBtn.textContent="❤️";

    const likesEl=postDiv.querySelector(".likes");
    likesEl.textContent=post.likes.length+" likes";
  }

  showHeartBurst(postDiv);

});

$("feed").addEventListener("keydown",function(e){
  if(e.key==="Enter" && e.target.matches(".commentBox input")){
    const user=currentUser();
    addComment(e.target.getAttribute("data-id"),e.target.value.trim(),user);
  }
});

function showHeartBurst(container){
  const heart=document.createElement("div");
  heart.className="heartBurst";
  heart.textContent="❤️";
  container.appendChild(heart);
  setTimeout(function(){ heart.remove(); },800);
}

function toggleLike(id,user){
  const post=posts.find(function(p){ return p.id===id; });
  if(!post) return;
  const idx=post.likes.indexOf(user.username);
  if(idx>-1){ post.likes.splice(idx,1); } else { post.likes.push(user.username); }
  savePosts(posts);
  renderFeed();
}

function toggleSave(id,user){
  const saved=getSaved(user.email);
  const idx=saved.indexOf(id);
  if(idx>-1){
    saved.splice(idx,1);
    showToast("Saqlanganlardan olindi");
  }else{
    saved.push(id);
    showToast("Saqlandi 🔖");
  }
  saveSaved(user.email,saved);
  renderFeed();
}

function toggleFollow(username,user){
  const list=getFollowing(user.email);
  const idx=list.indexOf(username);
  if(idx>-1){
    list.splice(idx,1);
    showToast("Unfollowed "+username);
  }else{
    list.push(username);
    showToast("Following "+username+" ✅");
  }
  saveFollowing(user.email,list);
  renderFeed();
  renderProfile();
}

function handlePostMore(id,user){
  const post=posts.find(function(p){ return p.id===id; });
  if(!post) return;

  if(post.username===user.username){
    if(confirm("Postni o'chirmoqchimisiz?")){
      posts=posts.filter(function(p){ return p.id!==id; });
      savePosts(posts);
      renderFeed();
      renderProfile();
      showToast("Post o'chirildi 🗑️");
    }
  }else{
    showToast("Faqat post egasi o'chira oladi");
  }
}

function addComment(id,text,user){
  if(!text || !user) return;
  const post=posts.find(function(p){ return p.id===id; });
  if(!post) return;
  post.comments.push({username:user.username,text:text});
  savePosts(posts);
  renderFeed();
  if($("commentModal").classList.contains("show")){
    closeCommentModal();
  }
  showToast("Izoh qo'shildi 💬");
}


/* ==============================
   COMMENT MODAL
============================== */

function openCommentModal(id){
  activeCommentPostId=id;
  $("commentText").value="";
  $("commentModal").classList.add("show");
}
function closeCommentModal(){
  $("commentModal").classList.remove("show");
  activeCommentPostId=null;
}

$("closeComment").addEventListener("click",closeCommentModal);

$("sendComment").addEventListener("click",function(){
  const user=currentUser();
  const text=$("commentText").value.trim();
  if(!activeCommentPostId || !text) return;
  addComment(activeCommentPostId,text,user);
});


/* ==============================
   STORIES / STORY VIEWER
============================== */

function renderStories(){

  const user=currentUser();
  const extra=getProfileExtra(user.email);
  const avatar=extra.avatar||avatarUrl(user.username);

  const container=$("stories");
  container.innerHTML="";

  const mine=document.createElement("div");
  mine.className="story";
  mine.innerHTML='<div class="storyRing"><img src="'+avatar+'"></div><span class="storyName">Your story</span>';
  mine.addEventListener("click",function(){
    const myLatest=posts.find(function(p){ return p.username===user.username && p.image; });
    openStory(user.username, myLatest ? myLatest.image : avatar);
  });
  container.appendChild(mine);

  DEMO_USERS.forEach(function(u){
    const el=document.createElement("div");
    el.className="story";
    el.innerHTML='<div class="storyRing"><img src="'+avatarUrl(u.username)+'"></div><span class="storyName">'+u.username+'</span>';
    el.addEventListener("click",function(){
      openStory(u.username,"https://picsum.photos/seed/"+u.username+"story/500/800");
    });
    container.appendChild(el);
  });

}

function openStory(username,imageUrl){
  $("storyAvatar").src=avatarUrl(username);
  $("storyUsername").textContent=username;
  $("storyImage").src=imageUrl;
  $("storyModal").classList.add("show");

  const fill=$("storyProgressFill");
  fill.style.transition="none";
  fill.style.width="0%";

  requestAnimationFrame(function(){
    requestAnimationFrame(function(){
      fill.style.transition="width 4s linear";
      fill.style.width="100%";
    });
  });

  clearTimeout(storyTimer);
  storyTimer=setTimeout(closeStory,4000);
}

function closeStory(){
  $("storyModal").classList.remove("show");
  clearTimeout(storyTimer);
}

$("closeStory").addEventListener("click",closeStory);
$("storyImage").addEventListener("click",closeStory);


/* ==============================
   SEARCH
============================== */

$("searchInput").addEventListener("input",function(){
  renderSearch(this.value.trim().toLowerCase());
});

function renderSearch(query){

  const results=$("searchResults");
  results.innerHTML="";

  const me=currentUser();

  const others=getUsers()
    .filter(function(u){ return !me || u.email!==me.email; })
    .map(function(u){ return {username:u.username}; });

  const allUsers=DEMO_USERS.concat(others);

  const filtered=query
    ? allUsers.filter(function(u){ return u.username.toLowerCase().indexOf(query)>-1; })
    : allUsers;

  if(!filtered.length){
    results.innerHTML='<p style="color:var(--muted);font-size:13px;padding:10px 4px;">Hech kim topilmadi</p>';
    return;
  }

  filtered.forEach(function(u){
    const row=document.createElement("div");
    row.className="searchRow";
    row.innerHTML='<img src="'+avatarUrl(u.username)+'"><b>'+u.username+'</b>';
    row.addEventListener("click",function(){ openChat(u.username); });
    results.appendChild(row);
  });

}


/* ==============================
   EXPLORE / REELS
============================== */

function renderExplore(){
  const grid=$("exploreGrid");
  grid.innerHTML="";
  for(let i=1;i<=12;i++){
    const img=document.createElement("img");
    img.src="https://picsum.photos/seed/explore"+i+"/400/400";
    grid.appendChild(img);
  }
}

/* ==============================
   VIDEOS (YouTube-style)
============================== */

const DEMO_VIDEO_SOURCES=[
  {title:"Big Buck Bunny - qisqa multfilm 🐰",url:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"},
  {title:"Fillar dunyosi 🐘",url:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"},
  {title:"Katta olov sahnasi 🔥",url:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"},
  {title:"Qochish sahnasi 🚗",url:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"},
  {title:"Sintel - qisqa film 🎬",url:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"}
];

function seedVideos(){
  return DEMO_VIDEO_SOURCES.map(function(v,i){
    return {
      id:"v"+i,
      channel:DEMO_USERS[i%DEMO_USERS.length].username,
      title:v.title,
      url:v.url,
      poster:"https://picsum.photos/seed/vid"+i+"/400/700",
      views:Math.floor(Math.random()*9000)+500,
      likes:[],
      comments:[]
    };
  });
}

let videos=seedVideos();
let currentVideoId=null;

function renderReels(){
  const grid=$("reelsGrid");
  grid.innerHTML="";

  videos.forEach(function(v){
    const card=document.createElement("div");
    card.className="videoCard";
    card.innerHTML=
      '<img src="'+v.poster+'">'+
      '<div class="videoPlay">▶️</div>'+
      '<div class="videoCardInfo"><span class="videoCardTitle">'+v.title+'</span>'+v.views.toLocaleString()+' views</div>';
    card.addEventListener("click",function(){ openVideo(v.id); });
    grid.appendChild(card);
  });
}

function openVideo(id){

  const v=videos.find(function(x){ return x.id===id; });
  if(!v) return;

  v.views++;
  currentVideoId=id;

  const player=$("videoPlayer");
  player.pause();
  player.src=v.url;
  player.play().catch(function(){});

  $("videoTitleText").textContent=v.title;
  $("videoChannel").textContent="@"+v.channel;
  $("videoViews").textContent=v.views.toLocaleString()+" views";

  renderVideoLike(v);
  renderVideoSub(v);
  renderVideoComments(v);

  $("videoModal").classList.add("show");
  renderReels();

}

function renderVideoLike(v){
  const user=currentUser();
  const liked=user && v.likes.indexOf(user.username)>-1;
  $("videoLikeBtn").innerHTML=(liked?'❤️':'🤍')+' <span>'+v.likes.length+'</span>';
  $("videoLikeBtn").classList.toggle("liked",liked);
}

function renderVideoSub(v){
  const user=currentUser();
  const subscribed=user && getFollowing(user.email).indexOf(v.channel)>-1;
  $("videoSubBtn").textContent=subscribed?"Subscribed ✓":"Subscribe";
  $("videoSubBtn").classList.toggle("following",subscribed);
}

function renderVideoComments(v){
  const box=$("videoComments");
  box.innerHTML="";
  if(!v.comments.length){
    box.innerHTML='<p style="color:var(--muted);font-size:12px;">Hali izoh yo\'q</p>';
    return;
  }
  v.comments.forEach(function(c){
    const p=document.createElement("p");
    p.style.fontSize="12px";
    p.style.marginBottom="6px";
    p.innerHTML="<b>"+c.username+"</b> "+c.text;
    box.appendChild(p);
  });
}

$("videoLikeBtn").addEventListener("click",function(){
  const user=currentUser();
  const v=videos.find(function(x){ return x.id===currentVideoId; });
  if(!v||!user) return;
  const idx=v.likes.indexOf(user.username);
  if(idx>-1){ v.likes.splice(idx,1); } else { v.likes.push(user.username); }
  renderVideoLike(v);
});

$("videoSubBtn").addEventListener("click",function(){
  const user=currentUser();
  const v=videos.find(function(x){ return x.id===currentVideoId; });
  if(!v||!user) return;
  toggleFollow(v.channel,user);
  renderVideoSub(v);
});

$("videoCommentSend").addEventListener("click",function(){
  const user=currentUser();
  const v=videos.find(function(x){ return x.id===currentVideoId; });
  const text=$("videoCommentInput").value.trim();
  if(!v||!user||!text) return;
  v.comments.push({username:user.username,text:text});
  $("videoCommentInput").value="";
  renderVideoComments(v);
});

$("closeVideo").addEventListener("click",function(){
  $("videoPlayer").pause();
  $("videoModal").classList.remove("show");
});

$("uploadVideoBtn").addEventListener("click",function(){
  $("videoFileInput").click();
});

$("videoFileInput").addEventListener("change",function(e){

  const file=e.target.files[0];
  if(!file) return;

  const user=currentUser();
  const url=URL.createObjectURL(file);
  const title=prompt("Video sarlavhasi:",file.name.replace(/\.[^/.]+$/,""))||file.name;

  videos.unshift({
    id:"uv"+Date.now(),
    channel:user.username,
    title:title,
    url:url,
    poster:"https://picsum.photos/seed/uv"+Date.now()+"/400/700",
    views:0,
    likes:[],
    comments:[]
  });

  renderReels();
  showToast("Video yuklandi 🎬 (faqat shu seansda saqlanadi)");
  e.target.value="";

});


/* ==============================
   MESSAGES / CHAT
============================== */

function getChatPartners(){
  let list;
  try{
    const stored=JSON.parse(localStorage.getItem("instanovaChatPartners")||"null");
    list=stored || DEMO_USERS.map(function(u){ return u.username; });
  }catch(e){
    list=DEMO_USERS.map(function(u){ return u.username; });
  }
  list=list.filter(function(u){ return u!=="ai_bot"; });
  return ["ai_bot"].concat(list);
}
function saveChatPartners(list){
  localStorage.setItem("instanovaChatPartners",JSON.stringify(list));
}

function getChatKey(username){
  const user=currentUser();
  return "instanovaChat_"+user.email+"_"+username;
}
function getChatMessages(username){
  try{
    return JSON.parse(localStorage.getItem(getChatKey(username))||"[]");
  }catch(e){
    return [];
  }
}
function saveChatMessages(username,msgs){
  localStorage.setItem(getChatKey(username),JSON.stringify(msgs));
}

function renderMessages(){

  const list=$("messagesList");
  list.innerHTML="";

  getChatPartners().forEach(function(username){

    const msgs=getChatMessages(username);
    const defaultGreeting=username==="ai_bot" ? "Savolingizni yozing, men yordam beraman 🤖" : "Salom! 👋";
    const last=msgs.length ? msgs[msgs.length-1].text : defaultGreeting;

    const row=document.createElement("div");
    row.className="message";
    row.innerHTML=
      '<img src="'+avatarUrl(username)+'">'+
      '<div class="messageInfo"><b>'+displayName(username)+'</b><p>'+last+'</p></div>';
    row.addEventListener("click",function(){ openChat(username); });

    list.appendChild(row);

  });

}

function openChat(username){

  let partners=getChatPartners();
  if(partners.indexOf(username)===-1){
    partners.unshift(username);
    saveChatPartners(partners);
  }

  $("chatTitle").textContent="Chat: "+displayName(username);
  $("chatHead").textContent=displayName(username);

  renderChatBody(username);
  goToPage("chat");

  if(username==="ai_bot" && getChatMessages(username).length===0){
    showToast("AI yordamchi bilan suhbatlashyapsiz 🤖");
  }

  $("sendMessage").onclick=function(){ sendMessage(username); };
  $("chatInput").onkeydown=function(e){
    if(e.key==="Enter") sendMessage(username);
  };

}

function renderChatBody(username){
  const body=$("chatBody");
  body.innerHTML="";
  getChatMessages(username).forEach(function(m){
    const div=document.createElement("div");
    div.className="msg "+(m.from==="me" ? "me" : "other");
    div.textContent=m.text;
    body.appendChild(div);
  });
  body.scrollTop=body.scrollHeight;
}

function sendMessage(username){

  const input=$("chatInput");
  const text=input.value.trim();
  if(!text) return;

  const msgs=getChatMessages(username);
  msgs.push({from:"me",text:text});
  saveChatMessages(username,msgs);

  input.value="";
  renderChatBody(username);
  renderMessages();

  if(username==="ai_bot"){
    showTyping();

    callAI(text).then(function(reply){
      hideTyping();
      const m2=getChatMessages(username);
      m2.push({from:"them",text:reply});
      saveChatMessages(username,m2);
      renderChatBody(username);
      renderMessages();
    });

    return;
  }

  setTimeout(function(){
    const replies=["Zo'r! 😊","Rozi bo'ldim 👍","Qiziq ekan 🙂","Keyinroq gaplashamiz","Ha albatta!","😄😄"];
    const reply=replies[Math.floor(Math.random()*replies.length)];
    const m2=getChatMessages(username);
    m2.push({from:"them",text:reply});
    saveChatMessages(username,m2);
    renderChatBody(username);
    renderMessages();
  },1200);

}

function showTyping(){
  const body=$("chatBody");
  const div=document.createElement("div");
  div.className="msg other";
  div.id="typingBubble";
  div.textContent="•••";
  body.appendChild(div);
  body.scrollTop=body.scrollHeight;
}
function hideTyping(){
  const el=$("typingBubble");
  if(el) el.remove();
}

/* Real AI reply, powered by Claude. Builds short conversation history
   from this thread so the bot has context. */
async function callAI(userText){

  try{

    const history=getChatMessages("ai_bot").slice(-10).map(function(m){
      return { role: m.from==="me" ? "user" : "assistant", content: m.text };
    });

    const response=await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body:JSON.stringify({
        model:"claude-sonnet-4-6",
        max_tokens:1000,
        system:"Siz InstaNova ilovasidagi do'stona AI yordamchisiz. Qisqa, samimiy va foydali javob bering. Foydalanuvchi qaysi tilda yozsa, o'sha tilda javob bering.",
        messages:history.concat([{ role:"user", content:userText }])
      })
    });

    if(!response.ok){
      return "Kechirasiz, AI xizmatidan javob kelmadi (xatolik "+response.status+"). Bu funksiya faqat Claude ilovasi ichida to'liq ishlaydi.";
    }

    const data=await response.json();

    const text=(data.content||[])
      .map(function(block){ return block.text||""; })
      .join("\n")
      .trim();

    return text || "...";

  }catch(err){
    return "AI xizmatiga ulanib bo'lmadi 😕 Bu funksiya faqat Claude ilovasi ichida ishlaydi.";
  }

}


/* ==============================
   NOTIFICATIONS
============================== */

function renderNotifications(){

  const list=$("notificationList");
  list.innerHTML="";

  const items=[
    {u:"sara_art",text:"sizning postingizni yoqtirdi ❤️"},
    {u:"mike_travel",text:"sizga izoh qoldirdi 💬"},
    {u:"techguru",text:"sizni kuzata boshladi 👤"},
    {u:"naturelover",text:"sizning postingizni yoqtirdi ❤️"},
    {u:"foodie_life",text:"sizga izoh qoldirdi 💬"}
  ];

  items.forEach(function(it){
    const row=document.createElement("div");
    row.className="message";
    row.innerHTML='<img src="'+avatarUrl(it.u)+'"><div class="messageInfo"><b>'+it.u+'</b><p>'+it.text+'</p></div>';
    list.appendChild(row);
  });

}


/* ==============================
   PROFILE
============================== */

function renderProfile(){

  const user=currentUser();
  if(!user) return;

  const myPosts=posts.filter(function(p){ return p.username===user.username; });

  $("postCount").textContent=myPosts.length;
  $("followingCount").textContent=312+getFollowing(user.email).length;

  const grid=$("profileGrid");
  grid.innerHTML="";

  myPosts.forEach(function(p){
    const img=document.createElement("img");
    img.src=p.image || ("https://picsum.photos/seed/"+p.id+"/400/400");
    grid.appendChild(img);
  });

}

$("editBtn").addEventListener("click",function(){

  const user=currentUser();
  const extra=getProfileExtra(user.email);

  pendingEditAvatar=extra.avatar||null;

  $("editAvatarPreview").src=extra.avatar||avatarUrl(user.username);
  $("editNameInput").value=extra.name||user.name||user.username;
  $("editBioInput").value=extra.bio||"Coding • Design • Technology 💻";
  $("editAvatarInput").value="";

  $("editProfileModal").classList.add("show");

});

$("editAvatarInput").addEventListener("change",function(e){
  const file=e.target.files[0];
  if(!file) return;
  const reader=new FileReader();
  reader.onload=function(ev){
    pendingEditAvatar=ev.target.result;
    $("editAvatarPreview").src=pendingEditAvatar;
  };
  reader.readAsDataURL(file);
});

$("closeEditProfile").addEventListener("click",function(){
  $("editProfileModal").classList.remove("show");
});

$("saveEditProfile").addEventListener("click",function(){

  const user=currentUser();

  const data={
    name:$("editNameInput").value.trim()||user.username,
    bio:$("editBioInput").value.trim(),
    avatar:pendingEditAvatar
  };

  saveProfileExtra(user.email,data);
  applyProfileToHeader(user);
  renderStories();

  $("editProfileModal").classList.remove("show");
  showToast("Profil yangilandi ✅");

});


/* ==============================
   THEME
============================== */

function applyTheme(){
  const theme=localStorage.getItem("instanovaTheme");
  document.body.classList.toggle("dark",theme==="dark");
}
function toggleTheme(){
  const isDark=document.body.classList.toggle("dark");
  localStorage.setItem("instanovaTheme",isDark?"dark":"light");
}

$("themeBtn").addEventListener("click",toggleTheme);
$("mobileTheme").addEventListener("click",toggleTheme);


/* ==============================
   LOGOUT
============================== */

$("logoutBtn").addEventListener("click",function(){
  localStorage.removeItem("instanovaCurrentUser");
  $("app").style.display="none";
  $("authPage").style.display="flex";
  $("loginEmail").value="";
  $("loginPassword").value="";
  showToast("Chiqdingiz 👋");
});


/* ==============================
   INIT
============================== */

applyTheme();

(function init(){

  const email=localStorage.getItem("instanovaCurrentUser");

  if(email){
    const exists=getUsers().some(function(u){ return u.email===email; });
    if(exists){
      startApp();
      return;
    }
  }

  $("authPage").style.display="flex";
  $("app").style.display="none";

})();

