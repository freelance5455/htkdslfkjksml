# Unit JSON schema for My English Book 8

Write ONE valid JSON file. No markdown, no comments, no trailing commas. UTF-8. Urdu in Arabic script.

Top level:
{
  "id": "u2",
  "number": 2,
  "title": "Natural Beauty of Pakistan",
  "learn": [{ "skill": "Reading", "points": ["full objective from the unit opener"] }],
  "lessons": [ Lesson, ... ],
  "vocab": [ Vocab, ... ]
}

Lesson:
{
  "id": "2.1",
  "code": "2.1",
  "title": "Reading Comprehension",
  "subtitle": "My Blessed Beautiful Land",
  "kind": "reading" | "speaking" | "language" | "writing" | "study" | "fun",
  "blocks": [ Block, ... ]
}

Blocks (use only these types):
- {"type":"h","text":"Pre-Reading"}
- {"type":"p","text":"A paragraph. Keep the book's wording."}
- {"type":"poem","lines":["line","", "blank string means stanza break"]}
- {"type":"list","ordered":true,"items":["..."]}
- {"type":"note","text":"One short teacher note, only if it helps the student. Do not duplicate."}
- {"type":"dialogue","lines":[{"who":"Soomar","text":"..."}]}
- {"type":"callout","title":"Rule","text":"Grammar explanation, can be several sentences."}
- {"type":"table","caption":"optional","headers":["A","B"],"rows":[["a","b"]]}
- {"type":"exercise","title":"Exercise 1","instruction":"...","items":[Question,...]}
- {"type":"words","intro":"Find these professionals.","words":["doctor","nurse"]}

Questions:
- {"kind":"mcq","q":"...","options":["text without a/b/c label"],"answer":0}
- {"kind":"tf","q":"...","answer":true}
- {"kind":"fill","q":"Sentence with a blank ____ .","answers":["into","in"],"hint":"optional"}
  answers are acceptable variants, lowercase ok. For a full-sentence answer include 2–4 acceptable wordings that contain the key idea.
- {"kind":"match","pairs":[{"left":"word","right":"meaning"}]}
  Do NOT add a separate q if the exercise title is enough. Optional "q".
- {"kind":"classify","q":"Place each line in the right part.","buckets":["Beginning","Middle","End"],"cards":[{"text":"...","bucket":0}]}
- {"kind":"open","q":"...","model":"A clear model answer a class 8 teacher would accept."}

Vocab (required):
{
  "word": "spellbinding",
  "pos": "adjective",
  "meaning": "Contextual English meaning as used in THIS lesson, one clear sentence.",
  "urdu": "دل موہ لینے والا",
  "synonyms": ["fascinating","captivating"],
  "antonyms": ["boring","dull"],
  "sentences": ["One sentence using the word the way the textbook uses it."]
}

Rules:
- Copy reading texts, poems, plays, sample letters, sample emails, and grammar explanations IN FULL. Do not summarise or skip paragraphs.
- Skip the preface, the credits/authors page, and the end-of-book teacher manual (Notes for Teachers / Extended Reading sections 1–6).
- Include every numbered exercise. Objective items MUST have a correct answer taken from the text, not a guess you cannot support.
- If the book already gives an example answer, include that item with the given answer.
- Picture-only tasks: describe the task in words and, if the answer is knowable from the text, make it mcq/fill; otherwise open with a model.
- "used to", prepositions, past perfect, speech, tags: turn each numbered item into fill or mcq with the correct form.
- Vocabulary list must include EVERY word from the unit's vocabulary tables PLUS other difficult words in the reading (aim 18–40 words per unit). Meaning must match the usage in the sentence. Urdu must be natural school Urdu, not Roman Urdu. 2–4 synonyms, 2–3 antonyms (if none, use a clear opposite or ["no direct antonym"]). Exactly one or two example sentences. Sentences will be shown in italics in light blue, so write them as real example sentences, not definitions.
- lesson.kind must be one of the six values.
- ids like "3.1". code same as id.
- Do not invent a new story. Do not omit the second half of a passage because it is long.
