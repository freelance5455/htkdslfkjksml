require("dotenv").config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

const token = process.env.DISCORD_BOT_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.LOG_GUILD_ID;
const logChannelId = process.env.LOG_CHANNEL_ID;

if (!token) {
  console.error("Missing DISCORD_BOT_TOKEN in .env");
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  if (guildId && logChannelId) {
    const channel = await client.channels.fetch(logChannelId).catch(() => null);
    if (channel?.isTextBased()) channel.send("🟦 تم تشغيل copy/NIZAR بنجاح.");
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (interaction.commandName === "ping") {
    await interaction.reply({ content: "🟦 copy/NIZAR يعمل.", ephemeral: true });
  }
});

async function registerCommands() {
  if (!clientId || !guildId) return;
  const commands = [
    new SlashCommandBuilder().setName("ping").setDescription("اختبار حالة بوت copy/NIZAR")
  ].map(c => c.toJSON());
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
}

registerCommands().then(() => client.login(token)).catch(err => {
  console.error("Bot startup error:", err);
  process.exit(1);
});