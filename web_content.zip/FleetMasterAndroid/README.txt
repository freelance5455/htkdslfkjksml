FleetMaster Android wrapper (source project)
============================================

This is an Android Studio project that wraps the FleetMaster HTML app in a WebView.
The bike background is embedded in the HTML file, so it is bundled with the app.

How to build an APK:
1. Install Android Studio on a computer and open the FleetMasterAndroid folder.
2. Let Android Studio sync/download the required Android Gradle Plugin and SDK.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the location of the generated APK.

Important:
- This source project is not itself a compiled APK.
- The app currently stores records locally in WebView browser storage on that device.
- It does not yet have cloud database sync, login, or multi-device sharing.
- Export your demo records before clearing app data.
