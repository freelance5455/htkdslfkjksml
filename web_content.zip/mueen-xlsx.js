/* =========================================================
   MUEEN | OFFLINE XLSX WRITER
   ملف Excel حقيقي بصيغة .xlsx بدون CDN
========================================================= */
"use strict";

(function () {
    const encoder = new TextEncoder();

    function xmlEscape(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&apos;");
    }

    function crc32(bytes) {
        let crc = 0 ^ -1;
        for (let i = 0; i < bytes.length; i++) {
            crc ^= bytes[i];
            for (let k = 0; k < 8; k++) {
                crc = (crc >>> 1) ^ (0xEDB88320 & -(crc & 1));
            }
        }
        return (crc ^ -1) >>> 0;
    }

    function u16(n) {
        return new Uint8Array([n & 255, (n >>> 8) & 255]);
    }
    function u32(n) {
        return new Uint8Array([
            n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255
        ]);
    }

    function concat(parts) {
        let total = parts.reduce((n, p) => n + p.length, 0);
        const out = new Uint8Array(total);
        let offset = 0;
        parts.forEach(p => { out.set(p, offset); offset += p.length; });
        return out;
    }

    function zipStore(files) {
        const local = [], central = [];
        let offset = 0;

        files.forEach(file => {
            const name = encoder.encode(file.name);
            const data = encoder.encode(file.data);
            const crc = crc32(data);

            const header = concat([
                new Uint8Array([0x50,0x4b,0x03,0x04]),
                u16(20), u16(0), u16(0),
                u16(0), u16(0),
                u32(crc), u32(data.length), u32(data.length),
                u16(name.length), u16(0), name
            ]);
            local.push(header, data);

            const centralHeader = concat([
                new Uint8Array([0x50,0x4b,0x01,0x02]),
                u16(20), u16(20), u16(0), u16(0),
                u16(0), u16(0),
                u32(crc), u32(data.length), u32(data.length),
                u16(name.length), u16(0), u16(0), u16(0),
                u16(0), u32(0), u32(offset), name
            ]);
            central.push(centralHeader);
            offset += header.length + data.length;
        });

        const centralBytes = concat(central);
        const localBytes = concat(local);
        const end = concat([
            new Uint8Array([0x50,0x4b,0x05,0x06]),
            u16(0),u16(0),
            u16(files.length),u16(files.length),
            u32(centralBytes.length),u32(localBytes.length),
            u16(0)
        ]);

        return concat([localBytes, centralBytes, end]);
    }

    function columnName(index) {
        let s = "";
        let n = index + 1;
        while (n > 0) {
            const r = (n - 1) % 26;
            s = String.fromCharCode(65 + r) + s;
            n = Math.floor((n - 1) / 26);
        }
        return s;
    }

    function buildSheet(rows) {
        const body = [];
        rows.forEach((row, r) => {
            const cells = [];
            (Array.isArray(row) ? row : []).forEach((value, c) => {
                const ref = `${columnName(c)}${r + 1}`;
                if (typeof value === "number" && Number.isFinite(value)) {
                    cells.push(`<c r="${ref}"><v>${value}</v></c>`);
                } else {
                    cells.push(`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`);
                }
            });
            body.push(`<row r="${r + 1}">${cells.join("")}</row>`);
        });

        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>${body.join("")}</sheetData>
</worksheet>`;
    }

    function create(rows, sheetName = "تقرير") {
        const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="${xmlEscape(sheetName).slice(0,31)}" sheetId="1" r:id="rId1"/></sheets>
</workbook>`;

        const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>`;

        const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

        const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>`;

        return new Blob([zipStore([
            {name:"[Content_Types].xml", data:contentTypes},
            {name:"_rels/.rels", data:rootRels},
            {name:"xl/workbook.xml", data:workbook},
            {name:"xl/_rels/workbook.xml.rels", data:workbookRels},
            {name:"xl/worksheets/sheet1.xml", data:buildSheet(rows)}
        ])], {
            type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        });
    }

    window.MueenXLSX = { create };
})();
