// Liste des unités pour chaque catégorie
// Pour longueur et poids, le nombre est le facteur de conversion vers l'unité de base
// (mètre pour la longueur, gramme pour le poids)

var unitesLongueur = [
    { nom: "Millimètre", code: "mm", facteur: 0.001 },
    { nom: "Centimètre", code: "cm", facteur: 0.01 },
    { nom: "Mètre", code: "m", facteur: 1 },
    { nom: "Kilomètre", code: "km", facteur: 1000 },
    { nom: "Pouce", code: "in", facteur: 0.0254 },
    { nom: "Pied", code: "ft", facteur: 0.3048 },
    { nom: "Mile", code: "mi", facteur: 1609.34 }
];

var unitesPoids = [
    { nom: "Gramme", code: "g", facteur: 1 },
    { nom: "Kilogramme", code: "kg", facteur: 1000 },
    { nom: "Livre", code: "lb", facteur: 453.592 },
    { nom: "Once", code: "oz", facteur: 28.3495 }
];

var unitesTemperature = [
    { nom: "Celsius", code: "c" },
    { nom: "Fahrenheit", code: "f" },
    { nom: "Kelvin", code: "k" }
];

// Quand la page est chargée, on prépare tout
document.addEventListener("DOMContentLoaded", function () {

    var selectCategorie = document.getElementById("categorie");
    var selectDepart = document.getElementById("unite_depart");
    var selectArrivee = document.getElementById("unite_arrivee");
    var boutonConvertir = document.getElementById("bouton_convertir");
    var champValeur = document.getElementById("valeur");
    var divResultat = document.getElementById("resultat");

    // Remplit les deux listes déroulantes selon la catégorie choisie
    function remplirUnites() {
        var categorie = selectCategorie.value;
        var liste = [];

        if (categorie === "longueur") {
            liste = unitesLongueur;
        } else if (categorie === "poids") {
            liste = unitesPoids;
        } else if (categorie === "temperature") {
            liste = unitesTemperature;
        }

        selectDepart.innerHTML = "";
        selectArrivee.innerHTML = "";

        for (var i = 0; i < liste.length; i++) {
            var option1 = document.createElement("option");
            option1.value = liste[i].code;
            option1.textContent = liste[i].nom;
            selectDepart.appendChild(option1);

            var option2 = document.createElement("option");
            option2.value = liste[i].code;
            option2.textContent = liste[i].nom;
            selectArrivee.appendChild(option2);
        }

        // Par défaut, on choisit une deuxième unité différente dans "Vers"
        if (liste.length > 1) {
            selectArrivee.selectedIndex = 1;
        }

        divResultat.textContent = "";
    }

    // Convertit une température d'une unité vers Celsius
    function versCelsius(valeur, code) {
        if (code === "c") {
            return valeur;
        } else if (code === "f") {
            return (valeur - 32) * 5 / 9;
        } else if (code === "k") {
            return valeur - 273.15;
        }
        return valeur;
    }

    // Convertit une valeur en Celsius vers une autre unité
    function depuisCelsius(valeurCelsius, code) {
        if (code === "c") {
            return valeurCelsius;
        } else if (code === "f") {
            return valeurCelsius * 9 / 5 + 32;
        } else if (code === "k") {
            return valeurCelsius + 273.15;
        }
        return valeurCelsius;
    }

    // Trouve le facteur de conversion d'une unité (longueur ou poids)
    function trouverFacteur(liste, code) {
        var facteur = 1;
        for (var i = 0; i < liste.length; i++) {
            if (liste[i].code === code) {
                facteur = liste[i].facteur;
            }
        }
        return facteur;
    }

    // Quand on clique sur le bouton "Convertir"
    function convertir() {
        var categorie = selectCategorie.value;
        var codeDepart = selectDepart.value;
        var codeArrivee = selectArrivee.value;
        var valeur = parseFloat(champValeur.value);

        if (isNaN(valeur)) {
            divResultat.textContent = "Merci d'entrer un nombre valide.";
            return;
        }

        var resultat = 0;

        if (categorie === "longueur") {
            var facteurDepart = trouverFacteur(unitesLongueur, codeDepart);
            var facteurArrivee = trouverFacteur(unitesLongueur, codeArrivee);
            var valeurEnMetres = valeur * facteurDepart;
            resultat = valeurEnMetres / facteurArrivee;

        } else if (categorie === "poids") {
            var facteurDepart2 = trouverFacteur(unitesPoids, codeDepart);
            var facteurArrivee2 = trouverFacteur(unitesPoids, codeArrivee);
            var valeurEnGrammes = valeur * facteurDepart2;
            resultat = valeurEnGrammes / facteurArrivee2;

        } else if (categorie === "temperature") {
            var valeurEnCelsius = versCelsius(valeur, codeDepart);
            resultat = depuisCelsius(valeurEnCelsius, codeArrivee);
        }

        var resultatArrondi = Math.round(resultat * 1000) / 1000;
        divResultat.textContent = valeur + " " + codeDepart + " = " + resultatArrondi + " " + codeArrivee;
    }

    // On écoute les événements
    selectCategorie.addEventListener("change", remplirUnites);
    boutonConvertir.addEventListener("click", convertir);

    // Initialisation au chargement de la page
    remplirUnites();

});
