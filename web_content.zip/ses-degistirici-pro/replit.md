# Ses Değiştirici PRO

Android için kulaklık mikrofonunu izleyen, preset ses efektleri ve düşük gecikmeli ses kontrolleri sunan koyu temalı Expo uygulaması.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/voice-changer-pro run dev` — run the Expo mobile preview
- `pnpm --filter @workspace/voice-changer-pro run typecheck` — typecheck the mobile app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/voice-changer-pro/app/index.tsx` — main control surface and interaction state
- `artifacts/voice-changer-pro/lib/voice-engine.ts` — microphone permission, recording and metering boundary
- `artifacts/voice-changer-pro/constants/colors.ts` — dark audio-focused theme tokens

## Architecture decisions

- The first build is frontend-only and keeps settings local to the screen; no database is needed for the audio control surface.
- Microphone capture and metering are isolated behind `VoiceEngine` so a future Android-native DSP graph can replace the managed runtime boundary.
- The product explicitly targets in-app monitoring and VoIP-supported scenarios; it does not attempt to intercept normal phone-call audio.
- Expo Router uses a single focused screen instead of tabs because this is a real-time utility.

## Product

- Selects 12 voice presets, including robot, alien, echo, monster and custom.
- Controls pitch, speed, echo, reverb, noise reduction and effect intensity.
- Requests microphone permission, starts/stops live metering, shows input level and distinguishes original/effected preview modes.
- Shows Bluetooth/wired headphone support and a clear Android call-audio limitation notice.

## User preferences

- The user requested a modern, professional dark Android interface in Turkish.

## Gotchas

- Android devices and the managed Expo runtime cannot universally replace normal cellular call audio; keep the in-app monitoring/VoIP boundary visible.
- `expo-av` is currently used for managed microphone metering because it is available in the installed Expo SDK; Expo warns that future work should evaluate `expo-audio`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
