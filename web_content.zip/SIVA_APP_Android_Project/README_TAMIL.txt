SIVA APP - Android project

முக்கியம்:
இந்த ZIP ஒரு Android project source. இது APK file அல்ல.
இந்த chat environment-ல் Android SDK/Gradle build tools இல்லை; அதனால் இங்கே நேரடியாக APK-ஆக compile செய்து கொடுக்க முடியவில்லை.

APK உருவாக்க:
1. Android Studio உள்ள கணினியில் இந்த ZIP-ஐ extract செய்யவும்.
2. Android Studio-ல் Open செய்து SIVA_APP folder-ஐ தேர்வு செய்யவும்.
3. Gradle sync முடிந்ததும் Build > Build APK(s) தேர்வு செய்யவும்.
4. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk-ல் உருவாகும்.

உங்கள் index.html app/src/main/assets/index.html-ல் சேர்க்கப்பட்டுள்ளது.

கணினி இல்லாமல் cloud build (GitHub) முயற்சி:
1. GitHub account தேவை.
2. இந்த ZIP-ஐ extract செய்து project files-ஐ புதிய GitHub repository-க்கு upload செய்ய வேண்டும்.
3. Actions tab-ல் Build SIVA APP APK workflow-ஐ run செய்யவும்.
4. Workflow முடிந்ததும் Artifacts பகுதியில் SIVA-APP-debug-apk download கிடைக்கும்.
இது சில படிகள் கொண்டது; நேரடியாக APK அல்ல.
