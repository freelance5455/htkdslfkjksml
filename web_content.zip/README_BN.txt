BR Football Challenge — BAYZID #10 (Fixed prototype)

ব্যবহার:
1) ZIP Extract করুন।
2) index.html ফাইলটি Chrome বা HTML viewer দিয়ে খুলুন।
3) নীল তীর বোতামগুলোতে চাপলে খেলোয়াড় নড়বে; পাস ও শটের বোতামও কাজ করবে।

গুরুত্বপূর্ণ: এটি একটি 2D HTML প্রোটোটাইপ, Android APK/AAB নয়। Play Store-এ প্রকাশের আগে Android অ্যাপে প্যাকেজিং, ডিভাইসে পরীক্ষা এবং Google Play-এর শর্ত পূরণ করতে হবে।
