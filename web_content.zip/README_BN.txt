SARSINA FOODS WEBSITE — NETLIFY UPLOAD

এই ZIP-এ ওয়েবসাইট এবং আপনার আপলোড করা Sarsina Foods লোগো আছে।

Netlify-তে আপলোড:
1. ZIP Extract/Unzip করুন।
2. https://app.netlify.com/drop খুলুন।
3. Extract করা ফোল্ডারটি আপলোড করুন।
4. index.html এবং sarsina-logo.jpg একই ফোল্ডারে রাখবেন।

নোট: এটি static website। এই সংস্করণের পণ্য/ক্যাটাগরির ডেটা একই ব্রাউজারে সংরক্ষিত হয়। Google/Facebook-এর আসল লগইন ও একাধিক ডিভাইসে একই ডেটা রাখতে backend configuration প্রয়োজন।
