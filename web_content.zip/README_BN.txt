LEGEND GANG Web App Package

এই ZIP-এ index.html ও আপনার দেওয়া আসল lg-logo.png আছে। এটি একটি APK builder-এ ওয়েবসাইট/HTML ZIP হিসেবে আপলোড করার জন্য প্রস্তুত। APK builder-এর নিয়ম অনুসারে app name LEGEND GANG এবং app icon হিসেবে lg-logo.png বেছে নিন। Build সফল হয়েছে কিনা তা builder-এ যাচাই করুন।
