Roman Trading Tracker v1.2 — Android source project

- Professional Neon Dark dashboard/web-style responsive UI
- Editable settings: Starting Balance, Daily Profit Target %, Daily Stop-Loss %
- All 30 days recalculate automatically using compound projection
- Each day shows planned start balance, dollar target, dollar stop-loss, projected end if target hit, cumulative planned profit, actual start/end balance
- Actual P/L inputs and profit/loss/completed checkboxes
- Local on-device save and JSON backup export
- Android WebView wrapper

Build APK:
1. Extract ZIP and open the project folder in Android Studio.
2. Wait for Gradle Sync.
3. Build > Build APK(s).
4. Debug APK normally appears at app/build/outputs/apk/debug/app-debug.apk.

This ZIP is source code, not a precompiled APK. It does not place trades or connect to Quotex. Profit projections are mathematical examples, not guaranteed earnings.
