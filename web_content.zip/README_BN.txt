FF_UDP_GLORY — Safe Android Tracker (বাংলা)

এই প্যাকেজটি মূল Free Fire automation bot-এর নিরাপদ বিকল্প। মূল app.py, game-protocol automation, password/token cache এবং anti-cheat/jitter code রাখা হয়নি।

ফিচার:
- মোবাইল-ফ্রেন্ডলি dashboard ও admin login
- Guild ID/name সেভ
- শুধু UID ও label; password/OTP/token নয়
- গেমে দেখে manually লেখা Guild EXP snapshot ও delta
- ১২টি UID থাকলে ৩টি স্কোয়াডে চারজন করে পরিকল্পনা
- localhost-only (127.0.0.1)

সীমা:
- Free Fire-এ login/online presence তৈরি করে না
- auto guild request, auto match start বা in-game movement করে না
- live official API নেই; EXP হাতে লিখতে হবে
- squad division শুধু পরিকল্পনা

Termux setup:
1) ZIP Extract করো।
2) Termux-এ চালাও:
   pkg update
   pkg install python unzip
3) Extract করা ফোল্ডারে ঢুকে নতুন দীর্ঘ admin password সেট করো:
   export SGX_TRACKER_PASSWORD='কমপক্ষে-১২-অক্ষরের-নতুন-পাসওয়ার্ড'
   (নিজের Free Fire password ব্যবহার করবে না।)
4) চালাও:
   python safe_dashboard.py
5) Chrome-এ খোলো: http://127.0.0.1:8765
6) Browser login: username admin; password = SGX_TRACKER_PASSWORD
7) বন্ধ করতে Termux-এ Ctrl+C

দীর্ঘক্ষণ চালানো:
- Android Settings > Apps > Termux > Battery-তে Unrestricted/Don't optimize নির্বাচন করো (নাম ফোনভেদে আলাদা)।
- Termux:API ইনস্টল থাকলে termux-wake-lock চালানো যায়; শেষে termux-wake-unlock। এতে ব্যাটারি বেশি খরচ হয়।
- ফোন restart হলে প্রোগ্রামটি আবার চালাতে হবে।

নিরাপত্তা:
মূল ZIP-এ accounts.json, token_cache.json ও devices.json ছিল। যদি এগুলোতে আসল password/token থাকে, password বদলাও এবং সম্ভব হলে পুরোনো active sessions revoke করো। নতুন প্যাকেজে ওই ফাইলগুলো কপি করা হয়নি।
