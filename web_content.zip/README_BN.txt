LV75 PUBLIC STARTER v2 — Firebase-backed web app
=================================================

এটি LV75-এর পাবলিক-লঞ্চের জন্য একটি উন্নত STARTER PROJECT, সম্পূর্ণ production app/APK নয়।

এখন কোডে আছে:
- Firebase Phone OTP login
- user profile + discoverable setting
- ফোন নম্বর দিয়ে registered user search
- দুই ব্যবহারকারীর মধ্যে Firestore realtime text chat
- ছবি/ফাইল upload-এর প্রাথমিক Firebase Storage integration
- responsive dark modern UI
- Firestore ও Storage rules template

এখনো production-ready নয় / সম্পূর্ণ যুক্ত নয়:
- audio/video calling (WebRTC + signaling server দরকার)
- push notifications (FCM + server-side sender দরকার)
- call history from real calls
- admin dashboard, premium billing, moderation/reporting
- full end-to-end encryption
- Play Store-ready signed Android APK

SETUP (ফোন বা কম্পিউটার থেকে Firebase Console-এ):
1. https://console.firebase.google.com এ project তৈরি করুন।
2. Project settings > Your apps > Web app যোগ করে config নিন।
3. web/app.js-এর firebaseConfig placeholder-গুলো আপনার config দিয়ে বদলান।
4. Authentication > Sign-in method > Phone চালু করুন। SMS region policy/limits ঠিক করুন।
5. Authentication > Settings-এ আপনার hosting domain অনুমোদন করুন।
6. Firestore Database তৈরি করুন।
7. Storage চালু করুন (যদি file/image upload ব্যবহার করতে চান)।
8. এই ZIP-এর firestore.rules Firebase Console > Firestore > Rules-এ publish করুন।
9. storage.rules Storage > Rules-এ publish করুন।
10. Firebase Hosting deploy করুন (Firebase CLI লাগতে পারে), অথবা অন্য HTTPS static hosting ব্যবহার করুন।
11. দুইটি আলাদা ফোন নম্বর দিয়ে দুই account তৈরি করে chat test করুন।

বাংলাদেশের ফোন নম্বর:
- সাধারণত +8801XXXXXXXXX ফরম্যাট ব্যবহার করুন।
- 01XXXXXXXXX দিলে কোডটি +88 যোগ করার চেষ্টা করে।

সতর্কতা:
- Firestore/Storage rules যাচাই করে প্রকাশ করুন; test mode rules ব্যবহার করবেন না।
- API key web app config-এ থাকা স্বাভাবিক, কিন্তু Security Rules ও App Check গুরুত্বপূর্ণ।
- SMS quota/region এবং Firebase billing limits প্রযোজ্য হতে পারে।
- ফাইলের আকার UI-তে 15 MB সীমা দেওয়া আছে; প্রকৃত সীমা rules/storage configuration-এর সঙ্গেও মিলিয়ে নিন।
- এই ZIP আর্কাইভ পরীক্ষা করা হয়েছে; Firebase project-এ deploy করে বাস্তব SMS/দুই ফোনে end-to-end পরীক্ষা করা হয়নি।
