Roman Trading Tracker — Android Project

এই প্রজেক্টে আছে:
- Neon Dark অফলাইন ট্রেডিং ট্র্যাকার UI
- ৩০ দিনের পূর্বনির্ধারিত চার্ট
- নিজে Starting Balance, target %, stop-loss % সেট করার ব্যবস্থা
- প্রতিদিনের Actual P/L ইনপুট, Target/Stop-Loss/Completed চেকবক্স
- ব্যালেন্স ও সারাংশ স্বয়ংক্রিয় হিসাব
- localStorage-এ ফোনের অ্যাপ ডেটা সেভ

APK তৈরি:
1. Android Studio ইনস্টল করুন।
2. এই ZIP extract করুন।
3. Android Studio থেকে project ফোল্ডার খুলুন।
4. Gradle sync শেষ হলে Build > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে।

নোট:
- এখানে সরাসরি তৈরি APK নেই; এটি APK বানানোর সোর্স প্রজেক্ট।
- অ্যাপটি Quotex-এ লগইন বা ট্রেড করে না; এটি ম্যানুয়াল হিসাবের ট্র্যাকার।
- অ্যাপ uninstall বা app data clear করলে local data মুছে যেতে পারে। দরকার হলে ফোনে ডেটা ব্যাকআপ রাখুন।
- 10% daily target কেবল একটি পরিকল্পনামূলক লক্ষ্য, নিশ্চিত লাভ নয়।
