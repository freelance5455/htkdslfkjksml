Sahan AI WebView Fixed

এই ZIP-এ একটিমাত্র root index.html আছে। কোনো external CSS/JS/image/resource নেই, যাতে HTML-to-APK wrapper-এ local WebView resource error কমে।

ব্যবহার: ZIP File to APK -> এই ZIP নির্বাচন -> Build APK.

অ্যাপে: Screenshot দিন -> ছবি নির্বাচন -> ANALYSE -> UP/DOWN.
