SA FLEX CAST — Cricket app starter
==================================
ফিচার:
- Live matches (currentMatches API)
- Upcoming fixtures ও Results (matches API থেকে তারিখ অনুযায়ী ভাগ)
- Series এবং Countries তালিকা
- Match details; scorecard endpoint থাকলে অতিরিক্ত স্কোরকার্ড
- Search, refresh, প্রতি ৬০ সেকেন্ডে live refresh
- Responsive dark sports UI এবং PWA manifest

চালানোর নিয়ম:
1. index.html একটি HTTPS static hosting-এ আপলোড করুন (GitHub Pages/Netlify ইত্যাদি)।
2. Android Chrome-এ URL খুলে Install app / Add to Home screen ব্যবহার করুন।
3. API key HTML-এ রাখা আছে; এটি public হলে অন্যরা ব্যবহার করতে পারবে। Production-এর জন্য নিজের secure backend proxy ব্যবহার করুন এবং key rotate করুন।

সীমাবদ্ধতা:
- API provider-এর quota/plan, endpoint access ও CORS policy-এর ওপর ডেটা নির্ভর করে।
- Detailed fantasy scorecard endpoint paid plan-এ সীমিত হতে পারে।
- Live TV stream যোগ করা হয়নি; অনুমোদিত stream URL/source প্রয়োজন। কোনো broadcast content পাইরেটেডভাবে সরবরাহ করা হয়নি।
- এটি source/PWA build, signed APK নয়। APK বানাতে Android Studio/Kodular build service দিয়ে compile ও sign করতে হবে।
