MY COLLEGE — Firebase সংযুক্ত সোর্স ZIP
=====================================

Firebase Project: my-college-98ee2
Firebase Web Config: firebase-config.js ফাইলে আগে থেকেই আছে।
Super Admin UID: HJf60F7a78RFgsBwWJw81gLUXx83

এই ZIP-এ যা প্রস্তুত আছে
- Email ও Password দিয়ে Signup / Login
- Signup-এর পর ইমেইল Verification পাঠানো
- ১৮ বছরের কম বয়সে Signup বন্ধ
- Student (HSC / Honours) এবং Teacher profile
- Firestore user profile ও user directory
- Internet-ভিত্তিক text chat
- College অনুযায়ী Notice Board
- Super Admin: user control, notice publisher permission, announcement, app update
- College/শিক্ষার ধরন অনুযায়ী syllabus link
- Local PDF library (IndexedDB)
- English default; Bangla/English language toggle

গুরুত্বপূর্ণ সীমাবদ্ধতা
- Firebase Spark Free Plan-এ Firebase Cloud Storage bucket ব্যবহার করা যায় না। তাই এই ZIP-এ Firebase Storage upload code রাখা হয়নি।
- Profile photo upload, chat-এর file/voice transfer এবং সরাসরি PDF upload এখনো চালু নয়। এগুলোর জন্য পরে Cloudflare R2 বা অন্য HTTPS file hosting সংযোগ করতে হবে।
- আপাতত Super Admin HTTPS PDF link সিলেবাসে সংরক্ষণ করতে পারবে; Notice-এও HTTPS attachment link দেওয়া যাবে।
- Text chat message Firestore-এ থাকে। Delivered হওয়ার পর server থেকে auto-delete এবং দুই ফোনে permanent local-only history এই সংস্করণে implement করা হয়নি।
- Firebase-এ live end-to-end test করা হয়নি। Public launch-এর আগে দুইটি test account দিয়ে পরীক্ষা করা জরুরি।

Firebase Console
1. Authentication > Sign-in method > Email/Password Enabled থাকতে হবে।
2. Firestore Database তৈরি থাকতে হবে।
3. Firestore Rules-এ এই ZIP-এর firestore.rules-এর সঙ্গে মিল থাকা প্রয়োজন।
4. Spark plan-এই থাকো; billing account link কোরো না।

HTTPS Hosting এবং APK
- Firebase JavaScript SDK-এর module import file:// থেকে নির্ভরযোগ্যভাবে চলে না। index.html সরাসরি File Manager থেকে খুলো না।
- এই ফোল্ডারটি HTTPS hosting-এ deploy করে আগে browser-এ Signup/Login পরীক্ষা করতে হবে। firebase.json ও .firebaserc Firebase Hosting deploy-এর জন্য রাখা হয়েছে।
- এরপর HTML-to-APK Builder যদি remote HTTPS URL load করতে পারে, তাহলে hosted URL দিয়ে APK বানানো যাবে। Builder যদি শুধু local ZIP embed করে এবং HTTPS origin না দেয়, Firebase module/Auth কাজ নাও করতে পারে।
- এটি আপডেট করা source ZIP; APK নয়।
