EMAN GAMING PANEL - Android Studio Project

এই প্রজেক্টটি আপনার HTML ফাইলকে Android WebView অ্যাপ হিসেবে চালায়।

APK তৈরি করার নিয়ম:
1. ZIP ফাইলটি Extract করুন।
2. Android Studio খুলে Open চাপুন এবং EmanGamingPanel ফোল্ডারটি নির্বাচন করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK তৈরি হলে Android Studio-র notification থেকে Locate চাপুন।

দ্রষ্টব্য:
- প্রথমবার Gradle build করার সময় ইন্টারনেট লাগতে পারে, যাতে Android Gradle Plugin ও SDK ডাউনলোড হয়।
- এটি একটি নিরাপদ Free Fire settings guide; game ফাইল/aim/recoil পরিবর্তন বা cheat করে না।
