TRUCK HISAB - APK BUILDER READY ZIP

এই ZIP-এ index.html root-এ এবং web/index.html দুটো জায়গাতেই রাখা হয়েছে।
যে APK builder web/index.html খুঁজছে, তার জন্য web/index.html ইচ্ছাকৃতভাবে রাখা হয়েছে।

App name: Truck Hisab
Icon: icon-512.png (512x512)

ZIP-এর ভিতরের web ফোল্ডার মুছবে না।
