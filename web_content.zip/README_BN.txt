Screen2AI Web APK package

এই ZIP-এ index.html আছে; ZIP-to-APK converter-এ এটি ব্যবহার করার উপযোগী ওয়েব অ্যাপ প্যাকেজ।

ব্যবহার:
1. ZIP-to-APK converter-এ এই ZIP নির্বাচন করো।
2. অ্যাপের নাম Screen2AI দাও।
3. Converter যদি index.html চায়, এই ZIP-এ সেটি root-এ আছে।
4. APK তৈরি করে ইনস্টল করো।

সীমাবদ্ধতা:
- Web edition-এ browser/WebView getDisplayMedia সমর্থন ও permission থাকলে স্ক্রিন ক্যাপচার হবে। সব converter/WebView এটি সমর্থন করে না।
- না চললে স্ক্রিনশট নির্বাচন করে ZIP বানানো যাবে।
- Native Android overlay button/background capture এই HTML edition-এ সম্ভব নয়; এটি মূল Native edition-এর সব ফিচারের সমান নয়।
