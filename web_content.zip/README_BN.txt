SARSINA FOODS — OWNER ADMIN EDITION

এই ZIP-এ আগের ধরনের সাধারণ পাবলিক ওয়েবসাইট এবং মালিকের জন্য Owner Admin Panel-এর ভিত্তি রাখা হয়েছে।
সাধারণ দর্শক পণ্য দেখতে পারবে। পণ্য/ক্যাটাগরি/লোগো পরিবর্তন করতে Firebase Authentication-এ নির্দিষ্ট OWNER_UID-সহ মালিকের অ্যাকাউন্ট লাগবে।

গুরুত্বপূর্ণ:
- এটি নিরাপদ অনলাইন লগইনের জন্য Firebase backend scaffold। ZIP একা আপলোড করলেই Owner Login চালু হবে না।
- Firebase project তৈরি ও config বসাতে হবে। Firebase-এর ওয়েব কনসোলে Authentication > Email/Password চালু করে মালিকের অ্যাকাউন্ট তৈরি করো।
- Firestore Database ও Storage চালু করো।
- index.html-এর firebaseConfig-এ Firebase project config বসাও।
- OWNER_UID-তে মালিক অ্যাকাউন্টের UID বসাও.
- firestore.rules এবং storage.rules-এর PASTE_OWNER_UID-তেও একই UID বসিয়ে Firebase console-এ Rules publish করো।
- এরপর index.html-সহ ফাইলগুলো Netlify/Vercel/অন্য static hosting-এ আপলোড করো।
- কোনো পাসওয়ার্ড এই ZIP-এ হার্ডকোড করা নেই; পাসওয়ার্ড Firebase Authentication-এ সেট হবে।
- নিজের লোগো Admin Panel থেকে আপলোড করা যাবে। প্রকৃত লোগো ফাইলটি এই ZIP-এ এমবেড করা নেই, কারণ এই মুহূর্তে আসল লোগো ফাইলটি সংযুক্ত অবস্থায় পাওয়া যায়নি।

ফাইল:
index.html — ওয়েবসাইট ও Owner Admin
firestore.rules — পণ্য/ক্যাটাগরির অনুমতি
storage.rules — ছবি/লোগোর অনুমতি

আগে Firebase সেটআপ সম্পূর্ণ করো, তারপর হোস্টিংয়ে আপলোড করো।
