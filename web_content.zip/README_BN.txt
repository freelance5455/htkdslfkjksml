এসো আরবী শিখি — HTML-to-APK ZIP package

ZIP-এর root-এ index.html আছে এবং assets/book.pdf-এ প্রথম ২৫০ পৃষ্ঠার PDF আছে।
HTML/ZIP-to-APK builder-এ ZIP upload করলে builder যেন index.html-কে homepage হিসেবে নেয় এবং assets ফোল্ডারটিও প্যাকেজ করে, তা নিশ্চিত করুন।
এই ZIP নিজে APK নয়। অ্যাপের ভেতরে PDF দেখানো builder-এর WebView/PDF support-এর ওপর নির্ভরশীল।
