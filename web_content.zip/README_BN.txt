স্মার্ট ক্যালকুলেটর — সংশোধিত সোর্স ZIP

এই ZIP-এ index.html রুটে এবং web/index.html পথেও রাখা হয়েছে, যাতে বিভিন্ন HTML/WebView APK Builder-এ ব্যবহার সহজ হয়।

ব্যবহার:
1. ZIP আপলোড করুন।
2. Builder যদি Start page / Entry file চায়, index.html নির্বাচন করুন (অথবা web/index.html যদি Builder স্পষ্টভাবে /web/index.html চায়)।
3. HTML/WebView app নির্বাচন করুন।
4. APK বানানোর পর ইনস্টল করে পরীক্ষা করুন।

এটি সোর্স ZIP, APK নয়। বিভিন্ন Builder-এর নিয়ম আলাদা হতে পারে; তৈরি APK ফোনে পরীক্ষা না করা পর্যন্ত কাজের নিশ্চয়তা দেওয়া যায় না.
