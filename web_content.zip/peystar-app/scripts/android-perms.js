// پس از «cap add android» مجوزهای میکروفون و دوربین را به AndroidManifest اضافه می‌کند (پیام صوتی، ویدیو).
const fs = require("fs");
const p = "android/app/src/main/AndroidManifest.xml";
let x = fs.readFileSync(p, "utf8");
const want = ["android.permission.RECORD_AUDIO", "android.permission.CAMERA", "android.permission.MODIFY_AUDIO_SETTINGS"];
const add = want.filter((w) => !x.includes(w)).map((w) => `    <uses-permission android:name="${w}" />`).join("\n");
if (add) x = x.replace("</manifest>", add + "\n</manifest>");
fs.writeFileSync(p, x);
console.log("permissions ok:", want.join(", "));
