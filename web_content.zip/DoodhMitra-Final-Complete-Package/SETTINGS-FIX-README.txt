DOODHMITRA — SETTINGS REDESIGN FIX 2

Main application:
DoodhMitra-B8-P12-Simplified-Package/index.html

The Settings screen should open to five navigation rows only:
Business Profile, Invoice Settings, Invoice Designer, Invoice Preferences,
and Backup & Data Management.

Select one row to open its dedicated content view. Use Back to return to the
five-row Settings landing screen.

Data safety:
Take a backup before replacing or testing the existing application. Use the
same browser/device profile if you need to access existing IndexedDB records.

See SETTINGS-FIX-CHANGELOG.txt and SETTINGS-FIX-QA-REPORT.txt.
