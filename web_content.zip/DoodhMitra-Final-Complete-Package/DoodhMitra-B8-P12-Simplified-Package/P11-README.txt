DoodhMitra B8 — P11 Financial Summary

This package carries forward the P10 application and adds expanded financial reporting and expense analysis in the existing Reports page.

P11 additions:
- Paid vs unpaid expense totals and entry counts.
- Expense category totals with percentage of total expenses.
- Paid expense breakdown by Cash, UPI, Bank Transfer and Other.
- Top 10 vendors/payees by recorded expenses.
- Expense-to-sales percentage for the selected period.
- CSV export includes the new expense analysis sections.

Accounting interpretation:
- Total expenses incurred include both paid and unpaid expense entries.
- Payment-mode totals include paid expenses only.
- The expense-to-sales ratio uses total expenses incurred divided by sales.
- Estimated profit remains an estimate based on available Product Master costs and expenses incurred; it is not audited accounting profit.
- Payment modes remain classifications only. No separate Cash/Bank balances, opening balances or transfers are introduced.

Data and compatibility:
- IndexedDB database name, version and object stores are unchanged.
- No migration is introduced.
- Existing P6-P10 baselines and P10 documentation are retained in this package.
- Keep a backup and test on a duplicate profile before live use.
