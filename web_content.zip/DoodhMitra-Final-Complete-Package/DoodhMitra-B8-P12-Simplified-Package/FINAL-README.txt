DOODHMITRA V7 – COMPLETE APPLICATION PACKAGE
============================================

START HERE
----------
For normal use, open:
DoodhMitra-B8-P12-Simplified-Package/index.html

The same latest application is also supplied as:
- DoodhMitra-V7.html
- DoodhMitra-B8-FINAL.html
- DoodhMitra-B8-P12-Simplified-Package/DoodhMitra-B8-FINAL.html

PACKAGE CONTENTS
----------------
1. Complete latest standalone HTML application.
2. Historical P6, P7, P8, P9, P10, P11 and P12 baseline HTML files.
3. Historical phase READMEs, changelogs, QA reports and security notes.
4. V7 README, changelog, QA report, security report and Android device checklist.
5. SHA-256 checksum manifest.
6. Final update changelog and final test status.

IMPORTANT DATA SAFETY
---------------------
- DoodhMitra stores application data in the browser/device IndexedDB.
- Before replacing an older build, open the old build and download a fresh backup.
- Keep the old HTML file until the new build is tested.
- Use the same browser profile/device when expecting locally stored data to remain available.
- Do not clear browser site data or app storage unless you have a verified backup.

CURRENT RELEASE TEST STATUS
---------------------------
Passed:
- Inline JavaScript syntax check.
- Static presence checks for the five Settings categories and dedicated navigation.
- Static check that the Settings Back navigation is present.
- Static check that the Backup category has its own view.
- Static check that the IndexedDB database name/version remain unchanged.
- ZIP integrity test.
- SHA-256 manifest generated for the final package.

Not yet performed:
- Full Android Chrome interactive acceptance test.
- Full end-to-end regression of Delivery, Billing, PDF generation/regeneration,
  Payments, Expenses, Inventory, Production and Reports.
- Backup/restore round-trip test against a real user database.
- Penetration testing or independent security audit.

This package is a complete source/application bundle, not a claim of completed
device-level certification. Use the included Android checklist before production use.
