DOODHMITRA VERSION 7 — MOBILE-FIRST UI RELEASE

START HERE
- DoodhMitra-B8-FINAL.html: standalone offline application.
- DoodhMitra-B8-P12-Simplified-Package/index.html: same application inside the retained development package.

VERSION 7 UI CHANGES
- Replaced the overcrowded 16-item mobile bottom strip with a fixed five-item navigation: Home, Customers, Delivery, Payments and More.
- Added a categorized More drawer with searchable access to every remaining module, including Settings.
- Kept the full desktop sidebar navigation unchanged.
- Preserved Hindi/English switching and the existing dark-green DoodhMitra brand.
- Added safe-area padding, touch-friendly targets, selected-state highlighting, backdrop dismissal and Escape-key dismissal.
- Delivery remains its own primary tab; its existing page and four delivery sections were not modified.

PRESERVATION
- IndexedDB database name and schema version remain unchanged (MilkLedgerDB, version 4).
- No store definitions, business calculations, invoice logic, payment logic, delivery logic or data records were intentionally changed.
- P6–P12 baseline files and prior release notes are retained for reference/rollback.

TESTING STATUS
- JavaScript syntax check: PASS (Node.js --check).
- Static navigation coverage: PASS (all 16 modules represented; 4 primary items plus 12 More-menu items).
- Database schema preservation check: PASS (DBN and VER unchanged).
- Automated live browser/device test: NOT COMPLETED in this environment because Chromium navigation was blocked by the execution sandbox.
- Android device acceptance: PENDING. Please test on a duplicate/test profile before live business use.

IMPORTANT
Keep an independent backup of existing business data before installing or testing. This release is a navigation/UI upgrade, not a penetration-test or production-security certification.
