DoodhMitra B8 - P9: Customer Receipts & Supplier Payments

This is a P9 QA candidate built from the supplied P8 Expense Category Management HTML.

P9 improvements:
- Customer receipt and supplier payment entry remain separate transaction types.
- Supports multiple partial receipts/payments; each payment is stored as an independent payment record.
- Displays current customer and supplier outstanding when selecting a party.
- Shows today's customer receipts and supplier payments, plus current outstanding totals.
- Adds payment-register filters for date range, type, payment mode and party/name/mobile/reference search.
- Adds a separate reference field while retaining the legacy note field.
- Edit requires a correction reason and records before/after values in Activity History.
- Delete requires a reason and records the previous entry in Activity History.
- Purchase-linked supplier payment records remain protected from edit/delete in the Payments screen.
- Payment modes are Cash, UPI, Bank Transfer and Other for classification only. No cash/bank balances, opening balances or transfers are maintained.

Compatibility:
- Existing IndexedDB database name MilkLedgerDB and version 4 are preserved.
- No new object store or schema migration is introduced.
- Existing payment records continue to use the payments store and retain party/kind/pid/amount/method/note fields.
- New optional reference field is additive and old records remain readable.
- P8 source is retained as a baseline; P6/P7 baselines are included from the P8 package.

Install/test:
1. Keep your P6/P7/P8 files and a JSON backup safe.
2. Test P9 on a duplicate/test profile first; do not overwrite your working app before device acceptance.
3. Test partial receipts, supplier payments, edit/delete audit history and customer/supplier outstanding reconciliation.
4. Test Android Chrome, backup/restore and all protected workflows before live use.
