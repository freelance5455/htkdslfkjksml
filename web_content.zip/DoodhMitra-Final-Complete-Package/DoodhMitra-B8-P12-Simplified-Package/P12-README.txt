DoodhMitra B8 — P12 Final Integration & Release Candidate

P12 establishes a consolidated release-candidate package from the P11 Financial Summary baseline. The application source is intentionally carried forward unchanged in this phase to avoid introducing unverified code changes during final integration.

Included capabilities carried forward:
- Expenses foundation and custom expense categories.
- Customer receipts and supplier payments, including partial receipts/payments.
- Payment history, outstanding summaries and payment-mode reporting.
- Expense analysis, paid/unpaid separation, category analysis and CSV reporting.
- Existing Delivery, Billing, PDF/bulk billing, Stock and Production modules.

Accounting decisions preserved:
- Payment modes are classifications only (Cash, UPI, Bank Transfer, Other).
- No separate Cash/Bank balances, opening balances or transfers.
- Unpaid expenses are not represented as paid cash movements.
- Payment/expense records and their existing history remain in the existing database.

Compatibility: IndexedDB database name MilkLedgerDB, version 4; no schema migration in P12.

IMPORTANT: This is a static-QA release candidate, not an Android-device-certified or production-certified release. Complete the device acceptance checklist before live use. Keep P11 as the rollback baseline and test with a duplicate profile first.
