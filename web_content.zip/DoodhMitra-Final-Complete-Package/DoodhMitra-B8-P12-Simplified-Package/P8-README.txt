DoodhMitra B8 - P8 Expense Category Management
================================================
STATUS
------
P8 implementation candidate. Static checks passed; Android device acceptance remains required.

P8 FEATURES
-----------
- Adds custom expense categories saved in the existing settings store (key: expenseCategories).
- Default expense categories remain available.
- Custom categories can be archived; they are not hard-deleted. Existing expense records remain intact.
- Active custom categories appear in the new-expense form and register filter.
- Expense records store categoryName snapshots so archived categories remain readable.
- Expense category add/archive actions are recorded in Activity History.
- Expense reports use saved category names instead of displaying internal category IDs.
- No new IndexedDB store, index or database-version migration.
- Payment modes remain informational only; no Cash/Bank balances or transfers.

PROTECTED AREAS
---------------
P7 expense foundation and existing Payment, Delivery, Billing, PDF, bulk billing, Stock and Production code are carried forward, except for expense category integration in expense/report code.

TEST ON A DUPLICATE PROFILE
---------------------------
Add a category; create an expense under it; filter by it; edit the expense; archive the category; confirm the old expense still displays its category name; confirm archived category is absent from new-entry choices; export/restore backup; test all protected workflows.
