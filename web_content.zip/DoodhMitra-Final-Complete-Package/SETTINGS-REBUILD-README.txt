DOODHMITRA — SETTINGS MODULE REBUILD

Start the application:
DoodhMitra-B8-P12-Simplified-Package/index.html

Settings has been rebuilt with five separate screens:
1. Business Profile
2. Invoice Settings
3. Invoice Designer
4. Invoice Preferences
5. Backup & Data Management

Each category has its own Save Changes action. Designer preview updates live.
Back returns to the five-category landing screen.

DATA SAFETY
- The IndexedDB database name/version/schema were not changed.
- Existing settings remain under the existing businessProfile key.
- Category saves merge only the fields belonging to that category.
- Download a backup before replacing your currently used app.
- To retain existing records, open the new file in the same browser/device storage
  context as the old application.

Read SETTINGS-REBUILD-CHANGELOG.txt and SETTINGS-REBUILD-QA-REPORT.txt for details.
