const band1 = document.getElementById("band1");
const band2 = document.getElementById("band2");
const band3 = document.getElementById("band3");
const band4 = document.getElementById("band4");
const answer = document.getElementById("answer");

function formatResistance(value) {
  if (value >= 1_000_000_000) {
    return `${Number((value / 1_000_000_000).toPrecision(4))} GΩ`;
  }
  if (value >= 1_000_000) {
    return `${Number((value / 1_000_000).toPrecision(4))} MΩ`;
  }
  if (value >= 1_000) {
    return `${Number((value / 1_000).toPrecision(4))} kΩ`;
  }
  return `${Number(value.toPrecision(4))} Ω`;
}

function calculateResistance() {
  const firstDigit = Number(band1.value);
  const secondDigit = Number(band2.value);
  const multiplier = Number(band3.value);
  const tolerance = Number(band4.value);
  const resistance = (firstDigit * 10 + secondDigit) * multiplier;

  answer.textContent = `${formatResistance(resistance)} ±${String(tolerance).replace(".", ",")}%`;
}

[band1, band2, band3, band4].forEach((select) => {
  select.addEventListener("change", calculateResistance);
});

calculateResistance();
