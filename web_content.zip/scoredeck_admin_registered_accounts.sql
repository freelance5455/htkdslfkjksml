-- Apply this migration in the connected Supabase project before testing the Roles dropdown.
-- Returns only the limited fields required by the owner-only account picker.
create or replace function public.scoredeck_admin_registered_accounts()
returns table (
  user_id uuid,
  display_name text,
  class_level text,
  account_created_at timestamptz,
  role text
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null or not exists (
    select 1 from public.scoredeck_admin_roles r
    where r.user_id = auth.uid() and r.role = 'owner'
  ) then
    raise exception 'Owner permission required';
  end if;

  return query
    select p.id,
           coalesce(nullif(p.display_name, ''), 'ScoreDeck user'),
           p.class_level,
           p.created_at,
           coalesce(r.role, 'user')
    from public.profiles p
    left join public.scoredeck_admin_roles r on r.user_id = p.id
    order by p.created_at desc;
end;
$$;

revoke all on function public.scoredeck_admin_registered_accounts() from public, anon;
grant execute on function public.scoredeck_admin_registered_accounts() to authenticated;
