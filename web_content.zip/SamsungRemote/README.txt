SAMSUNG REMOTE — APK MAKER PROJECT (V2)

This is an HTML/CSS/JavaScript project packaged as a ZIP for an APK Maker workflow.

WHAT THIS VERSION DOES
- Mobile remote interface for Samsung TVs.
- Tries WebSocket TLS (WSS) port 8002 first.
- If that fails, tries unencrypted WS port 8001.
- Sends common Samsung remote key commands after a connection is established.
- Remembers the last entered TV address on this device.

IMPORTANT LIMITS — PLEASE READ
1. Automatic Wi-Fi discovery is NOT implemented. Ordinary HTML/JavaScript in an Android WebView has no standard API for SSDP/UDP multicast or subnet scanning.
2. Bluetooth manual pairing is NOT implemented. Android WebView does not expose Web Bluetooth, and Samsung TV Bluetooth remote control is not a universal GATT interface.
3. The browser may reject a Samsung TV's self-signed WSS certificate. This project cannot safely override native TLS certificate validation from ordinary HTML/JavaScript.
4. Port 8001 is unencrypted. It should only be used on a trusted private home network.
5. This project does not persist authorization tokens. The TV may ask for permission again.
6. Power-on from standby may require Wake-on-LAN and the TV's MAC address; the Power key may only work while the TV is awake.
7. App launching shortcuts and automatic discovery are not included.
8. Not tested on a physical TV. Compatibility depends on model, firmware, TV settings, and APK Maker's WebView configuration.

HOW TO PACKAGE
- Upload this ZIP to APK Maker using its HTML/ZIP project option.
- Build the APK.
- Install it and connect phone and TV to the same Wi-Fi.
- Find the TV's local IP in its Network Status settings, enter it, then tap Connect.

WHY IT CANNOT DO THE REQUESTED FULL AUTO MODE
The requested automatic Wi-Fi scan and Bluetooth fallback require native Android APIs:
- SSDP/mDNS/local-network discovery via Android networking/multicast APIs.
- Bluetooth device discovery and Classic Bluetooth/BLE handling via Android Bluetooth APIs.
- WSS self-signed certificate trust-on-first-use and secure token storage via Android networking and Keystore APIs.
A plain HTML ZIP cannot add these native capabilities to the APK Maker wrapper. A native bridge supplied by APK Maker would be needed.

V2.1 FIX: IPv4 validation now checks four dot-separated numeric parts (1–3 digits each, 0–255), so valid two-digit final sections are accepted.
