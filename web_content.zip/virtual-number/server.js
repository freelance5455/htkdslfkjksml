import express from 'express';
import twilio from 'twilio';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const env = process.env;
const SID = env.TWILIO_ACCOUNT_SID, TOKEN = env.TWILIO_AUTH_TOKEN;
if (!SID || !TOKEN) { console.error('Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN (see .env.example)'); process.exit(1); }
const PORT = +env.PORT || 3000;
const RENTAL_MS = (+env.RENTAL_HOURS || 24) * 3600e3;
const MAX_ACTIVE = +env.MAX_ACTIVE_NUMBERS || 10;
const MAX_PER_IP_DAY = +env.MAX_RENTALS_PER_IP_PER_DAY || 3;
const DATA_FILE = env.DATA_FILE || './data/store.json';
const BUNDLES = JSON.parse(env.TWILIO_BUNDLES || '{}');
const HOOK_PATH = '/webhooks/twilio/sms';
const HOOK_URL = env.PUBLIC_URL ? env.PUBLIC_URL.replace(/\/$/, '') + HOOK_PATH : '';
const client = twilio(SID, TOKEN, { timeout: 20000 });

// ---- tiny persistent store (users -> rental). Swap for a real DB if you scale out. ----
let db = { rentals: {} };
try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch {}
let saveTimer;
const save = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DATA_FILE);
}, 200); };

// ---- rate limiting ----
const hits = new Map();
const recent = (k, win) => { const n = Date.now(); const a = (hits.get(k) || []).filter(t => n - t < win); hits.set(k, a); return a.length; };
const hit = k => hits.get(k).push(Date.now());
setInterval(() => { for (const k of hits.keys()) if (!recent(k, 864e5)) hits.delete(k); }, 6e5).unref();

// ---- helpers ----
const CODE_RE = /(?<![\d+])(\d{3}[-\s]\d{3}|\d{4,8})(?!\d)/;
const extractCode = b => { const m = CODE_RE.exec(b || ''); return m ? m[1].replace(/\D/g, '') : null; };
const view = r => ({
  number: r.number, country: r.country, expiresAt: r.expiresAt,
  messages: [...r.messages].sort((a, b) => b.receivedAt - a.receivedAt).map(m => ({ ...m, code: extractCode(m.body) })),
});
const getActive = uid => {
  const r = db.rentals[uid];
  if (!r) return null;
  if (r.expiresAt > Date.now()) return r;
  release(uid).catch(() => {});
  return null;
};
async function release(uid) {
  const r = db.rentals[uid];
  if (!r) return;
  try { await client.incomingPhoneNumbers(r.twilioSid).remove(); }
  catch (e) { if (e.status !== 404) throw e; }   // 404 = already gone
  delete db.rentals[uid]; save();
}
setInterval(() => { for (const [uid, r] of Object.entries(db.rentals))
  if (r.expiresAt <= Date.now()) release(uid).catch(e => console.error('release failed', e.message)); }, 6e4).unref();

function addMessage(r, m) {
  if (r.messages.some(x => x.id === m.id)) return false;
  r.messages.push(m); r.messages = r.messages.slice(-100); save(); return true;
}
async function sync(r) {                          // pull the real inbox from Twilio
  const list = await client.messages.list({ to: r.number, dateSentAfter: new Date(r.createdAt - 6e4), limit: 50 });
  for (const m of list) if (m.direction === 'inbound')
    addMessage(r, { id: m.sid, from: m.from, body: m.body, receivedAt: +new Date(m.dateCreated || m.dateSent) });
  r.lastSync = Date.now();
}

async function provision(country) {
  const errors = [];
  for (const type of ['mobile', 'local']) {
    let found = [];
    try { found = await client.availablePhoneNumbers(country)[type].list({ smsEnabled: true, limit: 5 }); }
    catch (e) { errors.push(e); continue; }
    for (const c of found) {
      try {
        return await client.incomingPhoneNumbers.create({
          phoneNumber: c.phoneNumber, friendlyName: 'vn-rental',
          ...(HOOK_URL && { smsUrl: HOOK_URL, smsMethod: 'POST' }),
          ...(BUNDLES[country] && { bundleSid: BUNDLES[country] }),
          ...(env.TWILIO_ADDRESS_SID && { addressSid: env.TWILIO_ADDRESS_SID }),
        });
      } catch (e) { errors.push(e); }
    }
  }
  console.error('provision failed', country, errors.map(e => `${e.status}/${e.code}: ${e.message}`));
  if (errors.some(e => e.status === 401 || e.status >= 500 || !e.status)) throw Object.assign(new Error('provider'), { api: 'PROVIDER' });
  if (errors.some(e => /bundle|address|regulat/i.test(e.message))) throw Object.assign(new Error('req'), { api: 'REQUIREMENT' });
  throw Object.assign(new Error('none'), { api: 'NO_NUMBER' });
}

// ---- app ----
const app = express();
app.disable('x-powered-by');
if (env.TRUST_PROXY) app.set('trust proxy', +env.TRUST_PROXY || env.TRUST_PROXY);

if (HOOK_URL) app.post(HOOK_PATH, express.urlencoded({ extended: false, limit: '20kb' }), (req, res) => {
  const ok = twilio.validateRequest(TOKEN, req.get('X-Twilio-Signature') || '', HOOK_URL, req.body);
  if (!ok) return res.sendStatus(403);
  const r = Object.values(db.rentals).find(x => x.number === req.body.To);
  if (r) addMessage(r, { id: req.body.MessageSid, from: req.body.From, body: req.body.Body || '', receivedAt: Date.now() });
  res.type('text/xml').send('<Response/>');
});

app.use((req, res, next) => { res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'" }); next(); });
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), 'public')));
app.use('/api', express.json({ limit: '2kb' }), (req, res, next) => {
  if (recent('api:' + req.ip, 6e4) >= 120) return res.status(429).json({ error: 'RATE' });
  hit('api:' + req.ip);
  if (req.method !== 'GET' && req.get('X-Requested-With') !== 'app') return res.sendStatus(403);
  let uid = /(?:^|;\s*)uid=([a-f0-9]{48})/.exec(req.headers.cookie || '')?.[1];
  if (!uid) { uid = crypto.randomBytes(24).toString('hex');
    res.cookie('uid', uid, { httpOnly: true, sameSite: 'strict', secure: env.NODE_ENV === 'production', maxAge: 30 * 864e5 }); }
  req.uid = uid; next();
});
const wrap = fn => (req, res) => fn(req, res).catch(e => {
  console.error('api error', e.status || '', e.code || '', e.message);
  res.status(e.api === 'NO_NUMBER' ? 404 : 502).json({ error: e.api || 'PROVIDER' });
});

let countries = { at: 0, list: [] };
app.get('/api/countries', wrap(async (req, res) => {
  if (Date.now() - countries.at > 6 * 3600e3) {
    const all = await client.availablePhoneNumbers.list({ limit: 300 });
    countries = { at: Date.now(), list: all.map(c => c.countryCode).sort() };
  }
  res.json({ countries: countries.list, push: !!HOOK_URL });
}));

app.get('/api/number', wrap(async (req, res) => {
  const r = getActive(req.uid);
  res.json(r ? view(r) : { number: null });
}));

const busy = new Set();
app.post('/api/number', wrap(async (req, res) => {
  const country = String(req.body?.country || '').toUpperCase();
  if (!/^[A-Z]{2}$/.test(country)) return res.status(400).json({ error: 'BAD_COUNTRY' });
  const existing = getActive(req.uid);
  if (existing) return res.status(409).json({ error: 'EXISTS', ...view(existing) });
  if (busy.has(req.uid)) return res.status(429).json({ error: 'RATE' });
  if (Object.keys(db.rentals).length >= MAX_ACTIVE || recent('buy:' + req.ip, 864e5) >= MAX_PER_IP_DAY)
    return res.status(429).json({ error: 'LIMIT' });
  busy.add(req.uid);
  try {
    const n = await provision(country);
    hit('buy:' + req.ip);
    const now = Date.now();
    db.rentals[req.uid] = { country, number: n.phoneNumber, twilioSid: n.sid, createdAt: now, expiresAt: now + RENTAL_MS, messages: [], lastSync: 0 };
    save();
    res.json(view(db.rentals[req.uid]));
  } finally { busy.delete(req.uid); }
}));

app.delete('/api/number', wrap(async (req, res) => { await release(req.uid); res.json({ number: null }); }));

app.get('/api/messages', wrap(async (req, res) => {
  const r = getActive(req.uid);
  if (!r) return res.status(404).json({ error: 'NO_RENTAL' });
  const force = req.query.refresh === '1';
  if (force || (!HOOK_URL && Date.now() - r.lastSync > 8000)) await sync(r);
  res.json(view(r));
}));

app.listen(PORT, () => console.log(`Virtual number app on :${PORT} (webhook ${HOOK_URL || 'off, polling Twilio'})`));
