# Virtual Number

Pick a country → **Get Number** → a real, dedicated Twilio number is purchased for you → use it on a service → **Refresh** → see the real SMS and the detected code. Persian/English UI.

## Provider choice
| | Twilio (implemented) | Telnyx |
|---|---|---|
| Number rental (US local) | ~$1.15/mo | ~$1.00/mo |
| Inbound SMS (US) | ~$0.0075–0.0083 | free to ~$0.004 (sources differ) |
| Countries | 100+, many need regulatory bundles | many, similar rules |
| List a number's real inbox via API | **Yes** (`messages.list`) – powers Refresh | No, webhook only |

Twilio is implemented because Refresh must read the number's actual inbox. Prices are list prices from public sources (2026); check the live price sheets. Telnyx is cheaper per number; to use it you must store webhook messages yourself and replace `provision()`/`sync()` in `server.js`.

**Cost reality:** Twilio bills a number monthly from purchase and does not refund on release. Each rental therefore costs about one month of number fees (~$1.15+, more for mobile numbers) plus a fraction of a cent per SMS. Charge users at least that, or keep the limits below low. Per-activation services (cents per code) exist but are shared-pool services that need a target service name, so they don't fit "dedicated number, any service".

## What you must provide
1. A Twilio account, **upgraded and funded** (trial accounts can't buy numbers freely). Account SID + Auth Token.
2. For many countries (UK, DE, FR, AU…): a Twilio **regulatory bundle / address** (identity or business verification). Put IDs in `TWILIO_BUNDLES='{"GB":"BU..."}'`. Without it the app shows a clear "requires a bundle" error. Some countries aren't sold by Twilio at all (e.g. Iran).
3. A public **HTTPS URL** (`PUBLIC_URL`) for instant delivery via webhook. Without it the app still works by polling Twilio every ~8 s and on Refresh.

## Run
```bash
npm install
cp .env.example .env     # fill in values
export $(grep -v '^#' .env | xargs) && npm start     # or: node --env-file=.env server.js
```
Open http://localhost:3000. Webhooks need a public URL (e.g. `cloudflared tunnel --url http://localhost:3000`, set as `PUBLIC_URL`).

## Deploy (cheapest)
Any small Node host (Fly.io, Render, Railway, a $4 VPS). Set the env vars, set `NODE_ENV=production`, keep HTTPS in front, and put `data/` on a persistent volume. Run **one instance** (the store is a JSON file; use a real DB to scale out). Set `TRUST_PROXY=1` behind a proxy so IP limits work.

## Security model
- Twilio credentials live only in server env vars.
- Each browser gets a random HttpOnly, SameSite=Strict cookie; its rental is keyed to it, so a user can only read their own number's messages.
- Webhook requests are verified with Twilio's signature; mutating API calls require a custom header (CSRF).
- Spend guards: 1 number per user, `MAX_ACTIVE_NUMBERS` global cap, `MAX_RENTALS_PER_IP_PER_DAY`, API rate limit.
- Rentals expire after `RENTAL_HOURS`; the number is released at Twilio and messages deleted. Stored messages (codes) are in `data/store.json` (mode 600).

## Not verified
This was built without live Twilio credentials, so it hasn't been run end to end. Test with one purchase in your own account and check the Twilio console. Many websites block VoIP numbers, and Twilio's Acceptable Use Policy and the target services' terms apply to how you offer this.
