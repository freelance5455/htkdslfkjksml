const chat=document.getElementById("chat"), input=document.getElementById("input"), send=document.getElementById("send"), mic=document.getElementById("mic"), statusEl=document.getElementById("status"), installBtn=document.getElementById("installBtn");
const synth=window.speechSynthesis;
let deferredPrompt=null;
let messages=[];

function addMsg(text,who){
  const d=document.createElement("div");
  d.className="msg "+who;
  d.textContent=text;
  chat.appendChild(d);
  chat.scrollTop=chat.scrollHeight;
  return d
}
function save(){
  localStorage.setItem("jarvisChat",chat.innerHTML);
  localStorage.setItem("jarvisMessages",JSON.stringify(messages.slice(-30)));
}
function load(){
  const s=localStorage.getItem("jarvisChat");
  const m=localStorage.getItem("jarvisMessages");
  if(s) chat.innerHTML=s;
  if(m){try{messages=JSON.parse(m)}catch(e){messages=[]}}
}
function speak(text){
  if(!synth)return;
  synth.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.rate=.96;u.pitch=.9;u.volume=1;
  synth.speak(u)
}
function reply(text){
  addMsg(text,"jarvis");
  save();
  speak(text)
}

async function askAI(q){
  const history=messages.slice(-20);
  history.push({role:"user",content:q});
  const res=await fetch("/api/chat",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({messages:history})
  });
  const data=await res.json();
  if(!res.ok) throw new Error(data.error||"AI request failed");
  return data.text;
}

async function sendMsg(){
  const q=input.value.trim();
  if(!q)return;
  addMsg(q,"user");
  messages.push({role:"user",content:q});
  input.value="";
  statusEl.textContent="THINKING";
  send.disabled=true;
  try{
    const a=await askAI(q);
    addMsg(a,"jarvis");
    messages.push({role:"assistant",content:a});
    save();
    speak(a);
  }catch(err){
    const msg="I couldn't reach my AI core. Check that the secure backend is running and that OPENAI_API_KEY is configured.";
    addMsg(msg,"jarvis");
    messages.push({role:"assistant",content:msg});
    save();
    console.error(err);
  }finally{
    statusEl.textContent="ONLINE";
    send.disabled=false;
  }
}
send.onclick=sendMsg;
input.addEventListener("keydown",e=>{if(e.key==="Enter")sendMsg()});

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){
  const rec=new SR();
  rec.lang=navigator.language||"en-US";
  rec.interimResults=false;
  rec.maxAlternatives=1;
  rec.onstart=()=>{statusEl.textContent="LISTENING";mic.textContent="⏹️"};
  rec.onend=()=>{statusEl.textContent="ONLINE";mic.textContent="🎙️"};
  rec.onerror=()=>{statusEl.textContent="ONLINE";mic.textContent="🎙️"};
  rec.onresult=e=>{input.value=e.results[0][0].transcript;sendMsg()};
  mic.onclick=()=>{try{rec.start()}catch(e){rec.stop()}};
}else{
  mic.disabled=true;
  mic.title="Speech recognition is not available in this browser";
}

load();
if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault();deferredPrompt=e;installBtn.hidden=false
});
installBtn.onclick=async()=>{
  if(deferredPrompt){
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt=null;
    installBtn.hidden=true
  }
};
