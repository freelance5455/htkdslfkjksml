import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not configured. JARVIS AI requests will fail until it is added to the server environment.");
}

const client = new OpenAI();

app.use(express.json({limit:"64kb"}));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/chat", async (req, res) => {
  try {
    const incoming = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const messages = incoming
      .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-20);

    if (!messages.length) {
      return res.status(400).json({error:"No messages supplied."});
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({error:"OPENAI_API_KEY is not configured on the server."});
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions: `You are JARVIS, a calm, capable personal AI assistant.
Speak naturally and concisely. You may have a futuristic butler personality.
Never claim to control the user's phone, camera, microphone, accounts, or smart devices unless a real tool has actually been connected.
If you do not know something, say so plainly.`,
      input: messages
    });

    res.json({text: response.output_text || "I received your request, but I had no text response."});
  } catch (error) {
    console.error(error);
    res.status(500).json({error:"The AI backend could not complete the request."});
  }
});

app.get("*", (req,res) => {
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(port, "0.0.0.0", () => {
  console.log(`JARVIS is running on port ${port}`);
});
