# JARVIS V1 + Secure OpenAI Backend

This version keeps the OpenAI API key on the server.

## Setup
1. Put your OpenAI API key in the server environment as `OPENAI_API_KEY`.
2. Never paste the key into `public/app.js`.
3. Install dependencies with `npm install`.
4. Start with `npm start`.
5. Open the app over HTTPS when using it as an installable Android PWA.

The frontend calls `/api/chat`; the server calls the OpenAI Responses API.
