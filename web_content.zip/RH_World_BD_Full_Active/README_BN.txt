R.H World BD — সম্পূর্ণ ক্যাটালগ (আপডেটেড)

মোট পণ্য: ২০,০৩০
ক্যাটাগরি: ৪১টি
লাইট ও টর্চ: ৩০টি (১ নং Pocketman Type-C ৳৯৫০)

সোর্স:
1) Normal Website Updated
2) AI Website Updated  
3) Category Markup Updated
+ Pocketman টর্চ ছবি

প্রতি পৃষ্ঠায় ২৪টি পণ্য → প্রায় ৮৩৫ পৃষ্ঠা (সব মাল মিলিয়ে)।
ফিল্টার/ক্যাটাগরি দিয়ে কমিয়ে দেখুন।

চালানো: index.html খুলুন অথবা node server.js → http://localhost:3000
অ্যাডমিন: admin / admin123
