// R.H World BD product-link lookup server. Node.js 18+
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const ALLOWED = ['aliexpress.com','www.aliexpress.com','m.aliexpress.com','alibaba.com','www.alibaba.com','detail.1688.com','1688.com','taobao.com','www.taobao.com','item.taobao.com'];
const FX = { USD: 120, CNY: 17, RMB: 17, EUR: 130, GBP: 150, HKD: 15.5, JPY: 0.82, KRW: 0.09 };
function fetchText(url, redirects=0){return new Promise((resolve,reject)=>{
 if(redirects>5) return reject(new Error('অতিরিক্ত redirect পাওয়া গেছে'));
 const u=new URL(url); const lib=u.protocol==='https:'?https:http;
 const req=lib.get(u,{headers:{'User-Agent':'Mozilla/5.0 (compatible; RHWorldBDProductBot/1.0)','Accept':'text/html,application/xhtml+xml','Accept-Language':'en-US,en;q=0.9'},timeout:18000},res=>{
  if([301,302,303,307,308].includes(res.statusCode)&&res.headers.location){res.resume();return resolve(fetchText(new URL(res.headers.location,u).href,redirects+1));}
  let body='';res.setEncoding('utf8');res.on('data',c=>{body+=c;if(body.length>5_000_000)req.destroy(new Error('পেজটি অনেক বড়'));});res.on('end',()=>resolve({status:res.statusCode,body,finalUrl:u.href,headers:res.headers}));
 });req.on('timeout',()=>req.destroy(new Error('সময় শেষ হয়েছে')));req.on('error',reject);
});}
function decode(s=''){return String(s).replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\\u0026/g,'&').trim();}
function strip(s=''){return decode(String(s).replace(/<[^>]*>/g,' ').replace(/\\s+/g,' '));}
function meta(html,key){const esc=key.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const a=new RegExp(`<meta[^>]+(?:property|name)=[\"']${esc}[\"'][^>]+content=[\"']([^\"']+)`,'i');const b=new RegExp(`<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"']${esc}[\"']`,'i');const m=html.match(a)||html.match(b);return m?decode(m[1]):'';}
function collectProducts(node,out=[]){if(!node||typeof node!=='object')return out;if(Array.isArray(node)){for(const x of node)collectProducts(x,out);return out;}const t=node['@type'];if(t==='Product'||(Array.isArray(t)&&t.includes('Product')))out.push(node);for(const v of Object.values(node))if(v&&typeof v==='object')collectProducts(v,out);return out;}
function parseProduct(html,url){let jsonProducts=[];const re=/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;let m;while((m=re.exec(html))){try{jsonProducts.push(...collectProducts(JSON.parse(m[1])))}catch{}}
 let p=jsonProducts.find(x=>x.name)||{};let title=strip(p.name)||strip(meta(html,'og:title'))||strip(meta(html,'twitter:title'));
 let image='';const im=p.image;if(typeof im==='string')image=im;else if(Array.isArray(im))image=typeof im[0]==='string'?im[0]:(im[0]?.url||'');else if(im&&typeof im==='object')image=im.url||'';image=image||meta(html,'og:image')||meta(html,'twitter:image');
 let offer=p.offers||{};if(Array.isArray(offer))offer=offer[0]||{};if(offer.offers&&Array.isArray(offer.offers))offer=offer.offers[0]||{};
 let price=offer.price||offer.lowPrice||p.price||meta(html,'product:price:amount')||meta(html,'og:price:amount');let currency=offer.priceCurrency||p.priceCurrency||meta(html,'product:price:currency')||meta(html,'og:price:currency')||'USD';
 let desc=strip(p.description||meta(html,'og:description')||meta(html,'description'));
 let sizes=[],colors=[];
 const variants=[];for(const x of jsonProducts){if(x.hasVariant){const a=Array.isArray(x.hasVariant)?x.hasVariant:[x.hasVariant];variants.push(...a)}if(x.additionalProperty){const a=Array.isArray(x.additionalProperty)?x.additionalProperty:[x.additionalProperty];for(const z of a){const n=String(z.name||'').toLowerCase(),v=String(z.value||'').trim();if(v&&(/size|sizing|সাইজ/.test(n)))sizes.push(v);if(v&&(/color|colour|রং/.test(n)))colors.push(v)}}}
 for(const v of variants){for(const [k,a] of [['size',sizes],['color',colors]]){const val=v[k]||v[k==='size'?'size':'color'];if(val)a.push(String(val));}}
 // Extract visible option labels where the marketplace embeds variant choices in HTML.
 for(const m of html.matchAll(/<option[^>]*>([^<]{1,45})<\/option>/gi)){const v=strip(m[1]);if(!v||/select|choose|please|option|--/i.test(v))continue;if(/^(XS|S|M|L|XL|XXL|XXXL|[0-9]{2,3}(?:cm|mm)?)$/i.test(v))sizes.push(v);if(/^(black|white|red|blue|green|pink|purple|gray|grey|yellow|brown|orange|navy|beige)$/i.test(v))colors.push(v);}
 sizes=[...new Set(sizes)].slice(0,40);colors=[...new Set(colors)].slice(0,40);
 const n=Number(String(price).replace(/[^0-9.]/g,''));const cur=String(currency).toUpperCase();const baseBDT=Number.isFinite(n)&&FX[cur]?Math.round(n*FX[cur]):null;
 return {title,image,description:desc,originalPrice:price?String(price):'',currency:cur,baseBDT,finalBDT:baseBDT===null?null:baseBDT+500 /* China WH + BD WH combined */,sizes,colors,source:new URL(url).hostname,priceNote:baseBDT===null?'মূল্য/মুদ্রা স্বয়ংক্রিয়ভাবে শনাক্ত হয়নি':'আনুমানিক বিনিময় হার দিয়ে হিসাব'};
}
function send(res,status,obj){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api/product'){
  try{const raw=u.searchParams.get('url');if(!raw)return send(res,400,{error:'পণ্যের লিংক দিন'});let target;try{target=new URL(raw)}catch{return send(res,400,{error:'সঠিক URL দিন'});}if(target.protocol!=='https:'||!ALLOWED.includes(target.hostname.toLowerCase()))return send(res,400,{error:'শুধু AliExpress, Alibaba, 1688 বা Taobao-এর HTTPS পণ্যের লিংক গ্রহণ করা হবে'});
   const got=await fetchText(target.href);if(got.status<200||got.status>=400)return send(res,502,{error:'মার্কেটপ্লেস পেজটি তথ্য দিতে রাজি হয়নি (HTTP '+got.status+')'});
   const product=parseProduct(got.body,got.finalUrl);if(!product.title)return send(res,422,{error:'এই পেজ থেকে পণ্যের নাম পাওয়া যায়নি। মার্কেটপ্লেস লগইন/বট-সুরক্ষা বা পেজের ধরন বাধা দিতে পারে।'});send(res,200,product);
  }catch(e){send(res,502,{error:'পণ্য আনা যায়নি: '+e.message});}return;
 }
 const file=u.pathname==='/'?'index.html':decodeURIComponent(u.pathname.slice(1));const full=path.resolve(ROOT,file);if(!full.startsWith(ROOT+path.sep)&&full!==path.join(ROOT,'index.html')){res.writeHead(403);return res.end('Forbidden');}
 fs.readFile(full,(err,data)=>{if(err){res.writeHead(404);return res.end('Not found');}const ext=path.extname(full);res.writeHead(200,{'Content-Type':ext==='.html'?'text/html; charset=utf-8':'application/octet-stream'});res.end(data);});
});
server.listen(PORT,()=>console.log(`R.H World BD চলছে: http://localhost:${PORT}`));
