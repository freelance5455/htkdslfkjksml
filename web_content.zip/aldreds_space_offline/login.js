(() => {
  "use strict";

  // Offline learning demo: account records are stored in this browser/device.
  // This is not suitable for protecting highly sensitive information.
  const DB_NAME = "AldredsSpaceAccounts";
  const DB_VERSION = 1;
  const STORE_NAME = "accounts";

  const authPanel = document.getElementById("authPanel");
  const dashboard = document.getElementById("dashboard");
  const form = document.getElementById("authForm");
  const title = document.getElementById("formTitle");
  const subtitle = document.getElementById("formSubtitle");
  const usernameInput = document.getElementById("username");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const confirmInput = document.getElementById("confirmPassword");
  const confirmGroup = document.getElementById("confirmGroup");
  const submitButton = document.getElementById("submitButton");
  const message = document.getElementById("message");
  const switchText = document.getElementById("switchText");
  const switchButton = document.getElementById("switchButton");

  let db = null;
  let mode = "signup";

  function showMessage(text, kind = "") {
    message.textContent = text;
    message.className = kind;
  }

  function openDatabase() {
    return new Promise((resolve, reject) => {
      if (!("indexedDB" in window)) {
        reject(new Error("This browser does not support local account storage."));
        return;
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE_NAME)) {
          const store = database.createObjectStore(STORE_NAME, {
            keyPath: "usernameKey"
          });
          store.createIndex("emailKey", "emailKey", { unique: true });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Could not open local storage."));
    });
  }

  function getByUsername(usernameKey) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).get(usernameKey);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  function getByEmail(emailKey) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).index("emailKey").get(emailKey);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  function saveAccount(account) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).add(account);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error("Could not save account."));
      tx.onabort = () => reject(tx.error || new Error("Account creation was cancelled."));
    });
  }

  function bytesToBase64(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }

  function base64ToBytes(value) {
    return Uint8Array.from(atob(value), character => character.charCodeAt(0));
  }

  async function hashPassword(password, saltBytes) {
    if (!window.crypto || !crypto.subtle) {
      throw new Error(
        "Password hashing is unavailable in this browser context. Try opening the app in a modern browser or through a local app wrapper."
      );
    }

    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(password),
      "PBKDF2",
      false,
      ["deriveBits"]
    );

    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt: saltBytes, iterations: 310000, hash: "SHA-256" },
      keyMaterial,
      256
    );

    return bytesToBase64(new Uint8Array(bits));
  }

  function randomSalt() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return bytes;
  }

  function setMode(nextMode) {
    mode = nextMode;
    const isSignup = mode === "signup";

    title.textContent = isSignup ? "Create Account" : "Confirm Identity";
    subtitle.textContent = isSignup
      ? "Create your local account to get started."
      : "Enter the details you used when you signed up.";
    confirmGroup.hidden = !isSignup;
    confirmInput.required = isSignup;
    passwordInput.autocomplete = isSignup ? "new-password" : "current-password";
    submitButton.textContent = isSignup ? "Create Account" : "Log in";
    switchText.firstChild.textContent = isSignup
      ? "Already have an account? "
      : "New here? ";
    switchButton.textContent = isSignup ? "Log in" : "Create account";
    showMessage("");
    passwordInput.value = "";
    confirmInput.value = "";
  }

  function showDashboard(account) {
    authPanel.hidden = true;
    dashboard.hidden = false;
    document.getElementById("welcomeTitle").textContent = `Welcome, ${account.username}!`;
    document.getElementById("dashboardUsername").textContent = account.username;
    document.getElementById("dashboardEmail").textContent = account.email;
  }

  function showAuth() {
    dashboard.hidden = true;
    authPanel.hidden = false;
    form.reset();
    setMode("login");
  }

  switchButton.addEventListener("click", () => {
    setMode(mode === "signup" ? "login" : "signup");
  });

  document.getElementById("logoutButton").addEventListener("click", showAuth);

  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (!db) {
      showMessage("Local account storage is not ready. Reload the page and try again.", "error");
      return;
    }

    submitButton.disabled = true;
    showMessage("");

    try {
      const username = usernameInput.value.trim();
      const usernameKey = username.toLowerCase();
      const email = emailInput.value.trim();
      const emailKey = email.toLowerCase();
      const password = passwordInput.value;

      if (username.length < 3) {
        throw new Error("Username must contain at least 3 characters.");
      }

      if (mode === "signup") {
        if (password.length < 8) {
          throw new Error("Choose a password with at least 8 characters.");
        }
        if (password !== confirmInput.value) {
          throw new Error("The passwords do not match.");
        }
        if (await getByUsername(usernameKey)) {
          throw new Error("That username already exists. Please log in.");
        }
        if (await getByEmail(emailKey)) {
          throw new Error("That email is already registered. Please log in.");
        }

        const salt = randomSalt();
        const passwordHash = await hashPassword(password, salt);

        await saveAccount({
          usernameKey,
          username,
          email,
          emailKey,
          salt: bytesToBase64(salt),
          passwordHash,
          createdAt: new Date().toISOString()
        });

        passwordInput.value = "";
        confirmInput.value = "";
        showDashboard({ username, email });
      } else {
        const account = await getByUsername(usernameKey);
        if (!account || account.emailKey !== emailKey) {
          throw new Error("No account matches that username and email.");
        }

        const salt = base64ToBytes(account.salt);
        const enteredHash = await hashPassword(password, salt);

        if (enteredHash !== account.passwordHash) {
          throw new Error("Incorrect password.");
        }

        passwordInput.value = "";
        confirmInput.value = "";
        showDashboard(account);
      }
    } catch (error) {
      showMessage(error.message || "Something went wrong. Please try again.", "error");
    } finally {
      submitButton.disabled = false;
    }
  });

  (async () => {
    try {
      db = await openDatabase();
      setMode("signup");
    } catch (error) {
      submitButton.disabled = true;
      showMessage(
        `${error.message} Some file-viewer apps block local storage or secure cryptography. Try a modern browser or an offline Android app wrapper.`,
        "error"
      );
    }
  })();
})();
