Aldred's Space — offline login demo

Files:
- index.html: account form and dashboard
- login.css: page styling
- login.js: local signup/login logic using IndexedDB and password hashing

How to use:
1. Keep the three files in the same folder.
2. Open index.html in a modern browser that supports IndexedDB and Web Crypto.
3. Create an account using username, email and a password of at least 8 characters.
4. Log out, switch to Log in, and enter the same username, email and password.

Notes:
- Accounts are stored in the browser's local IndexedDB on that device/browser. They are not synced to other devices.
- Clearing browser/site data may delete the accounts.
- This is a learning demo, not production-grade authentication. Client-side local storage can be inspected or altered by someone with sufficient access.
- If opening the HTML directly on Android causes browser security limitations, use a suitable offline Android WebView wrapper or local development setup.
- Optional assets from your original design (favicon.png and tree.jpg) can be copied into this folder; the page still works without them, but the background will use a fallback color.
