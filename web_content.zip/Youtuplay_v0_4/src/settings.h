#ifndef YOUTUPLAY_SETTINGS_H
#define YOUTUPLAY_SETTINGS_H
#include <stdbool.h>
typedef struct {
    bool background_audio_enabled;
    bool ps_triple_press_requested;
} YoutuplaySettings;
void youtuplay_settings_defaults(YoutuplaySettings *settings);
#endif
