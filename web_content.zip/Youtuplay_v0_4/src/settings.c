#include "settings.h"
void youtuplay_settings_defaults(YoutuplaySettings *settings) {
    if (!settings) return;
    settings->background_audio_enabled = false;
    settings->ps_triple_press_requested = false;
}
