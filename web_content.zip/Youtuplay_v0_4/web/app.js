// Interacciones de demostración: no conectan con YouTube ni con funciones del sistema PS4.
const searchInput = document.getElementById('searchInput');
const cards = [...document.querySelectorAll('.category')];
const emptyState = document.getElementById('emptyState');
searchInput.addEventListener('input', () => {
  const term = searchInput.value.trim().toLocaleLowerCase('es');
  let visible = 0;
  cards.forEach(card => {
    const match = card.dataset.name.toLocaleLowerCase('es').includes(term);
    card.hidden = !match;
    if (match) visible++;
  });
  emptyState.hidden = visible !== 0;
});
cards.forEach(card => card.addEventListener('click', () => {
  cards.forEach(item => item.classList.remove('selected'));
  card.classList.add('selected');
}));
