# Youtuplay v0.4 — interfaz web inicial

Este ZIP añade una interfaz `index.html` para visualizar el diseño de Youtuplay.

## Contenido
- `web/index.html`: pantalla principal adaptable a TV/consola y móvil.
- `web/styles.css`: estilos de la interfaz.
- `web/app.js`: navegación local, búsqueda visual y controles de demostración.
- `config/default.ini`: opciones de configuración de ejemplo.
- `src/settings.h` y `src/settings.c`: lectura sencilla de opciones INI (base de ejemplo).
- `plugin/README_ES.md`: límites conocidos de integración con GoldHEN.

## Importante
Esta versión **no es todavía una aplicación PS4 ni un PKG**. `index.html` es una interfaz web de demostración; sus botones no controlan el sistema PS4 ni implementan reproducción real de YouTube/YouTube Music. Para convertirla en una aplicación PS4 hay que integrarla en un proyecto nativo compatible, compilarlo con OpenOrbis y probarlo en la consola.

## Vista previa
Abre `web/index.html` en un navegador para revisar el diseño.
