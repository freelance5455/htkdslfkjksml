# Integración GoldHEN — estado

No se incluye un PRX funcional. No se ha demostrado que una aplicación pueda recibir tres pulsaciones del botón PS ni mantener audio de YouTube mientras se ejecuta otro juego. Estas funciones quedan desactivadas/no implementadas hasta contar con una API compatible y pruebas reales.
