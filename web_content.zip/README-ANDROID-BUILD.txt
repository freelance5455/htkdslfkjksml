BOOK UP — FULL SOURCE + ANDROID WRAPPER PACKAGE
================================================

INCLUDED
- www/index.html: latest Book Up v9 source. The Admin Panel is embedded in this file.
- www/sw.js and www/manifest.webmanifest: PWA shell.
- www/icons/: generated 192px and 512px icons (replace with official Book Up logo if available).
- Capacitor Android wrapper configuration and package.json.
- admin-integration/: optional Supabase table schema and security guidance.
- PLAY-STORE-CHECKLIST.txt and PRIVACY-POLICY-TEMPLATE.txt.

ADMIN / DATA
The Admin Panel is already included in index.html; it is not a separate server app.
Several app settings, uploads and records are stored in browser/device local storage.
They do not automatically sync between devices. The optional cloud panel supports a
Supabase endpoint, but production multi-user access must use authentication and
owner-scoped RLS or a trusted Edge Function. Never place a Supabase service_role key
or any private secret in client-side HTML.

BUILD
Requirements: Node.js 20+, Android Studio, compatible JDK, Android SDK Platform 36.
From this folder run:
  npm install
  npx cap add android
  npm run android:sync
  npm run android:open

In Android Studio choose Build > Generate Signed Bundle / APK > Android App Bundle.
Create your own upload keystore and keep secure backups. Never share the keystore.

APP ID
Currently set to com.bookup.app. Verify that it is unique before first publication.
Change capacitor.config.ts before running `npx cap add android` if required.

IMPORTANT
This is a complete web source + Android wrapper setup package, NOT a signed APK/AAB.
A signed Android binary cannot be generated here without Android SDK/build tools,
your signing key and a tested build environment. Test on real Android devices before
Play Store submission, especially camera/photo picker, downloads, sharing, external
links, offline mode and all admin workflows.
