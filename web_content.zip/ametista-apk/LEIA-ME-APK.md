# Ametista – projeto para gerar o APK

Este ZIP tem o app pronto e a configuração do Capacitor, que transforma o app em Android.
O arquivo APK em si precisa ser gerado no seu computador (ou por um serviço online), porque exige as ferramentas do Android.

## Opção 1: Android Studio (no computador)
1. Instale o Node.js (nodejs.org) e o Android Studio (developer.android.com/studio).
2. Extraia este ZIP e abra o terminal na pasta.
3. Rode, um por vez:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
4. No Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Envie o arquivo `app-debug.apk` para o celular e instale (ative "Instalar apps desconhecidos" quando o Android pedir).

## Opção 2: serviço online
Sites que convertem página em APK (como o PWABuilder) pedem um endereço público na internet. Hospede a pasta `www` (por exemplo no Netlify ou GitHub Pages) e use esse endereço.

## Mudar o app
Edite `www/index.html` e rode `npx cap sync android` de novo.
