# The Cursed Village — browser 3D horror prototype

A small playable first-person horror game built with HTML, CSS, JavaScript, and Three.js.

## Run it
Three.js is loaded as an ES module from jsDelivr, so you need an internet connection and a local web server.

### Option A: Python
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run: `python -m http.server 8000`
4. Open `http://localhost:8000` in your browser.

### Option B: VS Code
Install the Live Server extension, right-click `index.html`, and choose **Open with Live Server**.

## Controls
- PC: WASD / arrow keys to move, mouse to look, Shift to sprint, C to crouch, F to toggle flashlight, E to interact, Esc to pause.
- Android: left joystick to move, drag the right side of the screen to look, and tap the on-screen buttons.

## Current prototype
- Low-poly 3D village with fog, houses, trees, school, shrine, lamps, and gate
- First-person camera and flashlight
- Touchscreen movement and look controls
- Collectible key, readable clue, and escape gate
- Basic monster patrol, investigate, chase, and search states
- Stamina, crouch, pause, and restart/game-over screens

## Notes
This is a prototype foundation, not a finished photorealistic game. Models and textures are procedural placeholder geometry; replacing them with optimized models, animations, and sound assets will improve visual quality. Test on your target Android device and tune renderer quality for performance.
