import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const $ = id => document.getElementById(id);
const gameEl = $('game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x080d13);
scene.fog = new THREE.FogExp2(0x0b1117, 0.023);

const camera = new THREE.PerspectiveCamera(75, innerWidth/innerHeight, 0.1, 220);
camera.rotation.order = 'YXZ';
const renderer = new THREE.WebGLRenderer({antialias:false, powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
gameEl.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0x9eb4c8,0x17120f,1.15); scene.add(hemi);
const moon = new THREE.DirectionalLight(0x9cb7dc,1.65); moon.position.set(-18,32,12); moon.castShadow=true; moon.shadow.mapSize.set(1024,1024); scene.add(moon);
const ambient = new THREE.AmbientLight(0x4a5969,0.3); scene.add(ambient);

const flashlight = new THREE.SpotLight(0xdde8ff, 32, 25, Math.PI/7, .48, 1.3);
flashlight.castShadow = false;
camera.add(flashlight); flashlight.position.set(0,0.05,0); flashlight.target.position.set(0,0,-1); camera.add(flashlight.target);
scene.add(camera);

const mats = {
 ground: new THREE.MeshStandardMaterial({color:0x202a27,roughness:1}),
 road: new THREE.MeshStandardMaterial({color:0x252624,roughness:1}),
 wall: new THREE.MeshStandardMaterial({color:0x51483d,roughness:1}),
 darkWall: new THREE.MeshStandardMaterial({color:0x302d2a,roughness:1}),
 roof: new THREE.MeshStandardMaterial({color:0x211f20,roughness:1}),
 wood: new THREE.MeshStandardMaterial({color:0x3d2b20,roughness:1}),
 window: new THREE.MeshStandardMaterial({color:0x070b0f,roughness:1}),
 leaf: new THREE.MeshStandardMaterial({color:0x17251d,roughness:1}),
 trunk: new THREE.MeshStandardMaterial({color:0x2c211b,roughness:1}),
 stone: new THREE.MeshStandardMaterial({color:0x464744,roughness:1}),
 metal: new THREE.MeshStandardMaterial({color:0x393e40,metalness:.55,roughness:.65}),
 red: new THREE.MeshStandardMaterial({color:0x541a1c,roughness:.8}),
 monster: new THREE.MeshStandardMaterial({color:0x090b0d,roughness:1}),
 eyes: new THREE.MeshStandardMaterial({color:0xd91c19,emissive:0x8e0808,emissiveIntensity:2}),
 key: new THREE.MeshStandardMaterial({color:0xd9a947,metalness:.65,roughness:.28})
};
const colliders=[];
const interactables=[];
const hideSpots=[];
const worldThings=[];
function box(name,x,y,z,w,h,d,mat,solid=true){
 const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat); mesh.name=name; mesh.position.set(x,y,z); mesh.castShadow=true; mesh.receiveShadow=true; scene.add(mesh);
 if(solid) colliders.push({x:x-w/2,z:z-d/2,w,d,top:y+h/2,mesh});
 return mesh;
}
function addHouse(x,z,w=7,d=6,variant=0){
 const wallmat=variant%2?mats.darkWall:mats.wall;
 box('house',x,1.5,z,w,3,d,wallmat,true);
 // front door faces -Z
 box('door',x,1.0,z-d/2-.035,1.1,2,.12,mats.wood,true);
 box('roof',x,3.45,z,w+0.5,.35,d+0.5,mats.roof,true);
 box('window',x-w*.29,1.8,z-d/2-.105,.8,.8,.08,mats.window,false);
 box('window',x+w*.29,1.8,z-d/2-.105,.8,.8,.08,mats.window,false);
 // porch posts
 for(const dx of [-1.3,1.3]) box('post',x+dx,.9,z-d/2-.45,.12,1.8,.12,mats.wood,true);
 worldThings.push({type:'house',x,z});
 return {x,z,w,d};
}
function tree(x,z,s=1){
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.16*s,.28*s,2.2*s,6),mats.trunk);trunk.position.set(x,1.1*s,z);trunk.castShadow=true;scene.add(trunk);
 for(let i=0;i<3;i++){const crown=new THREE.Mesh(new THREE.ConeGeometry((1.15-i*.18)*s,2.2*s,7),mats.leaf);crown.position.set(x,(2.1+i*.7)*s,z);crown.castShadow=true;scene.add(crown);}
 colliders.push({x:x-.35*s,z:z-.35*s,w:.7*s,d:.7*s,top:3*s});
}
function lamp(x,z){
 const pole=box('lamp pole',x,2,z,.12,4,.12,mats.metal,true);
 const bulb=new THREE.PointLight(0xc68e60,1.7,9,2);bulb.position.set(x,3.8,z);scene.add(bulb);
 const orb=new THREE.Mesh(new THREE.SphereGeometry(.12,8,8),new THREE.MeshBasicMaterial({color:0xffc987}));orb.position.copy(bulb.position);scene.add(orb);
}
function makeGround(){
 box('ground',0,-.35,0,100,.6,100,mats.ground,false);
 // winding-ish road sections
 box('road',0,-.02,18,10,.08,64,mats.road,false);
 box('road',-12,-.01,3,28,.08,7,mats.road,false);
 box('road',10,-.01,-8,7,.08,24,mats.road,false);
 // fence and rocks
 for(let x=-28;x<=28;x+=2.2){box('fence post',x,.55,-27,.16,1.1,.16,mats.wood,true);}
 box('fence rail',0,.75,-27,58,.14,.14,mats.wood,true);
}
function buildWorld(){
 makeGround();
 // village houses in rough clusters
 addHouse(-9,13,7,6,0); addHouse(9,11,7,6,1); addHouse(-17,2,6,6,1);
 addHouse(17,1,7,6,0); addHouse(-10,-10,7,6,1); addHouse(10,-12,8,7,0);
 // school-like larger structure
 box('school',-1,1.7,-15,12,3.4,7,mats.darkWall,true);
 box('school roof',-1,3.65,-15,12.5,.35,7.5,mats.roof,true);
 box('school door',-1,1,-18.56,1.2,2,.12,mats.wood,true);
 for(let x=-5;x<=3;x+=2.6) box('school window',x,2,-18.62,1,.9,.1,mats.window,false);
 // shrine at far end
 box('shrine',0,1.7,-34,8,3.4,6,mats.stone,true);
 box('shrine roof',0,3.6,-34,9,.4,7,mats.roof,true);
 box('shrine door',0,1,-37.1,1.3,2,.12,mats.wood,true);
 // scattered crates and hay stacks
 for(const p of [[-5,7],[5,5],[-14,-5],[14,-5],[3,20],[-4,-23]]){
  box('crate',p[0],.55,p[1],1.1,1.1,1.1,mats.wood,true);
 }
 // trees around village perimeter
 for(let i=0;i<75;i++){
  const a=Math.random()*Math.PI*2, r=25+Math.random()*23;
  tree(Math.cos(a)*r,Math.sin(a)*r,.65+Math.random()*.8);
 }
 for(const p of [[-3,12],[3,18],[-13,-1],[14,5],[4,-22],[-18,-13]]) lamp(...p);
 // central well
 const well=new THREE.Mesh(new THREE.CylinderGeometry(1.25,1.4,.8,10),mats.stone);well.position.set(0,.4,3);well.castShadow=true;scene.add(well);
 const hole=new THREE.Mesh(new THREE.CylinderGeometry(.8,.8,.05,12),new THREE.MeshStandardMaterial({color:0x020405}));hole.position.set(0,.82,3);scene.add(hole);
}
buildWorld();

// Key and locked exit gate
const keyGroup=new THREE.Group();
const keyRing=new THREE.Mesh(new THREE.TorusGeometry(.18,.055,8,14),mats.key);keyRing.rotation.x=Math.PI/2;keyGroup.add(keyRing);
const keyStem=new THREE.Mesh(new THREE.BoxGeometry(.08,.06,.58),mats.key);keyStem.position.z=.32;keyGroup.add(keyStem);
const tooth=new THREE.Mesh(new THREE.BoxGeometry(.2,.06,.1),mats.key);tooth.position.set(.06,0,.5);keyGroup.add(tooth);
keyGroup.position.set(-9,.8,12.0);scene.add(keyGroup);
interactables.push({kind:'key',mesh:keyGroup,label:'Pick up the old key',range:2.3});

const gate= new THREE.Group();
for(let i=0;i<9;i++){const bar=new THREE.Mesh(new THREE.BoxGeometry(.13,3.1,.14),mats.metal);bar.position.set((i-4)*.75,1.55,0);gate.add(bar);}
for(const y of [.6,2.5]){const rail=new THREE.Mesh(new THREE.BoxGeometry(6.4,.16,.16),mats.metal);rail.position.y=y;gate.add(rail);}
gate.position.set(0,0,25);scene.add(gate);
colliders.push({x:-3.2,z:24.9,w:6.4,d:.25,top:3.1,gate:true});
interactables.push({kind:'gate',mesh:gate,label:'Unlock the escape gate',range:3});

// Puzzle note by the school
const note=box('note',-2,1.1,-18.1,.35,.45,.08,mats.red,false);
interactables.push({kind:'note',mesh:note,label:'Read the school note',range:2.2});

// Player
const player={pos:new THREE.Vector3(0,0,21),yaw:Math.PI,pitch:0,stamina:100,crouch:false,sprinting:false,flash:true,hasKey:false,readNote:false,escaped:false,alive:true};
camera.position.set(player.pos.x,1.65,player.pos.z);
let started=false,paused=false,ended=false,monsterState='patrol',stateTimer=0,lastKnown=new THREE.Vector3(0,0,21),monsterAlert=0,footstepClock=0,toastTimer=0,messageTimer=0,elapsed=0;
const monster=new THREE.Group();
const body=new THREE.Mesh(new THREE.CapsuleGeometry(.43,1.1,4,7),mats.monster);body.position.y=1.25;body.scale.set(.78,1,0.72);body.castShadow=true;monster.add(body);
const head=new THREE.Mesh(new THREE.SphereGeometry(.34,9,8),mats.monster);head.position.set(0,2.15,0);head.scale.set(.75,1.15,.7);head.castShadow=true;monster.add(head);
for(const x of [-.13,.13]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.045,8,6),mats.eyes);eye.position.set(x,2.19,-.23);monster.add(eye);}
for(const x of [-.26,.26]){const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.12,.9,3,5),mats.monster);arm.position.set(x,.95,-.02);arm.rotation.z=x<0?-.16:.16;monster.add(arm);}
monster.position.set(-17,0,-4);scene.add(monster);
const monsterLight=new THREE.PointLight(0x9d1111,.45,3);monsterLight.position.set(0,2,0);monster.add(monsterLight);

const keys={};
addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='Escape'&&started&&!ended)togglePause();if(e.code==='KeyF')toggleFlash();if(e.code==='KeyC')player.crouch=!player.crouch;if(e.code==='KeyE')interact();});
addEventListener('keyup',e=>keys[e.code]=false);
let pointerLocked=false;
renderer.domElement.addEventListener('click',()=>{if(started&&!paused&&!ended&&matchMedia('(pointer:fine)').matches)renderer.domElement.requestPointerLock?.();});
document.addEventListener('pointerlockchange',()=>pointerLocked=document.pointerLockElement===renderer.domElement);
document.addEventListener('mousemove',e=>{if(pointerLocked&&started&&!paused){player.yaw-=e.movementX*.0022;player.pitch-=e.movementY*.0022;player.pitch=THREE.MathUtils.clamp(player.pitch,-1.25,1.25);}});
let touchLook=false,lastTouchX=0,lastTouchY=0;
const lookZone=$('lookZone');
lookZone.addEventListener('pointerdown',e=>{touchLook=true;lastTouchX=e.clientX;lastTouchY=e.clientY;lookZone.setPointerCapture(e.pointerId);});
lookZone.addEventListener('pointermove',e=>{if(!touchLook||paused||!started)return;const dx=e.clientX-lastTouchX,dy=e.clientY-lastTouchY;lastTouchX=e.clientX;lastTouchY=e.clientY;player.yaw-=dx*.006;player.pitch=THREE.MathUtils.clamp(player.pitch-dy*.004,-1.2,1.2);});
lookZone.addEventListener('pointerup',()=>touchLook=false);lookZone.addEventListener('pointercancel',()=>touchLook=false);

// Virtual joystick
const joystick=$('joystick'),stick=$('stick');let joy={x:0,y:0,active:false,cx:0,cy:0};
joystick.addEventListener('pointerdown',e=>{joy.active=true;joystick.setPointerCapture(e.pointerId);const r=joystick.getBoundingClientRect();joy.cx=r.left+r.width/2;joy.cy=r.top+r.height/2;updateJoy(e);});
joystick.addEventListener('pointermove',e=>{if(joy.active)updateJoy(e);});
function updateJoy(e){const dx=e.clientX-joy.cx,dy=e.clientY-joy.cy,len=Math.hypot(dx,dy),max=37,s=len>max?max/len:1;joy.x=dx*s/max;joy.y=dy*s/max;stick.style.transform=`translate(${dx*s}px,${dy*s}px)`;}
function endJoy(){joy.active=false;joy.x=0;joy.y=0;stick.style.transform='translate(0,0)';}
joystick.addEventListener('pointerup',endJoy);joystick.addEventListener('pointercancel',endJoy);

$('flashBtn').addEventListener('click',toggleFlash);
$('crouchBtn').addEventListener('click',()=>{player.crouch=!player.crouch;showToast(player.crouch?'You crouch and move more quietly.':'You stand up.');});
$('useBtn').addEventListener('click',interact);
$('pauseBtn').addEventListener('click',togglePause);
$('startBtn').addEventListener('click',startGame);
$('resumeBtn').addEventListener('click',togglePause);
$('restartBtn').addEventListener('click',()=>location.reload());
$('againBtn').addEventListener('click',()=>location.reload());

function startGame(){started=true;$('startScreen').classList.add('hidden');$('hud').classList.remove('hidden');if(matchMedia('(pointer:fine)').matches)renderer.domElement.requestPointerLock?.();showMessage('Find the old key. Do not trust the silence.',3800);}
function togglePause(){if(!started||ended)return;paused=!paused;$('pauseScreen').classList.toggle('hidden',!paused);if(paused&&document.pointerLockElement)document.exitPointerLock();else if(!paused&&matchMedia('(pointer:fine)').matches)renderer.domElement.requestPointerLock?.();}
function toggleFlash(){player.flash=!player.flash;flashlight.visible=player.flash;showToast(player.flash?'Flashlight on':'Flashlight off');}
function showToast(t){const el=$('toast');el.textContent=t;el.classList.add('show');toastTimer=2.4;}
function showMessage(t,d=2200){const el=$('message');el.textContent=t;el.classList.add('show');messageTimer=d/1000;}
function setObjective(t){$('objective').textContent=t;$('missionText').textContent=t;}
function interact(){
 if(!started||paused||ended)return;
 let best=null,bd=Infinity;
 for(const it of interactables){if(it.used)continue;const p=it.mesh.getWorldPosition(new THREE.Vector3());const d=p.distanceTo(camera.position);if(d<it.range&&d<bd){best=it;bd=d;}}
 if(!best){showToast('Nothing close enough to use.');return;}
 if(best.kind==='key'){player.hasKey=true;best.used=true;scene.remove(best.mesh);setObjective('Unlock the escape gate');showMessage('The old key feels strangely warm.',2500);showToast('KEY COLLECTED');}
 else if(best.kind==='gate'){
  if(player.hasKey){player.escaped=true;endGame(true);}
  else showToast('The gate is locked. Find the old key near the western house.');
 }else if(best.kind==='note'){player.readNote=true;best.used=true;showMessage('NOTE: “The bell calls it. The light reveals its shape. The old gate is the only way out.”',5200);setObjective('Find the old key, then escape');}
}
function endGame(won){
 ended=true;document.exitPointerLock?.();$('endScreen').classList.remove('hidden');$('endTitle').textContent=won?'YOU ESCAPED':'YOU WERE FOUND';$('endText').textContent=won?'You slip beyond the gate as the village bell rings once behind you. For now, you are free.':'The Watcher found you in the fog. The village keeps another secret.';$('hud').classList.add('hidden');
}
function distXZ(a,b){return Math.hypot(a.x-b.x,a.z-b.z);}
function blocked(x,z,r=.35){
 for(const c of colliders){if(c.gate&&player.hasKey)continue;if(x+r>c.x&&x-r<c.x+c.w&&z+r>c.z&&z-r<c.z+c.d)return true;}
 return false;
}
function canSeePlayer(){
 const toPlayer=new THREE.Vector3(player.pos.x,1.2,player.pos.z).sub(monster.position);
 const distance=toPlayer.length();if(distance>17)return false;
 const forward=new THREE.Vector3(0,0,-1).applyQuaternion(monster.quaternion);
 if(forward.angleTo(toPlayer.clone().normalize())>1.25&&distance>4)return false;
 // simple raycast visibility check against house/wall meshes
 const ray=new THREE.Raycaster(monster.position.clone().add(new THREE.Vector3(0,1.8,0)),toPlayer.clone().normalize(),0,distance);
 const walls=scene.children.filter(o=>o.isMesh&&['house','school','shrine','roof','door','school roof','shrine roof'].includes(o.name));
 return ray.intersectObjects(walls,false).length===0;
}
function updateMonster(dt){
 if(ended)return;
 const mpos=monster.position;const d=distXZ(mpos,player.pos);const visible=canSeePlayer();
 const moving=Math.abs(joy.x)+Math.abs(joy.y)>.18||keys.KeyW||keys.KeyA||keys.KeyS||keys.KeyD;
 if(moving&&!player.crouch){monsterAlert=Math.min(1,monsterAlert+dt*.45);}else monsterAlert=Math.max(0,monsterAlert-dt*.22);
 if(visible&&d<13){monsterState='chase';lastKnown.copy(player.pos);stateTimer=4;}
 else if(monsterState==='chase'&&stateTimer<=0){monsterState='search';stateTimer=5;}
 if(monsterState==='patrol'&&monsterAlert>.65&&d<20){monsterState='investigate';lastKnown.copy(player.pos);stateTimer=5;}
 stateTimer-=dt;
 let target=null,speed=.9;
 if(monsterState==='patrol'){
  const patrol=[new THREE.Vector3(-17,0,-4),new THREE.Vector3(-8,0,8),new THREE.Vector3(10,0,8),new THREE.Vector3(13,0,-10),new THREE.Vector3(0,0,-28)];
  if(!monster.userData.idx)monster.userData.idx=0;
  target=patrol[monster.userData.idx%patrol.length];
  if(distXZ(mpos,target)<1.5)monster.userData.idx=(monster.userData.idx+1)%patrol.length;
 }else if(monsterState==='investigate'){target=lastKnown;speed=1.25;if(distXZ(mpos,target)<1.5){monsterState='search';stateTimer=3;}}
 else if(monsterState==='search'){target=lastKnown;speed=.65;if(stateTimer<=0){monsterState='patrol';monsterAlert=0;}}
 else if(monsterState==='chase'){target=player.pos;speed=2.15;if(!visible){lastKnown.copy(player.pos);stateTimer=Math.max(stateTimer,2.2);}}
 if(target){
  const dx=target.x-mpos.x,dz=target.z-mpos.z,len=Math.hypot(dx,dz);
  if(len>.2){const step=Math.min(len,speed*dt);const nx=mpos.x+dx/len*step,nz=mpos.z+dz/len*step;if(!blocked(nx,nz,.42)){mpos.x=nx;mpos.z=nz;}else{mpos.x+=Math.sin(elapsed*2)*dt*.35;mpos.z+=Math.cos(elapsed*2)*dt*.35;}
   monster.rotation.y=Math.atan2(-dx,-dz);
  }
 }
 monster.position.y=Math.sin(elapsed*5)*.035;
 const chasing=monsterState==='chase'||monsterState==='investigate';
 $('danger').classList.toggle('hidden',!chasing||d>14);
 if(d<1.35&&monsterState==='chase')endGame(false);
}
function updateInteractHint(){
 let best=null,bd=Infinity;
 for(const it of interactables){if(it.used)continue;const p=it.mesh.getWorldPosition(new THREE.Vector3());const d=p.distanceTo(camera.position);if(d<it.range+1&&d<bd){best=it;bd=d;}}
 $('interactHint').textContent=best?(bd<best.range?'[ E / USE ] '+best.label:best.label):'';
}
function updatePlayer(dt){
 const forward=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)-joy.y;
 const strafe=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+joy.x;
 player.sprinting=(keys.ShiftLeft||keys.ShiftRight)&&player.stamina>1&&forward>0&&!player.crouch;
 const speed=player.crouch?1.55:(player.sprinting?5.4:3.1);
 let dx=(Math.sin(player.yaw)*forward+Math.cos(player.yaw)*strafe);
 let dz=(Math.cos(player.yaw)*forward-Math.sin(player.yaw)*strafe);
 const len=Math.hypot(dx,dz);if(len>1){dx/=len;dz/=len;}
 const nx=player.pos.x+dx*speed*dt,nz=player.pos.z+dz*speed*dt;
 if(!blocked(nx,player.pos.z,.35))player.pos.x=nx;
 if(!blocked(player.pos.x,nz,.35))player.pos.z=nz;
 if(player.sprinting)player.stamina=Math.max(0,player.stamina-26*dt);else player.stamina=Math.min(100,player.stamina+17*dt);
 if(len>.05&&!player.crouch){footstepClock-=dt;if(footstepClock<=0){monsterAlert=Math.min(1,monsterAlert+.12);footstepClock=player.sprinting?.24:.46;}}
 camera.position.set(player.pos.x,player.crouch?1.05:1.65,player.pos.z);
 camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
 flashlight.visible=player.flash;
 flashlight.intensity=player.flash?(player.stamina<12?18:32):0;
 // key glows gently when close
 if(!player.hasKey){keyGroup.rotation.y+=dt*.7;keyGroup.position.y=.8+Math.sin(elapsed*2)*.08;}
 $('battery').textContent='🔦 '+(player.flash?'ON':'OFF');
 $('staminaBar').style.width=player.stamina+'%';
}
function updateGate(){
 // Animate gate visually after key pickup, allowing the escape passage
 const c=colliders.find(c=>c.gate);
 if(player.hasKey&&c){c.x=9999;gate.rotation.y=Math.sin(elapsed*1.5)*.05;}
}
function animate(){
 requestAnimationFrame(animate);
 const dt=Math.min(clock.getDelta(),.05);
 if(started&&!paused&&!ended){elapsed+=dt;updatePlayer(dt);updateMonster(dt);updateGate();updateInteractHint();
  if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$('toast').classList.remove('show');}
  if(messageTimer>0){messageTimer-=dt;if(messageTimer<=0)$('message').classList.remove('show');}
  // Subtle breathing-like camera movement while moving
  if(Math.abs(joy.x)+Math.abs(joy.y)>.2||keys.KeyW||keys.KeyS){camera.position.y+=(Math.sin(elapsed*10)*.018);}
 }
 renderer.render(scene,camera);
}
const clock=new THREE.Clock();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));});
animate();

// Make the escape gate passable visually once the key is acquired.
