/* =========================================
   MAMPOU INDUSTRIE
   10 POINTS = 1 FCFA
   VERSION SANS ALERT()
========================================= */

const POINTS_PAR_FCFA = 10;
const SERVEUR_MAMPOU = "http://127.0.0.1:3000";

let targetTimeout = null;
let reflexTimer = null;
let reflexStart = null;
let reflexWaiting = false;
let coinsInterval = null;
let coinsTimeLeft = 10;
let coinsScore = 0;


/* =========================================
   OUTILS
========================================= */

function getPoints() {
  return Number(localStorage.getItem("mampou_points")) || 0;
}

function setPoints(points) {
  points = Math.max(0, Math.floor(Number(points) || 0));
  localStorage.setItem("mampou_points", points);
  updateBalances();
}

function addPoints(points) {
  setPoints(getPoints() + Number(points));
}

function pointsToFcfa(points) {
  return Math.floor(Number(points) / POINTS_PAR_FCFA);
}


/* =========================================
   MESSAGES SANS ALERT
========================================= */

function showAppMessage(message, type = "success") {
  let box = document.getElementById("appMessage");

  if (!box) {
    box = document.createElement("div");
    box.id = "appMessage";

    box.style.position = "fixed";
    box.style.left = "15px";
    box.style.right = "15px";
    box.style.top = "85px";
    box.style.zIndex = "9999";
    box.style.padding = "15px";
    box.style.borderRadius = "12px";
    box.style.fontWeight = "bold";
    box.style.textAlign = "center";
    box.style.boxShadow = "0 4px 15px rgba(0,0,0,0.15)";

    document.body.appendChild(box);
  }

  box.textContent = message;

  if (type === "error") {
    box.style.background = "#ffe8e8";
    box.style.color = "#b00020";
  } else {
    box.style.background = "#e8f8ef";
    box.style.color = "#087f4f";
  }

  box.style.display = "block";

  setTimeout(() => {
    box.style.display = "none";
  }, 3500);
}


/* =========================================
   MISE À JOUR DES SOLDES
========================================= */

function updateBalances() {
  const points = getPoints();
  const fcfa = pointsToFcfa(points);

  const homeBalance = document.getElementById("homeBalance");
  const homePoints = document.getElementById("homePoints");

  const pointsDisplay = document.getElementById("pointsDisplay");
  const rewardFcfa = document.getElementById("rewardFcfa");

  const withdrawBalance = document.getElementById("withdrawBalance");
  const withdrawPoints = document.getElementById("withdrawPoints");

  if (homeBalance) {
    homeBalance.textContent = fcfa + " FCFA";
  }

  if (homePoints) {
    homePoints.textContent = points + " points";
  }

  if (pointsDisplay) {
    pointsDisplay.textContent = points;
  }

  if (rewardFcfa) {
    rewardFcfa.textContent = fcfa + " FCFA";
  }

  if (withdrawBalance) {
    withdrawBalance.textContent = fcfa + " FCFA";
  }

  if (withdrawPoints) {
    withdrawPoints.textContent = points + " points";
  }
}


/* =========================================
   NAVIGATION
========================================= */

function showPage(pageId) {
  const pages = document.querySelectorAll(".page");

  pages.forEach(page => {
    page.classList.remove("active");
  });

  const page = document.getElementById(pageId);

  if (page) {
    page.classList.add("active");
  }

  window.scrollTo(0, 0);

  if (pageId === "profile") {
    loadProfile();
  }

  updateBalances();
}


/* =========================================
   PROFIL
========================================= */

function loadProfile() {
  const firstName = localStorage.getItem("mampou_firstName") || "";
  const lastName = localStorage.getItem("mampou_lastName") || "";
  const phone = localStorage.getItem("mampou_phone") || "";

  const firstNameInput = document.getElementById("firstName");
  const lastNameInput = document.getElementById("lastName");
  const phoneInput = document.getElementById("phone");

  if (firstNameInput) firstNameInput.value = firstName;
  if (lastNameInput) lastNameInput.value = lastName;
  if (phoneInput) phoneInput.value = phone;
}


async function saveProfile() {
  const firstName = document.getElementById("firstName").value.trim();
  const lastName = document.getElementById("lastName").value.trim();
  const phone = document.getElementById("phone").value.trim();

  const message = document.getElementById("profileMessage");

  if (!firstName || !lastName || !phone) {
    if (message) {
      message.textContent = "❌ Remplis tous les champs du profil.";
      message.style.color = "#b00020";
    }
    return;
  }

  localStorage.setItem("mampou_firstName", firstName);
  localStorage.setItem("mampou_lastName", lastName);
  localStorage.setItem("mampou_phone", phone);

  if (message) {
    message.textContent = "⏳ Enregistrement du profil...";
    message.style.color = "#087f4f";
  }

  try {
    const response = await fetch(SERVEUR_MAMPOU + "/api/profile", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        firstName: firstName,
        lastName: lastName,
        phone: phone
      })
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || "Erreur serveur");
    }

    if (message) {
      message.textContent = "✅ Profil enregistré avec succès.";
      message.style.color = "#087f4f";
    }

  } catch (error) {

    console.error("Erreur profil :", error);

    if (message) {
      message.textContent =
        "⚠️ Profil enregistré sur le téléphone. Serveur indisponible.";
      message.style.color = "#735c00";
    }
  }
}


/* =========================================
   COULEUR DE FOND
========================================= */

function changeBackground(color) {
  document.body.style.background = color;
  localStorage.setItem("mampou_background", color);
}


function resetBackground() {
  const defaultColor = "#f4f7f6";

  document.body.style.background = defaultColor;
  localStorage.setItem("mampou_background", defaultColor);
}


function loadBackground() {
  const savedColor =
    localStorage.getItem("mampou_background") || "#f4f7f6";

  document.body.style.background = savedColor;
}


/* =========================================
   JEUX
========================================= */

function openGame(game) {
  const modal = document.getElementById("gameModal");
  const title = document.getElementById("gameTitle");
  const content = document.getElementById("gameContent");

  if (!modal || !title || !content) return;

  closeGameTimers();

  modal.classList.add("show");

  if (game === "target") {
    title.textContent = "🎯 Cible";
    openTargetGame();
  }

  else if (game === "memory") {
    title.textContent = "🧠 Mémoire";
    openMemoryGame();
  }

  else if (game === "reflex") {
    title.textContent = "⚡ Réflexe";
    openReflexGame();
  }

  else if (game === "number") {
    title.textContent = "🔢 Nombre mystère";
    openNumberGame();
  }

  else if (game === "coins") {
    title.textContent = "🪙 Attrape-les";
    openCoinsGame();
  }
}


function closeGame() {
  closeGameTimers();

  const modal = document.getElementById("gameModal");

  if (modal) {
    modal.classList.remove("show");
  }
}


function closeGameTimers() {
  if (targetTimeout) {
    clearTimeout(targetTimeout);
    targetTimeout = null;
  }

  if (reflexTimer) {
    clearTimeout(reflexTimer);
    reflexTimer = null;
  }

  if (coinsInterval) {
    clearInterval(coinsInterval);
    coinsInterval = null;
  }

  reflexWaiting = false;
}


/* =========================================
   JEU CIBLE
========================================= */

function openTargetGame() {
  const content = document.getElementById("gameContent");

  content.innerHTML = `
    <p>Clique sur la cible pour gagner <b>10 points</b>.</p>

    <div id="targetArea" class="target-area"></div>

    <p id="targetMessage" class="game-message">
      🎯 Clique sur la cible !
    </p>
  `;

  createTarget();
}


function createTarget() {
  const area = document.getElementById("targetArea");

  if (!area) return;

  area.innerHTML = "";

  const target = document.createElement("button");

  target.className = "target";
  target.type = "button";
  target.textContent = "🎯";

  const maxX = Math.max(0, area.clientWidth - 55);
  const maxY = Math.max(0, area.clientHeight - 55);

  target.style.left = Math.floor(Math.random() * (maxX + 1)) + "px";
  target.style.top = Math.floor(Math.random() * (maxY + 1)) + "px";

  target.onclick = function () {
    addPoints(10);

    const message = document.getElementById("targetMessage");

    if (message) {
      message.textContent = "✅ +10 points !";
    }

    createTarget();
  };

  area.appendChild(target);
}


/* =========================================
   JEU MÉMOIRE
========================================= */

function openMemoryGame() {
  const content = document.getElementById("gameContent");

  const number =
    Math.floor(100 + Math.random() * 900).toString();

  content.innerHTML = `
    <p>Mémorise ce nombre :</p>

    <div id="memoryNumber" class="memory-box">
      ${number}
    </div>

    <div id="memoryAnswerArea"></div>

    <p id="memoryMessage" class="game-message"></p>
  `;

  setTimeout(() => {
    const numberBox = document.getElementById("memoryNumber");

    if (numberBox) {
      numberBox.textContent = "❓";
    }

    const answerArea =
      document.getElementById("memoryAnswerArea");

    if (answerArea) {
      answerArea.innerHTML = `
        <input
          id="memoryInput"
          class="number-input"
          type="number"
          placeholder="Entre le nombre"
        >

        <button
          class="game-button"
          onclick="checkMemory('${number}')"
        >
          Vérifier
        </button>
      `;
    }
  }, 2000);
}


function checkMemory(correctNumber) {
  const input = document.getElementById("memoryInput");
  const message = document.getElementById("memoryMessage");

  if (!input) return;

  const answer = input.value.trim();

  if (!answer) {
    if (message) {
      message.textContent = "⚠️ Entre un nombre.";
    }
    return;
  }

  if (answer === correctNumber) {
    addPoints(20);

    if (message) {
      message.textContent = "🎉 Bravo ! +20 points";
    }
  } else {
    if (message) {
      message.textContent =
        "❌ Mauvaise réponse. Le nombre était " + correctNumber;
    }
  }
}


/* =========================================
   JEU RÉFLEXE
========================================= */

function openReflexGame() {
  const content = document.getElementById("gameContent");

  content.innerHTML = `
    <p>Attends que l'écran devienne vert.</p>

    <div
      id="reflexArea"
      class="reflex-area"
      onclick="reactReflex()"
    >
      ⏳ Attends...
    </div>

    <p id="reflexMessage" class="game-message"></p>
  `;

  const delay = 1500 + Math.random() * 3500;

  reflexWaiting = false;

  reflexTimer = setTimeout(() => {

    const area = document.getElementById("reflexArea");

    if (!area) return;

    area.style.background = "#087f4f";
    area.style.color = "white";
    area.textContent = "⚡ CLIQUE !";

    reflexStart = Date.now();
    reflexWaiting = true;

  }, delay);
}


function reactReflex() {
  const area = document.getElementById("reflexArea");
  const message = document.getElementById("reflexMessage");

  if (!area) return;

  if (!reflexWaiting) {
    if (message) {
      message.textContent =
        "⏳ Trop tôt ! Attends le signal vert.";
    }
    return;
  }

  const reactionTime = Date.now() - reflexStart;

  reflexWaiting = false;

  let points = 10;

  if (reactionTime < 500) {
    points = 30;
  }

  else if (reactionTime < 1000) {
    points = 20;
  }

  addPoints(points);

  area.style.background = "#eef5f2";
  area.style.color = "#222";
  area.textContent = reactionTime + " ms";

  if (message) {
    message.textContent =
      "⚡ " + reactionTime + " ms — +" + points + " points !";
  }
}


/* =========================================
   JEU NOMBRE MYSTÈRE
========================================= */

function openNumberGame() {
  const content = document.getElementById("gameContent");

  const secret =
    Math.floor(Math.random() * 10) + 1;

  content.innerHTML = `
    <p>Je pense à un nombre entre <b>1 et 10</b>.</p>

    <input
      id="numberInput"
      class="number-input"
      type="number"
      min="1"
      max="10"
      placeholder="Ton nombre"
    >

    <button
      class="game-button"
      onclick="checkMysteryNumber(${secret})"
    >
      Deviner
    </button>

    <p id="numberMessage" class="game-message"></p>
  `;
}


function checkMysteryNumber(secret) {
  const input = document.getElementById("numberInput");
  const message = document.getElementById("numberMessage");

  if (!input) return;

  const guess = Number(input.value);

  if (!guess || guess < 1 || guess > 10) {
    if (message) {
      message.textContent =
        "⚠️ Choisis un nombre entre 1 et 10.";
    }
    return;
  }

  if (guess === secret) {
    addPoints(25);

    if (message) {
      message.textContent =
        "🎉 Bravo ! Tu as trouvé. +25 points !";
    }

    input.disabled = true;
  } else {
    if (guess < secret) {
      message.textContent = "⬆️ Le nombre est plus grand.";
    } else {
      message.textContent = "⬇️ Le nombre est plus petit.";
    }
  }
}


/* =========================================
   JEU ATTRAPE-LES
========================================= */

function openCoinsGame() {
  const content = document.getElementById("gameContent");

  coinsTimeLeft = 10;
  coinsScore = 0;

  content.innerHTML = `
    <p>
      Attrape les pièces pendant
      <b>10 secondes</b>.
    </p>

    <p>
      Temps :
      <b id="coinsTime">10</b>s
      — Points :
      <b id="coinsScore">0</b>
    </p>

    <div id="coinsArea" class="coins-area"></div>

    <p id="coinsMessage" class="game-message">
      🪙 Attrape les pièces !
    </p>
  `;

  createCoin();

  coinsInterval = setInterval(() => {

    coinsTimeLeft--;

    const timeElement =
      document.getElementById("coinsTime");

    if (timeElement) {
      timeElement.textContent = coinsTimeLeft;
    }

    createCoin();

    if (coinsTimeLeft <= 0) {
      finishCoinsGame();
    }

  }, 1000);
}


function createCoin() {
  const area = document.getElementById("coinsArea");

  if (!area || coinsTimeLeft <= 0) return;

  const coin = document.createElement("button");

  coin.className = "coin";
  coin.type = "button";
  coin.textContent = "🪙";

  const maxX = Math.max(0, area.clientWidth - 40);
  const maxY = Math.max(0, area.clientHeight - 40);

  coin.style.left =
    Math.floor(Math.random() * (maxX + 1)) + "px";

  coin.style.top =
    Math.floor(Math.random() * (maxY + 1)) + "px";

  coin.onclick = function () {
    coinsScore += 5;

    const scoreElement =
      document.getElementById("coinsScore");

    if (scoreElement) {
      scoreElement.textContent = coinsScore;
    }

    coin.remove();
  };

  area.appendChild(coin);

  setTimeout(() => {
    if (coin.parentNode) {
      coin.remove();
    }
  }, 900);
}


function finishCoinsGame() {
  if (coinsInterval) {
    clearInterval(coinsInterval);
    coinsInterval = null;
  }

  addPoints(coinsScore);

  const message =
    document.getElementById("coinsMessage");

  if (message) {
    message.textContent =
      "⏱️ Terminé ! +" + coinsScore + " points !";
  }

  const area =
    document.getElementById("coinsArea");

  if (area) {
    area.innerHTML = "";
  }
}


/* =========================================
   RETRAIT
========================================= */

async function requestWithdrawal() {

  const country =
    document.getElementById("country").value;

  const paymentMethod =
    document.getElementById("paymentMethod").value;

  const beneficiary =
    document.getElementById("beneficiary").value.trim();

  const accountNumber =
    document.getElementById("accountNumber").value.trim();

  const amount =
    Number(document.getElementById("amount").value);

  const availablePoints = getPoints();
  const availableFcfa = pointsToFcfa(availablePoints);

  /* Vérification locale */

  if (
    !country ||
    !paymentMethod ||
    !beneficiary ||
    !accountNumber ||
    !amount
  ) {
    showAppMessage(
      "❌ Informations de retrait incomplètes.",
      "error"
    );
    return;
  }

  if (amount <= 0) {
    showAppMessage(
      "❌ Le montant demandé est invalide.",
      "error"
    );
    return;
  }

  if (amount > availableFcfa) {
    showAppMessage(
      "❌ Montant supérieur à ton solde disponible.",
      "error"
    );
    return;
  }

  showAppMessage(
    "⏳ Envoi de la demande de retrait..."
  );

  try {

    const response = await fetch(
      SERVEUR_MAMPOU + "/api/withdrawal",
      {
        method: "POST",

        headers: {
          "Content-Type": "application/json"
        },

        body: JSON.stringify({
          country: country,
          paymentMethod: paymentMethod,
          beneficiary: beneficiary,
          accountNumber: accountNumber,
          amount: amount
        })
      }
    );

    const data = await response.json();

    if (!response.ok || !data.success) {

      showAppMessage(
        "❌ " +
        (data.message ||
        "La demande de retrait a été refusée."),
        "error"
      );

      return;
    }

    /* Enregistrement local de la demande */

    localStorage.setItem(
      "mampou_last_withdrawal",
      JSON.stringify(data.withdrawal)
    );

    showAppMessage(
      "✅ Demande de retrait enregistrée. Statut : en attente."
    );

    /*
      Pour l'instant, le serveur reçoit la demande
      et la met en attente.

      Aucun transfert réel d'argent n'est effectué.
    */

    document.getElementById("amount").value = "";

  }

  catch (error) {

    console.error(
      "Erreur serveur MAMPOU :",
      error
    );

    showAppMessage(
      "❌ Serveur MAMPOU inaccessible.",
      "error"
    );
  }
}


/* =========================================
   INITIALISATION
========================================= */

document.addEventListener("DOMContentLoaded", () => {

  loadBackground();

  loadProfile();

  updateBalances();

});