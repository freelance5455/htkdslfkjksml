import http.server
import socketserver
import socket
import webbrowser
import os
import sys

PORT = 8080

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.254.254.254', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

def print_qr(url):
    try:
        import qrcode
        qr = qrcode.QRCode(border=1)
        qr.add_data(url)
        qr.make()
        qr.print_ascii(invert=True)
    except Exception:
        pass

def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    lan_ip = get_ip()
    local_url = f"http://localhost:{PORT}"
    mobile_url = f"http://{lan_ip}:{PORT}"

    Handler = http.server.SimpleHTTPRequestHandler
    
    # Enable address reuse
    socketserver.TCPServer.allow_reuse_address = True
    
    try:
        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            print("=" * 65)
            print("   📦 RETAIL STOCK & CUSTOMER LEDGER APP (READY TO USE) 📦")
            print("=" * 65)
            print()
            print("  💻 PC / Laptop Link:")
            print(f"     {local_url}")
            print()
            print("  📱 Android Phone Link (Connect phone to same Wi-Fi):")
            print(f"     {mobile_url}")
            print()
            print("  📷 SCAN THIS QR CODE ON YOUR ANDROID PHONE CAMERA:")
            print("-" * 65)
            print_qr(mobile_url)
            print("-" * 65)
            print()
            print("  💡 HOW TO INSTALL ON ANDROID PHONE AS AN APP:")
            print("     1. Open the link above in Google Chrome on your phone.")
            print("     2. Tap the 3 dots (⋮) in Chrome's top-right corner.")
            print("     3. Tap 'Install app' or 'Add to Home screen'.")
            print("     4. An app icon 'Stock & Ledger' will be placed on your home screen.")
            print("     5. It works 100% OFFLINE without internet!")
            print()
            print("  Press Ctrl+C anytime in this window to stop the server.")
            print("=" * 65)
            
            # Automatically open browser on PC
            webbrowser.open(local_url)
            
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server... Goodbye!")
    except Exception as e:
        print(f"\nError starting server: {e}")

if __name__ == '__main__':
    main()
