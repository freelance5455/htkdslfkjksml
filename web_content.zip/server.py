from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
import os
os.chdir("/storage/emulated/0/Download/PhysicsAI_V2_Enhanced")
PORT=8000
with TCPServer(("127.0.0.1",PORT),SimpleHTTPRequestHandler) as server:
    print("Physics AI V2 Enhanced: http://127.0.0.1:8000")
    server.serve_forever()
