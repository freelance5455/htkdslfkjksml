# =====================================================================
# JARVIS AI - ASINXRON FASTAPI BACKEND SERVERI
# Muallif / Dasturchi: Мухаммадризо (GitHub: olimovm158-dot, Telegram: @odamcha10)
# Production Server URL: https://jarvis-ai-epk1.onrender.com
# Model: llama-3.3-70b-versatile (Groq API)
# 5 ta API Kaliti: Round-robin va Failover Rotatsiyasi bilan
# =====================================================================

import os
import time
import logging
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import httpx

# Loglashni sozlash
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] Jarvis-Core: %(message)s"
)
logger = logging.getLogger("jarvis_backend")

# ---------------------------------------------------------------------
# KONFIGURATSIYA VA GROQ API KALITLARI (5 TA ROTATSIYA KALITI)
# ---------------------------------------------------------------------
GROQ_API_KEYS: List[str] = [
    "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",
    "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",
    "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",
    "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",
    "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",
]

GROQ_MODEL = "openai/gpt-oss-120b"
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"

# Global rotatsiya indeksi
current_key_index: int = 0

# Tizim prompti - Jarvis shaxsiyati
SYSTEM_PROMPT = """Siz "Jarvis" — eng zamonaviy, odobli va qudratli shaxsiy sun'iy intellekt yordamchisisiz.

QAT'IY QOIDALAR:
1. Foydalanuvchiga doimo "Sir" deb murojaat qiling (masalan: "Buyuring, Sir", "Xizmatingizdaman, Sir", "Bajarildi, Sir").
2. 100% faqat va faqat O'ZBEK TILIDA (lotin yozuvida) javob bering. Aslo boshqa tillarga o'tib ketmang.
3. Javoblaringiz lo'nda, aniq, ma'noli va futuristik ohangda bo'lsin.
4. QAT'IY QOIDA: Har bir javobingizda dasturchi yoki muallif nomini qo'shib yozmang! FAQAT foydalanuvchi sizdan "seni kim yaratgan", "muallifing kim", "dasturching kim" deb so'ragandagina daho dasturchi Мухаммадризо (GitHub: olimovm158-dot) tomonidan yaratilganingizni faxr bilan ayting. Boshqa paytda hech qachon muallif haqida ortiqcha gapirmang!"""

# ---------------------------------------------------------------------
# FASTAPI ILOVASI VA CORS SOZLAMALARI
# ---------------------------------------------------------------------
app = FastAPI(
    title="Jarvis AI Backend",
    description="Мухаммадризо tomonidan yaratilgan Jarvis sun'iy intellekt backend serveri",
    version="2.5.0"
)

# CORS sozlamalari - APK va Web mijozlardan so'rovlarni qabul qilish uchun
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------
# MA'LUMOT MODELLARI (PYDANTIC)
# ---------------------------------------------------------------------
class ChatRequest(BaseModel):
    prompt: str = Field(..., description="Foydalanuvchi bergan savol yoki buyruq")
    history: Optional[List[dict]] = Field(default=None, description="Oldingi suhbat tarixi")

class ChatResponse(BaseModel):
    response: str
    key_index: int
    duration_ms: int
    status: str = "success"

# ---------------------------------------------------------------------
# ASOSIY ENDPOINTLAR
# ---------------------------------------------------------------------
@app.get("/")
async def root():
    """Server holatini tekshirish uchun bosh sahifa"""
    return {
        "status": "online",
        "system": "Jarvis AI Core",
        "creator": "Мухаммадризо (GitHub: olimovm158-dot)",
        "model": GROQ_MODEL,
        "available_keys": len(GROQ_API_KEYS),
        "message": "Tizim to'liq shay holatda, Sir."
    }

@app.get("/health")
async def health_check():
    """Render monitoring uchun sog'liq tekshiruvi"""
    return {"status": "healthy", "timestamp": time.time()}

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Asosiy chat endpointi:
    5 ta API kalit o'rtasida round-robin va failover (rate limit chetlab o'tish)
    rotatsiyasini amalga oshiradi.
    """
    global current_key_index

    user_prompt = request.prompt.strip()
    if not user_prompt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Prompt bo'sh bo'lishi mumkin emas, Sir."
        )

    start_time = time.time()
    total_keys = len(GROQ_API_KEYS)
    attempts = 0
    last_error_detail = ""

    # Suhbat xabarlarini tayyorlash
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    
    # Agar chat tarixi berilgan bo'lsa
    if request.history:
        for msg in request.history[-6:]:
            if "role" in msg and "content" in msg:
                messages.append({"role": msg["role"], "content": msg["content"]})
    
    messages.append({"role": "user", "content": user_prompt})

    # Asinxron HTTP mijoz orqali Groq API ga murojaat qilish
    async with httpx.AsyncClient(timeout=30.0) as client:
        while attempts < total_keys:
            active_index = current_key_index
            api_key = GROQ_API_KEYS[active_index]

            logger.info(f"So'rov yuborilmoqda. Kalit #{active_index + 1} (Urinish {attempts + 1}/{total_keys})")

            payload = {
                "model": GROQ_MODEL,
                "messages": messages,
                "temperature": 0.65,
                "max_tokens": 1024,
                "top_p": 0.9,
            }

            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

            try:
                res = await client.post(GROQ_API_URL, json=payload, headers=headers)

                # Muvaffaqiyatli javob
                if res.status_code == 200:
                    data = res.json()
                    bot_text = data["choices"][0]["message"]["content"]
                    duration_ms = int((time.time() - start_time) * 1000)

                    # Navbatdagi chaqiruv uchun keyingi kalitga o'tkazish (Round-robin)
                    current_key_index = (current_key_index + 1) % total_keys

                    logger.info(f"Muvaffaqiyatli javob olindi (Kalit #{active_index + 1}, {duration_ms}ms)")
                    return ChatResponse(
                        response=bot_text,
                        key_index=active_index + 1,
                        duration_ms=duration_ms,
                        status="success"
                    )

                # Agar 429 (Rate Limit) yoki boshqa status kelsa, navbatdagi kalitga o'tish
                logger.warning(
                    f"Kalit #{active_index + 1} rad etildi. Status: {res.status_code}. "
                    f"Javob: {res.text[:120]}. Keyingi kalitga o'tilmoqda..."
                )
                last_error_detail = f"Status {res.status_code}: {res.text[:100]}"
                current_key_index = (current_key_index + 1) % total_keys
                attempts += 1

            except httpx.RequestError as exc:
                logger.error(f"Kalit #{active_index + 1} ga ulanishda tarmoq xatosi: {exc}")
                last_error_detail = str(exc)
                current_key_index = (current_key_index + 1) % total_keys
                attempts += 1

    # Barcha kalitlar limitga uchragan bo'lsa
    logger.error("Barcha 5 ta Groq kalitlari tugadi yoki xatolik berdi!")
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"Barcha 5 ta Groq API kalitlari limitga yetdi, Sir. So'nggi xatolik: {last_error_detail}"
    )

# ---------------------------------------------------------------------
# SERVERNI ISHGA TUSHIRISH (LOKAL TEST UCHUN)
# ---------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("server:app", host="0.0.0.0", port=port, reload=True)
