#!/usr/bin/env python3
"""سيرفر محلي: يستقبل ملف zip (حتى عدة جيجابايت) ويشغّل zip2apk.sh ثم يعرض الـ APK للتحميل.
التشغيل:  python3 server.py   ثم افتح  http://localhost:8000
"""
import json, os, shutil, subprocess, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

BASE = os.path.dirname(os.path.abspath(__file__))
JOB = os.path.join(BASE, "job")
SCRIPT = os.path.join(BASE, "zip2apk.sh")
PORT = 8000
state = {"status": "idle", "log": [], "files": []}


def run_build(zip_path, mode):
    state.update(status="building", log=[], files=[])
    try:
        p = subprocess.Popen([SCRIPT, zip_path, mode], cwd=JOB,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace")
        for line in p.stdout:
            state["log"].append(line.rstrip())
        p.wait()
        code = p.returncode
    except Exception as e:  # noqa
        state["log"].append(f"خطأ: {e}")
        code = 1
    out = os.path.join(JOB, "output")
    files = sorted(f for f in os.listdir(out) if f.endswith(".apk")) if os.path.isdir(out) else []
    try:
        os.remove(zip_path)
    except OSError:
        pass
    state.update(status="done" if code == 0 and files else "error", files=files)


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8" if "text" in ctype or "json" in ctype else ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            with open(os.path.join(BASE, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html")
        if path == "/status":
            return self._send(200, {**state, "log": state["log"][-300:]})
        if path.startswith("/download/"):
            name = os.path.basename(unquote(path[10:]))
            fp = os.path.join(JOB, "output", name)
            if not os.path.isfile(fp):
                return self._send(404, {"error": "not found"})
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Length", str(os.path.getsize(fp)))
            self.send_header("Content-Disposition", f'attachment; filename="{name}"')
            self.end_headers()
            with open(fp, "rb") as f:
                shutil.copyfileobj(f, self.wfile, 1024 * 1024)
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/build":
            return self._send(404, {"error": "not found"})
        if state["status"] in ("uploading", "building"):
            return self._send(409, {"error": "هناك عملية جارية"})
        mode = parse_qs(u.query).get("mode", ["debug"])[0]
        if mode not in ("debug", "release"):
            return self._send(400, {"error": "mode"})
        size = int(self.headers.get("Content-Length", 0))
        state.update(status="uploading", log=[], files=[])
        shutil.rmtree(JOB, ignore_errors=True)
        os.makedirs(JOB)
        zip_path = os.path.join(JOB, "upload.zip")
        left = size
        with open(zip_path, "wb") as f:  # كتابة تدريجية: لا يُحمَّل الملف كله في الذاكرة
            while left > 0:
                chunk = self.rfile.read(min(1024 * 1024, left))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        if left > 0:
            state.update(status="error")
            state["log"].append("انقطع الرفع قبل اكتماله")
            return self._send(400, {"error": "upload incomplete"})
        threading.Thread(target=run_build, args=(zip_path, mode), daemon=True).start()
        self._send(202, {"ok": True})

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    os.chmod(SCRIPT, 0o755)
    print(f"افتح http://localhost:{PORT}")
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
