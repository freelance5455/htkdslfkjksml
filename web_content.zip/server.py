import os, shutil, stat, subprocess, tempfile, zipfile
from pathlib import Path
from flask import Flask, request, send_file, jsonify

app = Flask(__name__, static_folder=".", static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500 MB

def safe_extract(zf: zipfile.ZipFile, dst: Path):
    dst_abs = dst.resolve()
    for member in zf.infolist():
        target = (dst / member.filename).resolve()
        if not str(target).startswith(str(dst_abs)):
            raise ValueError("Опасный путь внутри ZIP.")
    zf.extractall(dst)

def find_project_root(root: Path) -> Path | None:
    # Prefer gradlew, otherwise settings.gradle(.kts)
    candidates = []
    for p in root.rglob("gradlew"):
        if p.is_file():
            candidates.append(p.parent)
    if candidates:
        return min(candidates, key=lambda p: len(p.parts))
    for name in ("settings.gradle", "settings.gradle.kts"):
        found = list(root.rglob(name))
        if found:
            return min((p.parent for p in found), key=lambda p: len(p.parts))
    return None

def find_apk(project: Path) -> Path | None:
    preferred = list(project.rglob("app-debug.apk"))
    if preferred:
        return preferred[0]
    apks = [p for p in project.rglob("*.apk") if "build/outputs/apk" in str(p).replace("\\","/")]
    return max(apks, key=lambda p: p.stat().st_mtime) if apks else None

@app.get("/")
def index():
    return app.send_static_file("index.html")

@app.post("/api/build")
def build():
    upload = request.files.get("project")
    if not upload or not upload.filename.lower().endswith(".zip"):
        return jsonify(error="Загрузи ZIP-файл."), 400

    work = Path(tempfile.mkdtemp(prefix="apkbuild_"))
    try:
        zip_path = work / "project.zip"
        upload.save(zip_path)

        src = work / "src"
        src.mkdir()
        try:
            with zipfile.ZipFile(zip_path) as zf:
                safe_extract(zf, src)
        except zipfile.BadZipFile:
            return jsonify(error="ZIP повреждён или имеет неверный формат."), 400

        project = find_project_root(src)
        if not project:
            return jsonify(error="Не найден Android Gradle-проект. Нужен gradlew или settings.gradle."), 400

        gradlew = project / "gradlew"
        if gradlew.exists():
            gradlew.chmod(gradlew.stat().st_mode | stat.S_IEXEC)
            cmd = [str(gradlew), "--no-daemon", "assembleDebug"]
        else:
            cmd = ["gradle", "--no-daemon", "assembleDebug"]

        env = os.environ.copy()
        proc = subprocess.run(
            cmd, cwd=project, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=20*60
        )
        if proc.returncode != 0:
            tail = "\n".join(proc.stdout.splitlines()[-35:])
            return jsonify(error="Gradle не смог собрать проект:\n" + tail), 400

        apk = find_apk(project)
        if not apk:
            return jsonify(error="Сборка завершилась, но APK не найден."), 500

        out = work / "game-debug.apk"
        shutil.copy2(apk, out)
        return send_file(out, as_attachment=True, download_name="game-debug.apk",
                         mimetype="application/vnd.android.package-archive")
    except subprocess.TimeoutExpired:
        return jsonify(error="Сборка превысила лимит времени 20 минут."), 408
    except Exception as e:
        return jsonify(error=f"Ошибка сервера: {e}"), 500
    finally:
        # send_file may still be streaming; for production use a background cleanup strategy.
        pass

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","8080")))
