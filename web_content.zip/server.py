import os, sqlite3, json, hashlib, secrets, time
from datetime import datetime, timezone
from flask import Flask, request, jsonify, send_from_directory, g

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, "data.sqlite3")
app = Flask(__name__, static_folder="static")
app.config["JSON_AS_ASCII"] = False
SESSIONS = {}

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(exc):
    c = g.pop("db", None)
    if c: c.close()

def pw_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 240000).hex()
    return salt + "$" + h

def pw_ok(password, stored):
    try:
        salt, expected = stored.split("$", 1)
        got = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 240000).hex()
        return secrets.compare_digest(got, expected)
    except Exception: return False

def init_db():
    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS orgs(id TEXT PRIMARY KEY,name TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,org_id TEXT,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,active INTEGER DEFAULT 1,FOREIGN KEY(org_id) REFERENCES orgs(id));
    CREATE TABLE IF NOT EXISTS offices(id TEXT PRIMARY KEY,org_id TEXT NOT NULL,name TEXT NOT NULL,active INTEGER DEFAULT 1,FOREIGN KEY(org_id) REFERENCES orgs(id));
    CREATE TABLE IF NOT EXISTS visits(id TEXT PRIMARY KEY,org_id TEXT NOT NULL,visitor_name TEXT NOT NULL,name_fr TEXT DEFAULT '',office_id TEXT NOT NULL,office_name TEXT NOT NULL,visit_date TEXT NOT NULL,entry_time TEXT NOT NULL,exit_time TEXT DEFAULT '',reason TEXT DEFAULT '',notes TEXT DEFAULT '',birth_date TEXT DEFAULT '',national_id TEXT DEFAULT '',created_by TEXT NOT NULL,updated_at TEXT NOT NULL,deleted INTEGER DEFAULT 0,FOREIGN KEY(org_id) REFERENCES orgs(id));
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,org_id TEXT,user_id TEXT,user_name TEXT,action TEXT,record_id TEXT,details TEXT,at TEXT);
    """)
    org = c.execute("SELECT id FROM orgs LIMIT 1").fetchone()
    if not org:
        oid = "org-main"
        c.execute("INSERT INTO orgs VALUES(?,?,?)",(oid,"متوسطة ...",datetime.now().isoformat(timespec="seconds")))
        offices = ["مكتب المدير","الأمانة","مكتب الناظر","مكتب المستشار","مكتب المقتصد","مصلحة أخرى"]
        for i,n in enumerate(offices): c.execute("INSERT INTO offices VALUES(?,?,?,1)",(f"off-{i+1}",oid,n))
        c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,1)",("u-admin",oid,"مدير المؤسسة","admin",pw_hash("Admin@123"),"manager"))
        c.execute("INSERT INTO users VALUES(?,?,?,?,?,?,1)",("u-staff",oid,"موظف تجريبي","staff",pw_hash("Staff@123"),"employee"))
    c.commit(); c.close()

def now_local():
    return datetime.now().astimezone().isoformat(timespec="seconds")

def current_user():
    token = request.headers.get("Authorization","").replace("Bearer ","")
    uid = SESSIONS.get(token)
    if not uid: return None
    return db().execute("SELECT * FROM users WHERE id=? AND active=1",(uid,)).fetchone()

def auth_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrap(*a,**kw):
        u=current_user()
        if not u: return jsonify(error="يلزم تسجيل الدخول"),401
        g.user=u
        return fn(*a,**kw)
    return wrap

def audit(action, record_id="", details=""):
    u=g.user
    db().execute("INSERT INTO audit(org_id,user_id,user_name,action,record_id,details,at) VALUES(?,?,?,?,?,?,?)",
      (u["org_id"],u["id"],u["name"],action,record_id,details,now_local()))

@app.route("/")
def index(): return send_from_directory("static","index.html")
@app.route("/<path:path>")
def static_files(path): return send_from_directory("static",path)

@app.post("/api/login")
def login():
    data=request.get_json(force=True)
    u=db().execute("SELECT * FROM users WHERE username=?",(data.get("username",""),)).fetchone()
    if not u or not pw_ok(data.get("password",""),u["password"]): return jsonify(error="اسم المستخدم أو كلمة المرور غير صحيحين"),401
    token=secrets.token_urlsafe(32); SESSIONS[token]=u["id"]
    return jsonify(token=token,user={"id":u["id"],"name":u["name"],"role":u["role"],"org_id":u["org_id"],"org_name":db().execute("SELECT name FROM orgs WHERE id=?",(u["org_id"],)).fetchone()["name"]})

@app.post("/api/logout")
@auth_required
def logout():
    token=request.headers.get("Authorization","").replace("Bearer ",""); SESSIONS.pop(token,None)
    return jsonify(ok=True)

@app.get("/api/bootstrap")
@auth_required
def bootstrap():
    u=g.user; oid=u["org_id"]
    offices=db().execute("SELECT id,name FROM offices WHERE org_id=? AND active=1 ORDER BY rowid",(oid,)).fetchall()
    visits=db().execute("SELECT * FROM visits WHERE org_id=? AND deleted=0 ORDER BY visit_date DESC,entry_time DESC LIMIT 1000",(oid,)).fetchall()
    orgs=[]
    if u["role"]=="superadmin":
        orgs=[dict(x) for x in db().execute("SELECT id,name FROM orgs ORDER BY name")]
    return jsonify(offices=[dict(x) for x in offices],visits=[dict(x) for x in visits],orgs=orgs,server_time=now_local())

@app.post("/api/sync")
@auth_required
def sync():
    u=g.user; data=request.get_json(force=True); oid=u["org_id"]
    if not oid: return jsonify(error="اختر مؤسسة أولاً"),400
    accepted=[]; conflicts=[]
    for v in data.get("visits",[]):
        old=db().execute("SELECT updated_at FROM visits WHERE id=? AND org_id=?",(v.get("id"),oid)).fetchone()
        # Employees may create visits only; only managers may update an existing visit.
        if old and u["role"] == "employee":
            conflicts.append(v.get("id")); continue
        if old and old["updated_at"] > v.get("updated_at",""):
            conflicts.append(v.get("id")); continue
        db().execute("""INSERT INTO visits(id,org_id,visitor_name,name_fr,office_id,office_name,visit_date,entry_time,exit_time,reason,notes,birth_date,national_id,created_by,updated_at,deleted)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET visitor_name=excluded.visitor_name,name_fr=excluded.name_fr,office_id=excluded.office_id,office_name=excluded.office_name,visit_date=excluded.visit_date,entry_time=excluded.entry_time,exit_time=excluded.exit_time,reason=excluded.reason,notes=excluded.notes,birth_date=excluded.birth_date,national_id=excluded.national_id,updated_at=excluded.updated_at,deleted=excluded.deleted""",
        (v["id"],oid,v.get("visitor_name",""),v.get("name_fr",""),v.get("office_id",""),v.get("office_name",""),v.get("visit_date",""),v.get("entry_time",""),v.get("exit_time",""),v.get("reason",""),v.get("notes",""),v.get("birth_date",""),v.get("national_id",""),u["id"],v.get("updated_at",now_local()),int(v.get("deleted",0))))
        accepted.append(v.get("id"))
        audit("مزامنة/حفظ زيارة",v.get("id"),v.get("visitor_name",""))
    db().commit()
    rows=db().execute("SELECT * FROM visits WHERE org_id=? AND deleted=0 ORDER BY updated_at DESC LIMIT 2000",(oid,)).fetchall()
    return jsonify(accepted=accepted,conflicts=conflicts,visits=[dict(r) for r in rows])

@app.post("/api/offices")
@auth_required
def add_office():
    u=g.user
    if u["role"] not in ("manager","superadmin"): return jsonify(error="غير مصرح"),403
    d=request.get_json(force=True); oid=secrets.token_hex(8)
    db().execute("INSERT INTO offices VALUES(?,?,?,1)",(oid,u["org_id"],d["name"])); audit("إضافة مكتب",oid,d["name"]); db().commit()
    return jsonify(id=oid,name=d["name"])

@app.post("/api/users")
@auth_required
def add_user():
    u=g.user
    if u["role"] not in ("manager","superadmin"): return jsonify(error="غير مصرح"),403
    d=request.get_json(force=True)
    if d.get("role") not in ("manager","employee"): return jsonify(error="صلاحية غير صحيحة"),400
    uid=secrets.token_hex(8)
    try:
        db().execute("INSERT INTO users VALUES(?,?,?,?,?,?,1)",(uid,u["org_id"],d["name"],d["username"],pw_hash(d["password"]),d["role"]))
        audit("إنشاء حساب",uid,d["username"]); db().commit()
    except sqlite3.IntegrityError: return jsonify(error="اسم المستخدم مستخدم مسبقًا"),409
    return jsonify(ok=True,id=uid)

@app.post("/api/orgs")
@auth_required
def add_org():
    u=g.user
    if u["role"]!="superadmin": return jsonify(error="للمدير العام فقط"),403
    d=request.get_json(force=True); oid=secrets.token_hex(8)
    db().execute("INSERT INTO orgs VALUES(?,?,?)",(oid,d["name"],now_local()))
    for i,n in enumerate(["مكتب المدير","الأمانة","مكتب الناظر","مكتب المستشار","مكتب المقتصد","مصلحة أخرى"]):
        db().execute("INSERT INTO offices VALUES(?,?,?,1)",(secrets.token_hex(8),oid,n))
    db().commit(); return jsonify(id=oid,name=d["name"])

@app.get("/api/audit")
@auth_required
def get_audit():
    u=g.user
    if u["role"]=="employee": return jsonify(rows=[])
    rows=db().execute("SELECT user_name,action,record_id,details,at FROM audit WHERE org_id=? ORDER BY id DESC LIMIT 300",(u["org_id"],)).fetchall()
    return jsonify(rows=[dict(r) for r in rows])

@app.get("/manifest.json")
def manifest(): return send_from_directory("static","manifest.json")

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","8080")),debug=False)
