export const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
export const ALLOWED_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);

export function parseImageDataUrl(value) {
  if (typeof value !== 'string' || value.length < 100) {
    throw new Error('bad_image');
  }
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match) throw new Error('bad_image');
  const mime = match[1];
  const base64 = match[2];
  const estimatedBytes = Math.floor((base64.length * 3) / 4) - (base64.endsWith('==') ? 2 : base64.endsWith('=') ? 1 : 0);
  if (estimatedBytes <= 0 || estimatedBytes > MAX_IMAGE_BYTES) throw new Error('bad_image');
  const bytes = Buffer.from(base64, 'base64');
  if (bytes.length !== estimatedBytes || bytes.toString('base64') !== base64) throw new Error('bad_image');

  const signatures = {
    'image/jpeg': bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff,
    'image/png': bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])),
    'image/webp': bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP',
  };
  if (!ALLOWED_MIME.has(mime) || !signatures[mime]) throw new Error('bad_image');
  return { mime, bytes };
}

export function normalizeFoodName(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .toLocaleLowerCase('en')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function itemKey(item) {
  const en = normalizeFoodName(item.name_en);
  const ar = normalizeFoodName(item.name_ar);
  return { en, ar };
}
function stripArabicArticle(value) {
  return value.startsWith('ال') && value.length > 3 ? value.slice(2) : value;
}
function itemsMatch(a, b) {
  const ak = itemKey(a), bk = itemKey(b);
  const arabicMatch = ak.ar && bk.ar && (ak.ar === bk.ar || stripArabicArticle(ak.ar) === stripArabicArticle(bk.ar));
  return Boolean((ak.en && bk.en && ak.en === bk.en) || arabicMatch);
}

const confidenceRank = { low: 0, medium: 1, high: 2 };
const lowerConfidence = (a, b) => confidenceRank[a] <= confidenceRank[b] ? a : b;

function cleanStrings(values, max = 4) {
  return Array.isArray(values)
    ? values.filter((v) => typeof v === 'string').map((v) => v.trim()).filter(Boolean).slice(0, max)
    : [];
}

export function validateModelResult(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('malformed_model_output');
  const statuses = new Set(['food', 'not_food', 'uncertain']);
  const qualities = new Set(['clear', 'mixed', 'poor']);
  if (!statuses.has(raw.status) || !qualities.has(raw.quality)) throw new Error('malformed_model_output');
  if (typeof raw.summary_ar !== 'string' || typeof raw.summary_en !== 'string') throw new Error('malformed_model_output');
  if (!Array.isArray(raw.dishes) || raw.dishes.length > 5 || !Array.isArray(raw.visible_items) || raw.visible_items.length > 10) throw new Error('malformed_model_output');
  if (!Array.isArray(raw.uncertainties_ar) || !Array.isArray(raw.uncertainties_en)) throw new Error('malformed_model_output');
  const validateItem = (item, visible = false) => {
    if (!item || typeof item !== 'object') throw new Error('malformed_model_output');
    if (typeof item.name_ar !== 'string' || !item.name_ar.trim() || item.name_ar.length > 100) throw new Error('malformed_model_output');
    if (typeof item.name_en !== 'string' || !item.name_en.trim() || item.name_en.length > 100) throw new Error('malformed_model_output');
    if (!['high', 'medium', 'low'].includes(item.confidence)) throw new Error('malformed_model_output');
    if (typeof item.evidence_ar !== 'string' || typeof item.evidence_en !== 'string') throw new Error('malformed_model_output');
    if (!Array.isArray(item.alternatives_ar) || !Array.isArray(item.alternatives_en)) throw new Error('malformed_model_output');
    if (visible && !['main_dish', 'side', 'visible_component', 'drink', 'other'].includes(item.role)) throw new Error('malformed_model_output');
  };
  raw.dishes.forEach((item) => validateItem(item));
  raw.visible_items.forEach((item) => validateItem(item, true));
  if (raw.status === 'not_food' && (raw.dishes.length || raw.visible_items.length)) throw new Error('malformed_model_output');
  if (raw.status === 'food' && !raw.dishes.length && !raw.visible_items.length) throw new Error('malformed_model_output');
  return {
    status: raw.status,
    quality: raw.quality,
    summary_ar: raw.summary_ar.trim().slice(0, 500),
    summary_en: raw.summary_en.trim().slice(0, 500),
    dishes: raw.dishes.map((x) => ({ ...x, alternatives_ar: cleanStrings(x.alternatives_ar, 2), alternatives_en: cleanStrings(x.alternatives_en, 2) })),
    visible_items: raw.visible_items.map((x) => ({ ...x, alternatives_ar: cleanStrings(x.alternatives_ar, 2), alternatives_en: cleanStrings(x.alternatives_en, 2) })),
    uncertainties_ar: cleanStrings(raw.uncertainties_ar, 8),
    uncertainties_en: cleanStrings(raw.uncertainties_en, 8),
  };
}

function mergeItems(first, second, max, visible = false) {
  const output = [];
  const used = new Set();
  for (const a of first) {
    const matchIndex = second.findIndex((b, i) => !used.has(i) && itemsMatch(a, b));
    if (matchIndex < 0) {
      output.push({ ...a, confidence: 'low' });
      continue;
    }
    used.add(matchIndex);
    const b = second[matchIndex];
    output.push({
      ...a,
      confidence: lowerConfidence(a.confidence, b.confidence),
      evidence_ar: a.evidence_ar === b.evidence_ar ? a.evidence_ar : [a.evidence_ar, b.evidence_ar].filter(Boolean).join(' · ').slice(0, 240),
      evidence_en: a.evidence_en === b.evidence_en ? a.evidence_en : [a.evidence_en, b.evidence_en].filter(Boolean).join(' · ').slice(0, 240),
      alternatives_ar: cleanStrings([...(a.alternatives_ar || []), ...(b.alternatives_ar || [])], 3),
      alternatives_en: cleanStrings([...(a.alternatives_en || []), ...(b.alternatives_en || [])], 3),
      ...(visible && a.role !== b.role ? { role: 'other' } : {}),
    });
  }
  for (let i = 0; i < second.length; i++) {
    if (!used.has(i)) output.push({ ...second[i], confidence: 'low' });
  }
  return output.slice(0, max);
}

export function reconcileReviews(firstRaw, secondRaw) {
  const first = validateModelResult(firstRaw);
  const second = validateModelResult(secondRaw);
  const sameStatus = first.status === second.status;
  const dishes = mergeItems(first.dishes, second.dishes, 5);
  const visibleItems = mergeItems(first.visible_items, second.visible_items, 10, true);
  const count = Math.max(first.dishes.length + first.visible_items.length, second.dishes.length + second.visible_items.length, 1);
  const commonCount = [...first.dishes, ...first.visible_items].filter((a) => [...second.dishes, ...second.visible_items].some((b) => itemsMatch(a, b))).length;
  const overlap = commonCount / count;
  const bothClearlyNotFood = first.status === 'not_food' && second.status === 'not_food';
  const agreement = bothClearlyNotFood ? 'strong' : !sameStatus || overlap < 0.35 ? 'mismatch' : overlap >= 0.8 ? 'strong' : 'partial';
  let status;
  if (!sameStatus) status = 'uncertain';
  else if (first.status === 'not_food') status = 'not_food';
  else if (first.status === 'uncertain' || agreement === 'mismatch' || !dishes.length && !visibleItems.length) status = 'uncertain';
  else status = 'food';
  const qualityRank = { clear: 2, mixed: 1, poor: 0 };
  const quality = qualityRank[first.quality] <= qualityRank[second.quality] ? first.quality : second.quality;
  const uncertaintiesAr = cleanStrings([...first.uncertainties_ar, ...second.uncertainties_ar]);
  const uncertaintiesEn = cleanStrings([...first.uncertainties_en, ...second.uncertainties_en]);
  if (!sameStatus) {
    uncertaintiesAr.unshift('المراجعتان اختلفتا في تحديد ما إذا كانت الصورة تحتوي على طعام. راجعها يدويًا.');
    uncertaintiesEn.unshift('The two reviews disagreed about whether food is present. Check the photo manually.');
  } else if (agreement !== 'strong') {
    uncertaintiesAr.unshift('بعض العناصر لم تتأكد في المراجعتين؛ اعتبر الأسماء منخفضة الثقة.');
    uncertaintiesEn.unshift('Some items were not confirmed by both reviews; treat names as low-confidence suggestions.');
  }
  return {
    status,
    quality,
    summary_ar: first.summary_ar || second.summary_ar,
    summary_en: first.summary_en || second.summary_en,
    dishes,
    visible_items: visibleItems,
    uncertainties_ar: cleanStrings(uncertaintiesAr, 8),
    uncertainties_en: cleanStrings(uncertaintiesEn, 8),
    agreement,
  };
}
