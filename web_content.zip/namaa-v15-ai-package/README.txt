Namaa V15 AI food-photo package
Start: node server.mjs
Open: http://127.0.0.1:4173
Requirements: Node.js 20+
Tests: node --test
See README-AR.md for setup, privacy and accuracy limitations.
The HTML file contains no API key. An adult account owner must configure server-side OPENAI_API_KEY in a private .env file.
