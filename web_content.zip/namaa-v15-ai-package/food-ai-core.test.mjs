import test from 'node:test';
import assert from 'node:assert/strict';
import { parseImageDataUrl, normalizeFoodName, reconcileReviews, validateModelResult } from './food-ai-core.mjs';

const imageDataUrl = (mime, bytes) => `data:${mime};base64,${Buffer.from(bytes).toString('base64')}`;
const base = {
  status: 'food', quality: 'clear', summary_ar: 'طبق طعام واضح', summary_en: 'A clear meal photo',
  dishes: [{ name_ar: 'كشري', name_en: 'Koshari', confidence: 'high', evidence_ar: 'طبق مكرونة وعدس وأرز', evidence_en: 'A mixed rice, pasta and lentil dish', alternatives_ar: [], alternatives_en: [] }],
  visible_items: [{ name_ar: 'أرز', name_en: 'Rice', confidence: 'high', evidence_ar: 'حبات أرز ظاهرة', evidence_en: 'Visible rice grains', alternatives_ar: [], alternatives_en: [], role: 'visible_component' }],
  uncertainties_ar: [], uncertainties_en: [],
};

test('accepts only a well-formed JPEG data URL with matching magic bytes', () => {
  const valid = parseImageDataUrl(imageDataUrl('image/jpeg', [0xff, 0xd8, 0xff, ...Array(160).fill(0x41), 0xff, 0xd9]));
  assert.equal(valid.mime, 'image/jpeg');
  assert.throws(() => parseImageDataUrl(imageDataUrl('image/png', [0xff, 0xd8, 0xff, ...Array(160).fill(0x41)])), /bad_image/);
  assert.throws(() => parseImageDataUrl('data:image/svg+xml;base64,PHN2Zz4='), /bad_image/);
});

test('normalizes common Arabic spelling forms before comparison', () => {
  assert.equal(normalizeFoodName('إِرْز'), normalizeFoodName('ارز'));
  assert.equal(normalizeFoodName('كُشْرِي'), normalizeFoodName('كشري'));
});

test('rejects malformed or overconfident model output', () => {
  assert.throws(() => validateModelResult({ status: 'food', quality: 'clear' }));
  assert.throws(() => validateModelResult({ ...base, dishes: [{ ...base.dishes[0], confidence: 'certain' }] }));
});

test('agreement keeps shared item confidence and downgrades unsupported additions', () => {
  const second = structuredClone(base);
  second.dishes[0].confidence = 'medium';
  second.visible_items.push({ name_ar: 'زيت زيتون', name_en: 'Olive oil', confidence: 'high', evidence_ar: 'غير واضح', evidence_en: 'Not clearly visible', alternatives_ar: [], alternatives_en: [], role: 'other' });
  const result = reconcileReviews(base, second);
  assert.equal(result.dishes[0].confidence, 'medium');
  assert.equal(result.visible_items.find(x => x.name_en === 'Olive oil').confidence, 'low');
  assert.equal(result.agreement, 'partial');
});

test('food vs non-food disagreement fails closed as uncertain', () => {
  const nonFood = { status: 'not_food', quality: 'clear', summary_ar: 'مش طعام', summary_en: 'Not food', dishes: [], visible_items: [], uncertainties_ar: [], uncertainties_en: [] };
  const result = reconcileReviews(base, nonFood);
  assert.equal(result.status, 'uncertain');
  assert.equal(result.agreement, 'mismatch');
});

test('two non-food reviews are reported as non-food', () => {
  const nonFood = { status: 'not_food', quality: 'clear', summary_ar: 'قلم', summary_en: 'A pen', dishes: [], visible_items: [], uncertainties_ar: [], uncertainties_en: [] };
  const result = reconcileReviews(nonFood, nonFood);
  assert.equal(result.status, 'not_food');
  assert.equal(result.agreement, 'strong');
});

test('recognizes PNG and WebP file signatures', () => {
  const png = [137, 80, 78, 71, 13, 10, 26, 10, ...Array(120).fill(0x41)];
  const webp = [...Buffer.from('RIFF'), 20, 0, 0, 0, ...Buffer.from('WEBP'), ...Array(120).fill(0x41)];
  assert.equal(parseImageDataUrl(imageDataUrl('image/png', png)).mime, 'image/png');
  assert.equal(parseImageDataUrl(imageDataUrl('image/webp', webp)).mime, 'image/webp');
});

test('rejects invalid base64 even when the text resembles a data URL', () => {
  assert.throws(() => parseImageDataUrl(`data:image/jpeg;base64,${'A'.repeat(120)}!`), /bad_image/);
});

test('matches equivalent Arabic item names even when English wording differs', () => {
  const second = structuredClone(base);
  second.dishes[0].name_en = 'Egyptian koshari';
  second.dishes[0].name_ar = 'الكشري';
  const result = reconcileReviews(base, second);
  assert.equal(result.agreement, 'strong');
  assert.equal(result.dishes.length, 1);
  assert.equal(result.dishes[0].confidence, 'high');
});

test('does not invent an item when only one review sees it', () => {
  const second = structuredClone(base);
  second.visible_items = [];
  const result = reconcileReviews(base, second);
  const rice = result.visible_items.find((x) => x.name_en === 'Rice');
  assert.equal(rice.confidence, 'low');
  assert.equal(result.agreement, 'partial');
});
