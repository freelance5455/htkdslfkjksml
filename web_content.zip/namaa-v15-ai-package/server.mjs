import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseImageDataUrl, reconcileReviews } from './food-ai-core.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HTML_PATH = path.join(HERE, 'namaa-v15.html');

function loadEnvFile() {
  const envPath = path.join(HERE, '.env');
  if (!existsSync(envPath)) return;
  const raw = readFileSync(envPath, 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const match = /^\s*(?:export\s+)?([A-Z][A-Z0-9_]*)\s*=\s*(.*)\s*$/.exec(line);
    if (!match || process.env[match[1]] !== undefined) continue;
    let value = match[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    process.env[match[1]] = value;
  }
}
loadEnvFile();

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 4173);
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-astra';
const API_KEY = process.env.OPENAI_API_KEY || '';
const MAX_BODY_BYTES = 5_800_000;
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 2;
const requestWindows = new Map();

if (HOST !== '127.0.0.1' && HOST !== '::1' && HOST !== 'localhost') {
  console.error('For safety, Namaa AI server only binds to this device (127.0.0.1). Do not expose it to a network without authentication and HTTPS.');
  process.exit(1);
}

const itemSchema = {
  type: 'object', additionalProperties: false,
  required: ['name_ar', 'name_en', 'confidence', 'evidence_ar', 'evidence_en', 'alternatives_ar', 'alternatives_en'],
  properties: {
    name_ar: { type: 'string' }, name_en: { type: 'string' },
    confidence: { type: 'string', enum: ['high', 'medium', 'low'] },
    evidence_ar: { type: 'string' }, evidence_en: { type: 'string' },
    alternatives_ar: { type: 'array', items: { type: 'string' }, maxItems: 2 },
    alternatives_en: { type: 'array', items: { type: 'string' }, maxItems: 2 },
  },
};
const visibleItemSchema = {
  ...itemSchema,
  required: [...itemSchema.required, 'role'],
  properties: {
    ...itemSchema.properties,
    role: { type: 'string', enum: ['main_dish', 'side', 'visible_component', 'drink', 'other'] },
  },
};
const FOOD_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['status', 'quality', 'summary_ar', 'summary_en', 'dishes', 'visible_items', 'uncertainties_ar', 'uncertainties_en'],
  properties: {
    status: { type: 'string', enum: ['food', 'not_food', 'uncertain'] },
    quality: { type: 'string', enum: ['clear', 'mixed', 'poor'] },
    summary_ar: { type: 'string' }, summary_en: { type: 'string' },
    dishes: { type: 'array', items: itemSchema, maxItems: 5 },
    visible_items: { type: 'array', items: visibleItemSchema, maxItems: 10 },
    uncertainties_ar: { type: 'array', items: { type: 'string' }, maxItems: 8 },
    uncertainties_en: { type: 'array', items: { type: 'string' }, maxItems: 8 },
  },
};

const SYSTEM_INSTRUCTIONS = `You are a cautious food-photo recognition assistant for a bilingual Egyptian meal journal.
Your task is visual identification only. Do not estimate calories, macronutrients, grams, serving weight, edible yield, recipe, health value, or dietary advice.
Describe only foods and drinks that are actually visible in the image. Never infer hidden oil, butter, sugar, salt, sauces, fillings, cooking methods, ingredients inside opaque foods, or food behind an occlusion.
Distinguish the overall dish from separately visible components. Do not report the same food twice under different names. For mixed dishes, name the visible dish and list only components that can genuinely be distinguished visually.
Use natural, common Egyptian Arabic names in name_ar and precise plain English names in name_en. Do not make a regional recipe claim unless the image supports it.
Confidence is a qualitative visual judgment, not a probability. Use high only when visual evidence is clear and distinctive; medium when likely but not unique; low when uncertain, partly hidden, distant, blurred, or visually similar to other foods. Never upgrade confidence merely because a food is common in Egypt.
For every item, evidence_ar and evidence_en must state the visible visual cue, not an imagined ingredient list. alternatives should list at most two genuine visual alternatives only when relevant; otherwise use empty arrays.
If no food or drink is visible, use status not_food and empty arrays. If the photo is blurry, obstructed, too distant, or ambiguous, use uncertain or low confidence rather than forcing a guess. If the overall image quality is poor, quality must be poor.
Do not read labels, infer a person's identity, or comment on people in the frame. Never judge food as good, bad, healthy, or unhealthy.
Return only the exact JSON object matching the required schema.`;

const REVIEW_INSTRUCTIONS = `You are doing a second, cautious visual inspection of a food photo for a meal journal. This is a fresh review: identify only what you can independently see in the image. Do not assume that common foods are present. Do not infer any hidden ingredient, recipe, cooking method, oil, sauce, calories, grams, or portion weight. Distinguish a whole visible dish from its clearly distinguishable components and avoid duplicates. Use natural Egyptian Arabic in Arabic names and precise English names. Confidence labels are qualitative, not probabilities. Use low confidence for ambiguous items and status uncertain when the image is unclear. If no food is clearly visible, return not_food or uncertain as appropriate. Return only the exact JSON object matching the required schema.`;

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store, max-age=0',
    'Pragma': 'no-cache',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
  });
  res.end(body);
}

function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return false;
  try {
    const parsed = new URL(origin);
    const allowedHosts = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`, `[::1]:${PORT}`]);
    return parsed.protocol === 'http:' && allowedHosts.has(parsed.host);
  } catch {
    return false;
  }
}

async function readJsonBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error('body_too_large');
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new Error('bad_request'); }
}

function rateLimit(req) {
  const key = req.socket.remoteAddress || 'local';
  const now = Date.now();
  const current = requestWindows.get(key) || { start: now, count: 0 };
  if (now - current.start >= WINDOW_MS) { current.start = now; current.count = 0; }
  current.count += 1;
  requestWindows.set(key, current);
  if (requestWindows.size > 100) {
    for (const [k, v] of requestWindows) if (now - v.start > WINDOW_MS * 2) requestWindows.delete(k);
  }
  return current.count <= MAX_REQUESTS_PER_WINDOW;
}

function extractOutputText(response) {
  if (typeof response.output_text === 'string' && response.output_text.trim()) return response.output_text;
  for (const item of response.output || []) {
    for (const part of item.content || []) {
      if (part.type === 'refusal') throw new Error('model_refusal');
      if (part.type === 'output_text' && typeof part.text === 'string') return part.text;
    }
  }
  throw new Error('empty_model_response');
}

async function callVisionModel(imageDataUrl, instructions, language) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 55_000);
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
      },
      signal: controller.signal,
      body: JSON.stringify({
        model: MODEL,
        instructions: `${instructions}\nThe interface language selected by the user is ${language === 'ar' ? 'Arabic' : 'English'}; always provide both Arabic and English item names regardless.`,
        input: [{
          role: 'user',
          content: [
            { type: 'input_text', text: 'Inspect this single meal photo and return the food-identification schema. Be conservative. Do not infer portion size or nutrition.' },
            { type: 'input_image', image_url: imageDataUrl, detail: 'high' },
          ],
        }],
        text: {
          format: {
            type: 'json_schema',
            name: 'namaa_food_photo_review',
            strict: true,
            schema: FOOD_SCHEMA,
          },
        },
        reasoning: { effort: 'high' },
        max_output_tokens: 1800,
        store: false,
      }),
    });
    if (!response.ok) {
      const error = new Error('provider_error');
      error.status = response.status;
      throw error;
    }
    const payload = await response.json();
    const outputText = extractOutputText(payload);
    let parsed;
    try { parsed = JSON.parse(outputText); }
    catch { throw new Error('malformed_model_output'); }
    return parsed;
  } finally {
    clearTimeout(timer);
  }
}

function toPublicError(error) {
  if (error.message === 'bad_image' || error.message === 'body_too_large') return { status: 400, code: 'bad_image' };
  if (error.message === 'bad_request') return { status: 400, code: 'bad_request' };
  if (error.message === 'malformed_model_output' || error.message === 'empty_model_response') return { status: 502, code: 'invalid_model_response' };
  if (error.message === 'model_refusal') return { status: 422, code: 'model_refusal' };
  if (error.name === 'AbortError') return { status: 504, code: 'provider_timeout' };
  if (error.status === 401 || error.status === 403) return { status: 503, code: 'provider_auth' };
  if (error.status === 429) return { status: 429, code: 'provider_rate_limit' };
  if (error.status === 413 || error.status === 415) return { status: 400, code: 'bad_image' };
  return { status: 502, code: 'service_error' };
}

async function handleAnalysis(req, res) {
  if (!originAllowed(req)) return sendJson(res, 403, { ok: false, error: 'origin_blocked' });
  if (!rateLimit(req)) return sendJson(res, 429, { ok: false, error: 'rate_limit' });
  if (!API_KEY) return sendJson(res, 503, { ok: false, error: 'missing_config' });
  let imageDataUrl;
  try {
    const body = await readJsonBody(req);
    if (!body || typeof body.imageDataUrl !== 'string') throw new Error('bad_image');
    if (!['ar', 'en'].includes(body.language)) body.language = 'en';
    parseImageDataUrl(body.imageDataUrl);
    imageDataUrl = body.imageDataUrl;
    const first = await callVisionModel(imageDataUrl, SYSTEM_INSTRUCTIONS, body.language);
    const second = await callVisionModel(imageDataUrl, REVIEW_INSTRUCTIONS, body.language);
    const result = reconcileReviews(first, second);
    return sendJson(res, 200, { ok: true, result, agreement: result.agreement });
  } catch (error) {
    const publicError = toPublicError(error);
    // Deliberately log only a short error code. Never log image bytes or model output.
    if (publicError.code === 'service_error' || publicError.code === 'invalid_model_response') {
      console.error('[namaa-food-ai]', publicError.code);
    }
    return sendJson(res, publicError.status, { ok: false, error: publicError.code });
  } finally {
    imageDataUrl = '';
  }
}

const server = http.createServer(async (req, res) => {
  const requestUrl = new URL(req.url || '/', `http://${req.headers.host || `127.0.0.1:${PORT}`}`);
  if (req.method === 'GET' && (requestUrl.pathname === '/' || requestUrl.pathname === '/namaa-v15.html')) {
    try {
      const html = await readFile(HTML_PATH);
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Length': html.length,
        'Cache-Control': 'no-store, max-age=0',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
      });
      return res.end(html);
    } catch {
      return sendJson(res, 500, { ok: false, error: 'app_file_missing' });
    }
  }
  if (req.method === 'POST' && requestUrl.pathname === '/api/food/analyze') return handleAnalysis(req, res);
  if (req.method === 'GET' && requestUrl.pathname === '/health') return sendJson(res, 200, { ok: true, modelConfigured: Boolean(API_KEY), model: MODEL });
  return sendJson(res, 404, { ok: false, error: 'not_found' });
});

server.headersTimeout = 10_000;
server.requestTimeout = 30_000;
server.keepAliveTimeout = 5_000;
server.listen(PORT, HOST, () => {
  console.log(`Namaa is running locally: http://${HOST}:${PORT}`);
  console.log(`Food photo AI: ${API_KEY ? `configured (${MODEL})` : 'not configured yet (the app will show a clear setup message)'}`);
  console.log('The server is bound to this device only. Do not expose it to a network.');
});

function shutdown() {
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5_000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
