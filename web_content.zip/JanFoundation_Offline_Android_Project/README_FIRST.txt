JAN FOUNDATION LESSON PLAN TRACKER — OFFLINE ANDROID APP PROJECT

What this is
- An Android Studio project that packages your existing offline lesson tracker as a phone app.
- Uses your school logo as the app icon.
- Keeps the app's records locally on this phone; it does not use a cloud database or sync to other devices.
- Includes A Branch, B Branch, and Main Branch from the supplied tracker file.
- Reports use Android's print service, where you can choose Save as PDF.

IMPORTANT
This ZIP is the Android Studio SOURCE PROJECT, not a ready-to-install APK. It has not been built or tested on a physical phone in this environment.

How to build the APK on a computer
1. Install Android Studio from the official Android developer website.
2. Extract this ZIP to a folder.
3. In Android Studio choose Open and select the extracted JanFoundation_Offline_Android_Project folder.
4. Allow Gradle sync and install any Android SDK platform it requests.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, use the notification's locate link to find app-debug.apk.
7. Transfer app-debug.apk to your LG phone, open it, and allow installation from that source if Android asks.

DATA SAFETY
The app's local records stay inside the app's private browser storage on this device. Export backups regularly if the tracker provides the backup option. Uninstalling the app or clearing its data can erase records. The old HTML file in Chrome may have a separate set of records; this app will not automatically import those records.

BRANCH NOTE
The supplied HTML file is bundled as-is except for its title/theme metadata. Check teacher-to-branch assignments before using the app for official reports.

UPDATE: This version includes separate Daily Lesson Plan Report and Monthly Meeting Report options. Select the month and branch for the monthly report; each report has its own Print / Save PDF button.
