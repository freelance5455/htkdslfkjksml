package com.janfoundation.lessontracker;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("window.print = function(){ if(window.JanFoundationNative){window.JanFoundationNative.printPage();} };", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PrintBridge(this), "JanFoundationNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private static class PrintBridge {
        private final Activity activity;
        PrintBridge(Activity a) { activity = a; }
        @JavascriptInterface public void printPage() {
            activity.runOnUiThread(() -> {
                WebView view = ((MainActivity)activity).webView;
                PrintManager pm = (PrintManager)activity.getSystemService(Context.PRINT_SERVICE);
                if (pm != null) pm.print("Jan Foundation Lesson Plan Report", view.createPrintDocumentAdapter("Jan Foundation Report"), new PrintAttributes.Builder().build());
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
