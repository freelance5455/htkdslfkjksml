# Fast Brander v1.2.0

## Priority changes
- Added a complete Android Studio WebView host source project (not a compiled APK).
- Added Android 11+ all-files access permission request through Android Settings.
- Added native in-app shared-storage browsing for logo and business image selection.
- Added direct native Downloads/Fast Brander export path for PDF, PNG, JPEG, CSV and JSON files.
- Added status reporting for Android all-files access and native bridge availability.
- Kept browser/PWA file selection and download fallbacks for non-Android use.
- Updated app shell cache version to 1.2.0.

## Branding / document output
- Company logo, company identity details, optional signature and stamp remain included in branded HTML and canvas/PDF exports.
- Saved documents continue to use their stored company snapshot for consistent historical output.

## Important boundary
Android all-files access is a special restricted permission. It is user-approved, not guaranteed, and does not expose protected system/private app directories. Google Play use requires policy eligibility and approval.
