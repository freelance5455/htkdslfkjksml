# Fast Brander 1.1.0 — changes

This release continues the existing Fast Brander 1.0.2 project. It keeps the offline-first HTML/CSS/JavaScript architecture and has no remote runtime dependencies.

## New and improved

- Added a per-company media library for up to 20 supporting images.
- Added dedicated upload and removal controls for company signatures and stamps.
- Added a multi-image system picker for photos and supporting business artwork.
- Added a camera-capture control for compatible mobile browsers.
- Added signature/stamp placement to the document preview and native print output, and to raster-based PDF/image exports when the document layout has sufficient space.
- Added a device storage capability panel showing IndexedDB, save picker support, protected-storage status and approximate quota use.
- Added an explicit protected-storage request control using the browser Storage API where available.
- Added Save As support through `showSaveFilePicker()` where available, with normal browser download fallback.
- Included media assets in normal company records and JSON backup/restore.
- Updated the PWA cache version so the updated application shell replaces the older cached release.

## Permission boundary

Fast Brander does not request unrestricted access to the device filesystem. Photos, logos, stamps and signatures are selected through the browser or Android system picker, and camera capture is user initiated. The browser or native Android wrapper controls the permission prompt and the exact set of files returned to the app.
