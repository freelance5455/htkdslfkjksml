# Fast Brander Android host source (v1.2.0)

This package includes a complete Android Studio project source under `FastBranderAndroid/`. It is **not a compiled APK**. Open that folder in Android Studio, allow Gradle sync, connect a device/emulator, and run the `app` configuration.

## Priority capabilities implemented in the host source

- WebView packages the HTML/CSS/JavaScript app locally on a secure appassets origin; it does not depend on a hosted website. IndexedDB and service-worker-compatible origin handling use AndroidX WebKit WebViewAssetLoader.
- JavaScript and DOM storage are enabled for the app's local database.
- WebView file chooser callback supports single/multiple file inputs and camera/gallery providers.
- Android all-files access request uses the official special app-access Settings screen on Android 11+ (`MANAGE_EXTERNAL_STORAGE`).
- Fast Brander's **Browse device storage** buttons use a native bridge to browse accessible shared-storage folders and import selected image files without relying only on the generic system picker.
- PDF, PNG, JPEG, CSV and JSON exports sent through `FastBranderNative.saveFile()` are written directly to `Downloads/Fast Brander/` using MediaStore on Android 10+ (and the public Downloads folder on older Android versions).
- The native file browser limits imports to image types supported by the app and files up to 12 MB.

## All-files access warning — read before enabling

`MANAGE_EXTERNAL_STORAGE` is a powerful Android special permission. The app only requests it after the user taps **Request Android all-files access**. The user can deny it and continue using the normal file chooser and download functions. Android still blocks protected locations such as other apps' private data; this is not literal access to every byte on the phone.

Google Play restricts apps that request all-files access. A business-document app may not qualify as a core file manager/backup/antivirus use case. Do not publish to Google Play with this permission unless the app's declared purpose meets the current Play policy and approval is obtained. For private sideloading/testing, the permission can be enabled manually in Android Settings. Consider removing `MANAGE_EXTERNAL_STORAGE` for a Play release and using Storage Access Framework/MediaStore instead.

## Build / run

1. Install Android Studio and a compatible JDK (Android Studio's bundled JBR is suitable).
2. Open `FastBranderAndroid/` as an existing project.
3. Let Gradle sync download the Android Gradle Plugin/Kotlin plugin.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Run the `app` configuration. This builds/installs a debug app; no release signing keys are included.
6. In Fast Brander → Settings & backup, tap **Request Android all-files access** and approve it in Android Settings.
7. In Company profiles, use **Browse device storage** beside the logo/image controls.
8. Export a sample invoice PDF and verify it appears under `Downloads/Fast Brander/`.

## Security notes

- File paths are canonicalized and constrained to the shared-storage root to prevent path traversal.
- Native imports are limited to image extensions and 12 MB per file.
- The WebView loads only bundled local assets. No remote content or universal file-URL access is enabled.
- Do not load untrusted remote web pages in this WebView while the JavaScript bridge is enabled.
- The project uses no signing secrets. Configure release signing locally and keep keystores/passwords out of source control.

## Known limitations

- Android version, OEM file layout and permission state affect which folders can be browsed. `Android/data`, `Android/obb`, private app folders and system-protected paths are not promised to be accessible.
- The app's company/customer records remain in WebView IndexedDB/localStorage. Export backups regularly.
- Camera capture from the WebView file input depends on installed camera apps and WebView implementation.
- Android print/share integration is not included in this iteration; direct document downloads are implemented.
