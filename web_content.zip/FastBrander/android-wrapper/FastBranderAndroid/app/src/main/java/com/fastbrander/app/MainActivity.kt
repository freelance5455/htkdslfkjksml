package com.fastbrander.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import android.widget.Toast
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val FILE_CHOOSER = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.setSupportMultipleWindows(false)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    startActivityForResult(intent, FILE_CHOOSER)
                    true
                } catch (e: Exception) { fileCallback = null; false }
            }
        }
        web.addJavascriptInterface(NativeBridge(), "FastBranderNative")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        // Requesting broad access is explicit and user-controlled. Android may deny it or
        // prohibit its use for apps distributed through Google Play without an approved core use.
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Toast.makeText(this, "Fast Brander can request shared-storage access in Settings.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                else data.data?.let { arrayOf(it) }
            } else null
            fileCallback?.onReceiveValue(results)
            fileCallback = null
        }
    }

    private inner class NativeBridge {
        @JavascriptInterface fun hasAllFilesAccess(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

        @JavascriptInterface fun requestAllFilesAccess() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                    try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                    catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                } else Toast.makeText(this@MainActivity, "Shared storage access is already available.", Toast.LENGTH_SHORT).show()
            }
        }

        // Browses user-visible shared storage only. Android/data and protected system areas
        // remain unavailable even with all-files access on current Android versions.
        @JavascriptInterface fun listFiles(relativePath: String): String {
            if (!hasAllFilesAccess()) return "[]"
            return try {
                val base = Environment.getExternalStorageDirectory().canonicalFile
                val target = if (relativePath.isBlank()) base else File(base, relativePath).canonicalFile
                if (!(target.path == base.path || target.path.startsWith(base.path + File.separator)) || !target.isDirectory) return "[]"
                val out = JSONArray()
                target.listFiles()?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))?.forEach { f ->
                    if (f.isDirectory || f.extension.lowercase() in listOf("png", "jpg", "jpeg", "webp", "gif")) {
                        val rel = f.canonicalPath.removePrefix(base.path).trimStart(File.separatorChar).replace(File.separatorChar, '/')
                        out.put(JSONObject().put("name", f.name).put("path", rel).put("directory", f.isDirectory).put("size", if (f.isFile) f.length() else 0))
                    }
                }
                out.toString()
            } catch (_: Exception) { "[]" }
        }

        @JavascriptInterface fun readStorageFile(relativePath: String): String {
            if (!hasAllFilesAccess()) return ""
            return try {
                val base = Environment.getExternalStorageDirectory().canonicalFile
                val f = File(base, relativePath).canonicalFile
                if (!(f.path == base.path || f.path.startsWith(base.path + File.separator)) || !f.isFile || f.length() > 12L * 1024 * 1024) return ""
                val mime = when (f.extension.lowercase()) { "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "webp" -> "image/webp"; "gif" -> "image/gif"; else -> return "" }
                "data:$mime;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
            } catch (_: Exception) { "" }
        }

        // Saves exports directly into public Downloads. No extra save picker is needed.
        @JavascriptInterface fun saveFile(fileName: String, mimeType: String, base64Data: String) {
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "-").take(120).ifBlank { "fast-brander-export.bin" }
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "application/octet-stream" })
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Fast Brander")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Could not create download")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw Exception("Could not write download")
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                } else {
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Fast Brander")
                    if (!dir.exists()) dir.mkdirs()
                    FileOutputStream(File(dir, safeName)).use { it.write(bytes) }
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved to Downloads/Fast Brander/$safeName", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this@MainActivity, "Download failed: ${e.message}", Toast.LENGTH_LONG).show() } }
        }
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
