plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

dependencies { implementation("androidx.webkit:webkit:1.12.1") }

android {
    namespace = "com.fastbrander.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.fastbrander.app"; minSdk = 23; targetSdk = 35; versionCode = 12; versionName = "1.2.0" }
}
