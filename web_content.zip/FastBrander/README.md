# Fast Brander 1.1.0 — offline-first business document maker

Fast Brander is a no-sign-up, browser-based document maker. It uses HTML, CSS and plain JavaScript with no remote libraries, external fonts, cloud database, API keys or server-side account system. Version 1.2.0 builds on the recovered 1.0.2 project and keeps the same offline-first data model.

## Included features

- Separate company profiles on the same device; each profile has its own logo, contact details, TPIN, payment instructions, theme, currency, document numbering, customer list, catalog and saved documents.
- Company logo upload, optional tagline, contact details, website, TPIN and payment instructions.
- Company image library: upload multiple photos from the device gallery/files, capture a new image with the device camera where supported, and save/remove selected images.
- Separate signature and company-stamp uploads; these appear in the branded HTML/print document and in locally generated PDF/image exports when there is room in the final page layout.
- Document types: invoice, quotation, receipt, pro forma invoice, delivery note, purchase order and credit note.
- Automatic per-company, per-type document numbering, dates, references and quotation validity / due dates.
- Saved customer book; select a saved customer or type one-off recipient details.
- Reusable product/service catalog with category, SKU, description, unit, price, ZMW or USD currency, optional stock quantity and low-stock threshold.
- Import products/services and customers from CSV, TSV or JSON. Export catalog/customers to CSV. A CSV template and examples are in `sample-data/`.
- Line-item quantities, unit prices, line discounts, tax percentages, totals, payment received and balance for receipts.
- Color palette, custom accent color, black-and-white output, and modern/classic/minimal layouts.
- Live preview, save/edit/duplicate/delete, quotation-to-invoice conversion, print selected documents, native print / Save as PDF, local PDF export and PNG/JPEG export.
- Local JSON backup and restore for all company workspaces, including company logos, signatures, stamps and the image library.
- Browser save-location picker where supported, with normal Downloads fallback on browsers and Android WebViews that do not support it.
- Storage status panel showing IndexedDB availability, protected-storage status and estimated local storage use; request persistent storage from the browser where supported.
- Responsive phone/desktop layout; service-worker and manifest files included for PWA installation and offline app-shell caching.

## v1.2.0 priority upgrades

- Full Android Studio WebView host source is included under `android-wrapper/FastBranderAndroid/` (source project only; no APK is claimed).
- Android host requests the special all-files access permission when the user chooses it, exposes an in-app shared-storage browser for image selection, and saves generated documents directly into `Downloads/Fast Brander/`.
- Company logo, company details, optional signature and stamp are rendered into branded document previews and local PDF/PNG/JPEG exports. Each saved document uses its company snapshot so later company-profile edits do not silently rewrite old documents.
- Browser/PWA users still use standard file selection; unrestricted filesystem access is impossible from plain HTML in a normal browser.

## Quick start on Windows 11

### Option A — fastest test
1. Extract the ZIP file.
2. Open the `FastBrander` folder.
3. Double-click `index.html` (or right-click it and open with Chrome/Edge).
4. Complete the first company setup. Try creating a quotation, invoice or receipt.

Opening `index.html` directly is useful for a quick preview, but storage and downloads can vary in browsers or app wrappers using `file://`. For a more reliable offline setup with persistent app storage, use Option B or package the whole folder in a WebView wrapper with IndexedDB/local storage enabled. Service-worker installation is restricted to HTTPS or localhost in normal browser use.

### Option B — test the installable/offline PWA shell
1. Install Python 3 if it is not already on the PC.
2. Double-click `start-local.bat` inside this folder.
3. Open `http://localhost:8080` in Chrome or Edge.
4. Keep the local server running for the initial visit. After the page loads and the service worker installs, turn Wi-Fi off and refresh/test the app. Browser PWA installation is supported only in secure contexts such as HTTPS or localhost.

The app's core data and document generation do not call a server. File/media imports use the browser or Android system picker only after you choose a file. A normal website cannot silently read the phone's whole media gallery or filesystem. The local Python server only serves the files to the browser during testing. For an online hosted PWA, deploy the folder as static files over HTTPS.

## Turn the files into an Android app

Use an HTML-to-APK wrapper that packages a local website or creates a WebView app, and point it at this folder's `index.html` or package the complete folder. Keep `app.js`, `styles.css`, `manifest.webmanifest`, `sw.js` and `assets/` next to the HTML. The wrapper must allow JavaScript, local storage / IndexedDB, file input, downloads and the print/share intent if you want those functions in the APK. Feature support depends on the converter.

Test storage in the chosen wrapper before entering real records. Web storage is scoped to the app's origin; data in a browser, another origin or a newly installed APK is not automatically shared. Use **Settings & backup → Download backup JSON** and copy the backup into the new app if needed.

## Import format

CSV files need a header row. For the catalog, common headers such as `name`, `kind`, `description`, `category`, `sku`, `unit`, `price`, `currency`, `track_stock`, `stock_qty`, and `low_stock_at` are recognised. For customers, use `name`, `business`, `phone`, `email`, `address`, and `tpin`. JSON is also accepted as an array of objects. Excel workbooks should be exported as CSV before importing.

## Device media, storage and permissions

- On Android Chrome, tap **Company profiles → Add images** or **Upload logo / signature / stamp**. Android opens its file/photo picker. You can select one or more images from Photos, Gallery, Files or another provider shown by the phone.
- **Use camera** invokes the mobile browser camera capture control when the browser/device supports it. The app does not keep the camera open or capture in the background.
- The browser grants access only to the selected file(s). There is no request for unrestricted storage access, and the app does not need `MANAGE_EXTERNAL_STORAGE`, `READ_EXTERNAL_STORAGE` or `WRITE_EXTERNAL_STORAGE` for the picker-based flow.
- The **Settings & backup → Device media & storage access** panel checks browser capabilities and requests persistent web storage. The browser may approve or deny persistent storage; it is not a permission to browse all files.
- For Android, open the included `android-wrapper/FastBranderAndroid/` project in Android Studio. It implements WebView file chooser support, a native shared-storage browser, the Android all-files permission request and direct Downloads saving. See `android-wrapper/README.md` for policy and build instructions. The HTML app cannot add Android manifest permissions by itself.

## PDF and image output

- **Export PDF** produces a local A4-sized PDF. For maximum print sharpness and selectable text, the **Print / Save as PDF** route may be preferable because it uses the browser's print renderer.
- **Export PNG/JPEG** creates a high-resolution image; multi-page documents are combined into one tall image.
- For printing multiple documents, select them in Documents and choose **Print selected**.

## Storage and privacy

Records are stored in IndexedDB with a localStorage fallback. No login is required. There is no cloud sync, and the app does not upload company/customer data. Browser/app storage may be removed when the user clears site data, uninstalls an app or resets a device, so export backups regularly. A backup contains private company and customer information; store it securely.

## Verification

The package includes `TEST-REPORT.md` with source syntax/package checks and the previous 1.0.2 browser regression record. Android media picker, camera capture, save-location picker, WebView downloads and print behavior still require a manual check on the actual target phone/wrapper because they depend on its browser and WebView implementation.


## Version 1.0.1 update

This update improves logo selection, adds quick mobile navigation, strengthens file-download handling, and distinguishes catalog cost price from customer selling/unit price. See `CHANGELOG-v1.0.1.md`.


## Device files and permissions (v1.0.2)

Logo upload and imports use the device/browser file picker; exports use browser download/save behavior. The app asks the browser for persistent local storage where supported. No broad phone-storage permission is needed for a standard web/PWA installation. For an Android WebView APK, the wrapper must implement the native file chooser and download callbacks; see `ANDROID-WEBVIEW-FILE-ACCESS.md` for the required integration notes and a minimal manifest example.
