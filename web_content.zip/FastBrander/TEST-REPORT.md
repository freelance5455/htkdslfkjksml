# Fast Brander test report

Build: 1.0.0

## Automated checks run for this packaged version

- `node --check app.js` passed.
- Chromium browser test passed **26 of 26 checks** on the bundled build. Coverage included first-run company setup, logo upload, color and monochrome themes, preset accent color, catalog and customer create/import, ZMW and USD totals, line tax, automatic numbering, saved-document preview, quotation-to-invoice conversion, separate company data, backup export, local data persistence after reload, local PDF export, PNG and JPEG export, service-worker installation and a reload while offline.
- The locally generated PDF was validated with `pdfinfo` and rendered to a PNG for visual inspection. It was a valid one-page A4 PDF and the invoice layout, tables, totals and footer were aligned without overlap.
- Core assets were checked for remote runtime dependencies; no remote JavaScript libraries, web fonts or CSS imports are required.

## Manual checks recommended on the final target device

- Verify Android HTML-to-APK wrapper allows JavaScript, IndexedDB/localStorage, logo file picker, downloads/share, print dialog and storage persistence across closing/reopening the app.
- Check that the device has enough free storage for large logos, backups and long image exports.
- Verify a sample exported PDF prints at A4 size on the intended printer.

## Known boundaries

- Data is local to the current browser/app origin. It does not sync between devices.
- Product stock is a manual tracking field. Saving a document does not automatically decrement stock.
- Imports support CSV, TSV and JSON. Excel files (.xlsx) must be saved/exported as CSV first.
- PDFs exported with the one-file offline PDF writer are high-resolution image-based pages. Use browser Print / Save as PDF when selectable text or the browser's print layout is preferred.
- Business tax compliance, numbering requirements and TPIN obligations depend on local rules. Review document requirements for your business before using the app for official accounting records.
