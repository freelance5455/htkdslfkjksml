@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  echo Fast Brander local server: http://localhost:8080
  echo Keep this window open while testing the PWA. Press Ctrl+C to stop.
  py -m http.server 8080
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  echo Fast Brander local server: http://localhost:8080
  echo Keep this window open while testing the PWA. Press Ctrl+C to stop.
  python -m http.server 8080
  goto :eof
)
echo Python was not found. You can still open index.html directly, or install Python 3 to test PWA caching through localhost.
pause
