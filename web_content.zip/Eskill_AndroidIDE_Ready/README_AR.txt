مشروع eFootball Skills - نسخة مجهزة للاستيراد في AndroidIDE

المتطلبات: تطبيق AndroidIDE على هاتف Android واتصال إنترنت أثناء تنزيل أدوات البناء لأول مرة.

الخطوات:
1) فك ضغط Eskill_AndroidIDE_Ready.zip في مجلد يسهل الوصول إليه.
2) افتح AndroidIDE واختر Open Project ثم اختر مجلد Eskill_AndroidIDE_Ready (المجلد الذي يحتوي settings.gradle).
3) انتظر Gradle Sync وتنزيل المكونات المطلوبة.
4) من قائمة Build اختر Assemble Debug أو Build APK.
5) بعد نجاح البناء ستجد APK عادةً في app/build/outputs/apk/debug/app-debug.apk.
6) ثبّت APK على هاتفك.

التطبيق يحمل صفحة HTML من assets داخل APK ولا يحتاج اتصال إنترنت أثناء الاستخدام.
ملاحظة: تم تجهيز ملفات المشروع وتصحيح مراجع الأيقونة والثيم وإعدادات Gradle، لكن لم يتم تنفيذ بناء APK هنا؛ نجاح البناء يعتمد على توافق إصدار AndroidIDE وأدواته.
