# ഹാർമോണിയം ആപ്പ് — APK ഉണ്ടാക്കാൻ

ഫോൾഡർ ഘടന:
- `www/` — ആപ്പ് (index.html, offline ഫയൽ sw.js, ഐക്കണുകൾ)
- `package.json`, `capacitor.config.json` — രീതി B-ക്ക് മാത്രം

## രീതി A: എളുപ്പം (കമ്പ്യൂട്ടറിൽ ഒന്നും ഇൻസ്റ്റാൾ ചെയ്യേണ്ട)
1. https://app.netlify.com/drop തുറന്ന് `www` ഫോൾഡർ വലിച്ചിടുക. ഒരു https ലിങ്ക് കിട്ടും.
2. ആ ലിങ്ക് ഫോണിൽ Chrome-ൽ തുറന്നാൽ "Install app" വരും (ഓഫ്ലൈനും പ്രവർത്തിക്കും).
3. APK വേണമെങ്കിൽ https://www.pwabuilder.com തുറന്ന് ലിങ്ക് കൊടുക്കുക → Package for stores → Android → Generate. ഡൗൺലോഡ് സിപ്പിൽ APK ഉണ്ടാകും.
4. PWABuilder തരുന്ന signing key ഫയലും പാസ്വേഡും സൂക്ഷിച്ചുവയ്ക്കുക (പ്ലേ സ്റ്റോർ അപ്ഡേറ്റിന് വേണം).

## രീതി B: Android Studio ഉപയോഗിച്ച്
1. Node.js, Android Studio ഇൻസ്റ്റാൾ ചെയ്യുക.
2. ഈ ഫോൾഡറിൽ ടെർമിനൽ തുറന്ന്:
   ```
   npm install
   npx cap add android
   npx cap sync
   npx cap open android
   ```
3. Android Studio-യിൽ Build → Build APK(s). 
4. `capacitor.config.json`-ലെ `appId` (com.example.harmonium) നിങ്ങളുടെ സ്വന്തം പേരാക്കി മാറ്റുക (പ്ലേ സ്റ്റോറിന് വേണം).

## രീതി C: GitHub വഴി APK (കമ്പ്യൂട്ടറിൽ ഒന്നും ഇൻസ്റ്റാൾ ചെയ്യേണ്ട)
(ഈ ഫയൽ ഞാൻ പരീക്ഷിച്ചിട്ടില്ല; ആദ്യ ശ്രമത്തിൽ പിശക് വന്നാൽ Actions-ലെ ലോഗ് നോക്കുക.)
1. github.com-ൽ സൗജന്യ അക്കൗണ്ട് ഉണ്ടാക്കി പുതിയ repository ഉണ്ടാക്കുക.
2. ഈ ഫോൾഡറിലെ എല്ലാ ഫയലുകളും (www, package.json, capacitor.config.json) അപ്‌ലോഡ് ചെയ്യുക.
3. `.github/workflows/build-apk.yml` എന്ന പേരിൽ ഒരു പുതിയ ഫയൽ ഉണ്ടാക്കി (Add file → Create new file) അതിൽ `build-apk.yml`-ന്റെ ഉള്ളടക്കം ഒട്ടിക്കുക.
4. Actions ടാബ് → "Build APK" → Run workflow. 5–10 മിനിറ്റ് കഴിഞ്ഞ് പൂർത്തിയായ റണ്ണിൽ നിന്ന് `harmonium-apk` ഡൗൺലോഡ് ചെയ്യുക. അതിനുള്ളിൽ `app-debug.apk` ഉണ്ടാകും.
5. ഫോണിൽ APK തുറന്ന് "അജ്ഞാത ഉറവിടങ്ങളിൽ നിന്ന് ഇൻസ്റ്റാൾ" അനുവദിക്കുക.
