# Notices

**Empires — World at War** is an original game. No third-party code libraries are used.

- Coastline data: Natural Earth 1:50m land (naturalearthdata.com), public domain, simplified and stored in `js/landdata.js`.
- Flags (Old World scenario): national designs of c. 1936 redrawn in code (`js/flags.js`); designs carrying political emblems (e.g. Germany, Italy) are replaced by plain historical or neutral designs; coats of arms are simplified.
- Icons, UI, maps, rules, events and all other code and art: created for this project.
- Historical headlines are short, neutral summaries meant as flavour and do not claim to model history exactly.
