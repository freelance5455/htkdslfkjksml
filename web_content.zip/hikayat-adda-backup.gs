// نسخة احتياطية لتطبيق حكاية عدة على Gmail و Drive
var KEY = 'ضع-رمزاً-سرياً-هنا';   // غيّره ثم اكتب نفس الرمز داخل التطبيق
var FOLDER = 'نسخ حكاية عدة';
var KEEP = 30;           // عدد النسخ المحفوظة في Drive
var SEND_EMAIL = true;   // إرسال نسخة إلى بريدك مع كل رفع

function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function folder_() { var it = DriveApp.getFoldersByName(FOLDER); return it.hasNext() ? it.next() : DriveApp.createFolder(FOLDER); }

function doPost(e) {
  var d; try { d = JSON.parse(e.postData.contents); } catch (x) { return out_({ ok: false, error: 'bad' }); }
  if (d.key !== KEY) return out_({ ok: false, error: 'key' });
  var name = 'hikayat-adda-' + Utilities.formatDate(new Date(), 'Africa/Cairo', 'yyyy-MM-dd_HH-mm') + '.json';
  var blob = Utilities.newBlob(d.data, 'application/json', name);
  var f = folder_().createFile(blob);
  PropertiesService.getScriptProperties().setProperty('last', f.getId());
  if (SEND_EMAIL) MailApp.sendEmail({ to: Session.getEffectiveUser().getEmail(), subject: 'نسخة احتياطية - حكاية عدة - ' + name, body: 'مرفق نسخة بيانات التطبيق. للاسترجاع: من التطبيق اختر استرجاع آخر نسخة من الحساب، أو استعدها من ملف.', attachments: [blob] });
  var it = folder_().getFiles(), arr = [];
  while (it.hasNext()) arr.push(it.next());
  arr.sort(function (a, b) { return b.getDateCreated() - a.getDateCreated(); });
  for (var i = KEEP; i < arr.length; i++) arr[i].setTrashed(true);
  return out_({ ok: true, name: name });
}

function doGet(e) {
  if ((e.parameter.key || '') !== KEY) return out_({ ok: false, error: 'key' });
  if (e.parameter.action === 'update') {
    var it = DriveApp.getFilesByName('hikayat-adda-update.html'), best = null;
    while (it.hasNext()) { var g = it.next(); if (!best || g.getLastUpdated() > best.getLastUpdated()) best = g; }
    if (!best) return out_({ ok: false, error: 'noupdate' });
    return ContentService.createTextOutput(best.getBlob().getDataAsString()).setMimeType(ContentService.MimeType.TEXT);
  }
  var id = PropertiesService.getScriptProperties().getProperty('last');
  if (!id) return out_({ ok: false, error: 'empty' });
  var f = DriveApp.getFileById(id);
  if (e.parameter.action === 'meta') return out_({ ok: true, name: f.getName(), at: f.getDateCreated().getTime() });
  return ContentService.createTextOutput(f.getBlob().getDataAsString()).setMimeType(ContentService.MimeType.JSON);
}