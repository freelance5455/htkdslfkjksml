import { useState, useEffect, useRef } from 'react';
import { Play, Square, RotateCcw, Share2, Check, Server, Shield, Sparkles } from 'lucide-react';
import {
  GraphPoint,
  NetworkInfo,
  SpeedMetrics,
  TestConfig,
  TestPhase,
  TestResult,
} from './types/speedtest';
import { SERVERS, detectNetworkInfo } from './utils/networkInfo';
import { calculateQualityAssessment } from './utils/ratingEngine';
import { SpeedEngine } from './utils/speedEngine';
import {
  clearAllHistory,
  getStoredHistory,
  getStoredSettings,
  removeTestResult,
  saveStoredSettings,
  saveTestResult,
} from './utils/storage';
import { Header } from './components/Header';
import { Speedometer } from './components/Speedometer';
import { StageIndicator } from './components/StageIndicator';
import { MetricCards } from './components/MetricCards';
import { RealtimeGraph } from './components/RealtimeGraph';
import { QualityDashboard } from './components/QualityDashboard';
import { HistoryView } from './components/HistoryView';
import { SettingsModal } from './components/SettingsModal';

const INITIAL_METRICS: SpeedMetrics = {
  downloadSpeed: 0,
  uploadSpeed: 0,
  ping: 0,
  pingMin: 0,
  pingMax: 0,
  jitter: 0,
  packetLoss: 0,
  loadedPing: 0,
  downloadBytes: 0,
  uploadBytes: 0,
  downloadPeak: 0,
  uploadPeak: 0,
};

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('blazespeed_theme');
      if (savedTheme) return savedTheme === 'dark';
      return true; // Default to dark as shown in screenshot
    }
    return true;
  });

  // App navigation
  const [activeTab, setActiveTab] = useState<'test' | 'history' | 'insights'>('test');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // Speed test state
  const [phase, setPhase] = useState<TestPhase>('idle');
  const [metrics, setMetrics] = useState<SpeedMetrics>(INITIAL_METRICS);
  const [gaugeSpeed, setGaugeSpeed] = useState<number>(0);
  const [graphPoints, setGraphPoints] = useState<GraphPoint[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Persistence & environment
  const [history, setHistory] = useState<TestResult[]>([]);
  const [config, setConfig] = useState<TestConfig>(getStoredSettings());
  const [networkInfo, setNetworkInfo] = useState<NetworkInfo>({
    ip: 'Detecting...',
    isp: 'Detecting network...',
  });

  const speedEngineRef = useRef<SpeedEngine | null>(null);

  // Synchronize Dark Theme class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('blazespeed_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('blazespeed_theme', 'light');
    }
  }, [darkMode]);

  // Load history and network info on mount
  useEffect(() => {
    setHistory(getStoredHistory());
    detectNetworkInfo().then((info) => setNetworkInfo(info));
  }, []);

  // Update stored configuration
  const handleUpdateConfig = (newConfig: TestConfig) => {
    setConfig(newConfig);
    saveStoredSettings(newConfig);
  };

  // Start Speed Test
  const handleStartTest = () => {
    if (phase !== 'idle' && phase !== 'completed' && phase !== 'error') {
      // If currently running, acts as stop button
      handleStopTest();
      return;
    }

    setPhase('ping');
    setMetrics(INITIAL_METRICS);
    setGaugeSpeed(0);
    setGraphPoints([]);
    setErrorMessage(null);

    const engine = new SpeedEngine(config, {
      onPhaseChange: (newPhase) => {
        setPhase(newPhase);
      },
      onProgress: (partialMetrics, currentSpeed) => {
        setMetrics((prev) => ({ ...prev, ...partialMetrics }));
        setGaugeSpeed(currentSpeed);
      },
      onGraphPoint: (point) => {
        setGraphPoints((prev) => [...prev.slice(-120), point]);
      },
      onError: (msg) => {
        setErrorMessage(msg);
      },
      onComplete: (finalMetrics) => {
        setMetrics(finalMetrics);
        setGaugeSpeed(finalMetrics.downloadSpeed);

        // Haptic feedback if supported
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try {
            navigator.vibrate([40, 60, 40]);
          } catch {
            // Ignore
          }
        }

        // Calculate quality assessment
        const assessment = calculateQualityAssessment(finalMetrics);
        const activeServer = SERVERS.find((s) => s.id === config.serverId) || SERVERS[0];

        const newResult: TestResult = {
          id: `test_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          timestamp: Date.now(),
          metrics: finalMetrics,
          server: {
            name: activeServer.name,
            location: activeServer.location,
          },
          network: networkInfo,
          assessment,
          testDurationSeconds:
            config.testDurationMode === 'quick' ? 10 : config.testDurationMode === 'precision' ? 24 : 16,
        };

        const updatedHistory = saveTestResult(newResult);
        setHistory(updatedHistory);
      },
    });

    speedEngineRef.current = engine;
    engine.start();
  };

  const handleStopTest = () => {
    if (speedEngineRef.current) {
      speedEngineRef.current.stop();
      speedEngineRef.current = null;
    }
    setPhase('idle');
  };

  const handleClearHistory = () => {
    clearAllHistory();
    setHistory([]);
  };

  const handleDeleteResult = (id: string) => {
    const updated = removeTestResult(id);
    setHistory(updated);
  };

  const handleShareResults = async () => {
    const shareText = `🚀 BlazeSpeed Internet Test:
Download: ${metrics.downloadSpeed.toFixed(1)} ${config.unit}
Upload: ${metrics.uploadSpeed.toFixed(1)} ${config.unit}
Latency: ${metrics.ping.toFixed(0)} ms (Jitter: ${metrics.jitter.toFixed(1)} ms)
Loss: ${metrics.packetLoss.toFixed(1)}%
ISP: ${networkInfo.isp}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'BlazeSpeed Connection Test',
          text: shareText,
          url: window.location.href,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    } catch {
      // Ignore
    }
  };

  const currentAssessment = calculateQualityAssessment(metrics);
  const activeServer = SERVERS.find((s) => s.id === config.serverId) || SERVERS[0];
  const isTesting = phase === 'ping' || phase === 'download' || phase === 'upload';

  return (
    <div className="min-h-screen bg-[#0e0a08] dark:bg-[#0e0a08] light:bg-[#f8fafc] text-slate-100 dark:text-slate-100 light:text-slate-900 flex flex-col font-sans transition-colors duration-200">
      {/* Top Header Bar */}
      <Header
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenSettings={() => setIsSettingsOpen(true)}
        historyCount={history.length}
      />

      {/* Main View Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {/* TAB 1: MAIN SPEED TEST VIEW (Matching Screenshot Design) */}
        {activeTab === 'test' && (
          <div className="space-y-6">
            {/* Speedometer Gauge & Start Button Container */}
            <div className="flex flex-col items-center justify-center pt-2 pb-4">
              {/* Circular Gauge */}
              <Speedometer
                phase={phase}
                currentSpeed={gaugeSpeed}
                unit={config.unit}
              />

              {/* Start / Stop Test Button (Prominent peach/coral gradient from screenshot) */}
              <div className="w-full max-w-[360px] mt-4 px-2">
                <button
                  onClick={handleStartTest}
                  disabled={false}
                  className={`w-full py-4 px-6 rounded-2xl sm:rounded-full font-bold text-base transition-all duration-200 flex items-center justify-center gap-2.5 shadow-xl select-none ${
                    isTesting
                      ? 'bg-neutral-800 text-rose-400 hover:bg-neutral-700 hover:text-rose-300 border border-rose-500/30'
                      : 'bg-gradient-to-r from-[#FF7A50] via-[#FF6943] to-[#FF8C66] text-white hover:brightness-105 active:scale-[0.98] shadow-[#FF7A50]/20'
                  }`}
                >
                  {isTesting ? (
                    <>
                      <Square className="w-5 h-5 fill-current" />
                      <span>Stop test</span>
                    </>
                  ) : phase === 'completed' ? (
                    <>
                      <RotateCcw className="w-5 h-5" />
                      <span>Test again</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 fill-current" />
                      <span>Start test</span>
                    </>
                  )}
                </button>
              </div>

              {/* Phase Stage Indicators (• PING • DOWNLOAD • UPLOAD) */}
              <StageIndicator phase={phase} />

              {/* Error banner if network dropped */}
              {errorMessage && (
                <div className="mt-2 text-xs text-rose-400 bg-rose-500/10 border border-rose-500/30 px-3.5 py-2 rounded-xl text-center">
                  {errorMessage}
                </div>
              )}
            </div>

            {/* Results Cards (DOWNLOAD & UPLOAD + Latency, Jitter, Packet Loss) */}
            <MetricCards
              phase={phase}
              metrics={metrics}
              unit={config.unit}
              graphPoints={graphPoints}
            />

            {/* Live Real-Time Throughput Graph */}
            <RealtimeGraph
              phase={phase}
              points={graphPoints}
              unit={config.unit}
            />

            {/* Connection Rating & Non-Technical Quality Insights */}
            {(phase === 'completed' || metrics.downloadSpeed > 0) && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-orange-400" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-neutral-400">
                      Connection Experience Analysis
                    </h3>
                  </div>

                  <button
                    onClick={handleShareResults}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-100 hover:bg-[#261d19] border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 text-slate-700 dark:text-neutral-200 transition-colors"
                  >
                    {copiedShare ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Share Results</span>
                      </>
                    )}
                  </button>
                </div>

                <QualityDashboard assessment={currentAssessment} metrics={metrics} />
              </div>
            )}

            {/* Network & Active Server Information Footer Strip */}
            <div className="p-4 rounded-2xl bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5 text-slate-400 dark:text-neutral-400">
                <Shield className="w-4 h-4 text-emerald-500 shrink-0" />
                <div>
                  <span className="text-slate-500 dark:text-neutral-500">Provider: </span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {networkInfo.isp}
                  </span>
                  <span className="text-slate-500 dark:text-neutral-500 ml-2">({networkInfo.ip})</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-slate-400 dark:text-neutral-400">
                <Server className="w-4 h-4 text-orange-500 shrink-0" />
                <div>
                  <span className="text-slate-500 dark:text-neutral-500">Server: </span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {activeServer.name}
                  </span>
                  <span className="text-slate-500 dark:text-neutral-500 ml-1">
                    · {activeServer.location}
                  </span>
                </div>
                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="ml-2 text-orange-500 hover:underline font-semibold"
                >
                  Change
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LOCAL HISTORY VIEW */}
        {activeTab === 'history' && (
          <HistoryView
            history={history}
            onClearHistory={handleClearHistory}
            onDeleteResult={handleDeleteResult}
            onSelectResult={(item) => {
              setMetrics(item.metrics);
              setGaugeSpeed(item.metrics.downloadSpeed);
              setActiveTab('test');
            }}
            unit={config.unit}
          />
        )}
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onUpdateConfig={handleUpdateConfig}
        networkInfo={networkInfo}
      />

      {/* Quiet Footer */}
      <footer className="w-full max-w-4xl mx-auto py-6 px-4 sm:px-6 text-center text-xs text-slate-500 dark:text-neutral-600 border-t border-neutral-800/40 dark:border-neutral-800/40 light:border-slate-200">
        <p>BlazeSpeed · Lightweight, privacy-friendly browser speed tester</p>
      </footer>
    </div>
  );
}
