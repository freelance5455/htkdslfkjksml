export type TestPhase = 'idle' | 'ping' | 'download' | 'upload' | 'completed' | 'error';

export interface SpeedMetrics {
  downloadSpeed: number; // in Mbps
  uploadSpeed: number; // in Mbps
  ping: number; // in ms (average)
  pingMin: number; // in ms
  pingMax: number; // in ms
  jitter: number; // in ms
  packetLoss: number; // in percentage (0 - 100)
  loadedPing?: number; // ping under load (bufferbloat measure)
  downloadBytes: number;
  uploadBytes: number;
  downloadPeak?: number;
  uploadPeak?: number;
}

export interface GraphPoint {
  timestamp: number;
  speed: number;
  phase: 'download' | 'upload';
}

export interface QualityAssessment {
  overallGrade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  title: string;
  summary: string;
  gaming: {
    status: 'excellent' | 'good' | 'fair' | 'poor';
    label: string;
    details: string;
  };
  streaming: {
    status: 'excellent' | 'good' | 'fair' | 'poor';
    label: string;
    details: string;
  };
  conferencing: {
    status: 'excellent' | 'good' | 'fair' | 'poor';
    label: string;
    details: string;
  };
  browsing: {
    status: 'excellent' | 'good' | 'fair' | 'poor';
    label: string;
    details: string;
  };
}

export interface NetworkInfo {
  ip: string;
  isp: string;
  city?: string;
  country?: string;
  countryCode?: string;
  asn?: string;
}

export interface ServerOption {
  id: string;
  name: string;
  location: string;
  host: string;
  pingUrl: string;
  downloadUrl: string;
  uploadUrl: string;
}

export interface TestResult {
  id: string;
  timestamp: number;
  metrics: SpeedMetrics;
  server: {
    name: string;
    location: string;
  };
  network: NetworkInfo;
  assessment: QualityAssessment;
  testDurationSeconds: number;
}

export interface TestConfig {
  testDurationMode: 'quick' | 'standard' | 'precision'; // 5s, 10s, 15s per test
  unit: 'Mbps' | 'MBps';
  autoStartOnLoad: boolean;
  enableBufferbloatTest: boolean;
  serverId: string;
}
