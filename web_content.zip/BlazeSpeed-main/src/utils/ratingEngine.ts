import { QualityAssessment, SpeedMetrics } from '../types/speedtest';

export function calculateQualityAssessment(metrics: SpeedMetrics): QualityAssessment {
  const { downloadSpeed, uploadSpeed, ping, jitter, packetLoss } = metrics;

  // Gaming Assessment
  let gamingStatus: 'excellent' | 'good' | 'fair' | 'poor' = 'good';
  let gamingLabel = 'Good for Casual Gaming';
  let gamingDetails = 'Low latency suitable for online multiplayer.';

  if (ping <= 25 && jitter <= 5 && packetLoss === 0) {
    gamingStatus = 'excellent';
    gamingLabel = 'Pro Esports Ready';
    gamingDetails = `${ping.toFixed(0)}ms ping & ${jitter.toFixed(1)}ms jitter. Zero lag in fast-paced competitive FPS.`;
  } else if (ping <= 55 && jitter <= 12 && packetLoss <= 0.5) {
    gamingStatus = 'good';
    gamingLabel = 'Smooth Online Gaming';
    gamingDetails = `${ping.toFixed(0)}ms ping. Great response time for general multiplayer.`;
  } else if (ping <= 110 || jitter <= 25 || packetLoss <= 2) {
    gamingStatus = 'fair';
    gamingLabel = 'Moderate Latency';
    gamingDetails = 'Occasional hitches or delay possible in twitch shooters.';
  } else {
    gamingStatus = 'poor';
    gamingLabel = 'High Latency / Packet Loss';
    gamingDetails = 'Noticeable rubber-banding and delay expected during matches.';
  }

  // Streaming Assessment
  let streamingStatus: 'excellent' | 'good' | 'fair' | 'poor' = 'good';
  let streamingLabel = 'Full HD (1080p)';
  let streamingDetails = 'Smooth high-definition streaming on multiple screens.';

  if (downloadSpeed >= 50) {
    streamingStatus = 'excellent';
    streamingLabel = '4K UHD & 8K Ready';
    streamingDetails = `${downloadSpeed.toFixed(1)} Mbps comfortably streams multiple 4K/HDR streams simultaneously.`;
  } else if (downloadSpeed >= 25) {
    streamingStatus = 'excellent';
    streamingLabel = 'Single 4K Ultra HD';
    streamingDetails = 'Flawless single-screen 4K HDR playback with instant buffering.';
  } else if (downloadSpeed >= 12) {
    streamingStatus = 'good';
    streamingLabel = 'Crisp 1080p Full HD';
    streamingDetails = 'Reliable high-definition viewing with fast start times.';
  } else if (downloadSpeed >= 5) {
    streamingStatus = 'fair';
    streamingLabel = 'Standard HD (720p)';
    streamingDetails = 'Standard streaming. May take a few seconds to buffer.';
  } else {
    streamingStatus = 'poor';
    streamingLabel = 'Standard Definition';
    streamingDetails = 'Bandwidth is limited. Expect frequent buffering on high resolutions.';
  }

  // Conferencing Assessment (Zoom, Google Meet, Teams)
  let conferencingStatus: 'excellent' | 'good' | 'fair' | 'poor' = 'good';
  let conferencingLabel = 'HD Video Calls';
  let conferencingDetails = 'Crisp 1080p video meetings with clear voice.';

  if (uploadSpeed >= 10 && ping <= 60 && packetLoss === 0 && jitter <= 10) {
    conferencingStatus = 'excellent';
    conferencingLabel = 'Studio HD Multi-party';
    conferencingDetails = `${uploadSpeed.toFixed(1)} Mbps upload ensures crisp screen sharing and zero audio dropouts.`;
  } else if (uploadSpeed >= 3 && ping <= 100 && packetLoss <= 1) {
    conferencingStatus = 'good';
    conferencingLabel = 'HD Video Calls';
    conferencingDetails = 'Dependable two-way video calls and voice chats.';
  } else if (uploadSpeed >= 1 && ping <= 160) {
    conferencingStatus = 'fair';
    conferencingLabel = 'Basic Video / Audio Call';
    conferencingDetails = 'Video may downgrade resolution under background network activity.';
  } else {
    conferencingStatus = 'poor';
    conferencingLabel = 'Audio Only Recommended';
    conferencingDetails = 'Upload speed or packet loss may cause frozen camera or choppy voice.';
  }

  // Browsing Assessment
  let browsingStatus: 'excellent' | 'good' | 'fair' | 'poor' = 'good';
  let browsingLabel = 'Instant Loading';
  let browsingDetails = 'Websites and media load instantly without hesitation.';

  if (downloadSpeed >= 30 && ping <= 50) {
    browsingStatus = 'excellent';
    browsingLabel = 'Lightning Quick';
    browsingDetails = 'Webpages, heavy web apps, and rich media load in milliseconds.';
  } else if (downloadSpeed >= 10) {
    browsingStatus = 'good';
    browsingLabel = 'Fast Browsing';
    browsingDetails = 'Smooth navigation across modern websites and cloud portals.';
  } else if (downloadSpeed >= 3) {
    browsingStatus = 'fair';
    browsingLabel = 'Standard Browsing';
    browsingDetails = 'Noticeable pause when loading image-heavy pages.';
  } else {
    browsingStatus = 'poor';
    browsingLabel = 'Sluggish Browsing';
    browsingDetails = 'Slow page rendering and heavy media load times.';
  }

  // Calculate Overall Grade
  let overallGrade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F' = 'B';
  let title = 'Solid High-Speed Connection';
  let summary = 'Great connection capable of handling everyday work, streaming, and gaming.';

  const score =
    (downloadSpeed >= 200 ? 35 : downloadSpeed >= 100 ? 30 : downloadSpeed >= 50 ? 25 : downloadSpeed >= 20 ? 18 : 10) +
    (uploadSpeed >= 50 ? 30 : uploadSpeed >= 25 ? 25 : uploadSpeed >= 10 ? 20 : uploadSpeed >= 5 ? 12 : 5) +
    (ping <= 20 ? 20 : ping <= 45 ? 15 : ping <= 80 ? 10 : 5) +
    (jitter <= 5 ? 10 : jitter <= 15 ? 7 : 3) +
    (packetLoss === 0 ? 5 : packetLoss <= 1 ? 2 : 0);

  if (score >= 90) {
    overallGrade = 'A+';
    title = 'Exceptional Gigabit / Fiber Tier';
    summary = 'Top-tier performance with lightning-fast throughput and pristine latency.';
  } else if (score >= 75) {
    overallGrade = 'A';
    title = 'High-Performance Broadband';
    summary = 'Superb speeds for power users, 4K streaming, remote work, and gaming.';
  } else if (score >= 60) {
    overallGrade = 'B';
    title = 'Reliable Modern Broadband';
    summary = 'Comfortably supports multi-device households, streaming, and work.';
  } else if (score >= 45) {
    overallGrade = 'C';
    title = 'Standard Connection';
    summary = 'Adequate for routine web browsing and single-stream HD viewing.';
  } else if (score >= 30) {
    overallGrade = 'D';
    title = 'Below Average Connection';
    summary = 'May experience slowdowns when multiple devices or heavy downloads are active.';
  } else {
    overallGrade = 'F';
    title = 'Constrained Connection';
    summary = 'High latency or low bandwidth detected. Check your router or ISP connection.';
  }

  return {
    overallGrade,
    title,
    summary,
    gaming: { status: gamingStatus, label: gamingLabel, details: gamingDetails },
    streaming: { status: streamingStatus, label: streamingLabel, details: streamingDetails },
    conferencing: { status: conferencingStatus, label: conferencingLabel, details: conferencingDetails },
    browsing: { status: browsingStatus, label: browsingLabel, details: browsingDetails },
  };
}
