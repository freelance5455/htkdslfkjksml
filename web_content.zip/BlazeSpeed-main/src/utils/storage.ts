import { TestConfig, TestResult } from '../types/speedtest';

const HISTORY_KEY = 'blazespeed_test_history_v1';
const SETTINGS_KEY = 'blazespeed_settings_v1';

export const DEFAULT_CONFIG: TestConfig = {
  testDurationMode: 'standard',
  unit: 'Mbps',
  autoStartOnLoad: false,
  enableBufferbloatTest: true,
  serverId: 'cf-auto',
};

export function getStoredHistory(): TestResult[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveTestResult(result: TestResult): TestResult[] {
  try {
    const current = getStoredHistory();
    // Keep up to 100 most recent tests
    const updated = [result, ...current].slice(0, 100);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

export function removeTestResult(id: string): TestResult[] {
  try {
    const current = getStoredHistory();
    const updated = current.filter((item) => item.id !== id);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

export function clearAllHistory(): void {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch {
    // Ignore
  }
}

export function getStoredSettings(): TestConfig {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_CONFIG;
    return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveStoredSettings(config: TestConfig): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(config));
  } catch {
    // Ignore
  }
}

export function exportHistoryJSON(): void {
  const history = getStoredHistory();
  const blob = new Blob([JSON.stringify(history, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `blazespeed-history-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportHistoryCSV(): void {
  const history = getStoredHistory();
  if (history.length === 0) return;

  const headers = [
    'Date & Time',
    'Download (Mbps)',
    'Upload (Mbps)',
    'Ping (ms)',
    'Jitter (ms)',
    'Packet Loss (%)',
    'Grade',
    'Server',
    'ISP',
    'IP',
  ];

  const rows = history.map((item) => [
    new Date(item.timestamp).toLocaleString(),
    item.metrics.downloadSpeed.toFixed(2),
    item.metrics.uploadSpeed.toFixed(2),
    item.metrics.ping.toFixed(1),
    item.metrics.jitter.toFixed(2),
    item.metrics.packetLoss.toFixed(1),
    item.assessment.overallGrade,
    `"${item.server.name}"`,
    `"${item.network.isp}"`,
    item.network.ip,
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `blazespeed-history-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
