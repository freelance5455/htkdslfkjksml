import React, { useState } from 'react';
import { Gamepad2, Tv, Video, Globe, HelpCircle, ChevronDown, ChevronUp, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { QualityAssessment, SpeedMetrics } from '../types/speedtest';

interface QualityDashboardProps {
  assessment: QualityAssessment;
  metrics: SpeedMetrics;
}

export const QualityDashboard: React.FC<QualityDashboardProps> = ({
  assessment,
  metrics,
}) => {
  const [showExplanation, setShowExplanation] = useState(false);

  const getStatusIcon = (status: 'excellent' | 'good' | 'fair' | 'poor') => {
    switch (status) {
      case 'excellent':
      case 'good':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />;
      case 'fair':
        return <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'poor':
        return <XCircle className="w-4 h-4 text-rose-400 shrink-0" />;
    }
  };

  const getGradeBadge = (grade: string) => {
    switch (grade) {
      case 'A+':
      case 'A':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'B':
        return 'bg-sky-500/10 text-sky-400 border-sky-500/30';
      case 'C':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      default:
        return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
    }
  };

  const useCases = [
    {
      icon: <Gamepad2 className="w-5 h-5 text-indigo-400" />,
      title: 'Online Gaming',
      status: assessment.gaming.status,
      label: assessment.gaming.label,
      details: assessment.gaming.details,
    },
    {
      icon: <Tv className="w-5 h-5 text-orange-400" />,
      title: 'Video Streaming',
      status: assessment.streaming.status,
      label: assessment.streaming.label,
      details: assessment.streaming.details,
    },
    {
      icon: <Video className="w-5 h-5 text-cyan-400" />,
      title: 'Video Calls & Meetings',
      status: assessment.conferencing.status,
      label: assessment.conferencing.label,
      details: assessment.conferencing.details,
    },
    {
      icon: <Globe className="w-5 h-5 text-emerald-400" />,
      title: 'Web & Cloud Work',
      status: assessment.browsing.status,
      label: assessment.browsing.label,
      details: assessment.browsing.details,
    },
  ];

  return (
    <div className="w-full bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5">
      {/* Overall Score Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800/60 dark:border-neutral-800/60 light:border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-neutral-400">
              Connection Rating
            </span>
            <span
              className={`text-xs font-mono font-bold px-2 py-0.5 rounded-md border ${getGradeBadge(
                assessment.overallGrade
              )}`}
            >
              Grade {assessment.overallGrade}
            </span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
            {assessment.title}
          </h3>
          <p className="text-xs text-slate-500 dark:text-neutral-400 mt-1 max-w-xl">
            {assessment.summary}
          </p>
        </div>

        <button
          onClick={() => setShowExplanation(!showExplanation)}
          className="flex items-center gap-1.5 text-xs text-orange-500 dark:text-orange-400 hover:text-orange-600 transition-colors self-start sm:self-center"
        >
          <HelpCircle className="w-4 h-4" />
          <span>{showExplanation ? 'Hide Metrics Guide' : 'Explain My Metrics'}</span>
          {showExplanation ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* 4 Intuitive Use-Case Insight Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {useCases.map((uc) => (
          <div
            key={uc.title}
            className="p-3.5 rounded-xl bg-[#1f1815] dark:bg-[#1f1815] light:bg-slate-50 border border-neutral-800/60 dark:border-neutral-800/60 light:border-slate-200/80 flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-neutral-900/60 dark:bg-neutral-900/60 light:bg-white flex items-center justify-center">
                  {uc.icon}
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-900 dark:text-white">
                    {uc.title}
                  </h4>
                  <span className="text-[11px] font-medium text-slate-400 dark:text-neutral-400">
                    {uc.label}
                  </span>
                </div>
              </div>
              {getStatusIcon(uc.status)}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-neutral-400 leading-relaxed mt-1">
              {uc.details}
            </p>
          </div>
        ))}
      </div>

      {/* Educational Explanation Accordion */}
      {showExplanation && (
        <div className="p-4 rounded-xl bg-neutral-900/50 dark:bg-neutral-900/50 light:bg-slate-50 border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 text-xs space-y-3.5 animate-fadeIn">
          <h4 className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
            Understanding Your Internet Diagnostics
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-400 dark:text-neutral-400">
            <div>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 block mb-0.5">
                Download Speed ({metrics.downloadSpeed.toFixed(1)} Mbps)
              </span>
              How fast data travels from the web to your device. Determines how fast web pages load and video streams in 4K without stopping to buffer.
            </div>
            <div>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 block mb-0.5">
                Upload Speed ({metrics.uploadSpeed.toFixed(1)} Mbps)
              </span>
              How fast your device sends files and video to others. Crucial for video calls (Zoom/Teams), cloud backups, and sending emails with attachments.
            </div>
            <div>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 block mb-0.5">
                Latency / Ping ({metrics.ping.toFixed(0)} ms)
              </span>
              The reaction time of your connection. Under 30ms feels instantaneous; over 100ms causes noticeable lag in multiplayer gaming and voice chat.
            </div>
            <div>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 block mb-0.5">
                Jitter ({metrics.jitter.toFixed(1)} ms)
              </span>
              The consistency of your latency. High jitter means erratic ping spikes that cause stuttering in video calls and voice audio to crackle.
            </div>
            <div>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 block mb-0.5">
                Packet Loss ({metrics.packetLoss.toFixed(1)}%)
              </span>
              The percentage of data packets that get lost in transit. Should always be 0%. Any loss can cause websites to stall or calls to cut out.
            </div>
            <div>
              <span className="font-semibold text-slate-800 dark:text-neutral-200 block mb-0.5">
                Loaded Latency (Bufferbloat)
              </span>
              Measures if your router slows down or spikes ping when multiple people stream or download at the same time.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
