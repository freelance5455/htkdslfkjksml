import React from 'react';
import { Zap, Moon, Sun, Settings, History, Activity } from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  activeTab: 'test' | 'history' | 'insights';
  onSelectTab: (tab: 'test' | 'history' | 'insights') => void;
  onOpenSettings: () => void;
  historyCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  onToggleDarkMode,
  activeTab,
  onSelectTab,
  onOpenSettings,
  historyCount,
}) => {
  return (
    <header className="w-full flex items-center justify-between py-4 px-4 sm:px-6 max-w-4xl mx-auto border-b border-neutral-800/40 dark:border-neutral-800/40 light:border-slate-200">
      {/* Zone 1: Brand Wordmark (matching screenshot: Orange lightning bolt badge + BlazeSpeed) */}
      <div
        onClick={() => onSelectTab('test')}
        className="flex items-center gap-2.5 cursor-pointer select-none group"
      >
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
          <Zap className="w-5 h-5 fill-current" />
        </div>
        <div className="flex items-baseline">
          <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Blaze
          </span>
          <span className="text-xl font-extrabold tracking-tight text-orange-500">
            Speed
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links / Segmented View Selectors */}
      <nav className="flex items-center gap-1 sm:gap-2">
        <button
          onClick={() => onSelectTab('test')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'test'
              ? 'bg-[#251d19] dark:bg-[#251d19] light:bg-slate-100 text-orange-500 dark:text-orange-400 border border-orange-500/30'
              : 'text-slate-500 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Speed Test</span>
          <span className="sm:hidden">Test</span>
        </button>

        <button
          onClick={() => onSelectTab('history')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'history'
              ? 'bg-[#251d19] dark:bg-[#251d19] light:bg-slate-100 text-orange-500 dark:text-orange-400 border border-orange-500/30'
              : 'text-slate-500 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>History</span>
          {historyCount > 0 && (
            <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-neutral-800 text-neutral-300">
              {historyCount}
            </span>
          )}
        </button>
      </nav>

      {/* Zone 3: Settings & Dark Mode Toggle (matching screenshot rounded button) */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenSettings}
          className="p-2.5 rounded-xl border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 text-slate-500 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white hover:bg-neutral-800/40 dark:hover:bg-neutral-800/40 light:hover:bg-slate-100 transition-colors"
          title="Test Settings & Server Selection"
          aria-label="Settings"
        >
          <Settings className="w-4 h-4" />
        </button>

        <button
          onClick={onToggleDarkMode}
          className="p-2.5 rounded-xl border border-orange-500/30 dark:border-orange-500/30 light:border-slate-300 bg-[#1c1512]/50 dark:bg-[#1c1512]/50 light:bg-slate-100 text-orange-500 dark:text-orange-400 hover:border-orange-500/60 transition-colors shadow-sm"
          title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          aria-label="Toggle Dark Mode"
        >
          {darkMode ? <Moon className="w-4 h-4 fill-current/20" /> : <Sun className="w-4 h-4 fill-current/20 text-amber-500" />}
        </button>
      </div>
    </header>
  );
};
