import React, { useState } from 'react';
import { Download, Upload, Trash2, FileText, ArrowDown, ArrowUp, Activity, CheckCircle2, Search, X } from 'lucide-react';
import { TestResult } from '../types/speedtest';
import { exportHistoryCSV, exportHistoryJSON } from '../utils/storage';

interface HistoryViewProps {
  history: TestResult[];
  onClearHistory: () => void;
  onDeleteResult: (id: string) => void;
  onSelectResult?: (result: TestResult) => void;
  unit: 'Mbps' | 'MBps';
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  onClearHistory,
  onDeleteResult,
  onSelectResult,
  unit,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [selectedItem, setSelectedItem] = useState<TestResult | null>(null);

  // Filter history
  const filtered = history.filter((item) => {
    const query = searchQuery.toLowerCase();
    const dateStr = new Date(item.timestamp).toLocaleDateString().toLowerCase();
    const isp = item.network.isp.toLowerCase();
    const server = item.server.name.toLowerCase();
    return dateStr.includes(query) || isp.includes(query) || server.includes(query);
  });

  // Calculate summary metrics
  const avgDownload = history.length > 0
    ? history.reduce((sum, h) => sum + h.metrics.downloadSpeed, 0) / history.length
    : 0;
  const avgUpload = history.length > 0
    ? history.reduce((sum, h) => sum + h.metrics.uploadSpeed, 0) / history.length
    : 0;
  const bestPing = history.length > 0
    ? Math.min(...history.map((h) => h.metrics.ping))
    : 0;

  const formatSpeed = (val: number) => {
    const num = unit === 'MBps' ? val / 8 : val;
    return num.toFixed(2);
  };

  return (
    <div className="w-full space-y-5 animate-fadeIn">
      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200">
          <div className="text-xs text-slate-400 dark:text-neutral-400 font-medium">Tests Recorded</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
            {history.length}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200">
          <div className="text-xs text-slate-400 dark:text-neutral-400 font-medium">Avg Download</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-orange-500 dark:text-orange-400 mt-1">
            {avgDownload > 0 ? formatSpeed(avgDownload) : '—'} <span className="text-xs font-normal text-neutral-500">{unit}</span>
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200">
          <div className="text-xs text-slate-400 dark:text-neutral-400 font-medium">Avg Upload</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-cyan-500 dark:text-cyan-400 mt-1">
            {avgUpload > 0 ? formatSpeed(avgUpload) : '—'} <span className="text-xs font-normal text-neutral-500">{unit}</span>
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200">
          <div className="text-xs text-slate-400 dark:text-neutral-400 font-medium">Best Latency</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-500 dark:text-amber-400 mt-1">
            {bestPing > 0 ? bestPing.toFixed(0) : '—'} <span className="text-xs font-normal text-neutral-500">ms</span>
          </div>
        </div>
      </div>

      {/* Action Bar (Search & Export) */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by ISP or date..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-xl text-slate-900 dark:text-white placeholder-neutral-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {history.length > 0 && (
            <>
              <button
                onClick={exportHistoryCSV}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-neutral-200 bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-100 hover:bg-[#251d19] rounded-xl border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 transition-colors"
                title="Export as CSV"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
              <button
                onClick={exportHistoryJSON}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-neutral-200 bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-100 hover:bg-[#251d19] rounded-xl border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 transition-colors"
                title="Export as JSON"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>JSON</span>
              </button>
              <button
                onClick={() => setConfirmClear(true)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-rose-500 hover:bg-rose-500/10 rounded-xl border border-rose-500/30 transition-colors"
                title="Clear all results"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* History Table / Cards */}
      {filtered.length === 0 ? (
        <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-2xl p-8 text-center">
          <Activity className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
          <h4 className="text-sm font-semibold text-slate-900 dark:text-white">No Test Records Found</h4>
          <p className="text-xs text-slate-500 dark:text-neutral-400 mt-1 max-w-sm mx-auto">
            {history.length === 0
              ? 'Run your first speed test above. Your results, latency breakdown, and quality grade will be saved here automatically.'
              : 'No results match your search query.'}
          </p>
        </div>
      ) : (
        <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 bg-[#1a1411] dark:bg-[#1a1411] light:bg-slate-50 text-slate-500 dark:text-neutral-400">
                  <th className="py-3 px-4 font-semibold">Date & Time</th>
                  <th className="py-3 px-4 font-semibold text-right">Download</th>
                  <th className="py-3 px-4 font-semibold text-right">Upload</th>
                  <th className="py-3 px-4 font-semibold text-right">Ping / Jitter</th>
                  <th className="py-3 px-4 font-semibold text-center">Loss</th>
                  <th className="py-3 px-4 font-semibold text-center">Rating</th>
                  <th className="py-3 px-4 font-semibold">Provider / Server</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/40 dark:divide-neutral-800/40 light:divide-slate-100">
                {filtered.map((item) => (
                  <tr
                    key={item.id}
                    onClick={() => {
                      setSelectedItem(item);
                      if (onSelectResult) onSelectResult(item);
                    }}
                    className="hover:bg-neutral-800/20 dark:hover:bg-neutral-800/30 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4 whitespace-nowrap text-slate-700 dark:text-neutral-300">
                      {new Date(item.timestamp).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-orange-500 dark:text-orange-400 whitespace-nowrap">
                      {formatSpeed(item.metrics.downloadSpeed)} <span className="text-[10px] font-normal text-neutral-500">{unit}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-cyan-500 dark:text-cyan-400 whitespace-nowrap">
                      {formatSpeed(item.metrics.uploadSpeed)} <span className="text-[10px] font-normal text-neutral-500">{unit}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono whitespace-nowrap text-slate-700 dark:text-neutral-300">
                      {item.metrics.ping.toFixed(0)}ms <span className="text-neutral-500 text-[10px]">({item.metrics.jitter.toFixed(1)}ms)</span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono whitespace-nowrap">
                      <span className={item.metrics.packetLoss === 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {item.metrics.packetLoss.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-neutral-800 text-neutral-200">
                        {item.assessment.overallGrade}
                      </span>
                    </td>
                    <td className="py-3 px-4 max-w-[180px] truncate text-slate-500 dark:text-neutral-400">
                      <span className="font-medium text-slate-700 dark:text-neutral-300 block truncate">{item.network.isp}</span>
                      <span className="text-[10px] block truncate">{item.server.name}</span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onDeleteResult(item.id)}
                        className="p-1.5 text-neutral-500 hover:text-rose-400 transition-colors rounded-lg hover:bg-neutral-800"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Clear All */}
      {confirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-[#1c1512] dark:bg-[#1c1512] light:bg-white border border-neutral-800 rounded-2xl p-6 max-w-sm w-full space-y-4">
            <h4 className="font-bold text-slate-900 dark:text-white text-base">Clear Speed Test History?</h4>
            <p className="text-xs text-slate-400 dark:text-neutral-400">
              This will remove all {history.length} saved speed test measurements from this browser. This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmClear(false)}
                className="px-4 py-2 text-xs font-medium rounded-xl text-slate-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearHistory();
                  setConfirmClear(false);
                }}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition-colors"
              >
                Clear All
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Modal for Selected History Record */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800 rounded-2xl p-6 max-w-lg w-full space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Test Report · {new Date(selectedItem.timestamp).toLocaleDateString()}
                </h3>
                <span className="text-xs text-slate-400 dark:text-neutral-400">
                  {new Date(selectedItem.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 rounded-xl bg-[#201815] dark:bg-[#201815] light:bg-orange-50 border border-orange-500/30">
                <div className="text-[11px] font-semibold text-orange-400 uppercase">Download Speed</div>
                <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                  {formatSpeed(selectedItem.metrics.downloadSpeed)} {unit}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#141e22] dark:bg-[#141e22] light:bg-cyan-50 border border-cyan-500/30">
                <div className="text-[11px] font-semibold text-cyan-400 uppercase">Upload Speed</div>
                <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                  {formatSpeed(selectedItem.metrics.uploadSpeed)} {unit}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-lg bg-neutral-900/40 border border-neutral-800">
                <div className="text-neutral-400 text-[10px]">Ping</div>
                <div className="font-mono font-bold text-slate-200 mt-0.5">{selectedItem.metrics.ping.toFixed(1)} ms</div>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/40 border border-neutral-800">
                <div className="text-neutral-400 text-[10px]">Jitter</div>
                <div className="font-mono font-bold text-slate-200 mt-0.5">{selectedItem.metrics.jitter.toFixed(1)} ms</div>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/40 border border-neutral-800">
                <div className="text-neutral-400 text-[10px]">Packet Loss</div>
                <div className="font-mono font-bold text-slate-200 mt-0.5">{selectedItem.metrics.packetLoss.toFixed(1)}%</div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#201815] border border-neutral-800 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-neutral-400">ISP / Network:</span>
                <span className="font-semibold text-slate-200">{selectedItem.network.isp}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Server Node:</span>
                <span className="font-semibold text-slate-200">{selectedItem.server.name} ({selectedItem.server.location})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Overall Grade:</span>
                <span className="font-bold text-orange-400 font-mono">Grade {selectedItem.assessment.overallGrade}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedItem(null)}
              className="w-full py-2.5 text-xs font-semibold rounded-xl bg-orange-500 hover:bg-orange-600 text-white transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
