import React from 'react';
import { TestPhase } from '../types/speedtest';

interface SpeedometerProps {
  phase: TestPhase;
  currentSpeed: number;
  unit?: 'Mbps' | 'MBps';
  statusText?: string;
  subText?: string;
}

const TICKS = [
  { value: 0, label: '0' },
  { value: 10, label: '10' },
  { value: 50, label: '50' },
  { value: 100, label: '100' },
  { value: 500, label: '500' },
  { value: 1000, label: '1000' },
];

export const Speedometer: React.FC<SpeedometerProps> = ({
  phase,
  currentSpeed,
  unit = 'Mbps',
  statusText,
  subText,
}) => {
  // SVG geometry
  const size = 340;
  const cx = size / 2;
  const cy = size / 2 + 10;
  const radius = 135;
  const strokeWidth = 14;

  // Arc angles (in degrees): from 145° (bottom-left) to 395° (bottom-right) => total 250°
  const startAngle = 145;
  const totalSweep = 250;

  // Map speed to 0..1 using smooth piecewise logarithmic curve
  const speedToFraction = (speed: number): number => {
    if (speed <= 0) return 0;
    if (speed <= 10) return (speed / 10) * 0.18;
    if (speed <= 50) return 0.18 + ((speed - 10) / 40) * 0.22;
    if (speed <= 100) return 0.40 + ((speed - 50) / 50) * 0.20;
    if (speed <= 500) return 0.60 + ((speed - 100) / 400) * 0.22;
    return Math.min(1, 0.82 + ((speed - 500) / 500) * 0.18);
  };

  const progressFraction = speedToFraction(currentSpeed);

  // Circumference of the full circle & arc length
  const arcLength = (totalSweep / 360) * (2 * Math.PI * radius);
  const activeStrokeOffset = arcLength * (1 - progressFraction);

  // Polar to Cartesian converter
  const polarToCartesian = (angleDeg: number, r: number) => {
    const rad = (angleDeg * Math.PI) / 180;
    return {
      x: cx + r * Math.cos(rad),
      y: cy + r * Math.sin(rad),
    };
  };

  // Build SVG path for an arc
  const describeArc = (start: number, end: number, r: number) => {
    const p1 = polarToCartesian(start, r);
    const p2 = polarToCartesian(end, r);
    const largeArc = end - start <= 180 ? 0 : 1;
    return `M ${p1.x} ${p1.y} A ${r} ${r} 0 ${largeArc} 1 ${p2.x} ${p2.y}`;
  };

  const backgroundArcPath = describeArc(startAngle, startAngle + totalSweep, radius);

  // Needle angle in degrees
  const needleAngle = startAngle + progressFraction * totalSweep;
  const needleTip = polarToCartesian(needleAngle, radius - 6);
  const needleBase1 = polarToCartesian(needleAngle + 90, 8);
  const needleBase2 = polarToCartesian(needleAngle - 90, 8);

  // Status subtitle display
  const getDisplayStatus = () => {
    if (statusText) return statusText;
    switch (phase) {
      case 'idle':
        return 'READY';
      case 'ping':
        return 'TESTING PING';
      case 'download':
        return 'TESTING DOWNLOAD';
      case 'upload':
        return 'TESTING UPLOAD';
      case 'completed':
        return 'COMPLETED';
      case 'error':
        return 'ERROR';
    }
  };

  const getDisplaySubtext = () => {
    if (subText) return subText;
    switch (phase) {
      case 'idle':
        return 'Tap start to measure your connection';
      case 'ping':
        return 'Measuring latency & packet stability...';
      case 'download':
        return 'Receiving multi-stream test chunks...';
      case 'upload':
        return 'Sending outbound telemetry payloads...';
      case 'completed':
        return 'Test finished · Results saved locally';
      case 'error':
        return 'Check network connectivity and retry';
    }
  };

  const displaySpeedValue = unit === 'MBps' ? (currentSpeed / 8).toFixed(2) : currentSpeed.toFixed(2);

  return (
    <div className="relative flex flex-col items-center justify-center select-none w-full max-w-[380px] mx-auto">
      <svg
        viewBox={`0 0 ${size} ${size - 20}`}
        className="w-full h-auto overflow-visible"
        aria-hidden="true"
      >
        <defs>
          {/* Vibrant orange to coral gradient */}
          <linearGradient id="speedGaugeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#f97316" />
            <stop offset="40%" stopColor="#fb923c" />
            <stop offset="100%" stopColor="#ff7043" />
          </linearGradient>

          {/* Cyan gradient for upload phase */}
          <linearGradient id="uploadGaugeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#38bdf8" />
          </linearGradient>

          {/* Needle drop shadow */}
          <filter id="gaugeShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="2" stdDeviation="4" floodColor="#f97316" floodOpacity="0.4" />
          </filter>
        </defs>

        {/* Outer Background Arc Track */}
        <path
          d={backgroundArcPath}
          fill="none"
          stroke="currentColor"
          className="text-[#251e1b] dark:text-[#251e1b] light:text-slate-200 stroke-slate-200 dark:stroke-[#261f1c]"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />

        {/* Foreground Colored Active Arc */}
        <path
          d={backgroundArcPath}
          fill="none"
          stroke={phase === 'upload' ? 'url(#uploadGaugeGrad)' : 'url(#speedGaugeGrad)'}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={arcLength}
          strokeDashoffset={activeStrokeOffset}
          className="transition-all duration-150 ease-out"
        />

        {/* Gauge Tick Marks and Scale Numbers */}
        {TICKS.map((tick) => {
          const frac = speedToFraction(tick.value);
          const angle = startAngle + frac * totalSweep;
          const outerPoint = polarToCartesian(angle, radius + 15);
          const innerPoint = polarToCartesian(angle, radius + 22);
          const textPoint = polarToCartesian(angle, radius + 36);

          return (
            <g key={tick.value} className="select-none">
              <line
                x1={outerPoint.x}
                y1={outerPoint.y}
                x2={innerPoint.x}
                y2={innerPoint.y}
                stroke="currentColor"
                className="text-slate-400 dark:text-neutral-600"
                strokeWidth={2}
                strokeLinecap="round"
              />
              <text
                x={textPoint.x}
                y={textPoint.y + 3}
                textAnchor="middle"
                className="text-[11px] font-medium fill-slate-500 dark:fill-neutral-400 font-mono tracking-tight"
              >
                {tick.label}
              </text>
            </g>
          );
        })}

        {/* Needle Indicator */}
        {phase !== 'idle' && (
          <g className="transition-all duration-150 ease-out" filter="url(#gaugeShadow)">
            <polygon
              points={`${needleTip.x},${needleTip.y} ${needleBase1.x},${needleBase1.y} ${needleBase2.x},${needleBase2.y}`}
              fill={phase === 'upload' ? '#22d3ee' : '#ff7043'}
              opacity={0.9}
            />
            <circle
              cx={cx}
              cy={cy}
              r={7}
              fill={phase === 'upload' ? '#22d3ee' : '#ff7043'}
            />
            <circle
              cx={cx}
              cy={cy}
              r={3}
              fill="#ffffff"
            />
          </g>
        )}
      </svg>

      {/* Central Metrics & Status Display */}
      <div className="absolute top-[36%] flex flex-col items-center justify-center text-center px-4 pointer-events-none">
        {/* Status indicator (READY, TESTING PING, etc.) */}
        <span className="text-[12px] font-bold tracking-[0.2em] text-slate-400 dark:text-neutral-400 mb-1 transition-colors">
          {getDisplayStatus()}
        </span>

        {/* Large Speed Value */}
        <div className="flex items-baseline justify-center gap-1.5 leading-none my-0.5">
          <span className="text-5xl sm:text-6xl font-extrabold tracking-tight font-mono tabular-nums text-slate-900 dark:text-white">
            {displaySpeedValue}
          </span>
          <span className="text-sm font-semibold text-slate-500 dark:text-neutral-400">
            {unit}
          </span>
        </div>

        {/* Subtext description */}
        <span className="text-xs text-slate-500 dark:text-neutral-400 max-w-[220px] line-clamp-2 mt-2 leading-relaxed">
          {getDisplaySubtext()}
        </span>
      </div>
    </div>
  );
};
