import React from 'react';
import { X, Server, Clock, Sliders, Globe, Shield } from 'lucide-react';
import { NetworkInfo, TestConfig } from '../types/speedtest';
import { SERVERS } from '../utils/networkInfo';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: TestConfig;
  onUpdateConfig: (newConfig: TestConfig) => void;
  networkInfo: NetworkInfo;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  networkInfo,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800 rounded-3xl p-6 max-w-md w-full space-y-5 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-orange-500" />
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Test Configuration</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Server Selection */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-400 dark:text-neutral-400 flex items-center gap-1.5 uppercase tracking-wider">
            <Server className="w-3.5 h-3.5 text-orange-500" />
            <span>Test Server Location</span>
          </label>
          <div className="space-y-1.5">
            {SERVERS.map((server) => (
              <button
                key={server.id}
                onClick={() => onUpdateConfig({ ...config, serverId: server.id })}
                className={`w-full text-left p-3 rounded-xl border text-xs transition-all flex items-center justify-between ${
                  config.serverId === server.id
                    ? 'bg-orange-500/10 border-orange-500/50 text-orange-400'
                    : 'bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-50 border-neutral-800 hover:border-neutral-700 text-slate-300 dark:text-neutral-300'
                }`}
              >
                <div>
                  <div className="font-semibold">{server.name}</div>
                  <div className="text-[11px] text-neutral-500">{server.location}</div>
                </div>
                {config.serverId === server.id && (
                  <span className="w-2 h-2 rounded-full bg-orange-500" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Duration / Accuracy Mode */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-400 dark:text-neutral-400 flex items-center gap-1.5 uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5 text-orange-500" />
            <span>Test Accuracy & Duration</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { id: 'quick', label: 'Quick', desc: '5s / fast' },
                { id: 'standard', label: 'Standard', desc: '8s / balanced' },
                { id: 'precision', label: 'Precision', desc: '12s / deep' },
              ] as const
            ).map((mode) => (
              <button
                key={mode.id}
                onClick={() => onUpdateConfig({ ...config, testDurationMode: mode.id })}
                className={`p-2.5 rounded-xl border text-xs text-center transition-all ${
                  config.testDurationMode === mode.id
                    ? 'bg-orange-500/10 border-orange-500/50 text-orange-400 font-bold'
                    : 'bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-50 border-neutral-800 text-neutral-400'
                }`}
              >
                <div className="font-semibold">{mode.label}</div>
                <div className="text-[10px] text-neutral-500">{mode.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Speed Unit */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-400 dark:text-neutral-400 flex items-center gap-1.5 uppercase tracking-wider">
            <Sliders className="w-3.5 h-3.5 text-orange-500" />
            <span>Throughput Unit</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onUpdateConfig({ ...config, unit: 'Mbps' })}
              className={`p-2.5 rounded-xl border text-xs text-center transition-all ${
                config.unit === 'Mbps'
                  ? 'bg-orange-500/10 border-orange-500/50 text-orange-400 font-bold'
                  : 'bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-50 border-neutral-800 text-neutral-400'
              }`}
            >
              <div>Mbps (Megabits/sec)</div>
              <div className="text-[10px] text-neutral-500">Official ISP standard</div>
            </button>
            <button
              onClick={() => onUpdateConfig({ ...config, unit: 'MBps' })}
              className={`p-2.5 rounded-xl border text-xs text-center transition-all ${
                config.unit === 'MBps'
                  ? 'bg-orange-500/10 border-orange-500/50 text-orange-400 font-bold'
                  : 'bg-[#1e1714] dark:bg-[#1e1714] light:bg-slate-50 border-neutral-800 text-neutral-400'
              }`}
            >
              <div>MB/s (Megabytes/sec)</div>
              <div className="text-[10px] text-neutral-500">File download rate</div>
            </button>
          </div>
        </div>

        {/* Detected Network & ISP Diagnostics */}
        <div className="p-3.5 rounded-2xl bg-[#1f1714] border border-neutral-800 text-xs space-y-2">
          <div className="flex items-center gap-1.5 text-slate-300 font-semibold mb-1">
            <Globe className="w-3.5 h-3.5 text-orange-500" />
            <span>Connection Diagnostics</span>
          </div>
          <div className="flex items-center justify-between text-neutral-400">
            <span>Detected ISP:</span>
            <span className="font-medium text-slate-200">{networkInfo.isp}</span>
          </div>
          <div className="flex items-center justify-between text-neutral-400">
            <span>IP Address:</span>
            <span className="font-mono text-slate-200 flex items-center gap-1">
              <Shield className="w-3 h-3 text-emerald-400" />
              {networkInfo.ip}
            </span>
          </div>
          <div className="flex items-center justify-between text-neutral-400">
            <span>Location:</span>
            <span className="text-slate-200">
              {networkInfo.city ? `${networkInfo.city}, ` : ''}{networkInfo.country || 'Global'}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 text-xs font-bold rounded-2xl bg-orange-500 hover:bg-orange-600 text-white transition-colors shadow-lg shadow-orange-500/20"
        >
          Save & Close
        </button>
      </div>
    </div>
  );
};
