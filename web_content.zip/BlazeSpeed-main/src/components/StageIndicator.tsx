import React from 'react';
import { TestPhase } from '../types/speedtest';

interface StageIndicatorProps {
  phase: TestPhase;
}

export const StageIndicator: React.FC<StageIndicatorProps> = ({ phase }) => {
  const stages: { key: TestPhase; label: string; activeColor: string }[] = [
    { key: 'ping', label: 'PING', activeColor: 'text-amber-500 dark:text-amber-400' },
    { key: 'download', label: 'DOWNLOAD', activeColor: 'text-orange-500 dark:text-orange-400' },
    { key: 'upload', label: 'UPLOAD', activeColor: 'text-cyan-500 dark:text-cyan-400' },
  ];

  return (
    <div className="flex items-center justify-center gap-6 sm:gap-8 my-5 text-xs font-semibold tracking-widest select-none">
      {stages.map((stage) => {
        const isActive = phase === stage.key;
        const isPast =
          (stage.key === 'ping' && (phase === 'download' || phase === 'upload' || phase === 'completed')) ||
          (stage.key === 'download' && (phase === 'upload' || phase === 'completed')) ||
          (stage.key === 'upload' && phase === 'completed');

        return (
          <div
            key={stage.key}
            className={`flex items-center gap-2 transition-all duration-300 ${
              isActive
                ? `${stage.activeColor} scale-105 font-bold`
                : isPast
                ? 'text-slate-700 dark:text-neutral-300'
                : 'text-slate-400 dark:text-neutral-600'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                isActive
                  ? `ring-4 ring-orange-500/20 bg-orange-500 dark:bg-orange-400 scale-125 animate-pulse`
                  : isPast
                  ? 'bg-slate-400 dark:bg-neutral-400'
                  : 'bg-slate-300 dark:bg-neutral-700'
              }`}
            />
            <span>{stage.label}</span>
          </div>
        );
      })}
    </div>
  );
};
