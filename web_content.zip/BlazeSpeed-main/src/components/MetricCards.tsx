import React from 'react';
import { ArrowDown, ArrowUp, Activity, Shuffle, WifiOff, Gauge } from 'lucide-react';
import { GraphPoint, SpeedMetrics, TestPhase } from '../types/speedtest';

interface MetricCardsProps {
  phase: TestPhase;
  metrics: SpeedMetrics;
  unit: 'Mbps' | 'MBps';
  graphPoints: GraphPoint[];
}

export const MetricCards: React.FC<MetricCardsProps> = ({
  phase,
  metrics,
  unit,
  graphPoints,
}) => {
  const formatSpeed = (val: number) => {
    if (val <= 0) return '—';
    const num = unit === 'MBps' ? val / 8 : val;
    return num.toFixed(2);
  };

  const formatBytes = (bytes: number) => {
    if (bytes <= 0) return '';
    if (bytes >= 1_000_000_000) return `${(bytes / 1_000_000_000).toFixed(2)} GB`;
    return `${(bytes / 1_000_000).toFixed(1)} MB transferred`;
  };

  // Sparkline generator
  const renderSparkline = (targetPhase: 'download' | 'upload', strokeColor: string) => {
    const points = graphPoints.filter((p) => p.phase === targetPhase);
    if (points.length < 3) return null;

    const maxSpeed = Math.max(...points.map((p) => p.speed), 1);
    const width = 120;
    const height = 28;

    const coords = points.map((p, idx) => {
      const x = (idx / (points.length - 1)) * width;
      const y = height - (p.speed / maxSpeed) * (height - 4) - 2;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    return (
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-28 h-7 overflow-visible opacity-80"
        aria-hidden="true"
      >
        <polyline
          fill="none"
          stroke={strokeColor}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={coords.join(' ')}
        />
      </svg>
    );
  };

  const isDownloadActive = phase === 'download';
  const isDownloadDone = metrics.downloadSpeed > 0 || phase === 'upload' || phase === 'completed';

  const isUploadActive = phase === 'upload';
  const isUploadDone = metrics.uploadSpeed > 0 || phase === 'completed';

  return (
    <div className="w-full space-y-4">
      {/* Primary Download & Upload Cards (Matching Screenshot Layout) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* DOWNLOAD CARD */}
        <div
          className={`relative rounded-2xl p-5 transition-all duration-300 border ${
            isDownloadActive
              ? 'bg-[#1e1613] dark:bg-[#1e1613] light:bg-orange-50/70 border-orange-500/50 shadow-lg shadow-orange-500/10'
              : 'bg-[#181311] dark:bg-[#181311] light:bg-white border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200'
          }`}
        >
          {/* Subtle top edge accent glow */}
          <div
            className={`absolute top-0 left-6 right-6 h-[2px] rounded-full transition-opacity duration-300 ${
              isDownloadActive || isDownloadDone
                ? 'bg-gradient-to-r from-orange-500 via-amber-400 to-orange-400 opacity-90'
                : 'opacity-0'
            }`}
          />

          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-500">
                <ArrowDown className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-xs font-bold tracking-wider text-slate-400 dark:text-neutral-400 uppercase">
                Download
              </span>
            </div>

            {renderSparkline('download', '#f97316')}
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
              {formatSpeed(metrics.downloadSpeed)}
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-neutral-400">
              {unit}
            </span>
          </div>

          <div className="mt-2 text-xs text-slate-500 dark:text-neutral-400 flex items-center justify-between">
            <span>
              {isDownloadDone
                ? metrics.downloadPeak
                  ? `Peak: ${formatSpeed(metrics.downloadPeak)} ${unit}`
                  : 'Complete'
                : 'not measured yet'}
            </span>
            {metrics.downloadBytes > 0 && (
              <span className="font-mono text-[11px] opacity-80">
                {formatBytes(metrics.downloadBytes)}
              </span>
            )}
          </div>
        </div>

        {/* UPLOAD CARD */}
        <div
          className={`relative rounded-2xl p-5 transition-all duration-300 border ${
            isUploadActive
              ? 'bg-[#11191d] dark:bg-[#11191d] light:bg-cyan-50/70 border-cyan-500/50 shadow-lg shadow-cyan-500/10'
              : 'bg-[#181311] dark:bg-[#181311] light:bg-white border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200'
          }`}
        >
          {/* Subtle top edge accent glow */}
          <div
            className={`absolute top-0 left-6 right-6 h-[2px] rounded-full transition-opacity duration-300 ${
              isUploadActive || isUploadDone
                ? 'bg-gradient-to-r from-cyan-500 via-teal-400 to-sky-400 opacity-90'
                : 'opacity-0'
            }`}
          />

          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                <ArrowUp className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-xs font-bold tracking-wider text-slate-400 dark:text-neutral-400 uppercase">
                Upload
              </span>
            </div>

            {renderSparkline('upload', '#06b6d4')}
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
              {formatSpeed(metrics.uploadSpeed)}
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-neutral-400">
              {unit}
            </span>
          </div>

          <div className="mt-2 text-xs text-slate-500 dark:text-neutral-400 flex items-center justify-between">
            <span>
              {isUploadDone
                ? metrics.uploadPeak
                  ? `Peak: ${formatSpeed(metrics.uploadPeak)} ${unit}`
                  : 'Complete'
                : 'not measured yet'}
            </span>
            {metrics.uploadBytes > 0 && (
              <span className="font-mono text-[11px] opacity-80">
                {formatBytes(metrics.uploadBytes)}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Latency, Jitter, Packet Loss & Loaded Ping Section */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* LATENCY / PING CARD */}
        <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-neutral-400 text-xs font-medium mb-1">
            <Activity className="w-3.5 h-3.5 text-amber-500" />
            <span>Ping / Latency</span>
          </div>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
              {metrics.ping > 0 ? metrics.ping.toFixed(1) : '—'}
            </span>
            <span className="text-xs text-slate-500 dark:text-neutral-400">ms</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-neutral-500 truncate">
            {metrics.pingMin > 0 ? `Min ${metrics.pingMin.toFixed(0)} · Max ${metrics.pingMax.toFixed(0)}` : 'Idle latency'}
          </div>
        </div>

        {/* JITTER CARD */}
        <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-neutral-400 text-xs font-medium mb-1">
            <Shuffle className="w-3.5 h-3.5 text-indigo-400" />
            <span>Jitter</span>
          </div>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
              {metrics.jitter > 0 ? metrics.jitter.toFixed(1) : '—'}
            </span>
            <span className="text-xs text-slate-500 dark:text-neutral-400">ms</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-neutral-500 truncate">
            {metrics.jitter > 0
              ? metrics.jitter <= 5
                ? 'High stability'
                : metrics.jitter <= 15
                ? 'Normal variance'
                : 'Elevated variance'
              : 'Delay variation'}
          </div>
        </div>

        {/* PACKET LOSS CARD */}
        <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-neutral-400 text-xs font-medium mb-1">
            <WifiOff className="w-3.5 h-3.5 text-rose-500" />
            <span>Packet Loss</span>
          </div>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
              {metrics.ping > 0 ? metrics.packetLoss.toFixed(1) : '—'}
            </span>
            <span className="text-xs text-slate-500 dark:text-neutral-400">%</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-neutral-500 truncate">
            {metrics.ping > 0
              ? metrics.packetLoss === 0
                ? '0 dropped packets'
                : `${metrics.packetLoss.toFixed(1)}% dropped`
              : 'Reliability test'}
          </div>
        </div>

        {/* LOADED PING (BUFFERBLOAT) CARD */}
        <div className="bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-neutral-400 text-xs font-medium mb-1">
            <Gauge className="w-3.5 h-3.5 text-emerald-500" />
            <span>Under Load</span>
          </div>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
              {metrics.loadedPing && metrics.loadedPing > 0 ? metrics.loadedPing.toFixed(0) : '—'}
            </span>
            <span className="text-xs text-slate-500 dark:text-neutral-400">ms</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-neutral-500 truncate">
            {metrics.loadedPing && metrics.ping > 0
              ? `+${Math.max(0, metrics.loadedPing - metrics.ping).toFixed(0)}ms bufferbloat`
              : 'Loaded latency'}
          </div>
        </div>
      </div>
    </div>
  );
};
