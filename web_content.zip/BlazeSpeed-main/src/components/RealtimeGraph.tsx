import React from 'react';
import { GraphPoint, TestPhase } from '../types/speedtest';

interface RealtimeGraphProps {
  phase: TestPhase;
  points: GraphPoint[];
  unit: 'Mbps' | 'MBps';
}

export const RealtimeGraph: React.FC<RealtimeGraphProps> = ({
  phase,
  points,
  unit,
}) => {
  if (points.length < 2) {
    return (
      <div className="w-full bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-2xl p-4 flex flex-col items-center justify-center min-h-[160px] text-center">
        <span className="text-xs font-medium text-slate-400 dark:text-neutral-500">
          Live Bandwidth Graph
        </span>
        <span className="text-xs text-slate-500 dark:text-neutral-600 mt-1">
          Real-time throughput waveform will render here during the test
        </span>
      </div>
    );
  }

  // Find max speed for scaling
  const maxRawSpeed = Math.max(...points.map((p) => p.speed), 10);
  // Add 10% headroom
  const maxScale = Math.ceil(maxRawSpeed * 1.1);

  const width = 600;
  const height = 150;
  const paddingBottom = 24;
  const plotHeight = height - paddingBottom;

  const minTime = points[0].timestamp;
  const maxTime = Math.max(points[points.length - 1].timestamp, minTime + 1000);
  const timeSpan = maxTime - minTime;

  // Split into download and upload points
  const downloadPts = points.filter((p) => p.phase === 'download');
  const uploadPts = points.filter((p) => p.phase === 'upload');

  const buildPath = (subset: GraphPoint[]) => {
    if (subset.length < 2) return '';
    return subset
      .map((p, i) => {
        const x = ((p.timestamp - minTime) / timeSpan) * width;
        const y = plotHeight - (p.speed / maxScale) * (plotHeight - 8);
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const buildAreaPath = (subset: GraphPoint[]) => {
    if (subset.length < 2) return '';
    const linePath = buildPath(subset);
    const firstX = ((subset[0].timestamp - minTime) / timeSpan) * width;
    const lastX = ((subset[subset.length - 1].timestamp - minTime) / timeSpan) * width;
    return `${linePath} L ${lastX.toFixed(1)} ${plotHeight} L ${firstX.toFixed(1)} ${plotHeight} Z`;
  };

  const downloadLine = buildPath(downloadPts);
  const downloadArea = buildAreaPath(downloadPts);
  const uploadLine = buildPath(uploadPts);
  const uploadArea = buildAreaPath(uploadPts);

  const latestSpeed = points[points.length - 1].speed;
  const formattedLatest = unit === 'MBps' ? (latestSpeed / 8).toFixed(1) : latestSpeed.toFixed(1);

  return (
    <div className="w-full bg-[#181311] dark:bg-[#181311] light:bg-white border border-neutral-800/80 dark:border-neutral-800/80 light:border-slate-200 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-3">
          <span className="font-bold tracking-wider text-slate-400 dark:text-neutral-400 uppercase">
            Throughput Waveform
          </span>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5 text-orange-500 dark:text-orange-400">
              <span className="w-2 h-2 rounded-full bg-orange-500" />
              Download
            </span>
            <span className="flex items-center gap-1.5 text-cyan-500 dark:text-cyan-400">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              Upload
            </span>
          </div>
        </div>

        <div className="text-right">
          <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-white">
            {formattedLatest} {unit}
          </span>
          <span className="text-slate-500 dark:text-neutral-500 text-[11px] ml-1">
            {phase === 'completed' ? 'Final' : 'Current'}
          </span>
        </div>
      </div>

      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-32 sm:h-36 overflow-visible"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="dlAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f97316" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#f97316" stopOpacity="0.02" />
            </linearGradient>
            <linearGradient id="ulAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.02" />
            </linearGradient>
          </defs>

          {/* Horizontal grid lines */}
          <line
            x1="0"
            y1={plotHeight * 0.25}
            x2={width}
            y2={plotHeight * 0.25}
            stroke="currentColor"
            className="text-neutral-800/40 dark:text-neutral-800/60 light:text-slate-200"
            strokeDasharray="3 3"
          />
          <line
            x1="0"
            y1={plotHeight * 0.5}
            x2={width}
            y2={plotHeight * 0.5}
            stroke="currentColor"
            className="text-neutral-800/40 dark:text-neutral-800/60 light:text-slate-200"
            strokeDasharray="3 3"
          />
          <line
            x1="0"
            y1={plotHeight * 0.75}
            x2={width}
            y2={plotHeight * 0.75}
            stroke="currentColor"
            className="text-neutral-800/40 dark:text-neutral-800/60 light:text-slate-200"
            strokeDasharray="3 3"
          />
          <line
            x1="0"
            y1={plotHeight}
            x2={width}
            y2={plotHeight}
            stroke="currentColor"
            className="text-neutral-800/80 dark:text-neutral-800 light:text-slate-300"
          />

          {/* Download fill and line */}
          {downloadArea && <path d={downloadArea} fill="url(#dlAreaGrad)" />}
          {downloadLine && (
            <path
              d={downloadLine}
              fill="none"
              stroke="#f97316"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Upload fill and line */}
          {uploadArea && <path d={uploadArea} fill="url(#ulAreaGrad)" />}
          {uploadLine && (
            <path
              d={uploadLine}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Reference scale text */}
          <text
            x="4"
            y="12"
            className="text-[10px] font-mono fill-neutral-500"
          >
            {unit === 'MBps' ? (maxScale / 8).toFixed(0) : maxScale} {unit}
          </text>
          <text
            x="4"
            y={plotHeight - 4}
            className="text-[10px] font-mono fill-neutral-500"
          >
            0 {unit}
          </text>
        </svg>
      </div>
    </div>
  );
};
