package com.linguaai.loro;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.Manifest;import android.content.pm.PackageManager;
public class MainActivity extends Activity{
 WebView w;
 public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.setBackgroundColor(0xff090611);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.setWebChromeClient(new WebChromeClient(){public void onPermissionRequest(PermissionRequest r){r.grant(r.getResources());}});setContentView(w);w.loadUrl("file:///android_asset/index.html");}
 public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}