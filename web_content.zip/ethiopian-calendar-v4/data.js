/* ቀን መቁጠሪያ — data & calendar math. Developed by Bisrat Tadele */
const EM=[['መስከረም','Meskerem'],['ጥቅምት','Tikimt'],['ኅዳር','Hidar'],['ታኅሣሥ','Tahsas'],['ጥር','Tir'],['የካቲት','Yekatit'],['መጋቢት','Megabit'],['ሚያዝያ','Miazia'],['ግንቦት','Ginbot'],['ሰኔ','Sene'],['ሐምሌ','Hamle'],['ነሐሴ','Nehase'],['ጳጉሜ','Pagume']];
const GM=[['ጃንዋሪ','January'],['ፌብሩዋሪ','February'],['ማርች','March'],['ኤፕሪል','April'],['ሜይ','May'],['ጁን','June'],['ጁላይ','July'],['ኦገስት','August'],['ሴፕቴምበር','September'],['ኦክቶበር','October'],['ኖቬምበር','November'],['ዲሴምበር','December']];
const WD=[['እሑድ','Sunday'],['ሰኞ','Monday'],['ማክሰኞ','Tuesday'],['ረቡዕ','Wednesday'],['ሐሙስ','Thursday'],['ዓርብ','Friday'],['ቅዳሜ','Saturday']];
const WS=[['እሑ','Sun'],['ሰኞ','Mon'],['ማክ','Tue'],['ረቡ','Wed'],['ሐሙ','Thu'],['ዓር','Fri'],['ቅዳ','Sat']];

const geez=n=>{if(n<=0)return '0';if(n>=10000){const m=Math.floor(n/10000);return(m>1?geez(m):'')+'፼'+(n%10000?geez(n%10000):'')}if(n>=100){const h=Math.floor(n/100);return(h>1?geez(h):'')+'፻'+(n%100?geez(n%100):'')}return['','፲','፳','፴','፵','፶','፷','፸','፹','፺'][Math.floor(n/10)]+['','፩','፪','፫','፬','፭','፮','፯','፰','፱'][n%10]};
const jd=(y,m,d)=>Math.floor(Date.UTC(y,m-1,d)/864e5)+2440588, gd=j=>new Date((j-2440588)*864e5);
const toE=j=>{const r=(j-1723856)%1461,n=r%365+365*Math.floor(r/1460);return{y:4*Math.floor((j-1723856)/1461)+Math.floor(r/365)-Math.floor(r/1460),m:Math.floor(n/30)+1,d:n%30+1}};
const fromE=(y,m,d)=>1723856+365+365*(y-1)+Math.floor(y/4)+30*m+d-31;
const dim=(y,m)=>m<13?30:(y%4==3?6:5), wdOf=j=>(j+1)%7, gdim=(y,m)=>jd(m==12?y+1:y,m==12?1:m+1,1)-jd(y,m,1);
function easter(y){const a=y%4,b=y%7,c=y%19,d=(19*c+15)%30,e=(2*a+4*b-d+34)%7,s=d+e+114;return jd(y,Math.floor(s/31),s%31+1)+13}
function wEaster(y){const a=y%19,b=Math.floor(y/100),c=y%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451),s=h+l-7*m+114;return jd(y,Math.floor(s/31),s%31+1)}

/* holiday illustrations */
const IMG={newyear:'h_newyear',meskel:'h_meskel',genna:'h_genna',timket:'h_timket',fasika:'h_fasika',goodfriday:'h_fasika',adwa:'h_adwa',patriots:'h_adwa',fitr:'h_eid',adha:'h_eid',mawlid:'h_eid',ramadan:'h_eid'};
const SEASON=[ // by Ethiopian month
  null,
  ['s_tseday','ጸደይ','Tseday · Spring'],['s_tseday','ጸደይ','Tseday · Spring'],['s_tseday','ጸደይ','Tseday · Spring'],
  ['s_bega','በጋ','Bega · Dry season'],['s_bega','በጋ','Bega · Dry season'],['s_bega','በጋ','Bega · Dry season'],
  ['s_belg','በልግ','Belg · Short rains'],['s_belg','በልግ','Belg · Short rains'],['s_belg','በልግ','Belg · Short rains'],
  ['s_kiremt','ክረምት','Kiremt · Rainy season'],['s_kiremt','ክረምት','Kiremt · Rainy season'],['s_kiremt','ክረምት','Kiremt · Rainy season'],['s_kiremt','ክረምት','Kiremt · Rainy season']];

/* stories */
const STORY={
newyear:['እንቁጣጣሽ በመስከረም 1 የሚከበር የኢትዮጵያ አዲስ ዓመት ነው። ረጅሙ የክረምት ወቅት አብቅቶ ደጋው በአደይ አበባ ይደምቃል። ልጃገረዶች «አበባዮሽ» እያሉ ከቤት ቤት እየዞሩ ይዘፍናሉ፤ ልጆች ስዕል ይሰጣሉ፤ ቤተሰብም በአንድነት ተሰብስቦ አዲሱን ዓመት በተስፋ ይቀበላል።','Enkutatash is the Ethiopian New Year, celebrated on Meskerem 1 as the long rainy season ends and the highlands turn yellow with adey abeba daisies. Girls go door to door singing “Abebayehosh”, children hand out drawings, and families gather to welcome the year with hope.'],
meskel:['መስከረም 17 የሚከበረው መስቀል ንግሥት እሌኒ ቅዱስ መስቀሉን ያገኘችበት መታሰቢያ ነው። በዋዜማው ደመራ ተደምሮ በችቦ ይለኮሳል፤ የጢሱ አቅጣጫም ምልክት ተደርጎ ይታያል። በዓሉ በዩኔስኮ የማይዳሰስ የዓለም ቅርስ ሆኖ ተመዝግቧል።','Meskel (Meskerem 17) commemorates the finding of the True Cross by Empress Helena. On the eve, a towering Demera bonfire topped with a cross and daisies is lit with torches, and the direction of its smoke is read as a sign. It is inscribed by UNESCO as Intangible Cultural Heritage.'],
genna:['ገና የኢየሱስ ክርስቶስ ልደት በዓል ነው። ምእመናን የ43 ቀኑን የነቢያት ጾም ፈጽመው ነጭ ነጠላ ለብሰው ሌሊቱን በቤተ ክርስቲያን በቅዳሴ ያሳልፋሉ። ወጣቶችም በባህላዊው የገና ጨዋታ ይዝናናሉ።','Genna celebrates the birth of Christ. After the 43-day Fast of the Prophets, the faithful dress in white netela shawls and spend the night in church. Young people play the traditional game of genna, a kind of field hockey.'],
timket:['ጥምቀት የኢየሱስ ክርስቶስ በዮርዳኖስ ወንዝ መጠመቅን የሚዘክር በዓል ነው። በከተራ ዕለት ታቦታት በደማቅ ሥነ ሥርዓትና በያሬዳዊ ዝማሬ ወደ ጥምቀተ ባሕር ይወርዳሉ፤ በማለዳም ውኃው ተባርኮ ሕዝቡ ይረጫል። በዩኔስኮ የተመዘገበ ቅርስ ነው።','Timket celebrates the baptism of Christ in the Jordan. On Ketera, the eve, tabots are carried in colorful processions with chanting and embroidered umbrellas to a body of water; at dawn the water is blessed and sprinkled on the crowd. Timket is also UNESCO-inscribed.'],
fasika:['ፋሲካ (ትንሣኤ) የኢየሱስ ክርስቶስ ከሙታን የተነሣበት በዓል ነው። የ55 ቀኑን ዐቢይ ጾም ያስፈጽማል። ከሌሊቱ ቅዳሴ በኋላ ቤተሰብ በዶሮ ወጥና በደስታ ጾሙን ይፈታል።','Fasika, the Resurrection of Christ, ends the 55-day Great Lent (Abiy Tsom). After the long midnight service, families break the fast together with doro wat and joyful celebration.'],
goodfriday:['ስቅለት የኢየሱስ ክርስቶስ መሰቀል መታሰቢያ ነው። ምእመናን ቀኑን በጾም፣ በጸሎትና በስግደት ያሳልፋሉ።','Siklet (Good Friday) commemorates the crucifixion of Christ. The faithful spend the day fasting, praying and making prostrations.'],
adwa:['የካቲት 23 ቀን 1888 ዓ.ም በዳግማዊ ዐፄ ምኒልክና በእቴጌ ጣይቱ የተመራው የኢትዮጵያ ሠራዊት የጣልያንን ወራሪ ጦር በዓድዋ ድል አደረገ። ድሉ ለመላው አፍሪካና ለጥቁር ሕዝቦች የነጻነት ምልክት ሆኗል።','On 1 March 1896 (Yekatit 23, 1888 E.C.), Ethiopian forces led by Emperor Menelik II and Empress Taytu defeated the invading Italian army at Adwa. The victory became a lasting symbol of freedom for Africa and Black people worldwide.'],
patriots:['ሚያዝያ 27 ከአምስት ዓመት የፋሺስት ጣልያን ወረራ በኋላ በ1933 ዓ.ም በአርበኞች ተጋድሎ ነጻነት የተመለሰበትና ንጉሠ ነገሥቱ አዲስ አበባ የገቡበት ቀን ነው።','Patriots’ Victory Day (Miazia 27) marks 5 May 1941, when, after five years of Fascist Italian occupation and the resistance of the Arbegnoch (patriots), the Emperor returned to Addis Ababa.'],
derg:['ግንቦት 20 ቀን 1983 ዓ.ም የደርግ ሥርዓት የወደቀበት ቀን ነው።','Ginbot 20 marks 28 May 1991, the day the Derg regime fell.'],
labour:['ሚያዝያ 23 (ሜይ 1) የዓለም የሠራተኞች ቀን ነው።','International Workers’ Day, celebrated on 1 May.'],
fitr:['ኢድ አል-ፈጥር የረመዳን ወር ጾም ማብቂያ በዓል ነው። ሙስሊሞች በጋራ ሶላት፣ በምጽዋትና በቤተሰብ ግብዣ ያከብሩታል።','Eid al-Fitr marks the end of the month of Ramadan. Muslims celebrate with communal prayers, charity and family feasts.'],
adha:['ኢድ አል-አድሐ (አረፋ) የነቢዩ ኢብራሂምን ታዛዥነት የሚያስታውስ ሲሆን ከሐጅ ጉዞ ጋር ይገጣጠማል።','Eid al-Adha (Arefa) honors the devotion of the Prophet Ibrahim and coincides with the Hajj pilgrimage.'],
mawlid:['መውሊድ የነቢዩ ሙሐመድ ልደት በዓል ነው።','Mawlid celebrates the birthday of the Prophet Muhammad.'],
ramadan:['ከንጋት እስከ ፀሐይ መጥለቂያ የሚጾምበት የረመዳን ወር ይጀምራል።','Ramadan, the month of fasting from dawn to sunset, begins.'],
buhe:['ቡሄ (ደብረ ታቦር) የክርስቶስ መገለጥ በዓል ነው። ልጆች «ሆያ ሆዬ» እያሉ ይጨፍራሉ፤ ሙልሙል ዳቦ ይሰጣቸዋል፤ ችቦም ይበራል።','Buhe (Debre Tabor) celebrates the Transfiguration. Boys sing “Hoya Hoye” door to door and receive mulmul bread, and torches are lit at night.'],
tsion:['ኅዳር ጽዮን በአክሱም ጽዮን ማርያም በታላቅ ድምቀት የሚከበር በዓል ነው።','Hidar Tsion is celebrated with great devotion at the Church of Our Lady Mary of Zion in Axum.'],
nineveh:['ጾመ ነነዌ የሦስት ቀን ጾም ነው። የነነዌ ሰዎች በዮናስ ስብከት ንስሐ የገቡበትን ያስታውሳል።','The three-day Fast of Nineveh recalls the repentance of the people of Nineveh at the preaching of Jonah.'],
abiy:['ዐቢይ ጾም (ሁዳዴ) ለ55 ቀናት የሚቆይ ታላቁ ጾም ሲሆን በፋሲካ ይፈታል።','Abiy Tsom (Hudade), the Great Lent, lasts 55 days and ends at Fasika.'],
hosanna:['ሆሳዕና ክርስቶስ ወደ ኢየሩሳሌም በክብር የገባበት በዓል ነው። ምእመናን የዘንባባ ቅጠል ይዘው ይታያሉ።','Hosanna (Palm Sunday) marks Christ’s entry into Jerusalem; the faithful wear palm-leaf rings and crosses.'],
erget:['ዕርገት ክርስቶስ ከትንሣኤው በ40ኛው ቀን ወደ ሰማይ ያረገበት በዓል ነው።','Erget (Ascension) is celebrated on the 40th day after the Resurrection.'],
paraclete:['ጰራቅሊጦስ (በዓለ ኀምሳ) መንፈስ ቅዱስ በሐዋርያት ላይ የወረደበት ቀን ነው።','Paraclete (Pentecost) marks the descent of the Holy Spirit upon the apostles, 50 days after Easter.'],
debrezeit:['ደብረ ዘይት በዐቢይ ጾም አጋማሽ የሚከበር፣ ስለ ዳግም ምጽአት የሚዘከርበት ዕለት ነው።','Debre Zeit, in the middle of Great Lent, recalls Christ’s teaching on the Mount of Olives about the Second Coming.'],
xmas:['በምዕራቡ ዓለም አቆጣጠር የሚከበረው የገና በዓል።','Christmas as celebrated by Catholic and Protestant churches following the Gregorian calendar.'],
westeaster:['በምዕራቡ ዓለም አቆጣጠር የሚከበረው ፋሲካ።','Easter as celebrated by Catholic and Protestant churches.']
};

/* simple SVG emblems for holidays without illustrations */
const R=(n,f)=>Array.from({length:n},(_,i)=>f(i)).join(''),B=c=>`<rect width="64" height="64" fill="${c}"/>`;
const STAR=(f,tr)=>`<polygon points="32,10 36.7,23.5 51,23.8 39.6,32.5 43.8,46.2 32,38 20.2,46.2 24.4,32.5 13,23.8 27.3,23.5" fill="${f}" transform="${tr}"/>`;
const CRES=f=>`<path d="M42 12A20 20 0 1 0 42 52A16 16 0 1 1 42 12Z" fill="${f}"/>`;
const CROSS=(c,bg)=>B(bg)+`<path d="M32 10v44M20 22h24" stroke="${c}" stroke-width="5" stroke-linecap="round"/><circle cx="32" cy="22" r="4" fill="${c}"/>`;
const IC={
custom:B('#fde7ef')+'<path d="M32 11l6 12.2 13.4 2-9.7 9.4 2.3 13.3L32 41.6l-12 6.3 2.3-13.3-9.7-9.4 13.4-2z" fill="#e0457b"/><circle cx="50" cy="12" r="3" fill="#e9a100"/><circle cx="13" cy="50" r="2.5" fill="#078930"/><circle cx="52" cy="50" r="2" fill="#3b62d9"/>',
labour:B('#e4f3ea')+R(8,i=>`<rect x="29" y="7" width="6" height="10" rx="1.5" fill="#078930" transform="rotate(${i*45} 32 32)"/>`)+'<circle cx="32" cy="32" r="15" fill="#078930"/><circle cx="32" cy="32" r="6.5" fill="#e4f3ea"/>',
derg:B('#eeeef5')+'<rect x="7" y="21" width="27" height="15" rx="7.5" fill="none" stroke="#5b6078" stroke-width="5" transform="rotate(-22 20 28)"/><rect x="30" y="30" width="27" height="15" rx="7.5" fill="none" stroke="#da121a" stroke-width="5" transform="rotate(-22 43 37)"/>',
xmas:B('#e4f3ea')+'<path d="M32 12L45 29H37L48 43H16L27 29H19z" fill="#0f8a47"/><rect x="29" y="43" width="6" height="10" fill="#8a5a2b"/>'+STAR('#f2a900','translate(24 2) scale(.25)'),
westeaster:B('#f1eafb')+'<ellipse cx="32" cy="34" rx="16" ry="21" fill="#f7d3e4"/><path d="M17 30c5 4 10-4 15 0s10 4 15 0M17 40c5 4 10-4 15 0s10 4 15 0" stroke="#8e5bd0" stroke-width="3" fill="none"/>',
buhe:B('#fff3d6')+'<circle cx="32" cy="36" r="17" fill="#e8b25a"/><path d="M20 34c4-3 8 3 12 0s8 3 12 0" stroke="#a86b00" stroke-width="2.5" fill="none"/><path d="M32 6v10" stroke="#e8501b" stroke-width="4" stroke-linecap="round"/>',
tsion:CROSS('#a86b00','#fff0d2'),
nineveh:B('#dff0fb')+'<path d="M8 40c6-4 10 4 16 0s10 4 16 0 10 4 16 0" stroke="#2a8fd6" stroke-width="3.5" fill="none"/><path d="M14 30c8-10 28-10 36 0-8 6-28 6-36 0z" fill="#5b6078"/><circle cx="44" cy="29" r="2" fill="#fff"/>',
abiy:B('#e7f4e9')+'<path d="M32 54C16 44 14 24 32 10c18 14 16 34 0 44z" fill="#14955a"/><path d="M32 52V20" stroke="#e7f4e9" stroke-width="2.5"/>',
hosanna:B('#eaf5e0')+'<path d="M32 56V22" stroke="#4b8a1f" stroke-width="3"/>'+R(6,i=>`<path d="M32 ${24+i*5}c-8-2-14-6-16-12M32 ${24+i*5}c8-2 14-6 16-12" stroke="#6aab2e" stroke-width="2.5" fill="none" stroke-linecap="round"/>`),
erget:B('#e4e9ff')+'<path d="M10 50c8-6 36-6 44 0" stroke="#fff" stroke-width="8" stroke-linecap="round"/><path d="M32 44V12M22 22l10-10 10 10" stroke="#3b62d9" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
paraclete:B('#fff0d2')+'<path d="M16 34c6-10 26-10 32 0-4-2-8-1-10 2l-6 10-6-10c-2-3-6-4-10-2z" fill="#fff" stroke="#a86b00" stroke-width="2"/>'+R(3,i=>`<path d="M${24+i*8} 20c-3-4 0-8 0-10 3 3 4 6 0 10z" fill="#e8501b"/>`),
debrezeit:B('#efe9dc')+'<path d="M6 52l16-22 10 12 8-8 18 18z" fill="#6b8a3a"/><circle cx="46" cy="18" r="6" fill="#f2a900"/>',
generic:CROSS('#5b2f91','#f1e9fb')};

/* Ethiopian fixed holidays: [month, day, id, category, am, en, dayOff] */
const FXE=[[1,1,'newyear','nat','እንቁጣጣሽ (አዲስ ዓመት)','Enkutatash (Ethiopian New Year)',1],[1,17,'meskel','org','መስቀል','Meskel (Finding of the True Cross)',1],[3,21,'tsion','org','ኅዳር ጽዮን','Hidar Tsion (St. Mary of Zion)',0],[6,23,'adwa','nat','የዓድዋ ድል በዓል','Victory of Adwa',1],[8,27,'patriots','nat','የአርበኞች ቀን','Patriots’ Victory Day',1],[9,20,'derg','nat','ደርግ የወደቀበት ቀን','Downfall of the Derg',1],[12,13,'buhe','org','ቡሄ (ደብረ ታቦር)','Buhe (Transfiguration)',0]];
const CC={org:'#d98a00',nat:'#14955a',mus:'#0e9aa7',chr:'#8e5bd0',cus:'#e0457b'};
const cache={};
function evs(gy){if(cache[gy])return cache[gy];const M={},add=(j,id,c,am,en,off)=>(M[j]=M[j]||[]).push({id,c,am,en,off:!!off});
FXE.forEach(([m,d,id,c,am,en,o])=>[gy-8,gy-7].forEach(ey=>{const j=fromE(ey,m,d);if(gd(j).getUTCFullYear()==gy)add(j,id,c,am,en,o)}));
add(jd(gy,1,7),'genna','org','ገና (ልደት)','Genna (Ethiopian Christmas)',1);add(jd(gy,1,19),'timket','org','ጥምቀት','Timket (Epiphany)',1);
add(jd(gy,5,1),'labour','nat','የዓለም ሠራተኞች ቀን','International Labour Day',1);
const E=easter(gy);
add(E-69,'nineveh','org','ጾመ ነነዌ','Fast of Nineveh begins');add(E-55,'abiy','org','ዐቢይ ጾም ይጀምራል','Great Lent (Abiy Tsom) begins');add(E-28,'debrezeit','org','ደብረ ዘይት','Debre Zeit');add(E-7,'hosanna','org','ሆሳዕና','Hosanna (Palm Sunday)');
add(E-2,'goodfriday','org','ስቅለት','Good Friday (Siklet)',1);add(E,'fasika','org','ትንሣኤ (ፋሲካ)','Easter (Fasika)',1);add(E+39,'erget','org','ዕርገት','Ascension (Erget)');add(E+49,'paraclete','org','ጰራቅሊጦስ','Pentecost (Paraclete)');
const W=wEaster(gy);add(W-2,'goodfriday','chr','ስቅለት (ካቶሊክ/ፕሮቴስታንት)','Good Friday (Catholic/Protestant)');add(W,'westeaster','chr','ፋሲካ (ካቶሊክ/ፕሮቴስታንት)','Easter (Catholic/Protestant)');add(jd(gy,12,25),'xmas','chr','ክሪስማስ (ካቶሊክ/ፕሮቴስታንት)','Christmas (Catholic/Protestant)');
try{const f=new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{month:'numeric',day:'numeric',timeZone:'UTC'});
for(let j=jd(gy,1,1);j<=jd(gy,12,31);j++){const p=f.formatToParts(gd(j)),m=+p.find(x=>x.type=='month').value,d=+p.find(x=>x.type=='day').value;
if(m==9&&d==1)add(j,'ramadan','mus','ረመዳን ይጀምራል','Ramadan begins');if(m==10&&d==1)add(j,'fitr','mus','ኢድ አል-ፈጥር','Eid al-Fitr',1);if(m==12&&d==10)add(j,'adha','mus','ኢድ አል-አድሐ (አረፋ)','Eid al-Adha (Arefa)',1);if(m==3&&d==12)add(j,'mawlid','mus','መውሊድ','Mawlid (Prophet’s birthday)',1)}}catch(e){}
(typeof CUSTOM!='undefined'?CUSTOM:[]).forEach(x=>{try{if(x.t=='e')[gy-8,gy-7].forEach(ey=>{if(x.m==13&&x.d>dim(ey,13))return;const j=fromE(ey,x.m,x.d);if(gd(j).getUTCFullYear()==gy)add(j,x.id,x.c,x.am||x.en,x.en||x.am,x.off)});else if(!x.y||x.y==gy)add(jd(gy,x.m,x.d),x.id,x.c,x.am||x.en,x.en||x.am,x.off)}catch(e){}});
return cache[gy]=M}
const clearCache=()=>{for(const k in cache)delete cache[k]};
const hol=j=>evs(gd(j).getUTCFullYear())[j]||[];

/* Orthodox fasting guide */
function fastOf(j){const gy=gd(j).getUTCFullYear(),E=easter(gy),e=toE(j),w=wdOf(j);
 if(j>=E-55&&j<E)return['ዐቢይ ጾም','Great Lent'];
 if(j>=E-69&&j<=E-67)return['ጾመ ነነዌ','Fast of Nineveh'];
 const hw=fromE(toE(E).y,11,4);if(j>=E+50&&j<=hw)return['ጾመ ሐዋርያት','Fast of the Apostles'];
 if(e.m==12&&e.d<=14)return['ጾመ ፍልሰታ','Fast of the Assumption (Filseta)'];
 if((e.m==3&&e.d>=15)||(e.m==4&&e.d<=28))return['ጾመ ነቢያት','Fast of the Prophets (Advent)'];
 if(j==jd(gy,1,18))return['ገሀድ','Gahad (Timket eve)'];
 if(w==3||w==5){const E0=easter(gy);if(j>E0&&j<=E0+49)return null;if(j>=jd(gy,1,7)&&j<=jd(gy,1,19))return null;return w==3?['የረቡዕ ጾም','Wednesday fast']:['የዓርብ ጾም','Friday fast']}
 return null}
const SAINT={5:['አቦ (ገብረ መንፈስ ቅዱስ)','Abo (Gebre Menfes Kidus)'],7:['ሥላሴ','Holy Trinity (Selassie)'],12:['ቅዱስ ሚካኤል','St. Michael'],16:['ኪዳነ ምሕረት','Kidane Mihret'],19:['ቅዱስ ገብርኤል','St. Gabriel'],21:['ማርያም','St. Mary'],23:['ቅዱስ ጊዮርጊስ','St. George'],27:['መድኃኔ ዓለም','Medhane Alem'],29:['ባለ ወልድ','Bale Wold']};
const saintOf=j=>{const e=toE(j);return e.m<13?SAINT[e.d]:null};
const EVANG=[['ዮሐንስ','John'],['ማቴዎስ','Matthew'],['ማርቆስ','Mark'],['ሉቃስ','Luke']];

/* Amharic proverbs */
const PROV=[
['ድር ቢያብር አንበሳ ያስር።','When spider webs unite, they can tie up a lion.'],
['ቀስ በቀስ እንቁላል በእግሩ ይሄዳል።','Little by little, an egg will walk on its own legs.'],
['አንድ እጅ አያጨበጭብም።','One hand cannot clap.'],
['ዝምታ ወርቅ ነው።','Silence is golden.'],
['የቸኮለ አፍሶ ለቀመ።','The one who hurried spilled it and had to pick it up again.'],
['ሲሮጡ የታጠቁት ሲሮጡ ይፈታል።','What you tie on while running comes loose while running.'],
['ጉልቻ ቢለዋወጥ ወጥ አያጣፍጥም።','Changing the hearthstones won’t make the stew any tastier.'],
['አባይን ያላየ ምንጭ ያመሰግናል።','One who has never seen the Nile praises a spring.'],
['ጅብ ከሄደ ውሻ ጮኸ።','The dog barked after the hyena had gone.'],
['የእግር እንቅፋት ከምላስ እንቅፋት ይሻላል።','Better a stumble of the foot than a slip of the tongue.'],
['ሆድ ያባውን ብቅል ያወጣዋል።','What the heart hides, the drink reveals.'],
['ውሃ ሲወስድ እያሳሳቀ ነው።','When the river carries you away, it does so smiling.'],
['የሰው ወርቅ አያደምቅ።','Borrowed gold does not shine.'],
['ሰው ለሰው መድኃኒቱ ነው።','People are medicine for one another.'],
['ዕውቀት ኃይል ነው።','Knowledge is power.'],
['ትዕግስት መራራ ናት፤ ፍሬዋ ግን ጣፋጭ ነው።','Patience is bitter, but its fruit is sweet.']];
