set -e
SDK=/home/user/android/sdk; BT=$SDK/build-tools/34.0.0; AJ=$SDK/platforms/android-34/android.jar
cd /home/user/apk; rm -rf out && mkdir -p out/obj out/res assets
rm -rf assets/www && mkdir -p assets/www && cp -r /home/user/workspace/app/* assets/www/ && rm -f assets/www/README.txt
$BT/aapt2 compile --dir res -o out/res/res.zip
$BT/aapt2 link -o out/base.apk -I $AJ --manifest AndroidManifest.xml -A assets out/res/res.zip --java out/gen --min-sdk-version 24 --target-sdk-version 34 --version-code 42 --version-name 4.2 -0 webp -0 woff2 -0 png
javac -source 8 -target 8 -bootclasspath $AJ -classpath $AJ:$BT/core-lambda-stubs.jar -d out/obj $(find src out/gen -name '*.java') 2>&1 | grep -v "warning\|bootstrap" || true
$BT/d8 --release --min-api 24 --lib $AJ --output out $(find out/obj -name '*.class')
cd out && cp base.apk unsigned.apk && zip -q -j unsigned.apk classes.dex && cd ..
$BT/zipalign -f -p 4 out/unsigned.apk out/aligned.apk
[ -f /home/user/workspace/ethcal-release.jks ] || keytool -genkeypair -keystore /home/user/workspace/ethcal-release.jks -alias ethcal -keyalg RSA -keysize 2048 -validity 10000 -storepass Bsre0911ethcal -keypass Bsre0911ethcal -dname "CN=Bisrat Tadele, O=Bisrat Tadele, C=ET" >/dev/null 2>&1
$BT/apksigner sign --ks /home/user/workspace/ethcal-release.jks --ks-pass pass:Bsre0911ethcal --key-pass pass:Bsre0911ethcal --out /home/user/workspace/Ethiopian-Calendar-v4.2.apk out/aligned.apk
$BT/apksigner verify --print-certs /home/user/workspace/Ethiopian-Calendar-v4.2.apk | head -2
ls -la /home/user/workspace/Ethiopian-Calendar-v4.2.apk
