/* ቀን መቁጠሪያ v4 — UI. Developed by Bisrat Tadele · የተሰራው ብስራት ታደለ */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const sv=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}},ld=k=>{try{return localStorage.getItem(k)}catch(e){return null}},rm=k=>{try{localStorage.removeItem(k)}catch(e){}};
let L=ld('l')||'am',GZ=ld('g')==='1',WK=+(ld('wk')||0),TH=ld('th')||'auto',AC=ld('ac')||'saffron',SF=ld('sf')!=='0',SS=ld('ss')!=='0',HP=ld('hp')!=='0';
let EV=[];try{EV=JSON.parse(ld('ev')||'[]')}catch(e){}
/* admin-controlled config (see admin.js) */
const ADM_D={ttl:['',''],sub:['',''],ann:{on:0,am:'',en:'',c:'ac',v:1},tabs:{hol:1,tl:1,ev:1},sec:{cd:1,mycd:1,tags:1,week:1,stats:1,prov:1,up:1},cf:1,srch:1,share:1,lock:0,spl:2800,pv:'',pvOnly:0,acc:''};
let ADM=JSON.parse(JSON.stringify(ADM_D));try{const o=JSON.parse(ld('adm')||'{}');for(const k in o)ADM[k]=o[k]&&typeof o[k]=='object'&&!Array.isArray(o[k])?{...ADM_D[k],...o[k]}:o[k]}catch(e){}
let CUSTOM=[];try{CUSTOM=JSON.parse(ld('cev')||'[]')}catch(e){}
let NF=ld('nf')=='1';
const SEC=k=>ADM.sec[k]!==0,TTL=()=>A(ADM.ttl[0]||'ቀን መቁጠሪያ',ADM.ttl[1]||'Ethiopian Calendar'),TSUB=()=>A(ADM.sub[0]||'ኢትዮጵያዊ እና ግሪጎሪያን',ADM.sub[1]||'Ethiopian & Gregorian');
const A=(a,e)=>L=='am'?a:e,n2=a=>a[L=='am'?0:1],nm=n=>GZ?geez(n):n;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const buzz=(ms=8)=>{if(HP&&navigator.vibrate)try{navigator.vibrate(ms)}catch(e){}};

/* icons */
const P={
home:'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
cal:'<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>',
party:'<path d="M5.8 11.3 2 22l10.7-3.8"/><path d="M4 3h.01M22 8h.01M15 2h.01M22 20h.01"/><path d="m22 2-2.2.8a3 3 0 0 0-1.9 3.3 1.5 1.5 0 0 1-1.6 1.7l-.5-.1a2 2 0 0 0-2.3 1.9"/><path d="M11 13c1.9 1.9 2.8 4.2 2 5-.8.8-3.1-.1-5-2s-2.8-4.2-2-5c.8-.8 3.1.1 5 2z"/>',
calc:'<rect x="4" y="2" width="16" height="20" rx="3"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h.01M16 19h.01"/>',
note:'<path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4"/><path d="M2 6h4M2 10h4M2 14h4M2 18h4"/><path d="M18.4 2.6a2.1 2.1 0 1 1 3 3L16 11l-4 1 1-4Z"/>',
set:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
search:'<circle cx="11" cy="11" r="7.5"/><path d="m20.5 20.5-4.2-4.2"/>',
l:'<path d="m15 18-6-6 6-6"/>',r:'<path d="m9 18 6-6-6-6"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4"/>',
moon:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
globe:'<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
share:'<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="m16 6-4-4-4 4M12 2v13"/>',
plus:'<path d="M12 5v14M5 12h14"/>',x:'<path d="M18 6 6 18M6 6l12 12"/>',
trash:'<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
cake:'<path d="M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8M4 16s.5-1 2-1 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-1 2-1M2 21h20M7 8v3M12 8v3M17 8v3M7 4h.01M12 4h.01M17 4h.01"/>',
bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
heart:'<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/>',
star:'<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.2-6.2 3.2L7 14.2 2 9.3l6.9-1z"/>',
dl:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',ul:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
leaf:'<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10Z"/><path d="M2 21c0-3 1.9-5.4 5.1-6C9.5 14.5 12 13 13 12"/>',
cross:'<path d="M12 2v20M6 8h12"/>',grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
quote:'<path d="M3 21c3 0 7-1 7-8V5c0-1.3-.8-2-2-2H4c-1.3 0-2 .8-2 2v6c0 1.3.8 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 0-1 1v3c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.3-.8-2-2-2h-4c-1.3 0-2 .8-2 2v6c0 1.3.8 2 2 2h.8c0 2.3.2 4-2.8 4v3c0 1 0 1 1 1z"/>',
swap:'<path d="m16 3 4 4-4 4M20 7H4M8 21l-4-4 4-4M4 17h16"/>',hour:'<path d="M5 22h14M5 2h14M17 22v-4.2a2 2 0 0 0-.6-1.4L12 12l-4.4 4.4a2 2 0 0 0-.6 1.4V22M7 2v4.2a2 2 0 0 0 .6 1.4L12 12l4.4-4.4a2 2 0 0 0 .6-1.4V2"/>',
hash:'<path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/>',check:'<path d="M20 6 9 17l-5-5"/>',
palette:'<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.7-.8 1.7-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.5-.7-.5-1.1a1.6 1.6 0 0 1 1.7-1.7h2c3 0 5.6-2.5 5.6-5.6C22 6 17.5 2 12 2z"/>',
info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',book:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
repeat:'<path d="m17 2 4 4-4 4M3 11v-1a4 4 0 0 1 4-4h14M7 22l-4-4 4-4M21 13v1a4 4 0 0 1-4 4H3"/>',
phone:'<rect x="5" y="2" width="14" height="20" rx="3"/><path d="M12 18h.01"/>',vib:'<rect x="7" y="4" width="10" height="16" rx="2"/><path d="M3 8v8M21 8v8"/>',
week:'<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M3 10h18M8 15h8"/>',refresh:'<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/>',
lock:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',eye:'<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',pin:'<path d="M12 17v5M9 10.8V4h6v6.8l3 3.2v2H6v-2z"/>',copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',mega:'<path d="m3 11 15-6v14L3 13z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/><path d="M21 9v6"/>',layout:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M9 21V9"/>',db:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',out:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',ics:'<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18M12 14v5M9.5 16.5 12 19l2.5-2.5"/>',church:'<path d="M12 2v4M10 4h4M6 22V11l6-5 6 5v11M2 22h20M10 22v-5a2 2 0 0 1 4 0v5"/>',sparkle:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 3v4M17 5h4M5 17v4M3 19h4"/>'};
const I=(k,c='')=>`<svg class="i ${c}" viewBox="0 0 24 24" aria-hidden="true">${P[k]||''}</svg>`;
const emb=id=>`<svg viewBox="0 0 64 64" aria-hidden="true">${IC[id]||(String(id).startsWith('cx')?IC.custom:IC.generic)}</svg>`;
const hv=(id,cls='av')=>IMG[id]?`<div class="${cls}"><img src="img/${IMG[id]}.webp" alt="" loading="lazy"></div>`:`<div class="${cls}">${emb(id)}</div>`;

/* time */
let NW=new Date(),TJ=jd(NW.getFullYear(),NW.getMonth()+1,NW.getDate()),te=toE(TJ);
const fE=(j,w)=>{const e=toE(j);return(w?n2(WD[wdOf(j)])+'፣ ':'')+n2(EM[e.m-1])+' '+nm(e.d)+'፣ '+nm(e.y)+' '+A('ዓ.ም','E.C.')},
fG=(j,w)=>{const g=gd(j);return(w?n2(WD[wdOf(j)])+', ':'')+n2(GM[g.getUTCMonth()])+' '+g.getUTCDate()+', '+g.getUTCFullYear()};
const rel=n=>n==0?A('ዛሬ','Today'):n==1?A('ነገ','Tomorrow'):n==-1?A('ትናንት','Yesterday'):n>0?A(`በ${n} ቀን`,`in ${n} days`):A(`ከ${-n} ቀን በፊት`,`${-n} days ago`);
const col=j=>(wdOf(j)-WK+7)%7,wh=()=>[0,1,2,3,4,5,6].map(i=>(i+WK)%7);
function ethTime(d){const h=d.getHours(),m=d.getMinutes(),eh=(h+6)%12||12;const per=h>=6&&h<12?A('ጠዋት','morning'):h>=12&&h<18?A('ከሰዓት','afternoon'):h>=18?A('ማታ','evening'):A('ሌሊት','night');return{t:eh+':'+String(m).padStart(2,'0'),per}}
function nextOff(from=TJ){for(let k=0;k<400;k++){const a=hol(from+k).filter(x=>x.off);if(a.length)return[k,a[0],from+k]}return null}

/* notes */
const CAT={note:['ማስታወሻ','Note','note','#3b62d9'],bday:['ልደት','Birthday','cake','#e0457b'],rem:['አስታዋሽ','Reminder','bell','#e9a100'],anniv:['መታሰቢያ','Anniversary','heart','#8e5bd0']};
const saveEV=()=>sv('ev',JSON.stringify(EV));
function noteMatch(x,j){if(j<x.j)return false;if(x.r=='e'){const a=toE(j),b=toE(x.j);return a.m==b.m&&a.d==b.d}if(x.r=='g'){const a=gd(j),b=gd(x.j);return a.getUTCMonth()==b.getUTCMonth()&&a.getUTCDate()==b.getUTCDate()}return x.j==j}
const evAt=j=>EV.map((x,i)=>({...x,i})).filter(x=>noteMatch(x,j));
function nextOcc(x){if(!x.r)return x.j;if(x.r=='e'){const b=toE(x.j);for(let y=te.y;y<te.y+5;y++){if(b.m==13&&b.d>dim(y,13))continue;const j=fromE(y,b.m,b.d);if(j>=TJ&&j>=x.j)return j}}else{const b=gd(x.j);for(let y=NW.getFullYear();y<NW.getFullYear()+5;y++){const j=jd(y,b.getUTCMonth()+1,b.getUTCDate());if(j>=TJ&&j>=x.j)return j}}return x.j}
function ageAt(x,j){if(!x.r)return null;return x.r=='e'?toE(j).y-toE(x.j).y:gd(j).getUTCFullYear()-gd(x.j).getUTCFullYear()}

/* state */
const ST={tab:'today',P:ld('p')||'e',mode:'m',ey:te.y,em:te.m,gy:NW.getFullYear(),gm:NW.getMonth()+1,yv:null,hy:null,hf:'all',hseg:'h',by:te.y,nf:'all',nq:''};
ST.yv=ST.P=='g'?ST.gy:ST.ey;

/* ---------- views ---------- */
function todayV(){const e=toE(TJ),se=SEASON[e.m],nx=nextOff(),H=hol(TJ),fa=SF&&fastOf(TJ),sa=SS&&saintOf(TJ),et=ethTime(new Date());
const ylen=e.y%4==3?366:365,doy=(e.m-1)*30+e.d,pct=Math.round(doy/ylen*100),C=2*Math.PI*40;
let h=annH()+`<section class="hero"><img src="img/${se[0]}.webp" alt=""><div class="hero-in">
<div class="hero-top"><span class="pill">${I('leaf')}${n2([se[1],se[2]])}</span><span class="pill">${I('book')}${A('ዘመነ '+EVANG[e.y%4][0],'Year of '+EVANG[e.y%4][1])}</span>
<div class="hero-clock"><b id="hclk">${et.t}</b><small id="hper">${A('የኢትዮጵያ ሰዓት','Ethiopian time')} · ${et.per}</small></div></div>
<div class="hero-main"><div class="hero-day${GZ?' gz':''}">${nm(e.d)}</div><div class="hero-txt"><div class="wd">${n2(WD[wdOf(TJ)])}</div><h2>${n2(EM[e.m-1])} ${nm(e.y)}</h2><p>${fG(TJ)}</p></div></div></div></section><div class="tilet"></div>`;
if(H.length)h+=H.map(x=>`<button class="hol-today" onclick="hd('${x.id}',${TJ})">${hv(x.id)}<div style="flex:1"><small>${A('ዛሬ በዓል ነው','Today is a holiday')}</small><b>${n2([x.am,x.en])}</b></div>${x.off?`<span class="badge">${A('ዕረፍት','Day off')}</span>`:''}</button>`).join('');
if(SEC('cd')&&nx&&nx[0]>0){const x=nx[1];h+=`<div class="card" style="padding:0"><button class="cd" onclick="hd('${x.id}',${nx[2]})">${IMG[x.id]?`<img class="thumb" src="img/${IMG[x.id]}.webp" alt="">`:`<div class="thumb ic">${emb(x.id)}</div>`}
<div style="min-width:0;flex:1"><div class="k">${A('ቀጣይ በዓል','Next holiday')}</div><h4>${n2([x.am,x.en])}</h4><div class="when">${fE(nx[2],1)}</div>
<div class="clk" id="clk" data-j="${nx[2]}"></div></div></button></div>`}
h+=myCd();const tg=[];if(fa)tg.push(`<span class="tag" style="--c:var(--grn)"><span class="dot"></span>${n2(fa)}</span>`);else if(SF)tg.push(`<span class="tag" style="--c:var(--mut)"><span class="dot"></span>${A('ፍስክ ቀን','Non-fasting day')}</span>`);
if(sa)tg.push(`<span class="tag" style="--c:#d98a00"><span class="dot"></span>${n2(sa)} <small>${A('ወርኃዊ በዓል','monthly feast')}</small></span>`);
const mine=evAt(TJ);mine.forEach(x=>tg.push(`<span class="tag" style="--c:${CAT[x.c||'note'][3]}"><span class="dot"></span>${esc(x.t)}</span>`));
if(SEC('tags')&&tg.length)h+=`<div class="tags">${tg.join('')}</div>`;
// week strip
if(SEC('week')){h+=`<div class="sec-h"><h3>${A('ይህ ሳምንት','This week')}</h3><button onclick="tab('cal')">${A('ወር','Month')}${I('r')}</button></div><div class="week">`;
const ws=TJ-col(TJ);for(let j=ws;j<ws+7;j++){const ee=toE(j),hh=hol(j).some(x=>x.off);h+=`<button class="${j==TJ?'on':''}" onclick="sel(${j})">${hh?'<u></u>':''}<small>${n2(WS[wdOf(j)])}</small><b>${nm(ee.d)}</b><i>${gd(j).getUTCDate()}</i></button>`}
h+='</div>'}
if(SEC('stats'))h+=`<div class="grid2"><div class="card ring"><div class="ring-w"><svg viewBox="0 0 100 100"><circle class="bgc" cx="50" cy="50" r="40"/><circle class="fgc" cx="50" cy="50" r="40" stroke-dasharray="${C}" stroke-dashoffset="${C}" data-off="${C*(1-doy/ylen)}"/></svg><span>${pct}%</span></div><p>${A(`የ${nm(e.y)} ዓ.ም ቀን ${nm(doy)}/${nm(ylen)}`,`Day ${doy} of ${ylen} in ${e.y} E.C.`)}</p></div>
<div class="card etime"><span class="lbl">${A('የኢትዮጵያ ሰዓት','Ethiopian time')}</span><span class="big" id="etb">${et.t}</span><span class="per" id="etp">${et.per}</span><span class="sub" id="etw">${A('ዓለም አቀፍ','Western')}: ${new Date().toLocaleTimeString(L=='am'?'en-GB':'en-US',{hour:'2-digit',minute:'2-digit'})}</span></div></div>`;
const PV=pvPool(),pv=PV[TJ%PV.length];
if(SEC('prov')&&pv)h+=`<div class="card prov"><h3>${I('quote')}${A('የዕለቱ ተረት','Proverb of the day')}</h3><div class="q">${pv[0]}</div><p>${pv[1]}</p><div class="tl"></div></div>`;
// upcoming
const up=[];for(let k=1;k<=90&&up.length<6;k++){hol(TJ+k).forEach(x=>{if(up.length<6&&(x.off||x.c=='org'))up.push({j:TJ+k,x})})}
const myUp=EV.map((x,i)=>({...x,i,n:nextOcc(x)})).filter(x=>x.n>TJ&&x.n-TJ<=60).sort((a,b)=>a.n-b.n).slice(0,3);
if(SEC('up'))h+=`<div class="sec-h"><h3>${A('የሚመጡ','Coming up')}</h3><button onclick="tab('hol')">${A('ሁሉም','See all')}${I('r')}</button></div><div class="card">`;
const rows=[...myUp.map(x=>({j:x.n,html:`<button class="row" onclick="sel(${x.n})"><div class="av cat" style="background:${CAT[x.c||'note'][3]}">${I(CAT[x.c||'note'][2])}</div><div class="t"><b>${esc(x.t)}</b><small>${fE(x.n,1)}${x.c=='bday'&&ageAt(x,x.n)?' · '+A(`${nm(ageAt(x,x.n))} ዓመት ይሞላል`,`turns ${ageAt(x,x.n)}`):''}</small></div><span class="rel">${rel(x.n-TJ)}</span></button>`})),
...up.map(({j,x})=>({j,html:`<button class="row" onclick="hd('${x.id}',${j})">${hv(x.id)}<div class="t"><b>${n2([x.am,x.en])}</b><small>${fE(j,1)}</small></div><span class="rel">${rel(j-TJ)}</span></button>`}))].sort((a,b)=>a.j-b.j);
if(SEC('up'))h+=rows.map(r=>r.html).join('')+'</div>';
if(DEFERRED)h+=`<div class="card" style="display:flex;gap:12px;align-items:center"><div class="av cat" style="background:var(--night)">${I('phone')}</div><div style="flex:1"><b>${A('መተግበሪያውን ይጫኑ','Install the app')}</b><div class="sub">${A('ያለ ኢንተርኔት በስልክዎ ይጠቀሙ','Use it offline from your home screen')}</div></div><button class="btn ac" onclick="install()">${A('ጫን','Install')}</button></div>`;
return h}

function calV(){const E=ST.P=='e';let h=`<div class="seg"><button class="${E?'on':''}" onclick="setP('e')">${A('ኢትዮጵያ','Ethiopian')}</button><button class="${E?'':'on'}" onclick="setP('g')">${A('ግሪጎሪያን','Gregorian')}</button></div>`;
if(ST.mode=='y')return h+yrV();
const n=E?dim(ST.ey,ST.em):gdim(ST.gy,ST.gm),j0=E?fromE(ST.ey,ST.em,1):jd(ST.gy,ST.gm,1),j1=j0+n-1;
let ttl,sub;if(E){ttl=n2(EM[ST.em-1])+' '+nm(ST.ey);const a=gd(j0),b=gd(j1);sub=n2(GM[a.getUTCMonth()])+(a.getUTCMonth()!=b.getUTCMonth()?' – '+n2(GM[b.getUTCMonth()]):'')+' '+b.getUTCFullYear()}
else{ttl=n2(GM[ST.gm-1])+' '+ST.gy;const a=toE(j0),b=toE(j1);sub=n2(EM[a.m-1])+(a.m!=b.m?' – '+n2(EM[b.m-1]):'')+' '+nm(b.y)+' '+A('ዓ.ም','E.C.')}
const isCur=TJ>=j0&&TJ<=j1;
h+=`<div class="mh"><button class="ib" onclick="navM(-1)" aria-label="${A('ያለፈው ወር','Previous month')}">${I('l')}</button><div onclick="ST.mode='y';ST.yv=${E?ST.ey:ST.gy};render()" title="${A('ዓመት','Year view')}"><h2>${ttl}</h2><small>${sub}</small></div><button class="ib" onclick="navM(1)" aria-label="${A('ቀጣይ ወር','Next month')}">${I('r')}</button></div>`;
if(!isCur)h+=`<button class="today-btn" onclick="goT()">${A('ወደ ዛሬ ተመለስ','Back to today')}</button>`;
h+=`<div class="cgrid" id="cg">`;wh().forEach(w=>h+=`<div class="wdh${w==0?' s':''}">${n2(WS[w])}</div>`);
for(let i=0;i<col(j0);i++)h+='<div></div>';
const list=[];
for(let j=j0;j<=j1;j++){const e=toE(j),g=gd(j),gdn=g.getUTCDate(),H=hol(j),ho=H.some(x=>x.off),ot=H.length&&!ho,ev=evAt(j),fs=SF&&fastOf(j);
H.forEach(x=>list.push({j,x}));ev.forEach(x=>list.push({j,n:x}));
const big=E?nm(e.d):gdn,sm=E?(gdn==1?n2(GM[g.getUTCMonth()]).slice(0,3):gdn):(e.d==1?n2(EM[e.m-1]).slice(0,4):nm(e.d));
const dots=(ho?'<u style="--c:var(--red)"></u>':'')+(ot?'<u style="--c:var(--pur)"></u>':'')+(ev.length?`<u style="--c:${CAT[ev[0].c||'note'][3]}"></u>`:'');
h+=`<button class="c${wdOf(j)==0?' s':''}${ho?' h':''}${j==TJ?' td':''}${fs?' fs':''}${E&&GZ?' gz':''}" onclick="sel(${j})" aria-label="${fE(j,1)}"><span class="dots">${dots}</span><b>${big}</b><i>${sm}</i></button>`}
h+=`</div><div class="legend"><span><u style="--c:var(--red)"></u>${A('የዕረፍት ቀን','Day off')}</span><span><u style="--c:var(--pur)"></u>${A('በዓል','Observance')}</span><span><u style="--c:var(--ac)"></u>${A('ማስታወሻ','Note')}</span>${SF?`<span><u class="bar" style="--c:var(--grn)"></u>${A('ጾም','Fasting')}</span>`:''}</div>`;
if(list.length){h+=`<div class="sec-h"><h3>${A('በዚህ ወር','This month')}</h3></div><div class="card">`+list.map(({j,x,n})=>{const e=toE(j);return x?`<button class="row" onclick="hd('${x.id}',${j})"><div class="dt"><b>${E?nm(e.d):gd(j).getUTCDate()}</b><small>${n2(WS[wdOf(j)])}</small></div><div class="t"><b>${n2([x.am,x.en])}</b><small>${E?fG(j):fE(j)}</small></div>${x.off?`<span class="badge">${A('ዕረፍት','Day off')}</span>`:''}</button>`:`<button class="row" onclick="sel(${j})"><div class="dt" style="background:color-mix(in srgb,${CAT[n.c||'note'][3]} 18%,transparent)"><b>${E?nm(e.d):gd(j).getUTCDate()}</b><small>${n2(WS[wdOf(j)])}</small></div><div class="t"><b>${esc(n.t)}</b><small>${n2(CAT[n.c||'note'])}</small></div></button>`}).join('')+'</div>'}
return h}

function yrV(){const E=ST.P=='e',y=ST.yv,N=E?13:12;let h=`<div class="mh"><button class="ib" onclick="ST.yv--;render()" aria-label="Previous">${I('l')}</button><div onclick="ST.mode='m';render()"><h2>${E?nm(y)+' '+A('ዓ.ም','E.C.'):y}</h2><small>${E?A('ዘመነ '+EVANG[y%4][0],'Year of '+EVANG[y%4][1])+' · '+(y-8)+'/'+(y-7):nm(y-8)+'/'+nm(y-7)+' '+A('ዓ.ም','E.C.')}</small></div><button class="ib" onclick="ST.yv++;render()" aria-label="Next">${I('r')}</button></div><div class="yg">`;
for(let m=1;m<=N;m++){const j0=E?fromE(y,m,1):jd(y,m,1),n=E?dim(y,m):gdim(y,m),cur=TJ>=j0&&TJ<j0+n;
h+=`<button class="ym${cur?' cur':''}" onclick="jump(${m})"><h4>${n2((E?EM:GM)[m-1])}</h4><div>${'<span></span>'.repeat(col(j0))}${Array.from({length:n},(_,i)=>{const j=j0+i;return`<span class="${j==TJ?'t':hol(j).some(x=>x.off)?'h':''}">${E&&GZ?geez(i+1):i+1}</span>`}).join('')}</div></button>`}
return h+'</div>'}

function holV(){let h=`<div class="seg"><button class="${ST.hseg=='h'?'on':''}" onclick="ST.hseg='h';render()">${I('party')}${A('በዓላት','Holidays')}</button><button class="${ST.hseg=='b'?'on':''}" onclick="ST.hseg='b';render()">${I('book')}${A('ባሕረ ሐሳብ','Bahire Hasab')}</button></div>`;
return h+(ST.hseg=='h'?holList():bhV())}
function holList(){const y=ST.hy,f=ST.hf,up=y==null,cy=NW.getFullYear(),ja=up?TJ:jd(y,1,1),jb=up?TJ+365:jd(y,12,31);
let h=`<div class="mh"><button class="ib" onclick="ST.hy=ST.hy==null?${cy}:ST.hy-1;render()" aria-label="Previous">${I('l')}</button><div onclick="ST.hy=null;render()"><h2>${up?A('የሚመጡ በዓላት','Upcoming'):A('በዓላት','Holidays')+' '+y}</h2><small>${up?A('የሚቀጥሉት 12 ወራት','Next 12 months'):nm(y-8)+' – '+nm(y-7)+' '+A('ዓ.ም','E.C.')}</small></div><button class="ib" onclick="ST.hy=ST.hy==null?${cy+1}:ST.hy+1;render()" aria-label="Next">${I('r')}</button></div>
<div class="chips">${[['all',A('ሁሉም','All')],['off',A('የዕረፍት ቀናት','Days off')],['org',A('ኦርቶዶክስ','Orthodox'),CC.org],['nat',A('ብሔራዊ','National'),CC.nat],['mus',A('እስልምና','Muslim'),CC.mus],['chr',A('ካቶሊክ/ፕሮቴስታንት','Catholic/Protestant'),CC.chr],...(CUSTOM.length?[['cus',A('ልዩ','Special'),CC.cus]]:[])].map(([k,l,c])=>`<button class="chip ${f==k?'on':''}" onclick="ST.hf='${k}';render()">${c?`<span class="dot" style="--c:${c}"></span>`:''}${l}</button>`).join('')}</div>`;
if(!up&&y!=cy)h+=`<button class="today-btn" onclick="ST.hy=null;render()">${A('የሚመጡትን አሳይ','Show upcoming')}</button>`;
if(up){const nx=nextOff();if(nx&&IMG[nx[1].id]&&(f=='all'||f=='off'||f==nx[1].c))h+=`<button class="feat" onclick="hd('${nx[1].id}',${nx[2]})"><img src="img/${IMG[nx[1].id]}.webp" alt=""><div class="k">${A('ቀጣይ በዓል','Up next')} · ${rel(nx[0])}</div><h3>${n2([nx[1].am,nx[1].en])}</h3><p>${fE(nx[2],1)} · ${fG(nx[2])}</p></button>`}
let c=0,lm=-1;
for(let j=ja;j<=jb;j++)hol(j).filter(x=>f=='all'||(f=='off'?x.off:x.c==f)).forEach(x=>{c++;const m=gd(j).getUTCMonth()+gd(j).getUTCFullYear()*12;if(m!=lm){lm=m;h+=`<div class="mlab">${n2(GM[m%12])}${up?' '+Math.floor(m/12):''}</div>`}
h+=`<button class="hcard${j<TJ?' past':''}" style="${j<TJ?'opacity:.6':''}" onclick="hd('${x.id}',${j})">${hv(x.id).replace('class="av"',`class="av" style="--k:${CC[x.c]}"`)}<div class="t"><b>${n2([x.am,x.en])}</b><small>${fE(j,1)}<br>${fG(j)}</small></div><div class="side">${x.off?`<span class="badge">${A('ዕረፍት','Day off')}</span>`:''}<span class="rel">${rel(j-TJ)}</span></div></button>`});
return h+(c?'':emptyS('party',A('ምንም የለም','Nothing here'),''))+`<button class="btn ghost w" style="margin-top:14px" onclick="exportICS()">${I('ics')}${A('ወደ ስልክ ቀን መቁጠሪያ ላክ (.ics)','Add to my phone calendar (.ics)')}</button><p class="note">${I('info')}<span>${A('የእስልምና በዓላት ቀን በጨረቃ ዕይታ በአንድ ቀን ሊለያይ ይችላል። «ዕረፍት» የተሰየሙት በመንግሥት የሥራ ዕረፍት ቀናት ናቸው።','Muslim holiday dates follow moon sighting and may differ by one day. “Day off” marks official government non-working days.')}</span></p>`}

function bhV(){const y=ST.by,aa=y+5500,wb=(aa-1)%19,ab=(wb*11)%30,mt=(wb*19)%30,E=easter(y+8),ev=EVANG[y%4],leap=y%4==3;
let h=`<div class="mh"><button class="ib" onclick="ST.by--;render()" aria-label="Previous">${I('l')}</button><div><h2>${nm(y)} ${A('ዓ.ም','E.C.')}</h2><small>${y+7}/${y+8}</small></div><button class="ib" onclick="ST.by++;render()" aria-label="Next">${I('r')}</button></div>
<div class="bh-hero"><div class="k">${A('ዘመን','Evangelist year')}</div><h2>${A('ዘመነ '+ev[0],'Year of '+ev[1])}</h2><p>${A(`ዓመተ ዓለም ${nm(aa)} · ጳጉሜ ${nm(leap?6:5)} ቀን`,`Amete Alem ${aa} · Pagume has ${leap?6:5} days`)}</p>
<div class="stats"><div><b>${nm(wb)||0}</b><small>${A('ወንበር','Wenber')}</small></div><div><b>${nm(ab)||0}</b><small>${A('አበቅቴ','Abekte')}</small></div><div><b>${nm(mt)||0}</b><small>${A('መጥቅዕ','Metqe')}</small></div><div><b>${nm(leap?366:365)}</b><small>${A('ቀናት','days')}</small></div></div></div>
<div class="sec-h"><h3>${A('ተንቀሳቃሽ በዓላትና አጽዋማት','Movable feasts & fasts')}</h3></div><div class="card">`;
const mv=[[-69,'nineveh','ጾመ ነነዌ','Fast of Nineveh'],[-55,'abiy','ዐቢይ ጾም','Great Lent begins'],[-28,'debrezeit','ደብረ ዘይት','Debre Zeit'],[-7,'hosanna','ሆሳዕና','Hosanna'],[-2,'goodfriday','ስቅለት','Good Friday'],[0,'fasika','ትንሣኤ (ፋሲካ)','Easter (Fasika)'],[24,'generic','ርክበ ካህናት','Rikbe Kahinat'],[39,'erget','ዕርገት','Ascension'],[49,'paraclete','ጰራቅሊጦስ','Pentecost'],[50,'generic','ጾመ ሐዋርያት','Fast of the Apostles begins'],[52,'generic','ጾመ ድኅነት','Tsome Dihnet']];
h+=mv.map(([o,id,am,en])=>{const j=E+o,e=toE(j);return`<button class="row" onclick="sel(${j})"><div class="dt"><b>${nm(e.d)}</b><small>${n2(EM[e.m-1])}</small></div><div class="t"><b>${A(am,en)}</b><small>${n2(WD[wdOf(j)])} · ${fG(j)}</small></div><span class="rel">${rel(j-TJ)}</span></button>`}).join('');
h+=`</div><div class="sec-h"><h3>${A('ቋሚ አጽዋማት','Fixed fasts')}</h3></div><div class="card">`;
const fx=[[[3,15],[4,28],'ጾመ ነቢያት','Fast of the Prophets (Advent)'],[[12,1],[12,14],'ጾመ ፍልሰታ','Fast of the Assumption (Filseta)']];
h+=fx.map(([[m1,d1],[m2,d2],am,en])=>{const ja=fromE(y,m1,d1),jb=fromE(y,m2,d2);return`<button class="row" onclick="sel(${ja})"><div class="av cat" style="background:var(--grn)">${I('leaf')}</div><div class="t"><b>${A(am,en)}</b><small>${n2(EM[m1-1])} ${nm(d1)} – ${n2(EM[m2-1])} ${nm(d2)} · ${jb-ja+1} ${A('ቀናት','days')}</small></div></button>`}).join('');
h+=`<div class="row"><div class="av cat" style="background:var(--grn)">${I('leaf')}</div><div class="t"><b>${A('ረቡዕና ዓርብ','Wednesdays & Fridays')}</b><small>${A('ከፋሲካ እስከ ጰራቅሊጦስ እና ከገና እስከ ጥምቀት በስተቀር','Except the 50 days after Easter and from Genna to Timket')}</small></div></div></div>
<div class="sec-h"><h3>${A('ወርኃዊ በዓላት','Monthly feast days')}</h3></div><div class="card">${Object.entries(SAINT).map(([d,n])=>`<div class="row"><div class="dt"><b>${nm(+d)}</b><small>${A('በየወሩ','monthly')}</small></div><div class="t"><b>${n2(n)}</b></div></div>`).join('')}</div>
<p class="note">${I('info')}<span>${A('ይህ አጠቃላይ መመሪያ ነው፤ ለዝርዝሩ የአጥቢያ ቤተ ክርስቲያንዎን ይጠይቁ።','This is a general guide; please consult your local church for details.')}</span></p>`;
return h}

function toolV(){const iso=gd(TJ).toISOString().slice(0,10);const T=(ic,ti,su,body,open)=>`<details class="card tool"${open?' open':''}><summary><div class="tic">${I(ic)}</div><div class="t"><b>${ti}</b><small>${su}</small></div>${I('r','chev')}</summary><div class="body">${body}</div></details>`;
return T('swap',A('ከግሪጎሪያን ወደ ኢትዮጵያ','Gregorian → Ethiopian'),A('ቀን ይምረጡ','Pick any date'),`<input type="date" id="gi" value="${iso}" oninput="c1()"><div class="out" id="o1"></div>`,1)+
T('swap',A('ከኢትዮጵያ ወደ ግሪጎሪያን','Ethiopian → Gregorian'),A('ዓመት፣ ወር፣ ቀን','Year, month, day'),`<div class="f3"><div><label for="ey">${A('ዓመት','Year')}</label><input type="number" id="ey" value="${te.y}" oninput="c2()"></div><div><label for="em">${A('ወር','Month')}</label><select id="em" onchange="c2()">${EM.map((x,i)=>`<option value="${i+1}" ${i+1==te.m?'selected':''}>${n2(x)}</option>`).join('')}</select></div><div><label for="ed">${A('ቀን','Day')}</label><input type="number" id="ed" min="1" max="30" value="${te.d}" oninput="c2()"></div></div><div class="out" id="o2"></div>`)+
T('hour',A('በሁለት ቀናት መካከል','Days between dates'),A('ቀናትና ሳምንታት','Days and weeks'),`<div class="f2"><div><label for="a1">${A('ከ','From')}</label><input type="date" id="a1" value="${iso}" oninput="c3()"></div><div><label for="a2">${A('እስከ','To')}</label><input type="date" id="a2" value="${gd(nextOff()?.[2]||TJ).toISOString().slice(0,10)}" oninput="c3()"></div></div><div class="out" id="o3"></div>`)+
T('cake',A('ዕድሜ ማስላት','Age calculator'),A('በሁለቱም አቆጣጠር','In both calendars'),`<label for="bd">${A('የትውልድ ቀን','Date of birth')}</label><input type="date" id="bd" oninput="c4()"><div class="out" id="o4">—</div>`)+
T('plus',A('ቀናት መደመር/መቀነስ','Add or subtract days'),A('ከአንድ ቀን በኋላ ወይም በፊት','Find a date before or after'),`<div class="f2"><div><label for="p1">${A('ቀን','Date')}</label><input type="date" id="p1" value="${iso}" oninput="c5()"></div><div><label for="p2">${A('ቀናት (+/−)','Days (+/−)')}</label><input type="number" id="p2" value="40" oninput="c5()"></div></div><div class="out" id="o5"></div>`)+
T('clock',A('የሰዓት መቀየሪያ','Time converter'),A('ዓለም አቀፍ ↔ የኢትዮጵያ ሰዓት','Western ↔ Ethiopian time'),`<label for="t1">${A('ዓለም አቀፍ ሰዓት','Western time')}</label><input type="time" id="t1" value="${new Date().toTimeString().slice(0,5)}" oninput="c6()"><div class="out" id="o6"></div>`)+
T('hash',A('የግዕዝ ቁጥሮች','Ge’ez numerals'),A('ቁጥርን ወደ ግዕዝ ይቀይሩ','Convert numbers to Ge’ez'),`<input type="number" id="z1" value="${te.y}" min="1" max="99999" oninput="c7()"><div class="out" id="o7"></div>`)}
function c1(){const v=$('#gi')?.value;if(!v)return;const[y,m,d]=v.split('-').map(Number),j=jd(y,m,d);$('#o1').innerHTML=`<span class="big">${fE(j,1)}</span>${rel(j-TJ)}`}
function c2(){const y=+$('#ey').value,m=+$('#em').value,d=Math.min(Math.max(+$('#ed').value||1,1),dim(y,m)),j=fromE(y,m,d);$('#o2').innerHTML=`<span class="big">${fG(j,1)}</span>${rel(j-TJ)}`}
function c3(){const a=$('#a1').value,b=$('#a2').value;if(!a||!b)return;const p=s=>jd(...s.split('-').map(Number)),n=Math.abs(p(b)-p(a));$('#o3').innerHTML=`<span class="big">${n} ${A('ቀናት','days')}</span>${Math.floor(n/7)} ${A('ሳምንት','weeks')} + ${n%7} ${A('ቀን','days')} · ≈ ${(n/30.44).toFixed(1)} ${A('ወር','months')}`}
function c4(){const v=$('#bd').value;if(!v)return;const[y,m,d]=v.split('-').map(Number),b=jd(y,m,d);if(b>TJ){$('#o4').textContent='—';return}
const g=NW;let Y=g.getFullYear()-y,M=g.getMonth()+1-m,D=g.getDate()-d;if(D<0){M--;D+=new Date(g.getFullYear(),g.getMonth(),0).getDate()}if(M<0){Y--;M+=12}
const e0=toE(b);let y2=te.y-e0.y,m2=te.m-e0.m,d2=te.d-e0.d;if(d2<0){m2--;d2+=30}if(m2<0){y2--;m2+=13}
let nb=jd(g.getFullYear(),m,d);if(nb<TJ)nb=jd(g.getFullYear()+1,m,d);
$('#o4').innerHTML=`<span class="big">${Y} ${A('ዓመት','years')}</span>${A('ግሪጎሪያን','Gregorian')}: ${Y} ${A('ዓመት','y')}, ${M} ${A('ወር','m')}, ${D} ${A('ቀን','d')}<br>${A('ኢትዮጵያ','Ethiopian')}: ${y2} ${A('ዓመት','y')}, ${m2} ${A('ወር','m')}, ${d2} ${A('ቀን','d')}<br>${A('የተወለዱት','Born on')}: ${fE(b,1)}<br>${A('የኖሩት','Days lived')}: ${(TJ-b).toLocaleString()} · ${A('ቀጣይ ልደት','Next birthday')}: ${rel(nb-TJ)}<div class="birth">${I('sparkle')}<span><b>${A('የልደትዎ ታሪክ','Your birth story')}</b>${A(`የተወለዱት ${n2(WD[wdOf(b)])} ቀን፣ በ${n2([SEASON[e0.m][1],SEASON[e0.m][2]])} ወቅት፣ በዘመነ ${EVANG[e0.y%4][0]} ነው።`,`You were born on a ${n2(WD[wdOf(b)])}, in the ${n2([SEASON[e0.m][1],SEASON[e0.m][2]])} season, in the Year of ${EVANG[e0.y%4][1]}.`)}${saintOf(b)?' '+A(`ዕለቱ የ${n2(saintOf(b))} መታሰቢያ ነው።`,`The day honours ${n2(saintOf(b))}.`):''}</span></div>`}
function c5(){const v=$('#p1').value,n=+$('#p2').value||0;if(!v)return;const j=jd(...v.split('-').map(Number))+n;$('#o5').innerHTML=`<span class="big">${fE(j,1)}</span>${fG(j,1)}`}
function c6(){const v=$('#t1').value;if(!v)return;const[h,m]=v.split(':').map(Number),d=new Date();d.setHours(h,m);const e=ethTime(d);$('#o6').innerHTML=`<span class="big">${e.t} ${e.per}</span>${A('የኢትዮጵያ ሰዓት ከፀሐይ መውጫ (ከጠዋቱ 12) ይቆጠራል።','Ethiopian time counts hours from sunrise (6:00 = 12:00).')}`}
function c7(){const n=Math.floor(+$('#z1').value);$('#o7').innerHTML=n>0&&n<100000?`<span class="big" style="font-size:30px">${geez(n)}</span>${n.toLocaleString()}`:'—'}

function emptyS(ic,t,p,btn=''){return`<div class="empty"><div class="ill">${I(ic)}</div><h4>${t}</h4><p>${p}</p>${btn}</div>`}
function evV(){const q=ST.nq.toLowerCase(),f=ST.nf;let h=`<div class="searchbox">${I('search')}<input id="nq" placeholder="${A('ማስታወሻ ይፈልጉ…','Search your notes…')}" value="${esc(ST.nq)}" oninput="ST.nq=this.value;drawNotes()"></div>
<div class="chips">${[['all',A('ሁሉም','All')],...Object.entries(CAT).map(([k,v])=>[k,n2(v),v[3]])].map(([k,l,c])=>`<button class="chip ${f==k?'on':''}" onclick="ST.nf='${k}';render()">${c?`<span class="dot" style="--c:${c}"></span>`:''}${l}</button>`).join('')}</div><div id="nl"></div>
<div class="f2" style="margin-top:16px"><button class="btn ghost" onclick="exportN()">${I('dl')}${A('ምትኬ አውርድ','Back up')}</button><button class="btn ghost" onclick="$('#imp').click()">${I('ul')}${A('ምትኬ መልስ','Restore')}</button></div><input type="file" id="imp" accept="application/json" hidden onchange="importN(this)">`;
return h}
function drawNotes(){const el=$('#nl');if(!el)return;const q=ST.nq.toLowerCase(),f=ST.nf;
const l=EV.map((x,i)=>({...x,i,n:nextOcc(x)})).filter(x=>(f=='all'||(x.c||'note')==f)&&(!q||x.t.toLowerCase().includes(q)));
if(!EV.length){el.innerHTML=emptyS('note',A('ገና ምንም ማስታወሻ የለም','No notes yet'),A('ልደቶችን፣ ቀጠሮዎችንና አስታዋሾችን ይመዝግቡ። ማንኛውንም ቀን በመንካትም መጨመር ይችላሉ።','Save birthdays, appointments and reminders. You can also tap any day on the calendar.'),`<button class="btn ac" style="margin-top:16px" onclick="sel(TJ,1)">${I('plus')}${A('ማስታወሻ ጨምር','Add a note')}</button>`);return}
if(!l.length){el.innerHTML=emptyS('search',A('ምንም አልተገኘም','No matches'),'');return}
const up=l.filter(x=>x.n>=TJ).sort((a,b)=>a.n-b.n),past=l.filter(x=>x.n<TJ).sort((a,b)=>b.n-a.n);
const R=x=>{const c=CAT[x.c||'note'],e=toE(x.n),age=x.c=='bday'?ageAt(x,x.n):null;return`<div class="row"><button class="dt" style="background:color-mix(in srgb,${c[3]} 18%,transparent);border:0" onclick="sel(${x.n})"><b>${nm(e.d)}</b><small>${n2(EM[e.m-1])}</small></button><button class="t" style="text-align:left" onclick="sel(${x.n})"><b>${esc(x.t)}</b><small>${n2(c)}${x.r?' · '+I('repeat').replace('class="i ','style="width:12px;height:12px;vertical-align:-1px" class="i ')+' '+A('በየዓመቱ','yearly'):''}${age?' · '+A(`${nm(age)} ዓመት`,`turns ${age}`):''}</small><small>${fG(x.n)} · ${rel(x.n-TJ)}</small></button><button class="x${x.p?' pinned':''}" onclick="pin(${x.i})" aria-label="${A('በዛሬ ገጽ ላይ ቆጠራ','Pin countdown')}">${I('pin')}</button><button class="x" onclick="del(${x.i})" aria-label="${A('ሰርዝ','Delete')}">${I('trash')}</button></div>`};
el.innerHTML=(up.length?`<div class="mlab">${A('የሚመጡ','Upcoming')}</div><div class="card">${up.map(R).join('')}</div>`:'')+(past.length?`<div class="mlab">${A('ያለፉ','Past')}</div><div class="card" style="opacity:.75">${past.map(R).join('')}</div>`:'')}
function exportN(){const b=new Blob([JSON.stringify({app:'ethcal',v:4,notes:EV},null,1)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='ethcal-notes-'+gd(TJ).toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();a.remove();toast(A('ምትኬ ወርዷል','Backup downloaded'))}
function importN(inp){const f=inp.files[0];if(!f)return;f.text().then(s=>{const d=JSON.parse(s),n=Array.isArray(d)?d:d.notes;if(!Array.isArray(n))throw 0;let k=0;n.forEach(x=>{if(typeof x.j=='number'&&x.t&&!EV.some(y=>y.j==x.j&&y.t==x.t)){EV.push({j:x.j,t:String(x.t).slice(0,200),c:CAT[x.c]?x.c:'note',r:['e','g'].includes(x.r)?x.r:0});k++}});saveEV();render();toast(A(`${k} ማስታወሻ ተመልሷል`,`${k} notes restored`))}).catch(()=>toast(A('ፋይሉ ሊነበብ አልቻለም','Could not read that file')));inp.value=''}

/* ---------- sheets ---------- */
function openSheet(html){$('#shc').innerHTML='<div class="grab"></div>'+html;$('#sh').hidden=false;document.body.style.overflow='hidden';$('#shc').scrollTop=0}
function closeSheet(){$('#sh').hidden=true;document.body.style.overflow=''}
let NC='note',NR=0;
function sel(j,focus){buzz();const e=toE(j),ho=hol(j),ev=evAt(j),fa=SF&&fastOf(j),sa=SS&&saintOf(j),gy=gd(j).getUTCFullYear();
let h=`<div class="sh-h"><div><h2>${fE(j,1)}</h2><div class="meta">${fG(j,1)}</div><div class="meta">${rel(j-TJ)} · ${A('የዓመቱ ቀን','Day of year')} ${nm((e.m-1)*30+e.d)}</div></div><button class="x" onclick="copyD(${j})" aria-label="${A('ቅዳ','Copy date')}">${I('copy')}</button>${ADM.share?`<button class="x" onclick="shareDay(${j})" aria-label="${A('አጋራ','Share')}">${I('share')}</button>`:''}<button class="x" onclick="closeSheet()" aria-label="${A('ዝጋ','Close')}">${I('x')}</button></div>`;
h+=`<div style="margin-top:12px">${ho.map(x=>`<button class="hcard" onclick="hd('${x.id}',${j})">${hv(x.id).replace('class="av"',`class="av" style="--k:${CC[x.c]}"`)}<div class="t"><b>${n2([x.am,x.en])}</b><small>${A({org:'ኦርቶዶክስ',nat:'ብሔራዊ',mus:'እስልምና',chr:'ካቶሊክ/ፕሮቴስታንት'}[x.c],{org:'Orthodox',nat:'National',mus:'Muslim',chr:'Catholic/Protestant'}[x.c])}</small></div><div class="side">${x.off?`<span class="badge">${A('ዕረፍት','Day off')}</span>`:''}${I('r')}</div></button>`).join('')}</div>`;
if(fa||sa)h+=`<div class="tags">${fa?`<span class="tag" style="--c:var(--grn)"><span class="dot"></span>${n2(fa)}</span>`:''}${sa?`<span class="tag" style="--c:#d98a00"><span class="dot"></span>${n2(sa)}</span>`:''}</div>`;
if(ev.length)h+=`<div class="card" style="margin-top:10px;background:var(--bg)">${ev.map(x=>{const c=CAT[x.c||'note'],age=x.c=='bday'?ageAt(x,j):null;return`<div class="row"><div class="av cat" style="background:${c[3]};width:40px;height:40px;border-radius:12px">${I(c[2])}</div><div class="t"><b>${esc(x.t)}</b><small>${n2(c)}${x.r?' · '+A('በየዓመቱ','yearly'):''}${age?' · '+A(`${nm(age)} ዓመት ይሞላል`,`turns ${age}`):''}</small></div><button class="x${x.p?' pinned':''}" onclick="pin(${x.i},${j})" aria-label="${A('ቆጠራ','Pin countdown')}">${I('pin')}</button><button class="x" onclick="del(${x.i},${j})" aria-label="${A('ሰርዝ','Delete')}">${I('trash')}</button></div>`}).join('')}</div>`;
NC='note';NR=0;
h+=`<div style="margin-top:14px"><label for="ei">${A('አዲስ ማስታወሻ','New note')}</label><input id="ei" maxlength="200" placeholder="${A('ለምሳሌ፦ የአበበ ልደት','e.g. Abebe’s birthday')}" onkeydown="if(event.key=='Enter')addEv(${j})">
<div class="catsel" id="cs">${Object.entries(CAT).map(([k,v])=>`<button class="${k==NC?'on':''}" style="--c:${v[3]}" onclick="pickCat('${k}')">${I(v[2])}${n2(v)}</button>`).join('')}</div>
<label for="er">${A('መደጋገም','Repeat')}</label><select id="er" onchange="NR=this.value=='0'?0:this.value"><option value="0">${A('አንድ ጊዜ','Once')}</option><option value="e">${A('በየዓመቱ (ኢትዮጵያ)','Every year (Ethiopian date)')}</option><option value="g">${A('በየዓመቱ (ግሪጎሪያን)','Every year (Gregorian date)')}</option></select>
<button class="btn ac w" style="margin-top:14px" onclick="addEv(${j})">${I('plus')}${A('ጨምር','Add note')}</button></div>`;
openSheet(h);if(focus)setTimeout(()=>$('#ei')?.focus(),300)}
function pickCat(k){NC=k;$$('#cs button').forEach((b,i)=>b.classList.toggle('on',Object.keys(CAT)[i]==k));if(k=='bday'||k=='anniv'){$('#er').value='e';NR='e'}buzz(5)}
function addEv(j){const v=$('#ei').value.trim();if(!v){$('#ei').focus();return}EV.push({j,t:v,c:NC,r:NR||0});saveEV();buzz(15);toast(I('check')+A('ማስታወሻ ተቀምጧል','Note saved'));sel(j);render(true)}
function del(i,j){const x=EV[i];EV.splice(i,1);saveEV();toast(A('ተሰርዟል','Deleted'),()=>{EV.splice(i,0,x);saveEV();render(true);if(j)sel(j)});if(j)sel(j);render(true)}
function hd(id,j){buzz();const x=hol(j).find(h=>h.id==id)||{id,am:'',en:'',c:'org'},st=STORY[id]||(CUSTOM.find(c=>c.id==id)||{}).ds;
let h=IMG[id]?`<div class="sh-img"><img src="img/${IMG[id]}.webp" alt=""><button class="x" onclick="closeSheet()" aria-label="Close">${I('x')}</button></div>`:`<div class="sh-h"><div class="av" style="width:72px;height:72px;border-radius:22px">${emb(id)}</div><div></div><button class="x" onclick="closeSheet()" aria-label="Close">${I('x')}</button></div>`;
h+=`<div class="sh-h"><div><h2>${n2([x.am,x.en])}</h2><div class="meta">${fE(j,1)} · ${fG(j)}</div></div>${x.off?`<span class="badge">${A('የሥራ ዕረፍት','Day off')}</span>`:''}</div>`;
const d=j-TJ;if(d>0){h+=`<div class="kv"><div><b>${d}</b><small>${A('ቀናት ቀረው','days to go')}</small></div><div><b>${Math.floor(d/7)}</b><small>${A('ሳምንታት','weeks')}</small></div><div><b>${n2(WS[wdOf(j)])}</b><small>${A('ዕለት','weekday')}</small></div></div>`}else h+=`<div class="tags"><span class="tag">${rel(d)}</span></div>`;
if(st&&n2(st))h+=`<p class="story">${esc(n2(st))}</p>`;
h+=`<div class="f2" style="margin-top:8px"><button class="btn ghost" onclick="sel(${j})">${I('cal')}${A('ቀኑን ክፈት','Open day')}</button>${ADM.share?`<button class="btn ac" onclick="shareDay(${j},'${id}')">${I('share')}${A('አጋራ','Share')}</button>`:`<button class="btn ac" onclick="copyD(${j})">${I('copy')}${A('ቅዳ','Copy')}</button>`}</div>`;
openSheet(h)}

function setV(){const row=(ic,l,s,ctl)=>`<div class="set"><div class="l"><div class="tic">${I(ic)}</div><div>${l}${s?`<small>${s}</small>`:''}</div></div>${ctl}</div>`,tg=(on,fn)=>`<button class="tg${on?' on':''}" onclick="${fn}" role="switch" aria-checked="${on}"></button>`;
const sw=[['saffron','#e9a100'],['emerald','#14955a'],['crimson','#d7263d'],['lapis','#3b62d9'],['violet','#7b4fd0']];
let h=`<div class="sh-h"><div><h2>${A('ሴቲንግ','Settings')}</h2></div><button class="x" onclick="closeSheet()" aria-label="Close">${I('x')}</button></div><div class="card" style="background:var(--bg);margin-top:14px">`+
row('globe',A('ቋንቋ','Language'),'',`<div class="opts"><button class="${L=='am'?'on':''}" onclick="setL('am')">አማርኛ</button><button class="${L=='en'?'on':''}" onclick="setL('en')">English</button></div>`)+
row('moon',A('ገጽታ','Theme'),'',`<div class="opts">${[['auto',A('ራስ','Auto')],['light',A('ብርሃን','Light')],['dark',A('ጨለማ','Dark')]].map(([k,l])=>`<button class="${TH==k?'on':''}" onclick="setTh('${k}')">${l}</button>`).join('')}</div>`)+
row('palette',A('ቀለም','Accent'),'',`<div class="swatches">${sw.map(([k,c])=>`<button class="${AC==k?'on':''}" style="--c:${c}" onclick="setAc('${k}')" aria-label="${k}"></button>`).join('')}</div>`)+
row('hash',A('የግዕዝ ቁጥሮች','Ge’ez numerals'),'፩ ፪ ፫ · 1 2 3',tg(GZ,"GZ=!GZ;sv('g',GZ?1:0);setV();render(true)"))+
row('week',A('ሳምንት የሚጀምረው','Week starts on'),'',`<div class="opts"><button class="${WK==0?'on':''}" onclick="WK=0;sv('wk',0);setV();render(true)">${A('እሑድ','Sun')}</button><button class="${WK==1?'on':''}" onclick="WK=1;sv('wk',1);setV();render(true)">${A('ሰኞ','Mon')}</button></div>`)+
row('leaf',A('የጾም ቀናት','Fasting days'),A('በቀን መቁጠሪያው ላይ አሳይ','Show on calendar'),tg(SF,"SF=!SF;sv('sf',SF?1:0);setV();render(true)"))+
row('church',A('ወርኃዊ በዓላት','Monthly feasts'),A('ሚካኤል፣ ማርያም፣ ጊዮርጊስ…','Mikael, Maryam, Giorgis…'),tg(SS,"SS=!SS;sv('ss',SS?1:0);setV();render(true)"))+
row('bell',A('የበዓል ማስታወሻ','Holiday reminders'),A('ከበዓል አንድ ቀን በፊት ያሳውቃል','A heads-up the day before'),tg(NF,'nfT()'))+
row('vib',A('ንዝረት','Haptics'),'',tg(HP,"HP=!HP;sv('hp',HP?1:0);setV()"))+
row('check',A('ያለ ኢንተርኔት','Works offline'),A('ሁሉም ነገር በስልክዎ ይቀመጣል','Everything stays on your device'),`<b style="color:var(--grn)">${I('check')}</b>`)+`</div>
<div class="f2"><button class="btn ghost" onclick="closeSheet();showOnb()">${I('sparkle')}${A('መግቢያውን እይ','Replay intro')}</button>${DEFERRED?`<button class="btn ac" onclick="install()">${I('phone')}${A('ጫን','Install')}</button>`:`<button class="btn ghost" onclick="closeSheet();tab('ev')">${I('dl')}${A('ምትኬ','Backup')}</button>`}</div>${credit()}`;
openSheet(h)}
const credit=()=>`<div class="credit"><div class="sig"><div class="mono">ብ</div><div><small>${A('የተሰራው','Developed by')}</small><b>ብስራት ታደለ · Bisrat Tadele</b></div></div><div style="margin-top:10px">v4 · ${A('ቀን መቁጠሪያ','Ethiopian Calendar')}</div></div>`;
function setL(l){L=l;sv('l',L);render();if(!$('#sh').hidden)setV()}
function applyTheme(){const r=document.documentElement,d=TH=='dark'||(TH=='auto'&&matchMedia('(prefers-color-scheme: dark)').matches);r.dataset.mode=d?'dark':'light';r.dataset.ac=AC;if(ADM.acc){r.style.setProperty('--ac',ADM.acc);r.style.setProperty('--ac-ink',lum(ADM.acc)>.55?'#151a33':'#fff')}else{r.style.removeProperty('--ac');r.style.removeProperty('--ac-ink')}$('meta[name=theme-color]').content=d?'#0a0e20':'#f5f2ea'}
function setTh(k){TH=k;sv('th',k);applyTheme();setV()}
function setAc(k){AC=k;sv('ac',k);applyTheme();setV();buzz()}
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change',applyTheme);

/* search */
function openSearch(){$('#srch').hidden=false;$('#sq').value='';doSearch();setTimeout(()=>$('#sq').focus(),50)}
function closeSearch(){$('#srch').hidden=true}
function doSearch(){const q=$('#sq').value.trim().toLowerCase(),gy=NW.getFullYear();let out=[];
for(let y=gy;y<=gy+1;y++){const M=evs(y);Object.keys(M).map(Number).sort((a,b)=>a-b).forEach(j=>{if(j<TJ)return;M[j].forEach(x=>{if(!q||x.am.toLowerCase().includes(q)||x.en.toLowerCase().includes(q))out.push({j,x})})})}
const seen=new Set();out=out.filter(o=>{const k=o.x.id+o.x.c;if(seen.has(k))return false;seen.add(k);return true});
const notes=q?EV.map((x,i)=>({...x,i,n:nextOcc(x)})).filter(x=>x.t.toLowerCase().includes(q)):[];
let h='';if(notes.length)h+=`<div class="mlab">${A('ማስታወሻዎች','Notes')}</div><div class="card">${notes.map(x=>`<button class="row" onclick="closeSearch();sel(${x.n})"><div class="av cat" style="background:${CAT[x.c||'note'][3]}">${I(CAT[x.c||'note'][2])}</div><div class="t"><b>${esc(x.t)}</b><small>${fE(x.n,1)}</small></div><span class="rel">${rel(x.n-TJ)}</span></button>`).join('')}</div>`;
if(out.length)h+=`<div class="mlab">${A('በዓላት','Holidays')}</div><div class="card">${out.slice(0,30).map(({j,x})=>`<button class="row" onclick="closeSearch();hd('${x.id}',${j})">${hv(x.id)}<div class="t"><b>${n2([x.am,x.en])}</b><small>${fE(j,1)} · ${fG(j)}</small></div><span class="rel">${rel(j-TJ)}</span></button>`).join('')}</div>`;
$('#sr').innerHTML=h||emptyS('search',A('ምንም አልተገኘም','No results'),A('ሌላ ቃል ይሞክሩ፤ ለምሳሌ «ገና» ወይም «Eid»','Try another word, like “Genna” or “Eid”'))}

/* share card */
async function shareDay(j,id){buzz();const e=toE(j),H=id?hol(j).filter(x=>x.id==id):hol(j),img=new Image(),src=H[0]&&IMG[H[0].id]?IMG[H[0].id]:SEASON[e.m][0];
img.crossOrigin='anonymous';img.src='img/'+src+'.webp';try{await img.decode()}catch(_){}
try{await document.fonts.ready}catch(_){}
const W=1080,Hh=1350,c=document.createElement('canvas');c.width=W;c.height=Hh;const x=c.getContext('2d');x.fillStyle='#141b3a';x.fillRect(0,0,W,Hh);
try{const r=Math.max(W/img.width,Hh/img.height),iw=img.width*r,ih=img.height*r;x.drawImage(img,(W-iw)/2,(Hh-ih)/2,iw,ih)}catch(_){}
const g=x.createLinearGradient(0,0,0,Hh);g.addColorStop(0,'rgba(10,14,32,.1)');g.addColorStop(.45,'rgba(10,14,32,.35)');g.addColorStop(1,'rgba(10,14,32,.95)');x.fillStyle=g;x.fillRect(0,0,W,Hh);
x.fillStyle='#fff';x.textBaseline='alphabetic';x.font="800 300px Fraunces, 'Noto Serif Ethiopic'";x.fillText(String(nm(e.d)),80,Hh-430);
x.font="800 84px 'Noto Serif Ethiopic', Fraunces";x.fillText(n2(EM[e.m-1])+' '+nm(e.y),86,Hh-320);
x.globalAlpha=.85;x.font="600 46px 'Noto Sans Ethiopic'";x.fillText(n2(WD[wdOf(j)])+' · '+fG(j),88,Hh-250);x.globalAlpha=1;
if(H[0]){x.fillStyle='#fcdd09';x.font="800 54px 'Noto Serif Ethiopic', Fraunces";x.fillText(n2([H[0].am,H[0].en]).slice(0,34),88,Hh-160)}
const cols=['#078930','#fcdd09','#da121a','#fcdd09'];for(let i=0;i<W/40;i++){x.fillStyle=cols[i%4];x.beginPath();x.moveTo(i*40,Hh-40);x.lineTo(i*40+20,Hh-60);x.lineTo(i*40+40,Hh-40);x.lineTo(i*40+20,Hh-20);x.fill()}
x.fillStyle='rgba(255,255,255,.75)';x.font="600 34px 'Noto Sans Ethiopic'";x.fillText(A('ቀን መቁጠሪያ · ብስራት ታደለ','Ethiopian Calendar · by Bisrat Tadele'),88,Hh-90);
let blob;try{blob=await new Promise(r=>c.toBlob(r,'image/png'))}catch(_){}
if(!blob){toast(A('ማጋራት አልተቻለም','Could not create image'));return}
const file=new File([blob],'ethiopian-date.png',{type:'image/png'});
try{if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:fE(j,1)});return}}catch(_){}
const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ethiopian-date-'+e.y+'-'+e.m+'-'+e.d+'.png';document.body.appendChild(a);a.click();a.remove();toast(I('check')+A('ምስሉ ወርዷል','Image downloaded'))}

/* toast + confetti */
let TT;function toast(m,undo){clearTimeout(TT);$('.toast')?.remove();const t=document.createElement('div');t.className='toast';t.innerHTML=m+(undo?` <button style="color:var(--ac);font-weight:800;margin-left:6px">${A('መልስ','Undo')}</button>`:'');if(undo)t.querySelector('button').onclick=()=>{undo();t.remove()};document.body.appendChild(t);TT=setTimeout(()=>t.remove(),3200)}
function confetti(){if(!ADM.cf)return;if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const c=$('#confetti'),x=c.getContext('2d');c.width=innerWidth;c.height=innerHeight;const cols=['#078930','#fcdd09','#da121a','#e9a100','#fff'];
const ps=Array.from({length:140},()=>({x:Math.random()*c.width,y:-20-Math.random()*c.height*.5,vx:(Math.random()-.5)*3,vy:2+Math.random()*3,r:4+Math.random()*5,a:Math.random()*6,va:(Math.random()-.5)*.3,c:cols[Math.floor(Math.random()*5)]}));let f=0;
(function fr(){x.clearRect(0,0,c.width,c.height);ps.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.a+=p.va;p.vy+=.03;x.save();x.translate(p.x,p.y);x.rotate(p.a);x.fillStyle=p.c;x.fillRect(-p.r/2,-p.r/4,p.r,p.r/2);x.restore()});if(++f<240)requestAnimationFrame(fr);else x.clearRect(0,0,c.width,c.height)})()}

/* navigation */
const TABS=[['today','home',['ዛሬ','Today']],['cal','cal',['ወር','Calendar']],['hol','party',['በዓላት','Holidays']],['tl','calc',['መሣሪያ','Tools']],['ev','note',['ማስታወሻ','Notes']]];
function tab(k){if(!tabOn(k))return;if(ST.tab==k&&k=='cal'){goT();return}ST.tab=k;buzz(5);render();scrollTo({top:0})}
function setP(p){ST.P=p;sv('p',p);ST.yv=p=='e'?ST.ey:ST.gy;render(true)}
function goT(){ST.ey=te.y;ST.em=te.m;ST.gy=NW.getFullYear();ST.gm=NW.getMonth()+1;ST.mode='m';render(true)}
function navM(k){buzz(5);if(ST.P=='e'){ST.em+=k;if(ST.em>13){ST.em=1;ST.ey++}if(ST.em<1){ST.em=13;ST.ey--}}else{ST.gm+=k;if(ST.gm>12){ST.gm=1;ST.gy++}if(ST.gm<1){ST.gm=12;ST.gy--}}render(true)}
function jump(m){if(ST.P=='e'){ST.ey=ST.yv;ST.em=m}else{ST.gy=ST.yv;ST.gm=m}ST.mode='m';render()}

function render(keep){const y=scrollY;document.documentElement.lang=L;
$('#ttl').innerHTML=`<b>${esc(TTL())}</b><small>${esc(TSUB())}</small>`;document.title=TTL()+' · '+TSUB();$('#bq').hidden=!ADM.srch;$('#bs').hidden=!!ADM.lock;if(!tabOn(ST.tab))ST.tab='today';$('#bl').textContent=L=='am'?'EN':'አማ';
$('#nv').innerHTML=TABS.filter(t=>tabOn(t[0])).map(([k,i,l])=>`<button class="${ST.tab==k?'on':''}" onclick="tab('${k}')" aria-label="${n2(l)}"${ST.tab==k?' aria-current="page"':''}>${I(i)}${n2(l)}</button>`).join('');
const v={today:todayV,cal:calV,hol:holV,tl:toolV,ev:evV}[ST.tab]();
$('#app').innerHTML=`<div class="view${keep?' keep':''}">${v}${ST.tab!='today'?'':credit()}</div>`;
if(keep)$('#app .view').style.animation='none',$$('#app .view>*').forEach(e=>e.style.animation='none');
$('#fab').hidden=!(ST.tab=='ev'||ST.tab=='cal');
if(ST.tab=='tl'){c1();c2();c3();c5();c6();c7()}if(ST.tab=='ev')drawNotes();
if(ST.tab=='today'){requestAnimationFrame(()=>setTimeout(()=>{const r=$('.fgc');if(r)r.style.strokeDashoffset=r.dataset.off},60));tick()}
if(ST.tab=='cal')bindSwipe();
if(keep)scrollTo(0,y)}

function tick(){const n=new Date(),et=ethTime(n);const s=(id,v)=>{const e=$(id);if(e&&e.innerHTML!=v)e.innerHTML=v};
s('#hclk',et.t);s('#hper',A('የኢትዮጵያ ሰዓት','Ethiopian time')+' · '+et.per);s('#etb',et.t);s('#etp',et.per);s('#etw',A('ዓለም አቀፍ','Western')+': '+n.toLocaleTimeString(L=='am'?'en-GB':'en-US',{hour:'2-digit',minute:'2-digit'}));
const ck=$('#clk');if(ck){const g=gd(+ck.dataset.j),t=new Date(g.getUTCFullYear(),g.getUTCMonth(),g.getUTCDate()),d=Math.max(0,t-n),D=Math.floor(d/864e5),H=Math.floor(d/36e5)%24,M=Math.floor(d/6e4)%60,S=Math.floor(d/1e3)%60;
s('#clk',[[D,A('ቀን','days')],[H,A('ሰዓት','hrs')],[M,A('ደቂቃ','min')],[S,A('ሰከንድ','sec')]].map(([v,l])=>`<div><b>${String(v).padStart(2,'0')}</b><small>${l}</small></div>`).join(''))}
const nj=jd(n.getFullYear(),n.getMonth()+1,n.getDate());if(nj!=TJ){NW=n;TJ=nj;te=toE(TJ);render(true)}}
setInterval(()=>{if(!document.hidden)tick()},1000);

function bindSwipe(){const g=$('#cg');if(!g)return;let sx=0,sy=0;g.addEventListener('touchstart',e=>{sx=e.touches[0].clientX;sy=e.touches[0].clientY},{passive:true});g.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.4)navM(dx<0?1:-1)},{passive:true})}
document.addEventListener('keydown',e=>{if(e.key=='Escape'){if(!$('#srch').hidden)closeSearch();else closeSheet();return}
if(e.target.matches('input,select,textarea')||!$('#sh').hidden||!$('#srch').hidden)return;
if(ST.tab=='cal'&&ST.mode=='m'&&(e.key=='ArrowLeft'||e.key=='ArrowRight'))navM(e.key=='ArrowRight'?1:-1);
if(e.key=='/'){e.preventDefault();openSearch()}if(e.key=='t')goT()});

/* onboarding */
let OS=0;function showOnb(){OS=0;$('#onb').hidden=false;drawOnb()}
function drawOnb(){const d=`<div class="dots">${[0,1].map(i=>`<i class="${i==OS?'on':''}"></i>`).join('')}</div>`;
$('#onbc').innerHTML=OS==0?`<div class="step">${d}<span class="k">${I('sparkle')} ${A('እንኳን ደህና መጡ','Welcome')}</span><h1>${A('ጊዜን በራሳችን አቆጣጠር።','Time, the Ethiopian way.')}</h1><p>${A('የ13 ወራት ፀሐይ። ቀናትን፣ በዓላትንና ጾሞችን በሚያምር መንገድ ይከታተሉ።','Thirteen months of sunshine. Follow dates, holidays and fasts beautifully, in Amharic or English.')}</p>
<div class="langs"><button class="${L=='am'?'on':''}" onclick="L='am';sv('l','am');render();drawOnb()"><b>አማርኛ</b><small>Amharic</small></button><button class="${L=='en'?'on':''}" onclick="L='en';sv('l','en');render();drawOnb()"><b>English</b><small>እንግሊዝኛ</small></button></div>
<button class="btn w" onclick="OS=1;drawOnb()">${A('ቀጥል','Continue')} ${I('r')}</button>${onbBy()}</div>`:
`<div class="step">${d}<span class="k">${I('star')} ${A('ምን አዲስ ነገር አለ','What’s inside')}</span><h1>${A('ሁሉም በአንድ ቦታ።','Everything in one place.')}</h1>
<div class="feats"><div>${I('clock')}<span><b>${A('የቀጥታ የኢትዮጵያ ሰዓትና ቆጠራ','Live Ethiopian clock & countdowns')}</b><small>${A('እስከ ቀጣዩ በዓል','To the next holiday')}</small></span></div><div>${I('leaf')}<span><b>${A('ባሕረ ሐሳብና የጾም ቀናት','Bahire Hasab & fasting days')}</b><small>${A('ዘመን፣ ወንበር፣ አበቅቴ፣ መጥቅዕ','Evangelist year, Wenber, Abekte, Metqe')}</small></span></div><div>${I('cake')}<span><b>${A('ልደትና አስታዋሾች','Birthdays & reminders')}</b><small>${A('በየዓመቱ የሚደጋገሙ','Repeating every year')}</small></span></div><div>${I('share')}<span><b>${A('ቀንን እንደ ምስል ያጋሩ','Share any date as an image')}</b><small>${A('ለቤተሰብና ለጓደኞች','With family and friends')}</small></span></div></div>
<button class="btn w" onclick="endOnb()">${A('እንጀምር','Let’s begin')}</button>${onbBy()}</div>`}
function endOnb(){sv('onb','1');$('#onb').hidden=true;buzz(20);if(hol(TJ).some(x=>x.off))confetti()}
const onbBy=()=>`<div class="onb-by"><span class="mono">ብ</span><span><small>${A('የተሰራው በ','Developed by')}</small><b>ብስራት ታደለ · Bisrat Tadele</b></span></div>`;

/* ---------- extras ---------- */
const tabOn=k=>k=='today'||ADM.tabs[k]!==0;
function lum(h){const m=/^#?([0-9a-f]{6})$/i.exec(h||'');if(!m)return .5;const n=parseInt(m[1],16),f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(n>>16)+.7152*f(n>>8&255)+.0722*f(n&255)}
function pvPool(){const mine=(ADM.pv||'').split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{const[a,...b]=l.split('|');return[esc(a.trim()),esc(b.join('|').trim())]});return ADM.pvOnly&&mine.length?mine:PROV.concat(mine)}
function annH(){const a=ADM.ann;if(!a.on||!(a.am||a.en)||ld('annx')==String(a.v))return'';return`<div class="ann ${a.c||'ac'}">${I('mega')}<p>${esc(A(a.am||a.en,a.en||a.am))}</p><button onclick="sv('annx','${a.v}');render(true)" aria-label="${A('ዝጋ','Dismiss')}">${I('x')}</button></div>`}
function myCd(){if(!SEC('mycd'))return'';const p=EV.map((x,i)=>({...x,i,n:nextOcc(x)})).filter(x=>x.p&&x.n>=TJ).sort((a,b)=>a.n-b.n);if(!p.length)return'';
return`<div class="sec-h"><h3>${A('የእኔ ቆጠራዎች','My countdowns')}</h3><button onclick="tab('ev')">${A('ማስታወሻ','Notes')}${I('r')}</button></div><div class="mycd">${p.map(x=>{const c=CAT[x.c||'note'],d=x.n-TJ;return`<button style="--c:${c[3]}" onclick="sel(${x.n})"><span class="ic">${I(c[2])}</span><b>${d?nm(d):A('ዛሬ','Today')}</b><small>${d?A(d==1?'ቀን ቀረው':'ቀናት ቀረው',d==1?'day to go':'days to go'):A('ዛሬ ነው','is the day')}</small><span class="t">${esc(x.t)}</span><i>${fE(x.n)}</i></button>`}).join('')}</div>`}
function pin(i,j){const x=EV[i];if(!x)return;x.p=x.p?0:1;saveEV();buzz(10);toast(x.p?I('pin')+A('በዛሬ ገጽ ላይ ተሰክቷል','Pinned to Today'):A('ተነስቷል','Unpinned'));if(j)sel(j);render(true)}
function dlBlob(b,name){const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}
function exportICS(){const f=ST.hf,up=ST.hy==null,ja=up?TJ:jd(ST.hy,1,1),jb=up?TJ+365:jd(ST.hy,12,31),d=j=>gd(j).toISOString().slice(0,10).replace(/-/g,''),q=t=>String(t).replace(/[\\,;]/g,m=>'\\'+m);let s='BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Bisrat Tadele//Ethiopian Calendar//EN\r\nCALSCALE:GREGORIAN\r\nX-WR-CALNAME:'+q(A('የኢትዮጵያ በዓላት','Ethiopian holidays'))+'\r\n',k=0;
for(let j=ja;j<=jb;j++)hol(j).filter(x=>f=='all'||(f=='off'?x.off:x.c==f)).forEach(x=>{k++;s+=`BEGIN:VEVENT\r\nUID:${x.id}-${j}@ethcal\r\nDTSTAMP:${d(TJ)}T000000Z\r\nDTSTART;VALUE=DATE:${d(j)}\r\nDTEND;VALUE=DATE:${d(j+1)}\r\nSUMMARY:${q(n2([x.am,x.en]))}\r\nDESCRIPTION:${q(fE(j,1))}\r\nTRANSP:TRANSPARENT\r\nEND:VEVENT\r\n`});
s+='END:VCALENDAR\r\n';dlBlob(new Blob([s],{type:'text/calendar'}),'ethiopian-holidays.ics');toast(I('check')+A(`${k} በዓላት ወርደዋል`,`${k} holidays exported`))}
function copyD(j){const t=fE(j,1)+' · '+fG(j,1);const ok=()=>toast(I('check')+A('ቀኑ ተቀድቷል','Date copied'));try{navigator.clipboard.writeText(t).then(ok,()=>toast(t))}catch(e){toast(t)}}
async function nfT(){if(!NF){if(!('Notification'in window)){toast(A('ይህ አሳሽ ማሳወቂያ አይደግፍም','Notifications are not supported here'));return}let p='denied';try{p=await Notification.requestPermission()}catch(e){}if(p!='granted'){toast(A('ፈቃድ አልተሰጠም','Permission was not granted'));return}}NF=!NF;sv('nf',NF?1:0);setV();if(NF){rm('ntd');notifyCheck()}}
function notifyCheck(){try{if(!NF||!('Notification'in window)||Notification.permission!='granted'||ld('ntd')==String(TJ))return;
const tm=hol(TJ+1).filter(x=>x.off||x.c=='cus'),td=evAt(TJ),tn=evAt(TJ+1),b=[];tm.forEach(x=>b.push(A('ነገ: ','Tomorrow: ')+n2([x.am,x.en])));td.forEach(x=>b.push(A('ዛሬ: ','Today: ')+x.t));tn.forEach(x=>b.push(A('ነገ: ','Tomorrow: ')+x.t));sv('ntd',TJ);if(!b.length)return;
const t=TTL(),o={body:b.join('\n'),icon:'icon-192.png',badge:'icon-192.png',tag:'ethcal-'+TJ};(navigator.serviceWorker&&!window.Android?navigator.serviceWorker.ready:Promise.reject()).then(r=>r.showNotification(t,o)).catch(()=>{try{new Notification(t,o)}catch(e){}})}catch(e){}}
let SPLT;function showSplash(ms){const el=$('#spl');if(!el)return;clearTimeout(SPLT);$('#splt').innerHTML=[...TTL()].map((c,i)=>`<span style="--i:${i}">${c==' '?'&nbsp;':c.replace(/[<>&]/g,'')}</span>`).join('');$('#spls').textContent=TSUB();el.hidden=false;el.classList.remove('out');const bar=el.querySelector('.bar i');bar.style.setProperty('--d',(ms||ADM.spl)+'ms');bar.style.animation='none';void bar.offsetWidth;bar.style.animation='';document.body.classList.add('spl-on');SPLT=setTimeout(()=>{el.classList.add('out');document.body.classList.remove('spl-on');document.body.classList.add('spl-rev');setTimeout(()=>{document.body.classList.remove('spl-rev');if(el.classList.contains('out'))el.hidden=true},800)},ms||ADM.spl)}

/* PWA */
let DEFERRED=null;addEventListener('beforeinstallprompt',e=>{e.preventDefault();DEFERRED=e;if(ST.tab=='today')render(true)});
async function install(){if(!DEFERRED)return;DEFERRED.prompt();try{await DEFERRED.userChoice}catch(_){}DEFERRED=null;render(true)}
addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});

/* boot */
$('#bs').onclick=setV;$('#bq').onclick=openSearch;$('#bl').onclick=()=>{setL(L=='am'?'en':'am');buzz()};
$('#sh').onclick=e=>{if(e.target.id=='sh')closeSheet()};$('#fab').onclick=()=>sel(ST.tab=='cal'&&ST.mode=='m'?(ST.P=='e'?(te.y==ST.ey&&te.m==ST.em?TJ:fromE(ST.ey,ST.em,1)):(NW.getFullYear()==ST.gy&&NW.getMonth()+1==ST.gm?TJ:jd(ST.gy,ST.gm,1))):TJ,1);
const QP=new URLSearchParams(location.search);if(['cal','hol','tl','ev'].includes(QP.get('tab')))ST.tab=QP.get('tab');
sv('stl',(+(ld('stl')||0))+1);if(!ld('st0'))sv('st0',TJ);
applyTheme();render();showSplash();setTimeout(notifyCheck,ADM.spl+1500);
if(!ld('onb'))showOnb();else{const k='cf'+TJ;if(hol(TJ).some(x=>x.off)&&!ld(k)){sv(k,1);setTimeout(confetti,600)}}
try{if('serviceWorker'in navigator&&!window.Android&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{})}catch(e){}

window.__back=function(){try{const sh=$('#sh');if(sh&&!sh.hidden){closeSheet();return true}const sr=$('#srch');if(sr&&!sr.hidden){sr.hidden=true;return true}const ad=$('#spl');if(ST.tab&&ST.tab!='today'){tab('today');return true}}catch(e){}return false};
