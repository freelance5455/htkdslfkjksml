/* ቀን መቁጠሪያ — hidden admin panel. Developed by Bisrat Tadele · የተሰራው ብስራት ታደለ
   Open it: tap the logo 7 times, long-press the "Developed by" card, press Ctrl+Shift+A, or add #admin to the URL. */
function sha256(s){const K=[],H=[];let n=2,c=0;const isP=n=>{for(let i=2;i*i<=n;i++)if(n%i==0)return 0;return 1},fr=x=>(x-Math.floor(x))*4294967296|0;
while(c<64){if(isP(n)){if(c<8)H[c]=fr(Math.pow(n,1/2));K[c]=fr(Math.pow(n,1/3));c++}n++}
const b=new TextEncoder().encode(s),l=b.length,w=new Uint8Array(((l+9+63)>>6)<<6);w.set(b);w[l]=128;const dv=new DataView(w.buffer);dv.setUint32(w.length-4,l*8);
const r=(x,k)=>x>>>k|x<<(32-k),W=new Array(64);
for(let o=0;o<w.length;o+=64){for(let i=0;i<16;i++)W[i]=dv.getUint32(o+i*4)|0;for(let i=16;i<64;i++){const a=W[i-15],q=W[i-2];W[i]=(W[i-16]+(r(a,7)^r(a,18)^a>>>3)+W[i-7]+(r(q,17)^r(q,19)^q>>>10))|0}
let[a,b1,c1,d,e,f,g,h]=H;for(let i=0;i<64;i++){const t1=(h+(r(e,6)^r(e,11)^r(e,25))+(e&f^~e&g)+K[i]+W[i])|0,t2=((r(a,2)^r(a,13)^r(a,22))+(a&b1^a&c1^b1&c1))|0;h=g;g=f;f=e;e=(d+t1)|0;d=c1;c1=b1;b1=a;a=(t1+t2)|0}
[a,b1,c1,d,e,f,g,h].forEach((v,i)=>H[i]=(H[i]+v)|0)}
return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('')}

const PH0='ac462cceba949f6c68f3d6e7d2252d044a8da9dac34c86658aef608bff18a02e'; // default password, stored only as a salted SHA-256 hash
const ph=s=>sha256('ethcal|'+s);
const KEYS=['l','g','wk','th','ac','sf','ss','hp','p','ev','onb','adm','cev','aph','nf','stl','st0','annx'];
let AOK=false,ADS='ov';

/* ---- sign-in ---- */
function admEntry(){if(AOK){admV();return}buzz(20);
openSheet(`<div class="sh-h"><div><span class="adm-k">${I('shield')}${A('የተጠበቀ','Protected')}</span><h2>${A('የአስተዳዳሪ መግቢያ','Admin sign-in')}</h2><div class="meta">${A('ለመቀጠል የይለፍ ቃል ያስገቡ','Enter the password to continue')}</div></div><button class="x" onclick="closeSheet()" aria-label="Close">${I('x')}</button></div>
<div class="adm-lock">${I('lock')}</div>
<label for="apw">${A('የይለፍ ቃል','Password')}</label><div class="pw"><input id="apw" type="password" autocomplete="current-password" onkeydown="if(event.key=='Enter')admLogin()"><button class="x" onclick="const i=$('#apw');i.type=i.type=='password'?'text':'password'" aria-label="${A('አሳይ','Show password')}">${I('eye')}</button></div>
<p class="err" id="aer" role="alert"></p><button class="btn ac w" onclick="admLogin()">${I('lock')}${A('ክፈት','Unlock')}</button>`);
setTimeout(()=>$('#apw')?.focus(),250)}
function admLogin(){const lk=+(ld('alk')||0),now=Date.now(),er=$('#aer');
if(lk>now){er.textContent=A(`ብዙ ሙከራ ተደርጓል። ከ${Math.ceil((lk-now)/1000)} ሰከንድ በኋላ ይሞክሩ።`,`Too many attempts. Try again in ${Math.ceil((lk-now)/1000)}s.`);return}
const v=$('#apw').value;
if(ph(v)==(ld('aph')||PH0)){AOK=true;rm('afc');buzz(25);toast(I('check')+A('እንኳን ደህና መጡ፣ አስተዳዳሪ','Welcome back, admin'));ADS='ov';admV()}
else{const f=+(ld('afc')||0)+1;if(f>=5){sv('alk',now+60000);rm('afc')}else sv('afc',f);er.textContent=f>=5?A('5 ጊዜ ተሳስቷል። ለ1 ደቂቃ ተቆልፏል።','5 wrong attempts. Locked for 1 minute.'):A(`የተሳሳተ የይለፍ ቃል (${5-f} ሙከራ ቀርቷል)`,`Wrong password (${5-f} tries left)`);
$('#apw').value='';$('#apw').focus();buzz(60);const p=$('#shc');p.classList.remove('shake');void p.offsetWidth;p.classList.add('shake')}}
function admOut(){AOK=false;closeSheet();toast(I('lock')+A('ከአስተዳዳሪ ወጥተዋል','Signed out of admin'))}

/* ---- helpers ---- */
const saveADM=()=>{sv('adm',JSON.stringify(ADM));applyTheme();render(true)};
function admP(path,v,re){const k=path.split('.');let o=ADM;for(let i=0;i<k.length-1;i++)o=o[k[i]];o[k[k.length-1]]=v;saveADM();if(re)admV()}
const saveC=()=>{sv('cev',JSON.stringify(CUSTOM));clearCache();render(true)};
const aTg=(on,fn)=>`<button class="tg${on?' on':''}" onclick="${fn}" role="switch" aria-checked="${!!on}"></button>`;
const aRow=(ic,l,s,ctl)=>`<div class="set"><div class="l"><div class="tic">${I(ic)}</div><div>${l}${s?`<small>${s}</small>`:''}</div></div>${ctl}</div>`;
const aFlip=path=>{const k=path.split('.');let o=ADM;for(let i=0;i<k.length-1;i++)o=o[k[i]];return`admP('${path}',${o[k[k.length-1]]?0:1},1)`};
const aGet=path=>path.split('.').reduce((o,k)=>o[k],ADM);
const card=(ic,t,body)=>`<div class="card adm-c"><h4>${I(ic)}${t}</h4>${body}</div>`;
function dang(b,act){if(!b.dataset.arm){b.dataset.arm=1;b.dataset.t=b.innerHTML;b.innerHTML=I('info')+A('እርግጠኛ ነዎት? እንደገና ይንኩ','Are you sure? Tap again');setTimeout(()=>{if(b.isConnected){delete b.dataset.arm;b.innerHTML=b.dataset.t}},3500);return}
if(act=='notes'){EV=[];saveEV();toast(A('ሁሉም ማስታወሻዎች ተሰርዘዋል','All notes deleted'))}
if(act=='hols'){CUSTOM=[];saveC();toast(A('ልዩ በዓላት ተሰርዘዋል','Custom holidays deleted'))}
if(act=='cfg'){ADM=JSON.parse(JSON.stringify(ADM_D));saveADM();toast(A('ቅንብሮች ወደ መጀመሪያ ተመልሰዋል','Admin settings reset'))}
if(act=='all'){KEYS.concat(['afc','alk','ntd']).forEach(rm);toast(A('መተግበሪያው ዳግም ይጀምራል…','Restarting the app…'));setTimeout(()=>location.reload(),900);return}
render(true);admV()}

/* ---- panel ---- */
function admV(s){if(!AOK)return admEntry();const same=!s||s==ADS;if(s)ADS=s;const keep=same?$('#shc').scrollTop:0;
const tabs=[['ov','grid',A('አጠቃላይ','Overview')],['ct','mega',A('ይዘት','Content')],['hl','party',A('በዓላት','Holidays')],['lo','layout',A('ገጽታ','Layout')],['dt','db',A('ዳታ','Data')],['sc','shield',A('ደህንነት','Security')]];
let h=`<div class="sh-h"><div><span class="adm-k">${I('shield')}${A('አስተዳዳሪ','Admin')}</span><h2>${A('የቁጥጥር ማዕከል','Control center')}</h2></div><button class="x" onclick="admOut()" aria-label="${A('ውጣ','Sign out')}" title="${A('ውጣ','Sign out')}">${I('out')}</button><button class="x" onclick="closeSheet()" aria-label="Close">${I('x')}</button></div>
<div class="chips adm-tabs">${tabs.map(([k,i,l])=>`<button class="chip ${ADS==k?'on':''}" onclick="admV('${k}')">${I(i)}${l}</button>`).join('')}</div>`;
h+=({ov:aOv,ct:aCt,hl:aHl,lo:aLo,dt:aDt,sc:aSc}[ADS])();
h+=`<p class="note">${I('info')}<span>${A('ለውጦች ወዲያው ይቀመጣሉ። ይህ ፓነል በዚህ መሣሪያ ላይ ብቻ ይሠራል።','Changes save instantly. This panel controls the app on this device.')}</span></p>`;
openSheet(h);$('#shc').scrollTop=keep}

function aOv(){const kb=KEYS.reduce((t,k)=>t+(ld(k)||'').length,0)*2/1024,st0=+(ld('st0')||TJ);
const S=[[ld('stl')||1,A('ጊዜ ተከፍቷል','App opens')],[EV.length,A('ማስታወሻዎች','Notes')],[EV.filter(x=>x.p).length,A('የተሰኩ','Pinned')],[CUSTOM.length,A('ልዩ በዓላት','Custom holidays')],[TJ-st0,A('ቀናት ከጀመረ','Days in use')],[kb.toFixed(1)+' KB',A('ማከማቻ','Storage')]];
return`<div class="stg">${S.map(([v,l])=>`<div><b>${v}</b><small>${l}</small></div>`).join('')}</div>`+
card('sparkle',A('ፈጣን እርምጃዎች','Quick actions'),`<div class="f2"><button class="btn ghost" onclick="closeSheet();showSplash(2400)">${I('star')}${A('መግቢያ ገጹን እይ','Preview splash')}</button><button class="btn ghost" onclick="closeSheet();showOnb()">${I('sparkle')}${A('መግቢያውን እይ','Replay intro')}</button><button class="btn ghost" onclick="setV()">${I('set')}${A('የተጠቃሚ ሴቲንግ','User settings')}</button><button class="btn ghost" onclick="admV('ct')">${I('mega')}${A('ማስታወቂያ ጻፍ','Write announcement')}</button></div>`)+
card('check',A('ሁኔታ','Status'),aRow('mega',A('ማስታወቂያ','Announcement'),ADM.ann.on?A('በዛሬ ገጽ ላይ እየታየ ነው','Showing on Today'):A('ጠፍቷል','Off'),aTg(ADM.ann.on,aFlip('ann.on')))+
aRow('lock',A('የተጠቃሚ ሴቲንግ ቁልፍ','Lock user settings'),A('የሴቲንግ አዝራሩን ይደብቃል','Hides the settings button'),aTg(ADM.lock,aFlip('lock')))+
aRow('sparkle',A('ኮንፈቲ','Confetti on holidays'),'',aTg(ADM.cf,aFlip('cf'))))}

function aCt(){const a=ADM.ann,inp=(id,path,ph)=>`<input id="${id}" value="${esc(aGet(path)||'')}" placeholder="${esc(ph)}" maxlength="60" onchange="admP('${path}',this.value.trim())">`;
return card('star',A('የመተግበሪያ ስም','App name & tagline'),`<div class="f2"><div><label for="ta">${A('ስም (አማርኛ)','Name (Amharic)')}</label>${inp('ta','ttl.0','ቀን መቁጠሪያ')}</div><div><label for="te">${A('ስም (እንግሊዝኛ)','Name (English)')}</label>${inp('te','ttl.1','Ethiopian Calendar')}</div><div><label for="sa">${A('መግለጫ (አማርኛ)','Tagline (Amharic)')}</label>${inp('sa','sub.0','ኢትዮጵያዊ እና ግሪጎሪያን')}</div><div><label for="se">${A('መግለጫ (እንግሊዝኛ)','Tagline (English)')}</label>${inp('se','sub.1','Ethiopian & Gregorian')}</div></div><p class="hint">${A('ባዶ ከተተወ ነባሪው ይታያል። «የተሰራው በብስራት ታደለ» ሁልጊዜ ይታያል።','Leave empty for the default. “Developed by Bisrat Tadele” always stays.')}</p>`)+
card('mega',A('ማስታወቂያ','Announcement banner'),aRow('eye',A('አሳይ','Show on Today'),'',aTg(a.on,aFlip('ann.on')))+
`<label for="aa">${A('መልእክት (አማርኛ)','Message (Amharic)')}</label><textarea id="aa" maxlength="280" onchange="admP('ann.am',this.value.trim())" placeholder="${A('ለምሳሌ፦ እንኳን ለገና በዓል አደረሳችሁ!','e.g. Melkam Genna to everyone!')}">${esc(a.am)}</textarea>
<label for="ae">${A('መልእክት (እንግሊዝኛ)','Message (English)')}</label><textarea id="ae" maxlength="280" onchange="admP('ann.en',this.value.trim())">${esc(a.en)}</textarea>
<label>${A('ዓይነት','Style')}</label><div class="opts">${[['ac',A('ዋና','Accent')],['info',A('መረጃ','Info')],['alert',A('ማሳሰቢያ','Alert')],['ok',A('ደስታ','Celebrate')]].map(([k,l])=>`<button class="${a.c==k?'on':''}" onclick="admP('ann.c','${k}',1)">${l}</button>`).join('')}</div>
<button class="btn ac w" style="margin-top:14px" onclick="admP('ann.on',1);admP('ann.v',(ADM.ann.v||1)+1,1);toast(I('check')+A('ማስታወቂያው ታትሟል','Announcement published'))">${I('mega')}${A('አትም (ለሁሉም እንደገና አሳይ)','Publish (show again to everyone)')}</button>`)+
card('quote',A('የራስዎ ተረቶች','Your own proverbs'),`<label for="pv">${A('በአንድ መስመር አንድ፦ ተረት | ትርጉም','One per line: proverb | meaning')}</label><textarea id="pv" rows="5" onchange="admP('pv',this.value)" placeholder="ድር ቢያብር አንበሳ ያስር | When spider webs unite, they can tie up a lion.">${esc(ADM.pv)}</textarea>`+
aRow('quote',A('የእኔን ብቻ አሳይ','Show only mine'),A('የተዘጋጁትን 16 ይደብቃል','Hides the 16 built-in proverbs'),aTg(ADM.pvOnly,aFlip('pvOnly'))))}

let CT='e';
function aHl(){const cats=[['cus',A('ልዩ','Special')],['org',A('ኦርቶዶክስ','Orthodox')],['nat',A('ብሔራዊ','National')],['mus',A('እስልምና','Muslim')],['chr',A('ካቶሊክ/ፕሮቴስታንት','Catholic/Protestant')]];
const dsc=x=>x.t=='e'?n2(EM[x.m-1])+' '+nm(x.d)+' · '+A('በየዓመቱ','yearly'):(n2(GM[x.m-1])+' '+x.d+(x.y?', '+x.y:' · '+A('በየዓመቱ','yearly')));
const nxt=x=>{for(let k=0;k<800;k++)if(hol(TJ+k).some(h=>h.id==x.id))return TJ+k;return null};
let h=card('plus',A('አዲስ በዓል ወይም ዝግጅት','Add a holiday or event'),`<div class="f2"><div><label for="ca">${A('ስም (አማርኛ)','Name (Amharic)')}</label><input id="ca" maxlength="60"></div><div><label for="ce">${A('ስም (እንግሊዝኛ)','Name (English)')}</label><input id="ce" maxlength="60"></div></div>
<label>${A('የቀን ዓይነት','Date type')}</label><div class="opts">${[['e',A('ኢትዮጵያ · በየዓመቱ','Ethiopian · yearly')],['g',A('ግሪጎሪያን · በየዓመቱ','Gregorian · yearly')],['o',A('አንድ ጊዜ','One time')]].map(([k,l])=>`<button class="${CT==k?'on':''}" onclick="aCT('${k}')">${l}</button>`).join('')}</div>
${CT=='e'?`<div class="f2"><div><label for="cm">${A('ወር','Month')}</label><select id="cm">${EM.map((x,i)=>`<option value="${i+1}">${n2(x)}</option>`).join('')}</select></div><div><label for="cdd">${A('ቀን','Day')}</label><input id="cdd" type="number" min="1" max="30" value="1"></div></div>`:`<label for="cg">${A('ቀን','Date')}</label><input id="cg" type="date" value="${gd(TJ).toISOString().slice(0,10)}">`}
<label for="cc">${A('ምድብ','Category')}</label><select id="cc">${cats.map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select>
<label class="ck"><input type="checkbox" id="co"> ${A('የሥራ ዕረፍት ቀን ነው','It is a day off')}</label>
<label for="cx">${A('መግለጫ (አማራጭ)','Description (optional)')}</label><textarea id="cx" maxlength="400"></textarea>
<button class="btn ac w" style="margin-top:14px" onclick="admAddH()">${I('plus')}${A('በዓሉን ጨምር','Add holiday')}</button>`);
h+=card('party',A('የእርስዎ በዓላት','Your holidays')+` <span class="cnt">${CUSTOM.length}</span>`,CUSTOM.length?CUSTOM.map((x,i)=>{const n=nxt(x);return`<div class="row"><div class="av" style="--k:${CC[x.c]||CC.cus}">${emb(x.id)}</div><div class="t"><b>${esc(n2([x.am||x.en,x.en||x.am]))}</b><small>${dsc(x)}${x.off?' · '+A('ዕረፍት','day off'):''}${n!=null?' · '+rel(n-TJ):''}</small></div><button class="x" onclick="admDelH(${i})" aria-label="${A('ሰርዝ','Delete')}">${I('trash')}</button></div>`}).join(''):`<p class="hint">${A('እስካሁን ምንም የለም። የቤተሰብ፣ የድርጅት ወይም የአካባቢ በዓላትን ይጨምሩ — በቀን መቁጠሪያው፣ በበዓላት ዝርዝርና በፍለጋ ውስጥ ይታያሉ።','Nothing yet. Add family, company or local holidays; they appear on the calendar, in Holidays, search and reminders.')}</p>`);
return h}
function admAddH(){const am=$('#ca').value.trim(),en=$('#ce').value.trim();if(!am&&!en){$('#ca').focus();toast(A('ስም ያስገቡ','Please enter a name'));return}
const x={id:'cx'+Date.now().toString(36),am,en,c:$('#cc').value,off:$('#co').checked?1:0,t:CT=='e'?'e':'g'};const ds=$('#cx').value.trim();if(ds)x.ds=[ds,ds];
if(CT=='e'){x.m=+$('#cm').value;x.d=Math.min(Math.max(+$('#cdd').value||1,1),x.m==13?6:30)}else{const v=$('#cg').value;if(!v)return;const[y,m,d]=v.split('-').map(Number);x.m=m;x.d=d;if(CT=='o')x.y=y}
CUSTOM.push(x);saveC();buzz(15);toast(I('check')+A('በዓሉ ተጨምሯል','Holiday added'));admV()}
function admDelH(i){const x=CUSTOM[i];CUSTOM.splice(i,1);saveC();admV();toast(A('ተሰርዟል','Deleted'),()=>{CUSTOM.splice(i,0,x);saveC();admV()})}

function aLo(){const T=[['hol','party',A('በዓላት','Holidays')],['tl','calc',A('መሣሪያዎች','Tools')],['ev','note',A('ማስታወሻ','Notes')]];
const SC=[['cd','clock',A('የበዓል ቆጠራ','Holiday countdown')],['mycd','pin',A('የእኔ ቆጠራዎች','My countdowns')],['tags','leaf',A('የጾምና የበዓል መለያዎች','Fasting & feast tags')],['week','week',A('ይህ ሳምንት','This week')],['stats','hour',A('የዓመቱ ሂደትና ሰዓት','Year progress & clock')],['prov','quote',A('የዕለቱ ተረት','Proverb of the day')],['up','cal',A('የሚመጡ','Coming up')]];
const ac=ADM.acc||'#e9a100';
return card('grid',A('የታች ምናሌ ትሮች','Bottom tabs'),T.map(([k,i,l])=>aRow(i,l,'',aTg(ADM.tabs[k]!==0,`admP('tabs.${k}',${ADM.tabs[k]!==0?0:1},1)`))).join(''))+
card('home',A('የዛሬ ገጽ ክፍሎች','Today screen sections'),SC.map(([k,i,l])=>aRow(i,l,'',aTg(ADM.sec[k]!==0,`admP('sec.${k}',${ADM.sec[k]!==0?0:1},1)`))).join(''))+
card('sparkle',A('ባህሪያት','Features'),aRow('search',A('ፍለጋ','Search'),'',aTg(ADM.srch,aFlip('srch')))+aRow('share',A('እንደ ምስል ማጋራት','Share as image'),'',aTg(ADM.share,aFlip('share')))+aRow('sparkle',A('ኮንፈቲ','Confetti'),'',aTg(ADM.cf,aFlip('cf')))+aRow('lock',A('የተጠቃሚ ሴቲንግ ቁልፍ','Lock user settings'),'',aTg(ADM.lock,aFlip('lock'))))+
card('palette',A('የብራንድ ቀለም','Brand colour'),aRow('palette',A('የራስዎ ቀለም','Custom accent'),ADM.acc?ADM.acc.toUpperCase():A('አልተመረጠም','Not set'),`<input type="color" value="${ac}" onchange="admP('acc',this.value,1)" aria-label="${A('ቀለም','Colour')}">`)+(ADM.acc?`<button class="btn ghost w" onclick="admP('acc','',1)">${I('refresh')}${A('ወደ ነባሪ መልስ','Use preset colours')}</button>`:''))+
card('star',A('መግቢያ ገጽ (Splash)','Splash screen'),`<p class="hint">${A('«የተሰራው በብስራት ታደለ» በእያንዳንዱ ጊዜ ይታያል።','“Developed by Bisrat Tadele” shows on every launch.')}</p><label>${A('የሚቆይበት ጊዜ','Duration')}</label><div class="opts">${[[1500,'1.5s'],[2800,'2.8s'],[3600,'3.6s'],[4500,'4.5s']].map(([v,l])=>`<button class="${ADM.spl==v?'on':''}" onclick="admP('spl',${v},1)">${l}</button>`).join('')}</div><button class="btn ghost w" style="margin-top:12px" onclick="closeSheet();showSplash()">${I('eye')}${A('አሁን እይ','Preview now')}</button>`)}

function aDt(){return card('dl',A('ሙሉ ምትኬ','Full backup'),`<p class="hint">${A('ማስታወሻዎች፣ ልዩ በዓላት፣ ሴቲንግና የአስተዳዳሪ ቅንብሮች በአንድ ፋይል።','Notes, custom holidays, settings and admin config in one file.')}</p><div class="f2"><button class="btn ghost" onclick="admExp()">${I('dl')}${A('አውርድ','Download')}</button><button class="btn ghost" onclick="$('#aim').click()">${I('ul')}${A('መልስ','Restore')}</button></div><input type="file" id="aim" accept="application/json" hidden onchange="admImp(this)">`)+
card('trash',A('አደገኛ ዞን','Danger zone'),`<div class="dz"><button class="btn danger w" onclick="dang(this,'notes')">${I('trash')}${A(`ሁሉንም ማስታወሻዎች ሰርዝ (${EV.length})`,`Delete all notes (${EV.length})`)}</button><button class="btn danger w" onclick="dang(this,'hols')">${I('trash')}${A(`ልዩ በዓላትን ሰርዝ (${CUSTOM.length})`,`Delete custom holidays (${CUSTOM.length})`)}</button><button class="btn danger w" onclick="dang(this,'cfg')">${I('refresh')}${A('የአስተዳዳሪ ቅንብሮችን መልስ','Reset admin settings')}</button><button class="btn danger w" onclick="dang(this,'all')">${I('refresh')}${A('መተግበሪያውን ሙሉ በሙሉ አጽዳ','Factory reset the app')}</button></div>`)}
function admExp(){const o={app:'ethcal',v:4,kind:'full',at:new Date().toISOString(),data:{}};KEYS.filter(k=>k!='aph').forEach(k=>{const v=ld(k);if(v!=null)o.data[k]=v});dlBlob(new Blob([JSON.stringify(o,null,1)],{type:'application/json'}),'ethcal-full-backup-'+gd(TJ).toISOString().slice(0,10)+'.json');toast(I('check')+A('ሙሉ ምትኬ ወርዷል','Full backup downloaded'))}
function admImp(inp){const f=inp.files[0];if(!f)return;f.text().then(s=>{const o=JSON.parse(s);if(!o||o.app!='ethcal'||!o.data)throw 0;Object.entries(o.data).forEach(([k,v])=>{if(KEYS.includes(k)&&k!='aph'&&typeof v=='string')sv(k,v)});toast(A('ተመልሷል፤ ዳግም ይጀምራል…','Restored. Restarting…'));setTimeout(()=>location.reload(),900)}).catch(()=>toast(A('ፋይሉ ትክክለኛ ምትኬ አይደለም','That file is not a valid backup')));inp.value=''}

function aSc(){return card('lock',A('የይለፍ ቃል ቀይር','Change password'),`<label for="p0">${A('የአሁኑ','Current password')}</label><input id="p0" type="password" autocomplete="current-password"><label for="p1n">${A('አዲስ (ቢያንስ 6 ፊደል)','New (at least 6 characters)')}</label><input id="p1n" type="password" autocomplete="new-password"><label for="p2n">${A('አዲሱን ይድገሙ','Repeat new password')}</label><input id="p2n" type="password" autocomplete="new-password"><p class="err" id="per" role="alert"></p><button class="btn ac w" onclick="admPw()">${I('check')}${A('አስቀምጥ','Save password')}</button>`)+
card('shield',A('ስለ ደህንነት','About security'),`<p class="hint">${A('የይለፍ ቃሉ በቀጥታ አይቀመጥም፤ የተመሰጠረ (SHA-256) ብቻ ነው። 5 ጊዜ ከተሳሳተ ለ1 ደቂቃ ይቆለፋል። ይህ መተግበሪያ ሰርቨር ስለሌለው፣ ፓነሉ የሚቆጣጠረው ይህን መሣሪያ ብቻ ነው።','The password is never stored as plain text, only as a SHA-256 hash. Five wrong tries lock sign-in for 1 minute. Because the app has no server, this panel controls this device only.')}</p><button class="btn ghost w" onclick="admOut()">${I('out')}${A('ከአስተዳዳሪ ውጣ','Sign out of admin')}</button>`)}
function admPw(){const a=$('#p0').value,b=$('#p1n').value,c=$('#p2n').value,er=$('#per');
if(ph(a)!=(ld('aph')||PH0)){er.textContent=A('የአሁኑ የይለፍ ቃል ትክክል አይደለም','Current password is incorrect');return}
if(b.length<6){er.textContent=A('አዲሱ ቢያንስ 6 ፊደል መሆን አለበት','New password must be at least 6 characters');return}
if(b!=c){er.textContent=A('አዲሶቹ አይመሳሰሉም','New passwords do not match');return}
sv('aph',ph(b));er.textContent='';['p0','p1n','p2n'].forEach(i=>$('#'+i).value='');buzz(20);toast(I('check')+A('የይለፍ ቃሉ ተቀይሯል','Password changed'))}

/* ---- hidden entry points ---- */
(()=>{let taps=[];$('#lg').addEventListener('click',()=>{const n=Date.now();taps=taps.filter(t=>n-t<3000);taps.push(n);if(taps.length>=7){taps=[];admEntry()}});
document.addEventListener('pointerdown',e=>{const s=e.target.closest('.credit .sig');if(!s)return;const t=setTimeout(admEntry,1100),c=()=>{clearTimeout(t);['pointerup','pointercancel','pointerleave'].forEach(k=>s.removeEventListener(k,c))};['pointerup','pointercancel','pointerleave'].forEach(k=>s.addEventListener(k,c))});
document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.shiftKey&&(e.key=='A'||e.key=='a')){e.preventDefault();admEntry()}});
const hc=()=>{if(location.hash=='#admin'){history.replaceState(null,'',location.pathname+location.search);setTimeout(admEntry,ADM.spl+300)}};addEventListener('hashchange',hc);hc()})();

function aCT(k){const keep=['ca','ce','cc','co','cx'].map(i=>{const e=$('#'+i);return e?[i,e.type=='checkbox'?e.checked:e.value]:null}).filter(Boolean);CT=k;admV();keep.forEach(([i,v])=>{const e=$('#'+i);if(e){if(e.type=='checkbox')e.checked=v;else e.value=v}})}
