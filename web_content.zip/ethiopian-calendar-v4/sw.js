const C='ethcal-v4.2';
const F=['./','index.html','style.css','data.js','app.js','admin.js','native.js','manifest.json','icon.svg','icon-192.png','icon-512.png','fonts/fonts.css','fonts/fraunces-latin.woff2','fonts/notosansethiopic-ethiopic.woff2','fonts/notosansethiopic-latin.woff2','fonts/notoserifethiopic-ethiopic.woff2','fonts/notoserifethiopic-latin.woff2',
'img/onboard.webp','img/s_tseday.webp','img/s_bega.webp','img/s_belg.webp','img/s_kiremt.webp','img/h_newyear.webp','img/h_meskel.webp','img/h_genna.webp','img/h_timket.webp','img/h_fasika.webp','img/h_adwa.webp','img/h_eid.webp'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(C).then(c=>c.addAll(F)).catch(()=>{}))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin)return;
e.respondWith(caches.open(C).then(c=>c.match(e.request).then(r=>{const n=fetch(e.request).then(res=>{if(res.ok)c.put(e.request,res.clone());return res}).catch(()=>r||c.match('index.html'));return r||n})))});

self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(self.clients.matchAll({type:'window'}).then(l=>l.length?l[0].focus():self.clients.openWindow('index.html')))});
