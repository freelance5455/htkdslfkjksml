/* Android bridge: active only inside the APK (window.Android is injected natively). */
(function(){
var N=window.Android;if(!N)return;
document.documentElement.classList.add('apk');
function b64(blob){return new Promise(function(r){var f=new FileReader();f.onload=function(){r(String(f.result).split(',')[1]||'')};f.readAsDataURL(blob)})}
async function fromHref(href){var res=await fetch(href);return await res.blob()}
/* downloads: <a download href="blob:..."> */
var oc=HTMLAnchorElement.prototype.click;
HTMLAnchorElement.prototype.click=function(){
  if(this.download&&/^(blob|data):/.test(this.href)){var name=this.download,h=this.href;
    fromHref(h).then(function(bl){return b64(bl).then(function(d){N.save(name,bl.type||'application/octet-stream',d)})}).catch(function(){});return}
  return oc.apply(this,arguments)};
/* share */
navigator.canShare=function(){return true};
navigator.share=async function(o){o=o||{};
  if(o.files&&o.files.length){var f=o.files[0];N.shareFile(f.name||'file',f.type||'application/octet-stream',await b64(f),o.title||'');return}
  N.shareText(o.title||'',[o.text,o.url].filter(Boolean).join('\n'))};
/* clipboard */
try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:function(t){N.copy(String(t));return Promise.resolve()}}})}catch(e){}
/* vibration */
navigator.vibrate=function(p){try{N.vibrate(Array.isArray(p)?p[0]||20:(p||20))}catch(e){}return true};
/* notifications */
var pend=[];window.__np=function(s){NotificationShim.permission=s;pend.splice(0).forEach(function(r){r(s)})};
function NotificationShim(title,o){o=o||{};N.notify(String(title||''),String(o.body||''),String(o.tag||''))}
NotificationShim.permission=N.notifPerm();
NotificationShim.requestPermission=function(){return new Promise(function(r){var s=N.notifPerm();if(s=='granted'){r(s);return}pend.push(r);N.askNotif()})};
window.Notification=NotificationShim;
/* status/nav bar colour follows the app theme (navy during the splash) */
function bars(){try{var sp=document.getElementById('spl'),on=sp&&!sp.hidden&&!sp.classList.contains('out');
  var m=document.querySelector('meta[name=theme-color]'),c=on?'#141b3a':(m?m.content:'#f5f2ea');
  if(N.bars)N.bars(c,!on&&/^#f/i.test(c))}catch(e){}}
document.addEventListener('DOMContentLoaded',function(){bars();
  var m=document.querySelector('meta[name=theme-color]');if(m)new MutationObserver(bars).observe(m,{attributes:true});
  var sp=document.getElementById('spl');if(sp)new MutationObserver(function(){setTimeout(bars,350)}).observe(sp,{attributes:true,attributeFilter:['class','hidden']})});
})();
