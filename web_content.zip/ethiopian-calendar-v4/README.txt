ቀን መቁጠሪያ · Ethiopian & Gregorian Calendar
Developed by Bisrat Tadele · የተሰራው ብስራት ታደለ

Open index.html in a browser or host the folder (installable offline PWA).
For an Android/iOS app, wrap this folder with Capacitor or a PWA packager.
