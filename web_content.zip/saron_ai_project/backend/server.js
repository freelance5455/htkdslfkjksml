import express from 'express';

const app = express();
app.use(express.json({ limit: '1mb' }));
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Saron AI proxy' }));
app.post('/chat', async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: 'Server Gemini API key is not configured.' });
    const contents = req.body?.contents;
    if (!Array.isArray(contents) || contents.length === 0) return res.status(400).json({ error: 'A non-empty contents array is required.' });
    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: 'You are Saron AI, a helpful, clear, friendly assistant. Answer in the language used by the user.' }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 4096 }
      })
    });
    const data = await upstream.json();
    res.status(upstream.status).json(data);
  } catch (error) {
    res.status(502).json({ error: error.message || 'Gemini service unavailable.' });
  }
});
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Saron AI proxy listening on ${port}`));
