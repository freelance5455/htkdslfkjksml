SARON AI - ANDROID APK BUILDER PROJECT
======================================

CONTENTS
- index.html : required app start page for HTML/WebView APK builders
- style.css  : modern responsive dark interface
- app.js     : Gemini API connection, chat history, settings and response handling
- backend/   : optional Node.js proxy example for production deployments

BUILD AS APK
1. Extract this ZIP file.
2. Open your HTML-to-APK / WebView APK builder.
3. Select the extracted project folder or choose index.html as the start page.
4. Ensure the builder packages style.css and app.js alongside index.html.
5. Enable Internet access / network permission in the APK builder.
6. Build and install the APK on your Android phone.
7. Open Saron AI, tap the menu button, paste your Gemini API key and save.
8. Start chatting.

GEMINI API KEY
Create or manage a key in Google AI Studio:
https://aistudio.google.com/app/apikey

The app sends requests to Google's Gemini API using the key you enter. The key is saved in this app's local storage on your device. Anyone who can inspect or compromise the app/device may be able to retrieve it. Do not publish or share an APK with a personal key saved in it. For a public app, deploy the optional backend proxy and keep the key only on the server.

MODEL
Default: gemini-3.8-flash. You can change it in AI Settings. Model availability and API access depend on your Google AI Studio project and account.

TROUBLESHOOTING
- Blank page: confirm index.html is selected as the start page and all three frontend files are packaged together.
- No internet response: enable Internet permission and test the phone's connection.
- API key error: confirm the key is valid and Gemini API is enabled for its Google project.
- Model error: open AI Settings and select another model available to your API key.
- If your builder only accepts one HTML file, use a builder that supports project assets or copy the CSS and JS into index.html (this ZIP keeps files separate for easier maintenance).

This is a WebView-ready project, not a precompiled APK. APK compilation must be done by your APK builder.
