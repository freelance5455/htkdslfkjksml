'use strict';

const API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';
const STORAGE = { key: 'saron_ai_gemini_key', model: 'saron_ai_model', history: 'saron_ai_history' };
const $ = (id) => document.getElementById(id);
let history = loadHistory();
let busy = false;

function loadHistory() {
  try { const value = JSON.parse(localStorage.getItem(STORAGE.history) || '[]'); return Array.isArray(value) ? value : []; }
  catch { return []; }
}
function saveHistory() { try { localStorage.setItem(STORAGE.history, JSON.stringify(history.slice(-60))); } catch {} }
function escapeText(value) { return String(value); }
function addMessage(role, text, save = true) {
  const chat = $('chat');
  const row = document.createElement('div'); row.className = `message ${role}`;
  const avatar = document.createElement('div'); avatar.className = 'avatar'; avatar.textContent = role === 'user' ? 'You' : '✦';
  const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = escapeText(text);
  row.append(avatar, bubble); chat.appendChild(row); chat.scrollTop = chat.scrollHeight;
  if (save) { history.push({ role, text }); saveHistory(); }
  $('welcome').style.display = history.length ? 'none' : '';
  return bubble;
}
function renderHistory() {
  $('chat').innerHTML = '';
  history.forEach(item => addMessage(item.role, item.text, false));
  $('welcome').style.display = history.length ? 'none' : '';
}
function getModel() { return localStorage.getItem(STORAGE.model) || 'gemini-3.8-flash'; }
function getKey() { return (localStorage.getItem(STORAGE.key) || '').trim(); }
function setBusy(value) { busy = value; $('sendBtn').disabled = value; $('sendBtn').textContent = value ? '…' : '↑'; }

async function askGemini(userText) {
  const apiKey = getKey();
  if (!apiKey) {
    $('settingsOverlay').hidden = false;
    $('settingsStatus').textContent = 'Add your Gemini API key to start chatting.';
    throw new Error('Please add your Gemini API key in AI Settings.');
  }
  const contents = history.slice(0, -1).filter(m => m.role === 'user' || m.role === 'model').map(m => ({ role: m.role, parts: [{ text: m.text }] }));
  contents.push({ role: 'user', parts: [{ text: userText }] });
  const response = await fetch(`${API_BASE}${encodeURIComponent(getModel())}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: 'You are Saron AI, a helpful, clear, friendly assistant. Answer in the language used by the user. Be accurate and explain simply when useful.' }] },
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 4096 }
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data?.error?.message || `Gemini API request failed (${response.status}).`;
    throw new Error(message);
  }
  const answer = data?.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('').trim();
  if (!answer) throw new Error('Gemini returned an empty response. Please try again.');
  return answer;
}

async function sendMessage(text) {
  const prompt = (text || '').trim();
  if (!prompt || busy) return;
  $('promptInput').value = ''; $('promptInput').style.height = '28px';
  addMessage('user', prompt);
  setBusy(true);
  const waiting = addMessage('model', 'Saron AI is thinking…', false);
  waiting.classList.add('typing');
  try {
    const answer = await askGemini(prompt);
    waiting.parentElement.remove();
    addMessage('model', answer);
  } catch (error) {
    waiting.parentElement.remove();
    addMessage('model', `Sorry, I couldn't get a response.\n${error.message}\n\nCheck your API key and internet connection, then try again.`, false);
  } finally { setBusy(false); }
}

$('sendBtn').addEventListener('click', () => sendMessage($('promptInput').value));
$('promptInput').addEventListener('input', event => {
  event.target.style.height = '28px'; event.target.style.height = Math.min(event.target.scrollHeight, 130) + 'px';
});
$('promptInput').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(event.target.value); }
});
$('menuBtn').addEventListener('click', () => {
  $('apiKeyInput').value = getKey(); $('modelSelect').value = getModel(); $('settingsStatus').textContent = '';
  $('settingsOverlay').hidden = false;
});
$('closeSettings').addEventListener('click', () => $('settingsOverlay').hidden = true);
$('settingsOverlay').addEventListener('click', event => { if (event.target === $('settingsOverlay')) $('settingsOverlay').hidden = true; });
$('saveSettings').addEventListener('click', () => {
  const key = $('apiKeyInput').value.trim();
  if (key) localStorage.setItem(STORAGE.key, key); else localStorage.removeItem(STORAGE.key);
  localStorage.setItem(STORAGE.model, $('modelSelect').value);
  $('settingsStatus').textContent = 'Settings saved on this device.';
});
$('newChatBtn').addEventListener('click', () => {
  history = []; saveHistory(); $('chat').innerHTML = ''; $('welcome').style.display = '';
});
$('clearChatBtn').addEventListener('click', () => {
  history = []; saveHistory(); $('chat').innerHTML = ''; $('welcome').style.display = '';
  $('settingsStatus').textContent = 'Chat history cleared.';
});
document.querySelectorAll('.suggestion').forEach(button => button.addEventListener('click', () => sendMessage(button.dataset.prompt)));
renderHistory();
