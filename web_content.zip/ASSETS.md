# Adição da prévia 1.14 — menu e rota alternativa

`src/assets/menu-door-v114.webp`: imagem original gerada por IA para este projeto, de uma porta hospitalar de vidro aramado com condensação. Convertida para WebP e incorporada ao CSS/HTML; 130.866 bytes. É uma composição com aparência fotográfica, não fotografia de um hospital real. Nenhuma pessoa ou monstro foi gerado nessa imagem.

`src/menu-blood.js`: animação original em Canvas de fios, formação e queda de gotas, com gradientes/especulares e aceleração; não utiliza vídeo ou amostras externas. `src/portrait.css`: layout vertical original.

`src/trap-ending.js`: prensa de resíduos fictícia, comando, relé, placas em Canvas, progressão e sequência final criados por código. A cena reutiliza o monstro CC0 e os materiais/efeitos procedurais já documentados. Não há nova gravação de voz, fotografia ou modelo de fornecedor para a armadilha. O grito de captura continua licenciado separadamente, como abaixo.

# Adição da prévia 1.13 — grito feminino de captura

**“Scream- woman- pain 1” — Valerie-Vivegnis**, Freesound #767887, publicado em 14/11/2024. Gravação não verbal, descrita pela autora como voz feminina gritando de dor. Licença **Creative Commons Attribution 4.0 International (CC BY 4.0)**, não CC0. Não há endosso da autora.

- Fonte/autoria: https://freesound.org/people/Valerie-Vivegnis/sounds/767887/
- Licença: https://creativecommons.org/licenses/by/4.0/
- Prévia pública MP3 usada: https://cdn.freesound.org/previews/767/767887_15375955-hq.mp3
- Arquivo distribuído: `src/assets/audio/capture-female-pain.mp3`; 37.484 bytes, 3,67 segundos, mono/32 kHz/80 kbit/s.
- Alterações: corte 0,77–4,44 s, conversão mono, passa-altas 65 Hz, normalização de pico, fades e recodificação MP3.
- SHA256 distribuído: `b279b6fbf9b21115103dfb9c644a28632732928a0bfde4cbf7c1a5bb4827d0e2`. Proveniência completa no JSON adjacente.

O crédito e links da fonte/licença estão em **Ajustes → Créditos do grito de captura**, inclusive no HTML autônomo. A licença também está identificada em LICENSES.txt e no comentário do HTML exportado. O grito é incorporado, sem rede, blob ou fetch em tempo de execução. Os demais efeitos e música continuam procedurais; não há dublagem ou frases faladas. Nenhuma amostra do Pixabay foi incorporada.

O controlador `src/creature-motion.js` mistura e sincroniza os clipes do monstro CC0 já creditado abaixo, com complementos procedurais e ataque autoral; não são novos clipes capturados ou IK completo.

## Adição da prévia 1.12 — O Último Turno

Menu, manchas, escorridos e animações de gotas originais em HTML/CSS (`src/title-screen.css`). Nenhuma imagem ou fonte externa nova. `src/embedded-gltf.js` altera somente o mecanismo de leitura do mesmo GLB CC0 já documentado, sem rede/fetch/blob; não troca o modelo, a autoria ou a licença. Título e créditos visíveis atualizados para O Último Turno; créditos históricos de fornecedores preservados.

Para armazenamento do projeto, fabric.png e tiles.png de origem foram convertidos sem perdas para `src/assets/original-sources/*-lossless.webp`, com verificação de igualdade de pixels. As versões otimizadas WebP usadas pelo jogo são as mesmas de antes. Restauração opcional dos PNGs: `python scripts/restore-source-pngs.py`.

## Adição da prévia 1.10 — equipamentos hospitalares

`src/hospital-equipment.js`: geometria procedural original de grades, mecanismos de leito, suportes de soro e bolsas, carrinhos tubulares, rodízios, bandejas em formato de rim, tesouras e armários. Etiquetas e atlas originais desenhados em Canvas; gaze e campo cirúrgico reutilizam o tecido procedural de `clinical-materials.js`. Nenhum novo arquivo de fornecedor, modelo baixado ou áudio nesta rodada. Sem novas exigências de atribuição. Os modelos CC0 e imagens já incorporados continuam documentados abaixo. Vidro opaco, tubo e tecido estáticos, sem simulação física.

# Origem dos recursos — Último Plantão 1.5

As oito imagens abaixo foram geradas por IA especificamente para este projeto. Pessoas e noticiário são fictícios. Não há fotografias de indivíduos identificados, capturas de um telejornal real, modelos humanos escaneados ou imagens baixadas de bibliotecas externas.

| Arquivo em `src/assets/` | Uso |
|---|---|
| `vigilante-face.webp` | Rosto projetado na cabeça 3D do Vigilante |
| `patient-face.webp` | Rosto masculino de paciente adulto fictício |
| `patient-woman.webp` | Rosto feminino de paciente adulto fictício; recorte quadrado |
| `anchor.webp` | Apresentador fictício na textura animada da TV |
| `marta-memory.webp` | Fotografia de família fictícia de Marta, na abertura |
| `fabric.webp` | Tecido hospitalar envelhecido |
| `plaster.webp` | Reboco e faixa de azulejos das paredes |
| `tiles.webp` | Piso desgastado de granilite/cerâmica |

As imagens foram comprimidas em WebP; a paciente feminina foi recortada para a projeção facial. Os originais PNG de trabalho não são necessários à execução e não fazem parte do pacote distribuído. Os imports `?inline` incorporam todos os WebP ao HTML final. Normal e rugosidade das superfícies são sintetizados no navegador a partir da luminância das imagens, não de escaneamentos PBR reais.

Geometria, articulações, deformações, materiais adicionais e interfaces foram criados por código. O noticiário é uma composição 2D animada numa TV 3D; não é um serviço ao vivo. As cutscenes são renderizadas pelo próprio jogo.

Na versão 1.5, efeitos e música eram sintetizados por Web Audio, sem amostras de terceiros. Na 1.13 foi incorporado o grito CC BY 4.0 documentado no início deste arquivo. Os diálogos são legendados, sem dublagem. O projeto utiliza Three.js sob MIT; o texto da licença está em `LICENSES.txt`.

## Geometria anatômica da prévia 1.6

`src/assets/anatomy.json` adapta a malha hm08 e o rig padrão do MakeHuman Community, liberados sob CC0. Origem: https://github.com/makehumancommunity/makehuman — arquivos `makehuman/data/3dobjs/base.obj`, `makehuman/data/rigs/default.mhskel` e `default_weights.mhw`. A malha identifica os autores Data Collection AB, Joel Palmius e Jonas Hauquier. A licença integral CC0 foi acrescentada a `LICENSES.txt`.

Esta prévia usa 163 ossos por personagem animado; os corpos examináveis têm as poses convertidas em malhas estáticas. Roupas, corte do casaco, uniformes, máscaras, materiais, adaptação facial e integração foram modificados/construídos para o jogo. A base anatômica não foi criada do zero neste projeto. Todos os personagens são exibidos vestidos. O rosto do Vigilante e a luva mantêm partes da versão procedural anterior.

## Acabamento da prévia 1.7

Sem novas imagens externas. Os normais/rugosidade do tecido são derivados da imagem já incorporada. Dobras, lapelas com espessura, bolsos curvados, punhos, costuras, alterações faciais, morphs e poses foram construídos/modificados por código. Marcas de contato, umidade e ferrugem são geradas proceduralmente e posicionadas em faces expostas/encaixes, sem alterar a licença CC0 da base. O acabamento não constitui escaneamento físico nem animação capturada de atores.

## Monstro integrado na prévia 1.8 — CC0, download direto

O Vigilante foi substituído por uma adaptação do **3D Horror Game Monster**, publicado por **City Building Game Art / HorrorGameMaker.com** no OpenGameArt. A página declara licença **CC0** e os pacotes foram obtidos sem conta, cookies de autenticação ou API com chave:

- Página e declaração de licença: https://opengameart.org/content/3d-horror-game-monster
- Modelo e animações originais: https://opengameart.org/sites/default/files/Poses.zip
- Cores e texturas: https://opengameart.org/sites/default/files/Colors.zip
- CC0: https://creativecommons.org/publicdomain/zero/1.0/

`src/assets/creature/idle.glb` contém a geometria, rig deformador de 70 ossos, mapas de cor/normal incorporados e a animação de espera. `locomotion.json` contém as animações de caminhada e corrida derivadas do pacote do mesmo autor. Foram convertidas com Blender, otimizadas, redimensionadas e adaptadas para Three.js. Texturas originalmente grandes foram reduzidas para 1024 pixels. O conjunto de execução ocupa aproximadamente 915 KB antes da incorporação ao HTML. O projeto dá crédito ao autor mesmo que CC0 não o exija.

A seleção, transições, velocidade dos clipes, remoção de deriva horizontal, gesto adicional de ataque, escala, integração de colisão/IA e cópia para as cenas foram implementados neste projeto. Não são captura de movimento nova. O monstro não é o Behemoth de Final Fantasy/Sketchfab: esse modelo não foi baixado nem incorporado.

O candidato de EmoPreben foi apenas avaliado e não é distribuído. Os arquivos grandes de trabalho não são necessários para executar o jogo.

**Pixabay:** as páginas foram consultadas, mas os pedidos de download de áudio retornaram HTTP 403 no ambiente. Nenhum som do Pixabay foi incorporado nesta versão; os efeitos e música existentes continuam procedurais, sem frases ou dublagem. Não se deve atribuir os sons existentes ao Pixabay.

## Ambiente clínico da prévia 1.9

Novos detalhes criados por código para o projeto, sem novos downloads: atlas de placas hospitalares em português, trama de tecido, vidro aramado escurecido, forro em placas, cortinas geométricas, cabeceiras, colchões, travesseiros, lençóis, pastas/estantes, armários de parede, tubulação/manômetro e luminária cirúrgica. Não são escaneamentos físicos. Os pisos/parede continuam usando as texturas originais geradas por IA e seus mapas derivados, incorporados ao HTML. As janelas não simulam reflexão/exterior real e as cortinas não têm simulação de tecido. Créditos do monstro CC0 e da base MakeHuman permanecem inalterados.
