import { chromium } from 'playwright';
const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium_headless_shell-1148/chrome-linux/headless_shell', args: ['--no-sandbox','--disable-gpu'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
await page.goto('http://localhost:4173/', { waitUntil: 'networkidle' });
await page.waitForTimeout(500);
// buy glacier should fail (250 coins)
await page.getByRole('button', { name: 'Skins', exact: true }).first().click();
await page.waitForTimeout(300);
await page.getByRole('button', { name: /450/ }).click();
await page.waitForTimeout(300);
console.log('toast coins:', await page.locator('body').innerText().then(t => /Need 200 more coins/.test(t)));
// settings
await page.getByRole('button', { name: 'Settings' }).click();
await page.waitForTimeout(300);
await page.getByRole('textbox', { name: /Player name/i }).fill('Sanduni');
await page.keyboard.press('Escape');
await page.waitForTimeout(200);
// start game
await page.getByRole('button', { name: 'Play next level' }).click().catch(()=>{});
await page.waitForTimeout(200);
await page.getByRole('button', { name: 'Levels', exact: true }).first().click();
await page.waitForTimeout(300);
await page.getByRole('button', { name: '13', exact: true }).click();
await page.waitForTimeout(400);
// dismiss tutorial if present
const tut = page.getByRole('button', { name: /Start level/ });
if (await tut.count()) await tut.click();
await page.waitForTimeout(500);
const canvas = page.locator('canvas');
const box = await canvas.boundingBox();
// tap until some layers break; release near gaps
for (let i=0;i<24;i++){
  await page.mouse.move(box.x + box.width/2, box.y + box.height*0.44);
  await page.mouse.down();
  await page.waitForTimeout(420);
  await page.mouse.up();
  await page.waitForTimeout(380);
}
await page.screenshot({ path: 'qa/game-progress2.png' });
const txt = await page.locator('body').innerText();
console.log('progress:', /of \d+ layers down|layers/.test(txt));
// pause
await page.getByRole('button', { name: /Pause/ }).first().click();
await page.waitForTimeout(300);
await page.screenshot({ path: 'qa/pause.png' });
await page.getByRole('button', { name: /Resume descent/ }).click();
await page.waitForTimeout(200);
// reload persistence
await page.reload({ waitUntil: 'networkidle' });
await page.waitForTimeout(400);
const body = await page.locator('body').innerText();
console.log('name persisted:', /Sanduni/.test(body));
await page.screenshot({ path: 'qa/after-reload.png' });
console.log('ERRORS:', JSON.stringify(errors));
await browser.close();
