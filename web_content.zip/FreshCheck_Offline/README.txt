FreshCheck — version Offline
===========================
Cette version ne dépend pas d'un serveur pour les fonctions principales.
- Fonctionne sans Internet après installation.
- Données produits conservées localement sur le téléphone.
- États vert/orange/rouge calculés localement.
- Langues intégrées.
- Recettes et illustrations intégrées localement.
- Aucun produit de démonstration.
- Photo de la date possible; si la date est difficile à lire, saisie manuelle.
- Pour un vrai OCR hors-ligne, il faudra intégrer un moteur OCR Android natif lors de la conversion APK.
- Les notifications Android locales devront être activées/programméess dans le wrapper Android final.
