import './style.css';

const defaultChats = [
  { id: 1, name: 'Areeb Khan', avatar: 'AK', text: 'The notes are ready.', time: '10:42', unread: 2, online: true, starred: false },
  { id: 2, name: 'Study Group', avatar: 'SG', text: 'Sara: chapter 4 is important', time: '10:18', unread: 5, online: false, starred: true },
  { id: 3, name: 'Hassan', avatar: 'H', text: 'Send me the file when free', time: 'Yesterday', unread: 0, online: true, starred: false },
  { id: 4, name: 'Family', avatar: 'F', text: 'Ammi: Remember the groceries', time: 'Yesterday', unread: 0, online: false, starred: true },
  { id: 5, name: 'NOVA Updates', avatar: 'N', text: 'Welcome to your NOVA space', time: 'Mon', unread: 0, online: false, starred: false }
];
const state = {
  tab: 'Chats', selected: 1, dark: true,
  chats: JSON.parse(localStorage.getItem('nova.chats') || 'null') || defaultChats,
  messages: JSON.parse(localStorage.getItem('nova.messages') || 'null') || {
    1: [{id:11,from:'them',text:'Assalam-o-alaikum! Notes ready hain.',time:'10:40',starred:false},{id:12,from:'me',text:'Great, thank you.',time:'10:41',starred:true},{id:13,from:'them',text:'The notes are ready.',time:'10:42',starred:false}],
    2: [{id:21,from:'them',text:'Chapter 4 is important for the test.',time:'10:18',starred:true}],
    3: [{id:31,from:'them',text:'Send me the file when free.',time:'Yesterday',starred:false}],
    4: [{id:41,from:'them',text:'Remember the groceries.',time:'Yesterday',starred:false}],
    5: [{id:51,from:'them',text:'Welcome to your NOVA space.',time:'Mon',starred:false}]
  },
  notes: JSON.parse(localStorage.getItem('nova.notes') || 'null') || [],
  statuses: [{name:'Your status',avatar:'+',time:'Add an update'},{name:'Areeb',avatar:'AK',time:'12 min ago'},{name:'Sara',avatar:'S',time:'35 min ago'}],
  search: '', menuOpen: false
};
function save(){
  localStorage.setItem('nova.chats', JSON.stringify(state.chats));
  localStorage.setItem('nova.messages', JSON.stringify(state.messages));
  localStorage.setItem('nova.notes', JSON.stringify(state.notes));
}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function activeChat(){return state.chats.find(c=>c.id===state.selected)||state.chats[0];}
function icon(name){
 const paths={
  chats:'<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8A8.5 8.5 0 0 1 8.7 4a8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>',
  status:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  calls:'<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7l.5 2.8a2 2 0 0 1-.6 1.9L7.7 9.7a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 1.9-.6l2.8.5a2 2 0 0 1 1.7 2.6z"/>',
  communities:'<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  tools:'<path d="M12 3v18M3 12h18"/><rect x="4" y="4" width="16" height="16" rx="3"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  star:'<path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a8 8 0 0 1-1.8 1l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.8-1l-1.7.6-1.4-2.4L7.1 15a8 8 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.7.6a8 8 0 0 1 1.8-1l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.8 1l1.7-.6 1.4 2.4-1.4 1.1a8 8 0 0 1-.1 2z"/>'
 };
 return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.tools}</svg>`;
}
function render(){
 document.body.classList.toggle('light',!state.dark);
 const chat=activeChat();
 const filtered=state.chats.filter(c=>(c.name+' '+c.text).toLowerCase().includes(state.search.toLowerCase()));
 const starred=Object.entries(state.messages).flatMap(([cid,msgs])=>msgs.filter(m=>m.starred).map(m=>({...m,chatName:state.chats.find(c=>c.id===Number(cid))?.name||'Chat'})));
 let content='';
 if(state.tab==='Chats'){
   content=`<div class="workspace">
    <aside class="list-panel">
      <div class="panel-top"><div><span class="eyebrow">YOUR SPACE</span><h1>Messages</h1></div><button class="round-btn" data-action="new-chat" aria-label="New chat">＋</button></div>
      <label class="searchbox">${icon('search')}<input id="search" placeholder="Search chats..." value="${esc(state.search)}"></label>
      <div class="filter-row"><button class="chip active" data-action="filter-all">All</button><button class="chip" data-action="filter-unread">Unread</button><button class="chip" data-action="filter-starred">Starred</button></div>
      <div class="chat-list">${filtered.map(c=>`<button class="chat-row ${c.id===state.selected?'selected':''}" data-chat="${c.id}"><div class="avatar ${c.online?'online':''}">${esc(c.avatar)}</div><div class="chat-info"><div class="chat-title"><b>${esc(c.name)}</b><time>${esc(c.time)}</time></div><div class="chat-preview">${c.starred?'<span class="tiny-star">★</span>':''}${esc(c.text)}</div></div>${c.unread?`<span class="unread">${c.unread}</span>`:''}</button>`).join('')}</div>
      <div class="privacy-note">Demo mode · Messages are saved on this device</div>
    </aside>
    <section class="conversation">
      <header class="conversation-head"><div class="avatar ${chat.online?'online':''}">${esc(chat.avatar)}</div><div class="person"><b>${esc(chat.name)}</b><small>${chat.online?'Online':'Last seen recently'}</small></div><div class="head-actions"><button class="icon-btn" data-action="search-message" title="Search">${icon('search')}</button><button class="icon-btn" data-action="call" title="Call">${icon('calls')}</button><button class="icon-btn" data-action="chat-menu" title="More">•••</button></div></header>
      <div class="chat-banner"><span>✦</span> A calmer space to connect. Never share verification codes.</div>
      <div class="message-list" id="messageList">${(state.messages[chat.id]||[]).map(m=>`<div class="message ${m.from==='me'?'mine':''}"><div class="bubble">${esc(m.text)}<div class="bubble-meta"><time>${esc(m.time)}</time><button data-star="${chat.id}:${m.id}" class="star-message ${m.starred?'on':''}" title="${m.starred?'Unstar message':'Star message'}">★</button></div></div></div>`).join('')}</div>
      <form id="sendForm" class="composer"><button type="button" class="attach-btn" data-action="attach" title="Attach">＋</button><input id="messageInput" autocomplete="off" placeholder="Write a message..." maxlength="2000"><button type="button" class="emoji-btn" data-action="emoji" title="Add symbol">☺</button><button class="send-btn" type="submit" aria-label="Send">➤</button></form>
      <div class="composer-foot">Enter to send · Star messages to find them later</div>
    </section>
   </div>`;
 } else if(state.tab==='Starred'){
   content=`<section class="page"><div class="page-head"><div><span class="eyebrow">SAVED FOR LATER</span><h1>Starred messages</h1><p>Important messages collected in one place.</p></div>${icon('star')}</div><div class="saved-list">${starred.length?starred.map(m=>`<article class="saved-card"><div class="saved-top"><b>${esc(m.chatName)}</b><button data-star="${Object.keys(state.messages).find(cid=>state.messages[cid].some(x=>x.id===m.id))}:${m.id}" class="star-message on">★</button></div><p>${esc(m.text)}</p><small>${esc(m.time)}</small></article>`).join(''):'<div class="empty"><div>☆</div><h3>No starred messages yet</h3><p>Open a chat and tap ★ beside any message.</p></div>'}</div></section>`;
 } else if(state.tab==='Status'){
   content=`<section class="page"><div class="page-head"><div><span class="eyebrow">LIFE IN MOMENTS</span><h1>Status</h1><p>Share a small update with your people.</p></div><button class="primary-btn" data-action="new-status">＋ Add status</button></div><div class="status-grid">${state.statuses.map((s,i)=>`<button class="status-card" data-status="${i}"><div class="status-ring"><div class="avatar">${esc(s.avatar)}</div></div><b>${esc(s.name)}</b><small>${esc(s.time)}</small></button>`).join('')}</div><p class="muted">Status publishing is a local demo in this build.</p></section>`;
 } else if(state.tab==='Calls'){
   content=`<section class="page"><div class="page-head"><div><span class="eyebrow">STAY IN TOUCH</span><h1>Calls</h1><p>Call controls will connect after the live service is configured.</p></div>${icon('calls')}</div><div class="feature-grid"><article class="feature-card"><span class="feature-icon">${icon('calls')}</span><h3>Voice calls</h3><p>Talk to your contacts in real time.</p><span class="tag">Coming with server setup</span></article><article class="feature-card"><span class="feature-icon">▣</span><h3>Video calls</h3><p>Face-to-face conversations with privacy controls.</p><span class="tag">Coming with server setup</span></article></div></section>`;
 } else if(state.tab==='Communities'){
   content=`<section class="page"><div class="page-head"><div><span class="eyebrow">PEOPLE WITH A PURPOSE</span><h1>Communities</h1><p>Bring groups, classes and shared interests together.</p></div><button class="primary-btn" data-action="new-community">＋ Create</button></div><div class="feature-grid"><article class="feature-card"><span class="feature-icon">◈</span><h3>Study Circle</h3><p>Share learning resources and announcements.</p><span class="tag">Sample community</span></article><article class="feature-card"><span class="feature-icon">⌘</span><h3>Project Room</h3><p>Keep group discussions organized by topic.</p><span class="tag">Sample community</span></article></div></section>`;
 } else if(state.tab==='Tools'){
   content=`<section class="page"><div class="page-head"><div><span class="eyebrow">MORE THAN MESSAGES</span><h1>NOVA Tools</h1><p>A starting point for your wider NOVA project.</p></div>${icon('tools')}</div><div class="tool-grid"><button class="tool-card" data-action="notes"><span>▤</span><b>Quick Notes</b><small>Write and save ideas on this device</small></button><button class="tool-card" data-action="tasks"><span>✓</span><b>Tasks</b><small>Make a simple to-do list</small></button><button class="tool-card" data-action="files"><span>↥</span><b>File sharing</b><small>Planned for server-connected version</small></button><button class="tool-card" data-action="privacy"><span>◇</span><b>Privacy Center</b><small>Learn about account safety</small></button></div><div id="toolContent"></div></section>`;
 } else if(state.tab==='Settings'){
   content=`<section class="page"><div class="page-head"><div><span class="eyebrow">MAKE IT YOURS</span><h1>Settings</h1><p>Personalize your NOVA experience.</p></div>${icon('settings')}</div><div class="settings-list"><button class="setting-row" data-action="theme"><span class="setting-symbol">◐</span><span><b>Appearance</b><small>Switch between dark and light mode</small></span><strong>${state.dark?'Dark':'Light'}</strong></button><button class="setting-row" data-action="profile"><span class="setting-symbol">◎</span><span><b>Profile</b><small>Display name and profile details</small></span><strong>›</strong></button><button class="setting-row" data-action="privacy"><span class="setting-symbol">◇</span><span><b>Privacy and safety</b><small>Account safety guidance</small></span><strong>›</strong></button><button class="setting-row" data-action="about"><span class="setting-symbol">✦</span><span><b>About NOVA</b><small>Public app preview · v0.1</small></span><strong>›</strong></button></div></section>`;
 }
 document.querySelector('#app').innerHTML=`<div class="app-shell"><aside class="rail"><div class="brand-mark">N<span>•</span></div><div class="rail-nav">${[['Chats','chats'],['Status','status'],['Calls','calls'],['Communities','communities'],['Tools','tools']].map(([t,i])=>`<button class="rail-btn ${state.tab===t?'active':''}" data-tab="${t}" title="${t}">${icon(i)}<span>${t}</span></button>`).join('')}</div><div class="rail-bottom"><button class="rail-btn ${state.tab==='Starred'?'active':''}" data-tab="Starred" title="Starred">${icon('star')}<span>Starred</span></button><button class="rail-btn ${state.tab==='Settings'?'active':''}" data-tab="Settings" title="Settings">${icon('settings')}<span>Settings</span></button><div class="profile-mini">N</div></div></aside><main class="main-area"><div class="mobile-top"><div class="brand-word">NOVA<span>•</span></div><button class="icon-btn" data-tab="Settings">${icon('settings')}</button></div>${content}</main></div>`;
 bind();
}
function bind(){
 document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;render();});
 document.querySelectorAll('[data-chat]').forEach(b=>b.onclick=()=>{state.selected=Number(b.dataset.chat);state.tab='Chats';render();});
 const search=document.querySelector('#search'); if(search) search.oninput=e=>{const p=e.target.selectionStart;state.search=e.target.value;render();const n=document.querySelector('#search');n.focus();n.setSelectionRange(p,p);};
 const form=document.querySelector('#sendForm');if(form)form.onsubmit=e=>{e.preventDefault();const input=document.querySelector('#messageInput');const text=input.value.trim();if(!text)return;const id=state.selected;state.messages[id] ||= [];const now=new Date();const time=now.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});state.messages[id].push({id:Date.now(),from:'me',text,time,starred:false});const c=state.chats.find(x=>x.id===id);c.text=text;c.time=time;save();render();document.querySelector('#messageList')?.scrollTo(0,99999);};
 document.querySelectorAll('[data-star]').forEach(b=>b.onclick=e=>{e.stopPropagation();const [cid,mid]=b.dataset.star.split(':').map(Number);const m=(state.messages[cid]||[]).find(x=>x.id===mid);if(m){m.starred=!m.starred;save();render();}});
 document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>action(b.dataset.action));
 document.querySelectorAll('[data-status]').forEach(b=>b.onclick=()=>toast('Status viewer is a preview. Online sharing needs the NOVA server.'));
}
function toast(msg){let t=document.querySelector('.toast');if(!t){t=document.createElement('div');t.className='toast';document.body.append(t);}t.textContent=msg;t.classList.add('show');clearTimeout(window.novaToast);window.novaToast=setTimeout(()=>t.classList.remove('show'),2600);}
function action(a){
 if(a==='theme'){state.dark=!state.dark;render();}
 else if(a==='new-chat'){const name=prompt('Contact or group name:');if(name?.trim()){const id=Date.now();state.chats.unshift({id,name:name.trim(),avatar:name.trim().slice(0,2).toUpperCase(),text:'Start a new conversation',time:'Now',unread:0,online:false,starred:false});state.messages[id]=[];state.selected=id;save();render();}}
 else if(a==='emoji'){const i=document.querySelector('#messageInput');if(i){i.value+=' 🙂';i.focus();}}
 else if(a==='attach'){toast('Attachments will be enabled when file storage is connected to the server.');}
 else if(a==='call'){toast('Calls need the live NOVA server and calling service.');}
 else if(a==='search-message'){const q=prompt('Search messages in this chat:');if(q){const hits=(state.messages[state.selected]||[]).filter(m=>m.text.toLowerCase().includes(q.toLowerCase()));toast(`${hits.length} matching message(s) in this chat.`);}}
 else if(a==='chat-menu'){const c=activeChat();const choice=prompt('Chat options:\\n1. Star/unstar chat\\n2. Clear local messages\\n3. Report a problem\\nEnter 1, 2 or 3');if(choice==='1'){c.starred=!c.starred;save();render();}else if(choice==='2'&&confirm('Clear messages saved on this device?')){state.messages[c.id]=[];save();render();}else if(choice==='3'){const reason=prompt('Describe the problem (demo only):');if(reason)toast('Report form preview: server submission is not connected yet.');}}
 else if(a==='new-status'){const text=prompt('Write a status update:');if(text?.trim()){state.statuses.unshift({name:'Your status',avatar:'N',time:'Just now · '+text.trim().slice(0,36)});render();}}
 else if(a==='new-community'){const name=prompt('Community name:');if(name?.trim())toast(`“${name.trim()}” is noted for the next community build.`);}
 else if(a==='notes'){const text=prompt('Quick note:');if(text?.trim()){state.notes.unshift({id:Date.now(),text:text.trim(),time:new Date().toLocaleString()});save();toast('Note saved on this device.');document.querySelector('#toolContent').innerHTML=`<div class="notes-box"><h3>Your saved notes</h3>${state.notes.map(n=>`<p>${esc(n.text)}<small>${esc(n.time)}</small></p>`).join('')}</div>`;}}
 else if(a==='tasks'){const task=prompt('New task:');if(task?.trim())toast('Task preview created: '+task.trim());}
 else if(a==='files')toast('File sharing will need server storage and access controls.');
 else if(a==='privacy')alert('NOVA safety: never share OTP codes. Report harmful behavior through the in-app report form once server services are enabled. This preview stores messages locally on this device.');
 else if(a==='profile'){const name=prompt('Display name (preview only):','NOVA User');if(name?.trim())toast('Profile editing will be connected to your account after backend setup.');}
 else if(a==='about')alert('NOVA Public App · Preview v0.1\\nThis build demonstrates the interface and local-only features. It is not yet a live messaging service.'); 
 else if(a==='filter-all'){state.search='';render();}
 else if(a==='filter-unread'){const c=state.chats.find(x=>x.unread>0);if(c){state.selected=c.id;state.tab='Chats';render();}else toast('No unread chats in this demo.');}
 else if(a==='filter-starred'){state.tab='Starred';render();}
}
render();