# NOVA — Public App starter

This is a **mobile-friendly public-app prototype** for NOVA, configured to build an Android debug APK through GitHub Actions. It is not a ZIP that can be renamed to `.apk`.

## Current features in this preview
- NOVA multi-section interface: Chats, Status, Calls, Communities, Tools, Starred messages, Settings
- Demo conversations and local message sending
- Star/unstar messages and a Starred Messages view
- Search chat list, unread/starred filters
- Create a local demo chat
- Local notes, theme switch, sample communities/status cards
- Responsive layout for Android phones
- GitHub Actions workflow that builds and uploads a debug APK

## Important limitations
- This is a **local UI prototype**, not yet a real public messaging service.
- Demo chats/messages/notes are stored in this browser/app on this device only.
- SMS/OTP login, real user accounts, online presence, server-backed reports, admin moderation, real calls, cloud sync, file uploads, end-to-end encryption and production security are **not implemented**.
- Do not use this prototype for sensitive or private conversations.
- The debug APK is for testing. A production release needs app signing and security review.

## Build an APK using only your phone
1. Sign in to GitHub or create an account.
2. Create a new repository named `nova-public-app`.
3. Upload the **contents** of this ZIP to the repository (not the ZIP itself). Make sure `.github/workflows/build-apk.yml` is included. On mobile GitHub, you may need to use the browser's desktop-site option to upload folders/files conveniently.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Choose **Build NOVA Android APK**, then tap **Run workflow** if it did not start automatically.
6. Wait for the workflow to finish successfully.
7. Open that workflow run, scroll to **Artifacts**, and download `NOVA-debug-APK`.
8. Extract the downloaded artifact ZIP. Inside it is `app-debug.apk`. Install that `.apk` file on your Android phone. Do not rename the project ZIP to APK.
9. If Android blocks installation, allow “Install unknown apps” for the browser/file manager you used to open the APK. Only install APKs you built or trust.

## If GitHub build fails
Open the failed workflow, copy the red error lines, and use them to troubleshoot. Do not assume an APK was produced unless the workflow succeeded and the APK artifact is present.

## Next development phase
Add a real backend, phone OTP authentication, persistent chat database, server-side authorization, reporting/appeals and privacy-respecting moderation before treating NOVA as a live service.
