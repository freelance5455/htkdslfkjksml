ASYM 2D — projeto Android (WebView)

Este projeto envolve a versão HTML/CSS/JavaScript enviada em um app Android nativo que abre o jogo em tela cheia e em modo paisagem.

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Abra a pasta ASYM2D_Android no Android Studio (Open).
3. Aguarde a sincronização do Gradle e instale os componentes SDK sugeridos.
4. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
5. Quando terminar, clique em locate para encontrar o APK.

Requisitos: Android Studio, JDK compatível e Android SDK Platform 35. O projeto usa Gradle 8.9+ por meio do plugin Android Gradle 8.7.3.

Observação: este ambiente não tem Android SDK nem Gradle instalados, então o APK não foi compilado aqui. O projeto-fonte está preparado para compilar no Android Studio.
