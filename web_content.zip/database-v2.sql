-- CONNECTLY V2 DATABASE UPDATE

-- Make usernames unique (case-insensitive).
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique_lower
ON public.profiles (LOWER(username))
WHERE username IS NOT NULL AND BTRIM(username) <> '';

-- Save lowercase usernames during registration.
CREATE OR REPLACE FUNCTION public.connectly_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (id, email, username)
    VALUES (
        NEW.id,
        NEW.email,
        LOWER(NEW.raw_user_meta_data ->> 'username')
    )
    ON CONFLICT (id)
    DO UPDATE SET
        email = EXCLUDED.email,
        username = COALESCE(public.profiles.username, EXCLUDED.username);

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS connectly_auth_user_created ON auth.users;

CREATE TRIGGER connectly_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.connectly_new_user();
