package com.warehouse.inventory

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                installNativeScannerButton()
            }
        }
        webView.addJavascriptInterface(NativeScannerBridge(), "AndroidScanner")
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun installNativeScannerButton() {
        val js = """
            (function(){
              const b=document.getElementById('cameraBtn');
              if(!b || b.dataset.nativeScanner==='1') return;
              b.dataset.nativeScanner='1';
              b.addEventListener('click', function(e){
                e.preventDefault(); e.stopImmediatePropagation();
                if(window.AndroidScanner) window.AndroidScanner.startScan();
              }, true);
              const p=document.querySelector('#scan .sub');
              if(p) p.textContent='اضغط بدء المسح لفتح ماسح الباركود بالكاميرا. يتم حفظ الكود وتاريخ ووقت المسح تلقائياً.';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    inner class NativeScannerBridge {
        @JavascriptInterface
        fun vibrate(kind: String) {
            try {
                val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val manager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    manager.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    getSystemService(VIBRATOR_SERVICE) as Vibrator
                }
                if (!vibrator.hasVibrator()) return
                val timings = when (kind) {
                    "duplicate" -> longArrayOf(0, 260, 90, 260)
                    "invalid" -> longArrayOf(0, 90, 50, 90)
                    else -> longArrayOf(0, 110)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(timings, -1)
                }
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun startScan() {
            runOnUiThread {
                try {
                    val scanner = GmsBarcodeScanning.getClient(this@MainActivity)
                    scanner.startScan()
                        .addOnSuccessListener { barcode ->
                            val value = barcode.rawValue
                            if (!value.isNullOrBlank()) {
                                val quoted = org.json.JSONObject.quote(value)
                                webView.evaluateJavascript(
                                    "document.getElementById('scanCode').value=$quoted; document.getElementById('addScan').click();",
                                    null
                                )
                            } else {
                                Toast.makeText(this@MainActivity, "لم تتم قراءة باركود", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .addOnCanceledListener {
                            Toast.makeText(this@MainActivity, "تم إلغاء المسح", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { error ->
                            Toast.makeText(this@MainActivity, "تعذر فتح ماسح الباركود: ${error.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر تشغيل الماسح: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
