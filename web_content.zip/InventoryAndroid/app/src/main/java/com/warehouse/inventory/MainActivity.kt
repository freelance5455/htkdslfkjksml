package com.warehouse.inventory

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var noReadTimeout: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                installNativeScannerButton()
            }
        }
        webView.addJavascriptInterface(NativeScannerBridge(), "AndroidScanner")
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun installNativeScannerButton() {
        val js = """
            (function(){
              const b=document.getElementById('cameraBtn');
              if(!b || b.dataset.nativeScanner==='1') return;
              b.dataset.nativeScanner='1';
              b.addEventListener('click', function(e){
                e.preventDefault(); e.stopImmediatePropagation();
                if(window.AndroidScanner) window.AndroidScanner.startScan();
              }, true);
              const p=document.querySelector('#scan .sub');
              if(p) p.textContent='اضغط بدء المسح لفتح ماسح الباركود بالكاميرا. ستظهر نتيجة كل محاولة بوضوح، ويتم حفظ الكود وتاريخ ووقت المسح تلقائياً.';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(kind: String) {
        try {
            val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                manager.defaultVibrator
            } else {
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (!vibrator.hasVibrator()) return
            when (kind) {
                "duplicate" -> {
                    val pattern = longArrayOf(0, 110, 100, 110)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                    else vibrator.vibrate(pattern, -1)
                }
                "invalid" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                    else vibrator.vibrate(500)
                }
                else -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        vibrator.vibrate(VibrationEffect.createOneShot(75, VibrationEffect.DEFAULT_AMPLITUDE))
                    else vibrator.vibrate(75)
                }
            }
        } catch (_: Exception) { }
    }

    private fun cancelNoReadTimeout() {
        noReadTimeout?.let { mainHandler.removeCallbacks(it) }
        noReadTimeout = null
    }

    private fun showNoReadFeedback(message: String) {
        vibrate("invalid")
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        if (::webView.isInitialized) {
            val quoted = org.json.JSONObject.quote(message)
            webView.post {
                webView.evaluateJavascript(
                    "if(window.setNativeScanFeedback) window.setNativeScanFeedback('invalid',$quoted);",
                    null
                )
            }
        }
    }

    inner class NativeScannerBridge {
        @JavascriptInterface
        fun vibrate(kind: String) { this@MainActivity.vibrate(kind) }

        @JavascriptInterface
        fun startScan() {
            runOnUiThread {
                try {
                    cancelNoReadTimeout()
                    webView.evaluateJavascript(
                        "if(window.setNativeScanFeedback) window.setNativeScanFeedback('pending','📷 الكاميرا جاهزة — وجّهها إلى الباركود وانتظر نتيجة المسح.');",
                        null
                    )
                    // The native Google scanner does not emit a callback while it sees no code.
                    // Give a visible no-read warning after exactly two seconds, without closing the scanner.
                    noReadTimeout = Runnable {
                        showNoReadFeedback("⚠️ لم يتم التقاط الباركود خلال ثانيتين — وجّه الكاميرا للكود وحاول مرة أخرى.")
                    }
                    mainHandler.postDelayed(noReadTimeout!!, 2000)

                    val scanner = GmsBarcodeScanning.getClient(this@MainActivity)
                    scanner.startScan()
                        .addOnSuccessListener { barcode ->
                            cancelNoReadTimeout()
                            val value = barcode.rawValue
                            if (!value.isNullOrBlank()) {
                                val quoted = org.json.JSONObject.quote(value)
                                webView.evaluateJavascript(
                                    "document.getElementById('scanCode').value=$quoted; document.getElementById('addScan').click();",
                                    null
                                )
                            } else {
                                showNoReadFeedback("⚠️ لم يتم التقاط باركود واضح — حاول مرة أخرى.")
                            }
                        }
                        .addOnCanceledListener {
                            cancelNoReadTimeout()
                            showNoReadFeedback("⚠️ تم إلغاء المسح — لم يتم تسجيل أي كود.")
                        }
                        .addOnFailureListener { error ->
                            cancelNoReadTimeout()
                            showNoReadFeedback("⚠️ تعذر إكمال المسح: ${error.localizedMessage ?: "حاول مرة أخرى"}")
                        }
                } catch (e: Exception) {
                    cancelNoReadTimeout()
                    showNoReadFeedback("⚠️ تعذر تشغيل الماسح: ${e.localizedMessage ?: "حاول مرة أخرى"}")
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        cancelNoReadTimeout()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
