مطابقة المخزن الذكي - مشروع تطبيق Android

هذا مشروع Android Studio مصدره جاهز للبناء، وليس ملف APK مثبتاً.
تم تضمين صفحة نظام الجرد داخل التطبيق، ويستخدم زر المسح ماسح Google Code Scanner الأصلي بدلاً من getUserMedia في صفحة content://.

طريقة إنشاء APK:
1) افتح Android Studio على كمبيوتر.
2) اختر Open وافتح مجلد InventoryAndroid.
3) انتظر Gradle Sync واكتمال تنزيل الاعتمادات.
4) من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK داخل app/build/outputs/apk/debug/.
6) انقل APK إلى الهاتف وثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر.

ملاحظات:
- أول تشغيل قد يحتاج إنترنت حتى تتوفر وحدة Google Code Scanner من Google Play services.
- هذا المشروع يستخدم ماسح Google الأصلي، وليس نافذة معاينة الكاميرا داخل صفحة HTML.
- بيانات الصفحة تحفظ محلياً في مساحة WebView على نفس الهاتف.
- لم يتم بناء APK أو اختباره على هاتف فعلي في بيئة الإنشاء الحالية؛ يلزم فتح المشروع في Android Studio وبناؤه وتجربته.
