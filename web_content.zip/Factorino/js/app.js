function updateDateEquivalent(inputId,previewId){const input=document.getElementById(inputId),preview=document.getElementById(previewId);if(!input||!preview)return;preview.textContent="معادل شمسی: "+(input.value?finJalaliDate(input.value):"—")}
function applyTheme(color){
 const allowed=["blue","brown","red","green"],accent=allowed.includes(color)?color:"blue";
 document.body.dataset.accent=accent;
 document.querySelectorAll('input[name="themeChoice"]').forEach(r=>r.checked=r.value===accent);
}
const THEME_ICON={sun:'<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="12" cy="12" r="4.2" fill="currentColor"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',moon:'<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M20.5 14.6A8.6 8.6 0 0 1 9.4 3.5a8.6 8.6 0 1 0 11.1 11.1z" fill="currentColor"/></svg>'};
function cachedColorMode(){try{const v=localStorage.getItem("factorino-color-mode");return v==="dark"||v==="light"?v:""}catch(e){return ""}}
function systemPrefersDark(){try{return !!window.matchMedia?.("(prefers-color-scheme: dark)").matches}catch(e){return false}}
function applyColorMode(mode,persist=true){
 const dark=mode==="dark";document.documentElement.dataset.theme=dark?"dark":"light";
 try{localStorage.setItem("factorino-color-mode",dark?"dark":"light")}catch(e){}
 const themeMeta=document.querySelector('meta[name="theme-color"]');if(themeMeta)themeMeta.content=dark?"#06080F":"#142F4B";
 const btn=document.getElementById("themeToggle");
 if(btn){btn.innerHTML=dark?THEME_ICON.sun:THEME_ICON.moon;btn.setAttribute("aria-label",dark?"فعال‌سازی حالت روشن":"فعال‌سازی حالت تاریک");btn.setAttribute("aria-pressed",dark?"true":"false");btn.title=dark?"حالت روشن":"حالت تاریک"}
 if(persist&&typeof DB!=="undefined")DB.get("settings","seller").then(s=>DB.put("settings",{...(s||{}),id:"seller",colorMode:dark?"dark":"light"})).catch(console.error);
}
function moneyDigits(v){return String(v??"").replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/[^0-9.]/g,"")}
function formatMoneyValue(v){const raw=moneyDigits(v);if(!raw)return "";const parts=raw.split(".");const integer=(parts.shift()||"").replace(/^0+(?=\d)/,"");return integer.replace(/\B(?=(\d{3})+(?!\d))/g,",")+(parts.length?"."+parts.join("").slice(0,2):"")}
function initMoneyInputs(root=document){
 root.querySelectorAll('input[data-money-input],input.money-input').forEach(input=>{
  if(input.dataset.moneyReady)return;input.dataset.moneyReady="1";input.type="text";input.inputMode="numeric";
  input.value=formatMoneyValue(input.value);
  input.addEventListener("input",()=>{const pos=input.selectionStart??input.value.length,before=moneyDigits(input.value.slice(0,pos)).length,formatted=formatMoneyValue(input.value);input.value=formatted;let cursor=0,count=0;while(cursor<formatted.length&&count<before){if(/[0-9]/.test(formatted[cursor]))count++;cursor++}input.setSelectionRange(cursor,cursor)});
 });
}
document.addEventListener("DOMContentLoaded",()=>initMoneyInputs());
function esc(s){return String(s??"").replace(/\\n/g," ").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}function attr(s){return esc(s).replace(/`/g,"&#96;")}function emptyRow(t){return `<div class="empty">${t}</div>`}function toast(t){const e=document.getElementById("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2400)}function actionButtons(id){return `<button class="text-btn" data-act="edit" data-id="${id}">ویرایش</button><button class="text-btn danger" data-act="delete" data-id="${id}">حذف</button>`}
function showPage(name){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===name));document.getElementById("sidebar").classList.remove("open");if(name==="dashboard")renderDashboard();if(name==="invoices")renderInvoices();if(name==="customers")renderCustomers();if(name==="products")renderProducts();if(name==="settings"||name==="seller")loadSettings();if(["finance-customers","finance-transactions","expenses","finance-reports"].includes(name))refreshFinance()}
async function refreshAll(){await Promise.all([renderDashboard(),renderInvoices(),renderCustomers(),renderProducts()])}
async function renderDashboard(){const [i,c,p]=await Promise.all([DB.all("invoices"),DB.all("customers"),DB.all("products")]);document.getElementById("statInvoices").textContent=fmt(i.length);document.getElementById("statCustomers").textContent=fmt(c.length);document.getElementById("statProducts").textContent=fmt(p.length);document.getElementById("statRevenue").textContent=fmt(i.reduce((s,x)=>s+(x.totals?.total??calcInvoice(x).total),0));const recent=i.sort((a,b)=>b.number-a.number).slice(0,5);document.getElementById("recentInvoices").innerHTML=recent.length?invoiceTable(recent):emptyRow("هنوز فاکتوری ثبت نشده است.")}
const EMBLEM_SHORT={sun:"خورشید",architecture:"معماری",interior:"دکوراسیون",fruit:"میوه و تره‌بار",computer:"فناوری",mobile:"موبایل",supermarket:"سوپرمارکت",clothing:"پوشاک",restaurant:"رستوران",cafe:"کافه",bakery:"نان و شیرینی",beauty:"زیبایی",salon:"آرایشگاه",medical:"پزشکی",dental:"دندان‌پزشکی",pharmacy:"داروخانه",auto:"خودرو",carshop:"قطعات خودرو",construction:"ساختمان",electrical:"برق",plumbing:"تأسیسات",agriculture:"کشاورزی",education:"آموزش",legal:"حقوقی",transport:"حمل‌ونقل",photography:"عکاسی",jewelry:"طلا و جواهر"};
function brandEmblemHtml(value){return value==="sun"||!PROFESSION_MARKS[value]?emblemSunSvg():emblemSvg(value)}
function initEmblemPicker(){
 const select=document.getElementById("sellerProfession"),host=document.getElementById("emblemPicker");if(!select||!host)return;
 host.innerHTML=[...select.options].map(o=>`<button type="button" class="emblem-opt" role="radio" aria-checked="false" data-value="${attr(o.value)}" title="${attr(o.textContent)}" aria-label="${attr(o.textContent)}"><span class="eo-mark">${brandEmblemHtml(o.value)}</span><span class="eo-label">${esc(EMBLEM_SHORT[o.value]||o.textContent)}</span></button>`).join("");
 host.addEventListener("click",e=>{const b=e.target.closest(".emblem-opt");if(!b||select.disabled)return;select.value=b.dataset.value;syncEmblemPicker();renderBrandPreview()});
 host.addEventListener("keydown",e=>{
  if(!["ArrowRight","ArrowLeft","ArrowUp","ArrowDown"].includes(e.key))return;
  const items=[...host.querySelectorAll(".emblem-opt")],i=items.indexOf(document.activeElement);if(i<0)return;e.preventDefault();
  const step=e.key==="ArrowLeft"||e.key==="ArrowDown"?1:-1,next=items[(i+step+items.length)%items.length];next.focus();next.click();
 });
 ["sellerName","sellerEconomic"].forEach(id=>document.getElementById(id)?.addEventListener("input",renderBrandPreview));
}
function syncEmblemPicker(scroll=false){
 const select=document.getElementById("sellerProfession"),host=document.getElementById("emblemPicker");if(!select||!host)return;
 const current=select.value||"sun";let active=null;
 host.querySelectorAll(".emblem-opt").forEach(b=>{const on=b.dataset.value===current;b.setAttribute("aria-checked",on?"true":"false");b.tabIndex=on?0:-1;b.classList.toggle("is-active",on);if(on)active=b});
 if(scroll&&active&&host.scrollHeight>host.clientHeight)host.scrollTop=Math.max(0,active.offsetTop-host.offsetTop-(host.clientHeight-active.offsetHeight)/2);
}
function renderBrandPreview(){
 const box=document.getElementById("bpEmblem");if(!box)return;
 const mode=window.brandMode||"default",logo=window.pendingSellerLogo||"",value=document.getElementById("sellerProfession")?.value||"sun";
 if(mode==="custom"&&logo){box.className="bp-emblem is-logo";box.innerHTML=`<img alt="" src="${attr(logo)}">`}
 else if(value==="sun"||!PROFESSION_MARKS[value]){box.className="bp-emblem is-sun";box.innerHTML=emblemSunSvg()}
 else{box.className="bp-emblem is-sun";box.innerHTML=emblemSvg(value)}
 const name=document.getElementById("sellerName")?.value.trim(),eco=document.getElementById("sellerEconomic")?.value.trim(),nameEl=document.getElementById("bpName");
 if(nameEl){nameEl.textContent=name||"نام کسب‌وکار شما";nameEl.classList.toggle("is-placeholder",!name)}
 const ecoEl=document.getElementById("bpEconomic");if(ecoEl)ecoEl.textContent=eco||"—";
 const dateEl=document.getElementById("bpDate");if(dateEl)dateEl.textContent=typeof finJalaliDate==="function"&&typeof finToday==="function"?finJalaliDate(finToday()):"—";
}
function updateLogoControls(data,mode){
 const preview=document.getElementById("sellerLogoPreview"),empty=document.getElementById("sellerLogoEmpty"),tools=document.getElementById("customLogoTools"),picker=document.getElementById("emblemPickerWrap");
 window.brandMode=mode==="custom"?"custom":"default";
 if(preview){preview.src=data||"";preview.hidden=!data}
 if(empty)empty.hidden=!!data;
 if(tools)tools.hidden=window.brandMode!=="custom";
 if(picker)picker.hidden=window.brandMode==="custom";
 document.querySelectorAll('input[name="invoiceLogoMode"]').forEach(r=>{r.checked=r.value===window.brandMode;r.disabled=false});
 const profession=document.getElementById("sellerProfession");if(profession)profession.disabled=window.brandMode==="custom";
 syncEmblemPicker(true);renderBrandPreview();
}
function initSellerLogoControls(){
 const file=document.getElementById("sellerLogoFile"),change=document.getElementById("changeSellerLogo"),remove=document.getElementById("removeSellerLogo");
 file?.addEventListener("change",()=>{
  const f=file.files?.[0];if(!f)return;
  if(!/^image\/(png|jpeg|webp|svg\+xml)$/.test(f.type)){toast("فرمت لوگو باید PNG، JPG، WEBP یا SVG باشد");file.value="";return}
  if(f.size>5*1024*1024){toast("حجم لوگو نباید بیشتر از ۵ مگابایت باشد");file.value="";return}
  const reader=new FileReader();reader.onerror=()=>{toast("خواندن فایل لوگو ناموفق بود");file.value=""};reader.onload=async()=>{try{
   let data=String(reader.result);
   if(f.type!=="image/svg+xml"){
    const img=new Image();img.src=data;await img.decode();
    const scale=Math.min(1,1400/Math.max(img.naturalWidth,img.naturalHeight));
    if(scale<1||f.size>900*1024){const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));canvas.getContext("2d").drawImage(img,0,0,canvas.width,canvas.height);data=canvas.toDataURL("image/png")}
   }
   window.pendingSellerLogo=data;updateLogoControls(data,"custom");toast("پیش‌نمایش لوگو آماده شد؛ برای ذخیره، تنظیمات را ذخیره کنید")
  }catch(err){console.error(err);toast("فایل لوگو قابل پردازش نیست")}};
  reader.readAsDataURL(f);
 });
 change?.addEventListener("click",()=>file?.click());
 remove?.addEventListener("click",()=>{window.pendingSellerLogo="";updateLogoControls("","default");if(file)file.value="";toast("لوگوی اختصاصی حذف شد؛ برای ثبت تغییرات تنظیمات را ذخیره کنید")});
 document.querySelectorAll('input[name="invoiceLogoMode"]').forEach(r=>r.addEventListener("change",e=>{
  updateLogoControls(window.pendingSellerLogo||"",e.target.value);
 }));
}
async function loadSettings(){const s=await DB.get("settings","seller")||{};window.sellerSnapshot=s;document.getElementById("sellerName").value=s.name||"";document.getElementById("sellerPhone").value=s.phone||"";document.getElementById("sellerEconomic").value=s.economic||"";document.getElementById("sellerAddress").value=String(s.address||"").replace(/\\n/g," ");document.getElementById("startNumber").value=s.startNumber||1001;const theme=s.themeColor||"blue";const paper=document.getElementById("paperSize");if(paper)paper.value=s.paperSize||"A5";window.printPaperSize=s.paperSize||"A5";const unit=document.getElementById("sellerUnitType");if(unit)unit.value=UNIT_LABELS[s.unitType]?s.unitType:"weight";const profession=document.getElementById("sellerProfession");if(profession)profession.value=[...profession.options].some(o=>o.value===(s.profession||"sun"))?(s.profession||"sun"):"sun";applyTheme(theme);applyColorMode(s.colorMode||cachedColorMode()||(systemPrefersDark()?"dark":"light"),false);window.pendingSellerLogo=s.logoData||"";updateLogoControls(s.logoData||"",s.logoMode==="custom"&&s.logoData?"custom":"default")}
async function saveSettings(){const old=await DB.get("settings","seller")||{};const s={...old,id:"seller",name:val("sellerName").trim(),phone:val("sellerPhone").trim(),economic:val("sellerEconomic").trim(),address:val("sellerAddress").trim(),startNumber:Math.max(1,Number(val("startNumber"))||1001),themeColor:document.body.dataset.accent||"blue",paperSize:document.getElementById("paperSize")?.value||"A5",unitType:UNIT_LABELS[document.getElementById("sellerUnitType")?.value]?document.getElementById("sellerUnitType").value:"weight",profession:document.getElementById("sellerProfession")?.value||"sun",
 logoMode:document.querySelector('input[name="invoiceLogoMode"]:checked')?.value==="custom"&&window.pendingSellerLogo?"custom":"default",
 logoData:window.pendingSellerLogo||"",colorMode:document.documentElement.dataset.theme||"light"};await DB.put("settings",s);window.printPaperSize=s.paperSize;window.sellerSnapshot=s;updateLogoControls(s.logoData||"",s.logoMode);toast("تنظیمات فاکتور ذخیره شد")}
async function saveThemeChoice(color){const s=await DB.get("settings","seller")||{};s.id="seller";s.themeColor=color;await DB.put("settings",s);applyTheme(color);window.sellerSnapshot=s;toast("رنگ برنامه تغییر کرد")}
async function clearAllApplicationData(){
 if(!confirm("آیا مطمئن هستید تمام اطلاعات برنامه به‌طور کامل پاک شود؟ این عملیات قابل بازگشت نیست."))return;
 if(!confirm("تأیید نهایی: همه فاکتورها، مشتریان، کالاها، تراکنش‌ها، هزینه‌ها و تنظیمات حذف شوند؟"))return;
 await DB.clearAll();
 document.documentElement.dataset.theme="light";applyTheme("blue");applyColorMode("light",false);
 await loadSettings();await refreshAll();await refreshFinance();showPage("dashboard");toast("تمام اطلاعات برنامه پاک شد");
}
function openModal(title,fields,onSave){
 document.getElementById("modalTitle").textContent=title;const wrap=document.getElementById("modalFields");wrap.className="modal-fields";
 wrap.innerHTML=fields.map(f=>{const label=`<label class="${f.full?"full":""}">${f.label}`;
  if(f.type==="select"){const options=(f.options||[]).map(o=>`<option value="${attr(o[0])}" ${String(o[0])===String(f.value??"")?"selected":""}>${esc(o[1])}</option>`).join("");return `${label}<select name="${f.name}" ${f.required?"required":""}>${options}</select></label>`}
  const isMoney=f.type==="number"&&/(amount|unitPrice|openingBalance|previous|discount|price|cost|balance|debt|received|paid)/i.test(f.name);const type=isMoney?"text":(f.type==="jalali"?"date":(f.type||"text")),preview="";
  return `${label}<input name="${f.name}" type="${type}" ${f.type==="jalali"?'data-legacy-jalali="1"':""} value="${attr(f.value??"")}" ${f.required?"required":""} ${isMoney?'inputmode="numeric" data-money-input="1"':(f.type==="number"?'min="0" step="any"':"")}>${preview}</label>`
 }).join("");
 initAllJalaliDatePickers(wrap);initMoneyInputs(wrap);wrap.querySelectorAll('input[type="date"]').forEach(input=>{const preview=wrap.querySelector(`[data-date-preview="${input.name}"]`);const update=()=>{if(preview)preview.textContent="معادل شمسی: "+(input.value?finJalaliDate(input.value):"—")};input.addEventListener("change",update);update()});
 document.getElementById("modal").classList.add("open");document.getElementById("modalForm").onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target).entries());try{await onSave(data);closeModal()}catch(err){alert(err.message||"ذخیره اطلاعات انجام نشد")}}
}
function closeModal(){document.getElementById("modal").classList.remove("open")}
document.addEventListener("click",async e=>{const go=e.target.closest("[data-go]");if(go){if(go.dataset.go==="invoice")await newInvoice();else showPage(go.dataset.go);return}const nav=e.target.closest(".nav-item");if(nav){if(nav.dataset.page==="invoice")await newInvoice();else showPage(nav.dataset.page);return}if(e.target.closest("[data-close]")){closeModal();return}if(e.target.closest("[data-fin-ledger-close]")){document.getElementById("finLedgerModal").classList.remove("open");return}const a=e.target.closest("[data-act]");if(a){const id=a.dataset.id,kind=a.dataset.act,page=document.querySelector(".page.active")?.id;if(kind==="edit"){if(page==="page-customers")customerModal(await DB.get("customers",id));else if(page==="page-products")productModal(await DB.get("products",id));else await editInvoice(id)}if(kind==="delete"){if(!confirm("از حذف این مورد مطمئن هستید؟"))return;const store=page==="page-customers"?"customers":page==="page-products"?"products":"invoices";await DB.del(store,id);await refreshAll();toast("مورد انتخاب‌شده حذف شد")}if(kind==="print"){const printWindow=window.open("","_blank");if(!printWindow){alert("مرورگر اجازه بازکردن پنجره چاپ را نداد. اجازه پنجره‌های بازشو را فعال کنید.");return}const inv=await DB.get("invoices",id);printInvoice(inv,printWindow)}}});
document.getElementById("mobileMenu").onclick=()=>{const sidebar=document.getElementById("sidebar");sidebar.classList.toggle("open");document.getElementById("mobileMenu").setAttribute("aria-expanded",sidebar.classList.contains("open")?"true":"false")};
let themeTransitionRunning=false;
document.getElementById("themeToggle").onclick=()=>{
 if(themeTransitionRunning)return;
 const current=document.documentElement.dataset.theme==="dark"?"dark":"light";
 const next=current==="dark"?"light":"dark";
 const root=document.documentElement;
 const reduced=window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
 if(reduced){applyColorMode(next);return}
 themeTransitionRunning=true;
 root.classList.add("theme-fading");
 applyColorMode(next);
 window.setTimeout(()=>{
  root.classList.remove("theme-fading");
  themeTransitionRunning=false;
 },460);
};
document.addEventListener("click",e=>{const sidebar=document.getElementById("sidebar");if(sidebar.classList.contains("open")&&!e.target.closest("#sidebar")&&!e.target.closest("#mobileMenu"))sidebar.classList.remove("open")});
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.getElementById("sidebar").classList.remove("open")});
document.getElementById("quickNew").onclick=()=>newInvoice();
document.getElementById("addCustomer").onclick=()=>customerModal();document.getElementById("addProduct").onclick=()=>productModal();
document.getElementById("customerSearch").oninput=renderCustomers;document.getElementById("productSearch").oninput=renderProducts;document.getElementById("invoiceSearch").oninput=renderInvoices;
document.getElementById("addRow").onclick=()=>addInvoiceRow();["previous","discount","taxRate"].forEach(id=>document.getElementById(id).addEventListener("input",updateSummary));
document.getElementById("customerSelect").onchange=async e=>{const c=await DB.get("customers",e.target.value);if(c){document.getElementById("buyerName").value=c.name;document.getElementById("buyerPhone").value=c.phone||"";document.getElementById("buyerCode").value=c.code||"";document.getElementById("buyerAddress").value=c.address||""}};
document.getElementById("saveInvoice").onclick=saveCurrentInvoice;document.getElementById("saveInvoiceBottom").onclick=saveCurrentInvoice;document.getElementById("cancelInvoice").onclick=()=>showPage("dashboard");document.getElementById("saveSettings").onclick=saveSettings;
document.querySelectorAll('input[name="themeChoice"]').forEach(r=>r.addEventListener("change",e=>saveThemeChoice(e.target.value)));
document.getElementById("clearAllData").onclick=clearAllApplicationData;
document.getElementById("exportBackup").onclick=exportBackup;document.getElementById("importBackup").onchange=e=>{if(e.target.files[0])importBackup(e.target.files[0]);e.target.value=""};
(async()=>{initEmblemPicker();initSellerLogoControls();initBankInput();initAllJalaliDatePickers();await DB.init();initFinance();await loadSettings();await refreshAll();await refreshFinance();if("serviceWorker"in navigator&&location.protocol!=="file:")navigator.serviceWorker.register("./sw.js").catch(()=>{});})();

