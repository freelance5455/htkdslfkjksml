const fmt=n=>new Intl.NumberFormat("fa-IR",{maximumFractionDigits:2}).format(Number(n)||0);
const money=n=>fmt(Math.round(Number(n)||0))+" ریال";
const num=v=>Math.max(0,Number(String(v??"").replace(/[,٬\s]/g,"").replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d))))||0);
const UNIT_LABELS={weight:"وزن",count:"تعداد",liter:"لیتر",meter:"متر"};
function rowUnit(r, fallback="weight"){return Object.prototype.hasOwnProperty.call(UNIT_LABELS,r?.unitType)?r.unitType:fallback}
function rowMeasure(r){return num(r?.measure??r?.weight)}
function rowBase(r){return rowUnit(r)==="count"?num(r?.quantity):rowMeasure(r)}
function calcInvoice(inv){const fallback=inv?.seller?.unitType||"weight";const subtotal=(inv.rows||[]).reduce((s,r)=>s+rowBase({...r,unitType:rowUnit(r,fallback)})*num(r.unitPrice),0),previous=num(inv.previous),discount=num(inv.discount),taxRate=Math.min(100,num(inv.taxRate)),tax=Math.max(0,(subtotal+previous)*taxRate/100),total=Math.max(0,subtotal+previous+tax-discount);return{subtotal,previous,discount,tax,total}}
function toPersianDate(d=new Date()){try{return new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",month:"2-digit",day:"2-digit"}).format(d)}catch{return d.toLocaleDateString("fa-IR")}}
function documentStatusLabel(value){const normalized=String(value??"").normalize("NFC").replace(/[‌‍‎‏\s_-]/g,"").replace(/[يى]/g,"ی").replace(/ك/g,"ک");return normalized==="پیشفاکتور"?"پیش‌فاکتور":"فاکتور فروش"}

/* v39 — bank card number helpers (optional field on invoices) */
const FA_DIGITS="۰۱۲۳۴۵۶۷۸۹",AR_DIGITS="٠١٢٣٤٥٦٧٨٩";
function toFaDigits(v){return String(v??"").replace(/\d/g,d=>FA_DIGITS[d])}
function cardDigits(v){return String(v??"").replace(/[۰-۹]/g,d=>String(FA_DIGITS.indexOf(d))).replace(/[٠-٩]/g,d=>String(AR_DIGITS.indexOf(d))).replace(/\D/g,"").slice(0,16)}
function formatCardNumber(v){return cardDigits(v).replace(/(\d{4})(?=\d)/g,"$1 ")}

/* v40 — bank information on invoices: card number, account number or Sheba (IBAN) */
const BANK_TYPES={
 card:{title:"شماره کارت",label:"شماره کارت بانکی",placeholder:"0000 0000 0000 0000",hint:"۱۶ رقم؛ در صورت ثبت، روی فاکتور چاپی نمایش داده می‌شود."},
 account:{title:"شماره حساب",label:"شماره حساب",placeholder:"شماره حساب",hint:"فقط ارقام (و در صورت نیاز - یا .)؛ در صورت ثبت، روی فاکتور چاپی نمایش داده می‌شود."},
 sheba:{title:"شماره شبا",label:"شماره شبا",placeholder:"IR00 0000 0000 0000 0000 0000 00",hint:"۲۴ رقم پس از IR؛ پیشوند IR خودکار اضافه می‌شود."}
};
function latinDigits(v){return String(v??"").replace(/[۰-۹]/g,d=>String(FA_DIGITS.indexOf(d))).replace(/[٠-٩]/g,d=>String(AR_DIGITS.indexOf(d)))}
function bankTypeOf(v){return Object.prototype.hasOwnProperty.call(BANK_TYPES,v)?v:"card"}
/* canonical stored form: card → 16 digits, sheba → 24 digits (without IR), account → digits with optional - or . */
function normalizeBankNumber(type,v){
 const s=latinDigits(v);type=bankTypeOf(type);
 if(type==="card")return s.replace(/\D/g,"").slice(0,16);
 if(type==="sheba")return s.replace(/\D/g,"").slice(0,24);
 return s.replace(/[^\d.\-]/g,"").slice(0,30);
}
/* form-field display form */
function formatBankNumber(type,v){
 type=bankTypeOf(type);const n=normalizeBankNumber(type,v);
 if(!n)return "";
 if(type==="card")return n.replace(/(\d{4})(?=\d)/g,"$1 ");
 if(type==="sheba")return("IR"+n).replace(/(.{4})(?=.)/g,"$1 ");
 return n;
}
/* print display form: Persian digits */
function bankPrintNumber(type,number){const f=formatBankNumber(type,number);return f?toFaDigits(f):""}
function bankDigitCount(v){return latinDigits(v).replace(/\D/g,"").length}
function validateBankNumber(type,number){
 type=bankTypeOf(type);const n=normalizeBankNumber(type,number);if(!n)return "";
 if(type==="card"&&n.length!==16)return "شماره کارت باید ۱۶ رقم باشد؛ در غیر این صورت این فیلد را خالی بگذارید.";
 if(type==="sheba"&&n.length!==24)return "شماره شبا باید ۲۴ رقم (بدون IR) باشد؛ در غیر این صورت این فیلد را خالی بگذارید.";
 if(type==="account"){const c=bankDigitCount(n);if(c<6||c>24)return "شماره حساب باید بین ۶ تا ۲۴ رقم باشد؛ در غیر این صورت این فیلد را خالی بگذارید."}
 return "";
}
/* reads the bank block of any invoice, including v39 invoices that only have cardNumber */
function invoiceBank(inv){
 const type=bankTypeOf(inv?.bankType);
 const number=inv?.bankNumber?normalizeBankNumber(type,inv.bankNumber):(inv?.bankType?"":cardDigits(inv?.cardNumber));
 return{type,number,owner:String(inv?.bankOwner??"").replace(/\\n/g," ").trim()};
}
