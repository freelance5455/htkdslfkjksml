/* Financial modules — additive extension; existing invoice/product workflows remain intact. */
const FIN_METHODS=[["cash","نقدی"],["pos","کارت‌خوان"],["transfer","کارت‌به‌کارت"]];
const FIN_CATEGORIES=["اجاره","حقوق و دستمزد","حمل‌ونقل","قبوض و انرژی","ملزومات","تبلیغات","تعمیر و نگهداری","سایر"];
const finToday=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`};
const finDigits=s=>String(s??"").replace(/[۰-۹]/g,d=>String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
// Normalize every stored date to Gregorian ISO for reliable sorting/filtering.
// Legacy Persian dates (with either Persian or Arabic digits) are converted safely.
function finNormalizeDate(value){
 const raw=finDigits(value).trim();if(!raw)return "";
 const m=raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
 if(!m){const d=new Date(raw);return Number.isNaN(d.getTime())?"":`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
 const y=Number(m[1]),mo=Number(m[2]),day=Number(m[3]);
 if(y>=1200&&y<=1600){try{const iso=jalaliToISO(y,mo,day);const [gy,gm,gd]=iso.split("-").map(Number);const parts=new Intl.DateTimeFormat("en-US-u-ca-persian",{year:"numeric",month:"numeric",day:"numeric"}).formatToParts(new Date(gy,gm-1,gd,12));const get=t=>Number(parts.find(x=>x.type===t)?.value);if(get("year")!==y||get("month")!==mo||get("day")!==day)return "";return iso}catch(e){return ""}}
 const test=new Date(y,mo-1,day,12);if(test.getFullYear()!==y||test.getMonth()+1!==mo||test.getDate()!==day)return "";
 return `${y}-${String(mo).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
}
function finParseJalali(value){
 const raw=finDigits(value).trim().replace(/[.]/g,"/").replace(/-/g,"/");
 if(!raw)return "";
 const m=raw.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
 if(!m)throw Error("تاریخ معتبر نیست. نمونه قابل قبول: ۱۴۰۵/۰۸/۱۴ یا ۲۰۲۶/۱۱/۰۵");
 const y=+m[1],mo=+m[2],day=+m[3];
 if(mo<1||mo>12||day<1||day>31)throw Error("روز یا ماه واردشده معتبر نیست");
 if(y>=1200&&y<=1600){
  if(day>(mo<=6?31:mo<=11?30:30))throw Error("تاریخ شمسی واردشده معتبر نیست");
  const iso=jalaliToISO(y,mo,day),[gy,gm,gd]=iso.split("-").map(Number);
  const back=new Intl.DateTimeFormat("en-US-u-ca-persian",{year:"numeric",month:"numeric",day:"numeric"}).formatToParts(new Date(gy,gm-1,gd,12));
  const part=t=>Number(back.find(x=>x.type===t)?.value);
  if(part("year")!==y||part("month")!==mo||part("day")!==day)throw Error("تاریخ شمسی واردشده معتبر نیست");
  return iso;
 }
 const date=new Date(y,mo-1,day,12);
 if(date.getFullYear()!==y||date.getMonth()+1!==mo||date.getDate()!==day)throw Error("تاریخ میلادی واردشده معتبر نیست");
 return `${y}-${String(mo).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
}
function finJalaliDate(iso){if(!iso)return "—";const [y,m,d]=String(iso).slice(0,10).split("-").map(Number);if(!y||!m||!d)return String(iso);const parts=new Intl.DateTimeFormat("en-US-u-ca-persian",{year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(new Date(y,m-1,d,12));const get=t=>parts.find(x=>x.type===t)?.value||"";return `${get("year")}/${get("month")}/${get("day")}`.replace(/\d/g,x=>"۰۱۲۳۴۵۶۷۸۹"[+x])}
const finEsc=s=>esc(s);
function finInvoiceSale(inv){const c=calcInvoice(inv);return Math.max(0,c.subtotal+c.tax-c.discount)}
function finInvoiceDate(inv){return finNormalizeDate(inv.date)||finNormalizeDate(inv.createdAt)||""}
function jalaliToISO(jy,jm,jd){
 let jy2=jy-979,jdn=365*jy2+Math.floor(jy2/33)*8+Math.floor((jy2%33+3)/4);
 for(let i=1;i<jm;i++)jdn+=(i<=6?31:30);
 jdn+=jd-1;let gdn=jdn+79,gy=1600+400*Math.floor(gdn/146097);gdn%=146097;
 let leap=true;if(gdn>=36525){gdn--;gy+=100*Math.floor(gdn/36524);gdn%=36524;if(gdn>=365)gdn++ ;else leap=false}
 gy+=4*Math.floor(gdn/1461);gdn%=1461;if(gdn>=366){leap=false;gdn--;gy+=Math.floor(gdn/365);gdn%=365}
 const md=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];let gm=0;while(gm<12&&gdn>=md[gm])gdn-=md[gm++];
 return `${gy}-${String(gm+1).padStart(2,"0")}-${String(gdn+1).padStart(2,"0")}`;
}

const FIN_JMONTHS=["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
function finJalaliParts(iso){const [gy,gm,gd]=String(iso).slice(0,10).split("-").map(Number),parts=new Intl.DateTimeFormat("en-US-u-ca-persian",{year:"numeric",month:"numeric",day:"numeric"}).formatToParts(new Date(gy,gm-1,gd,12));const get=t=>Number(parts.find(x=>x.type===t)?.value);return{year:get("year"),month:get("month"),day:get("day")}}
function finJalaliMonthDays(y,m){if(m<=6)return 31;if(m<=11)return 30;try{const p=finJalaliParts(jalaliToISO(y,12,30));return p.year===y&&p.month===12&&p.day===30?30:29}catch(e){return 29}}
function initJalaliDatePicker(input){
 if(!input||input.dataset.jalaliReady)return;input.dataset.jalaliReady="1";
 const wrap=document.createElement("div");wrap.className="jalali-date-wrap";input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);
 const toggle=document.createElement("button");toggle.type="button";toggle.className="jalali-date-toggle";toggle.textContent="▦";toggle.setAttribute("aria-label","انتخاب تاریخ شمسی");wrap.appendChild(toggle);
 const panel=document.createElement("div");panel.className="jalali-calendar";panel.innerHTML='<div class="jalali-calendar-head"><button type="button" data-prev>‹</button><span data-title></span><button type="button" data-next>›</button></div><div class="jalali-days" data-grid></div>';wrap.appendChild(panel);
 let state=finJalaliParts(finToday());
 const fa=n=>String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[+d]);
 const open=()=>{try{state=input.value?(()=>{const iso=finParseJalali(input.value);return finJalaliParts(iso)})():finJalaliParts(finToday())}catch(e){}render();panel.classList.add("open")};
 const render=()=>{panel.querySelector("[data-title]").textContent=FIN_JMONTHS[state.month-1]+" "+fa(state.year);const grid=panel.querySelector("[data-grid]");grid.innerHTML="";["ش","ی","د","س","چ","پ","ج"].forEach(d=>{const el=document.createElement("div");el.className="jalali-weekday";el.textContent=d;grid.appendChild(el)});const first=jalaliToISO(state.year,state.month,1),[gy,gm,gd]=first.split("-").map(Number),offset=(new Date(gy,gm-1,gd,12).getDay()+1)%7,days=finJalaliMonthDays(state.year,state.month);for(let i=0;i<offset;i++){const blank=document.createElement("div");blank.className="jalali-day empty";grid.appendChild(blank)}for(let day=1;day<=days;day++){const btn=document.createElement("button");btn.type="button";btn.className="jalali-day";btn.textContent=fa(day);const value=`${state.year}/${String(state.month).padStart(2,"0")}/${String(day).padStart(2,"0")}`;if(input.value&&finDigits(input.value).replace(/-/g,"/")===value)btn.classList.add("selected");if(finJalaliParts(finToday()).year===state.year&&finJalaliParts(finToday()).month===state.month&&finJalaliParts(finToday()).day===day)btn.classList.add("today");btn.addEventListener("click",()=>{input.value=fa(value);panel.classList.remove("open");input.dispatchEvent(new Event("change",{bubbles:true}))});grid.appendChild(btn)}};
 toggle.addEventListener("click",()=>panel.classList.contains("open")?panel.classList.remove("open"):open());input.addEventListener("focus",open);panel.querySelector("[data-prev]").addEventListener("click",()=>{state.month--;if(state.month<1){state.month=12;state.year--}render()});panel.querySelector("[data-next]").addEventListener("click",()=>{state.month++;if(state.month>12){state.month=1;state.year++}render()});document.addEventListener("click",e=>{if(!wrap.contains(e.target))panel.classList.remove("open")});
}
function finRange(){const f=document.getElementById("finFrom")?.value||"",t=document.getElementById("finTo")?.value||"";const from=f?finNormalizeDate(f):"0001-01-01",to=t?finNormalizeDate(t):"9999-12-31";if(from>to)throw Error("تاریخ شروع نباید بعد از تاریخ پایان باشد");return{from,to}}
function inFinRange(date,r){return date>=r.from&&date<=r.to}
async function finCustomerId(inv){if(inv.buyer?.customerId)return inv.buyer.customerId;const all=await DB.all("customers");const n=normalizeSearch(inv.buyer?.name);return all.find(c=>normalizeSearch(c.name)===n)?.id||""}
async function finLedger(customerId){
 const [customer,invoices,payments]=await Promise.all([DB.get("customers",customerId),DB.all("invoices"),DB.all("payments")]);if(!customer)return null;
 const sales=[];for(const inv of invoices){if(await finCustomerId(inv)===customerId&&documentStatusLabel(inv.status)!=="پیش‌فاکتور")sales.push({id:inv.id,date:finInvoiceDate(inv),kind:"sale",label:`فاکتور فروش ${inv.number??""}`,amount:finInvoiceSale(inv),note:inv.notes||""})}
 const tx=payments.filter(p=>p.customerId===customerId).map(p=>({id:p.id,date:finNormalizeDate(p.date),kind:p.type,label:p.type==="receipt"?"دریافت وجه":"پرداخت به مشتری",amount:num(p.amount),note:p.description||"",method:p.method}));
 const rows=[...sales,...tx].sort((a,b)=>finNormalizeDate(a.date).localeCompare(finNormalizeDate(b.date)));
 const received=tx.filter(x=>x.kind==="receipt").reduce((s,x)=>s+x.amount,0),paid=tx.filter(x=>x.kind==="payment").reduce((s,x)=>s+x.amount,0),purchases=sales.reduce((s,x)=>s+x.amount,0),opening=num(customer.openingBalance);
 return{customer,rows,purchases,received,paid,opening,balance:opening+purchases-received-paid};
}
async function renderFinanceCustomers(){
 const q=normalizeSearch(document.getElementById("finCustomerSearch").value),customers=await DB.all("customers");
 const rows=[];for(const c of customers){const l=await finLedger(c.id);if(!q||normalizeSearch(c.name+" "+(c.phone||"")).includes(q))rows.push({c,l})}
 document.getElementById("finCustomerList").innerHTML=rows.length?`<table class="data-table"><thead><tr><th>مشتری</th><th>مجموع خرید</th><th>دریافت‌ها</th><th>پرداخت به مشتری</th><th>مانده حساب</th><th>عملیات</th></tr></thead><tbody>${rows.map(({c,l})=>`<tr><td>${finEsc(c.name)}</td><td>${money(l.purchases)}</td><td>${money(l.received)}</td><td>${money(l.paid)}</td><td class="${l.balance>0?"fin-debit":l.balance<0?"fin-credit":""}">${l.balance>0?"بدهکار: ":l.balance<0?"بستانکار: ":"تسویه: "}${money(Math.abs(l.balance))}</td><td><button class="text-btn" data-fin-ledger="${c.id}">دفتر حساب</button><button class="text-btn" data-fin-print-ledger="${c.id}">چاپ حساب</button><button class="text-btn" data-fin-opening="${c.id}">بدهی اولیه</button></td></tr>`).join("")}</tbody></table>`:emptyRow("مشتری‌ای مطابق جست‌وجو پیدا نشد.");
}
async function showFinLedger(id){
 const l=await finLedger(id);if(!l)return;document.getElementById("finLedgerTitle").textContent="دفتر حساب "+l.customer.name;
 document.getElementById("finLedgerStats").innerHTML=`<div class="fin-mini"><small>بدهی اولیه</small><strong>${money(l.opening)}</strong></div><div class="fin-mini"><small>مجموع خرید</small><strong>${money(l.purchases)}</strong></div><div class="fin-mini"><small>مجموع دریافت</small><strong>${money(l.received)}</strong></div><div class="fin-mini"><small>مانده حساب</small><strong>${money(l.balance)}</strong></div>`;
 document.getElementById("finLedgerRows").innerHTML=l.rows.length?`<table class="data-table"><thead><tr><th>تاریخ</th><th>شرح</th><th>روش</th><th>بدهکار</th><th>بستانکار</th><th>توضیحات</th></tr></thead><tbody>${l.rows.map(x=>`<tr><td>${finEsc(finJalaliDate(finNormalizeDate(x.date)))}</td><td>${finEsc(x.label)}</td><td>${FIN_METHODS.find(m=>m[0]===x.method)?.[1]||"—"}</td><td>${money(x.kind==="sale"?x.amount:0)}</td><td>${money(x.kind!=="sale"?x.amount:0)}</td><td>${finEsc(x.note)}</td></tr>`).join("")}</tbody></table>`:emptyRow("گردش حسابی ثبت نشده است.");
 document.getElementById("finLedgerModal").classList.add("open");
}
async function setOpeningBalance(id){const c=await DB.get("customers",id);openModal("ثبت بدهی اولیه مشتری",[{name:"openingBalance",label:"مانده اولیه (ریال)",type:"number",value:c.openingBalance??0,full:true}],async v=>{c.openingBalance=num(v.openingBalance);await DB.put("customers",c);await renderFinanceCustomers();toast("مانده اولیه ذخیره شد")})}
async function financeModal(item=null){
 const cs=await DB.all("customers");
 if(!cs.length){alert("ابتدا از بخش مدیریت مشتریان، حداقل یک مشتری ثبت کنید.");return}
 openModal(item?"ویرایش تراکنش":"ثبت تراکنش جدید",[
  {name:"customerId",label:"مشتری",type:"select",value:item?.customerId||"",required:true,options:cs.map(c=>[c.id,c.name])},
  {name:"type",label:"نوع تراکنش",type:"select",value:item?.type||"receipt",options:[["receipt","دریافت از مشتری"],["payment","پرداخت به مشتری"]]},
  {name:"amount",label:"مبلغ (ریال)",type:"number",value:item?.amount??"",required:true},
  {name:"date",label:"تاریخ (میلادی)",type:"date",value:finNormalizeDate(item?.date)||finToday(),required:true},
  {name:"method",label:"روش پرداخت",type:"select",value:item?.method||"cash",options:FIN_METHODS},
  {name:"description",label:"توضیحات",value:item?.description||"",full:true}
 ],async v=>{const amount=Number(finDigits(v.amount));if(!v.customerId)throw Error("لطفاً مشتری را انتخاب کنید");if(!Number.isFinite(amount)||amount<=0)throw Error("مبلغ باید بیشتر از صفر باشد");await DB.put("payments",{id:item?.id||uid(),customerId:v.customerId,type:v.type,amount,date:finNormalizeDate(v.date),method:v.method,description:v.description||"",createdAt:item?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()});await renderFinanceTransactions();await renderFinanceCustomers();await renderFinanceReports();toast("تراکنش با موفقیت ذخیره شد")});
}
async function renderFinanceTransactions(){
 const q=normalizeSearch(document.getElementById("finTxSearch").value),r=finRange(),[tx,cs]=await Promise.all([DB.all("payments"),DB.all("customers")]),map=new Map(cs.map(c=>[c.id,c]));
 const customerSelect=document.getElementById("finTxCustomerFilter"),oldCustomer=customerSelect.value;customerSelect.innerHTML='<option value="">همه مشتریان</option>'+cs.map(c=>`<option value="${attr(c.id)}">${esc(c.name)}</option>`).join("");customerSelect.value=cs.some(c=>c.id===oldCustomer)?oldCustomer:"";
 const customerFilter=customerSelect.value,typeFilter=document.getElementById("finTxTypeFilter").value;
 const a=tx.filter(x=>inFinRange(finNormalizeDate(x.date),r)&&(!customerFilter||x.customerId===customerFilter)&&(!typeFilter||x.type===typeFilter)&&(!q||normalizeSearch((map.get(x.customerId)?.name||"")+" "+x.description+" "+x.type).includes(q))).sort((x,y)=>finNormalizeDate(y.date).localeCompare(finNormalizeDate(x.date)));
 document.getElementById("finTxList").innerHTML=a.length?`<table class="data-table"><thead><tr><th>تاریخ</th><th>مشتری</th><th>نوع</th><th>روش</th><th>مبلغ</th><th>توضیحات</th><th>عملیات</th></tr></thead><tbody>${a.map(x=>`<tr><td>${finEsc(finJalaliDate(finNormalizeDate(x.date)))}</td><td>${finEsc(map.get(x.customerId)?.name||"مشتری حذف‌شده")}</td><td>${x.type==="receipt"?"دریافت":"پرداخت به مشتری"}</td><td>${FIN_METHODS.find(m=>m[0]===x.method)?.[1]||"—"}</td><td>${money(x.amount)}</td><td>${finEsc(x.description||"—")}</td><td><button class="text-btn" data-fin-edit="${x.id}">ویرایش</button><button class="text-btn danger" data-fin-delete="${x.id}">حذف</button></td></tr>`).join("")}</tbody></table>`:emptyRow("تراکنشی در این بازه ثبت نشده است.");
}
async function financeDeleteTx(id){if(!confirm("تراکنش حذف شود؟"))return;await DB.del("payments",id);await renderFinanceTransactions();await renderFinanceCustomers();await renderFinanceReports();toast("تراکنش حذف شد")}
function expenseModal(item=null){
 openModal(item?"ویرایش هزینه":"ثبت هزینه جدید",[
  {name:"category",label:"دسته‌بندی",type:"select",value:item?.category||"سایر",options:FIN_CATEGORIES.map(x=>[x,x])},
  {name:"amount",label:"مبلغ (ریال)",type:"number",value:item?.amount??"",required:true},
  {name:"date",label:"تاریخ (میلادی)",type:"date",value:finNormalizeDate(item?.date)||finToday(),required:true},
  {name:"description",label:"توضیحات",value:item?.description||"",full:true}
 ],async v=>{const amount=Number(finDigits(v.amount));if(!Number.isFinite(amount)||amount<=0)throw Error("مبلغ باید بیشتر از صفر باشد");await DB.put("expenses",{id:item?.id||uid(),category:v.category,amount,date:finNormalizeDate(v.date),description:v.description||"",createdAt:item?.createdAt||new Date().toISOString()});await renderExpenses();await renderFinanceReports();toast("هزینه با موفقیت ذخیره شد")});
}
async function renderExpenses(){
 const q=normalizeSearch(document.getElementById("expenseSearch").value),r=finRange(),a=(await DB.all("expenses")).filter(x=>inFinRange(finNormalizeDate(x.date),r)&&(!q||normalizeSearch(x.category+" "+x.description).includes(q))).sort((x,y)=>finNormalizeDate(y.date).localeCompare(finNormalizeDate(x.date)));
 document.getElementById("expenseTotal").textContent=money(a.reduce((s,x)=>s+num(x.amount),0));
 document.getElementById("expenseList").innerHTML=a.length?`<table class="data-table"><thead><tr><th>تاریخ</th><th>دسته‌بندی</th><th>مبلغ</th><th>توضیحات</th><th>عملیات</th></tr></thead><tbody>${a.map(x=>`<tr><td>${finEsc(finJalaliDate(finNormalizeDate(x.date)))}</td><td>${finEsc(x.category)}</td><td>${money(x.amount)}</td><td>${finEsc(x.description||"—")}</td><td><button class="text-btn" data-exp-edit="${x.id}">ویرایش</button><button class="text-btn danger" data-exp-delete="${x.id}">حذف</button></td></tr>`).join("")}</tbody></table>`:emptyRow("هزینه‌ای در این بازه ثبت نشده است.");
}
async function financeDeleteExpense(id){if(!confirm("این هزینه حذف شود؟"))return;await DB.del("expenses",id);await renderExpenses();await renderFinanceReports();toast("هزینه حذف شد")}
async function renderFinanceReports(){
 const r=finRange(),[invoices,payments,expenses,customers]=await Promise.all([DB.all("invoices"),DB.all("payments"),DB.all("expenses"),DB.all("customers")]);
 const sales=invoices.filter(x=>documentStatusLabel(x.status)!=="پیش‌فاکتور"&&inFinRange(finInvoiceDate(x),r)),tx=payments.filter(x=>inFinRange(finNormalizeDate(x.date),r)),ex=expenses.filter(x=>inFinRange(finNormalizeDate(x.date),r));
 let debt=0;for(const c of customers){const l=await finLedger(c.id);debt+=Math.max(0,l.balance)}
 const totalSales=sales.reduce((s,x)=>s+finInvoiceSale(x),0),totalExpenses=ex.reduce((s,x)=>s+num(x.amount),0),receipts=tx.filter(x=>x.type==="receipt").reduce((s,x)=>s+num(x.amount),0),payouts=tx.filter(x=>x.type==="payment").reduce((s,x)=>s+num(x.amount),0);
 document.getElementById("finReportStats").innerHTML=`<div class="stat-card"><div><small>فروش خالص</small><strong>${money(totalSales)}</strong></div></div><div class="stat-card"><div><small>مجموع هزینه‌ها</small><strong>${money(totalExpenses)}</strong></div></div><div class="stat-card"><div><small>مجموع دریافت‌ها</small><strong>${money(receipts)}</strong></div></div><div class="stat-card"><div><small>بدهی مشتریان</small><strong>${money(debt)}</strong></div></div><div class="stat-card"><div><small>پرداخت به مشتریان</small><strong>${money(payouts)}</strong></div></div><div class="stat-card"><div><small>سود / زیان عملیاتی</small><strong class="${totalSales-totalExpenses>=0?"fin-credit":"fin-debit"}">${money(totalSales-totalExpenses)}</strong></div></div>`;
 document.getElementById("finReportNote").textContent="سود/زیان عملیاتی = فروش خالص فاکتورهای فروش − هزینه‌های ثبت‌شده؛ دریافت‌ها صرفاً گردش نقدی هستند و دوباره به فروش اضافه نمی‌شوند.";
}
function initFinance(){
 const invoiceDate=document.getElementById("invDate");if(invoiceDate){invoiceDate.addEventListener("change",()=>updateDateEquivalent("invDate","invDateJalali"));updateDateEquivalent("invDate","invDateJalali");}
 const from=document.getElementById("finFrom"),to=document.getElementById("finTo");if(from&&!from.value){const now=new Date();from.value=`${now.getFullYear()}-01-01`;to.value=finToday()} 
 if(from){from.addEventListener("change",()=>updateDateEquivalent("finFrom","finFromJalali"));updateDateEquivalent("finFrom","finFromJalali")}
 if(to){to.addEventListener("change",()=>updateDateEquivalent("finTo","finToJalali"));updateDateEquivalent("finTo","finToJalali")}
 document.getElementById("finCustomerSearch").oninput=renderFinanceCustomers;document.getElementById("finTxSearch").oninput=renderFinanceTransactions;document.getElementById("finTxCustomerFilter").onchange=renderFinanceTransactions;document.getElementById("finTxTypeFilter").onchange=renderFinanceTransactions;document.getElementById("expenseSearch").oninput=renderExpenses;
 ["finFrom","finTo"].forEach(id=>{const el=document.getElementById(id);el.dataset.lastValid=el.value;el.addEventListener("change",()=>{try{finRange();document.getElementById("finFrom").dataset.lastValid=document.getElementById("finFrom").value;document.getElementById("finTo").dataset.lastValid=document.getElementById("finTo").value;renderFinanceTransactions();renderExpenses();renderFinanceReports()}catch(e){alert(e.message);el.value=el.dataset.lastValid||""}})});
 document.getElementById("addFinTx").onclick=()=>financeModal();document.getElementById("addExpense").onclick=()=>expenseModal();
 document.getElementById("printInvoices").onclick=()=>printFinanceSection("invoices");document.getElementById("printLedgers").onclick=()=>printFinanceSection("ledgers");document.getElementById("printTransactions").onclick=()=>printFinanceSection("transactions");document.getElementById("printExpenses").onclick=()=>printFinanceSection("expenses");document.getElementById("printFinReport").onclick=()=>printFinanceSection("report");
 document.addEventListener("click",e=>{
  const ledger=e.target.closest("[data-fin-ledger]");if(ledger)showFinLedger(ledger.dataset.finLedger);
  const opening=e.target.closest("[data-fin-opening]");if(opening)setOpeningBalance(opening.dataset.finOpening);
  const printLedger=e.target.closest("[data-fin-print-ledger]");if(printLedger)printFinanceSection("ledger",printLedger.dataset.finPrintLedger);
  const edit=e.target.closest("[data-fin-edit]");if(edit)DB.get("payments",edit.dataset.finEdit).then(x=>financeModal(x));
  const del=e.target.closest("[data-fin-delete]");if(del)financeDeleteTx(del.dataset.finDelete);
  const ee=e.target.closest("[data-exp-edit]");if(ee)DB.get("expenses",ee.dataset.expEdit).then(expenseModal);
  const ed=e.target.closest("[data-exp-delete]");if(ed)financeDeleteExpense(ed.dataset.expDelete);
 });
}
async function refreshFinance(){await Promise.all([renderFinanceCustomers(),renderFinanceTransactions(),renderExpenses(),renderFinanceReports()])}


function printFinanceSection(kind,customerId=""){
 const w=window.open("","_blank");if(!w){alert("برای چاپ، اجازه بازشدن پنجره جدید را در مرورگر فعال کنید.");return}
 const titleMap={invoices:"فاکتورهای ذخیره‌شده",ledgers:"دفتر حساب مشتریان",ledger:"دفتر حساب مشتری",transactions:"دریافت و پرداخت",expenses:"مدیریت هزینه‌ها",report:"گزارش سود و زیان"};
 const escCell=v=>esc(v??"—"),dateCell=v=>esc(finJalaliDate(v));
 const table=(headers,rows)=>`<table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.length?rows.map(row=>`<tr>${row.map(c=>`<td>${c}</td>`).join("")}</tr>`).join(""):`<tr><td colspan="${headers.length}" style="text-align:center">اطلاعاتی برای نمایش وجود ندارد</td></tr>`}</tbody></table>`;
 const meta=`<div class="meta"><span>تاریخ تهیه: ${dateCell(finToday())}</span></div>`;
 const doc=(body)=>{
  let started=false;
  const run=async()=>{if(started)return;started=true;try{if(w.document.fonts?.ready)await w.document.fonts.ready}catch(e){}const sheet=w.document.querySelector('link[rel="stylesheet"]');if(sheet&&!sheet.sheet)await new Promise(resolve=>{sheet.addEventListener("load",resolve,{once:true});sheet.addEventListener("error",resolve,{once:true});setTimeout(resolve,2500)});setTimeout(()=>{try{w.focus();w.print()}catch(e){console.error("Print failed:",e)}},250)};
  w.addEventListener("load",run,{once:true});w.onafterprint=()=>{try{w.close()}catch(e){}};
  w.document.open();w.document.write(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>${titleMap[kind]}</title><link rel="stylesheet" href="${new URL("./css/report-print.css",location.href).href}"></head><body><main class="report-print"><h1>${titleMap[kind]}</h1><div class="subhead">گزارش رسمی و قابل چاپ</div>${meta}${body}<div class="print-footer"><span>پایان گزارش</span></div></main></body></html>`);w.document.close();
  if(w.document.readyState==="complete")run();
 };
 (async()=>{try{
  let body="";
  if(kind==="invoices"){
   const q=normalizeSearch(document.getElementById("invoiceSearch")?.value||""),all=await DB.all("invoices"),a=all.filter(x=>!q||[x.number,x.buyer?.name,x.buyer?.phone,x.date].some(v=>normalizeSearch(v).includes(q))).sort((x,y)=>Number(x.number)-Number(y.number));
   body=table(["شماره فاکتور","تاریخ","نام مشتری","مبلغ نهایی","وضعیت"],a.map(x=>[escCell(x.number),dateCell(finInvoiceDate(x)),escCell(x.buyer?.name),`<span class="num">${money(x.totals?.total??calcInvoice(x).total)}</span>`,escCell(documentStatusLabel(x.status))]));
  }else if(kind==="ledgers"){
   const customers=await DB.all("customers"),summary=[];
   let grandOpening=0,grandPurchases=0,grandReceived=0,grandPaid=0,grandBalance=0;
   for(const c of customers){
    const l=await finLedger(c.id);if(!l)continue;
    grandOpening+=l.opening;grandPurchases+=l.purchases;grandReceived+=l.received;grandPaid+=l.paid;grandBalance+=l.balance;
    summary.push([escCell(c.name),escCell(c.phone||"—"),`<span class="num">${money(l.opening)}</span>`,`<span class="num">${money(l.purchases)}</span>`,`<span class="num">${money(l.received)}</span>`,`<span class="num">${money(l.paid)}</span>`,`<strong class="num">${money(l.balance)}</strong>`,l.balance>0?"بدهکار":l.balance<0?"بستانکار":"تسویه"]);
   }
   const totals=["<strong>جمع کل</strong>","—",...[grandOpening,grandPurchases,grandReceived,grandPaid,grandBalance].map(v=>`<strong class="num">${money(v)}</strong>`),"—"];
   body=`<div class="summary-grid"><div class="summary-item"><small>تعداد مشتریان</small><strong>${fmt(customers.length)}</strong></div><div class="summary-item"><small>مجموع مانده حساب‌ها</small><strong>${money(grandBalance)}</strong></div></div>`+table(["نام مشتری","شماره تماس","بدهی اولیه","مجموع خرید","مجموع دریافت","پرداخت به مشتری","مانده حساب","وضعیت"],[...summary,totals]);
  }else if(kind==="ledger"){
   const c=await DB.get("customers",customerId),l=c?await finLedger(customerId):null;
   if(l)body=`<h2>${escCell(c.name)} — مانده: ${money(l.balance)}</h2>`+table(["تاریخ","شرح","روش","بدهکار","بستانکار","توضیحات"],l.rows.map(x=>[dateCell(finNormalizeDate(x.date)),escCell(x.label),escCell(FIN_METHODS.find(m=>m[0]===x.method)?.[1]||"—"),`<span class="num">${money(x.kind==="sale"?x.amount:0)}</span>`,`<span class="num">${money(x.kind!=="sale"?x.amount:0)}</span>`,escCell(x.note)]));
  }else if(kind==="transactions"){
   const r=finRange(),[tx,cs]=await Promise.all([DB.all("payments"),DB.all("customers")]),map=new Map(cs.map(c=>[c.id,c]));const a=tx.filter(x=>inFinRange(finNormalizeDate(x.date),r)).sort((x,y)=>finNormalizeDate(x.date).localeCompare(finNormalizeDate(y.date)));
   body=table(["تاریخ","مشتری","نوع","روش پرداخت","مبلغ","توضیحات"],a.map(x=>[dateCell(finNormalizeDate(x.date)),escCell(map.get(x.customerId)?.name||"مشتری حذف‌شده"),x.type==="receipt"?"دریافت":"پرداخت به مشتری",escCell(FIN_METHODS.find(m=>m[0]===x.method)?.[1]||"—"),`<span class="num">${money(x.amount)}</span>`,escCell(x.description)]));
  }else if(kind==="expenses"){
   const r=finRange(),a=(await DB.all("expenses")).filter(x=>inFinRange(finNormalizeDate(x.date),r)).sort((x,y)=>finNormalizeDate(x.date).localeCompare(finNormalizeDate(y.date)));const total=a.reduce((s,x)=>s+num(x.amount),0);
   body=`<div class="summary-grid"><div class="summary-item"><small>تعداد هزینه‌ها</small><strong>${fmt(a.length)}</strong></div><div class="summary-item"><small>مجموع هزینه‌ها</small><strong>${money(total)}</strong></div></div>`+table(["تاریخ","دسته‌بندی","مبلغ","توضیحات"],a.map(x=>[dateCell(finNormalizeDate(x.date)),escCell(x.category),`<span class="num">${money(x.amount)}</span>`,escCell(x.description)]));
  }else if(kind==="report"){
   await renderFinanceReports();const r=finRange(),[invoices,payments,expenses,customers]=await Promise.all([DB.all("invoices"),DB.all("payments"),DB.all("expenses"),DB.all("customers")]);const sales=invoices.filter(x=>documentStatusLabel(x.status)!=="پیش‌فاکتور"&&inFinRange(finInvoiceDate(x),r)),tx=payments.filter(x=>inFinRange(finNormalizeDate(x.date),r)),ex=expenses.filter(x=>inFinRange(finNormalizeDate(x.date),r));let debt=0;for(const c of customers){const l=await finLedger(c.id);debt+=Math.max(0,l.balance)}const sale=sales.reduce((s,x)=>s+finInvoiceSale(x),0),cost=ex.reduce((s,x)=>s+num(x.amount),0),received=tx.filter(x=>x.type==="receipt").reduce((s,x)=>s+num(x.amount),0),paid=tx.filter(x=>x.type==="payment").reduce((s,x)=>s+num(x.amount),0);const period=`از ${dateCell(r.from)} تا ${dateCell(r.to)}`;
   body=`<div class="meta"><span>${period}</span><span>مبالغ به ریال</span></div><div class="summary-grid">${[["فروش خالص",sale],["مجموع هزینه‌ها",cost],["دریافت‌ها",received],["بدهی مشتریان",debt],["پرداخت به مشتریان",paid],["سود / زیان عملیاتی",sale-cost]].map(([k,v])=>`<div class="summary-item"><small>${k}</small><strong>${money(v)}</strong></div>`).join("")}</div><p class="muted">سود/زیان عملیاتی برابر فروش خالص فاکتورهای فروش منهای هزینه‌های ثبت‌شده است. دریافت‌ها و پرداخت‌ها صرفاً گردش وجوه هستند.</p>`;
  }
  doc(body);
 }catch(e){w.close();alert(e.message||"آماده‌سازی گزارش برای چاپ انجام نشد")}})();
}
