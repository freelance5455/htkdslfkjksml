/* Local-first database: IndexedDB with localStorage fallback */
const DB={
 name:"factorino-db",version:2,db:null,stores:["invoices","customers","products","settings","meta","payments","expenses"],
 async init(){
  if(!("indexedDB" in window))return;
  try{this.db=await new Promise((res,rej)=>{const r=indexedDB.open(this.name,this.version);r.onupgradeneeded=()=>{const d=r.result;this.stores.forEach(s=>{if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:"id"})})};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});document.getElementById("dbStatus").textContent="پایگاه داده محلی فعال"}
  catch(e){this.db=null;document.getElementById("dbStatus").textContent="ذخیره‌سازی جایگزین فعال"}
 },
 async all(store){if(!this.db)return JSON.parse(localStorage.getItem("fb_"+store)||"[]");return new Promise((res,rej)=>{const r=this.db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})},
 async get(store,id){if(!this.db)return(await this.all(store)).find(x=>x.id===id)||null;return new Promise((res,rej)=>{const r=this.db.transaction(store).objectStore(store).get(id);r.onsuccess=()=>res(r.result||null);r.onerror=()=>rej(r.error)})},
 async put(store,obj){if(!this.db){const a=await this.all(store),i=a.findIndex(x=>x.id===obj.id);if(i<0)a.push(obj);else a[i]=obj;localStorage.setItem("fb_"+store,JSON.stringify(a));return obj}return new Promise((res,rej)=>{const t=this.db.transaction(store,"readwrite");t.objectStore(store).put(obj);t.oncomplete=()=>res(obj);t.onerror=()=>rej(t.error)})},
 async del(store,id){if(!this.db){localStorage.setItem("fb_"+store,JSON.stringify((await this.all(store)).filter(x=>x.id!==id)));return}return new Promise((res,rej)=>{const t=this.db.transaction(store,"readwrite");t.objectStore(store).delete(id);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})},
 async replaceAll(data){for(const s of this.stores){const rows=data[s]||[];if(this.db)await new Promise((res,rej)=>{const t=this.db.transaction(s,"readwrite"),o=t.objectStore(s);o.clear();rows.forEach(x=>o.put(x));t.oncomplete=res;t.onerror=()=>rej(t.error)});else localStorage.setItem("fb_"+s,JSON.stringify(rows))}},
 async mergeAll(data){
  let added=0;
  for(const s of this.stores){
   const current=await this.all(s),incoming=Array.isArray(data[s])?data[s]:[];
   let rows;
   if(s==="settings"){
    const map=new Map(current.map(x=>[String(x.id),x]));
    for(const item of incoming){if(!item||item.id==null)continue;const key=String(item.id),old=map.get(key);if(old)map.set(key,{...item,...old});else{map.set(key,item);added++}}
    rows=[...map.values()];
   }else{
    const ids=new Set(current.filter(x=>x&&x.id!=null).map(x=>String(x.id)));rows=[...current];
    for(const item of incoming){if(!item||item.id==null)continue;const key=String(item.id);if(ids.has(key))continue;ids.add(key);rows.push(item);added++}
   }
   if(this.db)await new Promise((res,rej)=>{const t=this.db.transaction(s,"readwrite"),o=t.objectStore(s);rows.forEach(x=>o.put(x));t.oncomplete=res;t.onerror=()=>rej(t.error)});
   else localStorage.setItem("fb_"+s,JSON.stringify(rows));
  }
  const [meta,invoices]=await Promise.all([this.all("meta"),this.all("invoices")]);
  const incomingMeta=Array.isArray(data.meta)?data.meta:[];
  const currentSequence=meta.find(x=>x.id==="sequence")||{id:"sequence",next:1,lastUsed:0};
  const backupSequence=incomingMeta.find(x=>x?.id==="sequence")||{};
  const highest=invoices.reduce((m,x)=>Math.max(m,Number(x.number)||0),0);
  const sequence={id:"sequence",next:Math.max(Number(currentSequence.next)||1,Number(backupSequence.next)||1,highest+1),lastUsed:Math.max(Number(currentSequence.lastUsed)||0,Number(backupSequence.lastUsed)||0,highest)};
  await this.put("meta",sequence);return{added};
 }
};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
