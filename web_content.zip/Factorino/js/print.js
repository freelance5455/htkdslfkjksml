/** Print through the current WebView instead of opening a popup window.
 * This works in normal browsers and in WebViews that expose window.print().
 * The APK wrapper must still provide Android print support for native print UI.
 */
function printHtmlDocument(html){
  const frame=document.createElement("iframe");
  frame.setAttribute("aria-hidden","true");
  frame.title="پیش‌نمایش چاپ";
  frame.style.cssText="position:fixed;left:0;top:0;width:100vw;height:100vh;border:0;z-index:-1;background:#fff;pointer-events:none";
  document.body.appendChild(frame);
  const w=frame.contentWindow,doc=frame.contentDocument;
  let started=false;
  const cleanup=()=>{setTimeout(()=>{try{frame.remove()}catch(e){}},500)};
  const run=async()=>{
    if(started)return;started=true;
    try{if(doc.fonts?.ready)await doc.fonts.ready}catch(e){}
    const sheet=doc.querySelector('link[rel="stylesheet"]');
    if(sheet&&!sheet.sheet)await new Promise(resolve=>{sheet.addEventListener("load",resolve,{once:true});sheet.addEventListener("error",resolve,{once:true});setTimeout(resolve,3000)});
    setTimeout(()=>{try{w.onafterprint=cleanup;w.focus();w.print();setTimeout(cleanup,60000)}catch(e){cleanup();alert("چاپ در این نسخه از برنامه پشتیبانی نمی‌شود. لطفاً از گزینه چاپ مرورگر استفاده کنید.")}},300);
  };
  w.addEventListener("load",run,{once:true});
  doc.open();doc.write(html);doc.close();
  if(doc.readyState==="complete")run();
  return frame;
}

function printInvoice(inv,targetWindow=null,autoPrint=true){
  if(!inv)return;
  const seller=inv.seller||{},c=calcInvoice(inv),rows=inv.rows||[];
  const safe=s=>esc(s==null||s===""?"—":String(s));
  const cell=(label,value)=>`<div class="print-head-box"><span>${label}</span><b>${safe(value)}</b></div>`;
  const status=documentStatusLabel(inv.status);
  const filled=(rows.length?rows:[{}]).map((r,j)=>`<tr><td>${fmt(j+1)}</td><td>${safe(r.description)}</td><td>${fmt(r.quantity)}</td><td>${fmt(r.weight)}</td><td>${fmt(r.unitPrice)}</td><td>${fmt(num(r.weight)*num(r.unitPrice))}</td></tr>`);
  const sun=`<svg class="sun-emblem" viewBox="0 0 100 100" role="img" aria-label="خورشید"><circle cx="50" cy="50" r="19"/><circle cx="50" cy="50" r="11"/><g>${Array.from({length:16},(_,i)=>`<path d="M50 5 L50 20" transform="rotate(${i*22.5} 50 50)"/>`).join("")}</g></svg>`;
  const pageHtml=`<main class="invoice-print">
    <header class="print-header">
      <div class="print-head-side">${cell("کد اقتصادی:",seller.economic||"—")}</div>
      <div class="print-head-center">${sun}<h1>${status}</h1></div>
      <div class="print-head-side">${cell("شماره:",fmt(inv.number))}${cell("تاریخ:",inv.date||"—")}</div>
    </header>
    <div class="print-parties">
      <div class="party-line"><span class="party-label">نام فروشنده:</span><span class="party-value">${safe(seller.name)}</span><span class="party-extra">تلفن: ${safe(seller.phone)}</span></div>
      <div class="party-line"><span class="party-label">نام خریدار:</span><span class="party-value">${safe(inv.buyer?.name)}</span><span class="party-extra">تلفن: ${safe(inv.buyer?.phone)}</span></div>
      <div class="party-line double"><span class="party-label">نشانی خریدار:</span><span class="party-value">${safe(inv.buyer?.address)}</span></div>
    </div>
    <div class="print-customer-code"><span>کد شناسایی مشتری: ${safe(inv.buyer?.code)}</span><span>نشانی فروشنده: ${safe(seller.address)}</span></div>
    <table class="print-table"><thead><tr><th>ردیف</th><th>شرح کالا / خدمات</th><th>تعداد</th><th>وزن</th><th>قیمت واحد (ریال)</th><th>قیمت کل (ریال)</th></tr></thead><tbody>${filled.join("")}</tbody></table>
    <div class="print-ending">
      <div class="print-lower"><table class="print-summary"><tbody><tr><td>جمع کالاها</td><td>${fmt(c.subtotal)} ریال</td></tr><tr><td>حساب از قبل</td><td>${fmt(c.previous)} ریال</td></tr><tr><td>تخفیف</td><td>${fmt(c.discount)} ریال</td></tr><tr><td>مالیات (${fmt(inv.taxRate||0)}٪)</td><td>${fmt(c.tax)} ریال</td></tr><tr class="total-row"><td>جمع کل فاکتور</td><td>${fmt(c.total)} ریال</td></tr></tbody></table><div class="print-notes"><strong>توضیحات:</strong><div class="notes-content">${safe(inv.notes)}</div></div></div>
      <div class="signatures"><div class="signature">مهر و امضای فروشنده</div><div class="signature">امضای خریدار</div></div>
    </div>
    <footer class="print-footer"><span>${status}</span><span>با تشکر از خرید شما</span></footer>
  </main>`;
  const html=`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${status} ${fmt(inv.number)}</title><link rel="stylesheet" href="${new URL("./css/print.css",location.href).href}"></head><body>${pageHtml}</body></html>`;
  if(autoPrint)return printHtmlDocument(html);
  const preview=document.createElement("iframe");preview.style.cssText="width:100%;min-height:80vh;border:1px solid #ddd";document.body.appendChild(preview);preview.contentDocument.open();preview.contentDocument.write(html);preview.contentDocument.close();return preview;
}
