/* Factorino v40 — invoice printing */
/* v40 — business emblems: one monoline family (100×100 grid, round caps/joins, shared stroke weight) matching the sun emblem */
const PROFESSION_MARKS={
architecture:'<path d="M16 38L50 15l34 23z"/><path d="M26 46v26M42 46v26M58 46v26M74 46v26"/><path d="M16 82h68"/>',
interior:'<path d="M22 50V40a8 8 0 0 1 8-8h40a8 8 0 0 1 8 8v10"/><path d="M14 56a8 8 0 0 1 16 0v6h40v-6a8 8 0 0 1 16 0v18H14z"/><path d="M24 74v8M76 74v8"/>',
fruit:'<path d="M50 34c-8-8-28-6-28 14 0 16 10 34 20 34 4 0 6-2 8-2s4 2 8 2c10 0 20-18 20-34 0-20-20-22-28-14z"/><path d="M50 34c0-8 2-14 8-18"/><path d="M54 24c4-6 12-6 16-4-2 6-10 8-16 4z"/>',
computer:'<rect x="22" y="24" width="56" height="38" rx="5"/><path d="M10 70h80l-6 8H16z"/><path d="M42 38l-8 6 8 6M58 38l8 6-8 6"/>',
mobile:'<rect x="31" y="12" width="38" height="76" rx="8"/><path d="M44 22h12"/><path d="M50 77h.01"/>',
supermarket:'<path d="M12 22h12l8 40h40l8-30H28"/><circle cx="38" cy="76" r="5"/><circle cx="68" cy="76" r="5"/>',
clothing:'<path d="M36 18l-22 12 8 14 10-5v43h36V39l10 5 8-14-22-12c-2 7-8 11-14 11s-12-4-14-11z"/>',
restaurant:'<path d="M28 14v20c0 7 4 10 10 10s10-3 10-10V14M38 14v70"/><path d="M66 84V14c-8 4-12 14-12 28 0 6 4 8 12 8"/>',
cafe:'<path d="M20 36h48v20a20 20 0 0 1-20 20h-8a20 20 0 0 1-20-20z"/><path d="M68 42h6a10 10 0 0 1 0 20h-8"/><path d="M26 86h36"/><path d="M34 12c-4 5 4 8 0 14M48 12c-4 5 4 8 0 14"/>',
bakery:'<path d="M20 40c0-14 14-22 30-22s30 8 30 22c0 4-3 6-6 6v32H26V46c-3 0-6-2-6-6z"/><path d="M42 32l-5 9M55 30l-5 10M68 32l-5 9"/>',
beauty:'<rect x="34" y="58" width="32" height="26" rx="4"/><path d="M38 58V44h24v14"/><path d="M40 44V26l14-12 6 6v24"/>',
salon:'<circle cx="30" cy="72" r="10"/><circle cx="70" cy="72" r="10"/><path d="M37 64L72 16M63 64L28 16"/>',
medical:'<path d="M38 16h24v22h22v24H62v22H38V62H16V38h22z"/>',
dental:'<path d="M30 20c-10 0-16 8-14 20 2 12 8 16 10 28 1 8 6 14 10 14 6 0 6-18 14-18s8 18 14 18c4 0 9-6 10-14 2-12 8-16 10-28 2-12-4-20-14-20-8 0-12 4-20 4s-12-4-20-4z"/>',
pharmacy:'<g transform="rotate(-45 50 50)"><rect x="14" y="34" width="72" height="32" rx="16"/><path d="M50 34v32"/></g>',
auto:'<path d="M22 64H12V50l8-4 10-18h40l10 18 8 4v14H78"/><circle cx="30" cy="66" r="8"/><circle cx="70" cy="66" r="8"/><path d="M38 64h24M34 46h32"/>',
carshop:'<g transform="rotate(40 50 50)"><path d="M36 12h8v14h12V12h8v18c0 6-4 10-8 12v40a6 6 0 0 1-12 0V42c-4-2-8-6-8-12z"/></g>',
construction:'<rect x="14" y="22" width="72" height="56" rx="4"/><path d="M14 40h72M14 59h72M38 22v18M62 22v18M26 40v19M50 40v19M74 40v19M38 59v19M62 59v19"/>',
electrical:'<path d="M56 10L22 54h24l-4 36 36-46H54z"/>',
plumbing:'<path d="M20 46a30 26 0 0 1 60 0z"/><path d="M50 20V10h22"/><path d="M28 60v8M42 64v14M58 64v14M72 60v8"/>',
agriculture:'<path d="M50 86V46"/><path d="M50 56C28 56 20 42 20 28c18 0 30 8 30 28z"/><path d="M50 46c0-14 10-24 30-26 0 16-8 26-30 26z"/><path d="M30 86h40"/>',
education:'<path d="M50 20L12 40l38 20 38-20z"/><path d="M28 50v16c0 6 10 12 22 12s22-6 22-12V50"/><path d="M88 40v22"/>',
legal:'<path d="M50 16v62M30 82h40"/><path d="M22 28h56"/><path d="M22 28L10 54a12 8 0 0 0 24 0z"/><path d="M78 28L66 54a12 8 0 0 0 24 0z"/>',
transport:'<path d="M20 70H10V28h46v42H36"/><path d="M64 70h-8V40h18l16 16v14h-10"/><circle cx="28" cy="70" r="8"/><circle cx="72" cy="70" r="8"/>',
photography:'<path d="M12 34h18l6-10h28l6 10h18v46H12z"/><circle cx="50" cy="56" r="15"/><circle cx="50" cy="56" r="6"/>',
jewelry:'<path d="M28 20h44l16 20-38 46L12 40z"/><path d="M12 40h76M38 20l12 20 12-20M30 40l20 46 20-46"/>'
};
function emblemSvg(key){const inner=PROFESSION_MARKS[key];return inner?`<svg class="sun-emblem emblem-svg" viewBox="0 0 100 100" role="img" aria-label="نشان کسب‌وکار">${inner}</svg>`:emblemSunSvg()}
function emblemSunSvg(){return `<svg class="sun-emblem" viewBox="0 0 100 100" role="img" aria-label="خورشید"><circle cx="50" cy="50" r="19"/><circle cx="50" cy="50" r="11"/><g>${Array.from({length:16},(_,i)=>`<path d="M50 5 L50 20" transform="rotate(${i*22.5} 50 50)"/>`).join("")}</g></svg>`}
function printInvoice(inv,targetWindow=null,autoPrint=true){
  if(!inv){if(targetWindow)targetWindow.close();return;}
  const seller={...(window.sellerSnapshot||{}),...(inv.seller||{})},c=calcInvoice(inv),rows=inv.rows||[];
  if(!seller.logoData&&window.sellerSnapshot?.logoData){seller.logoData=window.sellerSnapshot.logoData;seller.logoMode=window.sellerSnapshot.logoMode||"custom"}
  if(!seller.profession)seller.profession=window.sellerSnapshot?.profession||"sun";
  const w=targetWindow||window.open("","_blank");
  if(!w){alert("مرورگر اجازه بازکردن پنجره چاپ را نداد. اجازه بازشدن پنجره‌های بازشو را فعال کنید.");return}
  const safe=s=>esc(s==null||s===""?"—":String(s).replace(/\\n/g," "));
  const filledText=v=>String(v??"").replace(/\\n/g," ").trim();
  const phoneView=v=>{const x=filledText(v);return x?`<span class="ltr-run" dir="ltr">${esc(toFaDigits(latinDigits(x)))}</span>`:"—"};
  const cell=(label,value)=>`<div class="print-head-box"><span>${label}</span><b>${safe(value)}</b></div>`;
  const status=documentStatusLabel(inv.status);
  const fallback=seller.unitType||"weight",allCount=rows.length>0&&rows.every(r=>rowUnit(r,fallback)==="count");
  const measureLabel=rows.length&&new Set(rows.map(r=>rowUnit(r,fallback))).size===1?UNIT_LABELS[rowUnit(rows[0],fallback)]:"مقدار";
  const mixedUnits=new Set(rows.map(x=>rowUnit(x,fallback))).size>1;
  const filled=(rows.length?rows:[{}]).map((r,j)=>{const unit=rowUnit(r,fallback),base=rowBase({...r,unitType:unit});return `<tr><td>${fmt(j+1)}</td><td>${safe(r.description)}</td>${allCount?`<td>${fmt(r.quantity??base)}</td>`:`<td>${fmt(r.quantity)}</td><td>${unit==="count"?"":fmt(base)+(mixedUnits?" "+UNIT_LABELS[unit]:"")}</td>`}<td>${fmt(r.unitPrice)}</td><td>${fmt(base*num(r.unitPrice))}</td></tr>`});
  const profession=seller.profession||"sun";
  const emblem=seller.logoMode==="custom"&&seller.logoData
    ?`<img class="invoice-custom-logo" src="${String(seller.logoData).replace(/"/g,"&quot;")}" alt="لوگوی فروشنده">`
    :emblemSvg(profession);
  /* seller and buyer details: every item has its own box; the address rows are printed only when filled */
  const sellerAddress=filledText(seller.address),buyerAddress=filledText(inv.buyer?.address);
  const box=(label,valueHtml,cls="")=>`<div class="party-box ${cls}"><span class="party-label">${label}</span><b class="party-value">${valueHtml}</b></div>`;
  const addressBox=(label,value)=>value?`<div class="party-row one">${box(label,esc(value),"addr")}</div>`:"";
  const bank=invoiceBank(inv),bankView=bank.number?bankPrintNumber(bank.type,bank.number):"";
  const bankBlock=bankView?`<div class="print-bank"><span class="pb-title">${BANK_TYPES[bank.type].title}</span><b class="pb-number${bank.type==='sheba'?' long':''}" dir="ltr">${esc(bankView)}</b>${bank.owner?`<span class="pb-owner"><span>به نام</span><b>${esc(bank.owner)}</b></span>`:""}</div>`:"";
  const pageHtml=`<main class="invoice-print">
    <header class="print-header">
      <div class="print-head-side">${cell("کد اقتصادی:",seller.economic||"—")}</div>
      <div class="print-head-center">${emblem}<h1>${status}</h1></div>
      <div class="print-head-side">${cell("شماره:",fmt(inv.number))}${cell("تاریخ:",typeof finJalaliDate==="function"?finJalaliDate(inv.date):inv.date||"—")}</div>
    </header>
    <section class="print-parties">
      <div class="party-group">
        <div class="party-row">${box("نام فروشنده",safe(seller.name))}${box("تلفن فروشنده",phoneView(seller.phone),"phone")}</div>
        ${addressBox("نشانی فروشنده",sellerAddress)}
      </div>
      <div class="party-group">
        <div class="party-row">${box("نام خریدار",safe(inv.buyer?.name))}${box("تلفن خریدار",phoneView(inv.buyer?.phone),"phone")}</div>
        ${addressBox("نشانی خریدار",buyerAddress)}
      </div>
    </section>
    <table class="print-table${allCount?" count-mode":""}"><thead><tr><th>ردیف</th><th>شرح کالا / خدمات</th><th>تعداد</th>${allCount?"":`<th>${safe(measureLabel)}</th>`}<th>قیمت واحد (ریال)</th><th>قیمت کل (ریال)</th></tr></thead><tbody>${filled.join("")}</tbody></table>
    <div class="print-ending">
      <div class="print-lower">
        <table class="print-summary"><tbody><tr><td>جمع کالاها</td><td><span class="summary-value">${fmt(c.subtotal)} ریال</span></td></tr><tr><td>حساب از قبل</td><td><span class="summary-value">${fmt(c.previous)} ریال</span></td></tr><tr><td>تخفیف</td><td><span class="summary-value">${fmt(c.discount)} ریال</span></td></tr><tr><td>مالیات (${fmt(inv.taxRate||0)}٪)</td><td><span class="summary-value">${fmt(c.tax)} ریال</span></td></tr><tr class="total-row"><td>جمع کل فاکتور</td><td><span class="summary-value">${fmt(c.total)} ریال</span></td></tr></tbody></table>
        <div class="print-side"><div class="print-notes"><strong>توضیحات</strong><div class="notes-content">${safe(inv.notes)}</div></div>${bankBlock}</div>
      </div>
      <div class="signatures"><div class="signature">مهر و امضای فروشنده</div><div class="signature">امضای خریدار</div></div>
    </div>
    <footer class="print-footer"><span class="pf-brand">فاکتورینو</span><span>با تشکر از خرید شما</span></footer>
  </main>`;
  const onReady=()=>{
    let started=false;
    const run=async()=>{
      if(started)return;started=true;
      try{if(w.document.fonts?.ready)await w.document.fonts.ready}catch(e){}
      try{await Promise.all([...w.document.images].map(img=>img.decode?img.decode().catch(()=>{}):new Promise(resolve=>{if(img.complete)resolve();else{img.onload=resolve;img.onerror=resolve}})))}catch(e){}
      const sheet=w.document.querySelector('link[rel="stylesheet"]');
      if(sheet&&!sheet.sheet)await new Promise(resolve=>{sheet.addEventListener("load",resolve,{once:true});sheet.addEventListener("error",resolve,{once:true});setTimeout(resolve,2500)});
      setTimeout(()=>{try{w.focus();w.print()}catch(e){console.error("Print failed:",e)}},250);
    };
    w.addEventListener("load",run,{once:true});
    w.onafterprint=()=>{try{w.close()}catch(e){}};
    return run;
  };
  const runPrint=autoPrint?onReady():null;
  const paper=window.printPaperSize||inv.seller?.paperSize||"A5",isA4=paper==="A4";
  const pageRule=isA4?"@page{size:210mm 297mm;margin:8mm 10mm}":`@page{size:148mm 210mm;margin:${paper==="ISO-A5"?"6mm":"5mm"} 6mm}`;
  w.document.open();
  w.document.write(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${status} ${fmt(inv.number)}</title><link rel="stylesheet" href="${new URL("./css/print.css",location.href).href}"><style>${pageRule}</style></head><body class="${isA4?"paper-a4":"paper-a5"}">${pageHtml}</body></html>`);
  w.document.close();
  if(autoPrint&&w.document.readyState==="complete")runPrint?.();
  return w;
}
