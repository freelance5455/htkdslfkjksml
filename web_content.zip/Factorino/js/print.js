function printInvoice(inv,targetWindow=null,autoPrint=true){
  if(!inv){if(targetWindow)targetWindow.close();return;}
  const seller=inv.seller||{},c=calcInvoice(inv),rows=inv.rows||[];
  const w=targetWindow||window.open("","_blank");
  if(!w){alert("مرورگر اجازه بازکردن پنجره چاپ را نداد. اجازه بازشدن پنجره‌های بازشو را فعال کنید.");return}
  const safe=s=>esc(s==null||s===""?"—":String(s));
  const cell=(label,value)=>`<div class="print-head-box"><span>${label}</span><b>${safe(value)}</b></div>`;
  const status=documentStatusLabel(inv.status);
  const filled=(rows.length?rows:[{}]).map((r,j)=>`<tr><td>${fmt(j+1)}</td><td>${safe(r.description)}</td><td>${fmt(r.quantity)}</td><td>${fmt(r.weight)}</td><td>${fmt(r.unitPrice)}</td><td>${fmt(num(r.weight)*num(r.unitPrice))}</td></tr>`);
  const sun=`<svg class="sun-emblem" viewBox="0 0 100 100" role="img" aria-label="خورشید"><circle cx="50" cy="50" r="19"/><circle cx="50" cy="50" r="11"/><g>${Array.from({length:16},(_,i)=>`<path d="M50 5 L50 20" transform="rotate(${i*22.5} 50 50)"/>`).join("")}</g></svg>`;
  const pageHtml=`<main class="invoice-print">
    <header class="print-header">
      <div class="print-head-side">${cell("کد اقتصادی:",seller.economic||"—")}</div>
      <div class="print-head-center">${sun}<h1>${status}</h1></div>
      <div class="print-head-side">${cell("شماره:",fmt(inv.number))}${cell("تاریخ:",inv.date||"—")}</div>
    </header>
    <div class="print-parties">
      <div class="party-line"><span class="party-label">نام فروشنده:</span><span class="party-value">${safe(seller.name)}</span><span class="party-extra">تلفن: ${safe(seller.phone)}</span></div>
      <div class="party-line"><span class="party-label">نام خریدار:</span><span class="party-value">${safe(inv.buyer?.name)}</span><span class="party-extra">تلفن: ${safe(inv.buyer?.phone)}</span></div>
      <div class="party-line double"><span class="party-label">نشانی خریدار:</span><span class="party-value">${safe(inv.buyer?.address)}</span></div>
    </div>
    <div class="print-customer-code"><span>کد شناسایی مشتری: ${safe(inv.buyer?.code)}</span><span>نشانی فروشنده: ${safe(seller.address)}</span></div>
    <table class="print-table"><thead><tr><th>ردیف</th><th>شرح کالا / خدمات</th><th>تعداد</th><th>وزن</th><th>قیمت واحد (ریال)</th><th>قیمت کل (ریال)</th></tr></thead><tbody>${filled.join("")}</tbody></table>
    <div class="print-ending">
      <div class="print-lower"><table class="print-summary"><tbody><tr><td>جمع کالاها</td><td>${fmt(c.subtotal)} ریال</td></tr><tr><td>حساب از قبل</td><td>${fmt(c.previous)} ریال</td></tr><tr><td>تخفیف</td><td>${fmt(c.discount)} ریال</td></tr><tr><td>مالیات (${fmt(inv.taxRate||0)}٪)</td><td>${fmt(c.tax)} ریال</td></tr><tr class="total-row"><td>جمع کل فاکتور</td><td>${fmt(c.total)} ریال</td></tr></tbody></table><div class="print-notes"><strong>توضیحات:</strong><div class="notes-content">${safe(inv.notes)}</div></div></div>
      <div class="signatures"><div class="signature">مهر و امضای فروشنده</div><div class="signature">امضای خریدار</div></div>
    </div>
    <footer class="print-footer"><span>${status}</span><span>با تشکر از خرید شما</span></footer>
  </main>`;
  const onReady=()=>{
    let started=false;
    const run=async()=>{
      if(started)return;started=true;
      try{if(w.document.fonts?.ready)await w.document.fonts.ready}catch(e){}
      const sheet=w.document.querySelector('link[rel="stylesheet"]');
      if(sheet&&!sheet.sheet)await new Promise(resolve=>{sheet.addEventListener("load",resolve,{once:true});sheet.addEventListener("error",resolve,{once:true});setTimeout(resolve,2500)});
      setTimeout(()=>{try{w.focus();w.print()}catch(e){console.error("Print failed:",e)}},250);
    };
    w.addEventListener("load",run,{once:true});
    w.onafterprint=()=>{try{w.close()}catch(e){}};
    return run;
  };
  const runPrint=autoPrint?onReady():null;
  w.document.open();
  w.document.write(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${status} ${fmt(inv.number)}</title><link rel="stylesheet" href="${new URL("./css/print.css",location.href).href}"></head><body>${pageHtml}</body></html>`);
  w.document.close();
  if(autoPrint&&w.document.readyState==="complete")runPrint?.();
  return w;
}
