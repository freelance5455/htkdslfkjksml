async function exportBackup(){
  try{
    // Export every known application store, including financial stores and sequence metadata.
    const stores=[...new Set([...(DB.stores||[]),...(DB.db?Array.from(DB.db.objectStoreNames):[])])];
    const data={format:"factorino-complete-backup",version:4,appVersion:16,createdAt:new Date().toISOString(),database:{name:DB.name,version:DB.version},stores:{}};
    for(const store of stores)data.stores[store]=await DB.all(store);
    // Keep top-level arrays for compatibility with earlier Factorino backup readers.
    for(const store of stores)data[store]=data.stores[store];
    const counts=Object.fromEntries(stores.map(store=>[store,data.stores[store].length]));
    data.manifest={complete:true,storeNames:stores,recordCounts:counts,totalRecords:Object.values(counts).reduce((a,b)=>a+b,0)};
    const filename="factorino-full-backup-"+new Date().toISOString().slice(0,10)+".json";
    const json=JSON.stringify(data,null,2);
    const blob=new Blob([json],{type:"application/json;charset=utf-8"});
    const file=typeof File==="function"?new File([blob],filename,{type:"application/json;charset=utf-8"}):null;

    // Android WebView may not implement the browser download manager. The native
    // share sheet lets the user save the JSON file to Downloads/Files when supported.
    if(file&&navigator.share&&(!navigator.canShare||navigator.canShare({files:[file]}))){
      try{await navigator.share({title:"نسخه پشتیبان فاکتورینو",text:"فایل پشتیبان اطلاعات فاکتورینو",files:[file]});toast(`نسخه پشتیبان آماده شد؛ ${fmt(data.manifest.totalRecords)} رکورد`);return}
      catch(shareError){if(shareError?.name==="AbortError")return;console.warn("Native share unavailable; trying browser download",shareError)}
    }

    const url=URL.createObjectURL(blob),a=document.createElement("a");
    a.href=url;a.download=filename;a.rel="noopener";a.style.display="none";
    document.body.appendChild(a);a.click();a.remove();
    // Some WebViews need more time to consume the object URL.
    setTimeout(()=>URL.revokeObjectURL(url),60000);
    toast(`فایل پشتیبان آماده شد؛ ${fmt(data.manifest.totalRecords)} رکورد`);
  }catch(e){alert("تهیه نسخه پشتیبان کامل انجام نشد: "+(e.message||e))}
}
async function importBackup(file){
  try{
    const textContent=typeof file.text==="function"?await file.text():await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||""));reader.onerror=()=>reject(reader.error||new Error("خواندن فایل انجام نشد"));reader.readAsText(file,"UTF-8")});
    const data=JSON.parse(textContent);
    if(!data||(!Array.isArray(data.invoices)&&!Array.isArray(data.stores?.invoices))||(!Array.isArray(data.customers)&&!Array.isArray(data.stores?.customers))||(!Array.isArray(data.products)&&!Array.isArray(data.stores?.products)))throw Error("ساختار فایل معتبر نیست");
    const incoming=data.stores&&typeof data.stores==="object"?data.stores:data;
    for(const s of DB.stores)if(!Array.isArray(incoming[s]))incoming[s]=[];
    const counts=await DB.mergeAll(incoming);
    await refreshAll();if(typeof refreshFinance==="function")await refreshFinance();
    toast(`اطلاعات پشتیبان اضافه شد؛ ${fmt(counts.added)} مورد جدید`);
    alert(`بازیابی اطلاعات انجام شد.\nموارد جدید: ${counts.added}\nرکوردهای دارای شناسه تکراری بدون تغییر باقی ماندند.`);
  }catch(e){alert("بازیابی اطلاعات انجام نشد: "+e.message)}
}
