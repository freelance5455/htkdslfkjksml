async function exportBackup(){
  try{
    // Export every known application store, including financial stores and sequence metadata.
    const stores=[...new Set([...(DB.stores||[]),...(DB.db?Array.from(DB.db.objectStoreNames):[])])];
    const data={format:"factorino-complete-backup",version:4,appVersion:14,createdAt:new Date().toISOString(),database:{name:DB.name,version:DB.version},stores:{}};
    for(const store of stores)data.stores[store]=await DB.all(store);
    // Keep top-level arrays for compatibility with earlier Factorino backup readers.
    for(const store of stores)data[store]=data.stores[store];
    const counts=Object.fromEntries(stores.map(store=>[store,data.stores[store].length]));
    data.manifest={complete:true,storeNames:stores,recordCounts:counts,totalRecords:Object.values(counts).reduce((a,b)=>a+b,0)};
    const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");
    a.href=url;a.download="factorino-full-backup-"+new Date().toISOString().slice(0,10)+".json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    toast(`نسخه پشتیبان کامل آماده شد؛ ${fmt(data.manifest.totalRecords)} رکورد از ${fmt(stores.length)} بخش`);
  }catch(e){alert("تهیه نسخه پشتیبان کامل انجام نشد: "+(e.message||e))}
}
async function importBackup(file){
  try{
    const data=JSON.parse(await file.text());
    if(!data||(!Array.isArray(data.invoices)&&!Array.isArray(data.stores?.invoices))||(!Array.isArray(data.customers)&&!Array.isArray(data.stores?.customers))||(!Array.isArray(data.products)&&!Array.isArray(data.stores?.products)))throw Error("ساختار فایل معتبر نیست");
    const incoming=data.stores&&typeof data.stores==="object"?data.stores:data;
    for(const s of DB.stores)if(!Array.isArray(incoming[s]))incoming[s]=[];
    const counts=await DB.mergeAll(incoming);
    await refreshAll();if(typeof refreshFinance==="function")await refreshFinance();
    toast(`اطلاعات پشتیبان اضافه شد؛ ${fmt(counts.added)} مورد جدید`);
    alert(`بازیابی اطلاعات انجام شد.\nموارد جدید: ${counts.added}\nرکوردهای دارای شناسه تکراری بدون تغییر باقی ماندند.`);
  }catch(e){alert("بازیابی اطلاعات انجام نشد: "+e.message)}
}
