async function buildBackupData(){
  // Export every known application store, including financial stores and sequence metadata.
  const stores=[...new Set([...(DB.stores||[]),...(DB.db?Array.from(DB.db.objectStoreNames):[])])];
  const data={format:"factorino-complete-backup",version:4,appVersion:40,createdAt:new Date().toISOString(),database:{name:DB.name,version:DB.version},stores:{}};
  for(const store of stores)data.stores[store]=await DB.all(store);
  // Keep top-level arrays for compatibility with earlier Factorino backup readers.
  for(const store of stores)data[store]=data.stores[store];
  const counts=Object.fromEntries(stores.map(store=>[store,data.stores[store].length]));
  data.manifest={complete:true,storeNames:stores,recordCounts:counts,totalRecords:Object.values(counts).reduce((a,b)=>a+b,0)};
  return{data,stores};
}
/* v40 — the user always chooses where the backup is saved */
async function exportBackup(){
  const fileName="factorino-full-backup-"+new Date().toISOString().slice(0,10)+".json";
  const done=(data,stores,where)=>toast(`نسخه پشتیبان ذخیره شد${where?" در «"+where+"»":""}؛ ${fmt(data.manifest.totalRecords)} رکورد از ${fmt(stores.length)} بخش`);
  let handle=null;
  try{
    // 1) The save dialog must open straight from the click, before any asynchronous work.
    if(typeof window.showSaveFilePicker==="function"){
      try{handle=await window.showSaveFilePicker({suggestedName:fileName,types:[{description:"فایل پشتیبان فاکتورینو (JSON)",accept:{"application/json":[".json"]}}]})}
      catch(e){if(e&&e.name==="AbortError"){toast("ذخیره‌سازی لغو شد؛ فایلی ذخیره نشد");return}throw e}
    }
    const {data,stores}=await buildBackupData(),text=JSON.stringify(data,null,2);
    if(handle){
      const writable=await handle.createWritable();
      try{await writable.write(new Blob([text],{type:"application/json"}));await writable.close()}catch(e){try{await writable.abort()}catch(_){}throw e}
      done(data,stores,handle.name||fileName);return;
    }
    const file=new File([text],fileName,{type:"application/json"});
    // 2) Phones/tablets without a save dialog: the system share sheet lets the user pick "Save to Files" and the folder.
    if(window.matchMedia?.("(pointer:coarse)").matches&&navigator.canShare&&navigator.canShare({files:[file]})&&navigator.share){
      try{await navigator.share({files:[file],title:"پشتیبان فاکتورینو"});done(data,stores,"");return}
      catch(e){if(e&&e.name==="AbortError"){toast("ذخیره‌سازی لغو شد؛ فایلی ذخیره نشد");return}}
    }
    // 3) Browsers without any picker: normal download (the browser decides the folder).
    const url=URL.createObjectURL(file),a=document.createElement("a");
    a.href=url;a.download=fileName;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    done(data,stores,"");
    alert("این مرورگر پنجرهٔ انتخاب محل ذخیره را پشتیبانی نمی‌کند، بنابراین فایل با دانلود معمولی ذخیره شد.\nبرای انتخاب پوشه، در تنظیمات مرورگر گزینهٔ «پرسیدن محل ذخیره هر دانلود» را فعال کنید یا از Chrome/Edge استفاده کنید.");
  }catch(e){alert("ذخیرهٔ نسخه پشتیبان انجام نشد: "+(e.message||e))}
}
async function importBackup(file){
  try{
    const data=JSON.parse(await file.text());
    if(!data||(!Array.isArray(data.invoices)&&!Array.isArray(data.stores?.invoices))||(!Array.isArray(data.customers)&&!Array.isArray(data.stores?.customers))||(!Array.isArray(data.products)&&!Array.isArray(data.stores?.products)))throw Error("ساختار فایل معتبر نیست");
    const incoming=data.stores&&typeof data.stores==="object"?data.stores:data;
    for(const s of DB.stores)if(!Array.isArray(incoming[s]))incoming[s]=[];
    const counts=await DB.mergeAll(incoming);
    await refreshAll();if(typeof refreshFinance==="function")await refreshFinance();
    toast(`اطلاعات پشتیبان اضافه شد؛ ${fmt(counts.added)} مورد جدید`);
    alert(`بازیابی اطلاعات انجام شد.\nموارد جدید: ${counts.added}\nرکوردهای دارای شناسه تکراری بدون تغییر باقی ماندند.`);
  }catch(e){alert("بازیابی اطلاعات انجام نشد: "+e.message)}
}
