/* Factorino v37 — Jalali date picker.
   One shared popup for the whole app (no per-field panels, no global listener leaks).
   Desktop: popover anchored to the field, measured after it is rendered and clamped to the viewport.
   Phone:   bottom sheet with a backdrop, so it can never spill past the screen edges. */
(function(){
"use strict";
const FA=n=>String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[+d]);
const WEEK=["ش","ی","د","س","چ","پ","ج"];
const WEEK_FULL=["شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنج‌شنبه","جمعه"];
const ICON={prev:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',next:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',cal:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15.5" rx="3.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M3.5 10h17M8 3v4M16 3v4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'};
const MQ=window.matchMedia?matchMedia("(max-width:640px)"):{matches:false};
let root,sheet,backdrop,monthSel,yearSel,grid,title,active=null,view={year:0,month:0},focusIso="";

const pad=n=>String(n).padStart(2,"0");
const toIso=(y,m,d)=>jalaliToISO(y,m,d);
function weekdayIndex(iso){const [y,m,d]=iso.split("-").map(Number);return (new Date(y,m-1,d,12).getDay()+1)%7}
function shiftIso(iso,days){const [y,m,d]=iso.split("-").map(Number),dt=new Date(y,m-1,d+days,12);return `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}`}
function label(iso){if(!iso)return "";const p=finJalaliParts(iso);return `${FA(p.year)}/${FA(pad(p.month))}/${FA(pad(p.day))}`}

function build(){
  root=document.createElement("div");root.className="fcal-root";root.hidden=true;
  root.innerHTML=`<div class="fcal-backdrop" data-fcal-close></div>
  <div class="fcal" role="dialog" aria-modal="false" aria-label="تقویم شمسی" dir="rtl">
    <div class="fcal-grab" aria-hidden="true"></div>
    <div class="fcal-head">
      <button type="button" class="fcal-nav" data-fcal-prev aria-label="ماه قبل">${ICON.prev}</button>
      <div class="fcal-selects"><select data-fcal-month aria-label="ماه"></select><select data-fcal-year aria-label="سال"></select></div>
      <button type="button" class="fcal-nav" data-fcal-next aria-label="ماه بعد">${ICON.next}</button>
    </div>
    <div class="fcal-week" aria-hidden="true">${WEEK.map((w,i)=>`<span class="${i===6?"is-fri":""}">${w}</span>`).join("")}</div>
    <div class="fcal-grid" role="grid" data-fcal-grid></div>
    <div class="fcal-foot"><button type="button" class="fcal-today" data-fcal-today>امروز</button><button type="button" class="fcal-close" data-fcal-close>بستن</button></div>
  </div>`;
  document.body.appendChild(root);
  sheet=root.querySelector(".fcal");monthSel=root.querySelector("[data-fcal-month]");yearSel=root.querySelector("[data-fcal-year]");grid=root.querySelector("[data-fcal-grid]");
  FIN_JMONTHS.forEach((n,i)=>monthSel.add(new Option(n,i+1)));
  root.addEventListener("click",e=>{
    if(e.target.closest("[data-fcal-close]"))return close();
    if(e.target.closest("[data-fcal-prev]"))return step(-1);
    if(e.target.closest("[data-fcal-next]"))return step(1);
    if(e.target.closest("[data-fcal-today]"))return pick(finToday());
    const day=e.target.closest("[data-iso]");if(day)pick(day.dataset.iso);
  });
  monthSel.addEventListener("change",()=>{view.month=+monthSel.value;render()});
  yearSel.addEventListener("change",()=>{view.year=+yearSel.value;render()});
  root.addEventListener("keydown",onKey);
  document.addEventListener("pointerdown",e=>{if(!active||root.hidden)return;if(sheet.contains(e.target)||active.wrap.contains(e.target))return;close()},true);
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!root.hidden){e.stopPropagation();close(true)}},true);
  const reflow=()=>{if(!root.hidden)place()};
  window.addEventListener("resize",reflow);
  window.addEventListener("scroll",e=>{if(root.hidden||sheet.contains(e.target))return;MQ.matches?null:place()},true);
  (window.visualViewport||window).addEventListener("resize",reflow);
  /* If the dialog that hosts the field is closed or removed, the calendar goes with it. */
  new MutationObserver(()=>{if(active&&!document.body.contains(active.visible))close()}).observe(document.body,{childList:true,subtree:true});
  const modal=document.getElementById("modal");if(modal)new MutationObserver(()=>{if(!modal.classList.contains("open"))close()}).observe(modal,{attributes:true,attributeFilter:["class"]});
}

function render(){
  const {year,month}=view,days=finJalaliMonthDays(year,month),first=toIso(year,month,1),offset=weekdayIndex(first),today=finToday(),selected=active?.input.value||"";
  monthSel.value=String(month);
  yearSel.innerHTML="";for(let y=year-25;y<=year+25;y++)yearSel.add(new Option(FA(y),y));yearSel.value=String(year);
  if(!focusIso||finJalaliParts(focusIso).month!==month||finJalaliParts(focusIso).year!==year)focusIso=selected&&finJalaliParts(selected).month===month&&finJalaliParts(selected).year===year?selected:first;
  let html="";
  for(let i=0;i<offset;i++)html+='<span class="fcal-blank"></span>';
  for(let d=1;d<=days;d++){
    const iso=toIso(year,month,d),wd=(offset+d-1)%7;
    html+=`<button type="button" role="gridcell" class="fcal-day${iso===selected?" is-selected":""}${iso===today?" is-today":""}${wd===6?" is-fri":""}" data-iso="${iso}" tabindex="${iso===focusIso?0:-1}" aria-label="${WEEK_FULL[wd]} ${FA(d)} ${FIN_JMONTHS[month-1]} ${FA(year)}"${iso===selected?' aria-selected="true"':""}>${FA(d)}</button>`;
  }
  grid.innerHTML=html;
}
function step(n){view.month+=n;if(view.month>12){view.month=1;view.year++}if(view.month<1){view.month=12;view.year--}render();place()}
function pick(iso){
  if(!active)return;const {input}=active;input.value=iso;input._jalaliSync?.();
  input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}));close(true);
}
function onKey(e){
  const btn=e.target.closest?.(".fcal-day");if(!btn)return;
  const map={ArrowRight:-1,ArrowLeft:1,ArrowUp:-7,ArrowDown:7};
  if(e.key in map||e.key==="PageUp"||e.key==="PageDown"){
    e.preventDefault();let next=btn.dataset.iso;
    if(e.key in map)next=shiftIso(next,map[e.key]);
    else{const p=finJalaliParts(next),m=p.month+(e.key==="PageDown"?1:-1),y=m>12?p.year+1:m<1?p.year-1:p.year,mm=m>12?1:m<1?12:m;next=toIso(y,mm,Math.min(p.day,finJalaliMonthDays(y,mm)))}
    const p=finJalaliParts(next);focusIso=next;view={year:p.year,month:p.month};render();place();grid.querySelector(`[data-iso="${next}"]`)?.focus();
  }
}

function place(){
  if(!active)return;
  const vv=window.visualViewport,vw=vv?vv.width:innerWidth,vh=vv?vv.height:innerHeight,pad8=8;
  root.classList.toggle("is-sheet",MQ.matches);
  sheet.style.cssText="";
  if(MQ.matches)return;                       /* phone: CSS positions the bottom sheet */
  const f=active.wrap.getBoundingClientRect();
  if(f.bottom<0||f.top>vh){close();return}
  sheet.style.visibility="hidden";sheet.style.left="0px";sheet.style.top="0px";sheet.style.maxHeight="";
  const w=Math.min(sheet.offsetWidth,vw-pad8*2),h=sheet.offsetHeight,gap=8;
  const below=vh-f.bottom-gap-pad8,above=f.top-gap-pad8;
  let top,maxH=null;
  if(h<=below)top=f.bottom+gap;
  else if(h<=above)top=f.top-gap-h;
  else if(below>=above){top=f.bottom+gap;maxH=Math.max(220,below)}
  else{maxH=Math.max(220,above);top=Math.max(pad8,f.top-gap-maxH)}
  let left=f.right-w;                          /* RTL: align to the field's end edge */
  left=Math.min(Math.max(pad8,left),vw-w-pad8);
  sheet.style.left=left+"px";sheet.style.top=top+"px";if(maxH)sheet.style.maxHeight=maxH+"px";
  sheet.style.visibility="";
}
function open(ctx){
  if(!root)build();
  if(active&&active!==ctx)active.wrap.classList.remove("is-open");
  active=ctx;
  const start=ctx.input.value&&finNormalizeDate(ctx.input.value)||finToday(),p=finJalaliParts(start);
  view={year:p.year,month:p.month};focusIso=start;
  render();root.hidden=false;place();
  ctx.wrap.classList.add("is-open");ctx.visible.setAttribute("aria-expanded","true");
  requestAnimationFrame(()=>{root.classList.add("is-on");if(MQ.matches)document.documentElement.classList.add("fcal-lock")});
}
function close(restoreFocus){
  if(!root||root.hidden)return;
  const ctx=active;active=null;root.classList.remove("is-on");root.hidden=true;document.documentElement.classList.remove("fcal-lock");
  if(ctx){ctx.wrap.classList.remove("is-open");ctx.visible.setAttribute("aria-expanded","false");if(restoreFocus&&document.body.contains(ctx.visible))ctx.visible.focus({preventScroll:true})}
}

window.initJalaliDatePicker=function(input){
  if(!input||input.dataset.jalaliReady)return;
  input.dataset.jalaliReady="1";
  const normalized=finNormalizeDate(input.value);input.value=normalized||(input.required?finToday():"");
  input.type="hidden";
  const wrap=document.createElement("div");wrap.className="fdp";
  input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);
  const visible=document.createElement("input");visible.type="text";visible.className="fdp-input";visible.readOnly=true;visible.autocomplete="off";visible.inputMode="none";
  visible.placeholder="انتخاب تاریخ";visible.setAttribute("aria-label","تاریخ شمسی");visible.setAttribute("aria-haspopup","dialog");visible.setAttribute("aria-expanded","false");
  const btn=document.createElement("button");btn.type="button";btn.className="fdp-btn";btn.innerHTML=ICON.cal;btn.setAttribute("aria-label","باز کردن تقویم شمسی");
  wrap.append(visible,btn);
  const ctx={input,visible,wrap};
  const sync=()=>{visible.value=label(finNormalizeDate(input.value))};input._jalaliSync=sync;
  const toggle=e=>{e.preventDefault();active===ctx&&!root.hidden?close():open(ctx)};
  visible.addEventListener("click",toggle);btn.addEventListener("click",toggle);
  visible.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "||e.key==="ArrowDown"){e.preventDefault();open(ctx)}});
  input.addEventListener("change",sync);sync();
};
window.initAllJalaliDatePickers=function(scope=document){scope.querySelectorAll('input[type="date"]').forEach(window.initJalaliDatePicker)};
})();
