const CACHE="factorino-v40";
const ASSETS=["./","./index.html","./css/main.css","./css/responsive.css","./css/v34-theme.css","./css/v36-polish.css","./css/calendar.css","./css/dark.css","./css/v39.css","./css/v40.css","./css/print.css","./css/report-print.css","./js/database.js","./js/calculations.js","./js/backup.js","./js/print.js","./js/customers.js","./js/products.js","./js/invoice.js","./js/app.js","./js/finance.js","./js/calendar.js","./manifest.webmanifest","./assets/factorino-icon.png","./assets/factorino-icon-192.png","./assets/factorino-icon-512.png","./assets/profile.png","./assets/fonts/Vazir-Light.ttf","./assets/fonts/Vazir-Bold.ttf"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET")return;
  const url=new URL(e.request.url);
  if(url.origin!==self.location.origin){
    e.respondWith(new Response("This offline application does not access external resources.",{status:504,statusText:"Offline"}));
    return;
  }
  e.respondWith(
    caches.match(e.request).then(cached=>{
      if(cached)return cached;
      return fetch(e.request).then(response=>{
        if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(e.request,copy));}
        return response;
      }).catch(()=>caches.match("./index.html"));
    })
  );
});
