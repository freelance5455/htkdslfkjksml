CryptoPulse V101.7
- Compact chart height for mobile.
- Candles use a narrow fixed visual body (3-7 px) so a single candle never fills the chart width.
- Darker grid/axis labels and stronger candle colors.
- Chart now starts the LBank WebSocket before history loading and waits for one-time 1-minute kline history as a fallback.
- REST kline requests include the required current `time` parameter.
- Live LBank price remains unchanged.
