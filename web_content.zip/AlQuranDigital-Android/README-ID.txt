PROYEK ANDROID - AL-QUR'AN DIGITAL
Pengembang: Hendrik Permana
Package: com.studiobaru.qurandigital

ISI:
- Website asli dari ZIP pengguna disimpan di app/src/main/assets/
- Android WebView memuat website dari AndroidX WebKit AssetLoader.
- Izin INTERNET disertakan karena jadwal sholat, data surat, dan audio
  mengambil data dari layanan online.
- Ikon launcher sederhana bernuansa hijau dan emas sudah disiapkan.

CARA MEMBANGUN APK:
1. Ekstrak ZIP proyek ini.
2. Buka folder AlQuranDigital sebagai proyek Gradle di IDE Android
   yang mendukung Android Gradle Plugin 8.7.3.
3. Pastikan SDK Android API 35 dan JDK 17 tersedia.
4. Tunggu Gradle Sync dan unduhan dependensi selesai.
5. Pilih Build > Build APK(s), atau jalankan:
   gradle assembleDebug
6. APK debug akan berada di:
   app/build/outputs/apk/debug/app-debug.apk

CATATAN:
- Ini adalah proyek sumber Android, bukan file APK yang sudah dikompilasi.
- Build memerlukan Android SDK, JDK 17, Gradle, dan koneksi internet
  untuk mengunduh plugin/dependensi.
- Fitur jadwal sholat, daftar surat, dan audio membutuhkan internet.
- Uji aplikasi di perangkat sebelum membagikannya.
