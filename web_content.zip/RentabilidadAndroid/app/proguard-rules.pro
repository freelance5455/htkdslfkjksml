# No se requieren reglas adicionales para la versión inicial.
