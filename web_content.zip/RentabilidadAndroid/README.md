# Rentabilidad x KG — Proyecto Android

Proyecto Android Studio que empaqueta la versión web actual de **Rentabilidad x KG** dentro de una aplicación Android nativa mediante WebView.

## Incluye
- Navegación por iconos y botón de tema claro/oscuro.
- La app HTML actual en `app/src/main/assets/index.html`.
- WebView con JavaScript y almacenamiento DOM habilitados para conservar los datos locales (`localStorage`).
- Icono, nombre de aplicación y configuración inicial de Android.

## Abrir y compilar
1. Descomprime el ZIP.
2. Abre Android Studio y selecciona **Open**.
3. Selecciona la carpeta `RentabilidadAndroid` (la que contiene `settings.gradle.kts`).
4. Acepta la sincronización de Gradle y espera a que descargue las herramientas necesarias.
5. Para probar: conecta un teléfono con depuración USB o crea un emulador y pulsa **Run**.
6. Para generar un APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El APK de depuración suele quedar en `app/build/outputs/apk/debug/app-debug.apk`.

## Actualizar el contenido web
Reemplaza `app/src/main/assets/index.html` por una nueva versión del HTML y vuelve a compilar.

## Detalles técnicos
- Paquete: `com.rentabilidad.app`
- Versión: `1.0.0` (versionCode 1)
- Android mínimo: Android 6.0 (API 23)
- `compileSdk`: 35; `targetSdk`: 34
- No solicita permisos de Internet ni de ubicación; los datos se almacenan localmente en el WebView.

## Nota
Este archivo es el **proyecto fuente**, no un APK ya compilado. La primera sincronización requiere conexión a Internet para descargar Gradle y el Android Gradle Plugin.
