طريقة بناء ملف APK:
1) ثبّت Android Studio (مجاني) من developer.android.com/studio
2) افتح البرنامج واختر File > Open ثم اختر مجلد GardenPlanner بعد فك الضغط
3) انتظر انتهاء مزامنة Gradle (يلزم اتصال بالإنترنت أول مرة)
4) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s)
5) سيظهر رابط Locate لملف app-debug.apk، انقله إلى هاتفك وثبّته (فعّل "التثبيت من مصادر غير معروفة" إن طُلب)
للتعديل على البرنامج: app/src/main/assets/index.html
