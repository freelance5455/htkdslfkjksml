#!/usr/bin/env node
/* The Chaos Club — zero-dependency server.
 *  - Serves the website from ./public
 *  - Real-time online rooms over WebSocket (/ws), server-authoritative game engine
 *  - AI translation proxy (/api/translate) for any typed language, when ANTHROPIC_API_KEY is set
 *
 *  Run:  node server.js        (PORT defaults to 8080)
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Engine = require('./public/js/engine.js');
const EN = require('./public/lang/en.js');

const PORT = Number(process.env.PORT) || 8080;
const PUBLIC = path.join(__dirname, 'public');
const CACHE_DIR = path.join(__dirname, '.translation-cache');
const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const MODEL = process.env.TRANSLATE_MODEL || 'claude-haiku-5-5';
const API_BASE = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, '');
const AUTO_PLAY_MS = Number(process.env.AUTO_PLAY_MS) || 15000; // auto-move for disconnected players
const MAX_MSG = 16 * 1024;

// ---------------------------------------------------------------- static files
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}
function json(res, code, obj) { cors(res); res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); }

function serveStatic(req, res) {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

// ---------------------------------------------------------------- translation
const memCache = new Map();
const inflight = new Map();
const slug = (s) => s.toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '').slice(0, 60) || 'x';
const placeholders = (s) => (String(s).match(/\{[a-zA-Z0-9_]+\}/g) || []).sort().join('|');

async function claude(system, user, maxTokens) {
  const r = await fetch(API_BASE + '/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, system, messages: [{ role: 'user', content: user }] }),
  });
  if (!r.ok) throw new Error('Anthropic API ' + r.status + ': ' + (await r.text()).slice(0, 300));
  const data = await r.json();
  const text = (data.content || []).map((c) => c.text || '').join('');
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) throw new Error('No JSON in model reply');
  return JSON.parse(m[0]);
}

async function translateAll(language) {
  const key = slug(language);
  if (memCache.has(key)) return memCache.get(key);
  const file = path.join(CACHE_DIR, key + '.json');
  if (fs.existsSync(file)) { const d = JSON.parse(fs.readFileSync(file, 'utf8')); memCache.set(key, d); return d; }
  if (inflight.has(key)) return inflight.get(key);

  const job = (async () => {
    const meta = await claude(
      'You identify languages. Reply with JSON only.',
      `The user typed this language name: ${JSON.stringify(language)}.\nReturn {"ok":true|false,"code":"BCP-47 code","name":"the language's own name for itself","dir":"ltr"|"rtl"}. ok=false only if it is clearly not a language or dialect (playful styles like "Pirate English" are fine).`, 300);
    if (!meta.ok) { const e = new Error('notALanguage'); e.userFacing = true; throw e; }

    const entries = Object.entries(EN.strings);
    const chunks = []; for (let i = 0; i < entries.length; i += 70) chunks.push(Object.fromEntries(entries.slice(i, i + 70)));
    const system = `You translate the user interface of "The Chaos Club", a funny, family-friendly board game, into ${meta.name} (${meta.code}).
Rules: return ONLY a JSON object with exactly the same keys. Translate every value naturally and keep the jokes funny for all ages.
Keep every {placeholder} exactly as written. Keep emoji. Keep translations short enough for buttons where the English is short.`;
    const out = {};
    let next = 0;
    async function worker() {
      while (next < chunks.length) {
        const chunk = chunks[next++];
        let res = {};
        for (let attempt = 0; attempt < 2; attempt++) {
          try { res = await claude(system, JSON.stringify(chunk), 8000); break; } catch (e) { if (attempt) console.warn('translate chunk failed:', e.message); }
        }
        for (const k of Object.keys(chunk)) {
          const v = res[k];
          out[k] = (typeof v === 'string' && v.trim() && placeholders(v) === placeholders(chunk[k])) ? v : chunk[k];
        }
      }
    }
    await Promise.all([worker(), worker(), worker(), worker()]);
    const translated = Object.keys(out).filter((k) => out[k] !== EN.strings[k]).length;
    const result = { lang: { code: meta.code, name: meta.name, dir: meta.dir === 'rtl' ? 'rtl' : 'ltr' }, strings: out, coverage: translated / entries.length };
    if (result.coverage > 0.5) {
      memCache.set(key, result);
      try { fs.mkdirSync(CACHE_DIR, { recursive: true }); fs.writeFileSync(file, JSON.stringify(result)); } catch (e) { /* cache is optional */ }
    }
    return result;
  })();
  inflight.set(key, job);
  try { return await job; } finally { inflight.delete(key); }
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const parts = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('tooLarge')); req.destroy(); } else parts.push(c); });
    req.on('end', () => resolve(Buffer.concat(parts).toString('utf8')));
    req.on('error', reject);
  });
}

// ---------------------------------------------------------------- HTTP
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname.startsWith('/api/')) {
    if (req.method === 'OPTIONS') { cors(res); res.writeHead(204); return res.end(); }
    if (url.pathname === '/api/status') return json(res, 200, { ok: true, translate: !!API_KEY, model: API_KEY ? MODEL : null, rooms: rooms.size });
    if (url.pathname === '/api/translate' && req.method === 'POST') {
      if (!API_KEY) return json(res, 501, { error: 'notConfigured' });
      try {
        const body = JSON.parse(await readBody(req, 2000));
        const language = String(body.language || '').trim().slice(0, 60);
        if (!language) return json(res, 400, { error: 'empty' });
        return json(res, 200, await translateAll(language));
      } catch (e) {
        console.warn('translate error:', e.message);
        return json(res, e.userFacing ? 422 : 502, { error: e.userFacing ? e.message : 'translateFailed' });
      }
    }
    return json(res, 404, { error: 'notFound' });
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  serveStatic(req, res);
});

// ---------------------------------------------------------------- minimal WebSocket (RFC 6455)
function upgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return null; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const ws = { socket, open: true, lastSeen: Date.now(), onmessage: null, onclose: null };
  let buf = Buffer.alloc(0); let frags = [];
  const frame = (op, data) => {
    const len = data.length; let head;
    if (len < 126) head = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
    return Buffer.concat([head, data]);
  };
  ws.send = (obj) => { if (ws.open) try { socket.write(frame(1, Buffer.from(JSON.stringify(obj)))); } catch (e) { /* closed */ } };
  ws.close = () => {
    if (!ws.open) return; ws.open = false;
    try { socket.write(frame(8, Buffer.alloc(0))); socket.end(); } catch (e) { /* ignore */ }
    if (ws.onclose) ws.onclose();
  };
  socket.on('data', (chunk) => {
    ws.lastSeen = Date.now();
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const fin = buf[0] & 0x80, op = buf[0] & 0x0f, masked = buf[1] & 0x80;
      let len = buf[1] & 0x7f, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > MAX_MSG) return ws.close();
      const maskAt = off; if (masked) off += 4;
      if (buf.length < off + len) return;
      let payload = Buffer.from(buf.subarray(off, off + len));
      if (masked) for (let i = 0; i < payload.length; i++) payload[i] ^= buf[maskAt + (i & 3)];
      buf = buf.subarray(off + len);
      if (op === 8) return ws.close();
      if (op === 9) { try { socket.write(frame(10, payload)); } catch (e) { /* ignore */ } continue; }
      if (op === 10) continue;
      frags.push(payload);
      if (frags.reduce((s, b) => s + b.length, 0) > MAX_MSG) return ws.close();
      if (fin) {
        const text = Buffer.concat(frags).toString('utf8'); frags = [];
        let msg; try { msg = JSON.parse(text); } catch (e) { continue; }
        if (ws.onmessage) ws.onmessage(msg);
      }
    }
  });
  socket.on('close', () => { if (ws.open) { ws.open = false; if (ws.onclose) ws.onclose(); } });
  socket.on('error', () => socket.destroy());
  return ws;
}

// ---------------------------------------------------------------- rooms
const rooms = new Map();
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const COLORS = ['#FF453A', '#FF9F0A', '#FFD60A', '#32D74B', '#64D2FF', '#0A84FF', '#BF5AF2', '#FF375F'];
function newCode() { let c; do { c = Array.from({ length: 5 }, () => CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]).join(''); } while (rooms.has(c)); return c; }
const clean = (s, n) => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, n);

function roomView(room) {
  return {
    code: room.code, phase: room.game ? 'game' : 'lobby', settings: room.settings,
    players: room.seats.map((s, i) => ({ seat: i, name: s.name, auto: !!s.auto, avatar: s.avatar, color: s.color, online: !!(s.ws && s.ws.open), host: i === room.host })),
  };
}
function broadcast(room, msg) { room.seats.forEach((s) => s.ws && s.ws.send(msg)); }
function sendLobby(room) { room.seats.forEach((s, i) => s.ws && s.ws.send({ t: 'lobby', room: roomView(room), you: i })); }

function freeColor(room, want, self) {
  const used = room.seats.filter((s) => s !== self).map((s) => s.color);
  if (COLORS.includes(want) && !used.includes(want)) return want;
  return COLORS.find((c) => !used.includes(c));
}

function runAction(room, seat, action) {
  const r = Engine.applyAction(room.game, seat, action);
  if (!r.ok) { if (r.detail) console.error(r.detail); return r; }
  room.seq++;
  broadcast(room, { t: 'events', events: r.events, seq: room.seq });
  scheduleAuto(room);
  return r;
}

// If the player who must act is offline, act for them after a grace period.
function scheduleAuto(room) {
  clearTimeout(room.autoTimer);
  if (!room.game || room.game.phase === 'over') return;
  const actor = Engine.actorOf(room.game);
  if (actor === null) return;
  const seat = room.seats[actor];
  if (seat && seat.ws && seat.ws.open) return;
  room.autoTimer = setTimeout(() => {
    const a = Engine.botAction(room.game);
    if (a && Engine.actorOf(room.game) === actor) runAction(room, actor, a);
  }, AUTO_PLAY_MS);
}

function leaveSeat(room, seatIdx) {
  if (room.game) return; // seats are fixed once a game starts
  room.seats.splice(seatIdx, 1);
  if (!room.seats.length) { rooms.delete(room.code); return; }
  if (room.host >= room.seats.length || room.host === seatIdx) room.host = 0;
  else if (room.host > seatIdx) room.host--;
  room.seats.forEach((s, i) => { if (s.ws) s.ws.seat = i; });
  sendLobby(room);
}

function handle(ws, m) {
  if (!m || typeof m.t !== 'string') return;
  const room = ws.room ? rooms.get(ws.room) : null;
  const seat = room ? room.seats[ws.seat] : null;
  switch (m.t) {
    case 'ping': return ws.send({ t: 'pong' });
    case 'create': {
      if (room) return;
      const code = newCode();
      const r = { code, host: 0, seats: [], game: null, seq: 0, settings: { rounds: 15, chaos: 'chaotic' }, created: Date.now(), touched: Date.now() };
      rooms.set(code, r);
      const s = { name: clean(m.name, 16) || 'Host', auto: !clean(m.name, 16), avatar: clean(m.avatar, 20), color: null, token: crypto.randomBytes(12).toString('hex'), ws };
      s.color = freeColor(r, m.color, s);
      r.seats.push(s); ws.room = code; ws.seat = 0;
      ws.send({ t: 'joined', code, seat: 0, token: s.token });
      return sendLobby(r);
    }
    case 'join': {
      if (room) return;
      const r = rooms.get(clean(m.code, 8).toUpperCase());
      if (!r) return ws.send({ t: 'error', code: 'noRoom' });
      if (r.game) return ws.send({ t: 'error', code: 'inProgress' });
      if (r.seats.length >= 4) return ws.send({ t: 'error', code: 'full' });
      const s = { name: clean(m.name, 16) || 'Player', auto: !clean(m.name, 16), avatar: clean(m.avatar, 20), color: null, token: crypto.randomBytes(12).toString('hex'), ws };
      s.color = freeColor(r, m.color, s);
      r.seats.push(s); ws.room = r.code; ws.seat = r.seats.length - 1; r.touched = Date.now();
      ws.send({ t: 'joined', code: r.code, seat: ws.seat, token: s.token });
      return sendLobby(r);
    }
    case 'rejoin': {
      if (room) return;
      const r = rooms.get(clean(m.code, 8).toUpperCase());
      const idx = r ? r.seats.findIndex((s) => s.token === m.token) : -1;
      if (idx < 0) return ws.send({ t: 'error', code: 'rejoinFailed' });
      const s = r.seats[idx];
      if (s.ws && s.ws !== ws && s.ws.open) { s.ws.onclose = null; s.ws.close(); }
      s.ws = ws; ws.room = r.code; ws.seat = idx; r.touched = Date.now();
      ws.send({ t: 'joined', code: r.code, seat: idx, token: s.token });
      sendLobby(r);
      if (r.game) { ws.send({ t: 'sync', state: r.game, seq: r.seq }); scheduleAuto(r); }
      return;
    }
    case 'profile': {
      if (!seat || room.game) return;
      if (m.name != null) { seat.name = clean(m.name, 16) || 'Player'; seat.auto = !clean(m.name, 16); }
      if (m.avatar) seat.avatar = clean(m.avatar, 20);
      if (m.color) seat.color = freeColor(room, m.color, seat);
      return sendLobby(room);
    }
    case 'settings': {
      if (!seat || room.game || ws.seat !== room.host) return;
      if ([10, 15, 20].includes(m.rounds)) room.settings.rounds = m.rounds;
      if (Engine.LEVELS[m.chaos]) room.settings.chaos = m.chaos;
      return sendLobby(room);
    }
    case 'start': {
      if (!seat || room.game || ws.seat !== room.host) return;
      if (room.seats.length < 2) return ws.send({ t: 'error', code: 'needTwo' });
      room.game = Engine.createGame(room.seats.map((s) => ({ name: s.name, auto: !!s.auto, avatar: s.avatar, color: s.color })), room.settings);
      const events = Engine.begin(room.game);
      room.seq = 1;
      sendLobby(room);
      broadcast(room, { t: 'events', events, seq: room.seq, start: true });
      return scheduleAuto(room);
    }
    case 'act': {
      if (!seat || !room.game) return;
      room.touched = Date.now();
      const r = runAction(room, ws.seat, m.action);
      if (!r.ok) ws.send({ t: 'error', code: r.error === 'notYourTurn' ? 'notYourTurn' : 'badAction', resync: true, state: room.game, seq: room.seq });
      return;
    }
    case 'emote': {
      if (!seat) return;
      const now = Date.now(); if (seat.lastEmote && now - seat.lastEmote < 600) return; seat.lastEmote = now;
      const e = clean(m.e, 8); if (!e) return;
      return broadcast(room, { t: 'emote', seat: ws.seat, e });
    }
    case 'rematch': {
      if (!seat || ws.seat !== room.host || !room.game || room.game.phase !== 'over') return;
      room.game = null; clearTimeout(room.autoTimer);
      return sendLobby(room);
    }
    case 'leave': {
      if (!seat) return;
      const r = room, idx = ws.seat; ws.room = null; ws.seat = null;
      if (r.game) { seat.ws = null; sendLobby(r); scheduleAuto(r); } else leaveSeat(r, idx);
      return;
    }
  }
}

server.on('upgrade', (req, socket) => {
  if (new URL(req.url, 'http://x').pathname !== '/ws') return socket.destroy();
  const ws = upgrade(req, socket);
  if (!ws) return;
  ws.onmessage = (m) => { try { handle(ws, m); } catch (e) { console.error(e); } };
  ws.onclose = () => {
    const room = ws.room && rooms.get(ws.room);
    if (!room) return;
    const s = room.seats[ws.seat];
    if (!s || s.ws !== ws) return;
    if (room.game) { s.ws = null; sendLobby(room); scheduleAuto(room); }
    else {
      // give lobby players a moment to reconnect before freeing their seat
      s.ws = null; sendLobby(room);
      setTimeout(() => { const r = rooms.get(room.code); if (r && !r.game && r.seats.includes(s) && !s.ws) leaveSeat(r, r.seats.indexOf(s)); }, 20000);
    }
  };
});

// housekeeping: drop dead sockets and abandoned rooms
setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms) {
    room.seats.forEach((s) => { if (s.ws && now - s.ws.lastSeen > 70000) s.ws.close(); });
    const anyone = room.seats.some((s) => s.ws && s.ws.open);
    if (!anyone && now - room.touched > 30 * 60 * 1000) { clearTimeout(room.autoTimer); rooms.delete(code); }
  }
}, 15000).unref();

server.listen(PORT, () => {
  console.log(`\n  🐔  The Chaos Club is running at http://localhost:${PORT}`);
  console.log(`      Online rooms: enabled (WebSocket /ws)`);
  console.log(`      AI translation: ${API_KEY ? 'enabled (' + MODEL + ')' : 'off — set ANTHROPIC_API_KEY to translate into any language'}\n`);
});
