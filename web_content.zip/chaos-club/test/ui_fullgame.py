# Plays a full 10-round bot game at high speed until the game-over screen appears.
from playwright.sync_api import sync_playwright
errors = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    pg.goto("http://localhost:8080/"); pg.wait_for_timeout(600)
    pg.fill("#mbLang", "Korean"); pg.press("#mbLang", "Enter"); pg.wait_for_timeout(1200)
    print("korean msg:", pg.evaluate("document.querySelector('.toast span') && document.querySelector('.toast span').textContent"))
    pg.evaluate("localStorage.setItem('cc.setup', JSON.stringify({players:[{name:'',avatar:'chicken',color:'#FF453A',bot:true},{name:'',avatar:'alien',color:'#0A84FF',bot:true},{name:'Zed',avatar:'rex',color:'#32D74B',bot:true},{name:'',avatar:'ghost',color:'#FFD60A',bot:true}],rounds:10,chaos:'mayhem'}))")
    pg.reload(); pg.wait_for_timeout(500)
    pg.click("[data-go=setup]"); pg.click("[data-start]")
    pg.evaluate("setInterval(()=>{FX.speed=0.02},50)")
    for k in range(240):
        pg.wait_for_timeout(1000)
        if pg.evaluate("!!document.querySelector('.podium')"): break
    print("seconds:", k, "round:", pg.evaluate("ChaosDebug.app.view.round"), "phase:", pg.evaluate("ChaosDebug.app.view.phase"))
    pg.wait_for_timeout(1500)
    pg.screenshot(path="/tmp/gameover.png")
    b.close()
print("ERR", errors[:10])
