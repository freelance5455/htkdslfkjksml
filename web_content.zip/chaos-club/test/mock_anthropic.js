// Fake Anthropic Messages API for testing the translation pipeline offline.
// Language meta -> "Testlandish"; translation -> wraps every value in ⟦ ⟧ keeping placeholders.
require('http').createServer((req, res) => {
  let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
    const body = JSON.parse(b); const user = body.messages[0].content;
    let out;
    if (user.startsWith('The user typed')) out = { ok: !/banana/i.test(user), code: 'x-test', name: 'Testlandish', dir: 'ltr' };
    else { const o = JSON.parse(user); out = {}; for (const k in o) out[k] = '⟦' + o[k] + '⟧'; }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ content: [{ type: 'text', text: JSON.stringify(out) }] }));
  });
}).listen(9911, () => console.log('mock on 9911'));
