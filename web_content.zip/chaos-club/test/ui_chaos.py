# Forces every chaos event and twist in a local game and screenshots the visual mid-animation.
import sys, os
from playwright.sync_api import sync_playwright
URL = "http://localhost:8080/"
OUT = "/tmp/chaos"; os.makedirs(OUT, exist_ok=True)
ids = sys.argv[1].split(",") if len(sys.argv) > 1 else []
errors = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.on("console", lambda m: errors.append(f"[{m.type}] {m.text}") if m.type == "error" and "404" not in m.text else None)
    pg.on("pageerror", lambda e: errors.append(f"[pageerror] {e}"))
    pg.goto(URL); pg.wait_for_timeout(600)
    pg.evaluate("localStorage.setItem('cc.setup', JSON.stringify({players:[{name:'Ann',avatar:'chicken',color:'#FF453A',bot:false},{name:'Bo',avatar:'alien',color:'#0A84FF',bot:false},{name:'Cy',avatar:'rex',color:'#32D74B',bot:false}],rounds:15,chaos:'chaotic'}))")
    pg.reload(); pg.wait_for_timeout(500)
    pg.click("[data-go=setup]"); pg.click("[data-start]")
    pg.wait_for_function("!ChaosDebug.app.playing", timeout=20000)
    # give players some property so hammer etc. have targets
    pg.evaluate("""(()=>{const g=ChaosDebug.app.game; g.tiles[1].owner=0; g.tiles[3].owner=0; g.tiles[1].level=2; g.tiles[9].owner=1; g.players[1].pos=5; g.players[2].pos=12;})()""")
    for kind_id in ids:
        kind, cid = kind_id.split(":")
        pg.evaluate(f"ChaosDebug.{kind}('{cid}')")
        delays = [4400, 900] if kind == "chaos" else [700]
        for k, d in enumerate(delays):
            pg.wait_for_timeout(d)
            pg.screenshot(path=f"{OUT}/{cid}_{k}.png")
        pg.wait_for_function("!ChaosDebug.app.playing", timeout=30000)
        # finish any auction
        pg.evaluate("""(()=>{const A=ChaosDebug.app; let n=0; while(A.game.phase==='auction' && n++<20){ const r=ChaosEngine.applyAction(A.game, ChaosEngine.actorOf(A.game), {type:'pass'}); }})()""")
        pg.wait_for_timeout(200)
    b.close()
print("ERRORS", errors)
