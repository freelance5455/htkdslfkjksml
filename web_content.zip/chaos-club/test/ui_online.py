# Two separate browsers play online: create room, join by code, start, take turns, disconnect/rejoin.
import os, re
from playwright.sync_api import sync_playwright
OUT = "/tmp/online"; os.makedirs(OUT, exist_ok=True); errors = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
    A = b.new_context(viewport={"width": 1280, "height": 800}).new_page()
    B = b.new_context(viewport={"width": 1280, "height": 800}).new_page()
    for pg, n in ((A, 'A'), (B, 'B')):
        pg.on("pageerror", lambda e, n=n: errors.append(n + ' ' + str(e)))
        pg.on("console", lambda m, n=n: errors.append(n + ' ' + m.text) if m.type == "error" else None)
        pg.goto("http://localhost:8080/"); pg.wait_for_timeout(600)
    A.click("[data-go=online]"); A.wait_for_timeout(800)
    A.fill("#opName", "Alice"); A.click("[data-create]"); A.wait_for_timeout(800)
    code = A.inner_text(".code-big").strip(); print("room", code)
    B.click("[data-go=online]"); B.wait_for_timeout(800)
    B.fill("#joinCode", code); B.press("#joinCode", "Enter"); B.wait_for_timeout(800)
    A.screenshot(path=f"{OUT}/lobby_A.png")
    print("A sees:", A.inner_text("#lobbyCount"))
    A.click("[data-chaos] [data-v=mayhem]"); A.wait_for_timeout(300)
    print("B sees chaos on:", B.evaluate("document.querySelector('[data-chaos] .on').dataset.v"))
    A.click("[data-start]"); A.wait_for_timeout(1500)
    for pg in (A, B): pg.evaluate("FX.speed=0.05")
    def step():
        for pg in (A, B):
            pg.evaluate("ChaosDebug.app.fast=true; FX.speed=0.05")
            btn = pg.query_selector("#action [data-a]:not([disabled])")
            if btn: btn.click(); return True
        return False
    acted = 0
    for k in range(70):
        if step(): acted += 1
        A.wait_for_timeout(400)
    print("actions taken:", acted)
    sA = A.evaluate("JSON.stringify([ChaosDebug.app.view.round, ChaosDebug.app.view.players.map(p=>p.coins+'@'+p.pos)])")
    sB = B.evaluate("JSON.stringify([ChaosDebug.app.view.round, ChaosDebug.app.view.players.map(p=>p.coins+'@'+p.pos)])")
    print("A state", sA); print("B state", sB)
    A.screenshot(path=f"{OUT}/game_A.png"); B.screenshot(path=f"{OUT}/game_B.png")
    # B reloads (disconnect) and should rejoin automatically
    B.reload(); B.wait_for_timeout(2500)
    print("B after reload screen:", B.evaluate("ChaosDebug.app.screen"), "players:", B.evaluate("ChaosDebug.app.view && ChaosDebug.app.view.players.length"))
    # B closes for good; A should be able to continue thanks to auto-play
    B.close()
    for k in range(25):
        step_btn = A.query_selector("#action [data-a]:not([disabled])")
        if step_btn: step_btn.click()
        A.wait_for_timeout(500)
    print("A round after B left:", A.evaluate("ChaosDebug.app.view.round"), A.evaluate("ChaosDebug.app.view.phase"))
    b.close()
print("ERR", errors[:10])
