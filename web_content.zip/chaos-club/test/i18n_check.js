// Verifies built-in language packs cover every English key with identical {placeholders}.
const fs = require('fs'), vm = require('vm'), path = require('path');
const ctx = { globalThis: {} }; ctx.globalThis = ctx; vm.createContext(ctx);
for (const f of ['en', 'th', 'es', 'ar']) vm.runInContext(fs.readFileSync(path.join(__dirname, '../public/lang', f + '.js'), 'utf8').replace(/typeof module !== 'undefined'/g, 'false'), ctx);
const EN = ctx.ChaosLang.en.strings; const ph = (s) => (s.match(/\{\w+\}/g) || []).sort().join();
let bad = 0;
for (const code of ['th', 'es', 'ar']) {
  const S = ctx.ChaosLang[code].strings;
  for (const k of Object.keys(EN)) {
    if (S[k] == null) { console.log(code, 'MISSING', k); bad++; }
    else if (ph(S[k]) !== ph(EN[k])) { console.log(code, 'PLACEHOLDER', k, S[k]); bad++; }
  }
  for (const k of Object.keys(S)) if (EN[k] == null) { console.log(code, 'EXTRA', k); bad++; }
  console.log(code, Object.keys(S).length, 'keys');
}
// every key used in app.js exists
const app = fs.readFileSync(path.join(__dirname, '../public/js/app.js'), 'utf8');
const used = new Set([...app.matchAll(/\bt[e]?\('([a-z][\w.]+)'/g)].map((m) => m[1]));
for (const k of used) if (!k.endsWith('.') && !EN[k]) { console.log('APP USES UNKNOWN KEY', k); bad++; }
// dynamic keys built from content ids
global.globalThis.x = 1;
const C = require('../public/js/content.js');
const need = [];
C.CHAOS_CARDS.concat(C.SURPRISE_CARDS).forEach((c) => need.push('card.' + c.id));
C.SMALL.forEach((c) => need.push('small.' + c.id));
Object.keys(C.MAJOR).forEach((id) => { need.push('chaos.' + id + '.t'); if (id !== 'hammer') need.push('chaos.' + id + '.d'); });
Object.keys(C.TWISTS).forEach((id) => need.push('twist.' + id + '.t', 'twist.' + id + '.d'));
C.CHARACTERS.forEach((c) => need.push('char.' + c.id));
C.BOARD.forEach((t) => need.push(t.t === 'prop' ? 'prop.' + t.id : t.t === 'tax' ? 'tax.' + t.id : 'tile.' + t.t, 'info.' + t.t));
for (const k of need) if (!EN[k]) { console.log('CONTENT KEY MISSING', k); bad++; }
console.log(bad ? bad + ' problems' : 'all packs complete');
process.exit(bad ? 1 : 0);
