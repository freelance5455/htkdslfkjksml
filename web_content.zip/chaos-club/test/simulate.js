// Plays thousands of full bot games through the engine to catch rule bugs.
// Run: node test/simulate.js
const E = require('../public/js/engine.js');
const C = require('../public/js/content.js');

const stats = { games: 0, actions: 0, events: {}, chaos: {}, twists: {}, cards: {}, overReasons: {}, bankrupt: 0, rounds: 0 };
function check(s, where) {
  for (const p of s.players) {
    if (p.coins < 0) throw new Error(where + ': negative coins ' + JSON.stringify(p));
    if (p.pos < 0 || p.pos >= 32 || !Number.isInteger(p.pos)) throw new Error(where + ': bad pos');
  }
  if (s.phase === 'busy') throw new Error(where + ': stuck in busy');
  if (s.phase !== 'over' && E.actorOf(s) == null) throw new Error(where + ': no actor in ' + s.phase);
}

function play(n, chaos, rounds) {
  const players = Array.from({ length: n }, (_, i) => ({ name: 'P' + i, avatar: C.CHARACTERS[i].id, color: C.COLORS[i] }));
  const s = E.createGame(players, { chaos, rounds });
  E.begin(s);
  let guard = 0;
  while (s.phase !== 'over') {
    if (++guard > 5000) throw new Error('game never ended');
    const pid = E.actorOf(s);
    const a = E.botAction(s);
    const r = E.applyAction(s, pid, a);
    if (!r.ok) throw new Error('action failed ' + JSON.stringify(a) + ' ' + r.error + ' ' + (r.detail || ''));
    stats.actions++;
    for (const ev of r.events) {
      stats.events[ev.type] = (stats.events[ev.type] || 0) + 1;
      if (ev.type === 'chaos') stats.chaos[ev.id] = (stats.chaos[ev.id] || 0) + 1;
      if (ev.type === 'twist') stats.twists[ev.id] = (stats.twists[ev.id] || 0) + 1;
      if (ev.type === 'card') stats.cards[ev.card] = (stats.cards[ev.card] || 0) + 1;
      if (ev.type === 'bankrupt') stats.bankrupt++;
      if (ev.type === 'gameOver') stats.overReasons[ev.reason] = (stats.overReasons[ev.reason] || 0) + 1;
    }
    check(s, 'after ' + a.type);
  }
  stats.games++; stats.rounds += Math.min(s.round, s.maxRounds);
}

// wrong-player and bad actions must be rejected
{
  const s = E.createGame([{ name: 'A' }, { name: 'B' }], {});
  E.begin(s);
  const other = s.order[1];
  if (E.applyAction(s, other, { type: 'roll' }).ok) throw new Error('accepted out-of-turn action');
  if (E.applyAction(s, s.order[0], { type: 'buy' }).ok) throw new Error('accepted invalid action');
}

// forced chaos + twists on a live game
for (const id of Object.keys(C.MAJOR)) {
  const s = E.createGame([{ name: 'A' }, { name: 'B' }, { name: 'C' }], {}); E.begin(s);
  E.debugForce(s, 'chaos', id);
  while (s.phase === 'auction') E.applyAction(s, E.actorOf(s), E.botAction(s));
  check(s, 'forced ' + id);
}
for (const id of Object.keys(C.TWISTS)) {
  const s = E.createGame([{ name: 'A' }, { name: 'B' }], {}); E.begin(s);
  E.debugForce(s, 'twist', id); check(s, 'twist ' + id);
}

const t0 = Date.now();
for (let g = 0; g < 1500; g++) play(2 + (g % 3), ['chill', 'chaotic', 'mayhem'][g % 3], [10, 15, 20][Math.floor(g / 3) % 3]);
console.log('OK', stats.games, 'games in', Date.now() - t0, 'ms');
console.log('avg actions/game', (stats.actions / stats.games).toFixed(1), 'avg rounds', (stats.rounds / stats.games).toFixed(1), 'bankruptcies', stats.bankrupt);
console.log('end reasons', stats.overReasons);
console.log('chaos', stats.chaos);
console.log('twists', stats.twists);
console.log('events', stats.events);
