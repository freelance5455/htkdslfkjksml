# Browser smoke test: plays a local game with 2 bots + forced chaos events, captures screenshots and console errors.
# Run: python3 test/ui_smoke.py  (server must be running on :8080)
import sys, time, json
from playwright.sync_api import sync_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080/"
OUT = "/tmp/shots"
import os; os.makedirs(OUT, exist_ok=True)
errors = []

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--autoplay-policy=no-user-gesture-required"])
    pg = b.new_page(viewport={"width": 1440, "height": 900}, device_scale_factor=1)
    pg.on("console", lambda m: errors.append(f"[{m.type}] {m.text}") if m.type in ("error", "warning") else None)
    pg.on("pageerror", lambda e: errors.append(f"[pageerror] {e}"))
    pg.goto(URL); pg.wait_for_timeout(900)
    pg.screenshot(path=f"{OUT}/1_home.png")
    pg.click("[data-go=setup]"); pg.wait_for_timeout(500)
    # make both players bots, 3 players
    pg.click("[data-add]"); pg.wait_for_timeout(200)
    for i in range(3):
        pg.click(f".pcard[data-i='{i}'] [data-bot='1']"); pg.wait_for_timeout(100)
    pg.click("[data-chaos] [data-v=mayhem]"); pg.wait_for_timeout(100)
    pg.screenshot(path=f"{OUT}/2_setup.png")
    pg.click("[data-start]"); pg.wait_for_timeout(1500)
    pg.screenshot(path=f"{OUT}/3_start.png")
    pg.wait_for_timeout(9000)
    pg.screenshot(path=f"{OUT}/4_game.png")
    # fast-forward: speed up animations a lot and let bots play
    pg.evaluate("FX.speed=0.05")
    for k in range(40):
        pg.wait_for_timeout(1000)
        pg.evaluate("document.querySelector('#boardArea') && document.querySelector('#boardArea').click()")
    pg.screenshot(path=f"{OUT}/5_later.png")
    print("phase:", pg.evaluate("document.querySelector('#roundPill') && document.querySelector('#roundPill').textContent"))
    b.close()

print("ERRORS:", len(errors))
for e in errors[:40]: print(e)
