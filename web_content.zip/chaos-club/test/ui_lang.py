# Language switching end-to-end: built-in Thai/Arabic, AI path (mock), unknown-language error, mobile layout.
import os
from playwright.sync_api import sync_playwright
OUT = "/tmp/lang"; os.makedirs(OUT, exist_ok=True); errors = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    pg.goto("http://localhost:8080/"); pg.wait_for_timeout(800)
    pg.fill("#mbLang", "thai"); pg.press("#mbLang", "Enter"); pg.wait_for_timeout(700)
    pg.screenshot(path=f"{OUT}/th_home.png")
    pg.click("[data-go=setup]"); pg.wait_for_timeout(300); pg.click("[data-start]"); pg.wait_for_timeout(5000)
    pg.evaluate("ChaosDebug.app.fast=true; FX.speed=0.05"); pg.wait_for_timeout(1500)
    pg.screenshot(path=f"{OUT}/th_game.png")
    pg.fill("#mbLang", "العربية"); pg.press("#mbLang", "Enter"); pg.wait_for_timeout(900)
    pg.screenshot(path=f"{OUT}/ar_game.png")
    print("dir:", pg.evaluate("document.documentElement.dir"))
    pg.fill("#mbLang", "Testlandish"); pg.press("#mbLang", "Enter"); pg.wait_for_timeout(2500)
    print("ai title:", pg.evaluate("document.querySelector('.mb-bold').textContent"))
    pg.screenshot(path=f"{OUT}/ai_game.png")
    pg.fill("#mbLang", "banana"); pg.press("#mbLang", "Enter"); pg.wait_for_timeout(1500)
    print("toast:", pg.evaluate("document.querySelector('.toast') && document.querySelector('.toast').innerText"))
    # session memory
    pg.reload(); pg.wait_for_timeout(800)
    print("after reload:", pg.evaluate("document.querySelector('.mb-bold').textContent"))
    m = b.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    m.goto("http://localhost:8080/?lang=Spanish"); m.wait_for_timeout(900)
    m.screenshot(path=f"{OUT}/m_home.png")
    m.click("[data-go=setup]"); m.wait_for_timeout(300); m.click("[data-start]"); m.wait_for_timeout(6000)
    m.screenshot(path=f"{OUT}/m_game.png", full_page=False)
    b.close()
print("ERR", errors)
