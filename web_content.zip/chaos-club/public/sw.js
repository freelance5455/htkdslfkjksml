/* Service worker: lets the installed web app open offline. Network first, so updates show up right away. */
const CACHE = 'chaos-club-v1';
const FILES = ['./', 'index.html', 'css/style.css', 'js/config.js', 'js/content.js', 'js/engine.js', 'js/i18n.js', 'js/sound.js', 'js/fx.js', 'js/net.js', 'js/app.js',
  'lang/en.js', 'lang/th.js', 'lang/es.js', 'lang/ar.js', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/') || url.pathname === '/ws') return;
  e.respondWith(fetch(e.request).then((r) => { if (r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); } return r; })
    .catch(() => caches.match(e.request).then((m) => m || caches.match('index.html'))));
});
