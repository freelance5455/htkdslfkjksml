/* The Chaos Club — online connection (WebSocket client with automatic reconnect + room rejoin). */
(function (root) {
  'use strict';
  const Net = {
    ws: null, url: null, handlers: {}, status: 'idle', session: null, retry: 0, timer: null, pinger: null, wanted: false,
    on(type, fn) { (this.handlers[type] = this.handlers[type] || []).push(fn); },
    emit(type, data) { (this.handlers[type] || []).forEach((fn) => fn(data)); },

    // base: http(s) origin of the Chaos Club server
    connect(base) {
      this.wanted = true;
      this.url = base.replace(/^http/, 'ws').replace(/\/$/, '') + '/ws';
      return new Promise((resolve, reject) => {
        let settled = false;
        const open = () => {
          clearTimeout(this.timer);
          let ws;
          try { ws = new WebSocket(this.url); } catch (e) { if (!settled) { settled = true; reject(e); } return; }
          this.ws = ws; this.setStatus('connecting');
          ws.onopen = () => {
            this.retry = 0; this.setStatus('open');
            clearInterval(this.pinger); this.pinger = setInterval(() => this.send({ t: 'ping' }), 20000);
            if (this.session) this.send({ t: 'rejoin', code: this.session.code, token: this.session.token });
            if (!settled) { settled = true; resolve(); }
          };
          ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } this.emit(m.t, m); };
          ws.onclose = () => {
            clearInterval(this.pinger);
            if (!settled) { settled = true; reject(new Error('closed')); this.setStatus('idle'); return; }
            if (!this.wanted) { this.setStatus('idle'); return; }
            this.setStatus('reconnecting');
            this.retry++; this.timer = setTimeout(open, Math.min(8000, 500 * Math.pow(1.6, this.retry)));
          };
          ws.onerror = () => { /* onclose follows */ };
        };
        open();
      });
    },
    setStatus(s) { this.status = s; this.emit('status', s); },
    send(obj) { if (this.ws && this.ws.readyState === 1) { this.ws.send(JSON.stringify(obj)); return true; } return false; },
    remember(code, token) { this.session = { code, token }; try { sessionStorage.setItem('cc.session', JSON.stringify(this.session)); } catch (e) { /* ignore */ } },
    restoreSession() { try { this.session = JSON.parse(sessionStorage.getItem('cc.session') || 'null'); } catch (e) { this.session = null; } return this.session; },
    forget() { this.session = null; try { sessionStorage.removeItem('cc.session'); } catch (e) { /* ignore */ } },
    close() { this.wanted = false; clearTimeout(this.timer); clearInterval(this.pinger); if (this.ws) try { this.ws.close(); } catch (e) { /* ignore */ } this.ws = null; this.setStatus('idle'); },
  };
  root.Net = Net;
})(globalThis);
