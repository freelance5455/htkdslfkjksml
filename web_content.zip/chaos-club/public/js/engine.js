/* The Chaos Club — rules engine.
 * Pure game logic shared by the browser (local games) and the Node server (online games).
 *
 *   createGame(players, options)        -> state
 *   begin(state)                        -> events
 *   applyAction(state, playerId, act)   -> { ok, events, error }
 *   actorOf(state)                      -> id of the player who must act next
 *   botAction(state)                    -> a sensible action for the current actor
 *
 * Every event is { type, ...data, s } where s is a snapshot of the state right after
 * that event, so clients can animate each step and then render exactly that state. */
(function (root) {
  'use strict';
  const C = (typeof module !== 'undefined' && module.exports) ? require('./content.js') : root.ChaosContent;
  const N = C.BOARD.length;

  const LEVELS = {
    chill:   { small: 0.16, major: 0.06, twist: 0.25, meter: [4, 9] },
    chaotic: { small: 0.24, major: 0.12, twist: 0.4, meter: [7, 14] },
    mayhem:  { small: 0.32, major: 0.22, twist: 0.7, meter: [12, 22] },
  };

  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const r5 = (n) => Math.round(n / 5) * 5;
  const r10 = (n) => Math.round(n / 10) * 10;
  const clone = (o) => JSON.parse(JSON.stringify(o));
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function weighted(list) {
    const total = list.reduce((s, x) => s + x.w, 0);
    let r = Math.random() * total;
    for (const x of list) { r -= x.w; if (r <= 0) return x; }
    return list[list.length - 1];
  }

  // Working context for the action being processed.
  let S = null, E = null;
  function emit(type, data) { E.push(Object.assign({ type }, data || {}, { s: clone(S) })); }

  const cur = () => S.players[S.order[S.turn]];
  const alive = () => S.players.filter((p) => !p.out);
  const onBoard = () => alive().filter((p) => !p.abducted);
  const twist = () => (S.twist ? S.twist.id : null);
  const cost = (n) => (twist() === 'inflation' ? n * 2 : n);
  const rentBase = (t) => Math.max(10, r5(t.price * 0.14));
  const upCost = (t) => r10(t.price * 0.5);
  const owned = (p) => S.tiles.map((t, i) => i).filter((i) => S.tiles[i].owner === p.id);
  const tileValue = (t) => t.price + t.level * upCost(t);
  const netWorth = (p) => p.coins + owned(p).reduce((s, i) => s + tileValue(S.tiles[i]), 0);
  const richest = () => alive().slice().sort((a, b) => b.coins - a.coins)[0];
  const poorest = () => alive().slice().sort((a, b) => a.coins - b.coins)[0];
  function randTile(ok) { const c = []; for (let i = 0; i < N; i++) if (!ok || ok(i)) c.push(i); return c.length ? pick(c) : rnd(1, N - 1); }
  const playersAt = (i) => onBoard().filter((p) => p.pos === i);

  function createGame(list, opts) {
    opts = opts || {};
    const s = {
      v: 1, round: 1, maxRounds: opts.rounds || 15, chaos: LEVELS[opts.chaos] ? opts.chaos : 'chaotic',
      players: list.map((p, i) => ({
        id: i, name: String(p.name || 'Player').slice(0, 24), auto: !!p.auto, avatar: p.avatar, color: p.color, bot: !!p.bot,
        coins: C.RULES.startCoins, pos: 0, skip: 0, skipWhy: null, shield: false, giant: 0, abducted: false,
        out: false, rescued: false, extra: false, chain: 0, outRound: 0,
      })),
      tiles: C.BOARD.map((t) => Object.assign({}, t, { owner: null, level: 0, crater: 0, bomb: 0, chicken: false, piles: [] })),
      order: shuffle(list.map((_, i) => i)), turn: 0, pot: 0, twist: null, meter: 0,
      phase: 'roll', pending: null, auction: null, lastRoll: null, ranking: null, winner: null,
      recentCards: [], recentChaos: [], recentSmall: [], recentTwists: [], started: false,
    };
    return s;
  }

  function begin(state) {
    S = state; E = [];
    S.started = true;
    emit('gameStart', { order: S.order.slice() });
    cur().chain = 0;
    emit('turn', { pid: cur().id });
    return E;
  }

  // ---------- money ----------
  function gain(p, n, why, extra) {
    if (p.out) return 0;
    if (n > 0 && twist() === 'doubleMoney' && why !== 'transfer') n *= 2;
    n = Math.round(n);
    p.coins += n;
    emit('money', Object.assign({ pid: p.id, delta: n, why }, extra || {}));
    return n;
  }

  // Make sure p can pay n: sell buildings, then Grandma's Emergency Fund (once).
  function settle(p, n) {
    if (p.coins >= n) return n;
    const props = owned(p).sort((a, b) => tileValue(S.tiles[a]) - tileValue(S.tiles[b]));
    while (p.coins < n && props.length) {
      const i = props.shift(); const t = S.tiles[i];
      const amt = Math.round(tileValue(t) / 2);
      t.owner = null; t.level = 0; p.coins += amt;
      emit('sell', { pid: p.id, tile: i, amount: amt });
    }
    if (p.coins < n && !p.rescued) {
      p.rescued = true; p.coins += C.RULES.rescue;
      emit('rescue', { pid: p.id, amount: C.RULES.rescue });
    }
    return Math.min(n, Math.max(0, p.coins));
  }

  // to: 'bank' | 'pot' | player id. Returns amount paid.
  function charge(p, n, why, to, opts) {
    n = Math.round(n); opts = opts || {};
    if (n <= 0 || p.out) return 0;
    if (opts.shieldable !== false && p.shield) {
      p.shield = false; emit('shieldBlock', { pid: p.id, amount: n, why }); return 0;
    }
    const paid = settle(p, n);
    p.coins -= paid;
    if (to === 'pot') S.pot += paid;
    emit('money', { pid: p.id, delta: -paid, why, to: typeof to === 'number' ? to : (to === 'pot' ? 'pot' : null) });
    if (typeof to === 'number' && S.players[to] && !S.players[to].out && paid > 0) {
      S.players[to].coins += paid;
      emit('money', { pid: to, delta: paid, why: why === 'rent' ? 'rentIn' : 'transfer', from: p.id });
    }
    if (paid < n) bankrupt(p);
    return paid;
  }

  function bankrupt(p) {
    if (p.out) return;
    p.out = true; p.coins = 0; p.abducted = false; p.outRound = S.round;
    S.tiles.forEach((t) => { if (t.owner === p.id) { t.owner = null; t.level = 0; } });
    emit('bankrupt', { pid: p.id });
    if (alive().length <= 1) gameOver('lastStanding');
  }

  function gameOver(reason) {
    if (S.phase === 'over') return;
    S.phase = 'over'; S.pending = null; S.auction = null;
    const ranking = S.players.slice().sort((a, b) => {
      if (a.out !== b.out) return a.out ? 1 : -1;
      if (a.out) return b.outRound - a.outRound;
      return netWorth(b) - netWorth(a);
    }).map((p) => ({ pid: p.id, worth: p.out ? 0 : netWorth(p), coins: p.coins, props: owned(p).length }));
    S.ranking = ranking; S.winner = ranking[0].pid;
    emit('gameOver', { reason, ranking });
  }

  // ---------- movement ----------
  function collectPiles(p, i) {
    const t = S.tiles[i];
    if (!t.piles.length) return;
    const piles = t.piles; t.piles = [];
    for (const pl of piles) gain(p, pl.v, pl.k === 'egg' ? 'egg' : 'pile', { tile: i });
  }

  function moveSteps(p, steps, opts) {
    opts = opts || {};
    const dir = steps < 0 ? -1 : 1; const path = [p.pos]; let passed = false;
    for (let k = 0; k < Math.abs(steps); k++) {
      p.pos = (p.pos + dir + N) % N; path.push(p.pos);
      if (dir > 0 && p.pos === 0) passed = true;
    }
    emit('move', { pid: p.id, path, kind: opts.kind || 'walk' });
    for (const i of path.slice(1)) { collectPiles(p, i); if (p.out) return; }
    if (passed && !opts.noStart) gain(p, C.RULES.passStart, 'passStart');
  }

  function jumpTo(p, to, kind, passStart) {
    const from = p.pos; p.pos = to;
    emit('move', { pid: p.id, path: [from, to], kind });
    collectPiles(p, to);
    if (passStart && to <= from && to !== from) gain(p, C.RULES.passStart, 'passStart');
  }

  function sendNap(p, why) {
    jumpTo(p, 8, 'nap', false);
    p.skip = 1; p.skipWhy = why || 'nap'; p.extra = false;
    emit('napped', { pid: p.id, why: why || 'nap' });
  }

  // ---------- tiles ----------
  function resolve(p, depth) {
    depth = depth || 0;
    if (S.phase === 'over' || p.out) return 'done';
    const i = p.pos; const t = S.tiles[i];
    if (t.bomb) {
      explodeBomb(i);
      if (!p.out) moveSteps(p, -3, { kind: 'blast', noStart: true });
      return 'done';
    }
    if (t.crater) { emit('crater', { pid: p.id, tile: i }); charge(p, cost(40), 'crater', 'pot'); return 'done'; }
    if (t.chicken) {
      t.chicken = false;
      if (Math.random() < 0.5) { emit('chickenTile', { pid: p.id, tile: i, good: true }); gain(p, 60, 'egg', { tile: i }); }
      else { emit('chickenTile', { pid: p.id, tile: i, good: false }); charge(p, cost(30), 'chicken'); }
      if (p.out || S.phase === 'over') return 'done';
    }
    switch (t.t) {
      case 'start': gain(p, C.RULES.landStart, 'landStart'); return 'done';
      case 'prop': return landProp(p, i, t);
      case 'chaos': case 'surprise': {
        if (depth >= 2) return 'done';
        const card = drawCard(t.t);
        emit('card', { pid: p.id, deck: t.t, card: card.id, fx: card.fx });
        return applyFx(p, card.fx, depth, 'card');
      }
      case 'tax': emit('tax', { pid: p.id, tile: i }); charge(p, cost(t.amt), 'tax', 'pot'); return 'done';
      case 'worm': emit('warp', { pid: p.id, from: i, to: t.to }); jumpTo(p, t.to, 'warp', false); return 'done';
      case 'mini': {
        S.phase = 'guess'; S.pending = { base: rnd(2, 5) };
        emit('miniStart', { pid: p.id, base: S.pending.base });
        return 'wait';
      }
      case 'pot': {
        const amt = S.pot; S.pot = 0;
        emit('potLand', { pid: p.id, amount: amt });
        if (amt > 0) gain(p, amt, 'pot'); else gain(p, 10, 'feather');
        return 'done';
      }
      case 'banana': emit('slip', { pid: p.id }); sendNap(p, 'banana'); return 'done';
      case 'nap': emit('napVisit', { pid: p.id }); return 'done';
    }
    return 'done';
  }

  function landProp(p, i, t) {
    if (t.owner === null) {
      const price = cost(t.price);
      if (p.coins >= price) { S.phase = 'buy'; S.pending = { tile: i, price }; emit('offerBuy', { pid: p.id, tile: i, price }); return 'wait'; }
      emit('cantAfford', { pid: p.id, tile: i }); return 'done';
    }
    if (t.owner === p.id) {
      const c = cost(upCost(t));
      if (t.level < 3 && p.coins >= c) { S.phase = 'upgrade'; S.pending = { tile: i, price: c }; emit('offerUpgrade', { pid: p.id, tile: i, price: c }); return 'wait'; }
      emit('homeSweet', { pid: p.id, tile: i }); return 'done';
    }
    const owner = S.players[t.owner];
    if (twist() === 'rentFreeze') { emit('rentFrozen', { pid: p.id, tile: i, owner: owner.id }); return 'done'; }
    const rent = rentOf(i, p);
    emit('rentDue', { pid: p.id, tile: i, owner: owner.id, amount: rent });
    charge(p, rent, 'rent', owner.id);
    return 'done';
  }

  function rentOf(i, payer) {
    const t = S.tiles[i];
    let rent = rentBase(t) * [1, 3, 6, 10][t.level];
    const group = S.tiles.filter((x) => x.t === 'prop' && x.g === t.g);
    if (t.level === 0 && group.every((x) => x.owner === t.owner)) rent *= 2;
    if (twist() === 'discoNight') rent *= 1.5;
    if (payer && payer.giant) rent *= 2;
    return cost(r5(rent));
  }

  function drawCard(deck) {
    const cards = deck === 'chaos' ? C.CHAOS_CARDS : C.SURPRISE_CARDS;
    let pool = cards.filter((c) => !S.recentCards.includes(c.id));
    if (!pool.length) pool = cards;
    const c = weighted(pool);
    S.recentCards.push(c.id); if (S.recentCards.length > 14) S.recentCards.shift();
    return c;
  }

  function applyFx(p, f, depth, src) {
    const others = alive().filter((o) => o.id !== p.id);
    if (f.money != null) { if (f.money > 0) gain(p, f.money, src); else if (f.money < 0) charge(p, cost(-f.money), src); else emit('nothing', { pid: p.id }); }
    if (f.range) gain(p, r5(rnd(f.range[0], f.range[1])), src);
    if (f.each) {
      if (f.each > 0) others.forEach((o) => charge(o, f.each, 'gift', p.id));
      else others.forEach((o) => { if (!p.out) charge(p, cost(-f.each), 'gift', o.id); });
    }
    if (f.perProp) { const n = owned(p).length * f.perProp; if (n) charge(p, cost(n), src); else emit('noProps', { pid: p.id }); }
    if (f.shield) { p.shield = true; emit('shieldUp', { pid: p.id }); }
    if (f.extra) { p.extra = true; emit('extraGranted', { pid: p.id }); }
    if (f.potHalf) { const h = Math.floor(S.pot / 2); S.pot -= h; if (h) gain(p, h, 'pot'); else gain(p, 10, 'feather'); }
    if (p.out || S.phase === 'over') return 'done';
    if (f.nap) { sendNap(p, 'card'); return 'done'; }
    if (f.swap && others.length) {
      const o = pick(others.filter((x) => !x.abducted).length ? others.filter((x) => !x.abducted) : others);
      const a = p.pos, b = o.pos; p.pos = b; o.pos = a;
      emit('move', { pid: p.id, path: [a, b], kind: 'swap' }); emit('move', { pid: o.id, path: [b, a], kind: 'swap' });
      return 'done';
    }
    if (src === 'small') { if (f.move) moveSteps(p, f.move, { kind: 'slide', noStart: f.move < 0 }); return 'done'; }
    if (f.move) { moveSteps(p, f.move, { kind: 'walk', noStart: f.move < 0 }); return resolve(p, depth + 1); }
    if (f.goto != null) { jumpTo(p, f.goto, 'fly', true); return resolve(p, depth + 1); }
    if (f.randomTile) { jumpTo(p, randTile((i) => i !== p.pos), 'warp', false); return resolve(p, depth + 1); }
    return 'done';
  }

  function explodeBomb(i) {
    const t = S.tiles[i]; t.bomb = 0;
    const victims = playersAt(i);
    const piles = [];
    for (let k = 0; k < 3; k++) { const j = (i + rnd(-3, 3) + N) % N; const v = rnd(4, 8) * 5; S.tiles[j].piles.push({ v, k: 'coin' }); piles.push({ tile: j, v }); }
    emit('bombBoom', { tile: i, piles, victims: victims.map((v) => v.id) });
    victims.forEach((v) => charge(v, cost(100), 'bomb'));
  }

  // ---------- chaos ----------
  const MAJOR_RUN = {
    meteor() {
      const tile = randTile((i) => i !== 0 && !S.tiles[i].crater);
      S.tiles[tile].crater = 3;
      const v = playersAt(tile);
      emit('chaos', { id: 'meteor', tile, pids: v.map((x) => x.id) });
      v.forEach((x) => charge(x, cost(60), 'meteor'));
    },
    coinBlast() {
      const tile = randTile(); const piles = [];
      for (let k = 0, n = rnd(5, 8); k < n; k++) {
        const j = randTile((x) => x !== tile); const v = rnd(4, 12) * 5;
        S.tiles[j].piles.push({ v, k: 'coin' }); piles.push({ tile: j, v });
      }
      emit('chaos', { id: 'coinBlast', tile, piles });
    },
    hammer() {
      const owners = onBoard().filter((p) => owned(p).length);
      if (owners.length) {
        const p = pick(owners); const props = owned(p);
        const leveled = props.filter((i) => S.tiles[i].level > 0);
        const tile = leveled.length ? pick(leveled) : pick(props);
        if (S.tiles[tile].level > 0) { S.tiles[tile].level--; emit('chaos', { id: 'hammer', pid: p.id, tile, down: true }); }
        else { emit('chaos', { id: 'hammer', pid: p.id, tile, down: false }); charge(p, cost(50), 'hammer'); }
      } else {
        const p = pick(onBoard()); emit('chaos', { id: 'hammer', pid: p.id, tile: p.pos, down: false }); charge(p, cost(50), 'hammer');
      }
    },
    quake() {
      emit('chaos', { id: 'quake' });
      onBoard().forEach((p) => moveSteps(p, pick([-2, -1, 1, 2]), { kind: 'quake', noStart: true }));
    },
    ufo() {
      const c = onBoard(); if (!c.length) return;
      const p = pick(c); p.abducted = true; p.skip = 1; p.skipWhy = 'ufo'; p.extra = false;
      emit('chaos', { id: 'ufo', pid: p.id, tile: p.pos });
    },
    chicken() {
      const side = rnd(0, 3); const tiles = []; for (let k = 0; k <= 8; k++) tiles.push((side * 8 + k) % N);
      const egg = pick(tiles); S.tiles[egg].piles.push({ v: 120, k: 'egg' });
      const v = onBoard().filter((p) => tiles.includes(p.pos));
      emit('chaos', { id: 'chicken', side, egg, pids: v.map((x) => x.id) });
      v.forEach((x) => charge(x, cost(25), 'chicken'));
    },
    richAunt() {
      const sorted = alive().sort((a, b) => a.coins - b.coins); const p = pick(sorted.slice(0, Math.max(1, Math.ceil(sorted.length / 2))));
      emit('chaos', { id: 'richAunt', pid: p.id }); gain(p, 400, 'chaos');
    },
    taxman() {
      emit('chaos', { id: 'taxman' });
      alive().forEach((p) => charge(p, Math.max(10, r5(p.coins * 0.1)), 'taxman', 'pot'));
    },
    tornado() {
      const ps = shuffle(onBoard()).slice(0, 2);
      emit('chaos', { id: 'tornado', pids: ps.map((p) => p.id) });
      ps.forEach((p) => jumpTo(p, randTile((i) => i !== p.pos), 'tornado', false));
    },
    bomb() {
      const tile = randTile((i) => i !== 0 && !S.tiles[i].bomb && !playersAt(i).length);
      S.tiles[tile].bomb = rnd(3, 5);
      emit('chaos', { id: 'bomb', tile });
    },
    coinShower() {
      emit('chaos', { id: 'coinShower' });
      alive().forEach((p) => gain(p, rnd(4, 16) * 5, 'chaos'));
    },
    giant() { const p = pick(onBoard().length ? onBoard() : alive()); p.giant = 2; emit('chaos', { id: 'giant', pid: p.id }); },
    millionaire() { const p = poorest(); emit('chaos', { id: 'millionaire', pid: p.id }); gain(p, 300, 'chaos'); },
    auction() {
      const tile = randTile((i) => S.tiles[i].t === 'prop' && S.tiles[i].owner === null);
      const startBid = Math.max(10, r10(S.tiles[tile].price * 0.5));
      const ids = []; for (let k = 0; k < S.order.length; k++) { const p = S.players[S.order[(S.turn + k) % S.order.length]]; if (!p.out) ids.push(p.id); }
      S.auction = { tile, bid: startBid, leader: null, active: ids, idx: 0 };
      S.phase = 'auction';
      emit('chaos', { id: 'auction', tile, bid: startBid });
      checkAuction();
      return S.phase === 'auction' ? 'wait' : 'done';
    },
    transform() {
      const props = S.tiles.map((t, i) => i).filter((i) => S.tiles[i].t === 'prop');
      const a = pick(props); const b = pick(props.filter((x) => x !== a));
      const keys = ['t', 'id', 'g', 'price', 'icon', 'owner', 'level'];
      const ta = S.tiles[a], tb = S.tiles[b];
      keys.forEach((k) => { const tmp = ta[k]; ta[k] = tb[k]; tb[k] = tmp; });
      emit('chaos', { id: 'transform', a, b });
    },
    gift() {
      const p = pick(onBoard().length ? onBoard() : alive());
      const kind = weighted([{ k: 'big', w: 3 }, { k: 'small', w: 3 }, { k: 'shield', w: 2 }, { k: 'bees', w: 2 }]).k;
      emit('chaos', { id: 'gift', pid: p.id, kind });
      if (kind === 'big') gain(p, 150, 'chaos');
      else if (kind === 'small') gain(p, 60, 'chaos');
      else if (kind === 'shield') { p.shield = true; emit('shieldUp', { pid: p.id }); }
      else charge(p, cost(40), 'chaos');
    },
    fakeWin() { const p = pick(alive()); emit('chaos', { id: 'fakeWin', pid: p.id }); gain(p, 25, 'consolation'); },
    lightning() { const p = richest(); emit('chaos', { id: 'lightning', pid: p.id }); charge(p, r5(p.coins * 0.15), 'lightning'); },
    robinHood() {
      const a = richest(), b = poorest(); if (a.id === b.id) return MAJOR_RUN.coinShower();
      emit('chaos', { id: 'robinHood', from: a.id, to: b.id });
      charge(a, Math.min(120, a.coins), 'robin', b.id, { shieldable: false });
    },
    duckFlood() {
      emit('chaos', { id: 'duckFlood' });
      onBoard().forEach((p) => moveSteps(p, rnd(1, 3), { kind: 'float' }));
    },
  };

  function majorEligible(id) {
    if (S.recentChaos.includes(id)) return false;
    if (id === 'auction') return S.tiles.some((t) => t.t === 'prop' && t.owner === null) && alive().length >= 2;
    if (id === 'robinHood') return alive().length >= 2;
    if (id === 'ufo' || id === 'tornado' || id === 'quake' || id === 'duckFlood') return onBoard().length >= 1;
    if (id === 'bomb') return S.tiles.filter((t) => t.bomb).length < 2;
    return true;
  }

  function runMajor(forceId) {
    let id = forceId;
    if (!id) {
      const list = Object.keys(C.MAJOR).filter(majorEligible).map((k) => ({ k, w: C.MAJOR[k].w }));
      id = (list.length ? weighted(list) : { k: 'coinShower' }).k;
    }
    S.recentChaos.push(id); if (S.recentChaos.length > 7) S.recentChaos.shift();
    return MAJOR_RUN[id]() === 'wait' ? 'wait' : 'done';
  }

  function runSmall(p) {
    let pool = C.SMALL.filter((x) => !S.recentSmall.includes(x.id));
    if (!pool.length) pool = C.SMALL;
    const ev = weighted(pool);
    S.recentSmall.push(ev.id); if (S.recentSmall.length > 6) S.recentSmall.shift();
    emit('small', { id: ev.id, pid: p.id });
    applyFx(p, ev.fx, 9, 'small');
  }

  function chaosStep(p) {
    if (S.phase === 'over') return 'done';
    const L = LEVELS[S.chaos]; const boost = twist() === 'chaosMode' ? 3 : 1;
    S.meter = Math.min(100, S.meter + rnd(L.meter[0], L.meter[1]) * (boost > 1 ? 2 : 1));
    if (S.meter >= 100 || Math.random() < L.major * boost) {
      S.meter = 0;
      return runMajor();
    }
    if (!p.out && !p.abducted && Math.random() < L.small * boost) runSmall(p);
    return 'done';
  }

  // ---------- auction ----------
  function minNext() { return S.auction.leader === null ? S.auction.bid : S.auction.bid + 10; }
  function checkAuction() {
    const A = S.auction;
    // Rotate so the bidder whose turn it is comes first, then drop anyone who can't keep up.
    A.active = A.active.slice(A.idx).concat(A.active.slice(0, A.idx)); A.idx = 0;
    // Drop bidders who cannot afford the minimum (the leader always stays).
    A.active = A.active.filter((id) => id === A.leader || (!S.players[id].out && S.players[id].coins >= minNext()));
    if (A.idx >= A.active.length) A.idx = 0;
    const done = A.active.length === 0 || (A.active.length === 1 && A.active[0] === A.leader);
    if (!done) {
      if (A.active[A.idx] === A.leader) A.idx = (A.idx + 1) % A.active.length;
      emit('auctionTurn', { pid: A.active[A.idx] });
      return;
    }
    const tile = A.tile;
    if (A.leader !== null) {
      const w = S.players[A.leader]; const price = A.bid;
      w.coins -= price; S.tiles[tile].owner = w.id;
      emit('money', { pid: w.id, delta: -price, why: 'auction' });
      emit('auctionWon', { pid: w.id, tile, price });
      checkMonopoly(w, tile);
    } else emit('auctionNone', { tile });
    S.auction = null; S.phase = 'busy';
  }

  function checkMonopoly(p, i) {
    const g = S.tiles[i].g;
    const group = S.tiles.filter((x) => x.t === 'prop' && x.g === g);
    if (group.every((x) => x.owner === p.id)) emit('monopoly', { pid: p.id, g });
  }

  // ---------- turns ----------
  function newRound() {
    S.round++;
    if (S.round > S.maxRounds) { gameOver('rounds'); return false; }
    S.tiles.forEach((t) => { if (t.crater) t.crater--; });
    if (S.twist) {
      const old = S.twist.id; S.twist = null;
      S.tiles.forEach((t) => { t.chicken = false; });
      emit('twistEnd', { id: old });
    }
    emit('round', { round: S.round, last: S.round === S.maxRounds });
    if (Math.random() < LEVELS[S.chaos].twist) {
      const list = Object.keys(C.TWISTS).filter((k) => !S.recentTwists.includes(k)).map((k) => ({ k, w: C.TWISTS[k].w }));
      const id = weighted(list).k;
      S.recentTwists.push(id); if (S.recentTwists.length > 6) S.recentTwists.shift();
      runTwist(id);
    }
    return S.phase !== 'over';
  }

  function runTwist(id) {
    if (C.TWISTS[id].round) S.twist = { id };
    if (id === 'chickenInvasion') {
      shuffle(S.tiles.map((t, i) => i).filter((i) => i !== 0)).slice(0, 6).forEach((i) => { S.tiles[i].chicken = true; });
    }
    if (id === 'reverseDay') S.order = [S.order[0]].concat(S.order.slice(1).reverse());
    emit('twist', { id });
    const ps = alive();
    switch (id) {
      case 'musicalChairs': {
        const on = onBoard(); const pos = shuffle(on.map((p) => p.pos));
        if (on.length > 1 && on.every((p, k) => p.pos === pos[k])) pos.push(pos.shift());
        on.forEach((p, k) => { if (p.pos !== pos[k]) jumpTo(p, pos[k], 'swap', false); });
        break;
      }
      case 'richGetRicher': gain(richest(), 150, 'twist'); break;
      case 'bankruptcyDay': ps.forEach((p) => charge(p, rnd(2, 12) * 5, 'twist', 'pot')); break;
      case 'mysteryBox': ps.forEach((p) => {
        if (p.out) return;
        const k = weighted([{ k: 200, w: 1 }, { k: 100, w: 3 }, { k: 50, w: 3 }, { k: -30, w: 2 }, { k: -50, w: 1 }, { k: 'shield', w: 2 }]).k;
        if (k === 'shield') { p.shield = true; emit('shieldUp', { pid: p.id }); }
        else if (k > 0) gain(p, k, 'twist'); else charge(p, -k, 'twist');
      }); break;
      case 'birthday': ps.forEach((p) => gain(p, 50, 'twist')); break;
      case 'groupHug': {
        let pool = 0; ps.forEach((p) => { const c = r5(p.coins * 0.2); pool += charge(p, c, 'twist', 'bank', { shieldable: false }); });
        const share = Math.floor(pool / Math.max(1, alive().length)); alive().forEach((p) => gain(p, share, 'transfer'));
        break;
      }
    }
  }

  function nextTurn() {
    if (S.phase === 'over') return;
    const n = S.order.length;
    for (let k = 0; k < n * 3; k++) {
      S.turn++;
      if (S.turn >= n) { S.turn = 0; if (!newRound()) return; }
      const p = cur();
      if (p.out) continue;
      if (p.skip > 0) {
        p.skip--;
        if (p.abducted) {
          p.abducted = false; p.skipWhy = null;
          p.pos = randTile();
          emit('ufoReturn', { pid: p.id, tile: p.pos });
          gain(p, 100, 'alien');
          collectPiles(p, p.pos);
          if (S.phase === 'over') return;
          continue;
        }
        emit('skipTurn', { pid: p.id, why: p.skipWhy });
        if (!p.skip) p.skipWhy = null;
        continue;
      }
      S.phase = 'roll'; S.pending = null; p.chain = 0;
      emit('turn', { pid: p.id });
      return;
    }
    S.phase = 'roll'; emit('turn', { pid: cur().id });
  }

  function endTurn(p) {
    if (S.phase === 'over') return;
    S.phase = 'busy'; S.pending = null;
    for (let i = 0; i < N; i++) {
      const t = S.tiles[i];
      if (t.bomb) { t.bomb--; if (t.bomb === 0) { t.bomb = 1; explodeBomb(i); if (S.phase === 'over') return; } }
    }
    if (p.giant > 0) { p.giant--; if (!p.giant) emit('giantEnd', { pid: p.id }); }
    if (p.extra && !p.out && !p.skip && !p.abducted) {
      p.extra = false; S.phase = 'roll';
      emit('extraRoll', { pid: p.id });
      return;
    }
    p.extra = false;
    nextTurn();
  }

  function finish(p) {
    if (S.phase === 'over') return;
    S.phase = 'busy'; S.pending = null;
    if (chaosStep(p) === 'wait') return;
    endTurn(p);
  }

  function doRoll(p) {
    const tw = twist();
    const nd = tw === 'turbo' ? 3 : 2;
    const dice = []; for (let k = 0; k < nd; k++) dice.push(rnd(1, 6));
    let steps = dice.reduce((a, b) => a + b, 0);
    if (tw === 'gravity') steps = Math.ceil(steps / 2);
    if (tw === 'slippery') steps += 2;
    if (p.giant) steps += 3;
    if (tw === 'moonwalk') steps = -steps;
    const doubles = nd === 2 && dice[0] === dice[1];
    S.lastRoll = dice; S.phase = 'busy';
    emit('dice', { pid: p.id, dice, steps, doubles });
    if (doubles) {
      p.chain++;
      if (p.chain >= 3) { emit('tooExcited', { pid: p.id }); sendNap(p, 'doubles'); return finish(p); }
      p.extra = true;
    }
    moveSteps(p, steps, { noStart: steps < 0 });
    if (S.phase === 'over') return;
    if (resolve(p, 0) === 'done') finish(p);
  }

  function actorOf(state) {
    if (!state || state.phase === 'over' || state.phase === 'busy') return null;
    if (state.phase === 'auction') return state.auction.active[state.auction.idx];
    return state.players[state.order[state.turn]].id;
  }

  function applyAction(state, pid, a) {
    S = state; E = [];
    try {
      if (!a || typeof a.type !== 'string') return { ok: false, error: 'bad' };
      if (actorOf(S) !== pid) return { ok: false, error: 'notYourTurn' };
      const p = S.players[pid];
      switch (S.phase) {
        case 'roll':
          if (a.type !== 'roll') return { ok: false, error: 'bad' };
          doRoll(p); break;
        case 'buy': case 'upgrade': {
          const i = S.pending.tile, t = S.tiles[i], price = S.pending.price;
          if (a.type === 'skip') { emit('declined', { pid, tile: i }); finish(p); break; }
          if (a.type !== 'buy' || p.coins < price) return { ok: false, error: 'bad' };
          p.coins -= price;
          emit('money', { pid, delta: -price, why: S.phase });
          if (S.phase === 'buy') { t.owner = pid; emit('bought', { pid, tile: i }); checkMonopoly(p, i); }
          else { t.level++; emit('upgraded', { pid, tile: i, level: t.level }); }
          finish(p); break;
        }
        case 'guess': {
          if (a.type !== 'guess' || (a.pick !== 'high' && a.pick !== 'low')) return { ok: false, error: 'bad' };
          const base = S.pending.base, die = rnd(1, 6);
          const win = (a.pick === 'high' && die > base) || (a.pick === 'low' && die < base);
          S.pending = null; S.phase = 'busy';
          emit('miniRoll', { pid, base, die, pick: a.pick, result: die === base ? 'tie' : win ? 'win' : 'lose' });
          if (die !== base) { if (win) gain(p, 100, 'mini'); else charge(p, cost(40), 'mini'); }
          finish(p); break;
        }
        case 'auction': {
          const A = S.auction;
          if (a.type === 'pass') {
            A.active.splice(A.idx, 1);
            emit('auctionPass', { pid });
          } else if (a.type === 'bid') {
            const inc = A.leader === null ? 0 : Number(a.inc);
            if (A.leader !== null && ![10, 50, 100].includes(inc)) return { ok: false, error: 'bad' };
            const nb = A.bid + inc;
            if (nb > p.coins) return { ok: false, error: 'bad' };
            A.bid = nb; A.leader = pid; A.idx = (A.idx + 1) % A.active.length;
            emit('bid', { pid, bid: nb });
          } else return { ok: false, error: 'bad' };
          checkAuction();
          if (S.phase !== 'auction') endTurn(cur());
          break;
        }
        default: return { ok: false, error: 'bad' };
      }
      return { ok: true, events: E };
    } catch (err) {
      return { ok: false, error: 'engine', detail: String(err && err.stack || err) };
    }
  }

  // Reasonable automatic decision (used for computer players and disconnected online players).
  function botAction(state) {
    const pid = actorOf(state); if (pid === null) return null;
    const p = state.players[pid];
    switch (state.phase) {
      case 'roll': return { type: 'roll' };
      case 'buy': return p.coins - state.pending.price >= 150 ? { type: 'buy' } : { type: 'skip' };
      case 'upgrade': return p.coins - state.pending.price >= 250 ? { type: 'buy' } : { type: 'skip' };
      case 'guess': return { type: 'guess', pick: state.pending.base <= 3 ? 'high' : 'low' };
      case 'auction': {
        const A = state.auction; const t = state.tiles[A.tile];
        const next = A.leader === null ? A.bid : A.bid + 10;
        if (next <= t.price * 0.9 && p.coins - next >= 200) return { type: 'bid', inc: A.leader === null ? 0 : 10 };
        return { type: 'pass' };
      }
    }
    return null;
  }

  function info(state) {
    S = state;
    return {
      netWorth: state.players.map((p) => netWorth(p)),
      rentOf: (i) => { S = state; return state.tiles[i].owner === null ? 0 : rentOf(i, null); },
      upCost: (i) => upCost(state.tiles[i]),
      rentBase: (i) => rentBase(state.tiles[i]),
    };
  }

  // Testing hook: force a specific chaos event or twist.
  function debugForce(state, kind, id) {
    S = state; E = [];
    if (kind === 'chaos' && MAJOR_RUN[id]) { const r = runMajor(id); if (r !== 'wait' && S.phase === 'busy') S.phase = 'roll'; }
    if (kind === 'twist' && C.TWISTS[id]) runTwist(id);
    return E;
  }

  const api = { createGame, begin, applyAction, actorOf, botAction, info, debugForce, LEVELS, N };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ChaosEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
