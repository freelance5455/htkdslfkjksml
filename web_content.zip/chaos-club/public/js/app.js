/* The Chaos Club — application: screens, board rendering, event playback, chaos visuals, online lobby. */
(function () {
  'use strict';
  const C = ChaosContent, Eng = ChaosEngine;
  const VERSION = '1.0.0';
  const t = (k, v) => I18N.t(k, fmtVars(v));
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const te = (k, v) => esc(t(k, v));
  const num = (n) => I18N.num(n);
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const charOf = (id) => C.CHARACTERS.find((c) => c.id === id) || C.CHARACTERS[0];
  const emo = (id) => charOf(id).e;
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const pickOne = (a) => a[Math.floor(Math.random() * a.length)];
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
  };

  const CARD_ICONS = { grandma: '🐔', potatoCeo: '🥔', sandwich: '🥪', jeans: '👖', hiccup: '😮', llamaSpit: '🦙', toothFairy: '🧚', bathtub: '🛁', karaoke: '🎤', pillowNap: '😴', wizardShield: '🧙', moonwalk: '🕺', rocketShoes: '🚀', catPresident: '🐱', noodles: '🍜', termites: '🐜', swappo: '🎩', juiceBox: '🧃', duckCollection: '🦆', pigeonFine: '🐦', sneezeLaunch: '🤧', lotteryTicket: '🎟️', wizardTax: '🔮', viralDance: '💃', boxInBox: '📦', potRecipe: '🍲', cloudRide: '☁️', bees: '🐝', birthday: '🎂', bubbleWrap: '🫧', goldenSpoon: '🥄', confettiOnly: '🎊', mysteryCheck: '💌', tinyWormhole: '🕳️', snailMail: '🐌', threeSleeves: '🧶', extraRoll: '🎲', pizzaPromise: '🍕', sockLawyer: '🧦', kangaroo: '🦘' };
  const SMALL_ICONS = { pigeonDrop: '🐦', whoopee: '💨', sneezeSlide: '🤧', butterfly: '🦋', underBoard: '🔍', seagull: '🍟', coolFlip: '🤸', dragonSneeze: '🐉', samples: '🧀', shoelace: '👟', ghostTip: '👻', squirrel: '🐿️' };
  const EMOTES = ['😂', '😱', '🤑', '😭', '👏', '🐔'];
  const SPEEDS = { slow: 1.35, normal: 1, fast: 0.62 };

  // ---------------------------------------------------------------- settings
  const BAKED_SERVER = ((window.CHAOS_CONFIG || {}).server || '').trim();
  const Settings = Object.assign({ sound: true, volume: 0.6, reduceMotion: false, shake: true, speed: 'normal', server: '' }, store.get('cc.settings', {}));
  if (!Settings.server && BAKED_SERVER) Settings.server = BAKED_SERVER;
  function applySettings() {
    Sound.enabled = Settings.sound; Sound.setVolume(Settings.volume);
    FX.reduceMotion = Settings.reduceMotion; FX.shakeOn = Settings.shake;
    if (!App.fast) FX.speed = SPEEDS[Settings.speed] || 1;
    document.body.classList.toggle('reduce-motion', Settings.reduceMotion);
    $('#mbSound').textContent = Settings.sound ? '🔊' : '🔇';
    store.set('cc.settings', Settings);
  }

  // ---------------------------------------------------------------- server detection
  const Server = { base: null, translate: false, checked: false };
  async function probe(base) {
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 4000);
    try { const r = await fetch(base + '/api/status', { cache: 'no-store', signal: ctl.signal }); if (!r.ok) return null; const d = await r.json(); return d && d.ok ? d : null; }
    catch (e) { return null; } finally { clearTimeout(tm); }
  }
  async function detectServer() {
    const list = [];
    if (Settings.server) list.push(Settings.server.trim().replace(/\/+$/, ''));
    if (/^https?:$/.test(location.protocol)) list.push(location.origin);
    Server.base = null; Server.translate = false;
    for (const base of list) { const d = await probe(base); if (d) { Server.base = base; Server.translate = !!d.translate; break; } }
    Server.checked = true;
    return !!Server.base;
  }

  // ---------------------------------------------------------------- app state
  const App = {
    screen: 'home', mode: null, game: null, view: null, me: null, room: null, log: [], queue: [], playing: false,
    sending: false, fast: false, botTimer: null, overShown: false,
    setup: store.get('cc.setup', null) || { players: [{ name: '', avatar: 'chicken', color: C.COLORS[0], bot: false }, { name: '', avatar: 'potato', color: C.COLORS[5], bot: true }], rounds: 15, chaos: 'chaotic' },
    profile: store.get('cc.profile', null) || { name: '', avatar: pickOne(C.CHARACTERS).id, color: pickOne(C.COLORS) },
  };
  let tileEls = [], tokenEls = {}, animating = new Set(), boardRO = null;

  // vars may contain {p: id} (player) or {tile: {t,id}} (tile) descriptors, resolved at render time
  function fmtVars(v) {
    if (!v) return v;
    const o = {};
    for (const k in v) {
      const x = v[k];
      if (x && typeof x === 'object' && 'p' in x) o[k] = pname(x.p);
      else if (x && typeof x === 'object' && 'tile' in x) o[k] = tileName(x.tile);
      else o[k] = x;
    }
    return o;
  }
  const P = (id) => ({ p: id });
  const T = (st, i) => ({ tile: { t: st.tiles[i].t, id: st.tiles[i].id } });
  function pname(id) { const st = App.view; return st && st.players[id] ? nameOf(st.players[id]) : '?'; }
  // players who didn't type a name are shown as their character's name in the current language
  function nameOf(p) { return p.auto ? I18N.t('char.' + p.avatar) : p.name; }
  function tileName(tl) { if (!tl) return ''; return tl.t === 'prop' ? I18N.t('prop.' + tl.id) : tl.t === 'tax' ? I18N.t('tax.' + tl.id) : I18N.t('tile.' + tl.t); }
  function tileIcon(tl) { return tl.icon || C.TILE_ICONS[tl.t] || '⬜️'; }

  // ---------------------------------------------------------------- static text, menus, chrome
  function applyStatic() {
    $$('[data-i18n]').forEach((el) => { el.textContent = I18N.t(el.dataset.i18n); });
    $$('[data-i18n-ph]').forEach((el) => { el.placeholder = I18N.t(el.dataset.i18nPh); });
    $$('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', I18N.t(el.dataset.i18nAria)); });
    $$('[data-i18n-title]').forEach((el) => { el.title = I18N.t(el.dataset.i18nTitle); });
    $('#langList').innerHTML = I18N.suggestions().map((s) => `<option value="${esc(s)}">`).join('');
    $('#mbLang').value = '';
    $('#mbLang').placeholder = I18N.current.name + ' — ' + I18N.t('settings.langPh');
    document.title = I18N.t('app.name');
    tickClock(); updateTitle();
  }
  function tickClock() {
    try { $('#mbClock').textContent = new Intl.DateTimeFormat(I18N.current.code, { weekday: 'short', hour: 'numeric', minute: '2-digit' }).format(new Date()); }
    catch (e) { $('#mbClock').textContent = new Date().toLocaleTimeString(); }
  }
  function updateTitle() {
    $('#winTitle').textContent = I18N.t('app.name');
    let sub = '';
    if (App.screen === 'game' && App.view) sub = t('game.round', { n: Math.min(App.view.round, App.view.maxRounds), m: App.view.maxRounds });
    if (App.room) sub = (sub ? sub + ' · ' : '') + App.room.code;
    $('#winSub').textContent = sub;
    const dot = $('#netDot');
    dot.hidden = App.mode !== 'online';
    dot.classList.toggle('bad', Net.status !== 'open');
  }

  const MENUS = {
    app: () => [{ k: 'menu.about', a: showAbout }, '-', { k: 'menu.settings', sc: '⌘,', a: () => openSettings() }],
    game: () => [
      { k: 'menu.newGame', sc: '⌘N', a: () => confirmLeave(() => go('setup')) },
      { k: 'menu.online', a: () => confirmLeave(() => go('online')) }, '-',
      { k: 'menu.home', a: () => confirmLeave(() => go('home')) },
      { k: 'menu.leave', a: () => confirmLeave(() => go('home')), dis: App.screen !== 'game' && !App.room },
    ],
    view: () => [
      { k: 'menu.sound', chk: Settings.sound, sc: 'M', a: toggleSound },
      { k: 'menu.reduceMotion', chk: Settings.reduceMotion, a: () => { Settings.reduceMotion = !Settings.reduceMotion; applySettings(); } }, '-',
      { k: 'menu.fullscreen', sc: 'F', a: toggleFullscreen },
    ],
    help: () => [{ k: 'menu.howTo', sc: '?', a: showHelp }, { k: 'menu.language', a: () => openSettings('language') }],
  };
  let openMenuName = null;
  function openMenu(name, btn) {
    const pop = $('#menuPop');
    if (openMenuName === name) return closeMenu();
    closeMenu();
    openMenuName = name;
    $$(`#menubar [data-menu="${name}"]`).forEach((b) => b.classList.add('open'));
    pop.innerHTML = MENUS[name]().map((it, i) => it === '-' ? '<hr>' : `<button data-i="${i}" ${it.dis ? 'disabled' : ''} role="menuitem"><span class="chk">${it.chk ? '✓' : ''}</span>${te(it.k)}${it.sc ? `<span class="sc">${it.sc}</span>` : ''}</button>`).join('');
    const r = btn.getBoundingClientRect();
    pop.hidden = false;
    const left = I18N.dir === 'rtl' ? Math.max(6, r.right - pop.offsetWidth) : Math.min(r.left, innerWidth - pop.offsetWidth - 6);
    pop.style.left = left + 'px';
    const items = MENUS[name]();
    $$('button', pop).forEach((b) => b.addEventListener('click', () => { closeMenu(); Sound.play('click'); items[+b.dataset.i].a(); }));
  }
  function closeMenu() { openMenuName = null; $('#menuPop').hidden = true; $$('#menubar .open').forEach((b) => b.classList.remove('open')); }

  function toggleSound() { Settings.sound = !Settings.sound; applySettings(); if (Settings.sound) Sound.play('coin'); }
  function toggleFullscreen() {
    const d = document;
    if (!d.fullscreenElement && d.documentElement.requestFullscreen) d.documentElement.requestFullscreen().catch(() => toggleZoom());
    else if (d.exitFullscreen && d.fullscreenElement) d.exitFullscreen();
    else toggleZoom();
  }
  function toggleZoom() { document.body.classList.toggle('zoomed'); }

  function toast(icon, title, body, ms) {
    const el = document.createElement('div');
    el.className = 'toast glass';
    el.innerHTML = `<div class="ti">${icon}</div><div>${title ? `<b>${esc(title)}</b>` : ''}${body ? `<span>${esc(body)}</span>` : ''}</div>`;
    $('#toasts').prepend(el);
    const kill = () => { el.classList.add('out'); setTimeout(() => el.remove(), 300); };
    el.addEventListener('click', kill);
    setTimeout(kill, ms || 4200);
    while ($('#toasts').children.length > 4) $('#toasts').lastChild.remove();
  }

  // ---------------------------------------------------------------- modals
  const modals = [];
  function modal(inner, opts) {
    opts = opts || {};
    const back = document.createElement('div'); back.className = 'modal-back';
    back.innerHTML = `<div class="modal glass" role="dialog">${inner}</div>`;
    $('#modalLayer').appendChild(back);
    const m = { el: back, close() { if (m.closed) return; m.closed = true; back.classList.add('closing'); setTimeout(() => back.remove(), 200); const i = modals.indexOf(m); if (i >= 0) modals.splice(i, 1); if (opts.onClose) opts.onClose(); } };
    if (opts.dismiss !== false) back.addEventListener('mousedown', (e) => { if (e.target === back) m.close(); });
    modals.push(m);
    return m;
  }
  function closeModals() { modals.slice().forEach((m) => m.close()); }
  function confirmBox(text, okLabel, onOk) {
    const m = modal(`<h2>${esc(t('app.name'))}</h2><p>${esc(text)}</p><div class="actions"><button class="btn" data-x>${te('game.cancel')}</button><button class="btn danger" data-ok>${esc(okLabel)}</button></div>`);
    $('[data-x]', m.el).onclick = () => m.close();
    $('[data-ok]', m.el).onclick = () => { m.close(); onOk(); };
    $('[data-ok]', m.el).focus();
  }
  function confirmLeave(fn) {
    const inGame = App.screen === 'game' && App.view && App.view.phase !== 'over';
    if (inGame) confirmBox(App.mode === 'online' ? t('game.leaveOnline') : t('game.leaveConfirm'), t('game.leave'), () => { leaveCurrent(); fn(); });
    else { if (App.room || App.mode) leaveCurrent(); fn(); }
  }
  function leaveCurrent() {
    if (App.mode === 'online' || App.room) { Net.send({ t: 'leave' }); Net.forget(); Net.close(); }
    clearTimeout(App.botTimer);
    App.mode = null; App.game = null; App.view = null; App.room = null; App.me = null; App.queue = []; App.sending = false; App.overShown = false;
    closeModals();
  }
  function showHelp() {
    const sec = [['🎯', 'goal'], ['🎲', 'turn'], ['🏠', 'props'], ['✨', 'spaces'], ['💥', 'chaos'], ['🌀', 'twists'], ['👵', 'safety']];
    const m = modal(`<h2>${te('help.title')}</h2><div class="help-grid">${sec.map(([i, k]) => `<div><i>${i}</i><b>${te('help.' + k + '.t')}</b><p>${te('help.' + k)}</p></div>`).join('')}</div><div class="actions"><button class="btn primary" data-x>${te('help.close')}</button></div>`);
    $('[data-x]', m.el).onclick = () => m.close();
  }
  function showAbout() {
    const m = modal(`<div style="text-align:center"><div class="app-icon" style="position:relative;inset:auto;width:96px;height:96px;margin:0 auto 12px;font-size:54px;border-radius:22px">🐔</div><h2 style="margin:0 0 4px">${te('app.name')}</h2><div class="muted">${te('settings.version', { n: VERSION })}</div><p class="small-note" style="margin:14px 0 0">${te('settings.aboutText')}</p></div><div class="actions"><button class="btn primary" data-x>${te('common.ok')}</button></div>`);
    $('[data-x]', m.el).onclick = () => m.close();
  }
  function pickAvatar(current, onPick) {
    const m = modal(`<h2>${te('setup.avatar')}</h2><div class="avatar-grid">${C.CHARACTERS.map((c) => `<button data-id="${c.id}" class="${c.id === current ? 'on' : ''}" title="${te('char.' + c.id)}">${c.e}</button>`).join('')}</div><p class="char-name" id="avName" style="text-align:center;margin:12px 0 0">${te('char.' + current)}</p>`);
    $$('[data-id]', m.el).forEach((b) => {
      b.onmouseenter = () => { $('#avName', m.el).textContent = t('char.' + b.dataset.id); Sound.play('hover'); };
      b.onclick = () => { Sound.play('pop'); m.close(); onPick(b.dataset.id); };
    });
  }

  // ---------------------------------------------------------------- settings window
  let settingsWin = null, settingsTab = 'language';
  function openSettings(tab) {
    settingsTab = tab || settingsTab;
    if (!settingsWin) {
      settingsWin = document.createElement('div');
      settingsWin.className = 'settings-win glass';
      $('#modalLayer').appendChild(settingsWin);
    }
    renderSettings();
  }
  function closeSettings() { if (!settingsWin) return; const w = settingsWin; settingsWin = null; w.classList.add('closing'); setTimeout(() => w.remove(), 200); }
  function renderSettings() {
    if (!settingsWin) return;
    const tabs = [['language', '🌐', '#0A84FF'], ['general', '⚙️', '#8e8e93'], ['sound', '🔊', '#FF453A'], ['online', '🌍', '#32D74B'], ['about', 'ℹ️', '#BF5AF2']];
    const sw = (on, id) => `<button class="switch ${on ? 'on' : ''}" data-sw="${id}" role="switch" aria-checked="${on}"></button>`;
    let main = '';
    if (settingsTab === 'language') {
      const ai = Server.base ? (Server.translate ? t('settings.aiOn') : t('settings.aiOff')) : t('settings.aiNoServer');
      main = `<h2>${te('settings.language')}</h2>
        <div class="label">${te('settings.langLabel')}</div>
        <form class="lang-big" id="sLangForm" autocomplete="off"><input class="field" id="sLang" list="langList" placeholder="${te('settings.langPh')}" spellcheck="false"><button class="btn primary">${te('settings.langApply')}</button></form>
        <div class="lang-status" id="sLangStatus"></div>
        <div class="chips">${I18N.suggestions().slice(0, 12).map((s) => `<button data-lang="${esc(s)}" class="${s === I18N.current.name ? 'on' : ''}">${esc(s)}</button>`).join('')}</div>
        <div class="sgroup" style="margin-top:16px">
          <div class="srow"><span>${te('settings.current', { lang: I18N.current.name })}</span><span>${I18N.current.ai ? '✨ AI' : '📦'}</span></div>
          <div class="srow"><span class="muted">${te('settings.langBuiltIn', { list: I18N.builtinList().join(', ') })}</span></div>
          <div class="srow"><span class="muted">${te('settings.langAi', { state: ai })}</span><span>${Server.translate ? '✅' : '⚪️'}</span></div>
        </div>
        <p class="small-note">${te('settings.langHelp')}</p>`;
    } else if (settingsTab === 'general') {
      main = `<h2>${te('settings.general')}</h2><div class="sgroup">
        <div class="srow"><span>${te('settings.speed')}</span><div class="seg" id="sSpeed">${['slow', 'normal', 'fast'].map((s) => `<button data-v="${s}" class="${Settings.speed === s ? 'on' : ''}">${te('settings.speed' + s[0].toUpperCase() + s.slice(1))}</button>`).join('')}</div></div>
        <div class="srow"><span>${te('settings.motion')}</span>${sw(Settings.reduceMotion, 'reduceMotion')}</div>
        <div class="srow"><span>${te('settings.shake')}</span>${sw(Settings.shake, 'shake')}</div></div>`;
    } else if (settingsTab === 'sound') {
      main = `<h2>${te('settings.sound')}</h2><div class="sgroup">
        <div class="srow"><span>${te('settings.soundOn')}</span>${sw(Settings.sound, 'sound')}</div>
        <div class="srow"><span>${te('settings.volume')}</span><input type="range" min="0" max="1" step="0.05" value="${Settings.volume}" id="sVol"></div></div>`;
    } else if (settingsTab === 'online') {
      main = `<h2>${te('settings.online')}</h2>
        <div class="label">${te('settings.serverUrl')}</div>
        <div class="lang-big"><input class="field" id="sServer" value="${esc(Settings.server)}" placeholder="https://chaos.example.com" spellcheck="false" dir="ltr"><button class="btn" id="sTest">${te('settings.test')}</button></div>
        <div class="lang-status" id="sSrvStatus">${Server.base ? '🟢 ' + esc(Server.base) : ''}</div>
        <p class="small-note">${te('settings.serverHelp')}</p>`;
    } else {
      main = `<div style="text-align:center;padding-top:20px"><div class="app-icon" style="position:relative;inset:auto;width:96px;height:96px;margin:0 auto 12px;font-size:54px;border-radius:22px">🐔</div><h2 style="margin:0 0 4px">${te('app.name')}</h2><div class="muted">${te('settings.version', { n: VERSION })}</div><p class="small-note" style="max-width:380px;margin:14px auto">${te('settings.aboutText')}</p></div>`;
    }
    settingsWin.innerHTML = `<div class="s-side"><div class="traffic"><button class="tl tl-red" data-close aria-label="${te('window.close')}"><svg viewBox="0 0 10 10"><path d="M2.5 2.5l5 5M7.5 2.5l-5 5"/></svg></button><span class="tl" style="background:#4a4a50"></span><span class="tl" style="background:#4a4a50"></span></div>
      ${tabs.map(([id, ic, c]) => `<button class="tab ${settingsTab === id ? 'on' : ''}" data-tab="${id}"><span class="ic" style="background:${c}">${ic}</span><span class="lbl">${te('settings.' + id)}</span></button>`).join('')}</div>
      <div class="s-main">${main}</div>`;
    const W = settingsWin;
    $('[data-close]', W).onclick = closeSettings;
    $$('[data-tab]', W).forEach((b) => { b.onclick = () => { settingsTab = b.dataset.tab; Sound.play('click'); renderSettings(); }; });
    $$('[data-sw]', W).forEach((b) => { b.onclick = () => { Settings[b.dataset.sw] = !Settings[b.dataset.sw]; applySettings(); Sound.play('click'); renderSettings(); }; });
    if ($('#sLangForm', W)) {
      $('#sLangForm', W).onsubmit = (e) => { e.preventDefault(); setLanguage($('#sLang', W).value, $('#sLangStatus', W)); };
      $$('[data-lang]', W).forEach((b) => { b.onclick = () => { $('#sLang', W).value = b.dataset.lang; setLanguage(b.dataset.lang, $('#sLangStatus', W)); }; });
      setTimeout(() => $('#sLang', W) && $('#sLang', W).focus(), 50);
    }
    if ($('#sSpeed', W)) $$('#sSpeed button', W).forEach((b) => { b.onclick = () => { Settings.speed = b.dataset.v; applySettings(); renderSettings(); }; });
    if ($('#sVol', W)) $('#sVol', W).oninput = (e) => { Settings.volume = +e.target.value; applySettings(); };
    if ($('#sVol', W)) $('#sVol', W).onchange = () => Sound.play('coin');
    if ($('#sTest', W)) {
      $('#sTest', W).onclick = async () => {
        const st = $('#sSrvStatus', W);
        Settings.server = $('#sServer', W).value.trim().replace(/\/+$/, ''); applySettings();
        st.className = 'lang-status'; st.innerHTML = `<span class="spin"></span> ${te('settings.testing')}`;
        const ok = await detectServer();
        if (!settingsWin) return;
        st.className = 'lang-status ' + (ok ? 'ok' : 'err');
        st.textContent = ok ? '🟢 ' + t('settings.testOk', { ai: Server.translate ? t('settings.yes') : t('settings.no') }) + ' — ' + Server.base : '🔴 ' + t('settings.testFail');
        if (App.screen === 'online' && !App.room) renderOnline();
      };
    }
  }

  async function setLanguage(text, statusEl) {
    text = String(text || '').trim();
    if (!text) return;
    const setStatus = (cls, html) => { if (statusEl && statusEl.isConnected) { statusEl.className = 'lang-status ' + cls; statusEl.innerHTML = html; } };
    if (!I18N.builtinFor(text)) {
      if (!Server.checked || !Server.base) await detectServer();
      if (Server.translate) { $('#mbSpin').hidden = false; setStatus('', `<span class="spin"></span> ${te('settings.translating', { lang: text })}`); toast('🌐', t('settings.translating', { lang: text }), '', 3000); }
    }
    const r = await I18N.setFromText(text, Server);
    $('#mbSpin').hidden = true;
    const el = settingsWin ? $('#sLangStatus', settingsWin) : statusEl;
    if (el) { el.className = 'lang-status ' + (r.ok ? 'ok' : 'err'); el.textContent = (r.ok ? '✅ ' : '⚠️ ') + r.message; }
    if (r.message) toast(r.ok ? '🌐' : '⚠️', r.ok ? I18N.current.name : t('settings.language'), r.message, r.ok ? 3000 : 7000);
    if (r.ok) Sound.play('pop');
  }
  I18N.onChange(() => {
    applyStatic();
    if (App.screen === 'game' && App.view) { buildGame(); renderState(App.view); }
    else render(true);
    if (settingsWin) renderSettings();
  });

  // ---------------------------------------------------------------- screens
  function go(screen) { App.screen = screen; hideTip(); render(); }
  function render(quiet) {
    const el = $('#screen');
    if (!quiet) { el.classList.remove('screen-enter'); void el.offsetWidth; el.classList.add('screen-enter'); }
    if (App.screen !== 'game' && boardRO) { boardRO.disconnect(); boardRO = null; }
    if (App.screen === 'home') renderHome();
    else if (App.screen === 'setup') renderSetup();
    else if (App.screen === 'online') renderOnline();
    else if (App.screen === 'game') { buildGame(); if (App.view) renderState(App.view); }
    el.scrollTop = 0;
    updateTitle();
  }

  function renderHome() {
    const orbit = ['🦖', '👽', '🥔', '🦄', '🐙', '🤖', '🍌', '👻'];
    $('#screen').innerHTML = `<div class="home"><div class="hero">
      <div class="hero-art"><div class="orbit">${orbit.map((e, i) => { const a = (i / orbit.length) * Math.PI * 2; return `<span style="left:${50 + 44 * Math.cos(a) - 7}%;top:${50 + 44 * Math.sin(a) - 7}%">${e}</span>`; }).join('')}</div><div class="app-icon">🐔</div></div>
      <h1>${te('app.name')}</h1><p>${te('app.tagline')}</p>
      <div class="home-cards">
        <button class="home-card primary" data-go="setup"><div class="hc-icon">🎲</div><b>${te('home.local')}</b><span>${te('home.localSub')}</span></button>
        <button class="home-card" data-go="online"><div class="hc-icon">🌍</div><b>${te('home.online')}</b><span>${te('home.onlineSub')}</span></button>
        <button class="home-card" data-go="rules"><div class="hc-icon">📖</div><b>${te('home.rules')}</b><span>${te('home.rulesSub')}</span></button>
      </div><div class="home-foot">${te('home.footer')}</div></div></div>`;
    $$('[data-go]').forEach((b) => { b.onclick = () => { Sound.unlock(); Sound.play('click'); if (b.dataset.go === 'rules') showHelp(); else go(b.dataset.go); }; });
  }

  // ---------- local setup ----------
  function renderSetup() {
    const S = App.setup;
    const used = (i) => S.players.filter((_, j) => j !== i).map((p) => p.color);
    $('#screen').innerHTML = `<div class="page">
      <div class="page-head"><div><h2>${te('setup.title')}</h2><div class="muted">${te('setup.sub')}</div></div><button class="btn ghost" data-back>‹ ${te('setup.back')}</button></div>
      <div class="players-grid">${S.players.map((p, i) => `
        <div class="pcard" data-i="${i}">
          ${S.players.length > 2 ? `<button class="pc-remove" data-remove title="${te('setup.remove')}">✕</button>` : ''}
          <div class="pc-top"><button class="avatar-btn" data-avatar style="--c:${p.color}" title="${te('setup.avatar')}">${emo(p.avatar)}</button>
            <div style="flex:1;min-width:0"><div class="label">${te('setup.player', { n: i + 1 })}</div><input class="field" data-name maxlength="16" value="${esc(p.name)}" placeholder="${te('char.' + p.avatar)}"></div></div>
          <div class="char-name">${te('char.' + p.avatar)}</div>
          <div><div class="label">${te('setup.color')}</div><div class="swatches">${C.COLORS.map((c) => `<button class="swatch ${c === p.color ? 'on' : ''}" data-color="${c}" style="--c:${c}" ${used(i).includes(c) ? 'disabled title="' + te('setup.colorTaken') + '"' : ''}></button>`).join('')}</div></div>
          <div class="seg" data-kind><button data-bot="0" class="${p.bot ? '' : 'on'}">🙂 ${te('setup.human')}</button><button data-bot="1" class="${p.bot ? 'on' : ''}">🤖 ${te('setup.bot')}</button></div>
        </div>`).join('')}
        ${S.players.length < 4 ? `<button class="add-card" data-add><b>+</b>${te('setup.add')}</button>` : ''}
      </div>
      <div class="options-row">
        <div><div class="label">${te('setup.length')}</div><div class="seg" data-rounds>${[[10, 'quick'], [15, 'classic'], [20, 'epic']].map(([r, k]) => `<button data-v="${r}" class="${S.rounds === r ? 'on' : ''}">${te('setup.' + k)}<small>${te('setup.rounds', { n: r })}</small></button>`).join('')}</div></div>
        <div><div class="label">${te('setup.chaos')}</div><div class="seg" data-chaos>${['chill', 'chaotic', 'mayhem'].map((k) => `<button data-v="${k}" class="${S.chaos === k ? 'on' : ''}">${te('chaos.' + k)}<small>${te('chaos.' + k + 'Sub')}</small></button>`).join('')}</div></div>
      </div>
      <div class="start-row"><div style="display:flex;align-items:center;gap:14px"><span class="label" style="margin:0">${te('setup.lineup')}</span><div class="lineup">${S.players.map((p) => `<span style="--c:${p.color}">${emo(p.avatar)}</span>`).join('')}</div></div>
        <button class="btn big primary" data-start ${S.players.length < 2 ? 'disabled' : ''}>▶︎ ${te('setup.start')}</button></div>
    </div>`;
    const save = () => store.set('cc.setup', S);
    $('[data-back]').onclick = () => go('home');
    $$('.pcard').forEach((card) => {
      const i = +card.dataset.i, p = S.players[i];
      $('[data-name]', card).oninput = (e) => { p.name = e.target.value; save(); };
      $('[data-avatar]', card).onclick = () => pickAvatar(p.avatar, (id) => { p.avatar = id; save(); renderSetup(); });
      $$('[data-color]', card).forEach((b) => { b.onclick = () => { p.color = b.dataset.color; Sound.play('click'); save(); renderSetup(); }; });
      $$('[data-bot]', card).forEach((b) => { b.onclick = () => { p.bot = b.dataset.bot === '1'; Sound.play('click'); save(); renderSetup(); }; });
      const rm = $('[data-remove]', card); if (rm) rm.onclick = () => { S.players.splice(i, 1); Sound.play('pop'); save(); renderSetup(); };
    });
    const add = $('[data-add]');
    if (add) add.onclick = () => {
      const usedC = S.players.map((p) => p.color), usedA = S.players.map((p) => p.avatar);
      S.players.push({ name: '', avatar: C.CHARACTERS.find((c) => !usedA.includes(c.id)).id, color: C.COLORS.find((c) => !usedC.includes(c)), bot: false });
      Sound.play('pop'); save(); renderSetup();
    };
    $$('[data-rounds] button').forEach((b) => { b.onclick = () => { S.rounds = +b.dataset.v; save(); renderSetup(); }; });
    $$('[data-chaos] button').forEach((b) => { b.onclick = () => { S.chaos = b.dataset.v; save(); renderSetup(); }; });
    $('[data-start]').onclick = startLocal;
  }

  function startLocal() {
    const S = App.setup;
    Sound.unlock();
    leaveCurrent();
    const list = S.players.map((p) => ({ name: p.name.trim() || I18N.t('char.' + p.avatar), auto: !p.name.trim(), avatar: p.avatar, color: p.color, bot: p.bot }));
    App.mode = 'local';
    App.game = Eng.createGame(list, { rounds: S.rounds, chaos: S.chaos });
    App.view = clone(App.game); App.log = []; App.queue = []; App.overShown = false;
    go('game');
    enqueue(Eng.begin(App.game));
  }

  // ---------- online lobby ----------
  function profileOut() { const p = App.profile; return { name: (p.name || '').trim(), avatar: p.avatar, color: p.color }; }
  async function ensureConnected() {
    if (Net.status === 'open') return true;
    if (!Server.base) await detectServer();
    if (!Server.base) { renderOnline(); return false; }
    try { await Net.connect(Server.base); return true; } catch (e) { toast('⚠️', t('online.title'), t('online.noServer')); return false; }
  }
  function profileEditor(lobby) {
    const p = App.profile;
    const taken = lobby && App.room ? App.room.players.filter((x) => x.seat !== App.me).map((x) => x.color) : [];
    return `<div class="pc-top"><button class="avatar-btn" id="opAvatar" style="--c:${p.color}">${emo(p.avatar)}</button>
      <div style="flex:1;min-width:0"><div class="label">${te('setup.name')}</div><input class="field" id="opName" maxlength="16" value="${esc(p.name)}" placeholder="${te('char.' + p.avatar)}"></div></div>
      <div style="margin-top:12px"><div class="label">${te('setup.color')}</div><div class="swatches">${C.COLORS.map((c) => `<button class="swatch ${c === p.color ? 'on' : ''}" data-ocolor="${c}" style="--c:${c}" ${taken.includes(c) ? 'disabled' : ''}></button>`).join('')}</div></div>`;
  }
  function bindProfile(lobby) {
    const p = App.profile, save = () => store.set('cc.profile', p);
    const push = () => { if (lobby) Net.send(Object.assign({ t: 'profile' }, profileOut())); };
    $('#opName').oninput = (e) => { p.name = e.target.value; save(); };
    $('#opName').onchange = push;
    $('#opAvatar').onclick = () => pickAvatar(p.avatar, (id) => { p.avatar = id; save(); push(); lobby ? updateLobby(true) : renderOnline(); });
    $$('[data-ocolor]').forEach((b) => { b.onclick = () => { p.color = b.dataset.ocolor; save(); push(); Sound.play('click'); lobby ? updateLobby(true) : renderOnline(); }; });
  }
  function renderOnline() {
    if (App.screen !== 'online') return;
    const head = `<div class="page-head"><div><h2>${te('online.title')}</h2><div class="muted">${te('home.onlineSub')}</div></div><button class="btn ghost" data-back>‹ ${te('setup.back')}</button></div>`;
    if (!App.room) {
      const noSrv = Server.checked && !Server.base;
      $('#screen').innerHTML = `<div class="page">${head}
        ${noSrv ? `<div class="notice" style="margin-bottom:16px"><span>⚠️</span><span>${te('online.noServer')}</span><button class="btn" data-srv>⚙︎ ${te('settings.online')}</button></div>` : ''}
        <div class="online-grid">
          <div class="panel"><h3>${te('online.you')}</h3>${profileEditor(false)}</div>
          <div class="panel"><h3>${te('online.create')}</h3>
            <button class="btn big primary" style="width:100%" data-create ${noSrv ? 'disabled' : ''}>＋ ${te('online.create')}</button>
            <div class="label" style="margin:22px 0 8px">${te('online.or')}</div>
            <form class="join-row" data-join><input class="field" id="joinCode" maxlength="5" placeholder="${te('online.codePh')}" autocomplete="off" spellcheck="false"><button class="btn" ${noSrv ? 'disabled' : ''}>${te('online.join')}</button></form>
            <p class="small-note" style="margin:14px 0 0">${Server.base ? '🟢 ' + te('online.server', { url: Server.base }) : (Server.checked ? '' : '<span class="spin"></span> ' + te('online.connecting'))}</p>
          </div></div></div>`;
      $('[data-back]').onclick = () => go('home');
      const srv = $('[data-srv]'); if (srv) srv.onclick = () => openSettings('online');
      bindProfile(false);
      $('[data-create]').onclick = async () => { Sound.unlock(); if (await ensureConnected()) Net.send(Object.assign({ t: 'create' }, profileOut())); };
      $('[data-join]').onsubmit = async (e) => {
        e.preventDefault(); Sound.unlock();
        const code = $('#joinCode').value.trim().toUpperCase(); if (!code) return;
        if (await ensureConnected()) Net.send(Object.assign({ t: 'join', code }, profileOut()));
      };
      if (!Server.checked) detectServer().then(() => renderOnline());
      return;
    }
    $('#screen').innerHTML = `<div class="page">${head}<div class="online-grid">
      <div class="panel"><div class="label">${te('online.roomCode')}</div><div class="code-big">${esc(App.room.code)}</div>
        <button class="btn" data-copy>📋 ${te('online.copy')}</button><p class="small-note">${te('online.invite')}</p>
        <div id="lobbyOpts"></div></div>
      <div class="panel"><div class="label" id="lobbyCount"></div><div class="lobby-list" id="lobbyPlayers"></div>
        <div style="margin-top:16px" id="lobbyMe"></div>
        <div class="start-row" style="margin-top:16px"><button class="btn ghost" data-leave>${te('online.leave')}</button><div id="lobbyStart"></div></div></div>
      </div></div>`;
    $('[data-back]').onclick = () => confirmLeave(() => go('home'));
    $('[data-leave]').onclick = () => { leaveCurrent(); go('online'); };
    $('[data-copy]').onclick = () => {
      const done = () => toast('📋', t('online.copied'), App.room.code, 2000);
      if (navigator.clipboard) navigator.clipboard.writeText(App.room.code).then(done, done); else done();
    };
    updateLobby(true);
  }
  function updateLobby(includeMe) {
    if (App.screen !== 'online' || !App.room || !$('#lobbyPlayers')) return renderOnline();
    const R = App.room, host = R.players.find((p) => p.host), isHost = host && host.seat === App.me;
    $('#lobbyCount').textContent = t('online.waiting', { n: R.players.length });
    $('#lobbyPlayers').innerHTML = R.players.map((p) => `<div class="lobby-p"><span class="av" style="--c:${p.color}">${emo(p.avatar)}</span><span class="nm">${esc(nameOf(p))}</span>
      ${p.seat === App.me ? `<span class="badge blue">${te('online.you')}</span>` : ''}${p.host ? `<span class="badge">👑 ${te('online.host')}</span>` : ''}
      ${p.online ? '<span class="dot"></span>' : `<span class="badge gray">${te('online.offline')}</span>`}</div>`).join('');
    $('#lobbyOpts').innerHTML = `<div style="margin-top:18px"><div class="label">${te('setup.length')}</div><div class="seg" data-rounds>${[[10, 'quick'], [15, 'classic'], [20, 'epic']].map(([r, k]) => `<button data-v="${r}" class="${R.settings.rounds === r ? 'on' : ''}" ${isHost ? '' : 'disabled'}>${te('setup.' + k)}<small>${te('setup.rounds', { n: r })}</small></button>`).join('')}</div></div>
      <div style="margin-top:14px"><div class="label">${te('setup.chaos')}</div><div class="seg" data-chaos>${['chill', 'chaotic', 'mayhem'].map((k) => `<button data-v="${k}" class="${R.settings.chaos === k ? 'on' : ''}" ${isHost ? '' : 'disabled'}>${te('chaos.' + k)}</button>`).join('')}</div></div>
      ${isHost ? '' : `<p class="small-note">${te('online.settingsHostOnly')}</p>`}`;
    $$('[data-rounds] button').forEach((b) => { b.onclick = () => Net.send({ t: 'settings', rounds: +b.dataset.v, chaos: R.settings.chaos }); });
    $$('[data-chaos] button').forEach((b) => { b.onclick = () => Net.send({ t: 'settings', rounds: R.settings.rounds, chaos: b.dataset.v }); });
    $('#lobbyStart').innerHTML = isHost
      ? `<button class="btn big primary" data-start ${R.players.length < 2 ? 'disabled' : ''}>▶︎ ${te('online.start')}</button>`
      : `<span class="muted"><span class="spin"></span> ${te('online.onlyHost')}</span>`;
    const sb = $('[data-start]'); if (sb) sb.onclick = () => { Sound.unlock(); Net.send({ t: 'start' }); };
    const me = R.players.find((p) => p.seat === App.me);
    if (me) { App.profile.color = me.color; }
    const meBox = $('#lobbyMe');
    if (includeMe || !meBox.innerHTML || !meBox.contains(document.activeElement)) { meBox.innerHTML = profileEditor(true); bindProfile(true); }
  }

  // ---------------------------------------------------------------- game screen
  function gridPos(i) {
    if (i <= 8) return [9, 9 - i];
    if (i <= 16) return [9 - (i - 8), 1];
    if (i <= 24) return [1, 1 + (i - 16)];
    return [1 + (i - 24), 9];
  }
  function dieHTML(v, cls) {
    const pips = { 1: [5], 2: [1, 9], 3: [1, 5, 9], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
    const face = (n) => `<div class="f f${n} ${n === 1 ? 'red' : ''}">${pips[n].map((k) => `<i style="grid-row:${Math.ceil(k / 3)};grid-column:${((k - 1) % 3) + 1}"></i>`).join('')}</div>`;
    return `<div class="die ${cls || ''}" data-v="${v || 1}">${[1, 2, 3, 4, 5, 6].map(face).join('')}</div>`;
  }
  const FACE = { 1: [0, 0], 6: [0, 180], 3: [0, -90], 4: [0, 90], 5: [-90, 0], 2: [90, 0] };
  function setDie(el, v, spin) {
    el._spin = (el._spin || 0) + (spin ? 2 + Math.floor(Math.random() * 2) : 0);
    const [ax, ay] = FACE[v];
    el.style.transform = `rotateX(${ax + 360 * el._spin}deg) rotateY(${ay + (spin ? 360 * el._spin : 0)}deg) rotateZ(${spin ? rnd(-12, 12) : 0}deg)`;
  }

  function buildGame() {
    const st = App.view;
    $('#screen').innerHTML = `<div class="game">
      <div class="board-area" id="boardArea"><div class="board" id="board">
        ${C.BOARD.map((_, i) => { const [r, c] = gridPos(i); return `<div class="tile ${i % 8 === 0 ? 'corner' : ''}" data-i="${i}" style="grid-row:${r};grid-column:${c}"></div>`; }).join('')}
        <div class="center" id="center">
          <div class="wordmark">THE CHAOS CLUB</div>
          <div class="c-top"><span class="pill" id="roundPill"></span><span class="pill twist" id="twistPill" hidden></span></div>
          <div class="decks"><div class="deck chaos">🌀</div><div class="deck surprise">🎁</div></div>
          <div class="dice-tray" id="dice">${dieHTML(1)}${dieHTML(1)}</div>
          <div class="turn-pill" id="turnPill"></div>
          <div class="c-bottom"><div class="meter" id="meter"><div class="mlabel"><span>💥 ${te('game.meter')}</span><span id="meterPct"></span></div><div class="bar"><i></i></div></div>
            <div class="pot" id="pot" title="${te('game.pot')}">🍲 <span></span></div></div>
          <div class="skip-hint">⏩ ${te('game.skipAnim')}</div>
        </div>
        <div class="tokens" id="tokens"></div>
      </div></div>
      <aside class="sidebar"><div class="players" id="players"></div><div class="action glass" id="action"></div>
        <div class="emotes" id="emotes" title="${te('game.emotes')}">${EMOTES.map((e) => `<button data-e="${e}">${e}</button>`).join('')}</div>
        <div class="log glass"><div class="label">${te('game.log')}</div><div class="log-list" id="log"></div></div></aside></div>`;
    const board = $('#board');
    tileEls = $$('.tile', board).sort((a, b) => a.dataset.i - b.dataset.i);
    tokenEls = {}; animating = new Set();
    if (st) st.players.forEach((p) => {
      const el = document.createElement('div');
      el.className = 'token'; el.style.setProperty('--c', p.color); el.style.setProperty('--delay', (-Math.random() * 2.4).toFixed(2) + 's');
      el.innerHTML = `<div class="tk-shield"></div><div class="tk-body">${emo(p.avatar)}</div><div class="tk-zzz">💤</div>`;
      $('#tokens').appendChild(el); tokenEls[p.id] = el;
    });
    $$('#dice .die').forEach((d) => setDie(d, 1, false));
    if (boardRO) boardRO.disconnect();
    boardRO = new ResizeObserver(() => { sizeTokens(); if (App.view) placeTokens(App.view, true); });
    boardRO.observe(board);
    // tooltips
    tileEls.forEach((el, i) => {
      el.addEventListener('mouseenter', (e) => showTip(i, e));
      el.addEventListener('mousemove', moveTip);
      el.addEventListener('mouseleave', hideTip);
      el.addEventListener('click', (e) => { if (!App.playing) { showTip(i, e); setTimeout(hideTip, 2600); } });
    });
    $('#boardArea').addEventListener('click', () => { if (App.playing && !App.fast) { App.fast = true; FX.speed = 0.18; } });
    $$('#emotes button').forEach((b) => { b.onclick = () => sendEmote(b.dataset.e); });
    renderLog(); sizeTokens();
  }
  function sizeTokens() {
    if (!tileEls[1]) return;
    const b = tileEls[1];
    App.tk = Math.max(16, Math.min(46, Math.round(Math.min(b.offsetWidth, b.offsetHeight) * 0.6)));
    $('#board').style.setProperty('--tk', App.tk + 'px');
  }
  function tileBox(i) { const el = tileEls[i]; return { x: el.offsetLeft, y: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight }; }
  function spotXY(i) { const b = tileBox(i); return { x: b.x + b.w / 2 - App.tk / 2, y: b.y + b.h / 2 - App.tk / 2 + b.h * 0.1 }; }
  function tokenXY(st, pid, i) {
    const b = tileBox(i); const s = spotXY(i);
    const here = st.players.filter((p) => !p.out && !p.abducted && p.pos === i).map((p) => p.id);
    const k = here.indexOf(pid);
    if (here.length > 1 && k >= 0) { const o = [[-1, -1], [1, -1], [-1, 1], [1, 1]][k]; s.x += o[0] * b.w * 0.2; s.y += o[1] * b.h * 0.15; }
    return s;
  }
  function setXY(el, p) { el._x = p.x; el._y = p.y; el.style.transform = `translate(${p.x}px, ${p.y}px)`; }
  function placeTokens(st, instant) {
    st.players.forEach((p) => {
      const el = tokenEls[p.id]; if (!el || animating.has(p.id)) return;
      if (instant) el.style.transition = 'none';
      setXY(el, tokenXY(st, p.id, p.pos));
      if (instant) { void el.offsetWidth; el.style.transition = ''; }
    });
  }
  function anchor(pid) {
    const el = tokenEls[pid], st = App.view;
    if (el && st && !st.players[pid].out && !st.players[pid].abducted && !el.classList.contains('hidden')) return FX.center(el);
    const card = $(`.pl[data-pid="${pid}"] .av`);
    return card ? FX.center(card) : { x: innerWidth / 2, y: innerHeight / 2, w: 0, h: 0 };
  }
  const tileC = (i) => FX.center(tileEls[i]);

  function tileInner(i, st) {
    const tl = st.tiles[i];
    let foot = '';
    if (tl.t === 'prop') {
      if (tl.owner !== null) { const o = st.players[tl.owner]; foot = `<span class="owner-chip">${emo(o.avatar)}</span>${tl.level ? `<span class="stars">${'★'.repeat(tl.level)}</span>` : ''}`; }
      else foot = `🪙${num(tl.price)}`;
    } else if (tl.t === 'tax') foot = `−${num(tl.amt)}`;
    else if (tl.t === 'pot') foot = `🪙${num(st.pot)}`;
    let over = '';
    if (tl.crater) over += '<div class="over crater"></div>';
    if (tl.bomb) over += `<div class="over bomb">💣<b>${tl.bomb}</b></div>`;
    if (tl.chicken) over += '<div class="over"><span class="chick">🐔</span></div>';
    const pile = tl.piles.reduce((s, p) => s + p.v, 0);
    if (pile) over += `<div class="piles"><i>${tl.piles.some((p) => p.k === 'egg') ? '🥚' : '🪙'}</i>${num(pile)}</div>`;
    return `${tl.t === 'prop' ? '<div class="strip"></div>' : ''}<div class="ticon">${tileIcon(tl)}</div><div class="tname">${esc(tileName(tl))}</div><div class="tfoot">${foot}</div>${over}`;
  }

  function renderState(st) {
    if (!st || App.screen !== 'game' || !tileEls.length) return;
    const board = $('#board');
    const tw = st.twist ? st.twist.id : null;
    board.className = 'board' + (tw ? ' ' + ({ gravity: 'gravity', moonwalk: 'moonwalk', discoNight: 'disco', chaosMode: 'chaos-mode', rentFreeze: 'frozen', slippery: 'slippery' }[tw] || '') : '');
    st.tiles.forEach((tl, i) => {
      const el = tileEls[i]; const html = tileInner(i, st);
      if (el._html !== html) { el.innerHTML = html; el._html = html; }
      const keep = ['spot', 'flash', 'landed'].filter((c) => el.classList.contains(c)).map((c) => ' ' + c).join('');
      el.className = `tile t-${tl.t}${i % 8 === 0 ? ' corner' : ''}${tl.owner !== null ? ' owned' : ''}${keep}`;
      el.style.setProperty('--g', tl.g ? C.GROUPS[tl.g] : 'transparent');
      if (tl.owner !== null) el.style.setProperty('--oc', st.players[tl.owner].color);
    });
    // center
    const actor = Eng.actorOf(st);
    const cur = st.players[st.order[st.turn]];
    $('#roundPill').textContent = st.phase === 'over' ? t('log.gameOver') : (st.round >= st.maxRounds ? '🔥 ' + t('game.lastRound') : t('game.round', { n: st.round, m: st.maxRounds }));
    $('#roundPill').classList.toggle('final', st.round >= st.maxRounds);
    const tp = $('#twistPill'); tp.hidden = !tw; if (tw) tp.textContent = C.TWISTS[tw].icon + ' ' + t('twist.' + tw + '.t');
    const shown = st.phase === 'auction' && actor != null ? st.players[actor] : cur;
    const turnHtml = `<span class="av" style="--c:${shown.color}">${emo(shown.avatar)}</span><span>${te('game.turnOf', { name: nameOf(shown) })}</span>`;
    const pill = $('#turnPill');
    if (pill._html !== turnHtml) { pill.innerHTML = turnHtml; pill._html = turnHtml; pill.classList.remove('pop'); void pill.offsetWidth; pill.classList.add('pop'); }
    $('#meter .bar i').style.width = st.meter + '%';
    $('#meterPct').textContent = num(st.meter) + '%';
    $('#meter').classList.toggle('hot', st.meter >= 75);
    $('#pot span').textContent = num(st.pot);
    // tokens
    st.players.forEach((p) => {
      const el = tokenEls[p.id]; if (!el) return;
      el.classList.toggle('current', p.id === cur.id && st.phase !== 'over');
      el.classList.toggle('giant', p.giant > 0);
      el.classList.toggle('shield', p.shield);
      el.classList.toggle('napping', p.skip > 0 && !p.abducted);
      el.classList.toggle('hidden', p.abducted);
      el.classList.toggle('out', p.out);
    });
    placeTokens(st);
    renderPlayers(st);
    renderAction(st);
    updateTitle();
  }

  function renderPlayers(st) {
    const box = $('#players'); if (!box) return;
    const order = st.order.join(',');
    if (box._order !== order) {
      box._order = order;
      box.innerHTML = st.order.map((id) => { const p = st.players[id]; return `<div class="pl" data-pid="${id}" style="--c:${p.color}"><div class="av">${emo(p.avatar)}</div><div class="nm"></div><div class="coins"></div><div class="sub"></div><div class="tags"></div></div>`; }).join('');
    }
    const info = Eng.info(st);
    const cur = st.players[st.order[st.turn]].id;
    st.order.forEach((id) => {
      const p = st.players[id]; const el = $(`.pl[data-pid="${id}"]`, box); if (!el) return;
      el.classList.toggle('current', id === cur && st.phase !== 'over');
      el.classList.toggle('out', p.out);
      const you = App.mode === 'online' && id === App.me ? ` <small>(${te('game.you')})</small>` : '';
      const offline = App.mode === 'online' && App.room && App.room.players[id] && !App.room.players[id].online;
      el.querySelector('.nm').innerHTML = esc(nameOf(p)) + you;
      tweenCoins(el.querySelector('.coins'), p.coins);
      const props = st.tiles.filter((x) => x.owner === id);
      el.querySelector('.sub').innerHTML = `<span>${te('game.worth', { n: info.netWorth[id] })}</span><span class="sets">${props.map((x) => `<i style="--g:${C.GROUPS[x.g]}"></i>`).join('')}</span>`;
      const tags = [];
      if (p.out) tags.push(`<span class="tag out">${te('game.outTag')}</span>`);
      if (p.abducted) tags.push(`<span class="tag ufo">🛸 ${te('game.ufoTag')}</span>`);
      else if (p.skip > 0) tags.push(`<span class="tag nap">💤 ${te('game.skipTag')}</span>`);
      if (p.giant) tags.push(`<span class="tag giant">🍄 ${te('game.giantTag')}</span>`);
      if (p.shield) tags.push(`<span class="tag shield">🫧 ${te('game.shieldTag')}</span>`);
      if (p.bot) tags.push('<span class="tag bot">🤖</span>');
      if (offline) tags.push(`<span class="tag">📴 ${te('online.offline')}</span>`);
      el.querySelector('.tags').innerHTML = tags.join('');
    });
  }
  function tweenCoins(el, value) {
    if (el._v == null) { el._v = value; el.textContent = '🪙 ' + num(value); return; }
    if (el._target === value) return;
    const from = el._shown != null ? el._shown : el._v; el._target = value;
    const t0 = performance.now(), dur = 700;
    el.classList.remove('up', 'down'); el.classList.add(value > from ? 'up' : 'down');
    cancelAnimationFrame(el._raf);
    const step = (now) => {
      const k = Math.min(1, (now - t0) / dur); const e = 1 - Math.pow(1 - k, 3);
      el._shown = Math.round(from + (value - from) * e); el.textContent = '🪙 ' + num(el._shown);
      if (k < 1) el._raf = requestAnimationFrame(step); else { el._v = value; el._shown = null; setTimeout(() => el.classList.remove('up', 'down'), 500); }
    };
    el._raf = requestAnimationFrame(step);
  }

  function canControl(pid) {
    if (pid == null || !App.view) return false;
    if (App.mode === 'local') return !App.view.players[pid].bot;
    return pid === App.me;
  }
  function renderAction(st) {
    const el = $('#action'); if (!el) return;
    const actor = Eng.actorOf(st);
    const busy = App.playing || App.sending;
    if (st.phase === 'over') { el.innerHTML = `<div class="waiting">🏁 ${te('log.gameOver')}</div><button class="btn" data-results>🏆 ${te('over.sub')}</button>`; $('[data-results]', el).onclick = () => showGameOver(st, true); return; }
    if (actor == null || (busy && !canControl(actor))) {
      const c = actor != null ? st.players[actor] : st.players[st.order[st.turn]];
      el.innerHTML = `<div class="ah"><span class="av" style="--c:${c.color}">${emo(c.avatar)}</span><span>${te('game.turnOf', { name: nameOf(c) })}</span></div><div class="waiting"><span class="spin"></span></div>`;
      return;
    }
    const p = st.players[actor];
    const head = `<div class="ah"><span class="av" style="--c:${p.color}">${emo(p.avatar)}</span><span>${App.mode === 'online' && actor === App.me ? te('game.yourTurn') : te(st.phase === 'auction' ? 'game.bidder' : 'game.turnOf', { name: nameOf(p) })}</span></div>`;
    if (!canControl(actor)) {
      el.innerHTML = head + `<div class="waiting">${p.bot ? '<span class="spin"></span> ' + te('game.thinking', { name: nameOf(p) }) : te('game.waitFor', { name: nameOf(p) })}</div>`;
      return;
    }
    const dis = busy ? 'disabled' : '';
    let body = '';
    const offer = (i, sub) => { const tl = st.tiles[i]; return `<div class="offer" style="--g:${C.GROUPS[tl.g] || 'transparent'}"><span class="oi">${tileIcon(tl)}</span><div><b>${esc(tileName(tl))}</b><span>${sub}</span></div></div>`; };
    const info = Eng.info(st);
    if (st.phase === 'roll') body = `<button class="btn huge primary" data-a="roll" ${dis}>🎲 ${te('game.roll')}</button>`;
    else if (st.phase === 'buy') {
      const i = st.pending.tile;
      body = `<div class="label" style="margin:0">${te('game.buyTitle', { tile: tileName(st.tiles[i]) })}</div>${offer(i, te('game.rent', { n: info.rentBase(i) }) + ' · ' + te('info.prop'))}
        <div class="row"><button class="btn big green" data-a="buy" ${dis}>🪙 ${te('game.buy', { n: st.pending.price })}</button><button class="btn big" data-a="skip" ${dis}>${te('game.pass')}</button></div>`;
    } else if (st.phase === 'upgrade') {
      const i = st.pending.tile, tl = st.tiles[i];
      const now = info.rentOf(i); const after = Math.round((now * [1, 3, 6, 10][tl.level + 1]) / [1, 3, 6, 10][tl.level] / 5) * 5;
      body = `<div class="label" style="margin:0">${te('game.upgradeTitle', { tile: tileName(tl) })}</div>${offer(i, '★'.repeat(tl.level) + '☆'.repeat(3 - tl.level) + ' · ' + te('game.rentInfo', { a: now, b: after }))}
        <div class="row"><button class="btn big green" data-a="buy" ${dis}>⭐ ${te('game.upgrade', { n: st.pending.price })}</button><button class="btn big" data-a="skip" ${dis}>${te('game.pass')}</button></div>`;
    } else if (st.phase === 'guess') {
      body = `<div class="guess-base"><div class="dice-tray" style="height:auto;width:auto">${dieHTML(st.pending.base, 'small')}</div><span>${te('game.guessPrompt', { n: st.pending.base })}</span></div>
        <div class="small-note" style="text-align:center">${te('game.guessRules')}</div>
        <div class="row"><button class="btn big" data-a="high" ${dis}>⬆️ ${te('game.higher')}</button><button class="btn big" data-a="low" ${dis}>⬇️ ${te('game.lower')}</button></div>`;
    } else if (st.phase === 'auction') {
      const A = st.auction; const first = A.leader === null;
      body = `<div class="label" style="margin:0">🔔 ${te('game.auctionTitle')}</div>${offer(A.tile, te('game.forSale', { n: st.tiles[A.tile].price }))}
        <div class="bid-big">🪙 ${num(A.bid)}</div><div class="small-note" style="text-align:center">${first ? te('game.startBid', { n: A.bid }) : te('game.leader', { name: nameOf(st.players[A.leader]) })} · ${te('game.coins')}: ${num(p.coins)}</div>
        <div class="row">${first ? `<button class="btn big green" data-a="bid0" ${dis || (p.coins < A.bid ? 'disabled' : '')}>${te('game.bid', { n: A.bid })}</button>`
          : [10, 50, 100].map((inc) => `<button class="btn big green" data-a="bid${inc}" ${dis || (p.coins < A.bid + inc ? 'disabled' : '')}>${te('game.raise', { n: inc })}</button>`).join('')}
        <button class="btn big" data-a="pass" ${dis}>${te('game.auctionPass')}</button></div>`;
    }
    el.innerHTML = head + body;
    $$('[data-a]', el).forEach((b) => {
      b.onclick = () => {
        Sound.play('click');
        const a = b.dataset.a;
        if (a === 'roll') doAction({ type: 'roll' });
        else if (a === 'buy') doAction({ type: 'buy' });
        else if (a === 'skip') doAction({ type: 'skip' });
        else if (a === 'high' || a === 'low') doAction({ type: 'guess', pick: a });
        else if (a === 'pass') doAction({ type: 'pass' });
        else if (a.startsWith('bid')) doAction({ type: 'bid', inc: +a.slice(3) });
      };
    });
  }

  function doAction(a) {
    if (!a || App.playing || !App.view) return;
    Sound.unlock();
    if (App.mode === 'local') {
      const actor = Eng.actorOf(App.game);
      const r = Eng.applyAction(App.game, actor, a);
      if (r.ok) enqueue(r.events); else console.warn('Rejected action', a, r);
    } else if (App.mode === 'online') {
      if (App.sending) return;
      App.sending = true; renderAction(App.view);
      if (!Net.send({ t: 'act', action: a })) { App.sending = false; toast('📴', t('online.disconnected')); }
      clearTimeout(App.sendTimer);
      App.sendTimer = setTimeout(() => { App.sending = false; if (App.view) renderAction(App.view); }, 8000);
    }
  }

  // ---------------------------------------------------------------- log
  const logHTML = (x) => `<i>${x.icon}</i><span>${te(x.k, x.v)}${x.k2 ? ' ' + te(x.k2, x.v2 || x.v) : ''}</span>`;
  function addLog(icon, k, v, k2, v2) {
    const x = { icon, k, v, k2, v2 };
    App.log.unshift(x);
    if (App.log.length > 80) App.log.pop();
    const el = $('#log'); if (!el) return;
    const d = document.createElement('div'); d.className = 'log-item new'; d.innerHTML = logHTML(x);
    el.prepend(d); el.scrollTop = 0;
    while (el.children.length > 80) el.lastChild.remove();
  }
  function renderLog() {
    const el = $('#log'); if (!el) return;
    el.innerHTML = App.log.map((x) => `<div class="log-item">${logHTML(x)}</div>`).join('');
  }

  // ---------------------------------------------------------------- event playback
  function enqueue(events) {
    App.queue.push(...events);
    if (!App.playing) runQueue();
  }
  async function runQueue() {
    App.playing = true;
    $('#boardArea') && $('#boardArea').classList.add('playing');
    if (App.view) renderAction(App.view);
    while (App.queue.length) {
      const e = App.queue.shift();
      try { await animate(e); } catch (err) { console.error('animation error', e.type, err); }
      App.view = e.s;
      renderState(e.s);
    }
    App.playing = false; App.fast = false; FX.speed = SPEEDS[Settings.speed] || 1;
    $('#boardArea') && $('#boardArea').classList.remove('playing');
    if (App.view) renderState(App.view);
    afterQueue();
  }
  function afterQueue() {
    const st = App.view; if (!st) return;
    if (st.phase === 'over') { if (!App.overShown) { App.overShown = true; setTimeout(() => showGameOver(st), FX.ms(400)); } return; }
    if (App.mode === 'local') {
      const a = Eng.actorOf(App.game);
      if (a != null && App.game.players[a].bot) {
        clearTimeout(App.botTimer);
        App.botTimer = setTimeout(() => { if (App.mode === 'local' && !App.playing && App.game && Eng.actorOf(App.game) === a) doAction(Eng.botAction(App.game)); }, FX.ms(App.game.phase === 'roll' ? 750 : 1100));
      }
    }
  }

  function react(pid, kind) {
    const el = tokenEls[pid]; if (!el || !App.view || App.view.players[pid].out) return;
    const cls = { gain: 'celebrate', loss: 'sad', confused: 'confused' }[kind] || kind;
    el.classList.remove('celebrate', 'sad', 'confused'); void el.offsetWidth; el.classList.add(cls);
    setTimeout(() => el.classList.remove(cls), 1000);
    const n = { gain: 4, loss: 4, confused: 3, idle: 5, meet: 3 }[kind];
    if (n && Math.random() < 0.7) FX.bubble(el, esc(I18N.t('react.' + kind + '.' + rnd(1, n))));
  }
  function tokenClass(pid, cls, ms) { const el = tokenEls[pid]; if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), ms || 1000); }
  function flashTile(i, cls) { const el = tileEls[i]; if (!el) return; cls = cls || 'flash'; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), 2500); }
  function shakeBoard(p, d) { return FX.shake($('#board'), p, d); }
  function overlay(html, cls) {
    const o = document.createElement('div'); o.className = 'board-overlay ' + (cls || ''); o.innerHTML = html;
    $('#boardArea').appendChild(o); return o;
  }
  function holdOrClick(node, ms) {
    return new Promise((resolve) => {
      let done = false; const fin = () => { if (done) return; done = true; resolve(); };
      setTimeout(fin, FX.ms(ms)); node.addEventListener('click', (e) => { e.stopPropagation(); fin(); });
    });
  }
  async function showBanner(o) {
    if (!$('#boardArea')) return;
    const ov = overlay(`<div class="banner ${o.kind || ''}"><div class="bl">${esc(o.label || '')}</div><div class="bi">${o.icon || ''}</div><h3>${esc(o.title)}</h3>${o.desc ? `<p>${esc(o.desc)}</p>` : ''}</div>`);
    await holdOrClick(ov, o.ms || 2600);
    ov.firstChild.classList.add('out'); await FX.wait(260); ov.remove();
  }
  async function miniToast(html, ms) {
    if (!$('#boardArea')) return;
    const d = document.createElement('div'); d.className = 'mini-toast'; d.innerHTML = html; $('#boardArea').appendChild(d);
    await FX.wait(ms || 1500); d.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 250, fill: 'forwards' }).finished.then(() => d.remove());
  }

  async function rollDiceAnim(values) {
    const tray = $('#dice'); if (!tray) return;
    if (tray.children.length !== values.length) { tray.innerHTML = values.map(() => dieHTML(1)).join(''); $$('.die', tray).forEach((d) => setDie(d, 1, false)); void tray.offsetWidth; }
    Sound.play('dice');
    $$('.die', tray).forEach((d, i) => { d.style.transition = `transform ${FX.ms(1000)}ms cubic-bezier(.2,.7,.2,1)`; setDie(d, values[i], true); });
    await FX.wait(1000); Sound.play('diceLand');
  }

  async function animMove(e) {
    const el = tokenEls[e.pid]; if (!el || !tileEls.length) return;
    const path = e.path, kind = e.kind;
    if (path.length < 2 || (path[0] === path[path.length - 1] && path.length === 2)) return;
    animating.add(e.pid); el.style.transition = 'none';
    const tk = App.tk;
    try {
      if (['walk', 'slide', 'float', 'quake', 'blast'].includes(kind)) {
        const stepMs = { walk: 165, slide: 230, float: 330, quake: 230, blast: 120 }[kind];
        const hop = kind === 'slide' ? 0 : kind === 'float' ? tk * 0.2 : kind === 'blast' ? tk * 0.9 : tk * 0.45;
        for (let k = 1; k < path.length; k++) {
          const a = { x: el._x, y: el._y }, b = spotXY(path[k]);
          await el.animate([{ transform: `translate(${a.x}px,${a.y}px)` }, { transform: `translate(${(a.x + b.x) / 2}px,${(a.y + b.y) / 2 - hop}px) scale(1.1) rotate(${kind === 'blast' ? 180 : 0}deg)` }, { transform: `translate(${b.x}px,${b.y}px) rotate(${kind === 'blast' ? 360 : 0}deg)` }], { duration: FX.ms(stepMs), easing: 'ease-in-out' }).finished;
          setXY(el, b);
          if (kind !== 'float') Sound.play('step');
        }
        flashTile(path[path.length - 1], 'landed');
      } else {
        const a = { x: el._x, y: el._y }, b = spotXY(path[path.length - 1]);
        let frames, dur = 700;
        if (kind === 'warp') {
          Sound.play('warp');
          frames = [{ transform: `translate(${a.x}px,${a.y}px) scale(1) rotate(0)`, opacity: 1 }, { transform: `translate(${a.x}px,${a.y}px) scale(0) rotate(540deg)`, opacity: 0, offset: 0.45 }, { transform: `translate(${b.x}px,${b.y}px) scale(0) rotate(0)`, opacity: 0, offset: 0.55 }, { transform: `translate(${b.x}px,${b.y}px) scale(1) rotate(720deg)`, opacity: 1 }];
          dur = 900;
        } else {
          const lift = kind === 'tornado' ? 260 : kind === 'swap' ? 90 : 160;
          const spin = kind === 'tornado' ? 1080 : kind === 'swap' ? 360 : 0;
          Sound.play('whoosh');
          frames = [{ transform: `translate(${a.x}px,${a.y}px) rotate(0)` }, { transform: `translate(${(a.x + b.x) / 2}px,${Math.min(a.y, b.y) - lift}px) scale(1.35) rotate(${spin / 2}deg)` }, { transform: `translate(${b.x}px,${b.y}px) rotate(${spin}deg)` }];
          dur = kind === 'tornado' ? 1100 : 800;
        }
        await el.animate(frames, { duration: FX.ms(dur), easing: 'ease-in-out' }).finished;
        setXY(el, b);
        flashTile(path[path.length - 1], 'landed');
        if (kind === 'nap') Sound.play('snore');
      }
    } finally {
      animating.delete(e.pid);
      void el.offsetWidth; el.style.transition = '';
    }
  }

  async function animMoney(e) {
    const st = e.s; const pid = e.pid; const d = e.delta;
    if (st.players[pid] && st.players[pid].out && d === 0) return;
    const tgt = anchor(pid);
    if (e.why === 'pile' || e.why === 'egg') { if (e.tile != null) await FX.coinsFly(tileC(e.tile), tgt, e.why === 'egg' ? 3 : 5); }
    if (d < 0 && typeof e.to === 'number') await FX.coinsFly(tgt, anchor(e.to), Math.min(9, 3 + Math.round(-d / 40)));
    if (d < 0 && e.to === 'pot' && $('#pot')) { FX.coinsFly(tgt, FX.center($('#pot')), Math.min(6, 2 + Math.round(-d / 50))); setTimeout(() => { const p = $('#pot'); if (p) { p.classList.remove('glow'); void p.offsetWidth; p.classList.add('glow'); } }, FX.ms(600)); }
    if (d !== 0) FX.floatText(tgt.x, tgt.y - 18, (d > 0 ? '+' : '−') + num(Math.abs(d)), d > 0 ? '#5BE584' : '#FF6B62');
    if (d > 0) {
      Sound.play(d >= 150 ? 'bigCoin' : 'coin');
      if (d >= 100) FX.burst(tgt.x, tgt.y, { count: 14, kind: 'text', text: '🪙', size: 16, speed: 5, up: 4, life: 900 });
      if (d >= 80 && e.why !== 'transfer') react(pid, 'gain');
    } else if (d < 0) {
      Sound.play('lose');
      if (d <= -60) react(pid, 'loss');
    }
    if (d) await FX.wait(e.why === 'passStart' ? 420 : 360);
  }

  async function showCard(e) {
    if (!$('#boardArea')) return;
    const deck = e.deck;
    Sound.play('card');
    const ov = overlay(`<div class="event-card ${deck}"><div class="inner"><div class="side front"><div class="cl">${te('deck.' + deck).toUpperCase()}</div><div class="ci">${CARD_ICONS[e.card] || '🃏'}</div><p>${te('card.' + e.card)}</p><small>${esc(pname(e.pid))}</small></div><div class="side back">${deck === 'chaos' ? '🌀' : '🎁'}</div></div></div>`);
    await holdOrClick(ov, 3300);
    ov.firstChild.classList.add('out'); await FX.wait(280); ov.remove();
    const f = e.fx || {};
    if (f.money < 0 || f.each < 0 || f.perProp) react(e.pid, 'loss'); else if (f.nap || f.swap || f.randomTile) react(e.pid, 'confused');
  }

  async function warning() {
    if (!$('#boardArea')) return;
    Sound.play('alarm');
    const siren = document.createElement('div'); siren.className = 'siren'; $('#board').appendChild(siren);
    const ov = overlay(`<div class="warning"><span>⚠️ ${te('chaos.warning')} ⚠️</span></div>`);
    ov.style.pointerEvents = 'none';
    await FX.wait(1250);
    ov.remove(); siren.remove();
  }

  // ---------- chaos visuals ----------
  function hammerSwing(p) {
    const h = FX.el('🔨', 'fx-emoji', { fontSize: '96px', transformOrigin: '80% 80%' });
    const a = h.animate([
      { transform: `translate(${p.x - 10}px, ${p.y - 150}px) translate(-50%,-50%) rotate(-80deg) scale(.6)`, opacity: 0 },
      { transform: `translate(${p.x - 10}px, ${p.y - 110}px) translate(-50%,-50%) rotate(-95deg) scale(1)`, opacity: 1, offset: 0.4 },
      { transform: `translate(${p.x - 20}px, ${p.y - 40}px) translate(-50%,-50%) rotate(20deg) scale(1.05)`, offset: 0.62 },
      { transform: `translate(${p.x - 20}px, ${p.y - 46}px) translate(-50%,-50%) rotate(10deg) scale(1)`, offset: 0.8 },
      { transform: `translate(${p.x - 20}px, ${p.y - 46}px) translate(-50%,-50%) rotate(10deg) scale(1)`, opacity: 0 },
    ], { duration: FX.ms(1300), easing: 'ease-in', fill: 'forwards' });
    setTimeout(() => { Sound.play('bonk'); FX.burst(p.x, p.y, { count: 8, kind: 'text', text: ['⭐', '💫'], size: 22, speed: 6, g: 0.1, life: 900 }); FX.comic(p.x, p.y - 30, 'BONK!', '#FFD60A'); shakeBoard(8, 400); }, FX.ms(800));
    return a.finished.then(() => h.remove());
  }

  const VISUAL = {
    async meteor(e) {
      const p = tileC(e.tile); Sound.play('whistle');
      await FX.fly('☄️', { x: innerWidth + 80, y: -80 }, p, { size: 76, arc: 0, dur: 950, easing: 'cubic-bezier(.55,0,1,.45)', s0: 0.5, s1: 1.4, spin: -20 });
      FX.explode(p, true); shakeBoard(18, 900); flashTile(e.tile);
      (e.pids || []).forEach((id) => tokenClass(id, 'squash'));
      await FX.wait(700);
    },
    async coinBlast(e) {
      const p = tileC(e.tile);
      FX.shake(tileEls[e.tile], 7, 700); Sound.play('tick'); await FX.wait(650);
      FX.explode(p, false); Sound.play('bigCoin'); shakeBoard(8, 400);
      await Promise.all(e.piles.map((pl, k) => FX.wait(k * 70).then(() => FX.fly('🪙', p, tileC(pl.tile), { size: 26, arc: -150 - Math.random() * 90, dur: 850, spin: 720 }))));
    },
    async hammer(e) {
      const visible = App.view && !App.view.players[e.pid].abducted;
      const p = e.down || !visible ? tileC(e.tile) : anchor(e.pid);
      const swing = hammerSwing(p);
      setTimeout(() => { if (e.down) flashTile(e.tile); else tokenClass(e.pid, 'squash', 1100); }, FX.ms(800));
      await swing;
    },
    async quake() {
      Sound.play('rumble');
      Object.keys(tokenEls).forEach((id) => tokenClass(+id, 'confused', 1200));
      for (let k = 0; k < 6; k++) setTimeout(() => { const c = tileC(rnd(0, 31)); FX.smoke(c.x, c.y, 5); }, FX.ms(k * 180));
      await shakeBoard(24, 1500);
    },
    async ufo(e) {
      const tok = tokenEls[e.pid]; const p = anchor(e.pid); const above = { x: p.x, y: p.y - 120 };
      Sound.play('ufo');
      const u = FX.el('🛸', 'fx-emoji', { fontSize: '84px' });
      await u.animate([{ transform: `translate(-120px, ${above.y - 120}px) translate(-50%,-50%) rotate(-20deg)` }, { transform: `translate(${above.x}px, ${above.y}px) translate(-50%,-50%) rotate(0)` }], { duration: FX.ms(1000), easing: 'cubic-bezier(.2,.8,.2,1)', fill: 'forwards' }).finished;
      const beam = FX.el('', 'fx-beam', { left: (p.x - 35) + 'px', top: (above.y + 14) + 'px', height: (p.y - above.y + 10) + 'px', transformOrigin: 'top' });
      beam.animate([{ opacity: 0, transform: 'scaleY(0)' }, { opacity: 1, transform: 'scaleY(1)' }], { duration: FX.ms(300), fill: 'forwards' });
      if (tok) {
        animating.add(e.pid); tok.style.transition = 'none';
        const lift = tok.animate([{ transform: `translate(${tok._x}px,${tok._y}px)` }, { transform: `translate(${tok._x}px,${tok._y - (p.y - above.y) + 10}px) scale(.15) rotate(360deg)`, opacity: 0 }], { duration: FX.ms(1100), easing: 'ease-in', fill: 'forwards' });
        await lift.finished; tok.classList.add('hidden'); lift.cancel(); animating.delete(e.pid); tok.style.transition = '';
      }
      beam.remove();
      await u.animate([{ transform: `translate(${above.x}px, ${above.y}px) translate(-50%,-50%)` }, { transform: `translate(${above.x + 30}px, ${above.y - 30}px) translate(-50%,-50%) rotate(10deg)`, offset: 0.3 }, { transform: `translate(${innerWidth + 140}px, -140px) translate(-50%,-50%) rotate(25deg) scale(.6)` }], { duration: FX.ms(900), easing: 'ease-in', fill: 'forwards' }).finished;
      u.remove();
    },
    async chicken(e) {
      const idx = []; for (let k = 0; k <= 8; k++) idx.push((e.side * 8 + k) % 32);
      const pts = idx.map(tileC); const first = pts[0], last = pts[pts.length - 1];
      const ext = (a, b) => ({ x: a.x + (a.x - b.x) * 0.6, y: a.y + (a.y - b.y) * 0.6 });
      const all = [ext(first, pts[1])].concat(pts, [ext(last, pts[pts.length - 2])]);
      const flip = e.side === 2 ? -1 : 1;
      const ch = FX.el('🐔', 'fx-emoji', { fontSize: '104px' });
      const dur = FX.ms(2300);
      const anim = ch.animate(all.map((p, k) => ({ transform: `translate(${p.x}px,${p.y - 40 - (k % 2 ? 18 : 0)}px) translate(-50%,-60%) scaleX(${flip}) rotate(${k % 2 ? -8 : 8}deg)` })), { duration: dur, easing: 'linear', fill: 'forwards' });
      for (let k = 0; k < all.length; k++) setTimeout(() => { Sound.play('cluck'); const p = all[k]; FX.burst(p.x, p.y - 20, { count: 4, kind: 'text', text: '🪶', size: 16, speed: 3, g: 0.08, life: 1200 }); FX.shake($('#board'), 4, 150); }, (dur / all.length) * k);
      (e.pids || []).forEach((id, k) => setTimeout(() => tokenClass(id, 'squash'), dur * 0.4 + k * 100));
      await anim.finished; ch.remove();
      const ep = tileC(e.egg); Sound.play('pop');
      await FX.fly('🥚', { x: ep.x, y: ep.y - 120 }, ep, { size: 34, arc: 0, dur: 500, easing: 'ease-in' });
      FX.burst(ep.x, ep.y, { count: 14, colors: ['#FFD60A', '#fff'], size: 4, speed: 4, life: 700 });
    },
    async richAunt(e) {
      const p = anchor(e.pid);
      await FX.fly('👵', { x: -80, y: innerHeight * 0.45 }, { x: p.x - 50, y: p.y - 30 }, { size: 64, arc: -80, dur: 1000 });
      Sound.play('bigCoin');
      await FX.fly('💰', { x: p.x, y: p.y - 220 }, p, { size: 54, arc: 0, dur: 520, easing: 'ease-in' });
      FX.burst(p.x, p.y, { count: 24, kind: 'text', text: '🪙', size: 18, speed: 8, up: 5, life: 1200 });
      FX.comic(p.x, p.y - 40, 'KA-CHING!', '#32D74B'); tokenClass(e.pid, 'celebrate');
      await FX.wait(500);
    },
    async taxman(e) {
      const c = FX.center($('#center')); const y = c.y + c.h * 0.1;
      const w = FX.el('🤵', 'fx-emoji', { fontSize: '78px' });
      const frames = []; for (let k = 0; k <= 8; k++) frames.push({ transform: `translate(${c.x - c.w / 2 - 60 + ((c.w + 120) * k) / 8}px, ${y - (k % 2 ? 16 : 0)}px) translate(-50%,-50%) rotate(${k % 2 ? 6 : -6}deg)` });
      const a = w.animate(frames, { duration: FX.ms(1700), easing: 'linear', fill: 'forwards' });
      for (let k = 0; k < 8; k++) setTimeout(() => Sound.play('tick'), FX.ms(k * 210));
      setTimeout(() => FX.bubble(w, '🧾💼'), FX.ms(700));
      await a.finished; w.remove();
    },
    async tornado(e) {
      const b = FX.center($('#board'));
      const pts = [{ x: b.x - b.w / 2 - 60, y: b.y }].concat(e.pids.map((id) => anchor(id)), [{ x: b.x + b.w / 2 + 60, y: b.y - b.h * 0.2 }]);
      const tw = FX.el('🌪️', 'fx-emoji', { fontSize: '120px' });
      Sound.play('whoosh'); setTimeout(() => Sound.play('whoosh'), FX.ms(600));
      const a = tw.animate(pts.map((p, k) => ({ transform: `translate(${p.x}px,${p.y}px) translate(-50%,-75%) rotate(${k % 2 ? 10 : -10}deg) scale(${1 + k * 0.08})` })), { duration: FX.ms(1600), easing: 'ease-in-out', fill: 'forwards' });
      e.pids.forEach((id, k) => setTimeout(() => tokenClass(id, 'spin', 1000), FX.ms(300 + k * 400)));
      const dust = setInterval(() => { const r = tw.getBoundingClientRect(); FX.smoke(r.left + r.width / 2, r.bottom - 10, 2); }, 120);
      await a.finished; clearInterval(dust); tw.remove();
    },
    async bomb(e) {
      const p = tileC(e.tile); Sound.play('whistle');
      await FX.fly('💣', { x: p.x + 40, y: -90 }, p, { size: 60, arc: 0, dur: 950, easing: 'cubic-bezier(.55,0,1,.45)', spin: 360 });
      Sound.play('bonk'); shakeBoard(6, 300); flashTile(e.tile);
      FX.comic(p.x, p.y - 30, '!!!', '#FF453A');
      for (let k = 0; k < 3; k++) setTimeout(() => Sound.play('tick'), FX.ms(300 + k * 260));
      await FX.wait(800);
    },
    async coinShower() {
      FX.rain(['🪙', '🪙', '🪙', '💰', '💎'], 80, FX.ms(1500));
      for (let k = 0; k < 4; k++) setTimeout(() => Sound.play('coin'), FX.ms(k * 350));
      await FX.wait(1700);
    },
    async giant(e) {
      const p = anchor(e.pid);
      await FX.fly('🍄', { x: p.x, y: p.y - 140 }, p, { size: 46, arc: 0, dur: 500 });
      Sound.play('grow'); tokenClass(e.pid, 'grow', 1200);
      FX.burst(p.x, p.y, { count: 20, colors: ['#FF453A', '#fff'], size: 5, speed: 6, life: 900 });
      await FX.wait(1100);
    },
    async millionaire(e) {
      const p = anchor(e.pid);
      FX.bubble(tokenEls[e.pid] || $('#board'), '📻🎉', { cls: 'emoji', dur: 2000 });
      FX.fireworks(5); Sound.play('fanfare'); tokenClass(e.pid, 'celebrate');
      FX.comic(p.x, p.y - 50, '+300!', '#32D74B');
      await FX.wait(1400);
    },
    async auction(e) {
      Sound.play('bell'); flashTile(e.tile, 'spot');
      const p = tileC(e.tile);
      await FX.fly('🔔', { x: p.x, y: p.y - 100 }, { x: p.x, y: p.y - 40 }, { size: 52, arc: -10, dur: 900, spin: 30 });
    },
    async transform(e) {
      const a = tileEls[e.a], b = tileEls[e.b]; Sound.play('whoosh');
      await Promise.all([a, b].map((el) => el.animate([{ transform: 'rotateY(0) scale(1)' }, { transform: 'rotateY(90deg) scale(1.2)' }], { duration: FX.ms(350), fill: 'forwards' }).finished));
      renderState(e.s);
      [a, b].forEach((el) => { const c = FX.center(el); FX.burst(c.x, c.y, { count: 14, kind: 'text', text: '✨', size: 14, speed: 4, life: 800 }); });
      await Promise.all([a, b].map((el) => el.animate([{ transform: 'rotateY(90deg) scale(1.2)' }, { transform: 'rotateY(0) scale(1)' }], { duration: FX.ms(450), easing: 'cubic-bezier(.34,1.56,.64,1)' }).finished));
      [a, b].forEach((el) => el.getAnimations().forEach((x) => x.cancel()));
      Sound.play('pop');
    },
    async gift(e) {
      const p = anchor(e.pid);
      const g = FX.el('<div style="text-align:center;line-height:.85">🪂<br>🎁</div>', 'fx-emoji', { fontSize: '46px' });
      Sound.play('whoosh');
      const frames = []; for (let k = 0; k <= 6; k++) frames.push({ transform: `translate(${p.x + (k % 2 ? 40 : -40) * (1 - k / 6)}px, ${-100 + ((p.y - 30 + 100) * k) / 6}px) translate(-50%,-100%) rotate(${k % 2 ? 10 : -10}deg)` });
      await g.animate(frames, { duration: FX.ms(1700), easing: 'ease-in-out', fill: 'forwards' }).finished; g.remove();
      Sound.play('pop');
      FX.burst(p.x, p.y, { count: 30, kind: 'confetti', size: 7, speed: 6, up: 3, life: 1100 });
      if (e.kind === 'bees') { FX.burst(p.x, p.y, { count: 14, kind: 'text', text: '🐝', size: 22, speed: 5, g: -0.02, life: 1600 }); Sound.play('rumble'); tokenClass(e.pid, 'sad'); }
      else if (e.kind === 'shield') FX.burst(p.x, p.y, { count: 12, kind: 'text', text: '🫧', size: 20, speed: 3, g: -0.05, life: 1400 });
      else FX.burst(p.x, p.y, { count: 18, kind: 'text', text: '🪙', size: 18, speed: 7, up: 4, life: 1200 });
      await miniToast(te('gift.' + e.kind), 1700);
    },
    async lightning(e) {
      const dim = FX.el('', 'fx-dim');
      dim.animate([{ opacity: 0 }, { opacity: 1 }], { duration: FX.ms(250), fill: 'forwards' });
      await FX.wait(300);
      const p = anchor(e.pid);
      FX.lightning(p); tokenClass(e.pid, 'zapped', 1000);
      setTimeout(() => { FX.smoke(p.x, p.y, 10); FX.burst(p.x, p.y, { count: 20, colors: ['#FFF7B0', '#fff'], size: 3, speed: 7, life: 500 }); }, FX.ms(150));
      await FX.wait(800);
      await dim.animate([{ opacity: 1 }, { opacity: 0 }], { duration: FX.ms(300), fill: 'forwards' }).finished; dim.remove();
    },
    async robinHood(e) {
      const a = anchor(e.from), b = anchor(e.to);
      Sound.play('whoosh');
      const ang = Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI;
      const arrow = FX.el('🏹', 'fx-emoji', { fontSize: '48px' });
      await arrow.animate([{ transform: `translate(${a.x}px,${a.y}px) translate(-50%,-50%) rotate(${ang + 45}deg)` }, { transform: `translate(${b.x}px,${b.y}px) translate(-50%,-50%) rotate(${ang + 45}deg)` }], { duration: FX.ms(700), easing: 'ease-in', fill: 'forwards' }).finished;
      arrow.remove(); FX.comic(a.x, a.y - 30, 'SWIPE!', '#32D74B'); tokenClass(e.from, 'sad'); tokenClass(e.to, 'celebrate');
    },
    async duckFlood() {
      Sound.play('quack');
      const water = FX.el('', 'fx-water', { top: 'auto' });
      water.animate([{ transform: 'translateY(100%)' }, { transform: 'translateY(0)' }], { duration: FX.ms(500), fill: 'forwards' });
      const ps = [];
      for (let k = 0; k < 28; k++) {
        const y = innerHeight * (0.55 + Math.random() * 0.4);
        ps.push(FX.wait(k * 50).then(() => FX.fly('🦆', { x: -50, y }, { x: innerWidth + 50, y: y - 20 }, { size: 22 + Math.random() * 20, arc: -10, dur: 1600 + Math.random() * 600 })));
      }
      setTimeout(() => Sound.play('quack'), FX.ms(700));
      await Promise.all(ps);
      await water.animate([{ opacity: 1 }, { opacity: 0 }], { duration: FX.ms(400), fill: 'forwards' }).finished; water.remove();
    },
  };

  async function fakeWin(e) {
    const p = e.s.players[e.pid];
    const o = document.createElement('div'); o.className = 'fakewin';
    o.innerHTML = `<div><div class="trophy">🏆</div><h2>${te('chaos.fakeWin.t', { name: nameOf(p) })}</h2><p>&nbsp;</p></div>`;
    document.body.appendChild(o);
    Sound.play('fanfare'); FX.confetti(); FX.fireworks(4);
    await FX.wait(Math.max(1800, FX.ms(2300)));
    Sound.play('scratch'); o.classList.add('kidding');
    $('.trophy', o).textContent = '🙃'; $('p', o).textContent = t('chaos.fakeWin.d');
    await FX.wait(Math.max(1600, FX.ms(2000)));
    o.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, fill: 'forwards' }).finished.then(() => o.remove());
  }

  async function playChaos(e) {
    const st = e.s; const id = e.id;
    const vars = { name: e.pid != null ? P(e.pid) : '', tile: e.tile != null ? T(st, e.tile) : '' };
    if (id === 'tornado') vars.names = e.pids.map((x) => nameOf(st.players[x])).join(' & ');
    if (id === 'transform') { vars.a = T(st, e.a); vars.b = T(st, e.b); }
    if (id === 'robinHood') { vars.from = P(e.from); vars.to = P(e.to); }
    const descKey = id === 'hammer' ? (e.down ? 'chaos.hammer.down' : 'chaos.hammer.bonk') : 'chaos.' + id + '.d';
    addLog(C.MAJOR[id].icon, 'chaos.' + id + '.t', vars, descKey, vars);
    if (id === 'fakeWin') return fakeWin(e);
    await warning();
    await showBanner({ label: t('chaos.label'), icon: C.MAJOR[id].icon, title: t('chaos.' + id + '.t', vars), desc: t(descKey, vars), kind: 'chaos' });
    if (VISUAL[id]) await VISUAL[id](e);
  }

  async function playTwist(e) {
    const id = e.id;
    addLog(C.TWISTS[id].icon, 'twist.' + id + '.t', null, 'twist.' + id + '.d');
    Sound.play('twist');
    await showBanner({ label: t('twist.label'), icon: C.TWISTS[id].icon, title: t('twist.' + id + '.t'), desc: t('twist.' + id + '.d'), kind: 'twist', ms: 2900 });
    const b = $('#board') ? FX.center($('#board')) : { x: innerWidth / 2, y: innerHeight / 2, w: 400, h: 400 };
    switch (id) {
      case 'doubleMoney': FX.rain('💸', 40, FX.ms(1200)); Sound.play('bigCoin'); break;
      case 'inflation': for (let k = 0; k < 14; k++) { const x = b.x - b.w / 2 + Math.random() * b.w; FX.wait(k * 70).then(() => FX.fly('🎈', { x, y: innerHeight + 40 }, { x: x + rnd(-60, 60), y: -60 }, { size: 34, arc: 0, dur: 1800 })); } break;
      case 'birthday': FX.rain(['🎂', '🎉', '🎈', '🥳'], 40, FX.ms(1200)); FX.confetti(b.x, b.y - b.h / 3); break;
      case 'rentFreeze': FX.rain('❄️', 50, FX.ms(1400)); break;
      case 'chickenInvasion': Sound.play('cluck'); setTimeout(() => Sound.play('cluck'), 400); break;
      case 'reverseDay': FX.comic(b.x, b.y, '🔄 !!!', '#64D2FF'); break;
      case 'turbo': FX.fly('🏎️', { x: -80, y: b.y }, { x: innerWidth + 80, y: b.y }, { size: 70, arc: 0, dur: 900 }); Sound.play('whoosh'); break;
      case 'discoNight': FX.burst(b.x, b.y, { count: 60, kind: 'confetti', speed: 9, size: 8, life: 1600 }); break;
      case 'mysteryBox': case 'groupHug': e.s.players.forEach((p) => { if (!p.out && tokenEls[p.id]) FX.bubble(tokenEls[p.id], id === 'groupHug' ? '🤗' : '📦', { cls: 'emoji' }); }); Sound.play('pop'); break;
      case 'gravity': Sound.play('warp'); break;
      case 'slippery': FX.rain('🫧', 30, FX.ms(1000)); break;
    }
    await FX.wait(600);
  }

  async function animate(e) {
    const st = e.s;
    const nm = e.pid != null ? P(e.pid) : null;
    switch (e.type) {
      case 'gameStart':
        addLog('🚀', 'log.start', { name: P(e.order[0]) });
        Sound.play('fanfare'); FX.confetti(null, innerHeight * 0.35, 80);
        await showBanner({ label: t('app.name').toUpperCase(), icon: '🐔', title: t('log.start', { name: P(e.order[0]) }), desc: e.order.map((id) => emo(st.players[id].avatar) + ' ' + nameOf(st.players[id])).join('  →  '), ms: 2600 });
        return;
      case 'turn': Sound.play('turn'); renderState(st); return FX.wait(250);
      case 'round':
        addLog('🔔', 'log.round', { n: e.round });
        if (e.last) { renderState(st); return showBanner({ label: t('game.round', { n: e.round, m: st.maxRounds }), icon: '🔥', title: t('game.lastRound'), ms: 1800 }); }
        return miniToast('🔔 ' + te('log.round', { n: e.round }), 1100);
      case 'dice': {
        await rollDiceAnim(e.dice);
        addLog('🎲', 'log.dice', { name: nm, dice: e.dice.join(' + '), n: Math.abs(e.steps) });
        if (e.doubles) { const c = FX.center($('#dice')); FX.comic(c.x, c.y - 50, 'DOUBLES!', '#64D2FF'); addLog('✨', 'log.doubles', { name: nm }); }
        return;
      }
      case 'move': return animMove(e);
      case 'money':
        if (e.why === 'passStart') addLog('🚀', 'log.passStart', { name: nm, n: e.delta });
        if (e.why === 'landStart') { addLog('🎯', 'log.landStart', { name: nm, n: e.delta }); FX.confetti(anchor(e.pid).x, anchor(e.pid).y, 50); }
        if (e.why === 'mini' && e.delta > 0) FX.confetti(anchor(e.pid).x, anchor(e.pid).y, 50);
        return animMoney(e);
      case 'card': addLog(CARD_ICONS[e.card] || '🃏', 'card.' + e.card); return showCard(e);
      case 'small': {
        addLog(SMALL_ICONS[e.id] || '✨', 'small.' + e.id, { name: nm });
        react(e.pid, 'confused');
        return miniToast(`${SMALL_ICONS[e.id] || '✨'} ${te('small.' + e.id, { name: nm })}`, 2000);
      }
      case 'chaos': return playChaos(e);
      case 'twist': return playTwist(e);
      case 'twistEnd': addLog('⏹', 'twist.ended', { title: I18N.t('twist.' + e.id + '.t') }); return;
      case 'offerBuy': case 'offerUpgrade': flashTile(e.tile); return;
      case 'bought': {
        addLog('🏠', 'log.bought', { name: nm, tile: T(st, e.tile) });
        const c = tileC(e.tile); Sound.play('bigCoin'); flashTile(e.tile);
        FX.burst(c.x, c.y, { count: 28, kind: 'confetti', size: 6, speed: 5, up: 3, life: 900 });
        return FX.wait(450);
      }
      case 'upgraded': {
        addLog('⭐', 'log.upgraded', { name: nm, tile: T(st, e.tile), n: e.level });
        const c = tileC(e.tile); Sound.play('grow'); flashTile(e.tile);
        FX.burst(c.x, c.y, { count: 10, kind: 'text', text: '⭐', size: 18, speed: 5, up: 3, life: 1000 });
        return FX.wait(450);
      }
      case 'declined': addLog('🙅', 'log.declined', { name: nm, tile: T(st, e.tile) }); return;
      case 'cantAfford': addLog('😬', 'log.cantAfford', { name: nm, tile: T(st, e.tile) }); return;
      case 'homeSweet': addLog('🛋️', 'log.home', { name: nm, tile: T(st, e.tile) }); return;
      case 'rentDue': addLog('💸', 'log.rent', { name: nm, n: e.amount, owner: P(e.owner) }); flashTile(e.tile); return;
      case 'rentFrozen': { addLog('🧊', 'log.rentFrozen', { name: nm, tile: T(st, e.tile) }); const c = tileC(e.tile); FX.burst(c.x, c.y, { count: 10, kind: 'text', text: '❄️', size: 18, speed: 4, life: 1000 }); return FX.wait(400); }
      case 'tax': addLog('🧾', 'log.tax', { name: nm }); return;
      case 'warp': addLog('🕳️', 'log.warp', { name: nm }); return;
      case 'potLand': {
        addLog('🍲', e.amount ? 'log.pot' : 'log.potEmpty', { name: nm, n: e.amount });
        if (e.amount) { const c = tileC(16); FX.burst(c.x, c.y, { count: 20, kind: 'text', text: ['🪙', '🍗'], size: 18, speed: 7, up: 4, life: 1200 }); Sound.play('cluck'); }
        return FX.wait(300);
      }
      case 'slip': { addLog('🍌', 'log.slip', { name: nm }); const c = anchor(e.pid); FX.comic(c.x, c.y - 30, 'SLIP!', '#FFD60A'); Sound.play('whoosh'); tokenClass(e.pid, 'spin'); return FX.wait(600); }
      case 'napVisit': addLog('😴', 'log.napVisit', { name: nm }); return;
      case 'napped': addLog('💤', 'log.napped', { name: nm }); Sound.play('snore'); return FX.wait(300);
      case 'skipTurn': { addLog('💤', 'log.skip', { name: nm }); Sound.play('snore'); const el = tokenEls[e.pid]; if (el) FX.bubble(el, '💤', { cls: 'emoji' }); return FX.wait(700); }
      case 'ufoReturn': {
        addLog('🛸', 'log.ufoReturn', { name: nm });
        const p = tileC(e.tile); Sound.play('ufo');
        const u = FX.el('🛸', 'fx-emoji', { fontSize: '70px' });
        await u.animate([{ transform: `translate(-100px, ${p.y - 200}px) translate(-50%,-50%)` }, { transform: `translate(${p.x}px, ${p.y - 110}px) translate(-50%,-50%)` }], { duration: FX.ms(900), easing: 'ease-out', fill: 'forwards' }).finished;
        const el = tokenEls[e.pid];
        if (el) { el.classList.remove('hidden'); animating.delete(e.pid); App.view = st; placeTokens(st, true); el.animate([{ opacity: 0, transform: `translate(${el._x}px,${el._y - 80}px) scale(.2)` }, { opacity: 1, transform: `translate(${el._x}px,${el._y}px) scale(1)` }], { duration: FX.ms(600), easing: 'cubic-bezier(.34,1.56,.64,1)' }); }
        FX.bubble(el, '🎁👽', { cls: 'emoji' });
        await u.animate([{ transform: `translate(${p.x}px, ${p.y - 110}px) translate(-50%,-50%)` }, { transform: `translate(${innerWidth + 120}px, -120px) translate(-50%,-50%) scale(.5)` }], { duration: FX.ms(900), easing: 'ease-in', fill: 'forwards' }).finished;
        u.remove(); return;
      }
      case 'crater': { addLog('🕳️', 'log.crater', { name: nm }); tokenClass(e.pid, 'squash'); Sound.play('bonk'); return FX.wait(500); }
      case 'bombBoom': {
        addLog('💥', 'log.bomb');
        const p = tileC(e.tile); FX.explode(p, true); shakeBoard(20, 900);
        e.victims.forEach((id) => tokenClass(id, 'squash', 1100));
        await Promise.all(e.piles.map((pl, k) => FX.wait(k * 80).then(() => FX.fly('🪙', p, tileC(pl.tile), { size: 24, arc: -140, dur: 800, spin: 540 }))));
        return;
      }
      case 'chickenTile': { addLog('🐔', e.good ? 'log.chickenGood' : 'log.chickenBad', { name: nm }); Sound.play('cluck'); const c = tileC(e.tile); FX.burst(c.x, c.y, { count: 6, kind: 'text', text: e.good ? '🥚' : '🪶', size: 18, speed: 4, life: 1000 }); return FX.wait(400); }
      case 'shieldUp': { addLog('🫧', 'log.shieldUp', { name: nm }); Sound.play('pop'); const c = anchor(e.pid); FX.burst(c.x, c.y, { count: 10, kind: 'text', text: '🫧', size: 16, speed: 3, g: -0.05, life: 1000 }); return FX.wait(300); }
      case 'shieldBlock': { addLog('🛡️', 'log.shieldBlock', { name: nm, n: e.amount }); Sound.play('pop'); const c = anchor(e.pid); FX.burst(c.x, c.y, { count: 22, colors: ['#64D2FF', '#fff'], size: 5, speed: 6, life: 800 }); FX.comic(c.x, c.y - 30, 'POP!', '#64D2FF'); return FX.wait(600); }
      case 'extraGranted': addLog('🎲', 'log.extraGranted', { name: nm }); return;
      case 'extraRoll': { addLog('🔁', 'log.extraRoll', { name: nm }); const c = FX.center($('#dice')); FX.comic(c.x, c.y - 40, 'AGAIN!', '#64D2FF'); return FX.wait(500); }
      case 'tooExcited': { addLog('🤪', 'log.tooExcited', { name: nm }); const c = anchor(e.pid); FX.comic(c.x, c.y - 30, 'TOO MUCH!', '#FF9F0A'); return FX.wait(700); }
      case 'sell': addLog('🏷️', 'log.sell', { name: nm, tile: T(st, e.tile), n: e.amount }); flashTile(e.tile); return FX.wait(300);
      case 'rescue': {
        addLog('👵', 'log.rescue', { name: nm, n: e.amount });
        const p = anchor(e.pid);
        await FX.fly('👵', { x: innerWidth + 60, y: p.y - 40 }, { x: p.x + 40, y: p.y - 30 }, { size: 60, arc: -100, dur: 900 });
        FX.burst(p.x, p.y, { count: 20, kind: 'text', text: ['🪙', '❤️'], size: 18, speed: 6, up: 4, life: 1200 });
        return miniToast('👵 ' + te('log.rescue', { name: nm, n: e.amount }), 2000);
      }
      case 'bankrupt': {
        addLog('💀', 'log.bankrupt', { name: nm });
        const p = anchor(e.pid); FX.smoke(p.x, p.y, 16); FX.comic(p.x, p.y - 20, 'POOF!', '#8e8e93'); Sound.play('lose');
        return miniToast('💸 ' + te('log.bankrupt', { name: nm }), 2200);
      }
      case 'monopoly': {
        addLog('👑', 'log.monopoly', { name: nm });
        st.tiles.forEach((tl, i) => { if (tl.g === e.g && tl.t === 'prop') flashTile(i, 'spot'); });
        Sound.play('fanfare'); FX.confetti(null, null, 100);
        return miniToast('👑 ' + te('log.monopoly', { name: nm }), 2000);
      }
      case 'miniStart': addLog('🔮', 'log.miniStart', { name: nm, n: e.base }); flashTile(st.players[e.pid].pos); return;
      case 'miniRoll': {
        const tray = $('#dice'); if (tray) { tray.innerHTML = dieHTML(e.base, 'small') + '<span style="font-size:20px">→</span>' + dieHTML(1); $$('.die', tray).forEach((d, i) => setDie(d, i ? 1 : e.base, false)); void tray.offsetWidth; }
        Sound.play('dice');
        const d = tray && $$('.die', tray)[1]; if (d) { d.style.transition = `transform ${FX.ms(1000)}ms cubic-bezier(.2,.7,.2,1)`; setDie(d, e.die, true); }
        await FX.wait(1050); Sound.play('diceLand');
        const c = tray ? FX.center(tray) : anchor(e.pid);
        addLog(e.result === 'win' ? '✅' : e.result === 'lose' ? '❌' : '🤝', e.result === 'win' ? 'log.miniWin' : e.result === 'lose' ? 'log.miniLose' : 'log.miniTie', { name: nm, n: e.die });
        FX.comic(c.x, c.y - 50, e.result === 'win' ? 'YES!' : e.result === 'lose' ? 'NOPE!' : 'TIE!', e.result === 'win' ? '#32D74B' : e.result === 'lose' ? '#FF453A' : '#FFD60A');
        if (tray) setTimeout(() => { if ($('#dice') === tray && !App.playing) { tray.innerHTML = dieHTML(1) + dieHTML(1); $$('.die', tray).forEach((x) => setDie(x, 1, false)); } }, 1500);
        return FX.wait(600);
      }
      case 'auctionTurn': return;
      case 'bid': { addLog('🙋', 'log.bid', { name: nm, n: e.bid }); Sound.play('tick'); const c = anchor(e.pid); FX.floatText(c.x, c.y - 20, '🙋 ' + num(e.bid), '#FFD60A'); return FX.wait(300); }
      case 'auctionPass': addLog('🙅', 'log.auctionPass', { name: nm }); return;
      case 'auctionWon': {
        addLog('🔨', 'log.auctionWon', { name: nm, tile: T(st, e.tile), n: e.price });
        const c = tileC(e.tile); Sound.play('bell'); FX.comic(c.x, c.y - 30, 'SOLD!', '#FFD60A'); FX.confetti(c.x, c.y, 60); flashTile(e.tile);
        return FX.wait(800);
      }
      case 'auctionNone': addLog('🤷', 'log.auctionNone', { tile: T(st, e.tile) }); return;
      case 'giantEnd': addLog('🤏', 'log.giantEnd', { name: nm }); Sound.play('warp'); return;
      case 'noProps': addLog('🐜', 'log.noProps', { name: nm }); return;
      case 'nothing': addLog('🤔', 'log.nothing'); react(e.pid, 'confused'); return;
      case 'gameOver': addLog('🏁', 'log.gameOver'); return;
    }
  }

  // ---------------------------------------------------------------- game over
  function showGameOver(st, again) {
    closeModals();
    const R = st.ranking || [];
    const w = st.players[st.winner];
    if (!again) { Sound.play('fanfare'); FX.confetti(null, null, 160); FX.fireworks(7); if (tokenEls[w.id]) FX.bubble(tokenEls[w.id], esc(I18N.t('react.win'))); }
    const pods = [R[1], R[0], R[2]].filter(Boolean).map((r) => { const p = st.players[r.pid]; return `<div class="pod ${r === R[0] ? 'first' : ''}"><div class="av" style="--c:${p.color}">${emo(p.avatar)}</div><div class="nm">${esc(nameOf(p))}</div><small>${p.out ? te('over.out') : te('over.worth', { n: r.worth })}</small><div class="blk">${R.indexOf(r) + 1}</div></div>`; }).join('');
    const rest = R.slice(3).map((r, k) => `<div class="lobby-p"><b>${k + 4}</b><span class="av" style="--c:${st.players[r.pid].color}">${emo(st.players[r.pid].avatar)}</span><span class="nm">${esc(nameOf(st.players[r.pid]))}</span><span class="muted">${st.players[r.pid].out ? te('over.out') : te('over.worth', { n: r.worth })}</span></div>`).join('');
    const host = App.mode === 'online' && App.room && App.room.players.find((p) => p.host);
    const isHost = host && host.seat === App.me;
    const reason = st.players.filter((p) => !p.out).length <= 1 ? 'over.reasonLast' : 'over.reasonRounds';
    const m = modal(`<div class="over-wrap"><div class="label">${te(reason)}</div><h2 style="font-size:30px;margin:4px 0 0">🏆 ${te('over.title', { name: nameOf(w) })}</h2><div class="muted">${te('over.sub')}</div>
      <div class="podium">${pods}</div>${rest ? `<div class="lobby-list" style="text-align:start">${rest}</div>` : ''}</div>
      <div class="actions">${App.mode === 'local' ? `<button class="btn" data-home>${te('over.home')}</button><button class="btn primary" data-again>🔁 ${te('over.again')}</button>`
        : `<button class="btn" data-home>${te('online.leave')}</button>${isHost ? `<button class="btn primary" data-rematch>🔁 ${te('online.rematch')}</button>` : ''}`}<button class="btn ghost" data-x>${te('common.close')}</button></div>`);
    const h = $('[data-home]', m.el); if (h) h.onclick = () => { m.close(); leaveCurrent(); go('home'); };
    const a = $('[data-again]', m.el); if (a) a.onclick = () => { m.close(); startLocal(); };
    const r = $('[data-rematch]', m.el); if (r) r.onclick = () => { m.close(); Net.send({ t: 'rematch' }); };
    $('[data-x]', m.el).onclick = () => m.close();
  }

  // ---------------------------------------------------------------- tooltips, emotes, idle chatter
  function showTip(i, ev) {
    const st = App.view; if (!st) return;
    const tl = st.tiles[i]; const tip = $('#tooltip'); const info = Eng.info(st);
    let rows = '';
    if (tl.t === 'prop') {
      rows += tl.owner !== null ? `<div class="tt-row"><span>${te('game.owner', { name: nameOf(st.players[tl.owner]) })}</span><span>${emo(st.players[tl.owner].avatar)}</span></div><div class="tt-row"><span>${te('game.rent', { n: info.rentOf(i) })}</span><span class="stars" style="color:#FFD60A">${'★'.repeat(tl.level)}</span></div>`
        : `<div class="tt-row"><span>${te('game.forSale', { n: tl.price })}</span><span>${te('game.rent', { n: info.rentBase(i) })}</span></div>`;
    }
    const notes = [];
    notes.push(tl.t === 'tax' ? te('info.tax', { n: tl.amt }) : te('info.' + tl.t));
    if (tl.crater) notes.push('🕳️ ' + te('info.crater', { n: tl.crater }));
    if (tl.bomb) notes.push('💣 ' + te('info.bomb', { n: tl.bomb }));
    if (tl.chicken) notes.push('🐔 ' + te('info.chicken'));
    const pile = tl.piles.reduce((s, p) => s + p.v, 0); if (pile) notes.push('🪙 ' + te('info.piles', { n: pile }));
    tip.innerHTML = `<b>${tl.g ? `<span class="tt-g" style="--g:${C.GROUPS[tl.g]}"></span>` : ''}${tileIcon(tl)} ${esc(tileName(tl))}</b>${rows}${notes.map((n) => `<p>${n}</p>`).join('')}`;
    tip.hidden = false; moveTip(ev);
  }
  function moveTip(ev) {
    const tip = $('#tooltip'); if (tip.hidden || !ev) return;
    const w = tip.offsetWidth, h = tip.offsetHeight;
    let x = ev.clientX + 14, y = ev.clientY + 14;
    if (x + w > innerWidth - 8) x = ev.clientX - w - 14;
    if (y + h > innerHeight - 8) y = ev.clientY - h - 14;
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  function hideTip() { $('#tooltip').hidden = true; }

  function sendEmote(e) {
    if (!App.view) return;
    if (App.mode === 'online') Net.send({ t: 'emote', e });
    else showEmote(App.view.players[App.view.order[App.view.turn]].id, e);
  }
  function showEmote(pid, e) {
    const p = anchor(pid); Sound.play('pop');
    FX.fly(esc(e), p, { x: p.x + rnd(-30, 30), y: p.y - 130 }, { size: 38, arc: -20, dur: 1300, s1: 1.5 });
    const card = $(`.pl[data-pid="${pid}"]`);
    if (card) { const c = FX.center(card); FX.fly(esc(e), { x: c.x + c.w / 2 - 30, y: c.y }, { x: c.x + c.w / 2 - 30, y: c.y - 60 }, { size: 26, arc: -10, dur: 1000 }); }
  }
  setInterval(() => {
    if (App.screen !== 'game' || App.playing || !App.view || App.view.phase === 'over' || document.hidden || Math.random() < 0.5) return;
    const ps = App.view.players.filter((p) => !p.out && !p.abducted);
    if (!ps.length) return;
    const shared = ps.find((p) => ps.some((q) => q.id !== p.id && q.pos === p.pos));
    if (shared) react(shared.id, 'meet'); else react(pickOne(ps).id, 'idle');
  }, 9000);

  // ---------------------------------------------------------------- networking
  Net.on('joined', (m) => { Net.remember(m.code, m.token); App.me = m.seat; App.mode = 'online'; });
  Net.on('lobby', (m) => {
    App.room = m.room; App.me = m.you; App.mode = 'online';
    if (m.room.phase === 'lobby') {
      if (App.screen === 'game') { App.view = null; App.queue = []; App.overShown = false; closeModals(); go('online'); }
      else if (App.screen === 'online') updateLobby(); else go('online');
    } else if (App.screen === 'game' && App.view) renderPlayers(App.view);
    updateTitle();
  });
  Net.on('events', (m) => {
    App.sending = false; clearTimeout(App.sendTimer);
    if (m.start || App.screen !== 'game') {
      App.mode = 'online'; App.log = []; App.queue = []; App.overShown = false;
      App.view = m.events[0] ? m.events[0].s : App.view;
      go('game');
    }
    enqueue(m.events);
  });
  Net.on('sync', (m) => {
    App.sending = false; App.mode = 'online'; App.queue = []; App.view = m.state;
    if (App.screen !== 'game') go('game'); else renderState(App.view);
    if (App.view.phase === 'over') afterQueue();
  });
  Net.on('error', (m) => {
    App.sending = false;
    if (m.code === 'rejoinFailed') { Net.forget(); App.room = null; if (App.screen === 'online') renderOnline(); return; }
    toast('⚠️', t('online.title'), I18N.has('online.err.' + m.code) ? t('online.err.' + m.code) : m.code);
    if (m.resync && m.state && !App.playing) { App.view = m.state; renderState(App.view); }
  });
  Net.on('emote', (m) => { if (App.screen === 'game') showEmote(m.seat, m.e); });
  let wasDown = false;
  Net.on('status', (s) => {
    updateTitle();
    if (s === 'reconnecting' && !wasDown && App.mode === 'online') { wasDown = true; toast('📡', t('online.disconnected')); }
    if (s === 'open' && wasDown) { wasDown = false; toast('✅', t('online.reconnected'), '', 2000); }
  });

  // ---------------------------------------------------------------- chrome wiring + boot
  function wire() {
    $$('#menubar [data-menu]').forEach((b) => {
      b.addEventListener('click', (e) => { e.stopPropagation(); openMenu(b.dataset.menu, b); });
      b.addEventListener('mouseenter', () => { if (openMenuName && openMenuName !== b.dataset.menu) openMenu(b.dataset.menu, b); });
    });
    document.addEventListener('mousedown', (e) => { if (openMenuName && !e.target.closest('#menuPop') && !e.target.closest('[data-menu]')) closeMenu(); });
    $('#mbSound').onclick = toggleSound;
    $('#mbLangForm').onsubmit = (e) => { e.preventDefault(); const v = $('#mbLang').value; $('#mbLang').blur(); setLanguage(v, null); };
    $('#mbLang').addEventListener('change', () => { const v = $('#mbLang').value; if (I18N.suggestions().includes(v)) { $('#mbLang').blur(); setLanguage(v, null); } });
    const win = $('#win');
    $('#tlClose').onclick = () => {
      if (App.screen === 'game') confirmLeave(() => go('home'));
      else if (App.screen !== 'home') confirmLeave(() => go('home'));
      else minimize();
    };
    $('#tlMin').onclick = minimize;
    $('#tlZoom').onclick = toggleFullscreen;
    function minimize() { Sound.play('whoosh'); win.classList.add('minimized'); toast('🐔', t('app.name'), t('window.minimized'), 3500); }
    $('#dockApp').onclick = () => {
      const d = $('#dockApp');
      if (win.classList.contains('minimized')) { win.classList.remove('minimized'); Sound.play('pop'); }
      else { d.classList.remove('bounce'); void d.offsetWidth; d.classList.add('bounce'); }
    };
    $('#dockSettings').onclick = () => openSettings();
    $('#dockRules').onclick = showHelp;
    $('#tbHelp').onclick = showHelp;
    $('#tbSettings').onclick = () => openSettings();
    document.addEventListener('keydown', (e) => {
      const typing = /input|textarea|select/i.test((e.target.tagName || ''));
      if (e.key === 'Escape') { if (openMenuName) closeMenu(); else if (modals.length) modals[modals.length - 1].close(); else if (settingsWin) closeSettings(); return; }
      if ((e.metaKey || e.ctrlKey) && e.key === ',') { e.preventDefault(); openSettings(); return; }
      if (typing || e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === 'm' || e.key === 'M') toggleSound();
      else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
      else if (e.key === '?') showHelp();
      else if ((e.key === ' ' || e.key === 'Enter') && App.screen === 'game' && App.view && App.view.phase === 'roll' && !modals.length) {
        const a = Eng.actorOf(App.view);
        if (canControl(a) && !App.playing && !App.sending) { e.preventDefault(); doAction({ type: 'roll' }); }
      }
    });
    document.addEventListener('pointerdown', () => Sound.unlock(), { once: true });
    addEventListener('beforeunload', (e) => { if (App.screen === 'game' && App.mode === 'local' && App.view && App.view.phase !== 'over') { e.preventDefault(); e.returnValue = ''; } });
    setInterval(tickClock, 15000);
  }

  // Developer hook for testing effects from the console: ChaosDebug.chaos('meteor'), ChaosDebug.twist('gravity')
  window.ChaosDebug = {
    chaos(id) { if (App.mode === 'local' && !App.playing) enqueue(Eng.debugForce(App.game, 'chaos', id)); },
    twist(id) { if (App.mode === 'local' && !App.playing) enqueue(Eng.debugForce(App.game, 'twist', id)); },
    get app() { return App; },
  };

  function boot() {
    FX.init(); wire(); applySettings();
    I18N.restore();
    applyStatic();
    go('home');
    $('#win').classList.add('opening');
    detectServer().then(() => {
      if (settingsWin) renderSettings();
      if (App.screen === 'online') renderOnline();
      if (Net.restoreSession() && Server.base) Net.connect(Server.base).catch(() => Net.forget());
    });
    // ?lang=Thai in the URL sets the language directly
    const q = new URLSearchParams(location.search).get('lang');
    if (q) setLanguage(q, null);
    // Installable web app: offline support when served from a website (not inside the Android app shell)
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !window.Capacitor && location.hostname !== 'localhost') {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  }
  boot();
})();
