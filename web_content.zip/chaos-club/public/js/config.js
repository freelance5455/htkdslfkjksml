/* Build-time settings. The Android build workflow can overwrite this file.
 * server: address of your Chaos Club server for online rooms + AI translation,
 *         e.g. 'https://chaos-club.onrender.com'. Leave '' to use the page's own server. */
window.CHAOS_CONFIG = { server: '' };
