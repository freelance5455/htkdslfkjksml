/* The Chaos Club — cartoon visual effects: particles, flying emoji, explosions, shakes, lightning. */
(function (root) {
  'use strict';
  const FX = { speed: 1, reduceMotion: false, shakeOn: true };
  let canvas, ctx, layer, parts = [], running = false, dpr = 1;

  FX.init = function () {
    canvas = document.getElementById('fxCanvas'); layer = document.getElementById('fxLayer');
    ctx = canvas.getContext('2d');
    const size = () => { dpr = Math.min(2, root.devicePixelRatio || 1); canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr; canvas.style.width = innerWidth + 'px'; canvas.style.height = innerHeight + 'px'; };
    size(); addEventListener('resize', size);
  };
  FX.ms = (n) => Math.round(n * FX.speed);
  FX.wait = (n) => new Promise((r) => setTimeout(r, FX.ms(n)));

  // ---------- particles ----------
  const COLORS = ['#FF453A', '#FF9F0A', '#FFD60A', '#32D74B', '#64D2FF', '#0A84FF', '#BF5AF2', '#FF375F'];
  function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const now = performance.now();
    parts = parts.filter((p) => now - p.born < p.life);
    for (const p of parts) {
      const k = (now - p.born) / p.life;
      p.vy += p.g; p.vx *= p.drag; p.vy *= p.drag; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
      ctx.save(); ctx.globalAlpha = p.fade ? Math.max(0, 1 - k) : (k > 0.8 ? (1 - k) * 5 : 1);
      ctx.translate(p.x * dpr, p.y * dpr); ctx.rotate(p.rot);
      if (p.kind === 'confetti') { ctx.fillStyle = p.c; ctx.fillRect(-p.s * dpr / 2, -p.s * dpr / 4, p.s * dpr, p.s * dpr / 2); }
      else if (p.kind === 'smoke') { const r = p.s * (1 + k * 2) * dpr; ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill(); }
      else if (p.kind === 'text') { ctx.font = `${p.s * dpr}px system-ui, "Apple Color Emoji", "Segoe UI Emoji", sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(p.t, 0, 0); }
      else { ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(0, 0, p.s * dpr * (1 - k * 0.7), 0, 7); ctx.fill(); }
      ctx.restore();
    }
    if (parts.length) requestAnimationFrame(loop); else { running = false; ctx.clearRect(0, 0, canvas.width, canvas.height); }
  }
  function add(p) {
    parts.push(Object.assign({ born: performance.now(), rot: 0, vr: 0, drag: 0.98, g: 0.25, life: 1200, s: 6, c: '#fff', kind: 'dot' }, p));
    if (!running) { running = true; requestAnimationFrame(loop); }
  }
  FX.burst = function (x, y, o) {
    o = o || {};
    const n = FX.reduceMotion ? Math.ceil((o.count || 30) / 3) : (o.count || 30);
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, sp = (o.speed || 6) * (0.4 + Math.random());
      add({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - (o.up || 0), g: o.g == null ? 0.25 : o.g, life: (o.life || 1100) * (0.7 + Math.random() * 0.6),
        s: (o.size || 6) * (0.6 + Math.random() * 0.8), c: o.colors ? o.colors[i % o.colors.length] : COLORS[i % COLORS.length],
        kind: o.kind || 'dot', t: o.text ? (Array.isArray(o.text) ? o.text[i % o.text.length] : o.text) : null, vr: (Math.random() - 0.5) * 0.3, drag: o.drag || 0.98, fade: o.fade });
    }
  };
  FX.confetti = function (x, y, count) {
    x = x == null ? innerWidth / 2 : x; y = y == null ? innerHeight / 3 : y;
    FX.burst(x, y, { count: count || 120, kind: 'confetti', speed: 11, up: 6, g: 0.22, size: 10, life: 2600, drag: 0.985 });
  };
  FX.rain = function (text, count, dur) {
    count = FX.reduceMotion ? Math.ceil(count / 3) : count;
    for (let i = 0; i < count; i++) {
      setTimeout(() => add({ x: Math.random() * innerWidth, y: -30, vx: (Math.random() - 0.5) * 2, vy: 2 + Math.random() * 3, g: 0.12, drag: 0.995, life: 3200, s: 22 + Math.random() * 14, kind: 'text', t: Array.isArray(text) ? text[i % text.length] : text, vr: (Math.random() - 0.5) * 0.1 }), Math.random() * (dur || 1200));
    }
  };
  FX.fireworks = function (n) {
    for (let i = 0; i < (n || 5); i++) {
      setTimeout(() => { const x = innerWidth * (0.2 + Math.random() * 0.6), y = innerHeight * (0.15 + Math.random() * 0.35); FX.burst(x, y, { count: 60, speed: 7, g: 0.08, life: 1500, size: 4, drag: 0.97, colors: [COLORS[i % 8], '#fff', COLORS[(i + 3) % 8]] }); root.Sound && Sound.play('pop'); }, i * 320);
    }
  };
  FX.smoke = function (x, y, n) { for (let i = 0; i < (n || 10); i++) add({ x: x + (Math.random() - 0.5) * 40, y: y + (Math.random() - 0.5) * 20, vx: (Math.random() - 0.5) * 2, vy: -1 - Math.random() * 1.5, g: -0.01, drag: 0.97, life: 1400, s: 10 + Math.random() * 10, c: 'rgba(200,200,210,0.35)', kind: 'smoke', fade: true }); };

  // ---------- DOM effects ----------
  function el(html, cls, style) { const d = document.createElement('div'); d.className = 'fx-el ' + (cls || ''); d.innerHTML = html; Object.assign(d.style, style || {}); layer.appendChild(d); return d; }
  FX.el = el;
  FX.center = function (node) { const r = node.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height }; };

  FX.fly = function (emoji, from, to, o) {
    o = o || {};
    const d = el(emoji, 'fx-emoji', { fontSize: (o.size || 32) + 'px', left: '0px', top: '0px' });
    const arc = o.arc == null ? -80 : o.arc; const mx = (from.x + to.x) / 2, my = Math.min(from.y, to.y) + arc;
    const spin = o.spin || 0;
    const a = d.animate([
      { transform: `translate(${from.x}px, ${from.y}px) translate(-50%,-50%) scale(${o.s0 || 1}) rotate(0deg)`, opacity: o.fadeIn ? 0 : 1 },
      { transform: `translate(${mx}px, ${my}px) translate(-50%,-50%) scale(${o.sMid || 1.2}) rotate(${spin / 2}deg)`, opacity: 1, offset: 0.5 },
      { transform: `translate(${to.x}px, ${to.y}px) translate(-50%,-50%) scale(${o.s1 || 1}) rotate(${spin}deg)`, opacity: o.fadeOut === false ? 1 : 0.9 },
    ], { duration: FX.ms(o.dur || 700), easing: o.easing || 'cubic-bezier(.45,.05,.55,.95)', fill: 'forwards' });
    return a.finished.then(() => { if (!o.keep) d.remove(); return d; });
  };
  FX.coinsFly = function (from, to, n) {
    const ps = [];
    for (let i = 0; i < (n || 6); i++) ps.push(new Promise((r) => setTimeout(() => FX.fly('🪙', { x: from.x + (Math.random() - 0.5) * 20, y: from.y }, { x: to.x + (Math.random() - 0.5) * 16, y: to.y }, { size: 20, arc: -60 - Math.random() * 60, dur: 600 }).then(r), FX.ms(i * 60))));
    return Promise.all(ps);
  };
  FX.floatText = function (x, y, text, color) {
    const d = el(text, 'fx-float', { left: x + 'px', top: y + 'px', color: color || '#fff' });
    d.animate([{ transform: 'translate(-50%,-50%) scale(.6)', opacity: 0 }, { transform: 'translate(-50%,-110%) scale(1.15)', opacity: 1, offset: 0.25 }, { transform: 'translate(-50%,-260%) scale(1)', opacity: 0 }], { duration: FX.ms(1400), easing: 'ease-out', fill: 'forwards' }).finished.then(() => d.remove());
  };
  FX.comic = function (x, y, text, color) {
    const d = el(`<span>${text}</span>`, 'fx-comic', { left: x + 'px', top: y + 'px', '--c': color || '#FFD60A' });
    d.animate([{ transform: 'translate(-50%,-50%) scale(0) rotate(-20deg)' }, { transform: 'translate(-50%,-50%) scale(1.25) rotate(6deg)', offset: 0.3 }, { transform: 'translate(-50%,-50%) scale(1) rotate(-4deg)', offset: 0.6 }, { transform: 'translate(-50%,-60%) scale(1.05) rotate(-4deg)', opacity: 0 }], { duration: FX.ms(1100), easing: 'ease-out', fill: 'forwards' }).finished.then(() => d.remove());
  };
  FX.shake = function (node, power, dur) {
    if (!FX.shakeOn || FX.reduceMotion || !node) return Promise.resolve();
    power = power || 8; const frames = [];
    for (let i = 0; i < 12; i++) { const k = 1 - i / 12; frames.push({ transform: `translate(${(Math.random() - 0.5) * power * 2 * k}px, ${(Math.random() - 0.5) * power * 2 * k}px) rotate(${(Math.random() - 0.5) * power * 0.2 * k}deg)` }); }
    frames.push({ transform: 'none' });
    return node.animate(frames, { duration: FX.ms(dur || 600) }).finished;
  };
  FX.flash = function (color, dur) {
    const d = el('', 'fx-flash', { background: color || '#fff' });
    return d.animate([{ opacity: 0.85 }, { opacity: 0 }], { duration: FX.ms(dur || 350), easing: 'ease-out' }).finished.then(() => d.remove());
  };
  FX.explode = function (p, big) {
    root.Sound && Sound.play(big ? 'boom' : 'smallBoom');
    const ring = el('', 'fx-ring', { left: p.x + 'px', top: p.y + 'px' });
    ring.animate([{ transform: 'translate(-50%,-50%) scale(.1)', opacity: 1 }, { transform: `translate(-50%,-50%) scale(${big ? 3.2 : 2})`, opacity: 0 }], { duration: FX.ms(600), easing: 'ease-out' }).finished.then(() => ring.remove());
    FX.burst(p.x, p.y, { count: big ? 70 : 35, speed: big ? 10 : 6, colors: ['#FFD60A', '#FF9F0A', '#FF453A', '#fff'], size: 7, life: 900, g: 0.18 });
    FX.burst(p.x, p.y, { count: big ? 10 : 5, text: ['⭐', '💫', '✨'], kind: 'text', size: 22, speed: 6, life: 1100, g: 0.15 });
    FX.smoke(p.x, p.y, big ? 16 : 8);
    FX.comic(p.x, p.y - 20, big ? 'KABOOM!' : 'POW!', big ? '#FF9F0A' : '#FFD60A');
    if (big) FX.flash('#FFF4C2', 300);
  };
  FX.lightning = function (to) {
    const svg = `<svg width="${innerWidth}" height="${innerHeight}" viewBox="0 0 ${innerWidth} ${innerHeight}"><path d="${bolt(to)}" fill="none" stroke="#FFF7B0" stroke-width="6" stroke-linejoin="round" filter="url(#glow)"/><defs><filter id="glow"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs></svg>`;
    const d = el(svg, 'fx-bolt', { left: 0, top: 0 });
    root.Sound && Sound.play('zap');
    FX.flash('#E8F0FF', 250);
    return d.animate([{ opacity: 1 }, { opacity: 0.2 }, { opacity: 1 }, { opacity: 0 }], { duration: FX.ms(700) }).finished.then(() => d.remove());
  };
  function bolt(to) {
    let x = to.x + (Math.random() - 0.5) * 120, y = -10; let d = `M${x},${y}`;
    const steps = 8;
    for (let i = 1; i <= steps; i++) { y = (to.y * i) / steps; x = i === steps ? to.x : to.x + (Math.random() - 0.5) * 90 * (1 - i / steps); d += ` L${x},${y}`; }
    return d;
  }
  FX.bubble = function (node, text, o) {
    if (!node) return;
    const c = FX.center(node);
    const d = el(text, 'fx-bubble ' + ((o && o.cls) || ''), { left: c.x + 'px', top: (c.y - c.h / 2 - 6) + 'px' });
    d.animate([{ transform: 'translate(-50%,-100%) scale(.4)', opacity: 0 }, { transform: 'translate(-50%,-100%) scale(1.05)', opacity: 1, offset: 0.15 }, { transform: 'translate(-50%,-100%) scale(1)', opacity: 1, offset: 0.85 }, { transform: 'translate(-50%,-120%) scale(.9)', opacity: 0 }], { duration: FX.ms((o && o.dur) || 1800), fill: 'forwards' }).finished.then(() => d.remove());
  };

  root.FX = FX;
})(globalThis);
