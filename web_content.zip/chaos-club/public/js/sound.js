/* The Chaos Club — synthesized sound effects (Web Audio, no audio files). */
(function (root) {
  'use strict';
  let ctx = null, master = null, noiseBuf = null;
  const Sound = { enabled: true, volume: 0.6 };

  function init() {
    if (ctx) return ctx.state === 'suspended' ? ctx.resume() : null;
    const AC = root.AudioContext || root.webkitAudioContext; if (!AC) return;
    ctx = new AC(); master = ctx.createGain(); master.gain.value = Sound.volume; master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  Sound.unlock = init;
  Sound.setVolume = (v) => { Sound.volume = v; if (master) master.gain.value = v; };

  function tone(freq, dur, opt) {
    opt = opt || {};
    const t = ctx.currentTime + (opt.delay || 0);
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = opt.type || 'sine'; o.frequency.setValueAtTime(freq, t);
    if (opt.to) o.frequency.exponentialRampToValueAtTime(Math.max(20, opt.to), t + dur);
    if (opt.vib) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = opt.vib; lg.gain.value = opt.vibDepth || 20; l.connect(lg); lg.connect(o.frequency); l.start(t); l.stop(t + dur); }
    const v = opt.vol == null ? 0.3 : opt.vol;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + (opt.attack || 0.01));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(dur, opt) {
    opt = opt || {};
    const t = ctx.currentTime + (opt.delay || 0);
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = opt.filter || 'lowpass'; f.frequency.setValueAtTime(opt.freq || 1200, t);
    if (opt.to) f.frequency.exponentialRampToValueAtTime(opt.to, t + dur);
    const g = ctx.createGain(); const v = opt.vol == null ? 0.3 : opt.vol;
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master); s.start(t); s.stop(t + dur + 0.05);
  }

  const FX = {
    click() { tone(900, 0.05, { type: 'triangle', vol: 0.12 }); },
    hover() { tone(1400, 0.03, { type: 'sine', vol: 0.04 }); },
    dice() { for (let i = 0; i < 7; i++) noise(0.04, { delay: i * 0.07 + Math.random() * 0.03, filter: 'bandpass', freq: 2500 + Math.random() * 1500, vol: 0.35 }); },
    diceLand() { tone(180, 0.12, { type: 'triangle', vol: 0.3 }); noise(0.05, { filter: 'highpass', freq: 3000, vol: 0.2 }); },
    step() { tone(520 + Math.random() * 80, 0.06, { type: 'triangle', vol: 0.12 }); },
    coin() { tone(988, 0.08, { type: 'square', vol: 0.08 }); tone(1319, 0.25, { type: 'square', vol: 0.08, delay: 0.07 }); },
    bigCoin() { [988, 1319, 1568, 1976].forEach((f, i) => tone(f, 0.2, { type: 'square', vol: 0.07, delay: i * 0.06 })); },
    lose() { tone(420, 0.25, { type: 'sawtooth', to: 180, vol: 0.12 }); tone(300, 0.35, { type: 'sawtooth', to: 120, vol: 0.1, delay: 0.15 }); },
    boom() { noise(1.1, { freq: 900, to: 60, vol: 0.9 }); tone(90, 0.8, { type: 'sine', to: 30, vol: 0.7 }); },
    smallBoom() { noise(0.5, { freq: 1500, to: 100, vol: 0.5 }); tone(140, 0.4, { to: 50, vol: 0.4 }); },
    whoosh() { noise(0.5, { filter: 'bandpass', freq: 300, to: 3000, vol: 0.35 }); },
    whistle() { tone(2200, 0.9, { to: 500, type: 'sine', vol: 0.15 }); },
    ufo() { tone(600, 1.6, { type: 'sine', vib: 7, vibDepth: 120, vol: 0.18 }); tone(900, 1.6, { type: 'triangle', vib: 5, vibDepth: 60, vol: 0.06 }); },
    cluck() { for (let i = 0; i < 4; i++) { tone(700 + Math.random() * 300, 0.08, { type: 'square', to: 400, vol: 0.12, delay: i * 0.14 }); } },
    bonk() { tone(300, 0.18, { type: 'square', to: 80, vol: 0.3 }); noise(0.1, { freq: 2000, vol: 0.3 }); },
    zap() { noise(0.4, { filter: 'highpass', freq: 1500, vol: 0.6 }); tone(1200, 0.3, { type: 'sawtooth', to: 60, vol: 0.25 }); },
    card() { noise(0.12, { filter: 'highpass', freq: 2500, vol: 0.25 }); tone(660, 0.08, { type: 'triangle', vol: 0.08, delay: 0.08 }); },
    pop() { tone(500, 0.1, { to: 1400, vol: 0.25 }); },
    alarm() { for (let i = 0; i < 3; i++) { tone(880, 0.16, { type: 'square', vol: 0.1, delay: i * 0.32 }); tone(660, 0.16, { type: 'square', vol: 0.1, delay: i * 0.32 + 0.16 }); } },
    tick() { tone(1500, 0.04, { type: 'square', vol: 0.08 }); },
    fanfare() { [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(f, i === 5 ? 0.6 : 0.16, { type: 'triangle', vol: 0.18, delay: i * 0.12 })); },
    scratch() { noise(0.35, { filter: 'bandpass', freq: 1800, to: 300, vol: 0.5 }); },
    twist() { [392, 494, 587, 784].forEach((f) => tone(f, 0.9, { type: 'triangle', vol: 0.08, attack: 0.05 })); tone(196, 1, { type: 'sine', vol: 0.15 }); },
    turn() { tone(660, 0.1, { type: 'sine', vol: 0.12 }); tone(990, 0.18, { type: 'sine', vol: 0.1, delay: 0.08 }); },
    warp() { tone(200, 0.6, { type: 'sine', to: 1600, vib: 18, vibDepth: 60, vol: 0.18 }); },
    quack() { for (let i = 0; i < 3; i++) tone(500, 0.12, { type: 'sawtooth', to: 280, vol: 0.1, delay: i * 0.18 }); },
    bell() { [1046, 1318].forEach((f, i) => tone(f, 1.2, { type: 'sine', vol: 0.15, delay: i * 0.02 })); },
    rumble() { noise(1.4, { freq: 200, to: 80, vol: 0.7 }); },
    grow() { tone(200, 0.6, { type: 'square', to: 800, vol: 0.1 }); },
    snore() { tone(120, 0.6, { type: 'sawtooth', to: 90, vol: 0.06 }); },
  };

  Sound.play = (name) => { if (!Sound.enabled) return; init(); if (!ctx || !FX[name]) return; try { FX[name](); } catch (e) { /* ignore */ } };
  root.Sound = Sound;
})(globalThis);
