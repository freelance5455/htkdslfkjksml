/* The Chaos Club — translation system.
 * - Every string in the UI comes from a key: I18N.t('game.roll').
 * - Built-in packs (lang/*.js) work offline.
 * - Any other typed language is translated by the server's /api/translate (AI) and cached for the session.
 * - English is the fallback for any missing key. */
(function (root) {
  'use strict';
  const PACKS = root.ChaosLang;
  const EN = PACKS.en;
  const RTL = ['ar', 'he', 'fa', 'ur', 'ps', 'sd', 'yi', 'dv', 'ug', 'ckb'];

  // Aliases for the built-in packs (lowercase, accents removed).
  const BUILTIN_ALIASES = {
    en: ['english', 'en', 'eng', 'inglés', 'ingles', 'anglais', 'englisch', 'อังกฤษ', 'ภาษาอังกฤษ', 'الإنجليزية', 'انجليزي', 'en-us', 'en-gb', 'american', 'british english'],
    th: ['thai', 'th', 'ไทย', 'ภาษาไทย', 'tailandés', 'tailandes', 'thaï', 'thailändisch', 'التايلاندية', 'siamese', 'th-th'],
    es: ['spanish', 'es', 'español', 'espanol', 'castellano', 'castilian', 'espagnol', 'spanisch', 'สเปน', 'ภาษาสเปน', 'الإسبانية', 'es-es', 'es-mx', 'mexican spanish', 'latin american spanish', 'spanish (spain)', 'spanish (mexico)'],
    ar: ['arabic', 'ar', 'عربي', 'العربية', 'عربية', 'árabe', 'arabe', 'arabisch', 'อาหรับ', 'ภาษาอาหรับ', 'ar-sa', 'ar-eg', 'modern standard arabic'],
  };
  // Common names that map to a language code for the AI translator (and for formatting numbers).
  const KNOWN = {
    'korean': 'ko', '한국어': 'ko', '조선말': 'ko', 'japanese': 'ja', '日本語': 'ja', 'nihongo': 'ja',
    'chinese': 'zh-CN', 'mandarin': 'zh-CN', 'simplified chinese': 'zh-CN', '中文': 'zh-CN', '简体中文': 'zh-CN', '普通话': 'zh-CN',
    'traditional chinese': 'zh-TW', '繁體中文': 'zh-TW', 'cantonese': 'yue', '廣東話': 'yue',
    'french': 'fr', 'français': 'fr', 'francais': 'fr', 'german': 'de', 'deutsch': 'de',
    'portuguese': 'pt-PT', 'português': 'pt-PT', 'brazilian portuguese': 'pt-BR', 'portuguese (brazil)': 'pt-BR', 'português brasileiro': 'pt-BR', 'português do brasil': 'pt-BR', 'pt-br': 'pt-BR', 'brazilian': 'pt-BR',
    'italian': 'it', 'italiano': 'it', 'russian': 'ru', 'русский': 'ru', 'hindi': 'hi', 'हिन्दी': 'hi', 'हिंदी': 'hi',
    'vietnamese': 'vi', 'tiếng việt': 'vi', 'indonesian': 'id', 'bahasa indonesia': 'id', 'malay': 'ms', 'bahasa melayu': 'ms',
    'turkish': 'tr', 'türkçe': 'tr', 'dutch': 'nl', 'nederlands': 'nl', 'polish': 'pl', 'polski': 'pl', 'swedish': 'sv', 'svenska': 'sv',
    'norwegian': 'nb', 'norsk': 'nb', 'danish': 'da', 'dansk': 'da', 'finnish': 'fi', 'suomi': 'fi', 'greek': 'el', 'ελληνικά': 'el',
    'hebrew': 'he', 'עברית': 'he', 'persian': 'fa', 'farsi': 'fa', 'فارسی': 'fa', 'urdu': 'ur', 'اردو': 'ur',
    'ukrainian': 'uk', 'українська': 'uk', 'czech': 'cs', 'čeština': 'cs', 'hungarian': 'hu', 'magyar': 'hu', 'romanian': 'ro', 'română': 'ro',
    'filipino': 'fil', 'tagalog': 'tl', 'bengali': 'bn', 'বাংলা': 'bn', 'tamil': 'ta', 'தமிழ்': 'ta', 'telugu': 'te', 'marathi': 'mr',
    'lao': 'lo', 'ລາວ': 'lo', 'khmer': 'km', 'ខ្មែរ': 'km', 'burmese': 'my', 'myanmar': 'my', 'swahili': 'sw', 'kiswahili': 'sw',
    'catalan': 'ca', 'català': 'ca', 'irish': 'ga', 'welsh': 'cy', 'icelandic': 'is', 'esperanto': 'eo', 'latin': 'la',
  };

  const norm = (s) => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ').replace(/^(the )?(language )?/, '').replace(/ language$/, '');

  const I18N = {
    current: EN,
    listeners: [],
    builtinList() { return ['en', 'th', 'es', 'ar'].filter((c) => PACKS[c]).map((c) => PACKS[c].name); },
    suggestions() {
      return [].concat(this.builtinList(), ['한국어 (Korean)', '日本語 (Japanese)', '中文 (Chinese)', 'Français', 'Deutsch', 'Brazilian Portuguese', 'Italiano', 'Tiếng Việt', 'Bahasa Indonesia', 'Русский', 'Türkçe', 'हिन्दी', 'עברית']);
    },
    builtinFor(input) {
      const n = norm(input).replace(/\s*\(.*\)$/, '');
      const full = norm(input);
      for (const code of Object.keys(BUILTIN_ALIASES)) {
        if (!PACKS[code]) continue;
        const names = BUILTIN_ALIASES[code].concat([PACKS[code].name.toLowerCase()]);
        if (names.includes(full) || names.includes(n)) return code;
      }
      return null;
    },
    codeFor(input) { const n = norm(input); return KNOWN[n] || KNOWN[n.replace(/\s*\(.*\)$/, '')] || null; },

    t(key, vars) {
      let s = this.current.strings[key];
      if (s == null) s = EN.strings[key];
      if (s == null) return key;
      if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (vars[k] == null ? m : (typeof vars[k] === 'number' ? this.num(vars[k]) : String(vars[k]))));
      return s;
    },
    has(key) { return this.current.strings[key] != null || EN.strings[key] != null; },
    num(n) { try { return new Intl.NumberFormat(this.current.code).format(n); } catch (e) { return String(n); } },
    get dir() { return this.current.dir || (RTL.includes((this.current.code || '').split('-')[0]) ? 'rtl' : 'ltr'); },

    apply(pack) {
      this.current = pack;
      const html = document.documentElement;
      html.lang = pack.code || 'en';
      html.dir = this.dir;
      try { sessionStorage.setItem('cc.lang', JSON.stringify(pack.code === 'en' || PACKS[pack.code] === pack ? { builtin: pack.code } : pack)); } catch (e) { /* storage blocked */ }
      this.listeners.forEach((fn) => fn(pack));
    },
    onChange(fn) { this.listeners.push(fn); },
    restore() {
      try {
        const saved = JSON.parse(sessionStorage.getItem('cc.lang') || 'null');
        if (saved && saved.builtin && PACKS[saved.builtin]) return this.apply(PACKS[saved.builtin]);
        if (saved && saved.strings) return this.apply(saved);
      } catch (e) { /* ignore */ }
      const nav = (navigator.language || 'en').split('-')[0];
      this.apply(PACKS[nav] || EN);
    },

    /* Set language from free text. Returns { ok, message }.
     * api: { base: string|null, translate: boolean } describing the server, if any. */
    async setFromText(input, api) {
      const text = String(input || '').trim();
      if (!text) return { ok: false, message: '' };
      const builtin = this.builtinFor(text);
      if (builtin) { this.apply(PACKS[builtin]); return { ok: true, message: this.t('settings.langDone', { lang: PACKS[builtin].name }) }; }
      if (!api || !api.base || !api.translate) {
        return { ok: false, message: this.t('settings.langUnknown', { lang: text, list: this.builtinList().join(', ') }) };
      }
      try {
        const r = await fetch(api.base + '/api/translate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ language: text }) });
        const data = await r.json().catch(() => ({}));
        if (r.status === 422) return { ok: false, message: this.t('settings.notLanguage', { lang: text }) };
        if (!r.ok || !data.strings) throw new Error(data.error || 'failed');
        const code = data.lang.code || this.codeFor(text) || 'en';
        const pack = { code, name: data.lang.name || text, dir: data.lang.dir || (RTL.includes(code.split('-')[0]) ? 'rtl' : 'ltr'), strings: data.strings, ai: true };
        this.apply(pack);
        return { ok: true, message: this.t('settings.langDone', { lang: pack.name }) };
      } catch (e) {
        return { ok: false, message: this.t('settings.langFailed', { lang: text }) };
      }
    },
  };

  root.I18N = I18N;
})(globalThis);
