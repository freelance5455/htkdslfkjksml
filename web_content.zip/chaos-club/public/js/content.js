/* The Chaos Club — static game content (board, characters, cards, chaos).
 * All player-facing text lives in /lang/*.js and is looked up by key.
 * Shared by the browser and the Node server. */
(function (root) {
  'use strict';

  // 32 tiles. 0 = Launch Pad (bottom-right corner), moving clockwise.
  const BOARD = [
    { t: 'start' },
    { t: 'prop', id: 'waffle', g: 'brown', price: 60, icon: '🧇' },
    { t: 'chaos' },
    { t: 'prop', id: 'sock', g: 'brown', price: 60, icon: '🧦' },
    { t: 'tax', id: 'snack', amt: 75, icon: '🍿' },
    { t: 'prop', id: 'bubble', g: 'sky', price: 100, icon: '🫧' },
    { t: 'surprise' },
    { t: 'prop', id: 'zoo', g: 'sky', price: 110, icon: '🦒' },
    { t: 'nap' },
    { t: 'prop', id: 'trampoline', g: 'pink', price: 140, icon: '📚' },
    { t: 'mini' },
    { t: 'prop', id: 'disco', g: 'pink', price: 150, icon: '🪩' },
    { t: 'worm', to: 28 },
    { t: 'prop', id: 'bouncy', g: 'orange', price: 180, icon: '🏰' },
    { t: 'chaos' },
    { t: 'prop', id: 'volcano', g: 'orange', price: 190, icon: '🍝' },
    { t: 'pot' },
    { t: 'prop', id: 'cheese', g: 'red', price: 220, icon: '🧀' },
    { t: 'surprise' },
    { t: 'prop', id: 'pillow', g: 'red', price: 230, icon: '🛏️' },
    { t: 'tax', id: 'dentist', amt: 100, icon: '🦷' },
    { t: 'prop', id: 'salon', g: 'yellow', price: 260, icon: '💇' },
    { t: 'mini' },
    { t: 'prop', id: 'pickle', g: 'yellow', price: 270, icon: '🥒' },
    { t: 'banana' },
    { t: 'prop', id: 'pizza', g: 'green', price: 300, icon: '🍕' },
    { t: 'chaos' },
    { t: 'prop', id: 'llama', g: 'green', price: 310, icon: '🦙' },
    { t: 'worm', to: 12 },
    { t: 'prop', id: 'toilet', g: 'blue', price: 350, icon: '🚽' },
    { t: 'surprise' },
    { t: 'prop', id: 'cloud', g: 'blue', price: 400, icon: '☁️' },
  ];

  const TILE_ICONS = { start: '🚀', chaos: '🌀', surprise: '🎁', nap: '😴', mini: '🔮', worm: '🕳️', pot: '🍲', banana: '🍌' };

  const GROUPS = {
    brown: '#B08A62', sky: '#64D2FF', pink: '#FF6FAE', orange: '#FF9F0A',
    red: '#FF453A', yellow: '#FFD60A', green: '#32D74B', blue: '#0A84FF',
  };

  const CHARACTERS = [
    { id: 'chicken', e: '🐔' }, { id: 'potato', e: '🥔' }, { id: 'rex', e: '🦖' },
    { id: 'alien', e: '👽' }, { id: 'robot', e: '🤖' }, { id: 'octo', e: '🐙' },
    { id: 'frog', e: '🐸' }, { id: 'unicorn', e: '🦄' }, { id: 'penguin', e: '🐧' },
    { id: 'sloth', e: '🦥' }, { id: 'banana', e: '🍌' }, { id: 'ghost', e: '👻' },
  ];

  const COLORS = ['#FF453A', '#FF9F0A', '#FFD60A', '#32D74B', '#64D2FF', '#0A84FF', '#BF5AF2', '#FF375F'];

  // fx keys: money, range, each (+ collect from each / - pay each), perProp, nap,
  // shield, extra, swap, move, goto, randomTile, potHalf
  const CHAOS_CARDS = [
    { id: 'grandma', w: 3, fx: { money: -50 } },
    { id: 'potatoCeo', w: 2, fx: { money: 200 } },
    { id: 'sandwich', w: 3, fx: { money: -30 } },
    { id: 'jeans', w: 3, fx: { money: 75 } },
    { id: 'hiccup', w: 3, fx: { move: 3 } },
    { id: 'llamaSpit', w: 3, fx: { money: -40 } },
    { id: 'toothFairy', w: 3, fx: { money: 60 } },
    { id: 'bathtub', w: 2, fx: { each: 25 } },
    { id: 'karaoke', w: 2, fx: { each: -15 } },
    { id: 'pillowNap', w: 2, fx: { nap: true } },
    { id: 'wizardShield', w: 2, fx: { shield: true } },
    { id: 'moonwalk', w: 3, fx: { move: -3 } },
    { id: 'rocketShoes', w: 2, fx: { goto: 0 } },
    { id: 'catPresident', w: 3, fx: { money: -45 } },
    { id: 'noodles', w: 3, fx: { money: 90 } },
    { id: 'termites', w: 2, fx: { perProp: 20 } },
    { id: 'swappo', w: 2, fx: { swap: true } },
    { id: 'juiceBox', w: 2, fx: { extra: true } },
    { id: 'duckCollection', w: 2, fx: { money: 110 } },
    { id: 'pigeonFine', w: 3, fx: { money: -35 } },
    { id: 'sneezeLaunch', w: 2, fx: { goto: 15 } },
    { id: 'lotteryTicket', w: 2, fx: { money: 5 } },
    { id: 'wizardTax', w: 2, fx: { money: -60 } },
    { id: 'viralDance', w: 2, fx: { each: 20 } },
  ];

  const SURPRISE_CARDS = [
    { id: 'boxInBox', w: 3, fx: { money: 150 } },
    { id: 'potRecipe', w: 2, fx: { potHalf: true } },
    { id: 'cloudRide', w: 2, fx: { goto: 31 } },
    { id: 'bees', w: 3, fx: { money: -40 } },
    { id: 'birthday', w: 2, fx: { each: 30 } },
    { id: 'bubbleWrap', w: 2, fx: { shield: true } },
    { id: 'goldenSpoon', w: 3, fx: { money: 100 } },
    { id: 'confettiOnly', w: 2, fx: { money: 10 } },
    { id: 'mysteryCheck', w: 3, fx: { range: [20, 200] } },
    { id: 'tinyWormhole', w: 2, fx: { randomTile: true } },
    { id: 'snailMail', w: 3, fx: { money: 70 } },
    { id: 'threeSleeves', w: 2, fx: { money: 85 } },
    { id: 'extraRoll', w: 2, fx: { extra: true } },
    { id: 'pizzaPromise', w: 2, fx: { each: -25 } },
    { id: 'sockLawyer', w: 2, fx: { money: 120 } },
    { id: 'kangaroo', w: 2, fx: { move: 5 } },
  ];

  // Small, frequent mini-events (no resolve on movement).
  const SMALL = [
    { id: 'pigeonDrop', w: 3, fx: { money: 15 } },
    { id: 'whoopee', w: 3, fx: { money: -5 } },
    { id: 'sneezeSlide', w: 2, fx: { move: 1 } },
    { id: 'butterfly', w: 3, fx: { money: 20 } },
    { id: 'underBoard', w: 3, fx: { money: 12 } },
    { id: 'seagull', w: 3, fx: { money: -15 } },
    { id: 'coolFlip', w: 2, fx: { money: 0 } },
    { id: 'dragonSneeze', w: 2, fx: { money: -20 } },
    { id: 'samples', w: 2, fx: { money: 10 } },
    { id: 'shoelace', w: 2, fx: { move: -1 } },
    { id: 'ghostTip', w: 2, fx: { money: 25 } },
    { id: 'squirrel', w: 3, fx: { money: -10 } },
  ];

  // Major chaos events. w = weight. Logic lives in engine.js.
  const MAJOR = {
    meteor: { w: 5, icon: '☄️' }, coinBlast: { w: 6, icon: '💥' }, hammer: { w: 5, icon: '🔨' },
    quake: { w: 4, icon: '🌋' }, ufo: { w: 4, icon: '🛸' }, chicken: { w: 5, icon: '🐔' },
    richAunt: { w: 3, icon: '💰' }, taxman: { w: 4, icon: '🎩' }, tornado: { w: 3, icon: '🌪️' },
    bomb: { w: 4, icon: '💣' }, coinShower: { w: 5, icon: '🪙' }, giant: { w: 4, icon: '🍄' },
    millionaire: { w: 3, icon: '🤑' }, auction: { w: 3, icon: '🔔' }, transform: { w: 3, icon: '🔀' },
    gift: { w: 6, icon: '🎁' }, fakeWin: { w: 2, icon: '🏆' }, lightning: { w: 4, icon: '⚡' },
    robinHood: { w: 3, icon: '🏹' }, duckFlood: { w: 3, icon: '🦆' },
  };

  // Global twists, rolled at the start of a round. round:true = lasts the round.
  const TWISTS = {
    doubleMoney: { w: 4, round: true, icon: '💸' }, inflation: { w: 4, round: true, icon: '🎈' },
    musicalChairs: { w: 3, icon: '🪑' }, richGetRicher: { w: 3, icon: '🎩' },
    bankruptcyDay: { w: 3, icon: '📉' }, gravity: { w: 3, round: true, icon: '🪐' },
    chaosMode: { w: 3, round: true, icon: '🌀' }, chickenInvasion: { w: 3, round: true, icon: '🐔' },
    reverseDay: { w: 3, icon: '🔄' }, mysteryBox: { w: 3, icon: '📦' },
    slippery: { w: 3, round: true, icon: '🧼' }, rentFreeze: { w: 3, round: true, icon: '🧊' },
    birthday: { w: 3, icon: '🎂' }, moonwalk: { w: 2, round: true, icon: '🕺' },
    discoNight: { w: 3, round: true, icon: '🪩' }, groupHug: { w: 2, icon: '🤗' },
    turbo: { w: 3, round: true, icon: '🏎️' },
  };

  const RULES = { startCoins: 750, passStart: 150, landStart: 100, rescue: 300 };

  const api = { BOARD, TILE_ICONS, GROUPS, CHARACTERS, COLORS, CHAOS_CARDS, SURPRISE_CARDS, SMALL, MAJOR, TWISTS, RULES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ChaosContent = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
