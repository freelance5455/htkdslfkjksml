# 📱 Turning The Chaos Club into an Android APK

There are three ways, from easiest to most hands-on. **Way 1 needs no computer and no Android tools.**

---

## Way 1 — Let GitHub build the APK for you (free, works from a phone or a computer)

The project includes a ready-made build script (`.github/workflows/android.yml`). GitHub runs it on its own servers and gives you `ChaosClub.apk`.

### 1. Put the project on GitHub
1. Sign in at **github.com** (or create a free account).
2. Tap **+ → New repository**. Name it `chaos-club` and make it **Public** or **Private**. Tick **Add a README file** and tap **Create repository**.
3. Add the files:
   - **On a computer:** unzip `chaos-club.zip`, open the repository, choose **Add file → Upload files**, and drag *everything inside* the `chaos-club` folder onto the page. That includes the hidden `.github` folder (on a Mac, press **⌘ ⇧ .** in Finder to show hidden files). Then tap **Commit changes**.
   - **On a phone:** uploading a folder tree is awkward. The simplest route is GitHub Desktop or a computer for this one step. Or upload the files, then do step 4 below to add the build script by hand.
4. *(Only if the `.github` folder didn't upload)* In the repository, open **Actions → set up a workflow yourself**. Name the file `android.yml`, paste in the contents of `.github/workflows/android.yml` from the zip, and tap **Commit changes**.

### 2. Build
1. Open the **Actions** tab and tap **Build Android APK → Run workflow**.
2. *(Optional)* In **server_url**, paste the address of your Chaos Club server (see "Online play" below). Leave it empty for play on one device.
3. Tap the green **Run workflow** button. It takes about 5–8 minutes.

### 3. Install on your phone
1. When the run turns green ✅, open the repository's **Releases** (on the main page, right side, or at `github.com/YOU/chaos-club/releases`).
2. Download **ChaosClub.apk** on your Android phone and tap it.
3. If Android asks, allow **Install unknown apps** for your browser, then tap **Install**.

> This is a *debug-signed* APK, which is perfect for installing on your own and your friends' phones. Android may show a "Play Protect" warning because it isn't from the Play Store. Tap **Install anyway**. To publish on Google Play you'd need a release-signed AAB. Way 3 covers that.

---

## Way 2 — PWABuilder (no GitHub, but needs the game hosted online)

1. Deploy the game online first (see **Deploy it online** in `README.md`; Render's free tier works). You'll get an address like `https://chaos-club.onrender.com`.
2. Open **https://www.pwabuilder.com**, paste that address and tap **Start**.
3. Choose **Package for stores → Android → Generate Package**, then download the zip. Inside are an `.apk` you can install right away and an `.aab` for the Play Store.

The game includes a web-app manifest, icons and an offline service worker, so it qualifies. Because this APK opens your hosted site, **online rooms and AI translation work automatically**.

**Even simpler (not an APK):** open the hosted game in Chrome on Android, then tap **⋮ → Install app** (or **Add to Home screen**). It gets its own icon and opens full-screen like an app.

---

## Way 3 — Build on your own computer (Android Studio)

You need **Node.js 22**, **JDK 21** and **Android Studio**.

```bash
cd chaos-club
npm install --no-save @capacitor/core @capacitor/cli @capacitor/android @capacitor/assets
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
cd android && ./gradlew assembleDebug        # APK → android/app/build/outputs/apk/debug/app-debug.apk
```

Or run `npx cap open android` and use **Build → Build Bundle(s) / APK(s)** in Android Studio. For the Play Store, use **Build → Generate Signed Bundle / APK** and create your own signing key.

After changing the game, run `npx cap sync android` again before rebuilding.

---

## Online play inside the APK

The APK contains the whole game, so **local play (2–4 players, computer players, all chaos, the four built-in languages) works with no internet.**

Online rooms and AI translation need a running Chaos Club server, because the APK can't host one itself. Deploy `server.js` once (see `README.md`), then either:
- paste its address into **server_url** when you run the GitHub build (Way 1), or
- in the app, open **Settings ⚙︎ → Online**, enter the address and tap **Test connection**.

Everyone in a room must use the same server. Friends can join from the APK, from a browser, or from a mix of both.
