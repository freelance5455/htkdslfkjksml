# 🐔 The Chaos Club

A chaotic, family-friendly board game for 2–4 players that runs in the browser. It looks like a native macOS app (dark mode, translucent glass, menu bar, traffic-light window controls, Dock).

- **Play on one device** with 2–4 players. Each seat can be a human or a computer player.
- **Play online** in real rooms. One person creates a room, friends join with a 5-letter code, and the server keeps every turn, dice roll, move, coin and event in sync.
- **Type any language.** Thai, Spanish and Arabic (right-to-left) are built in, alongside English. Any other language is translated live by AI once you add an API key.
- **Chaos everywhere:** 20 animated chaos events, 17 round twists, 40 event cards and 12 mini-events, with weighting and cooldowns so no two games play the same.

No frameworks and no build step. The client is plain HTML, CSS and JavaScript. The server is a single Node.js file with **zero npm dependencies**.

---

## Run it locally

You need **Node.js 18 or newer** (Node 22 recommended).

```bash
cd chaos-club
node server.js
```

Open **http://localhost:8080**. That's it: local play, online rooms and the built-in languages all work.

To play online with friends on the same Wi-Fi, they open `http://YOUR-COMPUTER-IP:8080` (for example `http://192.168.1.20:8080`), choose **Play online** and type your room code.

### Optional: AI translation into any language

Built-in languages work without any setup. To let players type **any** language (Korean, Japanese, Brazilian Portuguese, French, Swahili, "Pirate English"…), give the server an Anthropic API key:

```bash
ANTHROPIC_API_KEY=sk-ant-... node server.js
```

- Get a key at https://console.anthropic.com (API usage is billed to your account).
- The server translates the whole game, about 460 strings, once per language. It checks that every `{placeholder}` survived and keeps English for any string that didn't. Results are cached in `.translation-cache/`, so each language is only paid for once.
- You can change the model with `TRANSLATE_MODEL` (default: `claude-haiku-5-5`).
- Without a key, the game says so plainly when someone types a language that isn't built in. It never pretends to translate.

### Environment variables

| Variable | Default | What it does |
|---|---|---|
| `PORT` | `8080` | Port to listen on |
| `ANTHROPIC_API_KEY` | – | Turns on AI translation for any language |
| `TRANSLATE_MODEL` | `claude-haiku-5-5` | Model used for translation |
| `ANTHROPIC_BASE_URL` | `https://api.anthropic.com` | Override the API host (proxies, testing) |
| `AUTO_PLAY_MS` | `15000` | How long to wait before the server moves for a disconnected player |

---

## Deploy it online

The server is one long-running Node process that serves the website and the WebSocket rooms on the same port. Any host that runs Node and supports WebSockets will work.

### Render / Railway / Fly.io / any Node host
1. Push this folder to a GitHub repository.
2. Create a new **Web Service** from the repo.
3. Set the **start command** to `node server.js`. There is no build command.
4. *(Optional)* Add `ANTHROPIC_API_KEY` as an environment variable.
5. Open the URL the host gives you. Online rooms use `wss://` automatically on HTTPS.

Most platforms set `PORT` for you, and the server reads it.

### Docker
```bash
docker build -t chaos-club .
docker run -p 8080:8080 -e ANTHROPIC_API_KEY=sk-ant-... chaos-club
```

### A VPS behind nginx
Proxy both normal requests and the WebSocket upgrade:
```nginx
location / {
  proxy_pass http://127.0.0.1:8080;
  proxy_http_version 1.1;
  proxy_set_header Upgrade $http_upgrade;
  proxy_set_header Connection "upgrade";
  proxy_set_header Host $host;
}
```

### Static hosting (GitHub Pages, Netlify, …)
You can host the `public/` folder on its own for **local play and built-in languages**. For online rooms and AI translation, the page needs a running Chaos Club server. Open **Settings › Online** and enter that server's address (for example `https://chaos.example.com`). The server sends CORS headers, so this works across domains.

> Note: rooms live in the server's memory. A restart clears rooms in progress, which is fine for casual game nights. Run a single instance; don't scale horizontally without adding shared state.

---

## Android app (APK)

See **[BUILD_APK.md](BUILD_APK.md)**. The included GitHub workflow builds `ChaosClub.apk` in the cloud: open **Actions → Build Android APK → Run workflow**, then download the APK from Releases. The game is also an installable web app: in Chrome, use **Install app**.

---

## How to play (short version)

- **Goal:** have the highest net worth (coins + places) when the last round ends, or be the last one standing.
- **Turn:** roll two dice and move. Doubles roll again, but three doubles in a row sends you to nap.
- **Places:** buy unowned places. Others pay you rent. Land on your own place to upgrade it (up to ★★★). A full color set doubles rent.
- **Special spaces:** 🌀 Chaos Card · 🎁 Surprise Box · 🔮 Higher or Lower · 🕳️ Wormhole · 🍲 Chicken Pot (collects all taxes) · 🍌 Banana Peel · 😴 Nap Pod · 🚀 Launch Pad.
- **Chaos meter:** fills every turn. When it pops (or at random), a major event hits: meteors, UFO abductions, giant chicken stampedes, bombs, tornadoes, sudden auctions, fake victories…
- **Round twists:** some rounds start with a global rule change: Double Money, Great Inflation, Moonwalk Round, Gravity Failure, Chicken Invasion, Reverse Day, Turbo Round and more.
- **Safety net:** Grandma's Emergency Fund rescues each player once. The second time you run out, you're out.

Choose **Quick (10)**, **Classic (15)** or **Epic (20)** rounds. That's about 15, 25 or 35 minutes with 3–4 players. Choose **Chill**, **Chaotic** or **Absolute Mayhem** for how often chaos strikes.

**Shortcuts:** `Space` roll · `M` mute · `F` full screen · `?` rules · `⌘,` settings · click the board to fast-forward animations.

---

## Project layout

```
server.js              Node server: static files, WebSocket rooms (hand-written RFC 6455), /api/translate
public/
  index.html           App shell: menu bar, window, Dock
  css/style.css        macOS-style dark UI, board, tokens, effects
  js/content.js        Board, characters, cards, chaos and twist definitions (no text)
  js/engine.js         Rules engine, shared by the browser (local games) and the server (online games)
  js/i18n.js           Translation system: keys, aliases, built-in packs, AI fallback, RTL
  js/fx.js             Particles, flying emoji, explosions, lightning, screen shake
  js/sound.js          Synthesized sound effects (Web Audio, no audio files)
  js/net.js            WebSocket client with auto-reconnect and room rejoin
  js/app.js            Screens, board rendering, event playback, chaos animations, lobby
  lang/en.js th.js es.js ar.js   Language packs (every visible string lives here)
test/
  simulate.js          Plays 1,500 bot games through the engine and checks invariants
  i18n_check.js        Verifies every pack has every key with matching {placeholders}
  ui_*.py              Browser tests (Playwright): local game, chaos visuals, languages, two-player online
```

### Architecture notes
- **Server-authoritative online play.** Clients send intents (`roll`, `buy`, `bid`…). The server runs the same `engine.js`, rejects anything out of turn, and broadcasts the resulting events. Each event carries a snapshot of the game state, so every screen animates the same story and ends on exactly the same state. Rejoining after a disconnect restores your seat. If a player is offline on their turn, the server moves for them.
- **Translation architecture.** Every visible string comes from a key (`I18N.t('game.roll')`). Player names, tiles and log entries are stored as references and translated when shown, so switching language mid-game re-translates everything, including the event log. The language choice is remembered for the session.

### Tests
```bash
node test/simulate.js      # engine: 1,500 full games, no stuck states or negative balances
node test/i18n_check.js    # language packs complete
# browser tests need Playwright + Chrome and a running server:
python3 test/ui_smoke.py
```

### Adding a language pack
Copy `public/lang/es.js` to `public/lang/xx.js`, translate the values (keep every `{placeholder}`), add a `<script>` tag in `index.html`, and add aliases to `BUILTIN_ALIASES` in `js/i18n.js`. Run `node test/i18n_check.js`.
