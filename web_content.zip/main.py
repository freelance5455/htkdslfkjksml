<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Absensi GPS & Kamera</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
<style>
* { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f0f2f5; color:#333; padding-bottom:80px; }
.header { background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; padding:20px 16px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,.15); }
.header h1 { font-size:20px; margin-bottom:4px; }
.header p { font-size:12px; opacity:.9; }
.container { padding:16px; max-width:600px; margin:0 auto; }
.card { background:#fff; border-radius:14px; padding:16px; margin-bottom:14px; box-shadow:0 2px 10px rgba(0,0,0,.06); }
.card h2 { font-size:16px; margin-bottom:12px; color:#444; display:flex; align-items:center; gap:8px; }
.profile-section { display:flex; align-items:center; gap:14px; }
.avatar { width:70px; height:70px; border-radius:50%; background:#ddd; display:flex; align-items:center; justify-content:center; overflow:hidden; cursor:pointer; border:3px solid #667eea; flex-shrink:0; }
.avatar img { width:100%; height:100%; object-fit:cover; }
.avatar svg { width:36px; height:36px; fill:#888; }
.profile-info { flex:1; }
.profile-info input { width:100%; padding:8px; margin-bottom:6px; border:1px solid #ddd; border-radius:8px; font-size:13px; }
.btn { padding:12px 16px; border:none; border-radius:10px; font-size:14px; font-weight:600; cursor:pointer; transition:.2s; display:inline-flex; align-items:center; justify-content:center; gap:6px; }
.btn:active { transform:scale(.97); }
.btn-primary { background:#667eea; color:#fff; }
.btn-success { background:#10b981; color:#fff; }
.btn-danger { background:#ef4444; color:#fff; }
.btn-warning { background:#f59e0b; color:#fff; }
.btn-outline { background:#fff; color:#667eea; border:2px solid #667eea; }
.btn-block { width:100%; }
.btn-row { display:flex; gap:10px; margin-top:10px; }
.btn-row .btn { flex:1; }
.status-box { background:#f8f9ff; border-left:4px solid #667eea; padding:12px; border-radius:8px; margin-bottom:12px; font-size:13px; line-height:1.6; }
.status-box .row { display:flex; justify-content:space-between; }
.status-box .label { color:#666; }
.status-box .value { font-weight:600; color:#333; }
.badge { display:inline-block; padding:3px 8px; border-radius:20px; font-size:11px; font-weight:600; }
.badge-green { background:#d1fae5; color:#065f46; }
.badge-red { background:#fee2e2; color:#991b1b; }
.badge-yellow { background:#fef3c7; color:#92400e; }
.badge-blue { background:#dbeafe; color:#1e40af; }
.form-group { margin-bottom:10px; }
.form-group label { display:block; font-size:12px; color:#666; margin-bottom:4px; font-weight:500; }
.form-group input, .form-group select { width:100%; padding:9px 10px; border:1px solid #ddd; border-radius:8px; font-size:13px; }
.grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.grid-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; }
.tab-bar { display:flex; background:#fff; border-radius:12px; padding:4px; margin-bottom:14px; box-shadow:0 2px 8px rgba(0,0,0,.06); overflow-x:auto; }
.tab-bar button { flex:1; padding:9px 6px; border:none; background:transparent; border-radius:8px; font-size:12px; font-weight:600; color:#888; cursor:pointer; white-space:nowrap; }
.tab-bar button.active { background:#667eea; color:#fff; }
.tab-content { display:none; }
.tab-content.active { display:block; }
.record-item { background:#f8f9ff; border-radius:10px; padding:12px; margin-bottom:8px; font-size:12px; }
.record-item .head { display:flex; justify-content:space-between; margin-bottom:6px; font-weight:600; }
.record-item .detail { color:#666; line-height:1.7; }
.record-actions { display:flex; gap:6px; margin-top:8px; }
.record-actions button { padding:5px 10px; font-size:11px; border-radius:6px; border:none; cursor:pointer; }
.edit-btn { background:#dbeafe; color:#1e40af; }
.del-btn { background:#fee2e2; color:#991b1b; }
.modal { display:none; position:fixed; inset:0; background:rgba(0,0,0,.7); z-index:1000; align-items:center; justify-content:center; padding:16px; }
.modal.show { display:flex; }
.modal-content { background:#fff; border-radius:16px; width:100%; max-width:480px; max-height:90vh; overflow-y:auto; }
.modal-header { padding:16px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center; }
.modal-header h3 { font-size:16px; }
.modal-header button { background:none; border:none; font-size:24px; cursor:pointer; color:#888; }
.modal-body { padding:16px; }
.camera-preview { width:100%; border-radius:12px; background:#000; max-height:400px; object-fit:cover; }
.camera-wrap { position:relative; border-radius:12px; overflow:hidden; background:#000; }
.camera-overlay { position:absolute; bottom:12px; left:0; right:0; text-align:center; color:#fff; font-size:11px; text-shadow:0 1px 4px #000; }
.empty { text-align:center; padding:30px 10px; color:#999; font-size:13px; }
.summary-box { background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; border-radius:12px; padding:14px; margin-bottom:12px; }
.summary-box .item { display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px; }
.summary-box .item:last-child { margin-bottom:0; padding-top:8px; border-top:1px solid rgba(255,255,255,.3); font-weight:700; font-size:15px; }
.hint { font-size:11px; color:#888; margin-top:4px; }
.period-actions { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
.period-actions button { flex:1; min-width:120px; font-size:12px; }
</style>
</head>
<body>

<div class="header">
  <h1 id="appTitle">Absensi GPS & Kamera</h1>
  <p id="appSubtitle">Check In / Check Out Real-Time</p>
</div>

<div class="container">

  <!-- TAB BAR -->
  <div class="tab-bar">
    <button class="active" onclick="switchTab('home')">🏠 Absen</button>
    <button onclick="switchTab('riwayat')">📋 Riwayat</button>
    <button onclick="switchTab('pengaturan')">⚙️ Pengaturan</button>
    <button onclick="switchTab('laporan')">📄 Laporan</button>
  </div>

  <!-- ===== TAB HOME ===== -->
  <div id="tab-home" class="tab-content active">

    <div class="card">
      <h2>👤 Profil</h2>
      <div class="profile-section">
        <div class="avatar" onclick="document.getElementById('profileInput').click()">
          <img id="profileImg" style="display:none;">
          <svg id="profileIcon" viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
        </div>
        <input type="file" id="profileInput" accept="image/*" style="display:none" onchange="uploadProfile(event)">
        <div class="profile-info">
          <input type="text" id="inputNama" placeholder="Nama" onchange="saveProfile()">
          <input type="text" id="inputJabatan" placeholder="Jabatan" onchange="saveProfile()">
          <input type="text" id="inputPerusahaan" placeholder="Perusahaan" onchange="saveProfile()">
        </div>
      </div>
    </div>

    <div class="card">
      <h2>📍 Status Hari Ini</h2>
      <div class="status-box" id="statusBox">Memuat...</div>
      <div class="btn-row">
        <button class="btn btn-success btn-block" onclick="startCheck('in')">✅ CHECK IN</button>
        <button class="btn btn-danger btn-block" onclick="startCheck('out')">🚪 CHECK OUT</button>
      </div>
      <p class="hint">Kamera akan terbuka otomatis. Tekan tombol capture untuk menyimpan absen.</p>
    </div>

  </div>

  <!-- ===== TAB RIWAYAT ===== -->
  <div id="tab-riwayat" class="tab-content">
    <div class="card">
      <h2>📋 Riwayat Absensi</h2>
      <div id="riwayatList"></div>
    </div>
  </div>

  <!-- ===== TAB PENGATURAN ===== -->
  <div id="tab-pengaturan" class="tab-content">
    <div class="card">
      <h2>⏰ Jam Kerja</h2>
      <div class="grid-2">
        <div class="form-group">
          <label>Jam Check In Normal</label>
          <input type="time" id="setJamMasuk" value="08:00" onchange="saveSettings()">
        </div>
        <div class="form-group">
          <label>Jam Check Out Normal</label>
          <input type="time" id="setJamKeluar" value="17:00" onchange="saveSettings()">
        </div>
      </div>
      <p class="hint">Check in sebelum jam normal tetap dihitung normal (tidak lembur/terlambat).</p>
    </div>

    <div class="card">
      <h2>💰 Pengaturan Upah</h2>
      <div class="form-group">
        <label>Upah Harian (Rp)</label>
        <input type="number" id="setUpahHarian" value="100000" onchange="saveSettings()">
      </div>
      <div class="form-group">
        <label>Upah Lembur per Menit (Rp)</label>
        <input type="number" id="setUpahLembur" value="500" onchange="saveSettings()">
      </div>
      <div class="form-group">
        <label>Tunjangan Bulanan (Rp)</label>
        <input type="number" id="setTunjanganBulanan" value="0" onchange="saveSettings()">
      </div>
      <div class="form-group">
        <label>Tunjangan Lain-lain (Rp)</label>
        <input type="number" id="setTunjanganLain" value="0" onchange="saveSettings()">
      </div>
      <p class="hint">Tunjangan bulanan & lain-lain akan dibagi proporsional per hari kerja.</p>
    </div>
  </div>

  <!-- ===== TAB LAPORAN ===== -->
  <div id="tab-laporan" class="tab-content">
    <div class="card">
      <h2>📄 Laporan Periode</h2>
      <div class="grid-2">
        <div class="form-group">
          <label>Dari Tanggal</label>
          <input type="date" id="lapDari">
        </div>
        <div class="form-group">
          <label>Sampai Tanggal</label>
          <input type="date" id="lapSampai">
        </div>
      </div>
      <div id="lapSummary"></div>
      <div class="period-actions">
        <button class="btn btn-primary" onclick="hitungLaporan(true)">🧾 Cetak PDF + Tunjangan</button>
        <button class="btn btn-outline" onclick="hitungLaporan(false)">📄 Cetak PDF Tanpa Tunjangan</button>
        <button class="btn btn-danger" onclick="hapusPeriode()">🗑️ Hapus Data Periode</button>
      </div>
    </div>
  </div>

</div>

<!-- ===== MODAL KAMERA ===== -->
<div class="modal" id="cameraModal">
  <div class="modal-content">
    <div class="modal-header">
      <h3 id="cameraTitle">Ambil Foto Absen</h3>
      <button onclick="closeCamera()">×</button>
    </div>
    <div class="modal-body">
      <div class="camera-wrap">
        <video id="video" class="camera-preview" autoplay playsinline></video>
        <canvas id="canvas" style="display:none"></canvas>
        <div class="camera-overlay" id="cameraInfo">Memuat lokasi...</div>
      </div>
      <div class="btn-row">
        <button class="btn btn-outline" onclick="closeCamera()">Batal</button>
        <button class="btn btn-success btn-block" onclick="capturePhoto()">📸 Capture & Simpan</button>
      </div>
    </div>
  </div>
</div>

<!-- ===== MODAL EDIT ===== -->
<div class="modal" id="editModal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Koreksi Absen</h3>
      <button onclick="closeEdit()">×</button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label>Jam Check In</label>
        <input type="time" id="editIn">
      </div>
      <div class="form-group">
        <label>Jam Check Out</label>
        <input type="time" id="editOut">
      </div>
      <p class="hint" id="editHint"></p>
      <div class="btn-row">
        <button class="btn btn-outline" onclick="closeEdit()">Batal</button>
        <button class="btn btn-primary btn-block" onclick="simpanEdit()">💾 Simpan</button>
      </div>
    </div>
  </div>
</div>

<script>
// ==================== STATE ====================
let state = {
  profile: { nama:'', jabatan:'', perusahaan:'', foto:'' },
  settings: { jamMasuk:'08:00', jamKeluar:'17:00', upahHarian:100000, upahLembur:500, tunjanganBulanan:0, tunjanganLain:0 },
  records: [],
  currentCheck: null,
  currentLoc: null,
  stream: null,
  editTarget: null,
  editCount: 0
};

const STORAGE_KEY = 'absensi_app_v1';

function loadState() {
  try {
    const s = localStorage.getItem(STORAGE_KEY);
    if (s) {
      const parsed = JSON.parse(s);
      state = { ...state, ...parsed };
    }
  } catch(e) { console.log(e); }
}

function saveState() {
  const toSave = {
    profile: state.profile,
    settings: state.settings,
    records: state.records,
    editCount: state.editCount
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
}

// ==================== UTIL ====================
function pad(n){ return String(n).padStart(2,'0'); }
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}
function nowTime() {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function nowFull() {
  const d = new Date();
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function timeToMin(t) {
  if (!t) return 0;
  const [h,m] = t.split(':').map(Number);
  return h*60 + m;
}
function minToTime(m) {
  m = Math.max(0, Math.round(m));
  return `${pad(Math.floor(m/60))}:${pad(m%60)}`;
}
function rupiah(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}
function formatTanggal(s) {
  if (!s) return '-';
  const [y,m,d] = s.split('-');
  const bulan = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
  return `${d} ${bulan[parseInt(m)-1]} ${y}`;
}
function getEditCount() {
  const today = todayStr();
  const key = 'editCount_' + today;
  return parseInt(localStorage.getItem(key) || '0');
}
function setEditCount(n) {
  const today = todayStr();
  localStorage.setItem('editCount_' + today, n);
}

// ==================== NAVIGASI ====================
function switchTab(t) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-bar button').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + t).classList.add('active');
  event.target.classList.add('active');
  if (t === 'riwayat') renderRiwayat();
  if (t === 'laporan') initLaporan();
}

// ==================== PROFIL ====================
function loadProfile() {
  document.getElementById('inputNama').value = state.profile.nama || '';
  document.getElementById('inputJabatan').value = state.profile.jabatan || '';
  document.getElementById('inputPerusahaan').value = state.profile.perusahaan || '';
  if (state.profile.foto) {
    document.getElementById('profileImg').src = state.profile.foto;
    document.getElementById('profileImg').style.display = 'block';
    document.getElementById('profileIcon').style.display = 'none';
  }
  document.getElementById('appTitle').textContent = state.profile.perusahaan || 'Absensi GPS & Kamera';
  document.getElementById('appSubtitle').textContent = state.profile.nama ? `${state.profile.nama} - ${state.profile.jabatan || ''}` : 'Check In / Check Out Real-Time';
}

function saveProfile() {
  state.profile.nama = document.getElementById('inputNama').value;
  state.profile.jabatan = document.getElementById('inputJabatan').value;
  state.profile.perusahaan = document.getElementById('inputPerusahaan').value;
  saveState();
  loadProfile();
}

function uploadProfile(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    state.profile.foto = ev.target.result;
    saveState();
    loadProfile();
  };
  reader.readAsDataURL(file);
}

// ==================== SETTINGS ====================
function loadSettings() {
  document.getElementById('setJamMasuk').value = state.settings.jamMasuk;
  document.getElementById('setJamKeluar').value = state.settings.jamKeluar;
  document.getElementById('setUpahHarian').value = state.settings.upahHarian;
  document.getElementById('setUpahLembur').value = state.settings.upahLembur;
  document.getElementById('setTunjanganBulanan').value = state.settings.tunjanganBulanan;
  document.getElementById('setTunjanganLain').value = state.settings.tunjanganLain;
}
function saveSettings() {
  state.settings.jamMasuk = document.getElementById('setJamMasuk').value;
  state.settings.jamKeluar = document.getElementById('setJamKeluar').value;
  state.settings.upahHarian = parseFloat(document.getElementById('setUpahHarian').value) || 0;
  state.settings.upahLembur = parseFloat(document.getElementById('setUpahLembur').value) || 0;
  state.settings.tunjanganBulanan = parseFloat(document.getElementById('setTunjanganBulanan').value) || 0;
  state.settings.tunjanganLain = parseFloat(document.getElementById('setTunjanganLain').value) || 0;
  saveState();
}

// ==================== STATUS HARI INI ====================
function renderStatus() {
  const today = todayStr();
  const rec = state.records.find(r => r.tanggal === today);
  const box = document.getElementById('statusBox');
  const now = nowTime();
  const jm = timeToMin(state.settings.jamMasuk);
  const jk = timeToMin(state.settings.jamKeluar);

  let html = `<div class="row"><span class="label">Tanggal</span><span class="value">${formatTanggal(today)}</span></div>`;
  html += `<div class="row"><span class="label">Waktu Sekarang</span><span class="value">${nowFull()}</span></div>`;
  html += `<div class="row"><span class="label">Jadwal Kerja</span><span class="value">${state.settings.jamMasuk} - ${state.settings.jamKeluar}</span></div>`;

  if (!rec || !rec.checkIn) {
    if (timeToMin(now) > jm) {
      const telat = timeToMin(now) - jm;
      html += `<div class="row"><span class="label">Status</span><span class="value"><span class="badge badge-red">Terlambat ${telat} menit</span></span></div>`;
    } else {
      html += `<div class="row"><span class="label">Status</span><span class="value"><span class="badge badge-blue">Belum Check In</span></span></div>`;
    }
  } else {
    html += `<div class="row"><span class="label">Check In</span><span class="value">${rec.checkIn}</span></div>`;
    if (rec.checkOut) {
      html += `<div class="row"><span class="label">Check Out</span><span class="value">${rec.checkOut}</span></div>`;
      const lembur = rec.lembur || 0;
      const telat = rec.telat || 0;
      if (telat > 0) html += `<div class="row"><span class="label">Terlambat</span><span class="value"><span class="badge badge-red">${telat} menit</span></span></div>`;
      if (lembur > 0) html += `<div class="row"><span class="label">Lembur</span><span class="value"><span class="badge badge-yellow">${lembur} menit</span></span></div>`;
      html += `<div class="row"><span class="label">Upah Hari Ini</span><span class="value">${rupiah(rec.totalUpah)}</span></div>`;
    } else {
      html += `<div class="row"><span class="label">Status</span><span class="value"><span class="badge badge-green">Sudah Check In</span></span></div>`;
    }
  }
  box.innerHTML = html;
}

// ==================== CHECK IN/OUT ====================
function startCheck(type) {
  const today = todayStr();
  const rec = state.records.find(r => r.tanggal === today);

  if (type === 'in') {
    if (rec && rec.checkIn) { alert('Anda sudah Check In hari ini!'); return; }
  } else {
    if (!rec || !rec.checkIn) { alert('Anda belum Check In!'); return; }
    if (rec.checkOut) { alert('Anda sudah Check Out hari ini!'); return; }
  }

  state.currentCheck = type;
  document.getElementById('cameraTitle').textContent = type === 'in' ? '📸 Check In' : '📸 Check Out';
  document.getElementById('cameraInfo').textContent = 'Mendapatkan lokasi...';
  document.getElementById('cameraModal').classList.add('show');

  navigator.geolocation.getCurrentPosition(
    pos => {
      state.currentLoc = {
        lat: pos.coords.latitude.toFixed(6),
        lng: pos.coords.longitude.toFixed(6)
      };
      document.getElementById('cameraInfo').textContent = `📍 ${state.currentLoc.lat}, ${state.currentLoc.lng}`;
    },
    err => {
      state.currentLoc = { lat:'-', lng:'-' };
      document.getElementById('cameraInfo').textContent = '📍 Lokasi tidak tersedia';
    },
    { enableHighAccuracy:true, timeout:10000 }
  );

  openCamera();
}

function openCamera() {
  const video = document.getElementById('video');
  navigator.mediaDevices.getUserMedia({ video: { facingMode:'user' }, audio:false })
    .then(stream => {
      state.stream = stream;
      video.srcObject = stream;
    })
    .catch(err => {
      alert('Tidak dapat membuka kamera: ' + err.message);
      closeCamera();
    });
}

function closeCamera() {
  if (state.stream) {
    state.stream.getTracks().forEach(t => t.stop());
    state.stream = null;
  }
  document.getElementById('cameraModal').classList.remove('show');
}

function capturePhoto() {
  const video = document.getElementById('video');
  const canvas = document.getElementById('canvas');
  canvas.width = video.videoWidth || 640;
  canvas.height = video.videoHeight || 480;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const foto = canvas.toDataURL('image/jpeg', 0.7);

  simpanAbsen(foto);
  closeCamera();
}

function simpanAbsen(foto) {
  const today = todayStr();
  const now = nowTime();
  const jm = timeToMin(state.settings.jamMasuk);
  const jk = timeToMin(state.settings.jamKeluar);
  const nowM = timeToMin(now);

  let rec = state.records.find(r => r.tanggal === today);

  if (state.currentCheck === 'in') {
    // Check in sebelum jam normal = dianggap normal (tidak terlambat/lembur)
    // Check in lewat jam normal = terlambat
    const telat = nowM > jm ? (nowM - jm) : 0;
    rec = {
      id: Date.now(),
      tanggal: today,
      checkIn: now,
      checkOut: null,
      fotoIn: foto,
      fotoOut: null,
      lat: state.currentLoc?.lat || '-',
      lng: state.currentLoc?.lng || '-',
      telat: telat,
      lembur: 0,
      totalUpah: 0,
      editIn: 0,
      editOut: 0
    };
    state.records.push(rec);
  } else {
    if (rec) {
      rec.checkOut = now;
      rec.fotoOut = foto;
      // Lembur dihitung jika check out > jam normal
      const lembur = nowM > jk ? (nowM - jk) : 0;
      rec.lembur = lembur;
      // Hitung upah
      const upahHarian = state.settings.upahHarian;
      const upahLembur = lembur * state.settings.upahLembur;
      rec.totalUpah = upahHarian + upahLembur;
      rec.upahLembur = upahLembur;
    }
  }

  saveState();
  renderStatus();
  alert('Absen berhasil disimpan!');
}

// ==================== RIWAYAT ====================
function renderRiwayat() {
  const list = document.getElementById('riwayatList');
  const sorted = [...state.records].sort((a,b) => b.tanggal.localeCompare(a.tanggal));

  if (sorted.length === 0) {
    list.innerHTML = '<div class="empty">Belum ada data absensi</div>';
    return;
  }

  list.innerHTML = sorted.map(r => {
    const canEdit = (r.editIn || 0) < 3 || (r.editOut || 0) < 3;
    const badge = r.checkOut ? (r.lembur > 0 ? '<span class="badge badge-yellow">Lembur</span>' : '<span class="badge badge-green">Selesai</span>') : '<span class="badge badge-blue">Belum Out</span>';
    return `
      <div class="record-item">
        <div class="head">
          <span>${formatTanggal(r.tanggal)}</span>
          ${badge}
        </div>
        <div class="detail">
          🕐 In: <b>${r.checkIn || '-'}</b> | Out: <b>${r.checkOut || '-'}</b><br>
          ${r.telat > 0 ? `⚠️ Terlambat: ${r.telat} menit<br>` : ''}
          ${r.lembur > 0 ? `💼 Lembur: ${r.lembur} menit (${rupiah(r.upahLembur||0)})<br>` : ''}
          ${r.checkOut ? `💰 Total Upah: <b>${rupiah(r.totalUpah||0)}</b><br>` : ''}
          📍 ${r.lat}, ${r.lng}<br>
          ✏️ Koreksi: In ${r.editIn||0}/3, Out ${r.editOut||0}/3
        </div>
        <div class="record-actions">
          ${canEdit ? `<button class="edit-btn" onclick="openEdit('${r.tanggal}')">✏️ Koreksi</button>` : ''}
          <button class="del-btn" onclick="hapusRecord('${r.tanggal}')">🗑️ Hapus</button>
        </div>
      </div>
    `;
  }).join('');
}

function hapusRecord(tgl) {
  if (!confirm('Hapus data absensi ' + formatTanggal(tgl) + '?')) return;
  state.records = state.records.filter(r => r.tanggal !== tgl);
  saveState();
  renderRiwayat();
  renderStatus();
}

// ==================== EDIT / KOREKSI ====================
function openEdit(tgl) {
  const r = state.records.find(x => x.tanggal === tgl);
  if (!r) return;
  state.editTarget = tgl;
  document.getElementById('editIn').value = r.checkIn || '';
  document.getElementById('editOut').value = r.checkOut || '';
  document.getElementById('editHint').innerHTML = `Koreksi Check In: ${r.editIn||0}/3 · Koreksi Check Out: ${r.editOut||0}/3`;
  document.getElementById('editModal').classList.add('show');
}

function closeEdit() {
  document.getElementById('editModal').classList.remove('show');
  state.editTarget = null;
}

function simpanEdit() {
  const r = state.records.find(x => x.tanggal === state.editTarget);
  if (!r) return;

  const newIn = document.getElementById('editIn').value;
  const newOut = document.getElementById('editOut').value;
  const jm = timeToMin(state.settings.jamMasuk);
  const jk = timeToMin(state.settings.jamKeluar);

  if (newIn !== r.checkIn) {
    if ((r.editIn || 0) >= 3) { alert('Koreksi Check In sudah mencapai batas maksimal 3 kali!'); return; }
    r.checkIn = newIn;
    r.editIn = (r.editIn || 0) + 1;
    // Hitung ulang telat: check in sebelum jam normal = 0
    r.telat = timeToMin(newIn) > jm ? (timeToMin(newIn) - jm) : 0;
  }

  if (newOut !== r.checkOut) {
    if ((r.editOut || 0) >= 3) { alert('Koreksi Check Out sudah mencapai batas maksimal 3 kali!'); return; }
    r.checkOut = newOut || null;
    if (newOut) r.editOut = (r.editOut || 0) + 1;
    // Hitung ulang lembur
    if (newOut) {
      r.lembur = timeToMin(newOut) > jk ? (timeToMin(newOut) - jk) : 0;
      r.upahLembur = r.lembur * state.settings.upahLembur;
      r.totalUpah = state.settings.upahHarian + r.upahLembur;
    }
  }

  saveState();
  closeEdit();
  renderRiwayat();
  renderStatus();
  alert('Koreksi berhasil disimpan!');
}

// ==================== LAPORAN ====================
function initLaporan() {
  const d = new Date();
  const first = new Date(d.getFullYear(), d.getMonth(), 1);
  document.getElementById('lapDari').value = `${first.getFullYear()}-${pad(first.getMonth()+1)}-01`;
  document.getElementById('lapSampai').value = todayStr();
  hitungLaporan(false, true);
}

function getLaporanData(dari, sampai) {
  return state.records
    .filter(r => r.tanggal >= dari && r.tanggal <= sampai)
    .sort((a,b) => a.tanggal.localeCompare(b.tanggal));
}

function hitungLaporan(cetak, preview = false) {
  const dari = document.getElementById('lapDari').value;
  const sampai = document.getElementById('lapSampai').value;
  if (!dari || !sampai) { alert('Pilih periode terlebih dahulu'); return; }

  const data = getLaporanData(dari, sampai);
  if (data.length === 0) {
    if (preview) document.getElementById('lapSummary').innerHTML = '<div class="empty">Tidak ada data pada periode ini</div>';
    if (cetak) alert('Tidak ada data pada periode ini');
    return;
  }

  const hariKerja = data.filter(r => r.checkIn).length;
  const totalHarian = data.reduce((s,r) => s + (r.totalUpah || state.settings.upahHarian), 0);
  const totalLembur = data.reduce((s,r) => s + (r.upahLembur || 0), 0);

  // Tunjangan proporsional
  const hariDalamBulan = new Date(parseInt(sampai.split('-')[0]), parseInt(sampai.split('-')[1]), 0).getDate();
  const proporsi = hariKerja / hariDalamBulan;
  const tunjanganBulananProp = state.settings.tunjanganBulanan * proporsi;
  const tunjanganLainProp = state.settings.tunjanganLain * proporsi;
  const totalTunjangan = tunjanganBulananProp + tunjanganLainProp;

  const grandTotalDengan = totalHarian + totalTunjangan;
  const grandTotalTanpa = totalHarian;

  if (preview) {
    document.getElementById('lapSummary').innerHTML = `
      <div class="summary-box">
        <div class="item"><span>Periode</span><span>${formatTanggal(dari)} - ${formatTanggal(sampai)}</span></div>
        <div class="item"><span>Hari Kerja</span><span>${hariKerja} hari</span></div>
        <div class="item"><span>Total Upah Harian</span><span>${rupiah(totalHarian - totalLembur)}</span></div>
        <div class="item"><span>Total Lembur</span><span>${rupiah(totalLembur)}</span></div>
        <div class="item"><span>Tunjangan (proporsional)</span><span>${rupiah(totalTunjangan)}</span></div>
        <div class="item"><span>Total + Tunjangan</span><span>${rupiah(grandTotalDengan)}</span></div>
        <div class="item"><span>Total Tanpa Tunjangan</span><span>${rupiah(grandTotalTanpa)}</span></div>
      </div>
    `;
  }

  if (cetak) {
    cetakPDF(data, dari, sampai, totalHarian, totalLembur, totalTunjangan, grandTotalDengan, grandTotalTanpa, !!cetak && arguments[0] === true);
  }
}

function cetakPDF(data, dari, sampai, totalHarian, totalLembur, totalTunjangan, grandDengan, grandTanpa, denganTunjangan) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageW = doc.internal.pageSize.getWidth();

  // Header
  doc.setFillColor(102, 126, 234);
  doc.rect(0, 0, pageW, 28, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(state.profile.perusahaan || 'Laporan Absensi', 14, 12);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Laporan Absensi & Penggajian', 14, 19);
  doc.text(`Periode: ${formatTanggal(dari)} - ${formatTanggal(sampai)}`, 14, 25);

  // Info karyawan
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  let y = 36;
  doc.setFont('helvetica', 'bold');
  doc.text('Nama', 14, y); doc.setFont('helvetica', 'normal'); doc.text(': ' + (state.profile.nama || '-'), 45, y); y += 5;
  doc.setFont('helvetica', 'bold');
  doc.text('Jabatan', 14, y); doc.setFont('helvetica', 'normal'); doc.text(': ' + (state.profile.jabatan || '-'), 45, y); y += 5;
  doc.setFont('helvetica', 'bold');
  doc.text('Perusahaan', 14, y); doc.setFont('helvetica', 'normal'); doc.text(': ' + (state.profile.perusahaan || '-'), 45, y); y += 8;

  // Tabel
  const body = data.map(r => [
    formatTanggal(r.tanggal),
    r.checkIn || '-',
    r.checkOut || '-',
    (r.telat || 0) + ' mnt',
    (r.lembur || 0) + ' mnt',
    rupiah(r.upahLembur || 0),
    rupiah(r.totalUpah || 0)
  ]);

  doc.autoTable({
    startY: y,
    head: [['Tanggal','Check In','Check Out','Terlambat','Lembur','Upah Lembur','Upah Harian']],
    body: body,
    theme: 'striped',
    headStyles: { fillColor: [102,126,234], fontSize: 8, halign: 'center' },
    bodyStyles: { fontSize: 8 },
    columnStyles: {
      0: { cellWidth: 28 },
      3: { halign: 'center' },
      4: { halign: 'center' },
      5: { halign: 'right' },
      6: { halign: 'right' }
    }
  });

  y = doc.lastAutoTable.finalY + 8;

  // Summary
  doc.setFillColor(245, 247, 255);
  doc.rect(14, y, pageW - 28, denganTunjangan ? 40 : 30, 'F');
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('RINGKASAN', 18, y + 6);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  let yy = y + 12;
  doc.text('Total Upah Harian', 18, yy); doc.text(': ' + rupiah(totalHarian - totalLembur), 110, yy); yy += 5;
  doc.text('Total Upah Lembur', 18, yy); doc.text(': ' + rupiah(totalLembur), 110, yy); yy += 5;
  if (denganTunjangan) {
    doc.text('Total Tunjangan', 18, yy); doc.text(': ' + rupiah(totalTunjangan), 110, yy); yy += 5;
  }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  const totalFinal = denganTunjangan ? grandDengan : grandTanpa;
  doc.text('TOTAL DITERIMA', 18, yy + 2); doc.text(': ' + rupiah(totalFinal), 110, yy + 2);

  // Footer
  doc.setFontSize(8);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(120, 120, 120);
  doc.text(`Dicetak: ${new Date().toLocaleString('id-ID')} ${denganTunjangan ? '(Include Tunjangan)' : '(Exclude Tunjangan)'}`, 14, doc.internal.pageSize.getHeight() - 8);

  const fname = `Laporan_${dari}_${sampai}${denganTunjangan ? '_Tunjangan' : ''}.pdf`;
  doc.save(fname);
}

function hapusPeriode() {
  const dari = document.getElementById('lapDari').value;
  const sampai = document.getElementById('lapSampai').value;
  if (!dari || !sampai) { alert('Pilih periode terlebih dahulu'); return; }
  if (!confirm(`Hapus semua data absensi dari ${formatTanggal(dari)} sampai ${formatTanggal(sampai)}?`)) return;
  state.records = state.records.filter(r => r.tanggal < dari || r.tanggal > sampai);
  saveState();
  initLaporan();
  alert('Data periode berhasil dihapus!');
}

// ==================== INIT ====================
function init() {
  loadState();
  loadProfile();
  loadSettings();
  renderStatus();
  setInterval(renderStatus, 1000);
}

init();
</script>
</body>
</html>
