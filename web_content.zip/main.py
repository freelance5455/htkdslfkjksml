import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.label import Label


class _Handler(BaseHTTPRequestHandler):
    root = None
    def do_GET(self):
        try:
            if self.path == "/" or self.path == "/index.html":
                data = (self.root / "index.html").read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_error(404)
        except Exception:
            self.send_error(500)
    def log_message(self, *args):
        pass


class PulguitaApp(App):
    title = "Pulguita IA"

    def build(self):
        try:
            from jnius import autoclass
            from android.runnable import run_on_ui_thread

            self.memory_file = Path(self.user_data_dir) / "pulguita_memory.json"
            self.memory_file.parent.mkdir(parents=True, exist_ok=True)

            # Servimos el HTML desde localhost para que WebView tenga un origen
            # persistente. Esto evita la pérdida de localStorage típica de file:// / data:.
            handler_cls = type("PulguitaHandler", (_Handler,), {})
            handler_cls.root = Path(os.path.dirname(__file__))
            self.server = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
            self.port = self.server.server_address[1]
            self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.server_thread.start()

            WebView = autoclass("android.webkit.WebView")
            WebViewClient = autoclass("android.webkit.WebViewClient")
            activity = autoclass("org.kivy.android.PythonActivity").mActivity
            webview = WebView(activity)
            settings = webview.getSettings()
            settings.setJavaScriptEnabled(True)
            settings.setDomStorageEnabled(True)
            settings.setAllowFileAccess(True)
            settings.setAllowContentAccess(True)
            settings.setDatabaseEnabled(True)
            webview.setWebViewClient(WebViewClient())

            @run_on_ui_thread
            def load():
                webview.loadUrl("http://127.0.0.1:%d/index.html" % self.port)

            self._webview = webview
            load()
            Clock.schedule_interval(self._capture_memory, 1.0)
            return webview
        except Exception:
            return Label(text="Pulguita IA\nNo se pudo iniciar la interfaz.")

    def _capture_memory(self, _dt):
        try:
            title = str(self._webview.getTitle() or "")
            prefix = "PULGUITA_MEMORY:"
            if not title.startswith(prefix):
                return
            import base64
            raw = base64.b64decode(title[len(prefix):]).decode("utf-8")
            data = json.loads(raw)
            tmp = self.memory_file.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            os.replace(str(tmp), str(self.memory_file))
        except Exception:
            pass

    def on_pause(self):
        self._capture_memory(0)
        return True

    def on_stop(self):
        self._capture_memory(0)
        try:
            self.server.shutdown()
            self.server.server_close()
        except Exception:
            pass
        return super().on_stop()


if __name__ == "__main__":
    PulguitaApp().run()
