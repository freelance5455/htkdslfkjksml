FREE RUMMY ANDROID PROTOTYPE — SOURCE PACKAGE
================================================
Included:
- Playable local HTML prototype (13-card hand, draw, select, discard, demo declaration)
- Minimal Android WebView wrapper source project
- No network, account, payment, real-money, or cash-out functionality

Important:
This ZIP is source code, NOT a compiled APK. APK compilation requires Android Studio/Android SDK and Gradle.
To build:
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK.
2. Open this folder as a project.
3. Allow Gradle sync.
4. Build > Build APK(s).
5. Android Studio usually outputs app-debug.apk under app/build/outputs/apk/debug/.

To test the game immediately without Android Studio:
Open app/src/main/assets/index.html in Chrome, or open the standalone HTML file included at the root of the ZIP.

Prototype limitations:
- Single-player local demo only.
- Rummy rules are not fully validated; "Declare demo win" is just a demo action.
- No multiplayer or backend.
- Virtual coins only, no purchase or withdrawal.
