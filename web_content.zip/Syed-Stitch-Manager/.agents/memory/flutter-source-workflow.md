---
name: Flutter source workflow
description: This workspace does not include the Flutter SDK or a Flutter artifact template.
---

Flutter app requests in this project should be delivered as a self-contained Dart/Flutter source tree unless a Flutter-capable build environment is added.

**Why:** The workspace is centered on a pnpm/TypeScript monorepo and does not expose `flutter` or `dart`, so local analyzer, emulator, and platform-folder generation are unavailable.

**How to apply:** Keep the Flutter project portable with its own `pubspec.yaml`, `lib/`, README, and standard Flutter dependencies; validate Dart types by inspection until a Flutter SDK is available.