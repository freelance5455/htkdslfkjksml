import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.syedstitch.atelier',
  appName: 'SYED STITCH',
  webDir: 'dist/public',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#FFFDF7',
  },
};

export default config;