package com.syedstitch.atelier;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
