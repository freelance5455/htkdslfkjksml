import { useEffect, useMemo, useState } from 'react';
import {
  ArrowUpRight,
  CalendarDays,
  Check,
  ClipboardList,
  Copy,
  MessageCircle,
  Phone,
  ReceiptText,
  Ruler,
  Save,
  Scissors,
  Trash2,
  UserRound,
} from 'lucide-react';

const STORAGE_KEY = 'syed_stitch_orders';
const BASE_PRICE = 4350;
const ADVANCE = 1500;

const measurements = [
  ['Lambai', '42"'],
  ['Chhati', '44"'],
  ['Pait', '36"'],
  ['Hip', '45"'],
  ['Galla', '16"'],
  ['Teera', '18"'],
] as const;

const shoulderOptions = ['Straight', 'Down', 'Full Down'] as const;
const gallaHeightOptions = ['Up', 'Down', 'Normal'] as const;
const gallaStyleOptions = [
  'Gol Galla',
  'V Galla',
  'Chota V',
  'Normal V',
  'Bain Galla',
  'Nipple Galla (Coat Collar)',
] as const;
const buttonOptions = [
  { name: 'Sada Button', price: 0, note: 'Free' },
  { name: 'Kapre Wale Button', price: 150, note: '+PKR 150' },
  { name: 'Steel Button', price: 200, note: '+PKR 200' },
] as const;

type SavedOrder = {
  id: string;
  customerName: string;
  phone: string;
  orderDate: string;
  deliveryDate: string;
  shoulder: string;
  gallaHeight: string;
  gallaStyle: string;
  button: string;
  buttonPrice: number;
  total: number;
  advance: number;
  balance: number;
  createdAt: number;
};

function makeOrderId() {
  return `SS-${Date.now()}`;
}

function readSavedOrders(): SavedOrder[] {
  if (typeof window === 'undefined') return [];
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function money(value: number) {
  return `PKR ${value.toLocaleString('en-PK')}`;
}

function App() {
  const [orderId, setOrderId] = useState(makeOrderId);
  const [customerName, setCustomerName] = useState('Mr. Ahmed Khan Sahab');
  const [phone, setPhone] = useState('+92 300 1234567');
  const [shoulder, setShoulder] = useState<(typeof shoulderOptions)[number]>('Straight');
  const [gallaHeight, setGallaHeight] = useState<(typeof gallaHeightOptions)[number]>('Normal');
  const [gallaStyle, setGallaStyle] = useState<(typeof gallaStyleOptions)[number]>('Gol Galla');
  const [button, setButton] = useState<(typeof buttonOptions)[number]['name']>(buttonOptions[0].name);
  const [savedOrders, setSavedOrders] = useState<SavedOrder[]>(readSavedOrders);
  const [notice, setNotice] = useState('');
  const [receipt, setReceipt] = useState('');
  const [copied, setCopied] = useState(false);

  const deliveryDate = useMemo(() => {
    const date = new Date(Date.UTC(2024, 9, 12));
    date.setUTCDate(date.getUTCDate() + 11);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
  }, []);

  const buttonPrice = buttonOptions.find((item) => item.name === button)?.price ?? 0;
  const total = BASE_PRICE + buttonPrice;
  const balance = total - ADVANCE;

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(''), 4800);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  const currentOrder = (): SavedOrder => ({
    id: orderId,
    customerName: customerName.trim() || 'Unnamed Customer',
    phone: phone.trim(),
    orderDate: '12 Oct 2024',
    deliveryDate,
    shoulder,
    gallaHeight,
    gallaStyle,
    button,
    buttonPrice,
    total,
    advance: ADVANCE,
    balance,
    createdAt: Date.now(),
  });

  const createReceipt = (order: SavedOrder) => [
    'SYED STITCH',
    'Quietly made. Precisely yours.',
    '------------------------------',
    `Order: ${order.id}`,
    `Customer: ${order.customerName}`,
    `Phone: ${order.phone}`,
    `Order date: ${order.orderDate}`,
    `Delivery: ${order.deliveryDate}`,
    '',
    'MEASUREMENTS',
    ...measurements.map(([label, value]) => `${label}: ${value}`),
    '',
    'FINISHING',
    `Shoulder slope: ${order.shoulder}`,
    `Galla height: ${order.gallaHeight}`,
    `Galla style: ${order.gallaStyle}`,
    `Buttons: ${order.button}${order.buttonPrice ? ` (+PKR ${order.buttonPrice})` : ' (Free)'}`,
    '',
    'BILLING',
    `Total: ${money(order.total)}`,
    `Advance: ${money(order.advance)}`,
    `Balance: ${money(order.balance)}`,
    '------------------------------',
    'Thank you for choosing Syed Stitch.',
  ].join('\n');

  const handleSave = () => {
    const order = currentOrder();
    const next = [order, ...savedOrders];
    setSavedOrders(next);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    setNotice(`Order ${order.id} Saved Successfully! (Total Saved: ${next.length})`);
    setReceipt(createReceipt(order));
    setCopied(false);
  };

  const handleReceipt = () => {
    const order = currentOrder();
    setReceipt(createReceipt(order));
    setCopied(false);
  };

  const handleCopy = async () => {
    if (!receipt) {
      handleReceipt();
      return;
    }
    try {
      await navigator.clipboard.writeText(receipt);
    } catch {
      const textArea = document.createElement('textarea');
      textArea.value = receipt;
      textArea.style.position = 'fixed';
      textArea.style.opacity = '0';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    }
    setCopied(true);
    setNotice('WhatsApp receipt copied to clipboard.');
    window.setTimeout(() => setCopied(false), 2200);
  };

  const handleNewOrder = () => {
    setOrderId(makeOrderId());
    setCustomerName('Mr. Ahmed Khan Sahab');
    setPhone('+92 300 1234567');
    setShoulder('Straight');
    setGallaHeight('Normal');
    setGallaStyle('Gol Galla');
    setButton(buttonOptions[0].name);
    setReceipt('');
    setCopied(false);
    setNotice('A fresh order sheet is ready.');
  };

  const handleDelete = (id: string) => {
    const next = savedOrders.filter((order) => order.id !== id);
    setSavedOrders(next);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  };

  const handleClearAll = () => {
    if (!savedOrders.length || !window.confirm('Remove all saved orders from this browser?')) return;
    setSavedOrders([]);
    window.localStorage.removeItem(STORAGE_KEY);
    setNotice('Saved order book cleared.');
  };

  return (
    <main className="atelier-shell">
      <Scissors className="motif motif-scissors h-56 w-56" strokeWidth={0.7} aria-hidden="true" />
      <Ruler className="motif motif-ruler h-64 w-64" strokeWidth={0.7} aria-hidden="true" />

      <div className="content-layer mx-auto max-w-[1440px] px-4 pb-12 sm:px-7 lg:px-10">
        <header className="flex items-center justify-between border-b border-[hsl(35_26%_86%)] py-5 sm:py-7">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]">
              <Scissors size={19} strokeWidth={1.6} />
            </div>
            <div>
              <p className="serif text-lg leading-none tracking-[.08em] text-[hsl(var(--primary))]">SYED STITCH</p>
              <p className="mono mt-1 text-[9px] uppercase tracking-[.2em] text-[hsl(var(--muted-foreground))]">Digital atelier / Lahore</p>
            </div>
          </div>
          <div className="hidden items-center gap-6 sm:flex">
            <div className="text-right">
              <p className="eyebrow">Order book</p>
              <p className="mono mt-1 text-xs text-[hsl(var(--foreground))]">{savedOrders.length.toString().padStart(2, '0')} saved orders</p>
            </div>
            <button
              type="button"
              data-testid="button-new-order"
              onClick={handleNewOrder}
              className="flex items-center gap-2 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card)/.5)] px-4 py-2 text-xs font-bold text-[hsl(var(--primary))] transition hover:border-[hsl(var(--secondary))]"
            >
              New order <ArrowUpRight size={14} />
            </button>
          </div>
        </header>

        <section className="page-enter pb-8 pt-8 sm:pb-10 sm:pt-12">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <div>
              <p className="eyebrow">Order workspace / 01</p>
              <h1 className="serif mt-2 max-w-3xl text-4xl leading-[1.04] tracking-[-.025em] text-[hsl(var(--primary))] sm:text-6xl">
                A good fit begins<br className="hidden sm:block" /> with a good note.
              </h1>
              <p className="mt-4 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">
                Capture the details once. The atelier takes care of the rest — from shoulder line to the final button.
              </p>
            </div>
            <div className="flex items-center gap-3 self-start lg:self-end">
              <div className="rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card)/.55)] px-3 py-2">
                <span className="mono text-[10px] text-[hsl(var(--muted-foreground))]">SHEET </span>
                <span className="mono text-[10px] text-[hsl(var(--primary))]">{orderId}</span>
              </div>
              <div className="flex items-center gap-2 rounded-full bg-[hsl(38_42%_45%/.12)] px-3 py-2 text-[10px] font-bold uppercase tracking-[.13em] text-[hsl(var(--secondary))]">
                <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--secondary))]" /> Draft
              </div>
            </div>
          </div>
        </section>

        <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_370px] xl:gap-9">
          <div className="space-y-6">
            <section className="paper-card section-enter rounded-2xl p-5 sm:p-7" data-testid="section-customer">
              <div className="mb-6 flex items-start justify-between gap-4">
                <div>
                  <p className="eyebrow">The client</p>
                  <h2 className="serif mt-1 text-2xl text-[hsl(var(--primary))]">Who are we dressing?</h2>
                </div>
                <UserRound className="text-[hsl(var(--secondary))]" size={22} strokeWidth={1.4} />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <label>
                  <span className="field-label">Customer name</span>
                  <input
                    data-testid="input-customer-name"
                    value={customerName}
                    onChange={(event) => setCustomerName(event.target.value)}
                    className="field-control h-12 w-full px-4 text-sm"
                  />
                </label>
                <label>
                  <span className="field-label">WhatsApp / phone</span>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]" size={15} />
                    <input
                      data-testid="input-customer-phone"
                      value={phone}
                      onChange={(event) => setPhone(event.target.value)}
                      className="field-control h-12 w-full pl-10 pr-4 text-sm"
                    />
                  </div>
                </label>
              </div>
              <div className="mt-6 grid gap-3 border-t border-[hsl(var(--card-border))] pt-5 sm:grid-cols-2">
                <div className="flex items-center gap-3">
                  <CalendarDays size={16} className="text-[hsl(var(--secondary))]" />
                  <div><p className="field-label mb-0">Order date</p><p data-testid="text-order-date" className="mono mt-1 text-xs">12 Oct 2024</p></div>
                </div>
                <div className="flex items-center gap-3">
                  <ArrowUpRight size={16} className="text-[hsl(var(--secondary))]" />
                  <div><p className="field-label mb-0">Promised delivery</p><p data-testid="text-delivery-date" className="mono mt-1 text-xs">{deliveryDate} <span className="text-[hsl(var(--muted-foreground))]">/ +11 days</span></p></div>
                </div>
              </div>
            </section>

            <section className="paper-card rounded-2xl p-5 sm:p-7" data-testid="section-measurements">
              <div className="mb-6 flex items-start justify-between">
                <div><p className="eyebrow">The foundation</p><h2 className="serif mt-1 text-2xl text-[hsl(var(--primary))]">Measurements</h2></div>
                <Ruler className="text-[hsl(var(--secondary))]" size={24} strokeWidth={1.4} />
              </div>
              <div className="grid grid-cols-2 gap-x-5 gap-y-5 sm:grid-cols-3">
                {measurements.map(([label, value]) => (
                  <div key={label} className="border-b border-dashed border-[hsl(var(--border))] pb-3">
                    <p className="field-label mb-1">{label}</p>
                    <p data-testid={`text-measurement-${label.toLowerCase()}`} className="serif text-xl text-[hsl(var(--primary))]">{value}</p>
                  </div>
                ))}
              </div>
              <p className="mt-5 text-[11px] italic text-[hsl(var(--muted-foreground))]">Recorded in inches · from the original fitting book</p>
            </section>

            <section className="paper-card rounded-2xl p-5 sm:p-7" data-testid="section-finish">
              <div className="mb-7">
                <p className="eyebrow">The finish</p>
                <h2 className="serif mt-1 text-2xl text-[hsl(var(--primary))]">Small choices, proper character.</h2>
              </div>
              <OptionGroup label="Shoulder slope" value={shoulder} options={shoulderOptions} onChange={(next) => setShoulder(next)} testPrefix="shoulder" />
              <div className="gold-rule my-7" />
              <OptionGroup label="Galla height" value={gallaHeight} options={gallaHeightOptions} onChange={(next) => setGallaHeight(next)} testPrefix="galla-height" />
              <div className="mt-7 grid gap-5 sm:grid-cols-[1fr_1.25fr]">
                <label>
                  <span className="field-label">Galla style</span>
                  <select data-testid="select-galla-style" value={gallaStyle} onChange={(event) => setGallaStyle(event.target.value as (typeof gallaStyleOptions)[number])} className="field-control h-12 w-full px-4 text-sm">
                    {gallaStyleOptions.map((style) => <option value={style} key={style}>{style}</option>)}
                  </select>
                </label>
                <div>
                  <span className="field-label">Button finish</span>
                  <div className="grid grid-cols-3 gap-2">
                    {buttonOptions.map((item) => (
                      <button
                        type="button"
                        key={item.name}
                        data-testid={`button-finish-${item.name.toLowerCase().replaceAll(' ', '-')}`}
                        onClick={() => setButton(item.name)}
                        className={`option-card min-h-[74px] rounded-lg px-2 py-3 text-left ${button === item.name ? 'is-selected' : ''}`}
                      >
                        <span className="block text-[11px] font-bold leading-4 text-[hsl(var(--primary))]">{item.name.replace(' Button', '')}</span>
                        <span className="mono mt-2 block text-[9px] text-[hsl(var(--muted-foreground))]">{item.note}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          </div>

          <aside className="space-y-6 lg:sticky lg:top-6">
            <section className="paper-card overflow-hidden rounded-2xl" data-testid="section-billing">
              <div className="bg-[hsl(var(--primary))] px-5 py-6 text-[hsl(var(--primary-foreground))] sm:px-7">
                <div className="flex items-start justify-between">
                  <div><p className="eyebrow !text-[hsl(38_42%_67%)]">The ledger</p><h2 className="serif mt-1 text-3xl">Billing</h2></div>
                  <ReceiptText size={24} strokeWidth={1.3} className="text-[hsl(38_42%_67%)]" />
                </div>
                <p className="mt-5 text-xs leading-5 text-[hsl(39_38%_94%/.65)]">A clear account is part of a good fitting.</p>
              </div>
              <div className="p-5 sm:p-7">
                <div className="space-y-4">
                  <BillRow label="Base kameez price" value={money(BASE_PRICE)} />
                  <BillRow label={`Buttons · ${button}`} value={buttonPrice ? `+ ${money(buttonPrice)}` : 'Free'} muted={!buttonPrice} />
                  <div className="gold-rule my-2" />
                  <div className="flex items-end justify-between gap-3">
                    <span className="text-sm font-bold text-[hsl(var(--primary))]">Total</span>
                    <span data-testid="text-total" className="mono text-xl font-medium text-[hsl(var(--primary))]">{money(total)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-[hsl(var(--muted-foreground))]"><span>Advance received</span><span data-testid="text-advance" className="mono">{money(ADVANCE)}</span></div>
                  <div className="rounded-lg bg-[hsl(38_42%_45%/.10)] px-3 py-3">
                    <div className="flex items-center justify-between"><span className="text-xs font-bold text-[hsl(var(--primary))]">Balance at delivery</span><span data-testid="text-balance" className="mono text-sm font-medium text-[hsl(var(--primary))]">{money(balance)}</span></div>
                  </div>
                </div>
                <button type="button" data-testid="button-save-order" onClick={handleSave} className="mt-7 flex h-14 w-full items-center justify-center gap-2 rounded-lg bg-[hsl(var(--secondary))] px-5 text-sm font-extrabold tracking-[.02em] text-[hsl(var(--secondary-foreground))] shadow-[0_8px_20px_hsl(38_42%_45%/.22)] transition hover:-translate-y-0.5 hover:brightness-105">
                  <Save size={17} /> Save this order
                </button>
                <button type="button" data-testid="button-generate-receipt" onClick={handleReceipt} className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-[hsl(var(--border))] text-xs font-bold text-[hsl(var(--primary))] transition hover:border-[hsl(var(--secondary))]">
                  <MessageCircle size={15} /> Generate WhatsApp receipt
                </button>
              </div>
            </section>

            {receipt && (
              <section className="paper-card receipt-enter rounded-2xl p-5 sm:p-6" data-testid="section-receipt">
                <div className="flex items-center justify-between gap-3">
                  <div><p className="eyebrow">Ready to send</p><h3 className="serif mt-1 text-xl text-[hsl(var(--primary))]">WhatsApp receipt</h3></div>
                  <button type="button" data-testid="button-copy-receipt" onClick={handleCopy} className="flex items-center gap-1.5 rounded-full bg-[hsl(38_42%_45%/.12)] px-3 py-2 text-[10px] font-bold uppercase tracking-[.08em] text-[hsl(var(--primary))]">
                    {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre data-testid="text-receipt" className="mt-5 max-h-[315px] overflow-auto whitespace-pre-wrap rounded-lg bg-[hsl(37_25%_89%/.6)] p-4 font-mono text-[10px] leading-[1.65] text-[hsl(var(--foreground))]">{receipt}</pre>
              </section>
            )}

            <section className="paper-card rounded-2xl p-5 sm:p-6" data-testid="section-saved-orders">
              <div className="flex items-start justify-between gap-3">
                <div><p className="eyebrow">The archive</p><h3 className="serif mt-1 text-xl text-[hsl(var(--primary))]">Recent saved orders</h3></div>
                <ClipboardList size={21} className="text-[hsl(var(--secondary))]" strokeWidth={1.4} />
              </div>
              {!savedOrders.length ? (
                <div className="mt-5 rounded-lg border border-dashed border-[hsl(var(--border))] px-4 py-5 text-center">
                  <p data-testid="text-empty-orders" className="text-xs text-[hsl(var(--muted-foreground))]">Your saved order book is quiet.</p>
                  <p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">Saved sheets will appear here.</p>
                </div>
              ) : (
                <div className="mt-5">
                  {savedOrders.slice(0, 4).map((order) => (
                    <div key={`${order.id}-${order.createdAt}`} className="order-table-row flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0" data-testid={`row-saved-order-${order.id}`}>
                      <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-[hsl(var(--primary))]">{order.customerName}</p>
                        <p className="mono mt-1 text-[9px] text-[hsl(var(--muted-foreground))]">{order.id} · {order.orderDate}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="mono whitespace-nowrap text-[10px] text-[hsl(var(--primary))]">{money(order.total)}</span>
                        <button type="button" aria-label={`Delete ${order.id}`} data-testid={`button-delete-order-${order.id}`} onClick={() => handleDelete(order.id)} className="rounded p-1 text-[hsl(var(--muted-foreground))] transition hover:text-[hsl(var(--destructive))]"><Trash2 size={13} /></button>
                      </div>
                    </div>
                  ))}
                  {savedOrders.length > 4 && <p className="mt-4 text-[10px] text-[hsl(var(--muted-foreground))]">Showing the four latest sheets.</p>}
                  <button type="button" data-testid="button-clear-orders" onClick={handleClearAll} className="mt-5 text-[10px] font-bold uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))] transition hover:text-[hsl(var(--destructive))]">Clear order book</button>
                </div>
              )}
            </section>
          </aside>
        </div>

        <footer className="mt-12 flex flex-col justify-between gap-3 border-t border-[hsl(35_26%_86%)] pt-5 text-[10px] text-[hsl(var(--muted-foreground))] sm:flex-row">
          <p className="mono uppercase tracking-[.12em]">Syed Stitch · Lahore · Since 1987</p>
          <p>Made with patience, measured twice.</p>
        </footer>
      </div>

      {notice && (
        <div data-testid="status-notice" className="toast-note fixed bottom-5 left-1/2 z-20 flex max-w-[calc(100vw-2rem)] -translate-x-1/2 items-center gap-3 rounded-lg bg-[hsl(var(--primary))] px-4 py-3 text-xs font-semibold text-[hsl(var(--primary-foreground))] shadow-[0_12px_35px_hsl(26_38%_25%/.25)]">
          <Check size={15} className="shrink-0 text-[hsl(38_42%_67%)]" /> <span>{notice}</span>
        </div>
      )}
    </main>
  );
}

function OptionGroup<T extends string>({ label, value, options, onChange, testPrefix }: { label: string; value: T; options: readonly T[]; onChange: (value: T) => void; testPrefix: string }) {
  return (
    <div>
      <span className="field-label">{label}</span>
      <div className="grid gap-2 sm:grid-cols-3">
        {options.map((option) => (
          <button type="button" key={option} data-testid={`button-${testPrefix}-${option.toLowerCase().replaceAll(' ', '-')}`} onClick={() => onChange(option)} className={`option-card rounded-lg px-3 py-3 text-left text-xs font-bold text-[hsl(var(--primary))] ${value === option ? 'is-selected' : ''}`}>
            <span className={`mr-2 inline-block h-1.5 w-1.5 rounded-full align-middle ${value === option ? 'bg-[hsl(var(--secondary))]' : 'bg-[hsl(var(--border))]'}`} />
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

function BillRow({ label, value, muted = false }: { label: string; value: string; muted?: boolean }) {
  return <div className="flex justify-between gap-3 text-xs text-[hsl(var(--muted-foreground))]"><span>{label}</span><span className={`mono ${muted ? 'text-[hsl(var(--muted-foreground))]' : 'text-[hsl(var(--primary))]'}`}>{value}</span></div>;
}

export default App;