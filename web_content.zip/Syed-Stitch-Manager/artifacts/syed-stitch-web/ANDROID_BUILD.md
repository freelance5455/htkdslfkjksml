# SYED STITCH Android APK

This package wraps the browser version of SYED STITCH in a native Android project using Capacitor. Orders continue to persist locally in the Android WebView under `syed_stitch_orders`.

## Build the Android project

Requirements:

- Node.js 20+
- Android Studio with an Android SDK and Android build tools
- A connected Android device or emulator for `run`

From this directory:

```bash
pnpm install
pnpm run cap:sync
pnpm run android:assemble
```

The debug APK is created at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

To open the project in Android Studio:

```bash
pnpm run android:open
```

For a release APK, configure a signing key in Android Studio and use the
`generateSignedBundle` / signed APK flow. Do not distribute an unsigned debug
APK to production users.