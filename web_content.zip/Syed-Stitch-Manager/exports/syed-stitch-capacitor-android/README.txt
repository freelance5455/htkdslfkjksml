SYED STITCH - Capacitor Android Source Bundle

This archive contains:
- android/: complete Capacitor Android project, including Gradle wrapper and synced web assets
- web-source/: React/Vite source and Capacitor configuration used to produce the app
- BUILD.md: APK build instructions

Fastest route:
1. Open the android/ folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s) > Build APK(s).

The synced web app is already included at:
android/app/src/main/assets/public/

If you edit the web source, rebuild the web app and run Capacitor sync before opening Android Studio again.
