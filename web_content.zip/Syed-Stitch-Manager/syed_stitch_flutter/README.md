# SYED STITCH

A premium Flutter app for a tailoring shop to record waistcoat measurements, calculate dynamic bills, and keep orders available offline with Hive.

## Run

```bash
flutter pub get
flutter run
```

The app stores orders in a local Hive box named `orders`. No account or network connection is required.