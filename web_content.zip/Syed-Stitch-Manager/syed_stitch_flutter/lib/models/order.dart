import 'package:hive/hive.dart';

class TailoringOrder {
  TailoringOrder({
    required this.id,
    required this.customerName,
    required this.phone,
    required this.measurements,
    required this.basePrice,
    required this.fabricPrice,
    required this.pocketPrice,
    required this.buttonPrice,
    required this.discount,
    required this.status,
    required this.createdAt,
    this.notes = '',
  });

  final String id;
  final String customerName;
  final String phone;
  final Map<String, double> measurements;
  final double basePrice;
  final double fabricPrice;
  final double pocketPrice;
  final double buttonPrice;
  final double discount;
  final String status;
  final DateTime createdAt;
  final String notes;

  double get subtotal =>
      basePrice + fabricPrice + pocketPrice + buttonPrice;

  double get total =>
      (subtotal - discount).clamp(0, double.infinity).toDouble();
}

class TailoringOrderAdapter extends TypeAdapter<TailoringOrder> {
  @override
  final int typeId = 1;

  @override
  TailoringOrder read(BinaryReader reader) {
    final values = reader.readMap();
    return TailoringOrder(
      id: values['id'] as String,
      customerName: values['customerName'] as String,
      phone: values['phone'] as String,
      measurements: Map<String, double>.from(
        (values['measurements'] as Map).map(
          (key, value) => MapEntry(key.toString(), (value as num).toDouble()),
        ),
      ),
      basePrice: (values['basePrice'] as num).toDouble(),
      fabricPrice: (values['fabricPrice'] as num).toDouble(),
      pocketPrice: (values['pocketPrice'] as num).toDouble(),
      buttonPrice: (values['buttonPrice'] as num).toDouble(),
      discount: (values['discount'] as num).toDouble(),
      status: values['status'] as String,
      createdAt: DateTime.parse(values['createdAt'] as String),
      notes: (values['notes'] as String?) ?? '',
    );
  }

  @override
  void write(BinaryWriter writer, TailoringOrder order) {
    writer.writeMap({
      'id': order.id,
      'customerName': order.customerName,
      'phone': order.phone,
      'measurements': order.measurements,
      'basePrice': order.basePrice,
      'fabricPrice': order.fabricPrice,
      'pocketPrice': order.pocketPrice,
      'buttonPrice': order.buttonPrice,
      'discount': order.discount,
      'status': order.status,
      'createdAt': order.createdAt.toIso8601String(),
      'notes': order.notes,
    });
  }
}