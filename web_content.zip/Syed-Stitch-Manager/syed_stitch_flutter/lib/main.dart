import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';

const Color ivoryCream = Color(0xFFFFFDF7);
const Color mutedGold = Color(0xFFB68A3E);
const Color espressoBlack = Color(0xFF231F1B);
const Color warmInk = Color(0xFF4C4033);
const Color softInk = Color(0xFF83786B);
const Color paleGold = Color(0xFFF7F0E3);
const Color goldLine = Color(0xFFE4D4B9);
const Color successGreen = Color(0xFF388E3C);

const double basePrice = 4350;
const double advanceAmount = 1500;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('syed_stitch_orders');
  runApp(const SyedStitchApp());
}

class SyedStitchApp extends StatelessWidget {
  const SyedStitchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SYED STITCH',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: ivoryCream,
        colorScheme: ColorScheme.fromSeed(
          seedColor: mutedGold,
          brightness: Brightness.light,
          surface: ivoryCream,
        ),
        fontFamily: 'Avenir',
        appBarTheme: const AppBarTheme(
          backgroundColor: ivoryCream,
          foregroundColor: warmInk,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          labelStyle: const TextStyle(
            color: softInk,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
          hintStyle: const TextStyle(color: softInk),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: goldLine),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: mutedGold, width: 1.4),
          ),
        ),
      ),
      home: const OrderWorkspace(),
    );
  }
}

class OrderWorkspace extends StatefulWidget {
  const OrderWorkspace({super.key});

  @override
  State<OrderWorkspace> createState() => _OrderWorkspaceState();
}

class _OrderWorkspaceState extends State<OrderWorkspace> {
  final Box<dynamic> _ordersBox = Hive.box('syed_stitch_orders');
  final TextEditingController _customerNameController =
      TextEditingController(text: 'Mr. Ahmed Khan Sahab');
  final TextEditingController _phoneController =
      TextEditingController(text: '+92 300 1234567');

  final DateTime _fixedOrderDate = DateTime(2024, 10, 12);

  String _orderId = _createOrderId();
  String _shoulderSlope = 'Straight';
  String _gallaHeight = 'Normal';
  String _gallaStyle = 'Gol Galla';
  String _buttonLabel = 'Sada Button Free';
  int _buttonPrice = 0;

  DateTime get _deliveryDate =>
      _fixedOrderDate.add(const Duration(days: 11));

  int get _totalBill => basePrice.toInt() + _buttonPrice;

  int get _balance => _totalBill - advanceAmount.toInt();

  String get _orderDateLabel =>
      DateFormat('dd MMM yyyy', 'en_US').format(_fixedOrderDate);

  String get _deliveryDateLabel =>
      DateFormat('dd MMM yyyy', 'en_US').format(_deliveryDate);

  @override
  void dispose() {
    _customerNameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ivoryCream,
      body: Stack(
        children: [
          const _ThematicBackground(),
          SafeArea(
            child: CustomScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _Header(orderId: _orderId),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _ClientDetails(
                      customerNameController: _customerNameController,
                      phoneController: _phoneController,
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _ScheduleCard(
                      orderDate: _orderDateLabel,
                      deliveryDate: _deliveryDateLabel,
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _SectionCard(
                      eyebrow: 'SECTION A',
                      title: 'Waistcoat measurements',
                      child: const _MeasurementGrid(),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _SectionCard(
                      eyebrow: 'SECTION B',
                      title: 'Shoulder slope',
                      child: _SelectionCapsules(
                        values: const ['Straight', 'Down', 'Full Down'],
                        selectedValue: _shoulderSlope,
                        onSelected: (value) =>
                            setState(() => _shoulderSlope = value),
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _SectionCard(
                      eyebrow: 'SECTION C',
                      title: 'Galla selections',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _SelectionCapsules(
                            values: const ['Up', 'Down', 'Normal'],
                            selectedValue: _gallaHeight,
                            onSelected: (value) =>
                                setState(() => _gallaHeight = value),
                          ),
                          const SizedBox(height: 18),
                          Wrap(
                            spacing: 8,
                            runSpacing: 10,
                            children: [
                              'Gol Galla',
                              'V Galla',
                              'Chota V',
                              'Normal V',
                              'Bain Galla',
                              'Nipple Galla (Coat Collar)',
                            ]
                                .map(
                                  (value) => _SelectionChip(
                                    label: value,
                                    selected: _gallaStyle == value,
                                    onTap: () =>
                                        setState(() => _gallaStyle = value),
                                  ),
                                )
                                .toList(),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                  sliver: SliverToBoxAdapter(
                    child: _SectionCard(
                      eyebrow: 'SECTION D',
                      title: 'Button finish',
                      child: Column(
                        children: [
                          _ButtonPriceOption(
                            label: 'Sada Button Free',
                            priceLabel: '+PKR 0',
                            selected: _buttonLabel == 'Sada Button Free',
                            onTap: () => _selectButton(
                              'Sada Button Free',
                              0,
                            ),
                          ),
                          const SizedBox(height: 10),
                          _ButtonPriceOption(
                            label: 'Kapre Wale Button',
                            priceLabel: '+PKR 150',
                            selected: _buttonLabel == 'Kapre Wale Button',
                            onTap: () => _selectButton(
                              'Kapre Wale Button',
                              150,
                            ),
                          ),
                          const SizedBox(height: 10),
                          _ButtonPriceOption(
                            label: 'Steel Button',
                            priceLabel: '+PKR 200',
                            selected: _buttonLabel == 'Steel Button',
                            onTap: () => _selectButton(
                              'Steel Button',
                              200,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
                  sliver: SliverToBoxAdapter(
                    child: _BillingBlock(
                      totalBill: _totalBill,
                      advance: advanceAmount.toInt(),
                      balance: _balance,
                      onSave: _saveOrder,
                      onWhatsapp: _showWhatsappReceipt,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _selectButton(String label, int price) {
    setState(() {
      _buttonLabel = label;
      _buttonPrice = price;
    });
  }

  void _saveOrder() {
    FocusManager.instance.primaryFocus?.unfocus();

    final customerName = _customerNameController.text.trim();
    final phone = _phoneController.text.trim();
    if (customerName.isEmpty || phone.isEmpty) {
      _showMessage(
        'Please complete the customer name and phone fields first.',
        isError: true,
      );
      return;
    }

    final record = <String, dynamic>{
      'orderId': _orderId,
      'customerName': customerName,
      'phone': phone,
      'orderDate': _orderDateLabel,
      'deliveryDate': _deliveryDateLabel,
      'measurements': <String, String>{
        'Lambai': '42"',
        'Chhati': '44"',
        'Pait': '36"',
        'Hip': '45"',
        'Galla': '16"',
        'Teera': '18"',
      },
      'shoulderSlope': _shoulderSlope,
      'gallaHeight': _gallaHeight,
      'gallaStyle': _gallaStyle,
      'button': _buttonLabel,
      'buttonPrice': _buttonPrice,
      'basePrice': basePrice.toInt(),
      'totalBill': _totalBill,
      'advance': advanceAmount.toInt(),
      'baqiBalance': _balance,
      'savedAtMillis': DateTime.now().millisecondsSinceEpoch,
    };

    _ordersBox.put(_orderId, record);
    _showMessage(
      'Order $_orderId Saved Successfully! (Total Saved: ${_ordersBox.length})',
    );
    setState(() => _orderId = _createOrderId());
  }

  void _showWhatsappReceipt() {
    FocusManager.instance.primaryFocus?.unfocus();
    final payload = _buildWhatsappPayload();
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: ivoryCream,
          surfaceTintColor: ivoryCream,
          title: const Text(
            'WhatsApp Receipt',
            style: TextStyle(
              color: warmInk,
              fontWeight: FontWeight.w800,
            ),
          ),
          content: SingleChildScrollView(
            child: SelectableText(
              payload,
              style: const TextStyle(
                color: warmInk,
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text(
                'Close',
                style: TextStyle(color: softInk),
              ),
            ),
            FilledButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: payload));
                if (!dialogContext.mounted) return;
                Navigator.of(dialogContext).pop();
                _showMessage('WhatsApp receipt copied to clipboard.');
              },
              style: FilledButton.styleFrom(
                backgroundColor: mutedGold,
                foregroundColor: Colors.white,
              ),
              icon: const Icon(Icons.copy_rounded, size: 17),
              label: const Text('Copy receipt'),
            ),
          ],
        );
      },
    );
  }

  String _buildWhatsappPayload() {
    final customerName = _customerNameController.text.trim();
    final phone = _phoneController.text.trim();
    return '''SYED STITCH
WAISTCOAT ORDER RECEIPT
━━━━━━━━━━━━━━━━━━━━
Order ID: $_orderId
Customer: $customerName
Phone: $phone

SCHEDULE
Order Date: $_orderDateLabel
Delivery Date: $_deliveryDateLabel

MEASUREMENTS
Lambai: 42"
Chhati: 44"
Pait: 36"
Hip: 45"
Galla: 16"
Teera: 18"

STYLE
Shoulder Slope: $_shoulderSlope
Galla Height: $_gallaHeight
Galla Style: $_gallaStyle
Button: $_buttonLabel

BILLING
Base Price: PKR ${_formatMoney(basePrice.toInt())}
Button Price: PKR ${_formatMoney(_buttonPrice)}
Total Bill: PKR ${_formatMoney(_totalBill)}
Advance: PKR ${_formatMoney(advanceAmount.toInt())}
Baqi Balance: PKR ${_formatMoney(_balance)}

Thank you for choosing SYED STITCH.''';
  }

  void _showMessage(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: isError ? Colors.red.shade700 : mutedGold,
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      );
  }
}

class _ThematicBackground extends StatelessWidget {
  const _ThematicBackground();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Stack(
        children: [
          Positioned(
            top: 92,
            right: -26,
            child: Opacity(
              opacity: 0.03,
              child: Transform.rotate(
                angle: -0.25,
                child: const Icon(
                  Icons.content_cut,
                  size: 190,
                  color: mutedGold,
                ),
              ),
            ),
          ),
          Positioned(
            top: 520,
            left: -46,
            child: Opacity(
              opacity: 0.03,
              child: Transform.rotate(
                angle: 0.5,
                child: const Icon(
                  Icons.straighten,
                  size: 210,
                  color: mutedGold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.orderId});

  final String orderId;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: mutedGold,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.checkroom_outlined,
                      color: Colors.white,
                      size: 19,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'SYED STITCH',
                    style: TextStyle(
                      color: mutedGold,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.4,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              const Text(
                'New waistcoat',
                style: TextStyle(
                  color: warmInk,
                  fontSize: 30,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.8,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                'Measure with intention. Stitch with pride.',
                style: TextStyle(
                  color: softInk.withOpacity(0.95),
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
          decoration: BoxDecoration(
            color: paleGold,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: goldLine),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                'ORDER TOKEN',
                style: TextStyle(
                  color: mutedGold,
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                orderId,
                style: const TextStyle(
                  color: warmInk,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ClientDetails extends StatelessWidget {
  const _ClientDetails({
    required this.customerNameController,
    required this.phoneController,
  });

  final TextEditingController customerNameController;
  final TextEditingController phoneController;

  @override
  Widget build(BuildContext context) {
    return _SectionCard(
      eyebrow: 'CLIENT PROFILE',
      title: 'Who are we dressing?',
      child: Column(
        children: [
          TextField(
            controller: customerNameController,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Customer Name',
              prefixIcon: Icon(Icons.person_outline_rounded, color: mutedGold),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Phone',
              prefixIcon: Icon(Icons.phone_outlined, color: mutedGold),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScheduleCard extends StatelessWidget {
  const _ScheduleCard({
    required this.orderDate,
    required this.deliveryDate,
  });

  final String orderDate;
  final String deliveryDate;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(17, 16, 17, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: goldLine),
        boxShadow: [
          BoxShadow(
            color: mutedGold.withOpacity(0.07),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          _DateBlock(
            label: 'ORDER DATE',
            date: orderDate,
            icon: Icons.event_note_outlined,
          ),
          Container(
            width: 1,
            height: 44,
            margin: const EdgeInsets.symmetric(horizontal: 15),
            color: goldLine,
          ),
          _DateBlock(
            label: 'DELIVERY DATE  ·  +11 DAYS',
            date: deliveryDate,
            icon: Icons.local_shipping_outlined,
            dateColor: Colors.green.shade700,
          ),
        ],
      ),
    );
  }
}

class _DateBlock extends StatelessWidget {
  const _DateBlock({
    required this.label,
    required this.date,
    required this.icon,
    this.dateColor = warmInk,
  });

  final String label;
  final String date;
  final IconData icon;
  final Color dateColor;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Row(
        children: [
          Icon(icon, color: mutedGold, size: 20),
          const SizedBox(width: 9),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: softInk,
                    fontSize: 8,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .7,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  date,
                  style: TextStyle(
                    color: dateColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.eyebrow,
    required this.title,
    required this.child,
  });

  final String eyebrow;
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.94),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: goldLine),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            eyebrow,
            style: const TextStyle(
              color: mutedGold,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.6,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            style: const TextStyle(
              color: warmInk,
              fontSize: 19,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 15),
          child,
        ],
      ),
    );
  }
}

class _MeasurementGrid extends StatelessWidget {
  const _MeasurementGrid();

  static const List<Map<String, String>> values = [
    {'label': 'Lambai', 'value': '42"'},
    {'label': 'Chhati', 'value': '44"'},
    {'label': 'Pait', 'value': '36"'},
    {'label': 'Hip', 'value': '45"'},
    {'label': 'Galla', 'value': '16"'},
    {'label': 'Teera', 'value': '18"'},
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: values.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 9,
        mainAxisSpacing: 9,
        childAspectRatio: 0.96,
      ),
      itemBuilder: (context, index) {
        final measurement = values[index];
        return Container(
          padding: const EdgeInsets.fromLTRB(6, 11, 6, 9),
          decoration: BoxDecoration(
            color: ivoryCream,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: mutedGold.withOpacity(0.65)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.checkroom_outlined,
                color: mutedGold,
                size: 23,
              ),
              const SizedBox(height: 7),
              Text(
                measurement['label']!,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: softInk,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                measurement['value']!,
                style: const TextStyle(
                  color: warmInk,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SelectionCapsules extends StatelessWidget {
  const _SelectionCapsules({
    required this.values,
    required this.selectedValue,
    required this.onSelected,
  });

  final List<String> values;
  final String selectedValue;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: values
          .map(
            (value) => Expanded(
              child: Padding(
                padding: EdgeInsets.only(
                  right: value == values.last ? 0 : 8,
                ),
                child: _SelectionChip(
                  label: value,
                  selected: selectedValue == value,
                  expanded: true,
                  onTap: () => onSelected(value),
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}

class _SelectionChip extends StatelessWidget {
  const _SelectionChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.expanded = false,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    final content = AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      width: expanded ? double.infinity : null,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: selected ? mutedGold : ivoryCream,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: selected ? mutedGold : goldLine,
          width: selected ? 1.2 : 1,
        ),
      ),
      child: Text(
        label,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: selected ? Colors.white : warmInk,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(13),
      child: content,
    );
  }
}

class _ButtonPriceOption extends StatelessWidget {
  const _ButtonPriceOption({
    required this.label,
    required this.priceLabel,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final String priceLabel;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
        decoration: BoxDecoration(
          color: selected ? paleGold : ivoryCream,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? mutedGold : goldLine,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 21,
              height: 21,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? mutedGold : Colors.transparent,
                border: Border.all(
                  color: selected ? mutedGold : softInk,
                  width: 1.4,
                ),
              ),
              child: selected
                  ? const Icon(Icons.check, color: Colors.white, size: 14)
                  : null,
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: warmInk,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            Text(
              priceLabel,
              style: TextStyle(
                color: selected ? mutedGold : softInk,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BillingBlock extends StatelessWidget {
  const _BillingBlock({
    required this.totalBill,
    required this.advance,
    required this.balance,
    required this.onSave,
    required this.onWhatsapp,
  });

  final int totalBill;
  final int advance;
  final int balance;
  final VoidCallback onSave;
  final VoidCallback onWhatsapp;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: goldLine),
          ),
          child: Column(
            children: [
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'FINANCIAL SUMMARY',
                  style: TextStyle(
                    color: mutedGold,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.6,
                  ),
                ),
              ),
              const SizedBox(height: 15),
              _BillRow(
                label: 'Base price',
                value: 'PKR ${_formatMoney(basePrice.toInt())}',
              ),
              const SizedBox(height: 10),
              _BillRow(
                label: 'Button upgrade',
                value: 'PKR ${_formatMoney(totalBill - basePrice.toInt())}',
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Divider(color: goldLine, height: 1),
              ),
              _BillRow(
                label: 'Total Bill',
                value: 'PKR ${_formatMoney(totalBill)}',
                emphasized: true,
              ),
              const SizedBox(height: 10),
              _BillRow(
                label: 'Advance',
                value: 'PKR ${_formatMoney(advance)}',
              ),
              const SizedBox(height: 10),
              _BillRow(
                label: 'Baqi Balance',
                value: 'PKR ${_formatMoney(balance)}',
                valueColor: mutedGold,
                emphasized: true,
              ),
            ],
          ),
        ),
        const SizedBox(height: 13),
        Material(
          color: espressoBlack,
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            onTap: onSave,
            borderRadius: BorderRadius.circular(18),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
              child: Row(
                children: [
                  Container(
                    width: 39,
                    height: 39,
                    decoration: BoxDecoration(
                      color: mutedGold,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.save_outlined,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Save Waiskot',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Store this order securely on this device',
                          style: TextStyle(
                            color: Color(0xFFC8BFB6),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.arrow_forward_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 11),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: onWhatsapp,
            style: OutlinedButton.styleFrom(
              foregroundColor: mutedGold,
              side: const BorderSide(color: mutedGold),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
            icon: const Icon(Icons.chat_outlined, size: 19),
            label: const Text(
              'WhatsApp Receipt',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ],
    );
  }
}

class _BillRow extends StatelessWidget {
  const _BillRow({
    required this.label,
    required this.value,
    this.emphasized = false,
    this.valueColor = warmInk,
  });

  final String label;
  final String value;
  final bool emphasized;
  final Color valueColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: emphasized ? warmInk : softInk,
            fontSize: emphasized ? 14 : 13,
            fontWeight: emphasized ? FontWeight.w800 : FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: valueColor,
            fontSize: emphasized ? 16 : 13,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

String _createOrderId() => 'SS-${DateTime.now().millisecondsSinceEpoch}';

String _formatMoney(int amount) => NumberFormat('#,##0').format(amount);