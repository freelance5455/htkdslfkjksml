const {useEffect,useMemo,useState}=React;
const {createRoot}=ReactDOM;
const supabase=window.supabase.createClient('https://yghcowwkthdijpzmfszs.supabase.co','sb_publishable_H3A3VlFhnvWCuMv1pO08Vw_eSedwcky',{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});

const money=n=>new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(Number(n||0))
const today=()=>new Date().toISOString().slice(0,10)
const errText=e=>e?.message||'Une erreur est survenue.'
const feedOrder=['Aliment Démarrage','Aliment Croissance','Aliment Ponte 1','Aliment Ponte 2']
const orderFeeds=a=>[...a].sort((x,y)=>feedOrder.indexOf(x.name)-feedOrder.indexOf(y.name))
const menus=[
 ['dashboard','📊','Tableau de bord'],['fabrication','🏭','Fabrication'],['history','🧾','Historique fabrication'],
 ['formulas','🧪','Formules alimentaires'],['takes','🚚','Sortie / distribution'],['takes-history','📦','Historique sorties'],
 ['losses','⚠️','Pertes'],['stats','📈','Statistiques']
]

function Login(){
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[loading,setLoading]=useState(false),[error,setError]=useState('')
 async function submit(e){e.preventDefault();setLoading(true);setError('');const {error}=await supabase.auth.signInWithPassword({email,password});if(error)setError('Identifiant ou mot de passe incorrect.');setLoading(false)}
 return <div className="login"><div className="login-card"><div className="brand">MISSION TOVÉ</div><div className="subtitle">Gestion des stocks d’aliments</div><form onSubmit={submit}><label>Email / identifiant<input value={email} onChange={e=>setEmail(e.target.value)} type="email" required /></label><label>Mot de passe<input value={password} onChange={e=>setPassword(e.target.value)} type="password" required /></label>{error&&<div className="error">{error}</div>}<button className="primary big" disabled={loading}>{loading?'Connexion…':'Se connecter'}</button></form></div></div>
}

function App(){
 const [session,setSession]=useState(null),[page,setPage]=useState('dashboard'),[open,setOpen]=useState(false)
 useEffect(()=>{supabase.auth.getSession().then(({data})=>setSession(data.session));const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));return()=>subscription.unsubscribe()},[])
 if(!session)return <Login/>
 return <Shell page={page} setPage={p=>{setPage(p);setOpen(false)}} open={open} setOpen={setOpen}/>
}

function Shell({page,setPage,open,setOpen}){
 const [refresh,setRefresh]=useState(0)
 const [toast,setToast]=useState('')
 useEffect(()=>{const h=e=>setPage(e.detail);window.addEventListener('mission:navigate',h);return()=>window.removeEventListener('mission:navigate',h)},[])
 const notify=m=>{setToast(m);setRefresh(x=>x+1);setTimeout(()=>setToast(''),3500)}
 return <div className="app"><aside className={open?'open':''}><div className="side-brand"><b>MISSION TOVÉ</b><span>Stocks d’aliments</span></div>{menus.map(([id,ic,label])=><button key={id} className={page===id?'active':''} onClick={()=>setPage(id)}>{ic}<span>{label}</span></button>)}<button className="logout" onClick={()=>supabase.auth.signOut()}>↪ Déconnexion</button></aside><main><header><button className="hamb" onClick={()=>setOpen(!open)}>☰</button><div><b>{menus.find(x=>x[0]===page)?.[2]}</b><small> Mission Tové</small></div></header>{toast&&<div className="toast">{toast}</div>}<div className="content">{page==='dashboard'&&<Dashboard refresh={refresh}/>} {page==='fabrication'&&<Fabrication notify={notify}/>} {page==='history'&&<ProductionHistory refresh={refresh}/>} {page==='formulas'&&<Formulas notify={notify}/>} {page==='takes'&&<TakeForm notify={notify}/>} {page==='takes-history'&&<TakeHistory refresh={refresh}/>} {page==='losses'&&<LossForm notify={notify}/>} {page==='stats'&&<Stats refresh={refresh}/>}</div></main></div>
}

function useData(refresh=0){
 const [feeds,setFeeds]=useState([]),[farmers,setFarmers]=useState([]),[stock,setStock]=useState([]),[loading,setLoading]=useState(true)
 async function load(){setLoading(true);const [f,fa,s]=await Promise.all([supabase.from('feeds').select('*').eq('active',true).order('name'),supabase.from('farmers').select('*').eq('active',true).order('name'),supabase.from('stock_courant').select('*').order('feed_name')]);setFeeds(orderFeeds((f.data||[]).filter(x=>feedOrder.includes(x.name))));setFarmers(fa.data||[]);setStock(orderFeeds(s.data||[]));setLoading(false)}
 useEffect(()=>{load()},[refresh])
 return {feeds,farmers,stock,loading,reload:load}
}

function ChoiceGrid({label,items,value,onChange,empty='Aucun choix disponible',compact=false}){
 return <div className={'choice-field '+(compact?'compact':'')}><div className="choice-label">{label}</div>{items.length?<div className="choice-grid">{items.map(x=><button type="button" key={x.id} className={'choice '+(value===x.id?'selected':'')} onClick={()=>onChange(x.id)}>{x.name}</button>)}</div>:<div className="choice-empty">{empty}</div>}</div>
}

function Status({row}){const s=Number(row.stock_kg);return <span className={'badge '+(s<=Number(row.critical_stock_kg)?'critical':s<=Number(row.min_stock_kg)?'low':'ok')}>{s<=Number(row.critical_stock_kg)?'Critique':s<=Number(row.min_stock_kg)?'Faible':'Normal'}</span>}

function Dashboard({refresh}){
 const {stock,loading}=useData(refresh);
 const [acts,setActs]=useState([]);
 useEffect(()=>{(async()=>{
   const [p,t,l]=await Promise.all([
     supabase.from('productions').select('id,production_date,net_kg,feeds(name)').order('created_at',{ascending:false}).limit(6),
     supabase.from('takes').select('id,take_date,quantity_kg,feeds(name),farmers(name)').order('created_at',{ascending:false}).limit(6),
     supabase.from('losses').select('id,loss_date,quantity_kg,feeds(name),reason').order('created_at',{ascending:false}).limit(6)
   ]);
   setActs([
     ...((p.data||[]).map(x=>({date:x.production_date,type:'Fabrication',label:x.feeds?.name,qty:Number(x.net_kg),icon:'🏭'}))),
     ...((t.data||[]).map(x=>({date:x.take_date,type:'Sortie',label:x.feeds?.name,person:x.farmers?.name,qty:-Number(x.quantity_kg),icon:'🚚'}))),
     ...((l.data||[]).map(x=>({date:x.loss_date,type:'Perte',label:x.feeds?.name,qty:-Number(x.quantity_kg),reason:x.reason,icon:'⚠️'})))
   ].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,6));
 })()},[refresh]);
 const totals=useMemo(()=>stock.reduce((a,x)=>{a.stock+=Number(x.stock_kg||0);a.prod+=Number(x.production_kg||0);a.take+=Number(x.take_kg||0);a.loss+=Number(x.loss_kg||0);return a},{stock:0,prod:0,take:0,loss:0}),[stock]);
 const alerts=stock.filter(x=>Number(x.stock_kg)<=Number(x.min_stock_kg));
 const critical=stock.filter(x=>Number(x.stock_kg)<=Number(x.critical_stock_kg));
 const maxStock=Math.max(1,...stock.map(x=>Number(x.min_stock_kg||0)*2),...stock.map(x=>Number(x.stock_kg||0)));
 return <>
   <div className="dashboard-top">
     <div><span className="eyebrow">MISSION TOVÉ</span><h1>Bonjour 👋</h1><p>Voici l'état de vos aliments aujourd'hui.</p></div>
     <div className="date-pill">📅 {new Date().toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})}</div>
   </div>
   <section className="stock-hero-card">
     <div><span>STOCK TOTAL DISPONIBLE</span><strong>{money(totals.stock)} <small>kg</small></strong><p>{critical.length?`⚠️ ${critical.length} stock(s) critique(s)`:alerts.length?`⚠️ ${alerts.length} stock(s) à surveiller`:'✓ Tous les stocks sont sous contrôle'}</p></div>
     <div className="stock-hero-icon">📦</div>
   </section>
   <div className="quick-actions">
     <button onClick={()=>window.dispatchEvent(new CustomEvent('mission:navigate',{detail:'fabrication'}))}><span>🏭</span><b>Nouvelle fabrication</b><small>Ajouter au stock</small></button>
     <button onClick={()=>window.dispatchEvent(new CustomEvent('mission:navigate',{detail:'takes'}))}><span>🚚</span><b>Nouvelle sortie</b><small>Distribuer aux éleveurs</small></button>
   </div>
   <div className="dashboard-metrics">
     <div className="metric-card"><span>🏭</span><small>Production</small><b>{money(totals.prod)} kg</b></div>
     <div className="metric-card"><span>🚚</span><small>Sorties</small><b>{money(totals.take)} kg</b></div>
     <div className="metric-card"><span>⚠️</span><small>Pertes</small><b>{money(totals.loss)} kg</b></div>
   </div>
   <section className="panel stock-panel">
     <div className="section-head"><div><h2>État des stocks</h2><p>Les 4 aliments de MISSION TOVÉ</p></div><span className="stock-total-label">{stock.length} aliments</span></div>
     {loading?<Loader/>:<div className="mobile-stock-list">{stock.map(r=>{
       const s=Number(r.stock_kg||0), min=Number(r.min_stock_kg||0), crit=Number(r.critical_stock_kg||0), pct=Math.min(100,(s/Math.max(maxStock,min||1))*100);
       return <div className="stock-item" key={r.feed_id}>
         <div className="stock-item-head"><div><b>{r.feed_name}</b><small>Seuil minimum : {money(min)} kg</small></div><Status row={r}/></div>
         <div className="stock-progress"><i style={{width:`${pct}%`}}></i></div>
         <div className="stock-item-foot"><strong>{money(s)} kg</strong><span>Critique : {money(crit)} kg</span></div>
       </div>})}</div>}
   </section>
   {alerts.length>0&&<section className="panel dashboard-alerts"><div className="section-head"><div><h2>Alertes stock</h2><p>Les aliments nécessitant votre attention</p></div><span className="alert-count">{alerts.length}</span></div><div className="alert-list">{alerts.map(r=><div key={r.feed_id}><span>⚠️</span><div><b>{r.feed_name}</b><small>{Number(r.stock_kg)<=Number(r.critical_stock_kg)?'Stock critique':'Stock faible'} — {money(r.stock_kg)} kg disponibles</small></div></div>)}</div></section>}
   <section className="panel"><div className="section-head"><div><h2>Dernières activités</h2><p>Les derniers mouvements enregistrés</p></div></div>{acts.length?<div className="activity-mobile">{acts.map((a,i)=><div className="activity-item" key={i}><span className="activity-icon">{a.icon}</span><div><b>{a.type}</b><strong>{a.label}</strong><small>{a.person||a.reason||''}</small></div><div className={a.qty>=0?'qty-positive':'qty-negative'}>{a.qty>0?'+':''}{money(a.qty)} kg<small>{a.date}</small></div></div>)}</div>:<Empty/>}</section>
 </>
}
const Card=({t,v,i})=><div className="card"><span>{i}</span><small>{t}</small><strong>{v}</strong></div>
const Loader=()=> <div className="loading">Chargement…</div>
const Empty=()=> <div className="empty">Aucune donnée pour le moment.</div>
function EditProduction({row,onDone}){
 const [theo,setTheo]=useState(row.theoretical_kg),[loss,setLoss]=useState(row.loss_kg),[date,setDate]=useState(row.production_date),[busy,setBusy]=useState(false)
 async function save(e){e.preventDefault();setBusy(true);const {error}=await supabase.from('productions').update({production_date:date,theoretical_kg:Number(theo),loss_kg:Number(loss)}).eq('id',row.id);setBusy(false);if(error)alert(errText(error));else onDone()}
 return <div className="modal"><form className="modal-card" onSubmit={save}><h2>Modifier la fabrication</h2><label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><label>Théorique (kg)<input type="number" min="1" step=".01" value={theo} onChange={e=>setTheo(e.target.value)}/></label><label>Perte (kg)<input type="number" min="0" step=".01" value={loss} onChange={e=>setLoss(e.target.value)}/></label><div className="modal-actions"><button type="button" onClick={onDone}>Annuler</button><button className="primary" disabled={busy}>{busy?'Enregistrement…':'Enregistrer'}</button></div></form></div>
}
function EditTake({row,onDone}){
 const {feeds,farmers}=useData();const [date,setDate]=useState(row.take_date),[farmer,setFarmer]=useState(row.farmer_id),[feed,setFeed]=useState(row.feed_id),[bags,setBags]=useState(row.bags),[obs,setObs]=useState(row.observation||''),[busy,setBusy]=useState(false)
 async function save(e){e.preventDefault();setBusy(true);const {error}=await supabase.from('takes').update({take_date:date,farmer_id:farmer,feed_id:feed,bags:Number(bags),observation:obs||null}).eq('id',row.id);setBusy(false);if(error)alert(errText(error));else onDone()}
 return <div className="modal"><form className="modal-card" onSubmit={save}><h2>Modifier la sortie</h2><label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><ChoiceGrid label="Éleveur" items={farmers} value={farmer} onChange={setFarmer} compact/><ChoiceGrid label="Aliment" items={feeds} value={feed} onChange={setFeed} compact/><label>Sacs<input type="number" min="1" value={bags} onChange={e=>setBags(e.target.value)}/></label><label>Observation<textarea value={obs} onChange={e=>setObs(e.target.value)}/></label><div className="modal-actions"><button type="button" onClick={onDone}>Annuler</button><button className="primary" disabled={busy}>{busy?'Enregistrement…':'Enregistrer'}</button></div></form></div>
}
function EditLoss({row,onDone}){
 const {feeds}=useData();const [date,setDate]=useState(row.loss_date),[feed,setFeed]=useState(row.feed_id),[qty,setQty]=useState(row.quantity_kg),[reason,setReason]=useState(row.reason),[busy,setBusy]=useState(false)
 async function save(e){e.preventDefault();setBusy(true);const {error}=await supabase.from('losses').update({loss_date:date,feed_id:feed,quantity_kg:Number(qty),reason}).eq('id',row.id);setBusy(false);if(error)alert(errText(error));else onDone()}
 return <div className="modal"><form className="modal-card" onSubmit={save}><h2>Modifier la perte</h2><label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><ChoiceGrid label="Aliment" items={feeds} value={feed} onChange={setFeed} compact/><label>Quantité (kg)<input type="number" min=".01" step=".01" value={qty} onChange={e=>setQty(e.target.value)}/></label><label>Motif<select value={reason} onChange={e=>setReason(e.target.value)}><option>déversement</option><option>humidité</option><option>aliment avarié</option><option>transport</option><option>autre</option></select></label><div className="modal-actions"><button type="button" onClick={onDone}>Annuler</button><button className="primary" disabled={busy}>{busy?'Enregistrement…':'Enregistrer'}</button></div></form></div>
}


function Fabrication({notify}){
 const {feeds}=useData();const [feed,setFeed]=useState(''),[date,setDate]=useState(today()),[theo,setTheo]=useState('1000'),[loss,setLoss]=useState(''),[formula,setFormula]=useState(null),[saving,setSaving]=useState(false)
 useEffect(()=>{if(feed)loadFormula(feed)},[feed])
 async function loadFormula(fid){const {data}=await supabase.from('formulas').select('*,feeds(name),production_ingredients(*,ingredients(name))').eq('feed_id',fid).eq('active',true).order('version',{ascending:false}).limit(1).maybeSingle();setFormula(data)}
 const net=Math.max(0,Number(theo||0)-Number(loss||0)),bags=Math.floor(net/50),rem=net-bags*50,rate=Number(theo)?Number(loss||0)/Number(theo)*100:0
 async function save(e){e.preventDefault();if(!feed||net<=0)return;setSaving(true);const {error}=await supabase.from('productions').insert({production_date:date,feed_id:feed,formula_id:formula?.id,theoretical_kg:Number(theo),loss_kg:Number(loss||0)});if(error)notify(errText(error));else notify('Fabrication enregistrée. Stock mis à jour.');setSaving(false)}
 return <><div className="hero"><h1>Nouvelle fabrication</h1><p>La quantité nette est ajoutée automatiquement au stock.</p></div><form className="panel formgrid" onSubmit={save}><label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)} required/></label><ChoiceGrid label="Type d’aliment" items={feeds} value={feed} onChange={setFeed}/><div className="wide formula-section"><div className="choice-label">Formule active</div>{formula?<><div className="formula-box"><b>Version {formula.version}</b> · {formula.production_ingredients?.length||0} ingrédients</div><div className="ingredient-list">{(formula.production_ingredients||[]).map(x=><div key={x.id}><span>{x.ingredients?.name}</span><b>{money(Number(x.quantity_kg)*Number(theo||0)/(formula.production_ingredients||[]).reduce((a,r)=>a+Number(r.quantity_kg||0),0))} kg</b><small>{(Number(x.quantity_kg)/(formula.production_ingredients||[]).reduce((a,r)=>a+Number(r.quantity_kg||0),0)*100).toFixed(2)}%</small></div>)}</div></>:<div className="formula-box">Sélectionnez un type d’aliment pour afficher sa formule.</div>}</div><label>Quantité théorique (kg)<input type="number" min="1" step=".01" value={theo} onChange={e=>setTheo(e.target.value)}/></label><label>Perte fabrication (kg)<input type="number" min="0" step=".01" value={loss} onChange={e=>setLoss(e.target.value)}/></label><div className="calc"><div><small>Net</small><b>{money(net)} kg</b></div><div><small>Sacs 50 kg</small><b>{bags}</b></div><div><small>Reste</small><b>{money(rem)} kg</b></div><div><small>Taux de perte</small><b>{rate.toFixed(2)}%</b></div></div><button className="primary wide" disabled={saving}>{saving?'Enregistrement…':'Valider la fabrication'}</button></form></>
}

function ProductionHistory({refresh}){
 const [rows,setRows]=useState([]),[q,setQ]=useState(''),[edit,setEdit]=useState(null)
 async function load(){const {data}=await supabase.from('productions').select('*,feeds(name),formulas(version)').order('production_date',{ascending:false});setRows(data||[])}
 useEffect(()=>{load()},[refresh])
 const filtered=rows.filter(r=>`${r.feeds?.name} ${r.production_date}`.toLowerCase().includes(q.toLowerCase()))
 async function del(r){if(!confirm('Supprimer cette fabrication ? Le stock sera recalculé.'))return;const {error}=await supabase.from('productions').delete().eq('id',r.id);if(error)alert(errText(error));else load()}
 return <><div className="hero"><h1>Historique fabrication</h1></div><section className="panel"><input className="search" placeholder="Rechercher…" value={q} onChange={e=>setQ(e.target.value)}/><div className="tablewrap"><table><thead><tr><th>Date</th><th>Aliment</th><th>Théorique</th><th>Perte</th><th>Net</th><th>Sacs</th><th>Reste</th><th>Actions</th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td>{r.production_date}</td><td>{r.feeds?.name}</td><td>{money(r.theoretical_kg)}</td><td>{money(r.loss_kg)}</td><td><b>{money(r.net_kg)}</b></td><td>{r.bags}</td><td>{money(r.remainder_kg)}</td><td><button className="action" onClick={()=>setEdit(r)}>Modifier</button> <button className="action danger" onClick={()=>del(r)}>Suppr.</button></td></tr>)}</tbody></table></div></section>{edit&&<EditProduction row={edit} onDone={()=>{setEdit(null);load()}}/>}</>
}
function Formulas({notify}){
 const {feeds}=useData();
 const [feed,setFeed]=useState(''),[formula,setFormula]=useState(null),[ingredients,setIngredients]=useState([]),[rows,setRows]=useState([]),[effective,setEffective]=useState(today()),[notes,setNotes]=useState(''),[saving,setSaving]=useState(false),[loading,setLoading]=useState(false);
 async function load(fid){
  setLoading(true);
  const [f,ing]=await Promise.all([
   supabase.from('formulas').select('*,production_ingredients(*,ingredients(name))').eq('feed_id',fid).eq('active',true).order('version',{ascending:false}).limit(1).maybeSingle(),
   supabase.from('ingredients').select('id,name').eq('active',true).order('name')
  ]);
  setFormula(f.data||null); setIngredients(ing.data||[]);
  if(f.data){setEffective(f.data.effective_from||today());setNotes(f.data.notes||'');setRows((f.data.production_ingredients||[]).map(x=>({ingredient_id:x.ingredient_id,quantity_kg:Number(x.quantity_kg)})))} else {setEffective(today());setNotes('');setRows([])}
  setLoading(false);
 }
 useEffect(()=>{if(feed)load(feed);else{setFormula(null);setRows([]);setIngredients([])}},[feed]);
 const total=rows.reduce((a,r)=>a+Number(r.quantity_kg||0),0);
 function pct(q){return total?Number(q||0)/total*100:0}
 function addRow(){const used=new Set(rows.map(r=>r.ingredient_id));const next=ingredients.find(i=>!used.has(i.id));if(next)setRows([...rows,{ingredient_id:next.id,quantity_kg:0}]);else notify('Tous les ingrédients sont déjà ajoutés.')}
 function updateRow(i,key,value){setRows(rows.map((r,n)=>n===i?{...r,[key]:key==='quantity_kg'?Number(value):value}:r))}
 function removeRow(i){setRows(rows.filter((_,n)=>n!==i))}
 async function save(e){
  e.preventDefault(); if(!feed||total<=0||rows.some(r=>!r.ingredient_id||Number(r.quantity_kg)<0))return;
  setSaving(true);
  const {data,error}=await supabase.rpc('create_formula_version',{p_feed_id:feed,p_effective_from:effective,p_notes:notes||null,p_items:rows.filter(r=>Number(r.quantity_kg)>0).map(r=>({ingredient_id:r.ingredient_id,quantity_kg:Number(r.quantity_kg)}))});
  setSaving(false);
  if(error){notify(errText(error));return}
  notify(`Nouvelle version ${data?.[0]?.formula_version||''} créée. Les anciennes productions restent inchangées.`); await load(feed);
 }
 return <><div className="hero"><h1>Formules alimentaires</h1><p>Modifiez la formule sans toucher aux anciennes productions. Chaque sauvegarde crée une nouvelle version.</p></div><section className="panel">
  <label>Aliment<select value={feed} onChange={e=>setFeed(e.target.value)}><option value="">Choisir…</option>{feeds.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
  {loading&&<Loader/>}
  {feed&&!loading&&<form onSubmit={save}>
   <div className="formgrid" style={{marginTop:16}}>
    <label>Date d'effet<input type="date" value={effective} onChange={e=>setEffective(e.target.value)} required/></label>
    <label>Note / commentaire<input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Ex. modification du soja"/></label>
   </div>
   {formula&&<div className="formula-card"><h2>Version actuelle : {formula.version}</h2><p className="muted">Enregistrée le {formula.created_at?.slice(0,10)||'—'}. Cette version restera conservée.</p></div>}
   <div className="tablewrap"><table><thead><tr><th>Ingrédient</th><th>Quantité (kg)</th><th>%</th><th></th></tr></thead><tbody>{rows.map((r,i)=><tr key={`${r.ingredient_id}-${i}`}><td><select value={r.ingredient_id} onChange={e=>updateRow(i,'ingredient_id',e.target.value)}>{ingredients.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></td><td><input type="number" min="0" step=".01" value={r.quantity_kg} onChange={e=>updateRow(i,'quantity_kg',e.target.value)}/></td><td>{pct(r.quantity_kg).toFixed(2)}%</td><td><button type="button" className="action danger" onClick={()=>removeRow(i)}>Retirer</button></td></tr>)}</tbody></table></div>
   <div className="calc"><div><small>Total formule</small><b>{money(total)} kg</b></div><div><small>Nombre d'ingrédients</small><b>{rows.filter(r=>Number(r.quantity_kg)>0).length}</b></div></div>
   <div className="modal-actions"><button type="button" onClick={addRow}>+ Ajouter un ingrédient</button><button className="primary" disabled={saving||total<=0}>{saving?'Création…':'Créer la nouvelle version'}</button></div>
  </form>}
 </section></>
}
function TakeForm({notify}){
 const {feeds,farmers}=useData();const [date,setDate]=useState(today()),[farmer,setFarmer]=useState(''),[feed,setFeed]=useState(''),[bags,setBags]=useState(1),[obs,setObs]=useState(''),[saving,setSaving]=useState(false)
 async function save(e){e.preventDefault();setSaving(true);const {error}=await supabase.from('takes').insert({take_date:date,farmer_id:farmer,feed_id:feed,bags:Number(bags),observation:obs||null});notify(error?errText(error):'Sortie enregistrée. Stock déduit automatiquement.');setSaving(false);if(!error){setBags(1);setObs('')}}
 return <><div className="hero"><h1>Sortie / distribution</h1><p>1 sac = 50 kg. Le stock est contrôlé côté base de données.</p></div><form className="panel formgrid" onSubmit={save}><label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><ChoiceGrid label="Éleveur" items={farmers} value={farmer} onChange={setFarmer}/><ChoiceGrid label="Type d’aliment" items={feeds} value={feed} onChange={setFeed}/><label>Nombre de sacs<input type="number" min="1" step="1" value={bags} onChange={e=>setBags(e.target.value)}/></label><div className="formula-box wide"><b>Quantité : {money(Number(bags)*50)} kg</b></div><label className="wide">Observation<textarea value={obs} onChange={e=>setObs(e.target.value)} rows="3"/></label><button className="primary wide" disabled={saving}>{saving?'Enregistrement…':'Enregistrer la sortie'}</button></form></>
}

function TakeHistory({refresh}){
 const [rows,setRows]=useState([]),[q,setQ]=useState(''),[edit,setEdit]=useState(null)
 async function load(){const {data}=await supabase.from('takes').select('*,feeds(name),farmers(name)').order('take_date',{ascending:false});setRows(data||[])}
 useEffect(()=>{load()},[refresh])
 const f=rows.filter(r=>`${r.feeds?.name} ${r.farmers?.name} ${r.take_date}`.toLowerCase().includes(q.toLowerCase()))
 async function del(r){if(!confirm('Supprimer cette sortie ? Le stock sera recalculé.'))return;const {error}=await supabase.from('takes').delete().eq('id',r.id);if(error)alert(errText(error));else load()}
 return <><div className="hero"><h1>Historique sorties</h1></div><section className="panel"><input className="search" placeholder="Rechercher…" value={q} onChange={e=>setQ(e.target.value)}/><div className="tablewrap"><table><thead><tr><th>Date</th><th>Éleveur</th><th>Aliment</th><th>Sacs</th><th>Kg</th><th>Observation</th><th>Actions</th></tr></thead><tbody>{f.map(r=><tr key={r.id}><td>{r.take_date}</td><td>{r.farmers?.name}</td><td>{r.feeds?.name}</td><td>{r.bags}</td><td>{money(r.quantity_kg)}</td><td>{r.observation||'—'}</td><td><button className="action" onClick={()=>setEdit(r)}>Modifier</button> <button className="action danger" onClick={()=>del(r)}>Suppr.</button></td></tr>)}</tbody></table></div></section>{edit&&<EditTake row={edit} onDone={()=>{setEdit(null);load()}}/>}</>
}
function LossForm({notify}){
 const {feeds}=useData();const [date,setDate]=useState(today()),[feed,setFeed]=useState(''),[qty,setQty]=useState(''),[reason,setReason]=useState('déversement'),[saving,setSaving]=useState(false)
 async function save(e){e.preventDefault();setSaving(true);const {error}=await supabase.from('losses').insert({loss_date:date,feed_id:feed,quantity_kg:Number(qty),reason});notify(error?errText(error):'Perte enregistrée. Stock déduit automatiquement.');setSaving(false);if(!error)setQty('')}
 return <><div className="hero"><h1>Enregistrer une perte</h1><p>La perte est déduite immédiatement du stock.</p></div><form className="panel formgrid" onSubmit={save}><label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><ChoiceGrid label="Type d’aliment" items={feeds} value={feed} onChange={setFeed}/><label>Quantité perdue (kg)<input type="number" min=".01" step=".01" value={qty} onChange={e=>setQty(e.target.value)} required/></label><label>Motif<select value={reason} onChange={e=>setReason(e.target.value)}><option>déversement</option><option>humidité</option><option>aliment avarié</option><option>transport</option><option>autre</option></select></label><button className="primary wide" disabled={saving}>{saving?'Enregistrement…':'Enregistrer la perte'}</button></form><LossHistory/></>
}
function LossHistory(){
 const [rows,setRows]=useState([]),[edit,setEdit]=useState(null)
 async function load(){const {data}=await supabase.from('losses').select('*,feeds(name)').order('loss_date',{ascending:false});setRows(data||[])}
 useEffect(()=>{load()},[])
 async function del(r){if(!confirm('Supprimer cette perte ? Le stock sera recalculé.'))return;const {error}=await supabase.from('losses').delete().eq('id',r.id);if(error)alert(errText(error));else load()}
 return <section className="panel"><h2>Historique des pertes</h2><div className="tablewrap"><table><thead><tr><th>Date</th><th>Aliment</th><th>Kg</th><th>Motif</th><th>Actions</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.loss_date}</td><td>{r.feeds?.name}</td><td>{money(r.quantity_kg)}</td><td>{r.reason}</td><td><button className="action" onClick={()=>setEdit(r)}>Modifier</button> <button className="action danger" onClick={()=>del(r)}>Suppr.</button></td></tr>)}</tbody></table></div>{edit&&<EditLoss row={edit} onDone={()=>{setEdit(null);load()}}/>}</section>
}
function Stats({refresh}){
 const {stock}=useData(refresh);const [p,setP]=useState([]),[t,setT]=useState([]),[l,setL]=useState([])
 useEffect(()=>{Promise.all([supabase.from('productions').select('net_kg,production_date,feeds(name)'),supabase.from('takes').select('quantity_kg,take_date,feeds(name)'),supabase.from('losses').select('quantity_kg,loss_date,feeds(name)')]).then(([a,b,c])=>{setP(a.data||[]);setT(b.data||[]);setL(c.data||[])})},[refresh])
 const sum=a=>a.reduce((x,r)=>x+Number(r.net_kg??r.quantity_kg??0),0)
 return <><div className="hero"><h1>Statistiques</h1><p>Vue globale des mouvements enregistrés.</p></div><div className="cards"><Card t="Production totale" v={`${money(sum(p))} kg`} i="🏭"/><Card t="Sorties totales" v={`${money(sum(t))} kg`} i="🚚"/><Card t="Pertes totales" v={`${money(sum(l))} kg`} i="⚠️"/><Card t="Stock actuel" v={`${money(sum(stock.map(x=>({quantity_kg:x.stock_kg}))))} kg`} i="📦"/></div><section className="panel"><h2>Production par aliment</h2>{Object.entries(p.reduce((a,r)=>{a[r.feeds?.name]=(a[r.feeds?.name]||0)+Number(r.net_kg);return a},{})).map(([k,v])=><div className="barrow" key={k}><span>{k}</span><div><i style={{width:`${Math.min(100,v/Math.max(1,sum(p))*100)}%`}}/></div><b>{money(v)} kg</b></div>)}</section></>
}
function CardX(){return null}
createRoot(document.getElementById('root')).render(<App/>)
