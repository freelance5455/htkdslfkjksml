MISSION TOVÉ — VERSION FINALE ANDROID / NETLIFY DROP

Déploiement : décompresser ce dossier et déposer tout son contenu sur Netlify Drop.
Supabase : Anonymous Sign-Ins doit rester activé.

Fonctions incluses :
- accès direct sans identifiant
- tableau de bord mobile
- fabrication + calcul net/perte/sacs/reste
- choix tactile des 4 aliments
- choix tactile des 7 éleveurs
- historique fabrication avec recherche/date
- modification/suppression fabrication
- sortie/distribution avec contrôle du stock
- historique sorties avec recherche/date
- modification/suppression des sorties
- pertes avec motif + contrôle du stock
- modification/suppression des pertes
- formules versionnées et modification sans altérer l'historique
- historique des versions de formules
- quantités d'ingrédients mises à l'échelle avec la fabrication
- statistiques avec périodes et période personnalisée
- stockage centralisé Supabase
