# ADNAN.PY — Sky Rush Pro

A mobile-first original arcade flyer built with Canvas, HTML, CSS and JavaScript.

## Features
- ADNAN.PY branding printed on both pipes
- Five selectable bird styles
- Three world themes: Day, Night, Neon City
- Pipe gap behavior, collision, score when passing a pipe
- Collectible coin trails worth bonus points
- Increasing difficulty as score rises
- Local best score, sound toggle, pause, restart
- Responsive mobile UI and original vector-style game graphics

## Android-only build
This is a source project ZIP, not a compiled APK.
1. Extract the ZIP on your phone.
2. Open `www/index.html` in a browser to test.
3. Import the project folder or ZIP into a compatible HTML-to-APK builder.
4. App name: `ADNAN.PY Sky Rush Pro`
5. Package ID (if supported): `com.adnanpy.skyrushpro`
6. Enable local/offline assets, portrait mode, then build and sign.
7. Install and test on your device.

The shop has two score-gated birds: Golden Duck unlocks at a best score of 10, and Dragon Bird at 25. The five core birds are selectable immediately.
