ADNAN.PY SKY RUSH PRO — ANDROID FILES

Included:
- www/index.html, style.css, game.js, images/dragon.png
- android/app/src/main/AndroidManifest.xml
- android/app/src/main/res/values/strings.xml and styles.xml
- android/app/src/main/res/xml/network_security_config.xml
- android/app/src/main/assets/www/ (same game files for a WebView wrapper)

IMPORTANT:
This is source code, not a compiled APK. MT Manager can inspect/edit an existing APK and its XML/smali, but it does not normally compile this HTML/JS project into an APK by itself. To make an installable APK, import these files into an Android WebView project or an Android HTML-to-APK builder, then build/sign the APK. Do not replace files in the original Flappy Bird APK; this is a separate original game project.
