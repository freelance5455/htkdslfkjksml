Lorry Stock Manager - Fixed package

Open index.html in a mobile browser or upload this ZIP to an HTML-to-APK builder.
The app now pre-fills the next day's morning stock from the previous day's closing stock. First day requires initial stock entry. New loads are entered using Reload Stock. Sales and remaining stock are recorded as before.

Important: Local browser/app storage may not transfer between a browser and a newly built APK. Export a JSON backup regularly. Automatic Google Drive sync is not included.
