JASYS SUPER AI — Updated Project

WHAT CHANGED
- Updated the model ID from llama-3.3-70b-versatile to openai/gpt-oss-120b.
- Added a comment beside the model setting to make it easier to find.
- Kept the existing design, Groq API connection, chat history, English/Hausa support, and key controls.

HOW TO USE
1. Extract this ZIP.
2. Open index.html in a browser with internet access.
3. Enter your Groq API key in the Groq API key box.
4. Press Save key.
5. Ask a question.

IMPORTANT
The model ID must be available to your Groq account. If Groq returns a model-access error, check the models listed in your Groq Console and replace the model ID in index.html with one your account can use.

API KEY SAFETY
This is a browser-only demo and saves the key in the browser's local storage. Do not publish this version for public use with a private key embedded in the browser. A public website should call Groq through a secure backend that keeps the key on the server.
