/* ============================================================================
 * MODULE 08: MASTER UI CONTROLLER, FULL LUDO CAPO GAME DASHBOARD,
 *            SUPER TOKEN VAULT, SMART COLOR SYNCHRONIZATION & SCOREBOARD
 * ============================================================================ */

class CapoGameController {
  constructor() {
    this.storage = new CapoStorageManager();
    this.audio = new CapoAudioEngine(this.storage);
    this.rules = new CapoRulesEngine(this.storage, this.audio);
    this.renderer = null;

    this.currentScreen = "splash";
    this.inventoryTab = "supertokens";
    this.dashboardTab = "players";
    this.tutorialStep = 0;
    this.anchorEditMode = false;
    this.draggingAnchorIdx = null;

    this.matchSessionId = 0;
    this.isRollingDice = false;
    this.isAnimatingToken = false;
    this.botTimeout = null;
    this.rafId = null;

    this.dicePos = { x: 50, y: 50 };
  }

  init() {
    const canvas = document.getElementById("ludo-board-canvas");
    this.renderer = new CapoBoardRenderer(canvas, this.rules, this.storage);

    this.applyThemeCssVariables(this.storage.state.setup.selectedTheme);
    this.bindStaticEvents();
    this.renderHomeLoadoutStrip();
    this.renderSetupScreen();
    this.renderInventoryScreen();
    this.renderDashboardModal();
    this.renderStatsModal();
    this.renderTutorialStep();
    this.syncSettingsControls();
    this.resizeBoardCanvas();

    window.addEventListener("resize", () => {
      this.resizeBoardCanvas();
      if (this.currentScreen === "game") {
        this.syncTurnHud(true);
      }
    });

    const loop = (now) => {
      if (this.currentScreen === "game" && this.renderer) {
        this.renderer.renderFrame(now);
      }
      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);

    this.runSplashSequence();
  }

  runSplashSequence() {
    const bar = document.getElementById("splash-progress-bar");
    const status = document.getElementById("splash-status-text");
    const btn = document.getElementById("btn-splash-enter");
    const steps = [
      { pct: 28, text: "Initializing Ludo Capo 3D Shader & Smart Color Engine..." },
      { pct: 60, text: "Loading 6 Super Tokens, 6 Worlds, 8 3D Dice & Full Dashboard..." },
      { pct: 88, text: "Calibrating Strategic Score Analyzer & Capture VFX Sequencer..." },
      { pct: 100, text: "All Super Tokens & Systems Unlocked — Ready for Offline Play" }
    ];
    let idx = 0;
    const timer = setInterval(() => {
      if (idx < steps.length) {
        if (bar) bar.style.width = `${steps[idx].pct}%`;
        if (status) status.textContent = steps[idx].text;
        idx++;
      } else {
        clearInterval(timer);
        if (btn) {
          btn.classList.remove("opacity-50", "pointer-events-none");
          btn.classList.add("animate-pulse");
        }
      }
    }, 220);
  }

  applyThemeCssVariables(themeId) {
    const t = getThemeById(themeId);
    const root = document.documentElement;
    root.style.setProperty("--capo-bg-top", t.bgGradTop);
    root.style.setProperty("--capo-bg-mid", t.bgGradMid);
    root.style.setProperty("--capo-bg-bot", t.bgGradBot);
    root.style.setProperty("--capo-accent", t.uiAccent);
    root.style.setProperty("--capo-border", t.uiCardBorder);
    root.style.setProperty("--capo-card-bg", t.uiCardBg);

    const badgeEl = document.getElementById("home-active-theme-badge");
    if (badgeEl) badgeEl.textContent = `World: ${t.name}`;
    this.renderHomeLoadoutStrip();
  }

  renderHomeLoadoutStrip() {
    const setup = this.storage.state.setup;
    const theme = getThemeById(setup.selectedTheme);
    const dice = getDiceSkinById(setup.selectedDice);
    const token = getTokenSkinById(setup.selectedToken);
    const p1Pal = this.storage.getPlayerPalette(0);

    const diceBox = document.getElementById("home-loadout-dice-preview");
    if (diceBox) diceBox.innerHTML = renderDiceSvg(dice.id, 6, "w-9 h-9");

    const tokenBox = document.getElementById("home-loadout-token-preview");
    if (tokenBox) tokenBox.innerHTML = renderTokenPreviewSvg(token.id, p1Pal, "w-9 h-9");

    const themeName = document.getElementById("home-loadout-theme-name");
    if (themeName) themeName.textContent = theme.name;

    const diceName = document.getElementById("home-loadout-dice-name");
    if (diceName) diceName.textContent = dice.name;

    const tokenName = document.getElementById("home-loadout-token-name");
    if (tokenName) tokenName.textContent = token.name;
  }

  showScreen(screenName) {
    this.audio.ensureContext();
    this.currentScreen = screenName;
    const screens = ["splash", "home", "setup", "inventory", "game"];
    screens.forEach(s => {
      const el = document.getElementById(`screen-${s}`);
      if (el) {
        if (s === screenName) el.classList.remove("hidden");
        else el.classList.add("hidden");
      }
    });

    document.querySelectorAll(".nav-dock-btn").forEach(btn => {
      const target = btn.getAttribute("data-nav");
      if (target === screenName) {
        btn.classList.add("dock-tab-active");
      } else {
        btn.classList.remove("dock-tab-active");
      }
    });

    if (screenName === "home") {
      this.renderHomeLoadoutStrip();
    } else if (screenName === "setup") {
      this.renderSetupScreen();
    } else if (screenName === "inventory") {
      this.renderInventoryScreen();
    } else if (screenName === "game") {
      this.resizeBoardCanvas();
      setTimeout(() => {
        this.resizeBoardCanvas();
        this.syncTurnHud(true);
      }, 30);
    }
  }

  openModal(modalId) {
    this.audio.menuOpen();
    const el = document.getElementById(modalId);
    if (el) el.classList.remove("hidden");
    if (modalId === "modal-stats") this.renderStatsModal();
    if (modalId === "modal-settings") this.syncSettingsControls();
    if (modalId === "modal-tutorial") this.renderTutorialStep();
    if (modalId === "modal-dashboard") this.renderDashboardModal();
  }

  closeModal(modalId) {
    this.audio.menuClose();
    const el = document.getElementById(modalId);
    if (el) el.classList.add("hidden");
  }

  closeAllModals() {
    ["modal-pause", "modal-settings", "modal-rules", "modal-tutorial", "modal-stats", "modal-victory", "modal-dashboard"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add("hidden");
    });
  }

  showToast(msg) {
    const toast = document.getElementById("capo-toast");
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.remove("opacity-0", "pointer-events-none", "translate-y-4");
    toast.classList.add("opacity-100", "translate-y-0");
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => {
      toast.classList.add("opacity-0", "pointer-events-none", "translate-y-4");
      toast.classList.remove("opacity-100", "translate-y-0");
    }, 2400);
  }

  /**
   * Synchronizes any player color/HUD/board changes dynamically across the entire game!
   */
  applyLiveColorAndDashboardChanges() {
    this.rules.refreshPalettesFromSetup();
    this.renderHomeLoadoutStrip();
    if (this.currentScreen === "setup") {
      this.renderSetupScreen();
    } else if (this.currentScreen === "inventory") {
      this.renderInventoryScreen();
    } else if (this.currentScreen === "game") {
      this.buildPlayerHudPods();
      this.syncTurnHud(true);
      if (this.renderer) this.renderer.renderFrame(performance.now());
    }
  }

  /* --------------------------------------------------------------------------
   * MATCH SETUP & INVENTORY RENDERING (WITH SMART COLOR PICKERS & SUPER TOKENS)
   * -------------------------------------------------------------------------- */
  renderSetupScreen() {
    const setup = this.storage.state.setup;
    const settings = this.storage.state.settings;

    document.querySelectorAll(".setup-pcount-btn").forEach(btn => {
      const cnt = parseInt(btn.getAttribute("data-count"), 10);
      if (cnt === setup.playerCount) {
        btn.className = "setup-pcount-btn flex-1 py-2.5 px-3 rounded-xl font-black text-sm transition-all capo-gold-cta text-slate-950 shadow-lg";
      } else {
        btn.className = "setup-pcount-btn flex-1 py-2.5 px-3 rounded-xl font-bold text-sm transition-all bg-slate-900/90 text-slate-200 border-2 border-slate-600";
      }
    });

    const boardBadge = document.getElementById("setup-board-topology-label");
    if (boardBadge) {
      boardBadge.textContent = setup.playerCount === 5
        ? "Dedicated 5-Arm Pentagonal Royal Star Board (65-Tile Loop + 5 Home Sanctuaries)"
        : `Classic 4-Arm Royal Cross Board (${setup.playerCount === 2 ? "Diagonal Opposite Symmetry" : setup.playerCount + "-Corner Active Match"})`;
    }

    const rosterContainer = document.getElementById("setup-players-list");
    if (rosterContainer) {
      rosterContainer.innerHTML = "";
      for (let i = 0; i < setup.playerCount; i++) {
        const p = setup.players[i];
        const pal = this.storage.getPlayerPalette(i);
        const av = getAvatarById(p.avatar);
        const row = document.createElement("div");
        row.className = "p-2.5 rounded-xl bg-slate-900/90 border-2 shadow-inner space-y-2";
        row.style.borderColor = pal.primary;

        const colorSwatchesHtml = CAPO_COLOR_PRESETS.map(preset => {
          const isSel = pal.hex.toUpperCase() === preset.hex.toUpperCase();
          return `<button type="button" data-seat-color="${i}" data-color-hex="${preset.hex}" title="${preset.name}"
            class="w-5 h-5 rounded-full border-2 transition-transform ${isSel ? 'scale-125 border-white ring-2' : 'border-slate-600 opacity-85'}"
            style="background:${preset.primary}"></button>`;
        }).join("");

        row.innerHTML = `
          <div class="flex items-center gap-2.5">
            <button type="button" data-seat-avatar="${i}" class="w-12 h-12 rounded-xl flex-shrink-0 p-0.5 transition-transform active:scale-95 relative" style="background:${pal.primary}; box-shadow: 0 0 12px ${pal.glow}" title="Tap to cycle Avatar">
              ${av.svg}
            </button>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-1.5 mb-1">
                <span class="w-2.5 h-2.5 rounded-full inline-block" style="background:${pal.primary}"></span>
                <span class="text-[11px] font-extrabold uppercase tracking-wider text-amber-300">Player ${i + 1} • ${pal.name}</span>
              </div>
              <input type="text" data-seat-name="${i}" value="${p.name.replace(/"/g, '&quot;')}" maxlength="15"
                class="w-full bg-slate-950/90 border border-slate-600 rounded-lg px-2.5 py-1 text-sm font-bold text-white outline-none" />
            </div>
            <div class="flex-shrink-0" title="Live Smart-Colored Token Preview">
              ${renderTokenPreviewSvg(setup.selectedToken, pal, "w-10 h-10")}
            </div>
            <button type="button" data-seat-bot="${i}" class="px-2.5 py-2 rounded-xl text-xs font-extrabold border-2 transition-all flex-shrink-0 ${p.isBot ? 'bg-cyan-950/90 border-cyan-400 text-cyan-200' : 'bg-amber-500/25 border-amber-400 text-amber-200'}">
              ${p.isBot ? 'Auto-AI' : 'Pass & Play'}
            </button>
          </div>
          <div class="flex items-center justify-between gap-1.5 pt-1 border-t border-slate-800">
            <div class="flex items-center gap-1 flex-wrap">${colorSwatchesHtml}</div>
            <label class="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-700 cursor-pointer text-[10px] font-bold text-amber-200" title="Custom HEX Color Picker">
              <span>HEX</span>
              <input type="color" data-seat-custom-color="${i}" value="${pal.hex}" class="w-5 h-5 cursor-pointer bg-transparent border-0" />
            </label>
          </div>
        `;
        rosterContainer.appendChild(row);
      }

      rosterContainer.querySelectorAll("[data-seat-avatar]").forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = parseInt(btn.getAttribute("data-seat-avatar"), 10);
          const curId = setup.players[idx].avatar;
          const curPos = CAPO_AVATARS.findIndex(a => a.id === curId);
          setup.players[idx].avatar = CAPO_AVATARS[(curPos + 1) % CAPO_AVATARS.length].id;
          this.storage.save();
          this.audio.uiInteract();
          this.renderSetupScreen();
        });
      });

      rosterContainer.querySelectorAll("[data-seat-name]").forEach(inp => {
        inp.addEventListener("input", () => {
          const idx = parseInt(inp.getAttribute("data-seat-name"), 10);
          setup.players[idx].name = inp.value || `Player ${idx + 1}`;
          this.storage.save();
        });
      });

      rosterContainer.querySelectorAll("[data-seat-bot]").forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = parseInt(btn.getAttribute("data-seat-bot"), 10);
          setup.players[idx].isBot = !setup.players[idx].isBot;
          this.storage.save();
          this.audio.uiInteract();
          this.renderSetupScreen();
        });
      });

      rosterContainer.querySelectorAll("[data-seat-color]").forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = parseInt(btn.getAttribute("data-seat-color"), 10);
          const hex = btn.getAttribute("data-color-hex");
          this.storage.setPlayerColor(idx, hex);
          this.audio.uiInteract();
          this.applyLiveColorAndDashboardChanges();
        });
      });

      rosterContainer.querySelectorAll("[data-seat-custom-color]").forEach(inp => {
        inp.addEventListener("input", () => {
          const idx = parseInt(inp.getAttribute("data-seat-custom-color"), 10);
          this.storage.setPlayerColor(idx, inp.value);
          this.applyLiveColorAndDashboardChanges();
        });
      });
    }

    const themeStrip = document.getElementById("setup-theme-grid");
    if (themeStrip) {
      themeStrip.innerHTML = CAPO_THEMES.map(t => {
        const active = t.id === setup.selectedTheme;
        return `
          <button type="button" data-pick-theme="${t.id}" class="p-2.5 rounded-xl border-2 text-left transition-all flex items-center gap-2.5 ${active ? 'bg-amber-500/20 border-amber-400 ring-2' : 'bg-slate-900/85 border-slate-700'}">
            <span class="w-9 h-9 rounded-lg flex-shrink-0 border-2 border-amber-300 shadow-inner" style="background: linear-gradient(135deg, ${t.bgGradTop}, ${t.boardOuterFrame})"></span>
            <div class="min-w-0 flex-1">
              <div class="text-xs font-extrabold text-white truncate">${t.name}</div>
              <div class="text-[10px] text-slate-300 truncate">${t.tagline}</div>
            </div>
          </button>
        `;
      }).join("");

      themeStrip.querySelectorAll("[data-pick-theme]").forEach(btn => {
        btn.addEventListener("click", () => {
          const tid = btn.getAttribute("data-pick-theme");
          setup.selectedTheme = tid;
          this.storage.save();
          this.applyThemeCssVariables(tid);
          this.audio.themeSelect();
          this.renderSetupScreen();
        });
      });
    }

    const diceStrip = document.getElementById("setup-dice-grid");
    if (diceStrip) {
      diceStrip.innerHTML = CAPO_DICE_SKINS.map(d => {
        const active = d.id === setup.selectedDice;
        return `
          <button type="button" data-pick-dice="${d.id}" class="p-2 rounded-xl border-2 flex flex-col items-center text-center transition-all ${active ? 'bg-amber-500/20 border-amber-400 ring-2' : 'bg-slate-900/85 border-slate-700'}">
            ${renderDiceSvg(d.id, 6, "w-12 h-12")}
            <span class="text-[11px] font-extrabold text-white mt-1 truncate w-full">${d.name}</span>
          </button>
        `;
      }).join("");

      diceStrip.querySelectorAll("[data-pick-dice]").forEach(btn => {
        btn.addEventListener("click", () => {
          setup.selectedDice = btn.getAttribute("data-pick-dice");
          this.storage.save();
          this.audio.uiInteract();
          this.renderSetupScreen();
          this.renderHomeLoadoutStrip();
        });
      });
    }

    const tokenStrip = document.getElementById("setup-token-grid");
    if (tokenStrip) {
      const p1Pal = this.storage.getPlayerPalette(0);
      tokenStrip.innerHTML = CAPO_TOKEN_SKINS.map(tk => {
        const active = tk.id === setup.selectedToken;
        return `
          <button type="button" data-pick-token="${tk.id}" class="p-2 rounded-xl border-2 flex flex-col items-center text-center transition-all relative ${active ? 'bg-amber-500/20 border-amber-400 ring-2' : 'bg-slate-900/85 border-slate-700'}">
            ${tk.isSuper ? '<span class="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[9px] uppercase mb-0.5">SUPER</span>' : '<span class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-bold text-[9px] uppercase mb-0.5">CLASSIC</span>'}
            ${renderTokenPreviewSvg(tk.id, p1Pal, "w-12 h-12")}
            <span class="text-[11px] font-extrabold text-white mt-1 truncate w-full">${tk.name}</span>
            <span class="text-[9px] text-amber-200/90 truncate w-full">${tk.abilityName || ''}</span>
          </button>
        `;
      }).join("");

      tokenStrip.querySelectorAll("[data-pick-token]").forEach(btn => {
        btn.addEventListener("click", () => {
          setup.selectedToken = btn.getAttribute("data-pick-token");
          this.storage.save();
          this.audio.uiInteract();
          this.renderSetupScreen();
          this.renderHomeLoadoutStrip();
        });
      });
    }

    const dynBtn = document.getElementById("btn-setup-dynamic-dice");
    if (dynBtn) {
      dynBtn.textContent = settings.dynamicDicePosition ? "ON" : "OFF";
      dynBtn.className = settings.dynamicDicePosition
        ? "px-3.5 py-1.5 rounded-lg font-extrabold text-xs bg-emerald-500 text-slate-950 shadow"
        : "px-3.5 py-1.5 rounded-lg font-extrabold text-xs bg-slate-700 text-slate-300";
    }
  }

  renderInventoryScreen() {
    const setup = this.storage.state.setup;
    const container = document.getElementById("inventory-items-grid");
    if (!container) return;

    document.querySelectorAll(".inv-tab-btn").forEach(btn => {
      const tab = btn.getAttribute("data-inv-tab");
      if (tab === this.inventoryTab) {
        btn.className = "inv-tab-btn flex-1 py-2 px-2 rounded-xl font-black text-[11px] uppercase tracking-wider capo-gold-cta text-slate-950 shadow-md";
      } else {
        btn.className = "inv-tab-btn flex-1 py-2 px-2 rounded-xl font-bold text-[11px] uppercase tracking-wider bg-slate-900/85 text-slate-300 border-2 border-slate-700";
      }
    });

    const p0Pal = this.storage.getPlayerPalette(0);
    const p1Pal = this.storage.getPlayerPalette(1);
    const p2Pal = this.storage.getPlayerPalette(2);
    const p3Pal = this.storage.getPlayerPalette(3);

    if (this.inventoryTab === "supertokens") {
      const superSkins = CAPO_TOKEN_SKINS.filter(tk => tk.isSuper);
      container.innerHTML = superSkins.map(tk => {
        const equipped = setup.selectedToken === tk.id;
        return `
          <div class="p-3.5 rounded-2xl border-2 ${equipped ? 'border-amber-400 bg-amber-500/15' : 'border-purple-300/60 bg-slate-900/90'} flex flex-col items-center text-center justify-between gap-2.5 shadow-xl">
            <div class="w-full flex items-center justify-between">
              <span class="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase">Super Token</span>
              <span class="text-[10px] font-extrabold text-emerald-300 uppercase">Capture-Exclusive VFX</span>
            </div>
            <div class="flex items-center justify-center gap-1.5 py-1">
              ${renderTokenPreviewSvg(tk.id, p0Pal, "w-14 h-14")}
              ${renderTokenPreviewSvg(tk.id, p1Pal, "w-12 h-12")}
              ${renderTokenPreviewSvg(tk.id, p2Pal, "w-12 h-12")}
              ${renderTokenPreviewSvg(tk.id, p3Pal, "w-12 h-12")}
            </div>
            <div>
              <div class="text-base font-black text-white">${tk.name}</div>
              <div class="text-xs font-extrabold text-amber-300 mt-0.5">${tk.abilityName}</div>
              <p class="text-[11px] text-slate-300 mt-1 leading-relaxed">${tk.abilityDesc}</p>
            </div>
            <div class="w-full flex items-center gap-2">
              <button type="button" data-equip-token="${tk.id}" class="flex-1 py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-all ${equipped ? 'bg-emerald-500 text-slate-950 shadow' : 'capo-gold-cta text-slate-950'}">
                ${equipped ? 'Equipped Super Token' : 'Equip Super Token'}
              </button>
              <button type="button" data-demo-ability="${tk.superAbility}" class="px-3 py-2.5 rounded-xl capo-secondary-btn text-amber-200 font-extrabold text-xs uppercase" title="Test Capture Ability on Board">
                Demo
              </button>
            </div>
          </div>
        `;
      }).join("");

      container.querySelectorAll("[data-equip-token]").forEach(btn => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-equip-token");
          setup.selectedToken = id;
          this.storage.save();
          this.audio.buttonPress();
          this.renderInventoryScreen();
          this.renderHomeLoadoutStrip();
          this.showToast(`Equipped ${getTokenSkinById(id).name} Super Token!`);
        });
      });

      container.querySelectorAll("[data-demo-ability]").forEach(btn => {
        btn.addEventListener("click", () => {
          const ab = btn.getAttribute("data-demo-ability");
          this.launchSuperAbilityLiveDemo(ab);
        });
      });
    } else if (this.inventoryTab === "themes") {
      container.innerHTML = CAPO_THEMES.map(t => {
        const equipped = setup.selectedTheme === t.id;
        return `
          <div class="p-3.5 rounded-2xl border-2 ${equipped ? 'border-amber-400 bg-amber-500/15' : 'border-slate-700 bg-slate-900/90'} flex flex-col justify-between gap-3 shadow-xl">
            <div class="flex items-center gap-3">
              <div class="w-14 h-14 rounded-xl border-2 border-amber-300 shadow-inner flex-shrink-0 flex items-center justify-center" style="background: radial-gradient(circle, ${t.bgGradMid}, ${t.bgGradBot})">
                <span class="w-8 h-8 rounded-md border-2 border-amber-200" style="background:${t.boardSurface}"></span>
              </div>
              <div class="min-w-0">
                <div class="text-[10px] uppercase font-extrabold text-emerald-400 tracking-wider">Unlocked World Environment</div>
                <div class="text-base font-black text-white">${t.name}</div>
                <div class="text-xs text-slate-300">${t.tagline}</div>
              </div>
            </div>
            <button type="button" data-equip-theme="${t.id}" class="w-full py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-all ${equipped ? 'bg-emerald-500 text-slate-950 shadow' : 'capo-secondary-btn text-amber-200'}">
              ${equipped ? 'Equipped World Theme' : 'Equip World Theme'}
            </button>
          </div>
        `;
      }).join("");

      container.querySelectorAll("[data-equip-theme]").forEach(btn => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-equip-theme");
          setup.selectedTheme = id;
          this.storage.save();
          this.applyThemeCssVariables(id);
          this.audio.themeSelect();
          this.renderInventoryScreen();
          this.showToast(`Equipped ${getThemeById(id).name} World Theme`);
        });
      });
    } else if (this.inventoryTab === "dice") {
      container.innerHTML = CAPO_DICE_SKINS.map(d => {
        const equipped = setup.selectedDice === d.id;
        return `
          <div class="p-3.5 rounded-2xl border-2 ${equipped ? 'border-amber-400 bg-amber-500/15' : 'border-slate-700 bg-slate-900/90'} flex flex-col items-center text-center justify-between gap-2.5 shadow-xl">
            <div class="flex items-center gap-2.5">
              ${renderDiceSvg(d.id, 6, "w-16 h-16")}
              ${renderDiceSvg(d.id, 1, "w-14 h-14")}
            </div>
            <div>
              <div class="text-[10px] uppercase font-extrabold text-emerald-400">Unlocked 3D Die</div>
              <div class="text-sm font-black text-white">${d.name}</div>
              <div class="text-xs text-slate-300">${d.subtitle}</div>
            </div>
            <button type="button" data-equip-dice="${d.id}" class="w-full py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-all ${equipped ? 'bg-emerald-500 text-slate-950 shadow' : 'capo-secondary-btn text-amber-200'}">
              ${equipped ? 'Equipped Dice Skin' : 'Equip Dice Skin'}
            </button>
          </div>
        `;
      }).join("");

      container.querySelectorAll("[data-equip-dice]").forEach(btn => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-equip-dice");
          setup.selectedDice = id;
          this.storage.save();
          this.audio.buttonPress();
          this.renderInventoryScreen();
          this.renderHomeLoadoutStrip();
          this.showToast(`Equipped ${getDiceSkinById(id).name}`);
        });
      });
    } else if (this.inventoryTab === "tokens") {
      container.innerHTML = CAPO_TOKEN_SKINS.map(tk => {
        const equipped = setup.selectedToken === tk.id;
        return `
          <div class="p-3.5 rounded-2xl border-2 ${equipped ? 'border-amber-400 bg-amber-500/15' : 'border-slate-700 bg-slate-900/90'} flex flex-col items-center text-center justify-between gap-2.5 shadow-xl">
            <div class="flex items-center justify-center gap-1.5">
              ${renderTokenPreviewSvg(tk.id, p0Pal, "w-12 h-12")}
              ${renderTokenPreviewSvg(tk.id, p1Pal, "w-12 h-12")}
              ${renderTokenPreviewSvg(tk.id, p2Pal, "w-12 h-12")}
              ${renderTokenPreviewSvg(tk.id, p3Pal, "w-12 h-12")}
            </div>
            <div>
              <div class="text-[10px] uppercase font-extrabold ${tk.isSuper ? 'text-amber-300' : 'text-emerald-400'}">${tk.isSuper ? 'Super Token • Capture Ability' : 'Classic 3D Token'}</div>
              <div class="text-sm font-black text-white">${tk.name}</div>
              <div class="text-xs text-slate-300">${tk.subtitle}</div>
            </div>
            <button type="button" data-equip-token="${tk.id}" class="w-full py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-all ${equipped ? 'bg-emerald-500 text-slate-950 shadow' : 'capo-secondary-btn text-amber-200'}">
              ${equipped ? 'Equipped Token Skin' : 'Equip Token Skin'}
            </button>
          </div>
        `;
      }).join("");

      container.querySelectorAll("[data-equip-token]").forEach(btn => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-equip-token");
          setup.selectedToken = id;
          this.storage.save();
          this.audio.buttonPress();
          this.renderInventoryScreen();
          this.renderHomeLoadoutStrip();
          this.showToast(`Equipped ${getTokenSkinById(id).name}`);
        });
      });
    } else {
      container.innerHTML = CAPO_AVATARS.map(av => {
        const p1Equipped = setup.players[0].avatar === av.id;
        return `
          <div class="p-3.5 rounded-2xl border-2 ${p1Equipped ? 'border-amber-400 bg-amber-500/15' : 'border-slate-700 bg-slate-900/90'} flex flex-col items-center text-center justify-between gap-2.5 shadow-xl">
            <div class="w-16 h-16 rounded-2xl p-0.5 bg-gradient-to-b from-amber-300 to-amber-600 shadow-lg">
              ${av.svg}
            </div>
            <div>
              <div class="text-[10px] uppercase font-extrabold text-emerald-400">${av.title}</div>
              <div class="text-sm font-black text-white">${av.name}</div>
            </div>
            <button type="button" data-equip-avatar="${av.id}" class="w-full py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-all ${p1Equipped ? 'bg-emerald-500 text-slate-950 shadow' : 'capo-secondary-btn text-amber-200'}">
              ${p1Equipped ? 'Player 1 Avatar' : 'Assign to Player 1'}
            </button>
          </div>
        `;
      }).join("");

      container.querySelectorAll("[data-equip-avatar]").forEach(btn => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-equip-avatar");
          setup.players[0].avatar = id;
          this.storage.save();
          this.audio.buttonPress();
          this.renderInventoryScreen();
          this.showToast(`Assigned ${getAvatarById(id).name} to Player 1`);
        });
      });
    }
  }

  /**
   * Launches an instant live visual demonstration of any Super Token Capture Ability on the Game Board!
   */
  launchSuperAbilityLiveDemo(abilityType) {
    this.closeAllModals();
    if (this.currentScreen !== "game") {
      this.startNewMatch();
    }
    setTimeout(() => {
      const p0 = this.rules.players[0] || { palette: this.storage.getPlayerPalette(0), name: "Player 1" };
      const p1 = this.rules.players[1] || { palette: this.storage.getPlayerPalette(1), name: "Player 2" };
      const demoNode = this.rules.board.trackNodes[8] || { x: 404, y: 181 };
      const yardPos = this.rules.board.getTokenWorldPosition(1, 0, -1);

      this.audio.playSuperAbilitySfx(abilityType);
      this.renderer.triggerSuperCaptureSequence(
        abilityType,
        demoNode.x,
        demoNode.y,
        p0.palette,
        p1.palette,
        [],
        yardPos
      );
      this.renderer.spawnFloatingText(demoNode.x, demoNode.y - 42, `SUPER CAPTURE: ${abilityType.toUpperCase()}!`, "#FEF08A");
      this.showToast(`Super Capture Ability Triggered: ${abilityType.toUpperCase()}`);
    }, 120);
  }

  /* --------------------------------------------------------------------------
   * FULL LUDO CAPO GAME DASHBOARD / ADMIN CONFIGURATION STUDIO
   * -------------------------------------------------------------------------- */
  renderDashboardModal() {
    const body = document.getElementById("dashboard-tab-content");
    if (!body) return;

    document.querySelectorAll(".dash-tab-btn").forEach(btn => {
      const t = btn.getAttribute("data-dash-tab");
      if (t === this.dashboardTab) {
        btn.className = "dash-tab-btn px-2.5 py-1.5 rounded-xl font-black text-[11px] uppercase capo-gold-cta text-slate-950";
      } else {
        btn.className = "dash-tab-btn px-2.5 py-1.5 rounded-xl font-bold text-[11px] uppercase bg-slate-900 text-slate-300 border border-slate-700";
      }
    });

    const setup = this.storage.state.setup;
    const settings = this.storage.state.settings;
    const dash = this.storage.state.dashboard;

    if (this.dashboardTab === "players") {
      const playersHtml = [0, 1, 2, 3, 4].map(idx => {
        const p = setup.players[idx];
        const pal = this.storage.getPlayerPalette(idx);
        const av = getAvatarById(p.avatar);
        const presetsBar = CAPO_COLOR_PRESETS.map(pr => {
          const active = pal.hex.toUpperCase() === pr.hex.toUpperCase();
          return `<button type="button" data-dash-pcolor="${idx}" data-hex="${pr.hex}"
            class="px-2 py-1 rounded-lg border text-[10px] font-extrabold flex items-center gap-1 ${active ? 'border-white bg-slate-800 text-amber-300 ring-2' : 'border-slate-700 bg-slate-950 text-slate-200'}">
            <span class="w-3 h-3 rounded-full inline-block border border-white/50" style="background:${pr.primary}"></span>
            <span>${pr.name}</span>
          </button>`;
        }).join("");

        return `
          <div class="p-3 rounded-2xl bg-slate-950/90 border-2 space-y-2" style="border-color:${pal.primary}">
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-2">
                <button type="button" data-dash-pavatar="${idx}" class="w-11 h-11 rounded-xl p-0.5 flex-shrink-0" style="background:${pal.primary}">
                  ${av.svg}
                </button>
                <div>
                  <div class="text-xs font-black uppercase text-amber-300">Player ${idx + 1} (${idx < setup.playerCount ? 'Active' : '5P Seat'})</div>
                  <input type="text" data-dash-pname="${idx}" value="${p.name.replace(/"/g, '&quot;')}" maxlength="15"
                    class="mt-0.5 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs font-bold text-white w-36" />
                </div>
              </div>
              <div class="flex items-center gap-2">
                <div class="text-right">
                  <div class="text-[10px] font-bold text-slate-400">Smart 3D Token</div>
                  <div class="text-[10px] font-extrabold" style="color:${pal.secondary}">${pal.name} (${pal.hex})</div>
                </div>
                ${renderTokenPreviewSvg(setup.selectedToken, pal, "w-11 h-11")}
              </div>
            </div>
            <div class="text-[10px] font-bold text-slate-300 uppercase">Preset Colors (Burgundy, Beige, Olive, Coffee, Black, White &amp; Royal Jewels):</div>
            <div class="flex items-center gap-1 flex-wrap">${presetsBar}</div>
            <div class="flex items-center justify-between gap-2 pt-1 border-t border-slate-800">
              <div class="flex items-center gap-1.5">
                <span class="text-[10px] font-bold text-amber-200">Custom Color Picker:</span>
                <input type="color" data-dash-phex-picker="${idx}" value="${pal.hex}" class="w-7 h-6 cursor-pointer bg-transparent" />
                <input type="text" data-dash-phex-text="${idx}" value="${pal.hex}" maxlength="7"
                  class="w-20 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-[11px] font-bold text-white uppercase" />
              </div>
              <div class="flex items-center gap-1 text-[9px] font-bold text-slate-400">
                <span class="px-1.5 py-0.5 rounded" style="background:${pal.primary};color:#fff">Base</span>
                <span class="px-1.5 py-0.5 rounded" style="background:${pal.dark};color:#fff">Shadow</span>
                <span class="px-1.5 py-0.5 rounded" style="background:${pal.light};color:#020617">Highlight</span>
                <span class="px-1.5 py-0.5 rounded" style="background:${pal.edge};color:#020617">Edge</span>
              </div>
            </div>
          </div>
        `;
      }).join("");

      body.innerHTML = `
        <div class="space-y-3">
          <div class="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div class="font-extrabold text-amber-300 uppercase text-xs">Active Player Count &amp; HUD Console Style</div>
              <div class="text-[11px] text-slate-300">Synchronizes Board, Yards, Paths, 3D Tokens, HUD Consoles &amp; VFX</div>
            </div>
            <div class="flex items-center gap-1.5">
              ${[2, 3, 4, 5].map(c => `<button type="button" data-dash-pcount="${c}" class="px-2.5 py-1 rounded-lg font-extrabold text-xs ${setup.playerCount === c ? 'capo-gold-cta text-slate-950' : 'bg-slate-800 text-slate-300'}">${c}P</button>`).join("")}
            </div>
          </div>
          ${playersHtml}
        </div>
      `;

      body.querySelectorAll("[data-dash-pcount]").forEach(btn => {
        btn.addEventListener("click", () => {
          setup.playerCount = parseInt(btn.getAttribute("data-dash-pcount"), 10);
          this.storage.save();
          this.audio.uiInteract();
          this.renderDashboardModal();
          this.renderSetupScreen();
        });
      });

      body.querySelectorAll("[data-dash-pavatar]").forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = parseInt(btn.getAttribute("data-dash-pavatar"), 10);
          const cur = setup.players[idx].avatar;
          const pos = CAPO_AVATARS.findIndex(a => a.id === cur);
          setup.players[idx].avatar = CAPO_AVATARS[(pos + 1) % CAPO_AVATARS.length].id;
          this.storage.save();
          this.applyLiveColorAndDashboardChanges();
          this.renderDashboardModal();
        });
      });

      body.querySelectorAll("[data-dash-pname]").forEach(inp => {
        inp.addEventListener("input", () => {
          const idx = parseInt(inp.getAttribute("data-dash-pname"), 10);
          setup.players[idx].name = inp.value || `Player ${idx + 1}`;
          this.storage.save();
          this.applyLiveColorAndDashboardChanges();
        });
      });

      body.querySelectorAll("[data-dash-pcolor]").forEach(btn => {
        btn.addEventListener("click", () => {
          const idx = parseInt(btn.getAttribute("data-dash-pcolor"), 10);
          const hex = btn.getAttribute("data-hex");
          this.storage.setPlayerColor(idx, hex);
          this.audio.uiInteract();
          this.applyLiveColorAndDashboardChanges();
          this.renderDashboardModal();
        });
      });

      body.querySelectorAll("[data-dash-phex-picker]").forEach(inp => {
        inp.addEventListener("input", () => {
          const idx = parseInt(inp.getAttribute("data-dash-phex-picker"), 10);
          this.storage.setPlayerColor(idx, inp.value);
          this.applyLiveColorAndDashboardChanges();
          this.renderDashboardModal();
        });
      });

      body.querySelectorAll("[data-dash-phex-text]").forEach(inp => {
        inp.addEventListener("change", () => {
          const idx = parseInt(inp.getAttribute("data-dash-phex-text"), 10);
          this.storage.setPlayerColor(idx, inp.value);
          this.applyLiveColorAndDashboardChanges();
          this.renderDashboardModal();
        });
      });

    } else if (this.dashboardTab === "super") {
      const sa = dash.superAbilities;
      const abilityMeta = [
        { key: "blackhole", name: "Black Hole Singularity", token: "super_blackhole", desc: "Distorts space, pulls captured token into event horizon, then collapses." },
        { key: "ice", name: "Ice / Freeze Shatter", token: "super_ice", desc: "Encases target in crystalline frost, holds dramatically, then shatters into shards." },
        { key: "fire", name: "Fire Inferno Vortex", token: "super_fire", desc: "Surrounds target in raging flames & embers, finishing with a solar burst." },
        { key: "kick", name: "3D Armored Boot Kick", token: "super_kick", desc: "Custom 3D golden boot kicks captured token flying back to its home yard." },
        { key: "devour", name: "Monster Maw Devour", token: "super_devour", desc: "Custom 3D fanged monster opens wide, pulls target inside, and chomps shut." },
        { key: "thunder", name: "Tempest Plasma Strike", token: "super_thunder", desc: "Calls down an orbital lightning bolt that vaporizes the captured token." }
      ];

      const p0Pal = this.storage.getPlayerPalette(0);

      body.innerHTML = `
        <div class="space-y-3">
          <div class="p-3 rounded-2xl bg-slate-950/90 border border-amber-400/50 space-y-2">
            <div class="flex items-center justify-between">
              <div>
                <div class="font-extrabold text-amber-300 uppercase text-xs">Super Ability Master Controller</div>
                <div class="text-[11px] text-slate-300">Triggers EXCLUSIVELY when a token confirms a capture of an enemy token</div>
              </div>
              <button type="button" id="dash-toggle-sa-master" class="px-3 py-1 rounded-lg font-extrabold text-xs ${sa.enabled ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'}">${sa.enabled ? 'ENABLED' : 'DISABLED'}</button>
            </div>
            <div class="grid grid-cols-2 gap-2 pt-1">
              <div>
                <span class="text-[10px] font-bold text-slate-300 block">Global Ability Selection</span>
                <select id="dash-sa-override" class="w-full mt-0.5 bg-slate-800 border border-slate-600 rounded-lg px-2 py-1 text-white font-bold text-xs">
                  <option value="auto" ${sa.globalOverride === 'auto' ? 'selected' : ''}>Auto (Match Equipped Super Token)</option>
                  <option value="blackhole" ${sa.globalOverride === 'blackhole' ? 'selected' : ''}>Force Black Hole Singularity</option>
                  <option value="ice" ${sa.globalOverride === 'ice' ? 'selected' : ''}>Force Ice / Freeze Shatter</option>
                  <option value="fire" ${sa.globalOverride === 'fire' ? 'selected' : ''}>Force Fire Inferno Vortex</option>
                  <option value="kick" ${sa.globalOverride === 'kick' ? 'selected' : ''}>Force 3D Armored Boot Kick</option>
                  <option value="devour" ${sa.globalOverride === 'devour' ? 'selected' : ''}>Force Monster Maw Devour</option>
                  <option value="thunder" ${sa.globalOverride === 'thunder' ? 'selected' : ''}>Force Tempest Plasma Strike</option>
                </select>
              </div>
              <div>
                <span class="text-[10px] font-bold text-slate-300 block">Equipped Super Token</span>
                <select id="dash-sa-token-select" class="w-full mt-0.5 bg-slate-800 border border-slate-600 rounded-lg px-2 py-1 text-white font-bold text-xs">
                  ${CAPO_TOKEN_SKINS.map(tk => `<option value="${tk.id}" ${setup.selectedToken === tk.id ? 'selected' : ''}>${tk.isSuper ? '[SUPER] ' : '[CLASSIC] '}${tk.name}</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="grid grid-cols-3 gap-2 pt-1">
              <div>
                <span class="text-[10px] text-slate-300 font-bold">Effect Scale (${sa.effectScale}x)</span>
                <input type="range" id="dash-sa-scale" min="70" max="140" value="${Math.round((sa.effectScale || 1) * 100)}" class="w-full" />
              </div>
              <div>
                <span class="text-[10px] text-slate-300 font-bold">Particles (${Math.round((sa.particleMultiplier || 1) * 100)}%)</span>
                <input type="range" id="dash-sa-particles" min="50" max="180" value="${Math.round((sa.particleMultiplier || 1) * 100)}" class="w-full" />
              </div>
              <div>
                <span class="text-[10px] text-slate-300 font-bold">Camera Shake (${Math.round((sa.cameraShakeMul || 1) * 100)}%)</span>
                <input type="range" id="dash-sa-shake" min="0" max="180" value="${Math.round((sa.cameraShakeMul || 1) * 100)}" class="w-full" />
              </div>
            </div>
          </div>

          <div class="space-y-2">
            ${abilityMeta.map(m => {
              const cfg = sa.abilities[m.key] || { enabled: true, duration: 1150, scale: 1.0, particles: 45 };
              return `
                <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-700 flex items-center justify-between gap-2">
                  <div class="flex items-center gap-2.5 min-w-0">
                    ${renderTokenPreviewSvg(m.token, p0Pal, "w-11 h-11")}
                    <div class="min-w-0">
                      <div class="text-xs font-black text-white">${m.name}</div>
                      <div class="text-[10px] text-slate-300 truncate">${m.desc}</div>
                      <div class="flex items-center gap-2 mt-1 text-[10px] text-amber-200 font-bold">
                        <span>Duration: ${cfg.duration}ms</span>
                        <span>•</span>
                        <span>Particles: ${cfg.particles}</span>
                      </div>
                    </div>
                  </div>
                  <div class="flex items-center gap-1.5 flex-shrink-0">
                    <button type="button" data-dash-test-ab="${m.key}" class="px-2.5 py-1.5 rounded-xl capo-gold-cta text-slate-950 font-black text-[10px] uppercase">
                      Test Capture
                    </button>
                  </div>
                </div>
              `;
            }).join("")}
          </div>
        </div>
      `;

      const masterBtn = document.getElementById("dash-toggle-sa-master");
      if (masterBtn) {
        masterBtn.addEventListener("click", () => {
          sa.enabled = !sa.enabled;
          this.storage.save();
          this.audio.buttonPress();
          this.renderDashboardModal();
        });
      }
      const ovSel = document.getElementById("dash-sa-override");
      if (ovSel) {
        ovSel.addEventListener("change", (e) => {
          sa.globalOverride = e.target.value;
          this.storage.save();
          this.audio.uiInteract();
        });
      }
      const tkSel = document.getElementById("dash-sa-token-select");
      if (tkSel) {
        tkSel.addEventListener("change", (e) => {
          setup.selectedToken = e.target.value;
          this.storage.save();
          this.applyLiveColorAndDashboardChanges();
          this.renderDashboardModal();
        });
      }
      const scInp = document.getElementById("dash-sa-scale");
      if (scInp) {
        scInp.addEventListener("input", (e) => {
          sa.effectScale = parseInt(e.target.value, 10) / 100;
          this.storage.save();
        });
      }
      const ptInp = document.getElementById("dash-sa-particles");
      if (ptInp) {
        ptInp.addEventListener("input", (e) => {
          sa.particleMultiplier = parseInt(e.target.value, 10) / 100;
          this.storage.save();
        });
      }
      const shInp = document.getElementById("dash-sa-shake");
      if (shInp) {
        shInp.addEventListener("input", (e) => {
          sa.cameraShakeMul = parseInt(e.target.value, 10) / 100;
          this.storage.save();
        });
      }
      body.querySelectorAll("[data-dash-test-ab]").forEach(btn => {
        btn.addEventListener("click", () => {
          const ab = btn.getAttribute("data-dash-test-ab");
          this.launchSuperAbilityLiveDemo(ab);
        });
      });

    } else if (this.dashboardTab === "board") {
      const b = dash.board;
      body.innerHTML = `
        <div class="space-y-3">
          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2.5">
            <div class="font-extrabold text-amber-300 uppercase text-xs">Board Geometry, Scale, Rotation &amp; Materials</div>
            <div class="flex items-center justify-between">
              <span>Board Scale (${Math.round((b.scale || 1) * 100)}%)</span>
              <input type="range" id="dash-board-scale" min="85" max="110" value="${Math.round((b.scale || 1) * 100)}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Horizontal Offset X (${b.offsetX || 0}px)</span>
              <input type="range" id="dash-board-offx" min="-35" max="35" value="${b.offsetX || 0}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Vertical Offset Y (${b.offsetY || 0}px)</span>
              <input type="range" id="dash-board-offy" min="-35" max="35" value="${b.offsetY || 0}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Board Rotation</span>
              <select id="dash-board-rot" class="bg-slate-800 border border-slate-600 rounded-lg px-2 py-1 text-white font-bold">
                <option value="0" ${b.rotationDeg === 0 ? 'selected' : ''}>0° Standard</option>
                <option value="90" ${b.rotationDeg === 90 ? 'selected' : ''}>90° Clockwise</option>
                <option value="180" ${b.rotationDeg === 180 ? 'selected' : ''}>180° Inverted</option>
                <option value="270" ${b.rotationDeg === 270 ? 'selected' : ''}>270° Counter-CW</option>
              </select>
            </div>
            <div class="flex items-center justify-between">
              <span>Board Surface Material</span>
              <select id="dash-board-mat" class="bg-slate-800 border border-slate-600 rounded-lg px-2 py-1 text-white font-bold">
                <option value="theme" ${b.surfaceMaterial === 'theme' ? 'selected' : ''}>Match Active World Theme</option>
                <option value="parchment" ${b.surfaceMaterial === 'parchment' ? 'selected' : ''}>Royal Warm Parchment</option>
                <option value="marble" ${b.surfaceMaterial === 'marble' ? 'selected' : ''}>Imperial White Marble</option>
                <option value="obsidian" ${b.surfaceMaterial === 'obsidian' ? 'selected' : ''}>Volcanic Dark Obsidian</option>
                <option value="crystal" ${b.surfaceMaterial === 'crystal' ? 'selected' : ''}>Glacial Ice Crystal</option>
                <option value="wood" ${b.surfaceMaterial === 'wood' ? 'selected' : ''}>Sovereign Carved Wood</option>
              </select>
            </div>
            <div class="flex items-center justify-between">
              <span>Tile Cell Spacing (${b.cellGap || 0}px)</span>
              <input type="range" id="dash-board-gap" min="0" max="4" step="0.5" value="${b.cellGap || 0}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Home Yard Token Socket Scale (${Math.round((b.yardSocketScale || 1) * 100)}%)</span>
              <input type="range" id="dash-board-yard" min="85" max="115" value="${Math.round((b.yardSocketScale || 1) * 100)}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Center Sanctuary Scale (${Math.round((b.centerScale || 1) * 100)}%)</span>
              <input type="range" id="dash-board-center" min="85" max="120" value="${Math.round((b.centerScale || 1) * 100)}" class="w-40" />
            </div>
            <div class="pt-2">
              <button type="button" id="dash-reset-board" class="w-full py-2 rounded-xl bg-slate-800 border border-slate-600 font-bold text-amber-200">Reset Board Geometry to Default</button>
            </div>
          </div>
        </div>
      `;

      const bindRange = (id, fn) => {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", (e) => {
          fn(parseFloat(e.target.value));
          this.storage.save();
          if (this.renderer) this.renderer.renderFrame(performance.now());
        });
      };
      bindRange("dash-board-scale", v => { b.scale = v / 100; });
      bindRange("dash-board-offx", v => { b.offsetX = v; });
      bindRange("dash-board-offy", v => { b.offsetY = v; });
      bindRange("dash-board-gap", v => { b.cellGap = v; });
      bindRange("dash-board-yard", v => { b.yardSocketScale = v / 100; });
      bindRange("dash-board-center", v => { b.centerScale = v / 100; });

      const rotEl = document.getElementById("dash-board-rot");
      if (rotEl) rotEl.addEventListener("change", (e) => {
        b.rotationDeg = parseInt(e.target.value, 10);
        this.storage.save();
        if (this.renderer) this.renderer.renderFrame(performance.now());
      });
      const matEl = document.getElementById("dash-board-mat");
      if (matEl) matEl.addEventListener("change", (e) => {
        b.surfaceMaterial = e.target.value;
        this.storage.save();
        if (this.renderer) this.renderer.renderFrame(performance.now());
      });
      const resBtn = document.getElementById("dash-reset-board");
      if (resBtn) resBtn.addEventListener("click", () => {
        dash.board = JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultDashboard.board));
        this.storage.save();
        this.renderDashboardModal();
        if (this.renderer) this.renderer.renderFrame(performance.now());
        this.showToast("Board geometry restored to defaults");
      });

    } else if (this.dashboardTab === "dice_tokens") {
      const tk = dash.token;
      const dc = dash.dice;
      body.innerHTML = `
        <div class="space-y-3">
          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2.5">
            <div class="font-extrabold text-amber-300 uppercase text-xs">3D Dice Configuration &amp; Anchors</div>
            <div class="flex items-center justify-between">
              <span>Active 3D Dice Skin</span>
              <select id="dash-dice-skin" class="bg-slate-800 border border-slate-600 rounded-lg px-2 py-1 text-white font-bold">
                ${CAPO_DICE_SKINS.map(d => `<option value="${d.id}" ${setup.selectedDice === d.id ? 'selected' : ''}>${d.name}</option>`).join("")}
              </select>
            </div>
            <div class="flex items-center justify-between">
              <span>Dynamic Dice Position (Glides to Active Player Well)</span>
              <button type="button" id="dash-dice-dyn" class="px-3 py-1 rounded-lg font-extrabold text-xs ${settings.dynamicDicePosition ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'}">${settings.dynamicDicePosition ? 'ON' : 'OFF'}</button>
            </div>
            <div class="flex items-center justify-between">
              <span>Dice Scale (${Math.round((dc.scale || 1) * 100)}%)</span>
              <input type="range" id="dash-dice-scale" min="80" max="130" value="${Math.round((dc.scale || 1) * 100)}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Dice Roll Animation Speed (${settings.diceSpeed}x)</span>
              <input type="range" id="dash-dice-spd" min="50" max="200" value="${Math.round((settings.diceSpeed || 1) * 100)}" class="w-40" />
            </div>
          </div>

          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2.5">
            <div class="font-extrabold text-amber-300 uppercase text-xs">3D Token &amp; Super Token Configuration</div>
            <div class="flex items-center justify-between">
              <span>Token Size / Scale (${Math.round((tk.scale || 1) * 100)}%)</span>
              <input type="range" id="dash-token-scale" min="80" max="135" value="${Math.round((tk.scale || 1) * 100)}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Token Movement Hop Speed (${settings.tokenSpeed}x)</span>
              <input type="range" id="dash-token-spd" min="50" max="200" value="${Math.round((settings.tokenSpeed || 1) * 100)}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Idle Breathing Animation Speed</span>
              <input type="range" id="dash-token-idle" min="50" max="200" value="${Math.round((tk.idleSpeed || 1) * 100)}" class="w-40" />
            </div>
            <div class="flex items-center justify-between">
              <span>Selection Ring Pulse Speed</span>
              <input type="range" id="dash-token-pulse" min="50" max="200" value="${Math.round((tk.selectionPulse || 1) * 100)}" class="w-40" />
            </div>
          </div>
        </div>
      `;

      const dsEl = document.getElementById("dash-dice-skin");
      if (dsEl) dsEl.addEventListener("change", (e) => {
        setup.selectedDice = e.target.value;
        this.storage.save();
        this.updateDiceVisual(this.rules.currentDiceValue || 6, false);
        this.renderHomeLoadoutStrip();
      });
      const ddBtn = document.getElementById("dash-dice-dyn");
      if (ddBtn) ddBtn.addEventListener("click", () => {
        settings.dynamicDicePosition = !settings.dynamicDicePosition;
        this.storage.save();
        this.renderDashboardModal();
        if (this.currentScreen === "game") this.syncTurnHud();
      });
      const dscEl = document.getElementById("dash-dice-scale");
      if (dscEl) dscEl.addEventListener("input", (e) => {
        dc.scale = parseInt(e.target.value, 10) / 100;
        const ring = document.getElementById("floating-dice-ring");
        if (ring) ring.style.transform = `scale(${dc.scale})`;
        this.storage.save();
      });
      const dspEl = document.getElementById("dash-dice-spd");
      if (dspEl) dspEl.addEventListener("input", (e) => {
        settings.diceSpeed = parseInt(e.target.value, 10) / 100;
        this.storage.save();
      });
      const tscEl = document.getElementById("dash-token-scale");
      if (tscEl) tscEl.addEventListener("input", (e) => {
        tk.scale = parseInt(e.target.value, 10) / 100;
        this.storage.save();
        if (this.renderer) this.renderer.renderFrame(performance.now());
      });
      const tspEl = document.getElementById("dash-token-spd");
      if (tspEl) tspEl.addEventListener("input", (e) => {
        settings.tokenSpeed = parseInt(e.target.value, 10) / 100;
        this.storage.save();
      });
      const tidEl = document.getElementById("dash-token-idle");
      if (tidEl) tidEl.addEventListener("input", (e) => {
        tk.idleSpeed = parseInt(e.target.value, 10) / 100;
        this.storage.save();
      });
      const tplEl = document.getElementById("dash-token-pulse");
      if (tplEl) tplEl.addEventListener("input", (e) => {
        tk.selectionPulse = parseInt(e.target.value, 10) / 100;
        this.storage.save();
      });

    } else if (this.dashboardTab === "audio_vfx") {
      body.innerHTML = `
        <div class="space-y-3">
          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2">
            <div class="font-extrabold text-amber-300 uppercase text-xs">Multi-Channel Audio Mixer</div>
            ${[
              ["masterVolume", "Master Volume"],
              ["musicVolume", "Theme Music Volume"],
              ["sfxVolume", "Global SFX Volume"],
              ["diceVolume", "3D Dice Roll & Land Sounds"],
              ["tokenVolume", "Token Hop & Safe Star Sounds"],
              ["captureVolume", "Classic Capture Sounds"],
              ["superAbilityVolume", "Super Ability Cinematic Sounds"],
              ["victoryVolume", "Victory Fanfare Sounds"],
              ["uiVolume", "Menu & UI Button Sounds"]
            ].map(([key, label]) => `
              <div class="flex items-center justify-between">
                <span>${label}</span>
                <input type="range" data-dash-vol="${key}" min="0" max="100" value="${Math.round((settings[key] !== undefined ? settings[key] : 1) * 100)}" class="w-36" />
              </div>
            `).join("")}
          </div>

          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2">
            <div class="font-extrabold text-amber-300 uppercase text-xs">VFX, Shaders &amp; Camera Feedback</div>
            <div class="grid grid-cols-2 gap-2">
              ${[
                ["vfxEnabled", "Particles Master"],
                ["superAbilityVfxEnabled", "Super Capture VFX"],
                ["trailsEnabled", "Motion Blur Trails"],
                ["screenEffects", "Camera Impact Shake"],
                ["captureVfxEnabled", "Capture Shockwaves"],
                ["themeVfxEnabled", "World Ambient Particles"]
              ].map(([key, label]) => {
                const on = settings[key] !== false;
                return `<button type="button" data-dash-vfx-toggle="${key}" class="p-2 rounded-xl border text-left flex items-center justify-between ${on ? 'bg-emerald-500/25 border-emerald-300/60 text-white' : 'bg-slate-900 border-slate-700 text-slate-400'}">
                  <span class="font-bold text-[11px]">${label}</span>
                  <span class="font-black text-[10px]">${on ? 'ON' : 'OFF'}</span>
                </button>`;
              }).join("")}
            </div>
          </div>
        </div>
      `;

      body.querySelectorAll("[data-dash-vol]").forEach(inp => {
        inp.addEventListener("input", () => {
          const k = inp.getAttribute("data-dash-vol");
          settings[k] = parseInt(inp.value, 10) / 100;
          this.storage.save();
          this.syncSettingsControls();
        });
      });

      body.querySelectorAll("[data-dash-vfx-toggle]").forEach(btn => {
        btn.addEventListener("click", () => {
          const k = btn.getAttribute("data-dash-vfx-toggle");
          settings[k] = !(settings[k] !== false);
          this.storage.save();
          this.audio.uiInteract();
          this.renderDashboardModal();
          this.syncSettingsControls();
        });
      });

    } else {
      const sc = dash.scoring;
      body.innerHTML = `
        <div class="space-y-3">
          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2">
            <div class="font-extrabold text-amber-300 uppercase text-xs">Validated Gameplay Rules Engine</div>
            <div class="grid grid-cols-2 gap-2">
              ${[
                ["sixExitRequired", "Require 6 to Exit Yard"],
                ["sixBonusTurn", "Extra Roll on Rolling 6"],
                ["captureBonusTurn", "Extra Roll on Capture"],
                ["finishBonusTurn", "Extra Roll on Token Finish"],
                ["tripleSixRule", "Triple-6 Turn Forfeit"],
                ["safeZonesEnabled", "Protected Star Safe Zones"],
                ["exactFinishRoll", "Exact Roll for Finish"],
                ["autoMoveSingle", "Auto-Move Single Legal Token"]
              ].map(([key, label]) => {
                const on = settings[key] !== false;
                return `<button type="button" data-dash-rule="${key}" class="p-2 rounded-xl border text-left flex items-center justify-between ${on ? 'bg-amber-500/20 border-amber-400 text-white' : 'bg-slate-900 border-slate-700 text-slate-400'}">
                  <span class="font-bold text-[11px]">${label}</span>
                  <span class="font-black text-[10px] text-amber-300">${on ? 'ON' : 'OFF'}</span>
                </button>`;
              }).join("")}
            </div>
          </div>

          <div class="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2">
            <div class="font-extrabold text-amber-300 uppercase text-xs">Smart Strategic Score Model Weights</div>
            ${[
              ["basicCapturePts", "Basic Capture Points", 5, 50],
              ["strategicCapturePts", "Strategic Capture Points (Advanced Enemy)", 10, 60],
              ["multiCaptureChainPts", "Multiple-Capture Streak Bonus", 10, 80],
              ["escapeDangerPts", "Saving Token From Danger Bonus", 5, 40],
              ["safeZoneAnchorPts", "Safe Star Positioning Bonus", 5, 30],
              ["enterHomeStretchPts", "Entering Home Stretch Bonus", 5, 40],
              ["finishTokenPts", "Finishing Token Points", 15, 80],
              ["victoryBonusPts", "Winning Match Bonus", 50, 250]
            ].map(([k, label, min, max]) => `
              <div class="flex items-center justify-between">
                <span>${label} (+${sc[k]} pts)</span>
                <input type="range" data-dash-score="${k}" min="${min}" max="${max}" step="5" value="${sc[k]}" class="w-32" />
              </div>
            `).join("")}
          </div>
        </div>
      `;

      body.querySelectorAll("[data-dash-rule]").forEach(btn => {
        btn.addEventListener("click", () => {
          const k = btn.getAttribute("data-dash-rule");
          settings[k] = !(settings[k] !== false);
          this.storage.save();
          this.audio.buttonPress();
          this.renderDashboardModal();
          this.syncSettingsControls();
        });
      });

      body.querySelectorAll("[data-dash-score]").forEach(inp => {
        inp.addEventListener("input", () => {
          const k = inp.getAttribute("data-dash-score");
          sc[k] = parseInt(inp.value, 10);
          this.storage.save();
          this.renderDashboardModal();
        });
      });
    }
  }

  /* --------------------------------------------------------------------------
   * GAMEPLAY LAUNCH, LUDO KING PLAYER CONSOLES & DYNAMIC DICE WELL ANCHORS
   * -------------------------------------------------------------------------- */
  startNewMatch(overridePlayerCount = null) {
    this.matchSessionId += 1;
    clearTimeout(this.botTimeout);
    this.isRollingDice = false;
    this.isAnimatingToken = false;

    const setup = this.storage.state.setup;
    if (overridePlayerCount) {
      setup.playerCount = overridePlayerCount;
      this.storage.save();
    }

    this.applyThemeCssVariables(setup.selectedTheme);
    this.rules.initMatch(setup);
    this.storage.recordMatchStart(setup.selectedTheme, setup.selectedDice, setup.selectedToken);

    this.closeAllModals();
    this.showScreen("game");
    this.audio.gameStart();
    this.audio.startMusic(setup.selectedTheme);

    this.buildPlayerHudPods();
    this.resizeBoardCanvas();
    this.renderAnchorPinsOverlay();
    this.updateDiceVisual(6, false);

    setTimeout(() => {
      this.resizeBoardCanvas();
      this.syncTurnHud(true);
    }, 25);
  }

  resizeBoardCanvas() {
    const canvas = document.getElementById("ludo-board-canvas");
    if (!canvas) return;

    const vw = window.innerWidth || 430;
    const vh = window.innerHeight || 932;

    const maxW = Math.min(vw - 12, 600);
    const maxH = Math.max(290, vh - 208);
    const boardPx = Math.floor(Math.min(maxW, maxH));

    canvas.style.width = `${boardPx}px`;
    canvas.style.height = `${boardPx}px`;

    const topBar = document.getElementById("top-player-consoles");
    const botBar = document.getElementById("bottom-player-consoles");
    if (topBar) topBar.style.maxWidth = `${boardPx}px`;
    if (botBar) botBar.style.maxWidth = `${boardPx}px`;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = boardPx * dpr;
    canvas.height = boardPx * dpr;

    if (this.renderer) {
      this.renderer.renderFrame(performance.now());
    }
  }

  getActiveAnchorList() {
    return this.rules.playerCount === 5
      ? this.storage.state.anchors5P
      : this.storage.state.anchors4P;
  }

  getAnchorCoordsForSeat(seatIdx) {
    const anchors = this.getActiveAnchorList();
    const aIdx = this.rules.playerCount === 5 ? seatIdx : this.rules.board.getCornerForSeat(seatIdx);
    const savedAnchor = anchors[aIdx];

    if (savedAnchor && savedAnchor.custom) {
      return savedAnchor;
    }

    const stage = document.getElementById("game-stage-container");
    const well = document.getElementById(`dice-well-seat-${seatIdx}`);
    if (stage && well) {
      const sRect = stage.getBoundingClientRect();
      const wRect = well.getBoundingClientRect();
      if (sRect.width > 0 && sRect.height > 0 && wRect.width > 0) {
        const cx = ((wRect.left + wRect.width / 2 - sRect.left) / sRect.width) * 100;
        const cy = ((wRect.top + wRect.height / 2 - sRect.top) / sRect.height) * 100;
        if (savedAnchor) {
          savedAnchor.x = Math.round(cx * 10) / 10;
          savedAnchor.y = Math.round(cy * 10) / 10;
        }
        return { x: cx, y: cy };
      }
    }

    return savedAnchor || { x: 50, y: 50 };
  }

  buildPlayerHudPods() {
    const topRow = document.getElementById("top-player-consoles");
    const botRow = document.getElementById("bottom-player-consoles");
    const legacyLayer = document.getElementById("player-pods-layer");
    if (legacyLayer) legacyLayer.innerHTML = "";
    if (!topRow || !botRow) return;

    topRow.innerHTML = "";
    botRow.innerHTML = "";

    const is5P = this.rules.playerCount === 5;

    const createConsoleCard = (player, alignRight = false, compact5P = false) => {
      if (!player) {
        const empty = document.createElement("div");
        empty.className = "w-40 h-14 opacity-0 pointer-events-none";
        return empty;
      }
      const av = getAvatarById(player.avatar);
      const pal = player.palette;

      const consoleEl = document.createElement("div");
      consoleEl.id = `hud-pod-seat-${player.seatIdx}`;
      consoleEl.className = `${compact5P ? 'ludo-player-console-5p flex-1' : 'ludo-player-console'} relative flex items-center ${alignRight ? 'flex-row-reverse text-right' : 'flex-row text-left'} gap-1.5 px-2 py-1.5 rounded-2xl transition-all duration-300 pointer-events-auto select-none`;
      consoleEl.style.borderColor = pal.primary;
      consoleEl.style.background = `linear-gradient(180deg, ${pal.dark}EE 0%, #071026FA 100%)`;

      const avatarBlock = `
        <div class="relative ${compact5P ? 'w-8 h-8' : 'w-11 h-11'} rounded-xl p-0.5 flex-shrink-0 shadow-md" style="background: linear-gradient(135deg, ${pal.edge || '#FEF08A'}, ${pal.primary})">
          ${av.svg}
          <span id="pod-turn-dot-${player.seatIdx}" class="hidden absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-300 ring-2 animate-ping"></span>
        </div>
      `;

      const infoBlock = `
        <div class="min-w-0 flex-1 px-0.5">
          <div class="flex items-center ${alignRight ? 'justify-end' : 'justify-start'} gap-1">
            <span class="text-xs font-black text-white truncate ${compact5P ? 'max-w-[50px] text-[10px]' : 'max-w-[76px] text-xs'} drop-shadow">${player.name}</span>
            <span id="pod-score-${player.seatIdx}" class="px-1 py-0.5 rounded bg-slate-950/90 border border-amber-400/60 text-[9px] font-black text-amber-300">${player.smartScore || 0}pt</span>
          </div>
          <div class="flex items-center ${alignRight ? 'justify-end' : 'justify-start'} gap-1 mt-1" id="pod-pips-${player.seatIdx}">
            ${[0, 1, 2, 3].map(idx => `<span class="w-2.5 h-2.5 rounded-full border border-white/80 inline-block flex-shrink-0 shadow-sm" style="background:${idx < player.finishedCount ? '#FACC15' : pal.primary}"></span>`).join("")}
          </div>
          <div id="pod-status-${player.seatIdx}" class="text-[10px] font-extrabold uppercase tracking-wider text-amber-300 mt-0.5 truncate">READY</div>
        </div>
      `;

      const diceWellBlock = `
        <div id="dice-well-seat-${player.seatIdx}" class="recessed-dice-well ${compact5P ? 'w-11 h-11' : 'w-14 h-14'} rounded-xl flex-shrink-0 flex items-center justify-center relative" style="border-color: ${pal.secondary}">
          <span class="text-[9px] font-black uppercase text-slate-400/50 select-none">DICE</span>
        </div>
      `;

      consoleEl.innerHTML = avatarBlock + infoBlock + diceWellBlock;
      return consoleEl;
    };

    if (is5P) {
      topRow.appendChild(createConsoleCard(this.rules.players[0], false, false));
      topRow.appendChild(createConsoleCard(this.rules.players[1], true, false));

      botRow.appendChild(createConsoleCard(this.rules.players[4], false, true));
      botRow.appendChild(createConsoleCard(this.rules.players[3], false, true));
      botRow.appendChild(createConsoleCard(this.rules.players[2], true, true));
    } else {
      const byCorner = {};
      this.rules.players.forEach(p => { byCorner[p.cornerIdx] = p; });

      topRow.appendChild(createConsoleCard(byCorner[0] || null, false, false));
      topRow.appendChild(createConsoleCard(byCorner[1] || null, true, false));

      botRow.appendChild(createConsoleCard(byCorner[3] || null, false, false));
      botRow.appendChild(createConsoleCard(byCorner[2] || null, true, false));
    }
  }

  renderAnchorPinsOverlay() {
    const layer = document.getElementById("dice-anchors-overlay");
    if (!layer) return;
    layer.innerHTML = "";
    if (!this.anchorEditMode) {
      layer.classList.add("hidden");
      return;
    }
    layer.classList.remove("hidden");

    const anchors = this.getActiveAnchorList();
    anchors.forEach((anc, idx) => {
      const pal = this.storage.getPlayerPalette(idx);
      const pin = document.createElement("div");
      pin.className = "AnchorPin absolute -translate-x-1/2 -translate-y-1/2 px-2.5 py-1.5 rounded-xl border-2 border-amber-300 bg-slate-950/95 text-white text-[11px] font-extrabold shadow-2xl cursor-move flex items-center gap-1.5 select-none z-40";
      pin.style.left = `${anc.x}%`;
      pin.style.top = `${anc.y}%`;
      pin.innerHTML = `
        <span class="w-3 h-3 rounded-full" style="background:${pal.primary}"></span>
        <span>P${idx + 1} Anchor</span>
      `;

      const startDrag = (e) => {
        e.preventDefault();
        this.draggingAnchorIdx = idx;
      };
      pin.addEventListener("mousedown", startDrag);
      pin.addEventListener("touchstart", startDrag, { passive: false });
      layer.appendChild(pin);
    });
  }

  syncTurnHud(initialSnap = false) {
    const activePlayer = this.rules.getActivePlayer();
    if (!activePlayer) return;

    const settings = this.storage.state.settings;

    this.rules.players.forEach(p => {
      const pod = document.getElementById(`hud-pod-seat-${p.seatIdx}`);
      const dot = document.getElementById(`pod-turn-dot-${p.seatIdx}`);
      const status = document.getElementById(`pod-status-${p.seatIdx}`);
      const pips = document.getElementById(`pod-pips-${p.seatIdx}`);
      const well = document.getElementById(`dice-well-seat-${p.seatIdx}`);
      const scoreBadge = document.getElementById(`pod-score-${p.seatIdx}`);

      if (scoreBadge) {
        scoreBadge.textContent = `${p.smartScore || 0}pt`;
      }

      if (pips) {
        pips.innerHTML = [0, 1, 2, 3].map(idx =>
          `<span class="w-2.5 h-2.5 rounded-full border border-white/80 inline-block flex-shrink-0 shadow-sm" style="background:${idx < p.finishedCount ? '#FACC15' : p.palette.primary}"></span>`
        ).join("");
      }

      const isTurn = p.seatIdx === activePlayer.seatIdx;
      if (pod) {
        if (isTurn) {
          pod.classList.add("console-active-turn");
          pod.style.boxShadow = `0 0 24px ${p.palette.glow}, inset 0 0 14px rgba(251, 191, 36, 0.35)`;
          pod.style.borderColor = p.palette.edge || "#FACC15";
          pod.style.transform = "scale(1.03)";
          pod.style.opacity = "1";
        } else {
          pod.classList.remove("console-active-turn");
          pod.style.boxShadow = "0 6px 14px rgba(0,0,0,0.55)";
          pod.style.borderColor = p.palette.primary;
          pod.style.transform = "scale(0.96)";
          pod.style.opacity = "0.78";
        }
      }
      if (well) {
        well.style.background = isTurn
          ? `radial-gradient(circle, ${p.palette.light} 0%, ${p.palette.primary} 100%)`
          : "rgba(9, 14, 28, 0.85)";
      }
      if (dot) {
        if (isTurn) dot.classList.remove("hidden");
        else dot.classList.add("hidden");
      }
      if (status) {
        if (p.finishedCount === 4) {
          status.textContent = `RANK #${p.rank}`;
          status.className = "text-[10px] font-extrabold uppercase tracking-wider text-emerald-400 mt-0.5";
        } else if (isTurn) {
          status.textContent = this.rules.phase === "SELECT_TOKEN" ? "MOVE TOKEN" : "YOUR TURN";
          status.className = "text-[10px] font-extrabold uppercase tracking-wider text-amber-300 mt-0.5";
        } else {
          status.textContent = p.isBot ? "AUTO-AI" : "STANDBY";
          status.className = "text-[10px] font-bold uppercase tracking-wider text-slate-400 mt-0.5";
        }
      }
    });

    const banner = document.getElementById("game-turn-banner");
    if (banner) {
      banner.textContent = this.rules.phase === "SELECT_TOKEN"
        ? `${activePlayer.name}: Tap a Glowing Token (Rolled ${this.rules.currentDiceValue})`
        : `${activePlayer.name}'s Turn — Tap 3D Dice`;
      banner.style.borderColor = activePlayer.palette.secondary;
    }

    const diceWidget = document.getElementById("floating-dice-widget");
    const diceRing = document.getElementById("floating-dice-ring");
    if (diceWidget) {
      let target = { x: 50, y: 92 };
      if (settings.dynamicDicePosition) {
        target = this.getAnchorCoordsForSeat(activePlayer.seatIdx);
      }

      const turnSpeed = settings.turnSpeed * settings.gameSpeed;
      const durationMs = initialSnap ? 0 : Math.round(480 / Math.max(0.5, turnSpeed));

      diceWidget.style.transition = durationMs > 0
        ? `left ${durationMs}ms cubic-bezier(0.34, 1.56, 0.64, 1), top ${durationMs}ms cubic-bezier(0.34, 1.56, 0.64, 1), transform 280ms ease`
        : "none";
      diceWidget.style.left = `${target.x}%`;
      diceWidget.style.top = `${target.y}%`;

      if (!initialSnap && durationMs > 0) {
        diceWidget.classList.add("dice-flight-arc");
        setTimeout(() => diceWidget.classList.remove("dice-flight-arc"), durationMs);
      }

      if (diceRing) {
        diceRing.style.borderColor = activePlayer.palette.edge || "#FACC15";
        diceRing.style.boxShadow = `0 0 26px ${activePlayer.palette.glow}`;
      }
    }

    const dynToggleBtn = document.getElementById("btn-hud-dyn-dice");
    if (dynToggleBtn) {
      dynToggleBtn.textContent = `Dyn Dice: ${settings.dynamicDicePosition ? "ON" : "OFF"}`;
    }
    const speedBtn = document.getElementById("btn-hud-speed");
    if (speedBtn) {
      speedBtn.textContent = `${settings.gameSpeed}x Speed`;
    }

    if (activePlayer.isBot && this.rules.phase === "WAITING_FOR_ROLL") {
      clearTimeout(this.botTimeout);
      const session = this.matchSessionId;
      this.botTimeout = setTimeout(() => {
        if (this.matchSessionId === session && this.currentScreen === "game" && this.rules.phase === "WAITING_FOR_ROLL") {
          this.triggerDiceRoll();
        }
      }, Math.round(520 / (settings.gameSpeed || 1)));
    }
  }

  updateDiceVisual(faceValue, isRolling = false) {
    const box = document.getElementById("floating-dice-svg-box");
    const label = document.getElementById("floating-dice-label");
    const skinId = this.storage.state.setup.selectedDice;
    if (box) {
      box.innerHTML = renderDiceSvg(skinId, faceValue, "w-14 h-14");
    }
    if (label) {
      label.textContent = isRolling ? "ROLLING..." : `TAP [${faceValue}]`;
    }
  }

  triggerDiceRoll() {
    if (this.currentScreen !== "game") return;
    if (this.rules.phase !== "WAITING_FOR_ROLL" || this.isRollingDice || this.isAnimatingToken) return;

    const session = this.matchSessionId;
    const settings = this.storage.state.settings;
    const speedMul = Math.max(0.5, settings.diceSpeed * settings.gameSpeed);

    this.isRollingDice = true;
    this.rules.phase = "ROLLING";
    this.audio.diceRoll();

    const diceBox = document.getElementById("floating-dice-svg-box");
    if (diceBox) {
      diceBox.classList.add("dice-tumble-anim");
    }

    const activePlayer = this.rules.getActivePlayer();
    const allInYard = activePlayer.tokens.every(t => t.relStep === -1);
    let finalVal = Math.floor(Math.random() * 6) + 1;
    if (allInYard && Math.random() < 0.25) {
      finalVal = 6;
    }

    let ticks = 0;
    const maxTicks = 7;
    const intervalMs = Math.round(62 / speedMul);

    const rollTimer = setInterval(() => {
      if (this.matchSessionId !== session) {
        clearInterval(rollTimer);
        return;
      }
      ticks++;
      if (ticks < maxTicks) {
        const tempFace = ((ticks + Math.floor(Math.random() * 5)) % 6) + 1;
        this.updateDiceVisual(tempFace, true);
        if (ticks === 3) this.audio.diceBounce();
      } else {
        clearInterval(rollTimer);
        if (diceBox) diceBox.classList.remove("dice-tumble-anim");
        this.isRollingDice = false;
        this.updateDiceVisual(finalVal, false);
        this.audio.diceLand(finalVal === 6);

        if (finalVal === 6 && this.renderer) {
          this.renderer.triggerShake(6, 180);
        }

        this.handleDiceResult(finalVal, session);
      }
    }, intervalMs);
  }

  handleDiceResult(finalVal, session) {
    if (this.matchSessionId !== session) return;
    const outcome = this.rules.evaluateRollOutcome(finalVal);
    const settings = this.storage.state.settings;
    const speedMul = Math.max(0.5, settings.turnSpeed * settings.gameSpeed);

    const banner = document.getElementById("game-turn-banner");
    if (banner) banner.textContent = outcome.message;

    if (outcome.status === "TRIPLE_SIX_FORFEIT" || outcome.status === "NO_VALID_MOVES") {
      this.showToast(outcome.message);
      setTimeout(() => {
        if (this.matchSessionId !== session) return;
        this.rules.advanceToNextPlayer();
        this.audio.turnChange();
        this.syncTurnHud();
      }, Math.round(920 / speedMul));
      return;
    }

    this.syncTurnHud();
    const activePlayer = this.rules.getActivePlayer();

    if (activePlayer.isBot || (settings.autoMoveSingle && outcome.validTokens.length === 1)) {
      const chosen = this.rules.chooseSmartMove(outcome.validTokens, finalVal);
      setTimeout(() => {
        if (this.matchSessionId !== session || this.rules.phase !== "SELECT_TOKEN") return;
        this.executeTokenSelection(chosen);
      }, Math.round(400 / speedMul));
    }
  }

  executeTokenSelection(token) {
    if (!token || this.rules.phase !== "SELECT_TOKEN" || this.isAnimatingToken) return;
    if (!this.rules.validTokenIds.includes(token.id)) return;

    const session = this.matchSessionId;
    const settings = this.storage.state.settings;
    const speedMul = Math.max(0.5, settings.tokenSpeed * settings.gameSpeed);

    this.isAnimatingToken = true;
    this.rules.phase = "ANIMATING_MOVE";
    this.audio.tokenSelect();

    const plan = this.rules.planTokenMove(token, this.rules.currentDiceValue);
    const player = this.rules.players[token.seatIdx];

    this.rules.validTokenIds = [];

    let wpIdx = 0;
    const stepNextWaypoint = () => {
      if (this.matchSessionId !== session) return;
      if (wpIdx >= plan.waypoints.length) {
        token.animX = null;
        token.animY = null;
        token.hopZ = 0;
        token.animScale = 1;
        this.finalizeTokenMove(token, plan.endStep, plan.chosenAnalysis, plan.allAnalyses, session);
        return;
      }

      const fromPos = wpIdx === 0
        ? this.rules.board.getTokenWorldPosition(token.seatIdx, token.tokenIndex, plan.startStep)
        : plan.waypoints[wpIdx - 1].pos;
      const toPos = plan.waypoints[wpIdx].pos;
      const hopDuration = Math.max(65, Math.round(145 / speedMul));
      const startTime = performance.now();

      this.audio.tokenMove(wpIdx);

      const animateHop = (now) => {
        if (this.matchSessionId !== session) return;
        const t = Math.min(1, (now - startTime) / hopDuration);
        const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

        token.animX = fromPos.x + (toPos.x - fromPos.x) * ease;
        token.animY = fromPos.y + (toPos.y - fromPos.y) * ease;
        token.hopZ = Math.sin(t * Math.PI) * 32;
        token.animScale = 1 + Math.sin(t * Math.PI) * 0.20;

        if (this.renderer && Math.random() < 0.55) {
          this.renderer.addTrailPoint(token.animX, token.animY, player.palette.light);
        }

        if (t < 1) {
          requestAnimationFrame(animateHop);
        } else {
          token.relStep = plan.waypoints[wpIdx].relStep;
          wpIdx++;
          stepNextWaypoint();
        }
      };

      requestAnimationFrame(animateHop);
    };

    stepNextWaypoint();
  }

  finalizeTokenMove(token, endStep, chosenAnalysis, allAnalyses, session) {
    if (this.matchSessionId !== session) return;
    const player = this.rules.players[token.seatIdx];
    const res = this.rules.commitTokenMove(token, endStep, chosenAnalysis, allAnalyses);
    const dest = res.destInfo;
    const theme = getThemeById(this.storage.state.setup.selectedTheme);

    // Display Smart Score Floating Popups if earned on this move
    const scCfg = (this.storage.state.dashboard && this.storage.state.dashboard.scoring) || {};
    if (res.scoreEvents && res.scoreEvents.length > 0 && scCfg.showFloatingPopups !== false) {
      res.scoreEvents.forEach((ev, idx) => {
        const col = ev.pts >= 0 ? "#4ADE80" : "#FB7185";
        setTimeout(() => {
          if (this.renderer) {
            this.renderer.spawnFloatingText(dest.x, dest.y - 44 - idx * 26, ev.label, col);
          }
          this.audio.playScoreChime(ev.pts);
        }, idx * 140);
      });
    }

    const advanceFlowAfterCaptureOrMove = () => {
      if (this.matchSessionId !== session) return;
      this.isAnimatingToken = false;

      if (res.matchOver) {
        this.rules.phase = "GAME_OVER";
        this.storage.recordMatchWin(player.seatIdx, this.rules.turnCounter, this.rules.players);
        setTimeout(() => {
          if (this.matchSessionId !== session) return;
          this.presentVictoryScreen(player);
        }, 650);
        return;
      }

      if (res.bonusTurn) {
        this.rules.phase = "WAITING_FOR_ROLL";
        this.syncTurnHud();
      } else {
        this.rules.advanceToNextPlayer();
        this.audio.turnChange();
        this.syncTurnHud();
      }
    };

    // CRITICAL RULE: Super Token Abilities activate EXCLUSIVELY when a capture is confirmed!
    if (res.capturedTokens.length > 0) {
      const victim = res.capturedTokens[0];
      const victimPlayer = this.rules.players[victim.seatIdx];
      const yardPos = this.rules.board.getTokenWorldPosition(victim.seatIdx, victim.tokenIndex, -1);
      const superAbility = this.renderer.resolveActiveSuperAbility();

      if (superAbility) {
        // Trigger Capture-Exclusive Super Ability Animation Sequence!
        this.audio.playSuperAbilitySfx(superAbility);
        this.showToast(`${player.name} unleashed ${superAbility.toUpperCase()} on ${victimPlayer.name}'s token!`);
        this.renderer.triggerSuperCaptureSequence(
          superAbility,
          dest.x,
          dest.y,
          player.palette,
          victimPlayer.palette,
          res.capturedTokens,
          yardPos,
          () => {
            advanceFlowAfterCaptureOrMove();
          }
        );
        return;
      }

      // Classic Capture Sequence fallback (when a Classic non-Super token is equipped)
      this.audio.capture();
      this.renderer.triggerShake(12, 340);
      this.renderer.spawnBurst(
        dest.x,
        dest.y,
        [player.palette.primary, "#FEF08A", "#EF4444", "#FFFFFF"],
        36,
        6.5,
        6.8,
        "#EF4444"
      );

      res.capturedTokens.forEach(vTok => {
        const vYard = this.rules.board.getTokenWorldPosition(vTok.seatIdx, vTok.tokenIndex, -1);
        const startX = dest.x;
        const startY = dest.y;
        const startT = performance.now();
        const dur = 360;

        const retreatAnim = (now) => {
          if (this.matchSessionId !== session) return;
          const p = Math.min(1, (now - startT) / dur);
          vTok.animX = startX + (vYard.x - startX) * p;
          vTok.animY = startY + (vYard.y - startY) * p;
          vTok.hopZ = Math.sin(p * Math.PI) * 48;
          if (p < 1) {
            requestAnimationFrame(retreatAnim);
          } else {
            vTok.relStep = -1;
            vTok.animX = null;
            vTok.animY = null;
            vTok.hopZ = 0;
          }
        };
        requestAnimationFrame(retreatAnim);
      });
      this.showToast(`${player.name} captured ${victimPlayer.name}'s token!`);
      advanceFlowAfterCaptureOrMove();
      return;
    }

    if (res.reachedFinish) {
      this.audio.finishToken();
      this.renderer.triggerShake(8, 220);
      this.renderer.spawnBurst(dest.x, dest.y, ["#FEF08A", "#FBBF24", player.palette.light], 34, 5.8, 6.2, "#FBBF24");
    } else if (res.landedSafe) {
      this.audio.safeZone();
      this.renderer.spawnBurst(dest.x, dest.y, theme.particleColors, 20, 3.8, 4.8, "#38BDF8");
    } else {
      this.audio.tokenLand();
      this.renderer.spawnBurst(dest.x, dest.y, [player.palette.light, "#FFFFFF"], 12, 2.8, 3.8);
    }

    advanceFlowAfterCaptureOrMove();
  }

  /* --------------------------------------------------------------------------
   * POST-GAME STRATEGIC SCOREBOARD & VICTORY PRESENTATION
   * -------------------------------------------------------------------------- */
  presentVictoryScreen(winner) {
    this.audio.victory();
    const av = getAvatarById(winner.avatar);
    const avatarBox = document.getElementById("victory-winner-avatar");
    const nameEl = document.getElementById("victory-winner-name");
    const statsEl = document.getElementById("victory-match-stats");
    const scoreboardEl = document.getElementById("victory-strategic-scoreboard");

    if (avatarBox) {
      avatarBox.innerHTML = av.svg;
      avatarBox.style.borderColor = winner.palette.primary;
    }
    if (nameEl) {
      nameEl.textContent = `${winner.name} Wins! (${winner.smartScore || 0} Smart Pts)`;
    }
    if (statsEl) {
      statsEl.innerHTML = `
        <div class="p-2 rounded-xl bg-slate-900/90 border border-slate-700 text-center">
          <div class="text-[10px] text-slate-400 uppercase font-bold">Winner Score</div>
          <div class="text-base font-black text-amber-300">${winner.smartScore || 0} pts</div>
        </div>
        <div class="p-2 rounded-xl bg-slate-900/90 border border-slate-700 text-center">
          <div class="text-[10px] text-slate-400 uppercase font-bold">Best Move</div>
          <div class="text-xs font-extrabold text-emerald-300 truncate">${winner.bestMoveLabel} (+${winner.bestMovePts || 0})</div>
        </div>
        <div class="p-2 rounded-xl bg-slate-900/90 border border-slate-700 text-center">
          <div class="text-[10px] text-slate-400 uppercase font-bold">Captures</div>
          <div class="text-base font-extrabold text-rose-400">${this.rules.matchStats.captures}</div>
        </div>
        <div class="p-2 rounded-xl bg-slate-900/90 border border-slate-700 text-center">
          <div class="text-[10px] text-slate-400 uppercase font-bold">Strategic Plays</div>
          <div class="text-base font-extrabold text-cyan-300">${winner.strategicMovesCount || 0}</div>
        </div>
      `;
    }

    if (scoreboardEl) {
      const sortedPlayers = [...this.rules.players].sort((a, b) => {
        if ((b.finishedCount || 0) !== (a.finishedCount || 0)) return (b.finishedCount || 0) - (a.finishedCount || 0);
        return (b.smartScore || 0) - (a.smartScore || 0);
      });

      scoreboardEl.innerHTML = sortedPlayers.map((p, idx) => {
        const whySummary = p.scoreBreakdown && p.scoreBreakdown.length > 0
          ? p.scoreBreakdown.slice(-3).map(b => `${b.label}`).join(" • ")
          : "Standard progression";
        return `
          <div class="p-2.5 rounded-xl bg-slate-950/90 border-2 text-left space-y-1" style="border-color:${p.palette.primary}">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-1.5">
                <span class="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[10px]">#${idx + 1}</span>
                <span class="text-xs font-black text-white">${p.name}</span>
              </div>
              <span class="text-xs font-black text-amber-300">${p.smartScore || 0} Smart Pts</span>
            </div>
            <div class="grid grid-cols-4 gap-1 text-[10px] text-slate-300 font-bold">
              <span>Cap: ${p.capturesMade}</span>
              <span>Home: ${p.finishedCount}/4</span>
              <span>Strat: ${p.strategicMovesCount || 0}</span>
              <span class="truncate text-emerald-300">${p.bestCaptureLabel !== '—' ? p.bestCaptureLabel : p.bestMoveLabel}</span>
            </div>
            <div class="text-[9px] text-slate-400 truncate">Why: ${whySummary}</div>
          </div>
        `;
      }).join("");
    }

    this.openModal("modal-victory");
  }

  /* --------------------------------------------------------------------------
   * STATS, SETTINGS & TUTORIAL RENDERERS
   * -------------------------------------------------------------------------- */
  renderStatsModal() {
    const st = this.storage.state.stats;
    const avgScore = this.storage.getAverageSmartScore();
    const favTheme = getThemeById(this.storage.getFavoriteKey(st.themeCounts, "royal")).name;
    const favDice = getDiceSkinById(this.storage.getFavoriteKey(st.diceCounts, "royal_gold")).name;
    const favToken = getTokenSkinById(this.storage.getFavoriteKey(st.tokenCounts, "super_blackhole")).name;

    const grid = document.getElementById("stats-summary-grid");
    if (grid) {
      grid.innerHTML = `
        <div class="p-3 rounded-xl bg-slate-900/90 border border-amber-400/50">
          <div class="text-xs text-amber-300 font-bold uppercase">Total Smart Score</div>
          <div class="text-2xl font-black text-white mt-0.5">${st.totalSmartScore || 0}</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-amber-400/50">
          <div class="text-xs text-amber-300 font-bold uppercase">Best Match Score</div>
          <div class="text-2xl font-black text-amber-300 mt-0.5">${st.bestSmartScore || 0}</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-700">
          <div class="text-xs text-slate-400 font-bold uppercase">Average Smart Score</div>
          <div class="text-xl font-black text-emerald-300 mt-0.5">${avgScore} pts</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-700">
          <div class="text-xs text-slate-400 font-bold uppercase">Strategic Captures</div>
          <div class="text-xl font-black text-rose-400 mt-0.5">${st.strategicCaptures || 0} / ${st.totalCaptures || 0}</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-700">
          <div class="text-xs text-slate-400 font-bold uppercase">Games Played / Won</div>
          <div class="text-xl font-black text-white mt-0.5">${st.gamesPlayed} / ${st.gamesWon}</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-700">
          <div class="text-xs text-slate-400 font-bold uppercase">Tokens Finished</div>
          <div class="text-xl font-black text-cyan-300 mt-0.5">${st.totalTokensFinished || 0}</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-700">
          <div class="text-xs text-slate-400 font-bold uppercase">Favorite World</div>
          <div class="text-sm font-extrabold text-amber-200 mt-1 truncate">${favTheme}</div>
        </div>
        <div class="p-3 rounded-xl bg-slate-900/90 border border-slate-700">
          <div class="text-xs text-slate-400 font-bold uppercase">Favorite Super Token</div>
          <div class="text-sm font-extrabold text-white mt-1 truncate">${favToken}</div>
        </div>
      `;
    }

    const seatWins = document.getElementById("stats-seat-wins");
    if (seatWins) {
      seatWins.innerHTML = [0, 1, 2, 3, 4].map(idx => {
        const pal = this.storage.getPlayerPalette(idx);
        const w = st.winsByPlayer[idx] || 0;
        return `
          <div class="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900/80 border border-slate-800">
            <div class="flex items-center gap-2">
              <span class="w-3 h-3 rounded-full" style="background:${pal.primary}"></span>
              <span class="text-xs font-bold text-slate-200">Player ${idx + 1} (${pal.name})</span>
            </div>
            <span class="text-xs font-extrabold text-amber-300">${w} Wins</span>
          </div>
        `;
      }).join("");
    }
  }

  syncSettingsControls() {
    const s = this.storage.state.settings;
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) el.value = v;
    };
    setVal("slider-master-vol", Math.round(s.masterVolume * 100));
    setVal("slider-music-vol", Math.round(s.musicVolume * 100));
    setVal("slider-sfx-vol", Math.round(s.sfxVolume * 100));
    setVal("select-game-speed", String(s.gameSpeed));
    setVal("select-dice-speed", String(s.diceSpeed));
    setVal("select-token-speed", String(s.tokenSpeed));
    setVal("select-turn-speed", String(s.turnSpeed));

    const bindToggleVisual = (id, active) => {
      const btn = document.getElementById(id);
      if (!btn) return;
      btn.textContent = active ? "ON" : "OFF";
      btn.className = active
        ? "px-3.5 py-1.5 rounded-lg font-extrabold text-xs bg-emerald-500 text-slate-950 shadow"
        : "px-3.5 py-1.5 rounded-lg font-extrabold text-xs bg-slate-700 text-slate-300";
    };

    bindToggleVisual("toggle-dynamic-dice", s.dynamicDicePosition);
    bindToggleVisual("toggle-vfx", s.vfxEnabled);
    bindToggleVisual("toggle-screen-fx", s.screenEffects);
    bindToggleVisual("toggle-sound", s.soundEnabled);
    bindToggleVisual("toggle-music", s.musicEnabled);
    bindToggleVisual("toggle-vibration", s.vibrationEnabled);
    bindToggleVisual("toggle-triple-six", s.tripleSixRule);
  }

  renderTutorialStep() {
    const p0Pal = this.storage.getPlayerPalette(0);
    const steps = [
      {
        title: "1. Super Tokens & Capture-Exclusive Abilities",
        body: "Equip any of the 6 unlocked Super Tokens (Black Hole, Ice Freeze, Fire Inferno, 3D Boot Kick, Monster Devour, or Tempest Thunder). Normal movement stays clean—spectacular Super Abilities trigger EXCLUSIVELY when you capture an opponent's token!",
        visual: `<div class="flex items-center gap-2">${["super_blackhole", "super_ice", "super_fire", "super_kick", "super_devour"].map((id, idx) => renderTokenPreviewSvg(id, this.storage.getPlayerPalette(idx), "w-14 h-14")).join("")}</div>`
      },
      {
        title: "2. Smart Color Synchronization & Custom HEX",
        body: "Choose from 13 presets (including Burgundy, Beige, Olive, Coffee, Black, White) or pick any custom HEX color. The Smart Color Engine automatically derives 3D highlights, shadows, edges, and glow across the Board, Yards, Paths, Tokens, and HUD!",
        visual: renderTokenPreviewSvg(this.storage.state.setup.selectedToken, p0Pal, "w-20 h-20")
      },
      {
        title: "3. Full Ludo Capo Game Dashboard",
        body: "Open the Game Dashboard from the top bar to customize Players 1–5, Board scale/rotation/materials, Dice physics, Super Ability parameters, 9-channel Audio, and Rules—or test any Super Capture live on the board!",
        visual: renderDiceSvg(this.storage.state.setup.selectedDice, 6, "w-20 h-20")
      },
      {
        title: "4. Smart Strategic Score System",
        body: "Earn Smart Score points for intelligent play: Strategic Captures of advanced enemies, Multi-Capture streaks, Escaping Danger when threatened, Anchoring on Safe Stars, and Finishing Tokens—reviewed in the Post-Game Strategic Scoreboard!",
        visual: getIconSvg("crown", "w-20 h-20")
      },
      {
        title: "5. 2–4 Player Cross & 5-Player Pentagon",
        body: "Ludo Capo supports 2, 3, 4, and 5 local Pass-and-Play players completely offline. Selecting 5 Players activates the dedicated 65-tile 5-Arm Pentagonal Star Board.",
        visual: `<div class="flex items-center gap-2">${[0, 1, 2, 3, 4].map(i => renderTokenPreviewSvg("royal_pawn", this.storage.getPlayerPalette(i), "w-11 h-11")).join("")}</div>`
      }
    ];

    const step = steps[this.tutorialStep % steps.length];
    const titleEl = document.getElementById("tutorial-step-title");
    const bodyEl = document.getElementById("tutorial-step-body");
    const visEl = document.getElementById("tutorial-step-visual");
    const dotsEl = document.getElementById("tutorial-step-dots");

    if (titleEl) titleEl.textContent = step.title;
    if (bodyEl) bodyEl.textContent = step.body;
    if (visEl) visEl.innerHTML = step.visual;
    if (dotsEl) {
      dotsEl.innerHTML = steps.map((_, idx) =>
        `<span class="w-2.5 h-2.5 rounded-full ${idx === this.tutorialStep ? 'bg-amber-400 scale-125' : 'bg-slate-600'} transition-all"></span>`
      ).join("");
    }
  }

  bindStaticEvents() {
    const on = (id, ev, fn) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener(ev, fn);
    };

    on("btn-splash-enter", "click", () => {
      this.audio.buttonPress();
      this.audio.startMusic(this.storage.state.setup.selectedTheme);
      this.showScreen("home");
    });

    on("card-home-passplay", "click", () => {
      this.audio.buttonPress();
      this.showScreen("setup");
    });
    on("card-home-5p-star", "click", () => {
      this.audio.buttonPress();
      this.startNewMatch(5);
    });
    on("card-home-quick-4p", "click", () => {
      this.audio.buttonPress();
      this.startNewMatch(4);
    });
    on("card-home-vault", "click", () => {
      this.audio.buttonPress();
      this.showScreen("inventory");
    });

    document.querySelectorAll(".lobby-quick-pcount").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const cnt = parseInt(btn.getAttribute("data-quick-count"), 10);
        this.audio.buttonPress();
        this.startNewMatch(cnt);
      });
    });

    on("btn-open-dashboard", "click", () => this.openModal("modal-dashboard"));
    on("btn-setup-dashboard", "click", () => this.openModal("modal-dashboard"));
    on("btn-hud-dashboard", "click", () => this.openModal("modal-dashboard"));
    on("btn-pause-dashboard", "click", () => {
      this.closeModal("modal-pause");
      this.openModal("modal-dashboard");
    });
    on("btn-close-dashboard", "click", () => this.closeModal("modal-dashboard"));

    document.querySelectorAll(".dash-tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        this.dashboardTab = btn.getAttribute("data-dash-tab");
        this.audio.uiInteract();
        this.renderDashboardModal();
      });
    });

    on("btn-open-tutorial", "click", () => this.openModal("modal-tutorial"));
    on("btn-open-rules", "click", () => this.openModal("modal-rules"));
    on("btn-open-settings", "click", () => this.openModal("modal-settings"));
    on("btn-open-stats", "click", () => this.openModal("modal-stats"));

    document.querySelectorAll(".nav-dock-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const nav = btn.getAttribute("data-nav");
        this.audio.buttonPress();
        if (nav === "stats") this.openModal("modal-stats");
        else if (nav === "rules") this.openModal("modal-rules");
        else if (nav === "dashboard") this.openModal("modal-dashboard");
        else this.showScreen(nav);
      });
    });

    on("btn-setup-back", "click", () => {
      this.audio.buttonPress();
      this.showScreen("home");
    });
    document.querySelectorAll(".setup-pcount-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const cnt = parseInt(btn.getAttribute("data-count"), 10);
        this.storage.state.setup.playerCount = cnt;
        this.storage.save();
        this.audio.uiInteract();
        this.renderSetupScreen();
      });
    });
    on("btn-setup-dynamic-dice", "click", () => {
      const s = this.storage.state.settings;
      s.dynamicDicePosition = !s.dynamicDicePosition;
      this.storage.save();
      this.audio.buttonPress();
      this.renderSetupScreen();
    });
    on("btn-setup-start-match", "click", () => {
      this.audio.buttonPress();
      this.startNewMatch();
    });

    on("btn-inv-back", "click", () => {
      this.audio.buttonPress();
      this.showScreen("home");
    });
    document.querySelectorAll(".inv-tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        this.inventoryTab = btn.getAttribute("data-inv-tab");
        this.audio.uiInteract();
        this.renderInventoryScreen();
      });
    });

    on("btn-game-pause", "click", () => {
      this.openModal("modal-pause");
    });
    on("btn-hud-speed", "click", () => {
      const speeds = [1.0, 1.5, 2.0];
      const cur = this.storage.state.settings.gameSpeed;
      const next = speeds[(speeds.indexOf(cur) + 1) % speeds.length];
      this.storage.state.settings.gameSpeed = next;
      this.storage.save();
      this.audio.uiInteract();
      this.syncTurnHud(true);
      this.showToast(`Game Speed set to ${next}x`);
    });
    on("btn-hud-dyn-dice", "click", () => {
      const s = this.storage.state.settings;
      s.dynamicDicePosition = !s.dynamicDicePosition;
      this.storage.save();
      this.audio.buttonPress();
      this.syncTurnHud();
      this.showToast(`Dynamic Dice Position: ${s.dynamicDicePosition ? "ON" : "OFF"}`);
    });
    on("btn-hud-edit-anchors", "click", () => {
      this.anchorEditMode = !this.anchorEditMode;
      this.audio.buttonPress();
      this.renderAnchorPinsOverlay();
      this.showToast(this.anchorEditMode ? "Drag Player 1-5 Dice Anchors to customize" : "Saved Dice Anchor positions");
    });
    on("floating-dice-widget", "click", () => {
      this.triggerDiceRoll();
    });

    const canvas = document.getElementById("ludo-board-canvas");
    if (canvas) {
      canvas.addEventListener("click", (e) => {
        if (this.rules.phase === "WAITING_FOR_ROLL") {
          return;
        }
        if (this.rules.phase !== "SELECT_TOKEN") return;
        const pt = this.renderer.clientToBoardCoords(e.clientX, e.clientY);
        const hitToken = this.renderer.findTokenAtPoint(pt.x, pt.y);
        if (hitToken) {
          this.executeTokenSelection(hitToken);
        }
      });
    }

    const stage = document.getElementById("game-stage-container");
    if (stage) {
      const moveAnchor = (clientX, clientY) => {
        if (this.draggingAnchorIdx === null) return;
        const rect = stage.getBoundingClientRect();
        const nx = Math.max(8, Math.min(92, Math.round(((clientX - rect.left) / rect.width) * 100)));
        const ny = Math.max(5, Math.min(95, Math.round(((clientY - rect.top) / rect.height) * 100)));
        const list = this.getActiveAnchorList();
        if (list[this.draggingAnchorIdx]) {
          list[this.draggingAnchorIdx].x = nx;
          list[this.draggingAnchorIdx].y = ny;
          list[this.draggingAnchorIdx].custom = true;
          this.storage.save();
          this.renderAnchorPinsOverlay();
          this.syncTurnHud(true);
        }
      };
      window.addEventListener("mousemove", (e) => moveAnchor(e.clientX, e.clientY));
      window.addEventListener("touchmove", (e) => {
        if (this.draggingAnchorIdx !== null && e.touches[0]) {
          moveAnchor(e.touches[0].clientX, e.touches[0].clientY);
        }
      }, { passive: true });
      window.addEventListener("mouseup", () => { this.draggingAnchorIdx = null; });
      window.addEventListener("touchend", () => { this.draggingAnchorIdx = null; });
    }

    on("btn-pause-resume", "click", () => this.closeModal("modal-pause"));
    on("btn-pause-restart", "click", () => {
      this.closeModal("modal-pause");
      this.startNewMatch();
    });
    on("btn-pause-settings", "click", () => {
      this.closeModal("modal-pause");
      this.openModal("modal-settings");
    });
    on("btn-pause-rules", "click", () => {
      this.closeModal("modal-pause");
      this.openModal("modal-rules");
    });
    on("btn-pause-home", "click", () => {
      this.matchSessionId += 1;
      this.closeModal("modal-pause");
      this.showScreen("home");
    });

    on("btn-victory-rematch", "click", () => {
      this.closeModal("modal-victory");
      this.startNewMatch();
    });
    on("btn-victory-home", "click", () => {
      this.closeModal("modal-victory");
      this.showScreen("home");
    });

    on("btn-close-settings", "click", () => this.closeModal("modal-settings"));
    on("btn-close-rules", "click", () => this.closeModal("modal-rules"));
    on("btn-close-tutorial", "click", () => this.closeModal("modal-tutorial"));
    on("btn-close-stats", "click", () => this.closeModal("modal-stats"));

    on("btn-tutorial-prev", "click", () => {
      this.tutorialStep = (this.tutorialStep + 4) % 5;
      this.audio.uiInteract();
      this.renderTutorialStep();
    });
    on("btn-tutorial-next", "click", () => {
      this.tutorialStep = (this.tutorialStep + 1) % 5;
      this.audio.uiInteract();
      this.renderTutorialStep();
    });

    on("slider-master-vol", "input", (e) => {
      this.storage.state.settings.masterVolume = parseInt(e.target.value, 10) / 100;
      this.storage.save();
    });
    on("slider-music-vol", "input", (e) => {
      this.storage.state.settings.musicVolume = parseInt(e.target.value, 10) / 100;
      this.storage.save();
    });
    on("slider-sfx-vol", "input", (e) => {
      this.storage.state.settings.sfxVolume = parseInt(e.target.value, 10) / 100;
      this.storage.save();
    });

    const bindSelect = (id, key) => {
      on(id, "change", (e) => {
        this.storage.state.settings[key] = parseFloat(e.target.value);
        this.storage.save();
        this.audio.uiInteract();
        if (this.currentScreen === "game") this.syncTurnHud(true);
      });
    };
    bindSelect("select-game-speed", "gameSpeed");
    bindSelect("select-dice-speed", "diceSpeed");
    bindSelect("select-token-speed", "tokenSpeed");
    bindSelect("select-turn-speed", "turnSpeed");

    const bindSettingToggle = (id, key) => {
      on(id, "click", () => {
        const s = this.storage.state.settings;
        s[key] = !s[key];
        this.storage.save();
        this.audio.buttonPress();
        this.syncSettingsControls();
        if (this.currentScreen === "game") this.syncTurnHud();
      });
    };
    bindSettingToggle("toggle-dynamic-dice", "dynamicDicePosition");
    bindSettingToggle("toggle-vfx", "vfxEnabled");
    bindSettingToggle("toggle-screen-fx", "screenEffects");
    bindSettingToggle("toggle-sound", "soundEnabled");
    bindSettingToggle("toggle-music", "musicEnabled");
    bindSettingToggle("toggle-vibration", "vibrationEnabled");
    bindSettingToggle("toggle-triple-six", "tripleSixRule");

    on("btn-reset-anchors", "click", () => {
      this.storage.resetAnchors();
      this.audio.buttonPress();
      this.renderAnchorPinsOverlay();
      if (this.currentScreen === "game") this.syncTurnHud();
      this.showToast("Player 1–5 Dice Wells restored to automatic console positions");
    });

    on("btn-reset-all-data", "click", () => {
      this.storage.resetAll();
      this.applyThemeCssVariables(this.storage.state.setup.selectedTheme);
      this.syncSettingsControls();
      this.renderSetupScreen();
      this.renderInventoryScreen();
      this.renderDashboardModal();
      this.renderStatsModal();
      this.audio.buttonPress();
      this.showToast("All Ludo Capo preferences, dashboard & local stats reset");
    });
  }
}

window.addEventListener("load", () => {
  window.ludoCapoApp = new CapoGameController();
  window.ludoCapoApp.init();
});
