/* ============================================================================
 * MODULE 04: PROCEDURAL WEB AUDIO SYNTHESIZER, SUPER ABILITY SOUND DESIGN
 *            & MULTI-CHANNEL DASHBOARD AUDIO MIXER
 * ============================================================================ */

class CapoAudioEngine {
  constructor(storage) {
    this.storage = storage;
    this.ctx = null;
    this.musicTimer = null;
    this.musicStep = 0;
    this.currentThemeId = "royal";
    this.unlocked = false;
  }

  ensureContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    this.unlocked = true;
  }

  getEffectiveSfxGain(channelKey = null) {
    const s = this.storage.state.settings;
    if (!s.soundEnabled) return 0;
    const chanMul = (channelKey && s[channelKey] !== undefined) ? s[channelKey] : 1.0;
    return Math.max(0, Math.min(1, s.masterVolume * s.sfxVolume * chanMul));
  }

  getEffectiveMusicGain() {
    const s = this.storage.state.settings;
    if (!s.musicEnabled || !s.soundEnabled) return 0;
    return Math.max(0, Math.min(1, s.masterVolume * s.musicVolume * 0.16));
  }

  vibrate(pattern = 25) {
    const s = this.storage.state.settings;
    if (!s.vibrationEnabled) return;
    try {
      if (window.AndroidBridge && typeof window.AndroidBridge.vibrate === "function") {
        window.AndroidBridge.vibrate(Array.isArray(pattern) ? pattern[0] : pattern);
      } else if (navigator.vibrate) {
        navigator.vibrate(pattern);
      }
    } catch (e) {}
  }

  playTone(freq, duration = 0.12, type = "sine", delay = 0, volScale = 1, slideTo = null, channelKey = null) {
    const gainVal = this.getEffectiveSfxGain(channelKey) * volScale;
    if (gainVal <= 0.001) return;
    this.ensureContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freq), now);
    if (slideTo) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), now + duration);
    }

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainVal * 0.35, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  playNoiseBurst(duration = 0.08, delay = 0, volScale = 0.6, filterFreq = 1200, channelKey = null) {
    const gainVal = this.getEffectiveSfxGain(channelKey) * volScale;
    if (gainVal <= 0.001) return;
    this.ensureContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime + delay;
    const bufferSize = Math.max(64, Math.floor(this.ctx.sampleRate * duration));
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.45));
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(filterFreq, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainVal * 0.42, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    noise.start(now);
  }

  buttonPress() {
    this.vibrate(15);
    this.playTone(580, 0.07, "triangle", 0, 0.7, 720, "uiVolume");
  }

  uiInteract() {
    this.vibrate(10);
    this.playTone(480, 0.05, "sine", 0, 0.5, 560, "uiVolume");
  }

  menuOpen() {
    this.playTone(392, 0.09, "triangle", 0, 0.6, 523.25, "uiVolume");
    this.playTone(523.25, 0.12, "triangle", 0.05, 0.6, 659.25, "uiVolume");
  }

  menuClose() {
    this.playTone(523.25, 0.08, "triangle", 0, 0.5, 392, "uiVolume");
  }

  themeSelect() {
    this.vibrate(25);
    [440, 554.37, 659.25, 880].forEach((f, idx) => {
      this.playTone(f, 0.16, "triangle", idx * 0.05, 0.65, null, "uiVolume");
    });
  }

  diceRoll() {
    this.vibrate([20, 30, 20]);
    for (let i = 0; i < 5; i++) {
      this.playNoiseBurst(0.045, i * 0.055, 0.55, 900 + i * 220, "diceVolume");
      this.playTone(300 + i * 70, 0.04, "triangle", i * 0.055, 0.4, null, "diceVolume");
    }
  }

  diceBounce() {
    this.playNoiseBurst(0.05, 0, 0.5, 1100, "diceVolume");
    this.playTone(340, 0.06, "triangle", 0, 0.45, 220, "diceVolume");
  }

  diceLand(rolledSix = false) {
    this.vibrate(rolledSix ? [35, 40, 50] : 25);
    this.playNoiseBurst(0.07, 0, 0.7, 800, "diceVolume");
    if (rolledSix) {
      this.playTone(523.25, 0.12, "triangle", 0, 0.85, null, "diceVolume");
      this.playTone(659.25, 0.14, "triangle", 0.07, 0.85, null, "diceVolume");
      this.playTone(783.99, 0.22, "triangle", 0.14, 0.95, null, "diceVolume");
    } else {
      this.playTone(440, 0.11, "triangle", 0, 0.7, 380, "diceVolume");
    }
  }

  tokenSelect() {
    this.vibrate(15);
    this.playTone(520, 0.08, "sine", 0, 0.65, 680, "tokenVolume");
  }

  tokenMove(stepIndex = 0) {
    const pitch = 420 + (stepIndex % 8) * 35;
    this.playTone(pitch, 0.075, "sine", 0, 0.55, pitch * 1.18, "tokenVolume");
  }

  tokenLand() {
    this.vibrate(18);
    this.playTone(360, 0.09, "triangle", 0, 0.65, 480, "tokenVolume");
  }

  capture() {
    this.vibrate([50, 30, 70]);
    this.playNoiseBurst(0.18, 0, 0.9, 650, "captureVolume");
    this.playTone(620, 0.12, "sawtooth", 0, 0.8, 280, "captureVolume");
    this.playTone(440, 0.16, "sawtooth", 0.08, 0.85, 880, "captureVolume");
    this.playTone(880, 0.25, "triangle", 0.18, 0.9, null, "captureVolume");
  }

  /**
   * Dedicated Custom Sound Design for Every Super Token Elimination Sequence
   */
  playSuperAbilitySfx(abilityType) {
    this.vibrate([60, 30, 80, 30, 90]);
    const ch = "superAbilityVolume";
    if (abilityType === "blackhole") {
      // Deep gravitational singularity vortex + inward pull + hawking collapse
      this.playTone(180, 0.55, "sawtooth", 0, 0.9, 42, ch);
      this.playTone(320, 0.45, "sine", 0.1, 0.75, 65, ch);
      this.playNoiseBurst(0.45, 0.15, 0.7, 320, ch);
      this.playTone(90, 0.22, "triangle", 0.68, 1.0, 720, ch);
      this.playNoiseBurst(0.22, 0.75, 0.95, 950, ch);
    } else if (abilityType === "ice") {
      // Rapid crystal freeze sweep -> dramatic silence -> multi-shard ice shatter
      this.playTone(880, 0.28, "sine", 0, 0.8, 1960, ch);
      this.playTone(1320, 0.28, "triangle", 0.08, 0.75, 2400, ch);
      this.playNoiseBurst(0.20, 0.05, 0.55, 2800, ch);
      // Shatter burst at 0.62s
      [2100, 1760, 2640, 1480, 3100].forEach((freq, i) => {
        this.playTone(freq, 0.11, "triangle", 0.60 + i * 0.045, 0.85, freq * 0.6, ch);
        this.playNoiseBurst(0.08, 0.60 + i * 0.04, 0.75, 3200, ch);
      });
    } else if (abilityType === "fire") {
      // Roaring flame vortex + rising ember crackles + controlled fire detonation
      this.playNoiseBurst(0.55, 0, 0.95, 480, ch);
      this.playTone(140, 0.45, "sawtooth", 0.05, 0.8, 320, ch);
      this.playNoiseBurst(0.28, 0.55, 1.0, 260, ch);
      this.playTone(260, 0.30, "sawtooth", 0.55, 0.95, 55, ch);
    } else if (abilityType === "kick") {
      // Armored boot swing whoosh -> heavy kinetic impact thud -> launch whistle
      this.playTone(240, 0.16, "sine", 0, 0.7, 580, ch);
      this.playNoiseBurst(0.18, 0.18, 1.0, 380, ch);
      this.playTone(165, 0.22, "triangle", 0.18, 1.0, 38, ch);
      this.playTone(920, 0.38, "sine", 0.28, 0.75, 260, ch);
    } else if (abilityType === "devour") {
      // Abyssal monster roar -> heavy fanged jaw snap crunch -> gulp
      this.playTone(135, 0.36, "sawtooth", 0, 0.9, 68, ch);
      this.playNoiseBurst(0.16, 0.42, 1.0, 720, ch);
      this.playTone(290, 0.14, "sawtooth", 0.42, 0.95, 85, ch);
      this.playTone(190, 0.18, "sine", 0.68, 0.8, 110, ch);
    } else {
      // Thunder plasma strike
      this.playNoiseBurst(0.35, 0, 1.0, 1400, ch);
      this.playTone(880, 0.18, "sawtooth", 0, 0.9, 110, ch);
      this.playTone(120, 0.42, "triangle", 0.12, 0.95, 36, ch);
    }
  }

  playScoreChime(points = 15) {
    if (points >= 0) {
      this.playTone(659.25, 0.09, "sine", 0, 0.45, 880, "uiVolume");
    } else {
      this.playTone(280, 0.12, "triangle", 0, 0.45, 190, "uiVolume");
    }
  }

  safeZone() {
    this.vibrate(25);
    this.playTone(587.33, 0.12, "sine", 0, 0.7, null, "tokenVolume");
    this.playTone(880, 0.20, "sine", 0.07, 0.8, null, "tokenVolume");
  }

  finishToken() {
    this.vibrate([40, 30, 60]);
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      this.playTone(f, 0.18, "triangle", i * 0.06, 0.85, null, "victoryVolume");
    });
  }

  turnChange() {
    this.playTone(349.23, 0.07, "sine", 0, 0.35, 440, "uiVolume");
  }

  gameStart() {
    this.vibrate([30, 40, 30]);
    [392, 493.88, 587.33, 783.99].forEach((f, i) => {
      this.playTone(f, 0.18, "triangle", i * 0.07, 0.8, null, "uiVolume");
    });
  }

  gameEnd() {
    this.playTone(523.25, 0.25, "triangle", 0, 0.8, null, "victoryVolume");
  }

  victory() {
    this.vibrate([60, 40, 60, 40, 100]);
    const fanfare = [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5];
    const delays = [0, 0.12, 0.24, 0.36, 0.54, 0.68];
    fanfare.forEach((f, i) => {
      this.playTone(f, i === 5 ? 0.45 : 0.16, "triangle", delays[i], 0.95, null, "victoryVolume");
    });
  }

  defeat() {
    [392, 349.23, 311.13, 261.63].forEach((f, i) => {
      this.playTone(f, 0.2, "sawtooth", i * 0.12, 0.5, null, "victoryVolume");
    });
  }

  startMusic(themeId) {
    this.currentThemeId = themeId || this.currentThemeId;
    this.stopMusic();
    this.musicTimer = setInterval(() => {
      const gainVal = this.getEffectiveMusicGain();
      if (gainVal <= 0.001 || !this.unlocked || !this.ctx) return;
      const theme = getThemeById(this.currentThemeId);
      const notes = theme.musicNotes || [261.63, 329.63, 392.00, 523.25];
      const freq = notes[this.musicStep % notes.length];
      this.musicStep++;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = theme.musicWave === "sawtooth" ? "triangle" : (theme.musicWave || "sine");
      osc.frequency.setValueAtTime(freq * 0.5, now);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(gainVal, now + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.4);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 1.45);
    }, 1500);
  }

  stopMusic() {
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}
