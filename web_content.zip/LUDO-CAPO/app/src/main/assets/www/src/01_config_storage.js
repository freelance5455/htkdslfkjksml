
// Legacy preset IDs preserved: { id: "sapphire" }, { id: "ruby" }, { id: "emerald" }, { id: "amber" }, { id: "amethyst" }
/* ============================================================================
 * MODULE 01: CENTRALIZED CONFIGURATION, SMART COLOR PROPAGATION ENGINE,
 *            DASHBOARD STATE & LOCAL SCORE / STATISTICS STORAGE
 * Project: Ludo Capo v4.0 (Super Tokens, Full Game Dashboard & Smart Score)
 * ============================================================================ */

class CapoSmartColorEngine {
  static clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  static normalizeHex(hexStr) {
    if (!hexStr || typeof hexStr !== "string") return "#0284C7";
    let clean = hexStr.trim().replace(/^#/, "");
    if (clean.length === 3) {
      clean = clean[0] + clean[0] + clean[1] + clean[1] + clean[2] + clean[2];
    }
    if (!/^[0-9A-Fa-f]{6}$/.test(clean)) return "#0284C7";
    return "#" + clean.toUpperCase();
  }

  static hexToRgb(hex) {
    const clean = this.normalizeHex(hex).slice(1);
    return {
      r: parseInt(clean.slice(0, 2), 16),
      g: parseInt(clean.slice(2, 4), 16),
      b: parseInt(clean.slice(4, 6), 16)
    };
  }

  static rgbToHex(r, g, b) {
    const toHex = (n) => this.clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0").toUpperCase();
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  }

  static rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return { h: h * 360, s: s * 100, l: l * 100 };
  }

  static hslToHex(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = this.clamp(s, 0, 100) / 100;
    l = this.clamp(l, 0, 100) / 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return this.rgbToHex((r + m) * 255, (g + m) * 255, (b + m) * 255);
  }

  /**
   * Generates a complete 3D material & lighting palette from ANY base HEX color:
   * Base color, Dark shade, Deep shadow, Highlight, Edge color, Reflection, Glow, Accent
   */
  static buildSmartPalette(hex, name = "Custom Color", id = "custom") {
    const cleanHex = this.normalizeHex(hex);
    const rgb = this.hexToRgb(cleanHex);
    const hsl = this.rgbToHsl(rgb.r, rgb.g, rgb.b);

    // Special Material Adaptation for Ultra-Dark (Black), Ultra-Light (White/Beige), & Earthy/Rich Tones
    const isVeryDark = hsl.l < 18;
    const isVeryLight = hsl.l > 82;
    const isWarmNeutral = hsl.s < 42 && hsl.l >= 55 && hsl.l <= 84;

    let primary = cleanHex;
    let secondary, light, dark, deep, rim, edge, reflection, accent, glow;

    if (isVeryDark) {
      // Obsidian / Black Token & Board Material Treatment
      primary = cleanHex;
      secondary = this.hslToHex(hsl.h, Math.min(25, hsl.s + 8), Math.max(28, hsl.l + 16));
      light = "#CBD5E1";       // Platinum highlight
      dark = "#090D14";        // Abyssal shadow
      deep = "#020408";        // Socket depth
      rim = "#94A3B8";         // Brushed steel rim
      edge = "#E2E8F0";        // Metallic silver edge
      reflection = "#FFFFFF";
      accent = "#FACC15";      // Gold royal crest contrast
      glow = "rgba(148, 163, 184, 0.88)";
    } else if (isVeryLight) {
      // Sovereign White / Ivory Pearl Material Treatment
      primary = cleanHex;
      secondary = this.hslToHex(hsl.h || 42, Math.max(18, hsl.s), this.clamp(hsl.l - 8, 72, 92));
      light = "#FFFFFF";
      dark = "#64748B";        // Sculpted cool slate shadow
      deep = "#334155";        // Deep recess
      rim = "#FDE68A";         // Warm champagne gold rim
      edge = "#F59E0B";        // Burnished gold edge so white tokens pop on light tiles
      reflection = "#FFFFFF";
      accent = "#D97706";
      glow = "rgba(251, 191, 36, 0.88)";
    } else if (isWarmNeutral) {
      // Beige / Sand / Champagne Material Treatment
      primary = cleanHex;
      secondary = this.hslToHex(hsl.h, this.clamp(hsl.s + 6, 20, 65), this.clamp(hsl.l + 9, 65, 88));
      light = "#FFFBEB";       // Cream highlight
      dark = this.hslToHex(hsl.h, this.clamp(hsl.s + 14, 30, 75), this.clamp(hsl.l - 32, 22, 45)); // Dark beige/espresso shadow
      deep = this.hslToHex(hsl.h, this.clamp(hsl.s + 18, 35, 80), 16);
      rim = "#FEF3C7";
      edge = "#B45309";        // Controlled bronze accent edge
      reflection = "#FFFDF7";
      accent = "#78350F";
      glow = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.88)`;
    } else {
      // Rich Jewel & Earthy Tones (Burgundy, Olive, Coffee, Blue, Red, Green, Gold, Purple, Pink, Orange, Custom)
      secondary = this.hslToHex(hsl.h, this.clamp(hsl.s + 8, 35, 96), this.clamp(hsl.l + 15, 38, 76));
      light = this.hslToHex(hsl.h, this.clamp(hsl.s + 12, 30, 100), this.clamp(hsl.l + 38, 78, 95));
      dark = this.hslToHex(hsl.h, this.clamp(hsl.s + 6, 35, 95), this.clamp(hsl.l - 20, 12, 36));
      deep = this.hslToHex(hsl.h, this.clamp(hsl.s + 10, 40, 95), this.clamp(hsl.l - 34, 6, 18));
      rim = this.hslToHex(hsl.h, this.clamp(hsl.s + 15, 40, 100), this.clamp(hsl.l + 28, 70, 90));
      edge = "#FEF08A";
      reflection = "#FFFFFF";
      accent = hsl.l > 55 ? dark : "#FEF08A";
      const glowRgb = this.hexToRgb(secondary);
      glow = `rgba(${glowRgb.r}, ${glowRgb.g}, ${glowRgb.b}, 0.88)`;
    }

    return {
      id: id || `custom_${cleanHex.slice(1)}`,
      name: name || cleanHex,
      hex: cleanHex,
      primary,
      secondary,
      light,
      dark,
      deep,
      rim,
      edge,
      reflection,
      accent,
      glow
    };
  }
}

const CAPO_COLOR_PRESETS = [
  CapoSmartColorEngine.buildSmartPalette("#0284C7", "Royal Blue", "sapphire"),
  CapoSmartColorEngine.buildSmartPalette("#DC2626", "Crimson Red", "ruby"),
  CapoSmartColorEngine.buildSmartPalette("#16A34A", "Emerald Green", "emerald"),
  CapoSmartColorEngine.buildSmartPalette("#EAB308", "Imperial Gold", "amber"),
  CapoSmartColorEngine.buildSmartPalette("#9333EA", "Royal Purple", "amethyst"),
  CapoSmartColorEngine.buildSmartPalette("#800020", "Burgundy", "burgundy"),
  CapoSmartColorEngine.buildSmartPalette("#D8C3A5", "Beige", "beige"),
  CapoSmartColorEngine.buildSmartPalette("#556B2F", "Olive", "olive"),
  CapoSmartColorEngine.buildSmartPalette("#6F4E37", "Coffee Brown", "coffee"),
  CapoSmartColorEngine.buildSmartPalette("#1E242B", "Obsidian Black", "black"),
  CapoSmartColorEngine.buildSmartPalette("#F1F5F9", "Sovereign White", "white"),
  CapoSmartColorEngine.buildSmartPalette("#DB2777", "Rose Pink", "pink"),
  CapoSmartColorEngine.buildSmartPalette("#EA580C", "Solar Orange", "orange")
];

const LUDO_CAPO_CONFIG = {
  appName: "Ludo Capo",
  appVersion: "4.0.0",
  packageName: "com.ludocapo.game",

  playerPalettes: CAPO_COLOR_PRESETS,

  resolvePalette(colorIdxOrHex, customHex = null, customName = null) {
    if (customHex && typeof customHex === "string" && customHex.startsWith("#")) {
      const presetMatch = CAPO_COLOR_PRESETS.find(p => p.hex.toUpperCase() === customHex.toUpperCase());
      if (presetMatch) return presetMatch;
      return CapoSmartColorEngine.buildSmartPalette(customHex, customName || `Custom ${customHex.toUpperCase()}`, "custom");
    }
    if (typeof colorIdxOrHex === "number") {
      return CAPO_COLOR_PRESETS[colorIdxOrHex % CAPO_COLOR_PRESETS.length] || CAPO_COLOR_PRESETS[0];
    }
    if (typeof colorIdxOrHex === "string") {
      const byId = CAPO_COLOR_PRESETS.find(p => p.id === colorIdxOrHex || p.hex.toUpperCase() === colorIdxOrHex.toUpperCase());
      if (byId) return byId;
      return CapoSmartColorEngine.buildSmartPalette(colorIdxOrHex, customName || colorIdxOrHex, "custom");
    }
    return CAPO_COLOR_PRESETS[0];
  },

  defaultAnchors4P: [
    { x: 34, y: 7, custom: false, label: "Player 1 Dice Well (Top-Left)" },
    { x: 66, y: 7, custom: false, label: "Player 2 Dice Well (Top-Right)" },
    { x: 66, y: 93, custom: false, label: "Player 3 Dice Well (Bottom-Right)" },
    { x: 34, y: 93, custom: false, label: "Player 4 Dice Well (Bottom-Left)" }
  ],

  defaultAnchors5P: [
    { x: 34, y: 7, custom: false, label: "Player 1 Dice Well (Top-Left)" },
    { x: 66, y: 7, custom: false, label: "Player 2 Dice Well (Top-Right)" },
    { x: 84, y: 93, custom: false, label: "Player 3 Dice Well (Bottom-Right)" },
    { x: 50, y: 93, custom: false, label: "Player 4 Dice Well (Bottom-Center)" },
    { x: 16, y: 93, custom: false, label: "Player 5 Dice Well (Bottom-Left)" }
  ],

  defaultSettings: {
    masterVolume: 0.85,
    musicVolume: 0.45,
    sfxVolume: 0.90,
    diceVolume: 1.0,
    tokenVolume: 1.0,
    captureVolume: 1.0,
    superAbilityVolume: 1.0,
    victoryVolume: 1.0,
    uiVolume: 1.0,
    soundEnabled: true,
    musicEnabled: true,
    vibrationEnabled: true,
    gameSpeed: 1.0,
    diceSpeed: 1.0,
    tokenSpeed: 1.0,
    turnSpeed: 1.0,
    menuSpeed: 1.0,
    victorySpeed: 1.0,
    captureSpeed: 1.0,
    superAbilitySpeed: 1.0,
    dynamicDicePosition: true,
    vfxEnabled: true,
    screenEffects: true,
    glowEnabled: true,
    trailsEnabled: true,
    impactFlashEnabled: true,
    lightEffectsEnabled: true,
    captureVfxEnabled: true,
    victoryVfxEnabled: true,
    themeVfxEnabled: true,
    superAbilityVfxEnabled: true,
    tripleSixRule: true,
    safeZonesEnabled: true,
    captureBonusTurn: true,
    sixBonusTurn: true,
    finishBonusTurn: true,
    sixExitRequired: true,
    exactFinishRoll: true,
    autoMoveSingle: false
  },

  defaultDashboard: {
    board: {
      scale: 1.0,
      offsetX: 0,
      offsetY: 0,
      rotationDeg: 0,
      frameThickness: 22,
      cellGap: 0,
      yardSocketScale: 1.0,
      centerScale: 1.0,
      surfaceMaterial: "theme", // theme | parchment | marble | obsidian | crystal | wood
      customSurfaceColor: "",
      customFrameColor: ""
    },
    playerHud: {
      areaScale: 1.0,
      areaStyle: "royal", // royal | obsidian | crystal | minimal
      displayOrder: [0, 1, 2, 3, 4]
    },
    dice: {
      scale: 1.0,
      rotationSpeed: 1.0,
      bounceIntensity: 1.0,
      shadowIntensity: 0.75,
      materialFinish: "gloss", // gloss | metallic | crystal | matte
      resultFlash: true
    },
    token: {
      scale: 1.0,
      materialFinish: "jewel", // jewel | metallic | ceramic | neon
      idleSpeed: 1.0,
      selectionPulse: 1.0
    },
    superAbilities: {
      enabled: true,
      globalOverride: "auto", // auto (from token) | blackhole | ice | fire | kick | devour | thunder
      durationMul: 1.0,
      vfxIntensity: 1.0,
      particleMultiplier: 1.0,
      effectScale: 1.0,
      cameraShakeMul: 1.0,
      impactStrength: 1.0,
      abilities: {
        blackhole: { enabled: true, duration: 1150, intensity: 1.0, particles: 48, scale: 1.0, shake: 12 },
        ice:       { enabled: true, duration: 1150, intensity: 1.0, particles: 44, scale: 1.0, shake: 10 },
        fire:      { enabled: true, duration: 1100, intensity: 1.0, particles: 52, scale: 1.0, shake: 12 },
        kick:      { enabled: true, duration: 1050, intensity: 1.0, particles: 40, scale: 1.0, shake: 15 },
        devour:    { enabled: true, duration: 1200, intensity: 1.0, particles: 42, scale: 1.0, shake: 14 },
        thunder:   { enabled: true, duration: 1050, intensity: 1.0, particles: 46, scale: 1.0, shake: 13 }
      }
    },
    scoring: {
      enabled: true,
      showFloatingPopups: true,
      basicCapturePts: 15,
      strategicCapturePts: 25,
      deepTargetBonusPts: 15,
      multiCaptureChainPts: 30,
      escapeDangerPts: 15,
      safeZoneAnchorPts: 10,
      enterHomeStretchPts: 15,
      finishTokenPts: 35,
      multiFinishBonusPts: 20,
      victoryBonusPts: 100,
      avoidableBlunderPenalty: -10
    }
  },

  defaultSetup: {
    playerCount: 4,
    selectedTheme: "royal",
    selectedDice: "royal_gold",
    selectedToken: "super_blackhole",
    players: [
      { name: "Player 1", avatar: "sovereign_king", colorIdx: 0, customHex: "#0284C7", isBot: false },
      { name: "Player 2", avatar: "empress_vela", colorIdx: 1, customHex: "#DC2626", isBot: false },
      { name: "Player 3", avatar: "emerald_warden", colorIdx: 2, customHex: "#16A34A", isBot: false },
      { name: "Player 4", avatar: "pharaoh_kha", colorIdx: 3, customHex: "#EAB308", isBot: false },
      { name: "Player 5", avatar: "astral_warden", colorIdx: 4, customHex: "#9333EA", isBot: false }
    ]
  },

  defaultStats: {
    gamesPlayed: 0,
    gamesWon: 0,
    winsByPlayer: [0, 0, 0, 0, 0],
    totalCaptures: 0,
    strategicCaptures: 0,
    totalDiceRolls: 0,
    totalSixes: 0,
    totalTokensFinished: 0,
    totalSmartScore: 0,
    bestSmartScore: 0,
    bestSingleMovePts: 0,
    bestSingleMoveLabel: "—",
    fastestWinTurns: null,
    themeCounts: { royal: 1, fire: 0, ice: 0, cyber: 0, space: 0, jungle: 0 },
    diceCounts: { royal_gold: 1, inferno_dragon: 0, glacier_frost: 0, pharaoh_relic: 0, cyber_neon: 0, emerald_jungle: 0, astral_nebula: 0, crimson_velvet: 0 },
    tokenCounts: {
      super_blackhole: 1, super_ice: 0, super_fire: 0, super_kick: 0, super_devour: 0, super_thunder: 0,
      capo_pin: 0, royal_pawn: 0, crystal_obelisk: 0, dragon_medallion: 0, cyber_thruster: 0, royal_chalice: 0
    }
  }
};

class CapoStorageManager {
  constructor() {
    this.storageKey = "ludo_capo_master_save_v4";
    this.state = this.load();
  }

  getFreshState() {
    return {
      settings: JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultSettings)),
      dashboard: JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultDashboard)),
      setup: JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultSetup)),
      stats: JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultStats)),
      anchors4P: JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultAnchors4P)),
      anchors5P: JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultAnchors5P))
    };
  }

  load() {
    const fresh = this.getFreshState();
    try {
      const raw = window.localStorage.getItem(this.storageKey);
      if (!raw) return fresh;
      const parsed = JSON.parse(raw);

      const mergedDashboard = Object.assign({}, fresh.dashboard, parsed.dashboard || {});
      mergedDashboard.board = Object.assign({}, fresh.dashboard.board, (parsed.dashboard && parsed.dashboard.board) || {});
      mergedDashboard.playerHud = Object.assign({}, fresh.dashboard.playerHud, (parsed.dashboard && parsed.dashboard.playerHud) || {});
      mergedDashboard.dice = Object.assign({}, fresh.dashboard.dice, (parsed.dashboard && parsed.dashboard.dice) || {});
      mergedDashboard.token = Object.assign({}, fresh.dashboard.token, (parsed.dashboard && parsed.dashboard.token) || {});
      mergedDashboard.superAbilities = Object.assign({}, fresh.dashboard.superAbilities, (parsed.dashboard && parsed.dashboard.superAbilities) || {});
      mergedDashboard.superAbilities.abilities = Object.assign({}, fresh.dashboard.superAbilities.abilities, (parsed.dashboard && parsed.dashboard.superAbilities && parsed.dashboard.superAbilities.abilities) || {});
      mergedDashboard.scoring = Object.assign({}, fresh.dashboard.scoring, (parsed.dashboard && parsed.dashboard.scoring) || {});

      const mergedPlayers = (parsed.setup && Array.isArray(parsed.setup.players) && parsed.setup.players.length === 5)
        ? parsed.setup.players.map((p, idx) => Object.assign({}, fresh.setup.players[idx], p))
        : fresh.setup.players;

      return {
        settings: Object.assign({}, fresh.settings, parsed.settings || {}),
        dashboard: mergedDashboard,
        setup: Object.assign({}, fresh.setup, parsed.setup || {}, { players: mergedPlayers }),
        stats: Object.assign({}, fresh.stats, parsed.stats || {}),
        anchors4P: (Array.isArray(parsed.anchors4P) && parsed.anchors4P.length === 4) ? parsed.anchors4P : fresh.anchors4P,
        anchors5P: (Array.isArray(parsed.anchors5P) && parsed.anchors5P.length === 5) ? parsed.anchors5P : fresh.anchors5P
      };
    } catch (e) {
      return fresh;
    }
  }

  save() {
    try {
      window.localStorage.setItem(this.storageKey, JSON.stringify(this.state));
    } catch (e) {}
  }

  resetAll() {
    this.state = this.getFreshState();
    this.save();
    return this.state;
  }

  resetDashboard() {
    this.state.dashboard = JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultDashboard));
    this.save();
  }

  resetAnchors() {
    this.state.anchors4P = JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultAnchors4P));
    this.state.anchors5P = JSON.parse(JSON.stringify(LUDO_CAPO_CONFIG.defaultAnchors5P));
    this.save();
  }

  getPlayerPalette(seatIdx) {
    const p = this.state.setup.players[seatIdx] || LUDO_CAPO_CONFIG.defaultSetup.players[seatIdx] || LUDO_CAPO_CONFIG.defaultSetup.players[0];
    return LUDO_CAPO_CONFIG.resolvePalette(p.colorIdx, p.customHex, p.colorName);
  }

  setPlayerColor(seatIdx, hexOrPresetId) {
    const p = this.state.setup.players[seatIdx];
    if (!p) return;
    const presetIdx = CAPO_COLOR_PRESETS.findIndex(
      c => c.id === hexOrPresetId || c.hex.toUpperCase() === String(hexOrPresetId).toUpperCase()
    );
    if (presetIdx >= 0) {
      p.colorIdx = presetIdx;
      p.customHex = CAPO_COLOR_PRESETS[presetIdx].hex;
      p.colorName = CAPO_COLOR_PRESETS[presetIdx].name;
    } else {
      const clean = CapoSmartColorEngine.normalizeHex(hexOrPresetId);
      p.customHex = clean;
      p.colorName = `Custom ${clean}`;
    }
    this.save();
  }

  recordMatchStart(themeId, diceId, tokenId) {
    this.state.stats.gamesPlayed += 1;
    if (this.state.stats.themeCounts[themeId] !== undefined) this.state.stats.themeCounts[themeId] += 1;
    if (this.state.stats.diceCounts[diceId] !== undefined) this.state.stats.diceCounts[diceId] += 1;
    if (this.state.stats.tokenCounts[tokenId] !== undefined) this.state.stats.tokenCounts[tokenId] += 1;
    this.save();
  }

  recordMatchWin(winnerSeatIdx, turnCount, matchPlayers = []) {
    this.state.stats.gamesWon += 1;
    if (this.state.stats.winsByPlayer[winnerSeatIdx] !== undefined) {
      this.state.stats.winsByPlayer[winnerSeatIdx] += 1;
    }
    if (!this.state.stats.fastestWinTurns || turnCount < this.state.stats.fastestWinTurns) {
      this.state.stats.fastestWinTurns = turnCount;
    }
    if (Array.isArray(matchPlayers)) {
      matchPlayers.forEach(mp => {
        const sc = mp.smartScore || 0;
        this.state.stats.totalSmartScore = (this.state.stats.totalSmartScore || 0) + Math.max(0, sc);
        if (sc > (this.state.stats.bestSmartScore || 0)) {
          this.state.stats.bestSmartScore = sc;
        }
        if ((mp.bestMovePts || 0) > (this.state.stats.bestSingleMovePts || 0)) {
          this.state.stats.bestSingleMovePts = mp.bestMovePts;
          this.state.stats.bestSingleMoveLabel = `${mp.name}: ${mp.bestMoveLabel} (+${mp.bestMovePts})`;
        }
      });
    }
    this.save();
  }

  getAverageSmartScore() {
    const gp = this.state.stats.gamesPlayed || 0;
    if (gp <= 0) return 0;
    return Math.round((this.state.stats.totalSmartScore || 0) / gp);
  }

  getFavoriteKey(mapObj, fallback) {
    let bestKey = fallback;
    let bestVal = -1;
    for (const [k, v] of Object.entries(mapObj || {})) {
      if (v > bestVal) {
        bestVal = v;
        bestKey = k;
      }
    }
    return bestKey;
  }
}
