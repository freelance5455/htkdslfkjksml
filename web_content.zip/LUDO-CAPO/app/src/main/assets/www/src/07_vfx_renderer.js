/* ============================================================================
 * MODULE 07: COMMERCIAL 3D BOARD, SMART-COLOR SUPER TOKENS & CINEMATIC
 *            CAPTURE-EXCLUSIVE SUPER ABILITY VFX ENGINE
 * Strictly Zero Emojis — Custom 3D Procedural Canvas Assets & Particle Shaders
 * ============================================================================ */

class CapoBoardRenderer {
  constructor(canvas, rules, storage) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.rules = rules;
    this.storage = storage;

    this.particles = [];
    this.rings = [];
    this.trails = [];
    this.floatingTexts = [];
    this.ambientParticles = [];
    this.activeSuperEffects = [];
    this.shakeTime = 0;
    this.shakeMag = 0;
    this.lastTime = performance.now();

    this.initAmbientParticles();
  }

  initAmbientParticles() {
    this.ambientParticles = [];
    for (let i = 0; i < 42; i++) {
      this.ambientParticles.push({
        x: Math.random() * 1000,
        y: Math.random() * 1000,
        r: 2 + Math.random() * 4.5,
        vx: (Math.random() - 0.5) * 0.45,
        vy: -0.25 - Math.random() * 0.55,
        alpha: 0.25 + Math.random() * 0.55,
        phase: Math.random() * Math.PI * 2
      });
    }
  }

  triggerShake(magnitude = 8, durationMs = 260) {
    if (!this.storage.state.settings.screenEffects) return;
    const shakeMul = (this.storage.state.dashboard && this.storage.state.dashboard.superAbilities)
      ? (this.storage.state.dashboard.superAbilities.cameraShakeMul || 1.0)
      : 1.0;
    this.shakeMag = magnitude * shakeMul;
    this.shakeTime = durationMs;
  }

  spawnBurst(x, y, colors, count = 28, speed = 5.0, size = 5.5, ringColor = null) {
    if (!this.storage.state.settings.vfxEnabled) return;
    const vfxMul = this.storage.state.settings.gameSpeed || 1;
    const dashSa = (this.storage.state.dashboard && this.storage.state.dashboard.superAbilities) || {};
    const countScaled = Math.max(4, Math.round(count * (dashSa.particleMultiplier || 1.0)));

    for (let i = 0; i < countScaled; i++) {
      const ang = (Math.PI * 2 * i) / countScaled + (Math.random() - 0.5) * 0.35;
      const spd = (0.45 + Math.random() * 0.85) * speed * vfxMul;
      this.particles.push({
        x,
        y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd - 0.8,
        size: size * (0.65 + Math.random() * 0.7),
        color: colors[i % colors.length],
        life: 1.0,
        decay: (0.017 + Math.random() * 0.016) * vfxMul,
        gravity: 0.09
      });
    }
    if (ringColor) {
      this.rings.push({
        x,
        y,
        r: 12,
        maxR: 92,
        color: ringColor,
        alpha: 0.95
      });
    }
  }

  spawnFloatingText(x, y, text, color = "#FEF08A") {
    if (!this.storage.state.settings.vfxEnabled) return;
    this.floatingTexts.push({
      x: Math.max(140, Math.min(860, x)),
      y: Math.max(80, Math.min(920, y)),
      text,
      color,
      life: 1.0
    });
  }

  addTrailPoint(x, y, color) {
    if (!this.storage.state.settings.vfxEnabled || this.storage.state.settings.trailsEnabled === false) return;
    this.trails.push({
      x,
      y,
      r: 15,
      color,
      alpha: 0.82
    });
  }

  /**
   * Resolves which Super Ability is active for the current capture event.
   * Returns null if Super Abilities are disabled or a Classic Token is used without override.
   */
  resolveActiveSuperAbility() {
    const settings = this.storage.state.settings;
    const dashSa = (this.storage.state.dashboard && this.storage.state.dashboard.superAbilities)
      || LUDO_CAPO_CONFIG.defaultDashboard.superAbilities;

    if (!settings.superAbilityVfxEnabled || !dashSa.enabled) return null;

    if (dashSa.globalOverride && dashSa.globalOverride !== "auto" && dashSa.globalOverride !== "none") {
      const ov = dashSa.globalOverride;
      if (dashSa.abilities && dashSa.abilities[ov] && dashSa.abilities[ov].enabled === false) return null;
      return ov;
    }

    const skin = getTokenSkinById(this.storage.state.setup.selectedToken);
    if (skin && skin.isSuper && skin.superAbility) {
      const ab = skin.superAbility;
      if (dashSa.abilities && dashSa.abilities[ab] && dashSa.abilities[ab].enabled === false) return null;
      return ab;
    }
    return null;
  }

  /**
   * CAPTURE-EXCLUSIVE SUPER TOKEN ABILITY SEQUENCER
   * Triggered ONLY when a token successfully captures an opposing token (or via Dashboard Test Arena).
   */
  triggerSuperCaptureSequence(abilityType, x, y, attackerPal, victimPal, victimTokens = [], yardPos = null, onComplete = null) {
    const dashSa = (this.storage.state.dashboard && this.storage.state.dashboard.superAbilities)
      || LUDO_CAPO_CONFIG.defaultDashboard.superAbilities;
    const abCfg = (dashSa.abilities && dashSa.abilities[abilityType])
      || { duration: 1150, intensity: 1.0, particles: 45, scale: 1.0, shake: 12 };

    const speedSetting = (this.storage.state.settings.superAbilitySpeed || 1.0) * (this.storage.state.settings.gameSpeed || 1.0);
    const totalDuration = Math.max(480, Math.round(
      (abCfg.duration || 1150) * (dashSa.durationMul || 1.0) / Math.max(0.5, speedSetting)
    ));
    const effectScale = (abCfg.scale || 1.0) * (dashSa.effectScale || 1.0);
    const intensity = (abCfg.intensity || 1.0) * (dashSa.vfxIntensity || 1.0);
    const pCount = Math.max(12, Math.round((abCfg.particles || 44) * (dashSa.particleMultiplier || 1.0)));

    this.triggerShake((abCfg.shake || 12) * (dashSa.impactStrength || 1.0), Math.min(480, totalDuration * 0.45));

    // Pre-generate bespoke sub-particles for the ability
    const subParticles = [];
    for (let i = 0; i < pCount; i++) {
      const ang = (Math.PI * 2 * i) / pCount + (Math.random() - 0.5) * 0.4;
      subParticles.push({
        angle: ang,
        dist: 18 + Math.random() * 88,
        speed: 0.6 + Math.random() * 1.4,
        size: 3.5 + Math.random() * 6.5,
        rot: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.22,
        yOffset: Math.random() * 60,
        colorIdx: i % 4
      });
    }

    const targetYard = yardPos || { x: x > 500 ? 850 : 150, y: y > 500 ? 850 : 150 };

    // Temporarily hide normal token rendering for victim so the custom ability controls the victim's visual state
    victimTokens.forEach(vt => {
      vt.hiddenBySuperAbility = true;
    });

    this.activeSuperEffects.push({
      abilityType,
      x,
      y,
      targetYard,
      attackerPal: attackerPal || LUDO_CAPO_CONFIG.playerPalettes[0],
      victimPal: victimPal || LUDO_CAPO_CONFIG.playerPalettes[1],
      victimTokens,
      startTime: performance.now(),
      duration: totalDuration,
      scale: effectScale,
      intensity,
      subParticles,
      burstTriggered: false,
      onComplete
    });
  }

  /**
   * Renders all active Capture-Exclusive Super Ability animations on the Canvas
   */
  updateAndDrawSuperEffects(ctx, now) {
    for (let i = this.activeSuperEffects.length - 1; i >= 0; i--) {
      const fx = this.activeSuperEffects[i];
      const elapsed = now - fx.startTime;
      const p = Math.max(0, Math.min(1, elapsed / fx.duration));

      ctx.save();
      if (fx.abilityType === "blackhole") {
        this.drawSuperBlackHole(ctx, fx, p, now);
      } else if (fx.abilityType === "ice") {
        this.drawSuperIceFreeze(ctx, fx, p, now);
      } else if (fx.abilityType === "fire") {
        this.drawSuperFireInferno(ctx, fx, p, now);
      } else if (fx.abilityType === "kick") {
        this.drawSuperFootKick(ctx, fx, p, now);
      } else if (fx.abilityType === "devour") {
        this.drawSuperMonsterDevour(ctx, fx, p, now);
      } else {
        this.drawSuperThunderStrike(ctx, fx, p, now);
      }
      ctx.restore();

      if (p >= 1) {
        fx.victimTokens.forEach(vt => {
          vt.hiddenBySuperAbility = false;
          vt.relStep = -1;
          vt.animX = null;
          vt.animY = null;
          vt.hopZ = 0;
          vt.animScale = 1;
        });
        if (typeof fx.onComplete === "function") {
          const cb = fx.onComplete;
          fx.onComplete = null;
          cb();
        }
        this.activeSuperEffects.splice(i, 1);
      }
    }
  }

  /* --------------------------------------------------------------------------
   * 1. BLACK HOLE SUPER ABILITY
   * Miniature singularity -> space distortion -> gravitational pull -> collapse
   * -------------------------------------------------------------------------- */
  drawSuperBlackHole(ctx, fx, p, now) {
    const { x, y, scale, attackerPal, victimPal, subParticles } = fx;
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    // Stage curve: open (0..0.25), pull & distort (0.25..0.78), collapse (0.78..1.0)
    const openFactor = p < 0.22 ? (p / 0.22) : (p < 0.80 ? 1.0 : Math.max(0, (1 - p) / 0.20));
    const coreR = 54 * openFactor;

    // 1. Space-Time Gravitational Lensing Grid Distortion Rings
    for (let rIdx = 1; rIdx <= 3; rIdx++) {
      const waveP = ((p * 2.6 + rIdx * 0.33) % 1);
      const ringR = 115 * (1 - waveP) * openFactor;
      ctx.beginPath();
      ctx.arc(0, 0, Math.max(2, ringR), 0, Math.PI * 2);
      ctx.strokeStyle = rIdx % 2 === 0 ? attackerPal.secondary : "#A855F7";
      ctx.globalAlpha = waveP * 0.75 * openFactor;
      ctx.lineWidth = 3.5;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // 2. Rotating Relativistic Accretion Disk
    ctx.save();
    ctx.rotate(now * 0.008);
    const diskGrad = ctx.createRadialGradient(0, 0, coreR * 0.35, 0, 0, coreR * 1.95);
    diskGrad.addColorStop(0, "#000000");
    diskGrad.addColorStop(0.42, "#7E22CE");
    diskGrad.addColorStop(0.72, attackerPal.primary);
    diskGrad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = diskGrad;
    ctx.beginPath();
    ctx.arc(0, 0, coreR * 1.95, 0, Math.PI * 2);
    ctx.fill();

    // Swirling Photon Arms
    for (let arm = 0; arm < 4; arm++) {
      ctx.save();
      ctx.rotate((Math.PI / 2) * arm);
      ctx.beginPath();
      ctx.arc(14 * openFactor, 0, coreR * 1.15, 0, Math.PI * 1.15);
      ctx.strokeStyle = "#FDE047";
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.restore();
    }
    ctx.restore();

    // 3. Gravitational Inward Particles
    subParticles.forEach(sp => {
      const cycle = (p * sp.speed * 1.8) % 1;
      const curDist = sp.dist * (1 - cycle) * openFactor;
      const curAng = sp.angle + p * 8.5;
      const px = Math.cos(curAng) * curDist;
      const py = Math.sin(curAng) * curDist;
      ctx.fillStyle = sp.colorIdx % 2 === 0 ? "#E9D5FF" : attackerPal.light;
      ctx.beginPath();
      ctx.arc(px, py, sp.size * (1 - cycle * 0.5), 0, Math.PI * 2);
      ctx.fill();
    });

    // 4. Event Horizon Schwarzschild Singularity Core
    ctx.beginPath();
    ctx.arc(0, 0, Math.max(1, coreR), 0, Math.PI * 2);
    ctx.fillStyle = "#020108";
    ctx.fill();
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = "#C084FC";
    ctx.stroke();

    // 5. Captured Victim Token Spaghettifying & Spiraling Into the Black Hole (0..0.75)
    if (p < 0.76) {
      const pullT = Math.min(1, p / 0.75);
      const spiralDist = 42 * (1 - pullT);
      const spiralAng = pullT * Math.PI * 4.5;
      const vx = Math.cos(spiralAng) * spiralDist;
      const vy = Math.sin(spiralAng) * spiralDist;
      const stretchX = Math.max(0.05, (1 - pullT) * 1.15);
      const stretchY = Math.max(0.05, (1 - pullT * 0.85) * (1 + pullT * 0.9));

      ctx.save();
      ctx.translate(vx, vy);
      ctx.rotate(spiralAng + 0.8);
      ctx.scale(stretchX, stretchY);
      this.drawMiniVictimPawn(ctx, victimPal);
      ctx.restore();
    }

    // 6. Final Collapse Shockwave Flash (0.76..1.0)
    if (p >= 0.76) {
      if (!fx.burstTriggered) {
        fx.burstTriggered = true;
        this.spawnBurst(x, y, ["#C084FC", attackerPal.primary, "#FEF08A", "#FFFFFF"], 32, 6.2, 6.0, "#C084FC");
      }
      const flashP = (p - 0.76) / 0.24;
      ctx.beginPath();
      ctx.arc(0, 0, 95 * flashP, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(255, 255, 255, ${1 - flashP})`;
      ctx.lineWidth = 6 * (1 - flashP);
      ctx.stroke();
    }
  }

  /* --------------------------------------------------------------------------
   * 2. ICE / FREEZE SUPER ABILITY
   * Rapid frost spread -> crystal encasement -> dramatic freeze -> 18-shard shatter
   * -------------------------------------------------------------------------- */
  drawSuperIceFreeze(ctx, fx, p, now) {
    const { x, y, scale, victimPal, subParticles } = fx;
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    // Phase 1 & 2 (0..0.64): Frost spreads, encases token in crystalline ice block, holds frozen
    if (p < 0.64) {
      const freezeGrow = Math.min(1, p / 0.28);

      // Ground Frost Nova Ring
      ctx.beginPath();
      ctx.arc(0, 4, 68 * freezeGrow, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(186, 230, 253, 0.35)";
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#7DD3FC";
      ctx.stroke();

      // Radial Ice Spikes
      for (let s = 0; s < 8; s++) {
        ctx.save();
        ctx.rotate((Math.PI * 2 * s) / 8);
        ctx.beginPath();
        ctx.moveTo(-8, -10);
        ctx.lineTo(0, -64 * freezeGrow);
        ctx.lineTo(8, -10);
        ctx.closePath();
        ctx.fillStyle = "rgba(125, 211, 252, 0.75)";
        ctx.strokeStyle = "#FFFFFF";
        ctx.lineWidth = 1.5;
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }

      // Victim Token Frozen Inside
      const shiverX = p > 0.45 ? Math.sin(now * 0.08) * 3.5 : 0;
      ctx.save();
      ctx.translate(shiverX, 0);
      this.drawMiniVictimPawn(ctx, victimPal);

      // Translucent 3D Faceted Glacial Ice Block Encasing the Token
      ctx.scale(freezeGrow, freezeGrow);
      const iceGrad = ctx.createLinearGradient(-34, -52, 34, 24);
      iceGrad.addColorStop(0, "rgba(255, 255, 255, 0.82)");
      iceGrad.addColorStop(0.45, "rgba(125, 211, 252, 0.68)");
      iceGrad.addColorStop(1, "rgba(2, 132, 199, 0.78)");

      ctx.beginPath();
      ctx.moveTo(0, -56);
      ctx.lineTo(32, -32);
      ctx.lineTo(26, 18);
      ctx.lineTo(-26, 18);
      ctx.lineTo(-32, -32);
      ctx.closePath();
      ctx.fillStyle = iceGrad;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();

      // Internal Fracture Lines forming before shatter (0.42..0.64)
      if (p > 0.40) {
        ctx.beginPath();
        ctx.moveTo(-18, -36);
        ctx.lineTo(4, -14);
        ctx.lineTo(22, -26);
        ctx.moveTo(4, -14);
        ctx.lineTo(-12, 10);
        ctx.strokeStyle = "#FFFFFF";
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }
      ctx.restore();
    } else {
      // Phase 3 (0.64..1.0): Frozen token & crystal block SHATTER into polygonal ice shards!
      if (!fx.burstTriggered) {
        fx.burstTriggered = true;
        this.spawnBurst(x, y, ["#FFFFFF", "#E0F2FE", "#38BDF8", victimPal.primary], 36, 7.2, 6.2, "#38BDF8");
        this.triggerShake(14, 240);
      }
      const shP = (p - 0.64) / 0.36;
      subParticles.forEach((sp, idx) => {
        const dist = sp.dist * 1.45 * shP;
        const sx = Math.cos(sp.angle) * dist;
        const sy = Math.sin(sp.angle) * dist + shP * shP * 28;
        ctx.save();
        ctx.translate(sx, sy);
        ctx.rotate(sp.rot + shP * 6);
        ctx.globalAlpha = Math.max(0, 1 - shP);
        ctx.fillStyle = idx % 3 === 0 ? victimPal.primary : (idx % 2 === 0 ? "#E0F2FE" : "#38BDF8");
        ctx.strokeStyle = "#FFFFFF";
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(0, -sp.size * 1.6);
        ctx.lineTo(sp.size * 1.3, sp.size);
        ctx.lineTo(-sp.size * 1.3, sp.size);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      });
    }
  }

  /* --------------------------------------------------------------------------
   * 3. FIRE SUPER ABILITY
   * Magma rune ring -> roaring flame vortex -> sparks/embers -> controlled fire burst
   * -------------------------------------------------------------------------- */
  drawSuperFireInferno(ctx, fx, p, now) {
    const { x, y, scale, victimPal, subParticles } = fx;
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    if (p < 0.74) {
      const buildP = Math.min(1, p / 0.30);
      const consumeP = Math.max(0, (p - 0.25) / 0.49);

      // 1. Searing Magma Ground Ring
      const ringGrad = ctx.createRadialGradient(0, 4, 8, 0, 4, 66 * buildP);
      ringGrad.addColorStop(0, "#FEF08A");
      ringGrad.addColorStop(0.55, "#F97316");
      ringGrad.addColorStop(1, "rgba(220, 38, 38, 0)");
      ctx.fillStyle = ringGrad;
      ctx.beginPath();
      ctx.arc(0, 4, 66 * buildP, 0, Math.PI * 2);
      ctx.fill();

      // 2. Victim Token Being Consumed Inside the Flame Vortex
      ctx.save();
      ctx.scale(Math.max(0.08, 1 - consumeP * 0.92), Math.max(0.08, 1 - consumeP * 0.85));
      ctx.globalAlpha = Math.max(0, 1 - consumeP);
      this.drawMiniVictimPawn(ctx, victimPal);
      ctx.restore();

      // 3. Multi-Layered Swirling Flame Tongues
      const flameLayers = [
        { r: 44 * buildP, h: 86 * buildP, col: "rgba(220, 38, 38, 0.85)" },
        { r: 32 * buildP, h: 68 * buildP, col: "rgba(249, 115, 22, 0.90)" },
        { r: 20 * buildP, h: 48 * buildP, col: "rgba(254, 240, 138, 0.95)" }
      ];
      flameLayers.forEach((layer, lIdx) => {
        const wave = Math.sin(now * 0.018 + lIdx * 1.5) * 10;
        ctx.beginPath();
        ctx.moveTo(-layer.r, 12);
        ctx.quadraticCurveTo(-layer.r * 1.2, -layer.h * 0.45, wave, -layer.h);
        ctx.quadraticCurveTo(layer.r * 1.2, -layer.h * 0.45, layer.r, 12);
        ctx.closePath();
        ctx.fillStyle = layer.col;
        ctx.fill();
      });

      // 4. Rising Sparks & Embers
      subParticles.forEach((sp, idx) => {
        const rise = ((p * 2.2 + idx * 0.07) % 1);
        const ex = Math.sin(now * 0.01 + idx) * (36 * (1 - rise * 0.4));
        const ey = 10 - rise * 105;
        ctx.fillStyle = idx % 2 === 0 ? "#FEF08A" : "#FB923C";
        ctx.beginPath();
        ctx.arc(ex, ey, sp.size * (1 - rise * 0.6), 0, Math.PI * 2);
        ctx.fill();
      });
    } else {
      // Phase 3 (0.74..1.0): Controlled Solar Fire Burst Detonation
      if (!fx.burstTriggered) {
        fx.burstTriggered = true;
        this.spawnBurst(x, y, ["#FEF08A", "#F97316", "#EF4444", "#FFFFFF"], 40, 7.5, 6.8, "#F97316");
        this.triggerShake(13, 250);
      }
      const detP = (p - 0.74) / 0.26;
      const detR = 98 * detP;
      const detGrad = ctx.createRadialGradient(0, 0, detR * 0.2, 0, 0, detR);
      detGrad.addColorStop(0, `rgba(255, 255, 255, ${1 - detP})`);
      detGrad.addColorStop(0.5, `rgba(251, 146, 60, ${0.85 * (1 - detP)})`);
      detGrad.addColorStop(1, "rgba(220, 38, 38, 0)");
      ctx.fillStyle = detGrad;
      ctx.beginPath();
      ctx.arc(0, 0, detR, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  /* --------------------------------------------------------------------------
   * 4. FOOT KICK SUPER ABILITY (100% Custom 3D Armored Boot Asset — NO Emojis)
   * Custom 3D boot swings in -> kicks token -> shockwave -> high-velocity trail to yard
   * -------------------------------------------------------------------------- */
  drawSuperFootKick(ctx, fx, p, now) {
    const { x, y, targetYard, scale, attackerPal, victimPal } = fx;

    // Phase 1 (0..0.32): Custom 3D Armored Golden Boot winds up & swings into the target
    // Phase 2 (0.32..1.0): Boot impacts at p=0.32, launching victim token with motion trail to targetYard
    const impactT = 0.32;

    if (p < impactT) {
      const swingP = p / impactT;
      // Victim token waiting on tile before impact
      ctx.save();
      ctx.translate(x, y);
      ctx.scale(scale, scale);
      this.drawMiniVictimPawn(ctx, victimPal);
      ctx.restore();

      // Custom 3D Armored Greave & Boot swinging on pivot
      ctx.save();
      ctx.translate(x - 38 * scale, y - 54 * scale);
      ctx.scale(scale, scale);
      const swingAngle = (1 - swingP) * 1.15 - 0.15;
      ctx.rotate(swingAngle);
      this.drawCustom3DArmoredBoot(ctx, attackerPal);
      ctx.restore();
    } else {
      if (!fx.burstTriggered) {
        fx.burstTriggered = true;
        this.spawnBurst(x, y, ["#FEF08A", attackerPal.primary, "#FFFFFF", victimPal.primary], 34, 7.8, 6.5, "#FACC15");
        this.triggerShake(16, 300);
      }

      const flightP = (p - impactT) / (1 - impactT);

      // Boot follow-through & fade out (0.32..0.62)
      if (flightP < 0.45) {
        const fade = 1 - flightP / 0.45;
        ctx.save();
        ctx.translate(x - 16 * scale, y - 44 * scale);
        ctx.scale(scale, scale);
        ctx.rotate(-0.42);
        ctx.globalAlpha = fade;
        this.drawCustom3DArmoredBoot(ctx, attackerPal);
        ctx.restore();
      }

      // Directional Impact Shockwave Cone at Capture Tile
      if (flightP < 0.35) {
        const coneP = flightP / 0.35;
        ctx.save();
        ctx.translate(x, y);
        ctx.strokeStyle = `rgba(254, 240, 138, ${1 - coneP})`;
        ctx.lineWidth = 5 * (1 - coneP);
        ctx.beginPath();
        ctx.arc(0, 0, 75 * coneP, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Kicked Token Travelling with High-Velocity Comet Trail to Home Yard
      const curX = x + (targetYard.x - x) * flightP;
      const curY = y + (targetYard.y - y) * flightP - Math.sin(flightP * Math.PI) * 155;

      // Strong Motion Blur & Comet Trail
      for (let tr = 1; tr <= 6; tr++) {
        const tp = Math.max(0, flightP - tr * 0.035);
        const tx = x + (targetYard.x - x) * tp;
        const ty = y + (targetYard.y - y) * tp - Math.sin(tp * Math.PI) * 155;
        ctx.save();
        ctx.globalAlpha = (1 - tr / 7) * 0.65;
        ctx.fillStyle = tr % 2 === 0 ? "#FEF08A" : victimPal.secondary;
        ctx.beginPath();
        ctx.arc(tx, ty, (18 - tr * 2) * scale, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Spinning Kicked Victim Token
      ctx.save();
      ctx.translate(curX, curY);
      ctx.rotate(flightP * Math.PI * 6);
      ctx.scale(scale * (1 + Math.sin(flightP * Math.PI) * 0.35), scale * (1 + Math.sin(flightP * Math.PI) * 0.35));
      this.drawMiniVictimPawn(ctx, victimPal);
      ctx.restore();
    }
  }

  /**
   * Custom-Drawn 3D Sculpted Sovereign Armored Boot Asset (Strictly Zero Emojis)
   */
  drawCustom3DArmoredBoot(ctx, pal) {
    ctx.save();
    // Metallic Gold & Player-Colored Greave / Boot Gradient
    const bootGrad = ctx.createLinearGradient(-25, 0, 45, 70);
    bootGrad.addColorStop(0, "#FEF08A");
    bootGrad.addColorStop(0.45, "#F59E0B");
    bootGrad.addColorStop(1, "#78350F");

    // 1. Upper Armored Shin Greave
    ctx.beginPath();
    ctx.moveTo(-18, 0);
    ctx.lineTo(14, 0);
    ctx.lineTo(12, 42);
    ctx.lineTo(-14, 42);
    ctx.closePath();
    ctx.fillStyle = pal.primary;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = "#FEF08A";
    ctx.stroke();

    // Winged Gold Crest on Greave
    ctx.beginPath();
    ctx.moveTo(-24, 14);
    ctx.lineTo(-6, 8);
    ctx.lineTo(-8, 24);
    ctx.closePath();
    ctx.fillStyle = "#FEF08A";
    ctx.fill();

    // 2. Sculpted 3D Foot & Toe Plate
    ctx.beginPath();
    ctx.moveTo(-16, 38);
    ctx.lineTo(14, 38);
    ctx.lineTo(44, 48);
    ctx.quadraticCurveTo(52, 56, 44, 64);
    ctx.lineTo(-18, 64);
    ctx.closePath();
    ctx.fillStyle = bootGrad;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = "#FFFFFF";
    ctx.stroke();

    // 3. Heavy Reinforced Impact Sole & Cleat Studs
    ctx.fillStyle = "#0F172A";
    ctx.fillRect(-18, 62, 62, 8);
    ctx.fillStyle = "#FEF08A";
    [-12, 2, 16, 30].forEach(cx => {
      ctx.fillRect(cx, 70, 6, 4);
    });
    ctx.restore();
  }

  /* --------------------------------------------------------------------------
   * 5. DEVOUR / MONSTER SUPER ABILITY (100% Custom 3D Fanged Maw — NO Emojis)
   * Monster jaws open dramatically -> pulls target in -> bites/chomps shut -> gulp
   * -------------------------------------------------------------------------- */
  drawSuperMonsterDevour(ctx, fx, p, now) {
    const { x, y, scale, attackerPal, victimPal } = fx;
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    // Phase 1 (0..0.42): Monster jaws open wide; victim token is pulled upward into the maw
    // Phase 2 (0.42..0.68): Jaws snap shut violently on the victim token!
    // Phase 3 (0.68..1.00): Monster gulps (scale bounce) and fades out with crunch particles
    let jawOpen = 0;
    if (p < 0.38) {
      jawOpen = Math.min(1, p / 0.28) * 34;
    } else if (p < 0.56) {
      const snapP = (p - 0.38) / 0.18;
      jawOpen = 34 * (1 - snapP);
    } else {
      jawOpen = 0;
    }

    if (p >= 0.54 && !fx.burstTriggered) {
      fx.burstTriggered = true;
      this.spawnBurst(x, y, [attackerPal.primary, "#FEF08A", victimPal.primary, "#FFFFFF"], 38, 7.0, 6.4, attackerPal.primary);
      this.triggerShake(15, 280);
    }

    const gulpBounce = p >= 0.56 ? 1 + Math.sin(((p - 0.56) / 0.44) * Math.PI * 2) * 0.22 : 1.0;
    const endFade = p > 0.82 ? (1 - p) / 0.18 : 1.0;
    ctx.globalAlpha = Math.max(0, endFade);
    ctx.scale(gulpBounce, gulpBounce);

    // 1. Dark Abyssal Throat Cavity Behind Jaws
    ctx.beginPath();
    ctx.ellipse(0, 0, 44, 18 + jawOpen, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#05030A";
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = attackerPal.primary;
    ctx.stroke();

    // 2. Victim Token Being Pulled Into the Open Jaws (visible before jaws snap shut at p=0.52)
    if (p < 0.52) {
      const pullP = p / 0.52;
      ctx.save();
      ctx.translate(0, 18 * (1 - pullP));
      ctx.scale(1 - pullP * 0.45, 1 - pullP * 0.45);
      this.drawMiniVictimPawn(ctx, victimPal);
      ctx.restore();
    }

    // 3. Custom Sculpted Upper Horned Monster Head & Fanged Upper Jaw
    ctx.save();
    ctx.translate(0, -jawOpen);

    // Curved Obsidian/Gold Horns
    ctx.fillStyle = "#FBBF24";
    ctx.strokeStyle = "#0F172A";
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(-34, -18);
    ctx.quadraticCurveTo(-56, -42, -40, -58);
    ctx.quadraticCurveTo(-30, -38, -20, -24);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(34, -18);
    ctx.quadraticCurveTo(56, -42, 40, -58);
    ctx.quadraticCurveTo(30, -38, 20, -24);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Upper Cranium Dome
    const headGrad = ctx.createRadialGradient(-10, -28, 4, 0, -15, 48);
    headGrad.addColorStop(0, attackerPal.light);
    headGrad.addColorStop(0.5, attackerPal.primary);
    headGrad.addColorStop(1, attackerPal.dark);

    ctx.beginPath();
    ctx.moveTo(-44, 0);
    ctx.bezierCurveTo(-46, -42, 46, -42, 44, 0);
    ctx.closePath();
    ctx.fillStyle = headGrad;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = attackerPal.edge || "#FEF08A";
    ctx.stroke();

    // Fierce Glowing Predator Eyes
    ctx.fillStyle = "#FDE047";
    ctx.beginPath();
    ctx.moveTo(-28, -18); ctx.lineTo(-10, -11); ctx.lineTo(-24, -8); ctx.closePath();
    ctx.moveTo(28, -18);  ctx.lineTo(10, -11);  ctx.lineTo(24, -8);  ctx.closePath();
    ctx.fill();

    // Upper Row of Sharp Custom Fangs
    ctx.fillStyle = "#FFFFFF";
    ctx.strokeStyle = "#0F172A";
    ctx.lineWidth = 1.5;
    [-32, -19, -6, 6, 19, 32].forEach((fxPos, idx) => {
      const fangLen = (idx === 0 || idx === 5) ? 18 : 13;
      ctx.beginPath();
      ctx.moveTo(fxPos - 5.5, 0);
      ctx.lineTo(fxPos, fangLen);
      ctx.lineTo(fxPos + 5.5, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    });
    ctx.restore();

    // 4. Custom Sculpted Lower Monster Jaw & Lower Fangs
    ctx.save();
    ctx.translate(0, jawOpen);

    // Lower Fangs pointing up
    ctx.fillStyle = "#FFFFFF";
    ctx.strokeStyle = "#0F172A";
    ctx.lineWidth = 1.5;
    [-26, -13, 0, 13, 26].forEach((fxPos, idx) => {
      const fangLen = (idx === 0 || idx === 4) ? 16 : 11;
      ctx.beginPath();
      ctx.moveTo(fxPos - 5, 0);
      ctx.lineTo(fxPos, -fangLen);
      ctx.lineTo(fxPos + 5, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    });

    // Armored Chin Plate
    ctx.beginPath();
    ctx.moveTo(-42, 0);
    ctx.bezierCurveTo(-38, 30, 38, 30, 42, 0);
    ctx.closePath();
    ctx.fillStyle = attackerPal.dark;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = attackerPal.edge || "#FEF08A";
    ctx.stroke();
    ctx.restore();
  }

  /* --------------------------------------------------------------------------
   * 6. THUNDER / PLASMA STRIKE SUPER ABILITY
   * -------------------------------------------------------------------------- */
  drawSuperThunderStrike(ctx, fx, p, now) {
    const { x, y, scale, victimPal } = fx;
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    if (p < 0.65) {
      // Jagged Orbital Lightning Bolt
      ctx.save();
      ctx.strokeStyle = "#FEF08A";
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(0, -240);
      ctx.lineTo(-22, -160);
      ctx.lineTo(18, -110);
      ctx.lineTo(-16, -50);
      ctx.lineTo(0, 0);
      ctx.stroke();

      ctx.strokeStyle = "#38BDF8";
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.restore();

      ctx.save();
      ctx.scale(1 - p * 0.6, 1 - p * 0.6);
      this.drawMiniVictimPawn(ctx, victimPal);
      ctx.restore();
    } else if (!fx.burstTriggered) {
      fx.burstTriggered = true;
      this.spawnBurst(x, y, ["#FEF08A", "#38BDF8", "#FFFFFF", victimPal.primary], 36, 7.2, 6.2, "#38BDF8");
    }
  }

  drawMiniVictimPawn(ctx, pal) {
    const g = ctx.createRadialGradient(-5, -18, 2, 0, -12, 24);
    g.addColorStop(0, "#FFFFFF");
    g.addColorStop(0.3, pal.light || "#E0F2FE");
    g.addColorStop(0.7, pal.primary || "#DC2626");
    g.addColorStop(1, pal.dark || "#7F1D1D");

    ctx.beginPath();
    ctx.ellipse(0, 5, 15, 5.5, 0, 0, Math.PI * 2);
    ctx.fillStyle = pal.edge || "#FBBF24";
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(-13, 4);
    ctx.quadraticCurveTo(-8, -13, -5, -18);
    ctx.lineTo(5, -18);
    ctx.quadraticCurveTo(8, -13, 13, 4);
    ctx.closePath();
    ctx.fillStyle = g;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#FFFFFF";
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(0, -25, 10, 0, Math.PI * 2);
    ctx.fillStyle = g;
    ctx.fill();
    ctx.stroke();
  }

  clientToBoardCoords(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return { x: -1, y: -1 };
    let nx = ((clientX - rect.left) / rect.width) * 1000;
    let ny = ((clientY - rect.top) / rect.height) * 1000;

    // Account for Dashboard board transform (offsetX, offsetY, scale, rotationDeg)
    const bCfg = (this.storage.state.dashboard && this.storage.state.dashboard.board) || {};
    const dx = nx - (500 + (bCfg.offsetX || 0));
    const dy = ny - (500 + (bCfg.offsetY || 0));
    const bScale = bCfg.scale || 1.0;
    const rotRad = -((bCfg.rotationDeg || 0) * Math.PI) / 180;
    const rx = (dx * Math.cos(rotRad) - dy * Math.sin(rotRad)) / bScale + 500;
    const ry = (dx * Math.sin(rotRad) + dy * Math.cos(rotRad)) / bScale + 500;

    return { x: rx, y: ry };
  }

  findTokenAtPoint(bx, by) {
    const selectableIds = new Set(this.rules.validTokenIds || []);
    if (selectableIds.size === 0) return null;

    const renderedTokens = this.computeTokenRenderList();
    let bestToken = null;
    let bestDist = 68;
    for (let i = renderedTokens.length - 1; i >= 0; i--) {
      const item = renderedTokens[i];
      if (!selectableIds.has(item.token.id)) continue;
      const dx = bx - item.drawX;
      const dy = by - (item.drawY - 18);
      const dist = Math.hypot(dx, dy);
      if (dist < bestDist) {
        bestDist = dist;
        bestToken = item.token;
      }
    }
    return bestToken;
  }

  computeTokenRenderList() {
    const board = this.rules.board;
    const list = [];
    const groups = new Map();

    const tkDash = (this.storage.state.dashboard && this.storage.state.dashboard.token) || {};
    const userTokenScale = tkDash.scale || 1.0;
    const baseModeScale = (board.isFivePlayer ? 1.34 : 1.58) * userTokenScale;

    for (const player of this.rules.players) {
      for (const token of player.tokens) {
        if (token.hiddenBySuperAbility) continue;
        const basePos = board.getTokenWorldPosition(player.seatIdx, token.tokenIndex, token.relStep);
        const isAnimating = token.animX !== null && token.animY !== null;
        const x = isAnimating ? token.animX : basePos.x;
        const y = isAnimating ? token.animY : basePos.y;
        const key = isAnimating ? `anim_${token.id}` : `${Math.round(x * 0.25)}_${Math.round(y * 0.25)}`;

        const selectable = this.rules.validTokenIds.includes(token.id);
        const entry = {
          token,
          player,
          baseX: x,
          baseY: y,
          drawX: x,
          drawY: y,
          hopZ: token.hopZ || 0,
          scale: (token.animScale || 1) * baseModeScale * (selectable ? 1.12 : 1.0),
          selectable,
          stackCount: 1,
          isStackTop: false
        };
        list.push(entry);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(entry);
      }
    }

    for (const group of groups.values()) {
      if (group.length > 1) {
        const radius = group.length === 2 ? 12 : 15;
        group.forEach((item, idx) => {
          const ang = (Math.PI * 2 * idx) / group.length - Math.PI / 4;
          item.drawX = item.baseX + Math.cos(ang) * radius;
          item.drawY = item.baseY + Math.sin(ang) * radius;
          item.scale *= 0.85;
          item.stackCount = group.length;
          item.isStackTop = (idx === group.length - 1);
        });
      }
    }

    list.sort((a, b) => {
      if (a.hopZ !== b.hopZ) return a.hopZ - b.hopZ;
      if (a.selectable !== b.selectable) return a.selectable ? 1 : -1;
      return a.drawY - b.drawY;
    });

    return list;
  }

  renderFrame(now = performance.now()) {
    const dt = Math.min(50, now - this.lastTime);
    this.lastTime = now;

    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    if (w <= 0 || h <= 0) return;

    const theme = getThemeById(this.storage.state.setup.selectedTheme);
    const scale = w / 1000;
    const bCfg = (this.storage.state.dashboard && this.storage.state.dashboard.board) || {};

    ctx.save();
    ctx.clearRect(0, 0, w, h);
    ctx.scale(scale, scale);

    if (this.shakeTime > 0) {
      this.shakeTime -= dt;
      const sx = (Math.random() - 0.5) * this.shakeMag * 2;
      const sy = (Math.random() - 0.5) * this.shakeMag * 2;
      ctx.translate(sx, sy);
    }

    // Apply Dashboard Board Scale, Position Offset & Rotation
    ctx.translate(500 + (bCfg.offsetX || 0), 500 + (bCfg.offsetY || 0));
    if (bCfg.rotationDeg) {
      ctx.rotate((bCfg.rotationDeg * Math.PI) / 180);
    }
    if (bCfg.scale && bCfg.scale !== 1) {
      ctx.scale(bCfg.scale, bCfg.scale);
    }
    ctx.translate(-500, -500);

    if (this.rules.board.isFivePlayer) {
      this.drawFivePlayerPentagonBoard(ctx, theme, now, bCfg);
    } else {
      this.drawFourPlayerCrossBoard(ctx, theme, now, bCfg);
    }

    this.updateAndDrawVfx(ctx, theme, now);

    const tokenSkinId = this.storage.state.setup.selectedToken;
    const renderList = this.computeTokenRenderList();
    for (const item of renderList) {
      this.drawToken3D(ctx, item, tokenSkinId, now);
    }

    // Render Capture-Exclusive Super Token Sequences on top of the board
    this.updateAndDrawSuperEffects(ctx, now);

    this.updateAndDrawTopParticles(ctx);

    ctx.restore();
  }

  resolveBoardMaterials(theme, bCfg) {
    let surface = theme.boardSurface;
    let surfaceAlt = theme.boardSurfaceAlt;
    let frame = theme.boardOuterFrame;

    if (bCfg.surfaceMaterial === "marble") {
      surface = "#F8FAFC"; surfaceAlt = "#E2E8F0";
    } else if (bCfg.surfaceMaterial === "obsidian") {
      surface = "#0F172A"; surfaceAlt = "#1E293B";
    } else if (bCfg.surfaceMaterial === "parchment") {
      surface = "#FBF7EC"; surfaceAlt = "#F2E8CF";
    } else if (bCfg.surfaceMaterial === "crystal") {
      surface = "#E0F2FE"; surfaceAlt = "#BAE6FD";
    } else if (bCfg.surfaceMaterial === "wood") {
      surface = "#FEF3C7"; surfaceAlt = "#FDE68A"; frame = "#78350F";
    }

    if (bCfg.customSurfaceColor) surface = bCfg.customSurfaceColor;
    if (bCfg.customFrameColor) frame = bCfg.customFrameColor;
    return { surface, surfaceAlt, frame };
  }

  /* --------------------------------------------------------------------------
   * COMMERCIAL 4-ARM CROSS LUDO BOARD RENDERER (SMART COLOR SYNCHRONIZED)
   * -------------------------------------------------------------------------- */
  drawFourPlayerCrossBoard(ctx, theme, now, bCfg = {}) {
    const b = this.rules.board;
    const pad = b.pad;
    const inner = b.innerSize;
    const cell = b.cell;
    const cellGap = Math.max(0, Math.min(4, bCfg.cellGap || 0));
    const yardSockMul = bCfg.yardSocketScale || 1.0;
    const mats = this.resolveBoardMaterials(theme, bCfg);

    ctx.save();
    const frameGrad = ctx.createLinearGradient(0, 0, 1000, 1000);
    frameGrad.addColorStop(0, theme.boardOuterBevel);
    frameGrad.addColorStop(0.35, mats.frame);
    frameGrad.addColorStop(0.75, theme.boardInnerShadow);
    frameGrad.addColorStop(1, mats.frame);

    this.roundRect(ctx, 2, 2, 996, 996, 28);
    ctx.fillStyle = frameGrad;
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = theme.boardOuterBevel;
    ctx.stroke();

    this.roundRect(ctx, pad - 5, pad - 5, inner + 10, inner + 10, 14);
    ctx.fillStyle = theme.boardInnerShadow;
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = theme.boardOuterBevel;
    ctx.stroke();

    ctx.fillStyle = mats.surface;
    ctx.fillRect(pad, pad, inner, inner);
    ctx.restore();

    // Synchronize all 4 board corners with the players' Smart Color Palettes!
    const cornerPalettes = [0, 1, 2, 3].map(cIdx => {
      const seat = this.rules.players.find(p => p.cornerIdx === cIdx);
      if (seat && seat.palette) return seat.palette;
      return this.storage.getPlayerPalette(cIdx);
    });

    const cornerOrigins = [
      [0, 0],
      [9, 0],
      [9, 9],
      [0, 9]
    ];

    cornerOrigins.forEach(([c0, r0], cIdx) => {
      const pal = cornerPalettes[cIdx];
      const bx = pad + c0 * cell;
      const by = pad + r0 * cell;
      const bw = 6 * cell;

      const baseGrad = ctx.createRadialGradient(bx + bw * 0.3, by + bw * 0.25, 20, bx + bw * 0.5, by + bw * 0.5, bw * 0.85);
      baseGrad.addColorStop(0, pal.secondary);
      baseGrad.addColorStop(0.55, pal.primary);
      baseGrad.addColorStop(1, pal.dark);
      ctx.fillStyle = baseGrad;
      ctx.fillRect(bx, by, bw, bw);

      ctx.save();
      ctx.strokeStyle = "rgba(255,255,255,0.14)";
      ctx.lineWidth = 3;
      ctx.strokeRect(bx + 4, by + 4, bw - 8, bw - 8);
      ctx.restore();

      ctx.strokeStyle = theme.boardOuterBevel;
      ctx.lineWidth = 3;
      ctx.strokeRect(bx + 1.5, by + 1.5, bw - 3, bw - 3);

      const inset = cell * 0.72;
      this.roundRect(ctx, bx + inset - 3, by + inset - 3, bw - (inset - 3) * 2, bw - (inset - 3) * 2, 26);
      ctx.fillStyle = "rgba(0,0,0,0.35)";
      ctx.fill();

      this.roundRect(ctx, bx + inset, by + inset, bw - inset * 2, bw - inset * 2, 24);
      ctx.fillStyle = theme.yardBoxBg;
      ctx.fill();
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = pal.dark;
      ctx.stroke();

      this.roundRect(ctx, bx + inset + 5, by + inset + 5, bw - (inset + 5) * 2, bw - (inset + 5) * 2, 19);
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = pal.edge || theme.boardOuterBevel;
      ctx.stroke();

      const slots = b.yardSlots[cIdx];
      slots.forEach(s => {
        const outerR = cell * 0.56 * yardSockMul;
        const innerR = cell * 0.39 * yardSockMul;

        ctx.beginPath();
        ctx.arc(s.x, s.y + 2.5, outerR + 1.5, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(0,0,0,0.28)";
        ctx.fill();

        const sockGrad = ctx.createLinearGradient(s.x - 30, s.y - 30, s.x + 30, s.y + 30);
        sockGrad.addColorStop(0, pal.secondary);
        sockGrad.addColorStop(0.5, pal.primary);
        sockGrad.addColorStop(1, pal.dark);

        ctx.beginPath();
        ctx.arc(s.x, s.y, outerR, 0, Math.PI * 2);
        ctx.fillStyle = sockGrad;
        ctx.fill();
        ctx.lineWidth = 3.2;
        ctx.strokeStyle = pal.edge || "#FFFFFF";
        ctx.stroke();

        const wellGrad = ctx.createRadialGradient(s.x, s.y + 4, 2, s.x, s.y, innerR);
        wellGrad.addColorStop(0, pal.dark);
        wellGrad.addColorStop(1, pal.deep || "#0F172A");

        ctx.beginPath();
        ctx.arc(s.x, s.y, innerR, 0, Math.PI * 2);
        ctx.fillStyle = wellGrad;
        ctx.fill();
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = theme.boardOuterBevel;
        ctx.stroke();
      });
    });

    b.trackNodes.forEach(node => {
      const tx = node.x - cell / 2 + cellGap * 0.5;
      const ty = node.y - cell / 2 + cellGap * 0.5;
      const tw = cell - cellGap;
      const th = cell - cellGap;

      let fill = (node.index % 2 === 0) ? mats.surface : mats.surfaceAlt;
      let isColoredStart = node.isStartFor >= 0;

      if (isColoredStart) {
        const pal = cornerPalettes[node.isStartFor];
        const stGrad = ctx.createLinearGradient(tx, ty, tx + tw, ty + th);
        stGrad.addColorStop(0, pal.secondary);
        stGrad.addColorStop(1, pal.primary);
        fill = stGrad;
      } else if (node.isStar) {
        fill = theme.safeTileTint;
      }

      ctx.fillStyle = fill;
      ctx.fillRect(tx, ty, tw, th);

      ctx.fillStyle = "rgba(255,255,255,0.42)";
      ctx.fillRect(tx + 1.5, ty + 1.5, tw - 3, 3.5);
      ctx.fillRect(tx + 1.5, ty + 1.5, 3.5, th - 3);

      ctx.fillStyle = "rgba(0,0,0,0.14)";
      ctx.fillRect(tx + 1.5, ty + th - 5, tw - 3, 3.5);
      ctx.fillRect(tx + tw - 5, ty + 1.5, 3.5, th - 3);

      ctx.lineWidth = 1.8;
      ctx.strokeStyle = theme.tileBorder;
      ctx.strokeRect(tx, ty, tw, th);

      if (isColoredStart || node.isStar) {
        this.drawStarEmblem(
          ctx,
          node.x,
          node.y,
          cell * 0.37,
          isColoredStart ? (cornerPalettes[node.isStartFor].light || "#FFFFFF") : theme.safeStarColor,
          isColoredStart ? cornerPalettes[node.isStartFor].dark : "#78350F"
        );
      }
    });

    b.homeStretches.forEach((stretch, cIdx) => {
      const pal = cornerPalettes[cIdx];
      stretch.forEach((sNode) => {
        const tx = sNode.x - cell / 2 + cellGap * 0.5;
        const ty = sNode.y - cell / 2 + cellGap * 0.5;
        const tw = cell - cellGap;
        const th = cell - cellGap;

        const stGrad = ctx.createLinearGradient(tx, ty, tx + tw, ty + th);
        stGrad.addColorStop(0, pal.secondary);
        stGrad.addColorStop(1, pal.primary);
        ctx.fillStyle = stGrad;
        ctx.fillRect(tx, ty, tw, th);

        ctx.lineWidth = 2.2;
        ctx.strokeStyle = pal.edge || "#FFFFFF";
        ctx.strokeRect(tx + 1.5, ty + 1.5, tw - 3, th - 3);

        ctx.beginPath();
        ctx.arc(sNode.x, sNode.y, cell * 0.16, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255, 251, 235, 0.45)";
        ctx.fill();
      });
    });

    const arrowTurnMap = [
      { idx: 50, angle: 0, pal: cornerPalettes[0] },
      { idx: 11, angle: Math.PI / 2, pal: cornerPalettes[1] },
      { idx: 24, angle: Math.PI, pal: cornerPalettes[2] },
      { idx: 37, angle: -Math.PI / 2, pal: cornerPalettes[3] }
    ];
    arrowTurnMap.forEach(({ idx, angle, pal }) => {
      const n = b.trackNodes[idx];
      ctx.save();
      ctx.translate(n.x, n.y);
      ctx.rotate(angle);
      ctx.fillStyle = pal.primary;
      ctx.strokeStyle = pal.edge || "#FFFFFF";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-16, -9);
      ctx.lineTo(3, -9);
      ctx.lineTo(3, -17);
      ctx.lineTo(19, 0);
      ctx.lineTo(3, 17);
      ctx.lineTo(3, 9);
      ctx.lineTo(-16, 9);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    });

    const cx = 500;
    const cy = 500;
    const cLeft = pad + 6 * cell;
    const cRight = pad + 9 * cell;
    const cTop = pad + 6 * cell;
    const cBot = pad + 9 * cell;

    const triDefs = [
      { pts: [[cLeft, cTop], [cx, cy], [cLeft, cBot]], pal: cornerPalettes[0] },
      { pts: [[cLeft, cTop], [cx, cy], [cRight, cTop]], pal: cornerPalettes[1] },
      { pts: [[cRight, cTop], [cx, cy], [cRight, cBot]], pal: cornerPalettes[2] },
      { pts: [[cLeft, cBot], [cx, cy], [cRight, cBot]], pal: cornerPalettes[3] }
    ];

    triDefs.forEach(({ pts, pal }) => {
      const tGrad = ctx.createLinearGradient(pts[0][0], pts[0][1], cx, cy);
      tGrad.addColorStop(0, pal.secondary);
      tGrad.addColorStop(0.6, pal.primary);
      tGrad.addColorStop(1, pal.dark);

      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      ctx.lineTo(pts[1][0], pts[1][1]);
      ctx.lineTo(pts[2][0], pts[2][1]);
      ctx.closePath();
      ctx.fillStyle = tGrad;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = theme.boardOuterBevel;
      ctx.stroke();
    });

    ctx.strokeStyle = theme.boardOuterBevel;
    ctx.lineWidth = 3.5;
    ctx.strokeRect(cLeft, cTop, 3 * cell, 3 * cell);

    const centerScale = (bCfg.centerScale || 1.0) * (1 + Math.sin(now * 0.004) * 0.04);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(centerScale, centerScale);
    ctx.beginPath();
    ctx.arc(0, 2, 32, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(0, 0, 30, 0, Math.PI * 2);
    ctx.fillStyle = "#0F172A";
    ctx.fill();
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = "#FBBF24";
    ctx.stroke();
    this.drawCrownGlyph(ctx, 0, 0, 16);
    ctx.restore();
  }

  /* --------------------------------------------------------------------------
   * DEDICATED 5-PLAYER PENTAGONAL STAR BOARD RENDERER
   * -------------------------------------------------------------------------- */
  drawFivePlayerPentagonBoard(ctx, theme, now, bCfg = {}) {
    const b = this.rules.board;
    const mats = this.resolveBoardMaterials(theme, bCfg);

    ctx.save();
    const frameGrad = ctx.createRadialGradient(500, 500, 90, 500, 500, 494);
    frameGrad.addColorStop(0, theme.bgGradMid);
    frameGrad.addColorStop(0.86, theme.bgGradBot);
    frameGrad.addColorStop(0.94, mats.frame);
    frameGrad.addColorStop(1, theme.boardOuterBevel);

    ctx.beginPath();
    ctx.arc(500, 500, 492, 0, Math.PI * 2);
    ctx.fillStyle = frameGrad;
    ctx.fill();
    ctx.lineWidth = 6;
    ctx.strokeStyle = theme.boardOuterBevel;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(500, 500, 472, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(255,255,255,0.22)";
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.restore();

    const seatPalettes = [0, 1, 2, 3, 4].map(idx => {
      const p = this.rules.players[idx];
      return (p && p.palette) ? p.palette : this.storage.getPlayerPalette(idx);
    });

    b.yardCenters.forEach((yc, armIdx) => {
      const pal = seatPalettes[armIdx];
      ctx.save();
      ctx.beginPath();
      ctx.arc(yc.x, yc.y + 3, 78, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.fill();

      ctx.beginPath();
      ctx.arc(yc.x, yc.y, 76, 0, Math.PI * 2);
      ctx.fillStyle = pal.primary;
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = theme.boardOuterBevel;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(yc.x, yc.y, 62, 0, Math.PI * 2);
      ctx.fillStyle = theme.yardBoxBg;
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = pal.dark;
      ctx.stroke();

      b.yardSlots[armIdx].forEach(slot => {
        ctx.beginPath();
        ctx.arc(slot.x, slot.y, 21, 0, Math.PI * 2);
        ctx.fillStyle = pal.primary;
        ctx.fill();
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = pal.edge || "#FFFFFF";
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(slot.x, slot.y, 13.5, 0, Math.PI * 2);
        ctx.fillStyle = pal.deep || "#0F172A";
        ctx.fill();
      });
      ctx.restore();
    });

    b.trackNodes.forEach(node => {
      ctx.save();
      ctx.translate(node.x, node.y);
      ctx.rotate(node.angle);

      let fill = (node.index % 2 === 0) ? mats.surface : mats.surfaceAlt;
      if (node.isStartFor >= 0) {
        fill = seatPalettes[node.isStartFor].primary;
      } else if (node.isStar) {
        fill = theme.safeTileTint;
      }

      this.roundRect(ctx, -node.h / 2, -node.w / 2, node.h, node.w, 7);
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = theme.tileBorder;
      ctx.stroke();

      if (node.isStartFor >= 0 || node.isStar) {
        ctx.rotate(-node.angle);
        this.drawStarEmblem(
          ctx,
          0,
          0,
          14,
          node.isStartFor >= 0 ? "#FFFFFF" : theme.safeStarColor,
          "#0F172A"
        );
      }
      ctx.restore();
    });

    b.homeStretches.forEach((stretch, armIdx) => {
      const pal = seatPalettes[armIdx];
      stretch.forEach(sNode => {
        ctx.save();
        ctx.translate(sNode.x, sNode.y);
        ctx.rotate(sNode.angle);
        this.roundRect(ctx, -sNode.h / 2, -sNode.w / 2, sNode.h, sNode.w, 7);
        ctx.fillStyle = pal.primary;
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = pal.edge || "#FFFFFF";
        ctx.stroke();
        ctx.restore();
      });
    });

    const sanctuaryRadius = 138;
    for (let arm = 0; arm < 5; arm++) {
      const pal = seatPalettes[arm];
      const aMid = (b.armAnglesDeg[arm] * Math.PI) / 180;
      const a1 = aMid - Math.PI / 5;
      const a2 = aMid + Math.PI / 5;

      ctx.beginPath();
      ctx.moveTo(500, 500);
      ctx.lineTo(500 + Math.cos(a1) * sanctuaryRadius, 500 + Math.sin(a1) * sanctuaryRadius);
      ctx.lineTo(500 + Math.cos(aMid) * (sanctuaryRadius + 10), 500 + Math.sin(aMid) * (sanctuaryRadius + 10));
      ctx.lineTo(500 + Math.cos(a2) * sanctuaryRadius, 500 + Math.sin(a2) * sanctuaryRadius);
      ctx.closePath();
      ctx.fillStyle = pal.primary;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = theme.boardOuterBevel;
      ctx.stroke();
    }

    ctx.save();
    ctx.translate(500, 500);
    ctx.beginPath();
    ctx.arc(0, 0, 36, 0, Math.PI * 2);
    ctx.fillStyle = "#0F172A";
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = "#FBBF24";
    ctx.stroke();
    this.drawCrownGlyph(ctx, 0, 0, 18);
    ctx.restore();
  }

  /* --------------------------------------------------------------------------
   * LARGE 3D SCULPTED TOKEN & SUPER TOKEN RENDERER (SMART COLOR ADAPTIVE)
   * -------------------------------------------------------------------------- */
  drawToken3D(ctx, item, skinId, now) {
    const { token, player, drawX, drawY, hopZ, scale, selectable, stackCount, isStackTop } = item;
    const pal = player.palette;
    const skin = getTokenSkinById(skinId);
    const tkDash = (this.storage.state.dashboard && this.storage.state.dashboard.token) || {};
    const idleSpd = tkDash.idleSpeed || 1.0;
    const selSpd = tkDash.selectionPulse || 1.0;
    const edgeCol = pal.edge || "#FBBF24";

    const idleBob = selectable
      ? Math.sin(now * 0.009 * selSpd) * 5.5
      : Math.sin(now * 0.003 * idleSpd + token.tokenIndex) * 1.0;
    const liftY = hopZ + (selectable ? Math.max(0, idleBob) : 0);

    ctx.save();
    ctx.translate(drawX, drawY);

    // 1. Selectable Rotating Ring & Smart Color Glow Halo
    if (selectable) {
      const pulse = 1 + Math.sin(now * 0.01 * selSpd) * 0.16;
      ctx.save();
      ctx.scale(pulse, pulse * 0.72);

      ctx.beginPath();
      ctx.arc(0, 4, 34, 0, Math.PI * 2);
      ctx.fillStyle = pal.glow || "rgba(250, 204, 21, 0.35)";
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = edgeCol;
      ctx.stroke();

      ctx.rotate(now * 0.003 * selSpd);
      ctx.setLineDash([10, 6]);
      ctx.beginPath();
      ctx.arc(0, 4, 40, 0, Math.PI * 2);
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();
      ctx.restore();
    }

    // 2. Ground Contact Shadow
    const shadowScale = Math.max(0.55, 1 - liftY / 110) * scale;
    ctx.beginPath();
    ctx.ellipse(0, 8, 16.5 * shadowScale, 7.5 * shadowScale, 0, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0, 0, 0, 0.58)";
    ctx.fill();

    // 3. Apply 3D Elevation & Scale
    ctx.translate(0, -liftY);
    ctx.scale(scale, scale);

    // Smart Color 3D Material Shader Gradient
    const bodyGrad = ctx.createRadialGradient(-6, -21, 2, 0, -14, 26);
    bodyGrad.addColorStop(0, pal.reflection || "#FFFFFF");
    bodyGrad.addColorStop(0.20, pal.light);
    bodyGrad.addColorStop(0.58, pal.primary);
    bodyGrad.addColorStop(1, pal.dark);

    if (skin.shape === "super_blackhole") {
      // Super Token 1: Singularity Vortex Monolith
      ctx.beginPath();
      ctx.ellipse(0, 4, 15, 5.2, 0, 0, Math.PI * 2);
      ctx.fillStyle = edgeCol;
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(-13, 4);
      ctx.lineTo(-9, -15);
      ctx.lineTo(9, -15);
      ctx.lineTo(13, 4);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();

      // Accretion Ring
      ctx.save();
      ctx.translate(0, -21);
      ctx.rotate(-0.28);
      ctx.beginPath();
      ctx.ellipse(0, 0, 19, 6.5, 0, 0, Math.PI * 2);
      ctx.strokeStyle = pal.secondary;
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.restore();

      // Dark Singularity Sphere with Smart Color Rim
      ctx.beginPath();
      ctx.arc(0, -21, 11.5, 0, Math.PI * 2);
      ctx.fillStyle = "#05050B";
      ctx.fill();
      ctx.lineWidth = 2.6;
      ctx.strokeStyle = pal.primary;
      ctx.stroke();
    } else if (skin.shape === "super_ice") {
      // Super Token 2: Cryo Sovereign Glacial Spire
      ctx.beginPath();
      ctx.moveTo(0, -38);
      ctx.lineTo(10, -24);
      ctx.lineTo(16, -28);
      ctx.lineTo(12, -10);
      ctx.lineTo(15, 5);
      ctx.lineTo(-15, 5);
      ctx.lineTo(-12, -10);
      ctx.lineTo(-16, -28);
      ctx.lineTo(-10, -24);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = "#E0F2FE";
      ctx.stroke();

      this.drawStarEmblem(ctx, 0, -15, 6.5, "#FFFFFF", pal.dark);
    } else if (skin.shape === "super_fire") {
      // Super Token 3: Inferno Phoenix Core
      ctx.beginPath();
      ctx.ellipse(0, 5, 15, 5.5, 0, 0, Math.PI * 2);
      ctx.fillStyle = edgeCol;
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(-13, 4);
      ctx.bezierCurveTo(-18, -12, -12, -26, -5, -31);
      ctx.quadraticCurveTo(0, -40, 5, -31);
      ctx.bezierCurveTo(12, -26, 18, -12, 13, 4);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = edgeCol;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, -14, 6.2, 0, Math.PI * 2);
      ctx.fillStyle = "#FEF08A";
      ctx.fill();
    } else if (skin.shape === "super_kick") {
      // Super Token 4: Titan Striker Boot Medallion
      ctx.beginPath();
      ctx.arc(0, -15, 17.5, 0, Math.PI * 2);
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.8;
      ctx.strokeStyle = edgeCol;
      ctx.stroke();

      // Sculpted Golden Boot Relief Emblem
      ctx.fillStyle = "#FEF08A";
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-7, -26);
      ctx.lineTo(2, -26);
      ctx.lineTo(1, -13);
      ctx.lineTo(11, -10);
      ctx.lineTo(11, -5);
      ctx.lineTo(-8, -5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    } else if (skin.shape === "super_devour") {
      // Super Token 5: Abyssal Devourer Monster Crest
      ctx.beginPath();
      ctx.moveTo(-14, -22);
      ctx.lineTo(-19, -35);
      ctx.lineTo(-8, -28);
      ctx.lineTo(8, -28);
      ctx.lineTo(19, -35);
      ctx.lineTo(14, -22);
      ctx.quadraticCurveTo(18, -6, 12, 5);
      ctx.lineTo(-12, 5);
      ctx.quadraticCurveTo(-18, -6, -14, -22);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = edgeCol;
      ctx.stroke();

      // Monster Eyes & Fang Strip
      ctx.fillStyle = "#FEF08A";
      ctx.beginPath();
      ctx.arc(-6, -19, 2.4, 0, Math.PI * 2);
      ctx.arc(6, -19, 2.4, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#090D16";
      ctx.fillRect(-9, -12, 18, 9);
      ctx.fillStyle = "#FFFFFF";
      [-6, 0, 6].forEach(fxp => {
        ctx.beginPath();
        ctx.moveTo(fxp - 2.5, -12);
        ctx.lineTo(fxp, -6);
        ctx.lineTo(fxp + 2.5, -12);
        ctx.fill();
      });
    } else if (skin.shape === "super_thunder") {
      // Super Token 6: Tempest Archon Lightning Piece
      ctx.beginPath();
      ctx.arc(0, -15, 17, 0, Math.PI * 2);
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.6;
      ctx.strokeStyle = "#38BDF8";
      ctx.stroke();

      ctx.fillStyle = "#FEF08A";
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(3, -29);
      ctx.lineTo(-9, -14);
      ctx.lineTo(-1, -14);
      ctx.lineTo(-4, -1);
      ctx.lineTo(9, -17);
      ctx.lineTo(1, -17);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    } else if (skin.shape === "pin") {
      ctx.beginPath();
      ctx.ellipse(0, 5, 11, 4.2, 0, 0, Math.PI * 2);
      ctx.fillStyle = edgeCol;
      ctx.fill();
      ctx.lineWidth = 1.6;
      ctx.strokeStyle = "#0F172A";
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, 7);
      ctx.bezierCurveTo(-19, -9, -21, -30, 0, -35);
      ctx.bezierCurveTo(21, -30, 19, -9, 0, 7);
      ctx.closePath();
      ctx.fillStyle = "#FFFFFF";
      ctx.fill();
      ctx.lineWidth = 2.6;
      ctx.strokeStyle = "#0F172A";
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, 2.5);
      ctx.bezierCurveTo(-14.5, -10, -16.5, -26.5, 0, -31);
      ctx.bezierCurveTo(16.5, -26.5, 14.5, -10, 0, 2.5);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = pal.dark;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, -18.5, 7.2, 0, Math.PI * 2);
      ctx.fillStyle = "#FFFBEB";
      ctx.fill();
      ctx.lineWidth = 1.3;
      ctx.strokeStyle = pal.dark;
      ctx.stroke();
      this.drawStarEmblem(ctx, 0, -18.5, 5.2, pal.primary, pal.dark);
    } else if (skin.shape === "pawn") {
      ctx.beginPath();
      ctx.ellipse(0, 5, 16, 5.8, 0, 0, Math.PI * 2);
      ctx.fillStyle = edgeCol;
      ctx.fill();
      ctx.lineWidth = 2.2;
      ctx.strokeStyle = "#0F172A";
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-13.5, 3.5);
      ctx.quadraticCurveTo(-8.5, -14, -5.5, -19);
      ctx.lineTo(5.5, -19);
      ctx.quadraticCurveTo(8.5, -14, 13.5, 3.5);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();

      ctx.fillStyle = edgeCol;
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 1.4;
      ctx.fillRect(-8, -21, 16, 3.8);
      ctx.strokeRect(-8, -21, 16, 3.8);

      ctx.beginPath();
      ctx.arc(0, -27, 10.5, 0, Math.PI * 2);
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();
    } else if (skin.shape === "obelisk") {
      ctx.beginPath();
      ctx.moveTo(0, -37);
      ctx.lineTo(14.5, -20);
      ctx.lineTo(11.5, 5.5);
      ctx.lineTo(-11.5, 5.5);
      ctx.lineTo(-14.5, -20);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.6;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();

      this.drawStarEmblem(ctx, 0, -15, 6.8, edgeCol, "#0F172A");
    } else if (skin.shape === "shield") {
      ctx.beginPath();
      ctx.arc(0, -14, 17.5, 0, Math.PI * 2);
      ctx.fillStyle = edgeCol;
      ctx.fill();
      ctx.lineWidth = 2.6;
      ctx.strokeStyle = "#0F172A";
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, -14, 13.8, 0, Math.PI * 2);
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();
      this.drawCrownGlyph(ctx, 0, -14, 7.5);
    } else if (skin.shape === "cyber") {
      ctx.beginPath();
      ctx.arc(0, -14, 17.5, 0, Math.PI * 2);
      ctx.fillStyle = "#0F172A";
      ctx.fill();
      ctx.lineWidth = 2.8;
      ctx.strokeStyle = "#22D3EE";
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, -14, 12.5, 0, Math.PI * 2);
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, -14, 5, 0, Math.PI * 2);
      ctx.fillStyle = edgeCol;
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.moveTo(-13.5, 5.5);
      ctx.lineTo(-10, -25);
      ctx.lineTo(10, -25);
      ctx.lineTo(13.5, 5.5);
      ctx.closePath();
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = "#FFFFFF";
      ctx.stroke();

      ctx.fillStyle = edgeCol;
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 1.6;
      ctx.fillRect(-12, -31, 24, 6.5);
      ctx.strokeRect(-12, -31, 24, 6.5);
    }

    // Specular Highlight
    ctx.beginPath();
    ctx.ellipse(-5.5, -25.5, 4.2, 2.2, -0.45, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255, 255, 255, 0.82)";
    ctx.fill();

    if (stackCount > 1 && isStackTop) {
      ctx.save();
      ctx.translate(12, -30);
      ctx.beginPath();
      ctx.arc(0, 0, 8.5, 0, Math.PI * 2);
      ctx.fillStyle = "#0F172A";
      ctx.fill();
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = "#FBBF24";
      ctx.stroke();
      ctx.fillStyle = "#FEF08A";
      ctx.font = "900 10px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(`×${stackCount}`, 0, 0.5);
      ctx.restore();
    }

    if (selectable) {
      const arrowY = -44 - Math.abs(Math.sin(now * 0.009 * selSpd)) * 7;
      ctx.fillStyle = "#FACC15";
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(0, arrowY + 10);
      ctx.lineTo(-9, arrowY - 1);
      ctx.lineTo(9, arrowY - 1);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    ctx.restore();
  }

  updateAndDrawVfx(ctx, theme, now) {
    if (this.storage.state.settings.vfxEnabled && this.storage.state.settings.themeVfxEnabled !== false) {
      const colors = theme.particleColors || ["#FEF08A"];
      this.ambientParticles.forEach((p, idx) => {
        p.x += p.vx + Math.sin(now * 0.001 + p.phase) * 0.22;
        p.y += p.vy;
        if (p.y < 0) p.y = 1000;
        if (p.x < 0) p.x = 1000;
        if (p.x > 1000) p.x = 0;

        ctx.save();
        ctx.globalAlpha = p.alpha * 0.48;
        ctx.fillStyle = colors[idx % colors.length];
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
    }

    for (let i = this.trails.length - 1; i >= 0; i--) {
      const t = this.trails[i];
      t.alpha -= 0.045;
      t.r *= 0.94;
      if (t.alpha <= 0.02) {
        this.trails.splice(i, 1);
        continue;
      }
      ctx.save();
      ctx.globalAlpha = t.alpha;
      ctx.fillStyle = t.color;
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.r += (r.maxR - r.r) * 0.14;
      r.alpha -= 0.04;
      if (r.alpha <= 0.02) {
        this.rings.splice(i, 1);
        continue;
      }
      ctx.save();
      ctx.globalAlpha = r.alpha;
      ctx.strokeStyle = r.color;
      ctx.lineWidth = 4.5;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  updateAndDrawTopParticles(ctx) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += p.gravity;
      p.life -= p.decay;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.y -= 1.25;
      ft.life -= 0.020;
      if (ft.life <= 0) {
        this.floatingTexts.splice(i, 1);
        continue;
      }
      ctx.save();
      ctx.globalAlpha = Math.max(0, ft.life);
      ctx.font = "900 24px Cinzel, Georgia, serif";
      ctx.textAlign = "center";
      ctx.lineWidth = 5;
      ctx.strokeStyle = "#0F172A";
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    }
  }

  drawStarEmblem(ctx, cx, cy, outerR, color, strokeCol = "rgba(0,0,0,0.45)") {
    const innerR = outerR * 0.45;
    ctx.save();
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const r = i % 2 === 0 ? outerR : innerR;
      const a = (Math.PI * i) / 5 - Math.PI / 2;
      const px = cx + Math.cos(a) * r;
      const py = cy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = strokeCol;
    ctx.stroke();
    ctx.restore();
  }

  drawCrownGlyph(ctx, cx, cy, sz) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.beginPath();
    ctx.moveTo(-sz, sz * 0.65);
    ctx.lineTo(-sz * 0.85, -sz * 0.55);
    ctx.lineTo(-sz * 0.35, sz * 0.05);
    ctx.lineTo(0, -sz * 0.85);
    ctx.lineTo(sz * 0.35, sz * 0.05);
    ctx.lineTo(sz * 0.85, -sz * 0.55);
    ctx.lineTo(sz, sz * 0.65);
    ctx.closePath();
    ctx.fillStyle = "#FBBF24";
    ctx.fill();
    ctx.lineWidth = 1.8;
    ctx.strokeStyle = "#FEF08A";
    ctx.stroke();
    ctx.restore();
  }

  roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
}
