/* ============================================================================
 * MODULE 02: CUSTOM SVG ICON SYSTEM, AVATARS, 3D DICE, CLASSIC TOKENS
 *            & 6 ORIGINAL SUPER TOKENS (BLACK HOLE, ICE, FIRE, KICK, DEVOUR, THUNDER)
 * Strictly Zero Emojis — 100% Custom Vector & 3D Shader Artwork
 * ============================================================================ */

const CAPO_ICONS = {
  home: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><defs><linearGradient id="ic_gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FFF59D"/><stop offset="50%" stop-color="#FBBF24"/><stop offset="100%" stop-color="#B45309"/></linearGradient></defs><path d="M3 10.5L12 3l9 7.5v9a1.5 1.5 0 01-1.5 1.5h-5v-6h-5v6h-5A1.5 1.5 0 013 19.5v-9z" fill="url(#ic_gold)" stroke="#FFFBEB" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
  play: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M6 4.2l14.5 7.8L6 19.8V4.2z" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>`,
  pause: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><rect x="5.5" y="4" width="4.8" height="16" rx="1.6" fill="currentColor"/><rect x="13.7" y="4" width="4.8" height="16" rx="1.6" fill="currentColor"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M12 15.5A3.5 3.5 0 1012 8.5a3.5 3.5 0 000 7z" stroke="currentColor" stroke-width="2.2"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9c.26.6.85 1 1.51 1H21a2 2 0 010 4h-.09c-.66 0-1.25.4-1.51 1z" stroke="currentColor" stroke-width="1.9"/></svg>`,
  dashboard: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><rect x="3" y="3" width="7.5" height="7.5" rx="2" fill="currentColor"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2" stroke="currentColor" stroke-width="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2" stroke="currentColor" stroke-width="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2" fill="currentColor"/></svg>`,
  sound: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M11 5L6 9H2v6h4l5 4V5z" fill="currentColor"/><path d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>`,
  mute: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M11 5L6 9H2v6h4l5 4V5z" fill="currentColor"/><path d="M22 9l-6 6M16 9l6 6" stroke="#EF4444" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  music: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M9 18V5l12-2v13" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6" cy="18" r="3" fill="currentColor"/><circle cx="18" cy="16" r="3" fill="currentColor"/></svg>`,
  vibration: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><rect x="7" y="4" width="10" height="16" rx="2" stroke="currentColor" stroke-width="2"/><path d="M3 8v8M21 8v8M1 10v4M23 10v4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>`,
  inventory: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M4 8l8-5 8 5v8l-8 5-8-5V8z" stroke="currentColor" stroke-width="2" fill="rgba(245,158,11,0.25)"/><path d="M4 8l8 5 8-5M12 13v8" stroke="currentColor" stroke-width="2"/></svg>`,
  dice: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><rect x="3" y="3" width="18" height="18" rx="4" stroke="currentColor" stroke-width="2.2" fill="rgba(255,255,255,0.12)"/><circle cx="8" cy="8" r="1.7" fill="currentColor"/><circle cx="16" cy="8" r="1.7" fill="currentColor"/><circle cx="12" cy="12" r="1.7" fill="currentColor"/><circle cx="8" cy="16" r="1.7" fill="currentColor"/><circle cx="16" cy="16" r="1.7" fill="currentColor"/></svg>`,
  theme: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M12 2a10 10 0 100 20 2.5 2.5 0 002.5-2.5c0-.6-.2-1.2-.6-1.6-.4-.4-.6-1-.6-1.6A2.5 2.5 0 0115.8 14H18a4 4 0 004-4c0-4.4-4.5-8-10-8z" stroke="currentColor" stroke-width="2"/><circle cx="7.5" cy="10.5" r="1.6" fill="#EF4444"/><circle cx="10.5" cy="7" r="1.6" fill="#3B82F6"/><circle cx="15" cy="7.5" r="1.6" fill="#10B981"/><circle cx="7.5" cy="14.5" r="1.6" fill="#F59E0B"/></svg>`,
  token: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><circle cx="12" cy="7" r="4.2" fill="currentColor"/><path d="M6.5 20c0-3.8 2.4-6.8 5.5-6.8s5.5 3 5.5 6.8h-11z" fill="currentColor"/><rect x="5" y="19.5" width="14" height="2.5" rx="1" fill="currentColor"/></svg>`,
  avatar: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><circle cx="12" cy="8" r="4" stroke="currentColor" stroke-width="2"/><path d="M4 20c1.5-4 4.5-6 8-6s6.5 2 8 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`,
  back: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  close: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>`,
  confirm: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  next: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  prev: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  info: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><circle cx="12" cy="12" r="9.5" stroke="currentColor" stroke-width="2.2"/><path d="M12 11v5M12 8h.01" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>`,
  rules: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M4 4.5A2.5 2.5 0 016.5 2H19v18H6.5A2.5 2.5 0 004 22V4.5z" stroke="currentColor" stroke-width="2"/><path d="M8 7h7M8 11h7M8 15h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`,
  crown: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><defs><linearGradient id="cr_g" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FFF59D"/><stop offset="50%" stop-color="#FBBF24"/><stop offset="100%" stop-color="#B45309"/></linearGradient></defs><path d="M2.5 18L4.5 7l5 4.5L12 4l2.5 7.5L19.5 7l2 11h-19z" fill="url(#cr_g)" stroke="#FEF08A" stroke-width="1.4" stroke-linejoin="round"/><rect x="3" y="19" width="18" height="2.4" rx="1" fill="#F59E0B"/></svg>`,
  trophy: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M7 4h10v6a5 5 0 01-10 0V4z" fill="#FBBF24" stroke="#FEF08A" stroke-width="1.8"/><path d="M7 6H4v2a3 3 0 003 3M17 6h3v2a3 3 0 01-3 3M12 15v4M8 20h8" stroke="#FBBF24" stroke-width="2.2" stroke-linecap="round"/></svg>`,
  star: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9L12 2.5z" fill="currentColor" stroke="rgba(255,255,255,0.7)" stroke-width="1.3"/></svg>`,
  shield: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M12 2.5l8 3.5v6c0 5.2-3.4 9.3-8 10.5-4.6-1.2-8-5.3-8-10.5V6l8-3.5z" stroke="currentColor" stroke-width="2" fill="rgba(255,255,255,0.14)"/></svg>`,
  anchor: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="2" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="3.2" fill="currentColor"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`,
  restart: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M3 12a9 9 0 109-9 9.75 9.75 0 00-6.74 2.74L3 8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 3v5h5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  users: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><circle cx="9" cy="8" r="3.5" stroke="currentColor" stroke-width="2"/><path d="M2.5 19c1-3.2 3.5-5 6.5-5s5.5 1.8 6.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="16.5" cy="9" r="2.8" stroke="currentColor" stroke-width="1.8"/><path d="M15.5 14.3c2.4.3 4.5 1.8 5.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`,
  speed: `<svg viewBox="0 0 24 24" fill="none" class="w-full h-full"><path d="M13 3L4 14h7l-1 7 9-11h-7l1-7z" fill="currentColor"/></svg>`
};

function getIconSvg(name, extraClass = "w-5 h-5") {
  const raw = CAPO_ICONS[name] || CAPO_ICONS.star;
  return `<span class="inline-flex items-center justify-center ${extraClass}">${raw}</span>`;
}

/* ============================================================================
 * 8 CUSTOM VECTOR ILLUSTRATED AVATARS (ALL UNLOCKED)
 * ============================================================================ */
const CAPO_AVATARS = [
  {
    id: "sovereign_king",
    name: "King Aurelius",
    title: "High Sovereign",
    bg1: "#1E3A8A",
    bg2: "#090D16",
    accent: "#FBBF24",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <defs>
        <radialGradient id="av_k_bg" cx="50%" cy="30%" r="70%"><stop offset="0%" stop-color="#1D4ED8"/><stop offset="100%" stop-color="#090D16"/></radialGradient>
        <linearGradient id="av_k_cr" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#FEF08A"/><stop offset="50%" stop-color="#F59E0B"/><stop offset="100%" stop-color="#78350F"/></linearGradient>
        <linearGradient id="av1_armor" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#991B1B"/><stop offset="100%" stop-color="#450A0A"/></linearGradient>
      </defs>
      <rect x="2" y="2" width="76" height="76" rx="16" fill="url(#av_k_bg)" stroke="url(#av_k_cr)" stroke-width="3.5"/>
      <path d="M10 74 C12 54, 24 48, 40 48 C56 48, 68 54, 70 74 Z" fill="url(#av1_armor)" stroke="url(#av_k_cr)" stroke-width="2"/>
      <path d="M24 50 L40 66 L56 50" fill="none" stroke="url(#av_k_cr)" stroke-width="2.5"/>
      <path d="M27 30 C27 20, 53 20, 53 30 L52 44 C52 52, 45 57, 40 57 C35 57, 28 52, 28 44 Z" fill="#EAB308" opacity="0.2"/>
      <path d="M28 29 C28 21, 52 21, 52 29 L51 43 C51 50, 45 55, 40 55 C35 55, 29 50, 29 43 Z" fill="#FDE68A" stroke="#78350F" stroke-width="1.2"/>
      <path d="M28 39 C28 49, 34 56, 40 56 C46 56, 52 49, 52 39 C48 42, 44 43, 40 43 C36 43, 32 42, 28 39 Z" fill="#451A03"/>
      <path d="M33 45 H47" stroke="#D97706" stroke-width="1.8" stroke-linecap="round"/>
      <path d="M31 33 L37 34 M49 33 L43 34" stroke="#451A03" stroke-width="2.2" stroke-linecap="round"/>
      <circle cx="34.5" cy="36" r="1.8" fill="#0F172A"/><circle cx="45.5" cy="36" r="1.8" fill="#0F172A"/>
      <path d="M22 28 L25 12 L33 21 L40 9 L47 21 L55 12 L58 28 Z" fill="url(#av_k_cr)" stroke="#FFFBEB" stroke-width="1.4" stroke-linejoin="round"/>
      <rect x="22" y="26" width="36" height="4.5" rx="1.5" fill="url(#av_k_cr)" stroke="#78350F" stroke-width="1"/>
      <polygon points="40,15 42.5,20 40,24 37.5,20" fill="#DC2626"/>
    </svg>`
  },
  {
    id: "empress_vela",
    name: "Empress Vela",
    title: "Crown Regent",
    bg1: "#881337",
    bg2: "#090D16",
    accent: "#F43F5E",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <defs>
        <radialGradient id="av_e_bg" cx="50%" cy="30%" r="70%"><stop offset="0%" stop-color="#BE123C"/><stop offset="100%" stop-color="#090D16"/></radialGradient>
        <linearGradient id="av_e_cr" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#FEF08A"/><stop offset="50%" stop-color="#F59E0B"/><stop offset="100%" stop-color="#78350F"/></linearGradient>
      </defs>
      <rect x="2" y="2" width="76" height="76" rx="16" fill="url(#av_e_bg)" stroke="url(#av_e_cr)" stroke-width="3.5"/>
      <path d="M18 36 C18 18, 62 18, 62 36 C62 50, 58 62, 54 70 H26 C22 62, 18 50, 18 36 Z" fill="#1E1B4B"/>
      <path d="M12 74 C15 55, 26 49, 40 49 C54 49, 65 55, 68 74 Z" fill="#881337" stroke="url(#av_e_cr)" stroke-width="2"/>
      <polygon points="40,51 45,59 40,67 35,59" fill="url(#av_e_cr)"/>
      <path d="M29 30 C29 22, 51 22, 51 30 L50 42 C50 49, 45 53, 40 53 C35 53, 30 49, 30 42 Z" fill="#FDE68A" stroke="#78350F" stroke-width="1.2"/>
      <path d="M31 34 Q34.5 32 37.5 34 M42.5 34 Q45.5 32 49 34" stroke="#31102F" stroke-width="1.8" fill="none"/>
      <circle cx="34.5" cy="36.5" r="1.9" fill="#0F172A"/><circle cx="45.5" cy="36.5" r="1.9" fill="#0F172A"/>
      <path d="M36.5 45 Q40 47.5 43.5 45" stroke="#BE123C" stroke-width="2.2" fill="none" stroke-linecap="round"/>
      <path d="M24 27 L31 15 L40 9 L49 15 L56 27 Z" fill="url(#av_e_cr)" stroke="#FFFBEB" stroke-width="1.3"/>
      <polygon points="40,13 43,20 40,25 37,20" fill="#0284C7"/>
    </svg>`
  },
  {
    id: "emerald_warden",
    name: "Vanguard Kael",
    title: "Emerald Knight",
    bg1: "#065F46",
    bg2: "#090D16",
    accent: "#10B981",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <defs>
        <radialGradient id="av_d_bg" cx="50%" cy="30%" r="70%"><stop offset="0%" stop-color="#059669"/><stop offset="100%" stop-color="#052E16"/></radialGradient>
        <linearGradient id="av3_steel" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#ECFDF5"/><stop offset="50%" stop-color="#34D399"/><stop offset="100%" stop-color="#064E3B"/></linearGradient>
      </defs>
      <rect x="2" y="2" width="76" height="76" rx="16" fill="url(#av_d_bg)" stroke="#FBBF24" stroke-width="3.5"/>
      <path d="M11 74 C14 54, 25 48, 40 48 C55 48, 66 54, 69 74 Z" fill="#064E3B" stroke="#FBBF24" stroke-width="2"/>
      <path d="M24 26 C24 14, 56 14, 56 26 L55 48 L40 57 L25 48 Z" fill="url(#av3_steel)" stroke="#FEF08A" stroke-width="1.8"/>
      <path d="M40 15 V56" stroke="#FBBF24" stroke-width="2.5"/>
      <polygon points="28,34 38,37 28,39" fill="#FEF08A"/>
      <polygon points="52,34 42,37 52,39" fill="#FEF08A"/>
      <path d="M26 19 L33 10 L40 16 L47 10 L54 19" fill="none" stroke="#FBBF24" stroke-width="2.5" stroke-linecap="round"/>
    </svg>`
  },
  {
    id: "pharaoh_kha",
    name: "Pharaoh Kha-Ra",
    title: "Golden Dynasty",
    bg1: "#B45309",
    bg2: "#090D16",
    accent: "#FACC15",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <defs>
        <radialGradient id="av_f_bg" cx="50%" cy="30%" r="70%"><stop offset="0%" stop-color="#D97706"/><stop offset="100%" stop-color="#1C1917"/></radialGradient>
        <linearGradient id="av4_gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#FEF08A"/><stop offset="50%" stop-color="#F59E0B"/><stop offset="100%" stop-color="#78350F"/></linearGradient>
      </defs>
      <rect x="2" y="2" width="76" height="76" rx="16" fill="url(#av_f_bg)" stroke="url(#av4_gold)" stroke-width="3.5"/>
      <path d="M14 58 L22 16 H58 L66 58 L54 62 L40 52 L26 62 Z" fill="url(#av4_gold)" stroke="#1D4ED8" stroke-width="2.8"/>
      <path d="M12 74 C16 58, 26 52, 40 52 C54 52, 64 58, 68 74 Z" fill="#1E3A8A" stroke="url(#av4_gold)" stroke-width="2.2"/>
      <path d="M29 29 H51 L49 45 C49 50, 44 54, 40 54 C36 54, 31 50, 31 45 Z" fill="#D97706" stroke="#451A03" stroke-width="1.2"/>
      <circle cx="35" cy="36" r="1.9" fill="#FEF08A"/><circle cx="45" cy="36" r="1.9" fill="#FEF08A"/>
      <rect x="38" y="48" width="4" height="10" rx="1.5" fill="url(#av4_gold)" stroke="#451A03" stroke-width="1"/>
      <circle cx="40" cy="19" r="4.2" fill="#DC2626" stroke="#FEF08A" stroke-width="1.5"/>
    </svg>`
  },
  {
    id: "astral_warden",
    name: "Archon Orion",
    title: "Astral Sovereign",
    bg1: "#4C1D95",
    bg2: "#090D16",
    accent: "#C084FC",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <defs>
        <radialGradient id="av5_bg" cx="50%" cy="30%" r="70%"><stop offset="0%" stop-color="#7C3AED"/><stop offset="100%" stop-color="#090D16"/></radialGradient>
      </defs>
      <rect x="2" y="2" width="76" height="76" rx="16" fill="url(#av5_bg)" stroke="#E9D5FF" stroke-width="3.5"/>
      <path d="M12 74 C15 54, 26 48, 40 48 C54 48, 65 54, 68 74 Z" fill="#3B0764" stroke="#FBBF24" stroke-width="2"/>
      <path d="M23 30 C23 15, 57 15, 57 30 L54 49 L40 57 L26 49 Z" fill="#1E1B4B" stroke="#C084FC" stroke-width="2"/>
      <polygon points="29,34 38,37 29,40" fill="#38BDF8"/>
      <polygon points="51,34 42,37 51,40" fill="#38BDF8"/>
      <polygon points="40,12 44,23 55,23 46,29 49,40 40,33 31,40 34,29 25,23 36,23" fill="#FACC15" opacity="0.9"/>
    </svg>`
  },
  {
    id: "lord_drago",
    name: "Warlord Ignis",
    title: "Inferno Commander",
    bg1: "#991B1B",
    bg2: "#090D16",
    accent: "#FB923C",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <rect x="2" y="2" width="76" height="76" rx="16" fill="#450A0A" stroke="#F97316" stroke-width="3.5"/>
      <path d="M12 74 C15 54, 26 48, 40 48 C54 48, 65 54, 68 74 Z" fill="#18181B" stroke="#FBBF24" stroke-width="2"/>
      <path d="M18 20 L28 26 L40 16 L52 26 L62 20 L56 47 L40 56 L24 47 Z" fill="#27272A" stroke="#F97316" stroke-width="2"/>
      <polygon points="29,35 38,38 29,41" fill="#FDE047"/>
      <polygon points="51,35 42,38 51,41" fill="#FDE047"/>
    </svg>`
  },
  {
    id: "lady_frost",
    name: "Valeria Frost",
    title: "Glacier Sentinel",
    bg1: "#0284C7",
    bg2: "#090D16",
    accent: "#7DD3FC",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <rect x="2" y="2" width="76" height="76" rx="16" fill="#0C4A6E" stroke="#7DD3FC" stroke-width="3.5"/>
      <path d="M12 74 C15 54, 26 48, 40 48 C54 48, 65 54, 68 74 Z" fill="#0369A1" stroke="#E0F2FE" stroke-width="2"/>
      <path d="M24 27 C24 16, 56 16, 56 27 L53 48 L40 56 L27 48 Z" fill="#E0F2FE" stroke="#38BDF8" stroke-width="2"/>
      <polygon points="29,35 38,37 29,40" fill="#0284C7"/>
      <polygon points="51,35 42,37 51,40" fill="#0284C7"/>
      <polygon points="40,9 46,24 34,24" fill="#38BDF8" stroke="#FFFFFF" stroke-width="1.2"/>
    </svg>`
  },
  {
    id: "cyber_valkyrie",
    name: "Nexus Striker",
    title: "Cyber Tactical",
    bg1: "#1E1B4B",
    bg2: "#090D16",
    accent: "#22D3EE",
    svg: `<svg viewBox="0 0 80 80" class="w-full h-full">
      <rect x="2" y="2" width="76" height="76" rx="16" fill="#0F172A" stroke="#22D3EE" stroke-width="3.5"/>
      <path d="M12 74 L18 52 H62 L68 74 Z" fill="#1E293B" stroke="#E879F9" stroke-width="2"/>
      <rect x="24" y="19" width="32" height="34" rx="10" fill="#334155" stroke="#22D3EE" stroke-width="2"/>
      <rect x="27" y="30" width="26" height="9" rx="4" fill="#06B6D4"/>
      <path d="M30 33 H44" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"/>
    </svg>`
  }
];

function getAvatarById(id) {
  return CAPO_AVATARS.find(a => a.id === id) || CAPO_AVATARS[0];
}

/* ============================================================================
 * 8 CUSTOM 3D-SCULPTED DICE SKINS (DEEP BEVELS, RECESSED WELLS & GLOSS)
 * ============================================================================ */
const CAPO_DICE_SKINS = [
  {
    id: "royal_gold",
    name: "Capo Imperial Gold",
    subtitle: "Ivory Enamel & Burnished Gold Trim",
    outerRim: "#F59E0B",
    outerDark: "#78350F",
    faceGradTop: "#FFFFFF",
    faceGradBot: "#E2E8F0",
    innerBevel: "#FBBF24",
    pipColor: "#0F172A",
    pipOneColor: "#DC2626",
    pipGlow: "#F59E0B",
    styleType: "royal",
    numberMode: false
  },
  {
    id: "inferno_dragon",
    name: "Dragonfire Obsidian",
    subtitle: "Molten Magma Scales & Carvings",
    outerRim: "#EA580C",
    outerDark: "#450A0A",
    faceGradTop: "#991B1B",
    faceGradBot: "#18181B",
    innerBevel: "#F97316",
    pipColor: "#FDE047",
    pipOneColor: "#FB923C",
    pipGlow: "#EF4444",
    styleType: "fire",
    numberMode: true
  },
  {
    id: "glacier_frost",
    name: "Frostbound Crystal",
    subtitle: "Arctic Diamond & Ice Filigree",
    outerRim: "#38BDF8",
    outerDark: "#0369A1",
    faceGradTop: "#F0F9FF",
    faceGradBot: "#7DD3FC",
    innerBevel: "#E0F2FE",
    pipColor: "#0C4A6E",
    pipOneColor: "#0284C7",
    pipGlow: "#38BDF8",
    styleType: "ice",
    numberMode: false
  },
  {
    id: "pharaoh_relic",
    name: "Scarab Sun Relic",
    subtitle: "Ancient Gold & Lapis Inlays",
    outerRim: "#FACC15",
    outerDark: "#713F12",
    faceGradTop: "#D97706",
    faceGradBot: "#451A03",
    innerBevel: "#38BDF8",
    pipColor: "#FEF9C3",
    pipOneColor: "#38BDF8",
    pipGlow: "#FACC15",
    styleType: "ancient",
    numberMode: true
  },
  {
    id: "cyber_neon",
    name: "Cyber Matrix Core",
    subtitle: "Stealth Carbon & Laser Neon",
    outerRim: "#06B6D4",
    outerDark: "#0F172A",
    faceGradTop: "#1E293B",
    faceGradBot: "#090D16",
    innerBevel: "#EC4899",
    pipColor: "#22D3EE",
    pipOneColor: "#F472B6",
    pipGlow: "#EC4899",
    styleType: "cyber",
    numberMode: false
  },
  {
    id: "emerald_jungle",
    name: "Jade Temple Stone",
    subtitle: "Imperial Jade & Amber Filigree",
    outerRim: "#10B981",
    outerDark: "#064E3B",
    faceGradTop: "#059669",
    faceGradBot: "#022C22",
    innerBevel: "#FBBF24",
    pipColor: "#FEF08A",
    pipOneColor: "#F59E0B",
    pipGlow: "#34D399",
    styleType: "jungle",
    numberMode: false
  },
  {
    id: "astral_nebula",
    name: "Cosmic Starlight",
    subtitle: "Deep Nebula & Supernova Pips",
    outerRim: "#A855F7",
    outerDark: "#3B0764",
    faceGradTop: "#581C87",
    faceGradBot: "#0F0720",
    innerBevel: "#E879F9",
    pipColor: "#FAF5FF",
    pipOneColor: "#FDE047",
    pipGlow: "#C084FC",
    styleType: "space",
    numberMode: true
  },
  {
    id: "crimson_velvet",
    name: "Sovereign Ruby",
    subtitle: "Faceted Ruby & Platinum Trim",
    outerRim: "#F8FAFC",
    outerDark: "#475569",
    faceGradTop: "#EF4444",
    faceGradBot: "#7F1D1D",
    innerBevel: "#FCA5A5",
    pipColor: "#FFFFFF",
    pipOneColor: "#FEF08A",
    pipGlow: "#F87171",
    styleType: "ruby",
    numberMode: false
  }
];

function getDiceSkinById(id) {
  return CAPO_DICE_SKINS.find(d => d.id === id) || CAPO_DICE_SKINS[0];
}

function renderDiceSvg(skinId, faceVal = 6, sizeClass = "w-16 h-16") {
  const skin = getDiceSkinById(skinId);
  const uid = `d_${skin.id}_${faceVal}_${Math.floor(Math.random() * 99999)}`;
  const pipCoords = {
    1: [[50, 50]],
    2: [[30, 30], [70, 70]],
    3: [[28, 28], [50, 50], [72, 72]],
    4: [[30, 30], [70, 30], [30, 70], [70, 70]],
    5: [[28, 28], [72, 28], [50, 50], [28, 72], [72, 72]],
    6: [[30, 25], [70, 25], [30, 50], [70, 50], [30, 75], [70, 75]]
  };
  const coords = pipCoords[faceVal] || pipCoords[6];

  let centerContent = "";
  if (skin.numberMode) {
    centerContent = `
      <text x="50" y="68" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-weight="900" font-size="48" fill="${skin.pipColor}" stroke="${skin.outerDark}" stroke-width="2" filter="drop-shadow(0px 3px 4px rgba(0,0,0,0.6))">${faceVal}</text>
    `;
  } else {
    centerContent = coords.map(([cx, cy]) => {
      const r = faceVal === 1 ? 12.5 : 7.8;
      const pCol = faceVal === 1 ? (skin.pipOneColor || skin.pipColor) : skin.pipColor;
      return `
        <circle cx="${cx}" cy="${cy - 1.2}" r="${r + 1.4}" fill="rgba(0,0,0,0.35)"/>
        <circle cx="${cx}" cy="${cy + 1.2}" r="${r + 1.2}" fill="rgba(255,255,255,0.4)"/>
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="${pCol}" stroke="${skin.outerDark}" stroke-width="1.1"/>
        <circle cx="${cx - r * 0.3}" cy="${cy - r * 0.3}" r="${r * 0.32}" fill="rgba(255,255,255,0.75)"/>
      `;
    }).join("");
  }

  const studs = [[13, 13], [87, 13], [13, 87], [87, 87]].map(([rx, ry]) =>
    `<circle cx="${rx}" cy="${ry}" r="3" fill="${skin.innerBevel}" stroke="${skin.outerDark}" stroke-width="0.9"/>`
  ).join("");

  return `<svg viewBox="0 0 100 100" class="${sizeClass} select-none">
    <defs>
      <linearGradient id="${uid}_rim" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${skin.innerBevel}"/>
        <stop offset="45%" stop-color="${skin.outerRim}"/>
        <stop offset="100%" stop-color="${skin.outerDark}"/>
      </linearGradient>
      <radialGradient id="${uid}_face" cx="35%" cy="28%" r="75%">
        <stop offset="0%" stop-color="${skin.faceGradTop}"/>
        <stop offset="100%" stop-color="${skin.faceGradBot}"/>
      </radialGradient>
    </defs>
    <rect x="4" y="8" width="92" height="90" rx="22" fill="rgba(0,0,0,0.65)"/>
    <rect x="4" y="5" width="92" height="91" rx="22" fill="${skin.outerDark}"/>
    <rect x="4" y="2" width="92" height="89" rx="21" fill="url(#${uid}_rim)" stroke="#FFFFFF" stroke-opacity="0.65" stroke-width="1.8"/>
    <rect x="12" y="10" width="76" height="74" rx="15" fill="url(#${uid}_face)" stroke="${skin.innerBevel}" stroke-width="2"/>
    <path d="M16 22 C30 13, 70 13, 84 22 C76 15, 24 15, 16 22 Z" fill="rgba(255,255,255,0.55)"/>
    ${studs}
    ${centerContent}
  </svg>`;
}

/* ============================================================================
 * 12 SCULPTED 3D TOKEN SKINS:
 *  - 6 SUPER TOKENS (WITH CAPTURE-EXCLUSIVE CINEMATIC ABILITIES)
 *  - 6 CLASSIC ROYAL TOKENS
 * All 100% Unlocked from the Beginning
 * ============================================================================ */
const CAPO_TOKEN_SKINS = [
  {
    id: "super_blackhole",
    name: "Singularity Vortex",
    subtitle: "Super Token • Event Horizon Capture",
    shape: "super_blackhole",
    isSuper: true,
    superAbility: "blackhole",
    abilityName: "Black Hole Singularity",
    abilityDesc: "On Capture: Spawns a gravitational black hole that distorts space, pulls the enemy token inward, and collapses."
  },
  {
    id: "super_ice",
    name: "Cryo Sovereign",
    subtitle: "Super Token • Absolute Zero Shatter",
    shape: "super_ice",
    isSuper: true,
    superAbility: "ice",
    abilityName: "Glacial Freeze & Shatter",
    abilityDesc: "On Capture: Encases the enemy token in solid frost crystals, pauses dramatically, then shatters it into ice shards."
  },
  {
    id: "super_fire",
    name: "Inferno Phoenix",
    subtitle: "Super Token • Hellfire Incineration",
    shape: "super_fire",
    isSuper: true,
    superAbility: "fire",
    abilityName: "Solar Flame Vortex",
    abilityDesc: "On Capture: Surrounds the target in a raging fire pillar with rising sparks and finishes with a controlled fire burst."
  },
  {
    id: "super_kick",
    name: "Titan Striker",
    subtitle: "Super Token • 3D Armored Boot Kick",
    shape: "super_kick",
    isSuper: true,
    superAbility: "kick",
    abilityName: "Sovereign Striker Kick",
    abilityDesc: "On Capture: Materializes a custom 3D armored golden boot that kicks the captured token flying back to its home yard."
  },
  {
    id: "super_devour",
    name: "Abyssal Devourer",
    subtitle: "Super Token • Fanged Monster Bite",
    shape: "super_devour",
    isSuper: true,
    superAbility: "devour",
    abilityName: "Leviathan Devour",
    abilityDesc: "On Capture: Custom-sculpted monster jaws open wide, pull the enemy token inside, and chomp shut with impact shockwaves."
  },
  {
    id: "super_thunder",
    name: "Tempest Archon",
    subtitle: "Super Token • Plasma Lightning Strike",
    shape: "super_thunder",
    isSuper: true,
    superAbility: "thunder",
    abilityName: "Orbital Thunder Strike",
    abilityDesc: "On Capture: Calls down a high-voltage plasma lightning bolt that blasts the enemy token with electric arcs."
  },
  {
    id: "capo_pin",
    name: "Capo Heraldic Pin",
    subtitle: "Classic • Thick Ivory-Cased 3D Royal Pin",
    shape: "pin",
    isSuper: false,
    superAbility: null,
    abilityName: "Classic Royal Impact",
    abilityDesc: "Classic sculpted Ludo Capo pin with clean royal impact burst."
  },
  {
    id: "royal_pawn",
    name: "Imperial Crown Pawn",
    subtitle: "Classic • Sculpted Sovereign Tiered Pawn",
    shape: "pawn",
    isSuper: false,
    superAbility: null,
    abilityName: "Classic Royal Impact",
    abilityDesc: "Tiered sovereign chess-inspired pawn with burnished gold collar."
  },
  {
    id: "crystal_obelisk",
    name: "Arcane Spire",
    subtitle: "Classic • Faceted Crystal Obelisk Monolith",
    shape: "obelisk",
    isSuper: false,
    superAbility: null,
    abilityName: "Classic Royal Impact",
    abilityDesc: "Faceted geometric crystal monolith with glowing inner core."
  },
  {
    id: "dragon_medallion",
    name: "Dragon Crest Shield",
    subtitle: "Classic • Heavy Gold-Beveled War Medallion",
    shape: "shield",
    isSuper: false,
    superAbility: null,
    abilityName: "Classic Royal Impact",
    abilityDesc: "Armored heraldic war shield with gold bevels."
  },
  {
    id: "cyber_thruster",
    name: "Neon Hover Core",
    subtitle: "Classic • Concentric Plasma Ring Disc",
    shape: "cyber",
    isSuper: false,
    superAbility: null,
    abilityName: "Classic Royal Impact",
    abilityDesc: "Futuristic concentric hover disc with plasma core."
  },
  {
    id: "royal_chalice",
    name: "Sovereign Citadel",
    subtitle: "Classic • Crowned Battlement Tower Piece",
    shape: "tower",
    isSuper: false,
    superAbility: null,
    abilityName: "Classic Royal Impact",
    abilityDesc: "Fortified citadel rook piece with golden battlements."
  }
];

function getTokenSkinById(id) {
  return CAPO_TOKEN_SKINS.find(t => t.id === id) || CAPO_TOKEN_SKINS[0];
}

function renderTokenPreviewSvg(skinId, paletteOrIndex = 0, sizeClass = "w-14 h-14") {
  const skin = getTokenSkinById(skinId);
  const pal = (paletteOrIndex && typeof paletteOrIndex === "object" && paletteOrIndex.primary)
    ? paletteOrIndex
    : LUDO_CAPO_CONFIG.playerPalettes[(typeof paletteOrIndex === "number" ? paletteOrIndex : 0) % LUDO_CAPO_CONFIG.playerPalettes.length];
  const uid = `tk_${skin.id}_${Math.floor(Math.random() * 99999)}`;
  const edgeCol = pal.edge || "#FEF08A";

  let bodyMarkup = "";
  if (skin.shape === "super_blackhole") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="23" ry="7" fill="rgba(0,0,0,0.65)"/>
      <ellipse cx="40" cy="40" rx="29" ry="11" transform="rotate(-18 40 40)" fill="none" stroke="${pal.secondary}" stroke-width="3.5" stroke-dasharray="10 4"/>
      <ellipse cx="40" cy="40" rx="24" ry="8" transform="rotate(18 40 40)" fill="none" stroke="${edgeCol}" stroke-width="2"/>
      <path d="M22 65 L29 46 H51 L58 65 Z" fill="url(#${uid}_g)" stroke="${edgeCol}" stroke-width="2"/>
      <circle cx="40" cy="34" r="17" fill="#05050A" stroke="${pal.primary}" stroke-width="3.5"/>
      <circle cx="40" cy="34" r="11" fill="#000000" stroke="#A855F7" stroke-width="1.8" stroke-dasharray="5 3"/>
      <circle cx="34" cy="28" r="3.5" fill="rgba(255,255,255,0.85)"/>
    `;
  } else if (skin.shape === "super_ice") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.55)"/>
      <polygon points="40,5 54,19 62,14 56,37 61,65 19,65 24,37 18,14 26,19" fill="url(#${uid}_g)" stroke="#E0F2FE" stroke-width="2.5"/>
      <polygon points="40,5 48,24 40,63 32,24" fill="rgba(255,255,255,0.45)"/>
      <polygon points="40,16 47,32 40,48 33,32" fill="#E0F2FE" stroke="${pal.dark}" stroke-width="1.4"/>
    `;
  } else if (skin.shape === "super_fire") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.6)"/>
      <path d="M22 65 C15 47 22 28 31 19 C29 28 35 28 40 7 C47 22 52 27 50 18 C59 29 64 47 58 65 Z" fill="url(#${uid}_g)" stroke="${edgeCol}" stroke-width="2.4"/>
      <path d="M29 64 C26 50 31 37 40 23 C49 37 54 50 51 64 Z" fill="#FDE047" opacity="0.88"/>
      <circle cx="40" cy="50" r="7" fill="#FFFFFF"/>
    `;
  } else if (skin.shape === "super_kick") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="24" ry="7" fill="rgba(0,0,0,0.6)"/>
      <circle cx="40" cy="39" r="25" fill="url(#${uid}_g)" stroke="${edgeCol}" stroke-width="3"/>
      <!-- Custom 3D Sculpted Armored Boot Relief -->
      <path d="M27 19 H43 L41 41 L57 46 C60 47 61 54 56 55 H25 L23 44 Z" fill="#FBBF24" stroke="#0F172A" stroke-width="2.2" stroke-linejoin="round"/>
      <path d="M29 24 H39 M28 31 H39" stroke="#78350F" stroke-width="2.2" stroke-linecap="round"/>
      <rect x="24" y="54" width="33" height="4.5" rx="2" fill="#FFFFFF" stroke="#0F172A" stroke-width="1.4"/>
    `;
  } else if (skin.shape === "super_devour") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="24" ry="7" fill="rgba(0,0,0,0.62)"/>
      <!-- Custom Sculpted Horned Monster Maw Token -->
      <path d="M18 28 L12 11 L27 20 C35 16 45 16 53 20 L68 11 L62 28 C67 42 63 59 54 66 H26 C17 59 13 42 18 28 Z" fill="url(#${uid}_g)" stroke="${edgeCol}" stroke-width="2.5"/>
      <!-- Fierce Glowing Eyes -->
      <polygon points="24,27 35,31 26,34" fill="#FDE047" stroke="#0F172A" stroke-width="1"/>
      <polygon points="56,27 45,31 54,34" fill="#FDE047" stroke="#0F172A" stroke-width="1"/>
      <!-- Fanged Cavernous Maw -->
      <path d="M22 42 Q40 36 58 42 Q56 59 40 61 Q24 59 22 42 Z" fill="#090D16" stroke="${pal.dark}" stroke-width="2"/>
      <polygon points="26,41 30,49 34,40 38,50 42,40 46,50 50,40 54,48 56,41" fill="#FFFFFF"/>
      <polygon points="28,58 32,50 36,59 40,51 44,59 48,50 52,58" fill="#FFFFFF"/>
    `;
  } else if (skin.shape === "super_thunder") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.58)"/>
      <circle cx="40" cy="39" r="24" fill="url(#${uid}_g)" stroke="#38BDF8" stroke-width="3"/>
      <polygon points="44,11 24,40 38,40 33,65 57,34 42,34" fill="#FEF08A" stroke="#0F172A" stroke-width="2" stroke-linejoin="round"/>
    `;
  } else if (skin.shape === "pin") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.55)"/>
      <ellipse cx="40" cy="67" rx="16" ry="5.5" fill="${edgeCol}" stroke="#78350F" stroke-width="1.5"/>
      <path d="M40 66 C40 66 15 43 15 26 A25 25 0 1 1 65 26 C65 43 40 66 40 66 Z" fill="#FFFFFF" stroke="#0F172A" stroke-width="3"/>
      <path d="M40 60 C40 60 20 40 20 26 A20 20 0 1 1 60 26 C60 40 40 60 40 60 Z" fill="url(#${uid}_g)" stroke="${pal.dark}" stroke-width="1.5"/>
      <circle cx="40" cy="25" r="9.5" fill="#FFFBEB" stroke="${pal.dark}" stroke-width="1.5"/>
      <polygon points="40,17 42.5,22.5 48.5,23 44,27 45.2,33 40,29.8 34.8,33 36,27 31.5,23 37.5,22.5" fill="${pal.primary}"/>
      <ellipse cx="31" cy="16" rx="6.5" ry="3.2" transform="rotate(-28 31 16)" fill="rgba(255,255,255,0.75)"/>
    `;
  } else if (skin.shape === "pawn") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="23" ry="7" fill="rgba(0,0,0,0.55)"/>
      <ellipse cx="40" cy="65" rx="21" ry="6.5" fill="${edgeCol}" stroke="#78350F" stroke-width="2"/>
      <path d="M21 64 C23 46 29 38 33 32 L47 32 C51 38 57 46 59 64 Z" fill="url(#${uid}_g)" stroke="#FFFFFF" stroke-width="2.5"/>
      <rect x="29" y="29" width="22" height="5.5" rx="2.5" fill="${edgeCol}" stroke="#78350F" stroke-width="1.4"/>
      <circle cx="40" cy="18" r="13" fill="url(#${uid}_g)" stroke="#FFFFFF" stroke-width="2.5"/>
      <circle cx="35" cy="13" r="4.2" fill="rgba(255,255,255,0.78)"/>
    `;
  } else if (skin.shape === "obelisk") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.55)"/>
      <polygon points="40,6 59,26 54,66 26,66 21,26" fill="url(#${uid}_g)" stroke="#FFFFFF" stroke-width="2.6"/>
      <polygon points="40,6 40,66 26,66 21,26" fill="rgba(255,255,255,0.26)"/>
      <polygon points="40,19 49,35 40,51 31,35" fill="${edgeCol}" stroke="${pal.dark}" stroke-width="1.6"/>
    `;
  } else if (skin.shape === "shield") {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.55)"/>
      <path d="M40 8 L63 19 V42 C63 57 40 68 40 68 C40 68 17 57 17 42 V19 L40 8 Z" fill="${edgeCol}" stroke="#FFFFFF" stroke-width="2.5"/>
      <path d="M40 13 L58 22 V41 C58 53 40 62 40 62 C40 62 22 53 22 41 V22 L40 13 Z" fill="url(#${uid}_g)"/>
      <polygon points="40,22 44.5,33 55,33 46.5,40 49,51 40,45 31,51 33.5,40 25,33 35.5,33" fill="${edgeCol}"/>
    `;
  } else if (skin.shape === "cyber") {
    bodyMarkup = `
      <ellipse cx="40" cy="69" rx="23" ry="7" fill="rgba(0,0,0,0.55)"/>
      <circle cx="40" cy="39" r="26" fill="#0F172A" stroke="#22D3EE" stroke-width="3"/>
      <circle cx="40" cy="39" r="20" fill="url(#${uid}_g)" stroke="#FFFFFF" stroke-width="2.2"/>
      <circle cx="40" cy="39" r="9" fill="${edgeCol}"/>
    `;
  } else {
    bodyMarkup = `
      <ellipse cx="40" cy="70" rx="22" ry="7" fill="rgba(0,0,0,0.55)"/>
      <path d="M21 66 L26 26 H54 L59 66 Z" fill="url(#${uid}_g)" stroke="#FFFFFF" stroke-width="2.5"/>
      <path d="M21 18 H28 V24 H35 V18 H45 V24 H52 V18 H59 V29 H21 V18 Z" fill="${edgeCol}" stroke="#78350F" stroke-width="1.5"/>
      <circle cx="40" cy="46" r="7.5" fill="${edgeCol}" stroke="${pal.dark}" stroke-width="1.5"/>
    `;
  }

  return `<svg viewBox="0 0 80 78" class="${sizeClass} select-none">
    <defs>
      <radialGradient id="${uid}_g" cx="32%" cy="26%" r="72%">
        <stop offset="0%" stop-color="${pal.light}"/>
        <stop offset="42%" stop-color="${pal.primary}"/>
        <stop offset="100%" stop-color="${pal.dark}"/>
      </radialGradient>
    </defs>
    ${bodyMarkup}
  </svg>`;
}
