/* ============================================================================
 * MODULE 06: COMPLETE LUDO CAPO GAMEPLAY RULES, SMART COLOR SYNCHRONIZATION
 *            & DETERMINISTIC SMART STRATEGIC SCORE ENGINE
 * Supports 2, 3, 4, and 5 Players, Captures, Safe Zones, Triple-6, Bonus Rolls
 * ============================================================================ */

class CapoRulesEngine {
  constructor(storage, audio) {
    this.storage = storage;
    this.audio = audio;
    this.board = new CapoBoardGeometry(4);
    this.resetMatch();
  }

  initMatch(setupConfig) {
    const count = setupConfig.playerCount || 4;
    this.board.setPlayerCount(count);
    this.playerCount = count;
    this.turnIndex = 0;
    this.turnCounter = 1;
    this.consecutiveSixes = 0;
    this.currentDiceValue = 6;
    this.phase = "WAITING_FOR_ROLL";
    this.pausedPhase = null;
    this.validTokenIds = [];
    this.rankings = [];
    this.moveHistory = [];
    this.turnCapturesStreak = 0;
    this.matchStats = {
      rolls: 0,
      captures: 0,
      strategicCaptures: 0,
      sixes: 0,
      startTime: Date.now()
    };

    this.players = [];
    for (let s = 0; s < count; s++) {
      const pSetup = setupConfig.players[s] || LUDO_CAPO_CONFIG.defaultSetup.players[s];
      const cornerIdx = this.board.getCornerForSeat(s);
      const palette = LUDO_CAPO_CONFIG.resolvePalette(
        pSetup.colorIdx !== undefined ? pSetup.colorIdx : s,
        pSetup.customHex,
        pSetup.colorName
      );
      this.players.push({
        seatIdx: s,
        cornerIdx,
        name: (pSetup.name || `Player ${s + 1}`).trim().slice(0, 16),
        avatar: pSetup.avatar || CAPO_AVATARS[s % CAPO_AVATARS.length].id,
        colorIdx: pSetup.colorIdx !== undefined ? pSetup.colorIdx : s,
        customHex: pSetup.customHex || palette.hex,
        palette,
        isBot: Boolean(pSetup.isBot),
        finishedCount: 0,
        capturesMade: 0,
        strategicMovesCount: 0,
        dangerEscapesCount: 0,
        safeAnchorsCount: 0,
        smartScore: 0,
        bestMovePts: 0,
        bestMoveLabel: "—",
        bestCaptureLabel: "—",
        scoreBreakdown: [],
        rank: null,
        tokens: [0, 1, 2, 3].map(tIdx => ({
          id: `p${s}_t${tIdx}`,
          seatIdx: s,
          tokenIndex: tIdx,
          relStep: -1,
          state: "idle",
          animX: null,
          animY: null,
          animScale: 1,
          hiddenBySuperAbility: false
        }))
      });
    }
  }

  refreshPalettesFromSetup() {
    const setup = this.storage.state.setup;
    this.players.forEach((p, idx) => {
      const pSetup = setup.players[idx] || LUDO_CAPO_CONFIG.defaultSetup.players[idx];
      if (!pSetup) return;
      p.name = (pSetup.name || `Player ${idx + 1}`).trim().slice(0, 16);
      p.avatar = pSetup.avatar || p.avatar;
      p.colorIdx = pSetup.colorIdx !== undefined ? pSetup.colorIdx : idx;
      p.customHex = pSetup.customHex;
      p.isBot = Boolean(pSetup.isBot);
      p.palette = LUDO_CAPO_CONFIG.resolvePalette(p.colorIdx, p.customHex, pSetup.colorName);
    });
  }

  resetMatch() {
    this.initMatch(this.storage.state.setup);
  }

  getActivePlayer() {
    return this.players[this.turnIndex];
  }

  getValidMovesForRoll(seatIdx, diceVal) {
    const player = this.players[seatIdx];
    if (!player) return [];
    const maxStep = this.board.maxRelStep;
    const settings = this.storage.state.settings;
    const exactReq = settings.exactFinishRoll !== false;
    const sixExitReq = settings.sixExitRequired !== false;
    const valid = [];

    for (const token of player.tokens) {
      if (token.relStep === maxStep) continue;
      if (token.relStep === -1) {
        if (sixExitReq ? diceVal === 6 : (diceVal === 6 || diceVal === 1)) {
          valid.push(token);
        }
      } else {
        const targetStep = token.relStep + diceVal;
        if (exactReq) {
          if (targetStep <= maxStep) valid.push(token);
        } else {
          valid.push(token);
        }
      }
    }
    return valid;
  }

  /**
   * Checks whether a given track square index is currently under immediate capture threat
   * (1 to 6 steps ahead of any opposing token on the main track).
   */
  isTrackSquareThreatened(ownerSeatIdx, targetTrackIdx) {
    if (targetTrackIdx < 0) return false;
    const node = this.board.trackNodes[targetTrackIdx];
    if (node && node.isSafe && this.storage.state.settings.safeZonesEnabled !== false) {
      return false;
    }
    const trackLen = this.board.trackLength;
    for (const op of this.players) {
      if (op.seatIdx === ownerSeatIdx) continue;
      for (const ot of op.tokens) {
        if (ot.relStep < 0) continue;
        const otPos = this.board.getTokenWorldPosition(op.seatIdx, ot.tokenIndex, ot.relStep);
        if (otPos.zone !== "track") continue;
        const distAhead = (targetTrackIdx - otPos.trackIdx + trackLen) % trackLen;
        if (distAhead >= 1 && distAhead <= 6) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Checks whether moving `token` by `diceVal` would result in a capture, safe zone, or danger escape.
   */
   analyzeCandidateMove(token, diceVal) {
    const seatIdx = token.seatIdx;
    const maxStep = this.board.maxRelStep;
    const mainLimit = this.board.isFivePlayer ? 62 : 50;
    const startStep = token.relStep;
    const endStep = startStep === -1 ? 0 : Math.min(maxStep, startStep + diceVal);

    const startPos = this.board.getTokenWorldPosition(seatIdx, token.tokenIndex, startStep);
    const endPos = this.board.getTokenWorldPosition(seatIdx, token.tokenIndex, endStep);

    const wasThreatened = (startPos.zone === "track") && this.isTrackSquareThreatened(seatIdx, startPos.trackIdx);
    const willBeThreatened = (endPos.zone === "track") && this.isTrackSquareThreatened(seatIdx, endPos.trackIdx);

    let capturesEnemy = false;
    let maxEnemyProgress = 0;
    if (endPos.zone === "track" && (!endPos.isSafe || !this.storage.state.settings.safeZonesEnabled)) {
      for (const op of this.players) {
        if (op.seatIdx === seatIdx) continue;
        const enemyOnTile = op.tokens.filter(ot => {
          if (ot.relStep < 0) return false;
          const p = this.board.getTokenWorldPosition(op.seatIdx, ot.tokenIndex, ot.relStep);
          return p.zone === "track" && p.trackIdx === endPos.trackIdx;
        });
        if (enemyOnTile.length === 1) {
          capturesEnemy = true;
          maxEnemyProgress = Math.max(maxEnemyProgress, enemyOnTile[0].relStep);
        }
      }
    }

    const escapedDanger = wasThreatened && !willBeThreatened;
    const enteredHomeStretch = (startStep <= mainLimit) && (endPos.zone === "stretch");
    const reachedFinish = (endStep === maxStep);
    const landedSafeStar = (endPos.zone === "track") && Boolean(endPos.isSafe) && (startStep !== -1);

    return {
      token,
      startStep,
      endStep,
      wasThreatened,
      willBeThreatened,
      capturesEnemy,
      maxEnemyProgress,
      escapedDanger,
      enteredHomeStretch,
      reachedFinish,
      landedSafeStar
    };
  }

  evaluateRollOutcome(diceVal) {
    const settings = this.storage.state.settings;
    this.currentDiceValue = diceVal;
    this.matchStats.rolls += 1;
    this.storage.state.stats.totalDiceRolls += 1;

    if (diceVal === 6) {
      this.consecutiveSixes += 1;
      this.matchStats.sixes += 1;
      this.storage.state.stats.totalSixes += 1;
    } else {
      this.consecutiveSixes = 0;
    }
    this.storage.save();

    if (diceVal === 6 && settings.tripleSixRule && this.consecutiveSixes >= 3) {
      this.consecutiveSixes = 0;
      this.turnCapturesStreak = 0;
      this.validTokenIds = [];
      return {
        status: "TRIPLE_SIX_FORFEIT",
        validTokens: [],
        message: `${this.getActivePlayer().name} rolled three 6s in a row — turn passes!`
      };
    }

    const validTokens = this.getValidMovesForRoll(this.turnIndex, diceVal);
    this.validTokenIds = validTokens.map(t => t.id);

    this.players.forEach(p => {
      p.tokens.forEach(t => {
        t.state = this.validTokenIds.includes(t.id) ? "selectable" : (t.relStep === this.board.maxRelStep ? "finished" : "idle");
      });
    });

    if (validTokens.length === 0) {
      this.turnCapturesStreak = 0;
      return {
        status: "NO_VALID_MOVES",
        validTokens: [],
        message: `No legal moves for ${this.getActivePlayer().name} on a ${diceVal}.`
      };
    }

    this.phase = "SELECT_TOKEN";
    return {
      status: "SELECT_TOKEN",
      validTokens,
      message: `${this.getActivePlayer().name}: Tap a highlighted token to move ${diceVal}.`
    };
  }

  planTokenMove(token, diceVal) {
    const seatIdx = token.seatIdx;
    const maxStep = this.board.maxRelStep;
    const startStep = token.relStep;
    const endStep = startStep === -1 ? 0 : Math.min(maxStep, startStep + diceVal);

    // Pre-analyze all candidate moves BEFORE mutating token.relStep so Smart Score can evaluate decision quality!
    const allValidTokens = this.getValidMovesForRoll(seatIdx, diceVal);
    const chosenAnalysis = this.analyzeCandidateMove(token, diceVal);
    const allAnalyses = allValidTokens.map(t => this.analyzeCandidateMove(t, diceVal));

    const waypoints = [];
    if (startStep === -1) {
      waypoints.push({
        relStep: 0,
        pos: this.board.getTokenWorldPosition(seatIdx, token.tokenIndex, 0)
      });
    } else {
      for (let s = startStep + 1; s <= endStep; s++) {
        waypoints.push({
          relStep: s,
          pos: this.board.getTokenWorldPosition(seatIdx, token.tokenIndex, s)
        });
      }
    }

    return {
      token,
      startStep,
      endStep,
      waypoints,
      chosenAnalysis,
      allAnalyses
    };
  }

  /**
   * Deterministic Smart Score Evaluator:
   * Rewards Captures, Strategic High-Value Captures, Multi-Capture Chains,
   * Escaping Danger, Safe-Star Positioning, Home Stretch Entry, Finishing Tokens, and Winning.
   * Only penalizes avoidable tactical blunders when a safe/capture option was ignored.
   */
  computeSmartScoreEvents(player, chosenAnalysis, allAnalyses, capturedTokens, reachedFinish, matchOver) {
    const scCfg = (this.storage.state.dashboard && this.storage.state.dashboard.scoring)
      ? this.storage.state.dashboard.scoring
      : LUDO_CAPO_CONFIG.defaultDashboard.scoring;

    if (!scCfg || scCfg.enabled === false) return [];

    const events = [];

    // 1. Capture Scoring (Basic vs Strategic vs Multi-Capture)
    if (capturedTokens && capturedTokens.length > 0) {
      this.turnCapturesStreak = (this.turnCapturesStreak || 0) + capturedTokens.length;
      const maxVictimStep = Math.max(...capturedTokens.map(vt => vt.preCaptureStep !== undefined ? vt.preCaptureStep : vt.relStep));
      const isDeepTarget = maxVictimStep >= 24;

      if (isDeepTarget) {
        const pts = (scCfg.strategicCapturePts || 25) + (maxVictimStep >= 40 ? (scCfg.deepTargetBonusPts || 15) : 0);
        events.push({
          pts,
          label: `+${pts} STRATEGIC CAPTURE`,
          reason: `Eliminated an advanced opponent token (${maxVictimStep} steps in)`
        });
        player.strategicMovesCount += 1;
        this.matchStats.strategicCaptures += 1;
        this.storage.state.stats.strategicCaptures = (this.storage.state.stats.strategicCaptures || 0) + 1;
        player.bestCaptureLabel = `Strategic Capture (+${pts})`;
      } else {
        const pts = scCfg.basicCapturePts || 15;
        events.push({
          pts,
          label: `+${pts} CAPTURE`,
          reason: `Captured an opposing token on the main track`
        });
        if (player.bestCaptureLabel === "—") {
          player.bestCaptureLabel = `Tactical Capture (+${pts})`;
        }
      }

      if (this.turnCapturesStreak >= 2 || capturedTokens.length > 1) {
        const chainPts = scCfg.multiCaptureChainPts || 30;
        events.push({
          pts: chainPts,
          label: `+${chainPts} MULTI-CAPTURE STREAK`,
          reason: `Chained ${this.turnCapturesStreak} captures in a single turn sequence`
        });
        player.strategicMovesCount += 1;
      }
    }

    // 2. Saving a Token From Danger (Defensive Mastery)
    if (chosenAnalysis && chosenAnalysis.escapedDanger) {
      const pts = scCfg.escapeDangerPts || 15;
      events.push({
        pts,
        label: `+${pts} ESCAPED DANGER`,
        reason: `Moved a threatened token out of enemy capture range`
      });
      player.dangerEscapesCount += 1;
      player.strategicMovesCount += 1;
    }

    // 3. Entering Private Home Stretch
    if (chosenAnalysis && chosenAnalysis.enteredHomeStretch && !reachedFinish) {
      const pts = scCfg.enterHomeStretchPts || 15;
      events.push({
        pts,
        label: `+${pts} HOME STRETCH`,
        reason: `Secured token inside private colored Home Stretch`
      });
      player.strategicMovesCount += 1;
    }

    // 4. Anchoring on a Safe Star Square
    if (chosenAnalysis && chosenAnalysis.landedSafeStar && !chosenAnalysis.escapedDanger) {
      const pts = scCfg.safeZoneAnchorPts || 10;
      events.push({
        pts,
        label: `+${pts} SAFE POSITION`,
        reason: `Anchored token on anprotected Safe Star square`
      });
      player.safeAnchorsCount += 1;
      player.strategicMovesCount += 1;
    }

    // 5. Reaching the Central Finish Sanctuary & Multi-Finish Bonus
    if (reachedFinish) {
      const baseFin = scCfg.finishTokenPts || 35;
      const multiBonus = Math.max(0, (player.finishedCount - 1) * (scCfg.multiFinishBonusPts || 20));
      const totalFinPts = baseFin + multiBonus;
      events.push({
        pts: totalFinPts,
        label: `+${totalFinPts} TOKEN FINISHED`,
        reason: player.finishedCount > 1
          ? `Brought token #${player.finishedCount} home (includes multi-finish bonus)`
          : `Brought first token into the Victory Sanctuary`
      });
      player.strategicMovesCount += 1;
    }

    // 6. Avoidable Tactical Blunder Check (Never penalizes bad luck — ONLY when a better legal move existed)
    if (
      events.length === 0 &&
      chosenAnalysis &&
      !chosenAnalysis.wasThreatened &&
      chosenAnalysis.willBeThreatened &&
      Array.isArray(allAnalyses) &&
      allAnalyses.length > 1
    ) {
      const hadBetterAlternative = allAnalyses.some(alt =>
        alt.token.id !== chosenAnalysis.token.id &&
        (alt.capturesEnemy || alt.escapedDanger || !alt.willBeThreatened)
      );
      if (hadBetterAlternative) {
        const pen = scCfg.avoidableBlunderPenalty || -10;
        events.push({
          pts: pen,
          label: `${pen} RISKY EXPOSURE`,
          reason: `Stepped into enemy capture range while a safer move was available`
        });
      }
    }

    // 7. Match Victory Bonus
    if (matchOver) {
      const winPts = scCfg.victoryBonusPts || 100;
      events.push({
        pts: winPts,
        label: `+${winPts} VICTORY BONUS`,
        reason: `Crowned Ludo Capo Sovereign Champion`
      });
    }

    // Apply events to player's score & history
    let moveNetPts = 0;
    events.forEach(ev => {
      moveNetPts += ev.pts;
      player.smartScore = Math.max(0, (player.smartScore || 0) + ev.pts);
      player.scoreBreakdown.push({
        turn: this.turnCounter,
        pts: ev.pts,
        label: ev.label,
        reason: ev.reason
      });
      if (ev.pts > (player.bestMovePts || 0)) {
        player.bestMovePts = ev.pts;
        player.bestMoveLabel = ev.label.replace(/^\+\d+\s*/, "");
      }
    });

    return events;
  }

  commitTokenMove(token, endStep, chosenAnalysis = null, allAnalyses = []) {
    const settings = this.storage.state.settings;
    const seatIdx = token.seatIdx;
    const player = this.players[seatIdx];
    const maxStep = this.board.maxRelStep;

    token.relStep = endStep;
    this.validTokenIds = [];
    this.players.forEach(p => p.tokens.forEach(t => {
      if (t.relStep === maxStep) t.state = "finished";
      else t.state = "idle";
    }));

    const destInfo = this.board.getTokenWorldPosition(seatIdx, token.tokenIndex, endStep);
    let capturedTokens = [];
    let reachedFinish = false;
    let landedSafe = false;

    if (endStep === maxStep) {
      reachedFinish = true;
      token.state = "finished";
      player.finishedCount = player.tokens.filter(t => t.relStep === maxStep).length;
      this.storage.state.stats.totalTokensFinished += 1;

      if (player.finishedCount === 4 && !this.rankings.includes(seatIdx)) {
        this.rankings.push(seatIdx);
        player.rank = this.rankings.length;
      }
    } else if (destInfo.zone === "track") {
      const targetTrackIdx = destInfo.trackIdx;
      const isSafeSquare = settings.safeZonesEnabled !== false ? destInfo.isSafe : false;
      landedSafe = isSafeSquare;

      if (!isSafeSquare) {
        for (const otherPlayer of this.players) {
          if (otherPlayer.seatIdx === seatIdx) continue;
          const enemyOnTile = otherPlayer.tokens.filter(ot => {
            if (ot.relStep < 0) return false;
            const otPos = this.board.getTokenWorldPosition(otherPlayer.seatIdx, ot.tokenIndex, ot.relStep);
            return otPos.zone === "track" && otPos.trackIdx === targetTrackIdx;
          });
          if (enemyOnTile.length === 1) {
            enemyOnTile.forEach(et => { et.preCaptureStep = et.relStep; });
            capturedTokens.push(...enemyOnTile);
          }
        }
      }
    }

    if (capturedTokens.length > 0) {
      player.capturesMade += capturedTokens.length;
      this.matchStats.captures += capturedTokens.length;
      this.storage.state.stats.totalCaptures += capturedTokens.length;
    }

    const matchOver = this.rankings.length >= 1;
    const scoreEvents = this.computeSmartScoreEvents(
      player,
      chosenAnalysis,
      allAnalyses,
      capturedTokens,
      reachedFinish,
      matchOver
    );

    this.storage.save();

    const bonusTurn = !matchOver && (
      (this.currentDiceValue === 6 && settings.sixBonusTurn !== false) ||
      (capturedTokens.length > 0 && settings.captureBonusTurn !== false) ||
      (reachedFinish && settings.finishBonusTurn !== false)
    );

    if (!bonusTurn) {
      this.turnCapturesStreak = 0;
    }

    return {
      destInfo,
      capturedTokens,
      reachedFinish,
      landedSafe,
      bonusTurn,
      matchOver,
      scoreEvents
    };
  }

  advanceToNextPlayer() {
    this.consecutiveSixes = 0;
    this.turnCapturesStreak = 0;
    this.turnCounter += 1;
    for (let i = 1; i <= this.playerCount; i++) {
      const nextSeat = (this.turnIndex + i) % this.playerCount;
      if (this.players[nextSeat].finishedCount < 4) {
        this.turnIndex = nextSeat;
        break;
      }
    }
    this.phase = "WAITING_FOR_ROLL";
    return this.turnIndex;
  }

  chooseSmartMove(validTokens, diceVal) {
    if (!validTokens || validTokens.length === 0) return null;
    if (validTokens.length === 1) return validTokens[0];

    let bestToken = validTokens[0];
    let bestScore = -9999;

    for (const t of validTokens) {
      const analysis = this.analyzeCandidateMove(t, diceVal);
      let score = 0;

      if (analysis.reachedFinish) score += 520;
      if (analysis.capturesEnemy) score += 440 + analysis.maxEnemyProgress * 3;
      if (analysis.escapedDanger) score += 310;
      if (t.relStep === -1 && diceVal === 6) score += 275;
      if (analysis.enteredHomeStretch) score += 220;
      if (analysis.landedSafeStar) score += 170;
      if (!analysis.wasThreatened && analysis.willBeThreatened) score -= 180;
      score += analysis.endStep * 1.5;

      if (score > bestScore) {
        bestScore = score;
        bestToken = t;
      }
    }
    return bestToken;
  }
}
