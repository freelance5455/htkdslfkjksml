/* ============================================================================
 * MODULE 05: DUAL-TOPOLOGY BOARD GEOMETRY ENGINE (4-ARM CROSS & 5-ARM PENTAGON)
 * Normalized 1000x1000 Coordinate Space — Maximized Proportions & Yard Symmetry
 * ============================================================================ */

class CapoBoardGeometry {
  constructor(playerCount = 4) {
    this.setPlayerCount(playerCount);
  }

  setPlayerCount(playerCount) {
    this.playerCount = playerCount;
    this.isFivePlayer = (playerCount === 5);
    if (this.isFivePlayer) {
      this.buildFivePlayerPentagon();
    } else {
      this.buildFourPlayerCross();
    }
  }

  /* --------------------------------------------------------------------------
   * STANDARD 4-ARM CROSS LUDO GEOMETRY (2, 3, AND 4 PLAYERS)
   * Tighter outer bezel (pad = 22) -> Huge 956x956 playfield (63.73px cells)
   * -------------------------------------------------------------------------- */
  buildFourPlayerCross() {
    this.pad = 22;
    this.innerSize = 956;
    this.cell = this.innerSize / 15; // 63.733

    const g2n = (col, row) => ({
      x: this.pad + (col + 0.5) * this.cell,
      y: this.pad + (row + 0.5) * this.cell,
      col,
      row
    });

    // 52 clockwise main track squares
    const rawCoords = [
      // Left arm top row (0..4)
      [1,6], [2,6], [3,6], [4,6], [5,6],
      // Top arm left col (5..10)
      [6,5], [6,4], [6,3], [6,2], [6,1], [6,0],
      // Top turn (11)
      [7,0],
      // Top arm right col (12..17)
      [8,0], [8,1], [8,2], [8,3], [8,4], [8,5],
      // Right arm top row (18..23)
      [9,6], [10,6], [11,6], [12,6], [13,6], [14,6],
      // Right turn (24)
      [14,7],
      // Right arm bottom row (25..30)
      [14,8], [13,8], [12,8], [11,8], [10,8], [9,8],
      // Bottom arm right col (31..36)
      [8,9], [8,10], [8,11], [8,12], [8,13], [8,14],
      // Bottom turn (37)
      [7,14],
      // Bottom arm left col (38..43)
      [6,14], [6,13], [6,12], [6,11], [6,10], [6,9],
      // Left arm bottom row (44..49)
      [5,8], [4,8], [3,8], [2,8], [1,8], [0,8],
      // Left turn (50..51)
      [0,7], [0,6]
    ];

    this.trackLength = 52;
    this.maxRelStep = 56;
    this.startIndices = [0, 13, 26, 39];
    this.starIndices = [8, 21, 34, 47];
    this.safeIndices = new Set([...this.startIndices, ...this.starIndices]);

    this.trackNodes = rawCoords.map(([c, r], idx) => {
      const pt = g2n(c, r);
      return {
        index: idx,
        x: pt.x,
        y: pt.y,
        col: c,
        row: r,
        w: this.cell,
        h: this.cell,
        angle: 0,
        isStartFor: this.startIndices.indexOf(idx),
        isStar: this.starIndices.includes(idx),
        isSafe: this.safeIndices.has(idx)
      };
    });

    // Home stretches for the 4 corners (0: Left/TL, 1: Top/TR, 2: Right/BR, 3: Bottom/BL)
    const stretchCoords = [
      [[1,7], [2,7], [3,7], [4,7], [5,7]],
      [[7,1], [7,2], [7,3], [7,4], [7,5]],
      [[13,7], [12,7], [11,7], [10,7], [9,7]],
      [[7,13], [7,12], [7,11], [7,10], [7,9]]
    ];

    this.homeStretches = stretchCoords.map((arm, cornerIdx) =>
      arm.map(([c, r], stepIdx) => {
        const pt = g2n(c, r);
        return { x: pt.x, y: pt.y, col: c, row: r, cornerIdx, stepIdx };
      })
    );

    // Finish sanctuary positions inside center 3x3 triangle
    this.finishPositions = [
      g2n(6.25, 7.0), // Left triangle
      g2n(7.0, 6.25), // Top triangle
      g2n(7.75, 7.0), // Right triangle
      g2n(7.0, 7.75)  // Bottom triangle
    ];

    // Perfectly Symmetric Home Yard Sockets!
    // Each 6x6 corner yard spans cols/rows [0..5] (center at 2.5) or [9..14] (center at 11.5).
    // Placing sockets at +/- 1.12 cells around 2.5 and 11.5 centers them with mathematical precision!
    const yardSlotGrid = [
      [[1.38, 1.38], [3.62, 1.38], [1.38, 3.62], [3.62, 3.62]],     // TL (center 2.5, 2.5)
      [[10.38, 1.38], [12.62, 1.38], [10.38, 3.62], [12.62, 3.62]],  // TR (center 11.5, 2.5)
      [[10.38, 10.38], [12.62, 10.38], [10.38, 12.62], [12.62, 12.62]], // BR (center 11.5, 11.5)
      [[1.38, 10.38], [3.62, 10.38], [1.38, 12.62], [3.62, 12.62]]   // BL (center 2.5, 11.5)
    ];

    this.yardSlots = yardSlotGrid.map(slots =>
      slots.map(([c, r]) => g2n(c, r))
    );

    if (this.playerCount === 2) {
      this.seatToCorner = [0, 2]; // Opposite diagonal corners (TL vs BR)
    } else if (this.playerCount === 3) {
      this.seatToCorner = [0, 1, 2];
    } else {
      this.seatToCorner = [0, 1, 2, 3];
    }
  }

  /* --------------------------------------------------------------------------
   * DEDICATED 5-ARM PENTAGONAL STAR GEOMETRY (5 PLAYERS)
   * Enlarged arms, wider lanes, and larger Home Yard Sanctuaries
   * -------------------------------------------------------------------------- */
  buildFivePlayerPentagon() {
    this.trackLength = 65;
    this.maxRelStep = 68;
    this.seatToCorner = [0, 1, 2, 3, 4];

    this.armAnglesDeg = [-126, -54, 18, 90, 162];
    this.innerRadius = 144;
    this.radialStep = 50;
    this.laneSpacing = 44;

    const armLocalToWorld = (armIdx, ringIdx, laneOffset) => {
      const deg = this.armAnglesDeg[armIdx];
      const rad = (deg * Math.PI) / 180;
      const perpRad = rad + Math.PI / 2;
      const r = this.innerRadius + (ringIdx + 0.5) * this.radialStep;
      const w = laneOffset * this.laneSpacing;
      return {
        x: 500 + Math.cos(rad) * r + Math.cos(perpRad) * w,
        y: 500 + Math.sin(rad) * r + Math.sin(perpRad) * w,
        angle: rad,
        armIdx,
        ringIdx,
        laneOffset
      };
    };

    this.trackNodes = [];
    this.startIndices = [];
    this.starIndices = [];

    for (let arm = 0; arm < 5; arm++) {
      for (let r = 0; r < 6; r++) {
        const pt = armLocalToWorld(arm, r, -1);
        const idx = this.trackNodes.length;
        const isStar = (r === 2);
        if (isStar) this.starIndices.push(idx);
        this.trackNodes.push({
          index: idx,
          x: pt.x,
          y: pt.y,
          w: 42,
          h: 46,
          angle: pt.angle,
          armIdx: arm,
          isStartFor: -1,
          isStar,
          isSafe: isStar
        });
      }
      {
        const pt = armLocalToWorld(arm, 5, 0);
        const idx = this.trackNodes.length;
        this.trackNodes.push({
          index: idx,
          x: pt.x,
          y: pt.y,
          w: 42,
          h: 46,
          angle: pt.angle,
          armIdx: arm,
          isStartFor: -1,
          isStar: false,
          isSafe: false
        });
      }
      for (let r = 5; r >= 0; r--) {
        const pt = armLocalToWorld(arm, r, 1);
        const idx = this.trackNodes.length;
        const isStart = (r === 4);
        if (isStart) this.startIndices.push(idx);
        this.trackNodes.push({
          index: idx,
          x: pt.x,
          y: pt.y,
          w: 42,
          h: 46,
          angle: pt.angle,
          armIdx: arm,
          isStartFor: isStart ? arm : -1,
          isStar: false,
          isSafe: isStart
        });
      }
    }

    this.safeIndices = new Set([...this.startIndices, ...this.starIndices]);

    this.homeStretches = [];
    this.finishPositions = [];
    this.yardCenters = [];
    this.yardSlots = [];

    for (let arm = 0; arm < 5; arm++) {
      const stretch = [];
      for (let s = 0; s < 5; s++) {
        const r = 4 - s;
        const pt = armLocalToWorld(arm, r, 0);
        stretch.push({
          x: pt.x,
          y: pt.y,
          w: 42,
          h: 46,
          angle: pt.angle,
          cornerIdx: arm,
          stepIdx: s
        });
      }
      this.homeStretches.push(stretch);

      const rad = (this.armAnglesDeg[arm] * Math.PI) / 180;
      this.finishPositions.push({
        x: 500 + Math.cos(rad) * 78,
        y: 500 + Math.sin(rad) * 78
      });

      const yardDeg = this.armAnglesDeg[arm] + 36;
      const yardRad = (yardDeg * Math.PI) / 180;
      const ycx = 500 + Math.cos(yardRad) * 336;
      const ycy = 500 + Math.sin(yardRad) * 336;
      this.yardCenters.push({ x: ycx, y: ycy, angle: yardRad });

      const slotOffsets = [
        [-32, -32], [32, -32], [-32, 32], [32, 32]
      ];
      this.yardSlots.push(
        slotOffsets.map(([ox, oy]) => ({ x: ycx + ox, y: ycy + oy }))
      );
    }
  }

  getCornerForSeat(seatIdx) {
    return this.seatToCorner[seatIdx] !== undefined ? this.seatToCorner[seatIdx] : seatIdx;
  }

  getTrackIndexForStep(seatIdx, relStep) {
    const corner = this.getCornerForSeat(seatIdx);
    const startIdx = this.startIndices[corner];
    if (this.isFivePlayer) {
      if (relStep < 0 || relStep > 62) return -1;
      return (startIdx + relStep) % 65;
    } else {
      if (relStep < 0 || relStep > 50) return -1;
      return (startIdx + relStep) % 52;
    }
  }

  getTokenWorldPosition(seatIdx, tokenIndex, relStep) {
    const corner = this.getCornerForSeat(seatIdx);
    if (relStep === -1) {
      const slot = this.yardSlots[corner][tokenIndex % 4];
      return { x: slot.x, y: slot.y, zone: "yard", trackIdx: -1 };
    }
    const mainLimit = this.isFivePlayer ? 62 : 50;
    if (relStep <= mainLimit) {
      const tIdx = this.getTrackIndexForStep(seatIdx, relStep);
      const node = this.trackNodes[tIdx];
      return { x: node.x, y: node.y, zone: "track", trackIdx: tIdx, isSafe: node.isSafe };
    }
    if (relStep < this.maxRelStep) {
      const stretchIdx = relStep - (mainLimit + 1);
      const node = this.homeStretches[corner][stretchIdx];
      return { x: node.x, y: node.y, zone: "stretch", trackIdx: -1, stretchIdx };
    }
    const fin = this.finishPositions[corner];
    const offsets = [[-15, -15], [15, -15], [-15, 15], [15, 15]];
    const [ox, oy] = offsets[tokenIndex % 4];
    return { x: fin.x + ox, y: fin.y + oy, zone: "finish", trackIdx: -1 };
  }
}
