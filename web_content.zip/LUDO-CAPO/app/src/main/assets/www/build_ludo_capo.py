import base64, mimetypes, os, re, sys

src_dir = "artifacts/file_generation/ttl=63d/intermediate/ludo_capo_src"
inter_html = "artifacts/file_generation/ttl=63d/intermediate/ludo_capo.html"
out_html = "artifacts/file_generation/ttl=63d/output/ludo_capo.html"

css_content = open(os.path.join(src_dir, "styles.css"), encoding="utf-8").read()

js_files = [
    "01_config_storage.js",
    "02_icons_art.js",
    "03_themes_data.js",
    "04_audio_engine.js",
    "05_board_geometry.js",
    "06_rules_engine.js",
    "07_vfx_renderer.js",
    "08_ui_controller.js"
]

js_chunks = []
for jf in js_files:
    js_chunks.append(open(os.path.join(src_dir, jf), encoding="utf-8").read())

js_content = "\n\n".join(js_chunks)

template = open(os.path.join(src_dir, "index_template.html"), encoding="utf-8").read()
combined = template.replace("/*__INLINE_CSS__*/", css_content).replace("/*__INLINE_JS__*/", js_content)

with open(inter_html, "w", encoding="utf-8") as f:
    f.write(combined)

# Inline local image paths as base64 data URIs
def inline_img(m):
    f_path = m.group(2)
    if f_path.startswith(("http", "data:")) or not os.path.exists(f_path):
        return m.group(0)
    mime = mimetypes.guess_type(f_path)[0] or "image/jpeg"
    data = base64.b64encode(open(f_path, "rb").read()).decode()
    return f'{m.group(1)}data:{mime};base64,{data}{m.group(3)}'

final_html = re.sub(r'''(src=["'])([^"']+)(["'])''', inline_img, combined)

# Verify strictly zero emojis
emoji_pattern = re.compile(r'[\U0001F300-\U0001FAFF\u2600-\u27BF]')
emojis_found = emoji_pattern.findall(final_html)
if emojis_found:
    print("WARNING: Emojis found:", emojis_found)
    sys.exit(1)

with open(out_html, "w", encoding="utf-8") as f:
    f.write(final_html)

size_kb = os.path.getsize(out_html) / 1024
print(f"Built {out_html} ({size_kb:.1f} KB) — Zero emojis verified.")
