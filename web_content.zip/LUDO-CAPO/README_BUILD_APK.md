# LUDO CAPO v4.0 — Official Offline Android & Web Project

## Project Contents
- `app/src/main/AndroidManifest.xml`: Offline Android manifest (`com.ludocapo.game`, zero internet permissions)
- `app/src/main/java/com/ludocapo/game/MainActivity.java`: Fullscreen hardware-accelerated Android host
- `app/src/main/java/com/ludocapo/game/AndroidBridge.java`: Native haptic vibration bridge
- `app/src/main/assets/www/index.html`: Self-contained production Ludo Capo v4.0 bundle
- `app/src/main/assets/www/src/`: Modular engine source code:
  - `01_config_storage.js`: `CapoSmartColorEngine` (13 presets including Burgundy, Beige, Olive, Coffee, Black, White + Custom HEX), Dashboard state, and Smart Score persistence
  - `02_icons_art.js`: 6 Custom 3D Super Tokens (`super_blackhole`, `super_ice`, `super_fire`, `super_kick`, `super_devour`, `super_thunder`), 6 Classic Royal Tokens, 8 3D Dice, 8 Avatars
  - `03_themes_data.js`: 6 Complete World Themes
  - `04_audio_engine.js`: Multi-channel Web Audio synthesizer & Super Ability SFX
  - `05_board_geometry.js`: Dual-topology 4-Arm Cross (2-4P) & 5-Arm Pentagon (5P) geometry
  - `06_rules_engine.js`: Ludo gameplay engine & deterministic Smart Strategic Score analyzer
  - `07_vfx_renderer.js`: 3D Board, Smart-Color Tokens & Capture-Exclusive Super Ability VFX Sequencer
  - `08_ui_controller.js`: UI Controller, Full Game Dashboard Studio & Post-Game Strategic Scoreboard

## Building the APK in Android Studio
1. Extract `LUDO-CAPO.zip`.
2. Open Android Studio -> **Open** -> select the extracted project folder.
3. Let Gradle sync, then choose **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** (or run `./gradlew assembleDebug`).
