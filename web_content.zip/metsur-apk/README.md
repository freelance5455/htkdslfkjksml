# Metsur Producción – App Android

Envuelve tu `index.html` (en `app/src/main/assets/`) en una app nativa. Funciona 100 % sin Internet
(la app no pide ningún permiso). El HTML original no está modificado.

## Obtener el APK

### Opción A – GitHub (sin instalar nada)
1. Crea un repositorio nuevo en GitHub y sube **todo el contenido de esta carpeta**
   (incluida la carpeta oculta `.github`).
2. Entra a la pestaña **Actions → Compilar APK → Run workflow** (también corre solo al subir).
3. Al terminar (≈3 min), abre la ejecución y descarga **Metsur-Produccion-APK** (zip con `app-release.apk`).

### Opción B – Android Studio
1. *File → Open* y elige esta carpeta; espera la sincronización de Gradle.
2. *Build → Build APK(s)* (variante **release**).
3. El archivo queda en `app/build/outputs/apk/release/app-release.apk`.

### Opción C – Terminal
Requiere JDK 17, Android SDK (plataforma 34) y Gradle 8.9:

    gradle assembleRelease

## Instalar en el teléfono
Pasa el `.apk` al teléfono y ábrelo. Android pedirá permitir "instalar apps de origen desconocido"
para la app desde la que lo abres (Archivos, Chrome, WhatsApp, etc.).

## Qué agrega la envoltura nativa
| Función de la página | Problema en WebView | Solución incluida |
|---|---|---|
| `confirm()` al eliminar/borrar | No muestra diálogo | Diálogos nativos |
| Restaurar respaldo (`<input type=file>`) | No abre el selector | Selector de archivos nativo |
| Exportar CSV / Crear respaldo (`Blob` + `a.download`) | No descarga nada | Se abre "Guardar como…" y eliges la carpeta |
| Registros (`localStorage`) | Desactivado por defecto | Activado; persisten en la app |

## ⚠️ Datos
- Los registros de la **versión web no pasan solos a la app** (cada una guarda en su propio espacio).
  Para migrar: en la versión web, *Datos y respaldo → Crear respaldo*; en la app, *Restaurar respaldo*.
- Desinstalar la app borra sus datos. Exporta un respaldo antes.

## Firma y actualizaciones
`app/metsur.keystore` (contraseña `metsur123`, alias `metsur`) firma todas las compilaciones con la
misma llave, así una versión nueva se instala **encima** de la anterior sin perder datos.
No la pierdas. Para publicar en Google Play, crea tu propia llave y sube `targetSdk` a 35.

## Cambiar nombre / ícono / versión
- Nombre: `app/src/main/res/values/strings.xml`
- Ícono: generado desde el logo del HTML (`res/mipmap-*` y `drawable-nodpi`)
- Versión: `versionCode` / `versionName` en `app/build.gradle` (sube `versionCode` en cada actualización)
