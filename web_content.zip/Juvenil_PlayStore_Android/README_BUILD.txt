JUVENIL versão 42.0 - TESTE FAMILIAR

Alterações:
- Fonte de jogos: ESPN Soccer "all" por data, incluindo as competições disponíveis no placar global.
- Data calculada no fuso America/Sao_Paulo.
- Atualização ao vivo usa a mesma fonte global.
- INTERNET permission adicionada ao AndroidManifest.
- VersionCode 42 / VersionName 42.0.

Observação: a cobertura é a que a fonte ESPN disponibiliza no endpoint global. Não significa literalmente todas as 1.245 competições da API-Football.
