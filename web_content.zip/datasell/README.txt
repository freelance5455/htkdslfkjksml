DataSell Demo Starter

This is a mobile-first PWA prototype, not an Android APK and not a real data-selling service.

Preview: open index.html in a browser. PWA install/service-worker features generally require HTTPS or localhost.

Android APK route:
1. Host this PWA on HTTPS (Vercel can host a static site).
2. Wrap it with Capacitor in an Android project, or use a Trusted Web Activity.
3. Build/sign the APK with Android Studio/Gradle.
4. Test on real devices and review Google Play policies before publishing.

Real unused-data resale requires agreements/API support from telecom operators. This demo does not access carrier data, move data between users, or pay money.
