# Hinata AI Assistant — HopWeb APK package

## What was added
- `hopweb/index.html`: standalone HTML/CSS/JS build designed for HopWeb's website-to-APK workflow.
- Text chat through `/api/chat`.
- Tap-to-record microphone input; no automatic/background microphone listening.
- HTTPS backend URL saved locally on the device.
- WebSocket connection to `/ws/live` with REST fallback.
- CORS support added to `server.ts` so a packaged WebView can call the backend.
- The original React + Capacitor project is preserved.

## Important
This app still needs a backend for Gemini requests. The Gemini API key stays on the backend; do **not** put it into `index.html`.

## HopWeb
Import the `hopweb` folder as the web project and use `hopweb/index.html` as the homepage. Set the app name to **Hinata AI Assistant** and choose your icon. Internet/network access is required because the APK calls your HTTPS backend.

The project should be treated as a web app wrapper: HopWeb converts the HTML/CSS/JS into an Android WebView APK. 
