package com.raahpret.costing

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import java.io.File

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var backupFolderUri: Uri? = null
    private var pendingFileChooser: ValueCallback<Array<Uri>>? = null
    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pendingFileChooser?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        pendingFileChooser = null
    }
    private val prefs by lazy { getSharedPreferences("raahpret", MODE_PRIVATE) }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                backupFolderUri = uri
                prefs.edit().putString("backup_folder_uri", uri.toString()).apply()
                Toast.makeText(this, "Backup folder selected. Automatic backup is enabled.", Toast.LENGTH_LONG).show()
                val last = File(filesDir, "RaahPretBackup/RaahPret_Backup.json")
                if (last.exists()) writeToSelectedFolder(last.readText())
            } catch (e: Exception) {
                Toast.makeText(this, "Folder permission could not be saved.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backupFolderUri = prefs.getString("backup_folder_uri", null)?.let { Uri.parse(it) }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileChooser?.onReceiveValue(null)
                pendingFileChooser = filePathCallback
                imagePicker.launch("image/*")
                return true
            }
        }
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(PhoneBackupBridge(), "AndroidBackup")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class PhoneBackupBridge {
        @JavascriptInterface
        fun saveBackup(json: String) {
            runOnUiThread {
                try {
                    val dir = File(filesDir, "RaahPretBackup")
                    if (!dir.exists()) dir.mkdirs()
                    File(dir, "RaahPret_Backup.json").writeText(json)
                    writeToSelectedFolder(json)
                } catch (_: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "Automatic backup failed. Check phone storage.", Toast.LENGTH_LONG).show() }
                }
            }
        }

        @JavascriptInterface
        fun pickBackupFolder() {
            runOnUiThread { folderPicker.launch(null) }
        }
    }

    private fun writeToSelectedFolder(json: String) {
        val uri = backupFolderUri ?: return
        try {
            val tree = DocumentFile.fromTreeUri(this, uri) ?: return
            val file = tree.findFile("RaahPret_Backup.json") ?: tree.createFile("application/json", "RaahPret_Backup.json") ?: return
            contentResolver.openOutputStream(file.uri, "wt")?.bufferedWriter()?.use { it.write(json) }
        } catch (_: Exception) {
            runOnUiThread { Toast.makeText(this, "Internal backup saved, but Documents folder backup failed.", Toast.LENGTH_LONG).show() }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
