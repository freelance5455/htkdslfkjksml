# Raah Pret Pro Costing — Android project

This is an Android Studio project source, not a precompiled APK.

## Features
- Runs as an installed Android app (WebView inside the APK; does not open Chrome).
- Keeps costing data locally on the phone.
- On every save/edit/delete/import, writes `RaahPret_Backup.json` to the app's private internal folder: `files/RaahPretBackup/`.
- Optional one-time folder selection lets the app also update `RaahPret_Backup.json` in a user-selected phone folder (for example Documents/RaahPretBackup), offline.
- No internet permission is requested and no cloud service is used.

## Build APK
1. Open this folder in Android Studio (current stable version).
2. Allow Android Studio to install the Android SDK Platform 35 and Gradle dependencies if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer that APK to the phone and install it. Android may ask you to allow installation from that file app.

## Important
- The app-private backup is automatically updated but is removed if the app is uninstalled or its app data is cleared. For a more durable phone-storage copy, tap **Set phone backup folder** once and select `Documents/RaahPretBackup` (create that folder first if desired). The app will then update that JSON file on each save.
- Chrome's existing localStorage data does not automatically migrate into this Android app. Before switching, use **Export backup** in the Chrome version, then open the Android app and use **Import backup** to bring your designs across.
- This source project has not been built or tested on a physical device in this environment; an APK is not included.
