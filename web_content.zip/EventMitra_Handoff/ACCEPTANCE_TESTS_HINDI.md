# Event Mitra — अंतिम टेस्ट सूची (मालिक के लिए)

हर test को वास्तविक Android फोन पर करके परिणाम लिखें। केवल स्क्रीनशॉट पर्याप्त नहीं है।

## Booking और cloud sync
- [ ] ग्राहक A के फोन से booking भेजने पर server-confirmed booking reference मिलता है.
- [ ] उसी booking को मालिक के दूसरे फोन के admin panel में दिखाया जाता है.
- [ ] ऐप बंद करके दोबारा खोलने पर booking cloud से फिर दिखती है.
- [ ] ग्राहक B, ग्राहक A की booking नहीं देख सकता.
- [ ] एक ही बटन को बार-बार दबाने पर अनजाने duplicate bookings नहीं बनतीं या duplicates स्पष्ट रूप से handle होते हैं.
- [ ] इंटरनेट बंद होने पर ऐप booking सफल होने का झूठा संदेश नहीं देता.
- [ ] गलत फोन नंबर, खाली आवश्यक fields और पुरानी/अमान्य तारीख reject होती है.

## Admin और permissions
- [ ] बिना login के admin data नहीं दिखता.
- [ ] सामान्य customer admin actions नहीं कर सकता.
- [ ] Admin status Pending से Confirmed/Rejected/Cancelled/Completed में बदल सकता है.
- [ ] Status change customer के account में दिखाई देता है.
- [ ] Unauthorized database access test fail-closed होता है.

## Notifications
- [ ] नई booking पर owner notification आता है (अगर push notification scope में है).
- [ ] Status update पर customer notification आता है.
- [ ] Notification न आए तब भी booking status database में सही रहता है.

## Data, privacy, release
- [ ] Service list और price/package update सही दिखाई देते हैं.
- [ ] Export/backup (यदि scope में है) में अपेक्षित records आते हैं.
- [ ] Privacy policy और contact details उपलब्ध हैं.
- [ ] App uninstall/reinstall के बाद cloud bookings उपलब्ध रहती हैं जब user फिर login करता है.
- [ ] Release APK साफ Android install में चलता है.
- [ ] Developer source code, build steps, backend ownership and cost handover देता है.

## Owner sign-off
- APK version: ____________________
- Test date: ______________________
- Pending issues: __________________
- Owner approval: __________________
