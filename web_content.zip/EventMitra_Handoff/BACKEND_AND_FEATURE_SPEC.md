# Event Mitra — ऑनलाइन फीचर और Backend Specification

## A. ग्राहक ऐप
- Home screen, search/filter, category and service detail.
- Initial categories: Wedding Photography, Videography, Pre-wedding, Birthday Photography, Birthday Decoration, Tent & Decoration, DJ & Sound, Catering, Bridal Makeup, Mehendi, Other Events.
- Booking form fields: customer name, verified/validated phone, service ID, event type, event date/time, event address/location, budget range, notes, created timestamp, status.
- Generate unique booking reference on server; prevent accidental duplicate submission.
- Customer should only see their own bookings after authentication.
- Statuses: Pending, Confirmed, Rejected, Cancelled, Completed. State changes should be validated server-side.
- Friendly empty/error/loading/offline states; do not tell user a booking succeeded until server confirms it.

## B. Owner/Admin
- Separate secure owner role. No public sign-up as admin.
- Admin can list/search/filter bookings, view details, update status, manage service listings/photos/prices, and export data if supported.
- Protect all admin operations with server-side authorization/security rules, not only hidden UI buttons.
- Log important changes with actor and timestamp.
- Owner account recovery method and access handover must be documented.

## C. Online database — logical data model
Suggested collections/tables (adapt as needed):
- `users`: auth UID, display name, phone, role (`customer`/`admin`/`provider`), createdAt.
- `services`: serviceId, name, category, description, image URL, price label/range, active, updatedAt.
- `bookings`: bookingId, customerUid, customerName, customerPhone, serviceId, serviceNameSnapshot, eventType, eventDateTime, location, budget, notes, status, createdAt, updatedAt, assignedProviderId (optional).
- `bookingEvents`: bookingId, actorUid, oldStatus, newStatus, note, createdAt.
- `deviceTokens` (optional): uid, token, platform, updatedAt; handle token refresh and deletion.

Do not trust role, price, status, or user ID values submitted by an unauthenticated client. Enforce permissions on the backend/database rules.

## D. Security and privacy
- Use secure authentication; OTP provider configuration and cost must be explained before implementation.
- Customers can read their own bookings; only authorized admins can read all bookings or change services/admin fields.
- Block unauthenticated writes and unauthorized role changes.
- Validate fields and booking date; rate-limit or otherwise protect abuse where appropriate.
- No private service credentials, service-account keys, or admin passwords in source control or APK.
- Publish a privacy policy describing collected personal data, purpose, retention, contact and deletion process.
- Configure backups/export and document restore steps.

## E. Notifications
- Push notification to owner for new booking; customer for status updates.
- Notifications are best-effort; the database status remains the source of truth.
- If WhatsApp/SMS is requested, identify provider, template/consent requirements and recurring charges separately.

## F. Payment (not mandatory for first release)
- Default first release may collect booking requests without taking payment.
- Do not simulate payment as real. If added, use a legitimate payment gateway, server-side verification/webhooks, transaction status and refund handling. Quote gateway costs separately.

## G. Android implementation and release
- Add required internet/network permissions and dependencies as needed.
- Handle lifecycle, offline/network failures, loading, retries, and safe links.
- Keep app signing keys under owner's secure control; do not send private signing keys in a public repo.
- Provide signed release APK and debug APK as agreed, version number, release notes, build instructions and SHA-256 checksum.
- If WebView remains in use, ensure navigation is restricted and JavaScript bridge exposes only minimal safe functionality.

## H. Operational ownership
- Cloud project, domain, storage, app publishing account, and billing should be created in the owner's name where possible.
- Developer gets only required permissions; transfer/revoke access at handover.
- Provide monthly/annual running cost estimate and service limits before launch.
