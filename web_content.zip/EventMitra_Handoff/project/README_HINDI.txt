EVENT MITRA - ANDROID APP SOURCE PROJECT

Is project mein Event Mitra ka Android WebView demo app hai.

Features:
- Photography, wedding, birthday, decoration, DJ, catering aur makeup services
- Service search aur category filter
- Booking request form
- Is device par bookings dekhna aur demo status badalna
- CSV export; Android par save location choose karne ka dialog
- Event Mitra branding aur mobile-friendly layout

APK banane ke liye Android Studio, Android SDK aur internet connection chahiye:
1. ZIP extract karein.
2. Android Studio mein EventMitraAndroid folder Open karein.
3. Gradle Sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

IMPORTANT LIMITATIONS:
Yeh abhi demo app hai. Bookings sirf isi device/app ke local storage mein save hoti hain.
Cloud sync, secure admin/provider login, provider notifications, real payment gateway,
production privacy policy aur Play Store release setup abhi shamil nahi hain.
Admin panel password-protected nahi hai; real customer data na rakhein.
APK is package mein include nahi hai aur is environment mein compile/test nahi hua.

OPTIONAL: GitHub Actions se cloud build
Is project mein .github/workflows/build-apk.yml diya hai. Project ko GitHub repository mein upload
karne ke baad Actions tab se "Build Event Mitra APK" workflow chalaya ja sakta hai. Build safal
hone par Actions run ke Artifacts section se EventMitra-debug-apk download karein. GitHub account
ki zaroorat hogi; workflow ki safalta platform ki build availability par nirbhar hai.


APP BRANDING / CONTACT DETAILS
Company: Golu Digital Studio
Owner: Golu Chauhan
Mobile: 9236190528
Address: Gram Sandaha, Post Umaraha, Thana Chaubepur, District Varanasi, Uttar Pradesh - 221112

Important: This ZIP is Android source code, not a compiled APK. Build and test in an Android/Gradle environment before installation. Demo bookings are stored locally on the device; no live cloud booking, secure admin login, provider notifications, or real payments are configured.
