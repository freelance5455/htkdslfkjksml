# Event Mitra — डेवलपर के लिए पूरा प्रोजेक्ट ब्रीफ

## 1. ग्राहक/मालिक की जानकारी
- ऐप का नाम: Event Mitra
- व्यवसाय: Golu Digital Studio
- मालिक: Golu Chauhan
- संपर्क: 9236190528
- पता: Gram Sandaha, Post Umaraha, Thana Chaubepur, District Varanasi, Uttar Pradesh - 221112

## 2. इस ZIP में क्या है
- `project/`: पहले से उपलब्ध Android Studio WebView demo source project.
- `project/app/src/main/assets/index.html`: मौजूदा मोबाइल-फ्रेंडली demo interface और booking form.
- `project/README_HINDI.txt`: मौजूदा प्रोजेक्ट और सीमाएँ.
- `BACKEND_AND_FEATURE_SPEC.md`: ऑनलाइन backend और सुविधाओं की तकनीकी आवश्यकता.
- `ACCEPTANCE_TESTS_HINDI.md`: ऐप स्वीकार करने से पहले टेस्ट सूची.
- `DEVELOPER_HANDOVER_CHECKLIST.md`: डिलीवरी और लागत/स्वामित्व की शर्तें.

## 3. महत्वपूर्ण स्थिति — कृपया गलत दावा न करें
यह ZIP **डेवलपर को काम सौंपने के लिए source + specification package** है, अंतिम ऑनलाइन ऐप नहीं। मौजूदा demo में bookings browser/app के localStorage में ही सेव होती हैं। इसमें live cloud database, वास्तविक सुरक्षित admin login, deployed backend, OTP, push notifications या payment gateway configured नहीं हैं। इस ZIP में compiled APK शामिल नहीं है और Android build/test की सफलता की पुष्टि नहीं की गई है।

डेवलपर को online backend implement, secure, deploy और test करना होगा। Firebase/Google/other provider के credentials या billing-enabled project अभी शामिल नहीं हैं; वे मालिक के नियंत्रण वाले अकाउंट میں بنیں گے۔ किसी भी secret/API private key को ZIP या source code में hardcode न करें।

## 4. अपेक्षित अंतिम परिणाम
1. Android फोन पर install होने वाली APK.
2. ग्राहक द्वारा भेजी गई booking cloud database में सेव हो.
3. मालिक अपने मोबाइल से सुरक्षित admin panel/app में सभी bookings देख सके.
4. booking status change और notifications काम करें.
5. मालिक को पूरा source code, backend configuration instructions, database rules, backups, release APK और test evidence मिले.

## 5. प्रस्तावित तकनीकी दिशा
डेवलपर उपयुक्त तकनीक चुन सकता है। एक संभव विकल्प: Android app + Firebase Authentication + Cloud Firestore + Firebase Cloud Messaging; या equivalent secure backend. Architecture का चुनाव, recurring charges और limitations काम शुरू होने से पहले लिखित में स्वीकृत हों।

## 6. काम की प्राथमिकता
- Phase A: मौजूदा source audit और fixed-price/time estimate.
- Phase B: cloud database, secure owner/admin authentication and booking CRUD.
- Phase C: customer booking flow, booking status tracking and notifications.
- Phase D: security rules, privacy policy, error handling, backup and QA.
- Phase E: release APK, source handover, owner training and final tests.

## 7. स्वीकृति की शर्त
मालिक को demo में दो अलग-अलग मोबाइल/इंस्टॉल से booking बनाकर दिखाएँ। एक फोन से बनी booking दूसरे फोन के admin view में दिखनी चाहिए; status update के बाद ग्राहक के view में updated status आना चाहिए। सिर्फ screenshot या local-only demo को पूर्ण ऑनलाइन ऐप न माना जाए।
