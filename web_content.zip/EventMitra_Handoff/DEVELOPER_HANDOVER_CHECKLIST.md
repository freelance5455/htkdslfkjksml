# डेवलपर से लिखित में तय करने वाली शर्तें

काम शुरू होने से पहले:
- [ ] कुल development cost और deliverables लिखित में.
- [ ] Milestones और अनुमानित delivery dates.
- [ ] Cloud/database/hosting/OTP/SMS/WhatsApp/payment/Play Store का recurring खर्च अलग-अलग.
- [ ] कौन-सी सुविधाएँ first release में होंगी और कौन-सी बाद में.
- [ ] Source code और backend configuration का मालिकाना हक ग्राहक को.
- [ ] सभी cloud/domain/publishing accounts ग्राहक के नियंत्रण में.
- [ ] Privacy policy और customer-data retention/deletion approach.
- [ ] Bug-fix warranty/support अवधि.
- [ ] Payment milestones: demo, online backend, QA, final handover.

डिलीवरी के समय:
- [ ] Release APK और agreed debug APK.
- [ ] पूरा source code/repository.
- [ ] Database security rules/backend source and deployment instructions.
- [ ] Admin login सुरक्षित तरीके से handover; password chat/ZIP में न रखें.
- [ ] Build/install guide और test evidence.
- [ ] Backup/export और restore guide.
- [ ] Monthly cost and account ownership confirmed.
- [ ] Acceptance test checklist signed off.
