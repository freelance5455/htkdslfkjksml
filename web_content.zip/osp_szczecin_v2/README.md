# OSP Szczecin 2.0

Pełny prototyp full-stack: Express + SQLite + JWT + bcrypt + Web Push.

## Uruchomienie
Wymaga Node.js 18+.

    npm install
    npm start

Otwórz http://localhost:3000

Konta demonstracyjne:
- strazak / osp1234
- dowodca / osp1234

## Funkcje
- prawdziwe logowanie z hasłami haszowanymi bcrypt
- sesja JWT w ciasteczku HTTP-only
- baza SQLite
- role STRAZAK / DOWODCA
- baza strażaków
- panel dowódcy
- obsada pojazdów z miejscami
- rejestr alarmów
- Web Push
- PWA/service worker

## Web Push
Do prawdziwych powiadomień poza localhost ustaw VAPID:
1. wygeneruj parę kluczy VAPID (np. narzędziem web-push)
2. ustaw VAPID_SUBJECT i VAPID_KEYS
3. wdroż aplikację na HTTPS

## Ważne przed wdrożeniem OSP
Zmienić JWT_SECRET, hasła demo i politykę cookies; wymusić HTTPS; dodać CSRF/rate limiting, audyt logowań, kopie bazy, reset haseł, 2FA dla dowódców oraz odpowiednie zabezpieczenia danych. Nie należy używać tego prototypu jako systemu alarmowania operacyjnego bez testów i formalnego zatwierdzenia.
