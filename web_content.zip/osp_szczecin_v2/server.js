const express=require("express");
const path=require("path"), fs=require("fs");
const bcrypt=require("bcryptjs"), jwt=require("jsonwebtoken"), cookie=require("cookie-parser");
const Database=require("better-sqlite3"), webpush=require("web-push");
const app=express(), PORT=process.env.PORT||3000;
const DATA=path.join(__dirname,"data"); fs.mkdirSync(DATA,{recursive:true});
const db=new Database(path.join(DATA,"osp.sqlite"));
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,login TEXT UNIQUE,password TEXT,role TEXT,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS vehicles(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,registration TEXT,status TEXT);
CREATE TABLE IF NOT EXISTS crew(id INTEGER PRIMARY KEY AUTOINCREMENT,vehicle_id INTEGER,user_id INTEGER,seat TEXT,assigned_at TEXT);
CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,address TEXT,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS subscriptions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,endpoint TEXT UNIQUE,p256dh TEXT,auth TEXT);
`);
const count=db.prepare("SELECT COUNT(*) c FROM users").get().c;
if(!count){
 const pw=bcrypt.hashSync("osp1234",10);
 db.prepare("INSERT INTO users(name,login,password,role) VALUES (?,?,?,?)").run("Krzysztof Nowak","strazak",pw,"STRAZAK");
 db.prepare("INSERT INTO users(name,login,password,role) VALUES (?,?,?,?)").run("Dowódca Jednostki","dowodca",pw,"DOWODCA");
 db.prepare("INSERT INTO vehicles(name,registration,status) VALUES (?,?,?)").run("GBA 3/16","ZS 00001","DOSTĘPNY");
 db.prepare("INSERT INTO vehicles(name,registration,status) VALUES (?,?,?)").run("SLRr","ZS 00002","DOSTĘPNY");
}
let vapid;
try{
 vapid=JSON.parse(process.env.VAPID_KEYS||"null");
}catch{}
if(vapid) webpush.setVapidDetails(process.env.VAPID_SUBJECT||"mailto:osp@example.pl",vapid.publicKey,vapid.privateKey);

app.use(express.json({limit:"200kb"})); app.use(cookie()); app.use(express.static(path.join(__dirname,"public")));
const SECRET=process.env.JWT_SECRET||"zmien-ten-sekret-przed-produkcja";
function auth(req,res,next){
 try{req.user=jwt.verify(req.cookies.osp_token,SECRET);next()}catch{res.status(401).json({error:"Brak autoryzacji"});}
}
function admin(req,res,next){if(req.user.role!=="DOWODCA")return res.status(403).json({error:"Tylko dowódca"});next()}

app.post("/api/login",(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE login=? AND active=1").get(req.body.login);
 if(!u||!bcrypt.compareSync(req.body.password,u.password))return res.status(401).json({error:"Nieprawidłowy login lub hasło"});
 const token=jwt.sign({id:u.id,name:u.name,role:u.role},SECRET,{expiresIn:"12h"});
 res.cookie("osp_token",token,{httpOnly:true,sameSite:"lax",secure:false,maxAge:43200000});
 res.json({id:u.id,name:u.name,role:u.role});
});
app.post("/api/logout",(req,res)=>{res.clearCookie("osp_token");res.json({ok:true})});
app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/users",auth,(req,res)=>{
 const rows=db.prepare("SELECT id,name,login,role,active FROM users ORDER BY name").all();res.json(rows);
});
app.post("/api/users",auth,admin,(req,res)=>{
 const {name,login,password,role="STRAZAK"}=req.body;
 if(!name||!login||!password)return res.status(400).json({error:"Brak danych"});
 try{const hash=bcrypt.hashSync(password,10);const r=db.prepare("INSERT INTO users(name,login,password,role) VALUES (?,?,?,?)").run(name,login,hash,role);res.json({id:r.lastInsertRowid})}
 catch{res.status(409).json({error:"Login już istnieje"})}
});
app.get("/api/vehicles",auth,(req,res)=>res.json(db.prepare("SELECT * FROM vehicles").all()));
app.get("/api/crew",auth,(req,res)=>res.json(db.prepare(`SELECT c.*,u.name user_name,v.name vehicle_name FROM crew c JOIN users u ON u.id=c.user_id JOIN vehicles v ON v.id=c.vehicle_id ORDER BY v.id,c.id`).all()));
app.post("/api/crew",auth,admin,(req,res)=>{
 const {vehicle_id,user_id,seat}=req.body;
 db.prepare("DELETE FROM crew WHERE vehicle_id=? AND seat=?").run(vehicle_id,seat);
 const r=db.prepare("INSERT INTO crew(vehicle_id,user_id,seat,assigned_at) VALUES (?,?,?,datetime('now'))").run(vehicle_id,user_id,seat);
 res.json({id:r.lastInsertRowid});
});
app.delete("/api/crew/:id",auth,admin,(req,res)=>{db.prepare("DELETE FROM crew WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/incidents",auth,(req,res)=>res.json(db.prepare("SELECT * FROM incidents ORDER BY id DESC LIMIT 20").all()));
app.post("/api/incidents",auth,admin,async(req,res)=>{
 const {title,address}=req.body;
 const r=db.prepare("INSERT INTO incidents(title,address,status,created_at) VALUES (?,?,?,datetime('now'))").run(title,address,"AKTYWNE");
 const incident={id:r.lastInsertRowid,title,address};
 const subs=db.prepare("SELECT * FROM subscriptions").all();
 if(vapid){
  await Promise.allSettled(subs.map(s=>webpush.sendNotification({endpoint:s.endpoint,keys:{p256dh:s.p256dh,auth:s.auth}},JSON.stringify({title:"🚨 OSP Szczecin",body:title+" — "+address,incident}))));
 }
 res.json(incident);
});
app.post("/api/subscriptions",auth,(req,res)=>{
 const s=req.body; if(!s.endpoint||!s.keys)return res.status(400).json({error:"Nieprawidłowa subskrypcja"});
 db.prepare("INSERT OR REPLACE INTO subscriptions(user_id,endpoint,p256dh,auth) VALUES (?,?,?,?)").run(req.user.id,s.endpoint,s.keys.p256dh,s.keys.auth);
 res.json({ok:true});
});
app.get("/api/push-public-key",auth,(req,res)=>res.json({publicKey:vapid?.publicKey||null}));

app.listen(PORT,()=>console.log(`OSP Szczecin V2: http://localhost:${PORT}`));