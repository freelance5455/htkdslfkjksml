# Grub Wavi Crypto — proyek Android

Proyek ini membungkus file HTML yang diberikan menjadi aplikasi Android sederhana menggunakan WebView.

## Yang sudah disiapkan
- HTML asli disimpan di `app/src/main/assets/index.html`
- Nama aplikasi: Grub Wavi Crypto
- ID aplikasi: `com.grubwavi.crypto`
- Izin internet untuk mengambil data harga CoinGecko
- Alur build APK debug melalui GitHub Actions

## Penting
- Ini adalah **kode sumber proyek**, bukan APK/AAB siap unggah.
- APK debug hanya untuk pengujian; jangan unggah APK debug ke Google Play.
- Untuk Google Play, aplikasi baru umumnya perlu Android App Bundle (AAB) yang ditandatangani dengan kunci rilis, serta pemenuhan persyaratan Play Console, kebijakan privasi, deklarasi data, dan pengujian yang berlaku.
- Periksa syarat layanan dan batas permintaan CoinGecko. Aplikasi ini hanya informasi harga, bukan saran investasi.
- Sebelum rilis, tambahkan ikon aplikasi, materi listing, kebijakan privasi yang sesuai dengan perilaku aplikasi, serta pengujian pada perangkat nyata.

## Build dengan Android Studio
1. Ekstrak ZIP ini di komputer.
2. Buka folder proyek di Android Studio.
3. Izinkan Gradle menyinkronkan proyek.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)** untuk membuat APK pengujian.

## Build APK pengujian lewat GitHub Actions
1. Buat repositori GitHub baru dan unggah seluruh isi folder proyek ini.
2. Buka tab **Actions** dan jalankan workflow **Build debug APK** (atau dorong commit ke branch `main`).
3. Setelah workflow selesai, buka hasil run dan unduh artifact `grub-wavi-crypto-debug-apk`.
4. APK itu untuk uji coba saja, bukan untuk publikasi langsung.

## Sebelum publikasi Google Play
Perlu dibuat build release AAB bertanda tangan. Jangan bagikan ke siapa pun file keystore atau kata sandinya. Selesaikan juga pemeriksaan kebijakan Google Play dan pengujian yang diwajibkan untuk jenis akun Anda.
