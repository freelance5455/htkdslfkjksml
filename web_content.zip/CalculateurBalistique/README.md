# Calculateur Balistique - Application Android

Application Android qui affiche le calculateur balistique HTML en plein écran.

## Comment générer l'APK

### Méthode recommandée (Android Studio)

1. **Ouvre Android Studio**
2. **File → Open** et sélectionne le dossier `CalculateurBalistique`
3. Android Studio va automatiquement télécharger Gradle et les dépendances (la première fois ça peut prendre 2-5 minutes)
4. Une fois le projet synchronisé :
   - Clique sur **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - Ou pour une version installable signée : **Build → Generate Signed Bundle / APK**

5. L'APK se trouve ensuite dans :
   `app/build/outputs/apk/debug/app-debug.apk`

### Installation sur ton téléphone

- Active le **mode développeur** + **sources inconnues** (ou installe via USB avec `adb install`)
- Transfère le fichier `app-debug.apk` et installe-le

## Contenu du projet

- `app/src/main/assets/index.html` → Ton calculateur balistique
- Icône personnalisée (réticule doré sur fond sombre)
- WebView optimisée (JavaScript activé, hors ligne)

## Package

- **Nom** : Calculateur Balistique
- **Package** : `com.balistique.calculateur`
- **Min Android** : 7.0 (API 24)

---

Si tu as un problème lors de l'ouverture dans Android Studio, dis-le moi.
