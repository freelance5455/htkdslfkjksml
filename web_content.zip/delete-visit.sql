-- Delete exactly one stored visit from an item
-- Run this entire script once in Supabase SQL Editor.

create or replace function public.delete_visit(
  p_item_id uuid,
  p_day date,
  p_visit_id text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item public.items%rowtype;
  v_entry jsonb;
  v_filtered jsonb;
  v_new_progress jsonb := '[]'::jsonb;
  v_day_found boolean := false;
  v_visit_found boolean := false;
  v_legacy_given numeric := 0;
  v_legacy_visits integer := 0;
  v_legacy_notes text := '';
  v_given numeric := 0;
  v_count integer := 0;
  v_notes text := '';
  v_visit_notes text := '';
  v_visit_given numeric := 0;
  v_item_id uuid := p_item_id;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_item
  from public.items
  where id = p_item_id;

  if not found then
    raise exception 'Item not found';
  end if;

  if v_item.owner_id <> auth.uid() and not public.is_admin() then
    raise exception 'You are not allowed to change this item';
  end if;

  for v_entry in
    select value
    from jsonb_array_elements(coalesce(v_item.daily_progress, '[]'::jsonb))
  loop
    if v_entry->>'date' = p_day::text then
      v_day_found := true;

      if jsonb_typeof(v_entry->'visits') <> 'array' then
        raise exception 'This daily record has no individual visit data';
      end if;

      select
        coalesce(jsonb_agg(v), '[]'::jsonb)
      into v_filtered
      from jsonb_array_elements(v_entry->'visits') as t(v)
      where coalesce(v->>'id','') <> p_visit_id;

      if jsonb_array_length(v_filtered) = jsonb_array_length(v_entry->'visits') then
        raise exception 'The selected visit was not found';
      end if;

      v_visit_found := true;
      v_legacy_given := coalesce(nullif(v_entry->>'legacy_given','')::numeric, 0);
      v_legacy_visits := coalesce(nullif(v_entry->>'legacy_visits','')::integer, 0);
      v_legacy_notes := coalesce(v_entry->>'legacy_notes','');

      select coalesce(sum(coalesce(nullif(v->>'given','')::numeric,0)),0)
      into v_given
      from jsonb_array_elements(v_filtered) as t(v);
      v_given := v_given + v_legacy_given;

      v_count := v_legacy_visits + jsonb_array_length(v_filtered);

      select coalesce(string_agg(note,' | '),'')
      into v_visit_notes
      from (
        select nullif(v->>'notes','') as note
        from jsonb_array_elements(v_filtered) as t(v)
        where nullif(v->>'notes','') is not null
      ) q;

      v_notes := concat_ws(' | ',
        nullif(v_legacy_notes,''),
        nullif(v_visit_notes,'')
      );

      if v_count > 0 or v_given <> 0 or v_notes <> '' then
        v_entry := jsonb_set(v_entry, '{visits}', v_filtered, true);
        v_entry := jsonb_set(v_entry, '{given}', to_jsonb(v_given), true);
        v_entry := jsonb_set(v_entry, '{visits_count}', to_jsonb(v_count), true);
        v_entry := jsonb_set(v_entry, '{visited}', to_jsonb(v_count > 0), true);
        v_entry := jsonb_set(v_entry, '{notes}', to_jsonb(v_notes), true);
        v_new_progress := v_new_progress || jsonb_build_array(v_entry);
      end if;
    else
      v_new_progress := v_new_progress || jsonb_build_array(v_entry);
    end if;
  end loop;

  if not v_day_found then
    raise exception 'The selected day was not found';
  end if;
  if not v_visit_found then
    raise exception 'The selected visit was not found';
  end if;

  update public.items
  set daily_progress = v_new_progress,
      updated_at = now()
  where id = p_item_id;

  return jsonb_build_object('ok', true, 'item_id', v_item_id, 'date', p_day, 'visit_id', p_visit_id);
end;
$$;

revoke all on function public.delete_visit(uuid, date, text) from public;
grant execute on function public.delete_visit(uuid, date, text) to authenticated;
