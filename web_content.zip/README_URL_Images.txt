GB STUDY — URL Image Support

1. Extract the ZIP. Open GB_STUDY_Standalone.html in a modern browser.
2. Open profile > Admin access and sign in. Demo password: ChangeMe123! (change it in Admin Settings).
3. Platforms: add/edit a platform and use either “Icon / logo image (upload file)” OR “Icon image URL”.
4. Banners: use either “Banner image (upload file)” OR “Banner image URL”.
5. Use a direct, publicly accessible image URL ending in an image resource (PNG/JPG/WEBP recommended). Some hosts block hotlinking, so if an image does not appear, download it and upload the file instead.

Important: Admin data is saved only in this browser (localStorage). This is a demo starter, not a secure multi-device production admin. Do not use sensitive passwords. External image URLs require internet access.
