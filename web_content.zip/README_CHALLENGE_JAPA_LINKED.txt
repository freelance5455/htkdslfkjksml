VAISHNAV WORLD — JAPA-LINKED CHALLENGE PATCH

In the Admin challenge task, name the task clearly (e.g. "Complete 5 Mala Japa") and set type/taskType/category to "japa" (or include "japa"/"mala" in the task name). Set targetMala (preferred), target, goalMala, or goal to the required mala count; points is the completion reward.

The Devotee app now reads today's Japa counter and automatically updates the active challenge task progress (e.g. 1/5 mala). It completes the task once the target is reached and awards the configured challenge points through the existing deduplicated points-event system. Japa task checkboxes are replaced by read-only progress so users cannot manually claim completion.

Important: Japa counts are currently stored locally with a Firebase daily mirror. The automatic challenge progress sync requires internet and Firebase permissions. If a user reinstalls/clears app data, locally held Japa history may be lost. This ZIP was source-checked only; no APK build or live Firebase/device test was performed.
