'use strict';
// Starter licensing service. Put behind HTTPS and set ADMIN_KEY and LICENSE_SECRET.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PORT = Number(process.env.PORT || 8787);
const ADMIN_KEY = process.env.ADMIN_KEY;
const SECRET = process.env.LICENSE_SECRET;
if (!ADMIN_KEY || !SECRET || SECRET.length < 32) {
  console.error('Set ADMIN_KEY and LICENSE_SECRET (at least 32 characters) before starting.');
  process.exit(1);
}
const DB = path.join(__dirname, 'licenses.json');
function readDB(){ try{return JSON.parse(fs.readFileSync(DB,'utf8'));}catch{return {codes:{},devices:{}};} }
function writeDB(db){const tmp=DB+'.tmp';fs.writeFileSync(tmp,JSON.stringify(db,null,2),{mode:0o600});fs.renameSync(tmp,DB);}
function json(res,status,obj){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'*','access-control-allow-headers':'content-type,x-admin-key','access-control-allow-methods':'POST,GET,OPTIONS'});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>20000)reject(new Error('too large'));});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'));}catch{reject(new Error('invalid JSON'));}});});}
function randomCode(){return crypto.randomBytes(8).toString('hex').toUpperCase().match(/.{1,4}/g).join('-');}
function sign(payload){const b=Buffer.from(JSON.stringify(payload)).toString('base64url');return b+'.'+crypto.createHmac('sha256',SECRET).update(b).digest('base64url');}
function tokenValid(token){try{const [b,s]=String(token).split('.');const expected=crypto.createHmac('sha256',SECRET).update(b).digest();const got=Buffer.from(s,'base64url');if(got.length!==expected.length||!crypto.timingSafeEqual(got,expected))return null;const p=JSON.parse(Buffer.from(b,'base64url').toString());if(p.exp && p.exp<Date.now())return null;return p;}catch{return null;}}
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':'*','access-control-allow-headers':'content-type,x-admin-key','access-control-allow-methods':'POST,GET,OPTIONS'});return res.end();}
 try{
  if(req.method==='GET'&&req.url==='/health')return json(res,200,{ok:true,service:'Mortzs licensing'});
  if(req.method==='POST'&&req.url==='/admin/issue'){
   if(req.headers['x-admin-key']!==ADMIN_KEY)return json(res,401,{error:'unauthorized'});
   const b=await body(req);const plan=b.plan==='subscription'?'subscription':'lifetime';const days=plan==='lifetime'?0:Math.max(1,Math.min(3650,Number(b.days||365)));
   const code=randomCode(),db=readDB();db.codes[code]={plan,days,createdAt:Date.now(),customer:String(b.customer||'').slice(0,100),status:'active',deviceId:null};writeDB(db);return json(res,201,{code,plan,days,customer:db.codes[code].customer});
  }
  if(req.method==='POST'&&req.url==='/api/activate'){
   const b=await body(req),code=String(b.code||'').trim().toUpperCase(),deviceId=String(b.deviceId||'').slice(0,200);if(!code||!deviceId)return json(res,400,{error:'code_and_device_required'});
   const db=readDB(),lic=db.codes[code];if(!lic||lic.status!=='active')return json(res,403,{error:'invalid_or_revoked_code'});
   if(lic.deviceId&&lic.deviceId!==deviceId)return json(res,403,{error:'license_bound_to_another_device'});
   lic.deviceId=deviceId;let exp=0;if(lic.plan==='subscription'){if(!lic.expiresAt)lic.expiresAt=Date.now()+lic.days*86400000;exp=lic.expiresAt;if(exp<Date.now())return json(res,403,{error:'subscription_expired'});}
   writeDB(db);const payload={code,deviceId,plan:lic.plan,exp,issuedAt:Date.now()};return json(res,200,{token:sign(payload),plan:lic.plan,expiresAt:exp||null});
  }
  if(req.method==='POST'&&req.url==='/api/verify'){
   const b=await body(req),p=tokenValid(b.token);if(!p||p.deviceId!==b.deviceId)return json(res,403,{valid:false});const db=readDB(),lic=db.codes[p.code];if(!lic||lic.status!=='active'||lic.deviceId!==p.deviceId||(lic.expiresAt&&lic.expiresAt<Date.now()))return json(res,403,{valid:false});return json(res,200,{valid:true,plan:lic.plan,expiresAt:lic.expiresAt||null});
  }
  if(req.method==='POST'&&req.url==='/admin/list'){
   if(req.headers['x-admin-key']!==ADMIN_KEY)return json(res,401,{error:'unauthorized'});const db=readDB();return json(res,200,{licenses:Object.entries(db.codes).map(([code,v])=>({code,...v}))});
  }
  if(req.method==='POST'&&req.url==='/admin/revoke'){
   if(req.headers['x-admin-key']!==ADMIN_KEY)return json(res,401,{error:'unauthorized'});const b=await body(req),code=String(b.code||'').trim().toUpperCase(),db=readDB();if(!db.codes[code])return json(res,404,{error:'not_found'});db.codes[code].status='revoked';writeDB(db);return json(res,200,{ok:true});
  }
  return json(res,404,{error:'not_found'});
 }catch(e){return json(res,400,{error:e.message||'bad_request'});}
});
server.listen(PORT,()=>console.log(`Mortzs license service listening on ${PORT}`));
