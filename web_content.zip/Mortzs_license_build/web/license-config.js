/* قبل از انتشار، این نشانی را با آدرس HTTPS سرور مجوز خودت جایگزین کن. */
window.MORTZS_LICENSE_API = 'https://CHANGE-THIS-TO-YOUR-HTTPS-LICENSE-SERVER';
