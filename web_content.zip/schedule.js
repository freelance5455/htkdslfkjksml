/* =========================================================
   MUEEN - SCHEDULE.JS
   Weekly schedule
   Offline / localStorage
========================================================= */

(function () {

    "use strict";


    /* =====================================================
       STORAGE
    ===================================================== */

    const STORAGE = {

        current:
            "mueen_schedule_current",

        history:
            "mueen_schedule_history",

        subjects:
            "mueen_subjects",

        settings:
            "mueen_schedule_settings",

        classes:
            "mueen_classes"

    };


    /* =====================================================
       DAYS
    ===================================================== */

    const DAYS = [

        {
            id: "sunday",
            name: "الأحد"
        },

        {
            id: "monday",
            name: "الإثنين"
        },

        {
            id: "tuesday",
            name: "الثلاثاء"
        },

        {
            id: "wednesday",
            name: "الأربعاء"
        },

        {
            id: "thursday",
            name: "الخميس"
        }

    ];


    /* =====================================================
       DEFAULT SETTINGS

       بداية ونهاية طابور الصباح.
       الحصة الأولى تبدأ بعد نهاية الطابور.
    ===================================================== */

    const DEFAULT_SETTINGS = {

        queueStartTime:
            "07:15",

        queueEndTime:
            "07:30",

        lessonDuration:
            45

    };


    /* =====================================================
       STATE
    ===================================================== */

    let schedule = {

        version: 3,

        updatedAt:
            Date.now(),

        columns: [],

        assignments: {}

    };


    let settings = {

        queueStartTime:
            DEFAULT_SETTINGS.queueStartTime,

        queueEndTime:
            DEFAULT_SETTINGS.queueEndTime,

        lessonDuration:
            DEFAULT_SETTINGS.lessonDuration

    };


    let editingColumnIndex =
        -1;


    let editingBreakIndex =
        -1;


    let selectedDayId =
        null;


    let selectedColumnIndex =
        -1;


    let pendingSubject =
        "";


    let pendingClass =
        "";


    let deleteAction =
        null;


    /* =====================================================
       DOM
    ===================================================== */

    const $ = function (id) {

        return document.getElementById(id);

    };


    const scheduleTable =
        $("scheduleTable");


    const scheduleHead =
        $("scheduleHead");


    const scheduleBody =
        $("scheduleBody");


    const emptyState =
        $("emptyState");


    const addModal =
        $("addModal");


    const lessonModal =
        $("lessonModal");


    const breakModal =
        $("breakModal");


    const subjectModal =
        $("subjectModal");


    const historyModal =
        $("historyModal");


    const historyViewModal =
        $("historyViewModal");


    const deleteConfirmModal =
        $("deleteConfirmModal");


    /* =====================================================
       CREATE ID
    ===================================================== */

    function createId(prefix) {

        return (

            prefix +

            "_" +

            Date.now().toString(36) +

            "_" +

            Math.random()
                .toString(36)
                .slice(2, 8)

        );

    }


    /* =====================================================
       DEEP CLONE
    ===================================================== */

    function deepClone(value) {

        return JSON.parse(
            JSON.stringify(value)
        );

    }


    /* =====================================================
       TIME HELPERS
    ===================================================== */

    function timeToMinutes(time) {

        if (!time) {
            return null;
        }


        const parts =
            String(time).split(":");


        if (
            parts.length !== 2
        ) {

            return null;

        }


        const hours =
            Number(parts[0]);


        const minutes =
            Number(parts[1]);


        if (
            !Number.isFinite(hours) ||
            !Number.isFinite(minutes)
        ) {

            return null;

        }


        if (
            hours < 0 ||
            hours > 23 ||
            minutes < 0 ||
            minutes > 59
        ) {

            return null;

        }


        return (
            hours * 60 +
            minutes
        );

    }


    function minutesToTime(totalMinutes) {

        if (
            !Number.isFinite(totalMinutes)
        ) {

            return "";

        }


        totalMinutes =
            Math.max(
                0,
                Math.round(totalMinutes)
            );


        const hours =
            Math.floor(
                totalMinutes / 60
            );


        const minutes =
            totalMinutes % 60;


        return (

            String(hours)
                .padStart(2, "0") +

            ":" +

            String(minutes)
                .padStart(2, "0")

        );

    }


    function addMinutes(
        time,
        minutes
    ) {

        const base =
            timeToMinutes(time);


        if (
            base === null
        ) {

            return "";

        }


        return minutesToTime(
            base +
            Number(minutes || 0)
        );

    }


    /* =====================================================
       FORMAT DISPLAY TIME
       24h internal
       12h display
    ===================================================== */

    function formatDisplayTime(time) {

        if (!time) {
            return "";
        }


        const parts =
            String(time).split(":");


        if (
            parts.length !== 2
        ) {

            return time;

        }


        let hours =
            Number(parts[0]);


        const minutes =
            parts[1];


        if (
            !Number.isFinite(hours) ||
            !/^\d{2}$/.test(minutes)
        ) {

            return time;

        }


        const period =
            hours < 12
                ? "ص"
                : "م";


        hours =
            hours % 12;


        if (hours === 0) {
            hours = 12;
        }


        return (
            hours +
            ":" +
            minutes +
            " " +
            period
        );

    }


    /* =====================================================
       FORMAT TIME RANGE
       
       مهم:
       استخدام dir="ltr" يمنع انعكاس ترتيب
       البداية والنهاية داخل واجهة RTL.
    ===================================================== */

    function formatTime(start, end) {

        if (
            !start &&
            !end
        ) {

            return `
                <span
                    class="time-range"
                    dir="ltr">
                    يحدد تلقائيًا
                </span>
            `;

        }


        if (
            start &&
            end
        ) {

            return `

                <span
                    class="time-range"
                    dir="ltr">

                    <span>
                        ${escapeHtml(
                            formatDisplayTime(start)
                        )}
                    </span>

                    <span class="time-separator">
                        -
                    </span>

                    <span>
                        ${escapeHtml(
                            formatDisplayTime(end)
                        )}
                    </span>

                </span>

            `;

        }


        if (start) {

            return `

                <span
                    class="time-range"
                    dir="ltr">

                    <span>
                        ${escapeHtml(
                            formatDisplayTime(start)
                        )}
                    </span>

                    <span class="time-separator">
                        -
                    </span>

                    <span>
                        —
                    </span>

                </span>

            `;

        }


        return `

            <span
                class="time-range"
                dir="ltr">

                <span>
                    —
                </span>

                <span class="time-separator">
                    -
                </span>

                <span>
                    ${escapeHtml(
                        formatDisplayTime(end)
                    )}
                </span>

            </span>

        `;

    }


    /* =====================================================
       HTML ESCAPE
    ===================================================== */

    function escapeHtml(value) {

        return String(value ?? "")

            .replace(
                /&/g,
                "&amp;"
            )

            .replace(
                /</g,
                "&lt;"
            )

            .replace(
                />/g,
                "&gt;"
            )

            .replace(
                /"/g,
                "&quot;"
            )

            .replace(
                /'/g,
                "&#039;"
            );

    }


    /* =====================================================
       SETTINGS
    ===================================================== */

    function loadSettings() {

        settings = {

            queueStartTime:
                DEFAULT_SETTINGS.queueStartTime,

            queueEndTime:
                DEFAULT_SETTINGS.queueEndTime,

            lessonDuration:
                DEFAULT_SETTINGS.lessonDuration

        };


        try {

            const raw =
                localStorage.getItem(
                    STORAGE.settings
                );


            if (!raw) {

                updateSettingsInputs();

                return;

            }


            const parsed =
                JSON.parse(raw);


            if (
                !parsed ||
                typeof parsed !== "object"
            ) {

                updateSettingsInputs();

                return;

            }


            /*
             * النسخة الجديدة
             */

            if (
                typeof parsed.queueStartTime ===
                "string" &&
                /^\d{2}:\d{2}$/.test(
                    parsed.queueStartTime
                )
            ) {

                settings.queueStartTime =
                    parsed.queueStartTime;

            }


            if (
                typeof parsed.queueEndTime ===
                "string" &&
                /^\d{2}:\d{2}$/.test(
                    parsed.queueEndTime
                )
            ) {

                settings.queueEndTime =
                    parsed.queueEndTime;

            }


            /*
             * دعم النسخة القديمة.
             *
             * في النسخة القديمة كان هناك
             * dayStartTime فقط.
             *
             * نعتبره نهاية الطابور حتى لا
             * تتغير بداية أول حصة القديمة.
             */

            if (
                !parsed.queueEndTime &&
                typeof parsed.dayStartTime ===
                "string" &&
                /^\d{2}:\d{2}$/.test(
                    parsed.dayStartTime
                )
            ) {

                settings.queueEndTime =
                    parsed.dayStartTime;


                const oldEnd =
                    timeToMinutes(
                        parsed.dayStartTime
                    );


                if (
                    oldEnd !== null
                ) {

                    settings.queueStartTime =
                        minutesToTime(
                            Math.max(
                                0,
                                oldEnd - 15
                            )
                        );

                }

            }


            const duration =
                Number(
                    parsed.lessonDuration
                );


            if (
                Number.isFinite(duration) &&
                duration > 0
            ) {

                settings.lessonDuration =
                    Math.min(
                        180,
                        Math.max(
                            1,
                            Math.round(duration)
                        )
                    );

            }

        } catch (error) {

            console.error(
                "Mueen schedule settings load error:",
                error
            );

        }


        validateQueueTimes();

        updateSettingsInputs();

    }


    /* =====================================================
       VALIDATE QUEUE TIMES
    ===================================================== */

    function validateQueueTimes() {

        const start =
            timeToMinutes(
                settings.queueStartTime
            );


        const end =
            timeToMinutes(
                settings.queueEndTime
            );


        if (
            start === null ||
            end === null
        ) {

            settings.queueStartTime =
                DEFAULT_SETTINGS.queueStartTime;

            settings.queueEndTime =
                DEFAULT_SETTINGS.queueEndTime;

            return;

        }


        if (
            end <= start
        ) {

            settings.queueStartTime =
                DEFAULT_SETTINGS.queueStartTime;

            settings.queueEndTime =
                DEFAULT_SETTINGS.queueEndTime;

        }

    }


    /* =====================================================
       SAVE SETTINGS
    ===================================================== */

    function saveSettings() {

        localStorage.setItem(

            STORAGE.settings,

            JSON.stringify(settings)

        );

    }


    /* =====================================================
       UPDATE SETTINGS INPUTS
    ===================================================== */

    function updateSettingsInputs() {

        const queueStartInput =
            $("queueStartTimeInput");


        const queueEndInput =
            $("queueEndTimeInput");


        const durationInput =
            $("lessonDurationInput");


        if (queueStartInput) {

            queueStartInput.value =
                settings.queueStartTime;

        }


        if (queueEndInput) {

            queueEndInput.value =
                settings.queueEndTime;

        }


        if (durationInput) {

            durationInput.value =
                settings.lessonDuration;

        }


        /*
         * دعم قديم في حال بقي input قديم
         * في أي نسخة من الصفحة.
         */

        const oldStartInput =
            $("dayStartTimeInput");


        if (
            oldStartInput &&
            !queueStartInput
        ) {

            oldStartInput.value =
                settings.queueEndTime;

        }

    }


    /* =====================================================
       READ SETTINGS FROM FORM
    ===================================================== */

    function readSettingsFromForm() {

        const queueStartInput =
            $("queueStartTimeInput");


        const queueEndInput =
            $("queueEndTimeInput");


        const durationInput =
            $("lessonDurationInput");


        /*
         * بداية الطابور
         */

        if (queueStartInput) {

            const value =
                queueStartInput.value;


            if (
                /^\d{2}:\d{2}$/.test(value)
            ) {

                settings.queueStartTime =
                    value;

            }

        }


        /*
         * نهاية الطابور
         */

        if (queueEndInput) {

            const value =
                queueEndInput.value;


            if (
                /^\d{2}:\d{2}$/.test(value)
            ) {

                settings.queueEndTime =
                    value;

            }

        }


        /*
         * دعم input القديم
         */

        const oldStartInput =
            $("dayStartTimeInput");


        if (
            !queueEndInput &&
            oldStartInput
        ) {

            const value =
                oldStartInput.value;


            if (
                /^\d{2}:\d{2}$/.test(value)
            ) {

                settings.queueEndTime =
                    value;

            }

        }


        /*
         * مدة الحصة
         */

        if (durationInput) {

            let duration =
                Number(
                    durationInput.value
                );


            if (
                !Number.isFinite(duration) ||
                duration <= 0
            ) {

                duration =
                    DEFAULT_SETTINGS.lessonDuration;

            }


            settings.lessonDuration =
                Math.min(
                    180,
                    Math.max(
                        1,
                        Math.round(duration)
                    )
                );


            durationInput.value =
                settings.lessonDuration;

        }


        const start =
            timeToMinutes(
                settings.queueStartTime
            );


        const end =
            timeToMinutes(
                settings.queueEndTime
            );


        if (
            start !== null &&
            end !== null &&
            end <= start
        ) {

            showToast(
                "يجب أن تكون نهاية الطابور بعد بدايته."
            );


            settings.queueStartTime =
                DEFAULT_SETTINGS.queueStartTime;

            settings.queueEndTime =
                DEFAULT_SETTINGS.queueEndTime;


            updateSettingsInputs();

        }


        saveSettings();

    }


    /* =====================================================
       LOAD CURRENT SCHEDULE
    ===================================================== */

    function loadCurrentSchedule() {

        try {

            const raw =
                localStorage.getItem(
                    STORAGE.current
                );


            if (!raw) {

                schedule = {

                    version: 3,

                    updatedAt:
                        Date.now(),

                    columns: [],

                    assignments: {}

                };

                return;

            }


            const parsed =
                JSON.parse(raw);


            if (
                !parsed ||
                !Array.isArray(
                    parsed.columns
                )
            ) {

                throw new Error(
                    "Invalid schedule"
                );

            }


            schedule = {

                version:
                    parsed.version || 3,

                updatedAt:
                    parsed.updatedAt ||
                    Date.now(),

                columns:
                    Array.isArray(
                        parsed.columns
                    )
                        ? parsed.columns
                        : [],

                assignments:
                    parsed.assignments || {}

            };


            /*
             * تطبيع الأعمدة
             */

            schedule.columns =
                schedule.columns.map(

                    function (column) {

                        if (
                            !column ||
                            typeof column !==
                            "object"
                        ) {

                            return null;

                        }


                        const type =
                            column.type === "break"
                                ? "break"
                                : "lesson";


                        const normalized = {

                            id:
                                column.id ||
                                createId(
                                    type
                                ),

                            type:
                                type,

                            name:
                                column.name ||
                                (
                                    type === "break"
                                        ? "الفسحة"
                                        : "الحصة"
                                ),

                            start:
                                column.start || "",

                            end:
                                column.end || ""

                        };


                        if (
                            type === "break"
                        ) {

                            let duration =
                                Number(
                                    column.duration
                                );


                            /*
                             * دعم الفسح القديمة
                             * التي كانت start/end.
                             */

                            if (
                                !Number.isFinite(
                                    duration
                                ) ||
                                duration <= 0
                            ) {

                                const oldStart =
                                    timeToMinutes(
                                        column.start
                                    );


                                const oldEnd =
                                    timeToMinutes(
                                        column.end
                                    );


                                if (
                                    oldStart !== null &&
                                    oldEnd !== null &&
                                    oldEnd > oldStart
                                ) {

                                    duration =
                                        oldEnd -
                                        oldStart;

                                } else {

                                    duration =
                                        20;

                                }

                            }


                            normalized.duration =
                                Math.min(
                                    180,
                                    Math.max(
                                        1,
                                        Math.round(
                                            duration
                                        )
                                    )
                                );

                        }


                        return normalized;

                    }

                )
                .filter(Boolean);


            normalizeAssignments();


            recalculateLessonTimes();

        } catch (error) {

            console.error(
                "Mueen schedule load error:",
                error
            );


            schedule = {

                version: 3,

                updatedAt:
                    Date.now(),

                columns: [],

                assignments: {}

            };

        }

    }


    /* =====================================================
       NORMALIZE ASSIGNMENTS
       
       النسخة القديمة:
       key -> "اللغة العربية"

       النسخة الجديدة:
       key -> {
           subject: "اللغة العربية",
           className: "3/1"
       }
    ===================================================== */

    function normalizeAssignments() {

        const source =
            schedule.assignments || {};


        const normalized = {};


        Object.keys(source).forEach(

            function (key) {

                const value =
                    source[key];


                if (
                    !value
                ) {

                    return;

                }


                /*
                 * بالفعل بالشكل الجديد
                 */

                if (
                    typeof value === "object" &&
                    !Array.isArray(value)
                ) {

                    const subject =
                        String(
                            value.subject ??
                            value.subjectName ??
                            value.name ??
                            ""
                        ).trim();


                    const className =
                        String(
                            value.className ??
                            value.class ??
                            value.code ??
                            ""
                        ).trim();


                    if (subject) {

                        normalized[key] = {

                            subject:
                                subject,

                            className:
                                className

                        };

                    }


                    return;

                }


                /*
                 * الشكل القديم:
                 * قيمة نصية = المادة فقط
                 */

                if (
                    typeof value === "string"
                ) {

                    const subject =
                        value.trim();


                    if (subject) {

                        normalized[key] = {

                            subject:
                                subject,

                            className:
                                ""

                        };

                    }

                }

            }

        );


        schedule.assignments =
            normalized;

    }


    /* =====================================================
       SAVE CURRENT
    ===================================================== */

    function saveCurrent() {

        schedule.updatedAt =
            Date.now();


        localStorage.setItem(

            STORAGE.current,

            JSON.stringify(schedule)

        );

    }


    /* =====================================================
       RECALCULATE ALL TIMES
       
       الترتيب:

       نهاية الطابور
          ↓
       الحصة
          ↓
       الحصة
          ↓
       الفسحة حسب مدتها
          ↓
       الحصة التالية
    ===================================================== */

    function recalculateLessonTimes() {

        let cursor =
            timeToMinutes(
                settings.queueEndTime
            );


        if (cursor === null) {

            cursor =
                timeToMinutes(
                    DEFAULT_SETTINGS.queueEndTime
                );

        }


        schedule.columns.forEach(

            function (column) {

                if (
                    column.type === "break"
                ) {

                    let duration =
                        Number(
                            column.duration
                        );


                    if (
                        !Number.isFinite(
                            duration
                        ) ||
                        duration <= 0
                    ) {

                        duration = 20;

                    }


                    duration =
                        Math.min(
                            180,
                            Math.max(
                                1,
                                Math.round(
                                    duration
                                )
                            )
                        );


                    column.duration =
                        duration;


                    column.start =
                        minutesToTime(
                            cursor
                        );


                    cursor +=
                        duration;


                    column.end =
                        minutesToTime(
                            cursor
                        );


                    return;

                }


                column.start =
                    minutesToTime(
                        cursor
                    );


                column.end =
                    minutesToTime(

                        cursor +
                        Number(
                            settings.lessonDuration
                        )

                    );


                cursor +=
                    Number(
                        settings.lessonDuration
                    );

            }

        );

    }


    /* =====================================================
       CALCULATE TIME AT POSITION
    ===================================================== */

    function getCalculatedTimeAtPosition(
        columnIndex
    ) {

        let cursor =
            timeToMinutes(
                settings.queueEndTime
            );


        if (
            cursor === null
        ) {

            return {

                start: "",

                end: ""

            };

        }


        for (
            let i = 0;
            i <= columnIndex;
            i++
        ) {

            const column =
                schedule.columns[i];


            if (!column) {
                continue;
            }


            if (
                column.type === "break"
            ) {

                const duration =
                    Number(
                        column.duration
                    ) > 0
                        ? Number(
                            column.duration
                        )
                        : 20;


                if (
                    i === columnIndex
                ) {

                    return {

                        start:
                            minutesToTime(
                                cursor
                            ),

                        end:
                            minutesToTime(
                                cursor +
                                duration
                            )

                    };

                }


                cursor +=
                    duration;


                continue;

            }


            const start =
                minutesToTime(
                    cursor
                );


            const end =
                minutesToTime(

                    cursor +
                    Number(
                        settings.lessonDuration
                    )

                );


            if (
                i === columnIndex
            ) {

                return {

                    start:
                        start,

                    end:
                        end

                };

            }


            cursor +=
                Number(
                    settings.lessonDuration
                );

        }


        return {

            start: "",

            end: ""

        };

    }


    function getCalculatedLessonTime(
        columnIndex
    ) {

        return getCalculatedTimeAtPosition(
            columnIndex
        );

    }


    /* =====================================================
       GET NEXT POSITION TIME
    ===================================================== */

    function getCalculatedNewItemTime() {

        const index =
            schedule.columns.length;


        return getCalculatedTimeAtPosition(
            index
        );

    }


    /* =====================================================
       RENDER
    ===================================================== */

    function render() {

        recalculateLessonTimes();

        renderHeader();

        renderBody();

        updateEmptyState();

    }


    /* =====================================================
       RENDER HEADER
    ===================================================== */

    function renderHeader() {

        scheduleHead.innerHTML =
            "";


        const row =
            document.createElement("tr");


        const dayTh =
            document.createElement("th");


        dayTh.innerHTML =
            '<div class="day-header">اليوم</div>';


        row.appendChild(
            dayTh
        );


        schedule.columns.forEach(

            function (column, index) {

                const th =
                    document.createElement("th");


                if (
                    column.type === "break"
                ) {

                    th.classList.add(
                        "break-column"
                    );

                }


                th.innerHTML = `

                    <div class="lesson-header">

                        <div class="lesson-header-name">
                            ${escapeHtml(
                                column.name
                            )}
                        </div>

                        <div class="lesson-header-time">
                            ${formatTime(
                                column.start,
                                column.end
                            )}
                        </div>

                    </div>

                    <button
                        class="header-edit-button"
                        type="button"
                        title="تعديل"
                        data-edit-column="${index}">
                        ✎
                    </button>

                `;


                row.appendChild(
                    th
                );

            }

        );


        scheduleHead.appendChild(
            row
        );


        bindHeaderButtons();

    }


    /* =====================================================
       RENDER BODY
    ===================================================== */

    function renderBody() {

        scheduleBody.innerHTML =
            "";


        DAYS.forEach(

            function (day) {

                const row =
                    document.createElement("tr");


                const dayCell =
                    document.createElement("td");


                dayCell.innerHTML =
                    `<div class="day-cell">
                        ${escapeHtml(day.name)}
                    </div>`;


                row.appendChild(
                    dayCell
                );


                schedule.columns.forEach(

                    function (
                        column,
                        columnIndex
                    ) {

                        const cell =
                            document.createElement("td");


                        if (
                            column.type === "break"
                        ) {

                            cell.classList.add(
                                "break-column",
                                "break-body-cell"
                            );


                            cell.innerHTML = `

                                <div class="break-text">
                                    ${escapeHtml(
                                        column.name ||
                                        "الفسحة"
                                    )}
                                </div>

                                <div class="break-duration-text">
                                    ${column.duration || 20}
                                    دقيقة
                                </div>

                            `;


                        } else {

                            cell.classList.add(
                                "subject-cell"
                            );


                            const key =
                                getAssignmentKey(
                                    day.id,
                                    column.id
                                );


                            const assignment =
                                normalizeAssignmentValue(
                                    schedule.assignments[
                                        key
                                    ]
                                );


                            if (
                                assignment.subject
                            ) {

                                cell.innerHTML = `

                                    <div class="subject-name">
                                        ${escapeHtml(
                                            assignment.subject
                                        )}
                                    </div>

                                    ${
                                        assignment.className
                                            ? `
                                                <div class="subject-class">
                                                    ${escapeHtml(
                                                        assignment.className
                                                    )}
                                                </div>
                                            `
                                            : ""
                                    }

                                    <div class="cell-edit-mark">
                                        ✎
                                    </div>

                                `;

                            } else {

                                cell.innerHTML = `

                                    <div class="subject-empty">
                                        اضغط لاختيار المادة
                                    </div>

                                    <div class="cell-edit-mark">
                                        ＋
                                    </div>

                                `;

                            }


                            cell.addEventListener(

                                "click",

                                function () {

                                    openSubjectModal(
                                        day.id,
                                        columnIndex
                                    );

                                }

                            );

                        }


                        row.appendChild(
                            cell
                        );

                    }

                );


                scheduleBody.appendChild(
                    row
                );

            }

        );

    }


    /* =====================================================
       NORMALIZE SINGLE ASSIGNMENT
    ===================================================== */

    function normalizeAssignmentValue(
        value
    ) {

        if (!value) {

            return {

                subject: "",

                className: ""

            };

        }


        if (
            typeof value === "object" &&
            !Array.isArray(value)
        ) {

            return {

                subject:
                    String(
                        value.subject ??
                        value.subjectName ??
                        value.name ??
                        ""
                    ).trim(),

                className:
                    String(
                        value.className ??
                        value.class ??
                        value.code ??
                        ""
                    ).trim()

            };

        }


        return {

            subject:
                String(value).trim(),

            className:
                ""

        };

    }


    /* =====================================================
       HEADER BUTTONS
    ===================================================== */

    function bindHeaderButtons() {

        document
            .querySelectorAll(
                "[data-edit-column]"
            )
            .forEach(

                function (button) {

                    button.addEventListener(

                        "click",

                        function (event) {

                            event.stopPropagation();


                            const index =
                                Number(
                                    button.dataset
                                        .editColumn
                                );


                            openColumnEditor(
                                index
                            );

                        }

                    );

                }

            );

    }


    /* =====================================================
       EMPTY STATE
    ===================================================== */

    function updateEmptyState() {

        if (
            schedule.columns.length === 0
        ) {

            emptyState.style.display =
                "block";

        } else {

            emptyState.style.display =
                "none";

        }

    }


    /* =====================================================
       ADD MODAL
    ===================================================== */

    function openAddModal() {

        addModal.classList.add(
            "show"
        );

    }


    function closeAddModal() {

        addModal.classList.remove(
            "show"
        );

    }


    /* =====================================================
       LESSON
    ===================================================== */

    function openNewLessonModal() {

        editingColumnIndex =
            -1;


        $("lessonModalTitle")
            .textContent =
            "إضافة حصة";


        $("lessonNameInput")
            .value =
            getNextLessonName();


        $("deleteLessonButton")
            .style.display =
            "none";


        updateLessonCalculatedTimePreview(
            -1
        );


        lessonModal.classList.add(
            "show"
        );

    }


    function openColumnEditor(index) {

        const column =
            schedule.columns[index];


        if (!column) {
            return;
        }


        if (
            column.type === "break"
        ) {

            openBreakEditor(
                index
            );

            return;

        }


        editingColumnIndex =
            index;


        $("lessonModalTitle")
            .textContent =
            "تعديل الحصة";


        $("lessonNameInput")
            .value =
            column.name || "";


        $("deleteLessonButton")
            .style.display =
            "flex";


        updateLessonCalculatedTimePreview(
            index
        );


        lessonModal.classList.add(
            "show"
        );

    }


    function closeLessonModal() {

        lessonModal.classList.remove(
            "show"
        );


        editingColumnIndex =
            -1;

    }


    /* =====================================================
       LESSON TIME PREVIEW
    ===================================================== */

    function updateLessonCalculatedTimePreview(
        columnIndex
    ) {

        const output =
            $("lessonCalculatedTime");


        if (!output) {
            return;
        }


        let previewIndex =
            columnIndex;


        if (
            previewIndex < 0
        ) {

            previewIndex =
                schedule.columns.length;

        }


        const calculated =
            getCalculatedLessonTime(
                previewIndex
            );


        if (
            calculated &&
            calculated.start &&
            calculated.end
        ) {

            output.innerHTML =
                formatTime(
                    calculated.start,
                    calculated.end
                );

        } else {

            output.textContent =
                "سيظهر تلقائيًا";

        }

    }


    /* =====================================================
       SAVE LESSON
    ===================================================== */

    function saveLessonFromForm() {

        let name =
            $("lessonNameInput")
                .value
                .trim();


        if (!name) {

            name =
                getNextLessonName();

        }


        if (
            editingColumnIndex === -1
        ) {

            const newColumn = {

                id:
                    createId("lesson"),

                type:
                    "lesson",

                name:
                    name,

                start:
                    "",

                end:
                    ""

            };


            schedule.columns.push(
                newColumn
            );


            recalculateLessonTimes();

            saveCurrent();

            render();

            closeLessonModal();


            showToast(
                "تمت إضافة الحصة."
            );


            return;

        }


        const column =
            schedule.columns[
                editingColumnIndex
            ];


        if (!column) {
            return;
        }


        column.name =
            name;


        recalculateLessonTimes();

        saveCurrent();

        render();

        closeLessonModal();


        showToast(
            "تم تعديل الحصة."
        );

    }


    /* =====================================================
       DELETE LESSON
    ===================================================== */

    function deleteCurrentLesson() {

        if (
            editingColumnIndex < 0
        ) {
            return;
        }


        const column =
            schedule.columns[
                editingColumnIndex
            ];


        if (!column) {
            return;
        }


        openDeleteConfirmation(

            "حذف الحصة",

            "هل أنت متأكد من حذف هذه الحصة من الجدول؟ لا يمكن التراجع عن هذا الإجراء.",

            function () {

                const columnId =
                    column.id;


                schedule.columns.splice(
                    editingColumnIndex,
                    1
                );


                deleteAssignmentsForColumn(
                    columnId
                );


                recalculateLessonTimes();

                saveCurrent();

                render();

                closeLessonModal();


                showToast(
                    "تم حذف الحصة."
                );

            }

        );

    }


    /* =====================================================
       BREAK
    ===================================================== */

    function openNewBreakModal() {

        editingBreakIndex =
            -1;


        $("breakModalTitle")
            .textContent =
            "إضافة فسحة";


        $("breakNameInput")
            .value =
            "الفسحة";


        $("breakDurationInput")
            .value =
            20;


        $("deleteBreakButton")
            .style.display =
            "none";


        updateBreakCalculatedTimePreview(
            -1
        );


        breakModal.classList.add(
            "show"
        );

    }


    function openBreakEditor(index) {

        const column =
            schedule.columns[index];


        if (!column) {
            return;
        }


        editingBreakIndex =
            index;


        $("breakModalTitle")
            .textContent =
            "تعديل الفسحة";


        $("breakNameInput")
            .value =
            column.name ||
            "الفسحة";


        $("breakDurationInput")
            .value =
            Number(
                column.duration
            ) > 0
                ? Number(
                    column.duration
                )
                : 20;


        $("deleteBreakButton")
            .style.display =
            "flex";


        updateBreakCalculatedTimePreview(
            index
        );


        breakModal.classList.add(
            "show"
        );

    }


    function closeBreakModal() {

        breakModal.classList.remove(
            "show"
        );


        editingBreakIndex =
            -1;

    }


    /* =====================================================
       BREAK TIME PREVIEW
    ===================================================== */

    function updateBreakCalculatedTimePreview(
        columnIndex
    ) {

        const output =
            $("breakCalculatedTime");


        if (!output) {
            return;
        }


        let duration =
            Number(
                $("breakDurationInput")?.value
            );


        if (
            !Number.isFinite(duration) ||
            duration <= 0
        ) {

            duration =
                20;

        }


        duration =
            Math.min(
                180,
                Math.max(
                    1,
                    Math.round(
                        duration
                    )
                )
            );


        /*
         * عند تعديل فسحة موجودة:
         * نستخدم موضعها الحالي.
         *
         * عند إضافة فسحة جديدة:
         * الموضع = نهاية الجدول.
         */

        let previewIndex =
            columnIndex;


        if (
            previewIndex < 0
        ) {

            previewIndex =
                schedule.columns.length;

        }


        const calculated =
            calculateTimeWithTemporaryBreak(
                previewIndex,
                duration
            );


        if (
            calculated &&
            calculated.start &&
            calculated.end
        ) {

            output.innerHTML =
                formatTime(
                    calculated.start,
                    calculated.end
                );

        } else {

            output.textContent =
                "سيظهر تلقائيًا";

        }

    }


    function calculateTimeWithTemporaryBreak(
        index,
        duration
    ) {

        let cursor =
            timeToMinutes(
                settings.queueEndTime
            );


        if (
            cursor === null
        ) {

            return null;

        }


        for (
            let i = 0;
            i < index;
            i++
        ) {

            const column =
                schedule.columns[i];


            if (!column) {
                continue;
            }


            if (
                column.type === "break"
            ) {

                const existingDuration =
                    Number(
                        column.duration
                    ) > 0
                        ? Number(
                            column.duration
                        )
                        : 20;


                cursor +=
                    existingDuration;


            } else {

                cursor +=
                    Number(
                        settings.lessonDuration
                    );

            }

        }


        return {

            start:
                minutesToTime(
                    cursor
                ),

            end:
                minutesToTime(
                    cursor +
                    Number(duration)
                )

        };

    }


    /* =====================================================
       SAVE BREAK
    ===================================================== */

    function saveBreakFromForm() {

        let name =
            $("breakNameInput")
                .value
                .trim();


        let duration =
            Number(
                $("breakDurationInput")
                    .value
            );


        if (!name) {

            name =
                "الفسحة";

        }


        if (
            !Number.isFinite(duration) ||
            duration <= 0
        ) {

            showToast(
                "يرجى إدخال مدة الفسحة."
            );

            return;

        }


        duration =
            Math.min(
                180,
                Math.max(
                    1,
                    Math.round(
                        duration
                    )
                )
            );


        if (
            editingBreakIndex === -1
        ) {

            const newBreak = {

                id:
                    createId("break"),

                type:
                    "break",

                name:
                    name,

                duration:
                    duration,

                start:
                    "",

                end:
                    ""

            };


            schedule.columns.push(
                newBreak
            );


            recalculateLessonTimes();

            saveCurrent();

            render();

            closeBreakModal();


            showToast(
                "تمت إضافة الفسحة."
            );


            return;

        }


        const column =
            schedule.columns[
                editingBreakIndex
            ];


        if (!column) {
            return;
        }


        column.name =
            name;


        column.duration =
            duration;


        /*
         * start/end يعاد حسابهما
         * تلقائيًا ولا نقرأهما من المستخدم.
         */

        recalculateLessonTimes();

        saveCurrent();

        render();

        closeBreakModal();


        showToast(
            "تم تعديل الفسحة."
        );

    }


    /* =====================================================
       DELETE BREAK
    ===================================================== */

    function deleteCurrentBreak() {

        if (
            editingBreakIndex < 0
        ) {
            return;
        }


        const column =
            schedule.columns[
                editingBreakIndex
            ];


        if (!column) {
            return;
        }


        openDeleteConfirmation(

            "حذف الفسحة",

            "هل أنت متأكد من حذف هذه الفسحة من الجدول؟ لا يمكن التراجع عن هذا الإجراء.",

            function () {

                schedule.columns.splice(
                    editingBreakIndex,
                    1
                );


                recalculateLessonTimes();

                saveCurrent();

                render();

                closeBreakModal();


                showToast(
                    "تم حذف الفسحة."
                );

            }

        );

    }


    /* =====================================================
       SUBJECT MODAL
    ===================================================== */

    function openSubjectModal(
        dayId,
        columnIndex
    ) {

        const column =
            schedule.columns[
                columnIndex
            ];


        if (!column) {
            return;
        }


        selectedDayId =
            dayId;


        selectedColumnIndex =
            columnIndex;


        pendingSubject =
            "";


        pendingClass =
            "";


        const key =
            getAssignmentKey(
                dayId,
                column.id
            );


        const existing =
            normalizeAssignmentValue(
                schedule.assignments[key]
            );


        pendingSubject =
            existing.subject;


        pendingClass =
            existing.className;


        const day =
            DAYS.find(

                function (item) {

                    return (
                        item.id === dayId
                    );

                }

            );


        $("subjectModalDescription")
            .textContent =
            "اختر المادة ثم الصف لـ " +
            (
                day
                    ? day.name
                    : "هذا اليوم"
            ) +
            " — " +
            column.name;


        renderSubjects();


        renderClassPicker();


        subjectModal.classList.add(
            "show"
        );

    }


    function closeSubjectModal() {

        subjectModal.classList.remove(
            "show"
        );


        selectedDayId =
            null;


        selectedColumnIndex =
            -1;


        pendingSubject =
            "";


        pendingClass =
            "";

    }


    /* =====================================================
       SUBJECTS
    ===================================================== */

    function getSubjects() {

        const raw =
            localStorage.getItem(
                STORAGE.subjects
            );


        if (!raw) {
            return [];
        }


        try {

            const parsed =
                JSON.parse(raw);


            let list = [];


            if (Array.isArray(parsed)) {

                list =
                    parsed;

            } else if (
                parsed &&
                Array.isArray(
                    parsed.subjects
                )
            ) {

                list =
                    parsed.subjects;

            } else if (
                parsed &&
                Array.isArray(
                    parsed.items
                )
            ) {

                list =
                    parsed.items;

            }


            return list

                .map(

                    function (item) {

                        if (
                            typeof item ===
                            "string"
                        ) {

                            return item.trim();

                        }


                        if (
                            item &&
                            typeof item.name ===
                            "string"
                        ) {

                            return item.name.trim();

                        }


                        if (
                            item &&
                            typeof item.subjectName ===
                            "string"
                        ) {

                            return item.subjectName.trim();

                        }


                        if (
                            item &&
                            typeof item.title ===
                            "string"
                        ) {

                            return item.title.trim();

                        }


                        return "";

                    }

                )

                .filter(Boolean)

                .filter(

                    function (
                        value,
                        index,
                        array
                    ) {

                        return (
                            array.indexOf(value) ===
                            index
                        );

                    }

                );

        } catch (error) {

            console.error(
                "Subject parsing error:",
                error
            );


            return [];

        }

    }


    /* =====================================================
       RENDER SUBJECTS
    ===================================================== */

    function renderSubjects() {

        const container =
            $("subjectsList");


        if (!container) {
            return;
        }


        container.innerHTML =
            "";


        const subjects =
            getSubjects();


        if (
            subjects.length === 0
        ) {

            container.innerHTML = `

                <div class="no-subjects">

                    لا توجد مواد محفوظة حاليًا.

                    <br>

                    أضف المواد أولًا من صفحة المواد
                    ثم ستظهر هنا تلقائيًا.

                </div>

            `;


            return;

        }


        subjects.forEach(

            function (subject) {

                const button =
                    document.createElement(
                        "button"
                    );


                button.type =
                    "button";


                button.className =
                    "subject-option";


                if (
                    subject ===
                    pendingSubject
                ) {

                    button.classList.add(
                        "selected"
                    );

                }


                button.textContent =
                    subject;


                button.addEventListener(

                    "click",

                    function () {

                        pendingSubject =
                            subject;


                        /*
                         * عند تغيير المادة
                         * لا نمسح الصف المختار.
                         * يمكن الاحتفاظ بالصف ثم
                         * الضغط على الصف للتأكيد.
                         */

                        renderSubjects();

                        renderClassPicker();

                    }

                );


                container.appendChild(
                    button
                );

            }

        );

    }


    /* =====================================================
       GET CLASSES
       
       المصدر الحقيقي:
       mueen_classes
    ===================================================== */

    function getClasses() {

        try {

            const raw =
                localStorage.getItem(
                    STORAGE.classes
                );


            if (!raw) {
                return [];
            }


            const parsed =
                JSON.parse(raw);


            if (!Array.isArray(parsed)) {
                return [];
            }


            return parsed

                .filter(

                    function (item) {

                        return (
                            item &&
                            typeof item ===
                            "object"
                        );

                    }

                )

                .map(

                    function (item) {

                        const section =
                            String(
                                item.section ??
                                ""
                            ).trim();


                        const code =
                            String(
                                item.code ??
                                ""
                            ).trim();


                        let finalCode =
                            code;


                        if (
                            !finalCode &&
                            section
                        ) {

                            const gradeNumber =
                                getGradeNumberFromName(
                                    item.grade
                                );


                            if (
                                gradeNumber
                            ) {

                                finalCode =
                                    gradeNumber +
                                    "/" +
                                    section;

                            }

                        }


                        return {

                            id:
                                String(
                                    item.id ??
                                    finalCode
                                ),

                            stage:
                                String(
                                    item.stage ??
                                    ""
                                ).trim(),

                            grade:
                                String(
                                    item.grade ??
                                    ""
                                ).trim(),

                            section:
                                section,

                            code:
                                finalCode

                        };

                    }

                )

                .filter(

                    function (item) {

                        return (
                            item.code ||
                            (
                                item.grade &&
                                item.section
                            )
                        );

                    }

                );

        } catch (error) {

            console.error(
                "Class parsing error:",
                error
            );


            return [];

        }

    }


    /* =====================================================
       GRADE NUMBER
    ===================================================== */

    function getGradeNumberFromName(
        grade
    ) {

        const map = {

            "الصف الأول الابتدائي":
                "1",

            "الصف الثاني الابتدائي":
                "2",

            "الصف الثالث الابتدائي":
                "3",

            "الصف الرابع الابتدائي":
                "4",

            "الصف الخامس الابتدائي":
                "5",

            "الصف السادس الابتدائي":
                "6",

            "الصف الأول الإعدادي":
                "1",

            "الصف الثاني الإعدادي":
                "2",

            "الصف الثالث الإعدادي":
                "3",

            "الصف الأول الثانوي":
                "1",

            "الصف الثاني الثانوي":
                "2",

            "الصف الثالث الثانوي":
                "3"

        };


        return (
            map[
                String(
                    grade ??
                    ""
                ).trim()
            ] ||
            ""
        );

    }


    /* =====================================================
       RENDER CLASS PICKER
    ===================================================== */

    function renderClassPicker() {

        let container =
            $("classesList");


        /*
         * إذا لم يكن موجودًا في HTML،
         * ننشئه تلقائيًا بعد قائمة المواد.
         */

        if (!container) {

            const subjectsContainer =
                $("subjectsList");


            if (!subjectsContainer) {
                return;
            }


            container =
                document.createElement(
                    "div"
                );


            container.id =
                "classesList";


            container.className =
                "classes-list";


            subjectsContainer.insertAdjacentElement(
                "afterend",
                container
            );

        }


        container.innerHTML =
            "";


        const title =
            document.createElement(
                "div"
            );


        title.className =
            "class-picker-title";


        title.textContent =
            pendingSubject
                ? "اختر الصف والفصل"
                : "اختر المادة أولًا";


        container.appendChild(
            title
        );


        if (!pendingSubject) {

            const hint =
                document.createElement(
                    "div"
                );


            hint.className =
                "class-picker-hint";


            hint.textContent =
                "بعد اختيار المادة ستظهر الصفوف المسجلة في مُعين.";


            container.appendChild(
                hint
            );


            return;

        }


        const classes =
            getClasses();


        if (
            classes.length === 0
        ) {

            const empty =
                document.createElement(
                    "div"
                );


            empty.className =
                "no-classes";


            empty.innerHTML = `

                <strong>
                    لا توجد صفوف مسجلة
                </strong>

                <span>
                    أضف الصفوف أولًا من صفحة الطلاب.
                </span>

            `;


            container.appendChild(
                empty
            );


            return;

        }


        classes.forEach(

            function (classData) {

                const code =
                    classData.code ||
                    (
                        getGradeNumberFromName(
                            classData.grade
                        ) +
                        "/" +
                        classData.section
                    );


                const button =
                    document.createElement(
                        "button"
                    );


                button.type =
                    "button";


                button.className =
                    "class-option";


                if (
                    code ===
                    pendingClass
                ) {

                    button.classList.add(
                        "selected"
                    );

                }


                button.innerHTML = `

                    <span class="class-option-code">
                        ${escapeHtml(code)}
                    </span>

                    <span class="class-option-name">
                        ${escapeHtml(
                            classData.grade
                        )}

                        ${
                            classData.section
                                ? `
                                    — الفصل
                                    ${escapeHtml(
                                        classData.section
                                    )}
                                `
                                : ""
                        }

                    </span>

                `;


                button.addEventListener(

                    "click",

                    function () {

                        pendingClass =
                            code;


                        saveSelectedAssignment();

                    }

                );


                container.appendChild(
                    button
                );

            }

        );

    }


    /* =====================================================
       SAVE SELECTED ASSIGNMENT
       
       المادة + الصف
    ===================================================== */

    function saveSelectedAssignment() {

        if (
            !selectedDayId ||
            selectedColumnIndex < 0
        ) {

            return;

        }


        if (!pendingSubject) {

            showToast(
                "اختر المادة أولًا."
            );

            return;

        }


        if (!pendingClass) {

            showToast(
                "اختر الصف والفصل أولًا."
            );

            return;

        }


        const column =
            schedule.columns[
                selectedColumnIndex
            ];


        if (!column) {
            return;
        }


        const key =
            getAssignmentKey(
                selectedDayId,
                column.id
            );


        schedule.assignments[key] = {

            subject:
                pendingSubject,

            className:
                pendingClass

        };


        saveCurrent();

        render();

        closeSubjectModal();


        showToast(
            "تم حفظ المادة والصف."
        );

    }


    /* =====================================================
       CLEAR SUBJECT
    ===================================================== */

    function clearSelectedSubject() {

        if (
            !selectedDayId ||
            selectedColumnIndex < 0
        ) {

            return;

        }


        const column =
            schedule.columns[
                selectedColumnIndex
            ];


        if (!column) {
            return;
        }


        const key =
            getAssignmentKey(
                selectedDayId,
                column.id
            );


        if (
            !schedule.assignments[key]
        ) {

            closeSubjectModal();

            return;

        }


        openDeleteConfirmation(

            "مسح المادة",

            "هل تريد مسح المادة والصف من هذه الخلية؟",

            function () {

                delete schedule.assignments[
                    key
                ];


                saveCurrent();

                render();

                closeSubjectModal();


                showToast(
                    "تم مسح المادة من الخلية."
                );

            }

        );

    }


    /* =====================================================
       ASSIGNMENT KEY
    ===================================================== */

    function getAssignmentKey(
        dayId,
        columnId
    ) {

        return (
            dayId +
            "__" +
            columnId
        );

    }


    /* =====================================================
       DELETE COLUMN ASSIGNMENTS
    ===================================================== */

    function deleteAssignmentsForColumn(
        columnId
    ) {

        const suffix =
            "__" +
            columnId;


        Object.keys(
            schedule.assignments
        ).forEach(

            function (key) {

                if (
                    key.endsWith(
                        suffix
                    )
                ) {

                    delete schedule
                        .assignments[key];

                }

            }

        );

    }


    /* =====================================================
       LESSON NAMES
    ===================================================== */

    function getNextLessonName() {

        let count =
            0;


        schedule.columns.forEach(

            function (column) {

                if (
                    column.type === "lesson"
                ) {

                    count++;

                }

            }

        );


        count++;


        return (
            "الحصة " +
            numberToArabic(
                count
            )
        );

    }


    function numberToArabic(number) {

        const numbers = [

            "الأولى",
            "الثانية",
            "الثالثة",
            "الرابعة",
            "الخامسة",
            "السادسة",
            "السابعة",
            "الثامنة",
            "التاسعة",
            "العاشرة",
            "الحادية عشرة",
            "الثانية عشرة"

        ];


        return (
            numbers[number - 1] ||
            number
        );

    }


    /* =====================================================
       SETTINGS EVENTS
    ===================================================== */

    function handleSettingsChange() {

        readSettingsFromForm();

        validateQueueTimes();

        recalculateLessonTimes();

        saveSettings();

        saveCurrent();

        render();

        updateLessonCalculatedTimePreview(
            editingColumnIndex
        );


        updateBreakCalculatedTimePreview(
            editingBreakIndex
        );

    }


    const queueStartTimeInput =
        $("queueStartTimeInput");


    const queueEndTimeInput =
        $("queueEndTimeInput");


    const lessonDurationInput =
        $("lessonDurationInput");


    const oldDayStartTimeInput =
        $("dayStartTimeInput");


    if (queueStartTimeInput) {

        queueStartTimeInput.addEventListener(
            "change",
            handleSettingsChange
        );

    }


    if (queueEndTimeInput) {

        queueEndTimeInput.addEventListener(
            "change",
            handleSettingsChange
        );

    }


    if (oldDayStartTimeInput) {

        oldDayStartTimeInput.addEventListener(
            "change",
            handleSettingsChange
        );

    }


    if (lessonDurationInput) {

        lessonDurationInput.addEventListener(
            "change",
            handleSettingsChange
        );


        lessonDurationInput.addEventListener(
            "blur",
            handleSettingsChange
        );

    }


    const breakDurationInput =
        $("breakDurationInput");


    if (breakDurationInput) {

        breakDurationInput.addEventListener(

            "input",

            function () {

                updateBreakCalculatedTimePreview(
                    editingBreakIndex
                );

            }

        );


        breakDurationInput.addEventListener(

            "change",

            function () {

                updateBreakCalculatedTimePreview(
                    editingBreakIndex
                );

            }

        );

    }


    /* =====================================================
       SAVE HISTORY
    ===================================================== */

    function createHistorySignature(
        data
    ) {

        return JSON.stringify({

            version:
                data.version,

            settings:
                data.settings,

            columns:
                data.columns,

            assignments:
                data.assignments

        });

    }


    function saveScheduleToHistory() {

        if (
            schedule.columns.length === 0
        ) {

            showToast(
                "أضف حصة واحدة على الأقل قبل الحفظ."
            );

            return;

        }


        recalculateLessonTimes();


        const currentData = {

            version:
                schedule.version,

            settings:
                deepClone(
                    settings
                ),

            columns:
                deepClone(
                    schedule.columns
                ),

            assignments:
                deepClone(
                    schedule.assignments
                )

        };


        let history =
            getHistory();


        const currentSignature =
            createHistorySignature(
                currentData
            );


        /*
         * منع النسخ المتطابقة.
         */

        const duplicate =
            history.some(

                function (item) {

                    return (
                        createHistorySignature(
                            item
                        ) ===
                        currentSignature
                    );

                }

            );


        if (duplicate) {

            showToast(
                "هذه النسخة محفوظة بالفعل في السجل."
            );

            return;

        }


        const snapshot = {

            id:
                createId("history"),

            savedAt:
                Date.now(),

            version:
                currentData.version,

            settings:
                currentData.settings,

            columns:
                currentData.columns,

            assignments:
                currentData.assignments

        };


        history.unshift(
            snapshot
        );


        localStorage.setItem(

            STORAGE.history,

            JSON.stringify(
                history
            )

        );


        showToast(
            "تم حفظ نسخة من الجدول في السجل."
        );

    }


    /* =====================================================
       HISTORY
    ===================================================== */

    function getHistory() {

        const raw =
            localStorage.getItem(
                STORAGE.history
            );


        if (!raw) {
            return [];
        }


        try {

            const parsed =
                JSON.parse(raw);


            if (
                !Array.isArray(parsed)
            ) {

                return [];

            }


            /*
             * تنظيف النسخ المكررة الموجودة
             * من الإصدارات السابقة.
             */

            const unique =
                [];


            const signatures =
                new Set();


            parsed.forEach(

                function (item) {

                    if (!item) {
                        return;
                    }


                    const signature =
                        createHistorySignature(
                            item
                        );


                    if (
                        signatures.has(
                            signature
                        )
                    ) {

                        return;

                    }


                    signatures.add(
                        signature
                    );


                    unique.push(
                        item
                    );

                }

            );


            if (
                unique.length !==
                parsed.length
            ) {

                localStorage.setItem(

                    STORAGE.history,

                    JSON.stringify(
                        unique
                    )

                );

            }


            return unique;

        } catch (error) {

            console.error(
                "History error:",
                error
            );


            return [];

        }

    }


    function openHistoryModal() {

        renderHistory();


        historyModal.classList.add(
            "show"
        );

    }


    function closeHistoryModal() {

        historyModal.classList.remove(
            "show"
        );

    }


    /* =====================================================
       HISTORY DATE
    ===================================================== */

    function formatArabicDate(
        timestamp
    ) {

        const date =
            new Date(timestamp);


        const weekday =
            date.toLocaleDateString(

                "ar-EG",

                {
                    weekday:
                        "long"
                }

            );


        const dateText =
            date.toLocaleDateString(

                "ar-EG",

                {
                    day:
                        "numeric",

                    month:
                        "long",

                    year:
                        "numeric"
                }

            );


        return (
            weekday +
            "، " +
            dateText
        );

    }


    function formatArabicTime(
        timestamp
    ) {

        const date =
            new Date(timestamp);


        let hours =
            date.getHours();


        const minutes =
            String(
                date.getMinutes()
            ).padStart(
                2,
                "0"
            );


        const period =
            hours < 12
                ? "ص"
                : "م";


        hours =
            hours % 12;


        if (hours === 0) {
            hours = 12;
        }


        return (
            hours +
            ":" +
            minutes +
            " " +
            period
        );

    }


    /* =====================================================
       RENDER HISTORY
    ===================================================== */

    function renderHistory() {

        const list =
            $("historyList");


        const empty =
            $("historyEmpty");


        if (!list) {
            return;
        }


        list.innerHTML =
            "";


        const history =
            getHistory();


        if (
            history.length === 0
        ) {

            if (empty) {

                empty.style.display =
                    "flex";

            }


            return;

        }


        if (empty) {

            empty.style.display =
                "none";

        }


        history.forEach(

            function (item) {

                const card =
                    document.createElement(
                        "div"
                    );


                card.className =
                    "history-card";


                card.tabIndex =
                    0;


                card.setAttribute(
                    "role",
                    "button"
                );


                card.innerHTML = `

                    <div class="history-date-icon">
                        <span>▣</span>
                    </div>

                    <div class="history-card-content">

                        <div class="history-date">
                            ${escapeHtml(
                                formatArabicDate(
                                    item.savedAt
                                )
                            )}
                        </div>

                        <div class="history-time">
                            وقت الحفظ:
                            ${escapeHtml(
                                formatArabicTime(
                                    item.savedAt
                                )
                            )}
                        </div>

                    </div>

                    <button
                        class="history-delete-button"
                        type="button"
                        aria-label="حذف السجل"
                        data-history-delete="${escapeHtml(
                            item.id
                        )}">

                        ×

                    </button>

                    <div class="history-arrow">
                        ‹
                    </div>

                `;


                /*
                 * فتح السجل عند الضغط على
                 * البطاقة نفسها.
                 */

                card.addEventListener(

                    "click",

                    function (event) {

                        if (
                            event.target.closest(
                                ".history-delete-button"
                            )
                        ) {

                            return;

                        }


                        openSavedSchedule(
                            item
                        );

                    }

                );


                card.addEventListener(

                    "keydown",

                    function (event) {

                        if (
                            event.key ===
                            "Enter" ||
                            event.key ===
                            " "
                        ) {

                            event.preventDefault();


                            openSavedSchedule(
                                item
                            );

                        }

                    }

                );


                const deleteButton =
                    card.querySelector(
                        ".history-delete-button"
                    );


                deleteButton.addEventListener(

                    "click",

                    function (event) {

                        event.preventDefault();

                        event.stopPropagation();


                        deleteHistoryItem(
                            item.id
                        );

                    }

                );


                list.appendChild(
                    card
                );

            }

        );

    }


    /* =====================================================
       DELETE ONE HISTORY ITEM
    ===================================================== */

    function deleteHistoryItem(
        historyId
    ) {

        const history =
            getHistory();


        const item =
            history.find(

                function (entry) {

                    return String(
                        entry.id
                    ) ===
                    String(
                        historyId
                    );

                }

            );


        if (!item) {
            return;
        }


        openDeleteConfirmation(

            "حذف سجل الجدول",

            "هل تريد حذف هذه النسخة المحفوظة؟ لا يمكن التراجع عن هذا الإجراء.",

            function () {

                const updated =
                    history.filter(

                        function (entry) {

                            return String(
                                entry.id
                            ) !==
                            String(
                                historyId
                            );

                        }

                    );


                localStorage.setItem(

                    STORAGE.history,

                    JSON.stringify(
                        updated
                    )

                );


                renderHistory();


                showToast(
                    "تم حذف السجل."
                );

            }

        );

    }


    /* =====================================================
       DELETE ALL HISTORY
    ===================================================== */

    function deleteAllHistory() {

        const history =
            getHistory();


        if (
            history.length === 0
        ) {

            showToast(
                "لا توجد سجلات لحذفها."
            );

            return;

        }


        openDeleteConfirmation(

            "حذف جميع السجلات",

            "هل أنت متأكد من حذف جميع الجداول المحفوظة؟ لا يمكن التراجع عن هذا الإجراء.",

            function () {

                localStorage.removeItem(
                    STORAGE.history
                );


                renderHistory();


                showToast(
                    "تم حذف جميع السجلات."
                );

            }

        );

    }


    /* =====================================================
       SAVED SCHEDULE
    ===================================================== */

    function openSavedSchedule(
        snapshot
    ) {

        if (!snapshot) {
            return;
        }


        renderSavedSchedule(
            snapshot
        );


        $("savedViewDate")
            .textContent =
            formatArabicDate(
                snapshot.savedAt
            ) +
            " — تم الحفظ " +
            formatArabicTime(
                snapshot.savedAt
            );


        historyViewModal.classList.add(
            "show"
        );

    }


    function closeSavedSchedule() {

        historyViewModal.classList.remove(
            "show"
        );

    }


    /* =====================================================
       RENDER SAVED TABLE
    ===================================================== */

    function renderSavedSchedule(
        snapshot
    ) {

        const head =
            $("savedScheduleHead");


        const body =
            $("savedScheduleBody");


        if (
            !head ||
            !body
        ) {

            return;

        }


        head.innerHTML =
            "";


        body.innerHTML =
            "";


        const columns =
            Array.isArray(
                snapshot.columns
            )
                ? snapshot.columns
                : [];


        const assignments =
            snapshot.assignments ||
            {};


        const headRow =
            document.createElement(
                "tr"
            );


        const dayTh =
            document.createElement(
                "th"
            );


        dayTh.innerHTML =
            '<div class="day-header">اليوم</div>';


        headRow.appendChild(
            dayTh
        );


        columns.forEach(

            function (column) {

                const th =
                    document.createElement(
                        "th"
                    );


                if (
                    column.type ===
                    "break"
                ) {

                    th.classList.add(
                        "break-column"
                    );

                }


                th.innerHTML = `

                    <div class="lesson-header">

                        <div class="lesson-header-name">
                            ${escapeHtml(
                                column.name
                            )}
                        </div>

                        <div class="lesson-header-time">
                            ${formatTime(
                                column.start,
                                column.end
                            )}
                        </div>

                    </div>

                `;


                headRow.appendChild(
                    th
                );

            }

        );


        head.appendChild(
            headRow
        );


        DAYS.forEach(

            function (day) {

                const row =
                    document.createElement(
                        "tr"
                    );


                const dayCell =
                    document.createElement(
                        "td"
                    );


                dayCell.innerHTML =
                    `<div class="day-cell">
                        ${escapeHtml(
                            day.name
                        )}
                    </div>`;


                row.appendChild(
                    dayCell
                );


                columns.forEach(

                    function (column) {

                        const cell =
                            document.createElement(
                                "td"
                            );


                        if (
                            column.type ===
                            "break"
                        ) {

                            cell.classList.add(
                                "break-column",
                                "break-body-cell"
                            );


                            cell.innerHTML = `

                                <div class="break-text">
                                    ${escapeHtml(
                                        column.name ||
                                        "الفسحة"
                                    )}
                                </div>

                                <div class="break-duration-text">
                                    ${
                                        Number(
                                            column.duration
                                        ) || 20
                                    }
                                    دقيقة
                                </div>

                            `;

                        } else {

                            const key =
                                getAssignmentKey(
                                    day.id,
                                    column.id
                                );


                            const assignment =
                                normalizeAssignmentValue(
                                    assignments[key]
                                );


                            if (
                                assignment.subject
                            ) {

                                cell.innerHTML = `

                                    <div class="subject-name">
                                        ${escapeHtml(
                                            assignment.subject
                                        )}
                                    </div>

                                    ${
                                        assignment.className
                                            ? `
                                                <div class="subject-class">
                                                    ${escapeHtml(
                                                        assignment.className
                                                    )}
                                                </div>
                                            `
                                            : ""
                                    }

                                `;

                            } else {

                                cell.innerHTML = `

                                    <div class="subject-empty">
                                        —
                                    </div>

                                `;

                            }

                        }


                        row.appendChild(
                            cell
                        );

                    }

                );


                body.appendChild(
                    row
                );

            }

        );

    }


    /* =====================================================
       DELETE CONFIRMATION
    ===================================================== */

    function openDeleteConfirmation(
        title,
        message,
        action
    ) {

        deleteAction =
            action;


        if ($("deleteConfirmTitle")) {

            $("deleteConfirmTitle")
                .textContent =
                title;

        }


        if ($("deleteConfirmMessage")) {

            $("deleteConfirmMessage")
                .textContent =
                message;

        }


        if (deleteConfirmModal) {

            deleteConfirmModal.classList.add(
                "show"
            );

        }

    }


    function closeDeleteConfirmation() {

        deleteAction =
            null;


        if (deleteConfirmModal) {

            deleteConfirmModal.classList.remove(
                "show"
            );

        }

    }


    function confirmDeleteAction() {

        const action =
            deleteAction;


        closeDeleteConfirmation();


        if (
            typeof action ===
            "function"
        ) {

            action();

        }

    }


    /* =====================================================
       TOAST
    ===================================================== */

    let toastTimer =
        null;


    function showToast(
        message
    ) {

        const toast =
            $("toast");


        const text =
            $("toastMessage");


        if (
            !toast ||
            !text
        ) {

            return;

        }


        text.textContent =
            message;


        toast.classList.add(
            "show"
        );


        clearTimeout(
            toastTimer
        );


        toastTimer =
            setTimeout(

                function () {

                    toast.classList.remove(
                        "show"
                    );

                },

                2500

            );

    }


    /* =====================================================
       CLOSE ON BACKDROP
    ===================================================== */

    [
        addModal,
        lessonModal,
        breakModal,
        subjectModal,
        historyModal,
        historyViewModal,
        deleteConfirmModal

    ].forEach(

        function (modal) {

            if (!modal) {
                return;
            }


            modal.addEventListener(

                "click",

                function (event) {

                    if (
                        event.target ===
                        modal
                    ) {

                        modal.classList.remove(
                            "show"
                        );


                        if (
                            modal ===
                            deleteConfirmModal
                        ) {

                            deleteAction =
                                null;

                        }

                    }

                }

            );

        }

    );


    /* =====================================================
       BUTTON EVENTS
    ===================================================== */

    const addItemButton =
        $("addItemButton");


    if (addItemButton) {

        addItemButton.addEventListener(
            "click",
            openAddModal
        );

    }


    const emptyAddButton =
        $("emptyAddButton");


    if (emptyAddButton) {

        emptyAddButton.addEventListener(

            "click",

            function () {

                openNewLessonModal();

            }

        );

    }


    const closeAddModalButton =
        $("closeAddModal");


    if (closeAddModalButton) {

        closeAddModalButton.addEventListener(
            "click",
            closeAddModal
        );

    }


    const addLessonOption =
        $("addLessonOption");


    if (addLessonOption) {

        addLessonOption.addEventListener(

            "click",

            function () {

                closeAddModal();

                openNewLessonModal();

            }

        );

    }


    const addBreakOption =
        $("addBreakOption");


    if (addBreakOption) {

        addBreakOption.addEventListener(

            "click",

            function () {

                closeAddModal();

                openNewBreakModal();

            }

        );

    }


    const closeLessonModalButton =
        $("closeLessonModal");


    if (closeLessonModalButton) {

        closeLessonModalButton.addEventListener(
            "click",
            closeLessonModal
        );

    }


    const confirmLessonButton =
        $("confirmLessonButton");


    if (confirmLessonButton) {

        confirmLessonButton.addEventListener(
            "click",
            saveLessonFromForm
        );

    }


    const deleteLessonButton =
        $("deleteLessonButton");


    if (deleteLessonButton) {

        deleteLessonButton.addEventListener(
            "click",
            deleteCurrentLesson
        );

    }


    const closeBreakModalButton =
        $("closeBreakModal");


    if (closeBreakModalButton) {

        closeBreakModalButton.addEventListener(
            "click",
            closeBreakModal
        );

    }


    const confirmBreakButton =
        $("confirmBreakButton");


    if (confirmBreakButton) {

        confirmBreakButton.addEventListener(
            "click",
            saveBreakFromForm
        );

    }


    const deleteBreakButton =
        $("deleteBreakButton");


    if (deleteBreakButton) {

        deleteBreakButton.addEventListener(
            "click",
            deleteCurrentBreak
        );

    }


    const closeSubjectModalButton =
        $("closeSubjectModal");


    if (closeSubjectModalButton) {

        closeSubjectModalButton.addEventListener(
            "click",
            closeSubjectModal
        );

    }


    const clearSubjectButton =
        $("clearSubjectButton");


    if (clearSubjectButton) {

        clearSubjectButton.addEventListener(
            "click",
            clearSelectedSubject
        );

    }


    const saveScheduleButton =
        $("saveScheduleButton");


    if (saveScheduleButton) {

        saveScheduleButton.addEventListener(
            "click",
            saveScheduleToHistory
        );

    }


    const historyButton =
        $("historyButton");


    if (historyButton) {

        historyButton.addEventListener(
            "click",
            openHistoryModal
        );

    }


    const closeHistoryModalButton =
        $("closeHistoryModal");


    if (closeHistoryModalButton) {

        closeHistoryModalButton.addEventListener(
            "click",
            closeHistoryModal
        );

    }


    const closeHistoryViewModalButton =
        $("closeHistoryViewModal");


    if (closeHistoryViewModalButton) {

        closeHistoryViewModalButton.addEventListener(
            "click",
            closeSavedSchedule
        );

    }


    const deleteAllHistoryButton =
        $("deleteAllHistoryButton");


    if (deleteAllHistoryButton) {

        deleteAllHistoryButton.addEventListener(

            "click",

            deleteAllHistory

        );

    }


    /* =====================================================
       DELETE CONFIRMATION BUTTONS
    ===================================================== */

    const closeDeleteConfirmModalButton =
        $("closeDeleteConfirmModal");


    if (closeDeleteConfirmModalButton) {

        closeDeleteConfirmModalButton.addEventListener(
            "click",
            closeDeleteConfirmation
        );

    }


    const cancelDeleteButton =
        $("cancelDeleteButton");


    if (cancelDeleteButton) {

        cancelDeleteButton.addEventListener(
            "click",
            closeDeleteConfirmation
        );

    }


    const confirmDeleteButton =
        $("confirmDeleteButton");


    if (confirmDeleteButton) {

        confirmDeleteButton.addEventListener(
            "click",
            confirmDeleteAction
        );

    }


    /* =====================================================
       NAVIGATION
       Canonical 6-item navigation

       الصفحات الرئيسية لا يتم تكديسها
       في سجل الرجوع.
    ===================================================== */

    function goMain(page) {

        const currentPage =
            window.location.pathname
                .split("/")
                .pop()
                .toLowerCase();


        const targetPage =
            String(page)
                .split("?")[0]
                .toLowerCase();


        if (
            currentPage ===
            targetPage
        ) {

            return;

        }


        window.location.replace(
            page
        );

    }


    const homeNavigation =
        $("homeNavigation");


    const attendanceNavigation =
        $("attendanceNavigation");


    const studentsNavigation =
        $("studentsNavigation");


    const scheduleNavigation =
        $("scheduleNavigation");


    const gradesNavigation =
        $("gradesNavigation");


    const reportsNavigation =
        $("reportsNavigation");


    if (homeNavigation) {

        homeNavigation.addEventListener(

            "click",

            function () {

                goMain(
                    "home.html"
                );

            }

        );

    }


    if (attendanceNavigation) {

        attendanceNavigation.addEventListener(

            "click",

            function () {

                const currentClass =
                    localStorage.getItem(
                        "mueen_current_class"
                    );


                if (currentClass) {

                    goMain(
                        "attendance.html?class=" +
                        encodeURIComponent(
                            currentClass
                        )
                    );

                } else {

                    goMain(
                        "attendance.html"
                    );

                }

            }

        );

    }


    if (studentsNavigation) {

        studentsNavigation.addEventListener(

            "click",

            function () {

                goMain(
                    "students.html"
                );

            }

        );

    }


    if (scheduleNavigation) {

        scheduleNavigation.addEventListener(

            "click",

            function () {

                window.scrollTo({

                    top:
                        0,

                    behavior:
                        "smooth"

                });

            }

        );

    }


    if (gradesNavigation) {

        gradesNavigation.addEventListener(

            "click",

            function () {

                goMain(
                    "grades.html"
                );

            }

        );

    }


    if (reportsNavigation) {

        reportsNavigation.addEventListener(

            "click",

            function () {

                goMain(
                    "reports.html"
                );

            }

        );

    }


    /* =====================================================
       PHONE BACK / BROWSER BACK

       لا نستخدم pushState هنا.

       السبب:
       صفحة حصصي صفحة رئيسية، وعند الرجوع
       يجب الذهاب إلى الرئيسية دون إنشاء
       حلقة schedule -> home -> schedule.
    ===================================================== */

    let scheduleBackHandled =
        false;


    function setupScheduleBackHandler() {

        /*
         * نضع علامة على الصفحة الحالية فقط.
         * لا نضيف history entry جديد.
         */

        try {

            window.history.replaceState(

                {
                    mueenSchedulePage:
                        true
                },

                "",

                window.location.href

            );

        } catch (error) {

            console.warn(
                "Mueen schedule history setup warning:",
                error
            );

        }


        window.addEventListener(

            "popstate",

            function () {

                if (
                    scheduleBackHandled
                ) {

                    return;

                }


                scheduleBackHandled =
                    true;


                /*
                 * replace يمنع إبقاء schedule
                 * خلف home.
                 */

                window.location.replace(
                    "home.html"
                );

            }

        );

    }


    /* =====================================================
       BACK BUTTON
    ===================================================== */

    const backButton =
        $("backButton");


    if (backButton) {

        backButton.addEventListener(

            "click",

            function () {

                window.location.replace(
                    "home.html"
                );

            }

        );

    }


    /* =====================================================
       ESCAPE
    ===================================================== */

    document.addEventListener(

        "keydown",

        function (event) {

            if (
                event.key !==
                "Escape"
            ) {

                return;

            }


            [
                addModal,
                lessonModal,
                breakModal,
                subjectModal,
                historyModal,
                historyViewModal,
                deleteConfirmModal

            ].forEach(

                function (modal) {

                    if (!modal) {
                        return;
                    }


                    modal.classList.remove(
                        "show"
                    );

                }

            );


            deleteAction =
                null;

        }

    );


    /* =====================================================
       INIT
    ===================================================== */

    loadSettings();

    loadCurrentSchedule();

    recalculateLessonTimes();

    saveCurrent();

    render();

    setupScheduleBackHandler();


    console.log(
        "MUEEN schedule initialized.",
        {
            schedule:
                schedule,

            settings:
                settings
        }
    );


})();