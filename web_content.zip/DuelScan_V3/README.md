# DuelScan V3 — AR Duel and Unified Collection Prototype

This is a phone-friendly web prototype for the new DuelScan direction.

## Included
- Duel Links-inspired original navigation: Home/Duel World, Duel Arena, Card Shop, Unified Collection, Deck Studio, Scanner, Field Workshop.
- One unified collection for physical scanned records and digital cards earned/bought in the demo shop. Each copy retains a `physical` or `digital` source label.
- Three demo digital card packs, local in-game currency, and basic mission rewards.
- Camera capture and image upload for physical cards. User confirms card name; recognition is not automatic in this build.
- Five Monster Zones and five Spell/Trap Zones for each side, LP display, hand, basic summon/draw/turn demo, typed and browser speech commands.
- Custom player/opponent field colors, opacity, themes and optional uploaded background saved locally.
- Deck editing, local save, simple .ydk export/import (the bundled demo database only recognizes a small list of names).
- Mobile responsive UI and localStorage persistence.

## Run / test
Open `index.html` in a modern browser. Camera APIs generally require HTTPS or localhost and browser permission. For best testing, serve the files from a secure HTTPS host. Some browser file:// contexts will block camera and speech features.

## Android APK
This ZIP is source code, not an APK. To create a reliable Android app, wrap the web UI in an Android WebView/Capacitor project and configure camera/microphone permissions. For the planned table-anchored AR experience, use native ARCore (or another supported AR framework) and connect it to the web UI. A camera video with drawn zones is only a 2D overlay; it is NOT stable world-tracked AR and will not stay attached to the table as the phone moves.

## Current limitations
- The duel logic is intentionally a demo, not a complete Yu-Gi-Oh rules engine. Card effects, chains, tribute requirements, phases and damage are not comprehensively enforced.
- The card list is a tiny demo sample, not a full database. Scan image recognition/OCR is not implemented here; the user types/corrects the card name after photo capture.
- Shop cards are local demo rewards only; no real-money transactions or online account.
- Deck import only matches names in the demo list; exported numeric card IDs are placeholders unless IDs are available.
- Collection, coins, decks and settings stay in the browser's local storage on that device.
- This is an unofficial fan prototype. Review applicable intellectual-property, card-art, privacy and API terms before publishing.
