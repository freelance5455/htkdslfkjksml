# CPLS Stage 1166 — Replay Protection / Nonce & Idempotency

- Reward claim requests now use the client nonce as an idempotency key.
- A local 15-minute duplicate-submit guard prevents accidental repeated submissions from the same app instance.
- The client returns `DUPLICATE_CLAIM_NONCE` for a still-active duplicate.
- This local cache is explicitly **not** a security boundary.
- Production replay protection must be enforced atomically by the backend using a durable unique nonce/idempotency constraint.
- Backend must bind the nonce to the authenticated account, wallet, claim scope, chain ID, and expiry; reject reuse and expired claims.
- No private key, signature, transaction broadcast, or mainnet capability was added.
- Sepolia remains the only configured network (chain ID 11155111).
- No live backend or live blockchain transaction was claimed.

Version: 11.7.0 / versionCode 117.
