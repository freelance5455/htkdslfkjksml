BUS DUTY DIARY NEW – Android Studio source project

समाविष्ट prototype: email/mobile + password demo login, तारीख/वार/AM-PM घड्याळ, तीन डॉट menu, कर्मचारी profile व lock/unlock, पद निवड, badge, weekly off, PH/C-OFF balances, calendar मधून नोंदी, All Duty list, CSV export, A4 leave application print.

महत्त्वाच्या मर्यादा:
1. ही APK फाइल नाही; Android Studio project ZIP आहे. येथे Android SDK/Gradle build करून APK compile करता येत नाही.
2. Login सध्या local demo आहे; secure account creation/authentication नाही. Google login साठी Firebase project, OAuth configuration आणि google-services.json आवश्यक.
3. Notification सेवा, cloud backup, पूर्ण मराठी-इंग्रजी translation आणि PDF file generation/advanced leave workflow अजून जोडलेले नाहीत.
4. डेटा WebView localStorage मध्ये आहे; app data clear/फोन reset केल्यास नोंदी नष्ट होऊ शकतात.
5. PH/C-OFF balance prototype logic आहे; विभागीय नियम तपासल्याशिवाय अधिकृत हिशेबासाठी वापरू नये.

APK build करण्यासाठी: ZIP extract > Android Studio मध्ये folder उघडा > Gradle Sync > Build > Build Bundle(s)/APK(s) > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk.
