# JARVIS Android (offline AI prototype)

This project is a native Android WebView wrapper around a local HTML/JavaScript app. It does not call Gemini, OpenAI, or any hosted AI API.

## Features
- Local chat interface and localStorage memory
- Tiny character-level neural network trained in JavaScript on the device
- Import `.txt` / `.json` files through the app's file picker
- Export saved memories
- Android Text-to-Speech and speech recognition bridge
- Opens web search and websites in the external browser
- No dangerous unrestricted device automation

## Important limits
The model is a toy character predictor, not a capable conversational language model. Web search opens a search page but does not fetch or summarize results. Speech recognition may use Android's configured recognition service and may require internet depending on the device. Memories are stored in WebView localStorage and can be cleared by Android app-data clearing.

## Build APK
Recommended: Android Studio on a computer.
1. Open this folder as an existing Android Studio project.
2. Let Gradle sync. Install Android SDK 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer it to your phone and install it. You may need to allow installation from that file manager.

This source project does not include a prebuilt APK or Gradle wrapper. Android Studio may download Gradle/SDK components during setup. No API key is required.

## Phone-only note
This project is source code, not an APK file. Building a native APK usually requires Android build tools. AIDE or another Android IDE may support importing/building projects, but compatibility with the current Android Gradle Plugin is not guaranteed. If using an Android IDE, check its supported Gradle/SDK versions first.

## Permissions and privacy
- Microphone permission is requested by Android when speech recognition is launched.
- `INTERNET` is used only for opening user-requested websites/searches.
- Do not import sensitive documents on a shared phone.
