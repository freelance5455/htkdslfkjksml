# KingSaroj Routine 👑 Android APK Build Project

यो प्रोजेक्ट KingSaroj Routine एपको पूर्ण एन्ड्रोइड APK बनाउन तयार पारिएको स्रोत प्याकेज हो।

## APK बनाउने ३ सजिला तरिकाहरू:

### तरिका १: PWABuilder (सबैभन्दा सजिलो - १ मिनेटमा APK)
1. https://www.pwabuilder.com खोल्नुहोस्।
2. आफ्नो एपको URL राख्नुहोस्।
3. "Package for Android" थिच्नुहोस् र सिधै APK फाइल डाउनलोड गर्नुहोस्।

### तरिका २: Android Studio
1. Android Studio खोल्नुहोस्।
2. यस फोल्डरलाई Project को रूपमा Import गर्नुहोस्।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) थिच्नुहोस्।
4. तपाईंको Android APK तयार हुनेछ!

### तरिका ३: Capacitor CLI
Terminal मा रन गर्नुहोस्:
1. npm install @capacitor/core @capacitor/cli @capacitor/android
2. npx cap add android
3. npx cap sync
4. npx cap open android
