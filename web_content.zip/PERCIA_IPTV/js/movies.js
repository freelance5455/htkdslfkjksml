// Catálogo de películas
function initMovies(){
  $('movieSearch').addEventListener('input',applyMovieSearch);
  $('loadMoreButton').addEventListener('click',()=>{
    visibleMovies+=30;renderMovies();
  });
  $('backButton').addEventListener('click',()=>{
    $('catalogScreen').style.display='none';
    $('connectionScreen').style.display='block';
    window.scrollTo({top:0,behavior:'smooth'});
  });
  $('closeDetail').addEventListener('click',()=>{$('movieDetail').style.display='none';});
  $('movieDetail').addEventListener('click',event=>{
    if(event.target===$('movieDetail'))$('movieDetail').style.display='none';
  });
  $('prepareMovieButton').addEventListener('click',()=>{
    if(!selectedMovie)return;
    alert('Película seleccionada: '+selectedMovie.name);
  });
}
async function openCatalog(){
  $('connectionScreen').style.display='none';
  $('catalogScreen').style.display='block';
  $('movieSearch').value='';
  $('movieGrid').replaceChildren();
  $('categoryList').replaceChildren();
  await loadMovieCategories();
  window.scrollTo({top:0,behavior:'smooth'});
}
async function loadMovieCategories(){
  if(!activeProfile)return;
  message('catalogMessage','Cargando...','info');
  try{
    const data=await fetchJson(apiUrl(activeProfile,{action:'get_vod_categories'}));
    if(!Array.isArray(data))throw new Error('Respuesta no válida.');
    renderCategories(data);
    await loadMovies('all');
  }catch(error){
    message('catalogMessage','Error al cargar categorías: '+error.message,'error');
  }
}
function renderCategories(categories){
  $('categoryList').replaceChildren();
  addCategoryButton('Todas','all');
  categories.forEach(category=>{
    addCategoryButton(category.category_name||'Sin nombre',String(category.category_id));
  });
}
function addCategoryButton(name,id){
  const button=document.createElement('button');
  button.className='category-chip'+(id==='all'?' active':'');
  button.textContent=name;
  button.addEventListener('click',()=>{
    document.querySelectorAll('.category-chip').forEach(b=>b.classList.remove('active'));
    button.classList.add('active');
    loadMovies(id);
  });
  $('categoryList').appendChild(button);
}
async function loadMovies(categoryId){
  if(!activeProfile)return;
  visibleMovies=30;
  $('movieGrid').replaceChildren();
  $('loadMoreButton').style.display='none';
  message('catalogMessage','Cargando películas...','info');
  try{
    const extra={action:'get_vod_streams'};
    if(categoryId!=='all')extra.category_id=categoryId;
    const data=await fetchJson(apiUrl(activeProfile,extra));
    if(!Array.isArray(data))throw new Error('Respuesta no válida.');
    allMovies=data;
    applyMovieSearch();
    message('catalogMessage',data.length?'Películas cargadas.':'Sin películas.',data.length?'success':'info');
  }catch(error){
    message('catalogMessage','Error al cargar películas: '+error.message,'error');
  }
}
function applyMovieSearch(){
  const term=$('movieSearch').value.trim().toLowerCase();
  filteredMovies=allMovies.filter(movie=>String(movie.name||'').toLowerCase().includes(term));
  visibleMovies=30;
  renderMovies();
}
function renderMovies(){
  const grid=$('movieGrid');
  grid.replaceChildren();
  const items=filteredMovies.slice(0,visibleMovies);
  $('movieCount').textContent=filteredMovies.length+' películas';
  items.forEach(movie=>{
    const card=document.createElement('div');
    card.className='movie-card';
    if(movie.stream_icon){
      const img=document.createElement('img');
      img.className='poster';
      img.src=movie.stream_icon;
      img.alt=movie.name||'Película';
      img.loading='lazy';
      img.onerror=()=>{
        const placeholder=document.createElement('div');
        placeholder.className='poster-placeholder';
        placeholder.textContent='🎬';
        img.replaceWith(placeholder);
      };
      card.appendChild(img);
    }else{
      const placeholder=document.createElement('div');
      placeholder.className='poster-placeholder';
      placeholder.textContent='🎬';
      card.appendChild(placeholder);
    }
    const title=document.createElement('div');
    title.className='movie-name';
    title.textContent=movie.name||'Película';
    card.append(title);
    card.addEventListener('click',()=>showMovieDetail(movie));
    grid.appendChild(card);
  });
  $('loadMoreButton').style.display=visibleMovies<filteredMovies.length?'block':'none';
  if(!filteredMovies.length){
    const empty=document.createElement('div');
    empty.className='empty';
    empty.textContent='Sin resultados';
    grid.appendChild(empty);
  }
}
function showMovieDetail(movie){
  selectedMovie=movie;
  $('detailTitle').textContent=movie.name||'Película';
  $('detailDescription').textContent=movie.plot||movie.description||'';
  $('detailPoster').src=movie.stream_icon||'';
  $('detailPoster').style.display=movie.stream_icon?'block':'none';
  $('movieDetail').style.display='flex';
}
