// Comunicación con Xtream
function normalizeServer(value){
  return value.trim().replace(/\/+$/,'');
}
function apiUrl(profile,extra={}){
  const url=new URL('/player_api.php',profile.server);
  url.searchParams.set('username',profile.username);
  url.searchParams.set('password',profile.password);
  Object.entries(extra).forEach(([key,value])=>{
    if(value!==null&&value!==undefined)url.searchParams.set(key,value);
  });
  return url;
}
async function fetchJson(url){
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),20000);
  try{
    const response=await fetch(url.toString(),{method:'GET',signal:controller.signal});
    if(!response.ok)throw new Error('HTTP '+response.status);
    return await response.json();
  }finally{clearTimeout(timeout);}
}
