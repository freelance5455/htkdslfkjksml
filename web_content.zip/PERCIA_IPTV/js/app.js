// Estado general y funciones comunes
const STORAGE_KEY='percia_iptv_profiles_v1';
const $=id=>document.getElementById(id);
let profiles=[];
let editingId=null;
let activeProfile=null;
let allMovies=[];
let filteredMovies=[];
let visibleMovies=30;
let selectedMovie=null;

function message(id,text,type){
  $(id).textContent=text;
  $(id).className='message show '+type;
}
function hideMessage(id){
  $(id).textContent='';
  $(id).className='message';
}

// Los módulos se inicializan después de cargar todos los scripts.
initProfiles();
initMovies();
initLive();
$('showMoviesButton').addEventListener('click',()=>{
  $('liveScreen').style.display='none';$('catalogScreen').style.display='block';
});
$('showLiveButton').addEventListener('click',openLive);
loadProfiles();
