// Perfiles: guardar, editar, conectar y eliminar
function initProfiles(){
  $('extractButton').addEventListener('click',extractUrl);
  $('clearButton').addEventListener('click',clearForm);
  $('profileForm').addEventListener('submit',async event=>{
    event.preventDefault();
    const name=$('profileName').value.trim();
    const server=normalizeServer($('server').value);
    const username=$('username').value.trim();
    const password=$('password').value;
    if(!name||!server||!username||!password){
      message('connectionMessage','Completa todos los campos.','error');return;
    }
    try{
      const parsed=new URL(server);
      if(!['http:','https:'].includes(parsed.protocol))throw new Error();
    }catch{
      message('connectionMessage','Servidor no válido.','error');return;
    }
    await connectProfile({id:editingId||Date.now().toString(),name,server,username,password});
  });
}
function extractUrl(){
  try{
    const parsed=new URL($('fullUrl').value.trim());
    const username=parsed.searchParams.get('username');
    const password=parsed.searchParams.get('password');
    if(!username||!password)throw new Error('URL Xtream no válida');
    $('server').value=parsed.origin;
    $('username').value=username;
    $('password').value=password;
    if(!$('profileName').value.trim())$('profileName').value='Mi IPTV';
    message('urlMessage','Datos extraídos.','success');
  }catch(error){message('urlMessage',error.message||'URL no válida.','error');}
}
function clearForm(){
  $('profileForm').reset();
  editingId=null;
  $('connectButton').textContent='CONECTAR';
  hideMessage('urlMessage');
  hideMessage('connectionMessage');
}
function loadProfiles(){
  try{
    const data=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');
    profiles=Array.isArray(data)?data:[];
  }catch{profiles=[];}
  renderProfiles();
}
function saveProfiles(){
  localStorage.setItem(STORAGE_KEY,JSON.stringify(profiles));
  renderProfiles();
}
async function connectProfile(profile){
  const button=$('connectButton');
  button.disabled=true;
  button.textContent='CONECTANDO...';
  message('connectionMessage','Conectando...','info');
  try{
    const data=await fetchJson(apiUrl(profile));
    if(!data||!data.user_info||Number(data.user_info.auth)!==1)
      throw new Error('Credenciales incorrectas.');
    const index=profiles.findIndex(p=>p.id===profile.id);
    if(index>=0)profiles[index]=profile;else profiles.push(profile);
    saveProfiles();
    activeProfile=profile;
    editingId=null;
    await openCatalog();
  }catch(error){
    let detail=error.message;
    if(error.name==='AbortError')detail='Tiempo de espera agotado.';
    if(error instanceof TypeError)detail='No se pudo acceder al servidor. Posible error de CORS o conexión.';
    message('connectionMessage',detail,'error');
  }finally{
    button.disabled=false;
    button.textContent='CONECTAR';
  }
}
function editProfile(id){
  const p=profiles.find(item=>item.id===id);
  if(!p)return;
  editingId=id;
  $('profileName').value=p.name;
  $('server').value=p.server;
  $('username').value=p.username;
  $('password').value=p.password;
  $('fullUrl').value='';
  $('connectButton').textContent='ACTUALIZAR Y CONECTAR';
  window.scrollTo({top:0,behavior:'smooth'});
}
function deleteProfile(id){
  const p=profiles.find(item=>item.id===id);
  if(!p||!confirm('¿Eliminar este perfil?'))return;
  profiles=profiles.filter(item=>item.id!==id);
  saveProfiles();
  if(editingId===id)clearForm();
}
function renderProfiles(){
  const container=$('profilesList');
  container.replaceChildren();
  const title=document.createElement('div');
  title.textContent='Perfiles guardados';
  title.style.cssText='font-size:16px;font-weight:bold;margin-bottom:8px';
  container.appendChild(title);
  if(!profiles.length){
    const empty=document.createElement('div');
    empty.className='empty';
    empty.textContent='Sin perfiles guardados';
    container.appendChild(empty);return;
  }
  profiles.forEach(p=>{
    const item=document.createElement('div');
    item.className='profile';
    const name=document.createElement('div');
    name.className='profile-name';
    name.textContent=p.name||'Perfil sin nombre';
    const actions=document.createElement('div');
    actions.className='profile-actions';
    const connect=document.createElement('button');
    connect.textContent='CONECTAR';
    connect.addEventListener('click',()=>connectSavedProfile(p));
    const edit=document.createElement('button');
    edit.className='secondary';
    edit.textContent='EDITAR';
    edit.addEventListener('click',()=>editProfile(p.id));
    const remove=document.createElement('button');
    remove.className='danger';
    remove.textContent='ELIMINAR';
    remove.addEventListener('click',()=>deleteProfile(p.id));
    actions.append(connect,edit,remove);
    item.append(name,actions);
    container.appendChild(item);
  });
}
async function connectSavedProfile(profile){
  $('profileName').value=profile.name;
  $('server').value=profile.server;
  $('username').value=profile.username;
  $('password').value=profile.password;
  editingId=profile.id;
  await connectProfile(profile);
}
