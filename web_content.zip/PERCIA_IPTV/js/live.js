// TV EN VIVO: módulo independiente de Películas
let allLiveChannels=[];
let filteredLiveChannels=[];
let activeLiveCategory='all';

function initLive(){
  $('liveSearch').addEventListener('input',filterLiveChannels);
  $('liveBackButton').addEventListener('click',()=>{
    $('liveScreen').style.display='none';
    $('catalogScreen').style.display='block';
    window.scrollTo({top:0,behavior:'smooth'});
  });
  $('closeLivePlayer').addEventListener('click',closeLivePlayer);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('livePlayerModal').style.display==='flex')closeLivePlayer();});
  $('livePlayerModal').addEventListener('click',e=>{
    if(e.target===$('livePlayerModal'))closeLivePlayer();
  });
}
async function openLive(){
  $('catalogScreen').style.display='none';
  $('liveScreen').style.display='block';
  $('liveSearch').value='';
  $('liveGrid').replaceChildren();
  $('liveCategories').replaceChildren();
  await loadLiveCategories();
  window.scrollTo({top:0,behavior:'smooth'});
}
async function loadLiveCategories(){
  if(!activeProfile)return;
  message('liveMessage','Cargando categorías de TV EN VIVO...','info');
  try{
    const data=await fetchJson(apiUrl(activeProfile,{action:'get_live_categories'}));
    if(!Array.isArray(data))throw new Error('Respuesta de categorías no válida.');
    renderLiveCategories(data);
    await loadLiveChannels('all');
  }catch(error){message('liveMessage','Error al cargar TV EN VIVO: '+error.message,'error');}
}
function renderLiveCategories(categories){
  const box=$('liveCategories');box.replaceChildren();
  addLiveCategory('Todas','all');
  categories.forEach(c=>addLiveCategory(c.category_name||'Sin nombre',String(c.category_id)));
}
function addLiveCategory(name,id){
  const b=document.createElement('button');
  b.className='category-chip'+(id==='all'?' active':'');
  b.textContent=name;
  b.addEventListener('click',()=>{
    document.querySelectorAll('#liveCategories .category-chip').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');activeLiveCategory=id;loadLiveChannels(id);
  });
  $('liveCategories').appendChild(b);
}
async function loadLiveChannels(categoryId){
  if(!activeProfile)return;
  activeLiveCategory=categoryId;
  $('liveGrid').replaceChildren();
  message('liveMessage','Cargando canales...','info');
  try{
    const extra={action:'get_live_streams'};
    if(categoryId!=='all')extra.category_id=categoryId;
    const data=await fetchJson(apiUrl(activeProfile,extra));
    if(!Array.isArray(data))throw new Error('Respuesta de canales no válida.');
    allLiveChannels=data;filterLiveChannels();
    message('liveMessage',data.length?'Canales cargados.':'No hay canales en esta categoría.',data.length?'success':'info');
  }catch(error){message('liveMessage','Error al cargar canales: '+error.message,'error');}
}
function filterLiveChannels(){
  const q=$('liveSearch').value.trim().toLowerCase();
  filteredLiveChannels=allLiveChannels.filter(c=>String(c.name||'').toLowerCase().includes(q));
  renderLiveChannels();
}
function renderLiveChannels(){
  const grid=$('liveGrid');grid.replaceChildren();
  $('liveCount').textContent=filteredLiveChannels.length+' canales';
  filteredLiveChannels.forEach(channel=>{
    const card=document.createElement('button');card.className='live-card';
    if(channel.stream_icon){
      const img=document.createElement('img');img.src=channel.stream_icon;img.alt='';img.loading='lazy';
      img.onerror=()=>img.remove();card.appendChild(img);
    }
    const name=document.createElement('span');name.textContent=channel.name||'Canal';
    card.appendChild(name);card.addEventListener('click',()=>playLiveChannel(channel));grid.appendChild(card);
  });
  if(!filteredLiveChannels.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='No hay canales para mostrar';grid.appendChild(empty);}
}
async function playLiveChannel(channel){
  const url=activeProfile.server.replace(/\/+$/,'')+'/live/'+encodeURIComponent(activeProfile.username)+'/'+encodeURIComponent(activeProfile.password)+'/'+encodeURIComponent(channel.stream_id)+'.m3u8';
  $('livePlayerTitle').textContent=channel.name||'TV EN VIVO';
  $('livePlayerMessage').textContent='';
  $('livePlayerModal').style.display='flex';
  document.body.classList.add('live-playing');
  const video=$('liveVideo');video.pause();video.removeAttribute('src');video.load();
  if(window.liveHls){window.liveHls.destroy();window.liveHls=null;}

  // Solicita pantalla completa directamente desde el toque del usuario.
  // En navegadores compatibles esto oculta también la barra del navegador.
  let fullscreenRequest=null;
  try{
    if(!document.fullscreenElement){
      const player=$('livePlayerModal');
      if(player.requestFullscreen) fullscreenRequest=player.requestFullscreen();
      else if(player.webkitRequestFullscreen) player.webkitRequestFullscreen();
    }
  }catch(e){}
  try{if(fullscreenRequest)await fullscreenRequest;}catch(e){}
  try{if(screen.orientation&&screen.orientation.lock)await screen.orientation.lock('landscape');}catch(e){}

  if(window.Hls&&Hls.isSupported()){
    const hls=new Hls({enableWorker:true});window.liveHls=hls;
    hls.loadSource(url);hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED,()=>video.play().catch(()=>message('livePlayerMessage','Pulsa reproducir para iniciar el canal.','info')));
    hls.on(Hls.Events.ERROR,(_,data)=>{
      if(data.fatal)message('livePlayerMessage','No se pudo reproducir este canal. Comprueba la señal o el formato del servidor.','error');
    });
  }else if(video.canPlayType('application/vnd.apple.mpegurl')){
    video.src=url;video.play().catch(()=>message('livePlayerMessage','Pulsa reproducir para iniciar el canal.','info'));
  }else{
    message('livePlayerMessage','Este navegador no admite HLS. Prueba abrirlo en un navegador compatible.','error');
  }
}

function closeLivePlayer(){
  const video=$('liveVideo');video.pause();video.removeAttribute('src');video.load();
  if(window.liveHls){window.liveHls.destroy();window.liveHls=null;}
  const modal=$('livePlayerModal');
  modal.style.display='none';hideMessage('livePlayerMessage');
  document.body.classList.remove('live-playing');
  try{if(screen.orientation&&screen.orientation.unlock)screen.orientation.unlock();}catch(e){}
  if(document.fullscreenElement&&document.exitFullscreen){document.exitFullscreen().catch(()=>{});}
  else if(document.webkitFullscreenElement&&document.webkitExitFullscreen){document.webkitExitFullscreen();}
}
