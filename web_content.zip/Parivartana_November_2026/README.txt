PARIVARTANA — NOVEMBER 2026
============================

1. Extract this ZIP.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Open Sounds & BGM and tap a sound or switch BGM ON once to enable browser audio.
4. Your progress is saved in this browser on this device using localStorage.
5. Use Export JSON regularly to make a backup. Import JSON restores a backup.

Included:
- Animated Golden Sentinel warrior
- November 1–30 daily tracker
- 8 quests and Quality Audit
- Self-care codes: WE, WP, PM, SC, 2D, 2TM, MV, GT, SC, AC, SP, M
- Self-gratification codes: ES, NF, JF, NE, NG
- Per-code completion sound and XP sound
- Quest, victory, level-up, save, reset, and other SFX
- Four selectable synthesized BGM themes
- 150-point daily scoring architecture
- Freedom Days (maximum 3)
- JSON export/import

Note: Browser storage is local to the browser/device. It does not automatically sync across devices.
