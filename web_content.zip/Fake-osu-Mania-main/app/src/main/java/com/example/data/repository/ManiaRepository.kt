package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.audio.AudioSynthesisEngine
import com.example.audio.BeatmapGenerator
import com.example.data.db.ManiaDatabase
import com.example.data.model.Beatmap
import com.example.data.model.ScoreRecord
import com.example.data.model.SongTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class ManiaRepository(
    private val context: Context,
    private val database: ManiaDatabase = ManiaDatabase.getInstance(context)
) {
    val allSongs: Flow<List<SongTrack>> = database.songDao().getAllSongs()
    val allScores: Flow<List<ScoreRecord>> = database.scoreDao().getAllScores()

    fun getBeatmapsForSong(songId: String): Flow<List<Beatmap>> {
        return database.beatmapDao().getBeatmapsForSong(songId)
    }

    suspend fun getBeatmapById(beatmapId: String): Beatmap? {
        return database.beatmapDao().getBeatmapById(beatmapId)
    }

    suspend fun getSongById(songId: String): SongTrack? {
        return database.songDao().getSongById(songId)
    }

    suspend fun saveBeatmap(beatmap: Beatmap) = withContext(Dispatchers.IO) {
        database.beatmapDao().insertBeatmap(beatmap)
    }

    suspend fun deleteBeatmap(beatmapId: String) = withContext(Dispatchers.IO) {
        database.beatmapDao().deleteBeatmap(beatmapId)
    }

    suspend fun recordScore(scoreRecord: ScoreRecord) = withContext(Dispatchers.IO) {
        database.scoreDao().insertScore(scoreRecord)
    }

    suspend fun getHighScoreForBeatmap(beatmapId: String): ScoreRecord? {
        return database.scoreDao().getHighScoreForBeatmap(beatmapId)
    }

    /**
     * Initializes pre-bundled tracks if the database is empty.
     */
    suspend fun initializeBundledContentIfNeeded() = withContext(Dispatchers.IO) {
        val existing = database.songDao().getSongById("bundled_track_1")
        if (existing == null) {
            // Generate Track 1: Cyber Velocity (140 BPM)
            val track1File = AudioSynthesisEngine.getOrCreateBundledTrack(
                context, "cyber_velocity", 140, 40
            )
            val song1 = SongTrack(
                id = "bundled_track_1",
                title = "Cyber Velocity",
                artist = "Mania Core",
                audioPath = track1File.absolutePath,
                durationMs = 40_000L,
                bpm = 140,
                isBundled = true
            )
            database.songDao().insertSong(song1)

            // Generate Normal & Hard beatmaps for Track 1
            val bm1Normal = BeatmapGenerator.generateBeatmap(
                songId = song1.id,
                durationMs = song1.durationMs,
                bpm = 140,
                densityFactor = 1.0f,
                scrollSpeed = 1.6f,
                difficultyLabel = "Normal"
            )
            val bm1Hard = BeatmapGenerator.generateBeatmap(
                songId = song1.id,
                durationMs = song1.durationMs,
                bpm = 140,
                densityFactor = 1.5f,
                scrollSpeed = 2.2f,
                difficultyLabel = "Hard"
            )
            database.beatmapDao().insertBeatmap(bm1Normal)
            database.beatmapDao().insertBeatmap(bm1Hard)

            // Generate Track 2: Neon Midnight (120 BPM)
            val track2File = AudioSynthesisEngine.getOrCreateBundledTrack(
                context, "neon_midnight", 120, 36
            )
            val song2 = SongTrack(
                id = "bundled_track_2",
                title = "Neon Midnight",
                artist = "Retro Pulse",
                audioPath = track2File.absolutePath,
                durationMs = 36_000L,
                bpm = 120,
                isBundled = true
            )
            database.songDao().insertSong(song2)

            val bm2Easy = BeatmapGenerator.generateBeatmap(
                songId = song2.id,
                durationMs = song2.durationMs,
                bpm = 120,
                densityFactor = 0.7f,
                scrollSpeed = 1.3f,
                difficultyLabel = "Easy"
            )
            val bm2Normal = BeatmapGenerator.generateBeatmap(
                songId = song2.id,
                durationMs = song2.durationMs,
                bpm = 120,
                densityFactor = 1.1f,
                scrollSpeed = 1.8f,
                difficultyLabel = "Normal"
            )
            database.beatmapDao().insertBeatmap(bm2Easy)
            database.beatmapDao().insertBeatmap(bm2Normal)

            // Generate Track 3: Hyper Overdrive (165 BPM)
            val track3File = AudioSynthesisEngine.getOrCreateBundledTrack(
                context, "hyper_overdrive", 165, 35
            )
            val song3 = SongTrack(
                id = "bundled_track_3",
                title = "Hyper Overdrive",
                artist = "Dimension X",
                audioPath = track3File.absolutePath,
                durationMs = 35_000L,
                bpm = 165,
                isBundled = true
            )
            database.songDao().insertSong(song3)

            val bm3Insane = BeatmapGenerator.generateBeatmap(
                songId = song3.id,
                durationMs = song3.durationMs,
                bpm = 165,
                densityFactor = 1.8f,
                scrollSpeed = 2.5f,
                difficultyLabel = "Insane"
            )
            database.beatmapDao().insertBeatmap(bm3Insane)
        }
    }

    /**
     * Imports an audio file selected by the user from their device.
     */
    suspend fun importAudioFile(uri: Uri): SongTrack? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)

            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?: getFileNameFromUri(uri)
                ?: "Custom Audio Track"
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: "Imported Device Artist"
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 60_000L
            retriever.release()

            // Copy audio to app internal storage for reliable access
            val importedDir = File(context.filesDir, "imported_audio").apply { mkdirs() }
            val songId = "imported_${UUID.randomUUID()}"
            val targetFile = File(importedDir, "$songId.mp3")

            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(targetFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }

            val newSong = SongTrack(
                id = songId,
                title = title,
                artist = artist,
                audioPath = targetFile.absolutePath,
                durationMs = durationMs,
                bpm = 128,
                isBundled = false
            )
            database.songDao().insertSong(newSong)

            // Automatically generate default beatmap with standard density
            val autoBeatmap = BeatmapGenerator.generateBeatmap(
                songId = newSong.id,
                durationMs = newSong.durationMs,
                bpm = 128,
                densityFactor = 1.0f,
                scrollSpeed = 1.8f,
                difficultyLabel = "Auto 1.0x"
            )
            database.beatmapDao().insertBeatmap(autoBeatmap)

            newSong
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        val path = uri.path ?: return null
        val cut = path.lastIndexOf('/')
        return if (cut != -1) path.substring(cut + 1) else path
    }
}
