package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scores")
data class ScoreRecord(
    @PrimaryKey
    val id: String,
    val beatmapId: String,
    val songTitle: String,
    val difficultyName: String,
    val score: Int,
    val accuracy: Float,         // 0.00 to 100.00 %
    val maxCombo: Int,
    val perfectCount: Int,
    val greatCount: Int,
    val goodCount: Int,
    val mehCount: Int,
    val missCount: Int,
    val isPassed: Boolean,       // true = Win / Clear, false = Fail
    val letterGrade: String,     // "SS", "S", "A", "B", "C", "D", "F"
    val playedAt: Long = System.currentTimeMillis()
) {
    companion object {
        fun calculateGrade(accuracy: Float, isPassed: Boolean): String {
            if (!isPassed) return "F"
            return when {
                accuracy >= 100.0f -> "SS"
                accuracy >= 95.0f -> "S"
                accuracy >= 90.0f -> "A"
                accuracy >= 80.0f -> "B"
                accuracy >= 70.0f -> "C"
                else -> "D"
            }
        }
    }
}
