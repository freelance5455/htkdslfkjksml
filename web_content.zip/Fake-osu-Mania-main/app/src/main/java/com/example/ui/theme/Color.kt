package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mania Beat Cyber Theme Colors
val NeonCyan = Color(0xFF00E5FF)
val NeonPink = Color(0xFFFF2A85)
val NeonPurple = Color(0xFFB388FF)
val NeonYellow = Color(0xFFFFD600)
val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)

val CyberDarkBg = Color(0xFF0A0C13)
val CyberSurface = Color(0xFF131722)
val CyberSurfaceVariant = Color(0xFF1D2233)
val CyberBorder = Color(0xFF2C324B)

val LaneCyan = Color(0xFF00E5FF)
val LanePink = Color(0xFFFF2A85)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Judgments
val JudgmentPerfect = Color(0xFFFFD600)
val JudgmentGreat = Color(0xFF00E676)
val JudgmentGood = Color(0xFF00B0FF)
val JudgmentMeh = Color(0xFF90A4AE)
val JudgmentMiss = Color(0xFFFF1744)
