package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.HitJudgment
import com.example.ui.theme.*
import com.example.ui.viewmodel.ManiaViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun ResultsScreen(
    viewModel: ManiaViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateTo(Screen.SONG_SELECT)
    }

    val result by viewModel.lastFinishedScore.collectAsStateWithLifecycle()
    val record = result ?: return

    val isPassed = record.isPassed
    val gradeColor = when (record.letterGrade) {
        "SS" -> JudgmentPerfect
        "S" -> NeonCyan
        "A" -> NeonGreen
        "B" -> NeonYellow
        "C" -> NeonPink
        else -> NeonRed
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CyberDarkBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.5.dp,
                        color = if (isPassed) NeonGreen else NeonRed,
                        shape = RoundedCornerShape(16.dp)
                    ),
                colors = CardDefaults.cardColors(
                    containerColor = if (isPassed) NeonGreen.copy(alpha = 0.12f) else NeonRed.copy(alpha = 0.12f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isPassed) "CLEARED! تم اجتياز المستوى بنجاح" else "FAILED! نفدت طاقة الحياة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = if (isPassed) NeonGreen else NeonRed
                    )
                    Text(
                        text = "${record.songTitle} • ${record.difficultyName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Big Grade Badge & Score Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Big Letter Grade Circle
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(CyberSurface)
                        .border(3.dp, gradeColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = record.letterGrade,
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Black,
                        color = gradeColor
                    )
                }

                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "النتيجة الإجمالية",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "%07d".format(record.score),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = NeonYellow
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "الدقة: %.2f%%".format(record.accuracy),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )

                    Text(
                        text = "أعلى كومبو: ${record.maxCombo}x",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Judgments Breakdown Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberBorder, RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "تفاصيل الضربات (Judgments)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    JudgmentRow("PERFECT (300)", "مثالي", record.perfectCount, HitJudgment.PERFECT.color)
                    HorizontalDivider(color = CyberBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))
                    JudgmentRow("GREAT (200)", "رائع", record.greatCount, HitJudgment.GREAT.color)
                    HorizontalDivider(color = CyberBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))
                    JudgmentRow("GOOD (100)", "جيد", record.goodCount, HitJudgment.GOOD.color)
                    HorizontalDivider(color = CyberBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))
                    JudgmentRow("MEH (50)", "مقبول", record.mehCount, HitJudgment.MEH.color)
                    HorizontalDivider(color = CyberBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))
                    JudgmentRow("MISS (0)", "فائت", record.missCount, HitJudgment.MISS.color)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons: Play Again, Song Select, Home
            Button(
                onClick = { viewModel.startGameplay() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("retry_gameplay_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Retry")
                Spacer(modifier = Modifier.width(8.dp))
                Text("إعادة المحاولة (PLAY AGAIN)", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.navigateTo(Screen.SONG_SELECT) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = Brush.linearGradient(listOf(CyberBorder, CyberBorder))
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.QueueMusic, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("قائمة الأغاني")
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(Screen.HOME) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = Brush.linearGradient(listOf(CyberBorder, CyberBorder))
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Home, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("الرئيسية")
                }
            }
        }
    }
}

@Composable
private fun JudgmentRow(
    title: String,
    arabic: String,
    count: Int,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "$title • $arabic",
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )
        }
        Text(
            text = "$count",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
