package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.Beatmap
import kotlinx.coroutines.flow.Flow

@Dao
interface BeatmapDao {
    @Query("SELECT * FROM beatmaps WHERE songId = :songId ORDER BY createdAt ASC")
    fun getBeatmapsForSong(songId: String): Flow<List<Beatmap>>

    @Query("SELECT * FROM beatmaps WHERE id = :id LIMIT 1")
    suspend fun getBeatmapById(id: String): Beatmap?

    @Query("SELECT * FROM beatmaps ORDER BY createdAt DESC")
    fun getAllBeatmaps(): Flow<List<Beatmap>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeatmap(beatmap: Beatmap)

    @Query("DELETE FROM beatmaps WHERE id = :id")
    suspend fun deleteBeatmap(id: String)
}
