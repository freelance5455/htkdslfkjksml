package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class HitJudgment(
    val title: String,
    val arabicTitle: String,
    val scoreValue: Int,
    val maxWindowMs: Long,
    val color: Color
) {
    PERFECT("PERFECT", "مثالي", 300, 45L, JudgmentPerfect),
    GREAT("GREAT", "رائع", 200, 85L, JudgmentGreat),
    GOOD("GOOD", "جيد", 100, 130L, JudgmentGood),
    MEH("MEH", "مقبول", 50, 175L, JudgmentMeh),
    MISS("MISS", "فائت", 0, 220L, JudgmentMiss);

    companion object {
        fun evaluate(deltaMs: Long): HitJudgment {
            val absDelta = kotlin.math.abs(deltaMs)
            return when {
                absDelta <= PERFECT.maxWindowMs -> PERFECT
                absDelta <= GREAT.maxWindowMs -> GREAT
                absDelta <= GOOD.maxWindowMs -> GOOD
                absDelta <= MEH.maxWindowMs -> MEH
                else -> MISS
            }
        }
    }
}
