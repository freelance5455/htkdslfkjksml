package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.ManiaBeatTheme
import com.example.ui.viewmodel.ManiaViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ManiaBeatTheme {
                val viewModel: ManiaViewModel = viewModel()
                ManiaBeatApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun ManiaBeatApp(viewModel: ManiaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    Crossfade(
        targetState = currentScreen,
        animationSpec = tween(220),
        modifier = Modifier.fillMaxSize(),
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            Screen.HOME -> HomeScreen(viewModel = viewModel)
            Screen.SONG_SELECT -> SongSelectScreen(viewModel = viewModel)
            Screen.GAMEPLAY -> GameplayScreen(viewModel = viewModel)
            Screen.RESULTS -> ResultsScreen(viewModel = viewModel)
            Screen.STUDIO -> StudioScreen(viewModel = viewModel)
            Screen.STATS -> StatsScreen(viewModel = viewModel)
        }
    }
}
