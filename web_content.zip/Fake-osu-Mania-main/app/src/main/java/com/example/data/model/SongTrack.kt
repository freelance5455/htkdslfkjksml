package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class SongTrack(
    @PrimaryKey
    val id: String,
    val title: String,
    val artist: String,
    val audioPath: String,     // Local file path or bundled track identifier
    val durationMs: Long,
    val bpm: Int = 130,
    val isBundled: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis()
)
