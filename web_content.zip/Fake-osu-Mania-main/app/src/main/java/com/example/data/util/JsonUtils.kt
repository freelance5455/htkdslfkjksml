package com.example.data.util

import com.example.data.model.Note
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

object JsonUtils {
    private val moshi: Moshi = Moshi.Builder().build()
    private val noteListType = Types.newParameterizedType(List::class.java, Note::class.java)
    private val noteListAdapter: JsonAdapter<List<Note>> = moshi.adapter(noteListType)

    fun notesToJson(notes: List<Note>): String {
        return try {
            noteListAdapter.toJson(notes)
        } catch (e: Exception) {
            "[]"
        }
    }

    fun notesFromJson(json: String): List<Note> {
        return try {
            noteListAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
