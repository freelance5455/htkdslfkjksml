package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Note(
    val id: String,
    val lane: Int,         // 0, 1, 2, or 3
    val timeMs: Long,      // Target hit timestamp in ms
    val durationMs: Long = 0L // > 0 for hold / long notes
) {
    val isHoldNote: Boolean
        get() = durationMs > 50L

    val endTimeMs: Long
        get() = timeMs + durationMs
}
