package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

class GameAudioPlayer(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private var soundPool: SoundPool? = null
    private var hitsoundId: Int = 0

    private var isPrepared = false
    private var isPlaying = false
    private var onCompletionCallback: (() -> Unit)? = null

    init {
        initSoundPool()
    }

    private fun initSoundPool() {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            soundPool = SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(audioAttributes)
                .build()

            // Generate a crisp high-frequency click hitsound
            val hitsoundFile = getOrCreateHitsoundWav()
            hitsoundId = soundPool?.load(hitsoundFile.absolutePath, 1) ?: 0
        } catch (e: Exception) {
            Log.e("GameAudioPlayer", "Failed to init SoundPool", e)
        }
    }

    private fun getOrCreateHitsoundWav(): File {
        val file = File(context.cacheDir, "hitsound_tick.wav")
        if (!file.exists() || file.length() < 44) {
            try {
                val sampleRate = 44100
                val durationMs = 25
                val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
                val fos = FileOutputStream(file)
                fos.write(ByteArray(44)) // Header space

                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val progress = i.toDouble() / numSamples
                    val freq = 2200.0 * (1.0 - progress * 0.5)
                    val env = (1.0 - progress) * (1.0 - progress)
                    val sampleVal = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * env * 0.8
                    buffer[i] = (sampleVal * 32767).toInt().toShort()
                }

                val byteBuf = ByteBuffer.allocate(numSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
                buffer.forEach { byteBuf.putShort(it) }
                fos.write(byteBuf.array())
                fos.close()

                // Write header
                val raf = java.io.RandomAccessFile(file, "rw")
                val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                val audioBytesLength = numSamples * 2
                header.put("RIFF".toByteArray())
                header.putInt(audioBytesLength + 36)
                header.put("WAVE".toByteArray())
                header.put("fmt ".toByteArray())
                header.putInt(16)
                header.putShort(1) // PCM
                header.putShort(1) // Mono
                header.putInt(sampleRate)
                header.putInt(sampleRate * 2)
                header.putShort(2)
                header.putShort(16)
                header.put("data".toByteArray())
                header.putInt(audioBytesLength)
                raf.seek(0)
                raf.write(header.array())
                raf.close()
            } catch (e: Exception) {
                Log.e("GameAudioPlayer", "Error creating hitsound WAV", e)
            }
        }
        return file
    }

    fun playHitsound() {
        if (hitsoundId != 0) {
            soundPool?.play(hitsoundId, 0.75f, 0.75f, 1, 0, 1.0f)
        }
    }

    fun loadTrack(audioPath: String, onPrepared: (() -> Unit)? = null) {
        releasePlayer()
        try {
            val player = MediaPlayer().apply {
                if (audioPath.startsWith("content://") || audioPath.startsWith("file://")) {
                    setDataSource(context, Uri.parse(audioPath))
                } else {
                    setDataSource(audioPath)
                }
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .build()
                )
                setOnPreparedListener {
                    isPrepared = true
                    onPrepared?.invoke()
                }
                setOnCompletionListener {
                    this@GameAudioPlayer.isPlaying = false
                    onCompletionCallback?.invoke()
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e("GameAudioPlayer", "Error loading track: $audioPath", e)
        }
    }

    fun setOnCompletionListener(listener: () -> Unit) {
        this.onCompletionCallback = listener
    }

    fun play() {
        if (isPrepared && mediaPlayer?.isPlaying == false) {
            mediaPlayer?.start()
            isPlaying = true
        }
    }

    fun pause() {
        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.pause()
            isPlaying = false
        }
    }

    fun seekTo(positionMs: Long) {
        if (isPrepared) {
            mediaPlayer?.seekTo(positionMs.toInt())
        }
    }

    fun getCurrentPositionMs(): Long {
        return if (isPrepared && mediaPlayer != null) {
            mediaPlayer?.currentPosition?.toLong() ?: 0L
        } else 0L
    }

    fun getDurationMs(): Long {
        return if (isPrepared && mediaPlayer != null) {
            mediaPlayer?.duration?.toLong() ?: 0L
        } else 0L
    }

    fun isPlaying(): Boolean = isPlaying

    fun releasePlayer() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // Ignored
        } finally {
            mediaPlayer = null
            isPrepared = false
            isPlaying = false
        }
    }

    fun releaseAll() {
        releasePlayer()
        soundPool?.release()
        soundPool = null
    }
}
