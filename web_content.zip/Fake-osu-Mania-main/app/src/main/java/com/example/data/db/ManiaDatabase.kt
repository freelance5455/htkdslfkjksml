package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Beatmap
import com.example.data.model.ScoreRecord
import com.example.data.model.SongTrack

@Database(
    entities = [SongTrack::class, Beatmap::class, ScoreRecord::class],
    version = 1,
    exportSchema = false
)
abstract class ManiaDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun beatmapDao(): BeatmapDao
    abstract fun scoreDao(): ScoreDao

    companion object {
        @Volatile
        private var INSTANCE: ManiaDatabase? = null

        fun getInstance(context: Context): ManiaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ManiaDatabase::class.java,
                    "mania_beat.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
