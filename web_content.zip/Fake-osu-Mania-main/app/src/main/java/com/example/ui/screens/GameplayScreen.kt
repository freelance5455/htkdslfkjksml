package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.HitJudgment
import com.example.ui.theme.*
import com.example.ui.viewmodel.ManiaViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.isActive

@Composable
fun GameplayScreen(
    viewModel: ManiaViewModel,
    modifier: Modifier = Modifier
) {
    var isPaused by remember { mutableStateOf(false) }

    BackHandler {
        isPaused = true
        viewModel.audioPlayer.pause()
    }

    val session by viewModel.gameSession.collectAsStateWithLifecycle()
    val currentPlayhead by viewModel.currentPlayheadMs.collectAsStateWithLifecycle()

    // Active pressed state for visual hit feedback per lane
    val pressedLanes = remember { mutableStateMapOf<Int, Long>() }

    // Continuous 60+ FPS animation loop synchronized with audio
    LaunchedEffect(isPaused) {
        if (!isPaused) {
            while (isActive) {
                withFrameNanos {
                    val pos = viewModel.audioPlayer.getCurrentPositionMs()
                    viewModel.updatePlayhead(pos)
                }
            }
        }
    }

    val currentSession = session ?: return

    val health = currentSession.health
    val combo = currentSession.combo
    val score = currentSession.score
    val totalProcessed = currentSession.perfectCount + currentSession.greatCount +
            currentSession.goodCount + currentSession.mehCount + currentSession.missCount
    val maxWeighted = totalProcessed * 300f
    val currentWeighted = (currentSession.perfectCount * 300f) + (currentSession.greatCount * 200f) +
            (currentSession.goodCount * 100f) + (currentSession.mehCount * 50f)
    val accuracy = if (totalProcessed > 0) (currentWeighted / maxWeighted * 100f).coerceIn(0f, 100f) else 100f

    val latestJudgment = currentSession.latestJudgment
    val judgmentTime = currentSession.latestJudgmentTime
    val showJudgment = (System.currentTimeMillis() - judgmentTime) < 500L

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CyberDarkBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top HUD Bar: Score, Accuracy, Pause, Health bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "%07d".format(score),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = NeonYellow,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "الدقة: %.1f%%".format(accuracy),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (accuracy >= 90f) NeonCyan else NeonPink
                        )
                    }

                    // Health gauge bar
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "HP",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (health > 0.3f) NeonGreen else NeonRed
                            )
                            Text(
                                text = "%.0f%%".format(health * 100f),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyberSurface)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(health)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                if (health > 0.3f) NeonCyan else NeonRed,
                                                if (health > 0.3f) NeonGreen else NeonRed
                                            )
                                        )
                                    )
                            )
                        }
                    }

                    // Pause button
                    IconButton(
                        onClick = {
                            isPaused = true
                            viewModel.audioPlayer.pause()
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(CyberSurfaceVariant)
                            .testTag("pause_game_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause",
                            tint = TextPrimary
                        )
                    }
                }

                // 4K Highway Canvas
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    val scrollMultiplier = currentSession.beatmap.scrollSpeedMultiplier
                    val approachTimeMs = (1600f / scrollMultiplier).toLong()

                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        val highwayWidth = size.width
                        val highwayHeight = size.height
                        val laneWidth = highwayWidth / 4f
                        val hitLineY = highwayHeight * 0.82f

                        // Highway background
                        drawRect(
                            color = Color(0xFF0F121C),
                            size = Size(highwayWidth, highwayHeight)
                        )

                        // Vertical lane dividers
                        for (i in 1..3) {
                            val x = i * laneWidth
                            drawLine(
                                color = CyberBorder.copy(alpha = 0.5f),
                                start = Offset(x, 0f),
                                end = Offset(x, highwayHeight),
                                strokeWidth = 1.5f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f))
                            )
                        }

                        // Highway side borders
                        drawLine(
                            color = NeonCyan.copy(alpha = 0.7f),
                            start = Offset(0f, 0f),
                            end = Offset(0f, highwayHeight),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = NeonCyan.copy(alpha = 0.7f),
                            start = Offset(highwayWidth, 0f),
                            end = Offset(highwayWidth, highwayHeight),
                            strokeWidth = 3f
                        )

                        // Hit Judgment Line & Receptors
                        for (lane in 0..3) {
                            val laneX = lane * laneWidth
                            val isInner = lane == 1 || lane == 2
                            val laneColor = if (isInner) NeonPink else NeonCyan
                            val isPressed = pressedLanes.containsKey(lane) &&
                                    (System.currentTimeMillis() - (pressedLanes[lane] ?: 0L)) < 120L

                            // Receptor background glow on press
                            if (isPressed) {
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        listOf(Color.Transparent, laneColor.copy(alpha = 0.45f)),
                                        startY = hitLineY - 140f,
                                        endY = hitLineY + 30f
                                    ),
                                    topLeft = Offset(laneX, hitLineY - 140f),
                                    size = Size(laneWidth, 170f)
                                )
                            }

                            // Receptor Box
                            drawRoundRect(
                                color = if (isPressed) laneColor else laneColor.copy(alpha = 0.4f),
                                topLeft = Offset(laneX + 4f, hitLineY - 10f),
                                size = Size(laneWidth - 8f, 24f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                        }

                        // Hit Line Horizontal Beam
                        drawLine(
                            color = Color.White.copy(alpha = 0.85f),
                            start = Offset(0f, hitLineY),
                            end = Offset(highwayWidth, hitLineY),
                            strokeWidth = 3.5f
                        )

                        // Draw Falling Notes
                        val windowStart = currentPlayhead - 100L
                        val windowEnd = currentPlayhead + approachTimeMs

                        val visibleNotes = currentSession.notes.filter { note ->
                            !currentSession.processedNoteIds.contains(note.id) &&
                                    note.endTimeMs >= windowStart &&
                                    note.timeMs <= windowEnd
                        }

                        visibleNotes.forEach { note ->
                            val laneX = note.lane * laneWidth
                            val isInner = note.lane == 1 || note.lane == 2
                            val noteColor = if (isInner) NeonPink else NeonCyan

                            val progress = (currentPlayhead - (note.timeMs - approachTimeMs)).toFloat() / approachTimeMs
                            val noteHeadY = progress * hitLineY

                            if (note.isHoldNote) {
                                // Draw hold note tail / beam
                                val endProgress = (currentPlayhead - (note.endTimeMs - approachTimeMs)).toFloat() / approachTimeMs
                                val noteTailY = (endProgress * hitLineY).coerceAtLeast(0f)
                                val beamHeight = (noteHeadY - noteTailY).coerceAtLeast(10f)

                                drawRoundRect(
                                    brush = Brush.verticalGradient(
                                        listOf(noteColor.copy(alpha = 0.35f), noteColor.copy(alpha = 0.85f)),
                                        startY = noteTailY,
                                        endY = noteHeadY
                                    ),
                                    topLeft = Offset(laneX + 12f, noteTailY),
                                    size = Size(laneWidth - 24f, beamHeight),
                                    cornerRadius = CornerRadius(4f, 4f)
                                )
                            }

                            // Draw Note Head
                            drawRoundRect(
                                brush = Brush.verticalGradient(
                                    listOf(Color.White, noteColor),
                                    startY = noteHeadY - 14f,
                                    endY = noteHeadY + 14f
                                ),
                                topLeft = Offset(laneX + 6f, noteHeadY - 14f),
                                size = Size(laneWidth - 12f, 26f),
                                cornerRadius = CornerRadius(8f, 8f)
                            )
                        }
                    }

                    // Floating Combo & Judgment overlay in the center of highway
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (combo > 2) {
                            Text(
                                text = "$combo",
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Black,
                                color = NeonYellow,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "COMBO",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                letterSpacing = 3.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (showJudgment && latestJudgment != null) {
                            Text(
                                text = "${latestJudgment.title} • ${latestJudgment.arabicTitle}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = latestJudgment.color,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                // 4 Interactive Touch Receptor Buttons at the bottom
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(115.dp)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (lane in 0..3) {
                        val isInner = lane == 1 || lane == 2
                        val keyColor = if (isInner) NeonPink else NeonCyan

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (pressedLanes.containsKey(lane)) keyColor.copy(alpha = 0.5f)
                                    else CyberSurfaceVariant
                                )
                                .border(
                                    width = 2.dp,
                                    color = if (pressedLanes.containsKey(lane)) keyColor else CyberBorder,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onPress = {
                                            pressedLanes[lane] = System.currentTimeMillis()
                                            viewModel.onLanePress(lane)
                                            tryAwaitRelease()
                                        }
                                    )
                                }
                                .testTag("lane_key_$lane"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "KEY ${lane + 1}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (pressedLanes.containsKey(lane)) Color.White else keyColor
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(keyColor)
                                )
                            }
                        }
                    }
                }
            }

            // Pause Dialog
            if (isPaused) {
                AlertDialog(
                    onDismissRequest = {
                        isPaused = false
                        viewModel.audioPlayer.play()
                    },
                    containerColor = CyberSurface,
                    title = {
                        Text(
                            text = "إيقاف مؤقت (PAUSED)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = NeonCyan
                        )
                    },
                    text = {
                        Text(
                            text = "المستوى: ${currentSession.song.title} (${currentSession.beatmap.difficultyName})",
                            color = TextSecondary
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                isPaused = false
                                viewModel.audioPlayer.play()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("استئناف")
                        }
                    },
                    dismissButton = {
                        Row {
                            TextButton(
                                onClick = {
                                    isPaused = false
                                    viewModel.startGameplay()
                                }
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = NeonYellow)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إعادة الجولة", color = NeonYellow)
                            }
                            TextButton(
                                onClick = {
                                    isPaused = false
                                    viewModel.navigateTo(Screen.SONG_SELECT)
                                }
                            ) {
                                Text("خروج", color = TextSecondary)
                            }
                        }
                    }
                )
            }
        }
    }
}
