package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.ui.viewmodel.ManiaViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.isActive

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
    viewModel: ManiaViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateTo(Screen.SONG_SELECT)
    }

    val selectedSong by viewModel.selectedSong.collectAsStateWithLifecycle()
    val notes by viewModel.studioNotes.collectAsStateWithLifecycle()
    val cursorTimeMs by viewModel.studioPositionMs.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isStudioPlaying.collectAsStateWithLifecycle()
    val isLiveRecording by viewModel.isLiveRecording.collectAsStateWithLifecycle()

    var showSaveDialog by remember { mutableStateOf(false) }
    var beatmapName by remember { mutableStateOf("My Studio Map") }
    var scrollSpeed by remember { mutableFloatStateOf(1.8f) }
    var selectedNoteDurationMs by remember { mutableLongStateOf(0L) } // 0 = tap note, >0 = hold note

    val song = selectedSong ?: return

    // Audio tracking in studio when playing
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isActive) {
                withFrameNanos {
                    val pos = viewModel.audioPlayer.getCurrentPositionMs()
                    viewModel.updateStudioTimelinePosition(pos)
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CyberDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ستوديو التصميم (Beatmap Studio)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NeonYellow
                        )
                        Text(
                            text = "${song.title} • ${notes.size} نوتة",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.SONG_SELECT) },
                        modifier = Modifier.testTag("studio_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSaveDialog = true },
                        modifier = Modifier.testTag("studio_save_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save",
                            tint = NeonCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CyberSurface)
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(14.dp)
        ) {
            // Timeline Time indicator & scrubber
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatTime(cursorTimeMs),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = NeonCyan
                        )
                        Text(
                            text = "المدة: ${formatTime(song.durationMs)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Slider(
                        value = cursorTimeMs.toFloat(),
                        onValueChange = { viewModel.seekStudioPosition(it.toLong()) },
                        valueRange = 0f..song.durationMs.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = NeonCyan,
                            activeTrackColor = NeonCyan
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Studio Visual Highway / Timeline Canvas
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.5.dp, CyberBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C0E17)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures { offset ->
                                    val laneWidth = size.width / 4f
                                    val tappedLane = (offset.x / laneWidth).toInt().coerceIn(0, 3)
                                    viewModel.addStudioNoteAtCurrentTime(tappedLane, selectedNoteDurationMs)
                                }
                            }
                    ) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height
                        val laneWidth = canvasWidth / 4f
                        val cursorY = canvasHeight * 0.75f // Cursor line position

                        // Draw 4 lane columns
                        for (i in 1..3) {
                            drawLine(
                                color = CyberBorder,
                                start = Offset(i * laneWidth, 0f),
                                end = Offset(i * laneWidth, canvasHeight),
                                strokeWidth = 1.5f
                            )
                        }

                        // Cursor reference line
                        drawLine(
                            color = NeonYellow,
                            start = Offset(0f, cursorY),
                            end = Offset(canvasWidth, cursorY),
                            strokeWidth = 2.5f
                        )

                        // Render notes relative to cursor time (±2000ms window)
                        val windowMs = 2500L
                        val visibleNotes = notes.filter {
                            kotlin.math.abs(it.timeMs - cursorTimeMs) <= windowMs
                        }

                        visibleNotes.forEach { note ->
                            val laneX = note.lane * laneWidth
                            val isInner = note.lane == 1 || note.lane == 2
                            val noteColor = if (isInner) NeonPink else NeonCyan

                            val deltaMs = note.timeMs - cursorTimeMs
                            val y = cursorY - (deltaMs.toFloat() / windowMs) * (canvasHeight * 0.5f)

                            if (y in -50f..canvasHeight + 50f) {
                                if (note.isHoldNote) {
                                    val holdHeight = (note.durationMs.toFloat() / windowMs) * (canvasHeight * 0.5f)
                                    drawRoundRect(
                                        color = noteColor.copy(alpha = 0.45f),
                                        topLeft = Offset(laneX + 12f, y - holdHeight),
                                        size = Size(laneWidth - 24f, holdHeight),
                                        cornerRadius = CornerRadius(4f, 4f)
                                    )
                                }

                                drawRoundRect(
                                    color = noteColor,
                                    topLeft = Offset(laneX + 6f, y - 8f),
                                    size = Size(laneWidth - 12f, 18f),
                                    cornerRadius = CornerRadius(6f, 6f)
                                )
                            }
                        }
                    }

                    // Watermark hint
                    Text(
                        text = "المس أي مسار لوضع أو إزالة نوتة عند المؤشر الأصفر",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Studio Controls Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Play / Pause toggle
                FilledTonalButton(
                    onClick = { viewModel.toggleStudioPlayback() },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = if (isPlaying) NeonPink else NeonCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isPlaying) "إيقاف" else "تشغيل")
                }

                // Live Record Toggle
                FilterChip(
                    selected = isLiveRecording,
                    onClick = { viewModel.toggleLiveRecording() },
                    label = { Text("تسجيل حي (Live)") },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isLiveRecording) NeonRed else TextMuted)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonRed.copy(alpha = 0.25f),
                        selectedLabelColor = NeonRed,
                        containerColor = CyberSurface,
                        labelColor = TextPrimary
                    )
                )

                // Hold note duration toggle
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("نوع النوتة:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(modifier = Modifier.width(6.dp))
                    FilterChip(
                        selected = selectedNoteDurationMs > 0,
                        onClick = {
                            selectedNoteDurationMs = if (selectedNoteDurationMs == 0L) 350L else 0L
                        },
                        label = { Text(if (selectedNoteDurationMs > 0) "طويلة (Hold)" else "عادية (Tap)") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4 Tap Pads to insert notes at current time
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (lane in 0..3) {
                    val isInner = lane == 1 || lane == 2
                    val keyColor = if (isInner) NeonPink else NeonCyan

                    Button(
                        onClick = { viewModel.addStudioNoteAtCurrentTime(lane, selectedNoteDurationMs) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("studio_lane_$lane"),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant),
                        shape = RoundedCornerShape(14.dp),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(keyColor)
                        )
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "LANE ${lane + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = keyColor
                            )
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = keyColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Save Beatmap Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            containerColor = CyberSurface,
            title = {
                Text(
                    text = "حفظ الـ Beatmap الجديد",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = NeonYellow
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "عدد النوتات: ${notes.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = beatmapName,
                        onValueChange = { beatmapName = it },
                        label = { Text("اسم المستوى (Map Name)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonYellow,
                            unfocusedBorderColor = CyberBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("سرعة السقوط:", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        Text("%.1fx".format(scrollSpeed), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = NeonCyan)
                    }
                    Slider(
                        value = scrollSpeed,
                        onValueChange = { scrollSpeed = it },
                        valueRange = 1.0f..3.5f,
                        steps = 9,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveStudioBeatmap(beatmapName, scrollSpeed)
                        showSaveDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonYellow, contentColor = Color.Black)
                ) {
                    Text("حفظ والعودة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val millis = ((ms % 1000) / 10).toInt()
    return "%02d:%02d.%02d".format(minutes, seconds, millis)
}
