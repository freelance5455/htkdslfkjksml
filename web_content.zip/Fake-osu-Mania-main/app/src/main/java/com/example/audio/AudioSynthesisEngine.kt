package com.example.audio

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

object AudioSynthesisEngine {
    private const val SAMPLE_RATE = 44100

    /**
     * Synthesizes a high-energy electronic rhythm track and writes it to a WAV file.
     * Returns the File pointer.
     */
    fun getOrCreateBundledTrack(
        context: Context,
        trackId: String,
        bpm: Int,
        durationSeconds: Int = 45
    ): File {
        val audioDir = File(context.cacheDir, "bundled_audio").apply { mkdirs() }
        val targetFile = File(audioDir, "$trackId.wav")

        if (targetFile.exists() && targetFile.length() > 44) {
            return targetFile
        }

        generateElectronicTrack(targetFile, bpm, durationSeconds)
        return targetFile
    }

    private fun generateElectronicTrack(file: File, bpm: Int, durationSec: Int) {
        val totalSamples = SAMPLE_RATE * durationSec
        val beatLengthSamples = (60.0 * SAMPLE_RATE / bpm).toInt()
        val quarterBeatSamples = beatLengthSamples / 4

        val fos = FileOutputStream(file)
        // Write placeholder WAV header (44 bytes)
        fos.write(ByteArray(44))

        val buffer = ShortArray(4096)
        var bufferIdx = 0

        // Musical scales (Pentatonic minor for melodic cyber feel)
        val bassFreqs = doubleArrayOf(55.0, 65.41, 73.42, 82.41, 98.0) // A1, C2, D2, E2, G2
        val leadFreqs = doubleArrayOf(220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25)

        for (sample in 0 until totalSamples) {
            val beatNum = sample / beatLengthSamples
            val sampleInBeat = sample % beatLengthSamples
            val quarterBeatNum = (sampleInBeat / quarterBeatSamples).coerceIn(0, 3)
            val sampleInQuarter = sampleInBeat % quarterBeatSamples

            var mixedSignal = 0.0

            // 1. Kick drum on beats 0, 1, 2, 3 (every beat)
            val kickProgress = sampleInBeat.toDouble() / (SAMPLE_RATE * 0.22).coerceAtLeast(1.0)
            if (kickProgress < 1.0) {
                val kickFreq = 140.0 * (1.0 - kickProgress * 0.85) + 38.0
                val kickEnv = (1.0 - kickProgress) * (1.0 - kickProgress)
                mixedSignal += sin(2.0 * PI * kickFreq * (sampleInBeat.toDouble() / SAMPLE_RATE)) * kickEnv * 0.55
            }

            // 2. Snare / Clap on beats 1 and 3 (osu! mania style backbeat)
            val isSnareBeat = (beatNum % 2 == 1)
            if (isSnareBeat) {
                val snareProgress = sampleInBeat.toDouble() / (SAMPLE_RATE * 0.20).coerceAtLeast(1.0)
                if (snareProgress < 1.0) {
                    val noise = (Math.random() * 2.0 - 1.0)
                    val tone = sin(2.0 * PI * 185.0 * (sampleInBeat.toDouble() / SAMPLE_RATE)) * 0.4
                    val snareEnv = (1.0 - snareProgress)
                    mixedSignal += (noise * 0.6 + tone) * snareEnv * 0.40
                }
            }

            // 3. Hi-hats on off-beats (8th and 16th notes)
            val hatProgress = sampleInQuarter.toDouble() / (SAMPLE_RATE * 0.05).coerceAtLeast(1.0)
            if (hatProgress < 1.0 && quarterBeatNum % 2 == 1) {
                val hatNoise = (Math.random() * 2.0 - 1.0)
                val hatEnv = (1.0 - hatProgress)
                mixedSignal += hatNoise * hatEnv * 0.18
            }

            // 4. Bassline: Rolling 16th note bass
            val bassPitch = bassFreqs[(beatNum / 4) % bassFreqs.size]
            val bassPhase = (sample.toDouble() * bassPitch) / SAMPLE_RATE
            val bassEnv = 1.0 - (sampleInQuarter.toDouble() / quarterBeatSamples).coerceIn(0.0, 1.0) * 0.4
            val bassWave = (sin(2.0 * PI * bassPhase) + 0.3 * sin(4.0 * PI * bassPhase)) * bassEnv * 0.25
            mixedSignal += bassWave

            // 5. Arpeggiated Cyber Lead Melody
            val noteIdx = (sample / (beatLengthSamples / 4)) % leadFreqs.size
            val leadPitch = leadFreqs[noteIdx]
            val leadPhase = (sample.toDouble() * leadPitch) / SAMPLE_RATE
            val leadEnv = (1.0 - (sampleInQuarter.toDouble() / quarterBeatSamples)).coerceIn(0.0, 1.0)
            val leadTone = (sin(2.0 * PI * leadPhase) + 0.4 * sin(6.0 * PI * leadPhase)) * leadEnv * 0.22
            mixedSignal += leadTone

            // Soft clipping / limiter
            val clamped = mixedSignal.coerceIn(-0.95, 0.95)
            buffer[bufferIdx++] = (clamped * 32767.0).toInt().toShort()

            if (bufferIdx == buffer.size) {
                val byteBuf = ByteBuffer.allocate(buffer.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                buffer.forEach { byteBuf.putShort(it) }
                fos.write(byteBuf.array())
                bufferIdx = 0
            }
        }

        if (bufferIdx > 0) {
            val byteBuf = ByteBuffer.allocate(bufferIdx * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until bufferIdx) {
                byteBuf.putShort(buffer[i])
            }
            fos.write(byteBuf.array())
        }

        fos.close()

        // Write standard 44-byte WAV header
        val audioBytesLength = totalSamples * 2
        writeWavHeader(file, audioBytesLength)
    }

    private fun writeWavHeader(file: File, audioBytesLength: Int) {
        val raf = RandomAccessFile(file, "rw")
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        val totalDataLen = audioBytesLength + 36

        // RIFF chunk descriptor
        header.put("RIFF".toByteArray())
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray())

        // "fmt " sub-chunk
        header.put("fmt ".toByteArray())
        header.putInt(16) // Subchunk1Size for PCM
        header.putShort(1) // AudioFormat: 1 = PCM
        header.putShort(1) // NumChannels: 1 = Mono
        header.putInt(SAMPLE_RATE)
        header.putInt(SAMPLE_RATE * 2) // ByteRate
        header.putShort(2) // BlockAlign
        header.putShort(16) // BitsPerSample

        // "data" sub-chunk
        header.put("data".toByteArray())
        header.putInt(audioBytesLength)

        raf.seek(0)
        raf.write(header.array())
        raf.close()
    }
}
