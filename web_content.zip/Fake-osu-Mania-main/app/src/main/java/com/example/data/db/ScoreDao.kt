package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ScoreRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface ScoreDao {
    @Query("SELECT * FROM scores ORDER BY playedAt DESC")
    fun getAllScores(): Flow<List<ScoreRecord>>

    @Query("SELECT * FROM scores WHERE beatmapId = :beatmapId ORDER BY score DESC LIMIT 1")
    suspend fun getHighScoreForBeatmap(beatmapId: String): ScoreRecord?

    @Query("SELECT COUNT(*) FROM scores")
    fun getTotalPlaysCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM scores WHERE isPassed = 1")
    fun getPassCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(scoreRecord: ScoreRecord)

    @Query("DELETE FROM scores")
    suspend fun clearAllScores()
}
