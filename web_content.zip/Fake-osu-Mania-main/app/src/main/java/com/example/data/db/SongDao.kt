package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.SongTrack
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
    @Query("SELECT * FROM songs ORDER BY isBundled DESC, dateAdded DESC")
    fun getAllSongs(): Flow<List<SongTrack>>

    @Query("SELECT * FROM songs WHERE id = :id LIMIT 1")
    suspend fun getSongById(id: String): SongTrack?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: SongTrack)

    @Query("DELETE FROM songs WHERE id = :id")
    suspend fun deleteSong(id: String)
}
