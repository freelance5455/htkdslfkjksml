# Mania Beat: osu! Mania Rhythm Game & Studio

Mania Beat is a high-performance Android rhythm game inspired by *osu! Mania* featuring classic 4-Key (4K) gameplay, an algorithmic audio-to-beatmap auto-generator with customizable density, a full-featured Beatmap Studio editor, and comprehensive player performance statistics including win rate, accuracy grades, and combo tracking.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during the clarification interview:

- **Confirmed Decision 1 (Key Layout)**: Classic 4-Key (4K) lane layout tailored for mobile ergonomics with responsive dual-thumb / multi-finger touch zones, lane hit lights, and key glow feedback.
- **Confirmed Decision 2 (Auto-Beatmap Generation)**: Configurable audio onset detection with real-time sliders for note density (frequency sensitivity threshold) and scroll speed before generating the beatmap from device audio files.
- **Confirmed Decision 3 (Bundled & Custom Songs)**: Bundled with pre-loaded high-tempo electronic/synthwave tracks ready to play immediately on first launch, alongside Android Storage Access Framework audio import (MP3, WAV, OGG, M4A).
- **Confirmed Feature (Beatmap Studio & Stats)**: A tactile Beatmap Studio with audio waveform timeline, bpm/beat snapping, tap/hold note placement, and a persistent statistics dashboard tracking games played, win rate, average accuracy, and grade distribution (SS, S, A, B, C, D).

---

### 1. Overview & Core Concept

- **What It Does**:
  - **4K Rhythm Engine**: Top-to-bottom falling note highway (osu! Mania style) with precise millisecond hit judgments (PERFECT ±40ms, GREAT ±80ms, GOOD ±120ms, MEH ±160ms, MISS).
  - **Auto-Beatmap Generator**: Analyzes any device audio track (or pre-bundled songs) using spectral onset and energy envelope peak detection to generate rhythmic tap notes and hold notes aligned to musical transients.
  - **Beatmap Studio**: Interactive visual editor where players can scrub through songs, preview playback, set BPM & offset, tap to record beats in real-time, or place/delete notes on a quantized grid.
  - **Player Performance & Win Rate**: Detailed score results screen and stats profile calculating overall win rate (pass percentage), max combo, total score, letter grades, and accuracy percentage.
- **Target Audience**: Rhythm game enthusiasts, osu! Mania players on mobile, and music creators who want to play their own audio library.
- **Key Value**: Delivers genuine osu! Mania feel on Android with zero cloud dependencies, instant track loading, and creative freedom to build and auto-generate beatmaps from any personal audio file.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Play Flow**: Home Screen → Select Song (Bundled or Imported) → Choose Difficulty / Scroll Speed → 4K Gameplay Canvas with real-time audio sync → Results Screen with Accuracy, Grade, Max Combo, and Win/Loss status.
2. **Import & Auto-Generate Flow**: Home Screen / Song Select → Tap "استيراد أغنية" (Import Audio) → Select MP3/WAV/OGG via system file picker → Adjust Density Slider & Speed → Generate & Test Beatmap → Save to Library.
3. **Beatmap Studio Flow**: Studio Screen → Select or Create Beatmap → Interactive Timeline scrubbing → Grid Snap (1/4, 1/8, 1/16 beats) → Tap lanes to insert/remove tap notes or drag hold notes → Test Play → Save to Room Database.
4. **Stats & Win Rate Flow**: Profile / Stats Tab → View overall Win Rate %, total plays, clears vs fails, accuracy radar/distribution, and grade counts (SS, S, A, B, C, D).

#### Visual Identity & Theme
- **Theme Direction**: Cyberpunk Neon Dark Mode (`#0D0E15` background) with high-contrast glowing lane accents:
  - Lane 1 & 4 (Outer lanes): Vivid Cyan Neon (`#00E5FF`)
  - Lane 2 & 3 (Inner lanes): Electric Magenta / Pink Neon (`#FF1744` / `#E040FB`)
  - Hit Zone & Judgments: Gold/Yellow for 300 PERFECT (`#FFD600`), Green for GREAT (`#00E676`), Cyan for GOOD (`#00B0FF`), Gray for MEH (`#90A4AE`), Crimson Red for MISS (`#FF1744`).
- **Typography**: Clean, futuristic, high-legibility display numbers and stats with bold Arabic and English labeling.
- **Interactive Feedback**:
  - Receptive column touch receptors with expanding shockwave particles on tap.
  - Health/Life gauge (Drain on miss, refill on Perfect/Great). Drop to 0% triggers Fail condition (impacting Win Rate).
  - Floating combo counter with bounce animation and accuracy judgment text.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Audio Playback & Synchronization Engine**
  - *Chosen Approach*: Android `MediaPlayer` synchronized with `System.nanoTime()` / `currentPosition` tracking using a high-rate Compose frame clock (`withFrameNanos` / `Canvas`).
  - *Why*: Ensures stutter-free 60+ FPS note rendering with millisecond audio synchronization without external native C++ library complexity.
- **Decision 2: Audio Onset Detection Algorithm**
  - *Chosen Approach*: Dual-mode generator: Energy envelope transient detection on decoded PCM data (using Android's `MediaExtractor` & `MediaCodec`), with adaptive thresholding controlled by the user's density slider.
  - *Why*: Works fully on-device without needing internet or cloud APIs, providing instant beatmap creation from any local audio file.
- **Decision 3: Persistence with Room Database**
  - *Chosen Approach*: Room Database with entities for `SongTrack`, `Beatmap`, `ScoreRecord`, and `PlayerStats`.
  - *Why*: Device-local persistence ensures all custom created beatmaps, imported songs, high scores, and win rates survive app restarts instantly without mandatory logins.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                              Mania Beat                                │
├────────────────────────────────────────────────────────────────────────┤
│                               UI LAYER                                 │
│  ┌─────────────────┐  ┌─────────────────┐  ┌────────────────────────┐  │
│  │   HomeScreen    │  │   SongSelect    │  │     GameplayScreen     │  │
│  │  Quick play,    │  │  Track cards,   │  │  4K Highway Canvas,    │  │
│  │  stats preview  │  │  density slider │  │  receptors, judgments  │  │
│  └────────┬────────┘  └────────┬────────┘  └───────────┬────────────┘  │
│           │                    │                       │               │
│  ┌────────┴────────┐  ┌────────┴────────┐              │               │
│  │  BeatmapStudio  │  │  StatsProfile   │              │               │
│  │  Timeline, grid │  │  Win rate %,    │              │               │
│  │  note placer    │  │  grade counters │              │               │
│  └────────┬────────┘  └────────┬────────┘              │               │
├───────────┼────────────────────┼───────────────────────┼───────────────┤
│           ▼                    ▼                       ▼               │
│                         VIEWMODEL LAYER                                │
│       ManiaViewModel  •  StudioViewModel  •  AudioAnalysisEngine       │
├────────────────────────────────┬───────────────────────────────────────┤
│                                ▼                                       │
│                       DATA & AUDIO LAYER                               │
│  ┌─────────────────────────────┐  ┌─────────────────────────────────┐  │
│  │     AudioEngineManager      │  │        Room AppDatabase         │  │
│  │  MediaPlayer playback,      │  │  - SongTrackDao                 │  │
│  │  MediaCodec beat analysis   │  │  - BeatmapDao                   │  │
│  │  sample sound synthesis     │  │  - ScoreRecordDao               │  │
│  └─────────────────────────────┘  └─────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

#### Core Data Entities:
1. `SongTrack`: ID, title, artist, audioUri (or bundled asset path), durationMs, bpm.
2. `Beatmap`: ID, songTrackId, difficultyName, scrollSpeed, noteCount, notesJson (list of lane, timeMs, durationMs).
3. `ScoreRecord`: ID, beatmapId, score, accuracy, maxCombo, perfectCount, greatCount, goodCount, mehCount, missCount, isPassed, timestamp.
4. `PlayerStats`: Games played, wins, winRate, highestCombo, letterGradeTotals.
