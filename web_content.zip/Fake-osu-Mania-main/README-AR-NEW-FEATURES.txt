# Mania Beat - mobile project

## What was added
- `index.html`: Arabic mobile-friendly beatmap studio prototype.
- Select audio files or MP4 videos; MP4 can be used as a background during the current browser session.
- Approximate BPM estimation from decoded audio (browser support varies).
- Automatic four-lane note generation with adjustable density and hold-note probability.
- Local beatmap library, a simple studio for adding/removing notes, and a playback preview.
- Portrait/landscape layout selector.

## Important limitations
- The HTML studio is a browser prototype. It is not wired into the existing Kotlin/Jetpack Compose app automatically.
- The existing Android app remains the native Kotlin project in `app/`.
- The HTML page stores beatmap metadata in browser local storage. Browsers do not allow a normal web page to permanently keep selected local MP3/MP4 bytes in local storage, so reselect media after reopening the page if you need to preview it again.
- BPM estimation is approximate, and generated notes follow a beat grid with randomized lanes. This is not professional melody transcription.
- This package is source code, not a compiled APK. Use the project's Gradle build workflow to build the native Android app.

## Use on a phone
Open `index.html` in a modern browser, or host the project as a static website. For full local-file handling and a reliable APK experience, the HTML prototype needs to be integrated into an Android WebView or the features need to be implemented natively.
