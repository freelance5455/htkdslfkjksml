WA BUG SIMULATOR — PROJECT ANDROID

Isi:
- app/src/main/assets/index.html : antarmuka simulator
- Android WebView wrapper untuk menjalankan HTML sebagai aplikasi Android

PENTING:
Ini proyek sumber Android, bukan file APK yang sudah dikompilasi. Untuk menghasilkan APK, diperlukan Android Studio/Android SDK.

Cara build di Android Studio:
1. Ekstrak ZIP ini.
2. Buka Android Studio > Open, lalu pilih folder WA_Bug_Simulator_Android.
3. Tunggu Gradle Sync selesai. Jika diminta, gunakan JDK 17 dan pasang Android SDK Platform 35.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.
6. Untuk memasang di HP, pindahkan APK ke perangkat dan izinkan instalasi dari sumber tersebut bila Android memintanya.

Alternatif: gunakan Android Studio di komputer. HTML bisa dibuka langsung di browser untuk mencoba simulasi tanpa build APK.

Simulator ini hanya menampilkan animasi/log lokal. Tidak terhubung ke WhatsApp, tidak mengirim pesan, dan tidak mengganggu perangkat lain.
