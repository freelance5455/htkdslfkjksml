(() => {
'use strict';
const bad=/^(javascript|data|vbscript):/i;
const unsafeSchemes=/^(javascript|vbscript|file|data):/i;
document.addEventListener('click',e=>{
  const a=e.target?.closest?.('a[href]');
  if(a){
    const href=(a.getAttribute('href')||'').trim();
    if(bad.test(href)||unsafeSchemes.test(href)){e.preventDefault();e.stopPropagation();}
    else if(/^https?:/i.test(href)){e.preventDefault();e.stopPropagation();}
  }
},true);
document.addEventListener('submit',e=>e.preventDefault(),true);
window.addEventListener('error',e=>{try{console.error('Syllabe:',e.error||e.message)}catch(_){}});
window.addEventListener('unhandledrejection',e=>{try{console.error('Syllabe promise:',e.reason)}catch(_){}; e.preventDefault?.();});
})();
