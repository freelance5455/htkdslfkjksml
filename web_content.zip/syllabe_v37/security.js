(() => {
'use strict';
const bad=/^(javascript|data|vbscript):/i;
document.addEventListener('click',e=>{const a=e.target?.closest?.('a[href]'); if(a&&bad.test((a.getAttribute('href')||'').trim())){e.preventDefault();e.stopPropagation();}},true);
document.addEventListener('submit',e=>e.preventDefault(),true);
})();
