SYLLABE V3.8 — CORRECTIONS AUDIO + QUESTIONS SANS REPETITION

Corrections de cette version :
- Le moteur SpeechSynthesis est lancé immédiatement depuis le geste utilisateur, sans attendre getVoices().
- resume()/cancel()/retry sont utilisés pour les WebView Android qui mettent la synthèse en pause.
- Une voix française fr-FR est sélectionnée quand elle existe.
- Le bouton d'activation vocale teste réellement « Bonjour ».
- Le questionnaire de syllabes utilise une file mélangée : chaque syllabe est utilisée une fois avant de réapparaître.
- Le questionnaire d'images utilise la même logique : chaque mot/image est utilisé une fois avant le nouveau cycle.
- La banque d'images/mots a été enrichie à environ 100 éléments et le doublon « bébé » a été supprimé.
- Les fichiers restent 100 % locaux et fonctionnent hors Internet.

INSTALLATION TERMUX
1. unzip Syllabe_V3_8_Corrigee.zip -d Syllabe_V3_8
2. cd Syllabe_V3_8/syllabe_v37
3. python server.py
4. Ouvrir http://127.0.0.1:8080

IMPORTANT POUR LE SON ANDROID
Le ZIP est la version Web/Termux. Le son vocal dépend du moteur de synthèse vocale disponible dans le navigateur/WebView.
Si Android ne parle toujours pas :
- vérifier le volume « Multimédia » ;
- vérifier qu'un moteur de synthèse vocale est installé ;
- installer/activer une voix française dans les réglages de synthèse vocale ;
- ouvrir l'application puis appuyer sur « Activer la voix » et écouter le test « Bonjour ».

Cette version ne prétend pas fournir un Text-to-Speech natif Android : pour cela il faut la couche APK Android/WebView qui expose android.speech.tts.TextToSpeech.
