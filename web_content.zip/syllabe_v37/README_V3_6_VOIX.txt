Syllabe V3.6 — moteur de lecture vocale optimisé

Améliorations :
- attente du chargement des voix Android ;
- sélection prioritaire d'une voix française fr-FR ;
- débit enfant ralenti et borné ;
- annulation propre des lectures précédentes ;
- protection contre les lectures qui se chevauchent ;
- reprise de secours dans certains WebView Android ;
- correction de la lecture automatique du quiz : elle est déclenchée par l'action de l'enfant, ce qui évite les blocages d'autoplay ;
- lecture séquentielle fiable des syllabes sélectionnées ;
- guide de prononciation pour les graphies difficiles.

IMPORTANT : la synthèse vocale dépend du moteur TTS installé sur Android/WebView. Pour une voix 100% fiable hors connexion, la solution la plus robuste reste un moteur Android TTS natif ou des enregistrements audio intégrés.
