(() => {
  'use strict';

  const DATA = {
    1: { title: 'Voyelles', subtitle: 'Les sons de base', items: ['a','e','é','è','ê','ë','i','î','ï','o','ô','u','û','ü','y'] },
    2: { title: 'Syllabes simples', subtitle: 'Consonne + voyelle', items: cv(['b','c','d','f','g','j','l','m','n','p','r','s','t','v'], ['a','e','i','o','u','y']) },
    3: { title: 'Sons fréquents', subtitle: 'ou, oi, ai, ei, au, eau, eu…', items: unique(['ou','oi','ai','ei','au','eau','eu','œu','ui','oin','ion','ien','ien','oin','oin','qu','gu','ch','ph','gn','ill', ...cv(['b','c','d','f','j','l','m','n','p','r','s','t','v'], ['ou','oi','ai','ei','au','eu','ui'])]) },
    4: { title: 'Groupes consonantiques', subtitle: 'Deux consonnes + voyelle', items: cv(['bl','br','cl','cr','dr','fl','fr','gl','gr','pl','pr','tr','vr'], ['a','e','i','o','u','ou','oi']) },
    5: { title: 'Sons nasaux', subtitle: 'an, en, on, in, un…', items: unique(['an','am','en','em','on','om','in','im','yn','ym','un','um','ain','ein','aim','eim','ien','oin', ...cv(['b','c','d','f','g','j','l','m','p','r','s','t','v'], ['an','en','on','in','un','ain','ein'])]) },
    6: { title: 'Sons et écritures', subtitle: 'ch, j, gn, ill, qu, gu…', items: unique(['ch','j','ge','gi','g(e)','g(i)','gu','qu','k','ph','th','gn','ill','tion','sion','ss','ç','c(e)','c(i)','c(y)','s(e)','s(i)','s(y)','x','ks','z']) },
    7: { title: 'Mélange', subtitle: 'Tout réviser', items: [] }
  };

  DATA[7].items = unique(Object.values(DATA).flatMap(x => x.items));

  const WORDS = {
    'ba':['bateau','ballon','banane'],'be':['bébé','beurre'],'bi':['biberon','biche'],'bo':['bol','botte'],'bu':['bus','bulletin'],
    'ca':['cadeau','cabane','canard'],'co':['coq','colis'],'cu':['cube','culotte'],'da':['dame','danse'],'de':['deux','dent'],
    'di':['dinosaure','dix'],'do':['domino','dodo'],'du':['dur','dune'],'fa':['famille','farine'],'fi':['fille','ficelle'],
    'fo':['forêt','fourmi'],'fu':['fumée','fusée'],'la':['lapin','lama'],'le':['lettre','léon'],'li':['livre','lit'],
    'lo':['loto','loup'],'lu':['lune','lumière'],'ma':['maman','maison'],'me':['melon','mer'],'mi':['mimi','miel'],
    'mo':['moto','mouton'],'mu':['musique','mur'],'na':['nager','navire'],'ne':['nez','neige'],'ni':['nid','niveau'],
    'no':['noël','note'],'nu':['nuage','nuit'],'pa':['papa','pantalon'],'pe':['petit','peinture'],'pi':['pied','pirate'],
    'po':['pomme','poisson'],'pu':['poule','pull'],'ra':['radio','rat'],'re':['renard','repas'],'ri':['riz','rivière'],
    'ro':['robot','rose'],'ru':['rue','ruban'],'sa':['sac','salade'],'se':['serpent','semaine'],'si':['singe','sifflet'],
    'so':['soleil','souris'],'su':['sucre','super'],'ta':['table','tasse'],'te':['téléphone','terre'],'ti':['tigre','tissu'],
    'to':['tomate','tortue'],'tu':['tulipe','tuyau'],'va':['vache','valise'],'ve':['vélo','vent'],'vi':['ville','vis'],
    'vo':['voiture','volcan'],'vu':['vue','vulgaire'],'ou':['ours','ouistiti'],'oi':['oiseau','poisson'],'ai':['aigle','aide'],
    'au':['auto','autruche'],'eau':['eau','bateau'],'eu':['feu','deux'],'ch':['chat','chapeau'],'gn':['montagne','agneau'],
    'ph':['photo','phare'],'qu':['quatre','queue'],'ill':['fille','quille'],'an':['ange','orange'],'on':['onze','bonbon'],
    'in':['lapin','matin'],'un':['un','parfum'],'ain':['pain','main'],'ein':['plein','peinture']
  };


  // Banque de mots illustrés : les emojis servent d'images locales, donc
  // l'application fonctionne sans Internet dans Termux.
  const PICTURE_WORDS = [
    ['chat','🐱','ch','images400/001.svg'],
    ['chien','🐶','ch','images400/002.svg'],
    ['moto','🏍️','mo','images400/003.svg'],
    ['vélo','🚲','vé','images400/004.svg'],
    ['banane','🍌','ba','images400/005.svg'],
    ['pomme','🍎','po','images400/006.svg'],
    ['poisson','🐟','po','images400/007.svg'],
    ['oiseau','🐦','oi','images400/008.svg'],
    ['lapin','🐰','la','images400/009.svg'],
    ['lion','🦁','li','images400/010.svg'],
    ['singe','🐵','si','images400/011.svg'],
    ['tigre','🐯','ti','images400/012.svg'],
    ['vache','🐄','va','images400/013.svg'],
    ['poule','🐔','po','images400/014.svg'],
    ['mouton','🐑','mo','images400/015.svg'],
    ['cheval','🐴','ch','images400/016.svg'],
    ['maison','🏠','ma','images400/017.svg'],
    ['école','🏫','éc','images400/018.svg'],
    ['livre','📖','li','images400/019.svg'],
    ['stylo','🖊️','st','images400/020.svg'],
    ['ballon','⚽','ba','images400/021.svg'],
    ['fleur','🌸','fl','images400/022.svg'],
    ['soleil','☀️','so','images400/023.svg'],
    ['lune','🌙','lu','images400/024.svg'],
    ['étoile','⭐','ét','images400/025.svg'],
    ['arbre','🌳','ar','images400/026.svg'],
    ['eau','💧','eau','images400/027.svg'],
    ['feu','🔥','fe','images400/028.svg'],
    ['maman','👩','ma','images400/029.svg'],
    ['papa','👨','pa','images400/030.svg'],
    ['bébé','👶','bé','images400/031.svg'],
    ['table','🪑','ta','images400/032.svg'],
    ['tomate','🍅','to','images400/033.svg'],
    ['orange','🍊','or','images400/034.svg'],
    ['carotte','🥕','ca','images400/035.svg'],
    ['gâteau','🍰','gâ','images400/036.svg'],
    ['pain','🍞','pa','images400/037.svg'],
    ['fromage','🧀','fr','images400/038.svg'],
    ['photo','📷','ph','images400/039.svg'],
    ['bouche','👄','bo','images400/040.svg'],
    ['œil','👁️','œi','images400/041.svg'],
    ['main','✋','ma','images400/042.svg'],
    ['pied','🦶','pi','images400/043.svg'],
    ['robe','👗','ro','images400/044.svg'],
    ['pantalon','👖','pa','images400/045.svg'],
    ['chaussure','👟','ch','images400/046.svg'],
    ['chapeau','🧢','ch','images400/047.svg'],
    ['chemise','👕','ch','images400/048.svg'],
    ['manteau','🧥','ma','images400/049.svg'],
    ['sac','🎒','sa','images400/050.svg'],
    ['parapluie','☂️','pa','images400/051.svg'],
    ['crayon','✏️','cr','images400/052.svg'],
    ['gomme','🧽','go','images400/053.svg'],
    ['règle','📏','rè','images400/054.svg'],
    ['cahier','📓','ca','images400/055.svg'],
    ['cartable','🎒','ca','images400/056.svg'],
    ['ordinateur','💻','or','images400/057.svg'],
    ['téléphone','📱','té','images400/058.svg'],
    ['horloge','🕐','ho','images400/059.svg'],
    ['lampe','💡','la','images400/060.svg'],
    ['lit','🛏️','li','images400/061.svg'],
    ['chaise','🪑','ch','images400/062.svg'],
    ['porte','🚪','po','images400/063.svg'],
    ['fenêtre','🪟','fe','images400/064.svg'],
    ['voiture','🚗','vo','images400/065.svg'],
    ['bus','🚌','bu','images400/066.svg'],
    ['train','🚆','tr','images400/067.svg'],
    ['avion','✈️','av','images400/068.svg'],
    ['bateau','⛵','ba','images400/069.svg'],
    ['fusée','🚀','fu','images400/070.svg'],
    ['véhicule','🚙','vé','images400/071.svg'],
    ['taxi','🚕','ta','images400/072.svg'],
    ['camion','🚚','ca','images400/073.svg'],
    ['canard','🦆','ca','images400/074.svg'],
    ['cochon','🐷','co','images400/075.svg'],
    ['chèvre','🐐','ch','images400/076.svg'],
    ['âne','🫏','ân','images400/077.svg'],
    ['ours','🐻','ou','images400/078.svg'],
    ['renard','🦊','re','images400/079.svg'],
    ['loup','🐺','lo','images400/080.svg'],
    ['grenouille','🐸','gr','images400/081.svg'],
    ['tortue','🐢','to','images400/082.svg'],
    ['serpent','🐍','se','images400/083.svg'],
    ['abeille','🐝','ab','images400/084.svg'],
    ['papillon','🦋','pa','images400/085.svg'],
    ['escargot','🐌','es','images400/086.svg'],
    ['coccinelle','🐞','co','images400/087.svg'],
    ['fraise','🍓','fr','images400/088.svg'],
    ['raisin','🍇','ra','images400/089.svg'],
    ['pastèque','🍉','pa','images400/090.svg'],
    ['ananas','🍍','an','images400/091.svg'],
    ['citron','🍋','ci','images400/092.svg'],
    ['pêche','🍑','pê','images400/093.svg'],
    ['poire','🍐','po','images400/094.svg'],
    ['cerise','🍒','ce','images400/095.svg'],
    ['melon','🍈','me','images400/096.svg'],
    ['maïs','🌽','ma','images400/097.svg'],
    ['abricot','✂️','ab','images400/098.svg'],
    ['amande','🖌️','am','images400/099.svg'],
    ['asperge','🎒','as','images400/100.svg'],
    ['avocat','💻','av','images400/101.svg'],
    ['ail','📱','ai','images400/102.svg'],
    ['artichaut','⌚','ar','images400/103.svg'],
    ['aubergine','⏰','au','images400/104.svg'],
    ['haricot','📷','ha','images400/105.svg'],
    ['brocoli','📺','br','images400/106.svg'],
    ['chou','🎧','ch','images400/107.svg'],
    ['concombre','🔑','co','images400/108.svg'],
    ['courgette','🔒','co','images400/109.svg'],
    ['épinard','🧸','ép','images400/110.svg'],
    ['oignon','🪀','oi','images400/111.svg'],
    ['radis','🧩','ra','images400/112.svg'],
    ['salade','🎲','sa','images400/113.svg'],
    ['poivron','🎈','po','images400/114.svg'],
    ['de','🪁','de','images400/115.svg'],
    ['terre','🍀','te','images400/116.svg'],
    ['framboise','🎸','fr','images400/117.svg'],
    ['mûre','🎹','mû','images400/118.svg'],
    ['myrtille','🎺','my','images400/119.svg'],
    ['noix','🎻','no','images400/120.svg'],
    ['noisette','🎤','no','images400/121.svg'],
    ['cacahuète','🛋️','ca','images400/122.svg'],
    ['mangue','🪑','ma','images400/123.svg'],
    ['kiwi','🛏️','ki','images400/124.svg'],
    ['papaye','🧑‍🏫','pa','images400/125.svg'],
    ['coco','🪟','co','images400/126.svg'],
    ['figue','🪞','fi','images400/127.svg'],
    ['datte','🧺','da','images400/128.svg'],
    ['prune','🧴','pr','images400/129.svg'],
    ['clémentine','🧼','cl','images400/130.svg'],
    ['mandarine','🪥','ma','images400/131.svg'],
    ['pamplemousse','🧹','pa','images400/132.svg'],
    ['groseille','🏖️','gr','images400/133.svg'],
    ['grenade','🔨','gr','images400/134.svg'],
    ['cerneau','🪛','ce','images400/135.svg'],
    ['soupe','🥒','so','images400/136.svg'],
    ['pizza','🌽','pi','images400/137.svg'],
    ['sandwich','📚','sa','images400/138.svg'],
    ['biscuit','🍅','bi','images400/139.svg'],
    ['chocolat','🍞','ch','images400/140.svg'],
    ['glace','🌈','gl','images400/141.svg'],
    ['yaourt','🧀','ya','images400/142.svg'],
    ['lait','🥚','la','images400/143.svg'],
    ['beurre','✂️','be','images400/144.svg'],
    ['crème','🖌️','cr','images400/145.svg'],
    ['miel','🍔','mi','images400/146.svg'],
    ['confiture','🍟','co','images400/147.svg'],
    ['œuf','🌭','œu','images400/148.svg'],
    ['omelette','⌚','om','images400/149.svg'],
    ['riz','🍫','ri','images400/150.svg'],
    ['pâtes','📷','pâ','images400/151.svg'],
    ['farine','🍭','fa','images400/152.svg'],
    ['sucre','🍯','su','images400/153.svg'],
    ['sel','🥛','se','images400/154.svg'],
    ['poivre','🍚','po','images400/155.svg'],
    ['huile','🍝','hu','images400/156.svg'],
    ['tarte','🥣','ta','images400/157.svg'],
    ['crêpe','🍪','cr','images400/158.svg'],
    ['bonbon','🎂','bo','images400/159.svg'],
    ['caramel','🎈','ca','images400/160.svg'],
    ['popcorn','🪁','po','images400/161.svg'],
    ['compote','🥁','co','images400/162.svg'],
    ['baguette','🍋','ba','images400/163.svg'],
    ['croissant','🍌','cr','images400/164.svg'],
    ['brioche','🍉','br','images400/165.svg'],
    ['jambon','🍇','ja','images400/166.svg'],
    ['saucisse','🍓','sa','images400/167.svg'],
    ['poulet','🍒','po','images400/168.svg'],
    ['viande','🍑','vi','images400/169.svg'],
    ['steak','🛏️','st','images400/170.svg'],
    ['zèbre','🚪','zè','images400/171.svg'],
    ['éléphant','🐍','él','images400/172.svg'],
    ['girafe','🐊','gi','images400/173.svg'],
    ['rhinocéros','🧠','rh','images400/174.svg'],
    ['hippopotame','🧴','hi','images400/175.svg'],
    ['crocodile','🦏','cr','images400/176.svg'],
    ['alligator','🪥','al','images400/177.svg'],
    ['dinosaure','🦶','di','images400/178.svg'],
    ['kangourou','🪣','ka','images400/179.svg'],
    ['koala','🐳','ko','images400/180.svg'],
    ['panda','🦈','pa','images400/181.svg'],
    ['gorille','🪚','go','images400/182.svg'],
    ['chimpanzé','🪜','ch','images400/183.svg'],
    ['veau','📚','ve','images400/184.svg'],
    ['agneau','📖','ag','images400/185.svg'],
    ['dinde','✏️','di','images400/186.svg'],
    ['coq','🐹','co','images400/187.svg'],
    ['canari','🐰','ca','images400/188.svg'],
    ['perroquet','🦊','pe','images400/189.svg'],
    ['hibou','🐻','hi','images400/190.svg'],
    ['aigle','🐼','ai','images400/191.svg'],
    ['faucon','🐨','fa','images400/192.svg'],
    ['colombe','💻','co','images400/193.svg'],
    ['cygne','📱','cy','images400/194.svg'],
    ['oie','⌚','oi','images400/195.svg'],
    ['pingouin','🐷','pi','images400/196.svg'],
    ['dauphin','🐸','da','images400/197.svg'],
    ['baleine','🐵','ba','images400/198.svg'],
    ['requin','🐔','re','images400/199.svg'],
    ['phoque','🔑','ph','images400/200.svg'],
    ['méduse','🔒','mé','images400/201.svg'],
    ['crabe','🦆','cr','images400/202.svg'],
    ['crevette','🦅','cr','images400/203.svg'],
    ['araignée','🦉','ar','images400/204.svg'],
    ['fourmi','🐺','fo','images400/205.svg'],
    ['moustique','🐗','mo','images400/206.svg'],
    ['mouche','🐴','mo','images400/207.svg'],
    ['guêpe','🦄','gu','images400/208.svg'],
    ['scarabée','🎸','sc','images400/209.svg'],
    ['chenille','🐛','ch','images400/210.svg'],
    ['ver','🎺','ve','images400/211.svg'],
    ['lézard','🐌','lé','images400/212.svg'],
    ['iguane','🎤','ig','images400/213.svg'],
    ['rose','⚡','ro','images400/214.svg'],
    ['tulipe','🌈','tu','images400/215.svg'],
    ['violette','☀️','vi','images400/216.svg'],
    ['marguerite','🌙','ma','images400/217.svg'],
    ['coquelicot','🐍','co','images400/218.svg'],
    ['tournesol','🌍','to','images400/219.svg'],
    ['lavande','🪨','la','images400/220.svg'],
    ['herbe','🐚','he','images400/221.svg'],
    ['feuille','🌳','fe','images400/222.svg'],
    ['branche','🌲','br','images400/223.svg'],
    ['racine','🌴','ra','images400/224.svg'],
    ['graine','🌵','gr','images400/225.svg'],
    ['fruit','🍔','fr','images400/226.svg'],
    ['forêt','🍀','fo','images400/227.svg'],
    ['montagne','🌸','mo','images400/228.svg'],
    ['rivière','🌹','ri','images400/229.svg'],
    ['lac','🌷','la','images400/230.svg'],
    ['mer','🌻','me','images400/231.svg'],
    ['plage','🌺','pl','images400/232.svg'],
    ['île','🌼','îl','images400/233.svg'],
    ['désert','🌱','dé','images400/234.svg'],
    ['volcan','🍃','vo','images400/235.svg'],
    ['nuage','🍂','nu','images400/236.svg'],
    ['pluie','🍁','pl','images400/237.svg'],
    ['neige','🌾','ne','images400/238.svg'],
    ['vent','🌵','ve','images400/239.svg'],
    ['éclair','🏔️','éc','images400/240.svg'],
    ['tonnerre','⛰️','to','images400/241.svg'],
    ['arc-en-ciel','🌋','ar','images400/242.svg'],
    ['ciel','🏝️','ci','images400/243.svg'],
    ['sable','🏖️','sa','images400/244.svg'],
    ['pierre','🌊','pi','images400/245.svg'],
    ['rocher','💧','ro','images400/246.svg'],
    ['coquillage','🐦','co','images400/247.svg'],
    ['nez','🦶','ne','images400/248.svg'],
    ['oreille','✋','or','images400/249.svg'],
    ['doigt','☝️','do','images400/250.svg'],
    ['bras','💅','br','images400/251.svg'],
    ['jambe','👀','ja','images400/252.svg'],
    ['tête','👂','tê','images400/253.svg'],
    ['cheveux','👃','ch','images400/254.svg'],
    ['visage','👄','vi','images400/255.svg'],
    ['dent','🦷','de','images400/256.svg'],
    ['langue','👅','la','images400/257.svg'],
    ['cœur','🧠','cœ','images400/258.svg'],
    ['ventre','🌳','ve','images400/259.svg'],
    ['dos','💪','do','images400/260.svg'],
    ['épaule','🦵','ép','images400/261.svg'],
    ['genou','🦶','ge','images400/262.svg'],
    ['coude','✋','co','images400/263.svg'],
    ['poignet','☝️','po','images400/264.svg'],
    ['cheville','💅','ch','images400/265.svg'],
    ['ongle','👀','on','images400/266.svg'],
    ['peau','👂','pe','images400/267.svg'],
    ['poupée','🧼','po','images400/268.svg'],
    ['robot','🪥','ro','images400/269.svg'],
    ['puzzle','🧹','pu','images400/270.svg'],
    ['jouet','🪣','jo','images400/271.svg'],
    ['jeu','🔨','je','images400/272.svg'],
    ['cerf-volant','🪛','ce','images400/273.svg'],
    ['trottinette','🪚','tr','images400/274.svg'],
    ['patin','🪜','pa','images400/275.svg'],
    ['skateboard','📚','sk','images400/276.svg'],
    ['corde','📖','co','images400/277.svg'],
    ['tambour','✏️','ta','images400/278.svg'],
    ['guitare','🖊️','gu','images400/279.svg'],
    ['piano','🖍️','pi','images400/280.svg'],
    ['flûte','📏','fl','images400/281.svg'],
    ['trompette','✂️','tr','images400/282.svg'],
    ['violon','🖌️','vi','images400/283.svg'],
    ['micro','🎒','mi','images400/284.svg'],
    ['appareil','💻','ap','images400/285.svg'],
    ['caméra','📱','ca','images400/286.svg'],
    ['radio','⌚','ra','images400/287.svg'],
    ['télévision','⏰','té','images400/288.svg'],
    ['casque','📷','ca','images400/289.svg'],
    ['montre','📺','mo','images400/290.svg'],
    ['réveil','🎧','ré','images400/291.svg'],
    ['canapé','🔑','ca','images400/292.svg'],
    ['fauteuil','🔒','fa','images400/293.svg'],
    ['armoire','🧸','ar','images400/294.svg'],
    ['miroir','🧑‍🏫','mi','images400/295.svg'],
    ['tapis','🧩','ta','images400/296.svg'],
    ['rideau','🎲','ri','images400/297.svg'],
    ['coussin','🎈','co','images400/298.svg'],
    ['couverture','🪁','co','images400/299.svg'],
    ['oreiller','🧠','or','images400/300.svg'],
    ['drap','🎸','dr','images400/301.svg'],
    ['assiette','🎹','as','images400/302.svg'],
    ['verre','🎺','ve','images400/303.svg'],
    ['tasse','🎻','ta','images400/304.svg'],
    ['cuillère','🎤','cu','images400/305.svg'],
    ['fourchette','🛋️','fo','images400/306.svg'],
    ['couteau','🪑','co','images400/307.svg'],
    ['casserole','🛏️','ca','images400/308.svg'],
    ['poêle','🚪','po','images400/309.svg'],
    ['frigo','🪟','fr','images400/310.svg'],
    ['four','🪞','fo','images400/311.svg'],
    ['évier','🧺','év','images400/312.svg'],
    ['robinet','🧴','ro','images400/313.svg'],
    ['savon','🧼','sa','images400/314.svg'],
    ['serviette','🪥','se','images400/315.svg'],
    ['brosse','💪','br','images400/316.svg'],
    ['peigne','🪣','pe','images400/317.svg'],
    ['aspirateur','🧑‍🎤','as','images400/318.svg'],
    ['balai','🪛','ba','images400/319.svg'],
    ['seau','🪚','se','images400/320.svg'],
    ['panier','🪜','pa','images400/321.svg'],
    ['boîte','📚','bo','images400/322.svg'],
    ['bouteille','📖','bo','images400/323.svg'],
    ['bouchon','✏️','bo','images400/324.svg'],
    ['clé','🖊️','cl','images400/325.svg'],
    ['cadenas','🖍️','ca','images400/326.svg'],
    ['église','📚','ég','images400/327.svg'],
    ['château','🎭','ch','images400/328.svg'],
    ['bibliothèque','🖌️','bi','images400/329.svg'],
    ['hôpital','🏨','hô','images400/330.svg'],
    ['magasin','🍽️','ma','images400/331.svg'],
    ['marché','🚉','ma','images400/332.svg'],
    ['ferme','✈️','fe','images400/333.svg'],
    ['jardin','⏰','ja','images400/334.svg'],
    ['garage','🏭','ga','images400/335.svg'],
    ['bureau','🏠','bu','images400/336.svg'],
    ['usine','🏡','us','images400/337.svg'],
    ['gare','🌳','ga','images400/338.svg'],
    ['aéroport','🏟️','aé','images400/339.svg'],
    ['port','🏫','po','images400/340.svg'],
    ['rue','🪀','ru','images400/341.svg'],
    ['route','🏪','ro','images400/342.svg'],
    ['pont','🏦','po','images400/343.svg'],
    ['tunnel','📮','tu','images400/344.svg'],
    ['parc','🏰','pa','images400/345.svg'],
    ['stade','⛪','st','images400/346.svg'],
    ['cinéma','📚','ci','images400/347.svg'],
    ['théâtre','🎭','th','images400/348.svg'],
    ['musée','🎬','mu','images400/349.svg'],
    ['restaurant','🏨','re','images400/350.svg'],
    ['hôtel','🍽️','hô','images400/351.svg'],
    ['boulangerie','🚉','bo','images400/352.svg'],
    ['pharmacie','✈️','ph','images400/353.svg'],
    ['banque','⚓','ba','images400/354.svg'],
    ['poste','🏭','po','images400/355.svg'],
    ['pompier','🏴‍☠️','po','images400/356.svg'],
    ['docteur','👩','do','images400/357.svg'],
    ['infirmier','👨','in','images400/358.svg'],
    ['pilote','👧','pi','images400/359.svg'],
    ['conducteur','👦','co','images400/360.svg'],
    ['professeur','👶','pr','images400/361.svg'],
    ['élève','🧑‍⚕️','él','images400/362.svg'],
    ['enfant','🧑‍🏫','en','images400/363.svg'],
    ['garçon','🧑‍🍳','ga','images400/364.svg'],
    ['fille','🧑‍🌾','fi','images400/365.svg'],
    ['ami','🧑‍🚒','am','images400/366.svg'],
    ['reine','🧑‍✈️','re','images400/367.svg'],
    ['roi','🧑‍🎨','ro','images400/368.svg'],
    ['prince','🧑‍🎤','pr','images400/369.svg'],
    ['princesse','🧑‍🚀','pr','images400/370.svg'],
    ['pirate','👑','pi','images400/371.svg'],
    ['astronaute','🧙','as','images400/372.svg'],
    ['cuisinier','🏴‍☠️','cu','images400/373.svg'],
    ['fermier','👩','fe','images400/374.svg'],
    ['facteur','👨','fa','images400/375.svg'],
    ['policier','👧','po','images400/376.svg'],
    ['artiste','👦','ar','images400/377.svg'],
    ['chanteur','👶','ch','images400/378.svg'],
    ['danseur','🧑‍⚕️','da','images400/379.svg'],
    ['joueur','🧑‍🏫','jo','images400/380.svg'],
    ['camionnette','🧑‍🍳','ca','images400/381.svg'],
    ['ambulance','📺','am','images400/382.svg'],
    ['tracteur','🛶','tr','images400/383.svg'],
    ['scooter','🚗','sc','images400/384.svg'],
    ['métro','🚕','mé','images400/385.svg'],
    ['tramway','🚌','tr','images400/386.svg'],
    ['navire','🚎','na','images400/387.svg'],
    ['voilier','🚓','vo','images400/388.svg'],
    ['hélicoptère','🚑','hé','images400/389.svg'],
    ['locomotive','🚒','lo','images400/390.svg'],
    ['wagon','🚚','wa','images400/391.svg'],
    ['remorque','🚛','re','images400/392.svg'],
    ['cargo','🎸','ca','images400/393.svg'],
    ['jupe','🩳','ju','images400/394.svg'],
    ['pull','🥻','pu','images400/395.svg'],
    ['chemisier','🎻','ch','images400/396.svg'],
    ['veste','👚','ve','images400/397.svg'],
    ['bonnet','👔','bo','images400/398.svg'],
    ['casquette','👗','ca','images400/399.svg'],
    ['écharpe','👖','éc','images400/400.svg']
  ].map(([word, emoji, syllable, image]) => ({word, emoji, syllable, image}));

  const WORDS_PER_LEVEL = {
    1: PICTURE_WORDS.slice(0, 50),
    2: PICTURE_WORDS.slice(50, 110),
    3: PICTURE_WORDS.slice(110, 180),
    4: PICTURE_WORDS.slice(180, 250),
    5: PICTURE_WORDS.slice(250, 320),
    6: PICTURE_WORDS.slice(0, 400),
    7: PICTURE_WORDS.slice(0, 400)
  };

  // Comptes utilisateurs : chaque nom possède sa propre progression sur l'appareil.
  const USERS_KEY = 'syllabe_users_v1';
  const ACTIVE_USER_KEY = 'syllabe_active_user_v1';
  const LEGACY_KEYS = ['syllabes_score','syllabes_completed','syllabe_level_correct','syllabe_word_correct','syllabe_unlocked_level'];
  const DEFAULT_PROFILE = () => ({ score: 0, completed: {}, levelCorrect: {}, wordCorrect: {}, unlockedLevel: 1 });
  let users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
  let activeUser = localStorage.getItem(ACTIVE_USER_KEY) || '';

  function cleanName(name) { return String(name || '').trim().replace(/\s+/g, ' ').slice(0, 30); }
  function slugName(name) { return cleanName(name).toLocaleLowerCase(); }
  function saveUsers() { localStorage.setItem(USERS_KEY, JSON.stringify(users)); }
  function profileFor(name) {
    const key = slugName(name);
    if (!users[key]) users[key] = { name: cleanName(name), ...DEFAULT_PROFILE() };
    users[key].name = cleanName(name);
    users[key].completed = users[key].completed || {};
    users[key].levelCorrect = users[key].levelCorrect || {};
    users[key].wordCorrect = users[key].wordCorrect || {};
    users[key].score = Number(users[key].score || 0);
    users[key].unlockedLevel = Math.min(7, Math.max(1, Number(users[key].unlockedLevel || 1)));
    return users[key];
  }

  // Migration transparente de la progression V3.2 vers le premier compte.
  if (!Object.keys(users).length) {
    const legacyScore = Number(localStorage.getItem('syllabes_score') || 0);
    const legacyCompleted = JSON.parse(localStorage.getItem('syllabes_completed') || '{}');
    const legacyLevelCorrect = JSON.parse(localStorage.getItem('syllabe_level_correct') || '{}');
    const legacyWordCorrect = JSON.parse(localStorage.getItem('syllabe_word_correct') || '{}');
    const legacyUnlocked = Math.min(7, Math.max(1, Number(localStorage.getItem('syllabe_unlocked_level') || 1)));
    if (legacyScore || Object.keys(legacyCompleted).length || Object.keys(legacyLevelCorrect).length || Object.keys(legacyWordCorrect).length || legacyUnlocked > 1) {
      const migrated = profileFor('Utilisateur');
      Object.assign(migrated, { score: legacyScore, completed: legacyCompleted, levelCorrect: legacyLevelCorrect, wordCorrect: legacyWordCorrect, unlockedLevel: legacyUnlocked });
      activeUser = slugName('Utilisateur');
      saveUsers();
    }
  }

  let profile = activeUser && users[activeUser] ? profileFor(users[activeUser].name) : null;
  if (profile) activeUser = slugName(profile.name);

  let wordQuizAnswered = false;
  let wordAnswer = null;
  let wordQuestionIndex = 0;

  function updateWordCounter() {
    const lvl = Number(levelEl.value);
    const correct = Math.min(QUESTIONS_TO_UNLOCK, Number(wordCorrect[lvl] || 0));
    wordCounter.textContent = `${correct} / ${QUESTIONS_TO_UNLOCK}`;
    wordProgress.style.width = Math.round(correct / QUESTIONS_TO_UNLOCK * 100) + '%';
  }

  function showWordQuiz() {
    wordQuiz.classList.remove('hidden');
    newWordQuiz();
  }

  function newWordQuiz() {
    wordQuizAnswered = false;
    const lvl = Number(levelEl.value);
    const pool = WORDS_PER_LEVEL[lvl] && WORDS_PER_LEVEL[lvl].length ? WORDS_PER_LEVEL[lvl] : PICTURE_WORDS;
    wordAnswer = nextFromDeck(wordDecks, String(lvl), pool, x => x.word);
    wordAnswer._questionIndex = wordQuestionIndex++;
    if (wordQuestionIndex > 3999) wordQuestionIndex = 0;
    const choices = new Set([wordAnswer.word]);
    while (choices.size < Math.min(4, pool.length)) choices.add(pool[Math.floor(Math.random() * pool.length)].word);
    const arr = [...choices].sort(() => Math.random() - 0.5);
    wordImage.innerHTML = '';
    const img = document.createElement('img'); img.src = wordAnswer.image; img.alt = 'Image pédagogique'; img.loading = 'eager';
    wordImage.appendChild(img);
    const modes = [
      () => 'Quel est le mot ?',
      () => 'Choisis le mot qui correspond à cette image.',
      () => 'Quel mot vois-tu sur cette image ?',
      () => 'Quel est le nom de cet élément ?',
      () => `Quelle réponse correspond à l’image ?`
    ];
    const qKey = (wordAnswer._questionIndex || 0) % modes.length;
    wordQuestion.textContent = modes[qKey]();
    wordResult.textContent = '';
    wordChoices.innerHTML = '';
    arr.forEach(word => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'wordChoice'; b.textContent = word;
      b.addEventListener('click', () => answerWord(word, b));
      wordChoices.appendChild(b);
    });
  }

  function answerWord(word, button) {
    if (wordQuizAnswered) return;
    if (word === wordAnswer.word) {
      wordQuizAnswered = true;
      const lvl = Number(levelEl.value);
      wordCorrect[lvl] = Math.min(QUESTIONS_TO_UNLOCK, Number(wordCorrect[lvl] || 0) + 1);
      saveProfile();
      addScore(10);
      wordResult.textContent = '🌟 Bravo ! Bonne réponse.';
      button.classList.add('correct');
      wordText.textContent = wordAnswer.word;
      wordHint.textContent = `Mot avec « ${wordAnswer.syllable} »`;
      wordCard.classList.remove('hidden');
      current.textContent = wordAnswer.word;
      speak(wordAnswer.word, {silent:true});
      [...wordChoices.querySelectorAll('button')].forEach(x => x.disabled = true);
      updateWordCounter();
    } else {
      button.classList.add('wrong');
      wordResult.textContent = '💡 Essaie encore !';
      speak(wordAnswer.word, {silent:true});
    }
  }

  const levelEl = document.getElementById('level');
  const rateEl = document.getElementById('rate');
  const grid = document.getElementById('grid');
  const current = document.getElementById('current');
  const message = document.getElementById('message');
  const selectedList = document.getElementById('selectedList');
  const count = document.getElementById('count');
  const levelTitle = document.getElementById('levelTitle');
  const levelSubtitle = document.getElementById('levelSubtitle');
  const progress = document.getElementById('progress');
  const progressText = document.getElementById('progressText');
  const scoreEls = [document.getElementById('homeScore'), document.getElementById('progressScore')].filter(Boolean);
  function setScoreDisplay(value) { scoreEls.forEach(el => { el.textContent = value; }); }
  const quiz = document.getElementById('quiz');
  const quizQuestion = document.getElementById('quizQuestion');
  const quizChoices = document.getElementById('quizChoices');
  const quizResult = document.getElementById('quizResult');
  const quizCounter = document.getElementById('quizCounter');
  const quizProgress = document.getElementById('quizProgress');
  const wordCard = document.getElementById('wordCard');
  const wordText = document.getElementById('wordText');
  const wordHint = document.getElementById('wordHint');
  const wordQuiz = document.getElementById('wordQuiz');
  const wordImage = document.getElementById('wordImage');
  const wordQuestion = document.getElementById('wordQuestion');
  const wordChoices = document.getElementById('wordChoices');
  const wordResult = document.getElementById('wordResult');
  const wordCounter = document.getElementById('wordCounter');
  const wordProgress = document.getElementById('wordProgress');

  let selected = [];
  let lastText = '';
  let quizAnswer = '';
  let score = profile ? profile.score : 0;
  let completed = profile ? profile.completed : {};
  let levelCorrect = profile ? profile.levelCorrect : {};
  let wordCorrect = profile ? profile.wordCorrect : {};
  let unlockedLevel = profile ? profile.unlockedLevel : 1;
  let quizAnswered = false;

  const QUESTIONS_TO_UNLOCK = 200;

  function saveProfile() {
    if (!profile) return;
    profile.name = cleanName(profile.name);
    profile.score = score;
    profile.completed = completed;
    profile.levelCorrect = levelCorrect;
    profile.wordCorrect = wordCorrect;
    profile.unlockedLevel = unlockedLevel;
    users[activeUser] = profile;
    saveUsers();
    localStorage.setItem(ACTIVE_USER_KEY, activeUser);
  }

  function refreshUserUI() {
    const name = profile ? profile.name : 'Utilisateur';
    const wb = document.querySelector('#userBadge span');
    const wu = document.getElementById('welcomeUser');
    if (wb) wb.textContent = name;
    if (wu) wu.textContent = name;
  }

  function openUserModal() {
    const modal = document.getElementById('userModal');
    const input = document.getElementById('userNameInput');
    if (!modal) return;
    renderUserList();
    input.value = '';
    modal.classList.remove('hidden');
    setTimeout(() => input.focus(), 50);
  }

  function closeUserModal() { document.getElementById('userModal')?.classList.add('hidden'); }

  function renderUserList() {
    const list = document.getElementById('userList');
    if (!list) return;
    list.innerHTML = '';
    Object.entries(users).sort((a,b) => a[1].name.localeCompare(b[1].name, 'fr')).forEach(([key, u]) => {
      const row = document.createElement('div');
      row.className = 'userItem' + (key === activeUser ? ' active' : '');
      const label = document.createElement('strong'); label.textContent = '👤 ' + u.name;
      const btn = document.createElement('button'); btn.type = 'button'; btn.textContent = key === activeUser ? 'Actif' : 'Utiliser'; btn.disabled = key === activeUser;
      btn.addEventListener('click', () => switchUser(key));
      row.append(label, btn); list.appendChild(row);
    });
  }

  function switchUser(key) {
    if (!users[key]) return;
    saveProfile();
    activeUser = key;
    profile = profileFor(users[key].name);
    score = profile.score; completed = profile.completed; levelCorrect = profile.levelCorrect; wordCorrect = profile.wordCorrect; unlockedLevel = profile.unlockedLevel;
    selected = []; quizAnswered = false; wordQuizAnswered = false;
    localStorage.setItem(ACTIVE_USER_KEY, activeUser);
    setScoreDisplay(score); updateLevelLocks(); levelEl.value = String(Math.min(unlockedLevel, 7)); render(); updateWordCounter(); updateHomeStats(); refreshUserUI();
    closeUserModal();
  }

  function createUserFromInput() {
    const input = document.getElementById('userNameInput');
    const name = cleanName(input?.value);
    if (!name) { input?.focus(); return; }
    const key = slugName(name);
    if (!users[key]) users[key] = { name, ...DEFAULT_PROFILE() };
    switchUser(key);
  }

  setScoreDisplay(score);
  refreshUserUI();

  function unique(arr) { return [...new Set(arr)]; }
  function cv(cs, vs) { return cs.flatMap(c => vs.map(v => c + v)); }

  // === MOTEUR DE LECTURE VOCALE ROBUSTE ===
  // SpeechSynthesis sur Android/WebView peut charger les voix de façon asynchrone
  // et bloquer une lecture lancée automatiquement. On prépare les voix, on annule
  // la file précédente et on expose une lecture fiable déclenchée par l'enfant.
  let voices = [];
  let voiceReady = false;
  let speechToken = 0;
  const VOICE_CONSENT_KEY = 'syllabe_voice_consent_v1';

  function hasVoiceEngine() {
    return ('speechSynthesis' in window) && typeof SpeechSynthesisUtterance !== 'undefined';
  }

  function showVoiceModal() {
    const modal = document.getElementById('voiceModal');
    if (modal) modal.classList.remove('hidden');
  }

  function closeVoiceModal() {
    const modal = document.getElementById('voiceModal');
    if (modal) modal.classList.add('hidden');
  }

  function setVoiceStatus(text) {
    const el = document.getElementById('voiceStatus');
    if (el) el.textContent = text;
  }

  function loadVoices() {
    if (!('speechSynthesis' in window)) return false;
    const list = window.speechSynthesis.getVoices() || [];
    if (list.length) { voices = list; voiceReady = true; }
    return voiceReady;
  }

  function waitForVoices(timeout = 1200) {
    if (!('speechSynthesis' in window)) return Promise.resolve(false);
    if (loadVoices()) return Promise.resolve(true);
    return new Promise(resolve => {
      let done = false;
      const finish = ok => { if (!done) { done = true; resolve(ok); } };
      const handler = () => { loadVoices(); finish(voiceReady); };
      window.speechSynthesis.addEventListener('voiceschanged', handler, { once: true });
      setTimeout(() => { loadVoices(); finish(voiceReady); }, timeout);
    });
  }

  function chooseVoice() {
    const french = voices.filter(v => /^fr(?:-|_)/i.test(v.lang || ''));
    return french.find(v => /fr[-_]?FR/i.test(v.lang || '') && /Google|Microsoft|Samsung|French|français/i.test(v.name || ''))
      || french.find(v => /fr[-_]?FR/i.test(v.lang || ''))
      || french.find(v => /Google|Microsoft|Samsung|French|français/i.test(v.name || ''))
      || french[0]
      || null;
  }

  // Les graphies isolées doivent être prononcées comme des consignes françaises,
  // pas comme des mots anglais ou comme les noms de lettres anglaises.
  const PRONUNCIATION_GUIDE = {
    'a':'a', 'e':'e', 'é':'é', 'è':'è', 'ê':'ê', 'ë':'e tréma',
    'i':'i', 'î':'i accent circonflexe', 'ï':'i tréma',
    'o':'o', 'ô':'o accent circonflexe', 'u':'u', 'û':'u accent circonflexe',
    'ü':'u tréma', 'y':'i grec', 'ÿ':'i grec tréma',
    'ä':'a tréma', 'ö':'o tréma', 'æ':'a e', 'œ':'eu',
    'ou':'ou', 'oi':'oi', 'ai':'ai', 'ei':'è', 'au':'au', 'eau':'eau', 'eu':'eu', 'œu':'eu', 'ui':'ui',
    'oin':'oin', 'ion':'ion', 'ien':'ien', 'an':'an', 'am':'am', 'en':'en', 'em':'em',
    'on':'on', 'om':'om', 'in':'in', 'im':'im', 'yn':'in', 'ym':'in', 'un':'un', 'um':'un',
    'ain':'in', 'ein':'in', 'aim':'in', 'eim':'in',
    'ny':'gn, comme dans agneau', 'gn':'gn, comme dans agneau',
    'ill':'ill, comme dans fille', 'ph':'f, comme dans photo', 'th':'t, comme dans théâtre',
    'qu':'k, comme dans quatre', 'gu':'g dur, comme dans guitare', 'ch':'ch, comme dans chat',
    'ç':'cédille', 'c(e)':'s, comme dans ceci', 'c(i)':'s, comme dans cinéma', 'c(y)':'s, comme dans cycle',
    's(e)':'s, comme dans semaine', 's(i)':'s, comme dans si', 's(y)':'s, comme dans symbole',
    'ks':'ks, comme dans taxi', 'x':'iks', 'z':'zède', 'tion':'sion, comme dans attention', 'sion':'sion, comme dans vision'
  };

  function speechText(text) {
    const raw = String(text ?? '').trim();
    if (!raw) return '';
    const key = raw.toLocaleLowerCase('fr-FR');
    return PRONUNCIATION_GUIDE[key] || raw;
  }

  async function speak(text, options = {}) {
    const raw = String(text ?? '').trim();
    if (!raw) return false;
    if (!hasVoiceEngine()) {
      message.textContent = '🔇 Lecture vocale indisponible. Active un moteur de synthèse vocale français dans Android.';
      return false;
    }

    const token = ++speechToken;
    const synth = window.speechSynthesis;
    try { synth.cancel(); synth.resume(); } catch (_) {}

    // IMPORTANT Android/WebView : ne pas attendre getVoices() avant speak().
    // Une attente asynchrone peut faire perdre le geste utilisateur et bloquer l'audio.
    loadVoices();
    const u = new SpeechSynthesisUtterance(speechText(raw));
    u.lang = 'fr-FR';
    const selectedRate = options.rate ?? Number(rateEl.value);
    u.rate = Math.max(0.55, Math.min(1.0, Number.isFinite(selectedRate) ? selectedRate : 0.78));
    u.pitch = options.pitch ?? 1;
    u.volume = 1;
    const voice = chooseVoice();
    if (voice) u.voice = voice;

    lastText = raw;
    if (!options.silent) message.textContent = '🔊 Écoute : ' + raw;

    return new Promise(resolve => {
      let settled = false;
      let retry = 0;
      const finish = ok => { if (!settled) { settled = true; resolve(ok); } };
      u.onend = () => {
        if (token === speechToken && !options.silent) message.textContent = 'Bravo, tu peux répéter !';
        finish(true);
      };
      u.onerror = () => {
        if (retry++ < 1 && token === speechToken) {
          setTimeout(() => {
            try { synth.cancel(); synth.resume(); synth.speak(u); } catch (_) { finish(false); }
          }, 180);
        } else finish(false);
      };

      try {
        synth.resume();
        synth.speak(u);
      } catch (_) {
        finish(false);
        return;
      }

      // Certains WebView Android mettent la file en pause.
      setTimeout(() => {
        if (!settled && token === speechToken && !synth.speaking) {
          try { synth.resume(); synth.speak(u); } catch (_) { finish(false); }
        }
      }, 350);
      setTimeout(() => finish(false), 6000);
    });
  }


  function stopSpeech() {
    speechToken++;
    if ('speechSynthesis' in window) {
      try { speechSynthesis.cancel(); speechSynthesis.resume(); } catch (_) {}
    }
  }

  async function enableVoiceFromUserGesture() {
    if (!hasVoiceEngine()) {
      setVoiceStatus('❌ Cette WebView ne fournit pas la synthèse vocale. Dans l’APK, utilise une WebView Android avec Text-to-Speech.');
      return false;
    }

    setVoiceStatus('⏳ Activation de la voix française…');
    const ok = await speak('Bonjour', { rate: 0.72, silent: true });
    if (ok) {
      voiceReady = true;
      localStorage.setItem(VOICE_CONSENT_KEY, 'yes');
      setVoiceStatus('✅ Voix activée. Tu peux maintenant écouter les syllabes et les mots.');
      closeVoiceModal();
      return true;
    }

    loadVoices();
    setVoiceStatus(voices.length
      ? '⚠️ Une voix est détectée mais Android n’a pas démarré la lecture. Vérifie le volume multimédia et le moteur de synthèse vocale.'
      : '⚠️ Aucune voix n’est détectée. Active/installe un moteur de synthèse vocale français dans Android.');
    return false;
  }

  document.getElementById('enableVoiceBtn')?.addEventListener('click', enableVoiceFromUserGesture);
  document.getElementById('skipVoiceBtn')?.addEventListener('click', () => {
    localStorage.setItem(VOICE_CONSENT_KEY, 'no');
    closeVoiceModal();
  });

  loadVoices();
  if ('speechSynthesis' in window) {
    speechSynthesis.onvoiceschanged = () => { loadVoices(); };
  }

  function markCompleted(s) {
    completed[s] = true;
    saveProfile();
    updateProgress();
  }

  function updateQuizCounter() {
    const lvl = Number(levelEl.value);
    const correct = Math.min(QUESTIONS_TO_UNLOCK, Number(levelCorrect[lvl] || 0));
    quizCounter.textContent = `${correct} / ${QUESTIONS_TO_UNLOCK}`;
    quizProgress.style.width = Math.round(correct / QUESTIONS_TO_UNLOCK * 100) + '%';
  }

  function updateProgress() {
    const lvl = Number(levelEl.value);
    const correct = Math.min(QUESTIONS_TO_UNLOCK, Number(levelCorrect[lvl] || 0));
    const pct = Math.round(correct / QUESTIONS_TO_UNLOCK * 100);
    progress.style.width = pct + '%';
    progressText.textContent = `${correct}/${QUESTIONS_TO_UNLOCK} bonnes réponses`;
    if (lvl < 7 && correct >= QUESTIONS_TO_UNLOCK) {
      progressText.textContent = `Niveau terminé ! ${QUESTIONS_TO_UNLOCK}/${QUESTIONS_TO_UNLOCK}`;
    }
    updateQuizCounter();
  }

  function updateLevelLocks() {
    [...levelEl.options].forEach(opt => {
      const n = Number(opt.value);
      opt.disabled = n > unlockedLevel;
      opt.textContent = opt.textContent.replace(/ 🔒| 🔓/g, '') + (n > unlockedLevel ? ' 🔒' : '');
    });
    if (Number(levelEl.value) > unlockedLevel) levelEl.value = String(unlockedLevel);
  }

  function registerCorrectAnswer() {
    const lvl = Number(levelEl.value);
    levelCorrect[lvl] = Number(levelCorrect[lvl] || 0) + 1;
    saveProfile();
    if (levelCorrect[lvl] >= QUESTIONS_TO_UNLOCK && lvl < 7 && unlockedLevel === lvl) {
      unlockedLevel = lvl + 1;
      saveProfile();
      updateLevelLocks();
      message.textContent = `🎉 Niveau ${lvl} terminé ! Le niveau ${unlockedLevel} est débloqué !`;
    }
    updateProgress();
    updateHomeStats();
  }

  window.SyllabeGo = function(name) {
    const target = document.getElementById('page-' + name);
    if (!target) return;
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    target.classList.add('active');
    document.querySelectorAll('.navBtn').forEach(b => b.classList.toggle('active', b.dataset.page === name));
    updateHomeStats();
    window.scrollTo(0, 0);
  };

  function showPage(name) { window.SyllabeGo(name); }

  function updateHomeStats() {
    const hs=document.getElementById('homeScore'), hl=document.getElementById('homeLevel'), hc=document.getElementById('homeCorrect'), hsy=document.getElementById('homeSyllables');
    if(hs) hs.textContent=score;
    if(hl) hl.textContent=unlockedLevel;
    if(hc) hc.textContent=Object.values(levelCorrect).reduce((a,b)=>a+Number(b||0),0);
    if(hsy) hsy.textContent=Object.values(completed).filter(Boolean).length;
    const ps=document.getElementById('progressScore'), pl=document.getElementById('progressLevel');
    if(ps) ps.textContent=score; if(pl) pl.textContent=unlockedLevel;
  }

  document.querySelectorAll('.navBtn').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
  document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.go)));
  updateLevelLocks();

  function render() {
    const level = DATA[levelEl.value];
    levelTitle.textContent = level.title;
    levelSubtitle.textContent = level.subtitle;
    grid.innerHTML = '';
    unique(level.items).forEach(s => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'syllable' + (selected.includes(s) ? ' selected' : '') + (completed[s] ? ' learned' : '');
      b.textContent = s;
      b.setAttribute('aria-label', 'Écouter ' + s);
      b.addEventListener('click', () => {
        current.textContent = s;
        markCompleted(s);
        speak(s);
        toggleSelected(s, b);
        showWord(s);
      });
      grid.appendChild(b);
    });
    renderSelection();
    updateProgress();
  }

  function toggleSelected(s, b) {
    const i = selected.indexOf(s);
    if (i === -1) { selected.push(s); b.classList.add('selected'); }
    else { selected.splice(i, 1); b.classList.remove('selected'); }
    renderSelection();
  }

  function renderSelection() {
    count.textContent = selected.length;
    selectedList.innerHTML = '';
    if (!selected.length) { selectedList.textContent = 'Aucune syllabe sélectionnée.'; return; }
    selected.forEach(s => {
      const span = document.createElement('button');
      span.type = 'button'; span.className = 'chip'; span.textContent = s;
      span.title = 'Retirer ' + s;
      span.addEventListener('click', () => { selected = selected.filter(x => x !== s); render(); });
      selectedList.appendChild(span);
    });
  }

  function showWord(s) {
    const words = WORDS[s];
    if (!words) { wordCard.classList.add('hidden'); return; }
    const word = words[Math.floor(Math.random() * words.length)];
    wordText.textContent = word;
    wordHint.textContent = `Le son « ${s} » se trouve dans ce mot.`;
    wordCard.classList.remove('hidden');
  }

  async function playSelected() {
    if (!selected.length) { message.textContent = 'Choisis une ou plusieurs syllabes.'; return; }
    stopSpeech();
    message.textContent = '🔊 Lecture de la sélection…';
    for (const s of selected) {
      current.textContent = s; showWord(s);
      const ok = await speak(s, { silent: true });
      if (!ok) break;
      await new Promise(r => setTimeout(r, 180));
    }
    message.textContent = '🎉 Lecture terminée !';
  }

  function addScore(points) {
    score += points; setScoreDisplay(score); saveProfile(); updateHomeStats();
  }

  // === FILES SANS REPETITION ===
  // Chaque niveau parcourt tous ses éléments une fois avant de recommencer.
  const quizDecks = Object.create(null);
  const wordDecks = Object.create(null);

  function shuffledCopy(items) {
    const a = items.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function nextFromDeck(store, key, items, idFn = x => x) {
    const ids = new Set(items.map(idFn));
    let deck = store[key];
    if (!deck || !deck.length || deck.some(x => !ids.has(idFn(x)))) {
      deck = shuffledCopy(items);
    }
    const item = deck.shift();
    store[key] = deck;
    return item;
  }

  function newQuiz() {
    quizAnswered = false;
    const uniqueItems = unique(DATA[levelEl.value].items);
    if (!uniqueItems.length) return;
    const variants = ['Écoute puis trouve la syllabe', 'Quelle syllabe entends-tu ?', 'Choisis le son entendu', 'Quelle écriture correspond au son ?', 'Quel est le bon début de mot ?'];
    const questionPool = [];
    for (const syllable of uniqueItems) variants.forEach((variant, vi) => questionPool.push({syllable, variant, vi}));
    const key = String(levelEl.value);
    if (!quizDecks[key] || !quizDecks[key].length) quizDecks[key] = shuffledCopy(questionPool);
    const q = quizDecks[key].shift();
    quizAnswer = q.syllable;
    quizQuestion.textContent = '👂 ' + q.variant;
    const choices = new Set([quizAnswer]);
    while (choices.size < Math.min(4, uniqueItems.length)) choices.add(uniqueItems[Math.floor(Math.random() * uniqueItems.length)]);
    const arr = [...choices].sort(() => Math.random() - 0.5);
    quizChoices.innerHTML = ''; quizResult.textContent = '';
    arr.forEach(s => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'quizChoice'; b.textContent = s;
      b.addEventListener('click', () => {
        if (quizAnswered) return;
        if (s === quizAnswer) {
          quizAnswered = true;
          registerCorrectAnswer();
          quizResult.textContent = levelCorrect[Number(levelEl.value)] >= QUESTIONS_TO_UNLOCK ? '🏆 Niveau terminé !' : '🌟 Bravo ! +10 points';
          addScore(10); current.textContent = s; markCompleted(s); showWord(s);
          [...quizChoices.querySelectorAll('button')].forEach(x => x.disabled = true);
        } else {
          quizResult.textContent = '💡 Pas encore. Réécoute et essaie.';
          speak(quizAnswer, {silent:true});
        }
      });
      quizChoices.appendChild(b);
    });
    // La première lecture est déclenchée par le bouton 'Exercices' pour respecter les règles Android/WebView.
    // L'enfant peut réécouter avec le bouton Répéter.
  }

  document.getElementById('playBtn').addEventListener('click', playSelected);
  document.getElementById('repeatBtn').addEventListener('click', () => {
    if (selected.length) speak(selected.join(' '));
    else if (current.textContent !== '—') speak(current.textContent);
    else message.textContent = 'Rien à répéter.';
  });
  document.getElementById('clearBtn').addEventListener('click', () => { selected = []; render(); message.textContent = 'Sélection effacée.'; });
  document.getElementById('stopBtn').addEventListener('click', () => { stopSpeech(); message.textContent = 'Lecture arrêtée.'; });
  document.getElementById('quizBtn').addEventListener('click', async () => { showPage('exercices'); quiz.classList.remove('hidden'); newQuiz(); await speak(quizAnswer); });
  document.getElementById('nextQuizBtn').addEventListener('click', newQuiz);
  document.getElementById('closeQuizBtn').addEventListener('click', () => quiz.classList.add('hidden'));
  document.getElementById('speakWordBtn').addEventListener('click', () => wordText.textContent !== '—' && speak(wordText.textContent));
  document.getElementById('wordQuizBtn').addEventListener('click', () => { showPage('mots'); showWordQuiz(); });
  document.getElementById('nextWordBtn').addEventListener('click', newWordQuiz);
  document.getElementById('closeWordQuizBtn').addEventListener('click', () => wordQuiz.classList.add('hidden'));
  document.getElementById('userBtn').addEventListener('click', openUserModal);
  document.getElementById('switchUserBtn').addEventListener('click', openUserModal);
  document.getElementById('closeUserModal').addEventListener('click', closeUserModal);
  document.getElementById('saveUserBtn').addEventListener('click', createUserFromInput);
  document.getElementById('userNameInput').addEventListener('keydown', e => { if (e.key === 'Enter') createUserFromInput(); });
  document.getElementById('userModal').addEventListener('click', e => { if (e.target.id === 'userModal') closeUserModal(); });

  document.getElementById('resetBtn').addEventListener('click', () => {
    if (!confirm('Effacer la progression et le score ?')) return;
    score = 0; completed = {}; levelCorrect = {}; wordCorrect = {}; unlockedLevel = 1; quizAnswered = false; wordQuizAnswered = false; saveProfile(); setScoreDisplay(0); updateHomeStats(); updateLevelLocks(); levelEl.value = '1'; render(); updateWordCounter();
  });
  levelEl.addEventListener('change', () => { delete quizDecks[String(levelEl.value)]; delete wordDecks[String(levelEl.value)]; selected = []; quiz.classList.add('hidden'); wordQuiz.classList.add('hidden'); render(); updateWordCounter(); });

  if (localStorage.getItem(VOICE_CONSENT_KEY) === null) showVoiceModal();

  levelEl.value = String(Math.min(unlockedLevel, 7));
  render();
  updateWordCounter();
  updateHomeStats();
  if (!profile) openUserModal();
})();
