# Production Status v1.6

- Web/PWA: packaged.
- Supabase Auth client: packaged.
- Multi-tenant state snapshot: deployed in Supabase migration.
- Storage buckets: `mrk-documents`, `mrk-backups`.
- Immutable Audit Trail: enabled by database trigger.
- Sayyad check number: 16-digit server validation.
- Android source: present.
- Android Release workflow: present.
- Local environment: no Android SDK detected, therefore no binary APK was claimed as built here.

## Excel Storage/Export Audit — v1.6.1
- Android import: system file picker via WebView `onShowFileChooser` / `ACTION_OPEN_DOCUMENT`.
- Android export: system Save As picker via `ACTION_CREATE_DOCUMENT`; user chooses location and filename.
- Fixed official Excel template paths (`*-v1.5.xlsx`).
- Fixed Import Wizard XLSX handoff (`parseXlsx(file)`).
- Added operational Excel exports for parties and items.
- Added sample XLS report files under `examples/`.


## v1.6.6 Excel/Storage hotfix
Native Android file-open/save choosers are now wired to the Excel import and report export flows.
