# MR-KHORASANI v1.6.6 — Excel Storage & File Picker Fix

- Native Android `ACTION_OPEN_DOCUMENT` bridge for Excel/CSV/JSON imports.
- Native Android `ACTION_CREATE_DOCUMENT` bridge for report/export saving.
- Parties, items and financial reports use the same storage bridge.
- Web fallback remains available when the native bridge is unavailable.
