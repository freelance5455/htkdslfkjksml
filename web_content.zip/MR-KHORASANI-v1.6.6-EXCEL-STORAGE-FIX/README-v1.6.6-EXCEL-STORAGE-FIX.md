# MR-KHORASANI v1.6.6

This release fixes Android file selection and Excel/report export.

### Upload / import
Use «انتخاب فایل از حافظه گوشی» in the Excel Import Wizard. The Android picker opens with XLSX/XLS/CSV/JSON filters.

### Export
Excel reports for financial reports, parties and items use Android's file-save picker so the user chooses the destination and filename.

### APK
Use the included `android/` project for native picker support. A generic ZIP-to-APK wrapper that ignores the Android project cannot provide native bridge behavior.
