# MR-KHORASANI v1.6.4

## فاکتور چندردیفی
- یک شماره فاکتور برای چند ردیف کالا
- کالا، انبار، تعداد، فی، تخفیف و حمل در هر ردیف
- جمع ناخالص، تخفیف، حمل، مالیات و مبلغ نهایی خودکار
- کنترل موجودی هر ردیف و انبار

## برگشت چندردیفی
- ورود شماره فاکتور مبنا
- نمایش تمام ردیف‌های قابل برگشت
- انتخاب/تیک هر ردیف مستقل
- ثبت تعداد برگشتی برای هر ردیف
- کنترل حداکثر مجاز برگشت
- اتصال برگشت جدید به ردیف مبنا برای کنترل دفعات بعدی


## v1.6.5 Cloud settings activation
- Settings includes three active cloud fields: service sync URL, cloud email, and cloud password.
- Service URL and email are persisted; cloud password is intentionally not persisted.
- Activate Cloud authenticates against the configured Supabase service and enables Push/Pull.
- Successful backups are uploaded to the company-scoped `mrk-backups` bucket when a cloud session is active.
