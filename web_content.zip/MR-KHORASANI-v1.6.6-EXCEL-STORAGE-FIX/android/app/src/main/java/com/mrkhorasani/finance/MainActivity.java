package com.mrkhorasani.finance;

import android.app.Activity;
import android.content.Intent;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowInsets;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private static final int FILE_CHOOSER = 8016;
    private static final int SAVE_FILE_CHOOSER = 8017;
    private String pendingSaveRequestId;
    private String pendingSaveFileName;
    private String pendingSaveMime;
    private byte[] pendingSaveBytes;
    private String pendingPickRequestId;
    private String[] pendingPickMimeTypes;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(23,17,10));
        w.setNavigationBarColor(android.graphics.Color.rgb(23,17,10));
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileChooserCallback!=null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback=cb;
                Intent i=params.createIntent();
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try{ startActivityForResult(i, FILE_CHOOSER); }catch(Exception e){ fileChooserCallback=null; return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER && fileChooserCallback!=null){
            Uri[] r=(resultCode==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;
            fileChooserCallback.onReceiveValue(r); fileChooserCallback=null;
            return;
        }
        if(requestCode==FILE_CHOOSER){
            // Legacy WebView file inputs. The explicit native bridge below is preferred,
            // but this callback remains for compatibility with generic <input type=file>.
            return;
        }
        if(requestCode==9001){
            String req=pendingPickRequestId;
            pendingPickRequestId=null;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && req!=null){
                try{
                    Uri uri=data.getData();
                    String name=queryDisplayName(uri);
                    String mime=getContentResolver().getType(uri);
                    if(TextUtils.isEmpty(mime)) mime=guessMime(name);
                    byte[] bytes=readAll(getContentResolver().openInputStream(uri));
                    String b64=Base64.encodeToString(bytes,Base64.NO_WRAP);
                    notifyPickedFile(req,true,name,mime,b64);
                }catch(Exception e){ notifyPickedFile(req,false,"","",""); }
            }else if(req!=null){
                notifyPickedFile(req,false,"","","");
            }
            return;
        }
        if(requestCode==SAVE_FILE_CHOOSER){
            boolean ok=false;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingSaveBytes!=null){
                try(OutputStream os=getContentResolver().openOutputStream(data.getData())){
                    if(os!=null){os.write(pendingSaveBytes);os.flush();ok=true;}
                }catch(Exception ignored){}
            }
            notifySaveResult(ok);
        }
    }

    private void notifyPickedFile(String id, boolean ok, String name, String mime, String base64){
        if(id==null || webView==null)return;
        String safeId=id.replace("\\","\\\\").replace("'","\\'");
        String safeName=(name==null?"":name).replace("\\","\\\\").replace("'","\\'");
        String safeMime=(mime==null?"application/octet-stream":mime).replace("\\","\\\\").replace("'","\\'");
        String safeB64=base64==null?"":base64;
        webView.evaluateJavascript("window.__mrkNativeFileDone&&window.__mrkNativeFileDone('"+safeId+"',"+(ok?"true":"false")+",'"+safeName+"','"+safeMime+"','"+safeB64+"');",null);
    }

    private String queryDisplayName(Uri uri){
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(uri,new String[]{"_display_name"},null,null,null);
            if(c!=null && c.moveToFirst()){int i=c.getColumnIndex("_display_name");if(i>=0)return c.getString(i);}
        }catch(Exception ignored){} finally {if(c!=null)c.close();}
        String s=uri.getLastPathSegment();return s==null?"import.dat":s;
    }
    private String guessMime(String name){
        String n=name==null?"":name.toLowerCase(java.util.Locale.US);
        if(n.endsWith(".xlsx"))return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if(n.endsWith(".xls"))return "application/vnd.ms-excel";
        if(n.endsWith(".csv"))return "text/csv";
        if(n.endsWith(".json"))return "application/json";
        return "application/octet-stream";
    }
    private byte[] readAll(InputStream in)throws Exception{
        if(in==null)return new byte[0];ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int len;while((len=in.read(buf))!=-1)out.write(buf,0,len);in.close();return out.toByteArray();
    }

    private void notifySaveResult(boolean ok){
        String id=pendingSaveRequestId;
        pendingSaveRequestId=null; pendingSaveFileName=null; pendingSaveMime=null; pendingSaveBytes=null;
        if(id==null || webView==null)return;
        String safe=id.replace("\\","\\\\").replace("'","\\'");
        webView.evaluateJavascript("window.__mrkNativeSaveDone&&window.__mrkNativeSaveDone('"+safe+"',"+(ok?"true":"false")+");",null);
    }

    @Override public void onBackPressed(){
        if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class AndroidBridge {
        @android.webkit.JavascriptInterface public String getDeviceId(){
            try{return Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);}catch(Exception e){return "";}
        }
        @android.webkit.JavascriptInterface public String pickFileWithChooser(String mimeTypesCsv){
            try{
                final String req=UUID.randomUUID().toString();
                pendingPickRequestId=req;
                pendingPickMimeTypes=(mimeTypesCsv==null||mimeTypesCsv.trim().isEmpty())?new String[]{"*/*"}:mimeTypesCsv.split(",");
                final String[] mimes=pendingPickMimeTypes;
                runOnUiThread(()->{
                    try{
                        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        i.putExtra(Intent.EXTRA_MIME_TYPES,mimes);
                        startActivityForResult(i,9001);
                    }catch(Exception e){ notifyPickedFile(req,false,"","",""); }
                });
                return req;
            }catch(Exception e){pendingPickRequestId=null;return "";}
        }

        @android.webkit.JavascriptInterface public String saveFileWithChooser(String fileName,String mime,String base64){
            try{
                if(fileName==null || fileName.trim().isEmpty()) fileName="MR-KHORASANI-output.xls";
                final String req=UUID.randomUUID().toString();
                pendingSaveRequestId=req;
                pendingSaveFileName=fileName;
                pendingSaveMime=(mime==null||mime.isEmpty())?"application/octet-stream":mime;
                pendingSaveBytes=Base64.decode(base64,Base64.DEFAULT);
                final String saveName=pendingSaveFileName, saveMime=pendingSaveMime;
                runOnUiThread(()->{
                    try{
                        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType(saveMime);
                        i.putExtra(Intent.EXTRA_TITLE,saveName);
                        startActivityForResult(i,SAVE_FILE_CHOOSER);
                    }catch(Exception e){ notifySaveResult(false); }
                });
                return req;
            }catch(Exception e){
                pendingSaveRequestId=null; pendingSaveFileName=null; pendingSaveMime=null; pendingSaveBytes=null;
                return "";
            }
        }

        @android.webkit.JavascriptInterface public boolean saveFile(String fileName,String mime,String base64,String directory){
            try{
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                if(Build.VERSION.SDK_INT>=29){
                    android.content.ContentValues v=new android.content.ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,fileName);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MR-KHORASANI");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(uri==null)return false;
                    try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)return false;os.write(bytes);}
                    return true;
                }
                File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"MR-KHORASANI");
                if(!dir.exists() && !dir.mkdirs())return false;
                try(FileOutputStream fos=new FileOutputStream(new File(dir,fileName))){fos.write(bytes);}
                return true;
            }catch(Exception e){return false;}
        }
        @android.webkit.JavascriptInterface public boolean saveToDownloads(String fileName,String mime,String base64){return saveFile(fileName,mime,base64,"Download/MR-KHORASANI");}
        @android.webkit.JavascriptInterface public boolean writeFile(String path,String mime,String base64){
            String name=path==null?"file.bin":path.substring(path.lastIndexOf('/')+1);
            return saveFile(name,mime,base64,path);
        }
    }
}
