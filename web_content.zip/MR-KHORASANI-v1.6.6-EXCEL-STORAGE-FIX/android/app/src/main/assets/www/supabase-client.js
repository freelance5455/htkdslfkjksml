/* MR,KHORASANI v1.6 — Supabase production client (no service-role key) */
(function(){
  const CONFIG = window.MRK_SUPABASE || {
    url: 'https://klomsegarpfdkhkmoazy.supabase.co',
    publishableKey: 'sb_publishable_bkwQJ96fqM2zd0yu0XQ6LA_QJl2c2RV'
  };
  const TOKEN_KEY='mrk-supabase-session-v1';
  const jsonHeaders=token=>({
    'Content-Type':'application/json',
    'apikey':CONFIG.publishableKey,
    ...(token?{'Authorization':'Bearer '+token}:{})
  });
  const readSession=()=>{try{return JSON.parse(localStorage.getItem(TOKEN_KEY)||'null')}catch{return null}};
  const saveSession=s=>{try{localStorage.setItem(TOKEN_KEY,JSON.stringify(s))}catch{}};
  const clearSession=()=>{try{localStorage.removeItem(TOKEN_KEY)}catch{}};
  async function req(path,options={}){
    const s=readSession();
    const h={...jsonHeaders(s?.access_token),...(options.headers||{})};
    const r=await fetch(CONFIG.url+path,{...options,headers:h});
    const text=await r.text();
    let body=null; try{body=text?JSON.parse(text):null}catch{body=text}
    if(!r.ok) throw new Error(body?.msg||body?.message||body?.error_description||body?.error||('HTTP '+r.status));
    return body;
  }
  async function login(email,password){
    const r=await fetch(CONFIG.url+'/auth/v1/token?grant_type=password',{method:'POST',headers:jsonHeaders(),body:JSON.stringify({email,password})});
    const text=await r.text(); let body=null; try{body=JSON.parse(text)}catch{}
    if(!r.ok) throw new Error(body?.error_description||body?.msg||'ورود ابری ناموفق بود.');
    saveSession(body); return body;
  }
  async function user(){return req('/auth/v1/user');}
  async function memberships(uid){return req('/rest/v1/company_members?user_id=eq.'+encodeURIComponent(uid)+'&is_active=eq.true&select=company_id,role,is_active');}
  async function company(id){const r=await req('/rest/v1/companies?id=eq.'+encodeURIComponent(id)+'&select=*');return r?.[0]||null;}
  async function claimInitialCompany(name){return req('/rest/v1/rpc/claim_initial_company',{method:'POST',body:JSON.stringify({p_company_name:name||'MR,KHORASANI'})});}
  function setEndpoint(url){const u=String(url||'').trim().replace(/\/$/,'');if(!/^https?:\/\//i.test(u)) throw new Error('نشانی سرویس Cloud معتبر نیست.');CONFIG.url=u;try{window.MRK_SUPABASE=window.MRK_SUPABASE||{};window.MRK_SUPABASE.url=u}catch{}return u;}
  function roleFa(code){return ({OWNER:'مدیر عامل',ADMIN:'مدیر سیستم',FINANCE:'مدیر مالی',ACCOUNTANT:'حسابدار',SALES:'فروش',PURCHASE:'خرید',CASHIER:'صندوقدار',WAREHOUSE:'انباردار',AUDITOR:'حسابرس',VIEWER:'ناظر'}[String(code||'').toUpperCase()])||'حسابدار';}
  function scrub(state){
    const s=JSON.parse(JSON.stringify(state||{}));
    delete s.password; delete s.passwordHash; delete s.passwordSalt;
    if(Array.isArray(s.users)) s.users=s.users.map(u=>{const x={...u};delete x.password;delete x.passwordHash;delete x.passwordSalt;return x;});
    s.schemaVersion='1.6.0';
    return s;
  }
  async function pushState(companyId,state){
    if(!companyId||!/^[0-9a-f-]{36}$/i.test(companyId)) throw new Error('شناسه شرکت Cloud معتبر نیست.');
    return req('/rest/v1/app_state_snapshots',{method:'POST',headers:{'Prefer':'resolution=merge-duplicates,return=representation'},body:JSON.stringify({company_id:companyId,state:scrub(state),schema_version:'1.6.0',updated_by:(readSession()?.user?.id||null),updated_at:new Date().toISOString()})});
  }
  async function pullState(companyId){
    if(!companyId) throw new Error('شرکت فعال انتخاب نشده است.');
    const r=await req('/rest/v1/app_state_snapshots?company_id=eq.'+encodeURIComponent(companyId)+'&select=state,schema_version,updated_at');
    return r?.[0]||null;
  }
  async function uploadDocument(companyId,path,file){
    if(!companyId||!file) throw new Error('اطلاعات سند ناقص است.');
    const s=readSession();
    const safe=String(path||file.name).replace(/^\/+/, '').replace(/\.\.+/g,'.');
    const objectPath=companyId+'/'+safe;
    const r=await fetch(CONFIG.url+'/storage/v1/object/mrk-documents/'+encodeURIComponent(objectPath).replace(/%2F/g,'/'),{method:'POST',headers:{...jsonHeaders(s?.access_token),'x-upsert':'true'},body:file});
    if(!r.ok) throw new Error('ذخیره سند در Storage ناموفق بود.');
    return {path:objectPath};
  }
  async function uploadBackup(companyId,fileName,blob){
    const s=readSession(); const objectPath=companyId+'/'+fileName;
    const r=await fetch(CONFIG.url+'/storage/v1/object/mrk-backups/'+encodeURIComponent(objectPath).replace(/%2F/g,'/'),{method:'POST',headers:{...jsonHeaders(s?.access_token),'x-upsert':'true'},body:blob});
    if(!r.ok) throw new Error('ذخیره Backup ابری ناموفق بود.');
    return {path:objectPath};
  }
  window.MRKCloud={CONFIG,setEndpoint,readSession,saveSession,clearSession,login,user,memberships,company,claimInitialCompany,roleFa,pushState,pullState,uploadDocument,uploadBackup,ready:true};
})();
