package com.uddipan.followup;
import android.content.*; import java.util.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ android.content.SharedPreferences p=c.getSharedPreferences("alarms",0); Map<String,?> all=p.getAll(); for(String k:all.keySet()) if(k.startsWith("t_")){ try{int id=Integer.parseInt(k.substring(2)); long t=p.getLong(k,0); String n=p.getString("n_"+id,"সদস্য"); if(t>System.currentTimeMillis()) ReminderReceiver.schedule(c,t,id,n);}catch(Exception ignored){} } } }
