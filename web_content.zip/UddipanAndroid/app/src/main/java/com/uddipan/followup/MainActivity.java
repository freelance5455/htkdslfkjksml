package com.uddipan.followup;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(this),"Android"); web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i); setIntent(i); openMemberFromIntent(i);}
    private void openMemberFromIntent(Intent i){ final String id=i.getStringExtra("memberId"); if(id==null||web==null)return; web.postDelayed(()->web.evaluateJavascript("androidReminderTriggered('\"+id.replace("'","\\'")+"');openM("+id+");",null),900); }
    public static class AndroidBridge { final Context c; AndroidBridge(Context c){this.c=c;}
        @JavascriptInterface public void scheduleReminder(String millis,String memberId,String memberName){ try{ long t=Long.parseLong(millis); int id=Integer.parseInt(memberId); ReminderReceiver.schedule(c,t,id,memberName); }catch(Exception ignored){} }
    }
}
