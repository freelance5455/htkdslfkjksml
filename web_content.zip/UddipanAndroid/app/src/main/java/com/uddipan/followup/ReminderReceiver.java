package com.uddipan.followup;

import android.app.AlarmManager; import android.app.NotificationChannel; import android.app.NotificationManager; import android.app.PendingIntent; import android.content.Context; import android.content.Intent; import android.os.Build;

public class ReminderReceiver extends android.content.BroadcastReceiver {
 public static final String CH="uddipan_reminders";
 public static void schedule(Context c,long when,int memberId,String name){
   if(when<=System.currentTimeMillis()) when=System.currentTimeMillis()+1000;
   Intent i=new Intent(c,ReminderReceiver.class).putExtra("memberId",memberId).putExtra("name",name);
   PendingIntent pi=PendingIntent.getBroadcast(c,memberId,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
   try{ if(Build.VERSION.SDK_INT>=23){ try{am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);}catch(SecurityException e){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);} }else am.setExact(AlarmManager.RTC_WAKEUP,when,pi); }catch(Exception e){am.set(AlarmManager.RTC_WAKEUP,when,pi);}
   c.getSharedPreferences("alarms",0).edit().putLong("t_"+memberId,when).putString("n_"+memberId,name).apply();
 }
 @Override public void onReceive(Context c,Intent i){ int id=i.getIntExtra("memberId",0); String name=i.getStringExtra("name"); if(id<=0)return;
   NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CH,"উদ্দীপন রিমাইন্ডার",NotificationManager.IMPORTANCE_HIGH));
   Intent open=new Intent(c,MainActivity.class).putExtra("memberId",String.valueOf(id)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
   PendingIntent pi=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(c,CH):new android.app.Notification.Builder(c);
   b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("উদ্দীপন সদস্য ফলোআপ").setContentText((name==null?"সদস্য":name)+" — রিমাইন্ডারের সময় হয়েছে").setAutoCancel(true).setContentIntent(pi).setVibrate(new long[]{0,500,250,500,250,900}); nm.notify(id,b.build());
 }
}
