TPV KIT DESIGNER — UPGRADED ANDROID WEB APP

Included:
- Shirt, shorts, socks and full-kit preview tabs
- Outfield and goalkeeper kit mode
- Custom shirt colours, shorts colours and socks colours
- Six shirt patterns: plain, vertical stripes, hoops, diagonal sash, pinstripes and chevron
- Upload a custom club badge image
- Save/load/delete up to 50 designs in a local collection
- Export a PNG preview
- Export and import collection JSON backups
- DLS transfer guidance
- Responsive layout for Android phones

TRY IT:
1. Download and extract TPV_Kit_Designer_Upgraded.zip.
2. Open index.html in Chrome to use it locally.
3. For app-like installation, publish these files to a secure HTTPS static host.
4. Open the HTTPS address in Chrome and choose Install app or Add to Home screen if offered.

DLS NOTES:
This app designs visual kit concepts and PNG previews. It does not directly inject kits into Dream League Soccer or create a guaranteed-valid kit URL. Follow the current game's own customisation/import workflow. If the game asks for an image URL, it generally needs a direct, publicly accessible image URL accepted by that game version.

Saved designs are held in browser local storage. Export a JSON backup before clearing browser data.
This is a web app package, not an APK.
