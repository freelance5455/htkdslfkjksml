@echo off
setlocal
cd /d "%~dp0"
title Budget Pro - Local Server
chcp 65001 >nul

echo Starting Budget Pro...
echo.

if not exist "budgetpro_server.py" (
  echo ERROR: budgetpro_server.py was not found in this folder.
  pause
  exit /b 1
)
if not exist "budgetpro.html" (
  echo ERROR: budgetpro.html was not found in this folder.
  pause
  exit /b 1
)

where py >nul 2>nul
if not errorlevel 1 (
  py -3 "budgetpro_server.py"
) else (
  where python >nul 2>nul
  if not errorlevel 1 (
    python "budgetpro_server.py"
  ) else (
    echo ERROR: Python 3 was not found.
    echo Install Python 3 and select Add Python to PATH.
    pause
    exit /b 1
  )
)

echo.
echo Budget Pro has stopped. Review any error shown above.
pause
