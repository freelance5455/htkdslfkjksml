ELFIRR X G — DARK FANTASY
==========================
Offline browser RPG prototype.

FILES
-----
index.html              Main game. Open this file in a modern browser.
assets/ui_montage.png   Generated dark-fantasy artwork used by the UI.

CONTROLS
--------
Android: landscape + on-screen D-pad and skill buttons.
PC: WASD / Arrow keys, Space = attack, Q = Arcane, Shift = Dash, Esc = pause.

GAMEPLAY
--------
3 playable roles: Lyra (Mage), Bram (Tank), Kael (Assassin).
10 stages, enemy waves, HP/MP, gold, combat effects, upgrades, pause, settings.
Settings persist in localStorage. Audio is generated locally with Web Audio API.
No external libraries, CDN, network, or server are required.

PERFORMANCE
-----------
Low quality uses DPR 1 and lightweight Canvas 2D rendering. Medium/High increase
render resolution. For older Android devices, keep Quality = Low and Auto Attack
on/off according to preference.
