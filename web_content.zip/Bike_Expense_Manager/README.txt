BIKE EXPENSE MANAGER

Open index.html in a modern browser (Chrome recommended).
The app stores records locally in the browser on this device.

Features:
- Petrol, service, repair and other expense records
- Date, amount, odometer KM, petrol litres and price per litre
- Service date and service KM history
- Monthly totals and all-time totals
- Filter, edit and delete records
- CSV export (opens in Excel)
- Print / Save as PDF
- JSON backup and restore

IMPORTANT:
- This package is a browser-based app, not a compiled Android APK.
- Do not clear browser app/site data unless you have exported a backup.
- For an Android APK, this source needs to be packaged and built with Android tooling.
