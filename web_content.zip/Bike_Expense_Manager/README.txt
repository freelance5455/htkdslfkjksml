BIKE EXPENSE MANAGER - PIN LOCK VERSION

Open index.html in a modern browser (Chrome recommended).
Features retained from the original:
- Petrol, service, repair and other expense records
- Monthly totals, all-time totals, filters, edit/delete
- CSV export, print/PDF, JSON backup and restore

Security added:
- First launch asks you to create a 4-6 digit PIN.
- PIN is hashed with Web Crypto and stored in this browser on this device.
- App locks when it goes into the background and when it is reopened.
- Change PIN and Lock App Now controls are available in Reports & Backup.

IMPORTANT LIMITATIONS:
- This is still a browser-based HTML app, not an Android APK.
- Fingerprint authentication is NOT implemented in this ZIP. Android fingerprint requires a native Android wrapper using Android BiometricPrompt (or a compatible Capacitor biometric plugin), then building/signing an APK.
- Browser PIN protection is a convenience lock, not high-security encryption. App data remains in browser localStorage. Export backups regularly.
- Use Chrome on HTTPS or localhost for Web Crypto support. Some file:// viewers may not support secure cryptography.
- Clearing browser/site data can erase the PIN and expense records.
