/* Rift Mate v4.0.0 - data-driven champion guides, ratings, items, search, draft composition analysis.
   Loaded after the original inline script. Overrides selected global functions. */
(function(){
'use strict';
const AR=window.WRC4_AR||{};
const DB=window.WRC_DB;
const WRC4=window.WRC4={cache:{},waiting:{},
  d(s,o){this.cache[s]=o;(this.waiting[s]||[]).forEach(f=>f(o,null));delete this.waiting[s]},
  load(s,cb){
    if(this.cache[s])return cb(this.cache[s],null);
    if(this.waiting[s]){this.waiting[s].push(cb);return}
    this.waiting[s]=[cb];
    const c=CHAMPS.find(x=>x.slug===s);const sc=document.createElement('script');
    sc.src=(c&&c.detailFile)||('data/c/'+s+'.js');
    sc.onerror=()=>{const w=this.waiting[s]||[];delete this.waiting[s];w.forEach(f=>f(null,'load'))};
    document.head.appendChild(sc);
  }};
const esc=v=>escapeHTML(v);
const A=()=>lang==='ar';
const TM=Object.assign({},DB.translations||{},window.WRC4_TR||{});
Object.assign(nameAr,DB.nameArExtra||{});
const LANES=['Baron','Jungle','Mid','Dragon','Support'];
const laneName=l=>A()?(AR.LANE_AR[l]||l):l;
const itemAr=n=>AR.ITEM_AR[n]||null;
const itemLabel=n=>A()?(itemAr(n)?`${esc(itemAr(n))} <small class="en-name" dir="ltr">${esc(n)}</small>`:`<span dir="ltr">${esc(n)}</span>`):esc(n);
const runeLabel=n=>A()?(AR.RUNE_AR[n]?`${esc(AR.RUNE_AR[n])} <small class="en-name" dir="ltr">${esc(n)}</small>`:esc(n)):esc(n);
const bootsLabel=n=>A()?(AR.BOOTS_AR[n]?`${esc(AR.BOOTS_AR[n])} <small class="en-name" dir="ltr">${esc(n)}</small>`:esc(n)):esc(n);
const NOREC='لا تتوفر بيانات موثقة حاليًا';
function tx(en){ // prose from source
  if(!en)return '';
  if(!A())return esc(en);
  const t=TM[en];
  if(t)return esc(t);
  return `<span class="en-src" dir="ltr" lang="en">${esc(en)}</span>`;
}
function buildName(n){
  if(!A())return esc(n);
  const p=String(n).split(' — ');
  const a=AR.BUILD_NAME_AR[p[0]]||AR.BUILD_NAME_AR[n]||null;
  const b=p[1]?(AR.SUB_AR[p[1]]||p[1]):'';
  if(!a)return esc(n);
  return esc(a+(b?' — '+b:''));
}
function whenAr(w){
  if(!A())return esc(w||'');
  if(!w)return '';
  let out=w;
  Object.keys(AR.WHEN_AR).sort((a,b)=>b.length-a.length).forEach(k=>{out=out.split(k).join(AR.WHEN_AR[k]+' · ')});
  return esc(out.replace(/ · $/,'').replace(/ · +/g,' · ').trim());
}
function sitAr(w){
  if(!A())return esc(w);
  const m=String(w).split(' — instead of ');
  const base=AR.SIT_AR[m[0]]||m[0];
  return esc(base+(m[1]?' (بدلًا من '+(itemAr(m[1])||m[1])+')':''));
}
const verdictAr=v=>A()?(AR.VERDICT_AR[v]||v):v;
const tierAr={'Ideal':'مثالي','Strong':'قوي','Related':'مرتبط'};
const fmt=(v,d=1)=>v==null||v===''?'—':(typeof v==='number'?v.toFixed(d):v);
const stars=n=>n==null?'<span class="muted">—</span>':`<span class="rbar"><i style="width:${Math.max(0,Math.min(100,n*10))}%"></i></span><b>${n}/10</b>`;
function klassLabel(c){const k=c.klass;if(!k||k==='unknown')return A()?NOREC:'n/a';return A()?(AR.CLASS_AR[k]||k):k}
function dmgLabel(c){return A()?({AD:'ضرر جسدي',AP:'ضرر سحري',MIX:'ضرر مختلط'}[c.dmgType]||'—')+(c.damageSource==='estimate'?' (تقدير)':''):c.dmgType}
function diffLabel(c){const e=c.difficulty;if(e==null)return A()?NOREC:'n/a';return e>=7?(A()?'سهل':'Easy'):e>=5?(A()?'متوسط':'Medium'):(A()?'صعب':'Hard')}
function champImg(slugOrName){const c=typeof slugOrName==='string'?(CHAMPS.find(x=>x.slug===slugOrName)||CHAMPS.find(x=>x.name===slugOrName)):slugOrName;return c?img(c):''}
function champBySlug(s){return CHAMPS.find(c=>c.slug===s)}
function nameBox(c){return c?`<b>${esc(displayName(c))}</b>${A()?`<small class="en-name" dir="ltr">${esc(c.name)}</small>`:''}`:''}
function itemImg(name,img){const it=(DB.items||[]).find(x=>x.name===name);const src=img||(it&&it.image)||'';const g=(it&&ITEM_GLYPH[it.category])||'◇';return `<span class="item-art mini">${src?`<img loading="lazy" src="${esc(src)}" alt="${esc(name)}" onerror="this.remove()">`:''}<span>${g}</span></span>`}
const mk=(h)=>{const d=document.createElement('div');d.innerHTML=h;return d};

/* ---------------- champion detail ---------------- */
const TABS=[['overview','نظرة عامة','Overview'],['skills','المهارات','Skills'],['builds','البناءات','Builds'],['runes','الرونات والتعويذات','Runes & spells'],['counters','الكونترات','Counters'],['synergy','الانسجام','Synergy'],['stats','الإحصائيات','Stats'],['tips','نصائح اللعب','Tips'],['ratings','التقييمات','Ratings']];
let curChamp=null,curTab='overview';
window.showDetail=function(c){
  curChamp=c;curTab='overview';
  const detail=$('champDetail');detail.classList.remove('hidden');
  detail.innerHTML=`<div class="row between"><div class="row">${img(c)}<div><h2>${esc(displayName(c))}${A()?` <small class="en-name" dir="ltr">${esc(c.name)}</small>`:''}</h2>${(c.roles||[c.lane]).map(x=>`<span class="tag">${esc(laneName(x))}</span>`).join('')}<span class="tag">${esc(c.tier||'—')}</span><span class="tag">${esc(klassLabel(c))}</span><span class="tag">${esc(dmgLabel(c))}</span></div></div><button class="btn" id="closeDetail" aria-label="${A()?'إغلاق':'Close'}">×</button></div>
  <div class="detail-tabs wrc4-tabs">${TABS.map((t,i)=>`<button type="button" class="detail-tab ${i===0?'active':''}" data-detail-tab="${t[0]}">${A()?t[1]:t[2]}</button>`).join('')}</div><div id="detailContent" class="wrc4-pane"></div>
  `;
  detail.querySelectorAll('[data-detail-tab]').forEach(b=>b.addEventListener('click',()=>{detail.querySelectorAll('[data-detail-tab]').forEach(x=>x.classList.toggle('active',x===b));curTab=b.dataset.detailTab;paint()}));
  $('closeDetail').onclick=()=>detail.classList.add('hidden');
  paint();detail.scrollIntoView({behavior:'smooth',block:'nearest'});
};
function paint(){
  const c=curChamp,pane=$('detailContent');if(!pane)return;
  pane.innerHTML=`<div class="notice">${A()?'جاري تحميل بيانات البطل…':'Loading champion data…'}</div>`;
  WRC4.load(c.slug,(d,err)=>{
    if(c!==curChamp)return;
    if(err||!d){pane.innerHTML=`<div class="notice warn">${A()?'تعذر تحميل ملف بيانات هذا البطل (data/c/'+esc(c.slug)+'.js). تأكد أن مجلد data موجود بجانب index.html.':'Could not load this champion data file.'}</div>`+tabBase(c);return}
    const f={overview:tOverview,skills:tSkills,builds:tBuilds,runes:tRunes,counters:tCounters,synergy:tSynergy,stats:tStats,tips:tTips,ratings:tRatings}[curTab];
    pane.innerHTML=f(c,d)+srcNote();
    pane.querySelectorAll('[data-go-champ]').forEach(b=>b.onclick=()=>{const x=champBySlug(b.dataset.goChamp);if(x)showDetail(x)});
  });
}
function srcNote(){return A()?`<p class="muted small src-note">ملاحظة: النصوص الشارحة الطويلة (المكتوبة بالإنجليزية في الصندوق المميز) لم تُترجم كلها بعد (الترجمة جارية على دفعات)، أما الأسماء والأرقام والتصنيفات والتسميات فمعرّبة.</p>`:''}
function tabBase(c){const g=(c.stats)||{};return `<div class="stats-grid"><div><b>${fmt(g.winRate)}%</b><small>${tr('winRate')}</small></div><div><b>${fmt(g.pickRate)}%</b><small>${tr('pickRate')}</small></div><div><b>${fmt(g.banRate)}%</b><small>${tr('banRate')}</small></div></div>`}
function h(t,en){return `<h3>${A()?t:en}</h3>`}
function missing(){return `<div class="notice">${A()?NOREC+'.':'No documented data available.'}</div>`}
function paraList(a){return (a||[]).map(p=>`<p>${tx(p)}</p>`).join('')}
function bullets(a){return a&&a.length?`<ul>${a.map(x=>`<li>${tx(x)}</li>`).join('')}</ul>`:''}
function lanesOf(c){return (c.roles&&c.roles.length?c.roles:[c.lane])}
function tOverview(c,d){
  const r=c.ratings||{};
  let o=`<div class="facts"><div><small>${A()?'التصنيف':'Class'}</small><b>${esc(klassLabel(c))}</b></div><div><small>${A()?'نوع الضرر':'Damage'}</small><b>${esc(dmgLabel(c))}</b></div><div><small>${A()?'الصعوبة':'Difficulty'}</small><b>${esc(diffLabel(c))}</b></div><div><small>${A()?'المسارات':'Lanes'}</small><b>${lanesOf(c).map(laneName).map(esc).join(' / ')}</b></div><div><small>${A()?'تقييم القوة العامة':'General power'}</small><b>${r.general!=null?r.general+'/10':'—'}</b></div></div>`;
  o+=tabBase(c);
  if(c.stats)o+=`<small class="muted">${esc(c.stats.scope||'')} · ${A()?'تاريخ الالتقاط':'captured'} ${esc(c.stats.capturedAt||'')}</small>`;
  else o+=`<div class="notice">${A()?'إحصائيات الفوز والاختيار والحظر لهذا البطل غير متوفرة حاليًا — '+NOREC+'.':'No ranked stats on source page.'}</div>`;
  o+=h('نظرة عامة','Overview');
  if(d.h)o+=`<p class="headline">${tx(d.h)}</p>`;
  o+=d.overview&&d.overview.length?paraList(d.overview):missing();
  (d.variants||[]).forEach(v=>{
    const lab=v.lane?` · ${esc(laneName(v.lane))}`:'';
    o+=`<h4>${A()?'نقاط القوة':'Strengths'}${lab}</h4>${bullets(v.strengths)||missing()}<h4>${A()?'نقاط الضعف':'Weaknesses'}${lab}</h4>${bullets(v.weak)||missing()}`;
  });
  if(!(d.variants||[]).length)o+=`<h4>${A()?'نقاط القوة والضعف':'Strengths & weaknesses'}</h4>${missing()}`;
  o+=h('أسلوب اللعب (البداية / المنتصف / النهاية)','Game plan');
  if(d.plans&&d.plans.length){d.plans.forEach(p=>{
    if(p.lane)o+=`<h4>${esc(laneName(p.lane))}</h4>`;
    const names=A()?['البداية (مستوى 1 إلى 6)','المنتصف (7 إلى 11)','النهاية (12+)']:['Early (1-6)','Mid (7-11)','Late (12+)'];
    o+=`<ol class="plan">${(p.phases||[]).map((ph,i)=>`<li><b>${esc(names[i]||ph.lvl)}</b><br>${tx((ph.text||[])[0]||ph.title)}</li>`).join('')}</ol>`})}
  else o+=missing();
  return o;
}
function tSkills(c,d){
  let o=h('المهارات','Skills');
  if(typeof skillGrid==='function')o+=skillGrid(null,c.name);
  const ab=(window.WRC4_AB||{})[c.slug];
  if(ab&&ab.length){
    const K=['P','Q','W','E','R'],KN={P:A()?'السلبية':'Passive',Q:'Q',W:'W',E:'E',R:A()?'القدرة القصوى':'Ultimate'};
    o+=`<h4>${A()?'وصف القدرات':'Ability descriptions'}</h4>`;
    ab.forEach((x,i)=>{const k=K[i]||'';const useAr=A()&&x[3];
      o+=`<div class="data-row skill"><div class="row"><span class="tag key">${k}</span><b>${esc(useAr?x[2]:x[0])}</b>${useAr?`<small class="muted" dir="ltr">${esc(x[0])}</small>`:''}<small class="muted">${esc(KN[k]||'')}</small></div><p>${useAr?esc(x[3]):`<span class="en-src" dir="ltr" lang="en">${esc(x[1])}</span>`}</p></div>`});
  }
  const sp=d.spells||[];
  if(!sp.length)return o+(ab&&ab.length?'':missing());
  const names={P:A()?'السلبية':'Passive',Q:'Q',W:'W',E:'E',R:A()?'القدرة القصوى R':'R'};
  o+=`<p>${A()?'ترتيب رفع المهارات (المستويات التي ترفع فيها كل مهارة)':'Skill upgrade levels'}:</p>`;
  sp.forEach(s=>{
    o+=`<div class="data-row skill"><div class="row"><span class="tag key">${esc(s.key)}</span><b dir="ltr">${esc(s.name)}</b><small class="muted">${esc(names[s.key]||'')}</small></div>`;
    if(s.ranks&&s.ranks.length)o+=`<small>${A()?'تُرفع في المستويات':'Levels'}: <b>${s.ranks.map(esc).join(' ، ')}</b></small>`;
    if(s.attrs&&s.attrs.length)o+=`<table class="mini-table">${s.attrs.map(([a,v])=>`<tr><td>${esc(A()?(AR.ATTR_AR[a]||a):a)}</td><td dir="ltr">${esc(v)}</td></tr>`).join('')}</table>`;
    else if(s.key==='P')o+=`<small class="muted">${A()?'وصف السلبية غير متوفر — '+NOREC:'Passive description not on source.'}</small>`;
    o+='</div>';
  });
  (d.combos||[]).length&&(o+=h('الكومبو','Combos')+d.combos.map(cb=>`<div class="data-row"><b dir="ltr">${esc(cb.name)}</b> <span class="tag">${esc(A()?(AR.DIFF_AR[cb.diff]||cb.diff):cb.diff)}</span><div class="keys">${(cb.keys||[]).map(k=>`<span class="tag key" dir="ltr">${esc(k)}</span>`).join(' → ')}</div><small>${tx(cb.note)}</small></div>`).join(''));
  return o;
}
function itemRow(items,slugs){return `<div class="build-items">${items.map((n,i)=>`<span class="bi">${itemImg(n)}<small>${itemLabel(n)}</small></span>`).join('<span class="arrow">›</span>')}</div>`}
function tBuilds(c,d){
  let o=h('البناءات والعناصر','Builds');
  if(!(d.lanes||[]).length)return o+missing();
  d.lanes.forEach(L=>{
    o+=`<div class="lane-block"><h4>${esc(laneName(L.lane))}</h4>`;
    (L.builds||[]).forEach(b=>{o+=`<div class="data-row"><b>${buildName(b.name)}</b>${itemRow(b.items)}<small>${A()?'التكلفة الكلية':'Total cost'}: ${b.cost.toLocaleString('en')} ${A()?'ذهبة':'gold'}${b.delta?' ('+esc(b.delta)+')':''}</small><small>${A()?'متى تختاره: ':'When: '}${whenAr(b.when)}</small></div>`});
    if(L.boots)o+=`<p>${A()?'الحذاء الموصى به':'Recommended boots'}: <b>${bootsLabel(L.boots)}</b></p>`;
    if(L.power&&L.power.early!=null)o+=`<p class="small">${A()?'قوة البطل مقابل بقية القائمة (نسبة تتفوق عليها): بداية':'Power vs roster: early'} ${L.power.early}% · ${A()?'منتصف':'mid'} ${L.power.mid}% · ${A()?'نهاية':'late'} ${L.power.late}%</p>`;
    if((L.situational||[]).length)o+=`<h5>${A()?'عناصر حسب الموقف':'Situational items'}</h5><ul class="sit">${L.situational.map(s=>`<li>${itemImg(s.item)} <b>${itemLabel(s.item)}</b> — ${sitAr(s.when)}</li>`).join('')}</ul>`;
    if((L.vs||[]).length)o+=`<h5>${A()?'التكيّف حسب الخصم':'Adaptation by opponent'}</h5><ul class="sit">${L.vs.map(s=>{const oc=champBySlug(s.slug);return `<li>${oc?img(oc):''} <b>${esc(oc?displayName(oc):s.name)}</b> (${esc(A()?(AR.VS_AR[s.why]||s.why):s.why)}) ← ${itemLabel(s.item)}</li>`}).join('')}</ul>`;
    o+='</div>';
  });
  return o+`<small class="muted">${esc(d.bsource||'')} · ${A()?'محسوبة بتاريخ':'computed'} ${esc(d.computed||'')}</small>`;
}
function tRunes(c,d){
  let o=h('الرونات','Runes');
  o+=(d.runes||[]).length?`<div class="rune-list">${d.runes.map((r,i)=>`<div class="data-row"><b>${i===0?(A()?'الرون الأساسي: ':'Keystone: '):''}${runeLabel(r.name)}</b><small>${tx(r.why)}</small></div>`).join('')}</div>`:missing();
  const boots=[...new Set((d.lanes||[]).map(l=>l.boots).filter(Boolean))];
  if(boots.length)o+=`<h4>${A()?'الأحذية':'Boots'}</h4><p>${boots.map(bootsLabel).join(' · ')}</p>`;
  o+=h('التعويذات (Summoner Spells)','Summoner spells')+`<div class="notice">${A()?'التعويذات الموصى بها لكل بطل غير منشورة — '+NOREC+'. الدليل التالي يشرح كل تعويذة.':'No per-champion recommended spells. Reference guide below.'}</div>`+(window.WRC4_SPELLS||[]).map(s=>`<div class="data-row"><b>${esc(A()?s.ar:s.en)}</b>${A()?` <small class="muted" dir="ltr">${esc(s.en)}</small>`:''}<p>${esc(A()?s.d:(s.dEn||s.d))}</p><small>${A()?'التبريد':'Cooldown'}: <b>${esc(s.cd)}</b> · ${A()?'المدى':'Range'}: <b>${esc(s.r)}</b></small></div>`).join('');
  return o;
}
function counterEntry(e){
  const oc=champBySlug(e.slug);
  const body=[['decides','التفاعل الحاسم','What decides it'],['why','السبب','Why'],['lane','تأثيره على المسار','Lane impact'],['how','كيف تلعبها','How to play']].filter(x=>e[x[0]]).map(x=>`<p><b>${A()?x[1]:x[2]}:</b> ${tx(e[x[0]])}</p>`).join('');
  return `<details class="cm"><summary>${oc?img(oc):''}<span class="who">${esc(oc?displayName(oc):e.name)}${A()&&oc?` <small class="en-name" dir="ltr">${esc(e.name)}</small>`:''}</span>${e.delta?`<span class="tag" dir="ltr">${esc(e.delta)}</span>`:''}${oc?`<button class="btn tiny" data-go-champ="${esc(e.slug)}">${A()?'فتح':'Open'}</button>`:''}</summary>${body||`<small class="muted">${NOREC}</small>`}</details>`;
}
function laneCM(X){
  const M=DB.matchups||[],by={};const lanes=(X.roles&&X.roles.length?X.roles:[X.lane]);
  const R=n=>CHAMPS.find(c=>c.name===n);
  const sev={Hard:3,Unfavorable:2,Skill:0,Favorable:-2};
  lanes.forEach(L=>{
    const cnt={},str={},ix={};
    M.forEach((m,mi)=>{
      if(m.lane!==L)return;
      if(m.champion===X.name){const Y=R(m.opponent);if(!Y||!(Y.roles||[Y.lane]).includes(L))return;
        if(m.verdict==='Hard'||m.verdict==='Unfavorable'){if((cnt[Y.name]||0)<sev[m.verdict]){cnt[Y.name]=sev[m.verdict];ix[Y.name]=mi}}
        if(m.verdict==='Favorable')str[Y.name]=Math.max(str[Y.name]||0,2);}
      else if(m.opponent===X.name){const Y=R(m.champion);if(!Y||!(Y.roles||[Y.lane]).includes(L))return;
        if(m.verdict==='Favorable')cnt[Y.name]=Math.max(cnt[Y.name]||0,2);
        if(m.verdict==='Hard'||m.verdict==='Unfavorable')str[Y.name]=Math.max(str[Y.name]||0,sev[m.verdict]);}
    });
    const tierW={'S+':6,S:5,A:4,B:3,C:2,D:1},tw=n=>{const y=R(n);return y?(tierW[(y.laneTiers&&y.laneTiers[L])||y.tier]||0):0};const pack=o=>Object.keys(o).sort((a,b)=>o[b]-o[a]||((ix[a]??1e9)-(ix[b]??1e9))||tw(b)-tw(a)||a.localeCompare(b)).map(n=>({c:R(n),s:o[n]}));
    by[L]={counters:pack(cnt),strong:pack(str)};
  });
  return by;
}
window.WRC4.laneCM=laneCM;window.WRC4.itemRow=function(i){return itemRow(i)};
function tCounters(c,d){
  let o=h('الكونترات والمواجهات','Counters & matchups');
  o+=`<p class="muted small">${A()?'الكونترات والأبطال اللي البطل قوي ضدهم مرتبين حسب نفس اللين فقط: كل بطل مذكور بيلعب هذا اللين فعلًا. الأولوية للأخطر.':'Counters and favorable targets are listed per lane, and only champions who also play that same lane. Sorted by severity.'}</p>`;
  const by=laneCM(c);let any=false;
  Object.keys(by).forEach(L=>{
    const b=by[L];if(!b.counters.length&&!b.strong.length)return;any=true;
    const chip=e=>`<span class="chip">${img(e.c)}${esc(displayName(e.c))} <b dir="ltr">${e.s>=3?'●●●':e.s===2?'●●':'●'}</b></span>`;
    o+=`<div class="lane-block"><h4>${esc(laneName(L))}</h4>`;
    o+=`<h5>${A()?'الكونترات عليه (':'Counters to '+esc(displayName(c))+' ('}${b.counters.length})</h5><div class="chips">${b.counters.map(chip).join('')||'<span class="muted">—</span>'}</div>`;
    o+=`<h5>${A()?'قوي ضدهم (':'Strong against ('}${b.strong.length})</h5><div class="chips">${b.strong.map(chip).join('')||'<span class="muted">—</span>'}</div></div>`;
  });
  if(!any)o+=`<div class="notice">${A()?'لا توجد مواجهات موثقة لهذا البطل. لن يتم اختراع كونترات.':'No documented matchups.'}</div>`;
  return o;
}
function tSynergy(c,d){
  let o=h('الانسجام مع الأبطال','Synergy');
  const seen={};const rows=[];
  (d.wall||[]).forEach(w=>(w.items||[]).forEach(e=>{const t=(e.label||'').split(' ')[0];if(t==='Ideal'||t==='Strong'){const key=e.slug;if(!seen[key]){seen[key]=1;rows.push({e,t,lane:w.lane})}}}));
  if(!rows.length)return o+`<div class="notice">${A()?'لا توجد علاقات انسجام موثقة لهذا البطل — '+NOREC+'.':'No documented synergies.'}</div>`;
  ['Ideal','Strong'].forEach(t=>{const r=rows.filter(x=>x.t===t);if(!r.length)return;o+=`<h4>${esc(tierAr[t]||t)} (${r.length})</h4><div class="cm-list">${r.map(x=>{const oc=champBySlug(x.e.slug);return `<details class="cm"><summary>${oc?img(oc):''}<span class="who">${esc(oc?displayName(oc):x.e.name)}${A()&&oc?` <small class="en-name" dir="ltr">${esc(x.e.name)}</small>`:''}</span>${x.lane?`<span class="tag">${esc(laneName(x.lane))}</span>`:''}${oc?`<button class="btn tiny" data-go-champ="${esc(x.e.slug)}">${A()?'فتح':'Open'}</button>`:''}</summary>${x.e.desc?`<p>${tx(x.e.desc)}</p>`:`<small class="muted">${A()?'البيانات تذكر التصنيف فقط بدون شرح':'Tier only on source'}</small>`}</details>`}).join('')}</div>`});
  return o;
}
function tStats(c,d){
  let o=h('الإحصائيات','Stats');const s=c.stats;
  if(s){o+=`<div class="stats-grid"><div><b>${fmt(s.winRate)}%</b><small>${tr('winRate')}${s.winRank?` · #${s.winRank}`:''}${s.winTrend?` · ${esc(s.winTrend)}`:''}</small></div><div><b>${fmt(s.pickRate)}%</b><small>${tr('pickRate')}${s.pickRank?` · #${s.pickRank}`:''}</small></div><div><b>${fmt(s.banRate)}%</b><small>${tr('banRate')}${s.banRank?` · #${s.banRank}`:''}</small></div></div><small class="muted">${esc(s.scope)} · ${A()?'الإصدار الحالي، التقط بتاريخ':'current, captured'} ${esc(s.capturedAt)}</small>`}
  else o+=`<div class="notice">${A()?NOREC+' (لم تظهر الإحصائيات في البيانات).':'Not on source page.'}</div>`;
  if((c.statsHistory||[]).length)o+=`<h4>${A()?'إحصائيات قديمة محفوظة (منفصلة عن الحالية)':'Previous stats (kept separately)'}</h4>${c.statsHistory.map(x=>`<div class="data-row"><span>${A()?'فوز':'Win'} ${fmt(x.winRate)}% · ${A()?'اختيار':'Pick'} ${fmt(x.pickRate)}% · ${A()?'حظر':'Ban'} ${fmt(x.banRate)}%</span><small class="muted">${esc(x.source||'')} · patch ${esc(x.patch||'')}</small></div>`).join('')}`;
  if(d.levelStats&&d.levelStats.length){const hd=d.levelStats[0];const names={'Lvl':A()?'المستوى':'Lvl','HP':A()?'الصحة':'HP','AD':A()?'قوة الهجوم':'AD','Armor':A()?'الدرع':'Armor','MR':A()?'م.سحر':'MR','HP regen':A()?'تجدد الصحة':'HP regen'};
    o+=h('الإحصائيات الأساسية لكل مستوى','Base stats per level')+`<div class="tablewrap"><table class="mini-table lv"><tr>${hd.map(x=>`<th>${esc(names[x]||x)}</th>`).join('')}</tr>${d.levelStats.slice(1).map(r=>`<tr>${r.map(x=>`<td dir="ltr">${esc(x)}</td>`).join('')}</tr>`).join('')}</table></div>`;
    if(d.move)o+=`<small>${A()?'سرعة الحركة':'Move speed'} ${d.move} · ${A()?'مدى الهجوم':'Attack range'} ${d.range}</small>`}
  else o+=h('الإحصائيات الأساسية لكل مستوى','Base stats')+missing();
  if((d.balance||[]).length)o+=h('سجل التعديلات (Buffs / Nerfs)','Balance history')+d.balance.slice(0,6).map(b=>`<div class="data-row"><b dir="ltr">${esc(b.patch)} · ${esc(b.date)}</b> <span class="tag">${esc(b.kind)}</span><small dir="ltr" lang="en">${esc(b.text)}</small></div>`).join('');
  return o;
}
function tTips(c,d){
  let o=h('نصائح اللعب','Tips');
  o+=`<h4>${A()?'نصائح ميكانيكية':'Mechanical tips'}</h4>${bullets(d.tips)||missing()}`;
  o+=`<h4>${A()?'أخطاء شائعة':'Common mistakes'}</h4>${bullets(d.mistakes)||missing()}`;
  if((d.interactions||[]).length)o+=`<h4>${A()?'تفاعلات مهمة':'Notable interactions'}</h4>${bullets(d.interactions)}`;
  if((d.faq||[]).length)o+=h('أسئلة شائعة','FAQ')+d.faq.map(q=>`<details class="cm"><summary>${tx(q.q)}</summary><p>${tx(q.a)}</p></details>`).join('');
  const ex=(d.counters&&d.counters.extra)||{};
  Object.keys(ex).forEach(k=>{o+=`<h4>${esc(({'How to counter this champion':A()?'كيف تواجه هذا البطل':k,'Counter archetypes':A()?'أنماط الأبطال التي تواجهه':k,'Priority matchups':A()?'مواجهات ذات أولوية':k,'Common mistakes against him':A()?'أخطاء شائعة عند مواجهته':k})[k]||k)}</h4><p>${tx(ex[k])}</p>`});
  return o;
}
const RLABEL=[['general','القوة العامة','General power','tier + win rate'],['early','بداية المباراة','Early game','source power grid'],['mid','منتصف المباراة','Mid game','source power grid'],['late','نهاية المباراة','Late game','source power grid'],['ease','سهولة الاستخدام','Ease of use','source combo difficulty'],['carry','القدرة على حمل المباراة','Carry potential','estimate'],['impact','التأثير في الفريق','Team impact','estimate'],['engage','بدء الاشتباكات','Engage','estimate'],['protect','حماية الفريق','Protect team','estimate'],['duel','قوة المواجهات الفردية','1v1 strength','estimate'],['teamfight','التأثير في المعارك الجماعية','Teamfight impact','estimate'],['cc','التحكم الجماعي','Crowd control','estimate']];
function tRatings(c,d){
  const r=c.ratings;if(!r)return h('التقييمات','Ratings')+missing();
  let o=h('تقييمات القوة من 10','Power ratings /10');
  o+=`<div class="ratings">${RLABEL.map(([k,a,e,b])=>`<div class="rrow"><span>${A()?a:e}</span>${stars(r[k])}<small class="basis ${b==='estimate'?'est':'doc'}">${b==='estimate'?(A()?'تقدير':'estimate'):(A()?'مبني على إحصاءات':'stats-based')}</small></div>`).join('')}</div>`;
  o+=`<h4>${A()?'التقييم حسب المسار (من تصنيف Tier)':'By lane (tier)'}</h4><div class="ratings">${LANES.map(l=>`<div class="rrow"><span>${esc(laneName(l))}</span>${stars((r.lanes||{})[l])}<small class="basis doc">${(c.laneTiers||{})[l]?'Tier '+esc(c.laneTiers[l]):(A()?'لا يلعب هذا المسار / بلا بيانات':'no data')}</small></div>`).join('')}</div>`;
  o+=`<div class="notice">${A()?`<b>كيف حُسبت؟</b> التقييمات المكتوب عليها «مبني على إحصاءات» محسوبة من الإحصاءات المضمنة فقط: Tier كل مسار، نسبة الفوز في Master+ (Wild Rift CN)، ومؤشرات القوة في البداية/المنتصف/النهاية، وصعوبة الكومبو. أما التقييمات المكتوب عليها «تقدير» فهي تحليل تقديري بالخوارزمية من تصنيف البطل (${esc(klassLabel(c))}) والكلمات المفتاحية في وصفه، وليست إحصائية فعلية. الإصدار المعتمد: Patch ${esc(DB.source.patch)} · التاريخ: ${esc(DB.source.updated)}.`:`Source-based ratings use bundled tier/win-rate/power-grid data. Ratings marked estimate are algorithmic from class and text keywords. Patch ${esc(DB.source.patch)}, ${esc(DB.source.updated)}.`}</div>`;
  return o;
}

/* ---------------- library: search, filters, sort ---------------- */
const ITEMS=DB.items||[];
const blobCache={};
function blobOf(c){
  if(blobCache[c.id])return blobCache[c.id];
  const g=GUIDE_DATA[c.name]||{};
  const its=new Set();(g.builds||[]).forEach(b=>(b.items||[]).forEach(i=>its.add(i)));
  let t=[c.name,nameAr[c.name]||'',c.slug,c.klass||'',AR.CLASS_AR[c.klass]||'',g.archetype||''];
  its.forEach(i=>{t.push(i);if(AR.ITEM_AR[i])t.push(AR.ITEM_AR[i])});
  return blobCache[c.id]=normalizeSearch(t.join(' | '));
}
window.championMatches=function(c,q){
  const n=normalizeSearch(q);if(!n)return true;
  return blobOf(c).includes(n);
};
const F={klass:'',dmg:'',diff:'',sort:'name'};
function injectControls(){
  const row=document.querySelector('#champions .row');if(!row||$('champKlass'))return;
  const kl=['tank','bruiser','assassin','mage','marksman','enchanter','support'];
  row.insertAdjacentHTML('afterend',`<div class="row filters" id="champFilters"><select id="champKlass"><option value="">${'كل التصنيفات'}</option>${kl.map(k=>`<option value="${k}">${AR.CLASS_AR[k]}</option>`).join('')}</select><select id="champDmg"><option value="">كل أنواع الضرر</option><option value="AD">ضرر جسدي</option><option value="AP">ضرر سحري</option><option value="MIX">مختلط</option></select><select id="champDiff"><option value="">كل مستويات الصعوبة</option><option value="easy">سهل</option><option value="mid">متوسط</option><option value="hard">صعب</option></select><select id="champSort"><option value="name">ترتيب أبجدي</option><option value="power">الأقوى (التقييم العام)</option><option value="win">الأعلى نسبة فوز</option><option value="pick">الأعلى اختيارًا</option><option value="ban">الأعلى حظرًا</option><option value="ease">الأسهل استخدامًا</option></select><button class="btn" id="champClear" type="button">مسح الفلاتر</button><span class="tag" id="champCount2"></span></div>`);
  ['champKlass','champDmg','champDiff','champSort'].forEach(id=>$(id).onchange=()=>{F.klass=$('champKlass').value;F.dmg=$('champDmg').value;F.diff=$('champDiff').value;F.sort=$('champSort').value;renderLibrary()});
  $('champClear').onclick=()=>{$('champSearch').value='';$('champRole').value='';['champKlass','champDmg','champDiff'].forEach(i=>$(i).value='');$('champSort').value='name';F.klass=F.dmg=F.diff='';F.sort='name';renderLibrary()};
  let tmr;$('champSearch').oninput=()=>{clearTimeout(tmr);tmr=setTimeout(renderLibrary,80)};
}
window.renderLibrary=function(){
  injectControls();
  const q=$('champSearch').value,r=$('champRole').value;
  let a=CHAMPS.filter(c=>championMatches(c,q)&&(!r||c.roles.includes(r))&&(!F.klass||c.klass===F.klass)&&(!F.dmg||c.dmgType===F.dmg)&&(!F.diff||(c.difficulty!=null&&(F.diff==='easy'?c.difficulty>=7:F.diff==='mid'?c.difficulty>=5&&c.difficulty<7:c.difficulty<5))));
  const S=c=>c.stats||{};
  const sorters={name:(x,y)=>displayName(x).localeCompare(displayName(y),'ar'),power:(x,y)=>((y.ratings||{}).general||0)-((x.ratings||{}).general||0),win:(x,y)=>(S(y).winRate||0)-(S(x).winRate||0),pick:(x,y)=>(S(y).pickRate||0)-(S(x).pickRate||0),ban:(x,y)=>(S(y).banRate||0)-(S(x).banRate||0),ease:(x,y)=>((y.difficulty)||0)-((x.difficulty)||0)};
  a.sort(sorters[F.sort]||sorters.name);
  $('champLibrary').innerHTML=a.map(c=>`<button class="champ" data-champ="${c.id}" data-action="detail">${img(c)}<span style="min-width:0"><b>${esc(displayName(c))}</b><small>${A()?'':esc(c.name)+' · '}${(c.roles||[c.lane]).map(laneName).map(esc).join(' / ')} · ${esc(c.tier||'—')}${F.sort!=='name'?' · '+esc(F.sort==='power'?'قوة '+((c.ratings||{}).general??'—'):F.sort==='win'?'فوز '+fmt(S(c).winRate)+'%':F.sort==='pick'?'اختيار '+fmt(S(c).pickRate)+'%':F.sort==='ban'?'حظر '+fmt(S(c).banRate)+'%':'سهولة '+(c.difficulty??'—')):''}</small></span></button>`).join('')||`<div class="empty">${A()?'لا يوجد بطل مطابق. جرّب مسح الفلاتر.':'No champions found.'}</div>`;
  const cc=$('champCount2');if(cc)cc.textContent=a.length+' / '+CHAMPS.length;
};

/* ---------------- items ---------------- */
const ICAT={};
window.renderItems=function(){
  const qraw=$('itemSearch')?.value||'',q=normalizeSearch(qraw);
  const fc=window.__itemCat||'';
  const cats=[...new Set(ITEMS.map(x=>x.category).filter(Boolean))].sort();
  const a=ITEMS.filter(x=>{
    if(fc&&x.category!==fc)return false;
    if(!q)return true;
    const hay=normalizeSearch([x.name,x.nameAr||'',x.category||'',ITEM_CATEGORY_AR[x.category]||'',(x.tags||[]).join(' '),(x.tags||[]).map(t=>ITEM_TAG_AR[t]||'').join(' '),x.description||'',(x.usedBy||[]).join(' '),(x.usedBy||[]).map(n=>nameAr[n]||'').join(' ')].join(' | '));
    return hay.includes(q);
  });
  const bar=$('itemCatBar');
  if(!bar&&$('itemCount')){$('itemCount').insertAdjacentHTML('afterend','<div class="chips" id="itemCatBar" style="margin-top:8px"></div>')}
  if($('itemCatBar')){$('itemCatBar').innerHTML=`<button class="chip ${!fc?'on':''}" data-icat="">${A()?'الكل':'All'}</button>`+cats.map(k=>`<button class="chip ${fc===k?'on':''}" data-icat="${esc(k)}">${esc(A()?(ITEM_CATEGORY_AR[k]||k):k)}</button>`).join('');$('itemCatBar').onclick=e=>{const b=e.target.closest('[data-icat]');if(b){window.__itemCat=b.dataset.icat;renderItems()}}}
  $('itemCount').textContent=A()?`${a.length} من ${ITEMS.length} عنصر · القائمة الحالية: ${DB.coverage.itemsInCurrentCatalog||111}`:`${a.length} / ${ITEMS.length}`;
  $('itemLibrary').innerHTML=a.map(x=>{
    const cat=A()?(ITEM_CATEGORY_AR[x.category]||x.category||'عنصر'):(x.category||'Item');
    return `<article class="card item-card item-visual" data-item="${esc(x.name)}" tabindex="0" role="button"><div class="item-visual-head"><div class="item-art">${x.image?`<img loading="lazy" src="${esc(x.image)}" alt="${esc(x.name)}" onerror="this.remove()">`:''}<span>${ITEM_GLYPH[x.category]||'◇'}</span></div><div class="item-title"><b>${esc(A()&&x.nameAr?x.nameAr:x.name)}</b><small dir="ltr">${A()&&x.nameAr?esc(x.name):''}</small><small>${esc(cat)}</small></div></div>${x.price?`<span class="tag item-price">${x.price} ${A()?'ذهبة':'gold'}</span>`:`<span class="tag">${A()?'السعر: '+NOREC:'price n/a'}</span>`}<small class="item-tags">${(x.tags||[]).map(t=>esc(A()?(ITEM_TAG_AR[t]||''):t.replace(/-/g,' '))).filter(Boolean).join(' · ')}</small>${(x.usedBy||[]).length?`<small>${A()?'يُستخدم مع':'Used by'} ${x.usedBy.length} ${A()?'بطل':'champions'}</small>`:''}</article>`}).join('')||`<div class="empty">${A()?'لا يوجد عنصر مطابق في قاعدة البيانات المحلية.':'No matching item.'}</div>`;
  $('itemLibrary').onclick=e=>{const c=e.target.closest('[data-item]');if(c)itemModal(c.dataset.item)};
  $('itemLibrary').onkeydown=e=>{if(e.key==='Enter'){const c=e.target.closest('[data-item]');if(c)itemModal(c.dataset.item)}};
};
function itemModal(name){
  const x=ITEMS.find(i=>i.name===name);if(!x)return;
  let m=$('itemModal');if(!m){m=document.createElement('div');m.id='itemModal';m.className='modal hidden';document.body.appendChild(m)}
  const cat=A()?(ITEM_CATEGORY_AR[x.category]||x.category||'عنصر'):(x.category||'Item');
  const rel=(x.relatedItems||[]).map(n=>`<span class="chip">${itemImg(n)}${itemLabel(n)}</span>`).join('');
  m.innerHTML=`<div class="modal-card" role="dialog" aria-modal="true"><button class="btn" id="itemClose" aria-label="close">×</button><div class="row"><div class="item-art big">${x.image?`<img src="${esc(x.image)}" alt="" onerror="this.remove()">`:''}<span>${ITEM_GLYPH[x.category]||'◇'}</span></div><div><h2>${esc(A()&&x.nameAr?x.nameAr:x.name)}</h2><small dir="ltr">${esc(x.name)}</small><div><span class="tag">${esc(cat)}</span> ${x.price?`<span class="tag">${x.price} ${A()?'ذهبة':'gold'}</span>`:`<span class="tag">${A()?'السعر: '+NOREC:'price n/a'}</span>`}</div></div></div>
  <h4>${A()?'الوصف والتأثيرات ':'Description (source)'}</h4><p>${x.description?tx(x.description):NOREC}</p>
  <h4>${A()?'الوسوم والخصائص':'Tags'}</h4><p>${(x.tags||[]).map(t=>`<span class="tag">${esc(A()?(ITEM_TAG_AR[t]||t):t)}</span>`).join(' ')||NOREC}</p>
  <h4>${A()?'الأبطال المناسبون له (من البناءات الموثقة)':'Champions using it'}</h4><div class="chips">${(x.usedBy||[]).map(n=>{const c=CHAMPS.find(k=>k.name===n);return c?`<span class="chip">${img(c)}${esc(displayName(c))}</span>`:''}).join('')||`<small class="muted">${NOREC}</small>`}</div>
  <h4>${A()?'متى يُنصح بشرائه':'When to buy'}</h4><p>${(x.usefulVs||[]).length?x.usefulVs.map(w=>`<span class="tag">${sitAr(w)}</span>`).join(' '):`<span class="muted">${A()?'لا توجد حالات شراء خاصة — '+NOREC:'n/a'}</span>`}</p>
  <h4>${A()?'عناصر تُشترى معه / بدائل شائعة':'Often built with'}</h4><div class="chips">${rel||`<small class="muted">${NOREC}</small>`}</div>
  </div>`;
  m.classList.remove('hidden');
  const close=()=>m.classList.add('hidden');$('itemClose').onclick=close;m.onclick=e=>{if(e.target===m)close()};
}

/* ---------------- draft composition analysis ---------------- */
function teamOf(side){return Object.entries(draft[side]||{}).map(([role,id])=>({role,c:CHAMPS.find(x=>x.id===id)})).filter(x=>x.c)}
function avg(a,f){const v=a.map(f).filter(x=>x!=null);return v.length?v.reduce((s,x)=>s+x,0)/v.length:null}
function verdictBetween(a,b){ // from a's perspective: a favored?
  const m=(DB.matchups||[]).find(x=>x.champion===a.name&&x.opponent===b.name);
  if(m)return {Hard:-2,Unfavorable:-1,Skill:0,Favorable:1}[m.verdict];
  const n=(DB.matchups||[]).find(x=>x.champion===b.name&&x.opponent===a.name);
  if(n)return {Hard:2,Unfavorable:1,Skill:0,Favorable:-1}[n.verdict];
  return null;
}
function teamProfile(t){
  const cs=t.map(x=>x.c),n=cs.length;
  const ad=cs.filter(c=>c.dmgType==='AD').length,ap=cs.filter(c=>c.dmgType==='AP').length,mx=cs.filter(c=>c.dmgType==='MIX').length;
  const tanks=cs.filter(c=>c.klass==='tank'||(c.ratings&&c.ratings.protect>=7&&c.klass!=='mage')).length;
  const front=cs.filter(c=>['tank','bruiser'].includes(c.klass)).length;
  const R=k=>avg(cs,c=>c.ratings&&c.ratings[k]);
  const sum=k=>cs.reduce((s,c)=>s+((c.ratings&&c.ratings[k])||0),0);
  return {n,ad,ap,mx,front,tanks,engage:sum('engage'),protect:sum('protect'),cc:sum('cc'),early:R('early'),mid:R('mid'),late:R('late'),carry:sum('carry'),general:R('general'),teamfight:R('teamfight')};
}
function synergyPairs(t){
  const out=[];
  for(let i=0;i<t.length;i++)for(let j=0;j<t.length;j++){if(i===j)continue;
    const s=(DB.synergies||[]).find(x=>x.champion===t[i].c.name&&x.partner===t[j].c.name);
    if(s&&!out.find(o=>o.a===t[j].c.name&&o.b===t[i].c.name))out.push({a:t[i].c.name,b:t[j].c.name,tier:s.tier})}
  return out;
}
window.analyzeComp=function(){
  const ally=teamOf('ally'),enemy=teamOf('enemy');
  const host=$('draftResults');if(!host)return;
  let box=$('compAnalysis');if(!box){box=document.createElement('div');box.id='compAnalysis';host.parentNode.insertBefore(box,host)}
  if(!ally.length){box.innerHTML='';return}
  const P=teamProfile(ally),E=enemy.length?teamProfile(enemy):null;
  const good=[],bad=[],need=[],notes=[];
  let score=5.5;const parts=[];
  const lowData=ally.length<3;
  // roles
  const lanesFilled=ally.map(x=>x.role);const missingRoles=LANES.filter(l=>!lanesFilled.includes(l));
  ally.forEach(x=>{if(!(x.c.roles||[x.c.lane]).includes(x.role))bad.push(`${displayName(x.c)} موضوع في مسار ${AR.LANE_AR[x.role]} وليس من مساراته الموثقة (${(x.c.roles||[]).map(r=>AR.LANE_AR[r]).join('، ')})`)});
  // damage balance
  if(P.n>=2){
    const phys=P.ad+P.mx*.5,mag=P.ap+P.mx*.5;
    if(phys>0&&mag>0&&Math.min(phys,mag)/Math.max(phys,mag)>=.4){good.push('توازن جيد بين الضرر الجسدي والسحري');score+=.7}
    else if(P.n>=3){bad.push(mag===0?'كل الضرر تقريبًا جسدي، فيسهل على الخصم بناء دروع':'كل الضرر تقريبًا سحري، فيسهل على الخصم بناء مقاومة سحر');need.push(mag===0?'بطل بضرر سحري':'بطل بضرر جسدي');score-=.8}
  }
  parts.push({k:'توازن الضرر',v:`جسدي ${P.ad} · سحري ${P.ap} · مختلط ${P.mx}`});
  // frontline
  if(P.n>=3){if(P.front>=1){good.push('يوجد خط أمامي (تانك أو مقاتل)');score+=.5}else{bad.push('لا يوجد خط أمامي واضح');need.push('تانك أو مقاتل');score-=1}}
  parts.push({k:'الخط الأمامي',v:P.front+' من '+P.n});
  // engage / peel / cc
  if(P.n>=3){
    if(P.engage>=12){good.push('قدرة جيدة على بدء الاشتباكات (تقدير)');score+=.6}else{bad.push('قدرة ضعيفة على بدء الاشتباك (تقدير)');need.push('بطل يبدأ الاشتباك');score-=.5}
    if(P.protect>=10){good.push('حماية كافية للكاري (تقدير)');score+=.4}else if(P.n>=4){bad.push('حماية ضعيفة لحامل الضرر (تقدير)');need.push('بطل يحمي الفريق');score-=.4}
    if(P.cc>=18){good.push('تحكم جماعي جيد (تقدير)');score+=.4}else if(P.n>=4){bad.push('تحكم جماعي قليل (تقدير)');need.push('تحكم جماعي');score-=.3}
  }
  parts.push({k:'بدء الاشتباك',v:P.engage.toFixed(0)});parts.push({k:'الحماية',v:P.protect.toFixed(0)});parts.push({k:'التحكم الجماعي',v:P.cc.toFixed(0)});
  // synergy
  const sp=synergyPairs(ally);sp.forEach(s=>{good.push(`انسجام ${s.tier==='Ideal'?'مثالي':'قوي'}: ${nameAr[s.a]||s.a} + ${nameAr[s.b]||s.b} `);score+=s.tier==='Ideal'?.6:.3});
  // phases
  parts.push({k:'قوة البداية/المنتصف/النهاية',v:[P.early,P.mid,P.late].map(x=>x==null?'—':(x).toFixed(1)).join(' / ')});
  if(P.early!=null&&P.late!=null&&P.n>=3){if(P.early-P.late>=1){notes.push('تشكيلتك أقوى في البداية؛ حاول إنهاء المباراة مبكرًا قبل أن يتفوق الخصم');}else if(P.late-P.early>=1){notes.push('تشكيلتك أقوى في النهاية؛ العب بأمان وركّز على المحافظة على الموارد حتى المرحلة المتأخرة')}}
  // counters vs enemy
  let cmatch=[];
  if(enemy.length){
    ally.forEach(a=>enemy.forEach(e=>{const v=verdictBetween(a.c,e.c);if(v!=null&&v!==0)cmatch.push({a:a.c,e:e.c,v,lane:a.role===e.role})}));
    const pos=cmatch.filter(x=>x.v>0).length,neg=cmatch.filter(x=>x.v<0).length;
    pos&&good.push(`لديك ${pos} مواجهة${pos>1?'ات':''} مفضلة ضد الخصم `);neg&&bad.push(`لديك ${neg} مواجهة${neg>1?'ات':''} غير مفضلة ضد الخصم `);
    score+=Math.max(-1.5,Math.min(1.5,(pos-neg)*.3));
    parts.push({k:'مواجهات موثقة مع الخصم',v:`${pos} لصالحك · ${neg} ضدك`});
  }
  score=Math.max(1,Math.min(10,Math.round(score*2)/2));
  const conf=P.n>=5?'عالية نسبيًا':P.n>=3?'متوسطة':'منخفضة';
  // best additions
  let adds='';
  const role=$('draftRole')?$('draftRole').value:null;
  if(lastResults&&lastResults.length){adds=`<h4>أفضل الاختيارات المقترحة لمسار ${esc(AR.LANE_AR[role]||role||'')}</h4><ol class="adds">${lastResults.slice(0,12).map(x=>`<li><span class="addwho">${img(x.c)}<b>${esc(displayName(x.c))}</b><span class="tag">${x.score}</span></span><small>${esc(x.reasons.slice(0,3).join(' · '))}</small></li>`).join('')}</ol>`}
  box.innerHTML=`<div class="card comp"><div class="row between"><h3>تحليل التشكيلة</h3><span class="tag score-tag">${score}/10</span></div>
  <p class="muted small">درجة ثقة التحليل: <b>${conf}</b> (${P.n}/5 اختيارات في فريقك${enemy.length?` · ${enemy.length}/5 عند الخصم`:''}). ${lowData?'البيانات غير كافية للحكم النهائي، التوصيات استرشادية.':''} بيانات Patch ${esc(DB.source.patch)}؛ البنود المكتوب بجانبها «تقدير» تحليل خوارزمي من تصنيف الأبطال وليست إحصائية.</p>
  <div class="comp-cols"><div><h4>نقاط القوة</h4>${good.length?`<ul>${good.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'<small class="muted">لا نقاط قوة مؤكدة بعد</small>'}</div><div><h4>نقاط الضعف والمشكلات</h4>${bad.length?`<ul>${bad.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'<small class="muted">لا مشكلات ظاهرة في البيانات المتاحة</small>'}</div></div>
  ${need.length?`<h4>احتياجات الفريق</h4><p>${[...new Set(need)].map(x=>`<span class="tag">${esc(x)}</span>`).join(' ')}</p>`:''}
  ${missingRoles.length?`<p class="small">المسارات الناقصة: ${missingRoles.map(r=>AR.LANE_AR[r]).join('، ')}</p>`:''}
  <div class="data-grid">${parts.map(p=>`<div><small>${esc(p.k)}</small><b>${esc(p.v)}</b></div>`).join('')}</div>
  ${notes.length?`<p>${notes.map(esc).join('<br>')}</p>`:''}
  ${E?`<h4>الخصم</h4><p class="small">ضرر جسدي ${E.ad} · سحري ${E.ap} · مختلط ${E.mx} · خط أمامي ${E.front}.${E.front===0?' الخصم بلا خط أمامي واضح: ضغط الضرر والكايتنج مناسب.':''}${E.ad+E.mx*.5>=E.n*.7?' ضرر الخصم جسدي غالبًا، فكّر في عناصر مقاومة الدروع.':E.ap+E.mx*.5>=E.n*.7?' ضرر الخصم سحري غالبًا، فكّر في عناصر مقاومة السحر.':''}</p>`:'<p class="small muted">أضف أبطال الخصم لتحليل أفضل طريقة لمواجهته.</p>'}
  ${adds}</div>`;
}
function hookDraft(){const b=$('analyzeDraft');if(!b)return;if(!$('draftEngine')){b.insertAdjacentHTML('beforebegin','<label class="engine-sel"><small>محرك الحساب</small><select id="draftEngine"><option value="meta">Meta (يشمل Tier)</option><option value="off">Off-meta (مواجهة وانسجام واحتياج فقط)</option></select></label>');$('draftEngine').onchange=()=>{window.__offMeta=$('draftEngine').value==='off';if($('draftResults').children.length)b.onclick()}}if($('draftRole'))$('draftRole').addEventListener('change',()=>{if($('draftResults').querySelector('.score-breakdown'))b.onclick()});b.onclick=()=>{scoreDraft();try{analyzeComp()}catch(e){console.error(e)}}}

/* ---------------- developer info + db health ---------------- */
function devPanel(){
  const dev=$('developer');if(!dev||$('devInfo4'))return;
  const cv=DB.coverage||{};
  const html=`<div class="card" id="devInfo4"><h3>معلومات التطبيق</h3><div class="data-grid"><div><small>اسم التطبيق</small><b>Rift Mate</b></div><div><small>المطوّر</small><b>Mazen Mohamed</b></div><div><small>إصدار التطبيق</small><b>${esc(DB.appVersion||'4.0.0')}</b></div><div><small>إصدار قاعدة البيانات</small><b>${esc(DB.version||'4.0.0')}</b></div><div><small>تاريخ آخر تحديث</small><b>${esc(DB.source.updated)}</b></div><div><small>إصدار اللعبة في البيانات</small><b>Patch ${esc(DB.source.patch)}</b></div></div>
    <p><b>طبيعة البيانات غير الموثقة:</b> أي معلومة لم تظهر في البيانات مكتوب عندها «${NOREC}» ولا يتم اختراعها. التقييمات المكتوب عليها «تقدير» هي تحليل خوارزمي وليست إحصائيات. إحصائيات الفوز هي Master+ على سيرفر Wild Rift الصيني (CN) كما ينشرها المصدر.</p>
  <p><b>التغطية الحالية:</b> ${cv.champions} بطل (${cv.championsFullGuide} بدليل كامل · ${cv.championsPartial} ناقص جزئيًا) · ${cv.items} عنصر · ${cv.matchups} مواجهة · ${cv.synergies} علاقة انسجام · ${cv.guidePagesFetched} صفحة مصدر مجموعة من ${cv.guidePagesAdvertised} معلن عنها.</p>
  <p class="muted small">معلومات التواصل: كما في بطاقة المطوّر أعلاه (حساب إنستغرام الموجود في المشروع الأصلي). لا تُضاف بيانات تواصل أخرى.</p></div>`;
  dev.insertAdjacentHTML('beforeend',html);
  document.querySelectorAll('#developer .developer-bottom b').forEach(b=>{if(/3\.5\.0/.test(b.textContent))b.textContent=(DB.appVersion||'4.0.0')+' · DB '+(DB.version||'4.0.0')});
}
const _health=window.renderDbHealth;
window.renderDbHealth=function(){
  try{_health()}catch(e){}
  const p=$('dbHealth');if(!p||!A())return;const cv=DB.coverage||{};
  p.insertAdjacentHTML('beforeend',`<br>أبطال بدليل كامل: ${cv.championsFullGuide} · ناقصون: ${cv.championsPartial} · عناصر بسعر: ${cv.itemsWithPrice}/${cv.items} · نسخة قاعدة البيانات ${esc(DB.version||'')}`);
};

/* ---------------- boot ---------------- */
function boot(){
  hookDraft();renderLibrary();renderItems();devPanel();
  const hc=document.querySelector('#champions .sub');if(hc&&A())hc.textContent=`${CHAMPS.length} بطلًا من قائمة الباتش ${DB.source.patch}، مع صفحة تفصيلية لكل بطل (مهارات، بناءات، رونات، كونترات، انسجام، إحصائيات، نصائح، تقييمات).`;
  try{renderDbHealth()}catch(e){}
  const _tr=window.translate;
  window.translate=function(){_tr.apply(this,arguments);try{blobCache&&0;renderLibrary();renderItems();devPanel()}catch(e){console.error(e)}};
}
try{const ml=DB.metaByLane||{};CHAMPS.forEach(c=>{/* v4.0.13: المسار الأساسي الموثق فقط، بدون إضافة مسارات من الماتش أب/البيلدات */const s=new Set(c.roles&&c.roles.length?c.roles:[c.lane]);Object.keys(ml).forEach(L=>{if((ml[L]||[]).some(x=>x.name===c.name))s.add(L)});c.roles=[...s].filter(Boolean)})}catch(e){console.error(e)}
const _sd0=window.scoreDraft;
function enemyProfile(){
  const en=Object.values(draft.enemy||{}).map(id=>CHAMPS.find(x=>x.id===id)).filter(Boolean);
  const n=en.length,ad=en.reduce((a,c)=>a+((c.dmgType||c.damage)==='AD'?1:(c.dmgType||c.damage)==='MIX'?.5:0),0),ap=en.reduce((a,c)=>a+((c.dmgType||c.damage)==='AP'?1:(c.dmgType||c.damage)==='MIX'?.5:0),0);
  const k=x=>en.filter(c=>c.klass===x).length;
  const tanks=k('tank'),assassins=k('assassin'),bruisers=k('bruiser'),mages=k('mage');
  return{n,ad,ap,tanks,assassins,bruisers,mages,adShare:n?ad/n:0,apShare:n?ap/n:0};
}
function whenMatches(w,p){
  if(!p.n)return 0;
  const m=[];
  if(/2\+ enemy tanks/.test(w)&&p.tanks>=2)m.push(1);else if(/2\+ enemy tanks/.test(w))return -1;
  if(/Mostly physical/.test(w)){if(p.n>=3&&p.adShare>=.65)m.push(1);else return -1;}
  if(/Mostly magic/.test(w)){if(p.n>=3&&p.apShare>=.65)m.push(1);else return -1;}
  if(/2\+ dive threats/.test(w)){if(p.assassins+p.bruisers>=2)m.push(1);else return -1;}
  if(/2\+ burst champions/.test(w)){if(p.assassins+p.mages>=2)m.push(1);else return -1;}
  if(/2\+ duelists/.test(w)){if(p.bruisers>=2)m.push(1);else return -1;}
  if(/(hard engages|crowd-control chains|poke|allied|No enemy tank)/.test(w))return -1; /* شروط خاصة بفريقك أو بيانات غير متاحة عن الخصم */
  return m.length;
}
function pickAdaptive(c,role,p){
  const g=(DB.guides||{})[c.name];const bs=((g&&g.builds)||[]).filter(b=>!b.lane||b.lane===role);
  if(!bs.length)return null;let best=null,bs0=-1;
  bs.forEach(b=>{const s=whenMatches(b.when||'',p);const sc=/Balanced/.test(b.when||'')?0.1:s;if(sc>bs0){bs0=sc;best=b;}});
  return{b:best,matched:bs0>=1};
}
function extraItems(c,b,p){
  const need=[];if(p.assassins>=2&&p.ad>=2)need.push('AD burst');if(p.ap>=2&&(p.mages+p.assassins)>=2)need.push('AP burst');if(p.tanks>=2)need.push('2+ tanks');
  const have=new Set(b.items||[]);const out=[];
  (DB.items||[]).forEach(it=>{const u=[].concat(it.usefulVs||[]).join(' ');if(need.some(x=>u.includes(x))&&!have.has(it.name)&&(!it.usedBy||!it.usedBy.length||it.usedBy.includes(c.name)))out.push(it);});
  return out.slice(0,2);
}
function decorateDraft(){
  const role=document.getElementById('draftRole').value,p=enemyProfile();
  document.querySelectorAll('#draftResults .result').forEach(card=>{
    if(card.querySelector('.draft-build'))return;
    const m=/chooseRecommended\((\d+)\)/.exec(card.innerHTML);if(!m)return;
    const c=CHAMPS.find(x=>x.id==+m[1]);if(!c)return;
    const r=pickAdaptive(c,role,p);const g=(DB.guides||{})[c.name];
    const div=document.createElement('div');div.className='draft-build';
    if(!r||!r.b){div.innerHTML=`<small class="muted">${A()?'لا تتوفر بيانات موثقة حاليًا':'No documented data available'}</small>`;}
    else{
      const ex=extraItems(c,r.b,p);
      const why=p.n?(A()?`تحليل فريق الخصم (${p.n} أبطال): ضرر فيزيائي ${p.ad} / سحري ${p.ap}، تانكات ${p.tanks}، اغتيال ${p.assassins}، مقاتلين ${p.bruisers}، سحرة ${p.mages}.`:`Enemy comp (${p.n}): physical ${p.ad} / magic ${p.ap}, tanks ${p.tanks}, assassins ${p.assassins}, bruisers ${p.bruisers}, mages ${p.mages}.`):(A()?'لسه مفيش أبطال للخصم: البيلد الأساسي.':'No enemy picks yet: default build.');
      const rn=(g&&g.runes&&g.runes.length)?`<div class="small"><b>${A()?'الرونز الموثقة':'Documented runes'}:</b> ${g.runes.map(x=>esc(x)).join(' · ')}</div>`:'';
      div.innerHTML=`<h5>${A()?'البيلد المختار حسب فريق الخصم':'Build chosen for the enemy comp'} · ${esc(laneName(role))}</h5><div class="small muted">${esc(why)} ${r.matched?(A()?'اتطابق شرط: ':'Matched: ')+esc(r.b.when||''):(A()?'مفيش إشارة قوية، البيلد المتوازن.':'No strong signal: balanced build.')}</div><div class="small"><b>${esc(r.b.name||'')}</b></div>${itemRow(r.b.items)}`+(ex.length?`<div class="small"><b>${A()?'بنود مضادة مقترحة:':'Counter items:'}</b> ${ex.map(i=>esc(A()&&i.nameAr?i.nameAr:i.name)).join(' · ')}</div>`:'')+rn;
    }
    card.insertBefore(div,card.querySelector('button.btn.primary'));
  });
}
window.scoreDraft=function(){_sd0.apply(this,arguments);try{decorateDraft()}catch(e){console.error(e)}};

boot();
// a simple self-check hook used by the build test harness
window.WRC4_READY=true;
})();

;(function(){try{var e=document.getElementById('statsLive');if(e)e.textContent=CHAMPS.filter(function(c){return c.stats&&typeof c.stats==='object'&&c.stats.winRate!=null}).length+' / '+CHAMPS.length}catch(x){}})();
