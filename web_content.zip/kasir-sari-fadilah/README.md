# Kasir Sari Fadilah

Aplikasi kasir Android offline dengan tampilan modern bernuansa cafe premium.

## Penyimpanan data
- Android: SQLite lokal di penyimpanan privat aplikasi.
- Browser preview: localStorage sebagai fallback.
- PDF: struk setiap transaksi dan laporan penjualan dapat diekspor.
- Backup: ekspor seluruh produk dan transaksi ke file JSON. Simpan file backup di tempat aman.

**Catatan:** PDF adalah dokumen laporan/struk, bukan database utama. Database transaksi yang dapat diperbarui adalah SQLite. Ekspor JSON disediakan untuk backup dan pemindahan data.

## Fitur
- Dashboard ringkasan omzet dan transaksi
- Kasir, keranjang, pembayaran, dan kembalian
- Pengurangan stok otomatis saat checkout
- Manajemen tambah produk
- Riwayat transaksi
- Ekspor struk dan laporan PDF
- Backup data JSON
- Offline, tanpa akun dan server

## Membuat APK tanpa GitHub
Dibutuhkan komputer Windows/Mac/Linux dengan Node.js 20+, Java 21, dan Android Studio/Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK debug biasanya tersedia di `android/app/build/outputs/apk/debug/app-debug.apk`.

Untuk memperbarui setelah mengubah kode:
```bash
npm run android:sync
```

## Penting
- Ini source project Android, bukan APK yang sudah dikompilasi.
- Jangan hapus data aplikasi atau uninstall sebelum membuat backup JSON; database lokal dapat ikut terhapus.
- PDF yang diekspor berada di folder unduhan/perangkat sesuai pengaturan browser atau Android.
- Fitur printer Bluetooth, edit/hapus produk, login kasir, sinkronisasi cloud, dan restore backup belum termasuk versi ini.
