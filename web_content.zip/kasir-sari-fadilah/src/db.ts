import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';

export type Product = { id:number; name:string; category:string; price:number; stock:number; sku:string };
export type SaleItem = { productId:number; name:string; price:number; qty:number };
export type Sale = { id:number; createdAt:string; total:number; paid:number; change:number; items:SaleItem[] };
const KEY = 'ksf-local-v1';
const sqlite = new SQLiteConnection(CapacitorSQLite);
let db:any = null;
let mode:'sqlite'|'browser' = 'browser';

const starter:Product[] = [
 {id:1,name:'Kopi Susu Sari',category:'Kopi',price:22000,stock:35,sku:'KOP-001'},
 {id:2,name:'Americano',category:'Kopi',price:18000,stock:28,sku:'KOP-002'},
 {id:3,name:'Cappuccino',category:'Kopi',price:24000,stock:24,sku:'KOP-003'},
 {id:4,name:'Matcha Latte',category:'Non Kopi',price:26000,stock:18,sku:'NKO-001'},
 {id:5,name:'Chocolate',category:'Non Kopi',price:23000,stock:20,sku:'NKO-002'},
 {id:6,name:'Croissant Butter',category:'Pastry',price:19000,stock:15,sku:'PAS-001'}
];
const load = () => {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null') || {products:starter,sales:[]}; }
  catch { return {products:starter,sales:[]}; }
};
const save = (data:any) => localStorage.setItem(KEY, JSON.stringify(data));

export async function initDB() {
  if (Capacitor.isNativePlatform()) {
    try {
      db = await sqlite.createConnection('kasir_sari_fadilah', false, 'no-encryption', 1, false);
      await db.open();
      await db.execute(`CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, price REAL NOT NULL, stock INTEGER NOT NULL, sku TEXT);
      CREATE TABLE IF NOT EXISTS sales (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, total REAL NOT NULL, paid REAL NOT NULL, change_amount REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS sale_items (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER, name TEXT NOT NULL, price REAL NOT NULL, qty INTEGER NOT NULL);`);
      const count = await db.query('SELECT COUNT(*) as n FROM products');
      if (Number(count.values?.[0]?.n || 0) === 0) {
        for (const p of starter) await db.run('INSERT INTO products (name,category,price,stock,sku) VALUES (?,?,?,?,?)',[p.name,p.category,p.price,p.stock,p.sku]);
      }
      mode = 'sqlite'; return;
    } catch (e) { console.warn('SQLite unavailable; browser storage fallback', e); }
  }
  mode = 'browser';
  if (!localStorage.getItem(KEY)) save({products:starter,sales:[]});
}
export const storageMode = () => mode;
export async function getProducts():Promise<Product[]> {
  if (mode==='sqlite') { const r=await db.query('SELECT * FROM products ORDER BY name'); return (r.values||[]).map((p:any)=>({id:p.id,name:p.name,category:p.category,price:p.price,stock:p.stock,sku:p.sku})); }
  return load().products;
}
export async function addProduct(p:Omit<Product,'id'>) {
  if (mode==='sqlite') await db.run('INSERT INTO products (name,category,price,stock,sku) VALUES (?,?,?,?,?)',[p.name,p.category,p.price,p.stock,p.sku]);
  else { const d=load(); d.products.push({...p,id:Math.max(0,...d.products.map((x:Product)=>x.id))+1}); save(d); }
}
export async function checkout(items:SaleItem[], paid:number):Promise<Sale> {
  const total=items.reduce((s,i)=>s+i.price*i.qty,0);
  if (!items.length || paid<total) throw new Error('Pembayaran belum mencukupi.');
  const createdAt=new Date().toISOString();
  if (mode==='sqlite') {
    await db.execute('BEGIN TRANSACTION');
    try {
      for (const i of items) {
        const r=await db.query('SELECT stock FROM products WHERE id=?',[i.productId]);
        if (!r.values?.length || Number(r.values[0].stock)<i.qty) throw new Error(`Stok ${i.name} tidak mencukupi.`);
        await db.run('UPDATE products SET stock=stock-? WHERE id=?',[i.qty,i.productId]);
      }
      await db.run('INSERT INTO sales (created_at,total,paid,change_amount) VALUES (?,?,?,?)',[createdAt,total,paid,paid-total]);
      const idr=await db.query('SELECT last_insert_rowid() as id');
      const id=Number(idr.values?.[0]?.id);
      for (const i of items) await db.run('INSERT INTO sale_items (sale_id,product_id,name,price,qty) VALUES (?,?,?,?,?)',[id,i.productId,i.name,i.price,i.qty]);
      await db.execute('COMMIT');
      return {id,createdAt,total,paid,change:paid-total,items};
    } catch(e) { await db.execute('ROLLBACK'); throw e; }
  }
  const d=load();
  for (const i of items) {
    const p=d.products.find((x:Product)=>x.id===i.productId);
    if (!p || p.stock<i.qty) throw new Error(`Stok ${i.name} tidak mencukupi.`);
  }
  for (const i of items) d.products.find((x:Product)=>x.id===i.productId).stock-=i.qty;
  const sale:Sale={id:Date.now(),createdAt,total,paid,change:paid-total,items};
  d.sales.unshift(sale); save(d); return sale;
}
export async function getSales():Promise<Sale[]> {
  if (mode==='sqlite') {
    const r=await db.query('SELECT * FROM sales ORDER BY id DESC');
    const out:Sale[]=[];
    for (const s of r.values||[]) {
      const it=await db.query('SELECT product_id,name,price,qty FROM sale_items WHERE sale_id=?',[s.id]);
      out.push({id:s.id,createdAt:s.created_at,total:s.total,paid:s.paid,change:s.change_amount,items:(it.values||[]).map((x:any)=>({productId:x.product_id,name:x.name,price:x.price,qty:x.qty}))});
    }
    return out;
  }
  return load().sales;
}
export async function exportBackup():Promise<string> {
  if (mode==='sqlite') return JSON.stringify({products:await getProducts(),sales:await getSales(),exportedAt:new Date().toISOString()},null,2);
  return JSON.stringify({...load(),exportedAt:new Date().toISOString()},null,2);
}
