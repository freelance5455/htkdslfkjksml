import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'id.sarifadilah.kasir',
  appName: 'Kasir Sari Fadilah',
  webDir: 'dist',
  bundledWebRuntime: false
};
export default config;
