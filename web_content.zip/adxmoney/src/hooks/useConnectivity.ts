import { useCallback, useEffect, useRef, useState } from "react";

const SUPABASE_URL: string =
  (import.meta.env.VITE_SUPABASE_URL as string | undefined) || "https://wznepehesjmhpateaoby.supabase.co";
const PROBE_URL = `${SUPABASE_URL}/auth/v1/health`;

const ONLINE_INTERVAL_MS = 15_000; // verificação periódica com ligação ok
const OFFLINE_INTERVAL_MS = 4_000; // tenta recuperar mais depressa quando está offline
const PROBE_TIMEOUT_MS = 6_000;
const FAILS_TO_GO_OFFLINE = 2; // evita "piscar" com uma falha isolada

/** Pedido leve ao backend: qualquer resposta HTTP = há internet; erro de rede/timeout = não há. */
async function probe(): Promise<boolean> {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return false;
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), PROBE_TIMEOUT_MS);
  try {
    await fetch(`${PROBE_URL}?_=${Date.now()}`, { method: "GET", mode: "no-cors", cache: "no-store", signal: ctrl.signal });
    return true;
  } catch {
    return false;
  } finally {
    window.clearTimeout(timer);
  }
}

/**
 * Estado real da ligação (não só navigator.onLine, que falha em Wi‑Fi sem internet).
 * - Offline imediato quando o sistema avisa ("offline" / navigator.onLine === false).
 * - Wi‑Fi sem internet: marca offline após 2 falhas seguidas (~15–30 s).
 * - Recupera sozinho (verifica de 4 em 4 s enquanto offline).
 * - `recheck()` força uma verificação (botão "Tentar novamente").
 */
export function useConnectivity() {
  const [online, setOnline] = useState(() => typeof navigator === "undefined" || navigator.onLine !== false);
  const failures = useRef(0);
  const onlineRef = useRef(online);
  onlineRef.current = online;

  const apply = useCallback((ok: boolean, immediate = false) => {
    if (ok) {
      failures.current = 0;
      setOnline(true);
      return;
    }
    failures.current += 1;
    if (immediate || failures.current >= FAILS_TO_GO_OFFLINE || navigator.onLine === false) setOnline(false);
  }, []);

  const recheck = useCallback(async () => {
    const ok = await probe();
    apply(ok, true);
    return ok;
  }, [apply]);

  useEffect(() => {
    let timer: number | undefined;
    let stopped = false;

    const schedule = () => {
      if (stopped) return;
      timer = window.setTimeout(async () => {
        if (document.visibilityState === "visible") apply(await probe());
        schedule();
      }, onlineRef.current ? ONLINE_INTERVAL_MS : OFFLINE_INTERVAL_MS);
    };

    const onOffline = () => {
      failures.current = FAILS_TO_GO_OFFLINE;
      setOnline(false);
    };
    const onOnline = async () => apply(await probe());
    const onVisible = async () => {
      if (document.visibilityState === "visible") apply(await probe());
    };

    window.addEventListener("offline", onOffline);
    window.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVisible);
    schedule();

    return () => {
      stopped = true;
      if (timer) window.clearTimeout(timer);
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [apply]);

  return { online, recheck };
}
