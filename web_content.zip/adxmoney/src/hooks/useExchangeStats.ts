import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface ExchangeStats {
  /** Seguidores ganhos: provas aprovadas nas tarefas (links) do próprio utilizador. */
  followers: number;
  /** Seguidores ganhos nos últimos 7 dias. */
  followersWeek: number;
  /** O utilizador tem pelo menos um link publicado na troca. */
  hasOwnLink: boolean;
  /** Contas por seguir (tarefas atribuídas e ainda por fazer). */
  toFollow: number;
  /** Provas de outros membros à espera da validação do utilizador. */
  toReview: number;
  /** Monitor das execuções do utilizador (provas enviadas). */
  proofs: { review: number; approved: number; rejected: number; total: number };
  /** Execuções enviadas por dia, últimos 7 dias (mais antigo → hoje). */
  week: { label: string; count: number; today: boolean }[];
}

const APPROVED = ["APPROVED", "AUTO_APPROVED"];
const DAY_LABELS = ["D", "S", "T", "Q", "Q", "S", "S"];

const EMPTY: ExchangeStats = {
  followers: 0,
  followersWeek: 0,
  hasOwnLink: false,
  toFollow: 0,
  toReview: 0,
  proofs: { review: 0, approved: 0, rejected: 0, total: 0 },
  week: [],
};

function buildWeek(rows: { created_at: string }[]): ExchangeStats["week"] {
  const days: ExchangeStats["week"] = [];
  const keys: string[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    keys.push(d.toDateString());
    days.push({ label: DAY_LABELS[d.getDay()], count: 0, today: i === 0 });
  }
  rows.forEach((r) => {
    const idx = keys.indexOf(new Date(r.created_at).toDateString());
    if (idx >= 0) days[idx].count += 1;
  });
  return days;
}

/**
 * Números da Home (troca de seguidores + execuções). Só leitura, tolerante a falhas:
 * se uma consulta falhar mantém o último valor e nunca bloqueia a Home.
 */
export function useExchangeStats(userId?: string | null, refreshKey?: number | null) {
  const [stats, setStats] = useState<ExchangeStats>(EMPTY);
  const [loading, setLoading] = useState(true);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const load = useCallback(async () => {
    if (!userId) {
      setLoading(false);
      return;
    }
    try {
      const since = new Date(Date.now() - 7 * 86_400_000).toISOString();

      // Links do próprio utilizador na troca (quem os segue conta como seguidor)
      const ownRes: any = await supabase
        .from("community_tasks")
        .select("id")
        .eq("creator_user_id", userId)
        .eq("source", "EXCHANGE")
        .eq("is_active", true)
        .limit(50);
      const ids: string[] = ((ownRes?.data as any[]) || []).map((r) => r.id);
      const none: any = Promise.resolve({ count: 0 });

      const [fTot, fWeek, rev, queue, mine]: any[] = await Promise.all([
        ids.length
          ? supabase.from("task_proofs").select("id", { count: "exact", head: true }).in("task_id", ids).in("status", APPROVED)
          : none,
        ids.length
          ? supabase
              .from("task_proofs")
              .select("id", { count: "exact", head: true })
              .in("task_id", ids)
              .in("status", APPROVED)
              .gte("created_at", since)
          : none,
        ids.length
          ? supabase
              .from("task_proofs")
              .select("id", { count: "exact", head: true })
              .in("task_id", ids)
              .eq("status", "SUBMITTED")
              .neq("user_id", userId)
          : none,
        supabase
          .from("task_distribution_queue")
          .select("id", { count: "exact", head: true })
          .eq("user_id", userId)
          .eq("status", "ASSIGNED"),
        supabase
          .from("task_proofs")
          .select("status, created_at")
          .eq("user_id", userId)
          .order("created_at", { ascending: false })
          .limit(500),
      ]);

      const rows: { status: string; created_at: string }[] = (mine?.data as any[]) || [];
      const proofs = {
        review: rows.filter((r) => r.status === "SUBMITTED").length,
        approved: rows.filter((r) => APPROVED.includes(r.status)).length,
        rejected: rows.filter((r) => r.status === "REJECTED").length,
        total: rows.length,
      };

      if (!mounted.current) return;
      setStats({
        followers: fTot?.count ?? 0,
        followersWeek: fWeek?.count ?? 0,
        hasOwnLink: ids.length > 0,
        toFollow: queue?.count ?? 0,
        toReview: rev?.count ?? 0,
        proofs,
        week: buildWeek(rows),
      });
    } catch (err) {
      console.warn("Estatísticas da troca indisponíveis:", err);
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    void load();
  }, [load, refreshKey]);

  return { stats, loading, reload: load };
}
