import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface FlowDay {
  key: string; // YYYY-MM-DD
  date: Date;
  entradas: number;
  saidas: number;
}

interface TxLike {
  amount: number;
  created_at: string;
}

function pad(n: number) {
  return String(n).padStart(2, "0");
}
function keyOf(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function parseKey(k: string): Date {
  const [y, m, d] = k.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

/** Fallback local: usa os movimentos já carregados (últimos ~100). */
function bucketize(transactions: TxLike[], totalDays: number): FlowDay[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const days: FlowDay[] = [];
  const index = new Map<string, FlowDay>();
  for (let i = totalDays - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const item = { key: keyOf(d), date: d, entradas: 0, saidas: 0 };
    days.push(item);
    index.set(item.key, item);
  }
  for (const tx of transactions || []) {
    const amt = Number(tx.amount) || 0;
    const d = new Date(tx.created_at);
    d.setHours(0, 0, 0, 0);
    const slot = index.get(keyOf(d));
    if (!slot) continue;
    if (amt >= 0) slot.entradas += amt;
    else slot.saidas += Math.abs(amt);
  }
  return days;
}

/**
 * Série diária de entradas/saídas para `2 × period` dias (período actual + anterior).
 * Usa a RPC `get_wallet_flow` (completa, agregada no servidor). Se a migração 024 ainda não
 * existir ou falhar, cai para o cálculo local sem partir a Home.
 */
export function useWalletFlow(period: number, transactions: TxLike[]) {
  const totalDays = period * 2;
  const [remote, setRemote] = useState<Record<number, FlowDay[]>>({});
  const [failed, setFailed] = useState(false);
  const [loading, setLoading] = useState(false);
  const inflight = useRef(0);

  // Muda quando chegam movimentos novos (depósito, recompensa…) → volta a pedir ao servidor
  const txSignature = `${transactions?.length ?? 0}:${transactions?.[0]?.created_at ?? ""}`;

  useEffect(() => {
    if (failed) return;
    const ticket = ++inflight.current;
    setLoading(true);
    supabase.rpc("get_wallet_flow", { p_days: totalDays }).then(({ data, error }) => {
      if (ticket !== inflight.current) return;
      setLoading(false);
      if (error || !Array.isArray(data)) {
        setFailed(true);
        return;
      }
      const rows: FlowDay[] = (data as { day: string; entradas: number | string; saidas: number | string }[]).map((r) => ({
        key: String(r.day).slice(0, 10),
        date: parseKey(String(r.day).slice(0, 10)),
        entradas: Number(r.entradas) || 0,
        saidas: Number(r.saidas) || 0,
      }));
      setRemote((prev) => ({ ...prev, [totalDays]: rows }));
    });
  }, [totalDays, txSignature, failed]);

  const local = useMemo(() => bucketize(transactions, totalDays), [transactions, totalDays]);
  const days = remote[totalDays] && remote[totalDays].length === totalDays ? remote[totalDays] : local;
  return { days, source: remote[totalDays] ? ("server" as const) : ("local" as const), loading };
}
