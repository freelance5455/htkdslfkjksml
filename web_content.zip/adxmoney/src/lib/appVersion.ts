/**
 * Version check (Etapa 5). Só leitura: nunca bloqueia se a rede/tabela falhar.
 * Config no Supabase: tabela public.app_version_config (migração 036), uma linha por plataforma.
 */
import { supabase } from "@/integrations/supabase/client";
import { isNativePlatform } from "@/lib/nativeShell";

declare const __APP_VERSION__: string | undefined;

export type VersionConfig = {
  platform: string;
  min_version: string;
  latest_version: string;
  force_update: boolean;
  message: string | null;
  store_url: string | null;
};

export type UpdateStatus = "ok" | "optional" | "required";

export function getPlatformKey(): "android" | "ios" | "web" {
  try {
    const p = (window as unknown as { Capacitor?: { getPlatform?: () => string } }).Capacitor?.getPlatform?.();
    if (p === "android" || p === "ios") return p;
  } catch {
    /* ignore */
  }
  return "web";
}

/** Compara versões "1.2.3" (ignora sufixos tipo -beta). Devolve <0, 0 ou >0. */
export function compareVersions(a: string, b: string): number {
  const parse = (v: string) =>
    (v || "0").split("-")[0].split(".").map((x) => parseInt(x, 10) || 0);
  const pa = parse(a);
  const pb = parse(b);
  for (let i = 0; i < Math.max(pa.length, pb.length, 3); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) return d;
  }
  return 0;
}

export async function getCurrentVersion(): Promise<string> {
  if (isNativePlatform()) {
    try {
      const { App } = await import("@capacitor/app");
      const info = await App.getInfo();
      if (info?.version) return info.version; // versionName do build.gradle
    } catch {
      /* cai para a versão do bundle */
    }
  }
  return (typeof __APP_VERSION__ !== "undefined" && __APP_VERSION__) || "0.0.0";
}

export async function fetchVersionConfig(): Promise<VersionConfig | null> {
  try {
    const { data, error } = await supabase
      .from("app_version_config")
      .select("platform, min_version, latest_version, force_update, message, store_url")
      .eq("platform", getPlatformKey())
      .maybeSingle();
    if (error || !data) return null;
    return data as VersionConfig;
  } catch {
    return null;
  }
}

export function evaluateUpdate(current: string, cfg: VersionConfig): UpdateStatus {
  if (compareVersions(current, cfg.min_version) < 0) {
    return cfg.force_update ? "required" : "optional";
  }
  if (compareVersions(current, cfg.latest_version) < 0) return "optional";
  return "ok";
}

/** Web/PWA: limpa service workers + caches e recarrega. */
export async function hardReloadPwa(): Promise<void> {
  try {
    const regs = (await navigator.serviceWorker?.getRegistrations?.()) ?? [];
    await Promise.all(regs.map((r) => r.unregister()));
  } catch {
    /* ignore */
  }
  try {
    const keys = (await window.caches?.keys?.()) ?? [];
    await Promise.all(keys.map((k) => caches.delete(k)));
  } catch {
    /* ignore */
  }
  window.location.reload();
}
