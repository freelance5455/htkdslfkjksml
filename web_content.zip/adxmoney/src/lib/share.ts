/**
 * Partilha (Etapa 5). Nativo: @capacitor/share (sheet do sistema).
 * Web/PWA: navigator.share; sem suporte → copia o link.
 */
import { FEATURES } from "@/lib/features";
import { isNativePlatform } from "@/lib/nativeShell";

export type ShareResult = "shared" | "cancelled" | "copied" | "failed";

export async function shareLink(opts: {
  title: string;
  text: string;
  url: string;
  dialogTitle?: string;
}): Promise<ShareResult> {
  // 1) Sheet nativo
  if (FEATURES.NATIVE_SHARE && isNativePlatform()) {
    try {
      const { Share } = await import("@capacitor/share");
      const { value } = await Share.canShare();
      if (value) {
        await Share.share({
          title: opts.title,
          text: opts.text,
          url: opts.url,
          dialogTitle: opts.dialogTitle ?? opts.title,
        });
        return "shared";
      }
    } catch (e) {
      if (/cancel/i.test(String((e as Error)?.message ?? e))) return "cancelled";
      /* cai para o fallback */
    }
  }

  // 2) Web Share API
  try {
    if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
      await navigator.share({ title: opts.title, text: opts.text, url: opts.url });
      return "shared";
    }
  } catch (e) {
    if ((e as Error)?.name === "AbortError") return "cancelled";
  }

  // 3) Copiar
  try {
    await navigator.clipboard.writeText(opts.url);
    return "copied";
  } catch {
    return "failed";
  }
}
