/**
 * Evento único "app ficou activa / inactiva".
 * Nativo: Capacitor App.appStateChange. Web/PWA: visibilitychange.
 * Devolve a função para remover o listener.
 */
import { isNativePlatform } from "@/lib/nativeShell";

export function onAppActiveChange(cb: (active: boolean) => void): () => void {
  let removed = false;
  let handle: { remove: () => Promise<void> } | null = null;
  const onVisibility = () => cb(document.visibilityState === "visible");

  if (isNativePlatform()) {
    import("@capacitor/app")
      .then(({ App }) => App.addListener("appStateChange", (s) => cb(!!s.isActive)))
      .then((h) => {
        if (removed) void h.remove();
        else handle = h;
      })
      .catch(() => {
        /* sem plugin: ignora */
      });
  } else {
    document.addEventListener("visibilitychange", onVisibility);
  }

  return () => {
    removed = true;
    document.removeEventListener("visibilitychange", onVisibility);
    if (handle) void handle.remove();
  };
}
