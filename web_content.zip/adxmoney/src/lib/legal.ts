// Textos legais da plataforma. Redigidos com os dados do operador; recomenda-se revisão por advogado angolano.
// Se ainda houver marcadores [ENTRE PARÊNTESES], ponha LEGAL_IS_DRAFT = true para mostrar o aviso de rascunho.
// Sempre que alterar o conteúdo de forma relevante, mude TERMS_VERSION: todos os utilizadores voltarão a
// ter de aceitar (a aceitação fica registada em terms_acceptances).

export const TERMS_VERSION = "2026-11-v1";
export const LEGAL_IS_DRAFT = false;

export const COMPANY = {
  name: "Dojean",
  taxId: "", // NIF: preencher quando disponível (se vazio, não é mostrado nos textos)
  address: "Luanda, Angola",
  email: "", // e-mail de suporte: preencher quando existir (se vazio, não é mostrado)
  whatsapp: "+244 950 776 148",
};

const NIF_TXT = COMPANY.taxId ? ` (NIF ${COMPANY.taxId})` : "";
const EMAIL_TXT = COMPANY.email ? `${COMPANY.email} · ` : "";

export interface LegalSection {
  title: string;
  body: string[];
}

export const TERMS_SECTIONS: LegalSection[] = [
  {
    title: "1. Quem somos e aceitação",
    body: [
      `A plataforma ADXmoney é operada por ${COMPANY.name}${NIF_TXT}, com sede em ${COMPANY.address}. Contacto: ${EMAIL_TXT}WhatsApp ${COMPANY.whatsapp}.`,
      "Ao criar conta ou ao usar a plataforma, o utilizador declara que leu e aceita estes Termos e a Política de Privacidade.",
    ],
  },
  {
    title: "2. A conta",
    body: [
      "Só podem ter conta pessoas com 18 anos ou mais. Os dados fornecidos (nome, e-mail, telefone/WhatsApp, país) têm de ser verdadeiros.",
      "Cada pessoa pode ter apenas uma conta, e cada número de telefone só pode estar associado a uma conta.",
      "A palavra-passe é pessoal e intransmissível; o utilizador é responsável pela atividade feita com a sua conta. A plataforma nunca pede a palavra-passe por mensagem.",
    ],
  },
  {
    title: "3. Assinatura",
    body: [
      "O acesso às funcionalidades pagas (troca de seguidores, tarefas, campanhas e afiliados) exige uma assinatura ativa. O preço e a duração (por defeito, 6 meses) são os indicados na aplicação no momento do pagamento.",
      "A assinatura é ativada depois de a equipa validar o comprovativo de pagamento. Pode ser renovada nos últimos 30 dias de validade, somando-se os novos meses aos que ainda restam. Terminada a validade, o acesso às funcionalidades pagas é suspenso até nova renovação.",
      "Reembolsos: depois de ativada, a assinatura não é reembolsável, exceto em caso de cobrança em duplicado, erro de valor ou falha do serviço imputável à plataforma. O pedido deve ser feito pelo WhatsApp de suporte no prazo de 7 dias após o pagamento, com o comprovativo. Pedidos baseados em fraude ou uso indevido da conta não são reembolsados. Isto não afasta os direitos que a lei de defesa do consumidor reconhece ao utilizador.",
    ],
  },
  {
    title: "4. Troca de seguidores e tarefas",
    body: [
      "Na troca de seguidores, o link das redes sociais do utilizador é partilhado com os outros assinantes, e o utilizador recebe links de outros assinantes para seguir. Só são aceites links das próprias redes sociais indicadas (TikTok, Instagram, YouTube).",
      "As ações têm de ser feitas realmente, com a conta do próprio. A prova (captura de ecrã) pode ser validada pelo dono do link; se não for validada no prazo, pode ser aprovada automaticamente. Provas falsas, repetidas ou de contas que não são do utilizador são proibidas.",
      "Nas tarefas da loja (pedidos pagos por outros utilizadores) pode existir uma recompensa por tarefa validada, nos valores indicados na aplicação.",
    ],
  },
  {
    title: "5. Campanhas e resultados",
    body: [
      "Participar numa campanha não gera pagamento por si só. Quando a campanha produz um resultado financeiro, a equipa regista-o e uma percentagem desse resultado (indicada na aplicação para cada tipo de campanha) é repartida em partes iguais por todos os participantes que concluíram a campanha e mantêm a assinatura ativa nesse momento.",
      "Não é prometido nem garantido qualquer rendimento. Se não houver resultado, não há pagamento.",
    ],
  },
  {
    title: "6. Afiliados",
    body: [
      "O afiliado recebe uma percentagem (indicada na aplicação) quando um utilizador que convidou paga uma assinatura, um pedido na loja de engajamento ou uma campanha coletiva. O simples registo de um convidado não gera comissão.",
      "A comissão só é paga se o afiliado tiver assinatura ativa. É proibido criar contas falsas ou convidar a própria pessoa para obter comissões.",
    ],
  },
  {
    title: "7. Carteira, depósitos e saques",
    body: [
      "Os valores da carteira estão em kwanzas (Kz). Depósitos e assinaturas são creditados/ativados após validação do comprovativo pela equipa.",
      "Os saques têm um valor mínimo e limites máximos (por pedido, por utilizador em 24 horas e global da plataforma em 24 horas), indicados na aplicação, e são aprovados manualmente em dois passos (aprovação e pagamento). O prazo máximo para o pagamento de um saque é de 24 horas a contar do pedido, salvo verificações adicionais necessárias por segurança ou falhas de terceiros (bancos, operadores de pagamento) fora do controlo da plataforma, caso em que o utilizador será informado.",
      "Se um saque for rejeitado, o valor reservado volta à carteira. A plataforma pode pedir informação adicional para verificar um saque.",
    ],
  },
  {
    title: "8. Condutas proibidas, suspensão e encerramento",
    body: [
      "É proibido: criar contas falsas ou múltiplas; usar bots; enviar comprovativos ou provas falsos; manipular tarefas, campanhas, convites ou comissões; tentar aceder a dados de outros utilizadores ou contornar a segurança.",
      "A plataforma pode suspender ou desativar contas em caso de violação. Valores obtidos de forma fraudulenta podem ser retidos ou estornados, após análise da situação.",
      "Contas com movimentos financeiros não são apagadas: são desativadas e os registos financeiros são conservados pelo prazo legal.",
    ],
  },
  {
    title: "9. Responsabilidade",
    body: [
      "A plataforma é prestada no estado em que se encontra, e podem ocorrer interrupções. Na medida permitida pela lei, a responsabilidade da plataforma limita-se aos valores efetivamente pagos e não reembolsados pelo utilizador. ",
      "As redes sociais (TikTok, Instagram, YouTube) são de terceiros e as suas regras podem afetar as ações pedidas.",
    ],
  },
  {
    title: "10. Alterações a estes Termos",
    body: [
      "Os Termos podem ser atualizados. Quando a alteração for relevante, será publicada uma nova versão e o utilizador terá de a aceitar para continuar a usar a plataforma.",
    ],
  },
  {
    title: "11. Lei aplicável e contactos",
    body: [
      "Estes Termos regem-se pela lei da República de Angola, designadamente a Lei n.º 15/03, de 22 de Julho (Defesa do Consumidor), a Lei n.º 22/11, de 17 de Junho (Proteção de Dados Pessoais) e a Lei n.º 23/11, de 20 de Junho (Comunicações Eletrónicas e Serviços da Sociedade da Informação).",
      "Para a resolução de litígios é competente o foro da Comarca de Luanda, sem prejuízo das normas imperativas de proteção do consumidor e do direito do utilizador de recorrer às entidades de defesa do consumidor, como o INADEC.",
      `Reclamações e suporte: ${EMAIL_TXT}WhatsApp ${COMPANY.whatsapp}.`,
    ],
  },
];

export const PRIVACY_SECTIONS: LegalSection[] = [
  {
    title: "1. Responsável pelo tratamento",
    body: [`${COMPANY.name}${NIF_TXT}, ${COMPANY.address}. Contacto para privacidade: ${EMAIL_TXT}WhatsApp ${COMPANY.whatsapp}. O tratamento dos dados rege-se pela Lei n.º 22/11, de 17 de Junho (Lei da Proteção de Dados Pessoais).`],
  },
  {
    title: "2. Dados que tratamos",
    body: [
      "Dados da conta: nome, e-mail, telefone/WhatsApp, país, links das redes sociais indicados, código de convite.",
      "Dados financeiros: pagamentos, depósitos, saques, saldo, movimentos da carteira, comissões, e os comprovativos (imagens/PDF) que o utilizador envia.",
      "Dados de atividade: tarefas, provas, participação em campanhas, registo de ações na conta.",
      "Dados técnicos: endereço IP no momento do registo (para prevenção de abuso), tipo de dispositivo/navegador e erros técnicos da aplicação.",
    ],
  },
  {
    title: "3. Para que usamos os dados",
    body: [
      "Para criar e gerir a conta; validar pagamentos; processar saques, comissões e partilhas de campanhas; prevenir fraude e abuso; dar suporte; cumprir obrigações legais; e melhorar a estabilidade da aplicação.",
      "Fundamento: execução do contrato, cumprimento de obrigações legais, interesse legítimo na prevenção de fraude e, quando aplicável, consentimento do titular.",
    ],
  },
  {
    title: "4. Com quem partilhamos",
    body: [
      "Infraestrutura e alojamento: Supabase (base de dados, autenticação e armazenamento) e Vercel (alojamento da aplicação).",
      "Assistentes de IA da aplicação (coach, suporte e gerador de conteúdo): para gerar as respostas, enviamos a um fornecedor externo de IA (Groq) o texto que o utilizador escreve e, no coach e no suporte, também dados da conta: o primeiro nome, o estado da assinatura, o saldo disponível e reservado, tarefas pendentes e dados de afiliado (código, convites e ganhos). Não enviamos palavras-passe, e-mail, telefone nem comprovativos. Não introduza dados sensíveis nesses campos.",
      "Os links de redes sociais publicados na troca de seguidores são mostrados a outros assinantes. Não vendemos dados pessoais.",
      "Estes fornecedores tratam dados fora de Angola (transferência internacional), com as garantias exigidas pela Lei n.º 22/11 e pela Agência de Proteção de Dados (APD), na medida em que forem aplicáveis.",
    ],
  },
  {
    title: "5. Quanto tempo guardamos",
    body: [
      "Registos financeiros (movimentos, depósitos, saques, assinaturas, comissões): conservados durante o prazo exigido pela lei aplicável, mesmo que a conta seja desativada.",
      "Comprovativos enviados: apagados do armazenamento depois de validados, num prazo curto; registos de atividade: cerca de 180 dias; registos técnicos de registo (IP): cerca de 30 dias; registos de erros: 30 dias.",
    ],
  },
  {
    title: "6. Os seus direitos",
    body: [
      `Pode pedir acesso, correção, oposição ou eliminação dos seus dados, e a limitação do tratamento, pelo contacto acima. A eliminação pode ser limitada pelos prazos legais de conservação dos registos financeiros.`,
      "Pode também apresentar reclamação à Agência de Proteção de Dados (APD), a autoridade de proteção de dados de Angola.",
    ],
  },
  {
    title: "7. Segurança",
    body: [
      "Usamos controlo de acesso por conta, armazenamento privado dos comprovativos, registo de operações financeiras e outras medidas técnicas. Nenhum sistema é totalmente seguro; proteja a sua palavra-passe.",
    ],
  },
  {
    title: "8. Armazenamento no dispositivo",
    body: [
      "A aplicação usa armazenamento local do navegador/dispositivo para manter a sessão e funcionar como aplicação instalável (PWA). Não usamos cookies de publicidade.",
    ],
  },
  {
    title: "9. Menores e alterações",
    body: [
      "A plataforma não se destina a menores de 18 anos. Esta política pode ser atualizada; a versão em vigor é a publicada nesta página.",
    ],
  },
];
