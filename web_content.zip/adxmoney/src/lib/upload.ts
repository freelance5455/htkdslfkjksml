/**
 * Comprovativos: validação + compressão no dispositivo (poupa dados móveis e armazenamento).
 * Imagens são redimensionadas (máx. 1600 px) e guardadas em JPEG; PDFs não se comprimem (máx. 3 MB).
 */
export const MAX_RAW_IMAGE_BYTES = 15 * 1024 * 1024; // fotos de telemóvel antes de comprimir
export const MAX_PDF_BYTES = 3 * 1024 * 1024;
export const MAX_FINAL_BYTES = 1.5 * 1024 * 1024; // limite do que realmente é enviado
const TARGET_BYTES = 350 * 1024; // alvo da compressão

const ALLOWED: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "application/pdf": "pdf",
};

export interface ProofCheck {
  ok: boolean;
  error?: string;
  ext?: string;
}

export function checkProofFile(file: File, opts?: { imagesOnly?: boolean }): ProofCheck {
  const ext = ALLOWED[file.type];
  if (!ext || (opts?.imagesOnly && ext === "pdf")) {
    return {
      ok: false,
      error: opts?.imagesOnly ? "Formato inválido. Use JPG, PNG ou WEBP." : "Formato inválido. Use JPG, PNG, WEBP ou PDF.",
    };
  }
  if (file.size === 0) return { ok: false, error: "Ficheiro vazio." };
  if (ext === "pdf" && file.size > MAX_PDF_BYTES) return { ok: false, error: "PDF demasiado grande (máx. 3 MB)." };
  if (ext !== "pdf" && file.size > MAX_RAW_IMAGE_BYTES) {
    return { ok: false, error: "Imagem demasiado grande (máx. 15 MB)." };
  }
  return { ok: true, ext };
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob((b) => resolve(b), "image/jpeg", quality));
}

async function decodeImage(file: File): Promise<{ src: CanvasImageSource; width: number; height: number; release: () => void }> {
  if (typeof createImageBitmap === "function") {
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
      return { src: bmp, width: bmp.width, height: bmp.height, release: () => bmp.close() };
    } catch {
      /* cai para <img> */
    }
  }
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.src = url;
  await img.decode();
  return { src: img, width: img.naturalWidth, height: img.naturalHeight, release: () => URL.revokeObjectURL(url) };
}

/** Comprime imagens para JPEG (≈ 100–350 KB). Devolve o original se a compressão não ajudar. */
export async function compressImage(file: File): Promise<File> {
  const decoded = await decodeImage(file);
  try {
    const steps: Array<{ dim: number; q: number }> = [
      { dim: 1600, q: 0.78 },
      { dim: 1400, q: 0.7 },
      { dim: 1200, q: 0.62 },
      { dim: 1000, q: 0.55 },
    ];
    let best: Blob | null = null;
    for (const step of steps) {
      const scale = Math.min(1, step.dim / Math.max(decoded.width, decoded.height));
      const w = Math.max(1, Math.round(decoded.width * scale));
      const h = Math.max(1, Math.round(decoded.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (!ctx) break;
      ctx.fillStyle = "#ffffff"; // PNG com transparência → fundo branco
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(decoded.src, 0, 0, w, h);
      const blob = await canvasToBlob(canvas, step.q);
      canvas.width = 0;
      canvas.height = 0;
      if (!blob) continue;
      best = blob;
      if (blob.size <= TARGET_BYTES) break;
    }
    if (!best || best.size >= file.size) return file;
    return new File([best], "comprovativo.jpg", { type: "image/jpeg", lastModified: Date.now() });
  } finally {
    decoded.release();
  }
}

export interface PreparedProof {
  file: File;
  ext: string;
}

/** Valida e comprime. É isto que cada ecrã chama imediatamente antes do upload. */
export async function prepareProof(file: File, opts?: { imagesOnly?: boolean }): Promise<PreparedProof> {
  const check = checkProofFile(file, opts);
  if (!check.ok) throw new Error(check.error);
  if (check.ext === "pdf") return { file, ext: "pdf" };

  let out: File;
  try {
    out = await compressImage(file);
  } catch {
    throw new Error("Não foi possível processar a imagem. Tente outra captura.");
  }
  if (out.size > MAX_FINAL_BYTES) throw new Error("Imagem demasiado pesada mesmo após compressão. Use uma captura de ecrã.");
  const ext = out.type === "image/jpeg" ? "jpg" : ALLOWED[out.type] || "jpg";
  return { file: out, ext };
}

/** Caminho único e seguro: extensão vem do MIME validado (nunca do nome do ficheiro). */
export function proofPath(prefix: string, ext: string): string {
  const rnd = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : String(Date.now());
  return `${prefix}/${Date.now()}_${rnd.slice(0, 8)}.${ext}`;
}
