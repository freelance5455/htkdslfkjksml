/** SHA-256 (hex) de um ficheiro, para o servidor rejeitar capturas repetidas. */
export async function sha256File(file: File): Promise<string> {
  if (typeof crypto === "undefined" || !crypto.subtle) {
    throw new Error("Este dispositivo não suporta verificação segura de ficheiros. Atualize o navegador.");
  }
  const buf = await file.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}
