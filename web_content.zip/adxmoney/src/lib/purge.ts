import { supabase } from "@/integrations/supabase/client";

/**
 * Pede à Edge Function para apagar do Storage os comprovativos já validados.
 * "Fire-and-forget": nunca bloqueia nem falha o fluxo principal (há também limpeza agendada).
 */
export function purgeProofsSoon(): void {
  void supabase.functions.invoke("purge-proofs", { body: {} }).catch(() => undefined);
}
