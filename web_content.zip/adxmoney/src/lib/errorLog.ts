import { supabase } from "@/integrations/supabase/client";

// Registo simples de erros do cliente (tabela app_errors, só o admin lê). Sem serviço externo.
// Falha em silêncio: o registo de erros nunca pode causar outro erro.
let lastKey = "";
let lastAt = 0;

export async function logClientError(message: string, stack?: string) {
  try {
    const key = message.slice(0, 120);
    const now = Date.now();
    if (key === lastKey && now - lastAt < 30_000) return; // evita repetir o mesmo erro em ciclo
    lastKey = key;
    lastAt = now;
    const { data } = await supabase.auth.getSession();
    if (!data.session) return; // a função só aceita utilizadores autenticados
    await supabase.rpc("log_client_error", {
      p_message: message,
      p_stack: stack || null,
      p_url: window.location.pathname + window.location.search,
      p_user_agent: navigator.userAgent,
    });
  } catch {
    /* ignorar */
  }
}

export function installGlobalErrorLogging() {
  window.addEventListener("error", (e) => {
    logClientError(e.message || "Erro de script", e.error?.stack);
  });
  window.addEventListener("unhandledrejection", (e) => {
    const r: any = e.reason;
    logClientError(`Promise rejeitada: ${r?.message || String(r)}`, r?.stack);
  });
}
