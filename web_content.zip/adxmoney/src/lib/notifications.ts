import { supabase } from "@/integrations/supabase/client";

export type NotifEventType =
  | "proof"
  | "deposit"
  | "withdrawal"
  | "subscription"
  | "campaign"
  | "admin_message"
  | "system";

export type NotifPreferences = {
  proof: boolean;
  deposit: boolean;
  withdrawal: boolean;
  subscription: boolean;
  campaign: boolean;
  admin_message: boolean;
  marketing: boolean;
};

/** Regista token FCM no Supabase (chamar após permissão + getToken). */
export async function upsertDeviceToken(opts: {
  token: string;
  platform?: "android" | "ios" | "web";
  appVersion?: string;
  deviceLabel?: string;
}): Promise<{ ok: boolean; error?: string }> {
  const token = (opts.token || "").trim();
  if (token.length < 20) return { ok: false, error: "token_invalid" };

  const { error } = await supabase.rpc("upsert_device_token", {
    p_token: token,
    p_platform: opts.platform ?? "android",
    p_app_version: opts.appVersion ?? null,
    p_device_label: opts.deviceLabel ?? null,
  });

  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

export async function disableDeviceToken(token: string): Promise<void> {
  const t = (token || "").trim();
  if (!t) return;
  await supabase.rpc("disable_device_token", { p_token: t });
}

export async function loadNotificationPreferences(): Promise<NotifPreferences | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("notification_preferences")
    .select("proof, deposit, withdrawal, subscription, campaign, admin_message, marketing")
    .eq("user_id", user.id)
    .maybeSingle();

  if (error || !data) {
    return {
      proof: true,
      deposit: true,
      withdrawal: true,
      subscription: true,
      campaign: true,
      admin_message: true,
      marketing: false,
    };
  }
  return data as NotifPreferences;
}

export async function saveNotificationPreferences(
  partial: Partial<NotifPreferences>
): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase.rpc("set_notification_preferences", {
    p_proof: partial.proof ?? null,
    p_deposit: partial.deposit ?? null,
    p_withdrawal: partial.withdrawal ?? null,
    p_subscription: partial.subscription ?? null,
    p_campaign: partial.campaign ?? null,
    p_admin_message: partial.admin_message ?? null,
    p_marketing: partial.marketing ?? null,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

/**
 * Dispara o worker push-send (só com service role — uso em scripts/cron, não no browser do user).
 * No browser normal isto falha (401); o envio real é Cron + secret service_role.
 */
export async function invokePushSendWorker(serviceRoleKey: string, limit = 40): Promise<unknown> {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/push-send`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${serviceRoleKey}`,
      apikey: serviceRoleKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ limit }),
  });
  return res.json();
}
