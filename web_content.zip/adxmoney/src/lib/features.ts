/**
 * Feature flags da Etapa 5 (funcionalidades nativas).
 * Pôr uma flag a `false` desliga a funcionalidade por completo (os módulos passam a no-op).
 */
export const FEATURES = {
  HAPTICS: true,
  NATIVE_SHARE: true,
  BADGE: true,
  VERSION_CHECK: true,
  BIOMETRIC: true,
} as const;
