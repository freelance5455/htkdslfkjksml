/**
 * Haptics (Etapa 5). Nunca lança erro e nunca bloqueia a UI.
 * Nativo: @capacitor/haptics. Web/PWA: navigator.vibrate (best-effort; iOS ignora).
 */
import { FEATURES } from "@/lib/features";
import { isNativePlatform } from "@/lib/nativeShell";

function vibrate(pattern: number | number[]) {
  try {
    navigator.vibrate?.(pattern);
  } catch {
    /* ignore */
  }
}

async function run(
  native: (h: typeof import("@capacitor/haptics")) => Promise<unknown>,
  web: number | number[]
): Promise<void> {
  if (!FEATURES.HAPTICS) return;
  try {
    if (isNativePlatform()) {
      await native(await import("@capacitor/haptics"));
    } else {
      vibrate(web);
    }
  } catch {
    /* haptic é opcional */
  }
}

/** Toque normal (botões, copiar, partilhar). */
export const hapticTap = (): void => {
  void run((h) => h.Haptics.impact({ style: h.ImpactStyle.Light }), 10);
};

/** Acção concluída com sucesso (saque pedido, prova aprovada…). */
export const hapticSuccess = (): void => {
  void run((h) => h.Haptics.notification({ type: h.NotificationType.Success }), [15, 40, 15]);
};

/** Erro / acção recusada. */
export const hapticError = (): void => {
  void run((h) => h.Haptics.notification({ type: h.NotificationType.Error }), [40, 60, 40]);
};

/** Mudança de selecção (toggles, pickers). */
export const hapticSelect = (): void => {
  void run((h) => h.Haptics.selectionChanged(), 8);
};
