/**
 * Bootstrap do shell nativo (Capacitor).
 * Seguro na web: se não for nativo, não faz nada.
 */
export function isNativePlatform(): boolean {
  try {
    // Evita import estático que parta o bundle web se o módulo falhar
    const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap?.isNativePlatform) return !!cap.isNativePlatform();
  } catch {
    /* ignore */
  }
  return false;
}

export async function initNativeShell(): Promise<void> {
  try {
    const { Capacitor } = await import("@capacitor/core");
    if (!Capacitor.isNativePlatform()) return;

    // Status bar – cor alinhada ao tema ADX
    try {
      const { StatusBar, Style } = await import("@capacitor/status-bar");
      await StatusBar.setStyle({ style: Style.Light });
      await StatusBar.setBackgroundColor({ color: "#f2f3f5" });
    } catch (e) {
      console.warn("[nativeShell] StatusBar:", e);
    }

    // Deep links / app URL aberta (prep. etapa deep links)
    try {
      const { App } = await import("@capacitor/app");
      App.addListener("appUrlOpen", ({ url }) => {
        try {
          const u = new URL(url);
          // Mantém path + query (ex.: /register?r=CODIGO ou /app)
          const path = `${u.pathname}${u.search}${u.hash}` || "/";
          if (path && path !== window.location.pathname + window.location.search) {
            window.history.pushState({}, "", path);
            window.dispatchEvent(new PopStateEvent("popstate"));
          }
        } catch {
          /* ignore URL inválida */
        }
      });
    } catch (e) {
      console.warn("[nativeShell] App:", e);
    }
  } catch (e) {
    console.warn("[nativeShell] init skipped:", e);
  }
}
