/**
 * Badge no ícone (Etapa 5). Nunca lança erro.
 * Nativo: @capawesome/capacitor-badge (nem todos os launchers Android suportam).
 * Web/PWA: Badging API (navigator.setAppBadge), quando existir.
 */
import { FEATURES } from "@/lib/features";
import { isNativePlatform } from "@/lib/nativeShell";

let lastCount: number | null = null;

export async function setBadgeCount(count: number): Promise<void> {
  if (!FEATURES.BADGE) return;
  const n = Math.max(0, Math.floor(Number(count)) || 0);
  if (n === lastCount) return;
  lastCount = n;

  try {
    if (isNativePlatform()) {
      const { Badge } = await import("@capawesome/capacitor-badge");
      const { isSupported } = await Badge.isSupported();
      if (!isSupported) return;
      if (n === 0) {
        await Badge.clear();
        return;
      }
      const perm = await Badge.checkPermissions();
      if (perm.display !== "granted") return; // não pede permissão aqui (o push.ts já pede a de notificações)
      await Badge.set({ count: n });
      return;
    }

    const nav = navigator as Navigator & {
      setAppBadge?: (n?: number) => Promise<void>;
      clearAppBadge?: () => Promise<void>;
    };
    if (n === 0) await nav.clearAppBadge?.();
    else await nav.setAppBadge?.(n);
  } catch {
    /* launcher sem suporte / API indisponível */
  }
}

export const clearBadge = (): Promise<void> => setBadgeCount(0);
