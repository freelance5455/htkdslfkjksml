/**
 * FCM / Push (Capacitor) — etapa 3.
 * Na web: no-op. No Android nativo: pede permissão, obtém token, grava em device_tokens.
 */
import { upsertDeviceToken, disableDeviceToken } from "@/lib/notifications";

const TOKEN_KEY = "adx_fcm_token";

function isNative(): boolean {
  try {
    const w = window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } };
    return !!w.Capacitor?.isNativePlatform?.();
  } catch {
    return false;
  }
}

function platform(): "android" | "ios" | "web" {
  try {
    // Capacitor.getPlatform()
    const cap = (window as unknown as { Capacitor?: { getPlatform?: () => string } }).Capacitor;
    const p = cap?.getPlatform?.() || "web";
    if (p === "ios") return "ios";
    if (p === "android") return "android";
  } catch {
    /* ignore */
  }
  return "web";
}

/**
 * Inicializa push após login (ou sessão existente).
 * Idempotente: pode chamar várias vezes.
 */
export async function registerPushForUser(): Promise<{ ok: boolean; reason?: string }> {
  if (!isNative()) {
    return { ok: false, reason: "not_native" };
  }

  try {
    const { PushNotifications } = await import("@capacitor/push-notifications");

    // Listeners (uma vez por sessão de página)
    const g = window as unknown as { __adxPushBound?: boolean };
    if (!g.__adxPushBound) {
      g.__adxPushBound = true;

      await PushNotifications.addListener("registration", async (token) => {
        const value = (token?.value || "").trim();
        if (!value) return;
        try {
          localStorage.setItem(TOKEN_KEY, value);
        } catch {
          /* ignore */
        }
        const res = await upsertDeviceToken({
          token: value,
          platform: platform() === "ios" ? "ios" : "android",
          appVersion: import.meta.env.VITE_APP_VERSION as string | undefined,
          deviceLabel: platform(),
        });
        if (!res.ok) {
          console.warn("[push] upsertDeviceToken:", res.error);
        }
      });

      await PushNotifications.addListener("registrationError", (err) => {
        console.warn("[push] registrationError:", err);
      });

      // Notificação recebida em foreground — só log nesta etapa
      await PushNotifications.addListener("pushNotificationReceived", (notification) => {
        console.info("[push] received:", notification?.title || notification);
      });

      // Toque na notificação → deep link se data.url / data.path
      await PushNotifications.addListener("pushNotificationActionPerformed", (action) => {
        try {
          const data = (action?.notification?.data || {}) as Record<string, string>;
          const path = data.path || data.url || data.deeplink;
          if (path && typeof path === "string") {
            const target = path.startsWith("http")
              ? new URL(path).pathname + new URL(path).search
              : path.startsWith("/")
                ? path
                : `/${path}`;
            if (target) {
              window.history.pushState({}, "", target);
              window.dispatchEvent(new PopStateEvent("popstate"));
            }
          }
        } catch (e) {
          console.warn("[push] action navigate:", e);
        }
      });
    }

    let perm = await PushNotifications.checkPermissions();
    if (perm.receive === "prompt" || perm.receive === "prompt-with-rationale") {
      perm = await PushNotifications.requestPermissions();
    }
    if (perm.receive !== "granted") {
      return { ok: false, reason: "permission_denied" };
    }

    await PushNotifications.register();
    return { ok: true };
  } catch (e) {
    console.warn("[push] registerPushForUser:", e);
    return { ok: false, reason: "error" };
  }
}

/** Ao logout: desactiva token local no servidor (best-effort). */
export async function unregisterPushOnLogout(): Promise<void> {
  try {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      await disableDeviceToken(token);
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    /* ignore */
  }
}
