/**
 * Contagem de alertas por ler (Etapa 5 — fonte de verdade do badge).
 * O servidor não guarda "lido/não lido" para activity_logs, por isso guardamos
 * localmente (por utilizador) a data do último alerta visto.
 * Na primeira vez inicializa com o alerta mais recente → não inunda o badge com histórico antigo.
 */
import { useCallback, useEffect, useMemo, useState } from "react";

const keyFor = (uid: string) => `adx_alerts_seen:${uid}`;

function readSeen(uid: string | undefined): number | null {
  if (!uid) return null;
  try {
    const v = localStorage.getItem(keyFor(uid));
    const n = v ? Number(v) : NaN;
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
}

function writeSeen(uid: string, ts: number) {
  try {
    localStorage.setItem(keyFor(uid), String(ts));
  } catch {
    /* ignore */
  }
}

export function useUnreadAlerts(userId: string | undefined, logs: { created_at: string }[]) {
  const [seenAt, setSeenAt] = useState<number | null>(() => readSeen(userId));

  useEffect(() => {
    setSeenAt(readSeen(userId));
  }, [userId]);

  const newest = useMemo(
    () => logs.reduce((m, l) => Math.max(m, new Date(l.created_at).getTime() || 0), 0),
    [logs]
  );

  // Primeira utilização: marca o histórico existente como visto
  useEffect(() => {
    if (!userId || seenAt !== null || logs.length === 0) return;
    writeSeen(userId, newest);
    setSeenAt(newest);
  }, [userId, seenAt, logs.length, newest]);

  const unread = useMemo(() => {
    if (seenAt === null) return 0;
    return logs.filter((l) => (new Date(l.created_at).getTime() || 0) > seenAt).length;
  }, [logs, seenAt]);

  const markAllSeen = useCallback(() => {
    if (!userId || newest <= 0) return;
    const next = Math.max(newest, seenAt ?? 0);
    writeSeen(userId, next);
    setSeenAt(next);
  }, [userId, newest, seenAt]);

  return { unread, markAllSeen };
}
