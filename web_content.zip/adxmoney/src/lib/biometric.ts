/**
 * Biometria opcional (Etapa 5) — "desbloquear a app", NÃO é o login da conta.
 * Plugin: @aparajita/capacitor-biometric-auth (gratuito; o @capawesome-team/capacitor-biometrics é Insiders/pago).
 * Preferência guardada por utilizador em localStorage. Default = desligado.
 */
import { FEATURES } from "@/lib/features";
import { isNativePlatform } from "@/lib/nativeShell";

/** Tempo em segundo plano a partir do qual a app volta bloqueada. */
export const BIOMETRIC_LOCK_AFTER_MS = 30_000;

const prefKey = (uid: string) => `adx_biometric_lock:${uid}`;

export function isBiometricEnabled(uid: string | undefined | null): boolean {
  if (!FEATURES.BIOMETRIC || !uid) return false;
  try {
    return localStorage.getItem(prefKey(uid)) === "1";
  } catch {
    return false;
  }
}

export function setBiometricEnabled(uid: string, on: boolean): void {
  try {
    if (on) localStorage.setItem(prefKey(uid), "1");
    else localStorage.removeItem(prefKey(uid));
  } catch {
    /* ignore */
  }
}

/** Nativo + biometria disponível e registada no aparelho. */
export async function isBiometricAvailable(): Promise<boolean> {
  if (!FEATURES.BIOMETRIC || !isNativePlatform()) return false;
  try {
    const { BiometricAuth } = await import("@aparajita/capacitor-biometric-auth");
    const info = await BiometricAuth.checkBiometry();
    return !!info.isAvailable;
  } catch {
    return false;
  }
}

export type BiometricResult = "ok" | "cancelled" | "failed" | "unavailable";

export async function authenticateBiometric(reason = "Desbloquear o ADXmoney"): Promise<BiometricResult> {
  if (!(await isBiometricAvailable())) return "unavailable";
  try {
    const { BiometricAuth } = await import("@aparajita/capacitor-biometric-auth");
    await BiometricAuth.authenticate({
      reason,
      cancelTitle: "Cancelar",
      allowDeviceCredential: true, // PIN/padrão do aparelho como alternativa (evita ficar trancado)
      androidTitle: "ADXmoney",
      androidSubtitle: reason,
    });
    return "ok";
  } catch (e) {
    const code = String((e as { code?: string })?.code ?? "");
    return ["userCancel", "appCancel", "systemCancel"].includes(code) ? "cancelled" : "failed";
  }
}
