import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./globals.css";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { installGlobalErrorLogging } from "@/lib/errorLog";
import { initNativeShell } from "@/lib/nativeShell";

installGlobalErrorLogging();
void initNativeShell();


// Segurança: se o React não assumir o ecrã, remove o splash HTML após 12s
if (typeof window !== "undefined") {
  window.setTimeout(() => {
    const el = document.getElementById("adx-boot-splash");
    if (el) el.remove();
  }, 12_000);
}

createRoot(document.getElementById("root")!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);

// Registar Service Worker (PWA) — só em produção / HTTPS
// O APK carrega o site da Vercel (server.url): o Service Worker dá o shell/login offline.
if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    const isLocal =
      location.hostname === "localhost" ||
      location.hostname === "127.0.0.1";
    if (isLocal && location.protocol !== "https:") {
      // Em localhost HTTP o SW ainda funciona; registamos na mesma
    }
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        // Actualização em background
        reg.update().catch(() => {});
      })
      .catch(() => {
        /* SW opcional — app continua sem offline */
      });
  });
}
