import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { COMPANY, LEGAL_IS_DRAFT, PRIVACY_SECTIONS, TERMS_SECTIONS, TERMS_VERSION } from "@/lib/legal";

/** Páginas públicas /termos e /privacidade (acessíveis sem login, para o registo e para o advogado/autoridades). */
export default function Legal() {
  const { pathname } = useLocation();
  const isPrivacy = pathname.startsWith("/privacidade");
  const sections = isPrivacy ? PRIVACY_SECTIONS : TERMS_SECTIONS;
  const title = isPrivacy ? "Política de Privacidade" : "Termos e Condições";

  useEffect(() => {
    document.title = `${title} · ADXmoney`;
    window.scrollTo({ top: 0 });
  }, [title]);

  return (
    <div className="min-h-[100dvh] px-4 py-6 safe-x safe-top safe-bottom" style={{ background: "var(--adx-surface, #f2f3f5)" }}>
      <div className="mx-auto max-w-2xl space-y-5">
        <nav className="flex items-center justify-between text-xs font-semibold">
          <Link to="/login" className="text-emerald-700">← Voltar</Link>
          <div className="flex gap-4">
            <Link to="/termos" className={isPrivacy ? "text-slate-400" : "text-slate-900"}>Termos</Link>
            <Link to="/privacidade" className={isPrivacy ? "text-slate-900" : "text-slate-400"}>Privacidade</Link>
          </div>
        </nav>

        <header className="space-y-1">
          <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
          <p className="text-xs text-slate-500">
            Versão {TERMS_VERSION} · {COMPANY.name}
          </p>
        </header>

        {LEGAL_IS_DRAFT && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
            Versão de partida, ainda sujeita a revisão jurídica.
          </div>
        )}

        <article className="space-y-5 rounded-2xl bg-white p-5 shadow-sm">
          {sections.map((s) => (
            <section key={s.title} className="space-y-2">
              <h2 className="text-sm font-bold text-slate-900">{s.title}</h2>
              {s.body.map((p, i) => (
                <p key={i} className="text-[13px] leading-relaxed text-slate-600">{p}</p>
              ))}
            </section>
          ))}
        </article>
      </div>
    </div>
  );
}
