import React, { useState, useEffect } from "react";
import { Navigate, useNavigate, useLocation, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Mail, Lock, Loader2, HelpCircle } from "@/components/icons";
import { SplashScreen } from "@/components/SplashScreen";
import { AppLogo } from "@/components/AppLogo";

const Login: React.FC = () => {
  const { session, profile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isFaqOpen, setIsFaqOpen] = useState(false);

  // Pré-preencher e-mail + capturar código de afiliado (?r=)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const refCode = (params.get("r") || params.get("ref") || "").trim().toUpperCase();
    if (refCode) {
      try {
        sessionStorage.setItem("adx_invite_code", refCode);
      } catch {
        /* ignore */
      }
    }

    const fromState = (location.state as { email?: string } | null)?.email;
    if (fromState) {
      setEmail(fromState);
      return;
    }
    try {
      const stored = sessionStorage.getItem("adx_register_email");
      if (stored) {
        setEmail(stored);
        sessionStorage.removeItem("adx_register_email");
      }
    } catch {
      /* ignore */
    }
  }, [location.state, location.search]);

  // Redirecionamento automático caso já esteja autenticado
  if (!authLoading && session && profile) {
    if (profile.first_login) {
      return <Navigate to="/account/setup" replace />;
    }
    if (profile.role === "admin") {
      return <Navigate to="/admin" replace />;
    } else {
      return <Navigate to="/app" replace />;
    }
  }

  if (authLoading) {
    return <SplashScreen message="Verificando acesso..." />;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim();

    if (!cleanEmail || !password) {
      toast.error("Preencha o e-mail e a senha de acesso.");
      return;
    }

    if (typeof navigator !== "undefined" && !navigator.onLine) {
      toast.error("Sem internet. Ligue os dados ou o Wi‑Fi para entrar.");
      return;
    }

    setIsLoggingIn(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: password,
      });

      if (error) {
        console.error("[Login] Erro auth:", error);
        const em = (error.message || "").toLowerCase();
        if (em.includes("6 character") || em.includes("at least 6") || em.includes("password")) {
          // Supabase devolve isto se a senha enviada for curta demais — não é o formulário de registo
          toast.error("E-mail ou senha incorretos. Use a senha temporária completa que recebeu ao criar a conta.");
        } else {
          toast.error("E-mail ou senha incorretos.");
        }
        return;
      }

      console.log("[Login] Sucesso:", data.user.id);
      // O redirect será disparado pelo AuthContext/ProtectedRoute
    } catch (err: any) {
      console.error("[Login] Erro inesperado:", err);
      toast.error("Ocorreu um erro ao entrar.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-[100dvh] flex flex-col justify-center items-center px-5 py-10 select-none safe-x safe-top safe-bottom"
      style={{ background: 'linear-gradient(180deg, rgba(15, 118, 110, 0.06) 0%, transparent 32%), var(--adx-surface, #f2f3f5)' }}>
      <button
        type="button"
        onClick={() => setIsFaqOpen(true)}
        className="absolute top-4 right-4 text-[13px] text-slate-500 flex items-center gap-1.5 py-2 px-3 rounded-xl hover:bg-white/80 transition-colors"
        style={{ marginTop: 'env(safe-area-inset-top, 0px)' }}
      >
        <HelpCircle className="w-4 h-4" />
        Ajuda
      </button>

      <div className="w-full max-w-[340px] animate-fade-up">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-5">
            <AppLogo size="md" />
          </div>
          <h1 className="text-[24px] font-bold text-slate-900 tracking-tight">
            ADXmoney
          </h1>
          <p className="text-[13px] text-slate-500 mt-1.5 font-medium">Entre na sua conta</p>
        </div>

        <form onSubmit={handleLogin} className="card-premium p-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email" className="text-[13px] font-medium text-slate-600">E-mail</Label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isLoggingIn}
                className="pl-10 h-11 input-adx text-[15px]"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-[13px] font-medium text-slate-600">Senha</Label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isLoggingIn}
                className="pl-10 h-11 input-adx text-[15px]"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={isLoggingIn}
            className="w-full h-11 btn-adx text-[15px] mt-2"
          >
            {isLoggingIn ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                A entrar…
              </>
            ) : (
              "Entrar"
            )}
          </Button>

          <p className="text-center text-[13px] text-slate-500 pt-1">
            Ainda não tem conta?{" "}
            <Link
              to="/register"
              className="text-[#0f766e] font-medium hover:underline"
            >
              Criar conta ADX
            </Link>
          </p>
        </form>
      </div>

      <Dialog open={isFaqOpen} onOpenChange={setIsFaqOpen}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Ajuda e suporte</DialogTitle>
            <DialogDescription className="text-[13px] text-slate-500 leading-relaxed">
              Se esqueceu a senha ou não tem acesso, contacte o seu patrocinador ou o administrador da plataforma.
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Login;
