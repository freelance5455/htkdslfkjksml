import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { SplashScreen } from "@/components/SplashScreen";
import { AppLogo } from "@/components/AppLogo";
import { PhoneField } from "@/components/PhoneField";
import { toast } from "sonner";
import { Eye, EyeOff, ArrowRight, User, UserPlus, Link2, Loader2, CheckCircle2 } from "@/components/icons";

export default function AccountSetup() {
  const { user, profile, refreshProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const completedRef = useRef(false);

  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // Form states
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  
  const [tiktok, setTiktok] = useState("");
  const [instagram, setInstagram] = useState("");
  const [youtube, setYoutube] = useState("");
  const [activeTab, setActiveTab] = useState<"tiktok" | "instagram" | "youtube">("tiktok");
  const [inviteCode, setInviteCode] = useState("");

  useEffect(() => {
    // Já concluiu neste ciclo — não reprocessar
    if (completedRef.current) {
      navigate("/app", { replace: true });
      return;
    }

    // Flag de segurança após setup bem-sucedido (evita loop por race do perfil)
    try {
      if (sessionStorage.getItem("adx_setup_done") === "1") {
        completedRef.current = true;
        navigate("/app", { replace: true });
        return;
      }
    } catch {
      /* ignore */
    }

    // Código de afiliado do link (?r=) capturado no login
    try {
      const storedInvite = sessionStorage.getItem("adx_invite_code");
      if (storedInvite) {
        setInviteCode((prev) => prev || storedInvite);
      }
    } catch {
      /* ignore */
    }

    if (profile) {
      if (profile.first_login === false) {
        try {
          sessionStorage.removeItem("adx_setup_done");
        } catch {
          /* ignore */
        }
        navigate("/app", { replace: true });
        return;
      }
      // Dados já conhecidos — preencher automaticamente
      setName((prev) => prev || profile.name || "");
      setPhone((prev) => prev || profile.phone || "");
      setTiktok((prev) => prev || (profile as any).tiktok || "");
      setInstagram((prev) => prev || (profile as any).instagram || "");
      setYoutube((prev) => prev || (profile as any).youtube || "");
    }
  }, [profile, navigate]);

  // Evita flash de splash (depois de TODOS os hooks, para respeitar as Rules of Hooks)
  if (!profile && !user) {
    return <SplashScreen message="Carregando dados..." />;
  }

  const validateStep1 = () => {
    if (!password) {
      toast.error("Por favor, digite a nova palavra-passe.");
      return false;
    }
    if (password.length < 6) {
      toast.error("Defina uma senha definitiva com pelo menos 6 caracteres (só neste primeiro acesso).");
      return false;
    }
    if (password !== confirmPassword) {
      toast.error("As palavras-passe não coincidem.");
      return false;
    }
    return true;
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep1()) {
      setStep(2);
    }
  };

  const handleCompleteSetup = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStep1()) {
      setStep(1);
      return;
    }

    if (!name.trim()) {
      toast.error("Por favor, informe o seu nome completo.");
      return;
    }

    if (!phone.trim()) {
      toast.error("Indique o seu número.");
      return;
    }

    setLoading(true);

    try {
      // 1) Palavra-passe PRIMEIRO: a temporária foi mostrada no ecrã de registo e não pode ficar activa.
      //    Se falhar, não concluímos o setup (idempotente: o utilizador tenta de novo).
      const { error: authError } = await supabase.auth.updateUser({
        password: password,
      });

      // Se um envio anterior já gravou esta mesma palavra-passe (e falhou depois), o Supabase recusa a repetição
      // ("different from the old password"): isso NÃO é erro, seguimos para fechar o primeiro acesso.
      const samePassword =
        (authError as any)?.code === "same_password" ||
        /different from the old password/i.test(authError?.message || "");

      if (authError && !samePassword) {
        console.error("Erro ao atualizar palavra-passe:", authError);
        toast.error(`Não foi possível definir a nova palavra-passe: ${authError.message}`);
        setLoading(false);
        return;
      }

      // 2) RPC — define first_login=false de forma atómica no servidor
      const { data: rpcData, error: rpcError } = await supabase.rpc("complete_account_setup", {
        p_user_id: user?.id,
        p_name: name.trim(),
        p_phone: phone.trim(),
        p_primary_link: null,
        p_invite_code: inviteCode.trim().toUpperCase() || null,
      });

      if (rpcError) {
        console.error("Erro na RPC setup:", rpcError);
        toast.error(`Erro ao salvar dados: ${rpcError.message}`);
        setLoading(false);
        return;
      }

      const result = rpcData as { success: boolean; message: string };
      if (!result?.success) {
        // O servidor diz que o setup já estava concluído (ex.: envio anterior a meio): não prender o utilizador aqui.
        if (/já foi concluído/i.test(result?.message || "")) {
          try {
            sessionStorage.removeItem("adx_setup_done");
          } catch {
            /* ignore */
          }
          await refreshProfile();
          navigate("/app", { replace: true });
          return;
        }
        toast.error(result?.message || "Não foi possível concluir a configuração.");
        setLoading(false);
        return;
      }

      // Confirmar NO SERVIDOR que o primeiro acesso fechou, antes de deixar entrar (evita loop em cada novo login)
      const { data: checkRow } = await supabase
        .from("profiles")
        .select("first_login")
        .eq("id", user?.id)
        .maybeSingle();
      if (checkRow?.first_login !== false) {
        console.error("[AccountSetup] first_login não fechou no servidor", checkRow);
        toast.error("Não foi possível concluir a configuração. Tente novamente; se persistir, contacte o suporte.");
        setLoading(false);
        return;
      }

      // 3) Links sociais (best-effort; não bloqueia conclusão)
      try {
        await supabase
          .from("profiles")
          .update({
            tiktok: tiktok.trim() || null,
            instagram: instagram.trim() || null,
            youtube: youtube.trim() || null,
            updated_at: new Date().toISOString(),
          })
          .eq("id", user?.id);
      } catch {
        /* ignore */
      }

      // 4) Flags locais anti-loop (ProtectedRoute respeita adx_setup_done)
      completedRef.current = true;
      try {
        sessionStorage.setItem("adx_setup_done", "1");
        sessionStorage.removeItem("adx_invite_code");
      } catch {
        /* ignore */
      }

      // 5) Sincronizar perfil ANTES de navegar (elimina race do ProtectedRoute)
      try {
        await refreshProfile();
      } catch {
        /* setup_done + first_login=false no servidor já bastam para não prender */
      }

      toast.success(result.message || "Configuração inicial concluída com sucesso!");
      navigate("/app", { replace: true });
    } catch (err: any) {
      console.error("Erro inesperado no setup:", err);
      toast.error("Ocorreu um erro ao configurar a sua conta. Tente novamente.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[100dvh] flex flex-col justify-center items-center px-4 py-12 font-sans antialiased safe-x safe-top safe-bottom" style={{ background: "linear-gradient(180deg, rgba(15, 118, 110, 0.06) 0%, transparent 32%), var(--adx-surface, #f2f3f5)" }}>
      <div className="max-w-md w-full mb-10 text-center">
        <div className="flex justify-center mb-6">
          <AppLogo size="md" />
        </div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Ativação de Conta</h1>
        <p className="text-xs text-slate-500 mt-2 font-medium ">Configuração Obrigatória de Operador</p>
      </div>

      <Card className="max-w-md w-full card-premium overflow-hidden text-slate-900">
        <CardHeader className="space-y-4 pb-8 pt-8 px-8">
          <div className="flex items-center justify-between text-[11px] text-emerald-600 font-semibold ">
            <span>Passo {step} de 2</span>
            <span>{step === 1 ? "Segurança" : "Dados do Operador"}</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-emerald-600 h-full transition-all duration-500 ease-in-out"
              style={{ width: step === 1 ? "50%" : "100%" }}
            />
          </div>
          <CardTitle className="text-xl font-bold text-slate-900 pt-2 tracking-tight">
            {step === 1 ? "Definir Senha Pessoal" : "Validar Informações"}
          </CardTitle>
          <CardDescription className="text-slate-500 text-xs font-medium leading-relaxed">
            {step === 1
              ? "Substitua a senha provisória enviada pela gestão por uma senha definitiva e segura."
              : "Complete o seu cadastro e indique os links dos perfis onde as campanhas serão distribuídas."}
          </CardDescription>
        </CardHeader>

        {step === 1 ? (
          <form onSubmit={handleNextStep}>
            <CardContent className="space-y-5 px-8">
              <div className="space-y-1.5">
                <Label className="text-[13px] text-slate-600 font-semibold">Nova palavra-passe</Label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="h-11 rounded-xl bg-slate-50 border-slate-200 pr-10"
                    required
                    minLength={6}
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3 text-slate-400">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[13px] text-slate-600 font-semibold">Confirmar palavra-passe</Label>
                <div className="relative">
                  <Input
                    type={showConfirm ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repita a senha"
                    className="h-11 rounded-xl bg-slate-50 border-slate-200 pr-10"
                    required
                    minLength={6}
                  />
                  <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-3 top-3 text-slate-400">
                    {showConfirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="px-8 pb-8 pt-4">
              <Button type="submit" className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold">
                Continuar <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardFooter>
          </form>
        ) : (
          <form onSubmit={handleCompleteSetup}>
            <CardContent className="space-y-5 px-8">
              <div className="space-y-1.5">
                <Label className="text-[13px] text-slate-600 font-semibold flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5" /> Nome completo
                </Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="O seu nome"
                  className="h-11 rounded-xl bg-slate-50 border-slate-200"
                  required
                />
              </div>
              <PhoneField
                id="setup-phone"
                label="Número"
                value={phone}
                onChange={setPhone}
                required
                hint="Indicativo Angola (+244) por predefinição"
              />

              {/* Abas de perfis / links distribuídos */}
              <div className="space-y-3">
                <Label className="text-[13px] text-slate-600 font-semibold flex items-center gap-1.5">
                  <Link2 className="w-3.5 h-3.5" /> Links dos perfis (campanhas)
                </Label>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
                  {((["tiktok", "instagram", "youtube"] as const)).map((tab) => (
                    <button
                      key={tab}
                      type="button"
                      onClick={() => setActiveTab(tab)}
                      className={`flex-1 text-[11px] font-semibold py-2 rounded-lg capitalize transition-colors ${
                        activeTab === tab
                          ? "bg-white text-emerald-700 shadow-sm"
                          : "text-slate-500 hover:text-slate-700"
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
                {activeTab === "tiktok" && (
                  <Input
                    value={tiktok}
                    onChange={(e) => setTiktok(e.target.value)}
                    placeholder="https://tiktok.com/@seu_perfil"
                    className="h-11 rounded-xl bg-slate-50 border-slate-200"
                  />
                )}
                {activeTab === "instagram" && (
                  <Input
                    value={instagram}
                    onChange={(e) => setInstagram(e.target.value)}
                    placeholder="https://instagram.com/seu_perfil"
                    className="h-11 rounded-xl bg-slate-50 border-slate-200"
                  />
                )}
                {activeTab === "youtube" && (
                  <Input
                    value={youtube}
                    onChange={(e) => setYoutube(e.target.value)}
                    placeholder="https://youtube.com/@seu_canal"
                    className="h-11 rounded-xl bg-slate-50 border-slate-200"
                  />
                )}
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Estes 3 links (TikTok, Instagram e YouTube) são os perfis onde as campanhas serão distribuídas. Disponível para assinantes.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-[13px] text-slate-600 font-semibold flex items-center gap-1.5">
                  <UserPlus className="w-3.5 h-3.5" /> Código de convite (opcional)
                </Label>
                <Input
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, "").slice(0, 16))}
                  placeholder="Código do afiliado"
                  maxLength={16}
                  className="h-11 rounded-xl bg-slate-50 border-slate-200 "
                  readOnly={!!inviteCode && inviteCode.length >= 4}
                />
                {inviteCode && (
                  <p className="text-[11px] text-emerald-600 font-medium">Código de convite aplicado automaticamente</p>
                )}
              </div>
            </CardContent>
            <CardFooter className="px-8 pb-8 pt-4 flex flex-col gap-3">
              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" /> A guardar...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" /> Concluir ativação
                  </>
                )}
              </Button>
              <Button
                type="button"
                variant="ghost"
                disabled={loading}
                onClick={() => setStep(1)}
                className="w-full text-slate-500"
              >
                Voltar
              </Button>
            </CardFooter>
          </form>
        )}
      </Card>

      <button
        type="button"
        onClick={() => signOut()}
        className="mt-8 text-xs text-slate-400 hover:text-slate-600"
      >
        Sair da conta
      </button>
    </div>
  );
}
