import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { LevelIcon, ShieldCheck, ArrowLeft, ChevronRight, Layers, Wallet, LogOut, ArrowUpRight, ExternalLink, Loader2, Copy, Plus, Lock, Megaphone, Settings, Bell, MoreVertical, HelpCircle, Shield, Info, Clock, MessageSquare, Eye, EyeOff, ShoppingCart, Users, Share2, Ranking, Priority, Activity, User as UserIcon } from "@/components/icons";
import {
  IconHome,
  IconTasks,
  IconCampaigns,
  IconStore,
  IconWallet,
  IconTrendingUp,
  IconMessage,
  IconHelp,
} from "@/components/icons";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import LoComponent from "@/components/user/EngagementComponent";
import { toast } from "sonner";
import { TermsGate } from "@/components/user/TermsGate";
import { ChangePasswordDialog } from "@/components/user/ChangePasswordDialog";
import { UserCampaignsSection } from "@/components/user/UserCampaignsSection";
import { CommunityTasksSection } from "@/components/user/CommunityTasksSection";
import { ProofReviewList } from "@/components/user/ProofReviewList";
import { HomeDashboard } from "@/components/user/HomeDashboard";
import { BiometricSetting } from "@/components/user/BiometricSetting";
import { hapticError, hapticSuccess, hapticTap } from "@/lib/haptics";
import { shareLink } from "@/lib/share";
import { setBadgeCount } from "@/lib/badge";
import { useUnreadAlerts } from "@/lib/unreadAlerts";

import { SplashScreen } from "@/components/SplashScreen";
import { AppLogo } from "@/components/AppLogo";
import { SubscriptionModal } from "@/components/user/SubscriptionModal";
import { DepositModal } from "@/components/user/DepositModal";
import { IAAdxContentGenerator } from "@/components/user/IAAdxContentGenerator";
import IAAdxCoach from "@/components/user/IAAdxCoach";
import IAAdxSupport from "@/components/user/IAAdxSupport";
import { MemberLevelSection, type LevelInfo, type RankingEntry } from "@/components/user/MemberLevelSection";

type AppTab = "home" | "tasks" | "campaigns" | "affiliate" | "wallet" | "engagement";

/** URL público do site (definir VITE_PUBLIC_URL no Vercel). Em app nativo window.location.origin não serve para partilhar. */
const PUBLIC_APP_URL: string =
  ((import.meta.env.VITE_PUBLIC_URL as string | undefined) || "").replace(/\/$/, "") || window.location.origin;

const APP_TABS: AppTab[] = ["home", "tasks", "campaigns", "affiliate", "wallet", "engagement"];

export default function UserAppPage() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Aba inicial a partir da URL (?tab=) — permite histórico do botão voltar
  const tabFromUrl = searchParams.get("tab") as AppTab | null;
  const initialTab: AppTab =
    tabFromUrl && APP_TABS.includes(tabFromUrl) ? tabFromUrl : "home";

  const [activeTab, setActiveTab] = useState<AppTab>(initialTab);
  /** Separadores já visitados ficam montados (troca instantânea + scroll preservado) */
  const [visitedTabs, setVisitedTabs] = useState<Set<AppTab>>(() => new Set([initialTab]));
  const scrollPositions = useRef<Partial<Record<AppTab, number>>>({});
  const [wallet, setWallet] = useState<{ id: string; balance: number; reserved_balance: number } | null>(null);
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [activityLogs, setActivityLogs] = useState<
    { id: string; action_type?: string; title?: string; details?: string; created_at: string }[]
  >([]);
  const [affiliate, setAffiliate] = useState<any | null>(null);

  const markVisited = (tab: AppTab) => {
    setVisitedTabs((prev) => {
      if (prev.has(tab)) return prev;
      const next = new Set(prev);
      next.add(tab);
      return next;
    });
  };

  /** Muda de aba e regista no histórico do browser (botão físico voltar) */
  const goToTab = (tab: AppTab, replace = false) => {
    const main = document.querySelector(".app-content");
    if (main) scrollPositions.current[activeTab] = main.scrollTop;
    setActiveTab(tab);
    markVisited(tab);
    setSearchParams({ tab }, { replace });
    requestAnimationFrame(() => {
      const el = document.querySelector(".app-content");
      if (!el) return;
      const saved = scrollPositions.current[tab];
      el.scrollTo({ top: typeof saved === "number" ? saved : 0, behavior: "instant" as ScrollBehavior });
    });
  };

  // URL → estado (back / forward do browser ou botão físico)
  useEffect(() => {
    const t = searchParams.get("tab") as AppTab | null;
    if (t && APP_TABS.includes(t) && t !== activeTab) {
      const main = document.querySelector(".app-content");
      if (main) scrollPositions.current[activeTab] = main.scrollTop;
      setActiveTab(t);
      markVisited(t);
      requestAnimationFrame(() => {
        const el = document.querySelector(".app-content");
        if (!el) return;
        const saved = scrollPositions.current[t];
        el.scrollTo({ top: typeof saved === "number" ? saved : 0, behavior: "instant" as ScrollBehavior });
      });
    }
  }, [searchParams]); // eslint-disable-line react-hooks/exhaustive-deps

  // Garante ?tab= na URL sem criar entrada extra no histórico
  useEffect(() => {
    if (!searchParams.get("tab")) {
      setSearchParams({ tab: activeTab }, { replace: true });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const subStatus: string = (profile as any)?.subscription_status || "visitor";
  const subExpiresAt: string | null = (profile as any)?.subscription_expires_at || null;
  // Activa só se o estado for 'active' E a validade (6 meses) ainda não passou
  const isSubscriber = subStatus === "active" && (!subExpiresAt || new Date(subExpiresAt).getTime() > Date.now());
  const subDaysLeft: number | null = subExpiresAt
    ? Math.max(0, Math.ceil((new Date(subExpiresAt).getTime() - Date.now()) / 86400000))
    : null;
  const SUB_RENEW_WINDOW_DAYS = 30;
  const subExpiringSoon = isSubscriber && subDaysLeft !== null && subDaysLeft <= SUB_RENEW_WINDOW_DAYS;
  const subExpired = !isSubscriber && (subStatus === "expired" || (subStatus === "active" && !!subExpiresAt));
  const subExpiresLabel = subExpiresAt ? new Date(subExpiresAt).toLocaleDateString("pt-PT") : "";
  const subModalShownRef = useRef(false);

  // Função auxiliar para mudar aba com verificação de assinatura
  const handleTabChange = (tab: AppTab) => {
    const isRestricted = tab === "tasks" || tab === "campaigns" || tab === "affiliate";
    if (isRestricted && !isSubscriber) {
      setIsSubscriptionModalOpen(true);
      toast.error("Ativação Necessária", {
        description: "Esta funcionalidade é exclusiva para membros com assinatura ativa.",
      });
      return;
    }
    goToTab(tab);
  };

  /** Navegação a partir da Home (respeita restrições de assinante) */
  const handleHomeNavigate = (tab: Exclude<AppTab, "home">) => {
    handleTabChange(tab);
  };
  const [tasksSubTab, setTasksSubTab] = useState<"community" | "financial">("community");

  const [loading, setLoading] = useState(true);
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  const [dataUpdatedAt, setDataUpdatedAt] = useState<number | null>(null);
  const [homeRefreshing, setHomeRefreshing] = useState(false);
  const [currency, setCurrency] = useState<"USD" | "AOA" | "EUR" | "BRL">("USD");

  const EXCHANGE_RATES = {
    AOA: 950,
    USD: 1,
    EUR: 0.92,
    BRL: 5.40,
  };

  const convert = (amountKz: number) => {
    // Primeiro convertemos de Kz para USD (base), depois para a moeda destino
    const amountUsd = amountKz / 950;
    return amountUsd * EXCHANGE_RATES[currency];
  };

  const formatCurrency = (amountKz: number) => {
    const converted = convert(amountKz);
    const symbols = { AOA: "Kz", USD: "$", EUR: "€", BRL: "R$" };
    
    // Formatação profissional baseada na moeda
    const formatter = new Intl.NumberFormat("pt-PT", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    if (currency === "AOA") return `${formatter.format(converted)} Kz`;
    return `${symbols[currency]} ${formatter.format(converted)}`;
  };

  // Profile overlay / Settings Modal
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  // Alertas por ler → badge no ícone (fora do render: só reage a mudanças da contagem)
  const { unread: unreadAlerts, markAllSeen } = useUnreadAlerts(user?.id, activityLogs);
  useEffect(() => {
    void setBadgeCount(unreadAlerts);
  }, [unreadAlerts]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isFaqOpen, setIsFaqOpen] = useState(false);
  const [isPasswordOpen, setIsPasswordOpen] = useState(false);

  // Espelho de saldo ocultável na home
  const [hideBalanceHome, setHideBalanceHome] = useState(false);
  const [profileName, setProfileName] = useState("");
  const [profilePhone, setProfilePhone] = useState("");
  const [profileLink, setProfileLink] = useState("");
  const [profileTiktok, setProfileTiktok] = useState("");
  const [profileInstagram, setProfileInstagram] = useState("");
  const [profileYoutube, setProfileYoutube] = useState("");
  const [profileLanguage, setProfileLanguage] = useState<"pt" | "en" | "fr">("pt");
  const [updatingProfile, setUpdatingProfile] = useState(false);

  // Simulador de ganhos
  const [simulatorValue, setSimulatorValue] = useState(1);
  const EARNING_PER_MEMBER = 500;

  // Modal de Assinatura (para não assinantes)
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);

  // Ideias para postar
  const [isIAOpen, setIsIAOpen] = useState(false);
  const [iaDefaultPlatform, setIaDefaultPlatform] = useState<"TikTok" | "Instagram" | "YouTube">("TikTok");
  const [iaDefaultObjective, setIaDefaultObjective] = useState<"followers" | "engagement" | "affiliate" | "campaign">("engagement");

  // O que fazer hoje
  const [isCoachOpen, setIsCoachOpen] = useState(false);

  // Ajuda
  const [isAISupportOpen, setIsAISupportOpen] = useState(false);

  // Sistema de Níveis & Ranking
  const [levelInfo, setLevelInfo] = useState<LevelInfo | null>(null);
  const [ranking, setRanking] = useState<RankingEntry[]>([]);
  const [levelLoading, setLevelLoading] = useState(false);
  const [showLevelSection, setShowLevelSection] = useState(false);

  const openIA = (
    objective: "followers" | "engagement" | "affiliate" | "campaign" = "engagement",
    platform: "TikTok" | "Instagram" | "YouTube" = "TikTok"
  ) => {
    setIaDefaultObjective(objective);
    setIaDefaultPlatform(platform);
    setIsIAOpen(true);
  };

  // Remitly dataset
  const REMITLY_COUNTRIES = {
    "Angola": {
      code: "+244",
      cities: ["Luanda", "Benguela", "Huambo", "Lubango", "Cabinda", "Soyo", "Malanje", "Kuito", "Uíge", "Namibe"]
    },
    "Brasil": {
      code: "+55",
      cities: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador", "Fortaleza", "Belo Horizonte", "Curitiba", "Manaus", "Recife", "Porto Alegre"]
    },
    "Portugal": {
      code: "+351",
      cities: ["Lisboa", "Porto", "Amadora", "Braga", "Coimbra", "Funchal", "Setúbal", "Vila Nova de Gaia", "Almada"]
    },
    "Moçambique": {
      code: "+258",
      cities: ["Maputo", "Matola", "Beira", "Nampula", "Chimoio", "Nacala", "Quelimane", "Tete"]
    },
    "Cabo Verde": {
      code: "+238",
      cities: ["Praia", "Mindelo", "Santa Maria", "Espargos", "Assomada", "Porto Novo"]
    }
  } as const;

  type RemitlyCountryKey = keyof typeof REMITLY_COUNTRIES;

  // Withdrawal form
  const [withdrawMethod, setWithdrawMethod] = useState<string>("express");
  const [withdrawAmount, setWithdrawAmount] = useState<string>("");
  const [withdrawIban, setWithdrawIban] = useState("");
  const [withdrawHolder, setWithdrawHolder] = useState("");
  const [withdrawPhone, setWithdrawPhone] = useState("");
  
  // Remitly specific fields
  const [remitlyFullName, setRemitlyFullName] = useState("");
  const [remitlyCountry, setRemitlyCountry] = useState<RemitlyCountryKey>("Angola");
  const [remitlyCity, setRemitlyCity] = useState("Luanda");
  const [remitlyPhone, setRemitlyPhone] = useState("+244 ");
  const [remitlyEmail, setRemitlyEmail] = useState("");
  const [remitlyDeliveryMethod, setRemitlyDeliveryMethod] = useState("Conta bancária");
  const [remitlyCurrency, setRemitlyCurrency] = useState("Kz (AOA)");
  
  const [isRequestingWithdraw, setIsRequestingWithdraw] = useState(false);
  const [hideTransactions, setHideTransactions] = useState(false);

  const handleRemitlyCountryChange = (country: RemitlyCountryKey) => {
    setRemitlyCountry(country);
    const countryData = REMITLY_COUNTRIES[country];
    if (countryData) {
      setRemitlyCity(countryData.cities[0]);
      setRemitlyPhone(countryData.code + " ");
    }
  };

  useEffect(() => {
    const checkSuspension = async () => {
      if (!user) return;

      const { data: profileData } = await supabase
        .from("profiles")
        .select("suspended_until, is_active")
        .eq("id", user.id)
        .single();

      if (profileData) {
        const now = new Date();
        const suspendedUntil = profileData.suspended_until ? new Date(profileData.suspended_until) : null;

        if (suspendedUntil && suspendedUntil > now) {
          toast.error("Conta suspensa temporariamente por violação de diretrizes.", {
            duration: 10000,
          });
        } else if (suspendedUntil && suspendedUntil <= now && !profileData.is_active) {
          // Reactivação só via admin/RPC — cliente não altera is_active
          console.info("[UserApp] Suspensão expirada; aguarde reativação administrativa.");
          toast.success("Sua conta foi reativada após o período de suspensão.");
          await refreshProfile();
        }
      }
    };
    checkSuspension();
  }, [user?.id]);

  useEffect(() => {
    if (profile) {
      const p = profile as any;
      setProfileName(p.name || "");
      setProfilePhone(p.phone || "");
      setProfileLink(p.primary_link || "");
      setProfileTiktok(p.tiktok || "");
      setProfileInstagram(p.instagram || "");
      setProfileYoutube(p.youtube || "");
      setProfileLanguage((p.preferred_language as "pt" | "en" | "fr") || "pt");
      setWithdrawHolder(p.name || "");
      setWithdrawPhone(p.phone || "");
      setRemitlyFullName(p.name || "");
      if (p.phone) setRemitlyPhone(p.phone);

      // Se não for assinante e estiver nas abas restritas, redireciona para a Home
      if (p.subscription_status !== "active") {
        setActiveTab((prev) => {
          if (prev === "tasks" || prev === "campaigns" || prev === "affiliate") {
            setSearchParams({ tab: "home" }, { replace: true });
            return "home";
          }
          return prev;
        });
        // Modal de ativação só uma vez por sessão (evita loop a cada refresh de perfil)
        if (!subModalShownRef.current) {
          subModalShownRef.current = true;
          setTimeout(() => {
            setIsSubscriptionModalOpen(true);
          }, 600);
        }
      }
    }
  }, [profile]);

  // Marca a participação numa campanha atribuída como concluída (não paga: conta para a partilha do resultado)
  const handleCampaignDone = async (campaignId: string) => {
    try {
      const { error } = await supabase.rpc("complete_campaign_participation", { p_campaign_id: campaignId });
      if (error) throw error;
      hapticSuccess();
      toast.success("Concluída! Será paga quando a campanha tiver resultado financeiro.");
      await loadUserData(false, { silent: true });
    } catch (err: any) {
      hapticError();
      toast.error(err?.message || "Não foi possível concluir.");
    }
  };

  // Percentagens/valores da economia (editáveis pelo admin) mostrados ao afiliado
  const [econ, setEcon] = useState<Record<string, number>>({});
  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      try {
        const { data } = await supabase.from("economy_settings").select("key, value");
        const m: Record<string, number> = {};
        (data || []).forEach((r: any) => { m[r.key] = Number(r.value); });
        setEcon(m);
      } catch { /* usa valores por defeito */ }
    })();
  }, [user?.id]);

  // Ao abrir: o servidor expira assinaturas vencidas; se o estado mudou, recarrega o perfil
  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      try {
        const { data } = await supabase.rpc("refresh_my_subscription");
        const st = (data as any)?.status;
        if (st && st !== (profile as any)?.subscription_status) refreshProfile();
      } catch (e) {
        console.warn("refresh_my_subscription indisponível:", e);
      }
    })();
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadUserData = async (_showSplash = false, opts?: { silent?: boolean }) => {
    if (!user) return;
    // Splash a ecrã inteiro só no primeiro carregamento da sessão
    if (isFirstLoad) setLoading(true);
    else if (!opts?.silent) setHomeRefreshing(true);
    try {
      // Todas as leituras em paralelo (antes: 7 pedidos em série = 7 round-trips na rede móvel)
      const [walletRes, txRes, logRes, assignRes, affRes, levelRes, rankRes] = await Promise.all([
        supabase.from("wallets").select("*").eq("user_id", user.id).maybeSingle(),
        supabase
          .from("wallet_transactions")
          .select("id, type, amount, description, status, created_at")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(100),
        supabase
          .from("activity_logs")
          .select("id, action_type, title, details, created_at")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(20),
        supabase
          .from("campaign_assignments")
          .select(`id, status, campaign_id, campaigns (*)`)
          .eq("user_id", user.id),
        supabase.from("affiliate_profiles").select("*").eq("user_id", user.id).maybeSingle(),
        supabase.rpc("get_my_level_info"),
        supabase.rpc("get_member_ranking", { p_limit: 20 }),
      ]);

      if (walletRes.data) setWallet(walletRes.data);
      if (txRes.data) setTransactions(txRes.data);
      if (logRes.data) setActivityLogs(logRes.data);

      if (assignRes.data) {
        const mapped = assignRes.data
          .filter((a: any) => a.campaigns)
          .map((a: any) => ({
            ...a.campaigns,
            assignment_id: a.id,
            assignment_status: a.status,
          }));
        setCampaigns(mapped);
      }

      if (affRes.data) setAffiliate(affRes.data);

      // Nível & ranking: se a migração 006 não existir, ignorar silenciosamente
      if (!levelRes.error && levelRes.data) setLevelInfo(levelRes.data as LevelInfo);
      if (!rankRes.error && rankRes.data) setRanking(rankRes.data as RankingEntry[]);
    } catch (err: any) {
      console.error("Erro ao carregar dados:", err);
    } finally {
      setLoading(false);
      setIsFirstLoad(false);
      setHomeRefreshing(false);
      setDataUpdatedAt(Date.now());
    }
  };

  // Separadores ficam montados: ao voltar a um deles, actualizar saldo/movimentos se os dados têm > 30 s
  useEffect(() => {
    if (isFirstLoad || !user) return;
    if (dataUpdatedAt && Date.now() - dataUpdatedAt > 30_000) {
      loadUserData(false, { silent: activeTab !== "home" });
    }
  }, [activeTab]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSetCustomCode = async (code: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.rpc("set_custom_affiliate_code", {
        p_code: code,
      });
      if (error) throw error;
      toast.success("Código personalizado atualizado!");
      return true;
    } catch (err: any) {
      toast.error(err.message || "Erro ao definir código personalizado");
      return false;
    }
  };

  const refreshLevelData = async () => {
    if (!user) return;
    setLevelLoading(true);
    try {
      const { data: levelData } = await supabase.rpc("get_my_level_info");
      if (levelData) setLevelInfo(levelData as LevelInfo);
      const { data: rankData } = await supabase.rpc("get_member_ranking", { p_limit: 20 });
      if (rankData) setRanking(rankData as RankingEntry[]);
    } catch {
      /* ignore */
    } finally {
      setLevelLoading(false);
    }
  };

  useEffect(() => {
    loadUserData();
  }, [user?.id]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setUpdatingProfile(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          name: profileName.trim(),
          phone: profilePhone.trim(),
          primary_link: profileLink.trim(),
          tiktok: profileTiktok.trim(),
          instagram: profileInstagram.trim(),
          youtube: profileYoutube.trim(),
          preferred_language: profileLanguage,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user.id);

      if (error) throw error;
      toast.success("Dados do perfil atualizados com sucesso!");
      await refreshProfile();
      setIsSettingsOpen(false);
    } catch (err: any) {
      toast.error("Erro ao atualizar perfil: " + err.message);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleRequestWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);

    if (!amount || amount <= 0) {
      toast.error("Insira um valor válido para o saque.");
      return;
    }

    if (amount < 1000) {
      toast.error("Valor mínimo de saque: 1.000 Kz.");
      return;
    }

    if (!wallet || amount > wallet.balance) {
      toast.error("Saldo insuficiente para este valor.");
      return;
    }

    setIsRequestingWithdraw(true);
    try {
      const details: any = {};
      if (withdrawMethod === 'iban') {
        details.titular = withdrawHolder;
        details.iban = withdrawIban;
      } else if (withdrawMethod === 'express' || withdrawMethod === 'unitel') {
        details.telefone = withdrawPhone;
      } else if (withdrawMethod === 'remitly') {
        details.remitly = {
          nome_beneficiario: remitlyFullName,
          pais: remitlyCountry,
          cidade: remitlyCity,
          telefone: remitlyPhone,
          email: remitlyEmail,
          metodo_recebimento: remitlyDeliveryMethod,
          moeda_recebimento: remitlyCurrency
        };
      }

      const { data, error: wError } = await supabase.rpc("request_withdrawal", {
        p_amount: amount,
        p_method: withdrawMethod.toUpperCase(),
        p_payment_details: details
      });

      if (wError) throw wError;
      if (data && typeof data === "object" && (data as { success?: boolean }).success === false) {
        throw new Error((data as { error?: string }).error || "Não foi possível solicitar o saque.");
      }

      hapticSuccess();
      toast.success("Solicitação de levantamento enviada com sucesso!");
      setWithdrawAmount("");
      loadUserData();
    } catch (err: any) {
      hapticError();
      toast.error("Erro ao solicitar levantamento: " + err.message);
    } finally {
      setIsRequestingWithdraw(false);
    }
  };

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      hapticTap();
      toast.success(`${label} copiado!`);
    } catch {
      toast.error("Não foi possível copiar. Copie manualmente.");
    }
  };

  /** Código público de convite: personalizado (Gold+) ou referral padrão */
  const getInviteCode = () => {
    const custom = (profile as { custom_affiliate_code?: string | null })?.custom_affiliate_code;
    const standard = profile?.referral_code;
    return (custom || standard || "").trim();
  };

  const shareAppNative = async () => {
    const referralCode = getInviteCode();
    if (!referralCode) {
      toast.error("Conclua o setup da conta para obter o seu link de convite.");
      return;
    }
    const inviteLink = `${PUBLIC_APP_URL}/register?r=${encodeURIComponent(referralCode)}`;

    hapticTap();
    const result = await shareLink({
      title: "Convite ADXmoney",
      text: `Junte-se a mim no ADXmoney! Use o meu código de convite: ${referralCode}`,
      url: inviteLink,
      dialogTitle: "Partilhar link de convite",
    });
    if (result === "copied") {
      toast.success("Link de Convite copiado!");
    } else if (result === "failed") {
      toast.error("Não foi possível partilhar. Copie o link manualmente.");
    }
  };

  const getReferralLink = () => {
    const code = getInviteCode();
    if (!code) return PUBLIC_APP_URL + "/register";
    return `${PUBLIC_APP_URL}/register?r=${encodeURIComponent(code)}`;
  };

  // Respeita flag de setup recém-concluído para evitar loop por race do perfil
  let setupJustDone = false;
  try {
    setupJustDone = sessionStorage.getItem("adx_setup_done") === "1";
  } catch {
    /* ignore */
  }
  if (profile?.first_login && !setupJustDone) {
    return <Navigate to="/account/setup" replace />;
  }

  // Splash só no boot real (primeiro load). Refreshes de dados não cobrem o ecrã.
  if (isFirstLoad) {
    return <SplashScreen message="A preparar a conta…" />;
  }

  return (
    <div className="app-shell text-slate-900 font-sans antialiased overflow-x-hidden select-none">

      {/* Header */}
      <header className="app-header px-4 pb-2.5 flex items-center justify-between safe-x">
        <div className="flex items-center gap-2.5 min-w-0">
          <AppLogo size="xs" className="w-9 h-9 rounded-xl shrink-0" />
          <div className="min-w-0">
            <p className="text-[14px] font-bold text-slate-900 leading-tight tracking-tight">
              ADXmoney
            </p>
            <p className="text-[11px] text-slate-500 leading-tight flex items-center gap-1.5 truncate">
              <span className="truncate">{profile?.name?.split(' ')[0] || "Utilizador"}</span>
              {levelInfo && (
                <span className={`badge-level badge-${levelInfo.member_level} shrink-0`}>
                  {levelInfo.member_level}
                </span>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value as any)}
            className="appearance-none text-[11px] font-medium text-slate-600 bg-white border border-slate-200 rounded-lg px-2 py-1.5 outline-none cursor-pointer"
          >
            <option value="USD">USD</option>
            <option value="AOA">AOA</option>
            <option value="EUR">EUR</option>
            <option value="BRL">BRL</option>
          </select>

          <button
            onClick={() => setHideBalanceHome(!hideBalanceHome)}
            className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 pressable"
          >
            {hideBalanceHome ? <Eye className="w-3.5 h-3.5 text-slate-400" /> : <EyeOff className="w-3.5 h-3.5 text-slate-400" />}
            <span className="text-[12px] font-semibold text-slate-800 tabular-nums">
              {hideBalanceHome ? "••••" : formatCurrency(wallet?.balance || 0)}
            </span>
          </button>

          <button
            onClick={() => setIsMenuOpen(true)}
            className="w-11 h-11 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 pressable"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Conteúdo principal com scroll nativo */}
      <main className="app-content w-full mx-auto max-w-lg px-4 pt-4 space-y-6">

        {(subExpiringSoon || subExpired) && (
          <button
            type="button"
            onClick={() => setIsSubscriptionModalOpen(true)}
            className="w-full text-left rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 flex items-center justify-between gap-3"
          >
            <div className="min-w-0">
              <p className="text-[13px] font-semibold text-amber-900">
                {subExpired ? "A sua assinatura expirou" : `A sua assinatura expira em ${subDaysLeft} ${subDaysLeft === 1 ? "dia" : "dias"}`}
              </p>
              <p className="text-[11px] text-amber-700">
                {subExpired
                  ? "Renove para voltar a aceder a tarefas, campanhas e afiliados."
                  : `Válida até ${subExpiresLabel}. Renove agora: os novos meses somam-se aos dias que ainda tem.`}
              </p>
            </div>
            <span className="shrink-0 text-[11px] font-bold text-amber-900 bg-amber-100 rounded-xl px-3 py-2">Renovar</span>
          </button>
        )}

        {/* 0. ABA: HOME — montada se visitada; escondida quando outra aba está activa */}
        {visitedTabs.has("home") && (
          <div className={activeTab === "home" ? "tab-enter" : "hidden"} aria-hidden={activeTab !== "home"}>
          <HomeDashboard
            userName={profile?.name}
            userId={user?.id}
            isSubscriber={!!isSubscriber}
            balance={wallet?.balance || 0}
            reservedBalance={wallet?.reserved_balance || 0}
            transactions={transactions}
            campaigns={campaigns}
            affiliate={affiliate}
            formatCurrency={formatCurrency}
            onNavigate={handleHomeNavigate}
            onOpenSubscribe={() => setIsSubscriptionModalOpen(true)}
            onOpenDeposit={() => setIsDepositModalOpen(true)}
            dataUpdatedAt={dataUpdatedAt}
            isRefreshing={homeRefreshing}
            onRefresh={() => loadUserData(false)}
            hideBalance={hideBalanceHome}
            onToggleHideBalance={() => setHideBalanceHome((v) => !v)}
          />
          </div>
        )}

        {/* 1. ABA: TAREFAS */}
        {visitedTabs.has("tasks") && (
          <div className={`space-y-6 ${activeTab === "tasks" ? "tab-enter" : "hidden"}`} aria-hidden={activeTab !== "tasks"}>
            {/* Seletor Segmentado */}
            <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
              <button
                onClick={() => setTasksSubTab("community")}
                className={`flex-1 py-2.5 text-[13px] font-semibold rounded-xl transition-all ${
                  tasksSubTab === "community"
                    ? "bg-emerald-600 text-white shadow-sm "
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                Comunitárias
              </button>
              <button
                onClick={() => setTasksSubTab("financial")}
                className={`flex-1 py-2.5 text-[13px] font-semibold rounded-xl transition-all ${
                  tasksSubTab === "financial"
                    ? "bg-emerald-600 text-white shadow-sm "
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                Tarefas Financeiras
              </button>
            </div>

            {tasksSubTab === "financial" ? (
              <div className="space-y-6">
                <div className="px-1">
                  <h2 className="text-xl font-bold text-slate-900 flex items-center gap-3">
                    <Layers className="w-6 h-6 text-emerald-600" /> Atividades Disponíveis
                  </h2>
                  <p className="text-[15px] text-slate-500 mt-2 font-normal">Campanhas atribuídas a si. O pagamento só existe quando a campanha gera resultado financeiro, e é partilhado em partes iguais por todos os participantes que concluírem.</p>
                </div>

                {campaigns.length === 0 ? (
                  <div className="bg-white border border-slate-200 rounded-[24px] py-20 text-center shadow-sm">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Layers className="w-10 h-10 text-slate-300" />
                    </div>
                    <p className="text-base text-slate-700 font-semibold tracking-tight">Sem tarefas financeiras no momento</p>
                    <p className="text-sm text-slate-400 mt-2">Aguarde novas oportunidades de ganhos.</p>
                  </div>
                ) : (
                  <div className="grid gap-6 sm:grid-cols-2">
                    {campaigns.map((c) => (
                      <div key={c.id} className="bg-white border border-slate-100 rounded-[24px] p-6 flex flex-col justify-between hover:shadow-md hover:transition-all shadow-md group">
                        <div>
                          <div className="flex justify-between items-start mb-4">
                            <Badge className="text-[11px] font-semibold border-none text-emerald-700 bg-emerald-50 px-3 py-1 rounded-lg">
                              {c.platform}
                            </Badge>
                            <span className="text-[12px] font-bold text-emerald-700 bg-emerald-50 rounded-lg px-3 py-1 text-right leading-tight">
                              Partilha dos resultados
                            </span>
                          </div>
                          <h3 className="text-[15px] font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">{c.title}</h3>
                          <p className="text-sm text-slate-500 mt-3 line-clamp-2 leading-relaxed font-normal">{c.description}</p>
                        </div>
                        
                        <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between">
                          <Badge className={c.assignment_status === 'COMPLETED' ? 'bg-slate-100 text-slate-500 border-none px-3 py-1 font-semibold' : 'bg-lime-400 text-slate-900 border-none px-3 py-1 font-bold'}>
                            {c.assignment_status === 'COMPLETED' ? 'Concluída · a aguardar resultado' : 'Em curso'}
                          </Badge>
                          <div className="flex gap-2">
                            <Button asChild size="sm" variant="outline" className="h-10 text-[13px] font-semibold rounded-xl px-4">
                              <a href={c.target_url} target="_blank" rel="noreferrer">
                                Abrir link <ExternalLink className="w-4 h-4 ml-2" />
                              </a>
                            </Button>
                            {c.assignment_status !== 'COMPLETED' && (
                              <Button
                                size="sm"
                                onClick={() => handleCampaignDone(c.id)}
                                className="h-10 text-[13px] font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-4"
                              >
                                Concluí
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <CommunityTasksSection active={activeTab === "tasks"} />
            )}
          </div>
        )}

        {/* 2. ABA: CAMPANHAS */}
        {visitedTabs.has("campaigns") && user && (
          <div className={`space-y-6 ${activeTab === "campaigns" ? "tab-enter" : "hidden"}`} aria-hidden={activeTab !== "campaigns"}>
            <UserCampaignsSection
              userId={user.id}
              active={activeTab === "campaigns"}
              onNeedDeposit={() => {
                setIsDepositModalOpen(true);
                toast.info("Saldo insuficiente. Carregue a conta para solicitar campanhas.");
              }}
            />
          </div>
        )}

        {/* 3. ABA: AFILIADOS */}
        {visitedTabs.has("affiliate") && (
          <div className={`space-y-4 pb-4 ${activeTab === "affiliate" ? "tab-enter" : "hidden"}`} aria-hidden={activeTab !== "affiliate"}>
            {showLevelSection ? (
              <>
                <Button
                  variant="ghost"
                  onClick={() => setShowLevelSection(false)}
                  className="h-11 text-[13px] font-medium text-slate-600 -ml-2"
                >
                  <ArrowLeft className="w-4 h-4 mr-1.5" /> Voltar a Afiliados
                </Button>
                <MemberLevelSection
                  levelInfo={levelInfo}
                  ranking={ranking}
                  loading={levelLoading}
                  formatCurrency={formatCurrency}
                  onSetCustomCode={handleSetCustomCode}
                  onRefresh={refreshLevelData}
                />
              </>
            ) : (
              <>
            <div className="flex items-start justify-between gap-2">
              <div>
                <h2 className="text-[17px] font-semibold text-slate-900">Afiliados</h2>
                <p className="text-[13px] text-slate-500 mt-0.5">Convide e receba comissões</p>
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => openIA("affiliate")}
                className="h-10 min-h-[40px] rounded-xl border-slate-200 text-[12px] font-medium shrink-0"
              >
                <IconMessage className="w-3.5 h-3.5 mr-1 text-[#0f766e]" />
                Ideias
              </Button>
            </div>

            {/* Badge de nível + atalho */}
            {levelInfo && (
              <button
                onClick={() => setShowLevelSection(true)}
                className="w-full bg-[#0b5f58] rounded-2xl p-4 flex items-center justify-between gap-3 text-left pressable shadow-sm border border-teal-900/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
                    <LevelIcon level={levelInfo.member_level} className="w-5 h-5 text-amber-200" />
                  </div>
                  <div>
                    <p className="text-[11px] text-white/70 font-medium">
                      Nível · {levelInfo.rank_position ? `#${levelInfo.rank_position}` : "—"}
                    </p>
                    <p className="text-[15px] font-semibold text-white capitalize tracking-tight">
                      {levelInfo.member_level}
                      {levelInfo.priority_withdrawal && (
                        <span className="ml-2 text-[11px] text-amber-200 font-medium tracking-wide">
                          · Prioritário
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <span className="flex items-center gap-0.5 text-[12px] text-white/80 font-semibold">Ver <ChevronRight className="w-3.5 h-3.5" /></span>
              </button>
            )}

            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div>
                <p className="text-[12px] text-slate-500">Comissões ganhas</p>
                <p className="text-[22px] font-semibold text-slate-900 tabular-nums mt-0.5">
                  {formatCurrency(affiliate?.total_earned || 0)}
                </p>
              </div>
              <div className="text-right">
                <p className="text-[12px] text-slate-500">Rede</p>
                <p className="text-[15px] font-semibold text-slate-800 mt-0.5">
                  {affiliate?.total_referrals || 0}{" "}
                  <span className="font-normal text-slate-500 text-[13px]">membros</span>
                </p>
              </div>
            </div>

            <div className="bg-emerald-50/60 border border-emerald-100 rounded-2xl p-4 space-y-2">
              <p className="text-[13px] font-semibold text-emerald-900">Quanto ganha com cada indicado</p>
              <ul className="space-y-1 text-[12px] text-emerald-900/80">
                <li>• <strong>{econ.aff_subscription_pct ?? 20}%</strong> da assinatura (renovações: {econ.aff_subscription_renewal_pct ?? 10}%)</li>
                <li>• <strong>{econ.aff_engagement_pct ?? 10}%</strong> de cada pedido na loja de engajamento</li>
                <li>• <strong>{econ.aff_campaign_request_pct ?? 10}%</strong> de cada campanha coletiva paga</li>
              </ul>
              <p className="text-[11px] text-emerald-800/70">
                Só é pago quando o indicado paga, e só enquanto a sua assinatura estiver activa. O indicado recebe {econ.referred_bonus_aoa ?? 250} Kz de bónus ao activar a assinatura.
              </p>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 space-y-3">
              <p className="text-[13px] font-medium text-slate-700">Código de indicação</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-3.5 py-2.5">
                  <span className="font-mono text-[15px] font-semibold text-slate-900 tracking-wide">
                    {getInviteCode() || "—"}
                  </span>
                </div>
                <Button
                  onClick={() => copyToClipboard(getInviteCode() || "", "Código")}
                  variant="outline"
                  className="h-10 px-3 rounded-xl border-slate-200 text-[13px] font-medium shrink-0"
                >
                  <Copy className="w-3.5 h-3.5 mr-1.5" />
                  Copiar
                </Button>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => copyToClipboard(getReferralLink(), "Link")}
                  variant="outline"
                  className="flex-1 h-10 rounded-xl border-slate-200 text-[13px] font-medium"
                >
                  Copiar link
                </Button>
                <Button
                  onClick={shareAppNative}
                  className="flex-1 h-10 rounded-xl bg-[#0f766e] hover:bg-[#0d9488] text-white text-[13px] font-medium"
                >
                  <Share2 className="w-3.5 h-3.5 mr-1.5" />
                  Partilhar
                </Button>
              </div>
              <p className="text-[12px] text-slate-400 leading-snug">
                O convidado deve usar este código no primeiro acesso para ficar na sua rede.
              </p>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-[13px] font-medium text-slate-700">Simulador</p>
                <p className="text-[12px] text-slate-500">
                  {simulatorValue.toLocaleString()} indicações
                </p>
              </div>
              <input
                type="range"
                min="1"
                max="2000"
                step="5"
                value={simulatorValue}
                onChange={(e) => setSimulatorValue(parseInt(e.target.value))}
                className="w-full accent-[#0f766e] cursor-pointer h-1.5 bg-slate-100 rounded-full"
              />
              <div className="flex items-center justify-between pt-1">
                <span className="text-[13px] text-slate-500">Estimativa</span>
                <span className="text-[15px] font-semibold text-slate-900 tabular-nums">
                  {formatCurrency(simulatorValue * EARNING_PER_MEMBER)}
                </span>
              </div>
            </div>
              </>
            )}
          </div>
        )}

        {/* ABA: LOJA */}
        {visitedTabs.has("engagement") && (
          <div className={`space-y-6 ${activeTab === "engagement" ? "tab-enter" : "hidden"}`} aria-hidden={activeTab !== "engagement"}>
            <ProofReviewList mode="creator" userId={user?.id} active={activeTab === "engagement"} />
            <LoComponent
              active={activeTab === "engagement"}
              selectedCurrency={currency}
              exchangeRates={EXCHANGE_RATES}
              formatCurrency={formatCurrency}
              onOpenIA={() => openIA("engagement")}
            />
          </div>
        )}

        {/* 4. ABA: CARTEIRA */}
        {visitedTabs.has("wallet") && (
          <div className={`space-y-5 ${activeTab === "wallet" ? "tab-enter" : "hidden"}`} aria-hidden={activeTab !== "wallet"}>
            {/* Card de Saldo */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-5">
              <p className="text-[13px] text-slate-500 mb-1">Saldo disponível</p>
              <p className="text-[28px] font-semibold text-slate-900 tabular-nums tracking-tight">
                {formatCurrency(wallet?.balance || 0)}
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-[13px] text-slate-500">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  Em processamento:{" "}
                  <span className="font-medium text-slate-700 tabular-nums">
                    {formatCurrency(wallet?.reserved_balance || 0)}
                  </span>
                </span>
              </div>
              <Button
                type="button"
                onClick={() => setIsDepositModalOpen(true)}
                className="w-full mt-4 h-11 rounded-xl bg-teal-600 hover:bg-teal-700 font-bold"
              >
                Carregar conta
              </Button>
            </div>

            {/* Formulário de Levantamento */}
            <div className="bg-white border border-slate-200/80 rounded-[24px] p-8 shadow-md space-y-6">
              <h3 className="text-base font-semibold text-slate-900">Solicitar Pagamento</h3>

              {levelInfo?.priority_withdrawal && (
                <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-amber-50 border border-amber-100">
                  <Priority className="w-4 h-4 text-amber-600 shrink-0" />
                  <p className="text-[12px] font-medium text-amber-800">
                    Saque prioritário ativo (nível {levelInfo.member_level}) — processamento mais rápido.
                  </p>
                </div>
              )}
              
              <form onSubmit={handleRequestWithdraw} className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-[13px] font-semibold text-slate-600 ml-1">Escolha o Método</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'express', label: 'Multicaixa Express', icon: '/icons/express.jpg' },
                      { id: 'unitel', label: 'Unitel Money', icon: '/icons/unitel.jpg' },
                      { id: 'remitly', label: 'Remitly', icon: '/icons/remitly.jpg' }
                    ].map((method) => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setWithdrawMethod(method.id)}
                        className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                          withdrawMethod === method.id
                            ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm '
                            : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        <img
                          src={method.icon}
                          alt={method.label}
                          className="w-7 h-7 object-cover rounded-md shadow-sm mb-1.5 shrink-0"
                        />
                        <span className="text-[11px] font-semibold leading-tight">{method.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[13px] font-semibold text-slate-600 ml-1">Valor do Saque</Label>
                  <div className="relative">
                    <Input
                      type="number"
                      inputMode="numeric"
                      min={1000}
                      max={999999999}
                      step={100}
                      placeholder="Mínimo 1.000 Kz"
                      value={withdrawAmount}
                      onChange={(e) => {
                        const v = e.target.value.replace(/[^\d.]/g, "");
                        if (v.length <= 12) setWithdrawAmount(v);
                      }}
                      className="bg-slate-50 border-slate-200 focus:bg-white focus:border-emerald-500 h-12 font-mono text-xl font-bold text-slate-900 rounded-xl px-4"
                      required
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-sm">Kz</span>
                  </div>
                </div>

                {/* Formulários Dinâmicos */}
                {(withdrawMethod === 'express' || withdrawMethod === 'unitel') && (
                  <div className="p-5 bg-slate-50 rounded-xl border border-slate-200/60">
                    <Label className="text-[13px] font-semibold text-slate-600 ml-1">Número de Telefone</Label>
                    <Input
                      type="tel"
                      inputMode="tel"
                      placeholder="9xx xxx xxx"
                      value={withdrawPhone}
                      onChange={(e) => setWithdrawPhone(e.target.value.replace(/[^\d+\s]/g, "").slice(0, 16))}
                      maxLength={16}
                      readOnly={!!profile?.phone}
                      className="bg-white border-slate-200 font-mono text-base font-normal h-11 rounded-xl mt-1.5"
                    />
                    {profile?.phone && (
                      <p className="text-[11px] text-slate-400 mt-1">Número do seu perfil</p>
                    )}
                  </div>
                )}

                {withdrawMethod === 'remitly' && (
                  <div className="space-y-4 p-5 bg-slate-50 rounded-xl border border-slate-200/60">
                    <div className="space-y-1.5">
                      <Label className="text-[13px] font-semibold text-slate-600 ml-1">Nome completo do beneficiário</Label>
                      <Input
                        placeholder="Nome completo"
                        value={remitlyFullName}
                        onChange={(e) => setRemitlyFullName(e.target.value)}
                        className="bg-white border-slate-200 text-base font-normal h-11 rounded-xl"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-[13px] font-semibold text-slate-600 ml-1">País do beneficiário</Label>
                        <select
                          value={remitlyCountry}
                          onChange={(e) => handleRemitlyCountryChange(e.target.value as any)}
                          className="w-full bg-white border border-slate-200 text-sm h-11 rounded-xl px-3 outline-none focus:border-emerald-500 text-slate-700 font-medium"
                          required
                        >
                          {Object.keys(REMITLY_COUNTRIES).map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <Label className="text-[13px] font-semibold text-slate-600 ml-1">Cidade</Label>
                        <select
                          value={remitlyCity}
                          onChange={(e) => setRemitlyCity(e.target.value)}
                          className="w-full bg-white border border-slate-200 text-sm h-11 rounded-xl px-3 outline-none focus:border-emerald-500 text-slate-700 font-medium"
                          required
                        >
                          {REMITLY_COUNTRIES[remitlyCountry]?.cities.map((city) => (
                            <option key={city} value={city}>{city}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-[13px] font-semibold text-slate-600 ml-1">Número de Telefone</Label>
                      <Input
                        placeholder="Telefone do beneficiário"
                        value={remitlyPhone}
                        onChange={(e) => setRemitlyPhone(e.target.value)}
                        className="bg-white border-slate-200 font-mono text-base font-normal h-11 rounded-xl"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-[13px] font-semibold text-slate-600 ml-1">E-mail</Label>
                      <Input
                        type="email"
                        placeholder="exemplo@email.com"
                        value={remitlyEmail}
                        onChange={(e) => setRemitlyEmail(e.target.value)}
                        className="bg-white border-slate-200 text-base font-normal h-11 rounded-xl"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[11px] font-semibold text-slate-500">Método de recebimento</Label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {["Conta bancária", "Carteira móvel", "Levantamento em dinheiro"].map((m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => setRemitlyDeliveryMethod(m)}
                            className={`p-2 rounded-xl border text-center text-[11px] font-semibold tracking-tight transition-all ${
                              remitlyDeliveryMethod === m
                                ? "bg-emerald-600 border-emerald-600 text-white shadow-md "
                                : "bg-white border-slate-100 text-slate-600 hover:border-slate-200"
                            }`}
                          >
                            {m}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[11px] font-semibold text-slate-500">Moeda de recebimento</Label>
                      <div className="grid grid-cols-4 gap-1.5">
                        {["Kz (AOA)", "USD", "EUR", "BRL"].map((curr) => (
                          <button
                            key={curr}
                            type="button"
                            onClick={() => setRemitlyCurrency(curr)}
                            className={`p-2 rounded-xl border text-center text-[11px] font-semibold tracking-tight transition-all ${
                              remitlyCurrency === curr
                                ? "bg-emerald-600 border-emerald-600 text-white shadow-md "
                                : "bg-white border-slate-100 text-slate-600 hover:border-slate-200"
                            }`}
                          >
                            {curr}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={isRequestingWithdraw || !withdrawAmount || parseFloat(withdrawAmount) < 1000 || parseFloat(withdrawAmount) > (wallet?.balance || 0)}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-14 rounded-2xl shadow-md transition-all text-sm "
                >
                  {isRequestingWithdraw ? <Loader2 className="w-5 h-5 animate-spin" /> : "Solicitar Levantamento"}
                </Button>
              </form>
            </div>

            {/* Histórico com Ocultar Movimentações */}
            <div className="space-y-4">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-bold text-slate-400 ">Extrato de Movimentações</h3>
                <button
                  type="button"
                  onClick={() => setHideTransactions(!hideTransactions)}
                  className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500 hover:text-emerald-600 bg-slate-100 hover:bg-slate-200/80 px-2.5 py-1 rounded-xl transition-all"
                >
                  {hideTransactions ? (
                    <>
                      <Eye className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Mostrar Movimentação</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3.5 h-3.5 text-slate-400" />
                      <span>Ocultar Movimentação</span>
                    </>
                  )}
                </button>
              </div>
              
              {!hideTransactions && (
                transactions.length === 0 ? (
                  <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-xs text-slate-400 font-medium">
                    Nenhuma movimentação registrada.
                  </div>
                ) : (
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-50 shadow-sm">
                    {transactions.map((tx) => (
                      <div key={tx.id} className="p-5 flex items-center justify-between hover:bg-slate-50 transition-colors">
                        <div className="flex gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tx.amount > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'}`}>
                            {tx.amount > 0 ? <Plus className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-slate-900">{tx.description || tx.type}</p>
                            <p className="text-[11px] text-slate-400 font-semibold tracking-tighter">{new Date(tx.created_at).toLocaleString()}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-bold font-mono ${tx.amount > 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                            {tx.amount > 0 ? '+' : ''}{formatCurrency(tx.amount)}
                          </p>
                          <Badge variant="outline" className="text-[11px] font-semibold border-slate-200 text-slate-400 px-2 mt-1">
                            {tx.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )
              )}
            </div>
          </div>
        )}

      </main>

      {/* MODAL CONFIGURAÇÕES */}
      <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
        <DialogContent className="bg-white border-none sm:rounded-2xl max-h-[90vh] overflow-y-auto w-full max-w-md p-6 shadow-md">
          <DialogHeader className="relative border-b border-slate-50 pb-5">
            <DialogTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <UserIcon className="w-6 h-6 text-emerald-600" /> Meu Perfil
            </DialogTitle>
            <DialogDescription className="text-sm text-slate-500 mt-1 font-medium">
              Atualize suas informações de rede social para validar as tarefas.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleUpdateProfile} className="space-y-5 py-6">
            <div className="space-y-2">
              <Label className="text-[11px] font-semibold text-slate-400 ">Nome Operacional</Label>
              <Input 
                value={profileName} 
                onChange={(e) => setProfileName(e.target.value)}
                className="bg-slate-50 border-transparent focus:bg-white focus:border-emerald-500 h-12 rounded-xl text-sm font-bold" 
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[11px] font-semibold text-slate-400 ">WhatsApp / Telefone</Label>
              <Input 
                value={profilePhone} 
                onChange={(e) => setProfilePhone(e.target.value)}
                className="bg-slate-50 border-transparent focus:bg-white focus:border-emerald-500 h-12 rounded-xl text-sm font-bold" 
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[13px] font-medium text-slate-600">Idioma / Language / Langue</Label>
              <select
                value={profileLanguage}
                onChange={(e) => setProfileLanguage(e.target.value as "pt" | "en" | "fr")}
                className="w-full h-11 rounded-xl bg-slate-50 border border-slate-200 px-3 text-[14px] font-medium text-slate-800 outline-none"
              >
                <option value="pt">Português</option>
                <option value="en">English</option>
                <option value="fr">Français</option>
              </select>
            </div>
            
            <div className="space-y-4 pt-2">
              <span className="text-[11px] font-semibold text-emerald-600 block">Canais de Trabalho</span>
              
              <div className="space-y-2">
                <Label className="text-[11px] font-semibold text-slate-400 flex items-center gap-2">
                   <img src="/tiktok-logo.png" alt="TikTok" className="w-3 h-3 object-contain" /> TikTok Handle
                </Label>
                <Input
                  value={profileTiktok}
                  onChange={(e) => setProfileTiktok(e.target.value)}
                  placeholder="@usuario"
                  className="bg-slate-50 border-transparent focus:bg-white focus:border-emerald-500 h-11 rounded-xl text-sm font-bold"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-[11px] font-semibold text-slate-400 flex items-center gap-2">
                   <img src="/instagram-logo.png" alt="Instagram" className="w-3 h-3 object-contain" /> Instagram Handle
                </Label>
                <Input
                  value={profileInstagram}
                  onChange={(e) => setProfileInstagram(e.target.value)}
                  placeholder="@usuario"
                  className="bg-slate-50 border-transparent focus:bg-white focus:border-emerald-500 h-11 rounded-xl text-sm font-bold"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-[11px] font-semibold text-slate-400 flex items-center gap-2">
                   <img src="/youtube-logo.png" alt="YouTube" className="w-3 h-3 object-contain" /> YouTube Channel
                </Label>
                <Input
                  value={profileYoutube}
                  onChange={(e) => setProfileYoutube(e.target.value)}
                  placeholder="URL ou @canal"
                  className="bg-slate-50 border-transparent focus:bg-white focus:border-emerald-500 h-11 rounded-xl text-sm font-bold"
                />
              </div>
            </div>

            <BiometricSetting />

            <div className="pt-6 border-t border-slate-50 flex flex-col gap-3">
              <Button 
                type="submit" 
                disabled={updatingProfile}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-12 rounded-2xl shadow-sm text-xs "
              >
                {updatingProfile ? <Loader2 className="w-4 h-4 animate-spin" /> : "SALVAR ALTERAÇÕES"}
              </Button>
              <Button
                type="button"
                variant="ghost"
                onClick={() => signOut()}
                className="w-full text-red-500 hover:text-red-600 hover:bg-red-50 h-12 rounded-2xl font-bold text-xs gap-2"
              >
                <LogOut className="w-4 h-4" /> Encerrar sessão
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Menu principal — funções reais do app */}
      <Dialog open={isMenuOpen} onOpenChange={setIsMenuOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-[90vw] sm:max-w-sm p-0 shadow-md max-h-[90vh] overflow-hidden flex flex-col">
          {/* Cabeçalho com perfil real */}
          <div className="px-4 pt-5 pb-4 bg-[#0b5f58] text-white border-b border-teal-900/20">
            <div className="flex items-center gap-3 pr-8">
              <AppLogo size="sm" className="w-12 h-12 rounded-2xl shrink-0 ring-white/20" />
              <div className="min-w-0">
                <p className="text-[15px] font-bold truncate leading-tight">
                  {profile?.name || "Utilizador"}
                </p>
                <p className="text-[11px] text-white/80 truncate">{profile?.email || user?.email}</p>
                <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                  {levelInfo && (
                    <span className="text-[11px] font-semibold bg-white/20 px-2 py-0.5 rounded-full">
                      {levelInfo.member_level}
                    </span>
                  )}
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                    isSubscriber ? "bg-emerald-400/30 text-white" : "bg-white/15 text-white/90"
                  }`}>
                    {isSubscriber ? "Assinante" : "Visitante"}
                  </span>
                </div>
              </div>
            </div>
            <p className="text-[11px] text-white/70 mt-3">
              Saldo: <span className="font-bold text-white">{formatCurrency(wallet?.balance || 0)}</span>
            </p>
          </div>

          <div className="overflow-y-auto px-3 py-3 space-y-4 flex-1">
            {/* Navegação real */}
            <div>
              <p className="text-[11px] font-semibold text-slate-400 px-2 mb-1.5">Navegar</p>
              <div className="space-y-0.5">
                {[
                  { id: "home" as const, label: "Início", desc: "Resumo e tendências", icon: Activity, color: "bg-teal-50 text-teal-700" },
                  { id: "engagement" as const, label: "Loja", desc: "Comprar engajamento", icon: ShoppingCart, color: "bg-teal-50 text-teal-700" },
                  { id: "wallet" as const, label: "Carteira", desc: "Saldo e saques", icon: Wallet, color: "bg-emerald-50 text-emerald-700" },
                  { id: "affiliate" as const, label: "Afiliados", desc: "Link e comissões", icon: Users, color: "bg-amber-50 text-amber-700", restricted: true },
                  { id: "campaigns" as const, label: "Campanhas", desc: "Missões activas", icon: Megaphone, color: "bg-violet-50 text-violet-700", restricted: true },
                  { id: "tasks" as const, label: "Tarefas", desc: "Comunidade", icon: Layers, color: "bg-sky-50 text-sky-700", restricted: true },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      if (item.restricted) handleTabChange(item.id);
                      else goToTab(item.id);
                    }}
                    className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                  >
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${item.color}`}>
                      <item.icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-semibold text-slate-800 truncate">{item.label}</p>
                      <p className="text-[11px] text-slate-400 truncate">{item.desc}</p>
                    </div>
                    {item.restricted && !isSubscriber && (
                      <Lock className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Conta e dinheiro */}
            <div>
              <p className="text-[11px] font-semibold text-slate-400 px-2 mb-1.5">Conta</p>
              <div className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => {
                    setIsMenuOpen(false);
                    if (subStatus === "pending") toast.info("O seu pagamento está em validação pela equipa.");
                    else if (!isSubscriber || subExpiringSoon) setIsSubscriptionModalOpen(true);
                    else toast.success(`Assinatura activa até ${subExpiresLabel || "—"}.`);
                  }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Assinatura</p>
                    <p className="text-[11px] text-slate-400">
                      {subStatus === "pending"
                        ? "Pagamento em validação"
                        : isSubscriber
                          ? subExpiresAt
                            ? `Activa até ${subExpiresLabel} · ${subDaysLeft} dias${subExpiringSoon ? " · Renovar" : ""}`
                            : "Plano activo"
                          : subExpired
                            ? "Expirada — renovar"
                            : "Activar acesso completo"}
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsMenuOpen(false);
                    handleTabChange("affiliate");
                  }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
                    <Ranking className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Níveis e ranking</p>
                    <p className="text-[11px] text-slate-400">Do Bronze à Platina e benefícios</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsMenuOpen(false);
                    shareAppNative();
                  }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <Share2 className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Convidar amigos</p>
                    <p className="text-[11px] text-slate-400">Partilhar link de afiliado</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsSettingsOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <Settings className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Perfil e dados</p>
                    <p className="text-[11px] text-slate-400">Nome, WhatsApp, redes</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsHistoryOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Histórico financeiro</p>
                    <p className="text-[11px] text-slate-400">{transactions.length} movimentos recentes</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsNotificationsOpen(true); markAllSeen(); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0 relative">
                    <Bell className="w-4 h-4" />
                    {unreadAlerts > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Notificações</p>
                    <p className="text-[11px] text-slate-400">
                      {unreadAlerts > 0 ? `${unreadAlerts} novos` : activityLogs.length > 0 ? `${activityLogs.length} eventos recentes` : "Avisos da conta"}
                    </p>
                  </div>
                </button>
              </div>
            </div>

            {/* Para ti */}
            <div>
              <p className="text-[11px] font-medium text-slate-400 px-2 mb-1.5">Para ti</p>
              <div className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsCoachOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left min-h-[48px]"
                >
                  <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                    <IconTrendingUp className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">O que fazer hoje</p>
                    <p className="text-[11px] text-slate-400">Sugestões com base na tua conta</p>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); openIA("engagement"); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left min-h-[48px]"
                >
                  <div className="w-9 h-9 rounded-lg bg-violet-50 text-violet-700 flex items-center justify-center shrink-0">
                    <IconMessage className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Ideias para postar</p>
                    <p className="text-[11px] text-slate-400">Legendas e ideias para redes</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Ajuda */}
            <div>
              <p className="text-[11px] font-medium text-slate-400 px-2 mb-1.5">Ajuda</p>
              <div className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsAISupportOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left min-h-[48px]"
                >
                  <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <IconHelp className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Ajuda</p>
                    <p className="text-[11px] text-slate-400">Respostas e WhatsApp da equipa</p>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsFaqOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <HelpCircle className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Perguntas frequentes</p>
                    <p className="text-[11px] text-slate-400">Saques, afiliados, assinatura</p>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsAboutOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <Info className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Sobre a ADXmoney</p>
                    <p className="text-[11px] text-slate-400">Versão e missão</p>
                  </div>
                </button>
                <button
                  onClick={() => { setIsMenuOpen(false); setIsPasswordOpen(true); }}
                  className="w-full flex items-center gap-3 px-4 py-3.5 text-left active:bg-slate-50"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Alterar palavra-passe</p>
                    <p className="text-[11px] text-slate-400">Segurança da conta</p>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => { setIsMenuOpen(false); setIsPrivacyOpen(true); }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-semibold text-slate-800">Privacidade e termos</p>
                    <p className="text-[11px] text-slate-400">Regras da plataforma</p>
                  </div>
                </button>
              </div>
            </div>
          </div>

          <div className="p-3 border-t border-slate-100 shrink-0">
            <Button
              onClick={() => { setIsMenuOpen(false); signOut(); }}
              variant="destructive"
              className="w-full h-11 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-[12px] gap-2 border border-rose-100"
            >
              <LogOut className="w-4 h-4" /> Terminar sessão
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal Notificações — eventos reais da conta */}
      <Dialog open={isNotificationsOpen} onOpenChange={setIsNotificationsOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-md p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Notificações</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Eventos recentes da sua conta (saques, assinatura, tarefas).
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 max-h-[60vh] overflow-y-auto space-y-3">
            {activityLogs.length === 0 ? (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center">
                <Bell className="w-6 h-6 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-500">Ainda não há eventos registados.</p>
                <p className="text-[11px] text-slate-400 mt-1">Saques, assinaturas e tarefas aparecem aqui.</p>
              </div>
            ) : (
              activityLogs.map((log) => (
                <div key={log.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Bell className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 truncate">
                      {log.title || log.action_type || "Actividade"}
                    </h4>
                    {log.details && (
                      <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">{log.details}</p>
                    )}
                    <span className="text-[11px] text-slate-400 font-medium mt-1 block">
                      {new Date(log.created_at).toLocaleString("pt-PT")}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal Histórico */}
      <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-lg p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Histórico de Atividades</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Suas últimas transações e movimentações financeiras.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 max-h-[60vh] overflow-y-auto space-y-3">
            {transactions.length === 0 ? (
              <p className="text-center text-xs text-slate-400 py-8">Nenhuma transação recente encontrada.</p>
            ) : (
              transactions.map((tx) => (
                <div key={tx.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{tx.description || tx.type}</h4>
                    <span className="text-[11px] text-slate-400">{new Date(tx.created_at).toLocaleDateString()}</span>
                  </div>
                  <span className={`text-xs font-bold ${tx.amount > 0 ? "text-emerald-600" : "text-rose-600"}`}>
                    {tx.amount > 0 ? "+" : ""}{tx.amount} Kz
                  </span>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal Suporte */}
      <Dialog open={isSupportOpen} onOpenChange={setIsSupportOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-md p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Apoio ao Cliente</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Precisa de ajuda? Fale diretamente com nossa equipe via WhatsApp.
            </DialogDescription>
          </DialogHeader>
          <div className="py-6 space-y-4 text-center">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
              <MessageSquare className="w-8 h-8" />
            </div>
            <p className="text-xs text-slate-600 font-medium">
              Nosso atendimento funciona de segunda a sábado das 08h às 20h.
            </p>
            <Button
              onClick={() => window.open("https://wa.me/244933271690?text=Ol%C3%A1%2C%20preciso%20de%20suporte%20no%20ADXmoney", "_blank")}
              className="w-full h-12 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold text-xs gap-2 shadow-sm "
            >
              Abrir WhatsApp de Suporte
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal Sobre */}
      <Dialog open={isAboutOpen} onOpenChange={setIsAboutOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-md p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Sobre a ADXmoney</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Monetização e engajamento para criadores e operadores.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-3 text-xs text-slate-600 leading-relaxed">
            <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50">
              <AppLogo size="sm" />
              <div>
                <p className="font-bold text-slate-900">ADXmoney</p>
                <p className="text-[11px] text-slate-400">Versão 7 · PWA 2026</p>
              </div>
            </div>
            <p>
              A ADXmoney liga anunciantes a operadores: campanhas, tarefas de comunidade,
              loja de engajamento, carteira digital e rede de afiliados com níveis
              (Bronze a Platinum).
            </p>
            <ul className="list-disc pl-4 space-y-1 text-[11px]">
              <li>Assinatura de 6 meses (renovável) para desbloquear tarefas, campanhas e afiliados</li>
              <li>Saques via Unitel Money, Multicaixa Express ou Remitly (mín. 1.000 Kz)</li>
              <li>Comissões e ranking baseados em indicações e ganhos</li>
            </ul>
          </div>
        </DialogContent>
      </Dialog>

      <TermsGate />
      <ChangePasswordDialog open={isPasswordOpen} onOpenChange={setIsPasswordOpen} />

      {/* Modal Privacidade e Termos */}
      <Dialog open={isPrivacyOpen} onOpenChange={setIsPrivacyOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-md p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Privacidade e Termos</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Regras de uso da plataforma ADXmoney.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-3 text-xs text-slate-600 leading-relaxed">
            <p>Os Termos e Condições e a Política de Privacidade completos estão disponíveis nestas páginas:</p>
            <div className="flex flex-col gap-2">
              <a href="/termos" target="_blank" rel="noreferrer" className="rounded-xl bg-slate-900 px-4 py-3 text-center text-[13px] font-semibold text-white">Termos e Condições</a>
              <a href="/privacidade" target="_blank" rel="noreferrer" className="rounded-xl bg-slate-100 px-4 py-3 text-center text-[13px] font-semibold text-slate-800">Política de Privacidade</a>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal FAQ */}
      <Dialog open={isFaqOpen} onOpenChange={setIsFaqOpen}>
        <DialogContent className="bg-white rounded-2xl border-none max-w-lg p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Perguntas frequentes</DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Respostas práticas para operadores.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 max-h-[60vh] overflow-y-auto space-y-3">
            {[
              {
                q: "Como activo a conta completa?",
                a: "No menu, abra Assinatura e escolha o método (Unitel, Express ou Remitly), envie o comprovativo e aguarde a aprovação da equipa. O acesso dura 6 meses e pode ser renovado nos últimos 30 dias.",
              },
              {
                q: "Como começo a ganhar?",
                a: "Com assinatura activa: na troca de seguidores você segue os outros membros e eles seguem você; nas tarefas da loja e nas campanhas o pagamento só existe quando há resultado financeiro, e é partilhado por todos os participantes. Como afiliado, recebe uma percentagem quando o seu indicado paga (assinatura, pedidos da loja e campanhas).",
              },
              {
                q: "Qual o mínimo de saque?",
                a: "1.000 Kz. Pode sacar via Unitel Money, Multicaixa Express ou Remitly. Prazo máximo de pagamento: 24 horas.",
              },
              {
                q: "Como funciona o afiliado?",
                a: "Partilhe o seu link (menu, opção Convidar amigos). Quando alguém se regista com o seu código e paga (assinatura, pedido na loja ou campanha coletiva), recebe uma percentagem na carteira. Só recebe com a sua assinatura activa. O registo sozinho não gera comissão.",
              },
              {
                q: "O que são os níveis Bronze a Platinum?",
                a: "Reflectem indicações e ganhos. Gold e Platinum têm saque prioritário e código de afiliado personalizado.",
              },
              {
                q: "A loja exige assinatura?",
                a: "Não. Qualquer utilizador autenticado pode pedir engajamento na Loja e pagar com comprovativo.",
              },
            ].map((item) => (
              <div key={item.q} className="p-3.5 rounded-2xl bg-slate-50 space-y-1 border border-slate-100">
                <h4 className="text-xs font-bold text-slate-900">{item.q}</h4>
                <p className="text-[11px] text-slate-600 leading-relaxed">{item.a}</p>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Assinatura Exclusiva */}
      {user && (
        <SubscriptionModal
          isOpen={isSubscriptionModalOpen}
          onClose={() => setIsSubscriptionModalOpen(false)}
          userId={user.id}
          currency={currency}
          exchangeRates={EXCHANGE_RATES}
          defaultPayerName={profile?.name || ""}
          renewal={subExpiringSoon || subExpired}
          expiresAt={subExpiresAt}
          onSuccess={() => refreshProfile()}
        />
      )}

      {/* Carregar conta (depósito) */}
      {user && (
        <DepositModal
          isOpen={isDepositModalOpen}
          onClose={() => setIsDepositModalOpen(false)}
          userId={user.id}
          currency={currency}
          exchangeRates={EXCHANGE_RATES}
          defaultPayerName={profile?.name || ""}
          onSuccess={() => loadUserData(false, { silent: true })}
        />
      )}

      <IAAdxContentGenerator
        open={isIAOpen}
        onClose={() => setIsIAOpen(false)}
        defaultPlatform={iaDefaultPlatform}
        defaultObjective={iaDefaultObjective}
      />

      <IAAdxCoach
        open={isCoachOpen}
        onClose={() => setIsCoachOpen(false)}
        onNavigate={(tab) => {
          // Usa a mesma lógica de restrição de assinatura
          handleTabChange(tab);
        }}
        onOpenContentGenerator={() => openIA("engagement")}
      />

      <IAAdxSupport
        open={isAISupportOpen}
        onClose={() => setIsAISupportOpen(false)}
      />

      {/* Bottom Navigation – estilo nativo (pill ativo, alvos ≥ 44px) */}
      <nav className="app-bottom-nav" aria-label="Navegação principal">
        <div className="max-w-lg mx-auto h-full flex items-stretch justify-around px-1">
          {([
            { id: "home" as const, label: "Início", icon: IconHome, restricted: false },
            { id: "tasks" as const, label: "Tarefas", icon: IconTasks, restricted: true },
            { id: "campaigns" as const, label: "Ações", icon: IconCampaigns, restricted: true },
            { id: "engagement" as const, label: "Loja", icon: IconStore, restricted: false },
            { id: "wallet" as const, label: "Conta", icon: IconWallet, restricted: false },
          ]).map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => (tab.restricted ? handleTabChange(tab.id) : goToTab(tab.id))}
                className={`nav-item pressable${isActive ? " active" : ""}`}
                aria-current={isActive ? "page" : undefined}
              >
                <Icon className="nav-icon" aria-hidden />
                <span className="nav-label">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

    </div>
  );
}
