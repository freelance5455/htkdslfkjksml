import React, { useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { ArrowLeft, FileQuestion } from "@/components/icons";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-[100dvh] flex items-center justify-center p-6 safe-x safe-top safe-bottom" style={{ background: "var(--adx-surface, #f2f3f5)" }}>
      <div className="max-w-md w-full text-center card-premium p-10 flex flex-col items-center">
        <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6 shadow-sm">
          <FileQuestion className="w-8 h-8" />
        </div>
        <h1 className="text-4xl font-bold text-slate-900 tracking-tight mb-2">404</h1>
        <p className="text-sm font-bold text-slate-700 mb-2">Página não encontrada</p>
        <p className="text-xs text-slate-400 font-medium mb-8">
          O caminho solicitado não existe ou foi movido na plataforma ADXmoney.
        </p>
        <Link to="/app" className="w-full">
          <Button className="w-full btn-adx h-12 text-sm flex items-center justify-center gap-2">
            <ArrowLeft className="w-4 h-4" /> Voltar ao Painel
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
