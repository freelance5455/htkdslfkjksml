import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

/** Indicativo padrão Angola (+244) */
export const DEFAULT_DIAL = "+244";

type PhoneFieldProps = {
  id?: string;
  label?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  className?: string;
  inputClassName?: string;
  /** Texto auxiliar sob o campo */
  hint?: string;
};

/**
 * Campo "Número" com bandeira AO e indicativo +244.
 * O valor inclui o prefixo quando o utilizador digita só o nacional.
 */
export function PhoneField({
  id = "phone",
  label = "Número",
  value,
  onChange,
  placeholder = "9xx xxx xxx",
  required,
  disabled,
  readOnly,
  className,
  inputClassName,
  hint,
}: PhoneFieldProps) {
  const handleChange = (raw: string) => {
    // Permite +, dígitos e espaços; limita comprimento
    const cleaned = raw.replace(/[^\d+\s]/g, "").slice(0, 20);
    onChange(cleaned);
  };

  return (
    <div className={cn("space-y-1.5", className)}>
      {label ? (
        <Label htmlFor={id} className="text-[13px] font-medium text-slate-600">
          {label}
          {required ? <span className="text-rose-500"> *</span> : null}
        </Label>
      ) : null}
      <div className="flex items-stretch gap-0 rounded-xl border border-slate-200 bg-white overflow-hidden focus-within:ring-2 focus-within:ring-teal-600/20 focus-within:border-teal-600/40">
        {/* Bandeira + indicativo Angola (padrão) */}
        <div
          className="flex items-center gap-1.5 px-2.5 bg-slate-50 border-r border-slate-200 shrink-0 select-none"
          title="Angola (+244)"
          aria-label="Indicativo Angola +244"
        >
          <span className="text-[16px] leading-none" aria-hidden>
            🇦🇴
          </span>
          <span className="text-[13px] font-semibold text-slate-600 tabular-nums">
            +244
          </span>
        </div>
        <Input
          id={id}
          type="tel"
          inputMode="tel"
          autoComplete="tel-national"
          placeholder={placeholder}
          value={stripDialDisplay(value)}
          onChange={(e) => {
            const national = e.target.value.replace(/[^\d\s]/g, "").slice(0, 12);
            // Guarda com indicativo se houver dígitos
            const digits = national.replace(/\s/g, "");
            if (!digits) {
              onChange("");
              return;
            }
            onChange(`${DEFAULT_DIAL} ${national.trim()}`.trim());
          }}
          required={required}
          disabled={disabled}
          readOnly={readOnly}
          className={cn(
            "h-11 border-0 rounded-none shadow-none focus-visible:ring-0 focus-visible:ring-offset-0 text-[15px] font-mono",
            inputClassName
          )}
        />
      </div>
      {hint ? (
        <p className="text-[11px] text-slate-400 leading-snug">{hint}</p>
      ) : null}
    </div>
  );
}

/** Remove +244 do início para mostrar só a parte nacional no input */
function stripDialDisplay(value: string): string {
  const v = (value || "").trim();
  if (!v) return "";
  return v
    .replace(/^\+?244[\s-]*/i, "")
    .replace(/^\+/, "")
    .trim();
}

export default PhoneField;
