import { purgeProofsSoon } from "@/lib/purge";
import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, XCircle, ExternalLink, Wallet } from "@/components/icons";
import { toast } from "sonner";

interface DepositRow {
  id: string;
  user_id: string;
  amount: number;
  currency: string;
  method: string;
  proof_url: string | null;
  status: string;
  created_at: string;
  profiles?: { name?: string; email?: string } | null;
}

export default function DepositRequests() {
  const [rows, setRows] = useState<DepositRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [proofUrls, setProofUrls] = useState<Record<string, string>>({});

  const load = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("wallet_deposits")
        .select("id, user_id, amount, currency, method, proof_url, status, created_at, profiles(name, email)")
        .eq("status", "PENDING")
        .order("created_at", { ascending: true });

      if (error) throw error;
      const list = (data || []) as unknown as DepositRow[];
      setRows(list);

      const urls: Record<string, string> = {};
      await Promise.all(
        list.map(async (req) => {
          if (!req.proof_url) return;
          if (req.proof_url.startsWith("http://") || req.proof_url.startsWith("https://")) {
            urls[req.id] = req.proof_url;
            return;
          }
          try {
            const { data: signed } = await supabase.storage
              .from("subscription-proofs")
              .createSignedUrl(req.proof_url, 3600);
            if (signed?.signedUrl) urls[req.id] = signed.signedUrl;
          } catch {
            /* ignore */
          }
        })
      );
      setProofUrls(urls);
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Erro ao carregar depósitos");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const process = async (id: string, status: "APPROVED" | "REJECTED") => {
    setProcessingId(id);
    try {
      const { data, error } = await supabase.rpc("admin_process_wallet_deposit", {
        p_deposit_id: id,
        p_status: status,
        p_rejection_reason: status === "REJECTED" ? "Rejeitado pelo administrador" : null,
      });
      if (error) throw error;
      const result = data as { success?: boolean } | null;
      if (result && result.success === false) {
        throw new Error("Falha ao processar depósito");
      }
      toast.success(status === "APPROVED" ? "Depósito aprovado e saldo creditado" : "Depósito rejeitado");
      purgeProofsSoon();
      setRows((prev) => prev.filter((r) => r.id !== id));
    } catch (err: any) {
      toast.error(err.message || "Erro ao processar");
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12 text-slate-400">
        <Loader2 className="w-5 h-5 animate-spin mr-2" /> A carregar depósitos…
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="rounded-2xl border border-slate-100 bg-white p-8 text-center">
        <Wallet className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-[13px] font-semibold text-slate-600">Sem depósitos pendentes</p>
        <p className="text-[11px] text-slate-400 mt-1">Novos carregamentos de conta aparecem aqui.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-[13px] font-extrabold text-slate-900">
          Depósitos pendentes ({rows.length})
        </p>
        <Button variant="outline" size="sm" className="h-8 rounded-lg text-[11px]" onClick={load}>
          Atualizar
        </Button>
      </div>

      {rows.map((req) => (
        <div
          key={req.id}
          className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm space-y-3"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-[13px] font-bold text-slate-900 truncate">
                {(req.profiles as any)?.name || "Utilizador"}
              </p>
              <p className="text-[11px] text-slate-400 truncate">
                {(req.profiles as any)?.email || req.user_id.slice(0, 8)}
              </p>
            </div>
            <Badge className="bg-amber-50 text-amber-700 border-none text-[11px] font-bold">
              PENDENTE
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[12px]">
            <div className="rounded-xl bg-slate-50 p-2.5">
              <p className="text-[11px] text-slate-400 font-semibold">Valor</p>
              <p className="font-extrabold text-slate-900">
                {Number(req.amount).toLocaleString("pt-PT", { minimumFractionDigits: 2 })} Kz
              </p>
            </div>
            <div className="rounded-xl bg-slate-50 p-2.5">
              <p className="text-[11px] text-slate-400 font-semibold">Data</p>
              <p className="font-semibold text-slate-800">
                {new Date(req.created_at).toLocaleString("pt-PT", {
                  day: "2-digit",
                  month: "short",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>

          <p className="text-[11px] text-slate-500 break-words">
            <span className="font-semibold text-slate-600">Método: </span>
            {req.method}
          </p>

          {proofUrls[req.id] && (
            <a
              href={proofUrls[req.id]}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-[12px] font-bold text-teal-700 hover:underline"
            >
              Ver comprovativo <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}

          <div className="flex gap-2 pt-1">
            <Button
              disabled={processingId === req.id}
              onClick={() => process(req.id, "APPROVED")}
              className="flex-1 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold text-[12px]"
            >
              {processingId === req.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-1" /> Aprovar
                </>
              )}
            </Button>
            <Button
              disabled={processingId === req.id}
              variant="outline"
              onClick={() => process(req.id, "REJECTED")}
              className="flex-1 h-10 rounded-xl border-rose-200 text-rose-600 hover:bg-rose-50 font-bold text-[12px]"
            >
              <XCircle className="w-4 h-4 mr-1" /> Rejeitar
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
