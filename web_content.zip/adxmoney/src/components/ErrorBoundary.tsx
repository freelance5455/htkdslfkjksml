import { Component, ErrorInfo, ReactNode } from "react";
import { logClientError } from "@/lib/errorLog";

interface State {
  hasError: boolean;
}

/** Evita o "ecrã branco": mostra uma mensagem amigável, regista o erro e permite recarregar. */
export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    logClientError(`Erro de interface: ${error.message}`, `${error.stack || ""}\n${info.componentStack || ""}`);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50 p-6 text-center">
        <h1 className="text-lg font-bold text-slate-900">Algo correu mal</h1>
        <p className="max-w-xs text-sm text-slate-600">
          O problema foi registado. Recarregue a página; se continuar, contacte o suporte.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="h-11 rounded-xl bg-slate-900 px-6 text-sm font-semibold text-white"
        >
          Recarregar
        </button>
      </div>
    );
  }
}
