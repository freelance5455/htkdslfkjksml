import React, { useState, useEffect, useCallback } from "react";
import { RefreshCw, WifiOff } from "@/components/icons";
import { SPLASH_LOGO } from "@/lib/splashLogo";

interface SplashScreenProps {
  /** Mantido por compatibilidade: o splash mostra sempre o mesmo texto (um único ecrã contínuo). */
  message?: string;
  /** Após este tempo (online) mostra o botão de recarregar (ms). Default 7s. */
  showReloadAfterMs?: number;
  /** Força estado offline (ex.: teste). */
  forceOffline?: boolean;
  /** Estado de rede controlado pelo BootGate (verificação real). Se omitido, usa navigator.onLine. */
  offline?: boolean;
  /** "Tentar novamente": verifica a ligação e devolve true se há internet. */
  onRetry?: () => Promise<boolean>;
  /** Desvanece o splash (saída suave). */
  fading?: boolean;
  /** "logout": texto "A terminar sessão…", nunca mostra o bloco offline nem o botão recarregar. */
  variant?: "boot" | "logout" | "offline";
}

function isBrowserOnline(): boolean {
  if (typeof navigator === "undefined") return true;
  return navigator.onLine !== false;
}

/**
 * Splash ÚNICO do app. Usa as mesmas classes (.adx-splash*) do splash HTML do index.html,
 * por isso a passagem HTML → React é invisível (mesmo logo, mesma posição, mesmas fontes).
 * - Não depende de rede (logo local + CSS).
 * - Deteta falta de internet e mostra a informação + recarregar.
 */
export const SplashScreen: React.FC<SplashScreenProps> = ({
  showReloadAfterMs = 7000,
  forceOffline = false,
  offline,
  onRetry,
  fading = false,
  variant = "boot",
}) => {
  const isLogout = variant === "logout";
  const [browserOnline, setOnline] = useState(() => isBrowserOnline() && !forceOffline);
  const [showReload, setShowReload] = useState(false);
  const [checking, setChecking] = useState(false);
  const [stillOffline, setStillOffline] = useState(false);
  const online = offline === undefined ? browserOnline : !offline;

  useEffect(() => {
    if (forceOffline) {
      setOnline(false);
      return;
    }
    const goOffline = () => setOnline(false);
    const goOnline = () => setOnline(true);
    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    setOnline(isBrowserOnline());
    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
    };
  }, [forceOffline]);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowReload(true), showReloadAfterMs);
    return () => window.clearTimeout(timer);
  }, [showReloadAfterMs]);

  const handleRetry = useCallback(async () => {
    if (!onRetry) {
      window.location.reload();
      return;
    }
    setChecking(true);
    setStillOffline(false);
    const ok = await onRetry();
    setChecking(false);
    if (!ok) {
      setStillOffline(true);
      window.setTimeout(() => setStillOffline(false), 3000);
    }
  }, [onRetry]);

  const handleReload = useCallback(() => {
    try {
      window.location.reload();
    } catch {
      window.location.href = window.location.href;
    }
  }, []);

  // No logout o estado offline é irrelevante: mantém sempre a vista normal.
  const showOffline = !online && !isLogout;
  const className =
    "adx-splash" + (showOffline ? " adx-splash-offline" : "") + (fading ? " adx-splash-hide" : "") + (variant !== "boot" ? " adx-splash-enter" : "");

  return (
    <div role="status" aria-live="polite" className={className}>
      <div className="adx-splash-logo">
        <img src={SPLASH_LOGO} alt="" width={112} height={112} draggable={false} />
      </div>

      <div className="adx-splash-body">
        <h1>ADXmoney</h1>

        {!showOffline ? (
          <>
            <p className="adx-splash-sub">Monetização e engajamento</p>
            <div className="adx-splash-status">
              <span className="adx-splash-dot" aria-hidden="true" />
              <span>{isLogout ? "A terminar sessão…" : "A carregar…"}</span>
            </div>
            <div className="adx-splash-bar" aria-hidden="true">
              <i />
            </div>
            {showReload && !isLogout && (
              <div className="adx-splash-actions">
                <p className="adx-splash-hint" style={{ marginTop: 0 }}>
                  Está a demorar mais do que o esperado?
                </p>
                <button type="button" className="adx-splash-btn" onClick={handleReload}>
                  <RefreshCw className="w-4 h-4" />
                  Recarregar
                </button>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="adx-splash-warn" aria-hidden="true">
              <WifiOff className="w-5 h-5" />
            </div>
            <p className="adx-splash-msg">Sem conexão com a internet</p>
            <p className="adx-splash-hint">
              Verifique os dados móveis ou o Wi‑Fi. Assim que a ligação voltar, o sistema retoma
              automaticamente onde estava.
            </p>
            <div className="adx-splash-actions">
              <button type="button" className="adx-splash-btn" onClick={handleRetry} disabled={checking}>
                <RefreshCw className={"w-4 h-4" + (checking ? " animate-spin" : "")} />
                {checking ? "A verificar…" : "Tentar novamente"}
              </button>
              {stillOffline && <p className="adx-splash-hint" style={{ marginTop: 0 }}>Ainda sem ligação.</p>}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SplashScreen;
