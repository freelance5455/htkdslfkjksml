import React, { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { onAppActiveChange } from "@/lib/appLifecycle";
import {
  BIOMETRIC_LOCK_AFTER_MS,
  authenticateBiometric,
  isBiometricEnabled,
} from "@/lib/biometric";
import { isNativePlatform } from "@/lib/nativeShell";
import { AppLogo } from "@/components/AppLogo";
import { Button } from "@/components/ui/button";
import { Lock, LogOut, Loader2 } from "@/components/icons";

/**
 * Ecrã de bloqueio interno. Só activa se: app nativa + utilizador com sessão + preferência ligada.
 * Bloqueia ao reabrir a app (arranque com sessão existente) e ao voltar de segundo plano após >30 s.
 * Falhar/cancelar mantém bloqueado; a saída é autenticar ou terminar sessão.
 */
export const BiometricLock: React.FC = () => {
  const { user, loading, signOut } = useAuth();
  const [locked, setLocked] = useState(false);
  const [busy, setBusy] = useState(false);

  const uidRef = useRef<string | undefined>(undefined);
  const busyRef = useRef(false);
  const hiddenAt = useRef<number | null>(null);
  const graceUntil = useRef(0);
  const coldChecked = useRef(false);

  uidRef.current = user?.id;

  const unlock = useCallback(async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    const r = await authenticateBiometric();
    busyRef.current = false;
    setBusy(false);
    if (r === "ok") {
      graceUntil.current = Date.now() + 2000; // o próprio prompt pode disparar appStateChange
      setLocked(false);
    }
  }, []);

  const lock = useCallback(() => {
    setLocked(true);
    void unlock();
  }, [unlock]);

  // Arranque a frio com sessão já existente (não bloqueia logins novos nem o 1.º arranque)
  useEffect(() => {
    if (loading || coldChecked.current) return;
    coldChecked.current = true;
    if (isNativePlatform() && user && isBiometricEnabled(user.id)) lock();
  }, [loading, user, lock]);

  // Voltar de segundo plano
  useEffect(() => {
    if (!isNativePlatform()) return;
    return onAppActiveChange((active) => {
      if (!active) {
        if (!busyRef.current) hiddenAt.current = Date.now();
        return;
      }
      if (busyRef.current || Date.now() < graceUntil.current) return;
      const since = hiddenAt.current;
      hiddenAt.current = null;
      if (!since || !isBiometricEnabled(uidRef.current)) return;
      if (Date.now() - since > BIOMETRIC_LOCK_AFTER_MS) lock();
    });
  }, [lock]);

  // Logout → remove o bloqueio
  useEffect(() => {
    if (!user) setLocked(false);
  }, [user]);

  if (!locked || !user) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="App bloqueada"
      className="fixed inset-0 z-[9999] bg-white flex flex-col items-center justify-center px-8 text-center"
    >
      <AppLogo size="lg" framed />
      <div className="mt-6 w-10 h-10 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center">
        <Lock className="w-5 h-5" />
      </div>
      <h2 className="mt-3 text-lg font-bold text-slate-900">App bloqueada</h2>
      <p className="text-sm text-slate-500 mt-1 max-w-xs">Confirme a sua identidade para continuar.</p>
      <Button
        onClick={() => void unlock()}
        disabled={busy}
        className="mt-6 w-full max-w-xs bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-12 rounded-2xl"
      >
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : "Desbloquear"}
      </Button>
      <Button
        variant="ghost"
        onClick={() => void signOut()}
        className="mt-2 w-full max-w-xs text-red-500 hover:text-red-600 hover:bg-red-50 h-11 rounded-2xl font-bold text-xs gap-2"
      >
        <LogOut className="w-4 h-4" /> Encerrar sessão
      </Button>
    </div>
  );
};

export default BiometricLock;
