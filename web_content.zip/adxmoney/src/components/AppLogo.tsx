import React, { useState } from "react";
import { cn } from "@/lib/utils";
import { SPLASH_LOGO } from "@/lib/splashLogo";

type AppLogoProps = {
  /** Visual size in Tailwind scale or px-like: sm | md | lg | xl */
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  /** Show subtle native app-icon frame (ring + shadow) */
  framed?: boolean;
  alt?: string;
};

const sizeMap = {
  xs: "w-8 h-8 rounded-lg",
  sm: "w-10 h-10 rounded-xl",
  md: "w-14 h-14 rounded-2xl",
  lg: "w-20 h-20 rounded-[1.25rem]",
  xl: "w-28 h-28 sm:w-32 sm:h-32 rounded-[1.75rem]",
} as const;

/**
 * Logo do app com aspeto de ícone nativo (não “foto solta”).
 * Usa o logo embutido (data URI): carrega em qualquer WebView/offline; fallback texto se falhar.
 */
export const AppLogo: React.FC<AppLogoProps> = ({
  size = "md",
  className,
  framed = true,
  alt = "ADXmoney",
}) => {
  const [err, setErr] = useState(false);

  return (
    <div
      className={cn(
        "relative overflow-hidden flex items-center justify-center bg-[#0a0c12] select-none",
        sizeMap[size],
        framed &&
          "shadow-[0_1px_2px_rgba(15,23,42,0.08),0_4px_12px_rgba(15,23,42,0.06)] ring-1 ring-black/10",
        className,
      )}
      aria-hidden={alt ? undefined : true}
    >
      {!err ? (
        <img
          src={SPLASH_LOGO}
          alt={alt}
          width={128}
          height={128}
          decoding="async"
          loading="eager"
          onError={() => setErr(true)}
          className="w-full h-full object-cover pointer-events-none"
          draggable={false}
        />
      ) : (
        <span className="text-white font-extrabold tracking-tight text-[40%]">
          ADX
        </span>
      )}
    </div>
  );
};

export default AppLogo;
