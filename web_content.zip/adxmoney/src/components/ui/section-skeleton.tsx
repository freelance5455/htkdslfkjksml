import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

/** Esqueleto genérico de secção — substitui spinners de ecrã inteiro */
export function SectionSkeleton({
  rows = 4,
  className,
  withHeader = true,
}: {
  rows?: number;
  className?: string;
  withHeader?: boolean;
}) {
  return (
    <div className={cn("space-y-4 pb-4", className)} aria-busy="true" aria-label="A carregar">
      {withHeader && (
        <div className="space-y-2">
          <Skeleton className="h-5 w-40 rounded-md" />
          <Skeleton className="h-4 w-56 rounded-md" />
        </div>
      )}
      {Array.from({ length: rows }).map((_, i) => (
        <div
          key={i}
          className="rounded-xl border border-slate-100 bg-white p-4 space-y-3 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <Skeleton className="h-10 w-10 rounded-lg shrink-0" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-3/5 rounded-md" />
              <Skeleton className="h-3 w-2/5 rounded-md" />
            </div>
            <Skeleton className="h-6 w-14 rounded-full" />
          </div>
          {i % 2 === 0 && <Skeleton className="h-3 w-full rounded-md" />}
        </div>
      ))}
    </div>
  );
}

/** Grelha 2 colunas — útil para resumos / loja */
export function GridSkeleton({
  cells = 4,
  className,
}: {
  cells?: number;
  className?: string;
}) {
  return (
    <div className={cn("grid grid-cols-2 gap-2.5", className)} aria-busy="true">
      {Array.from({ length: cells }).map((_, i) => (
        <Skeleton key={i} className="h-28 rounded-xl" />
      ))}
    </div>
  );
}

/** Linhas de lista (carteira / movimentos) */
export function ListSkeleton({
  rows = 5,
  className,
}: {
  rows?: number;
  className?: string;
}) {
  return (
    <div className={cn("rounded-xl border border-slate-100 bg-white overflow-hidden divide-y divide-slate-50", className)} aria-busy="true">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 px-4 py-3.5">
          <Skeleton className="h-9 w-9 rounded-full shrink-0" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-3.5 w-32 rounded-md" />
            <Skeleton className="h-3 w-20 rounded-md" />
          </div>
          <Skeleton className="h-4 w-16 rounded-md" />
        </div>
      ))}
    </div>
  );
}
