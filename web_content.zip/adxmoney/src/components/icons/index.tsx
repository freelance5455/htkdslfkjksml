import * as React from "react";

/**
 * Ícones ADXmoney — desenho próprio, grelha 24×24, traço 1.75, extremidades redondas.
 * Uso: <Wallet className="w-5 h-5" />  (herdam a cor do texto: currentColor).
 * Os nomes seguem a convenção habitual (Home, Wallet, Check…); os `IconX` são apelidos mantidos por compatibilidade.
 */

export type IconProps = React.SVGProps<SVGSVGElement> & { size?: number | string };

function createIcon(name: string, children: React.ReactNode) {
  const Icon = React.forwardRef<SVGSVGElement, IconProps>(({ size = 24, ...props }, ref) => (
    <svg
      ref={ref}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      {children}
    </svg>
  ));
  Icon.displayName = name;
  return Icon;
}

export const Home = createIcon("Home", <><path d="M3.5 11.2L12 4L20.5 11.2"/><path d="M6 9.6V19.2Q6 20 6.8 20H17.2Q18 20 18 19.2V9.6"/><path d="M10 20V14.5H14V20"/></>);
export const Wallet = createIcon("Wallet", <><rect x="3" y="6" width="18" height="14" rx="3.2"/><path d="M6.5 6L15.5 3.5Q16.5 3.3 16.5 4.3V6"/><rect x="14.5" y="11.5" width="6.5" height="4.5" rx="2.2"/><circle cx="17.2" cy="13.75" r="0.75" fill="currentColor" stroke="none"/></>);
export const Tasks = createIcon("Tasks", <><rect x="4" y="3" width="16" height="18" rx="3.2"/><path d="M8 9.2L9.4 10.6L12 7.8"/><path d="M14.5 9H16.2"/><path d="M8 15.4L9.4 16.8L12 14"/><path d="M14.5 15.2H16.2"/></>);
export const Megaphone = createIcon("Megaphone", <><path d="M4 9.5H8L16 5V19L8 14.5H4Z"/><path d="M8 14.5L9.4 19.4H12.2"/><path d="M19 9.5Q20.6 12 19 14.5"/></>);
export const ShoppingBag = createIcon("ShoppingBag", <><path d="M5.2 8H18.8L19.8 19Q19.9 20 18.9 20H5.1Q4.1 20 4.2 19Z"/><path d="M8.8 8V7.2Q8.8 4 12 4Q15.2 4 15.2 7.2V8"/></>);
export const Users = createIcon("Users", <><circle cx="9" cy="8" r="3.2"/><path d="M3.4 19.4Q3.4 14.2 9 14.2Q14.6 14.2 14.6 19.4"/><circle cx="17.2" cy="9" r="2.4"/><path d="M16.6 14.3Q20.6 14.6 20.6 19.2"/></>);
export const UserPlus = createIcon("UserPlus", <><circle cx="9.6" cy="8" r="3.3"/><path d="M3.6 19.6Q3.6 14.3 9.6 14.3Q15.6 14.3 15.6 19.6"/><path d="M19 8.5V14.5"/><path d="M16 11.5H22"/></>);
export const UserCheck = createIcon("UserCheck", <><circle cx="9.6" cy="8" r="3.3"/><path d="M3.6 19.6Q3.6 14.3 9.6 14.3Q15.6 14.3 15.6 19.6"/><path d="M16.3 11.4L18.4 13.5L22 9.6"/></>);
export const User = createIcon("User", <><circle cx="12" cy="8" r="3.6"/><path d="M5 20Q5 14.2 12 14.2Q19 14.2 19 20"/></>);
export const Bell = createIcon("Bell", <><path d="M6 17.2V11Q6 5.8 12 5.8Q18 5.8 18 11V17.2"/><path d="M4.6 17.2H19.4"/><path d="M10 20.2Q12 21.8 14 20.2"/><path d="M12 3.6V5.8"/></>);
export const Settings = createIcon("Settings", <><circle cx="12" cy="12" r="2.6"/><circle cx="12" cy="12" r="6.4"/><line x1="19.40" y1="12.00" x2="21.60" y2="12.00"/><line x1="17.23" y1="17.23" x2="18.79" y2="18.79"/><line x1="12.00" y1="19.40" x2="12.00" y2="21.60"/><line x1="6.77" y1="17.23" x2="5.21" y2="18.79"/><line x1="4.60" y1="12.00" x2="2.40" y2="12.00"/><line x1="6.77" y1="6.77" x2="5.21" y2="5.21"/><line x1="12.00" y1="4.60" x2="12.00" y2="2.40"/><line x1="17.23" y1="6.77" x2="18.79" y2="5.21"/></>);
export const Lock = createIcon("Lock", <><rect x="5" y="10.8" width="14" height="9.6" rx="2.6"/><path d="M8 10.8V8.2Q8 4.4 12 4.4Q16 4.4 16 8.2V10.8"/><circle cx="12" cy="15.6" r="1.1" fill="currentColor" stroke="none"/></>);
export const LogOut = createIcon("LogOut", <><path d="M10 4H6.4Q4 4 4 6.4V17.6Q4 20 6.4 20H10"/><path d="M14 8L18 12L14 16"/><path d="M18 12H9"/></>);
export const Mail = createIcon("Mail", <><rect x="3" y="5.5" width="18" height="13" rx="3"/><path d="M4.2 8.4L12 13.6L19.8 8.4"/></>);
export const Phone = createIcon("Phone", <><rect x="6.8" y="2.8" width="10.4" height="18.4" rx="3"/><path d="M10.4 18H13.6"/></>);
export const Globe = createIcon("Globe", <><circle cx="12" cy="12" r="9"/><path d="M3 12H21"/><path d="M12 3Q7.2 7.6 7.2 12Q7.2 16.4 12 21"/><path d="M12 3Q16.8 7.6 16.8 12Q16.8 16.4 12 21"/></>);
export const Link2 = createIcon("Link2", <><rect x="2.6" y="9" width="10" height="6" rx="3"/><rect x="11.4" y="9" width="10" height="6" rx="3"/><path d="M9 12H15"/></>);
export const Copy = createIcon("Copy", <><rect x="8.2" y="8.2" width="12" height="12" rx="2.8"/><path d="M15.8 8.2V6.4Q15.8 4 13.4 4H6.6Q4 4 4 6.6V13.4Q4 15.8 6.4 15.8H8.2"/></>);
export const Share2 = createIcon("Share2", <><circle cx="18" cy="5.6" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="18.4" r="2.5"/><path d="M8.3 10.8L15.7 6.8"/><path d="M8.3 13.2L15.7 17.2"/></>);
export const ExternalLink = createIcon("ExternalLink", <><path d="M14 4H20V10"/><path d="M20 4L11 13"/><path d="M18 14.2V17.6Q18 20 15.6 20H6.4Q4 20 4 17.6V8.4Q4 6 6.4 6H9.8"/></>);
export const Search = createIcon("Search", <><circle cx="10.6" cy="10.6" r="6.4"/><path d="M15.4 15.4L20.4 20.4"/></>);
export const Menu = createIcon("Menu", <><path d="M4 7H20"/><path d="M4 12H20"/><path d="M4 17H20"/></>);
export const MoreVertical = createIcon("MoreVertical", <><circle cx="12" cy="5" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.5" fill="currentColor" stroke="none"/></>);
export const Plus = createIcon("Plus", <><path d="M12 5V19"/><path d="M5 12H19"/></>);
export const PlusCircle = createIcon("PlusCircle", <><circle cx="12" cy="12" r="9"/><path d="M12 8V16"/><path d="M8 12H16"/></>);
export const Minus = createIcon("Minus", <><path d="M5 12H19"/></>);
export const X = createIcon("X", <><path d="M6 6L18 18"/><path d="M18 6L6 18"/></>);
export const XCircle = createIcon("XCircle", <><circle cx="12" cy="12" r="9"/><path d="M9 9L15 15"/><path d="M15 9L9 15"/></>);
export const Check = createIcon("Check", <><path d="M5 12.6L10 17.4L19 7.2"/></>);
export const CheckCircle = createIcon("CheckCircle", <><circle cx="12" cy="12" r="9"/><path d="M8.2 12.4L11 15.2L16 9.4"/></>);
export const ChevronRight = createIcon("ChevronRight", <><path d="M9 5L16 12L9 19"/></>);
export const ChevronDown = createIcon("ChevronDown", <><path d="M5 9L12 16L19 9"/></>);
export const ChevronUp = createIcon("ChevronUp", <><path d="M5 15L12 8L19 15"/></>);
export const ArrowLeft = createIcon("ArrowLeft", <><path d="M19.5 12H5"/><path d="M11 6L5 12L11 18"/></>);
export const ArrowRight = createIcon("ArrowRight", <><path d="M4.5 12H19"/><path d="M13 6L19 12L13 18"/></>);
export const ArrowUpRight = createIcon("ArrowUpRight", <><path d="M7 17L17 7"/><path d="M8.5 7H17V15.5"/></>);
export const ArrowDownLeft = createIcon("ArrowDownLeft", <><path d="M17 7L7 17"/><path d="M15.5 17H7V8.5"/></>);
export const Eye = createIcon("Eye", <><path d="M2.4 12Q12 3.4 21.6 12Q12 20.6 2.4 12Z"/><circle cx="12" cy="12" r="3.1"/></>);
export const EyeOff = createIcon("EyeOff", <><path d="M2.4 12Q12 3.4 21.6 12Q12 20.6 2.4 12Z"/><circle cx="12" cy="12" r="3.1"/><path d="M4 4L20 20"/></>);
export const Trash2 = createIcon("Trash2", <><path d="M4.6 7H19.4"/><path d="M9.2 7V5.2Q9.2 4 10.4 4H13.6Q14.8 4 14.8 5.2V7"/><path d="M6.4 7L7.2 19Q7.3 20.2 8.5 20.2H15.5Q16.7 20.2 16.8 19L17.6 7"/><path d="M10.2 11V16"/><path d="M13.8 11V16"/></>);
export const Upload = createIcon("Upload", <><path d="M4 15V17.8Q4 20 6.2 20H17.8Q20 20 20 17.8V15"/><path d="M12 15V4.8"/><path d="M7.6 9L12 4.6L16.4 9"/></>);
export const Image = createIcon("Image", <><rect x="3" y="4.4" width="18" height="15.2" rx="3.2"/><circle cx="8.6" cy="9.8" r="1.6"/><path d="M4.4 17.6L9.4 12.8L13 16L15.6 13.6L19.8 17.8"/></>);
export const FileText = createIcon("FileText", <><path d="M7 3H13.6L19 8.4V18.6Q19 21 16.6 21H7.4Q5 21 5 18.6V5.4Q5 3 7.4 3Z"/><path d="M13.4 3.2V8.6H18.8"/><path d="M8.6 13.2H15.4"/><path d="M8.6 17H13"/></>);
export const Flag = createIcon("Flag", <><path d="M5.4 21V4"/><path d="M5.4 4.4H18L15.4 8.2L18 12H5.4"/></>);
export const Clock = createIcon("Clock", <><circle cx="12" cy="12" r="9"/><path d="M12 7V12L15.4 14"/></>);
export const History = createIcon("History", <><path d="M4.2 12A7.8 7.8 0 1 0 6.5 6.5"/><path d="M4 4.2V8.4H8.2"/><path d="M12 8V12L14.8 13.6"/></>);
export const Info = createIcon("Info", <><circle cx="12" cy="12" r="9"/><path d="M12 11.2V16.4"/><circle cx="12" cy="7.9" r="1" fill="currentColor" stroke="none"/></>);
export const HelpCircle = createIcon("HelpCircle", <><circle cx="12" cy="12" r="9"/><path d="M9.4 9.6Q9.4 7.2 12 7.2Q14.6 7.2 14.6 9.4Q14.6 11 12 12V13.2"/><circle cx="12" cy="16.4" r="1" fill="currentColor" stroke="none"/></>);
export const AlertTriangle = createIcon("AlertTriangle", <><path d="M12 4L21 19.6H3Z"/><path d="M12 10V14"/><circle cx="12" cy="16.8" r="1" fill="currentColor" stroke="none"/></>);
export const Shield = createIcon("Shield", <><path d="M12 3L19.5 6V11.5Q19.5 17.5 12 21Q4.5 17.5 4.5 11.5V6Z"/></>);
export const ShieldCheck = createIcon("ShieldCheck", <><path d="M12 3L19.5 6V11.5Q19.5 17.5 12 21Q4.5 17.5 4.5 11.5V6Z"/><path d="M8.6 12L11 14.4L15.6 9.6"/></>);
export const CreditCard = createIcon("CreditCard", <><rect x="3" y="5.4" width="18" height="13.2" rx="3.2"/><path d="M3 10H21"/><path d="M6.6 14.6H10.4"/></>);
export const Send = createIcon("Send", <><path d="M21 3L3 10.4L10.4 13.6L13.6 21Z"/><path d="M10.4 13.6L21 3"/></>);
export const RefreshCw = createIcon("RefreshCw", <><path d="M19.6 10.6A8 8 0 0 0 5.2 7.6"/><path d="M20 5V10.6H14.4"/><path d="M4.4 13.4A8 8 0 0 0 18.8 16.4"/><path d="M4 19V13.4H9.6"/></>);
export const Loader2 = createIcon("Loader2", <><path d="M12 3.5A8.5 8.5 0 1 1 3.5 12"/></>);
export const Wifi = createIcon("Wifi", <><path d="M3.6 9.6Q12 2.6 20.4 9.6"/><path d="M6.6 13Q12 8.4 17.4 13"/><path d="M9.5 16.3Q12 14.2 14.5 16.3"/><circle cx="12" cy="19.4" r="1.15" fill="currentColor" stroke="none"/></>);
export const WifiOff = createIcon("WifiOff", <><path d="M3.6 9.6Q8 5.9 12.6 5.7"/><path d="M6.6 13Q9 11 11.2 10.4"/><path d="M9.5 16.3Q12 14.2 14.5 16.3"/><circle cx="12" cy="19.4" r="1.15" fill="currentColor" stroke="none"/><path d="M4 4L20 20"/></>);
export const PlayCircle = createIcon("PlayCircle", <><circle cx="12" cy="12" r="9"/><path d="M10 8.6L15.4 12L10 15.4Z"/></>);
export const MessageSquare = createIcon("MessageSquare", <><path d="M5.6 4H18.4Q21 4 21 6.6V14.4Q21 17 18.4 17H12L7.4 21V17H5.6Q3 17 3 14.4V6.6Q3 4 5.6 4Z"/></>);
export const TrendingUp = createIcon("TrendingUp", <><path d="M3 17L9 11L13 15L21 7"/><path d="M15 7H21V13"/></>);
export const TrendingDown = createIcon("TrendingDown", <><path d="M3 7L9 13L13 9L21 17"/><path d="M15 17H21V11"/></>);
export const LayoutDashboard = createIcon("LayoutDashboard", <><rect x="3" y="3" width="8" height="10" rx="2.2"/><rect x="13" y="3" width="8" height="6" rx="2.2"/><rect x="13" y="11" width="8" height="10" rx="2.2"/><rect x="3" y="15" width="8" height="6" rx="2.2"/></>);
export const Target = createIcon("Target", <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/></>);
export const Circle = createIcon("Circle", <><circle cx="12" cy="12" r="4.5" fill="currentColor" stroke="none"/></>);
export const BarChart = createIcon("BarChart", <><rect x="4" y="11" width="3.6" height="9" rx="1.2"/><rect x="10.2" y="4.6" width="3.6" height="15.4" rx="1.2"/><rect x="16.4" y="8" width="3.6" height="12" rx="1.2"/></>);
export const Ranking = createIcon("Ranking", <><rect x="3" y="12" width="5.6" height="8" rx="1.4"/><rect x="9.2" y="4.4" width="5.6" height="15.6" rx="1.4"/><rect x="15.4" y="9" width="5.6" height="11" rx="1.4"/></>);
export const Priority = createIcon("Priority", <><path d="M6 6L12 12L6 18"/><path d="M12 6L18 12L12 18"/></>);
export const Percent = createIcon("Percent", <><path d="M19 5L5 19"/><circle cx="7.2" cy="7.2" r="2.3"/><circle cx="16.8" cy="16.8" r="2.3"/></>);
export const Pencil = createIcon("Pencil", <><path d="M4.4 19.6L5.2 15.6L15.6 5.2Q16.8 4 18 5.2L18.8 6Q20 7.2 18.8 8.4L8.4 18.8Z"/><path d="M13.6 7.2L16.8 10.4"/></>);
export const LevelBronze = createIcon("LevelBronze", <><path d="M12 3L19.5 6V11.5Q19.5 17.5 12 21Q4.5 17.5 4.5 11.5V6Z"/><path d="M9 14.2L12 11.2L15 14.2"/></>);
export const LevelSilver = createIcon("LevelSilver", <><path d="M12 3L19.5 6V11.5Q19.5 17.5 12 21Q4.5 17.5 4.5 11.5V6Z"/><path d="M9 15.4L12 12.4L15 15.4"/><path d="M9 12.8L12 9.8L15 12.8"/></>);
export const LevelGold = createIcon("LevelGold", <><path d="M12 3L19.5 6V11.5Q19.5 17.5 12 21Q4.5 17.5 4.5 11.5V6Z"/><path d="M9.3 15.8L12 13.100000000000001L14.7 15.8"/><path d="M9.3 13.1L12 10.399999999999999L14.7 13.1"/><path d="M9.3 10.4L12 7.7L14.7 10.4"/></>);
export const LevelPlatinum = createIcon("LevelPlatinum", <><path d="M12 3L19.5 6V11.5Q19.5 17.5 12 21Q4.5 17.5 4.5 11.5V6Z"/><path d="M12 7.4L15.6 11.6L12 16.4L8.4 11.6Z"/><path d="M8.4 11.6H15.6"/></>);
export const Deposit = createIcon("Deposit", <><path d="M12 4V14.4"/><path d="M7.6 10.2L12 14.6L16.4 10.2"/><path d="M4 16.6V18Q4 20 6 20H18Q20 20 20 18V16.6"/></>);
export const Camera = createIcon("Camera", <><path d="M4.6 8H7.4L9 5.6H15L16.6 8H19.4Q21 8 21 9.6V17.4Q21 19 19.4 19H4.6Q3 19 3 17.4V9.6Q3 8 4.6 8Z"/><circle cx="12" cy="13.4" r="3.2"/></>);
export const MoreHorizontal = createIcon("MoreHorizontal", <><circle cx="5" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.5" fill="currentColor" stroke="none"/></>);

/* Apelidos de compatibilidade */
export const Activity = BarChart;
export const CheckCircle2 = CheckCircle;
export const FileQuestion = FileText;
export const ImageIcon = Image;
export const Layers = Tasks;
export const MessageCircleQuestion = HelpCircle;
export const UserIcon = User;
export const ShoppingCart = ShoppingBag;
export const Withdraw = Upload;

/** Ícones de plataformas sociais — preenchidos, legíveis em tamanho pequeno */
export const BrandTikTok = React.forwardRef<SVGSVGElement, IconProps>(({ size = 24, className, ...props }, ref) => (
  <svg ref={ref} width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" className={className} {...props}>
    <path d="M16.6 5.82A4.84 4.84 0 0 1 14.2 4.1V15.1a4.1 4.1 0 1 1-3.52-4.06v2.18a2 2 0 1 0 1.42 1.91V2h2.18c.2 1.55 1.06 2.88 2.32 3.82Z" />
  </svg>
));
BrandTikTok.displayName = "BrandTikTok";

export const BrandInstagram = React.forwardRef<SVGSVGElement, IconProps>(({ size = 24, className, ...props }, ref) => (
  <svg ref={ref} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" className={className} {...props}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
  </svg>
));
BrandInstagram.displayName = "BrandInstagram";

export const BrandYouTube = React.forwardRef<SVGSVGElement, IconProps>(({ size = 24, className, ...props }, ref) => (
  <svg ref={ref} width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false" className={className} {...props}>
    <path d="M22.5 7.5a3.4 3.4 0 0 0-2.4-2.4C18.3 4.7 12 4.7 12 4.7s-6.3 0-8.1.4A3.4 3.4 0 0 0 1.5 7.5 35.6 35.6 0 0 0 1.1 12a35.6 35.6 0 0 0 .4 4.5 3.4 3.4 0 0 0 2.4 2.4c1.8.4 8.1.4 8.1.4s6.3 0 8.1-.4a3.4 3.4 0 0 0 2.4-2.4 35.6 35.6 0 0 0 .4-4.5 35.6 35.6 0 0 0-.4-4.5ZM10 15.2V8.8L15.5 12 10 15.2Z" />
  </svg>
));
BrandYouTube.displayName = "BrandYouTube";

export const IconHome = Home;
export const IconTasks = Tasks;
export const IconCampaigns = Megaphone;
export const IconStore = ShoppingBag;
export const IconWallet = Wallet;
export const IconMore = MoreHorizontal;
export const IconDeposit = Deposit;
export const IconWithdraw = Upload;
export const IconSend = Send;
export const IconReceive = ArrowDownLeft;
export const IconProof = Camera;
export const IconValidate = ShieldCheck;
export const IconInvite = UserPlus;
export const IconUsers = Users;
export const IconTrendingUp = TrendingUp;
export const IconTrendingDown = TrendingDown;
export const IconMessage = MessageSquare;
export const IconHelp = HelpCircle;
export const IconActivity = BarChart;
export const IconShield = Shield;
export const IconShare = Share2;
export const IconSettings = Settings;
export const IconSearch = Search;
export const IconRefresh = RefreshCw;
export const IconPlus = Plus;
export const IconLogout = LogOut;
export const IconLock = Lock;
export const IconLoader = Loader2;
export const IconInfo = Info;
export const IconEyeOff = EyeOff;
export const IconEye = Eye;
export const IconExternal = ExternalLink;
export const IconCopy = Copy;
export const IconClose = X;
export const IconClock = Clock;
export const IconChevronRight = ChevronRight;
export const IconChevronDown = ChevronDown;
export const IconCheck = Check;
export const IconBell = Bell;
export const IconAlert = AlertTriangle;
export const IconBadge = ShieldCheck;
export const IconLevel = LevelGold;

/** Distintivo do nível de membro (bronze → platina). */
export function LevelIcon({ level, ...props }: IconProps & { level?: string | null }) {
  const C = level === "platinum" ? LevelPlatinum : level === "gold" ? LevelGold : level === "silver" ? LevelSilver : LevelBronze;
  return <C {...props} />;
}
