import React, { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { FEATURES } from "@/lib/features";
import { isNativePlatform } from "@/lib/nativeShell";
import { onAppActiveChange } from "@/lib/appLifecycle";
import {
  evaluateUpdate,
  fetchVersionConfig,
  getCurrentVersion,
  hardReloadPwa,
  type VersionConfig,
} from "@/lib/appVersion";
import { Button } from "@/components/ui/button";

const RECHECK_MS = 10 * 60 * 1000;

function openUpdate(cfg: VersionConfig | null) {
  if (isNativePlatform() && cfg?.store_url) {
    window.open(cfg.store_url, "_blank");
    return;
  }
  void hardReloadPwa();
}

/**
 * Version check: corre no arranque e ao voltar à app (máx. 1x / 10 min).
 * - obrigatória (force_update + versão < min_version): ecrã bloqueante
 * - opcional: aviso discreto 1x por sessão
 * Falhas de rede/tabela são ignoradas.
 */
export const UpdateGate: React.FC = () => {
  const [blocking, setBlocking] = useState<VersionConfig | null>(null);
  const lastCheck = useRef(0);
  const softShown = useRef(false);

  const check = useCallback(async () => {
    if (!FEATURES.VERSION_CHECK) return;
    if (Date.now() - lastCheck.current < RECHECK_MS) return;
    lastCheck.current = Date.now();
    try {
      const [current, cfg] = await Promise.all([getCurrentVersion(), fetchVersionConfig()]);
      if (!cfg) return;
      const status = evaluateUpdate(current, cfg);
      setBlocking(status === "required" ? cfg : null);
      if (status === "optional" && !softShown.current) {
        softShown.current = true;
        toast("Nova versão disponível", {
          description: cfg.message || "Atualize para ter as últimas melhorias.",
          duration: 12_000,
          action: { label: "Atualizar", onClick: () => openUpdate(cfg) },
        });
      }
    } catch {
      /* nunca bloquear por falha do check */
    }
  }, []);

  useEffect(() => {
    void check();
    return onAppActiveChange((active) => {
      if (active) void check();
    });
  }, [check]);

  if (!blocking) return null;

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      className="fixed inset-0 z-[10000] bg-white flex flex-col items-center justify-center px-8 text-center"
    >
      <h2 className="text-lg font-bold text-slate-900">Atualização necessária</h2>
      <p className="text-sm text-slate-500 mt-2 max-w-xs">
        {blocking.message || "Esta versão do ADXmoney já não é suportada. Atualize a app para continuar."}
      </p>
      <Button
        onClick={() => openUpdate(blocking)}
        className="mt-6 w-full max-w-xs bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-12 rounded-2xl"
      >
        {isNativePlatform() ? "Atualizar na loja" : "Atualizar agora"}
      </Button>
    </div>
  );
};

export default UpdateGate;
