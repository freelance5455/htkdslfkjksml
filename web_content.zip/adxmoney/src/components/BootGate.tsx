import React, { useEffect, useLayoutEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { SplashScreen } from "@/components/SplashScreen";
import { useConnectivity } from "@/hooks/useConnectivity";

/** Tempo mínimo do splash, contado desde o início do carregamento da página. */
const MIN_BOOT_MS = 2600;
/** Duração do desvanecimento final (igual ao CSS .adx-splash). */
const FADE_MS = 500;

type Phase = "splash" | "fading" | "done";

/**
 * Splash único e contínuo no arranque (APK / PWA):
 *  1) o splash HTML do index.html aparece antes do JS (funciona sem rede);
 *  2) o React assume com um splash idêntico (sem salto nem segundo ecrã);
 *  3) assim que a sessão carrega, a app (login ou área logada) é montada POR TRÁS do splash,
 *     em segundo plano;
 *  4) o splash só desvanece quando: sessão pronta + tempo mínimo + ligação à internet
 *     (sem internet mostra a página "Sem conexão"; entra sozinho quando a rede volta);
 *  5) depois do arranque, se a internet cair (mesmo com sessão iniciada) a página "Sem conexão"
 *     cobre a app; a app fica montada por baixo (estado preservado) e retoma quando a rede volta.
 *
 * Não altera rotas nem a lógica de login/auth.
 */
export const BootGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { loading, signingOut } = useAuth();
  const [minElapsed, setMinElapsed] = useState(false);
  const [phase, setPhase] = useState<Phase>("splash");
  const [logoutPhase, setLogoutPhase] = useState<"idle" | "show" | "fading">("idle");

  // Ligação real (não só navigator.onLine)
  const { online, recheck } = useConnectivity();

  // Tempo mínimo desde o início da página (não desde o mount do React)
  useEffect(() => {
    const sinceStart = typeof performance !== "undefined" ? performance.now() : 0;
    const t = window.setTimeout(() => setMinElapsed(true), Math.max(0, MIN_BOOT_MS - sinceStart));
    return () => window.clearTimeout(t);
  }, []);

  // O splash React (idêntico) já está no DOM: remove o HTML no mesmo frame, sem transição visível.
  useLayoutEffect(() => {
    document.getElementById("adx-boot-splash")?.remove();
  }, []);

  const waitingOffline = !online;
  const ready = !loading && minElapsed && !waitingOffline;

  useEffect(() => {
    if (ready && phase === "splash") setPhase("fading");
  }, [ready, phase]);

  useEffect(() => {
    if (phase !== "fading") return;
    const t = window.setTimeout(() => setPhase("done"), FADE_MS);
    return () => window.clearTimeout(t);
  }, [phase]);

  // Splash de saída: aparece ao terminar sessão e desvanece quando o login já está por trás
  useEffect(() => {
    if (signingOut) setLogoutPhase("show");
    else setLogoutPhase((p) => (p === "show" ? "fading" : p));
  }, [signingOut]);

  useEffect(() => {
    if (logoutPhase !== "fading") return;
    const t = window.setTimeout(() => setLogoutPhase("idle"), FADE_MS);
    return () => window.clearTimeout(t);
  }, [logoutPhase]);

  // Sem internet depois do arranque: página "Sem conexão" por cima da app (a app NÃO é desmontada,
  // por isso formulários e estado são preservados). Desvanece sozinha quando a ligação volta.
  const [offlinePhase, setOfflinePhase] = useState<"idle" | "show" | "fading">("idle");
  useEffect(() => {
    if (phase !== "done") return;
    if (!online) setOfflinePhase("show");
    else setOfflinePhase((p) => (p === "show" ? "fading" : p));
  }, [online, phase]);
  useEffect(() => {
    if (offlinePhase !== "fading") return;
    const t = window.setTimeout(() => setOfflinePhase("idle"), FADE_MS);
    return () => window.clearTimeout(t);
  }, [offlinePhase]);

  const bootActive = phase !== "done";
  const logoutActive = logoutPhase !== "idle";
  const offlineActive = offlinePhase !== "idle";

  return (
    <>
      {/* A app monta em segundo plano assim que a sessão está resolvida */}
      {(!loading || phase === "done") && children}
      {(bootActive || logoutActive || offlineActive) && (
        <SplashScreen
          variant={bootActive ? "boot" : logoutActive ? "logout" : "offline"}
          // durante o desvanecimento mantém a vista offline (sem piscar "A carregar…")
          offline={bootActive || logoutActive ? !online : true}
          onRetry={recheck}
          fading={
            bootActive
              ? phase === "fading"
              : logoutActive
                ? logoutPhase === "fading"
                : offlinePhase === "fading"
          }
        />
      )}
    </>
  );
};

export default BootGate;
