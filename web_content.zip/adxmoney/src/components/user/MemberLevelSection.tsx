import React, { useState } from "react";
import { Copy, Loader2, CheckCircle2, Lock, Users, TrendingUp } from "@/components/icons";
import { LevelBronze, LevelSilver, LevelGold, LevelPlatinum, Ranking, ShieldCheck, FileText, UserPlus, Wallet } from "@/components/icons";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { toast } from "sonner";

export type MemberLevel = "bronze" | "silver" | "gold" | "platinum";

export interface LevelInfo {
  user_id: string;
  name: string;
  member_level: MemberLevel;
  priority_withdrawal: boolean;
  custom_affiliate_code: string | null;
  referral_code: string | null;
  total_referrals: number;
  total_earned: number;
  rank_position: number | null;
  benefits: string[];
}

export interface RankingEntry {
  rank_position: number;
  name: string;
  member_level: MemberLevel;
  total_referrals: number;
  total_earned: number;
  is_me: boolean;
}

interface MemberLevelSectionProps {
  levelInfo: LevelInfo | null;
  ranking: RankingEntry[];
  loading: boolean;
  formatCurrency: (amountKz: number) => string;
  onSetCustomCode: (code: string) => Promise<boolean>;
  onRefresh: () => void;
}

const LEVEL_CONFIG: Record<
  MemberLevel,
  {
    label: string;
    color: string;
    bg: string;
    border: string;
    icon: React.ElementType;
    gradient: string;
  }
> = {
  bronze: {
    label: "Bronze",
    color: "text-amber-800",
    bg: "bg-amber-50",
    border: "border-amber-200",
    icon: LevelBronze,
    gradient: "from-amber-600 to-amber-800",
  },
  silver: {
    label: "Silver",
    color: "text-slate-600",
    bg: "bg-slate-100",
    border: "border-slate-300",
    icon: LevelSilver,
    gradient: "from-slate-400 to-slate-600",
  },
  gold: {
    label: "Gold",
    color: "text-yellow-700",
    bg: "bg-yellow-50",
    border: "border-yellow-300",
    icon: LevelGold,
    gradient: "from-yellow-500 to-amber-600",
  },
  platinum: {
    label: "Platinum",
    color: "text-indigo-700",
    bg: "bg-indigo-50",
    border: "border-indigo-300",
    icon: LevelPlatinum,
    gradient: "from-indigo-500 to-purple-700",
  },
};

const NEXT_LEVEL: Record<MemberLevel, { label: string; referrals: number; earned: number } | null> = {
  bronze: { label: "Silver", referrals: 5, earned: 5000 },
  silver: { label: "Gold", referrals: 15, earned: 15000 },
  gold: { label: "Platinum", referrals: 50, earned: 50000 },
  platinum: null,
};

export const MemberLevelSection: React.FC<MemberLevelSectionProps> = ({
  levelInfo,
  ranking,
  loading,
  formatCurrency,
  onSetCustomCode,
  onRefresh,
}) => {
  const [customCode, setCustomCode] = useState("");
  const [savingCode, setSavingCode] = useState(false);
  const [showCertificate, setShowCertificate] = useState(false);

  if (loading || !levelInfo) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  const cfg = LEVEL_CONFIG[levelInfo.member_level] || LEVEL_CONFIG.bronze;
  const LevelIcon = cfg.icon;
  const next = NEXT_LEVEL[levelInfo.member_level];
  const canCustomCode = levelInfo.member_level === "gold" || levelInfo.member_level === "platinum";

  const progressReferrals = next
    ? Math.min(100, (levelInfo.total_referrals / next.referrals) * 100)
    : 100;
  const progressEarned = next
    ? Math.min(100, (levelInfo.total_earned / next.earned) * 100)
    : 100;

  const handleSaveCode = async () => {
    if (!customCode.trim()) {
      toast.error("Introduza um código válido");
      return;
    }
    setSavingCode(true);
    const ok = await onSetCustomCode(customCode.trim());
    setSavingCode(false);
    if (ok) {
      setCustomCode("");
      onRefresh();
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("Código copiado!");
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
      {/* Header */}
      <div className="px-1">
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Nível & Ranking</h2>
        <p className="text-xs text-slate-500 font-medium mt-1">
          O seu estatuto e posição na comunidade ADX
        </p>
      </div>

      {/* Card principal de nível */}
      <Card className="rounded-2xl overflow-hidden bg-[#0b5f58] border border-teal-900/20 shadow-sm">
        <CardContent className="p-6 sm:p-8 text-white relative">
          <div className="absolute top-4 right-4 opacity-15">
            <LevelIcon className="w-24 h-24" />
          </div>
          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-white/15 flex items-center justify-center">
                <LevelIcon className="w-8 h-8" />
              </div>
              <div>
                <p className="text-xs font-medium text-white/70">Nível atual</p>
                <h3 className="text-2xl font-semibold tracking-tight">{cfg.label}</h3>
                <p className="text-sm text-white/85 mt-0.5">{levelInfo.name}</p>
              </div>
            </div>
            <div className="flex flex-col sm:items-end gap-2">
              {levelInfo.rank_position && (
                <div className="flex items-center gap-2 bg-white/12 px-4 py-2 rounded-xl border border-white/10">
                  <Ranking className="w-4 h-4" />
                  <span className="text-sm font-semibold">
                    #{levelInfo.rank_position} no ranking
                  </span>
                </div>
              )}
              {levelInfo.priority_withdrawal && (
                <Badge className="bg-white/15 text-white border border-white/10 font-medium text-[11px]">
                  <Wallet className="w-3 h-3 mr-1" /> Saque prioritário
                </Badge>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3 mt-8 relative z-10">
            <div className="bg-white/10 rounded-xl p-4 border border-white/10">
              <p className="text-[12px] font-medium text-white/65">Indicações</p>
              <p className="text-2xl font-semibold mt-1 tabular-nums tracking-tight">{levelInfo.total_referrals}</p>
            </div>
            <div className="bg-white/10 rounded-xl p-4 border border-white/10">
              <p className="text-[12px] font-medium text-white/65">Ganhos afiliado</p>
              <p className="text-2xl font-semibold mt-1 tracking-tight">{formatCurrency(levelInfo.total_earned)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progresso para o próximo nível */}
      {next && (
        <Card className="card-clean">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Progresso para {next.label}
            </CardTitle>
            <CardDescription className="text-xs">
              Precisa de {next.referrals} indicações ou {formatCurrency(next.earned)} em ganhos
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-[11px] font-semibold text-slate-500 mb-1.5">
                <span>Indicações ({levelInfo.total_referrals}/{next.referrals})</span>
                <span>{Math.round(progressReferrals)}%</span>
              </div>
              <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressReferrals}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-[11px] font-semibold text-slate-500 mb-1.5">
                <span>Ganhos ({formatCurrency(levelInfo.total_earned)} / {formatCurrency(next.earned)})</span>
                <span>{Math.round(progressEarned)}%</span>
              </div>
              <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressEarned}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Benefícios */}
      <Card className="card-clean">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-500" />
            Benefícios do nível {cfg.label}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {levelInfo.benefits.map((b, i) => (
              <li key={i} className="flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span className="text-sm text-slate-700 font-medium">{b}</span>
              </li>
            ))}
          </ul>
          <Button
            variant="outline"
            className="mt-6 w-full rounded-xl h-11 font-semibold text-[13px]"
            onClick={() => setShowCertificate(true)}
          >
            <FileText className="w-4 h-4 mr-2" />
            Ver certificado de membro
          </Button>
        </CardContent>
      </Card>

      {/* Código personalizado (Gold+) */}
      <Card className="card-clean">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <UserPlus className="w-4 h-4 text-sky-500" />
            Código de afiliado
          </CardTitle>
          <CardDescription className="text-xs">
            {canCustomCode
              ? "Como membro Gold/Platinum pode personalizar o seu código"
              : "Personalização disponível a partir do nível Gold"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-2xl">
            <code className="flex-1 text-sm font-bold text-slate-800">
              {levelInfo.custom_affiliate_code || levelInfo.referral_code || "—"}
            </code>
            <Button
              size="sm"
              variant="ghost"
              className="h-11 w-11 p-0"
              onClick={() =>
                copyCode(levelInfo.custom_affiliate_code || levelInfo.referral_code || "")
              }
            >
              <Copy className="w-4 h-4" />
            </Button>
          </div>

          {canCustomCode ? (
            <div className="space-y-3 pt-2">
              <Label className="text-[11px] font-semibold text-slate-400">
                Novo código personalizado
              </Label>
              <div className="flex gap-2">
                <Input
                  value={customCode}
                  onChange={(e) => setCustomCode(e.target.value.toUpperCase())}
                  placeholder="EX: MEUCODIGO"
                  maxLength={16}
                  className="rounded-xl h-11 font-mono "
                />
                <Button
                  onClick={handleSaveCode}
                  disabled={savingCode || !customCode.trim()}
                  className="h-11 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold text-xs "
                >
                  {savingCode ? <Loader2 className="w-4 h-4 animate-spin" /> : "Guardar"}
                </Button>
              </div>
              <p className="text-[11px] text-slate-400">
                4–16 caracteres · apenas letras, números e _
              </p>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs text-slate-400 font-medium pt-1">
              <Lock className="w-3.5 h-3.5" />
              Desbloqueie no nível Gold (15+ indicações ou {formatCurrency(15000)} em ganhos)
            </div>
          )}
        </CardContent>
      </Card>

      {/* Ranking */}
      <Card className="card-clean">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <Users className="w-4 h-4 text-teal-700" />
            Ranking da comunidade
          </CardTitle>
          <CardDescription className="text-xs">
            Top membros por indicações e ganhos
          </CardDescription>
        </CardHeader>
        <CardContent>
          {ranking.length === 0 ? (
            <p className="text-center text-sm text-slate-400 py-8">
              Ainda não há dados de ranking.
            </p>
          ) : (
            <div className="space-y-2">
              {ranking.map((entry) => {
                const eCfg = LEVEL_CONFIG[entry.member_level] || LEVEL_CONFIG.bronze;
                return (
                  <div
                    key={entry.rank_position}
                    className={`flex items-center gap-3 p-3 rounded-2xl transition-colors ${
                      entry.is_me
                        ? "bg-emerald-50 border border-emerald-100"
                        : "bg-slate-50/80 hover:bg-slate-50"
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
                        entry.rank_position <= 3
                          ? "bg-amber-100 text-amber-700"
                          : "bg-slate-200 text-slate-600"
                      }`}
                    >
                      {entry.rank_position}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-800 truncate">
                        {entry.name}
                        {entry.is_me && (
                          <span className="ml-1.5 text-[11px] text-emerald-600 font-semibold ">
                            (você)
                          </span>
                        )}
                      </p>
                      <p className="text-[11px] text-slate-400 font-medium">
                        {entry.total_referrals} ind. · {formatCurrency(entry.total_earned)}
                      </p>
                    </div>
                    <Badge
                      className={`${eCfg.bg} ${eCfg.color} border-none font-semibold text-[11px] `}
                    >
                      {eCfg.label}
                    </Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal Certificado */}
      <Dialog open={showCertificate} onOpenChange={setShowCertificate}>
        <DialogContent className="sm:max-w-md rounded-2xl p-0 overflow-hidden">
          <div className={`bg-gradient-to-br ${cfg.gradient} p-8 text-white text-center`}>
            <div className="w-16 h-16 mx-auto rounded-2xl bg-white/20 flex items-center justify-center mb-4">
              <LevelIcon className="w-8 h-8" />
            </div>
            <p className="text-[11px] font-semibold tracking-[0.2em] opacity-80">
              Certificado de Membro
            </p>
            <h3 className="text-2xl font-bold mt-1 tracking-tight">ADXmoney</h3>
          </div>
          <div className="p-6 sm:p-8 text-center space-y-4">
            <p className="text-xs text-slate-400 font-medium ">
              Certifica-se que
            </p>
            <p className="text-xl font-bold text-slate-900">{levelInfo.name}</p>
            <p className="text-sm text-slate-600">
              é membro <strong className={cfg.color}>{cfg.label}</strong> da plataforma ADXmoney
            </p>
            <div className="flex justify-center gap-6 pt-2 text-[11px] text-slate-500 font-semibold">
              <div>
                <p className="text-slate-400 font-semibold text-[11px]">Indicações</p>
                <p className="text-lg text-slate-800">{levelInfo.total_referrals}</p>
              </div>
              <div>
                <p className="text-slate-400 font-semibold text-[11px]">Ranking</p>
                <p className="text-lg text-slate-800">
                  #{levelInfo.rank_position || "—"}
                </p>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 pt-4 border-t border-slate-100">
              Emitido automaticamente · ADXmoney © {new Date().getFullYear()}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MemberLevelSection;
