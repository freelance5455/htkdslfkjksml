import { checkProofFile, prepareProof, proofPath } from "@/lib/upload";
import React, { useState, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, ShieldCheck, Upload, Copy, ArrowLeft, ArrowRight, FileText, X, Image as ImageIcon } from "@/components/icons";
import { toast } from "sonner";

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  currency: "USD" | "AOA" | "EUR" | "BRL";
  exchangeRates: {
    AOA: number;
    USD: number;
    EUR: number;
    BRL: number;
  };
  onSuccess?: () => void;
  /** Nome do perfil autenticado — preenchido automaticamente */
  defaultPayerName?: string;
  /** Renovação de uma assinatura ativa (ou expirada) */
  renewal?: boolean;
  /** Validade actual (ISO) — mostrada na renovação */
  expiresAt?: string | null;
}

type WalletMethod = "unitel" | "express" | "remitly";
type Step = 1 | 2 | 3;

const WALLETS: {
  id: WalletMethod;
  label: string;
  description: string;
  icon: string;
}[] = [
  {
    id: "unitel",
    label: "Unitel Money",
    description: "Transferência via carteira Unitel Money",
    icon: "/icons/unitel.jpg",
  },
  {
    id: "express",
    label: "Multicaixa Express",
    description: "Pagamento via Multicaixa Express",
    icon: "/icons/express.jpg",
  },
  {
    id: "remitly",
    label: "Remitly",
    description: "Transferência internacional (Remitly)",
    icon: "/icons/remitly.jpg",
  },
];

const PAYMENT_NUMBER = "933 271 690";

const ACCEPTED_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "application/pdf",
];

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  userId,
  currency,
  exchangeRates,
  onSuccess,
  defaultPayerName = "",
  renewal = false,
  expiresAt = null,
}) => {
  const [step, setStep] = useState<Step>(1);
  const [selectedMethod, setSelectedMethod] = useState<WalletMethod | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Step 2 fields — nome vem do perfil autenticado
  const [payerName, setPayerName] = useState(defaultPayerName);
  const [transactionId, setTransactionId] = useState("");
  // Remitly location (only for remitly)
  const [remitlyCountry, setRemitlyCountry] = useState<"Angola" | "Portugal">("Angola");

  // Step 3
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Preencher nome do titular automaticamente quando o modal abre
  useEffect(() => {
    if (isOpen && defaultPayerName) {
      setPayerName(defaultPayerName);
    }
  }, [isOpen, defaultPayerName]);

  // Preço e duração vêm das definições do servidor (que também as força no pagamento)
  const [basePriceKz, setBasePriceKz] = useState(4900);
  const [months, setMonths] = useState(6);
  useEffect(() => {
    if (!isOpen) return;
    (async () => {
      try {
        const { data } = await supabase
          .from("economy_settings")
          .select("key, value")
          .in("key", ["subscription_price_aoa", "subscription_months"]);
        (data || []).forEach((r: any) => {
          if (r.key === "subscription_price_aoa" && Number(r.value) > 0) setBasePriceKz(Number(r.value));
          if (r.key === "subscription_months" && Number(r.value) > 0) setMonths(Number(r.value));
        });
      } catch {
        /* mantém os valores por defeito */
      }
    })();
  }, [isOpen]);
  const monthlyKz = Math.round(basePriceKz / months);
  const expiresLabel = expiresAt ? new Date(expiresAt).toLocaleDateString("pt-PT") : null;

  const calculateConvertedPrice = () => {
    const priceUsd = basePriceKz / 950;
    return priceUsd * exchangeRates[currency];
  };

  const formatPrice = () => {
    const val = calculateConvertedPrice();
    const symbols = { AOA: "Kz", USD: "$", EUR: "€", BRL: "R$" };
    const formatter = new Intl.NumberFormat("pt-PT", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    if (currency === "AOA") return `${formatter.format(val)} Kz`;
    return `${symbols[currency]} ${formatter.format(val)}`;
  };

  /** Para Unitel/Express mostra sempre Kz; para Remitly usa a moeda do utilizador */
  const displayAmount = () => {
    if (selectedMethod === "remitly") return formatPrice();
    const formatter = new Intl.NumberFormat("pt-PT", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
    return `${formatter.format(basePriceKz)} Kz`;
  };

  const copyNumber = async () => {
    try {
      await navigator.clipboard.writeText(PAYMENT_NUMBER.replace(/\s/g, ""));
      toast.success("Número copiado");
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error("Formato inválido. Use PDF, JPG, JPEG, PNG ou WEBP.");
      e.target.value = "";
      return;
    }
    const sizeCheck = checkProofFile(file);
    if (!sizeCheck.ok) {
      toast.error(sizeCheck.error);
      e.target.value = "";
      return;
    }

    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setProofFile(file);
    if (file.type.startsWith("image/")) {
      setPreviewUrl(URL.createObjectURL(file));
    } else {
      setPreviewUrl(null);
    }
  };

  const clearProof = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setProofFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const canGoStep2 = selectedMethod !== null;

  const canGoStep3 = () => {
    if (!payerName.trim() || !transactionId.trim()) return false;
    return true;
  };

  const handleSubmit = async () => {
    if (!userId) {
      toast.error("Sessão inválida. Por favor, volte a autenticar-se.");
      return;
    }
    if (!selectedMethod) {
      toast.error("Selecione uma carteira.");
      return;
    }
    if (!proofFile) {
      toast.error("Por favor, anexe o comprovativo de pagamento.");
      return;
    }
    if (!payerName.trim() || !transactionId.trim()) {
      toast.error("Preencha o nome do titular e o ID da transação.");
      return;
    }

    setSubmitting(true);
    try {
      const prepared = await prepareProof(proofFile);
      const filePath = proofPath(`${userId}`, prepared.ext);

      const { error: uploadError } = await supabase.storage
        .from("subscription-proofs")
        .upload(filePath, prepared.file, { upsert: false, contentType: prepared.file.type });

      if (uploadError) {
        throw new Error(`Falha no upload do comprovativo: ${uploadError.message}`);
      }

      // Método começa por EXPRESS|UNITEL|REMITLY (servidor normaliza + força amount=4900)
      const cleanMethod =
        selectedMethod === "express" ? "EXPRESS" : selectedMethod === "unitel" ? "UNITEL" : "REMITLY";
      const city = remitlyCountry === "Portugal" ? "Lisboa" : "Luanda";
      const methodDetails =
        selectedMethod === "remitly"
          ? `${cleanMethod} | Beneficiario: Adxmoney | Pais: ${remitlyCountry} | Local: ${city} | Titular: ${payerName.trim()} | ID: ${transactionId.trim().slice(0, 64)}`
          : `${cleanMethod} | Titular: ${payerName.trim()} | ID: ${transactionId.trim().slice(0, 64)} | Nr: ${PAYMENT_NUMBER}`;

      const { error: rpcError } = await supabase.rpc("submit_subscription_payment", {
        p_amount: basePriceKz,
        p_currency: currency,
        p_method: methodDetails,
        p_proof_url: filePath,
      });

      if (rpcError) throw rpcError;

      toast.success(
        "Comprovativo de assinatura enviado com sucesso! O administrador ativará a sua conta em breve."
      );
      resetForm();
      onClose();
      if (onSuccess) onSuccess();
    } catch (err: any) {
      console.error("Erro ao submeter pagamento de assinatura:", err);
      toast.error(err.message || "Erro ao processar assinatura.");
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setStep(1);
    setSelectedMethod(null);
    setPayerName("");
    setTransactionId("");
    setRemitlyCountry("Angola");
    clearProof();
  };

  const handleClose = () => {
    if (!submitting) {
      resetForm();
      onClose();
    }
  };

  const Progress = () => (
    <div className="flex items-center justify-between gap-1 mb-1">
      {[
        { n: 1, label: "Carteira" },
        { n: 2, label: "Transferência" },
        { n: 3, label: "Comprovativo" },
      ].map((s, i) => (
        <React.Fragment key={s.n}>
          <div className="flex flex-col items-center gap-1 min-w-0 flex-1">
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-semibold border-2 transition-colors ${
                step === s.n
                  ? "bg-[#0f766e] border-[#0f766e] text-white"
                  : step > s.n
                  ? "bg-emerald-100 border-emerald-300 text-emerald-700"
                  : "bg-white border-slate-200 text-slate-400"
              }`}
            >
              {step > s.n ? <CheckCircle2 className="w-3.5 h-3.5" /> : s.n}
            </div>
            <span
              className={`text-[11px] font-medium truncate ${
                step === s.n ? "text-[#0f766e]" : "text-slate-400"
              }`}
            >
              {s.label}
            </span>
          </div>
          {i < 2 && (
            <div
              className={`h-0.5 flex-1 max-w-[40px] rounded-full mt-[-12px] ${
                step > s.n ? "bg-emerald-300" : "bg-slate-200"
              }`}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) handleClose(); }}>
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-2xl p-0 shadow-md max-h-[92vh] overflow-hidden flex flex-col">
        <DialogHeader className="px-5 pt-5 pb-3 text-left border-b border-slate-100 space-y-3">
          <div className="flex items-center justify-between">
            <Badge className="bg-emerald-50 text-emerald-700 border-none text-[11px] font-semibold px-2.5 py-0.5 rounded-lg">
              {renewal ? "Renovação" : `Plano de ${months} meses`}
            </Badge>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Pagamento seguro
            </div>
          </div>
          <div>
            <DialogTitle className="text-[17px] font-semibold text-slate-900">
              {renewal ? "Renovar assinatura" : `Ativar acesso de ${months} meses`}
            </DialogTitle>
            <DialogDescription className="text-[12px] text-slate-500 mt-0.5">
              {renewal && expiresLabel
                ? `Soma ${months} meses ao que ainda tem (válida até ${expiresLabel}).`
                : `${new Intl.NumberFormat("pt-PT").format(basePriceKz)} Kz por ${months} meses (≈ ${new Intl.NumberFormat("pt-PT").format(monthlyKz)} Kz/mês). Desbloqueia tarefas, campanhas e afiliados.`}
            </DialogDescription>
          </div>
          <Progress />
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* ========== ETAPA 1 — Carteira ========== */}
          {step === 1 && (
            <div className="space-y-3">
              <p className="text-[13px] font-medium text-slate-700">
                Selecione a carteira de pagamento
              </p>
              <div className="space-y-2.5">
                {WALLETS.map((w) => {
                  const selected = selectedMethod === w.id;
                  return (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => setSelectedMethod(w.id)}
                      className={`w-full flex items-center gap-3 p-3.5 rounded-xl border-2 text-left transition-all ${
                        selected
                          ? "border-[#0f766e] bg-teal-50/50 shadow-sm"
                          : "border-slate-150 border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 shrink-0 border border-slate-100">
                        <img
                          src={w.icon}
                          alt={w.label}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = "none";
                          }}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-semibold text-slate-900">
                          {w.label}
                        </p>
                        <p className="text-[12px] text-slate-500 mt-0.5">
                          {w.description}
                        </p>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                          selected
                            ? "border-[#0f766e] bg-[#0f766e]"
                            : "border-slate-300"
                        }`}
                      >
                        {selected && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* ========== ETAPA 2 — Transferência ========== */}
          {step === 2 && selectedMethod && (
            <div className="space-y-4">
              {/* Valor */}
              <div className="rounded-xl bg-emerald-50 border border-emerald-100 p-4 text-center">
                <p className="text-[11px] font-medium text-emerald-700 tracking-wide">
                  Valor a transferir
                </p>
                <p className="text-[22px] font-bold text-emerald-900 mt-1 tabular-nums">
                  {displayAmount()}
                </p>
                <p className="text-[11px] text-emerald-600/80 mt-0.5">
                  {selectedMethod === "remitly"
                    ? "Valor convertido na moeda selecionada"
                    : "Valor oficial em Kwanzas (Kz)"}
                </p>
              </div>

              {/* Dados da carteira */}
              {(selectedMethod === "unitel" || selectedMethod === "express") && (
                <div className="rounded-xl border border-slate-200 p-4 space-y-2">
                  <p className="text-[12px] font-semibold text-slate-800">
                    {selectedMethod === "unitel"
                      ? "Unitel Money"
                      : "Multicaixa Express"}
                  </p>
                  <div className="flex items-center justify-between gap-2 bg-slate-50 rounded-lg px-3 py-2.5">
                    <div>
                      <p className="text-[11px] text-slate-500 ">Número</p>
                      <p className="text-[15px] font-mono font-semibold text-slate-900 tracking-wide">
                        {PAYMENT_NUMBER}
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={copyNumber}
                      className="h-11 rounded-lg text-[11px] gap-1.5"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copiar
                    </Button>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Transfira o valor exato e guarde o comprovativo.
                  </p>
                </div>
              )}

              {selectedMethod === "remitly" && (
                <div className="rounded-xl border border-slate-200 p-4 space-y-3">
                  <p className="text-[12px] font-semibold text-slate-800">
                    Remitly — Transferência bancária
                  </p>
                  <div className="grid grid-cols-1 gap-2 text-[13px]">
                    <div className="flex justify-between gap-2">
                      <span className="text-slate-500">Beneficiário</span>
                      <span className="font-semibold text-slate-900">
                        Adxmoney inc
                      </span>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[11px] text-slate-500">País</Label>
                      <select
                        value={remitlyCountry}
                        onChange={(e) =>
                          setRemitlyCountry(e.target.value as "Angola" | "Portugal")
                        }
                        className="w-full h-10 rounded-lg border border-slate-200 bg-white px-3 text-[13px] font-medium text-slate-800"
                      >
                        <option value="Angola">Angola</option>
                        <option value="Portugal">Portugal</option>
                      </select>
                    </div>
                    <div className="flex justify-between gap-2">
                      <span className="text-slate-500">Localidade</span>
                      <span className="font-semibold text-slate-900">
                        {remitlyCountry === "Portugal" ? "Lisboa" : "Luanda"}
                      </span>
                    </div>
                    <div className="flex justify-between gap-2">
                      <span className="text-slate-500">Método</span>
                      <span className="font-semibold text-slate-900">
                        Transferência bancária
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Campos comuns */}
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label className="text-[12px] font-medium text-slate-700">
                    Nome do titular do pagamento *
                  </Label>
                  <Input
                    value={payerName}
                    onChange={(e) => setPayerName(e.target.value.slice(0, 120))}
                    placeholder="Nome completo de quem pagou"
                    className="h-11 rounded-xl text-[13px]"
                    maxLength={120}
                    readOnly={!!defaultPayerName}
                  />
                  {defaultPayerName && (
                    <p className="text-[11px] text-slate-400">Preenchido a partir do seu perfil</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[12px] font-medium text-slate-700">
                    ID da transação *
                  </Label>
                  <Input
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    placeholder="Código / referência da transferência"
                    className="h-11 rounded-xl text-[13px] font-mono"
                    maxLength={80}
                  />
                </div>
              </div>
            </div>
          )}

          {/* ========== ETAPA 3 — Comprovativo ========== */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <p className="text-[14px] font-semibold text-slate-900">
                  Comprovativo de pagamento
                </p>
                <p className="text-[12px] text-slate-500 mt-0.5">
                  PDF, JPG, JPEG, PNG ou WEBP · imagens comprimidas automaticamente
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp,application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />

              {!proofFile ? (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full border-2 border-dashed border-slate-200 rounded-xl p-8 text-center hover:border-[#0f766e] hover:bg-teal-50/30 transition-colors"
                >
                  <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-[13px] font-semibold text-slate-700">
                    Selecionar comprovativo
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Toque para escolher o ficheiro
                  </p>
                </button>
              ) : (
                <div className="rounded-xl border border-slate-200 overflow-hidden">
                  {previewUrl ? (
                    <div className="bg-slate-50 p-2">
                      <img
                        src={previewUrl}
                        alt="Pré-visualização"
                        className="w-full max-h-48 object-contain rounded-lg"
                      />
                    </div>
                  ) : (
                    <div className="bg-slate-50 p-6 flex flex-col items-center gap-2">
                      <FileText className="w-10 h-10 text-slate-400" />
                      <p className="text-[12px] font-medium text-slate-600">
                        Documento PDF
                      </p>
                    </div>
                  )}
                  <div className="px-3 py-2.5 flex items-center justify-between gap-2 border-t border-slate-100">
                    <div className="flex items-center gap-2 min-w-0">
                      {proofFile.type.startsWith("image/") ? (
                        <ImageIcon className="w-4 h-4 text-slate-400 shrink-0" />
                      ) : (
                        <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <span className="text-[12px] text-slate-700 truncate">
                        {proofFile.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-11 text-[11px]"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        Substituir
                      </Button>
                      <button
                        type="button"
                        onClick={clearProof}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Resumo */}
              <div className="rounded-xl bg-slate-50 border border-slate-100 p-3 space-y-1.5 text-[12px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Método</span>
                  <span className="font-medium text-slate-800">
                    {WALLETS.find((w) => w.id === selectedMethod)?.label}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Valor</span>
                  <span className="font-medium text-slate-800">{displayAmount()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Titular</span>
                  <span className="font-medium text-slate-800 truncate max-w-[60%]">
                    {payerName || "—"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">ID transação</span>
                  <span className="font-mono font-medium text-slate-800 truncate max-w-[60%]">
                    {transactionId || "—"}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer buttons */}
        <div className="px-5 py-3.5 border-t border-slate-100 flex gap-2">
          {step === 1 && (
            <>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                className="h-11 rounded-xl text-[13px] flex-1"
              >
                Cancelar
              </Button>
              <Button
                type="button"
                disabled={!canGoStep2}
                onClick={() => setStep(2)}
                className="h-11 rounded-xl text-[13px] flex-1 bg-[#0f766e] hover:bg-[#0d9488] text-white gap-1.5"
              >
                Continuar
                <ArrowRight className="w-4 h-4" />
              </Button>
            </>
          )}

          {step === 2 && (
            <>
              <Button
                type="button"
                variant="outline"
                onClick={() => setStep(1)}
                className="h-11 rounded-xl text-[13px] gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                Voltar
              </Button>
              <Button
                type="button"
                disabled={!canGoStep3()}
                onClick={() => setStep(3)}
                className="h-11 rounded-xl text-[13px] flex-1 bg-[#0f766e] hover:bg-[#0d9488] text-white gap-1.5"
              >
                Continuar
                <ArrowRight className="w-4 h-4" />
              </Button>
            </>
          )}

          {step === 3 && (
            <>
              <Button
                type="button"
                variant="outline"
                disabled={submitting}
                onClick={() => setStep(2)}
                className="h-11 rounded-xl text-[13px] gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                Voltar
              </Button>
              <Button
                type="button"
                disabled={submitting || !proofFile}
                onClick={handleSubmit}
                className="h-11 rounded-xl text-[13px] flex-1 bg-[#0f766e] hover:bg-[#0d9488] text-white"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    A processar...
                  </>
                ) : (
                  "Finalizar pagamento"
                )}
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
