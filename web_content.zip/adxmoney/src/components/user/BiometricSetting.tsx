import React, { useEffect, useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { Switch } from "@/components/ui/switch";
import {
  authenticateBiometric,
  isBiometricAvailable,
  isBiometricEnabled,
  setBiometricEnabled,
} from "@/lib/biometric";
import { hapticError, hapticSelect } from "@/lib/haptics";

/** Toggle "Proteger app com biometria". Só aparece em app nativa com biometria disponível. */
export const BiometricSetting: React.FC = () => {
  const { user } = useAuth();
  const [available, setAvailable] = useState(false);
  const [on, setOn] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    isBiometricAvailable().then((ok) => alive && setAvailable(ok));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    setOn(isBiometricEnabled(user?.id));
  }, [user?.id]);

  if (!available || !user) return null;

  const toggle = async (next: boolean) => {
    if (busy) return;
    setBusy(true);
    try {
      if (next) {
        // Só liga depois de confirmar que a biometria funciona
        const r = await authenticateBiometric("Ativar proteção da app");
        if (r !== "ok") {
          if (r !== "cancelled") {
            hapticError();
            toast.error("Não foi possível ativar a biometria.");
          }
          return;
        }
      }
      setBiometricEnabled(user.id, next);
      setOn(next);
      hapticSelect();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center justify-between gap-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
      <div className="min-w-0">
        <p className="text-[13px] font-semibold text-slate-800">Proteger app com biometria</p>
        <p className="text-[11px] text-slate-400">Pede a impressão digital / rosto ao reabrir a app.</p>
      </div>
      <Switch checked={on} disabled={busy} onCheckedChange={toggle} aria-label="Proteger app com biometria" />
    </div>
  );
};

export default BiometricSetting;
