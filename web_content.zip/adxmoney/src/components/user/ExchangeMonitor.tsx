import React from "react";
import { Users, UserPlus, Activity, ChevronRight, Clock, ShieldCheck } from "@/components/icons";
import { Skeleton } from "@/components/ui/skeleton";
import { useExchangeStats } from "@/hooks/useExchangeStats";

interface ExchangeMonitorProps {
  userId?: string | null;
  isSubscriber: boolean;
  /** Muda quando a Home atualiza os dados (recarrega os números). */
  refreshKey?: number | null;
  onOpenTasks: () => void;
  onOpenSubscribe?: () => void;
}

const nf = (n: number) => n.toLocaleString("pt-PT");

/**
 * Home · Comunidade: seguidores, contas a seguir e monitor das execuções.
 * Visual alinhado com os restantes cartões da Home (rounded-2xl, borda slate-200/80, texto 11–14px).
 */
export const ExchangeMonitor: React.FC<ExchangeMonitorProps> = ({
  userId,
  isSubscriber,
  refreshKey,
  onOpenTasks,
  onOpenSubscribe,
}) => {
  const { stats, loading } = useExchangeStats(userId, refreshKey);
  const { proofs, week } = stats;

  const decided = proofs.approved + proofs.rejected;
  const approvalRate = decided > 0 ? Math.round((proofs.approved / decided) * 100) : null;
  const weekTotal = week.reduce((a, d) => a + d.count, 0);
  const weekMax = Math.max(1, ...week.map((d) => d.count));
  const pct = (n: number) => (proofs.total > 0 ? (n / proofs.total) * 100 : 0);

  if (loading) {
    return (
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-sm p-4 space-y-3">
        <Skeleton className="h-5 w-40 rounded-md" />
        <div className="grid grid-cols-2 gap-2.5">
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
        </div>
        <Skeleton className="h-28 w-full rounded-xl" />
      </div>
    );
  }

  return (
    <section className="rounded-2xl bg-white border border-slate-200/80 shadow-sm overflow-hidden">
      {/* Cabeçalho */}
      <div className="flex items-center justify-between gap-3 px-4 pt-4">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <Users className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <p className="text-[14px] font-semibold text-slate-900 leading-tight">Comunidade</p>
            <p className="text-[11px] text-slate-400 leading-tight mt-0.5">Troca de seguidores</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onOpenTasks}
          className="text-[12px] font-semibold text-teal-700 min-h-[44px] px-1 flex items-center gap-0.5 shrink-0"
        >
          Ver tarefas
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Seguidores · A seguir */}
      <div className="grid grid-cols-2 gap-2.5 px-4 pt-1">
        <div className="rounded-xl p-3.5 bg-gradient-to-br from-teal-50 to-emerald-50/60 ring-1 ring-teal-100">
          <div className="flex items-center gap-1.5 text-teal-700">
            <UserPlus className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium text-slate-500">Seguidores</span>
          </div>
          <p className="mt-1.5 text-[26px] leading-none font-bold text-slate-900 tabular-nums tracking-tight">
            {nf(stats.followers)}
          </p>
          <p className={`mt-1.5 text-[11px] ${stats.followersWeek > 0 ? "text-emerald-600 font-medium" : "text-slate-400"}`}>
            {stats.followersWeek > 0 ? `+${nf(stats.followersWeek)} nos últimos 7 dias` : "Sem novos esta semana"}
          </p>
        </div>

        <div className="rounded-xl p-3.5 bg-gradient-to-br from-sky-50 to-indigo-50/60 ring-1 ring-sky-100">
          <div className="flex items-center gap-1.5 text-sky-700">
            <Users className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium text-slate-500">A seguir</span>
          </div>
          <p className="mt-1.5 text-[26px] leading-none font-bold text-slate-900 tabular-nums tracking-tight">
            {nf(stats.toFollow)}
          </p>
          <p className="mt-1.5 text-[11px] text-slate-400">
            {proofs.approved > 0 ? `${nf(proofs.approved)} concluídas` : "Contas por seguir"}
          </p>
        </div>
      </div>

      {/* Monitor de execuções */}
      <div className="px-4 pt-4 pb-4">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-slate-700">
            <Activity className="w-3.5 h-3.5 text-teal-700" />
            <p className="text-[13px] font-semibold text-slate-900">Monitor de execuções</p>
          </div>
          {approvalRate !== null && (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100">
              {approvalRate}% aprovação
            </span>
          )}
        </div>

        {/* Barra segmentada */}
        <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden flex" aria-hidden="true">
          <div className="h-full bg-emerald-500 transition-[width] duration-700" style={{ width: `${pct(proofs.approved)}%` }} />
          <div className="h-full bg-amber-400 transition-[width] duration-700" style={{ width: `${pct(proofs.review)}%` }} />
          <div className="h-full bg-rose-400 transition-[width] duration-700" style={{ width: `${pct(proofs.rejected)}%` }} />
        </div>

        <div className="grid grid-cols-3 gap-2 mt-3">
          {[
            { label: "Aprovadas", value: proofs.approved, dot: "bg-emerald-500" },
            { label: "Em análise", value: proofs.review, dot: "bg-amber-400" },
            { label: "Rejeitadas", value: proofs.rejected, dot: "bg-rose-400" },
          ].map((s) => (
            <div key={s.label} className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                <span className="text-[11px] text-slate-500 truncate">{s.label}</span>
              </div>
              <p className="text-[16px] font-bold text-slate-900 tabular-nums leading-tight mt-0.5">{nf(s.value)}</p>
            </div>
          ))}
        </div>

        {/* Últimos 7 dias */}
        <div className="mt-4 pt-3.5 border-t border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <p className="text-[11px] font-medium text-slate-500">Últimos 7 dias</p>
            <p className="text-[11px] text-slate-400 tabular-nums">
              {weekTotal === 0 ? "Sem execuções" : `${nf(weekTotal)} ${weekTotal === 1 ? "execução" : "execuções"}`}
            </p>
          </div>
          <div className="flex items-end gap-1.5 h-12" role="img" aria-label="Execuções por dia nos últimos 7 dias">
            {week.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center justify-end h-full gap-1">
                <div
                  className={`w-full rounded-md transition-[height] duration-700 ${
                    d.count === 0 ? "bg-slate-100" : d.today ? "bg-teal-600" : "bg-teal-300"
                  }`}
                  style={{ height: `${d.count === 0 ? 10 : Math.max(18, (d.count / weekMax) * 100)}%` }}
                />
              </div>
            ))}
          </div>
          <div className="flex gap-1.5 mt-1">
            {week.map((d, i) => (
              <span key={i} className={`flex-1 text-center text-[10px] ${d.today ? "font-semibold text-slate-700" : "text-slate-400"}`}>
                {d.label}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Avisos contextuais (só o que importa) */}
      {!isSubscriber ? (
        <button
          type="button"
          onClick={() => onOpenSubscribe?.()}
          className="w-full flex items-center gap-2.5 px-4 py-3 bg-slate-900 text-white text-left pressable"
        >
          <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" />
          <span className="text-[12px] flex-1 leading-snug">Ative a conta para participar na troca de seguidores.</span>
          <ChevronRight className="w-3.5 h-3.5 text-white/70" />
        </button>
      ) : stats.toReview > 0 ? (
        <button
          type="button"
          onClick={onOpenTasks}
          className="w-full flex items-center gap-2.5 px-4 py-3 bg-amber-50 border-t border-amber-200/70 text-amber-950 text-left pressable"
        >
          <Clock className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="text-[12px] font-medium flex-1 leading-snug">
            {stats.toReview === 1
              ? "1 prova à espera da sua validação"
              : `${nf(stats.toReview)} provas à espera da sua validação`}
          </span>
          <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
        </button>
      ) : !stats.hasOwnLink ? (
        <div className="px-4 py-3 bg-slate-50 border-t border-slate-100">
          <p className="text-[12px] text-slate-500 leading-snug">
            Adicione o link da sua conta no Perfil para que outros membros o sigam e para receber contas na troca.
          </p>
        </div>
      ) : null}
    </section>
  );
};

export default ExchangeMonitor;
