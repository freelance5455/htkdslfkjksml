import React, { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Check, X, Eye, Loader2, ShieldCheck, Clock } from "@/components/icons";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { purgeProofsSoon } from "@/lib/purge";
import { hapticError, hapticSuccess } from "@/lib/haptics";

interface ProofRow {
  id: string;
  user_id: string;
  handle: string;
  proof_path: string;
  status: string;
  reward_amount: number;
  escalated: boolean;
  created_at: string;
  due_at: string;
  community_tasks: { description: string | null; platform: string | null; profile_url: string | null } | null;
}

interface Props {
  /** "creator": provas das tarefas que eu criei · "admin": todas as provas pendentes */
  mode: "creator" | "admin";
  userId?: string;
  /** false quando o separador está escondido; ao voltar a true, recarrega */
  active?: boolean;
}

/** Lista de provas a validar. Não renderiza nada se não houver pendentes (modo creator). */
export const ProofReviewList: React.FC<Props> = ({ mode, userId, active = true }) => {
  const [rows, setRows] = useState<ProofRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ url: string; row: ProofRow } | null>(null);
  const [rejecting, setRejecting] = useState<ProofRow | null>(null);
  const [note, setNote] = useState("");
  const [runningAuto, setRunningAuto] = useState(false);

  const load = useCallback(async () => {
    try {
      let q = supabase
        .from("task_proofs")
        .select(
          "id, user_id, handle, proof_path, status, reward_amount, escalated, created_at, due_at, community_tasks(description, platform, profile_url)"
        )
        .eq("status", "SUBMITTED")
        .order("created_at", { ascending: true })
        .limit(100);
      if (mode === "creator" && userId) q = q.neq("user_id", userId);
      const { data, error } = await q;
      if (error) throw error;
      setRows((data as unknown as ProofRow[]) || []);
    } catch (err) {
      console.warn("Provas pendentes indisponíveis:", err);
      if (mode === "admin") toast.error(`Não foi possível carregar as provas: ${(err as any)?.message || "erro desconhecido"}`);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [mode, userId]);

  useEffect(() => {
    if (active) load();
  }, [load, active]);

  const openPreview = async (row: ProofRow) => {
    const { data, error } = await supabase.storage.from("subscription-proofs").createSignedUrl(row.proof_path, 300);
    if (error || !data?.signedUrl) {
      toast.error("Não foi possível abrir a captura.");
      return;
    }
    setPreview({ url: data.signedUrl, row });
  };

  const review = async (row: ProofRow, approve: boolean, reason?: string) => {
    setBusyId(row.id);
    try {
      const { error } = await supabase.rpc("review_task_proof", {
        p_proof_id: row.id,
        p_approve: approve,
        p_note: reason ?? null,
      });
      if (error) throw error;
      hapticSuccess();
      toast.success(approve ? "Prova aprovada." : "Prova rejeitada.");
      setPreview(null);
      setRejecting(null);
      setNote("");
      purgeProofsSoon();
      await load();
    } catch (err: any) {
      hapticError();
      toast.error(err?.message || "Erro ao avaliar a prova.");
    } finally {
      setBusyId(null);
    }
  };

  const runAuto = async () => {
    setRunningAuto(true);
    try {
      const { data, error } = await supabase.rpc("admin_run_auto_approve");
      if (error) throw error;
      toast.success(`${data ?? 0} prova(s) vencida(s) aprovada(s) automaticamente.`);
      purgeProofsSoon();
      await load();
    } catch (err: any) {
      toast.error(err?.message || "Erro ao processar vencidas.");
    } finally {
      setRunningAuto(false);
    }
  };

  if (loading) return null;
  if (mode === "creator" && rows.length === 0) return null;

  const fmt = (iso: string) =>
    new Date(iso).toLocaleString("pt-PT", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

  return (
    <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span className="text-[11px] font-semibold text-slate-500 ">
            {mode === "admin" ? "Provas a validar (todas)" : "Provas das suas tarefas"} · {rows.length}
          </span>
        </div>
        {mode === "admin" && (
          <Button
            variant="outline"
            onClick={runAuto}
            disabled={runningAuto}
            className="h-11 rounded-xl text-[11px] font-semibold "
          >
            {runningAuto ? <Loader2 className="w-3 h-3 animate-spin" /> : "Processar vencidas"}
          </Button>
        )}
      </div>

      {rows.length === 0 ? (
        <p className="text-xs text-slate-400">Sem provas pendentes.</p>
      ) : (
        <div className="space-y-3">
          {rows.map((r) => (
            <div key={r.id} className="border border-slate-200/80 rounded-2xl p-4 space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 truncate">
                    @{r.handle} · {r.community_tasks?.platform}
                  </p>
                  <p className="text-[11px] text-slate-500 line-clamp-2">{r.community_tasks?.description}</p>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  {r.escalated && (
                    <Badge className="bg-amber-50 text-amber-700 border-none text-[11px] font-semibold ">Escalada</Badge>
                  )}
                  <span className="flex items-center gap-1 text-[11px] text-slate-400">
                    <Clock className="w-3 h-3" /> {fmt(r.created_at)}
                  </span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => openPreview(r)}
                  className="flex-1 h-10 rounded-xl text-[11px] font-semibold "
                >
                  <Eye className="w-3.5 h-3.5 mr-1.5" /> Ver captura
                </Button>
                <Button
                  onClick={() => review(r, true)}
                  disabled={busyId === r.id}
                  className="h-10 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white"
                  aria-label="Aprovar"
                >
                  {busyId === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                </Button>
                <Button
                  onClick={() => setRejecting(r)}
                  disabled={busyId === r.id}
                  className="h-10 px-4 rounded-xl bg-red-500 hover:bg-red-600 text-white"
                  aria-label="Rejeitar"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="bg-white border-none sm:rounded-2xl p-4 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm font-bold">@{preview?.row.handle}</DialogTitle>
          </DialogHeader>
          {preview && (
            /\.pdf($|\?)/i.test(preview.row.proof_path) ? (
              <a href={preview.url} target="_blank" rel="noreferrer" className="text-emerald-600 font-bold text-sm underline">
                Abrir PDF
              </a>
            ) : (
              <img src={preview.url} alt="Captura de ecrã" className="w-full max-h-[60vh] object-contain rounded-xl bg-slate-50" />
            )
          )}
          <DialogFooter className="flex gap-2">
            <Button
              onClick={() => preview && review(preview.row, true)}
              disabled={!preview || busyId === preview.row.id}
              className="flex-1 h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] "
            >
              Aprovar
            </Button>
            <Button
              onClick={() => {
                if (preview) setRejecting(preview.row);
                setPreview(null);
              }}
              className="flex-1 h-11 rounded-xl bg-red-500 hover:bg-red-600 text-white font-semibold text-[11px] "
            >
              Rejeitar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!rejecting} onOpenChange={(o) => !o && setRejecting(null)}>
        <DialogContent className="bg-white border-none sm:rounded-2xl p-6">
          <DialogHeader>
            <DialogTitle className="text-base font-bold">Motivo da rejeição</DialogTitle>
          </DialogHeader>
          <Textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Ex.: a captura não mostra que seguiu a página."
            className="bg-slate-50 border-transparent rounded-2xl min-h-[100px]"
          />
          <DialogFooter className="flex gap-2">
            <Button variant="ghost" onClick={() => setRejecting(null)} className="flex-1 h-11 rounded-xl text-[11px] font-semibold ">
              Cancelar
            </Button>
            <Button
              disabled={note.trim().length < 3 || !rejecting || busyId === rejecting.id}
              onClick={() => rejecting && review(rejecting, false, note.trim())}
              className="flex-1 h-11 rounded-xl bg-red-500 hover:bg-red-600 text-white text-[11px] font-semibold "
            >
              Rejeitar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProofReviewList;
