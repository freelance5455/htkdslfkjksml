import React, { useMemo, useState } from "react";
import { WalletFlowChart } from "@/components/user/WalletFlowChart";
import { useWalletFlow } from "@/hooks/useWalletFlow";
import { TrendingUp, TrendingDown, ArrowDownLeft, ArrowUpRight, ChevronRight, RefreshCw, Eye, EyeOff } from "@/components/icons";
import { IconWallet, IconTasks, IconCampaigns, IconInvite, IconStore, IconHelp, IconDeposit, IconWithdraw, IconProof } from "@/components/icons";
import { Skeleton } from "@/components/ui/skeleton";
import { ExchangeMonitor } from "@/components/user/ExchangeMonitor";

export type HomeTabTarget =
  | "tasks"
  | "campaigns"
  | "affiliate"
  | "wallet"
  | "engagement";

type PeriodDays = 7 | 30 | 90;

interface Tx {
  id?: string;
  amount: number;
  type?: string;
  description?: string;
  created_at: string;
  status?: string;
}

interface HomeDashboardProps {
  userName?: string | null;
  /** Id do utilizador (números da troca de seguidores / execuções) */
  userId?: string | null;
  isSubscriber: boolean;
  balance: number;
  reservedBalance: number;
  transactions: Tx[];
  campaigns: any[];
  affiliate: any | null;
  formatCurrency: (amountKz: number) => string;
  onNavigate: (tab: HomeTabTarget) => void;
  onOpenSubscribe?: () => void;
  onOpenDeposit?: () => void;
  /** Timestamp da última sincronização de dados (ms) */
  dataUpdatedAt?: number | null;
  /** Mostra skeletons (ex.: refresh em curso) */
  isRefreshing?: boolean;
  onRefresh?: () => void;
  /** Ocultar valores de saldo (espelho do header) */
  hideBalance?: boolean;
  onToggleHideBalance?: () => void;
}

function pctChange(current: number, previous: number): number | null {
  if (previous === 0) {
    if (current === 0) return 0;
    return null; // sem base comparável
  }
  return ((current - previous) / Math.abs(previous)) * 100;
}

function formatUpdatedAt(ts?: number | null) {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleString("pt-PT", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function HomeSkeleton() {
  return (
    <div className="space-y-5 pb-2">
      <div className="space-y-2">
        <Skeleton className="h-6 w-36 rounded-md" />
        <Skeleton className="h-4 w-48 rounded-md" />
      </div>
      <Skeleton className="h-44 w-full rounded-2xl" />
      <Skeleton className="h-16 w-full rounded-xl" />
      <div className="grid grid-cols-3 gap-2.5">
        <Skeleton className="h-16 rounded-xl" />
        <Skeleton className="h-16 rounded-xl" />
        <Skeleton className="h-16 rounded-xl" />
      </div>
      <Skeleton className="h-[200px] w-full rounded-2xl" />
      <div className="grid grid-cols-2 gap-2.5">
        <Skeleton className="h-28 rounded-xl" />
        <Skeleton className="h-28 rounded-xl" />
        <Skeleton className="h-28 rounded-xl" />
        <Skeleton className="h-28 rounded-xl" />
      </div>
    </div>
  );
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  userName,
  userId,
  isSubscriber,
  balance,
  reservedBalance,
  transactions,
  campaigns,
  affiliate,
  formatCurrency,
  onNavigate,
  onOpenSubscribe,
  onOpenDeposit,
  dataUpdatedAt,
  isRefreshing,
  onRefresh,
  hideBalance = false,
  onToggleHideBalance,
}) => {
  const [period, setPeriod] = useState<PeriodDays>(30);
  const firstName = (userName || "Operador").split(" ")[0];

  const flow = useWalletFlow(period, transactions);

  const analytics = useMemo(() => {
    const cur = flow.days.slice(-period);
    const prev = flow.days.slice(0, Math.max(0, flow.days.length - period));
    const sum = (arr: typeof cur) =>
      arr.reduce((acc, d) => ({ entradas: acc.entradas + d.entradas, saidas: acc.saidas + d.saidas }), {
        entradas: 0,
        saidas: 0,
      });
    const c = sum(cur);
    const p = sum(prev);

    const recent = [...(transactions || [])]
      .sort((x, y) => +new Date(y.created_at) - +new Date(x.created_at))
      .slice(0, 5);

    return {
      totalIn: c.entradas,
      totalOut: c.saidas,
      net: c.entradas - c.saidas,
      inDelta: pctChange(c.entradas, p.entradas),
      outDelta: pctChange(c.saidas, p.saidas),
      netDelta: pctChange(c.entradas - c.saidas, p.entradas - p.saidas),
      recentMoves: recent,
      periodLabel: period === 7 ? "7 dias" : period === 30 ? "30 dias" : "90 dias",
    };
  }, [flow.days, period, transactions]);

  const activeCampaignsList = (campaigns || []).filter(
    (c) =>
      c.assignment_status === "ASSIGNED" ||
      c.assignment_status === "IN_PROGRESS" ||
      c.status === "ACTIVE"
  );
  const activeCampaigns = activeCampaignsList.length;
  const doneCampaigns = (campaigns || []).filter(
    (c) => c.assignment_status === "COMPLETED" || c.status === "COMPLETED"
  ).length;
  const referrals = Number(affiliate?.total_referrals ?? 0);
  const affiliateEarned = Number(affiliate?.total_earned ?? 0);

  // Próxima ação recomendada (uma só, por prioridade)
  const nextAction = useMemo(() => {
    if (!isSubscriber) {
      return {
        title: "Ativar conta completa",
        desc: "Desbloqueie tarefas, campanhas e ganhos de afiliado",
        cta: "Ativar agora",
        onClick: () => onOpenSubscribe?.(),
        icon: IconHelp,
        tone: "dark" as const,
      };
    }
    if (reservedBalance > 0) {
      return {
        title: "Saque em processamento",
        desc: `${formatCurrency(reservedBalance)} reservado — acompanhe na conta`,
        cta: "Ver conta",
        onClick: () => onNavigate("wallet"),
        icon: IconWallet,
        tone: "amber" as const,
      };
    }
    if (activeCampaigns > 0) {
      return {
        title:
          activeCampaigns === 1
            ? "1 campanha em curso"
            : `${activeCampaigns} campanhas em curso`,
        desc: "Conclua as ações pendentes para creditar recompensas",
        cta: "Ver ações",
        onClick: () => onNavigate("campaigns"),
        icon: IconCampaigns,
        tone: "violet" as const,
      };
    }
    if (referrals === 0) {
      return {
        title: "Ainda sem indicações",
        desc: "Partilhe o seu link e comece a ganhar comissões",
        cta: "Programa afiliado",
        onClick: () => onNavigate("affiliate"),
        icon: IconInvite,
        tone: "amber" as const,
      };
    }
    return {
      title: "Continue a operar",
      desc: "Veja tarefas da comunidade ou peça engajamento na loja",
      cta: "Ver tarefas",
      onClick: () => onNavigate("tasks"),
      icon: IconTasks,
      tone: "teal" as const,
    };
  }, [
    isSubscriber,
    reservedBalance,
    activeCampaigns,
    referrals,
    formatCurrency,
    onNavigate,
    onOpenSubscribe,
  ]);

  // Skeleton só no primeiro carregamento de dados (não em cada refresh)
  if (isRefreshing && !dataUpdatedAt) {
    return <HomeSkeleton />;
  }

  const NextIcon = nextAction.icon;
  const nextToneClass =
    nextAction.tone === "dark"
      ? "bg-slate-900 text-white border border-slate-800"
      : nextAction.tone === "amber"
        ? "bg-amber-50 text-amber-950 border border-amber-200/80"
        : nextAction.tone === "violet"
          ? "bg-violet-50 text-violet-950 border border-violet-200/80"
          : "bg-teal-50 text-teal-950 border border-teal-200/80";

  const nextIconBox =
    nextAction.tone === "dark"
      ? "bg-white/10 text-amber-300"
      : nextAction.tone === "amber"
        ? "bg-amber-100 text-amber-700"
        : nextAction.tone === "violet"
          ? "bg-violet-100 text-violet-700"
          : "bg-teal-100 text-teal-700";

  const nextCtaClass =
    nextAction.tone === "dark"
      ? "text-white/90"
      : "text-slate-700";

  return (
    <div className="space-y-5 tab-enter pb-2">
      {/* Saudação curta + nível discreto */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-[20px] font-semibold text-slate-900 tracking-tight truncate">
            Olá, {firstName}
          </h2>
          <p className="text-[13px] text-slate-400 mt-0.5 flex items-center gap-1.5 flex-wrap">
            <span>Atualizado {formatUpdatedAt(dataUpdatedAt)}</span>
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                disabled={!!isRefreshing}
                className="inline-flex items-center gap-1 text-teal-700 font-medium hover:underline disabled:opacity-60 min-h-[44px]"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "A atualizar…" : "Atualizar"}
              </button>
            )}
          </p>
        </div>
        <span
          className={`shrink-0 text-[11px] font-medium px-2.5 py-1 rounded-full ${
            isSubscriber
              ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"
              : "bg-amber-50 text-amber-700 ring-1 ring-amber-100"
          }`}
        >
          {isSubscriber ? "Assinante" : "Visitante"}
        </span>
      </div>

      {/* Cartão de saldo + ações primárias */}
      <div className="relative overflow-hidden rounded-2xl bg-[#0b5f58] text-white p-5 shadow-md border border-teal-900/20">
        {/* Mascote em marca d'água (fundo transparente) */}
        <img
          src="/home-mascot.png"
          alt=""
          aria-hidden="true"
          width={140}
          height={140}
          decoding="async"
          className="pointer-events-none absolute -right-3 -bottom-6 w-36 h-36 object-contain opacity-[0.22] select-none mix-blend-screen"
        />
        <div className="relative z-[1]">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-white/80">
              <IconWallet className="w-4 h-4" />
              <span className="text-[13px] font-medium">Disponível</span>
            </div>
            <div className="flex items-center gap-2">
              {onToggleHideBalance && (
                <button
                  type="button"
                  onClick={onToggleHideBalance}
                  className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/15 flex items-center justify-center pressable"
                  aria-label={hideBalance ? "Mostrar saldo" : "Ocultar saldo"}
                >
                  {hideBalance ? (
                    <Eye className="w-3.5 h-3.5 text-white/90" />
                  ) : (
                    <EyeOff className="w-3.5 h-3.5 text-white/90" />
                  )}
                </button>
              )}
              <button
                type="button"
                onClick={() => onNavigate("wallet")}
                className="text-[12px] font-medium text-white/90 underline-offset-2 hover:underline"
              >
                Ver conta
              </button>
            </div>
          </div>
          <p className="text-[30px] font-bold tracking-tight tabular-nums leading-none">
            {hideBalance ? "••••••" : formatCurrency(balance)}
          </p>
          {reservedBalance > 0 && (
            <p className="text-[12px] text-white/70 mt-2">
              Em análise: {hideBalance ? "••••" : formatCurrency(reservedBalance)}
            </p>
          )}
          {/* Dois botões primários */}
          <div className="mt-4 grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => onOpenDeposit?.()}
              className="h-11 min-h-[44px] rounded-xl bg-white text-teal-900 text-[13px] font-semibold flex items-center justify-center gap-1.5 pressable"
            >
              <IconDeposit className="w-4 h-4" />
              Depositar
            </button>
            <button
              type="button"
              onClick={() => onNavigate("wallet")}
              className="h-11 min-h-[44px] rounded-xl bg-white/12 hover:bg-white/20 text-white text-[13px] font-semibold border border-white/20 flex items-center justify-center gap-1.5 pressable"
            >
              <IconWithdraw className="w-4 h-4" />
              Levantar
            </button>
          </div>
          {/* Dois secundários */}
          <div className="mt-2.5 grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => onNavigate("affiliate")}
              className="h-10 min-h-[40px] rounded-xl bg-transparent text-white/90 text-[12px] font-medium border border-white/15 flex items-center justify-center gap-1.5 pressable"
            >
              <IconInvite className="w-3.5 h-3.5" />
              Convidar
            </button>
            <button
              type="button"
              onClick={() => onNavigate("tasks")}
              className="h-10 min-h-[40px] rounded-xl bg-transparent text-white/90 text-[12px] font-medium border border-white/15 flex items-center justify-center gap-1.5 pressable"
            >
              <IconProof className="w-3.5 h-3.5" />
              Enviar prova
            </button>
          </div>
        </div>
      </div>

      {/* Pendente / próxima ação (só o que pede atenção) */}
      <button
        type="button"
        onClick={nextAction.onClick}
        className={`w-full rounded-2xl p-4 flex items-center gap-3 pressable text-left min-h-[56px] shadow-sm ${nextToneClass}`}
      >
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${nextIconBox}`}
        >
          <NextIcon className="w-5 h-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[14px] font-semibold leading-tight">{nextAction.title}</p>
          <p
            className={`text-[12px] mt-0.5 leading-snug ${
              nextAction.tone === "dark" ? "text-white/65" : "text-slate-500"
            }`}
          >
            {nextAction.desc}
          </p>
        </div>
        <span className={`text-[12px] font-semibold shrink-0 flex items-center gap-0.5 ${nextCtaClass}`}>
          {nextAction.cta}
          <ChevronRight className="w-3.5 h-3.5" />
        </span>
      </button>

      {/* Três métricas da semana */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="card-clean p-3.5">
          <div className="flex items-center gap-1.5 text-emerald-600 mb-1.5">
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium text-slate-500">Entradas</span>
          </div>
          <p className="text-[14px] font-semibold text-slate-900 tabular-nums leading-tight">
            {formatCurrency(analytics.totalIn)}
          </p>
        </div>
        <div className="card-clean p-3.5">
          <div className="flex items-center gap-1.5 text-rose-500 mb-1.5">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium text-slate-500">Saídas</span>
          </div>
          <p className="text-[14px] font-semibold text-slate-900 tabular-nums leading-tight">
            {formatCurrency(analytics.totalOut)}
          </p>
        </div>
        <div className="card-clean p-3.5">
          <div className="flex items-center gap-1.5 text-teal-700 mb-1.5">
            {analytics.net >= 0 ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5" />
            )}
            <span className="text-[11px] font-medium text-slate-500">Líquido</span>
          </div>
          <p
            className={`text-[14px] font-semibold tabular-nums leading-tight ${
              analytics.net >= 0 ? "text-emerald-700" : "text-rose-600"
            }`}
          >
            {formatCurrency(analytics.net)}
          </p>
        </div>
      </div>

      {/* Fluxo da carteira */}
      <WalletFlowChart
        days={flow.days}
        period={period}
        onPeriodChange={setPeriod}
        balance={balance}
        formatCurrency={formatCurrency}
        onOpenDeposit={onOpenDeposit}
        source={flow.source}
      />

      {/* Comunidade: seguidores, a seguir e monitor de execuções */}
      <ExchangeMonitor
        userId={userId}
        isSubscriber={isSubscriber}
        refreshKey={dataUpdatedAt}
        onOpenTasks={() => onNavigate("tasks")}
        onOpenSubscribe={onOpenSubscribe}
      />

      {/* Resumo de trabalho */}
      <div>
        <p className="text-[14px] font-semibold text-slate-900 mb-2.5">Resumo de trabalho</p>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => onNavigate("campaigns")}
            className="rounded-2xl bg-white border border-slate-200/80 p-3.5 text-left shadow-sm pressable min-h-[44px]"
          >
            <div className="w-9 h-9 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center mb-2">
              <IconCampaigns className="w-4 h-4" />
            </div>
            <p className="text-[12px] font-medium text-slate-500">Campanhas ativas</p>
            <p className="text-[18px] font-bold text-slate-900 tabular-nums tracking-tight">{activeCampaigns}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">{doneCampaigns} concluídas</p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("tasks")}
            className="rounded-2xl bg-white border border-slate-200/80 p-3.5 text-left shadow-sm pressable min-h-[44px]"
          >
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mb-2">
              <IconTasks className="w-4 h-4" />
            </div>
            <p className="text-[12px] font-medium text-slate-500">Tarefas</p>
            <p className="text-[18px] font-bold text-slate-900 tabular-nums tracking-tight">
              {isSubscriber ? "Abertas" : "—"}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isSubscriber ? "Ver comunidade" : "Requer assinatura"}
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("affiliate")}
            className="rounded-2xl bg-white border border-slate-200/80 p-3.5 text-left shadow-sm pressable min-h-[44px]"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-2">
              <IconInvite className="w-4 h-4" />
            </div>
            <p className="text-[12px] font-medium text-slate-500">Indicações</p>
            <p className="text-[18px] font-bold text-slate-900 tabular-nums tracking-tight">{referrals}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {affiliateEarned > 0 ? formatCurrency(affiliateEarned) + " ganhos" : "Programa afiliado"}
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("engagement")}
            className="rounded-2xl bg-white border border-slate-200/80 p-3.5 text-left shadow-sm pressable min-h-[44px]"
          >
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center mb-2">
              <IconStore className="w-4 h-4" />
            </div>
            <p className="text-[12px] font-medium text-slate-500">Loja</p>
            <p className="text-[18px] font-bold text-slate-900 tracking-tight">Engajamento</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Seguidores, gostos, views</p>
          </button>
        </div>
      </div>

      {/* Movimentos recentes */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <p className="text-[14px] font-semibold text-slate-900">Movimentos recentes</p>
          <button
            type="button"
            onClick={() => onNavigate("wallet")}
            className="text-[12px] font-semibold text-teal-700 min-h-[44px] px-1"
          >
            Ver todos
          </button>
        </div>
        {analytics.recentMoves.length === 0 ? (
          <p className="px-4 pb-4 text-[12px] text-slate-400">Ainda não há movimentos na carteira.</p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {analytics.recentMoves.map((tx, i) => {
              const amt = Number(tx.amount) || 0;
              const positive = amt >= 0;
              return (
                <li key={tx.id || i} className="flex items-center gap-3 px-4 py-3">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      positive ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500"
                    }`}
                  >
                    {positive ? (
                      <ArrowDownLeft className="w-3.5 h-3.5" />
                    ) : (
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[12px] font-semibold text-slate-800 truncate">
                      {tx.description || tx.type || "Movimento"}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      {new Date(tx.created_at).toLocaleString("pt-PT", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <p
                    className={`text-[12px] font-extrabold tabular-nums shrink-0 ${
                      positive ? "text-emerald-600" : "text-rose-600"
                    }`}
                  >
                    {positive ? "+" : ""}
                    {formatCurrency(amt)}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
};

export default HomeDashboard;
