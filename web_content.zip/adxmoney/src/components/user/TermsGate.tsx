import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { TERMS_VERSION } from "@/lib/legal";

/**
 * Ecrã bloqueante: enquanto o utilizador não tiver aceite a versão atual dos Termos/Privacidade,
 * não consegue usar a app. Cobre contas antigas, contas criadas pelo admin e novas versões dos termos.
 * Se a verificação falhar (rede/migração em falta), a app FICA bloqueada com "Tentar novamente":
 * nunca se presume que os termos foram aceites. (A versão oficial é validada pelo servidor.)
 */
export function TermsGate() {
  const { user } = useAuth();
  const [needsAccept, setNeedsAccept] = useState(false);
  const [saving, setSaving] = useState(false);
  const [checked, setChecked] = useState(false);
  const [checkFailed, setCheckFailed] = useState(false);
  const [retryTick, setRetryTick] = useState(0);

  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;
    setCheckFailed(false);
    (async () => {
      try {
        const { data, error } = await supabase
          .from("terms_acceptances")
          .select("id")
          .eq("user_id", user.id)
          .eq("terms_version", TERMS_VERSION)
          .limit(1);
        if (error) throw error;
        if (!cancelled) setNeedsAccept((data || []).length === 0);
      } catch (e) {
        console.warn("TermsGate: verificação indisponível", e);
        if (!cancelled) setCheckFailed(true);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id, retryTick]);

  if (checkFailed) {
    return (
      <div className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-900/70 p-4 sm:items-center">
        <div className="w-full max-w-md space-y-4 rounded-2xl bg-white p-5 shadow-xl">
          <h2 className="text-lg font-bold text-slate-900">Não foi possível verificar os Termos</h2>
          <p className="text-[13px] leading-relaxed text-slate-600">
            Verifique a ligação à internet e tente novamente. Por segurança, só pode continuar depois desta verificação.
          </p>
          <Button
            onClick={() => setRetryTick((n) => n + 1)}
            className="h-12 w-full rounded-xl bg-emerald-700 text-[14px] font-semibold text-white hover:bg-emerald-800"
          >
            Tentar novamente
          </Button>
        </div>
      </div>
    );
  }

  if (!needsAccept) return null;

  const accept = async () => {
    setSaving(true);
    try {
      const { error } = await supabase.rpc("accept_terms", { p_version: TERMS_VERSION });
      if (error) throw error;
      setNeedsAccept(false);
    } catch (e: any) {
      toast.error(e?.message || "Não foi possível guardar a aceitação. Tente novamente.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-900/70 p-4 sm:items-center">
      <div className="w-full max-w-md space-y-4 rounded-2xl bg-white p-5 shadow-xl">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Termos e Privacidade</h2>
          <p className="mt-1 text-[13px] leading-relaxed text-slate-600">
            Para continuar a usar a ADXmoney, leia e aceite os Termos e Condições e a Política de Privacidade (versão {TERMS_VERSION}).
          </p>
        </div>
        <div className="flex gap-4 text-[13px] font-semibold">
          <Link to="/termos" target="_blank" className="text-emerald-700 underline">Ler os Termos</Link>
          <Link to="/privacidade" target="_blank" className="text-emerald-700 underline">Ler a Privacidade</Link>
        </div>
        <label className="flex items-start gap-3 text-[13px] text-slate-700">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            className="mt-0.5 h-5 w-5 shrink-0 accent-emerald-700"
          />
          <span>Li e aceito os Termos e Condições e a Política de Privacidade.</span>
        </label>
        <Button
          onClick={accept}
          disabled={!checked || saving}
          className="h-12 w-full rounded-xl bg-emerald-700 text-[14px] font-semibold text-white hover:bg-emerald-800"
        >
          {saving ? "A guardar..." : "Aceitar e continuar"}
        </Button>
      </div>
    </div>
  );
}
