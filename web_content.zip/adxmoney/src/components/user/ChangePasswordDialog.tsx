import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ChangePasswordDialog({ open, onOpenChange }: Props) {
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [saving, setSaving] = useState(false);

  const close = (o: boolean) => {
    if (!o) { setPw(""); setPw2(""); }
    onOpenChange(o);
  };

  const save = async () => {
    if (pw.length < 8) { toast.error("A palavra-passe deve ter pelo menos 8 caracteres."); return; }
    if (pw !== pw2) { toast.error("As palavras-passe não coincidem."); return; }
    setSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: pw });
      if (error) throw error;
      toast.success("Palavra-passe alterada.");
      close(false);
    } catch (e: any) {
      toast.error(e?.message || "Não foi possível alterar a palavra-passe.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent className="max-w-sm rounded-2xl bg-white">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Alterar palavra-passe</DialogTitle>
          <DialogDescription className="text-xs">Escolha uma palavra-passe nova, com pelo menos 8 caracteres.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label className="text-xs font-bold">Nova palavra-passe</Label>
            <Input type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} className="h-11" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs font-bold">Repita a nova palavra-passe</Label>
            <Input type="password" autoComplete="new-password" value={pw2} onChange={(e) => setPw2(e.target.value)} className="h-11" />
          </div>
          <Button onClick={save} disabled={saving} className="h-11 w-full rounded-xl bg-slate-900 text-white">
            {saving ? "A guardar..." : "Guardar"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
