import React, { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ExternalLink, Loader2, MoreVertical, Flag, Upload, Clock, CheckCircle2, XCircle, BrandTikTok, BrandInstagram, BrandYouTube } from "@/components/icons";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { SectionSkeleton } from "@/components/ui/section-skeleton";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { checkProofFile, prepareProof, proofPath } from "@/lib/upload";
import { sha256File } from "@/lib/hash";
import { ProofReviewList } from "@/components/user/ProofReviewList";

interface CommunityTask {
  id: string;
  task_id: string;
  platform: 'tiktok' | 'instagram' | 'youtube' | 'other';
  task_type: 'follow' | 'like' | 'comment' | 'view';
  profile_url: string;
  description: string;
  status: string;
  proof_status?: string | null;
}

interface ProofHistory {
  id: string;
  status: string;
  review_note: string | null;
  handle: string;
  created_at: string;
}

interface Platform {
  id: 'tiktok' | 'instagram' | 'youtube';
  label: string;
  icon: React.ReactNode;
}

export const CommunityTasksSection: React.FC<{ active?: boolean }> = ({ active = true }) => {
  const [tasks, setTasks] = useState<CommunityTask[]>([]);
  const [loading, setLoading] = useState(true);
  // Troca de seguidores: sem link publicado não se recebem links de outros
  const [hasOwnLink, setHasOwnLink] = useState(true);
  const [activePlatform, setActivePlatform] = useState<'tiktok' | 'instagram' | 'youtube'>('tiktok');
  
  // Daily limits state mapped by platform
  const [limits, setLimits] = useState<Record<string, { current: number, max: number }>>({
    tiktok: { current: 0, max: 100 },
    instagram: { current: 0, max: 100 },
    youtube: { current: 0, max: 100 }
  });

  // Prova de execução (a recompensa só é paga depois de validada)
  const [proofTask, setProofTask] = useState<CommunityTask | null>(null);
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreview, setProofPreview] = useState<string | null>(null);
  const [proofHandle, setProofHandle] = useState("");
  const [isSubmittingProof, setIsSubmittingProof] = useState(false);
  const [handles, setHandles] = useState<Record<string, string>>({});
  const [history, setHistory] = useState<ProofHistory[]>([]);
  const [myId, setMyId] = useState<string | undefined>(undefined);

  const [reportingTask, setReportingTask] = useState<CommunityTask | null>(null);
  const [reportReason, setReportReason] = useState("");
  const [isReporting, setIsReporting] = useState(false);

  const platforms: Platform[] = [
    { id: 'tiktok', label: 'TikTok', icon: <BrandTikTok className="w-5 h-5 text-slate-800" /> },
    { id: 'instagram', label: 'Instagram', icon: <BrandInstagram className="w-5 h-5 text-slate-800" /> },
    { id: 'youtube', label: 'YouTube', icon: <BrandYouTube className="w-5 h-5 text-[#FF0000]" /> },
  ];

  const firstLoadDone = useRef(false);
  const loadTasks = async () => {
    if (!firstLoadDone.current) setLoading(true);
    try {
      const { data, error } = await supabase.rpc('fetch_or_assign_community_tasks');
      if (error) throw error;
      
      const loadedTasks = data || [];
      setTasks(loadedTasks);

      // @ já registados e histórico recente de provas (tolerante a falhas)
      try {
        const uid = (await supabase.auth.getUser()).data.user?.id;
        setMyId(uid);
        const { data: ownLinks } = await supabase
          .from('community_tasks')
          .select('id')
          .eq('creator_user_id', uid || '')
          .eq('source', 'EXCHANGE')
          .eq('is_active', true)
          .limit(1);
        setHasOwnLink((ownLinks || []).length > 0);
        const [hRes, pRes] = await Promise.all([
          supabase.from('social_handles').select('platform, handle'),
          supabase
            .from('task_proofs')
            .select('id, status, review_note, handle, created_at')
            .eq('user_id', uid || '')
            .order('created_at', { ascending: false })
            .limit(8),
        ]);
        const map: Record<string, string> = {};
        (hRes.data || []).forEach((h: any) => { map[h.platform] = h.handle; });
        setHandles(map);
        setHistory((pRes.data as ProofHistory[]) || []);
      } catch (e) {
        console.warn("Histórico de provas indisponível:", e);
      }

      // Obter limites configurados de forma totalmente segura e tolerante a falhas
      let configuredLimits: Record<string, number> = { tiktok: 100, instagram: 100, youtube: 100 };
      try {
        const { data: limitRows } = await supabase
          .from('community_settings')
          .select('platform, daily_limit');
        (limitRows || []).forEach((r: any) => {
          if (r?.platform && Number.isFinite(r.daily_limit)) configuredLimits[r.platform] = r.daily_limit;
        });
      } catch (e) {
        console.warn("Usando limites padrão por indisponibilidade de settings:", e);
      }

      // Contagem de provas enviadas hoje por plataforma (alinhada com o servidor)
      const counts: Record<string, number> = { tiktok: 0, instagram: 0, youtube: 0 };
      
      const userId = (await supabase.auth.getUser()).data.user?.id;
      if (userId) {
        // Mesma regra do servidor: provas enviadas hoje (dia UTC), por plataforma
        const todayUtc = new Date().toISOString().slice(0, 10) + 'T00:00:00Z';
        const { data: doneToday, error: qError } = await supabase
          .from('task_proofs')
          .select('id, task_id')
          .eq('user_id', userId)
          .gte('created_at', todayUtc);

        if (!qError && doneToday && doneToday.length > 0) {
          const tIds = doneToday.map((q: any) => q.task_id).filter(Boolean);
          const { data: tData } = await supabase.from('community_tasks').select('id, platform').in('id', tIds);
          if (tData) {
            const platformMap = new Map(tData.map((t: any) => [t.id, t.platform?.toLowerCase()]));
            doneToday.forEach((q: any) => {
              const plat = platformMap.get(q.task_id);
              if (plat && counts[plat] !== undefined) counts[plat]++;
            });
          }
        }

        // Novos utilizadores (confiança < 5) têm teto de 10/dia: mostra o limite que o servidor aplica de facto
        try {
          const { data: trustRow } = await supabase.from('user_trust').select('score').eq('user_id', userId).maybeSingle();
          if (((trustRow as any)?.score ?? 0) < 5) {
            Object.keys(configuredLimits).forEach((k) => { configuredLimits[k] = Math.min(configuredLimits[k], 10); });
          }
        } catch { /* sem confiança registada = novo utilizador */ }
      }

      setLimits({
        tiktok: { current: counts.tiktok, max: configuredLimits.tiktok },
        instagram: { current: counts.instagram, max: configuredLimits.instagram },
        youtube: { current: counts.youtube, max: configuredLimits.youtube }
      });

    } catch (err: any) {
      console.error("Erro ao carregar tarefas:", err);
      // Não bloqueia a UI com toast de erro agressivo se for falha de rede/sincronismo menor
      setTasks([]);
    } finally {
      firstLoadDone.current = true;
      setLoading(false);
    }
  };

  // 1.ª vez: carrega com esqueleto; ao voltar a este separador: actualiza em silêncio
  useEffect(() => {
    if (active) loadTasks();
  }, [active]);

  const openProof = (task: CommunityTask) => {
    setProofTask(task);
    setProofFile(null);
    setProofPreview(null);
    setProofHandle(handles[task.platform] ? `@${handles[task.platform]}` : "");
  };

  const closeProof = () => {
    if (isSubmittingProof) return;
    if (proofPreview) URL.revokeObjectURL(proofPreview);
    setProofTask(null);
    setProofFile(null);
    setProofPreview(null);
  };

  const onProofFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    if (!f) return;
    const check = checkProofFile(f, { imagesOnly: true });
    if (!check.ok) {
      toast.error(check.error);
      e.target.value = "";
      return;
    }
    if (proofPreview) URL.revokeObjectURL(proofPreview);
    setProofFile(f);
    setProofPreview(f.type.startsWith("image/") ? URL.createObjectURL(f) : null);
  };

  const handleSubmitProof = async () => {
    if (!proofTask || !proofFile || !myId) return;
    if (proofHandle.trim().length < 2) {
      toast.error("Indique o seu @ da plataforma.");
      return;
    }
    setIsSubmittingProof(true);
    try {
      // Hash do original (deteta a mesma captura reenviada); envia-se a versão comprimida
      const prepared = await prepareProof(proofFile, { imagesOnly: true });
      const hash = await sha256File(proofFile);
      const path = proofPath(myId, prepared.ext);

      const { error: upErr } = await supabase.storage
        .from("subscription-proofs")
        .upload(path, prepared.file, { upsert: false, contentType: prepared.file.type });
      if (upErr) throw upErr;

      const { error } = await supabase.rpc('submit_task_proof', {
        p_task_id: proofTask.task_id,
        p_proof_path: path,
        p_proof_hash: hash,
        p_handle: proofHandle.trim(),
      });
      if (error) {
        // limpeza best-effort do ficheiro órfão
        await supabase.storage.from("subscription-proofs").remove([path]).catch(() => undefined);
        throw error;
      }
      toast.success("Prova enviada! O dono do link valida em até 24h; se não responder, a prova é aprovada automaticamente.");
      if (proofPreview) URL.revokeObjectURL(proofPreview);
      setProofTask(null);
      setProofFile(null);
      setProofPreview(null);
      loadTasks();
    } catch (err: any) {
      toast.error(err?.message || "Erro ao enviar a prova.");
    } finally {
      setIsSubmittingProof(false);
    }
  };

  const handleReport = async () => {
    if (!reportingTask || !reportReason.trim()) return;
    setIsReporting(true);
    try {
      const { error } = await supabase.rpc('report_community_task', { 
        p_task_id: reportingTask.task_id, 
        p_reason: reportReason 
      });
      if (error) throw error;
      toast.success("Denúncia enviada.");
      setReportingTask(null);
      setReportReason("");
      loadTasks();
    } catch (err: any) {
      toast.error("Erro ao denunciar: " + err.message);
    } finally {
      setIsReporting(false);
    }
  };

  const filteredTasks = tasks.filter(t => t.platform?.toLowerCase() === activePlatform.toLowerCase());

  if (loading) return <SectionSkeleton rows={4} />;

  return (
    <div className="space-y-6">
      {/* Abas de Plataforma */}
      <div className="flex bg-white rounded-2xl p-1 border border-slate-200 shadow-sm">
        {platforms.map(p => (
          <button
            key={p.id}
            onClick={() => setActivePlatform(p.id)}
            className={`flex-1 py-3 rounded-xl text-[11px] font-semibold transition-all flex items-center justify-center gap-2 ${
              activePlatform === p.id ? "bg-emerald-600 text-white shadow-sm " : "text-slate-400 hover:text-slate-600"
            }`}
          >
            {p.icon} {p.label}
          </button>
        ))}
      </div>

      {/* Contador e Progresso */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm">
        <div className="flex justify-between items-center mb-3">
          <span className="text-[11px] font-semibold text-slate-500">Limite diário {platforms.find(p => p.id === activePlatform)?.label}</span>
          <span className="text-xs font-mono font-bold text-emerald-600">{limits[activePlatform].current} / {limits[activePlatform].max}</span>
        </div>
        <Progress value={(limits[activePlatform].current / limits[activePlatform].max) * 100} className="h-2 bg-slate-100 rounded-full" />
      </div>

      {limits[activePlatform].current >= limits[activePlatform].max ? (
        <div className="text-center py-16 bg-white border border-slate-200/80 rounded-2xl shadow-sm text-slate-400 text-xs font-medium tracking-tight">Limite de {activePlatform} atingido por hoje.</div>
      ) : filteredTasks.length === 0 ? (
        <div className="text-center py-16 bg-white border border-slate-200/80 rounded-2xl shadow-sm text-slate-400 text-xs font-medium tracking-tight">{hasOwnLink
          ? "Nenhuma tarefa disponível nesta plataforma."
          : "Para receber links na troca de seguidores, adicione o link da sua conta no Perfil. O seu link é partilhado com os outros membros."}</div>
      ) : (
        <div className="grid gap-3">
          {filteredTasks.map((task) => (
            <Card key={task.id} className="card-clean overflow-hidden">
              <CardHeader className="p-5 pb-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-center shrink-0">
                      {task.platform === 'tiktok' && <BrandTikTok className="w-4 h-4 text-slate-800" />}
                      {task.platform === 'instagram' && <BrandInstagram className="w-4 h-4 text-slate-800" />}
                      {task.platform === 'youtube' && <BrandYouTube className="w-4 h-4 text-[#FF0000]" />}
                    </div>
                    <Badge className="bg-emerald-50 text-emerald-700 border border-emerald-100 px-3 py-1 font-semibold text-[11px]">
                       {task.task_type}
                    </Badge>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                       <Button variant="ghost" size="icon" className="h-11 w-11 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50">
                          <MoreVertical className="w-4 h-4" />
                       </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-white border-slate-100 rounded-2xl shadow-md">
                      <DropdownMenuItem className="text-red-500 font-bold text-xs" onClick={() => setReportingTask(task)}>
                         <Flag className="w-3 h-3 mr-2" /> Denunciar Problema
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="p-5 pt-0 text-sm text-slate-500 font-medium leading-relaxed">
                 {task.description}
              </CardContent>
              <CardFooter className="p-5 pt-0 flex gap-3">
                <Button variant="outline" className="flex-1 h-11 rounded-2xl border-slate-100 text-slate-600 font-semibold text-[11px] hover:bg-slate-50" asChild>
                   <a href={task.profile_url} target="_blank" rel="noreferrer">
                      Abrir perfil <ExternalLink className="w-3 h-3 ml-2" />
                   </a>
                </Button>
                {task.proof_status === 'SUBMITTED' ? (
                  <Button disabled className="flex-1 h-11 rounded-2xl bg-amber-50 text-amber-700 font-semibold text-[11px] opacity-100">
                    <Clock className="w-3.5 h-3.5 mr-2" /> A aguardar validação
                  </Button>
                ) : (
                  <Button className="flex-1 h-11 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] shadow-sm " onClick={() => openProof(task)}>
                    <Upload className="w-3.5 h-3.5 mr-2" /> Enviar prova
                  </Button>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Provas a validar (só aparece se for criador de tarefas com provas pendentes) */}
      <ProofReviewList mode="creator" userId={myId} active={active} />

      {/* Histórico recente de provas */}
      {history.length > 0 && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm space-y-3">
          <span className="text-[11px] font-semibold text-slate-500">As minhas últimas provas</span>
          {history.map((h) => (
            <div key={h.id} className="flex items-start justify-between gap-3 text-xs">
              <div className="min-w-0">
                <p className="font-bold text-slate-700 truncate">@{h.handle}</p>
                {h.status === 'REJECTED' && h.review_note && (
                  <p className="text-[11px] text-red-500">{h.review_note}</p>
                )}
              </div>
              {h.status === 'SUBMITTED' && <span className="flex items-center gap-1 text-amber-600 font-semibold text-[11px] shrink-0"><Clock className="w-3 h-3" />Pendente</span>}
              {(h.status === 'APPROVED' || h.status === 'AUTO_APPROVED') && <span className="flex items-center gap-1 text-emerald-600 font-semibold text-[11px] shrink-0"><CheckCircle2 className="w-3 h-3" />Paga</span>}
              {h.status === 'REJECTED' && <span className="flex items-center gap-1 text-red-500 font-semibold text-[11px] shrink-0"><XCircle className="w-3 h-3" />Rejeitada</span>}
            </div>
          ))}
        </div>
      )}

      {/* Dialog de envio de prova */}
      <Dialog open={!!proofTask} onOpenChange={(open) => !open && closeProof()}>
        <DialogContent className="bg-white border-none sm:rounded-2xl p-6 shadow-md">
          <DialogHeader>
            <DialogTitle className="text-lg font-bold text-slate-900">Enviar prova</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              Troca de seguidores: siga as contas abaixo e envie uma captura de ecrã como prova. O dono do link valida em até 24h (se não responder, é aprovada). Os outros membros também seguem a sua conta.
            </p>
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-400 ">O seu @ nesta plataforma</label>
              <Input
                value={proofHandle}
                onChange={(e) => setProofHandle(e.target.value)}
                disabled={!!proofTask && !!handles[proofTask.platform]}
                placeholder="@o_seu_utilizador"
                className="h-12 rounded-2xl bg-slate-50 border-transparent font-bold"
              />
              <p className="text-[11px] text-slate-400">Cada @ só pode ser usado numa conta e não pode ser alterado.</p>
            </div>
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-400 ">Captura de ecrã</label>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={onProofFileChange}
                className="block w-full text-xs text-slate-500 file:mr-3 file:rounded-xl file:border-0 file:bg-emerald-50 file:px-4 file:py-2.5 file:text-[11px] file:font-semibold file:file:text-emerald-700"
              />
              {proofPreview && <img src={proofPreview} alt="Pré-visualização" className="w-full max-h-52 object-contain rounded-xl bg-slate-50" />}
            </div>
          </div>
          <DialogFooter className="flex gap-3">
            <Button variant="ghost" onClick={closeProof} disabled={isSubmittingProof} className="flex-1 h-12 rounded-2xl font-semibold text-[11px] text-slate-400">
              Cancelar
            </Button>
            <Button onClick={handleSubmitProof} disabled={isSubmittingProof || !proofFile} className="flex-1 h-12 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] ">
              {isSubmittingProof ? <Loader2 className="w-4 h-4 animate-spin" /> : "ENVIAR"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Report Dialog */}
      <Dialog open={!!reportingTask} onOpenChange={(open) => !open && setReportingTask(null)}>
        <DialogContent className="bg-white border-none sm:rounded-2xl p-8 shadow-md">
          <DialogHeader>
             <DialogTitle className="text-lg font-bold text-slate-900">Denunciar Tarefa</DialogTitle>
          </DialogHeader>
          <div className="py-4">
             <Textarea 
               className="bg-slate-50 border-transparent focus:bg-white focus:border-emerald-500 rounded-2xl min-h-[120px] font-medium text-slate-600" 
               value={reportReason} 
               onChange={(e) => setReportReason(e.target.value)} 
               placeholder="Descreva o motivo da denúncia..." 
             />
          </div>
          <DialogFooter className="flex gap-3">
            <Button variant="ghost" onClick={() => setReportingTask(null)} className="flex-1 h-12 rounded-2xl font-semibold text-[11px] text-slate-400">
               Cancelar
            </Button>
            <Button onClick={handleReport} disabled={isReporting} className="flex-1 h-12 rounded-2xl bg-red-500 hover:bg-red-600 text-white font-semibold text-[11px] shadow-sm ">
               {isReporting ? <Loader2 className="w-4 h-4 animate-spin" /> : "ENVIAR DENÚNCIA"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
