import React, { useEffect, useMemo, useState } from "react";
import {
  ComposedChart,
  Bar,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  ReferenceLine,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, TrendingDown, Wallet } from "@/components/icons";
import type { FlowDay } from "@/hooks/useWalletFlow";

export type FlowPeriod = 7 | 30 | 90;

interface Point {
  label: string;
  range: string;
  entradas: number;
  saidas: number;
  saidasNeg: number;
  net: number;
  saldo: number;
}

interface Props {
  /** Dias (antigo → recente), com 2 × período: a 1.ª metade é o período anterior */
  days: FlowDay[];
  period: FlowPeriod;
  onPeriodChange: (p: FlowPeriod) => void;
  balance: number;
  formatCurrency: (amountKz: number) => string;
  onOpenDeposit?: () => void;
  source?: "server" | "local";
}

const TEAL = "#0f766e";
const ROSE = "#f43f5e";

function clean(s: string) {
  return s.replace(/\./g, "").trim();
}
function dayMonth(d: Date) {
  return clean(d.toLocaleDateString("pt-PT", { day: "2-digit", month: "short" }));
}
function weekday(d: Date) {
  return clean(d.toLocaleDateString("pt-PT", { weekday: "short" }));
}
function fullDate(d: Date) {
  return clean(d.toLocaleDateString("pt-PT", { weekday: "short", day: "2-digit", month: "short" }));
}
function compact(n: number) {
  const a = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (a >= 1_000_000) return `${sign}${(a / 1_000_000).toFixed(1).replace(".0", "")}M`;
  if (a >= 1_000) return `${sign}${Math.round(a / 1_000)}k`;
  return `${sign}${Math.round(a)}`;
}

/** Lê o ponto sob o dedo/cursor a partir do Tooltip do recharts (funciona com toque e rato). */
function Probe({ active, payload, onChange }: any) {
  const point: Point | null = active && payload && payload.length ? payload[0].payload : null;
  useEffect(() => {
    onChange(point);
  }, [point, onChange]);
  return null;
}

export const WalletFlowChart: React.FC<Props> = ({
  days,
  period,
  onPeriodChange,
  balance,
  formatCurrency,
  onOpenDeposit,
  source = "server",
}) => {
  const [mode, setMode] = useState<"flow" | "balance">("flow");
  const [hover, setHover] = useState<Point | null>(null);

  const reduceMotion =
    typeof window !== "undefined" && !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

  const model = useMemo(() => {
    const current = days.slice(-period);
    const previous = days.slice(0, Math.max(0, days.length - period));

    // Saldo no fim de cada dia, reconstruído para trás a partir do saldo actual
    const saldoEnd: number[] = new Array(current.length).fill(0);
    let running = balance;
    for (let i = current.length - 1; i >= 0; i--) {
      saldoEnd[i] = Math.max(0, running);
      running -= current[i].entradas - current[i].saidas;
    }

    const size = period === 90 ? 7 : 1;
    const groups: number[][] = [];
    for (let end = current.length; end > 0; end -= size) {
      const start = Math.max(0, end - size);
      groups.unshift(Array.from({ length: end - start }, (_, k) => start + k));
    }

    const points: Point[] = groups.map((idx) => {
      const first = current[idx[0]];
      const last = current[idx[idx.length - 1]];
      const entradas = idx.reduce((s, i) => s + current[i].entradas, 0);
      const saidas = idx.reduce((s, i) => s + current[i].saidas, 0);
      const label = period === 7 ? weekday(last.date) : dayMonth(last.date);
      const range = idx.length === 1 ? fullDate(last.date) : `${dayMonth(first.date)} – ${dayMonth(last.date)}`;
      return { label, range, entradas, saidas, saidasNeg: -saidas, net: entradas - saidas, saldo: saldoEnd[idx[idx.length - 1]] };
    });

    const sum = (arr: FlowDay[]) =>
      arr.reduce((a, d) => ({ in: a.in + d.entradas, out: a.out + d.saidas }), { in: 0, out: 0 });
    const cur = sum(current);
    const prev = sum(previous);
    const net = cur.in - cur.out;
    const prevNet = prev.in - prev.out;
    const delta = prevNet !== 0 ? ((net - prevNet) / Math.abs(prevNet)) * 100 : null;
    const hasActivity = cur.in > 0 || cur.out > 0;
    return { points, net, delta, hasActivity, totalIn: cur.in, totalOut: cur.out };
  }, [days, period, balance]);

  const interval = model.points.length <= 7 ? 0 : Math.ceil(model.points.length / 5) - 1;
  const periodLabel = period === 7 ? "7 dias" : period === 30 ? "30 dias" : "90 dias";
  const shown = hover;
  const netToShow = shown ? shown.net : model.net;
  const delta = model.delta;

  return (
    <div className="rounded-2xl bg-white border border-slate-200/80 p-4 shadow-sm">
      {/* Leitura: período por defeito, ponto seleccionado ao tocar/arrastar */}
      <div className="min-h-[68px]">
        <p className="text-[12px] text-slate-500">
          {shown ? shown.range : `Líquido · últimos ${periodLabel}`}
        </p>
        <div className="flex items-baseline gap-2 flex-wrap">
          <p
            className={`text-[24px] font-bold tabular-nums tracking-tight ${
              netToShow < 0 ? "text-rose-600" : "text-slate-900"
            }`}
          >
            {netToShow > 0 ? "+" : ""}
            {formatCurrency(netToShow)}
          </p>
          {!shown && delta !== null && Math.abs(delta) >= 0.1 && (
            <span
              className={`inline-flex items-center gap-1 text-[12px] font-medium ${
                delta >= 0 ? "text-emerald-600" : "text-rose-600"
              }`}
            >
              {delta >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              {delta >= 0 ? "+" : ""}
              {delta.toFixed(0)}% vs período anterior
            </span>
          )}
        </div>
        {shown && (
          <p className="text-[12px] text-slate-500 tabular-nums mt-0.5">
            <span className="text-teal-700">Entradas {formatCurrency(shown.entradas)}</span>
            {" · "}
            <span className="text-rose-600">Saídas {formatCurrency(shown.saidas)}</span>
            {" · "}
            Saldo {formatCurrency(shown.saldo)}
          </p>
        )}
      </div>

      {/* Vista + período */}
      <div className="flex items-center justify-between gap-2 mt-2 mb-1">
        <div className="flex gap-1" role="tablist" aria-label="Vista do gráfico">
          {([
            ["flow", "Fluxo"],
            ["balance", "Saldo"],
          ] as const).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={mode === id}
              onClick={() => setMode(id)}
              className={`px-3 min-h-[44px] text-[13px] rounded-lg pressable ${
                mode === id ? "bg-teal-50 text-teal-800 font-semibold" : "text-slate-500 font-medium"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="flex bg-slate-100 p-0.5 rounded-lg" role="tablist" aria-label="Período">
          {([7, 30, 90] as FlowPeriod[]).map((d) => (
            <button
              key={d}
              type="button"
              role="tab"
              aria-selected={period === d}
              onClick={() => onPeriodChange(d)}
              className={`min-w-[44px] min-h-[40px] px-2 text-[13px] rounded-md pressable ${
                period === d ? "bg-white text-slate-900 font-semibold shadow-sm" : "text-slate-500 font-medium"
              }`}
            >
              {d}d
            </button>
          ))}
        </div>
      </div>

      <div
        className="h-[190px] w-full"
        role="img"
        aria-label={`Gráfico de ${mode === "flow" ? "fluxo" : "saldo"} dos últimos ${periodLabel}. Entradas ${formatCurrency(
          model.totalIn
        )}, saídas ${formatCurrency(model.totalOut)}.`}
      >
        {model.hasActivity || mode === "balance" ? (
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={model.points}
              margin={{ top: 8, right: 4, left: 0, bottom: 0 }}
              barCategoryGap={period === 7 ? "30%" : "18%"}
              onMouseLeave={() => setHover(null)}
            >
              <CartesianGrid vertical={false} stroke="#eef2f6" />
              <XAxis
                dataKey="label"
                tickLine={false}
                axisLine={false}
                interval={interval}
                tickMargin={6}
                tick={{ fontSize: 11, fill: "#94a3b8" }}
              />
              <YAxis
                width={40}
                tickLine={false}
                axisLine={false}
                tickCount={4}
                tickFormatter={compact}
                tick={{ fontSize: 11, fill: "#94a3b8" }}
              />
              <Tooltip
                content={<Probe onChange={setHover} />}
                isAnimationActive={false}
                cursor={
                  mode === "flow"
                    ? { fill: "rgba(15,118,110,0.06)" }
                    : { stroke: "#94a3b8", strokeDasharray: "3 3" }
                }
              />
              {mode === "flow" ? (
                <>
                  <ReferenceLine y={0} stroke="#cbd5e1" />
                  <Bar
                    dataKey="entradas"
                    stackId="flow"
                    fill={TEAL}
                    radius={[3, 3, 0, 0]}
                    maxBarSize={18}
                    isAnimationActive={!reduceMotion}
                    animationDuration={350}
                  />
                  <Bar
                    dataKey="saidasNeg"
                    stackId="flow"
                    fill={ROSE}
                    radius={[0, 0, 3, 3]}
                    maxBarSize={18}
                    isAnimationActive={!reduceMotion}
                    animationDuration={350}
                  />
                </>
              ) : (
                <Area
                  type="stepAfter"
                  dataKey="saldo"
                  stroke={TEAL}
                  strokeWidth={2}
                  fill={TEAL}
                  fillOpacity={0.08}
                  dot={false}
                  activeDot={{ r: 4, stroke: "#fff", strokeWidth: 2, fill: TEAL }}
                  isAnimationActive={!reduceMotion}
                  animationDuration={350}
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center px-4">
            <Wallet className="w-8 h-8 text-slate-300 mb-2" />
            <p className="text-[14px] font-semibold text-slate-700">Sem movimentos nos últimos {periodLabel}</p>
            <p className="text-[13px] text-slate-500 mt-1 max-w-[260px]">
              Faça um depósito ou conclua tarefas e o fluxo da carteira aparece aqui.
            </p>
            {onOpenDeposit && (
              <button
                type="button"
                onClick={onOpenDeposit}
                className="mt-3 min-h-[44px] px-4 rounded-xl bg-teal-700 text-white text-[13px] font-semibold pressable"
              >
                Depositar
              </button>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between mt-1">
        {mode === "flow" ? (
          <div className="flex items-center gap-3 text-[12px] text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: TEAL }} /> Entradas
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: ROSE }} /> Saídas
            </span>
          </div>
        ) : (
          <span className="text-[12px] text-slate-500">Saldo disponível ao fim de cada {period === 90 ? "semana" : "dia"}</span>
        )}
        {source === "local" && <span className="text-[11px] text-slate-400">Últimos movimentos carregados</span>}
      </div>
    </div>
  );
};

export default WalletFlowChart;
