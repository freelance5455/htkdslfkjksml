import React, { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Layers, PlusCircle, PlayCircle, History } from "@/components/icons";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SectionSkeleton } from "@/components/ui/section-skeleton";
import { CampaignRequestModal } from "./CampaignRequestModal";
import { toast } from "sonner";

interface UserCampaignsHubProps {
  userId: string;
  onNeedDeposit?: () => void;
}

export const UserCampaignsSection: React.FC<UserCampaignsHubProps & { active?: boolean }> = ({ userId, onNeedDeposit, active = true }) => {
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"online" | "historico">("online");
  const [onlineCampaigns, setOnlineCampaigns] = useState<any[]>([]);
  const [completedCampaigns, setCompletedCampaigns] = useState<any[]>([]);
  const [userRequests, setUserRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  // Minhas participações (campaign_id → estado) e total já recebido por campanha
  const [myParts, setMyParts] = useState<Record<string, string>>({});
  const [paidByCampaign, setPaidByCampaign] = useState<Record<string, number>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  const hasLoaded = useRef(false);
  const loadData = async () => {
    if (!userId) return;
    if (!hasLoaded.current) setLoading(true);
    try {
      // Carregar campanhas ativas/online
      const { data: activeData } = await supabase
        .from("campaigns")
        .select("*")
        .eq("status", "ACTIVE")
        .order("created_at", { ascending: false });

      setOnlineCampaigns(activeData || []);

      // Simular histórico ou buscar campanhas finalizadas
      const { data: compData } = await supabase
        .from("campaigns")
        .select("*")
        .in("status", ["COMPLETED", "ended"])
        .order("created_at", { ascending: false });

      setCompletedCampaigns(compData || []);

      // Minhas participações e pagamentos recebidos por resultado
      const [partsRes, paidRes] = await Promise.all([
        supabase.from("campaign_assignments").select("campaign_id, status").eq("user_id", userId),
        supabase.from("campaign_result_payouts").select("campaign_id, amount_aoa").eq("user_id", userId),
      ]);
      const parts: Record<string, string> = {};
      (partsRes.data || []).forEach((a: any) => { parts[a.campaign_id] = a.status; });
      setMyParts(parts);
      const paid: Record<string, number> = {};
      (paidRes.data || []).forEach((r: any) => { paid[r.campaign_id] = (paid[r.campaign_id] || 0) + Number(r.amount_aoa); });
      setPaidByCampaign(paid);

      // Minhas solicitações
      const { data: reqData } = await supabase
        .from("campaign_requests")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });

      setUserRequests(reqData || []);
    } catch (err) {
      console.error("Erro ao carregar dados de campanhas:", err);
    } finally {
      hasLoaded.current = true;
      setLoading(false);
    }
  };

  const handleJoin = async (camp: any) => {
    setBusyId(camp.id);
    try {
      const { error } = await supabase.rpc("join_campaign", { p_campaign_id: camp.id });
      if (error) throw error;
      setMyParts((prev) => ({ ...prev, [camp.id]: prev[camp.id] || "IN_PROGRESS" }));
      if (camp.target_url) window.open(camp.target_url, "_blank");
      toast.success("Participação registada. Faça a acção pedida e toque em “Concluí”.");
    } catch (err: any) {
      toast.error(err?.message || "Não foi possível participar.");
    } finally {
      setBusyId(null);
    }
  };

  const handleDone = async (camp: any) => {
    setBusyId(camp.id);
    try {
      const { error } = await supabase.rpc("complete_campaign_participation", { p_campaign_id: camp.id });
      if (error) throw error;
      setMyParts((prev) => ({ ...prev, [camp.id]: "COMPLETED" }));
      toast.success("Marcada como concluída. Será paga quando a campanha tiver resultado financeiro.");
    } catch (err: any) {
      toast.error(err?.message || "Não foi possível concluir.");
    } finally {
      setBusyId(null);
    }
  };

  useEffect(() => {
    if (active) loadData();
  }, [userId, active]);

  if (loading) return <SectionSkeleton rows={4} />;

  return (
    <div className="space-y-5 pb-12">
      {/* HEADER NATIVO APP */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-slate-900 tracking-tight">Campanhas</h1>
          <p className="text-[13px] text-slate-500">Engajamento sincronizado em rede</p>
        </div>
        <Button
          onClick={() => setIsRequestModalOpen(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-10 px-4 rounded-2xl shadow-md gap-1.5"
        >
          <PlusCircle className="w-4 h-4" />
          Nova Campanha (10$)
        </Button>
      </div>

      {/* TABS NATIVAS APP (ONLINE vs HISTÓRICO) */}
      <div className="bg-slate-100 p-1 rounded-2xl flex gap-1">
        <button
          onClick={() => setActiveTab("online")}
          className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${
            activeTab === "online"
              ? "bg-white text-slate-900 shadow-sm"
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <PlayCircle className="w-4 h-4 text-emerald-600" />
          Campanhas Online ({onlineCampaigns.length})
        </button>
        <button
          onClick={() => setActiveTab("historico")}
          className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${
            activeTab === "historico"
              ? "bg-white text-slate-900 shadow-sm"
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <History className="w-4 h-4 text-slate-400" />
          Histórico / Concluídas ({completedCampaigns.length})
        </button>
      </div>

      {/* CONTEÚDO DA ABA ATIVA */}
      {activeTab === "online" ? (
        <div className="space-y-3">
          {onlineCampaigns.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-slate-200/80 shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <Layers className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-slate-800 tracking-tight">Nenhuma campanha online neste momento</p>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                As campanhas ativas aparecerão aqui para interações e recompensas coletivas.
              </p>
              <Button
                onClick={() => setIsRequestModalOpen(true)}
                variant="outline"
                className="h-10 px-4 rounded-xl text-xs font-bold border-slate-200 mt-2"
              >
                Criar a primeira campanha
              </Button>
            </div>
          ) : (
            onlineCampaigns.map((camp) => (
              <div key={camp.id} className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <Badge className="bg-emerald-50 text-emerald-700 border-none text-[11px] font-semibold mb-1.5">
                      {camp.platform || "Plataforma"}
                    </Badge>
                    <h3 className="text-xs font-bold text-slate-900">{camp.title}</h3>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl text-right leading-tight">
                    {paidByCampaign[camp.id]
                      ? `Recebeu ${Math.round(paidByCampaign[camp.id]).toLocaleString("pt-PT")} Kz`
                      : "Partilha dos resultados"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 line-clamp-2 font-medium">{camp.description}</p>
                <p className="text-[11px] text-slate-400">
                  {camp.campaign_type === "affiliate"
                    ? "Só é paga quando a campanha gera resultado financeiro: a receita é partilhada por todos os participantes que concluírem."
                    : "Só é paga quando há resultado financeiro: a partilha é dividida em partes iguais por todos os participantes que concluírem."}
                </p>
                <div className="pt-2 border-t border-slate-50 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-400 font-semibold">
                    {myParts[camp.id] === "COMPLETED"
                      ? "Concluída ✓ — a aguardar resultado"
                      : myParts[camp.id] === "IN_PROGRESS" || myParts[camp.id] === "ASSIGNED"
                        ? "Em curso"
                        : "Ativa na rede"}
                  </span>
                  {myParts[camp.id] === "COMPLETED" ? (
                    <Button size="sm" variant="outline" className="font-semibold text-[11px] h-11 rounded-xl px-4"
                      onClick={() => window.open(camp.target_url, "_blank")}>
                      Abrir link
                    </Button>
                  ) : myParts[camp.id] === "IN_PROGRESS" || myParts[camp.id] === "ASSIGNED" ? (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="font-semibold text-[11px] h-11 rounded-xl px-3"
                        onClick={() => window.open(camp.target_url, "_blank")}>
                        Abrir link
                      </Button>
                      <Button size="sm" disabled={busyId === camp.id}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] h-11 rounded-xl px-4"
                        onClick={() => handleDone(camp)}>
                        Concluí
                      </Button>
                    </div>
                  ) : (
                    <Button size="sm" disabled={busyId === camp.id}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-[11px] h-11 rounded-xl px-4"
                      onClick={() => handleJoin(camp)}>
                      Participar
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {completedCampaigns.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-slate-200/80 shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-50 text-slate-400 flex items-center justify-center mx-auto">
                <History className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-slate-800 tracking-tight">Sem histórico de campanhas concluídas</p>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                As campanhas que já atingiram as metas e encerraram serão listadas aqui como arquivo.
              </p>
            </div>
          ) : (
            completedCampaigns.map((camp) => (
              <div key={camp.id} className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm opacity-75 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">{camp.title}</span>
                  <Badge className="bg-slate-100 text-slate-500 border-none text-[11px] font-semibold ">
                    Concluída
                  </Badge>
                </div>
                <p className="text-[11px] text-slate-400">{camp.description}</p>
              </div>
            ))
          )}
        </div>
      )}

      {/* MINHAS SOLICITAÇÕES PENDENTES OU APROVADAS */}
      {userRequests.length > 0 && (
        <div className="space-y-3 pt-4">
          <h3 className="text-xs font-bold text-slate-400 px-1">Minhas Propostas Submetidas</h3>
          <div className="space-y-2">
            {userRequests.map((req) => (
              <div key={req.id} className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-900 block">{req.title}</span>
                  <span className="text-[11px] text-slate-400 font-semibold ">{new Date(req.created_at).toLocaleDateString()}</span>
                </div>
                <Badge className={
                  req.status === "APPROVED" || req.status === "aprovada" ? "bg-emerald-50 text-emerald-600 border-none text-[11px] font-semibold" :
                  req.status === "REJECTED" || req.status === "rejeitada" ? "bg-rose-50 text-rose-500 border-none text-[11px] font-semibold" :
                  "bg-amber-50 text-amber-600 border-none text-[11px] font-semibold"
                }>
                  {req.status.toUpperCase()}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal de Solicitação */}
      <CampaignRequestModal
        isOpen={isRequestModalOpen}
        onClose={() => setIsRequestModalOpen(false)}
        onSuccess={loadData}
        userId={userId}
        onNeedDeposit={onNeedDeposit}
      />
    </div>
  );
};
