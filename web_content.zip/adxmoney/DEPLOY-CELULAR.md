# Deploy a partir do telemóvel

Tudo o que precisa está neste ZIP. A compilação acontece na **Vercel** (na nuvem), por isso não precisa de computador.

## A. Preparar o Termux (só uma vez)
1. Instale o **Termux** pela F-Droid (a versão da Play Store está desatualizada).
2. Abra o Termux e corra:
   ```
   pkg update -y && pkg install -y nodejs unzip
   termux-setup-storage
   ```
   (aceite a permissão de armazenamento)
3. Opcional, para copiar SQL direto para a área de transferência: `pkg install -y termux-api` e instale a app **Termux:API**.
4. Crie um token na Vercel: https://vercel.com/account/tokens → *Create Token* (guarde-o; o script pede-o uma vez).

## B. Base de dados (Supabase → SQL Editor)
Execute **um ficheiro de cada vez**, nesta ordem (salte os que já executou sem erro):

`018` → `019` → `020` → `021` → `022` → `023` → `024` → `025` → `026` → `027` → `028` → `029` → `030` → `031` → `032` → `033` → `VERIFY`

Para copiar cada ficheiro:
```
cd ~/adxmoney
bash sql.sh 027
```
Depois abra o SQL Editor, cole e carregue em **Run**. Repita com `018`, `019`… e no fim `bash sql.sh VERIFY`.

No `VERIFY`, **todas as linhas devem ter `ok = true`**. Se alguma vier `false`, envie-me o nome da linha.

## C. Publicar a app (sempre que receber um ZIP novo)
1. Descarregue o ZIP para o telemóvel (fica em Transferências).
2. No Termux:
   ```
   cd ~ && rm -rf adxmoney && unzip -o ~/storage/downloads/Adxmoney-v7-personalizado-18.zip
   cd adxmoney && bash deploy.sh
   ```
3. Na 1.ª vez: cole o token e confirme o nome do projeto (por defeito `adxmoneyv9`). Se o projeto estiver numa equipa da Vercel, corra antes `export VERCEL_SCOPE=nome-da-equipa`.
4. No fim aparece o endereço de produção. Se a compilação falhar, o erro aparece no próprio ecrã: **envie-me o texto**.

## D. Edge Functions (Supabase → Edge Functions)
**Três funções** têm de ser publicadas/republicadas:
- `public-register` (registo robusto + aceitação dos termos obrigatória)
- `admin-delete-user` (contas com histórico financeiro são desativadas, não apagadas)
- `admin-reset-password` (**nova**: o admin redefine a palavra-passe de um utilizador). Em Edge Functions → *Deploy a new function* → nome `admin-reset-password` → `bash fn.sh admin-reset-password` e cole o código.

Para cada uma: `bash fn.sh <nome>`; exemplo: `bash fn.sh public-register` → no Supabase abra **Edge Functions → public-register → Code**, cole (substituindo tudo) e carregue em **Deploy**. Repita com `bash fn.sh admin-delete-user`.

Confirme ainda:
- Em **`public-register` → Settings**, **Enforce JWT Verification** deve estar **desligada** (o registo é feito sem sessão). O `supabase/config.toml` só vale para quem usa a CLI.
- **CAPTCHA (opcional, recomendado):** crie um widget em Cloudflare Turnstile; ponha a *site key* na Vercel (`VITE_TURNSTILE_SITE_KEY`) e a *secret key* nos Secrets do Supabase (`TURNSTILE_SECRET_KEY`). Enquanto o segredo não existir, o registo funciona sem CAPTCHA.
- Limites da IA por utilizador (opcional): secrets `AI_HOURLY_LIMIT` e `AI_DAILY_LIMIT` (por defeito, 20/60 no coach e no suporte; 10/30 no gerador).
- Em **Edge Functions → Secrets**, existe `GROQ_API_KEY` (funções de IA). Opcional: `REGISTER_GLOBAL_HOURLY_CAP` (teto de registos por hora; por defeito 300).

## E. Antes de abrir ao público (dinheiro real)
- Em **Admin → Definições → Economia**, confirme **Saques: exigir aprovação antes de pagar = 1** (o admin primeiro toca em *Aprovar*, depois em *Pagar*).
- Execute `RECONCILE.sql` na base real (compara saldos com movimentos) e confirme que o `VERIFY` não tem nenhuma linha `false`.

## F. Testes financeiros automáticos (recomendado antes de abrir ao público)
```
bash sql.sh TESTES
```
Cole no SQL Editor e carregue em **Run**. O script **não grava nada**: termina sempre com um erro propositado, **"RESULTADO DOS TESTES: X de Y passaram"**, seguido da lista ✅/❌. Envie-me as linhas ❌. Se possível, corra primeiro num projeto Supabase de teste (staging).

### Testes de concorrência (pedidos em simultâneo) — só num projeto Supabase de TESTE
```
export SUPABASE_URL="https://xxxx.supabase.co"
export SUPABASE_ANON_KEY="..."
export SUPABASE_SERVICE_KEY="..."      # chave secreta/service_role do projeto de TESTE
export CONFIRMO_STAGING=sim
node scripts/teste-concorrencia.mjs
```
Dispara 12 pedidos em paralelo e confirma que o dinheiro só mexe uma vez (depósito, assinatura, saque, duplo gasto, resultado de campanha, registo). **Nunca em produção**: cria contas de teste que, pela proteção do histórico, não se apagam facilmente.

## G. Teste rápido (3 contas)
1. **Admin** → Definições → Economia: confira os valores (assinatura 4.900 Kz / 6 meses, comissões, partilha).
2. **Utilizador A** (afiliado, assinatura ativa) copia o seu código de convite.
3. **Utilizador B** regista-se com esse código, faz o primeiro login e **paga a assinatura** (envia comprovativo).
4. **Admin** aprova a assinatura → confirme: B fica ativo com validade de 6 meses e recebe o bónus; A recebe 20% (980 Kz) na carteira.
5. **Admin** → Campanhas → crie uma campanha, B participa e toca "Concluí" → no admin, botão **Resultado** → introduza um valor → o pagamento é repartido pelos participantes.
6. Navegue por todas as secções e use o botão **voltar** do telemóvel: deve voltar à secção anterior, e cada janela fecha no X.

## H. Primeiro administrador
Registe uma conta normal na app e, no SQL Editor, promova-a (a guarda do perfil exige esta forma):
```
BEGIN;
SELECT set_config('app.skip_profile_guard', 'on', true);
UPDATE public.profiles SET role = 'admin' WHERE email = 'O-SEU-EMAIL';
COMMIT;
```
Depois, os restantes operadores criam-se no painel (*Criar operador*).

## I. Ambiente de teste separado (recomendado)
1. Crie um 2.º projeto Supabase só para testes e aplique nele as migrações 014–028 (para um projeto vazio, 001–013 primeiro).
2. Na Vercel → Settings → Environment Variables, no ambiente **Preview**, defina `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY` (ver `.env.example`).
3. Os deploys de teste usam o projeto de teste; o de produção continua no projeto real.

## J. Lista de verificação antes de testar
- [ ] `VERIFY.sql` sem nenhuma linha `false`
- [ ] Edge Functions `public-register` e `admin-delete-user` republicadas; *Enforce JWT* desligado em `public-register`
- [ ] Deploy da Vercel concluído sem erros
- [ ] Existe um administrador (secção H)
- [ ] Em Definições → Economia: saques exigem aprovação = 1

