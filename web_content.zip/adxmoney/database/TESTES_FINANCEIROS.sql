-- ====================================================================
-- TESTES_FINANCEIROS.sql — cenários financeiros e de segurança
-- Executar DEPOIS das migrações 014–029 (SQL Editor do Supabase, um único Run).
--
-- NÃO GRAVA NADA: todo o teste corre numa transação e termina SEMPRE com um erro propositado
-- ("RESULTADO DOS TESTES"), que desfaz tudo (utilizadores, carteiras, campanhas de teste).
-- O relatório aparece na mensagem desse erro: ✅ passou · ❌ falhou.
--
-- Cobre: assinatura (preço, validade 6 meses, dupla aprovação, renovação, expiração), comissões
-- (valor, idempotência, afiliado inativo, recuperação de falhas), depósitos, saques (dois passos,
-- estorno), campanhas (partilha, idempotência, confirmação), segurança (saldo, admin, RLS,
-- funções internas), proteção de histórico ao eliminar contas, troca de seguidores e
-- reconciliação saldo = soma dos movimentos.
-- Limite: um único utilizador de base de dados; testes de concorrência real (dois pedidos
-- em simultâneo) não são possíveis aqui.
-- ====================================================================

CREATE TEMP TABLE IF NOT EXISTS _t (n SERIAL, name TEXT, ok BOOLEAN, info TEXT);
TRUNCATE _t;

CREATE OR REPLACE FUNCTION pg_temp.chk(p_name TEXT, p_ok BOOLEAN, p_info TEXT DEFAULT '')
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO _t (name, ok, info) VALUES (p_name, COALESCE(p_ok, false), COALESCE(p_info, ''));
END $$;

CREATE OR REPLACE FUNCTION pg_temp.as_user(p_uid UUID)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  PERFORM set_config('request.jwt.claim.sub', p_uid::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM set_config('request.jwt.claims',
    json_build_object('sub', p_uid, 'role', 'authenticated')::text, true);
END $$;

CREATE OR REPLACE FUNCTION pg_temp.guard(p_on BOOLEAN)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  PERFORM set_config('app.skip_profile_guard', CASE WHEN p_on THEN 'on' ELSE 'off' END, true);
END $$;

CREATE OR REPLACE FUNCTION pg_temp.mk_user(p_label TEXT, p_meta JSONB DEFAULT '{}'::jsonb)
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE v UUID := gen_random_uuid();
BEGIN
  INSERT INTO auth.users (id, instance_id, aud, role, email, email_confirmed_at,
                          raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  VALUES (v, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
          'teste_' || p_label || '_' || substr(v::text, 1, 8) || '@exemplo.invalid', now(),
          '{"provider":"email"}'::jsonb,
          p_meta || jsonb_build_object('name', 'Teste ' || p_label), now(), now());
  RETURN v;
END $$;

-- estado de assinatura sem passar pela guarda do perfil (setup do teste)
CREATE OR REPLACE FUNCTION pg_temp.set_sub(p_uid UUID, p_status TEXT, p_days INTEGER)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  PERFORM pg_temp.guard(true);
  UPDATE public.profiles
  SET subscription_status = p_status,
      subscription_expires_at = now() + (p_days || ' days')::interval
  WHERE id = p_uid;
  PERFORM pg_temp.guard(false);
END $$;

CREATE OR REPLACE FUNCTION pg_temp.bal(p_uid UUID)
RETURNS NUMERIC LANGUAGE sql AS $$
  SELECT balance FROM public.wallets WHERE user_id = p_uid;
$$;

-- espera que o SQL FALHE (opcionalmente como um papel de base de dados e com um texto no erro)
CREATE OR REPLACE FUNCTION pg_temp.expect_fail(
  p_name TEXT, p_sql TEXT, p_role TEXT DEFAULT NULL, p_must_contain TEXT DEFAULT NULL)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  IF p_role IS NOT NULL THEN EXECUTE 'SET LOCAL ROLE ' || quote_ident(p_role); END IF;
  EXECUTE p_sql;
  IF p_role IS NOT NULL THEN EXECUTE 'RESET ROLE'; END IF;
  PERFORM pg_temp.chk(p_name, false, 'NÃO falhou (devia ter sido bloqueado)');
EXCEPTION WHEN OTHERS THEN
  PERFORM pg_temp.chk(p_name,
    p_must_contain IS NULL OR EXISTS (
      SELECT 1 FROM unnest(string_to_array(p_must_contain, '|')) AS alt
      WHERE SQLERRM ILIKE '%' || alt || '%'),
    'erro: ' || left(SQLERRM, 160));
END $$;

-- executa como papel de base de dados e devolve o erro (ou NULL se correu)
CREATE OR REPLACE FUNCTION pg_temp.try_as(p_role TEXT, p_sql TEXT)
RETURNS TEXT LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE 'SET LOCAL ROLE ' || quote_ident(p_role);
  EXECUTE p_sql;
  EXECUTE 'RESET ROLE';
  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RETURN SQLERRM;
END $$;

-- conta linhas visíveis para um papel (RLS); -1 se o acesso foi negado
CREATE OR REPLACE FUNCTION pg_temp.count_as(p_role TEXT, p_sql TEXT)
RETURNS BIGINT LANGUAGE plpgsql AS $$
DECLARE v BIGINT;
BEGIN
  EXECUTE 'SET LOCAL ROLE ' || quote_ident(p_role);
  EXECUTE p_sql INTO v;
  EXECUTE 'RESET ROLE';
  RETURN v;
EXCEPTION WHEN OTHERS THEN
  RETURN -1;
END $$;

DO $test$
DECLARE
  v_adm UUID; v_a UUID; v_b UUID; v_c UUID; v_p1 UUID; v_p2 UUID; v_n UUID; v_e UUID;
  v_z UUID; v_m UUID; v_l1 UUID; v_l2 UUID;
  v_pay UUID; v_pay2 UUID; v_dep UUID; v_dep2 UUID; v_w UUID; v_w2 UUID; v_w3 UUID; v_w4 UUID;
  v_camp UUID; v_camp2 UUID; v_camp3 UUID;
  v_res JSONB; v_err TEXT; v_cnt BIGINT; v_bal0 NUMERIC; v_txt TEXT;
  v_ok INTEGER; v_total INTEGER; v_report TEXT; r RECORD;
BEGIN
  ------------------------------------------------------------------
  -- 0) SETUP
  ------------------------------------------------------------------
  BEGIN
    v_adm := pg_temp.mk_user('admin');
    v_a   := pg_temp.mk_user('afiliado');
    v_b   := pg_temp.mk_user('indicado');
    v_c   := pg_temp.mk_user('visitante');
    v_p1  := pg_temp.mk_user('part1');
    v_p2  := pg_temp.mk_user('part2');
    v_n   := pg_temp.mk_user('semlink');
    v_e   := pg_temp.mk_user('expirado');
    v_z   := pg_temp.mk_user('apagavel');
    v_m   := pg_temp.mk_user('meta', '{"role":"admin"}'::jsonb);
    v_l1  := pg_temp.mk_user('troca1');
    v_l2  := pg_temp.mk_user('troca2');

    PERFORM pg_temp.guard(true);
    UPDATE public.profiles SET role = 'admin' WHERE id = v_adm;
    PERFORM pg_temp.guard(false);

    PERFORM pg_temp.chk('Setup: 12 utilizadores de teste criados com perfil e carteira',
      (SELECT count(*) FROM public.profiles WHERE id IN
        (v_adm, v_a, v_b, v_c, v_p1, v_p2, v_n, v_e, v_z, v_m, v_l1, v_l2)) = 12
      AND (SELECT count(*) FROM public.wallets WHERE user_id IN
        (v_adm, v_a, v_b, v_c, v_p1, v_p2, v_n, v_e, v_z, v_m, v_l1, v_l2)) = 12);

    PERFORM pg_temp.chk('Registo com role=admin nos metadados NÃO cria administrador',
      (SELECT role FROM public.profiles WHERE id = v_m) = 'user');

    -- economia no estado de fábrica, para os valores esperados
    UPDATE public.economy_settings SET value = 4900 WHERE key = 'subscription_price_aoa';
    UPDATE public.economy_settings SET value = 6 WHERE key = 'subscription_months';
    UPDATE public.economy_settings SET value = 20 WHERE key = 'aff_subscription_pct';
    UPDATE public.economy_settings SET value = 10 WHERE key = 'aff_subscription_renewal_pct';
    UPDATE public.economy_settings SET value = 250 WHERE key = 'referred_bonus_aoa';
    UPDATE public.economy_settings SET value = 50 WHERE key = 'pool_pct_collective';
    UPDATE public.economy_settings SET value = 60 WHERE key = 'pool_pct_affiliate';
    INSERT INTO public.economy_settings (key, value, label)
      VALUES ('withdrawal_require_approval', 1, 'teste')
      ON CONFLICT (key) DO UPDATE SET value = 1;
    INSERT INTO public.economy_settings (key, value, label) VALUES
      ('withdrawal_max_per_request_aoa', 100000, 'teste'),
      ('withdrawal_max_daily_per_user_aoa', 150000, 'teste'),
      ('withdrawal_global_daily_cap_aoa', 2000000, 'teste')
      ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

    -- afiliado ativo + indicado com convite pendente
    INSERT INTO public.affiliate_profiles (user_id, affiliate_code)
      VALUES (v_a, 'TA' || substr(v_a::text, 1, 6))
      ON CONFLICT (user_id) DO UPDATE SET affiliate_code = EXCLUDED.affiliate_code;
    PERFORM pg_temp.set_sub(v_a, 'active', 200);
    PERFORM pg_temp.guard(true);
    UPDATE public.profiles SET invited_by = v_a WHERE id = v_b;
    PERFORM pg_temp.guard(false);
    INSERT INTO public.affiliate_referrals
      (affiliate_user_id, referred_user_id, affiliate_code, bonus_user, commission_affiliate, status)
      VALUES (v_a, v_b, 'TESTE', 250, 0, 'PENDING');
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('SETUP abortou (os testes seguintes podem falhar por causa disto)', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 1) ASSINATURA E COMISSÕES
  ------------------------------------------------------------------
  BEGIN
    PERFORM pg_temp.as_user(v_b);
    v_res := public.submit_subscription_payment(1, 'AOA', 'EXPRESS', v_b::text || '/comprovativo.png', NULL);
    v_pay := (v_res->>'payment_id')::uuid;
    PERFORM pg_temp.chk('Assinatura: preço é do servidor (4.900 Kz; ignora o valor enviado pelo cliente)',
      (v_res->>'amount')::numeric = 4900, v_res::text);
    PERFORM pg_temp.chk('Assinatura: estado do utilizador passa a pending',
      (SELECT subscription_status FROM public.profiles WHERE id = v_b) = 'pending');

    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_subscription_payment(v_pay, 'APPROVED', NULL);
    PERFORM pg_temp.guard(false);

    PERFORM pg_temp.chk('Aprovação: utilizador fica ativo',
      (SELECT subscription_status FROM public.profiles WHERE id = v_b) = 'active');
    PERFORM pg_temp.chk('Aprovação: validade ≈ 6 meses',
      (SELECT subscription_expires_at FROM public.profiles WHERE id = v_b)
        BETWEEN now() + interval '178 days' AND now() + interval '186 days',
      (SELECT subscription_expires_at::text FROM public.profiles WHERE id = v_b));

    PERFORM pg_temp.expect_fail('Aprovar a MESMA assinatura duas vezes é bloqueado',
      format('SELECT public.admin_process_subscription_payment(%L, ''APPROVED'', NULL)', v_pay),
      NULL, 'processado');

    PERFORM pg_temp.chk('Comissão do afiliado: 20% de 4.900 = 980 Kz na carteira',
      pg_temp.bal(v_a) = 980, 'saldo=' || pg_temp.bal(v_a));
    PERFORM pg_temp.chk('Comissão: exatamente 1 registo e 1 movimento no ledger',
      (SELECT count(*) FROM public.affiliate_commissions WHERE affiliate_user_id = v_a) = 1
      AND (SELECT count(*) FROM public.wallet_transactions
           WHERE user_id = v_a AND type = 'AFFILIATE_COMMISSION') = 1);

    PERFORM public._pay_affiliate_commission(v_b, 'SUBSCRIPTION', v_pay, 4900, 20);
    PERFORM pg_temp.chk('Comissão repetida para a mesma origem NÃO paga duas vezes',
      pg_temp.bal(v_a) = 980, 'saldo=' || pg_temp.bal(v_a));

    PERFORM pg_temp.chk('Bónus do indicado (250 Kz) creditado só ao ativar a assinatura',
      pg_temp.bal(v_b) = 250
      AND (SELECT status FROM public.affiliate_referrals WHERE referred_user_id = v_b) = 'COMPLETED'
      AND (SELECT referred_completed FROM public.profiles WHERE id = v_b) = true,
      'saldo B=' || pg_temp.bal(v_b));

    -- renovação
    PERFORM pg_temp.set_sub(v_b, 'active', 100);
    PERFORM pg_temp.as_user(v_b);
    PERFORM pg_temp.expect_fail('Renovar com 100 dias de validade (fora da janela de 30) é bloqueado',
      format('SELECT public.submit_subscription_payment(1, ''AOA'', ''EXPRESS'', %L, NULL)', v_b::text || '/r.png'),
      NULL, 'activa');

    PERFORM pg_temp.set_sub(v_b, 'active', 10);
    PERFORM pg_temp.as_user(v_b);
    v_res := public.submit_subscription_payment(1, 'AOA', 'EXPRESS', v_b::text || '/r2.png', NULL);
    v_pay2 := (v_res->>'payment_id')::uuid;
    PERFORM pg_temp.chk('Renovação: não tira o acesso enquanto o pagamento é validado',
      (SELECT subscription_status FROM public.profiles WHERE id = v_b) = 'active'
      AND (v_res->>'renewal')::boolean = true);

    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_subscription_payment(v_pay2, 'APPROVED', NULL);
    PERFORM pg_temp.guard(false);
    PERFORM pg_temp.chk('Renovação: soma 6 meses aos dias que ainda restavam (> 188 dias)',
      (SELECT subscription_expires_at FROM public.profiles WHERE id = v_b) > now() + interval '188 days',
      (SELECT subscription_expires_at::text FROM public.profiles WHERE id = v_b));
    PERFORM pg_temp.chk('Renovação: comissão de 10% (490 Kz) → afiliado com 1.470 Kz',
      pg_temp.bal(v_a) = 1470, 'saldo A=' || pg_temp.bal(v_a));

    -- expiração
    PERFORM pg_temp.set_sub(v_a, 'active', -1);
    PERFORM public.expire_subscriptions();
    PERFORM pg_temp.chk('Assinatura vencida passa a expired',
      (SELECT subscription_status FROM public.profiles WHERE id = v_a) = 'expired');
    PERFORM pg_temp.chk('Assinante expirado deixa de contar como ativo', NOT public._is_active_subscriber(v_a));

    -- afiliado sem assinatura ativa não recebe
    PERFORM pg_temp.set_sub(v_b, 'expired', -1);
    PERFORM pg_temp.as_user(v_b);
    v_res := public.submit_subscription_payment(1, 'AOA', 'EXPRESS', v_b::text || '/r3.png', NULL);
    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_subscription_payment((v_res->>'payment_id')::uuid, 'APPROVED', NULL);
    PERFORM pg_temp.guard(false);
    PERFORM pg_temp.chk('Afiliado SEM assinatura ativa não recebe comissão',
      pg_temp.bal(v_a) = 1470
      AND (SELECT count(*) FROM public.affiliate_commissions WHERE affiliate_user_id = v_a) = 2,
      'saldo A=' || pg_temp.bal(v_a));

    -- recuperação de comissão falhada
    PERFORM pg_temp.set_sub(v_a, 'active', 200);
    INSERT INTO public.affiliate_commission_failures
      (referred_user_id, source_type, source_id, base_amount_aoa, pct, error)
      VALUES (v_b, 'ENGAGEMENT_ORDER', gen_random_uuid(), 10000, 10, 'falha simulada');
    PERFORM pg_temp.as_user(v_adm);
    v_res := public.admin_retry_commission_failures();
    PERFORM pg_temp.chk('Reprocessar comissão falhada paga 10% de 10.000 = 1.000 Kz (saldo 2.470)',
      pg_temp.bal(v_a) = 2470 AND (v_res->>'resolved')::int = 1,
      'saldo A=' || pg_temp.bal(v_a) || ' ' || v_res::text);
    v_res := public.admin_retry_commission_failures();
    PERFORM pg_temp.chk('Reprocessar de novo NÃO paga outra vez',
      pg_temp.bal(v_a) = 2470 AND (v_res->>'resolved')::int = 0, 'saldo A=' || pg_temp.bal(v_a));
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Assinatura/Comissões abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 2) DEPÓSITOS
  ------------------------------------------------------------------
  BEGIN
    PERFORM pg_temp.as_user(v_b);
    v_res := public.submit_wallet_deposit(5000, 'AOA', 'EXPRESS', 'deposits/' || v_b::text || '/p.png');
    v_dep := (v_res->>'id')::uuid;
    v_bal0 := pg_temp.bal(v_b);

    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_wallet_deposit(v_dep, 'APPROVED', NULL);
    PERFORM pg_temp.chk('Depósito aprovado credita uma vez (+5.000)',
      pg_temp.bal(v_b) = v_bal0 + 5000, 'antes=' || v_bal0 || ' depois=' || pg_temp.bal(v_b));
    PERFORM pg_temp.expect_fail('Aprovar o MESMO depósito duas vezes é bloqueado',
      format('SELECT public.admin_process_wallet_deposit(%L, ''APPROVED'', NULL)', v_dep), NULL, 'processado');
    PERFORM pg_temp.chk('Depósito: saldo não mudou na 2.ª tentativa; 1 movimento DEPOSIT',
      pg_temp.bal(v_b) = v_bal0 + 5000
      AND (SELECT count(*) FROM public.wallet_transactions WHERE user_id = v_b AND type = 'DEPOSIT') = 1);

    PERFORM pg_temp.as_user(v_b);
    v_res := public.submit_wallet_deposit(2000, 'AOA', 'EXPRESS', 'deposits/' || v_b::text || '/q.png');
    v_dep2 := (v_res->>'id')::uuid;
    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_wallet_deposit(v_dep2, 'REJECTED', 'teste');
    PERFORM pg_temp.chk('Depósito rejeitado não credita', pg_temp.bal(v_b) = v_bal0 + 5000);
    PERFORM pg_temp.expect_fail('Aprovar depósito já rejeitado é bloqueado',
      format('SELECT public.admin_process_wallet_deposit(%L, ''APPROVED'', NULL)', v_dep2), NULL, 'processado');
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Depósitos abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 3) SAQUES
  ------------------------------------------------------------------
  BEGIN
    v_bal0 := pg_temp.bal(v_b);                       -- 5.250
    PERFORM pg_temp.as_user(v_b);
    PERFORM pg_temp.expect_fail('Saque abaixo do mínimo (500 Kz) é recusado',
      'SELECT public.request_withdrawal(500, ''EXPRESS'', ''{"c":"1"}''::jsonb)', NULL, 'mínimo');
    PERFORM pg_temp.expect_fail('Saque acima do saldo é recusado',
      'SELECT public.request_withdrawal(90000, ''EXPRESS'', ''{"c":"1"}''::jsonb)', NULL, 'insuficiente');
    PERFORM pg_temp.expect_fail('Saque acima do máximo por pedido (100.000 Kz) é recusado',
      'SELECT public.request_withdrawal(100001, ''EXPRESS'', ''{"c":"1"}''::jsonb)', NULL, 'máximo');

    v_res := public.request_withdrawal(2000, 'EXPRESS', '{"conta":"123"}'::jsonb);
    v_w := (v_res->>'withdrawal_id')::uuid;
    PERFORM pg_temp.chk('Saque: 2.000 saem do saldo e ficam reservados',
      pg_temp.bal(v_b) = v_bal0 - 2000
      AND (SELECT reserved_balance FROM public.wallets WHERE user_id = v_b) = 2000);

    PERFORM pg_temp.as_user(v_adm);
    PERFORM pg_temp.expect_fail('Dois passos: pagar saque PENDING sem aprovar é bloqueado (na base de dados)',
      format('SELECT public.admin_process_withdrawal(%L, ''PAID'', NULL)', v_w), NULL, 'Aprove');
    PERFORM public.admin_process_withdrawal(v_w, 'APPROVE', NULL);
    PERFORM pg_temp.expect_fail('Aprovar duas vezes o mesmo saque é bloqueado',
      format('SELECT public.admin_process_withdrawal(%L, ''APPROVE'', NULL)', v_w), NULL, 'pendentes');
    PERFORM public.admin_process_withdrawal(v_w, 'PAID', NULL);
    PERFORM pg_temp.chk('Saque pago: reserva liquidada (0) e saldo disponível intacto',
      (SELECT reserved_balance FROM public.wallets WHERE user_id = v_b) = 0
      AND pg_temp.bal(v_b) = v_bal0 - 2000);
    PERFORM pg_temp.expect_fail('Pagar o mesmo saque duas vezes é bloqueado',
      format('SELECT public.admin_process_withdrawal(%L, ''PAID'', NULL)', v_w), NULL, 'finalizado');

    -- rejeição → estorno uma única vez
    PERFORM pg_temp.as_user(v_b);
    v_res := public.request_withdrawal(1000, 'EXPRESS', '{"conta":"123"}'::jsonb);
    v_w2 := (v_res->>'withdrawal_id')::uuid;
    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_withdrawal(v_w2, 'REJECT', 'teste');
    PERFORM pg_temp.chk('Saque rejeitado: saldo devolvido uma vez',
      pg_temp.bal(v_b) = v_bal0 - 2000
      AND (SELECT reserved_balance FROM public.wallets WHERE user_id = v_b) = 0
      AND (SELECT count(*) FROM public.wallet_transactions
           WHERE user_id = v_b AND type = 'WITHDRAWAL_REFUND') = 1);
    PERFORM pg_temp.expect_fail('Rejeitar o mesmo saque duas vezes é bloqueado',
      format('SELECT public.admin_process_withdrawal(%L, ''REJECT'', ''x'')', v_w2), NULL, 'finalizado');
    PERFORM pg_temp.chk('Após rejeição repetida o saldo continua igual',
      pg_temp.bal(v_b) = v_bal0 - 2000, 'saldo=' || pg_temp.bal(v_b));

    -- opção de pagar direto (regra desligada)
    UPDATE public.economy_settings SET value = 0 WHERE key = 'withdrawal_require_approval';
    PERFORM pg_temp.as_user(v_b);
    v_res := public.request_withdrawal(1000, 'EXPRESS', '{"conta":"123"}'::jsonb);
    v_w3 := (v_res->>'withdrawal_id')::uuid;
    PERFORM pg_temp.as_user(v_adm);
    PERFORM public.admin_process_withdrawal(v_w3, 'PAID', NULL);
    PERFORM pg_temp.chk('Com a regra desligada, pagar direto a partir de PENDING funciona',
      (SELECT status FROM public.withdrawals WHERE id = v_w3) = 'PAID');
    UPDATE public.economy_settings SET value = 1 WHERE key = 'withdrawal_require_approval';

    -- tetos de risco
    UPDATE public.economy_settings SET value = 3500 WHERE key = 'withdrawal_max_daily_per_user_aoa';
    PERFORM pg_temp.as_user(v_b);
    PERFORM pg_temp.expect_fail('Teto diário por utilizador (3.500 Kz) bloqueia o saque seguinte',
      'SELECT public.request_withdrawal(1000, ''EXPRESS'', ''{"c":"1"}''::jsonb)', NULL, 'Limite diário');
    UPDATE public.economy_settings SET value = 150000 WHERE key = 'withdrawal_max_daily_per_user_aoa';
    UPDATE public.economy_settings SET value = 1 WHERE key = 'withdrawal_global_daily_cap_aoa';
    PERFORM pg_temp.expect_fail('Teto global diário da plataforma bloqueia o saque',
      'SELECT public.request_withdrawal(1000, ''EXPRESS'', ''{"c":"1"}''::jsonb)', NULL, 'plataforma');
    UPDATE public.economy_settings SET value = 2000000 WHERE key = 'withdrawal_global_daily_cap_aoa';
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Saques abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 4) CAMPANHAS
  ------------------------------------------------------------------
  BEGIN
    PERFORM pg_temp.set_sub(v_p1, 'active', 200);
    PERFORM pg_temp.set_sub(v_p2, 'active', 200);
    PERFORM pg_temp.set_sub(v_n, 'active', 200);
    PERFORM pg_temp.set_sub(v_e, 'active', 200);

    INSERT INTO public.campaigns (title, description, platform, target_url, instructions, reward_amount, status, campaign_type)
      VALUES ('Teste coletiva', 'd', 'TikTok', 'https://www.tiktok.com/@x', 'i', 150, 'ACTIVE', 'collective')
      RETURNING id INTO v_camp;
    INSERT INTO public.campaign_assignments (campaign_id, user_id, status, completed_at) VALUES
      (v_camp, v_p1, 'COMPLETED', now()), (v_camp, v_p2, 'COMPLETED', now()),
      (v_camp, v_e, 'COMPLETED', now());
    INSERT INTO public.campaign_assignments (campaign_id, user_id, status) VALUES (v_camp, v_n, 'ASSIGNED');

    -- um participante cuja assinatura expirou
    PERFORM pg_temp.set_sub(v_e, 'active', -1);
    PERFORM public.expire_subscriptions();

    PERFORM pg_temp.as_user(v_c);
    PERFORM pg_temp.expect_fail('Não-admin não consegue registar resultado de campanha',
      format('SELECT public.admin_register_campaign_result(%L, 1000, NULL, ''kc'', false)', v_camp),
      NULL, 'administradores');
    PERFORM pg_temp.expect_fail('Visitante sem assinatura não consegue participar',
      format('SELECT public.join_campaign(%L)', v_camp), NULL, 'assinatura');

    PERFORM pg_temp.as_user(v_adm);
    PERFORM pg_temp.expect_fail('Resultado de 0 Kz é recusado',
      format('SELECT public.admin_register_campaign_result(%L, 0, NULL, ''k0'', false)', v_camp), NULL, 'maior que zero');

    v_res := public.admin_register_campaign_result(v_camp, 1000, 'teste', 'k1', false);
    PERFORM pg_temp.chk('Campanha coletiva: 50% de 1.000 = 500, 2 participantes × 250 Kz',
      (v_res->>'participants')::int = 2 AND (v_res->>'per_participant_aoa')::numeric = 250, v_res::text);
    PERFORM pg_temp.chk('Só quem concluiu E tem assinatura ativa recebe (p1, p2 = 250; n e e = 0)',
      pg_temp.bal(v_p1) = 250 AND pg_temp.bal(v_p2) = 250 AND pg_temp.bal(v_n) = 0 AND pg_temp.bal(v_e) = 0,
      'p1=' || pg_temp.bal(v_p1) || ' n=' || pg_temp.bal(v_n) || ' e=' || pg_temp.bal(v_e));

    v_res := public.admin_register_campaign_result(v_camp, 1000, 'teste', 'k1', false);
    PERFORM pg_temp.chk('Mesma chave de pedido repetida: devolve o já pago, SEM pagar de novo',
      (v_res->>'duplicate')::boolean = true AND pg_temp.bal(v_p1) = 250
      AND (SELECT count(*) FROM public.campaign_results WHERE campaign_id = v_camp) = 1, v_res::text);

    PERFORM pg_temp.expect_fail('Mesmo valor sem confirmação (chave nova) pede confirmação',
      format('SELECT public.admin_register_campaign_result(%L, 1000, NULL, ''k2'', false)', v_camp),
      NULL, 'CONFIRMAR_RESULTADO_SEMELHANTE');
    PERFORM pg_temp.chk('Pedido que pediu confirmação não pagou nada', pg_temp.bal(v_p1) = 250);
    v_res := public.admin_register_campaign_result(v_camp, 1000, 'teste', 'k2', true);
    PERFORM pg_temp.chk('Com confirmação explícita, resultado novo é pago (p1 = 500)',
      pg_temp.bal(v_p1) = 500
      AND (SELECT count(*) FROM public.campaign_results WHERE campaign_id = v_camp) = 2);

    INSERT INTO public.campaigns (title, description, platform, target_url, instructions, reward_amount, status, campaign_type)
      VALUES ('Teste afiliado', 'd', 'TikTok', 'https://www.tiktok.com/@x', 'i', 150, 'ACTIVE', 'affiliate')
      RETURNING id INTO v_camp2;
    INSERT INTO public.campaign_assignments (campaign_id, user_id, status, completed_at)
      VALUES (v_camp2, v_p1, 'COMPLETED', now());
    v_res := public.admin_register_campaign_result(v_camp2, 1000, NULL, 'ka', false);
    PERFORM pg_temp.chk('Campanha de afiliado: 60% de 1.000 = 600 para o único participante',
      (v_res->>'pool_aoa')::numeric = 600 AND pg_temp.bal(v_p1) = 1100, 'p1=' || pg_temp.bal(v_p1));

    INSERT INTO public.campaigns (title, description, platform, target_url, instructions, reward_amount, status, campaign_type)
      VALUES ('Sem participantes', 'd', 'TikTok', 'https://www.tiktok.com/@x', 'i', 150, 'ACTIVE', 'collective')
      RETURNING id INTO v_camp3;
    PERFORM pg_temp.expect_fail('Campanha sem participantes que concluíram não paga',
      format('SELECT public.admin_register_campaign_result(%L, 1000, NULL, ''kz'', false)', v_camp3),
      NULL, 'participantes');

    PERFORM pg_temp.as_user(v_n);
    PERFORM pg_temp.expect_fail('Concluir campanha sem ter participado é bloqueado',
      format('SELECT public.complete_campaign_participation(%L)', v_camp3), NULL, 'Participar');
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Campanhas abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 5) SEGURANÇA (papéis reais da base de dados + RLS)
  ------------------------------------------------------------------
  BEGIN
    PERFORM pg_temp.guard(false);                  -- garante que a guarda do perfil está ATIVA
    PERFORM pg_temp.as_user(v_c);

    v_err := pg_temp.try_as('authenticated',
      format('UPDATE public.wallets SET balance = 999999 WHERE user_id = %L', v_c));
    PERFORM pg_temp.chk('Utilizador NÃO consegue alterar o próprio saldo',
      pg_temp.bal(v_c) = 0, COALESCE(left(v_err, 120), 'sem erro, 0 linhas alteradas'));

    v_err := pg_temp.try_as('authenticated',
      format('UPDATE public.profiles SET role = ''admin'' WHERE id = %L', v_c));
    PERFORM pg_temp.chk('Utilizador NÃO consegue tornar-se administrador',
      (SELECT role FROM public.profiles WHERE id = v_c) = 'user', COALESCE(left(v_err, 120), 'guarda repôs o valor'));

    v_err := pg_temp.try_as('authenticated',
      format('UPDATE public.profiles SET subscription_status = ''active'', subscription_expires_at = now() + interval ''10 years'' WHERE id = %L', v_c));
    PERFORM pg_temp.chk('Utilizador NÃO consegue ativar/estender a própria assinatura',
      (SELECT subscription_status FROM public.profiles WHERE id = v_c) <> 'active'
      AND (SELECT subscription_expires_at FROM public.profiles WHERE id = v_c) IS NULL,
      COALESCE(left(v_err, 120), 'guarda repôs o valor'));

    v_err := pg_temp.try_as('authenticated',
      format('UPDATE public.profiles SET invited_by = %L WHERE id = %L', v_a, v_c));
    PERFORM pg_temp.chk('Utilizador NÃO consegue definir o próprio afiliado (invited_by)',
      (SELECT invited_by FROM public.profiles WHERE id = v_c) IS NULL);

    PERFORM pg_temp.chk('RLS: não vê a carteira de outro utilizador',
      pg_temp.count_as('authenticated', format('SELECT count(*) FROM public.wallets WHERE user_id = %L', v_a)) = 0);
    PERFORM pg_temp.chk('RLS: não vê movimentos de outro utilizador',
      pg_temp.count_as('authenticated', format('SELECT count(*) FROM public.wallet_transactions WHERE user_id = %L', v_a)) = 0);
    PERFORM pg_temp.chk('RLS: não vê saques de outro utilizador',
      pg_temp.count_as('authenticated', format('SELECT count(*) FROM public.withdrawals WHERE user_id = %L', v_b)) = 0);
    PERFORM pg_temp.chk('RLS: não vê comissões nem falhas de comissão de outros',
      pg_temp.count_as('authenticated', 'SELECT count(*) FROM public.affiliate_commission_failures') = 0
      AND pg_temp.count_as('authenticated', format('SELECT count(*) FROM public.affiliate_commissions WHERE affiliate_user_id = %L', v_a)) = 0);

    v_err := pg_temp.try_as('authenticated',
      format('INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, status) SELECT id, %L, ''MANUAL_ADJUSTMENT'', 1000, ''x'', ''COMPLETED'' FROM public.wallets WHERE user_id = %L', v_c, v_c));
    PERFORM pg_temp.chk('Utilizador NÃO consegue inserir movimentos no próprio ledger',
      (SELECT count(*) FROM public.wallet_transactions WHERE user_id = v_c AND type = 'MANUAL_ADJUSTMENT') = 0,
      COALESCE(left(v_err, 120), 'sem erro, nada inserido'));

    -- saque pendente do B: B (dono) não o consegue marcar como pago
    PERFORM pg_temp.as_user(v_b);
    v_res := public.request_withdrawal(1000, 'EXPRESS', '{"conta":"1"}'::jsonb);
    v_w4 := (v_res->>'withdrawal_id')::uuid;
    v_err := pg_temp.try_as('authenticated',
      format('UPDATE public.withdrawals SET status = ''PAID'' WHERE id = %L', v_w4));
    PERFORM pg_temp.chk('Utilizador NÃO consegue marcar o próprio saque como pago',
      (SELECT status FROM public.withdrawals WHERE id = v_w4) = 'PENDING', COALESCE(left(v_err, 120), '0 linhas alteradas'));

    PERFORM pg_temp.as_user(v_c);
    PERFORM pg_temp.expect_fail('Funções internas de dinheiro fechadas ao utilizador (_credit_wallet)',
      format('SELECT public._credit_wallet(%L, 1000, ''MANUAL_ADJUSTMENT'', ''x'', NULL)', v_c),
      'authenticated', 'permission denied');
    PERFORM pg_temp.expect_fail('Funções internas fechadas ao utilizador (_pay_affiliate_commission)',
      format('SELECT public._pay_affiliate_commission(%L, ''SUBSCRIPTION'', gen_random_uuid(), 4900, 20)', v_b),
      'authenticated', 'permission denied');
    PERFORM pg_temp.expect_fail('Função de dinheiro fechada ao papel anónimo (request_withdrawal)',
      'SELECT public.request_withdrawal(1000, ''EXPRESS'', ''{}''::jsonb)', 'anon', 'permission denied');
    PERFORM pg_temp.expect_fail('Utilizador comum não altera definições de economia',
      'SELECT public.admin_set_economy_setting(''aff_subscription_pct'', 100)', NULL, 'administradores');
    PERFORM pg_temp.expect_fail('Utilizador comum não reprocessa comissões',
      'SELECT public.admin_retry_commission_failures()', NULL, 'administradores');
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Segurança abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 6) ELIMINAR CONTAS: o histórico financeiro não pode desaparecer
  ------------------------------------------------------------------
  BEGIN
    PERFORM pg_temp.as_user(v_adm);
    PERFORM pg_temp.expect_fail('Eliminar conta COM histórico financeiro é recusado pela base de dados',
      format('DELETE FROM auth.users WHERE id = %L', v_a), NULL, 'protegid|não pode ser eliminada');
    PERFORM pg_temp.chk('Conta com histórico continua a existir, com carteira e movimentos',
      EXISTS (SELECT 1 FROM public.profiles WHERE id = v_a)
      AND EXISTS (SELECT 1 FROM public.wallet_transactions WHERE user_id = v_a));

    DELETE FROM auth.users WHERE id = v_z;
    PERFORM pg_temp.chk('Conta SEM histórico financeiro pode ser eliminada',
      NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = v_z)
      AND NOT EXISTS (SELECT 1 FROM public.wallets WHERE user_id = v_z));
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Eliminação abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 7) TROCA DE SEGUIDORES (links validados e distribuição)
  ------------------------------------------------------------------
  BEGIN
    PERFORM pg_temp.chk('Link: @handle vira URL do TikTok',
      public._exchange_link('tiktok', '@abc_1') = 'https://www.tiktok.com/@abc_1');
    PERFORM pg_temp.chk('Link: domínio falso tiktok.com.evil.com é rejeitado',
      public._exchange_link('tiktok', 'https://tiktok.com.evil.com/x') IS NULL);
    PERFORM pg_temp.chk('Link: outro domínio é rejeitado',
      public._exchange_link('tiktok', 'https://evil.com/tiktok.com/') IS NULL);
    PERFORM pg_temp.chk('Link: javascript: é rejeitado',
      public._exchange_link('instagram', 'javascript:alert(1)') IS NULL);
    PERFORM pg_temp.chk('Link: utilizador@domínio é rejeitado',
      public._exchange_link('youtube', 'https://user@youtube.com/x') IS NULL);

    PERFORM pg_temp.set_sub(v_l1, 'active', 200);
    PERFORM pg_temp.set_sub(v_l2, 'active', 200);
    UPDATE public.profiles SET tiktok = '@teste_l1' WHERE id = v_l1;
    UPDATE public.profiles SET instagram = '@teste_l2' WHERE id = v_l2;

    PERFORM pg_temp.chk('Assinante ativo com link publica a tarefa de troca',
      (SELECT count(*) FROM public.community_tasks
       WHERE creator_user_id = v_l1 AND source = 'EXCHANGE' AND is_active
         AND profile_url = 'https://www.tiktok.com/@teste_l1') = 1);

    -- isola o teste: desativa tarefas reais (o LIMIT 5 podia deixar o link de teste de fora); tudo é desfeito no fim
    UPDATE public.community_tasks SET is_active = false
      WHERE creator_user_id IS DISTINCT FROM v_l1 AND creator_user_id IS DISTINCT FROM v_l2;

    PERFORM pg_temp.as_user(v_l2);
    v_txt := public.fetch_or_assign_community_tasks()::text;
    PERFORM pg_temp.chk('Quem tem link recebe o link dos outros assinantes', v_txt LIKE '%teste_l1%', left(v_txt, 120));
    PERFORM pg_temp.chk('Não recebe o próprio link', v_txt NOT LIKE '%teste_l2%');

    PERFORM pg_temp.as_user(v_n);
    v_txt := public.fetch_or_assign_community_tasks()::text;
    PERFORM pg_temp.chk('Assinante SEM link próprio não recebe links de troca (reciprocidade)',
      v_txt NOT LIKE '%teste_l1%', left(v_txt, 120));

    PERFORM pg_temp.as_user(v_c);
    PERFORM pg_temp.chk('Visitante (sem assinatura) não recebe nenhum link',
      public.fetch_or_assign_community_tasks()::text = '[]');

    UPDATE public.profiles SET tiktok = 'https://tiktok.com.evil.com/x' WHERE id = v_l1;
    PERFORM pg_temp.chk('Trocar para link inválido retira a tarefa da troca',
      (SELECT count(*) FROM public.community_tasks
       WHERE creator_user_id = v_l1 AND source = 'EXCHANGE' AND is_active) = 0);

    UPDATE public.profiles SET tiktok = '@teste_l1' WHERE id = v_l1;
    PERFORM pg_temp.set_sub(v_l1, 'active', -1);
    PERFORM public.expire_subscriptions();
    PERFORM pg_temp.chk('Assinatura expirada retira os links da troca',
      (SELECT count(*) FROM public.community_tasks
       WHERE creator_user_id = v_l1 AND source = 'EXCHANGE' AND is_active) = 0);
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Troca de seguidores abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 7b) TERMOS, RECONCILIAÇÃO PELO PAINEL E REGISTO DE ERROS
  ------------------------------------------------------------------
  BEGIN
    PERFORM set_config('app.t_ver', (SELECT value FROM public.app_settings WHERE key = 'terms_version'), true);
    PERFORM pg_temp.as_user(v_c);
    PERFORM public.accept_terms(current_setting('app.t_ver'));
    PERFORM public.accept_terms(current_setting('app.t_ver'));
    PERFORM pg_temp.chk('Termos: aceitar duas vezes a mesma versão guarda um único registo',
      (SELECT count(*) FROM public.terms_acceptances WHERE user_id = v_c AND terms_version = current_setting('app.t_ver')) = 1);
    PERFORM pg_temp.expect_fail('Termos: versão inventada pelo cliente é recusada', 'SELECT public.accept_terms(''versao-inventada'')', NULL, 'desatualizada');
    PERFORM pg_temp.chk('Termos: versão inventada não ficou registada',
      (SELECT count(*) FROM public.terms_acceptances WHERE user_id = v_c AND terms_version = 'versao-inventada') = 0);
    PERFORM pg_temp.chk('IA: 1.º e 2.º pedido permitidos (limite 2/hora)',
      (public.ai_rate_limit_check(v_c, 'teste-ia', 2, 10)->>'allowed')::boolean
      AND (public.ai_rate_limit_check(v_c, 'teste-ia', 2, 10)->>'allowed')::boolean);
    PERFORM pg_temp.chk('IA: 3.º pedido na mesma hora é recusado',
      NOT (public.ai_rate_limit_check(v_c, 'teste-ia', 2, 10)->>'allowed')::boolean);
    PERFORM pg_temp.chk('IA: pedido recusado não gasta quota (continuam 2 registos)',
      (SELECT count(*) FROM public.ai_usage_log WHERE user_id = v_c AND fn = 'teste-ia') = 2);
    PERFORM pg_temp.chk('IA: limite é por utilizador (outro utilizador não é afetado)',
      (public.ai_rate_limit_check(v_b, 'teste-ia', 2, 10)->>'allowed')::boolean);
    PERFORM pg_temp.chk('IA: tabela e função fechadas ao utilizador comum',
      pg_temp.count_as('authenticated', 'SELECT count(*) FROM public.ai_usage_log') <= 0
      AND NOT has_function_privilege('authenticated', 'public.ai_rate_limit_check(uuid,text,integer,integer)', 'EXECUTE'));
    -- PRIMEIRO ACESSO: fecha uma vez e não volta a abrir (evita o loop no /account/setup)
    PERFORM pg_temp.guard(true);
    UPDATE public.profiles SET first_login = true WHERE id = v_c;
    PERFORM pg_temp.guard(false);
    PERFORM pg_temp.as_user(v_c);
    PERFORM public.complete_account_setup(v_c, 'Teste Primeiro Acesso',
      '9' || lpad((floor(random() * 99999999))::bigint::text, 8, '0'), NULL, NULL);
    PERFORM pg_temp.chk('Primeiro acesso: concluir o setup fecha first_login (false)',
      (SELECT first_login FROM public.profiles WHERE id = v_c) IS FALSE);
    PERFORM pg_temp.chk('Primeiro acesso: repetir o setup devolve "já concluído" e não reabre',
      (public.complete_account_setup(v_c, 'X', '900000000', NULL, NULL) ->> 'success')::boolean IS FALSE
      AND (SELECT first_login FROM public.profiles WHERE id = v_c) IS FALSE);
    PERFORM pg_temp.expect_fail('Termos: versão vazia é recusada', 'SELECT public.accept_terms('''')', NULL, 'inválida');
    PERFORM pg_temp.chk('RLS: utilizador não vê a aceitação de termos de outros',
      pg_temp.count_as('authenticated', format('SELECT count(*) FROM public.terms_acceptances WHERE user_id = %L', v_b)) = 0);

    PERFORM public.log_client_error('erro de teste', 'stack', '/x', 'ua');
    PERFORM pg_temp.chk('Registo de erros: erro do cliente é guardado',
      (SELECT count(*) FROM public.app_errors WHERE user_id = v_c AND message = 'erro de teste') = 1);
    PERFORM pg_temp.chk('RLS: utilizador comum não lê o registo de erros',
      pg_temp.count_as('authenticated', 'SELECT count(*) FROM public.app_errors') = 0);

    PERFORM pg_temp.expect_fail('Reconciliação pelo painel é só para administradores',
      'SELECT public.admin_reconcile_wallets()', NULL, 'administradores');
    PERFORM pg_temp.as_user(v_adm);
    v_res := public.admin_reconcile_wallets();
    PERFORM pg_temp.chk('Reconciliação pelo painel devolve o relatório',
      (v_res->>'wallets_checked')::int >= 12 AND v_res ? 'healthy' AND v_res ? 'reserved_mismatches', left(v_res::text, 160));
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Termos/Monitorização abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- 8) RECONCILIAÇÃO: saldo = soma dos movimentos (todos os utilizadores de teste)
  ------------------------------------------------------------------
  BEGIN
    SELECT count(*) INTO v_cnt
    FROM public.wallets w
    WHERE w.user_id IN (v_adm, v_a, v_b, v_c, v_p1, v_p2, v_n, v_e, v_m, v_l1, v_l2)
      AND w.balance <> COALESCE((SELECT sum(t.amount) FROM public.wallet_transactions t WHERE t.wallet_id = w.id), 0);
    PERFORM pg_temp.chk('Reconciliação: em todas as carteiras, saldo = soma dos movimentos', v_cnt = 0,
      v_cnt || ' carteira(s) divergentes');

    SELECT count(*) INTO v_cnt FROM public.wallets
    WHERE user_id IN (v_adm, v_a, v_b, v_c, v_p1, v_p2, v_n, v_e, v_m, v_l1, v_l2)
      AND (balance < 0 OR reserved_balance < 0);
    PERFORM pg_temp.chk('Nenhuma carteira com saldo ou reserva negativos', v_cnt = 0);

    PERFORM pg_temp.chk('Pagamentos de campanha: soma dos registos = soma creditada',
      COALESCE((SELECT sum(amount_aoa) FROM public.campaign_result_payouts
                WHERE campaign_id IN (v_camp, v_camp2)), 0)
      = COALESCE((SELECT sum(amount) FROM public.wallet_transactions
                  WHERE type = 'CAMPAIGN_REWARD' AND user_id IN (v_p1, v_p2, v_n, v_e)), 0));
  EXCEPTION WHEN OTHERS THEN
    PERFORM pg_temp.chk('GRUPO Reconciliação abortou', false, SQLERRM);
  END;

  ------------------------------------------------------------------
  -- RELATÓRIO (termina com erro propositado → desfaz tudo)
  ------------------------------------------------------------------
  SELECT count(*) FILTER (WHERE ok), count(*) INTO v_ok, v_total FROM _t;
  v_report := E'\n\n===== RESULTADO DOS TESTES: ' || v_ok || ' de ' || v_total || E' passaram =====\n'
              || E'(nada foi gravado: este erro é propositado e desfaz o teste)\n\n';
  FOR r IN SELECT * FROM _t ORDER BY ok, n LOOP
    v_report := v_report || CASE WHEN r.ok THEN '✅ ' ELSE '❌ ' END || r.name
                || CASE WHEN NOT r.ok AND r.info <> '' THEN ' — ' || r.info ELSE '' END || E'\n';
  END LOOP;
  RAISE EXCEPTION '%', v_report;
END
$test$;
