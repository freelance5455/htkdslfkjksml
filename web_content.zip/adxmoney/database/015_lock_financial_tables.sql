-- ====================================================================
-- 015 — Tabelas financeiras só via RPC
-- Revoga INSERT directo; grants/policies de admin para engagement_orders e community_tasks.
-- Idempotente (CREATE OR REPLACE / IF NOT EXISTS). Executar uma vez no SQL Editor.
-- ====================================================================

-- Inserção directa em tabelas financeiras: só via RPC
--    (antes: utilizador podia inserir linha com status APPROVED / valores livres)
-- --------------------------------------------------------------------
REVOKE INSERT ON TABLE public.subscription_payments FROM authenticated;
REVOKE INSERT ON TABLE public.engagement_orders     FROM authenticated;
REVOKE INSERT ON TABLE public.campaign_requests     FROM authenticated;
REVOKE INSERT ON TABLE public.wallet_deposits       FROM authenticated;
REVOKE UPDATE ON TABLE public.task_distribution_queue FROM authenticated;

-- Admin precisa de UPDATE em engagement_orders (o painel faz update directo) — policy só admin
GRANT UPDATE ON TABLE public.engagement_orders TO authenticated;
DROP POLICY IF EXISTS "eng_orders_admin_update" ON public.engagement_orders;
CREATE POLICY "eng_orders_admin_update" ON public.engagement_orders
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Admin precisa de INSERT/UPDATE em community_tasks (painel lança tarefas)
GRANT INSERT, UPDATE ON TABLE public.community_tasks TO authenticated;
DROP POLICY IF EXISTS "comm_tasks_admin_write" ON public.community_tasks;
CREATE POLICY "comm_tasks_admin_write" ON public.community_tasks
  FOR ALL TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

