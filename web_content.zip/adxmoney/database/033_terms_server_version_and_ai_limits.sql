-- ====================================================================
-- 033 — Termos validados pelo servidor + limite de utilização da IA
-- Idempotente. Executar depois da 032.
--
-- 1) A versão oficial dos termos passa a viver na base (app_settings). O registo público e
--    accept_terms() recusam qualquer versão que não seja a oficial (antes aceitavam o que o cliente enviasse).
--    AO MUDAR TERMS_VERSION em src/lib/legal.ts, execute também:
--      UPDATE public.app_settings SET value = 'NOVA-VERSAO', updated_at = now() WHERE key = 'terms_version';
-- 2) ai_rate_limit_check(): limite por utilizador/hora e /dia, atómico, só para service_role (Edge Functions).
-- ====================================================================

-- ---------- 1) Versão oficial dos termos ----------
CREATE TABLE IF NOT EXISTS public.app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;   -- sem policies: ninguém lê pela API
REVOKE ALL ON public.app_settings FROM PUBLIC, anon, authenticated;

INSERT INTO public.app_settings (key, value) VALUES ('terms_version', '2026-11-v1')
ON CONFLICT (key) DO NOTHING;

CREATE OR REPLACE FUNCTION public.current_terms_version()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$ SELECT value FROM public.app_settings WHERE key = 'terms_version' $$;
REVOKE ALL ON FUNCTION public.current_terms_version() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.current_terms_version() TO service_role;

CREATE OR REPLACE FUNCTION public.accept_terms(p_version TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_current TEXT := public.current_terms_version();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF p_version IS NULL OR length(trim(p_version)) = 0 OR length(p_version) > 40 THEN
    RAISE EXCEPTION 'Versão inválida.';
  END IF;
  IF v_current IS NULL THEN
    RAISE EXCEPTION 'Versão oficial dos termos não configurada.';
  END IF;
  IF trim(p_version) <> v_current THEN
    RAISE EXCEPTION 'Versão dos termos desatualizada. Atualize a página e tente de novo.';
  END IF;
  INSERT INTO public.terms_acceptances (user_id, terms_version, source)
  VALUES (v_uid, v_current, 'gate')
  ON CONFLICT (user_id, terms_version) DO NOTHING;
  RETURN jsonb_build_object('success', true);
END;
$$;
REVOKE ALL ON FUNCTION public.accept_terms(TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.accept_terms(TEXT) TO authenticated;

-- ---------- 2) Limite de utilização da IA ----------
CREATE TABLE IF NOT EXISTS public.ai_usage_log (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  fn         TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ai_usage_log_user_fn_time_idx ON public.ai_usage_log (user_id, fn, created_at DESC);
ALTER TABLE public.ai_usage_log ENABLE ROW LEVEL SECURITY;   -- sem policies
REVOKE ALL ON public.ai_usage_log FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.ai_rate_limit_check(
  p_user_id UUID,
  p_fn      TEXT,
  p_hourly  INTEGER,
  p_daily   INTEGER
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_hour INTEGER;
  v_day  INTEGER;
BEGIN
  IF p_user_id IS NULL OR p_fn IS NULL THEN RAISE EXCEPTION 'Parâmetros inválidos'; END IF;

  -- serializa pedidos do mesmo utilizador/função: pedidos simultâneos não passam todos pelo "ainda há margem"
  PERFORM pg_advisory_xact_lock(hashtext(p_user_id::text || ':' || p_fn));

  SELECT count(*) INTO v_hour FROM public.ai_usage_log
   WHERE user_id = p_user_id AND fn = p_fn AND created_at > NOW() - INTERVAL '1 hour';
  SELECT count(*) INTO v_day FROM public.ai_usage_log
   WHERE user_id = p_user_id AND fn = p_fn AND created_at > NOW() - INTERVAL '1 day';

  IF v_hour >= p_hourly THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'hourly');
  END IF;
  IF v_day >= p_daily THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'daily');
  END IF;

  INSERT INTO public.ai_usage_log (user_id, fn) VALUES (p_user_id, p_fn);

  -- limpeza oportunista do próprio utilizador (mantém a tabela pequena)
  DELETE FROM public.ai_usage_log WHERE user_id = p_user_id AND created_at < NOW() - INTERVAL '3 days';

  RETURN jsonb_build_object('allowed', true);
END;
$$;
REVOKE ALL ON FUNCTION public.ai_rate_limit_check(UUID, TEXT, INTEGER, INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ai_rate_limit_check(UUID, TEXT, INTEGER, INTEGER) TO service_role;
