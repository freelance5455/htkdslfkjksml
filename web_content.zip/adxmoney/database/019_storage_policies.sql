-- ====================================================================
-- 019 — Policies do bucket subscription-proofs
-- Bucket tem de existir e ser PRIVADO. Cobre {uid}/... e deposits/{uid}/...
-- Idempotente (CREATE OR REPLACE / IF NOT EXISTS). Executar uma vez no SQL Editor.
-- ====================================================================

-- Storage: policies para os dois caminhos usados pelo app
--     {uid}/...  e  deposits/{uid}/...   (a policy sugerida em 004 bloqueava deposits/)
--     Requer que o bucket 'subscription-proofs' já exista e seja PRIVADO.
-- --------------------------------------------------------------------
-- Bucket privado (cria se não existir; se já existir, força privado e limites)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('subscription-proofs', 'subscription-proofs', false, 5242880,
        ARRAY['image/jpeg', 'image/png', 'image/webp', 'application/pdf'])
ON CONFLICT (id) DO UPDATE SET public = false;

DROP POLICY IF EXISTS "proofs_insert_own" ON storage.objects;
CREATE POLICY "proofs_insert_own" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'subscription-proofs'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR ((storage.foldername(name))[1] = 'deposits' AND (storage.foldername(name))[2] = auth.uid()::text)
    )
  );

DROP POLICY IF EXISTS "proofs_select_own_or_admin" ON storage.objects;
CREATE POLICY "proofs_select_own_or_admin" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'subscription-proofs'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR ((storage.foldername(name))[1] = 'deposits' AND (storage.foldername(name))[2] = auth.uid()::text)
      OR public.is_admin()
    )
  );

