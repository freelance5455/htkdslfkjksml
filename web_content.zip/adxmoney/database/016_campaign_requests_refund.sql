-- ====================================================================
-- 016 — Pedidos de campanha
-- Tipo CAMPAIGN_REFUND no ledger, preço fixo no servidor e reembolso ao rejeitar.
-- Idempotente (CREATE OR REPLACE / IF NOT EXISTS). Executar uma vez no SQL Editor.
-- ====================================================================

-- Ledger: tipo de reembolso
-- --------------------------------------------------------------------
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;
ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check CHECK (type IN (
    'SIGNUP_BONUS', 'AFFILIATE_COMMISSION', 'CAMPAIGN_REWARD', 'CAMPAIGN_TOKEN',
    'CAMPAIGN_REFUND', 'DEPOSIT', 'WITHDRAWAL_LOCK', 'WITHDRAWAL_PAID',
    'WITHDRAWAL_REFUND', 'MANUAL_ADJUSTMENT'
  ));

-- Pedido de campanha: preço fixo no servidor + reembolso ao rejeitar
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_paid_campaign_request(
  p_title TEXT,
  p_platform TEXT,
  p_target_url TEXT,
  p_action_type TEXT DEFAULT 'follow',
  p_objective TEXT DEFAULT NULL,
  p_description TEXT DEFAULT NULL,
  p_target_audience TEXT DEFAULT 'Geral',
  p_requester_phone TEXT DEFAULT NULL,
  p_cost_kz NUMERIC DEFAULT 9500,   -- ignorado: preço é fixo no servidor
  p_additional_information TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_wallet RECORD;
  v_req_id UUID;
  v_cost CONSTANT NUMERIC := 9500;
  v_platform TEXT;
  v_active BOOLEAN;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  SELECT is_active INTO v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION 'Conta inactiva.';
  END IF;

  IF p_title IS NULL OR length(trim(p_title)) < 3 THEN
    RAISE EXCEPTION 'Título inválido.';
  END IF;
  IF p_target_url IS NULL OR length(trim(p_target_url)) < 5 THEN
    RAISE EXCEPTION 'URL alvo inválida.';
  END IF;

  v_platform := COALESCE(NULLIF(trim(p_platform), ''), 'Instagram');
  IF lower(v_platform) LIKE '%tiktok%' THEN v_platform := 'TikTok';
  ELSIF lower(v_platform) LIKE '%insta%' THEN v_platform := 'Instagram';
  ELSIF lower(v_platform) LIKE '%you%' THEN v_platform := 'YouTube';
  END IF;

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (v_uid, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_uid FOR UPDATE;

  IF v_wallet.balance < v_cost THEN
    RETURN jsonb_build_object(
      'success', false, 'error', 'Saldo insuficiente.',
      'balance', v_wallet.balance, 'required', v_cost
    );
  END IF;

  INSERT INTO public.campaign_requests (
    user_id, title, platform, target_url, action_type, objective, description,
    target_audience, requester_phone, cost_usd, currency, amount_paid, status, additional_information
  ) VALUES (
    v_uid, trim(p_title), v_platform, trim(p_target_url),
    COALESCE(NULLIF(trim(p_action_type), ''), 'follow'),
    NULLIF(trim(COALESCE(p_objective, '')), ''),
    NULLIF(trim(COALESCE(p_description, '')), ''),
    COALESCE(NULLIF(trim(p_target_audience), ''), 'Geral'),
    NULLIF(trim(COALESCE(p_requester_phone, '')), ''),
    ROUND(v_cost / 950.0, 2), 'AOA', v_cost, 'PENDING',
    NULLIF(trim(COALESCE(p_additional_information, '')), '')
  )
  RETURNING id INTO v_req_id;

  UPDATE public.wallets SET balance = balance - v_cost, updated_at = NOW() WHERE id = v_wallet.id;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wallet.id, v_uid, 'CAMPAIGN_TOKEN', -v_cost,
          'Taxa de solicitação de campanha: ' || trim(p_title), v_req_id::text, 'COMPLETED');

  RETURN jsonb_build_object('success', true, 'request_id', v_req_id, 'charged', v_cost, 'status', 'PENDING');
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_process_campaign_request(
  p_request_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_req RECORD;
  v_wallet RECORD;
  v_refunded BOOLEAN := FALSE;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar pedidos.';
  END IF;
  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido.';
  END IF;

  SELECT * INTO v_req FROM public.campaign_requests WHERE id = p_request_id FOR UPDATE;
  IF v_req.id IS NULL THEN
    RAISE EXCEPTION 'Pedido não encontrado.';
  END IF;
  IF v_req.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Este pedido já foi processado (%).', v_req.status;
  END IF;

  IF p_status = 'REJECTED' AND COALESCE(v_req.amount_paid, 0) > 0 THEN
    SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_req.user_id FOR UPDATE;
    IF v_wallet.id IS NOT NULL THEN
      UPDATE public.wallets SET balance = balance + v_req.amount_paid, updated_at = NOW()
      WHERE id = v_wallet.id;
      INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
      VALUES (v_wallet.id, v_req.user_id, 'CAMPAIGN_REFUND', v_req.amount_paid,
              'Reembolso de pedido de campanha rejeitado: ' || v_req.title, v_req.id::text, 'COMPLETED');
      v_refunded := TRUE;
    END IF;
  END IF;

  UPDATE public.campaign_requests
  SET status = p_status,
      rejection_reason = CASE WHEN p_status = 'REJECTED'
                              THEN COALESCE(NULLIF(trim(COALESCE(p_rejection_reason, '')), ''), 'Rejeitado pela administração')
                              ELSE NULL END,
      processed_at = NOW(), processed_by = v_admin, updated_at = NOW()
  WHERE id = v_req.id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_req.user_id, 'CAMPAIGN_REQUEST_' || p_status,
          CASE WHEN p_status = 'APPROVED' THEN 'Pedido de campanha aprovado' ELSE 'Pedido de campanha rejeitado' END,
          CASE WHEN v_refunded THEN 'Valor reembolsado na carteira: ' || v_req.amount_paid || ' Kz' ELSE v_req.title END);

  RETURN jsonb_build_object('success', true, 'status', p_status, 'refunded', v_refunded);
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_process_campaign_request(UUID, TEXT, TEXT) TO authenticated;

