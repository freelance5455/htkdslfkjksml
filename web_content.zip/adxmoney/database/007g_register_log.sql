-- 007g — Tabela de rate-limit para registos publicos
CREATE TABLE IF NOT EXISTS public.public_register_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_public_register_log_created
  ON public.public_register_log (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_public_register_log_email
  ON public.public_register_log (email, created_at DESC);

ALTER TABLE public.public_register_log ENABLE ROW LEVEL SECURITY;

GRANT ALL ON TABLE public.public_register_log TO service_role;
