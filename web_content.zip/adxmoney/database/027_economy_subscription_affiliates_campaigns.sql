-- ====================================================================
-- 027 — Economia: assinatura de 6 meses, comissões de afiliado (%) e
--       campanhas pagas por resultado financeiro
-- Executar DEPOIS de 026. Idempotente.
--
-- Regras (valores editáveis em public.economy_settings / painel admin → Economia):
--  • Assinatura: 4.900 Kz por 6 meses. Renovável nos últimos 30 dias ou depois de expirar.
--  • Afiliado recebe % quando o indicado PAGA (nunca no registo):
--      assinatura 20% (renovação 10%) · pedido da loja 10% · campanha coletiva (10 USD) 10%.
--      O afiliado precisa de ter assinatura ativa.
--  • Bónus do indicado (250 Kz) só quando ele ativa a assinatura.
--  • Campanhas: ninguém é pago por "clicar". Quando o admin regista um RESULTADO FINANCEIRO,
--    uma percentagem (coletiva 50% / afiliado 60%) é repartida em partes iguais por TODOS os
--    participantes que concluíram. Sem resultado = sem pagamento; o custo é sempre limitado
--    pela receita real da campanha.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1) Definições da economia
-- --------------------------------------------------------------------
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = '_complete_referral' AND pg_get_function_result(p.oid) <> 'void') OR
        (p.proname = '_credit_wallet' AND pg_get_function_result(p.oid) <> 'void') OR
        (p.proname = '_is_active_subscriber' AND pg_get_function_result(p.oid) <> 'boolean') OR
        (p.proname = '_log_commission_failure' AND pg_get_function_result(p.oid) <> 'void') OR
        (p.proname = '_pay_affiliate_commission' AND pg_get_function_result(p.oid) <> 'void') OR
        (p.proname = '_to_aoa' AND pg_get_function_result(p.oid) <> 'numeric') OR
        (p.proname = 'admin_process_subscription_payment' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_register_campaign_result' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_retry_commission_failures' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_set_community_setting' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_set_economy_setting' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'complete_account_setup' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'complete_campaign_participation' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'econ' AND pg_get_function_result(p.oid) <> 'numeric') OR
        (p.proname = 'expire_subscriptions' AND pg_get_function_result(p.oid) <> 'integer') OR
        (p.proname = 'join_campaign' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'refresh_my_subscription' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'submit_subscription_payment' AND pg_get_function_result(p.oid) <> 'jsonb')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

CREATE TABLE IF NOT EXISTS public.economy_settings (
  key TEXT PRIMARY KEY,
  value NUMERIC(14, 2) NOT NULL CHECK (value >= 0),
  label TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.economy_settings (key, value, label) VALUES
  ('subscription_price_aoa',       4900, 'Preço da assinatura (Kz)'),
  ('subscription_months',             6, 'Duração da assinatura (meses)'),
  ('renewal_window_days',            30, 'Renovação permitida nos últimos X dias'),
  ('aff_subscription_pct',           20, 'Comissão do afiliado — 1.ª assinatura (%)'),
  ('aff_subscription_renewal_pct',   10, 'Comissão do afiliado — renovação (%)'),
  ('aff_engagement_pct',             10, 'Comissão do afiliado — pedido da loja (%)'),
  ('aff_campaign_request_pct',       10, 'Comissão do afiliado — campanha coletiva paga (%)'),
  ('referred_bonus_aoa',            250, 'Bónus do indicado ao ativar assinatura (Kz)'),
  ('pool_pct_collective',            50, 'Campanha coletiva — % do resultado repartida pelos participantes'),
  ('pool_pct_affiliate',             60, 'Campanha de afiliado — % do resultado repartida pelos participantes')
ON CONFLICT (key) DO NOTHING;

ALTER TABLE public.economy_settings ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.economy_settings TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.economy_settings TO service_role;
DROP POLICY IF EXISTS "economy_settings_select" ON public.economy_settings;
CREATE POLICY "economy_settings_select" ON public.economy_settings
  FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.econ(p_key TEXT, p_default NUMERIC)
RETURNS NUMERIC
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT COALESCE((SELECT value FROM public.economy_settings WHERE key = p_key), p_default);
$$;

CREATE OR REPLACE FUNCTION public.admin_set_economy_setting(p_key TEXT, p_value NUMERIC)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.economy_settings WHERE key = p_key) THEN
    RAISE EXCEPTION 'Definição desconhecida.';
  END IF;
  IF p_value IS NULL OR p_value < 0 THEN
    RAISE EXCEPTION 'Valor inválido.';
  END IF;
  IF (p_key LIKE '%\_pct' OR p_key LIKE 'pool\_pct\_%') AND p_value > 100 THEN
    RAISE EXCEPTION 'Percentagem máxima: 100.';
  END IF;
  IF p_key = 'subscription_months' AND (p_value < 1 OR p_value > 36 OR p_value <> trunc(p_value)) THEN
    RAISE EXCEPTION 'A duração deve ser um número inteiro de meses entre 1 e 36.';
  END IF;
  IF p_key = 'withdrawal_require_approval' AND p_value NOT IN (0, 1) THEN
    RAISE EXCEPTION 'Use 0 (pagar direto) ou 1 (exigir aprovação antes de pagar).';
  END IF;
  IF p_key = 'subscription_price_aoa' AND p_value < 1 THEN
    RAISE EXCEPTION 'O preço deve ser maior que zero.';
  END IF;

  UPDATE public.economy_settings SET value = p_value, updated_at = NOW() WHERE key = p_key;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (auth.uid(), 'ECONOMY_SETTING_CHANGED', 'Definição de economia alterada', p_key || ' = ' || p_value::text);

  RETURN jsonb_build_object('success', true);
END;
$$;

-- Recompensas por plataforma da comunidade (tarefas da loja e troca) — antes só editáveis por SQL
CREATE OR REPLACE FUNCTION public.admin_set_community_setting(
  p_platform TEXT, p_reward_per_task NUMERIC, p_exchange_reward NUMERIC, p_daily_limit INTEGER
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;
  IF p_reward_per_task < 0 OR p_exchange_reward < 0 OR p_daily_limit < 1 THEN
    RAISE EXCEPTION 'Valores inválidos.';
  END IF;
  UPDATE public.community_settings
  SET reward_per_task = p_reward_per_task, exchange_reward = p_exchange_reward, daily_limit = p_daily_limit
  WHERE platform = lower(p_platform);
  IF NOT FOUND THEN RAISE EXCEPTION 'Plataforma não encontrada.'; END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (auth.uid(), 'COMMUNITY_SETTING_CHANGED', 'Definições da comunidade alteradas',
          lower(p_platform) || ': loja=' || p_reward_per_task || ' troca=' || p_exchange_reward || ' limite=' || p_daily_limit);
  RETURN jsonb_build_object('success', true);
END;
$$;

-- --------------------------------------------------------------------
-- 2) Utilitários internos de dinheiro
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public._to_aoa(p_amount NUMERIC, p_currency TEXT)
RETURNS NUMERIC
LANGUAGE sql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
  SELECT round(CASE upper(coalesce(p_currency, 'AOA'))
    WHEN 'AOA' THEN p_amount
    WHEN 'USD' THEN p_amount * 950
    WHEN 'EUR' THEN p_amount / 0.92 * 950
    WHEN 'BRL' THEN p_amount / 5.40 * 950
    ELSE 0 END, 2);
$$;

-- FIX: a coluna tem de existir ANTES da função (LANGUAGE sql valida o corpo ao criar)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS subscription_expires_at TIMESTAMPTZ;

CREATE OR REPLACE FUNCTION public._is_active_subscriber(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = p_user_id AND is_active = true AND subscription_status = 'active'
      AND (subscription_expires_at IS NULL OR subscription_expires_at > NOW())
  );
$$;

CREATE OR REPLACE FUNCTION public._credit_wallet(
  p_user_id UUID, p_amount NUMERIC, p_type TEXT, p_description TEXT, p_reference TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_wallet_id UUID;
BEGIN
  IF p_amount IS NULL OR p_amount <= 0 THEN RETURN; END IF;
  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (p_user_id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;
  SELECT id INTO v_wallet_id FROM public.wallets WHERE user_id = p_user_id FOR UPDATE;
  UPDATE public.wallets SET balance = balance + p_amount, updated_at = NOW() WHERE id = v_wallet_id;
  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wallet_id, p_user_id, p_type, p_amount, p_description, p_reference, 'COMPLETED');
END;
$$;

-- --------------------------------------------------------------------
-- 3) Assinatura com prazo (6 meses)
-- --------------------------------------------------------------------
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS subscription_expires_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_profiles_sub_expiry
  ON public.profiles (subscription_expires_at) WHERE subscription_status = 'active';

-- FIX: em bases criadas antes da 004, subscription_payments pode não ter estas colunas
-- (CREATE TABLE IF NOT EXISTS não altera uma tabela já existente). Garante-as aqui, idempotente.
ALTER TABLE public.subscription_payments
  ADD COLUMN IF NOT EXISTS currency TEXT NOT NULL DEFAULT 'AOA',
  ADD COLUMN IF NOT EXISTS proof_url TEXT,
  ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
  ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS processed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Pagamentos já aprovados sem data de processamento: usa a melhor data disponível
UPDATE public.subscription_payments
SET processed_at = COALESCE(updated_at, created_at, NOW())
WHERE status = 'APPROVED' AND processed_at IS NULL;

-- Assinantes que já existem: 6 meses a contar da última aprovação (mínimo 30 dias de margem)
DO $$
BEGIN
  PERFORM set_config('app.skip_profile_guard', 'on', true);
  UPDATE public.profiles p
  SET subscription_expires_at = GREATEST(
        COALESCE((SELECT max(sp.processed_at) FROM public.subscription_payments sp
                  WHERE sp.user_id = p.id AND sp.status = 'APPROVED'), NOW())
          + (public.econ('subscription_months', 6)::int * INTERVAL '1 month'),
        NOW() + INTERVAL '30 days')
  WHERE p.subscription_status = 'active' AND p.subscription_expires_at IS NULL;
END $$;

-- Guarda das colunas sensíveis do perfil (substitui a função da 014): agora também protege
-- subscription_expires_at (o utilizador não pode estender a própria assinatura) e a origem do convite.
CREATE OR REPLACE FUNCTION public.protect_profile_sensitive_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  IF current_setting('app.skip_profile_guard', true) = 'on' THEN
    RETURN NEW;
  END IF;

  IF COALESCE(auth.role(), '') = 'service_role' THEN
    RETURN NEW;
  END IF;

  IF public.is_admin() THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    NEW.role := OLD.role;
    NEW.subscription_status := OLD.subscription_status;
    NEW.subscription_expires_at := OLD.subscription_expires_at;
    NEW.invited_by := OLD.invited_by;
    NEW.referred_completed := OLD.referred_completed;
    NEW.is_active := OLD.is_active;
    NEW.member_level := OLD.member_level;
    NEW.priority_withdrawal := OLD.priority_withdrawal;
    NEW.level_updated_at := OLD.level_updated_at;
    NEW.custom_affiliate_code := OLD.custom_affiliate_code;
    IF OLD.first_login IS FALSE THEN
      NEW.first_login := FALSE;
    END IF;
    IF NEW.suspended_until IS DISTINCT FROM OLD.suspended_until THEN
      NEW.suspended_until := OLD.suspended_until;
    END IF;
  END IF;

  RETURN NEW;
END;
$fn$;

-- Passa a 'expired' quem passou do prazo (os gatilhos da 026 retiram os links da troca)
CREATE OR REPLACE FUNCTION public.expire_subscriptions()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_n INTEGER;
BEGIN
  PERFORM set_config('app.skip_profile_guard', 'on', true);
  UPDATE public.profiles
  SET subscription_status = 'expired', updated_at = NOW()
  WHERE subscription_status = 'active'
    AND subscription_expires_at IS NOT NULL
    AND subscription_expires_at < NOW();
  GET DIAGNOSTICS v_n = ROW_COUNT;
  RETURN v_n;
END;
$$;

-- O app chama isto ao abrir: actualiza o estado e devolve a validade para mostrar ao utilizador
CREATE OR REPLACE FUNCTION public.refresh_my_subscription()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_p RECORD;
  v_window INTEGER := public.econ('renewal_window_days', 30)::int;
  v_days INTEGER;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  PERFORM public.expire_subscriptions();
  SELECT subscription_status, subscription_expires_at INTO v_p FROM public.profiles WHERE id = v_uid;
  v_days := CASE WHEN v_p.subscription_expires_at IS NULL THEN NULL
                 ELSE GREATEST(0, CEIL(EXTRACT(EPOCH FROM (v_p.subscription_expires_at - NOW())) / 86400.0)::int) END;
  RETURN jsonb_build_object(
    'status', v_p.subscription_status,
    'expires_at', v_p.subscription_expires_at,
    'days_left', v_days,
    'can_renew', v_p.subscription_status IN ('visitor', 'expired', 'cancelled')
                 OR (v_p.subscription_status = 'active' AND v_days IS NOT NULL AND v_days <= v_window),
    'price_aoa', public.econ('subscription_price_aoa', 4900),
    'months', public.econ('subscription_months', 6)::int
  );
END;
$$;

-- Pedido de assinatura / renovação (substitui a versão da 017): preço e duração vêm das definições
CREATE OR REPLACE FUNCTION public.submit_subscription_payment(
  p_amount NUMERIC,                -- ignorado: preço é do servidor
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL,
  p_payment_date TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_pay_id UUID;
  v_cur TEXT := upper(trim(coalesce(p_currency, 'AOA')));
  v_meth TEXT := upper(trim(split_part(coalesce(p_method, ''), ' ', 1)));
  v_details TEXT := trim(coalesce(p_method, ''));
  v_base_aoa NUMERIC := public.econ('subscription_price_aoa', 4900);
  v_window INTEGER := public.econ('renewal_window_days', 30)::int;
  v_amount NUMERIC;
  v_status TEXT;
  v_active BOOLEAN;
  v_expires TIMESTAMPTZ;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  PERFORM public.expire_subscriptions();

  SELECT subscription_status, is_active, subscription_expires_at
  INTO v_status, v_active, v_expires FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;

  IF v_status = 'active' AND (v_expires IS NULL OR v_expires > NOW() + (v_window || ' days')::interval) THEN
    RAISE EXCEPTION 'A sua assinatura está activa até %. Poderá renovar nos últimos % dias.',
      to_char(v_expires, 'DD/MM/YYYY'), v_window;
  END IF;

  IF EXISTS (SELECT 1 FROM public.subscription_payments WHERE user_id = v_uid AND status = 'PENDING') THEN
    RAISE EXCEPTION 'Já tem um pagamento de assinatura em validação.';
  END IF;

  v_amount := CASE v_cur
    WHEN 'AOA' THEN v_base_aoa
    WHEN 'USD' THEN round(v_base_aoa / 950.0, 2)
    WHEN 'EUR' THEN round(v_base_aoa / 950.0 * 0.92, 2)
    WHEN 'BRL' THEN round(v_base_aoa / 950.0 * 5.40, 2)
    ELSE NULL END;
  IF v_amount IS NULL THEN RAISE EXCEPTION 'Moeda não suportada.'; END IF;

  IF v_meth LIKE 'EXPRESS%' OR v_meth LIKE 'MULTICAIXA%' THEN v_meth := 'EXPRESS';
  ELSIF v_meth LIKE 'UNITEL%' THEN v_meth := 'UNITEL';
  ELSIF v_meth LIKE 'REMITLY%' THEN v_meth := 'REMITLY';
  ELSE RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;

  IF p_proof_url IS NULL OR split_part(trim(p_proof_url), '/', 1) <> v_uid::text THEN
    RAISE EXCEPTION 'Comprovativo inválido para este utilizador.';
  END IF;

  INSERT INTO public.subscription_payments (user_id, amount, currency, method, proof_url, status)
  VALUES (v_uid, v_amount, v_cur,
          v_meth || CASE WHEN length(v_details) > 20 THEN ' | ' || left(v_details, 400) ELSE '' END,
          trim(p_proof_url), 'PENDING')
  RETURNING id INTO v_pay_id;

  -- Renovar NÃO tira o acesso enquanto o pagamento é validado
  IF v_status <> 'active' THEN
    PERFORM set_config('app.skip_profile_guard', 'on', true);
    UPDATE public.profiles SET subscription_status = 'pending', updated_at = NOW() WHERE id = v_uid;
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_uid, 'SUBSCRIPTION_SUBMITTED',
          CASE WHEN v_status = 'active' THEN 'Pedido de renovação enviado' ELSE 'Pedido de assinatura enviado' END,
          v_meth || ' / ' || v_cur);

  RETURN jsonb_build_object('success', true, 'payment_id', v_pay_id, 'amount', v_amount, 'currency', v_cur,
                            'renewal', v_status = 'active');
END;
$$;

-- Aprovação (substitui a versão da 017): soma os meses à validade actual (renovar não perde dias)
CREATE OR REPLACE FUNCTION public.admin_process_subscription_payment(
  p_payment_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_payment RECORD;
  v_months INTEGER := public.econ('subscription_months', 6)::int;
  v_expires TIMESTAMPTZ;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar assinaturas.';
  END IF;
  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido. Use APPROVED ou REJECTED.';
  END IF;

  SELECT * INTO v_payment FROM public.subscription_payments WHERE id = p_payment_id FOR UPDATE;
  IF v_payment.id IS NULL THEN RAISE EXCEPTION 'Pagamento não encontrado.'; END IF;
  IF v_payment.status <> 'PENDING' THEN RAISE EXCEPTION 'Este pagamento já foi processado.'; END IF;

  UPDATE public.subscription_payments
  SET status = p_status,
      rejection_reason = CASE WHEN p_status = 'REJECTED' THEN p_rejection_reason ELSE NULL END,
      processed_at = NOW(), processed_by = v_admin, updated_at = NOW()
  WHERE id = p_payment_id;

  IF p_status = 'APPROVED' THEN
    UPDATE public.profiles
    SET subscription_status = 'active',
        subscription_onboarding_completed = true,
        subscription_expires_at =
          (GREATEST(NOW(), COALESCE(subscription_expires_at, NOW())) + (v_months * INTERVAL '1 month')),
        updated_at = NOW()
    WHERE id = v_payment.user_id
    RETURNING subscription_expires_at INTO v_expires;
  ELSE
    -- Rejeitar não rebaixa quem já é assinante; quem estava pendente volta a expirado/visitante
    UPDATE public.profiles
    SET subscription_status = CASE WHEN subscription_expires_at IS NOT NULL THEN 'expired' ELSE 'visitor' END,
        updated_at = NOW()
    WHERE id = v_payment.user_id AND subscription_status = 'pending';
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details, metadata)
  VALUES (v_payment.user_id, 'SUBSCRIPTION_' || p_status, 'Assinatura ' || lower(p_status),
          COALESCE(p_rejection_reason,
                   CASE WHEN p_status = 'APPROVED' THEN 'Válida até ' || to_char(v_expires, 'DD/MM/YYYY')
                        ELSE 'Processado pelo admin' END),
          jsonb_build_object('payment_id', p_payment_id, 'admin_id', v_admin));

  RETURN jsonb_build_object('success', true, 'status', p_status, 'expires_at', v_expires);
END;
$$;

-- Agendamento horário (se pg_cron existir); sem pg_cron a expiração acontece ao abrir o app
-- (refresh_my_subscription), ao pedir tarefas (021) e no painel admin
DO $$
BEGIN
  CREATE EXTENSION IF NOT EXISTS pg_cron;
  PERFORM cron.schedule('adx-expire-subscriptions', '5 * * * *', 'SELECT public.expire_subscriptions();');
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron indisponível (%). A expiração corre ao abrir o app e no painel admin.', SQLERRM;
END $$;

-- --------------------------------------------------------------------
-- 4) Afiliados: comissão em % quando o indicado PAGA
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.affiliate_commissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  affiliate_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL
    CHECK (source_type IN ('SUBSCRIPTION', 'SUBSCRIPTION_RENEWAL', 'ENGAGEMENT_ORDER', 'CAMPAIGN_REQUEST')),
  source_id UUID NOT NULL,
  base_amount_aoa NUMERIC(14, 2) NOT NULL,
  pct NUMERIC(5, 2) NOT NULL,
  amount_aoa NUMERIC(14, 2) NOT NULL CHECK (amount_aoa > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_affiliate_commission_source UNIQUE (source_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_aff_comm_affiliate ON public.affiliate_commissions (affiliate_user_id, created_at DESC);

ALTER TABLE public.affiliate_commissions ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.affiliate_commissions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.affiliate_commissions TO service_role;
DROP POLICY IF EXISTS "aff_comm_select" ON public.affiliate_commissions;
CREATE POLICY "aff_comm_select" ON public.affiliate_commissions
  FOR SELECT TO authenticated
  USING (affiliate_user_id = auth.uid() OR public.is_admin());

-- Falhas de comissão NÃO se perdem: ficam registadas e o admin pode reprocessá-las
CREATE TABLE IF NOT EXISTS public.affiliate_commission_failures (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  referred_user_id UUID NOT NULL,
  source_type TEXT NOT NULL,
  source_id UUID NOT NULL,
  base_amount_aoa NUMERIC(14, 2),
  pct NUMERIC(5, 2),
  error TEXT,
  attempts INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ,
  CONSTRAINT uq_comm_failure UNIQUE (source_type, source_id)
);
ALTER TABLE public.affiliate_commission_failures ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.affiliate_commission_failures TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.affiliate_commission_failures TO service_role;
DROP POLICY IF EXISTS "comm_failures_admin" ON public.affiliate_commission_failures;
CREATE POLICY "comm_failures_admin" ON public.affiliate_commission_failures
  FOR SELECT TO authenticated USING (public.is_admin());

CREATE OR REPLACE FUNCTION public._log_commission_failure(
  p_referred UUID, p_type TEXT, p_source UUID, p_base NUMERIC, p_pct NUMERIC, p_error TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  INSERT INTO public.affiliate_commission_failures
    (referred_user_id, source_type, source_id, base_amount_aoa, pct, error)
  VALUES (p_referred, p_type, p_source, p_base, p_pct, left(p_error, 500))
  ON CONFLICT (source_type, source_id) DO UPDATE
    SET attempts = public.affiliate_commission_failures.attempts + 1,
        error = EXCLUDED.error,
        resolved_at = NULL;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'não foi possível registar a falha de comissão (%): %', p_source, SQLERRM;
END;
$$;

CREATE OR REPLACE FUNCTION public._pay_affiliate_commission(
  p_referred UUID, p_type TEXT, p_source UUID, p_base_aoa NUMERIC, p_pct NUMERIC
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_aff UUID;
  v_amount NUMERIC(14, 2);
  v_rows INTEGER;
BEGIN
  IF p_base_aoa IS NULL OR p_base_aoa <= 0 OR p_pct IS NULL OR p_pct <= 0 THEN RETURN; END IF;

  SELECT invited_by INTO v_aff FROM public.profiles WHERE id = p_referred;
  IF v_aff IS NULL OR v_aff = p_referred THEN RETURN; END IF;
  -- o afiliado precisa de ter assinatura ativa para receber
  IF NOT public._is_active_subscriber(v_aff) THEN RETURN; END IF;

  v_amount := round(p_base_aoa * p_pct / 100.0, 2);
  IF v_amount <= 0 THEN RETURN; END IF;

  INSERT INTO public.affiliate_commissions
    (affiliate_user_id, referred_user_id, source_type, source_id, base_amount_aoa, pct, amount_aoa)
  VALUES (v_aff, p_referred, p_type, p_source, p_base_aoa, p_pct, v_amount)
  ON CONFLICT (source_type, source_id) DO NOTHING;
  GET DIAGNOSTICS v_rows = ROW_COUNT;
  IF v_rows = 0 THEN RETURN; END IF;   -- já pago

  PERFORM public._credit_wallet(
    v_aff, v_amount, 'AFFILIATE_COMMISSION',
    'Comissão ' || p_pct::text || '% — ' ||
      CASE p_type WHEN 'SUBSCRIPTION' THEN 'assinatura de utilizador indicado'
                  WHEN 'SUBSCRIPTION_RENEWAL' THEN 'renovação de utilizador indicado'
                  WHEN 'ENGAGEMENT_ORDER' THEN 'pedido da loja de utilizador indicado'
                  ELSE 'campanha de utilizador indicado' END,
    p_source::text);

  UPDATE public.affiliate_profiles
  SET total_earned = total_earned + v_amount, updated_at = NOW()
  WHERE user_id = v_aff;

  BEGIN
    PERFORM public.refresh_user_level(v_aff);
  EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'refresh_user_level falhou para %: %', v_aff, SQLERRM;
  END;
END;
$$;

-- Primeira assinatura do indicado: conclui o convite, paga o bónus e conta o indicado
CREATE OR REPLACE FUNCTION public._complete_referral(p_referred UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_ref RECORD;
  v_bonus NUMERIC := public.econ('referred_bonus_aoa', 250);
BEGIN
  UPDATE public.affiliate_referrals
  SET status = 'COMPLETED', bonus_user = v_bonus
  WHERE referred_user_id = p_referred AND status = 'PENDING'
  RETURNING * INTO v_ref;
  IF v_ref.id IS NULL THEN RETURN; END IF;

  PERFORM public._credit_wallet(p_referred, v_bonus, 'SIGNUP_BONUS',
                                'Bónus de convite — assinatura ativada', v_ref.affiliate_code);

  UPDATE public.affiliate_profiles
  SET total_referrals = total_referrals + 1, updated_at = NOW()
  WHERE user_id = v_ref.affiliate_user_id;

  PERFORM set_config('app.skip_profile_guard', 'on', true);
  UPDATE public.profiles SET referred_completed = true WHERE id = p_referred;
END;
$$;

CREATE OR REPLACE FUNCTION public.trg_commission_subscription()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_renewal BOOLEAN;
  v_type TEXT;
  v_base NUMERIC;
  v_pct NUMERIC;
BEGIN
  IF NEW.status = 'APPROVED' AND OLD.status IS DISTINCT FROM 'APPROVED' THEN
    v_renewal := EXISTS (
      SELECT 1 FROM public.subscription_payments
      WHERE user_id = NEW.user_id AND status = 'APPROVED' AND id <> NEW.id
    );
    v_type := CASE WHEN v_renewal THEN 'SUBSCRIPTION_RENEWAL' ELSE 'SUBSCRIPTION' END;
    v_base := public._to_aoa(NEW.amount, NEW.currency);
    v_pct := CASE WHEN v_renewal THEN public.econ('aff_subscription_renewal_pct', 10)
                  ELSE public.econ('aff_subscription_pct', 20) END;
    BEGIN
      IF NOT v_renewal THEN
        PERFORM public._complete_referral(NEW.user_id);
      END IF;
      PERFORM public._pay_affiliate_commission(NEW.user_id, v_type, NEW.id, v_base, v_pct);
    EXCEPTION WHEN OTHERS THEN
      -- A aprovação da assinatura não pode falhar por causa da comissão, mas a falha fica REGISTADA
      -- (affiliate_commission_failures) e pode ser reprocessada pelo admin.
      PERFORM public._log_commission_failure(NEW.user_id, v_type, NEW.id, v_base, v_pct, SQLERRM);
      RAISE WARNING 'comissão de assinatura falhou (%): %', NEW.id, SQLERRM;
    END;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.trg_commission_engagement()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_base NUMERIC;
  v_pct NUMERIC;
BEGIN
  IF NEW.status IN ('APPROVED', 'PROCESSING', 'COMPLETED') AND OLD.status = 'PENDING' THEN
    v_base := public._to_aoa(NEW.total_price, NEW.currency);
    v_pct := public.econ('aff_engagement_pct', 10);
    BEGIN
      PERFORM public._pay_affiliate_commission(NEW.user_id, 'ENGAGEMENT_ORDER', NEW.id, v_base, v_pct);
    EXCEPTION WHEN OTHERS THEN
      PERFORM public._log_commission_failure(NEW.user_id, 'ENGAGEMENT_ORDER', NEW.id, v_base, v_pct, SQLERRM);
      RAISE WARNING 'comissão de pedido falhou (%): %', NEW.id, SQLERRM;
    END;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.trg_commission_campaign_request()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_base NUMERIC;
  v_pct NUMERIC;
BEGIN
  IF NEW.status IN ('APPROVED', 'IN_PROGRESS', 'COMPLETED') AND OLD.status = 'PENDING' THEN
    v_base := CASE WHEN NEW.amount_paid IS NOT NULL AND NEW.amount_paid > 0
                   THEN public._to_aoa(NEW.amount_paid, NEW.currency)
                   ELSE public._to_aoa(NEW.cost_usd, 'USD') END;
    v_pct := public.econ('aff_campaign_request_pct', 10);
    BEGIN
      PERFORM public._pay_affiliate_commission(NEW.user_id, 'CAMPAIGN_REQUEST', NEW.id, v_base, v_pct);
    EXCEPTION WHEN OTHERS THEN
      PERFORM public._log_commission_failure(NEW.user_id, 'CAMPAIGN_REQUEST', NEW.id, v_base, v_pct, SQLERRM);
      RAISE WARNING 'comissão de campanha falhou (%): %', NEW.id, SQLERRM;
    END;
  END IF;
  RETURN NEW;
END;
$$;

-- Reprocessa as comissões que falharam (idempotente: a tabela de comissões tem chave única por origem)
CREATE OR REPLACE FUNCTION public.admin_retry_commission_failures()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  r RECORD;
  v_ok INTEGER := 0;
  v_fail INTEGER := 0;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;

  FOR r IN SELECT * FROM public.affiliate_commission_failures WHERE resolved_at IS NULL ORDER BY created_at LIMIT 200
  LOOP
    BEGIN
      IF r.source_type = 'SUBSCRIPTION' THEN
        PERFORM public._complete_referral(r.referred_user_id);
      END IF;
      PERFORM public._pay_affiliate_commission(r.referred_user_id, r.source_type, r.source_id, r.base_amount_aoa, r.pct);
      UPDATE public.affiliate_commission_failures SET resolved_at = NOW() WHERE id = r.id;
      v_ok := v_ok + 1;
    EXCEPTION WHEN OTHERS THEN
      UPDATE public.affiliate_commission_failures
      SET attempts = attempts + 1, error = left(SQLERRM, 500) WHERE id = r.id;
      v_fail := v_fail + 1;
    END;
  END LOOP;

  RETURN jsonb_build_object('success', true, 'resolved', v_ok, 'still_failing', v_fail);
END;
$$;

DROP TRIGGER IF EXISTS trg_subscription_commission ON public.subscription_payments;
CREATE TRIGGER trg_subscription_commission
AFTER UPDATE OF status ON public.subscription_payments
FOR EACH ROW EXECUTE FUNCTION public.trg_commission_subscription();

DROP TRIGGER IF EXISTS trg_engagement_commission ON public.engagement_orders;
CREATE TRIGGER trg_engagement_commission
AFTER UPDATE OF status ON public.engagement_orders
FOR EACH ROW EXECUTE FUNCTION public.trg_commission_engagement();

DROP TRIGGER IF EXISTS trg_campaign_request_commission ON public.campaign_requests;
CREATE TRIGGER trg_campaign_request_commission
AFTER UPDATE OF status ON public.campaign_requests
FOR EACH ROW EXECUTE FUNCTION public.trg_commission_campaign_request();

-- Setup do primeiro login (substitui a versão da 008): REGISTA o convite, mas já não paga nada.
-- Antes pagava 250 + 500 Kz logo no registo, sem o indicado pagar — contas falsas rendiam dinheiro.
CREATE OR REPLACE FUNCTION public.complete_account_setup(
  p_user_id UUID,
  p_name TEXT,
  p_phone TEXT,
  p_primary_link TEXT DEFAULT NULL,
  p_invite_code TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_first_login BOOLEAN;
  v_clean_code TEXT;
  v_aff_user UUID;
  v_aff_code TEXT;
  v_referral_code TEXT;
  v_invite_registered BOOLEAN := FALSE;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;
  IF v_caller != p_user_id AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permissão negada.';
  END IF;

  SELECT first_login INTO v_first_login FROM public.profiles WHERE id = p_user_id;
  IF v_first_login IS NOT TRUE THEN
    RETURN jsonb_build_object('success', false, 'message', 'O setup desta conta já foi concluído.');
  END IF;

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (p_user_id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  SELECT referral_code INTO v_referral_code FROM public.profiles WHERE id = p_user_id;
  IF v_referral_code IS NULL OR length(trim(v_referral_code)) = 0 THEN
    v_referral_code := 'ADX' || upper(substr(replace(p_user_id::text, '-', ''), 1, 8));
  END IF;

  IF p_invite_code IS NOT NULL AND length(trim(p_invite_code)) > 0 THEN
    v_clean_code := upper(trim(p_invite_code));

    SELECT ap.user_id, ap.affiliate_code INTO v_aff_user, v_aff_code
    FROM public.affiliate_profiles ap
    WHERE upper(ap.affiliate_code) = v_clean_code AND ap.is_active = true
    LIMIT 1;

    IF v_aff_user IS NULL THEN
      SELECT p.id, COALESCE(p.custom_affiliate_code, p.referral_code) INTO v_aff_user, v_aff_code
      FROM public.profiles p
      WHERE p.id != p_user_id
        AND p.is_active = true
        AND (upper(COALESCE(p.referral_code, '')) = v_clean_code
             OR upper(COALESCE(p.custom_affiliate_code, '')) = v_clean_code)
      LIMIT 1;
    END IF;

    IF v_aff_user IS NOT NULL AND v_aff_user != p_user_id
       AND NOT EXISTS (SELECT 1 FROM public.affiliate_referrals WHERE referred_user_id = p_user_id) THEN
      INSERT INTO public.affiliate_referrals (
        affiliate_user_id, referred_user_id, affiliate_code, bonus_user, commission_affiliate, status
      ) VALUES (
        v_aff_user, p_user_id, v_clean_code, public.econ('referred_bonus_aoa', 250), 0.00, 'PENDING'
      );
      PERFORM set_config('app.skip_profile_guard', 'on', true);   -- invited_by é protegido pela guarda
      UPDATE public.profiles SET invited_by = v_aff_user WHERE id = p_user_id;
      v_invite_registered := TRUE;
    END IF;
  END IF;

  UPDATE public.profiles
  SET name = COALESCE(NULLIF(trim(p_name), ''), name),
      phone = COALESCE(NULLIF(trim(p_phone), ''), phone),
      primary_link = NULLIF(trim(p_primary_link), ''),
      referral_code = v_referral_code,
      first_login = false,
      updated_at = NOW()
  WHERE id = p_user_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (p_user_id, 'ACCOUNT_SETUP_COMPLETED', 'Configuração inicial concluída',
          CASE WHEN v_invite_registered THEN 'Convite registado: o bónus é creditado ao ativar a assinatura.'
               ELSE 'Concluído sem código de convite.' END);

  RETURN jsonb_build_object(
    'success', true,
    'message', CASE WHEN v_invite_registered
      THEN 'Conta configurada! O seu bónus de convite é creditado quando ativar a assinatura.'
      ELSE 'Conta configurada com sucesso!' END,
    'bonus_applied', false,
    'invite_registered', v_invite_registered
  );
END;
$$;

-- --------------------------------------------------------------------
-- 5) Campanhas: participação + pagamento por resultado financeiro
-- --------------------------------------------------------------------
ALTER TABLE public.campaigns
  ADD COLUMN IF NOT EXISTS campaign_type TEXT NOT NULL DEFAULT 'collective'
    CHECK (campaign_type IN ('collective', 'affiliate'));
UPDATE public.campaigns SET campaign_type = 'affiliate'
WHERE campaign_type = 'collective' AND instructions ILIKE '%Tipo: affiliate%';

CREATE TABLE IF NOT EXISTS public.campaign_results (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  revenue_aoa NUMERIC(14, 2) NOT NULL CHECK (revenue_aoa > 0),
  pool_pct NUMERIC(5, 2) NOT NULL,
  pool_aoa NUMERIC(14, 2) NOT NULL,
  participants INTEGER NOT NULL CHECK (participants > 0),
  per_participant_aoa NUMERIC(14, 2) NOT NULL,
  note TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Chave de idempotência: o mesmo pedido (duplo toque, repetição de rede) nunca paga duas vezes
ALTER TABLE public.campaign_results ADD COLUMN IF NOT EXISTS request_key TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS uq_campaign_results_request_key
  ON public.campaign_results (campaign_id, request_key) WHERE request_key IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.campaign_result_payouts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  result_id UUID NOT NULL REFERENCES public.campaign_results(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount_aoa NUMERIC(14, 2) NOT NULL CHECK (amount_aoa > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_result_payout UNIQUE (result_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_result_payouts_user ON public.campaign_result_payouts (user_id, created_at DESC);

ALTER TABLE public.campaign_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_result_payouts ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.campaign_results, public.campaign_result_payouts TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.campaign_results, public.campaign_result_payouts TO service_role;

DROP POLICY IF EXISTS "campaign_results_select" ON public.campaign_results;
CREATE POLICY "campaign_results_select" ON public.campaign_results
  FOR SELECT TO authenticated USING (true);   -- transparência: todos veem os resultados registados
DROP POLICY IF EXISTS "result_payouts_select" ON public.campaign_result_payouts;
CREATE POLICY "result_payouts_select" ON public.campaign_result_payouts
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_admin());

-- "Participar": o assinante entra na campanha (antes o botão só abria o link e nada era registado)
CREATE OR REPLACE FUNCTION public.join_campaign(p_campaign_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_status TEXT;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF NOT public._is_active_subscriber(v_uid) THEN
    RAISE EXCEPTION 'É necessária uma assinatura ativa para participar.';
  END IF;
  SELECT status INTO v_status FROM public.campaigns WHERE id = p_campaign_id;
  IF v_status IS NULL THEN RAISE EXCEPTION 'Campanha não encontrada.'; END IF;
  IF v_status <> 'ACTIVE' THEN RAISE EXCEPTION 'Esta campanha não está ativa.'; END IF;

  INSERT INTO public.campaign_assignments (campaign_id, user_id, status)
  VALUES (p_campaign_id, v_uid, 'IN_PROGRESS')
  ON CONFLICT (campaign_id, user_id) DO NOTHING;

  RETURN jsonb_build_object('success', true);
END;
$$;

-- "Concluí": marca a participação como feita (não paga nada; só conta para a partilha dos resultados)
CREATE OR REPLACE FUNCTION public.complete_campaign_participation(p_campaign_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_a RECORD;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF NOT public._is_active_subscriber(v_uid) THEN
    RAISE EXCEPTION 'É necessária uma assinatura ativa.';
  END IF;

  SELECT * INTO v_a FROM public.campaign_assignments
  WHERE campaign_id = p_campaign_id AND user_id = v_uid FOR UPDATE;
  IF v_a.id IS NULL THEN RAISE EXCEPTION 'Primeiro toque em Participar.'; END IF;
  IF v_a.status = 'COMPLETED' THEN
    RETURN jsonb_build_object('success', true, 'already', true);
  END IF;
  IF v_a.status = 'CANCELLED' THEN RAISE EXCEPTION 'A sua participação foi cancelada.'; END IF;

  UPDATE public.campaign_assignments SET status = 'COMPLETED', completed_at = NOW() WHERE id = v_a.id;
  RETURN jsonb_build_object('success', true);
END;
$$;

-- Admin regista um RESULTADO FINANCEIRO e a partilha é paga a todos os participantes que concluíram.
-- Proteções contra pagamento repetido:
--  1) p_request_key (gerada pelo ecrã): o mesmo pedido repetido devolve o resultado já registado, sem pagar;
--  2) o mesmo valor na mesma campanha nos últimos 15 minutos exige CONFIRMAÇÃO explícita (p_confirm_similar);
--  3) a campanha fica bloqueada (FOR UPDATE) durante o processamento: pedidos simultâneos são sequenciais.
DROP FUNCTION IF EXISTS public.admin_register_campaign_result(UUID, NUMERIC, TEXT);
DROP FUNCTION IF EXISTS public.admin_register_campaign_result(UUID, NUMERIC, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.admin_register_campaign_result(
  p_campaign_id UUID, p_revenue_aoa NUMERIC, p_note TEXT DEFAULT NULL, p_request_key TEXT DEFAULT NULL,
  p_confirm_similar BOOLEAN DEFAULT FALSE
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_camp RECORD;
  v_prev RECORD;
  v_pct NUMERIC;
  v_pool NUMERIC(14, 2);
  v_users UUID[];
  v_n INTEGER;
  v_each NUMERIC(14, 2);
  v_result_id UUID;
  v_u UUID;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;
  IF p_revenue_aoa IS NULL OR p_revenue_aoa <= 0 THEN
    RAISE EXCEPTION 'Indique o resultado financeiro (Kz) maior que zero.';
  END IF;

  SELECT * INTO v_camp FROM public.campaigns WHERE id = p_campaign_id FOR UPDATE;
  IF v_camp.id IS NULL THEN RAISE EXCEPTION 'Campanha não encontrada.'; END IF;

  -- 1) mesmo pedido repetido → devolve o que já foi pago
  IF p_request_key IS NOT NULL AND length(trim(p_request_key)) > 0 THEN
    SELECT * INTO v_prev FROM public.campaign_results
    WHERE campaign_id = p_campaign_id AND request_key = p_request_key;
    IF v_prev.id IS NOT NULL THEN
      RETURN jsonb_build_object('success', true, 'duplicate', true, 'pool_aoa', v_prev.pool_aoa,
                                'participants', v_prev.participants,
                                'per_participant_aoa', v_prev.per_participant_aoa);
    END IF;
  END IF;

  -- 2) resultado igual há pouco tempo: pede CONFIRMAÇÃO explícita (pode ser legítimo; não é bloqueio rígido)
  IF NOT COALESCE(p_confirm_similar, FALSE) AND EXISTS (
    SELECT 1 FROM public.campaign_results
    WHERE campaign_id = p_campaign_id AND revenue_aoa = p_revenue_aoa
      AND created_at > NOW() - INTERVAL '15 minutes'
  ) THEN
    RAISE EXCEPTION 'CONFIRMAR_RESULTADO_SEMELHANTE: já existe um resultado com este valor nesta campanha há menos de 15 minutos. Confirme se é um resultado novo.';
  END IF;

  v_pct := CASE v_camp.campaign_type
             WHEN 'affiliate' THEN public.econ('pool_pct_affiliate', 60)
             ELSE public.econ('pool_pct_collective', 50) END;
  v_pool := round(p_revenue_aoa * v_pct / 100.0, 2);

  SELECT array_agg(ca.user_id) INTO v_users
  FROM public.campaign_assignments ca
  WHERE ca.campaign_id = p_campaign_id
    AND ca.status = 'COMPLETED'
    AND public._is_active_subscriber(ca.user_id);
  v_n := COALESCE(array_length(v_users, 1), 0);
  IF v_n = 0 THEN
    RAISE EXCEPTION 'Ainda não há participantes que concluíram esta campanha.';
  END IF;

  v_each := floor(v_pool / v_n * 100) / 100;    -- arredonda para baixo: nunca paga mais que o pool
  IF v_each <= 0 THEN
    RAISE EXCEPTION 'O resultado é demasiado pequeno para repartir por % participantes.', v_n;
  END IF;

  INSERT INTO public.campaign_results
    (campaign_id, revenue_aoa, pool_pct, pool_aoa, participants, per_participant_aoa, note, created_by, request_key)
  VALUES (p_campaign_id, p_revenue_aoa, v_pct, v_pool, v_n, v_each, p_note, v_admin,
          NULLIF(trim(coalesce(p_request_key, '')), ''))
  RETURNING id INTO v_result_id;

  FOREACH v_u IN ARRAY v_users
  LOOP
    INSERT INTO public.campaign_result_payouts (result_id, campaign_id, user_id, amount_aoa)
    VALUES (v_result_id, p_campaign_id, v_u, v_each)
    ON CONFLICT (result_id, user_id) DO NOTHING;

    PERFORM public._credit_wallet(
      v_u, v_each, 'CAMPAIGN_REWARD',
      'Partilha do resultado da campanha: ' || v_camp.title, v_result_id::text);
  END LOOP;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_admin, 'CAMPAIGN_RESULT_REGISTERED', 'Resultado de campanha registado',
          v_camp.title || ': ' || p_revenue_aoa || ' Kz → ' || v_n || ' participantes × ' || v_each || ' Kz');

  RETURN jsonb_build_object('success', true, 'duplicate', false, 'pool_aoa', v_pool,
                            'participants', v_n, 'per_participant_aoa', v_each);
END;
$$;

-- Função antiga de pagamento fixo por "concluir": já estava fechada na 021; fica removida (código morto)
DROP FUNCTION IF EXISTS public.complete_campaign_execution(UUID);

-- --------------------------------------------------------------------
-- 6) Permissões
-- --------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.econ(TEXT, NUMERIC) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._to_aoa(NUMERIC, TEXT) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._is_active_subscriber(UUID) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._credit_wallet(UUID, NUMERIC, TEXT, TEXT, TEXT) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._pay_affiliate_commission(UUID, TEXT, UUID, NUMERIC, NUMERIC) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._complete_referral(UUID) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.expire_subscriptions() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_commission_subscription() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_commission_engagement() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_commission_campaign_request() FROM PUBLIC, anon, authenticated;

REVOKE ALL ON FUNCTION public.refresh_my_subscription() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.refresh_my_subscription() TO authenticated;
REVOKE ALL ON FUNCTION public.join_campaign(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.join_campaign(UUID) TO authenticated;
REVOKE ALL ON FUNCTION public.complete_campaign_participation(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.complete_campaign_participation(UUID) TO authenticated;
REVOKE ALL ON FUNCTION public.admin_register_campaign_result(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_register_campaign_result(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO authenticated;
REVOKE ALL ON FUNCTION public.admin_retry_commission_failures() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_retry_commission_failures() TO authenticated;
REVOKE ALL ON FUNCTION public._log_commission_failure(UUID, TEXT, UUID, NUMERIC, NUMERIC, TEXT) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_set_economy_setting(TEXT, NUMERIC) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_set_economy_setting(TEXT, NUMERIC) TO authenticated;
REVOKE ALL ON FUNCTION public.admin_set_community_setting(TEXT, NUMERIC, NUMERIC, INTEGER) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_set_community_setting(TEXT, NUMERIC, NUMERIC, INTEGER) TO authenticated;
-- as versões redefinidas mantêm as permissões da 017/008 (CREATE OR REPLACE não as altera)

NOTIFY pgrst, 'reload schema';
