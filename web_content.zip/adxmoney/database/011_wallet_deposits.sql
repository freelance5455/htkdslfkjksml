-- ====================================================================
-- 011 — Depósitos de carteira (carregar conta)
-- Utilizador envia comprovativo; admin aprova e credita o saldo.
-- Executar uma vez no SQL Editor do Supabase
-- ====================================================================

-- 1) Tipo DEPOSIT no ledger
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;

ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check CHECK (type IN (
    'SIGNUP_BONUS',
    'AFFILIATE_COMMISSION',
    'CAMPAIGN_REWARD',
    'CAMPAIGN_TOKEN',
    'DEPOSIT',
    'WITHDRAWAL_LOCK',
    'WITHDRAWAL_PAID',
    'WITHDRAWAL_REFUND',
    'MANUAL_ADJUSTMENT'
  ));

-- 2) Tabela wallet_deposits
CREATE TABLE IF NOT EXISTS public.wallet_deposits (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount NUMERIC(14, 2) NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL DEFAULT 'AOA',
  method TEXT NOT NULL,
  proof_url TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  rejection_reason TEXT,
  processed_at TIMESTAMPTZ,
  processed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wallet_deposits_user
  ON public.wallet_deposits (user_id, status);
CREATE INDEX IF NOT EXISTS idx_wallet_deposits_status
  ON public.wallet_deposits (status, created_at DESC);

ALTER TABLE public.wallet_deposits
  DROP CONSTRAINT IF EXISTS fk_wallet_deposits_profiles;
ALTER TABLE public.wallet_deposits
  ADD CONSTRAINT fk_wallet_deposits_profiles
  FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

ALTER TABLE public.wallet_deposits ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON TABLE public.wallet_deposits TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.wallet_deposits TO service_role;

DROP POLICY IF EXISTS "wallet_deposits_select" ON public.wallet_deposits;
CREATE POLICY "wallet_deposits_select" ON public.wallet_deposits
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "wallet_deposits_insert" ON public.wallet_deposits;
CREATE POLICY "wallet_deposits_insert" ON public.wallet_deposits
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "wallet_deposits_admin_update" ON public.wallet_deposits;
CREATE POLICY "wallet_deposits_admin_update" ON public.wallet_deposits
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 3) Utilizador submete depósito
CREATE OR REPLACE FUNCTION public.submit_wallet_deposit(
  p_amount NUMERIC,
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_id UUID;
  v_amount NUMERIC;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  v_amount := ROUND(COALESCE(p_amount, 0)::numeric, 2);
  IF v_amount < 1000 THEN
    RAISE EXCEPTION 'O valor mínimo de depósito é 1.000 Kz.';
  END IF;
  IF v_amount > 5000000 THEN
    RAISE EXCEPTION 'O valor máximo de depósito é 5.000.000 Kz.';
  END IF;

  IF p_method IS NULL OR length(trim(p_method)) < 3 THEN
    RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;

  IF p_proof_url IS NULL OR length(trim(p_proof_url)) < 3 THEN
    RAISE EXCEPTION 'Comprovativo obrigatório.';
  END IF;

  INSERT INTO public.wallet_deposits (
    user_id, amount, currency, method, proof_url, status
  ) VALUES (
    v_uid,
    v_amount,
    COALESCE(NULLIF(trim(p_currency), ''), 'AOA'),
    trim(p_method),
    trim(p_proof_url),
    'PENDING'
  )
  RETURNING id INTO v_id;

  RETURN jsonb_build_object(
    'success', true,
    'id', v_id,
    'amount', v_amount,
    'status', 'PENDING'
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_wallet_deposit(NUMERIC, TEXT, TEXT, TEXT) TO authenticated;

-- 4) Admin aprova / rejeita (crédito só em APPROVED)
CREATE OR REPLACE FUNCTION public.admin_process_wallet_deposit(
  p_deposit_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_dep RECORD;
  v_wallet RECORD;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar depósitos.';
  END IF;

  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido. Use APPROVED ou REJECTED.';
  END IF;

  SELECT * INTO v_dep
  FROM public.wallet_deposits
  WHERE id = p_deposit_id
  FOR UPDATE;

  IF v_dep.id IS NULL THEN
    RAISE EXCEPTION 'Depósito não encontrado.';
  END IF;

  IF v_dep.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Este depósito já foi processado.';
  END IF;

  IF p_status = 'REJECTED' THEN
    UPDATE public.wallet_deposits
    SET status = 'REJECTED',
        rejection_reason = NULLIF(trim(COALESCE(p_rejection_reason, '')), ''),
        processed_at = NOW(),
        processed_by = v_admin,
        updated_at = NOW()
    WHERE id = v_dep.id;

    RETURN jsonb_build_object('success', true, 'status', 'REJECTED');
  END IF;

  -- APPROVED → creditar carteira
  SELECT * INTO v_wallet
  FROM public.wallets
  WHERE user_id = v_dep.user_id
  FOR UPDATE;

  IF v_wallet.id IS NULL THEN
    INSERT INTO public.wallets (user_id, balance, reserved_balance)
    VALUES (v_dep.user_id, 0, 0)
    ON CONFLICT (user_id) DO NOTHING;

    SELECT * INTO v_wallet
    FROM public.wallets
    WHERE user_id = v_dep.user_id
    FOR UPDATE;
  END IF;

  UPDATE public.wallets
  SET balance = balance + v_dep.amount,
      updated_at = NOW()
  WHERE id = v_wallet.id;

  INSERT INTO public.wallet_transactions (
    wallet_id, user_id, type, amount, description, reference_id, status
  ) VALUES (
    v_wallet.id,
    v_dep.user_id,
    'DEPOSIT',
    v_dep.amount,
    'Depósito aprovado #' || left(v_dep.id::text, 8),
    v_dep.id::text,
    'COMPLETED'
  );

  UPDATE public.wallet_deposits
  SET status = 'APPROVED',
      processed_at = NOW(),
      processed_by = v_admin,
      updated_at = NOW()
  WHERE id = v_dep.id;

  RETURN jsonb_build_object(
    'success', true,
    'status', 'APPROVED',
    'credited', v_dep.amount
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_process_wallet_deposit(UUID, TEXT, TEXT) TO authenticated;

COMMENT ON TABLE public.wallet_deposits IS 'Pedidos de carregamento de saldo (comprovativo + aprovação admin)';
