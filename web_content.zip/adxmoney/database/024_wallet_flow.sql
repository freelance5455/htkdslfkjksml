-- ====================================================================
-- 024 — Fluxo diário da carteira (gráfico da Home)
-- Executar DEPOIS de 023. Idempotente. Só leitura de dados do próprio utilizador.
--
-- Antes: o gráfico era calculado no telemóvel com os últimos 100 movimentos (incompleto em 90 dias).
-- Agora: o servidor soma entradas/saídas por dia (fuso de Luanda) para qualquer janela até 366 dias.
-- ====================================================================

-- Compatibilidade com instalações antigas: se get_wallet_flow já existir com OUTRO tipo de retorno, o
-- CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso.
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname = 'get_wallet_flow'
      AND pg_get_function_result(p.oid) <> 'TABLE(day date, entradas numeric, saidas numeric)'
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

CREATE INDEX IF NOT EXISTS idx_wallet_tx_user_created
  ON public.wallet_transactions (user_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.get_wallet_flow(p_days INTEGER DEFAULT 60)
RETURNS TABLE (day DATE, entradas NUMERIC, saidas NUMERIC)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_days INTEGER := GREATEST(1, LEAST(COALESCE(p_days, 60), 366));
  v_today DATE := (NOW() AT TIME ZONE 'Africa/Luanda')::date;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  RETURN QUERY
  SELECT g.d::date AS day,
         COALESCE(SUM(t.amount) FILTER (WHERE t.amount > 0), 0)::numeric AS entradas,
         COALESCE(SUM(-t.amount) FILTER (WHERE t.amount < 0), 0)::numeric AS saidas
  FROM generate_series(
         (v_today - (v_days - 1))::timestamp,
         v_today::timestamp,
         INTERVAL '1 day'
       ) AS g(d)
  LEFT JOIN public.wallet_transactions t
    ON t.user_id = v_uid
   AND t.status = 'COMPLETED'
   AND t.created_at >= (g.d AT TIME ZONE 'Africa/Luanda')
   AND t.created_at <  ((g.d + INTERVAL '1 day') AT TIME ZONE 'Africa/Luanda')
  GROUP BY g.d
  ORDER BY g.d;
END;
$$;

REVOKE ALL ON FUNCTION public.get_wallet_flow(INTEGER) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_wallet_flow(INTEGER) TO authenticated, service_role;
