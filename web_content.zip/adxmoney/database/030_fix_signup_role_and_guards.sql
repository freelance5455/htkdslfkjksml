-- ====================================================================
-- 030 — Corrige escalada de privilégios no registo + triggers legados
-- Idempotente. Executar uma vez no SQL Editor (depois da 029).
--
-- PROBLEMA ENCONTRADO NA BASE REAL:
--  a) on_auth_user_created_profile -> handle_new_auth_user() lia o role de
--     raw_user_meta_data: signUp com {"role":"admin"} criava um ADMINISTRADOR.
--     (a handle_new_user() segura da 014 nem estava ligada a auth.users)
--  b) trg_protect_profile_privileged_columns revertia role/subscription_status
--     para qualquer chamada sem is_admin() (jobs, funções internas, o próprio
--     setup do teste), ignorando a guarda oficial (skip_profile_guard/service_role).
-- ====================================================================

-- 1) Registo: um único trigger, com a função segura da 014 (role sempre 'user')
DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Função legada: mesmo que algo a chame, nunca confia no role do cliente
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
BEGIN
  INSERT INTO public.profiles (id, email, first_name, role, subscription_status)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data ->> 'first_name', split_part(new.email, '@', 1)),
    'user',
    'visitor'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$function$;
REVOKE EXECUTE ON FUNCTION public.handle_new_auth_user() FROM PUBLIC, anon, authenticated;

-- 2) Guarda legada duplicada: remove (a oficial é protect_profile_sensitive_columns)
DROP TRIGGER IF EXISTS trg_protect_profile_privileged_columns ON public.profiles;
DROP FUNCTION IF EXISTS public.protect_profile_privileged_columns();

-- 3) A guarda oficial passa a cobrir também os campos que a legada protegia
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS suspension_reason TEXT;

CREATE OR REPLACE FUNCTION public.protect_profile_sensitive_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  IF current_setting('app.skip_profile_guard', true) = 'on' THEN
    RETURN NEW;
  END IF;

  IF COALESCE(auth.role(), '') = 'service_role' THEN
    RETURN NEW;
  END IF;

  IF public.is_admin() THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    NEW.role := OLD.role;
    NEW.subscription_status := OLD.subscription_status;
    NEW.subscription_expires_at := OLD.subscription_expires_at;
    NEW.subscription_onboarding_completed := OLD.subscription_onboarding_completed;
    NEW.invited_by := OLD.invited_by;
    NEW.referred_completed := OLD.referred_completed;
    NEW.is_active := OLD.is_active;
    NEW.member_level := OLD.member_level;
    NEW.priority_withdrawal := OLD.priority_withdrawal;
    NEW.level_updated_at := OLD.level_updated_at;
    NEW.custom_affiliate_code := OLD.custom_affiliate_code;
    NEW.suspension_reason := OLD.suspension_reason;
    IF OLD.first_login IS FALSE THEN
      NEW.first_login := FALSE;
    END IF;
    IF NEW.suspended_until IS DISTINCT FROM OLD.suspended_until THEN
      NEW.suspended_until := OLD.suspended_until;
    END IF;
  END IF;

  RETURN NEW;
END;
$fn$;
