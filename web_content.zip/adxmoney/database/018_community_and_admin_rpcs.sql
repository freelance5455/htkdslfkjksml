-- ====================================================================
-- 018 — Tarefas da comunidade e RPCs de admin
-- Validações no servidor; admin_assign_campaign e admin_toggle_affiliate.
-- Idempotente (CREATE OR REPLACE / IF NOT EXISTS). Executar uma vez no SQL Editor.
-- ====================================================================

-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = 'admin_assign_campaign' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_toggle_affiliate' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'complete_community_task' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'report_community_task' AND pg_get_function_result(p.oid) <> 'jsonb')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

-- Tarefas da comunidade: validações no servidor (assinatura ativa, tarefa ativa, limites, tempo mínimo)

DROP FUNCTION IF EXISTS public.complete_community_task(UUID);
CREATE OR REPLACE FUNCTION public.complete_community_task(p_task_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_queue RECORD;
  v_task RECORD;
  v_reward NUMERIC(10, 2);
  v_wallet_id UUID;
  v_sub TEXT;
  v_active BOOLEAN;
  v_daily_limit INTEGER;
  v_done_today INTEGER;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT subscription_status, is_active INTO v_sub, v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_sub IS DISTINCT FROM 'active' THEN RAISE EXCEPTION 'Assinatura activa necessária.'; END IF;

  SELECT * INTO v_queue FROM public.task_distribution_queue
  WHERE user_id = v_uid AND task_id = p_task_id AND status = 'ASSIGNED' FOR UPDATE;
  IF v_queue.id IS NULL THEN RAISE EXCEPTION 'Tarefa não encontrada ou já concluída.'; END IF;

  IF v_queue.assigned_at IS NOT NULL AND v_queue.assigned_at > NOW() - INTERVAL '15 seconds' THEN
    RAISE EXCEPTION 'Execute a tarefa antes de a confirmar.';
  END IF;

  SELECT * INTO v_task FROM public.community_tasks WHERE id = p_task_id FOR UPDATE;
  IF v_task.id IS NULL OR v_task.is_active IS NOT TRUE THEN
    RAISE EXCEPTION 'Esta tarefa já não está disponível.';
  END IF;
  IF v_task.current_completions >= v_task.max_completions THEN
    RAISE EXCEPTION 'Esta tarefa já atingiu o limite de participações.';
  END IF;

  SELECT daily_limit INTO v_daily_limit FROM public.community_settings WHERE platform = lower(v_task.platform);
  IF v_daily_limit IS NOT NULL THEN
    SELECT count(*) INTO v_done_today
    FROM public.task_distribution_queue q
    WHERE q.user_id = v_uid AND q.status = 'COMPLETED' AND lower(q.platform) = lower(v_task.platform)
      AND q.completed_at >= date_trunc('day', NOW());
    IF v_done_today >= v_daily_limit THEN
      RAISE EXCEPTION 'Limite diário desta plataforma atingido.';
    END IF;
  END IF;

  UPDATE public.task_distribution_queue SET status = 'COMPLETED', completed_at = NOW() WHERE id = v_queue.id;
  UPDATE public.community_tasks SET current_completions = current_completions + 1, updated_at = NOW() WHERE id = p_task_id;

  v_reward := COALESCE(v_task.reward_amount, 5.00);

  INSERT INTO public.wallets (user_id, balance, reserved_balance) VALUES (v_uid, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;
  SELECT id INTO v_wallet_id FROM public.wallets WHERE user_id = v_uid FOR UPDATE;

  UPDATE public.wallets SET balance = balance + v_reward, updated_at = NOW() WHERE id = v_wallet_id;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wallet_id, v_uid, 'CAMPAIGN_REWARD', v_reward, 'Tarefa de comunidade concluída', p_task_id::text, 'COMPLETED');

  RETURN jsonb_build_object('success', true, 'reward', v_reward);
END;
$$;

-- Denúncia: só de tarefas atribuídas ao próprio utilizador, uma vez por tarefa
CREATE OR REPLACE FUNCTION public.report_community_task(p_task_id UUID, p_reason TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF p_reason IS NULL OR length(trim(p_reason)) < 3 THEN
    RAISE EXCEPTION 'Motivo da denúncia é obrigatório.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.task_distribution_queue WHERE user_id = v_uid AND task_id = p_task_id) THEN
    RAISE EXCEPTION 'Tarefa não encontrada.';
  END IF;
  IF EXISTS (SELECT 1 FROM public.task_reports WHERE reporter_user_id = v_uid AND task_id = p_task_id) THEN
    RAISE EXCEPTION 'Já denunciou esta tarefa.';
  END IF;

  INSERT INTO public.task_reports (reporter_user_id, task_id, reason) VALUES (v_uid, p_task_id, left(trim(p_reason), 500));

  UPDATE public.task_distribution_queue SET status = 'REPORTED'
  WHERE user_id = v_uid AND task_id = p_task_id AND status = 'ASSIGNED';

  RETURN jsonb_build_object('success', true);
END;
$$;

-- RPCs chamadas pelo painel admin mas inexistentes no repositório
--    (se já existirem em produção com outra definição, REVER antes de correr este bloco)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_assign_campaign(p_campaign_id UUID, p_user_ids UUID[])
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_count INTEGER := 0;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem atribuir campanhas.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.campaigns WHERE id = p_campaign_id) THEN
    RAISE EXCEPTION 'Campanha não encontrada.';
  END IF;

  INSERT INTO public.campaign_assignments (campaign_id, user_id, status)
  SELECT p_campaign_id, p.id, 'ASSIGNED'
  FROM public.profiles p
  WHERE p.id = ANY (COALESCE(p_user_ids, ARRAY[]::UUID[])) AND p.is_active = true
  ON CONFLICT (campaign_id, user_id) DO NOTHING;
  GET DIAGNOSTICS v_count = ROW_COUNT;

  RETURN jsonb_build_object('success', true, 'assigned', v_count);
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_assign_campaign(UUID, UUID[]) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_toggle_affiliate(
  p_user_id UUID, p_is_active BOOLEAN, p_custom_code TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_code TEXT;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem gerir afiliados.';
  END IF;

  v_code := upper(NULLIF(trim(COALESCE(p_custom_code, '')), ''));
  IF v_code IS NOT NULL AND v_code !~ '^[A-Z0-9_-]{3,20}$' THEN
    RAISE EXCEPTION 'Código inválido (3–20 caracteres A–Z, 0–9, _ ou -).';
  END IF;

  INSERT INTO public.affiliate_profiles (user_id, affiliate_code, is_active)
  VALUES (p_user_id,
          COALESCE(v_code, 'ADX' || upper(substr(replace(p_user_id::text, '-', ''), 1, 8))),
          p_is_active)
  ON CONFLICT (user_id) DO UPDATE
  SET is_active = EXCLUDED.is_active,
      affiliate_code = COALESCE(v_code, public.affiliate_profiles.affiliate_code),
      updated_at = NOW();

  RETURN jsonb_build_object('success', true);
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_toggle_affiliate(UUID, BOOLEAN, TEXT) TO authenticated;

-- report_community_task: as permissões são repostas (a função pode ter sido recriada pela proteção acima)
REVOKE ALL ON FUNCTION public.report_community_task(UUID, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.report_community_task(UUID, TEXT) TO authenticated;
