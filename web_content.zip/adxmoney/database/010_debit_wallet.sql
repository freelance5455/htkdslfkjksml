-- ====================================================================
-- 010 — RPC debit_wallet
-- Usado por CampaignRequestModal ao pagar Token de Solicitação com saldo
-- Executar uma vez no SQL Editor do Supabase
-- ====================================================================

-- 1) Permitir tipo CAMPAIGN_TOKEN no ledger
ALTER TABLE public.wallet_transactions
  DROP CONSTRAINT IF EXISTS wallet_transactions_type_check;

ALTER TABLE public.wallet_transactions
  ADD CONSTRAINT wallet_transactions_type_check CHECK (type IN (
    'SIGNUP_BONUS',
    'AFFILIATE_COMMISSION',
    'CAMPAIGN_REWARD',
    'CAMPAIGN_TOKEN',
    'WITHDRAWAL_LOCK',
    'WITHDRAWAL_PAID',
    'WITHDRAWAL_REFUND',
    'MANUAL_ADJUSTMENT'
  ));

-- 2) RPC de débito atómico
CREATE OR REPLACE FUNCTION public.debit_wallet(
  p_user_id UUID,
  p_amount NUMERIC,
  p_description TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_wallet RECORD;
  v_tx_id UUID;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  IF v_caller != p_user_id AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permissão negada.';
  END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'O valor a debitar deve ser maior que zero.';
  END IF;

  SELECT * INTO v_wallet
  FROM public.wallets
  WHERE user_id = p_user_id
  FOR UPDATE;

  IF v_wallet.id IS NULL THEN
    INSERT INTO public.wallets (user_id, balance, reserved_balance)
    VALUES (p_user_id, 0.00, 0.00)
    ON CONFLICT (user_id) DO NOTHING;

    SELECT * INTO v_wallet
    FROM public.wallets
    WHERE user_id = p_user_id
    FOR UPDATE;
  END IF;

  IF v_wallet.id IS NULL THEN
    RAISE EXCEPTION 'Carteira não encontrada.';
  END IF;

  IF v_wallet.balance < p_amount THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Saldo insuficiente.',
      'balance', v_wallet.balance,
      'required', p_amount
    );
  END IF;

  UPDATE public.wallets
  SET balance = balance - p_amount,
      updated_at = NOW()
  WHERE id = v_wallet.id;

  INSERT INTO public.wallet_transactions (
    wallet_id,
    user_id,
    type,
    amount,
    description,
    reference_id,
    status
  ) VALUES (
    v_wallet.id,
    p_user_id,
    'CAMPAIGN_TOKEN',
    -p_amount,
    COALESCE(NULLIF(trim(p_description), ''), 'Débito de Token de Solicitação de Campanha'),
    NULL,
    'COMPLETED'
  )
  RETURNING id INTO v_tx_id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (
    p_user_id,
    'WALLET_DEBIT',
    'Débito de saldo',
    COALESCE(NULLIF(trim(p_description), ''), 'Token de campanha') || ' | Valor: ' || p_amount
  );

  RETURN jsonb_build_object(
    'success', true,
    'transaction_id', v_tx_id,
    'amount', p_amount,
    'new_balance', v_wallet.balance - p_amount
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.debit_wallet(UUID, NUMERIC, TEXT) TO authenticated;

COMMENT ON FUNCTION public.debit_wallet(UUID, NUMERIC, TEXT) IS
  'Debita saldo da carteira de forma atómica (Token de Solicitação de Campanha)';
