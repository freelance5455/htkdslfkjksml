-- ====================================================================
-- 035 — Enfileirar push nos eventos de negócio (cirúrgico)
-- Usa public.enqueue_notification (034). Não altera lógica financeira.
-- Idempotente.
-- ====================================================================

-- Helper: dispara enqueue sem falhar a transacção principal
CREATE OR REPLACE FUNCTION public._notify_user(
  p_user_id    UUID,
  p_event_type TEXT,
  p_title      TEXT,
  p_body       TEXT,
  p_data       JSONB DEFAULT '{}'::jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF p_user_id IS NULL THEN
    RETURN;
  END IF;
  BEGIN
    PERFORM public.enqueue_notification(p_user_id, p_event_type, p_title, p_body, COALESCE(p_data, '{}'::jsonb));
  EXCEPTION WHEN OTHERS THEN
    RAISE WARNING '[_notify_user] %', SQLERRM;
  END;
END;
$$;

REVOKE ALL ON FUNCTION public._notify_user(UUID, TEXT, TEXT, TEXT, JSONB) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public._notify_user(UUID, TEXT, TEXT, TEXT, JSONB) TO service_role;

-- --------------------------------------------------------------------
-- Depósitos
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.trg_notify_wallet_deposit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'APPROVED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'deposit',
        'Depósito aprovado',
        'O seu depósito foi creditado na carteira.',
        jsonb_build_object('path', '/app', 'deposit_id', NEW.id)
      );
    ELSIF NEW.status = 'REJECTED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'deposit',
        'Depósito rejeitado',
        'O comprovativo de depósito não foi aceite. Verifique e tente de novo.',
        jsonb_build_object('path', '/app', 'deposit_id', NEW.id)
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_wallet_deposit ON public.wallet_deposits;
CREATE TRIGGER trg_notify_wallet_deposit
  AFTER UPDATE OF status ON public.wallet_deposits
  FOR EACH ROW EXECUTE FUNCTION public.trg_notify_wallet_deposit();

-- --------------------------------------------------------------------
-- Saques
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.trg_notify_withdrawal()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'APPROVED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'withdrawal',
        'Saque aprovado',
        'O seu pedido de saque foi aprovado e será processado.',
        jsonb_build_object('path', '/app', 'withdrawal_id', NEW.id)
      );
    ELSIF NEW.status = 'PAID' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'withdrawal',
        'Saque pago',
        'O valor do saque foi marcado como pago.',
        jsonb_build_object('path', '/app', 'withdrawal_id', NEW.id)
      );
    ELSIF NEW.status = 'REJECTED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'withdrawal',
        'Saque rejeitado',
        'O pedido de saque foi rejeitado. O saldo foi reposto se aplicável.',
        jsonb_build_object('path', '/app', 'withdrawal_id', NEW.id)
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_withdrawal ON public.withdrawals;
CREATE TRIGGER trg_notify_withdrawal
  AFTER UPDATE OF status ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.trg_notify_withdrawal();

-- --------------------------------------------------------------------
-- Assinatura (subscription_payments)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.trg_notify_subscription_payment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'APPROVED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'subscription',
        'Assinatura activada',
        'A sua assinatura ADXmoney está activa. Boas campanhas!',
        jsonb_build_object('path', '/app', 'payment_id', NEW.id)
      );
    ELSIF NEW.status = 'REJECTED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'subscription',
        'Assinatura não aprovada',
        'O pagamento da assinatura foi rejeitado. Envie um novo comprovativo se precisar.',
        jsonb_build_object('path', '/app', 'payment_id', NEW.id)
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_subscription_payment ON public.subscription_payments;
CREATE TRIGGER trg_notify_subscription_payment
  AFTER UPDATE OF status ON public.subscription_payments
  FOR EACH ROW EXECUTE FUNCTION public.trg_notify_subscription_payment();

-- --------------------------------------------------------------------
-- Provas de tarefa
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.trg_notify_task_proof()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status IN ('APPROVED', 'AUTO_APPROVED') THEN
      PERFORM public._notify_user(
        NEW.user_id, 'proof',
        'Prova aprovada',
        'A sua prova foi validada. A recompensa será creditada conforme as regras.',
        jsonb_build_object('path', '/app', 'proof_id', NEW.id)
      );
    ELSIF NEW.status = 'REJECTED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'proof',
        'Prova rejeitada',
        COALESCE(NULLIF(trim(NEW.review_note), ''), 'A prova enviada não foi aceite.'),
        jsonb_build_object('path', '/app', 'proof_id', NEW.id)
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_task_proof ON public.task_proofs;
CREATE TRIGGER trg_notify_task_proof
  AFTER UPDATE OF status ON public.task_proofs
  FOR EACH ROW EXECUTE FUNCTION public.trg_notify_task_proof();

-- --------------------------------------------------------------------
-- Pedidos de campanha
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.trg_notify_campaign_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'APPROVED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'campaign',
        'Campanha aprovada',
        'O seu pedido de campanha foi aprovado.',
        jsonb_build_object('path', '/app', 'request_id', NEW.id)
      );
    ELSIF NEW.status = 'REJECTED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'campaign',
        'Campanha rejeitada',
        'O pedido de campanha foi rejeitado. Consulte o saldo / reembolso se aplicável.',
        jsonb_build_object('path', '/app', 'request_id', NEW.id)
      );
    ELSIF NEW.status = 'COMPLETED' THEN
      PERFORM public._notify_user(
        NEW.user_id, 'campaign',
        'Campanha concluída',
        'A sua campanha foi marcada como concluída.',
        jsonb_build_object('path', '/app', 'request_id', NEW.id)
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_campaign_request ON public.campaign_requests;
CREATE TRIGGER trg_notify_campaign_request
  AFTER UPDATE OF status ON public.campaign_requests
  FOR EACH ROW EXECUTE FUNCTION public.trg_notify_campaign_request();

-- Permissões triggers (funções SECURITY DEFINER)
REVOKE ALL ON FUNCTION public.trg_notify_wallet_deposit() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_notify_withdrawal() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_notify_subscription_payment() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_notify_task_proof() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_notify_campaign_request() FROM PUBLIC, anon, authenticated;

-- --------------------------------------------------------------------
-- Admin: mensagem manual (opcional)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_enqueue_notification(
  p_user_id UUID,
  p_title   TEXT,
  p_body    TEXT,
  p_path    TEXT DEFAULT '/app'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_id UUID;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Acesso negado';
  END IF;
  v_id := public.enqueue_notification(
    p_user_id,
    'admin_message',
    left(COALESCE(p_title, 'Mensagem ADXmoney'), 120),
    left(COALESCE(p_body, ''), 500),
    jsonb_build_object('path', COALESCE(NULLIF(trim(p_path), ''), '/app'))
  );
  RETURN jsonb_build_object('success', true, 'queue_id', v_id);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_enqueue_notification(UUID, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_enqueue_notification(UUID, TEXT, TEXT, TEXT) TO authenticated, service_role;
