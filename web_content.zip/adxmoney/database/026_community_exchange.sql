-- ====================================================================
-- 026 — Troca de seguidores (tarefas comunitárias)
-- Executar DEPOIS de 021 e 025. Idempotente.
--
-- Regra de negócio:
--  • Quando um utilizador passa a ASSINANTE ATIVO, os links que registou (TikTok / Instagram /
--    YouTube — captados no primeiro login ou editados no perfil) viram tarefas "EXCHANGE".
--  • Cada tarefa é distribuída a TODOS os outros assinantes (incluindo os que entrarem depois),
--    sem limite de execuções: fetch_or_assign_community_tasks (021) reparte as que têm menos
--    atribuições primeiro, até cada utilizador ter 5 abertas, respeitando o limite diário.
--  • O assinante só recebe links de troca se também tiver o seu link publicado (reciprocidade).
--  • Se deixa de ser assinante/ativo ou apaga o link, a tarefa é desativada; se muda o link,
--    todos passam a ver o novo (a lista lê sempre o link actual).
--  • Recompensa em dinheiro: community_settings.exchange_reward (por defeito 0 = troca pura).
--  • Tarefas desativadas pelo admin (denúncia) não são reativadas pela sincronização.
-- ====================================================================

-- 1) Uma tarefa de troca por utilizador e plataforma
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = '_exchange_link' AND pg_get_function_result(p.oid) <> 'text') OR
        (p.proname = '_sync_exchange_tasks' AND pg_get_function_result(p.oid) <> 'void')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_exchange_task_user_platform
  ON public.community_tasks (creator_user_id, platform)
  WHERE source = 'EXCHANGE';

-- 2) Normaliza o que o utilizador escreveu (URL ou @handle) para um link seguro da plataforma.
--    Só aceita domínios da própria rede social: os links são mostrados a outros utilizadores.
CREATE OR REPLACE FUNCTION public._exchange_link(p_platform TEXT, p_raw TEXT)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
DECLARE
  v TEXT := btrim(coalesce(p_raw, ''));
  v_dom TEXT;
  v_handle TEXT;
BEGIN
  IF v = '' OR v ~ '\s' OR length(v) > 300 THEN
    RETURN NULL;
  END IF;

  v_dom := CASE p_platform
             WHEN 'tiktok' THEN 'tiktok\.com'
             WHEN 'instagram' THEN 'instagram\.com'
             WHEN 'youtube' THEN '(youtube\.com|youtu\.be)'
             ELSE NULL END;
  IF v_dom IS NULL THEN RETURN NULL; END IF;

  -- URL sem esquema (ex.: tiktok.com/@user) → acrescenta https://
  IF v !~* '^https?://' AND v ~* ('^(www\.|m\.)?' || v_dom || '/') THEN
    v := 'https://' || v;
  END IF;

  IF v ~* '^https?://' THEN
    IF v ~* ('^https?://([a-z0-9-]+\.)*' || v_dom || '(/|\?|#|$)') THEN
      RETURN v;
    END IF;
    RETURN NULL;
  END IF;

  -- @handle simples
  v_handle := regexp_replace(v, '^@+', '');
  IF v_handle !~ '^[A-Za-z0-9._-]{2,60}$' THEN
    RETURN NULL;
  END IF;

  RETURN CASE p_platform
           WHEN 'tiktok' THEN 'https://www.tiktok.com/@' || v_handle
           WHEN 'instagram' THEN 'https://www.instagram.com/' || v_handle
           ELSE 'https://www.youtube.com/@' || v_handle
         END;
END;
$$;

-- 3) Publica / actualiza / retira as tarefas de troca de um utilizador
CREATE OR REPLACE FUNCTION public._sync_exchange_tasks(p_user_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_prof RECORD;
  v_plat TEXT;
  v_raw TEXT;
  v_url TEXT;
  v_ok BOOLEAN;
  v_reward NUMERIC(10, 2);
BEGIN
  SELECT name, is_active, subscription_status, tiktok, instagram, youtube
  INTO v_prof FROM public.profiles WHERE id = p_user_id;
  IF NOT FOUND THEN RETURN; END IF;

  v_ok := v_prof.is_active IS TRUE AND v_prof.subscription_status = 'active';

  FOREACH v_plat IN ARRAY ARRAY['tiktok', 'instagram', 'youtube']
  LOOP
    v_raw := CASE v_plat WHEN 'tiktok' THEN v_prof.tiktok
                         WHEN 'instagram' THEN v_prof.instagram
                         ELSE v_prof.youtube END;
    v_url := CASE WHEN v_ok THEN public._exchange_link(v_plat, v_raw) END;

    IF v_url IS NOT NULL THEN
      SELECT exchange_reward INTO v_reward FROM public.community_settings WHERE platform = v_plat;
      v_reward := COALESCE(v_reward, 0);

      INSERT INTO public.community_tasks (
        creator_user_id, platform, task_type, profile_url, description,
        max_completions, current_completions, is_active, reward_amount, source
      ) VALUES (
        p_user_id, v_plat, 'follow', v_url,
        'Seguir ' || initcap(v_plat) || ' de ' || COALESCE(NULLIF(btrim(v_prof.name), ''), 'um membro'),
        1000000000, 0, true, v_reward, 'EXCHANGE'
      )
      ON CONFLICT (creator_user_id, platform) WHERE source = 'EXCHANGE'
      DO UPDATE SET
        profile_url = EXCLUDED.profile_url,
        description = EXCLUDED.description,
        reward_amount = EXCLUDED.reward_amount,
        is_active = NOT community_tasks.disabled_by_admin,
        updated_at = NOW();
    ELSE
      UPDATE public.community_tasks
      SET is_active = false, updated_at = NOW()
      WHERE creator_user_id = p_user_id AND source = 'EXCHANGE' AND platform = v_plat AND is_active = true;
    END IF;
  END LOOP;
END;
$$;

-- 4) Gatilho: sempre que muda o estado de assinatura/ativação ou um dos links do perfil
CREATE OR REPLACE FUNCTION public.trg_sync_exchange_tasks()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF NEW.subscription_status IS DISTINCT FROM OLD.subscription_status
     OR NEW.is_active IS DISTINCT FROM OLD.is_active
     OR NEW.tiktok IS DISTINCT FROM OLD.tiktok
     OR NEW.instagram IS DISTINCT FROM OLD.instagram
     OR NEW.youtube IS DISTINCT FROM OLD.youtube
     OR NEW.name IS DISTINCT FROM OLD.name THEN
    BEGIN
      PERFORM public._sync_exchange_tasks(NEW.id);
    EXCEPTION WHEN OTHERS THEN
      -- nunca bloquear a actualização do perfil por causa da troca
      RAISE WARNING 'sync exchange tasks falhou para %: %', NEW.id, SQLERRM;
    END;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profiles_sync_exchange ON public.profiles;
CREATE TRIGGER trg_profiles_sync_exchange
AFTER UPDATE OF subscription_status, is_active, tiktok, instagram, youtube, name ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.trg_sync_exchange_tasks();

-- 4b) Privacidade da distribuição: antes, qualquer utilizador autenticado lia TODAS as tarefas activas
--     (e portanto todos os links), ignorando limite diário, reciprocidade e distribuição.
--     Agora só vê: as suas (criador), as que lhe foram atribuídas, ou tudo se for admin.
DROP POLICY IF EXISTS "comm_tasks_select" ON public.community_tasks;
CREATE POLICY "comm_tasks_select" ON public.community_tasks
  FOR SELECT TO authenticated
  USING (
    public.is_admin()
    OR creator_user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM public.task_distribution_queue q
      WHERE q.task_id = community_tasks.id AND q.user_id = auth.uid()
    )
  );

-- 5) Permissões: nenhuma destas funções é chamada pelo cliente
REVOKE ALL ON FUNCTION public._exchange_link(TEXT, TEXT) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._sync_exchange_tasks(UUID) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.trg_sync_exchange_tasks() FROM PUBLIC, anon, authenticated;

-- 6) Assinantes que já existem passam a participar na troca
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT id FROM public.profiles WHERE subscription_status = 'active' AND is_active = true
  LOOP
    PERFORM public._sync_exchange_tasks(r.id);
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';
