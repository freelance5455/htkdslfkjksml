-- ====================================================================
-- ADXmoney App - Migration 006: Sistema de Níveis, Ranking e Benefícios
-- PostgreSQL / Supabase
-- VALIDADO em 2026-10-22 — executar na ordem das secções se necessário
-- ====================================================================

-- --------------------------------------------------------------------
-- 1. Colunas de nível no perfil
-- --------------------------------------------------------------------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS member_level TEXT NOT NULL DEFAULT 'bronze'
    CHECK (member_level IN ('bronze', 'silver', 'gold', 'platinum'));

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS level_updated_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS custom_affiliate_code TEXT;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS priority_withdrawal BOOLEAN NOT NULL DEFAULT false;

CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_custom_affiliate_code
  ON public.profiles (upper(custom_affiliate_code))
  WHERE custom_affiliate_code IS NOT NULL;

COMMENT ON COLUMN public.profiles.member_level IS 'Nivel do membro: bronze | silver | gold | platinum';
COMMENT ON COLUMN public.profiles.custom_affiliate_code IS 'Codigo de afiliado personalizado (disponivel a partir de Gold)';
COMMENT ON COLUMN public.profiles.priority_withdrawal IS 'Saque prioritario (Gold e Platinum)';

-- --------------------------------------------------------------------
-- 2. View de ranking
-- --------------------------------------------------------------------
CREATE OR REPLACE VIEW public.member_ranking AS
SELECT
  p.id AS user_id,
  p.name,
  p.member_level,
  COALESCE(ap.total_referrals, 0) AS total_referrals,
  COALESCE(ap.total_earned, 0) AS total_earned,
  COALESCE(p.referral_code, p.custom_affiliate_code) AS display_code,
  RANK() OVER (
    ORDER BY COALESCE(ap.total_referrals, 0) DESC,
             COALESCE(ap.total_earned, 0) DESC,
             p.created_at ASC
  ) AS rank_position
FROM public.profiles p
LEFT JOIN public.affiliate_profiles ap ON ap.user_id = p.id
WHERE p.role = 'user'
  AND p.is_active = true
  AND COALESCE(p.subscription_status, 'visitor') = 'active';

-- --------------------------------------------------------------------
-- 3. Função: calcular nível
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.calculate_member_level(
  p_referrals INTEGER,
  p_earned NUMERIC
)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
AS $body$
BEGIN
  IF p_referrals >= 50 OR p_earned >= 50000 THEN
    RETURN 'platinum';
  ELSIF p_referrals >= 15 OR p_earned >= 15000 THEN
    RETURN 'gold';
  ELSIF p_referrals >= 5 OR p_earned >= 5000 THEN
    RETURN 'silver';
  ELSE
    RETURN 'bronze';
  END IF;
END;
$body$;

-- --------------------------------------------------------------------
-- 4. Função: atualizar nível do utilizador
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.refresh_user_level(p_user_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  v_referrals INTEGER;
  v_earned NUMERIC;
  v_level TEXT;
  v_priority BOOLEAN;
BEGIN
  v_referrals := 0;
  v_earned := 0;

  SELECT COALESCE(ap.total_referrals, 0), COALESCE(ap.total_earned, 0)
  INTO v_referrals, v_earned
  FROM public.affiliate_profiles ap
  WHERE ap.user_id = p_user_id;

  IF v_referrals IS NULL THEN
    v_referrals := 0;
  END IF;
  IF v_earned IS NULL THEN
    v_earned := 0;
  END IF;

  v_level := public.calculate_member_level(v_referrals, v_earned);
  v_priority := (v_level = 'gold' OR v_level = 'platinum');

  UPDATE public.profiles
  SET
    member_level = v_level,
    priority_withdrawal = v_priority,
    level_updated_at = NOW(),
    updated_at = NOW()
  WHERE id = p_user_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Utilizador nao encontrado');
  END IF;

  RETURN jsonb_build_object(
    'success', true,
    'user_id', p_user_id,
    'member_level', v_level,
    'priority_withdrawal', v_priority,
    'total_referrals', v_referrals,
    'total_earned', v_earned
  );
END;
$body$;

-- --------------------------------------------------------------------
-- 5. Trigger: atualizar nível quando afiliado muda
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.trg_refresh_level_on_affiliate()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
BEGIN
  PERFORM public.refresh_user_level(NEW.user_id);
  RETURN NEW;
END;
$body$;

DROP TRIGGER IF EXISTS trg_affiliate_level_refresh ON public.affiliate_profiles;

CREATE TRIGGER trg_affiliate_level_refresh
  AFTER INSERT OR UPDATE OF total_referrals, total_earned
  ON public.affiliate_profiles
  FOR EACH ROW
  EXECUTE PROCEDURE public.trg_refresh_level_on_affiliate();

-- --------------------------------------------------------------------
-- 6. Função: código de afiliado personalizado (Gold+)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_custom_affiliate_code(p_code TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  v_user_id UUID;
  v_level TEXT;
  v_clean TEXT;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Nao autenticado';
  END IF;

  SELECT member_level INTO v_level
  FROM public.profiles
  WHERE id = v_user_id;

  IF v_level IS NULL OR (v_level <> 'gold' AND v_level <> 'platinum') THEN
    RAISE EXCEPTION 'Codigo personalizado disponivel apenas a partir do nivel Gold.';
  END IF;

  v_clean := upper(trim(p_code));

  IF v_clean IS NULL OR length(v_clean) < 4 OR length(v_clean) > 16 THEN
    RAISE EXCEPTION 'O codigo deve ter entre 4 e 16 caracteres.';
  END IF;

  IF v_clean !~ '^[A-Z0-9_]+$' THEN
    RAISE EXCEPTION 'Use apenas letras, numeros e underscore.';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE upper(COALESCE(custom_affiliate_code, '')) = v_clean AND id <> v_user_id
  ) THEN
    RAISE EXCEPTION 'Este codigo ja esta em uso. Escolha outro.';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE upper(COALESCE(referral_code, '')) = v_clean AND id <> v_user_id
  ) THEN
    RAISE EXCEPTION 'Este codigo ja esta em uso. Escolha outro.';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.affiliate_profiles
    WHERE upper(affiliate_code) = v_clean AND user_id <> v_user_id
  ) THEN
    RAISE EXCEPTION 'Este codigo ja esta em uso. Escolha outro.';
  END IF;

  UPDATE public.profiles
  SET custom_affiliate_code = v_clean,
      updated_at = NOW()
  WHERE id = v_user_id;

  UPDATE public.affiliate_profiles
  SET affiliate_code = v_clean,
      updated_at = NOW()
  WHERE user_id = v_user_id;

  RETURN jsonb_build_object(
    'success', true,
    'custom_affiliate_code', v_clean
  );
END;
$body$;

-- --------------------------------------------------------------------
-- 7. Função: dados do nível do utilizador autenticado
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_my_level_info()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  v_user_id UUID;
  v_result jsonb;
  v_level TEXT;
  v_benefits jsonb;
  v_rank INTEGER;
  v_name TEXT;
  v_priority BOOLEAN;
  v_custom TEXT;
  v_referral TEXT;
  v_referrals INTEGER;
  v_earned NUMERIC;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Nao autenticado';
  END IF;

  PERFORM public.refresh_user_level(v_user_id);

  SELECT
    p.name,
    p.member_level,
    p.priority_withdrawal,
    p.custom_affiliate_code,
    p.referral_code
  INTO
    v_name,
    v_level,
    v_priority,
    v_custom,
    v_referral
  FROM public.profiles p
  WHERE p.id = v_user_id;

  SELECT COALESCE(ap.total_referrals, 0), COALESCE(ap.total_earned, 0)
  INTO v_referrals, v_earned
  FROM public.affiliate_profiles ap
  WHERE ap.user_id = v_user_id;

  IF v_referrals IS NULL THEN v_referrals := 0; END IF;
  IF v_earned IS NULL THEN v_earned := 0; END IF;

  SELECT mr.rank_position INTO v_rank
  FROM public.member_ranking mr
  WHERE mr.user_id = v_user_id;

  IF v_level = 'platinum' THEN
    v_benefits := '["Saque prioritario (ate 24h)","Codigo de afiliado personalizado","Certificado Platinum","Acesso prioritario a campanhas","Suporte prioritario"]'::jsonb;
  ELSIF v_level = 'gold' THEN
    v_benefits := '["Saque prioritario (ate 48h)","Codigo de afiliado personalizado","Certificado Gold","Suporte prioritario"]'::jsonb;
  ELSIF v_level = 'silver' THEN
    v_benefits := '["Certificado Silver","Acesso a estatisticas avancadas"]'::jsonb;
  ELSE
    v_benefits := '["Certificado Bronze","Acesso completo a plataforma"]'::jsonb;
  END IF;

  v_result := jsonb_build_object(
    'user_id', v_user_id,
    'name', v_name,
    'member_level', COALESCE(v_level, 'bronze'),
    'priority_withdrawal', COALESCE(v_priority, false),
    'custom_affiliate_code', v_custom,
    'referral_code', v_referral,
    'total_referrals', v_referrals,
    'total_earned', v_earned,
    'rank_position', v_rank,
    'benefits', v_benefits
  );

  RETURN v_result;
END;
$body$;

-- --------------------------------------------------------------------
-- 8. Função: ranking da comunidade
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_member_ranking(p_limit INTEGER DEFAULT 20)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
DECLARE
  v_user_id UUID;
  v_limit INTEGER;
  v_result jsonb;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Nao autenticado';
  END IF;

  v_limit := LEAST(GREATEST(COALESCE(p_limit, 20), 1), 50);

  SELECT COALESCE(jsonb_agg(row_to_json(t)::jsonb), '[]'::jsonb)
  INTO v_result
  FROM (
    SELECT
      rank_position,
      name,
      member_level,
      total_referrals,
      total_earned,
      (user_id = v_user_id) AS is_me
    FROM public.member_ranking
    ORDER BY rank_position
    LIMIT v_limit
  ) t;

  RETURN v_result;
END;
$body$;

-- --------------------------------------------------------------------
-- 9. Grants e atualização inicial
-- --------------------------------------------------------------------
GRANT SELECT ON public.member_ranking TO authenticated;

GRANT EXECUTE ON FUNCTION public.calculate_member_level(INTEGER, NUMERIC) TO authenticated;
GRANT EXECUTE ON FUNCTION public.refresh_user_level(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_custom_affiliate_code(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_my_level_info() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_member_ranking(INTEGER) TO authenticated;

DO $body$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT id FROM public.profiles WHERE role = 'user' LOOP
    PERFORM public.refresh_user_level(r.id);
  END LOOP;
END;
$body$;
