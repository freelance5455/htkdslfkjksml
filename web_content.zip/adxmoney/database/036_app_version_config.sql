-- ====================================================================
-- 036 — Configuração de versão da app (version check / atualização forçada)
-- Idempotente. Executar depois da 035.
--
-- Uma linha por plataforma (android | ios | web). Leitura pública (a config não é sensível e
-- tem de funcionar também antes do login); escrita só pelo SQL editor / service_role.
--
-- Regras do cliente:
--   versão < min_version  e force_update = true   → ecrã bloqueante "Atualizar"
--   versão < min_version  e force_update = false  → aviso discreto
--   versão < latest_version                       → aviso discreto (1x por sessão)
--
-- Para forçar a atualização no Android:
--   UPDATE public.app_version_config
--      SET min_version = '1.2.0', latest_version = '1.2.0', force_update = true,
--          store_url = 'https://play.google.com/store/apps/details?id=com.adxmoney.app', updated_at = now()
--    WHERE platform = 'android';
-- ====================================================================

CREATE TABLE IF NOT EXISTS public.app_version_config (
  platform       TEXT PRIMARY KEY CHECK (platform IN ('android', 'ios', 'web')),
  min_version    TEXT NOT NULL DEFAULT '0.0.0',
  latest_version TEXT NOT NULL DEFAULT '0.0.0',
  force_update   BOOLEAN NOT NULL DEFAULT FALSE,
  message        TEXT,
  store_url      TEXT,
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.app_version_config (platform) VALUES ('android'), ('ios'), ('web')
ON CONFLICT (platform) DO NOTHING;

ALTER TABLE public.app_version_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS app_version_config_read ON public.app_version_config;
CREATE POLICY app_version_config_read ON public.app_version_config
  FOR SELECT TO anon, authenticated
  USING (true);

REVOKE ALL ON public.app_version_config FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.app_version_config TO anon, authenticated;
GRANT ALL ON public.app_version_config TO service_role;
