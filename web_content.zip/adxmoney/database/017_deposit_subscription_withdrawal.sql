-- ====================================================================
-- 017 — Depósito, assinatura e saque
-- Versões canónicas (substituem 007d/007f/010-013 onde divergiam).
-- Idempotente (CREATE OR REPLACE / IF NOT EXISTS). Executar uma vez no SQL Editor.
-- ====================================================================

-- Depósito: comprovativo tem de estar na pasta do próprio utilizador
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_wallet_deposit(
  p_amount NUMERIC, p_currency TEXT, p_method TEXT, p_proof_url TEXT
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_id UUID;
  v_amount NUMERIC;
  v_active BOOLEAN;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT is_active INTO v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;

  v_amount := ROUND(COALESCE(p_amount, 0)::numeric, 2);
  IF v_amount < 1000 THEN RAISE EXCEPTION 'O valor mínimo de depósito é 1.000 Kz.'; END IF;
  IF v_amount > 5000000 THEN RAISE EXCEPTION 'O valor máximo de depósito é 5.000.000 Kz.'; END IF;

  IF p_method IS NULL OR length(trim(p_method)) < 3 THEN
    RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;

  IF p_proof_url IS NULL OR left(trim(p_proof_url), length('deposits/' || v_uid::text || '/')) <> ('deposits/' || v_uid::text || '/') THEN
    RAISE EXCEPTION 'Comprovativo inválido para este utilizador.';
  END IF;

  IF (SELECT count(*) FROM public.wallet_deposits WHERE user_id = v_uid AND status = 'PENDING') >= 5 THEN
    RAISE EXCEPTION 'Tem demasiados depósitos pendentes. Aguarde a validação.';
  END IF;

  INSERT INTO public.wallet_deposits (user_id, amount, currency, method, proof_url, status)
  VALUES (v_uid, v_amount, COALESCE(NULLIF(trim(p_currency), ''), 'AOA'), trim(p_method), trim(p_proof_url), 'PENDING')
  RETURNING id INTO v_id;

  RETURN jsonb_build_object('success', true, 'id', v_id, 'amount', v_amount, 'status', 'PENDING');
END;
$$;

-- Assinatura: UMA versão canónica (as 3 anteriores divergiam entre si)
--    - preço calculado no servidor (4.900 Kz base) por moeda
--    - não rebaixa assinante activo; estado 'pending' agora persiste (guard desligado)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_subscription_payment(
  p_amount NUMERIC,                -- ignorado: preço é do servidor
  p_currency TEXT,
  p_method TEXT,
  p_proof_url TEXT DEFAULT NULL,
  p_payment_date TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_pay_id UUID;
  v_cur TEXT := upper(trim(coalesce(p_currency, 'AOA')));
  v_meth TEXT := upper(trim(split_part(coalesce(p_method, ''), ' ', 1)));
  v_details TEXT := trim(coalesce(p_method, ''));
  v_base_aoa CONSTANT NUMERIC := 4900.00;
  v_amount NUMERIC;
  v_status TEXT;
  v_active BOOLEAN;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT subscription_status, is_active INTO v_status, v_active FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_status = 'active' THEN RAISE EXCEPTION 'A sua assinatura já está activa.'; END IF;

  IF EXISTS (SELECT 1 FROM public.subscription_payments WHERE user_id = v_uid AND status = 'PENDING') THEN
    RAISE EXCEPTION 'Já tem um pagamento de assinatura em validação.';
  END IF;

  -- Taxas iguais às de submit_engagement_order (007e). CONFIRMAR antes de produção.
  v_amount := CASE v_cur
    WHEN 'AOA' THEN v_base_aoa
    WHEN 'USD' THEN round(v_base_aoa / 950.0, 2)
    WHEN 'EUR' THEN round(v_base_aoa / 950.0 * 0.92, 2)
    WHEN 'BRL' THEN round(v_base_aoa / 950.0 * 5.40, 2)
    ELSE NULL END;
  IF v_amount IS NULL THEN RAISE EXCEPTION 'Moeda não suportada.'; END IF;

  IF v_meth LIKE 'EXPRESS%' OR v_meth LIKE 'MULTICAIXA%' THEN v_meth := 'EXPRESS';
  ELSIF v_meth LIKE 'UNITEL%' THEN v_meth := 'UNITEL';
  ELSIF v_meth LIKE 'REMITLY%' THEN v_meth := 'REMITLY';
  ELSE RAISE EXCEPTION 'Método de pagamento inválido.';
  END IF;

  IF p_proof_url IS NULL OR split_part(trim(p_proof_url), '/', 1) <> v_uid::text THEN
    RAISE EXCEPTION 'Comprovativo inválido para este utilizador.';
  END IF;

  INSERT INTO public.subscription_payments (user_id, amount, currency, method, proof_url, status)
  VALUES (v_uid, v_amount, v_cur,
          v_meth || CASE WHEN length(v_details) > 20 THEN ' | ' || left(v_details, 400) ELSE '' END,
          trim(p_proof_url), 'PENDING')
  RETURNING id INTO v_pay_id;

  PERFORM set_config('app.skip_profile_guard', 'on', true);
  UPDATE public.profiles SET subscription_status = 'pending', updated_at = NOW() WHERE id = v_uid;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_uid, 'SUBSCRIPTION_SUBMITTED', 'Pedido de assinatura enviado', v_meth || ' / ' || v_cur);

  RETURN jsonb_build_object('success', true, 'payment_id', v_pay_id, 'amount', v_amount, 'currency', v_cur);
END;
$$;
REVOKE ALL ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_subscription_payment(NUMERIC, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Rejeitar um pagamento NÃO pode rebaixar quem já é assinante activo
CREATE OR REPLACE FUNCTION public.admin_process_subscription_payment(
  p_payment_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_payment RECORD;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar assinaturas.';
  END IF;
  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido. Use APPROVED ou REJECTED.';
  END IF;

  SELECT * INTO v_payment FROM public.subscription_payments WHERE id = p_payment_id FOR UPDATE;
  IF v_payment.id IS NULL THEN RAISE EXCEPTION 'Pagamento não encontrado.'; END IF;
  IF v_payment.status <> 'PENDING' THEN RAISE EXCEPTION 'Este pagamento já foi processado.'; END IF;

  UPDATE public.subscription_payments
  SET status = p_status,
      rejection_reason = CASE WHEN p_status = 'REJECTED' THEN p_rejection_reason ELSE NULL END,
      processed_at = NOW(), processed_by = v_admin, updated_at = NOW()
  WHERE id = p_payment_id;

  IF p_status = 'APPROVED' THEN
    UPDATE public.profiles
    SET subscription_status = 'active', subscription_onboarding_completed = true, updated_at = NOW()
    WHERE id = v_payment.user_id;
  ELSE
    UPDATE public.profiles
    SET subscription_status = 'visitor', updated_at = NOW()
    WHERE id = v_payment.user_id AND subscription_status = 'pending';
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details, metadata)
  VALUES (v_payment.user_id, 'SUBSCRIPTION_' || p_status, 'Assinatura ' || lower(p_status),
          COALESCE(p_rejection_reason, 'Processado pelo admin'),
          jsonb_build_object('payment_id', p_payment_id, 'admin_id', v_admin));

  RETURN jsonb_build_object('success', true, 'status', p_status);
END;
$$;

-- Saque: UMA versão canónica (lock antes de validar, mínimo 1.000, conta activa, sem suspensão)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.request_withdrawal(
  p_amount NUMERIC,
  p_method TEXT,
  p_payment_details JSONB
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_wal RECORD;
  v_wid UUID;
  v_active BOOLEAN;
  v_susp TIMESTAMPTZ;
  v_amount NUMERIC;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT is_active, suspended_until INTO v_active, v_susp FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_susp IS NOT NULL AND v_susp > NOW() THEN RAISE EXCEPTION 'Conta suspensa temporariamente.'; END IF;

  v_amount := ROUND(COALESCE(p_amount, 0)::numeric, 2);
  IF v_amount <= 0 THEN RAISE EXCEPTION 'O valor do saque deve ser maior que zero.'; END IF;
  IF v_amount < 1000 THEN RAISE EXCEPTION 'Valor mínimo de saque: 1000 Kz.'; END IF;
  IF p_method IS NULL OR length(trim(p_method)) = 0 THEN
    RAISE EXCEPTION 'Informe o método de pagamento para o saque.';
  END IF;
  IF p_payment_details IS NOT NULL AND length(p_payment_details::text) > 4000 THEN
    RAISE EXCEPTION 'Dados de pagamento demasiado longos.';
  END IF;

  SELECT * INTO v_wal FROM public.wallets WHERE user_id = v_uid FOR UPDATE;
  IF v_wal.id IS NULL THEN RAISE EXCEPTION 'Carteira não encontrada.'; END IF;
  IF v_wal.balance < v_amount THEN
    RAISE EXCEPTION 'Saldo disponível insuficiente para realizar este saque.';
  END IF;

  UPDATE public.wallets
  SET balance = balance - v_amount, reserved_balance = reserved_balance + v_amount, updated_at = NOW()
  WHERE id = v_wal.id;

  INSERT INTO public.withdrawals (user_id, amount, method, payment_details, status, requested_at)
  VALUES (v_uid, v_amount, trim(p_method), COALESCE(p_payment_details, '{}'::jsonb), 'PENDING', NOW())
  RETURNING id INTO v_wid;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wal.id, v_uid, 'WITHDRAWAL_LOCK', -v_amount,
          'Reserva de saldo para solicitacao de saque #' || substr(v_wid::text, 1, 8), v_wid::text, 'COMPLETED');

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_uid, 'WITHDRAWAL_REQUESTED', 'Solicitacao de saque criada',
          'Valor: ' || v_amount || ' Kz via ' || trim(p_method));

  RETURN jsonb_build_object('success', true, 'withdrawal_id', v_wid, 'amount', v_amount, 'status', 'PENDING');
END;
$$;
GRANT EXECUTE ON FUNCTION public.request_withdrawal(NUMERIC, TEXT, JSONB) TO authenticated;

-- Admin: comparação NULL != 'admin' deixava passar quem não tem perfil; usar is_admin()
CREATE OR REPLACE FUNCTION public.admin_process_withdrawal(
  p_withdrawal_id UUID,
  p_action TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin_id UUID := auth.uid();
  v_withdrawal RECORD;
  v_wallet RECORD;
BEGIN
  IF v_admin_id IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem processar saques.';
  END IF;

  SELECT * INTO v_withdrawal FROM public.withdrawals WHERE id = p_withdrawal_id FOR UPDATE;
  IF v_withdrawal.id IS NULL THEN RAISE EXCEPTION 'Solicitação de saque não encontrada.'; END IF;
  IF v_withdrawal.status IN ('PAID', 'REJECTED') THEN
    RAISE EXCEPTION 'Este saque já foi finalizado anteriormente.';
  END IF;

  SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_withdrawal.user_id FOR UPDATE;
  IF v_wallet.id IS NULL THEN RAISE EXCEPTION 'Carteira do utilizador não encontrada.'; END IF;

  IF p_action = 'APPROVE' THEN
    IF v_withdrawal.status <> 'PENDING' THEN RAISE EXCEPTION 'Só é possível aprovar saques pendentes.'; END IF;
    UPDATE public.withdrawals SET status = 'APPROVED', processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;

  ELSIF p_action = 'PAID' THEN
    UPDATE public.wallets
    SET reserved_balance = GREATEST(0.00, reserved_balance - v_withdrawal.amount), updated_at = NOW()
    WHERE id = v_wallet.id;
    UPDATE public.withdrawals SET status = 'PAID', processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;
    INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
    VALUES (v_wallet.id, v_withdrawal.user_id, 'WITHDRAWAL_PAID', 0.00,
            'Saque liquidado e transferido ao usuário (' || v_withdrawal.amount || ' Kz)',
            p_withdrawal_id::text, 'COMPLETED');

  ELSIF p_action = 'REJECT' THEN
    UPDATE public.wallets
    SET balance = balance + v_withdrawal.amount,
        reserved_balance = GREATEST(0.00, reserved_balance - v_withdrawal.amount), updated_at = NOW()
    WHERE id = v_wallet.id;
    UPDATE public.withdrawals
    SET status = 'REJECTED',
        rejection_reason = COALESCE(p_rejection_reason, 'Motivo não especificado pela administração'),
        processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;
    INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
    VALUES (v_wallet.id, v_withdrawal.user_id, 'WITHDRAWAL_REFUND', v_withdrawal.amount,
            'Estorno de saque rejeitado: ' || COALESCE(p_rejection_reason, 'Dados incorretos'),
            p_withdrawal_id::text, 'COMPLETED');
  ELSE
    RAISE EXCEPTION 'Ação inválida. Use APPROVE, PAID ou REJECT.';
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_admin_id, 'ADMIN_WITHDRAWAL_' || p_action,
          'Saque #' || substr(p_withdrawal_id::text, 1, 8) || ' processado: ' || p_action,
          'Usuário: ' || v_withdrawal.user_id || ' | Valor: ' || v_withdrawal.amount || ' Kz');

  RETURN jsonb_build_object('success', true, 'action', p_action, 'withdrawal_id', p_withdrawal_id,
                            'status', (SELECT status FROM public.withdrawals WHERE id = p_withdrawal_id));
END;
$$;

