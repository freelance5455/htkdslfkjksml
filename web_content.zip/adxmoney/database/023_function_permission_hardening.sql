-- ====================================================================
-- 023 — Endurecimento de permissões de funções (auditoria AUD-001/002/003/004)
-- Executar DEPOIS de 022. Idempotente.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1) AUD-001: refresh_user_level(UUID) deixa de ser chamável por utilizadores.
--    Antes: qualquer autenticado podia chamá-la para QUALQUER UUID (lia total_referrals/total_earned
--    do alvo, repunha o nível calculado e activava o bypass do guard de perfis).
--    Os chamadores legítimos (trigger de afiliado e get_my_level_info) são SECURITY DEFINER,
--    por isso continuam a funcionar.
-- --------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.refresh_user_level(UUID) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.refresh_user_level(UUID) TO service_role;
ALTER FUNCTION public.refresh_user_level(UUID) SET search_path = public, pg_temp;

-- --------------------------------------------------------------------
-- 2) AUD-003: nenhuma função SECURITY DEFINER do schema public fica executável por anónimos.
--    Mantém-se o acesso de quem já tinha (authenticated), dá-se service_role, tira-se PUBLIC/anon.
--    Excepções: ajudantes usados dentro de policies RLS.
-- --------------------------------------------------------------------
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig,
           has_function_privilege('authenticated', p.oid, 'EXECUTE') AS auth_ok
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.prosecdef
      AND p.prorettype <> 'trigger'::regtype
      AND p.proname NOT IN ('is_admin', 'is_task_creator', 'can_view_task_proof_file', 'proof_path_in_use')
  LOOP
    BEGIN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, anon', r.sig);
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r.sig);
      IF r.auth_ok THEN
        EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', r.sig);
      END IF;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Ignorada %: %', r.sig, SQLERRM;
    END;
  END LOOP;
END;
$$;

-- Funções novas deixam de ser executáveis por anon por defeito
DO $$
BEGIN
  ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM anon;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'ALTER DEFAULT PRIVILEGES ignorado (%): garanta REVOKE ... FROM anon nas funções novas.', SQLERRM;
END;
$$;

-- --------------------------------------------------------------------
-- 3) AUD-003: search_path fixo (com pg_temp no fim) em todas as SECURITY DEFINER
-- --------------------------------------------------------------------
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig,
           NOT EXISTS (SELECT 1 FROM unnest(COALESCE(p.proconfig, ARRAY[]::text[])) c WHERE c LIKE 'search_path=%') AS no_path
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.prosecdef
      AND (
        NOT EXISTS (SELECT 1 FROM unnest(COALESCE(p.proconfig, ARRAY[]::text[])) c WHERE c LIKE 'search_path=%')
        OR 'search_path=public' = ANY (COALESCE(p.proconfig, ARRAY[]::text[]))
      )
  LOOP
    BEGIN
      IF r.no_path THEN
        EXECUTE format('ALTER FUNCTION %s SET search_path = public, auth, pg_temp', r.sig);
      ELSE
        EXECUTE format('ALTER FUNCTION %s SET search_path = public, pg_temp', r.sig);
      END IF;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Ignorada %: %', r.sig, SQLERRM;
    END;
  END LOOP;
END;
$$;

-- --------------------------------------------------------------------
-- 4) AUD-004: a base de dados passa a impedir créditos duplicados da mesma operação
--    (rede de segurança por baixo dos FOR UPDATE e das verificações de estado).
--    Em bloco protegido: se já existirem duplicados históricos, só avisa e não aborta a migração.
-- --------------------------------------------------------------------
DO $$
BEGIN
  CREATE UNIQUE INDEX IF NOT EXISTS uq_wallet_tx_once_per_ref
    ON public.wallet_transactions (type, reference_id, user_id)
    WHERE reference_id IS NOT NULL
      AND type IN ('CAMPAIGN_REFUND', 'WITHDRAWAL_REFUND', 'WITHDRAWAL_PAID', 'DEPOSIT', 'CAMPAIGN_REWARD');
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Índice anti-duplicado não criado (%). Corra database/RECONCILE.sql e resolva duplicados históricos.', SQLERRM;
END;
$$;

-- --------------------------------------------------------------------
-- 5) Resumo final: os blocos acima toleram falhas pontuais (NOTICE), por isso confirmamos aqui.
--    Falha dura se a função crítica continuar aberta; avisos para o resto (ver separador Messages).
-- --------------------------------------------------------------------
DO $$
DECLARE
  v_anon INTEGER;
  v_nopath INTEGER;
BEGIN
  IF has_function_privilege('authenticated', 'public.refresh_user_level(uuid)', 'EXECUTE')
     OR has_function_privilege('anon', 'public.refresh_user_level(uuid)', 'EXECUTE') THEN
    RAISE EXCEPTION '023: refresh_user_level continua executável por utilizadores/anónimos. Migração abortada.';
  END IF;

  SELECT count(*) INTO v_anon
  FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.prosecdef AND p.prorettype <> 'trigger'::regtype
    AND p.proname NOT IN ('is_admin', 'is_task_creator', 'can_view_task_proof_file', 'proof_path_in_use')
    AND has_function_privilege('anon', p.oid, 'EXECUTE');

  SELECT count(*) INTO v_nopath
  FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.prosecdef
    AND NOT EXISTS (SELECT 1 FROM unnest(COALESCE(p.proconfig, ARRAY[]::text[])) c WHERE c LIKE 'search_path=%');

  IF v_anon > 0 OR v_nopath > 0 THEN
    RAISE WARNING '023 INCOMPLETA: % função(ões) ainda executável(eis) por anon e % sem search_path fixo. Corra VERIFY.sql e a auditoria completa.', v_anon, v_nopath;
  ELSE
    RAISE NOTICE '023 OK: permissões e search_path confirmados.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND indexname = 'uq_wallet_tx_once_per_ref') THEN
    RAISE WARNING '023: índice anti-duplicado NÃO foi criado. Corra RECONCILE.sql (verificação 4) e resolva duplicados históricos.';
  END IF;
END;
$$;
