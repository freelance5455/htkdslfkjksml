-- ====================================================================
-- 022 — Poupança de armazenamento: comprovativos apagados após validação
-- Executar DEPOIS de 021. Idempotente.
--
-- Como funciona:
--   • Quando uma prova/pagamento/depósito/pedido SAI do estado pendente (aprovado OU rejeitado),
--     um gatilho põe o ficheiro numa fila (proof_purge_queue). Nada é apagado antes da validação.
--   • A Edge Function `purge-proofs` apaga os ficheiros da fila no Storage (a única forma de
--     libertar espaço de verdade: apagar linhas de storage.objects por SQL NÃO remove o ficheiro).
--   • Ficheiros órfãos (enviados mas nunca ligados a um registo, > 48h) também são apagados.
--   • Na base de dados ficam o registo, o valor, o estado e o hash (o anti-duplicado continua a funcionar).
-- ====================================================================

-- 1) Fila de limpeza (só service_role; utilizadores não têm acesso)
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = '_enqueue_proof_purge' AND pg_get_function_result(p.oid) <> 'void') OR
        (p.proname = 'cleanup_old_logs' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'mark_proofs_purged' AND pg_get_function_result(p.oid) <> 'integer') OR
        (p.proname = 'proof_path_in_use' AND pg_get_function_result(p.oid) <> 'boolean')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

CREATE TABLE IF NOT EXISTS public.proof_purge_queue (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  bucket TEXT NOT NULL DEFAULT 'subscription-proofs',
  path TEXT NOT NULL,
  source TEXT,
  due_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  purged_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (bucket, path)
);
CREATE INDEX IF NOT EXISTS idx_proof_purge_pending
  ON public.proof_purge_queue (due_at) WHERE purged_at IS NULL;

ALTER TABLE public.proof_purge_queue ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.proof_purge_queue TO service_role;

-- 2) Pôr um caminho na fila (ignora vazios e URLs antigos completos)
CREATE OR REPLACE FUNCTION public._enqueue_proof_purge(p_path TEXT, p_source TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF p_path IS NULL OR length(trim(p_path)) = 0 OR p_path ~* '^https?://' THEN
    RETURN;
  END IF;
  INSERT INTO public.proof_purge_queue (path, source)
  VALUES (trim(p_path), p_source)
  ON CONFLICT (bucket, path) DO NOTHING;
END;
$$;
REVOKE ALL ON FUNCTION public._enqueue_proof_purge(TEXT, TEXT) FROM PUBLIC, anon, authenticated;

-- 3) Gatilhos: ao deixar o estado pendente, enfileirar o ficheiro
CREATE OR REPLACE FUNCTION public.trg_purge_task_proof()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF OLD.status = 'SUBMITTED' AND NEW.status <> 'SUBMITTED' THEN
    PERFORM public._enqueue_proof_purge(NEW.proof_path, 'task_proofs');
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS purge_task_proof ON public.task_proofs;
CREATE TRIGGER purge_task_proof
  AFTER UPDATE OF status ON public.task_proofs
  FOR EACH ROW EXECUTE FUNCTION public.trg_purge_task_proof();

CREATE OR REPLACE FUNCTION public.trg_purge_subscription_payment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF OLD.status = 'PENDING' AND NEW.status <> 'PENDING' THEN
    PERFORM public._enqueue_proof_purge(NEW.proof_url, 'subscription_payments');
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS purge_subscription_payment ON public.subscription_payments;
CREATE TRIGGER purge_subscription_payment
  AFTER UPDATE OF status ON public.subscription_payments
  FOR EACH ROW EXECUTE FUNCTION public.trg_purge_subscription_payment();

CREATE OR REPLACE FUNCTION public.trg_purge_wallet_deposit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF OLD.status = 'PENDING' AND NEW.status <> 'PENDING' THEN
    PERFORM public._enqueue_proof_purge(NEW.proof_url, 'wallet_deposits');
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS purge_wallet_deposit ON public.wallet_deposits;
CREATE TRIGGER purge_wallet_deposit
  AFTER UPDATE OF status ON public.wallet_deposits
  FOR EACH ROW EXECUTE FUNCTION public.trg_purge_wallet_deposit();

CREATE OR REPLACE FUNCTION public.trg_purge_engagement_order()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF OLD.status = 'PENDING' AND NEW.status <> 'PENDING' THEN
    PERFORM public._enqueue_proof_purge(NEW.proof_url, 'engagement_orders');
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS purge_engagement_order ON public.engagement_orders;
CREATE TRIGGER purge_engagement_order
  AFTER UPDATE OF status ON public.engagement_orders
  FOR EACH ROW EXECUTE FUNCTION public.trg_purge_engagement_order();

-- 4) Backlog: comprovativos de registos JÁ validados antes desta migração
INSERT INTO public.proof_purge_queue (path, source)
SELECT trim(proof_url), 'subscription_payments' FROM public.subscription_payments
WHERE status <> 'PENDING' AND proof_url IS NOT NULL AND length(trim(proof_url)) > 0 AND proof_url !~* '^https?://'
ON CONFLICT (bucket, path) DO NOTHING;

INSERT INTO public.proof_purge_queue (path, source)
SELECT trim(proof_url), 'wallet_deposits' FROM public.wallet_deposits
WHERE status <> 'PENDING' AND proof_url IS NOT NULL AND length(trim(proof_url)) > 0 AND proof_url !~* '^https?://'
ON CONFLICT (bucket, path) DO NOTHING;

INSERT INTO public.proof_purge_queue (path, source)
SELECT trim(proof_url), 'engagement_orders' FROM public.engagement_orders
WHERE status <> 'PENDING' AND proof_url IS NOT NULL AND length(trim(proof_url)) > 0 AND proof_url !~* '^https?://'
ON CONFLICT (bucket, path) DO NOTHING;

INSERT INTO public.proof_purge_queue (path, source)
SELECT trim(proof_path), 'task_proofs' FROM public.task_proofs
WHERE status <> 'SUBMITTED' AND proof_path IS NOT NULL AND length(trim(proof_path)) > 0
ON CONFLICT (bucket, path) DO NOTHING;

-- 5) Um caminho está em uso por algum registo ainda não validado ou referenciado?
CREATE OR REPLACE FUNCTION public.proof_path_in_use(p_path TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT
    EXISTS (SELECT 1 FROM public.task_proofs t WHERE t.proof_path = p_path)
    OR EXISTS (SELECT 1 FROM public.subscription_payments s WHERE s.proof_url IS NOT NULL AND (s.proof_url = p_path OR s.proof_url LIKE '%' || p_path))
    OR EXISTS (SELECT 1 FROM public.wallet_deposits d WHERE d.proof_url IS NOT NULL AND (d.proof_url = p_path OR d.proof_url LIKE '%' || p_path))
    OR EXISTS (SELECT 1 FROM public.engagement_orders e WHERE e.proof_url IS NOT NULL AND (e.proof_url = p_path OR e.proof_url LIKE '%' || p_path));
$$;
REVOKE ALL ON FUNCTION public.proof_path_in_use(TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.proof_path_in_use(TEXT) TO authenticated, service_role;

-- O utilizador pode apagar os SEUS ficheiros que ainda não estão ligados a nenhum registo
-- (limpeza imediata quando o envio falha a meio)
DROP POLICY IF EXISTS "proofs_delete_own_unreferenced" ON storage.objects;
CREATE POLICY "proofs_delete_own_unreferenced" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'subscription-proofs'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR ((storage.foldername(name))[1] = 'deposits' AND (storage.foldername(name))[2] = auth.uid()::text)
    )
    AND NOT public.proof_path_in_use(name)
  );

-- 6) Lote para a Edge Function (só service_role): varre órfãos > 48h e devolve o que apagar
CREATE OR REPLACE FUNCTION public.claim_proof_purge_batch(p_limit INTEGER DEFAULT 100)
RETURNS TABLE (o_bucket TEXT, o_path TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage, pg_temp
AS $$
BEGIN
  INSERT INTO public.proof_purge_queue (bucket, path, source)
  SELECT o.bucket_id, o.name, 'orphan'
  FROM storage.objects o
  WHERE o.bucket_id = 'subscription-proofs'
    AND o.created_at < NOW() - INTERVAL '48 hours'
    AND NOT public.proof_path_in_use(o.name)
  LIMIT 200
  ON CONFLICT (bucket, path) DO NOTHING;

  RETURN QUERY
  SELECT q.bucket, q.path
  FROM public.proof_purge_queue q
  WHERE q.purged_at IS NULL AND q.due_at <= NOW()
  ORDER BY q.due_at
  LIMIT GREATEST(1, LEAST(COALESCE(p_limit, 100), 500));
END;
$$;
REVOKE ALL ON FUNCTION public.claim_proof_purge_batch(INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_proof_purge_batch(INTEGER) TO service_role;

CREATE OR REPLACE FUNCTION public.mark_proofs_purged(p_paths TEXT[])
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_n INTEGER;
BEGIN
  UPDATE public.proof_purge_queue
  SET purged_at = NOW()
  WHERE purged_at IS NULL AND path = ANY (COALESCE(p_paths, ARRAY[]::TEXT[]));
  GET DIAGNOSTICS v_n = ROW_COUNT;

  -- A própria fila não cresce para sempre
  DELETE FROM public.proof_purge_queue WHERE purged_at IS NOT NULL AND purged_at < NOW() - INTERVAL '7 days';
  RETURN v_n;
END;
$$;
REVOKE ALL ON FUNCTION public.mark_proofs_purged(TEXT[]) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.mark_proofs_purged(TEXT[]) TO service_role;

-- 7) Retenção de logs técnicos (poupa base de dados)
CREATE OR REPLACE FUNCTION public.cleanup_old_logs()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_reg INTEGER;
  v_act INTEGER;
BEGIN
  DELETE FROM public.public_register_log WHERE created_at < NOW() - INTERVAL '30 days';
  GET DIAGNOSTICS v_reg = ROW_COUNT;
  DELETE FROM public.activity_logs WHERE created_at < NOW() - INTERVAL '180 days';
  GET DIAGNOSTICS v_act = ROW_COUNT;
  RETURN jsonb_build_object('register_log', v_reg, 'activity_logs', v_act);
END;
$$;
REVOKE ALL ON FUNCTION public.cleanup_old_logs() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_old_logs() TO service_role;
