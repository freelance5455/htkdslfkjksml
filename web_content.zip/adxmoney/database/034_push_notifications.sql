-- ====================================================================
-- 034 — Push notifications (base)
-- device_tokens + preferências + fila com retry.
-- Não envia FCM ainda (isso é Edge Function na etapa seguinte).
-- Idempotente. Executar no SQL Editor do Supabase.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1) Tokens FCM / dispositivo
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.device_tokens (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  token         TEXT NOT NULL,
  platform      TEXT NOT NULL DEFAULT 'android'
                  CHECK (platform IN ('android', 'ios', 'web')),
  app_version   TEXT,
  device_label  TEXT,
  enabled       BOOLEAN NOT NULL DEFAULT true,
  last_seen_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, token)
);

CREATE INDEX IF NOT EXISTS idx_device_tokens_user
  ON public.device_tokens (user_id) WHERE enabled;

CREATE INDEX IF NOT EXISTS idx_device_tokens_token
  ON public.device_tokens (token);

ALTER TABLE public.device_tokens ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS device_tokens_select_own ON public.device_tokens;
CREATE POLICY device_tokens_select_own ON public.device_tokens
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

-- Escrita só via RPC (evita o cliente inventar tokens de outros)
REVOKE ALL ON public.device_tokens FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.device_tokens TO authenticated;
GRANT ALL ON public.device_tokens TO service_role;

-- --------------------------------------------------------------------
-- 2) Preferências por utilizador
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notification_preferences (
  user_id           UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  proof             BOOLEAN NOT NULL DEFAULT true,  -- prova aprovada/rejeitada
  deposit           BOOLEAN NOT NULL DEFAULT true,
  withdrawal        BOOLEAN NOT NULL DEFAULT true,
  subscription      BOOLEAN NOT NULL DEFAULT true,
  campaign          BOOLEAN NOT NULL DEFAULT true,
  admin_message     BOOLEAN NOT NULL DEFAULT true,
  marketing         BOOLEAN NOT NULL DEFAULT false,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS notif_prefs_select_own ON public.notification_preferences;
CREATE POLICY notif_prefs_select_own ON public.notification_preferences
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

REVOKE ALL ON public.notification_preferences FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.notification_preferences TO authenticated;
GRANT ALL ON public.notification_preferences TO service_role;

-- --------------------------------------------------------------------
-- 3) Fila de envio (retry)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notification_queue (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  event_type      TEXT NOT NULL
                    CHECK (event_type IN (
                      'proof', 'deposit', 'withdrawal', 'subscription',
                      'campaign', 'admin_message', 'system'
                    )),
  title           TEXT NOT NULL,
  body            TEXT NOT NULL,
  data            JSONB NOT NULL DEFAULT '{}'::jsonb,  -- deep link, ids, etc.
  status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'processing', 'sent', 'failed', 'cancelled')),
  attempts        INTEGER NOT NULL DEFAULT 0,
  max_attempts    INTEGER NOT NULL DEFAULT 5,
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_error      TEXT,
  sent_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notification_queue_pending
  ON public.notification_queue (next_attempt_at)
  WHERE status IN ('pending', 'failed');

CREATE INDEX IF NOT EXISTS idx_notification_queue_user
  ON public.notification_queue (user_id, created_at DESC);

ALTER TABLE public.notification_queue ENABLE ROW LEVEL SECURITY;

-- Utilizador só lê as suas (histórico); escrita só service_role / RPC interna
DROP POLICY IF EXISTS notif_queue_select_own ON public.notification_queue;
CREATE POLICY notif_queue_select_own ON public.notification_queue
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

REVOKE ALL ON public.notification_queue FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.notification_queue TO authenticated;
GRANT ALL ON public.notification_queue TO service_role;

-- --------------------------------------------------------------------
-- 4) RPC: registar / actualizar token do dispositivo
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.upsert_device_token(
  p_token       TEXT,
  p_platform    TEXT DEFAULT 'android',
  p_app_version TEXT DEFAULT NULL,
  p_device_label TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_platform TEXT := lower(trim(COALESCE(p_platform, 'android')));
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;
  IF p_token IS NULL OR length(trim(p_token)) < 20 THEN
    RAISE EXCEPTION 'Token inválido';
  END IF;
  IF v_platform NOT IN ('android', 'ios', 'web') THEN
    v_platform := 'android';
  END IF;

  INSERT INTO public.device_tokens (user_id, token, platform, app_version, device_label, enabled, last_seen_at)
  VALUES (v_uid, trim(p_token), v_platform, NULLIF(trim(p_app_version), ''), NULLIF(trim(p_device_label), ''), true, NOW())
  ON CONFLICT (user_id, token) DO UPDATE SET
    platform     = EXCLUDED.platform,
    app_version  = COALESCE(EXCLUDED.app_version, public.device_tokens.app_version),
    device_label = COALESCE(EXCLUDED.device_label, public.device_tokens.device_label),
    enabled      = true,
    last_seen_at = NOW();

  -- Preferências por omissão na primeira vez
  INSERT INTO public.notification_preferences (user_id)
  VALUES (v_uid)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN jsonb_build_object('success', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.disable_device_token(p_token TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;
  UPDATE public.device_tokens
     SET enabled = false, last_seen_at = NOW()
   WHERE user_id = v_uid AND token = trim(p_token);
  RETURN jsonb_build_object('success', true);
END;
$$;

-- --------------------------------------------------------------------
-- 5) RPC: actualizar preferências
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_notification_preferences(
  p_proof          BOOLEAN DEFAULT NULL,
  p_deposit        BOOLEAN DEFAULT NULL,
  p_withdrawal     BOOLEAN DEFAULT NULL,
  p_subscription   BOOLEAN DEFAULT NULL,
  p_campaign       BOOLEAN DEFAULT NULL,
  p_admin_message  BOOLEAN DEFAULT NULL,
  p_marketing      BOOLEAN DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  INSERT INTO public.notification_preferences (user_id)
  VALUES (v_uid)
  ON CONFLICT (user_id) DO NOTHING;

  UPDATE public.notification_preferences SET
    proof         = COALESCE(p_proof, proof),
    deposit       = COALESCE(p_deposit, deposit),
    withdrawal    = COALESCE(p_withdrawal, withdrawal),
    subscription  = COALESCE(p_subscription, subscription),
    campaign      = COALESCE(p_campaign, campaign),
    admin_message = COALESCE(p_admin_message, admin_message),
    marketing     = COALESCE(p_marketing, marketing),
    updated_at    = NOW()
  WHERE user_id = v_uid;

  RETURN jsonb_build_object('success', true);
END;
$$;

-- --------------------------------------------------------------------
-- 6) Enfileirar notificação (só service_role / triggers internos)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enqueue_notification(
  p_user_id    UUID,
  p_event_type TEXT,
  p_title      TEXT,
  p_body       TEXT,
  p_data       JSONB DEFAULT '{}'::jsonb
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_id UUID;
  v_pref BOOLEAN;
BEGIN
  IF p_user_id IS NULL OR p_title IS NULL OR p_body IS NULL THEN
    RETURN NULL;
  END IF;
  IF p_event_type NOT IN ('proof','deposit','withdrawal','subscription','campaign','admin_message','system') THEN
    RAISE EXCEPTION 'event_type inválido';
  END IF;

  -- Respeitar preferências (system e admin_message: admin_message flag; system sempre)
  IF p_event_type = 'system' THEN
    v_pref := true;
  ELSE
    SELECT CASE p_event_type
      WHEN 'proof' THEN proof
      WHEN 'deposit' THEN deposit
      WHEN 'withdrawal' THEN withdrawal
      WHEN 'subscription' THEN subscription
      WHEN 'campaign' THEN campaign
      WHEN 'admin_message' THEN admin_message
      ELSE true
    END INTO v_pref
    FROM public.notification_preferences
    WHERE user_id = p_user_id;

    -- Sem linha de preferências = defaults (tudo true excepto marketing)
    IF v_pref IS NULL THEN
      v_pref := true;
    END IF;
  END IF;

  IF NOT v_pref THEN
    RETURN NULL;
  END IF;

  -- Só enfileira se existir pelo menos um token activo
  IF NOT EXISTS (
    SELECT 1 FROM public.device_tokens
    WHERE user_id = p_user_id AND enabled
  ) THEN
    RETURN NULL;
  END IF;

  INSERT INTO public.notification_queue (user_id, event_type, title, body, data)
  VALUES (p_user_id, p_event_type, left(p_title, 120), left(p_body, 500), COALESCE(p_data, '{}'::jsonb))
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;

-- --------------------------------------------------------------------
-- 7) Claim batch para o worker (Edge) — marca processing
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.claim_notification_batch(p_limit INTEGER DEFAULT 50)
RETURNS SETOF public.notification_queue
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_limit INTEGER := GREATEST(1, LEAST(COALESCE(p_limit, 50), 100));
BEGIN
  RETURN QUERY
  WITH picked AS (
    SELECT id
    FROM public.notification_queue
    WHERE status IN ('pending', 'failed')
      AND attempts < max_attempts
      AND next_attempt_at <= NOW()
    ORDER BY next_attempt_at
    LIMIT v_limit
    FOR UPDATE SKIP LOCKED
  )
  UPDATE public.notification_queue q
     SET status = 'processing',
         attempts = q.attempts + 1
    FROM picked
   WHERE q.id = picked.id
  RETURNING q.*;
END;
$$;

CREATE OR REPLACE FUNCTION public.mark_notification_sent(p_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  UPDATE public.notification_queue
     SET status = 'sent', sent_at = NOW(), last_error = NULL
   WHERE id = p_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.mark_notification_failed(
  p_id UUID,
  p_error TEXT DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_attempts INTEGER;
  v_max INTEGER;
BEGIN
  SELECT attempts, max_attempts INTO v_attempts, v_max
  FROM public.notification_queue WHERE id = p_id;

  IF v_attempts IS NULL THEN
    RETURN;
  END IF;

  IF v_attempts >= v_max THEN
    UPDATE public.notification_queue
       SET status = 'failed',
           last_error = left(COALESCE(p_error, 'max attempts'), 500)
     WHERE id = p_id;
  ELSE
    -- backoff: 1min, 5min, 15min, 1h, 6h
    UPDATE public.notification_queue
       SET status = 'failed',
           last_error = left(COALESCE(p_error, 'send failed'), 500),
           next_attempt_at = NOW() + (
             CASE v_attempts
               WHEN 1 THEN INTERVAL '1 minute'
               WHEN 2 THEN INTERVAL '5 minutes'
               WHEN 3 THEN INTERVAL '15 minutes'
               WHEN 4 THEN INTERVAL '1 hour'
               ELSE INTERVAL '6 hours'
             END
           )
     WHERE id = p_id;
  END IF;
END;
$$;

-- Permissões: cliente só token + prefs; fila/worker só service_role
REVOKE ALL ON FUNCTION public.upsert_device_token(TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.upsert_device_token(TEXT, TEXT, TEXT, TEXT) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.disable_device_token(TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.disable_device_token(TEXT) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.set_notification_preferences(BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_notification_preferences(BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN, BOOLEAN) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.enqueue_notification(UUID, TEXT, TEXT, TEXT, JSONB) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.enqueue_notification(UUID, TEXT, TEXT, TEXT, JSONB) TO service_role;

REVOKE ALL ON FUNCTION public.claim_notification_batch(INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_notification_batch(INTEGER) TO service_role;

REVOKE ALL ON FUNCTION public.mark_notification_sent(UUID) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.mark_notification_sent(UUID) TO service_role;

REVOKE ALL ON FUNCTION public.mark_notification_failed(UUID, TEXT) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.mark_notification_failed(UUID, TEXT) TO service_role;
