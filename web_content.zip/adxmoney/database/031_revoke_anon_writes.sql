-- ====================================================================
-- 031 — O papel anónimo (visitante sem login) não pode escrever em nenhuma tabela do public
-- Idempotente. Executar depois da 030. Corrige a verificação do VERIFY.sql:
--   "anon sem privilégios de escrita em tabelas do public"
-- O registo público usa a Edge Function com service_role; nenhuma tabela precisa de escrita por anon.
-- ====================================================================
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
  ON ALL TABLES IN SCHEMA public FROM anon;

-- tabelas futuras não herdam escrita para anon
DO $$
BEGIN
  ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE INSERT, UPDATE, DELETE ON TABLES FROM anon;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'ALTER DEFAULT PRIVILEGES ignorado (%): faça REVOKE manual nas tabelas novas.', SQLERRM;
END $$;

-- confirmação: deve devolver 0 linhas
SELECT table_name, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema='public' AND grantee='anon' AND privilege_type IN ('INSERT','UPDATE','DELETE');
