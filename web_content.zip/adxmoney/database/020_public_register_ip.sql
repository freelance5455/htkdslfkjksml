-- ====================================================================
-- 020 — Rate-limit por IP no registo público
-- Usado pela Edge Function public-register (tabela criada em 007g).
-- Idempotente. Executar uma vez no SQL Editor.
-- ====================================================================

ALTER TABLE public.public_register_log ADD COLUMN IF NOT EXISTS ip TEXT;

CREATE INDEX IF NOT EXISTS idx_public_register_log_ip
  ON public.public_register_log (ip, created_at DESC);
