-- ====================================================================
-- 013 — Hardening produção: logs em depósitos + comentários
-- (As Edge Functions admin-delete/create foram reforçadas no repo)
-- ====================================================================

-- Garantir que aprovação de depósito regista activity_log para o utilizador
CREATE OR REPLACE FUNCTION public.admin_process_wallet_deposit(
  p_deposit_id UUID,
  p_status TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_dep RECORD;
  v_wallet RECORD;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores podem processar depósitos.';
  END IF;

  IF p_status NOT IN ('APPROVED', 'REJECTED') THEN
    RAISE EXCEPTION 'Status inválido. Use APPROVED ou REJECTED.';
  END IF;

  SELECT * INTO v_dep
  FROM public.wallet_deposits
  WHERE id = p_deposit_id
  FOR UPDATE;

  IF v_dep.id IS NULL THEN
    RAISE EXCEPTION 'Depósito não encontrado.';
  END IF;

  IF v_dep.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Este depósito já foi processado.';
  END IF;

  IF p_status = 'REJECTED' THEN
    UPDATE public.wallet_deposits
    SET status = 'REJECTED',
        rejection_reason = NULLIF(trim(COALESCE(p_rejection_reason, '')), ''),
        processed_at = NOW(),
        processed_by = v_admin,
        updated_at = NOW()
    WHERE id = v_dep.id;

    INSERT INTO public.activity_logs (user_id, action_type, title, details)
    VALUES (
      v_dep.user_id,
      'DEPOSIT_REJECTED',
      'Depósito rejeitado',
      'O seu pedido de carregamento de ' || v_dep.amount::text || ' Kz foi rejeitado.'
    );

    RETURN jsonb_build_object('success', true, 'status', 'REJECTED');
  END IF;

  SELECT * INTO v_wallet
  FROM public.wallets
  WHERE user_id = v_dep.user_id
  FOR UPDATE;

  IF v_wallet.id IS NULL THEN
    INSERT INTO public.wallets (user_id, balance, reserved_balance)
    VALUES (v_dep.user_id, 0, 0)
    ON CONFLICT (user_id) DO NOTHING;

    SELECT * INTO v_wallet
    FROM public.wallets
    WHERE user_id = v_dep.user_id
    FOR UPDATE;
  END IF;

  UPDATE public.wallets
  SET balance = balance + v_dep.amount,
      updated_at = NOW()
  WHERE id = v_wallet.id;

  INSERT INTO public.wallet_transactions (
    wallet_id, user_id, type, amount, description, reference_id, status
  ) VALUES (
    v_wallet.id,
    v_dep.user_id,
    'DEPOSIT',
    v_dep.amount,
    'Depósito aprovado #' || left(v_dep.id::text, 8),
    v_dep.id::text,
    'COMPLETED'
  );

  UPDATE public.wallet_deposits
  SET status = 'APPROVED',
      processed_at = NOW(),
      processed_by = v_admin,
      updated_at = NOW()
  WHERE id = v_dep.id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (
    v_dep.user_id,
    'DEPOSIT_APPROVED',
    'Saldo creditado',
    'Foram creditados ' || v_dep.amount::text || ' Kz na sua carteira.'
  );

  RETURN jsonb_build_object(
    'success', true,
    'status', 'APPROVED',
    'credited', v_dep.amount
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_process_wallet_deposit(UUID, TEXT, TEXT) TO authenticated;
