-- ====================================================================
-- 014 — Segurança de perfis
-- handle_new_user sem role do cliente, guard de colunas, coluna facebook, desliga admin_create_user legado.
-- Idempotente (CREATE OR REPLACE / IF NOT EXISTS). Executar uma vez no SQL Editor.
-- ====================================================================

-- CRÍTICO: handle_new_user NUNCA confia no role vindo do metadata
--    (antes: signUp com data {role:'admin'} criava um administrador)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  INSERT INTO public.profiles (
    id, name, first_name, last_name, email, role,
    first_login, is_active, subscription_status, country
  )
  VALUES (
    new.id,
    COALESCE(
      NULLIF(trim(new.raw_user_meta_data ->> 'name'), ''),
      NULLIF(trim(concat_ws(' ', new.raw_user_meta_data ->> 'first_name', new.raw_user_meta_data ->> 'last_name')), ''),
      split_part(new.email, '@', 1)
    ),
    new.raw_user_meta_data ->> 'first_name',
    new.raw_user_meta_data ->> 'last_name',
    new.email,
    'user',
    true,
    true,
    'visitor',
    COALESCE(new.raw_user_meta_data ->> 'country', 'Angola')
  )
  ON CONFLICT (id) DO UPDATE
  SET email = EXCLUDED.email;

  INSERT INTO public.wallets (user_id, balance, reserved_balance)
  VALUES (new.id, 0.00, 0.00)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN new;
END;
$$;

-- Coluna usada pela Edge Function admin-create-user (não existia → criação falhava)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS facebook TEXT;

-- suspended_until é lido pelo app e pelo guard (007a/014) mas nenhuma migração anterior a criava
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS suspended_until TIMESTAMPTZ;

-- Guard de colunas sensíveis: service_role (Edge Functions) passa; utilizador normal continua protegido
-- e first_login deixa de poder voltar a true (evitava repetir o setup/bónus).
CREATE OR REPLACE FUNCTION public.protect_profile_sensitive_columns()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  IF current_setting('app.skip_profile_guard', true) = 'on' THEN
    RETURN NEW;
  END IF;

  IF COALESCE(auth.role(), '') = 'service_role' THEN
    RETURN NEW;
  END IF;

  IF public.is_admin() THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    NEW.role := OLD.role;
    NEW.subscription_status := OLD.subscription_status;
    NEW.is_active := OLD.is_active;
    NEW.member_level := OLD.member_level;
    NEW.priority_withdrawal := OLD.priority_withdrawal;
    NEW.level_updated_at := OLD.level_updated_at;
    NEW.custom_affiliate_code := OLD.custom_affiliate_code;
    -- first_login só pode ir de true → false
    IF OLD.first_login IS FALSE THEN
      NEW.first_login := FALSE;
    END IF;
    IF NEW.suspended_until IS DISTINCT FROM OLD.suspended_until THEN
      NEW.suspended_until := OLD.suspended_until;
    END IF;
  END IF;

  RETURN NEW;
END;
$fn$;

-- Função legada que insere directo em auth.users (sem identities → login impossível): desligar
REVOKE EXECUTE ON FUNCTION public.admin_create_user(text, text, text, text, text) FROM PUBLIC, anon, authenticated;

