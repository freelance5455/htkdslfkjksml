# Migrações — ADXmoney (PostgreSQL / Supabase)

Histórico linear. **Nunca edites um ficheiro já executado**; alterações novas = novo ficheiro numerado.

## O que executar agora
Ambiente actual (001–013 já aplicadas): corre **014 → 035, por esta ordem, uma de cada vez** no SQL Editor, e no fim **`VERIFY.sql`** (todas as linhas com `ok = true`).
Ambiente novo (vazio): 001 → 013 e depois 014 → 035.

| # | Ficheiro | Estado | O que faz |
|---|---|---|---|
| 001 | `001_initial_schema.sql` | aplicada | tabelas base |
| 002 | `002_rls.sql` | aplicada | grants, RLS, `is_admin()` |
| 003 | `003_functions.sql` | aplicada | `handle_new_user`, saque, campanhas |
| 004 | `004_align_frontend.sql` | aplicada | assinatura, engajamento, campanhas, tarefas comunitárias |
| 005 | `005_ai_language.sql` | aplicada | idioma da IA |
| 006 | `006_user_levels.sql` | aplicada | níveis, ranking |
| 007a–g | `007*.sql` | aplicadas | guard de perfis, refresh de nível, códigos, assinatura, engajamento, saque, log de registo |
| 008 | `008_invite_custom_code.sql` | aplicada | convite + código personalizado |
| 009–013 | `009`…`013` | aplicadas | admin campanhas, `debit_wallet`, depósitos, correções, hardening |
| **014** | `014_security_roles_and_profiles.sql` | **NOVA** | role nunca vem do metadata; guard de colunas; `facebook`, `suspended_until` |
| **015** | `015_lock_financial_tables.sql` | **NOVA** | revoga INSERT directo em tabelas financeiras; grants admin |
| **016** | `016_campaign_requests_refund.sql` | **NOVA** | tipo `CAMPAIGN_REFUND`; preço fixo; reembolso ao rejeitar |
| **017** | `017_deposit_subscription_withdrawal.sql` | **NOVA** | versões canónicas de depósito, assinatura e saque |
| **018** | `018_community_and_admin_rpcs.sql` | **NOVA** | validações de tarefas; `admin_assign_campaign`, `admin_toggle_affiliate` |
| **019** | `019_storage_policies.sql` | **NOVA** | cria o bucket privado `subscription-proofs` e as suas policies |
| **020** | `020_public_register_ip.sql` | **NOVA** | rate-limit por IP no registo público |
| **021** | `021_task_proofs_and_trust.sql` | **NOVA** | repara `community_tasks`/`task_distribution_queue` (colunas em falta) e adiciona recompensas com prova: envio, validação (criador/admin), @ único, hash, reputação, pagamento adiado |
| **022** | `022_proof_storage_cleanup.sql` | **NOVA** | fila de limpeza: comprovativos apagados do Storage após validação; órfãos > 48h; retenção de logs |
| **023** | `023_function_permission_hardening.sql` | **NOVA** | fecha `refresh_user_level`; retira anon das funções SECURITY DEFINER; search_path fixo; índice anti-crédito-duplicado |
| **024** | `024_wallet_flow.sql` | **NOVA** | RPC `get_wallet_flow` (fluxo diário agregado no servidor) para o gráfico da Home |
| **025** | `025_admin_audit_fixes.sql` | **NOVA** | `admin_launch_engagement_task` atómica, `admin_resolve_task_report`; FKs para `profiles` (joins do painel); recarrega o cache do PostgREST |
| **026** | `026_community_exchange.sql` | **NOVA** | **troca de seguidores**: links do assinante (TikTok/Instagram/YouTube) viram tarefas para todos os outros assinantes, incluindo os novos |
| **027** | `027_economy_subscription_affiliates_campaigns.sql` | **NOVA** | **assinatura de 6 meses** (validade, renovação, expiração), **comissões de afiliado em %** quando o indicado paga, **campanhas pagas por resultado financeiro**, definições de economia editáveis no painel |
| **028** | `028_financial_integrity.sql` | **NOVA** | histórico financeiro imutável (contas com histórico só se desativam), telefone único, saques em dois passos opcional (substitui `admin_process_withdrawal` da 017) |
| **029** | `029_limits_terms_monitoring.sql` | **NOVA** | tetos de saque (por pedido, por utilizador/dia, global/dia), aceitação de termos, reconciliação pelo painel, registo de erros do app (substitui `request_withdrawal` da 017) |
| **030** | `030_fix_signup_role_and_guards.sql` | **NOVA** | **corrige escalada de privilégios**: o registo já não aceita `role` do cliente (um `signUp` com `{"role":"admin"}` criava administrador na base real); remove guarda legada duplicada |
| **031** | `031_revoke_anon_writes.sql` | **NOVA** | o papel anónimo deixa de ter escrita em qualquer tabela |
| **032** | `032_fix_community_tasks_created_by_fk.sql` | **NOVA** | apagar um utilizador deixa de ser bloqueado por `community_tasks.created_by` |
| **033** | `033_terms_server_version_and_ai_limits.sql` | **NOVA** | versão oficial dos termos validada pelo servidor (`app_settings`); limite de IA por utilizador (`ai_rate_limit_check`) |
| — | `TESTES_FINANCEIROS.sql` | testes | cenários financeiros e de segurança numa transação que se desfaz sempre (nada é gravado); relatório ✅/❌ na mensagem de erro final |
| — | `../scripts/teste-concorrencia.mjs` | testes (Node) | pedidos em paralelo contra um projeto de TESTE: depósito, assinatura, saque, duplo gasto, campanha, registo |
| — | `RECONCILE.sql` | só leitura | reconciliação saldo × ledger (correr em staging após testes) |
| — | `VERIFY.sql` | só leitura | confirma que 014–033 ficaram aplicadas (inclui verificação de FKs que bloqueiam apagar utilizadores) |

## Funções substituídas (a versão válida é a mais recente)
- `handle_new_user`: 003 → 004 → **014**
- `protect_profile_sensitive_columns`: 007a → **014**
- `submit_subscription_payment` / `admin_process_subscription_payment`: 004/007d → **017**
- `request_withdrawal` / `admin_process_withdrawal`: 003/007f → **017**
- `submit_wallet_deposit`: 011 → **017**
- `submit_paid_campaign_request`: 012 → **016**
- `complete_community_task` / `report_community_task`: 004 → **018**; `complete_community_task` e `complete_campaign_execution` ficam **sem EXECUTE** para utilizadores em **021** (pagamento só via `review_task_proof`)
- `refresh_user_level`: 006/007b → **023** (sem EXECUTE para utilizadores)
- `fetch_or_assign_community_tasks`: 004 → **021**

Todas as novas migrações são idempotentes (`CREATE OR REPLACE`, `IF NOT EXISTS`, `DROP … IF EXISTS`).
