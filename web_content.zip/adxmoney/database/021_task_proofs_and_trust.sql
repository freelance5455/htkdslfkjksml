-- ====================================================================
-- 021 — Recompensas com prova, validação e reputação
-- Executar DEPOIS de 014–020 (a 018 tem de estar aplicada). Idempotente.
--
-- Fluxo:  utilizador envia captura + @  →  fica SUBMITTED (nada é pago)
--         criador da tarefa (ou admin) aprova/rejeita  →  só então o saldo sobe
--         sem resposta em 48h: aprovação automática só para utilizadores de confiança (score >= 3);
--         os restantes ficam escalados para o admin.
-- Anti-fraude: @ único por plataforma, hash da captura único, limite diário
--              (10/dia enquanto score < 5), suspensão de 7 dias após 3 rejeições seguidas.
-- ====================================================================

-- --------------------------------------------------------------------
-- 0) Reparação do schema existente (idempotente)
--    A community_tasks criada antes da 004 não tem creator_user_id e outras colunas, e o
--    CREATE TABLE IF NOT EXISTS da 004 não altera tabelas já existentes. Sem isto, a 021 falha.
-- --------------------------------------------------------------------
-- community_tasks: todas as colunas que 018/021 e o painel admin usam
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = '_settle_task_proof' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_run_auto_approve' AND pg_get_function_result(p.oid) <> 'integer') OR
        (p.proname = 'auto_approve_stale_proofs' AND pg_get_function_result(p.oid) <> 'integer') OR
        (p.proname = 'can_view_task_proof_file' AND pg_get_function_result(p.oid) <> 'boolean') OR
        (p.proname = 'fetch_or_assign_community_tasks' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'is_task_creator' AND pg_get_function_result(p.oid) <> 'boolean') OR
        (p.proname = 'review_task_proof' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'submit_task_proof' AND pg_get_function_result(p.oid) <> 'jsonb')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

ALTER TABLE public.community_tasks
  ADD COLUMN IF NOT EXISTS creator_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS task_type TEXT NOT NULL DEFAULT 'follow',
  ADD COLUMN IF NOT EXISTS description TEXT,
  ADD COLUMN IF NOT EXISTS max_completions INTEGER NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS current_completions INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS reward_amount NUMERIC(10, 2) NOT NULL DEFAULT 5.00,
  -- origem: 'EXCHANGE' = link do assinante (troca de seguidores) · 'STORE' = pedido pago na loja
  ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'STORE',
  -- true quando o admin desativa (denúncia/moderação): a sincronização automática não volta a ativar
  ADD COLUMN IF NOT EXISTS disabled_by_admin BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- task_distribution_queue: colunas usadas pelas RPCs + estado EXPIRED (usado na rejeição de provas)
ALTER TABLE public.task_distribution_queue
  ADD COLUMN IF NOT EXISTS platform TEXT,
  ADD COLUMN IF NOT EXISTS task_type TEXT,
  ADD COLUMN IF NOT EXISTS profile_url TEXT,
  ADD COLUMN IF NOT EXISTS description TEXT,
  ADD COLUMN IF NOT EXISTS assigned_at TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;

DO $$
DECLARE c RECORD;
BEGIN
  FOR c IN
    SELECT conname FROM pg_constraint
    WHERE conrelid = 'public.task_distribution_queue'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%status%'
  LOOP
    EXECUTE format('ALTER TABLE public.task_distribution_queue DROP CONSTRAINT %I', c.conname);
  END LOOP;
  ALTER TABLE public.task_distribution_queue
    ADD CONSTRAINT task_distribution_queue_status_check
    CHECK (status IN ('ASSIGNED', 'COMPLETED', 'REPORTED', 'EXPIRED')) NOT VALID; -- NOT VALID: não falha por linhas antigas
END $$;

-- ON CONFLICT (user_id, task_id) exige índice único
CREATE UNIQUE INDEX IF NOT EXISTS uq_task_queue_user_task
  ON public.task_distribution_queue (user_id, task_id);

-- community_settings.daily_limit (usado nas validações)
ALTER TABLE public.community_settings
  ADD COLUMN IF NOT EXISTS daily_limit INTEGER NOT NULL DEFAULT 100,
  -- Recompensa por prova aprovada na TROCA de seguidores (0 = troca pura, sem dinheiro).
  -- reward_per_task continua a ser a recompensa das tarefas da LOJA (pedidos pagos).
  ADD COLUMN IF NOT EXISTS exchange_reward NUMERIC(10, 2) NOT NULL DEFAULT 0;

-- --------------------------------------------------------------------
-- 1) Fechar o pagamento directo (qualquer utilizador podia chamar estas RPCs sem prova)
-- --------------------------------------------------------------------
-- (tolerante: a 027 remove complete_campaign_execution; repetir a 021 depois dela não pode falhar)
DO $$
BEGIN
  IF to_regprocedure('public.complete_campaign_execution(uuid)') IS NOT NULL THEN
    REVOKE EXECUTE ON FUNCTION public.complete_campaign_execution(UUID) FROM PUBLIC, anon, authenticated;
  END IF;
  IF to_regprocedure('public.complete_community_task(uuid)') IS NOT NULL THEN
    REVOKE EXECUTE ON FUNCTION public.complete_community_task(UUID) FROM PUBLIC, anon, authenticated;
  END IF;
END $$;

-- --------------------------------------------------------------------
-- 2) Tabelas
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.social_handles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('tiktok', 'instagram', 'youtube')),
  handle TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, platform)
);
-- Um @ só pode pertencer a UMA conta ADX por plataforma
CREATE UNIQUE INDEX IF NOT EXISTS uq_social_handles_platform_handle
  ON public.social_handles (platform, lower(handle));

CREATE TABLE IF NOT EXISTS public.task_proofs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  queue_id UUID NOT NULL UNIQUE REFERENCES public.task_distribution_queue(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES public.community_tasks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  handle TEXT NOT NULL,
  proof_path TEXT NOT NULL,
  proof_hash TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'SUBMITTED'
    CHECK (status IN ('SUBMITTED', 'APPROVED', 'REJECTED', 'AUTO_APPROVED')),
  reward_amount NUMERIC(10, 2) NOT NULL,
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  review_note TEXT,
  escalated BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  due_at TIMESTAMPTZ NOT NULL,
  reviewed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_task_proofs_status ON public.task_proofs (status, due_at);
CREATE INDEX IF NOT EXISTS idx_task_proofs_task   ON public.task_proofs (task_id, status);
CREATE INDEX IF NOT EXISTS idx_task_proofs_user   ON public.task_proofs (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.user_trust (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  score INTEGER NOT NULL DEFAULT 0,
  rejected_streak INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- --------------------------------------------------------------------
-- 3) Grants + RLS (utilizadores só LEEM; toda a escrita é por RPC)
-- --------------------------------------------------------------------
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.social_handles TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.task_proofs    TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.user_trust     TO service_role;
GRANT SELECT ON TABLE public.social_handles TO authenticated;
GRANT SELECT ON TABLE public.task_proofs    TO authenticated;
GRANT SELECT ON TABLE public.user_trust     TO authenticated;

ALTER TABLE public.social_handles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_proofs    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_trust     ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "social_handles_select" ON public.social_handles;
CREATE POLICY "social_handles_select" ON public.social_handles
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "user_trust_select" ON public.user_trust;
CREATE POLICY "user_trust_select" ON public.user_trust
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

-- Ajudante SECURITY DEFINER (evita recursão de RLS): o utilizador é o criador da tarefa desta prova?
CREATE OR REPLACE FUNCTION public.is_task_creator(p_task_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.community_tasks ct
    WHERE ct.id = p_task_id AND ct.creator_user_id = auth.uid()
  );
$$;
GRANT EXECUTE ON FUNCTION public.is_task_creator(UUID) TO authenticated;

DROP POLICY IF EXISTS "task_proofs_select" ON public.task_proofs;
CREATE POLICY "task_proofs_select" ON public.task_proofs
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin() OR public.is_task_creator(task_id));

-- O criador da tarefa precisa de ver a captura (bucket privado)
CREATE OR REPLACE FUNCTION public.can_view_task_proof_file(p_path TEXT)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.task_proofs tp
    JOIN public.community_tasks ct ON ct.id = tp.task_id
    WHERE tp.proof_path = p_path AND ct.creator_user_id = auth.uid()
  );
$$;
GRANT EXECUTE ON FUNCTION public.can_view_task_proof_file(TEXT) TO authenticated;

DROP POLICY IF EXISTS "proofs_select_task_creator" ON storage.objects;
CREATE POLICY "proofs_select_task_creator" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'subscription-proofs' AND public.can_view_task_proof_file(name));

-- --------------------------------------------------------------------
-- 4) Liquidação interna (paga ou rejeita). Não é exposta a utilizadores.
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public._settle_task_proof(
  p_proof_id UUID,
  p_approve BOOLEAN,
  p_reviewer UUID,
  p_note TEXT,
  p_auto BOOLEAN DEFAULT FALSE
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_proof RECORD;
  v_task RECORD;
  v_wallet_id UUID;
  v_streak INTEGER;
BEGIN
  SELECT * INTO v_proof FROM public.task_proofs WHERE id = p_proof_id FOR UPDATE;
  IF v_proof.id IS NULL THEN
    RAISE EXCEPTION 'Prova não encontrada.';
  END IF;
  IF v_proof.status <> 'SUBMITTED' THEN
    RAISE EXCEPTION 'Esta prova já foi avaliada.';
  END IF;

  IF p_approve THEN
    SELECT * INTO v_task FROM public.community_tasks WHERE id = v_proof.task_id FOR UPDATE;

    -- Recompensa 0 (troca pura de seguidores): não mexe na carteira nem no ledger
    IF v_proof.reward_amount > 0 THEN
      INSERT INTO public.wallets (user_id, balance, reserved_balance)
      VALUES (v_proof.user_id, 0.00, 0.00)
      ON CONFLICT (user_id) DO NOTHING;
      SELECT id INTO v_wallet_id FROM public.wallets WHERE user_id = v_proof.user_id FOR UPDATE;

      UPDATE public.wallets
      SET balance = balance + v_proof.reward_amount, updated_at = NOW()
      WHERE id = v_wallet_id;

      INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
      VALUES (v_wallet_id, v_proof.user_id, 'CAMPAIGN_REWARD', v_proof.reward_amount,
              'Tarefa de comunidade aprovada', v_proof.id::text, 'COMPLETED');
    END IF;

    IF v_task.id IS NOT NULL AND v_task.current_completions < v_task.max_completions THEN
      UPDATE public.community_tasks
      SET current_completions = current_completions + 1, updated_at = NOW()
      WHERE id = v_task.id;
    END IF;

    UPDATE public.task_distribution_queue
    SET status = 'COMPLETED', completed_at = NOW()
    WHERE id = v_proof.queue_id;

    UPDATE public.task_proofs
    SET status = CASE WHEN p_auto THEN 'AUTO_APPROVED' ELSE 'APPROVED' END,
        reviewed_by = p_reviewer,
        review_note = left(COALESCE(p_note, ''), 300),
        reviewed_at = NOW()
    WHERE id = v_proof.id;

    INSERT INTO public.user_trust (user_id, score, rejected_streak)
    VALUES (v_proof.user_id, 1, 0)
    ON CONFLICT (user_id) DO UPDATE
    SET score = user_trust.score + 1, rejected_streak = 0, updated_at = NOW();

    RETURN jsonb_build_object('success', true, 'status', CASE WHEN p_auto THEN 'AUTO_APPROVED' ELSE 'APPROVED' END,
                              'reward', v_proof.reward_amount);
  END IF;

  -- Rejeição
  UPDATE public.task_distribution_queue
  SET status = 'EXPIRED'
  WHERE id = v_proof.queue_id;

  UPDATE public.task_proofs
  SET status = 'REJECTED',
      reviewed_by = p_reviewer,
      review_note = left(COALESCE(p_note, ''), 300),
      reviewed_at = NOW()
  WHERE id = v_proof.id;

  INSERT INTO public.user_trust (user_id, score, rejected_streak)
  VALUES (v_proof.user_id, 0, 1)
  ON CONFLICT (user_id) DO UPDATE
  SET score = GREATEST(user_trust.score - 2, 0),
      rejected_streak = user_trust.rejected_streak + 1,
      updated_at = NOW()
  RETURNING rejected_streak INTO v_streak;

  IF v_streak >= 3 THEN
    PERFORM set_config('app.skip_profile_guard', 'on', true);
    UPDATE public.profiles
    SET suspended_until = NOW() + INTERVAL '7 days', updated_at = NOW()
    WHERE id = v_proof.user_id;
    UPDATE public.user_trust SET rejected_streak = 0 WHERE user_id = v_proof.user_id;
  END IF;

  RETURN jsonb_build_object('success', true, 'status', 'REJECTED', 'suspended', COALESCE(v_streak >= 3, false));
END;
$$;
REVOKE ALL ON FUNCTION public._settle_task_proof(UUID, BOOLEAN, UUID, TEXT, BOOLEAN) FROM PUBLIC, anon, authenticated;

-- --------------------------------------------------------------------
-- 5) Distribuição: não atribuir ao criador as suas próprias tarefas; devolver estado da prova
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fetch_or_assign_community_tasks()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_sub TEXT;
  v_active BOOLEAN;
  v_open INTEGER;
  v_has_link BOOLEAN;
  v_result jsonb;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  -- Só assinantes activos recebem links de outros utilizadores (antes: só o ecrã escondia o separador)
  SELECT subscription_status, is_active INTO v_sub, v_active FROM public.profiles WHERE id = v_user_id;
  IF v_active IS DISTINCT FROM TRUE OR v_sub IS DISTINCT FROM 'active' THEN
    RETURN '[]'::jsonb;
  END IF;

  -- Repõe até 5 tarefas abertas (antes: cada chamada juntava mais 5 e a fila crescia sem limite)
  SELECT count(*) INTO v_open
  FROM public.task_distribution_queue WHERE user_id = v_user_id AND status = 'ASSIGNED';

  -- Troca de seguidores: só recebe links de outros quem também tem o seu link publicado
  SELECT EXISTS (
    SELECT 1 FROM public.community_tasks
    WHERE creator_user_id = v_user_id AND source = 'EXCHANGE' AND is_active = true
  ) INTO v_has_link;

  IF v_open < 5 THEN
    INSERT INTO public.task_distribution_queue (
      user_id, task_id, platform, task_type, profile_url, description, status
    )
    SELECT v_user_id, ct.id, ct.platform, ct.task_type, ct.profile_url, ct.description, 'ASSIGNED'
    FROM public.community_tasks ct
    WHERE ct.is_active = true
      AND ct.creator_user_id IS DISTINCT FROM v_user_id
      AND (ct.source <> 'EXCHANGE' OR v_has_link)
      -- tarefas da loja: execuções pagas + provas por validar cabem no limite comprado
      -- (troca de seguidores não tem limite: passa por todos os utilizadores, incluindo os novos)
      AND (ct.source = 'EXCHANGE' OR ct.current_completions + (
            SELECT count(*) FROM public.task_proofs tp WHERE tp.task_id = ct.id AND tp.status = 'SUBMITTED'
          ) < ct.max_completions)
      AND NOT EXISTS (
        SELECT 1 FROM public.task_distribution_queue tq
        WHERE tq.user_id = v_user_id AND tq.task_id = ct.id
      )
    -- distribuição justa: primeiro as tarefas com menos utilizadores atribuídos, depois as mais antigas
    ORDER BY (SELECT count(*) FROM public.task_distribution_queue q WHERE q.task_id = ct.id) ASC,
             ct.created_at ASC
    LIMIT (5 - v_open)
    ON CONFLICT (user_id, task_id) DO NOTHING;
  END IF;

  SELECT coalesce(jsonb_agg(
    jsonb_build_object(
      'id', tq.id,
      'task_id', tq.task_id,
      'platform', ct.platform,
      'task_type', ct.task_type,
      'profile_url', ct.profile_url,   -- sempre o link actual do dono (se o mudar, todos veem o novo)
      'description', ct.description,
      'status', tq.status,
      'proof_status', tp.status
    )
  ), '[]'::jsonb)
  INTO v_result
  FROM public.task_distribution_queue tq
  JOIN public.community_tasks ct ON ct.id = tq.task_id AND ct.is_active = true
  LEFT JOIN public.task_proofs tp ON tp.queue_id = tq.id
  WHERE tq.user_id = v_user_id AND tq.status = 'ASSIGNED';

  RETURN v_result;
END;
$$;

-- --------------------------------------------------------------------
-- 6) Utilizador envia a prova (substitui o antigo "CONFIRMAR" que pagava logo)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_task_proof(
  p_task_id UUID,
  p_proof_path TEXT,
  p_proof_hash TEXT,
  p_handle TEXT
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_sub TEXT;
  v_active BOOLEAN;
  v_susp TIMESTAMPTZ;
  v_queue RECORD;
  v_task RECORD;
  v_handle TEXT;
  v_hash TEXT;
  v_platform TEXT;
  v_existing_handle TEXT;
  v_daily_limit INTEGER;
  v_trust INTEGER;
  v_cap INTEGER;
  v_done_today INTEGER;
  v_proof_id UUID;
  v_pending INTEGER;
  v_reward NUMERIC(10, 2);
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT subscription_status, is_active, suspended_until
    INTO v_sub, v_active, v_susp
  FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_sub IS DISTINCT FROM 'active' THEN RAISE EXCEPTION 'Assinatura activa necessária.'; END IF;
  IF v_susp IS NOT NULL AND v_susp > NOW() THEN
    RAISE EXCEPTION 'Conta suspensa até %.', to_char(v_susp, 'DD/MM/YYYY');
  END IF;

  v_hash := lower(trim(COALESCE(p_proof_hash, '')));
  IF v_hash !~ '^[0-9a-f]{64}$' THEN RAISE EXCEPTION 'Prova inválida.'; END IF;

  IF p_proof_path IS NULL
     OR split_part(trim(p_proof_path), '/', 1) <> v_uid::text
     OR position('..' IN p_proof_path) > 0 THEN
    RAISE EXCEPTION 'Caminho da prova inválido para este utilizador.';
  END IF;

  SELECT * INTO v_queue
  FROM public.task_distribution_queue
  WHERE user_id = v_uid AND task_id = p_task_id AND status = 'ASSIGNED'
  FOR UPDATE;
  IF v_queue.id IS NULL THEN RAISE EXCEPTION 'Tarefa não encontrada ou já concluída.'; END IF;

  IF EXISTS (SELECT 1 FROM public.task_proofs WHERE queue_id = v_queue.id) THEN
    RAISE EXCEPTION 'Já enviou a prova desta tarefa.';
  END IF;

  IF v_queue.assigned_at IS NOT NULL AND v_queue.assigned_at > NOW() - INTERVAL '15 seconds' THEN
    RAISE EXCEPTION 'Execute a tarefa e só depois envie a prova.';
  END IF;

  SELECT * INTO v_task FROM public.community_tasks WHERE id = p_task_id;
  IF v_task.id IS NULL OR v_task.is_active IS NOT TRUE THEN
    RAISE EXCEPTION 'Esta tarefa já não está disponível.';
  END IF;
  IF v_task.creator_user_id IS NOT DISTINCT FROM v_uid THEN
    RAISE EXCEPTION 'Não pode executar as suas próprias tarefas.';
  END IF;

  -- Nunca pagar mais execuções do que o comprador adquiriu
  SELECT count(*) INTO v_pending FROM public.task_proofs WHERE task_id = p_task_id AND status = 'SUBMITTED';
  IF v_task.source <> 'EXCHANGE' AND v_task.current_completions + v_pending >= v_task.max_completions THEN
    RAISE EXCEPTION 'Esta tarefa já atingiu o limite de execuções.';
  END IF;

  v_platform := lower(v_task.platform);
  IF v_platform NOT IN ('tiktok', 'instagram', 'youtube') THEN
    RAISE EXCEPTION 'Plataforma não suportada.';
  END IF;

  -- @ normalizado e associado de forma permanente à conta (um @ = uma conta por plataforma)
  v_handle := lower(regexp_replace(trim(COALESCE(p_handle, '')), '^@+', ''));
  IF v_handle !~ '^[a-z0-9._-]{2,40}$' THEN
    RAISE EXCEPTION 'Indique o seu @ da plataforma (2–40 caracteres: letras, números, ponto, hífen ou _).';
  END IF;

  SELECT handle INTO v_existing_handle
  FROM public.social_handles WHERE user_id = v_uid AND platform = v_platform;

  IF v_existing_handle IS NOT NULL AND lower(v_existing_handle) <> v_handle THEN
    RAISE EXCEPTION 'A sua conta % registada é @%. Use sempre o mesmo @.', v_platform, v_existing_handle;
  END IF;

  IF v_existing_handle IS NULL THEN
    BEGIN
      INSERT INTO public.social_handles (user_id, platform, handle) VALUES (v_uid, v_platform, v_handle);
    EXCEPTION WHEN unique_violation THEN
      RAISE EXCEPTION 'Este @ já está associado a outra conta ADX.';
    END;
  END IF;

  -- Limite diário (mais baixo enquanto a confiança é pequena)
  SELECT daily_limit INTO v_daily_limit FROM public.community_settings WHERE platform = v_platform;
  v_daily_limit := COALESCE(v_daily_limit, 100);
  SELECT COALESCE(score, 0) INTO v_trust FROM public.user_trust WHERE user_id = v_uid;
  v_trust := COALESCE(v_trust, 0);
  v_cap := CASE WHEN v_trust < 5 THEN LEAST(v_daily_limit, 10) ELSE v_daily_limit END;

  SELECT count(*) INTO v_done_today
  FROM public.task_proofs tp
  JOIN public.community_tasks ct ON ct.id = tp.task_id
  WHERE tp.user_id = v_uid
    AND lower(ct.platform) = v_platform
    AND tp.created_at >= date_trunc('day', NOW());
  IF v_done_today >= v_cap THEN
    RAISE EXCEPTION 'Limite diário de % atingido (%).', v_platform, v_cap;
  END IF;

  -- Troca de seguidores: recompensa lida das definições (admin pode pôr 0 = troca pura); loja: valor da tarefa
  IF v_task.source = 'EXCHANGE' THEN
    SELECT exchange_reward INTO v_reward FROM public.community_settings WHERE platform = v_platform;
    v_reward := COALESCE(v_reward, 0);
  ELSE
    v_reward := COALESCE(v_task.reward_amount, 5.00);
  END IF;

  BEGIN
    INSERT INTO public.task_proofs (
      queue_id, task_id, user_id, handle, proof_path, proof_hash, status, reward_amount, due_at
    ) VALUES (
      v_queue.id, p_task_id, v_uid, v_handle, trim(p_proof_path), v_hash, 'SUBMITTED',
      v_reward, NOW() + CASE WHEN v_task.source = 'EXCHANGE' THEN INTERVAL '24 hours' ELSE INTERVAL '48 hours' END
    )
    RETURNING id INTO v_proof_id;
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'Esta captura de ecrã já foi utilizada.';
  END;

  RETURN jsonb_build_object('success', true, 'proof_id', v_proof_id, 'status', 'SUBMITTED');
END;
$$;
GRANT EXECUTE ON FUNCTION public.submit_task_proof(UUID, TEXT, TEXT, TEXT) TO authenticated;

-- --------------------------------------------------------------------
-- 7) Criador da tarefa ou admin avalia a prova
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.review_task_proof(
  p_proof_id UUID,
  p_approve BOOLEAN,
  p_note TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_proof RECORD;
  v_creator UUID;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT * INTO v_proof FROM public.task_proofs WHERE id = p_proof_id;
  IF v_proof.id IS NULL THEN RAISE EXCEPTION 'Prova não encontrada.'; END IF;

  SELECT creator_user_id INTO v_creator FROM public.community_tasks WHERE id = v_proof.task_id;

  IF NOT (public.is_admin() OR v_creator IS NOT DISTINCT FROM v_uid) THEN
    RAISE EXCEPTION 'Sem permissão para avaliar esta prova.';
  END IF;
  IF v_proof.user_id = v_uid THEN
    RAISE EXCEPTION 'Não pode avaliar a sua própria prova.';
  END IF;
  IF NOT p_approve AND (p_note IS NULL OR length(trim(p_note)) < 3) THEN
    RAISE EXCEPTION 'Indique o motivo da rejeição.';
  END IF;

  RETURN public._settle_task_proof(p_proof_id, p_approve, v_uid, p_note, FALSE);
END;
$$;
GRANT EXECUTE ON FUNCTION public.review_task_proof(UUID, BOOLEAN, TEXT) TO authenticated;

-- --------------------------------------------------------------------
-- 8) Vencidas (24h troca / 48h loja): aprovação automática conforme risco; o resto escala para o admin
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.auto_approve_stale_proofs()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  r RECORD;
  v_trust INTEGER;
  v_count INTEGER := 0;
BEGIN
  FOR r IN
    SELECT tp.id, tp.user_id, tp.reward_amount, ct.source
    FROM public.task_proofs tp
    JOIN public.community_tasks ct ON ct.id = tp.task_id
    WHERE tp.status = 'SUBMITTED' AND tp.due_at < NOW()
    ORDER BY tp.due_at
    LIMIT 500
  LOOP
    SELECT COALESCE(score, 0) INTO v_trust FROM public.user_trust WHERE user_id = r.user_id;
    v_trust := COALESCE(v_trust, 0);

    -- Sem validação do dono no prazo:
    --  • troca de seguidores sem dinheiro (recompensa 0): aprova sempre, não há nada em risco
    --    e o admin deixa de ser gargalo;
    --  • restantes: só quem tem confiança; os outros ficam escalados para o admin.
    IF (r.source = 'EXCHANGE' AND COALESCE(r.reward_amount, 0) = 0) OR v_trust >= 3 THEN
      PERFORM public._settle_task_proof(r.id, TRUE, NULL, 'Aprovação automática (sem avaliação no prazo)', TRUE);
      v_count := v_count + 1;
    ELSE
      UPDATE public.task_proofs SET escalated = TRUE WHERE id = r.id AND escalated = FALSE;
    END IF;
  END LOOP;
  RETURN v_count;
END;
$$;
REVOKE ALL ON FUNCTION public.auto_approve_stale_proofs() FROM PUBLIC, anon, authenticated;

-- Botão no painel admin (funciona mesmo sem pg_cron)
CREATE OR REPLACE FUNCTION public.admin_run_auto_approve()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;
  RETURN public.auto_approve_stale_proofs();
END;
$$;
GRANT EXECUTE ON FUNCTION public.admin_run_auto_approve() TO authenticated;

-- Agendamento automático (se a extensão pg_cron estiver disponível no projecto)
DO $$
BEGIN
  CREATE EXTENSION IF NOT EXISTS pg_cron;
  PERFORM cron.schedule('adx-auto-approve-proofs', '*/30 * * * *', 'SELECT public.auto_approve_stale_proofs();');
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron indisponível (%). Use o botão "Processar vencidas" no painel admin.', SQLERRM;
END;
$$;

-- Recarrega o cache de schema do PostgREST (evita 'column ... in the schema cache')
NOTIFY pgrst, 'reload schema';
