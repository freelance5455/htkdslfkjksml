-- VERIFY.sql — só leitura. Executar depois de 014–033. Todas as linhas devem ter ok = true.
SELECT '014 handle_new_user ignora role do metadata' AS verificacao,
       NOT (pg_get_functiondef('public.handle_new_user()'::regprocedure) ILIKE '%''role''%') AS ok
UNION ALL SELECT '014 coluna profiles.facebook',
       EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='facebook')
UNION ALL SELECT '014 coluna profiles.suspended_until',
       EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='suspended_until')
UNION ALL SELECT '014 admin_create_user legado sem EXECUTE para authenticated',
       to_regprocedure('public.admin_create_user(text,text,text,text,text)') IS NULL
       OR NOT has_function_privilege('authenticated','public.admin_create_user(text,text,text,text,text)','EXECUTE')
UNION ALL SELECT '015 sem INSERT directo em wallet_deposits', NOT has_table_privilege('authenticated','public.wallet_deposits','INSERT')
UNION ALL SELECT '015 sem INSERT directo em campaign_requests', NOT has_table_privilege('authenticated','public.campaign_requests','INSERT')
UNION ALL SELECT '015 sem INSERT directo em subscription_payments', NOT has_table_privilege('authenticated','public.subscription_payments','INSERT')
UNION ALL SELECT '015 sem INSERT directo em engagement_orders', NOT has_table_privilege('authenticated','public.engagement_orders','INSERT')
UNION ALL SELECT '015 sem UPDATE directo em task_distribution_queue', NOT has_table_privilege('authenticated','public.task_distribution_queue','UPDATE')
UNION ALL SELECT '016 ledger aceita CAMPAIGN_REFUND',
       EXISTS (SELECT 1 FROM pg_constraint WHERE conname='wallet_transactions_type_check' AND pg_get_constraintdef(oid) LIKE '%CAMPAIGN_REFUND%')
UNION ALL SELECT '016 admin_process_campaign_request existe',
       to_regprocedure('public.admin_process_campaign_request(uuid,text,text)') IS NOT NULL
UNION ALL SELECT '017 submit_wallet_deposit existe', to_regprocedure('public.submit_wallet_deposit(numeric,text,text,text)') IS NOT NULL
UNION ALL SELECT '017 submit_subscription_payment existe', to_regprocedure('public.submit_subscription_payment(numeric,text,text,text,text)') IS NOT NULL
UNION ALL SELECT '017 request_withdrawal existe', to_regprocedure('public.request_withdrawal(numeric,text,jsonb)') IS NOT NULL
UNION ALL SELECT '018 admin_assign_campaign existe', to_regprocedure('public.admin_assign_campaign(uuid,uuid[])') IS NOT NULL
UNION ALL SELECT '018 admin_toggle_affiliate existe', to_regprocedure('public.admin_toggle_affiliate(uuid,boolean,text)') IS NOT NULL
UNION ALL SELECT '019 policies do bucket subscription-proofs',
       (SELECT count(*) FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname IN ('proofs_insert_own','proofs_select_own_or_admin')) = 2
UNION ALL SELECT '020 coluna public_register_log.ip',
       EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='public_register_log' AND column_name='ip')
UNION ALL SELECT '021 complete_community_task fechada ao utilizador',
       NOT has_function_privilege('authenticated','public.complete_community_task(uuid)','EXECUTE')
UNION ALL SELECT '027 complete_campaign_execution removida (pagamento fixo sem resultado)',
       to_regprocedure('public.complete_campaign_execution(uuid)') IS NULL
UNION ALL SELECT '021 tabelas task_proofs / social_handles / user_trust',
       to_regclass('public.task_proofs') IS NOT NULL AND to_regclass('public.social_handles') IS NOT NULL AND to_regclass('public.user_trust') IS NOT NULL
UNION ALL SELECT '021 @ único por plataforma (índice)',
       EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND indexname='uq_social_handles_platform_handle')
UNION ALL SELECT '021 submit_task_proof existe', to_regprocedure('public.submit_task_proof(uuid,text,text,text)') IS NOT NULL
UNION ALL SELECT '021 review_task_proof existe', to_regprocedure('public.review_task_proof(uuid,boolean,text)') IS NOT NULL
UNION ALL SELECT '021 liquidação interna não exposta',
       NOT has_function_privilege('authenticated','public._settle_task_proof(uuid,boolean,uuid,text,boolean)','EXECUTE')
UNION ALL SELECT '021 auto-aprovação não exposta a utilizadores',
       NOT has_function_privilege('authenticated','public.auto_approve_stale_proofs()','EXECUTE')
UNION ALL SELECT '022 fila de limpeza existe', to_regclass('public.proof_purge_queue') IS NOT NULL
UNION ALL SELECT '022 gatilhos de limpeza (4)',
       (SELECT count(*) FROM pg_trigger WHERE tgname IN ('purge_task_proof','purge_subscription_payment','purge_wallet_deposit','purge_engagement_order') AND NOT tgisinternal) = 4
UNION ALL SELECT '022 claim_proof_purge_batch só para service_role',
       NOT has_function_privilege('authenticated','public.claim_proof_purge_batch(integer)','EXECUTE')
UNION ALL SELECT '022 policy de apagar ficheiros próprios não referenciados',
       EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname='proofs_delete_own_unreferenced')
UNION ALL SELECT '023 refresh_user_level fechada a utilizadores e anónimos',
       NOT has_function_privilege('authenticated','public.refresh_user_level(uuid)','EXECUTE')
       AND NOT has_function_privilege('anon','public.refresh_user_level(uuid)','EXECUTE')
UNION ALL SELECT '023 nenhuma função SECURITY DEFINER executável por anon (exceto ajudantes de RLS)',
       NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
                   WHERE n.nspname='public' AND p.prosecdef AND p.prorettype <> 'trigger'::regtype
                     AND p.proname NOT IN ('is_admin','is_task_creator','can_view_task_proof_file','proof_path_in_use')
                     AND has_function_privilege('anon', p.oid, 'EXECUTE'))
UNION ALL SELECT '023 todas as SECURITY DEFINER com search_path fixo',
       NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
                   WHERE n.nspname='public' AND p.prosecdef
                     AND NOT EXISTS (SELECT 1 FROM unnest(COALESCE(p.proconfig, ARRAY[]::text[])) c WHERE c LIKE 'search_path=%'))
UNION ALL SELECT '023 índice anti-crédito-duplicado (se false: ver RECONCILE.sql)',
       EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND indexname='uq_wallet_tx_once_per_ref')
UNION ALL SELECT '024 get_wallet_flow existe e fechada a anónimos',
       to_regprocedure('public.get_wallet_flow(integer)') IS NOT NULL
       AND NOT has_function_privilege('anon','public.get_wallet_flow(integer)','EXECUTE')
UNION ALL SELECT 'RLS activa em TODAS as tabelas do schema public',
       NOT EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
                   WHERE n.nspname='public' AND c.relkind IN ('r','p') AND NOT c.relrowsecurity)
UNION ALL SELECT 'anon sem privilégios de escrita em tabelas do public',
       NOT EXISTS (SELECT 1 FROM information_schema.role_table_grants
                   WHERE table_schema='public' AND grantee='anon' AND privilege_type IN ('INSERT','UPDATE','DELETE'))
UNION ALL SELECT '021 community_tasks.creator_user_id existe',
       EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='community_tasks' AND column_name='creator_user_id')
UNION ALL SELECT '021 community_tasks tem todas as colunas usadas pelo painel',
       (SELECT count(*) FROM information_schema.columns WHERE table_schema='public' AND table_name='community_tasks'
        AND column_name IN ('task_type','description','max_completions','current_completions','is_active','reward_amount','profile_url','platform')) = 8
UNION ALL SELECT '021 task_distribution_queue aceita EXPIRED',
       EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.task_distribution_queue'::regclass AND contype='c' AND pg_get_constraintdef(oid) LIKE '%EXPIRED%')
UNION ALL SELECT '018 complete_community_task existe', to_regprocedure('public.complete_community_task(uuid)') IS NOT NULL
UNION ALL SELECT '025 admin_launch_engagement_task existe', to_regprocedure('public.admin_launch_engagement_task(uuid)') IS NOT NULL
UNION ALL SELECT '025 admin_resolve_task_report existe', to_regprocedure('public.admin_resolve_task_report(uuid,text,boolean)') IS NOT NULL
UNION ALL SELECT '011/013 admin_process_wallet_deposit existe', to_regprocedure('public.admin_process_wallet_deposit(uuid,text,text)') IS NOT NULL
UNION ALL SELECT '017 admin_process_withdrawal existe', to_regprocedure('public.admin_process_withdrawal(uuid,text,text)') IS NOT NULL
UNION ALL SELECT '017 admin_process_subscription_payment existe', to_regprocedure('public.admin_process_subscription_payment(uuid,text,text)') IS NOT NULL
UNION ALL SELECT 'nenhuma FK bloqueia a eliminação de utilizadores (NO ACTION/RESTRICT para auth.users ou profiles)',
       NOT EXISTS (SELECT 1 FROM pg_constraint WHERE contype='f'
                   AND confrelid IN ('auth.users'::regclass,'public.profiles'::regclass) AND confdeltype IN ('a','r'))
UNION ALL SELECT '019 bucket subscription-proofs existe e é privado',
       EXISTS (SELECT 1 FROM storage.buckets WHERE id='subscription-proofs' AND public = false)
UNION ALL SELECT '025 painel: FK única para profiles em ' || t,
       (SELECT count(*) FROM pg_constraint WHERE contype='f' AND conrelid=('public.'||t)::regclass
        AND confrelid='public.profiles'::regclass) = 1
FROM unnest(ARRAY['wallets','campaign_assignments','withdrawals','affiliate_profiles','campaign_requests','engagement_orders']) AS t
UNION ALL SELECT '026 função ' || f, to_regprocedure('public.' || f) IS NOT NULL
FROM unnest(ARRAY['_exchange_link(text,text)','_sync_exchange_tasks(uuid)','trg_sync_exchange_tasks()']) AS f
UNION ALL SELECT '026 gatilho trg_profiles_sync_exchange existe',
       EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_profiles_sync_exchange' AND NOT tgisinternal)
UNION ALL SELECT '026 índice único da troca existe',
       to_regclass('public.uq_exchange_task_user_platform') IS NOT NULL
UNION ALL SELECT '027 tabela ' || t, to_regclass('public.' || t) IS NOT NULL
FROM unnest(ARRAY['economy_settings','affiliate_commissions','affiliate_commission_failures','campaign_results','campaign_result_payouts']) AS t
UNION ALL SELECT '027 função ' || f, to_regprocedure('public.' || f) IS NOT NULL
FROM unnest(ARRAY['econ(text,numeric)','expire_subscriptions()','refresh_my_subscription()','join_campaign(uuid)',
                  'complete_campaign_participation(uuid)','admin_register_campaign_result(uuid,numeric,text,text,boolean)','admin_retry_commission_failures()',
                  'admin_set_economy_setting(text,numeric)','admin_set_community_setting(text,numeric,numeric,integer)',
                  '_pay_affiliate_commission(uuid,text,uuid,numeric,numeric)','_complete_referral(uuid)']) AS f
UNION ALL SELECT '027 gatilho ' || tg,
       EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = tg AND NOT tgisinternal)
FROM unnest(ARRAY['trg_subscription_commission','trg_engagement_commission','trg_campaign_request_commission']) AS tg
UNION ALL SELECT '027 profiles.subscription_expires_at existe',
       EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='subscription_expires_at')
UNION ALL SELECT '027 todo assinante ativo tem data de validade',
       NOT EXISTS (SELECT 1 FROM public.profiles WHERE subscription_status='active' AND subscription_expires_at IS NULL)
UNION ALL SELECT '027 definições de economia carregadas (10)',
       (SELECT count(*) FROM public.economy_settings) >= 10
UNION ALL SELECT '028 histórico financeiro protegido contra DELETE em ' || t,
       EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_protect_financial_history' AND tgrelid=('public.'||t)::regclass AND NOT tgisinternal)
FROM unnest(ARRAY['wallet_transactions','withdrawals','wallet_deposits','subscription_payments','engagement_orders','campaign_requests']) AS t
UNION ALL SELECT '028 carteira com saldo não pode ser apagada',
       EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_protect_wallet_delete' AND NOT tgisinternal)
UNION ALL SELECT '028 saques exigem aprovação antes de pagar (recomendado; ajuste em Definições → Economia)',
       COALESCE((SELECT value FROM public.economy_settings WHERE key='withdrawal_require_approval'), 0) = 1
UNION ALL SELECT '029 tabela ' || t, to_regclass('public.' || t) IS NOT NULL
FROM unnest(ARRAY['terms_acceptances','app_errors']) AS t
UNION ALL SELECT '029 função ' || f, to_regprocedure('public.' || f) IS NOT NULL
FROM unnest(ARRAY['accept_terms(text)','admin_reconcile_wallets()','log_client_error(text,text,text,text)']) AS f
UNION ALL SELECT '029 tetos de saque definidos (3)',
       (SELECT count(*) FROM public.economy_settings WHERE key IN ('withdrawal_max_per_request_aoa','withdrawal_max_daily_per_user_aoa','withdrawal_global_daily_cap_aoa')) = 3
UNION ALL SELECT '029 request_withdrawal inclui os tetos',
       pg_get_functiondef('public.request_withdrawal(numeric,text,jsonb)'::regprocedure) LIKE '%withdrawal_max_daily_per_user_aoa%'
UNION ALL SELECT '030 um único trigger de registo (on_auth_user_created → handle_new_user)',
       EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_proc p ON p.oid = t.tgfoid
               WHERE t.tgrelid = 'auth.users'::regclass AND t.tgname = 'on_auth_user_created'
                 AND p.proname = 'handle_new_user' AND NOT t.tgisinternal)
       AND NOT EXISTS (SELECT 1 FROM pg_trigger t WHERE t.tgrelid = 'auth.users'::regclass
                       AND t.tgname = 'on_auth_user_created_profile')
UNION ALL SELECT '030 registo nunca lê o role enviado pelo cliente (handle_new_user)',
       pg_get_functiondef('public.handle_new_user()'::regprocedure) NOT ILIKE '%->> ''role''%'
UNION ALL SELECT '030 função legada handle_new_auth_user (se existir) também não lê o role do cliente',
       NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'handle_new_auth_user' AND pronamespace = 'public'::regnamespace
                   AND pg_get_functiondef(oid) ILIKE '%->> ''role''%')
UNION ALL SELECT '032 community_tasks.created_by: apagar utilizador não é bloqueado (ON DELETE SET NULL)',
       COALESCE((SELECT confdeltype = 'n' FROM pg_constraint WHERE conname = 'community_tasks_created_by_fkey'), true)
UNION ALL SELECT '033 versão oficial dos termos configurada no servidor',
       EXISTS (SELECT 1 FROM public.app_settings WHERE key = 'terms_version')
UNION ALL SELECT '033 função ' || f, to_regprocedure('public.' || f) IS NOT NULL
FROM unnest(ARRAY['current_terms_version()','ai_rate_limit_check(uuid,text,integer,integer)']) AS f
UNION ALL SELECT '033 limite de IA e versão dos termos fechados ao utilizador (só service_role)',
       NOT has_function_privilege('authenticated','public.ai_rate_limit_check(uuid,text,integer,integer)','EXECUTE')
       AND NOT has_function_privilege('anon','public.ai_rate_limit_check(uuid,text,integer,integer)','EXECUTE')
       AND NOT has_table_privilege('authenticated','public.ai_usage_log','SELECT')
       AND NOT has_table_privilege('authenticated','public.app_settings','SELECT')
UNION ALL SELECT '035 push triggers + admin_enqueue',
       to_regprocedure('public._notify_user(uuid,text,text,text,jsonb)') IS NOT NULL
       AND to_regprocedure('public.admin_enqueue_notification(uuid,text,text,text)') IS NOT NULL
UNION ALL SELECT '034 device_tokens + prefs + queue',
       to_regclass('public.device_tokens') IS NOT NULL
       AND to_regclass('public.notification_preferences') IS NOT NULL
       AND to_regclass('public.notification_queue') IS NOT NULL
UNION ALL SELECT '034 RPC upsert_device_token autenticada',
       to_regprocedure('public.upsert_device_token(text,text,text,text)') IS NOT NULL
       AND has_function_privilege('authenticated','public.upsert_device_token(text,text,text,text)','EXECUTE')
UNION ALL SELECT '034 enqueue/claim só service_role',
       NOT has_function_privilege('authenticated','public.enqueue_notification(uuid,text,text,text,jsonb)','EXECUTE')
       AND NOT has_function_privilege('anon','public.enqueue_notification(uuid,text,text,text,jsonb)','EXECUTE')
       AND has_function_privilege('service_role','public.claim_notification_batch(integer)','EXECUTE')
UNION ALL SELECT '028 telefone único por conta (índice)',
       to_regclass('public.uq_profiles_phone') IS NOT NULL
UNION ALL SELECT '027 guarda do perfil protege subscription_expires_at',
       pg_get_functiondef('public.protect_profile_sensitive_columns()'::regprocedure) LIKE '%subscription_expires_at%'
UNION ALL SELECT '027 funções internas de dinheiro fechadas ao utilizador',
       NOT has_function_privilege('authenticated','public._pay_affiliate_commission(uuid,text,uuid,numeric,numeric)','EXECUTE')
       AND NOT has_function_privilege('authenticated','public._credit_wallet(uuid,numeric,text,text,text)','EXECUTE')
       AND NOT has_function_privilege('authenticated','public.expire_subscriptions()','EXECUTE')
UNION ALL SELECT '026 todo assinante ativo com link válido tem tarefa de troca activa',
       NOT EXISTS (
         SELECT 1 FROM public.profiles p
         WHERE p.is_active AND p.subscription_status='active'
           AND (public._exchange_link('tiktok', p.tiktok) IS NOT NULL
                OR public._exchange_link('instagram', p.instagram) IS NOT NULL
                OR public._exchange_link('youtube', p.youtube) IS NOT NULL)
           AND NOT EXISTS (SELECT 1 FROM public.community_tasks ct
                           WHERE ct.creator_user_id = p.id AND ct.source='EXCHANGE'
                             AND (ct.is_active OR ct.disabled_by_admin))
       );

-- Auditoria completa de permissões (correr à parte): funções SECURITY DEFINER e quem as pode executar
-- SELECT p.proname, pg_get_function_identity_arguments(p.oid) AS args,
--        has_function_privilege('anon', p.oid, 'EXECUTE') AS anon,
--        has_function_privilege('authenticated', p.oid, 'EXECUTE') AS authenticated
-- FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
-- WHERE n.nspname = 'public' AND p.prosecdef ORDER BY p.proname;

-- Auditoria manual (correr à parte): policies do bucket. Se existir alguma permissiva antiga
-- (ex.: USING (bucket_id='subscription-proofs')), remove-a.
-- SELECT policyname, cmd, qual FROM pg_policies WHERE schemaname='storage' AND tablename='objects' ORDER BY policyname;
