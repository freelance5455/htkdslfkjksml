-- ====================================================================
-- 032 — community_tasks.created_by: a eliminação de um utilizador deixa de ser bloqueada
-- O repositório (001) define ON DELETE SET NULL; na base real a FK ficou NO ACTION.
-- Idempotente.
-- ====================================================================
ALTER TABLE public.community_tasks DROP CONSTRAINT IF EXISTS community_tasks_created_by_fkey;
ALTER TABLE public.community_tasks
  ADD CONSTRAINT community_tasks_created_by_fkey
  FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;
