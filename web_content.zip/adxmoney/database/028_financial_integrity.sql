-- ====================================================================
-- 028 — Integridade financeira
-- Executar DEPOIS de 027. Idempotente.
--
-- Problema: várias tabelas com dinheiro tinham ON DELETE CASCADE a partir de auth.users/profiles.
-- Eliminar uma conta apagava carteira, movimentos, depósitos, saques, assinaturas, pedidos e comissões.
--
-- Regra nova: o histórico financeiro é IMUTÁVEL. Uma conta com histórico só pode ser DESATIVADA
-- (a Edge Function admin-delete-user já faz isso). Mesmo que alguém chame deleteUser diretamente
-- ou apague linhas por SQL, a base de dados recusa.
-- ====================================================================

-- 1) Recusa apagar linhas de tabelas com dinheiro (inclui apagamentos em cascata)
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = 'admin_process_withdrawal' AND pg_get_function_result(p.oid) <> 'jsonb')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

CREATE OR REPLACE FUNCTION public._protect_financial_history()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
  -- Saída de emergência, só para manutenção consciente (ex.: limpar contas de teste), na mesma transação:
  --   BEGIN; SELECT set_config('app.allow_financial_delete', 'on', true); DELETE ...; COMMIT;
  IF current_setting('app.allow_financial_delete', true) = 'on' THEN
    RETURN OLD;
  END IF;
  RAISE EXCEPTION 'Histórico financeiro protegido (%): desative a conta em vez de a eliminar.', TG_TABLE_NAME
    USING ERRCODE = 'restrict_violation';
END;
$$;

-- 2) A carteira só pode desaparecer se estiver a zero (e, via ledger protegido acima, sem movimentos)
CREATE OR REPLACE FUNCTION public._protect_wallet_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
  IF current_setting('app.allow_financial_delete', true) = 'on' THEN
    RETURN OLD;
  END IF;
  IF COALESCE(OLD.balance, 0) <> 0 OR COALESCE(OLD.reserved_balance, 0) <> 0 THEN
    RAISE EXCEPTION 'Carteira com saldo não pode ser eliminada: desative a conta.'
      USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN OLD;
END;
$$;

DO $$
DECLARE
  t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'wallet_transactions', 'withdrawals', 'wallet_deposits', 'subscription_payments',
    'engagement_orders', 'campaign_requests', 'affiliate_commissions', 'campaign_result_payouts',
    'campaign_results'
  ]
  LOOP
    IF to_regclass('public.' || t) IS NOT NULL THEN
      EXECUTE format('DROP TRIGGER IF EXISTS trg_protect_financial_history ON public.%I', t);
      EXECUTE format(
        'CREATE TRIGGER trg_protect_financial_history BEFORE DELETE ON public.%I
         FOR EACH ROW EXECUTE FUNCTION public._protect_financial_history()', t);
    END IF;
  END LOOP;
END $$;

DROP TRIGGER IF EXISTS trg_protect_wallet_delete ON public.wallets;
CREATE TRIGGER trg_protect_wallet_delete BEFORE DELETE ON public.wallets
FOR EACH ROW EXECUTE FUNCTION public._protect_wallet_delete();

-- 3) Um telefone = uma conta (a verificação na Edge Function sozinha tinha janela de concorrência).
--    Só cria o índice se não houver duplicados já existentes.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE phone IS NOT NULL AND btrim(phone) <> ''
    GROUP BY phone HAVING count(*) > 1
  ) THEN
    RAISE NOTICE 'Existem telefones duplicados em profiles: índice único NÃO criado. Resolva-os e execute de novo.';
  ELSE
    CREATE UNIQUE INDEX IF NOT EXISTS uq_profiles_phone
      ON public.profiles (phone) WHERE phone IS NOT NULL AND btrim(phone) <> '';
  END IF;
END $$;

-- 4) Saques em dois passos (PENDING → APPROVED → PAID), controlável em Definições → Economia.
--    Por defeito 1 (recomendado para dinheiro real): o PAID só é aceite depois de APPROVED. Com 0 volta ao
--    fluxo de pagar direto a partir de PENDING. Com 1, o PAID só é aceite depois
--    de APPROVED — e a regra é imposta AQUI, na base de dados, não só nos botões do painel.
--    (Substitui a função da 017; só acrescenta a verificação marcada.)
-- DO UPDATE (e não DO NOTHING): instalações que já tinham a definição a 0 passam também a exigir
-- aprovação. Consequência consciente: voltar a executar esta migração repõe 1; se depois quiser pagar
-- direto, altere em Definições → Economia (a alteração fica registada nos logs).
INSERT INTO public.economy_settings (key, value, label) VALUES
  ('withdrawal_require_approval', 1, 'Saques: exigir aprovação antes de pagar (1 = sim, 0 = não)')
ON CONFLICT (key) DO UPDATE SET value = 1, label = EXCLUDED.label, updated_at = NOW();

CREATE OR REPLACE FUNCTION public.admin_process_withdrawal(
  p_withdrawal_id UUID,
  p_action TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin_id UUID := auth.uid();
  v_withdrawal RECORD;
  v_wallet RECORD;
BEGIN
  IF v_admin_id IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem processar saques.';
  END IF;

  SELECT * INTO v_withdrawal FROM public.withdrawals WHERE id = p_withdrawal_id FOR UPDATE;
  IF v_withdrawal.id IS NULL THEN RAISE EXCEPTION 'Solicitação de saque não encontrada.'; END IF;
  IF v_withdrawal.status IN ('PAID', 'REJECTED') THEN
    RAISE EXCEPTION 'Este saque já foi finalizado anteriormente.';
  END IF;

  SELECT * INTO v_wallet FROM public.wallets WHERE user_id = v_withdrawal.user_id FOR UPDATE;
  IF v_wallet.id IS NULL THEN RAISE EXCEPTION 'Carteira do utilizador não encontrada.'; END IF;

  IF p_action = 'APPROVE' THEN
    IF v_withdrawal.status <> 'PENDING' THEN RAISE EXCEPTION 'Só é possível aprovar saques pendentes.'; END IF;
    UPDATE public.withdrawals SET status = 'APPROVED', processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;

  ELSIF p_action = 'PAID' THEN
    -- Regra de dois passos (opcional, Definições → Economia): só se paga o que foi aprovado antes
    IF public.econ('withdrawal_require_approval', 1) = 1 AND v_withdrawal.status <> 'APPROVED' THEN
      RAISE EXCEPTION 'Aprove o saque antes de o pagar (regra de dois passos ativa).';
    END IF;
    UPDATE public.wallets
    SET reserved_balance = GREATEST(0.00, reserved_balance - v_withdrawal.amount), updated_at = NOW()
    WHERE id = v_wallet.id;
    UPDATE public.withdrawals SET status = 'PAID', processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;
    INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
    VALUES (v_wallet.id, v_withdrawal.user_id, 'WITHDRAWAL_PAID', 0.00,
            'Saque liquidado e transferido ao usuário (' || v_withdrawal.amount || ' Kz)',
            p_withdrawal_id::text, 'COMPLETED');

  ELSIF p_action = 'REJECT' THEN
    UPDATE public.wallets
    SET balance = balance + v_withdrawal.amount,
        reserved_balance = GREATEST(0.00, reserved_balance - v_withdrawal.amount), updated_at = NOW()
    WHERE id = v_wallet.id;
    UPDATE public.withdrawals
    SET status = 'REJECTED',
        rejection_reason = COALESCE(p_rejection_reason, 'Motivo não especificado pela administração'),
        processed_at = NOW(), processed_by = v_admin_id
    WHERE id = p_withdrawal_id;
    INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
    VALUES (v_wallet.id, v_withdrawal.user_id, 'WITHDRAWAL_REFUND', v_withdrawal.amount,
            'Estorno de saque rejeitado: ' || COALESCE(p_rejection_reason, 'Dados incorretos'),
            p_withdrawal_id::text, 'COMPLETED');
  ELSE
    RAISE EXCEPTION 'Ação inválida. Use APPROVE, PAID ou REJECT.';
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_admin_id, 'ADMIN_WITHDRAWAL_' || p_action,
          'Saque #' || substr(p_withdrawal_id::text, 1, 8) || ' processado: ' || p_action,
          'Usuário: ' || v_withdrawal.user_id || ' | Valor: ' || v_withdrawal.amount || ' Kz');

  RETURN jsonb_build_object('success', true, 'action', p_action, 'withdrawal_id', p_withdrawal_id,
                            'status', (SELECT status FROM public.withdrawals WHERE id = p_withdrawal_id));
END;
$$;

REVOKE ALL ON FUNCTION public._protect_financial_history() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._protect_wallet_delete() FROM PUBLIC, anon, authenticated;

NOTIFY pgrst, 'reload schema';
