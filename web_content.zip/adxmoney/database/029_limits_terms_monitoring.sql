-- ====================================================================
-- 029 — Limites de saque · aceitação de termos · reconciliação · registo de erros
-- Executar DEPOIS de 028. Idempotente.
-- ====================================================================

-- --------------------------------------------------------------------
-- 1) Tetos de saque (0 = sem limite). Limitam o estrago se uma conta for comprometida.
-- --------------------------------------------------------------------
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = 'accept_terms' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_reconcile_wallets' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'log_client_error' AND pg_get_function_result(p.oid) <> 'void') OR
        (p.proname = 'request_withdrawal' AND pg_get_function_result(p.oid) <> 'jsonb')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

INSERT INTO public.economy_settings (key, value, label) VALUES
  ('withdrawal_max_per_request_aoa',      100000, 'Saque: máximo por pedido (Kz; 0 = sem limite)'),
  ('withdrawal_max_daily_per_user_aoa',   150000, 'Saque: máximo por utilizador em 24h (Kz; 0 = sem limite)'),
  ('withdrawal_global_daily_cap_aoa',    2000000, 'Saque: máximo da plataforma em 24h (Kz; 0 = sem limite)')
ON CONFLICT (key) DO NOTHING;

-- Pedido de saque (substitui a função da 017; acrescenta só as verificações de tetos marcadas).
-- A carteira fica bloqueada (FOR UPDATE) durante a verificação: dois pedidos do mesmo utilizador
-- em simultâneo são processados em sequência. O teto global usa um bloqueio consultivo da transação,
-- por isso também é exato quando utilizadores diferentes pedem ao mesmo tempo.
CREATE OR REPLACE FUNCTION public.request_withdrawal(
  p_amount NUMERIC,
  p_method TEXT,
  p_payment_details JSONB
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_wal RECORD;
  v_wid UUID;
  v_active BOOLEAN;
  v_susp TIMESTAMPTZ;
  v_amount NUMERIC;
  v_max NUMERIC;
  v_cap NUMERIC;
  v_sum NUMERIC;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;

  SELECT is_active, suspended_until INTO v_active, v_susp FROM public.profiles WHERE id = v_uid;
  IF v_active IS DISTINCT FROM TRUE THEN RAISE EXCEPTION 'Conta inactiva.'; END IF;
  IF v_susp IS NOT NULL AND v_susp > NOW() THEN RAISE EXCEPTION 'Conta suspensa temporariamente.'; END IF;

  v_amount := ROUND(COALESCE(p_amount, 0)::numeric, 2);
  IF v_amount <= 0 THEN RAISE EXCEPTION 'O valor do saque deve ser maior que zero.'; END IF;
  IF v_amount < 1000 THEN RAISE EXCEPTION 'Valor mínimo de saque: 1000 Kz.'; END IF;
  -- Tetos de risco (0 = sem limite). Editáveis em Definições → Economia.
  v_max := public.econ('withdrawal_max_per_request_aoa', 100000);
  IF v_max > 0 AND v_amount > v_max THEN
    RAISE EXCEPTION 'Valor máximo por saque: % Kz. Divida em pedidos menores ou contacte o suporte.', v_max;
  END IF;
  IF p_method IS NULL OR length(trim(p_method)) = 0 THEN
    RAISE EXCEPTION 'Informe o método de pagamento para o saque.';
  END IF;
  IF p_payment_details IS NOT NULL AND length(p_payment_details::text) > 4000 THEN
    RAISE EXCEPTION 'Dados de pagamento demasiado longos.';
  END IF;

  SELECT * INTO v_wal FROM public.wallets WHERE user_id = v_uid FOR UPDATE;
  IF v_wal.id IS NULL THEN RAISE EXCEPTION 'Carteira não encontrada.'; END IF;
  IF v_wal.balance < v_amount THEN
    RAISE EXCEPTION 'Saldo disponível insuficiente para realizar este saque.';
  END IF;

  v_cap := public.econ('withdrawal_max_daily_per_user_aoa', 150000);
  IF v_cap > 0 THEN
    SELECT COALESCE(sum(amount), 0) INTO v_sum FROM public.withdrawals
    WHERE user_id = v_uid AND status <> 'REJECTED' AND requested_at > NOW() - INTERVAL '24 hours';
    IF v_sum + v_amount > v_cap THEN
      RAISE EXCEPTION 'Limite diário de saques atingido: % Kz nas últimas 24h (máximo % Kz).', v_sum, v_cap;
    END IF;
  END IF;

  v_cap := public.econ('withdrawal_global_daily_cap_aoa', 2000000);
  IF v_cap > 0 THEN
    -- bloqueio consultivo: pedidos de saque de utilizadores diferentes passam um de cada vez por aqui,
    -- por isso a soma global já inclui o pedido anterior (teto exato, sem ultrapassagem em simultâneo)
    PERFORM pg_advisory_xact_lock(727001);
    SELECT COALESCE(sum(amount), 0) INTO v_sum FROM public.withdrawals
    WHERE status <> 'REJECTED' AND requested_at > NOW() - INTERVAL '24 hours';
    IF v_sum + v_amount > v_cap THEN
      RAISE EXCEPTION 'O limite diário de saques da plataforma foi atingido. Tente novamente amanhã.';
    END IF;
  END IF;

  UPDATE public.wallets
  SET balance = balance - v_amount, reserved_balance = reserved_balance + v_amount, updated_at = NOW()
  WHERE id = v_wal.id;

  INSERT INTO public.withdrawals (user_id, amount, method, payment_details, status, requested_at)
  VALUES (v_uid, v_amount, trim(p_method), COALESCE(p_payment_details, '{}'::jsonb), 'PENDING', NOW())
  RETURNING id INTO v_wid;

  INSERT INTO public.wallet_transactions (wallet_id, user_id, type, amount, description, reference_id, status)
  VALUES (v_wal.id, v_uid, 'WITHDRAWAL_LOCK', -v_amount,
          'Reserva de saldo para solicitacao de saque #' || substr(v_wid::text, 1, 8), v_wid::text, 'COMPLETED');

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_uid, 'WITHDRAWAL_REQUESTED', 'Solicitacao de saque criada',
          'Valor: ' || v_amount || ' Kz via ' || trim(p_method));

  RETURN jsonb_build_object('success', true, 'withdrawal_id', v_wid, 'amount', v_amount, 'status', 'PENDING');
END;
$$;

-- --------------------------------------------------------------------
-- 2) Aceitação de Termos e Política de Privacidade (prova do consentimento)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.terms_acceptances (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  terms_version TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'gate',      -- register | gate
  accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_terms_acceptance UNIQUE (user_id, terms_version)
);
ALTER TABLE public.terms_acceptances ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.terms_acceptances TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.terms_acceptances TO service_role;
DROP POLICY IF EXISTS "terms_select_own" ON public.terms_acceptances;
CREATE POLICY "terms_select_own" ON public.terms_acceptances
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_admin());

CREATE OR REPLACE FUNCTION public.accept_terms(p_version TEXT)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF p_version IS NULL OR length(trim(p_version)) = 0 OR length(p_version) > 40 THEN
    RAISE EXCEPTION 'Versão inválida.';
  END IF;
  INSERT INTO public.terms_acceptances (user_id, terms_version, source)
  VALUES (v_uid, trim(p_version), 'gate')
  ON CONFLICT (user_id, terms_version) DO NOTHING;
  RETURN jsonb_build_object('success', true);
END;
$$;

-- --------------------------------------------------------------------
-- 3) Reconciliação feita pelo painel (substitui correr o RECONCILE.sql à mão todos os dias)
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_reconcile_wallets()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_checked INTEGER;
  v_mismatch JSONB;
  v_mismatch_n INTEGER;
  v_reserved JSONB;
  v_reserved_n INTEGER;
  v_negative INTEGER;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;

  SELECT count(*) INTO v_checked FROM public.wallets;

  -- saldo disponível tem de ser igual à soma dos movimentos
  WITH d AS (
    SELECT w.user_id, w.balance,
           COALESCE((SELECT sum(t.amount) FROM public.wallet_transactions t WHERE t.wallet_id = w.id), 0) AS ledger
    FROM public.wallets w
  )
  SELECT count(*), COALESCE(jsonb_agg(jsonb_build_object('user_id', user_id, 'balance', balance, 'ledger', ledger)) FILTER (WHERE rn <= 20), '[]'::jsonb)
  INTO v_mismatch_n, v_mismatch
  FROM (SELECT d.*, row_number() OVER () AS rn FROM d WHERE d.balance <> d.ledger) x;

  -- reserva tem de ser igual aos saques ainda por liquidar (PENDING + APPROVED)
  WITH r AS (
    SELECT w.user_id, w.reserved_balance,
           COALESCE((SELECT sum(wd.amount) FROM public.withdrawals wd
                     WHERE wd.user_id = w.user_id AND wd.status IN ('PENDING', 'APPROVED')), 0) AS open_amount
    FROM public.wallets w
  )
  SELECT count(*), COALESCE(jsonb_agg(jsonb_build_object('user_id', user_id, 'reserved', reserved_balance, 'open_withdrawals', open_amount)) FILTER (WHERE rn <= 20), '[]'::jsonb)
  INTO v_reserved_n, v_reserved
  FROM (SELECT r.*, row_number() OVER () AS rn FROM r WHERE r.reserved_balance <> r.open_amount) y;

  SELECT count(*) INTO v_negative FROM public.wallets WHERE balance < 0 OR reserved_balance < 0;

  RETURN jsonb_build_object(
    'checked_at', NOW(),
    'wallets_checked', v_checked,
    'balance_mismatches', v_mismatch_n,
    'balance_mismatch_samples', v_mismatch,
    'reserved_mismatches', v_reserved_n,
    'reserved_mismatch_samples', v_reserved,
    'negative_wallets', v_negative,
    'pending_withdrawals', (SELECT count(*) FROM public.withdrawals WHERE status IN ('PENDING', 'APPROVED')),
    'commission_failures', (SELECT count(*) FROM public.affiliate_commission_failures WHERE resolved_at IS NULL),
    'healthy', (v_mismatch_n = 0 AND v_reserved_n = 0 AND v_negative = 0)
  );
END;
$$;

-- --------------------------------------------------------------------
-- 4) Registo de erros do aplicativo (monitorização simples, sem serviço externo)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.app_errors (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  message TEXT NOT NULL,
  stack TEXT,
  url TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_app_errors_created ON public.app_errors (created_at DESC);
ALTER TABLE public.app_errors ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON TABLE public.app_errors TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.app_errors TO service_role;
DROP POLICY IF EXISTS "app_errors_admin" ON public.app_errors;
CREATE POLICY "app_errors_admin" ON public.app_errors
  FOR SELECT TO authenticated USING (public.is_admin());

CREATE OR REPLACE FUNCTION public.log_client_error(
  p_message TEXT, p_stack TEXT DEFAULT NULL, p_url TEXT DEFAULT NULL, p_user_agent TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
BEGIN
  IF v_uid IS NULL OR p_message IS NULL OR length(trim(p_message)) = 0 THEN RETURN; END IF;
  -- limites: 20 por utilizador/hora e 300 por hora no total (evita encher a tabela)
  IF (SELECT count(*) FROM public.app_errors WHERE user_id = v_uid AND created_at > NOW() - INTERVAL '1 hour') >= 20 THEN RETURN; END IF;
  IF (SELECT count(*) FROM public.app_errors WHERE created_at > NOW() - INTERVAL '1 hour') >= 300 THEN RETURN; END IF;

  INSERT INTO public.app_errors (user_id, message, stack, url, user_agent)
  VALUES (v_uid, left(p_message, 500), left(p_stack, 2000), left(p_url, 300), left(p_user_agent, 300));

  IF random() < 0.02 THEN
    DELETE FROM public.app_errors WHERE created_at < NOW() - INTERVAL '30 days';
  END IF;
END;
$$;

-- --------------------------------------------------------------------
-- 5) Permissões
-- --------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.accept_terms(TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.accept_terms(TEXT) TO authenticated;
REVOKE ALL ON FUNCTION public.admin_reconcile_wallets() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_reconcile_wallets() TO authenticated;
REVOKE ALL ON FUNCTION public.log_client_error(TEXT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_client_error(TEXT, TEXT, TEXT, TEXT) TO authenticated;
-- request_withdrawal mantém as permissões da 017 (CREATE OR REPLACE não as altera)

NOTIFY pgrst, 'reload schema';
