-- RECONCILE.sql — SÓ LEITURA (nenhuma escrita). Seguro para correr em staging ou produção.
-- Devolve UMA tabela: a coluna "linhas" deve ser 0 em todas as verificações.
-- Linhas > 0 = diferenças a investigar (não corrigir dados às cegas). Detalhe de cada uma: consultas no fim.
SELECT '1 saldo da carteira ≠ soma do ledger (COMPLETED)' AS verificacao, count(*) AS linhas FROM (
  SELECT w.id
  FROM public.wallets w
  LEFT JOIN public.wallet_transactions t ON t.wallet_id = w.id AND t.status = 'COMPLETED'
  GROUP BY w.id, w.balance
  HAVING w.balance <> COALESCE(SUM(t.amount), 0)
) a
UNION ALL
SELECT '2 reserved_balance ≠ saques em curso (PENDING/APPROVED)', count(*) FROM (
  SELECT w.id
  FROM public.wallets w
  LEFT JOIN public.withdrawals x ON x.user_id = w.user_id AND x.status IN ('PENDING', 'APPROVED')
  GROUP BY w.id, w.reserved_balance
  HAVING w.reserved_balance <> COALESCE(SUM(x.amount), 0)
) b
UNION ALL
SELECT '3 saldos negativos', count(*) FROM public.wallets WHERE balance < 0 OR reserved_balance < 0
UNION ALL
SELECT '4 operações creditadas mais de uma vez', count(*) FROM (
  SELECT 1
  FROM public.wallet_transactions
  WHERE reference_id IS NOT NULL
    AND type IN ('CAMPAIGN_REFUND', 'WITHDRAWAL_REFUND', 'WITHDRAWAL_PAID', 'DEPOSIT', 'CAMPAIGN_REWARD')
  GROUP BY type, reference_id, user_id
  HAVING count(*) > 1
) c;

-- ---------------- DETALHE (correr UMA de cada vez, só se a verificação respectiva der > 0) ----------------
-- 1) SELECT w.user_id, w.balance, COALESCE(SUM(t.amount),0) AS ledger_sum
--    FROM public.wallets w LEFT JOIN public.wallet_transactions t ON t.wallet_id = w.id AND t.status = 'COMPLETED'
--    GROUP BY w.user_id, w.balance HAVING w.balance <> COALESCE(SUM(t.amount),0) LIMIT 50;
-- 2) SELECT w.user_id, w.reserved_balance, COALESCE(SUM(x.amount),0) AS em_curso
--    FROM public.wallets w LEFT JOIN public.withdrawals x ON x.user_id = w.user_id AND x.status IN ('PENDING','APPROVED')
--    GROUP BY w.user_id, w.reserved_balance HAVING w.reserved_balance <> COALESCE(SUM(x.amount),0) LIMIT 50;
-- 3) SELECT * FROM public.wallets WHERE balance < 0 OR reserved_balance < 0;
-- 4) SELECT type, reference_id, user_id, count(*) FROM public.wallet_transactions
--    WHERE reference_id IS NOT NULL AND type IN ('CAMPAIGN_REFUND','WITHDRAWAL_REFUND','WITHDRAWAL_PAID','DEPOSIT','CAMPAIGN_REWARD')
--    GROUP BY 1,2,3 HAVING count(*) > 1;
--
-- Nota: dados anteriores a estas migrações podem ter diferenças históricas na verificação 1 (ex.: ajustes manuais
-- sem linha no ledger). Compare antes/depois dos testes de staging: o que importa é não surgirem diferenças NOVAS.
