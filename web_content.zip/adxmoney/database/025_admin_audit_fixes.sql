-- ====================================================================
-- 025 — Correções da auditoria do painel admin
-- Executar DEPOIS de 021. Idempotente.
-- ====================================================================

-- 1) "Aprovar & Lançar" passa a ser atómico no servidor.
--    Antes: o painel inseria em community_tasks e depois fazia UPDATE do pedido sem verificar erro
--    (podia lançar a mesma tarefa duas vezes e 'Visualizações' ficava como 'follow').
-- Compatibilidade com instalações antigas: se já existir uma função com o mesmo nome mas OUTRO tipo de
-- retorno, o CREATE OR REPLACE falharia (erro 42P13). Remove-a primeiro, SÓ nesse caso (se o tipo coincide, não toca).
DO $guard$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND (
        (p.proname = 'admin_launch_engagement_task' AND pg_get_function_result(p.oid) <> 'jsonb') OR
        (p.proname = 'admin_resolve_task_report' AND pg_get_function_result(p.oid) <> 'jsonb')
      )
  LOOP
    EXECUTE 'DROP FUNCTION ' || r.sig::text;
  END LOOP;
END
$guard$;

DROP FUNCTION IF EXISTS public.admin_launch_engagement_task(UUID);
CREATE OR REPLACE FUNCTION public.admin_launch_engagement_task(p_order_id UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_admin UUID := auth.uid();
  v_order RECORD;
  v_plat TEXT;
  v_type TEXT;
  v_reward NUMERIC(10, 2);
  v_task_id UUID;
BEGIN
  IF v_admin IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;

  SELECT * INTO v_order FROM public.engagement_orders WHERE id = p_order_id FOR UPDATE;
  IF v_order.id IS NULL THEN RAISE EXCEPTION 'Pedido não encontrado.'; END IF;
  IF v_order.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Este pedido já foi processado (%).', v_order.status;
  END IF;

  v_plat := lower(v_order.platform);
  IF v_plat NOT IN ('tiktok', 'instagram', 'youtube') THEN v_plat := 'other'; END IF;

  v_type := CASE v_order.service_type
              WHEN 'Gostos' THEN 'like'
              WHEN 'Comentários' THEN 'comment'
              WHEN 'Visualizações' THEN 'view'
              ELSE 'follow' END;

  SELECT reward_per_task INTO v_reward FROM public.community_settings WHERE platform = v_plat;
  v_reward := COALESCE(v_reward, 5.00);

  INSERT INTO public.community_tasks (
    creator_user_id, platform, task_type, profile_url, description,
    max_completions, current_completions, is_active, reward_amount
  ) VALUES (
    v_order.user_id, v_plat, v_type, v_order.target_link,
    v_order.service_type || ' em ' || v_order.platform || ' (' || v_order.target_link || ')',
    COALESCE(v_order.quantity, 100), 0, true, v_reward
  ) RETURNING id INTO v_task_id;

  UPDATE public.engagement_orders
  SET status = 'APPROVED', processed_at = NOW(), processed_by = v_admin, updated_at = NOW()
  WHERE id = v_order.id;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (v_order.user_id, 'ENGAGEMENT_ORDER_APPROVED', 'Pedido de engajamento aprovado',
          v_order.service_type || ' x ' || v_order.quantity || ' lançado na Comunidade');

  RETURN jsonb_build_object('success', true, 'task_id', v_task_id);
END;
$$;
REVOKE ALL ON FUNCTION public.admin_launch_engagement_task(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_launch_engagement_task(UUID) TO authenticated, service_role;

-- 2) Denúncias: o painel só mostrava a lista (sem forma de resolver). RPC para marcar e, se preciso, desativar a tarefa.
DROP FUNCTION IF EXISTS public.admin_resolve_task_report(UUID, TEXT, BOOLEAN);
CREATE OR REPLACE FUNCTION public.admin_resolve_task_report(
  p_report_id UUID,
  p_status TEXT,
  p_deactivate_task BOOLEAN DEFAULT FALSE
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_rep RECORD;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin() THEN
    RAISE EXCEPTION 'Apenas administradores.';
  END IF;
  IF p_status NOT IN ('REVIEWED', 'DISMISSED') THEN
    RAISE EXCEPTION 'Status inválido.';
  END IF;

  SELECT * INTO v_rep FROM public.task_reports WHERE id = p_report_id FOR UPDATE;
  IF v_rep.id IS NULL THEN RAISE EXCEPTION 'Denúncia não encontrada.'; END IF;

  UPDATE public.task_reports SET status = p_status WHERE id = v_rep.id;

  IF p_deactivate_task THEN
    UPDATE public.community_tasks SET is_active = false, disabled_by_admin = true, updated_at = NOW() WHERE id = v_rep.task_id;
  END IF;

  INSERT INTO public.activity_logs (user_id, action_type, title, details)
  VALUES (auth.uid(), 'TASK_REPORT_' || p_status, 'Denúncia de tarefa processada',
          CASE WHEN p_deactivate_task THEN 'Tarefa desativada: ' ELSE 'Tarefa mantida: ' END || v_rep.task_id::text);

  RETURN jsonb_build_object('success', true);
END;
$$;
REVOKE ALL ON FUNCTION public.admin_resolve_task_report(UUID, TEXT, BOOLEAN) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_resolve_task_report(UUID, TEXT, BOOLEAN) TO authenticated, service_role;

-- 3) Relações com public.profiles exigidas pelo painel (select "profiles:user_id(...)" e "wallets(...)").
--    O PostgREST só resolve estes joins se existir uma FK directa para public.profiles; uma FK para
--    auth.users não chega. Só cria se ainda NÃO existir nenhuma (duas FKs causariam erro PGRST201).
--    NOT VALID: não falha por linhas antigas órfãs; passa a valer para novas linhas.
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['wallets','campaign_assignments','withdrawals','affiliate_profiles',
                           'campaign_requests','engagement_orders']
  LOOP
    IF to_regclass('public.' || t) IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM pg_constraint
      WHERE contype = 'f'
        AND conrelid = ('public.' || t)::regclass
        AND confrelid = 'public.profiles'::regclass
    ) THEN
      EXECUTE format(
        'ALTER TABLE public.%I ADD CONSTRAINT %I FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE NOT VALID',
        t, 'fk_' || t || '_profiles');
    END IF;
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';
