-- ====================================================================
-- 012 — Corrigir campaign_requests (status EN + RPC atómica)
-- Executar no SQL Editor do Supabase
-- ====================================================================

-- 1) Normalizar status legados PT → EN
UPDATE public.campaign_requests
SET status = 'PENDING'
WHERE status IN ('pendente', 'Pendente', 'pending');

UPDATE public.campaign_requests
SET status = 'APPROVED'
WHERE status IN ('aprovada', 'Aprovada', 'approved');

UPDATE public.campaign_requests
SET status = 'REJECTED'
WHERE status IN ('rejeitada', 'Rejeitada', 'rejected');

-- 2) Garantir colunas usadas pelo frontend (idempotente)
ALTER TABLE public.campaign_requests
  ADD COLUMN IF NOT EXISTS additional_information TEXT;

-- 3) RPC atómica: valida saldo → cria pedido PENDING → debita
--    Se qualquer passo falhar, a transacção reverte (sem cobrança órfã).
CREATE OR REPLACE FUNCTION public.submit_paid_campaign_request(
  p_title TEXT,
  p_platform TEXT,
  p_target_url TEXT,
  p_action_type TEXT DEFAULT 'follow',
  p_objective TEXT DEFAULT NULL,
  p_description TEXT DEFAULT NULL,
  p_target_audience TEXT DEFAULT 'Geral',
  p_requester_phone TEXT DEFAULT NULL,
  p_cost_kz NUMERIC DEFAULT 9500,
  p_additional_information TEXT DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_wallet RECORD;
  v_req_id UUID;
  v_cost NUMERIC;
  v_platform TEXT;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Não autenticado';
  END IF;

  IF p_title IS NULL OR length(trim(p_title)) < 3 THEN
    RAISE EXCEPTION 'Título inválido.';
  END IF;

  IF p_target_url IS NULL OR length(trim(p_target_url)) < 5 THEN
    RAISE EXCEPTION 'URL alvo inválida.';
  END IF;

  v_cost := ROUND(COALESCE(p_cost_kz, 9500)::numeric, 2);
  IF v_cost <= 0 THEN
    RAISE EXCEPTION 'Custo inválido.';
  END IF;

  v_platform := COALESCE(NULLIF(trim(p_platform), ''), 'Instagram');
  -- Normalizar para valores comuns
  IF lower(v_platform) LIKE '%tiktok%' THEN v_platform := 'TikTok';
  ELSIF lower(v_platform) LIKE '%insta%' THEN v_platform := 'Instagram';
  ELSIF lower(v_platform) LIKE '%you%' THEN v_platform := 'YouTube';
  END IF;

  SELECT * INTO v_wallet
  FROM public.wallets
  WHERE user_id = v_uid
  FOR UPDATE;

  IF v_wallet.id IS NULL THEN
    INSERT INTO public.wallets (user_id, balance, reserved_balance)
    VALUES (v_uid, 0, 0)
    ON CONFLICT (user_id) DO NOTHING;

    SELECT * INTO v_wallet
    FROM public.wallets
    WHERE user_id = v_uid
    FOR UPDATE;
  END IF;

  IF v_wallet.balance < v_cost THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Saldo insuficiente.',
      'balance', v_wallet.balance,
      'required', v_cost
    );
  END IF;

  INSERT INTO public.campaign_requests (
    user_id,
    title,
    platform,
    target_url,
    action_type,
    objective,
    description,
    target_audience,
    requester_phone,
    cost_usd,
    currency,
    amount_paid,
    status,
    additional_information
  ) VALUES (
    v_uid,
    trim(p_title),
    v_platform,
    trim(p_target_url),
    COALESCE(NULLIF(trim(p_action_type), ''), 'follow'),
    NULLIF(trim(COALESCE(p_objective, '')), ''),
    NULLIF(trim(COALESCE(p_description, '')), ''),
    COALESCE(NULLIF(trim(p_target_audience), ''), 'Geral'),
    NULLIF(trim(COALESCE(p_requester_phone, '')), ''),
    ROUND(v_cost / 950.0, 2),
    'AOA',
    v_cost,
    'PENDING',
    NULLIF(trim(COALESCE(p_additional_information, '')), '')
  )
  RETURNING id INTO v_req_id;

  UPDATE public.wallets
  SET balance = balance - v_cost,
      updated_at = NOW()
  WHERE id = v_wallet.id;

  INSERT INTO public.wallet_transactions (
    wallet_id, user_id, type, amount, description, reference_id, status
  ) VALUES (
    v_wallet.id,
    v_uid,
    'CAMPAIGN_TOKEN',
    -v_cost,
    'Taxa de solicitação de campanha: ' || trim(p_title),
    v_req_id::text,
    'COMPLETED'
  );

  RETURN jsonb_build_object(
    'success', true,
    'request_id', v_req_id,
    'charged', v_cost,
    'status', 'PENDING'
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_paid_campaign_request(
  TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, NUMERIC, TEXT
) TO authenticated;

COMMENT ON FUNCTION public.submit_paid_campaign_request IS
  'Cria campaign_request PENDING e debita carteira na mesma transacção';
