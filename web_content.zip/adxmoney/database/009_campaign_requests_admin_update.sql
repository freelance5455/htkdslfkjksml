-- ====================================================================
-- 009 — campaign_requests: UPDATE para admin + grants
-- Resolver: erro de permissão ao aprovar/rejeitar pedidos de campanha
-- Executar uma vez no SQL Editor do Supabase
-- ====================================================================

-- 1) Grant UPDATE ao role authenticated (a policy restringe a admin)
GRANT SELECT, INSERT, UPDATE ON TABLE public.campaign_requests TO authenticated;

-- 2) Policy de UPDATE (só admin)
DROP POLICY IF EXISTS "camp_req_update" ON public.campaign_requests;
CREATE POLICY "camp_req_update" ON public.campaign_requests
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 3) Policy de DELETE (só admin) — útil para limpeza operacional
DROP POLICY IF EXISTS "camp_req_delete" ON public.campaign_requests;
CREATE POLICY "camp_req_delete" ON public.campaign_requests
  FOR DELETE TO authenticated
  USING (public.is_admin());

COMMENT ON POLICY "camp_req_update" ON public.campaign_requests IS
  'Admin pode atualizar status e dados de pedidos de campanha';
