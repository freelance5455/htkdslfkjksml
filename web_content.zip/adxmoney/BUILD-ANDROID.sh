#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d node_modules/vite ] || npm install --legacy-peer-deps
node scripts/build-android.mjs
