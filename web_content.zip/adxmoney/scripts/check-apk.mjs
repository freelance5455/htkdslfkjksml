/**
 * Inspeciona um APK já gerado e diz se ele abre o site da Vercel ou https://localhost.
 * Uso:  node scripts/check-apk.mjs [caminho\para\app-debug.apk]
 */
import { existsSync, readFileSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { inflateRawSync } from "node:zlib";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const candidates = [
  process.argv[2],
  join(root, "android/app/build/outputs/apk/debug/app-debug.apk"),
  join(root, "android/app/build/outputs/apk/release/app-release.apk"),
].filter(Boolean);
const apk = candidates.find((p) => existsSync(p));
if (!apk) {
  console.error("❌ APK não encontrado. Passe o caminho:  node scripts/check-apk.mjs C:\\caminho\\app-debug.apk");
  process.exit(1);
}

const buf = readFileSync(apk);
let eocd = -1;
for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) {
  if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
}
if (eocd < 0) { console.error("❌ Ficheiro não é um ZIP/APK válido."); process.exit(1); }
const total = buf.readUInt16LE(eocd + 10);
let p = buf.readUInt32LE(eocd + 16);
const entries = new Map();
for (let n = 0; n < total; n++) {
  if (buf.readUInt32LE(p) !== 0x02014b50) break;
  const method = buf.readUInt16LE(p + 10);
  const csize = buf.readUInt32LE(p + 20);
  const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
  const lho = buf.readUInt32LE(p + 42);
  entries.set(buf.toString("utf8", p + 46, p + 46 + nlen), { method, csize, lho });
  p += 46 + nlen + elen + clen;
}
const read = (name) => {
  const e = entries.get(name);
  if (!e) return null;
  const nlen = buf.readUInt16LE(e.lho + 26), elen = buf.readUInt16LE(e.lho + 28);
  const start = e.lho + 30 + nlen + elen;
  const raw = buf.subarray(start, start + e.csize);
  return (e.method === 8 ? inflateRawSync(raw) : raw).toString("utf8");
};

console.log("APK:", apk);
console.log("Tamanho:", (buf.length / 1048576).toFixed(1), "MB · gerado em:", statSync(apk).mtime.toLocaleString());
const cfgText = read("assets/capacitor.config.json");
let ok = true;
if (!cfgText) {
  console.log("❌ assets/capacitor.config.json NÃO existe no APK → a app cai em https://localhost (sem site dentro).");
  ok = false;
} else {
  const cfg = JSON.parse(cfgText);
  const url = cfg.server && cfg.server.url;
  console.log("server.url dentro do APK:", url || "(NÃO DEFINIDO)");
  console.log("errorPath:", (cfg.server && cfg.server.errorPath) || "(nenhum)");
  if (!url) { console.log("❌ Sem server.url → o APK abre https://localhost. Recompile depois de BUILD-ANDROID.bat."); ok = false; }
}
console.log(entries.has("assets/public/index.html") ? "✔ assets/public/index.html presente" : "• assets/public/index.html ausente");
console.log(entries.has("assets/public/offline.html") ? "✔ assets/public/offline.html presente" : "❌ assets/public/offline.html ausente");
const plugins = read("assets/capacitor.plugins.json");
if (plugins) console.log("Plugins no APK:", JSON.parse(plugins).map((x) => x.pkg).join(", "));

const src = join(root, "android/app/src/main/assets/capacitor.config.json");
if (existsSync(src)) {
  const newer = statSync(src).mtimeMs > statSync(apk).mtimeMs;
  console.log("Último sync desta pasta:", statSync(src).mtime.toLocaleString());
  if (newer) { console.log("⚠ O APK é MAIS ANTIGO que o último sync: recompile e reinstale."); ok = false; }
} else {
  console.log("⚠ Esta pasta não tem android/app/src/main/assets (sync nunca correu AQUI). O APK veio de outra pasta?");
  ok = false;
}
console.log(ok ? "\n✅ Este APK está correto." : "\n❌ Este APK NÃO é o esperado. Veja as linhas acima.");
