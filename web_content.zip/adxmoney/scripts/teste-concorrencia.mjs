#!/usr/bin/env node
// ====================================================================
// Teste de CONCORRÊNCIA contra um projeto Supabase de TESTE (staging).
// Dispara pedidos em simultâneo e confirma que o dinheiro só mexe uma vez:
//   • aprovar o mesmo depósito / a mesma assinatura em paralelo
//   • levantar várias vezes ao mesmo tempo com saldo para uma só vez (duplo gasto)
//   • pagar e rejeitar o mesmo saque em paralelo
//   • registar o mesmo resultado de campanha em paralelo (mesma chave e chaves diferentes)
//   • registar várias contas com o mesmo e-mail / telefone em paralelo (Edge Function)
//
// USO (Node 18+; no Termux: `pkg install nodejs`):
//   export SUPABASE_URL="https://xxxx.supabase.co"
//   export SUPABASE_ANON_KEY="..."            # chave publicável/anon
//   export SUPABASE_SERVICE_KEY="..."         # service_role/secret — SÓ de um projeto de TESTE
//   export CONFIRMO_STAGING=sim
//   node scripts/teste-concorrencia.mjs
//
// ⚠ NUNCA corra contra produção: cria utilizadores (@concorrencia.invalid) e movimentos reais.
//   Como o histórico financeiro é imutável (028), essas contas de teste não se apagam facilmente;
//   por isso use um projeto de teste.
// ====================================================================

const URL_ = (process.env.SUPABASE_URL || "").replace(/\/$/, "");
const ANON = process.env.SUPABASE_ANON_KEY || "";
const SERVICE = process.env.SUPABASE_SERVICE_KEY || "";

if (!URL_ || !ANON || !SERVICE) {
  console.error("Faltam variáveis: SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_KEY.");
  process.exit(2);
}
if (process.env.CONFIRMO_STAGING !== "sim") {
  console.error(`Este teste cria dados reais em ${URL_}.\nSe for um projeto de TESTE, repita com:  export CONFIRMO_STAGING=sim`);
  process.exit(2);
}

const PAR = 12;                         // pedidos em paralelo por cenário
const RUN = Date.now().toString(36);    // identifica esta execução
const PASS = "Teste#" + RUN + "Aa1";
let failures = 0;
const lines = [];

function check(name, ok, info = "") {
  if (!ok) failures++;
  lines.push(`${ok ? "✅" : "❌"} ${name}${!ok && info ? " — " + info : ""}`);
  console.log(lines[lines.length - 1]);
}

async function http(method, path, { token, key = ANON, body, headers = {} } = {}) {
  const res = await fetch(URL_ + path, {
    method,
    headers: {
      apikey: key,
      Authorization: `Bearer ${token || key}`,
      "Content-Type": "application/json",
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data = null;
  const text = await res.text();
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { ok: res.ok, status: res.status, data };
}

const svc = (method, path, body, headers) => http(method, path, { key: SERVICE, body, headers });
const rpc = (token, name, args) => http("POST", `/rest/v1/rpc/${name}`, { token, body: args });

async function createUser(label, meta = {}) {
  const email = `${label}.${RUN}@concorrencia.invalid`;
  const r = await svc("POST", "/auth/v1/admin/users", {
    email, password: PASS, email_confirm: true, user_metadata: { name: `Teste ${label}`, ...meta },
  });
  if (!r.ok) throw new Error(`createUser ${label}: ${JSON.stringify(r.data)}`);
  const s = await http("POST", "/auth/v1/token?grant_type=password", { body: { email, password: PASS } });
  if (!s.ok) throw new Error(`signIn ${label}: ${JSON.stringify(s.data)}`);
  return { id: r.data.id, email, token: s.data.access_token };
}

async function setProfile(id, patch) {
  const r = await svc("PATCH", `/rest/v1/profiles?id=eq.${id}`, patch, { Prefer: "return=minimal" });
  if (!r.ok) throw new Error(`setProfile: ${JSON.stringify(r.data)}`);
}
async function wallet(id) {
  const r = await svc("GET", `/rest/v1/wallets?user_id=eq.${id}&select=id,balance,reserved_balance`);
  return r.data?.[0];
}
async function ledgerSum(walletId) {
  const r = await svc("GET", `/rest/v1/wallet_transactions?wallet_id=eq.${walletId}&select=amount`);
  return (r.data || []).reduce((s, x) => s + Number(x.amount), 0);
}
async function reconcile(label, id) {
  const w = await wallet(id);
  const sum = await ledgerSum(w.id);
  check(`${label}: saldo = soma dos movimentos`, Math.abs(Number(w.balance) - sum) < 0.005, `saldo=${w.balance} ledger=${sum}`);
}
const successes = (rs) => rs.filter((r) => r.ok && !r.data?.error);

async function main() {
  console.log(`Projeto: ${URL_}\nExecução: ${RUN}\n`);

  const admin = await createUser("admin");
  await setProfile(admin.id, { role: "admin" });
  const adm = (name, args) => rpc(admin.token, name, args);

  // economia no estado esperado
  await svc("PATCH", "/rest/v1/economy_settings?key=eq.withdrawal_require_approval", { value: 1 }, { Prefer: "return=minimal" });

  // ---------------- 1) mesmo depósito aprovado em paralelo ----------------
  try {
    const u = await createUser("dep");
    const d = await rpc(u.token, "submit_wallet_deposit", {
      p_amount: 5000, p_currency: "AOA", p_method: "EXPRESS", p_proof_url: `deposits/${u.id}/p.png`,
    });
    const depId = d.data?.id;
    const rs = await Promise.all(Array.from({ length: PAR }, () =>
      adm("admin_process_wallet_deposit", { p_deposit_id: depId, p_status: "APPROVED", p_rejection_reason: null })));
    check(`Depósito: ${PAR} aprovações em paralelo → exatamente 1 sucesso`, successes(rs).length === 1, `sucessos=${successes(rs).length}`);
    const w = await wallet(u.id);
    check("Depósito: creditado uma única vez (5.000)", Number(w.balance) === 5000, `saldo=${w.balance}`);
    await reconcile("Depósito", u.id);

    // ---------------- 2) duplo gasto: levantar em paralelo ----------------
    const ws = await Promise.all(Array.from({ length: PAR }, () =>
      rpc(u.token, "request_withdrawal", { p_amount: 3000, p_method: "EXPRESS", p_payment_details: { conta: "1" } })));
    const okW = successes(ws);
    check(`Duplo gasto: ${PAR} saques de 3.000 com saldo de 5.000 → exatamente 1 aceite`, okW.length === 1, `aceites=${okW.length}`);
    const w2 = await wallet(u.id);
    check("Duplo gasto: saldo 2.000 e 3.000 reservados", Number(w2.balance) === 2000 && Number(w2.reserved_balance) === 3000,
      `saldo=${w2.balance} reservado=${w2.reserved_balance}`);

    // ---------------- 3) pagar e rejeitar o mesmo saque em paralelo ----------------
    const wid = okW[0]?.data?.withdrawal_id;
    await adm("admin_process_withdrawal", { p_withdrawal_id: wid, p_action: "APPROVE", p_rejection_reason: null });
    const acts = Array.from({ length: PAR }, (_, i) => i % 2 === 0 ? "PAID" : "REJECT");
    const fin = await Promise.all(acts.map((a) =>
      adm("admin_process_withdrawal", { p_withdrawal_id: wid, p_action: a, p_rejection_reason: "teste" })));
    check("Saque: pagar/rejeitar em paralelo → exatamente 1 finalização", successes(fin).length === 1, `sucessos=${successes(fin).length}`);
    const w3 = await wallet(u.id);
    const paid = Number(w3.balance) === 2000;      // pago: reserva liquidada
    const refunded = Number(w3.balance) === 5000;  // rejeitado: estorno
    check("Saque: estado final coerente (pago OU estornado, nunca os dois)",
      (paid || refunded) && Number(w3.reserved_balance) === 0, `saldo=${w3.balance} reservado=${w3.reserved_balance}`);
    await reconcile("Saque", u.id);
  } catch (e) { check("Cenários depósito/saque executaram", false, e.message); }

  // ---------------- 4) mesma assinatura aprovada em paralelo ----------------
  try {
    const u = await createUser("sub");
    const s = await rpc(u.token, "submit_subscription_payment", {
      p_amount: 1, p_currency: "AOA", p_method: "EXPRESS", p_proof_url: `${u.id}/c.png`,
    });
    const rs = await Promise.all(Array.from({ length: PAR }, () =>
      adm("admin_process_subscription_payment", { p_payment_id: s.data?.payment_id, p_status: "APPROVED", p_rejection_reason: null })));
    check(`Assinatura: ${PAR} aprovações em paralelo → exatamente 1 sucesso`, successes(rs).length === 1, `sucessos=${successes(rs).length}`);
    const p = (await svc("GET", `/rest/v1/profiles?id=eq.${u.id}&select=subscription_status,subscription_expires_at`)).data?.[0];
    const days = (new Date(p.subscription_expires_at) - Date.now()) / 86400000;
    check("Assinatura: 6 meses (não acumulou várias aprovações)", p.subscription_status === "active" && days > 175 && days < 190, `dias=${Math.round(days)}`);
  } catch (e) { check("Cenário assinatura executou", false, e.message); }

  // ---------------- 5) resultado de campanha em paralelo ----------------
  try {
    const p1 = await createUser("part1");
    const p2 = await createUser("part2");
    for (const u of [p1, p2]) {
      await setProfile(u.id, { subscription_status: "active", subscription_expires_at: new Date(Date.now() + 200 * 86400000).toISOString() });
    }
    const c = await svc("POST", "/rest/v1/campaigns", {
      title: "Concorrência " + RUN, description: "d", platform: "TikTok", target_url: "https://www.tiktok.com/@x",
      instructions: "i", reward_amount: 150, status: "ACTIVE", campaign_type: "collective",
    }, { Prefer: "return=representation" });
    const camp = c.data?.[0]?.id;
    for (const u of [p1, p2]) {
      await svc("POST", "/rest/v1/campaign_assignments", { campaign_id: camp, user_id: u.id, status: "COMPLETED", completed_at: new Date().toISOString() }, { Prefer: "return=minimal" });
    }

    // mesma chave, pedido repetido em paralelo
    const same = await Promise.all(Array.from({ length: PAR }, () =>
      adm("admin_register_campaign_result", { p_campaign_id: camp, p_revenue_aoa: 1000, p_note: "t", p_request_key: "k-" + RUN, p_confirm_similar: false })));
    const newOnes = successes(same).filter((r) => r.data?.duplicate === false);
    check(`Campanha: ${PAR} pedidos com a MESMA chave → 1 pagamento real`, newOnes.length === 1, `reais=${newOnes.length}`);
    check("Campanha: cada participante recebeu 250 uma só vez",
      Number((await wallet(p1.id)).balance) === 250 && Number((await wallet(p2.id)).balance) === 250,
      `p1=${(await wallet(p1.id)).balance}`);

    // chaves diferentes, mesmo valor (novo), em paralelo
    const diff = await Promise.all(Array.from({ length: PAR }, (_, i) =>
      adm("admin_register_campaign_result", { p_campaign_id: camp, p_revenue_aoa: 777, p_note: "t", p_request_key: `d${i}-${RUN}`, p_confirm_similar: false })));
    check(`Campanha: ${PAR} pedidos com chaves diferentes e o mesmo valor → só 1 passa sem confirmação`,
      successes(diff).filter((r) => r.data?.duplicate === false).length === 1,
      `sucessos=${successes(diff).length}`);
    await reconcile("Campanha p1", p1.id);
    await reconcile("Campanha p2", p2.id);
  } catch (e) { check("Cenário campanha executou", false, e.message); }

  // ---------------- 6) registo público em paralelo (Edge Function) ----------------
  try {
    const email = `reg.${RUN}@concorrencia.invalid`;
    const reg = (e, phone) => http("POST", "/functions/v1/public-register", {
      body: { name: "Teste Registo", email: e, phone, country: "Angola", accepted_terms: true, terms_version: process.env.TERMS_VERSION || "2026-11-v1" },
    });
    const sameEmail = await Promise.all(Array.from({ length: 8 }, (_, i) => reg(email, `9${RUN.slice(-5)}${i}1`)));
    check("Registo: 8 pedidos com o MESMO e-mail em paralelo → no máximo 1 conta",
      sameEmail.filter((r) => r.ok).length === 1, `contas=${sameEmail.filter((r) => r.ok).length} · estados=${sameEmail.map((r) => r.status).join(",")} (esperado: exatamente 1; 0 = pedidos recusados por validação/limites, não prova nada)`);
    const phone = `8${RUN.slice(-6)}77`;
    const samePhone = await Promise.all(Array.from({ length: 6 }, (_, i) => reg(`tel${i}.${RUN}@concorrencia.invalid`, phone)));
    check("Registo: 6 pedidos com o MESMO telefone em paralelo → no máximo 1 conta",
      samePhone.filter((r) => r.ok).length === 1, `contas=${samePhone.filter((r) => r.ok).length} · estados=${samePhone.map((r) => r.status).join(",")} (esperado: exatamente 1)`);
  } catch (e) { check("Cenário registo executou", false, e.message); }

  console.log(`\n===== ${lines.length - failures} de ${lines.length} passaram =====`);
  process.exit(failures ? 1 : 0);
}

main().catch((e) => { console.error("Erro inesperado:", e); process.exit(3); });
