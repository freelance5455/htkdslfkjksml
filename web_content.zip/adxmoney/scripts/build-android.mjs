/**
 * ADXmoney — build Android seguro (Windows/macOS/Linux).
 * 1) vite build  → dist/
 * 2) cap sync    → android/app/src/main/assets/public
 * Falha com mensagem clara se QUALQUER passo não produzir o resultado esperado.
 * Uso: npm run build:android   (ou BUILD-ANDROID.bat no Windows)
 */
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(root);

const fail = (msg) => {
  console.error("\n❌ " + msg + "\n");
  process.exit(1);
};
const step = (n, t) => console.log(`\n=== [${n}] ${t} ===`);

// 0) Pré-requisitos
const major = Number(process.versions.node.split(".")[0]);
console.log(`Node ${process.versions.node} · pasta: ${root}`);
if (major < 18) fail("Node demasiado antigo. Instale o Node.js 20 LTS ou 22 LTS (https://nodejs.org).");

const viteBin = join(root, "node_modules", "vite", "bin", "vite.js");
const capBin = join(root, "node_modules", "@capacitor", "cli", "bin", "capacitor");
if (!existsSync(viteBin) || !existsSync(capBin)) {
  fail("Dependências em falta (node_modules). Execute primeiro:  npm install --legacy-peer-deps");
}
for (const p of ["haptics", "share"]) {
  if (!existsSync(join(root, "node_modules", "@capacitor", p))) {
    fail(`Plugin @capacitor/${p} não instalado. Execute:  npm install --legacy-peer-deps`);
  }
}

const run = (script, args) => {
  const r = spawnSync(process.execPath, [script, ...args], { stdio: "inherit", cwd: root, env: process.env });
  if (r.error) fail("Erro ao executar: " + r.error.message);
  return r.status ?? 1;
};

// 1) Vite build
step(1, "Compilar frontend (vite build)");
if (run(viteBin, ["build"]) !== 0) fail("vite build falhou (veja o erro acima). Nada foi sincronizado com o Android.");

const dist = join(root, "dist");
if (!existsSync(join(dist, "index.html"))) fail("vite terminou mas dist/index.html não existe.");
const jsFiles = existsSync(join(dist, "assets")) ? readdirSync(join(dist, "assets")).filter((f) => f.endsWith(".js")) : [];
if (jsFiles.length === 0) fail("dist/assets não contém ficheiros .js — build incompleto.");
console.log(`✔ dist OK (${jsFiles.length} ficheiros JS)`);

// 2) Capacitor sync
step(2, "Sincronizar com Android (cap sync)");
if (run(capBin, ["sync", "android"]) !== 0) fail("cap sync falhou (veja o erro acima).");

// 3) Verificação final: o APK só funciona se estes ficheiros existirem
step(3, "Verificar assets no projeto Android");
const assets = join(root, "android", "app", "src", "main", "assets");
const mustHave = [join(assets, "public", "index.html"), join(assets, "capacitor.config.json"), join(assets, "capacitor.plugins.json")];
for (const f of mustHave) if (!existsSync(f)) fail("Ficheiro em falta após sync: " + f);

const cfg = JSON.parse(readFileSync(join(assets, "capacitor.config.json"), "utf-8"));
const url = cfg.server && cfg.server.url;
if (!url) fail("capacitor.config sem server.url. Defina https://adxmoneynative.vercel.app em capacitor.config.ts.");
if (!/^https:\/\//.test(url) || /localhost|10\.0\.2\.2|127\.0\.0\.1/.test(url)) {
  fail(`server.url inválido (${url}). Use o domínio https da Vercel.`);
}
if (!existsSync(join(assets, "public", "offline.html"))) fail("offline.html não foi copiado para os assets do APK (verifique public/offline.html).");
console.log("✔ app carrega de:", url);
const plugins = JSON.parse(readFileSync(join(assets, "capacitor.plugins.json"), "utf-8")).map((p) => p.pkg);
console.log("✔ fallback offline.html empacotado no APK");
console.log("✔ plugins nativos:", plugins.join(", "));

console.log("\n✅ Pronto. Agora no Android Studio: File > Sync Project with Gradle Files, depois Build > Build APK(s).\n");
