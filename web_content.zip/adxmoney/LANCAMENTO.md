# Manual de lançamento e operação — ADXmoney

> Este manual diz o que falta antes de abrir ao público e como operar no dia a dia.
> A segurança financeira está **implementada e escrita em código**, mas só fica **comprovada** depois de
> executar os testes (secção 2) no seu Supabase.

## 1. O que já está pronto no código
- Carteira, ledger, depósitos, saques (dois passos, estorno, tetos), assinatura de 6 meses com renovação e expiração
- Afiliados por percentagem (só quando o indicado paga), campanhas pagas por resultado, troca de seguidores
- Proteções: histórico financeiro imutável, comissões falhadas recuperáveis, resultados de campanha idempotentes,
  registo público com limites, funções internas de dinheiro fechadas aos utilizadores
- Termos e Privacidade (`/termos`, `/privacidade`) com aceitação obrigatória (registo e ecrã de aceitação); a versão oficial é validada pelo servidor
- CAPTCHA Cloudflare Turnstile no registo (ativa-se ao configurar as chaves) e limites de utilização da IA por utilizador
- Registo seguro: o `role` enviado pelo cliente é ignorado (corrigido na migração 030, depois de ter sido encontrado na base real)
- Reconciliação e registo de erros no painel (Definições), redefinição de palavra-passe pelo admin,
  alteração de palavra-passe pelo utilizador

## 2. Antes de abrir ao público (por ordem)
1. **Base de dados** — migrações 014→033 e `VERIFY.sql` sem nenhuma linha `false`
2. **Testes financeiros** — `TESTES_FINANCEIROS.sql` (não grava nada) com tudo ✅
3. **Testes de concorrência** — `scripts/teste-concorrencia.mjs`, **só num projeto de teste**; depois rode a chave `service_role`
4. **Edge Functions** publicadas: `public-register`, `admin-delete-user`, `admin-reset-password`
   (e `public-register` com *Enforce JWT* desligado)
5. **Build** da Vercel sem erros; idealmente `npm run typecheck` e `npm run lint`
6. **Jurídico** (secção 6) — advogado revê os textos; preencha os `[MARCADORES]` em `src/lib/legal.ts`
   (já preenchido com os dados do operador; falta NIF e e-mail de suporte) e mantenha `LEGAL_IS_DRAFT` coerente com o estado da revisão
7. **Planos e cópias de segurança** (secção 5)
8. **Piloto fechado** (secção 7) antes de abrir a todos

## 3. Rotina diária do administrador (≈ 5 minutos)
1. Painel → **Definições → Saúde financeira → Reconciliar agora**. Tem de dar ✅. Se der ❌, **não aprove mais saques** e veja a secção 4.
2. **Definições → Economia**: se aparecer "comissões com falha", toque em **Reprocessar**.
3. **Saques**: aprove e pague os pendentes (dois passos). Confira o valor e o método antes de pagar.
4. **Depósitos e assinaturas**: valide comprovativos contra o extrato real antes de aprovar.
5. **Definições → Erros recentes**: veja se há erros repetidos.

## 4. Se algo correr mal
| Situação | O que fazer |
|---|---|
| Reconciliar mostra divergência | Parar aprovações de saques; correr `RECONCILE.sql` para ver as carteiras; enviar-me a lista |
| Comissão falhada | Definições → Reprocessar (é seguro repetir) |
| Utilizador perdeu a palavra-passe | Editar utilizador → **Redefinir palavra-passe** → enviar a temporária por WhatsApp |
| Suspeita de conta comprometida | Editar utilizador → desativar; rever os saques pendentes dessa conta e rejeitá-los se necessário |
| Saque pago por engano | Não existe "desfazer" automático: registar o caso e tratar manualmente com o utilizador |
| Pico de registos falsos | Baixar `REGISTER_GLOBAL_HOURLY_CAP` (secret da função `public-register`) |
| Limites de saque a bloquear clientes legítimos | Definições → Economia → ajustar os três tetos de saque |

## 5. Contas e planos a confirmar (só você consegue)
- **Vercel:** o plano gratuito (Hobby) é para uso pessoal e não comercial — confirme o plano adequado a uma operação com dinheiro.
- **Supabase:** confirme limites do plano, **cópias de segurança automáticas e restauro**, e se o projeto não pausa por inatividade.
- **Chaves:** guarde a `service_role` apenas nos segredos das Edge Functions; nunca em ficheiros do projeto ou no cliente.
- **Domínio e HTTPS** próprios para o lançamento; em Supabase → Authentication → URL Configuration, o Site URL com o domínio final.
- **Contacto de suporte** visível (preencher em `src/lib/legal.ts`).

## 6. Jurídico — perguntas para o advogado
- Uma carteira interna com saques, comissões de afiliados e partilha de resultados exige licença, registo ou notificação em Angola?
- Obrigações fiscais da empresa e eventuais retenções sobre pagamentos a utilizadores.
- Proteção de dados pessoais: base legal, transferências internacionais (Supabase, Vercel, fornecedor de IA), prazos de conservação.
- Política de reembolso, retenção de saldos em caso de fraude, foro e lei aplicável.
- Validação final dos textos em `src/lib/legal.ts` (versão de partida).

## 7. Lançamento por fases
1. **Teste interno** (projeto de teste): todos os testes da secção 2.
2. **Piloto fechado**: ~20 pessoas conhecidas, saques pequenos (reduza os tetos), reconciliação diária.
3. **Abertura gradual**: aumentar tetos e limite de registos por etapas se a reconciliação se mantiver limpa.

## 8. Limitações conhecidas (decisões suas)
- **E-mail não verificado:** exige SMTP (Resend/Brevo). O CAPTCHA já está implementado e ativa-se com as chaves do Turnstile. Entretanto, mitigado por limites de registo e por não haver comissão só por registo.
- **Recuperação de palavra-passe:** feita pelo admin (sem e-mail). Com SMTP, pode passar a ser automática.
- TypeScript não estrito e sem testes automatizados no código da aplicação.

## 9. Procedimentos de manutenção
- **Publicar uma nova versão dos Termos:** altere o texto e `TERMS_VERSION` em `src/lib/legal.ts`, faça o deploy e **no mesmo momento** execute
  `UPDATE public.app_settings SET value = 'NOVA-VERSAO', updated_at = now() WHERE key = 'terms_version';`.
  Todos os utilizadores terão de aceitar de novo (o registo recusa versões que não coincidam com a do servidor).
- **Cabeçalho de segurança (CSP) em `vercel.json`:** está ativo. Se algo deixar de carregar (imagens, letras, CAPTCHA, ligação em tempo real),
  mude a chave `Content-Security-Policy` para `Content-Security-Policy-Report-Only`, volte a publicar e veja a consola do navegador para saber o que falta autorizar.
- **Compromissos assumidos nos Termos:** pagamento de saques até 24 horas e reembolso só nos casos descritos. Confirme que a equipa consegue cumprir.
- **Android:** a pasta `android/` está incompleta (só Gradle); a distribuição é pela PWA.
