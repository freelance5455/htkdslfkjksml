@echo off
cd /d "%~dp0"
node scripts\check-apk.mjs %*
pause
