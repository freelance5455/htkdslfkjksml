import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

/**
 * Worker de push: lê notification_queue, envia FCM, marca sent/failed.
 * Autorização: só service_role (header Authorization = Bearer <SERVICE_ROLE_KEY>).
 * JWT gateway: desligado (cron / invoke com service key).
 *
 * Secrets:
 * - FCM_SERVER_KEY (legado FCM HTTP)  OU
 * - FIREBASE_SERVER_KEY (alias)
 */

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

type QueueRow = {
  id: string;
  user_id: string;
  event_type: string;
  title: string;
  body: string;
  data: Record<string, unknown> | null;
  attempts: number;
};

async function sendFcm(
  serverKey: string,
  token: string,
  title: string,
  body: string,
  data: Record<string, string>
): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch("https://fcm.googleapis.com/fcm/send", {
      method: "POST",
      headers: {
        Authorization: `key=${serverKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        to: token,
        priority: "high",
        notification: { title, body, sound: "default" },
        data: {
          ...data,
          title,
          body,
        },
      }),
    });
    const text = await res.text();
    let parsed: { success?: number; failure?: number; results?: { error?: string }[] } = {};
    try {
      parsed = JSON.parse(text);
    } catch {
      /* ignore */
    }
    if (!res.ok) {
      return { ok: false, error: `http_${res.status}:${text.slice(0, 200)}` };
    }
    if (parsed.failure && parsed.failure > 0) {
      const err = parsed.results?.[0]?.error || "fcm_failure";
      return { ok: false, error: err };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "send_error" };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const fcmKey =
      Deno.env.get("FCM_SERVER_KEY") ||
      Deno.env.get("FIREBASE_SERVER_KEY") ||
      "";

    if (!supabaseUrl || !serviceKey) {
      return json({ error: "Configuração incompleta." }, 500);
    }

    // Só service_role
    const auth = req.headers.get("Authorization") || "";
    const bearer = auth.replace(/^Bearer\s+/i, "").trim();
    if (!bearer || bearer !== serviceKey) {
      return json({ error: "Não autorizado." }, 401);
    }

    if (!fcmKey) {
      return json({ error: "FCM_SERVER_KEY em falta nos secrets." }, 500);
    }

    const admin = createClient(supabaseUrl, serviceKey);
    const body = await req.json().catch(() => ({}));
    const limit = Math.min(Number(body?.limit) || 40, 100);

    const { data: batch, error: claimErr } = await admin.rpc(
      "claim_notification_batch",
      { p_limit: limit }
    );
    if (claimErr) throw claimErr;

    const rows = (batch || []) as QueueRow[];
    let sent = 0;
    let failed = 0;

    for (const row of rows) {
      const { data: tokens } = await admin
        .from("device_tokens")
        .select("token")
        .eq("user_id", row.user_id)
        .eq("enabled", true);

      const list = (tokens || []).map((t: { token: string }) => t.token).filter(Boolean);
      if (list.length === 0) {
        await admin.rpc("mark_notification_failed", {
          p_id: row.id,
          p_error: "no_device_token",
        });
        failed++;
        continue;
      }

      const dataObj: Record<string, string> = {};
      const raw = row.data || {};
      for (const [k, v] of Object.entries(raw)) {
        if (v == null) continue;
        dataObj[k] = typeof v === "string" ? v : JSON.stringify(v);
      }
      if (!dataObj.path && !dataObj.url) {
        // rotas por defeito
        const defaults: Record<string, string> = {
          proof: "/app",
          deposit: "/app",
          withdrawal: "/app",
          subscription: "/app",
          campaign: "/app",
          admin_message: "/app",
          system: "/app",
        };
        dataObj.path = defaults[row.event_type] || "/app";
      }

      let anyOk = false;
      let lastErr = "";
      for (const token of list) {
        const r = await sendFcm(fcmKey, token, row.title, row.body, dataObj);
        if (r.ok) anyOk = true;
        else lastErr = r.error || "fcm_error";

        // Token inválido → desactivar
        if (
          lastErr.includes("NotRegistered") ||
          lastErr.includes("InvalidRegistration")
        ) {
          await admin
            .from("device_tokens")
            .update({ enabled: false })
            .eq("token", token);
        }
      }

      if (anyOk) {
        await admin.rpc("mark_notification_sent", { p_id: row.id });
        sent++;
      } else {
        await admin.rpc("mark_notification_failed", {
          p_id: row.id,
          p_error: lastErr || "all_tokens_failed",
        });
        failed++;
      }
    }

    return json({ processed: rows.length, sent, failed });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : "erro";
    console.error("[push-send]", msg);
    return json({ error: "Falha no envio de push." }, 500);
  }
});
