import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

/**
 * Apaga do Storage os comprovativos já validados (fila proof_purge_queue) e órfãos > 48h.
 * Idempotente e sem parâmetros do cliente: quem chama não escolhe o que se apaga.
 * Chamada: depois de cada validação (front) + agendada (Supabase Cron, ex.: de hora a hora).
 */
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!supabaseUrl || !serviceKey) throw new Error("Configuração do servidor incompleta.");

    const admin = createClient(supabaseUrl, serviceKey);

    const { data: batch, error: claimErr } = await admin.rpc("claim_proof_purge_batch", { p_limit: 100 });
    if (claimErr) throw claimErr;

    const rows = (batch ?? []) as { o_bucket: string; o_path: string }[];
    const byBucket = new Map<string, string[]>();
    for (const r of rows) {
      const list = byBucket.get(r.o_bucket) ?? [];
      list.push(r.o_path);
      byBucket.set(r.o_bucket, list);
    }

    let removed = 0;
    for (const [bucket, paths] of byBucket) {
      const { error: rmErr } = await admin.storage.from(bucket).remove(paths);
      if (rmErr) {
        console.error("[purge-proofs] erro a remover", bucket, rmErr.message);
        continue; // fica na fila e tenta-se de novo na próxima execução
      }
      const { data: n } = await admin.rpc("mark_proofs_purged", { p_paths: paths });
      removed += typeof n === "number" ? n : paths.length;
    }

    // Retenção de logs técnicos (uma vez por execução, é barato)
    await admin.rpc("cleanup_old_logs");

    return json({ purged: removed, pending_batch: rows.length });
  } catch (error: any) {
    console.error("[purge-proofs] erro:", error?.message);
    return json({ error: "Falha na limpeza." }, 500);
  }
});
