import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

// Palavra-passe temporária criptograficamente segura (o utilizador troca-a no primeiro acesso)
function generatePassword(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("") + "!7";
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!supabaseUrl || !serviceKey) throw new Error("Configuração do servidor incompleta.");

    const body = await req.json().catch(() => ({}));
    const email = String(body?.email ?? "").trim().toLowerCase();
    const name = String(body?.name ?? "").trim();
    const phone = String(body?.phone ?? "").trim();
    // Aceitação dos Termos/Privacidade é obrigatória (e fica registada com a versão)
    if (body?.accepted_terms !== true) {
      return json({ error: "Tem de aceitar os Termos e a Política de Privacidade." }, 400);
    }
    const clientTermsVersion = String(body?.terms_version ?? "").trim().slice(0, 40);
    const country = String(body?.country ?? "Angola").trim().slice(0, 60) || "Angola";

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 160) {
      return json({ error: "E-mail inválido." }, 400);
    }
    if (name.length < 2 || name.length > 120) return json({ error: "Indique o seu nome completo." }, 400);
    if (phone.length < 6 || phone.length > 32) return json({ error: "Indique um WhatsApp válido." }, 400);

    const admin = createClient(supabaseUrl, serviceKey);

    // A versão dos termos é a OFICIAL do servidor; o valor do cliente só é conferido (nunca guardado tal e qual)
    const { data: officialVersion, error: verErr } = await admin.rpc("current_terms_version");
    if (verErr || !officialVersion) throw new Error("Versão dos termos não configurada no servidor.");
    if (clientTermsVersion !== officialVersion) {
      return json({ error: "A página está desatualizada. Atualize-a e tente de novo." }, 409);
    }
    const termsVersion = String(officialVersion);

    // CAPTCHA (Cloudflare Turnstile): obrigatório quando o segredo TURNSTILE_SECRET_KEY está configurado
    const turnstileSecret = Deno.env.get("TURNSTILE_SECRET_KEY") ?? "";
    if (turnstileSecret) {
      const token = String(body?.turnstile_token ?? "").trim();
      if (!token) return json({ error: "Confirme que não é um robô e tente de novo." }, 400);
      const form = new URLSearchParams({ secret: turnstileSecret, response: token });
      const remoteIp = (req.headers.get("cf-connecting-ip") || "").trim();
      if (remoteIp) form.set("remoteip", remoteIp);
      const verify = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
        method: "POST",
        body: form,
      }).then((r) => r.json()).catch(() => null);
      if (!verify?.success) {
        return json({ error: "Verificação anti-robô falhou. Atualize a página e tente de novo." }, 400);
      }
    }

    // Rate-limit (anti-farm). O IP vem do Cloudflare (cf-connecting-ip), que o cliente não consegue forjar;
    // x-forwarded-for só como último recurso. Regista PRIMEIRO e conta depois, para que pedidos
    // simultâneos não passem todos pelo mesmo "ainda há margem".
    const ip =
      (req.headers.get("cf-connecting-ip") ||
        req.headers.get("x-real-ip") ||
        (req.headers.get("x-forwarded-for") || "").split(",")[0] ||
        "unknown").trim() || "unknown";
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();

    const { data: logRow, error: logErr } = await admin
      .from("public_register_log")
      .insert({ email, ip })
      .select("id")
      .single();
    if (logErr) throw logErr;

    const [{ count: byIp }, { count: byEmail }, { count: total }] = await Promise.all([
      admin.from("public_register_log").select("id", { count: "exact", head: true }).eq("ip", ip).gte("created_at", since),
      admin.from("public_register_log").select("id", { count: "exact", head: true }).eq("email", email).gte("created_at", since),
      admin.from("public_register_log").select("id", { count: "exact", head: true }).gte("created_at", since),
    ]);
    // Teto global por hora: limita o estrago mesmo que alguém consiga rodar IPs
    // Configurável (secret REGISTER_GLOBAL_HOURLY_CAP). Compromisso: um teto baixo trava farms, mas um atacante
    // com muitos IPs podia esgotá-lo e bloquear registos legítimos; sem CAPTCHA este é o equilíbrio.
    const GLOBAL_HOURLY_CAP = Number(Deno.env.get("REGISTER_GLOBAL_HOURLY_CAP") || 300);
    if ((byIp ?? 0) > 5 || (byEmail ?? 0) > 3 || (total ?? 0) > GLOBAL_HOURLY_CAP) {
      // Pedido recusado: apaga o próprio registo. Assim, recusas não enchem o teto global nem prolongam o
      // bloqueio por e-mail/IP: só contam as tentativas aceites (e as que estão em curso).
      await admin.from("public_register_log").delete().eq("id", logRow.id);
      return json({ error: "Demasiadas tentativas. Tente novamente mais tarde." }, 429);
    }

    const { data: byPhone } = await admin.from("profiles").select("id").eq("phone", phone).maybeSingle();
    if (byPhone) return json({ error: "Este número de telefone já está associado a outra conta." }, 400);

    const password = generatePassword();

    // role NUNCA vem do cliente; o trigger handle_new_user cria o perfil com role 'user'
    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name, phone, country },
    });

    if (createErr) {
      const m = createErr.message || "";
      if (m.includes("already") || m.includes("registered")) {
        return json({ error: "Este e-mail já está associado a uma conta." }, 400);
      }
      throw createErr;
    }

    // Completa dados do perfil (o trigger já o criou)
    await admin
      .from("profiles")
      .update({ name, phone, country, updated_at: new Date().toISOString() })
      .eq("id", created.user.id);

    // Prova do consentimento (se falhar, o ecrã de aceitação volta a aparecer no primeiro acesso)
    const { error: acceptErr } = await admin
      .from("terms_acceptances")
      .insert({ user_id: created.user.id, terms_version: termsVersion, source: "register" });
    if (acceptErr) console.error("[public-register] aceitação não registada:", acceptErr.message);

    // A palavra-passe só é devolvida aqui, uma vez
    return json({ message: "Conta criada com sucesso", email, password });
  } catch (error: any) {
    console.error("[public-register] erro:", error?.message);
    return json({ error: "Não foi possível criar a conta. Tente novamente." }, 400);
  }
});
