import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Tabelas com dinheiro: (tabela, coluna do utilizador). Se existir qualquer linha, a conta NÃO é apagada.
const FINANCIAL_TABLES: Array<[string, string]> = [
  ["wallet_transactions", "user_id"],
  ["withdrawals", "user_id"],
  ["wallet_deposits", "user_id"],
  ["subscription_payments", "user_id"],
  ["engagement_orders", "user_id"],
  ["campaign_requests", "user_id"],
  ["affiliate_commissions", "affiliate_user_id"],
  ["affiliate_commissions", "referred_user_id"],
  ["campaign_result_payouts", "user_id"],
];

async function hasFinancialHistory(admin: any, userId: string): Promise<boolean> {
  const { data: wallet, error: walletErr } = await admin
    .from("wallets")
    .select("balance, reserved_balance")
    .eq("user_id", userId)
    .maybeSingle();
  if (walletErr) return true; // não conseguiu verificar → modo seguro: desativa, não apaga
  if (wallet && (Number(wallet.balance) !== 0 || Number(wallet.reserved_balance) !== 0)) return true;

  for (const [table, col] of FINANCIAL_TABLES) {
    const { count, error } = await admin
      .from(table)
      .select("id", { count: "exact", head: true })
      .eq(col, userId);
    if (error) {
      // tabela ainda inexistente (migração não aplicada) → ignora; qualquer outro erro → modo seguro
      if (error.code === "42P01" || error.code === "PGRST205") continue;
      return true;
    }
    if ((count ?? 0) > 0) return true;
  }
  return false;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    if (!supabaseUrl || !serviceKey) {
      throw new Error("Configuração do servidor incompleta.");
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Cliente com JWT do caller — para validar identidade e role
    const supabaseUser = createClient(supabaseUrl, anonKey || serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user: caller },
      error: callerErr,
    } = await supabaseUser.auth.getUser();

    if (callerErr || !caller) {
      return new Response(JSON.stringify({ error: "Sessão inválida" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    const { data: callerProfile, error: profileErr } = await supabaseAdmin
      .from("profiles")
      .select("id, role, email")
      .eq("id", caller.id)
      .maybeSingle();

    if (profileErr || !callerProfile || callerProfile.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Apenas administradores podem eliminar utilizadores." }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const body = await req.json().catch(() => ({}));
    const userId = body?.userId as string | undefined;
    if (!userId) throw new Error("ID do utilizador necessário");

    if (userId === caller.id) {
      return new Response(
        JSON.stringify({ error: "Não pode eliminar a sua própria conta de administrador." }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: target, error: targetErr } = await supabaseAdmin
      .from("profiles")
      .select("id, role, email")
      .eq("id", userId)
      .maybeSingle();

    if (targetErr) throw targetErr;
    if (!target) throw new Error("Utilizador não encontrado.");

    // Evitar apagar outro admin sem confirmação explícita no body
    if (target.role === "admin" && body?.confirmAdminDelete !== true) {
      return new Response(
        JSON.stringify({
          error:
            "Para eliminar outro administrador, confirme explicitamente (confirmAdminDelete).",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Histórico financeiro (carteira, depósitos, saques, assinaturas, pedidos, comissões) é preservado:
    // nesse caso a conta é DESATIVADA e bloqueada, nunca apagada.
    if (await hasFinancialHistory(supabaseAdmin, userId)) {
      const { error: deactErr } = await supabaseAdmin
        .from("profiles")
        .update({ is_active: false, updated_at: new Date().toISOString() })
        .eq("id", userId);
      if (deactErr) throw deactErr;

      const { error: banErr } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        ban_duration: "876000h",
      });
      if (banErr) throw banErr;

      try {
        await supabaseAdmin.from("activity_logs").insert({
          user_id: caller.id,
          action_type: "ADMIN_DEACTIVATE_USER",
          title: "Conta desativada (histórico financeiro preservado)",
          details: `Admin desativou ${target.email || userId} (${userId})`,
        });
      } catch {
        /* não bloquear */
      }

      return new Response(
        JSON.stringify({
          mode: "deactivated",
          message:
            "A conta tem histórico financeiro, por isso foi DESATIVADA e bloqueada (os registos foram preservados).",
          userId,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Melhor esforço: limpar comprovativos no storage (só chega aqui quem não tem histórico financeiro)
    try {
      const { data: files } = await supabaseAdmin.storage
        .from("subscription-proofs")
        .list(userId, { limit: 100 });
      if (files && files.length > 0) {
        await supabaseAdmin.storage
          .from("subscription-proofs")
          .remove(files.map((f) => `${userId}/${f.name}`));
      }
      const { data: depFiles } = await supabaseAdmin.storage
        .from("subscription-proofs")
        .list(`deposits/${userId}`, { limit: 100 });
      if (depFiles && depFiles.length > 0) {
        await supabaseAdmin.storage
          .from("subscription-proofs")
          .remove(depFiles.map((f) => `deposits/${userId}/${f.name}`));
      }
    } catch (storageErr) {
      console.warn("Storage cleanup (não bloqueante):", storageErr);
    }

    // Log de auditoria antes de apagar
    try {
      await supabaseAdmin.from("activity_logs").insert({
        user_id: caller.id,
        action_type: "ADMIN_DELETE_USER",
        title: "Utilizador eliminado",
        details: `Admin eliminou conta ${target.email || userId} (${userId})`,
      });
    } catch {
      /* não bloquear */
    }

    const { error: delErr } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (delErr) throw delErr;

    return new Response(
      JSON.stringify({ mode: "deleted", message: "Utilizador eliminado com sucesso", userId }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("admin-delete-user:", error);
    return new Response(JSON.stringify({ error: error.message || "Erro" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
