import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// Palavra-passe temporária criptograficamente segura
function generatePassword(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("") + "!7";
}

/**
 * Redefinição de palavra-passe feita por um ADMIN (sem e-mail): gera uma palavra-passe temporária,
 * mostrada ao admin uma única vez, para entregar ao utilizador (ex.: por WhatsApp). O utilizador
 * deve trocá-la em Menu → Alterar palavra-passe. Não permite redefinir outros administradores.
 */
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    if (!supabaseUrl || !serviceKey) throw new Error("Configuração do servidor incompleta.");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Não autorizado" }, 401);

    const supabaseUser = createClient(supabaseUrl, anonKey || serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user: caller }, error: callerErr } = await supabaseUser.auth.getUser();
    if (callerErr || !caller) return json({ error: "Sessão inválida" }, 401);

    const admin = createClient(supabaseUrl, serviceKey);

    const { data: callerProfile } = await admin
      .from("profiles").select("id, role").eq("id", caller.id).maybeSingle();
    if (!callerProfile || callerProfile.role !== "admin") {
      return json({ error: "Apenas administradores podem redefinir palavras-passe." }, 403);
    }

    const body = await req.json().catch(() => ({}));
    const userId = String(body?.userId ?? "");
    if (!userId) return json({ error: "ID do utilizador necessário." }, 400);

    const { data: target } = await admin
      .from("profiles").select("id, email, role, is_active").eq("id", userId).maybeSingle();
    if (!target) return json({ error: "Utilizador não encontrado." }, 404);
    if (target.role === "admin") {
      return json({ error: "Não é possível redefinir a palavra-passe de outro administrador." }, 403);
    }

    const password = generatePassword();
    const { error: updErr } = await admin.auth.admin.updateUserById(userId, { password });
    if (updErr) throw updErr;

    try {
      await admin.from("activity_logs").insert({
        user_id: caller.id,
        action_type: "ADMIN_RESET_PASSWORD",
        title: "Palavra-passe redefinida pelo administrador",
        details: `Utilizador ${target.email || userId}`,
      });
    } catch { /* não bloquear */ }

    return json({ success: true, email: target.email, password });
  } catch (error: any) {
    console.error("[admin-reset-password] erro:", error?.message);
    return json({ error: "Não foi possível redefinir a palavra-passe." }, 400);
  }
});
