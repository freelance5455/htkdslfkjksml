# ADXmoney — Android (Capacitor) · Etapa 2

## Pré-requisitos
- Node 20+
- Android Studio (Ladybug ou mais recente) + SDK 35
- No projecto: `npm install` (instala `@capacitor/*`)

## Build web → nativo
```bash
npm run build          # gera dist/
npx cap sync android   # copia dist + plugins para android/
npx cap open android   # abre no Android Studio
```

Ou num só passo: `npm run build:android`

## Identidade
| Campo | Valor |
|-------|--------|
| appId | `com.adxmoney.app` |
| appName | ADXmoney |
| scheme | `adxmoney://` |
| https host (exemplo) | `adxmoney.app` |

Altera o host em `android/app/src/main/AndroidManifest.xml` para o teu domínio real antes de publicar.

## O que já está nesta etapa
- Projecto `android/` Capacitor 7
- Status bar (init em `src/lib/nativeShell.ts`)
- Deep links (scheme + https) preparados no Manifest
- Permissão `POST_NOTIFICATIONS` (FCM na etapa 3)
- Scripts npm: `build:android`, `cap:sync`, `cap:open`

## O que NÃO está ainda
- FCM / `google-services.json` (etapa 3)
- Push worker Edge
- Biometria, haptics, share plugins (etapas seguintes)

## Nota
Na web (Vercel/PWA) o Capacitor não corre — `initNativeShell()` é no-op.

## Etapa 3 — FCM (push)

1. Firebase Console → app Android `com.adxmoney.app`.
2. Coloca o ficheiro real em `android/app/google-services.json`  
   (modelo: `android/app/google-services.json.example`).
3. ```bash
   npm install
   npm run build:android
   npx cap open android
   ```
4. Login no dispositivo → permissão de notificações → token gravado com `upsert_device_token` (migração **034**).

### Código
- `src/lib/push.ts` — permissão, registo FCM, deep link ao tocar
- `AuthContext` — regista após sessão; desactiva no logout

### Ainda não (etapa 4)
- Edge `push-send` + triggers de eventos

## Etapa 4 — Worker push + eventos

1. SQL: correr `035_push_event_triggers.sql` + VERIFY.
2. Deploy Edge: `supabase functions deploy push-send`
3. Secret: `FCM_SERVER_KEY` (Firebase Console → Cloud Messaging → Server key legada)  
   ou `FIREBASE_SERVER_KEY`.
4. Cron (Supabase Dashboard → Edge Functions → Schedules) a cada 1–5 min:
   - Function: `push-send`
   - Header: `Authorization: Bearer <SERVICE_ROLE_KEY>`
   - Body: `{ "limit": 40 }`

Eventos que enfileiram automaticamente: depósito, saque, assinatura, prova, pedido de campanha.
Admin: RPC `admin_enqueue_notification(user_id, title, body, path)`.

## Etapa 5 — Badge · Haptics · Share · Biometria · Version check

Tudo funciona em PWA (com fallback) e no APK; cada módulo é no-op se falhar. Flags em `src/lib/features.ts`.

| Função | Ficheiro | Nativo | PWA |
|--------|----------|--------|-----|
| Badge | `src/lib/badge.ts` | `@capawesome/capacitor-badge` | `navigator.setAppBadge` |
| Haptics | `src/lib/haptics.ts` | `@capacitor/haptics` | `navigator.vibrate` |
| Share | `src/lib/share.ts` | `@capacitor/share` | `navigator.share` → copiar link |
| Biometria | `src/lib/biometric.ts`, `BiometricLock`, `BiometricSetting` | `@aparajita/capacitor-biometric-auth` | desligada |
| Version check | `src/lib/appVersion.ts`, `UpdateGate` | `App.getInfo()` | `__APP_VERSION__` |

### Para activar
1. SQL: correr `database/036_app_version_config.sql`.
2. No PC (ou CI): `npm install` e fazer commit do `package-lock.json` actualizado.
3. `npm run build:android` (o `cap sync` regista os 4 plugins novos nos `.gradle`).
4. Manter `versionName` em `android/app/build.gradle` alinhado com `min_version`/`latest_version` da tabela.
