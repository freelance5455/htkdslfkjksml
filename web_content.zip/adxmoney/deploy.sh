#!/usr/bin/env bash
# ADXmoney — deploy a partir do telemóvel (Termux). A Vercel instala e compila na nuvem:
# não precisa de npm install nem de build local.
set -e
cd "$(dirname "$0")"

echo "== ADXmoney · deploy para a Vercel =="

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js não encontrado. Instale com:  pkg install -y nodejs"
  exit 1
fi

# 1) Token da Vercel (guardado só no telemóvel, fora da pasta do projeto)
TOKEN_FILE="$HOME/.adx_vercel_token"
if [ -z "$VERCEL_TOKEN" ]; then
  if [ -f "$TOKEN_FILE" ]; then
    VERCEL_TOKEN="$(cat "$TOKEN_FILE")"
  else
    echo
    echo "Crie um token em  https://vercel.com/account/tokens  (Create Token) e cole-o aqui:"
    read -r VERCEL_TOKEN
    [ -z "$VERCEL_TOKEN" ] && { echo "Token vazio."; exit 1; }
    printf '%s' "$VERCEL_TOKEN" > "$TOKEN_FILE"
    chmod 600 "$TOKEN_FILE"
  fi
fi

SCOPE_ARGS=""
[ -n "$VERCEL_SCOPE" ] && SCOPE_ARGS="--scope $VERCEL_SCOPE"

# 2) Ligar ao projeto existente (só na 1.ª vez em cada pasta nova)
if [ ! -f .vercel/project.json ]; then
  DEFAULT_PROJECT="${VERCEL_PROJECT:-adxmoneyv9}"
  printf "Nome do projeto na Vercel [%s]: " "$DEFAULT_PROJECT"
  read -r PROJECT
  PROJECT="${PROJECT:-$DEFAULT_PROJECT}"
  npx --yes vercel@latest link --yes --project "$PROJECT" --token "$VERCEL_TOKEN" $SCOPE_ARGS
fi

# 3) Deploy de produção
echo
echo "A enviar e compilar na Vercel (1–3 minutos)..."
npx --yes vercel@latest deploy --prod --yes --token "$VERCEL_TOKEN" $SCOPE_ARGS

echo
echo "Concluído. Abra o endereço indicado acima (Production)."
