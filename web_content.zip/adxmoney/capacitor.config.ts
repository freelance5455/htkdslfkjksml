import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Shell nativo Android (etapa 2).
 * server.url = site na Vercel; webDir (dist) só fornece o offline.html de fallback.
 */
const config: CapacitorConfig = {
  appId: "com.adxmoney.app",
  appName: "ADXmoney",
  webDir: "dist",
  server: {
    // A app carrega o site publicado na Vercel (atualiza sem recompilar o APK).
    url: "https://adxmoneynative.vercel.app",
    cleartext: false,
    androidScheme: "https",
    allowNavigation: ["adxmoneynative.vercel.app"],
    // Página local (dist/offline.html) mostrada se o servidor não puder ser carregado.
    errorPath: "offline.html",
  },
  android: {
    allowMixedContent: false,
    backgroundColor: "#f2f3f5",
  },
  plugins: {
    SplashScreen: {
      launchAutoHide: true,
      backgroundColor: "#f2f3f5",
      showSpinner: false,
    },
    StatusBar: {
      style: "LIGHT",
      backgroundColor: "#f2f3f5",
    },
  },
};

export default config;
