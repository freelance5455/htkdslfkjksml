@echo off
title ADXmoney - Build Android
cd /d "%~dp0"
echo Pasta do projeto: %CD%
echo.
if not exist package.json (
  echo ERRO: package.json nao encontrado nesta pasta. Extraia o ZIP por completo ^(Extrair tudo^) e execute o .bat dentro da pasta adxmoney.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Node.js nao encontrado. Instale o Node 20 LTS em https://nodejs.org e reinicie o PC.
  pause
  exit /b 1
)
if not exist node_modules\vite (
  echo A instalar dependencias ^(pode demorar alguns minutos^)...
  call npm install --legacy-peer-deps
  if errorlevel 1 (
    echo ERRO no npm install. Veja a mensagem acima.
    pause
    exit /b 1
  )
)
node scripts\build-android.mjs
echo.
echo Codigo de saida: %ERRORLEVEL%
pause
