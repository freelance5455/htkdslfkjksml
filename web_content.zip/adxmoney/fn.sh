#!/usr/bin/env bash
# Copia o código de uma Edge Function para colar no editor do painel do Supabase.
# Uso:  bash fn.sh public-register   |   bash fn.sh admin-delete-user
cd "$(dirname "$0")"
NAME="$1"
FILE="supabase/functions/$NAME/index.ts"
[ -z "$NAME" ] && { echo "Uso: bash fn.sh <nome>"; ls supabase/functions; exit 1; }
[ ! -f "$FILE" ] && { echo "Função não encontrada: $NAME"; ls supabase/functions; exit 1; }
if command -v termux-clipboard-set >/dev/null 2>&1; then
  termux-clipboard-set < "$FILE"
  echo "Copiado: $FILE. Supabase → Edge Functions → $NAME → Code → cole (substitui tudo) → Deploy."
else
  DEST="$HOME/storage/downloads/ADX-SQL"
  mkdir -p "$DEST" 2>/dev/null && cp "$FILE" "$DEST/$NAME.ts" && \
    echo "Copiado para Transferências/ADX-SQL/$NAME.ts. Abra, copie tudo e cole no editor da função no Supabase."
fi
