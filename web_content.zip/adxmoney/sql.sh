#!/usr/bin/env bash
# Copia um ficheiro SQL para a área de transferência, para colar no SQL Editor do Supabase.
# Uso:  bash sql.sh 027        (ou: bash sql.sh VERIFY)
cd "$(dirname "$0")"
KEY="$1"
[ -z "$KEY" ] && { echo "Uso: bash sql.sh 027   |   bash sql.sh VERIFY"; ls database/*.sql | sed 's#database/##'; exit 1; }
FILE="$(ls database/"${KEY}"_*.sql database/"${KEY}".sql 2>/dev/null | head -1)"
[ -z "$FILE" ] && { echo "Ficheiro não encontrado para '$KEY'."; exit 1; }

if command -v termux-clipboard-set >/dev/null 2>&1; then
  termux-clipboard-set < "$FILE"
  echo "Copiado: $FILE ($(wc -l < "$FILE") linhas)."
  echo "Abra o SQL Editor do Supabase, cole e execute."
else
  DEST="$HOME/storage/downloads/ADX-SQL"
  mkdir -p "$DEST" 2>/dev/null && cp "$FILE" "$DEST/" && \
    echo "Copiado para Transferências/ADX-SQL/$(basename "$FILE"). Abra-o com qualquer editor de texto, copie tudo e cole no Supabase." || \
    echo "Sem acesso ao armazenamento. Corra primeiro:  termux-setup-storage"
  echo "(Dica: 'pkg install termux-api' + app Termux:API copia direto para a área de transferência.)"
fi
