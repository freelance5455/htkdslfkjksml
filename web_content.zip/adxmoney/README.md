# ADXmoney

> **A desenvolver no telemóvel?** Siga **`DEPLOY-CELULAR.md`**: base de dados (`sql.sh`) e publicação (`deploy.sh`) sem computador.

> **Antes de abrir ao público:** leia **`LANCAMENTO.md`** (checklist, rotina diária, incidentes, jurídico).

PWA (React + Vite + TypeScript + Tailwind) com backend Supabase (Auth, Postgres/RLS, Storage, Edge Functions).
A pasta `android/` contém **apenas configuração Gradle (incompleta)**: não tem `AndroidManifest.xml` nem a atividade da WebView, por isso **não compila como app Android**. O canal de distribuição é a **PWA** (instalável pelo navegador).

## Estrutura
| Pasta | Conteúdo |
|---|---|
| `src/` | App web (rotas em `src/App.tsx`; Admin e App do utilizador carregados a pedido) |
| `database/` | Migrações SQL numeradas + `VERIFY.sql` (ver `database/README.md`) |
| `supabase/functions/` | Edge Functions: `public-register`, `admin-create-user`, `admin-delete-user`, `ai-*` |
| `android/` | Shell Android (WebView), abre no Android Studio |

## Desenvolvimento
```bash
npm ci --legacy-peer-deps
npm run dev          # http://localhost:5173
npm run build        # gera dist/
```
Variável opcional: `VITE_PUBLIC_URL` (domínio público, usado nos links de convite).

## Produção (checklist)
1. **SQL** — correr `database/` na ordem de `database/README.md` (014 → 029) e depois `VERIFY.sql` (todas as linhas `ok = true`).
2. **Edge Functions** — `supabase functions deploy` (usa `supabase/config.toml`: `public-register` sem verificação de JWT, é chamada sem sessão). Funções: `public-register`, `admin-create-user`, `admin-delete-user`, `purge-proofs`, `ai-coach`, `ai-support`, `ai-generate-content`.
3. **Secret das funções de IA** — `supabase secrets set GROQ_API_KEY=...` (as restantes variáveis são injectadas pelo Supabase).
4. **Cron (opcional)** — agendar `purge-proofs` de hora a hora para libertar espaço do Storage.
5. **Vercel** — importar o repositório (usa `vercel.json`; `npm ci --legacy-peer-deps` + `npm run build`). Variável opcional `VITE_PUBLIC_URL`.
6. **Auth** — no Supabase, em *Authentication → URL Configuration*, definir o Site URL com o domínio da Vercel.
7. **Testes** — criar/eliminar utilizador, aprovar pedido de campanha e de engajamento, validar prova, pagar/recusar saque.
