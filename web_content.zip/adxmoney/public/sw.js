/* ADXmoney PWA — shell offline (login + app) */
const CACHE = "adx-v3-offline";
const PRECACHE = [
  "/",
  "/index.html",
  "/login",
  "/register",
  "/manifest.webmanifest",
  "/logo.png",
  "/favicon.ico",
  "/sw.js"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then(async (cache) => {
        // index.html é o fallback SPA; /login e /register podem falhar no addAll se o host não as servir estáticas
        try {
          await cache.addAll(["/", "/index.html", "/manifest.webmanifest", "/logo.png", "/favicon.ico", "/icon-192.png", "/home-mascot.png"]);
        } catch (_) {
          /* precache parcial ok */
        }
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Nunca interceptar API / Auth Supabase
  if (
    url.hostname.includes("supabase.co") ||
    url.pathname.startsWith("/functions") ||
    url.pathname.includes("/auth/v1")
  ) {
    return;
  }

  // Navegação SPA: network first → fallback index.html (permite /login offline)
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => {
            c.put("/index.html", copy);
            c.put(req, res.clone()).catch(() => {});
          });
          return res;
        })
        .catch(async () => {
          const cached =
            (await caches.match(req)) ||
            (await caches.match("/index.html")) ||
            (await caches.match("/"));
          if (cached) return cached;
          return new Response(
            "<!DOCTYPE html><html lang=pt><head><meta charset=utf-8><meta name=viewport content=\"width=device-width,initial-scale=1\"><title>ADXmoney</title></head><body style=\"font-family:system-ui;background:#f8fafc;color:#0f172a;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0\"><div style=\"text-align:center;padding:24px\"><h1 style=\"font-size:18px;margin:0 0 8px\">ADXmoney</h1><p style=\"font-size:13px;color:#64748b\">Sem internet. Abra novamente quando tiver dados para carregar o app.</p></div></body></html>",
            { headers: { "Content-Type": "text/html; charset=utf-8" } }
          );
        })
    );
    return;
  }

  // Ficheiros com hash (/assets/*) são imutáveis: cache first.
  if (url.pathname.startsWith("/assets/")) {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req)
          .then((res) => {
            if (!res || res.status !== 200 || res.type === "opaque") return res;
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
            return res;
          })
          .catch(() => cached);
      })
    );
    return;
  }

  // Restante (logo, ícones, manifest...): network first → cache só como fallback offline.
  // Assim uma imagem atualizada na Vercel aparece logo, e continua a funcionar sem rede.
  event.respondWith(
    fetch(req)
      .then((res) => {
        if (res && res.status === 200 && res.type !== "opaque") {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req))
  );
});
