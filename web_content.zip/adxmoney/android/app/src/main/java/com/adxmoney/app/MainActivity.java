package com.adxmoney.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
