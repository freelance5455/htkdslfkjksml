# ADXmoney — APK com Android Studio (Capacitor 7, NÃO é app nativo)

O APK é um "contentor" (WebView) que abre o site publicado na Vercel: **https://adxmoneynative.vercel.app**.
- Fazer deploy na Vercel atualiza a app instantaneamente, sem recompilar o APK.
- Sem internet: o Service Worker mostra o boot/login em cache; se nunca foi carregado, aparece `offline.html` (empacotada no APK) com botão "Tentar novamente".
- A app **não usa** `https://localhost`: o `capacitor.config.ts` define `server.url`.

## Versões fixas (não mudar, evita conflitos)
Android **10+** (minSdk 29) · compileSdk/targetSdk 35 · Capacitor 7.6.10 · AGP 8.7.2 · Gradle 8.11.1 · JDK **21** · `com.adxmoney.app`

## Passos (PC Windows)
1. Instalar: Node.js 20 LTS (ou 22), Android Studio recente (traz JDK 21). SDK Manager: **Android SDK Platform 35** + **Build-Tools 35.x**.
2. Extrair o zip num caminho curto, ex.: `C:\Projetos\adxmoney`.
3. Duplo clique em **`BUILD-ANDROID.bat`**. Instala dependências, compila, sincroniza e verifica (server.url, offline.html, plugins). Só avança com "✅ Pronto".
   - Manual: `npm install --legacy-peer-deps` → `npm run build:android`.
4. Android Studio → **Open** → pasta `adxmoney\android` (não `app`) → esperar o Gradle Sync. Gradle JDK = **21** (Settings → Build Tools → Gradle).
5. **Build → Build APK(s)** (ou `gradlew.bat assembleDebug` na pasta `android`). Saída: `android\app\build\outputs\apk\debug\app-debug.apk`.

> Mudou só o site? Basta deploy na Vercel. Mudou plugins, ícones, manifest ou `capacitor.config.ts`? Repetir o passo 3 e recompilar.

## Ativar o google-services.json (push / FCM)
1. https://console.firebase.google.com → **Adicionar projeto** (ou usar um existente).
2. Dentro do projeto → **Adicionar app → Android**. Nome do pacote exatamente: `com.adxmoney.app`. (SHA-1 não é necessário para push.)
3. **Baixar `google-services.json`** e copiar para `android\app\google-services.json` (dentro de `app`, não na raiz de `android`). O Gradle aplica o plugin Google Services automaticamente quando o ficheiro existe e tem conteúdo.
4. Android Studio → **Sync Project with Gradle Files** → recompilar o APK. Package diferente de `com.adxmoney.app` no ficheiro faz o build falhar.
5. Servidor: a função `push-send` ainda usa a API FCM **legada** (`FCM_SERVER_KEY`), que a Google descontinuou. Para o envio funcionar é preciso migrar para a API FCM HTTP v1 (Firebase → Definições do projeto → Contas de serviço → Gerar chave privada, guardada como secret no Supabase). Sem isto, o `google-services.json` só permite registar o dispositivo; as notificações não são entregues.
Sem `google-services.json` a app abre normalmente; só o push fica inativo.

## Problemas conhecidos
**Tela de erro / página branca ao abrir**: confirmar que `https://adxmoneynative.vercel.app` abre no navegador do telemóvel e que o último deploy da Vercel passou. Sem internet deve aparecer a tela "Sem ligação" do ADXmoney.

**Google Play Protect bloqueia a instalação**: normal em APK fora da Play Store, sobretudo com chave de debug.
- Teste: "Mais detalhes → Instalar mesmo assim", ou Play Store → perfil → Play Protect → Definições → desligar "Analisar apps" só durante o teste. Ativar "Instalar apps desconhecidos" para o app usado (Ficheiros/Chrome).
- Melhor: APK **release assinado**. Criar chave (uma vez; guardar o `.jks` e as senhas — perdê-las impede atualizações): `keytool -genkeypair -v -keystore adxmoney-release.jks -alias adxmoney -keyalg RSA -keysize 2048 -validity 10000`. Copiar `android\keystore.properties.example` para `android\keystore.properties`, preencher, e usar **Build → Generate Signed App Bundle / APK** ou `gradlew.bat assembleRelease`.
- Distribuição pública: Play Console. Atenção: a Google pode recusar apps que sejam apenas um site embutido; o Play Protect pode continuar a avisar.

**USB e "não abre"**: desinstalar a versão anterior; correr `app` pelo Android Studio; abrir **Logcat** com filtro `package:com.adxmoney.app` e enviar o erro.

## Notas
- Registo com Cloudflare Turnstile: o domínio `adxmoneynative.vercel.app` tem de estar nos hostnames permitidos da chave.
- Deep link HTTPS no manifest aponta para `adxmoneynative.vercel.app` (verificação automática exigiria `assetlinks.json` com a assinatura do APK; ainda não configurado).
- Testar: login, logout, sessão, uploads, links externos, botão Voltar, modo avião, biometria, partilha, barra de status no Android 15.

## Diagnóstico: o APK continua a abrir https://localhost
1. No cmd, na pasta do projeto: `node scripts\check-apk.mjs` (ou duplo clique em `CHECK-APK.bat`). Mostra o `server.url` que está DENTRO do APK, se o `offline.html` foi empacotado e se o APK é mais antigo que o último sync.
2. Ao gerar o APK, a aba **Build** do Android Studio mostra `[ADX] Projeto web: ...` e `[ADX] ... server.url = ...`. Confirme que o caminho é a pasta onde correu o `BUILD-ANDROID.bat`. Se o build falhar com `[ADX]`, siga a mensagem.
3. Desinstale o app do telemóvel e instale o APK recém-gerado (confira a data do ficheiro).
4. Com o telemóvel por USB: `adb logcat -s Capacitor` e abra a app. A linha "Loading app at ..." mostra o endereço realmente carregado.
