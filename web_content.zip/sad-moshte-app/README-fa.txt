ساخت APK بازی (فقط یک بار)
پیش‌نیاز: Node.js و Android Studio

1) npm install @capacitor/core @capacitor/cli @capacitor/android
2) npx cap add android
3) node patch-android.js      (قفل افقی + تمام‌صفحه)
4) npx cap sync
5) npx cap open android
6) در Android Studio: Build > Generate Signed Bundle / APK > APK

موسیقی: فایل normal-guy.mp3 را (خودت تهیه کن) کنار www/index.html بگذار، قبل از مرحله 4.
اسم بسته: ir.example.sadmoshte را در capacitor.config.json قبل از مرحله 2 عوض کن.
