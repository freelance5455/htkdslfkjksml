// بعد از "npx cap add android" اجرا کن: node patch-android.js
const fs = require('fs');
const mf = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('screenOrientation')) {
  x = x.replace('<activity', '<activity android:screenOrientation="sensorLandscape"');
  fs.writeFileSync(mf, x);
  console.log('Landscape lock applied.');
}
const sf = 'android/app/src/main/res/values/styles.xml';
let s = fs.readFileSync(sf, 'utf8');
if (!s.includes('windowFullscreen')) {
  s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
  fs.writeFileSync(sf, s);
  console.log('Fullscreen applied.');
}
