1. Откройте папку в Android Studio (File > Open).
2. Дождитесь Gradle Sync (Android Studio сам создаст gradle wrapper).
3. Build > Build APK(s) — готовый APK появится в app/build/outputs/apk/debug/.
Весь интерфейс лежит в app/src/main/assets/index.html.
