DAILY DIARY - ANDROID WEB APP BUNDLE

Files:
- index.html: the complete offline-capable diary web app.
- manifest.json: basic web-app metadata.

BUILDING AN ANDROID APK
1. Upload this ZIP bundle to your chosen HTML-to-Android app builder.
2. Set the app name to Daily Diary.
3. Set index.html as the start page if the builder asks.
4. Build/export the APK, then download and install it on your Android phone.
5. Android may ask you to allow installation from the browser or file manager you used. Only install APKs from a builder you trust.

FEATURES
- Daily journal entries with edit/delete and optional photos.
- Mood check-ins.
- Calendar view with entry markers.
- Search entries.
- Goals and habit completion tracking.
- Daily quote and gratitude notes.
- Writing streak, mood summary and On This Day memories.
- Light/dark theme.
- Optional PIN lock.
- JSON backup/restore and CSV export.
- Device-local storage; no account required.

IMPORTANT PRIVACY / STORAGE NOTES
- Data is stored in the app's local browser storage on the device; it is not synced to an account.
- The PIN is a basic barrier, not encryption. Do not treat it as secure protection against someone with technical access to the device.
- Uninstalling the app, clearing app/browser storage, or some builder settings can erase data. Export JSON backups regularly.
- The app uses browser localStorage, which has a storage limit. Photos are resized before saving, but keep photo counts modest and export backups.
- If the app builder wraps this page in a WebView, verify local storage persistence by creating a test entry, closing/reopening the app, and confirming it remains.
