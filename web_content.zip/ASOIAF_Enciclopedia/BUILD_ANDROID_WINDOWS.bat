@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo ASOIAF - Android APK builder
echo Requires Node.js, Android Studio and Android SDK
echo ===============================================
where node >nul 2>nul || (echo Node.js is missing.& pause& exit /b 1)
if not exist node_modules (echo Installing app dependencies...& npm install) || (echo Dependencies already installed.)
if not exist android (echo Creating Android project...& npx cap add android) || (echo Android project already exists.)
echo Syncing app files...
npx cap sync android
if errorlevel 1 (echo Sync failed.& pause& exit /b 1)
cd android
call gradlew.bat assembleDebug
if errorlevel 1 (echo APK build failed. Check Android SDK configuration.& pause& exit /b 1)
echo.
echo APK created at: android\app\build\outputs\apk\debug\app-debug.apk
pause
