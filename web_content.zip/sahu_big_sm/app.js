const $ = id => document.getElementById(id);
const configured = window.SUPABASE_URL?.startsWith("https://") && !window.SUPABASE_URL.includes("YOUR_") && window.SUPABASE_ANON_KEY && !window.SUPABASE_ANON_KEY.includes("YOUR_");
let db, currentUser, busy = false;
if (configured && window.supabase) db = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);

function message(t){$("authmsg").textContent=t}
function showSession(user){
  currentUser=user;
  $("auth").classList.toggle("hidden",!!user); $("app").classList.toggle("hidden",!user);
  $("logout").classList.toggle("hidden",!user);
  if(user){$("useremail").textContent=user.email||""; loadProfile(); loadHistory(); checkAdmin();}
}
async function authAction(mode){
  if(!db){message("Setup required: add Supabase URL and anon key in config.js.");return}
  const email=$("email").value.trim(), password=$("password").value;
  if(!email||password.length<8){message("Enter a valid email and password (minimum 8 characters).");return}
  message("Please wait…");
  const {data,error}=mode==="signup"?await db.auth.signUp({email,password}):await db.auth.signInWithPassword({email,password});
  if(error){message(error.message);return}
  if(mode==="signup"&&!data.session)message("Account created. Check your email to confirm, then sign in.");
  else message("Signed in.");
}
$("signup").onclick=()=>authAction("signup"); $("login").onclick=()=>authAction("login");
$("logout").onclick=async()=>{await db?.auth.signOut();showSession(null)};
async function loadProfile(){
  const {data,error}=await db.from("profiles").select("demo_points").eq("id",currentUser.id).single();
  $("balance").textContent=error?"—":data.demo_points;
}
async function loadHistory(){
  const {data,error}=await db.from("rounds").select("id,choice,number,result,created_at").eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(10);
  if(error){$("history").innerHTML='<p class="muted">Could not load history yet.</p>';return}
  $("history").innerHTML=data.length?data.map(r=>`<div class="history-row"><span>${new Date(r.created_at).toLocaleString()} · ${r.choice}</span><b class="${r.result==='WIN'?'win':'loss'}">${r.result} (${r.number})</b></div>`).join(""):'<p class="muted">No rounds yet.</p>';
}
function secureRandomDigit(){const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]%10}
async function play(choice){
  if(!db||!currentUser||busy)return;
  busy=true;document.querySelectorAll(".choice").forEach(b=>b.disabled=true);
  $("result").textContent="Drawing a fair random result…";
  const number=secureRandomDigit(), result=(number>=5?"BIG":"SMALL")===choice?"WIN":"LOSE";
  const {error}=await db.from("rounds").insert({user_id:currentUser.id,choice,number,result});
  if(error)$("result").textContent="Round could not be saved: "+error.message;
  else{$("result").textContent=`Number ${number} · ${number>=5?"BIG":"SMALL"} · ${result}`;await loadHistory()}
  document.querySelectorAll(".choice").forEach(b=>b.disabled=false);busy=false;
}
document.querySelectorAll(".choice").forEach(b=>b.onclick=()=>play(b.dataset.choice));
async function checkAdmin(){
  const {data}=await db.from("profiles").select("role").eq("id",currentUser.id).single();
  if(data?.role==="admin"){$("admin").classList.remove("hidden");$("adminstats").textContent="Admin role verified."}
}
if(db)db.auth.getSession().then(({data})=>showSession(data.session?.user||null));
else message("Website setup: connect a Supabase project using config.js to enable online accounts and saved game history.");
